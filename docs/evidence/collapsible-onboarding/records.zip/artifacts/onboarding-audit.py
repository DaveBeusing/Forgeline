import hashlib,json,math
from pathlib import Path
from PIL import Image
source="6aad37feebcce50adbb02dcd90c60cf85694fcd1"
rows=[]
for name in ["onboarding-reference-1080","onboarding-reference-dark","onboarding-reference-4k"]:
 root=Path("artifacts")/name
 m=json.loads((root/"manifest.json").read_text(encoding="utf-8-sig"))
 assert m["commit"]==source and m["status"]=="structural-pass" and m["buildIdentity"].endswith(source)
 for c in m["captures"]:
  p=root/c["image"]; image=Image.open(p).convert("RGBA")
  assert hashlib.sha256(p.read_bytes()).hexdigest().upper()==c["imageSha256"].upper()
  assert hashlib.sha256(image.tobytes()).hexdigest().upper()==c["pixelSha256"].upper()
  assert image.size==(c["requestedDisplay"]["width"],c["requestedDisplay"]["height"])
  assert c["repeatPixelsEqual"] and c["repeatCaptures"]==8 and not c["repeatFailures"]
  ui=c["ui"]; text=ui["text"]; skin=ui["battlefieldSkin"]
  assert text["atlasReady"] and text["missingGlyphs"]==0 and text["droppedGlyphs"]==0
  assert skin["missingAssets"]==0 and skin["droppedQuads"]==0 and skin["residentPageBytes"]==28*1024*1024
  for r in ui["regions"]:
   pixels=image.crop((r["x"],r["y"],r["x"]+r["width"],r["y"]+r["height"])).tobytes()
   assert hashlib.sha256(pixels).hexdigest().upper()==r["pixelSha256"].upper()
  frames=c["performance"]["cpuFrames"]
  assert all(f["health"]["submissionFaultCount"]==0 for f in frames)
  assert len({f["resources"]["textureUploadCount"] for f in frames})==1
  assert len({f["resources"]["residentTextureBytes"] for f in frames})==1
  rows.append(dict(root=name,key=c["key"],png=str(p.resolve()),pngSha256=c["imageSha256"],rgbaSha256=c["pixelSha256"],dimensions=image.size,
   repeats=c["repeatCaptures"],glyphs=text["glyphs"],textUploadBytes=text["uploadBytes"],skinUploadBytes=skin["vertexUploadBytes"],skinBuffers=skin["buffers"],
   atlasBytes=skin["residentPageBytes"],nativeFullFrameAllocations=c["performance"]["allocations"],visualAcceptance="pending"))
assert len(rows)==14
root=Path("artifacts/onboarding-qualified-sequence")
m=json.loads((root/"qualification.json").read_text(encoding="utf-8-sig"))
assert m["Source"].endswith(source) and len(m["Cases"])==120 and m["Health"]["SubmissionFaultCount"]==0 and m["Health"]["PendingRetirementCount"]==0
endpoints={}; sequence=[]
for c in m["Cases"]:
 s=c["State"]; t=c["Milliseconds"]/220; ease=t*t*(3-2*t)
 expected=(1 if c["Direction"]=="Closing" else 0) if c["ReducedMotion"] else (ease if c["Direction"]=="Closing" else 1-ease)
 assert abs(s["Collapse"]-expected)<1e-5
 panel,clip,visible,tab=(s[k] for k in ["Panel","Clip","VisiblePanel","Tab"])
 assert abs(visible["Width"]-max(0,min(panel["Right"],clip["Right"])-max(panel["X"],clip["X"])))<.001
 assert s["Visible"] and c["Text"]["MissingGlyphs"]==0 and c["Text"]["DroppedGlyphs"]==0
 assert c["Skin"]["MissingAssets"]==0 and c["Skin"]["DroppedQuads"]==0 and c["Skin"]["Buffers"]==52
 assert c["Skin"]["ResidentPageBytes"]==28*1024*1024
 if expected==1: assert visible["IsEmpty"] and not tab["IsEmpty"]
 path=root/(c["Key"]+".png")
 if path.exists():
  im=Image.open(path).convert("RGBA");assert hashlib.sha256(im.tobytes()).hexdigest().upper()==c["PixelSha256"]
 sequence.append(dict(key=c["Key"],phase=s["Phase"],collapse=s["Collapse"],rgbaSha256=c["PixelSha256"]))
assert len(list(root.glob("*.png")))==40
report=dict(source=source,status="structural-pass",canonical=rows,sequence=sequence,scope="Original PNG/RGBA/region hashes, repeated native pixels, exact time-based transforms and bounded warm resource diagnostics. No golden or human acceptance.")
Path("artifacts/onboarding-audit.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print("Audited 14 canonical images with eight equal repeats and 120 controller sequence samples / 40 original PNGs with two equal repeats.")
print("Native skin: 52 buffers, 28 MiB shared atlases; no missing/dropped glyphs or skin, no submission faults, stable warm texture resources.")
