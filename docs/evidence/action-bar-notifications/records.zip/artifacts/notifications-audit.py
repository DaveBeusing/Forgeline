import hashlib,json
from pathlib import Path
from PIL import Image,ImageStat

source="2cd5a2ade90420e4cd4e3c3b9e92c447842dfd2c"
roots=["day","dark","compact","compact-max","large"]
rows=[]
for lane in roots:
    root=Path("artifacts")/("notifications-final-"+lane)
    manifest=json.loads((root/"manifest.json").read_text(encoding="utf-8-sig"))
    assert manifest["commit"]==source and manifest["status"]=="structural-pass"
    assert manifest["buildIdentity"].endswith(source)
    for capture in manifest["captures"]:
        path=root/capture["image"]
        assert hashlib.sha256(path.read_bytes()).hexdigest().upper()==capture["imageSha256"].upper()
        image=Image.open(path).convert("RGBA")
        assert image.size==(capture["requestedDisplay"]["width"],capture["requestedDisplay"]["height"])
        assert hashlib.sha256(image.tobytes()).hexdigest().upper()==capture["pixelSha256"].upper()
        assert capture["repeatPixelsEqual"] and not capture["repeatFailures"]
        ui=capture["ui"]; text=ui["text"]; skin=ui["battlefieldSkin"]
        assert text["atlasReady"] and not text["missingGlyphs"] and not text["droppedGlyphs"]
        assert not skin["missingAssets"] and not skin["droppedQuads"]
        for region in ui["regions"]:
            pixels=image.crop((region["x"],region["y"],region["x"]+region["width"],region["y"]+region["height"])).tobytes()
            assert hashlib.sha256(pixels).hexdigest().upper()==region["pixelSha256"].upper()
        stack=ui["notifications"]; regions={r["name"]:r for r in ui["regions"]}
        dock=regions["action-dock"]; minimap=regions["minimap"]
        assert stack["fontSize"]>=14 and stack["count"]<=4
        assert abs(stack["bounds"]["right"]-(dock["x"]+dock["width"]))<1
        assert stack["bounds"]["y"]>dock["y"]+dock["height"]
        assert stack["bounds"]["bottom"]<=minimap["y"]
        cards=[stack[k] for k in ["first","second","third","overflow"]][:stack["count"]]
        for card in cards:
            b=card["bounds"]; region=stack["bounds"]
            assert b["x"]>=region["x"] and b["right"]<=region["right"]+.001
            assert b["y"]>=region["y"] and b["bottom"]<=region["bottom"]+.001
        frames=capture["performance"]["cpuFrames"]
        assert all(f["health"]["submissionFaultCount"]==0 for f in frames)
        uploads={f["resources"]["textureUploadCount"] for f in frames}
        residents={f["resources"]["residentTextureBytes"] for f in frames}
        assert len(uploads)==1 and len(residents)==1
        width,height=image.size
        world=ImageStat.Stat(image.crop((width//4,height//3,width//2,height*2//3))).mean[:3]
        rows.append(dict(lane=lane,key=capture["key"],image=str(path.resolve()),pngSha256=capture["imageSha256"],
            rgbaSha256=capture["pixelSha256"],nativeSize=image.size,repeatCaptures=capture["repeatCaptures"],
            fontSize=stack["fontSize"],visibleCards=stack["count"],hudVertices=ui["vertices"],
            skinDraws=skin["draws"],skinVertices=skin["vertices"],skinUploadBytes=skin["vertexUploadBytes"],
            textVertices=text["vertices"],textUploadBytes=text["uploadBytes"],
            nativeFullFrameAllocations=capture["performance"]["allocations"],
            skinResidentBytes=skin["residentPageBytes"],warmTextureUploadDelta=0,
            worldMeanRgb=world,visualAcceptance="pending"))
assert len(rows)==15
report=dict(source=source,status="structural-pass",captures=rows,
    scope="Independent original PNG/RGBA/region hashes, dimensions, shared card bounds, repeated native pixels and stable warm texture resources; no human or sustained-FPS acceptance")
Path("artifacts/notifications-native-audit.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print("15 original PNG/RGBA/region hashes and native contracts verified; 8 repeated captures per image.")
print("HUD vertices",min(r["hudVertices"] for r in rows),max(r["hudVertices"] for r in rows),
      "skin draws",min(r["skinDraws"] for r in rows),max(r["skinDraws"] for r in rows),
      "font",min(r["fontSize"] for r in rows),max(r["fontSize"] for r in rows))
