from pathlib import Path
import zipfile,json,hashlib
p=Path('artifacts/graphical-tactical-package/FORGELINE-0.1.379-dev-win-x64.zip')
with zipfile.ZipFile(p) as z:
 names=set(z.namelist()); checked=0
 for line in z.read('manifest.sha256').decode('utf-8-sig').splitlines():
  digest,name=line.split('  ',1); assert hashlib.sha256(z.read(name)).hexdigest()==digest,name; checked+=1
 manifest=json.loads(z.read('assets/runtime/manifest.json'))
 for asset in manifest['assets']:
  raw=z.read('assets/runtime/'+asset['runtimePath']); assert len(raw)==asset['runtimeBytes']; assert hashlib.sha256(raw).hexdigest()==asset['runtimeHash']
 forbidden=[n for n in names if '/source/' in n.lower() or '/reference/' in n.lower() or Path(n).suffix.lower() in ['.cs','.csproj','.sln','.svg','.ps1','.py']]
 assert not forbidden,forbidden
 dev=Path('assets/runtime'); pack={n.removeprefix('assets/runtime/'):n for n in names if n.startswith('assets/runtime/') and not n.endswith('/')}
 shared=0
 for f in dev.rglob('*'):
  if f.is_file():
   key=f.relative_to(dev).as_posix(); assert f.read_bytes()==z.read(pack[key]),key; shared+=1
 extras=sorted(set(pack)-{f.relative_to(dev).as_posix() for f in dev.rglob('*') if f.is_file()})
 assert extras==['audio/ui/accepted.wav','audio/ui/intent.wav','audio/ui/navigation.wav','audio/ui/rejected.wav','branding/studio-intro.mp4','branding/studio-intro.wav'],extras
 provenance=json.loads(z.read('build-provenance.json'))
before=json.loads(Path('artifacts/tactical-native-final-normal/manifest.json').read_text(encoding='utf-8-sig'))
after=json.loads(Path('artifacts/tactical-native-packaged/manifest.json').read_text(encoding='utf-8-sig'))
assert after['status']=='structural-pass' and after['commit']==before['commit']
by_key={c['key']:c for c in before['captures']}
assert len(after['captures'])==5
for c in after['captures']:
 assert c['repeatPixelsEqual'] and c['imageSha256']==by_key[c['key']]['imageSha256'] and c['pixelSha256']==by_key[c['key']]['pixelSha256'],c['key']
smoke=Path('artifacts/tactical-package-smoke.log').read_text(encoding='utf-8-sig')
assert 'createdDefaults=True' in smoke,smoke[-1000:]
result=dict(source=before['commit'],archive=str(p),archiveBytes=p.stat().st_size,archiveSha256=hashlib.sha256(p.read_bytes()).hexdigest(),verifiedManifestFiles=checked,verifiedRuntimeAssets=len(manifest['assets']),sharedRuntimeFiles=shared,packageOnlyPlaybackSidecars=extras,sourceFilesExcluded=True,exactPackagedCaptureMatches=5,createdFreshSettings=True,developmentRuntimeFingerprint=before['runtimeFingerprint'],packagedRuntimeFingerprint=after['runtimeFingerprint'],provenance=provenance)
Path('artifacts/tactical-package-verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='provenance'},indent=2))
