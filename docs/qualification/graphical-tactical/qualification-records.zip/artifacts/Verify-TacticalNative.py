from pathlib import Path
import json,hashlib
from PIL import Image
SOURCE='0cb9b8089f84abfdce0e754e9176be5c4628c16b'
roots={'tactical-native-final-normal':5,'tactical-native-final-close':5,'tactical-native-final-world-zooms':3,'tactical-native-final-compact':15,'tactical-native-final-wide':10,'tactical-native-final-4k':5,'tactical-native-final-dark':5}
rows=[]; identities=[]
for root,count in roots.items():
 p=Path('artifacts')/root/'manifest.json';j=json.loads(p.read_text(encoding='utf-8-sig'))
 assert j['commit']==SOURCE and j['status']=='structural-pass',(root,j['status'])
 assert len(j['captures'])==count
 identities.append(dict(root=str(p.parent),manifestSha256=hashlib.sha256(p.read_bytes()).hexdigest(),source=j['commit'],runtimeFingerprint=j['runtimeFingerprint'],clientAssemblySha256=j['clientAssemblySha256'],presentationAssemblySha256=j['presentationAssemblySha256'],cases=count))
 for c in j['captures']:
  s=c['ui']['battlefieldSkin'];t=c['ui']['text'];image=p.parent/c['image'];native=Image.open(image).convert('RGBA')
  assert c['repeatPixelsEqual'] and not c['repeatFailures'],c['key']
  assert s['missingAssets']==s['droppedQuads']==t['missingGlyphs']==t['droppedGlyphs']==0,c['key']
  assert native.size==(c['requestedDisplay']['width'],c['requestedDisplay']['height'])
  assert c['actualSurface']['width']==native.width and c['actualSurface']['height']==native.height
  assert hashlib.sha256(image.read_bytes()).hexdigest().upper()==c['imageSha256'].upper()
  assert hashlib.sha256(native.tobytes()).hexdigest().upper()==c['pixelSha256'].upper()
  assert c['visualReview']=='pending'
  rows.append(dict(root=root,key=c['key'],image=c['image'],imageSha256=c['imageSha256'],pixelSha256=c['pixelSha256'],skin=s,cpu=c['cpu'],gpu=c['gpu'],camera=c['camera'],rasterDpi=c['rasterDpi'],uiScale=c['uiScale'],resources=c['graphics']['resources'],health=c['graphics']['health'],debug=c['graphics']['debug']))
assert len(rows)==48
for key in ['runtimeFingerprint','clientAssemblySha256','presentationAssemblySha256']:
 assert len({i[key] for i in identities})==1,key
result=dict(source=SOURCE,totalCases=len(rows),roots=identities,humanVisualAcceptance='pending',
 skin=dict(residentBytes=sorted({r['skin']['residentPageBytes'] for r in rows}),batches=sorted({r['skin']['batches'] for r in rows}),buffers=sorted({r['skin']['buffers'] for r in rows}),
 draws=[min(r['skin']['draws'] for r in rows),max(r['skin']['draws'] for r in rows)],vertices=[min(r['skin']['vertices'] for r in rows),max(r['skin']['vertices'] for r in rows)],uploadBytes=[min(r['skin']['vertexUploadBytes'] for r in rows),max(r['skin']['vertexUploadBytes'] for r in rows)]),cases=rows)
Path('artifacts/tactical-native-verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ['cases','roots']},indent=2))
