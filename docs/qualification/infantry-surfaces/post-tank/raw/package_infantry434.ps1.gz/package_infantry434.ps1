$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$repo=Split-Path -Parent $PSScriptRoot
Set-Location $repo
& ./build/Publish-PreAlpha.ps1 -Configuration Release -OutputRoot artifacts/ifpkg434 -VerifyReproducible -RuntimeAssetRoot artifacts/ifc3 *> artifacts/infantry434-publish.log
python artifacts/install_infantry434.py *> artifacts/infantry434-installation.log
if($LASTEXITCODE -ne 0){throw 'Fresh installation hash verification failed.'}
foreach($variant in @('published','installed')) {
    $player=if($variant -eq 'published'){Join-Path $repo 'artifacts/ifpkg434/win-x64/publish'}else{Join-Path (Split-Path -Parent $repo) 'infantry-player434'}
    $output=Join-Path $repo "artifacts/infantry434-$variant-smoke"
    New-Item -ItemType Directory -Path $output|Out-Null
    $info=[Diagnostics.ProcessStartInfo]::new((Join-Path $player 'ForgeLine.Client.exe'))
    $info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.WorkingDirectory=$player
    $info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
    foreach($argument in @('--smoke-test','--skip-splash','--startup-diagnostics-output',(Join-Path $output 'startup.json'),'--visual-qualification-output',(Join-Path $output 'visual.json'),'--settings-root',(Join-Path $output 'settings'))){$info.ArgumentList.Add($argument)}
    $info.Environment['PATH']="$env:SystemRoot\System32;$env:SystemRoot;C:\Program Files\dotnet"
    $info.Environment['FORGELINE_RUNTIME_ASSETS']=Join-Path $player 'assets/runtime'
    $process=[Diagnostics.Process]::Start($info)
    $stdout=$process.StandardOutput.ReadToEndAsync();$stderr=$process.StandardError.ReadToEndAsync()
    $timedOut=-not $process.WaitForExit(90000)
    if($timedOut){$process.Kill();$process.WaitForExit()}
    [IO.File]::WriteAllText((Join-Path $output 'stdout.log'),$stdout.GetAwaiter().GetResult())
    [IO.File]::WriteAllText((Join-Path $output 'stderr.log'),$stderr.GetAwaiter().GetResult())
    @{source=(& git rev-parse HEAD);exitCode=$process.ExitCode;timedOut=$timedOut;player=$player;runtimeLoadedFromPackage=$true;method='Fresh child settings and package runtime; child PATH only system and .NET. System Blender remains installed.'}|ConvertTo-Json|Set-Content (Join-Path $output 'status.json') -Encoding utf8NoBOM
    if($timedOut -or $process.ExitCode -ne 0){throw "Packaged $variant smoke failed."}
}
$install=Join-Path (Split-Path -Parent $repo) 'infantry-player434'
$common=@{Capture=$true;ClientPath=(Join-Path $install 'ForgeLine.Client.exe');RuntimeAssetRoot=(Join-Path $install 'assets/runtime');Warmups=8;Samples=32;RepeatCaptures=8;ContinueAfterMismatch=$true;Profiles=@('High');Displays=@('1920x1080');Zooms=@('CloseTactical');MechanicalSeconds=.375}
foreach($cohort in @(@{name='gallery';scenes=@('InfantrySkinning','InfantrySkinningEngineer');distance=20},@{name='close-loads';scenes=@('InfantryRifleThousand','InfantryEngineerThousand');distance=40})) {
    $output="artifacts/ifni434/$($cohort.name)";$baseline="artifacts/ifn4/$($cohort.name)/after"
    & ./build/Invoke-RtsReferenceQualification.ps1 @common -Scenes $cohort.scenes -InspectionDistanceMeters $cohort.distance -OutputRoot $output -BaselineRoot $baseline
    & ./build/Compare-VisualReferenceEvidence.ps1 -CurrentRoot $output -BaselineRoot $baseline -ComparePixels -ReportPath "$output/pixels.json"
}
@{source=(& git rev-parse HEAD);cases=4;humanArtApproval='pending';performanceAcceptance='failed-historical-gates-retained'}|ConvertTo-Json|Set-Content artifacts/ifni434/summary.json -Encoding utf8NoBOM
