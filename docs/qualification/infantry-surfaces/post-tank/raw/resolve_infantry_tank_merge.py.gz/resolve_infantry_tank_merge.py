import re,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent.parent
pattern=re.compile(r'^<<<<<<< HEAD\n(.*?)^=======\n(.*?)^>>>>>>> origin/master\n',re.M|re.S)
tanks=' or VisualReferenceSceneKind.MainBattleTankSingle or VisualReferenceSceneKind.MainBattleTankHundred or VisualReferenceSceneKind.MainBattleTankThousand'
for name in ('src/ForgeLine.Client/VisualReferenceCapture.cs','src/ForgeLine.Presentation/VisualReferenceScene.cs','tests/ForgeLine.Client.Tests/VisualReferenceCaptureTests.cs'):
    p=root/name;text=p.read_text(encoding='utf-8-sig')
    if '<<<<<<< HEAD' not in text:continue
    def resolve(m):
        ours,theirs=m.groups()
        if ours.startswith('public enum'):
            extra='InfantryRifleSingle, InfantryRifleHundred, InfantryRifleThousand, InfantryEngineerSingle, InfantryEngineerHundred, InfantryEngineerThousand'
            return theirs.replace(' }',', '+extra+' }')
        if name.startswith('tests/'):
            return ours+'    }\n\n    [Theory]\n'+theirs
        return ours.replace('VisualReferenceSceneKind.MainBattleTankFormation','VisualReferenceSceneKind.MainBattleTankFormation'+tanks)
    text,count=pattern.subn(resolve,text)
    assert count==(2 if name.endswith('/VisualReferenceScene.cs') else 1),(name,count)
    assert '<<<<<<<' not in text
    p.write_text(text,encoding='utf-8')
current=(root/'src/ForgeLine.Presentation/VisualReferenceScene.cs').read_text()
master=subprocess.check_output(['git','show','origin/master:src/ForgeLine.Presentation/VisualReferenceScene.cs'],cwd=root,text=True)
enums=lambda text:[x.strip() for x in re.search(r'public enum VisualReferenceSceneKind \{([^}]+)',text).group(1).split(',')]
a,b=enums(master),enums(current)
assert b[:len(a)]==a and len(b)==len(a)+6
props=root/'Directory.Build.props'
text=props.read_text();assert '<ForgeLineVersionPatch>433</ForgeLineVersionPatch>' in text
props.write_text(text.replace('<ForgeLineVersionPatch>433</ForgeLineVersionPatch>','<ForgeLineVersionPatch>434</ForgeLineVersionPatch>'),encoding='utf-8')
print('Resolved all three shared files; preserved all',len(a),'master scene IDs and both admission/test paths; version 0.1.434.')
