import hashlib,json,zipfile
from pathlib import Path
repo=Path(__file__).resolve().parent.parent
archive=repo/'artifacts/ifpkg434/FORGELINE-0.1.434-dev-win-x64.zip'
install=repo.parent/'infantry-player434'
assert not install.exists()
install.mkdir()
with zipfile.ZipFile(archive) as z:
    entries=z.namelist()
    assert all(not p.lower().endswith(('.blend','.blend1','.glb','.gltf','.py','.ps1')) for p in entries)
    assert all((install/p).resolve().is_relative_to(install.resolve()) for p in entries)
    z.extractall(install)
count=0
for line in (install/'manifest.sha256').read_text().splitlines():
    digest,name=line.split('  ',1)
    assert hashlib.sha256((install/name).read_bytes()).hexdigest()==digest.lower(),name
    count+=1
provenance=json.loads((install/'build-provenance.json').read_text())
assert provenance['sourceRevision']=='c85fd2987611de126963c93608cf3eda66636680' and provenance['sourceTreeClean']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
candidate=repo/'artifacts/ifc3';runtime=install/'assets/runtime'
a={p.relative_to(candidate).as_posix():sha(p) for p in candidate.rglob('*') if p.is_file()}
b={p.relative_to(runtime).as_posix():sha(p) for p in runtime.rglob('*') if p.is_file()}
assert all(b.get(k)==v for k,v in a.items()) and len(b)-len(a)==63
report=dict(success=True,source=provenance['sourceRevision'],sourceTreeClean=True,archive=str(archive),archiveBytes=archive.stat().st_size,archiveSha256=sha(archive),archiveEntries=len(entries),installation=str(install),verifiedFileHashes=count,authoringFiles=0,commonByteIdenticalCompiledFiles=len(a),publisherOnlyMediaFiles=63)
(repo/'artifacts/infantry434-installation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
