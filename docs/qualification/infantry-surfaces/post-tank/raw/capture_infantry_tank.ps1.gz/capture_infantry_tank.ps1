$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$repo=Split-Path -Parent $PSScriptRoot
Set-Location $repo
$common=@{Capture=$true;ClientPath=(Join-Path $repo 'artifacts/infantry-build/bin/ForgeLine.Client/release_win-x64/ForgeLine.Client.exe');Warmups=8;Samples=32;RepeatCaptures=8;ContinueAfterMismatch=$true;Zooms=@('CloseTactical');Profiles=@('High');Displays=@('1920x1080');MechanicalSeconds=.375}
$results=@()
foreach($cohort in @(@{name='gallery';scenes=@('InfantrySkinning','InfantrySkinningEngineer');distance=20},@{name='close-loads';scenes=@('InfantryRifleThousand','InfantryEngineerThousand');distance=40})) {
    $before="artifacts/ifn4/$($cohort.name)/before";$after="artifacts/ifn4/$($cohort.name)/after"
    & ./build/Invoke-RtsReferenceQualification.ps1 @common -Scenes $cohort.scenes -InspectionDistanceMeters $cohort.distance -RuntimeAssetRoot artifacts/ifb3 -OutputRoot $before
    & ./build/Invoke-RtsReferenceQualification.ps1 @common -Scenes $cohort.scenes -InspectionDistanceMeters $cohort.distance -RuntimeAssetRoot artifacts/ifc3 -OutputRoot $after -BaselineRoot $before
    & ./build/Compare-VisualReferenceEvidence.ps1 -CurrentRoot $after -BaselineRoot $before -ComparePixels -ReportPath "artifacts/ifn4/$($cohort.name)/pixels.json"
    $passed=$false
    try {& ./build/Compare-ReferencePerformance.ps1 -CurrentRoot $after -BaselineRoot $before -GatePerformance -ReportPath "artifacts/ifn4/$($cohort.name)/performance.json" *> "artifacts/ifn4/$($cohort.name)/performance.log";$passed=$true}
    catch {$_|Out-String|Add-Content "artifacts/ifn4/$($cohort.name)/performance.log"}
    $results+=@{cohort=$cohort.name;performancePassed=$passed}
}
@{source=(& git rev-parse HEAD);pairedCases=4;results=$results;performanceAcceptance='failed-historical-gates-retained';humanArtApproval='pending'}|ConvertTo-Json -Depth 6|Set-Content artifacts/ifn4/summary.json -Encoding utf8NoBOM
