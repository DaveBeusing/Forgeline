$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$repo = Split-Path -Parent $PSScriptRoot
Set-Location $repo
$source = Join-Path $repo 'artifacts/infantry-baseline-source3'
foreach ($relative in @('artifacts/infantry-baseline-source3','artifacts/ifb3','artifacts/ifc3')) {
    $target = [IO.Path]::GetFullPath($relative,$repo)
    if (-not $target.StartsWith((Join-Path $repo 'artifacts')+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase) -or (Test-Path -LiteralPath $target)) { throw 'Use fresh scoped runtime/source targets.' }
}
foreach ($family in @('rifle_squad','combat_engineer')) {
    $expected = (& git rev-parse "origin/master:assets/source/units/directorate/authoring/infantry/$family.glb").Trim()
    $original = (& git hash-object "artifacts/infantry-original/$family.glb").Trim()
    if ($expected -ne $original) { throw "Original GLB differs from current master: $family" }
}
& robocopy (Join-Path $repo 'assets/source') $source /E /XF '*.blend' '*.blend1' /R:1 /W:1 /NJH /NJS /NP *> artifacts/infantry-baseline-source3-copy.log
if ($LASTEXITCODE -ge 8) { throw 'Baseline source copy failed.' }
foreach ($family in @('rifle_squad','combat_engineer')) {
    Copy-Item -LiteralPath "artifacts/infantry-original/$family.glb" -Destination (Join-Path $source "units/directorate/authoring/infantry/$family.glb") -Force
}
Copy-Item -LiteralPath artifacts/ifb -Destination artifacts/ifb3 -Recurse
Copy-Item -LiteralPath artifacts/ifc -Destination artifacts/ifc3 -Recurse
$compiler = Join-Path $repo 'artifacts/infantry-build/bin/ForgeLine.AssetCompiler/release/ForgeLine.AssetCompiler.dll'
$absent = Join-Path $repo 'artifacts/infantry-source-not-present'
if (Test-Path -LiteralPath $absent) { throw 'Source-less validation path must be absent.' }
foreach ($variant in @('baseline','candidate')) {
    $input = if ($variant -eq 'baseline') { $source } else { Join-Path $repo 'assets/source' }
    $runtime = Join-Path $repo $(if ($variant -eq 'baseline') { 'artifacts/ifb3' } else { 'artifacts/ifc3' })
    & dotnet $compiler --mode development --source $input --runtime $runtime --qualification-output "artifacts/infantry-tank-$variant-assets.json" *> "artifacts/infantry-tank-$variant-compile.log"
    if ($LASTEXITCODE -ne 0) { throw "Integrated $variant compilation failed." }
    & dotnet $compiler --mode validate --source $absent --runtime $runtime *> "artifacts/infantry-tank-$variant-source-less.log"
    if ($LASTEXITCODE -ne 0) { throw "Integrated $variant source-less validation failed." }
    Write-Output "Integrated $variant catalog and absent-source validation passed."
}
