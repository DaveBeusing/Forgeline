$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$repo = Split-Path -Parent $PSScriptRoot
Set-Location $repo
$common = @{ Capture=$true; ClientPath=(Join-Path $repo 'artifacts/infantry-build/bin/ForgeLine.Client/release_win-x64/ForgeLine.Client.exe'); Warmups=8; Samples=32; RepeatCaptures=8; ContinueAfterMismatch=$true; Zooms=@('CloseTactical'); MechanicalSeconds=.375 }
$roles = @('InfantrySkinning','InfantrySkinningEngineer')
$loads = @('InfantryRifleSingle','InfantryRifleHundred','InfantryRifleThousand','InfantryEngineerSingle','InfantryEngineerHundred','InfantryEngineerThousand')
$cohorts = @(
    @{Name='gallery';Scenes=$roles;Profiles=@('High');Displays=@('1920x1080','3840x2160');InspectionDistanceMeters=20},
    @{Name='quality-close';Scenes=$roles;Profiles=@('Low','Medium');Displays=@('1920x1080');InspectionDistanceMeters=20},
    @{Name='close-loads';Scenes=$loads;Profiles=@('High');Displays=@('1920x1080');InspectionDistanceMeters=40}
)
foreach ($cohort in $cohorts) {
    $settings = @{}
    foreach ($key in $cohort.Keys) { if ($key -ne 'Name') { $settings[$key]=$cohort[$key] } }
    $before = Join-Path $repo "artifacts/ifn3/$($cohort.Name)/before"
    $after = Join-Path $repo "artifacts/ifn3/$($cohort.Name)/after"
    & ./build/Invoke-RtsReferenceQualification.ps1 @common @settings -RuntimeAssetRoot (Join-Path $repo 'artifacts/ifb2') -OutputRoot $before
    & ./build/Invoke-RtsReferenceQualification.ps1 @common @settings -RuntimeAssetRoot (Join-Path $repo 'artifacts/ifc2') -OutputRoot $after -BaselineRoot $before
    & ./build/Compare-VisualReferenceEvidence.ps1 -CurrentRoot $after -BaselineRoot $before -ComparePixels -ReportPath (Join-Path $repo "artifacts/ifn3/$($cohort.Name)/pixels.json")
}
& ./build/Invoke-RtsReferenceQualification.ps1 @common -Scenes $roles -Profiles @('High') -Displays @('1920x1080') -InspectionDistanceMeters 20 -YawDegrees 225 -RuntimeAssetRoot (Join-Path $repo 'artifacts/ifc2') -OutputRoot (Join-Path $repo 'artifacts/ifn3/rear')
@{sourceSha=(& git rev-parse HEAD);pairedCases=14;additionalRearCases=2;warmups=8;samples=32;repeatCaptures=8;performanceAcceptance='pending';humanArtApproval='pending'} |
    ConvertTo-Json | Set-Content artifacts/ifn3/summary.json -Encoding utf8NoBOM
