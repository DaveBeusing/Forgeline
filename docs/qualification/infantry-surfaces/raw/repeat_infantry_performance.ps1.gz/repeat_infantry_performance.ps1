$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$repo = Split-Path -Parent $PSScriptRoot
Set-Location $repo
$root = Join-Path $repo 'artifacts/ifp'
if (Test-Path -LiteralPath $root) { throw 'Use fresh performance evidence.' }
[void][IO.Directory]::CreateDirectory($root)
$source = (& git rev-parse HEAD).Trim()
$order = @(@{name='baseline-a';runtime='ifb2'},@{name='candidate-b';runtime='ifc2'},@{name='candidate-c';runtime='ifc2'},@{name='baseline-d';runtime='ifb2'})
@{source=$source;phases=@(0,.75);order=$order;warmups=32;samples=128;repeatCaptures=8;maximumRegressionPercent=15;method='Predetermined ABBA diagnostic repetition of both original outlier phases; shared workstation, no driver/power settings changed; not full physical milestone acceptance.'} |
    ConvertTo-Json -Depth 8 | Set-Content (Join-Path $root 'plan.json') -Encoding utf8NoBOM
$observer = Start-Process -FilePath (Get-Command nvidia-smi).Source -ArgumentList @('--query-gpu=timestamp,name,pstate,power.draw,power.limit,clocks.current.graphics,utilization.gpu,temperature.gpu','--format=csv','--loop-ms=1000') -RedirectStandardOutput (Join-Path $root 'gpu-telemetry.csv') -RedirectStandardError (Join-Path $root 'gpu-telemetry.stderr.log') -WindowStyle Hidden -PassThru
$results = @()
try {
    foreach ($phase in @(0,.75)) {
        $phaseRoot = Join-Path $root "phase-$phase"
        foreach ($step in $order) {
            & ./build/Invoke-RtsReferenceQualification.ps1 -Capture -ClientPath (Join-Path $repo 'artifacts/infantry-build/bin/ForgeLine.Client/release_win-x64/ForgeLine.Client.exe') -RuntimeAssetRoot (Join-Path $repo "artifacts/$($step.runtime)") -Scenes @('InfantrySkinning') -Profiles @('High') -Zooms @('CloseTactical') -Displays @('1920x1080') -InspectionDistanceMeters 20 -MechanicalSeconds $phase -Warmups 32 -Samples 128 -RepeatCaptures 8 -ContinueAfterMismatch -OutputRoot (Join-Path $phaseRoot $step.name)
        }
        foreach ($pair in @(@{name='a';baseline='baseline-a';candidate='candidate-b'},@{name='b';baseline='baseline-d';candidate='candidate-c'})) {
            $baseline = Join-Path $phaseRoot $pair.baseline; $candidate = Join-Path $phaseRoot $pair.candidate
            & ./build/Compare-VisualReferenceEvidence.ps1 -CurrentRoot $candidate -BaselineRoot $baseline -ComparePixels -ReportPath (Join-Path $phaseRoot "pair-$($pair.name)-pixels.json")
            $passed=$false; $errorMessage=$null
            try {
                & ./build/Compare-ReferencePerformance.ps1 -CurrentRoot $candidate -BaselineRoot $baseline -GatePerformance -ReportPath (Join-Path $phaseRoot "pair-$($pair.name)-performance.json") *> (Join-Path $phaseRoot "pair-$($pair.name)-performance.log")
                $passed=$true
            } catch { $errorMessage=$_.Exception.Message; $_ | Out-String | Add-Content (Join-Path $phaseRoot "pair-$($pair.name)-performance.log") }
            $report = Get-Content (Join-Path $phaseRoot "pair-$($pair.name)-performance.json") -Raw | ConvertFrom-Json
            $results += @{phase=$phase;pair=$pair.name;passed=$passed;regressions=@($report.regressions).Count;unqualified=@($report.unqualified).Count;error=$errorMessage}
        }
    }
} finally {
    if (-not $observer.HasExited) { $observer.Kill(); $observer.WaitForExit() }
}
@{source=$source;results=$results;allPairsPassed=(@($results | Where-Object { -not $_.passed }).Count -eq 0);maximumRegressionPercent=15;fullPhysicalAcceptance='pending';humanArtApproval='pending'} |
    ConvertTo-Json -Depth 8 | Set-Content (Join-Path $root 'summary.json') -Encoding utf8NoBOM
Get-Content (Join-Path $root 'summary.json')
