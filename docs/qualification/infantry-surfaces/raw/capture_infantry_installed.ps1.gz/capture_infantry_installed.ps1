$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$repo = Split-Path -Parent $PSScriptRoot
Set-Location $repo
$install = Join-Path (Split-Path -Parent $repo) 'infantry-player433'
$common = @{Capture=$true;ClientPath=(Join-Path $install 'ForgeLine.Client.exe');RuntimeAssetRoot=(Join-Path $install 'assets/runtime');Warmups=8;Samples=32;RepeatCaptures=8;ContinueAfterMismatch=$true;Profiles=@('High');Displays=@('1920x1080');Zooms=@('CloseTactical');MechanicalSeconds=.375}
& ./build/Invoke-RtsReferenceQualification.ps1 @common -Scenes @('InfantrySkinning','InfantrySkinningEngineer') -InspectionDistanceMeters 20 -OutputRoot (Join-Path $repo 'artifacts/ifni/gallery') -BaselineRoot (Join-Path $repo 'artifacts/ifn3/gallery/after')
& ./build/Compare-VisualReferenceEvidence.ps1 -CurrentRoot artifacts/ifni/gallery -BaselineRoot artifacts/ifn3/gallery/after -ComparePixels -ReportPath artifacts/ifni/gallery/pixels.json
& ./build/Invoke-RtsReferenceQualification.ps1 @common -Scenes @('InfantryRifleThousand','InfantryEngineerThousand') -InspectionDistanceMeters 40 -OutputRoot (Join-Path $repo 'artifacts/ifni/close-loads') -BaselineRoot (Join-Path $repo 'artifacts/ifn3/close-loads/after')
& ./build/Compare-VisualReferenceEvidence.ps1 -CurrentRoot artifacts/ifni/close-loads -BaselineRoot artifacts/ifn3/close-loads/after -ComparePixels -ReportPath artifacts/ifni/close-loads/pixels.json
@{source=(& git rev-parse HEAD);installation=$install;cases=4;humanArtApproval='pending';performanceAcceptance='pending'} | ConvertTo-Json | Set-Content artifacts/ifni/summary.json -Encoding utf8NoBOM
