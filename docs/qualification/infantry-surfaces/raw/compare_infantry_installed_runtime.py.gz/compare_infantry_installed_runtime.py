import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
candidate = root/'ifc2'
installed = root.parent.parent/'infantry-player433/assets/runtime'
def files(folder):
    return {p.relative_to(folder).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
            for p in folder.rglob('*') if p.is_file()}
a,b = files(candidate),files(installed)
missing=sorted(a.keys()-b.keys());extra=sorted(b.keys()-a.keys())
changed=sorted(name for name in a.keys()&b.keys() if a[name]!=b[name])
assert len(a)==1364 and not missing and not changed and len(extra)==63, (len(a),missing,changed,len(extra))
report=dict(success=True,commonByteIdenticalFiles=len(a),candidateFiles=len(a),installedFiles=len(b),
    missingFiles=missing,changedCommonFiles=changed,packageOnlyFiles=extra,
    manifestSha256=a['manifest.json'],method='Every compiled manifest/payload byte is identical; directory fingerprints differ because publishing adds existing media files.')
(root/'infantry-installed-runtime-comparison.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='packageOnlyFiles'},indent=2))
