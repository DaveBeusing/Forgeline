$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
Set-Location (Split-Path -Parent $PSScriptRoot)
$results=@()
foreach($item in @(@{group='ifp';phase='0'},@{group='ifp';phase='0.75'},@{group='ifpc';phase='0.375'})) {
    $root="artifacts/$($item.group)/phase-$($item.phase)"
    foreach($control in @(@{name='baseline';before='baseline-a';after='baseline-d'},@{name='candidate';before='candidate-b';after='candidate-c'})) {
        $passed=$false;$message=$null
        try { & ./build/Compare-ReferencePerformance.ps1 -CurrentRoot "$root/$($control.after)" -BaselineRoot "$root/$($control.before)" -GatePerformance -ReportPath "$root/control-$($control.name)-performance.json" *> "$root/control-$($control.name)-performance.log";$passed=$true }
        catch {$message=$_.Exception.Message;$_|Out-String|Add-Content "$root/control-$($control.name)-performance.log"}
        $report=Get-Content "$root/control-$($control.name)-performance.json" -Raw|ConvertFrom-Json
        $results+=@{group=$item.group;phase=$item.phase;control=$control.name;passed=$passed;regressions=@($report.regressions).Count;unqualified=@($report.unqualified).Count;error=$message}
    }
}
@{maximumRegressionPercent=15;results=$results;interpretation='Same-runtime controls quantify observed drift. Their results neither waive failed asset comparisons nor establish a cause.'}|ConvertTo-Json -Depth 7|Set-Content artifacts/infantry-timing-controls.json -Encoding utf8NoBOM
Get-Content artifacts/infantry-timing-controls.json
