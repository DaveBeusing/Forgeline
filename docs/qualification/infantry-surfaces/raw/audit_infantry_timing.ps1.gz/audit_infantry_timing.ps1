$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
Set-Location (Split-Path -Parent $PSScriptRoot)
$cohorts = @()
foreach ($name in @('gallery','distances','quality')) { $cohorts += @{group='ifn';name=$name} }
foreach ($entry in (Get-Content artifacts/ifn2/summary.json -Raw | ConvertFrom-Json).cohorts) { $cohorts += @{group='ifn2';name=$entry.name} }
foreach ($name in @('gallery','quality-close','close-loads')) { $cohorts += @{group='ifn3';name=$name} }
$results = @()
foreach ($cohort in $cohorts) {
    $root = "artifacts/$($cohort.group)/$($cohort.name)"
    $passed = $false; $errorMessage = $null
    try {
        & ./build/Compare-ReferencePerformance.ps1 -CurrentRoot "$root/after" -BaselineRoot "$root/before" -ReportPath "$root/performance-gate.json" -GatePerformance *> "$root/performance-gate.log"
        $passed = $true
    } catch { $errorMessage = $_.Exception.Message; $_ | Out-String | Add-Content "$root/performance-gate.log" }
    $report = Get-Content "$root/performance-gate.json" -Raw | ConvertFrom-Json
    $results += @{group=$cohort.group;cohort=$cohort.name;passed=$passed;regressions=@($report.regressions).Count;unqualified=@($report.unqualified).Count;error=$errorMessage}
}
@{gate='Compare-ReferencePerformance.ps1 -GatePerformance';maximumRegressionPercent=15;allGatesPassed=(@($results | Where-Object { -not $_.passed }).Count -eq 0);results=$results;interpretation='Original short-cohort failures remain retained; no threshold is changed and no normal-power acceptance follows.'} |
    ConvertTo-Json -Depth 8 | Set-Content artifacts/infantry-timing-audit.json -Encoding utf8NoBOM
$results | ConvertTo-Json -Depth 5
