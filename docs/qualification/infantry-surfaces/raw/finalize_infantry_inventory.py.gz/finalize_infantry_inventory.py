import csv
from collections import Counter
import json
from pathlib import Path
import runpy

def number(value): return float(value.split()[0])

root=Path(__file__).resolve().parent
state=runpy.run_path(str(root/'inventory_infantry_captures.py'))
images,pairs,additional,load,read = [state[k] for k in ('images','pairs','additional','load','read')]
source='1991b0c2abbed292ee2a90b7df0e08822f933154'
for name in ('gallery','close-loads'):
    folder=root/'ifni'/name
    manifest=load(folder,source)
    comparison=read(folder/'pixels.json')
    assert all(x['pixelComparison']['ChangedPixels']==0 and x['equivalentHardware'] and x['sameSource'] for x in comparison['captures'])
    additional.extend(dict(group='ifni',cohort=name,key=x['key'],source=source) for x in manifest['captures'])
for group,phases in (('ifp',('0','0.75')),('ifpc',('0.375',))):
    assert (root/group/'summary.json').exists()
    for phase in phases:
        folder=root/group/f'phase-{phase}'
        manifests={name:load(folder/name,source) for name in ('baseline-a','candidate-b','candidate-c','baseline-d')}
        for label,before_name,after_name in (('a','baseline-a','candidate-b'),('b','baseline-d','candidate-c')):
            a={x['key']:x for x in manifests[before_name]['captures']};b={x['key']:x for x in manifests[after_name]['captures']}
            p={x['key']:x for x in read(folder/f'pair-{label}-pixels.json')['captures']}
            assert a.keys()==b.keys()
            for key in a:
                x,y=a[key],b[key]
                for field in ('instances','submission','materials','camera','profile','lighting','rasterDpi','hostWindowDpi','mechanicalSeconds'):
                    assert x[field]==y[field],(group,phase,key,field)
                assert x['graphics']['resources']==y['graphics']['resources'] and x['fingerprint']==y['fingerprint']
                pairs.append(dict(group=group,cohort=f'phase-{phase}/pair-{label}',key=key,source=source,
                    identicalPng=x['imageSha256']==y['imageSha256'],pixels=p[key]['pixelComparison'],
                    beforeCpu=x['cpu'],afterCpu=y['cpu'],beforeGpu=x['gpu'],afterGpu=y['gpu'],
                    instances=y['instances'],submission=y['submission'],resources=y['graphics']['resources']))
telemetry=[]
for group in ('ifp','ifpc'):
    with (root/group/'gpu-telemetry.csv').open(encoding='utf-8-sig') as stream:
        rows=[{k.strip():v.strip() for k,v in row.items()} for row in csv.DictReader(stream) if row.get('timestamp')]
    telemetry.append(dict(group=group,samples=len(rows),pstates=dict(Counter(x['pstate'] for x in rows)),
        graphicsClockMHzRange=[min(number(x['clocks.current.graphics [MHz]']) for x in rows),max(number(x['clocks.current.graphics [MHz]']) for x in rows)],
        maximumUtilizationPercent=max(number(x['utilization.gpu [%]']) for x in rows),
        temperatureRange=[min(number(x['temperature.gpu']) for x in rows),max(number(x['temperature.gpu']) for x in rows)],
        maximumPowerWatts=max(number(x['power.draw [W]']) for x in rows),powerLimitReported=sorted(set(x['power.limit [W]'] for x in rows))))
summary=dict(success=True,pairedCases=len(pairs),originalImages=len(images),additionalCases=len(additional),
    originalImageBytes=sum(x['bytes'] for x in images),identicalPngPairs=sum(x['identicalPng'] for x in pairs),
    maximumSkinPoses=max(x['submission']['skinEvaluatedPoses'] for x in pairs),
    maximumSkinUploadBytes=max(x['submission']['skinUploadBytes'] for x in pairs),
    maximumResidentTextureBytes=max(x['resources']['residentTextureBytes'] for x in pairs),
    maximumDescriptors=max(x['resources']['shaderResourceDescriptorsUsed'] for x in pairs),
    allRepeatReadbacksAgree=True,allPairsHaveIdenticalGeometryAndResourceCounters=True,
    zeroFallbacksAndBindingFailures=True,installedCasesPixelExact=4,
    performanceAcceptance='failed-15-percent-comparisons-retained-not-qualified',humanArtApproval='pending')
(root/'infantry-complete-native-inventory.json').write_text(json.dumps(dict(summary=summary,telemetry=telemetry,images=images,pairs=pairs,additional=additional),indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(summary=summary,telemetry=telemetry),indent=2))
