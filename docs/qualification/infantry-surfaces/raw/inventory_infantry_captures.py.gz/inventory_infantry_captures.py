import hashlib
import json
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parent
SOURCES = {'ifn':'f3eda9de1c9fc032796cbf999b4cbecaf623a92c',
           'ifn2':'57a632b5afad82eac5c988d818a6c1a5c4caaa98',
           'ifn3':'1991b0c2abbed292ee2a90b7df0e08822f933154'}
PAIRS = [('ifn',name) for name in ('gallery','distances','quality')]
PAIRS += [('ifn2',entry['name']) for entry in json.loads((ROOT/'ifn2/summary.json').read_text(encoding='utf-8-sig'))['cohorts']]
if (ROOT/'ifn3/summary.json').exists():
    PAIRS += [('ifn3',name) for name in ('gallery','quality-close','close-loads')]

def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(raw): return hashlib.sha256(raw).hexdigest()
images = []; pairs = []; additional = []

def load(folder, expected):
    manifest = read(folder/'manifest.json')
    assert manifest['status'] == 'structural-pass' and not manifest['failedCaptures'], folder
    assert manifest['commit'] == expected and manifest['buildIdentity'].endswith(expected), folder
    for item in manifest['captures']:
        assert item['repeatPixelsEqual'] and item['repeatCaptures'] == 8 and not item['repeatFailures'], item['key']
        assert item['instances']['fallbackMeshInstances'] == item['submission']['skinStaticFallbacks'] == 0, item['key']
        assert item['materials']['bindingFailureCount'] == item['graphics']['resources']['textureBindingFailureCount'] == 0, item['key']
        assert item['submission']['skinEvaluatedPoses'] <= 16, item['key']
        path = folder/item['image']; raw = path.read_bytes()
        assert sha(raw) == item['imageSha256'].lower(), path
        assert raw[:8] == b'\x89PNG\r\n\x1a\n' and raw[24:26] == bytes([8,6]), path
        width,height = struct.unpack_from('>II',raw,16)
        assert width == item['actualSurface']['width'] == item['requestedDisplay']['width'], path
        assert height == item['actualSurface']['height'] == item['requestedDisplay']['height'], path
        images.append(dict(path=path.relative_to(ROOT).as_posix(),bytes=len(raw),sha256=sha(raw),
                           source=expected,key=item['key'],width=width,height=height))
    return manifest

for group,name in PAIRS:
    folder = ROOT/group/name
    before,after = [load(folder/side,SOURCES[group]) for side in ('before','after')]
    a={x['key']:x for x in before['captures']}; b={x['key']:x for x in after['captures']}
    assert a.keys() == b.keys()
    pixel = {x['key']:x for x in read(folder/'pixels.json')['captures']}
    for key in a:
        x,y = a[key],b[key]
        for field in ('instances','submission','materials','camera','profile','lighting','rasterDpi','hostWindowDpi','mechanicalSeconds'):
            assert x[field] == y[field], (group,name,key,field)
        assert x['graphics']['resources'] == y['graphics']['resources'], (group,name,key,'resources')
        assert x['fingerprint'] == y['fingerprint'], (group,name,key,'fixture')
        assert pixel[key]['equivalentHardware'] and pixel[key]['sameSource']
        pairs.append(dict(group=group,cohort=name,key=key,source=SOURCES[group],
            identicalPng=x['imageSha256'] == y['imageSha256'],pixels=pixel[key]['pixelComparison'],
            beforeCpu=x['cpu'],afterCpu=y['cpu'],beforeGpu=x['gpu'],afterGpu=y['gpu'],
            instances=y['instances'],submission=y['submission'],resources=y['graphics']['resources']))

if (ROOT/'ifn3/summary.json').exists():
    rear = load(ROOT/'ifn3/rear',SOURCES['ifn3'])
    additional = [dict(group='ifn3',cohort='rear',key=x['key'],source=SOURCES['ifn3']) for x in rear['captures']]

summary = dict(success=True,pairedCases=len(pairs),originalImages=len(images),
               distinctPairedSettings=len({(x['cohort'],x['key']) for x in pairs}),
               identicalPngPairs=sum(x['identicalPng'] for x in pairs),
               changedPairs=sum(not x['identicalPng'] for x in pairs),additionalCases=len(additional),
               originalImageBytes=sum(x['bytes'] for x in images),
               maximumSkinPoses=max(x['submission']['skinEvaluatedPoses'] for x in pairs),
               maximumSkinUploadBytes=max(x['submission']['skinUploadBytes'] for x in pairs),
               maximumResidentTextureBytes=max(x['resources']['residentTextureBytes'] for x in pairs),
               maximumDescriptors=max(x['resources']['shaderResourceDescriptorsUsed'] for x in pairs),
               sourceBound=True,allRepeatReadbacksAgree=True,allPairsHaveIdenticalGeometryAndResourceCounters=True,
               zeroFallbacksAndBindingFailures=True,performanceAcceptance='pending',humanArtApproval='pending')
summary['worstCpuMeanDelta'] = max((dict(group=x['group'],cohort=x['cohort'],key=x['key'],
    before=x['beforeCpu']['mean'],after=x['afterCpu']['mean'],
    percent=100*(x['afterCpu']['mean']/x['beforeCpu']['mean']-1)) for x in pairs),key=lambda x:x['percent'])
summary['worstGpuMeanDelta'] = max((dict(group=x['group'],cohort=x['cohort'],key=x['key'],
    before=x['beforeGpu']['mean'],after=x['afterGpu']['mean'],
    percent=100*(x['afterGpu']['mean']/x['beforeGpu']['mean']-1)) for x in pairs if x['beforeGpu']['mean'] > 0),key=lambda x:x['percent'])
(ROOT/'infantry-native-inventory.json').write_text(json.dumps(dict(summary=summary,images=images,pairs=pairs,additional=additional),indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))
