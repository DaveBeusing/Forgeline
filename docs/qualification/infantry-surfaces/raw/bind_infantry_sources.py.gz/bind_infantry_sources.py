import hashlib,json,subprocess
from pathlib import Path
repo=Path(__file__).resolve().parent.parent
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
paths=set(git('diff','--name-only','origin/master','HEAD').splitlines())
for pattern in ('assets/source/materials/directorate/surfaces/*','assets/source/units/directorate/*rifle*','assets/source/units/directorate/*engineer*'):
    paths.update(p.relative_to(repo).as_posix() for p in repo.glob(pattern) if p.is_file())
report=dict(implementationSource=git('rev-parse','HEAD'),base=git('rev-parse','origin/master'),clean=not git('status','--porcelain'),files=[])
assert report['clean']
for name in sorted(paths):
    p=repo/name
    report['files'].append(dict(path=name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),gitBlob=git('rev-parse','HEAD:'+name),baseBlob=git('ls-tree','origin/master','--',name)))
(repo/'artifacts/infantry-source-bindings.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print('Bound',len(report['files']),'files to clean source',report['implementationSource'])
