import hashlib
import json
from pathlib import Path
import struct
import sys

root = Path(__file__).resolve().parent
before, after = (Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()) if len(sys.argv) > 2 else (root / 'ifb', root / 'ifc')
output = Path(sys.argv[3]) if len(sys.argv) > 3 else root/'infantry-runtime-comparison.json'
old = json.loads((before / 'manifest.json').read_text(encoding='utf-8-sig'))
new = json.loads((after / 'manifest.json').read_text(encoding='utf-8-sig'))
a = {x['id']: x for x in old['assets']}; b = {x['id']: x for x in new['assets']}
assert a.keys() == b.keys()
changed = []; payloads = []; length_changes = []
def sha(raw): return hashlib.sha256(raw).hexdigest()
def payload(raw):
    metadata, size = struct.unpack_from('<ii', raw, 12)
    return raw[20 + metadata:20 + metadata + size]
for name in a:
    x = (before / a[name]['runtimePath']).read_bytes()
    y = (after / b[name]['runtimePath']).read_bytes()
    if x != y: changed.append(name)
    if payload(x) != payload(y): payloads.append(name)
    if len(x) != len(y): length_changes.append(dict(id=name,before=len(x),after=len(y)))
    for field in ('dependencies','materialReferences','textureReferences','lods',
                  'collisionReference','animationReferences','sockets','mechanicalParts','bounds'):
        assert a[name].get(field) == b[name].get(field), (name,field)
expected = {prefix + family for family in ('rifle_squad','combat_engineer')
            for prefix in ('unit.directorate.','skin.directorate.')}
assert set(payloads) == expected, payloads
assert not length_changes, length_changes
report = dict(success=True, assets=len(a), idsAndMetadataUnchanged=True,
              totalContainerBytesBefore=sum(x['runtimeBytes'] for x in a.values()),
              totalContainerBytesAfter=sum(x['runtimeBytes'] for x in b.values()),
              changedContainers=changed,changedPayloads=payloads,
              unchangedContainers=len(a)-len(changed),unchangedPayloads=len(a)-len(payloads),
              unchangedContainerLengths=True,
              beforeManifestSha256=sha((before/'manifest.json').read_bytes()),
              afterManifestSha256=sha((after/'manifest.json').read_bytes()),
              beforeContentSignature=old['contentSignature'],afterContentSignature=new['contentSignature'])
output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
