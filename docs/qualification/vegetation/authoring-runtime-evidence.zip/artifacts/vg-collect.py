"""Retain original native/toolchain and functional journals without source/cache duplication."""
import hashlib
import json
import os
from pathlib import Path
import zipfile
ROOT = Path(__file__).resolve().parents[1]
ART = ROOT/'artifacts'
OUT = ROOT/'docs/qualification/vegetation'
OUT.mkdir(parents=True,exist_ok=True)
archive = OUT/'authoring-runtime-evidence.zip'
if archive.exists():
    raise SystemExit('Evidence archive already exists')
files = set()
for name in ('vg-check','vg1','vg2','vg3','ve','ve2','vr'):
    for folder, dirs, names in os.walk(ART/name):
        dirs[:] = [d for d in dirs if d not in ('source','baseline-source','candidate-source','runtime','native-readback-glb')]
        for filename in names:
            p=Path(folder)/filename
            if p.suffix in ('.json','.log','.txt','.jsonl'):
                files.add(p)
for pattern in ('vg-*.log','vg-*.json','vg-*.ps1','vg-*.mjs','vg-*.csv','vg-silhouette-check.py','vg-collect.py'):
    files.update(ART.glob(pattern))
files.add(ROOT/'assets/staged/vegetation/lineage.json')
for p in (ART/'v-package').glob('*.json'):
    files.add(p)
for p in (ART/'v-package').glob('*.sha256'):
    files.add(p)
for root in ('assets/runtime','artifacts/v-runtime'):
    files.add(ROOT/root/'manifest.json')
index=[]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as target:
    for p in sorted(files):
        if not p.is_file():
            continue
        data=p.read_bytes()
        relative=p.relative_to(ROOT).as_posix()
        target.writestr(relative,data)
        index.append({'path':relative,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
report={'schemaVersion':1,'archive':archive.name,'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':index}
(OUT/'authoring-runtime-index.json').write_bytes((json.dumps(report,indent=2)+'\n').encode())
print(len(index),'original evidence files retained',archive.stat().st_size,'archive bytes')
