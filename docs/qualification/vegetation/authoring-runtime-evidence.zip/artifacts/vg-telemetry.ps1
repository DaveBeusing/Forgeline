Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$repo = [IO.Path]::GetFullPath('..', $PSScriptRoot)
$tool = Get-Command nvidia-smi -ErrorAction SilentlyContinue
if (-not $tool) { 'Telemetry unavailable'; exit 0 }
$target = Join-Path $PSScriptRoot 'vg-gpu-telemetry.csv'
if (Test-Path -LiteralPath $target) { throw 'Use fresh telemetry output.' }
'utc,name,driver,memoryTotalMiB,memoryUsedMiB,temperatureC,gpuUtilizationPercent,graphicsClockMHz,memoryClockMHz,powerW' | Out-File $target -Encoding utf8NoBOM
while (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'vg-gpu-telemetry.stop'))) {
    $sample = & $tool.Source --query-gpu=name,driver_version,memory.total,memory.used,temperature.gpu,utilization.gpu,clocks.gr,clocks.mem,power.draw --format=csv,noheader,nounits
    if ($LASTEXITCODE -ne 0) { throw 'GPU telemetry read failed.' }
    foreach ($row in $sample) { ([DateTimeOffset]::UtcNow.ToString('o') + ',' + $row) | Out-File $target -Encoding utf8NoBOM -Append }
    Start-Sleep -Seconds 5
}
'Observed GPU telemetry retained; no stability or acceptance claim.'
