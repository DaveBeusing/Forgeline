import sys
from pathlib import Path
sys.path[:0] = [str(Path.cwd()/'tools/blender'), str(Path.cwd()/'build/vegetation')]
from asset_contract import geometry_stats, read_geometry, write_glb
from geometry import refine
for name in ('scrub','grass_clump'):
    for low in (False,True):
        suffix = '_lod1' if low else ''
        source = Path('assets/source/world/meshes/sources')/('mesh_world_vegetation_'+name+suffix+'.gltf')
        baseline = read_geometry(source, Path('assets/source'), {'materialReferences':['material.world.vegetation']})
        result = refine(name, baseline, low)
        assert geometry_stats(baseline) == geometry_stats(result)
        if name == 'scrub':
            pts = result['primitives'][0]['attributes']['POSITION']
            for start in range(0,len(pts),24):
                volume=0
                for i in range(start,start+24,3):
                    a,b,c=pts[i:i+3]
                    volume += (a[0]*(b[1]*c[2]-b[2]*c[1])+a[1]*(b[2]*c[0]-b[0]*c[2])+a[2]*(b[0]*c[1]-b[1]*c[0]))/6
                assert volume > 0, volume
        target = Path('artifacts')/(name+suffix+'-preflight.glb')
        write_glb(target,result)
        print(name,suffix,geometry_stats(result))
