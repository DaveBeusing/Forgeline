import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
const root=path.resolve(process.argv[2]||'.');
const source=root+'/artifacts/vg-native-analysis';
const output=root+'/artifacts/v-evidence2';
await fs.mkdir(output+'/images',{recursive:true});
await fs.cp(source+'/reports',output+'/reports',{recursive:true,errorOnExist:true,force:false});
const summary=JSON.parse(await fs.readFile(source+'/summary.json','utf8'));
if(summary.pairs!==91||summary.captures!==182)throw Error('Incomplete matrix');
const pictures=[];
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
for(const [index,row] of summary.rows.entries()){
  for(const role of ['before','after']){
    const original='artifacts/vn/'+row.group+'/'+role+'/'+row[role+'Image'];
    const bytes=await fs.readFile(root+'/'+original);
    if(hash(bytes)!==row[role+'ImageSha256'].toLowerCase())throw Error('Changed image '+original);
    const file='images/'+String(index+1).padStart(3,'0')+'-'+role+'.png';
    await fs.writeFile(output+'/'+file,bytes,{flag:'wx'});
    pictures.push({group:row.group,key:row.key,role,path:file,sha256:hash(bytes),original});
  }
}
let motion=0;
for(const group of ['traverse-full','traverse-half'])for(const role of ['before','after']){
  const originalRoot='artifacts/vn/'+group+'/'+role;
  const manifest=JSON.parse(await fs.readFile(root+'/'+originalRoot+'/manifest.json','utf8'));
  for(const capture of manifest.captures)for(const [index,item] of capture.motionImages.entries()){
    const bytes=await fs.readFile(root+'/'+originalRoot+'/'+item.image);
    if(hash(bytes)!==item.imageSha256.toLowerCase())throw Error('Changed camera-pose image');
    const file='images/m-'+group+'-'+role+'-'+index+'.png';
    await fs.writeFile(output+'/'+file,bytes,{flag:'wx'});
    pictures.push({group,key:capture.key,role,path:file,sha256:hash(bytes),original:originalRoot+'/'+item.image,camera:item.camera});
    motion++;
  }
}
if(motion!==32)throw Error('Incomplete adjacent-camera evidence');
await fs.writeFile(output+'/images.json',JSON.stringify({schemaVersion:1,pictures},null,2)+'\n');
await fs.copyFile(source+'/summary.json',output+'/native-summary.json');
for(const [name,target] of [['vg-runtime-delta.json','runtime-delta.json'],['vg-installation.json','installation.json']])await fs.copyFile(root+'/artifacts/'+name,output+'/'+target);
console.log(JSON.stringify({pictures:pictures.length,motion,sourceSha:summary.sourceSha}));
