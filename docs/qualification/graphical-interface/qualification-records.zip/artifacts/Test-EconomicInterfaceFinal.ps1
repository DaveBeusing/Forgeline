$ErrorActionPreference = 'Stop'
dotnet test --solution ForgeLine.sln --configuration Release --no-build --max-parallel-test-modules 1 *> artifacts/operations-full-tests.log
$testExit = $LASTEXITCODE
@{ exitCode=$testExit; source=(& git rev-parse HEAD).Trim(); command='dotnet test --solution ForgeLine.sln --configuration Release --no-build --max-parallel-test-modules 1' } | ConvertTo-Json | Set-Content artifacts/operations-full-tests-status.json -Encoding utf8
dotnet run --project src/ForgeLine.Headless/ForgeLine.Headless.csproj --configuration Release --no-build -- --scenario central-divide --profile validation --ticks 80000 --seed 2026 --matches 1 --require-terminal --diagnostics-output artifacts/operations-terminal-match.json --telemetry-output artifacts/operations-terminal-telemetry.json *> artifacts/operations-terminal-match.log
$matchExit = $LASTEXITCODE
@{ testsExitCode=$testExit; matchExitCode=$matchExit; source=(& git rev-parse HEAD).Trim() } | ConvertTo-Json | Set-Content artifacts/operations-regression-status.json -Encoding utf8
Get-Content artifacts/operations-full-tests.log -Tail 15
Get-Content artifacts/operations-terminal-match.log -Tail 10
