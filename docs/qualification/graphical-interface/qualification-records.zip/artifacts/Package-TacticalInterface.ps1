$ErrorActionPreference='Stop'
$packageRoot=[IO.Path]::GetFullPath('artifacts/graphical-tactical-package',$PWD)
if(Test-Path -LiteralPath $packageRoot){throw 'Use a new package root.'}
./build/Publish-PreAlpha.ps1 -Configuration Release -VerifyReproducible -RuntimeAssetRoot assets/runtime -OutputRoot artifacts/graphical-tactical-package *> artifacts/tactical-package.log
if($LASTEXITCODE -ne 0){throw 'Package failed.'}
$client=Join-Path $packageRoot 'win-x64/publish/ForgeLine.Client.exe'
$runtime=Join-Path $packageRoot 'win-x64/publish/assets/runtime'
$settings=[IO.Path]::GetFullPath('artifacts/tactical-package-fresh-settings',$PWD)
if(Test-Path -LiteralPath $settings){throw 'Fresh settings root exists.'}
& $client --smoke-test --render-stress 1000 --settings-root $settings | Out-File artifacts/tactical-package-smoke.log -Encoding utf8
if($LASTEXITCODE -ne 0){throw 'Fresh package smoke failed.'}
& ./build/Invoke-RtsReferenceQualification.ps1 -Capture -ClientPath $client -RuntimeAssetRoot $runtime -Scenes BattlefieldCombat -Profiles Medium -Zooms NormalGameplay -Displays 1920x1080 -RasterDpi 96 -UiScales 1 -UiScenarios @('Contacts','Targeting','MinimapStrategic','MixedSelection','SupplyCritical') -Warmups 3 -Samples 8 -RepeatCaptures 2 -OutputRoot artifacts/tactical-native-packaged *> artifacts/tactical-package-capture.log
if($LASTEXITCODE -ne 0){throw 'Packaged rendering failed.'}
dotnet run --project src/ForgeLine.Headless/ForgeLine.Headless.csproj --configuration Release --no-build -- --scenario central-divide --profile validation --ticks 80000 --seed 2026 --matches 1 --require-terminal --diagnostics-output artifacts/tactical-terminal-match.json --telemetry-output artifacts/tactical-terminal-telemetry.json *> artifacts/tactical-terminal-match.log
if($LASTEXITCODE -ne 0){throw 'Natural terminal gate failed.'}
Write-Host 'Package, fresh settings, packaged rendering and terminal match complete.'
