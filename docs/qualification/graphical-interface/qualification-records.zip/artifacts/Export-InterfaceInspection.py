"""Create a separate, native-pixel HTML inspection aid; never rewrite evidence."""
from pathlib import Path
import argparse, hashlib, html, json

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--matrix', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
assert not a.output.exists()
assert not a.output.resolve().is_relative_to(a.matrix.resolve())
records = []
for checkpoint in sorted(a.matrix.glob('*.complete.json')):
    c = json.loads(checkpoint.read_text(encoding='utf-8-sig'))
    root = Path(c['root']); manifest = root/'manifest.json'
    assert hashlib.sha256(manifest.read_bytes()).hexdigest().upper() == c['manifestSha256']
    m = json.loads(manifest.read_text(encoding='utf-8-sig'))
    assert m['status'] == 'structural-pass' and not (root/'failure.json').exists()
    for row in m['captures']:
        image = (root/row['image']).resolve()
        assert image.is_relative_to(root.resolve())
        assert hashlib.sha256(image.read_bytes()).hexdigest().upper() == row['imageSha256']
        records.append(dict(key=row['key'],src=image.as_uri(),sha256=row['imageSha256'],
                            source=m['commit'],width=row['actualSurface']['width'],height=row['actualSurface']['height']))
assert records
# Machado severity-1 matrices are published numeric research data, independently
# checked against the Colour project's source dataset. SVG applies them in linear RGB.
matrices = {
 'protan': [.152286,1.052583,-.204868,.114503,.786281,.099216,-.003882,-.048116,1.051998],
 'deutan': [.367322,.860646,-.227968,.280085,.672501,.047413,-.011820,.042940,.968881],
 'tritan': [1.255528,-.076749,-.178779,-.078411,.930809,.147602,.004733,.691367,.303900]}
filters = ''
for name, matrix in matrices.items():
    values = ' '.join(str(x) for row in range(3) for x in [*matrix[row*3:row*3+3],0,0]) + ' 0 0 0 1 0'
    filters += f'<filter id="{name}" color-interpolation-filters="linearRGB"><feColorMatrix type="matrix" values="{values}"/></filter>'
data = json.dumps(records).replace('</','<\\/')
page = '''<!doctype html><html lang="en"><meta charset="utf-8"><title>FORGELINE native UI inspection</title>
<style>body{margin:0;background:#171d21;color:#eee;font:16px system-ui}header{position:sticky;top:0;background:#171d21;padding:12px;z-index:2}select,button{font:inherit;max-width:70vw}p{margin:6px 0}#viewport{overflow:auto;height:75vh;border-top:1px solid #aab}img{display:block;max-width:none;width:auto;height:auto}code{font-size:12px;overflow-wrap:anywhere}</style>
<header><p>FORGELINE — native pixel inspection. Original evidence remains unchanged; human acceptance is pending.</p>
<button id="previous">Previous</button><select id="cases"></select><button id="next">Next</button>
<select id="mode"><option value="none">Original</option><option value="grayscale(1)">Grayscale aid</option><option value="url(#protan)">Protan aid</option><option value="url(#deutan)">Deutan aid</option><option value="url(#tritan)">Tritan approximation</option></select>
<p id="identity"></p><code id="hash"></code></header><svg width="0" height="0" aria-hidden="true"><defs>FILTERS</defs></svg>
<div id="viewport"><img id="image" alt="Selected original UI capture at native pixel size"></div>
<p>Use 100% browser zoom and scroll to inspect every pixel; no fit-to-screen scaling is applied. Display filters are inspection aids, not game accessibility modes or human acceptance. Physical monitors and live interaction require separate review.</p>
<p>Numeric model: <a href="https://www.inf.ufrgs.br/~oliveira/pubs_files/CVD_Simulation/CVD_Simulation.html">Machado / Oliveira / Fernandes</a>; checked against <a href="https://github.com/colour-science/colour/blob/develop/colour/blindness/datasets/machado2010.py">Colour dataset</a>. Tritan uses the model's shift approximation.</p>
<script>const records=DATA; const cases=document.querySelector('#cases'), picture=document.querySelector('#image');
records.forEach((r,i)=>{const o=document.createElement('option');o.value=i;o.textContent=r.key;cases.append(o)});
function show(){const r=records[Number(cases.value)];picture.src=r.src;picture.width=r.width;picture.height=r.height;document.querySelector('#identity').textContent=`${r.width} × ${r.height} — source ${r.source}`;document.querySelector('#hash').textContent=`Original PNG SHA-256: ${r.sha256}`;}
cases.onchange=show;document.querySelector('#previous').onclick=()=>{cases.selectedIndex=Math.max(0,cases.selectedIndex-1);show()};document.querySelector('#next').onclick=()=>{cases.selectedIndex=Math.min(records.length-1,cases.selectedIndex+1);show()};document.querySelector('#mode').onchange=e=>picture.style.filter=e.target.value;show();</script></html>'''
page = page.replace('FILTERS',filters).replace('DATA',data)
a.output.write_text(page,encoding='utf-8',newline='\n')
print(f'Exported {len(records)} source-bound native images for separate visual inspection; no originals modified.')
