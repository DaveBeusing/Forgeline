$ErrorActionPreference = 'Stop'
$source = (& git rev-parse HEAD).Trim()
if ($source -ne '5b216f7f3e87b8e7bbfb90f7ac53392e5b6f374b') { throw 'Candidate source changed.' }
$results = @()
function Step([string]$Name, [scriptblock]$Action) {
    $watch = [Diagnostics.Stopwatch]::StartNew()
    $log = "artifacts/interface-$Name.log"
    $success = $true
    try { & $Action *> $log } catch { $success = $false; $_ | Out-String | Add-Content -LiteralPath $log }
    $script:results += [ordered]@{name=$Name;passed=$success;seconds=$watch.Elapsed.TotalSeconds;log=$log}
    [ordered]@{source=$source;results=$script:results} | ConvertTo-Json -Depth 6 | Set-Content artifacts/interface-checks.json
    Write-Host "$Name : $success"
    return $success
}
if (-not (Step 'restore' { dotnet restore ForgeLine.sln; if ($LASTEXITCODE) { throw 'Restore failed' } })) { exit 1 }
if (-not (Step 'build' { dotnet build ForgeLine.sln --configuration Release --no-restore; if ($LASTEXITCODE) { throw 'Build failed' } })) { exit 1 }
Step 'references' { ./build/Validate-ProjectReferences.ps1 } | Out-Null
Step 'version' { ./build/Validate-SemVer.ps1 -BaseRef origin/master; ./build/Test-Versioning.ps1; ./build/Test-VersionAllocation.ps1 } | Out-Null
if (-not (Step 'assets' { ./build/Build-RuntimeAssets.ps1 -Mode development -NoBuild -QualificationOutput artifacts/interface-assets.json -ProgressLog artifacts/interface-assets.jsonl })) { exit 1 }
Step 'contracts' { ./build/Test-UiQualificationMatrix.ps1; ./build/Validate-UiFonts.ps1; ./build/Validate-UiAudio.ps1; ./build/Test-VisualReferenceEvidence.ps1; ./build/Test-ReferencePerformance.ps1; ./build/Test-UiSkinPackage.ps1 } | Out-Null
Step 'full-tests' { dotnet test --solution ForgeLine.sln --configuration Release --no-build --max-parallel-test-modules 1; if ($LASTEXITCODE) { throw 'Full solution failed' } } | Out-Null
Step 'window-budget' { ./build/Invoke-WindowModeQualification.ps1 -SettingsRoot artifacts/interface-window-settings -WindowedReport artifacts/interface-windowed.json -BorderlessReport artifacts/interface-borderless.json -AssetQualificationReport artifacts/interface-assets.json } | Out-Null
Step 'lifetime' {
    $env:FORGELINE_GPU_LIFETIME_TESTS='1'
    try { dotnet test --project tests/ForgeLine.Graphics.Tests/ForgeLine.Graphics.Tests.csproj --configuration Release --no-build -- --filter-class '*D3D12ResourceLifetimeIntegrationTests'; if ($LASTEXITCODE) { throw 'Opt-in resource lifetime failed' } }
    finally { Remove-Item Env:FORGELINE_GPU_LIFETIME_TESTS }
} | Out-Null
Step 'matrix' { ./build/Invoke-UiInterfaceQualification.ps1 -Capture -OutputRoot artifacts/interface-native-matrix } | Out-Null
Write-Host 'Candidate checks complete; inspect each result, including failures.'
