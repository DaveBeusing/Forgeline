$ErrorActionPreference='Stop'
$client=(Resolve-Path src/ForgeLine.Client/bin/Release/net10.0-windows/win-x64/ForgeLine.Client.exe).Path
$common=@{Capture=$true;ClientPath=$client;RuntimeAssetRoot='assets/runtime';Scenes=@('BattlefieldCombat');Profiles=@('Medium');Warmups=3;Samples=8;RepeatCaptures=2}
$states=@('Contacts','Targeting','MinimapStrategic','MixedSelection','SupplyCritical')
& ./build/Invoke-RtsReferenceQualification.ps1 @common -Zooms NormalGameplay -Displays 1920x1080 -RasterDpi 96 -UiScales 1 -UiScenarios $states -OutputRoot artifacts/tactical-native-final-normal *> artifacts/tactical-native-final-normal.log
if($LASTEXITCODE -ne 0){throw 'Normal matrix failed.'}
& ./build/Invoke-RtsReferenceQualification.ps1 @common -Zooms NormalGameplay -InspectionDistanceMeters 120 -Displays 1920x1080 -RasterDpi 96 -UiScales 1 -UiScenarios $states -OutputRoot artifacts/tactical-native-final-close *> artifacts/tactical-native-final-close.log
if($LASTEXITCODE -ne 0){throw 'Close inspection matrix failed.'}
& ./build/Invoke-RtsReferenceQualification.ps1 @common -Zooms @('CloseTactical','NormalGameplay','Strategic') -Displays 1920x1080 -RasterDpi 96 -UiScales 1 -UiScenarios World -OutputRoot artifacts/tactical-native-final-world-zooms *> artifacts/tactical-native-final-world-zooms.log
if($LASTEXITCODE -ne 0){throw 'World zoom matrix failed.'}
& ./build/Invoke-RtsReferenceQualification.ps1 @common -Zooms NormalGameplay -Displays 1280x720 -RasterDpi 144 -UiScales @(.75,1,2) -UiScenarios $states -ResolutionScale .5 -OutputRoot artifacts/tactical-native-final-compact *> artifacts/tactical-native-final-compact.log
if($LASTEXITCODE -ne 0){throw 'Compact matrix failed.'}
& ./build/Invoke-RtsReferenceQualification.ps1 @common -Zooms NormalGameplay -Displays @('2560x1440','3440x1440') -RasterDpi 144 -UiScales 1 -UiScenarios $states -ResolutionScale .5 -OutputRoot artifacts/tactical-native-final-wide *> artifacts/tactical-native-final-wide.log
if($LASTEXITCODE -ne 0){throw 'Wide matrix failed.'}
& ./build/Invoke-RtsReferenceQualification.ps1 @common -Zooms NormalGameplay -Displays 3840x2160 -RasterDpi 192 -UiScales 2 -UiScenarios $states -ResolutionScale .5 -OutputRoot artifacts/tactical-native-final-4k *> artifacts/tactical-native-final-4k.log
if($LASTEXITCODE -ne 0){throw '4K matrix failed.'}
& ./build/Invoke-RtsReferenceQualification.ps1 @common -Zooms NormalGameplay -InspectionDistanceMeters 120 -Displays 1920x1080 -RasterDpi 96 -UiScales 1 -UiScenarios $states -WorldDaylight .2 -CloudCover 1 -OutputRoot artifacts/tactical-native-final-dark *> artifacts/tactical-native-final-dark.log
if($LASTEXITCODE -ne 0){throw 'Dark matrix failed.'}
Write-Host 'All 48 native tactical cases completed.'
