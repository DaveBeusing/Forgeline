from pathlib import Path
import hashlib, json, shutil, zipfile
A=Path('artifacts'); D=Path('docs/qualification/graphical-interface')
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
verification=read(A/'interface-native-verification.json')
assert verification['distinctCases']==2610
D.mkdir(parents=True,exist_ok=True)
records=set()
for p in A.glob('interface*'):
 if p.is_file() and p.name!='interface-retained-evidence.log' and p.suffix in {'.json','.jsonl','.log','.html'}: records.add(p)
for root in A.glob('interface*'):
 if root.is_dir():
  for p in root.rglob('*.json'):
   # Preserve capture/review/checkpoint records; exclude copied broken runtime trees.
   if 'assets' not in p.parts and 'settings' not in p.name.lower(): records.add(p)
for p in A.glob('*.ps1'):
 if any(k in p.name for k in ['Interface','GraphicalInterface']): records.add(p)
for p in A.glob('*.py'):
 if p.name not in {'Harden-InterfaceQualification.py','Write-InterfaceQualificationReport.py'} and any(k in p.name for k in ['Interface','GraphicalInterface']): records.add(p)
for p in (A/'allocation-counter-probe').glob('*'):
 if p.is_file(): records.add(p)
# Avoid copying a still-running progress record.
assert read(A/'interface-record-stage.json')['stage']=='complete'
archive=D/'qualification-records.zip'
entries=[]
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(records):
  z.write(p,p.as_posix())
  entries.append(dict(path=p.as_posix(),bytes=p.stat().st_size,sha256=sha(p)))
choices=[
 ('onboarding-before.png','interface-native-final/dpi96-1280x720-states2-attempt1','Onboarding',2),
 ('onboarding-after.png','interface-native-installed/dpi96-1280x720-states2-attempt1','Onboarding',2),
 ('onboarding-dpi192.png','interface-native-installed/dpi192-1280x720-states2-attempt1','Onboarding',2),
 ('operations-before.png','interface-native-final/dpi96-1280x720-states2-attempt1','Operations',2),
 ('operations-after.png','interface-native-installed/dpi96-1280x720-states2-attempt1','Operations',2),
 ('menu.png','interface-native-installed/dpi96-1920x1080-states1-attempt1','Menu',1),
 ('audio-settings.png','interface-native-installed/dpi144-2560x1440-states1-attempt1','SettingsAudio',1),
 ('controls-compact.png','interface-native-installed/dpi192-1280x720-states1-attempt1','ControlsLong',2),
 ('selection-4k.png','interface-native-installed/dpi192-3840x2160-states2-attempt1','SelectionUnit',2),
 ('contacts-ultrawide.png','interface-native-installed/dpi144-3440x1440-states2-attempt1','Contacts',1),
 ('operations-overcast.png','interface-installed-dark','Operations',1)]
images=[]
for name,root,scenario,scale in choices:
 r=A/root;m=read(r/'manifest.json')
 c=next(c for c in m['captures'] if c['ui']['scenario']==scenario and c['uiScale']==scale)
 src=r/c['image'];dest=D/name
 assert sha(src).upper()==c['imageSha256']
 shutil.copyfile(src,dest)
 assert sha(src)==sha(dest)
 images.append(dict(path=name,original=src.as_posix(),key=c['key'],source=m['commit'],runtimeFingerprint=m['runtimeFingerprint'],
                    imageSha256=c['imageSha256'],pixelSha256=c['pixelSha256'],width=c['actualSurface']['width'],height=c['actualSurface']['height']))
index=dict(schemaVersion=1,base='5bfd8a14ceaea60368ded7bad0b0a6e2f79a5be8',applicationSource=verification['source'],version='0.1.380-dev',
           qualificationSource='a73698d46a27d5d834d56ae773fc88af85e31b7a',testSource='a2c29525564a2ff5530d508fd790c685978ec6ac',
           visualAcceptance='pending',physicalMonitor='pending',liveMotion='pending',
           native={k:v for k,v in verification.items() if k!='cases'},
           package=read(A/'interface-package-verification.json'),
           archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),entries=entries),selectedOriginals=images)
(D/'evidence.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(records=len(entries),archiveBytes=archive.stat().st_size,images=len(images),imageBytes=sum((D/x['path']).stat().st_size for x in images)),indent=2))
