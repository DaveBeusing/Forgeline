using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text.Json;

var idle = new Sample[32];
var positive = new Sample[8];
var pressure = new Sample[192];
for (int i = 0; i < 128; i++) _ = MeasureIdle();
Thread.Sleep(600); // Outside measurement: allow ordinary tiered compilation to settle.
for (int i = 0; i < idle.Length; i++) idle[i] = MeasureIdle();
_ = Allocate();
for (int i = 0; i < positive.Length; i++) positive[i] = MeasurePositive();
using var ready = new ManualResetEventSlim();
int done = 0, requests = 0;
Exception? workerError = null;
var collector = new Thread(() =>
{
    try
    {
        var retained = new byte[8][];
        for (int i = 0; i < retained.Length; i++) retained[i] = new byte[1024 * 1024];
        GC.Collect(2, GCCollectionMode.Forced, blocking: true, compacting: false);
        ready.Set();
        for (int i = 0; i < 512 && Volatile.Read(ref done) == 0; i++)
        {
            retained[i % retained.Length] = new byte[1024 * 1024];
            Interlocked.Increment(ref requests);
            GC.Collect(2, GCCollectionMode.Forced, blocking: false, compacting: false);
            Thread.Sleep(2);
        }
        GC.KeepAlive(retained);
    }
    catch (Exception error) { workerError = error; ready.Set(); }
}) { IsBackground = true };
collector.Start();
bool joined = false;
try
{
    if (!ready.Wait(TimeSpan.FromSeconds(10))) throw new TimeoutException("Collector did not start.");
    if (workerError is not null) throw workerError;
    for (int i = 0; i < pressure.Length; i++)
    {
        // A live context is established outside the measured interval.
        object anchor = new byte[256];
        pressure[i] = MeasureIdle();
        GC.KeepAlive(anchor);
    }
}
finally
{
    Volatile.Write(ref done, 1);
    joined = collector.Join(TimeSpan.FromSeconds(10));
}
if (!joined) throw new TimeoutException("Collector did not stop.");
if (workerError is not null) throw workerError;
Console.WriteLine(JsonSerializer.Serialize(new
{
    runtime = RuntimeInformation.FrameworkDescription,
    os = RuntimeInformation.OSDescription,
    architecture = RuntimeInformation.ProcessArchitecture.ToString(),
    serverGc = System.Runtime.GCSettings.IsServerGC,
    warmupCalls = 128,
    warmupDelayMilliseconds = 600,
    requests,
    idle,
    positive,
    pressure,
    idleNonzero = idle.Count(x => x.Bytes != 0),
    positive64 = positive.Count(x => x.Bytes == 64),
    pressureNonzero = pressure.Count(x => x.Bytes != 0)
}, new JsonSerializerOptions { WriteIndented = true }));
return idle.Any(x => x.Bytes != 0) || positive.Any(x => x.Bytes != 64) ? 2 : 0;

[MethodImpl(MethodImplOptions.NoInlining)]
static Sample MeasureIdle()
{
    int gen2 = GC.CollectionCount(2);
    long start = GC.GetAllocatedBytesForCurrentThread();
    Thread.SpinWait(50_000);
    long bytes = GC.GetAllocatedBytesForCurrentThread() - start;
    return new(bytes, gen2, GC.CollectionCount(2));
}

[MethodImpl(MethodImplOptions.NoInlining)]
static Sample MeasurePositive()
{
    int gen2 = GC.CollectionCount(2);
    long start = GC.GetAllocatedBytesForCurrentThread();
    object value = Allocate();
    long bytes = GC.GetAllocatedBytesForCurrentThread() - start;
    GC.KeepAlive(value);
    return new(bytes, gen2, GC.CollectionCount(2));
}

[MethodImpl(MethodImplOptions.NoInlining)]
static byte[] Allocate() => new byte[37];

readonly record struct Sample(long Bytes, int Gen2Before, int Gen2After);
