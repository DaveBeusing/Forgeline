$ErrorActionPreference='Stop'
foreach($dpi in @(96,192)) {
    ./build/Invoke-RtsReferenceQualification.ps1 -Capture -ClientPath src/ForgeLine.Client/bin/Release/net10.0-windows/win-x64/ForgeLine.Client.exe -RuntimeAssetRoot assets/runtime -Scenes BattlefieldCombat -Profiles Medium -Zooms NormalGameplay -Displays 1280x720 -RasterDpi $dpi -UiScales 2 -UiScenarios @('Onboarding','Operations') -Warmups 3 -Samples 8 -RepeatCaptures 2 -OutputRoot "artifacts/interface-readable-probe-dpi$dpi"
}
