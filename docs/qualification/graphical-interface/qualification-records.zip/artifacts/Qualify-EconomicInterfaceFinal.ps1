$ErrorActionPreference = 'Stop'
$client = (Resolve-Path src/ForgeLine.Client/bin/Release/net10.0-windows/win-x64/ForgeLine.Client.exe).Path
$common = @{ Capture=$true; ClientPath=$client; RuntimeAssetRoot='assets/runtime'; Scenes=@('BattlefieldCombat'); Profiles=@('Medium'); Zooms=@('NormalGameplay'); Warmups=3; Samples=8; RepeatCaptures=2 }
$states = @('QueueBlocked','Technology','TechnologyBlocked','ProductionQueue','LogisticsBlocked','SupplyPolicy','Operations','OperationsEmpty','OperationsMissing','DockQueueTooltip','DockTechnologyTooltip','ResourcePressure','LowPower','SupplyCritical','DockPending','DockAccepted','DockRejected')
& ./build/Invoke-RtsReferenceQualification.ps1 @common -Displays 1920x1080 -RasterDpi 96 -UiScales 1 -UiScenarios $states -OutputRoot artifacts/operations-ui-final *> artifacts/operations-ui-final.log
if ($LASTEXITCODE -ne 0) { throw 'Normal named capture failed.' }
$compact = @('QueueBlocked','TechnologyBlocked','ProductionQueue','LogisticsBlocked','SupplyPolicy','Operations','OperationsEmpty','OperationsMissing','DockTechnologyTooltip')
& ./build/Invoke-RtsReferenceQualification.ps1 @common -Displays 1280x720 -RasterDpi 144 -UiScales @(.75,1,2) -UiScenarios $compact -ResolutionScale .5 -OutputRoot artifacts/operations-ui-final-compact *> artifacts/operations-ui-final-compact.log
if ($LASTEXITCODE -ne 0) { throw 'Compact named capture failed.' }
& ./build/Invoke-RtsReferenceQualification.ps1 @common -Displays 3840x2160 -RasterDpi 192 -UiScales 2 -UiScenarios $compact -ResolutionScale .5 -OutputRoot artifacts/operations-ui-final-4k *> artifacts/operations-ui-final-4k.log
if ($LASTEXITCODE -ne 0) { throw '4K named capture failed.' }
& ./build/Invoke-RtsReferenceQualification.ps1 @common -Displays @('2560x1440','3440x1440') -RasterDpi 144 -UiScales 1 -UiScenarios @('Operations','OperationsEmpty','OperationsMissing') -ResolutionScale .5 -OutputRoot artifacts/operations-ui-final-wide *> artifacts/operations-ui-final-wide.log
if ($LASTEXITCODE -ne 0) { throw 'Wide operations capture failed.' }
& $client --command-dock-capture (Join-Path $PWD 'artifacts/operations-dock-final-matrix') (Join-Path $PWD 'assets/runtime') | Out-File artifacts/operations-dock-final-matrix.log -Encoding utf8
if ($LASTEXITCODE -ne 0) { throw 'Full command matrix failed.' }
Write-Host 'All native qualification processes completed.'

