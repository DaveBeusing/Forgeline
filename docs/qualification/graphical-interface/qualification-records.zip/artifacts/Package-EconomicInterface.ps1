$ErrorActionPreference = 'Stop'
$packageRoot = [IO.Path]::GetFullPath('artifacts/graphical-operations-package',$PWD)
if (Test-Path -LiteralPath $packageRoot) { throw 'Use a new package root.' }
./build/Publish-PreAlpha.ps1 -Configuration Release -VerifyReproducible -RuntimeAssetRoot assets/runtime -OutputRoot artifacts/graphical-operations-package *> artifacts/operations-package.log
if ($LASTEXITCODE -ne 0) { throw 'Package qualification failed.' }
$client = Join-Path $packageRoot 'win-x64/publish/ForgeLine.Client.exe'
$runtime = Join-Path $packageRoot 'win-x64/publish/assets/runtime'
$settings = [IO.Path]::GetFullPath('artifacts/operations-package-fresh-settings',$PWD)
if (Test-Path -LiteralPath $settings) { throw 'Fresh settings root already exists.' }
& $client --smoke-test --render-stress 1000 --settings-root $settings | Out-File artifacts/operations-package-smoke.log -Encoding utf8
if ($LASTEXITCODE -ne 0) { throw 'Fresh package smoke failed.' }
& ./build/Invoke-RtsReferenceQualification.ps1 -Capture -ClientPath $client -RuntimeAssetRoot $runtime -Scenes BattlefieldCombat -Profiles Medium -Zooms NormalGameplay -Displays 1920x1080 -RasterDpi 96 -UiScales 1 -UiScenarios @('ProductionQueue','QueueBlocked','Operations','OperationsEmpty','DockTechnologyTooltip','LogisticsBlocked') -Warmups 3 -Samples 8 -RepeatCaptures 2 -OutputRoot artifacts/operations-ui-packaged *> artifacts/operations-package-capture.log
if ($LASTEXITCODE -ne 0) { throw 'Packaged native capture failed.' }
Write-Host 'Reproducible package, fresh settings smoke and packaged captures complete.'

