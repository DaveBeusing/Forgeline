$ErrorActionPreference='Stop'
$clock=[Diagnostics.Stopwatch]::StartNew()
$complete='artifacts/interface-native-installed/complete.json'
while(-not(Test-Path -LiteralPath $complete)) {
    if($clock.Elapsed.TotalHours -gt 4){throw 'Native matrix completion was not observed within four hours.'}
    Start-Sleep -Seconds 45
}
$matrix=Get-Content -LiteralPath $complete -Raw|ConvertFrom-Json
if($matrix.status -cne 'structural-pass' -or $matrix.commit -cne '705e63297748fc1fd675d3fe331fbd94e8c20c34' -or $matrix.cases -ne 2610){throw 'Unexpected completed matrix.'}
@{stage='matched-performance';startedUtc=[DateTime]::UtcNow.ToString('O')}|ConvertTo-Json|Set-Content artifacts/interface-post-native-stage.json
./artifacts/Compare-InstalledInterfacePerformance.ps1
@{stage='allocation-counter-diagnostic';startedUtc=[DateTime]::UtcNow.ToString('O')}|ConvertTo-Json|Set-Content artifacts/interface-post-native-stage.json
dotnet build artifacts/allocation-counter-probe/CounterProbe.csproj --configuration Release *> artifacts/interface-counter-build.log
if($LASTEXITCODE){throw 'Counter diagnostic build failed.'}
dotnet artifacts/allocation-counter-probe/bin/Release/net10.0/CounterProbe.dll > artifacts/interface-counter-diagnostic.json
if($LASTEXITCODE){throw 'Allocation counter controls failed.'}
@{stage='complete';completedUtc=[DateTime]::UtcNow.ToString('O')}|ConvertTo-Json|Set-Content artifacts/interface-post-native-stage.json
