$ErrorActionPreference='Stop'
$source=(& git rev-parse HEAD).Trim()
if($source -ne '705e63297748fc1fd675d3fe331fbd94e8c20c34'){throw 'Source changed.'}
if((& git status --porcelain)){throw 'Source must remain clean.'}
$results=@()
function Step([string]$Name,[scriptblock]$Action) {
    $clock=[Diagnostics.Stopwatch]::StartNew();$log="artifacts/interface-final-$Name.log";$success=$true
    try { & $Action *> $log } catch { $success=$false;$_|Out-String|Add-Content -LiteralPath $log }
    $script:results += [ordered]@{name=$Name;passed=$success;seconds=$clock.Elapsed.TotalSeconds;log=$log}
    [ordered]@{source=$source;results=$script:results}|ConvertTo-Json -Depth 6|Set-Content artifacts/interface-final-checks.json
    Write-Host "$Name : $success";return $success
}
Step 'restore' {dotnet restore ForgeLine.sln;if($LASTEXITCODE){throw 'Restore failed'}}|Out-Null
Step 'references' {./build/Validate-ProjectReferences.ps1}|Out-Null
Step 'version' {./build/Validate-SemVer.ps1 -BaseRef origin/master;./build/Test-Versioning.ps1;./build/Test-VersionAllocation.ps1}|Out-Null
if(-not(Step 'assets' {./build/Build-RuntimeAssets.ps1 -Mode development -NoBuild -QualificationOutput artifacts/interface-final-assets.json -ProgressLog artifacts/interface-final-assets.jsonl})){exit 1}
Step 'contracts' {./build/Test-UiQualificationMatrix.ps1;./build/Test-RuntimeAssetPipeline.ps1;./build/Validate-UiFonts.ps1;./build/Validate-UiAudio.ps1;./build/Test-VisualReferenceEvidence.ps1;./build/Test-ReferencePerformance.ps1;./build/Test-UiSkinPackage.ps1}|Out-Null
Step 'full-tests' {dotnet test --solution ForgeLine.sln --configuration Release --no-build --max-parallel-test-modules 1;if($LASTEXITCODE){throw 'Full suite failed'}}|Out-Null
Step 'window-budget' {./build/Invoke-WindowModeQualification.ps1 -SettingsRoot artifacts/interface-final-window-settings -WindowedReport artifacts/interface-final-windowed.json -BorderlessReport artifacts/interface-final-borderless.json -AssetQualificationReport artifacts/interface-final-assets.json}|Out-Null
if(-not(Step 'package' {./artifacts/Package-GraphicalInterface.ps1})){exit 1}
$client='artifacts/graphical-interface-package/win-x64/publish/ForgeLine.Client.exe'
$runtime='artifacts/graphical-interface-package/win-x64/publish/assets/runtime'
Step 'installed-window-modes' {
    $settings=[IO.Path]::GetFullPath('artifacts/interface-installed-window-settings',$PWD)
    if(Test-Path -LiteralPath $settings){throw 'Settings root exists'}
    foreach($mode in @('windowed','borderless')) {
        if($mode -eq 'borderless') {
            $path=Join-Path $settings 'FORGELINE/settings.json'
            $data=Get-Content -LiteralPath $path -Raw|ConvertFrom-Json -Depth 32
            $data.borderlessFullscreen=$true
            $data|ConvertTo-Json -Depth 32|Set-Content -LiteralPath $path -Encoding utf8
        }
        & ([IO.Path]::GetFullPath($client,$PWD)) --smoke-test --render-stress 1000 --settings-root $settings --visual-qualification-output ([IO.Path]::GetFullPath("artifacts/interface-installed-$mode.json",$PWD)) | Out-Host
        if($LASTEXITCODE){throw "Direct installed smoke failed: $mode"}
    }
}|Out-Null
Step 'installed-negative' {./artifacts/Test-InstalledInterfaceFailures.ps1}|Out-Null
$common=@{Capture=$true;ClientPath=$client;RuntimeAssetRoot=$runtime;Scenes='BattlefieldCombat';Profiles='Medium';Zooms='NormalGameplay';RasterDpi=96;UiScales=1;Warmups=64;Samples=256;RepeatCaptures=2;Displays='1920x1080';UiScenarios=@('Menu','Onboarding','Operations','Contacts');CinematicFrontend=$true}
Step 'warm-pair' {
    ./build/Invoke-RtsReferenceQualification.ps1 @common -OutputRoot artifacts/interface-warm-installed/run-1
    ./build/Invoke-RtsReferenceQualification.ps1 @common -OutputRoot artifacts/interface-warm-installed/run-2
    ./build/Compare-ReferencePerformance.ps1 -CurrentRoot artifacts/interface-warm-installed/run-2 -BaselineRoot artifacts/interface-warm-installed/run-1 -ReportPath artifacts/interface-warm-installed/variance.json
}|Out-Null
Step 'dark-terrain' {./build/Invoke-RtsReferenceQualification.ps1 -Capture -ClientPath $client -RuntimeAssetRoot $runtime -Scenes BattlefieldCombat -Profiles Medium -Zooms NormalGameplay -Displays 1920x1080 -RasterDpi 96 -UiScales 1 -UiScenarios @('Onboarding','Operations','Contacts') -Warmups 3 -Samples 8 -RepeatCaptures 2 -WorldDaylight .2 -CloudCover 1 -OutputRoot artifacts/interface-installed-dark}|Out-Null
Step 'world-half' {./build/Invoke-RtsReferenceQualification.ps1 -Capture -ClientPath $client -RuntimeAssetRoot $runtime -Scenes BattlefieldCombat -Profiles Medium -Zooms NormalGameplay -Displays 3840x2160 -RasterDpi 192 -UiScales 2 -UiScenarios @('Menu','Onboarding','Operations','Contacts') -CinematicFrontend -ResolutionScale .5 -Warmups 3 -Samples 8 -RepeatCaptures 2 -OutputRoot artifacts/interface-installed-half}|Out-Null
Step 'software-fallback' {./build/Invoke-RtsReferenceQualification.ps1 -Capture -Software -ClientPath $client -RuntimeAssetRoot $runtime -Scenes BattlefieldCombat -Profiles Low -Zooms NormalGameplay -Displays 640x360 -RasterDpi 96 -UiScales 1 -UiScenarios @('Menu','Controls','Onboarding','Operations') -Warmups 3 -Samples 8 -RepeatCaptures 2 -OutputRoot artifacts/interface-installed-warp}|Out-Null
Step 'installed-matrix' {./build/Invoke-UiInterfaceQualification.ps1 -Capture -ClientPath $client -RuntimeAssetRoot $runtime -OutputRoot artifacts/interface-native-installed}|Out-Null
Write-Host 'Installed qualification completed. Inspect individual failures and pending human acceptance.'
