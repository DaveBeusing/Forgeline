$ErrorActionPreference='Stop'
$clock=[Diagnostics.Stopwatch]::StartNew()
while($true) {
    $ready=$false
    if(Test-Path -LiteralPath artifacts/interface-post-native-stage.json) {
        try {$ready=(Get-Content artifacts/interface-post-native-stage.json -Raw|ConvertFrom-Json).stage -ceq 'complete'} catch {}
    }
    if($ready){break}
    if($clock.Elapsed.TotalHours -gt 4){throw 'Post-native work did not complete within four hours.'}
    Start-Sleep -Seconds 45
}
@{stage='verifying-originals';startedUtc=[DateTime]::UtcNow.ToString('O')}|ConvertTo-Json|Set-Content artifacts/interface-record-stage.json
$python='C:/Users/david.beusing/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
& $python -X utf8 artifacts/Verify-InstalledInterfaceMatrix.py
if($LASTEXITCODE){throw 'Native original verification failed.'}
foreach($display in @('1280x720','1920x1080')) {
    foreach($bank in @(1,2)) {
        $id="dpi96-$display-states$bank-attempt1"
        ./build/Compare-VisualReferenceEvidence.ps1 -CurrentRoot "artifacts/interface-native-installed/$id" -BaselineRoot "artifacts/interface-native-final/$id" -ComparePixels -ReportPath "artifacts/interface-before-after-$display-states$bank.json"
    }
}
$extra=@('interface-packaged-native','interface-installed-dark','interface-installed-half','interface-installed-warp',
    'interface-readable-probe-dpi96','interface-readable-probe-dpi192','interface-warm-installed/run-1','interface-warm-installed/run-2')
foreach($side in @('before','after')) {foreach($workload in @('normal','compact')) {foreach($run in @(1,2)) {$extra+="interface-performance-$side/$workload/run-$run"}}}
foreach($name in $extra) {
    $root="artifacts/$name"
    $review=[IO.Path]::GetFullPath("artifacts/interface-review-$($name.Replace('/','-')).pending.json",$PWD)
    ./build/Export-VisualReferenceReview.ps1 -EvidenceRoot $root -OutputPath $review
}
$rejected=$false
try {
    ./build/Compare-VisualReferenceEvidence.ps1 -CurrentRoot artifacts/interface-warm-installed/run-2 -BaselineRoot artifacts/interface-warm-installed/run-1 -GateImages -ApprovalPath artifacts/interface-review-interface-warm-installed-run-1.pending.json -ReportPath artifacts/interface-pending-review-gate.json
} catch {
    $_|Out-String|Set-Content artifacts/interface-pending-review-gate.log
    if($_.ToString() -notmatch 'review|approval|accepted'){throw}
    $rejected=$true
}
if(-not $rejected){throw 'Pending human review unexpectedly passed.'}
& $python -X utf8 artifacts/Export-InterfaceInspection.py --matrix artifacts/interface-native-installed --output artifacts/interface-native-inspection.html
if($LASTEXITCODE){throw 'Inspection aid export failed.'}
@{stage='complete';completedUtc=[DateTime]::UtcNow.ToString('O');pendingHumanGateRejected=$rejected}|ConvertTo-Json|Set-Content artifacts/interface-record-stage.json
