$ErrorActionPreference='Stop'
$target=[IO.Path]::GetFullPath((Join-Path $PWD 'artifacts/interface-performance-baseline-source'))
$expected=[IO.Path]::GetFullPath((Join-Path $PWD 'artifacts'))+[IO.Path]::DirectorySeparatorChar
if(-not $target.StartsWith($expected,[StringComparison]::OrdinalIgnoreCase)){throw 'Cleanup target escaped artifacts.'}
# The comparison script verified a clean detached baseline before Git removed its registration.
if(Test-Path -LiteralPath $target){Remove-Item -LiteralPath $target -Recurse -Force}
if(Test-Path -LiteralPath $target){throw 'Baseline cleanup remains incomplete.'}
@{stage='allocation-counter-diagnostic';startedUtc=[DateTime]::UtcNow.ToString('O');performanceCapturesComplete=$true;cleanupRecovered=$true}|ConvertTo-Json|Set-Content artifacts/interface-post-native-stage.json
dotnet build artifacts/allocation-counter-probe/CounterProbe.csproj --configuration Release *> artifacts/interface-counter-build.log
$buildExit=$LASTEXITCODE
$counterExit=$null
if($buildExit -eq 0){
    dotnet artifacts/allocation-counter-probe/bin/Release/net10.0/CounterProbe.dll > artifacts/interface-counter-diagnostic.json
    $counterExit=$LASTEXITCODE
}
@{stage='complete';completedUtc=[DateTime]::UtcNow.ToString('O');performanceCapturesComplete=$true;cleanupRecovered=$true;counterBuildExitCode=$buildExit;counterDiagnosticExitCode=$counterExit;counterControlsPassed=($counterExit -eq 0)}|ConvertTo-Json|Set-Content artifacts/interface-post-native-stage.json
