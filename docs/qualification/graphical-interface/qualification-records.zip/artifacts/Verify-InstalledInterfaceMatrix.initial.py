from pathlib import Path
from PIL import Image
import hashlib, itertools, json

SOURCE='705e63297748fc1fd675d3fe331fbd94e8c20c34'
RUNTIME='B8ACA01894C15F98C09ACB5A1A80EA173B7FCD73C51D4C7E7BFF3701B61F523F'
ROOT=Path('artifacts/interface-native-installed')
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
plan=read(ROOT/'plan.json'); complete=read(ROOT/'complete.json')
assert complete['status']=='structural-pass' and complete['commit']==SOURCE and complete['cases']==2610
assert len(plan['scenarios'])==58 and len(set(plan['scenarios']))==58
expected=set(itertools.product(plan['scenarios'],['1280x720','1920x1080','2560x1440','3440x1440','3840x2160'],[96,144,192],[.75,1,2]))
keys=set(); rows=[]; cohorts=[]; assemblies=set(); drivers=set(); host_dpis=set(); image_bytes=0
for cohort in complete['cohorts']:
 root=Path(cohort['root']); mp=root/'manifest.json'; m=read(mp)
 assert m['status']=='structural-pass' and m['commit']==SOURCE and not (root/'failure.json').exists()
 assert sha(mp).upper()==cohort['manifestSha256']
 assert m['runtimeFingerprint']==RUNTIME and len(m['captures'])==87
 assert not m['software'] and m['environment']['configuration']=='Release'
 assemblies.add((m['clientAssemblySha256'],m['presentationAssemblySha256']))
 drivers.add(m['driver']); host_dpis.add(m['hostWindowDpi'])
 review_path=Path(cohort['review']); review=read(review_path)
 assert review['manifestSha256']==cohort['manifestSha256'] and review['commit']==SOURCE
 assert not review['reviewer'] and not review['reviewedAtUtc']
 assert all(review[k]=='pending' for k in ['physicalMonitor','liveMotion','gpuPerformance'])
 reviewed={r['key']:r for r in review['captures']}; assert len(reviewed)==87
 for c in m['captures']:
  display=f"{c['requestedDisplay']['width']}x{c['requestedDisplay']['height']}"
  case=(c['ui']['scenario'],display,c['rasterDpi'],c['uiScale'])
  assert case in expected,case; expected.remove(case)
  assert c['key'] not in keys; keys.add(c['key'])
  assert c['repeatPixelsEqual'] and c['repeatCaptures']==2 and not c['repeatFailures']
  assert c['actualSurface']['width']==c['requestedDisplay']['width'] and c['actualSurface']['height']==c['requestedDisplay']['height']
  assert c['ui']['text']['atlasReady'] and c['ui']['text']['missingGlyphs']==c['ui']['text']['droppedGlyphs']==0
  for name in ['skin','battlefieldSkin']:
   skin=c['ui'].get(name)
   if skin: assert skin['missingAssets']==skin['droppedQuads']==0
  assert c['ui']['battlefieldSkin']['prepared']
  assert c['graphics']['resources']['textureBindingFailureCount']==0
  assert c['graphics']['health']['submissionFaultCount']==c['graphics']['health']['pendingRetirementCount']==0
  assert c['materials']['bindingFailureCount']==c['instances']['fallbackMeshInstances']==0
  assert c['run']['resourcesBeforeSetup']['loadedTextureCount']==c['run']['resourcesBeforeSetup']['residentTextureBytes']==0
  assert c['run']['resourcesBeforeSamples']['textureUploadCount']==c['graphics']['resources']['textureUploadCount']
  image=(root/c['image']).resolve();assert image.is_relative_to(root.resolve())
  assert sha(image).upper()==c['imageSha256']
  with Image.open(image) as png:
   assert png.mode=='RGBA' and png.size==(c['actualSurface']['width'],c['actualSurface']['height'])
   assert hashlib.sha256(png.tobytes()).hexdigest().upper()==c['pixelSha256']
  image_bytes+=image.stat().st_size
  decision=reviewed[c['key']]
  assert decision['decision']=='pending' and decision['imageSha256']==c['imageSha256'] and all(x=='pending' for x in decision['rubric'].values())
  rows.append(dict(key=c['key'],root=str(root),image=c['image'],imageSha256=c['imageSha256'],pixelSha256=c['pixelSha256'],
      uiScenario=c['ui']['scenario'],display=display,rasterDpi=c['rasterDpi'],uiScale=c['uiScale'],hostWindowDpi=c['hostWindowDpi'],
      skin=c['ui']['battlefieldSkin'],frontendSkin=c['ui']['skin'],text=c['ui']['text'],cpu=c['cpu'],gpu=c['gpu'],
      resources=c['graphics']['resources'],health=c['graphics']['health'],device=c['graphics']['device'],
      beforeSetup=c['run']['resourcesBeforeSetup'],allocations=c['performance']['allocations']))
 cohorts.append(dict(id=cohort['id'],root=str(root),manifestSha256=cohort['manifestSha256'],reviewSha256=sha(review_path),cases=87))
assert not expected and len(rows)==2610 and len(cohorts)==30 and len(assemblies)==1 and len(drivers)==1
result=dict(source=SOURCE,runtimeFingerprint=RUNTIME,distinctCases=2610,readbacks=5220,cohorts=cohorts,
            assemblyHashes=list(assemblies)[0],drivers=list(drivers),hostWindowDpis=sorted(host_dpis),originalPngBytes=image_bytes,
            visualAcceptance='pending',physicalMonitor='pending',liveMotion='pending',cases=rows)
Path('artifacts/interface-native-verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['cases','cohorts']},indent=2))
