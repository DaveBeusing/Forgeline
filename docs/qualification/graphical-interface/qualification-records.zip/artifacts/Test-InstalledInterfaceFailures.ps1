$ErrorActionPreference='Stop'
$package=[IO.Path]::GetFullPath('artifacts/graphical-interface-package/win-x64/publish',$PWD)
$root=[IO.Path]::GetFullPath('artifacts/interface-installed-failures',$PWD)
if(Test-Path -LiteralPath $root){throw 'Negative fixture root already exists.'}
[void](New-Item -ItemType Directory -Path $root)
$results=@()
foreach($kind in @('missing-manifest','corrupt-signature','missing-ui-page','corrupt-core-mesh')) {
    $fixture=Join-Path $root $kind
    [void](New-Item -ItemType Directory -Path $fixture)
    $runtime=Join-Path $fixture 'runtime'
    if($kind -ne 'missing-manifest') {Copy-Item -LiteralPath (Join-Path $package 'assets/runtime') -Destination $runtime -Recurse}
    else {[void](New-Item -ItemType Directory -Path $runtime)}
    $manifestPath=Join-Path $runtime 'manifest.json'
    $changed=$null;$before=$null
    if($kind -eq 'corrupt-signature') {
        $manifest=Get-Content -LiteralPath $manifestPath -Raw|ConvertFrom-Json -Depth 40
        $manifest.contentSignature='0'*64
        $manifest|ConvertTo-Json -Depth 40|Set-Content -LiteralPath $manifestPath -Encoding utf8
        $changed=$manifestPath;$before=(Get-FileHash -LiteralPath $changed).Hash
    } elseif($kind -in @('missing-ui-page','corrupt-core-mesh')) {
        $manifest=Get-Content -LiteralPath $manifestPath -Raw|ConvertFrom-Json -Depth 40
        $id=if($kind -eq 'missing-ui-page'){'ui.atlas.directorate.core.p1'}else{'building.directorate.command_core'}
        $asset=@($manifest.assets|Where-Object id -CEQ $id)
        if($asset.Count -ne 1){throw "Unknown required asset: $id"}
        $changed=[IO.Path]::GetFullPath((Join-Path $runtime $asset[0].runtimePath))
        if(-not $changed.StartsWith($runtime+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Fixture asset escaped runtime.'}
        if($kind -eq 'missing-ui-page'){Remove-Item -LiteralPath $changed}
        else {$bytes=[IO.File]::ReadAllBytes($changed);$bytes[-1]=$bytes[-1]-bxor 1;[IO.File]::WriteAllBytes($changed,$bytes);$before=(Get-FileHash -LiteralPath $changed).Hash}
    }
    $start=[Diagnostics.ProcessStartInfo]::new((Join-Path $package 'ForgeLine.Client.exe'))
    $start.WorkingDirectory=$fixture;$start.UseShellExecute=$false;$start.CreateNoWindow=$true;$start.WindowStyle=[Diagnostics.ProcessWindowStyle]::Hidden
    $start.RedirectStandardOutput=$true;$start.RedirectStandardError=$true;$start.Environment['FORGELINE_RUNTIME_ASSETS']=$runtime
    $report=Join-Path $fixture 'startup.json'
    $arguments=@('--skip-splash','--settings-root',(Join-Path $fixture 'settings'),'--startup-diagnostics-output',$report)
    $arguments+=if($kind -in @('missing-ui-page','corrupt-core-mesh')){@('--smoke-test','--render-stress','1000')}else{@('--startup-menu-smoke-test')}
    foreach($argument in $arguments){$start.ArgumentList.Add($argument)}
    $process=[Diagnostics.Process]::Start($start);$stdout=$process.StandardOutput.ReadToEndAsync();$stderr=$process.StandardError.ReadToEndAsync()
    try {
        if(-not $process.WaitForExit(60000)){$process.Kill($true);$process.WaitForExit();throw "Installed negative case timed out: $kind"}
        $stdout.GetAwaiter().GetResult()|Set-Content (Join-Path $fixture 'stdout.log')
        $stderr.GetAwaiter().GetResult()|Set-Content (Join-Path $fixture 'stderr.log')
        if($process.ExitCode -ne 1){throw "Expected installed asset rejection exit 1: $kind / $($process.ExitCode)"}
        if(-not(Test-Path -LiteralPath $report)){throw 'Missing startup diagnostics.'}
        if($kind -eq 'missing-ui-page' -and (Test-Path -LiteralPath $changed)){throw 'Player repaired a missing UI page.'}
        if($before -and (Get-FileHash -LiteralPath $changed).Hash -cne $before){throw 'Player repaired a damaged runtime file.'}
        $results += @{case=$kind;exitCode=$process.ExitCode;report=$report;runtimeUnchanged=$true}
    } finally {$process.Dispose()}
}
[ordered]@{cases=$results;source=(& git rev-parse HEAD).Trim();package=$package}|ConvertTo-Json -Depth 6|Set-Content (Join-Path $root 'results.json')
Write-Output 'Four installed missing/corrupt content cases rejected without source compilation or runtime repair.'
