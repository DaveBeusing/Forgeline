from pathlib import Path
import hashlib, json, zipfile

cases = [
 ('before','graphical-tactical-package','0.1.379','c10f1a143dd9c5fa972b0fe65f604cd580ca74adf685116dee15c8ce7ebf2dc8'),
 ('after','graphical-interface-package','0.1.380','c366d3452fe6b1ddf6e14ae3f5943ed5459484e6bb87f14857643218b12595fa')]
records=[]
for side,folder,version,expected in cases:
 root=Path('artifacts')/folder
 archive=root/f'FORGELINE-{version}-dev-win-x64.zip'
 assert hashlib.sha256(archive.read_bytes()).hexdigest()==expected
 publish=(root/'win-x64/publish').resolve()
 with zipfile.ZipFile(archive) as z:
  checked=0
  for line in z.read('manifest.sha256').decode('utf-8-sig').splitlines():
   digest,name=line.split('  ',1); target=(publish/name).resolve()
   assert target.is_relative_to(publish)
   assert hashlib.sha256(target.read_bytes()).hexdigest()==digest, name
   checked+=1
  manifest=json.loads(z.read('assets/runtime/manifest.json'))
 records.append(dict(side=side,archive=str(archive),sha256=expected,files=checked,contentSignature=manifest['contentSignature']))
assert records[0]['contentSignature']==records[1]['contentSignature']
Path('artifacts/interface-performance-package-verification.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Both immutable performance packages match their recorded archives and every published file checksum.')
