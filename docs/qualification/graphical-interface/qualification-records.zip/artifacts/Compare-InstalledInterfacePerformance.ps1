$ErrorActionPreference='Stop'
$repository=$PWD.Path
$baseline='0cb9b8089f84abfdce0e754e9176be5c4628c16b'
$candidate='705e63297748fc1fd675d3fe331fbd94e8c20c34'
if((& git rev-parse HEAD).Trim() -cne $candidate){throw 'Candidate source changed.'}
$worktree=[IO.Path]::GetFullPath('artifacts/interface-performance-baseline-source',$repository)
$artifacts=[IO.Path]::GetFullPath('artifacts',$repository)
if(-not $worktree.StartsWith($artifacts+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Baseline checkout escaped artifacts.'}
if(Test-Path -LiteralPath $worktree){throw 'Baseline checkout exists.'}
$oldPublish=[IO.Path]::GetFullPath('artifacts/graphical-tactical-package/win-x64/publish',$repository)
$newPublish=[IO.Path]::GetFullPath('artifacts/graphical-interface-package/win-x64/publish',$repository)
$oldArchive=Join-Path $repository 'artifacts/graphical-tactical-package/FORGELINE-0.1.379-dev-win-x64.zip'
if((Get-FileHash -LiteralPath $oldArchive).Hash -cne 'C10F1A143DD9C5FA972B0FE65F604CD580CA74ADF685116DEE15C8CE7EBF2DC8'){throw 'Baseline archive identity changed.'}
$oldIdentity=Get-Content (Join-Path $oldPublish 'build-provenance.json') -Raw|ConvertFrom-Json
& 'C:/Users/david.beusing/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -X utf8 artifacts/Verify-InterfacePerformancePackages.py
if($LASTEXITCODE){throw 'Performance package verification failed.'}
git -c core.longpaths=true worktree add --detach $worktree $baseline
if($LASTEXITCODE){throw 'Cannot prepare isolated baseline source.'}
$runs=@()
try {
    foreach($run in @(1,2)) {
        foreach($workload in @('normal','compact')) {
            foreach($side in @('before','after')) {
                $tree=if($side -eq 'before'){$worktree}else{$repository}
                $publish=if($side -eq 'before'){$oldPublish}else{$newPublish}
                $source=if($side -eq 'before'){$baseline}else{$candidate}
                $root=Join-Path $artifacts "interface-performance-$side/$workload/run-$run"
                Push-Location $tree
                try {
                    if((& git rev-parse HEAD).Trim() -cne $source -or (& git status --porcelain)){throw 'Performance source is not clean and attributable.'}
                    $parameters=@{Capture=$true;ClientPath=(Join-Path $publish 'ForgeLine.Client.exe');RuntimeAssetRoot=(Join-Path $publish 'assets/runtime');Scenes='BattlefieldCombat';Profiles='Medium';Zooms='NormalGameplay';Warmups=64;Samples=256;RepeatCaptures=2;OutputRoot=$root}
                    if($workload -eq 'normal'){$parameters.Displays='1920x1080';$parameters.RasterDpi=96;$parameters.UiScales=1;$parameters.UiScenarios=@('Menu','Onboarding','Operations','Contacts');$parameters.CinematicFrontend=$true}
                    else {$parameters.Displays='1280x720';$parameters.RasterDpi=192;$parameters.UiScales=2;$parameters.UiScenarios=@('Onboarding','Operations')}
                    ./build/Invoke-RtsReferenceQualification.ps1 @parameters
                    $runs+=@{source=$source;side=$side;workload=$workload;run=$run;root=$root}
                } finally {Pop-Location}
            }
        }
    }
    foreach($workload in @('normal','compact')) {
        ./build/Compare-ReferencePerformance.ps1 -CurrentRoot "artifacts/interface-performance-after/$workload/run-2" -BaselineRoot "artifacts/interface-performance-before/$workload/run-2" -ReportPath "artifacts/interface-performance-$workload-before-after.json"
        foreach($side in @('before','after')) {
            ./build/Compare-ReferencePerformance.ps1 -CurrentRoot "artifacts/interface-performance-$side/$workload/run-2" -BaselineRoot "artifacts/interface-performance-$side/$workload/run-1" -ReportPath "artifacts/interface-performance-$side-$workload-variance.json"
        }
    }
    [ordered]@{baseline=$baseline;candidate=$candidate;baselinePackage=$oldArchive;baselineProvenance=$oldIdentity;runs=$runs;sequence='Alternating before/after; normal and compact; two independent processes per side/workload.'}|ConvertTo-Json -Depth 8|Set-Content artifacts/interface-performance-identities.json
} finally {
    if((& git -C $worktree status --porcelain)){throw 'Baseline checkout acquired changes; preserved for inspection.'}
    if(-not [IO.Path]::GetFullPath($worktree).StartsWith($artifacts+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Cleanup path escaped verified workspace.'}
    git worktree remove $worktree
    if($LASTEXITCODE){throw 'Baseline checkout cleanup failed.'}
}
