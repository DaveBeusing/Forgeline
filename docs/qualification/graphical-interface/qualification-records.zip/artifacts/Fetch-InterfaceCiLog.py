import subprocess,urllib.request,urllib.parse
from pathlib import Path
reply=subprocess.run(['git','-c','credential.interactive=false','credential','fill'],input='protocol=https\nhost=github.com\n\n',text=True,capture_output=True,check=True).stdout
credential=dict(line.split('=',1) for line in reply.splitlines() if '=' in line)
class SafeRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):
  nxt=super().redirect_request(req,fp,code,msg,headers,newurl)
  if nxt is not None and urllib.parse.urlparse(req.full_url).netloc!=urllib.parse.urlparse(newurl).netloc:
   nxt.remove_header('Authorization');nxt.unredirected_hdrs.pop('Authorization',None)
  return nxt
request=urllib.request.Request('https://api.github.com/repos/DaveBeusing/Forgeline/actions/jobs/116907444148/logs',headers={'Authorization':'Bearer '+credential['password'],'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28'})
with urllib.request.build_opener(SafeRedirect()).open(request,timeout=60) as response: raw=response.read().decode('utf-8-sig')
Path('artifacts/interface-source-ci-job.log').write_text(raw,encoding='utf-8')
lines=raw.splitlines();indexes=[i for i,s in enumerate(lines) if ('texture' in s.lower() and ('budget' in s.lower() or 'exceed' in s.lower())) or '99608050' in s or '58720256' in s or '##[error]' in s]
keep=sorted(set(j for i in indexes for j in range(max(0,i-3),min(len(lines),i+5))))
excerpt='\n'.join(lines[i] for i in keep)+'\n';Path('artifacts/interface-source-ci-failure.log').write_text(excerpt,encoding='utf-8');print(excerpt[-6000:])

