from pathlib import Path
import json
A=Path('artifacts')
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
half=read(A/'interface-installed-half/manifest.json')
full=[]
for bank in (1,2): full+=read(A/f'interface-native-installed/dpi192-3840x2160-states{bank}-attempt1/manifest.json')['captures']
rows=[]
for c in half['captures']:
 p=next(x for x in full if x['key']==c['key'])
 assert all(c['actualSurface'][k]==p['actualSurface'][k] for k in ['width','height'])
 assert c['graphics']['postProcessing']['resolutionScale']==.5 and p['graphics']['postProcessing']['resolutionScale']==1
 for field in ['glyphs','vertices','missingGlyphs','droppedGlyphs','uploadBytes','atlasReady']:
  assert c['ui']['text'][field]==p['ui']['text'][field],(c['key'],field)
 for owner in ['skin','battlefieldSkin']:
  skin=c['ui'][owner]; previous=p['ui'][owner]
  assert (skin is None)==(previous is None)
  if skin is not None:
   for field in ['draws','vertices','vertexUploadBytes','residentPageBytes','pageBytes']:
    if field in skin: assert skin[field]==previous[field],(c['key'],owner,field)
 def bounds(x): return [{k:r[k] for k in ['name','x','y','width','height']} for r in x['ui']['regions']]
 assert bounds(c)==bounds(p)
 rows.append(dict(key=c['key'],nativeSurface=c['actualSurface'],halfPngSha256=c['imageSha256'],fullPngSha256=p['imageSha256'],
                  exactPixels=c['pixelSha256']==p['pixelSha256'],text=c['ui']['text'],skin=c['ui']['battlefieldSkin'],regions=bounds(c)))
result=dict(source=half['commit'],runtimeFingerprint=half['runtimeFingerprint'],status='native-output-and-ui-geometry-pass',
            limitation='Equal output, glyph/skin geometry and region bounds do not prove perceptual sharpness; transparent HUD regions contain differently resolved world pixels. Human review remains pending.',cases=rows)
(A/'interface-half-ui-comparison.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(cases=len(rows),exactPixels=sum(x['exactPixels'] for x in rows),geometry='pass')))
