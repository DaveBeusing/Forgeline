$ErrorActionPreference = 'Stop'
$source = (& git rev-parse HEAD).Trim()
if ($source -ne '0cb9b8089f84abfdce0e754e9176be5c4628c16b') { throw 'Qualification source changed.' }
dotnet restore ForgeLine.sln *> artifacts/tactical-final-restore.log
if ($LASTEXITCODE -ne 0) { throw 'Restore failed.' }
dotnet build ForgeLine.sln --configuration Release --no-restore *> artifacts/tactical-final-source-build.log
if ($LASTEXITCODE -ne 0) { throw 'Build failed.' }
./build/Validate-ProjectReferences.ps1 *> artifacts/tactical-final-references.log
./build/Validate-SemVer.ps1 -BaseRef origin/master *> artifacts/tactical-final-version.log
./build/Test-Versioning.ps1 *>> artifacts/tactical-final-version.log
./build/Test-VersionAllocation.ps1 *>> artifacts/tactical-final-version.log
dotnet run --project tools/ForgeLine.AssetCompiler/ForgeLine.AssetCompiler.csproj --configuration Release --no-build -- --mode validate --source assets/source --runtime assets/runtime --qualification-output artifacts/tactical-final-asset-qualification.json *> artifacts/tactical-final-assets.log
if ($LASTEXITCODE -ne 0) { throw 'Runtime asset validation failed.' }
dotnet test --project tests/ForgeLine.Platform.Windows.Tests/ForgeLine.Platform.Windows.Tests.csproj --configuration Release --no-build -- --filter-class '*WindowsCursorTests' *> artifacts/tactical-final-platform.log
if ($LASTEXITCODE -ne 0) { throw 'Native cursor contracts failed.' }
dotnet test --project tests/ForgeLine.Client.Tests/ForgeLine.Client.Tests.csproj --configuration Release --no-build -- --filter-class '*TacticalCursorTests' *> artifacts/tactical-final-cursors.log
if ($LASTEXITCODE -ne 0) { throw 'Runtime cursor contracts failed.' }
dotnet test --project tests/ForgeLine.Presentation.Tests/ForgeLine.Presentation.Tests.csproj --configuration Release --no-build -- --filter-class '*Rts*' '*SelectionMarkerTests' '*ContextCursorTests' '*TacticalTargeting*' '*BattlefieldProductionSkinTests' '*GameplayUiFixtureTests' '*TacticalArtworkTests' *> artifacts/tactical-final-contracts.log
if ($LASTEXITCODE -ne 0) { throw 'Tactical privacy and geometry contracts failed.' }
dotnet test --solution ForgeLine.sln --configuration Release --no-build --max-parallel-test-modules 1 *> artifacts/tactical-final-full-tests.log
if ($LASTEXITCODE -ne 0) { throw 'Full solution failed.' }
Write-Host 'Final-source regression complete.'
