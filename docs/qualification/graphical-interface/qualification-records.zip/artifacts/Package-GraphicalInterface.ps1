$ErrorActionPreference='Stop'
$packageRoot=[IO.Path]::GetFullPath('artifacts/graphical-interface-package',$PWD)
if(Test-Path -LiteralPath $packageRoot){throw 'Package root already exists.'}
if(-not $packageRoot.StartsWith([IO.Path]::GetFullPath('artifacts',$PWD)+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Package escaped artifact workspace.'}
./build/Publish-PreAlpha.ps1 -Configuration Release -VerifyReproducible -RuntimeAssetRoot assets/runtime -OutputRoot artifacts/graphical-interface-package *> artifacts/interface-package.log
if($LASTEXITCODE){throw 'Reproducible package failed.'}
$client=Join-Path $packageRoot 'win-x64/publish/ForgeLine.Client.exe'
$runtime=Join-Path $packageRoot 'win-x64/publish/assets/runtime'
./build/Invoke-StartupQualification.ps1 -ClientPath $client -OutputRoot artifacts/interface-packaged-startup -Samples 2 -RequireApplicationIcons *> artifacts/interface-packaged-startup.log
foreach($cycle in @(1,2)) {
    $settings=[IO.Path]::GetFullPath("artifacts/interface-package-fresh-$cycle",$PWD)
    if(Test-Path -LiteralPath $settings){throw 'Fresh settings root exists.'}
    & $client --smoke-test --render-stress 1000 --settings-root $settings --startup-diagnostics-output ([IO.Path]::GetFullPath("artifacts/interface-package-match-$cycle.json",$PWD)) | Out-File "artifacts/interface-package-match-$cycle.log" -Encoding utf8
    if($LASTEXITCODE){throw 'Packaged fresh match failed.'}
}
./build/Invoke-RtsReferenceQualification.ps1 -Capture -ClientPath $client -RuntimeAssetRoot $runtime -Scenes BattlefieldCombat -Profiles Medium -Zooms NormalGameplay -Displays 1920x1080 -RasterDpi 96 -UiScales 1 -UiScenarios @('Menu','SettingsAudio','ControlsLong','Operations','Contacts','ProductionQueue') -CinematicFrontend -Warmups 3 -Samples 8 -RepeatCaptures 2 -OutputRoot artifacts/interface-packaged-native *> artifacts/interface-packaged-native.log
dotnet run --project src/ForgeLine.Headless/ForgeLine.Headless.csproj --configuration Release --no-build -- --scenario central-divide --profile validation --ticks 80000 --seed 2026 --matches 1 --require-terminal --diagnostics-output artifacts/interface-terminal.json --telemetry-output artifacts/interface-terminal-telemetry.json *> artifacts/interface-terminal.log
if($LASTEXITCODE){throw 'Natural terminal gate failed.'}
dotnet run --project src/ForgeLine.Headless/ForgeLine.Headless.csproj --configuration Release --no-build -- --scenario central-divide --profile validation --ticks 256 --seed 4242 --save-output artifacts/interface-recovery.save.json --replay-output artifacts/interface-recovery.replay.json *> artifacts/interface-recovery-save.log
if($LASTEXITCODE){throw 'Recovery save failed.'}
dotnet run --project src/ForgeLine.Headless/ForgeLine.Headless.csproj --configuration Release --no-build -- --load-input artifacts/interface-recovery.save.json *> artifacts/interface-recovery-load.log
if($LASTEXITCODE){throw 'Recovery load failed.'}
dotnet run --project src/ForgeLine.Headless/ForgeLine.Headless.csproj --configuration Release --no-build -- --replay-input artifacts/interface-recovery.replay.json *> artifacts/interface-recovery-replay.log
if($LASTEXITCODE){throw 'Recovery replay failed.'}
Write-Host 'Package, independent fresh starts, native package frames, natural terminal and recovery completed.'
