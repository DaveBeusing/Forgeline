param([string]$RepositoryRoot)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
Set-Location -LiteralPath $RepositoryRoot
$root=Join-Path (Get-Location) 'artifacts/performance-integration/canonical'
[IO.Directory]::CreateDirectory($root) | Out-Null
function Step([string]$Name,[scriptblock]$Action) {
    $started=[DateTimeOffset]::UtcNow
    $timer=[Diagnostics.Stopwatch]::StartNew()
    $log=Join-Path $root ($Name+'.log')
    $status='passed';$message=$null;$code=0
    Write-Output "Starting canonical check: $Name"
    try {
        $global:LASTEXITCODE=0
        & $Action *> $log
        $code=$LASTEXITCODE
        if($code -ne 0){throw "Command exited $code"}
    } catch {$status='failed';$message=$_.Exception.Message}
    $record=[ordered]@{name=$Name;status=$status;exitCode=$code;startedUtc=$started;completedUtc=[DateTimeOffset]::UtcNow;seconds=$timer.Elapsed.TotalSeconds;log="artifacts/performance-integration/canonical/$Name.log";error=$message;source=(& git rev-parse HEAD).Trim()}
    ($record | ConvertTo-Json -Compress) | Add-Content -LiteralPath (Join-Path $root 'results.jsonl') -Encoding utf8
    Write-Output "Completed canonical check: $Name ($status)"
}
Step 'version' { ./build/Validate-SemVer.ps1 -BaseRef origin/master }
Step 'project-references' { ./build/Validate-ProjectReferences.ps1 }
Step 'central-divide-map' { dotnet run --project tools/ForgeLine.MapCompiler/ForgeLine.MapCompiler.csproj -c Release --no-build -- --output artifacts/maps/central-divide.flmap.json --qualification-output artifacts/map-qualification.json }
Step 'compiled-scenario-contracts' { ./build/Test-CompiledScenarioLoading.ps1 }
Step 'runtime-assets-clean-build' { ./build/Build-RuntimeAssets.ps1 -Mode build -ForceRebuild -NoBuild }
Step 'runtime-asset-process-contracts' { ./build/Test-RuntimeAssetPipeline.ps1 -OutputRoot artifacts/performance-integration/runtime-pipeline }
Step 'native-client-smoke' { dotnet run --project src/ForgeLine.Client/ForgeLine.Client.csproj -c Release --no-build -- --smoke-test --render-stress 1000 --settings-root artifacts/performance-integration/smoke-settings }
Step 'headless-smoke' { dotnet run --project src/ForgeLine.Headless/ForgeLine.Headless.csproj -c Release --no-build -- --ticks 64 --seed 12345 --tick-rate 20 --entities 1000 --diagnostics-output artifacts/performance-integration/headless-smoke.json }
Step 'headless-stress' { dotnet run --project src/ForgeLine.Headless/ForgeLine.Headless.csproj -c Release --no-build -- --ticks 16 --seed 67890 --tick-rate 20 --entities 10000 --diagnostics-output artifacts/performance-integration/headless-stress.json }
Step 'solution-tests' { dotnet test --solution ForgeLine.sln -c Release --no-build }
Step 'reproducible-local-package' { ./build/Publish-PreAlpha.ps1 -Configuration Release -VerifyReproducible -RuntimeAssetRoot assets/runtime -OutputRoot artifacts/performance-integration/package }
Step 'natural-terminal-match' { dotnet run --project src/ForgeLine.Headless/ForgeLine.Headless.csproj -c Release --no-build -- --scenario central-divide --profile validation --ticks 80000 --seed 2026 --require-terminal --diagnostics-output artifacts/performance-integration/match.json }
Step 'focused-graphics-lifetime' { dotnet test --project tests/ForgeLine.Graphics.Tests/ForgeLine.Graphics.Tests.csproj -c Release --no-build -- --filter-class '*ResourceScheduling*' '*GraphicsSurfaceLifecycleStateTests*' '*D3D12ParticleTests*' }
Step 'focused-correspondence-submission' { dotnet test --project tests/ForgeLine.Presentation.Tests/ForgeLine.Presentation.Tests.csproj -c Release --no-build -- --filter-class '*SnapshotPublication*' '*RenderSubmission*' '*BattlefieldStatusNativeTests*' }
Step 'focused-host-collector' { dotnet test --project tests/ForgeLine.Client.Tests/ForgeLine.Client.Tests.csproj -c Release --no-build -- --filter-class '*ReferencePerformanceSamplesTests*' '*ReferenceSnapshotHistoryTests*' '*RenderQualification*' '*ClientRenderCompositionTests*' '*ClientWorldPassSequenceTests*' }
Step 'reference-contract-scripts' { ./build/Test-ReferencePerformance.ps1 }
Write-Output 'Canonical sequence and independent remaining gates recorded.'
