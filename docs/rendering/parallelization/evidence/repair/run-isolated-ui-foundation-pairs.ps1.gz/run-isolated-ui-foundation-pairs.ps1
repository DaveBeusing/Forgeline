$ErrorActionPreference = 'Stop'
$repository = (Get-Location).Path
$drivers = @(Get-CimInstance Win32_VideoController | ForEach-Object { "$($_.Name): $($_.DriverVersion)" }) -join '; '
$beforeClient = Join-Path $repository 'artifacts/foundation-ui-baseline/bin/ForgeLine.Client/release_win-x64/ForgeLine.Client.exe'
$afterClient = Join-Path $repository 'artifacts/foundation-ui-current/bin/ForgeLine.Client/release_win-x64/ForgeLine.Client.exe'
$beforeSha = 'eee4b603d9443b244ac7dc331577ea28b96440d0'
$afterSha = '25f4060746e89e582f339e29b840175701f8e5c8'
function Capture-Matrix([string]$Name,[string]$Client,[string]$Sha) {
    $request = Get-Content artifacts/render-foundation-before.request.json -Raw | ConvertFrom-Json
    $request.outputRoot = Join-Path $repository "artifacts/$Name"
    if (Test-Path -LiteralPath $request.outputRoot) { throw 'Evidence exists' }
    $request.commit=$Sha; $request.warmups=128; $request.samples=512; $request.repeatCaptures=2; $request.driver=$drivers
    $requestPath=$request.outputRoot+'.request.json'
    $request | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $requestPath -Encoding utf8
    & nvidia-smi --query-gpu=timestamp,pstate,clocks.gr,power.draw,power.limit --format=csv | Add-Content artifacts/foundation-isolated-ui-gpu.csv
    $foreign = @(Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('ForgeLine.Client.exe','ForgeLine.Headless.exe') -or ($_.Name -eq 'dotnet.exe' -and $_.CommandLine -match 'test |ForgeLine.Headless|Observer.dll') })
    if ($foreign.Count) { throw 'Quiet window unavailable before capture' }
    $native = Start-Process -FilePath $Client -ArgumentList @('--reference-capture-request',$requestPath) -WindowStyle Hidden -PassThru -RedirectStandardOutput "artifacts/$Name.log" -RedirectStandardError "artifacts/$Name.stderr.log"
    $overlap = $false
    do {
        $busy = @(Get-CimInstance Win32_Process | Where-Object { ($_.Name -in @('ForgeLine.Client.exe','ForgeLine.Headless.exe') -and $_.ProcessId -ne $native.Id) -or ($_.Name -eq 'dotnet.exe' -and $_.CommandLine -match 'test |ForgeLine.Headless|Observer.dll') })
        [pscustomobject]@{timestamp=(Get-Date).ToString('o');capture=$Name;ownProcessId=$native.Id;foreign=@($busy | Select-Object ProcessId,Name,CreationDate)} | ConvertTo-Json -Depth 5 -Compress | Add-Content 'artifacts/foundation-isolated-ui-process-monitor.jsonl'
        if ($busy.Count) { $overlap = $true }
        Start-Sleep -Seconds 2
        $native.Refresh()
    } while (!$native.HasExited)
    $native.WaitForExit()
    if ($native.ExitCode -ne 0) { throw "Native matrix failed: $Name exit $($native.ExitCode)" }
    if ($overlap) { throw 'Foreign workload detected; preserve completed capture and reject protocol' }
    & nvidia-smi --query-gpu=timestamp,pstate,clocks.gr,power.draw,power.limit --format=csv | Add-Content artifacts/foundation-isolated-ui-gpu.csv
    Write-Output "Finished $Name"
}
Write-Output 'Waiting for all other native clients, tests and headless work to finish before timing.'
do {
    $busy = @(Get-CimInstance Win32_Process | Where-Object {
        $_.Name -in @('ForgeLine.Headless.exe','ForgeLine.Client.exe') -or
        ($_.Name -eq 'dotnet.exe' -and $_.CommandLine -match 'test |ForgeLine.Headless|foundation-timeline-observer.*Observer.dll')
    })
    if ($busy.Count -gt 0) { Start-Sleep -Seconds 15 }
} while ($busy.Count -gt 0)
if (!(Test-Path -LiteralPath $beforeClient) -or !(Test-Path -LiteralPath $afterClient)) { throw 'Missing paired client' }
Write-Output 'Starting the fixed isolated fixture-6 protocol with foreign-workload monitoring.'
Capture-Matrix 'foundation-isolated-ui-pair1-before' $beforeClient $beforeSha
Capture-Matrix 'foundation-isolated-ui-pair1-after' $afterClient $afterSha
Capture-Matrix 'foundation-isolated-ui-pair2-after' $afterClient $afterSha
Capture-Matrix 'foundation-isolated-ui-pair2-before' $beforeClient $beforeSha
$failed=$false
foreach ($cohort in 1,2) {
    try {
        & ./build/Compare-ReferencePerformance.ps1 -CurrentRoot "artifacts/foundation-isolated-ui-pair$cohort-after" -BaselineRoot "artifacts/foundation-isolated-ui-pair$cohort-before" -ReportPath "artifacts/foundation-isolated-ui-pair$cohort-performance.json" -GatePerformance
    } catch { $failed=$true; Write-Output $_.Exception.Message }
    & ./build/Compare-VisualReferenceEvidence.ps1 -CurrentRoot "artifacts/foundation-isolated-ui-pair$cohort-after" -BaselineRoot "artifacts/foundation-isolated-ui-pair$cohort-before"
    if ($LASTEXITCODE -ne 0) { throw 'Pixel comparison failed' }
}
if ($failed) { throw 'Paired performance gate failed; retained both complete cohorts.' }





