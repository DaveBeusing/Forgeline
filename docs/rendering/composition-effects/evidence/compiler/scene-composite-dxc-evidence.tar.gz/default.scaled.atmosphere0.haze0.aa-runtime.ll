;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xy  
; TEXCOORD                 1   xyzw        2     NONE   float       
; TEXCOORD                 2   xyzw        3     NONE   float       
; TEXCOORD                 3   xyzw        4     NONE   float       
; TEXCOORD                 4   xyzw        5     NONE   float       
; TEXCOORD                 5   xyzw        6     NONE   float       
; TEXCOORD                 6   xyzw        7     NONE   float       
; TEXCOORD                 7   xyzw        8     NONE   float       
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float   xyz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: 6aa4793da379f58e5de8312b8a3c73ac
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 40, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 40, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 40, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %15 = extractvalue %dx.types.Dimensions %14, 0
  %16 = extractvalue %dx.types.Dimensions %14, 1
  %17 = uitofp i32 %15 to float
  %18 = uitofp i32 %16 to float
  %19 = fmul fast float %17, %12
  %20 = fmul fast float %18, %13
  %21 = fdiv fast float %19, %4
  %22 = fdiv fast float %20, %5
  %23 = fadd fast float %21, -5.000000e-01
  %24 = fadd fast float %22, -5.000000e-01
  %25 = call float @dx.op.unary.f32(i32 27, float %23)  ; Round_ni(value)
  %26 = call float @dx.op.unary.f32(i32 27, float %24)  ; Round_ni(value)
  %27 = fptosi float %25 to i32
  %28 = fptosi float %26 to i32
  %29 = call float @dx.op.unary.f32(i32 22, float %23)  ; Frc(value)
  %30 = call float @dx.op.unary.f32(i32 22, float %24)  ; Frc(value)
  %31 = add i32 %15, -1
  %32 = add i32 %16, -1
  %33 = call i32 @dx.op.binary.i32(i32 37, i32 %27, i32 0)  ; IMax(a,b)
  %34 = call i32 @dx.op.binary.i32(i32 37, i32 %28, i32 0)  ; IMax(a,b)
  %35 = call i32 @dx.op.binary.i32(i32 38, i32 %33, i32 %31)  ; IMin(a,b)
  %36 = call i32 @dx.op.binary.i32(i32 38, i32 %34, i32 %32)  ; IMin(a,b)
  %37 = add i32 %27, 1
  %38 = call i32 @dx.op.binary.i32(i32 37, i32 %37, i32 0)  ; IMax(a,b)
  %39 = call i32 @dx.op.binary.i32(i32 38, i32 %38, i32 %31)  ; IMin(a,b)
  %40 = add i32 %28, 1
  %41 = call i32 @dx.op.binary.i32(i32 37, i32 %40, i32 0)  ; IMax(a,b)
  %42 = call i32 @dx.op.binary.i32(i32 38, i32 %41, i32 %32)  ; IMin(a,b)
  %43 = call float @dx.op.unary.f32(i32 27, float %21)  ; Round_ni(value)
  %44 = call float @dx.op.unary.f32(i32 27, float %22)  ; Round_ni(value)
  %45 = fptosi float %43 to i32
  %46 = fptosi float %44 to i32
  %47 = call i32 @dx.op.binary.i32(i32 37, i32 %45, i32 0)  ; IMax(a,b)
  %48 = call i32 @dx.op.binary.i32(i32 37, i32 %46, i32 0)  ; IMax(a,b)
  %49 = call i32 @dx.op.binary.i32(i32 38, i32 %47, i32 %31)  ; IMin(a,b)
  %50 = call i32 @dx.op.binary.i32(i32 38, i32 %48, i32 %32)  ; IMin(a,b)
  %51 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %49, i32 %50, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %52 = extractvalue %dx.types.ResRet.f32 %51, 0
  %53 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %35, i32 %36, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %54 = extractvalue %dx.types.ResRet.f32 %53, 0
  %55 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %39, i32 %36, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %56 = extractvalue %dx.types.ResRet.f32 %55, 0
  %57 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %35, i32 %42, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %58 = extractvalue %dx.types.ResRet.f32 %57, 0
  %59 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %39, i32 %42, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %60 = extractvalue %dx.types.ResRet.f32 %59, 0
  %61 = fsub fast float 1.000000e+00, %29
  %62 = fsub fast float 1.000000e+00, %30
  %63 = fmul fast float %62, %61
  %64 = fmul fast float %62, %29
  %65 = fmul fast float %61, %30
  %66 = fmul fast float %30, %29
  %67 = fsub fast float 1.000000e+00, %52
  %68 = fmul fast float %67, 0x3FA99999A0000000
  %69 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %68)  ; FMax(a,b)
  %70 = fsub fast float %54, %52
  %71 = call float @dx.op.unary.f32(i32 6, float %70)  ; FAbs(value)
  %72 = fdiv fast float %71, %69
  %73 = fsub fast float 1.000000e+00, %72
  %74 = call float @dx.op.unary.f32(i32 7, float %73)  ; Saturate(value)
  %75 = fsub fast float %56, %52
  %76 = call float @dx.op.unary.f32(i32 6, float %75)  ; FAbs(value)
  %77 = fdiv fast float %76, %69
  %78 = fsub fast float 1.000000e+00, %77
  %79 = call float @dx.op.unary.f32(i32 7, float %78)  ; Saturate(value)
  %80 = fsub fast float %58, %52
  %81 = call float @dx.op.unary.f32(i32 6, float %80)  ; FAbs(value)
  %82 = fdiv fast float %81, %69
  %83 = fsub fast float 1.000000e+00, %82
  %84 = call float @dx.op.unary.f32(i32 7, float %83)  ; Saturate(value)
  %85 = fsub fast float %60, %52
  %86 = call float @dx.op.unary.f32(i32 6, float %85)  ; FAbs(value)
  %87 = fdiv fast float %86, %69
  %88 = fsub fast float 1.000000e+00, %87
  %89 = call float @dx.op.unary.f32(i32 7, float %88)  ; Saturate(value)
  %90 = fmul fast float %63, %74
  %91 = fmul fast float %64, %79
  %92 = fmul fast float %65, %84
  %93 = fmul fast float %66, %89
  %94 = fcmp fast oge float %29, 5.000000e-01
  %95 = zext i1 %94 to i32
  %96 = fcmp fast oge float %30, 5.000000e-01
  %97 = select i1 %96, i32 2, i32 0
  %98 = or i32 %97, %95
  %99 = call float @dx.op.dot4.f32(i32 56, float %90, float %91, float %92, float %93, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %100 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %90)  ; IsFinite(value)
  %101 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %91)  ; IsFinite(value)
  %102 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %92)  ; IsFinite(value)
  %103 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %93)  ; IsFinite(value)
  %104 = and i1 %100, %101
  %105 = and i1 %104, %102
  %106 = and i1 %105, %103
  br i1 %106, label %107, label %124

; <label>:107                                     ; preds = %0
  %108 = fcmp fast oge float %90, 0.000000e+00
  %109 = fcmp fast oge float %91, 0.000000e+00
  %110 = fcmp fast oge float %92, 0.000000e+00
  %111 = fcmp fast oge float %93, 0.000000e+00
  %112 = and i1 %108, %109
  %113 = and i1 %112, %110
  %114 = and i1 %113, %111
  br i1 %114, label %115, label %124

; <label>:115                                     ; preds = %107
  %116 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %99)  ; IsFinite(value)
  %117 = fcmp fast oge float %99, 0x3810000000000000
  %118 = and i1 %117, %116
  br i1 %118, label %119, label %124

; <label>:119                                     ; preds = %115
  %120 = fdiv fast float %90, %99
  %121 = fdiv fast float %91, %99
  %122 = fdiv fast float %92, %99
  %123 = fdiv fast float %93, %99
  br label %133

; <label>:124                                     ; preds = %115, %107, %0
  %125 = icmp eq i32 %98, 0
  %126 = uitofp i1 %125 to float
  %127 = icmp eq i32 %98, 1
  %128 = uitofp i1 %127 to float
  %129 = icmp eq i32 %98, 2
  %130 = uitofp i1 %129 to float
  %131 = icmp eq i32 %98, 3
  %132 = uitofp i1 %131 to float
  br label %133

; <label>:133                                     ; preds = %124, %119
  %134 = phi float [ %120, %119 ], [ %126, %124 ]
  %135 = phi float [ %121, %119 ], [ %128, %124 ]
  %136 = phi float [ %122, %119 ], [ %130, %124 ]
  %137 = phi float [ %123, %119 ], [ %132, %124 ]
  %138 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %35, i32 %36, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %139 = extractvalue %dx.types.ResRet.f32 %138, 0
  %140 = extractvalue %dx.types.ResRet.f32 %138, 1
  %141 = extractvalue %dx.types.ResRet.f32 %138, 2
  %142 = extractvalue %dx.types.ResRet.f32 %138, 3
  %143 = fcmp fast olt float %142, 0.000000e+00
  br i1 %143, label %144, label %146

; <label>:144                                     ; preds = %133
  %145 = fsub fast float -1.000000e+00, %142
  br label %926

; <label>:146                                     ; preds = %133
  %147 = fadd fast float %6, 1.000000e+00
  %148 = fadd fast float %7, 1.000000e+00
  %149 = fsub fast float 1.000000e+00, %6
  %150 = fmul fast float %10, %147
  %151 = fmul fast float %10, %148
  %152 = fmul fast float %10, %149
  %153 = fmul fast float %150, %139
  %154 = fmul fast float %151, %140
  %155 = fmul fast float %152, %141
  %156 = fcmp fast ult float %11, 5.000000e-01
  br i1 %156, label %182, label %157

; <label>:157                                     ; preds = %146
  %158 = fmul fast float %153, 0x4004147AE0000000
  %159 = fmul fast float %154, 0x4004147AE0000000
  %160 = fmul fast float %155, 0x4004147AE0000000
  %161 = fadd fast float %158, 0x3F9EB851E0000000
  %162 = fadd fast float %159, 0x3F9EB851E0000000
  %163 = fadd fast float %160, 0x3F9EB851E0000000
  %164 = fmul fast float %161, %153
  %165 = fmul fast float %162, %154
  %166 = fmul fast float %163, %155
  %167 = fmul fast float %153, 0x400370A3E0000000
  %168 = fmul fast float %154, 0x400370A3E0000000
  %169 = fmul fast float %155, 0x400370A3E0000000
  %170 = fadd fast float %167, 0x3FE2E147A0000000
  %171 = fadd fast float %168, 0x3FE2E147A0000000
  %172 = fadd fast float %169, 0x3FE2E147A0000000
  %173 = fmul fast float %170, %153
  %174 = fmul fast float %171, %154
  %175 = fmul fast float %172, %155
  %176 = fadd fast float %173, 0x3FC1EB8520000000
  %177 = fadd fast float %174, 0x3FC1EB8520000000
  %178 = fadd fast float %175, 0x3FC1EB8520000000
  %179 = fdiv fast float %164, %176
  %180 = fdiv fast float %165, %177
  %181 = fdiv fast float %166, %178
  br label %182

; <label>:182                                     ; preds = %157, %146
  %183 = phi float [ %179, %157 ], [ %153, %146 ]
  %184 = phi float [ %180, %157 ], [ %154, %146 ]
  %185 = phi float [ %181, %157 ], [ %155, %146 ]
  %186 = call float @dx.op.unary.f32(i32 7, float %183)  ; Saturate(value)
  %187 = call float @dx.op.unary.f32(i32 7, float %184)  ; Saturate(value)
  %188 = call float @dx.op.unary.f32(i32 7, float %185)  ; Saturate(value)
  %189 = call float @dx.op.dot3.f32(i32 55, float %186, float %187, float %188, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %190 = fsub fast float %186, %189
  %191 = fsub fast float %187, %189
  %192 = fsub fast float %188, %189
  %193 = fmul fast float %190, %9
  %194 = fmul fast float %191, %9
  %195 = fmul fast float %192, %9
  %196 = fadd fast float %193, %189
  %197 = fadd fast float %194, %189
  %198 = fadd fast float %195, %189
  %199 = call float @dx.op.unary.f32(i32 7, float %196)  ; Saturate(value)
  %200 = call float @dx.op.unary.f32(i32 7, float %197)  ; Saturate(value)
  %201 = call float @dx.op.unary.f32(i32 7, float %198)  ; Saturate(value)
  %202 = fadd fast float %199, 0xBFC70A3D80000000
  %203 = fadd fast float %200, 0xBFC70A3D80000000
  %204 = fadd fast float %201, 0xBFC70A3D80000000
  %205 = fmul fast float %202, %8
  %206 = fmul fast float %203, %8
  %207 = fmul fast float %204, %8
  %208 = fadd fast float %205, 0x3FC70A3D80000000
  %209 = fadd fast float %206, 0x3FC70A3D80000000
  %210 = fadd fast float %207, 0x3FC70A3D80000000
  %211 = call float @dx.op.unary.f32(i32 7, float %208)  ; Saturate(value)
  %212 = call float @dx.op.unary.f32(i32 7, float %209)  ; Saturate(value)
  %213 = call float @dx.op.unary.f32(i32 7, float %210)  ; Saturate(value)
  %214 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %214, label %215, label %886

; <label>:215                                     ; preds = %182
  %216 = add i32 %36, -1
  %217 = call i32 @dx.op.binary.i32(i32 37, i32 %35, i32 0)  ; IMax(a,b)
  %218 = call i32 @dx.op.binary.i32(i32 37, i32 %216, i32 0)  ; IMax(a,b)
  %219 = call i32 @dx.op.binary.i32(i32 38, i32 %217, i32 %31)  ; IMin(a,b)
  %220 = call i32 @dx.op.binary.i32(i32 38, i32 %218, i32 %32)  ; IMin(a,b)
  %221 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %219, i32 %220, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %222 = extractvalue %dx.types.ResRet.f32 %221, 0
  %223 = fsub fast float 1.000000e+00, %54
  %224 = fmul fast float %223, 0x3FA99999A0000000
  %225 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %224)  ; FMax(a,b)
  %226 = fsub fast float %222, %54
  %227 = call float @dx.op.unary.f32(i32 6, float %226)  ; FAbs(value)
  %228 = fdiv fast float %227, %225
  %229 = fsub fast float 1.000000e+00, %228
  %230 = call float @dx.op.unary.f32(i32 7, float %229)  ; Saturate(value)
  %231 = fcmp fast ugt float %230, 0.000000e+00
  br i1 %231, label %232, label %358

; <label>:232                                     ; preds = %215
  %233 = call i32 @dx.op.binary.i32(i32 37, i32 %219, i32 0)  ; IMax(a,b)
  %234 = call i32 @dx.op.binary.i32(i32 37, i32 %220, i32 0)  ; IMax(a,b)
  %235 = call i32 @dx.op.binary.i32(i32 38, i32 %233, i32 %31)  ; IMin(a,b)
  %236 = call i32 @dx.op.binary.i32(i32 38, i32 %234, i32 %32)  ; IMin(a,b)
  %237 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %235, i32 %236, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %238 = extractvalue %dx.types.ResRet.f32 %237, 0
  %239 = extractvalue %dx.types.ResRet.f32 %237, 1
  %240 = extractvalue %dx.types.ResRet.f32 %237, 2
  %241 = extractvalue %dx.types.ResRet.f32 %237, 3
  %242 = fcmp fast olt float %241, 0.000000e+00
  br i1 %242, label %243, label %277

; <label>:243                                     ; preds = %232
  %244 = fcmp fast ogt float %238, 0x3FA4B5DCC0000000
  %245 = fcmp fast ogt float %239, 0x3FA4B5DCC0000000
  %246 = fcmp fast ogt float %240, 0x3FA4B5DCC0000000
  %247 = select i1 %244, float 0.000000e+00, float 1.000000e+00
  %248 = select i1 %245, float 0.000000e+00, float 1.000000e+00
  %249 = select i1 %246, float 0.000000e+00, float 1.000000e+00
  %250 = fmul fast float %238, 0x3FB3D07220000000
  %251 = fmul fast float %239, 0x3FB3D07220000000
  %252 = fmul fast float %240, 0x3FB3D07220000000
  %253 = fadd fast float %238, 0x3FAC28F5C0000000
  %254 = fadd fast float %239, 0x3FAC28F5C0000000
  %255 = fadd fast float %240, 0x3FAC28F5C0000000
  %256 = fmul fast float %253, 0x3FEE54EDE0000000
  %257 = fmul fast float %254, 0x3FEE54EDE0000000
  %258 = fmul fast float %255, 0x3FEE54EDE0000000
  %259 = call float @dx.op.unary.f32(i32 23, float %256)  ; Log(value)
  %260 = call float @dx.op.unary.f32(i32 23, float %257)  ; Log(value)
  %261 = call float @dx.op.unary.f32(i32 23, float %258)  ; Log(value)
  %262 = fmul fast float %259, 0x4003333340000000
  %263 = fmul fast float %260, 0x4003333340000000
  %264 = fmul fast float %261, 0x4003333340000000
  %265 = call float @dx.op.unary.f32(i32 21, float %262)  ; Exp(value)
  %266 = call float @dx.op.unary.f32(i32 21, float %263)  ; Exp(value)
  %267 = call float @dx.op.unary.f32(i32 21, float %264)  ; Exp(value)
  %268 = fsub fast float %250, %265
  %269 = fsub fast float %251, %266
  %270 = fsub fast float %252, %267
  %271 = fmul fast float %268, %247
  %272 = fmul fast float %269, %248
  %273 = fmul fast float %270, %249
  %274 = fadd fast float %271, %265
  %275 = fadd fast float %272, %266
  %276 = fadd fast float %273, %267
  br label %345

; <label>:277                                     ; preds = %232
  %278 = fadd fast float %6, 1.000000e+00
  %279 = fadd fast float %7, 1.000000e+00
  %280 = fsub fast float 1.000000e+00, %6
  %281 = fmul fast float %10, %278
  %282 = fmul fast float %10, %279
  %283 = fmul fast float %10, %280
  %284 = fmul fast float %281, %238
  %285 = fmul fast float %282, %239
  %286 = fmul fast float %283, %240
  %287 = fcmp fast ult float %11, 5.000000e-01
  br i1 %287, label %313, label %288

; <label>:288                                     ; preds = %277
  %289 = fmul fast float %284, 0x4004147AE0000000
  %290 = fmul fast float %285, 0x4004147AE0000000
  %291 = fmul fast float %286, 0x4004147AE0000000
  %292 = fadd fast float %289, 0x3F9EB851E0000000
  %293 = fadd fast float %290, 0x3F9EB851E0000000
  %294 = fadd fast float %291, 0x3F9EB851E0000000
  %295 = fmul fast float %292, %284
  %296 = fmul fast float %293, %285
  %297 = fmul fast float %294, %286
  %298 = fmul fast float %284, 0x400370A3E0000000
  %299 = fmul fast float %285, 0x400370A3E0000000
  %300 = fmul fast float %286, 0x400370A3E0000000
  %301 = fadd fast float %298, 0x3FE2E147A0000000
  %302 = fadd fast float %299, 0x3FE2E147A0000000
  %303 = fadd fast float %300, 0x3FE2E147A0000000
  %304 = fmul fast float %301, %284
  %305 = fmul fast float %302, %285
  %306 = fmul fast float %303, %286
  %307 = fadd fast float %304, 0x3FC1EB8520000000
  %308 = fadd fast float %305, 0x3FC1EB8520000000
  %309 = fadd fast float %306, 0x3FC1EB8520000000
  %310 = fdiv fast float %295, %307
  %311 = fdiv fast float %296, %308
  %312 = fdiv fast float %297, %309
  br label %313

; <label>:313                                     ; preds = %288, %277
  %314 = phi float [ %310, %288 ], [ %284, %277 ]
  %315 = phi float [ %311, %288 ], [ %285, %277 ]
  %316 = phi float [ %312, %288 ], [ %286, %277 ]
  %317 = call float @dx.op.unary.f32(i32 7, float %314)  ; Saturate(value)
  %318 = call float @dx.op.unary.f32(i32 7, float %315)  ; Saturate(value)
  %319 = call float @dx.op.unary.f32(i32 7, float %316)  ; Saturate(value)
  %320 = call float @dx.op.dot3.f32(i32 55, float %317, float %318, float %319, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %321 = fsub fast float %317, %320
  %322 = fsub fast float %318, %320
  %323 = fsub fast float %319, %320
  %324 = fmul fast float %321, %9
  %325 = fmul fast float %322, %9
  %326 = fmul fast float %323, %9
  %327 = fadd fast float %324, %320
  %328 = fadd fast float %325, %320
  %329 = fadd fast float %326, %320
  %330 = call float @dx.op.unary.f32(i32 7, float %327)  ; Saturate(value)
  %331 = call float @dx.op.unary.f32(i32 7, float %328)  ; Saturate(value)
  %332 = call float @dx.op.unary.f32(i32 7, float %329)  ; Saturate(value)
  %333 = fadd fast float %330, 0xBFC70A3D80000000
  %334 = fadd fast float %331, 0xBFC70A3D80000000
  %335 = fadd fast float %332, 0xBFC70A3D80000000
  %336 = fmul fast float %333, %8
  %337 = fmul fast float %334, %8
  %338 = fmul fast float %335, %8
  %339 = fadd fast float %336, 0x3FC70A3D80000000
  %340 = fadd fast float %337, 0x3FC70A3D80000000
  %341 = fadd fast float %338, 0x3FC70A3D80000000
  %342 = call float @dx.op.unary.f32(i32 7, float %339)  ; Saturate(value)
  %343 = call float @dx.op.unary.f32(i32 7, float %340)  ; Saturate(value)
  %344 = call float @dx.op.unary.f32(i32 7, float %341)  ; Saturate(value)
  br label %345

; <label>:345                                     ; preds = %313, %243
  %346 = phi float [ %274, %243 ], [ %342, %313 ]
  %347 = phi float [ %275, %243 ], [ %343, %313 ]
  %348 = phi float [ %276, %243 ], [ %344, %313 ]
  %349 = fsub fast float %346, %211
  %350 = fsub fast float %347, %212
  %351 = fsub fast float %348, %213
  %352 = fmul fast float %349, %230
  %353 = fmul fast float %350, %230
  %354 = fmul fast float %351, %230
  %355 = fadd fast float %352, %211
  %356 = fadd fast float %353, %212
  %357 = fadd fast float %354, %213
  br label %358

; <label>:358                                     ; preds = %345, %215
  %359 = phi float [ %355, %345 ], [ %211, %215 ]
  %360 = phi float [ %356, %345 ], [ %212, %215 ]
  %361 = phi float [ %357, %345 ], [ %213, %215 ]
  %362 = add i32 %36, 1
  %363 = call i32 @dx.op.binary.i32(i32 37, i32 %362, i32 0)  ; IMax(a,b)
  %364 = call i32 @dx.op.binary.i32(i32 38, i32 %363, i32 %32)  ; IMin(a,b)
  %365 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %219, i32 %364, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %366 = extractvalue %dx.types.ResRet.f32 %365, 0
  %367 = fsub fast float %366, %54
  %368 = call float @dx.op.unary.f32(i32 6, float %367)  ; FAbs(value)
  %369 = fdiv fast float %368, %225
  %370 = fsub fast float 1.000000e+00, %369
  %371 = call float @dx.op.unary.f32(i32 7, float %370)  ; Saturate(value)
  %372 = fcmp fast ugt float %371, 0.000000e+00
  br i1 %372, label %373, label %499

; <label>:373                                     ; preds = %358
  %374 = call i32 @dx.op.binary.i32(i32 37, i32 %219, i32 0)  ; IMax(a,b)
  %375 = call i32 @dx.op.binary.i32(i32 37, i32 %364, i32 0)  ; IMax(a,b)
  %376 = call i32 @dx.op.binary.i32(i32 38, i32 %374, i32 %31)  ; IMin(a,b)
  %377 = call i32 @dx.op.binary.i32(i32 38, i32 %375, i32 %32)  ; IMin(a,b)
  %378 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %376, i32 %377, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %379 = extractvalue %dx.types.ResRet.f32 %378, 0
  %380 = extractvalue %dx.types.ResRet.f32 %378, 1
  %381 = extractvalue %dx.types.ResRet.f32 %378, 2
  %382 = extractvalue %dx.types.ResRet.f32 %378, 3
  %383 = fcmp fast olt float %382, 0.000000e+00
  br i1 %383, label %384, label %418

; <label>:384                                     ; preds = %373
  %385 = fcmp fast ogt float %379, 0x3FA4B5DCC0000000
  %386 = fcmp fast ogt float %380, 0x3FA4B5DCC0000000
  %387 = fcmp fast ogt float %381, 0x3FA4B5DCC0000000
  %388 = select i1 %385, float 0.000000e+00, float 1.000000e+00
  %389 = select i1 %386, float 0.000000e+00, float 1.000000e+00
  %390 = select i1 %387, float 0.000000e+00, float 1.000000e+00
  %391 = fmul fast float %379, 0x3FB3D07220000000
  %392 = fmul fast float %380, 0x3FB3D07220000000
  %393 = fmul fast float %381, 0x3FB3D07220000000
  %394 = fadd fast float %379, 0x3FAC28F5C0000000
  %395 = fadd fast float %380, 0x3FAC28F5C0000000
  %396 = fadd fast float %381, 0x3FAC28F5C0000000
  %397 = fmul fast float %394, 0x3FEE54EDE0000000
  %398 = fmul fast float %395, 0x3FEE54EDE0000000
  %399 = fmul fast float %396, 0x3FEE54EDE0000000
  %400 = call float @dx.op.unary.f32(i32 23, float %397)  ; Log(value)
  %401 = call float @dx.op.unary.f32(i32 23, float %398)  ; Log(value)
  %402 = call float @dx.op.unary.f32(i32 23, float %399)  ; Log(value)
  %403 = fmul fast float %400, 0x4003333340000000
  %404 = fmul fast float %401, 0x4003333340000000
  %405 = fmul fast float %402, 0x4003333340000000
  %406 = call float @dx.op.unary.f32(i32 21, float %403)  ; Exp(value)
  %407 = call float @dx.op.unary.f32(i32 21, float %404)  ; Exp(value)
  %408 = call float @dx.op.unary.f32(i32 21, float %405)  ; Exp(value)
  %409 = fsub fast float %391, %406
  %410 = fsub fast float %392, %407
  %411 = fsub fast float %393, %408
  %412 = fmul fast float %409, %388
  %413 = fmul fast float %410, %389
  %414 = fmul fast float %411, %390
  %415 = fadd fast float %412, %406
  %416 = fadd fast float %413, %407
  %417 = fadd fast float %414, %408
  br label %486

; <label>:418                                     ; preds = %373
  %419 = fadd fast float %6, 1.000000e+00
  %420 = fadd fast float %7, 1.000000e+00
  %421 = fsub fast float 1.000000e+00, %6
  %422 = fmul fast float %10, %419
  %423 = fmul fast float %10, %420
  %424 = fmul fast float %10, %421
  %425 = fmul fast float %422, %379
  %426 = fmul fast float %423, %380
  %427 = fmul fast float %424, %381
  %428 = fcmp fast ult float %11, 5.000000e-01
  br i1 %428, label %454, label %429

; <label>:429                                     ; preds = %418
  %430 = fmul fast float %425, 0x4004147AE0000000
  %431 = fmul fast float %426, 0x4004147AE0000000
  %432 = fmul fast float %427, 0x4004147AE0000000
  %433 = fadd fast float %430, 0x3F9EB851E0000000
  %434 = fadd fast float %431, 0x3F9EB851E0000000
  %435 = fadd fast float %432, 0x3F9EB851E0000000
  %436 = fmul fast float %433, %425
  %437 = fmul fast float %434, %426
  %438 = fmul fast float %435, %427
  %439 = fmul fast float %425, 0x400370A3E0000000
  %440 = fmul fast float %426, 0x400370A3E0000000
  %441 = fmul fast float %427, 0x400370A3E0000000
  %442 = fadd fast float %439, 0x3FE2E147A0000000
  %443 = fadd fast float %440, 0x3FE2E147A0000000
  %444 = fadd fast float %441, 0x3FE2E147A0000000
  %445 = fmul fast float %442, %425
  %446 = fmul fast float %443, %426
  %447 = fmul fast float %444, %427
  %448 = fadd fast float %445, 0x3FC1EB8520000000
  %449 = fadd fast float %446, 0x3FC1EB8520000000
  %450 = fadd fast float %447, 0x3FC1EB8520000000
  %451 = fdiv fast float %436, %448
  %452 = fdiv fast float %437, %449
  %453 = fdiv fast float %438, %450
  br label %454

; <label>:454                                     ; preds = %429, %418
  %455 = phi float [ %451, %429 ], [ %425, %418 ]
  %456 = phi float [ %452, %429 ], [ %426, %418 ]
  %457 = phi float [ %453, %429 ], [ %427, %418 ]
  %458 = call float @dx.op.unary.f32(i32 7, float %455)  ; Saturate(value)
  %459 = call float @dx.op.unary.f32(i32 7, float %456)  ; Saturate(value)
  %460 = call float @dx.op.unary.f32(i32 7, float %457)  ; Saturate(value)
  %461 = call float @dx.op.dot3.f32(i32 55, float %458, float %459, float %460, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %462 = fsub fast float %458, %461
  %463 = fsub fast float %459, %461
  %464 = fsub fast float %460, %461
  %465 = fmul fast float %462, %9
  %466 = fmul fast float %463, %9
  %467 = fmul fast float %464, %9
  %468 = fadd fast float %465, %461
  %469 = fadd fast float %466, %461
  %470 = fadd fast float %467, %461
  %471 = call float @dx.op.unary.f32(i32 7, float %468)  ; Saturate(value)
  %472 = call float @dx.op.unary.f32(i32 7, float %469)  ; Saturate(value)
  %473 = call float @dx.op.unary.f32(i32 7, float %470)  ; Saturate(value)
  %474 = fadd fast float %471, 0xBFC70A3D80000000
  %475 = fadd fast float %472, 0xBFC70A3D80000000
  %476 = fadd fast float %473, 0xBFC70A3D80000000
  %477 = fmul fast float %474, %8
  %478 = fmul fast float %475, %8
  %479 = fmul fast float %476, %8
  %480 = fadd fast float %477, 0x3FC70A3D80000000
  %481 = fadd fast float %478, 0x3FC70A3D80000000
  %482 = fadd fast float %479, 0x3FC70A3D80000000
  %483 = call float @dx.op.unary.f32(i32 7, float %480)  ; Saturate(value)
  %484 = call float @dx.op.unary.f32(i32 7, float %481)  ; Saturate(value)
  %485 = call float @dx.op.unary.f32(i32 7, float %482)  ; Saturate(value)
  br label %486

; <label>:486                                     ; preds = %454, %384
  %487 = phi float [ %415, %384 ], [ %483, %454 ]
  %488 = phi float [ %416, %384 ], [ %484, %454 ]
  %489 = phi float [ %417, %384 ], [ %485, %454 ]
  %490 = fsub fast float %487, %211
  %491 = fsub fast float %488, %212
  %492 = fsub fast float %489, %213
  %493 = fmul fast float %490, %371
  %494 = fmul fast float %491, %371
  %495 = fmul fast float %492, %371
  %496 = fadd fast float %493, %211
  %497 = fadd fast float %494, %212
  %498 = fadd fast float %495, %213
  br label %499

; <label>:499                                     ; preds = %486, %358
  %500 = phi float [ %496, %486 ], [ %211, %358 ]
  %501 = phi float [ %497, %486 ], [ %212, %358 ]
  %502 = phi float [ %498, %486 ], [ %213, %358 ]
  %503 = add i32 %35, -1
  %504 = call i32 @dx.op.binary.i32(i32 37, i32 %503, i32 0)  ; IMax(a,b)
  %505 = call i32 @dx.op.binary.i32(i32 37, i32 %36, i32 0)  ; IMax(a,b)
  %506 = call i32 @dx.op.binary.i32(i32 38, i32 %504, i32 %31)  ; IMin(a,b)
  %507 = call i32 @dx.op.binary.i32(i32 38, i32 %505, i32 %32)  ; IMin(a,b)
  %508 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %506, i32 %507, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %509 = extractvalue %dx.types.ResRet.f32 %508, 0
  %510 = fsub fast float %509, %54
  %511 = call float @dx.op.unary.f32(i32 6, float %510)  ; FAbs(value)
  %512 = fdiv fast float %511, %225
  %513 = fsub fast float 1.000000e+00, %512
  %514 = call float @dx.op.unary.f32(i32 7, float %513)  ; Saturate(value)
  %515 = fcmp fast ugt float %514, 0.000000e+00
  br i1 %515, label %516, label %642

; <label>:516                                     ; preds = %499
  %517 = call i32 @dx.op.binary.i32(i32 37, i32 %506, i32 0)  ; IMax(a,b)
  %518 = call i32 @dx.op.binary.i32(i32 37, i32 %507, i32 0)  ; IMax(a,b)
  %519 = call i32 @dx.op.binary.i32(i32 38, i32 %517, i32 %31)  ; IMin(a,b)
  %520 = call i32 @dx.op.binary.i32(i32 38, i32 %518, i32 %32)  ; IMin(a,b)
  %521 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %519, i32 %520, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %522 = extractvalue %dx.types.ResRet.f32 %521, 0
  %523 = extractvalue %dx.types.ResRet.f32 %521, 1
  %524 = extractvalue %dx.types.ResRet.f32 %521, 2
  %525 = extractvalue %dx.types.ResRet.f32 %521, 3
  %526 = fcmp fast olt float %525, 0.000000e+00
  br i1 %526, label %527, label %561

; <label>:527                                     ; preds = %516
  %528 = fcmp fast ogt float %522, 0x3FA4B5DCC0000000
  %529 = fcmp fast ogt float %523, 0x3FA4B5DCC0000000
  %530 = fcmp fast ogt float %524, 0x3FA4B5DCC0000000
  %531 = select i1 %528, float 0.000000e+00, float 1.000000e+00
  %532 = select i1 %529, float 0.000000e+00, float 1.000000e+00
  %533 = select i1 %530, float 0.000000e+00, float 1.000000e+00
  %534 = fmul fast float %522, 0x3FB3D07220000000
  %535 = fmul fast float %523, 0x3FB3D07220000000
  %536 = fmul fast float %524, 0x3FB3D07220000000
  %537 = fadd fast float %522, 0x3FAC28F5C0000000
  %538 = fadd fast float %523, 0x3FAC28F5C0000000
  %539 = fadd fast float %524, 0x3FAC28F5C0000000
  %540 = fmul fast float %537, 0x3FEE54EDE0000000
  %541 = fmul fast float %538, 0x3FEE54EDE0000000
  %542 = fmul fast float %539, 0x3FEE54EDE0000000
  %543 = call float @dx.op.unary.f32(i32 23, float %540)  ; Log(value)
  %544 = call float @dx.op.unary.f32(i32 23, float %541)  ; Log(value)
  %545 = call float @dx.op.unary.f32(i32 23, float %542)  ; Log(value)
  %546 = fmul fast float %543, 0x4003333340000000
  %547 = fmul fast float %544, 0x4003333340000000
  %548 = fmul fast float %545, 0x4003333340000000
  %549 = call float @dx.op.unary.f32(i32 21, float %546)  ; Exp(value)
  %550 = call float @dx.op.unary.f32(i32 21, float %547)  ; Exp(value)
  %551 = call float @dx.op.unary.f32(i32 21, float %548)  ; Exp(value)
  %552 = fsub fast float %534, %549
  %553 = fsub fast float %535, %550
  %554 = fsub fast float %536, %551
  %555 = fmul fast float %552, %531
  %556 = fmul fast float %553, %532
  %557 = fmul fast float %554, %533
  %558 = fadd fast float %555, %549
  %559 = fadd fast float %556, %550
  %560 = fadd fast float %557, %551
  br label %629

; <label>:561                                     ; preds = %516
  %562 = fadd fast float %6, 1.000000e+00
  %563 = fadd fast float %7, 1.000000e+00
  %564 = fsub fast float 1.000000e+00, %6
  %565 = fmul fast float %10, %562
  %566 = fmul fast float %10, %563
  %567 = fmul fast float %10, %564
  %568 = fmul fast float %565, %522
  %569 = fmul fast float %566, %523
  %570 = fmul fast float %567, %524
  %571 = fcmp fast ult float %11, 5.000000e-01
  br i1 %571, label %597, label %572

; <label>:572                                     ; preds = %561
  %573 = fmul fast float %568, 0x4004147AE0000000
  %574 = fmul fast float %569, 0x4004147AE0000000
  %575 = fmul fast float %570, 0x4004147AE0000000
  %576 = fadd fast float %573, 0x3F9EB851E0000000
  %577 = fadd fast float %574, 0x3F9EB851E0000000
  %578 = fadd fast float %575, 0x3F9EB851E0000000
  %579 = fmul fast float %576, %568
  %580 = fmul fast float %577, %569
  %581 = fmul fast float %578, %570
  %582 = fmul fast float %568, 0x400370A3E0000000
  %583 = fmul fast float %569, 0x400370A3E0000000
  %584 = fmul fast float %570, 0x400370A3E0000000
  %585 = fadd fast float %582, 0x3FE2E147A0000000
  %586 = fadd fast float %583, 0x3FE2E147A0000000
  %587 = fadd fast float %584, 0x3FE2E147A0000000
  %588 = fmul fast float %585, %568
  %589 = fmul fast float %586, %569
  %590 = fmul fast float %587, %570
  %591 = fadd fast float %588, 0x3FC1EB8520000000
  %592 = fadd fast float %589, 0x3FC1EB8520000000
  %593 = fadd fast float %590, 0x3FC1EB8520000000
  %594 = fdiv fast float %579, %591
  %595 = fdiv fast float %580, %592
  %596 = fdiv fast float %581, %593
  br label %597

; <label>:597                                     ; preds = %572, %561
  %598 = phi float [ %594, %572 ], [ %568, %561 ]
  %599 = phi float [ %595, %572 ], [ %569, %561 ]
  %600 = phi float [ %596, %572 ], [ %570, %561 ]
  %601 = call float @dx.op.unary.f32(i32 7, float %598)  ; Saturate(value)
  %602 = call float @dx.op.unary.f32(i32 7, float %599)  ; Saturate(value)
  %603 = call float @dx.op.unary.f32(i32 7, float %600)  ; Saturate(value)
  %604 = call float @dx.op.dot3.f32(i32 55, float %601, float %602, float %603, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %605 = fsub fast float %601, %604
  %606 = fsub fast float %602, %604
  %607 = fsub fast float %603, %604
  %608 = fmul fast float %605, %9
  %609 = fmul fast float %606, %9
  %610 = fmul fast float %607, %9
  %611 = fadd fast float %608, %604
  %612 = fadd fast float %609, %604
  %613 = fadd fast float %610, %604
  %614 = call float @dx.op.unary.f32(i32 7, float %611)  ; Saturate(value)
  %615 = call float @dx.op.unary.f32(i32 7, float %612)  ; Saturate(value)
  %616 = call float @dx.op.unary.f32(i32 7, float %613)  ; Saturate(value)
  %617 = fadd fast float %614, 0xBFC70A3D80000000
  %618 = fadd fast float %615, 0xBFC70A3D80000000
  %619 = fadd fast float %616, 0xBFC70A3D80000000
  %620 = fmul fast float %617, %8
  %621 = fmul fast float %618, %8
  %622 = fmul fast float %619, %8
  %623 = fadd fast float %620, 0x3FC70A3D80000000
  %624 = fadd fast float %621, 0x3FC70A3D80000000
  %625 = fadd fast float %622, 0x3FC70A3D80000000
  %626 = call float @dx.op.unary.f32(i32 7, float %623)  ; Saturate(value)
  %627 = call float @dx.op.unary.f32(i32 7, float %624)  ; Saturate(value)
  %628 = call float @dx.op.unary.f32(i32 7, float %625)  ; Saturate(value)
  br label %629

; <label>:629                                     ; preds = %597, %527
  %630 = phi float [ %558, %527 ], [ %626, %597 ]
  %631 = phi float [ %559, %527 ], [ %627, %597 ]
  %632 = phi float [ %560, %527 ], [ %628, %597 ]
  %633 = fsub fast float %630, %211
  %634 = fsub fast float %631, %212
  %635 = fsub fast float %632, %213
  %636 = fmul fast float %633, %514
  %637 = fmul fast float %634, %514
  %638 = fmul fast float %635, %514
  %639 = fadd fast float %636, %211
  %640 = fadd fast float %637, %212
  %641 = fadd fast float %638, %213
  br label %642

; <label>:642                                     ; preds = %629, %499
  %643 = phi float [ %639, %629 ], [ %211, %499 ]
  %644 = phi float [ %640, %629 ], [ %212, %499 ]
  %645 = phi float [ %641, %629 ], [ %213, %499 ]
  %646 = add i32 %35, 1
  %647 = call i32 @dx.op.binary.i32(i32 37, i32 %646, i32 0)  ; IMax(a,b)
  %648 = call i32 @dx.op.binary.i32(i32 38, i32 %647, i32 %31)  ; IMin(a,b)
  %649 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %648, i32 %507, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %650 = extractvalue %dx.types.ResRet.f32 %649, 0
  %651 = fsub fast float %650, %54
  %652 = call float @dx.op.unary.f32(i32 6, float %651)  ; FAbs(value)
  %653 = fdiv fast float %652, %225
  %654 = fsub fast float 1.000000e+00, %653
  %655 = call float @dx.op.unary.f32(i32 7, float %654)  ; Saturate(value)
  %656 = fcmp fast ugt float %655, 0.000000e+00
  br i1 %656, label %657, label %783

; <label>:657                                     ; preds = %642
  %658 = call i32 @dx.op.binary.i32(i32 37, i32 %648, i32 0)  ; IMax(a,b)
  %659 = call i32 @dx.op.binary.i32(i32 37, i32 %507, i32 0)  ; IMax(a,b)
  %660 = call i32 @dx.op.binary.i32(i32 38, i32 %658, i32 %31)  ; IMin(a,b)
  %661 = call i32 @dx.op.binary.i32(i32 38, i32 %659, i32 %32)  ; IMin(a,b)
  %662 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %660, i32 %661, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %663 = extractvalue %dx.types.ResRet.f32 %662, 0
  %664 = extractvalue %dx.types.ResRet.f32 %662, 1
  %665 = extractvalue %dx.types.ResRet.f32 %662, 2
  %666 = extractvalue %dx.types.ResRet.f32 %662, 3
  %667 = fcmp fast olt float %666, 0.000000e+00
  br i1 %667, label %668, label %702

; <label>:668                                     ; preds = %657
  %669 = fcmp fast ogt float %663, 0x3FA4B5DCC0000000
  %670 = fcmp fast ogt float %664, 0x3FA4B5DCC0000000
  %671 = fcmp fast ogt float %665, 0x3FA4B5DCC0000000
  %672 = select i1 %669, float 0.000000e+00, float 1.000000e+00
  %673 = select i1 %670, float 0.000000e+00, float 1.000000e+00
  %674 = select i1 %671, float 0.000000e+00, float 1.000000e+00
  %675 = fmul fast float %663, 0x3FB3D07220000000
  %676 = fmul fast float %664, 0x3FB3D07220000000
  %677 = fmul fast float %665, 0x3FB3D07220000000
  %678 = fadd fast float %663, 0x3FAC28F5C0000000
  %679 = fadd fast float %664, 0x3FAC28F5C0000000
  %680 = fadd fast float %665, 0x3FAC28F5C0000000
  %681 = fmul fast float %678, 0x3FEE54EDE0000000
  %682 = fmul fast float %679, 0x3FEE54EDE0000000
  %683 = fmul fast float %680, 0x3FEE54EDE0000000
  %684 = call float @dx.op.unary.f32(i32 23, float %681)  ; Log(value)
  %685 = call float @dx.op.unary.f32(i32 23, float %682)  ; Log(value)
  %686 = call float @dx.op.unary.f32(i32 23, float %683)  ; Log(value)
  %687 = fmul fast float %684, 0x4003333340000000
  %688 = fmul fast float %685, 0x4003333340000000
  %689 = fmul fast float %686, 0x4003333340000000
  %690 = call float @dx.op.unary.f32(i32 21, float %687)  ; Exp(value)
  %691 = call float @dx.op.unary.f32(i32 21, float %688)  ; Exp(value)
  %692 = call float @dx.op.unary.f32(i32 21, float %689)  ; Exp(value)
  %693 = fsub fast float %675, %690
  %694 = fsub fast float %676, %691
  %695 = fsub fast float %677, %692
  %696 = fmul fast float %693, %672
  %697 = fmul fast float %694, %673
  %698 = fmul fast float %695, %674
  %699 = fadd fast float %696, %690
  %700 = fadd fast float %697, %691
  %701 = fadd fast float %698, %692
  br label %770

; <label>:702                                     ; preds = %657
  %703 = fadd fast float %6, 1.000000e+00
  %704 = fadd fast float %7, 1.000000e+00
  %705 = fsub fast float 1.000000e+00, %6
  %706 = fmul fast float %10, %703
  %707 = fmul fast float %10, %704
  %708 = fmul fast float %10, %705
  %709 = fmul fast float %706, %663
  %710 = fmul fast float %707, %664
  %711 = fmul fast float %708, %665
  %712 = fcmp fast ult float %11, 5.000000e-01
  br i1 %712, label %738, label %713

; <label>:713                                     ; preds = %702
  %714 = fmul fast float %709, 0x4004147AE0000000
  %715 = fmul fast float %710, 0x4004147AE0000000
  %716 = fmul fast float %711, 0x4004147AE0000000
  %717 = fadd fast float %714, 0x3F9EB851E0000000
  %718 = fadd fast float %715, 0x3F9EB851E0000000
  %719 = fadd fast float %716, 0x3F9EB851E0000000
  %720 = fmul fast float %717, %709
  %721 = fmul fast float %718, %710
  %722 = fmul fast float %719, %711
  %723 = fmul fast float %709, 0x400370A3E0000000
  %724 = fmul fast float %710, 0x400370A3E0000000
  %725 = fmul fast float %711, 0x400370A3E0000000
  %726 = fadd fast float %723, 0x3FE2E147A0000000
  %727 = fadd fast float %724, 0x3FE2E147A0000000
  %728 = fadd fast float %725, 0x3FE2E147A0000000
  %729 = fmul fast float %726, %709
  %730 = fmul fast float %727, %710
  %731 = fmul fast float %728, %711
  %732 = fadd fast float %729, 0x3FC1EB8520000000
  %733 = fadd fast float %730, 0x3FC1EB8520000000
  %734 = fadd fast float %731, 0x3FC1EB8520000000
  %735 = fdiv fast float %720, %732
  %736 = fdiv fast float %721, %733
  %737 = fdiv fast float %722, %734
  br label %738

; <label>:738                                     ; preds = %713, %702
  %739 = phi float [ %735, %713 ], [ %709, %702 ]
  %740 = phi float [ %736, %713 ], [ %710, %702 ]
  %741 = phi float [ %737, %713 ], [ %711, %702 ]
  %742 = call float @dx.op.unary.f32(i32 7, float %739)  ; Saturate(value)
  %743 = call float @dx.op.unary.f32(i32 7, float %740)  ; Saturate(value)
  %744 = call float @dx.op.unary.f32(i32 7, float %741)  ; Saturate(value)
  %745 = call float @dx.op.dot3.f32(i32 55, float %742, float %743, float %744, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %746 = fsub fast float %742, %745
  %747 = fsub fast float %743, %745
  %748 = fsub fast float %744, %745
  %749 = fmul fast float %746, %9
  %750 = fmul fast float %747, %9
  %751 = fmul fast float %748, %9
  %752 = fadd fast float %749, %745
  %753 = fadd fast float %750, %745
  %754 = fadd fast float %751, %745
  %755 = call float @dx.op.unary.f32(i32 7, float %752)  ; Saturate(value)
  %756 = call float @dx.op.unary.f32(i32 7, float %753)  ; Saturate(value)
  %757 = call float @dx.op.unary.f32(i32 7, float %754)  ; Saturate(value)
  %758 = fadd fast float %755, 0xBFC70A3D80000000
  %759 = fadd fast float %756, 0xBFC70A3D80000000
  %760 = fadd fast float %757, 0xBFC70A3D80000000
  %761 = fmul fast float %758, %8
  %762 = fmul fast float %759, %8
  %763 = fmul fast float %760, %8
  %764 = fadd fast float %761, 0x3FC70A3D80000000
  %765 = fadd fast float %762, 0x3FC70A3D80000000
  %766 = fadd fast float %763, 0x3FC70A3D80000000
  %767 = call float @dx.op.unary.f32(i32 7, float %764)  ; Saturate(value)
  %768 = call float @dx.op.unary.f32(i32 7, float %765)  ; Saturate(value)
  %769 = call float @dx.op.unary.f32(i32 7, float %766)  ; Saturate(value)
  br label %770

; <label>:770                                     ; preds = %738, %668
  %771 = phi float [ %699, %668 ], [ %767, %738 ]
  %772 = phi float [ %700, %668 ], [ %768, %738 ]
  %773 = phi float [ %701, %668 ], [ %769, %738 ]
  %774 = fsub fast float %771, %211
  %775 = fsub fast float %772, %212
  %776 = fsub fast float %773, %213
  %777 = fmul fast float %774, %655
  %778 = fmul fast float %775, %655
  %779 = fmul fast float %776, %655
  %780 = fadd fast float %777, %211
  %781 = fadd fast float %778, %212
  %782 = fadd fast float %779, %213
  br label %783

; <label>:783                                     ; preds = %770, %642
  %784 = phi float [ %780, %770 ], [ %211, %642 ]
  %785 = phi float [ %781, %770 ], [ %212, %642 ]
  %786 = phi float [ %782, %770 ], [ %213, %642 ]
  %787 = call float @dx.op.binary.f32(i32 36, float %643, float %784)  ; FMin(a,b)
  %788 = call float @dx.op.binary.f32(i32 36, float %644, float %785)  ; FMin(a,b)
  %789 = call float @dx.op.binary.f32(i32 36, float %645, float %786)  ; FMin(a,b)
  %790 = call float @dx.op.binary.f32(i32 36, float %359, float %500)  ; FMin(a,b)
  %791 = call float @dx.op.binary.f32(i32 36, float %360, float %501)  ; FMin(a,b)
  %792 = call float @dx.op.binary.f32(i32 36, float %361, float %502)  ; FMin(a,b)
  %793 = call float @dx.op.binary.f32(i32 36, float %790, float %787)  ; FMin(a,b)
  %794 = call float @dx.op.binary.f32(i32 36, float %791, float %788)  ; FMin(a,b)
  %795 = call float @dx.op.binary.f32(i32 36, float %792, float %789)  ; FMin(a,b)
  %796 = call float @dx.op.binary.f32(i32 36, float %211, float %793)  ; FMin(a,b)
  %797 = call float @dx.op.binary.f32(i32 36, float %212, float %794)  ; FMin(a,b)
  %798 = call float @dx.op.binary.f32(i32 36, float %213, float %795)  ; FMin(a,b)
  %799 = call float @dx.op.binary.f32(i32 35, float %643, float %784)  ; FMax(a,b)
  %800 = call float @dx.op.binary.f32(i32 35, float %644, float %785)  ; FMax(a,b)
  %801 = call float @dx.op.binary.f32(i32 35, float %645, float %786)  ; FMax(a,b)
  %802 = call float @dx.op.binary.f32(i32 35, float %359, float %500)  ; FMax(a,b)
  %803 = call float @dx.op.binary.f32(i32 35, float %360, float %501)  ; FMax(a,b)
  %804 = call float @dx.op.binary.f32(i32 35, float %361, float %502)  ; FMax(a,b)
  %805 = call float @dx.op.binary.f32(i32 35, float %802, float %799)  ; FMax(a,b)
  %806 = call float @dx.op.binary.f32(i32 35, float %803, float %800)  ; FMax(a,b)
  %807 = call float @dx.op.binary.f32(i32 35, float %804, float %801)  ; FMax(a,b)
  %808 = call float @dx.op.binary.f32(i32 35, float %211, float %805)  ; FMax(a,b)
  %809 = call float @dx.op.binary.f32(i32 35, float %212, float %806)  ; FMax(a,b)
  %810 = call float @dx.op.binary.f32(i32 35, float %213, float %807)  ; FMax(a,b)
  %811 = fsub fast float %808, %796
  %812 = fsub fast float %809, %797
  %813 = fsub fast float %810, %798
  %814 = call float @dx.op.unary.f32(i32 6, float %811)  ; FAbs(value)
  %815 = call float @dx.op.unary.f32(i32 6, float %812)  ; FAbs(value)
  %816 = call float @dx.op.unary.f32(i32 6, float %813)  ; FAbs(value)
  %817 = call float @dx.op.binary.f32(i32 35, float %815, float %816)  ; FMax(a,b)
  %818 = call float @dx.op.binary.f32(i32 35, float %814, float %817)  ; FMax(a,b)
  %819 = call float @dx.op.binary.f32(i32 35, float %809, float %810)  ; FMax(a,b)
  %820 = call float @dx.op.binary.f32(i32 35, float %808, float %819)  ; FMax(a,b)
  %821 = fmul fast float %820, 1.250000e-01
  %822 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %821)  ; FMax(a,b)
  %823 = fcmp fast ogt float %818, %822
  br i1 %823, label %824, label %886

; <label>:824                                     ; preds = %783
  %825 = fsub fast float %359, %500
  %826 = fsub fast float %360, %501
  %827 = fsub fast float %361, %502
  %828 = call float @dx.op.unary.f32(i32 6, float %825)  ; FAbs(value)
  %829 = call float @dx.op.unary.f32(i32 6, float %826)  ; FAbs(value)
  %830 = call float @dx.op.unary.f32(i32 6, float %827)  ; FAbs(value)
  %831 = call float @dx.op.binary.f32(i32 35, float %829, float %830)  ; FMax(a,b)
  %832 = call float @dx.op.binary.f32(i32 35, float %828, float %831)  ; FMax(a,b)
  %833 = fsub fast float %643, %784
  %834 = fsub fast float %644, %785
  %835 = fsub fast float %645, %786
  %836 = call float @dx.op.unary.f32(i32 6, float %833)  ; FAbs(value)
  %837 = call float @dx.op.unary.f32(i32 6, float %834)  ; FAbs(value)
  %838 = call float @dx.op.unary.f32(i32 6, float %835)  ; FAbs(value)
  %839 = call float @dx.op.binary.f32(i32 35, float %837, float %838)  ; FMax(a,b)
  %840 = call float @dx.op.binary.f32(i32 35, float %836, float %839)  ; FMax(a,b)
  %841 = fcmp fast olt float %832, %840
  %842 = select i1 %841, float %359, float %643
  %843 = select i1 %841, float %360, float %644
  %844 = select i1 %841, float %361, float %645
  %845 = select i1 %841, float %500, float %784
  %846 = select i1 %841, float %501, float %785
  %847 = select i1 %841, float %502, float %786
  %848 = fsub fast float %211, %845
  %849 = fsub fast float %212, %846
  %850 = fsub fast float %213, %847
  %851 = fsub fast float %211, %842
  %852 = fsub fast float %212, %843
  %853 = fsub fast float %213, %844
  %854 = call float @dx.op.dot3.f32(i32 55, float %851, float %852, float %853, float %848, float %849, float %850)  ; Dot3(ax,ay,az,bx,by,bz)
  %855 = fcmp fast ogt float %854, 0.000000e+00
  br i1 %855, label %856, label %867

; <label>:856                                     ; preds = %824
  %857 = fsub fast float %842, %845
  %858 = fsub fast float %843, %846
  %859 = fsub fast float %844, %847
  %860 = call float @dx.op.unary.f32(i32 6, float %857)  ; FAbs(value)
  %861 = call float @dx.op.unary.f32(i32 6, float %858)  ; FAbs(value)
  %862 = call float @dx.op.unary.f32(i32 6, float %859)  ; FAbs(value)
  %863 = call float @dx.op.binary.f32(i32 35, float %861, float %862)  ; FMax(a,b)
  %864 = call float @dx.op.binary.f32(i32 35, float %860, float %863)  ; FMax(a,b)
  %865 = fmul fast float %818, 2.500000e-01
  %866 = fcmp fast olt float %864, %865
  br label %867

; <label>:867                                     ; preds = %856, %824
  %868 = phi i1 [ false, %824 ], [ %866, %856 ]
  %869 = select i1 %868, float 5.000000e-01, float 1.000000e+00
  %870 = fmul fast float %869, %3
  %871 = fadd fast float %842, %845
  %872 = fadd fast float %843, %846
  %873 = fadd fast float %844, %847
  %874 = fmul fast float %871, 5.000000e-01
  %875 = fmul fast float %872, 5.000000e-01
  %876 = fmul fast float %873, 5.000000e-01
  %877 = fsub fast float %874, %211
  %878 = fsub fast float %875, %212
  %879 = fsub fast float %876, %213
  %880 = fmul fast float %870, %877
  %881 = fmul fast float %870, %878
  %882 = fmul fast float %870, %879
  %883 = fadd fast float %880, %211
  %884 = fadd fast float %881, %212
  %885 = fadd fast float %882, %213
  br label %886

; <label>:886                                     ; preds = %867, %783, %182
  %887 = phi float [ %211, %182 ], [ %883, %867 ], [ %211, %783 ]
  %888 = phi float [ %212, %182 ], [ %884, %867 ], [ %212, %783 ]
  %889 = phi float [ %213, %182 ], [ %885, %867 ], [ %213, %783 ]
  %890 = fcmp fast ogt float %887, 0x3F69A5C380000000
  %891 = fcmp fast ogt float %888, 0x3F69A5C380000000
  %892 = fcmp fast ogt float %889, 0x3F69A5C380000000
  %893 = select i1 %890, float 0.000000e+00, float 1.000000e+00
  %894 = select i1 %891, float 0.000000e+00, float 1.000000e+00
  %895 = select i1 %892, float 0.000000e+00, float 1.000000e+00
  %896 = fmul fast float %887, 0x4029D70A40000000
  %897 = fmul fast float %888, 0x4029D70A40000000
  %898 = fmul fast float %889, 0x4029D70A40000000
  %899 = call float @dx.op.binary.f32(i32 35, float %887, float 0.000000e+00)  ; FMax(a,b)
  %900 = call float @dx.op.binary.f32(i32 35, float %888, float 0.000000e+00)  ; FMax(a,b)
  %901 = call float @dx.op.binary.f32(i32 35, float %889, float 0.000000e+00)  ; FMax(a,b)
  %902 = call float @dx.op.unary.f32(i32 23, float %899)  ; Log(value)
  %903 = call float @dx.op.unary.f32(i32 23, float %900)  ; Log(value)
  %904 = call float @dx.op.unary.f32(i32 23, float %901)  ; Log(value)
  %905 = fmul fast float %902, 0x3FDAAAAAA0000000
  %906 = fmul fast float %903, 0x3FDAAAAAA0000000
  %907 = fmul fast float %904, 0x3FDAAAAAA0000000
  %908 = call float @dx.op.unary.f32(i32 21, float %905)  ; Exp(value)
  %909 = call float @dx.op.unary.f32(i32 21, float %906)  ; Exp(value)
  %910 = call float @dx.op.unary.f32(i32 21, float %907)  ; Exp(value)
  %911 = fmul fast float %908, 0x3FF0E147A0000000
  %912 = fmul fast float %909, 0x3FF0E147A0000000
  %913 = fmul fast float %910, 0x3FF0E147A0000000
  %914 = fadd fast float %911, 0xBFAC28F5C0000000
  %915 = fadd fast float %912, 0xBFAC28F5C0000000
  %916 = fadd fast float %913, 0xBFAC28F5C0000000
  %917 = fsub fast float %896, %914
  %918 = fsub fast float %897, %915
  %919 = fsub fast float %898, %916
  %920 = fmul fast float %917, %893
  %921 = fmul fast float %918, %894
  %922 = fmul fast float %919, %895
  %923 = fadd fast float %920, %914
  %924 = fadd fast float %921, %915
  %925 = fadd fast float %922, %916
  br label %926

; <label>:926                                     ; preds = %886, %144
  %927 = phi float [ %139, %144 ], [ %923, %886 ]
  %928 = phi float [ %140, %144 ], [ %924, %886 ]
  %929 = phi float [ %141, %144 ], [ %925, %886 ]
  %930 = phi float [ %145, %144 ], [ %142, %886 ]
  %931 = fcmp fast ogt float %927, 0x3FA4B5DCC0000000
  %932 = fcmp fast ogt float %928, 0x3FA4B5DCC0000000
  %933 = fcmp fast ogt float %929, 0x3FA4B5DCC0000000
  %934 = select i1 %931, float 0.000000e+00, float 1.000000e+00
  %935 = select i1 %932, float 0.000000e+00, float 1.000000e+00
  %936 = select i1 %933, float 0.000000e+00, float 1.000000e+00
  %937 = fmul fast float %927, 0x3FB3D07220000000
  %938 = fmul fast float %928, 0x3FB3D07220000000
  %939 = fmul fast float %929, 0x3FB3D07220000000
  %940 = fadd fast float %927, 0x3FAC28F5C0000000
  %941 = fadd fast float %928, 0x3FAC28F5C0000000
  %942 = fadd fast float %929, 0x3FAC28F5C0000000
  %943 = fmul fast float %940, 0x3FEE54EDE0000000
  %944 = fmul fast float %941, 0x3FEE54EDE0000000
  %945 = fmul fast float %942, 0x3FEE54EDE0000000
  %946 = call float @dx.op.unary.f32(i32 23, float %943)  ; Log(value)
  %947 = call float @dx.op.unary.f32(i32 23, float %944)  ; Log(value)
  %948 = call float @dx.op.unary.f32(i32 23, float %945)  ; Log(value)
  %949 = fmul fast float %946, 0x4003333340000000
  %950 = fmul fast float %947, 0x4003333340000000
  %951 = fmul fast float %948, 0x4003333340000000
  %952 = call float @dx.op.unary.f32(i32 21, float %949)  ; Exp(value)
  %953 = call float @dx.op.unary.f32(i32 21, float %950)  ; Exp(value)
  %954 = call float @dx.op.unary.f32(i32 21, float %951)  ; Exp(value)
  %955 = fsub fast float %937, %952
  %956 = fsub fast float %938, %953
  %957 = fsub fast float %939, %954
  %958 = fmul fast float %955, %934
  %959 = fmul fast float %956, %935
  %960 = fmul fast float %957, %936
  %961 = fadd fast float %958, %952
  %962 = fadd fast float %959, %953
  %963 = fadd fast float %960, %954
  %964 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %39, i32 %36, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %965 = extractvalue %dx.types.ResRet.f32 %964, 0
  %966 = extractvalue %dx.types.ResRet.f32 %964, 1
  %967 = extractvalue %dx.types.ResRet.f32 %964, 2
  %968 = extractvalue %dx.types.ResRet.f32 %964, 3
  %969 = fcmp fast olt float %968, 0.000000e+00
  br i1 %969, label %970, label %972

; <label>:970                                     ; preds = %926
  %971 = fsub fast float -1.000000e+00, %968
  br label %1752

; <label>:972                                     ; preds = %926
  %973 = fadd fast float %6, 1.000000e+00
  %974 = fadd fast float %7, 1.000000e+00
  %975 = fsub fast float 1.000000e+00, %6
  %976 = fmul fast float %10, %973
  %977 = fmul fast float %10, %974
  %978 = fmul fast float %10, %975
  %979 = fmul fast float %976, %965
  %980 = fmul fast float %977, %966
  %981 = fmul fast float %978, %967
  %982 = fcmp fast ult float %11, 5.000000e-01
  br i1 %982, label %1008, label %983

; <label>:983                                     ; preds = %972
  %984 = fmul fast float %979, 0x4004147AE0000000
  %985 = fmul fast float %980, 0x4004147AE0000000
  %986 = fmul fast float %981, 0x4004147AE0000000
  %987 = fadd fast float %984, 0x3F9EB851E0000000
  %988 = fadd fast float %985, 0x3F9EB851E0000000
  %989 = fadd fast float %986, 0x3F9EB851E0000000
  %990 = fmul fast float %987, %979
  %991 = fmul fast float %988, %980
  %992 = fmul fast float %989, %981
  %993 = fmul fast float %979, 0x400370A3E0000000
  %994 = fmul fast float %980, 0x400370A3E0000000
  %995 = fmul fast float %981, 0x400370A3E0000000
  %996 = fadd fast float %993, 0x3FE2E147A0000000
  %997 = fadd fast float %994, 0x3FE2E147A0000000
  %998 = fadd fast float %995, 0x3FE2E147A0000000
  %999 = fmul fast float %996, %979
  %1000 = fmul fast float %997, %980
  %1001 = fmul fast float %998, %981
  %1002 = fadd fast float %999, 0x3FC1EB8520000000
  %1003 = fadd fast float %1000, 0x3FC1EB8520000000
  %1004 = fadd fast float %1001, 0x3FC1EB8520000000
  %1005 = fdiv fast float %990, %1002
  %1006 = fdiv fast float %991, %1003
  %1007 = fdiv fast float %992, %1004
  br label %1008

; <label>:1008                                    ; preds = %983, %972
  %1009 = phi float [ %1005, %983 ], [ %979, %972 ]
  %1010 = phi float [ %1006, %983 ], [ %980, %972 ]
  %1011 = phi float [ %1007, %983 ], [ %981, %972 ]
  %1012 = call float @dx.op.unary.f32(i32 7, float %1009)  ; Saturate(value)
  %1013 = call float @dx.op.unary.f32(i32 7, float %1010)  ; Saturate(value)
  %1014 = call float @dx.op.unary.f32(i32 7, float %1011)  ; Saturate(value)
  %1015 = call float @dx.op.dot3.f32(i32 55, float %1012, float %1013, float %1014, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1016 = fsub fast float %1012, %1015
  %1017 = fsub fast float %1013, %1015
  %1018 = fsub fast float %1014, %1015
  %1019 = fmul fast float %1016, %9
  %1020 = fmul fast float %1017, %9
  %1021 = fmul fast float %1018, %9
  %1022 = fadd fast float %1019, %1015
  %1023 = fadd fast float %1020, %1015
  %1024 = fadd fast float %1021, %1015
  %1025 = call float @dx.op.unary.f32(i32 7, float %1022)  ; Saturate(value)
  %1026 = call float @dx.op.unary.f32(i32 7, float %1023)  ; Saturate(value)
  %1027 = call float @dx.op.unary.f32(i32 7, float %1024)  ; Saturate(value)
  %1028 = fadd fast float %1025, 0xBFC70A3D80000000
  %1029 = fadd fast float %1026, 0xBFC70A3D80000000
  %1030 = fadd fast float %1027, 0xBFC70A3D80000000
  %1031 = fmul fast float %1028, %8
  %1032 = fmul fast float %1029, %8
  %1033 = fmul fast float %1030, %8
  %1034 = fadd fast float %1031, 0x3FC70A3D80000000
  %1035 = fadd fast float %1032, 0x3FC70A3D80000000
  %1036 = fadd fast float %1033, 0x3FC70A3D80000000
  %1037 = call float @dx.op.unary.f32(i32 7, float %1034)  ; Saturate(value)
  %1038 = call float @dx.op.unary.f32(i32 7, float %1035)  ; Saturate(value)
  %1039 = call float @dx.op.unary.f32(i32 7, float %1036)  ; Saturate(value)
  %1040 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %1040, label %1041, label %1712

; <label>:1041                                    ; preds = %1008
  %1042 = add i32 %36, -1
  %1043 = call i32 @dx.op.binary.i32(i32 37, i32 %39, i32 0)  ; IMax(a,b)
  %1044 = call i32 @dx.op.binary.i32(i32 37, i32 %1042, i32 0)  ; IMax(a,b)
  %1045 = call i32 @dx.op.binary.i32(i32 38, i32 %1043, i32 %31)  ; IMin(a,b)
  %1046 = call i32 @dx.op.binary.i32(i32 38, i32 %1044, i32 %32)  ; IMin(a,b)
  %1047 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1045, i32 %1046, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1048 = extractvalue %dx.types.ResRet.f32 %1047, 0
  %1049 = fsub fast float 1.000000e+00, %56
  %1050 = fmul fast float %1049, 0x3FA99999A0000000
  %1051 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %1050)  ; FMax(a,b)
  %1052 = fsub fast float %1048, %56
  %1053 = call float @dx.op.unary.f32(i32 6, float %1052)  ; FAbs(value)
  %1054 = fdiv fast float %1053, %1051
  %1055 = fsub fast float 1.000000e+00, %1054
  %1056 = call float @dx.op.unary.f32(i32 7, float %1055)  ; Saturate(value)
  %1057 = fcmp fast ugt float %1056, 0.000000e+00
  br i1 %1057, label %1058, label %1184

; <label>:1058                                    ; preds = %1041
  %1059 = call i32 @dx.op.binary.i32(i32 37, i32 %1045, i32 0)  ; IMax(a,b)
  %1060 = call i32 @dx.op.binary.i32(i32 37, i32 %1046, i32 0)  ; IMax(a,b)
  %1061 = call i32 @dx.op.binary.i32(i32 38, i32 %1059, i32 %31)  ; IMin(a,b)
  %1062 = call i32 @dx.op.binary.i32(i32 38, i32 %1060, i32 %32)  ; IMin(a,b)
  %1063 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1061, i32 %1062, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1064 = extractvalue %dx.types.ResRet.f32 %1063, 0
  %1065 = extractvalue %dx.types.ResRet.f32 %1063, 1
  %1066 = extractvalue %dx.types.ResRet.f32 %1063, 2
  %1067 = extractvalue %dx.types.ResRet.f32 %1063, 3
  %1068 = fcmp fast olt float %1067, 0.000000e+00
  br i1 %1068, label %1069, label %1103

; <label>:1069                                    ; preds = %1058
  %1070 = fcmp fast ogt float %1064, 0x3FA4B5DCC0000000
  %1071 = fcmp fast ogt float %1065, 0x3FA4B5DCC0000000
  %1072 = fcmp fast ogt float %1066, 0x3FA4B5DCC0000000
  %1073 = select i1 %1070, float 0.000000e+00, float 1.000000e+00
  %1074 = select i1 %1071, float 0.000000e+00, float 1.000000e+00
  %1075 = select i1 %1072, float 0.000000e+00, float 1.000000e+00
  %1076 = fmul fast float %1064, 0x3FB3D07220000000
  %1077 = fmul fast float %1065, 0x3FB3D07220000000
  %1078 = fmul fast float %1066, 0x3FB3D07220000000
  %1079 = fadd fast float %1064, 0x3FAC28F5C0000000
  %1080 = fadd fast float %1065, 0x3FAC28F5C0000000
  %1081 = fadd fast float %1066, 0x3FAC28F5C0000000
  %1082 = fmul fast float %1079, 0x3FEE54EDE0000000
  %1083 = fmul fast float %1080, 0x3FEE54EDE0000000
  %1084 = fmul fast float %1081, 0x3FEE54EDE0000000
  %1085 = call float @dx.op.unary.f32(i32 23, float %1082)  ; Log(value)
  %1086 = call float @dx.op.unary.f32(i32 23, float %1083)  ; Log(value)
  %1087 = call float @dx.op.unary.f32(i32 23, float %1084)  ; Log(value)
  %1088 = fmul fast float %1085, 0x4003333340000000
  %1089 = fmul fast float %1086, 0x4003333340000000
  %1090 = fmul fast float %1087, 0x4003333340000000
  %1091 = call float @dx.op.unary.f32(i32 21, float %1088)  ; Exp(value)
  %1092 = call float @dx.op.unary.f32(i32 21, float %1089)  ; Exp(value)
  %1093 = call float @dx.op.unary.f32(i32 21, float %1090)  ; Exp(value)
  %1094 = fsub fast float %1076, %1091
  %1095 = fsub fast float %1077, %1092
  %1096 = fsub fast float %1078, %1093
  %1097 = fmul fast float %1094, %1073
  %1098 = fmul fast float %1095, %1074
  %1099 = fmul fast float %1096, %1075
  %1100 = fadd fast float %1097, %1091
  %1101 = fadd fast float %1098, %1092
  %1102 = fadd fast float %1099, %1093
  br label %1171

; <label>:1103                                    ; preds = %1058
  %1104 = fadd fast float %6, 1.000000e+00
  %1105 = fadd fast float %7, 1.000000e+00
  %1106 = fsub fast float 1.000000e+00, %6
  %1107 = fmul fast float %10, %1104
  %1108 = fmul fast float %10, %1105
  %1109 = fmul fast float %10, %1106
  %1110 = fmul fast float %1107, %1064
  %1111 = fmul fast float %1108, %1065
  %1112 = fmul fast float %1109, %1066
  %1113 = fcmp fast ult float %11, 5.000000e-01
  br i1 %1113, label %1139, label %1114

; <label>:1114                                    ; preds = %1103
  %1115 = fmul fast float %1110, 0x4004147AE0000000
  %1116 = fmul fast float %1111, 0x4004147AE0000000
  %1117 = fmul fast float %1112, 0x4004147AE0000000
  %1118 = fadd fast float %1115, 0x3F9EB851E0000000
  %1119 = fadd fast float %1116, 0x3F9EB851E0000000
  %1120 = fadd fast float %1117, 0x3F9EB851E0000000
  %1121 = fmul fast float %1118, %1110
  %1122 = fmul fast float %1119, %1111
  %1123 = fmul fast float %1120, %1112
  %1124 = fmul fast float %1110, 0x400370A3E0000000
  %1125 = fmul fast float %1111, 0x400370A3E0000000
  %1126 = fmul fast float %1112, 0x400370A3E0000000
  %1127 = fadd fast float %1124, 0x3FE2E147A0000000
  %1128 = fadd fast float %1125, 0x3FE2E147A0000000
  %1129 = fadd fast float %1126, 0x3FE2E147A0000000
  %1130 = fmul fast float %1127, %1110
  %1131 = fmul fast float %1128, %1111
  %1132 = fmul fast float %1129, %1112
  %1133 = fadd fast float %1130, 0x3FC1EB8520000000
  %1134 = fadd fast float %1131, 0x3FC1EB8520000000
  %1135 = fadd fast float %1132, 0x3FC1EB8520000000
  %1136 = fdiv fast float %1121, %1133
  %1137 = fdiv fast float %1122, %1134
  %1138 = fdiv fast float %1123, %1135
  br label %1139

; <label>:1139                                    ; preds = %1114, %1103
  %1140 = phi float [ %1136, %1114 ], [ %1110, %1103 ]
  %1141 = phi float [ %1137, %1114 ], [ %1111, %1103 ]
  %1142 = phi float [ %1138, %1114 ], [ %1112, %1103 ]
  %1143 = call float @dx.op.unary.f32(i32 7, float %1140)  ; Saturate(value)
  %1144 = call float @dx.op.unary.f32(i32 7, float %1141)  ; Saturate(value)
  %1145 = call float @dx.op.unary.f32(i32 7, float %1142)  ; Saturate(value)
  %1146 = call float @dx.op.dot3.f32(i32 55, float %1143, float %1144, float %1145, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1147 = fsub fast float %1143, %1146
  %1148 = fsub fast float %1144, %1146
  %1149 = fsub fast float %1145, %1146
  %1150 = fmul fast float %1147, %9
  %1151 = fmul fast float %1148, %9
  %1152 = fmul fast float %1149, %9
  %1153 = fadd fast float %1150, %1146
  %1154 = fadd fast float %1151, %1146
  %1155 = fadd fast float %1152, %1146
  %1156 = call float @dx.op.unary.f32(i32 7, float %1153)  ; Saturate(value)
  %1157 = call float @dx.op.unary.f32(i32 7, float %1154)  ; Saturate(value)
  %1158 = call float @dx.op.unary.f32(i32 7, float %1155)  ; Saturate(value)
  %1159 = fadd fast float %1156, 0xBFC70A3D80000000
  %1160 = fadd fast float %1157, 0xBFC70A3D80000000
  %1161 = fadd fast float %1158, 0xBFC70A3D80000000
  %1162 = fmul fast float %1159, %8
  %1163 = fmul fast float %1160, %8
  %1164 = fmul fast float %1161, %8
  %1165 = fadd fast float %1162, 0x3FC70A3D80000000
  %1166 = fadd fast float %1163, 0x3FC70A3D80000000
  %1167 = fadd fast float %1164, 0x3FC70A3D80000000
  %1168 = call float @dx.op.unary.f32(i32 7, float %1165)  ; Saturate(value)
  %1169 = call float @dx.op.unary.f32(i32 7, float %1166)  ; Saturate(value)
  %1170 = call float @dx.op.unary.f32(i32 7, float %1167)  ; Saturate(value)
  br label %1171

; <label>:1171                                    ; preds = %1139, %1069
  %1172 = phi float [ %1100, %1069 ], [ %1168, %1139 ]
  %1173 = phi float [ %1101, %1069 ], [ %1169, %1139 ]
  %1174 = phi float [ %1102, %1069 ], [ %1170, %1139 ]
  %1175 = fsub fast float %1172, %1037
  %1176 = fsub fast float %1173, %1038
  %1177 = fsub fast float %1174, %1039
  %1178 = fmul fast float %1175, %1056
  %1179 = fmul fast float %1176, %1056
  %1180 = fmul fast float %1177, %1056
  %1181 = fadd fast float %1178, %1037
  %1182 = fadd fast float %1179, %1038
  %1183 = fadd fast float %1180, %1039
  br label %1184

; <label>:1184                                    ; preds = %1171, %1041
  %1185 = phi float [ %1181, %1171 ], [ %1037, %1041 ]
  %1186 = phi float [ %1182, %1171 ], [ %1038, %1041 ]
  %1187 = phi float [ %1183, %1171 ], [ %1039, %1041 ]
  %1188 = add i32 %36, 1
  %1189 = call i32 @dx.op.binary.i32(i32 37, i32 %1188, i32 0)  ; IMax(a,b)
  %1190 = call i32 @dx.op.binary.i32(i32 38, i32 %1189, i32 %32)  ; IMin(a,b)
  %1191 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1045, i32 %1190, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1192 = extractvalue %dx.types.ResRet.f32 %1191, 0
  %1193 = fsub fast float %1192, %56
  %1194 = call float @dx.op.unary.f32(i32 6, float %1193)  ; FAbs(value)
  %1195 = fdiv fast float %1194, %1051
  %1196 = fsub fast float 1.000000e+00, %1195
  %1197 = call float @dx.op.unary.f32(i32 7, float %1196)  ; Saturate(value)
  %1198 = fcmp fast ugt float %1197, 0.000000e+00
  br i1 %1198, label %1199, label %1325

; <label>:1199                                    ; preds = %1184
  %1200 = call i32 @dx.op.binary.i32(i32 37, i32 %1045, i32 0)  ; IMax(a,b)
  %1201 = call i32 @dx.op.binary.i32(i32 37, i32 %1190, i32 0)  ; IMax(a,b)
  %1202 = call i32 @dx.op.binary.i32(i32 38, i32 %1200, i32 %31)  ; IMin(a,b)
  %1203 = call i32 @dx.op.binary.i32(i32 38, i32 %1201, i32 %32)  ; IMin(a,b)
  %1204 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1202, i32 %1203, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1205 = extractvalue %dx.types.ResRet.f32 %1204, 0
  %1206 = extractvalue %dx.types.ResRet.f32 %1204, 1
  %1207 = extractvalue %dx.types.ResRet.f32 %1204, 2
  %1208 = extractvalue %dx.types.ResRet.f32 %1204, 3
  %1209 = fcmp fast olt float %1208, 0.000000e+00
  br i1 %1209, label %1210, label %1244

; <label>:1210                                    ; preds = %1199
  %1211 = fcmp fast ogt float %1205, 0x3FA4B5DCC0000000
  %1212 = fcmp fast ogt float %1206, 0x3FA4B5DCC0000000
  %1213 = fcmp fast ogt float %1207, 0x3FA4B5DCC0000000
  %1214 = select i1 %1211, float 0.000000e+00, float 1.000000e+00
  %1215 = select i1 %1212, float 0.000000e+00, float 1.000000e+00
  %1216 = select i1 %1213, float 0.000000e+00, float 1.000000e+00
  %1217 = fmul fast float %1205, 0x3FB3D07220000000
  %1218 = fmul fast float %1206, 0x3FB3D07220000000
  %1219 = fmul fast float %1207, 0x3FB3D07220000000
  %1220 = fadd fast float %1205, 0x3FAC28F5C0000000
  %1221 = fadd fast float %1206, 0x3FAC28F5C0000000
  %1222 = fadd fast float %1207, 0x3FAC28F5C0000000
  %1223 = fmul fast float %1220, 0x3FEE54EDE0000000
  %1224 = fmul fast float %1221, 0x3FEE54EDE0000000
  %1225 = fmul fast float %1222, 0x3FEE54EDE0000000
  %1226 = call float @dx.op.unary.f32(i32 23, float %1223)  ; Log(value)
  %1227 = call float @dx.op.unary.f32(i32 23, float %1224)  ; Log(value)
  %1228 = call float @dx.op.unary.f32(i32 23, float %1225)  ; Log(value)
  %1229 = fmul fast float %1226, 0x4003333340000000
  %1230 = fmul fast float %1227, 0x4003333340000000
  %1231 = fmul fast float %1228, 0x4003333340000000
  %1232 = call float @dx.op.unary.f32(i32 21, float %1229)  ; Exp(value)
  %1233 = call float @dx.op.unary.f32(i32 21, float %1230)  ; Exp(value)
  %1234 = call float @dx.op.unary.f32(i32 21, float %1231)  ; Exp(value)
  %1235 = fsub fast float %1217, %1232
  %1236 = fsub fast float %1218, %1233
  %1237 = fsub fast float %1219, %1234
  %1238 = fmul fast float %1235, %1214
  %1239 = fmul fast float %1236, %1215
  %1240 = fmul fast float %1237, %1216
  %1241 = fadd fast float %1238, %1232
  %1242 = fadd fast float %1239, %1233
  %1243 = fadd fast float %1240, %1234
  br label %1312

; <label>:1244                                    ; preds = %1199
  %1245 = fadd fast float %6, 1.000000e+00
  %1246 = fadd fast float %7, 1.000000e+00
  %1247 = fsub fast float 1.000000e+00, %6
  %1248 = fmul fast float %10, %1245
  %1249 = fmul fast float %10, %1246
  %1250 = fmul fast float %10, %1247
  %1251 = fmul fast float %1248, %1205
  %1252 = fmul fast float %1249, %1206
  %1253 = fmul fast float %1250, %1207
  %1254 = fcmp fast ult float %11, 5.000000e-01
  br i1 %1254, label %1280, label %1255

; <label>:1255                                    ; preds = %1244
  %1256 = fmul fast float %1251, 0x4004147AE0000000
  %1257 = fmul fast float %1252, 0x4004147AE0000000
  %1258 = fmul fast float %1253, 0x4004147AE0000000
  %1259 = fadd fast float %1256, 0x3F9EB851E0000000
  %1260 = fadd fast float %1257, 0x3F9EB851E0000000
  %1261 = fadd fast float %1258, 0x3F9EB851E0000000
  %1262 = fmul fast float %1259, %1251
  %1263 = fmul fast float %1260, %1252
  %1264 = fmul fast float %1261, %1253
  %1265 = fmul fast float %1251, 0x400370A3E0000000
  %1266 = fmul fast float %1252, 0x400370A3E0000000
  %1267 = fmul fast float %1253, 0x400370A3E0000000
  %1268 = fadd fast float %1265, 0x3FE2E147A0000000
  %1269 = fadd fast float %1266, 0x3FE2E147A0000000
  %1270 = fadd fast float %1267, 0x3FE2E147A0000000
  %1271 = fmul fast float %1268, %1251
  %1272 = fmul fast float %1269, %1252
  %1273 = fmul fast float %1270, %1253
  %1274 = fadd fast float %1271, 0x3FC1EB8520000000
  %1275 = fadd fast float %1272, 0x3FC1EB8520000000
  %1276 = fadd fast float %1273, 0x3FC1EB8520000000
  %1277 = fdiv fast float %1262, %1274
  %1278 = fdiv fast float %1263, %1275
  %1279 = fdiv fast float %1264, %1276
  br label %1280

; <label>:1280                                    ; preds = %1255, %1244
  %1281 = phi float [ %1277, %1255 ], [ %1251, %1244 ]
  %1282 = phi float [ %1278, %1255 ], [ %1252, %1244 ]
  %1283 = phi float [ %1279, %1255 ], [ %1253, %1244 ]
  %1284 = call float @dx.op.unary.f32(i32 7, float %1281)  ; Saturate(value)
  %1285 = call float @dx.op.unary.f32(i32 7, float %1282)  ; Saturate(value)
  %1286 = call float @dx.op.unary.f32(i32 7, float %1283)  ; Saturate(value)
  %1287 = call float @dx.op.dot3.f32(i32 55, float %1284, float %1285, float %1286, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1288 = fsub fast float %1284, %1287
  %1289 = fsub fast float %1285, %1287
  %1290 = fsub fast float %1286, %1287
  %1291 = fmul fast float %1288, %9
  %1292 = fmul fast float %1289, %9
  %1293 = fmul fast float %1290, %9
  %1294 = fadd fast float %1291, %1287
  %1295 = fadd fast float %1292, %1287
  %1296 = fadd fast float %1293, %1287
  %1297 = call float @dx.op.unary.f32(i32 7, float %1294)  ; Saturate(value)
  %1298 = call float @dx.op.unary.f32(i32 7, float %1295)  ; Saturate(value)
  %1299 = call float @dx.op.unary.f32(i32 7, float %1296)  ; Saturate(value)
  %1300 = fadd fast float %1297, 0xBFC70A3D80000000
  %1301 = fadd fast float %1298, 0xBFC70A3D80000000
  %1302 = fadd fast float %1299, 0xBFC70A3D80000000
  %1303 = fmul fast float %1300, %8
  %1304 = fmul fast float %1301, %8
  %1305 = fmul fast float %1302, %8
  %1306 = fadd fast float %1303, 0x3FC70A3D80000000
  %1307 = fadd fast float %1304, 0x3FC70A3D80000000
  %1308 = fadd fast float %1305, 0x3FC70A3D80000000
  %1309 = call float @dx.op.unary.f32(i32 7, float %1306)  ; Saturate(value)
  %1310 = call float @dx.op.unary.f32(i32 7, float %1307)  ; Saturate(value)
  %1311 = call float @dx.op.unary.f32(i32 7, float %1308)  ; Saturate(value)
  br label %1312

; <label>:1312                                    ; preds = %1280, %1210
  %1313 = phi float [ %1241, %1210 ], [ %1309, %1280 ]
  %1314 = phi float [ %1242, %1210 ], [ %1310, %1280 ]
  %1315 = phi float [ %1243, %1210 ], [ %1311, %1280 ]
  %1316 = fsub fast float %1313, %1037
  %1317 = fsub fast float %1314, %1038
  %1318 = fsub fast float %1315, %1039
  %1319 = fmul fast float %1316, %1197
  %1320 = fmul fast float %1317, %1197
  %1321 = fmul fast float %1318, %1197
  %1322 = fadd fast float %1319, %1037
  %1323 = fadd fast float %1320, %1038
  %1324 = fadd fast float %1321, %1039
  br label %1325

; <label>:1325                                    ; preds = %1312, %1184
  %1326 = phi float [ %1322, %1312 ], [ %1037, %1184 ]
  %1327 = phi float [ %1323, %1312 ], [ %1038, %1184 ]
  %1328 = phi float [ %1324, %1312 ], [ %1039, %1184 ]
  %1329 = add i32 %39, -1
  %1330 = call i32 @dx.op.binary.i32(i32 37, i32 %1329, i32 0)  ; IMax(a,b)
  %1331 = call i32 @dx.op.binary.i32(i32 37, i32 %36, i32 0)  ; IMax(a,b)
  %1332 = call i32 @dx.op.binary.i32(i32 38, i32 %1330, i32 %31)  ; IMin(a,b)
  %1333 = call i32 @dx.op.binary.i32(i32 38, i32 %1331, i32 %32)  ; IMin(a,b)
  %1334 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1332, i32 %1333, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1335 = extractvalue %dx.types.ResRet.f32 %1334, 0
  %1336 = fsub fast float %1335, %56
  %1337 = call float @dx.op.unary.f32(i32 6, float %1336)  ; FAbs(value)
  %1338 = fdiv fast float %1337, %1051
  %1339 = fsub fast float 1.000000e+00, %1338
  %1340 = call float @dx.op.unary.f32(i32 7, float %1339)  ; Saturate(value)
  %1341 = fcmp fast ugt float %1340, 0.000000e+00
  br i1 %1341, label %1342, label %1468

; <label>:1342                                    ; preds = %1325
  %1343 = call i32 @dx.op.binary.i32(i32 37, i32 %1332, i32 0)  ; IMax(a,b)
  %1344 = call i32 @dx.op.binary.i32(i32 37, i32 %1333, i32 0)  ; IMax(a,b)
  %1345 = call i32 @dx.op.binary.i32(i32 38, i32 %1343, i32 %31)  ; IMin(a,b)
  %1346 = call i32 @dx.op.binary.i32(i32 38, i32 %1344, i32 %32)  ; IMin(a,b)
  %1347 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1345, i32 %1346, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1348 = extractvalue %dx.types.ResRet.f32 %1347, 0
  %1349 = extractvalue %dx.types.ResRet.f32 %1347, 1
  %1350 = extractvalue %dx.types.ResRet.f32 %1347, 2
  %1351 = extractvalue %dx.types.ResRet.f32 %1347, 3
  %1352 = fcmp fast olt float %1351, 0.000000e+00
  br i1 %1352, label %1353, label %1387

; <label>:1353                                    ; preds = %1342
  %1354 = fcmp fast ogt float %1348, 0x3FA4B5DCC0000000
  %1355 = fcmp fast ogt float %1349, 0x3FA4B5DCC0000000
  %1356 = fcmp fast ogt float %1350, 0x3FA4B5DCC0000000
  %1357 = select i1 %1354, float 0.000000e+00, float 1.000000e+00
  %1358 = select i1 %1355, float 0.000000e+00, float 1.000000e+00
  %1359 = select i1 %1356, float 0.000000e+00, float 1.000000e+00
  %1360 = fmul fast float %1348, 0x3FB3D07220000000
  %1361 = fmul fast float %1349, 0x3FB3D07220000000
  %1362 = fmul fast float %1350, 0x3FB3D07220000000
  %1363 = fadd fast float %1348, 0x3FAC28F5C0000000
  %1364 = fadd fast float %1349, 0x3FAC28F5C0000000
  %1365 = fadd fast float %1350, 0x3FAC28F5C0000000
  %1366 = fmul fast float %1363, 0x3FEE54EDE0000000
  %1367 = fmul fast float %1364, 0x3FEE54EDE0000000
  %1368 = fmul fast float %1365, 0x3FEE54EDE0000000
  %1369 = call float @dx.op.unary.f32(i32 23, float %1366)  ; Log(value)
  %1370 = call float @dx.op.unary.f32(i32 23, float %1367)  ; Log(value)
  %1371 = call float @dx.op.unary.f32(i32 23, float %1368)  ; Log(value)
  %1372 = fmul fast float %1369, 0x4003333340000000
  %1373 = fmul fast float %1370, 0x4003333340000000
  %1374 = fmul fast float %1371, 0x4003333340000000
  %1375 = call float @dx.op.unary.f32(i32 21, float %1372)  ; Exp(value)
  %1376 = call float @dx.op.unary.f32(i32 21, float %1373)  ; Exp(value)
  %1377 = call float @dx.op.unary.f32(i32 21, float %1374)  ; Exp(value)
  %1378 = fsub fast float %1360, %1375
  %1379 = fsub fast float %1361, %1376
  %1380 = fsub fast float %1362, %1377
  %1381 = fmul fast float %1378, %1357
  %1382 = fmul fast float %1379, %1358
  %1383 = fmul fast float %1380, %1359
  %1384 = fadd fast float %1381, %1375
  %1385 = fadd fast float %1382, %1376
  %1386 = fadd fast float %1383, %1377
  br label %1455

; <label>:1387                                    ; preds = %1342
  %1388 = fadd fast float %6, 1.000000e+00
  %1389 = fadd fast float %7, 1.000000e+00
  %1390 = fsub fast float 1.000000e+00, %6
  %1391 = fmul fast float %10, %1388
  %1392 = fmul fast float %10, %1389
  %1393 = fmul fast float %10, %1390
  %1394 = fmul fast float %1391, %1348
  %1395 = fmul fast float %1392, %1349
  %1396 = fmul fast float %1393, %1350
  %1397 = fcmp fast ult float %11, 5.000000e-01
  br i1 %1397, label %1423, label %1398

; <label>:1398                                    ; preds = %1387
  %1399 = fmul fast float %1394, 0x4004147AE0000000
  %1400 = fmul fast float %1395, 0x4004147AE0000000
  %1401 = fmul fast float %1396, 0x4004147AE0000000
  %1402 = fadd fast float %1399, 0x3F9EB851E0000000
  %1403 = fadd fast float %1400, 0x3F9EB851E0000000
  %1404 = fadd fast float %1401, 0x3F9EB851E0000000
  %1405 = fmul fast float %1402, %1394
  %1406 = fmul fast float %1403, %1395
  %1407 = fmul fast float %1404, %1396
  %1408 = fmul fast float %1394, 0x400370A3E0000000
  %1409 = fmul fast float %1395, 0x400370A3E0000000
  %1410 = fmul fast float %1396, 0x400370A3E0000000
  %1411 = fadd fast float %1408, 0x3FE2E147A0000000
  %1412 = fadd fast float %1409, 0x3FE2E147A0000000
  %1413 = fadd fast float %1410, 0x3FE2E147A0000000
  %1414 = fmul fast float %1411, %1394
  %1415 = fmul fast float %1412, %1395
  %1416 = fmul fast float %1413, %1396
  %1417 = fadd fast float %1414, 0x3FC1EB8520000000
  %1418 = fadd fast float %1415, 0x3FC1EB8520000000
  %1419 = fadd fast float %1416, 0x3FC1EB8520000000
  %1420 = fdiv fast float %1405, %1417
  %1421 = fdiv fast float %1406, %1418
  %1422 = fdiv fast float %1407, %1419
  br label %1423

; <label>:1423                                    ; preds = %1398, %1387
  %1424 = phi float [ %1420, %1398 ], [ %1394, %1387 ]
  %1425 = phi float [ %1421, %1398 ], [ %1395, %1387 ]
  %1426 = phi float [ %1422, %1398 ], [ %1396, %1387 ]
  %1427 = call float @dx.op.unary.f32(i32 7, float %1424)  ; Saturate(value)
  %1428 = call float @dx.op.unary.f32(i32 7, float %1425)  ; Saturate(value)
  %1429 = call float @dx.op.unary.f32(i32 7, float %1426)  ; Saturate(value)
  %1430 = call float @dx.op.dot3.f32(i32 55, float %1427, float %1428, float %1429, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1431 = fsub fast float %1427, %1430
  %1432 = fsub fast float %1428, %1430
  %1433 = fsub fast float %1429, %1430
  %1434 = fmul fast float %1431, %9
  %1435 = fmul fast float %1432, %9
  %1436 = fmul fast float %1433, %9
  %1437 = fadd fast float %1434, %1430
  %1438 = fadd fast float %1435, %1430
  %1439 = fadd fast float %1436, %1430
  %1440 = call float @dx.op.unary.f32(i32 7, float %1437)  ; Saturate(value)
  %1441 = call float @dx.op.unary.f32(i32 7, float %1438)  ; Saturate(value)
  %1442 = call float @dx.op.unary.f32(i32 7, float %1439)  ; Saturate(value)
  %1443 = fadd fast float %1440, 0xBFC70A3D80000000
  %1444 = fadd fast float %1441, 0xBFC70A3D80000000
  %1445 = fadd fast float %1442, 0xBFC70A3D80000000
  %1446 = fmul fast float %1443, %8
  %1447 = fmul fast float %1444, %8
  %1448 = fmul fast float %1445, %8
  %1449 = fadd fast float %1446, 0x3FC70A3D80000000
  %1450 = fadd fast float %1447, 0x3FC70A3D80000000
  %1451 = fadd fast float %1448, 0x3FC70A3D80000000
  %1452 = call float @dx.op.unary.f32(i32 7, float %1449)  ; Saturate(value)
  %1453 = call float @dx.op.unary.f32(i32 7, float %1450)  ; Saturate(value)
  %1454 = call float @dx.op.unary.f32(i32 7, float %1451)  ; Saturate(value)
  br label %1455

; <label>:1455                                    ; preds = %1423, %1353
  %1456 = phi float [ %1384, %1353 ], [ %1452, %1423 ]
  %1457 = phi float [ %1385, %1353 ], [ %1453, %1423 ]
  %1458 = phi float [ %1386, %1353 ], [ %1454, %1423 ]
  %1459 = fsub fast float %1456, %1037
  %1460 = fsub fast float %1457, %1038
  %1461 = fsub fast float %1458, %1039
  %1462 = fmul fast float %1459, %1340
  %1463 = fmul fast float %1460, %1340
  %1464 = fmul fast float %1461, %1340
  %1465 = fadd fast float %1462, %1037
  %1466 = fadd fast float %1463, %1038
  %1467 = fadd fast float %1464, %1039
  br label %1468

; <label>:1468                                    ; preds = %1455, %1325
  %1469 = phi float [ %1465, %1455 ], [ %1037, %1325 ]
  %1470 = phi float [ %1466, %1455 ], [ %1038, %1325 ]
  %1471 = phi float [ %1467, %1455 ], [ %1039, %1325 ]
  %1472 = add i32 %39, 1
  %1473 = call i32 @dx.op.binary.i32(i32 37, i32 %1472, i32 0)  ; IMax(a,b)
  %1474 = call i32 @dx.op.binary.i32(i32 38, i32 %1473, i32 %31)  ; IMin(a,b)
  %1475 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1474, i32 %1333, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1476 = extractvalue %dx.types.ResRet.f32 %1475, 0
  %1477 = fsub fast float %1476, %56
  %1478 = call float @dx.op.unary.f32(i32 6, float %1477)  ; FAbs(value)
  %1479 = fdiv fast float %1478, %1051
  %1480 = fsub fast float 1.000000e+00, %1479
  %1481 = call float @dx.op.unary.f32(i32 7, float %1480)  ; Saturate(value)
  %1482 = fcmp fast ugt float %1481, 0.000000e+00
  br i1 %1482, label %1483, label %1609

; <label>:1483                                    ; preds = %1468
  %1484 = call i32 @dx.op.binary.i32(i32 37, i32 %1474, i32 0)  ; IMax(a,b)
  %1485 = call i32 @dx.op.binary.i32(i32 37, i32 %1333, i32 0)  ; IMax(a,b)
  %1486 = call i32 @dx.op.binary.i32(i32 38, i32 %1484, i32 %31)  ; IMin(a,b)
  %1487 = call i32 @dx.op.binary.i32(i32 38, i32 %1485, i32 %32)  ; IMin(a,b)
  %1488 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1486, i32 %1487, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1489 = extractvalue %dx.types.ResRet.f32 %1488, 0
  %1490 = extractvalue %dx.types.ResRet.f32 %1488, 1
  %1491 = extractvalue %dx.types.ResRet.f32 %1488, 2
  %1492 = extractvalue %dx.types.ResRet.f32 %1488, 3
  %1493 = fcmp fast olt float %1492, 0.000000e+00
  br i1 %1493, label %1494, label %1528

; <label>:1494                                    ; preds = %1483
  %1495 = fcmp fast ogt float %1489, 0x3FA4B5DCC0000000
  %1496 = fcmp fast ogt float %1490, 0x3FA4B5DCC0000000
  %1497 = fcmp fast ogt float %1491, 0x3FA4B5DCC0000000
  %1498 = select i1 %1495, float 0.000000e+00, float 1.000000e+00
  %1499 = select i1 %1496, float 0.000000e+00, float 1.000000e+00
  %1500 = select i1 %1497, float 0.000000e+00, float 1.000000e+00
  %1501 = fmul fast float %1489, 0x3FB3D07220000000
  %1502 = fmul fast float %1490, 0x3FB3D07220000000
  %1503 = fmul fast float %1491, 0x3FB3D07220000000
  %1504 = fadd fast float %1489, 0x3FAC28F5C0000000
  %1505 = fadd fast float %1490, 0x3FAC28F5C0000000
  %1506 = fadd fast float %1491, 0x3FAC28F5C0000000
  %1507 = fmul fast float %1504, 0x3FEE54EDE0000000
  %1508 = fmul fast float %1505, 0x3FEE54EDE0000000
  %1509 = fmul fast float %1506, 0x3FEE54EDE0000000
  %1510 = call float @dx.op.unary.f32(i32 23, float %1507)  ; Log(value)
  %1511 = call float @dx.op.unary.f32(i32 23, float %1508)  ; Log(value)
  %1512 = call float @dx.op.unary.f32(i32 23, float %1509)  ; Log(value)
  %1513 = fmul fast float %1510, 0x4003333340000000
  %1514 = fmul fast float %1511, 0x4003333340000000
  %1515 = fmul fast float %1512, 0x4003333340000000
  %1516 = call float @dx.op.unary.f32(i32 21, float %1513)  ; Exp(value)
  %1517 = call float @dx.op.unary.f32(i32 21, float %1514)  ; Exp(value)
  %1518 = call float @dx.op.unary.f32(i32 21, float %1515)  ; Exp(value)
  %1519 = fsub fast float %1501, %1516
  %1520 = fsub fast float %1502, %1517
  %1521 = fsub fast float %1503, %1518
  %1522 = fmul fast float %1519, %1498
  %1523 = fmul fast float %1520, %1499
  %1524 = fmul fast float %1521, %1500
  %1525 = fadd fast float %1522, %1516
  %1526 = fadd fast float %1523, %1517
  %1527 = fadd fast float %1524, %1518
  br label %1596

; <label>:1528                                    ; preds = %1483
  %1529 = fadd fast float %6, 1.000000e+00
  %1530 = fadd fast float %7, 1.000000e+00
  %1531 = fsub fast float 1.000000e+00, %6
  %1532 = fmul fast float %10, %1529
  %1533 = fmul fast float %10, %1530
  %1534 = fmul fast float %10, %1531
  %1535 = fmul fast float %1532, %1489
  %1536 = fmul fast float %1533, %1490
  %1537 = fmul fast float %1534, %1491
  %1538 = fcmp fast ult float %11, 5.000000e-01
  br i1 %1538, label %1564, label %1539

; <label>:1539                                    ; preds = %1528
  %1540 = fmul fast float %1535, 0x4004147AE0000000
  %1541 = fmul fast float %1536, 0x4004147AE0000000
  %1542 = fmul fast float %1537, 0x4004147AE0000000
  %1543 = fadd fast float %1540, 0x3F9EB851E0000000
  %1544 = fadd fast float %1541, 0x3F9EB851E0000000
  %1545 = fadd fast float %1542, 0x3F9EB851E0000000
  %1546 = fmul fast float %1543, %1535
  %1547 = fmul fast float %1544, %1536
  %1548 = fmul fast float %1545, %1537
  %1549 = fmul fast float %1535, 0x400370A3E0000000
  %1550 = fmul fast float %1536, 0x400370A3E0000000
  %1551 = fmul fast float %1537, 0x400370A3E0000000
  %1552 = fadd fast float %1549, 0x3FE2E147A0000000
  %1553 = fadd fast float %1550, 0x3FE2E147A0000000
  %1554 = fadd fast float %1551, 0x3FE2E147A0000000
  %1555 = fmul fast float %1552, %1535
  %1556 = fmul fast float %1553, %1536
  %1557 = fmul fast float %1554, %1537
  %1558 = fadd fast float %1555, 0x3FC1EB8520000000
  %1559 = fadd fast float %1556, 0x3FC1EB8520000000
  %1560 = fadd fast float %1557, 0x3FC1EB8520000000
  %1561 = fdiv fast float %1546, %1558
  %1562 = fdiv fast float %1547, %1559
  %1563 = fdiv fast float %1548, %1560
  br label %1564

; <label>:1564                                    ; preds = %1539, %1528
  %1565 = phi float [ %1561, %1539 ], [ %1535, %1528 ]
  %1566 = phi float [ %1562, %1539 ], [ %1536, %1528 ]
  %1567 = phi float [ %1563, %1539 ], [ %1537, %1528 ]
  %1568 = call float @dx.op.unary.f32(i32 7, float %1565)  ; Saturate(value)
  %1569 = call float @dx.op.unary.f32(i32 7, float %1566)  ; Saturate(value)
  %1570 = call float @dx.op.unary.f32(i32 7, float %1567)  ; Saturate(value)
  %1571 = call float @dx.op.dot3.f32(i32 55, float %1568, float %1569, float %1570, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1572 = fsub fast float %1568, %1571
  %1573 = fsub fast float %1569, %1571
  %1574 = fsub fast float %1570, %1571
  %1575 = fmul fast float %1572, %9
  %1576 = fmul fast float %1573, %9
  %1577 = fmul fast float %1574, %9
  %1578 = fadd fast float %1575, %1571
  %1579 = fadd fast float %1576, %1571
  %1580 = fadd fast float %1577, %1571
  %1581 = call float @dx.op.unary.f32(i32 7, float %1578)  ; Saturate(value)
  %1582 = call float @dx.op.unary.f32(i32 7, float %1579)  ; Saturate(value)
  %1583 = call float @dx.op.unary.f32(i32 7, float %1580)  ; Saturate(value)
  %1584 = fadd fast float %1581, 0xBFC70A3D80000000
  %1585 = fadd fast float %1582, 0xBFC70A3D80000000
  %1586 = fadd fast float %1583, 0xBFC70A3D80000000
  %1587 = fmul fast float %1584, %8
  %1588 = fmul fast float %1585, %8
  %1589 = fmul fast float %1586, %8
  %1590 = fadd fast float %1587, 0x3FC70A3D80000000
  %1591 = fadd fast float %1588, 0x3FC70A3D80000000
  %1592 = fadd fast float %1589, 0x3FC70A3D80000000
  %1593 = call float @dx.op.unary.f32(i32 7, float %1590)  ; Saturate(value)
  %1594 = call float @dx.op.unary.f32(i32 7, float %1591)  ; Saturate(value)
  %1595 = call float @dx.op.unary.f32(i32 7, float %1592)  ; Saturate(value)
  br label %1596

; <label>:1596                                    ; preds = %1564, %1494
  %1597 = phi float [ %1525, %1494 ], [ %1593, %1564 ]
  %1598 = phi float [ %1526, %1494 ], [ %1594, %1564 ]
  %1599 = phi float [ %1527, %1494 ], [ %1595, %1564 ]
  %1600 = fsub fast float %1597, %1037
  %1601 = fsub fast float %1598, %1038
  %1602 = fsub fast float %1599, %1039
  %1603 = fmul fast float %1600, %1481
  %1604 = fmul fast float %1601, %1481
  %1605 = fmul fast float %1602, %1481
  %1606 = fadd fast float %1603, %1037
  %1607 = fadd fast float %1604, %1038
  %1608 = fadd fast float %1605, %1039
  br label %1609

; <label>:1609                                    ; preds = %1596, %1468
  %1610 = phi float [ %1606, %1596 ], [ %1037, %1468 ]
  %1611 = phi float [ %1607, %1596 ], [ %1038, %1468 ]
  %1612 = phi float [ %1608, %1596 ], [ %1039, %1468 ]
  %1613 = call float @dx.op.binary.f32(i32 36, float %1469, float %1610)  ; FMin(a,b)
  %1614 = call float @dx.op.binary.f32(i32 36, float %1470, float %1611)  ; FMin(a,b)
  %1615 = call float @dx.op.binary.f32(i32 36, float %1471, float %1612)  ; FMin(a,b)
  %1616 = call float @dx.op.binary.f32(i32 36, float %1185, float %1326)  ; FMin(a,b)
  %1617 = call float @dx.op.binary.f32(i32 36, float %1186, float %1327)  ; FMin(a,b)
  %1618 = call float @dx.op.binary.f32(i32 36, float %1187, float %1328)  ; FMin(a,b)
  %1619 = call float @dx.op.binary.f32(i32 36, float %1616, float %1613)  ; FMin(a,b)
  %1620 = call float @dx.op.binary.f32(i32 36, float %1617, float %1614)  ; FMin(a,b)
  %1621 = call float @dx.op.binary.f32(i32 36, float %1618, float %1615)  ; FMin(a,b)
  %1622 = call float @dx.op.binary.f32(i32 36, float %1037, float %1619)  ; FMin(a,b)
  %1623 = call float @dx.op.binary.f32(i32 36, float %1038, float %1620)  ; FMin(a,b)
  %1624 = call float @dx.op.binary.f32(i32 36, float %1039, float %1621)  ; FMin(a,b)
  %1625 = call float @dx.op.binary.f32(i32 35, float %1469, float %1610)  ; FMax(a,b)
  %1626 = call float @dx.op.binary.f32(i32 35, float %1470, float %1611)  ; FMax(a,b)
  %1627 = call float @dx.op.binary.f32(i32 35, float %1471, float %1612)  ; FMax(a,b)
  %1628 = call float @dx.op.binary.f32(i32 35, float %1185, float %1326)  ; FMax(a,b)
  %1629 = call float @dx.op.binary.f32(i32 35, float %1186, float %1327)  ; FMax(a,b)
  %1630 = call float @dx.op.binary.f32(i32 35, float %1187, float %1328)  ; FMax(a,b)
  %1631 = call float @dx.op.binary.f32(i32 35, float %1628, float %1625)  ; FMax(a,b)
  %1632 = call float @dx.op.binary.f32(i32 35, float %1629, float %1626)  ; FMax(a,b)
  %1633 = call float @dx.op.binary.f32(i32 35, float %1630, float %1627)  ; FMax(a,b)
  %1634 = call float @dx.op.binary.f32(i32 35, float %1037, float %1631)  ; FMax(a,b)
  %1635 = call float @dx.op.binary.f32(i32 35, float %1038, float %1632)  ; FMax(a,b)
  %1636 = call float @dx.op.binary.f32(i32 35, float %1039, float %1633)  ; FMax(a,b)
  %1637 = fsub fast float %1634, %1622
  %1638 = fsub fast float %1635, %1623
  %1639 = fsub fast float %1636, %1624
  %1640 = call float @dx.op.unary.f32(i32 6, float %1637)  ; FAbs(value)
  %1641 = call float @dx.op.unary.f32(i32 6, float %1638)  ; FAbs(value)
  %1642 = call float @dx.op.unary.f32(i32 6, float %1639)  ; FAbs(value)
  %1643 = call float @dx.op.binary.f32(i32 35, float %1641, float %1642)  ; FMax(a,b)
  %1644 = call float @dx.op.binary.f32(i32 35, float %1640, float %1643)  ; FMax(a,b)
  %1645 = call float @dx.op.binary.f32(i32 35, float %1635, float %1636)  ; FMax(a,b)
  %1646 = call float @dx.op.binary.f32(i32 35, float %1634, float %1645)  ; FMax(a,b)
  %1647 = fmul fast float %1646, 1.250000e-01
  %1648 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1647)  ; FMax(a,b)
  %1649 = fcmp fast ogt float %1644, %1648
  br i1 %1649, label %1650, label %1712

; <label>:1650                                    ; preds = %1609
  %1651 = fsub fast float %1185, %1326
  %1652 = fsub fast float %1186, %1327
  %1653 = fsub fast float %1187, %1328
  %1654 = call float @dx.op.unary.f32(i32 6, float %1651)  ; FAbs(value)
  %1655 = call float @dx.op.unary.f32(i32 6, float %1652)  ; FAbs(value)
  %1656 = call float @dx.op.unary.f32(i32 6, float %1653)  ; FAbs(value)
  %1657 = call float @dx.op.binary.f32(i32 35, float %1655, float %1656)  ; FMax(a,b)
  %1658 = call float @dx.op.binary.f32(i32 35, float %1654, float %1657)  ; FMax(a,b)
  %1659 = fsub fast float %1469, %1610
  %1660 = fsub fast float %1470, %1611
  %1661 = fsub fast float %1471, %1612
  %1662 = call float @dx.op.unary.f32(i32 6, float %1659)  ; FAbs(value)
  %1663 = call float @dx.op.unary.f32(i32 6, float %1660)  ; FAbs(value)
  %1664 = call float @dx.op.unary.f32(i32 6, float %1661)  ; FAbs(value)
  %1665 = call float @dx.op.binary.f32(i32 35, float %1663, float %1664)  ; FMax(a,b)
  %1666 = call float @dx.op.binary.f32(i32 35, float %1662, float %1665)  ; FMax(a,b)
  %1667 = fcmp fast olt float %1658, %1666
  %1668 = select i1 %1667, float %1185, float %1469
  %1669 = select i1 %1667, float %1186, float %1470
  %1670 = select i1 %1667, float %1187, float %1471
  %1671 = select i1 %1667, float %1326, float %1610
  %1672 = select i1 %1667, float %1327, float %1611
  %1673 = select i1 %1667, float %1328, float %1612
  %1674 = fsub fast float %1037, %1671
  %1675 = fsub fast float %1038, %1672
  %1676 = fsub fast float %1039, %1673
  %1677 = fsub fast float %1037, %1668
  %1678 = fsub fast float %1038, %1669
  %1679 = fsub fast float %1039, %1670
  %1680 = call float @dx.op.dot3.f32(i32 55, float %1677, float %1678, float %1679, float %1674, float %1675, float %1676)  ; Dot3(ax,ay,az,bx,by,bz)
  %1681 = fcmp fast ogt float %1680, 0.000000e+00
  br i1 %1681, label %1682, label %1693

; <label>:1682                                    ; preds = %1650
  %1683 = fsub fast float %1668, %1671
  %1684 = fsub fast float %1669, %1672
  %1685 = fsub fast float %1670, %1673
  %1686 = call float @dx.op.unary.f32(i32 6, float %1683)  ; FAbs(value)
  %1687 = call float @dx.op.unary.f32(i32 6, float %1684)  ; FAbs(value)
  %1688 = call float @dx.op.unary.f32(i32 6, float %1685)  ; FAbs(value)
  %1689 = call float @dx.op.binary.f32(i32 35, float %1687, float %1688)  ; FMax(a,b)
  %1690 = call float @dx.op.binary.f32(i32 35, float %1686, float %1689)  ; FMax(a,b)
  %1691 = fmul fast float %1644, 2.500000e-01
  %1692 = fcmp fast olt float %1690, %1691
  br label %1693

; <label>:1693                                    ; preds = %1682, %1650
  %1694 = phi i1 [ false, %1650 ], [ %1692, %1682 ]
  %1695 = select i1 %1694, float 5.000000e-01, float 1.000000e+00
  %1696 = fmul fast float %1695, %3
  %1697 = fadd fast float %1668, %1671
  %1698 = fadd fast float %1669, %1672
  %1699 = fadd fast float %1670, %1673
  %1700 = fmul fast float %1697, 5.000000e-01
  %1701 = fmul fast float %1698, 5.000000e-01
  %1702 = fmul fast float %1699, 5.000000e-01
  %1703 = fsub fast float %1700, %1037
  %1704 = fsub fast float %1701, %1038
  %1705 = fsub fast float %1702, %1039
  %1706 = fmul fast float %1696, %1703
  %1707 = fmul fast float %1696, %1704
  %1708 = fmul fast float %1696, %1705
  %1709 = fadd fast float %1706, %1037
  %1710 = fadd fast float %1707, %1038
  %1711 = fadd fast float %1708, %1039
  br label %1712

; <label>:1712                                    ; preds = %1693, %1609, %1008
  %1713 = phi float [ %1037, %1008 ], [ %1709, %1693 ], [ %1037, %1609 ]
  %1714 = phi float [ %1038, %1008 ], [ %1710, %1693 ], [ %1038, %1609 ]
  %1715 = phi float [ %1039, %1008 ], [ %1711, %1693 ], [ %1039, %1609 ]
  %1716 = fcmp fast ogt float %1713, 0x3F69A5C380000000
  %1717 = fcmp fast ogt float %1714, 0x3F69A5C380000000
  %1718 = fcmp fast ogt float %1715, 0x3F69A5C380000000
  %1719 = select i1 %1716, float 0.000000e+00, float 1.000000e+00
  %1720 = select i1 %1717, float 0.000000e+00, float 1.000000e+00
  %1721 = select i1 %1718, float 0.000000e+00, float 1.000000e+00
  %1722 = fmul fast float %1713, 0x4029D70A40000000
  %1723 = fmul fast float %1714, 0x4029D70A40000000
  %1724 = fmul fast float %1715, 0x4029D70A40000000
  %1725 = call float @dx.op.binary.f32(i32 35, float %1713, float 0.000000e+00)  ; FMax(a,b)
  %1726 = call float @dx.op.binary.f32(i32 35, float %1714, float 0.000000e+00)  ; FMax(a,b)
  %1727 = call float @dx.op.binary.f32(i32 35, float %1715, float 0.000000e+00)  ; FMax(a,b)
  %1728 = call float @dx.op.unary.f32(i32 23, float %1725)  ; Log(value)
  %1729 = call float @dx.op.unary.f32(i32 23, float %1726)  ; Log(value)
  %1730 = call float @dx.op.unary.f32(i32 23, float %1727)  ; Log(value)
  %1731 = fmul fast float %1728, 0x3FDAAAAAA0000000
  %1732 = fmul fast float %1729, 0x3FDAAAAAA0000000
  %1733 = fmul fast float %1730, 0x3FDAAAAAA0000000
  %1734 = call float @dx.op.unary.f32(i32 21, float %1731)  ; Exp(value)
  %1735 = call float @dx.op.unary.f32(i32 21, float %1732)  ; Exp(value)
  %1736 = call float @dx.op.unary.f32(i32 21, float %1733)  ; Exp(value)
  %1737 = fmul fast float %1734, 0x3FF0E147A0000000
  %1738 = fmul fast float %1735, 0x3FF0E147A0000000
  %1739 = fmul fast float %1736, 0x3FF0E147A0000000
  %1740 = fadd fast float %1737, 0xBFAC28F5C0000000
  %1741 = fadd fast float %1738, 0xBFAC28F5C0000000
  %1742 = fadd fast float %1739, 0xBFAC28F5C0000000
  %1743 = fsub fast float %1722, %1740
  %1744 = fsub fast float %1723, %1741
  %1745 = fsub fast float %1724, %1742
  %1746 = fmul fast float %1743, %1719
  %1747 = fmul fast float %1744, %1720
  %1748 = fmul fast float %1745, %1721
  %1749 = fadd fast float %1746, %1740
  %1750 = fadd fast float %1747, %1741
  %1751 = fadd fast float %1748, %1742
  br label %1752

; <label>:1752                                    ; preds = %1712, %970
  %1753 = phi float [ %965, %970 ], [ %1749, %1712 ]
  %1754 = phi float [ %966, %970 ], [ %1750, %1712 ]
  %1755 = phi float [ %967, %970 ], [ %1751, %1712 ]
  %1756 = phi float [ %971, %970 ], [ %968, %1712 ]
  %1757 = fcmp fast ogt float %1753, 0x3FA4B5DCC0000000
  %1758 = fcmp fast ogt float %1754, 0x3FA4B5DCC0000000
  %1759 = fcmp fast ogt float %1755, 0x3FA4B5DCC0000000
  %1760 = select i1 %1757, float 0.000000e+00, float 1.000000e+00
  %1761 = select i1 %1758, float 0.000000e+00, float 1.000000e+00
  %1762 = select i1 %1759, float 0.000000e+00, float 1.000000e+00
  %1763 = fmul fast float %1753, 0x3FB3D07220000000
  %1764 = fmul fast float %1754, 0x3FB3D07220000000
  %1765 = fmul fast float %1755, 0x3FB3D07220000000
  %1766 = fadd fast float %1753, 0x3FAC28F5C0000000
  %1767 = fadd fast float %1754, 0x3FAC28F5C0000000
  %1768 = fadd fast float %1755, 0x3FAC28F5C0000000
  %1769 = fmul fast float %1766, 0x3FEE54EDE0000000
  %1770 = fmul fast float %1767, 0x3FEE54EDE0000000
  %1771 = fmul fast float %1768, 0x3FEE54EDE0000000
  %1772 = call float @dx.op.unary.f32(i32 23, float %1769)  ; Log(value)
  %1773 = call float @dx.op.unary.f32(i32 23, float %1770)  ; Log(value)
  %1774 = call float @dx.op.unary.f32(i32 23, float %1771)  ; Log(value)
  %1775 = fmul fast float %1772, 0x4003333340000000
  %1776 = fmul fast float %1773, 0x4003333340000000
  %1777 = fmul fast float %1774, 0x4003333340000000
  %1778 = call float @dx.op.unary.f32(i32 21, float %1775)  ; Exp(value)
  %1779 = call float @dx.op.unary.f32(i32 21, float %1776)  ; Exp(value)
  %1780 = call float @dx.op.unary.f32(i32 21, float %1777)  ; Exp(value)
  %1781 = fsub fast float %1763, %1778
  %1782 = fsub fast float %1764, %1779
  %1783 = fsub fast float %1765, %1780
  %1784 = fmul fast float %1781, %1760
  %1785 = fmul fast float %1782, %1761
  %1786 = fmul fast float %1783, %1762
  %1787 = fadd fast float %1784, %1778
  %1788 = fadd fast float %1785, %1779
  %1789 = fadd fast float %1786, %1780
  %1790 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %35, i32 %42, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1791 = extractvalue %dx.types.ResRet.f32 %1790, 0
  %1792 = extractvalue %dx.types.ResRet.f32 %1790, 1
  %1793 = extractvalue %dx.types.ResRet.f32 %1790, 2
  %1794 = extractvalue %dx.types.ResRet.f32 %1790, 3
  %1795 = fcmp fast olt float %1794, 0.000000e+00
  br i1 %1795, label %1796, label %1798

; <label>:1796                                    ; preds = %1752
  %1797 = fsub fast float -1.000000e+00, %1794
  br label %2578

; <label>:1798                                    ; preds = %1752
  %1799 = fadd fast float %6, 1.000000e+00
  %1800 = fadd fast float %7, 1.000000e+00
  %1801 = fsub fast float 1.000000e+00, %6
  %1802 = fmul fast float %10, %1799
  %1803 = fmul fast float %10, %1800
  %1804 = fmul fast float %10, %1801
  %1805 = fmul fast float %1802, %1791
  %1806 = fmul fast float %1803, %1792
  %1807 = fmul fast float %1804, %1793
  %1808 = fcmp fast ult float %11, 5.000000e-01
  br i1 %1808, label %1834, label %1809

; <label>:1809                                    ; preds = %1798
  %1810 = fmul fast float %1805, 0x4004147AE0000000
  %1811 = fmul fast float %1806, 0x4004147AE0000000
  %1812 = fmul fast float %1807, 0x4004147AE0000000
  %1813 = fadd fast float %1810, 0x3F9EB851E0000000
  %1814 = fadd fast float %1811, 0x3F9EB851E0000000
  %1815 = fadd fast float %1812, 0x3F9EB851E0000000
  %1816 = fmul fast float %1813, %1805
  %1817 = fmul fast float %1814, %1806
  %1818 = fmul fast float %1815, %1807
  %1819 = fmul fast float %1805, 0x400370A3E0000000
  %1820 = fmul fast float %1806, 0x400370A3E0000000
  %1821 = fmul fast float %1807, 0x400370A3E0000000
  %1822 = fadd fast float %1819, 0x3FE2E147A0000000
  %1823 = fadd fast float %1820, 0x3FE2E147A0000000
  %1824 = fadd fast float %1821, 0x3FE2E147A0000000
  %1825 = fmul fast float %1822, %1805
  %1826 = fmul fast float %1823, %1806
  %1827 = fmul fast float %1824, %1807
  %1828 = fadd fast float %1825, 0x3FC1EB8520000000
  %1829 = fadd fast float %1826, 0x3FC1EB8520000000
  %1830 = fadd fast float %1827, 0x3FC1EB8520000000
  %1831 = fdiv fast float %1816, %1828
  %1832 = fdiv fast float %1817, %1829
  %1833 = fdiv fast float %1818, %1830
  br label %1834

; <label>:1834                                    ; preds = %1809, %1798
  %1835 = phi float [ %1831, %1809 ], [ %1805, %1798 ]
  %1836 = phi float [ %1832, %1809 ], [ %1806, %1798 ]
  %1837 = phi float [ %1833, %1809 ], [ %1807, %1798 ]
  %1838 = call float @dx.op.unary.f32(i32 7, float %1835)  ; Saturate(value)
  %1839 = call float @dx.op.unary.f32(i32 7, float %1836)  ; Saturate(value)
  %1840 = call float @dx.op.unary.f32(i32 7, float %1837)  ; Saturate(value)
  %1841 = call float @dx.op.dot3.f32(i32 55, float %1838, float %1839, float %1840, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1842 = fsub fast float %1838, %1841
  %1843 = fsub fast float %1839, %1841
  %1844 = fsub fast float %1840, %1841
  %1845 = fmul fast float %1842, %9
  %1846 = fmul fast float %1843, %9
  %1847 = fmul fast float %1844, %9
  %1848 = fadd fast float %1845, %1841
  %1849 = fadd fast float %1846, %1841
  %1850 = fadd fast float %1847, %1841
  %1851 = call float @dx.op.unary.f32(i32 7, float %1848)  ; Saturate(value)
  %1852 = call float @dx.op.unary.f32(i32 7, float %1849)  ; Saturate(value)
  %1853 = call float @dx.op.unary.f32(i32 7, float %1850)  ; Saturate(value)
  %1854 = fadd fast float %1851, 0xBFC70A3D80000000
  %1855 = fadd fast float %1852, 0xBFC70A3D80000000
  %1856 = fadd fast float %1853, 0xBFC70A3D80000000
  %1857 = fmul fast float %1854, %8
  %1858 = fmul fast float %1855, %8
  %1859 = fmul fast float %1856, %8
  %1860 = fadd fast float %1857, 0x3FC70A3D80000000
  %1861 = fadd fast float %1858, 0x3FC70A3D80000000
  %1862 = fadd fast float %1859, 0x3FC70A3D80000000
  %1863 = call float @dx.op.unary.f32(i32 7, float %1860)  ; Saturate(value)
  %1864 = call float @dx.op.unary.f32(i32 7, float %1861)  ; Saturate(value)
  %1865 = call float @dx.op.unary.f32(i32 7, float %1862)  ; Saturate(value)
  %1866 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %1866, label %1867, label %2538

; <label>:1867                                    ; preds = %1834
  %1868 = add i32 %42, -1
  %1869 = call i32 @dx.op.binary.i32(i32 37, i32 %35, i32 0)  ; IMax(a,b)
  %1870 = call i32 @dx.op.binary.i32(i32 37, i32 %1868, i32 0)  ; IMax(a,b)
  %1871 = call i32 @dx.op.binary.i32(i32 38, i32 %1869, i32 %31)  ; IMin(a,b)
  %1872 = call i32 @dx.op.binary.i32(i32 38, i32 %1870, i32 %32)  ; IMin(a,b)
  %1873 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1871, i32 %1872, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1874 = extractvalue %dx.types.ResRet.f32 %1873, 0
  %1875 = fsub fast float 1.000000e+00, %58
  %1876 = fmul fast float %1875, 0x3FA99999A0000000
  %1877 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %1876)  ; FMax(a,b)
  %1878 = fsub fast float %1874, %58
  %1879 = call float @dx.op.unary.f32(i32 6, float %1878)  ; FAbs(value)
  %1880 = fdiv fast float %1879, %1877
  %1881 = fsub fast float 1.000000e+00, %1880
  %1882 = call float @dx.op.unary.f32(i32 7, float %1881)  ; Saturate(value)
  %1883 = fcmp fast ugt float %1882, 0.000000e+00
  br i1 %1883, label %1884, label %2010

; <label>:1884                                    ; preds = %1867
  %1885 = call i32 @dx.op.binary.i32(i32 37, i32 %1871, i32 0)  ; IMax(a,b)
  %1886 = call i32 @dx.op.binary.i32(i32 37, i32 %1872, i32 0)  ; IMax(a,b)
  %1887 = call i32 @dx.op.binary.i32(i32 38, i32 %1885, i32 %31)  ; IMin(a,b)
  %1888 = call i32 @dx.op.binary.i32(i32 38, i32 %1886, i32 %32)  ; IMin(a,b)
  %1889 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1887, i32 %1888, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1890 = extractvalue %dx.types.ResRet.f32 %1889, 0
  %1891 = extractvalue %dx.types.ResRet.f32 %1889, 1
  %1892 = extractvalue %dx.types.ResRet.f32 %1889, 2
  %1893 = extractvalue %dx.types.ResRet.f32 %1889, 3
  %1894 = fcmp fast olt float %1893, 0.000000e+00
  br i1 %1894, label %1895, label %1929

; <label>:1895                                    ; preds = %1884
  %1896 = fcmp fast ogt float %1890, 0x3FA4B5DCC0000000
  %1897 = fcmp fast ogt float %1891, 0x3FA4B5DCC0000000
  %1898 = fcmp fast ogt float %1892, 0x3FA4B5DCC0000000
  %1899 = select i1 %1896, float 0.000000e+00, float 1.000000e+00
  %1900 = select i1 %1897, float 0.000000e+00, float 1.000000e+00
  %1901 = select i1 %1898, float 0.000000e+00, float 1.000000e+00
  %1902 = fmul fast float %1890, 0x3FB3D07220000000
  %1903 = fmul fast float %1891, 0x3FB3D07220000000
  %1904 = fmul fast float %1892, 0x3FB3D07220000000
  %1905 = fadd fast float %1890, 0x3FAC28F5C0000000
  %1906 = fadd fast float %1891, 0x3FAC28F5C0000000
  %1907 = fadd fast float %1892, 0x3FAC28F5C0000000
  %1908 = fmul fast float %1905, 0x3FEE54EDE0000000
  %1909 = fmul fast float %1906, 0x3FEE54EDE0000000
  %1910 = fmul fast float %1907, 0x3FEE54EDE0000000
  %1911 = call float @dx.op.unary.f32(i32 23, float %1908)  ; Log(value)
  %1912 = call float @dx.op.unary.f32(i32 23, float %1909)  ; Log(value)
  %1913 = call float @dx.op.unary.f32(i32 23, float %1910)  ; Log(value)
  %1914 = fmul fast float %1911, 0x4003333340000000
  %1915 = fmul fast float %1912, 0x4003333340000000
  %1916 = fmul fast float %1913, 0x4003333340000000
  %1917 = call float @dx.op.unary.f32(i32 21, float %1914)  ; Exp(value)
  %1918 = call float @dx.op.unary.f32(i32 21, float %1915)  ; Exp(value)
  %1919 = call float @dx.op.unary.f32(i32 21, float %1916)  ; Exp(value)
  %1920 = fsub fast float %1902, %1917
  %1921 = fsub fast float %1903, %1918
  %1922 = fsub fast float %1904, %1919
  %1923 = fmul fast float %1920, %1899
  %1924 = fmul fast float %1921, %1900
  %1925 = fmul fast float %1922, %1901
  %1926 = fadd fast float %1923, %1917
  %1927 = fadd fast float %1924, %1918
  %1928 = fadd fast float %1925, %1919
  br label %1997

; <label>:1929                                    ; preds = %1884
  %1930 = fadd fast float %6, 1.000000e+00
  %1931 = fadd fast float %7, 1.000000e+00
  %1932 = fsub fast float 1.000000e+00, %6
  %1933 = fmul fast float %10, %1930
  %1934 = fmul fast float %10, %1931
  %1935 = fmul fast float %10, %1932
  %1936 = fmul fast float %1933, %1890
  %1937 = fmul fast float %1934, %1891
  %1938 = fmul fast float %1935, %1892
  %1939 = fcmp fast ult float %11, 5.000000e-01
  br i1 %1939, label %1965, label %1940

; <label>:1940                                    ; preds = %1929
  %1941 = fmul fast float %1936, 0x4004147AE0000000
  %1942 = fmul fast float %1937, 0x4004147AE0000000
  %1943 = fmul fast float %1938, 0x4004147AE0000000
  %1944 = fadd fast float %1941, 0x3F9EB851E0000000
  %1945 = fadd fast float %1942, 0x3F9EB851E0000000
  %1946 = fadd fast float %1943, 0x3F9EB851E0000000
  %1947 = fmul fast float %1944, %1936
  %1948 = fmul fast float %1945, %1937
  %1949 = fmul fast float %1946, %1938
  %1950 = fmul fast float %1936, 0x400370A3E0000000
  %1951 = fmul fast float %1937, 0x400370A3E0000000
  %1952 = fmul fast float %1938, 0x400370A3E0000000
  %1953 = fadd fast float %1950, 0x3FE2E147A0000000
  %1954 = fadd fast float %1951, 0x3FE2E147A0000000
  %1955 = fadd fast float %1952, 0x3FE2E147A0000000
  %1956 = fmul fast float %1953, %1936
  %1957 = fmul fast float %1954, %1937
  %1958 = fmul fast float %1955, %1938
  %1959 = fadd fast float %1956, 0x3FC1EB8520000000
  %1960 = fadd fast float %1957, 0x3FC1EB8520000000
  %1961 = fadd fast float %1958, 0x3FC1EB8520000000
  %1962 = fdiv fast float %1947, %1959
  %1963 = fdiv fast float %1948, %1960
  %1964 = fdiv fast float %1949, %1961
  br label %1965

; <label>:1965                                    ; preds = %1940, %1929
  %1966 = phi float [ %1962, %1940 ], [ %1936, %1929 ]
  %1967 = phi float [ %1963, %1940 ], [ %1937, %1929 ]
  %1968 = phi float [ %1964, %1940 ], [ %1938, %1929 ]
  %1969 = call float @dx.op.unary.f32(i32 7, float %1966)  ; Saturate(value)
  %1970 = call float @dx.op.unary.f32(i32 7, float %1967)  ; Saturate(value)
  %1971 = call float @dx.op.unary.f32(i32 7, float %1968)  ; Saturate(value)
  %1972 = call float @dx.op.dot3.f32(i32 55, float %1969, float %1970, float %1971, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1973 = fsub fast float %1969, %1972
  %1974 = fsub fast float %1970, %1972
  %1975 = fsub fast float %1971, %1972
  %1976 = fmul fast float %1973, %9
  %1977 = fmul fast float %1974, %9
  %1978 = fmul fast float %1975, %9
  %1979 = fadd fast float %1976, %1972
  %1980 = fadd fast float %1977, %1972
  %1981 = fadd fast float %1978, %1972
  %1982 = call float @dx.op.unary.f32(i32 7, float %1979)  ; Saturate(value)
  %1983 = call float @dx.op.unary.f32(i32 7, float %1980)  ; Saturate(value)
  %1984 = call float @dx.op.unary.f32(i32 7, float %1981)  ; Saturate(value)
  %1985 = fadd fast float %1982, 0xBFC70A3D80000000
  %1986 = fadd fast float %1983, 0xBFC70A3D80000000
  %1987 = fadd fast float %1984, 0xBFC70A3D80000000
  %1988 = fmul fast float %1985, %8
  %1989 = fmul fast float %1986, %8
  %1990 = fmul fast float %1987, %8
  %1991 = fadd fast float %1988, 0x3FC70A3D80000000
  %1992 = fadd fast float %1989, 0x3FC70A3D80000000
  %1993 = fadd fast float %1990, 0x3FC70A3D80000000
  %1994 = call float @dx.op.unary.f32(i32 7, float %1991)  ; Saturate(value)
  %1995 = call float @dx.op.unary.f32(i32 7, float %1992)  ; Saturate(value)
  %1996 = call float @dx.op.unary.f32(i32 7, float %1993)  ; Saturate(value)
  br label %1997

; <label>:1997                                    ; preds = %1965, %1895
  %1998 = phi float [ %1926, %1895 ], [ %1994, %1965 ]
  %1999 = phi float [ %1927, %1895 ], [ %1995, %1965 ]
  %2000 = phi float [ %1928, %1895 ], [ %1996, %1965 ]
  %2001 = fsub fast float %1998, %1863
  %2002 = fsub fast float %1999, %1864
  %2003 = fsub fast float %2000, %1865
  %2004 = fmul fast float %2001, %1882
  %2005 = fmul fast float %2002, %1882
  %2006 = fmul fast float %2003, %1882
  %2007 = fadd fast float %2004, %1863
  %2008 = fadd fast float %2005, %1864
  %2009 = fadd fast float %2006, %1865
  br label %2010

; <label>:2010                                    ; preds = %1997, %1867
  %2011 = phi float [ %2007, %1997 ], [ %1863, %1867 ]
  %2012 = phi float [ %2008, %1997 ], [ %1864, %1867 ]
  %2013 = phi float [ %2009, %1997 ], [ %1865, %1867 ]
  %2014 = add i32 %42, 1
  %2015 = call i32 @dx.op.binary.i32(i32 37, i32 %2014, i32 0)  ; IMax(a,b)
  %2016 = call i32 @dx.op.binary.i32(i32 38, i32 %2015, i32 %32)  ; IMin(a,b)
  %2017 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1871, i32 %2016, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2018 = extractvalue %dx.types.ResRet.f32 %2017, 0
  %2019 = fsub fast float %2018, %58
  %2020 = call float @dx.op.unary.f32(i32 6, float %2019)  ; FAbs(value)
  %2021 = fdiv fast float %2020, %1877
  %2022 = fsub fast float 1.000000e+00, %2021
  %2023 = call float @dx.op.unary.f32(i32 7, float %2022)  ; Saturate(value)
  %2024 = fcmp fast ugt float %2023, 0.000000e+00
  br i1 %2024, label %2025, label %2151

; <label>:2025                                    ; preds = %2010
  %2026 = call i32 @dx.op.binary.i32(i32 37, i32 %1871, i32 0)  ; IMax(a,b)
  %2027 = call i32 @dx.op.binary.i32(i32 37, i32 %2016, i32 0)  ; IMax(a,b)
  %2028 = call i32 @dx.op.binary.i32(i32 38, i32 %2026, i32 %31)  ; IMin(a,b)
  %2029 = call i32 @dx.op.binary.i32(i32 38, i32 %2027, i32 %32)  ; IMin(a,b)
  %2030 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2028, i32 %2029, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2031 = extractvalue %dx.types.ResRet.f32 %2030, 0
  %2032 = extractvalue %dx.types.ResRet.f32 %2030, 1
  %2033 = extractvalue %dx.types.ResRet.f32 %2030, 2
  %2034 = extractvalue %dx.types.ResRet.f32 %2030, 3
  %2035 = fcmp fast olt float %2034, 0.000000e+00
  br i1 %2035, label %2036, label %2070

; <label>:2036                                    ; preds = %2025
  %2037 = fcmp fast ogt float %2031, 0x3FA4B5DCC0000000
  %2038 = fcmp fast ogt float %2032, 0x3FA4B5DCC0000000
  %2039 = fcmp fast ogt float %2033, 0x3FA4B5DCC0000000
  %2040 = select i1 %2037, float 0.000000e+00, float 1.000000e+00
  %2041 = select i1 %2038, float 0.000000e+00, float 1.000000e+00
  %2042 = select i1 %2039, float 0.000000e+00, float 1.000000e+00
  %2043 = fmul fast float %2031, 0x3FB3D07220000000
  %2044 = fmul fast float %2032, 0x3FB3D07220000000
  %2045 = fmul fast float %2033, 0x3FB3D07220000000
  %2046 = fadd fast float %2031, 0x3FAC28F5C0000000
  %2047 = fadd fast float %2032, 0x3FAC28F5C0000000
  %2048 = fadd fast float %2033, 0x3FAC28F5C0000000
  %2049 = fmul fast float %2046, 0x3FEE54EDE0000000
  %2050 = fmul fast float %2047, 0x3FEE54EDE0000000
  %2051 = fmul fast float %2048, 0x3FEE54EDE0000000
  %2052 = call float @dx.op.unary.f32(i32 23, float %2049)  ; Log(value)
  %2053 = call float @dx.op.unary.f32(i32 23, float %2050)  ; Log(value)
  %2054 = call float @dx.op.unary.f32(i32 23, float %2051)  ; Log(value)
  %2055 = fmul fast float %2052, 0x4003333340000000
  %2056 = fmul fast float %2053, 0x4003333340000000
  %2057 = fmul fast float %2054, 0x4003333340000000
  %2058 = call float @dx.op.unary.f32(i32 21, float %2055)  ; Exp(value)
  %2059 = call float @dx.op.unary.f32(i32 21, float %2056)  ; Exp(value)
  %2060 = call float @dx.op.unary.f32(i32 21, float %2057)  ; Exp(value)
  %2061 = fsub fast float %2043, %2058
  %2062 = fsub fast float %2044, %2059
  %2063 = fsub fast float %2045, %2060
  %2064 = fmul fast float %2061, %2040
  %2065 = fmul fast float %2062, %2041
  %2066 = fmul fast float %2063, %2042
  %2067 = fadd fast float %2064, %2058
  %2068 = fadd fast float %2065, %2059
  %2069 = fadd fast float %2066, %2060
  br label %2138

; <label>:2070                                    ; preds = %2025
  %2071 = fadd fast float %6, 1.000000e+00
  %2072 = fadd fast float %7, 1.000000e+00
  %2073 = fsub fast float 1.000000e+00, %6
  %2074 = fmul fast float %10, %2071
  %2075 = fmul fast float %10, %2072
  %2076 = fmul fast float %10, %2073
  %2077 = fmul fast float %2074, %2031
  %2078 = fmul fast float %2075, %2032
  %2079 = fmul fast float %2076, %2033
  %2080 = fcmp fast ult float %11, 5.000000e-01
  br i1 %2080, label %2106, label %2081

; <label>:2081                                    ; preds = %2070
  %2082 = fmul fast float %2077, 0x4004147AE0000000
  %2083 = fmul fast float %2078, 0x4004147AE0000000
  %2084 = fmul fast float %2079, 0x4004147AE0000000
  %2085 = fadd fast float %2082, 0x3F9EB851E0000000
  %2086 = fadd fast float %2083, 0x3F9EB851E0000000
  %2087 = fadd fast float %2084, 0x3F9EB851E0000000
  %2088 = fmul fast float %2085, %2077
  %2089 = fmul fast float %2086, %2078
  %2090 = fmul fast float %2087, %2079
  %2091 = fmul fast float %2077, 0x400370A3E0000000
  %2092 = fmul fast float %2078, 0x400370A3E0000000
  %2093 = fmul fast float %2079, 0x400370A3E0000000
  %2094 = fadd fast float %2091, 0x3FE2E147A0000000
  %2095 = fadd fast float %2092, 0x3FE2E147A0000000
  %2096 = fadd fast float %2093, 0x3FE2E147A0000000
  %2097 = fmul fast float %2094, %2077
  %2098 = fmul fast float %2095, %2078
  %2099 = fmul fast float %2096, %2079
  %2100 = fadd fast float %2097, 0x3FC1EB8520000000
  %2101 = fadd fast float %2098, 0x3FC1EB8520000000
  %2102 = fadd fast float %2099, 0x3FC1EB8520000000
  %2103 = fdiv fast float %2088, %2100
  %2104 = fdiv fast float %2089, %2101
  %2105 = fdiv fast float %2090, %2102
  br label %2106

; <label>:2106                                    ; preds = %2081, %2070
  %2107 = phi float [ %2103, %2081 ], [ %2077, %2070 ]
  %2108 = phi float [ %2104, %2081 ], [ %2078, %2070 ]
  %2109 = phi float [ %2105, %2081 ], [ %2079, %2070 ]
  %2110 = call float @dx.op.unary.f32(i32 7, float %2107)  ; Saturate(value)
  %2111 = call float @dx.op.unary.f32(i32 7, float %2108)  ; Saturate(value)
  %2112 = call float @dx.op.unary.f32(i32 7, float %2109)  ; Saturate(value)
  %2113 = call float @dx.op.dot3.f32(i32 55, float %2110, float %2111, float %2112, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2114 = fsub fast float %2110, %2113
  %2115 = fsub fast float %2111, %2113
  %2116 = fsub fast float %2112, %2113
  %2117 = fmul fast float %2114, %9
  %2118 = fmul fast float %2115, %9
  %2119 = fmul fast float %2116, %9
  %2120 = fadd fast float %2117, %2113
  %2121 = fadd fast float %2118, %2113
  %2122 = fadd fast float %2119, %2113
  %2123 = call float @dx.op.unary.f32(i32 7, float %2120)  ; Saturate(value)
  %2124 = call float @dx.op.unary.f32(i32 7, float %2121)  ; Saturate(value)
  %2125 = call float @dx.op.unary.f32(i32 7, float %2122)  ; Saturate(value)
  %2126 = fadd fast float %2123, 0xBFC70A3D80000000
  %2127 = fadd fast float %2124, 0xBFC70A3D80000000
  %2128 = fadd fast float %2125, 0xBFC70A3D80000000
  %2129 = fmul fast float %2126, %8
  %2130 = fmul fast float %2127, %8
  %2131 = fmul fast float %2128, %8
  %2132 = fadd fast float %2129, 0x3FC70A3D80000000
  %2133 = fadd fast float %2130, 0x3FC70A3D80000000
  %2134 = fadd fast float %2131, 0x3FC70A3D80000000
  %2135 = call float @dx.op.unary.f32(i32 7, float %2132)  ; Saturate(value)
  %2136 = call float @dx.op.unary.f32(i32 7, float %2133)  ; Saturate(value)
  %2137 = call float @dx.op.unary.f32(i32 7, float %2134)  ; Saturate(value)
  br label %2138

; <label>:2138                                    ; preds = %2106, %2036
  %2139 = phi float [ %2067, %2036 ], [ %2135, %2106 ]
  %2140 = phi float [ %2068, %2036 ], [ %2136, %2106 ]
  %2141 = phi float [ %2069, %2036 ], [ %2137, %2106 ]
  %2142 = fsub fast float %2139, %1863
  %2143 = fsub fast float %2140, %1864
  %2144 = fsub fast float %2141, %1865
  %2145 = fmul fast float %2142, %2023
  %2146 = fmul fast float %2143, %2023
  %2147 = fmul fast float %2144, %2023
  %2148 = fadd fast float %2145, %1863
  %2149 = fadd fast float %2146, %1864
  %2150 = fadd fast float %2147, %1865
  br label %2151

; <label>:2151                                    ; preds = %2138, %2010
  %2152 = phi float [ %2148, %2138 ], [ %1863, %2010 ]
  %2153 = phi float [ %2149, %2138 ], [ %1864, %2010 ]
  %2154 = phi float [ %2150, %2138 ], [ %1865, %2010 ]
  %2155 = add i32 %35, -1
  %2156 = call i32 @dx.op.binary.i32(i32 37, i32 %2155, i32 0)  ; IMax(a,b)
  %2157 = call i32 @dx.op.binary.i32(i32 37, i32 %42, i32 0)  ; IMax(a,b)
  %2158 = call i32 @dx.op.binary.i32(i32 38, i32 %2156, i32 %31)  ; IMin(a,b)
  %2159 = call i32 @dx.op.binary.i32(i32 38, i32 %2157, i32 %32)  ; IMin(a,b)
  %2160 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2158, i32 %2159, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2161 = extractvalue %dx.types.ResRet.f32 %2160, 0
  %2162 = fsub fast float %2161, %58
  %2163 = call float @dx.op.unary.f32(i32 6, float %2162)  ; FAbs(value)
  %2164 = fdiv fast float %2163, %1877
  %2165 = fsub fast float 1.000000e+00, %2164
  %2166 = call float @dx.op.unary.f32(i32 7, float %2165)  ; Saturate(value)
  %2167 = fcmp fast ugt float %2166, 0.000000e+00
  br i1 %2167, label %2168, label %2294

; <label>:2168                                    ; preds = %2151
  %2169 = call i32 @dx.op.binary.i32(i32 37, i32 %2158, i32 0)  ; IMax(a,b)
  %2170 = call i32 @dx.op.binary.i32(i32 37, i32 %2159, i32 0)  ; IMax(a,b)
  %2171 = call i32 @dx.op.binary.i32(i32 38, i32 %2169, i32 %31)  ; IMin(a,b)
  %2172 = call i32 @dx.op.binary.i32(i32 38, i32 %2170, i32 %32)  ; IMin(a,b)
  %2173 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2171, i32 %2172, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2174 = extractvalue %dx.types.ResRet.f32 %2173, 0
  %2175 = extractvalue %dx.types.ResRet.f32 %2173, 1
  %2176 = extractvalue %dx.types.ResRet.f32 %2173, 2
  %2177 = extractvalue %dx.types.ResRet.f32 %2173, 3
  %2178 = fcmp fast olt float %2177, 0.000000e+00
  br i1 %2178, label %2179, label %2213

; <label>:2179                                    ; preds = %2168
  %2180 = fcmp fast ogt float %2174, 0x3FA4B5DCC0000000
  %2181 = fcmp fast ogt float %2175, 0x3FA4B5DCC0000000
  %2182 = fcmp fast ogt float %2176, 0x3FA4B5DCC0000000
  %2183 = select i1 %2180, float 0.000000e+00, float 1.000000e+00
  %2184 = select i1 %2181, float 0.000000e+00, float 1.000000e+00
  %2185 = select i1 %2182, float 0.000000e+00, float 1.000000e+00
  %2186 = fmul fast float %2174, 0x3FB3D07220000000
  %2187 = fmul fast float %2175, 0x3FB3D07220000000
  %2188 = fmul fast float %2176, 0x3FB3D07220000000
  %2189 = fadd fast float %2174, 0x3FAC28F5C0000000
  %2190 = fadd fast float %2175, 0x3FAC28F5C0000000
  %2191 = fadd fast float %2176, 0x3FAC28F5C0000000
  %2192 = fmul fast float %2189, 0x3FEE54EDE0000000
  %2193 = fmul fast float %2190, 0x3FEE54EDE0000000
  %2194 = fmul fast float %2191, 0x3FEE54EDE0000000
  %2195 = call float @dx.op.unary.f32(i32 23, float %2192)  ; Log(value)
  %2196 = call float @dx.op.unary.f32(i32 23, float %2193)  ; Log(value)
  %2197 = call float @dx.op.unary.f32(i32 23, float %2194)  ; Log(value)
  %2198 = fmul fast float %2195, 0x4003333340000000
  %2199 = fmul fast float %2196, 0x4003333340000000
  %2200 = fmul fast float %2197, 0x4003333340000000
  %2201 = call float @dx.op.unary.f32(i32 21, float %2198)  ; Exp(value)
  %2202 = call float @dx.op.unary.f32(i32 21, float %2199)  ; Exp(value)
  %2203 = call float @dx.op.unary.f32(i32 21, float %2200)  ; Exp(value)
  %2204 = fsub fast float %2186, %2201
  %2205 = fsub fast float %2187, %2202
  %2206 = fsub fast float %2188, %2203
  %2207 = fmul fast float %2204, %2183
  %2208 = fmul fast float %2205, %2184
  %2209 = fmul fast float %2206, %2185
  %2210 = fadd fast float %2207, %2201
  %2211 = fadd fast float %2208, %2202
  %2212 = fadd fast float %2209, %2203
  br label %2281

; <label>:2213                                    ; preds = %2168
  %2214 = fadd fast float %6, 1.000000e+00
  %2215 = fadd fast float %7, 1.000000e+00
  %2216 = fsub fast float 1.000000e+00, %6
  %2217 = fmul fast float %10, %2214
  %2218 = fmul fast float %10, %2215
  %2219 = fmul fast float %10, %2216
  %2220 = fmul fast float %2217, %2174
  %2221 = fmul fast float %2218, %2175
  %2222 = fmul fast float %2219, %2176
  %2223 = fcmp fast ult float %11, 5.000000e-01
  br i1 %2223, label %2249, label %2224

; <label>:2224                                    ; preds = %2213
  %2225 = fmul fast float %2220, 0x4004147AE0000000
  %2226 = fmul fast float %2221, 0x4004147AE0000000
  %2227 = fmul fast float %2222, 0x4004147AE0000000
  %2228 = fadd fast float %2225, 0x3F9EB851E0000000
  %2229 = fadd fast float %2226, 0x3F9EB851E0000000
  %2230 = fadd fast float %2227, 0x3F9EB851E0000000
  %2231 = fmul fast float %2228, %2220
  %2232 = fmul fast float %2229, %2221
  %2233 = fmul fast float %2230, %2222
  %2234 = fmul fast float %2220, 0x400370A3E0000000
  %2235 = fmul fast float %2221, 0x400370A3E0000000
  %2236 = fmul fast float %2222, 0x400370A3E0000000
  %2237 = fadd fast float %2234, 0x3FE2E147A0000000
  %2238 = fadd fast float %2235, 0x3FE2E147A0000000
  %2239 = fadd fast float %2236, 0x3FE2E147A0000000
  %2240 = fmul fast float %2237, %2220
  %2241 = fmul fast float %2238, %2221
  %2242 = fmul fast float %2239, %2222
  %2243 = fadd fast float %2240, 0x3FC1EB8520000000
  %2244 = fadd fast float %2241, 0x3FC1EB8520000000
  %2245 = fadd fast float %2242, 0x3FC1EB8520000000
  %2246 = fdiv fast float %2231, %2243
  %2247 = fdiv fast float %2232, %2244
  %2248 = fdiv fast float %2233, %2245
  br label %2249

; <label>:2249                                    ; preds = %2224, %2213
  %2250 = phi float [ %2246, %2224 ], [ %2220, %2213 ]
  %2251 = phi float [ %2247, %2224 ], [ %2221, %2213 ]
  %2252 = phi float [ %2248, %2224 ], [ %2222, %2213 ]
  %2253 = call float @dx.op.unary.f32(i32 7, float %2250)  ; Saturate(value)
  %2254 = call float @dx.op.unary.f32(i32 7, float %2251)  ; Saturate(value)
  %2255 = call float @dx.op.unary.f32(i32 7, float %2252)  ; Saturate(value)
  %2256 = call float @dx.op.dot3.f32(i32 55, float %2253, float %2254, float %2255, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2257 = fsub fast float %2253, %2256
  %2258 = fsub fast float %2254, %2256
  %2259 = fsub fast float %2255, %2256
  %2260 = fmul fast float %2257, %9
  %2261 = fmul fast float %2258, %9
  %2262 = fmul fast float %2259, %9
  %2263 = fadd fast float %2260, %2256
  %2264 = fadd fast float %2261, %2256
  %2265 = fadd fast float %2262, %2256
  %2266 = call float @dx.op.unary.f32(i32 7, float %2263)  ; Saturate(value)
  %2267 = call float @dx.op.unary.f32(i32 7, float %2264)  ; Saturate(value)
  %2268 = call float @dx.op.unary.f32(i32 7, float %2265)  ; Saturate(value)
  %2269 = fadd fast float %2266, 0xBFC70A3D80000000
  %2270 = fadd fast float %2267, 0xBFC70A3D80000000
  %2271 = fadd fast float %2268, 0xBFC70A3D80000000
  %2272 = fmul fast float %2269, %8
  %2273 = fmul fast float %2270, %8
  %2274 = fmul fast float %2271, %8
  %2275 = fadd fast float %2272, 0x3FC70A3D80000000
  %2276 = fadd fast float %2273, 0x3FC70A3D80000000
  %2277 = fadd fast float %2274, 0x3FC70A3D80000000
  %2278 = call float @dx.op.unary.f32(i32 7, float %2275)  ; Saturate(value)
  %2279 = call float @dx.op.unary.f32(i32 7, float %2276)  ; Saturate(value)
  %2280 = call float @dx.op.unary.f32(i32 7, float %2277)  ; Saturate(value)
  br label %2281

; <label>:2281                                    ; preds = %2249, %2179
  %2282 = phi float [ %2210, %2179 ], [ %2278, %2249 ]
  %2283 = phi float [ %2211, %2179 ], [ %2279, %2249 ]
  %2284 = phi float [ %2212, %2179 ], [ %2280, %2249 ]
  %2285 = fsub fast float %2282, %1863
  %2286 = fsub fast float %2283, %1864
  %2287 = fsub fast float %2284, %1865
  %2288 = fmul fast float %2285, %2166
  %2289 = fmul fast float %2286, %2166
  %2290 = fmul fast float %2287, %2166
  %2291 = fadd fast float %2288, %1863
  %2292 = fadd fast float %2289, %1864
  %2293 = fadd fast float %2290, %1865
  br label %2294

; <label>:2294                                    ; preds = %2281, %2151
  %2295 = phi float [ %2291, %2281 ], [ %1863, %2151 ]
  %2296 = phi float [ %2292, %2281 ], [ %1864, %2151 ]
  %2297 = phi float [ %2293, %2281 ], [ %1865, %2151 ]
  %2298 = add i32 %35, 1
  %2299 = call i32 @dx.op.binary.i32(i32 37, i32 %2298, i32 0)  ; IMax(a,b)
  %2300 = call i32 @dx.op.binary.i32(i32 38, i32 %2299, i32 %31)  ; IMin(a,b)
  %2301 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2300, i32 %2159, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2302 = extractvalue %dx.types.ResRet.f32 %2301, 0
  %2303 = fsub fast float %2302, %58
  %2304 = call float @dx.op.unary.f32(i32 6, float %2303)  ; FAbs(value)
  %2305 = fdiv fast float %2304, %1877
  %2306 = fsub fast float 1.000000e+00, %2305
  %2307 = call float @dx.op.unary.f32(i32 7, float %2306)  ; Saturate(value)
  %2308 = fcmp fast ugt float %2307, 0.000000e+00
  br i1 %2308, label %2309, label %2435

; <label>:2309                                    ; preds = %2294
  %2310 = call i32 @dx.op.binary.i32(i32 37, i32 %2300, i32 0)  ; IMax(a,b)
  %2311 = call i32 @dx.op.binary.i32(i32 37, i32 %2159, i32 0)  ; IMax(a,b)
  %2312 = call i32 @dx.op.binary.i32(i32 38, i32 %2310, i32 %31)  ; IMin(a,b)
  %2313 = call i32 @dx.op.binary.i32(i32 38, i32 %2311, i32 %32)  ; IMin(a,b)
  %2314 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2312, i32 %2313, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2315 = extractvalue %dx.types.ResRet.f32 %2314, 0
  %2316 = extractvalue %dx.types.ResRet.f32 %2314, 1
  %2317 = extractvalue %dx.types.ResRet.f32 %2314, 2
  %2318 = extractvalue %dx.types.ResRet.f32 %2314, 3
  %2319 = fcmp fast olt float %2318, 0.000000e+00
  br i1 %2319, label %2320, label %2354

; <label>:2320                                    ; preds = %2309
  %2321 = fcmp fast ogt float %2315, 0x3FA4B5DCC0000000
  %2322 = fcmp fast ogt float %2316, 0x3FA4B5DCC0000000
  %2323 = fcmp fast ogt float %2317, 0x3FA4B5DCC0000000
  %2324 = select i1 %2321, float 0.000000e+00, float 1.000000e+00
  %2325 = select i1 %2322, float 0.000000e+00, float 1.000000e+00
  %2326 = select i1 %2323, float 0.000000e+00, float 1.000000e+00
  %2327 = fmul fast float %2315, 0x3FB3D07220000000
  %2328 = fmul fast float %2316, 0x3FB3D07220000000
  %2329 = fmul fast float %2317, 0x3FB3D07220000000
  %2330 = fadd fast float %2315, 0x3FAC28F5C0000000
  %2331 = fadd fast float %2316, 0x3FAC28F5C0000000
  %2332 = fadd fast float %2317, 0x3FAC28F5C0000000
  %2333 = fmul fast float %2330, 0x3FEE54EDE0000000
  %2334 = fmul fast float %2331, 0x3FEE54EDE0000000
  %2335 = fmul fast float %2332, 0x3FEE54EDE0000000
  %2336 = call float @dx.op.unary.f32(i32 23, float %2333)  ; Log(value)
  %2337 = call float @dx.op.unary.f32(i32 23, float %2334)  ; Log(value)
  %2338 = call float @dx.op.unary.f32(i32 23, float %2335)  ; Log(value)
  %2339 = fmul fast float %2336, 0x4003333340000000
  %2340 = fmul fast float %2337, 0x4003333340000000
  %2341 = fmul fast float %2338, 0x4003333340000000
  %2342 = call float @dx.op.unary.f32(i32 21, float %2339)  ; Exp(value)
  %2343 = call float @dx.op.unary.f32(i32 21, float %2340)  ; Exp(value)
  %2344 = call float @dx.op.unary.f32(i32 21, float %2341)  ; Exp(value)
  %2345 = fsub fast float %2327, %2342
  %2346 = fsub fast float %2328, %2343
  %2347 = fsub fast float %2329, %2344
  %2348 = fmul fast float %2345, %2324
  %2349 = fmul fast float %2346, %2325
  %2350 = fmul fast float %2347, %2326
  %2351 = fadd fast float %2348, %2342
  %2352 = fadd fast float %2349, %2343
  %2353 = fadd fast float %2350, %2344
  br label %2422

; <label>:2354                                    ; preds = %2309
  %2355 = fadd fast float %6, 1.000000e+00
  %2356 = fadd fast float %7, 1.000000e+00
  %2357 = fsub fast float 1.000000e+00, %6
  %2358 = fmul fast float %10, %2355
  %2359 = fmul fast float %10, %2356
  %2360 = fmul fast float %10, %2357
  %2361 = fmul fast float %2358, %2315
  %2362 = fmul fast float %2359, %2316
  %2363 = fmul fast float %2360, %2317
  %2364 = fcmp fast ult float %11, 5.000000e-01
  br i1 %2364, label %2390, label %2365

; <label>:2365                                    ; preds = %2354
  %2366 = fmul fast float %2361, 0x4004147AE0000000
  %2367 = fmul fast float %2362, 0x4004147AE0000000
  %2368 = fmul fast float %2363, 0x4004147AE0000000
  %2369 = fadd fast float %2366, 0x3F9EB851E0000000
  %2370 = fadd fast float %2367, 0x3F9EB851E0000000
  %2371 = fadd fast float %2368, 0x3F9EB851E0000000
  %2372 = fmul fast float %2369, %2361
  %2373 = fmul fast float %2370, %2362
  %2374 = fmul fast float %2371, %2363
  %2375 = fmul fast float %2361, 0x400370A3E0000000
  %2376 = fmul fast float %2362, 0x400370A3E0000000
  %2377 = fmul fast float %2363, 0x400370A3E0000000
  %2378 = fadd fast float %2375, 0x3FE2E147A0000000
  %2379 = fadd fast float %2376, 0x3FE2E147A0000000
  %2380 = fadd fast float %2377, 0x3FE2E147A0000000
  %2381 = fmul fast float %2378, %2361
  %2382 = fmul fast float %2379, %2362
  %2383 = fmul fast float %2380, %2363
  %2384 = fadd fast float %2381, 0x3FC1EB8520000000
  %2385 = fadd fast float %2382, 0x3FC1EB8520000000
  %2386 = fadd fast float %2383, 0x3FC1EB8520000000
  %2387 = fdiv fast float %2372, %2384
  %2388 = fdiv fast float %2373, %2385
  %2389 = fdiv fast float %2374, %2386
  br label %2390

; <label>:2390                                    ; preds = %2365, %2354
  %2391 = phi float [ %2387, %2365 ], [ %2361, %2354 ]
  %2392 = phi float [ %2388, %2365 ], [ %2362, %2354 ]
  %2393 = phi float [ %2389, %2365 ], [ %2363, %2354 ]
  %2394 = call float @dx.op.unary.f32(i32 7, float %2391)  ; Saturate(value)
  %2395 = call float @dx.op.unary.f32(i32 7, float %2392)  ; Saturate(value)
  %2396 = call float @dx.op.unary.f32(i32 7, float %2393)  ; Saturate(value)
  %2397 = call float @dx.op.dot3.f32(i32 55, float %2394, float %2395, float %2396, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2398 = fsub fast float %2394, %2397
  %2399 = fsub fast float %2395, %2397
  %2400 = fsub fast float %2396, %2397
  %2401 = fmul fast float %2398, %9
  %2402 = fmul fast float %2399, %9
  %2403 = fmul fast float %2400, %9
  %2404 = fadd fast float %2401, %2397
  %2405 = fadd fast float %2402, %2397
  %2406 = fadd fast float %2403, %2397
  %2407 = call float @dx.op.unary.f32(i32 7, float %2404)  ; Saturate(value)
  %2408 = call float @dx.op.unary.f32(i32 7, float %2405)  ; Saturate(value)
  %2409 = call float @dx.op.unary.f32(i32 7, float %2406)  ; Saturate(value)
  %2410 = fadd fast float %2407, 0xBFC70A3D80000000
  %2411 = fadd fast float %2408, 0xBFC70A3D80000000
  %2412 = fadd fast float %2409, 0xBFC70A3D80000000
  %2413 = fmul fast float %2410, %8
  %2414 = fmul fast float %2411, %8
  %2415 = fmul fast float %2412, %8
  %2416 = fadd fast float %2413, 0x3FC70A3D80000000
  %2417 = fadd fast float %2414, 0x3FC70A3D80000000
  %2418 = fadd fast float %2415, 0x3FC70A3D80000000
  %2419 = call float @dx.op.unary.f32(i32 7, float %2416)  ; Saturate(value)
  %2420 = call float @dx.op.unary.f32(i32 7, float %2417)  ; Saturate(value)
  %2421 = call float @dx.op.unary.f32(i32 7, float %2418)  ; Saturate(value)
  br label %2422

; <label>:2422                                    ; preds = %2390, %2320
  %2423 = phi float [ %2351, %2320 ], [ %2419, %2390 ]
  %2424 = phi float [ %2352, %2320 ], [ %2420, %2390 ]
  %2425 = phi float [ %2353, %2320 ], [ %2421, %2390 ]
  %2426 = fsub fast float %2423, %1863
  %2427 = fsub fast float %2424, %1864
  %2428 = fsub fast float %2425, %1865
  %2429 = fmul fast float %2426, %2307
  %2430 = fmul fast float %2427, %2307
  %2431 = fmul fast float %2428, %2307
  %2432 = fadd fast float %2429, %1863
  %2433 = fadd fast float %2430, %1864
  %2434 = fadd fast float %2431, %1865
  br label %2435

; <label>:2435                                    ; preds = %2422, %2294
  %2436 = phi float [ %2432, %2422 ], [ %1863, %2294 ]
  %2437 = phi float [ %2433, %2422 ], [ %1864, %2294 ]
  %2438 = phi float [ %2434, %2422 ], [ %1865, %2294 ]
  %2439 = call float @dx.op.binary.f32(i32 36, float %2295, float %2436)  ; FMin(a,b)
  %2440 = call float @dx.op.binary.f32(i32 36, float %2296, float %2437)  ; FMin(a,b)
  %2441 = call float @dx.op.binary.f32(i32 36, float %2297, float %2438)  ; FMin(a,b)
  %2442 = call float @dx.op.binary.f32(i32 36, float %2011, float %2152)  ; FMin(a,b)
  %2443 = call float @dx.op.binary.f32(i32 36, float %2012, float %2153)  ; FMin(a,b)
  %2444 = call float @dx.op.binary.f32(i32 36, float %2013, float %2154)  ; FMin(a,b)
  %2445 = call float @dx.op.binary.f32(i32 36, float %2442, float %2439)  ; FMin(a,b)
  %2446 = call float @dx.op.binary.f32(i32 36, float %2443, float %2440)  ; FMin(a,b)
  %2447 = call float @dx.op.binary.f32(i32 36, float %2444, float %2441)  ; FMin(a,b)
  %2448 = call float @dx.op.binary.f32(i32 36, float %1863, float %2445)  ; FMin(a,b)
  %2449 = call float @dx.op.binary.f32(i32 36, float %1864, float %2446)  ; FMin(a,b)
  %2450 = call float @dx.op.binary.f32(i32 36, float %1865, float %2447)  ; FMin(a,b)
  %2451 = call float @dx.op.binary.f32(i32 35, float %2295, float %2436)  ; FMax(a,b)
  %2452 = call float @dx.op.binary.f32(i32 35, float %2296, float %2437)  ; FMax(a,b)
  %2453 = call float @dx.op.binary.f32(i32 35, float %2297, float %2438)  ; FMax(a,b)
  %2454 = call float @dx.op.binary.f32(i32 35, float %2011, float %2152)  ; FMax(a,b)
  %2455 = call float @dx.op.binary.f32(i32 35, float %2012, float %2153)  ; FMax(a,b)
  %2456 = call float @dx.op.binary.f32(i32 35, float %2013, float %2154)  ; FMax(a,b)
  %2457 = call float @dx.op.binary.f32(i32 35, float %2454, float %2451)  ; FMax(a,b)
  %2458 = call float @dx.op.binary.f32(i32 35, float %2455, float %2452)  ; FMax(a,b)
  %2459 = call float @dx.op.binary.f32(i32 35, float %2456, float %2453)  ; FMax(a,b)
  %2460 = call float @dx.op.binary.f32(i32 35, float %1863, float %2457)  ; FMax(a,b)
  %2461 = call float @dx.op.binary.f32(i32 35, float %1864, float %2458)  ; FMax(a,b)
  %2462 = call float @dx.op.binary.f32(i32 35, float %1865, float %2459)  ; FMax(a,b)
  %2463 = fsub fast float %2460, %2448
  %2464 = fsub fast float %2461, %2449
  %2465 = fsub fast float %2462, %2450
  %2466 = call float @dx.op.unary.f32(i32 6, float %2463)  ; FAbs(value)
  %2467 = call float @dx.op.unary.f32(i32 6, float %2464)  ; FAbs(value)
  %2468 = call float @dx.op.unary.f32(i32 6, float %2465)  ; FAbs(value)
  %2469 = call float @dx.op.binary.f32(i32 35, float %2467, float %2468)  ; FMax(a,b)
  %2470 = call float @dx.op.binary.f32(i32 35, float %2466, float %2469)  ; FMax(a,b)
  %2471 = call float @dx.op.binary.f32(i32 35, float %2461, float %2462)  ; FMax(a,b)
  %2472 = call float @dx.op.binary.f32(i32 35, float %2460, float %2471)  ; FMax(a,b)
  %2473 = fmul fast float %2472, 1.250000e-01
  %2474 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %2473)  ; FMax(a,b)
  %2475 = fcmp fast ogt float %2470, %2474
  br i1 %2475, label %2476, label %2538

; <label>:2476                                    ; preds = %2435
  %2477 = fsub fast float %2011, %2152
  %2478 = fsub fast float %2012, %2153
  %2479 = fsub fast float %2013, %2154
  %2480 = call float @dx.op.unary.f32(i32 6, float %2477)  ; FAbs(value)
  %2481 = call float @dx.op.unary.f32(i32 6, float %2478)  ; FAbs(value)
  %2482 = call float @dx.op.unary.f32(i32 6, float %2479)  ; FAbs(value)
  %2483 = call float @dx.op.binary.f32(i32 35, float %2481, float %2482)  ; FMax(a,b)
  %2484 = call float @dx.op.binary.f32(i32 35, float %2480, float %2483)  ; FMax(a,b)
  %2485 = fsub fast float %2295, %2436
  %2486 = fsub fast float %2296, %2437
  %2487 = fsub fast float %2297, %2438
  %2488 = call float @dx.op.unary.f32(i32 6, float %2485)  ; FAbs(value)
  %2489 = call float @dx.op.unary.f32(i32 6, float %2486)  ; FAbs(value)
  %2490 = call float @dx.op.unary.f32(i32 6, float %2487)  ; FAbs(value)
  %2491 = call float @dx.op.binary.f32(i32 35, float %2489, float %2490)  ; FMax(a,b)
  %2492 = call float @dx.op.binary.f32(i32 35, float %2488, float %2491)  ; FMax(a,b)
  %2493 = fcmp fast olt float %2484, %2492
  %2494 = select i1 %2493, float %2011, float %2295
  %2495 = select i1 %2493, float %2012, float %2296
  %2496 = select i1 %2493, float %2013, float %2297
  %2497 = select i1 %2493, float %2152, float %2436
  %2498 = select i1 %2493, float %2153, float %2437
  %2499 = select i1 %2493, float %2154, float %2438
  %2500 = fsub fast float %1863, %2497
  %2501 = fsub fast float %1864, %2498
  %2502 = fsub fast float %1865, %2499
  %2503 = fsub fast float %1863, %2494
  %2504 = fsub fast float %1864, %2495
  %2505 = fsub fast float %1865, %2496
  %2506 = call float @dx.op.dot3.f32(i32 55, float %2503, float %2504, float %2505, float %2500, float %2501, float %2502)  ; Dot3(ax,ay,az,bx,by,bz)
  %2507 = fcmp fast ogt float %2506, 0.000000e+00
  br i1 %2507, label %2508, label %2519

; <label>:2508                                    ; preds = %2476
  %2509 = fsub fast float %2494, %2497
  %2510 = fsub fast float %2495, %2498
  %2511 = fsub fast float %2496, %2499
  %2512 = call float @dx.op.unary.f32(i32 6, float %2509)  ; FAbs(value)
  %2513 = call float @dx.op.unary.f32(i32 6, float %2510)  ; FAbs(value)
  %2514 = call float @dx.op.unary.f32(i32 6, float %2511)  ; FAbs(value)
  %2515 = call float @dx.op.binary.f32(i32 35, float %2513, float %2514)  ; FMax(a,b)
  %2516 = call float @dx.op.binary.f32(i32 35, float %2512, float %2515)  ; FMax(a,b)
  %2517 = fmul fast float %2470, 2.500000e-01
  %2518 = fcmp fast olt float %2516, %2517
  br label %2519

; <label>:2519                                    ; preds = %2508, %2476
  %2520 = phi i1 [ false, %2476 ], [ %2518, %2508 ]
  %2521 = select i1 %2520, float 5.000000e-01, float 1.000000e+00
  %2522 = fmul fast float %2521, %3
  %2523 = fadd fast float %2494, %2497
  %2524 = fadd fast float %2495, %2498
  %2525 = fadd fast float %2496, %2499
  %2526 = fmul fast float %2523, 5.000000e-01
  %2527 = fmul fast float %2524, 5.000000e-01
  %2528 = fmul fast float %2525, 5.000000e-01
  %2529 = fsub fast float %2526, %1863
  %2530 = fsub fast float %2527, %1864
  %2531 = fsub fast float %2528, %1865
  %2532 = fmul fast float %2522, %2529
  %2533 = fmul fast float %2522, %2530
  %2534 = fmul fast float %2522, %2531
  %2535 = fadd fast float %2532, %1863
  %2536 = fadd fast float %2533, %1864
  %2537 = fadd fast float %2534, %1865
  br label %2538

; <label>:2538                                    ; preds = %2519, %2435, %1834
  %2539 = phi float [ %1863, %1834 ], [ %2535, %2519 ], [ %1863, %2435 ]
  %2540 = phi float [ %1864, %1834 ], [ %2536, %2519 ], [ %1864, %2435 ]
  %2541 = phi float [ %1865, %1834 ], [ %2537, %2519 ], [ %1865, %2435 ]
  %2542 = fcmp fast ogt float %2539, 0x3F69A5C380000000
  %2543 = fcmp fast ogt float %2540, 0x3F69A5C380000000
  %2544 = fcmp fast ogt float %2541, 0x3F69A5C380000000
  %2545 = select i1 %2542, float 0.000000e+00, float 1.000000e+00
  %2546 = select i1 %2543, float 0.000000e+00, float 1.000000e+00
  %2547 = select i1 %2544, float 0.000000e+00, float 1.000000e+00
  %2548 = fmul fast float %2539, 0x4029D70A40000000
  %2549 = fmul fast float %2540, 0x4029D70A40000000
  %2550 = fmul fast float %2541, 0x4029D70A40000000
  %2551 = call float @dx.op.binary.f32(i32 35, float %2539, float 0.000000e+00)  ; FMax(a,b)
  %2552 = call float @dx.op.binary.f32(i32 35, float %2540, float 0.000000e+00)  ; FMax(a,b)
  %2553 = call float @dx.op.binary.f32(i32 35, float %2541, float 0.000000e+00)  ; FMax(a,b)
  %2554 = call float @dx.op.unary.f32(i32 23, float %2551)  ; Log(value)
  %2555 = call float @dx.op.unary.f32(i32 23, float %2552)  ; Log(value)
  %2556 = call float @dx.op.unary.f32(i32 23, float %2553)  ; Log(value)
  %2557 = fmul fast float %2554, 0x3FDAAAAAA0000000
  %2558 = fmul fast float %2555, 0x3FDAAAAAA0000000
  %2559 = fmul fast float %2556, 0x3FDAAAAAA0000000
  %2560 = call float @dx.op.unary.f32(i32 21, float %2557)  ; Exp(value)
  %2561 = call float @dx.op.unary.f32(i32 21, float %2558)  ; Exp(value)
  %2562 = call float @dx.op.unary.f32(i32 21, float %2559)  ; Exp(value)
  %2563 = fmul fast float %2560, 0x3FF0E147A0000000
  %2564 = fmul fast float %2561, 0x3FF0E147A0000000
  %2565 = fmul fast float %2562, 0x3FF0E147A0000000
  %2566 = fadd fast float %2563, 0xBFAC28F5C0000000
  %2567 = fadd fast float %2564, 0xBFAC28F5C0000000
  %2568 = fadd fast float %2565, 0xBFAC28F5C0000000
  %2569 = fsub fast float %2548, %2566
  %2570 = fsub fast float %2549, %2567
  %2571 = fsub fast float %2550, %2568
  %2572 = fmul fast float %2569, %2545
  %2573 = fmul fast float %2570, %2546
  %2574 = fmul fast float %2571, %2547
  %2575 = fadd fast float %2572, %2566
  %2576 = fadd fast float %2573, %2567
  %2577 = fadd fast float %2574, %2568
  br label %2578

; <label>:2578                                    ; preds = %2538, %1796
  %2579 = phi float [ %1791, %1796 ], [ %2575, %2538 ]
  %2580 = phi float [ %1792, %1796 ], [ %2576, %2538 ]
  %2581 = phi float [ %1793, %1796 ], [ %2577, %2538 ]
  %2582 = phi float [ %1797, %1796 ], [ %1794, %2538 ]
  %2583 = fcmp fast ogt float %2579, 0x3FA4B5DCC0000000
  %2584 = fcmp fast ogt float %2580, 0x3FA4B5DCC0000000
  %2585 = fcmp fast ogt float %2581, 0x3FA4B5DCC0000000
  %2586 = select i1 %2583, float 0.000000e+00, float 1.000000e+00
  %2587 = select i1 %2584, float 0.000000e+00, float 1.000000e+00
  %2588 = select i1 %2585, float 0.000000e+00, float 1.000000e+00
  %2589 = fmul fast float %2579, 0x3FB3D07220000000
  %2590 = fmul fast float %2580, 0x3FB3D07220000000
  %2591 = fmul fast float %2581, 0x3FB3D07220000000
  %2592 = fadd fast float %2579, 0x3FAC28F5C0000000
  %2593 = fadd fast float %2580, 0x3FAC28F5C0000000
  %2594 = fadd fast float %2581, 0x3FAC28F5C0000000
  %2595 = fmul fast float %2592, 0x3FEE54EDE0000000
  %2596 = fmul fast float %2593, 0x3FEE54EDE0000000
  %2597 = fmul fast float %2594, 0x3FEE54EDE0000000
  %2598 = call float @dx.op.unary.f32(i32 23, float %2595)  ; Log(value)
  %2599 = call float @dx.op.unary.f32(i32 23, float %2596)  ; Log(value)
  %2600 = call float @dx.op.unary.f32(i32 23, float %2597)  ; Log(value)
  %2601 = fmul fast float %2598, 0x4003333340000000
  %2602 = fmul fast float %2599, 0x4003333340000000
  %2603 = fmul fast float %2600, 0x4003333340000000
  %2604 = call float @dx.op.unary.f32(i32 21, float %2601)  ; Exp(value)
  %2605 = call float @dx.op.unary.f32(i32 21, float %2602)  ; Exp(value)
  %2606 = call float @dx.op.unary.f32(i32 21, float %2603)  ; Exp(value)
  %2607 = fsub fast float %2589, %2604
  %2608 = fsub fast float %2590, %2605
  %2609 = fsub fast float %2591, %2606
  %2610 = fmul fast float %2607, %2586
  %2611 = fmul fast float %2608, %2587
  %2612 = fmul fast float %2609, %2588
  %2613 = fadd fast float %2610, %2604
  %2614 = fadd fast float %2611, %2605
  %2615 = fadd fast float %2612, %2606
  %2616 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %39, i32 %42, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2617 = extractvalue %dx.types.ResRet.f32 %2616, 0
  %2618 = extractvalue %dx.types.ResRet.f32 %2616, 1
  %2619 = extractvalue %dx.types.ResRet.f32 %2616, 2
  %2620 = extractvalue %dx.types.ResRet.f32 %2616, 3
  %2621 = fcmp fast olt float %2620, 0.000000e+00
  br i1 %2621, label %2622, label %2624

; <label>:2622                                    ; preds = %2578
  %2623 = fsub fast float -1.000000e+00, %2620
  br label %3404

; <label>:2624                                    ; preds = %2578
  %2625 = fadd fast float %6, 1.000000e+00
  %2626 = fadd fast float %7, 1.000000e+00
  %2627 = fsub fast float 1.000000e+00, %6
  %2628 = fmul fast float %10, %2625
  %2629 = fmul fast float %10, %2626
  %2630 = fmul fast float %10, %2627
  %2631 = fmul fast float %2628, %2617
  %2632 = fmul fast float %2629, %2618
  %2633 = fmul fast float %2630, %2619
  %2634 = fcmp fast ult float %11, 5.000000e-01
  br i1 %2634, label %2660, label %2635

; <label>:2635                                    ; preds = %2624
  %2636 = fmul fast float %2631, 0x4004147AE0000000
  %2637 = fmul fast float %2632, 0x4004147AE0000000
  %2638 = fmul fast float %2633, 0x4004147AE0000000
  %2639 = fadd fast float %2636, 0x3F9EB851E0000000
  %2640 = fadd fast float %2637, 0x3F9EB851E0000000
  %2641 = fadd fast float %2638, 0x3F9EB851E0000000
  %2642 = fmul fast float %2639, %2631
  %2643 = fmul fast float %2640, %2632
  %2644 = fmul fast float %2641, %2633
  %2645 = fmul fast float %2631, 0x400370A3E0000000
  %2646 = fmul fast float %2632, 0x400370A3E0000000
  %2647 = fmul fast float %2633, 0x400370A3E0000000
  %2648 = fadd fast float %2645, 0x3FE2E147A0000000
  %2649 = fadd fast float %2646, 0x3FE2E147A0000000
  %2650 = fadd fast float %2647, 0x3FE2E147A0000000
  %2651 = fmul fast float %2648, %2631
  %2652 = fmul fast float %2649, %2632
  %2653 = fmul fast float %2650, %2633
  %2654 = fadd fast float %2651, 0x3FC1EB8520000000
  %2655 = fadd fast float %2652, 0x3FC1EB8520000000
  %2656 = fadd fast float %2653, 0x3FC1EB8520000000
  %2657 = fdiv fast float %2642, %2654
  %2658 = fdiv fast float %2643, %2655
  %2659 = fdiv fast float %2644, %2656
  br label %2660

; <label>:2660                                    ; preds = %2635, %2624
  %2661 = phi float [ %2657, %2635 ], [ %2631, %2624 ]
  %2662 = phi float [ %2658, %2635 ], [ %2632, %2624 ]
  %2663 = phi float [ %2659, %2635 ], [ %2633, %2624 ]
  %2664 = call float @dx.op.unary.f32(i32 7, float %2661)  ; Saturate(value)
  %2665 = call float @dx.op.unary.f32(i32 7, float %2662)  ; Saturate(value)
  %2666 = call float @dx.op.unary.f32(i32 7, float %2663)  ; Saturate(value)
  %2667 = call float @dx.op.dot3.f32(i32 55, float %2664, float %2665, float %2666, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2668 = fsub fast float %2664, %2667
  %2669 = fsub fast float %2665, %2667
  %2670 = fsub fast float %2666, %2667
  %2671 = fmul fast float %2668, %9
  %2672 = fmul fast float %2669, %9
  %2673 = fmul fast float %2670, %9
  %2674 = fadd fast float %2671, %2667
  %2675 = fadd fast float %2672, %2667
  %2676 = fadd fast float %2673, %2667
  %2677 = call float @dx.op.unary.f32(i32 7, float %2674)  ; Saturate(value)
  %2678 = call float @dx.op.unary.f32(i32 7, float %2675)  ; Saturate(value)
  %2679 = call float @dx.op.unary.f32(i32 7, float %2676)  ; Saturate(value)
  %2680 = fadd fast float %2677, 0xBFC70A3D80000000
  %2681 = fadd fast float %2678, 0xBFC70A3D80000000
  %2682 = fadd fast float %2679, 0xBFC70A3D80000000
  %2683 = fmul fast float %2680, %8
  %2684 = fmul fast float %2681, %8
  %2685 = fmul fast float %2682, %8
  %2686 = fadd fast float %2683, 0x3FC70A3D80000000
  %2687 = fadd fast float %2684, 0x3FC70A3D80000000
  %2688 = fadd fast float %2685, 0x3FC70A3D80000000
  %2689 = call float @dx.op.unary.f32(i32 7, float %2686)  ; Saturate(value)
  %2690 = call float @dx.op.unary.f32(i32 7, float %2687)  ; Saturate(value)
  %2691 = call float @dx.op.unary.f32(i32 7, float %2688)  ; Saturate(value)
  %2692 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %2692, label %2693, label %3364

; <label>:2693                                    ; preds = %2660
  %2694 = add i32 %42, -1
  %2695 = call i32 @dx.op.binary.i32(i32 37, i32 %39, i32 0)  ; IMax(a,b)
  %2696 = call i32 @dx.op.binary.i32(i32 37, i32 %2694, i32 0)  ; IMax(a,b)
  %2697 = call i32 @dx.op.binary.i32(i32 38, i32 %2695, i32 %31)  ; IMin(a,b)
  %2698 = call i32 @dx.op.binary.i32(i32 38, i32 %2696, i32 %32)  ; IMin(a,b)
  %2699 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2697, i32 %2698, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2700 = extractvalue %dx.types.ResRet.f32 %2699, 0
  %2701 = fsub fast float 1.000000e+00, %60
  %2702 = fmul fast float %2701, 0x3FA99999A0000000
  %2703 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %2702)  ; FMax(a,b)
  %2704 = fsub fast float %2700, %60
  %2705 = call float @dx.op.unary.f32(i32 6, float %2704)  ; FAbs(value)
  %2706 = fdiv fast float %2705, %2703
  %2707 = fsub fast float 1.000000e+00, %2706
  %2708 = call float @dx.op.unary.f32(i32 7, float %2707)  ; Saturate(value)
  %2709 = fcmp fast ugt float %2708, 0.000000e+00
  br i1 %2709, label %2710, label %2836

; <label>:2710                                    ; preds = %2693
  %2711 = call i32 @dx.op.binary.i32(i32 37, i32 %2697, i32 0)  ; IMax(a,b)
  %2712 = call i32 @dx.op.binary.i32(i32 37, i32 %2698, i32 0)  ; IMax(a,b)
  %2713 = call i32 @dx.op.binary.i32(i32 38, i32 %2711, i32 %31)  ; IMin(a,b)
  %2714 = call i32 @dx.op.binary.i32(i32 38, i32 %2712, i32 %32)  ; IMin(a,b)
  %2715 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2713, i32 %2714, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2716 = extractvalue %dx.types.ResRet.f32 %2715, 0
  %2717 = extractvalue %dx.types.ResRet.f32 %2715, 1
  %2718 = extractvalue %dx.types.ResRet.f32 %2715, 2
  %2719 = extractvalue %dx.types.ResRet.f32 %2715, 3
  %2720 = fcmp fast olt float %2719, 0.000000e+00
  br i1 %2720, label %2721, label %2755

; <label>:2721                                    ; preds = %2710
  %2722 = fcmp fast ogt float %2716, 0x3FA4B5DCC0000000
  %2723 = fcmp fast ogt float %2717, 0x3FA4B5DCC0000000
  %2724 = fcmp fast ogt float %2718, 0x3FA4B5DCC0000000
  %2725 = select i1 %2722, float 0.000000e+00, float 1.000000e+00
  %2726 = select i1 %2723, float 0.000000e+00, float 1.000000e+00
  %2727 = select i1 %2724, float 0.000000e+00, float 1.000000e+00
  %2728 = fmul fast float %2716, 0x3FB3D07220000000
  %2729 = fmul fast float %2717, 0x3FB3D07220000000
  %2730 = fmul fast float %2718, 0x3FB3D07220000000
  %2731 = fadd fast float %2716, 0x3FAC28F5C0000000
  %2732 = fadd fast float %2717, 0x3FAC28F5C0000000
  %2733 = fadd fast float %2718, 0x3FAC28F5C0000000
  %2734 = fmul fast float %2731, 0x3FEE54EDE0000000
  %2735 = fmul fast float %2732, 0x3FEE54EDE0000000
  %2736 = fmul fast float %2733, 0x3FEE54EDE0000000
  %2737 = call float @dx.op.unary.f32(i32 23, float %2734)  ; Log(value)
  %2738 = call float @dx.op.unary.f32(i32 23, float %2735)  ; Log(value)
  %2739 = call float @dx.op.unary.f32(i32 23, float %2736)  ; Log(value)
  %2740 = fmul fast float %2737, 0x4003333340000000
  %2741 = fmul fast float %2738, 0x4003333340000000
  %2742 = fmul fast float %2739, 0x4003333340000000
  %2743 = call float @dx.op.unary.f32(i32 21, float %2740)  ; Exp(value)
  %2744 = call float @dx.op.unary.f32(i32 21, float %2741)  ; Exp(value)
  %2745 = call float @dx.op.unary.f32(i32 21, float %2742)  ; Exp(value)
  %2746 = fsub fast float %2728, %2743
  %2747 = fsub fast float %2729, %2744
  %2748 = fsub fast float %2730, %2745
  %2749 = fmul fast float %2746, %2725
  %2750 = fmul fast float %2747, %2726
  %2751 = fmul fast float %2748, %2727
  %2752 = fadd fast float %2749, %2743
  %2753 = fadd fast float %2750, %2744
  %2754 = fadd fast float %2751, %2745
  br label %2823

; <label>:2755                                    ; preds = %2710
  %2756 = fadd fast float %6, 1.000000e+00
  %2757 = fadd fast float %7, 1.000000e+00
  %2758 = fsub fast float 1.000000e+00, %6
  %2759 = fmul fast float %10, %2756
  %2760 = fmul fast float %10, %2757
  %2761 = fmul fast float %10, %2758
  %2762 = fmul fast float %2759, %2716
  %2763 = fmul fast float %2760, %2717
  %2764 = fmul fast float %2761, %2718
  %2765 = fcmp fast ult float %11, 5.000000e-01
  br i1 %2765, label %2791, label %2766

; <label>:2766                                    ; preds = %2755
  %2767 = fmul fast float %2762, 0x4004147AE0000000
  %2768 = fmul fast float %2763, 0x4004147AE0000000
  %2769 = fmul fast float %2764, 0x4004147AE0000000
  %2770 = fadd fast float %2767, 0x3F9EB851E0000000
  %2771 = fadd fast float %2768, 0x3F9EB851E0000000
  %2772 = fadd fast float %2769, 0x3F9EB851E0000000
  %2773 = fmul fast float %2770, %2762
  %2774 = fmul fast float %2771, %2763
  %2775 = fmul fast float %2772, %2764
  %2776 = fmul fast float %2762, 0x400370A3E0000000
  %2777 = fmul fast float %2763, 0x400370A3E0000000
  %2778 = fmul fast float %2764, 0x400370A3E0000000
  %2779 = fadd fast float %2776, 0x3FE2E147A0000000
  %2780 = fadd fast float %2777, 0x3FE2E147A0000000
  %2781 = fadd fast float %2778, 0x3FE2E147A0000000
  %2782 = fmul fast float %2779, %2762
  %2783 = fmul fast float %2780, %2763
  %2784 = fmul fast float %2781, %2764
  %2785 = fadd fast float %2782, 0x3FC1EB8520000000
  %2786 = fadd fast float %2783, 0x3FC1EB8520000000
  %2787 = fadd fast float %2784, 0x3FC1EB8520000000
  %2788 = fdiv fast float %2773, %2785
  %2789 = fdiv fast float %2774, %2786
  %2790 = fdiv fast float %2775, %2787
  br label %2791

; <label>:2791                                    ; preds = %2766, %2755
  %2792 = phi float [ %2788, %2766 ], [ %2762, %2755 ]
  %2793 = phi float [ %2789, %2766 ], [ %2763, %2755 ]
  %2794 = phi float [ %2790, %2766 ], [ %2764, %2755 ]
  %2795 = call float @dx.op.unary.f32(i32 7, float %2792)  ; Saturate(value)
  %2796 = call float @dx.op.unary.f32(i32 7, float %2793)  ; Saturate(value)
  %2797 = call float @dx.op.unary.f32(i32 7, float %2794)  ; Saturate(value)
  %2798 = call float @dx.op.dot3.f32(i32 55, float %2795, float %2796, float %2797, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2799 = fsub fast float %2795, %2798
  %2800 = fsub fast float %2796, %2798
  %2801 = fsub fast float %2797, %2798
  %2802 = fmul fast float %2799, %9
  %2803 = fmul fast float %2800, %9
  %2804 = fmul fast float %2801, %9
  %2805 = fadd fast float %2802, %2798
  %2806 = fadd fast float %2803, %2798
  %2807 = fadd fast float %2804, %2798
  %2808 = call float @dx.op.unary.f32(i32 7, float %2805)  ; Saturate(value)
  %2809 = call float @dx.op.unary.f32(i32 7, float %2806)  ; Saturate(value)
  %2810 = call float @dx.op.unary.f32(i32 7, float %2807)  ; Saturate(value)
  %2811 = fadd fast float %2808, 0xBFC70A3D80000000
  %2812 = fadd fast float %2809, 0xBFC70A3D80000000
  %2813 = fadd fast float %2810, 0xBFC70A3D80000000
  %2814 = fmul fast float %2811, %8
  %2815 = fmul fast float %2812, %8
  %2816 = fmul fast float %2813, %8
  %2817 = fadd fast float %2814, 0x3FC70A3D80000000
  %2818 = fadd fast float %2815, 0x3FC70A3D80000000
  %2819 = fadd fast float %2816, 0x3FC70A3D80000000
  %2820 = call float @dx.op.unary.f32(i32 7, float %2817)  ; Saturate(value)
  %2821 = call float @dx.op.unary.f32(i32 7, float %2818)  ; Saturate(value)
  %2822 = call float @dx.op.unary.f32(i32 7, float %2819)  ; Saturate(value)
  br label %2823

; <label>:2823                                    ; preds = %2791, %2721
  %2824 = phi float [ %2752, %2721 ], [ %2820, %2791 ]
  %2825 = phi float [ %2753, %2721 ], [ %2821, %2791 ]
  %2826 = phi float [ %2754, %2721 ], [ %2822, %2791 ]
  %2827 = fsub fast float %2824, %2689
  %2828 = fsub fast float %2825, %2690
  %2829 = fsub fast float %2826, %2691
  %2830 = fmul fast float %2827, %2708
  %2831 = fmul fast float %2828, %2708
  %2832 = fmul fast float %2829, %2708
  %2833 = fadd fast float %2830, %2689
  %2834 = fadd fast float %2831, %2690
  %2835 = fadd fast float %2832, %2691
  br label %2836

; <label>:2836                                    ; preds = %2823, %2693
  %2837 = phi float [ %2833, %2823 ], [ %2689, %2693 ]
  %2838 = phi float [ %2834, %2823 ], [ %2690, %2693 ]
  %2839 = phi float [ %2835, %2823 ], [ %2691, %2693 ]
  %2840 = add i32 %42, 1
  %2841 = call i32 @dx.op.binary.i32(i32 37, i32 %2840, i32 0)  ; IMax(a,b)
  %2842 = call i32 @dx.op.binary.i32(i32 38, i32 %2841, i32 %32)  ; IMin(a,b)
  %2843 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2697, i32 %2842, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2844 = extractvalue %dx.types.ResRet.f32 %2843, 0
  %2845 = fsub fast float %2844, %60
  %2846 = call float @dx.op.unary.f32(i32 6, float %2845)  ; FAbs(value)
  %2847 = fdiv fast float %2846, %2703
  %2848 = fsub fast float 1.000000e+00, %2847
  %2849 = call float @dx.op.unary.f32(i32 7, float %2848)  ; Saturate(value)
  %2850 = fcmp fast ugt float %2849, 0.000000e+00
  br i1 %2850, label %2851, label %2977

; <label>:2851                                    ; preds = %2836
  %2852 = call i32 @dx.op.binary.i32(i32 37, i32 %2697, i32 0)  ; IMax(a,b)
  %2853 = call i32 @dx.op.binary.i32(i32 37, i32 %2842, i32 0)  ; IMax(a,b)
  %2854 = call i32 @dx.op.binary.i32(i32 38, i32 %2852, i32 %31)  ; IMin(a,b)
  %2855 = call i32 @dx.op.binary.i32(i32 38, i32 %2853, i32 %32)  ; IMin(a,b)
  %2856 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2854, i32 %2855, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2857 = extractvalue %dx.types.ResRet.f32 %2856, 0
  %2858 = extractvalue %dx.types.ResRet.f32 %2856, 1
  %2859 = extractvalue %dx.types.ResRet.f32 %2856, 2
  %2860 = extractvalue %dx.types.ResRet.f32 %2856, 3
  %2861 = fcmp fast olt float %2860, 0.000000e+00
  br i1 %2861, label %2862, label %2896

; <label>:2862                                    ; preds = %2851
  %2863 = fcmp fast ogt float %2857, 0x3FA4B5DCC0000000
  %2864 = fcmp fast ogt float %2858, 0x3FA4B5DCC0000000
  %2865 = fcmp fast ogt float %2859, 0x3FA4B5DCC0000000
  %2866 = select i1 %2863, float 0.000000e+00, float 1.000000e+00
  %2867 = select i1 %2864, float 0.000000e+00, float 1.000000e+00
  %2868 = select i1 %2865, float 0.000000e+00, float 1.000000e+00
  %2869 = fmul fast float %2857, 0x3FB3D07220000000
  %2870 = fmul fast float %2858, 0x3FB3D07220000000
  %2871 = fmul fast float %2859, 0x3FB3D07220000000
  %2872 = fadd fast float %2857, 0x3FAC28F5C0000000
  %2873 = fadd fast float %2858, 0x3FAC28F5C0000000
  %2874 = fadd fast float %2859, 0x3FAC28F5C0000000
  %2875 = fmul fast float %2872, 0x3FEE54EDE0000000
  %2876 = fmul fast float %2873, 0x3FEE54EDE0000000
  %2877 = fmul fast float %2874, 0x3FEE54EDE0000000
  %2878 = call float @dx.op.unary.f32(i32 23, float %2875)  ; Log(value)
  %2879 = call float @dx.op.unary.f32(i32 23, float %2876)  ; Log(value)
  %2880 = call float @dx.op.unary.f32(i32 23, float %2877)  ; Log(value)
  %2881 = fmul fast float %2878, 0x4003333340000000
  %2882 = fmul fast float %2879, 0x4003333340000000
  %2883 = fmul fast float %2880, 0x4003333340000000
  %2884 = call float @dx.op.unary.f32(i32 21, float %2881)  ; Exp(value)
  %2885 = call float @dx.op.unary.f32(i32 21, float %2882)  ; Exp(value)
  %2886 = call float @dx.op.unary.f32(i32 21, float %2883)  ; Exp(value)
  %2887 = fsub fast float %2869, %2884
  %2888 = fsub fast float %2870, %2885
  %2889 = fsub fast float %2871, %2886
  %2890 = fmul fast float %2887, %2866
  %2891 = fmul fast float %2888, %2867
  %2892 = fmul fast float %2889, %2868
  %2893 = fadd fast float %2890, %2884
  %2894 = fadd fast float %2891, %2885
  %2895 = fadd fast float %2892, %2886
  br label %2964

; <label>:2896                                    ; preds = %2851
  %2897 = fadd fast float %6, 1.000000e+00
  %2898 = fadd fast float %7, 1.000000e+00
  %2899 = fsub fast float 1.000000e+00, %6
  %2900 = fmul fast float %10, %2897
  %2901 = fmul fast float %10, %2898
  %2902 = fmul fast float %10, %2899
  %2903 = fmul fast float %2900, %2857
  %2904 = fmul fast float %2901, %2858
  %2905 = fmul fast float %2902, %2859
  %2906 = fcmp fast ult float %11, 5.000000e-01
  br i1 %2906, label %2932, label %2907

; <label>:2907                                    ; preds = %2896
  %2908 = fmul fast float %2903, 0x4004147AE0000000
  %2909 = fmul fast float %2904, 0x4004147AE0000000
  %2910 = fmul fast float %2905, 0x4004147AE0000000
  %2911 = fadd fast float %2908, 0x3F9EB851E0000000
  %2912 = fadd fast float %2909, 0x3F9EB851E0000000
  %2913 = fadd fast float %2910, 0x3F9EB851E0000000
  %2914 = fmul fast float %2911, %2903
  %2915 = fmul fast float %2912, %2904
  %2916 = fmul fast float %2913, %2905
  %2917 = fmul fast float %2903, 0x400370A3E0000000
  %2918 = fmul fast float %2904, 0x400370A3E0000000
  %2919 = fmul fast float %2905, 0x400370A3E0000000
  %2920 = fadd fast float %2917, 0x3FE2E147A0000000
  %2921 = fadd fast float %2918, 0x3FE2E147A0000000
  %2922 = fadd fast float %2919, 0x3FE2E147A0000000
  %2923 = fmul fast float %2920, %2903
  %2924 = fmul fast float %2921, %2904
  %2925 = fmul fast float %2922, %2905
  %2926 = fadd fast float %2923, 0x3FC1EB8520000000
  %2927 = fadd fast float %2924, 0x3FC1EB8520000000
  %2928 = fadd fast float %2925, 0x3FC1EB8520000000
  %2929 = fdiv fast float %2914, %2926
  %2930 = fdiv fast float %2915, %2927
  %2931 = fdiv fast float %2916, %2928
  br label %2932

; <label>:2932                                    ; preds = %2907, %2896
  %2933 = phi float [ %2929, %2907 ], [ %2903, %2896 ]
  %2934 = phi float [ %2930, %2907 ], [ %2904, %2896 ]
  %2935 = phi float [ %2931, %2907 ], [ %2905, %2896 ]
  %2936 = call float @dx.op.unary.f32(i32 7, float %2933)  ; Saturate(value)
  %2937 = call float @dx.op.unary.f32(i32 7, float %2934)  ; Saturate(value)
  %2938 = call float @dx.op.unary.f32(i32 7, float %2935)  ; Saturate(value)
  %2939 = call float @dx.op.dot3.f32(i32 55, float %2936, float %2937, float %2938, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2940 = fsub fast float %2936, %2939
  %2941 = fsub fast float %2937, %2939
  %2942 = fsub fast float %2938, %2939
  %2943 = fmul fast float %2940, %9
  %2944 = fmul fast float %2941, %9
  %2945 = fmul fast float %2942, %9
  %2946 = fadd fast float %2943, %2939
  %2947 = fadd fast float %2944, %2939
  %2948 = fadd fast float %2945, %2939
  %2949 = call float @dx.op.unary.f32(i32 7, float %2946)  ; Saturate(value)
  %2950 = call float @dx.op.unary.f32(i32 7, float %2947)  ; Saturate(value)
  %2951 = call float @dx.op.unary.f32(i32 7, float %2948)  ; Saturate(value)
  %2952 = fadd fast float %2949, 0xBFC70A3D80000000
  %2953 = fadd fast float %2950, 0xBFC70A3D80000000
  %2954 = fadd fast float %2951, 0xBFC70A3D80000000
  %2955 = fmul fast float %2952, %8
  %2956 = fmul fast float %2953, %8
  %2957 = fmul fast float %2954, %8
  %2958 = fadd fast float %2955, 0x3FC70A3D80000000
  %2959 = fadd fast float %2956, 0x3FC70A3D80000000
  %2960 = fadd fast float %2957, 0x3FC70A3D80000000
  %2961 = call float @dx.op.unary.f32(i32 7, float %2958)  ; Saturate(value)
  %2962 = call float @dx.op.unary.f32(i32 7, float %2959)  ; Saturate(value)
  %2963 = call float @dx.op.unary.f32(i32 7, float %2960)  ; Saturate(value)
  br label %2964

; <label>:2964                                    ; preds = %2932, %2862
  %2965 = phi float [ %2893, %2862 ], [ %2961, %2932 ]
  %2966 = phi float [ %2894, %2862 ], [ %2962, %2932 ]
  %2967 = phi float [ %2895, %2862 ], [ %2963, %2932 ]
  %2968 = fsub fast float %2965, %2689
  %2969 = fsub fast float %2966, %2690
  %2970 = fsub fast float %2967, %2691
  %2971 = fmul fast float %2968, %2849
  %2972 = fmul fast float %2969, %2849
  %2973 = fmul fast float %2970, %2849
  %2974 = fadd fast float %2971, %2689
  %2975 = fadd fast float %2972, %2690
  %2976 = fadd fast float %2973, %2691
  br label %2977

; <label>:2977                                    ; preds = %2964, %2836
  %2978 = phi float [ %2974, %2964 ], [ %2689, %2836 ]
  %2979 = phi float [ %2975, %2964 ], [ %2690, %2836 ]
  %2980 = phi float [ %2976, %2964 ], [ %2691, %2836 ]
  %2981 = add i32 %39, -1
  %2982 = call i32 @dx.op.binary.i32(i32 37, i32 %2981, i32 0)  ; IMax(a,b)
  %2983 = call i32 @dx.op.binary.i32(i32 37, i32 %42, i32 0)  ; IMax(a,b)
  %2984 = call i32 @dx.op.binary.i32(i32 38, i32 %2982, i32 %31)  ; IMin(a,b)
  %2985 = call i32 @dx.op.binary.i32(i32 38, i32 %2983, i32 %32)  ; IMin(a,b)
  %2986 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2984, i32 %2985, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2987 = extractvalue %dx.types.ResRet.f32 %2986, 0
  %2988 = fsub fast float %2987, %60
  %2989 = call float @dx.op.unary.f32(i32 6, float %2988)  ; FAbs(value)
  %2990 = fdiv fast float %2989, %2703
  %2991 = fsub fast float 1.000000e+00, %2990
  %2992 = call float @dx.op.unary.f32(i32 7, float %2991)  ; Saturate(value)
  %2993 = fcmp fast ugt float %2992, 0.000000e+00
  br i1 %2993, label %2994, label %3120

; <label>:2994                                    ; preds = %2977
  %2995 = call i32 @dx.op.binary.i32(i32 37, i32 %2984, i32 0)  ; IMax(a,b)
  %2996 = call i32 @dx.op.binary.i32(i32 37, i32 %2985, i32 0)  ; IMax(a,b)
  %2997 = call i32 @dx.op.binary.i32(i32 38, i32 %2995, i32 %31)  ; IMin(a,b)
  %2998 = call i32 @dx.op.binary.i32(i32 38, i32 %2996, i32 %32)  ; IMin(a,b)
  %2999 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2997, i32 %2998, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3000 = extractvalue %dx.types.ResRet.f32 %2999, 0
  %3001 = extractvalue %dx.types.ResRet.f32 %2999, 1
  %3002 = extractvalue %dx.types.ResRet.f32 %2999, 2
  %3003 = extractvalue %dx.types.ResRet.f32 %2999, 3
  %3004 = fcmp fast olt float %3003, 0.000000e+00
  br i1 %3004, label %3005, label %3039

; <label>:3005                                    ; preds = %2994
  %3006 = fcmp fast ogt float %3000, 0x3FA4B5DCC0000000
  %3007 = fcmp fast ogt float %3001, 0x3FA4B5DCC0000000
  %3008 = fcmp fast ogt float %3002, 0x3FA4B5DCC0000000
  %3009 = select i1 %3006, float 0.000000e+00, float 1.000000e+00
  %3010 = select i1 %3007, float 0.000000e+00, float 1.000000e+00
  %3011 = select i1 %3008, float 0.000000e+00, float 1.000000e+00
  %3012 = fmul fast float %3000, 0x3FB3D07220000000
  %3013 = fmul fast float %3001, 0x3FB3D07220000000
  %3014 = fmul fast float %3002, 0x3FB3D07220000000
  %3015 = fadd fast float %3000, 0x3FAC28F5C0000000
  %3016 = fadd fast float %3001, 0x3FAC28F5C0000000
  %3017 = fadd fast float %3002, 0x3FAC28F5C0000000
  %3018 = fmul fast float %3015, 0x3FEE54EDE0000000
  %3019 = fmul fast float %3016, 0x3FEE54EDE0000000
  %3020 = fmul fast float %3017, 0x3FEE54EDE0000000
  %3021 = call float @dx.op.unary.f32(i32 23, float %3018)  ; Log(value)
  %3022 = call float @dx.op.unary.f32(i32 23, float %3019)  ; Log(value)
  %3023 = call float @dx.op.unary.f32(i32 23, float %3020)  ; Log(value)
  %3024 = fmul fast float %3021, 0x4003333340000000
  %3025 = fmul fast float %3022, 0x4003333340000000
  %3026 = fmul fast float %3023, 0x4003333340000000
  %3027 = call float @dx.op.unary.f32(i32 21, float %3024)  ; Exp(value)
  %3028 = call float @dx.op.unary.f32(i32 21, float %3025)  ; Exp(value)
  %3029 = call float @dx.op.unary.f32(i32 21, float %3026)  ; Exp(value)
  %3030 = fsub fast float %3012, %3027
  %3031 = fsub fast float %3013, %3028
  %3032 = fsub fast float %3014, %3029
  %3033 = fmul fast float %3030, %3009
  %3034 = fmul fast float %3031, %3010
  %3035 = fmul fast float %3032, %3011
  %3036 = fadd fast float %3033, %3027
  %3037 = fadd fast float %3034, %3028
  %3038 = fadd fast float %3035, %3029
  br label %3107

; <label>:3039                                    ; preds = %2994
  %3040 = fadd fast float %6, 1.000000e+00
  %3041 = fadd fast float %7, 1.000000e+00
  %3042 = fsub fast float 1.000000e+00, %6
  %3043 = fmul fast float %10, %3040
  %3044 = fmul fast float %10, %3041
  %3045 = fmul fast float %10, %3042
  %3046 = fmul fast float %3043, %3000
  %3047 = fmul fast float %3044, %3001
  %3048 = fmul fast float %3045, %3002
  %3049 = fcmp fast ult float %11, 5.000000e-01
  br i1 %3049, label %3075, label %3050

; <label>:3050                                    ; preds = %3039
  %3051 = fmul fast float %3046, 0x4004147AE0000000
  %3052 = fmul fast float %3047, 0x4004147AE0000000
  %3053 = fmul fast float %3048, 0x4004147AE0000000
  %3054 = fadd fast float %3051, 0x3F9EB851E0000000
  %3055 = fadd fast float %3052, 0x3F9EB851E0000000
  %3056 = fadd fast float %3053, 0x3F9EB851E0000000
  %3057 = fmul fast float %3054, %3046
  %3058 = fmul fast float %3055, %3047
  %3059 = fmul fast float %3056, %3048
  %3060 = fmul fast float %3046, 0x400370A3E0000000
  %3061 = fmul fast float %3047, 0x400370A3E0000000
  %3062 = fmul fast float %3048, 0x400370A3E0000000
  %3063 = fadd fast float %3060, 0x3FE2E147A0000000
  %3064 = fadd fast float %3061, 0x3FE2E147A0000000
  %3065 = fadd fast float %3062, 0x3FE2E147A0000000
  %3066 = fmul fast float %3063, %3046
  %3067 = fmul fast float %3064, %3047
  %3068 = fmul fast float %3065, %3048
  %3069 = fadd fast float %3066, 0x3FC1EB8520000000
  %3070 = fadd fast float %3067, 0x3FC1EB8520000000
  %3071 = fadd fast float %3068, 0x3FC1EB8520000000
  %3072 = fdiv fast float %3057, %3069
  %3073 = fdiv fast float %3058, %3070
  %3074 = fdiv fast float %3059, %3071
  br label %3075

; <label>:3075                                    ; preds = %3050, %3039
  %3076 = phi float [ %3072, %3050 ], [ %3046, %3039 ]
  %3077 = phi float [ %3073, %3050 ], [ %3047, %3039 ]
  %3078 = phi float [ %3074, %3050 ], [ %3048, %3039 ]
  %3079 = call float @dx.op.unary.f32(i32 7, float %3076)  ; Saturate(value)
  %3080 = call float @dx.op.unary.f32(i32 7, float %3077)  ; Saturate(value)
  %3081 = call float @dx.op.unary.f32(i32 7, float %3078)  ; Saturate(value)
  %3082 = call float @dx.op.dot3.f32(i32 55, float %3079, float %3080, float %3081, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3083 = fsub fast float %3079, %3082
  %3084 = fsub fast float %3080, %3082
  %3085 = fsub fast float %3081, %3082
  %3086 = fmul fast float %3083, %9
  %3087 = fmul fast float %3084, %9
  %3088 = fmul fast float %3085, %9
  %3089 = fadd fast float %3086, %3082
  %3090 = fadd fast float %3087, %3082
  %3091 = fadd fast float %3088, %3082
  %3092 = call float @dx.op.unary.f32(i32 7, float %3089)  ; Saturate(value)
  %3093 = call float @dx.op.unary.f32(i32 7, float %3090)  ; Saturate(value)
  %3094 = call float @dx.op.unary.f32(i32 7, float %3091)  ; Saturate(value)
  %3095 = fadd fast float %3092, 0xBFC70A3D80000000
  %3096 = fadd fast float %3093, 0xBFC70A3D80000000
  %3097 = fadd fast float %3094, 0xBFC70A3D80000000
  %3098 = fmul fast float %3095, %8
  %3099 = fmul fast float %3096, %8
  %3100 = fmul fast float %3097, %8
  %3101 = fadd fast float %3098, 0x3FC70A3D80000000
  %3102 = fadd fast float %3099, 0x3FC70A3D80000000
  %3103 = fadd fast float %3100, 0x3FC70A3D80000000
  %3104 = call float @dx.op.unary.f32(i32 7, float %3101)  ; Saturate(value)
  %3105 = call float @dx.op.unary.f32(i32 7, float %3102)  ; Saturate(value)
  %3106 = call float @dx.op.unary.f32(i32 7, float %3103)  ; Saturate(value)
  br label %3107

; <label>:3107                                    ; preds = %3075, %3005
  %3108 = phi float [ %3036, %3005 ], [ %3104, %3075 ]
  %3109 = phi float [ %3037, %3005 ], [ %3105, %3075 ]
  %3110 = phi float [ %3038, %3005 ], [ %3106, %3075 ]
  %3111 = fsub fast float %3108, %2689
  %3112 = fsub fast float %3109, %2690
  %3113 = fsub fast float %3110, %2691
  %3114 = fmul fast float %3111, %2992
  %3115 = fmul fast float %3112, %2992
  %3116 = fmul fast float %3113, %2992
  %3117 = fadd fast float %3114, %2689
  %3118 = fadd fast float %3115, %2690
  %3119 = fadd fast float %3116, %2691
  br label %3120

; <label>:3120                                    ; preds = %3107, %2977
  %3121 = phi float [ %3117, %3107 ], [ %2689, %2977 ]
  %3122 = phi float [ %3118, %3107 ], [ %2690, %2977 ]
  %3123 = phi float [ %3119, %3107 ], [ %2691, %2977 ]
  %3124 = add i32 %39, 1
  %3125 = call i32 @dx.op.binary.i32(i32 37, i32 %3124, i32 0)  ; IMax(a,b)
  %3126 = call i32 @dx.op.binary.i32(i32 38, i32 %3125, i32 %31)  ; IMin(a,b)
  %3127 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3126, i32 %2985, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3128 = extractvalue %dx.types.ResRet.f32 %3127, 0
  %3129 = fsub fast float %3128, %60
  %3130 = call float @dx.op.unary.f32(i32 6, float %3129)  ; FAbs(value)
  %3131 = fdiv fast float %3130, %2703
  %3132 = fsub fast float 1.000000e+00, %3131
  %3133 = call float @dx.op.unary.f32(i32 7, float %3132)  ; Saturate(value)
  %3134 = fcmp fast ugt float %3133, 0.000000e+00
  br i1 %3134, label %3135, label %3261

; <label>:3135                                    ; preds = %3120
  %3136 = call i32 @dx.op.binary.i32(i32 37, i32 %3126, i32 0)  ; IMax(a,b)
  %3137 = call i32 @dx.op.binary.i32(i32 37, i32 %2985, i32 0)  ; IMax(a,b)
  %3138 = call i32 @dx.op.binary.i32(i32 38, i32 %3136, i32 %31)  ; IMin(a,b)
  %3139 = call i32 @dx.op.binary.i32(i32 38, i32 %3137, i32 %32)  ; IMin(a,b)
  %3140 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3138, i32 %3139, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3141 = extractvalue %dx.types.ResRet.f32 %3140, 0
  %3142 = extractvalue %dx.types.ResRet.f32 %3140, 1
  %3143 = extractvalue %dx.types.ResRet.f32 %3140, 2
  %3144 = extractvalue %dx.types.ResRet.f32 %3140, 3
  %3145 = fcmp fast olt float %3144, 0.000000e+00
  br i1 %3145, label %3146, label %3180

; <label>:3146                                    ; preds = %3135
  %3147 = fcmp fast ogt float %3141, 0x3FA4B5DCC0000000
  %3148 = fcmp fast ogt float %3142, 0x3FA4B5DCC0000000
  %3149 = fcmp fast ogt float %3143, 0x3FA4B5DCC0000000
  %3150 = select i1 %3147, float 0.000000e+00, float 1.000000e+00
  %3151 = select i1 %3148, float 0.000000e+00, float 1.000000e+00
  %3152 = select i1 %3149, float 0.000000e+00, float 1.000000e+00
  %3153 = fmul fast float %3141, 0x3FB3D07220000000
  %3154 = fmul fast float %3142, 0x3FB3D07220000000
  %3155 = fmul fast float %3143, 0x3FB3D07220000000
  %3156 = fadd fast float %3141, 0x3FAC28F5C0000000
  %3157 = fadd fast float %3142, 0x3FAC28F5C0000000
  %3158 = fadd fast float %3143, 0x3FAC28F5C0000000
  %3159 = fmul fast float %3156, 0x3FEE54EDE0000000
  %3160 = fmul fast float %3157, 0x3FEE54EDE0000000
  %3161 = fmul fast float %3158, 0x3FEE54EDE0000000
  %3162 = call float @dx.op.unary.f32(i32 23, float %3159)  ; Log(value)
  %3163 = call float @dx.op.unary.f32(i32 23, float %3160)  ; Log(value)
  %3164 = call float @dx.op.unary.f32(i32 23, float %3161)  ; Log(value)
  %3165 = fmul fast float %3162, 0x4003333340000000
  %3166 = fmul fast float %3163, 0x4003333340000000
  %3167 = fmul fast float %3164, 0x4003333340000000
  %3168 = call float @dx.op.unary.f32(i32 21, float %3165)  ; Exp(value)
  %3169 = call float @dx.op.unary.f32(i32 21, float %3166)  ; Exp(value)
  %3170 = call float @dx.op.unary.f32(i32 21, float %3167)  ; Exp(value)
  %3171 = fsub fast float %3153, %3168
  %3172 = fsub fast float %3154, %3169
  %3173 = fsub fast float %3155, %3170
  %3174 = fmul fast float %3171, %3150
  %3175 = fmul fast float %3172, %3151
  %3176 = fmul fast float %3173, %3152
  %3177 = fadd fast float %3174, %3168
  %3178 = fadd fast float %3175, %3169
  %3179 = fadd fast float %3176, %3170
  br label %3248

; <label>:3180                                    ; preds = %3135
  %3181 = fadd fast float %6, 1.000000e+00
  %3182 = fadd fast float %7, 1.000000e+00
  %3183 = fsub fast float 1.000000e+00, %6
  %3184 = fmul fast float %10, %3181
  %3185 = fmul fast float %10, %3182
  %3186 = fmul fast float %10, %3183
  %3187 = fmul fast float %3184, %3141
  %3188 = fmul fast float %3185, %3142
  %3189 = fmul fast float %3186, %3143
  %3190 = fcmp fast ult float %11, 5.000000e-01
  br i1 %3190, label %3216, label %3191

; <label>:3191                                    ; preds = %3180
  %3192 = fmul fast float %3187, 0x4004147AE0000000
  %3193 = fmul fast float %3188, 0x4004147AE0000000
  %3194 = fmul fast float %3189, 0x4004147AE0000000
  %3195 = fadd fast float %3192, 0x3F9EB851E0000000
  %3196 = fadd fast float %3193, 0x3F9EB851E0000000
  %3197 = fadd fast float %3194, 0x3F9EB851E0000000
  %3198 = fmul fast float %3195, %3187
  %3199 = fmul fast float %3196, %3188
  %3200 = fmul fast float %3197, %3189
  %3201 = fmul fast float %3187, 0x400370A3E0000000
  %3202 = fmul fast float %3188, 0x400370A3E0000000
  %3203 = fmul fast float %3189, 0x400370A3E0000000
  %3204 = fadd fast float %3201, 0x3FE2E147A0000000
  %3205 = fadd fast float %3202, 0x3FE2E147A0000000
  %3206 = fadd fast float %3203, 0x3FE2E147A0000000
  %3207 = fmul fast float %3204, %3187
  %3208 = fmul fast float %3205, %3188
  %3209 = fmul fast float %3206, %3189
  %3210 = fadd fast float %3207, 0x3FC1EB8520000000
  %3211 = fadd fast float %3208, 0x3FC1EB8520000000
  %3212 = fadd fast float %3209, 0x3FC1EB8520000000
  %3213 = fdiv fast float %3198, %3210
  %3214 = fdiv fast float %3199, %3211
  %3215 = fdiv fast float %3200, %3212
  br label %3216

; <label>:3216                                    ; preds = %3191, %3180
  %3217 = phi float [ %3213, %3191 ], [ %3187, %3180 ]
  %3218 = phi float [ %3214, %3191 ], [ %3188, %3180 ]
  %3219 = phi float [ %3215, %3191 ], [ %3189, %3180 ]
  %3220 = call float @dx.op.unary.f32(i32 7, float %3217)  ; Saturate(value)
  %3221 = call float @dx.op.unary.f32(i32 7, float %3218)  ; Saturate(value)
  %3222 = call float @dx.op.unary.f32(i32 7, float %3219)  ; Saturate(value)
  %3223 = call float @dx.op.dot3.f32(i32 55, float %3220, float %3221, float %3222, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3224 = fsub fast float %3220, %3223
  %3225 = fsub fast float %3221, %3223
  %3226 = fsub fast float %3222, %3223
  %3227 = fmul fast float %3224, %9
  %3228 = fmul fast float %3225, %9
  %3229 = fmul fast float %3226, %9
  %3230 = fadd fast float %3227, %3223
  %3231 = fadd fast float %3228, %3223
  %3232 = fadd fast float %3229, %3223
  %3233 = call float @dx.op.unary.f32(i32 7, float %3230)  ; Saturate(value)
  %3234 = call float @dx.op.unary.f32(i32 7, float %3231)  ; Saturate(value)
  %3235 = call float @dx.op.unary.f32(i32 7, float %3232)  ; Saturate(value)
  %3236 = fadd fast float %3233, 0xBFC70A3D80000000
  %3237 = fadd fast float %3234, 0xBFC70A3D80000000
  %3238 = fadd fast float %3235, 0xBFC70A3D80000000
  %3239 = fmul fast float %3236, %8
  %3240 = fmul fast float %3237, %8
  %3241 = fmul fast float %3238, %8
  %3242 = fadd fast float %3239, 0x3FC70A3D80000000
  %3243 = fadd fast float %3240, 0x3FC70A3D80000000
  %3244 = fadd fast float %3241, 0x3FC70A3D80000000
  %3245 = call float @dx.op.unary.f32(i32 7, float %3242)  ; Saturate(value)
  %3246 = call float @dx.op.unary.f32(i32 7, float %3243)  ; Saturate(value)
  %3247 = call float @dx.op.unary.f32(i32 7, float %3244)  ; Saturate(value)
  br label %3248

; <label>:3248                                    ; preds = %3216, %3146
  %3249 = phi float [ %3177, %3146 ], [ %3245, %3216 ]
  %3250 = phi float [ %3178, %3146 ], [ %3246, %3216 ]
  %3251 = phi float [ %3179, %3146 ], [ %3247, %3216 ]
  %3252 = fsub fast float %3249, %2689
  %3253 = fsub fast float %3250, %2690
  %3254 = fsub fast float %3251, %2691
  %3255 = fmul fast float %3252, %3133
  %3256 = fmul fast float %3253, %3133
  %3257 = fmul fast float %3254, %3133
  %3258 = fadd fast float %3255, %2689
  %3259 = fadd fast float %3256, %2690
  %3260 = fadd fast float %3257, %2691
  br label %3261

; <label>:3261                                    ; preds = %3248, %3120
  %3262 = phi float [ %3258, %3248 ], [ %2689, %3120 ]
  %3263 = phi float [ %3259, %3248 ], [ %2690, %3120 ]
  %3264 = phi float [ %3260, %3248 ], [ %2691, %3120 ]
  %3265 = call float @dx.op.binary.f32(i32 36, float %3121, float %3262)  ; FMin(a,b)
  %3266 = call float @dx.op.binary.f32(i32 36, float %3122, float %3263)  ; FMin(a,b)
  %3267 = call float @dx.op.binary.f32(i32 36, float %3123, float %3264)  ; FMin(a,b)
  %3268 = call float @dx.op.binary.f32(i32 36, float %2837, float %2978)  ; FMin(a,b)
  %3269 = call float @dx.op.binary.f32(i32 36, float %2838, float %2979)  ; FMin(a,b)
  %3270 = call float @dx.op.binary.f32(i32 36, float %2839, float %2980)  ; FMin(a,b)
  %3271 = call float @dx.op.binary.f32(i32 36, float %3268, float %3265)  ; FMin(a,b)
  %3272 = call float @dx.op.binary.f32(i32 36, float %3269, float %3266)  ; FMin(a,b)
  %3273 = call float @dx.op.binary.f32(i32 36, float %3270, float %3267)  ; FMin(a,b)
  %3274 = call float @dx.op.binary.f32(i32 36, float %2689, float %3271)  ; FMin(a,b)
  %3275 = call float @dx.op.binary.f32(i32 36, float %2690, float %3272)  ; FMin(a,b)
  %3276 = call float @dx.op.binary.f32(i32 36, float %2691, float %3273)  ; FMin(a,b)
  %3277 = call float @dx.op.binary.f32(i32 35, float %3121, float %3262)  ; FMax(a,b)
  %3278 = call float @dx.op.binary.f32(i32 35, float %3122, float %3263)  ; FMax(a,b)
  %3279 = call float @dx.op.binary.f32(i32 35, float %3123, float %3264)  ; FMax(a,b)
  %3280 = call float @dx.op.binary.f32(i32 35, float %2837, float %2978)  ; FMax(a,b)
  %3281 = call float @dx.op.binary.f32(i32 35, float %2838, float %2979)  ; FMax(a,b)
  %3282 = call float @dx.op.binary.f32(i32 35, float %2839, float %2980)  ; FMax(a,b)
  %3283 = call float @dx.op.binary.f32(i32 35, float %3280, float %3277)  ; FMax(a,b)
  %3284 = call float @dx.op.binary.f32(i32 35, float %3281, float %3278)  ; FMax(a,b)
  %3285 = call float @dx.op.binary.f32(i32 35, float %3282, float %3279)  ; FMax(a,b)
  %3286 = call float @dx.op.binary.f32(i32 35, float %2689, float %3283)  ; FMax(a,b)
  %3287 = call float @dx.op.binary.f32(i32 35, float %2690, float %3284)  ; FMax(a,b)
  %3288 = call float @dx.op.binary.f32(i32 35, float %2691, float %3285)  ; FMax(a,b)
  %3289 = fsub fast float %3286, %3274
  %3290 = fsub fast float %3287, %3275
  %3291 = fsub fast float %3288, %3276
  %3292 = call float @dx.op.unary.f32(i32 6, float %3289)  ; FAbs(value)
  %3293 = call float @dx.op.unary.f32(i32 6, float %3290)  ; FAbs(value)
  %3294 = call float @dx.op.unary.f32(i32 6, float %3291)  ; FAbs(value)
  %3295 = call float @dx.op.binary.f32(i32 35, float %3293, float %3294)  ; FMax(a,b)
  %3296 = call float @dx.op.binary.f32(i32 35, float %3292, float %3295)  ; FMax(a,b)
  %3297 = call float @dx.op.binary.f32(i32 35, float %3287, float %3288)  ; FMax(a,b)
  %3298 = call float @dx.op.binary.f32(i32 35, float %3286, float %3297)  ; FMax(a,b)
  %3299 = fmul fast float %3298, 1.250000e-01
  %3300 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %3299)  ; FMax(a,b)
  %3301 = fcmp fast ogt float %3296, %3300
  br i1 %3301, label %3302, label %3364

; <label>:3302                                    ; preds = %3261
  %3303 = fsub fast float %2837, %2978
  %3304 = fsub fast float %2838, %2979
  %3305 = fsub fast float %2839, %2980
  %3306 = call float @dx.op.unary.f32(i32 6, float %3303)  ; FAbs(value)
  %3307 = call float @dx.op.unary.f32(i32 6, float %3304)  ; FAbs(value)
  %3308 = call float @dx.op.unary.f32(i32 6, float %3305)  ; FAbs(value)
  %3309 = call float @dx.op.binary.f32(i32 35, float %3307, float %3308)  ; FMax(a,b)
  %3310 = call float @dx.op.binary.f32(i32 35, float %3306, float %3309)  ; FMax(a,b)
  %3311 = fsub fast float %3121, %3262
  %3312 = fsub fast float %3122, %3263
  %3313 = fsub fast float %3123, %3264
  %3314 = call float @dx.op.unary.f32(i32 6, float %3311)  ; FAbs(value)
  %3315 = call float @dx.op.unary.f32(i32 6, float %3312)  ; FAbs(value)
  %3316 = call float @dx.op.unary.f32(i32 6, float %3313)  ; FAbs(value)
  %3317 = call float @dx.op.binary.f32(i32 35, float %3315, float %3316)  ; FMax(a,b)
  %3318 = call float @dx.op.binary.f32(i32 35, float %3314, float %3317)  ; FMax(a,b)
  %3319 = fcmp fast olt float %3310, %3318
  %3320 = select i1 %3319, float %2837, float %3121
  %3321 = select i1 %3319, float %2838, float %3122
  %3322 = select i1 %3319, float %2839, float %3123
  %3323 = select i1 %3319, float %2978, float %3262
  %3324 = select i1 %3319, float %2979, float %3263
  %3325 = select i1 %3319, float %2980, float %3264
  %3326 = fsub fast float %2689, %3323
  %3327 = fsub fast float %2690, %3324
  %3328 = fsub fast float %2691, %3325
  %3329 = fsub fast float %2689, %3320
  %3330 = fsub fast float %2690, %3321
  %3331 = fsub fast float %2691, %3322
  %3332 = call float @dx.op.dot3.f32(i32 55, float %3329, float %3330, float %3331, float %3326, float %3327, float %3328)  ; Dot3(ax,ay,az,bx,by,bz)
  %3333 = fcmp fast ogt float %3332, 0.000000e+00
  br i1 %3333, label %3334, label %3346

; <label>:3334                                    ; preds = %3302
  %3335 = fsub fast float %3320, %3323
  %3336 = fsub fast float %3321, %3324
  %3337 = fsub fast float %3322, %3325
  %3338 = call float @dx.op.unary.f32(i32 6, float %3335)  ; FAbs(value)
  %3339 = call float @dx.op.unary.f32(i32 6, float %3336)  ; FAbs(value)
  %3340 = call float @dx.op.unary.f32(i32 6, float %3337)  ; FAbs(value)
  %3341 = call float @dx.op.binary.f32(i32 35, float %3339, float %3340)  ; FMax(a,b)
  %3342 = call float @dx.op.binary.f32(i32 35, float %3338, float %3341)  ; FMax(a,b)
  %3343 = fmul fast float %3296, 2.500000e-01
  %3344 = fcmp fast olt float %3342, %3343
  %3345 = select i1 %3344, float 5.000000e-01, float 1.000000e+00
  br label %3346

; <label>:3346                                    ; preds = %3334, %3302
  %3347 = phi float [ 1.000000e+00, %3302 ], [ %3345, %3334 ]
  %3348 = fmul fast float %3347, %3
  %3349 = fadd fast float %3320, %3323
  %3350 = fadd fast float %3321, %3324
  %3351 = fadd fast float %3322, %3325
  %3352 = fmul fast float %3349, 5.000000e-01
  %3353 = fmul fast float %3350, 5.000000e-01
  %3354 = fmul fast float %3351, 5.000000e-01
  %3355 = fsub fast float %3352, %2689
  %3356 = fsub fast float %3353, %2690
  %3357 = fsub fast float %3354, %2691
  %3358 = fmul fast float %3348, %3355
  %3359 = fmul fast float %3348, %3356
  %3360 = fmul fast float %3348, %3357
  %3361 = fadd fast float %3358, %2689
  %3362 = fadd fast float %3359, %2690
  %3363 = fadd fast float %3360, %2691
  br label %3364

; <label>:3364                                    ; preds = %3346, %3261, %2660
  %3365 = phi float [ %2689, %2660 ], [ %3361, %3346 ], [ %2689, %3261 ]
  %3366 = phi float [ %2690, %2660 ], [ %3362, %3346 ], [ %2690, %3261 ]
  %3367 = phi float [ %2691, %2660 ], [ %3363, %3346 ], [ %2691, %3261 ]
  %3368 = fcmp fast ogt float %3365, 0x3F69A5C380000000
  %3369 = fcmp fast ogt float %3366, 0x3F69A5C380000000
  %3370 = fcmp fast ogt float %3367, 0x3F69A5C380000000
  %3371 = select i1 %3368, float 0.000000e+00, float 1.000000e+00
  %3372 = select i1 %3369, float 0.000000e+00, float 1.000000e+00
  %3373 = select i1 %3370, float 0.000000e+00, float 1.000000e+00
  %3374 = fmul fast float %3365, 0x4029D70A40000000
  %3375 = fmul fast float %3366, 0x4029D70A40000000
  %3376 = fmul fast float %3367, 0x4029D70A40000000
  %3377 = call float @dx.op.binary.f32(i32 35, float %3365, float 0.000000e+00)  ; FMax(a,b)
  %3378 = call float @dx.op.binary.f32(i32 35, float %3366, float 0.000000e+00)  ; FMax(a,b)
  %3379 = call float @dx.op.binary.f32(i32 35, float %3367, float 0.000000e+00)  ; FMax(a,b)
  %3380 = call float @dx.op.unary.f32(i32 23, float %3377)  ; Log(value)
  %3381 = call float @dx.op.unary.f32(i32 23, float %3378)  ; Log(value)
  %3382 = call float @dx.op.unary.f32(i32 23, float %3379)  ; Log(value)
  %3383 = fmul fast float %3380, 0x3FDAAAAAA0000000
  %3384 = fmul fast float %3381, 0x3FDAAAAAA0000000
  %3385 = fmul fast float %3382, 0x3FDAAAAAA0000000
  %3386 = call float @dx.op.unary.f32(i32 21, float %3383)  ; Exp(value)
  %3387 = call float @dx.op.unary.f32(i32 21, float %3384)  ; Exp(value)
  %3388 = call float @dx.op.unary.f32(i32 21, float %3385)  ; Exp(value)
  %3389 = fmul fast float %3386, 0x3FF0E147A0000000
  %3390 = fmul fast float %3387, 0x3FF0E147A0000000
  %3391 = fmul fast float %3388, 0x3FF0E147A0000000
  %3392 = fadd fast float %3389, 0xBFAC28F5C0000000
  %3393 = fadd fast float %3390, 0xBFAC28F5C0000000
  %3394 = fadd fast float %3391, 0xBFAC28F5C0000000
  %3395 = fsub fast float %3374, %3392
  %3396 = fsub fast float %3375, %3393
  %3397 = fsub fast float %3376, %3394
  %3398 = fmul fast float %3395, %3371
  %3399 = fmul fast float %3396, %3372
  %3400 = fmul fast float %3397, %3373
  %3401 = fadd fast float %3398, %3392
  %3402 = fadd fast float %3399, %3393
  %3403 = fadd fast float %3400, %3394
  br label %3404

; <label>:3404                                    ; preds = %3364, %2622
  %3405 = phi float [ %2617, %2622 ], [ %3401, %3364 ]
  %3406 = phi float [ %2618, %2622 ], [ %3402, %3364 ]
  %3407 = phi float [ %2619, %2622 ], [ %3403, %3364 ]
  %3408 = phi float [ %2623, %2622 ], [ %2620, %3364 ]
  %3409 = fcmp fast ogt float %3405, 0x3FA4B5DCC0000000
  %3410 = fcmp fast ogt float %3406, 0x3FA4B5DCC0000000
  %3411 = fcmp fast ogt float %3407, 0x3FA4B5DCC0000000
  %3412 = select i1 %3409, float 0.000000e+00, float 1.000000e+00
  %3413 = select i1 %3410, float 0.000000e+00, float 1.000000e+00
  %3414 = select i1 %3411, float 0.000000e+00, float 1.000000e+00
  %3415 = fmul fast float %3405, 0x3FB3D07220000000
  %3416 = fmul fast float %3406, 0x3FB3D07220000000
  %3417 = fmul fast float %3407, 0x3FB3D07220000000
  %3418 = fadd fast float %3405, 0x3FAC28F5C0000000
  %3419 = fadd fast float %3406, 0x3FAC28F5C0000000
  %3420 = fadd fast float %3407, 0x3FAC28F5C0000000
  %3421 = fmul fast float %3418, 0x3FEE54EDE0000000
  %3422 = fmul fast float %3419, 0x3FEE54EDE0000000
  %3423 = fmul fast float %3420, 0x3FEE54EDE0000000
  %3424 = call float @dx.op.unary.f32(i32 23, float %3421)  ; Log(value)
  %3425 = call float @dx.op.unary.f32(i32 23, float %3422)  ; Log(value)
  %3426 = call float @dx.op.unary.f32(i32 23, float %3423)  ; Log(value)
  %3427 = fmul fast float %3424, 0x4003333340000000
  %3428 = fmul fast float %3425, 0x4003333340000000
  %3429 = fmul fast float %3426, 0x4003333340000000
  %3430 = call float @dx.op.unary.f32(i32 21, float %3427)  ; Exp(value)
  %3431 = call float @dx.op.unary.f32(i32 21, float %3428)  ; Exp(value)
  %3432 = call float @dx.op.unary.f32(i32 21, float %3429)  ; Exp(value)
  %3433 = fsub fast float %3415, %3430
  %3434 = fsub fast float %3416, %3431
  %3435 = fsub fast float %3417, %3432
  %3436 = fmul fast float %3433, %3412
  %3437 = fmul fast float %3434, %3413
  %3438 = fmul fast float %3435, %3414
  %3439 = fadd fast float %3436, %3430
  %3440 = fadd fast float %3437, %3431
  %3441 = fadd fast float %3438, %3432
  %3442 = fmul fast float %961, %134
  %3443 = fmul fast float %962, %134
  %3444 = fmul fast float %963, %134
  %3445 = fmul fast float %1787, %135
  %3446 = fmul fast float %1788, %135
  %3447 = fmul fast float %1789, %135
  %3448 = fadd fast float %3445, %3442
  %3449 = fadd fast float %3446, %3443
  %3450 = fadd fast float %3447, %3444
  %3451 = fmul fast float %2613, %136
  %3452 = fmul fast float %2614, %136
  %3453 = fmul fast float %2615, %136
  %3454 = fadd fast float %3448, %3451
  %3455 = fadd fast float %3449, %3452
  %3456 = fadd fast float %3450, %3453
  %3457 = fmul fast float %3439, %137
  %3458 = fmul fast float %3440, %137
  %3459 = fmul fast float %3441, %137
  %3460 = fadd fast float %3454, %3457
  %3461 = fadd fast float %3455, %3458
  %3462 = fadd fast float %3456, %3459
  %3463 = fcmp fast ogt float %3460, 0x3F69A5C380000000
  %3464 = fcmp fast ogt float %3461, 0x3F69A5C380000000
  %3465 = fcmp fast ogt float %3462, 0x3F69A5C380000000
  %3466 = select i1 %3463, float 0.000000e+00, float 1.000000e+00
  %3467 = select i1 %3464, float 0.000000e+00, float 1.000000e+00
  %3468 = select i1 %3465, float 0.000000e+00, float 1.000000e+00
  %3469 = fmul fast float %3460, 0x4029D70A40000000
  %3470 = fmul fast float %3461, 0x4029D70A40000000
  %3471 = fmul fast float %3462, 0x4029D70A40000000
  %3472 = call float @dx.op.binary.f32(i32 35, float %3460, float 0.000000e+00)  ; FMax(a,b)
  %3473 = call float @dx.op.binary.f32(i32 35, float %3461, float 0.000000e+00)  ; FMax(a,b)
  %3474 = call float @dx.op.binary.f32(i32 35, float %3462, float 0.000000e+00)  ; FMax(a,b)
  %3475 = call float @dx.op.unary.f32(i32 23, float %3472)  ; Log(value)
  %3476 = call float @dx.op.unary.f32(i32 23, float %3473)  ; Log(value)
  %3477 = call float @dx.op.unary.f32(i32 23, float %3474)  ; Log(value)
  %3478 = fmul fast float %3475, 0x3FDAAAAAA0000000
  %3479 = fmul fast float %3476, 0x3FDAAAAAA0000000
  %3480 = fmul fast float %3477, 0x3FDAAAAAA0000000
  %3481 = call float @dx.op.unary.f32(i32 21, float %3478)  ; Exp(value)
  %3482 = call float @dx.op.unary.f32(i32 21, float %3479)  ; Exp(value)
  %3483 = call float @dx.op.unary.f32(i32 21, float %3480)  ; Exp(value)
  %3484 = fmul fast float %3481, 0x3FF0E147A0000000
  %3485 = fmul fast float %3482, 0x3FF0E147A0000000
  %3486 = fmul fast float %3483, 0x3FF0E147A0000000
  %3487 = fadd fast float %3484, 0xBFAC28F5C0000000
  %3488 = fadd fast float %3485, 0xBFAC28F5C0000000
  %3489 = fadd fast float %3486, 0xBFAC28F5C0000000
  %3490 = fsub fast float %3469, %3487
  %3491 = fsub fast float %3470, %3488
  %3492 = fsub fast float %3471, %3489
  %3493 = fmul fast float %3490, %3466
  %3494 = fmul fast float %3491, %3467
  %3495 = fmul fast float %3492, %3468
  %3496 = fadd fast float %3493, %3487
  %3497 = fadd fast float %3494, %3488
  %3498 = fadd fast float %3495, %3489
  %3499 = call float @dx.op.dot4.f32(i32 56, float %930, float %1756, float %2582, float %3408, float %134, float %135, float %136, float %137)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %3496)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %3497)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %3498)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %3499)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %52)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare i1 @dx.op.isSpecialFloat.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !37, null}
!12 = !{!13, !16, !17, !19, !21, !23, !25, !27, !29, !31, !34}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !15}
!17 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !18, i8 1, i32 1, i8 4, i32 2, i8 0, null}
!18 = !{i32 1}
!19 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !20, i8 1, i32 1, i8 4, i32 3, i8 0, null}
!20 = !{i32 2}
!21 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !22, i8 1, i32 1, i8 4, i32 4, i8 0, null}
!22 = !{i32 3}
!23 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !24, i8 1, i32 1, i8 4, i32 5, i8 0, null}
!24 = !{i32 4}
!25 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !26, i8 1, i32 1, i8 4, i32 6, i8 0, null}
!26 = !{i32 5}
!27 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !28, i8 1, i32 1, i8 4, i32 7, i8 0, null}
!28 = !{i32 6}
!29 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 8, i8 0, null}
!30 = !{i32 7}
!31 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 9, i8 0, !33}
!32 = !{i32 8}
!33 = !{i32 3, i32 15}
!34 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !35, i8 1, i32 1, i8 4, i32 10, i8 0, !36}
!35 = !{i32 9}
!36 = !{i32 3, i32 7}
!37 = !{!38, !39}
!38 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !33}
!39 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !40}
!40 = !{i32 3, i32 1}
