;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float    yz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: 59ffa8e425480f6f38d9dc2afa617d54
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %40 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %41 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %42 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %43 = extractvalue %dx.types.Dimensions %42, 0
  %44 = extractvalue %dx.types.Dimensions %42, 1
  %45 = uitofp i32 %43 to float
  %46 = uitofp i32 %44 to float
  %47 = fmul fast float %45, %40
  %48 = fmul fast float %46, %41
  %49 = fdiv fast float %47, %3
  %50 = fdiv fast float %48, %4
  %51 = fadd fast float %49, -5.000000e-01
  %52 = fadd fast float %50, -5.000000e-01
  %53 = call float @dx.op.unary.f32(i32 27, float %51)  ; Round_ni(value)
  %54 = call float @dx.op.unary.f32(i32 27, float %52)  ; Round_ni(value)
  %55 = fptosi float %53 to i32
  %56 = fptosi float %54 to i32
  %57 = call float @dx.op.unary.f32(i32 22, float %51)  ; Frc(value)
  %58 = call float @dx.op.unary.f32(i32 22, float %52)  ; Frc(value)
  %59 = add i32 %43, -1
  %60 = add i32 %44, -1
  %61 = call i32 @dx.op.binary.i32(i32 37, i32 %55, i32 0)  ; IMax(a,b)
  %62 = call i32 @dx.op.binary.i32(i32 37, i32 %56, i32 0)  ; IMax(a,b)
  %63 = call i32 @dx.op.binary.i32(i32 38, i32 %61, i32 %59)  ; IMin(a,b)
  %64 = call i32 @dx.op.binary.i32(i32 38, i32 %62, i32 %60)  ; IMin(a,b)
  %65 = add i32 %55, 1
  %66 = call i32 @dx.op.binary.i32(i32 37, i32 %65, i32 0)  ; IMax(a,b)
  %67 = call i32 @dx.op.binary.i32(i32 38, i32 %66, i32 %59)  ; IMin(a,b)
  %68 = add i32 %56, 1
  %69 = call i32 @dx.op.binary.i32(i32 37, i32 %68, i32 0)  ; IMax(a,b)
  %70 = call i32 @dx.op.binary.i32(i32 38, i32 %69, i32 %60)  ; IMin(a,b)
  %71 = call float @dx.op.unary.f32(i32 27, float %49)  ; Round_ni(value)
  %72 = call float @dx.op.unary.f32(i32 27, float %50)  ; Round_ni(value)
  %73 = fptosi float %71 to i32
  %74 = fptosi float %72 to i32
  %75 = call i32 @dx.op.binary.i32(i32 37, i32 %73, i32 0)  ; IMax(a,b)
  %76 = call i32 @dx.op.binary.i32(i32 37, i32 %74, i32 0)  ; IMax(a,b)
  %77 = call i32 @dx.op.binary.i32(i32 38, i32 %75, i32 %59)  ; IMin(a,b)
  %78 = call i32 @dx.op.binary.i32(i32 38, i32 %76, i32 %60)  ; IMin(a,b)
  %79 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %77, i32 %78, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %80 = extractvalue %dx.types.ResRet.f32 %79, 0
  %81 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %82 = extractvalue %dx.types.ResRet.f32 %81, 0
  %83 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %67, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %84 = extractvalue %dx.types.ResRet.f32 %83, 0
  %85 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %86 = extractvalue %dx.types.ResRet.f32 %85, 0
  %87 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %67, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %88 = extractvalue %dx.types.ResRet.f32 %87, 0
  %89 = fsub fast float 1.000000e+00, %57
  %90 = fsub fast float 1.000000e+00, %58
  %91 = fmul fast float %90, %89
  %92 = fmul fast float %90, %57
  %93 = fmul fast float %89, %58
  %94 = fmul fast float %58, %57
  %95 = fsub fast float 1.000000e+00, %80
  %96 = fmul fast float %95, 0x3FA99999A0000000
  %97 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %96)  ; FMax(a,b)
  %98 = fsub fast float %82, %80
  %99 = call float @dx.op.unary.f32(i32 6, float %98)  ; FAbs(value)
  %100 = fdiv fast float %99, %97
  %101 = fsub fast float 1.000000e+00, %100
  %102 = call float @dx.op.unary.f32(i32 7, float %101)  ; Saturate(value)
  %103 = fsub fast float %84, %80
  %104 = call float @dx.op.unary.f32(i32 6, float %103)  ; FAbs(value)
  %105 = fdiv fast float %104, %97
  %106 = fsub fast float 1.000000e+00, %105
  %107 = call float @dx.op.unary.f32(i32 7, float %106)  ; Saturate(value)
  %108 = fsub fast float %86, %80
  %109 = call float @dx.op.unary.f32(i32 6, float %108)  ; FAbs(value)
  %110 = fdiv fast float %109, %97
  %111 = fsub fast float 1.000000e+00, %110
  %112 = call float @dx.op.unary.f32(i32 7, float %111)  ; Saturate(value)
  %113 = fsub fast float %88, %80
  %114 = call float @dx.op.unary.f32(i32 6, float %113)  ; FAbs(value)
  %115 = fdiv fast float %114, %97
  %116 = fsub fast float 1.000000e+00, %115
  %117 = call float @dx.op.unary.f32(i32 7, float %116)  ; Saturate(value)
  %118 = fmul fast float %91, %102
  %119 = fmul fast float %92, %107
  %120 = fmul fast float %93, %112
  %121 = fmul fast float %94, %117
  %122 = fcmp fast oge float %57, 5.000000e-01
  %123 = zext i1 %122 to i32
  %124 = fcmp fast oge float %58, 5.000000e-01
  %125 = select i1 %124, i32 2, i32 0
  %126 = or i32 %125, %123
  %127 = call float @dx.op.dot4.f32(i32 56, float %118, float %119, float %120, float %121, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %128 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %118)  ; IsFinite(value)
  %129 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %119)  ; IsFinite(value)
  %130 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %120)  ; IsFinite(value)
  %131 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %121)  ; IsFinite(value)
  %132 = and i1 %128, %129
  %133 = and i1 %132, %130
  %134 = and i1 %133, %131
  br i1 %134, label %135, label %152

; <label>:135                                     ; preds = %0
  %136 = fcmp fast oge float %118, 0.000000e+00
  %137 = fcmp fast oge float %119, 0.000000e+00
  %138 = fcmp fast oge float %120, 0.000000e+00
  %139 = fcmp fast oge float %121, 0.000000e+00
  %140 = and i1 %136, %137
  %141 = and i1 %140, %138
  %142 = and i1 %141, %139
  br i1 %142, label %143, label %152

; <label>:143                                     ; preds = %135
  %144 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %127)  ; IsFinite(value)
  %145 = fcmp fast oge float %127, 0x3810000000000000
  %146 = and i1 %145, %144
  br i1 %146, label %147, label %152

; <label>:147                                     ; preds = %143
  %148 = fdiv fast float %118, %127
  %149 = fdiv fast float %119, %127
  %150 = fdiv fast float %120, %127
  %151 = fdiv fast float %121, %127
  br label %161

; <label>:152                                     ; preds = %143, %135, %0
  %153 = icmp eq i32 %126, 0
  %154 = uitofp i1 %153 to float
  %155 = icmp eq i32 %126, 1
  %156 = uitofp i1 %155 to float
  %157 = icmp eq i32 %126, 2
  %158 = uitofp i1 %157 to float
  %159 = icmp eq i32 %126, 3
  %160 = uitofp i1 %159 to float
  br label %161

; <label>:161                                     ; preds = %152, %147
  %162 = phi float [ %148, %147 ], [ %154, %152 ]
  %163 = phi float [ %149, %147 ], [ %156, %152 ]
  %164 = phi float [ %150, %147 ], [ %158, %152 ]
  %165 = phi float [ %151, %147 ], [ %160, %152 ]
  %166 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %167 = extractvalue %dx.types.ResRet.f32 %166, 0
  %168 = extractvalue %dx.types.ResRet.f32 %166, 1
  %169 = extractvalue %dx.types.ResRet.f32 %166, 2
  %170 = extractvalue %dx.types.ResRet.f32 %166, 3
  %171 = fcmp fast olt float %170, 0.000000e+00
  br i1 %171, label %172, label %174

; <label>:172                                     ; preds = %161
  %173 = fsub fast float -1.000000e+00, %170
  br label %1424

; <label>:174                                     ; preds = %161
  %175 = fcmp fast ogt float %38, 5.000000e-01
  %176 = fcmp fast olt float %82, 1.000000e+00
  %177 = and i1 %175, %176
  br i1 %177, label %178, label %264

; <label>:178                                     ; preds = %174
  %179 = sitofp i32 %63 to float
  %180 = sitofp i32 %64 to float
  %181 = fadd fast float %179, 5.000000e-01
  %182 = fadd fast float %180, 5.000000e-01
  %183 = fdiv fast float %181, %45
  %184 = fdiv fast float %182, %46
  %185 = fmul fast float %183, 2.000000e+00
  %186 = fmul fast float %184, 2.000000e+00
  %187 = fadd fast float %185, -1.000000e+00
  %188 = fsub fast float 1.000000e+00, %186
  %189 = fmul fast float %187, %35
  %190 = call float @dx.op.tertiary.f32(i32 46, float %188, float %31, float %189)  ; FMad(a,b,c)
  %191 = call float @dx.op.tertiary.f32(i32 46, float %82, float %27, float %190)  ; FMad(a,b,c)
  %192 = fadd fast float %191, %23
  %193 = call float @dx.op.unary.f32(i32 6, float %192)  ; FAbs(value)
  %194 = fcmp fast ogt float %193, 0x3EB0C6F7A0000000
  br i1 %194, label %195, label %264

; <label>:195                                     ; preds = %178
  %196 = fmul fast float %187, %34
  %197 = call float @dx.op.tertiary.f32(i32 46, float %188, float %30, float %196)  ; FMad(a,b,c)
  %198 = call float @dx.op.tertiary.f32(i32 46, float %82, float %26, float %197)  ; FMad(a,b,c)
  %199 = fadd fast float %198, %22
  %200 = fmul fast float %187, %33
  %201 = call float @dx.op.tertiary.f32(i32 46, float %188, float %29, float %200)  ; FMad(a,b,c)
  %202 = call float @dx.op.tertiary.f32(i32 46, float %82, float %25, float %201)  ; FMad(a,b,c)
  %203 = fadd fast float %202, %21
  %204 = fmul fast float %187, %32
  %205 = call float @dx.op.tertiary.f32(i32 46, float %188, float %28, float %204)  ; FMad(a,b,c)
  %206 = call float @dx.op.tertiary.f32(i32 46, float %82, float %24, float %205)  ; FMad(a,b,c)
  %207 = fadd fast float %206, %20
  %208 = fdiv fast float %207, %192
  %209 = fdiv fast float %203, %192
  %210 = fdiv fast float %199, %192
  %211 = fsub fast float %208, %17
  %212 = fsub fast float %209, %18
  %213 = fsub fast float %210, %19
  %214 = fmul fast float %211, %211
  %215 = fmul fast float %212, %212
  %216 = fadd fast float %215, %214
  %217 = fmul fast float %213, %213
  %218 = fadd fast float %216, %217
  %219 = call float @dx.op.unary.f32(i32 24, float %218)  ; Sqrt(value)
  %220 = fsub fast float %219, %9
  %221 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %220)  ; FMax(a,b)
  %222 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %222, label %223, label %246

; <label>:223                                     ; preds = %195
  %224 = call float @dx.op.unary.f32(i32 6, float %212)  ; FAbs(value)
  %225 = fmul fast float %224, %11
  %226 = fcmp fast olt float %225, 0x3F50624DE0000000
  br i1 %226, label %227, label %230

; <label>:227                                     ; preds = %223
  %228 = fmul fast float %225, 5.000000e-01
  %229 = fsub fast float 1.000000e+00, %228
  br label %235

; <label>:230                                     ; preds = %223
  %231 = fmul fast float %225, 0xBFF7154760000000
  %232 = call float @dx.op.unary.f32(i32 21, float %231)  ; Exp(value)
  %233 = fsub fast float 1.000000e+00, %232
  %234 = fdiv fast float %233, %225
  br label %235

; <label>:235                                     ; preds = %230, %227
  %236 = phi float [ %229, %227 ], [ %234, %230 ]
  %237 = call float @dx.op.binary.f32(i32 36, float %209, float %18)  ; FMin(a,b)
  %238 = fsub fast float %237, %10
  %239 = fmul fast float %11, %238
  %240 = fsub fast float -0.000000e+00, %239
  %241 = call float @dx.op.binary.f32(i32 35, float %240, float -4.000000e+01)  ; FMax(a,b)
  %242 = call float @dx.op.binary.f32(i32 36, float %241, float 5.000000e+00)  ; FMin(a,b)
  %243 = fmul fast float %242, 0x3FF7154760000000
  %244 = call float @dx.op.unary.f32(i32 21, float %243)  ; Exp(value)
  %245 = fmul fast float %244, %236
  br label %246

; <label>:246                                     ; preds = %235, %195
  %247 = phi float [ %245, %235 ], [ 1.000000e+00, %195 ]
  %248 = fmul fast float %221, %16
  %249 = fmul fast float %248, %247
  %250 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %249)  ; FMin(a,b)
  %251 = fmul fast float %250, 0xBFF7154760000000
  %252 = call float @dx.op.unary.f32(i32 21, float %251)  ; Exp(value)
  %253 = fsub fast float 1.000000e+00, %252
  %254 = call float @dx.op.binary.f32(i32 36, float %12, float %253)  ; FMin(a,b)
  %255 = fsub fast float %13, %167
  %256 = fsub fast float %14, %168
  %257 = fsub fast float %15, %169
  %258 = fmul fast float %254, %255
  %259 = fmul fast float %254, %256
  %260 = fmul fast float %254, %257
  %261 = fadd fast float %258, %167
  %262 = fadd fast float %259, %168
  %263 = fadd fast float %260, %169
  br label %264

; <label>:264                                     ; preds = %246, %178, %174
  %265 = phi float [ %261, %246 ], [ %167, %178 ], [ %167, %174 ]
  %266 = phi float [ %262, %246 ], [ %168, %178 ], [ %168, %174 ]
  %267 = phi float [ %263, %246 ], [ %169, %178 ], [ %169, %174 ]
  %268 = fadd fast float %5, 1.000000e+00
  %269 = fadd fast float %6, 1.000000e+00
  %270 = fsub fast float 1.000000e+00, %5
  %271 = fmul fast float %36, %268
  %272 = fmul fast float %36, %269
  %273 = fmul fast float %36, %270
  %274 = fmul fast float %271, %265
  %275 = fmul fast float %272, %266
  %276 = fmul fast float %273, %267
  %277 = fcmp fast ult float %37, 5.000000e-01
  br i1 %277, label %303, label %278

; <label>:278                                     ; preds = %264
  %279 = fmul fast float %274, 0x4004147AE0000000
  %280 = fmul fast float %275, 0x4004147AE0000000
  %281 = fmul fast float %276, 0x4004147AE0000000
  %282 = fadd fast float %279, 0x3F9EB851E0000000
  %283 = fadd fast float %280, 0x3F9EB851E0000000
  %284 = fadd fast float %281, 0x3F9EB851E0000000
  %285 = fmul fast float %282, %274
  %286 = fmul fast float %283, %275
  %287 = fmul fast float %284, %276
  %288 = fmul fast float %274, 0x400370A3E0000000
  %289 = fmul fast float %275, 0x400370A3E0000000
  %290 = fmul fast float %276, 0x400370A3E0000000
  %291 = fadd fast float %288, 0x3FE2E147A0000000
  %292 = fadd fast float %289, 0x3FE2E147A0000000
  %293 = fadd fast float %290, 0x3FE2E147A0000000
  %294 = fmul fast float %291, %274
  %295 = fmul fast float %292, %275
  %296 = fmul fast float %293, %276
  %297 = fadd fast float %294, 0x3FC1EB8520000000
  %298 = fadd fast float %295, 0x3FC1EB8520000000
  %299 = fadd fast float %296, 0x3FC1EB8520000000
  %300 = fdiv fast float %285, %297
  %301 = fdiv fast float %286, %298
  %302 = fdiv fast float %287, %299
  br label %303

; <label>:303                                     ; preds = %278, %264
  %304 = phi float [ %300, %278 ], [ %274, %264 ]
  %305 = phi float [ %301, %278 ], [ %275, %264 ]
  %306 = phi float [ %302, %278 ], [ %276, %264 ]
  %307 = call float @dx.op.unary.f32(i32 7, float %304)  ; Saturate(value)
  %308 = call float @dx.op.unary.f32(i32 7, float %305)  ; Saturate(value)
  %309 = call float @dx.op.unary.f32(i32 7, float %306)  ; Saturate(value)
  %310 = call float @dx.op.dot3.f32(i32 55, float %307, float %308, float %309, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %311 = fsub fast float %307, %310
  %312 = fsub fast float %308, %310
  %313 = fsub fast float %309, %310
  %314 = fmul fast float %311, %8
  %315 = fmul fast float %312, %8
  %316 = fmul fast float %313, %8
  %317 = fadd fast float %314, %310
  %318 = fadd fast float %315, %310
  %319 = fadd fast float %316, %310
  %320 = call float @dx.op.unary.f32(i32 7, float %317)  ; Saturate(value)
  %321 = call float @dx.op.unary.f32(i32 7, float %318)  ; Saturate(value)
  %322 = call float @dx.op.unary.f32(i32 7, float %319)  ; Saturate(value)
  %323 = fadd fast float %320, 0xBFC70A3D80000000
  %324 = fadd fast float %321, 0xBFC70A3D80000000
  %325 = fadd fast float %322, 0xBFC70A3D80000000
  %326 = fmul fast float %323, %7
  %327 = fmul fast float %324, %7
  %328 = fmul fast float %325, %7
  %329 = fadd fast float %326, 0x3FC70A3D80000000
  %330 = fadd fast float %327, 0x3FC70A3D80000000
  %331 = fadd fast float %328, 0x3FC70A3D80000000
  %332 = call float @dx.op.unary.f32(i32 7, float %329)  ; Saturate(value)
  %333 = call float @dx.op.unary.f32(i32 7, float %330)  ; Saturate(value)
  %334 = call float @dx.op.unary.f32(i32 7, float %331)  ; Saturate(value)
  %335 = add i32 %64, -1
  %336 = call i32 @dx.op.binary.i32(i32 37, i32 %63, i32 0)  ; IMax(a,b)
  %337 = call i32 @dx.op.binary.i32(i32 37, i32 %335, i32 0)  ; IMax(a,b)
  %338 = call i32 @dx.op.binary.i32(i32 38, i32 %336, i32 %59)  ; IMin(a,b)
  %339 = call i32 @dx.op.binary.i32(i32 38, i32 %337, i32 %60)  ; IMin(a,b)
  %340 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %338, i32 %339, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %341 = extractvalue %dx.types.ResRet.f32 %340, 0
  %342 = fsub fast float 1.000000e+00, %82
  %343 = fmul fast float %342, 0x3FA99999A0000000
  %344 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %343)  ; FMax(a,b)
  %345 = fsub fast float %341, %82
  %346 = call float @dx.op.unary.f32(i32 6, float %345)  ; FAbs(value)
  %347 = fdiv fast float %346, %344
  %348 = fsub fast float 1.000000e+00, %347
  %349 = call float @dx.op.unary.f32(i32 7, float %348)  ; Saturate(value)
  %350 = fcmp fast ugt float %349, 0.000000e+00
  br i1 %350, label %351, label %572

; <label>:351                                     ; preds = %303
  %352 = call i32 @dx.op.binary.i32(i32 37, i32 %338, i32 0)  ; IMax(a,b)
  %353 = call i32 @dx.op.binary.i32(i32 37, i32 %339, i32 0)  ; IMax(a,b)
  %354 = call i32 @dx.op.binary.i32(i32 38, i32 %352, i32 %59)  ; IMin(a,b)
  %355 = call i32 @dx.op.binary.i32(i32 38, i32 %353, i32 %60)  ; IMin(a,b)
  %356 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %354, i32 %355, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %357 = extractvalue %dx.types.ResRet.f32 %356, 0
  %358 = extractvalue %dx.types.ResRet.f32 %356, 1
  %359 = extractvalue %dx.types.ResRet.f32 %356, 2
  %360 = extractvalue %dx.types.ResRet.f32 %356, 3
  %361 = fcmp fast olt float %360, 0.000000e+00
  br i1 %361, label %362, label %396

; <label>:362                                     ; preds = %351
  %363 = fcmp fast ogt float %357, 0x3FA4B5DCC0000000
  %364 = fcmp fast ogt float %358, 0x3FA4B5DCC0000000
  %365 = fcmp fast ogt float %359, 0x3FA4B5DCC0000000
  %366 = select i1 %363, float 0.000000e+00, float 1.000000e+00
  %367 = select i1 %364, float 0.000000e+00, float 1.000000e+00
  %368 = select i1 %365, float 0.000000e+00, float 1.000000e+00
  %369 = fmul fast float %357, 0x3FB3D07220000000
  %370 = fmul fast float %358, 0x3FB3D07220000000
  %371 = fmul fast float %359, 0x3FB3D07220000000
  %372 = fadd fast float %357, 0x3FAC28F5C0000000
  %373 = fadd fast float %358, 0x3FAC28F5C0000000
  %374 = fadd fast float %359, 0x3FAC28F5C0000000
  %375 = fmul fast float %372, 0x3FEE54EDE0000000
  %376 = fmul fast float %373, 0x3FEE54EDE0000000
  %377 = fmul fast float %374, 0x3FEE54EDE0000000
  %378 = call float @dx.op.unary.f32(i32 23, float %375)  ; Log(value)
  %379 = call float @dx.op.unary.f32(i32 23, float %376)  ; Log(value)
  %380 = call float @dx.op.unary.f32(i32 23, float %377)  ; Log(value)
  %381 = fmul fast float %378, 0x4003333340000000
  %382 = fmul fast float %379, 0x4003333340000000
  %383 = fmul fast float %380, 0x4003333340000000
  %384 = call float @dx.op.unary.f32(i32 21, float %381)  ; Exp(value)
  %385 = call float @dx.op.unary.f32(i32 21, float %382)  ; Exp(value)
  %386 = call float @dx.op.unary.f32(i32 21, float %383)  ; Exp(value)
  %387 = fsub fast float %369, %384
  %388 = fsub fast float %370, %385
  %389 = fsub fast float %371, %386
  %390 = fmul fast float %387, %366
  %391 = fmul fast float %388, %367
  %392 = fmul fast float %389, %368
  %393 = fadd fast float %390, %384
  %394 = fadd fast float %391, %385
  %395 = fadd fast float %392, %386
  br label %559

; <label>:396                                     ; preds = %351
  %397 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %354, i32 %355, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %398 = extractvalue %dx.types.ResRet.f32 %397, 0
  %399 = fcmp fast ogt float %38, 5.000000e-01
  %400 = fcmp fast olt float %398, 1.000000e+00
  %401 = and i1 %399, %400
  br i1 %401, label %402, label %488

; <label>:402                                     ; preds = %396
  %403 = sitofp i32 %354 to float
  %404 = sitofp i32 %355 to float
  %405 = fadd fast float %403, 5.000000e-01
  %406 = fadd fast float %404, 5.000000e-01
  %407 = fdiv fast float %405, %45
  %408 = fdiv fast float %406, %46
  %409 = fmul fast float %407, 2.000000e+00
  %410 = fmul fast float %408, 2.000000e+00
  %411 = fadd fast float %409, -1.000000e+00
  %412 = fsub fast float 1.000000e+00, %410
  %413 = fmul fast float %411, %35
  %414 = call float @dx.op.tertiary.f32(i32 46, float %412, float %31, float %413)  ; FMad(a,b,c)
  %415 = call float @dx.op.tertiary.f32(i32 46, float %398, float %27, float %414)  ; FMad(a,b,c)
  %416 = fadd fast float %415, %23
  %417 = call float @dx.op.unary.f32(i32 6, float %416)  ; FAbs(value)
  %418 = fcmp fast ogt float %417, 0x3EB0C6F7A0000000
  br i1 %418, label %419, label %488

; <label>:419                                     ; preds = %402
  %420 = fmul fast float %411, %34
  %421 = call float @dx.op.tertiary.f32(i32 46, float %412, float %30, float %420)  ; FMad(a,b,c)
  %422 = call float @dx.op.tertiary.f32(i32 46, float %398, float %26, float %421)  ; FMad(a,b,c)
  %423 = fadd fast float %422, %22
  %424 = fmul fast float %411, %33
  %425 = call float @dx.op.tertiary.f32(i32 46, float %412, float %29, float %424)  ; FMad(a,b,c)
  %426 = call float @dx.op.tertiary.f32(i32 46, float %398, float %25, float %425)  ; FMad(a,b,c)
  %427 = fadd fast float %426, %21
  %428 = fmul fast float %411, %32
  %429 = call float @dx.op.tertiary.f32(i32 46, float %412, float %28, float %428)  ; FMad(a,b,c)
  %430 = call float @dx.op.tertiary.f32(i32 46, float %398, float %24, float %429)  ; FMad(a,b,c)
  %431 = fadd fast float %430, %20
  %432 = fdiv fast float %431, %416
  %433 = fdiv fast float %427, %416
  %434 = fdiv fast float %423, %416
  %435 = fsub fast float %432, %17
  %436 = fsub fast float %433, %18
  %437 = fsub fast float %434, %19
  %438 = fmul fast float %435, %435
  %439 = fmul fast float %436, %436
  %440 = fadd fast float %439, %438
  %441 = fmul fast float %437, %437
  %442 = fadd fast float %440, %441
  %443 = call float @dx.op.unary.f32(i32 24, float %442)  ; Sqrt(value)
  %444 = fsub fast float %443, %9
  %445 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %444)  ; FMax(a,b)
  %446 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %446, label %447, label %470

; <label>:447                                     ; preds = %419
  %448 = call float @dx.op.unary.f32(i32 6, float %436)  ; FAbs(value)
  %449 = fmul fast float %448, %11
  %450 = fcmp fast olt float %449, 0x3F50624DE0000000
  br i1 %450, label %451, label %454

; <label>:451                                     ; preds = %447
  %452 = fmul fast float %449, 5.000000e-01
  %453 = fsub fast float 1.000000e+00, %452
  br label %459

; <label>:454                                     ; preds = %447
  %455 = fmul fast float %449, 0xBFF7154760000000
  %456 = call float @dx.op.unary.f32(i32 21, float %455)  ; Exp(value)
  %457 = fsub fast float 1.000000e+00, %456
  %458 = fdiv fast float %457, %449
  br label %459

; <label>:459                                     ; preds = %454, %451
  %460 = phi float [ %453, %451 ], [ %458, %454 ]
  %461 = call float @dx.op.binary.f32(i32 36, float %433, float %18)  ; FMin(a,b)
  %462 = fsub fast float %461, %10
  %463 = fmul fast float %11, %462
  %464 = fsub fast float -0.000000e+00, %463
  %465 = call float @dx.op.binary.f32(i32 35, float %464, float -4.000000e+01)  ; FMax(a,b)
  %466 = call float @dx.op.binary.f32(i32 36, float %465, float 5.000000e+00)  ; FMin(a,b)
  %467 = fmul fast float %466, 0x3FF7154760000000
  %468 = call float @dx.op.unary.f32(i32 21, float %467)  ; Exp(value)
  %469 = fmul fast float %468, %460
  br label %470

; <label>:470                                     ; preds = %459, %419
  %471 = phi float [ %469, %459 ], [ 1.000000e+00, %419 ]
  %472 = fmul fast float %445, %16
  %473 = fmul fast float %472, %471
  %474 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %473)  ; FMin(a,b)
  %475 = fmul fast float %474, 0xBFF7154760000000
  %476 = call float @dx.op.unary.f32(i32 21, float %475)  ; Exp(value)
  %477 = fsub fast float 1.000000e+00, %476
  %478 = call float @dx.op.binary.f32(i32 36, float %12, float %477)  ; FMin(a,b)
  %479 = fsub fast float %13, %357
  %480 = fsub fast float %14, %358
  %481 = fsub fast float %15, %359
  %482 = fmul fast float %478, %479
  %483 = fmul fast float %478, %480
  %484 = fmul fast float %478, %481
  %485 = fadd fast float %482, %357
  %486 = fadd fast float %483, %358
  %487 = fadd fast float %484, %359
  br label %488

; <label>:488                                     ; preds = %470, %402, %396
  %489 = phi float [ %485, %470 ], [ %357, %402 ], [ %357, %396 ]
  %490 = phi float [ %486, %470 ], [ %358, %402 ], [ %358, %396 ]
  %491 = phi float [ %487, %470 ], [ %359, %402 ], [ %359, %396 ]
  %492 = fadd fast float %5, 1.000000e+00
  %493 = fadd fast float %6, 1.000000e+00
  %494 = fsub fast float 1.000000e+00, %5
  %495 = fmul fast float %36, %492
  %496 = fmul fast float %36, %493
  %497 = fmul fast float %36, %494
  %498 = fmul fast float %495, %489
  %499 = fmul fast float %496, %490
  %500 = fmul fast float %497, %491
  %501 = fcmp fast ult float %37, 5.000000e-01
  br i1 %501, label %527, label %502

; <label>:502                                     ; preds = %488
  %503 = fmul fast float %498, 0x4004147AE0000000
  %504 = fmul fast float %499, 0x4004147AE0000000
  %505 = fmul fast float %500, 0x4004147AE0000000
  %506 = fadd fast float %503, 0x3F9EB851E0000000
  %507 = fadd fast float %504, 0x3F9EB851E0000000
  %508 = fadd fast float %505, 0x3F9EB851E0000000
  %509 = fmul fast float %506, %498
  %510 = fmul fast float %507, %499
  %511 = fmul fast float %508, %500
  %512 = fmul fast float %498, 0x400370A3E0000000
  %513 = fmul fast float %499, 0x400370A3E0000000
  %514 = fmul fast float %500, 0x400370A3E0000000
  %515 = fadd fast float %512, 0x3FE2E147A0000000
  %516 = fadd fast float %513, 0x3FE2E147A0000000
  %517 = fadd fast float %514, 0x3FE2E147A0000000
  %518 = fmul fast float %515, %498
  %519 = fmul fast float %516, %499
  %520 = fmul fast float %517, %500
  %521 = fadd fast float %518, 0x3FC1EB8520000000
  %522 = fadd fast float %519, 0x3FC1EB8520000000
  %523 = fadd fast float %520, 0x3FC1EB8520000000
  %524 = fdiv fast float %509, %521
  %525 = fdiv fast float %510, %522
  %526 = fdiv fast float %511, %523
  br label %527

; <label>:527                                     ; preds = %502, %488
  %528 = phi float [ %524, %502 ], [ %498, %488 ]
  %529 = phi float [ %525, %502 ], [ %499, %488 ]
  %530 = phi float [ %526, %502 ], [ %500, %488 ]
  %531 = call float @dx.op.unary.f32(i32 7, float %528)  ; Saturate(value)
  %532 = call float @dx.op.unary.f32(i32 7, float %529)  ; Saturate(value)
  %533 = call float @dx.op.unary.f32(i32 7, float %530)  ; Saturate(value)
  %534 = call float @dx.op.dot3.f32(i32 55, float %531, float %532, float %533, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %535 = fsub fast float %531, %534
  %536 = fsub fast float %532, %534
  %537 = fsub fast float %533, %534
  %538 = fmul fast float %535, %8
  %539 = fmul fast float %536, %8
  %540 = fmul fast float %537, %8
  %541 = fadd fast float %538, %534
  %542 = fadd fast float %539, %534
  %543 = fadd fast float %540, %534
  %544 = call float @dx.op.unary.f32(i32 7, float %541)  ; Saturate(value)
  %545 = call float @dx.op.unary.f32(i32 7, float %542)  ; Saturate(value)
  %546 = call float @dx.op.unary.f32(i32 7, float %543)  ; Saturate(value)
  %547 = fadd fast float %544, 0xBFC70A3D80000000
  %548 = fadd fast float %545, 0xBFC70A3D80000000
  %549 = fadd fast float %546, 0xBFC70A3D80000000
  %550 = fmul fast float %547, %7
  %551 = fmul fast float %548, %7
  %552 = fmul fast float %549, %7
  %553 = fadd fast float %550, 0x3FC70A3D80000000
  %554 = fadd fast float %551, 0x3FC70A3D80000000
  %555 = fadd fast float %552, 0x3FC70A3D80000000
  %556 = call float @dx.op.unary.f32(i32 7, float %553)  ; Saturate(value)
  %557 = call float @dx.op.unary.f32(i32 7, float %554)  ; Saturate(value)
  %558 = call float @dx.op.unary.f32(i32 7, float %555)  ; Saturate(value)
  br label %559

; <label>:559                                     ; preds = %527, %362
  %560 = phi float [ %393, %362 ], [ %556, %527 ]
  %561 = phi float [ %394, %362 ], [ %557, %527 ]
  %562 = phi float [ %395, %362 ], [ %558, %527 ]
  %563 = fsub fast float %560, %332
  %564 = fsub fast float %561, %333
  %565 = fsub fast float %562, %334
  %566 = fmul fast float %563, %349
  %567 = fmul fast float %564, %349
  %568 = fmul fast float %565, %349
  %569 = fadd fast float %566, %332
  %570 = fadd fast float %567, %333
  %571 = fadd fast float %568, %334
  br label %572

; <label>:572                                     ; preds = %559, %303
  %573 = phi float [ %569, %559 ], [ %332, %303 ]
  %574 = phi float [ %570, %559 ], [ %333, %303 ]
  %575 = phi float [ %571, %559 ], [ %334, %303 ]
  %576 = add i32 %64, 1
  %577 = call i32 @dx.op.binary.i32(i32 37, i32 %576, i32 0)  ; IMax(a,b)
  %578 = call i32 @dx.op.binary.i32(i32 38, i32 %577, i32 %60)  ; IMin(a,b)
  %579 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %338, i32 %578, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %580 = extractvalue %dx.types.ResRet.f32 %579, 0
  %581 = fsub fast float %580, %82
  %582 = call float @dx.op.unary.f32(i32 6, float %581)  ; FAbs(value)
  %583 = fdiv fast float %582, %344
  %584 = fsub fast float 1.000000e+00, %583
  %585 = call float @dx.op.unary.f32(i32 7, float %584)  ; Saturate(value)
  %586 = fcmp fast ugt float %585, 0.000000e+00
  br i1 %586, label %587, label %808

; <label>:587                                     ; preds = %572
  %588 = call i32 @dx.op.binary.i32(i32 37, i32 %338, i32 0)  ; IMax(a,b)
  %589 = call i32 @dx.op.binary.i32(i32 37, i32 %578, i32 0)  ; IMax(a,b)
  %590 = call i32 @dx.op.binary.i32(i32 38, i32 %588, i32 %59)  ; IMin(a,b)
  %591 = call i32 @dx.op.binary.i32(i32 38, i32 %589, i32 %60)  ; IMin(a,b)
  %592 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %590, i32 %591, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %593 = extractvalue %dx.types.ResRet.f32 %592, 0
  %594 = extractvalue %dx.types.ResRet.f32 %592, 1
  %595 = extractvalue %dx.types.ResRet.f32 %592, 2
  %596 = extractvalue %dx.types.ResRet.f32 %592, 3
  %597 = fcmp fast olt float %596, 0.000000e+00
  br i1 %597, label %598, label %632

; <label>:598                                     ; preds = %587
  %599 = fcmp fast ogt float %593, 0x3FA4B5DCC0000000
  %600 = fcmp fast ogt float %594, 0x3FA4B5DCC0000000
  %601 = fcmp fast ogt float %595, 0x3FA4B5DCC0000000
  %602 = select i1 %599, float 0.000000e+00, float 1.000000e+00
  %603 = select i1 %600, float 0.000000e+00, float 1.000000e+00
  %604 = select i1 %601, float 0.000000e+00, float 1.000000e+00
  %605 = fmul fast float %593, 0x3FB3D07220000000
  %606 = fmul fast float %594, 0x3FB3D07220000000
  %607 = fmul fast float %595, 0x3FB3D07220000000
  %608 = fadd fast float %593, 0x3FAC28F5C0000000
  %609 = fadd fast float %594, 0x3FAC28F5C0000000
  %610 = fadd fast float %595, 0x3FAC28F5C0000000
  %611 = fmul fast float %608, 0x3FEE54EDE0000000
  %612 = fmul fast float %609, 0x3FEE54EDE0000000
  %613 = fmul fast float %610, 0x3FEE54EDE0000000
  %614 = call float @dx.op.unary.f32(i32 23, float %611)  ; Log(value)
  %615 = call float @dx.op.unary.f32(i32 23, float %612)  ; Log(value)
  %616 = call float @dx.op.unary.f32(i32 23, float %613)  ; Log(value)
  %617 = fmul fast float %614, 0x4003333340000000
  %618 = fmul fast float %615, 0x4003333340000000
  %619 = fmul fast float %616, 0x4003333340000000
  %620 = call float @dx.op.unary.f32(i32 21, float %617)  ; Exp(value)
  %621 = call float @dx.op.unary.f32(i32 21, float %618)  ; Exp(value)
  %622 = call float @dx.op.unary.f32(i32 21, float %619)  ; Exp(value)
  %623 = fsub fast float %605, %620
  %624 = fsub fast float %606, %621
  %625 = fsub fast float %607, %622
  %626 = fmul fast float %623, %602
  %627 = fmul fast float %624, %603
  %628 = fmul fast float %625, %604
  %629 = fadd fast float %626, %620
  %630 = fadd fast float %627, %621
  %631 = fadd fast float %628, %622
  br label %795

; <label>:632                                     ; preds = %587
  %633 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %590, i32 %591, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %634 = extractvalue %dx.types.ResRet.f32 %633, 0
  %635 = fcmp fast ogt float %38, 5.000000e-01
  %636 = fcmp fast olt float %634, 1.000000e+00
  %637 = and i1 %635, %636
  br i1 %637, label %638, label %724

; <label>:638                                     ; preds = %632
  %639 = sitofp i32 %590 to float
  %640 = sitofp i32 %591 to float
  %641 = fadd fast float %639, 5.000000e-01
  %642 = fadd fast float %640, 5.000000e-01
  %643 = fdiv fast float %641, %45
  %644 = fdiv fast float %642, %46
  %645 = fmul fast float %643, 2.000000e+00
  %646 = fmul fast float %644, 2.000000e+00
  %647 = fadd fast float %645, -1.000000e+00
  %648 = fsub fast float 1.000000e+00, %646
  %649 = fmul fast float %647, %35
  %650 = call float @dx.op.tertiary.f32(i32 46, float %648, float %31, float %649)  ; FMad(a,b,c)
  %651 = call float @dx.op.tertiary.f32(i32 46, float %634, float %27, float %650)  ; FMad(a,b,c)
  %652 = fadd fast float %651, %23
  %653 = call float @dx.op.unary.f32(i32 6, float %652)  ; FAbs(value)
  %654 = fcmp fast ogt float %653, 0x3EB0C6F7A0000000
  br i1 %654, label %655, label %724

; <label>:655                                     ; preds = %638
  %656 = fmul fast float %647, %34
  %657 = call float @dx.op.tertiary.f32(i32 46, float %648, float %30, float %656)  ; FMad(a,b,c)
  %658 = call float @dx.op.tertiary.f32(i32 46, float %634, float %26, float %657)  ; FMad(a,b,c)
  %659 = fadd fast float %658, %22
  %660 = fmul fast float %647, %33
  %661 = call float @dx.op.tertiary.f32(i32 46, float %648, float %29, float %660)  ; FMad(a,b,c)
  %662 = call float @dx.op.tertiary.f32(i32 46, float %634, float %25, float %661)  ; FMad(a,b,c)
  %663 = fadd fast float %662, %21
  %664 = fmul fast float %647, %32
  %665 = call float @dx.op.tertiary.f32(i32 46, float %648, float %28, float %664)  ; FMad(a,b,c)
  %666 = call float @dx.op.tertiary.f32(i32 46, float %634, float %24, float %665)  ; FMad(a,b,c)
  %667 = fadd fast float %666, %20
  %668 = fdiv fast float %667, %652
  %669 = fdiv fast float %663, %652
  %670 = fdiv fast float %659, %652
  %671 = fsub fast float %668, %17
  %672 = fsub fast float %669, %18
  %673 = fsub fast float %670, %19
  %674 = fmul fast float %671, %671
  %675 = fmul fast float %672, %672
  %676 = fadd fast float %675, %674
  %677 = fmul fast float %673, %673
  %678 = fadd fast float %676, %677
  %679 = call float @dx.op.unary.f32(i32 24, float %678)  ; Sqrt(value)
  %680 = fsub fast float %679, %9
  %681 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %680)  ; FMax(a,b)
  %682 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %682, label %683, label %706

; <label>:683                                     ; preds = %655
  %684 = call float @dx.op.unary.f32(i32 6, float %672)  ; FAbs(value)
  %685 = fmul fast float %684, %11
  %686 = fcmp fast olt float %685, 0x3F50624DE0000000
  br i1 %686, label %687, label %690

; <label>:687                                     ; preds = %683
  %688 = fmul fast float %685, 5.000000e-01
  %689 = fsub fast float 1.000000e+00, %688
  br label %695

; <label>:690                                     ; preds = %683
  %691 = fmul fast float %685, 0xBFF7154760000000
  %692 = call float @dx.op.unary.f32(i32 21, float %691)  ; Exp(value)
  %693 = fsub fast float 1.000000e+00, %692
  %694 = fdiv fast float %693, %685
  br label %695

; <label>:695                                     ; preds = %690, %687
  %696 = phi float [ %689, %687 ], [ %694, %690 ]
  %697 = call float @dx.op.binary.f32(i32 36, float %669, float %18)  ; FMin(a,b)
  %698 = fsub fast float %697, %10
  %699 = fmul fast float %11, %698
  %700 = fsub fast float -0.000000e+00, %699
  %701 = call float @dx.op.binary.f32(i32 35, float %700, float -4.000000e+01)  ; FMax(a,b)
  %702 = call float @dx.op.binary.f32(i32 36, float %701, float 5.000000e+00)  ; FMin(a,b)
  %703 = fmul fast float %702, 0x3FF7154760000000
  %704 = call float @dx.op.unary.f32(i32 21, float %703)  ; Exp(value)
  %705 = fmul fast float %704, %696
  br label %706

; <label>:706                                     ; preds = %695, %655
  %707 = phi float [ %705, %695 ], [ 1.000000e+00, %655 ]
  %708 = fmul fast float %681, %16
  %709 = fmul fast float %708, %707
  %710 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %709)  ; FMin(a,b)
  %711 = fmul fast float %710, 0xBFF7154760000000
  %712 = call float @dx.op.unary.f32(i32 21, float %711)  ; Exp(value)
  %713 = fsub fast float 1.000000e+00, %712
  %714 = call float @dx.op.binary.f32(i32 36, float %12, float %713)  ; FMin(a,b)
  %715 = fsub fast float %13, %593
  %716 = fsub fast float %14, %594
  %717 = fsub fast float %15, %595
  %718 = fmul fast float %714, %715
  %719 = fmul fast float %714, %716
  %720 = fmul fast float %714, %717
  %721 = fadd fast float %718, %593
  %722 = fadd fast float %719, %594
  %723 = fadd fast float %720, %595
  br label %724

; <label>:724                                     ; preds = %706, %638, %632
  %725 = phi float [ %721, %706 ], [ %593, %638 ], [ %593, %632 ]
  %726 = phi float [ %722, %706 ], [ %594, %638 ], [ %594, %632 ]
  %727 = phi float [ %723, %706 ], [ %595, %638 ], [ %595, %632 ]
  %728 = fadd fast float %5, 1.000000e+00
  %729 = fadd fast float %6, 1.000000e+00
  %730 = fsub fast float 1.000000e+00, %5
  %731 = fmul fast float %36, %728
  %732 = fmul fast float %36, %729
  %733 = fmul fast float %36, %730
  %734 = fmul fast float %731, %725
  %735 = fmul fast float %732, %726
  %736 = fmul fast float %733, %727
  %737 = fcmp fast ult float %37, 5.000000e-01
  br i1 %737, label %763, label %738

; <label>:738                                     ; preds = %724
  %739 = fmul fast float %734, 0x4004147AE0000000
  %740 = fmul fast float %735, 0x4004147AE0000000
  %741 = fmul fast float %736, 0x4004147AE0000000
  %742 = fadd fast float %739, 0x3F9EB851E0000000
  %743 = fadd fast float %740, 0x3F9EB851E0000000
  %744 = fadd fast float %741, 0x3F9EB851E0000000
  %745 = fmul fast float %742, %734
  %746 = fmul fast float %743, %735
  %747 = fmul fast float %744, %736
  %748 = fmul fast float %734, 0x400370A3E0000000
  %749 = fmul fast float %735, 0x400370A3E0000000
  %750 = fmul fast float %736, 0x400370A3E0000000
  %751 = fadd fast float %748, 0x3FE2E147A0000000
  %752 = fadd fast float %749, 0x3FE2E147A0000000
  %753 = fadd fast float %750, 0x3FE2E147A0000000
  %754 = fmul fast float %751, %734
  %755 = fmul fast float %752, %735
  %756 = fmul fast float %753, %736
  %757 = fadd fast float %754, 0x3FC1EB8520000000
  %758 = fadd fast float %755, 0x3FC1EB8520000000
  %759 = fadd fast float %756, 0x3FC1EB8520000000
  %760 = fdiv fast float %745, %757
  %761 = fdiv fast float %746, %758
  %762 = fdiv fast float %747, %759
  br label %763

; <label>:763                                     ; preds = %738, %724
  %764 = phi float [ %760, %738 ], [ %734, %724 ]
  %765 = phi float [ %761, %738 ], [ %735, %724 ]
  %766 = phi float [ %762, %738 ], [ %736, %724 ]
  %767 = call float @dx.op.unary.f32(i32 7, float %764)  ; Saturate(value)
  %768 = call float @dx.op.unary.f32(i32 7, float %765)  ; Saturate(value)
  %769 = call float @dx.op.unary.f32(i32 7, float %766)  ; Saturate(value)
  %770 = call float @dx.op.dot3.f32(i32 55, float %767, float %768, float %769, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %771 = fsub fast float %767, %770
  %772 = fsub fast float %768, %770
  %773 = fsub fast float %769, %770
  %774 = fmul fast float %771, %8
  %775 = fmul fast float %772, %8
  %776 = fmul fast float %773, %8
  %777 = fadd fast float %774, %770
  %778 = fadd fast float %775, %770
  %779 = fadd fast float %776, %770
  %780 = call float @dx.op.unary.f32(i32 7, float %777)  ; Saturate(value)
  %781 = call float @dx.op.unary.f32(i32 7, float %778)  ; Saturate(value)
  %782 = call float @dx.op.unary.f32(i32 7, float %779)  ; Saturate(value)
  %783 = fadd fast float %780, 0xBFC70A3D80000000
  %784 = fadd fast float %781, 0xBFC70A3D80000000
  %785 = fadd fast float %782, 0xBFC70A3D80000000
  %786 = fmul fast float %783, %7
  %787 = fmul fast float %784, %7
  %788 = fmul fast float %785, %7
  %789 = fadd fast float %786, 0x3FC70A3D80000000
  %790 = fadd fast float %787, 0x3FC70A3D80000000
  %791 = fadd fast float %788, 0x3FC70A3D80000000
  %792 = call float @dx.op.unary.f32(i32 7, float %789)  ; Saturate(value)
  %793 = call float @dx.op.unary.f32(i32 7, float %790)  ; Saturate(value)
  %794 = call float @dx.op.unary.f32(i32 7, float %791)  ; Saturate(value)
  br label %795

; <label>:795                                     ; preds = %763, %598
  %796 = phi float [ %629, %598 ], [ %792, %763 ]
  %797 = phi float [ %630, %598 ], [ %793, %763 ]
  %798 = phi float [ %631, %598 ], [ %794, %763 ]
  %799 = fsub fast float %796, %332
  %800 = fsub fast float %797, %333
  %801 = fsub fast float %798, %334
  %802 = fmul fast float %799, %585
  %803 = fmul fast float %800, %585
  %804 = fmul fast float %801, %585
  %805 = fadd fast float %802, %332
  %806 = fadd fast float %803, %333
  %807 = fadd fast float %804, %334
  br label %808

; <label>:808                                     ; preds = %795, %572
  %809 = phi float [ %805, %795 ], [ %332, %572 ]
  %810 = phi float [ %806, %795 ], [ %333, %572 ]
  %811 = phi float [ %807, %795 ], [ %334, %572 ]
  %812 = add i32 %63, -1
  %813 = call i32 @dx.op.binary.i32(i32 37, i32 %812, i32 0)  ; IMax(a,b)
  %814 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %815 = call i32 @dx.op.binary.i32(i32 38, i32 %813, i32 %59)  ; IMin(a,b)
  %816 = call i32 @dx.op.binary.i32(i32 38, i32 %814, i32 %60)  ; IMin(a,b)
  %817 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %815, i32 %816, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %818 = extractvalue %dx.types.ResRet.f32 %817, 0
  %819 = fsub fast float %818, %82
  %820 = call float @dx.op.unary.f32(i32 6, float %819)  ; FAbs(value)
  %821 = fdiv fast float %820, %344
  %822 = fsub fast float 1.000000e+00, %821
  %823 = call float @dx.op.unary.f32(i32 7, float %822)  ; Saturate(value)
  %824 = fcmp fast ugt float %823, 0.000000e+00
  br i1 %824, label %825, label %1046

; <label>:825                                     ; preds = %808
  %826 = call i32 @dx.op.binary.i32(i32 37, i32 %815, i32 0)  ; IMax(a,b)
  %827 = call i32 @dx.op.binary.i32(i32 37, i32 %816, i32 0)  ; IMax(a,b)
  %828 = call i32 @dx.op.binary.i32(i32 38, i32 %826, i32 %59)  ; IMin(a,b)
  %829 = call i32 @dx.op.binary.i32(i32 38, i32 %827, i32 %60)  ; IMin(a,b)
  %830 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %828, i32 %829, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %831 = extractvalue %dx.types.ResRet.f32 %830, 0
  %832 = extractvalue %dx.types.ResRet.f32 %830, 1
  %833 = extractvalue %dx.types.ResRet.f32 %830, 2
  %834 = extractvalue %dx.types.ResRet.f32 %830, 3
  %835 = fcmp fast olt float %834, 0.000000e+00
  br i1 %835, label %836, label %870

; <label>:836                                     ; preds = %825
  %837 = fcmp fast ogt float %831, 0x3FA4B5DCC0000000
  %838 = fcmp fast ogt float %832, 0x3FA4B5DCC0000000
  %839 = fcmp fast ogt float %833, 0x3FA4B5DCC0000000
  %840 = select i1 %837, float 0.000000e+00, float 1.000000e+00
  %841 = select i1 %838, float 0.000000e+00, float 1.000000e+00
  %842 = select i1 %839, float 0.000000e+00, float 1.000000e+00
  %843 = fmul fast float %831, 0x3FB3D07220000000
  %844 = fmul fast float %832, 0x3FB3D07220000000
  %845 = fmul fast float %833, 0x3FB3D07220000000
  %846 = fadd fast float %831, 0x3FAC28F5C0000000
  %847 = fadd fast float %832, 0x3FAC28F5C0000000
  %848 = fadd fast float %833, 0x3FAC28F5C0000000
  %849 = fmul fast float %846, 0x3FEE54EDE0000000
  %850 = fmul fast float %847, 0x3FEE54EDE0000000
  %851 = fmul fast float %848, 0x3FEE54EDE0000000
  %852 = call float @dx.op.unary.f32(i32 23, float %849)  ; Log(value)
  %853 = call float @dx.op.unary.f32(i32 23, float %850)  ; Log(value)
  %854 = call float @dx.op.unary.f32(i32 23, float %851)  ; Log(value)
  %855 = fmul fast float %852, 0x4003333340000000
  %856 = fmul fast float %853, 0x4003333340000000
  %857 = fmul fast float %854, 0x4003333340000000
  %858 = call float @dx.op.unary.f32(i32 21, float %855)  ; Exp(value)
  %859 = call float @dx.op.unary.f32(i32 21, float %856)  ; Exp(value)
  %860 = call float @dx.op.unary.f32(i32 21, float %857)  ; Exp(value)
  %861 = fsub fast float %843, %858
  %862 = fsub fast float %844, %859
  %863 = fsub fast float %845, %860
  %864 = fmul fast float %861, %840
  %865 = fmul fast float %862, %841
  %866 = fmul fast float %863, %842
  %867 = fadd fast float %864, %858
  %868 = fadd fast float %865, %859
  %869 = fadd fast float %866, %860
  br label %1033

; <label>:870                                     ; preds = %825
  %871 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %828, i32 %829, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %872 = extractvalue %dx.types.ResRet.f32 %871, 0
  %873 = fcmp fast ogt float %38, 5.000000e-01
  %874 = fcmp fast olt float %872, 1.000000e+00
  %875 = and i1 %873, %874
  br i1 %875, label %876, label %962

; <label>:876                                     ; preds = %870
  %877 = sitofp i32 %828 to float
  %878 = sitofp i32 %829 to float
  %879 = fadd fast float %877, 5.000000e-01
  %880 = fadd fast float %878, 5.000000e-01
  %881 = fdiv fast float %879, %45
  %882 = fdiv fast float %880, %46
  %883 = fmul fast float %881, 2.000000e+00
  %884 = fmul fast float %882, 2.000000e+00
  %885 = fadd fast float %883, -1.000000e+00
  %886 = fsub fast float 1.000000e+00, %884
  %887 = fmul fast float %885, %35
  %888 = call float @dx.op.tertiary.f32(i32 46, float %886, float %31, float %887)  ; FMad(a,b,c)
  %889 = call float @dx.op.tertiary.f32(i32 46, float %872, float %27, float %888)  ; FMad(a,b,c)
  %890 = fadd fast float %889, %23
  %891 = call float @dx.op.unary.f32(i32 6, float %890)  ; FAbs(value)
  %892 = fcmp fast ogt float %891, 0x3EB0C6F7A0000000
  br i1 %892, label %893, label %962

; <label>:893                                     ; preds = %876
  %894 = fmul fast float %885, %34
  %895 = call float @dx.op.tertiary.f32(i32 46, float %886, float %30, float %894)  ; FMad(a,b,c)
  %896 = call float @dx.op.tertiary.f32(i32 46, float %872, float %26, float %895)  ; FMad(a,b,c)
  %897 = fadd fast float %896, %22
  %898 = fmul fast float %885, %33
  %899 = call float @dx.op.tertiary.f32(i32 46, float %886, float %29, float %898)  ; FMad(a,b,c)
  %900 = call float @dx.op.tertiary.f32(i32 46, float %872, float %25, float %899)  ; FMad(a,b,c)
  %901 = fadd fast float %900, %21
  %902 = fmul fast float %885, %32
  %903 = call float @dx.op.tertiary.f32(i32 46, float %886, float %28, float %902)  ; FMad(a,b,c)
  %904 = call float @dx.op.tertiary.f32(i32 46, float %872, float %24, float %903)  ; FMad(a,b,c)
  %905 = fadd fast float %904, %20
  %906 = fdiv fast float %905, %890
  %907 = fdiv fast float %901, %890
  %908 = fdiv fast float %897, %890
  %909 = fsub fast float %906, %17
  %910 = fsub fast float %907, %18
  %911 = fsub fast float %908, %19
  %912 = fmul fast float %909, %909
  %913 = fmul fast float %910, %910
  %914 = fadd fast float %913, %912
  %915 = fmul fast float %911, %911
  %916 = fadd fast float %914, %915
  %917 = call float @dx.op.unary.f32(i32 24, float %916)  ; Sqrt(value)
  %918 = fsub fast float %917, %9
  %919 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %918)  ; FMax(a,b)
  %920 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %920, label %921, label %944

; <label>:921                                     ; preds = %893
  %922 = call float @dx.op.unary.f32(i32 6, float %910)  ; FAbs(value)
  %923 = fmul fast float %922, %11
  %924 = fcmp fast olt float %923, 0x3F50624DE0000000
  br i1 %924, label %925, label %928

; <label>:925                                     ; preds = %921
  %926 = fmul fast float %923, 5.000000e-01
  %927 = fsub fast float 1.000000e+00, %926
  br label %933

; <label>:928                                     ; preds = %921
  %929 = fmul fast float %923, 0xBFF7154760000000
  %930 = call float @dx.op.unary.f32(i32 21, float %929)  ; Exp(value)
  %931 = fsub fast float 1.000000e+00, %930
  %932 = fdiv fast float %931, %923
  br label %933

; <label>:933                                     ; preds = %928, %925
  %934 = phi float [ %927, %925 ], [ %932, %928 ]
  %935 = call float @dx.op.binary.f32(i32 36, float %907, float %18)  ; FMin(a,b)
  %936 = fsub fast float %935, %10
  %937 = fmul fast float %11, %936
  %938 = fsub fast float -0.000000e+00, %937
  %939 = call float @dx.op.binary.f32(i32 35, float %938, float -4.000000e+01)  ; FMax(a,b)
  %940 = call float @dx.op.binary.f32(i32 36, float %939, float 5.000000e+00)  ; FMin(a,b)
  %941 = fmul fast float %940, 0x3FF7154760000000
  %942 = call float @dx.op.unary.f32(i32 21, float %941)  ; Exp(value)
  %943 = fmul fast float %942, %934
  br label %944

; <label>:944                                     ; preds = %933, %893
  %945 = phi float [ %943, %933 ], [ 1.000000e+00, %893 ]
  %946 = fmul fast float %919, %16
  %947 = fmul fast float %946, %945
  %948 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %947)  ; FMin(a,b)
  %949 = fmul fast float %948, 0xBFF7154760000000
  %950 = call float @dx.op.unary.f32(i32 21, float %949)  ; Exp(value)
  %951 = fsub fast float 1.000000e+00, %950
  %952 = call float @dx.op.binary.f32(i32 36, float %12, float %951)  ; FMin(a,b)
  %953 = fsub fast float %13, %831
  %954 = fsub fast float %14, %832
  %955 = fsub fast float %15, %833
  %956 = fmul fast float %952, %953
  %957 = fmul fast float %952, %954
  %958 = fmul fast float %952, %955
  %959 = fadd fast float %956, %831
  %960 = fadd fast float %957, %832
  %961 = fadd fast float %958, %833
  br label %962

; <label>:962                                     ; preds = %944, %876, %870
  %963 = phi float [ %959, %944 ], [ %831, %876 ], [ %831, %870 ]
  %964 = phi float [ %960, %944 ], [ %832, %876 ], [ %832, %870 ]
  %965 = phi float [ %961, %944 ], [ %833, %876 ], [ %833, %870 ]
  %966 = fadd fast float %5, 1.000000e+00
  %967 = fadd fast float %6, 1.000000e+00
  %968 = fsub fast float 1.000000e+00, %5
  %969 = fmul fast float %36, %966
  %970 = fmul fast float %36, %967
  %971 = fmul fast float %36, %968
  %972 = fmul fast float %969, %963
  %973 = fmul fast float %970, %964
  %974 = fmul fast float %971, %965
  %975 = fcmp fast ult float %37, 5.000000e-01
  br i1 %975, label %1001, label %976

; <label>:976                                     ; preds = %962
  %977 = fmul fast float %972, 0x4004147AE0000000
  %978 = fmul fast float %973, 0x4004147AE0000000
  %979 = fmul fast float %974, 0x4004147AE0000000
  %980 = fadd fast float %977, 0x3F9EB851E0000000
  %981 = fadd fast float %978, 0x3F9EB851E0000000
  %982 = fadd fast float %979, 0x3F9EB851E0000000
  %983 = fmul fast float %980, %972
  %984 = fmul fast float %981, %973
  %985 = fmul fast float %982, %974
  %986 = fmul fast float %972, 0x400370A3E0000000
  %987 = fmul fast float %973, 0x400370A3E0000000
  %988 = fmul fast float %974, 0x400370A3E0000000
  %989 = fadd fast float %986, 0x3FE2E147A0000000
  %990 = fadd fast float %987, 0x3FE2E147A0000000
  %991 = fadd fast float %988, 0x3FE2E147A0000000
  %992 = fmul fast float %989, %972
  %993 = fmul fast float %990, %973
  %994 = fmul fast float %991, %974
  %995 = fadd fast float %992, 0x3FC1EB8520000000
  %996 = fadd fast float %993, 0x3FC1EB8520000000
  %997 = fadd fast float %994, 0x3FC1EB8520000000
  %998 = fdiv fast float %983, %995
  %999 = fdiv fast float %984, %996
  %1000 = fdiv fast float %985, %997
  br label %1001

; <label>:1001                                    ; preds = %976, %962
  %1002 = phi float [ %998, %976 ], [ %972, %962 ]
  %1003 = phi float [ %999, %976 ], [ %973, %962 ]
  %1004 = phi float [ %1000, %976 ], [ %974, %962 ]
  %1005 = call float @dx.op.unary.f32(i32 7, float %1002)  ; Saturate(value)
  %1006 = call float @dx.op.unary.f32(i32 7, float %1003)  ; Saturate(value)
  %1007 = call float @dx.op.unary.f32(i32 7, float %1004)  ; Saturate(value)
  %1008 = call float @dx.op.dot3.f32(i32 55, float %1005, float %1006, float %1007, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1009 = fsub fast float %1005, %1008
  %1010 = fsub fast float %1006, %1008
  %1011 = fsub fast float %1007, %1008
  %1012 = fmul fast float %1009, %8
  %1013 = fmul fast float %1010, %8
  %1014 = fmul fast float %1011, %8
  %1015 = fadd fast float %1012, %1008
  %1016 = fadd fast float %1013, %1008
  %1017 = fadd fast float %1014, %1008
  %1018 = call float @dx.op.unary.f32(i32 7, float %1015)  ; Saturate(value)
  %1019 = call float @dx.op.unary.f32(i32 7, float %1016)  ; Saturate(value)
  %1020 = call float @dx.op.unary.f32(i32 7, float %1017)  ; Saturate(value)
  %1021 = fadd fast float %1018, 0xBFC70A3D80000000
  %1022 = fadd fast float %1019, 0xBFC70A3D80000000
  %1023 = fadd fast float %1020, 0xBFC70A3D80000000
  %1024 = fmul fast float %1021, %7
  %1025 = fmul fast float %1022, %7
  %1026 = fmul fast float %1023, %7
  %1027 = fadd fast float %1024, 0x3FC70A3D80000000
  %1028 = fadd fast float %1025, 0x3FC70A3D80000000
  %1029 = fadd fast float %1026, 0x3FC70A3D80000000
  %1030 = call float @dx.op.unary.f32(i32 7, float %1027)  ; Saturate(value)
  %1031 = call float @dx.op.unary.f32(i32 7, float %1028)  ; Saturate(value)
  %1032 = call float @dx.op.unary.f32(i32 7, float %1029)  ; Saturate(value)
  br label %1033

; <label>:1033                                    ; preds = %1001, %836
  %1034 = phi float [ %867, %836 ], [ %1030, %1001 ]
  %1035 = phi float [ %868, %836 ], [ %1031, %1001 ]
  %1036 = phi float [ %869, %836 ], [ %1032, %1001 ]
  %1037 = fsub fast float %1034, %332
  %1038 = fsub fast float %1035, %333
  %1039 = fsub fast float %1036, %334
  %1040 = fmul fast float %1037, %823
  %1041 = fmul fast float %1038, %823
  %1042 = fmul fast float %1039, %823
  %1043 = fadd fast float %1040, %332
  %1044 = fadd fast float %1041, %333
  %1045 = fadd fast float %1042, %334
  br label %1046

; <label>:1046                                    ; preds = %1033, %808
  %1047 = phi float [ %1043, %1033 ], [ %332, %808 ]
  %1048 = phi float [ %1044, %1033 ], [ %333, %808 ]
  %1049 = phi float [ %1045, %1033 ], [ %334, %808 ]
  %1050 = add i32 %63, 1
  %1051 = call i32 @dx.op.binary.i32(i32 37, i32 %1050, i32 0)  ; IMax(a,b)
  %1052 = call i32 @dx.op.binary.i32(i32 38, i32 %1051, i32 %59)  ; IMin(a,b)
  %1053 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1052, i32 %816, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1054 = extractvalue %dx.types.ResRet.f32 %1053, 0
  %1055 = fsub fast float %1054, %82
  %1056 = call float @dx.op.unary.f32(i32 6, float %1055)  ; FAbs(value)
  %1057 = fdiv fast float %1056, %344
  %1058 = fsub fast float 1.000000e+00, %1057
  %1059 = call float @dx.op.unary.f32(i32 7, float %1058)  ; Saturate(value)
  %1060 = fcmp fast ugt float %1059, 0.000000e+00
  br i1 %1060, label %1061, label %1282

; <label>:1061                                    ; preds = %1046
  %1062 = call i32 @dx.op.binary.i32(i32 37, i32 %1052, i32 0)  ; IMax(a,b)
  %1063 = call i32 @dx.op.binary.i32(i32 37, i32 %816, i32 0)  ; IMax(a,b)
  %1064 = call i32 @dx.op.binary.i32(i32 38, i32 %1062, i32 %59)  ; IMin(a,b)
  %1065 = call i32 @dx.op.binary.i32(i32 38, i32 %1063, i32 %60)  ; IMin(a,b)
  %1066 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1064, i32 %1065, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1067 = extractvalue %dx.types.ResRet.f32 %1066, 0
  %1068 = extractvalue %dx.types.ResRet.f32 %1066, 1
  %1069 = extractvalue %dx.types.ResRet.f32 %1066, 2
  %1070 = extractvalue %dx.types.ResRet.f32 %1066, 3
  %1071 = fcmp fast olt float %1070, 0.000000e+00
  br i1 %1071, label %1072, label %1106

; <label>:1072                                    ; preds = %1061
  %1073 = fcmp fast ogt float %1067, 0x3FA4B5DCC0000000
  %1074 = fcmp fast ogt float %1068, 0x3FA4B5DCC0000000
  %1075 = fcmp fast ogt float %1069, 0x3FA4B5DCC0000000
  %1076 = select i1 %1073, float 0.000000e+00, float 1.000000e+00
  %1077 = select i1 %1074, float 0.000000e+00, float 1.000000e+00
  %1078 = select i1 %1075, float 0.000000e+00, float 1.000000e+00
  %1079 = fmul fast float %1067, 0x3FB3D07220000000
  %1080 = fmul fast float %1068, 0x3FB3D07220000000
  %1081 = fmul fast float %1069, 0x3FB3D07220000000
  %1082 = fadd fast float %1067, 0x3FAC28F5C0000000
  %1083 = fadd fast float %1068, 0x3FAC28F5C0000000
  %1084 = fadd fast float %1069, 0x3FAC28F5C0000000
  %1085 = fmul fast float %1082, 0x3FEE54EDE0000000
  %1086 = fmul fast float %1083, 0x3FEE54EDE0000000
  %1087 = fmul fast float %1084, 0x3FEE54EDE0000000
  %1088 = call float @dx.op.unary.f32(i32 23, float %1085)  ; Log(value)
  %1089 = call float @dx.op.unary.f32(i32 23, float %1086)  ; Log(value)
  %1090 = call float @dx.op.unary.f32(i32 23, float %1087)  ; Log(value)
  %1091 = fmul fast float %1088, 0x4003333340000000
  %1092 = fmul fast float %1089, 0x4003333340000000
  %1093 = fmul fast float %1090, 0x4003333340000000
  %1094 = call float @dx.op.unary.f32(i32 21, float %1091)  ; Exp(value)
  %1095 = call float @dx.op.unary.f32(i32 21, float %1092)  ; Exp(value)
  %1096 = call float @dx.op.unary.f32(i32 21, float %1093)  ; Exp(value)
  %1097 = fsub fast float %1079, %1094
  %1098 = fsub fast float %1080, %1095
  %1099 = fsub fast float %1081, %1096
  %1100 = fmul fast float %1097, %1076
  %1101 = fmul fast float %1098, %1077
  %1102 = fmul fast float %1099, %1078
  %1103 = fadd fast float %1100, %1094
  %1104 = fadd fast float %1101, %1095
  %1105 = fadd fast float %1102, %1096
  br label %1269

; <label>:1106                                    ; preds = %1061
  %1107 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1064, i32 %1065, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1108 = extractvalue %dx.types.ResRet.f32 %1107, 0
  %1109 = fcmp fast ogt float %38, 5.000000e-01
  %1110 = fcmp fast olt float %1108, 1.000000e+00
  %1111 = and i1 %1109, %1110
  br i1 %1111, label %1112, label %1198

; <label>:1112                                    ; preds = %1106
  %1113 = sitofp i32 %1064 to float
  %1114 = sitofp i32 %1065 to float
  %1115 = fadd fast float %1113, 5.000000e-01
  %1116 = fadd fast float %1114, 5.000000e-01
  %1117 = fdiv fast float %1115, %45
  %1118 = fdiv fast float %1116, %46
  %1119 = fmul fast float %1117, 2.000000e+00
  %1120 = fmul fast float %1118, 2.000000e+00
  %1121 = fadd fast float %1119, -1.000000e+00
  %1122 = fsub fast float 1.000000e+00, %1120
  %1123 = fmul fast float %1121, %35
  %1124 = call float @dx.op.tertiary.f32(i32 46, float %1122, float %31, float %1123)  ; FMad(a,b,c)
  %1125 = call float @dx.op.tertiary.f32(i32 46, float %1108, float %27, float %1124)  ; FMad(a,b,c)
  %1126 = fadd fast float %1125, %23
  %1127 = call float @dx.op.unary.f32(i32 6, float %1126)  ; FAbs(value)
  %1128 = fcmp fast ogt float %1127, 0x3EB0C6F7A0000000
  br i1 %1128, label %1129, label %1198

; <label>:1129                                    ; preds = %1112
  %1130 = fmul fast float %1121, %34
  %1131 = call float @dx.op.tertiary.f32(i32 46, float %1122, float %30, float %1130)  ; FMad(a,b,c)
  %1132 = call float @dx.op.tertiary.f32(i32 46, float %1108, float %26, float %1131)  ; FMad(a,b,c)
  %1133 = fadd fast float %1132, %22
  %1134 = fmul fast float %1121, %33
  %1135 = call float @dx.op.tertiary.f32(i32 46, float %1122, float %29, float %1134)  ; FMad(a,b,c)
  %1136 = call float @dx.op.tertiary.f32(i32 46, float %1108, float %25, float %1135)  ; FMad(a,b,c)
  %1137 = fadd fast float %1136, %21
  %1138 = fmul fast float %1121, %32
  %1139 = call float @dx.op.tertiary.f32(i32 46, float %1122, float %28, float %1138)  ; FMad(a,b,c)
  %1140 = call float @dx.op.tertiary.f32(i32 46, float %1108, float %24, float %1139)  ; FMad(a,b,c)
  %1141 = fadd fast float %1140, %20
  %1142 = fdiv fast float %1141, %1126
  %1143 = fdiv fast float %1137, %1126
  %1144 = fdiv fast float %1133, %1126
  %1145 = fsub fast float %1142, %17
  %1146 = fsub fast float %1143, %18
  %1147 = fsub fast float %1144, %19
  %1148 = fmul fast float %1145, %1145
  %1149 = fmul fast float %1146, %1146
  %1150 = fadd fast float %1149, %1148
  %1151 = fmul fast float %1147, %1147
  %1152 = fadd fast float %1150, %1151
  %1153 = call float @dx.op.unary.f32(i32 24, float %1152)  ; Sqrt(value)
  %1154 = fsub fast float %1153, %9
  %1155 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1154)  ; FMax(a,b)
  %1156 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1156, label %1157, label %1180

; <label>:1157                                    ; preds = %1129
  %1158 = call float @dx.op.unary.f32(i32 6, float %1146)  ; FAbs(value)
  %1159 = fmul fast float %1158, %11
  %1160 = fcmp fast olt float %1159, 0x3F50624DE0000000
  br i1 %1160, label %1161, label %1164

; <label>:1161                                    ; preds = %1157
  %1162 = fmul fast float %1159, 5.000000e-01
  %1163 = fsub fast float 1.000000e+00, %1162
  br label %1169

; <label>:1164                                    ; preds = %1157
  %1165 = fmul fast float %1159, 0xBFF7154760000000
  %1166 = call float @dx.op.unary.f32(i32 21, float %1165)  ; Exp(value)
  %1167 = fsub fast float 1.000000e+00, %1166
  %1168 = fdiv fast float %1167, %1159
  br label %1169

; <label>:1169                                    ; preds = %1164, %1161
  %1170 = phi float [ %1163, %1161 ], [ %1168, %1164 ]
  %1171 = call float @dx.op.binary.f32(i32 36, float %1143, float %18)  ; FMin(a,b)
  %1172 = fsub fast float %1171, %10
  %1173 = fmul fast float %11, %1172
  %1174 = fsub fast float -0.000000e+00, %1173
  %1175 = call float @dx.op.binary.f32(i32 35, float %1174, float -4.000000e+01)  ; FMax(a,b)
  %1176 = call float @dx.op.binary.f32(i32 36, float %1175, float 5.000000e+00)  ; FMin(a,b)
  %1177 = fmul fast float %1176, 0x3FF7154760000000
  %1178 = call float @dx.op.unary.f32(i32 21, float %1177)  ; Exp(value)
  %1179 = fmul fast float %1178, %1170
  br label %1180

; <label>:1180                                    ; preds = %1169, %1129
  %1181 = phi float [ %1179, %1169 ], [ 1.000000e+00, %1129 ]
  %1182 = fmul fast float %1155, %16
  %1183 = fmul fast float %1182, %1181
  %1184 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1183)  ; FMin(a,b)
  %1185 = fmul fast float %1184, 0xBFF7154760000000
  %1186 = call float @dx.op.unary.f32(i32 21, float %1185)  ; Exp(value)
  %1187 = fsub fast float 1.000000e+00, %1186
  %1188 = call float @dx.op.binary.f32(i32 36, float %12, float %1187)  ; FMin(a,b)
  %1189 = fsub fast float %13, %1067
  %1190 = fsub fast float %14, %1068
  %1191 = fsub fast float %15, %1069
  %1192 = fmul fast float %1188, %1189
  %1193 = fmul fast float %1188, %1190
  %1194 = fmul fast float %1188, %1191
  %1195 = fadd fast float %1192, %1067
  %1196 = fadd fast float %1193, %1068
  %1197 = fadd fast float %1194, %1069
  br label %1198

; <label>:1198                                    ; preds = %1180, %1112, %1106
  %1199 = phi float [ %1195, %1180 ], [ %1067, %1112 ], [ %1067, %1106 ]
  %1200 = phi float [ %1196, %1180 ], [ %1068, %1112 ], [ %1068, %1106 ]
  %1201 = phi float [ %1197, %1180 ], [ %1069, %1112 ], [ %1069, %1106 ]
  %1202 = fadd fast float %5, 1.000000e+00
  %1203 = fadd fast float %6, 1.000000e+00
  %1204 = fsub fast float 1.000000e+00, %5
  %1205 = fmul fast float %36, %1202
  %1206 = fmul fast float %36, %1203
  %1207 = fmul fast float %36, %1204
  %1208 = fmul fast float %1205, %1199
  %1209 = fmul fast float %1206, %1200
  %1210 = fmul fast float %1207, %1201
  %1211 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1211, label %1237, label %1212

; <label>:1212                                    ; preds = %1198
  %1213 = fmul fast float %1208, 0x4004147AE0000000
  %1214 = fmul fast float %1209, 0x4004147AE0000000
  %1215 = fmul fast float %1210, 0x4004147AE0000000
  %1216 = fadd fast float %1213, 0x3F9EB851E0000000
  %1217 = fadd fast float %1214, 0x3F9EB851E0000000
  %1218 = fadd fast float %1215, 0x3F9EB851E0000000
  %1219 = fmul fast float %1216, %1208
  %1220 = fmul fast float %1217, %1209
  %1221 = fmul fast float %1218, %1210
  %1222 = fmul fast float %1208, 0x400370A3E0000000
  %1223 = fmul fast float %1209, 0x400370A3E0000000
  %1224 = fmul fast float %1210, 0x400370A3E0000000
  %1225 = fadd fast float %1222, 0x3FE2E147A0000000
  %1226 = fadd fast float %1223, 0x3FE2E147A0000000
  %1227 = fadd fast float %1224, 0x3FE2E147A0000000
  %1228 = fmul fast float %1225, %1208
  %1229 = fmul fast float %1226, %1209
  %1230 = fmul fast float %1227, %1210
  %1231 = fadd fast float %1228, 0x3FC1EB8520000000
  %1232 = fadd fast float %1229, 0x3FC1EB8520000000
  %1233 = fadd fast float %1230, 0x3FC1EB8520000000
  %1234 = fdiv fast float %1219, %1231
  %1235 = fdiv fast float %1220, %1232
  %1236 = fdiv fast float %1221, %1233
  br label %1237

; <label>:1237                                    ; preds = %1212, %1198
  %1238 = phi float [ %1234, %1212 ], [ %1208, %1198 ]
  %1239 = phi float [ %1235, %1212 ], [ %1209, %1198 ]
  %1240 = phi float [ %1236, %1212 ], [ %1210, %1198 ]
  %1241 = call float @dx.op.unary.f32(i32 7, float %1238)  ; Saturate(value)
  %1242 = call float @dx.op.unary.f32(i32 7, float %1239)  ; Saturate(value)
  %1243 = call float @dx.op.unary.f32(i32 7, float %1240)  ; Saturate(value)
  %1244 = call float @dx.op.dot3.f32(i32 55, float %1241, float %1242, float %1243, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1245 = fsub fast float %1241, %1244
  %1246 = fsub fast float %1242, %1244
  %1247 = fsub fast float %1243, %1244
  %1248 = fmul fast float %1245, %8
  %1249 = fmul fast float %1246, %8
  %1250 = fmul fast float %1247, %8
  %1251 = fadd fast float %1248, %1244
  %1252 = fadd fast float %1249, %1244
  %1253 = fadd fast float %1250, %1244
  %1254 = call float @dx.op.unary.f32(i32 7, float %1251)  ; Saturate(value)
  %1255 = call float @dx.op.unary.f32(i32 7, float %1252)  ; Saturate(value)
  %1256 = call float @dx.op.unary.f32(i32 7, float %1253)  ; Saturate(value)
  %1257 = fadd fast float %1254, 0xBFC70A3D80000000
  %1258 = fadd fast float %1255, 0xBFC70A3D80000000
  %1259 = fadd fast float %1256, 0xBFC70A3D80000000
  %1260 = fmul fast float %1257, %7
  %1261 = fmul fast float %1258, %7
  %1262 = fmul fast float %1259, %7
  %1263 = fadd fast float %1260, 0x3FC70A3D80000000
  %1264 = fadd fast float %1261, 0x3FC70A3D80000000
  %1265 = fadd fast float %1262, 0x3FC70A3D80000000
  %1266 = call float @dx.op.unary.f32(i32 7, float %1263)  ; Saturate(value)
  %1267 = call float @dx.op.unary.f32(i32 7, float %1264)  ; Saturate(value)
  %1268 = call float @dx.op.unary.f32(i32 7, float %1265)  ; Saturate(value)
  br label %1269

; <label>:1269                                    ; preds = %1237, %1072
  %1270 = phi float [ %1103, %1072 ], [ %1266, %1237 ]
  %1271 = phi float [ %1104, %1072 ], [ %1267, %1237 ]
  %1272 = phi float [ %1105, %1072 ], [ %1268, %1237 ]
  %1273 = fsub fast float %1270, %332
  %1274 = fsub fast float %1271, %333
  %1275 = fsub fast float %1272, %334
  %1276 = fmul fast float %1273, %1059
  %1277 = fmul fast float %1274, %1059
  %1278 = fmul fast float %1275, %1059
  %1279 = fadd fast float %1276, %332
  %1280 = fadd fast float %1277, %333
  %1281 = fadd fast float %1278, %334
  br label %1282

; <label>:1282                                    ; preds = %1269, %1046
  %1283 = phi float [ %1279, %1269 ], [ %332, %1046 ]
  %1284 = phi float [ %1280, %1269 ], [ %333, %1046 ]
  %1285 = phi float [ %1281, %1269 ], [ %334, %1046 ]
  %1286 = call float @dx.op.binary.f32(i32 36, float %1047, float %1283)  ; FMin(a,b)
  %1287 = call float @dx.op.binary.f32(i32 36, float %1048, float %1284)  ; FMin(a,b)
  %1288 = call float @dx.op.binary.f32(i32 36, float %1049, float %1285)  ; FMin(a,b)
  %1289 = call float @dx.op.binary.f32(i32 36, float %573, float %809)  ; FMin(a,b)
  %1290 = call float @dx.op.binary.f32(i32 36, float %574, float %810)  ; FMin(a,b)
  %1291 = call float @dx.op.binary.f32(i32 36, float %575, float %811)  ; FMin(a,b)
  %1292 = call float @dx.op.binary.f32(i32 36, float %1289, float %1286)  ; FMin(a,b)
  %1293 = call float @dx.op.binary.f32(i32 36, float %1290, float %1287)  ; FMin(a,b)
  %1294 = call float @dx.op.binary.f32(i32 36, float %1291, float %1288)  ; FMin(a,b)
  %1295 = call float @dx.op.binary.f32(i32 36, float %332, float %1292)  ; FMin(a,b)
  %1296 = call float @dx.op.binary.f32(i32 36, float %333, float %1293)  ; FMin(a,b)
  %1297 = call float @dx.op.binary.f32(i32 36, float %334, float %1294)  ; FMin(a,b)
  %1298 = call float @dx.op.binary.f32(i32 35, float %1047, float %1283)  ; FMax(a,b)
  %1299 = call float @dx.op.binary.f32(i32 35, float %1048, float %1284)  ; FMax(a,b)
  %1300 = call float @dx.op.binary.f32(i32 35, float %1049, float %1285)  ; FMax(a,b)
  %1301 = call float @dx.op.binary.f32(i32 35, float %573, float %809)  ; FMax(a,b)
  %1302 = call float @dx.op.binary.f32(i32 35, float %574, float %810)  ; FMax(a,b)
  %1303 = call float @dx.op.binary.f32(i32 35, float %575, float %811)  ; FMax(a,b)
  %1304 = call float @dx.op.binary.f32(i32 35, float %1301, float %1298)  ; FMax(a,b)
  %1305 = call float @dx.op.binary.f32(i32 35, float %1302, float %1299)  ; FMax(a,b)
  %1306 = call float @dx.op.binary.f32(i32 35, float %1303, float %1300)  ; FMax(a,b)
  %1307 = call float @dx.op.binary.f32(i32 35, float %332, float %1304)  ; FMax(a,b)
  %1308 = call float @dx.op.binary.f32(i32 35, float %333, float %1305)  ; FMax(a,b)
  %1309 = call float @dx.op.binary.f32(i32 35, float %334, float %1306)  ; FMax(a,b)
  %1310 = fsub fast float %1307, %1295
  %1311 = fsub fast float %1308, %1296
  %1312 = fsub fast float %1309, %1297
  %1313 = call float @dx.op.unary.f32(i32 6, float %1310)  ; FAbs(value)
  %1314 = call float @dx.op.unary.f32(i32 6, float %1311)  ; FAbs(value)
  %1315 = call float @dx.op.unary.f32(i32 6, float %1312)  ; FAbs(value)
  %1316 = call float @dx.op.binary.f32(i32 35, float %1314, float %1315)  ; FMax(a,b)
  %1317 = call float @dx.op.binary.f32(i32 35, float %1313, float %1316)  ; FMax(a,b)
  %1318 = call float @dx.op.binary.f32(i32 35, float %1308, float %1309)  ; FMax(a,b)
  %1319 = call float @dx.op.binary.f32(i32 35, float %1307, float %1318)  ; FMax(a,b)
  %1320 = fmul fast float %1319, 1.250000e-01
  %1321 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1320)  ; FMax(a,b)
  %1322 = fcmp fast ogt float %1317, %1321
  br i1 %1322, label %1323, label %1384

; <label>:1323                                    ; preds = %1282
  %1324 = fsub fast float %573, %809
  %1325 = fsub fast float %574, %810
  %1326 = fsub fast float %575, %811
  %1327 = call float @dx.op.unary.f32(i32 6, float %1324)  ; FAbs(value)
  %1328 = call float @dx.op.unary.f32(i32 6, float %1325)  ; FAbs(value)
  %1329 = call float @dx.op.unary.f32(i32 6, float %1326)  ; FAbs(value)
  %1330 = call float @dx.op.binary.f32(i32 35, float %1328, float %1329)  ; FMax(a,b)
  %1331 = call float @dx.op.binary.f32(i32 35, float %1327, float %1330)  ; FMax(a,b)
  %1332 = fsub fast float %1047, %1283
  %1333 = fsub fast float %1048, %1284
  %1334 = fsub fast float %1049, %1285
  %1335 = call float @dx.op.unary.f32(i32 6, float %1332)  ; FAbs(value)
  %1336 = call float @dx.op.unary.f32(i32 6, float %1333)  ; FAbs(value)
  %1337 = call float @dx.op.unary.f32(i32 6, float %1334)  ; FAbs(value)
  %1338 = call float @dx.op.binary.f32(i32 35, float %1336, float %1337)  ; FMax(a,b)
  %1339 = call float @dx.op.binary.f32(i32 35, float %1335, float %1338)  ; FMax(a,b)
  %1340 = fcmp fast olt float %1331, %1339
  %1341 = select i1 %1340, float %573, float %1047
  %1342 = select i1 %1340, float %574, float %1048
  %1343 = select i1 %1340, float %575, float %1049
  %1344 = select i1 %1340, float %809, float %1283
  %1345 = select i1 %1340, float %810, float %1284
  %1346 = select i1 %1340, float %811, float %1285
  %1347 = fsub fast float %332, %1344
  %1348 = fsub fast float %333, %1345
  %1349 = fsub fast float %334, %1346
  %1350 = fsub fast float %332, %1341
  %1351 = fsub fast float %333, %1342
  %1352 = fsub fast float %334, %1343
  %1353 = call float @dx.op.dot3.f32(i32 55, float %1350, float %1351, float %1352, float %1347, float %1348, float %1349)  ; Dot3(ax,ay,az,bx,by,bz)
  %1354 = fcmp fast ogt float %1353, 0.000000e+00
  br i1 %1354, label %1355, label %1366

; <label>:1355                                    ; preds = %1323
  %1356 = fsub fast float %1341, %1344
  %1357 = fsub fast float %1342, %1345
  %1358 = fsub fast float %1343, %1346
  %1359 = call float @dx.op.unary.f32(i32 6, float %1356)  ; FAbs(value)
  %1360 = call float @dx.op.unary.f32(i32 6, float %1357)  ; FAbs(value)
  %1361 = call float @dx.op.unary.f32(i32 6, float %1358)  ; FAbs(value)
  %1362 = call float @dx.op.binary.f32(i32 35, float %1360, float %1361)  ; FMax(a,b)
  %1363 = call float @dx.op.binary.f32(i32 35, float %1359, float %1362)  ; FMax(a,b)
  %1364 = fmul fast float %1317, 2.500000e-01
  %1365 = fcmp fast olt float %1363, %1364
  br label %1366

; <label>:1366                                    ; preds = %1355, %1323
  %1367 = phi i1 [ false, %1323 ], [ %1365, %1355 ]
  %1368 = select i1 %1367, float 0x3FC3333340000000, float 0x3FD3333340000000
  %1369 = fadd fast float %1341, %1344
  %1370 = fadd fast float %1342, %1345
  %1371 = fadd fast float %1343, %1346
  %1372 = fmul fast float %1369, 5.000000e-01
  %1373 = fmul fast float %1370, 5.000000e-01
  %1374 = fmul fast float %1371, 5.000000e-01
  %1375 = fsub fast float %1372, %332
  %1376 = fsub fast float %1373, %333
  %1377 = fsub fast float %1374, %334
  %1378 = fmul fast float %1368, %1375
  %1379 = fmul fast float %1368, %1376
  %1380 = fmul fast float %1368, %1377
  %1381 = fadd fast float %1378, %332
  %1382 = fadd fast float %1379, %333
  %1383 = fadd fast float %1380, %334
  br label %1384

; <label>:1384                                    ; preds = %1366, %1282
  %1385 = phi float [ %1381, %1366 ], [ %332, %1282 ]
  %1386 = phi float [ %1382, %1366 ], [ %333, %1282 ]
  %1387 = phi float [ %1383, %1366 ], [ %334, %1282 ]
  %1388 = fcmp fast ogt float %1385, 0x3F69A5C380000000
  %1389 = fcmp fast ogt float %1386, 0x3F69A5C380000000
  %1390 = fcmp fast ogt float %1387, 0x3F69A5C380000000
  %1391 = select i1 %1388, float 0.000000e+00, float 1.000000e+00
  %1392 = select i1 %1389, float 0.000000e+00, float 1.000000e+00
  %1393 = select i1 %1390, float 0.000000e+00, float 1.000000e+00
  %1394 = fmul fast float %1385, 0x4029D70A40000000
  %1395 = fmul fast float %1386, 0x4029D70A40000000
  %1396 = fmul fast float %1387, 0x4029D70A40000000
  %1397 = call float @dx.op.binary.f32(i32 35, float %1385, float 0.000000e+00)  ; FMax(a,b)
  %1398 = call float @dx.op.binary.f32(i32 35, float %1386, float 0.000000e+00)  ; FMax(a,b)
  %1399 = call float @dx.op.binary.f32(i32 35, float %1387, float 0.000000e+00)  ; FMax(a,b)
  %1400 = call float @dx.op.unary.f32(i32 23, float %1397)  ; Log(value)
  %1401 = call float @dx.op.unary.f32(i32 23, float %1398)  ; Log(value)
  %1402 = call float @dx.op.unary.f32(i32 23, float %1399)  ; Log(value)
  %1403 = fmul fast float %1400, 0x3FDAAAAAA0000000
  %1404 = fmul fast float %1401, 0x3FDAAAAAA0000000
  %1405 = fmul fast float %1402, 0x3FDAAAAAA0000000
  %1406 = call float @dx.op.unary.f32(i32 21, float %1403)  ; Exp(value)
  %1407 = call float @dx.op.unary.f32(i32 21, float %1404)  ; Exp(value)
  %1408 = call float @dx.op.unary.f32(i32 21, float %1405)  ; Exp(value)
  %1409 = fmul fast float %1406, 0x3FF0E147A0000000
  %1410 = fmul fast float %1407, 0x3FF0E147A0000000
  %1411 = fmul fast float %1408, 0x3FF0E147A0000000
  %1412 = fadd fast float %1409, 0xBFAC28F5C0000000
  %1413 = fadd fast float %1410, 0xBFAC28F5C0000000
  %1414 = fadd fast float %1411, 0xBFAC28F5C0000000
  %1415 = fsub fast float %1394, %1412
  %1416 = fsub fast float %1395, %1413
  %1417 = fsub fast float %1396, %1414
  %1418 = fmul fast float %1415, %1391
  %1419 = fmul fast float %1416, %1392
  %1420 = fmul fast float %1417, %1393
  %1421 = fadd fast float %1418, %1412
  %1422 = fadd fast float %1419, %1413
  %1423 = fadd fast float %1420, %1414
  br label %1424

; <label>:1424                                    ; preds = %1384, %172
  %1425 = phi float [ %167, %172 ], [ %1421, %1384 ]
  %1426 = phi float [ %168, %172 ], [ %1422, %1384 ]
  %1427 = phi float [ %169, %172 ], [ %1423, %1384 ]
  %1428 = phi float [ %173, %172 ], [ %170, %1384 ]
  %1429 = fcmp fast ogt float %1425, 0x3FA4B5DCC0000000
  %1430 = fcmp fast ogt float %1426, 0x3FA4B5DCC0000000
  %1431 = fcmp fast ogt float %1427, 0x3FA4B5DCC0000000
  %1432 = select i1 %1429, float 0.000000e+00, float 1.000000e+00
  %1433 = select i1 %1430, float 0.000000e+00, float 1.000000e+00
  %1434 = select i1 %1431, float 0.000000e+00, float 1.000000e+00
  %1435 = fmul fast float %1425, 0x3FB3D07220000000
  %1436 = fmul fast float %1426, 0x3FB3D07220000000
  %1437 = fmul fast float %1427, 0x3FB3D07220000000
  %1438 = fadd fast float %1425, 0x3FAC28F5C0000000
  %1439 = fadd fast float %1426, 0x3FAC28F5C0000000
  %1440 = fadd fast float %1427, 0x3FAC28F5C0000000
  %1441 = fmul fast float %1438, 0x3FEE54EDE0000000
  %1442 = fmul fast float %1439, 0x3FEE54EDE0000000
  %1443 = fmul fast float %1440, 0x3FEE54EDE0000000
  %1444 = call float @dx.op.unary.f32(i32 23, float %1441)  ; Log(value)
  %1445 = call float @dx.op.unary.f32(i32 23, float %1442)  ; Log(value)
  %1446 = call float @dx.op.unary.f32(i32 23, float %1443)  ; Log(value)
  %1447 = fmul fast float %1444, 0x4003333340000000
  %1448 = fmul fast float %1445, 0x4003333340000000
  %1449 = fmul fast float %1446, 0x4003333340000000
  %1450 = call float @dx.op.unary.f32(i32 21, float %1447)  ; Exp(value)
  %1451 = call float @dx.op.unary.f32(i32 21, float %1448)  ; Exp(value)
  %1452 = call float @dx.op.unary.f32(i32 21, float %1449)  ; Exp(value)
  %1453 = fsub fast float %1435, %1450
  %1454 = fsub fast float %1436, %1451
  %1455 = fsub fast float %1437, %1452
  %1456 = fmul fast float %1453, %1432
  %1457 = fmul fast float %1454, %1433
  %1458 = fmul fast float %1455, %1434
  %1459 = fadd fast float %1456, %1450
  %1460 = fadd fast float %1457, %1451
  %1461 = fadd fast float %1458, %1452
  %1462 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %67, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1463 = extractvalue %dx.types.ResRet.f32 %1462, 0
  %1464 = extractvalue %dx.types.ResRet.f32 %1462, 1
  %1465 = extractvalue %dx.types.ResRet.f32 %1462, 2
  %1466 = extractvalue %dx.types.ResRet.f32 %1462, 3
  %1467 = fcmp fast olt float %1466, 0.000000e+00
  br i1 %1467, label %1468, label %1470

; <label>:1468                                    ; preds = %1424
  %1469 = fsub fast float -1.000000e+00, %1466
  br label %2720

; <label>:1470                                    ; preds = %1424
  %1471 = fcmp fast ogt float %38, 5.000000e-01
  %1472 = fcmp fast olt float %84, 1.000000e+00
  %1473 = and i1 %1471, %1472
  br i1 %1473, label %1474, label %1560

; <label>:1474                                    ; preds = %1470
  %1475 = sitofp i32 %67 to float
  %1476 = sitofp i32 %64 to float
  %1477 = fadd fast float %1475, 5.000000e-01
  %1478 = fadd fast float %1476, 5.000000e-01
  %1479 = fdiv fast float %1477, %45
  %1480 = fdiv fast float %1478, %46
  %1481 = fmul fast float %1479, 2.000000e+00
  %1482 = fmul fast float %1480, 2.000000e+00
  %1483 = fadd fast float %1481, -1.000000e+00
  %1484 = fsub fast float 1.000000e+00, %1482
  %1485 = fmul fast float %1483, %35
  %1486 = call float @dx.op.tertiary.f32(i32 46, float %1484, float %31, float %1485)  ; FMad(a,b,c)
  %1487 = call float @dx.op.tertiary.f32(i32 46, float %84, float %27, float %1486)  ; FMad(a,b,c)
  %1488 = fadd fast float %1487, %23
  %1489 = call float @dx.op.unary.f32(i32 6, float %1488)  ; FAbs(value)
  %1490 = fcmp fast ogt float %1489, 0x3EB0C6F7A0000000
  br i1 %1490, label %1491, label %1560

; <label>:1491                                    ; preds = %1474
  %1492 = fmul fast float %1483, %34
  %1493 = call float @dx.op.tertiary.f32(i32 46, float %1484, float %30, float %1492)  ; FMad(a,b,c)
  %1494 = call float @dx.op.tertiary.f32(i32 46, float %84, float %26, float %1493)  ; FMad(a,b,c)
  %1495 = fadd fast float %1494, %22
  %1496 = fmul fast float %1483, %33
  %1497 = call float @dx.op.tertiary.f32(i32 46, float %1484, float %29, float %1496)  ; FMad(a,b,c)
  %1498 = call float @dx.op.tertiary.f32(i32 46, float %84, float %25, float %1497)  ; FMad(a,b,c)
  %1499 = fadd fast float %1498, %21
  %1500 = fmul fast float %1483, %32
  %1501 = call float @dx.op.tertiary.f32(i32 46, float %1484, float %28, float %1500)  ; FMad(a,b,c)
  %1502 = call float @dx.op.tertiary.f32(i32 46, float %84, float %24, float %1501)  ; FMad(a,b,c)
  %1503 = fadd fast float %1502, %20
  %1504 = fdiv fast float %1503, %1488
  %1505 = fdiv fast float %1499, %1488
  %1506 = fdiv fast float %1495, %1488
  %1507 = fsub fast float %1504, %17
  %1508 = fsub fast float %1505, %18
  %1509 = fsub fast float %1506, %19
  %1510 = fmul fast float %1507, %1507
  %1511 = fmul fast float %1508, %1508
  %1512 = fadd fast float %1511, %1510
  %1513 = fmul fast float %1509, %1509
  %1514 = fadd fast float %1512, %1513
  %1515 = call float @dx.op.unary.f32(i32 24, float %1514)  ; Sqrt(value)
  %1516 = fsub fast float %1515, %9
  %1517 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1516)  ; FMax(a,b)
  %1518 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1518, label %1519, label %1542

; <label>:1519                                    ; preds = %1491
  %1520 = call float @dx.op.unary.f32(i32 6, float %1508)  ; FAbs(value)
  %1521 = fmul fast float %1520, %11
  %1522 = fcmp fast olt float %1521, 0x3F50624DE0000000
  br i1 %1522, label %1523, label %1526

; <label>:1523                                    ; preds = %1519
  %1524 = fmul fast float %1521, 5.000000e-01
  %1525 = fsub fast float 1.000000e+00, %1524
  br label %1531

; <label>:1526                                    ; preds = %1519
  %1527 = fmul fast float %1521, 0xBFF7154760000000
  %1528 = call float @dx.op.unary.f32(i32 21, float %1527)  ; Exp(value)
  %1529 = fsub fast float 1.000000e+00, %1528
  %1530 = fdiv fast float %1529, %1521
  br label %1531

; <label>:1531                                    ; preds = %1526, %1523
  %1532 = phi float [ %1525, %1523 ], [ %1530, %1526 ]
  %1533 = call float @dx.op.binary.f32(i32 36, float %1505, float %18)  ; FMin(a,b)
  %1534 = fsub fast float %1533, %10
  %1535 = fmul fast float %11, %1534
  %1536 = fsub fast float -0.000000e+00, %1535
  %1537 = call float @dx.op.binary.f32(i32 35, float %1536, float -4.000000e+01)  ; FMax(a,b)
  %1538 = call float @dx.op.binary.f32(i32 36, float %1537, float 5.000000e+00)  ; FMin(a,b)
  %1539 = fmul fast float %1538, 0x3FF7154760000000
  %1540 = call float @dx.op.unary.f32(i32 21, float %1539)  ; Exp(value)
  %1541 = fmul fast float %1540, %1532
  br label %1542

; <label>:1542                                    ; preds = %1531, %1491
  %1543 = phi float [ %1541, %1531 ], [ 1.000000e+00, %1491 ]
  %1544 = fmul fast float %1517, %16
  %1545 = fmul fast float %1544, %1543
  %1546 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1545)  ; FMin(a,b)
  %1547 = fmul fast float %1546, 0xBFF7154760000000
  %1548 = call float @dx.op.unary.f32(i32 21, float %1547)  ; Exp(value)
  %1549 = fsub fast float 1.000000e+00, %1548
  %1550 = call float @dx.op.binary.f32(i32 36, float %12, float %1549)  ; FMin(a,b)
  %1551 = fsub fast float %13, %1463
  %1552 = fsub fast float %14, %1464
  %1553 = fsub fast float %15, %1465
  %1554 = fmul fast float %1550, %1551
  %1555 = fmul fast float %1550, %1552
  %1556 = fmul fast float %1550, %1553
  %1557 = fadd fast float %1554, %1463
  %1558 = fadd fast float %1555, %1464
  %1559 = fadd fast float %1556, %1465
  br label %1560

; <label>:1560                                    ; preds = %1542, %1474, %1470
  %1561 = phi float [ %1557, %1542 ], [ %1463, %1474 ], [ %1463, %1470 ]
  %1562 = phi float [ %1558, %1542 ], [ %1464, %1474 ], [ %1464, %1470 ]
  %1563 = phi float [ %1559, %1542 ], [ %1465, %1474 ], [ %1465, %1470 ]
  %1564 = fadd fast float %5, 1.000000e+00
  %1565 = fadd fast float %6, 1.000000e+00
  %1566 = fsub fast float 1.000000e+00, %5
  %1567 = fmul fast float %36, %1564
  %1568 = fmul fast float %36, %1565
  %1569 = fmul fast float %36, %1566
  %1570 = fmul fast float %1567, %1561
  %1571 = fmul fast float %1568, %1562
  %1572 = fmul fast float %1569, %1563
  %1573 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1573, label %1599, label %1574

; <label>:1574                                    ; preds = %1560
  %1575 = fmul fast float %1570, 0x4004147AE0000000
  %1576 = fmul fast float %1571, 0x4004147AE0000000
  %1577 = fmul fast float %1572, 0x4004147AE0000000
  %1578 = fadd fast float %1575, 0x3F9EB851E0000000
  %1579 = fadd fast float %1576, 0x3F9EB851E0000000
  %1580 = fadd fast float %1577, 0x3F9EB851E0000000
  %1581 = fmul fast float %1578, %1570
  %1582 = fmul fast float %1579, %1571
  %1583 = fmul fast float %1580, %1572
  %1584 = fmul fast float %1570, 0x400370A3E0000000
  %1585 = fmul fast float %1571, 0x400370A3E0000000
  %1586 = fmul fast float %1572, 0x400370A3E0000000
  %1587 = fadd fast float %1584, 0x3FE2E147A0000000
  %1588 = fadd fast float %1585, 0x3FE2E147A0000000
  %1589 = fadd fast float %1586, 0x3FE2E147A0000000
  %1590 = fmul fast float %1587, %1570
  %1591 = fmul fast float %1588, %1571
  %1592 = fmul fast float %1589, %1572
  %1593 = fadd fast float %1590, 0x3FC1EB8520000000
  %1594 = fadd fast float %1591, 0x3FC1EB8520000000
  %1595 = fadd fast float %1592, 0x3FC1EB8520000000
  %1596 = fdiv fast float %1581, %1593
  %1597 = fdiv fast float %1582, %1594
  %1598 = fdiv fast float %1583, %1595
  br label %1599

; <label>:1599                                    ; preds = %1574, %1560
  %1600 = phi float [ %1596, %1574 ], [ %1570, %1560 ]
  %1601 = phi float [ %1597, %1574 ], [ %1571, %1560 ]
  %1602 = phi float [ %1598, %1574 ], [ %1572, %1560 ]
  %1603 = call float @dx.op.unary.f32(i32 7, float %1600)  ; Saturate(value)
  %1604 = call float @dx.op.unary.f32(i32 7, float %1601)  ; Saturate(value)
  %1605 = call float @dx.op.unary.f32(i32 7, float %1602)  ; Saturate(value)
  %1606 = call float @dx.op.dot3.f32(i32 55, float %1603, float %1604, float %1605, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1607 = fsub fast float %1603, %1606
  %1608 = fsub fast float %1604, %1606
  %1609 = fsub fast float %1605, %1606
  %1610 = fmul fast float %1607, %8
  %1611 = fmul fast float %1608, %8
  %1612 = fmul fast float %1609, %8
  %1613 = fadd fast float %1610, %1606
  %1614 = fadd fast float %1611, %1606
  %1615 = fadd fast float %1612, %1606
  %1616 = call float @dx.op.unary.f32(i32 7, float %1613)  ; Saturate(value)
  %1617 = call float @dx.op.unary.f32(i32 7, float %1614)  ; Saturate(value)
  %1618 = call float @dx.op.unary.f32(i32 7, float %1615)  ; Saturate(value)
  %1619 = fadd fast float %1616, 0xBFC70A3D80000000
  %1620 = fadd fast float %1617, 0xBFC70A3D80000000
  %1621 = fadd fast float %1618, 0xBFC70A3D80000000
  %1622 = fmul fast float %1619, %7
  %1623 = fmul fast float %1620, %7
  %1624 = fmul fast float %1621, %7
  %1625 = fadd fast float %1622, 0x3FC70A3D80000000
  %1626 = fadd fast float %1623, 0x3FC70A3D80000000
  %1627 = fadd fast float %1624, 0x3FC70A3D80000000
  %1628 = call float @dx.op.unary.f32(i32 7, float %1625)  ; Saturate(value)
  %1629 = call float @dx.op.unary.f32(i32 7, float %1626)  ; Saturate(value)
  %1630 = call float @dx.op.unary.f32(i32 7, float %1627)  ; Saturate(value)
  %1631 = add i32 %64, -1
  %1632 = call i32 @dx.op.binary.i32(i32 37, i32 %67, i32 0)  ; IMax(a,b)
  %1633 = call i32 @dx.op.binary.i32(i32 37, i32 %1631, i32 0)  ; IMax(a,b)
  %1634 = call i32 @dx.op.binary.i32(i32 38, i32 %1632, i32 %59)  ; IMin(a,b)
  %1635 = call i32 @dx.op.binary.i32(i32 38, i32 %1633, i32 %60)  ; IMin(a,b)
  %1636 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1634, i32 %1635, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1637 = extractvalue %dx.types.ResRet.f32 %1636, 0
  %1638 = fsub fast float 1.000000e+00, %84
  %1639 = fmul fast float %1638, 0x3FA99999A0000000
  %1640 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %1639)  ; FMax(a,b)
  %1641 = fsub fast float %1637, %84
  %1642 = call float @dx.op.unary.f32(i32 6, float %1641)  ; FAbs(value)
  %1643 = fdiv fast float %1642, %1640
  %1644 = fsub fast float 1.000000e+00, %1643
  %1645 = call float @dx.op.unary.f32(i32 7, float %1644)  ; Saturate(value)
  %1646 = fcmp fast ugt float %1645, 0.000000e+00
  br i1 %1646, label %1647, label %1868

; <label>:1647                                    ; preds = %1599
  %1648 = call i32 @dx.op.binary.i32(i32 37, i32 %1634, i32 0)  ; IMax(a,b)
  %1649 = call i32 @dx.op.binary.i32(i32 37, i32 %1635, i32 0)  ; IMax(a,b)
  %1650 = call i32 @dx.op.binary.i32(i32 38, i32 %1648, i32 %59)  ; IMin(a,b)
  %1651 = call i32 @dx.op.binary.i32(i32 38, i32 %1649, i32 %60)  ; IMin(a,b)
  %1652 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1650, i32 %1651, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1653 = extractvalue %dx.types.ResRet.f32 %1652, 0
  %1654 = extractvalue %dx.types.ResRet.f32 %1652, 1
  %1655 = extractvalue %dx.types.ResRet.f32 %1652, 2
  %1656 = extractvalue %dx.types.ResRet.f32 %1652, 3
  %1657 = fcmp fast olt float %1656, 0.000000e+00
  br i1 %1657, label %1658, label %1692

; <label>:1658                                    ; preds = %1647
  %1659 = fcmp fast ogt float %1653, 0x3FA4B5DCC0000000
  %1660 = fcmp fast ogt float %1654, 0x3FA4B5DCC0000000
  %1661 = fcmp fast ogt float %1655, 0x3FA4B5DCC0000000
  %1662 = select i1 %1659, float 0.000000e+00, float 1.000000e+00
  %1663 = select i1 %1660, float 0.000000e+00, float 1.000000e+00
  %1664 = select i1 %1661, float 0.000000e+00, float 1.000000e+00
  %1665 = fmul fast float %1653, 0x3FB3D07220000000
  %1666 = fmul fast float %1654, 0x3FB3D07220000000
  %1667 = fmul fast float %1655, 0x3FB3D07220000000
  %1668 = fadd fast float %1653, 0x3FAC28F5C0000000
  %1669 = fadd fast float %1654, 0x3FAC28F5C0000000
  %1670 = fadd fast float %1655, 0x3FAC28F5C0000000
  %1671 = fmul fast float %1668, 0x3FEE54EDE0000000
  %1672 = fmul fast float %1669, 0x3FEE54EDE0000000
  %1673 = fmul fast float %1670, 0x3FEE54EDE0000000
  %1674 = call float @dx.op.unary.f32(i32 23, float %1671)  ; Log(value)
  %1675 = call float @dx.op.unary.f32(i32 23, float %1672)  ; Log(value)
  %1676 = call float @dx.op.unary.f32(i32 23, float %1673)  ; Log(value)
  %1677 = fmul fast float %1674, 0x4003333340000000
  %1678 = fmul fast float %1675, 0x4003333340000000
  %1679 = fmul fast float %1676, 0x4003333340000000
  %1680 = call float @dx.op.unary.f32(i32 21, float %1677)  ; Exp(value)
  %1681 = call float @dx.op.unary.f32(i32 21, float %1678)  ; Exp(value)
  %1682 = call float @dx.op.unary.f32(i32 21, float %1679)  ; Exp(value)
  %1683 = fsub fast float %1665, %1680
  %1684 = fsub fast float %1666, %1681
  %1685 = fsub fast float %1667, %1682
  %1686 = fmul fast float %1683, %1662
  %1687 = fmul fast float %1684, %1663
  %1688 = fmul fast float %1685, %1664
  %1689 = fadd fast float %1686, %1680
  %1690 = fadd fast float %1687, %1681
  %1691 = fadd fast float %1688, %1682
  br label %1855

; <label>:1692                                    ; preds = %1647
  %1693 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1650, i32 %1651, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1694 = extractvalue %dx.types.ResRet.f32 %1693, 0
  %1695 = fcmp fast ogt float %38, 5.000000e-01
  %1696 = fcmp fast olt float %1694, 1.000000e+00
  %1697 = and i1 %1695, %1696
  br i1 %1697, label %1698, label %1784

; <label>:1698                                    ; preds = %1692
  %1699 = sitofp i32 %1650 to float
  %1700 = sitofp i32 %1651 to float
  %1701 = fadd fast float %1699, 5.000000e-01
  %1702 = fadd fast float %1700, 5.000000e-01
  %1703 = fdiv fast float %1701, %45
  %1704 = fdiv fast float %1702, %46
  %1705 = fmul fast float %1703, 2.000000e+00
  %1706 = fmul fast float %1704, 2.000000e+00
  %1707 = fadd fast float %1705, -1.000000e+00
  %1708 = fsub fast float 1.000000e+00, %1706
  %1709 = fmul fast float %1707, %35
  %1710 = call float @dx.op.tertiary.f32(i32 46, float %1708, float %31, float %1709)  ; FMad(a,b,c)
  %1711 = call float @dx.op.tertiary.f32(i32 46, float %1694, float %27, float %1710)  ; FMad(a,b,c)
  %1712 = fadd fast float %1711, %23
  %1713 = call float @dx.op.unary.f32(i32 6, float %1712)  ; FAbs(value)
  %1714 = fcmp fast ogt float %1713, 0x3EB0C6F7A0000000
  br i1 %1714, label %1715, label %1784

; <label>:1715                                    ; preds = %1698
  %1716 = fmul fast float %1707, %34
  %1717 = call float @dx.op.tertiary.f32(i32 46, float %1708, float %30, float %1716)  ; FMad(a,b,c)
  %1718 = call float @dx.op.tertiary.f32(i32 46, float %1694, float %26, float %1717)  ; FMad(a,b,c)
  %1719 = fadd fast float %1718, %22
  %1720 = fmul fast float %1707, %33
  %1721 = call float @dx.op.tertiary.f32(i32 46, float %1708, float %29, float %1720)  ; FMad(a,b,c)
  %1722 = call float @dx.op.tertiary.f32(i32 46, float %1694, float %25, float %1721)  ; FMad(a,b,c)
  %1723 = fadd fast float %1722, %21
  %1724 = fmul fast float %1707, %32
  %1725 = call float @dx.op.tertiary.f32(i32 46, float %1708, float %28, float %1724)  ; FMad(a,b,c)
  %1726 = call float @dx.op.tertiary.f32(i32 46, float %1694, float %24, float %1725)  ; FMad(a,b,c)
  %1727 = fadd fast float %1726, %20
  %1728 = fdiv fast float %1727, %1712
  %1729 = fdiv fast float %1723, %1712
  %1730 = fdiv fast float %1719, %1712
  %1731 = fsub fast float %1728, %17
  %1732 = fsub fast float %1729, %18
  %1733 = fsub fast float %1730, %19
  %1734 = fmul fast float %1731, %1731
  %1735 = fmul fast float %1732, %1732
  %1736 = fadd fast float %1735, %1734
  %1737 = fmul fast float %1733, %1733
  %1738 = fadd fast float %1736, %1737
  %1739 = call float @dx.op.unary.f32(i32 24, float %1738)  ; Sqrt(value)
  %1740 = fsub fast float %1739, %9
  %1741 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1740)  ; FMax(a,b)
  %1742 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1742, label %1743, label %1766

; <label>:1743                                    ; preds = %1715
  %1744 = call float @dx.op.unary.f32(i32 6, float %1732)  ; FAbs(value)
  %1745 = fmul fast float %1744, %11
  %1746 = fcmp fast olt float %1745, 0x3F50624DE0000000
  br i1 %1746, label %1747, label %1750

; <label>:1747                                    ; preds = %1743
  %1748 = fmul fast float %1745, 5.000000e-01
  %1749 = fsub fast float 1.000000e+00, %1748
  br label %1755

; <label>:1750                                    ; preds = %1743
  %1751 = fmul fast float %1745, 0xBFF7154760000000
  %1752 = call float @dx.op.unary.f32(i32 21, float %1751)  ; Exp(value)
  %1753 = fsub fast float 1.000000e+00, %1752
  %1754 = fdiv fast float %1753, %1745
  br label %1755

; <label>:1755                                    ; preds = %1750, %1747
  %1756 = phi float [ %1749, %1747 ], [ %1754, %1750 ]
  %1757 = call float @dx.op.binary.f32(i32 36, float %1729, float %18)  ; FMin(a,b)
  %1758 = fsub fast float %1757, %10
  %1759 = fmul fast float %11, %1758
  %1760 = fsub fast float -0.000000e+00, %1759
  %1761 = call float @dx.op.binary.f32(i32 35, float %1760, float -4.000000e+01)  ; FMax(a,b)
  %1762 = call float @dx.op.binary.f32(i32 36, float %1761, float 5.000000e+00)  ; FMin(a,b)
  %1763 = fmul fast float %1762, 0x3FF7154760000000
  %1764 = call float @dx.op.unary.f32(i32 21, float %1763)  ; Exp(value)
  %1765 = fmul fast float %1764, %1756
  br label %1766

; <label>:1766                                    ; preds = %1755, %1715
  %1767 = phi float [ %1765, %1755 ], [ 1.000000e+00, %1715 ]
  %1768 = fmul fast float %1741, %16
  %1769 = fmul fast float %1768, %1767
  %1770 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1769)  ; FMin(a,b)
  %1771 = fmul fast float %1770, 0xBFF7154760000000
  %1772 = call float @dx.op.unary.f32(i32 21, float %1771)  ; Exp(value)
  %1773 = fsub fast float 1.000000e+00, %1772
  %1774 = call float @dx.op.binary.f32(i32 36, float %12, float %1773)  ; FMin(a,b)
  %1775 = fsub fast float %13, %1653
  %1776 = fsub fast float %14, %1654
  %1777 = fsub fast float %15, %1655
  %1778 = fmul fast float %1774, %1775
  %1779 = fmul fast float %1774, %1776
  %1780 = fmul fast float %1774, %1777
  %1781 = fadd fast float %1778, %1653
  %1782 = fadd fast float %1779, %1654
  %1783 = fadd fast float %1780, %1655
  br label %1784

; <label>:1784                                    ; preds = %1766, %1698, %1692
  %1785 = phi float [ %1781, %1766 ], [ %1653, %1698 ], [ %1653, %1692 ]
  %1786 = phi float [ %1782, %1766 ], [ %1654, %1698 ], [ %1654, %1692 ]
  %1787 = phi float [ %1783, %1766 ], [ %1655, %1698 ], [ %1655, %1692 ]
  %1788 = fadd fast float %5, 1.000000e+00
  %1789 = fadd fast float %6, 1.000000e+00
  %1790 = fsub fast float 1.000000e+00, %5
  %1791 = fmul fast float %36, %1788
  %1792 = fmul fast float %36, %1789
  %1793 = fmul fast float %36, %1790
  %1794 = fmul fast float %1791, %1785
  %1795 = fmul fast float %1792, %1786
  %1796 = fmul fast float %1793, %1787
  %1797 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1797, label %1823, label %1798

; <label>:1798                                    ; preds = %1784
  %1799 = fmul fast float %1794, 0x4004147AE0000000
  %1800 = fmul fast float %1795, 0x4004147AE0000000
  %1801 = fmul fast float %1796, 0x4004147AE0000000
  %1802 = fadd fast float %1799, 0x3F9EB851E0000000
  %1803 = fadd fast float %1800, 0x3F9EB851E0000000
  %1804 = fadd fast float %1801, 0x3F9EB851E0000000
  %1805 = fmul fast float %1802, %1794
  %1806 = fmul fast float %1803, %1795
  %1807 = fmul fast float %1804, %1796
  %1808 = fmul fast float %1794, 0x400370A3E0000000
  %1809 = fmul fast float %1795, 0x400370A3E0000000
  %1810 = fmul fast float %1796, 0x400370A3E0000000
  %1811 = fadd fast float %1808, 0x3FE2E147A0000000
  %1812 = fadd fast float %1809, 0x3FE2E147A0000000
  %1813 = fadd fast float %1810, 0x3FE2E147A0000000
  %1814 = fmul fast float %1811, %1794
  %1815 = fmul fast float %1812, %1795
  %1816 = fmul fast float %1813, %1796
  %1817 = fadd fast float %1814, 0x3FC1EB8520000000
  %1818 = fadd fast float %1815, 0x3FC1EB8520000000
  %1819 = fadd fast float %1816, 0x3FC1EB8520000000
  %1820 = fdiv fast float %1805, %1817
  %1821 = fdiv fast float %1806, %1818
  %1822 = fdiv fast float %1807, %1819
  br label %1823

; <label>:1823                                    ; preds = %1798, %1784
  %1824 = phi float [ %1820, %1798 ], [ %1794, %1784 ]
  %1825 = phi float [ %1821, %1798 ], [ %1795, %1784 ]
  %1826 = phi float [ %1822, %1798 ], [ %1796, %1784 ]
  %1827 = call float @dx.op.unary.f32(i32 7, float %1824)  ; Saturate(value)
  %1828 = call float @dx.op.unary.f32(i32 7, float %1825)  ; Saturate(value)
  %1829 = call float @dx.op.unary.f32(i32 7, float %1826)  ; Saturate(value)
  %1830 = call float @dx.op.dot3.f32(i32 55, float %1827, float %1828, float %1829, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1831 = fsub fast float %1827, %1830
  %1832 = fsub fast float %1828, %1830
  %1833 = fsub fast float %1829, %1830
  %1834 = fmul fast float %1831, %8
  %1835 = fmul fast float %1832, %8
  %1836 = fmul fast float %1833, %8
  %1837 = fadd fast float %1834, %1830
  %1838 = fadd fast float %1835, %1830
  %1839 = fadd fast float %1836, %1830
  %1840 = call float @dx.op.unary.f32(i32 7, float %1837)  ; Saturate(value)
  %1841 = call float @dx.op.unary.f32(i32 7, float %1838)  ; Saturate(value)
  %1842 = call float @dx.op.unary.f32(i32 7, float %1839)  ; Saturate(value)
  %1843 = fadd fast float %1840, 0xBFC70A3D80000000
  %1844 = fadd fast float %1841, 0xBFC70A3D80000000
  %1845 = fadd fast float %1842, 0xBFC70A3D80000000
  %1846 = fmul fast float %1843, %7
  %1847 = fmul fast float %1844, %7
  %1848 = fmul fast float %1845, %7
  %1849 = fadd fast float %1846, 0x3FC70A3D80000000
  %1850 = fadd fast float %1847, 0x3FC70A3D80000000
  %1851 = fadd fast float %1848, 0x3FC70A3D80000000
  %1852 = call float @dx.op.unary.f32(i32 7, float %1849)  ; Saturate(value)
  %1853 = call float @dx.op.unary.f32(i32 7, float %1850)  ; Saturate(value)
  %1854 = call float @dx.op.unary.f32(i32 7, float %1851)  ; Saturate(value)
  br label %1855

; <label>:1855                                    ; preds = %1823, %1658
  %1856 = phi float [ %1689, %1658 ], [ %1852, %1823 ]
  %1857 = phi float [ %1690, %1658 ], [ %1853, %1823 ]
  %1858 = phi float [ %1691, %1658 ], [ %1854, %1823 ]
  %1859 = fsub fast float %1856, %1628
  %1860 = fsub fast float %1857, %1629
  %1861 = fsub fast float %1858, %1630
  %1862 = fmul fast float %1859, %1645
  %1863 = fmul fast float %1860, %1645
  %1864 = fmul fast float %1861, %1645
  %1865 = fadd fast float %1862, %1628
  %1866 = fadd fast float %1863, %1629
  %1867 = fadd fast float %1864, %1630
  br label %1868

; <label>:1868                                    ; preds = %1855, %1599
  %1869 = phi float [ %1865, %1855 ], [ %1628, %1599 ]
  %1870 = phi float [ %1866, %1855 ], [ %1629, %1599 ]
  %1871 = phi float [ %1867, %1855 ], [ %1630, %1599 ]
  %1872 = add i32 %64, 1
  %1873 = call i32 @dx.op.binary.i32(i32 37, i32 %1872, i32 0)  ; IMax(a,b)
  %1874 = call i32 @dx.op.binary.i32(i32 38, i32 %1873, i32 %60)  ; IMin(a,b)
  %1875 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1634, i32 %1874, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1876 = extractvalue %dx.types.ResRet.f32 %1875, 0
  %1877 = fsub fast float %1876, %84
  %1878 = call float @dx.op.unary.f32(i32 6, float %1877)  ; FAbs(value)
  %1879 = fdiv fast float %1878, %1640
  %1880 = fsub fast float 1.000000e+00, %1879
  %1881 = call float @dx.op.unary.f32(i32 7, float %1880)  ; Saturate(value)
  %1882 = fcmp fast ugt float %1881, 0.000000e+00
  br i1 %1882, label %1883, label %2104

; <label>:1883                                    ; preds = %1868
  %1884 = call i32 @dx.op.binary.i32(i32 37, i32 %1634, i32 0)  ; IMax(a,b)
  %1885 = call i32 @dx.op.binary.i32(i32 37, i32 %1874, i32 0)  ; IMax(a,b)
  %1886 = call i32 @dx.op.binary.i32(i32 38, i32 %1884, i32 %59)  ; IMin(a,b)
  %1887 = call i32 @dx.op.binary.i32(i32 38, i32 %1885, i32 %60)  ; IMin(a,b)
  %1888 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1886, i32 %1887, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1889 = extractvalue %dx.types.ResRet.f32 %1888, 0
  %1890 = extractvalue %dx.types.ResRet.f32 %1888, 1
  %1891 = extractvalue %dx.types.ResRet.f32 %1888, 2
  %1892 = extractvalue %dx.types.ResRet.f32 %1888, 3
  %1893 = fcmp fast olt float %1892, 0.000000e+00
  br i1 %1893, label %1894, label %1928

; <label>:1894                                    ; preds = %1883
  %1895 = fcmp fast ogt float %1889, 0x3FA4B5DCC0000000
  %1896 = fcmp fast ogt float %1890, 0x3FA4B5DCC0000000
  %1897 = fcmp fast ogt float %1891, 0x3FA4B5DCC0000000
  %1898 = select i1 %1895, float 0.000000e+00, float 1.000000e+00
  %1899 = select i1 %1896, float 0.000000e+00, float 1.000000e+00
  %1900 = select i1 %1897, float 0.000000e+00, float 1.000000e+00
  %1901 = fmul fast float %1889, 0x3FB3D07220000000
  %1902 = fmul fast float %1890, 0x3FB3D07220000000
  %1903 = fmul fast float %1891, 0x3FB3D07220000000
  %1904 = fadd fast float %1889, 0x3FAC28F5C0000000
  %1905 = fadd fast float %1890, 0x3FAC28F5C0000000
  %1906 = fadd fast float %1891, 0x3FAC28F5C0000000
  %1907 = fmul fast float %1904, 0x3FEE54EDE0000000
  %1908 = fmul fast float %1905, 0x3FEE54EDE0000000
  %1909 = fmul fast float %1906, 0x3FEE54EDE0000000
  %1910 = call float @dx.op.unary.f32(i32 23, float %1907)  ; Log(value)
  %1911 = call float @dx.op.unary.f32(i32 23, float %1908)  ; Log(value)
  %1912 = call float @dx.op.unary.f32(i32 23, float %1909)  ; Log(value)
  %1913 = fmul fast float %1910, 0x4003333340000000
  %1914 = fmul fast float %1911, 0x4003333340000000
  %1915 = fmul fast float %1912, 0x4003333340000000
  %1916 = call float @dx.op.unary.f32(i32 21, float %1913)  ; Exp(value)
  %1917 = call float @dx.op.unary.f32(i32 21, float %1914)  ; Exp(value)
  %1918 = call float @dx.op.unary.f32(i32 21, float %1915)  ; Exp(value)
  %1919 = fsub fast float %1901, %1916
  %1920 = fsub fast float %1902, %1917
  %1921 = fsub fast float %1903, %1918
  %1922 = fmul fast float %1919, %1898
  %1923 = fmul fast float %1920, %1899
  %1924 = fmul fast float %1921, %1900
  %1925 = fadd fast float %1922, %1916
  %1926 = fadd fast float %1923, %1917
  %1927 = fadd fast float %1924, %1918
  br label %2091

; <label>:1928                                    ; preds = %1883
  %1929 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1886, i32 %1887, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1930 = extractvalue %dx.types.ResRet.f32 %1929, 0
  %1931 = fcmp fast ogt float %38, 5.000000e-01
  %1932 = fcmp fast olt float %1930, 1.000000e+00
  %1933 = and i1 %1931, %1932
  br i1 %1933, label %1934, label %2020

; <label>:1934                                    ; preds = %1928
  %1935 = sitofp i32 %1886 to float
  %1936 = sitofp i32 %1887 to float
  %1937 = fadd fast float %1935, 5.000000e-01
  %1938 = fadd fast float %1936, 5.000000e-01
  %1939 = fdiv fast float %1937, %45
  %1940 = fdiv fast float %1938, %46
  %1941 = fmul fast float %1939, 2.000000e+00
  %1942 = fmul fast float %1940, 2.000000e+00
  %1943 = fadd fast float %1941, -1.000000e+00
  %1944 = fsub fast float 1.000000e+00, %1942
  %1945 = fmul fast float %1943, %35
  %1946 = call float @dx.op.tertiary.f32(i32 46, float %1944, float %31, float %1945)  ; FMad(a,b,c)
  %1947 = call float @dx.op.tertiary.f32(i32 46, float %1930, float %27, float %1946)  ; FMad(a,b,c)
  %1948 = fadd fast float %1947, %23
  %1949 = call float @dx.op.unary.f32(i32 6, float %1948)  ; FAbs(value)
  %1950 = fcmp fast ogt float %1949, 0x3EB0C6F7A0000000
  br i1 %1950, label %1951, label %2020

; <label>:1951                                    ; preds = %1934
  %1952 = fmul fast float %1943, %34
  %1953 = call float @dx.op.tertiary.f32(i32 46, float %1944, float %30, float %1952)  ; FMad(a,b,c)
  %1954 = call float @dx.op.tertiary.f32(i32 46, float %1930, float %26, float %1953)  ; FMad(a,b,c)
  %1955 = fadd fast float %1954, %22
  %1956 = fmul fast float %1943, %33
  %1957 = call float @dx.op.tertiary.f32(i32 46, float %1944, float %29, float %1956)  ; FMad(a,b,c)
  %1958 = call float @dx.op.tertiary.f32(i32 46, float %1930, float %25, float %1957)  ; FMad(a,b,c)
  %1959 = fadd fast float %1958, %21
  %1960 = fmul fast float %1943, %32
  %1961 = call float @dx.op.tertiary.f32(i32 46, float %1944, float %28, float %1960)  ; FMad(a,b,c)
  %1962 = call float @dx.op.tertiary.f32(i32 46, float %1930, float %24, float %1961)  ; FMad(a,b,c)
  %1963 = fadd fast float %1962, %20
  %1964 = fdiv fast float %1963, %1948
  %1965 = fdiv fast float %1959, %1948
  %1966 = fdiv fast float %1955, %1948
  %1967 = fsub fast float %1964, %17
  %1968 = fsub fast float %1965, %18
  %1969 = fsub fast float %1966, %19
  %1970 = fmul fast float %1967, %1967
  %1971 = fmul fast float %1968, %1968
  %1972 = fadd fast float %1971, %1970
  %1973 = fmul fast float %1969, %1969
  %1974 = fadd fast float %1972, %1973
  %1975 = call float @dx.op.unary.f32(i32 24, float %1974)  ; Sqrt(value)
  %1976 = fsub fast float %1975, %9
  %1977 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1976)  ; FMax(a,b)
  %1978 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1978, label %1979, label %2002

; <label>:1979                                    ; preds = %1951
  %1980 = call float @dx.op.unary.f32(i32 6, float %1968)  ; FAbs(value)
  %1981 = fmul fast float %1980, %11
  %1982 = fcmp fast olt float %1981, 0x3F50624DE0000000
  br i1 %1982, label %1983, label %1986

; <label>:1983                                    ; preds = %1979
  %1984 = fmul fast float %1981, 5.000000e-01
  %1985 = fsub fast float 1.000000e+00, %1984
  br label %1991

; <label>:1986                                    ; preds = %1979
  %1987 = fmul fast float %1981, 0xBFF7154760000000
  %1988 = call float @dx.op.unary.f32(i32 21, float %1987)  ; Exp(value)
  %1989 = fsub fast float 1.000000e+00, %1988
  %1990 = fdiv fast float %1989, %1981
  br label %1991

; <label>:1991                                    ; preds = %1986, %1983
  %1992 = phi float [ %1985, %1983 ], [ %1990, %1986 ]
  %1993 = call float @dx.op.binary.f32(i32 36, float %1965, float %18)  ; FMin(a,b)
  %1994 = fsub fast float %1993, %10
  %1995 = fmul fast float %11, %1994
  %1996 = fsub fast float -0.000000e+00, %1995
  %1997 = call float @dx.op.binary.f32(i32 35, float %1996, float -4.000000e+01)  ; FMax(a,b)
  %1998 = call float @dx.op.binary.f32(i32 36, float %1997, float 5.000000e+00)  ; FMin(a,b)
  %1999 = fmul fast float %1998, 0x3FF7154760000000
  %2000 = call float @dx.op.unary.f32(i32 21, float %1999)  ; Exp(value)
  %2001 = fmul fast float %2000, %1992
  br label %2002

; <label>:2002                                    ; preds = %1991, %1951
  %2003 = phi float [ %2001, %1991 ], [ 1.000000e+00, %1951 ]
  %2004 = fmul fast float %1977, %16
  %2005 = fmul fast float %2004, %2003
  %2006 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2005)  ; FMin(a,b)
  %2007 = fmul fast float %2006, 0xBFF7154760000000
  %2008 = call float @dx.op.unary.f32(i32 21, float %2007)  ; Exp(value)
  %2009 = fsub fast float 1.000000e+00, %2008
  %2010 = call float @dx.op.binary.f32(i32 36, float %12, float %2009)  ; FMin(a,b)
  %2011 = fsub fast float %13, %1889
  %2012 = fsub fast float %14, %1890
  %2013 = fsub fast float %15, %1891
  %2014 = fmul fast float %2010, %2011
  %2015 = fmul fast float %2010, %2012
  %2016 = fmul fast float %2010, %2013
  %2017 = fadd fast float %2014, %1889
  %2018 = fadd fast float %2015, %1890
  %2019 = fadd fast float %2016, %1891
  br label %2020

; <label>:2020                                    ; preds = %2002, %1934, %1928
  %2021 = phi float [ %2017, %2002 ], [ %1889, %1934 ], [ %1889, %1928 ]
  %2022 = phi float [ %2018, %2002 ], [ %1890, %1934 ], [ %1890, %1928 ]
  %2023 = phi float [ %2019, %2002 ], [ %1891, %1934 ], [ %1891, %1928 ]
  %2024 = fadd fast float %5, 1.000000e+00
  %2025 = fadd fast float %6, 1.000000e+00
  %2026 = fsub fast float 1.000000e+00, %5
  %2027 = fmul fast float %36, %2024
  %2028 = fmul fast float %36, %2025
  %2029 = fmul fast float %36, %2026
  %2030 = fmul fast float %2027, %2021
  %2031 = fmul fast float %2028, %2022
  %2032 = fmul fast float %2029, %2023
  %2033 = fcmp fast ult float %37, 5.000000e-01
  br i1 %2033, label %2059, label %2034

; <label>:2034                                    ; preds = %2020
  %2035 = fmul fast float %2030, 0x4004147AE0000000
  %2036 = fmul fast float %2031, 0x4004147AE0000000
  %2037 = fmul fast float %2032, 0x4004147AE0000000
  %2038 = fadd fast float %2035, 0x3F9EB851E0000000
  %2039 = fadd fast float %2036, 0x3F9EB851E0000000
  %2040 = fadd fast float %2037, 0x3F9EB851E0000000
  %2041 = fmul fast float %2038, %2030
  %2042 = fmul fast float %2039, %2031
  %2043 = fmul fast float %2040, %2032
  %2044 = fmul fast float %2030, 0x400370A3E0000000
  %2045 = fmul fast float %2031, 0x400370A3E0000000
  %2046 = fmul fast float %2032, 0x400370A3E0000000
  %2047 = fadd fast float %2044, 0x3FE2E147A0000000
  %2048 = fadd fast float %2045, 0x3FE2E147A0000000
  %2049 = fadd fast float %2046, 0x3FE2E147A0000000
  %2050 = fmul fast float %2047, %2030
  %2051 = fmul fast float %2048, %2031
  %2052 = fmul fast float %2049, %2032
  %2053 = fadd fast float %2050, 0x3FC1EB8520000000
  %2054 = fadd fast float %2051, 0x3FC1EB8520000000
  %2055 = fadd fast float %2052, 0x3FC1EB8520000000
  %2056 = fdiv fast float %2041, %2053
  %2057 = fdiv fast float %2042, %2054
  %2058 = fdiv fast float %2043, %2055
  br label %2059

; <label>:2059                                    ; preds = %2034, %2020
  %2060 = phi float [ %2056, %2034 ], [ %2030, %2020 ]
  %2061 = phi float [ %2057, %2034 ], [ %2031, %2020 ]
  %2062 = phi float [ %2058, %2034 ], [ %2032, %2020 ]
  %2063 = call float @dx.op.unary.f32(i32 7, float %2060)  ; Saturate(value)
  %2064 = call float @dx.op.unary.f32(i32 7, float %2061)  ; Saturate(value)
  %2065 = call float @dx.op.unary.f32(i32 7, float %2062)  ; Saturate(value)
  %2066 = call float @dx.op.dot3.f32(i32 55, float %2063, float %2064, float %2065, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2067 = fsub fast float %2063, %2066
  %2068 = fsub fast float %2064, %2066
  %2069 = fsub fast float %2065, %2066
  %2070 = fmul fast float %2067, %8
  %2071 = fmul fast float %2068, %8
  %2072 = fmul fast float %2069, %8
  %2073 = fadd fast float %2070, %2066
  %2074 = fadd fast float %2071, %2066
  %2075 = fadd fast float %2072, %2066
  %2076 = call float @dx.op.unary.f32(i32 7, float %2073)  ; Saturate(value)
  %2077 = call float @dx.op.unary.f32(i32 7, float %2074)  ; Saturate(value)
  %2078 = call float @dx.op.unary.f32(i32 7, float %2075)  ; Saturate(value)
  %2079 = fadd fast float %2076, 0xBFC70A3D80000000
  %2080 = fadd fast float %2077, 0xBFC70A3D80000000
  %2081 = fadd fast float %2078, 0xBFC70A3D80000000
  %2082 = fmul fast float %2079, %7
  %2083 = fmul fast float %2080, %7
  %2084 = fmul fast float %2081, %7
  %2085 = fadd fast float %2082, 0x3FC70A3D80000000
  %2086 = fadd fast float %2083, 0x3FC70A3D80000000
  %2087 = fadd fast float %2084, 0x3FC70A3D80000000
  %2088 = call float @dx.op.unary.f32(i32 7, float %2085)  ; Saturate(value)
  %2089 = call float @dx.op.unary.f32(i32 7, float %2086)  ; Saturate(value)
  %2090 = call float @dx.op.unary.f32(i32 7, float %2087)  ; Saturate(value)
  br label %2091

; <label>:2091                                    ; preds = %2059, %1894
  %2092 = phi float [ %1925, %1894 ], [ %2088, %2059 ]
  %2093 = phi float [ %1926, %1894 ], [ %2089, %2059 ]
  %2094 = phi float [ %1927, %1894 ], [ %2090, %2059 ]
  %2095 = fsub fast float %2092, %1628
  %2096 = fsub fast float %2093, %1629
  %2097 = fsub fast float %2094, %1630
  %2098 = fmul fast float %2095, %1881
  %2099 = fmul fast float %2096, %1881
  %2100 = fmul fast float %2097, %1881
  %2101 = fadd fast float %2098, %1628
  %2102 = fadd fast float %2099, %1629
  %2103 = fadd fast float %2100, %1630
  br label %2104

; <label>:2104                                    ; preds = %2091, %1868
  %2105 = phi float [ %2101, %2091 ], [ %1628, %1868 ]
  %2106 = phi float [ %2102, %2091 ], [ %1629, %1868 ]
  %2107 = phi float [ %2103, %2091 ], [ %1630, %1868 ]
  %2108 = add i32 %67, -1
  %2109 = call i32 @dx.op.binary.i32(i32 37, i32 %2108, i32 0)  ; IMax(a,b)
  %2110 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %2111 = call i32 @dx.op.binary.i32(i32 38, i32 %2109, i32 %59)  ; IMin(a,b)
  %2112 = call i32 @dx.op.binary.i32(i32 38, i32 %2110, i32 %60)  ; IMin(a,b)
  %2113 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2111, i32 %2112, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2114 = extractvalue %dx.types.ResRet.f32 %2113, 0
  %2115 = fsub fast float %2114, %84
  %2116 = call float @dx.op.unary.f32(i32 6, float %2115)  ; FAbs(value)
  %2117 = fdiv fast float %2116, %1640
  %2118 = fsub fast float 1.000000e+00, %2117
  %2119 = call float @dx.op.unary.f32(i32 7, float %2118)  ; Saturate(value)
  %2120 = fcmp fast ugt float %2119, 0.000000e+00
  br i1 %2120, label %2121, label %2342

; <label>:2121                                    ; preds = %2104
  %2122 = call i32 @dx.op.binary.i32(i32 37, i32 %2111, i32 0)  ; IMax(a,b)
  %2123 = call i32 @dx.op.binary.i32(i32 37, i32 %2112, i32 0)  ; IMax(a,b)
  %2124 = call i32 @dx.op.binary.i32(i32 38, i32 %2122, i32 %59)  ; IMin(a,b)
  %2125 = call i32 @dx.op.binary.i32(i32 38, i32 %2123, i32 %60)  ; IMin(a,b)
  %2126 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2124, i32 %2125, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2127 = extractvalue %dx.types.ResRet.f32 %2126, 0
  %2128 = extractvalue %dx.types.ResRet.f32 %2126, 1
  %2129 = extractvalue %dx.types.ResRet.f32 %2126, 2
  %2130 = extractvalue %dx.types.ResRet.f32 %2126, 3
  %2131 = fcmp fast olt float %2130, 0.000000e+00
  br i1 %2131, label %2132, label %2166

; <label>:2132                                    ; preds = %2121
  %2133 = fcmp fast ogt float %2127, 0x3FA4B5DCC0000000
  %2134 = fcmp fast ogt float %2128, 0x3FA4B5DCC0000000
  %2135 = fcmp fast ogt float %2129, 0x3FA4B5DCC0000000
  %2136 = select i1 %2133, float 0.000000e+00, float 1.000000e+00
  %2137 = select i1 %2134, float 0.000000e+00, float 1.000000e+00
  %2138 = select i1 %2135, float 0.000000e+00, float 1.000000e+00
  %2139 = fmul fast float %2127, 0x3FB3D07220000000
  %2140 = fmul fast float %2128, 0x3FB3D07220000000
  %2141 = fmul fast float %2129, 0x3FB3D07220000000
  %2142 = fadd fast float %2127, 0x3FAC28F5C0000000
  %2143 = fadd fast float %2128, 0x3FAC28F5C0000000
  %2144 = fadd fast float %2129, 0x3FAC28F5C0000000
  %2145 = fmul fast float %2142, 0x3FEE54EDE0000000
  %2146 = fmul fast float %2143, 0x3FEE54EDE0000000
  %2147 = fmul fast float %2144, 0x3FEE54EDE0000000
  %2148 = call float @dx.op.unary.f32(i32 23, float %2145)  ; Log(value)
  %2149 = call float @dx.op.unary.f32(i32 23, float %2146)  ; Log(value)
  %2150 = call float @dx.op.unary.f32(i32 23, float %2147)  ; Log(value)
  %2151 = fmul fast float %2148, 0x4003333340000000
  %2152 = fmul fast float %2149, 0x4003333340000000
  %2153 = fmul fast float %2150, 0x4003333340000000
  %2154 = call float @dx.op.unary.f32(i32 21, float %2151)  ; Exp(value)
  %2155 = call float @dx.op.unary.f32(i32 21, float %2152)  ; Exp(value)
  %2156 = call float @dx.op.unary.f32(i32 21, float %2153)  ; Exp(value)
  %2157 = fsub fast float %2139, %2154
  %2158 = fsub fast float %2140, %2155
  %2159 = fsub fast float %2141, %2156
  %2160 = fmul fast float %2157, %2136
  %2161 = fmul fast float %2158, %2137
  %2162 = fmul fast float %2159, %2138
  %2163 = fadd fast float %2160, %2154
  %2164 = fadd fast float %2161, %2155
  %2165 = fadd fast float %2162, %2156
  br label %2329

; <label>:2166                                    ; preds = %2121
  %2167 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2124, i32 %2125, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2168 = extractvalue %dx.types.ResRet.f32 %2167, 0
  %2169 = fcmp fast ogt float %38, 5.000000e-01
  %2170 = fcmp fast olt float %2168, 1.000000e+00
  %2171 = and i1 %2169, %2170
  br i1 %2171, label %2172, label %2258

; <label>:2172                                    ; preds = %2166
  %2173 = sitofp i32 %2124 to float
  %2174 = sitofp i32 %2125 to float
  %2175 = fadd fast float %2173, 5.000000e-01
  %2176 = fadd fast float %2174, 5.000000e-01
  %2177 = fdiv fast float %2175, %45
  %2178 = fdiv fast float %2176, %46
  %2179 = fmul fast float %2177, 2.000000e+00
  %2180 = fmul fast float %2178, 2.000000e+00
  %2181 = fadd fast float %2179, -1.000000e+00
  %2182 = fsub fast float 1.000000e+00, %2180
  %2183 = fmul fast float %2181, %35
  %2184 = call float @dx.op.tertiary.f32(i32 46, float %2182, float %31, float %2183)  ; FMad(a,b,c)
  %2185 = call float @dx.op.tertiary.f32(i32 46, float %2168, float %27, float %2184)  ; FMad(a,b,c)
  %2186 = fadd fast float %2185, %23
  %2187 = call float @dx.op.unary.f32(i32 6, float %2186)  ; FAbs(value)
  %2188 = fcmp fast ogt float %2187, 0x3EB0C6F7A0000000
  br i1 %2188, label %2189, label %2258

; <label>:2189                                    ; preds = %2172
  %2190 = fmul fast float %2181, %34
  %2191 = call float @dx.op.tertiary.f32(i32 46, float %2182, float %30, float %2190)  ; FMad(a,b,c)
  %2192 = call float @dx.op.tertiary.f32(i32 46, float %2168, float %26, float %2191)  ; FMad(a,b,c)
  %2193 = fadd fast float %2192, %22
  %2194 = fmul fast float %2181, %33
  %2195 = call float @dx.op.tertiary.f32(i32 46, float %2182, float %29, float %2194)  ; FMad(a,b,c)
  %2196 = call float @dx.op.tertiary.f32(i32 46, float %2168, float %25, float %2195)  ; FMad(a,b,c)
  %2197 = fadd fast float %2196, %21
  %2198 = fmul fast float %2181, %32
  %2199 = call float @dx.op.tertiary.f32(i32 46, float %2182, float %28, float %2198)  ; FMad(a,b,c)
  %2200 = call float @dx.op.tertiary.f32(i32 46, float %2168, float %24, float %2199)  ; FMad(a,b,c)
  %2201 = fadd fast float %2200, %20
  %2202 = fdiv fast float %2201, %2186
  %2203 = fdiv fast float %2197, %2186
  %2204 = fdiv fast float %2193, %2186
  %2205 = fsub fast float %2202, %17
  %2206 = fsub fast float %2203, %18
  %2207 = fsub fast float %2204, %19
  %2208 = fmul fast float %2205, %2205
  %2209 = fmul fast float %2206, %2206
  %2210 = fadd fast float %2209, %2208
  %2211 = fmul fast float %2207, %2207
  %2212 = fadd fast float %2210, %2211
  %2213 = call float @dx.op.unary.f32(i32 24, float %2212)  ; Sqrt(value)
  %2214 = fsub fast float %2213, %9
  %2215 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2214)  ; FMax(a,b)
  %2216 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %2216, label %2217, label %2240

; <label>:2217                                    ; preds = %2189
  %2218 = call float @dx.op.unary.f32(i32 6, float %2206)  ; FAbs(value)
  %2219 = fmul fast float %2218, %11
  %2220 = fcmp fast olt float %2219, 0x3F50624DE0000000
  br i1 %2220, label %2221, label %2224

; <label>:2221                                    ; preds = %2217
  %2222 = fmul fast float %2219, 5.000000e-01
  %2223 = fsub fast float 1.000000e+00, %2222
  br label %2229

; <label>:2224                                    ; preds = %2217
  %2225 = fmul fast float %2219, 0xBFF7154760000000
  %2226 = call float @dx.op.unary.f32(i32 21, float %2225)  ; Exp(value)
  %2227 = fsub fast float 1.000000e+00, %2226
  %2228 = fdiv fast float %2227, %2219
  br label %2229

; <label>:2229                                    ; preds = %2224, %2221
  %2230 = phi float [ %2223, %2221 ], [ %2228, %2224 ]
  %2231 = call float @dx.op.binary.f32(i32 36, float %2203, float %18)  ; FMin(a,b)
  %2232 = fsub fast float %2231, %10
  %2233 = fmul fast float %11, %2232
  %2234 = fsub fast float -0.000000e+00, %2233
  %2235 = call float @dx.op.binary.f32(i32 35, float %2234, float -4.000000e+01)  ; FMax(a,b)
  %2236 = call float @dx.op.binary.f32(i32 36, float %2235, float 5.000000e+00)  ; FMin(a,b)
  %2237 = fmul fast float %2236, 0x3FF7154760000000
  %2238 = call float @dx.op.unary.f32(i32 21, float %2237)  ; Exp(value)
  %2239 = fmul fast float %2238, %2230
  br label %2240

; <label>:2240                                    ; preds = %2229, %2189
  %2241 = phi float [ %2239, %2229 ], [ 1.000000e+00, %2189 ]
  %2242 = fmul fast float %2215, %16
  %2243 = fmul fast float %2242, %2241
  %2244 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2243)  ; FMin(a,b)
  %2245 = fmul fast float %2244, 0xBFF7154760000000
  %2246 = call float @dx.op.unary.f32(i32 21, float %2245)  ; Exp(value)
  %2247 = fsub fast float 1.000000e+00, %2246
  %2248 = call float @dx.op.binary.f32(i32 36, float %12, float %2247)  ; FMin(a,b)
  %2249 = fsub fast float %13, %2127
  %2250 = fsub fast float %14, %2128
  %2251 = fsub fast float %15, %2129
  %2252 = fmul fast float %2248, %2249
  %2253 = fmul fast float %2248, %2250
  %2254 = fmul fast float %2248, %2251
  %2255 = fadd fast float %2252, %2127
  %2256 = fadd fast float %2253, %2128
  %2257 = fadd fast float %2254, %2129
  br label %2258

; <label>:2258                                    ; preds = %2240, %2172, %2166
  %2259 = phi float [ %2255, %2240 ], [ %2127, %2172 ], [ %2127, %2166 ]
  %2260 = phi float [ %2256, %2240 ], [ %2128, %2172 ], [ %2128, %2166 ]
  %2261 = phi float [ %2257, %2240 ], [ %2129, %2172 ], [ %2129, %2166 ]
  %2262 = fadd fast float %5, 1.000000e+00
  %2263 = fadd fast float %6, 1.000000e+00
  %2264 = fsub fast float 1.000000e+00, %5
  %2265 = fmul fast float %36, %2262
  %2266 = fmul fast float %36, %2263
  %2267 = fmul fast float %36, %2264
  %2268 = fmul fast float %2265, %2259
  %2269 = fmul fast float %2266, %2260
  %2270 = fmul fast float %2267, %2261
  %2271 = fcmp fast ult float %37, 5.000000e-01
  br i1 %2271, label %2297, label %2272

; <label>:2272                                    ; preds = %2258
  %2273 = fmul fast float %2268, 0x4004147AE0000000
  %2274 = fmul fast float %2269, 0x4004147AE0000000
  %2275 = fmul fast float %2270, 0x4004147AE0000000
  %2276 = fadd fast float %2273, 0x3F9EB851E0000000
  %2277 = fadd fast float %2274, 0x3F9EB851E0000000
  %2278 = fadd fast float %2275, 0x3F9EB851E0000000
  %2279 = fmul fast float %2276, %2268
  %2280 = fmul fast float %2277, %2269
  %2281 = fmul fast float %2278, %2270
  %2282 = fmul fast float %2268, 0x400370A3E0000000
  %2283 = fmul fast float %2269, 0x400370A3E0000000
  %2284 = fmul fast float %2270, 0x400370A3E0000000
  %2285 = fadd fast float %2282, 0x3FE2E147A0000000
  %2286 = fadd fast float %2283, 0x3FE2E147A0000000
  %2287 = fadd fast float %2284, 0x3FE2E147A0000000
  %2288 = fmul fast float %2285, %2268
  %2289 = fmul fast float %2286, %2269
  %2290 = fmul fast float %2287, %2270
  %2291 = fadd fast float %2288, 0x3FC1EB8520000000
  %2292 = fadd fast float %2289, 0x3FC1EB8520000000
  %2293 = fadd fast float %2290, 0x3FC1EB8520000000
  %2294 = fdiv fast float %2279, %2291
  %2295 = fdiv fast float %2280, %2292
  %2296 = fdiv fast float %2281, %2293
  br label %2297

; <label>:2297                                    ; preds = %2272, %2258
  %2298 = phi float [ %2294, %2272 ], [ %2268, %2258 ]
  %2299 = phi float [ %2295, %2272 ], [ %2269, %2258 ]
  %2300 = phi float [ %2296, %2272 ], [ %2270, %2258 ]
  %2301 = call float @dx.op.unary.f32(i32 7, float %2298)  ; Saturate(value)
  %2302 = call float @dx.op.unary.f32(i32 7, float %2299)  ; Saturate(value)
  %2303 = call float @dx.op.unary.f32(i32 7, float %2300)  ; Saturate(value)
  %2304 = call float @dx.op.dot3.f32(i32 55, float %2301, float %2302, float %2303, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2305 = fsub fast float %2301, %2304
  %2306 = fsub fast float %2302, %2304
  %2307 = fsub fast float %2303, %2304
  %2308 = fmul fast float %2305, %8
  %2309 = fmul fast float %2306, %8
  %2310 = fmul fast float %2307, %8
  %2311 = fadd fast float %2308, %2304
  %2312 = fadd fast float %2309, %2304
  %2313 = fadd fast float %2310, %2304
  %2314 = call float @dx.op.unary.f32(i32 7, float %2311)  ; Saturate(value)
  %2315 = call float @dx.op.unary.f32(i32 7, float %2312)  ; Saturate(value)
  %2316 = call float @dx.op.unary.f32(i32 7, float %2313)  ; Saturate(value)
  %2317 = fadd fast float %2314, 0xBFC70A3D80000000
  %2318 = fadd fast float %2315, 0xBFC70A3D80000000
  %2319 = fadd fast float %2316, 0xBFC70A3D80000000
  %2320 = fmul fast float %2317, %7
  %2321 = fmul fast float %2318, %7
  %2322 = fmul fast float %2319, %7
  %2323 = fadd fast float %2320, 0x3FC70A3D80000000
  %2324 = fadd fast float %2321, 0x3FC70A3D80000000
  %2325 = fadd fast float %2322, 0x3FC70A3D80000000
  %2326 = call float @dx.op.unary.f32(i32 7, float %2323)  ; Saturate(value)
  %2327 = call float @dx.op.unary.f32(i32 7, float %2324)  ; Saturate(value)
  %2328 = call float @dx.op.unary.f32(i32 7, float %2325)  ; Saturate(value)
  br label %2329

; <label>:2329                                    ; preds = %2297, %2132
  %2330 = phi float [ %2163, %2132 ], [ %2326, %2297 ]
  %2331 = phi float [ %2164, %2132 ], [ %2327, %2297 ]
  %2332 = phi float [ %2165, %2132 ], [ %2328, %2297 ]
  %2333 = fsub fast float %2330, %1628
  %2334 = fsub fast float %2331, %1629
  %2335 = fsub fast float %2332, %1630
  %2336 = fmul fast float %2333, %2119
  %2337 = fmul fast float %2334, %2119
  %2338 = fmul fast float %2335, %2119
  %2339 = fadd fast float %2336, %1628
  %2340 = fadd fast float %2337, %1629
  %2341 = fadd fast float %2338, %1630
  br label %2342

; <label>:2342                                    ; preds = %2329, %2104
  %2343 = phi float [ %2339, %2329 ], [ %1628, %2104 ]
  %2344 = phi float [ %2340, %2329 ], [ %1629, %2104 ]
  %2345 = phi float [ %2341, %2329 ], [ %1630, %2104 ]
  %2346 = add i32 %67, 1
  %2347 = call i32 @dx.op.binary.i32(i32 37, i32 %2346, i32 0)  ; IMax(a,b)
  %2348 = call i32 @dx.op.binary.i32(i32 38, i32 %2347, i32 %59)  ; IMin(a,b)
  %2349 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2348, i32 %2112, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2350 = extractvalue %dx.types.ResRet.f32 %2349, 0
  %2351 = fsub fast float %2350, %84
  %2352 = call float @dx.op.unary.f32(i32 6, float %2351)  ; FAbs(value)
  %2353 = fdiv fast float %2352, %1640
  %2354 = fsub fast float 1.000000e+00, %2353
  %2355 = call float @dx.op.unary.f32(i32 7, float %2354)  ; Saturate(value)
  %2356 = fcmp fast ugt float %2355, 0.000000e+00
  br i1 %2356, label %2357, label %2578

; <label>:2357                                    ; preds = %2342
  %2358 = call i32 @dx.op.binary.i32(i32 37, i32 %2348, i32 0)  ; IMax(a,b)
  %2359 = call i32 @dx.op.binary.i32(i32 37, i32 %2112, i32 0)  ; IMax(a,b)
  %2360 = call i32 @dx.op.binary.i32(i32 38, i32 %2358, i32 %59)  ; IMin(a,b)
  %2361 = call i32 @dx.op.binary.i32(i32 38, i32 %2359, i32 %60)  ; IMin(a,b)
  %2362 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2360, i32 %2361, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2363 = extractvalue %dx.types.ResRet.f32 %2362, 0
  %2364 = extractvalue %dx.types.ResRet.f32 %2362, 1
  %2365 = extractvalue %dx.types.ResRet.f32 %2362, 2
  %2366 = extractvalue %dx.types.ResRet.f32 %2362, 3
  %2367 = fcmp fast olt float %2366, 0.000000e+00
  br i1 %2367, label %2368, label %2402

; <label>:2368                                    ; preds = %2357
  %2369 = fcmp fast ogt float %2363, 0x3FA4B5DCC0000000
  %2370 = fcmp fast ogt float %2364, 0x3FA4B5DCC0000000
  %2371 = fcmp fast ogt float %2365, 0x3FA4B5DCC0000000
  %2372 = select i1 %2369, float 0.000000e+00, float 1.000000e+00
  %2373 = select i1 %2370, float 0.000000e+00, float 1.000000e+00
  %2374 = select i1 %2371, float 0.000000e+00, float 1.000000e+00
  %2375 = fmul fast float %2363, 0x3FB3D07220000000
  %2376 = fmul fast float %2364, 0x3FB3D07220000000
  %2377 = fmul fast float %2365, 0x3FB3D07220000000
  %2378 = fadd fast float %2363, 0x3FAC28F5C0000000
  %2379 = fadd fast float %2364, 0x3FAC28F5C0000000
  %2380 = fadd fast float %2365, 0x3FAC28F5C0000000
  %2381 = fmul fast float %2378, 0x3FEE54EDE0000000
  %2382 = fmul fast float %2379, 0x3FEE54EDE0000000
  %2383 = fmul fast float %2380, 0x3FEE54EDE0000000
  %2384 = call float @dx.op.unary.f32(i32 23, float %2381)  ; Log(value)
  %2385 = call float @dx.op.unary.f32(i32 23, float %2382)  ; Log(value)
  %2386 = call float @dx.op.unary.f32(i32 23, float %2383)  ; Log(value)
  %2387 = fmul fast float %2384, 0x4003333340000000
  %2388 = fmul fast float %2385, 0x4003333340000000
  %2389 = fmul fast float %2386, 0x4003333340000000
  %2390 = call float @dx.op.unary.f32(i32 21, float %2387)  ; Exp(value)
  %2391 = call float @dx.op.unary.f32(i32 21, float %2388)  ; Exp(value)
  %2392 = call float @dx.op.unary.f32(i32 21, float %2389)  ; Exp(value)
  %2393 = fsub fast float %2375, %2390
  %2394 = fsub fast float %2376, %2391
  %2395 = fsub fast float %2377, %2392
  %2396 = fmul fast float %2393, %2372
  %2397 = fmul fast float %2394, %2373
  %2398 = fmul fast float %2395, %2374
  %2399 = fadd fast float %2396, %2390
  %2400 = fadd fast float %2397, %2391
  %2401 = fadd fast float %2398, %2392
  br label %2565

; <label>:2402                                    ; preds = %2357
  %2403 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2360, i32 %2361, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2404 = extractvalue %dx.types.ResRet.f32 %2403, 0
  %2405 = fcmp fast ogt float %38, 5.000000e-01
  %2406 = fcmp fast olt float %2404, 1.000000e+00
  %2407 = and i1 %2405, %2406
  br i1 %2407, label %2408, label %2494

; <label>:2408                                    ; preds = %2402
  %2409 = sitofp i32 %2360 to float
  %2410 = sitofp i32 %2361 to float
  %2411 = fadd fast float %2409, 5.000000e-01
  %2412 = fadd fast float %2410, 5.000000e-01
  %2413 = fdiv fast float %2411, %45
  %2414 = fdiv fast float %2412, %46
  %2415 = fmul fast float %2413, 2.000000e+00
  %2416 = fmul fast float %2414, 2.000000e+00
  %2417 = fadd fast float %2415, -1.000000e+00
  %2418 = fsub fast float 1.000000e+00, %2416
  %2419 = fmul fast float %2417, %35
  %2420 = call float @dx.op.tertiary.f32(i32 46, float %2418, float %31, float %2419)  ; FMad(a,b,c)
  %2421 = call float @dx.op.tertiary.f32(i32 46, float %2404, float %27, float %2420)  ; FMad(a,b,c)
  %2422 = fadd fast float %2421, %23
  %2423 = call float @dx.op.unary.f32(i32 6, float %2422)  ; FAbs(value)
  %2424 = fcmp fast ogt float %2423, 0x3EB0C6F7A0000000
  br i1 %2424, label %2425, label %2494

; <label>:2425                                    ; preds = %2408
  %2426 = fmul fast float %2417, %34
  %2427 = call float @dx.op.tertiary.f32(i32 46, float %2418, float %30, float %2426)  ; FMad(a,b,c)
  %2428 = call float @dx.op.tertiary.f32(i32 46, float %2404, float %26, float %2427)  ; FMad(a,b,c)
  %2429 = fadd fast float %2428, %22
  %2430 = fmul fast float %2417, %33
  %2431 = call float @dx.op.tertiary.f32(i32 46, float %2418, float %29, float %2430)  ; FMad(a,b,c)
  %2432 = call float @dx.op.tertiary.f32(i32 46, float %2404, float %25, float %2431)  ; FMad(a,b,c)
  %2433 = fadd fast float %2432, %21
  %2434 = fmul fast float %2417, %32
  %2435 = call float @dx.op.tertiary.f32(i32 46, float %2418, float %28, float %2434)  ; FMad(a,b,c)
  %2436 = call float @dx.op.tertiary.f32(i32 46, float %2404, float %24, float %2435)  ; FMad(a,b,c)
  %2437 = fadd fast float %2436, %20
  %2438 = fdiv fast float %2437, %2422
  %2439 = fdiv fast float %2433, %2422
  %2440 = fdiv fast float %2429, %2422
  %2441 = fsub fast float %2438, %17
  %2442 = fsub fast float %2439, %18
  %2443 = fsub fast float %2440, %19
  %2444 = fmul fast float %2441, %2441
  %2445 = fmul fast float %2442, %2442
  %2446 = fadd fast float %2445, %2444
  %2447 = fmul fast float %2443, %2443
  %2448 = fadd fast float %2446, %2447
  %2449 = call float @dx.op.unary.f32(i32 24, float %2448)  ; Sqrt(value)
  %2450 = fsub fast float %2449, %9
  %2451 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2450)  ; FMax(a,b)
  %2452 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %2452, label %2453, label %2476

; <label>:2453                                    ; preds = %2425
  %2454 = call float @dx.op.unary.f32(i32 6, float %2442)  ; FAbs(value)
  %2455 = fmul fast float %2454, %11
  %2456 = fcmp fast olt float %2455, 0x3F50624DE0000000
  br i1 %2456, label %2457, label %2460

; <label>:2457                                    ; preds = %2453
  %2458 = fmul fast float %2455, 5.000000e-01
  %2459 = fsub fast float 1.000000e+00, %2458
  br label %2465

; <label>:2460                                    ; preds = %2453
  %2461 = fmul fast float %2455, 0xBFF7154760000000
  %2462 = call float @dx.op.unary.f32(i32 21, float %2461)  ; Exp(value)
  %2463 = fsub fast float 1.000000e+00, %2462
  %2464 = fdiv fast float %2463, %2455
  br label %2465

; <label>:2465                                    ; preds = %2460, %2457
  %2466 = phi float [ %2459, %2457 ], [ %2464, %2460 ]
  %2467 = call float @dx.op.binary.f32(i32 36, float %2439, float %18)  ; FMin(a,b)
  %2468 = fsub fast float %2467, %10
  %2469 = fmul fast float %11, %2468
  %2470 = fsub fast float -0.000000e+00, %2469
  %2471 = call float @dx.op.binary.f32(i32 35, float %2470, float -4.000000e+01)  ; FMax(a,b)
  %2472 = call float @dx.op.binary.f32(i32 36, float %2471, float 5.000000e+00)  ; FMin(a,b)
  %2473 = fmul fast float %2472, 0x3FF7154760000000
  %2474 = call float @dx.op.unary.f32(i32 21, float %2473)  ; Exp(value)
  %2475 = fmul fast float %2474, %2466
  br label %2476

; <label>:2476                                    ; preds = %2465, %2425
  %2477 = phi float [ %2475, %2465 ], [ 1.000000e+00, %2425 ]
  %2478 = fmul fast float %2451, %16
  %2479 = fmul fast float %2478, %2477
  %2480 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2479)  ; FMin(a,b)
  %2481 = fmul fast float %2480, 0xBFF7154760000000
  %2482 = call float @dx.op.unary.f32(i32 21, float %2481)  ; Exp(value)
  %2483 = fsub fast float 1.000000e+00, %2482
  %2484 = call float @dx.op.binary.f32(i32 36, float %12, float %2483)  ; FMin(a,b)
  %2485 = fsub fast float %13, %2363
  %2486 = fsub fast float %14, %2364
  %2487 = fsub fast float %15, %2365
  %2488 = fmul fast float %2484, %2485
  %2489 = fmul fast float %2484, %2486
  %2490 = fmul fast float %2484, %2487
  %2491 = fadd fast float %2488, %2363
  %2492 = fadd fast float %2489, %2364
  %2493 = fadd fast float %2490, %2365
  br label %2494

; <label>:2494                                    ; preds = %2476, %2408, %2402
  %2495 = phi float [ %2491, %2476 ], [ %2363, %2408 ], [ %2363, %2402 ]
  %2496 = phi float [ %2492, %2476 ], [ %2364, %2408 ], [ %2364, %2402 ]
  %2497 = phi float [ %2493, %2476 ], [ %2365, %2408 ], [ %2365, %2402 ]
  %2498 = fadd fast float %5, 1.000000e+00
  %2499 = fadd fast float %6, 1.000000e+00
  %2500 = fsub fast float 1.000000e+00, %5
  %2501 = fmul fast float %36, %2498
  %2502 = fmul fast float %36, %2499
  %2503 = fmul fast float %36, %2500
  %2504 = fmul fast float %2501, %2495
  %2505 = fmul fast float %2502, %2496
  %2506 = fmul fast float %2503, %2497
  %2507 = fcmp fast ult float %37, 5.000000e-01
  br i1 %2507, label %2533, label %2508

; <label>:2508                                    ; preds = %2494
  %2509 = fmul fast float %2504, 0x4004147AE0000000
  %2510 = fmul fast float %2505, 0x4004147AE0000000
  %2511 = fmul fast float %2506, 0x4004147AE0000000
  %2512 = fadd fast float %2509, 0x3F9EB851E0000000
  %2513 = fadd fast float %2510, 0x3F9EB851E0000000
  %2514 = fadd fast float %2511, 0x3F9EB851E0000000
  %2515 = fmul fast float %2512, %2504
  %2516 = fmul fast float %2513, %2505
  %2517 = fmul fast float %2514, %2506
  %2518 = fmul fast float %2504, 0x400370A3E0000000
  %2519 = fmul fast float %2505, 0x400370A3E0000000
  %2520 = fmul fast float %2506, 0x400370A3E0000000
  %2521 = fadd fast float %2518, 0x3FE2E147A0000000
  %2522 = fadd fast float %2519, 0x3FE2E147A0000000
  %2523 = fadd fast float %2520, 0x3FE2E147A0000000
  %2524 = fmul fast float %2521, %2504
  %2525 = fmul fast float %2522, %2505
  %2526 = fmul fast float %2523, %2506
  %2527 = fadd fast float %2524, 0x3FC1EB8520000000
  %2528 = fadd fast float %2525, 0x3FC1EB8520000000
  %2529 = fadd fast float %2526, 0x3FC1EB8520000000
  %2530 = fdiv fast float %2515, %2527
  %2531 = fdiv fast float %2516, %2528
  %2532 = fdiv fast float %2517, %2529
  br label %2533

; <label>:2533                                    ; preds = %2508, %2494
  %2534 = phi float [ %2530, %2508 ], [ %2504, %2494 ]
  %2535 = phi float [ %2531, %2508 ], [ %2505, %2494 ]
  %2536 = phi float [ %2532, %2508 ], [ %2506, %2494 ]
  %2537 = call float @dx.op.unary.f32(i32 7, float %2534)  ; Saturate(value)
  %2538 = call float @dx.op.unary.f32(i32 7, float %2535)  ; Saturate(value)
  %2539 = call float @dx.op.unary.f32(i32 7, float %2536)  ; Saturate(value)
  %2540 = call float @dx.op.dot3.f32(i32 55, float %2537, float %2538, float %2539, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2541 = fsub fast float %2537, %2540
  %2542 = fsub fast float %2538, %2540
  %2543 = fsub fast float %2539, %2540
  %2544 = fmul fast float %2541, %8
  %2545 = fmul fast float %2542, %8
  %2546 = fmul fast float %2543, %8
  %2547 = fadd fast float %2544, %2540
  %2548 = fadd fast float %2545, %2540
  %2549 = fadd fast float %2546, %2540
  %2550 = call float @dx.op.unary.f32(i32 7, float %2547)  ; Saturate(value)
  %2551 = call float @dx.op.unary.f32(i32 7, float %2548)  ; Saturate(value)
  %2552 = call float @dx.op.unary.f32(i32 7, float %2549)  ; Saturate(value)
  %2553 = fadd fast float %2550, 0xBFC70A3D80000000
  %2554 = fadd fast float %2551, 0xBFC70A3D80000000
  %2555 = fadd fast float %2552, 0xBFC70A3D80000000
  %2556 = fmul fast float %2553, %7
  %2557 = fmul fast float %2554, %7
  %2558 = fmul fast float %2555, %7
  %2559 = fadd fast float %2556, 0x3FC70A3D80000000
  %2560 = fadd fast float %2557, 0x3FC70A3D80000000
  %2561 = fadd fast float %2558, 0x3FC70A3D80000000
  %2562 = call float @dx.op.unary.f32(i32 7, float %2559)  ; Saturate(value)
  %2563 = call float @dx.op.unary.f32(i32 7, float %2560)  ; Saturate(value)
  %2564 = call float @dx.op.unary.f32(i32 7, float %2561)  ; Saturate(value)
  br label %2565

; <label>:2565                                    ; preds = %2533, %2368
  %2566 = phi float [ %2399, %2368 ], [ %2562, %2533 ]
  %2567 = phi float [ %2400, %2368 ], [ %2563, %2533 ]
  %2568 = phi float [ %2401, %2368 ], [ %2564, %2533 ]
  %2569 = fsub fast float %2566, %1628
  %2570 = fsub fast float %2567, %1629
  %2571 = fsub fast float %2568, %1630
  %2572 = fmul fast float %2569, %2355
  %2573 = fmul fast float %2570, %2355
  %2574 = fmul fast float %2571, %2355
  %2575 = fadd fast float %2572, %1628
  %2576 = fadd fast float %2573, %1629
  %2577 = fadd fast float %2574, %1630
  br label %2578

; <label>:2578                                    ; preds = %2565, %2342
  %2579 = phi float [ %2575, %2565 ], [ %1628, %2342 ]
  %2580 = phi float [ %2576, %2565 ], [ %1629, %2342 ]
  %2581 = phi float [ %2577, %2565 ], [ %1630, %2342 ]
  %2582 = call float @dx.op.binary.f32(i32 36, float %2343, float %2579)  ; FMin(a,b)
  %2583 = call float @dx.op.binary.f32(i32 36, float %2344, float %2580)  ; FMin(a,b)
  %2584 = call float @dx.op.binary.f32(i32 36, float %2345, float %2581)  ; FMin(a,b)
  %2585 = call float @dx.op.binary.f32(i32 36, float %1869, float %2105)  ; FMin(a,b)
  %2586 = call float @dx.op.binary.f32(i32 36, float %1870, float %2106)  ; FMin(a,b)
  %2587 = call float @dx.op.binary.f32(i32 36, float %1871, float %2107)  ; FMin(a,b)
  %2588 = call float @dx.op.binary.f32(i32 36, float %2585, float %2582)  ; FMin(a,b)
  %2589 = call float @dx.op.binary.f32(i32 36, float %2586, float %2583)  ; FMin(a,b)
  %2590 = call float @dx.op.binary.f32(i32 36, float %2587, float %2584)  ; FMin(a,b)
  %2591 = call float @dx.op.binary.f32(i32 36, float %1628, float %2588)  ; FMin(a,b)
  %2592 = call float @dx.op.binary.f32(i32 36, float %1629, float %2589)  ; FMin(a,b)
  %2593 = call float @dx.op.binary.f32(i32 36, float %1630, float %2590)  ; FMin(a,b)
  %2594 = call float @dx.op.binary.f32(i32 35, float %2343, float %2579)  ; FMax(a,b)
  %2595 = call float @dx.op.binary.f32(i32 35, float %2344, float %2580)  ; FMax(a,b)
  %2596 = call float @dx.op.binary.f32(i32 35, float %2345, float %2581)  ; FMax(a,b)
  %2597 = call float @dx.op.binary.f32(i32 35, float %1869, float %2105)  ; FMax(a,b)
  %2598 = call float @dx.op.binary.f32(i32 35, float %1870, float %2106)  ; FMax(a,b)
  %2599 = call float @dx.op.binary.f32(i32 35, float %1871, float %2107)  ; FMax(a,b)
  %2600 = call float @dx.op.binary.f32(i32 35, float %2597, float %2594)  ; FMax(a,b)
  %2601 = call float @dx.op.binary.f32(i32 35, float %2598, float %2595)  ; FMax(a,b)
  %2602 = call float @dx.op.binary.f32(i32 35, float %2599, float %2596)  ; FMax(a,b)
  %2603 = call float @dx.op.binary.f32(i32 35, float %1628, float %2600)  ; FMax(a,b)
  %2604 = call float @dx.op.binary.f32(i32 35, float %1629, float %2601)  ; FMax(a,b)
  %2605 = call float @dx.op.binary.f32(i32 35, float %1630, float %2602)  ; FMax(a,b)
  %2606 = fsub fast float %2603, %2591
  %2607 = fsub fast float %2604, %2592
  %2608 = fsub fast float %2605, %2593
  %2609 = call float @dx.op.unary.f32(i32 6, float %2606)  ; FAbs(value)
  %2610 = call float @dx.op.unary.f32(i32 6, float %2607)  ; FAbs(value)
  %2611 = call float @dx.op.unary.f32(i32 6, float %2608)  ; FAbs(value)
  %2612 = call float @dx.op.binary.f32(i32 35, float %2610, float %2611)  ; FMax(a,b)
  %2613 = call float @dx.op.binary.f32(i32 35, float %2609, float %2612)  ; FMax(a,b)
  %2614 = call float @dx.op.binary.f32(i32 35, float %2604, float %2605)  ; FMax(a,b)
  %2615 = call float @dx.op.binary.f32(i32 35, float %2603, float %2614)  ; FMax(a,b)
  %2616 = fmul fast float %2615, 1.250000e-01
  %2617 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %2616)  ; FMax(a,b)
  %2618 = fcmp fast ogt float %2613, %2617
  br i1 %2618, label %2619, label %2680

; <label>:2619                                    ; preds = %2578
  %2620 = fsub fast float %1869, %2105
  %2621 = fsub fast float %1870, %2106
  %2622 = fsub fast float %1871, %2107
  %2623 = call float @dx.op.unary.f32(i32 6, float %2620)  ; FAbs(value)
  %2624 = call float @dx.op.unary.f32(i32 6, float %2621)  ; FAbs(value)
  %2625 = call float @dx.op.unary.f32(i32 6, float %2622)  ; FAbs(value)
  %2626 = call float @dx.op.binary.f32(i32 35, float %2624, float %2625)  ; FMax(a,b)
  %2627 = call float @dx.op.binary.f32(i32 35, float %2623, float %2626)  ; FMax(a,b)
  %2628 = fsub fast float %2343, %2579
  %2629 = fsub fast float %2344, %2580
  %2630 = fsub fast float %2345, %2581
  %2631 = call float @dx.op.unary.f32(i32 6, float %2628)  ; FAbs(value)
  %2632 = call float @dx.op.unary.f32(i32 6, float %2629)  ; FAbs(value)
  %2633 = call float @dx.op.unary.f32(i32 6, float %2630)  ; FAbs(value)
  %2634 = call float @dx.op.binary.f32(i32 35, float %2632, float %2633)  ; FMax(a,b)
  %2635 = call float @dx.op.binary.f32(i32 35, float %2631, float %2634)  ; FMax(a,b)
  %2636 = fcmp fast olt float %2627, %2635
  %2637 = select i1 %2636, float %1869, float %2343
  %2638 = select i1 %2636, float %1870, float %2344
  %2639 = select i1 %2636, float %1871, float %2345
  %2640 = select i1 %2636, float %2105, float %2579
  %2641 = select i1 %2636, float %2106, float %2580
  %2642 = select i1 %2636, float %2107, float %2581
  %2643 = fsub fast float %1628, %2640
  %2644 = fsub fast float %1629, %2641
  %2645 = fsub fast float %1630, %2642
  %2646 = fsub fast float %1628, %2637
  %2647 = fsub fast float %1629, %2638
  %2648 = fsub fast float %1630, %2639
  %2649 = call float @dx.op.dot3.f32(i32 55, float %2646, float %2647, float %2648, float %2643, float %2644, float %2645)  ; Dot3(ax,ay,az,bx,by,bz)
  %2650 = fcmp fast ogt float %2649, 0.000000e+00
  br i1 %2650, label %2651, label %2662

; <label>:2651                                    ; preds = %2619
  %2652 = fsub fast float %2637, %2640
  %2653 = fsub fast float %2638, %2641
  %2654 = fsub fast float %2639, %2642
  %2655 = call float @dx.op.unary.f32(i32 6, float %2652)  ; FAbs(value)
  %2656 = call float @dx.op.unary.f32(i32 6, float %2653)  ; FAbs(value)
  %2657 = call float @dx.op.unary.f32(i32 6, float %2654)  ; FAbs(value)
  %2658 = call float @dx.op.binary.f32(i32 35, float %2656, float %2657)  ; FMax(a,b)
  %2659 = call float @dx.op.binary.f32(i32 35, float %2655, float %2658)  ; FMax(a,b)
  %2660 = fmul fast float %2613, 2.500000e-01
  %2661 = fcmp fast olt float %2659, %2660
  br label %2662

; <label>:2662                                    ; preds = %2651, %2619
  %2663 = phi i1 [ false, %2619 ], [ %2661, %2651 ]
  %2664 = select i1 %2663, float 0x3FC3333340000000, float 0x3FD3333340000000
  %2665 = fadd fast float %2637, %2640
  %2666 = fadd fast float %2638, %2641
  %2667 = fadd fast float %2639, %2642
  %2668 = fmul fast float %2665, 5.000000e-01
  %2669 = fmul fast float %2666, 5.000000e-01
  %2670 = fmul fast float %2667, 5.000000e-01
  %2671 = fsub fast float %2668, %1628
  %2672 = fsub fast float %2669, %1629
  %2673 = fsub fast float %2670, %1630
  %2674 = fmul fast float %2664, %2671
  %2675 = fmul fast float %2664, %2672
  %2676 = fmul fast float %2664, %2673
  %2677 = fadd fast float %2674, %1628
  %2678 = fadd fast float %2675, %1629
  %2679 = fadd fast float %2676, %1630
  br label %2680

; <label>:2680                                    ; preds = %2662, %2578
  %2681 = phi float [ %2677, %2662 ], [ %1628, %2578 ]
  %2682 = phi float [ %2678, %2662 ], [ %1629, %2578 ]
  %2683 = phi float [ %2679, %2662 ], [ %1630, %2578 ]
  %2684 = fcmp fast ogt float %2681, 0x3F69A5C380000000
  %2685 = fcmp fast ogt float %2682, 0x3F69A5C380000000
  %2686 = fcmp fast ogt float %2683, 0x3F69A5C380000000
  %2687 = select i1 %2684, float 0.000000e+00, float 1.000000e+00
  %2688 = select i1 %2685, float 0.000000e+00, float 1.000000e+00
  %2689 = select i1 %2686, float 0.000000e+00, float 1.000000e+00
  %2690 = fmul fast float %2681, 0x4029D70A40000000
  %2691 = fmul fast float %2682, 0x4029D70A40000000
  %2692 = fmul fast float %2683, 0x4029D70A40000000
  %2693 = call float @dx.op.binary.f32(i32 35, float %2681, float 0.000000e+00)  ; FMax(a,b)
  %2694 = call float @dx.op.binary.f32(i32 35, float %2682, float 0.000000e+00)  ; FMax(a,b)
  %2695 = call float @dx.op.binary.f32(i32 35, float %2683, float 0.000000e+00)  ; FMax(a,b)
  %2696 = call float @dx.op.unary.f32(i32 23, float %2693)  ; Log(value)
  %2697 = call float @dx.op.unary.f32(i32 23, float %2694)  ; Log(value)
  %2698 = call float @dx.op.unary.f32(i32 23, float %2695)  ; Log(value)
  %2699 = fmul fast float %2696, 0x3FDAAAAAA0000000
  %2700 = fmul fast float %2697, 0x3FDAAAAAA0000000
  %2701 = fmul fast float %2698, 0x3FDAAAAAA0000000
  %2702 = call float @dx.op.unary.f32(i32 21, float %2699)  ; Exp(value)
  %2703 = call float @dx.op.unary.f32(i32 21, float %2700)  ; Exp(value)
  %2704 = call float @dx.op.unary.f32(i32 21, float %2701)  ; Exp(value)
  %2705 = fmul fast float %2702, 0x3FF0E147A0000000
  %2706 = fmul fast float %2703, 0x3FF0E147A0000000
  %2707 = fmul fast float %2704, 0x3FF0E147A0000000
  %2708 = fadd fast float %2705, 0xBFAC28F5C0000000
  %2709 = fadd fast float %2706, 0xBFAC28F5C0000000
  %2710 = fadd fast float %2707, 0xBFAC28F5C0000000
  %2711 = fsub fast float %2690, %2708
  %2712 = fsub fast float %2691, %2709
  %2713 = fsub fast float %2692, %2710
  %2714 = fmul fast float %2711, %2687
  %2715 = fmul fast float %2712, %2688
  %2716 = fmul fast float %2713, %2689
  %2717 = fadd fast float %2714, %2708
  %2718 = fadd fast float %2715, %2709
  %2719 = fadd fast float %2716, %2710
  br label %2720

; <label>:2720                                    ; preds = %2680, %1468
  %2721 = phi float [ %1463, %1468 ], [ %2717, %2680 ]
  %2722 = phi float [ %1464, %1468 ], [ %2718, %2680 ]
  %2723 = phi float [ %1465, %1468 ], [ %2719, %2680 ]
  %2724 = phi float [ %1469, %1468 ], [ %1466, %2680 ]
  %2725 = fcmp fast ogt float %2721, 0x3FA4B5DCC0000000
  %2726 = fcmp fast ogt float %2722, 0x3FA4B5DCC0000000
  %2727 = fcmp fast ogt float %2723, 0x3FA4B5DCC0000000
  %2728 = select i1 %2725, float 0.000000e+00, float 1.000000e+00
  %2729 = select i1 %2726, float 0.000000e+00, float 1.000000e+00
  %2730 = select i1 %2727, float 0.000000e+00, float 1.000000e+00
  %2731 = fmul fast float %2721, 0x3FB3D07220000000
  %2732 = fmul fast float %2722, 0x3FB3D07220000000
  %2733 = fmul fast float %2723, 0x3FB3D07220000000
  %2734 = fadd fast float %2721, 0x3FAC28F5C0000000
  %2735 = fadd fast float %2722, 0x3FAC28F5C0000000
  %2736 = fadd fast float %2723, 0x3FAC28F5C0000000
  %2737 = fmul fast float %2734, 0x3FEE54EDE0000000
  %2738 = fmul fast float %2735, 0x3FEE54EDE0000000
  %2739 = fmul fast float %2736, 0x3FEE54EDE0000000
  %2740 = call float @dx.op.unary.f32(i32 23, float %2737)  ; Log(value)
  %2741 = call float @dx.op.unary.f32(i32 23, float %2738)  ; Log(value)
  %2742 = call float @dx.op.unary.f32(i32 23, float %2739)  ; Log(value)
  %2743 = fmul fast float %2740, 0x4003333340000000
  %2744 = fmul fast float %2741, 0x4003333340000000
  %2745 = fmul fast float %2742, 0x4003333340000000
  %2746 = call float @dx.op.unary.f32(i32 21, float %2743)  ; Exp(value)
  %2747 = call float @dx.op.unary.f32(i32 21, float %2744)  ; Exp(value)
  %2748 = call float @dx.op.unary.f32(i32 21, float %2745)  ; Exp(value)
  %2749 = fsub fast float %2731, %2746
  %2750 = fsub fast float %2732, %2747
  %2751 = fsub fast float %2733, %2748
  %2752 = fmul fast float %2749, %2728
  %2753 = fmul fast float %2750, %2729
  %2754 = fmul fast float %2751, %2730
  %2755 = fadd fast float %2752, %2746
  %2756 = fadd fast float %2753, %2747
  %2757 = fadd fast float %2754, %2748
  %2758 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %63, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2759 = extractvalue %dx.types.ResRet.f32 %2758, 0
  %2760 = extractvalue %dx.types.ResRet.f32 %2758, 1
  %2761 = extractvalue %dx.types.ResRet.f32 %2758, 2
  %2762 = extractvalue %dx.types.ResRet.f32 %2758, 3
  %2763 = fcmp fast olt float %2762, 0.000000e+00
  br i1 %2763, label %2764, label %2766

; <label>:2764                                    ; preds = %2720
  %2765 = fsub fast float -1.000000e+00, %2762
  br label %4016

; <label>:2766                                    ; preds = %2720
  %2767 = fcmp fast ogt float %38, 5.000000e-01
  %2768 = fcmp fast olt float %86, 1.000000e+00
  %2769 = and i1 %2767, %2768
  br i1 %2769, label %2770, label %2856

; <label>:2770                                    ; preds = %2766
  %2771 = sitofp i32 %63 to float
  %2772 = sitofp i32 %70 to float
  %2773 = fadd fast float %2771, 5.000000e-01
  %2774 = fadd fast float %2772, 5.000000e-01
  %2775 = fdiv fast float %2773, %45
  %2776 = fdiv fast float %2774, %46
  %2777 = fmul fast float %2775, 2.000000e+00
  %2778 = fmul fast float %2776, 2.000000e+00
  %2779 = fadd fast float %2777, -1.000000e+00
  %2780 = fsub fast float 1.000000e+00, %2778
  %2781 = fmul fast float %2779, %35
  %2782 = call float @dx.op.tertiary.f32(i32 46, float %2780, float %31, float %2781)  ; FMad(a,b,c)
  %2783 = call float @dx.op.tertiary.f32(i32 46, float %86, float %27, float %2782)  ; FMad(a,b,c)
  %2784 = fadd fast float %2783, %23
  %2785 = call float @dx.op.unary.f32(i32 6, float %2784)  ; FAbs(value)
  %2786 = fcmp fast ogt float %2785, 0x3EB0C6F7A0000000
  br i1 %2786, label %2787, label %2856

; <label>:2787                                    ; preds = %2770
  %2788 = fmul fast float %2779, %34
  %2789 = call float @dx.op.tertiary.f32(i32 46, float %2780, float %30, float %2788)  ; FMad(a,b,c)
  %2790 = call float @dx.op.tertiary.f32(i32 46, float %86, float %26, float %2789)  ; FMad(a,b,c)
  %2791 = fadd fast float %2790, %22
  %2792 = fmul fast float %2779, %33
  %2793 = call float @dx.op.tertiary.f32(i32 46, float %2780, float %29, float %2792)  ; FMad(a,b,c)
  %2794 = call float @dx.op.tertiary.f32(i32 46, float %86, float %25, float %2793)  ; FMad(a,b,c)
  %2795 = fadd fast float %2794, %21
  %2796 = fmul fast float %2779, %32
  %2797 = call float @dx.op.tertiary.f32(i32 46, float %2780, float %28, float %2796)  ; FMad(a,b,c)
  %2798 = call float @dx.op.tertiary.f32(i32 46, float %86, float %24, float %2797)  ; FMad(a,b,c)
  %2799 = fadd fast float %2798, %20
  %2800 = fdiv fast float %2799, %2784
  %2801 = fdiv fast float %2795, %2784
  %2802 = fdiv fast float %2791, %2784
  %2803 = fsub fast float %2800, %17
  %2804 = fsub fast float %2801, %18
  %2805 = fsub fast float %2802, %19
  %2806 = fmul fast float %2803, %2803
  %2807 = fmul fast float %2804, %2804
  %2808 = fadd fast float %2807, %2806
  %2809 = fmul fast float %2805, %2805
  %2810 = fadd fast float %2808, %2809
  %2811 = call float @dx.op.unary.f32(i32 24, float %2810)  ; Sqrt(value)
  %2812 = fsub fast float %2811, %9
  %2813 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2812)  ; FMax(a,b)
  %2814 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %2814, label %2815, label %2838

; <label>:2815                                    ; preds = %2787
  %2816 = call float @dx.op.unary.f32(i32 6, float %2804)  ; FAbs(value)
  %2817 = fmul fast float %2816, %11
  %2818 = fcmp fast olt float %2817, 0x3F50624DE0000000
  br i1 %2818, label %2819, label %2822

; <label>:2819                                    ; preds = %2815
  %2820 = fmul fast float %2817, 5.000000e-01
  %2821 = fsub fast float 1.000000e+00, %2820
  br label %2827

; <label>:2822                                    ; preds = %2815
  %2823 = fmul fast float %2817, 0xBFF7154760000000
  %2824 = call float @dx.op.unary.f32(i32 21, float %2823)  ; Exp(value)
  %2825 = fsub fast float 1.000000e+00, %2824
  %2826 = fdiv fast float %2825, %2817
  br label %2827

; <label>:2827                                    ; preds = %2822, %2819
  %2828 = phi float [ %2821, %2819 ], [ %2826, %2822 ]
  %2829 = call float @dx.op.binary.f32(i32 36, float %2801, float %18)  ; FMin(a,b)
  %2830 = fsub fast float %2829, %10
  %2831 = fmul fast float %11, %2830
  %2832 = fsub fast float -0.000000e+00, %2831
  %2833 = call float @dx.op.binary.f32(i32 35, float %2832, float -4.000000e+01)  ; FMax(a,b)
  %2834 = call float @dx.op.binary.f32(i32 36, float %2833, float 5.000000e+00)  ; FMin(a,b)
  %2835 = fmul fast float %2834, 0x3FF7154760000000
  %2836 = call float @dx.op.unary.f32(i32 21, float %2835)  ; Exp(value)
  %2837 = fmul fast float %2836, %2828
  br label %2838

; <label>:2838                                    ; preds = %2827, %2787
  %2839 = phi float [ %2837, %2827 ], [ 1.000000e+00, %2787 ]
  %2840 = fmul fast float %2813, %16
  %2841 = fmul fast float %2840, %2839
  %2842 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2841)  ; FMin(a,b)
  %2843 = fmul fast float %2842, 0xBFF7154760000000
  %2844 = call float @dx.op.unary.f32(i32 21, float %2843)  ; Exp(value)
  %2845 = fsub fast float 1.000000e+00, %2844
  %2846 = call float @dx.op.binary.f32(i32 36, float %12, float %2845)  ; FMin(a,b)
  %2847 = fsub fast float %13, %2759
  %2848 = fsub fast float %14, %2760
  %2849 = fsub fast float %15, %2761
  %2850 = fmul fast float %2846, %2847
  %2851 = fmul fast float %2846, %2848
  %2852 = fmul fast float %2846, %2849
  %2853 = fadd fast float %2850, %2759
  %2854 = fadd fast float %2851, %2760
  %2855 = fadd fast float %2852, %2761
  br label %2856

; <label>:2856                                    ; preds = %2838, %2770, %2766
  %2857 = phi float [ %2853, %2838 ], [ %2759, %2770 ], [ %2759, %2766 ]
  %2858 = phi float [ %2854, %2838 ], [ %2760, %2770 ], [ %2760, %2766 ]
  %2859 = phi float [ %2855, %2838 ], [ %2761, %2770 ], [ %2761, %2766 ]
  %2860 = fadd fast float %5, 1.000000e+00
  %2861 = fadd fast float %6, 1.000000e+00
  %2862 = fsub fast float 1.000000e+00, %5
  %2863 = fmul fast float %36, %2860
  %2864 = fmul fast float %36, %2861
  %2865 = fmul fast float %36, %2862
  %2866 = fmul fast float %2863, %2857
  %2867 = fmul fast float %2864, %2858
  %2868 = fmul fast float %2865, %2859
  %2869 = fcmp fast ult float %37, 5.000000e-01
  br i1 %2869, label %2895, label %2870

; <label>:2870                                    ; preds = %2856
  %2871 = fmul fast float %2866, 0x4004147AE0000000
  %2872 = fmul fast float %2867, 0x4004147AE0000000
  %2873 = fmul fast float %2868, 0x4004147AE0000000
  %2874 = fadd fast float %2871, 0x3F9EB851E0000000
  %2875 = fadd fast float %2872, 0x3F9EB851E0000000
  %2876 = fadd fast float %2873, 0x3F9EB851E0000000
  %2877 = fmul fast float %2874, %2866
  %2878 = fmul fast float %2875, %2867
  %2879 = fmul fast float %2876, %2868
  %2880 = fmul fast float %2866, 0x400370A3E0000000
  %2881 = fmul fast float %2867, 0x400370A3E0000000
  %2882 = fmul fast float %2868, 0x400370A3E0000000
  %2883 = fadd fast float %2880, 0x3FE2E147A0000000
  %2884 = fadd fast float %2881, 0x3FE2E147A0000000
  %2885 = fadd fast float %2882, 0x3FE2E147A0000000
  %2886 = fmul fast float %2883, %2866
  %2887 = fmul fast float %2884, %2867
  %2888 = fmul fast float %2885, %2868
  %2889 = fadd fast float %2886, 0x3FC1EB8520000000
  %2890 = fadd fast float %2887, 0x3FC1EB8520000000
  %2891 = fadd fast float %2888, 0x3FC1EB8520000000
  %2892 = fdiv fast float %2877, %2889
  %2893 = fdiv fast float %2878, %2890
  %2894 = fdiv fast float %2879, %2891
  br label %2895

; <label>:2895                                    ; preds = %2870, %2856
  %2896 = phi float [ %2892, %2870 ], [ %2866, %2856 ]
  %2897 = phi float [ %2893, %2870 ], [ %2867, %2856 ]
  %2898 = phi float [ %2894, %2870 ], [ %2868, %2856 ]
  %2899 = call float @dx.op.unary.f32(i32 7, float %2896)  ; Saturate(value)
  %2900 = call float @dx.op.unary.f32(i32 7, float %2897)  ; Saturate(value)
  %2901 = call float @dx.op.unary.f32(i32 7, float %2898)  ; Saturate(value)
  %2902 = call float @dx.op.dot3.f32(i32 55, float %2899, float %2900, float %2901, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2903 = fsub fast float %2899, %2902
  %2904 = fsub fast float %2900, %2902
  %2905 = fsub fast float %2901, %2902
  %2906 = fmul fast float %2903, %8
  %2907 = fmul fast float %2904, %8
  %2908 = fmul fast float %2905, %8
  %2909 = fadd fast float %2906, %2902
  %2910 = fadd fast float %2907, %2902
  %2911 = fadd fast float %2908, %2902
  %2912 = call float @dx.op.unary.f32(i32 7, float %2909)  ; Saturate(value)
  %2913 = call float @dx.op.unary.f32(i32 7, float %2910)  ; Saturate(value)
  %2914 = call float @dx.op.unary.f32(i32 7, float %2911)  ; Saturate(value)
  %2915 = fadd fast float %2912, 0xBFC70A3D80000000
  %2916 = fadd fast float %2913, 0xBFC70A3D80000000
  %2917 = fadd fast float %2914, 0xBFC70A3D80000000
  %2918 = fmul fast float %2915, %7
  %2919 = fmul fast float %2916, %7
  %2920 = fmul fast float %2917, %7
  %2921 = fadd fast float %2918, 0x3FC70A3D80000000
  %2922 = fadd fast float %2919, 0x3FC70A3D80000000
  %2923 = fadd fast float %2920, 0x3FC70A3D80000000
  %2924 = call float @dx.op.unary.f32(i32 7, float %2921)  ; Saturate(value)
  %2925 = call float @dx.op.unary.f32(i32 7, float %2922)  ; Saturate(value)
  %2926 = call float @dx.op.unary.f32(i32 7, float %2923)  ; Saturate(value)
  %2927 = add i32 %70, -1
  %2928 = call i32 @dx.op.binary.i32(i32 37, i32 %63, i32 0)  ; IMax(a,b)
  %2929 = call i32 @dx.op.binary.i32(i32 37, i32 %2927, i32 0)  ; IMax(a,b)
  %2930 = call i32 @dx.op.binary.i32(i32 38, i32 %2928, i32 %59)  ; IMin(a,b)
  %2931 = call i32 @dx.op.binary.i32(i32 38, i32 %2929, i32 %60)  ; IMin(a,b)
  %2932 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2930, i32 %2931, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2933 = extractvalue %dx.types.ResRet.f32 %2932, 0
  %2934 = fsub fast float 1.000000e+00, %86
  %2935 = fmul fast float %2934, 0x3FA99999A0000000
  %2936 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %2935)  ; FMax(a,b)
  %2937 = fsub fast float %2933, %86
  %2938 = call float @dx.op.unary.f32(i32 6, float %2937)  ; FAbs(value)
  %2939 = fdiv fast float %2938, %2936
  %2940 = fsub fast float 1.000000e+00, %2939
  %2941 = call float @dx.op.unary.f32(i32 7, float %2940)  ; Saturate(value)
  %2942 = fcmp fast ugt float %2941, 0.000000e+00
  br i1 %2942, label %2943, label %3164

; <label>:2943                                    ; preds = %2895
  %2944 = call i32 @dx.op.binary.i32(i32 37, i32 %2930, i32 0)  ; IMax(a,b)
  %2945 = call i32 @dx.op.binary.i32(i32 37, i32 %2931, i32 0)  ; IMax(a,b)
  %2946 = call i32 @dx.op.binary.i32(i32 38, i32 %2944, i32 %59)  ; IMin(a,b)
  %2947 = call i32 @dx.op.binary.i32(i32 38, i32 %2945, i32 %60)  ; IMin(a,b)
  %2948 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2946, i32 %2947, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2949 = extractvalue %dx.types.ResRet.f32 %2948, 0
  %2950 = extractvalue %dx.types.ResRet.f32 %2948, 1
  %2951 = extractvalue %dx.types.ResRet.f32 %2948, 2
  %2952 = extractvalue %dx.types.ResRet.f32 %2948, 3
  %2953 = fcmp fast olt float %2952, 0.000000e+00
  br i1 %2953, label %2954, label %2988

; <label>:2954                                    ; preds = %2943
  %2955 = fcmp fast ogt float %2949, 0x3FA4B5DCC0000000
  %2956 = fcmp fast ogt float %2950, 0x3FA4B5DCC0000000
  %2957 = fcmp fast ogt float %2951, 0x3FA4B5DCC0000000
  %2958 = select i1 %2955, float 0.000000e+00, float 1.000000e+00
  %2959 = select i1 %2956, float 0.000000e+00, float 1.000000e+00
  %2960 = select i1 %2957, float 0.000000e+00, float 1.000000e+00
  %2961 = fmul fast float %2949, 0x3FB3D07220000000
  %2962 = fmul fast float %2950, 0x3FB3D07220000000
  %2963 = fmul fast float %2951, 0x3FB3D07220000000
  %2964 = fadd fast float %2949, 0x3FAC28F5C0000000
  %2965 = fadd fast float %2950, 0x3FAC28F5C0000000
  %2966 = fadd fast float %2951, 0x3FAC28F5C0000000
  %2967 = fmul fast float %2964, 0x3FEE54EDE0000000
  %2968 = fmul fast float %2965, 0x3FEE54EDE0000000
  %2969 = fmul fast float %2966, 0x3FEE54EDE0000000
  %2970 = call float @dx.op.unary.f32(i32 23, float %2967)  ; Log(value)
  %2971 = call float @dx.op.unary.f32(i32 23, float %2968)  ; Log(value)
  %2972 = call float @dx.op.unary.f32(i32 23, float %2969)  ; Log(value)
  %2973 = fmul fast float %2970, 0x4003333340000000
  %2974 = fmul fast float %2971, 0x4003333340000000
  %2975 = fmul fast float %2972, 0x4003333340000000
  %2976 = call float @dx.op.unary.f32(i32 21, float %2973)  ; Exp(value)
  %2977 = call float @dx.op.unary.f32(i32 21, float %2974)  ; Exp(value)
  %2978 = call float @dx.op.unary.f32(i32 21, float %2975)  ; Exp(value)
  %2979 = fsub fast float %2961, %2976
  %2980 = fsub fast float %2962, %2977
  %2981 = fsub fast float %2963, %2978
  %2982 = fmul fast float %2979, %2958
  %2983 = fmul fast float %2980, %2959
  %2984 = fmul fast float %2981, %2960
  %2985 = fadd fast float %2982, %2976
  %2986 = fadd fast float %2983, %2977
  %2987 = fadd fast float %2984, %2978
  br label %3151

; <label>:2988                                    ; preds = %2943
  %2989 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2946, i32 %2947, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2990 = extractvalue %dx.types.ResRet.f32 %2989, 0
  %2991 = fcmp fast ogt float %38, 5.000000e-01
  %2992 = fcmp fast olt float %2990, 1.000000e+00
  %2993 = and i1 %2991, %2992
  br i1 %2993, label %2994, label %3080

; <label>:2994                                    ; preds = %2988
  %2995 = sitofp i32 %2946 to float
  %2996 = sitofp i32 %2947 to float
  %2997 = fadd fast float %2995, 5.000000e-01
  %2998 = fadd fast float %2996, 5.000000e-01
  %2999 = fdiv fast float %2997, %45
  %3000 = fdiv fast float %2998, %46
  %3001 = fmul fast float %2999, 2.000000e+00
  %3002 = fmul fast float %3000, 2.000000e+00
  %3003 = fadd fast float %3001, -1.000000e+00
  %3004 = fsub fast float 1.000000e+00, %3002
  %3005 = fmul fast float %3003, %35
  %3006 = call float @dx.op.tertiary.f32(i32 46, float %3004, float %31, float %3005)  ; FMad(a,b,c)
  %3007 = call float @dx.op.tertiary.f32(i32 46, float %2990, float %27, float %3006)  ; FMad(a,b,c)
  %3008 = fadd fast float %3007, %23
  %3009 = call float @dx.op.unary.f32(i32 6, float %3008)  ; FAbs(value)
  %3010 = fcmp fast ogt float %3009, 0x3EB0C6F7A0000000
  br i1 %3010, label %3011, label %3080

; <label>:3011                                    ; preds = %2994
  %3012 = fmul fast float %3003, %34
  %3013 = call float @dx.op.tertiary.f32(i32 46, float %3004, float %30, float %3012)  ; FMad(a,b,c)
  %3014 = call float @dx.op.tertiary.f32(i32 46, float %2990, float %26, float %3013)  ; FMad(a,b,c)
  %3015 = fadd fast float %3014, %22
  %3016 = fmul fast float %3003, %33
  %3017 = call float @dx.op.tertiary.f32(i32 46, float %3004, float %29, float %3016)  ; FMad(a,b,c)
  %3018 = call float @dx.op.tertiary.f32(i32 46, float %2990, float %25, float %3017)  ; FMad(a,b,c)
  %3019 = fadd fast float %3018, %21
  %3020 = fmul fast float %3003, %32
  %3021 = call float @dx.op.tertiary.f32(i32 46, float %3004, float %28, float %3020)  ; FMad(a,b,c)
  %3022 = call float @dx.op.tertiary.f32(i32 46, float %2990, float %24, float %3021)  ; FMad(a,b,c)
  %3023 = fadd fast float %3022, %20
  %3024 = fdiv fast float %3023, %3008
  %3025 = fdiv fast float %3019, %3008
  %3026 = fdiv fast float %3015, %3008
  %3027 = fsub fast float %3024, %17
  %3028 = fsub fast float %3025, %18
  %3029 = fsub fast float %3026, %19
  %3030 = fmul fast float %3027, %3027
  %3031 = fmul fast float %3028, %3028
  %3032 = fadd fast float %3031, %3030
  %3033 = fmul fast float %3029, %3029
  %3034 = fadd fast float %3032, %3033
  %3035 = call float @dx.op.unary.f32(i32 24, float %3034)  ; Sqrt(value)
  %3036 = fsub fast float %3035, %9
  %3037 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3036)  ; FMax(a,b)
  %3038 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %3038, label %3039, label %3062

; <label>:3039                                    ; preds = %3011
  %3040 = call float @dx.op.unary.f32(i32 6, float %3028)  ; FAbs(value)
  %3041 = fmul fast float %3040, %11
  %3042 = fcmp fast olt float %3041, 0x3F50624DE0000000
  br i1 %3042, label %3043, label %3046

; <label>:3043                                    ; preds = %3039
  %3044 = fmul fast float %3041, 5.000000e-01
  %3045 = fsub fast float 1.000000e+00, %3044
  br label %3051

; <label>:3046                                    ; preds = %3039
  %3047 = fmul fast float %3041, 0xBFF7154760000000
  %3048 = call float @dx.op.unary.f32(i32 21, float %3047)  ; Exp(value)
  %3049 = fsub fast float 1.000000e+00, %3048
  %3050 = fdiv fast float %3049, %3041
  br label %3051

; <label>:3051                                    ; preds = %3046, %3043
  %3052 = phi float [ %3045, %3043 ], [ %3050, %3046 ]
  %3053 = call float @dx.op.binary.f32(i32 36, float %3025, float %18)  ; FMin(a,b)
  %3054 = fsub fast float %3053, %10
  %3055 = fmul fast float %11, %3054
  %3056 = fsub fast float -0.000000e+00, %3055
  %3057 = call float @dx.op.binary.f32(i32 35, float %3056, float -4.000000e+01)  ; FMax(a,b)
  %3058 = call float @dx.op.binary.f32(i32 36, float %3057, float 5.000000e+00)  ; FMin(a,b)
  %3059 = fmul fast float %3058, 0x3FF7154760000000
  %3060 = call float @dx.op.unary.f32(i32 21, float %3059)  ; Exp(value)
  %3061 = fmul fast float %3060, %3052
  br label %3062

; <label>:3062                                    ; preds = %3051, %3011
  %3063 = phi float [ %3061, %3051 ], [ 1.000000e+00, %3011 ]
  %3064 = fmul fast float %3037, %16
  %3065 = fmul fast float %3064, %3063
  %3066 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3065)  ; FMin(a,b)
  %3067 = fmul fast float %3066, 0xBFF7154760000000
  %3068 = call float @dx.op.unary.f32(i32 21, float %3067)  ; Exp(value)
  %3069 = fsub fast float 1.000000e+00, %3068
  %3070 = call float @dx.op.binary.f32(i32 36, float %12, float %3069)  ; FMin(a,b)
  %3071 = fsub fast float %13, %2949
  %3072 = fsub fast float %14, %2950
  %3073 = fsub fast float %15, %2951
  %3074 = fmul fast float %3070, %3071
  %3075 = fmul fast float %3070, %3072
  %3076 = fmul fast float %3070, %3073
  %3077 = fadd fast float %3074, %2949
  %3078 = fadd fast float %3075, %2950
  %3079 = fadd fast float %3076, %2951
  br label %3080

; <label>:3080                                    ; preds = %3062, %2994, %2988
  %3081 = phi float [ %3077, %3062 ], [ %2949, %2994 ], [ %2949, %2988 ]
  %3082 = phi float [ %3078, %3062 ], [ %2950, %2994 ], [ %2950, %2988 ]
  %3083 = phi float [ %3079, %3062 ], [ %2951, %2994 ], [ %2951, %2988 ]
  %3084 = fadd fast float %5, 1.000000e+00
  %3085 = fadd fast float %6, 1.000000e+00
  %3086 = fsub fast float 1.000000e+00, %5
  %3087 = fmul fast float %36, %3084
  %3088 = fmul fast float %36, %3085
  %3089 = fmul fast float %36, %3086
  %3090 = fmul fast float %3087, %3081
  %3091 = fmul fast float %3088, %3082
  %3092 = fmul fast float %3089, %3083
  %3093 = fcmp fast ult float %37, 5.000000e-01
  br i1 %3093, label %3119, label %3094

; <label>:3094                                    ; preds = %3080
  %3095 = fmul fast float %3090, 0x4004147AE0000000
  %3096 = fmul fast float %3091, 0x4004147AE0000000
  %3097 = fmul fast float %3092, 0x4004147AE0000000
  %3098 = fadd fast float %3095, 0x3F9EB851E0000000
  %3099 = fadd fast float %3096, 0x3F9EB851E0000000
  %3100 = fadd fast float %3097, 0x3F9EB851E0000000
  %3101 = fmul fast float %3098, %3090
  %3102 = fmul fast float %3099, %3091
  %3103 = fmul fast float %3100, %3092
  %3104 = fmul fast float %3090, 0x400370A3E0000000
  %3105 = fmul fast float %3091, 0x400370A3E0000000
  %3106 = fmul fast float %3092, 0x400370A3E0000000
  %3107 = fadd fast float %3104, 0x3FE2E147A0000000
  %3108 = fadd fast float %3105, 0x3FE2E147A0000000
  %3109 = fadd fast float %3106, 0x3FE2E147A0000000
  %3110 = fmul fast float %3107, %3090
  %3111 = fmul fast float %3108, %3091
  %3112 = fmul fast float %3109, %3092
  %3113 = fadd fast float %3110, 0x3FC1EB8520000000
  %3114 = fadd fast float %3111, 0x3FC1EB8520000000
  %3115 = fadd fast float %3112, 0x3FC1EB8520000000
  %3116 = fdiv fast float %3101, %3113
  %3117 = fdiv fast float %3102, %3114
  %3118 = fdiv fast float %3103, %3115
  br label %3119

; <label>:3119                                    ; preds = %3094, %3080
  %3120 = phi float [ %3116, %3094 ], [ %3090, %3080 ]
  %3121 = phi float [ %3117, %3094 ], [ %3091, %3080 ]
  %3122 = phi float [ %3118, %3094 ], [ %3092, %3080 ]
  %3123 = call float @dx.op.unary.f32(i32 7, float %3120)  ; Saturate(value)
  %3124 = call float @dx.op.unary.f32(i32 7, float %3121)  ; Saturate(value)
  %3125 = call float @dx.op.unary.f32(i32 7, float %3122)  ; Saturate(value)
  %3126 = call float @dx.op.dot3.f32(i32 55, float %3123, float %3124, float %3125, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3127 = fsub fast float %3123, %3126
  %3128 = fsub fast float %3124, %3126
  %3129 = fsub fast float %3125, %3126
  %3130 = fmul fast float %3127, %8
  %3131 = fmul fast float %3128, %8
  %3132 = fmul fast float %3129, %8
  %3133 = fadd fast float %3130, %3126
  %3134 = fadd fast float %3131, %3126
  %3135 = fadd fast float %3132, %3126
  %3136 = call float @dx.op.unary.f32(i32 7, float %3133)  ; Saturate(value)
  %3137 = call float @dx.op.unary.f32(i32 7, float %3134)  ; Saturate(value)
  %3138 = call float @dx.op.unary.f32(i32 7, float %3135)  ; Saturate(value)
  %3139 = fadd fast float %3136, 0xBFC70A3D80000000
  %3140 = fadd fast float %3137, 0xBFC70A3D80000000
  %3141 = fadd fast float %3138, 0xBFC70A3D80000000
  %3142 = fmul fast float %3139, %7
  %3143 = fmul fast float %3140, %7
  %3144 = fmul fast float %3141, %7
  %3145 = fadd fast float %3142, 0x3FC70A3D80000000
  %3146 = fadd fast float %3143, 0x3FC70A3D80000000
  %3147 = fadd fast float %3144, 0x3FC70A3D80000000
  %3148 = call float @dx.op.unary.f32(i32 7, float %3145)  ; Saturate(value)
  %3149 = call float @dx.op.unary.f32(i32 7, float %3146)  ; Saturate(value)
  %3150 = call float @dx.op.unary.f32(i32 7, float %3147)  ; Saturate(value)
  br label %3151

; <label>:3151                                    ; preds = %3119, %2954
  %3152 = phi float [ %2985, %2954 ], [ %3148, %3119 ]
  %3153 = phi float [ %2986, %2954 ], [ %3149, %3119 ]
  %3154 = phi float [ %2987, %2954 ], [ %3150, %3119 ]
  %3155 = fsub fast float %3152, %2924
  %3156 = fsub fast float %3153, %2925
  %3157 = fsub fast float %3154, %2926
  %3158 = fmul fast float %3155, %2941
  %3159 = fmul fast float %3156, %2941
  %3160 = fmul fast float %3157, %2941
  %3161 = fadd fast float %3158, %2924
  %3162 = fadd fast float %3159, %2925
  %3163 = fadd fast float %3160, %2926
  br label %3164

; <label>:3164                                    ; preds = %3151, %2895
  %3165 = phi float [ %3161, %3151 ], [ %2924, %2895 ]
  %3166 = phi float [ %3162, %3151 ], [ %2925, %2895 ]
  %3167 = phi float [ %3163, %3151 ], [ %2926, %2895 ]
  %3168 = add i32 %70, 1
  %3169 = call i32 @dx.op.binary.i32(i32 37, i32 %3168, i32 0)  ; IMax(a,b)
  %3170 = call i32 @dx.op.binary.i32(i32 38, i32 %3169, i32 %60)  ; IMin(a,b)
  %3171 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2930, i32 %3170, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3172 = extractvalue %dx.types.ResRet.f32 %3171, 0
  %3173 = fsub fast float %3172, %86
  %3174 = call float @dx.op.unary.f32(i32 6, float %3173)  ; FAbs(value)
  %3175 = fdiv fast float %3174, %2936
  %3176 = fsub fast float 1.000000e+00, %3175
  %3177 = call float @dx.op.unary.f32(i32 7, float %3176)  ; Saturate(value)
  %3178 = fcmp fast ugt float %3177, 0.000000e+00
  br i1 %3178, label %3179, label %3400

; <label>:3179                                    ; preds = %3164
  %3180 = call i32 @dx.op.binary.i32(i32 37, i32 %2930, i32 0)  ; IMax(a,b)
  %3181 = call i32 @dx.op.binary.i32(i32 37, i32 %3170, i32 0)  ; IMax(a,b)
  %3182 = call i32 @dx.op.binary.i32(i32 38, i32 %3180, i32 %59)  ; IMin(a,b)
  %3183 = call i32 @dx.op.binary.i32(i32 38, i32 %3181, i32 %60)  ; IMin(a,b)
  %3184 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3182, i32 %3183, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3185 = extractvalue %dx.types.ResRet.f32 %3184, 0
  %3186 = extractvalue %dx.types.ResRet.f32 %3184, 1
  %3187 = extractvalue %dx.types.ResRet.f32 %3184, 2
  %3188 = extractvalue %dx.types.ResRet.f32 %3184, 3
  %3189 = fcmp fast olt float %3188, 0.000000e+00
  br i1 %3189, label %3190, label %3224

; <label>:3190                                    ; preds = %3179
  %3191 = fcmp fast ogt float %3185, 0x3FA4B5DCC0000000
  %3192 = fcmp fast ogt float %3186, 0x3FA4B5DCC0000000
  %3193 = fcmp fast ogt float %3187, 0x3FA4B5DCC0000000
  %3194 = select i1 %3191, float 0.000000e+00, float 1.000000e+00
  %3195 = select i1 %3192, float 0.000000e+00, float 1.000000e+00
  %3196 = select i1 %3193, float 0.000000e+00, float 1.000000e+00
  %3197 = fmul fast float %3185, 0x3FB3D07220000000
  %3198 = fmul fast float %3186, 0x3FB3D07220000000
  %3199 = fmul fast float %3187, 0x3FB3D07220000000
  %3200 = fadd fast float %3185, 0x3FAC28F5C0000000
  %3201 = fadd fast float %3186, 0x3FAC28F5C0000000
  %3202 = fadd fast float %3187, 0x3FAC28F5C0000000
  %3203 = fmul fast float %3200, 0x3FEE54EDE0000000
  %3204 = fmul fast float %3201, 0x3FEE54EDE0000000
  %3205 = fmul fast float %3202, 0x3FEE54EDE0000000
  %3206 = call float @dx.op.unary.f32(i32 23, float %3203)  ; Log(value)
  %3207 = call float @dx.op.unary.f32(i32 23, float %3204)  ; Log(value)
  %3208 = call float @dx.op.unary.f32(i32 23, float %3205)  ; Log(value)
  %3209 = fmul fast float %3206, 0x4003333340000000
  %3210 = fmul fast float %3207, 0x4003333340000000
  %3211 = fmul fast float %3208, 0x4003333340000000
  %3212 = call float @dx.op.unary.f32(i32 21, float %3209)  ; Exp(value)
  %3213 = call float @dx.op.unary.f32(i32 21, float %3210)  ; Exp(value)
  %3214 = call float @dx.op.unary.f32(i32 21, float %3211)  ; Exp(value)
  %3215 = fsub fast float %3197, %3212
  %3216 = fsub fast float %3198, %3213
  %3217 = fsub fast float %3199, %3214
  %3218 = fmul fast float %3215, %3194
  %3219 = fmul fast float %3216, %3195
  %3220 = fmul fast float %3217, %3196
  %3221 = fadd fast float %3218, %3212
  %3222 = fadd fast float %3219, %3213
  %3223 = fadd fast float %3220, %3214
  br label %3387

; <label>:3224                                    ; preds = %3179
  %3225 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3182, i32 %3183, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3226 = extractvalue %dx.types.ResRet.f32 %3225, 0
  %3227 = fcmp fast ogt float %38, 5.000000e-01
  %3228 = fcmp fast olt float %3226, 1.000000e+00
  %3229 = and i1 %3227, %3228
  br i1 %3229, label %3230, label %3316

; <label>:3230                                    ; preds = %3224
  %3231 = sitofp i32 %3182 to float
  %3232 = sitofp i32 %3183 to float
  %3233 = fadd fast float %3231, 5.000000e-01
  %3234 = fadd fast float %3232, 5.000000e-01
  %3235 = fdiv fast float %3233, %45
  %3236 = fdiv fast float %3234, %46
  %3237 = fmul fast float %3235, 2.000000e+00
  %3238 = fmul fast float %3236, 2.000000e+00
  %3239 = fadd fast float %3237, -1.000000e+00
  %3240 = fsub fast float 1.000000e+00, %3238
  %3241 = fmul fast float %3239, %35
  %3242 = call float @dx.op.tertiary.f32(i32 46, float %3240, float %31, float %3241)  ; FMad(a,b,c)
  %3243 = call float @dx.op.tertiary.f32(i32 46, float %3226, float %27, float %3242)  ; FMad(a,b,c)
  %3244 = fadd fast float %3243, %23
  %3245 = call float @dx.op.unary.f32(i32 6, float %3244)  ; FAbs(value)
  %3246 = fcmp fast ogt float %3245, 0x3EB0C6F7A0000000
  br i1 %3246, label %3247, label %3316

; <label>:3247                                    ; preds = %3230
  %3248 = fmul fast float %3239, %34
  %3249 = call float @dx.op.tertiary.f32(i32 46, float %3240, float %30, float %3248)  ; FMad(a,b,c)
  %3250 = call float @dx.op.tertiary.f32(i32 46, float %3226, float %26, float %3249)  ; FMad(a,b,c)
  %3251 = fadd fast float %3250, %22
  %3252 = fmul fast float %3239, %33
  %3253 = call float @dx.op.tertiary.f32(i32 46, float %3240, float %29, float %3252)  ; FMad(a,b,c)
  %3254 = call float @dx.op.tertiary.f32(i32 46, float %3226, float %25, float %3253)  ; FMad(a,b,c)
  %3255 = fadd fast float %3254, %21
  %3256 = fmul fast float %3239, %32
  %3257 = call float @dx.op.tertiary.f32(i32 46, float %3240, float %28, float %3256)  ; FMad(a,b,c)
  %3258 = call float @dx.op.tertiary.f32(i32 46, float %3226, float %24, float %3257)  ; FMad(a,b,c)
  %3259 = fadd fast float %3258, %20
  %3260 = fdiv fast float %3259, %3244
  %3261 = fdiv fast float %3255, %3244
  %3262 = fdiv fast float %3251, %3244
  %3263 = fsub fast float %3260, %17
  %3264 = fsub fast float %3261, %18
  %3265 = fsub fast float %3262, %19
  %3266 = fmul fast float %3263, %3263
  %3267 = fmul fast float %3264, %3264
  %3268 = fadd fast float %3267, %3266
  %3269 = fmul fast float %3265, %3265
  %3270 = fadd fast float %3268, %3269
  %3271 = call float @dx.op.unary.f32(i32 24, float %3270)  ; Sqrt(value)
  %3272 = fsub fast float %3271, %9
  %3273 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3272)  ; FMax(a,b)
  %3274 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %3274, label %3275, label %3298

; <label>:3275                                    ; preds = %3247
  %3276 = call float @dx.op.unary.f32(i32 6, float %3264)  ; FAbs(value)
  %3277 = fmul fast float %3276, %11
  %3278 = fcmp fast olt float %3277, 0x3F50624DE0000000
  br i1 %3278, label %3279, label %3282

; <label>:3279                                    ; preds = %3275
  %3280 = fmul fast float %3277, 5.000000e-01
  %3281 = fsub fast float 1.000000e+00, %3280
  br label %3287

; <label>:3282                                    ; preds = %3275
  %3283 = fmul fast float %3277, 0xBFF7154760000000
  %3284 = call float @dx.op.unary.f32(i32 21, float %3283)  ; Exp(value)
  %3285 = fsub fast float 1.000000e+00, %3284
  %3286 = fdiv fast float %3285, %3277
  br label %3287

; <label>:3287                                    ; preds = %3282, %3279
  %3288 = phi float [ %3281, %3279 ], [ %3286, %3282 ]
  %3289 = call float @dx.op.binary.f32(i32 36, float %3261, float %18)  ; FMin(a,b)
  %3290 = fsub fast float %3289, %10
  %3291 = fmul fast float %11, %3290
  %3292 = fsub fast float -0.000000e+00, %3291
  %3293 = call float @dx.op.binary.f32(i32 35, float %3292, float -4.000000e+01)  ; FMax(a,b)
  %3294 = call float @dx.op.binary.f32(i32 36, float %3293, float 5.000000e+00)  ; FMin(a,b)
  %3295 = fmul fast float %3294, 0x3FF7154760000000
  %3296 = call float @dx.op.unary.f32(i32 21, float %3295)  ; Exp(value)
  %3297 = fmul fast float %3296, %3288
  br label %3298

; <label>:3298                                    ; preds = %3287, %3247
  %3299 = phi float [ %3297, %3287 ], [ 1.000000e+00, %3247 ]
  %3300 = fmul fast float %3273, %16
  %3301 = fmul fast float %3300, %3299
  %3302 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3301)  ; FMin(a,b)
  %3303 = fmul fast float %3302, 0xBFF7154760000000
  %3304 = call float @dx.op.unary.f32(i32 21, float %3303)  ; Exp(value)
  %3305 = fsub fast float 1.000000e+00, %3304
  %3306 = call float @dx.op.binary.f32(i32 36, float %12, float %3305)  ; FMin(a,b)
  %3307 = fsub fast float %13, %3185
  %3308 = fsub fast float %14, %3186
  %3309 = fsub fast float %15, %3187
  %3310 = fmul fast float %3306, %3307
  %3311 = fmul fast float %3306, %3308
  %3312 = fmul fast float %3306, %3309
  %3313 = fadd fast float %3310, %3185
  %3314 = fadd fast float %3311, %3186
  %3315 = fadd fast float %3312, %3187
  br label %3316

; <label>:3316                                    ; preds = %3298, %3230, %3224
  %3317 = phi float [ %3313, %3298 ], [ %3185, %3230 ], [ %3185, %3224 ]
  %3318 = phi float [ %3314, %3298 ], [ %3186, %3230 ], [ %3186, %3224 ]
  %3319 = phi float [ %3315, %3298 ], [ %3187, %3230 ], [ %3187, %3224 ]
  %3320 = fadd fast float %5, 1.000000e+00
  %3321 = fadd fast float %6, 1.000000e+00
  %3322 = fsub fast float 1.000000e+00, %5
  %3323 = fmul fast float %36, %3320
  %3324 = fmul fast float %36, %3321
  %3325 = fmul fast float %36, %3322
  %3326 = fmul fast float %3323, %3317
  %3327 = fmul fast float %3324, %3318
  %3328 = fmul fast float %3325, %3319
  %3329 = fcmp fast ult float %37, 5.000000e-01
  br i1 %3329, label %3355, label %3330

; <label>:3330                                    ; preds = %3316
  %3331 = fmul fast float %3326, 0x4004147AE0000000
  %3332 = fmul fast float %3327, 0x4004147AE0000000
  %3333 = fmul fast float %3328, 0x4004147AE0000000
  %3334 = fadd fast float %3331, 0x3F9EB851E0000000
  %3335 = fadd fast float %3332, 0x3F9EB851E0000000
  %3336 = fadd fast float %3333, 0x3F9EB851E0000000
  %3337 = fmul fast float %3334, %3326
  %3338 = fmul fast float %3335, %3327
  %3339 = fmul fast float %3336, %3328
  %3340 = fmul fast float %3326, 0x400370A3E0000000
  %3341 = fmul fast float %3327, 0x400370A3E0000000
  %3342 = fmul fast float %3328, 0x400370A3E0000000
  %3343 = fadd fast float %3340, 0x3FE2E147A0000000
  %3344 = fadd fast float %3341, 0x3FE2E147A0000000
  %3345 = fadd fast float %3342, 0x3FE2E147A0000000
  %3346 = fmul fast float %3343, %3326
  %3347 = fmul fast float %3344, %3327
  %3348 = fmul fast float %3345, %3328
  %3349 = fadd fast float %3346, 0x3FC1EB8520000000
  %3350 = fadd fast float %3347, 0x3FC1EB8520000000
  %3351 = fadd fast float %3348, 0x3FC1EB8520000000
  %3352 = fdiv fast float %3337, %3349
  %3353 = fdiv fast float %3338, %3350
  %3354 = fdiv fast float %3339, %3351
  br label %3355

; <label>:3355                                    ; preds = %3330, %3316
  %3356 = phi float [ %3352, %3330 ], [ %3326, %3316 ]
  %3357 = phi float [ %3353, %3330 ], [ %3327, %3316 ]
  %3358 = phi float [ %3354, %3330 ], [ %3328, %3316 ]
  %3359 = call float @dx.op.unary.f32(i32 7, float %3356)  ; Saturate(value)
  %3360 = call float @dx.op.unary.f32(i32 7, float %3357)  ; Saturate(value)
  %3361 = call float @dx.op.unary.f32(i32 7, float %3358)  ; Saturate(value)
  %3362 = call float @dx.op.dot3.f32(i32 55, float %3359, float %3360, float %3361, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3363 = fsub fast float %3359, %3362
  %3364 = fsub fast float %3360, %3362
  %3365 = fsub fast float %3361, %3362
  %3366 = fmul fast float %3363, %8
  %3367 = fmul fast float %3364, %8
  %3368 = fmul fast float %3365, %8
  %3369 = fadd fast float %3366, %3362
  %3370 = fadd fast float %3367, %3362
  %3371 = fadd fast float %3368, %3362
  %3372 = call float @dx.op.unary.f32(i32 7, float %3369)  ; Saturate(value)
  %3373 = call float @dx.op.unary.f32(i32 7, float %3370)  ; Saturate(value)
  %3374 = call float @dx.op.unary.f32(i32 7, float %3371)  ; Saturate(value)
  %3375 = fadd fast float %3372, 0xBFC70A3D80000000
  %3376 = fadd fast float %3373, 0xBFC70A3D80000000
  %3377 = fadd fast float %3374, 0xBFC70A3D80000000
  %3378 = fmul fast float %3375, %7
  %3379 = fmul fast float %3376, %7
  %3380 = fmul fast float %3377, %7
  %3381 = fadd fast float %3378, 0x3FC70A3D80000000
  %3382 = fadd fast float %3379, 0x3FC70A3D80000000
  %3383 = fadd fast float %3380, 0x3FC70A3D80000000
  %3384 = call float @dx.op.unary.f32(i32 7, float %3381)  ; Saturate(value)
  %3385 = call float @dx.op.unary.f32(i32 7, float %3382)  ; Saturate(value)
  %3386 = call float @dx.op.unary.f32(i32 7, float %3383)  ; Saturate(value)
  br label %3387

; <label>:3387                                    ; preds = %3355, %3190
  %3388 = phi float [ %3221, %3190 ], [ %3384, %3355 ]
  %3389 = phi float [ %3222, %3190 ], [ %3385, %3355 ]
  %3390 = phi float [ %3223, %3190 ], [ %3386, %3355 ]
  %3391 = fsub fast float %3388, %2924
  %3392 = fsub fast float %3389, %2925
  %3393 = fsub fast float %3390, %2926
  %3394 = fmul fast float %3391, %3177
  %3395 = fmul fast float %3392, %3177
  %3396 = fmul fast float %3393, %3177
  %3397 = fadd fast float %3394, %2924
  %3398 = fadd fast float %3395, %2925
  %3399 = fadd fast float %3396, %2926
  br label %3400

; <label>:3400                                    ; preds = %3387, %3164
  %3401 = phi float [ %3397, %3387 ], [ %2924, %3164 ]
  %3402 = phi float [ %3398, %3387 ], [ %2925, %3164 ]
  %3403 = phi float [ %3399, %3387 ], [ %2926, %3164 ]
  %3404 = add i32 %63, -1
  %3405 = call i32 @dx.op.binary.i32(i32 37, i32 %3404, i32 0)  ; IMax(a,b)
  %3406 = call i32 @dx.op.binary.i32(i32 37, i32 %70, i32 0)  ; IMax(a,b)
  %3407 = call i32 @dx.op.binary.i32(i32 38, i32 %3405, i32 %59)  ; IMin(a,b)
  %3408 = call i32 @dx.op.binary.i32(i32 38, i32 %3406, i32 %60)  ; IMin(a,b)
  %3409 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3407, i32 %3408, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3410 = extractvalue %dx.types.ResRet.f32 %3409, 0
  %3411 = fsub fast float %3410, %86
  %3412 = call float @dx.op.unary.f32(i32 6, float %3411)  ; FAbs(value)
  %3413 = fdiv fast float %3412, %2936
  %3414 = fsub fast float 1.000000e+00, %3413
  %3415 = call float @dx.op.unary.f32(i32 7, float %3414)  ; Saturate(value)
  %3416 = fcmp fast ugt float %3415, 0.000000e+00
  br i1 %3416, label %3417, label %3638

; <label>:3417                                    ; preds = %3400
  %3418 = call i32 @dx.op.binary.i32(i32 37, i32 %3407, i32 0)  ; IMax(a,b)
  %3419 = call i32 @dx.op.binary.i32(i32 37, i32 %3408, i32 0)  ; IMax(a,b)
  %3420 = call i32 @dx.op.binary.i32(i32 38, i32 %3418, i32 %59)  ; IMin(a,b)
  %3421 = call i32 @dx.op.binary.i32(i32 38, i32 %3419, i32 %60)  ; IMin(a,b)
  %3422 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3420, i32 %3421, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3423 = extractvalue %dx.types.ResRet.f32 %3422, 0
  %3424 = extractvalue %dx.types.ResRet.f32 %3422, 1
  %3425 = extractvalue %dx.types.ResRet.f32 %3422, 2
  %3426 = extractvalue %dx.types.ResRet.f32 %3422, 3
  %3427 = fcmp fast olt float %3426, 0.000000e+00
  br i1 %3427, label %3428, label %3462

; <label>:3428                                    ; preds = %3417
  %3429 = fcmp fast ogt float %3423, 0x3FA4B5DCC0000000
  %3430 = fcmp fast ogt float %3424, 0x3FA4B5DCC0000000
  %3431 = fcmp fast ogt float %3425, 0x3FA4B5DCC0000000
  %3432 = select i1 %3429, float 0.000000e+00, float 1.000000e+00
  %3433 = select i1 %3430, float 0.000000e+00, float 1.000000e+00
  %3434 = select i1 %3431, float 0.000000e+00, float 1.000000e+00
  %3435 = fmul fast float %3423, 0x3FB3D07220000000
  %3436 = fmul fast float %3424, 0x3FB3D07220000000
  %3437 = fmul fast float %3425, 0x3FB3D07220000000
  %3438 = fadd fast float %3423, 0x3FAC28F5C0000000
  %3439 = fadd fast float %3424, 0x3FAC28F5C0000000
  %3440 = fadd fast float %3425, 0x3FAC28F5C0000000
  %3441 = fmul fast float %3438, 0x3FEE54EDE0000000
  %3442 = fmul fast float %3439, 0x3FEE54EDE0000000
  %3443 = fmul fast float %3440, 0x3FEE54EDE0000000
  %3444 = call float @dx.op.unary.f32(i32 23, float %3441)  ; Log(value)
  %3445 = call float @dx.op.unary.f32(i32 23, float %3442)  ; Log(value)
  %3446 = call float @dx.op.unary.f32(i32 23, float %3443)  ; Log(value)
  %3447 = fmul fast float %3444, 0x4003333340000000
  %3448 = fmul fast float %3445, 0x4003333340000000
  %3449 = fmul fast float %3446, 0x4003333340000000
  %3450 = call float @dx.op.unary.f32(i32 21, float %3447)  ; Exp(value)
  %3451 = call float @dx.op.unary.f32(i32 21, float %3448)  ; Exp(value)
  %3452 = call float @dx.op.unary.f32(i32 21, float %3449)  ; Exp(value)
  %3453 = fsub fast float %3435, %3450
  %3454 = fsub fast float %3436, %3451
  %3455 = fsub fast float %3437, %3452
  %3456 = fmul fast float %3453, %3432
  %3457 = fmul fast float %3454, %3433
  %3458 = fmul fast float %3455, %3434
  %3459 = fadd fast float %3456, %3450
  %3460 = fadd fast float %3457, %3451
  %3461 = fadd fast float %3458, %3452
  br label %3625

; <label>:3462                                    ; preds = %3417
  %3463 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3420, i32 %3421, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3464 = extractvalue %dx.types.ResRet.f32 %3463, 0
  %3465 = fcmp fast ogt float %38, 5.000000e-01
  %3466 = fcmp fast olt float %3464, 1.000000e+00
  %3467 = and i1 %3465, %3466
  br i1 %3467, label %3468, label %3554

; <label>:3468                                    ; preds = %3462
  %3469 = sitofp i32 %3420 to float
  %3470 = sitofp i32 %3421 to float
  %3471 = fadd fast float %3469, 5.000000e-01
  %3472 = fadd fast float %3470, 5.000000e-01
  %3473 = fdiv fast float %3471, %45
  %3474 = fdiv fast float %3472, %46
  %3475 = fmul fast float %3473, 2.000000e+00
  %3476 = fmul fast float %3474, 2.000000e+00
  %3477 = fadd fast float %3475, -1.000000e+00
  %3478 = fsub fast float 1.000000e+00, %3476
  %3479 = fmul fast float %3477, %35
  %3480 = call float @dx.op.tertiary.f32(i32 46, float %3478, float %31, float %3479)  ; FMad(a,b,c)
  %3481 = call float @dx.op.tertiary.f32(i32 46, float %3464, float %27, float %3480)  ; FMad(a,b,c)
  %3482 = fadd fast float %3481, %23
  %3483 = call float @dx.op.unary.f32(i32 6, float %3482)  ; FAbs(value)
  %3484 = fcmp fast ogt float %3483, 0x3EB0C6F7A0000000
  br i1 %3484, label %3485, label %3554

; <label>:3485                                    ; preds = %3468
  %3486 = fmul fast float %3477, %34
  %3487 = call float @dx.op.tertiary.f32(i32 46, float %3478, float %30, float %3486)  ; FMad(a,b,c)
  %3488 = call float @dx.op.tertiary.f32(i32 46, float %3464, float %26, float %3487)  ; FMad(a,b,c)
  %3489 = fadd fast float %3488, %22
  %3490 = fmul fast float %3477, %33
  %3491 = call float @dx.op.tertiary.f32(i32 46, float %3478, float %29, float %3490)  ; FMad(a,b,c)
  %3492 = call float @dx.op.tertiary.f32(i32 46, float %3464, float %25, float %3491)  ; FMad(a,b,c)
  %3493 = fadd fast float %3492, %21
  %3494 = fmul fast float %3477, %32
  %3495 = call float @dx.op.tertiary.f32(i32 46, float %3478, float %28, float %3494)  ; FMad(a,b,c)
  %3496 = call float @dx.op.tertiary.f32(i32 46, float %3464, float %24, float %3495)  ; FMad(a,b,c)
  %3497 = fadd fast float %3496, %20
  %3498 = fdiv fast float %3497, %3482
  %3499 = fdiv fast float %3493, %3482
  %3500 = fdiv fast float %3489, %3482
  %3501 = fsub fast float %3498, %17
  %3502 = fsub fast float %3499, %18
  %3503 = fsub fast float %3500, %19
  %3504 = fmul fast float %3501, %3501
  %3505 = fmul fast float %3502, %3502
  %3506 = fadd fast float %3505, %3504
  %3507 = fmul fast float %3503, %3503
  %3508 = fadd fast float %3506, %3507
  %3509 = call float @dx.op.unary.f32(i32 24, float %3508)  ; Sqrt(value)
  %3510 = fsub fast float %3509, %9
  %3511 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3510)  ; FMax(a,b)
  %3512 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %3512, label %3513, label %3536

; <label>:3513                                    ; preds = %3485
  %3514 = call float @dx.op.unary.f32(i32 6, float %3502)  ; FAbs(value)
  %3515 = fmul fast float %3514, %11
  %3516 = fcmp fast olt float %3515, 0x3F50624DE0000000
  br i1 %3516, label %3517, label %3520

; <label>:3517                                    ; preds = %3513
  %3518 = fmul fast float %3515, 5.000000e-01
  %3519 = fsub fast float 1.000000e+00, %3518
  br label %3525

; <label>:3520                                    ; preds = %3513
  %3521 = fmul fast float %3515, 0xBFF7154760000000
  %3522 = call float @dx.op.unary.f32(i32 21, float %3521)  ; Exp(value)
  %3523 = fsub fast float 1.000000e+00, %3522
  %3524 = fdiv fast float %3523, %3515
  br label %3525

; <label>:3525                                    ; preds = %3520, %3517
  %3526 = phi float [ %3519, %3517 ], [ %3524, %3520 ]
  %3527 = call float @dx.op.binary.f32(i32 36, float %3499, float %18)  ; FMin(a,b)
  %3528 = fsub fast float %3527, %10
  %3529 = fmul fast float %11, %3528
  %3530 = fsub fast float -0.000000e+00, %3529
  %3531 = call float @dx.op.binary.f32(i32 35, float %3530, float -4.000000e+01)  ; FMax(a,b)
  %3532 = call float @dx.op.binary.f32(i32 36, float %3531, float 5.000000e+00)  ; FMin(a,b)
  %3533 = fmul fast float %3532, 0x3FF7154760000000
  %3534 = call float @dx.op.unary.f32(i32 21, float %3533)  ; Exp(value)
  %3535 = fmul fast float %3534, %3526
  br label %3536

; <label>:3536                                    ; preds = %3525, %3485
  %3537 = phi float [ %3535, %3525 ], [ 1.000000e+00, %3485 ]
  %3538 = fmul fast float %3511, %16
  %3539 = fmul fast float %3538, %3537
  %3540 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3539)  ; FMin(a,b)
  %3541 = fmul fast float %3540, 0xBFF7154760000000
  %3542 = call float @dx.op.unary.f32(i32 21, float %3541)  ; Exp(value)
  %3543 = fsub fast float 1.000000e+00, %3542
  %3544 = call float @dx.op.binary.f32(i32 36, float %12, float %3543)  ; FMin(a,b)
  %3545 = fsub fast float %13, %3423
  %3546 = fsub fast float %14, %3424
  %3547 = fsub fast float %15, %3425
  %3548 = fmul fast float %3544, %3545
  %3549 = fmul fast float %3544, %3546
  %3550 = fmul fast float %3544, %3547
  %3551 = fadd fast float %3548, %3423
  %3552 = fadd fast float %3549, %3424
  %3553 = fadd fast float %3550, %3425
  br label %3554

; <label>:3554                                    ; preds = %3536, %3468, %3462
  %3555 = phi float [ %3551, %3536 ], [ %3423, %3468 ], [ %3423, %3462 ]
  %3556 = phi float [ %3552, %3536 ], [ %3424, %3468 ], [ %3424, %3462 ]
  %3557 = phi float [ %3553, %3536 ], [ %3425, %3468 ], [ %3425, %3462 ]
  %3558 = fadd fast float %5, 1.000000e+00
  %3559 = fadd fast float %6, 1.000000e+00
  %3560 = fsub fast float 1.000000e+00, %5
  %3561 = fmul fast float %36, %3558
  %3562 = fmul fast float %36, %3559
  %3563 = fmul fast float %36, %3560
  %3564 = fmul fast float %3561, %3555
  %3565 = fmul fast float %3562, %3556
  %3566 = fmul fast float %3563, %3557
  %3567 = fcmp fast ult float %37, 5.000000e-01
  br i1 %3567, label %3593, label %3568

; <label>:3568                                    ; preds = %3554
  %3569 = fmul fast float %3564, 0x4004147AE0000000
  %3570 = fmul fast float %3565, 0x4004147AE0000000
  %3571 = fmul fast float %3566, 0x4004147AE0000000
  %3572 = fadd fast float %3569, 0x3F9EB851E0000000
  %3573 = fadd fast float %3570, 0x3F9EB851E0000000
  %3574 = fadd fast float %3571, 0x3F9EB851E0000000
  %3575 = fmul fast float %3572, %3564
  %3576 = fmul fast float %3573, %3565
  %3577 = fmul fast float %3574, %3566
  %3578 = fmul fast float %3564, 0x400370A3E0000000
  %3579 = fmul fast float %3565, 0x400370A3E0000000
  %3580 = fmul fast float %3566, 0x400370A3E0000000
  %3581 = fadd fast float %3578, 0x3FE2E147A0000000
  %3582 = fadd fast float %3579, 0x3FE2E147A0000000
  %3583 = fadd fast float %3580, 0x3FE2E147A0000000
  %3584 = fmul fast float %3581, %3564
  %3585 = fmul fast float %3582, %3565
  %3586 = fmul fast float %3583, %3566
  %3587 = fadd fast float %3584, 0x3FC1EB8520000000
  %3588 = fadd fast float %3585, 0x3FC1EB8520000000
  %3589 = fadd fast float %3586, 0x3FC1EB8520000000
  %3590 = fdiv fast float %3575, %3587
  %3591 = fdiv fast float %3576, %3588
  %3592 = fdiv fast float %3577, %3589
  br label %3593

; <label>:3593                                    ; preds = %3568, %3554
  %3594 = phi float [ %3590, %3568 ], [ %3564, %3554 ]
  %3595 = phi float [ %3591, %3568 ], [ %3565, %3554 ]
  %3596 = phi float [ %3592, %3568 ], [ %3566, %3554 ]
  %3597 = call float @dx.op.unary.f32(i32 7, float %3594)  ; Saturate(value)
  %3598 = call float @dx.op.unary.f32(i32 7, float %3595)  ; Saturate(value)
  %3599 = call float @dx.op.unary.f32(i32 7, float %3596)  ; Saturate(value)
  %3600 = call float @dx.op.dot3.f32(i32 55, float %3597, float %3598, float %3599, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3601 = fsub fast float %3597, %3600
  %3602 = fsub fast float %3598, %3600
  %3603 = fsub fast float %3599, %3600
  %3604 = fmul fast float %3601, %8
  %3605 = fmul fast float %3602, %8
  %3606 = fmul fast float %3603, %8
  %3607 = fadd fast float %3604, %3600
  %3608 = fadd fast float %3605, %3600
  %3609 = fadd fast float %3606, %3600
  %3610 = call float @dx.op.unary.f32(i32 7, float %3607)  ; Saturate(value)
  %3611 = call float @dx.op.unary.f32(i32 7, float %3608)  ; Saturate(value)
  %3612 = call float @dx.op.unary.f32(i32 7, float %3609)  ; Saturate(value)
  %3613 = fadd fast float %3610, 0xBFC70A3D80000000
  %3614 = fadd fast float %3611, 0xBFC70A3D80000000
  %3615 = fadd fast float %3612, 0xBFC70A3D80000000
  %3616 = fmul fast float %3613, %7
  %3617 = fmul fast float %3614, %7
  %3618 = fmul fast float %3615, %7
  %3619 = fadd fast float %3616, 0x3FC70A3D80000000
  %3620 = fadd fast float %3617, 0x3FC70A3D80000000
  %3621 = fadd fast float %3618, 0x3FC70A3D80000000
  %3622 = call float @dx.op.unary.f32(i32 7, float %3619)  ; Saturate(value)
  %3623 = call float @dx.op.unary.f32(i32 7, float %3620)  ; Saturate(value)
  %3624 = call float @dx.op.unary.f32(i32 7, float %3621)  ; Saturate(value)
  br label %3625

; <label>:3625                                    ; preds = %3593, %3428
  %3626 = phi float [ %3459, %3428 ], [ %3622, %3593 ]
  %3627 = phi float [ %3460, %3428 ], [ %3623, %3593 ]
  %3628 = phi float [ %3461, %3428 ], [ %3624, %3593 ]
  %3629 = fsub fast float %3626, %2924
  %3630 = fsub fast float %3627, %2925
  %3631 = fsub fast float %3628, %2926
  %3632 = fmul fast float %3629, %3415
  %3633 = fmul fast float %3630, %3415
  %3634 = fmul fast float %3631, %3415
  %3635 = fadd fast float %3632, %2924
  %3636 = fadd fast float %3633, %2925
  %3637 = fadd fast float %3634, %2926
  br label %3638

; <label>:3638                                    ; preds = %3625, %3400
  %3639 = phi float [ %3635, %3625 ], [ %2924, %3400 ]
  %3640 = phi float [ %3636, %3625 ], [ %2925, %3400 ]
  %3641 = phi float [ %3637, %3625 ], [ %2926, %3400 ]
  %3642 = add i32 %63, 1
  %3643 = call i32 @dx.op.binary.i32(i32 37, i32 %3642, i32 0)  ; IMax(a,b)
  %3644 = call i32 @dx.op.binary.i32(i32 38, i32 %3643, i32 %59)  ; IMin(a,b)
  %3645 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3644, i32 %3408, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3646 = extractvalue %dx.types.ResRet.f32 %3645, 0
  %3647 = fsub fast float %3646, %86
  %3648 = call float @dx.op.unary.f32(i32 6, float %3647)  ; FAbs(value)
  %3649 = fdiv fast float %3648, %2936
  %3650 = fsub fast float 1.000000e+00, %3649
  %3651 = call float @dx.op.unary.f32(i32 7, float %3650)  ; Saturate(value)
  %3652 = fcmp fast ugt float %3651, 0.000000e+00
  br i1 %3652, label %3653, label %3874

; <label>:3653                                    ; preds = %3638
  %3654 = call i32 @dx.op.binary.i32(i32 37, i32 %3644, i32 0)  ; IMax(a,b)
  %3655 = call i32 @dx.op.binary.i32(i32 37, i32 %3408, i32 0)  ; IMax(a,b)
  %3656 = call i32 @dx.op.binary.i32(i32 38, i32 %3654, i32 %59)  ; IMin(a,b)
  %3657 = call i32 @dx.op.binary.i32(i32 38, i32 %3655, i32 %60)  ; IMin(a,b)
  %3658 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3656, i32 %3657, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3659 = extractvalue %dx.types.ResRet.f32 %3658, 0
  %3660 = extractvalue %dx.types.ResRet.f32 %3658, 1
  %3661 = extractvalue %dx.types.ResRet.f32 %3658, 2
  %3662 = extractvalue %dx.types.ResRet.f32 %3658, 3
  %3663 = fcmp fast olt float %3662, 0.000000e+00
  br i1 %3663, label %3664, label %3698

; <label>:3664                                    ; preds = %3653
  %3665 = fcmp fast ogt float %3659, 0x3FA4B5DCC0000000
  %3666 = fcmp fast ogt float %3660, 0x3FA4B5DCC0000000
  %3667 = fcmp fast ogt float %3661, 0x3FA4B5DCC0000000
  %3668 = select i1 %3665, float 0.000000e+00, float 1.000000e+00
  %3669 = select i1 %3666, float 0.000000e+00, float 1.000000e+00
  %3670 = select i1 %3667, float 0.000000e+00, float 1.000000e+00
  %3671 = fmul fast float %3659, 0x3FB3D07220000000
  %3672 = fmul fast float %3660, 0x3FB3D07220000000
  %3673 = fmul fast float %3661, 0x3FB3D07220000000
  %3674 = fadd fast float %3659, 0x3FAC28F5C0000000
  %3675 = fadd fast float %3660, 0x3FAC28F5C0000000
  %3676 = fadd fast float %3661, 0x3FAC28F5C0000000
  %3677 = fmul fast float %3674, 0x3FEE54EDE0000000
  %3678 = fmul fast float %3675, 0x3FEE54EDE0000000
  %3679 = fmul fast float %3676, 0x3FEE54EDE0000000
  %3680 = call float @dx.op.unary.f32(i32 23, float %3677)  ; Log(value)
  %3681 = call float @dx.op.unary.f32(i32 23, float %3678)  ; Log(value)
  %3682 = call float @dx.op.unary.f32(i32 23, float %3679)  ; Log(value)
  %3683 = fmul fast float %3680, 0x4003333340000000
  %3684 = fmul fast float %3681, 0x4003333340000000
  %3685 = fmul fast float %3682, 0x4003333340000000
  %3686 = call float @dx.op.unary.f32(i32 21, float %3683)  ; Exp(value)
  %3687 = call float @dx.op.unary.f32(i32 21, float %3684)  ; Exp(value)
  %3688 = call float @dx.op.unary.f32(i32 21, float %3685)  ; Exp(value)
  %3689 = fsub fast float %3671, %3686
  %3690 = fsub fast float %3672, %3687
  %3691 = fsub fast float %3673, %3688
  %3692 = fmul fast float %3689, %3668
  %3693 = fmul fast float %3690, %3669
  %3694 = fmul fast float %3691, %3670
  %3695 = fadd fast float %3692, %3686
  %3696 = fadd fast float %3693, %3687
  %3697 = fadd fast float %3694, %3688
  br label %3861

; <label>:3698                                    ; preds = %3653
  %3699 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3656, i32 %3657, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3700 = extractvalue %dx.types.ResRet.f32 %3699, 0
  %3701 = fcmp fast ogt float %38, 5.000000e-01
  %3702 = fcmp fast olt float %3700, 1.000000e+00
  %3703 = and i1 %3701, %3702
  br i1 %3703, label %3704, label %3790

; <label>:3704                                    ; preds = %3698
  %3705 = sitofp i32 %3656 to float
  %3706 = sitofp i32 %3657 to float
  %3707 = fadd fast float %3705, 5.000000e-01
  %3708 = fadd fast float %3706, 5.000000e-01
  %3709 = fdiv fast float %3707, %45
  %3710 = fdiv fast float %3708, %46
  %3711 = fmul fast float %3709, 2.000000e+00
  %3712 = fmul fast float %3710, 2.000000e+00
  %3713 = fadd fast float %3711, -1.000000e+00
  %3714 = fsub fast float 1.000000e+00, %3712
  %3715 = fmul fast float %3713, %35
  %3716 = call float @dx.op.tertiary.f32(i32 46, float %3714, float %31, float %3715)  ; FMad(a,b,c)
  %3717 = call float @dx.op.tertiary.f32(i32 46, float %3700, float %27, float %3716)  ; FMad(a,b,c)
  %3718 = fadd fast float %3717, %23
  %3719 = call float @dx.op.unary.f32(i32 6, float %3718)  ; FAbs(value)
  %3720 = fcmp fast ogt float %3719, 0x3EB0C6F7A0000000
  br i1 %3720, label %3721, label %3790

; <label>:3721                                    ; preds = %3704
  %3722 = fmul fast float %3713, %34
  %3723 = call float @dx.op.tertiary.f32(i32 46, float %3714, float %30, float %3722)  ; FMad(a,b,c)
  %3724 = call float @dx.op.tertiary.f32(i32 46, float %3700, float %26, float %3723)  ; FMad(a,b,c)
  %3725 = fadd fast float %3724, %22
  %3726 = fmul fast float %3713, %33
  %3727 = call float @dx.op.tertiary.f32(i32 46, float %3714, float %29, float %3726)  ; FMad(a,b,c)
  %3728 = call float @dx.op.tertiary.f32(i32 46, float %3700, float %25, float %3727)  ; FMad(a,b,c)
  %3729 = fadd fast float %3728, %21
  %3730 = fmul fast float %3713, %32
  %3731 = call float @dx.op.tertiary.f32(i32 46, float %3714, float %28, float %3730)  ; FMad(a,b,c)
  %3732 = call float @dx.op.tertiary.f32(i32 46, float %3700, float %24, float %3731)  ; FMad(a,b,c)
  %3733 = fadd fast float %3732, %20
  %3734 = fdiv fast float %3733, %3718
  %3735 = fdiv fast float %3729, %3718
  %3736 = fdiv fast float %3725, %3718
  %3737 = fsub fast float %3734, %17
  %3738 = fsub fast float %3735, %18
  %3739 = fsub fast float %3736, %19
  %3740 = fmul fast float %3737, %3737
  %3741 = fmul fast float %3738, %3738
  %3742 = fadd fast float %3741, %3740
  %3743 = fmul fast float %3739, %3739
  %3744 = fadd fast float %3742, %3743
  %3745 = call float @dx.op.unary.f32(i32 24, float %3744)  ; Sqrt(value)
  %3746 = fsub fast float %3745, %9
  %3747 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3746)  ; FMax(a,b)
  %3748 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %3748, label %3749, label %3772

; <label>:3749                                    ; preds = %3721
  %3750 = call float @dx.op.unary.f32(i32 6, float %3738)  ; FAbs(value)
  %3751 = fmul fast float %3750, %11
  %3752 = fcmp fast olt float %3751, 0x3F50624DE0000000
  br i1 %3752, label %3753, label %3756

; <label>:3753                                    ; preds = %3749
  %3754 = fmul fast float %3751, 5.000000e-01
  %3755 = fsub fast float 1.000000e+00, %3754
  br label %3761

; <label>:3756                                    ; preds = %3749
  %3757 = fmul fast float %3751, 0xBFF7154760000000
  %3758 = call float @dx.op.unary.f32(i32 21, float %3757)  ; Exp(value)
  %3759 = fsub fast float 1.000000e+00, %3758
  %3760 = fdiv fast float %3759, %3751
  br label %3761

; <label>:3761                                    ; preds = %3756, %3753
  %3762 = phi float [ %3755, %3753 ], [ %3760, %3756 ]
  %3763 = call float @dx.op.binary.f32(i32 36, float %3735, float %18)  ; FMin(a,b)
  %3764 = fsub fast float %3763, %10
  %3765 = fmul fast float %11, %3764
  %3766 = fsub fast float -0.000000e+00, %3765
  %3767 = call float @dx.op.binary.f32(i32 35, float %3766, float -4.000000e+01)  ; FMax(a,b)
  %3768 = call float @dx.op.binary.f32(i32 36, float %3767, float 5.000000e+00)  ; FMin(a,b)
  %3769 = fmul fast float %3768, 0x3FF7154760000000
  %3770 = call float @dx.op.unary.f32(i32 21, float %3769)  ; Exp(value)
  %3771 = fmul fast float %3770, %3762
  br label %3772

; <label>:3772                                    ; preds = %3761, %3721
  %3773 = phi float [ %3771, %3761 ], [ 1.000000e+00, %3721 ]
  %3774 = fmul fast float %3747, %16
  %3775 = fmul fast float %3774, %3773
  %3776 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3775)  ; FMin(a,b)
  %3777 = fmul fast float %3776, 0xBFF7154760000000
  %3778 = call float @dx.op.unary.f32(i32 21, float %3777)  ; Exp(value)
  %3779 = fsub fast float 1.000000e+00, %3778
  %3780 = call float @dx.op.binary.f32(i32 36, float %12, float %3779)  ; FMin(a,b)
  %3781 = fsub fast float %13, %3659
  %3782 = fsub fast float %14, %3660
  %3783 = fsub fast float %15, %3661
  %3784 = fmul fast float %3780, %3781
  %3785 = fmul fast float %3780, %3782
  %3786 = fmul fast float %3780, %3783
  %3787 = fadd fast float %3784, %3659
  %3788 = fadd fast float %3785, %3660
  %3789 = fadd fast float %3786, %3661
  br label %3790

; <label>:3790                                    ; preds = %3772, %3704, %3698
  %3791 = phi float [ %3787, %3772 ], [ %3659, %3704 ], [ %3659, %3698 ]
  %3792 = phi float [ %3788, %3772 ], [ %3660, %3704 ], [ %3660, %3698 ]
  %3793 = phi float [ %3789, %3772 ], [ %3661, %3704 ], [ %3661, %3698 ]
  %3794 = fadd fast float %5, 1.000000e+00
  %3795 = fadd fast float %6, 1.000000e+00
  %3796 = fsub fast float 1.000000e+00, %5
  %3797 = fmul fast float %36, %3794
  %3798 = fmul fast float %36, %3795
  %3799 = fmul fast float %36, %3796
  %3800 = fmul fast float %3797, %3791
  %3801 = fmul fast float %3798, %3792
  %3802 = fmul fast float %3799, %3793
  %3803 = fcmp fast ult float %37, 5.000000e-01
  br i1 %3803, label %3829, label %3804

; <label>:3804                                    ; preds = %3790
  %3805 = fmul fast float %3800, 0x4004147AE0000000
  %3806 = fmul fast float %3801, 0x4004147AE0000000
  %3807 = fmul fast float %3802, 0x4004147AE0000000
  %3808 = fadd fast float %3805, 0x3F9EB851E0000000
  %3809 = fadd fast float %3806, 0x3F9EB851E0000000
  %3810 = fadd fast float %3807, 0x3F9EB851E0000000
  %3811 = fmul fast float %3808, %3800
  %3812 = fmul fast float %3809, %3801
  %3813 = fmul fast float %3810, %3802
  %3814 = fmul fast float %3800, 0x400370A3E0000000
  %3815 = fmul fast float %3801, 0x400370A3E0000000
  %3816 = fmul fast float %3802, 0x400370A3E0000000
  %3817 = fadd fast float %3814, 0x3FE2E147A0000000
  %3818 = fadd fast float %3815, 0x3FE2E147A0000000
  %3819 = fadd fast float %3816, 0x3FE2E147A0000000
  %3820 = fmul fast float %3817, %3800
  %3821 = fmul fast float %3818, %3801
  %3822 = fmul fast float %3819, %3802
  %3823 = fadd fast float %3820, 0x3FC1EB8520000000
  %3824 = fadd fast float %3821, 0x3FC1EB8520000000
  %3825 = fadd fast float %3822, 0x3FC1EB8520000000
  %3826 = fdiv fast float %3811, %3823
  %3827 = fdiv fast float %3812, %3824
  %3828 = fdiv fast float %3813, %3825
  br label %3829

; <label>:3829                                    ; preds = %3804, %3790
  %3830 = phi float [ %3826, %3804 ], [ %3800, %3790 ]
  %3831 = phi float [ %3827, %3804 ], [ %3801, %3790 ]
  %3832 = phi float [ %3828, %3804 ], [ %3802, %3790 ]
  %3833 = call float @dx.op.unary.f32(i32 7, float %3830)  ; Saturate(value)
  %3834 = call float @dx.op.unary.f32(i32 7, float %3831)  ; Saturate(value)
  %3835 = call float @dx.op.unary.f32(i32 7, float %3832)  ; Saturate(value)
  %3836 = call float @dx.op.dot3.f32(i32 55, float %3833, float %3834, float %3835, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3837 = fsub fast float %3833, %3836
  %3838 = fsub fast float %3834, %3836
  %3839 = fsub fast float %3835, %3836
  %3840 = fmul fast float %3837, %8
  %3841 = fmul fast float %3838, %8
  %3842 = fmul fast float %3839, %8
  %3843 = fadd fast float %3840, %3836
  %3844 = fadd fast float %3841, %3836
  %3845 = fadd fast float %3842, %3836
  %3846 = call float @dx.op.unary.f32(i32 7, float %3843)  ; Saturate(value)
  %3847 = call float @dx.op.unary.f32(i32 7, float %3844)  ; Saturate(value)
  %3848 = call float @dx.op.unary.f32(i32 7, float %3845)  ; Saturate(value)
  %3849 = fadd fast float %3846, 0xBFC70A3D80000000
  %3850 = fadd fast float %3847, 0xBFC70A3D80000000
  %3851 = fadd fast float %3848, 0xBFC70A3D80000000
  %3852 = fmul fast float %3849, %7
  %3853 = fmul fast float %3850, %7
  %3854 = fmul fast float %3851, %7
  %3855 = fadd fast float %3852, 0x3FC70A3D80000000
  %3856 = fadd fast float %3853, 0x3FC70A3D80000000
  %3857 = fadd fast float %3854, 0x3FC70A3D80000000
  %3858 = call float @dx.op.unary.f32(i32 7, float %3855)  ; Saturate(value)
  %3859 = call float @dx.op.unary.f32(i32 7, float %3856)  ; Saturate(value)
  %3860 = call float @dx.op.unary.f32(i32 7, float %3857)  ; Saturate(value)
  br label %3861

; <label>:3861                                    ; preds = %3829, %3664
  %3862 = phi float [ %3695, %3664 ], [ %3858, %3829 ]
  %3863 = phi float [ %3696, %3664 ], [ %3859, %3829 ]
  %3864 = phi float [ %3697, %3664 ], [ %3860, %3829 ]
  %3865 = fsub fast float %3862, %2924
  %3866 = fsub fast float %3863, %2925
  %3867 = fsub fast float %3864, %2926
  %3868 = fmul fast float %3865, %3651
  %3869 = fmul fast float %3866, %3651
  %3870 = fmul fast float %3867, %3651
  %3871 = fadd fast float %3868, %2924
  %3872 = fadd fast float %3869, %2925
  %3873 = fadd fast float %3870, %2926
  br label %3874

; <label>:3874                                    ; preds = %3861, %3638
  %3875 = phi float [ %3871, %3861 ], [ %2924, %3638 ]
  %3876 = phi float [ %3872, %3861 ], [ %2925, %3638 ]
  %3877 = phi float [ %3873, %3861 ], [ %2926, %3638 ]
  %3878 = call float @dx.op.binary.f32(i32 36, float %3639, float %3875)  ; FMin(a,b)
  %3879 = call float @dx.op.binary.f32(i32 36, float %3640, float %3876)  ; FMin(a,b)
  %3880 = call float @dx.op.binary.f32(i32 36, float %3641, float %3877)  ; FMin(a,b)
  %3881 = call float @dx.op.binary.f32(i32 36, float %3165, float %3401)  ; FMin(a,b)
  %3882 = call float @dx.op.binary.f32(i32 36, float %3166, float %3402)  ; FMin(a,b)
  %3883 = call float @dx.op.binary.f32(i32 36, float %3167, float %3403)  ; FMin(a,b)
  %3884 = call float @dx.op.binary.f32(i32 36, float %3881, float %3878)  ; FMin(a,b)
  %3885 = call float @dx.op.binary.f32(i32 36, float %3882, float %3879)  ; FMin(a,b)
  %3886 = call float @dx.op.binary.f32(i32 36, float %3883, float %3880)  ; FMin(a,b)
  %3887 = call float @dx.op.binary.f32(i32 36, float %2924, float %3884)  ; FMin(a,b)
  %3888 = call float @dx.op.binary.f32(i32 36, float %2925, float %3885)  ; FMin(a,b)
  %3889 = call float @dx.op.binary.f32(i32 36, float %2926, float %3886)  ; FMin(a,b)
  %3890 = call float @dx.op.binary.f32(i32 35, float %3639, float %3875)  ; FMax(a,b)
  %3891 = call float @dx.op.binary.f32(i32 35, float %3640, float %3876)  ; FMax(a,b)
  %3892 = call float @dx.op.binary.f32(i32 35, float %3641, float %3877)  ; FMax(a,b)
  %3893 = call float @dx.op.binary.f32(i32 35, float %3165, float %3401)  ; FMax(a,b)
  %3894 = call float @dx.op.binary.f32(i32 35, float %3166, float %3402)  ; FMax(a,b)
  %3895 = call float @dx.op.binary.f32(i32 35, float %3167, float %3403)  ; FMax(a,b)
  %3896 = call float @dx.op.binary.f32(i32 35, float %3893, float %3890)  ; FMax(a,b)
  %3897 = call float @dx.op.binary.f32(i32 35, float %3894, float %3891)  ; FMax(a,b)
  %3898 = call float @dx.op.binary.f32(i32 35, float %3895, float %3892)  ; FMax(a,b)
  %3899 = call float @dx.op.binary.f32(i32 35, float %2924, float %3896)  ; FMax(a,b)
  %3900 = call float @dx.op.binary.f32(i32 35, float %2925, float %3897)  ; FMax(a,b)
  %3901 = call float @dx.op.binary.f32(i32 35, float %2926, float %3898)  ; FMax(a,b)
  %3902 = fsub fast float %3899, %3887
  %3903 = fsub fast float %3900, %3888
  %3904 = fsub fast float %3901, %3889
  %3905 = call float @dx.op.unary.f32(i32 6, float %3902)  ; FAbs(value)
  %3906 = call float @dx.op.unary.f32(i32 6, float %3903)  ; FAbs(value)
  %3907 = call float @dx.op.unary.f32(i32 6, float %3904)  ; FAbs(value)
  %3908 = call float @dx.op.binary.f32(i32 35, float %3906, float %3907)  ; FMax(a,b)
  %3909 = call float @dx.op.binary.f32(i32 35, float %3905, float %3908)  ; FMax(a,b)
  %3910 = call float @dx.op.binary.f32(i32 35, float %3900, float %3901)  ; FMax(a,b)
  %3911 = call float @dx.op.binary.f32(i32 35, float %3899, float %3910)  ; FMax(a,b)
  %3912 = fmul fast float %3911, 1.250000e-01
  %3913 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %3912)  ; FMax(a,b)
  %3914 = fcmp fast ogt float %3909, %3913
  br i1 %3914, label %3915, label %3976

; <label>:3915                                    ; preds = %3874
  %3916 = fsub fast float %3165, %3401
  %3917 = fsub fast float %3166, %3402
  %3918 = fsub fast float %3167, %3403
  %3919 = call float @dx.op.unary.f32(i32 6, float %3916)  ; FAbs(value)
  %3920 = call float @dx.op.unary.f32(i32 6, float %3917)  ; FAbs(value)
  %3921 = call float @dx.op.unary.f32(i32 6, float %3918)  ; FAbs(value)
  %3922 = call float @dx.op.binary.f32(i32 35, float %3920, float %3921)  ; FMax(a,b)
  %3923 = call float @dx.op.binary.f32(i32 35, float %3919, float %3922)  ; FMax(a,b)
  %3924 = fsub fast float %3639, %3875
  %3925 = fsub fast float %3640, %3876
  %3926 = fsub fast float %3641, %3877
  %3927 = call float @dx.op.unary.f32(i32 6, float %3924)  ; FAbs(value)
  %3928 = call float @dx.op.unary.f32(i32 6, float %3925)  ; FAbs(value)
  %3929 = call float @dx.op.unary.f32(i32 6, float %3926)  ; FAbs(value)
  %3930 = call float @dx.op.binary.f32(i32 35, float %3928, float %3929)  ; FMax(a,b)
  %3931 = call float @dx.op.binary.f32(i32 35, float %3927, float %3930)  ; FMax(a,b)
  %3932 = fcmp fast olt float %3923, %3931
  %3933 = select i1 %3932, float %3165, float %3639
  %3934 = select i1 %3932, float %3166, float %3640
  %3935 = select i1 %3932, float %3167, float %3641
  %3936 = select i1 %3932, float %3401, float %3875
  %3937 = select i1 %3932, float %3402, float %3876
  %3938 = select i1 %3932, float %3403, float %3877
  %3939 = fsub fast float %2924, %3936
  %3940 = fsub fast float %2925, %3937
  %3941 = fsub fast float %2926, %3938
  %3942 = fsub fast float %2924, %3933
  %3943 = fsub fast float %2925, %3934
  %3944 = fsub fast float %2926, %3935
  %3945 = call float @dx.op.dot3.f32(i32 55, float %3942, float %3943, float %3944, float %3939, float %3940, float %3941)  ; Dot3(ax,ay,az,bx,by,bz)
  %3946 = fcmp fast ogt float %3945, 0.000000e+00
  br i1 %3946, label %3947, label %3958

; <label>:3947                                    ; preds = %3915
  %3948 = fsub fast float %3933, %3936
  %3949 = fsub fast float %3934, %3937
  %3950 = fsub fast float %3935, %3938
  %3951 = call float @dx.op.unary.f32(i32 6, float %3948)  ; FAbs(value)
  %3952 = call float @dx.op.unary.f32(i32 6, float %3949)  ; FAbs(value)
  %3953 = call float @dx.op.unary.f32(i32 6, float %3950)  ; FAbs(value)
  %3954 = call float @dx.op.binary.f32(i32 35, float %3952, float %3953)  ; FMax(a,b)
  %3955 = call float @dx.op.binary.f32(i32 35, float %3951, float %3954)  ; FMax(a,b)
  %3956 = fmul fast float %3909, 2.500000e-01
  %3957 = fcmp fast olt float %3955, %3956
  br label %3958

; <label>:3958                                    ; preds = %3947, %3915
  %3959 = phi i1 [ false, %3915 ], [ %3957, %3947 ]
  %3960 = select i1 %3959, float 0x3FC3333340000000, float 0x3FD3333340000000
  %3961 = fadd fast float %3933, %3936
  %3962 = fadd fast float %3934, %3937
  %3963 = fadd fast float %3935, %3938
  %3964 = fmul fast float %3961, 5.000000e-01
  %3965 = fmul fast float %3962, 5.000000e-01
  %3966 = fmul fast float %3963, 5.000000e-01
  %3967 = fsub fast float %3964, %2924
  %3968 = fsub fast float %3965, %2925
  %3969 = fsub fast float %3966, %2926
  %3970 = fmul fast float %3960, %3967
  %3971 = fmul fast float %3960, %3968
  %3972 = fmul fast float %3960, %3969
  %3973 = fadd fast float %3970, %2924
  %3974 = fadd fast float %3971, %2925
  %3975 = fadd fast float %3972, %2926
  br label %3976

; <label>:3976                                    ; preds = %3958, %3874
  %3977 = phi float [ %3973, %3958 ], [ %2924, %3874 ]
  %3978 = phi float [ %3974, %3958 ], [ %2925, %3874 ]
  %3979 = phi float [ %3975, %3958 ], [ %2926, %3874 ]
  %3980 = fcmp fast ogt float %3977, 0x3F69A5C380000000
  %3981 = fcmp fast ogt float %3978, 0x3F69A5C380000000
  %3982 = fcmp fast ogt float %3979, 0x3F69A5C380000000
  %3983 = select i1 %3980, float 0.000000e+00, float 1.000000e+00
  %3984 = select i1 %3981, float 0.000000e+00, float 1.000000e+00
  %3985 = select i1 %3982, float 0.000000e+00, float 1.000000e+00
  %3986 = fmul fast float %3977, 0x4029D70A40000000
  %3987 = fmul fast float %3978, 0x4029D70A40000000
  %3988 = fmul fast float %3979, 0x4029D70A40000000
  %3989 = call float @dx.op.binary.f32(i32 35, float %3977, float 0.000000e+00)  ; FMax(a,b)
  %3990 = call float @dx.op.binary.f32(i32 35, float %3978, float 0.000000e+00)  ; FMax(a,b)
  %3991 = call float @dx.op.binary.f32(i32 35, float %3979, float 0.000000e+00)  ; FMax(a,b)
  %3992 = call float @dx.op.unary.f32(i32 23, float %3989)  ; Log(value)
  %3993 = call float @dx.op.unary.f32(i32 23, float %3990)  ; Log(value)
  %3994 = call float @dx.op.unary.f32(i32 23, float %3991)  ; Log(value)
  %3995 = fmul fast float %3992, 0x3FDAAAAAA0000000
  %3996 = fmul fast float %3993, 0x3FDAAAAAA0000000
  %3997 = fmul fast float %3994, 0x3FDAAAAAA0000000
  %3998 = call float @dx.op.unary.f32(i32 21, float %3995)  ; Exp(value)
  %3999 = call float @dx.op.unary.f32(i32 21, float %3996)  ; Exp(value)
  %4000 = call float @dx.op.unary.f32(i32 21, float %3997)  ; Exp(value)
  %4001 = fmul fast float %3998, 0x3FF0E147A0000000
  %4002 = fmul fast float %3999, 0x3FF0E147A0000000
  %4003 = fmul fast float %4000, 0x3FF0E147A0000000
  %4004 = fadd fast float %4001, 0xBFAC28F5C0000000
  %4005 = fadd fast float %4002, 0xBFAC28F5C0000000
  %4006 = fadd fast float %4003, 0xBFAC28F5C0000000
  %4007 = fsub fast float %3986, %4004
  %4008 = fsub fast float %3987, %4005
  %4009 = fsub fast float %3988, %4006
  %4010 = fmul fast float %4007, %3983
  %4011 = fmul fast float %4008, %3984
  %4012 = fmul fast float %4009, %3985
  %4013 = fadd fast float %4010, %4004
  %4014 = fadd fast float %4011, %4005
  %4015 = fadd fast float %4012, %4006
  br label %4016

; <label>:4016                                    ; preds = %3976, %2764
  %4017 = phi float [ %2759, %2764 ], [ %4013, %3976 ]
  %4018 = phi float [ %2760, %2764 ], [ %4014, %3976 ]
  %4019 = phi float [ %2761, %2764 ], [ %4015, %3976 ]
  %4020 = phi float [ %2765, %2764 ], [ %2762, %3976 ]
  %4021 = fcmp fast ogt float %4017, 0x3FA4B5DCC0000000
  %4022 = fcmp fast ogt float %4018, 0x3FA4B5DCC0000000
  %4023 = fcmp fast ogt float %4019, 0x3FA4B5DCC0000000
  %4024 = select i1 %4021, float 0.000000e+00, float 1.000000e+00
  %4025 = select i1 %4022, float 0.000000e+00, float 1.000000e+00
  %4026 = select i1 %4023, float 0.000000e+00, float 1.000000e+00
  %4027 = fmul fast float %4017, 0x3FB3D07220000000
  %4028 = fmul fast float %4018, 0x3FB3D07220000000
  %4029 = fmul fast float %4019, 0x3FB3D07220000000
  %4030 = fadd fast float %4017, 0x3FAC28F5C0000000
  %4031 = fadd fast float %4018, 0x3FAC28F5C0000000
  %4032 = fadd fast float %4019, 0x3FAC28F5C0000000
  %4033 = fmul fast float %4030, 0x3FEE54EDE0000000
  %4034 = fmul fast float %4031, 0x3FEE54EDE0000000
  %4035 = fmul fast float %4032, 0x3FEE54EDE0000000
  %4036 = call float @dx.op.unary.f32(i32 23, float %4033)  ; Log(value)
  %4037 = call float @dx.op.unary.f32(i32 23, float %4034)  ; Log(value)
  %4038 = call float @dx.op.unary.f32(i32 23, float %4035)  ; Log(value)
  %4039 = fmul fast float %4036, 0x4003333340000000
  %4040 = fmul fast float %4037, 0x4003333340000000
  %4041 = fmul fast float %4038, 0x4003333340000000
  %4042 = call float @dx.op.unary.f32(i32 21, float %4039)  ; Exp(value)
  %4043 = call float @dx.op.unary.f32(i32 21, float %4040)  ; Exp(value)
  %4044 = call float @dx.op.unary.f32(i32 21, float %4041)  ; Exp(value)
  %4045 = fsub fast float %4027, %4042
  %4046 = fsub fast float %4028, %4043
  %4047 = fsub fast float %4029, %4044
  %4048 = fmul fast float %4045, %4024
  %4049 = fmul fast float %4046, %4025
  %4050 = fmul fast float %4047, %4026
  %4051 = fadd fast float %4048, %4042
  %4052 = fadd fast float %4049, %4043
  %4053 = fadd fast float %4050, %4044
  %4054 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %67, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4055 = extractvalue %dx.types.ResRet.f32 %4054, 0
  %4056 = extractvalue %dx.types.ResRet.f32 %4054, 1
  %4057 = extractvalue %dx.types.ResRet.f32 %4054, 2
  %4058 = extractvalue %dx.types.ResRet.f32 %4054, 3
  %4059 = fcmp fast olt float %4058, 0.000000e+00
  br i1 %4059, label %4060, label %4062

; <label>:4060                                    ; preds = %4016
  %4061 = fsub fast float -1.000000e+00, %4058
  br label %5312

; <label>:4062                                    ; preds = %4016
  %4063 = fcmp fast ogt float %38, 5.000000e-01
  %4064 = fcmp fast olt float %88, 1.000000e+00
  %4065 = and i1 %4063, %4064
  br i1 %4065, label %4066, label %4152

; <label>:4066                                    ; preds = %4062
  %4067 = sitofp i32 %67 to float
  %4068 = sitofp i32 %70 to float
  %4069 = fadd fast float %4067, 5.000000e-01
  %4070 = fadd fast float %4068, 5.000000e-01
  %4071 = fdiv fast float %4069, %45
  %4072 = fdiv fast float %4070, %46
  %4073 = fmul fast float %4071, 2.000000e+00
  %4074 = fmul fast float %4072, 2.000000e+00
  %4075 = fadd fast float %4073, -1.000000e+00
  %4076 = fsub fast float 1.000000e+00, %4074
  %4077 = fmul fast float %4075, %35
  %4078 = call float @dx.op.tertiary.f32(i32 46, float %4076, float %31, float %4077)  ; FMad(a,b,c)
  %4079 = call float @dx.op.tertiary.f32(i32 46, float %88, float %27, float %4078)  ; FMad(a,b,c)
  %4080 = fadd fast float %4079, %23
  %4081 = call float @dx.op.unary.f32(i32 6, float %4080)  ; FAbs(value)
  %4082 = fcmp fast ogt float %4081, 0x3EB0C6F7A0000000
  br i1 %4082, label %4083, label %4152

; <label>:4083                                    ; preds = %4066
  %4084 = fmul fast float %4075, %34
  %4085 = call float @dx.op.tertiary.f32(i32 46, float %4076, float %30, float %4084)  ; FMad(a,b,c)
  %4086 = call float @dx.op.tertiary.f32(i32 46, float %88, float %26, float %4085)  ; FMad(a,b,c)
  %4087 = fadd fast float %4086, %22
  %4088 = fmul fast float %4075, %33
  %4089 = call float @dx.op.tertiary.f32(i32 46, float %4076, float %29, float %4088)  ; FMad(a,b,c)
  %4090 = call float @dx.op.tertiary.f32(i32 46, float %88, float %25, float %4089)  ; FMad(a,b,c)
  %4091 = fadd fast float %4090, %21
  %4092 = fmul fast float %4075, %32
  %4093 = call float @dx.op.tertiary.f32(i32 46, float %4076, float %28, float %4092)  ; FMad(a,b,c)
  %4094 = call float @dx.op.tertiary.f32(i32 46, float %88, float %24, float %4093)  ; FMad(a,b,c)
  %4095 = fadd fast float %4094, %20
  %4096 = fdiv fast float %4095, %4080
  %4097 = fdiv fast float %4091, %4080
  %4098 = fdiv fast float %4087, %4080
  %4099 = fsub fast float %4096, %17
  %4100 = fsub fast float %4097, %18
  %4101 = fsub fast float %4098, %19
  %4102 = fmul fast float %4099, %4099
  %4103 = fmul fast float %4100, %4100
  %4104 = fadd fast float %4103, %4102
  %4105 = fmul fast float %4101, %4101
  %4106 = fadd fast float %4104, %4105
  %4107 = call float @dx.op.unary.f32(i32 24, float %4106)  ; Sqrt(value)
  %4108 = fsub fast float %4107, %9
  %4109 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4108)  ; FMax(a,b)
  %4110 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %4110, label %4111, label %4134

; <label>:4111                                    ; preds = %4083
  %4112 = call float @dx.op.unary.f32(i32 6, float %4100)  ; FAbs(value)
  %4113 = fmul fast float %4112, %11
  %4114 = fcmp fast olt float %4113, 0x3F50624DE0000000
  br i1 %4114, label %4115, label %4118

; <label>:4115                                    ; preds = %4111
  %4116 = fmul fast float %4113, 5.000000e-01
  %4117 = fsub fast float 1.000000e+00, %4116
  br label %4123

; <label>:4118                                    ; preds = %4111
  %4119 = fmul fast float %4113, 0xBFF7154760000000
  %4120 = call float @dx.op.unary.f32(i32 21, float %4119)  ; Exp(value)
  %4121 = fsub fast float 1.000000e+00, %4120
  %4122 = fdiv fast float %4121, %4113
  br label %4123

; <label>:4123                                    ; preds = %4118, %4115
  %4124 = phi float [ %4117, %4115 ], [ %4122, %4118 ]
  %4125 = call float @dx.op.binary.f32(i32 36, float %4097, float %18)  ; FMin(a,b)
  %4126 = fsub fast float %4125, %10
  %4127 = fmul fast float %11, %4126
  %4128 = fsub fast float -0.000000e+00, %4127
  %4129 = call float @dx.op.binary.f32(i32 35, float %4128, float -4.000000e+01)  ; FMax(a,b)
  %4130 = call float @dx.op.binary.f32(i32 36, float %4129, float 5.000000e+00)  ; FMin(a,b)
  %4131 = fmul fast float %4130, 0x3FF7154760000000
  %4132 = call float @dx.op.unary.f32(i32 21, float %4131)  ; Exp(value)
  %4133 = fmul fast float %4132, %4124
  br label %4134

; <label>:4134                                    ; preds = %4123, %4083
  %4135 = phi float [ %4133, %4123 ], [ 1.000000e+00, %4083 ]
  %4136 = fmul fast float %4109, %16
  %4137 = fmul fast float %4136, %4135
  %4138 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4137)  ; FMin(a,b)
  %4139 = fmul fast float %4138, 0xBFF7154760000000
  %4140 = call float @dx.op.unary.f32(i32 21, float %4139)  ; Exp(value)
  %4141 = fsub fast float 1.000000e+00, %4140
  %4142 = call float @dx.op.binary.f32(i32 36, float %12, float %4141)  ; FMin(a,b)
  %4143 = fsub fast float %13, %4055
  %4144 = fsub fast float %14, %4056
  %4145 = fsub fast float %15, %4057
  %4146 = fmul fast float %4142, %4143
  %4147 = fmul fast float %4142, %4144
  %4148 = fmul fast float %4142, %4145
  %4149 = fadd fast float %4146, %4055
  %4150 = fadd fast float %4147, %4056
  %4151 = fadd fast float %4148, %4057
  br label %4152

; <label>:4152                                    ; preds = %4134, %4066, %4062
  %4153 = phi float [ %4149, %4134 ], [ %4055, %4066 ], [ %4055, %4062 ]
  %4154 = phi float [ %4150, %4134 ], [ %4056, %4066 ], [ %4056, %4062 ]
  %4155 = phi float [ %4151, %4134 ], [ %4057, %4066 ], [ %4057, %4062 ]
  %4156 = fadd fast float %5, 1.000000e+00
  %4157 = fadd fast float %6, 1.000000e+00
  %4158 = fsub fast float 1.000000e+00, %5
  %4159 = fmul fast float %36, %4156
  %4160 = fmul fast float %36, %4157
  %4161 = fmul fast float %36, %4158
  %4162 = fmul fast float %4159, %4153
  %4163 = fmul fast float %4160, %4154
  %4164 = fmul fast float %4161, %4155
  %4165 = fcmp fast ult float %37, 5.000000e-01
  br i1 %4165, label %4191, label %4166

; <label>:4166                                    ; preds = %4152
  %4167 = fmul fast float %4162, 0x4004147AE0000000
  %4168 = fmul fast float %4163, 0x4004147AE0000000
  %4169 = fmul fast float %4164, 0x4004147AE0000000
  %4170 = fadd fast float %4167, 0x3F9EB851E0000000
  %4171 = fadd fast float %4168, 0x3F9EB851E0000000
  %4172 = fadd fast float %4169, 0x3F9EB851E0000000
  %4173 = fmul fast float %4170, %4162
  %4174 = fmul fast float %4171, %4163
  %4175 = fmul fast float %4172, %4164
  %4176 = fmul fast float %4162, 0x400370A3E0000000
  %4177 = fmul fast float %4163, 0x400370A3E0000000
  %4178 = fmul fast float %4164, 0x400370A3E0000000
  %4179 = fadd fast float %4176, 0x3FE2E147A0000000
  %4180 = fadd fast float %4177, 0x3FE2E147A0000000
  %4181 = fadd fast float %4178, 0x3FE2E147A0000000
  %4182 = fmul fast float %4179, %4162
  %4183 = fmul fast float %4180, %4163
  %4184 = fmul fast float %4181, %4164
  %4185 = fadd fast float %4182, 0x3FC1EB8520000000
  %4186 = fadd fast float %4183, 0x3FC1EB8520000000
  %4187 = fadd fast float %4184, 0x3FC1EB8520000000
  %4188 = fdiv fast float %4173, %4185
  %4189 = fdiv fast float %4174, %4186
  %4190 = fdiv fast float %4175, %4187
  br label %4191

; <label>:4191                                    ; preds = %4166, %4152
  %4192 = phi float [ %4188, %4166 ], [ %4162, %4152 ]
  %4193 = phi float [ %4189, %4166 ], [ %4163, %4152 ]
  %4194 = phi float [ %4190, %4166 ], [ %4164, %4152 ]
  %4195 = call float @dx.op.unary.f32(i32 7, float %4192)  ; Saturate(value)
  %4196 = call float @dx.op.unary.f32(i32 7, float %4193)  ; Saturate(value)
  %4197 = call float @dx.op.unary.f32(i32 7, float %4194)  ; Saturate(value)
  %4198 = call float @dx.op.dot3.f32(i32 55, float %4195, float %4196, float %4197, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4199 = fsub fast float %4195, %4198
  %4200 = fsub fast float %4196, %4198
  %4201 = fsub fast float %4197, %4198
  %4202 = fmul fast float %4199, %8
  %4203 = fmul fast float %4200, %8
  %4204 = fmul fast float %4201, %8
  %4205 = fadd fast float %4202, %4198
  %4206 = fadd fast float %4203, %4198
  %4207 = fadd fast float %4204, %4198
  %4208 = call float @dx.op.unary.f32(i32 7, float %4205)  ; Saturate(value)
  %4209 = call float @dx.op.unary.f32(i32 7, float %4206)  ; Saturate(value)
  %4210 = call float @dx.op.unary.f32(i32 7, float %4207)  ; Saturate(value)
  %4211 = fadd fast float %4208, 0xBFC70A3D80000000
  %4212 = fadd fast float %4209, 0xBFC70A3D80000000
  %4213 = fadd fast float %4210, 0xBFC70A3D80000000
  %4214 = fmul fast float %4211, %7
  %4215 = fmul fast float %4212, %7
  %4216 = fmul fast float %4213, %7
  %4217 = fadd fast float %4214, 0x3FC70A3D80000000
  %4218 = fadd fast float %4215, 0x3FC70A3D80000000
  %4219 = fadd fast float %4216, 0x3FC70A3D80000000
  %4220 = call float @dx.op.unary.f32(i32 7, float %4217)  ; Saturate(value)
  %4221 = call float @dx.op.unary.f32(i32 7, float %4218)  ; Saturate(value)
  %4222 = call float @dx.op.unary.f32(i32 7, float %4219)  ; Saturate(value)
  %4223 = add i32 %70, -1
  %4224 = call i32 @dx.op.binary.i32(i32 37, i32 %67, i32 0)  ; IMax(a,b)
  %4225 = call i32 @dx.op.binary.i32(i32 37, i32 %4223, i32 0)  ; IMax(a,b)
  %4226 = call i32 @dx.op.binary.i32(i32 38, i32 %4224, i32 %59)  ; IMin(a,b)
  %4227 = call i32 @dx.op.binary.i32(i32 38, i32 %4225, i32 %60)  ; IMin(a,b)
  %4228 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4226, i32 %4227, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4229 = extractvalue %dx.types.ResRet.f32 %4228, 0
  %4230 = fsub fast float 1.000000e+00, %88
  %4231 = fmul fast float %4230, 0x3FA99999A0000000
  %4232 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %4231)  ; FMax(a,b)
  %4233 = fsub fast float %4229, %88
  %4234 = call float @dx.op.unary.f32(i32 6, float %4233)  ; FAbs(value)
  %4235 = fdiv fast float %4234, %4232
  %4236 = fsub fast float 1.000000e+00, %4235
  %4237 = call float @dx.op.unary.f32(i32 7, float %4236)  ; Saturate(value)
  %4238 = fcmp fast ugt float %4237, 0.000000e+00
  br i1 %4238, label %4239, label %4460

; <label>:4239                                    ; preds = %4191
  %4240 = call i32 @dx.op.binary.i32(i32 37, i32 %4226, i32 0)  ; IMax(a,b)
  %4241 = call i32 @dx.op.binary.i32(i32 37, i32 %4227, i32 0)  ; IMax(a,b)
  %4242 = call i32 @dx.op.binary.i32(i32 38, i32 %4240, i32 %59)  ; IMin(a,b)
  %4243 = call i32 @dx.op.binary.i32(i32 38, i32 %4241, i32 %60)  ; IMin(a,b)
  %4244 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4242, i32 %4243, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4245 = extractvalue %dx.types.ResRet.f32 %4244, 0
  %4246 = extractvalue %dx.types.ResRet.f32 %4244, 1
  %4247 = extractvalue %dx.types.ResRet.f32 %4244, 2
  %4248 = extractvalue %dx.types.ResRet.f32 %4244, 3
  %4249 = fcmp fast olt float %4248, 0.000000e+00
  br i1 %4249, label %4250, label %4284

; <label>:4250                                    ; preds = %4239
  %4251 = fcmp fast ogt float %4245, 0x3FA4B5DCC0000000
  %4252 = fcmp fast ogt float %4246, 0x3FA4B5DCC0000000
  %4253 = fcmp fast ogt float %4247, 0x3FA4B5DCC0000000
  %4254 = select i1 %4251, float 0.000000e+00, float 1.000000e+00
  %4255 = select i1 %4252, float 0.000000e+00, float 1.000000e+00
  %4256 = select i1 %4253, float 0.000000e+00, float 1.000000e+00
  %4257 = fmul fast float %4245, 0x3FB3D07220000000
  %4258 = fmul fast float %4246, 0x3FB3D07220000000
  %4259 = fmul fast float %4247, 0x3FB3D07220000000
  %4260 = fadd fast float %4245, 0x3FAC28F5C0000000
  %4261 = fadd fast float %4246, 0x3FAC28F5C0000000
  %4262 = fadd fast float %4247, 0x3FAC28F5C0000000
  %4263 = fmul fast float %4260, 0x3FEE54EDE0000000
  %4264 = fmul fast float %4261, 0x3FEE54EDE0000000
  %4265 = fmul fast float %4262, 0x3FEE54EDE0000000
  %4266 = call float @dx.op.unary.f32(i32 23, float %4263)  ; Log(value)
  %4267 = call float @dx.op.unary.f32(i32 23, float %4264)  ; Log(value)
  %4268 = call float @dx.op.unary.f32(i32 23, float %4265)  ; Log(value)
  %4269 = fmul fast float %4266, 0x4003333340000000
  %4270 = fmul fast float %4267, 0x4003333340000000
  %4271 = fmul fast float %4268, 0x4003333340000000
  %4272 = call float @dx.op.unary.f32(i32 21, float %4269)  ; Exp(value)
  %4273 = call float @dx.op.unary.f32(i32 21, float %4270)  ; Exp(value)
  %4274 = call float @dx.op.unary.f32(i32 21, float %4271)  ; Exp(value)
  %4275 = fsub fast float %4257, %4272
  %4276 = fsub fast float %4258, %4273
  %4277 = fsub fast float %4259, %4274
  %4278 = fmul fast float %4275, %4254
  %4279 = fmul fast float %4276, %4255
  %4280 = fmul fast float %4277, %4256
  %4281 = fadd fast float %4278, %4272
  %4282 = fadd fast float %4279, %4273
  %4283 = fadd fast float %4280, %4274
  br label %4447

; <label>:4284                                    ; preds = %4239
  %4285 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4242, i32 %4243, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4286 = extractvalue %dx.types.ResRet.f32 %4285, 0
  %4287 = fcmp fast ogt float %38, 5.000000e-01
  %4288 = fcmp fast olt float %4286, 1.000000e+00
  %4289 = and i1 %4287, %4288
  br i1 %4289, label %4290, label %4376

; <label>:4290                                    ; preds = %4284
  %4291 = sitofp i32 %4242 to float
  %4292 = sitofp i32 %4243 to float
  %4293 = fadd fast float %4291, 5.000000e-01
  %4294 = fadd fast float %4292, 5.000000e-01
  %4295 = fdiv fast float %4293, %45
  %4296 = fdiv fast float %4294, %46
  %4297 = fmul fast float %4295, 2.000000e+00
  %4298 = fmul fast float %4296, 2.000000e+00
  %4299 = fadd fast float %4297, -1.000000e+00
  %4300 = fsub fast float 1.000000e+00, %4298
  %4301 = fmul fast float %4299, %35
  %4302 = call float @dx.op.tertiary.f32(i32 46, float %4300, float %31, float %4301)  ; FMad(a,b,c)
  %4303 = call float @dx.op.tertiary.f32(i32 46, float %4286, float %27, float %4302)  ; FMad(a,b,c)
  %4304 = fadd fast float %4303, %23
  %4305 = call float @dx.op.unary.f32(i32 6, float %4304)  ; FAbs(value)
  %4306 = fcmp fast ogt float %4305, 0x3EB0C6F7A0000000
  br i1 %4306, label %4307, label %4376

; <label>:4307                                    ; preds = %4290
  %4308 = fmul fast float %4299, %34
  %4309 = call float @dx.op.tertiary.f32(i32 46, float %4300, float %30, float %4308)  ; FMad(a,b,c)
  %4310 = call float @dx.op.tertiary.f32(i32 46, float %4286, float %26, float %4309)  ; FMad(a,b,c)
  %4311 = fadd fast float %4310, %22
  %4312 = fmul fast float %4299, %33
  %4313 = call float @dx.op.tertiary.f32(i32 46, float %4300, float %29, float %4312)  ; FMad(a,b,c)
  %4314 = call float @dx.op.tertiary.f32(i32 46, float %4286, float %25, float %4313)  ; FMad(a,b,c)
  %4315 = fadd fast float %4314, %21
  %4316 = fmul fast float %4299, %32
  %4317 = call float @dx.op.tertiary.f32(i32 46, float %4300, float %28, float %4316)  ; FMad(a,b,c)
  %4318 = call float @dx.op.tertiary.f32(i32 46, float %4286, float %24, float %4317)  ; FMad(a,b,c)
  %4319 = fadd fast float %4318, %20
  %4320 = fdiv fast float %4319, %4304
  %4321 = fdiv fast float %4315, %4304
  %4322 = fdiv fast float %4311, %4304
  %4323 = fsub fast float %4320, %17
  %4324 = fsub fast float %4321, %18
  %4325 = fsub fast float %4322, %19
  %4326 = fmul fast float %4323, %4323
  %4327 = fmul fast float %4324, %4324
  %4328 = fadd fast float %4327, %4326
  %4329 = fmul fast float %4325, %4325
  %4330 = fadd fast float %4328, %4329
  %4331 = call float @dx.op.unary.f32(i32 24, float %4330)  ; Sqrt(value)
  %4332 = fsub fast float %4331, %9
  %4333 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4332)  ; FMax(a,b)
  %4334 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %4334, label %4335, label %4358

; <label>:4335                                    ; preds = %4307
  %4336 = call float @dx.op.unary.f32(i32 6, float %4324)  ; FAbs(value)
  %4337 = fmul fast float %4336, %11
  %4338 = fcmp fast olt float %4337, 0x3F50624DE0000000
  br i1 %4338, label %4339, label %4342

; <label>:4339                                    ; preds = %4335
  %4340 = fmul fast float %4337, 5.000000e-01
  %4341 = fsub fast float 1.000000e+00, %4340
  br label %4347

; <label>:4342                                    ; preds = %4335
  %4343 = fmul fast float %4337, 0xBFF7154760000000
  %4344 = call float @dx.op.unary.f32(i32 21, float %4343)  ; Exp(value)
  %4345 = fsub fast float 1.000000e+00, %4344
  %4346 = fdiv fast float %4345, %4337
  br label %4347

; <label>:4347                                    ; preds = %4342, %4339
  %4348 = phi float [ %4341, %4339 ], [ %4346, %4342 ]
  %4349 = call float @dx.op.binary.f32(i32 36, float %4321, float %18)  ; FMin(a,b)
  %4350 = fsub fast float %4349, %10
  %4351 = fmul fast float %11, %4350
  %4352 = fsub fast float -0.000000e+00, %4351
  %4353 = call float @dx.op.binary.f32(i32 35, float %4352, float -4.000000e+01)  ; FMax(a,b)
  %4354 = call float @dx.op.binary.f32(i32 36, float %4353, float 5.000000e+00)  ; FMin(a,b)
  %4355 = fmul fast float %4354, 0x3FF7154760000000
  %4356 = call float @dx.op.unary.f32(i32 21, float %4355)  ; Exp(value)
  %4357 = fmul fast float %4356, %4348
  br label %4358

; <label>:4358                                    ; preds = %4347, %4307
  %4359 = phi float [ %4357, %4347 ], [ 1.000000e+00, %4307 ]
  %4360 = fmul fast float %4333, %16
  %4361 = fmul fast float %4360, %4359
  %4362 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4361)  ; FMin(a,b)
  %4363 = fmul fast float %4362, 0xBFF7154760000000
  %4364 = call float @dx.op.unary.f32(i32 21, float %4363)  ; Exp(value)
  %4365 = fsub fast float 1.000000e+00, %4364
  %4366 = call float @dx.op.binary.f32(i32 36, float %12, float %4365)  ; FMin(a,b)
  %4367 = fsub fast float %13, %4245
  %4368 = fsub fast float %14, %4246
  %4369 = fsub fast float %15, %4247
  %4370 = fmul fast float %4366, %4367
  %4371 = fmul fast float %4366, %4368
  %4372 = fmul fast float %4366, %4369
  %4373 = fadd fast float %4370, %4245
  %4374 = fadd fast float %4371, %4246
  %4375 = fadd fast float %4372, %4247
  br label %4376

; <label>:4376                                    ; preds = %4358, %4290, %4284
  %4377 = phi float [ %4373, %4358 ], [ %4245, %4290 ], [ %4245, %4284 ]
  %4378 = phi float [ %4374, %4358 ], [ %4246, %4290 ], [ %4246, %4284 ]
  %4379 = phi float [ %4375, %4358 ], [ %4247, %4290 ], [ %4247, %4284 ]
  %4380 = fadd fast float %5, 1.000000e+00
  %4381 = fadd fast float %6, 1.000000e+00
  %4382 = fsub fast float 1.000000e+00, %5
  %4383 = fmul fast float %36, %4380
  %4384 = fmul fast float %36, %4381
  %4385 = fmul fast float %36, %4382
  %4386 = fmul fast float %4383, %4377
  %4387 = fmul fast float %4384, %4378
  %4388 = fmul fast float %4385, %4379
  %4389 = fcmp fast ult float %37, 5.000000e-01
  br i1 %4389, label %4415, label %4390

; <label>:4390                                    ; preds = %4376
  %4391 = fmul fast float %4386, 0x4004147AE0000000
  %4392 = fmul fast float %4387, 0x4004147AE0000000
  %4393 = fmul fast float %4388, 0x4004147AE0000000
  %4394 = fadd fast float %4391, 0x3F9EB851E0000000
  %4395 = fadd fast float %4392, 0x3F9EB851E0000000
  %4396 = fadd fast float %4393, 0x3F9EB851E0000000
  %4397 = fmul fast float %4394, %4386
  %4398 = fmul fast float %4395, %4387
  %4399 = fmul fast float %4396, %4388
  %4400 = fmul fast float %4386, 0x400370A3E0000000
  %4401 = fmul fast float %4387, 0x400370A3E0000000
  %4402 = fmul fast float %4388, 0x400370A3E0000000
  %4403 = fadd fast float %4400, 0x3FE2E147A0000000
  %4404 = fadd fast float %4401, 0x3FE2E147A0000000
  %4405 = fadd fast float %4402, 0x3FE2E147A0000000
  %4406 = fmul fast float %4403, %4386
  %4407 = fmul fast float %4404, %4387
  %4408 = fmul fast float %4405, %4388
  %4409 = fadd fast float %4406, 0x3FC1EB8520000000
  %4410 = fadd fast float %4407, 0x3FC1EB8520000000
  %4411 = fadd fast float %4408, 0x3FC1EB8520000000
  %4412 = fdiv fast float %4397, %4409
  %4413 = fdiv fast float %4398, %4410
  %4414 = fdiv fast float %4399, %4411
  br label %4415

; <label>:4415                                    ; preds = %4390, %4376
  %4416 = phi float [ %4412, %4390 ], [ %4386, %4376 ]
  %4417 = phi float [ %4413, %4390 ], [ %4387, %4376 ]
  %4418 = phi float [ %4414, %4390 ], [ %4388, %4376 ]
  %4419 = call float @dx.op.unary.f32(i32 7, float %4416)  ; Saturate(value)
  %4420 = call float @dx.op.unary.f32(i32 7, float %4417)  ; Saturate(value)
  %4421 = call float @dx.op.unary.f32(i32 7, float %4418)  ; Saturate(value)
  %4422 = call float @dx.op.dot3.f32(i32 55, float %4419, float %4420, float %4421, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4423 = fsub fast float %4419, %4422
  %4424 = fsub fast float %4420, %4422
  %4425 = fsub fast float %4421, %4422
  %4426 = fmul fast float %4423, %8
  %4427 = fmul fast float %4424, %8
  %4428 = fmul fast float %4425, %8
  %4429 = fadd fast float %4426, %4422
  %4430 = fadd fast float %4427, %4422
  %4431 = fadd fast float %4428, %4422
  %4432 = call float @dx.op.unary.f32(i32 7, float %4429)  ; Saturate(value)
  %4433 = call float @dx.op.unary.f32(i32 7, float %4430)  ; Saturate(value)
  %4434 = call float @dx.op.unary.f32(i32 7, float %4431)  ; Saturate(value)
  %4435 = fadd fast float %4432, 0xBFC70A3D80000000
  %4436 = fadd fast float %4433, 0xBFC70A3D80000000
  %4437 = fadd fast float %4434, 0xBFC70A3D80000000
  %4438 = fmul fast float %4435, %7
  %4439 = fmul fast float %4436, %7
  %4440 = fmul fast float %4437, %7
  %4441 = fadd fast float %4438, 0x3FC70A3D80000000
  %4442 = fadd fast float %4439, 0x3FC70A3D80000000
  %4443 = fadd fast float %4440, 0x3FC70A3D80000000
  %4444 = call float @dx.op.unary.f32(i32 7, float %4441)  ; Saturate(value)
  %4445 = call float @dx.op.unary.f32(i32 7, float %4442)  ; Saturate(value)
  %4446 = call float @dx.op.unary.f32(i32 7, float %4443)  ; Saturate(value)
  br label %4447

; <label>:4447                                    ; preds = %4415, %4250
  %4448 = phi float [ %4281, %4250 ], [ %4444, %4415 ]
  %4449 = phi float [ %4282, %4250 ], [ %4445, %4415 ]
  %4450 = phi float [ %4283, %4250 ], [ %4446, %4415 ]
  %4451 = fsub fast float %4448, %4220
  %4452 = fsub fast float %4449, %4221
  %4453 = fsub fast float %4450, %4222
  %4454 = fmul fast float %4451, %4237
  %4455 = fmul fast float %4452, %4237
  %4456 = fmul fast float %4453, %4237
  %4457 = fadd fast float %4454, %4220
  %4458 = fadd fast float %4455, %4221
  %4459 = fadd fast float %4456, %4222
  br label %4460

; <label>:4460                                    ; preds = %4447, %4191
  %4461 = phi float [ %4457, %4447 ], [ %4220, %4191 ]
  %4462 = phi float [ %4458, %4447 ], [ %4221, %4191 ]
  %4463 = phi float [ %4459, %4447 ], [ %4222, %4191 ]
  %4464 = add i32 %70, 1
  %4465 = call i32 @dx.op.binary.i32(i32 37, i32 %4464, i32 0)  ; IMax(a,b)
  %4466 = call i32 @dx.op.binary.i32(i32 38, i32 %4465, i32 %60)  ; IMin(a,b)
  %4467 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4226, i32 %4466, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4468 = extractvalue %dx.types.ResRet.f32 %4467, 0
  %4469 = fsub fast float %4468, %88
  %4470 = call float @dx.op.unary.f32(i32 6, float %4469)  ; FAbs(value)
  %4471 = fdiv fast float %4470, %4232
  %4472 = fsub fast float 1.000000e+00, %4471
  %4473 = call float @dx.op.unary.f32(i32 7, float %4472)  ; Saturate(value)
  %4474 = fcmp fast ugt float %4473, 0.000000e+00
  br i1 %4474, label %4475, label %4696

; <label>:4475                                    ; preds = %4460
  %4476 = call i32 @dx.op.binary.i32(i32 37, i32 %4226, i32 0)  ; IMax(a,b)
  %4477 = call i32 @dx.op.binary.i32(i32 37, i32 %4466, i32 0)  ; IMax(a,b)
  %4478 = call i32 @dx.op.binary.i32(i32 38, i32 %4476, i32 %59)  ; IMin(a,b)
  %4479 = call i32 @dx.op.binary.i32(i32 38, i32 %4477, i32 %60)  ; IMin(a,b)
  %4480 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4478, i32 %4479, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4481 = extractvalue %dx.types.ResRet.f32 %4480, 0
  %4482 = extractvalue %dx.types.ResRet.f32 %4480, 1
  %4483 = extractvalue %dx.types.ResRet.f32 %4480, 2
  %4484 = extractvalue %dx.types.ResRet.f32 %4480, 3
  %4485 = fcmp fast olt float %4484, 0.000000e+00
  br i1 %4485, label %4486, label %4520

; <label>:4486                                    ; preds = %4475
  %4487 = fcmp fast ogt float %4481, 0x3FA4B5DCC0000000
  %4488 = fcmp fast ogt float %4482, 0x3FA4B5DCC0000000
  %4489 = fcmp fast ogt float %4483, 0x3FA4B5DCC0000000
  %4490 = select i1 %4487, float 0.000000e+00, float 1.000000e+00
  %4491 = select i1 %4488, float 0.000000e+00, float 1.000000e+00
  %4492 = select i1 %4489, float 0.000000e+00, float 1.000000e+00
  %4493 = fmul fast float %4481, 0x3FB3D07220000000
  %4494 = fmul fast float %4482, 0x3FB3D07220000000
  %4495 = fmul fast float %4483, 0x3FB3D07220000000
  %4496 = fadd fast float %4481, 0x3FAC28F5C0000000
  %4497 = fadd fast float %4482, 0x3FAC28F5C0000000
  %4498 = fadd fast float %4483, 0x3FAC28F5C0000000
  %4499 = fmul fast float %4496, 0x3FEE54EDE0000000
  %4500 = fmul fast float %4497, 0x3FEE54EDE0000000
  %4501 = fmul fast float %4498, 0x3FEE54EDE0000000
  %4502 = call float @dx.op.unary.f32(i32 23, float %4499)  ; Log(value)
  %4503 = call float @dx.op.unary.f32(i32 23, float %4500)  ; Log(value)
  %4504 = call float @dx.op.unary.f32(i32 23, float %4501)  ; Log(value)
  %4505 = fmul fast float %4502, 0x4003333340000000
  %4506 = fmul fast float %4503, 0x4003333340000000
  %4507 = fmul fast float %4504, 0x4003333340000000
  %4508 = call float @dx.op.unary.f32(i32 21, float %4505)  ; Exp(value)
  %4509 = call float @dx.op.unary.f32(i32 21, float %4506)  ; Exp(value)
  %4510 = call float @dx.op.unary.f32(i32 21, float %4507)  ; Exp(value)
  %4511 = fsub fast float %4493, %4508
  %4512 = fsub fast float %4494, %4509
  %4513 = fsub fast float %4495, %4510
  %4514 = fmul fast float %4511, %4490
  %4515 = fmul fast float %4512, %4491
  %4516 = fmul fast float %4513, %4492
  %4517 = fadd fast float %4514, %4508
  %4518 = fadd fast float %4515, %4509
  %4519 = fadd fast float %4516, %4510
  br label %4683

; <label>:4520                                    ; preds = %4475
  %4521 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4478, i32 %4479, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4522 = extractvalue %dx.types.ResRet.f32 %4521, 0
  %4523 = fcmp fast ogt float %38, 5.000000e-01
  %4524 = fcmp fast olt float %4522, 1.000000e+00
  %4525 = and i1 %4523, %4524
  br i1 %4525, label %4526, label %4612

; <label>:4526                                    ; preds = %4520
  %4527 = sitofp i32 %4478 to float
  %4528 = sitofp i32 %4479 to float
  %4529 = fadd fast float %4527, 5.000000e-01
  %4530 = fadd fast float %4528, 5.000000e-01
  %4531 = fdiv fast float %4529, %45
  %4532 = fdiv fast float %4530, %46
  %4533 = fmul fast float %4531, 2.000000e+00
  %4534 = fmul fast float %4532, 2.000000e+00
  %4535 = fadd fast float %4533, -1.000000e+00
  %4536 = fsub fast float 1.000000e+00, %4534
  %4537 = fmul fast float %4535, %35
  %4538 = call float @dx.op.tertiary.f32(i32 46, float %4536, float %31, float %4537)  ; FMad(a,b,c)
  %4539 = call float @dx.op.tertiary.f32(i32 46, float %4522, float %27, float %4538)  ; FMad(a,b,c)
  %4540 = fadd fast float %4539, %23
  %4541 = call float @dx.op.unary.f32(i32 6, float %4540)  ; FAbs(value)
  %4542 = fcmp fast ogt float %4541, 0x3EB0C6F7A0000000
  br i1 %4542, label %4543, label %4612

; <label>:4543                                    ; preds = %4526
  %4544 = fmul fast float %4535, %34
  %4545 = call float @dx.op.tertiary.f32(i32 46, float %4536, float %30, float %4544)  ; FMad(a,b,c)
  %4546 = call float @dx.op.tertiary.f32(i32 46, float %4522, float %26, float %4545)  ; FMad(a,b,c)
  %4547 = fadd fast float %4546, %22
  %4548 = fmul fast float %4535, %33
  %4549 = call float @dx.op.tertiary.f32(i32 46, float %4536, float %29, float %4548)  ; FMad(a,b,c)
  %4550 = call float @dx.op.tertiary.f32(i32 46, float %4522, float %25, float %4549)  ; FMad(a,b,c)
  %4551 = fadd fast float %4550, %21
  %4552 = fmul fast float %4535, %32
  %4553 = call float @dx.op.tertiary.f32(i32 46, float %4536, float %28, float %4552)  ; FMad(a,b,c)
  %4554 = call float @dx.op.tertiary.f32(i32 46, float %4522, float %24, float %4553)  ; FMad(a,b,c)
  %4555 = fadd fast float %4554, %20
  %4556 = fdiv fast float %4555, %4540
  %4557 = fdiv fast float %4551, %4540
  %4558 = fdiv fast float %4547, %4540
  %4559 = fsub fast float %4556, %17
  %4560 = fsub fast float %4557, %18
  %4561 = fsub fast float %4558, %19
  %4562 = fmul fast float %4559, %4559
  %4563 = fmul fast float %4560, %4560
  %4564 = fadd fast float %4563, %4562
  %4565 = fmul fast float %4561, %4561
  %4566 = fadd fast float %4564, %4565
  %4567 = call float @dx.op.unary.f32(i32 24, float %4566)  ; Sqrt(value)
  %4568 = fsub fast float %4567, %9
  %4569 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4568)  ; FMax(a,b)
  %4570 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %4570, label %4571, label %4594

; <label>:4571                                    ; preds = %4543
  %4572 = call float @dx.op.unary.f32(i32 6, float %4560)  ; FAbs(value)
  %4573 = fmul fast float %4572, %11
  %4574 = fcmp fast olt float %4573, 0x3F50624DE0000000
  br i1 %4574, label %4575, label %4578

; <label>:4575                                    ; preds = %4571
  %4576 = fmul fast float %4573, 5.000000e-01
  %4577 = fsub fast float 1.000000e+00, %4576
  br label %4583

; <label>:4578                                    ; preds = %4571
  %4579 = fmul fast float %4573, 0xBFF7154760000000
  %4580 = call float @dx.op.unary.f32(i32 21, float %4579)  ; Exp(value)
  %4581 = fsub fast float 1.000000e+00, %4580
  %4582 = fdiv fast float %4581, %4573
  br label %4583

; <label>:4583                                    ; preds = %4578, %4575
  %4584 = phi float [ %4577, %4575 ], [ %4582, %4578 ]
  %4585 = call float @dx.op.binary.f32(i32 36, float %4557, float %18)  ; FMin(a,b)
  %4586 = fsub fast float %4585, %10
  %4587 = fmul fast float %11, %4586
  %4588 = fsub fast float -0.000000e+00, %4587
  %4589 = call float @dx.op.binary.f32(i32 35, float %4588, float -4.000000e+01)  ; FMax(a,b)
  %4590 = call float @dx.op.binary.f32(i32 36, float %4589, float 5.000000e+00)  ; FMin(a,b)
  %4591 = fmul fast float %4590, 0x3FF7154760000000
  %4592 = call float @dx.op.unary.f32(i32 21, float %4591)  ; Exp(value)
  %4593 = fmul fast float %4592, %4584
  br label %4594

; <label>:4594                                    ; preds = %4583, %4543
  %4595 = phi float [ %4593, %4583 ], [ 1.000000e+00, %4543 ]
  %4596 = fmul fast float %4569, %16
  %4597 = fmul fast float %4596, %4595
  %4598 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4597)  ; FMin(a,b)
  %4599 = fmul fast float %4598, 0xBFF7154760000000
  %4600 = call float @dx.op.unary.f32(i32 21, float %4599)  ; Exp(value)
  %4601 = fsub fast float 1.000000e+00, %4600
  %4602 = call float @dx.op.binary.f32(i32 36, float %12, float %4601)  ; FMin(a,b)
  %4603 = fsub fast float %13, %4481
  %4604 = fsub fast float %14, %4482
  %4605 = fsub fast float %15, %4483
  %4606 = fmul fast float %4602, %4603
  %4607 = fmul fast float %4602, %4604
  %4608 = fmul fast float %4602, %4605
  %4609 = fadd fast float %4606, %4481
  %4610 = fadd fast float %4607, %4482
  %4611 = fadd fast float %4608, %4483
  br label %4612

; <label>:4612                                    ; preds = %4594, %4526, %4520
  %4613 = phi float [ %4609, %4594 ], [ %4481, %4526 ], [ %4481, %4520 ]
  %4614 = phi float [ %4610, %4594 ], [ %4482, %4526 ], [ %4482, %4520 ]
  %4615 = phi float [ %4611, %4594 ], [ %4483, %4526 ], [ %4483, %4520 ]
  %4616 = fadd fast float %5, 1.000000e+00
  %4617 = fadd fast float %6, 1.000000e+00
  %4618 = fsub fast float 1.000000e+00, %5
  %4619 = fmul fast float %36, %4616
  %4620 = fmul fast float %36, %4617
  %4621 = fmul fast float %36, %4618
  %4622 = fmul fast float %4619, %4613
  %4623 = fmul fast float %4620, %4614
  %4624 = fmul fast float %4621, %4615
  %4625 = fcmp fast ult float %37, 5.000000e-01
  br i1 %4625, label %4651, label %4626

; <label>:4626                                    ; preds = %4612
  %4627 = fmul fast float %4622, 0x4004147AE0000000
  %4628 = fmul fast float %4623, 0x4004147AE0000000
  %4629 = fmul fast float %4624, 0x4004147AE0000000
  %4630 = fadd fast float %4627, 0x3F9EB851E0000000
  %4631 = fadd fast float %4628, 0x3F9EB851E0000000
  %4632 = fadd fast float %4629, 0x3F9EB851E0000000
  %4633 = fmul fast float %4630, %4622
  %4634 = fmul fast float %4631, %4623
  %4635 = fmul fast float %4632, %4624
  %4636 = fmul fast float %4622, 0x400370A3E0000000
  %4637 = fmul fast float %4623, 0x400370A3E0000000
  %4638 = fmul fast float %4624, 0x400370A3E0000000
  %4639 = fadd fast float %4636, 0x3FE2E147A0000000
  %4640 = fadd fast float %4637, 0x3FE2E147A0000000
  %4641 = fadd fast float %4638, 0x3FE2E147A0000000
  %4642 = fmul fast float %4639, %4622
  %4643 = fmul fast float %4640, %4623
  %4644 = fmul fast float %4641, %4624
  %4645 = fadd fast float %4642, 0x3FC1EB8520000000
  %4646 = fadd fast float %4643, 0x3FC1EB8520000000
  %4647 = fadd fast float %4644, 0x3FC1EB8520000000
  %4648 = fdiv fast float %4633, %4645
  %4649 = fdiv fast float %4634, %4646
  %4650 = fdiv fast float %4635, %4647
  br label %4651

; <label>:4651                                    ; preds = %4626, %4612
  %4652 = phi float [ %4648, %4626 ], [ %4622, %4612 ]
  %4653 = phi float [ %4649, %4626 ], [ %4623, %4612 ]
  %4654 = phi float [ %4650, %4626 ], [ %4624, %4612 ]
  %4655 = call float @dx.op.unary.f32(i32 7, float %4652)  ; Saturate(value)
  %4656 = call float @dx.op.unary.f32(i32 7, float %4653)  ; Saturate(value)
  %4657 = call float @dx.op.unary.f32(i32 7, float %4654)  ; Saturate(value)
  %4658 = call float @dx.op.dot3.f32(i32 55, float %4655, float %4656, float %4657, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4659 = fsub fast float %4655, %4658
  %4660 = fsub fast float %4656, %4658
  %4661 = fsub fast float %4657, %4658
  %4662 = fmul fast float %4659, %8
  %4663 = fmul fast float %4660, %8
  %4664 = fmul fast float %4661, %8
  %4665 = fadd fast float %4662, %4658
  %4666 = fadd fast float %4663, %4658
  %4667 = fadd fast float %4664, %4658
  %4668 = call float @dx.op.unary.f32(i32 7, float %4665)  ; Saturate(value)
  %4669 = call float @dx.op.unary.f32(i32 7, float %4666)  ; Saturate(value)
  %4670 = call float @dx.op.unary.f32(i32 7, float %4667)  ; Saturate(value)
  %4671 = fadd fast float %4668, 0xBFC70A3D80000000
  %4672 = fadd fast float %4669, 0xBFC70A3D80000000
  %4673 = fadd fast float %4670, 0xBFC70A3D80000000
  %4674 = fmul fast float %4671, %7
  %4675 = fmul fast float %4672, %7
  %4676 = fmul fast float %4673, %7
  %4677 = fadd fast float %4674, 0x3FC70A3D80000000
  %4678 = fadd fast float %4675, 0x3FC70A3D80000000
  %4679 = fadd fast float %4676, 0x3FC70A3D80000000
  %4680 = call float @dx.op.unary.f32(i32 7, float %4677)  ; Saturate(value)
  %4681 = call float @dx.op.unary.f32(i32 7, float %4678)  ; Saturate(value)
  %4682 = call float @dx.op.unary.f32(i32 7, float %4679)  ; Saturate(value)
  br label %4683

; <label>:4683                                    ; preds = %4651, %4486
  %4684 = phi float [ %4517, %4486 ], [ %4680, %4651 ]
  %4685 = phi float [ %4518, %4486 ], [ %4681, %4651 ]
  %4686 = phi float [ %4519, %4486 ], [ %4682, %4651 ]
  %4687 = fsub fast float %4684, %4220
  %4688 = fsub fast float %4685, %4221
  %4689 = fsub fast float %4686, %4222
  %4690 = fmul fast float %4687, %4473
  %4691 = fmul fast float %4688, %4473
  %4692 = fmul fast float %4689, %4473
  %4693 = fadd fast float %4690, %4220
  %4694 = fadd fast float %4691, %4221
  %4695 = fadd fast float %4692, %4222
  br label %4696

; <label>:4696                                    ; preds = %4683, %4460
  %4697 = phi float [ %4693, %4683 ], [ %4220, %4460 ]
  %4698 = phi float [ %4694, %4683 ], [ %4221, %4460 ]
  %4699 = phi float [ %4695, %4683 ], [ %4222, %4460 ]
  %4700 = add i32 %67, -1
  %4701 = call i32 @dx.op.binary.i32(i32 37, i32 %4700, i32 0)  ; IMax(a,b)
  %4702 = call i32 @dx.op.binary.i32(i32 37, i32 %70, i32 0)  ; IMax(a,b)
  %4703 = call i32 @dx.op.binary.i32(i32 38, i32 %4701, i32 %59)  ; IMin(a,b)
  %4704 = call i32 @dx.op.binary.i32(i32 38, i32 %4702, i32 %60)  ; IMin(a,b)
  %4705 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4703, i32 %4704, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4706 = extractvalue %dx.types.ResRet.f32 %4705, 0
  %4707 = fsub fast float %4706, %88
  %4708 = call float @dx.op.unary.f32(i32 6, float %4707)  ; FAbs(value)
  %4709 = fdiv fast float %4708, %4232
  %4710 = fsub fast float 1.000000e+00, %4709
  %4711 = call float @dx.op.unary.f32(i32 7, float %4710)  ; Saturate(value)
  %4712 = fcmp fast ugt float %4711, 0.000000e+00
  br i1 %4712, label %4713, label %4934

; <label>:4713                                    ; preds = %4696
  %4714 = call i32 @dx.op.binary.i32(i32 37, i32 %4703, i32 0)  ; IMax(a,b)
  %4715 = call i32 @dx.op.binary.i32(i32 37, i32 %4704, i32 0)  ; IMax(a,b)
  %4716 = call i32 @dx.op.binary.i32(i32 38, i32 %4714, i32 %59)  ; IMin(a,b)
  %4717 = call i32 @dx.op.binary.i32(i32 38, i32 %4715, i32 %60)  ; IMin(a,b)
  %4718 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4716, i32 %4717, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4719 = extractvalue %dx.types.ResRet.f32 %4718, 0
  %4720 = extractvalue %dx.types.ResRet.f32 %4718, 1
  %4721 = extractvalue %dx.types.ResRet.f32 %4718, 2
  %4722 = extractvalue %dx.types.ResRet.f32 %4718, 3
  %4723 = fcmp fast olt float %4722, 0.000000e+00
  br i1 %4723, label %4724, label %4758

; <label>:4724                                    ; preds = %4713
  %4725 = fcmp fast ogt float %4719, 0x3FA4B5DCC0000000
  %4726 = fcmp fast ogt float %4720, 0x3FA4B5DCC0000000
  %4727 = fcmp fast ogt float %4721, 0x3FA4B5DCC0000000
  %4728 = select i1 %4725, float 0.000000e+00, float 1.000000e+00
  %4729 = select i1 %4726, float 0.000000e+00, float 1.000000e+00
  %4730 = select i1 %4727, float 0.000000e+00, float 1.000000e+00
  %4731 = fmul fast float %4719, 0x3FB3D07220000000
  %4732 = fmul fast float %4720, 0x3FB3D07220000000
  %4733 = fmul fast float %4721, 0x3FB3D07220000000
  %4734 = fadd fast float %4719, 0x3FAC28F5C0000000
  %4735 = fadd fast float %4720, 0x3FAC28F5C0000000
  %4736 = fadd fast float %4721, 0x3FAC28F5C0000000
  %4737 = fmul fast float %4734, 0x3FEE54EDE0000000
  %4738 = fmul fast float %4735, 0x3FEE54EDE0000000
  %4739 = fmul fast float %4736, 0x3FEE54EDE0000000
  %4740 = call float @dx.op.unary.f32(i32 23, float %4737)  ; Log(value)
  %4741 = call float @dx.op.unary.f32(i32 23, float %4738)  ; Log(value)
  %4742 = call float @dx.op.unary.f32(i32 23, float %4739)  ; Log(value)
  %4743 = fmul fast float %4740, 0x4003333340000000
  %4744 = fmul fast float %4741, 0x4003333340000000
  %4745 = fmul fast float %4742, 0x4003333340000000
  %4746 = call float @dx.op.unary.f32(i32 21, float %4743)  ; Exp(value)
  %4747 = call float @dx.op.unary.f32(i32 21, float %4744)  ; Exp(value)
  %4748 = call float @dx.op.unary.f32(i32 21, float %4745)  ; Exp(value)
  %4749 = fsub fast float %4731, %4746
  %4750 = fsub fast float %4732, %4747
  %4751 = fsub fast float %4733, %4748
  %4752 = fmul fast float %4749, %4728
  %4753 = fmul fast float %4750, %4729
  %4754 = fmul fast float %4751, %4730
  %4755 = fadd fast float %4752, %4746
  %4756 = fadd fast float %4753, %4747
  %4757 = fadd fast float %4754, %4748
  br label %4921

; <label>:4758                                    ; preds = %4713
  %4759 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4716, i32 %4717, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4760 = extractvalue %dx.types.ResRet.f32 %4759, 0
  %4761 = fcmp fast ogt float %38, 5.000000e-01
  %4762 = fcmp fast olt float %4760, 1.000000e+00
  %4763 = and i1 %4761, %4762
  br i1 %4763, label %4764, label %4850

; <label>:4764                                    ; preds = %4758
  %4765 = sitofp i32 %4716 to float
  %4766 = sitofp i32 %4717 to float
  %4767 = fadd fast float %4765, 5.000000e-01
  %4768 = fadd fast float %4766, 5.000000e-01
  %4769 = fdiv fast float %4767, %45
  %4770 = fdiv fast float %4768, %46
  %4771 = fmul fast float %4769, 2.000000e+00
  %4772 = fmul fast float %4770, 2.000000e+00
  %4773 = fadd fast float %4771, -1.000000e+00
  %4774 = fsub fast float 1.000000e+00, %4772
  %4775 = fmul fast float %4773, %35
  %4776 = call float @dx.op.tertiary.f32(i32 46, float %4774, float %31, float %4775)  ; FMad(a,b,c)
  %4777 = call float @dx.op.tertiary.f32(i32 46, float %4760, float %27, float %4776)  ; FMad(a,b,c)
  %4778 = fadd fast float %4777, %23
  %4779 = call float @dx.op.unary.f32(i32 6, float %4778)  ; FAbs(value)
  %4780 = fcmp fast ogt float %4779, 0x3EB0C6F7A0000000
  br i1 %4780, label %4781, label %4850

; <label>:4781                                    ; preds = %4764
  %4782 = fmul fast float %4773, %34
  %4783 = call float @dx.op.tertiary.f32(i32 46, float %4774, float %30, float %4782)  ; FMad(a,b,c)
  %4784 = call float @dx.op.tertiary.f32(i32 46, float %4760, float %26, float %4783)  ; FMad(a,b,c)
  %4785 = fadd fast float %4784, %22
  %4786 = fmul fast float %4773, %33
  %4787 = call float @dx.op.tertiary.f32(i32 46, float %4774, float %29, float %4786)  ; FMad(a,b,c)
  %4788 = call float @dx.op.tertiary.f32(i32 46, float %4760, float %25, float %4787)  ; FMad(a,b,c)
  %4789 = fadd fast float %4788, %21
  %4790 = fmul fast float %4773, %32
  %4791 = call float @dx.op.tertiary.f32(i32 46, float %4774, float %28, float %4790)  ; FMad(a,b,c)
  %4792 = call float @dx.op.tertiary.f32(i32 46, float %4760, float %24, float %4791)  ; FMad(a,b,c)
  %4793 = fadd fast float %4792, %20
  %4794 = fdiv fast float %4793, %4778
  %4795 = fdiv fast float %4789, %4778
  %4796 = fdiv fast float %4785, %4778
  %4797 = fsub fast float %4794, %17
  %4798 = fsub fast float %4795, %18
  %4799 = fsub fast float %4796, %19
  %4800 = fmul fast float %4797, %4797
  %4801 = fmul fast float %4798, %4798
  %4802 = fadd fast float %4801, %4800
  %4803 = fmul fast float %4799, %4799
  %4804 = fadd fast float %4802, %4803
  %4805 = call float @dx.op.unary.f32(i32 24, float %4804)  ; Sqrt(value)
  %4806 = fsub fast float %4805, %9
  %4807 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4806)  ; FMax(a,b)
  %4808 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %4808, label %4809, label %4832

; <label>:4809                                    ; preds = %4781
  %4810 = call float @dx.op.unary.f32(i32 6, float %4798)  ; FAbs(value)
  %4811 = fmul fast float %4810, %11
  %4812 = fcmp fast olt float %4811, 0x3F50624DE0000000
  br i1 %4812, label %4813, label %4816

; <label>:4813                                    ; preds = %4809
  %4814 = fmul fast float %4811, 5.000000e-01
  %4815 = fsub fast float 1.000000e+00, %4814
  br label %4821

; <label>:4816                                    ; preds = %4809
  %4817 = fmul fast float %4811, 0xBFF7154760000000
  %4818 = call float @dx.op.unary.f32(i32 21, float %4817)  ; Exp(value)
  %4819 = fsub fast float 1.000000e+00, %4818
  %4820 = fdiv fast float %4819, %4811
  br label %4821

; <label>:4821                                    ; preds = %4816, %4813
  %4822 = phi float [ %4815, %4813 ], [ %4820, %4816 ]
  %4823 = call float @dx.op.binary.f32(i32 36, float %4795, float %18)  ; FMin(a,b)
  %4824 = fsub fast float %4823, %10
  %4825 = fmul fast float %11, %4824
  %4826 = fsub fast float -0.000000e+00, %4825
  %4827 = call float @dx.op.binary.f32(i32 35, float %4826, float -4.000000e+01)  ; FMax(a,b)
  %4828 = call float @dx.op.binary.f32(i32 36, float %4827, float 5.000000e+00)  ; FMin(a,b)
  %4829 = fmul fast float %4828, 0x3FF7154760000000
  %4830 = call float @dx.op.unary.f32(i32 21, float %4829)  ; Exp(value)
  %4831 = fmul fast float %4830, %4822
  br label %4832

; <label>:4832                                    ; preds = %4821, %4781
  %4833 = phi float [ %4831, %4821 ], [ 1.000000e+00, %4781 ]
  %4834 = fmul fast float %4807, %16
  %4835 = fmul fast float %4834, %4833
  %4836 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4835)  ; FMin(a,b)
  %4837 = fmul fast float %4836, 0xBFF7154760000000
  %4838 = call float @dx.op.unary.f32(i32 21, float %4837)  ; Exp(value)
  %4839 = fsub fast float 1.000000e+00, %4838
  %4840 = call float @dx.op.binary.f32(i32 36, float %12, float %4839)  ; FMin(a,b)
  %4841 = fsub fast float %13, %4719
  %4842 = fsub fast float %14, %4720
  %4843 = fsub fast float %15, %4721
  %4844 = fmul fast float %4840, %4841
  %4845 = fmul fast float %4840, %4842
  %4846 = fmul fast float %4840, %4843
  %4847 = fadd fast float %4844, %4719
  %4848 = fadd fast float %4845, %4720
  %4849 = fadd fast float %4846, %4721
  br label %4850

; <label>:4850                                    ; preds = %4832, %4764, %4758
  %4851 = phi float [ %4847, %4832 ], [ %4719, %4764 ], [ %4719, %4758 ]
  %4852 = phi float [ %4848, %4832 ], [ %4720, %4764 ], [ %4720, %4758 ]
  %4853 = phi float [ %4849, %4832 ], [ %4721, %4764 ], [ %4721, %4758 ]
  %4854 = fadd fast float %5, 1.000000e+00
  %4855 = fadd fast float %6, 1.000000e+00
  %4856 = fsub fast float 1.000000e+00, %5
  %4857 = fmul fast float %36, %4854
  %4858 = fmul fast float %36, %4855
  %4859 = fmul fast float %36, %4856
  %4860 = fmul fast float %4857, %4851
  %4861 = fmul fast float %4858, %4852
  %4862 = fmul fast float %4859, %4853
  %4863 = fcmp fast ult float %37, 5.000000e-01
  br i1 %4863, label %4889, label %4864

; <label>:4864                                    ; preds = %4850
  %4865 = fmul fast float %4860, 0x4004147AE0000000
  %4866 = fmul fast float %4861, 0x4004147AE0000000
  %4867 = fmul fast float %4862, 0x4004147AE0000000
  %4868 = fadd fast float %4865, 0x3F9EB851E0000000
  %4869 = fadd fast float %4866, 0x3F9EB851E0000000
  %4870 = fadd fast float %4867, 0x3F9EB851E0000000
  %4871 = fmul fast float %4868, %4860
  %4872 = fmul fast float %4869, %4861
  %4873 = fmul fast float %4870, %4862
  %4874 = fmul fast float %4860, 0x400370A3E0000000
  %4875 = fmul fast float %4861, 0x400370A3E0000000
  %4876 = fmul fast float %4862, 0x400370A3E0000000
  %4877 = fadd fast float %4874, 0x3FE2E147A0000000
  %4878 = fadd fast float %4875, 0x3FE2E147A0000000
  %4879 = fadd fast float %4876, 0x3FE2E147A0000000
  %4880 = fmul fast float %4877, %4860
  %4881 = fmul fast float %4878, %4861
  %4882 = fmul fast float %4879, %4862
  %4883 = fadd fast float %4880, 0x3FC1EB8520000000
  %4884 = fadd fast float %4881, 0x3FC1EB8520000000
  %4885 = fadd fast float %4882, 0x3FC1EB8520000000
  %4886 = fdiv fast float %4871, %4883
  %4887 = fdiv fast float %4872, %4884
  %4888 = fdiv fast float %4873, %4885
  br label %4889

; <label>:4889                                    ; preds = %4864, %4850
  %4890 = phi float [ %4886, %4864 ], [ %4860, %4850 ]
  %4891 = phi float [ %4887, %4864 ], [ %4861, %4850 ]
  %4892 = phi float [ %4888, %4864 ], [ %4862, %4850 ]
  %4893 = call float @dx.op.unary.f32(i32 7, float %4890)  ; Saturate(value)
  %4894 = call float @dx.op.unary.f32(i32 7, float %4891)  ; Saturate(value)
  %4895 = call float @dx.op.unary.f32(i32 7, float %4892)  ; Saturate(value)
  %4896 = call float @dx.op.dot3.f32(i32 55, float %4893, float %4894, float %4895, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4897 = fsub fast float %4893, %4896
  %4898 = fsub fast float %4894, %4896
  %4899 = fsub fast float %4895, %4896
  %4900 = fmul fast float %4897, %8
  %4901 = fmul fast float %4898, %8
  %4902 = fmul fast float %4899, %8
  %4903 = fadd fast float %4900, %4896
  %4904 = fadd fast float %4901, %4896
  %4905 = fadd fast float %4902, %4896
  %4906 = call float @dx.op.unary.f32(i32 7, float %4903)  ; Saturate(value)
  %4907 = call float @dx.op.unary.f32(i32 7, float %4904)  ; Saturate(value)
  %4908 = call float @dx.op.unary.f32(i32 7, float %4905)  ; Saturate(value)
  %4909 = fadd fast float %4906, 0xBFC70A3D80000000
  %4910 = fadd fast float %4907, 0xBFC70A3D80000000
  %4911 = fadd fast float %4908, 0xBFC70A3D80000000
  %4912 = fmul fast float %4909, %7
  %4913 = fmul fast float %4910, %7
  %4914 = fmul fast float %4911, %7
  %4915 = fadd fast float %4912, 0x3FC70A3D80000000
  %4916 = fadd fast float %4913, 0x3FC70A3D80000000
  %4917 = fadd fast float %4914, 0x3FC70A3D80000000
  %4918 = call float @dx.op.unary.f32(i32 7, float %4915)  ; Saturate(value)
  %4919 = call float @dx.op.unary.f32(i32 7, float %4916)  ; Saturate(value)
  %4920 = call float @dx.op.unary.f32(i32 7, float %4917)  ; Saturate(value)
  br label %4921

; <label>:4921                                    ; preds = %4889, %4724
  %4922 = phi float [ %4755, %4724 ], [ %4918, %4889 ]
  %4923 = phi float [ %4756, %4724 ], [ %4919, %4889 ]
  %4924 = phi float [ %4757, %4724 ], [ %4920, %4889 ]
  %4925 = fsub fast float %4922, %4220
  %4926 = fsub fast float %4923, %4221
  %4927 = fsub fast float %4924, %4222
  %4928 = fmul fast float %4925, %4711
  %4929 = fmul fast float %4926, %4711
  %4930 = fmul fast float %4927, %4711
  %4931 = fadd fast float %4928, %4220
  %4932 = fadd fast float %4929, %4221
  %4933 = fadd fast float %4930, %4222
  br label %4934

; <label>:4934                                    ; preds = %4921, %4696
  %4935 = phi float [ %4931, %4921 ], [ %4220, %4696 ]
  %4936 = phi float [ %4932, %4921 ], [ %4221, %4696 ]
  %4937 = phi float [ %4933, %4921 ], [ %4222, %4696 ]
  %4938 = add i32 %67, 1
  %4939 = call i32 @dx.op.binary.i32(i32 37, i32 %4938, i32 0)  ; IMax(a,b)
  %4940 = call i32 @dx.op.binary.i32(i32 38, i32 %4939, i32 %59)  ; IMin(a,b)
  %4941 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4940, i32 %4704, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4942 = extractvalue %dx.types.ResRet.f32 %4941, 0
  %4943 = fsub fast float %4942, %88
  %4944 = call float @dx.op.unary.f32(i32 6, float %4943)  ; FAbs(value)
  %4945 = fdiv fast float %4944, %4232
  %4946 = fsub fast float 1.000000e+00, %4945
  %4947 = call float @dx.op.unary.f32(i32 7, float %4946)  ; Saturate(value)
  %4948 = fcmp fast ugt float %4947, 0.000000e+00
  br i1 %4948, label %4949, label %5170

; <label>:4949                                    ; preds = %4934
  %4950 = call i32 @dx.op.binary.i32(i32 37, i32 %4940, i32 0)  ; IMax(a,b)
  %4951 = call i32 @dx.op.binary.i32(i32 37, i32 %4704, i32 0)  ; IMax(a,b)
  %4952 = call i32 @dx.op.binary.i32(i32 38, i32 %4950, i32 %59)  ; IMin(a,b)
  %4953 = call i32 @dx.op.binary.i32(i32 38, i32 %4951, i32 %60)  ; IMin(a,b)
  %4954 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4952, i32 %4953, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4955 = extractvalue %dx.types.ResRet.f32 %4954, 0
  %4956 = extractvalue %dx.types.ResRet.f32 %4954, 1
  %4957 = extractvalue %dx.types.ResRet.f32 %4954, 2
  %4958 = extractvalue %dx.types.ResRet.f32 %4954, 3
  %4959 = fcmp fast olt float %4958, 0.000000e+00
  br i1 %4959, label %4960, label %4994

; <label>:4960                                    ; preds = %4949
  %4961 = fcmp fast ogt float %4955, 0x3FA4B5DCC0000000
  %4962 = fcmp fast ogt float %4956, 0x3FA4B5DCC0000000
  %4963 = fcmp fast ogt float %4957, 0x3FA4B5DCC0000000
  %4964 = select i1 %4961, float 0.000000e+00, float 1.000000e+00
  %4965 = select i1 %4962, float 0.000000e+00, float 1.000000e+00
  %4966 = select i1 %4963, float 0.000000e+00, float 1.000000e+00
  %4967 = fmul fast float %4955, 0x3FB3D07220000000
  %4968 = fmul fast float %4956, 0x3FB3D07220000000
  %4969 = fmul fast float %4957, 0x3FB3D07220000000
  %4970 = fadd fast float %4955, 0x3FAC28F5C0000000
  %4971 = fadd fast float %4956, 0x3FAC28F5C0000000
  %4972 = fadd fast float %4957, 0x3FAC28F5C0000000
  %4973 = fmul fast float %4970, 0x3FEE54EDE0000000
  %4974 = fmul fast float %4971, 0x3FEE54EDE0000000
  %4975 = fmul fast float %4972, 0x3FEE54EDE0000000
  %4976 = call float @dx.op.unary.f32(i32 23, float %4973)  ; Log(value)
  %4977 = call float @dx.op.unary.f32(i32 23, float %4974)  ; Log(value)
  %4978 = call float @dx.op.unary.f32(i32 23, float %4975)  ; Log(value)
  %4979 = fmul fast float %4976, 0x4003333340000000
  %4980 = fmul fast float %4977, 0x4003333340000000
  %4981 = fmul fast float %4978, 0x4003333340000000
  %4982 = call float @dx.op.unary.f32(i32 21, float %4979)  ; Exp(value)
  %4983 = call float @dx.op.unary.f32(i32 21, float %4980)  ; Exp(value)
  %4984 = call float @dx.op.unary.f32(i32 21, float %4981)  ; Exp(value)
  %4985 = fsub fast float %4967, %4982
  %4986 = fsub fast float %4968, %4983
  %4987 = fsub fast float %4969, %4984
  %4988 = fmul fast float %4985, %4964
  %4989 = fmul fast float %4986, %4965
  %4990 = fmul fast float %4987, %4966
  %4991 = fadd fast float %4988, %4982
  %4992 = fadd fast float %4989, %4983
  %4993 = fadd fast float %4990, %4984
  br label %5157

; <label>:4994                                    ; preds = %4949
  %4995 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4952, i32 %4953, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4996 = extractvalue %dx.types.ResRet.f32 %4995, 0
  %4997 = fcmp fast ogt float %38, 5.000000e-01
  %4998 = fcmp fast olt float %4996, 1.000000e+00
  %4999 = and i1 %4997, %4998
  br i1 %4999, label %5000, label %5086

; <label>:5000                                    ; preds = %4994
  %5001 = sitofp i32 %4952 to float
  %5002 = sitofp i32 %4953 to float
  %5003 = fadd fast float %5001, 5.000000e-01
  %5004 = fadd fast float %5002, 5.000000e-01
  %5005 = fdiv fast float %5003, %45
  %5006 = fdiv fast float %5004, %46
  %5007 = fmul fast float %5005, 2.000000e+00
  %5008 = fmul fast float %5006, 2.000000e+00
  %5009 = fadd fast float %5007, -1.000000e+00
  %5010 = fsub fast float 1.000000e+00, %5008
  %5011 = fmul fast float %5009, %35
  %5012 = call float @dx.op.tertiary.f32(i32 46, float %5010, float %31, float %5011)  ; FMad(a,b,c)
  %5013 = call float @dx.op.tertiary.f32(i32 46, float %4996, float %27, float %5012)  ; FMad(a,b,c)
  %5014 = fadd fast float %5013, %23
  %5015 = call float @dx.op.unary.f32(i32 6, float %5014)  ; FAbs(value)
  %5016 = fcmp fast ogt float %5015, 0x3EB0C6F7A0000000
  br i1 %5016, label %5017, label %5086

; <label>:5017                                    ; preds = %5000
  %5018 = fmul fast float %5009, %34
  %5019 = call float @dx.op.tertiary.f32(i32 46, float %5010, float %30, float %5018)  ; FMad(a,b,c)
  %5020 = call float @dx.op.tertiary.f32(i32 46, float %4996, float %26, float %5019)  ; FMad(a,b,c)
  %5021 = fadd fast float %5020, %22
  %5022 = fmul fast float %5009, %33
  %5023 = call float @dx.op.tertiary.f32(i32 46, float %5010, float %29, float %5022)  ; FMad(a,b,c)
  %5024 = call float @dx.op.tertiary.f32(i32 46, float %4996, float %25, float %5023)  ; FMad(a,b,c)
  %5025 = fadd fast float %5024, %21
  %5026 = fmul fast float %5009, %32
  %5027 = call float @dx.op.tertiary.f32(i32 46, float %5010, float %28, float %5026)  ; FMad(a,b,c)
  %5028 = call float @dx.op.tertiary.f32(i32 46, float %4996, float %24, float %5027)  ; FMad(a,b,c)
  %5029 = fadd fast float %5028, %20
  %5030 = fdiv fast float %5029, %5014
  %5031 = fdiv fast float %5025, %5014
  %5032 = fdiv fast float %5021, %5014
  %5033 = fsub fast float %5030, %17
  %5034 = fsub fast float %5031, %18
  %5035 = fsub fast float %5032, %19
  %5036 = fmul fast float %5033, %5033
  %5037 = fmul fast float %5034, %5034
  %5038 = fadd fast float %5037, %5036
  %5039 = fmul fast float %5035, %5035
  %5040 = fadd fast float %5038, %5039
  %5041 = call float @dx.op.unary.f32(i32 24, float %5040)  ; Sqrt(value)
  %5042 = fsub fast float %5041, %9
  %5043 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5042)  ; FMax(a,b)
  %5044 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %5044, label %5045, label %5068

; <label>:5045                                    ; preds = %5017
  %5046 = call float @dx.op.unary.f32(i32 6, float %5034)  ; FAbs(value)
  %5047 = fmul fast float %5046, %11
  %5048 = fcmp fast olt float %5047, 0x3F50624DE0000000
  br i1 %5048, label %5049, label %5052

; <label>:5049                                    ; preds = %5045
  %5050 = fmul fast float %5047, 5.000000e-01
  %5051 = fsub fast float 1.000000e+00, %5050
  br label %5057

; <label>:5052                                    ; preds = %5045
  %5053 = fmul fast float %5047, 0xBFF7154760000000
  %5054 = call float @dx.op.unary.f32(i32 21, float %5053)  ; Exp(value)
  %5055 = fsub fast float 1.000000e+00, %5054
  %5056 = fdiv fast float %5055, %5047
  br label %5057

; <label>:5057                                    ; preds = %5052, %5049
  %5058 = phi float [ %5051, %5049 ], [ %5056, %5052 ]
  %5059 = call float @dx.op.binary.f32(i32 36, float %5031, float %18)  ; FMin(a,b)
  %5060 = fsub fast float %5059, %10
  %5061 = fmul fast float %11, %5060
  %5062 = fsub fast float -0.000000e+00, %5061
  %5063 = call float @dx.op.binary.f32(i32 35, float %5062, float -4.000000e+01)  ; FMax(a,b)
  %5064 = call float @dx.op.binary.f32(i32 36, float %5063, float 5.000000e+00)  ; FMin(a,b)
  %5065 = fmul fast float %5064, 0x3FF7154760000000
  %5066 = call float @dx.op.unary.f32(i32 21, float %5065)  ; Exp(value)
  %5067 = fmul fast float %5066, %5058
  br label %5068

; <label>:5068                                    ; preds = %5057, %5017
  %5069 = phi float [ %5067, %5057 ], [ 1.000000e+00, %5017 ]
  %5070 = fmul fast float %5043, %16
  %5071 = fmul fast float %5070, %5069
  %5072 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %5071)  ; FMin(a,b)
  %5073 = fmul fast float %5072, 0xBFF7154760000000
  %5074 = call float @dx.op.unary.f32(i32 21, float %5073)  ; Exp(value)
  %5075 = fsub fast float 1.000000e+00, %5074
  %5076 = call float @dx.op.binary.f32(i32 36, float %12, float %5075)  ; FMin(a,b)
  %5077 = fsub fast float %13, %4955
  %5078 = fsub fast float %14, %4956
  %5079 = fsub fast float %15, %4957
  %5080 = fmul fast float %5076, %5077
  %5081 = fmul fast float %5076, %5078
  %5082 = fmul fast float %5076, %5079
  %5083 = fadd fast float %5080, %4955
  %5084 = fadd fast float %5081, %4956
  %5085 = fadd fast float %5082, %4957
  br label %5086

; <label>:5086                                    ; preds = %5068, %5000, %4994
  %5087 = phi float [ %5083, %5068 ], [ %4955, %5000 ], [ %4955, %4994 ]
  %5088 = phi float [ %5084, %5068 ], [ %4956, %5000 ], [ %4956, %4994 ]
  %5089 = phi float [ %5085, %5068 ], [ %4957, %5000 ], [ %4957, %4994 ]
  %5090 = fadd fast float %5, 1.000000e+00
  %5091 = fadd fast float %6, 1.000000e+00
  %5092 = fsub fast float 1.000000e+00, %5
  %5093 = fmul fast float %36, %5090
  %5094 = fmul fast float %36, %5091
  %5095 = fmul fast float %36, %5092
  %5096 = fmul fast float %5093, %5087
  %5097 = fmul fast float %5094, %5088
  %5098 = fmul fast float %5095, %5089
  %5099 = fcmp fast ult float %37, 5.000000e-01
  br i1 %5099, label %5125, label %5100

; <label>:5100                                    ; preds = %5086
  %5101 = fmul fast float %5096, 0x4004147AE0000000
  %5102 = fmul fast float %5097, 0x4004147AE0000000
  %5103 = fmul fast float %5098, 0x4004147AE0000000
  %5104 = fadd fast float %5101, 0x3F9EB851E0000000
  %5105 = fadd fast float %5102, 0x3F9EB851E0000000
  %5106 = fadd fast float %5103, 0x3F9EB851E0000000
  %5107 = fmul fast float %5104, %5096
  %5108 = fmul fast float %5105, %5097
  %5109 = fmul fast float %5106, %5098
  %5110 = fmul fast float %5096, 0x400370A3E0000000
  %5111 = fmul fast float %5097, 0x400370A3E0000000
  %5112 = fmul fast float %5098, 0x400370A3E0000000
  %5113 = fadd fast float %5110, 0x3FE2E147A0000000
  %5114 = fadd fast float %5111, 0x3FE2E147A0000000
  %5115 = fadd fast float %5112, 0x3FE2E147A0000000
  %5116 = fmul fast float %5113, %5096
  %5117 = fmul fast float %5114, %5097
  %5118 = fmul fast float %5115, %5098
  %5119 = fadd fast float %5116, 0x3FC1EB8520000000
  %5120 = fadd fast float %5117, 0x3FC1EB8520000000
  %5121 = fadd fast float %5118, 0x3FC1EB8520000000
  %5122 = fdiv fast float %5107, %5119
  %5123 = fdiv fast float %5108, %5120
  %5124 = fdiv fast float %5109, %5121
  br label %5125

; <label>:5125                                    ; preds = %5100, %5086
  %5126 = phi float [ %5122, %5100 ], [ %5096, %5086 ]
  %5127 = phi float [ %5123, %5100 ], [ %5097, %5086 ]
  %5128 = phi float [ %5124, %5100 ], [ %5098, %5086 ]
  %5129 = call float @dx.op.unary.f32(i32 7, float %5126)  ; Saturate(value)
  %5130 = call float @dx.op.unary.f32(i32 7, float %5127)  ; Saturate(value)
  %5131 = call float @dx.op.unary.f32(i32 7, float %5128)  ; Saturate(value)
  %5132 = call float @dx.op.dot3.f32(i32 55, float %5129, float %5130, float %5131, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5133 = fsub fast float %5129, %5132
  %5134 = fsub fast float %5130, %5132
  %5135 = fsub fast float %5131, %5132
  %5136 = fmul fast float %5133, %8
  %5137 = fmul fast float %5134, %8
  %5138 = fmul fast float %5135, %8
  %5139 = fadd fast float %5136, %5132
  %5140 = fadd fast float %5137, %5132
  %5141 = fadd fast float %5138, %5132
  %5142 = call float @dx.op.unary.f32(i32 7, float %5139)  ; Saturate(value)
  %5143 = call float @dx.op.unary.f32(i32 7, float %5140)  ; Saturate(value)
  %5144 = call float @dx.op.unary.f32(i32 7, float %5141)  ; Saturate(value)
  %5145 = fadd fast float %5142, 0xBFC70A3D80000000
  %5146 = fadd fast float %5143, 0xBFC70A3D80000000
  %5147 = fadd fast float %5144, 0xBFC70A3D80000000
  %5148 = fmul fast float %5145, %7
  %5149 = fmul fast float %5146, %7
  %5150 = fmul fast float %5147, %7
  %5151 = fadd fast float %5148, 0x3FC70A3D80000000
  %5152 = fadd fast float %5149, 0x3FC70A3D80000000
  %5153 = fadd fast float %5150, 0x3FC70A3D80000000
  %5154 = call float @dx.op.unary.f32(i32 7, float %5151)  ; Saturate(value)
  %5155 = call float @dx.op.unary.f32(i32 7, float %5152)  ; Saturate(value)
  %5156 = call float @dx.op.unary.f32(i32 7, float %5153)  ; Saturate(value)
  br label %5157

; <label>:5157                                    ; preds = %5125, %4960
  %5158 = phi float [ %4991, %4960 ], [ %5154, %5125 ]
  %5159 = phi float [ %4992, %4960 ], [ %5155, %5125 ]
  %5160 = phi float [ %4993, %4960 ], [ %5156, %5125 ]
  %5161 = fsub fast float %5158, %4220
  %5162 = fsub fast float %5159, %4221
  %5163 = fsub fast float %5160, %4222
  %5164 = fmul fast float %5161, %4947
  %5165 = fmul fast float %5162, %4947
  %5166 = fmul fast float %5163, %4947
  %5167 = fadd fast float %5164, %4220
  %5168 = fadd fast float %5165, %4221
  %5169 = fadd fast float %5166, %4222
  br label %5170

; <label>:5170                                    ; preds = %5157, %4934
  %5171 = phi float [ %5167, %5157 ], [ %4220, %4934 ]
  %5172 = phi float [ %5168, %5157 ], [ %4221, %4934 ]
  %5173 = phi float [ %5169, %5157 ], [ %4222, %4934 ]
  %5174 = call float @dx.op.binary.f32(i32 36, float %4935, float %5171)  ; FMin(a,b)
  %5175 = call float @dx.op.binary.f32(i32 36, float %4936, float %5172)  ; FMin(a,b)
  %5176 = call float @dx.op.binary.f32(i32 36, float %4937, float %5173)  ; FMin(a,b)
  %5177 = call float @dx.op.binary.f32(i32 36, float %4461, float %4697)  ; FMin(a,b)
  %5178 = call float @dx.op.binary.f32(i32 36, float %4462, float %4698)  ; FMin(a,b)
  %5179 = call float @dx.op.binary.f32(i32 36, float %4463, float %4699)  ; FMin(a,b)
  %5180 = call float @dx.op.binary.f32(i32 36, float %5177, float %5174)  ; FMin(a,b)
  %5181 = call float @dx.op.binary.f32(i32 36, float %5178, float %5175)  ; FMin(a,b)
  %5182 = call float @dx.op.binary.f32(i32 36, float %5179, float %5176)  ; FMin(a,b)
  %5183 = call float @dx.op.binary.f32(i32 36, float %4220, float %5180)  ; FMin(a,b)
  %5184 = call float @dx.op.binary.f32(i32 36, float %4221, float %5181)  ; FMin(a,b)
  %5185 = call float @dx.op.binary.f32(i32 36, float %4222, float %5182)  ; FMin(a,b)
  %5186 = call float @dx.op.binary.f32(i32 35, float %4935, float %5171)  ; FMax(a,b)
  %5187 = call float @dx.op.binary.f32(i32 35, float %4936, float %5172)  ; FMax(a,b)
  %5188 = call float @dx.op.binary.f32(i32 35, float %4937, float %5173)  ; FMax(a,b)
  %5189 = call float @dx.op.binary.f32(i32 35, float %4461, float %4697)  ; FMax(a,b)
  %5190 = call float @dx.op.binary.f32(i32 35, float %4462, float %4698)  ; FMax(a,b)
  %5191 = call float @dx.op.binary.f32(i32 35, float %4463, float %4699)  ; FMax(a,b)
  %5192 = call float @dx.op.binary.f32(i32 35, float %5189, float %5186)  ; FMax(a,b)
  %5193 = call float @dx.op.binary.f32(i32 35, float %5190, float %5187)  ; FMax(a,b)
  %5194 = call float @dx.op.binary.f32(i32 35, float %5191, float %5188)  ; FMax(a,b)
  %5195 = call float @dx.op.binary.f32(i32 35, float %4220, float %5192)  ; FMax(a,b)
  %5196 = call float @dx.op.binary.f32(i32 35, float %4221, float %5193)  ; FMax(a,b)
  %5197 = call float @dx.op.binary.f32(i32 35, float %4222, float %5194)  ; FMax(a,b)
  %5198 = fsub fast float %5195, %5183
  %5199 = fsub fast float %5196, %5184
  %5200 = fsub fast float %5197, %5185
  %5201 = call float @dx.op.unary.f32(i32 6, float %5198)  ; FAbs(value)
  %5202 = call float @dx.op.unary.f32(i32 6, float %5199)  ; FAbs(value)
  %5203 = call float @dx.op.unary.f32(i32 6, float %5200)  ; FAbs(value)
  %5204 = call float @dx.op.binary.f32(i32 35, float %5202, float %5203)  ; FMax(a,b)
  %5205 = call float @dx.op.binary.f32(i32 35, float %5201, float %5204)  ; FMax(a,b)
  %5206 = call float @dx.op.binary.f32(i32 35, float %5196, float %5197)  ; FMax(a,b)
  %5207 = call float @dx.op.binary.f32(i32 35, float %5195, float %5206)  ; FMax(a,b)
  %5208 = fmul fast float %5207, 1.250000e-01
  %5209 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %5208)  ; FMax(a,b)
  %5210 = fcmp fast ogt float %5205, %5209
  br i1 %5210, label %5211, label %5272

; <label>:5211                                    ; preds = %5170
  %5212 = fsub fast float %4461, %4697
  %5213 = fsub fast float %4462, %4698
  %5214 = fsub fast float %4463, %4699
  %5215 = call float @dx.op.unary.f32(i32 6, float %5212)  ; FAbs(value)
  %5216 = call float @dx.op.unary.f32(i32 6, float %5213)  ; FAbs(value)
  %5217 = call float @dx.op.unary.f32(i32 6, float %5214)  ; FAbs(value)
  %5218 = call float @dx.op.binary.f32(i32 35, float %5216, float %5217)  ; FMax(a,b)
  %5219 = call float @dx.op.binary.f32(i32 35, float %5215, float %5218)  ; FMax(a,b)
  %5220 = fsub fast float %4935, %5171
  %5221 = fsub fast float %4936, %5172
  %5222 = fsub fast float %4937, %5173
  %5223 = call float @dx.op.unary.f32(i32 6, float %5220)  ; FAbs(value)
  %5224 = call float @dx.op.unary.f32(i32 6, float %5221)  ; FAbs(value)
  %5225 = call float @dx.op.unary.f32(i32 6, float %5222)  ; FAbs(value)
  %5226 = call float @dx.op.binary.f32(i32 35, float %5224, float %5225)  ; FMax(a,b)
  %5227 = call float @dx.op.binary.f32(i32 35, float %5223, float %5226)  ; FMax(a,b)
  %5228 = fcmp fast olt float %5219, %5227
  %5229 = select i1 %5228, float %4461, float %4935
  %5230 = select i1 %5228, float %4462, float %4936
  %5231 = select i1 %5228, float %4463, float %4937
  %5232 = select i1 %5228, float %4697, float %5171
  %5233 = select i1 %5228, float %4698, float %5172
  %5234 = select i1 %5228, float %4699, float %5173
  %5235 = fsub fast float %4220, %5232
  %5236 = fsub fast float %4221, %5233
  %5237 = fsub fast float %4222, %5234
  %5238 = fsub fast float %4220, %5229
  %5239 = fsub fast float %4221, %5230
  %5240 = fsub fast float %4222, %5231
  %5241 = call float @dx.op.dot3.f32(i32 55, float %5238, float %5239, float %5240, float %5235, float %5236, float %5237)  ; Dot3(ax,ay,az,bx,by,bz)
  %5242 = fcmp fast ogt float %5241, 0.000000e+00
  br i1 %5242, label %5243, label %5255

; <label>:5243                                    ; preds = %5211
  %5244 = fsub fast float %5229, %5232
  %5245 = fsub fast float %5230, %5233
  %5246 = fsub fast float %5231, %5234
  %5247 = call float @dx.op.unary.f32(i32 6, float %5244)  ; FAbs(value)
  %5248 = call float @dx.op.unary.f32(i32 6, float %5245)  ; FAbs(value)
  %5249 = call float @dx.op.unary.f32(i32 6, float %5246)  ; FAbs(value)
  %5250 = call float @dx.op.binary.f32(i32 35, float %5248, float %5249)  ; FMax(a,b)
  %5251 = call float @dx.op.binary.f32(i32 35, float %5247, float %5250)  ; FMax(a,b)
  %5252 = fmul fast float %5205, 2.500000e-01
  %5253 = fcmp fast olt float %5251, %5252
  %5254 = select i1 %5253, float 0x3FC3333340000000, float 0x3FD3333340000000
  br label %5255

; <label>:5255                                    ; preds = %5243, %5211
  %5256 = phi float [ 0x3FD3333340000000, %5211 ], [ %5254, %5243 ]
  %5257 = fadd fast float %5229, %5232
  %5258 = fadd fast float %5230, %5233
  %5259 = fadd fast float %5231, %5234
  %5260 = fmul fast float %5257, 5.000000e-01
  %5261 = fmul fast float %5258, 5.000000e-01
  %5262 = fmul fast float %5259, 5.000000e-01
  %5263 = fsub fast float %5260, %4220
  %5264 = fsub fast float %5261, %4221
  %5265 = fsub fast float %5262, %4222
  %5266 = fmul fast float %5256, %5263
  %5267 = fmul fast float %5256, %5264
  %5268 = fmul fast float %5256, %5265
  %5269 = fadd fast float %5266, %4220
  %5270 = fadd fast float %5267, %4221
  %5271 = fadd fast float %5268, %4222
  br label %5272

; <label>:5272                                    ; preds = %5255, %5170
  %5273 = phi float [ %5269, %5255 ], [ %4220, %5170 ]
  %5274 = phi float [ %5270, %5255 ], [ %4221, %5170 ]
  %5275 = phi float [ %5271, %5255 ], [ %4222, %5170 ]
  %5276 = fcmp fast ogt float %5273, 0x3F69A5C380000000
  %5277 = fcmp fast ogt float %5274, 0x3F69A5C380000000
  %5278 = fcmp fast ogt float %5275, 0x3F69A5C380000000
  %5279 = select i1 %5276, float 0.000000e+00, float 1.000000e+00
  %5280 = select i1 %5277, float 0.000000e+00, float 1.000000e+00
  %5281 = select i1 %5278, float 0.000000e+00, float 1.000000e+00
  %5282 = fmul fast float %5273, 0x4029D70A40000000
  %5283 = fmul fast float %5274, 0x4029D70A40000000
  %5284 = fmul fast float %5275, 0x4029D70A40000000
  %5285 = call float @dx.op.binary.f32(i32 35, float %5273, float 0.000000e+00)  ; FMax(a,b)
  %5286 = call float @dx.op.binary.f32(i32 35, float %5274, float 0.000000e+00)  ; FMax(a,b)
  %5287 = call float @dx.op.binary.f32(i32 35, float %5275, float 0.000000e+00)  ; FMax(a,b)
  %5288 = call float @dx.op.unary.f32(i32 23, float %5285)  ; Log(value)
  %5289 = call float @dx.op.unary.f32(i32 23, float %5286)  ; Log(value)
  %5290 = call float @dx.op.unary.f32(i32 23, float %5287)  ; Log(value)
  %5291 = fmul fast float %5288, 0x3FDAAAAAA0000000
  %5292 = fmul fast float %5289, 0x3FDAAAAAA0000000
  %5293 = fmul fast float %5290, 0x3FDAAAAAA0000000
  %5294 = call float @dx.op.unary.f32(i32 21, float %5291)  ; Exp(value)
  %5295 = call float @dx.op.unary.f32(i32 21, float %5292)  ; Exp(value)
  %5296 = call float @dx.op.unary.f32(i32 21, float %5293)  ; Exp(value)
  %5297 = fmul fast float %5294, 0x3FF0E147A0000000
  %5298 = fmul fast float %5295, 0x3FF0E147A0000000
  %5299 = fmul fast float %5296, 0x3FF0E147A0000000
  %5300 = fadd fast float %5297, 0xBFAC28F5C0000000
  %5301 = fadd fast float %5298, 0xBFAC28F5C0000000
  %5302 = fadd fast float %5299, 0xBFAC28F5C0000000
  %5303 = fsub fast float %5282, %5300
  %5304 = fsub fast float %5283, %5301
  %5305 = fsub fast float %5284, %5302
  %5306 = fmul fast float %5303, %5279
  %5307 = fmul fast float %5304, %5280
  %5308 = fmul fast float %5305, %5281
  %5309 = fadd fast float %5306, %5300
  %5310 = fadd fast float %5307, %5301
  %5311 = fadd fast float %5308, %5302
  br label %5312

; <label>:5312                                    ; preds = %5272, %4060
  %5313 = phi float [ %4055, %4060 ], [ %5309, %5272 ]
  %5314 = phi float [ %4056, %4060 ], [ %5310, %5272 ]
  %5315 = phi float [ %4057, %4060 ], [ %5311, %5272 ]
  %5316 = phi float [ %4061, %4060 ], [ %4058, %5272 ]
  %5317 = fcmp fast ogt float %5313, 0x3FA4B5DCC0000000
  %5318 = fcmp fast ogt float %5314, 0x3FA4B5DCC0000000
  %5319 = fcmp fast ogt float %5315, 0x3FA4B5DCC0000000
  %5320 = select i1 %5317, float 0.000000e+00, float 1.000000e+00
  %5321 = select i1 %5318, float 0.000000e+00, float 1.000000e+00
  %5322 = select i1 %5319, float 0.000000e+00, float 1.000000e+00
  %5323 = fmul fast float %5313, 0x3FB3D07220000000
  %5324 = fmul fast float %5314, 0x3FB3D07220000000
  %5325 = fmul fast float %5315, 0x3FB3D07220000000
  %5326 = fadd fast float %5313, 0x3FAC28F5C0000000
  %5327 = fadd fast float %5314, 0x3FAC28F5C0000000
  %5328 = fadd fast float %5315, 0x3FAC28F5C0000000
  %5329 = fmul fast float %5326, 0x3FEE54EDE0000000
  %5330 = fmul fast float %5327, 0x3FEE54EDE0000000
  %5331 = fmul fast float %5328, 0x3FEE54EDE0000000
  %5332 = call float @dx.op.unary.f32(i32 23, float %5329)  ; Log(value)
  %5333 = call float @dx.op.unary.f32(i32 23, float %5330)  ; Log(value)
  %5334 = call float @dx.op.unary.f32(i32 23, float %5331)  ; Log(value)
  %5335 = fmul fast float %5332, 0x4003333340000000
  %5336 = fmul fast float %5333, 0x4003333340000000
  %5337 = fmul fast float %5334, 0x4003333340000000
  %5338 = call float @dx.op.unary.f32(i32 21, float %5335)  ; Exp(value)
  %5339 = call float @dx.op.unary.f32(i32 21, float %5336)  ; Exp(value)
  %5340 = call float @dx.op.unary.f32(i32 21, float %5337)  ; Exp(value)
  %5341 = fsub fast float %5323, %5338
  %5342 = fsub fast float %5324, %5339
  %5343 = fsub fast float %5325, %5340
  %5344 = fmul fast float %5341, %5320
  %5345 = fmul fast float %5342, %5321
  %5346 = fmul fast float %5343, %5322
  %5347 = fadd fast float %5344, %5338
  %5348 = fadd fast float %5345, %5339
  %5349 = fadd fast float %5346, %5340
  %5350 = fmul fast float %1459, %162
  %5351 = fmul fast float %1460, %162
  %5352 = fmul fast float %1461, %162
  %5353 = fmul fast float %2755, %163
  %5354 = fmul fast float %2756, %163
  %5355 = fmul fast float %2757, %163
  %5356 = fadd fast float %5353, %5350
  %5357 = fadd fast float %5354, %5351
  %5358 = fadd fast float %5355, %5352
  %5359 = fmul fast float %4051, %164
  %5360 = fmul fast float %4052, %164
  %5361 = fmul fast float %4053, %164
  %5362 = fadd fast float %5356, %5359
  %5363 = fadd fast float %5357, %5360
  %5364 = fadd fast float %5358, %5361
  %5365 = fmul fast float %5347, %165
  %5366 = fmul fast float %5348, %165
  %5367 = fmul fast float %5349, %165
  %5368 = fadd fast float %5362, %5365
  %5369 = fadd fast float %5363, %5366
  %5370 = fadd fast float %5364, %5367
  %5371 = fcmp fast ogt float %5368, 0x3F69A5C380000000
  %5372 = fcmp fast ogt float %5369, 0x3F69A5C380000000
  %5373 = fcmp fast ogt float %5370, 0x3F69A5C380000000
  %5374 = select i1 %5371, float 0.000000e+00, float 1.000000e+00
  %5375 = select i1 %5372, float 0.000000e+00, float 1.000000e+00
  %5376 = select i1 %5373, float 0.000000e+00, float 1.000000e+00
  %5377 = fmul fast float %5368, 0x4029D70A40000000
  %5378 = fmul fast float %5369, 0x4029D70A40000000
  %5379 = fmul fast float %5370, 0x4029D70A40000000
  %5380 = call float @dx.op.binary.f32(i32 35, float %5368, float 0.000000e+00)  ; FMax(a,b)
  %5381 = call float @dx.op.binary.f32(i32 35, float %5369, float 0.000000e+00)  ; FMax(a,b)
  %5382 = call float @dx.op.binary.f32(i32 35, float %5370, float 0.000000e+00)  ; FMax(a,b)
  %5383 = call float @dx.op.unary.f32(i32 23, float %5380)  ; Log(value)
  %5384 = call float @dx.op.unary.f32(i32 23, float %5381)  ; Log(value)
  %5385 = call float @dx.op.unary.f32(i32 23, float %5382)  ; Log(value)
  %5386 = fmul fast float %5383, 0x3FDAAAAAA0000000
  %5387 = fmul fast float %5384, 0x3FDAAAAAA0000000
  %5388 = fmul fast float %5385, 0x3FDAAAAAA0000000
  %5389 = call float @dx.op.unary.f32(i32 21, float %5386)  ; Exp(value)
  %5390 = call float @dx.op.unary.f32(i32 21, float %5387)  ; Exp(value)
  %5391 = call float @dx.op.unary.f32(i32 21, float %5388)  ; Exp(value)
  %5392 = fmul fast float %5389, 0x3FF0E147A0000000
  %5393 = fmul fast float %5390, 0x3FF0E147A0000000
  %5394 = fmul fast float %5391, 0x3FF0E147A0000000
  %5395 = fadd fast float %5392, 0xBFAC28F5C0000000
  %5396 = fadd fast float %5393, 0xBFAC28F5C0000000
  %5397 = fadd fast float %5394, 0xBFAC28F5C0000000
  %5398 = fsub fast float %5377, %5395
  %5399 = fsub fast float %5378, %5396
  %5400 = fsub fast float %5379, %5397
  %5401 = fmul fast float %5398, %5374
  %5402 = fmul fast float %5399, %5375
  %5403 = fmul fast float %5400, %5376
  %5404 = fadd fast float %5401, %5395
  %5405 = fadd fast float %5402, %5396
  %5406 = fadd fast float %5403, %5397
  %5407 = call float @dx.op.dot4.f32(i32 56, float %1428, float %2724, float %4020, float %5316, float %162, float %163, float %164, float %165)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %5404)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %5405)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %5406)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %5407)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %80)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare i1 @dx.op.isSpecialFloat.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !38, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, !37}
!36 = !{i32 9}
!37 = !{i32 3, i32 6}
!38 = !{!39, !40}
!39 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
!40 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !41}
!41 = !{i32 3, i32 1}
