;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xy  
; TEXCOORD                 1   xyzw        2     NONE   float       
; TEXCOORD                 2   xyzw        3     NONE   float       
; TEXCOORD                 3   xyzw        4     NONE   float       
; TEXCOORD                 4   xyzw        5     NONE   float       
; TEXCOORD                 5   xyzw        6     NONE   float       
; TEXCOORD                 6   xyzw        7     NONE   float       
; TEXCOORD                 7   xyzw        8     NONE   float       
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float    yz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: 3eac8d4331dbcb738ca095e417d1e861
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %14 = extractvalue %dx.types.Dimensions %13, 0
  %15 = extractvalue %dx.types.Dimensions %13, 1
  %16 = uitofp i32 %14 to float
  %17 = uitofp i32 %15 to float
  %18 = fmul fast float %16, %11
  %19 = fmul fast float %17, %12
  %20 = fdiv fast float %18, %3
  %21 = fdiv fast float %19, %4
  %22 = fadd fast float %20, -5.000000e-01
  %23 = fadd fast float %21, -5.000000e-01
  %24 = call float @dx.op.unary.f32(i32 27, float %22)  ; Round_ni(value)
  %25 = call float @dx.op.unary.f32(i32 27, float %23)  ; Round_ni(value)
  %26 = fptosi float %24 to i32
  %27 = fptosi float %25 to i32
  %28 = call float @dx.op.unary.f32(i32 22, float %22)  ; Frc(value)
  %29 = call float @dx.op.unary.f32(i32 22, float %23)  ; Frc(value)
  %30 = add i32 %14, -1
  %31 = add i32 %15, -1
  %32 = call i32 @dx.op.binary.i32(i32 37, i32 %26, i32 0)  ; IMax(a,b)
  %33 = call i32 @dx.op.binary.i32(i32 37, i32 %27, i32 0)  ; IMax(a,b)
  %34 = call i32 @dx.op.binary.i32(i32 38, i32 %32, i32 %30)  ; IMin(a,b)
  %35 = call i32 @dx.op.binary.i32(i32 38, i32 %33, i32 %31)  ; IMin(a,b)
  %36 = add i32 %26, 1
  %37 = call i32 @dx.op.binary.i32(i32 37, i32 %36, i32 0)  ; IMax(a,b)
  %38 = call i32 @dx.op.binary.i32(i32 38, i32 %37, i32 %30)  ; IMin(a,b)
  %39 = add i32 %27, 1
  %40 = call i32 @dx.op.binary.i32(i32 37, i32 %39, i32 0)  ; IMax(a,b)
  %41 = call i32 @dx.op.binary.i32(i32 38, i32 %40, i32 %31)  ; IMin(a,b)
  %42 = call float @dx.op.unary.f32(i32 27, float %20)  ; Round_ni(value)
  %43 = call float @dx.op.unary.f32(i32 27, float %21)  ; Round_ni(value)
  %44 = fptosi float %42 to i32
  %45 = fptosi float %43 to i32
  %46 = call i32 @dx.op.binary.i32(i32 37, i32 %44, i32 0)  ; IMax(a,b)
  %47 = call i32 @dx.op.binary.i32(i32 37, i32 %45, i32 0)  ; IMax(a,b)
  %48 = call i32 @dx.op.binary.i32(i32 38, i32 %46, i32 %30)  ; IMin(a,b)
  %49 = call i32 @dx.op.binary.i32(i32 38, i32 %47, i32 %31)  ; IMin(a,b)
  %50 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %48, i32 %49, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %51 = extractvalue %dx.types.ResRet.f32 %50, 0
  %52 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %34, i32 %35, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %53 = extractvalue %dx.types.ResRet.f32 %52, 0
  %54 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %38, i32 %35, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %55 = extractvalue %dx.types.ResRet.f32 %54, 0
  %56 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %34, i32 %41, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %57 = extractvalue %dx.types.ResRet.f32 %56, 0
  %58 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %38, i32 %41, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %59 = extractvalue %dx.types.ResRet.f32 %58, 0
  %60 = fsub fast float 1.000000e+00, %28
  %61 = fsub fast float 1.000000e+00, %29
  %62 = fmul fast float %61, %60
  %63 = fmul fast float %61, %28
  %64 = fmul fast float %60, %29
  %65 = fmul fast float %29, %28
  %66 = fsub fast float 1.000000e+00, %51
  %67 = fmul fast float %66, 0x3FA99999A0000000
  %68 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %67)  ; FMax(a,b)
  %69 = fsub fast float %53, %51
  %70 = call float @dx.op.unary.f32(i32 6, float %69)  ; FAbs(value)
  %71 = fdiv fast float %70, %68
  %72 = fsub fast float 1.000000e+00, %71
  %73 = call float @dx.op.unary.f32(i32 7, float %72)  ; Saturate(value)
  %74 = fsub fast float %55, %51
  %75 = call float @dx.op.unary.f32(i32 6, float %74)  ; FAbs(value)
  %76 = fdiv fast float %75, %68
  %77 = fsub fast float 1.000000e+00, %76
  %78 = call float @dx.op.unary.f32(i32 7, float %77)  ; Saturate(value)
  %79 = fsub fast float %57, %51
  %80 = call float @dx.op.unary.f32(i32 6, float %79)  ; FAbs(value)
  %81 = fdiv fast float %80, %68
  %82 = fsub fast float 1.000000e+00, %81
  %83 = call float @dx.op.unary.f32(i32 7, float %82)  ; Saturate(value)
  %84 = fsub fast float %59, %51
  %85 = call float @dx.op.unary.f32(i32 6, float %84)  ; FAbs(value)
  %86 = fdiv fast float %85, %68
  %87 = fsub fast float 1.000000e+00, %86
  %88 = call float @dx.op.unary.f32(i32 7, float %87)  ; Saturate(value)
  %89 = fmul fast float %62, %73
  %90 = fmul fast float %63, %78
  %91 = fmul fast float %64, %83
  %92 = fmul fast float %65, %88
  %93 = fcmp fast oge float %28, 5.000000e-01
  %94 = zext i1 %93 to i32
  %95 = fcmp fast oge float %29, 5.000000e-01
  %96 = select i1 %95, i32 2, i32 0
  %97 = or i32 %96, %94
  %98 = call float @dx.op.dot4.f32(i32 56, float %89, float %90, float %91, float %92, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %99 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %89)  ; IsFinite(value)
  %100 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %90)  ; IsFinite(value)
  %101 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %91)  ; IsFinite(value)
  %102 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %92)  ; IsFinite(value)
  %103 = and i1 %99, %100
  %104 = and i1 %103, %101
  %105 = and i1 %104, %102
  br i1 %105, label %106, label %123

; <label>:106                                     ; preds = %0
  %107 = fcmp fast oge float %89, 0.000000e+00
  %108 = fcmp fast oge float %90, 0.000000e+00
  %109 = fcmp fast oge float %91, 0.000000e+00
  %110 = fcmp fast oge float %92, 0.000000e+00
  %111 = and i1 %107, %108
  %112 = and i1 %111, %109
  %113 = and i1 %112, %110
  br i1 %113, label %114, label %123

; <label>:114                                     ; preds = %106
  %115 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %98)  ; IsFinite(value)
  %116 = fcmp fast oge float %98, 0x3810000000000000
  %117 = and i1 %116, %115
  br i1 %117, label %118, label %123

; <label>:118                                     ; preds = %114
  %119 = fdiv fast float %89, %98
  %120 = fdiv fast float %90, %98
  %121 = fdiv fast float %91, %98
  %122 = fdiv fast float %92, %98
  br label %132

; <label>:123                                     ; preds = %114, %106, %0
  %124 = icmp eq i32 %97, 0
  %125 = uitofp i1 %124 to float
  %126 = icmp eq i32 %97, 1
  %127 = uitofp i1 %126 to float
  %128 = icmp eq i32 %97, 2
  %129 = uitofp i1 %128 to float
  %130 = icmp eq i32 %97, 3
  %131 = uitofp i1 %130 to float
  br label %132

; <label>:132                                     ; preds = %123, %118
  %133 = phi float [ %119, %118 ], [ %125, %123 ]
  %134 = phi float [ %120, %118 ], [ %127, %123 ]
  %135 = phi float [ %121, %118 ], [ %129, %123 ]
  %136 = phi float [ %122, %118 ], [ %131, %123 ]
  %137 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %34, i32 %35, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %138 = extractvalue %dx.types.ResRet.f32 %137, 0
  %139 = extractvalue %dx.types.ResRet.f32 %137, 1
  %140 = extractvalue %dx.types.ResRet.f32 %137, 2
  %141 = extractvalue %dx.types.ResRet.f32 %137, 3
  %142 = fcmp fast olt float %141, 0.000000e+00
  br i1 %142, label %143, label %145

; <label>:143                                     ; preds = %132
  %144 = fsub fast float -1.000000e+00, %141
  br label %249

; <label>:145                                     ; preds = %132
  %146 = fadd fast float %5, 1.000000e+00
  %147 = fadd fast float %6, 1.000000e+00
  %148 = fsub fast float 1.000000e+00, %5
  %149 = fmul fast float %9, %146
  %150 = fmul fast float %9, %147
  %151 = fmul fast float %9, %148
  %152 = fmul fast float %149, %138
  %153 = fmul fast float %150, %139
  %154 = fmul fast float %151, %140
  %155 = fcmp fast ult float %10, 5.000000e-01
  br i1 %155, label %181, label %156

; <label>:156                                     ; preds = %145
  %157 = fmul fast float %152, 0x4004147AE0000000
  %158 = fmul fast float %153, 0x4004147AE0000000
  %159 = fmul fast float %154, 0x4004147AE0000000
  %160 = fadd fast float %157, 0x3F9EB851E0000000
  %161 = fadd fast float %158, 0x3F9EB851E0000000
  %162 = fadd fast float %159, 0x3F9EB851E0000000
  %163 = fmul fast float %160, %152
  %164 = fmul fast float %161, %153
  %165 = fmul fast float %162, %154
  %166 = fmul fast float %152, 0x400370A3E0000000
  %167 = fmul fast float %153, 0x400370A3E0000000
  %168 = fmul fast float %154, 0x400370A3E0000000
  %169 = fadd fast float %166, 0x3FE2E147A0000000
  %170 = fadd fast float %167, 0x3FE2E147A0000000
  %171 = fadd fast float %168, 0x3FE2E147A0000000
  %172 = fmul fast float %169, %152
  %173 = fmul fast float %170, %153
  %174 = fmul fast float %171, %154
  %175 = fadd fast float %172, 0x3FC1EB8520000000
  %176 = fadd fast float %173, 0x3FC1EB8520000000
  %177 = fadd fast float %174, 0x3FC1EB8520000000
  %178 = fdiv fast float %163, %175
  %179 = fdiv fast float %164, %176
  %180 = fdiv fast float %165, %177
  br label %181

; <label>:181                                     ; preds = %156, %145
  %182 = phi float [ %178, %156 ], [ %152, %145 ]
  %183 = phi float [ %179, %156 ], [ %153, %145 ]
  %184 = phi float [ %180, %156 ], [ %154, %145 ]
  %185 = call float @dx.op.unary.f32(i32 7, float %182)  ; Saturate(value)
  %186 = call float @dx.op.unary.f32(i32 7, float %183)  ; Saturate(value)
  %187 = call float @dx.op.unary.f32(i32 7, float %184)  ; Saturate(value)
  %188 = call float @dx.op.dot3.f32(i32 55, float %185, float %186, float %187, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %189 = fsub fast float %185, %188
  %190 = fsub fast float %186, %188
  %191 = fsub fast float %187, %188
  %192 = fmul fast float %189, %8
  %193 = fmul fast float %190, %8
  %194 = fmul fast float %191, %8
  %195 = fadd fast float %192, %188
  %196 = fadd fast float %193, %188
  %197 = fadd fast float %194, %188
  %198 = call float @dx.op.unary.f32(i32 7, float %195)  ; Saturate(value)
  %199 = call float @dx.op.unary.f32(i32 7, float %196)  ; Saturate(value)
  %200 = call float @dx.op.unary.f32(i32 7, float %197)  ; Saturate(value)
  %201 = fadd fast float %198, 0xBFC70A3D80000000
  %202 = fadd fast float %199, 0xBFC70A3D80000000
  %203 = fadd fast float %200, 0xBFC70A3D80000000
  %204 = fmul fast float %201, %7
  %205 = fmul fast float %202, %7
  %206 = fmul fast float %203, %7
  %207 = fadd fast float %204, 0x3FC70A3D80000000
  %208 = fadd fast float %205, 0x3FC70A3D80000000
  %209 = fadd fast float %206, 0x3FC70A3D80000000
  %210 = call float @dx.op.unary.f32(i32 7, float %207)  ; Saturate(value)
  %211 = call float @dx.op.unary.f32(i32 7, float %208)  ; Saturate(value)
  %212 = call float @dx.op.unary.f32(i32 7, float %209)  ; Saturate(value)
  %213 = fcmp fast ogt float %210, 0x3F69A5C380000000
  %214 = fcmp fast ogt float %211, 0x3F69A5C380000000
  %215 = fcmp fast ogt float %212, 0x3F69A5C380000000
  %216 = select i1 %213, float 0.000000e+00, float 1.000000e+00
  %217 = select i1 %214, float 0.000000e+00, float 1.000000e+00
  %218 = select i1 %215, float 0.000000e+00, float 1.000000e+00
  %219 = fmul fast float %210, 0x4029D70A40000000
  %220 = fmul fast float %211, 0x4029D70A40000000
  %221 = fmul fast float %212, 0x4029D70A40000000
  %222 = call float @dx.op.binary.f32(i32 35, float %210, float 0.000000e+00)  ; FMax(a,b)
  %223 = call float @dx.op.binary.f32(i32 35, float %211, float 0.000000e+00)  ; FMax(a,b)
  %224 = call float @dx.op.binary.f32(i32 35, float %212, float 0.000000e+00)  ; FMax(a,b)
  %225 = call float @dx.op.unary.f32(i32 23, float %222)  ; Log(value)
  %226 = call float @dx.op.unary.f32(i32 23, float %223)  ; Log(value)
  %227 = call float @dx.op.unary.f32(i32 23, float %224)  ; Log(value)
  %228 = fmul fast float %225, 0x3FDAAAAAA0000000
  %229 = fmul fast float %226, 0x3FDAAAAAA0000000
  %230 = fmul fast float %227, 0x3FDAAAAAA0000000
  %231 = call float @dx.op.unary.f32(i32 21, float %228)  ; Exp(value)
  %232 = call float @dx.op.unary.f32(i32 21, float %229)  ; Exp(value)
  %233 = call float @dx.op.unary.f32(i32 21, float %230)  ; Exp(value)
  %234 = fmul fast float %231, 0x3FF0E147A0000000
  %235 = fmul fast float %232, 0x3FF0E147A0000000
  %236 = fmul fast float %233, 0x3FF0E147A0000000
  %237 = fadd fast float %234, 0xBFAC28F5C0000000
  %238 = fadd fast float %235, 0xBFAC28F5C0000000
  %239 = fadd fast float %236, 0xBFAC28F5C0000000
  %240 = fsub fast float %219, %237
  %241 = fsub fast float %220, %238
  %242 = fsub fast float %221, %239
  %243 = fmul fast float %240, %216
  %244 = fmul fast float %241, %217
  %245 = fmul fast float %242, %218
  %246 = fadd fast float %243, %237
  %247 = fadd fast float %244, %238
  %248 = fadd fast float %245, %239
  br label %249

; <label>:249                                     ; preds = %181, %143
  %250 = phi float [ %138, %143 ], [ %246, %181 ]
  %251 = phi float [ %139, %143 ], [ %247, %181 ]
  %252 = phi float [ %140, %143 ], [ %248, %181 ]
  %253 = phi float [ %144, %143 ], [ %141, %181 ]
  %254 = fcmp fast ogt float %250, 0x3FA4B5DCC0000000
  %255 = fcmp fast ogt float %251, 0x3FA4B5DCC0000000
  %256 = fcmp fast ogt float %252, 0x3FA4B5DCC0000000
  %257 = select i1 %254, float 0.000000e+00, float 1.000000e+00
  %258 = select i1 %255, float 0.000000e+00, float 1.000000e+00
  %259 = select i1 %256, float 0.000000e+00, float 1.000000e+00
  %260 = fmul fast float %250, 0x3FB3D07220000000
  %261 = fmul fast float %251, 0x3FB3D07220000000
  %262 = fmul fast float %252, 0x3FB3D07220000000
  %263 = fadd fast float %250, 0x3FAC28F5C0000000
  %264 = fadd fast float %251, 0x3FAC28F5C0000000
  %265 = fadd fast float %252, 0x3FAC28F5C0000000
  %266 = fmul fast float %263, 0x3FEE54EDE0000000
  %267 = fmul fast float %264, 0x3FEE54EDE0000000
  %268 = fmul fast float %265, 0x3FEE54EDE0000000
  %269 = call float @dx.op.unary.f32(i32 23, float %266)  ; Log(value)
  %270 = call float @dx.op.unary.f32(i32 23, float %267)  ; Log(value)
  %271 = call float @dx.op.unary.f32(i32 23, float %268)  ; Log(value)
  %272 = fmul fast float %269, 0x4003333340000000
  %273 = fmul fast float %270, 0x4003333340000000
  %274 = fmul fast float %271, 0x4003333340000000
  %275 = call float @dx.op.unary.f32(i32 21, float %272)  ; Exp(value)
  %276 = call float @dx.op.unary.f32(i32 21, float %273)  ; Exp(value)
  %277 = call float @dx.op.unary.f32(i32 21, float %274)  ; Exp(value)
  %278 = fsub fast float %260, %275
  %279 = fsub fast float %261, %276
  %280 = fsub fast float %262, %277
  %281 = fmul fast float %278, %257
  %282 = fmul fast float %279, %258
  %283 = fmul fast float %280, %259
  %284 = fadd fast float %281, %275
  %285 = fadd fast float %282, %276
  %286 = fadd fast float %283, %277
  %287 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %38, i32 %35, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %288 = extractvalue %dx.types.ResRet.f32 %287, 0
  %289 = extractvalue %dx.types.ResRet.f32 %287, 1
  %290 = extractvalue %dx.types.ResRet.f32 %287, 2
  %291 = extractvalue %dx.types.ResRet.f32 %287, 3
  %292 = fcmp fast olt float %291, 0.000000e+00
  br i1 %292, label %293, label %295

; <label>:293                                     ; preds = %249
  %294 = fsub fast float -1.000000e+00, %291
  br label %399

; <label>:295                                     ; preds = %249
  %296 = fadd fast float %5, 1.000000e+00
  %297 = fadd fast float %6, 1.000000e+00
  %298 = fsub fast float 1.000000e+00, %5
  %299 = fmul fast float %9, %296
  %300 = fmul fast float %9, %297
  %301 = fmul fast float %9, %298
  %302 = fmul fast float %299, %288
  %303 = fmul fast float %300, %289
  %304 = fmul fast float %301, %290
  %305 = fcmp fast ult float %10, 5.000000e-01
  br i1 %305, label %331, label %306

; <label>:306                                     ; preds = %295
  %307 = fmul fast float %302, 0x4004147AE0000000
  %308 = fmul fast float %303, 0x4004147AE0000000
  %309 = fmul fast float %304, 0x4004147AE0000000
  %310 = fadd fast float %307, 0x3F9EB851E0000000
  %311 = fadd fast float %308, 0x3F9EB851E0000000
  %312 = fadd fast float %309, 0x3F9EB851E0000000
  %313 = fmul fast float %310, %302
  %314 = fmul fast float %311, %303
  %315 = fmul fast float %312, %304
  %316 = fmul fast float %302, 0x400370A3E0000000
  %317 = fmul fast float %303, 0x400370A3E0000000
  %318 = fmul fast float %304, 0x400370A3E0000000
  %319 = fadd fast float %316, 0x3FE2E147A0000000
  %320 = fadd fast float %317, 0x3FE2E147A0000000
  %321 = fadd fast float %318, 0x3FE2E147A0000000
  %322 = fmul fast float %319, %302
  %323 = fmul fast float %320, %303
  %324 = fmul fast float %321, %304
  %325 = fadd fast float %322, 0x3FC1EB8520000000
  %326 = fadd fast float %323, 0x3FC1EB8520000000
  %327 = fadd fast float %324, 0x3FC1EB8520000000
  %328 = fdiv fast float %313, %325
  %329 = fdiv fast float %314, %326
  %330 = fdiv fast float %315, %327
  br label %331

; <label>:331                                     ; preds = %306, %295
  %332 = phi float [ %328, %306 ], [ %302, %295 ]
  %333 = phi float [ %329, %306 ], [ %303, %295 ]
  %334 = phi float [ %330, %306 ], [ %304, %295 ]
  %335 = call float @dx.op.unary.f32(i32 7, float %332)  ; Saturate(value)
  %336 = call float @dx.op.unary.f32(i32 7, float %333)  ; Saturate(value)
  %337 = call float @dx.op.unary.f32(i32 7, float %334)  ; Saturate(value)
  %338 = call float @dx.op.dot3.f32(i32 55, float %335, float %336, float %337, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %339 = fsub fast float %335, %338
  %340 = fsub fast float %336, %338
  %341 = fsub fast float %337, %338
  %342 = fmul fast float %339, %8
  %343 = fmul fast float %340, %8
  %344 = fmul fast float %341, %8
  %345 = fadd fast float %342, %338
  %346 = fadd fast float %343, %338
  %347 = fadd fast float %344, %338
  %348 = call float @dx.op.unary.f32(i32 7, float %345)  ; Saturate(value)
  %349 = call float @dx.op.unary.f32(i32 7, float %346)  ; Saturate(value)
  %350 = call float @dx.op.unary.f32(i32 7, float %347)  ; Saturate(value)
  %351 = fadd fast float %348, 0xBFC70A3D80000000
  %352 = fadd fast float %349, 0xBFC70A3D80000000
  %353 = fadd fast float %350, 0xBFC70A3D80000000
  %354 = fmul fast float %351, %7
  %355 = fmul fast float %352, %7
  %356 = fmul fast float %353, %7
  %357 = fadd fast float %354, 0x3FC70A3D80000000
  %358 = fadd fast float %355, 0x3FC70A3D80000000
  %359 = fadd fast float %356, 0x3FC70A3D80000000
  %360 = call float @dx.op.unary.f32(i32 7, float %357)  ; Saturate(value)
  %361 = call float @dx.op.unary.f32(i32 7, float %358)  ; Saturate(value)
  %362 = call float @dx.op.unary.f32(i32 7, float %359)  ; Saturate(value)
  %363 = fcmp fast ogt float %360, 0x3F69A5C380000000
  %364 = fcmp fast ogt float %361, 0x3F69A5C380000000
  %365 = fcmp fast ogt float %362, 0x3F69A5C380000000
  %366 = select i1 %363, float 0.000000e+00, float 1.000000e+00
  %367 = select i1 %364, float 0.000000e+00, float 1.000000e+00
  %368 = select i1 %365, float 0.000000e+00, float 1.000000e+00
  %369 = fmul fast float %360, 0x4029D70A40000000
  %370 = fmul fast float %361, 0x4029D70A40000000
  %371 = fmul fast float %362, 0x4029D70A40000000
  %372 = call float @dx.op.binary.f32(i32 35, float %360, float 0.000000e+00)  ; FMax(a,b)
  %373 = call float @dx.op.binary.f32(i32 35, float %361, float 0.000000e+00)  ; FMax(a,b)
  %374 = call float @dx.op.binary.f32(i32 35, float %362, float 0.000000e+00)  ; FMax(a,b)
  %375 = call float @dx.op.unary.f32(i32 23, float %372)  ; Log(value)
  %376 = call float @dx.op.unary.f32(i32 23, float %373)  ; Log(value)
  %377 = call float @dx.op.unary.f32(i32 23, float %374)  ; Log(value)
  %378 = fmul fast float %375, 0x3FDAAAAAA0000000
  %379 = fmul fast float %376, 0x3FDAAAAAA0000000
  %380 = fmul fast float %377, 0x3FDAAAAAA0000000
  %381 = call float @dx.op.unary.f32(i32 21, float %378)  ; Exp(value)
  %382 = call float @dx.op.unary.f32(i32 21, float %379)  ; Exp(value)
  %383 = call float @dx.op.unary.f32(i32 21, float %380)  ; Exp(value)
  %384 = fmul fast float %381, 0x3FF0E147A0000000
  %385 = fmul fast float %382, 0x3FF0E147A0000000
  %386 = fmul fast float %383, 0x3FF0E147A0000000
  %387 = fadd fast float %384, 0xBFAC28F5C0000000
  %388 = fadd fast float %385, 0xBFAC28F5C0000000
  %389 = fadd fast float %386, 0xBFAC28F5C0000000
  %390 = fsub fast float %369, %387
  %391 = fsub fast float %370, %388
  %392 = fsub fast float %371, %389
  %393 = fmul fast float %390, %366
  %394 = fmul fast float %391, %367
  %395 = fmul fast float %392, %368
  %396 = fadd fast float %393, %387
  %397 = fadd fast float %394, %388
  %398 = fadd fast float %395, %389
  br label %399

; <label>:399                                     ; preds = %331, %293
  %400 = phi float [ %288, %293 ], [ %396, %331 ]
  %401 = phi float [ %289, %293 ], [ %397, %331 ]
  %402 = phi float [ %290, %293 ], [ %398, %331 ]
  %403 = phi float [ %294, %293 ], [ %291, %331 ]
  %404 = fcmp fast ogt float %400, 0x3FA4B5DCC0000000
  %405 = fcmp fast ogt float %401, 0x3FA4B5DCC0000000
  %406 = fcmp fast ogt float %402, 0x3FA4B5DCC0000000
  %407 = select i1 %404, float 0.000000e+00, float 1.000000e+00
  %408 = select i1 %405, float 0.000000e+00, float 1.000000e+00
  %409 = select i1 %406, float 0.000000e+00, float 1.000000e+00
  %410 = fmul fast float %400, 0x3FB3D07220000000
  %411 = fmul fast float %401, 0x3FB3D07220000000
  %412 = fmul fast float %402, 0x3FB3D07220000000
  %413 = fadd fast float %400, 0x3FAC28F5C0000000
  %414 = fadd fast float %401, 0x3FAC28F5C0000000
  %415 = fadd fast float %402, 0x3FAC28F5C0000000
  %416 = fmul fast float %413, 0x3FEE54EDE0000000
  %417 = fmul fast float %414, 0x3FEE54EDE0000000
  %418 = fmul fast float %415, 0x3FEE54EDE0000000
  %419 = call float @dx.op.unary.f32(i32 23, float %416)  ; Log(value)
  %420 = call float @dx.op.unary.f32(i32 23, float %417)  ; Log(value)
  %421 = call float @dx.op.unary.f32(i32 23, float %418)  ; Log(value)
  %422 = fmul fast float %419, 0x4003333340000000
  %423 = fmul fast float %420, 0x4003333340000000
  %424 = fmul fast float %421, 0x4003333340000000
  %425 = call float @dx.op.unary.f32(i32 21, float %422)  ; Exp(value)
  %426 = call float @dx.op.unary.f32(i32 21, float %423)  ; Exp(value)
  %427 = call float @dx.op.unary.f32(i32 21, float %424)  ; Exp(value)
  %428 = fsub fast float %410, %425
  %429 = fsub fast float %411, %426
  %430 = fsub fast float %412, %427
  %431 = fmul fast float %428, %407
  %432 = fmul fast float %429, %408
  %433 = fmul fast float %430, %409
  %434 = fadd fast float %431, %425
  %435 = fadd fast float %432, %426
  %436 = fadd fast float %433, %427
  %437 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %34, i32 %41, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %438 = extractvalue %dx.types.ResRet.f32 %437, 0
  %439 = extractvalue %dx.types.ResRet.f32 %437, 1
  %440 = extractvalue %dx.types.ResRet.f32 %437, 2
  %441 = extractvalue %dx.types.ResRet.f32 %437, 3
  %442 = fcmp fast olt float %441, 0.000000e+00
  br i1 %442, label %443, label %445

; <label>:443                                     ; preds = %399
  %444 = fsub fast float -1.000000e+00, %441
  br label %549

; <label>:445                                     ; preds = %399
  %446 = fadd fast float %5, 1.000000e+00
  %447 = fadd fast float %6, 1.000000e+00
  %448 = fsub fast float 1.000000e+00, %5
  %449 = fmul fast float %9, %446
  %450 = fmul fast float %9, %447
  %451 = fmul fast float %9, %448
  %452 = fmul fast float %449, %438
  %453 = fmul fast float %450, %439
  %454 = fmul fast float %451, %440
  %455 = fcmp fast ult float %10, 5.000000e-01
  br i1 %455, label %481, label %456

; <label>:456                                     ; preds = %445
  %457 = fmul fast float %452, 0x4004147AE0000000
  %458 = fmul fast float %453, 0x4004147AE0000000
  %459 = fmul fast float %454, 0x4004147AE0000000
  %460 = fadd fast float %457, 0x3F9EB851E0000000
  %461 = fadd fast float %458, 0x3F9EB851E0000000
  %462 = fadd fast float %459, 0x3F9EB851E0000000
  %463 = fmul fast float %460, %452
  %464 = fmul fast float %461, %453
  %465 = fmul fast float %462, %454
  %466 = fmul fast float %452, 0x400370A3E0000000
  %467 = fmul fast float %453, 0x400370A3E0000000
  %468 = fmul fast float %454, 0x400370A3E0000000
  %469 = fadd fast float %466, 0x3FE2E147A0000000
  %470 = fadd fast float %467, 0x3FE2E147A0000000
  %471 = fadd fast float %468, 0x3FE2E147A0000000
  %472 = fmul fast float %469, %452
  %473 = fmul fast float %470, %453
  %474 = fmul fast float %471, %454
  %475 = fadd fast float %472, 0x3FC1EB8520000000
  %476 = fadd fast float %473, 0x3FC1EB8520000000
  %477 = fadd fast float %474, 0x3FC1EB8520000000
  %478 = fdiv fast float %463, %475
  %479 = fdiv fast float %464, %476
  %480 = fdiv fast float %465, %477
  br label %481

; <label>:481                                     ; preds = %456, %445
  %482 = phi float [ %478, %456 ], [ %452, %445 ]
  %483 = phi float [ %479, %456 ], [ %453, %445 ]
  %484 = phi float [ %480, %456 ], [ %454, %445 ]
  %485 = call float @dx.op.unary.f32(i32 7, float %482)  ; Saturate(value)
  %486 = call float @dx.op.unary.f32(i32 7, float %483)  ; Saturate(value)
  %487 = call float @dx.op.unary.f32(i32 7, float %484)  ; Saturate(value)
  %488 = call float @dx.op.dot3.f32(i32 55, float %485, float %486, float %487, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %489 = fsub fast float %485, %488
  %490 = fsub fast float %486, %488
  %491 = fsub fast float %487, %488
  %492 = fmul fast float %489, %8
  %493 = fmul fast float %490, %8
  %494 = fmul fast float %491, %8
  %495 = fadd fast float %492, %488
  %496 = fadd fast float %493, %488
  %497 = fadd fast float %494, %488
  %498 = call float @dx.op.unary.f32(i32 7, float %495)  ; Saturate(value)
  %499 = call float @dx.op.unary.f32(i32 7, float %496)  ; Saturate(value)
  %500 = call float @dx.op.unary.f32(i32 7, float %497)  ; Saturate(value)
  %501 = fadd fast float %498, 0xBFC70A3D80000000
  %502 = fadd fast float %499, 0xBFC70A3D80000000
  %503 = fadd fast float %500, 0xBFC70A3D80000000
  %504 = fmul fast float %501, %7
  %505 = fmul fast float %502, %7
  %506 = fmul fast float %503, %7
  %507 = fadd fast float %504, 0x3FC70A3D80000000
  %508 = fadd fast float %505, 0x3FC70A3D80000000
  %509 = fadd fast float %506, 0x3FC70A3D80000000
  %510 = call float @dx.op.unary.f32(i32 7, float %507)  ; Saturate(value)
  %511 = call float @dx.op.unary.f32(i32 7, float %508)  ; Saturate(value)
  %512 = call float @dx.op.unary.f32(i32 7, float %509)  ; Saturate(value)
  %513 = fcmp fast ogt float %510, 0x3F69A5C380000000
  %514 = fcmp fast ogt float %511, 0x3F69A5C380000000
  %515 = fcmp fast ogt float %512, 0x3F69A5C380000000
  %516 = select i1 %513, float 0.000000e+00, float 1.000000e+00
  %517 = select i1 %514, float 0.000000e+00, float 1.000000e+00
  %518 = select i1 %515, float 0.000000e+00, float 1.000000e+00
  %519 = fmul fast float %510, 0x4029D70A40000000
  %520 = fmul fast float %511, 0x4029D70A40000000
  %521 = fmul fast float %512, 0x4029D70A40000000
  %522 = call float @dx.op.binary.f32(i32 35, float %510, float 0.000000e+00)  ; FMax(a,b)
  %523 = call float @dx.op.binary.f32(i32 35, float %511, float 0.000000e+00)  ; FMax(a,b)
  %524 = call float @dx.op.binary.f32(i32 35, float %512, float 0.000000e+00)  ; FMax(a,b)
  %525 = call float @dx.op.unary.f32(i32 23, float %522)  ; Log(value)
  %526 = call float @dx.op.unary.f32(i32 23, float %523)  ; Log(value)
  %527 = call float @dx.op.unary.f32(i32 23, float %524)  ; Log(value)
  %528 = fmul fast float %525, 0x3FDAAAAAA0000000
  %529 = fmul fast float %526, 0x3FDAAAAAA0000000
  %530 = fmul fast float %527, 0x3FDAAAAAA0000000
  %531 = call float @dx.op.unary.f32(i32 21, float %528)  ; Exp(value)
  %532 = call float @dx.op.unary.f32(i32 21, float %529)  ; Exp(value)
  %533 = call float @dx.op.unary.f32(i32 21, float %530)  ; Exp(value)
  %534 = fmul fast float %531, 0x3FF0E147A0000000
  %535 = fmul fast float %532, 0x3FF0E147A0000000
  %536 = fmul fast float %533, 0x3FF0E147A0000000
  %537 = fadd fast float %534, 0xBFAC28F5C0000000
  %538 = fadd fast float %535, 0xBFAC28F5C0000000
  %539 = fadd fast float %536, 0xBFAC28F5C0000000
  %540 = fsub fast float %519, %537
  %541 = fsub fast float %520, %538
  %542 = fsub fast float %521, %539
  %543 = fmul fast float %540, %516
  %544 = fmul fast float %541, %517
  %545 = fmul fast float %542, %518
  %546 = fadd fast float %543, %537
  %547 = fadd fast float %544, %538
  %548 = fadd fast float %545, %539
  br label %549

; <label>:549                                     ; preds = %481, %443
  %550 = phi float [ %438, %443 ], [ %546, %481 ]
  %551 = phi float [ %439, %443 ], [ %547, %481 ]
  %552 = phi float [ %440, %443 ], [ %548, %481 ]
  %553 = phi float [ %444, %443 ], [ %441, %481 ]
  %554 = fcmp fast ogt float %550, 0x3FA4B5DCC0000000
  %555 = fcmp fast ogt float %551, 0x3FA4B5DCC0000000
  %556 = fcmp fast ogt float %552, 0x3FA4B5DCC0000000
  %557 = select i1 %554, float 0.000000e+00, float 1.000000e+00
  %558 = select i1 %555, float 0.000000e+00, float 1.000000e+00
  %559 = select i1 %556, float 0.000000e+00, float 1.000000e+00
  %560 = fmul fast float %550, 0x3FB3D07220000000
  %561 = fmul fast float %551, 0x3FB3D07220000000
  %562 = fmul fast float %552, 0x3FB3D07220000000
  %563 = fadd fast float %550, 0x3FAC28F5C0000000
  %564 = fadd fast float %551, 0x3FAC28F5C0000000
  %565 = fadd fast float %552, 0x3FAC28F5C0000000
  %566 = fmul fast float %563, 0x3FEE54EDE0000000
  %567 = fmul fast float %564, 0x3FEE54EDE0000000
  %568 = fmul fast float %565, 0x3FEE54EDE0000000
  %569 = call float @dx.op.unary.f32(i32 23, float %566)  ; Log(value)
  %570 = call float @dx.op.unary.f32(i32 23, float %567)  ; Log(value)
  %571 = call float @dx.op.unary.f32(i32 23, float %568)  ; Log(value)
  %572 = fmul fast float %569, 0x4003333340000000
  %573 = fmul fast float %570, 0x4003333340000000
  %574 = fmul fast float %571, 0x4003333340000000
  %575 = call float @dx.op.unary.f32(i32 21, float %572)  ; Exp(value)
  %576 = call float @dx.op.unary.f32(i32 21, float %573)  ; Exp(value)
  %577 = call float @dx.op.unary.f32(i32 21, float %574)  ; Exp(value)
  %578 = fsub fast float %560, %575
  %579 = fsub fast float %561, %576
  %580 = fsub fast float %562, %577
  %581 = fmul fast float %578, %557
  %582 = fmul fast float %579, %558
  %583 = fmul fast float %580, %559
  %584 = fadd fast float %581, %575
  %585 = fadd fast float %582, %576
  %586 = fadd fast float %583, %577
  %587 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %38, i32 %41, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %588 = extractvalue %dx.types.ResRet.f32 %587, 0
  %589 = extractvalue %dx.types.ResRet.f32 %587, 1
  %590 = extractvalue %dx.types.ResRet.f32 %587, 2
  %591 = extractvalue %dx.types.ResRet.f32 %587, 3
  %592 = fcmp fast olt float %591, 0.000000e+00
  br i1 %592, label %593, label %595

; <label>:593                                     ; preds = %549
  %594 = fsub fast float -1.000000e+00, %591
  br label %699

; <label>:595                                     ; preds = %549
  %596 = fadd fast float %5, 1.000000e+00
  %597 = fadd fast float %6, 1.000000e+00
  %598 = fsub fast float 1.000000e+00, %5
  %599 = fmul fast float %9, %596
  %600 = fmul fast float %9, %597
  %601 = fmul fast float %9, %598
  %602 = fmul fast float %599, %588
  %603 = fmul fast float %600, %589
  %604 = fmul fast float %601, %590
  %605 = fcmp fast ult float %10, 5.000000e-01
  br i1 %605, label %631, label %606

; <label>:606                                     ; preds = %595
  %607 = fmul fast float %602, 0x4004147AE0000000
  %608 = fmul fast float %603, 0x4004147AE0000000
  %609 = fmul fast float %604, 0x4004147AE0000000
  %610 = fadd fast float %607, 0x3F9EB851E0000000
  %611 = fadd fast float %608, 0x3F9EB851E0000000
  %612 = fadd fast float %609, 0x3F9EB851E0000000
  %613 = fmul fast float %610, %602
  %614 = fmul fast float %611, %603
  %615 = fmul fast float %612, %604
  %616 = fmul fast float %602, 0x400370A3E0000000
  %617 = fmul fast float %603, 0x400370A3E0000000
  %618 = fmul fast float %604, 0x400370A3E0000000
  %619 = fadd fast float %616, 0x3FE2E147A0000000
  %620 = fadd fast float %617, 0x3FE2E147A0000000
  %621 = fadd fast float %618, 0x3FE2E147A0000000
  %622 = fmul fast float %619, %602
  %623 = fmul fast float %620, %603
  %624 = fmul fast float %621, %604
  %625 = fadd fast float %622, 0x3FC1EB8520000000
  %626 = fadd fast float %623, 0x3FC1EB8520000000
  %627 = fadd fast float %624, 0x3FC1EB8520000000
  %628 = fdiv fast float %613, %625
  %629 = fdiv fast float %614, %626
  %630 = fdiv fast float %615, %627
  br label %631

; <label>:631                                     ; preds = %606, %595
  %632 = phi float [ %628, %606 ], [ %602, %595 ]
  %633 = phi float [ %629, %606 ], [ %603, %595 ]
  %634 = phi float [ %630, %606 ], [ %604, %595 ]
  %635 = call float @dx.op.unary.f32(i32 7, float %632)  ; Saturate(value)
  %636 = call float @dx.op.unary.f32(i32 7, float %633)  ; Saturate(value)
  %637 = call float @dx.op.unary.f32(i32 7, float %634)  ; Saturate(value)
  %638 = call float @dx.op.dot3.f32(i32 55, float %635, float %636, float %637, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %639 = fsub fast float %635, %638
  %640 = fsub fast float %636, %638
  %641 = fsub fast float %637, %638
  %642 = fmul fast float %639, %8
  %643 = fmul fast float %640, %8
  %644 = fmul fast float %641, %8
  %645 = fadd fast float %642, %638
  %646 = fadd fast float %643, %638
  %647 = fadd fast float %644, %638
  %648 = call float @dx.op.unary.f32(i32 7, float %645)  ; Saturate(value)
  %649 = call float @dx.op.unary.f32(i32 7, float %646)  ; Saturate(value)
  %650 = call float @dx.op.unary.f32(i32 7, float %647)  ; Saturate(value)
  %651 = fadd fast float %648, 0xBFC70A3D80000000
  %652 = fadd fast float %649, 0xBFC70A3D80000000
  %653 = fadd fast float %650, 0xBFC70A3D80000000
  %654 = fmul fast float %651, %7
  %655 = fmul fast float %652, %7
  %656 = fmul fast float %653, %7
  %657 = fadd fast float %654, 0x3FC70A3D80000000
  %658 = fadd fast float %655, 0x3FC70A3D80000000
  %659 = fadd fast float %656, 0x3FC70A3D80000000
  %660 = call float @dx.op.unary.f32(i32 7, float %657)  ; Saturate(value)
  %661 = call float @dx.op.unary.f32(i32 7, float %658)  ; Saturate(value)
  %662 = call float @dx.op.unary.f32(i32 7, float %659)  ; Saturate(value)
  %663 = fcmp fast ogt float %660, 0x3F69A5C380000000
  %664 = fcmp fast ogt float %661, 0x3F69A5C380000000
  %665 = fcmp fast ogt float %662, 0x3F69A5C380000000
  %666 = select i1 %663, float 0.000000e+00, float 1.000000e+00
  %667 = select i1 %664, float 0.000000e+00, float 1.000000e+00
  %668 = select i1 %665, float 0.000000e+00, float 1.000000e+00
  %669 = fmul fast float %660, 0x4029D70A40000000
  %670 = fmul fast float %661, 0x4029D70A40000000
  %671 = fmul fast float %662, 0x4029D70A40000000
  %672 = call float @dx.op.binary.f32(i32 35, float %660, float 0.000000e+00)  ; FMax(a,b)
  %673 = call float @dx.op.binary.f32(i32 35, float %661, float 0.000000e+00)  ; FMax(a,b)
  %674 = call float @dx.op.binary.f32(i32 35, float %662, float 0.000000e+00)  ; FMax(a,b)
  %675 = call float @dx.op.unary.f32(i32 23, float %672)  ; Log(value)
  %676 = call float @dx.op.unary.f32(i32 23, float %673)  ; Log(value)
  %677 = call float @dx.op.unary.f32(i32 23, float %674)  ; Log(value)
  %678 = fmul fast float %675, 0x3FDAAAAAA0000000
  %679 = fmul fast float %676, 0x3FDAAAAAA0000000
  %680 = fmul fast float %677, 0x3FDAAAAAA0000000
  %681 = call float @dx.op.unary.f32(i32 21, float %678)  ; Exp(value)
  %682 = call float @dx.op.unary.f32(i32 21, float %679)  ; Exp(value)
  %683 = call float @dx.op.unary.f32(i32 21, float %680)  ; Exp(value)
  %684 = fmul fast float %681, 0x3FF0E147A0000000
  %685 = fmul fast float %682, 0x3FF0E147A0000000
  %686 = fmul fast float %683, 0x3FF0E147A0000000
  %687 = fadd fast float %684, 0xBFAC28F5C0000000
  %688 = fadd fast float %685, 0xBFAC28F5C0000000
  %689 = fadd fast float %686, 0xBFAC28F5C0000000
  %690 = fsub fast float %669, %687
  %691 = fsub fast float %670, %688
  %692 = fsub fast float %671, %689
  %693 = fmul fast float %690, %666
  %694 = fmul fast float %691, %667
  %695 = fmul fast float %692, %668
  %696 = fadd fast float %693, %687
  %697 = fadd fast float %694, %688
  %698 = fadd fast float %695, %689
  br label %699

; <label>:699                                     ; preds = %631, %593
  %700 = phi float [ %588, %593 ], [ %696, %631 ]
  %701 = phi float [ %589, %593 ], [ %697, %631 ]
  %702 = phi float [ %590, %593 ], [ %698, %631 ]
  %703 = phi float [ %594, %593 ], [ %591, %631 ]
  %704 = fcmp fast ogt float %700, 0x3FA4B5DCC0000000
  %705 = fcmp fast ogt float %701, 0x3FA4B5DCC0000000
  %706 = fcmp fast ogt float %702, 0x3FA4B5DCC0000000
  %707 = select i1 %704, float 0.000000e+00, float 1.000000e+00
  %708 = select i1 %705, float 0.000000e+00, float 1.000000e+00
  %709 = select i1 %706, float 0.000000e+00, float 1.000000e+00
  %710 = fmul fast float %700, 0x3FB3D07220000000
  %711 = fmul fast float %701, 0x3FB3D07220000000
  %712 = fmul fast float %702, 0x3FB3D07220000000
  %713 = fadd fast float %700, 0x3FAC28F5C0000000
  %714 = fadd fast float %701, 0x3FAC28F5C0000000
  %715 = fadd fast float %702, 0x3FAC28F5C0000000
  %716 = fmul fast float %713, 0x3FEE54EDE0000000
  %717 = fmul fast float %714, 0x3FEE54EDE0000000
  %718 = fmul fast float %715, 0x3FEE54EDE0000000
  %719 = call float @dx.op.unary.f32(i32 23, float %716)  ; Log(value)
  %720 = call float @dx.op.unary.f32(i32 23, float %717)  ; Log(value)
  %721 = call float @dx.op.unary.f32(i32 23, float %718)  ; Log(value)
  %722 = fmul fast float %719, 0x4003333340000000
  %723 = fmul fast float %720, 0x4003333340000000
  %724 = fmul fast float %721, 0x4003333340000000
  %725 = call float @dx.op.unary.f32(i32 21, float %722)  ; Exp(value)
  %726 = call float @dx.op.unary.f32(i32 21, float %723)  ; Exp(value)
  %727 = call float @dx.op.unary.f32(i32 21, float %724)  ; Exp(value)
  %728 = fsub fast float %710, %725
  %729 = fsub fast float %711, %726
  %730 = fsub fast float %712, %727
  %731 = fmul fast float %728, %707
  %732 = fmul fast float %729, %708
  %733 = fmul fast float %730, %709
  %734 = fadd fast float %731, %725
  %735 = fadd fast float %732, %726
  %736 = fadd fast float %733, %727
  %737 = fmul fast float %284, %133
  %738 = fmul fast float %285, %133
  %739 = fmul fast float %286, %133
  %740 = fmul fast float %434, %134
  %741 = fmul fast float %435, %134
  %742 = fmul fast float %436, %134
  %743 = fadd fast float %740, %737
  %744 = fadd fast float %741, %738
  %745 = fadd fast float %742, %739
  %746 = fmul fast float %584, %135
  %747 = fmul fast float %585, %135
  %748 = fmul fast float %586, %135
  %749 = fadd fast float %743, %746
  %750 = fadd fast float %744, %747
  %751 = fadd fast float %745, %748
  %752 = fmul fast float %734, %136
  %753 = fmul fast float %735, %136
  %754 = fmul fast float %736, %136
  %755 = fadd fast float %749, %752
  %756 = fadd fast float %750, %753
  %757 = fadd fast float %751, %754
  %758 = fcmp fast ogt float %755, 0x3F69A5C380000000
  %759 = fcmp fast ogt float %756, 0x3F69A5C380000000
  %760 = fcmp fast ogt float %757, 0x3F69A5C380000000
  %761 = select i1 %758, float 0.000000e+00, float 1.000000e+00
  %762 = select i1 %759, float 0.000000e+00, float 1.000000e+00
  %763 = select i1 %760, float 0.000000e+00, float 1.000000e+00
  %764 = fmul fast float %755, 0x4029D70A40000000
  %765 = fmul fast float %756, 0x4029D70A40000000
  %766 = fmul fast float %757, 0x4029D70A40000000
  %767 = call float @dx.op.binary.f32(i32 35, float %755, float 0.000000e+00)  ; FMax(a,b)
  %768 = call float @dx.op.binary.f32(i32 35, float %756, float 0.000000e+00)  ; FMax(a,b)
  %769 = call float @dx.op.binary.f32(i32 35, float %757, float 0.000000e+00)  ; FMax(a,b)
  %770 = call float @dx.op.unary.f32(i32 23, float %767)  ; Log(value)
  %771 = call float @dx.op.unary.f32(i32 23, float %768)  ; Log(value)
  %772 = call float @dx.op.unary.f32(i32 23, float %769)  ; Log(value)
  %773 = fmul fast float %770, 0x3FDAAAAAA0000000
  %774 = fmul fast float %771, 0x3FDAAAAAA0000000
  %775 = fmul fast float %772, 0x3FDAAAAAA0000000
  %776 = call float @dx.op.unary.f32(i32 21, float %773)  ; Exp(value)
  %777 = call float @dx.op.unary.f32(i32 21, float %774)  ; Exp(value)
  %778 = call float @dx.op.unary.f32(i32 21, float %775)  ; Exp(value)
  %779 = fmul fast float %776, 0x3FF0E147A0000000
  %780 = fmul fast float %777, 0x3FF0E147A0000000
  %781 = fmul fast float %778, 0x3FF0E147A0000000
  %782 = fadd fast float %779, 0xBFAC28F5C0000000
  %783 = fadd fast float %780, 0xBFAC28F5C0000000
  %784 = fadd fast float %781, 0xBFAC28F5C0000000
  %785 = fsub fast float %764, %782
  %786 = fsub fast float %765, %783
  %787 = fsub fast float %766, %784
  %788 = fmul fast float %785, %761
  %789 = fmul fast float %786, %762
  %790 = fmul fast float %787, %763
  %791 = fadd fast float %788, %782
  %792 = fadd fast float %789, %783
  %793 = fadd fast float %790, %784
  %794 = call float @dx.op.dot4.f32(i32 56, float %253, float %403, float %553, float %703, float %133, float %134, float %135, float %136)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %791)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %792)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %793)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %794)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %51)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare i1 @dx.op.isSpecialFloat.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 0, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !37, null}
!12 = !{!13, !16, !17, !19, !21, !23, !25, !27, !29, !31, !34}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !15}
!17 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !18, i8 1, i32 1, i8 4, i32 2, i8 0, null}
!18 = !{i32 1}
!19 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !20, i8 1, i32 1, i8 4, i32 3, i8 0, null}
!20 = !{i32 2}
!21 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !22, i8 1, i32 1, i8 4, i32 4, i8 0, null}
!22 = !{i32 3}
!23 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !24, i8 1, i32 1, i8 4, i32 5, i8 0, null}
!24 = !{i32 4}
!25 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !26, i8 1, i32 1, i8 4, i32 6, i8 0, null}
!26 = !{i32 5}
!27 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !28, i8 1, i32 1, i8 4, i32 7, i8 0, null}
!28 = !{i32 6}
!29 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 8, i8 0, null}
!30 = !{i32 7}
!31 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 9, i8 0, !33}
!32 = !{i32 8}
!33 = !{i32 3, i32 15}
!34 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !35, i8 1, i32 1, i8 4, i32 10, i8 0, !36}
!35 = !{i32 9}
!36 = !{i32 3, i32 6}
!37 = !{!38, !39}
!38 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !33}
!39 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !40}
!40 = !{i32 3, i32 1}
