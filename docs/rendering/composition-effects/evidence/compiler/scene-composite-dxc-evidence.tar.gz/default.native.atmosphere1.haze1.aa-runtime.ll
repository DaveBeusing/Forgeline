;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float   x   
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
;
; shader hash: 12e3236b8a99b66ed312bae8cb2b21b6
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=0
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 1
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40 }
;   output 3 depends on inputs: { 0, 1 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %40 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %41 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %42 = extractvalue %dx.types.Dimensions %41, 0
  %43 = extractvalue %dx.types.Dimensions %41, 1
  %44 = fptosi float %39 to i32
  %45 = fptosi float %40 to i32
  %46 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %44, i32 %45, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %47 = extractvalue %dx.types.ResRet.f32 %46, 0
  %48 = extractvalue %dx.types.ResRet.f32 %46, 1
  %49 = extractvalue %dx.types.ResRet.f32 %46, 2
  %50 = extractvalue %dx.types.ResRet.f32 %46, 3
  %51 = fcmp fast olt float %50, 0.000000e+00
  br i1 %51, label %52, label %54

; <label>:52                                      ; preds = %0
  %53 = fsub fast float -1.000000e+00, %50
  br label %1486

; <label>:54                                      ; preds = %0
  %55 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %44, i32 %45, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %56 = extractvalue %dx.types.ResRet.f32 %55, 0
  %57 = fcmp fast ogt float %37, 5.000000e-01
  %58 = fcmp fast olt float %56, 1.000000e+00
  %59 = and i1 %57, %58
  br i1 %59, label %60, label %200

; <label>:60                                      ; preds = %54
  %61 = sitofp i32 %44 to float
  %62 = sitofp i32 %45 to float
  %63 = fadd fast float %61, 5.000000e-01
  %64 = fadd fast float %62, 5.000000e-01
  %65 = uitofp i32 %42 to float
  %66 = uitofp i32 %43 to float
  %67 = fdiv fast float %63, %65
  %68 = fdiv fast float %64, %66
  %69 = fmul fast float %67, 2.000000e+00
  %70 = fmul fast float %68, 2.000000e+00
  %71 = fadd fast float %69, -1.000000e+00
  %72 = fsub fast float 1.000000e+00, %70
  %73 = fmul fast float %71, %34
  %74 = call float @dx.op.tertiary.f32(i32 46, float %72, float %30, float %73)  ; FMad(a,b,c)
  %75 = call float @dx.op.tertiary.f32(i32 46, float %56, float %26, float %74)  ; FMad(a,b,c)
  %76 = fadd fast float %75, %22
  %77 = call float @dx.op.unary.f32(i32 6, float %76)  ; FAbs(value)
  %78 = fcmp fast ogt float %77, 0x3EB0C6F7A0000000
  br i1 %78, label %79, label %200

; <label>:79                                      ; preds = %60
  %80 = fmul fast float %71, %33
  %81 = call float @dx.op.tertiary.f32(i32 46, float %72, float %29, float %80)  ; FMad(a,b,c)
  %82 = call float @dx.op.tertiary.f32(i32 46, float %56, float %25, float %81)  ; FMad(a,b,c)
  %83 = fadd fast float %82, %21
  %84 = fmul fast float %71, %32
  %85 = call float @dx.op.tertiary.f32(i32 46, float %72, float %28, float %84)  ; FMad(a,b,c)
  %86 = call float @dx.op.tertiary.f32(i32 46, float %56, float %24, float %85)  ; FMad(a,b,c)
  %87 = fadd fast float %86, %20
  %88 = fmul fast float %71, %31
  %89 = call float @dx.op.tertiary.f32(i32 46, float %72, float %27, float %88)  ; FMad(a,b,c)
  %90 = call float @dx.op.tertiary.f32(i32 46, float %56, float %23, float %89)  ; FMad(a,b,c)
  %91 = fadd fast float %90, %19
  %92 = fdiv fast float %91, %76
  %93 = fdiv fast float %87, %76
  %94 = fdiv fast float %83, %76
  %95 = fsub fast float %92, %16
  %96 = fsub fast float %93, %17
  %97 = fsub fast float %94, %18
  %98 = fmul fast float %95, %95
  %99 = fmul fast float %96, %96
  %100 = fadd fast float %99, %98
  %101 = fmul fast float %97, %97
  %102 = fadd fast float %100, %101
  %103 = call float @dx.op.unary.f32(i32 24, float %102)  ; Sqrt(value)
  %104 = fsub fast float %103, %8
  %105 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %104)  ; FMax(a,b)
  %106 = fcmp fast ogt float %38, 1.500000e+00
  br i1 %106, label %107, label %130

; <label>:107                                     ; preds = %79
  %108 = call float @dx.op.unary.f32(i32 6, float %96)  ; FAbs(value)
  %109 = fmul fast float %108, %10
  %110 = fcmp fast olt float %109, 0x3F50624DE0000000
  br i1 %110, label %111, label %114

; <label>:111                                     ; preds = %107
  %112 = fmul fast float %109, 5.000000e-01
  %113 = fsub fast float 1.000000e+00, %112
  br label %119

; <label>:114                                     ; preds = %107
  %115 = fmul fast float %109, 0xBFF7154760000000
  %116 = call float @dx.op.unary.f32(i32 21, float %115)  ; Exp(value)
  %117 = fsub fast float 1.000000e+00, %116
  %118 = fdiv fast float %117, %109
  br label %119

; <label>:119                                     ; preds = %114, %111
  %120 = phi float [ %113, %111 ], [ %118, %114 ]
  %121 = call float @dx.op.binary.f32(i32 36, float %93, float %17)  ; FMin(a,b)
  %122 = fsub fast float %121, %9
  %123 = fmul fast float %10, %122
  %124 = fsub fast float -0.000000e+00, %123
  %125 = call float @dx.op.binary.f32(i32 35, float %124, float -4.000000e+01)  ; FMax(a,b)
  %126 = call float @dx.op.binary.f32(i32 36, float %125, float 5.000000e+00)  ; FMin(a,b)
  %127 = fmul fast float %126, 0x3FF7154760000000
  %128 = call float @dx.op.unary.f32(i32 21, float %127)  ; Exp(value)
  %129 = fmul fast float %128, %120
  br label %130

; <label>:130                                     ; preds = %119, %79
  %131 = phi float [ %129, %119 ], [ 1.000000e+00, %79 ]
  %132 = fmul fast float %105, %15
  %133 = fmul fast float %132, %131
  %134 = fcmp fast ole float %103, %8
  %135 = fcmp fast olt float %103, 0x3F1A36E2E0000000
  %136 = or i1 %134, %135
  br i1 %136, label %183, label %137

; <label>:137                                     ; preds = %130
  %138 = fdiv fast float %8, %103
  %139 = fmul fast float %138, %95
  %140 = fmul fast float %138, %96
  %141 = fmul fast float %138, %97
  %142 = fadd fast float %139, %16
  %143 = fadd fast float %140, %17
  %144 = fadd fast float %141, %18
  %145 = fadd fast float %142, -9.000000e+02
  %146 = fadd fast float %143, -1.500000e+01
  %147 = fadd fast float %144, -7.500000e+02
  %148 = fmul fast float %145, 0x3F62345680000000
  %149 = fmul fast float %146, 0x3F62345680000000
  %150 = fmul fast float %147, 0x3F62345680000000
  %151 = call float @dx.op.dot3.f32(i32 55, float %148, float %149, float %150, float %148, float %149, float %150)  ; Dot3(ax,ay,az,bx,by,bz)
  %152 = fsub fast float 1.000000e+00, %151
  %153 = call float @dx.op.unary.f32(i32 7, float %152)  ; Saturate(value)
  %154 = fmul fast float %153, %153
  %155 = fadd fast float %142, %92
  %156 = fadd fast float %143, %93
  %157 = fadd fast float %144, %94
  %158 = fmul fast float %155, 0x3F52345680000000
  %159 = fadd fast float %158, -2.000000e+00
  %160 = fmul fast float %156, 0x3F52345680000000
  %161 = fadd fast float %160, 0xBFA1111120000000
  %162 = fmul fast float %157, 0x3F52345680000000
  %163 = fadd fast float %162, 0xBFFAAAAAC0000000
  %164 = call float @dx.op.dot3.f32(i32 55, float %159, float %161, float %163, float %159, float %161, float %163)  ; Dot3(ax,ay,az,bx,by,bz)
  %165 = fsub fast float 1.000000e+00, %164
  %166 = call float @dx.op.unary.f32(i32 7, float %165)  ; Saturate(value)
  %167 = fmul fast float %166, %166
  %168 = fmul fast float %167, 4.000000e+00
  %169 = fadd fast float %168, %154
  %170 = fadd fast float %92, -9.000000e+02
  %171 = fadd fast float %93, -1.500000e+01
  %172 = fadd fast float %94, -7.500000e+02
  %173 = fmul fast float %170, 0x3F62345680000000
  %174 = fmul fast float %171, 0x3F62345680000000
  %175 = fmul fast float %172, 0x3F62345680000000
  %176 = call float @dx.op.dot3.f32(i32 55, float %173, float %174, float %175, float %173, float %174, float %175)  ; Dot3(ax,ay,az,bx,by,bz)
  %177 = fsub fast float 1.000000e+00, %176
  %178 = call float @dx.op.unary.f32(i32 7, float %177)  ; Saturate(value)
  %179 = fmul fast float %178, %178
  %180 = fadd fast float %169, %179
  %181 = fmul fast float %104, 0x3F25D867E0000000
  %182 = fmul fast float %181, %180
  br label %183

; <label>:183                                     ; preds = %137, %130
  %184 = phi float [ %182, %137 ], [ 0.000000e+00, %130 ]
  %185 = fadd fast float %184, %133
  %186 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %185)  ; FMin(a,b)
  %187 = fmul fast float %186, 0xBFF7154760000000
  %188 = call float @dx.op.unary.f32(i32 21, float %187)  ; Exp(value)
  %189 = fsub fast float 1.000000e+00, %188
  %190 = call float @dx.op.binary.f32(i32 36, float %11, float %189)  ; FMin(a,b)
  %191 = fsub fast float %12, %47
  %192 = fsub fast float %13, %48
  %193 = fsub fast float %14, %49
  %194 = fmul fast float %190, %191
  %195 = fmul fast float %190, %192
  %196 = fmul fast float %190, %193
  %197 = fadd fast float %194, %47
  %198 = fadd fast float %195, %48
  %199 = fadd fast float %196, %49
  br label %200

; <label>:200                                     ; preds = %183, %60, %54
  %201 = phi float [ %197, %183 ], [ %47, %60 ], [ %47, %54 ]
  %202 = phi float [ %198, %183 ], [ %48, %60 ], [ %48, %54 ]
  %203 = phi float [ %199, %183 ], [ %49, %60 ], [ %49, %54 ]
  %204 = fadd fast float %4, 1.000000e+00
  %205 = fadd fast float %5, 1.000000e+00
  %206 = fsub fast float 1.000000e+00, %4
  %207 = fmul fast float %35, %204
  %208 = fmul fast float %35, %205
  %209 = fmul fast float %35, %206
  %210 = fmul fast float %207, %201
  %211 = fmul fast float %208, %202
  %212 = fmul fast float %209, %203
  %213 = fcmp fast ult float %36, 5.000000e-01
  br i1 %213, label %239, label %214

; <label>:214                                     ; preds = %200
  %215 = fmul fast float %210, 0x4004147AE0000000
  %216 = fmul fast float %211, 0x4004147AE0000000
  %217 = fmul fast float %212, 0x4004147AE0000000
  %218 = fadd fast float %215, 0x3F9EB851E0000000
  %219 = fadd fast float %216, 0x3F9EB851E0000000
  %220 = fadd fast float %217, 0x3F9EB851E0000000
  %221 = fmul fast float %218, %210
  %222 = fmul fast float %219, %211
  %223 = fmul fast float %220, %212
  %224 = fmul fast float %210, 0x400370A3E0000000
  %225 = fmul fast float %211, 0x400370A3E0000000
  %226 = fmul fast float %212, 0x400370A3E0000000
  %227 = fadd fast float %224, 0x3FE2E147A0000000
  %228 = fadd fast float %225, 0x3FE2E147A0000000
  %229 = fadd fast float %226, 0x3FE2E147A0000000
  %230 = fmul fast float %227, %210
  %231 = fmul fast float %228, %211
  %232 = fmul fast float %229, %212
  %233 = fadd fast float %230, 0x3FC1EB8520000000
  %234 = fadd fast float %231, 0x3FC1EB8520000000
  %235 = fadd fast float %232, 0x3FC1EB8520000000
  %236 = fdiv fast float %221, %233
  %237 = fdiv fast float %222, %234
  %238 = fdiv fast float %223, %235
  br label %239

; <label>:239                                     ; preds = %214, %200
  %240 = phi float [ %236, %214 ], [ %210, %200 ]
  %241 = phi float [ %237, %214 ], [ %211, %200 ]
  %242 = phi float [ %238, %214 ], [ %212, %200 ]
  %243 = call float @dx.op.unary.f32(i32 7, float %240)  ; Saturate(value)
  %244 = call float @dx.op.unary.f32(i32 7, float %241)  ; Saturate(value)
  %245 = call float @dx.op.unary.f32(i32 7, float %242)  ; Saturate(value)
  %246 = call float @dx.op.dot3.f32(i32 55, float %243, float %244, float %245, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %247 = fsub fast float %243, %246
  %248 = fsub fast float %244, %246
  %249 = fsub fast float %245, %246
  %250 = fmul fast float %247, %7
  %251 = fmul fast float %248, %7
  %252 = fmul fast float %249, %7
  %253 = fadd fast float %250, %246
  %254 = fadd fast float %251, %246
  %255 = fadd fast float %252, %246
  %256 = call float @dx.op.unary.f32(i32 7, float %253)  ; Saturate(value)
  %257 = call float @dx.op.unary.f32(i32 7, float %254)  ; Saturate(value)
  %258 = call float @dx.op.unary.f32(i32 7, float %255)  ; Saturate(value)
  %259 = fadd fast float %256, 0xBFC70A3D80000000
  %260 = fadd fast float %257, 0xBFC70A3D80000000
  %261 = fadd fast float %258, 0xBFC70A3D80000000
  %262 = fmul fast float %259, %6
  %263 = fmul fast float %260, %6
  %264 = fmul fast float %261, %6
  %265 = fadd fast float %262, 0x3FC70A3D80000000
  %266 = fadd fast float %263, 0x3FC70A3D80000000
  %267 = fadd fast float %264, 0x3FC70A3D80000000
  %268 = call float @dx.op.unary.f32(i32 7, float %265)  ; Saturate(value)
  %269 = call float @dx.op.unary.f32(i32 7, float %266)  ; Saturate(value)
  %270 = call float @dx.op.unary.f32(i32 7, float %267)  ; Saturate(value)
  %271 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %271, label %272, label %1446

; <label>:272                                     ; preds = %239
  %273 = add i32 %45, -1
  %274 = add i32 %42, -1
  %275 = add i32 %43, -1
  %276 = call i32 @dx.op.binary.i32(i32 37, i32 %44, i32 0)  ; IMax(a,b)
  %277 = call i32 @dx.op.binary.i32(i32 37, i32 %273, i32 0)  ; IMax(a,b)
  %278 = call i32 @dx.op.binary.i32(i32 38, i32 %276, i32 %274)  ; IMin(a,b)
  %279 = call i32 @dx.op.binary.i32(i32 38, i32 %277, i32 %275)  ; IMin(a,b)
  %280 = call i32 @dx.op.binary.i32(i32 37, i32 %278, i32 0)  ; IMax(a,b)
  %281 = call i32 @dx.op.binary.i32(i32 37, i32 %279, i32 0)  ; IMax(a,b)
  %282 = call i32 @dx.op.binary.i32(i32 38, i32 %280, i32 %274)  ; IMin(a,b)
  %283 = call i32 @dx.op.binary.i32(i32 38, i32 %281, i32 %275)  ; IMin(a,b)
  %284 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %282, i32 %283, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %285 = extractvalue %dx.types.ResRet.f32 %284, 0
  %286 = extractvalue %dx.types.ResRet.f32 %284, 1
  %287 = extractvalue %dx.types.ResRet.f32 %284, 2
  %288 = extractvalue %dx.types.ResRet.f32 %284, 3
  %289 = fcmp fast olt float %288, 0.000000e+00
  br i1 %289, label %290, label %324

; <label>:290                                     ; preds = %272
  %291 = fcmp fast ogt float %285, 0x3FA4B5DCC0000000
  %292 = fcmp fast ogt float %286, 0x3FA4B5DCC0000000
  %293 = fcmp fast ogt float %287, 0x3FA4B5DCC0000000
  %294 = select i1 %291, float 0.000000e+00, float 1.000000e+00
  %295 = select i1 %292, float 0.000000e+00, float 1.000000e+00
  %296 = select i1 %293, float 0.000000e+00, float 1.000000e+00
  %297 = fmul fast float %285, 0x3FB3D07220000000
  %298 = fmul fast float %286, 0x3FB3D07220000000
  %299 = fmul fast float %287, 0x3FB3D07220000000
  %300 = fadd fast float %285, 0x3FAC28F5C0000000
  %301 = fadd fast float %286, 0x3FAC28F5C0000000
  %302 = fadd fast float %287, 0x3FAC28F5C0000000
  %303 = fmul fast float %300, 0x3FEE54EDE0000000
  %304 = fmul fast float %301, 0x3FEE54EDE0000000
  %305 = fmul fast float %302, 0x3FEE54EDE0000000
  %306 = call float @dx.op.unary.f32(i32 23, float %303)  ; Log(value)
  %307 = call float @dx.op.unary.f32(i32 23, float %304)  ; Log(value)
  %308 = call float @dx.op.unary.f32(i32 23, float %305)  ; Log(value)
  %309 = fmul fast float %306, 0x4003333340000000
  %310 = fmul fast float %307, 0x4003333340000000
  %311 = fmul fast float %308, 0x4003333340000000
  %312 = call float @dx.op.unary.f32(i32 21, float %309)  ; Exp(value)
  %313 = call float @dx.op.unary.f32(i32 21, float %310)  ; Exp(value)
  %314 = call float @dx.op.unary.f32(i32 21, float %311)  ; Exp(value)
  %315 = fsub fast float %297, %312
  %316 = fsub fast float %298, %313
  %317 = fsub fast float %299, %314
  %318 = fmul fast float %315, %294
  %319 = fmul fast float %316, %295
  %320 = fmul fast float %317, %296
  %321 = fadd fast float %318, %312
  %322 = fadd fast float %319, %313
  %323 = fadd fast float %320, %314
  br label %541

; <label>:324                                     ; preds = %272
  %325 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %282, i32 %283, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %326 = extractvalue %dx.types.ResRet.f32 %325, 0
  %327 = fcmp fast ogt float %37, 5.000000e-01
  %328 = fcmp fast olt float %326, 1.000000e+00
  %329 = and i1 %327, %328
  br i1 %329, label %330, label %470

; <label>:330                                     ; preds = %324
  %331 = sitofp i32 %282 to float
  %332 = sitofp i32 %283 to float
  %333 = fadd fast float %331, 5.000000e-01
  %334 = fadd fast float %332, 5.000000e-01
  %335 = uitofp i32 %42 to float
  %336 = uitofp i32 %43 to float
  %337 = fdiv fast float %333, %335
  %338 = fdiv fast float %334, %336
  %339 = fmul fast float %337, 2.000000e+00
  %340 = fmul fast float %338, 2.000000e+00
  %341 = fadd fast float %339, -1.000000e+00
  %342 = fsub fast float 1.000000e+00, %340
  %343 = fmul fast float %341, %34
  %344 = call float @dx.op.tertiary.f32(i32 46, float %342, float %30, float %343)  ; FMad(a,b,c)
  %345 = call float @dx.op.tertiary.f32(i32 46, float %326, float %26, float %344)  ; FMad(a,b,c)
  %346 = fadd fast float %345, %22
  %347 = call float @dx.op.unary.f32(i32 6, float %346)  ; FAbs(value)
  %348 = fcmp fast ogt float %347, 0x3EB0C6F7A0000000
  br i1 %348, label %349, label %470

; <label>:349                                     ; preds = %330
  %350 = fmul fast float %341, %33
  %351 = call float @dx.op.tertiary.f32(i32 46, float %342, float %29, float %350)  ; FMad(a,b,c)
  %352 = call float @dx.op.tertiary.f32(i32 46, float %326, float %25, float %351)  ; FMad(a,b,c)
  %353 = fadd fast float %352, %21
  %354 = fmul fast float %341, %32
  %355 = call float @dx.op.tertiary.f32(i32 46, float %342, float %28, float %354)  ; FMad(a,b,c)
  %356 = call float @dx.op.tertiary.f32(i32 46, float %326, float %24, float %355)  ; FMad(a,b,c)
  %357 = fadd fast float %356, %20
  %358 = fmul fast float %341, %31
  %359 = call float @dx.op.tertiary.f32(i32 46, float %342, float %27, float %358)  ; FMad(a,b,c)
  %360 = call float @dx.op.tertiary.f32(i32 46, float %326, float %23, float %359)  ; FMad(a,b,c)
  %361 = fadd fast float %360, %19
  %362 = fdiv fast float %361, %346
  %363 = fdiv fast float %357, %346
  %364 = fdiv fast float %353, %346
  %365 = fsub fast float %362, %16
  %366 = fsub fast float %363, %17
  %367 = fsub fast float %364, %18
  %368 = fmul fast float %365, %365
  %369 = fmul fast float %366, %366
  %370 = fadd fast float %369, %368
  %371 = fmul fast float %367, %367
  %372 = fadd fast float %370, %371
  %373 = call float @dx.op.unary.f32(i32 24, float %372)  ; Sqrt(value)
  %374 = fsub fast float %373, %8
  %375 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %374)  ; FMax(a,b)
  %376 = fcmp fast ogt float %38, 1.500000e+00
  br i1 %376, label %377, label %400

; <label>:377                                     ; preds = %349
  %378 = call float @dx.op.unary.f32(i32 6, float %366)  ; FAbs(value)
  %379 = fmul fast float %378, %10
  %380 = fcmp fast olt float %379, 0x3F50624DE0000000
  br i1 %380, label %381, label %384

; <label>:381                                     ; preds = %377
  %382 = fmul fast float %379, 5.000000e-01
  %383 = fsub fast float 1.000000e+00, %382
  br label %389

; <label>:384                                     ; preds = %377
  %385 = fmul fast float %379, 0xBFF7154760000000
  %386 = call float @dx.op.unary.f32(i32 21, float %385)  ; Exp(value)
  %387 = fsub fast float 1.000000e+00, %386
  %388 = fdiv fast float %387, %379
  br label %389

; <label>:389                                     ; preds = %384, %381
  %390 = phi float [ %383, %381 ], [ %388, %384 ]
  %391 = call float @dx.op.binary.f32(i32 36, float %363, float %17)  ; FMin(a,b)
  %392 = fsub fast float %391, %9
  %393 = fmul fast float %10, %392
  %394 = fsub fast float -0.000000e+00, %393
  %395 = call float @dx.op.binary.f32(i32 35, float %394, float -4.000000e+01)  ; FMax(a,b)
  %396 = call float @dx.op.binary.f32(i32 36, float %395, float 5.000000e+00)  ; FMin(a,b)
  %397 = fmul fast float %396, 0x3FF7154760000000
  %398 = call float @dx.op.unary.f32(i32 21, float %397)  ; Exp(value)
  %399 = fmul fast float %398, %390
  br label %400

; <label>:400                                     ; preds = %389, %349
  %401 = phi float [ %399, %389 ], [ 1.000000e+00, %349 ]
  %402 = fmul fast float %375, %15
  %403 = fmul fast float %402, %401
  %404 = fcmp fast ole float %373, %8
  %405 = fcmp fast olt float %373, 0x3F1A36E2E0000000
  %406 = or i1 %404, %405
  br i1 %406, label %453, label %407

; <label>:407                                     ; preds = %400
  %408 = fdiv fast float %8, %373
  %409 = fmul fast float %408, %365
  %410 = fmul fast float %408, %366
  %411 = fmul fast float %408, %367
  %412 = fadd fast float %409, %16
  %413 = fadd fast float %410, %17
  %414 = fadd fast float %411, %18
  %415 = fadd fast float %412, -9.000000e+02
  %416 = fadd fast float %413, -1.500000e+01
  %417 = fadd fast float %414, -7.500000e+02
  %418 = fmul fast float %415, 0x3F62345680000000
  %419 = fmul fast float %416, 0x3F62345680000000
  %420 = fmul fast float %417, 0x3F62345680000000
  %421 = call float @dx.op.dot3.f32(i32 55, float %418, float %419, float %420, float %418, float %419, float %420)  ; Dot3(ax,ay,az,bx,by,bz)
  %422 = fsub fast float 1.000000e+00, %421
  %423 = call float @dx.op.unary.f32(i32 7, float %422)  ; Saturate(value)
  %424 = fmul fast float %423, %423
  %425 = fadd fast float %412, %362
  %426 = fadd fast float %413, %363
  %427 = fadd fast float %414, %364
  %428 = fmul fast float %425, 0x3F52345680000000
  %429 = fadd fast float %428, -2.000000e+00
  %430 = fmul fast float %426, 0x3F52345680000000
  %431 = fadd fast float %430, 0xBFA1111120000000
  %432 = fmul fast float %427, 0x3F52345680000000
  %433 = fadd fast float %432, 0xBFFAAAAAC0000000
  %434 = call float @dx.op.dot3.f32(i32 55, float %429, float %431, float %433, float %429, float %431, float %433)  ; Dot3(ax,ay,az,bx,by,bz)
  %435 = fsub fast float 1.000000e+00, %434
  %436 = call float @dx.op.unary.f32(i32 7, float %435)  ; Saturate(value)
  %437 = fmul fast float %436, %436
  %438 = fmul fast float %437, 4.000000e+00
  %439 = fadd fast float %438, %424
  %440 = fadd fast float %362, -9.000000e+02
  %441 = fadd fast float %363, -1.500000e+01
  %442 = fadd fast float %364, -7.500000e+02
  %443 = fmul fast float %440, 0x3F62345680000000
  %444 = fmul fast float %441, 0x3F62345680000000
  %445 = fmul fast float %442, 0x3F62345680000000
  %446 = call float @dx.op.dot3.f32(i32 55, float %443, float %444, float %445, float %443, float %444, float %445)  ; Dot3(ax,ay,az,bx,by,bz)
  %447 = fsub fast float 1.000000e+00, %446
  %448 = call float @dx.op.unary.f32(i32 7, float %447)  ; Saturate(value)
  %449 = fmul fast float %448, %448
  %450 = fadd fast float %439, %449
  %451 = fmul fast float %374, 0x3F25D867E0000000
  %452 = fmul fast float %451, %450
  br label %453

; <label>:453                                     ; preds = %407, %400
  %454 = phi float [ %452, %407 ], [ 0.000000e+00, %400 ]
  %455 = fadd fast float %454, %403
  %456 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %455)  ; FMin(a,b)
  %457 = fmul fast float %456, 0xBFF7154760000000
  %458 = call float @dx.op.unary.f32(i32 21, float %457)  ; Exp(value)
  %459 = fsub fast float 1.000000e+00, %458
  %460 = call float @dx.op.binary.f32(i32 36, float %11, float %459)  ; FMin(a,b)
  %461 = fsub fast float %12, %285
  %462 = fsub fast float %13, %286
  %463 = fsub fast float %14, %287
  %464 = fmul fast float %460, %461
  %465 = fmul fast float %460, %462
  %466 = fmul fast float %460, %463
  %467 = fadd fast float %464, %285
  %468 = fadd fast float %465, %286
  %469 = fadd fast float %466, %287
  br label %470

; <label>:470                                     ; preds = %453, %330, %324
  %471 = phi float [ %467, %453 ], [ %285, %330 ], [ %285, %324 ]
  %472 = phi float [ %468, %453 ], [ %286, %330 ], [ %286, %324 ]
  %473 = phi float [ %469, %453 ], [ %287, %330 ], [ %287, %324 ]
  %474 = fadd fast float %4, 1.000000e+00
  %475 = fadd fast float %5, 1.000000e+00
  %476 = fsub fast float 1.000000e+00, %4
  %477 = fmul fast float %35, %474
  %478 = fmul fast float %35, %475
  %479 = fmul fast float %35, %476
  %480 = fmul fast float %477, %471
  %481 = fmul fast float %478, %472
  %482 = fmul fast float %479, %473
  %483 = fcmp fast ult float %36, 5.000000e-01
  br i1 %483, label %509, label %484

; <label>:484                                     ; preds = %470
  %485 = fmul fast float %480, 0x4004147AE0000000
  %486 = fmul fast float %481, 0x4004147AE0000000
  %487 = fmul fast float %482, 0x4004147AE0000000
  %488 = fadd fast float %485, 0x3F9EB851E0000000
  %489 = fadd fast float %486, 0x3F9EB851E0000000
  %490 = fadd fast float %487, 0x3F9EB851E0000000
  %491 = fmul fast float %488, %480
  %492 = fmul fast float %489, %481
  %493 = fmul fast float %490, %482
  %494 = fmul fast float %480, 0x400370A3E0000000
  %495 = fmul fast float %481, 0x400370A3E0000000
  %496 = fmul fast float %482, 0x400370A3E0000000
  %497 = fadd fast float %494, 0x3FE2E147A0000000
  %498 = fadd fast float %495, 0x3FE2E147A0000000
  %499 = fadd fast float %496, 0x3FE2E147A0000000
  %500 = fmul fast float %497, %480
  %501 = fmul fast float %498, %481
  %502 = fmul fast float %499, %482
  %503 = fadd fast float %500, 0x3FC1EB8520000000
  %504 = fadd fast float %501, 0x3FC1EB8520000000
  %505 = fadd fast float %502, 0x3FC1EB8520000000
  %506 = fdiv fast float %491, %503
  %507 = fdiv fast float %492, %504
  %508 = fdiv fast float %493, %505
  br label %509

; <label>:509                                     ; preds = %484, %470
  %510 = phi float [ %506, %484 ], [ %480, %470 ]
  %511 = phi float [ %507, %484 ], [ %481, %470 ]
  %512 = phi float [ %508, %484 ], [ %482, %470 ]
  %513 = call float @dx.op.unary.f32(i32 7, float %510)  ; Saturate(value)
  %514 = call float @dx.op.unary.f32(i32 7, float %511)  ; Saturate(value)
  %515 = call float @dx.op.unary.f32(i32 7, float %512)  ; Saturate(value)
  %516 = call float @dx.op.dot3.f32(i32 55, float %513, float %514, float %515, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %517 = fsub fast float %513, %516
  %518 = fsub fast float %514, %516
  %519 = fsub fast float %515, %516
  %520 = fmul fast float %517, %7
  %521 = fmul fast float %518, %7
  %522 = fmul fast float %519, %7
  %523 = fadd fast float %520, %516
  %524 = fadd fast float %521, %516
  %525 = fadd fast float %522, %516
  %526 = call float @dx.op.unary.f32(i32 7, float %523)  ; Saturate(value)
  %527 = call float @dx.op.unary.f32(i32 7, float %524)  ; Saturate(value)
  %528 = call float @dx.op.unary.f32(i32 7, float %525)  ; Saturate(value)
  %529 = fadd fast float %526, 0xBFC70A3D80000000
  %530 = fadd fast float %527, 0xBFC70A3D80000000
  %531 = fadd fast float %528, 0xBFC70A3D80000000
  %532 = fmul fast float %529, %6
  %533 = fmul fast float %530, %6
  %534 = fmul fast float %531, %6
  %535 = fadd fast float %532, 0x3FC70A3D80000000
  %536 = fadd fast float %533, 0x3FC70A3D80000000
  %537 = fadd fast float %534, 0x3FC70A3D80000000
  %538 = call float @dx.op.unary.f32(i32 7, float %535)  ; Saturate(value)
  %539 = call float @dx.op.unary.f32(i32 7, float %536)  ; Saturate(value)
  %540 = call float @dx.op.unary.f32(i32 7, float %537)  ; Saturate(value)
  br label %541

; <label>:541                                     ; preds = %509, %290
  %542 = phi float [ %321, %290 ], [ %538, %509 ]
  %543 = phi float [ %322, %290 ], [ %539, %509 ]
  %544 = phi float [ %323, %290 ], [ %540, %509 ]
  %545 = add i32 %45, 1
  %546 = call i32 @dx.op.binary.i32(i32 37, i32 %545, i32 0)  ; IMax(a,b)
  %547 = call i32 @dx.op.binary.i32(i32 38, i32 %546, i32 %275)  ; IMin(a,b)
  %548 = call i32 @dx.op.binary.i32(i32 37, i32 %547, i32 0)  ; IMax(a,b)
  %549 = call i32 @dx.op.binary.i32(i32 38, i32 %548, i32 %275)  ; IMin(a,b)
  %550 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %282, i32 %549, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %551 = extractvalue %dx.types.ResRet.f32 %550, 0
  %552 = extractvalue %dx.types.ResRet.f32 %550, 1
  %553 = extractvalue %dx.types.ResRet.f32 %550, 2
  %554 = extractvalue %dx.types.ResRet.f32 %550, 3
  %555 = fcmp fast olt float %554, 0.000000e+00
  br i1 %555, label %556, label %590

; <label>:556                                     ; preds = %541
  %557 = fcmp fast ogt float %551, 0x3FA4B5DCC0000000
  %558 = fcmp fast ogt float %552, 0x3FA4B5DCC0000000
  %559 = fcmp fast ogt float %553, 0x3FA4B5DCC0000000
  %560 = select i1 %557, float 0.000000e+00, float 1.000000e+00
  %561 = select i1 %558, float 0.000000e+00, float 1.000000e+00
  %562 = select i1 %559, float 0.000000e+00, float 1.000000e+00
  %563 = fmul fast float %551, 0x3FB3D07220000000
  %564 = fmul fast float %552, 0x3FB3D07220000000
  %565 = fmul fast float %553, 0x3FB3D07220000000
  %566 = fadd fast float %551, 0x3FAC28F5C0000000
  %567 = fadd fast float %552, 0x3FAC28F5C0000000
  %568 = fadd fast float %553, 0x3FAC28F5C0000000
  %569 = fmul fast float %566, 0x3FEE54EDE0000000
  %570 = fmul fast float %567, 0x3FEE54EDE0000000
  %571 = fmul fast float %568, 0x3FEE54EDE0000000
  %572 = call float @dx.op.unary.f32(i32 23, float %569)  ; Log(value)
  %573 = call float @dx.op.unary.f32(i32 23, float %570)  ; Log(value)
  %574 = call float @dx.op.unary.f32(i32 23, float %571)  ; Log(value)
  %575 = fmul fast float %572, 0x4003333340000000
  %576 = fmul fast float %573, 0x4003333340000000
  %577 = fmul fast float %574, 0x4003333340000000
  %578 = call float @dx.op.unary.f32(i32 21, float %575)  ; Exp(value)
  %579 = call float @dx.op.unary.f32(i32 21, float %576)  ; Exp(value)
  %580 = call float @dx.op.unary.f32(i32 21, float %577)  ; Exp(value)
  %581 = fsub fast float %563, %578
  %582 = fsub fast float %564, %579
  %583 = fsub fast float %565, %580
  %584 = fmul fast float %581, %560
  %585 = fmul fast float %582, %561
  %586 = fmul fast float %583, %562
  %587 = fadd fast float %584, %578
  %588 = fadd fast float %585, %579
  %589 = fadd fast float %586, %580
  br label %807

; <label>:590                                     ; preds = %541
  %591 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %282, i32 %549, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %592 = extractvalue %dx.types.ResRet.f32 %591, 0
  %593 = fcmp fast ogt float %37, 5.000000e-01
  %594 = fcmp fast olt float %592, 1.000000e+00
  %595 = and i1 %593, %594
  br i1 %595, label %596, label %736

; <label>:596                                     ; preds = %590
  %597 = sitofp i32 %282 to float
  %598 = sitofp i32 %549 to float
  %599 = fadd fast float %597, 5.000000e-01
  %600 = fadd fast float %598, 5.000000e-01
  %601 = uitofp i32 %42 to float
  %602 = uitofp i32 %43 to float
  %603 = fdiv fast float %599, %601
  %604 = fdiv fast float %600, %602
  %605 = fmul fast float %603, 2.000000e+00
  %606 = fmul fast float %604, 2.000000e+00
  %607 = fadd fast float %605, -1.000000e+00
  %608 = fsub fast float 1.000000e+00, %606
  %609 = fmul fast float %607, %34
  %610 = call float @dx.op.tertiary.f32(i32 46, float %608, float %30, float %609)  ; FMad(a,b,c)
  %611 = call float @dx.op.tertiary.f32(i32 46, float %592, float %26, float %610)  ; FMad(a,b,c)
  %612 = fadd fast float %611, %22
  %613 = call float @dx.op.unary.f32(i32 6, float %612)  ; FAbs(value)
  %614 = fcmp fast ogt float %613, 0x3EB0C6F7A0000000
  br i1 %614, label %615, label %736

; <label>:615                                     ; preds = %596
  %616 = fmul fast float %607, %33
  %617 = call float @dx.op.tertiary.f32(i32 46, float %608, float %29, float %616)  ; FMad(a,b,c)
  %618 = call float @dx.op.tertiary.f32(i32 46, float %592, float %25, float %617)  ; FMad(a,b,c)
  %619 = fadd fast float %618, %21
  %620 = fmul fast float %607, %32
  %621 = call float @dx.op.tertiary.f32(i32 46, float %608, float %28, float %620)  ; FMad(a,b,c)
  %622 = call float @dx.op.tertiary.f32(i32 46, float %592, float %24, float %621)  ; FMad(a,b,c)
  %623 = fadd fast float %622, %20
  %624 = fmul fast float %607, %31
  %625 = call float @dx.op.tertiary.f32(i32 46, float %608, float %27, float %624)  ; FMad(a,b,c)
  %626 = call float @dx.op.tertiary.f32(i32 46, float %592, float %23, float %625)  ; FMad(a,b,c)
  %627 = fadd fast float %626, %19
  %628 = fdiv fast float %627, %612
  %629 = fdiv fast float %623, %612
  %630 = fdiv fast float %619, %612
  %631 = fsub fast float %628, %16
  %632 = fsub fast float %629, %17
  %633 = fsub fast float %630, %18
  %634 = fmul fast float %631, %631
  %635 = fmul fast float %632, %632
  %636 = fadd fast float %635, %634
  %637 = fmul fast float %633, %633
  %638 = fadd fast float %636, %637
  %639 = call float @dx.op.unary.f32(i32 24, float %638)  ; Sqrt(value)
  %640 = fsub fast float %639, %8
  %641 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %640)  ; FMax(a,b)
  %642 = fcmp fast ogt float %38, 1.500000e+00
  br i1 %642, label %643, label %666

; <label>:643                                     ; preds = %615
  %644 = call float @dx.op.unary.f32(i32 6, float %632)  ; FAbs(value)
  %645 = fmul fast float %644, %10
  %646 = fcmp fast olt float %645, 0x3F50624DE0000000
  br i1 %646, label %647, label %650

; <label>:647                                     ; preds = %643
  %648 = fmul fast float %645, 5.000000e-01
  %649 = fsub fast float 1.000000e+00, %648
  br label %655

; <label>:650                                     ; preds = %643
  %651 = fmul fast float %645, 0xBFF7154760000000
  %652 = call float @dx.op.unary.f32(i32 21, float %651)  ; Exp(value)
  %653 = fsub fast float 1.000000e+00, %652
  %654 = fdiv fast float %653, %645
  br label %655

; <label>:655                                     ; preds = %650, %647
  %656 = phi float [ %649, %647 ], [ %654, %650 ]
  %657 = call float @dx.op.binary.f32(i32 36, float %629, float %17)  ; FMin(a,b)
  %658 = fsub fast float %657, %9
  %659 = fmul fast float %10, %658
  %660 = fsub fast float -0.000000e+00, %659
  %661 = call float @dx.op.binary.f32(i32 35, float %660, float -4.000000e+01)  ; FMax(a,b)
  %662 = call float @dx.op.binary.f32(i32 36, float %661, float 5.000000e+00)  ; FMin(a,b)
  %663 = fmul fast float %662, 0x3FF7154760000000
  %664 = call float @dx.op.unary.f32(i32 21, float %663)  ; Exp(value)
  %665 = fmul fast float %664, %656
  br label %666

; <label>:666                                     ; preds = %655, %615
  %667 = phi float [ %665, %655 ], [ 1.000000e+00, %615 ]
  %668 = fmul fast float %641, %15
  %669 = fmul fast float %668, %667
  %670 = fcmp fast ole float %639, %8
  %671 = fcmp fast olt float %639, 0x3F1A36E2E0000000
  %672 = or i1 %670, %671
  br i1 %672, label %719, label %673

; <label>:673                                     ; preds = %666
  %674 = fdiv fast float %8, %639
  %675 = fmul fast float %674, %631
  %676 = fmul fast float %674, %632
  %677 = fmul fast float %674, %633
  %678 = fadd fast float %675, %16
  %679 = fadd fast float %676, %17
  %680 = fadd fast float %677, %18
  %681 = fadd fast float %678, -9.000000e+02
  %682 = fadd fast float %679, -1.500000e+01
  %683 = fadd fast float %680, -7.500000e+02
  %684 = fmul fast float %681, 0x3F62345680000000
  %685 = fmul fast float %682, 0x3F62345680000000
  %686 = fmul fast float %683, 0x3F62345680000000
  %687 = call float @dx.op.dot3.f32(i32 55, float %684, float %685, float %686, float %684, float %685, float %686)  ; Dot3(ax,ay,az,bx,by,bz)
  %688 = fsub fast float 1.000000e+00, %687
  %689 = call float @dx.op.unary.f32(i32 7, float %688)  ; Saturate(value)
  %690 = fmul fast float %689, %689
  %691 = fadd fast float %678, %628
  %692 = fadd fast float %679, %629
  %693 = fadd fast float %680, %630
  %694 = fmul fast float %691, 0x3F52345680000000
  %695 = fadd fast float %694, -2.000000e+00
  %696 = fmul fast float %692, 0x3F52345680000000
  %697 = fadd fast float %696, 0xBFA1111120000000
  %698 = fmul fast float %693, 0x3F52345680000000
  %699 = fadd fast float %698, 0xBFFAAAAAC0000000
  %700 = call float @dx.op.dot3.f32(i32 55, float %695, float %697, float %699, float %695, float %697, float %699)  ; Dot3(ax,ay,az,bx,by,bz)
  %701 = fsub fast float 1.000000e+00, %700
  %702 = call float @dx.op.unary.f32(i32 7, float %701)  ; Saturate(value)
  %703 = fmul fast float %702, %702
  %704 = fmul fast float %703, 4.000000e+00
  %705 = fadd fast float %704, %690
  %706 = fadd fast float %628, -9.000000e+02
  %707 = fadd fast float %629, -1.500000e+01
  %708 = fadd fast float %630, -7.500000e+02
  %709 = fmul fast float %706, 0x3F62345680000000
  %710 = fmul fast float %707, 0x3F62345680000000
  %711 = fmul fast float %708, 0x3F62345680000000
  %712 = call float @dx.op.dot3.f32(i32 55, float %709, float %710, float %711, float %709, float %710, float %711)  ; Dot3(ax,ay,az,bx,by,bz)
  %713 = fsub fast float 1.000000e+00, %712
  %714 = call float @dx.op.unary.f32(i32 7, float %713)  ; Saturate(value)
  %715 = fmul fast float %714, %714
  %716 = fadd fast float %705, %715
  %717 = fmul fast float %640, 0x3F25D867E0000000
  %718 = fmul fast float %717, %716
  br label %719

; <label>:719                                     ; preds = %673, %666
  %720 = phi float [ %718, %673 ], [ 0.000000e+00, %666 ]
  %721 = fadd fast float %720, %669
  %722 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %721)  ; FMin(a,b)
  %723 = fmul fast float %722, 0xBFF7154760000000
  %724 = call float @dx.op.unary.f32(i32 21, float %723)  ; Exp(value)
  %725 = fsub fast float 1.000000e+00, %724
  %726 = call float @dx.op.binary.f32(i32 36, float %11, float %725)  ; FMin(a,b)
  %727 = fsub fast float %12, %551
  %728 = fsub fast float %13, %552
  %729 = fsub fast float %14, %553
  %730 = fmul fast float %726, %727
  %731 = fmul fast float %726, %728
  %732 = fmul fast float %726, %729
  %733 = fadd fast float %730, %551
  %734 = fadd fast float %731, %552
  %735 = fadd fast float %732, %553
  br label %736

; <label>:736                                     ; preds = %719, %596, %590
  %737 = phi float [ %733, %719 ], [ %551, %596 ], [ %551, %590 ]
  %738 = phi float [ %734, %719 ], [ %552, %596 ], [ %552, %590 ]
  %739 = phi float [ %735, %719 ], [ %553, %596 ], [ %553, %590 ]
  %740 = fadd fast float %4, 1.000000e+00
  %741 = fadd fast float %5, 1.000000e+00
  %742 = fsub fast float 1.000000e+00, %4
  %743 = fmul fast float %35, %740
  %744 = fmul fast float %35, %741
  %745 = fmul fast float %35, %742
  %746 = fmul fast float %743, %737
  %747 = fmul fast float %744, %738
  %748 = fmul fast float %745, %739
  %749 = fcmp fast ult float %36, 5.000000e-01
  br i1 %749, label %775, label %750

; <label>:750                                     ; preds = %736
  %751 = fmul fast float %746, 0x4004147AE0000000
  %752 = fmul fast float %747, 0x4004147AE0000000
  %753 = fmul fast float %748, 0x4004147AE0000000
  %754 = fadd fast float %751, 0x3F9EB851E0000000
  %755 = fadd fast float %752, 0x3F9EB851E0000000
  %756 = fadd fast float %753, 0x3F9EB851E0000000
  %757 = fmul fast float %754, %746
  %758 = fmul fast float %755, %747
  %759 = fmul fast float %756, %748
  %760 = fmul fast float %746, 0x400370A3E0000000
  %761 = fmul fast float %747, 0x400370A3E0000000
  %762 = fmul fast float %748, 0x400370A3E0000000
  %763 = fadd fast float %760, 0x3FE2E147A0000000
  %764 = fadd fast float %761, 0x3FE2E147A0000000
  %765 = fadd fast float %762, 0x3FE2E147A0000000
  %766 = fmul fast float %763, %746
  %767 = fmul fast float %764, %747
  %768 = fmul fast float %765, %748
  %769 = fadd fast float %766, 0x3FC1EB8520000000
  %770 = fadd fast float %767, 0x3FC1EB8520000000
  %771 = fadd fast float %768, 0x3FC1EB8520000000
  %772 = fdiv fast float %757, %769
  %773 = fdiv fast float %758, %770
  %774 = fdiv fast float %759, %771
  br label %775

; <label>:775                                     ; preds = %750, %736
  %776 = phi float [ %772, %750 ], [ %746, %736 ]
  %777 = phi float [ %773, %750 ], [ %747, %736 ]
  %778 = phi float [ %774, %750 ], [ %748, %736 ]
  %779 = call float @dx.op.unary.f32(i32 7, float %776)  ; Saturate(value)
  %780 = call float @dx.op.unary.f32(i32 7, float %777)  ; Saturate(value)
  %781 = call float @dx.op.unary.f32(i32 7, float %778)  ; Saturate(value)
  %782 = call float @dx.op.dot3.f32(i32 55, float %779, float %780, float %781, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %783 = fsub fast float %779, %782
  %784 = fsub fast float %780, %782
  %785 = fsub fast float %781, %782
  %786 = fmul fast float %783, %7
  %787 = fmul fast float %784, %7
  %788 = fmul fast float %785, %7
  %789 = fadd fast float %786, %782
  %790 = fadd fast float %787, %782
  %791 = fadd fast float %788, %782
  %792 = call float @dx.op.unary.f32(i32 7, float %789)  ; Saturate(value)
  %793 = call float @dx.op.unary.f32(i32 7, float %790)  ; Saturate(value)
  %794 = call float @dx.op.unary.f32(i32 7, float %791)  ; Saturate(value)
  %795 = fadd fast float %792, 0xBFC70A3D80000000
  %796 = fadd fast float %793, 0xBFC70A3D80000000
  %797 = fadd fast float %794, 0xBFC70A3D80000000
  %798 = fmul fast float %795, %6
  %799 = fmul fast float %796, %6
  %800 = fmul fast float %797, %6
  %801 = fadd fast float %798, 0x3FC70A3D80000000
  %802 = fadd fast float %799, 0x3FC70A3D80000000
  %803 = fadd fast float %800, 0x3FC70A3D80000000
  %804 = call float @dx.op.unary.f32(i32 7, float %801)  ; Saturate(value)
  %805 = call float @dx.op.unary.f32(i32 7, float %802)  ; Saturate(value)
  %806 = call float @dx.op.unary.f32(i32 7, float %803)  ; Saturate(value)
  br label %807

; <label>:807                                     ; preds = %775, %556
  %808 = phi float [ %587, %556 ], [ %804, %775 ]
  %809 = phi float [ %588, %556 ], [ %805, %775 ]
  %810 = phi float [ %589, %556 ], [ %806, %775 ]
  %811 = add i32 %44, -1
  %812 = call i32 @dx.op.binary.i32(i32 37, i32 %811, i32 0)  ; IMax(a,b)
  %813 = call i32 @dx.op.binary.i32(i32 37, i32 %45, i32 0)  ; IMax(a,b)
  %814 = call i32 @dx.op.binary.i32(i32 38, i32 %812, i32 %274)  ; IMin(a,b)
  %815 = call i32 @dx.op.binary.i32(i32 38, i32 %813, i32 %275)  ; IMin(a,b)
  %816 = call i32 @dx.op.binary.i32(i32 37, i32 %814, i32 0)  ; IMax(a,b)
  %817 = call i32 @dx.op.binary.i32(i32 37, i32 %815, i32 0)  ; IMax(a,b)
  %818 = call i32 @dx.op.binary.i32(i32 38, i32 %816, i32 %274)  ; IMin(a,b)
  %819 = call i32 @dx.op.binary.i32(i32 38, i32 %817, i32 %275)  ; IMin(a,b)
  %820 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %818, i32 %819, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %821 = extractvalue %dx.types.ResRet.f32 %820, 0
  %822 = extractvalue %dx.types.ResRet.f32 %820, 1
  %823 = extractvalue %dx.types.ResRet.f32 %820, 2
  %824 = extractvalue %dx.types.ResRet.f32 %820, 3
  %825 = fcmp fast olt float %824, 0.000000e+00
  br i1 %825, label %826, label %860

; <label>:826                                     ; preds = %807
  %827 = fcmp fast ogt float %821, 0x3FA4B5DCC0000000
  %828 = fcmp fast ogt float %822, 0x3FA4B5DCC0000000
  %829 = fcmp fast ogt float %823, 0x3FA4B5DCC0000000
  %830 = select i1 %827, float 0.000000e+00, float 1.000000e+00
  %831 = select i1 %828, float 0.000000e+00, float 1.000000e+00
  %832 = select i1 %829, float 0.000000e+00, float 1.000000e+00
  %833 = fmul fast float %821, 0x3FB3D07220000000
  %834 = fmul fast float %822, 0x3FB3D07220000000
  %835 = fmul fast float %823, 0x3FB3D07220000000
  %836 = fadd fast float %821, 0x3FAC28F5C0000000
  %837 = fadd fast float %822, 0x3FAC28F5C0000000
  %838 = fadd fast float %823, 0x3FAC28F5C0000000
  %839 = fmul fast float %836, 0x3FEE54EDE0000000
  %840 = fmul fast float %837, 0x3FEE54EDE0000000
  %841 = fmul fast float %838, 0x3FEE54EDE0000000
  %842 = call float @dx.op.unary.f32(i32 23, float %839)  ; Log(value)
  %843 = call float @dx.op.unary.f32(i32 23, float %840)  ; Log(value)
  %844 = call float @dx.op.unary.f32(i32 23, float %841)  ; Log(value)
  %845 = fmul fast float %842, 0x4003333340000000
  %846 = fmul fast float %843, 0x4003333340000000
  %847 = fmul fast float %844, 0x4003333340000000
  %848 = call float @dx.op.unary.f32(i32 21, float %845)  ; Exp(value)
  %849 = call float @dx.op.unary.f32(i32 21, float %846)  ; Exp(value)
  %850 = call float @dx.op.unary.f32(i32 21, float %847)  ; Exp(value)
  %851 = fsub fast float %833, %848
  %852 = fsub fast float %834, %849
  %853 = fsub fast float %835, %850
  %854 = fmul fast float %851, %830
  %855 = fmul fast float %852, %831
  %856 = fmul fast float %853, %832
  %857 = fadd fast float %854, %848
  %858 = fadd fast float %855, %849
  %859 = fadd fast float %856, %850
  br label %1077

; <label>:860                                     ; preds = %807
  %861 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %818, i32 %819, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %862 = extractvalue %dx.types.ResRet.f32 %861, 0
  %863 = fcmp fast ogt float %37, 5.000000e-01
  %864 = fcmp fast olt float %862, 1.000000e+00
  %865 = and i1 %863, %864
  br i1 %865, label %866, label %1006

; <label>:866                                     ; preds = %860
  %867 = sitofp i32 %818 to float
  %868 = sitofp i32 %819 to float
  %869 = fadd fast float %867, 5.000000e-01
  %870 = fadd fast float %868, 5.000000e-01
  %871 = uitofp i32 %42 to float
  %872 = uitofp i32 %43 to float
  %873 = fdiv fast float %869, %871
  %874 = fdiv fast float %870, %872
  %875 = fmul fast float %873, 2.000000e+00
  %876 = fmul fast float %874, 2.000000e+00
  %877 = fadd fast float %875, -1.000000e+00
  %878 = fsub fast float 1.000000e+00, %876
  %879 = fmul fast float %877, %34
  %880 = call float @dx.op.tertiary.f32(i32 46, float %878, float %30, float %879)  ; FMad(a,b,c)
  %881 = call float @dx.op.tertiary.f32(i32 46, float %862, float %26, float %880)  ; FMad(a,b,c)
  %882 = fadd fast float %881, %22
  %883 = call float @dx.op.unary.f32(i32 6, float %882)  ; FAbs(value)
  %884 = fcmp fast ogt float %883, 0x3EB0C6F7A0000000
  br i1 %884, label %885, label %1006

; <label>:885                                     ; preds = %866
  %886 = fmul fast float %877, %33
  %887 = call float @dx.op.tertiary.f32(i32 46, float %878, float %29, float %886)  ; FMad(a,b,c)
  %888 = call float @dx.op.tertiary.f32(i32 46, float %862, float %25, float %887)  ; FMad(a,b,c)
  %889 = fadd fast float %888, %21
  %890 = fmul fast float %877, %32
  %891 = call float @dx.op.tertiary.f32(i32 46, float %878, float %28, float %890)  ; FMad(a,b,c)
  %892 = call float @dx.op.tertiary.f32(i32 46, float %862, float %24, float %891)  ; FMad(a,b,c)
  %893 = fadd fast float %892, %20
  %894 = fmul fast float %877, %31
  %895 = call float @dx.op.tertiary.f32(i32 46, float %878, float %27, float %894)  ; FMad(a,b,c)
  %896 = call float @dx.op.tertiary.f32(i32 46, float %862, float %23, float %895)  ; FMad(a,b,c)
  %897 = fadd fast float %896, %19
  %898 = fdiv fast float %897, %882
  %899 = fdiv fast float %893, %882
  %900 = fdiv fast float %889, %882
  %901 = fsub fast float %898, %16
  %902 = fsub fast float %899, %17
  %903 = fsub fast float %900, %18
  %904 = fmul fast float %901, %901
  %905 = fmul fast float %902, %902
  %906 = fadd fast float %905, %904
  %907 = fmul fast float %903, %903
  %908 = fadd fast float %906, %907
  %909 = call float @dx.op.unary.f32(i32 24, float %908)  ; Sqrt(value)
  %910 = fsub fast float %909, %8
  %911 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %910)  ; FMax(a,b)
  %912 = fcmp fast ogt float %38, 1.500000e+00
  br i1 %912, label %913, label %936

; <label>:913                                     ; preds = %885
  %914 = call float @dx.op.unary.f32(i32 6, float %902)  ; FAbs(value)
  %915 = fmul fast float %914, %10
  %916 = fcmp fast olt float %915, 0x3F50624DE0000000
  br i1 %916, label %917, label %920

; <label>:917                                     ; preds = %913
  %918 = fmul fast float %915, 5.000000e-01
  %919 = fsub fast float 1.000000e+00, %918
  br label %925

; <label>:920                                     ; preds = %913
  %921 = fmul fast float %915, 0xBFF7154760000000
  %922 = call float @dx.op.unary.f32(i32 21, float %921)  ; Exp(value)
  %923 = fsub fast float 1.000000e+00, %922
  %924 = fdiv fast float %923, %915
  br label %925

; <label>:925                                     ; preds = %920, %917
  %926 = phi float [ %919, %917 ], [ %924, %920 ]
  %927 = call float @dx.op.binary.f32(i32 36, float %899, float %17)  ; FMin(a,b)
  %928 = fsub fast float %927, %9
  %929 = fmul fast float %10, %928
  %930 = fsub fast float -0.000000e+00, %929
  %931 = call float @dx.op.binary.f32(i32 35, float %930, float -4.000000e+01)  ; FMax(a,b)
  %932 = call float @dx.op.binary.f32(i32 36, float %931, float 5.000000e+00)  ; FMin(a,b)
  %933 = fmul fast float %932, 0x3FF7154760000000
  %934 = call float @dx.op.unary.f32(i32 21, float %933)  ; Exp(value)
  %935 = fmul fast float %934, %926
  br label %936

; <label>:936                                     ; preds = %925, %885
  %937 = phi float [ %935, %925 ], [ 1.000000e+00, %885 ]
  %938 = fmul fast float %911, %15
  %939 = fmul fast float %938, %937
  %940 = fcmp fast ole float %909, %8
  %941 = fcmp fast olt float %909, 0x3F1A36E2E0000000
  %942 = or i1 %940, %941
  br i1 %942, label %989, label %943

; <label>:943                                     ; preds = %936
  %944 = fdiv fast float %8, %909
  %945 = fmul fast float %944, %901
  %946 = fmul fast float %944, %902
  %947 = fmul fast float %944, %903
  %948 = fadd fast float %945, %16
  %949 = fadd fast float %946, %17
  %950 = fadd fast float %947, %18
  %951 = fadd fast float %948, -9.000000e+02
  %952 = fadd fast float %949, -1.500000e+01
  %953 = fadd fast float %950, -7.500000e+02
  %954 = fmul fast float %951, 0x3F62345680000000
  %955 = fmul fast float %952, 0x3F62345680000000
  %956 = fmul fast float %953, 0x3F62345680000000
  %957 = call float @dx.op.dot3.f32(i32 55, float %954, float %955, float %956, float %954, float %955, float %956)  ; Dot3(ax,ay,az,bx,by,bz)
  %958 = fsub fast float 1.000000e+00, %957
  %959 = call float @dx.op.unary.f32(i32 7, float %958)  ; Saturate(value)
  %960 = fmul fast float %959, %959
  %961 = fadd fast float %948, %898
  %962 = fadd fast float %949, %899
  %963 = fadd fast float %950, %900
  %964 = fmul fast float %961, 0x3F52345680000000
  %965 = fadd fast float %964, -2.000000e+00
  %966 = fmul fast float %962, 0x3F52345680000000
  %967 = fadd fast float %966, 0xBFA1111120000000
  %968 = fmul fast float %963, 0x3F52345680000000
  %969 = fadd fast float %968, 0xBFFAAAAAC0000000
  %970 = call float @dx.op.dot3.f32(i32 55, float %965, float %967, float %969, float %965, float %967, float %969)  ; Dot3(ax,ay,az,bx,by,bz)
  %971 = fsub fast float 1.000000e+00, %970
  %972 = call float @dx.op.unary.f32(i32 7, float %971)  ; Saturate(value)
  %973 = fmul fast float %972, %972
  %974 = fmul fast float %973, 4.000000e+00
  %975 = fadd fast float %974, %960
  %976 = fadd fast float %898, -9.000000e+02
  %977 = fadd fast float %899, -1.500000e+01
  %978 = fadd fast float %900, -7.500000e+02
  %979 = fmul fast float %976, 0x3F62345680000000
  %980 = fmul fast float %977, 0x3F62345680000000
  %981 = fmul fast float %978, 0x3F62345680000000
  %982 = call float @dx.op.dot3.f32(i32 55, float %979, float %980, float %981, float %979, float %980, float %981)  ; Dot3(ax,ay,az,bx,by,bz)
  %983 = fsub fast float 1.000000e+00, %982
  %984 = call float @dx.op.unary.f32(i32 7, float %983)  ; Saturate(value)
  %985 = fmul fast float %984, %984
  %986 = fadd fast float %975, %985
  %987 = fmul fast float %910, 0x3F25D867E0000000
  %988 = fmul fast float %987, %986
  br label %989

; <label>:989                                     ; preds = %943, %936
  %990 = phi float [ %988, %943 ], [ 0.000000e+00, %936 ]
  %991 = fadd fast float %990, %939
  %992 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %991)  ; FMin(a,b)
  %993 = fmul fast float %992, 0xBFF7154760000000
  %994 = call float @dx.op.unary.f32(i32 21, float %993)  ; Exp(value)
  %995 = fsub fast float 1.000000e+00, %994
  %996 = call float @dx.op.binary.f32(i32 36, float %11, float %995)  ; FMin(a,b)
  %997 = fsub fast float %12, %821
  %998 = fsub fast float %13, %822
  %999 = fsub fast float %14, %823
  %1000 = fmul fast float %996, %997
  %1001 = fmul fast float %996, %998
  %1002 = fmul fast float %996, %999
  %1003 = fadd fast float %1000, %821
  %1004 = fadd fast float %1001, %822
  %1005 = fadd fast float %1002, %823
  br label %1006

; <label>:1006                                    ; preds = %989, %866, %860
  %1007 = phi float [ %1003, %989 ], [ %821, %866 ], [ %821, %860 ]
  %1008 = phi float [ %1004, %989 ], [ %822, %866 ], [ %822, %860 ]
  %1009 = phi float [ %1005, %989 ], [ %823, %866 ], [ %823, %860 ]
  %1010 = fadd fast float %4, 1.000000e+00
  %1011 = fadd fast float %5, 1.000000e+00
  %1012 = fsub fast float 1.000000e+00, %4
  %1013 = fmul fast float %35, %1010
  %1014 = fmul fast float %35, %1011
  %1015 = fmul fast float %35, %1012
  %1016 = fmul fast float %1013, %1007
  %1017 = fmul fast float %1014, %1008
  %1018 = fmul fast float %1015, %1009
  %1019 = fcmp fast ult float %36, 5.000000e-01
  br i1 %1019, label %1045, label %1020

; <label>:1020                                    ; preds = %1006
  %1021 = fmul fast float %1016, 0x4004147AE0000000
  %1022 = fmul fast float %1017, 0x4004147AE0000000
  %1023 = fmul fast float %1018, 0x4004147AE0000000
  %1024 = fadd fast float %1021, 0x3F9EB851E0000000
  %1025 = fadd fast float %1022, 0x3F9EB851E0000000
  %1026 = fadd fast float %1023, 0x3F9EB851E0000000
  %1027 = fmul fast float %1024, %1016
  %1028 = fmul fast float %1025, %1017
  %1029 = fmul fast float %1026, %1018
  %1030 = fmul fast float %1016, 0x400370A3E0000000
  %1031 = fmul fast float %1017, 0x400370A3E0000000
  %1032 = fmul fast float %1018, 0x400370A3E0000000
  %1033 = fadd fast float %1030, 0x3FE2E147A0000000
  %1034 = fadd fast float %1031, 0x3FE2E147A0000000
  %1035 = fadd fast float %1032, 0x3FE2E147A0000000
  %1036 = fmul fast float %1033, %1016
  %1037 = fmul fast float %1034, %1017
  %1038 = fmul fast float %1035, %1018
  %1039 = fadd fast float %1036, 0x3FC1EB8520000000
  %1040 = fadd fast float %1037, 0x3FC1EB8520000000
  %1041 = fadd fast float %1038, 0x3FC1EB8520000000
  %1042 = fdiv fast float %1027, %1039
  %1043 = fdiv fast float %1028, %1040
  %1044 = fdiv fast float %1029, %1041
  br label %1045

; <label>:1045                                    ; preds = %1020, %1006
  %1046 = phi float [ %1042, %1020 ], [ %1016, %1006 ]
  %1047 = phi float [ %1043, %1020 ], [ %1017, %1006 ]
  %1048 = phi float [ %1044, %1020 ], [ %1018, %1006 ]
  %1049 = call float @dx.op.unary.f32(i32 7, float %1046)  ; Saturate(value)
  %1050 = call float @dx.op.unary.f32(i32 7, float %1047)  ; Saturate(value)
  %1051 = call float @dx.op.unary.f32(i32 7, float %1048)  ; Saturate(value)
  %1052 = call float @dx.op.dot3.f32(i32 55, float %1049, float %1050, float %1051, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1053 = fsub fast float %1049, %1052
  %1054 = fsub fast float %1050, %1052
  %1055 = fsub fast float %1051, %1052
  %1056 = fmul fast float %1053, %7
  %1057 = fmul fast float %1054, %7
  %1058 = fmul fast float %1055, %7
  %1059 = fadd fast float %1056, %1052
  %1060 = fadd fast float %1057, %1052
  %1061 = fadd fast float %1058, %1052
  %1062 = call float @dx.op.unary.f32(i32 7, float %1059)  ; Saturate(value)
  %1063 = call float @dx.op.unary.f32(i32 7, float %1060)  ; Saturate(value)
  %1064 = call float @dx.op.unary.f32(i32 7, float %1061)  ; Saturate(value)
  %1065 = fadd fast float %1062, 0xBFC70A3D80000000
  %1066 = fadd fast float %1063, 0xBFC70A3D80000000
  %1067 = fadd fast float %1064, 0xBFC70A3D80000000
  %1068 = fmul fast float %1065, %6
  %1069 = fmul fast float %1066, %6
  %1070 = fmul fast float %1067, %6
  %1071 = fadd fast float %1068, 0x3FC70A3D80000000
  %1072 = fadd fast float %1069, 0x3FC70A3D80000000
  %1073 = fadd fast float %1070, 0x3FC70A3D80000000
  %1074 = call float @dx.op.unary.f32(i32 7, float %1071)  ; Saturate(value)
  %1075 = call float @dx.op.unary.f32(i32 7, float %1072)  ; Saturate(value)
  %1076 = call float @dx.op.unary.f32(i32 7, float %1073)  ; Saturate(value)
  br label %1077

; <label>:1077                                    ; preds = %1045, %826
  %1078 = phi float [ %857, %826 ], [ %1074, %1045 ]
  %1079 = phi float [ %858, %826 ], [ %1075, %1045 ]
  %1080 = phi float [ %859, %826 ], [ %1076, %1045 ]
  %1081 = add i32 %44, 1
  %1082 = call i32 @dx.op.binary.i32(i32 37, i32 %1081, i32 0)  ; IMax(a,b)
  %1083 = call i32 @dx.op.binary.i32(i32 38, i32 %1082, i32 %274)  ; IMin(a,b)
  %1084 = call i32 @dx.op.binary.i32(i32 37, i32 %1083, i32 0)  ; IMax(a,b)
  %1085 = call i32 @dx.op.binary.i32(i32 38, i32 %1084, i32 %274)  ; IMin(a,b)
  %1086 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1085, i32 %819, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1087 = extractvalue %dx.types.ResRet.f32 %1086, 0
  %1088 = extractvalue %dx.types.ResRet.f32 %1086, 1
  %1089 = extractvalue %dx.types.ResRet.f32 %1086, 2
  %1090 = extractvalue %dx.types.ResRet.f32 %1086, 3
  %1091 = fcmp fast olt float %1090, 0.000000e+00
  br i1 %1091, label %1092, label %1126

; <label>:1092                                    ; preds = %1077
  %1093 = fcmp fast ogt float %1087, 0x3FA4B5DCC0000000
  %1094 = fcmp fast ogt float %1088, 0x3FA4B5DCC0000000
  %1095 = fcmp fast ogt float %1089, 0x3FA4B5DCC0000000
  %1096 = select i1 %1093, float 0.000000e+00, float 1.000000e+00
  %1097 = select i1 %1094, float 0.000000e+00, float 1.000000e+00
  %1098 = select i1 %1095, float 0.000000e+00, float 1.000000e+00
  %1099 = fmul fast float %1087, 0x3FB3D07220000000
  %1100 = fmul fast float %1088, 0x3FB3D07220000000
  %1101 = fmul fast float %1089, 0x3FB3D07220000000
  %1102 = fadd fast float %1087, 0x3FAC28F5C0000000
  %1103 = fadd fast float %1088, 0x3FAC28F5C0000000
  %1104 = fadd fast float %1089, 0x3FAC28F5C0000000
  %1105 = fmul fast float %1102, 0x3FEE54EDE0000000
  %1106 = fmul fast float %1103, 0x3FEE54EDE0000000
  %1107 = fmul fast float %1104, 0x3FEE54EDE0000000
  %1108 = call float @dx.op.unary.f32(i32 23, float %1105)  ; Log(value)
  %1109 = call float @dx.op.unary.f32(i32 23, float %1106)  ; Log(value)
  %1110 = call float @dx.op.unary.f32(i32 23, float %1107)  ; Log(value)
  %1111 = fmul fast float %1108, 0x4003333340000000
  %1112 = fmul fast float %1109, 0x4003333340000000
  %1113 = fmul fast float %1110, 0x4003333340000000
  %1114 = call float @dx.op.unary.f32(i32 21, float %1111)  ; Exp(value)
  %1115 = call float @dx.op.unary.f32(i32 21, float %1112)  ; Exp(value)
  %1116 = call float @dx.op.unary.f32(i32 21, float %1113)  ; Exp(value)
  %1117 = fsub fast float %1099, %1114
  %1118 = fsub fast float %1100, %1115
  %1119 = fsub fast float %1101, %1116
  %1120 = fmul fast float %1117, %1096
  %1121 = fmul fast float %1118, %1097
  %1122 = fmul fast float %1119, %1098
  %1123 = fadd fast float %1120, %1114
  %1124 = fadd fast float %1121, %1115
  %1125 = fadd fast float %1122, %1116
  br label %1343

; <label>:1126                                    ; preds = %1077
  %1127 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1085, i32 %819, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1128 = extractvalue %dx.types.ResRet.f32 %1127, 0
  %1129 = fcmp fast ogt float %37, 5.000000e-01
  %1130 = fcmp fast olt float %1128, 1.000000e+00
  %1131 = and i1 %1129, %1130
  br i1 %1131, label %1132, label %1272

; <label>:1132                                    ; preds = %1126
  %1133 = sitofp i32 %1085 to float
  %1134 = sitofp i32 %819 to float
  %1135 = fadd fast float %1133, 5.000000e-01
  %1136 = fadd fast float %1134, 5.000000e-01
  %1137 = uitofp i32 %42 to float
  %1138 = uitofp i32 %43 to float
  %1139 = fdiv fast float %1135, %1137
  %1140 = fdiv fast float %1136, %1138
  %1141 = fmul fast float %1139, 2.000000e+00
  %1142 = fmul fast float %1140, 2.000000e+00
  %1143 = fadd fast float %1141, -1.000000e+00
  %1144 = fsub fast float 1.000000e+00, %1142
  %1145 = fmul fast float %1143, %34
  %1146 = call float @dx.op.tertiary.f32(i32 46, float %1144, float %30, float %1145)  ; FMad(a,b,c)
  %1147 = call float @dx.op.tertiary.f32(i32 46, float %1128, float %26, float %1146)  ; FMad(a,b,c)
  %1148 = fadd fast float %1147, %22
  %1149 = call float @dx.op.unary.f32(i32 6, float %1148)  ; FAbs(value)
  %1150 = fcmp fast ogt float %1149, 0x3EB0C6F7A0000000
  br i1 %1150, label %1151, label %1272

; <label>:1151                                    ; preds = %1132
  %1152 = fmul fast float %1143, %33
  %1153 = call float @dx.op.tertiary.f32(i32 46, float %1144, float %29, float %1152)  ; FMad(a,b,c)
  %1154 = call float @dx.op.tertiary.f32(i32 46, float %1128, float %25, float %1153)  ; FMad(a,b,c)
  %1155 = fadd fast float %1154, %21
  %1156 = fmul fast float %1143, %32
  %1157 = call float @dx.op.tertiary.f32(i32 46, float %1144, float %28, float %1156)  ; FMad(a,b,c)
  %1158 = call float @dx.op.tertiary.f32(i32 46, float %1128, float %24, float %1157)  ; FMad(a,b,c)
  %1159 = fadd fast float %1158, %20
  %1160 = fmul fast float %1143, %31
  %1161 = call float @dx.op.tertiary.f32(i32 46, float %1144, float %27, float %1160)  ; FMad(a,b,c)
  %1162 = call float @dx.op.tertiary.f32(i32 46, float %1128, float %23, float %1161)  ; FMad(a,b,c)
  %1163 = fadd fast float %1162, %19
  %1164 = fdiv fast float %1163, %1148
  %1165 = fdiv fast float %1159, %1148
  %1166 = fdiv fast float %1155, %1148
  %1167 = fsub fast float %1164, %16
  %1168 = fsub fast float %1165, %17
  %1169 = fsub fast float %1166, %18
  %1170 = fmul fast float %1167, %1167
  %1171 = fmul fast float %1168, %1168
  %1172 = fadd fast float %1171, %1170
  %1173 = fmul fast float %1169, %1169
  %1174 = fadd fast float %1172, %1173
  %1175 = call float @dx.op.unary.f32(i32 24, float %1174)  ; Sqrt(value)
  %1176 = fsub fast float %1175, %8
  %1177 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1176)  ; FMax(a,b)
  %1178 = fcmp fast ogt float %38, 1.500000e+00
  br i1 %1178, label %1179, label %1202

; <label>:1179                                    ; preds = %1151
  %1180 = call float @dx.op.unary.f32(i32 6, float %1168)  ; FAbs(value)
  %1181 = fmul fast float %1180, %10
  %1182 = fcmp fast olt float %1181, 0x3F50624DE0000000
  br i1 %1182, label %1183, label %1186

; <label>:1183                                    ; preds = %1179
  %1184 = fmul fast float %1181, 5.000000e-01
  %1185 = fsub fast float 1.000000e+00, %1184
  br label %1191

; <label>:1186                                    ; preds = %1179
  %1187 = fmul fast float %1181, 0xBFF7154760000000
  %1188 = call float @dx.op.unary.f32(i32 21, float %1187)  ; Exp(value)
  %1189 = fsub fast float 1.000000e+00, %1188
  %1190 = fdiv fast float %1189, %1181
  br label %1191

; <label>:1191                                    ; preds = %1186, %1183
  %1192 = phi float [ %1185, %1183 ], [ %1190, %1186 ]
  %1193 = call float @dx.op.binary.f32(i32 36, float %1165, float %17)  ; FMin(a,b)
  %1194 = fsub fast float %1193, %9
  %1195 = fmul fast float %10, %1194
  %1196 = fsub fast float -0.000000e+00, %1195
  %1197 = call float @dx.op.binary.f32(i32 35, float %1196, float -4.000000e+01)  ; FMax(a,b)
  %1198 = call float @dx.op.binary.f32(i32 36, float %1197, float 5.000000e+00)  ; FMin(a,b)
  %1199 = fmul fast float %1198, 0x3FF7154760000000
  %1200 = call float @dx.op.unary.f32(i32 21, float %1199)  ; Exp(value)
  %1201 = fmul fast float %1200, %1192
  br label %1202

; <label>:1202                                    ; preds = %1191, %1151
  %1203 = phi float [ %1201, %1191 ], [ 1.000000e+00, %1151 ]
  %1204 = fmul fast float %1177, %15
  %1205 = fmul fast float %1204, %1203
  %1206 = fcmp fast ole float %1175, %8
  %1207 = fcmp fast olt float %1175, 0x3F1A36E2E0000000
  %1208 = or i1 %1206, %1207
  br i1 %1208, label %1255, label %1209

; <label>:1209                                    ; preds = %1202
  %1210 = fdiv fast float %8, %1175
  %1211 = fmul fast float %1210, %1167
  %1212 = fmul fast float %1210, %1168
  %1213 = fmul fast float %1210, %1169
  %1214 = fadd fast float %1211, %16
  %1215 = fadd fast float %1212, %17
  %1216 = fadd fast float %1213, %18
  %1217 = fadd fast float %1214, -9.000000e+02
  %1218 = fadd fast float %1215, -1.500000e+01
  %1219 = fadd fast float %1216, -7.500000e+02
  %1220 = fmul fast float %1217, 0x3F62345680000000
  %1221 = fmul fast float %1218, 0x3F62345680000000
  %1222 = fmul fast float %1219, 0x3F62345680000000
  %1223 = call float @dx.op.dot3.f32(i32 55, float %1220, float %1221, float %1222, float %1220, float %1221, float %1222)  ; Dot3(ax,ay,az,bx,by,bz)
  %1224 = fsub fast float 1.000000e+00, %1223
  %1225 = call float @dx.op.unary.f32(i32 7, float %1224)  ; Saturate(value)
  %1226 = fmul fast float %1225, %1225
  %1227 = fadd fast float %1214, %1164
  %1228 = fadd fast float %1215, %1165
  %1229 = fadd fast float %1216, %1166
  %1230 = fmul fast float %1227, 0x3F52345680000000
  %1231 = fadd fast float %1230, -2.000000e+00
  %1232 = fmul fast float %1228, 0x3F52345680000000
  %1233 = fadd fast float %1232, 0xBFA1111120000000
  %1234 = fmul fast float %1229, 0x3F52345680000000
  %1235 = fadd fast float %1234, 0xBFFAAAAAC0000000
  %1236 = call float @dx.op.dot3.f32(i32 55, float %1231, float %1233, float %1235, float %1231, float %1233, float %1235)  ; Dot3(ax,ay,az,bx,by,bz)
  %1237 = fsub fast float 1.000000e+00, %1236
  %1238 = call float @dx.op.unary.f32(i32 7, float %1237)  ; Saturate(value)
  %1239 = fmul fast float %1238, %1238
  %1240 = fmul fast float %1239, 4.000000e+00
  %1241 = fadd fast float %1240, %1226
  %1242 = fadd fast float %1164, -9.000000e+02
  %1243 = fadd fast float %1165, -1.500000e+01
  %1244 = fadd fast float %1166, -7.500000e+02
  %1245 = fmul fast float %1242, 0x3F62345680000000
  %1246 = fmul fast float %1243, 0x3F62345680000000
  %1247 = fmul fast float %1244, 0x3F62345680000000
  %1248 = call float @dx.op.dot3.f32(i32 55, float %1245, float %1246, float %1247, float %1245, float %1246, float %1247)  ; Dot3(ax,ay,az,bx,by,bz)
  %1249 = fsub fast float 1.000000e+00, %1248
  %1250 = call float @dx.op.unary.f32(i32 7, float %1249)  ; Saturate(value)
  %1251 = fmul fast float %1250, %1250
  %1252 = fadd fast float %1241, %1251
  %1253 = fmul fast float %1176, 0x3F25D867E0000000
  %1254 = fmul fast float %1253, %1252
  br label %1255

; <label>:1255                                    ; preds = %1209, %1202
  %1256 = phi float [ %1254, %1209 ], [ 0.000000e+00, %1202 ]
  %1257 = fadd fast float %1256, %1205
  %1258 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1257)  ; FMin(a,b)
  %1259 = fmul fast float %1258, 0xBFF7154760000000
  %1260 = call float @dx.op.unary.f32(i32 21, float %1259)  ; Exp(value)
  %1261 = fsub fast float 1.000000e+00, %1260
  %1262 = call float @dx.op.binary.f32(i32 36, float %11, float %1261)  ; FMin(a,b)
  %1263 = fsub fast float %12, %1087
  %1264 = fsub fast float %13, %1088
  %1265 = fsub fast float %14, %1089
  %1266 = fmul fast float %1262, %1263
  %1267 = fmul fast float %1262, %1264
  %1268 = fmul fast float %1262, %1265
  %1269 = fadd fast float %1266, %1087
  %1270 = fadd fast float %1267, %1088
  %1271 = fadd fast float %1268, %1089
  br label %1272

; <label>:1272                                    ; preds = %1255, %1132, %1126
  %1273 = phi float [ %1269, %1255 ], [ %1087, %1132 ], [ %1087, %1126 ]
  %1274 = phi float [ %1270, %1255 ], [ %1088, %1132 ], [ %1088, %1126 ]
  %1275 = phi float [ %1271, %1255 ], [ %1089, %1132 ], [ %1089, %1126 ]
  %1276 = fadd fast float %4, 1.000000e+00
  %1277 = fadd fast float %5, 1.000000e+00
  %1278 = fsub fast float 1.000000e+00, %4
  %1279 = fmul fast float %35, %1276
  %1280 = fmul fast float %35, %1277
  %1281 = fmul fast float %35, %1278
  %1282 = fmul fast float %1279, %1273
  %1283 = fmul fast float %1280, %1274
  %1284 = fmul fast float %1281, %1275
  %1285 = fcmp fast ult float %36, 5.000000e-01
  br i1 %1285, label %1311, label %1286

; <label>:1286                                    ; preds = %1272
  %1287 = fmul fast float %1282, 0x4004147AE0000000
  %1288 = fmul fast float %1283, 0x4004147AE0000000
  %1289 = fmul fast float %1284, 0x4004147AE0000000
  %1290 = fadd fast float %1287, 0x3F9EB851E0000000
  %1291 = fadd fast float %1288, 0x3F9EB851E0000000
  %1292 = fadd fast float %1289, 0x3F9EB851E0000000
  %1293 = fmul fast float %1290, %1282
  %1294 = fmul fast float %1291, %1283
  %1295 = fmul fast float %1292, %1284
  %1296 = fmul fast float %1282, 0x400370A3E0000000
  %1297 = fmul fast float %1283, 0x400370A3E0000000
  %1298 = fmul fast float %1284, 0x400370A3E0000000
  %1299 = fadd fast float %1296, 0x3FE2E147A0000000
  %1300 = fadd fast float %1297, 0x3FE2E147A0000000
  %1301 = fadd fast float %1298, 0x3FE2E147A0000000
  %1302 = fmul fast float %1299, %1282
  %1303 = fmul fast float %1300, %1283
  %1304 = fmul fast float %1301, %1284
  %1305 = fadd fast float %1302, 0x3FC1EB8520000000
  %1306 = fadd fast float %1303, 0x3FC1EB8520000000
  %1307 = fadd fast float %1304, 0x3FC1EB8520000000
  %1308 = fdiv fast float %1293, %1305
  %1309 = fdiv fast float %1294, %1306
  %1310 = fdiv fast float %1295, %1307
  br label %1311

; <label>:1311                                    ; preds = %1286, %1272
  %1312 = phi float [ %1308, %1286 ], [ %1282, %1272 ]
  %1313 = phi float [ %1309, %1286 ], [ %1283, %1272 ]
  %1314 = phi float [ %1310, %1286 ], [ %1284, %1272 ]
  %1315 = call float @dx.op.unary.f32(i32 7, float %1312)  ; Saturate(value)
  %1316 = call float @dx.op.unary.f32(i32 7, float %1313)  ; Saturate(value)
  %1317 = call float @dx.op.unary.f32(i32 7, float %1314)  ; Saturate(value)
  %1318 = call float @dx.op.dot3.f32(i32 55, float %1315, float %1316, float %1317, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1319 = fsub fast float %1315, %1318
  %1320 = fsub fast float %1316, %1318
  %1321 = fsub fast float %1317, %1318
  %1322 = fmul fast float %1319, %7
  %1323 = fmul fast float %1320, %7
  %1324 = fmul fast float %1321, %7
  %1325 = fadd fast float %1322, %1318
  %1326 = fadd fast float %1323, %1318
  %1327 = fadd fast float %1324, %1318
  %1328 = call float @dx.op.unary.f32(i32 7, float %1325)  ; Saturate(value)
  %1329 = call float @dx.op.unary.f32(i32 7, float %1326)  ; Saturate(value)
  %1330 = call float @dx.op.unary.f32(i32 7, float %1327)  ; Saturate(value)
  %1331 = fadd fast float %1328, 0xBFC70A3D80000000
  %1332 = fadd fast float %1329, 0xBFC70A3D80000000
  %1333 = fadd fast float %1330, 0xBFC70A3D80000000
  %1334 = fmul fast float %1331, %6
  %1335 = fmul fast float %1332, %6
  %1336 = fmul fast float %1333, %6
  %1337 = fadd fast float %1334, 0x3FC70A3D80000000
  %1338 = fadd fast float %1335, 0x3FC70A3D80000000
  %1339 = fadd fast float %1336, 0x3FC70A3D80000000
  %1340 = call float @dx.op.unary.f32(i32 7, float %1337)  ; Saturate(value)
  %1341 = call float @dx.op.unary.f32(i32 7, float %1338)  ; Saturate(value)
  %1342 = call float @dx.op.unary.f32(i32 7, float %1339)  ; Saturate(value)
  br label %1343

; <label>:1343                                    ; preds = %1311, %1092
  %1344 = phi float [ %1123, %1092 ], [ %1340, %1311 ]
  %1345 = phi float [ %1124, %1092 ], [ %1341, %1311 ]
  %1346 = phi float [ %1125, %1092 ], [ %1342, %1311 ]
  %1347 = call float @dx.op.binary.f32(i32 36, float %1078, float %1344)  ; FMin(a,b)
  %1348 = call float @dx.op.binary.f32(i32 36, float %1079, float %1345)  ; FMin(a,b)
  %1349 = call float @dx.op.binary.f32(i32 36, float %1080, float %1346)  ; FMin(a,b)
  %1350 = call float @dx.op.binary.f32(i32 36, float %542, float %808)  ; FMin(a,b)
  %1351 = call float @dx.op.binary.f32(i32 36, float %543, float %809)  ; FMin(a,b)
  %1352 = call float @dx.op.binary.f32(i32 36, float %544, float %810)  ; FMin(a,b)
  %1353 = call float @dx.op.binary.f32(i32 36, float %1350, float %1347)  ; FMin(a,b)
  %1354 = call float @dx.op.binary.f32(i32 36, float %1351, float %1348)  ; FMin(a,b)
  %1355 = call float @dx.op.binary.f32(i32 36, float %1352, float %1349)  ; FMin(a,b)
  %1356 = call float @dx.op.binary.f32(i32 36, float %268, float %1353)  ; FMin(a,b)
  %1357 = call float @dx.op.binary.f32(i32 36, float %269, float %1354)  ; FMin(a,b)
  %1358 = call float @dx.op.binary.f32(i32 36, float %270, float %1355)  ; FMin(a,b)
  %1359 = call float @dx.op.binary.f32(i32 35, float %1078, float %1344)  ; FMax(a,b)
  %1360 = call float @dx.op.binary.f32(i32 35, float %1079, float %1345)  ; FMax(a,b)
  %1361 = call float @dx.op.binary.f32(i32 35, float %1080, float %1346)  ; FMax(a,b)
  %1362 = call float @dx.op.binary.f32(i32 35, float %542, float %808)  ; FMax(a,b)
  %1363 = call float @dx.op.binary.f32(i32 35, float %543, float %809)  ; FMax(a,b)
  %1364 = call float @dx.op.binary.f32(i32 35, float %544, float %810)  ; FMax(a,b)
  %1365 = call float @dx.op.binary.f32(i32 35, float %1362, float %1359)  ; FMax(a,b)
  %1366 = call float @dx.op.binary.f32(i32 35, float %1363, float %1360)  ; FMax(a,b)
  %1367 = call float @dx.op.binary.f32(i32 35, float %1364, float %1361)  ; FMax(a,b)
  %1368 = call float @dx.op.binary.f32(i32 35, float %268, float %1365)  ; FMax(a,b)
  %1369 = call float @dx.op.binary.f32(i32 35, float %269, float %1366)  ; FMax(a,b)
  %1370 = call float @dx.op.binary.f32(i32 35, float %270, float %1367)  ; FMax(a,b)
  %1371 = fsub fast float %1368, %1356
  %1372 = fsub fast float %1369, %1357
  %1373 = fsub fast float %1370, %1358
  %1374 = call float @dx.op.unary.f32(i32 6, float %1371)  ; FAbs(value)
  %1375 = call float @dx.op.unary.f32(i32 6, float %1372)  ; FAbs(value)
  %1376 = call float @dx.op.unary.f32(i32 6, float %1373)  ; FAbs(value)
  %1377 = call float @dx.op.binary.f32(i32 35, float %1375, float %1376)  ; FMax(a,b)
  %1378 = call float @dx.op.binary.f32(i32 35, float %1374, float %1377)  ; FMax(a,b)
  %1379 = call float @dx.op.binary.f32(i32 35, float %1369, float %1370)  ; FMax(a,b)
  %1380 = call float @dx.op.binary.f32(i32 35, float %1368, float %1379)  ; FMax(a,b)
  %1381 = fmul fast float %1380, 1.250000e-01
  %1382 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1381)  ; FMax(a,b)
  %1383 = fcmp fast ogt float %1378, %1382
  br i1 %1383, label %1384, label %1446

; <label>:1384                                    ; preds = %1343
  %1385 = fsub fast float %542, %808
  %1386 = fsub fast float %543, %809
  %1387 = fsub fast float %544, %810
  %1388 = call float @dx.op.unary.f32(i32 6, float %1385)  ; FAbs(value)
  %1389 = call float @dx.op.unary.f32(i32 6, float %1386)  ; FAbs(value)
  %1390 = call float @dx.op.unary.f32(i32 6, float %1387)  ; FAbs(value)
  %1391 = call float @dx.op.binary.f32(i32 35, float %1389, float %1390)  ; FMax(a,b)
  %1392 = call float @dx.op.binary.f32(i32 35, float %1388, float %1391)  ; FMax(a,b)
  %1393 = fsub fast float %1078, %1344
  %1394 = fsub fast float %1079, %1345
  %1395 = fsub fast float %1080, %1346
  %1396 = call float @dx.op.unary.f32(i32 6, float %1393)  ; FAbs(value)
  %1397 = call float @dx.op.unary.f32(i32 6, float %1394)  ; FAbs(value)
  %1398 = call float @dx.op.unary.f32(i32 6, float %1395)  ; FAbs(value)
  %1399 = call float @dx.op.binary.f32(i32 35, float %1397, float %1398)  ; FMax(a,b)
  %1400 = call float @dx.op.binary.f32(i32 35, float %1396, float %1399)  ; FMax(a,b)
  %1401 = fcmp fast olt float %1392, %1400
  %1402 = select i1 %1401, float %542, float %1078
  %1403 = select i1 %1401, float %543, float %1079
  %1404 = select i1 %1401, float %544, float %1080
  %1405 = select i1 %1401, float %808, float %1344
  %1406 = select i1 %1401, float %809, float %1345
  %1407 = select i1 %1401, float %810, float %1346
  %1408 = fsub fast float %268, %1405
  %1409 = fsub fast float %269, %1406
  %1410 = fsub fast float %270, %1407
  %1411 = fsub fast float %268, %1402
  %1412 = fsub fast float %269, %1403
  %1413 = fsub fast float %270, %1404
  %1414 = call float @dx.op.dot3.f32(i32 55, float %1411, float %1412, float %1413, float %1408, float %1409, float %1410)  ; Dot3(ax,ay,az,bx,by,bz)
  %1415 = fcmp fast ogt float %1414, 0.000000e+00
  br i1 %1415, label %1416, label %1428

; <label>:1416                                    ; preds = %1384
  %1417 = fsub fast float %1402, %1405
  %1418 = fsub fast float %1403, %1406
  %1419 = fsub fast float %1404, %1407
  %1420 = call float @dx.op.unary.f32(i32 6, float %1417)  ; FAbs(value)
  %1421 = call float @dx.op.unary.f32(i32 6, float %1418)  ; FAbs(value)
  %1422 = call float @dx.op.unary.f32(i32 6, float %1419)  ; FAbs(value)
  %1423 = call float @dx.op.binary.f32(i32 35, float %1421, float %1422)  ; FMax(a,b)
  %1424 = call float @dx.op.binary.f32(i32 35, float %1420, float %1423)  ; FMax(a,b)
  %1425 = fmul fast float %1378, 2.500000e-01
  %1426 = fcmp fast olt float %1424, %1425
  %1427 = select i1 %1426, float 5.000000e-01, float 1.000000e+00
  br label %1428

; <label>:1428                                    ; preds = %1416, %1384
  %1429 = phi float [ 1.000000e+00, %1384 ], [ %1427, %1416 ]
  %1430 = fmul fast float %1429, %3
  %1431 = fadd fast float %1402, %1405
  %1432 = fadd fast float %1403, %1406
  %1433 = fadd fast float %1404, %1407
  %1434 = fmul fast float %1431, 5.000000e-01
  %1435 = fmul fast float %1432, 5.000000e-01
  %1436 = fmul fast float %1433, 5.000000e-01
  %1437 = fsub fast float %1434, %268
  %1438 = fsub fast float %1435, %269
  %1439 = fsub fast float %1436, %270
  %1440 = fmul fast float %1430, %1437
  %1441 = fmul fast float %1430, %1438
  %1442 = fmul fast float %1430, %1439
  %1443 = fadd fast float %1440, %268
  %1444 = fadd fast float %1441, %269
  %1445 = fadd fast float %1442, %270
  br label %1446

; <label>:1446                                    ; preds = %1428, %1343, %239
  %1447 = phi float [ %268, %239 ], [ %1443, %1428 ], [ %268, %1343 ]
  %1448 = phi float [ %269, %239 ], [ %1444, %1428 ], [ %269, %1343 ]
  %1449 = phi float [ %270, %239 ], [ %1445, %1428 ], [ %270, %1343 ]
  %1450 = fcmp fast ogt float %1447, 0x3F69A5C380000000
  %1451 = fcmp fast ogt float %1448, 0x3F69A5C380000000
  %1452 = fcmp fast ogt float %1449, 0x3F69A5C380000000
  %1453 = select i1 %1450, float 0.000000e+00, float 1.000000e+00
  %1454 = select i1 %1451, float 0.000000e+00, float 1.000000e+00
  %1455 = select i1 %1452, float 0.000000e+00, float 1.000000e+00
  %1456 = fmul fast float %1447, 0x4029D70A40000000
  %1457 = fmul fast float %1448, 0x4029D70A40000000
  %1458 = fmul fast float %1449, 0x4029D70A40000000
  %1459 = call float @dx.op.binary.f32(i32 35, float %1447, float 0.000000e+00)  ; FMax(a,b)
  %1460 = call float @dx.op.binary.f32(i32 35, float %1448, float 0.000000e+00)  ; FMax(a,b)
  %1461 = call float @dx.op.binary.f32(i32 35, float %1449, float 0.000000e+00)  ; FMax(a,b)
  %1462 = call float @dx.op.unary.f32(i32 23, float %1459)  ; Log(value)
  %1463 = call float @dx.op.unary.f32(i32 23, float %1460)  ; Log(value)
  %1464 = call float @dx.op.unary.f32(i32 23, float %1461)  ; Log(value)
  %1465 = fmul fast float %1462, 0x3FDAAAAAA0000000
  %1466 = fmul fast float %1463, 0x3FDAAAAAA0000000
  %1467 = fmul fast float %1464, 0x3FDAAAAAA0000000
  %1468 = call float @dx.op.unary.f32(i32 21, float %1465)  ; Exp(value)
  %1469 = call float @dx.op.unary.f32(i32 21, float %1466)  ; Exp(value)
  %1470 = call float @dx.op.unary.f32(i32 21, float %1467)  ; Exp(value)
  %1471 = fmul fast float %1468, 0x3FF0E147A0000000
  %1472 = fmul fast float %1469, 0x3FF0E147A0000000
  %1473 = fmul fast float %1470, 0x3FF0E147A0000000
  %1474 = fadd fast float %1471, 0xBFAC28F5C0000000
  %1475 = fadd fast float %1472, 0xBFAC28F5C0000000
  %1476 = fadd fast float %1473, 0xBFAC28F5C0000000
  %1477 = fsub fast float %1456, %1474
  %1478 = fsub fast float %1457, %1475
  %1479 = fsub fast float %1458, %1476
  %1480 = fmul fast float %1477, %1453
  %1481 = fmul fast float %1478, %1454
  %1482 = fmul fast float %1479, %1455
  %1483 = fadd fast float %1480, %1474
  %1484 = fadd fast float %1481, %1475
  %1485 = fadd fast float %1482, %1476
  br label %1486

; <label>:1486                                    ; preds = %1446, %52
  %1487 = phi float [ %47, %52 ], [ %1483, %1446 ]
  %1488 = phi float [ %48, %52 ], [ %1484, %1446 ]
  %1489 = phi float [ %49, %52 ], [ %1485, %1446 ]
  %1490 = phi float [ %53, %52 ], [ %50, %1446 ]
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %1487)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %1488)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %1489)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %1490)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 0, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !38, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, !37}
!36 = !{i32 9}
!37 = !{i32 3, i32 1}
!38 = !{!39}
!39 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
