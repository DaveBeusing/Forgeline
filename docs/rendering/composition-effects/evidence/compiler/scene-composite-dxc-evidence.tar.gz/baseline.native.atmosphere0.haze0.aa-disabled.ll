;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xy  
; TEXCOORD                 1   xyzw        2     NONE   float       
; TEXCOORD                 2   xyzw        3     NONE   float       
; TEXCOORD                 3   xyzw        4     NONE   float       
; TEXCOORD                 4   xyzw        5     NONE   float       
; TEXCOORD                 5   xyzw        6     NONE   float       
; TEXCOORD                 6   xyzw        7     NONE   float       
; TEXCOORD                 7   xyzw        8     NONE   float       
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float       
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
;
; shader hash: 652e11d8c06d5de80a3fdd91a07de820
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=0
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 1
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39 }
;   output 3 depends on inputs: { 0, 1 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = fptosi float %6 to i32
  %9 = fptosi float %7 to i32
  %10 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %8, i32 %9, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %11 = extractvalue %dx.types.ResRet.f32 %10, 0
  %12 = extractvalue %dx.types.ResRet.f32 %10, 1
  %13 = extractvalue %dx.types.ResRet.f32 %10, 2
  %14 = extractvalue %dx.types.ResRet.f32 %10, 3
  %15 = fcmp fast olt float %14, 0.000000e+00
  br i1 %15, label %16, label %18

; <label>:16                                      ; preds = %0
  %17 = fsub fast float -1.000000e+00, %14
  br label %124

; <label>:18                                      ; preds = %0
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = fadd fast float %2, 1.000000e+00
  %22 = fadd fast float %20, 1.000000e+00
  %23 = fsub fast float 1.000000e+00, %2
  %24 = fmul fast float %5, %21
  %25 = fmul fast float %5, %22
  %26 = fmul fast float %5, %23
  %27 = fmul fast float %24, %11
  %28 = fmul fast float %25, %12
  %29 = fmul fast float %26, %13
  %30 = fcmp fast ult float %19, 5.000000e-01
  br i1 %30, label %56, label %31

; <label>:31                                      ; preds = %18
  %32 = fmul fast float %27, 0x4004147AE0000000
  %33 = fmul fast float %28, 0x4004147AE0000000
  %34 = fmul fast float %29, 0x4004147AE0000000
  %35 = fadd fast float %32, 0x3F9EB851E0000000
  %36 = fadd fast float %33, 0x3F9EB851E0000000
  %37 = fadd fast float %34, 0x3F9EB851E0000000
  %38 = fmul fast float %35, %27
  %39 = fmul fast float %36, %28
  %40 = fmul fast float %37, %29
  %41 = fmul fast float %27, 0x400370A3E0000000
  %42 = fmul fast float %28, 0x400370A3E0000000
  %43 = fmul fast float %29, 0x400370A3E0000000
  %44 = fadd fast float %41, 0x3FE2E147A0000000
  %45 = fadd fast float %42, 0x3FE2E147A0000000
  %46 = fadd fast float %43, 0x3FE2E147A0000000
  %47 = fmul fast float %44, %27
  %48 = fmul fast float %45, %28
  %49 = fmul fast float %46, %29
  %50 = fadd fast float %47, 0x3FC1EB8520000000
  %51 = fadd fast float %48, 0x3FC1EB8520000000
  %52 = fadd fast float %49, 0x3FC1EB8520000000
  %53 = fdiv fast float %38, %50
  %54 = fdiv fast float %39, %51
  %55 = fdiv fast float %40, %52
  br label %56

; <label>:56                                      ; preds = %31, %18
  %57 = phi float [ %53, %31 ], [ %27, %18 ]
  %58 = phi float [ %54, %31 ], [ %28, %18 ]
  %59 = phi float [ %55, %31 ], [ %29, %18 ]
  %60 = call float @dx.op.unary.f32(i32 7, float %57)  ; Saturate(value)
  %61 = call float @dx.op.unary.f32(i32 7, float %58)  ; Saturate(value)
  %62 = call float @dx.op.unary.f32(i32 7, float %59)  ; Saturate(value)
  %63 = call float @dx.op.dot3.f32(i32 55, float %60, float %61, float %62, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %64 = fsub fast float %60, %63
  %65 = fsub fast float %61, %63
  %66 = fsub fast float %62, %63
  %67 = fmul fast float %64, %4
  %68 = fmul fast float %65, %4
  %69 = fmul fast float %66, %4
  %70 = fadd fast float %67, %63
  %71 = fadd fast float %68, %63
  %72 = fadd fast float %69, %63
  %73 = call float @dx.op.unary.f32(i32 7, float %70)  ; Saturate(value)
  %74 = call float @dx.op.unary.f32(i32 7, float %71)  ; Saturate(value)
  %75 = call float @dx.op.unary.f32(i32 7, float %72)  ; Saturate(value)
  %76 = fadd fast float %73, 0xBFC70A3D80000000
  %77 = fadd fast float %74, 0xBFC70A3D80000000
  %78 = fadd fast float %75, 0xBFC70A3D80000000
  %79 = fmul fast float %76, %3
  %80 = fmul fast float %77, %3
  %81 = fmul fast float %78, %3
  %82 = fadd fast float %79, 0x3FC70A3D80000000
  %83 = fadd fast float %80, 0x3FC70A3D80000000
  %84 = fadd fast float %81, 0x3FC70A3D80000000
  %85 = call float @dx.op.unary.f32(i32 7, float %82)  ; Saturate(value)
  %86 = call float @dx.op.unary.f32(i32 7, float %83)  ; Saturate(value)
  %87 = call float @dx.op.unary.f32(i32 7, float %84)  ; Saturate(value)
  %88 = fcmp fast ogt float %85, 0x3F69A5C380000000
  %89 = fcmp fast ogt float %86, 0x3F69A5C380000000
  %90 = fcmp fast ogt float %87, 0x3F69A5C380000000
  %91 = select i1 %88, float 0.000000e+00, float 1.000000e+00
  %92 = select i1 %89, float 0.000000e+00, float 1.000000e+00
  %93 = select i1 %90, float 0.000000e+00, float 1.000000e+00
  %94 = fmul fast float %85, 0x4029D70A40000000
  %95 = fmul fast float %86, 0x4029D70A40000000
  %96 = fmul fast float %87, 0x4029D70A40000000
  %97 = call float @dx.op.binary.f32(i32 35, float %85, float 0.000000e+00)  ; FMax(a,b)
  %98 = call float @dx.op.binary.f32(i32 35, float %86, float 0.000000e+00)  ; FMax(a,b)
  %99 = call float @dx.op.binary.f32(i32 35, float %87, float 0.000000e+00)  ; FMax(a,b)
  %100 = call float @dx.op.unary.f32(i32 23, float %97)  ; Log(value)
  %101 = call float @dx.op.unary.f32(i32 23, float %98)  ; Log(value)
  %102 = call float @dx.op.unary.f32(i32 23, float %99)  ; Log(value)
  %103 = fmul fast float %100, 0x3FDAAAAAA0000000
  %104 = fmul fast float %101, 0x3FDAAAAAA0000000
  %105 = fmul fast float %102, 0x3FDAAAAAA0000000
  %106 = call float @dx.op.unary.f32(i32 21, float %103)  ; Exp(value)
  %107 = call float @dx.op.unary.f32(i32 21, float %104)  ; Exp(value)
  %108 = call float @dx.op.unary.f32(i32 21, float %105)  ; Exp(value)
  %109 = fmul fast float %106, 0x3FF0E147A0000000
  %110 = fmul fast float %107, 0x3FF0E147A0000000
  %111 = fmul fast float %108, 0x3FF0E147A0000000
  %112 = fadd fast float %109, 0xBFAC28F5C0000000
  %113 = fadd fast float %110, 0xBFAC28F5C0000000
  %114 = fadd fast float %111, 0xBFAC28F5C0000000
  %115 = fsub fast float %94, %112
  %116 = fsub fast float %95, %113
  %117 = fsub fast float %96, %114
  %118 = fmul fast float %115, %91
  %119 = fmul fast float %116, %92
  %120 = fmul fast float %117, %93
  %121 = fadd fast float %118, %112
  %122 = fadd fast float %119, %113
  %123 = fadd fast float %120, %114
  br label %124

; <label>:124                                     ; preds = %56, %16
  %125 = phi float [ %11, %16 ], [ %121, %56 ]
  %126 = phi float [ %12, %16 ], [ %122, %56 ]
  %127 = phi float [ %13, %16 ], [ %123, %56 ]
  %128 = phi float [ %17, %16 ], [ %14, %56 ]
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %125)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %126)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %127)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %128)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!8}
!dx.entryPoints = !{!9}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 0, i32 0, i32 0, i32 0]}
!9 = !{void ()* @PSMain, !"PSMain", !10, !4, null}
!10 = !{!11, !35, null}
!11 = !{!12, !15, !16, !18, !20, !22, !24, !26, !28, !30, !33}
!12 = !{i32 0, !"SV_Position", i8 9, i8 3, !13, i8 4, i32 1, i8 4, i32 0, i8 0, !14}
!13 = !{i32 0}
!14 = !{i32 3, i32 3}
!15 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !13, i8 1, i32 1, i8 4, i32 1, i8 0, !14}
!16 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !17, i8 1, i32 1, i8 4, i32 2, i8 0, null}
!17 = !{i32 1}
!18 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 3, i8 0, null}
!19 = !{i32 2}
!20 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 4, i8 0, null}
!21 = !{i32 3}
!22 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 5, i8 0, null}
!23 = !{i32 4}
!24 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 6, i8 0, null}
!25 = !{i32 5}
!26 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 7, i8 0, null}
!27 = !{i32 6}
!28 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !29, i8 1, i32 1, i8 4, i32 8, i8 0, null}
!29 = !{i32 7}
!30 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !31, i8 1, i32 1, i8 4, i32 9, i8 0, !32}
!31 = !{i32 8}
!32 = !{i32 3, i32 15}
!33 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 10, i8 0, null}
!34 = !{i32 9}
!35 = !{!36}
!36 = !{i32 0, !"SV_Target", i8 9, i8 16, !13, i8 0, i32 1, i8 4, i32 0, i8 0, !32}
