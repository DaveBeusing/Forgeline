;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float   x   
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
;
; shader hash: b0a054e55f890114cd0cba40b804abc8
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=0
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 1
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40 }
;   output 3 depends on inputs: { 0, 1 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %40 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %41 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %42 = extractvalue %dx.types.Dimensions %41, 0
  %43 = extractvalue %dx.types.Dimensions %41, 1
  %44 = fptosi float %39 to i32
  %45 = fptosi float %40 to i32
  %46 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %44, i32 %45, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %47 = extractvalue %dx.types.ResRet.f32 %46, 0
  %48 = extractvalue %dx.types.ResRet.f32 %46, 1
  %49 = extractvalue %dx.types.ResRet.f32 %46, 2
  %50 = extractvalue %dx.types.ResRet.f32 %46, 3
  %51 = fcmp fast olt float %50, 0.000000e+00
  br i1 %51, label %52, label %54

; <label>:52                                      ; preds = %0
  %53 = fsub fast float -1.000000e+00, %50
  br label %1214

; <label>:54                                      ; preds = %0
  %55 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %44, i32 %45, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %56 = extractvalue %dx.types.ResRet.f32 %55, 0
  %57 = fcmp fast ogt float %37, 5.000000e-01
  %58 = fcmp fast olt float %56, 1.000000e+00
  %59 = and i1 %57, %58
  br i1 %59, label %60, label %148

; <label>:60                                      ; preds = %54
  %61 = sitofp i32 %44 to float
  %62 = sitofp i32 %45 to float
  %63 = fadd fast float %61, 5.000000e-01
  %64 = fadd fast float %62, 5.000000e-01
  %65 = uitofp i32 %42 to float
  %66 = uitofp i32 %43 to float
  %67 = fdiv fast float %63, %65
  %68 = fdiv fast float %64, %66
  %69 = fmul fast float %67, 2.000000e+00
  %70 = fmul fast float %68, 2.000000e+00
  %71 = fadd fast float %69, -1.000000e+00
  %72 = fsub fast float 1.000000e+00, %70
  %73 = fmul fast float %71, %34
  %74 = call float @dx.op.tertiary.f32(i32 46, float %72, float %30, float %73)  ; FMad(a,b,c)
  %75 = call float @dx.op.tertiary.f32(i32 46, float %56, float %26, float %74)  ; FMad(a,b,c)
  %76 = fadd fast float %75, %22
  %77 = call float @dx.op.unary.f32(i32 6, float %76)  ; FAbs(value)
  %78 = fcmp fast ogt float %77, 0x3EB0C6F7A0000000
  br i1 %78, label %79, label %148

; <label>:79                                      ; preds = %60
  %80 = fmul fast float %71, %33
  %81 = call float @dx.op.tertiary.f32(i32 46, float %72, float %29, float %80)  ; FMad(a,b,c)
  %82 = call float @dx.op.tertiary.f32(i32 46, float %56, float %25, float %81)  ; FMad(a,b,c)
  %83 = fadd fast float %82, %21
  %84 = fmul fast float %71, %32
  %85 = call float @dx.op.tertiary.f32(i32 46, float %72, float %28, float %84)  ; FMad(a,b,c)
  %86 = call float @dx.op.tertiary.f32(i32 46, float %56, float %24, float %85)  ; FMad(a,b,c)
  %87 = fadd fast float %86, %20
  %88 = fmul fast float %71, %31
  %89 = call float @dx.op.tertiary.f32(i32 46, float %72, float %27, float %88)  ; FMad(a,b,c)
  %90 = call float @dx.op.tertiary.f32(i32 46, float %56, float %23, float %89)  ; FMad(a,b,c)
  %91 = fadd fast float %90, %19
  %92 = fdiv fast float %91, %76
  %93 = fdiv fast float %87, %76
  %94 = fdiv fast float %83, %76
  %95 = fsub fast float %92, %16
  %96 = fsub fast float %93, %17
  %97 = fsub fast float %94, %18
  %98 = fmul fast float %95, %95
  %99 = fmul fast float %96, %96
  %100 = fadd fast float %99, %98
  %101 = fmul fast float %97, %97
  %102 = fadd fast float %100, %101
  %103 = call float @dx.op.unary.f32(i32 24, float %102)  ; Sqrt(value)
  %104 = fsub fast float %103, %8
  %105 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %104)  ; FMax(a,b)
  %106 = fcmp fast ogt float %38, 1.500000e+00
  br i1 %106, label %107, label %130

; <label>:107                                     ; preds = %79
  %108 = call float @dx.op.unary.f32(i32 6, float %96)  ; FAbs(value)
  %109 = fmul fast float %108, %10
  %110 = fcmp fast olt float %109, 0x3F50624DE0000000
  br i1 %110, label %111, label %114

; <label>:111                                     ; preds = %107
  %112 = fmul fast float %109, 5.000000e-01
  %113 = fsub fast float 1.000000e+00, %112
  br label %119

; <label>:114                                     ; preds = %107
  %115 = fmul fast float %109, 0xBFF7154760000000
  %116 = call float @dx.op.unary.f32(i32 21, float %115)  ; Exp(value)
  %117 = fsub fast float 1.000000e+00, %116
  %118 = fdiv fast float %117, %109
  br label %119

; <label>:119                                     ; preds = %114, %111
  %120 = phi float [ %113, %111 ], [ %118, %114 ]
  %121 = call float @dx.op.binary.f32(i32 36, float %93, float %17)  ; FMin(a,b)
  %122 = fsub fast float %121, %9
  %123 = fmul fast float %10, %122
  %124 = fsub fast float -0.000000e+00, %123
  %125 = call float @dx.op.binary.f32(i32 35, float %124, float -4.000000e+01)  ; FMax(a,b)
  %126 = call float @dx.op.binary.f32(i32 36, float %125, float 5.000000e+00)  ; FMin(a,b)
  %127 = fmul fast float %126, 0x3FF7154760000000
  %128 = call float @dx.op.unary.f32(i32 21, float %127)  ; Exp(value)
  %129 = fmul fast float %128, %120
  br label %130

; <label>:130                                     ; preds = %119, %79
  %131 = phi float [ %129, %119 ], [ 1.000000e+00, %79 ]
  %132 = fmul fast float %105, %15
  %133 = fmul fast float %132, %131
  %134 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %133)  ; FMin(a,b)
  %135 = fmul fast float %134, 0xBFF7154760000000
  %136 = call float @dx.op.unary.f32(i32 21, float %135)  ; Exp(value)
  %137 = fsub fast float 1.000000e+00, %136
  %138 = call float @dx.op.binary.f32(i32 36, float %11, float %137)  ; FMin(a,b)
  %139 = fsub fast float %12, %47
  %140 = fsub fast float %13, %48
  %141 = fsub fast float %14, %49
  %142 = fmul fast float %138, %139
  %143 = fmul fast float %138, %140
  %144 = fmul fast float %138, %141
  %145 = fadd fast float %142, %47
  %146 = fadd fast float %143, %48
  %147 = fadd fast float %144, %49
  br label %148

; <label>:148                                     ; preds = %130, %60, %54
  %149 = phi float [ %145, %130 ], [ %47, %60 ], [ %47, %54 ]
  %150 = phi float [ %146, %130 ], [ %48, %60 ], [ %48, %54 ]
  %151 = phi float [ %147, %130 ], [ %49, %60 ], [ %49, %54 ]
  %152 = fadd fast float %4, 1.000000e+00
  %153 = fadd fast float %5, 1.000000e+00
  %154 = fsub fast float 1.000000e+00, %4
  %155 = fmul fast float %35, %152
  %156 = fmul fast float %35, %153
  %157 = fmul fast float %35, %154
  %158 = fmul fast float %155, %149
  %159 = fmul fast float %156, %150
  %160 = fmul fast float %157, %151
  %161 = fcmp fast ult float %36, 5.000000e-01
  br i1 %161, label %187, label %162

; <label>:162                                     ; preds = %148
  %163 = fmul fast float %158, 0x4004147AE0000000
  %164 = fmul fast float %159, 0x4004147AE0000000
  %165 = fmul fast float %160, 0x4004147AE0000000
  %166 = fadd fast float %163, 0x3F9EB851E0000000
  %167 = fadd fast float %164, 0x3F9EB851E0000000
  %168 = fadd fast float %165, 0x3F9EB851E0000000
  %169 = fmul fast float %166, %158
  %170 = fmul fast float %167, %159
  %171 = fmul fast float %168, %160
  %172 = fmul fast float %158, 0x400370A3E0000000
  %173 = fmul fast float %159, 0x400370A3E0000000
  %174 = fmul fast float %160, 0x400370A3E0000000
  %175 = fadd fast float %172, 0x3FE2E147A0000000
  %176 = fadd fast float %173, 0x3FE2E147A0000000
  %177 = fadd fast float %174, 0x3FE2E147A0000000
  %178 = fmul fast float %175, %158
  %179 = fmul fast float %176, %159
  %180 = fmul fast float %177, %160
  %181 = fadd fast float %178, 0x3FC1EB8520000000
  %182 = fadd fast float %179, 0x3FC1EB8520000000
  %183 = fadd fast float %180, 0x3FC1EB8520000000
  %184 = fdiv fast float %169, %181
  %185 = fdiv fast float %170, %182
  %186 = fdiv fast float %171, %183
  br label %187

; <label>:187                                     ; preds = %162, %148
  %188 = phi float [ %184, %162 ], [ %158, %148 ]
  %189 = phi float [ %185, %162 ], [ %159, %148 ]
  %190 = phi float [ %186, %162 ], [ %160, %148 ]
  %191 = call float @dx.op.unary.f32(i32 7, float %188)  ; Saturate(value)
  %192 = call float @dx.op.unary.f32(i32 7, float %189)  ; Saturate(value)
  %193 = call float @dx.op.unary.f32(i32 7, float %190)  ; Saturate(value)
  %194 = call float @dx.op.dot3.f32(i32 55, float %191, float %192, float %193, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %195 = fsub fast float %191, %194
  %196 = fsub fast float %192, %194
  %197 = fsub fast float %193, %194
  %198 = fmul fast float %195, %7
  %199 = fmul fast float %196, %7
  %200 = fmul fast float %197, %7
  %201 = fadd fast float %198, %194
  %202 = fadd fast float %199, %194
  %203 = fadd fast float %200, %194
  %204 = call float @dx.op.unary.f32(i32 7, float %201)  ; Saturate(value)
  %205 = call float @dx.op.unary.f32(i32 7, float %202)  ; Saturate(value)
  %206 = call float @dx.op.unary.f32(i32 7, float %203)  ; Saturate(value)
  %207 = fadd fast float %204, 0xBFC70A3D80000000
  %208 = fadd fast float %205, 0xBFC70A3D80000000
  %209 = fadd fast float %206, 0xBFC70A3D80000000
  %210 = fmul fast float %207, %6
  %211 = fmul fast float %208, %6
  %212 = fmul fast float %209, %6
  %213 = fadd fast float %210, 0x3FC70A3D80000000
  %214 = fadd fast float %211, 0x3FC70A3D80000000
  %215 = fadd fast float %212, 0x3FC70A3D80000000
  %216 = call float @dx.op.unary.f32(i32 7, float %213)  ; Saturate(value)
  %217 = call float @dx.op.unary.f32(i32 7, float %214)  ; Saturate(value)
  %218 = call float @dx.op.unary.f32(i32 7, float %215)  ; Saturate(value)
  %219 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %219, label %220, label %1174

; <label>:220                                     ; preds = %187
  %221 = add i32 %45, -1
  %222 = add i32 %42, -1
  %223 = add i32 %43, -1
  %224 = call i32 @dx.op.binary.i32(i32 37, i32 %44, i32 0)  ; IMax(a,b)
  %225 = call i32 @dx.op.binary.i32(i32 37, i32 %221, i32 0)  ; IMax(a,b)
  %226 = call i32 @dx.op.binary.i32(i32 38, i32 %224, i32 %222)  ; IMin(a,b)
  %227 = call i32 @dx.op.binary.i32(i32 38, i32 %225, i32 %223)  ; IMin(a,b)
  %228 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %226, i32 %227, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %229 = extractvalue %dx.types.ResRet.f32 %228, 0
  %230 = extractvalue %dx.types.ResRet.f32 %228, 1
  %231 = extractvalue %dx.types.ResRet.f32 %228, 2
  %232 = extractvalue %dx.types.ResRet.f32 %228, 3
  %233 = fcmp fast olt float %232, 0.000000e+00
  br i1 %233, label %234, label %268

; <label>:234                                     ; preds = %220
  %235 = fcmp fast ogt float %229, 0x3FA4B5DCC0000000
  %236 = fcmp fast ogt float %230, 0x3FA4B5DCC0000000
  %237 = fcmp fast ogt float %231, 0x3FA4B5DCC0000000
  %238 = select i1 %235, float 0.000000e+00, float 1.000000e+00
  %239 = select i1 %236, float 0.000000e+00, float 1.000000e+00
  %240 = select i1 %237, float 0.000000e+00, float 1.000000e+00
  %241 = fmul fast float %229, 0x3FB3D07220000000
  %242 = fmul fast float %230, 0x3FB3D07220000000
  %243 = fmul fast float %231, 0x3FB3D07220000000
  %244 = fadd fast float %229, 0x3FAC28F5C0000000
  %245 = fadd fast float %230, 0x3FAC28F5C0000000
  %246 = fadd fast float %231, 0x3FAC28F5C0000000
  %247 = fmul fast float %244, 0x3FEE54EDE0000000
  %248 = fmul fast float %245, 0x3FEE54EDE0000000
  %249 = fmul fast float %246, 0x3FEE54EDE0000000
  %250 = call float @dx.op.unary.f32(i32 23, float %247)  ; Log(value)
  %251 = call float @dx.op.unary.f32(i32 23, float %248)  ; Log(value)
  %252 = call float @dx.op.unary.f32(i32 23, float %249)  ; Log(value)
  %253 = fmul fast float %250, 0x4003333340000000
  %254 = fmul fast float %251, 0x4003333340000000
  %255 = fmul fast float %252, 0x4003333340000000
  %256 = call float @dx.op.unary.f32(i32 21, float %253)  ; Exp(value)
  %257 = call float @dx.op.unary.f32(i32 21, float %254)  ; Exp(value)
  %258 = call float @dx.op.unary.f32(i32 21, float %255)  ; Exp(value)
  %259 = fsub fast float %241, %256
  %260 = fsub fast float %242, %257
  %261 = fsub fast float %243, %258
  %262 = fmul fast float %259, %238
  %263 = fmul fast float %260, %239
  %264 = fmul fast float %261, %240
  %265 = fadd fast float %262, %256
  %266 = fadd fast float %263, %257
  %267 = fadd fast float %264, %258
  br label %433

; <label>:268                                     ; preds = %220
  %269 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %226, i32 %227, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %270 = extractvalue %dx.types.ResRet.f32 %269, 0
  %271 = fcmp fast ogt float %37, 5.000000e-01
  %272 = fcmp fast olt float %270, 1.000000e+00
  %273 = and i1 %271, %272
  br i1 %273, label %274, label %362

; <label>:274                                     ; preds = %268
  %275 = sitofp i32 %226 to float
  %276 = sitofp i32 %227 to float
  %277 = fadd fast float %275, 5.000000e-01
  %278 = fadd fast float %276, 5.000000e-01
  %279 = uitofp i32 %42 to float
  %280 = uitofp i32 %43 to float
  %281 = fdiv fast float %277, %279
  %282 = fdiv fast float %278, %280
  %283 = fmul fast float %281, 2.000000e+00
  %284 = fmul fast float %282, 2.000000e+00
  %285 = fadd fast float %283, -1.000000e+00
  %286 = fsub fast float 1.000000e+00, %284
  %287 = fmul fast float %285, %34
  %288 = call float @dx.op.tertiary.f32(i32 46, float %286, float %30, float %287)  ; FMad(a,b,c)
  %289 = call float @dx.op.tertiary.f32(i32 46, float %270, float %26, float %288)  ; FMad(a,b,c)
  %290 = fadd fast float %289, %22
  %291 = call float @dx.op.unary.f32(i32 6, float %290)  ; FAbs(value)
  %292 = fcmp fast ogt float %291, 0x3EB0C6F7A0000000
  br i1 %292, label %293, label %362

; <label>:293                                     ; preds = %274
  %294 = fmul fast float %285, %33
  %295 = call float @dx.op.tertiary.f32(i32 46, float %286, float %29, float %294)  ; FMad(a,b,c)
  %296 = call float @dx.op.tertiary.f32(i32 46, float %270, float %25, float %295)  ; FMad(a,b,c)
  %297 = fadd fast float %296, %21
  %298 = fmul fast float %285, %32
  %299 = call float @dx.op.tertiary.f32(i32 46, float %286, float %28, float %298)  ; FMad(a,b,c)
  %300 = call float @dx.op.tertiary.f32(i32 46, float %270, float %24, float %299)  ; FMad(a,b,c)
  %301 = fadd fast float %300, %20
  %302 = fmul fast float %285, %31
  %303 = call float @dx.op.tertiary.f32(i32 46, float %286, float %27, float %302)  ; FMad(a,b,c)
  %304 = call float @dx.op.tertiary.f32(i32 46, float %270, float %23, float %303)  ; FMad(a,b,c)
  %305 = fadd fast float %304, %19
  %306 = fdiv fast float %305, %290
  %307 = fdiv fast float %301, %290
  %308 = fdiv fast float %297, %290
  %309 = fsub fast float %306, %16
  %310 = fsub fast float %307, %17
  %311 = fsub fast float %308, %18
  %312 = fmul fast float %309, %309
  %313 = fmul fast float %310, %310
  %314 = fadd fast float %313, %312
  %315 = fmul fast float %311, %311
  %316 = fadd fast float %314, %315
  %317 = call float @dx.op.unary.f32(i32 24, float %316)  ; Sqrt(value)
  %318 = fsub fast float %317, %8
  %319 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %318)  ; FMax(a,b)
  %320 = fcmp fast ogt float %38, 1.500000e+00
  br i1 %320, label %321, label %344

; <label>:321                                     ; preds = %293
  %322 = call float @dx.op.unary.f32(i32 6, float %310)  ; FAbs(value)
  %323 = fmul fast float %322, %10
  %324 = fcmp fast olt float %323, 0x3F50624DE0000000
  br i1 %324, label %325, label %328

; <label>:325                                     ; preds = %321
  %326 = fmul fast float %323, 5.000000e-01
  %327 = fsub fast float 1.000000e+00, %326
  br label %333

; <label>:328                                     ; preds = %321
  %329 = fmul fast float %323, 0xBFF7154760000000
  %330 = call float @dx.op.unary.f32(i32 21, float %329)  ; Exp(value)
  %331 = fsub fast float 1.000000e+00, %330
  %332 = fdiv fast float %331, %323
  br label %333

; <label>:333                                     ; preds = %328, %325
  %334 = phi float [ %327, %325 ], [ %332, %328 ]
  %335 = call float @dx.op.binary.f32(i32 36, float %307, float %17)  ; FMin(a,b)
  %336 = fsub fast float %335, %9
  %337 = fmul fast float %10, %336
  %338 = fsub fast float -0.000000e+00, %337
  %339 = call float @dx.op.binary.f32(i32 35, float %338, float -4.000000e+01)  ; FMax(a,b)
  %340 = call float @dx.op.binary.f32(i32 36, float %339, float 5.000000e+00)  ; FMin(a,b)
  %341 = fmul fast float %340, 0x3FF7154760000000
  %342 = call float @dx.op.unary.f32(i32 21, float %341)  ; Exp(value)
  %343 = fmul fast float %342, %334
  br label %344

; <label>:344                                     ; preds = %333, %293
  %345 = phi float [ %343, %333 ], [ 1.000000e+00, %293 ]
  %346 = fmul fast float %319, %15
  %347 = fmul fast float %346, %345
  %348 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %347)  ; FMin(a,b)
  %349 = fmul fast float %348, 0xBFF7154760000000
  %350 = call float @dx.op.unary.f32(i32 21, float %349)  ; Exp(value)
  %351 = fsub fast float 1.000000e+00, %350
  %352 = call float @dx.op.binary.f32(i32 36, float %11, float %351)  ; FMin(a,b)
  %353 = fsub fast float %12, %229
  %354 = fsub fast float %13, %230
  %355 = fsub fast float %14, %231
  %356 = fmul fast float %352, %353
  %357 = fmul fast float %352, %354
  %358 = fmul fast float %352, %355
  %359 = fadd fast float %356, %229
  %360 = fadd fast float %357, %230
  %361 = fadd fast float %358, %231
  br label %362

; <label>:362                                     ; preds = %344, %274, %268
  %363 = phi float [ %359, %344 ], [ %229, %274 ], [ %229, %268 ]
  %364 = phi float [ %360, %344 ], [ %230, %274 ], [ %230, %268 ]
  %365 = phi float [ %361, %344 ], [ %231, %274 ], [ %231, %268 ]
  %366 = fadd fast float %4, 1.000000e+00
  %367 = fadd fast float %5, 1.000000e+00
  %368 = fsub fast float 1.000000e+00, %4
  %369 = fmul fast float %35, %366
  %370 = fmul fast float %35, %367
  %371 = fmul fast float %35, %368
  %372 = fmul fast float %369, %363
  %373 = fmul fast float %370, %364
  %374 = fmul fast float %371, %365
  %375 = fcmp fast ult float %36, 5.000000e-01
  br i1 %375, label %401, label %376

; <label>:376                                     ; preds = %362
  %377 = fmul fast float %372, 0x4004147AE0000000
  %378 = fmul fast float %373, 0x4004147AE0000000
  %379 = fmul fast float %374, 0x4004147AE0000000
  %380 = fadd fast float %377, 0x3F9EB851E0000000
  %381 = fadd fast float %378, 0x3F9EB851E0000000
  %382 = fadd fast float %379, 0x3F9EB851E0000000
  %383 = fmul fast float %380, %372
  %384 = fmul fast float %381, %373
  %385 = fmul fast float %382, %374
  %386 = fmul fast float %372, 0x400370A3E0000000
  %387 = fmul fast float %373, 0x400370A3E0000000
  %388 = fmul fast float %374, 0x400370A3E0000000
  %389 = fadd fast float %386, 0x3FE2E147A0000000
  %390 = fadd fast float %387, 0x3FE2E147A0000000
  %391 = fadd fast float %388, 0x3FE2E147A0000000
  %392 = fmul fast float %389, %372
  %393 = fmul fast float %390, %373
  %394 = fmul fast float %391, %374
  %395 = fadd fast float %392, 0x3FC1EB8520000000
  %396 = fadd fast float %393, 0x3FC1EB8520000000
  %397 = fadd fast float %394, 0x3FC1EB8520000000
  %398 = fdiv fast float %383, %395
  %399 = fdiv fast float %384, %396
  %400 = fdiv fast float %385, %397
  br label %401

; <label>:401                                     ; preds = %376, %362
  %402 = phi float [ %398, %376 ], [ %372, %362 ]
  %403 = phi float [ %399, %376 ], [ %373, %362 ]
  %404 = phi float [ %400, %376 ], [ %374, %362 ]
  %405 = call float @dx.op.unary.f32(i32 7, float %402)  ; Saturate(value)
  %406 = call float @dx.op.unary.f32(i32 7, float %403)  ; Saturate(value)
  %407 = call float @dx.op.unary.f32(i32 7, float %404)  ; Saturate(value)
  %408 = call float @dx.op.dot3.f32(i32 55, float %405, float %406, float %407, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %409 = fsub fast float %405, %408
  %410 = fsub fast float %406, %408
  %411 = fsub fast float %407, %408
  %412 = fmul fast float %409, %7
  %413 = fmul fast float %410, %7
  %414 = fmul fast float %411, %7
  %415 = fadd fast float %412, %408
  %416 = fadd fast float %413, %408
  %417 = fadd fast float %414, %408
  %418 = call float @dx.op.unary.f32(i32 7, float %415)  ; Saturate(value)
  %419 = call float @dx.op.unary.f32(i32 7, float %416)  ; Saturate(value)
  %420 = call float @dx.op.unary.f32(i32 7, float %417)  ; Saturate(value)
  %421 = fadd fast float %418, 0xBFC70A3D80000000
  %422 = fadd fast float %419, 0xBFC70A3D80000000
  %423 = fadd fast float %420, 0xBFC70A3D80000000
  %424 = fmul fast float %421, %6
  %425 = fmul fast float %422, %6
  %426 = fmul fast float %423, %6
  %427 = fadd fast float %424, 0x3FC70A3D80000000
  %428 = fadd fast float %425, 0x3FC70A3D80000000
  %429 = fadd fast float %426, 0x3FC70A3D80000000
  %430 = call float @dx.op.unary.f32(i32 7, float %427)  ; Saturate(value)
  %431 = call float @dx.op.unary.f32(i32 7, float %428)  ; Saturate(value)
  %432 = call float @dx.op.unary.f32(i32 7, float %429)  ; Saturate(value)
  br label %433

; <label>:433                                     ; preds = %401, %234
  %434 = phi float [ %265, %234 ], [ %430, %401 ]
  %435 = phi float [ %266, %234 ], [ %431, %401 ]
  %436 = phi float [ %267, %234 ], [ %432, %401 ]
  %437 = add i32 %45, 1
  %438 = call i32 @dx.op.binary.i32(i32 37, i32 %437, i32 0)  ; IMax(a,b)
  %439 = call i32 @dx.op.binary.i32(i32 38, i32 %438, i32 %223)  ; IMin(a,b)
  %440 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %226, i32 %439, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %441 = extractvalue %dx.types.ResRet.f32 %440, 0
  %442 = extractvalue %dx.types.ResRet.f32 %440, 1
  %443 = extractvalue %dx.types.ResRet.f32 %440, 2
  %444 = extractvalue %dx.types.ResRet.f32 %440, 3
  %445 = fcmp fast olt float %444, 0.000000e+00
  br i1 %445, label %446, label %480

; <label>:446                                     ; preds = %433
  %447 = fcmp fast ogt float %441, 0x3FA4B5DCC0000000
  %448 = fcmp fast ogt float %442, 0x3FA4B5DCC0000000
  %449 = fcmp fast ogt float %443, 0x3FA4B5DCC0000000
  %450 = select i1 %447, float 0.000000e+00, float 1.000000e+00
  %451 = select i1 %448, float 0.000000e+00, float 1.000000e+00
  %452 = select i1 %449, float 0.000000e+00, float 1.000000e+00
  %453 = fmul fast float %441, 0x3FB3D07220000000
  %454 = fmul fast float %442, 0x3FB3D07220000000
  %455 = fmul fast float %443, 0x3FB3D07220000000
  %456 = fadd fast float %441, 0x3FAC28F5C0000000
  %457 = fadd fast float %442, 0x3FAC28F5C0000000
  %458 = fadd fast float %443, 0x3FAC28F5C0000000
  %459 = fmul fast float %456, 0x3FEE54EDE0000000
  %460 = fmul fast float %457, 0x3FEE54EDE0000000
  %461 = fmul fast float %458, 0x3FEE54EDE0000000
  %462 = call float @dx.op.unary.f32(i32 23, float %459)  ; Log(value)
  %463 = call float @dx.op.unary.f32(i32 23, float %460)  ; Log(value)
  %464 = call float @dx.op.unary.f32(i32 23, float %461)  ; Log(value)
  %465 = fmul fast float %462, 0x4003333340000000
  %466 = fmul fast float %463, 0x4003333340000000
  %467 = fmul fast float %464, 0x4003333340000000
  %468 = call float @dx.op.unary.f32(i32 21, float %465)  ; Exp(value)
  %469 = call float @dx.op.unary.f32(i32 21, float %466)  ; Exp(value)
  %470 = call float @dx.op.unary.f32(i32 21, float %467)  ; Exp(value)
  %471 = fsub fast float %453, %468
  %472 = fsub fast float %454, %469
  %473 = fsub fast float %455, %470
  %474 = fmul fast float %471, %450
  %475 = fmul fast float %472, %451
  %476 = fmul fast float %473, %452
  %477 = fadd fast float %474, %468
  %478 = fadd fast float %475, %469
  %479 = fadd fast float %476, %470
  br label %645

; <label>:480                                     ; preds = %433
  %481 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %226, i32 %439, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %482 = extractvalue %dx.types.ResRet.f32 %481, 0
  %483 = fcmp fast ogt float %37, 5.000000e-01
  %484 = fcmp fast olt float %482, 1.000000e+00
  %485 = and i1 %483, %484
  br i1 %485, label %486, label %574

; <label>:486                                     ; preds = %480
  %487 = sitofp i32 %226 to float
  %488 = sitofp i32 %439 to float
  %489 = fadd fast float %487, 5.000000e-01
  %490 = fadd fast float %488, 5.000000e-01
  %491 = uitofp i32 %42 to float
  %492 = uitofp i32 %43 to float
  %493 = fdiv fast float %489, %491
  %494 = fdiv fast float %490, %492
  %495 = fmul fast float %493, 2.000000e+00
  %496 = fmul fast float %494, 2.000000e+00
  %497 = fadd fast float %495, -1.000000e+00
  %498 = fsub fast float 1.000000e+00, %496
  %499 = fmul fast float %497, %34
  %500 = call float @dx.op.tertiary.f32(i32 46, float %498, float %30, float %499)  ; FMad(a,b,c)
  %501 = call float @dx.op.tertiary.f32(i32 46, float %482, float %26, float %500)  ; FMad(a,b,c)
  %502 = fadd fast float %501, %22
  %503 = call float @dx.op.unary.f32(i32 6, float %502)  ; FAbs(value)
  %504 = fcmp fast ogt float %503, 0x3EB0C6F7A0000000
  br i1 %504, label %505, label %574

; <label>:505                                     ; preds = %486
  %506 = fmul fast float %497, %33
  %507 = call float @dx.op.tertiary.f32(i32 46, float %498, float %29, float %506)  ; FMad(a,b,c)
  %508 = call float @dx.op.tertiary.f32(i32 46, float %482, float %25, float %507)  ; FMad(a,b,c)
  %509 = fadd fast float %508, %21
  %510 = fmul fast float %497, %32
  %511 = call float @dx.op.tertiary.f32(i32 46, float %498, float %28, float %510)  ; FMad(a,b,c)
  %512 = call float @dx.op.tertiary.f32(i32 46, float %482, float %24, float %511)  ; FMad(a,b,c)
  %513 = fadd fast float %512, %20
  %514 = fmul fast float %497, %31
  %515 = call float @dx.op.tertiary.f32(i32 46, float %498, float %27, float %514)  ; FMad(a,b,c)
  %516 = call float @dx.op.tertiary.f32(i32 46, float %482, float %23, float %515)  ; FMad(a,b,c)
  %517 = fadd fast float %516, %19
  %518 = fdiv fast float %517, %502
  %519 = fdiv fast float %513, %502
  %520 = fdiv fast float %509, %502
  %521 = fsub fast float %518, %16
  %522 = fsub fast float %519, %17
  %523 = fsub fast float %520, %18
  %524 = fmul fast float %521, %521
  %525 = fmul fast float %522, %522
  %526 = fadd fast float %525, %524
  %527 = fmul fast float %523, %523
  %528 = fadd fast float %526, %527
  %529 = call float @dx.op.unary.f32(i32 24, float %528)  ; Sqrt(value)
  %530 = fsub fast float %529, %8
  %531 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %530)  ; FMax(a,b)
  %532 = fcmp fast ogt float %38, 1.500000e+00
  br i1 %532, label %533, label %556

; <label>:533                                     ; preds = %505
  %534 = call float @dx.op.unary.f32(i32 6, float %522)  ; FAbs(value)
  %535 = fmul fast float %534, %10
  %536 = fcmp fast olt float %535, 0x3F50624DE0000000
  br i1 %536, label %537, label %540

; <label>:537                                     ; preds = %533
  %538 = fmul fast float %535, 5.000000e-01
  %539 = fsub fast float 1.000000e+00, %538
  br label %545

; <label>:540                                     ; preds = %533
  %541 = fmul fast float %535, 0xBFF7154760000000
  %542 = call float @dx.op.unary.f32(i32 21, float %541)  ; Exp(value)
  %543 = fsub fast float 1.000000e+00, %542
  %544 = fdiv fast float %543, %535
  br label %545

; <label>:545                                     ; preds = %540, %537
  %546 = phi float [ %539, %537 ], [ %544, %540 ]
  %547 = call float @dx.op.binary.f32(i32 36, float %519, float %17)  ; FMin(a,b)
  %548 = fsub fast float %547, %9
  %549 = fmul fast float %10, %548
  %550 = fsub fast float -0.000000e+00, %549
  %551 = call float @dx.op.binary.f32(i32 35, float %550, float -4.000000e+01)  ; FMax(a,b)
  %552 = call float @dx.op.binary.f32(i32 36, float %551, float 5.000000e+00)  ; FMin(a,b)
  %553 = fmul fast float %552, 0x3FF7154760000000
  %554 = call float @dx.op.unary.f32(i32 21, float %553)  ; Exp(value)
  %555 = fmul fast float %554, %546
  br label %556

; <label>:556                                     ; preds = %545, %505
  %557 = phi float [ %555, %545 ], [ 1.000000e+00, %505 ]
  %558 = fmul fast float %531, %15
  %559 = fmul fast float %558, %557
  %560 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %559)  ; FMin(a,b)
  %561 = fmul fast float %560, 0xBFF7154760000000
  %562 = call float @dx.op.unary.f32(i32 21, float %561)  ; Exp(value)
  %563 = fsub fast float 1.000000e+00, %562
  %564 = call float @dx.op.binary.f32(i32 36, float %11, float %563)  ; FMin(a,b)
  %565 = fsub fast float %12, %441
  %566 = fsub fast float %13, %442
  %567 = fsub fast float %14, %443
  %568 = fmul fast float %564, %565
  %569 = fmul fast float %564, %566
  %570 = fmul fast float %564, %567
  %571 = fadd fast float %568, %441
  %572 = fadd fast float %569, %442
  %573 = fadd fast float %570, %443
  br label %574

; <label>:574                                     ; preds = %556, %486, %480
  %575 = phi float [ %571, %556 ], [ %441, %486 ], [ %441, %480 ]
  %576 = phi float [ %572, %556 ], [ %442, %486 ], [ %442, %480 ]
  %577 = phi float [ %573, %556 ], [ %443, %486 ], [ %443, %480 ]
  %578 = fadd fast float %4, 1.000000e+00
  %579 = fadd fast float %5, 1.000000e+00
  %580 = fsub fast float 1.000000e+00, %4
  %581 = fmul fast float %35, %578
  %582 = fmul fast float %35, %579
  %583 = fmul fast float %35, %580
  %584 = fmul fast float %581, %575
  %585 = fmul fast float %582, %576
  %586 = fmul fast float %583, %577
  %587 = fcmp fast ult float %36, 5.000000e-01
  br i1 %587, label %613, label %588

; <label>:588                                     ; preds = %574
  %589 = fmul fast float %584, 0x4004147AE0000000
  %590 = fmul fast float %585, 0x4004147AE0000000
  %591 = fmul fast float %586, 0x4004147AE0000000
  %592 = fadd fast float %589, 0x3F9EB851E0000000
  %593 = fadd fast float %590, 0x3F9EB851E0000000
  %594 = fadd fast float %591, 0x3F9EB851E0000000
  %595 = fmul fast float %592, %584
  %596 = fmul fast float %593, %585
  %597 = fmul fast float %594, %586
  %598 = fmul fast float %584, 0x400370A3E0000000
  %599 = fmul fast float %585, 0x400370A3E0000000
  %600 = fmul fast float %586, 0x400370A3E0000000
  %601 = fadd fast float %598, 0x3FE2E147A0000000
  %602 = fadd fast float %599, 0x3FE2E147A0000000
  %603 = fadd fast float %600, 0x3FE2E147A0000000
  %604 = fmul fast float %601, %584
  %605 = fmul fast float %602, %585
  %606 = fmul fast float %603, %586
  %607 = fadd fast float %604, 0x3FC1EB8520000000
  %608 = fadd fast float %605, 0x3FC1EB8520000000
  %609 = fadd fast float %606, 0x3FC1EB8520000000
  %610 = fdiv fast float %595, %607
  %611 = fdiv fast float %596, %608
  %612 = fdiv fast float %597, %609
  br label %613

; <label>:613                                     ; preds = %588, %574
  %614 = phi float [ %610, %588 ], [ %584, %574 ]
  %615 = phi float [ %611, %588 ], [ %585, %574 ]
  %616 = phi float [ %612, %588 ], [ %586, %574 ]
  %617 = call float @dx.op.unary.f32(i32 7, float %614)  ; Saturate(value)
  %618 = call float @dx.op.unary.f32(i32 7, float %615)  ; Saturate(value)
  %619 = call float @dx.op.unary.f32(i32 7, float %616)  ; Saturate(value)
  %620 = call float @dx.op.dot3.f32(i32 55, float %617, float %618, float %619, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %621 = fsub fast float %617, %620
  %622 = fsub fast float %618, %620
  %623 = fsub fast float %619, %620
  %624 = fmul fast float %621, %7
  %625 = fmul fast float %622, %7
  %626 = fmul fast float %623, %7
  %627 = fadd fast float %624, %620
  %628 = fadd fast float %625, %620
  %629 = fadd fast float %626, %620
  %630 = call float @dx.op.unary.f32(i32 7, float %627)  ; Saturate(value)
  %631 = call float @dx.op.unary.f32(i32 7, float %628)  ; Saturate(value)
  %632 = call float @dx.op.unary.f32(i32 7, float %629)  ; Saturate(value)
  %633 = fadd fast float %630, 0xBFC70A3D80000000
  %634 = fadd fast float %631, 0xBFC70A3D80000000
  %635 = fadd fast float %632, 0xBFC70A3D80000000
  %636 = fmul fast float %633, %6
  %637 = fmul fast float %634, %6
  %638 = fmul fast float %635, %6
  %639 = fadd fast float %636, 0x3FC70A3D80000000
  %640 = fadd fast float %637, 0x3FC70A3D80000000
  %641 = fadd fast float %638, 0x3FC70A3D80000000
  %642 = call float @dx.op.unary.f32(i32 7, float %639)  ; Saturate(value)
  %643 = call float @dx.op.unary.f32(i32 7, float %640)  ; Saturate(value)
  %644 = call float @dx.op.unary.f32(i32 7, float %641)  ; Saturate(value)
  br label %645

; <label>:645                                     ; preds = %613, %446
  %646 = phi float [ %477, %446 ], [ %642, %613 ]
  %647 = phi float [ %478, %446 ], [ %643, %613 ]
  %648 = phi float [ %479, %446 ], [ %644, %613 ]
  %649 = add i32 %44, -1
  %650 = call i32 @dx.op.binary.i32(i32 37, i32 %649, i32 0)  ; IMax(a,b)
  %651 = call i32 @dx.op.binary.i32(i32 37, i32 %45, i32 0)  ; IMax(a,b)
  %652 = call i32 @dx.op.binary.i32(i32 38, i32 %650, i32 %222)  ; IMin(a,b)
  %653 = call i32 @dx.op.binary.i32(i32 38, i32 %651, i32 %223)  ; IMin(a,b)
  %654 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %652, i32 %653, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %655 = extractvalue %dx.types.ResRet.f32 %654, 0
  %656 = extractvalue %dx.types.ResRet.f32 %654, 1
  %657 = extractvalue %dx.types.ResRet.f32 %654, 2
  %658 = extractvalue %dx.types.ResRet.f32 %654, 3
  %659 = fcmp fast olt float %658, 0.000000e+00
  br i1 %659, label %660, label %694

; <label>:660                                     ; preds = %645
  %661 = fcmp fast ogt float %655, 0x3FA4B5DCC0000000
  %662 = fcmp fast ogt float %656, 0x3FA4B5DCC0000000
  %663 = fcmp fast ogt float %657, 0x3FA4B5DCC0000000
  %664 = select i1 %661, float 0.000000e+00, float 1.000000e+00
  %665 = select i1 %662, float 0.000000e+00, float 1.000000e+00
  %666 = select i1 %663, float 0.000000e+00, float 1.000000e+00
  %667 = fmul fast float %655, 0x3FB3D07220000000
  %668 = fmul fast float %656, 0x3FB3D07220000000
  %669 = fmul fast float %657, 0x3FB3D07220000000
  %670 = fadd fast float %655, 0x3FAC28F5C0000000
  %671 = fadd fast float %656, 0x3FAC28F5C0000000
  %672 = fadd fast float %657, 0x3FAC28F5C0000000
  %673 = fmul fast float %670, 0x3FEE54EDE0000000
  %674 = fmul fast float %671, 0x3FEE54EDE0000000
  %675 = fmul fast float %672, 0x3FEE54EDE0000000
  %676 = call float @dx.op.unary.f32(i32 23, float %673)  ; Log(value)
  %677 = call float @dx.op.unary.f32(i32 23, float %674)  ; Log(value)
  %678 = call float @dx.op.unary.f32(i32 23, float %675)  ; Log(value)
  %679 = fmul fast float %676, 0x4003333340000000
  %680 = fmul fast float %677, 0x4003333340000000
  %681 = fmul fast float %678, 0x4003333340000000
  %682 = call float @dx.op.unary.f32(i32 21, float %679)  ; Exp(value)
  %683 = call float @dx.op.unary.f32(i32 21, float %680)  ; Exp(value)
  %684 = call float @dx.op.unary.f32(i32 21, float %681)  ; Exp(value)
  %685 = fsub fast float %667, %682
  %686 = fsub fast float %668, %683
  %687 = fsub fast float %669, %684
  %688 = fmul fast float %685, %664
  %689 = fmul fast float %686, %665
  %690 = fmul fast float %687, %666
  %691 = fadd fast float %688, %682
  %692 = fadd fast float %689, %683
  %693 = fadd fast float %690, %684
  br label %859

; <label>:694                                     ; preds = %645
  %695 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %652, i32 %653, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %696 = extractvalue %dx.types.ResRet.f32 %695, 0
  %697 = fcmp fast ogt float %37, 5.000000e-01
  %698 = fcmp fast olt float %696, 1.000000e+00
  %699 = and i1 %697, %698
  br i1 %699, label %700, label %788

; <label>:700                                     ; preds = %694
  %701 = sitofp i32 %652 to float
  %702 = sitofp i32 %653 to float
  %703 = fadd fast float %701, 5.000000e-01
  %704 = fadd fast float %702, 5.000000e-01
  %705 = uitofp i32 %42 to float
  %706 = uitofp i32 %43 to float
  %707 = fdiv fast float %703, %705
  %708 = fdiv fast float %704, %706
  %709 = fmul fast float %707, 2.000000e+00
  %710 = fmul fast float %708, 2.000000e+00
  %711 = fadd fast float %709, -1.000000e+00
  %712 = fsub fast float 1.000000e+00, %710
  %713 = fmul fast float %711, %34
  %714 = call float @dx.op.tertiary.f32(i32 46, float %712, float %30, float %713)  ; FMad(a,b,c)
  %715 = call float @dx.op.tertiary.f32(i32 46, float %696, float %26, float %714)  ; FMad(a,b,c)
  %716 = fadd fast float %715, %22
  %717 = call float @dx.op.unary.f32(i32 6, float %716)  ; FAbs(value)
  %718 = fcmp fast ogt float %717, 0x3EB0C6F7A0000000
  br i1 %718, label %719, label %788

; <label>:719                                     ; preds = %700
  %720 = fmul fast float %711, %33
  %721 = call float @dx.op.tertiary.f32(i32 46, float %712, float %29, float %720)  ; FMad(a,b,c)
  %722 = call float @dx.op.tertiary.f32(i32 46, float %696, float %25, float %721)  ; FMad(a,b,c)
  %723 = fadd fast float %722, %21
  %724 = fmul fast float %711, %32
  %725 = call float @dx.op.tertiary.f32(i32 46, float %712, float %28, float %724)  ; FMad(a,b,c)
  %726 = call float @dx.op.tertiary.f32(i32 46, float %696, float %24, float %725)  ; FMad(a,b,c)
  %727 = fadd fast float %726, %20
  %728 = fmul fast float %711, %31
  %729 = call float @dx.op.tertiary.f32(i32 46, float %712, float %27, float %728)  ; FMad(a,b,c)
  %730 = call float @dx.op.tertiary.f32(i32 46, float %696, float %23, float %729)  ; FMad(a,b,c)
  %731 = fadd fast float %730, %19
  %732 = fdiv fast float %731, %716
  %733 = fdiv fast float %727, %716
  %734 = fdiv fast float %723, %716
  %735 = fsub fast float %732, %16
  %736 = fsub fast float %733, %17
  %737 = fsub fast float %734, %18
  %738 = fmul fast float %735, %735
  %739 = fmul fast float %736, %736
  %740 = fadd fast float %739, %738
  %741 = fmul fast float %737, %737
  %742 = fadd fast float %740, %741
  %743 = call float @dx.op.unary.f32(i32 24, float %742)  ; Sqrt(value)
  %744 = fsub fast float %743, %8
  %745 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %744)  ; FMax(a,b)
  %746 = fcmp fast ogt float %38, 1.500000e+00
  br i1 %746, label %747, label %770

; <label>:747                                     ; preds = %719
  %748 = call float @dx.op.unary.f32(i32 6, float %736)  ; FAbs(value)
  %749 = fmul fast float %748, %10
  %750 = fcmp fast olt float %749, 0x3F50624DE0000000
  br i1 %750, label %751, label %754

; <label>:751                                     ; preds = %747
  %752 = fmul fast float %749, 5.000000e-01
  %753 = fsub fast float 1.000000e+00, %752
  br label %759

; <label>:754                                     ; preds = %747
  %755 = fmul fast float %749, 0xBFF7154760000000
  %756 = call float @dx.op.unary.f32(i32 21, float %755)  ; Exp(value)
  %757 = fsub fast float 1.000000e+00, %756
  %758 = fdiv fast float %757, %749
  br label %759

; <label>:759                                     ; preds = %754, %751
  %760 = phi float [ %753, %751 ], [ %758, %754 ]
  %761 = call float @dx.op.binary.f32(i32 36, float %733, float %17)  ; FMin(a,b)
  %762 = fsub fast float %761, %9
  %763 = fmul fast float %10, %762
  %764 = fsub fast float -0.000000e+00, %763
  %765 = call float @dx.op.binary.f32(i32 35, float %764, float -4.000000e+01)  ; FMax(a,b)
  %766 = call float @dx.op.binary.f32(i32 36, float %765, float 5.000000e+00)  ; FMin(a,b)
  %767 = fmul fast float %766, 0x3FF7154760000000
  %768 = call float @dx.op.unary.f32(i32 21, float %767)  ; Exp(value)
  %769 = fmul fast float %768, %760
  br label %770

; <label>:770                                     ; preds = %759, %719
  %771 = phi float [ %769, %759 ], [ 1.000000e+00, %719 ]
  %772 = fmul fast float %745, %15
  %773 = fmul fast float %772, %771
  %774 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %773)  ; FMin(a,b)
  %775 = fmul fast float %774, 0xBFF7154760000000
  %776 = call float @dx.op.unary.f32(i32 21, float %775)  ; Exp(value)
  %777 = fsub fast float 1.000000e+00, %776
  %778 = call float @dx.op.binary.f32(i32 36, float %11, float %777)  ; FMin(a,b)
  %779 = fsub fast float %12, %655
  %780 = fsub fast float %13, %656
  %781 = fsub fast float %14, %657
  %782 = fmul fast float %778, %779
  %783 = fmul fast float %778, %780
  %784 = fmul fast float %778, %781
  %785 = fadd fast float %782, %655
  %786 = fadd fast float %783, %656
  %787 = fadd fast float %784, %657
  br label %788

; <label>:788                                     ; preds = %770, %700, %694
  %789 = phi float [ %785, %770 ], [ %655, %700 ], [ %655, %694 ]
  %790 = phi float [ %786, %770 ], [ %656, %700 ], [ %656, %694 ]
  %791 = phi float [ %787, %770 ], [ %657, %700 ], [ %657, %694 ]
  %792 = fadd fast float %4, 1.000000e+00
  %793 = fadd fast float %5, 1.000000e+00
  %794 = fsub fast float 1.000000e+00, %4
  %795 = fmul fast float %35, %792
  %796 = fmul fast float %35, %793
  %797 = fmul fast float %35, %794
  %798 = fmul fast float %795, %789
  %799 = fmul fast float %796, %790
  %800 = fmul fast float %797, %791
  %801 = fcmp fast ult float %36, 5.000000e-01
  br i1 %801, label %827, label %802

; <label>:802                                     ; preds = %788
  %803 = fmul fast float %798, 0x4004147AE0000000
  %804 = fmul fast float %799, 0x4004147AE0000000
  %805 = fmul fast float %800, 0x4004147AE0000000
  %806 = fadd fast float %803, 0x3F9EB851E0000000
  %807 = fadd fast float %804, 0x3F9EB851E0000000
  %808 = fadd fast float %805, 0x3F9EB851E0000000
  %809 = fmul fast float %806, %798
  %810 = fmul fast float %807, %799
  %811 = fmul fast float %808, %800
  %812 = fmul fast float %798, 0x400370A3E0000000
  %813 = fmul fast float %799, 0x400370A3E0000000
  %814 = fmul fast float %800, 0x400370A3E0000000
  %815 = fadd fast float %812, 0x3FE2E147A0000000
  %816 = fadd fast float %813, 0x3FE2E147A0000000
  %817 = fadd fast float %814, 0x3FE2E147A0000000
  %818 = fmul fast float %815, %798
  %819 = fmul fast float %816, %799
  %820 = fmul fast float %817, %800
  %821 = fadd fast float %818, 0x3FC1EB8520000000
  %822 = fadd fast float %819, 0x3FC1EB8520000000
  %823 = fadd fast float %820, 0x3FC1EB8520000000
  %824 = fdiv fast float %809, %821
  %825 = fdiv fast float %810, %822
  %826 = fdiv fast float %811, %823
  br label %827

; <label>:827                                     ; preds = %802, %788
  %828 = phi float [ %824, %802 ], [ %798, %788 ]
  %829 = phi float [ %825, %802 ], [ %799, %788 ]
  %830 = phi float [ %826, %802 ], [ %800, %788 ]
  %831 = call float @dx.op.unary.f32(i32 7, float %828)  ; Saturate(value)
  %832 = call float @dx.op.unary.f32(i32 7, float %829)  ; Saturate(value)
  %833 = call float @dx.op.unary.f32(i32 7, float %830)  ; Saturate(value)
  %834 = call float @dx.op.dot3.f32(i32 55, float %831, float %832, float %833, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %835 = fsub fast float %831, %834
  %836 = fsub fast float %832, %834
  %837 = fsub fast float %833, %834
  %838 = fmul fast float %835, %7
  %839 = fmul fast float %836, %7
  %840 = fmul fast float %837, %7
  %841 = fadd fast float %838, %834
  %842 = fadd fast float %839, %834
  %843 = fadd fast float %840, %834
  %844 = call float @dx.op.unary.f32(i32 7, float %841)  ; Saturate(value)
  %845 = call float @dx.op.unary.f32(i32 7, float %842)  ; Saturate(value)
  %846 = call float @dx.op.unary.f32(i32 7, float %843)  ; Saturate(value)
  %847 = fadd fast float %844, 0xBFC70A3D80000000
  %848 = fadd fast float %845, 0xBFC70A3D80000000
  %849 = fadd fast float %846, 0xBFC70A3D80000000
  %850 = fmul fast float %847, %6
  %851 = fmul fast float %848, %6
  %852 = fmul fast float %849, %6
  %853 = fadd fast float %850, 0x3FC70A3D80000000
  %854 = fadd fast float %851, 0x3FC70A3D80000000
  %855 = fadd fast float %852, 0x3FC70A3D80000000
  %856 = call float @dx.op.unary.f32(i32 7, float %853)  ; Saturate(value)
  %857 = call float @dx.op.unary.f32(i32 7, float %854)  ; Saturate(value)
  %858 = call float @dx.op.unary.f32(i32 7, float %855)  ; Saturate(value)
  br label %859

; <label>:859                                     ; preds = %827, %660
  %860 = phi float [ %691, %660 ], [ %856, %827 ]
  %861 = phi float [ %692, %660 ], [ %857, %827 ]
  %862 = phi float [ %693, %660 ], [ %858, %827 ]
  %863 = add i32 %44, 1
  %864 = call i32 @dx.op.binary.i32(i32 37, i32 %863, i32 0)  ; IMax(a,b)
  %865 = call i32 @dx.op.binary.i32(i32 38, i32 %864, i32 %222)  ; IMin(a,b)
  %866 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %865, i32 %653, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %867 = extractvalue %dx.types.ResRet.f32 %866, 0
  %868 = extractvalue %dx.types.ResRet.f32 %866, 1
  %869 = extractvalue %dx.types.ResRet.f32 %866, 2
  %870 = extractvalue %dx.types.ResRet.f32 %866, 3
  %871 = fcmp fast olt float %870, 0.000000e+00
  br i1 %871, label %872, label %906

; <label>:872                                     ; preds = %859
  %873 = fcmp fast ogt float %867, 0x3FA4B5DCC0000000
  %874 = fcmp fast ogt float %868, 0x3FA4B5DCC0000000
  %875 = fcmp fast ogt float %869, 0x3FA4B5DCC0000000
  %876 = select i1 %873, float 0.000000e+00, float 1.000000e+00
  %877 = select i1 %874, float 0.000000e+00, float 1.000000e+00
  %878 = select i1 %875, float 0.000000e+00, float 1.000000e+00
  %879 = fmul fast float %867, 0x3FB3D07220000000
  %880 = fmul fast float %868, 0x3FB3D07220000000
  %881 = fmul fast float %869, 0x3FB3D07220000000
  %882 = fadd fast float %867, 0x3FAC28F5C0000000
  %883 = fadd fast float %868, 0x3FAC28F5C0000000
  %884 = fadd fast float %869, 0x3FAC28F5C0000000
  %885 = fmul fast float %882, 0x3FEE54EDE0000000
  %886 = fmul fast float %883, 0x3FEE54EDE0000000
  %887 = fmul fast float %884, 0x3FEE54EDE0000000
  %888 = call float @dx.op.unary.f32(i32 23, float %885)  ; Log(value)
  %889 = call float @dx.op.unary.f32(i32 23, float %886)  ; Log(value)
  %890 = call float @dx.op.unary.f32(i32 23, float %887)  ; Log(value)
  %891 = fmul fast float %888, 0x4003333340000000
  %892 = fmul fast float %889, 0x4003333340000000
  %893 = fmul fast float %890, 0x4003333340000000
  %894 = call float @dx.op.unary.f32(i32 21, float %891)  ; Exp(value)
  %895 = call float @dx.op.unary.f32(i32 21, float %892)  ; Exp(value)
  %896 = call float @dx.op.unary.f32(i32 21, float %893)  ; Exp(value)
  %897 = fsub fast float %879, %894
  %898 = fsub fast float %880, %895
  %899 = fsub fast float %881, %896
  %900 = fmul fast float %897, %876
  %901 = fmul fast float %898, %877
  %902 = fmul fast float %899, %878
  %903 = fadd fast float %900, %894
  %904 = fadd fast float %901, %895
  %905 = fadd fast float %902, %896
  br label %1071

; <label>:906                                     ; preds = %859
  %907 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %865, i32 %653, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %908 = extractvalue %dx.types.ResRet.f32 %907, 0
  %909 = fcmp fast ogt float %37, 5.000000e-01
  %910 = fcmp fast olt float %908, 1.000000e+00
  %911 = and i1 %909, %910
  br i1 %911, label %912, label %1000

; <label>:912                                     ; preds = %906
  %913 = sitofp i32 %865 to float
  %914 = sitofp i32 %653 to float
  %915 = fadd fast float %913, 5.000000e-01
  %916 = fadd fast float %914, 5.000000e-01
  %917 = uitofp i32 %42 to float
  %918 = uitofp i32 %43 to float
  %919 = fdiv fast float %915, %917
  %920 = fdiv fast float %916, %918
  %921 = fmul fast float %919, 2.000000e+00
  %922 = fmul fast float %920, 2.000000e+00
  %923 = fadd fast float %921, -1.000000e+00
  %924 = fsub fast float 1.000000e+00, %922
  %925 = fmul fast float %923, %34
  %926 = call float @dx.op.tertiary.f32(i32 46, float %924, float %30, float %925)  ; FMad(a,b,c)
  %927 = call float @dx.op.tertiary.f32(i32 46, float %908, float %26, float %926)  ; FMad(a,b,c)
  %928 = fadd fast float %927, %22
  %929 = call float @dx.op.unary.f32(i32 6, float %928)  ; FAbs(value)
  %930 = fcmp fast ogt float %929, 0x3EB0C6F7A0000000
  br i1 %930, label %931, label %1000

; <label>:931                                     ; preds = %912
  %932 = fmul fast float %923, %33
  %933 = call float @dx.op.tertiary.f32(i32 46, float %924, float %29, float %932)  ; FMad(a,b,c)
  %934 = call float @dx.op.tertiary.f32(i32 46, float %908, float %25, float %933)  ; FMad(a,b,c)
  %935 = fadd fast float %934, %21
  %936 = fmul fast float %923, %32
  %937 = call float @dx.op.tertiary.f32(i32 46, float %924, float %28, float %936)  ; FMad(a,b,c)
  %938 = call float @dx.op.tertiary.f32(i32 46, float %908, float %24, float %937)  ; FMad(a,b,c)
  %939 = fadd fast float %938, %20
  %940 = fmul fast float %923, %31
  %941 = call float @dx.op.tertiary.f32(i32 46, float %924, float %27, float %940)  ; FMad(a,b,c)
  %942 = call float @dx.op.tertiary.f32(i32 46, float %908, float %23, float %941)  ; FMad(a,b,c)
  %943 = fadd fast float %942, %19
  %944 = fdiv fast float %943, %928
  %945 = fdiv fast float %939, %928
  %946 = fdiv fast float %935, %928
  %947 = fsub fast float %944, %16
  %948 = fsub fast float %945, %17
  %949 = fsub fast float %946, %18
  %950 = fmul fast float %947, %947
  %951 = fmul fast float %948, %948
  %952 = fadd fast float %951, %950
  %953 = fmul fast float %949, %949
  %954 = fadd fast float %952, %953
  %955 = call float @dx.op.unary.f32(i32 24, float %954)  ; Sqrt(value)
  %956 = fsub fast float %955, %8
  %957 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %956)  ; FMax(a,b)
  %958 = fcmp fast ogt float %38, 1.500000e+00
  br i1 %958, label %959, label %982

; <label>:959                                     ; preds = %931
  %960 = call float @dx.op.unary.f32(i32 6, float %948)  ; FAbs(value)
  %961 = fmul fast float %960, %10
  %962 = fcmp fast olt float %961, 0x3F50624DE0000000
  br i1 %962, label %963, label %966

; <label>:963                                     ; preds = %959
  %964 = fmul fast float %961, 5.000000e-01
  %965 = fsub fast float 1.000000e+00, %964
  br label %971

; <label>:966                                     ; preds = %959
  %967 = fmul fast float %961, 0xBFF7154760000000
  %968 = call float @dx.op.unary.f32(i32 21, float %967)  ; Exp(value)
  %969 = fsub fast float 1.000000e+00, %968
  %970 = fdiv fast float %969, %961
  br label %971

; <label>:971                                     ; preds = %966, %963
  %972 = phi float [ %965, %963 ], [ %970, %966 ]
  %973 = call float @dx.op.binary.f32(i32 36, float %945, float %17)  ; FMin(a,b)
  %974 = fsub fast float %973, %9
  %975 = fmul fast float %10, %974
  %976 = fsub fast float -0.000000e+00, %975
  %977 = call float @dx.op.binary.f32(i32 35, float %976, float -4.000000e+01)  ; FMax(a,b)
  %978 = call float @dx.op.binary.f32(i32 36, float %977, float 5.000000e+00)  ; FMin(a,b)
  %979 = fmul fast float %978, 0x3FF7154760000000
  %980 = call float @dx.op.unary.f32(i32 21, float %979)  ; Exp(value)
  %981 = fmul fast float %980, %972
  br label %982

; <label>:982                                     ; preds = %971, %931
  %983 = phi float [ %981, %971 ], [ 1.000000e+00, %931 ]
  %984 = fmul fast float %957, %15
  %985 = fmul fast float %984, %983
  %986 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %985)  ; FMin(a,b)
  %987 = fmul fast float %986, 0xBFF7154760000000
  %988 = call float @dx.op.unary.f32(i32 21, float %987)  ; Exp(value)
  %989 = fsub fast float 1.000000e+00, %988
  %990 = call float @dx.op.binary.f32(i32 36, float %11, float %989)  ; FMin(a,b)
  %991 = fsub fast float %12, %867
  %992 = fsub fast float %13, %868
  %993 = fsub fast float %14, %869
  %994 = fmul fast float %990, %991
  %995 = fmul fast float %990, %992
  %996 = fmul fast float %990, %993
  %997 = fadd fast float %994, %867
  %998 = fadd fast float %995, %868
  %999 = fadd fast float %996, %869
  br label %1000

; <label>:1000                                    ; preds = %982, %912, %906
  %1001 = phi float [ %997, %982 ], [ %867, %912 ], [ %867, %906 ]
  %1002 = phi float [ %998, %982 ], [ %868, %912 ], [ %868, %906 ]
  %1003 = phi float [ %999, %982 ], [ %869, %912 ], [ %869, %906 ]
  %1004 = fadd fast float %4, 1.000000e+00
  %1005 = fadd fast float %5, 1.000000e+00
  %1006 = fsub fast float 1.000000e+00, %4
  %1007 = fmul fast float %35, %1004
  %1008 = fmul fast float %35, %1005
  %1009 = fmul fast float %35, %1006
  %1010 = fmul fast float %1007, %1001
  %1011 = fmul fast float %1008, %1002
  %1012 = fmul fast float %1009, %1003
  %1013 = fcmp fast ult float %36, 5.000000e-01
  br i1 %1013, label %1039, label %1014

; <label>:1014                                    ; preds = %1000
  %1015 = fmul fast float %1010, 0x4004147AE0000000
  %1016 = fmul fast float %1011, 0x4004147AE0000000
  %1017 = fmul fast float %1012, 0x4004147AE0000000
  %1018 = fadd fast float %1015, 0x3F9EB851E0000000
  %1019 = fadd fast float %1016, 0x3F9EB851E0000000
  %1020 = fadd fast float %1017, 0x3F9EB851E0000000
  %1021 = fmul fast float %1018, %1010
  %1022 = fmul fast float %1019, %1011
  %1023 = fmul fast float %1020, %1012
  %1024 = fmul fast float %1010, 0x400370A3E0000000
  %1025 = fmul fast float %1011, 0x400370A3E0000000
  %1026 = fmul fast float %1012, 0x400370A3E0000000
  %1027 = fadd fast float %1024, 0x3FE2E147A0000000
  %1028 = fadd fast float %1025, 0x3FE2E147A0000000
  %1029 = fadd fast float %1026, 0x3FE2E147A0000000
  %1030 = fmul fast float %1027, %1010
  %1031 = fmul fast float %1028, %1011
  %1032 = fmul fast float %1029, %1012
  %1033 = fadd fast float %1030, 0x3FC1EB8520000000
  %1034 = fadd fast float %1031, 0x3FC1EB8520000000
  %1035 = fadd fast float %1032, 0x3FC1EB8520000000
  %1036 = fdiv fast float %1021, %1033
  %1037 = fdiv fast float %1022, %1034
  %1038 = fdiv fast float %1023, %1035
  br label %1039

; <label>:1039                                    ; preds = %1014, %1000
  %1040 = phi float [ %1036, %1014 ], [ %1010, %1000 ]
  %1041 = phi float [ %1037, %1014 ], [ %1011, %1000 ]
  %1042 = phi float [ %1038, %1014 ], [ %1012, %1000 ]
  %1043 = call float @dx.op.unary.f32(i32 7, float %1040)  ; Saturate(value)
  %1044 = call float @dx.op.unary.f32(i32 7, float %1041)  ; Saturate(value)
  %1045 = call float @dx.op.unary.f32(i32 7, float %1042)  ; Saturate(value)
  %1046 = call float @dx.op.dot3.f32(i32 55, float %1043, float %1044, float %1045, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1047 = fsub fast float %1043, %1046
  %1048 = fsub fast float %1044, %1046
  %1049 = fsub fast float %1045, %1046
  %1050 = fmul fast float %1047, %7
  %1051 = fmul fast float %1048, %7
  %1052 = fmul fast float %1049, %7
  %1053 = fadd fast float %1050, %1046
  %1054 = fadd fast float %1051, %1046
  %1055 = fadd fast float %1052, %1046
  %1056 = call float @dx.op.unary.f32(i32 7, float %1053)  ; Saturate(value)
  %1057 = call float @dx.op.unary.f32(i32 7, float %1054)  ; Saturate(value)
  %1058 = call float @dx.op.unary.f32(i32 7, float %1055)  ; Saturate(value)
  %1059 = fadd fast float %1056, 0xBFC70A3D80000000
  %1060 = fadd fast float %1057, 0xBFC70A3D80000000
  %1061 = fadd fast float %1058, 0xBFC70A3D80000000
  %1062 = fmul fast float %1059, %6
  %1063 = fmul fast float %1060, %6
  %1064 = fmul fast float %1061, %6
  %1065 = fadd fast float %1062, 0x3FC70A3D80000000
  %1066 = fadd fast float %1063, 0x3FC70A3D80000000
  %1067 = fadd fast float %1064, 0x3FC70A3D80000000
  %1068 = call float @dx.op.unary.f32(i32 7, float %1065)  ; Saturate(value)
  %1069 = call float @dx.op.unary.f32(i32 7, float %1066)  ; Saturate(value)
  %1070 = call float @dx.op.unary.f32(i32 7, float %1067)  ; Saturate(value)
  br label %1071

; <label>:1071                                    ; preds = %1039, %872
  %1072 = phi float [ %903, %872 ], [ %1068, %1039 ]
  %1073 = phi float [ %904, %872 ], [ %1069, %1039 ]
  %1074 = phi float [ %905, %872 ], [ %1070, %1039 ]
  %1075 = call float @dx.op.binary.f32(i32 36, float %860, float %1072)  ; FMin(a,b)
  %1076 = call float @dx.op.binary.f32(i32 36, float %861, float %1073)  ; FMin(a,b)
  %1077 = call float @dx.op.binary.f32(i32 36, float %862, float %1074)  ; FMin(a,b)
  %1078 = call float @dx.op.binary.f32(i32 36, float %434, float %646)  ; FMin(a,b)
  %1079 = call float @dx.op.binary.f32(i32 36, float %435, float %647)  ; FMin(a,b)
  %1080 = call float @dx.op.binary.f32(i32 36, float %436, float %648)  ; FMin(a,b)
  %1081 = call float @dx.op.binary.f32(i32 36, float %1078, float %1075)  ; FMin(a,b)
  %1082 = call float @dx.op.binary.f32(i32 36, float %1079, float %1076)  ; FMin(a,b)
  %1083 = call float @dx.op.binary.f32(i32 36, float %1080, float %1077)  ; FMin(a,b)
  %1084 = call float @dx.op.binary.f32(i32 36, float %216, float %1081)  ; FMin(a,b)
  %1085 = call float @dx.op.binary.f32(i32 36, float %217, float %1082)  ; FMin(a,b)
  %1086 = call float @dx.op.binary.f32(i32 36, float %218, float %1083)  ; FMin(a,b)
  %1087 = call float @dx.op.binary.f32(i32 35, float %860, float %1072)  ; FMax(a,b)
  %1088 = call float @dx.op.binary.f32(i32 35, float %861, float %1073)  ; FMax(a,b)
  %1089 = call float @dx.op.binary.f32(i32 35, float %862, float %1074)  ; FMax(a,b)
  %1090 = call float @dx.op.binary.f32(i32 35, float %434, float %646)  ; FMax(a,b)
  %1091 = call float @dx.op.binary.f32(i32 35, float %435, float %647)  ; FMax(a,b)
  %1092 = call float @dx.op.binary.f32(i32 35, float %436, float %648)  ; FMax(a,b)
  %1093 = call float @dx.op.binary.f32(i32 35, float %1090, float %1087)  ; FMax(a,b)
  %1094 = call float @dx.op.binary.f32(i32 35, float %1091, float %1088)  ; FMax(a,b)
  %1095 = call float @dx.op.binary.f32(i32 35, float %1092, float %1089)  ; FMax(a,b)
  %1096 = call float @dx.op.binary.f32(i32 35, float %216, float %1093)  ; FMax(a,b)
  %1097 = call float @dx.op.binary.f32(i32 35, float %217, float %1094)  ; FMax(a,b)
  %1098 = call float @dx.op.binary.f32(i32 35, float %218, float %1095)  ; FMax(a,b)
  %1099 = fsub fast float %1096, %1084
  %1100 = fsub fast float %1097, %1085
  %1101 = fsub fast float %1098, %1086
  %1102 = call float @dx.op.unary.f32(i32 6, float %1099)  ; FAbs(value)
  %1103 = call float @dx.op.unary.f32(i32 6, float %1100)  ; FAbs(value)
  %1104 = call float @dx.op.unary.f32(i32 6, float %1101)  ; FAbs(value)
  %1105 = call float @dx.op.binary.f32(i32 35, float %1103, float %1104)  ; FMax(a,b)
  %1106 = call float @dx.op.binary.f32(i32 35, float %1102, float %1105)  ; FMax(a,b)
  %1107 = call float @dx.op.binary.f32(i32 35, float %1097, float %1098)  ; FMax(a,b)
  %1108 = call float @dx.op.binary.f32(i32 35, float %1096, float %1107)  ; FMax(a,b)
  %1109 = fmul fast float %1108, 1.250000e-01
  %1110 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1109)  ; FMax(a,b)
  %1111 = fcmp fast ogt float %1106, %1110
  br i1 %1111, label %1112, label %1174

; <label>:1112                                    ; preds = %1071
  %1113 = fsub fast float %434, %646
  %1114 = fsub fast float %435, %647
  %1115 = fsub fast float %436, %648
  %1116 = call float @dx.op.unary.f32(i32 6, float %1113)  ; FAbs(value)
  %1117 = call float @dx.op.unary.f32(i32 6, float %1114)  ; FAbs(value)
  %1118 = call float @dx.op.unary.f32(i32 6, float %1115)  ; FAbs(value)
  %1119 = call float @dx.op.binary.f32(i32 35, float %1117, float %1118)  ; FMax(a,b)
  %1120 = call float @dx.op.binary.f32(i32 35, float %1116, float %1119)  ; FMax(a,b)
  %1121 = fsub fast float %860, %1072
  %1122 = fsub fast float %861, %1073
  %1123 = fsub fast float %862, %1074
  %1124 = call float @dx.op.unary.f32(i32 6, float %1121)  ; FAbs(value)
  %1125 = call float @dx.op.unary.f32(i32 6, float %1122)  ; FAbs(value)
  %1126 = call float @dx.op.unary.f32(i32 6, float %1123)  ; FAbs(value)
  %1127 = call float @dx.op.binary.f32(i32 35, float %1125, float %1126)  ; FMax(a,b)
  %1128 = call float @dx.op.binary.f32(i32 35, float %1124, float %1127)  ; FMax(a,b)
  %1129 = fcmp fast olt float %1120, %1128
  %1130 = select i1 %1129, float %434, float %860
  %1131 = select i1 %1129, float %435, float %861
  %1132 = select i1 %1129, float %436, float %862
  %1133 = select i1 %1129, float %646, float %1072
  %1134 = select i1 %1129, float %647, float %1073
  %1135 = select i1 %1129, float %648, float %1074
  %1136 = fsub fast float %216, %1133
  %1137 = fsub fast float %217, %1134
  %1138 = fsub fast float %218, %1135
  %1139 = fsub fast float %216, %1130
  %1140 = fsub fast float %217, %1131
  %1141 = fsub fast float %218, %1132
  %1142 = call float @dx.op.dot3.f32(i32 55, float %1139, float %1140, float %1141, float %1136, float %1137, float %1138)  ; Dot3(ax,ay,az,bx,by,bz)
  %1143 = fcmp fast ogt float %1142, 0.000000e+00
  br i1 %1143, label %1144, label %1156

; <label>:1144                                    ; preds = %1112
  %1145 = fsub fast float %1130, %1133
  %1146 = fsub fast float %1131, %1134
  %1147 = fsub fast float %1132, %1135
  %1148 = call float @dx.op.unary.f32(i32 6, float %1145)  ; FAbs(value)
  %1149 = call float @dx.op.unary.f32(i32 6, float %1146)  ; FAbs(value)
  %1150 = call float @dx.op.unary.f32(i32 6, float %1147)  ; FAbs(value)
  %1151 = call float @dx.op.binary.f32(i32 35, float %1149, float %1150)  ; FMax(a,b)
  %1152 = call float @dx.op.binary.f32(i32 35, float %1148, float %1151)  ; FMax(a,b)
  %1153 = fmul fast float %1106, 2.500000e-01
  %1154 = fcmp fast olt float %1152, %1153
  %1155 = select i1 %1154, float 5.000000e-01, float 1.000000e+00
  br label %1156

; <label>:1156                                    ; preds = %1144, %1112
  %1157 = phi float [ 1.000000e+00, %1112 ], [ %1155, %1144 ]
  %1158 = fmul fast float %1157, %3
  %1159 = fadd fast float %1130, %1133
  %1160 = fadd fast float %1131, %1134
  %1161 = fadd fast float %1132, %1135
  %1162 = fmul fast float %1159, 5.000000e-01
  %1163 = fmul fast float %1160, 5.000000e-01
  %1164 = fmul fast float %1161, 5.000000e-01
  %1165 = fsub fast float %1162, %216
  %1166 = fsub fast float %1163, %217
  %1167 = fsub fast float %1164, %218
  %1168 = fmul fast float %1158, %1165
  %1169 = fmul fast float %1158, %1166
  %1170 = fmul fast float %1158, %1167
  %1171 = fadd fast float %1168, %216
  %1172 = fadd fast float %1169, %217
  %1173 = fadd fast float %1170, %218
  br label %1174

; <label>:1174                                    ; preds = %1156, %1071, %187
  %1175 = phi float [ %1171, %1156 ], [ %216, %1071 ], [ %216, %187 ]
  %1176 = phi float [ %1172, %1156 ], [ %217, %1071 ], [ %217, %187 ]
  %1177 = phi float [ %1173, %1156 ], [ %218, %1071 ], [ %218, %187 ]
  %1178 = fcmp fast ogt float %1175, 0x3F69A5C380000000
  %1179 = fcmp fast ogt float %1176, 0x3F69A5C380000000
  %1180 = fcmp fast ogt float %1177, 0x3F69A5C380000000
  %1181 = select i1 %1178, float 0.000000e+00, float 1.000000e+00
  %1182 = select i1 %1179, float 0.000000e+00, float 1.000000e+00
  %1183 = select i1 %1180, float 0.000000e+00, float 1.000000e+00
  %1184 = fmul fast float %1175, 0x4029D70A40000000
  %1185 = fmul fast float %1176, 0x4029D70A40000000
  %1186 = fmul fast float %1177, 0x4029D70A40000000
  %1187 = call float @dx.op.binary.f32(i32 35, float %1175, float 0.000000e+00)  ; FMax(a,b)
  %1188 = call float @dx.op.binary.f32(i32 35, float %1176, float 0.000000e+00)  ; FMax(a,b)
  %1189 = call float @dx.op.binary.f32(i32 35, float %1177, float 0.000000e+00)  ; FMax(a,b)
  %1190 = call float @dx.op.unary.f32(i32 23, float %1187)  ; Log(value)
  %1191 = call float @dx.op.unary.f32(i32 23, float %1188)  ; Log(value)
  %1192 = call float @dx.op.unary.f32(i32 23, float %1189)  ; Log(value)
  %1193 = fmul fast float %1190, 0x3FDAAAAAA0000000
  %1194 = fmul fast float %1191, 0x3FDAAAAAA0000000
  %1195 = fmul fast float %1192, 0x3FDAAAAAA0000000
  %1196 = call float @dx.op.unary.f32(i32 21, float %1193)  ; Exp(value)
  %1197 = call float @dx.op.unary.f32(i32 21, float %1194)  ; Exp(value)
  %1198 = call float @dx.op.unary.f32(i32 21, float %1195)  ; Exp(value)
  %1199 = fmul fast float %1196, 0x3FF0E147A0000000
  %1200 = fmul fast float %1197, 0x3FF0E147A0000000
  %1201 = fmul fast float %1198, 0x3FF0E147A0000000
  %1202 = fadd fast float %1199, 0xBFAC28F5C0000000
  %1203 = fadd fast float %1200, 0xBFAC28F5C0000000
  %1204 = fadd fast float %1201, 0xBFAC28F5C0000000
  %1205 = fsub fast float %1184, %1202
  %1206 = fsub fast float %1185, %1203
  %1207 = fsub fast float %1186, %1204
  %1208 = fmul fast float %1205, %1181
  %1209 = fmul fast float %1206, %1182
  %1210 = fmul fast float %1207, %1183
  %1211 = fadd fast float %1208, %1202
  %1212 = fadd fast float %1209, %1203
  %1213 = fadd fast float %1210, %1204
  br label %1214

; <label>:1214                                    ; preds = %1174, %52
  %1215 = phi float [ %47, %52 ], [ %1211, %1174 ]
  %1216 = phi float [ %48, %52 ], [ %1212, %1174 ]
  %1217 = phi float [ %49, %52 ], [ %1213, %1174 ]
  %1218 = phi float [ %53, %52 ], [ %50, %1174 ]
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %1215)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %1216)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %1217)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %1218)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 0, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !38, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, !37}
!36 = !{i32 9}
!37 = !{i32 3, i32 1}
!38 = !{!39}
!39 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
