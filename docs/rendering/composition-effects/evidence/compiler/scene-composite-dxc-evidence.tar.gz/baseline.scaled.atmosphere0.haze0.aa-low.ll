;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xy  
; TEXCOORD                 1   xyzw        2     NONE   float       
; TEXCOORD                 2   xyzw        3     NONE   float       
; TEXCOORD                 3   xyzw        4     NONE   float       
; TEXCOORD                 4   xyzw        5     NONE   float       
; TEXCOORD                 5   xyzw        6     NONE   float       
; TEXCOORD                 6   xyzw        7     NONE   float       
; TEXCOORD                 7   xyzw        8     NONE   float       
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float    yz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: 1173dcef2a4861787935af83b762fca6
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %14 = extractvalue %dx.types.Dimensions %13, 0
  %15 = extractvalue %dx.types.Dimensions %13, 1
  %16 = uitofp i32 %14 to float
  %17 = uitofp i32 %15 to float
  %18 = fmul fast float %16, %11
  %19 = fmul fast float %17, %12
  %20 = fdiv fast float %18, %3
  %21 = fdiv fast float %19, %4
  %22 = fadd fast float %20, -5.000000e-01
  %23 = fadd fast float %21, -5.000000e-01
  %24 = call float @dx.op.unary.f32(i32 27, float %22)  ; Round_ni(value)
  %25 = call float @dx.op.unary.f32(i32 27, float %23)  ; Round_ni(value)
  %26 = fptosi float %24 to i32
  %27 = fptosi float %25 to i32
  %28 = call float @dx.op.unary.f32(i32 22, float %22)  ; Frc(value)
  %29 = call float @dx.op.unary.f32(i32 22, float %23)  ; Frc(value)
  %30 = add i32 %14, -1
  %31 = add i32 %15, -1
  %32 = call i32 @dx.op.binary.i32(i32 37, i32 %26, i32 0)  ; IMax(a,b)
  %33 = call i32 @dx.op.binary.i32(i32 37, i32 %27, i32 0)  ; IMax(a,b)
  %34 = call i32 @dx.op.binary.i32(i32 38, i32 %32, i32 %30)  ; IMin(a,b)
  %35 = call i32 @dx.op.binary.i32(i32 38, i32 %33, i32 %31)  ; IMin(a,b)
  %36 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %34, i32 %35, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %37 = extractvalue %dx.types.ResRet.f32 %36, 0
  %38 = extractvalue %dx.types.ResRet.f32 %36, 1
  %39 = extractvalue %dx.types.ResRet.f32 %36, 2
  %40 = extractvalue %dx.types.ResRet.f32 %36, 3
  %41 = fcmp fast olt float %40, 0.000000e+00
  br i1 %41, label %42, label %44

; <label>:42                                      ; preds = %0
  %43 = fsub fast float -1.000000e+00, %40
  br label %714

; <label>:44                                      ; preds = %0
  %45 = fadd fast float %5, 1.000000e+00
  %46 = fadd fast float %6, 1.000000e+00
  %47 = fsub fast float 1.000000e+00, %5
  %48 = fmul fast float %9, %45
  %49 = fmul fast float %9, %46
  %50 = fmul fast float %9, %47
  %51 = fmul fast float %48, %37
  %52 = fmul fast float %49, %38
  %53 = fmul fast float %50, %39
  %54 = fcmp fast ult float %10, 5.000000e-01
  br i1 %54, label %80, label %55

; <label>:55                                      ; preds = %44
  %56 = fmul fast float %51, 0x4004147AE0000000
  %57 = fmul fast float %52, 0x4004147AE0000000
  %58 = fmul fast float %53, 0x4004147AE0000000
  %59 = fadd fast float %56, 0x3F9EB851E0000000
  %60 = fadd fast float %57, 0x3F9EB851E0000000
  %61 = fadd fast float %58, 0x3F9EB851E0000000
  %62 = fmul fast float %59, %51
  %63 = fmul fast float %60, %52
  %64 = fmul fast float %61, %53
  %65 = fmul fast float %51, 0x400370A3E0000000
  %66 = fmul fast float %52, 0x400370A3E0000000
  %67 = fmul fast float %53, 0x400370A3E0000000
  %68 = fadd fast float %65, 0x3FE2E147A0000000
  %69 = fadd fast float %66, 0x3FE2E147A0000000
  %70 = fadd fast float %67, 0x3FE2E147A0000000
  %71 = fmul fast float %68, %51
  %72 = fmul fast float %69, %52
  %73 = fmul fast float %70, %53
  %74 = fadd fast float %71, 0x3FC1EB8520000000
  %75 = fadd fast float %72, 0x3FC1EB8520000000
  %76 = fadd fast float %73, 0x3FC1EB8520000000
  %77 = fdiv fast float %62, %74
  %78 = fdiv fast float %63, %75
  %79 = fdiv fast float %64, %76
  br label %80

; <label>:80                                      ; preds = %55, %44
  %81 = phi float [ %77, %55 ], [ %51, %44 ]
  %82 = phi float [ %78, %55 ], [ %52, %44 ]
  %83 = phi float [ %79, %55 ], [ %53, %44 ]
  %84 = call float @dx.op.unary.f32(i32 7, float %81)  ; Saturate(value)
  %85 = call float @dx.op.unary.f32(i32 7, float %82)  ; Saturate(value)
  %86 = call float @dx.op.unary.f32(i32 7, float %83)  ; Saturate(value)
  %87 = call float @dx.op.dot3.f32(i32 55, float %84, float %85, float %86, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %88 = fsub fast float %84, %87
  %89 = fsub fast float %85, %87
  %90 = fsub fast float %86, %87
  %91 = fmul fast float %88, %8
  %92 = fmul fast float %89, %8
  %93 = fmul fast float %90, %8
  %94 = fadd fast float %91, %87
  %95 = fadd fast float %92, %87
  %96 = fadd fast float %93, %87
  %97 = call float @dx.op.unary.f32(i32 7, float %94)  ; Saturate(value)
  %98 = call float @dx.op.unary.f32(i32 7, float %95)  ; Saturate(value)
  %99 = call float @dx.op.unary.f32(i32 7, float %96)  ; Saturate(value)
  %100 = fadd fast float %97, 0xBFC70A3D80000000
  %101 = fadd fast float %98, 0xBFC70A3D80000000
  %102 = fadd fast float %99, 0xBFC70A3D80000000
  %103 = fmul fast float %100, %7
  %104 = fmul fast float %101, %7
  %105 = fmul fast float %102, %7
  %106 = fadd fast float %103, 0x3FC70A3D80000000
  %107 = fadd fast float %104, 0x3FC70A3D80000000
  %108 = fadd fast float %105, 0x3FC70A3D80000000
  %109 = call float @dx.op.unary.f32(i32 7, float %106)  ; Saturate(value)
  %110 = call float @dx.op.unary.f32(i32 7, float %107)  ; Saturate(value)
  %111 = call float @dx.op.unary.f32(i32 7, float %108)  ; Saturate(value)
  %112 = add i32 %35, -1
  %113 = call i32 @dx.op.binary.i32(i32 37, i32 %34, i32 0)  ; IMax(a,b)
  %114 = call i32 @dx.op.binary.i32(i32 37, i32 %112, i32 0)  ; IMax(a,b)
  %115 = call i32 @dx.op.binary.i32(i32 38, i32 %113, i32 %30)  ; IMin(a,b)
  %116 = call i32 @dx.op.binary.i32(i32 38, i32 %114, i32 %31)  ; IMin(a,b)
  %117 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %115, i32 %116, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %118 = extractvalue %dx.types.ResRet.f32 %117, 0
  %119 = extractvalue %dx.types.ResRet.f32 %117, 1
  %120 = extractvalue %dx.types.ResRet.f32 %117, 2
  %121 = extractvalue %dx.types.ResRet.f32 %117, 3
  %122 = fcmp fast olt float %121, 0.000000e+00
  br i1 %122, label %123, label %157

; <label>:123                                     ; preds = %80
  %124 = fcmp fast ogt float %118, 0x3FA4B5DCC0000000
  %125 = fcmp fast ogt float %119, 0x3FA4B5DCC0000000
  %126 = fcmp fast ogt float %120, 0x3FA4B5DCC0000000
  %127 = select i1 %124, float 0.000000e+00, float 1.000000e+00
  %128 = select i1 %125, float 0.000000e+00, float 1.000000e+00
  %129 = select i1 %126, float 0.000000e+00, float 1.000000e+00
  %130 = fmul fast float %118, 0x3FB3D07220000000
  %131 = fmul fast float %119, 0x3FB3D07220000000
  %132 = fmul fast float %120, 0x3FB3D07220000000
  %133 = fadd fast float %118, 0x3FAC28F5C0000000
  %134 = fadd fast float %119, 0x3FAC28F5C0000000
  %135 = fadd fast float %120, 0x3FAC28F5C0000000
  %136 = fmul fast float %133, 0x3FEE54EDE0000000
  %137 = fmul fast float %134, 0x3FEE54EDE0000000
  %138 = fmul fast float %135, 0x3FEE54EDE0000000
  %139 = call float @dx.op.unary.f32(i32 23, float %136)  ; Log(value)
  %140 = call float @dx.op.unary.f32(i32 23, float %137)  ; Log(value)
  %141 = call float @dx.op.unary.f32(i32 23, float %138)  ; Log(value)
  %142 = fmul fast float %139, 0x4003333340000000
  %143 = fmul fast float %140, 0x4003333340000000
  %144 = fmul fast float %141, 0x4003333340000000
  %145 = call float @dx.op.unary.f32(i32 21, float %142)  ; Exp(value)
  %146 = call float @dx.op.unary.f32(i32 21, float %143)  ; Exp(value)
  %147 = call float @dx.op.unary.f32(i32 21, float %144)  ; Exp(value)
  %148 = fsub fast float %130, %145
  %149 = fsub fast float %131, %146
  %150 = fsub fast float %132, %147
  %151 = fmul fast float %148, %127
  %152 = fmul fast float %149, %128
  %153 = fmul fast float %150, %129
  %154 = fadd fast float %151, %145
  %155 = fadd fast float %152, %146
  %156 = fadd fast float %153, %147
  br label %225

; <label>:157                                     ; preds = %80
  %158 = fadd fast float %5, 1.000000e+00
  %159 = fadd fast float %6, 1.000000e+00
  %160 = fsub fast float 1.000000e+00, %5
  %161 = fmul fast float %9, %158
  %162 = fmul fast float %9, %159
  %163 = fmul fast float %9, %160
  %164 = fmul fast float %161, %118
  %165 = fmul fast float %162, %119
  %166 = fmul fast float %163, %120
  %167 = fcmp fast ult float %10, 5.000000e-01
  br i1 %167, label %193, label %168

; <label>:168                                     ; preds = %157
  %169 = fmul fast float %164, 0x4004147AE0000000
  %170 = fmul fast float %165, 0x4004147AE0000000
  %171 = fmul fast float %166, 0x4004147AE0000000
  %172 = fadd fast float %169, 0x3F9EB851E0000000
  %173 = fadd fast float %170, 0x3F9EB851E0000000
  %174 = fadd fast float %171, 0x3F9EB851E0000000
  %175 = fmul fast float %172, %164
  %176 = fmul fast float %173, %165
  %177 = fmul fast float %174, %166
  %178 = fmul fast float %164, 0x400370A3E0000000
  %179 = fmul fast float %165, 0x400370A3E0000000
  %180 = fmul fast float %166, 0x400370A3E0000000
  %181 = fadd fast float %178, 0x3FE2E147A0000000
  %182 = fadd fast float %179, 0x3FE2E147A0000000
  %183 = fadd fast float %180, 0x3FE2E147A0000000
  %184 = fmul fast float %181, %164
  %185 = fmul fast float %182, %165
  %186 = fmul fast float %183, %166
  %187 = fadd fast float %184, 0x3FC1EB8520000000
  %188 = fadd fast float %185, 0x3FC1EB8520000000
  %189 = fadd fast float %186, 0x3FC1EB8520000000
  %190 = fdiv fast float %175, %187
  %191 = fdiv fast float %176, %188
  %192 = fdiv fast float %177, %189
  br label %193

; <label>:193                                     ; preds = %168, %157
  %194 = phi float [ %190, %168 ], [ %164, %157 ]
  %195 = phi float [ %191, %168 ], [ %165, %157 ]
  %196 = phi float [ %192, %168 ], [ %166, %157 ]
  %197 = call float @dx.op.unary.f32(i32 7, float %194)  ; Saturate(value)
  %198 = call float @dx.op.unary.f32(i32 7, float %195)  ; Saturate(value)
  %199 = call float @dx.op.unary.f32(i32 7, float %196)  ; Saturate(value)
  %200 = call float @dx.op.dot3.f32(i32 55, float %197, float %198, float %199, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %201 = fsub fast float %197, %200
  %202 = fsub fast float %198, %200
  %203 = fsub fast float %199, %200
  %204 = fmul fast float %201, %8
  %205 = fmul fast float %202, %8
  %206 = fmul fast float %203, %8
  %207 = fadd fast float %204, %200
  %208 = fadd fast float %205, %200
  %209 = fadd fast float %206, %200
  %210 = call float @dx.op.unary.f32(i32 7, float %207)  ; Saturate(value)
  %211 = call float @dx.op.unary.f32(i32 7, float %208)  ; Saturate(value)
  %212 = call float @dx.op.unary.f32(i32 7, float %209)  ; Saturate(value)
  %213 = fadd fast float %210, 0xBFC70A3D80000000
  %214 = fadd fast float %211, 0xBFC70A3D80000000
  %215 = fadd fast float %212, 0xBFC70A3D80000000
  %216 = fmul fast float %213, %7
  %217 = fmul fast float %214, %7
  %218 = fmul fast float %215, %7
  %219 = fadd fast float %216, 0x3FC70A3D80000000
  %220 = fadd fast float %217, 0x3FC70A3D80000000
  %221 = fadd fast float %218, 0x3FC70A3D80000000
  %222 = call float @dx.op.unary.f32(i32 7, float %219)  ; Saturate(value)
  %223 = call float @dx.op.unary.f32(i32 7, float %220)  ; Saturate(value)
  %224 = call float @dx.op.unary.f32(i32 7, float %221)  ; Saturate(value)
  br label %225

; <label>:225                                     ; preds = %193, %123
  %226 = phi float [ %154, %123 ], [ %222, %193 ]
  %227 = phi float [ %155, %123 ], [ %223, %193 ]
  %228 = phi float [ %156, %123 ], [ %224, %193 ]
  %229 = add i32 %35, 1
  %230 = call i32 @dx.op.binary.i32(i32 37, i32 %229, i32 0)  ; IMax(a,b)
  %231 = call i32 @dx.op.binary.i32(i32 38, i32 %230, i32 %31)  ; IMin(a,b)
  %232 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %115, i32 %231, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %233 = extractvalue %dx.types.ResRet.f32 %232, 0
  %234 = extractvalue %dx.types.ResRet.f32 %232, 1
  %235 = extractvalue %dx.types.ResRet.f32 %232, 2
  %236 = extractvalue %dx.types.ResRet.f32 %232, 3
  %237 = fcmp fast olt float %236, 0.000000e+00
  br i1 %237, label %238, label %272

; <label>:238                                     ; preds = %225
  %239 = fcmp fast ogt float %233, 0x3FA4B5DCC0000000
  %240 = fcmp fast ogt float %234, 0x3FA4B5DCC0000000
  %241 = fcmp fast ogt float %235, 0x3FA4B5DCC0000000
  %242 = select i1 %239, float 0.000000e+00, float 1.000000e+00
  %243 = select i1 %240, float 0.000000e+00, float 1.000000e+00
  %244 = select i1 %241, float 0.000000e+00, float 1.000000e+00
  %245 = fmul fast float %233, 0x3FB3D07220000000
  %246 = fmul fast float %234, 0x3FB3D07220000000
  %247 = fmul fast float %235, 0x3FB3D07220000000
  %248 = fadd fast float %233, 0x3FAC28F5C0000000
  %249 = fadd fast float %234, 0x3FAC28F5C0000000
  %250 = fadd fast float %235, 0x3FAC28F5C0000000
  %251 = fmul fast float %248, 0x3FEE54EDE0000000
  %252 = fmul fast float %249, 0x3FEE54EDE0000000
  %253 = fmul fast float %250, 0x3FEE54EDE0000000
  %254 = call float @dx.op.unary.f32(i32 23, float %251)  ; Log(value)
  %255 = call float @dx.op.unary.f32(i32 23, float %252)  ; Log(value)
  %256 = call float @dx.op.unary.f32(i32 23, float %253)  ; Log(value)
  %257 = fmul fast float %254, 0x4003333340000000
  %258 = fmul fast float %255, 0x4003333340000000
  %259 = fmul fast float %256, 0x4003333340000000
  %260 = call float @dx.op.unary.f32(i32 21, float %257)  ; Exp(value)
  %261 = call float @dx.op.unary.f32(i32 21, float %258)  ; Exp(value)
  %262 = call float @dx.op.unary.f32(i32 21, float %259)  ; Exp(value)
  %263 = fsub fast float %245, %260
  %264 = fsub fast float %246, %261
  %265 = fsub fast float %247, %262
  %266 = fmul fast float %263, %242
  %267 = fmul fast float %264, %243
  %268 = fmul fast float %265, %244
  %269 = fadd fast float %266, %260
  %270 = fadd fast float %267, %261
  %271 = fadd fast float %268, %262
  br label %340

; <label>:272                                     ; preds = %225
  %273 = fadd fast float %5, 1.000000e+00
  %274 = fadd fast float %6, 1.000000e+00
  %275 = fsub fast float 1.000000e+00, %5
  %276 = fmul fast float %9, %273
  %277 = fmul fast float %9, %274
  %278 = fmul fast float %9, %275
  %279 = fmul fast float %276, %233
  %280 = fmul fast float %277, %234
  %281 = fmul fast float %278, %235
  %282 = fcmp fast ult float %10, 5.000000e-01
  br i1 %282, label %308, label %283

; <label>:283                                     ; preds = %272
  %284 = fmul fast float %279, 0x4004147AE0000000
  %285 = fmul fast float %280, 0x4004147AE0000000
  %286 = fmul fast float %281, 0x4004147AE0000000
  %287 = fadd fast float %284, 0x3F9EB851E0000000
  %288 = fadd fast float %285, 0x3F9EB851E0000000
  %289 = fadd fast float %286, 0x3F9EB851E0000000
  %290 = fmul fast float %287, %279
  %291 = fmul fast float %288, %280
  %292 = fmul fast float %289, %281
  %293 = fmul fast float %279, 0x400370A3E0000000
  %294 = fmul fast float %280, 0x400370A3E0000000
  %295 = fmul fast float %281, 0x400370A3E0000000
  %296 = fadd fast float %293, 0x3FE2E147A0000000
  %297 = fadd fast float %294, 0x3FE2E147A0000000
  %298 = fadd fast float %295, 0x3FE2E147A0000000
  %299 = fmul fast float %296, %279
  %300 = fmul fast float %297, %280
  %301 = fmul fast float %298, %281
  %302 = fadd fast float %299, 0x3FC1EB8520000000
  %303 = fadd fast float %300, 0x3FC1EB8520000000
  %304 = fadd fast float %301, 0x3FC1EB8520000000
  %305 = fdiv fast float %290, %302
  %306 = fdiv fast float %291, %303
  %307 = fdiv fast float %292, %304
  br label %308

; <label>:308                                     ; preds = %283, %272
  %309 = phi float [ %305, %283 ], [ %279, %272 ]
  %310 = phi float [ %306, %283 ], [ %280, %272 ]
  %311 = phi float [ %307, %283 ], [ %281, %272 ]
  %312 = call float @dx.op.unary.f32(i32 7, float %309)  ; Saturate(value)
  %313 = call float @dx.op.unary.f32(i32 7, float %310)  ; Saturate(value)
  %314 = call float @dx.op.unary.f32(i32 7, float %311)  ; Saturate(value)
  %315 = call float @dx.op.dot3.f32(i32 55, float %312, float %313, float %314, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %316 = fsub fast float %312, %315
  %317 = fsub fast float %313, %315
  %318 = fsub fast float %314, %315
  %319 = fmul fast float %316, %8
  %320 = fmul fast float %317, %8
  %321 = fmul fast float %318, %8
  %322 = fadd fast float %319, %315
  %323 = fadd fast float %320, %315
  %324 = fadd fast float %321, %315
  %325 = call float @dx.op.unary.f32(i32 7, float %322)  ; Saturate(value)
  %326 = call float @dx.op.unary.f32(i32 7, float %323)  ; Saturate(value)
  %327 = call float @dx.op.unary.f32(i32 7, float %324)  ; Saturate(value)
  %328 = fadd fast float %325, 0xBFC70A3D80000000
  %329 = fadd fast float %326, 0xBFC70A3D80000000
  %330 = fadd fast float %327, 0xBFC70A3D80000000
  %331 = fmul fast float %328, %7
  %332 = fmul fast float %329, %7
  %333 = fmul fast float %330, %7
  %334 = fadd fast float %331, 0x3FC70A3D80000000
  %335 = fadd fast float %332, 0x3FC70A3D80000000
  %336 = fadd fast float %333, 0x3FC70A3D80000000
  %337 = call float @dx.op.unary.f32(i32 7, float %334)  ; Saturate(value)
  %338 = call float @dx.op.unary.f32(i32 7, float %335)  ; Saturate(value)
  %339 = call float @dx.op.unary.f32(i32 7, float %336)  ; Saturate(value)
  br label %340

; <label>:340                                     ; preds = %308, %238
  %341 = phi float [ %269, %238 ], [ %337, %308 ]
  %342 = phi float [ %270, %238 ], [ %338, %308 ]
  %343 = phi float [ %271, %238 ], [ %339, %308 ]
  %344 = add i32 %34, -1
  %345 = call i32 @dx.op.binary.i32(i32 37, i32 %344, i32 0)  ; IMax(a,b)
  %346 = call i32 @dx.op.binary.i32(i32 37, i32 %35, i32 0)  ; IMax(a,b)
  %347 = call i32 @dx.op.binary.i32(i32 38, i32 %345, i32 %30)  ; IMin(a,b)
  %348 = call i32 @dx.op.binary.i32(i32 38, i32 %346, i32 %31)  ; IMin(a,b)
  %349 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %347, i32 %348, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %350 = extractvalue %dx.types.ResRet.f32 %349, 0
  %351 = extractvalue %dx.types.ResRet.f32 %349, 1
  %352 = extractvalue %dx.types.ResRet.f32 %349, 2
  %353 = extractvalue %dx.types.ResRet.f32 %349, 3
  %354 = fcmp fast olt float %353, 0.000000e+00
  br i1 %354, label %355, label %389

; <label>:355                                     ; preds = %340
  %356 = fcmp fast ogt float %350, 0x3FA4B5DCC0000000
  %357 = fcmp fast ogt float %351, 0x3FA4B5DCC0000000
  %358 = fcmp fast ogt float %352, 0x3FA4B5DCC0000000
  %359 = select i1 %356, float 0.000000e+00, float 1.000000e+00
  %360 = select i1 %357, float 0.000000e+00, float 1.000000e+00
  %361 = select i1 %358, float 0.000000e+00, float 1.000000e+00
  %362 = fmul fast float %350, 0x3FB3D07220000000
  %363 = fmul fast float %351, 0x3FB3D07220000000
  %364 = fmul fast float %352, 0x3FB3D07220000000
  %365 = fadd fast float %350, 0x3FAC28F5C0000000
  %366 = fadd fast float %351, 0x3FAC28F5C0000000
  %367 = fadd fast float %352, 0x3FAC28F5C0000000
  %368 = fmul fast float %365, 0x3FEE54EDE0000000
  %369 = fmul fast float %366, 0x3FEE54EDE0000000
  %370 = fmul fast float %367, 0x3FEE54EDE0000000
  %371 = call float @dx.op.unary.f32(i32 23, float %368)  ; Log(value)
  %372 = call float @dx.op.unary.f32(i32 23, float %369)  ; Log(value)
  %373 = call float @dx.op.unary.f32(i32 23, float %370)  ; Log(value)
  %374 = fmul fast float %371, 0x4003333340000000
  %375 = fmul fast float %372, 0x4003333340000000
  %376 = fmul fast float %373, 0x4003333340000000
  %377 = call float @dx.op.unary.f32(i32 21, float %374)  ; Exp(value)
  %378 = call float @dx.op.unary.f32(i32 21, float %375)  ; Exp(value)
  %379 = call float @dx.op.unary.f32(i32 21, float %376)  ; Exp(value)
  %380 = fsub fast float %362, %377
  %381 = fsub fast float %363, %378
  %382 = fsub fast float %364, %379
  %383 = fmul fast float %380, %359
  %384 = fmul fast float %381, %360
  %385 = fmul fast float %382, %361
  %386 = fadd fast float %383, %377
  %387 = fadd fast float %384, %378
  %388 = fadd fast float %385, %379
  br label %457

; <label>:389                                     ; preds = %340
  %390 = fadd fast float %5, 1.000000e+00
  %391 = fadd fast float %6, 1.000000e+00
  %392 = fsub fast float 1.000000e+00, %5
  %393 = fmul fast float %9, %390
  %394 = fmul fast float %9, %391
  %395 = fmul fast float %9, %392
  %396 = fmul fast float %393, %350
  %397 = fmul fast float %394, %351
  %398 = fmul fast float %395, %352
  %399 = fcmp fast ult float %10, 5.000000e-01
  br i1 %399, label %425, label %400

; <label>:400                                     ; preds = %389
  %401 = fmul fast float %396, 0x4004147AE0000000
  %402 = fmul fast float %397, 0x4004147AE0000000
  %403 = fmul fast float %398, 0x4004147AE0000000
  %404 = fadd fast float %401, 0x3F9EB851E0000000
  %405 = fadd fast float %402, 0x3F9EB851E0000000
  %406 = fadd fast float %403, 0x3F9EB851E0000000
  %407 = fmul fast float %404, %396
  %408 = fmul fast float %405, %397
  %409 = fmul fast float %406, %398
  %410 = fmul fast float %396, 0x400370A3E0000000
  %411 = fmul fast float %397, 0x400370A3E0000000
  %412 = fmul fast float %398, 0x400370A3E0000000
  %413 = fadd fast float %410, 0x3FE2E147A0000000
  %414 = fadd fast float %411, 0x3FE2E147A0000000
  %415 = fadd fast float %412, 0x3FE2E147A0000000
  %416 = fmul fast float %413, %396
  %417 = fmul fast float %414, %397
  %418 = fmul fast float %415, %398
  %419 = fadd fast float %416, 0x3FC1EB8520000000
  %420 = fadd fast float %417, 0x3FC1EB8520000000
  %421 = fadd fast float %418, 0x3FC1EB8520000000
  %422 = fdiv fast float %407, %419
  %423 = fdiv fast float %408, %420
  %424 = fdiv fast float %409, %421
  br label %425

; <label>:425                                     ; preds = %400, %389
  %426 = phi float [ %422, %400 ], [ %396, %389 ]
  %427 = phi float [ %423, %400 ], [ %397, %389 ]
  %428 = phi float [ %424, %400 ], [ %398, %389 ]
  %429 = call float @dx.op.unary.f32(i32 7, float %426)  ; Saturate(value)
  %430 = call float @dx.op.unary.f32(i32 7, float %427)  ; Saturate(value)
  %431 = call float @dx.op.unary.f32(i32 7, float %428)  ; Saturate(value)
  %432 = call float @dx.op.dot3.f32(i32 55, float %429, float %430, float %431, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %433 = fsub fast float %429, %432
  %434 = fsub fast float %430, %432
  %435 = fsub fast float %431, %432
  %436 = fmul fast float %433, %8
  %437 = fmul fast float %434, %8
  %438 = fmul fast float %435, %8
  %439 = fadd fast float %436, %432
  %440 = fadd fast float %437, %432
  %441 = fadd fast float %438, %432
  %442 = call float @dx.op.unary.f32(i32 7, float %439)  ; Saturate(value)
  %443 = call float @dx.op.unary.f32(i32 7, float %440)  ; Saturate(value)
  %444 = call float @dx.op.unary.f32(i32 7, float %441)  ; Saturate(value)
  %445 = fadd fast float %442, 0xBFC70A3D80000000
  %446 = fadd fast float %443, 0xBFC70A3D80000000
  %447 = fadd fast float %444, 0xBFC70A3D80000000
  %448 = fmul fast float %445, %7
  %449 = fmul fast float %446, %7
  %450 = fmul fast float %447, %7
  %451 = fadd fast float %448, 0x3FC70A3D80000000
  %452 = fadd fast float %449, 0x3FC70A3D80000000
  %453 = fadd fast float %450, 0x3FC70A3D80000000
  %454 = call float @dx.op.unary.f32(i32 7, float %451)  ; Saturate(value)
  %455 = call float @dx.op.unary.f32(i32 7, float %452)  ; Saturate(value)
  %456 = call float @dx.op.unary.f32(i32 7, float %453)  ; Saturate(value)
  br label %457

; <label>:457                                     ; preds = %425, %355
  %458 = phi float [ %386, %355 ], [ %454, %425 ]
  %459 = phi float [ %387, %355 ], [ %455, %425 ]
  %460 = phi float [ %388, %355 ], [ %456, %425 ]
  %461 = add i32 %34, 1
  %462 = call i32 @dx.op.binary.i32(i32 37, i32 %461, i32 0)  ; IMax(a,b)
  %463 = call i32 @dx.op.binary.i32(i32 38, i32 %462, i32 %30)  ; IMin(a,b)
  %464 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %463, i32 %348, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %465 = extractvalue %dx.types.ResRet.f32 %464, 0
  %466 = extractvalue %dx.types.ResRet.f32 %464, 1
  %467 = extractvalue %dx.types.ResRet.f32 %464, 2
  %468 = extractvalue %dx.types.ResRet.f32 %464, 3
  %469 = fcmp fast olt float %468, 0.000000e+00
  br i1 %469, label %470, label %504

; <label>:470                                     ; preds = %457
  %471 = fcmp fast ogt float %465, 0x3FA4B5DCC0000000
  %472 = fcmp fast ogt float %466, 0x3FA4B5DCC0000000
  %473 = fcmp fast ogt float %467, 0x3FA4B5DCC0000000
  %474 = select i1 %471, float 0.000000e+00, float 1.000000e+00
  %475 = select i1 %472, float 0.000000e+00, float 1.000000e+00
  %476 = select i1 %473, float 0.000000e+00, float 1.000000e+00
  %477 = fmul fast float %465, 0x3FB3D07220000000
  %478 = fmul fast float %466, 0x3FB3D07220000000
  %479 = fmul fast float %467, 0x3FB3D07220000000
  %480 = fadd fast float %465, 0x3FAC28F5C0000000
  %481 = fadd fast float %466, 0x3FAC28F5C0000000
  %482 = fadd fast float %467, 0x3FAC28F5C0000000
  %483 = fmul fast float %480, 0x3FEE54EDE0000000
  %484 = fmul fast float %481, 0x3FEE54EDE0000000
  %485 = fmul fast float %482, 0x3FEE54EDE0000000
  %486 = call float @dx.op.unary.f32(i32 23, float %483)  ; Log(value)
  %487 = call float @dx.op.unary.f32(i32 23, float %484)  ; Log(value)
  %488 = call float @dx.op.unary.f32(i32 23, float %485)  ; Log(value)
  %489 = fmul fast float %486, 0x4003333340000000
  %490 = fmul fast float %487, 0x4003333340000000
  %491 = fmul fast float %488, 0x4003333340000000
  %492 = call float @dx.op.unary.f32(i32 21, float %489)  ; Exp(value)
  %493 = call float @dx.op.unary.f32(i32 21, float %490)  ; Exp(value)
  %494 = call float @dx.op.unary.f32(i32 21, float %491)  ; Exp(value)
  %495 = fsub fast float %477, %492
  %496 = fsub fast float %478, %493
  %497 = fsub fast float %479, %494
  %498 = fmul fast float %495, %474
  %499 = fmul fast float %496, %475
  %500 = fmul fast float %497, %476
  %501 = fadd fast float %498, %492
  %502 = fadd fast float %499, %493
  %503 = fadd fast float %500, %494
  br label %572

; <label>:504                                     ; preds = %457
  %505 = fadd fast float %5, 1.000000e+00
  %506 = fadd fast float %6, 1.000000e+00
  %507 = fsub fast float 1.000000e+00, %5
  %508 = fmul fast float %9, %505
  %509 = fmul fast float %9, %506
  %510 = fmul fast float %9, %507
  %511 = fmul fast float %508, %465
  %512 = fmul fast float %509, %466
  %513 = fmul fast float %510, %467
  %514 = fcmp fast ult float %10, 5.000000e-01
  br i1 %514, label %540, label %515

; <label>:515                                     ; preds = %504
  %516 = fmul fast float %511, 0x4004147AE0000000
  %517 = fmul fast float %512, 0x4004147AE0000000
  %518 = fmul fast float %513, 0x4004147AE0000000
  %519 = fadd fast float %516, 0x3F9EB851E0000000
  %520 = fadd fast float %517, 0x3F9EB851E0000000
  %521 = fadd fast float %518, 0x3F9EB851E0000000
  %522 = fmul fast float %519, %511
  %523 = fmul fast float %520, %512
  %524 = fmul fast float %521, %513
  %525 = fmul fast float %511, 0x400370A3E0000000
  %526 = fmul fast float %512, 0x400370A3E0000000
  %527 = fmul fast float %513, 0x400370A3E0000000
  %528 = fadd fast float %525, 0x3FE2E147A0000000
  %529 = fadd fast float %526, 0x3FE2E147A0000000
  %530 = fadd fast float %527, 0x3FE2E147A0000000
  %531 = fmul fast float %528, %511
  %532 = fmul fast float %529, %512
  %533 = fmul fast float %530, %513
  %534 = fadd fast float %531, 0x3FC1EB8520000000
  %535 = fadd fast float %532, 0x3FC1EB8520000000
  %536 = fadd fast float %533, 0x3FC1EB8520000000
  %537 = fdiv fast float %522, %534
  %538 = fdiv fast float %523, %535
  %539 = fdiv fast float %524, %536
  br label %540

; <label>:540                                     ; preds = %515, %504
  %541 = phi float [ %537, %515 ], [ %511, %504 ]
  %542 = phi float [ %538, %515 ], [ %512, %504 ]
  %543 = phi float [ %539, %515 ], [ %513, %504 ]
  %544 = call float @dx.op.unary.f32(i32 7, float %541)  ; Saturate(value)
  %545 = call float @dx.op.unary.f32(i32 7, float %542)  ; Saturate(value)
  %546 = call float @dx.op.unary.f32(i32 7, float %543)  ; Saturate(value)
  %547 = call float @dx.op.dot3.f32(i32 55, float %544, float %545, float %546, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %548 = fsub fast float %544, %547
  %549 = fsub fast float %545, %547
  %550 = fsub fast float %546, %547
  %551 = fmul fast float %548, %8
  %552 = fmul fast float %549, %8
  %553 = fmul fast float %550, %8
  %554 = fadd fast float %551, %547
  %555 = fadd fast float %552, %547
  %556 = fadd fast float %553, %547
  %557 = call float @dx.op.unary.f32(i32 7, float %554)  ; Saturate(value)
  %558 = call float @dx.op.unary.f32(i32 7, float %555)  ; Saturate(value)
  %559 = call float @dx.op.unary.f32(i32 7, float %556)  ; Saturate(value)
  %560 = fadd fast float %557, 0xBFC70A3D80000000
  %561 = fadd fast float %558, 0xBFC70A3D80000000
  %562 = fadd fast float %559, 0xBFC70A3D80000000
  %563 = fmul fast float %560, %7
  %564 = fmul fast float %561, %7
  %565 = fmul fast float %562, %7
  %566 = fadd fast float %563, 0x3FC70A3D80000000
  %567 = fadd fast float %564, 0x3FC70A3D80000000
  %568 = fadd fast float %565, 0x3FC70A3D80000000
  %569 = call float @dx.op.unary.f32(i32 7, float %566)  ; Saturate(value)
  %570 = call float @dx.op.unary.f32(i32 7, float %567)  ; Saturate(value)
  %571 = call float @dx.op.unary.f32(i32 7, float %568)  ; Saturate(value)
  br label %572

; <label>:572                                     ; preds = %540, %470
  %573 = phi float [ %501, %470 ], [ %569, %540 ]
  %574 = phi float [ %502, %470 ], [ %570, %540 ]
  %575 = phi float [ %503, %470 ], [ %571, %540 ]
  %576 = call float @dx.op.binary.f32(i32 36, float %458, float %573)  ; FMin(a,b)
  %577 = call float @dx.op.binary.f32(i32 36, float %459, float %574)  ; FMin(a,b)
  %578 = call float @dx.op.binary.f32(i32 36, float %460, float %575)  ; FMin(a,b)
  %579 = call float @dx.op.binary.f32(i32 36, float %226, float %341)  ; FMin(a,b)
  %580 = call float @dx.op.binary.f32(i32 36, float %227, float %342)  ; FMin(a,b)
  %581 = call float @dx.op.binary.f32(i32 36, float %228, float %343)  ; FMin(a,b)
  %582 = call float @dx.op.binary.f32(i32 36, float %579, float %576)  ; FMin(a,b)
  %583 = call float @dx.op.binary.f32(i32 36, float %580, float %577)  ; FMin(a,b)
  %584 = call float @dx.op.binary.f32(i32 36, float %581, float %578)  ; FMin(a,b)
  %585 = call float @dx.op.binary.f32(i32 36, float %109, float %582)  ; FMin(a,b)
  %586 = call float @dx.op.binary.f32(i32 36, float %110, float %583)  ; FMin(a,b)
  %587 = call float @dx.op.binary.f32(i32 36, float %111, float %584)  ; FMin(a,b)
  %588 = call float @dx.op.binary.f32(i32 35, float %458, float %573)  ; FMax(a,b)
  %589 = call float @dx.op.binary.f32(i32 35, float %459, float %574)  ; FMax(a,b)
  %590 = call float @dx.op.binary.f32(i32 35, float %460, float %575)  ; FMax(a,b)
  %591 = call float @dx.op.binary.f32(i32 35, float %226, float %341)  ; FMax(a,b)
  %592 = call float @dx.op.binary.f32(i32 35, float %227, float %342)  ; FMax(a,b)
  %593 = call float @dx.op.binary.f32(i32 35, float %228, float %343)  ; FMax(a,b)
  %594 = call float @dx.op.binary.f32(i32 35, float %591, float %588)  ; FMax(a,b)
  %595 = call float @dx.op.binary.f32(i32 35, float %592, float %589)  ; FMax(a,b)
  %596 = call float @dx.op.binary.f32(i32 35, float %593, float %590)  ; FMax(a,b)
  %597 = call float @dx.op.binary.f32(i32 35, float %109, float %594)  ; FMax(a,b)
  %598 = call float @dx.op.binary.f32(i32 35, float %110, float %595)  ; FMax(a,b)
  %599 = call float @dx.op.binary.f32(i32 35, float %111, float %596)  ; FMax(a,b)
  %600 = fsub fast float %597, %585
  %601 = fsub fast float %598, %586
  %602 = fsub fast float %599, %587
  %603 = call float @dx.op.unary.f32(i32 6, float %600)  ; FAbs(value)
  %604 = call float @dx.op.unary.f32(i32 6, float %601)  ; FAbs(value)
  %605 = call float @dx.op.unary.f32(i32 6, float %602)  ; FAbs(value)
  %606 = call float @dx.op.binary.f32(i32 35, float %604, float %605)  ; FMax(a,b)
  %607 = call float @dx.op.binary.f32(i32 35, float %603, float %606)  ; FMax(a,b)
  %608 = call float @dx.op.binary.f32(i32 35, float %598, float %599)  ; FMax(a,b)
  %609 = call float @dx.op.binary.f32(i32 35, float %597, float %608)  ; FMax(a,b)
  %610 = fmul fast float %609, 1.250000e-01
  %611 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %610)  ; FMax(a,b)
  %612 = fcmp fast ogt float %607, %611
  br i1 %612, label %613, label %674

; <label>:613                                     ; preds = %572
  %614 = fsub fast float %226, %341
  %615 = fsub fast float %227, %342
  %616 = fsub fast float %228, %343
  %617 = call float @dx.op.unary.f32(i32 6, float %614)  ; FAbs(value)
  %618 = call float @dx.op.unary.f32(i32 6, float %615)  ; FAbs(value)
  %619 = call float @dx.op.unary.f32(i32 6, float %616)  ; FAbs(value)
  %620 = call float @dx.op.binary.f32(i32 35, float %618, float %619)  ; FMax(a,b)
  %621 = call float @dx.op.binary.f32(i32 35, float %617, float %620)  ; FMax(a,b)
  %622 = fsub fast float %458, %573
  %623 = fsub fast float %459, %574
  %624 = fsub fast float %460, %575
  %625 = call float @dx.op.unary.f32(i32 6, float %622)  ; FAbs(value)
  %626 = call float @dx.op.unary.f32(i32 6, float %623)  ; FAbs(value)
  %627 = call float @dx.op.unary.f32(i32 6, float %624)  ; FAbs(value)
  %628 = call float @dx.op.binary.f32(i32 35, float %626, float %627)  ; FMax(a,b)
  %629 = call float @dx.op.binary.f32(i32 35, float %625, float %628)  ; FMax(a,b)
  %630 = fcmp fast olt float %621, %629
  %631 = select i1 %630, float %226, float %458
  %632 = select i1 %630, float %227, float %459
  %633 = select i1 %630, float %228, float %460
  %634 = select i1 %630, float %341, float %573
  %635 = select i1 %630, float %342, float %574
  %636 = select i1 %630, float %343, float %575
  %637 = fsub fast float %109, %634
  %638 = fsub fast float %110, %635
  %639 = fsub fast float %111, %636
  %640 = fsub fast float %109, %631
  %641 = fsub fast float %110, %632
  %642 = fsub fast float %111, %633
  %643 = call float @dx.op.dot3.f32(i32 55, float %640, float %641, float %642, float %637, float %638, float %639)  ; Dot3(ax,ay,az,bx,by,bz)
  %644 = fcmp fast ogt float %643, 0.000000e+00
  br i1 %644, label %645, label %656

; <label>:645                                     ; preds = %613
  %646 = fsub fast float %631, %634
  %647 = fsub fast float %632, %635
  %648 = fsub fast float %633, %636
  %649 = call float @dx.op.unary.f32(i32 6, float %646)  ; FAbs(value)
  %650 = call float @dx.op.unary.f32(i32 6, float %647)  ; FAbs(value)
  %651 = call float @dx.op.unary.f32(i32 6, float %648)  ; FAbs(value)
  %652 = call float @dx.op.binary.f32(i32 35, float %650, float %651)  ; FMax(a,b)
  %653 = call float @dx.op.binary.f32(i32 35, float %649, float %652)  ; FMax(a,b)
  %654 = fmul fast float %607, 2.500000e-01
  %655 = fcmp fast olt float %653, %654
  br label %656

; <label>:656                                     ; preds = %645, %613
  %657 = phi i1 [ false, %613 ], [ %655, %645 ]
  %658 = select i1 %657, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  %659 = fadd fast float %631, %634
  %660 = fadd fast float %632, %635
  %661 = fadd fast float %633, %636
  %662 = fmul fast float %659, 5.000000e-01
  %663 = fmul fast float %660, 5.000000e-01
  %664 = fmul fast float %661, 5.000000e-01
  %665 = fsub fast float %662, %109
  %666 = fsub fast float %663, %110
  %667 = fsub fast float %664, %111
  %668 = fmul fast float %658, %665
  %669 = fmul fast float %658, %666
  %670 = fmul fast float %658, %667
  %671 = fadd fast float %668, %109
  %672 = fadd fast float %669, %110
  %673 = fadd fast float %670, %111
  br label %674

; <label>:674                                     ; preds = %656, %572
  %675 = phi float [ %671, %656 ], [ %109, %572 ]
  %676 = phi float [ %672, %656 ], [ %110, %572 ]
  %677 = phi float [ %673, %656 ], [ %111, %572 ]
  %678 = fcmp fast ogt float %675, 0x3F69A5C380000000
  %679 = fcmp fast ogt float %676, 0x3F69A5C380000000
  %680 = fcmp fast ogt float %677, 0x3F69A5C380000000
  %681 = select i1 %678, float 0.000000e+00, float 1.000000e+00
  %682 = select i1 %679, float 0.000000e+00, float 1.000000e+00
  %683 = select i1 %680, float 0.000000e+00, float 1.000000e+00
  %684 = fmul fast float %675, 0x4029D70A40000000
  %685 = fmul fast float %676, 0x4029D70A40000000
  %686 = fmul fast float %677, 0x4029D70A40000000
  %687 = call float @dx.op.binary.f32(i32 35, float %675, float 0.000000e+00)  ; FMax(a,b)
  %688 = call float @dx.op.binary.f32(i32 35, float %676, float 0.000000e+00)  ; FMax(a,b)
  %689 = call float @dx.op.binary.f32(i32 35, float %677, float 0.000000e+00)  ; FMax(a,b)
  %690 = call float @dx.op.unary.f32(i32 23, float %687)  ; Log(value)
  %691 = call float @dx.op.unary.f32(i32 23, float %688)  ; Log(value)
  %692 = call float @dx.op.unary.f32(i32 23, float %689)  ; Log(value)
  %693 = fmul fast float %690, 0x3FDAAAAAA0000000
  %694 = fmul fast float %691, 0x3FDAAAAAA0000000
  %695 = fmul fast float %692, 0x3FDAAAAAA0000000
  %696 = call float @dx.op.unary.f32(i32 21, float %693)  ; Exp(value)
  %697 = call float @dx.op.unary.f32(i32 21, float %694)  ; Exp(value)
  %698 = call float @dx.op.unary.f32(i32 21, float %695)  ; Exp(value)
  %699 = fmul fast float %696, 0x3FF0E147A0000000
  %700 = fmul fast float %697, 0x3FF0E147A0000000
  %701 = fmul fast float %698, 0x3FF0E147A0000000
  %702 = fadd fast float %699, 0xBFAC28F5C0000000
  %703 = fadd fast float %700, 0xBFAC28F5C0000000
  %704 = fadd fast float %701, 0xBFAC28F5C0000000
  %705 = fsub fast float %684, %702
  %706 = fsub fast float %685, %703
  %707 = fsub fast float %686, %704
  %708 = fmul fast float %705, %681
  %709 = fmul fast float %706, %682
  %710 = fmul fast float %707, %683
  %711 = fadd fast float %708, %702
  %712 = fadd fast float %709, %703
  %713 = fadd fast float %710, %704
  br label %714

; <label>:714                                     ; preds = %674, %42
  %715 = phi float [ %37, %42 ], [ %711, %674 ]
  %716 = phi float [ %38, %42 ], [ %712, %674 ]
  %717 = phi float [ %39, %42 ], [ %713, %674 ]
  %718 = phi float [ %43, %42 ], [ %40, %674 ]
  %719 = add i32 %26, 1
  %720 = call i32 @dx.op.binary.i32(i32 37, i32 %719, i32 0)  ; IMax(a,b)
  %721 = call i32 @dx.op.binary.i32(i32 38, i32 %720, i32 %30)  ; IMin(a,b)
  %722 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %721, i32 %35, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %723 = extractvalue %dx.types.ResRet.f32 %722, 0
  %724 = extractvalue %dx.types.ResRet.f32 %722, 1
  %725 = extractvalue %dx.types.ResRet.f32 %722, 2
  %726 = extractvalue %dx.types.ResRet.f32 %722, 3
  %727 = fcmp fast olt float %726, 0.000000e+00
  br i1 %727, label %728, label %730

; <label>:728                                     ; preds = %714
  %729 = fsub fast float -1.000000e+00, %726
  br label %1400

; <label>:730                                     ; preds = %714
  %731 = fadd fast float %5, 1.000000e+00
  %732 = fadd fast float %6, 1.000000e+00
  %733 = fsub fast float 1.000000e+00, %5
  %734 = fmul fast float %9, %731
  %735 = fmul fast float %9, %732
  %736 = fmul fast float %9, %733
  %737 = fmul fast float %734, %723
  %738 = fmul fast float %735, %724
  %739 = fmul fast float %736, %725
  %740 = fcmp fast ult float %10, 5.000000e-01
  br i1 %740, label %766, label %741

; <label>:741                                     ; preds = %730
  %742 = fmul fast float %737, 0x4004147AE0000000
  %743 = fmul fast float %738, 0x4004147AE0000000
  %744 = fmul fast float %739, 0x4004147AE0000000
  %745 = fadd fast float %742, 0x3F9EB851E0000000
  %746 = fadd fast float %743, 0x3F9EB851E0000000
  %747 = fadd fast float %744, 0x3F9EB851E0000000
  %748 = fmul fast float %745, %737
  %749 = fmul fast float %746, %738
  %750 = fmul fast float %747, %739
  %751 = fmul fast float %737, 0x400370A3E0000000
  %752 = fmul fast float %738, 0x400370A3E0000000
  %753 = fmul fast float %739, 0x400370A3E0000000
  %754 = fadd fast float %751, 0x3FE2E147A0000000
  %755 = fadd fast float %752, 0x3FE2E147A0000000
  %756 = fadd fast float %753, 0x3FE2E147A0000000
  %757 = fmul fast float %754, %737
  %758 = fmul fast float %755, %738
  %759 = fmul fast float %756, %739
  %760 = fadd fast float %757, 0x3FC1EB8520000000
  %761 = fadd fast float %758, 0x3FC1EB8520000000
  %762 = fadd fast float %759, 0x3FC1EB8520000000
  %763 = fdiv fast float %748, %760
  %764 = fdiv fast float %749, %761
  %765 = fdiv fast float %750, %762
  br label %766

; <label>:766                                     ; preds = %741, %730
  %767 = phi float [ %763, %741 ], [ %737, %730 ]
  %768 = phi float [ %764, %741 ], [ %738, %730 ]
  %769 = phi float [ %765, %741 ], [ %739, %730 ]
  %770 = call float @dx.op.unary.f32(i32 7, float %767)  ; Saturate(value)
  %771 = call float @dx.op.unary.f32(i32 7, float %768)  ; Saturate(value)
  %772 = call float @dx.op.unary.f32(i32 7, float %769)  ; Saturate(value)
  %773 = call float @dx.op.dot3.f32(i32 55, float %770, float %771, float %772, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %774 = fsub fast float %770, %773
  %775 = fsub fast float %771, %773
  %776 = fsub fast float %772, %773
  %777 = fmul fast float %774, %8
  %778 = fmul fast float %775, %8
  %779 = fmul fast float %776, %8
  %780 = fadd fast float %777, %773
  %781 = fadd fast float %778, %773
  %782 = fadd fast float %779, %773
  %783 = call float @dx.op.unary.f32(i32 7, float %780)  ; Saturate(value)
  %784 = call float @dx.op.unary.f32(i32 7, float %781)  ; Saturate(value)
  %785 = call float @dx.op.unary.f32(i32 7, float %782)  ; Saturate(value)
  %786 = fadd fast float %783, 0xBFC70A3D80000000
  %787 = fadd fast float %784, 0xBFC70A3D80000000
  %788 = fadd fast float %785, 0xBFC70A3D80000000
  %789 = fmul fast float %786, %7
  %790 = fmul fast float %787, %7
  %791 = fmul fast float %788, %7
  %792 = fadd fast float %789, 0x3FC70A3D80000000
  %793 = fadd fast float %790, 0x3FC70A3D80000000
  %794 = fadd fast float %791, 0x3FC70A3D80000000
  %795 = call float @dx.op.unary.f32(i32 7, float %792)  ; Saturate(value)
  %796 = call float @dx.op.unary.f32(i32 7, float %793)  ; Saturate(value)
  %797 = call float @dx.op.unary.f32(i32 7, float %794)  ; Saturate(value)
  %798 = add i32 %35, -1
  %799 = call i32 @dx.op.binary.i32(i32 37, i32 %721, i32 0)  ; IMax(a,b)
  %800 = call i32 @dx.op.binary.i32(i32 37, i32 %798, i32 0)  ; IMax(a,b)
  %801 = call i32 @dx.op.binary.i32(i32 38, i32 %799, i32 %30)  ; IMin(a,b)
  %802 = call i32 @dx.op.binary.i32(i32 38, i32 %800, i32 %31)  ; IMin(a,b)
  %803 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %801, i32 %802, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %804 = extractvalue %dx.types.ResRet.f32 %803, 0
  %805 = extractvalue %dx.types.ResRet.f32 %803, 1
  %806 = extractvalue %dx.types.ResRet.f32 %803, 2
  %807 = extractvalue %dx.types.ResRet.f32 %803, 3
  %808 = fcmp fast olt float %807, 0.000000e+00
  br i1 %808, label %809, label %843

; <label>:809                                     ; preds = %766
  %810 = fcmp fast ogt float %804, 0x3FA4B5DCC0000000
  %811 = fcmp fast ogt float %805, 0x3FA4B5DCC0000000
  %812 = fcmp fast ogt float %806, 0x3FA4B5DCC0000000
  %813 = select i1 %810, float 0.000000e+00, float 1.000000e+00
  %814 = select i1 %811, float 0.000000e+00, float 1.000000e+00
  %815 = select i1 %812, float 0.000000e+00, float 1.000000e+00
  %816 = fmul fast float %804, 0x3FB3D07220000000
  %817 = fmul fast float %805, 0x3FB3D07220000000
  %818 = fmul fast float %806, 0x3FB3D07220000000
  %819 = fadd fast float %804, 0x3FAC28F5C0000000
  %820 = fadd fast float %805, 0x3FAC28F5C0000000
  %821 = fadd fast float %806, 0x3FAC28F5C0000000
  %822 = fmul fast float %819, 0x3FEE54EDE0000000
  %823 = fmul fast float %820, 0x3FEE54EDE0000000
  %824 = fmul fast float %821, 0x3FEE54EDE0000000
  %825 = call float @dx.op.unary.f32(i32 23, float %822)  ; Log(value)
  %826 = call float @dx.op.unary.f32(i32 23, float %823)  ; Log(value)
  %827 = call float @dx.op.unary.f32(i32 23, float %824)  ; Log(value)
  %828 = fmul fast float %825, 0x4003333340000000
  %829 = fmul fast float %826, 0x4003333340000000
  %830 = fmul fast float %827, 0x4003333340000000
  %831 = call float @dx.op.unary.f32(i32 21, float %828)  ; Exp(value)
  %832 = call float @dx.op.unary.f32(i32 21, float %829)  ; Exp(value)
  %833 = call float @dx.op.unary.f32(i32 21, float %830)  ; Exp(value)
  %834 = fsub fast float %816, %831
  %835 = fsub fast float %817, %832
  %836 = fsub fast float %818, %833
  %837 = fmul fast float %834, %813
  %838 = fmul fast float %835, %814
  %839 = fmul fast float %836, %815
  %840 = fadd fast float %837, %831
  %841 = fadd fast float %838, %832
  %842 = fadd fast float %839, %833
  br label %911

; <label>:843                                     ; preds = %766
  %844 = fadd fast float %5, 1.000000e+00
  %845 = fadd fast float %6, 1.000000e+00
  %846 = fsub fast float 1.000000e+00, %5
  %847 = fmul fast float %9, %844
  %848 = fmul fast float %9, %845
  %849 = fmul fast float %9, %846
  %850 = fmul fast float %847, %804
  %851 = fmul fast float %848, %805
  %852 = fmul fast float %849, %806
  %853 = fcmp fast ult float %10, 5.000000e-01
  br i1 %853, label %879, label %854

; <label>:854                                     ; preds = %843
  %855 = fmul fast float %850, 0x4004147AE0000000
  %856 = fmul fast float %851, 0x4004147AE0000000
  %857 = fmul fast float %852, 0x4004147AE0000000
  %858 = fadd fast float %855, 0x3F9EB851E0000000
  %859 = fadd fast float %856, 0x3F9EB851E0000000
  %860 = fadd fast float %857, 0x3F9EB851E0000000
  %861 = fmul fast float %858, %850
  %862 = fmul fast float %859, %851
  %863 = fmul fast float %860, %852
  %864 = fmul fast float %850, 0x400370A3E0000000
  %865 = fmul fast float %851, 0x400370A3E0000000
  %866 = fmul fast float %852, 0x400370A3E0000000
  %867 = fadd fast float %864, 0x3FE2E147A0000000
  %868 = fadd fast float %865, 0x3FE2E147A0000000
  %869 = fadd fast float %866, 0x3FE2E147A0000000
  %870 = fmul fast float %867, %850
  %871 = fmul fast float %868, %851
  %872 = fmul fast float %869, %852
  %873 = fadd fast float %870, 0x3FC1EB8520000000
  %874 = fadd fast float %871, 0x3FC1EB8520000000
  %875 = fadd fast float %872, 0x3FC1EB8520000000
  %876 = fdiv fast float %861, %873
  %877 = fdiv fast float %862, %874
  %878 = fdiv fast float %863, %875
  br label %879

; <label>:879                                     ; preds = %854, %843
  %880 = phi float [ %876, %854 ], [ %850, %843 ]
  %881 = phi float [ %877, %854 ], [ %851, %843 ]
  %882 = phi float [ %878, %854 ], [ %852, %843 ]
  %883 = call float @dx.op.unary.f32(i32 7, float %880)  ; Saturate(value)
  %884 = call float @dx.op.unary.f32(i32 7, float %881)  ; Saturate(value)
  %885 = call float @dx.op.unary.f32(i32 7, float %882)  ; Saturate(value)
  %886 = call float @dx.op.dot3.f32(i32 55, float %883, float %884, float %885, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %887 = fsub fast float %883, %886
  %888 = fsub fast float %884, %886
  %889 = fsub fast float %885, %886
  %890 = fmul fast float %887, %8
  %891 = fmul fast float %888, %8
  %892 = fmul fast float %889, %8
  %893 = fadd fast float %890, %886
  %894 = fadd fast float %891, %886
  %895 = fadd fast float %892, %886
  %896 = call float @dx.op.unary.f32(i32 7, float %893)  ; Saturate(value)
  %897 = call float @dx.op.unary.f32(i32 7, float %894)  ; Saturate(value)
  %898 = call float @dx.op.unary.f32(i32 7, float %895)  ; Saturate(value)
  %899 = fadd fast float %896, 0xBFC70A3D80000000
  %900 = fadd fast float %897, 0xBFC70A3D80000000
  %901 = fadd fast float %898, 0xBFC70A3D80000000
  %902 = fmul fast float %899, %7
  %903 = fmul fast float %900, %7
  %904 = fmul fast float %901, %7
  %905 = fadd fast float %902, 0x3FC70A3D80000000
  %906 = fadd fast float %903, 0x3FC70A3D80000000
  %907 = fadd fast float %904, 0x3FC70A3D80000000
  %908 = call float @dx.op.unary.f32(i32 7, float %905)  ; Saturate(value)
  %909 = call float @dx.op.unary.f32(i32 7, float %906)  ; Saturate(value)
  %910 = call float @dx.op.unary.f32(i32 7, float %907)  ; Saturate(value)
  br label %911

; <label>:911                                     ; preds = %879, %809
  %912 = phi float [ %840, %809 ], [ %908, %879 ]
  %913 = phi float [ %841, %809 ], [ %909, %879 ]
  %914 = phi float [ %842, %809 ], [ %910, %879 ]
  %915 = add i32 %35, 1
  %916 = call i32 @dx.op.binary.i32(i32 37, i32 %915, i32 0)  ; IMax(a,b)
  %917 = call i32 @dx.op.binary.i32(i32 38, i32 %916, i32 %31)  ; IMin(a,b)
  %918 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %801, i32 %917, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %919 = extractvalue %dx.types.ResRet.f32 %918, 0
  %920 = extractvalue %dx.types.ResRet.f32 %918, 1
  %921 = extractvalue %dx.types.ResRet.f32 %918, 2
  %922 = extractvalue %dx.types.ResRet.f32 %918, 3
  %923 = fcmp fast olt float %922, 0.000000e+00
  br i1 %923, label %924, label %958

; <label>:924                                     ; preds = %911
  %925 = fcmp fast ogt float %919, 0x3FA4B5DCC0000000
  %926 = fcmp fast ogt float %920, 0x3FA4B5DCC0000000
  %927 = fcmp fast ogt float %921, 0x3FA4B5DCC0000000
  %928 = select i1 %925, float 0.000000e+00, float 1.000000e+00
  %929 = select i1 %926, float 0.000000e+00, float 1.000000e+00
  %930 = select i1 %927, float 0.000000e+00, float 1.000000e+00
  %931 = fmul fast float %919, 0x3FB3D07220000000
  %932 = fmul fast float %920, 0x3FB3D07220000000
  %933 = fmul fast float %921, 0x3FB3D07220000000
  %934 = fadd fast float %919, 0x3FAC28F5C0000000
  %935 = fadd fast float %920, 0x3FAC28F5C0000000
  %936 = fadd fast float %921, 0x3FAC28F5C0000000
  %937 = fmul fast float %934, 0x3FEE54EDE0000000
  %938 = fmul fast float %935, 0x3FEE54EDE0000000
  %939 = fmul fast float %936, 0x3FEE54EDE0000000
  %940 = call float @dx.op.unary.f32(i32 23, float %937)  ; Log(value)
  %941 = call float @dx.op.unary.f32(i32 23, float %938)  ; Log(value)
  %942 = call float @dx.op.unary.f32(i32 23, float %939)  ; Log(value)
  %943 = fmul fast float %940, 0x4003333340000000
  %944 = fmul fast float %941, 0x4003333340000000
  %945 = fmul fast float %942, 0x4003333340000000
  %946 = call float @dx.op.unary.f32(i32 21, float %943)  ; Exp(value)
  %947 = call float @dx.op.unary.f32(i32 21, float %944)  ; Exp(value)
  %948 = call float @dx.op.unary.f32(i32 21, float %945)  ; Exp(value)
  %949 = fsub fast float %931, %946
  %950 = fsub fast float %932, %947
  %951 = fsub fast float %933, %948
  %952 = fmul fast float %949, %928
  %953 = fmul fast float %950, %929
  %954 = fmul fast float %951, %930
  %955 = fadd fast float %952, %946
  %956 = fadd fast float %953, %947
  %957 = fadd fast float %954, %948
  br label %1026

; <label>:958                                     ; preds = %911
  %959 = fadd fast float %5, 1.000000e+00
  %960 = fadd fast float %6, 1.000000e+00
  %961 = fsub fast float 1.000000e+00, %5
  %962 = fmul fast float %9, %959
  %963 = fmul fast float %9, %960
  %964 = fmul fast float %9, %961
  %965 = fmul fast float %962, %919
  %966 = fmul fast float %963, %920
  %967 = fmul fast float %964, %921
  %968 = fcmp fast ult float %10, 5.000000e-01
  br i1 %968, label %994, label %969

; <label>:969                                     ; preds = %958
  %970 = fmul fast float %965, 0x4004147AE0000000
  %971 = fmul fast float %966, 0x4004147AE0000000
  %972 = fmul fast float %967, 0x4004147AE0000000
  %973 = fadd fast float %970, 0x3F9EB851E0000000
  %974 = fadd fast float %971, 0x3F9EB851E0000000
  %975 = fadd fast float %972, 0x3F9EB851E0000000
  %976 = fmul fast float %973, %965
  %977 = fmul fast float %974, %966
  %978 = fmul fast float %975, %967
  %979 = fmul fast float %965, 0x400370A3E0000000
  %980 = fmul fast float %966, 0x400370A3E0000000
  %981 = fmul fast float %967, 0x400370A3E0000000
  %982 = fadd fast float %979, 0x3FE2E147A0000000
  %983 = fadd fast float %980, 0x3FE2E147A0000000
  %984 = fadd fast float %981, 0x3FE2E147A0000000
  %985 = fmul fast float %982, %965
  %986 = fmul fast float %983, %966
  %987 = fmul fast float %984, %967
  %988 = fadd fast float %985, 0x3FC1EB8520000000
  %989 = fadd fast float %986, 0x3FC1EB8520000000
  %990 = fadd fast float %987, 0x3FC1EB8520000000
  %991 = fdiv fast float %976, %988
  %992 = fdiv fast float %977, %989
  %993 = fdiv fast float %978, %990
  br label %994

; <label>:994                                     ; preds = %969, %958
  %995 = phi float [ %991, %969 ], [ %965, %958 ]
  %996 = phi float [ %992, %969 ], [ %966, %958 ]
  %997 = phi float [ %993, %969 ], [ %967, %958 ]
  %998 = call float @dx.op.unary.f32(i32 7, float %995)  ; Saturate(value)
  %999 = call float @dx.op.unary.f32(i32 7, float %996)  ; Saturate(value)
  %1000 = call float @dx.op.unary.f32(i32 7, float %997)  ; Saturate(value)
  %1001 = call float @dx.op.dot3.f32(i32 55, float %998, float %999, float %1000, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1002 = fsub fast float %998, %1001
  %1003 = fsub fast float %999, %1001
  %1004 = fsub fast float %1000, %1001
  %1005 = fmul fast float %1002, %8
  %1006 = fmul fast float %1003, %8
  %1007 = fmul fast float %1004, %8
  %1008 = fadd fast float %1005, %1001
  %1009 = fadd fast float %1006, %1001
  %1010 = fadd fast float %1007, %1001
  %1011 = call float @dx.op.unary.f32(i32 7, float %1008)  ; Saturate(value)
  %1012 = call float @dx.op.unary.f32(i32 7, float %1009)  ; Saturate(value)
  %1013 = call float @dx.op.unary.f32(i32 7, float %1010)  ; Saturate(value)
  %1014 = fadd fast float %1011, 0xBFC70A3D80000000
  %1015 = fadd fast float %1012, 0xBFC70A3D80000000
  %1016 = fadd fast float %1013, 0xBFC70A3D80000000
  %1017 = fmul fast float %1014, %7
  %1018 = fmul fast float %1015, %7
  %1019 = fmul fast float %1016, %7
  %1020 = fadd fast float %1017, 0x3FC70A3D80000000
  %1021 = fadd fast float %1018, 0x3FC70A3D80000000
  %1022 = fadd fast float %1019, 0x3FC70A3D80000000
  %1023 = call float @dx.op.unary.f32(i32 7, float %1020)  ; Saturate(value)
  %1024 = call float @dx.op.unary.f32(i32 7, float %1021)  ; Saturate(value)
  %1025 = call float @dx.op.unary.f32(i32 7, float %1022)  ; Saturate(value)
  br label %1026

; <label>:1026                                    ; preds = %994, %924
  %1027 = phi float [ %955, %924 ], [ %1023, %994 ]
  %1028 = phi float [ %956, %924 ], [ %1024, %994 ]
  %1029 = phi float [ %957, %924 ], [ %1025, %994 ]
  %1030 = add i32 %721, -1
  %1031 = call i32 @dx.op.binary.i32(i32 37, i32 %1030, i32 0)  ; IMax(a,b)
  %1032 = call i32 @dx.op.binary.i32(i32 37, i32 %35, i32 0)  ; IMax(a,b)
  %1033 = call i32 @dx.op.binary.i32(i32 38, i32 %1031, i32 %30)  ; IMin(a,b)
  %1034 = call i32 @dx.op.binary.i32(i32 38, i32 %1032, i32 %31)  ; IMin(a,b)
  %1035 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1033, i32 %1034, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1036 = extractvalue %dx.types.ResRet.f32 %1035, 0
  %1037 = extractvalue %dx.types.ResRet.f32 %1035, 1
  %1038 = extractvalue %dx.types.ResRet.f32 %1035, 2
  %1039 = extractvalue %dx.types.ResRet.f32 %1035, 3
  %1040 = fcmp fast olt float %1039, 0.000000e+00
  br i1 %1040, label %1041, label %1075

; <label>:1041                                    ; preds = %1026
  %1042 = fcmp fast ogt float %1036, 0x3FA4B5DCC0000000
  %1043 = fcmp fast ogt float %1037, 0x3FA4B5DCC0000000
  %1044 = fcmp fast ogt float %1038, 0x3FA4B5DCC0000000
  %1045 = select i1 %1042, float 0.000000e+00, float 1.000000e+00
  %1046 = select i1 %1043, float 0.000000e+00, float 1.000000e+00
  %1047 = select i1 %1044, float 0.000000e+00, float 1.000000e+00
  %1048 = fmul fast float %1036, 0x3FB3D07220000000
  %1049 = fmul fast float %1037, 0x3FB3D07220000000
  %1050 = fmul fast float %1038, 0x3FB3D07220000000
  %1051 = fadd fast float %1036, 0x3FAC28F5C0000000
  %1052 = fadd fast float %1037, 0x3FAC28F5C0000000
  %1053 = fadd fast float %1038, 0x3FAC28F5C0000000
  %1054 = fmul fast float %1051, 0x3FEE54EDE0000000
  %1055 = fmul fast float %1052, 0x3FEE54EDE0000000
  %1056 = fmul fast float %1053, 0x3FEE54EDE0000000
  %1057 = call float @dx.op.unary.f32(i32 23, float %1054)  ; Log(value)
  %1058 = call float @dx.op.unary.f32(i32 23, float %1055)  ; Log(value)
  %1059 = call float @dx.op.unary.f32(i32 23, float %1056)  ; Log(value)
  %1060 = fmul fast float %1057, 0x4003333340000000
  %1061 = fmul fast float %1058, 0x4003333340000000
  %1062 = fmul fast float %1059, 0x4003333340000000
  %1063 = call float @dx.op.unary.f32(i32 21, float %1060)  ; Exp(value)
  %1064 = call float @dx.op.unary.f32(i32 21, float %1061)  ; Exp(value)
  %1065 = call float @dx.op.unary.f32(i32 21, float %1062)  ; Exp(value)
  %1066 = fsub fast float %1048, %1063
  %1067 = fsub fast float %1049, %1064
  %1068 = fsub fast float %1050, %1065
  %1069 = fmul fast float %1066, %1045
  %1070 = fmul fast float %1067, %1046
  %1071 = fmul fast float %1068, %1047
  %1072 = fadd fast float %1069, %1063
  %1073 = fadd fast float %1070, %1064
  %1074 = fadd fast float %1071, %1065
  br label %1143

; <label>:1075                                    ; preds = %1026
  %1076 = fadd fast float %5, 1.000000e+00
  %1077 = fadd fast float %6, 1.000000e+00
  %1078 = fsub fast float 1.000000e+00, %5
  %1079 = fmul fast float %9, %1076
  %1080 = fmul fast float %9, %1077
  %1081 = fmul fast float %9, %1078
  %1082 = fmul fast float %1079, %1036
  %1083 = fmul fast float %1080, %1037
  %1084 = fmul fast float %1081, %1038
  %1085 = fcmp fast ult float %10, 5.000000e-01
  br i1 %1085, label %1111, label %1086

; <label>:1086                                    ; preds = %1075
  %1087 = fmul fast float %1082, 0x4004147AE0000000
  %1088 = fmul fast float %1083, 0x4004147AE0000000
  %1089 = fmul fast float %1084, 0x4004147AE0000000
  %1090 = fadd fast float %1087, 0x3F9EB851E0000000
  %1091 = fadd fast float %1088, 0x3F9EB851E0000000
  %1092 = fadd fast float %1089, 0x3F9EB851E0000000
  %1093 = fmul fast float %1090, %1082
  %1094 = fmul fast float %1091, %1083
  %1095 = fmul fast float %1092, %1084
  %1096 = fmul fast float %1082, 0x400370A3E0000000
  %1097 = fmul fast float %1083, 0x400370A3E0000000
  %1098 = fmul fast float %1084, 0x400370A3E0000000
  %1099 = fadd fast float %1096, 0x3FE2E147A0000000
  %1100 = fadd fast float %1097, 0x3FE2E147A0000000
  %1101 = fadd fast float %1098, 0x3FE2E147A0000000
  %1102 = fmul fast float %1099, %1082
  %1103 = fmul fast float %1100, %1083
  %1104 = fmul fast float %1101, %1084
  %1105 = fadd fast float %1102, 0x3FC1EB8520000000
  %1106 = fadd fast float %1103, 0x3FC1EB8520000000
  %1107 = fadd fast float %1104, 0x3FC1EB8520000000
  %1108 = fdiv fast float %1093, %1105
  %1109 = fdiv fast float %1094, %1106
  %1110 = fdiv fast float %1095, %1107
  br label %1111

; <label>:1111                                    ; preds = %1086, %1075
  %1112 = phi float [ %1108, %1086 ], [ %1082, %1075 ]
  %1113 = phi float [ %1109, %1086 ], [ %1083, %1075 ]
  %1114 = phi float [ %1110, %1086 ], [ %1084, %1075 ]
  %1115 = call float @dx.op.unary.f32(i32 7, float %1112)  ; Saturate(value)
  %1116 = call float @dx.op.unary.f32(i32 7, float %1113)  ; Saturate(value)
  %1117 = call float @dx.op.unary.f32(i32 7, float %1114)  ; Saturate(value)
  %1118 = call float @dx.op.dot3.f32(i32 55, float %1115, float %1116, float %1117, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1119 = fsub fast float %1115, %1118
  %1120 = fsub fast float %1116, %1118
  %1121 = fsub fast float %1117, %1118
  %1122 = fmul fast float %1119, %8
  %1123 = fmul fast float %1120, %8
  %1124 = fmul fast float %1121, %8
  %1125 = fadd fast float %1122, %1118
  %1126 = fadd fast float %1123, %1118
  %1127 = fadd fast float %1124, %1118
  %1128 = call float @dx.op.unary.f32(i32 7, float %1125)  ; Saturate(value)
  %1129 = call float @dx.op.unary.f32(i32 7, float %1126)  ; Saturate(value)
  %1130 = call float @dx.op.unary.f32(i32 7, float %1127)  ; Saturate(value)
  %1131 = fadd fast float %1128, 0xBFC70A3D80000000
  %1132 = fadd fast float %1129, 0xBFC70A3D80000000
  %1133 = fadd fast float %1130, 0xBFC70A3D80000000
  %1134 = fmul fast float %1131, %7
  %1135 = fmul fast float %1132, %7
  %1136 = fmul fast float %1133, %7
  %1137 = fadd fast float %1134, 0x3FC70A3D80000000
  %1138 = fadd fast float %1135, 0x3FC70A3D80000000
  %1139 = fadd fast float %1136, 0x3FC70A3D80000000
  %1140 = call float @dx.op.unary.f32(i32 7, float %1137)  ; Saturate(value)
  %1141 = call float @dx.op.unary.f32(i32 7, float %1138)  ; Saturate(value)
  %1142 = call float @dx.op.unary.f32(i32 7, float %1139)  ; Saturate(value)
  br label %1143

; <label>:1143                                    ; preds = %1111, %1041
  %1144 = phi float [ %1072, %1041 ], [ %1140, %1111 ]
  %1145 = phi float [ %1073, %1041 ], [ %1141, %1111 ]
  %1146 = phi float [ %1074, %1041 ], [ %1142, %1111 ]
  %1147 = add i32 %721, 1
  %1148 = call i32 @dx.op.binary.i32(i32 37, i32 %1147, i32 0)  ; IMax(a,b)
  %1149 = call i32 @dx.op.binary.i32(i32 38, i32 %1148, i32 %30)  ; IMin(a,b)
  %1150 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1149, i32 %1034, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1151 = extractvalue %dx.types.ResRet.f32 %1150, 0
  %1152 = extractvalue %dx.types.ResRet.f32 %1150, 1
  %1153 = extractvalue %dx.types.ResRet.f32 %1150, 2
  %1154 = extractvalue %dx.types.ResRet.f32 %1150, 3
  %1155 = fcmp fast olt float %1154, 0.000000e+00
  br i1 %1155, label %1156, label %1190

; <label>:1156                                    ; preds = %1143
  %1157 = fcmp fast ogt float %1151, 0x3FA4B5DCC0000000
  %1158 = fcmp fast ogt float %1152, 0x3FA4B5DCC0000000
  %1159 = fcmp fast ogt float %1153, 0x3FA4B5DCC0000000
  %1160 = select i1 %1157, float 0.000000e+00, float 1.000000e+00
  %1161 = select i1 %1158, float 0.000000e+00, float 1.000000e+00
  %1162 = select i1 %1159, float 0.000000e+00, float 1.000000e+00
  %1163 = fmul fast float %1151, 0x3FB3D07220000000
  %1164 = fmul fast float %1152, 0x3FB3D07220000000
  %1165 = fmul fast float %1153, 0x3FB3D07220000000
  %1166 = fadd fast float %1151, 0x3FAC28F5C0000000
  %1167 = fadd fast float %1152, 0x3FAC28F5C0000000
  %1168 = fadd fast float %1153, 0x3FAC28F5C0000000
  %1169 = fmul fast float %1166, 0x3FEE54EDE0000000
  %1170 = fmul fast float %1167, 0x3FEE54EDE0000000
  %1171 = fmul fast float %1168, 0x3FEE54EDE0000000
  %1172 = call float @dx.op.unary.f32(i32 23, float %1169)  ; Log(value)
  %1173 = call float @dx.op.unary.f32(i32 23, float %1170)  ; Log(value)
  %1174 = call float @dx.op.unary.f32(i32 23, float %1171)  ; Log(value)
  %1175 = fmul fast float %1172, 0x4003333340000000
  %1176 = fmul fast float %1173, 0x4003333340000000
  %1177 = fmul fast float %1174, 0x4003333340000000
  %1178 = call float @dx.op.unary.f32(i32 21, float %1175)  ; Exp(value)
  %1179 = call float @dx.op.unary.f32(i32 21, float %1176)  ; Exp(value)
  %1180 = call float @dx.op.unary.f32(i32 21, float %1177)  ; Exp(value)
  %1181 = fsub fast float %1163, %1178
  %1182 = fsub fast float %1164, %1179
  %1183 = fsub fast float %1165, %1180
  %1184 = fmul fast float %1181, %1160
  %1185 = fmul fast float %1182, %1161
  %1186 = fmul fast float %1183, %1162
  %1187 = fadd fast float %1184, %1178
  %1188 = fadd fast float %1185, %1179
  %1189 = fadd fast float %1186, %1180
  br label %1258

; <label>:1190                                    ; preds = %1143
  %1191 = fadd fast float %5, 1.000000e+00
  %1192 = fadd fast float %6, 1.000000e+00
  %1193 = fsub fast float 1.000000e+00, %5
  %1194 = fmul fast float %9, %1191
  %1195 = fmul fast float %9, %1192
  %1196 = fmul fast float %9, %1193
  %1197 = fmul fast float %1194, %1151
  %1198 = fmul fast float %1195, %1152
  %1199 = fmul fast float %1196, %1153
  %1200 = fcmp fast ult float %10, 5.000000e-01
  br i1 %1200, label %1226, label %1201

; <label>:1201                                    ; preds = %1190
  %1202 = fmul fast float %1197, 0x4004147AE0000000
  %1203 = fmul fast float %1198, 0x4004147AE0000000
  %1204 = fmul fast float %1199, 0x4004147AE0000000
  %1205 = fadd fast float %1202, 0x3F9EB851E0000000
  %1206 = fadd fast float %1203, 0x3F9EB851E0000000
  %1207 = fadd fast float %1204, 0x3F9EB851E0000000
  %1208 = fmul fast float %1205, %1197
  %1209 = fmul fast float %1206, %1198
  %1210 = fmul fast float %1207, %1199
  %1211 = fmul fast float %1197, 0x400370A3E0000000
  %1212 = fmul fast float %1198, 0x400370A3E0000000
  %1213 = fmul fast float %1199, 0x400370A3E0000000
  %1214 = fadd fast float %1211, 0x3FE2E147A0000000
  %1215 = fadd fast float %1212, 0x3FE2E147A0000000
  %1216 = fadd fast float %1213, 0x3FE2E147A0000000
  %1217 = fmul fast float %1214, %1197
  %1218 = fmul fast float %1215, %1198
  %1219 = fmul fast float %1216, %1199
  %1220 = fadd fast float %1217, 0x3FC1EB8520000000
  %1221 = fadd fast float %1218, 0x3FC1EB8520000000
  %1222 = fadd fast float %1219, 0x3FC1EB8520000000
  %1223 = fdiv fast float %1208, %1220
  %1224 = fdiv fast float %1209, %1221
  %1225 = fdiv fast float %1210, %1222
  br label %1226

; <label>:1226                                    ; preds = %1201, %1190
  %1227 = phi float [ %1223, %1201 ], [ %1197, %1190 ]
  %1228 = phi float [ %1224, %1201 ], [ %1198, %1190 ]
  %1229 = phi float [ %1225, %1201 ], [ %1199, %1190 ]
  %1230 = call float @dx.op.unary.f32(i32 7, float %1227)  ; Saturate(value)
  %1231 = call float @dx.op.unary.f32(i32 7, float %1228)  ; Saturate(value)
  %1232 = call float @dx.op.unary.f32(i32 7, float %1229)  ; Saturate(value)
  %1233 = call float @dx.op.dot3.f32(i32 55, float %1230, float %1231, float %1232, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1234 = fsub fast float %1230, %1233
  %1235 = fsub fast float %1231, %1233
  %1236 = fsub fast float %1232, %1233
  %1237 = fmul fast float %1234, %8
  %1238 = fmul fast float %1235, %8
  %1239 = fmul fast float %1236, %8
  %1240 = fadd fast float %1237, %1233
  %1241 = fadd fast float %1238, %1233
  %1242 = fadd fast float %1239, %1233
  %1243 = call float @dx.op.unary.f32(i32 7, float %1240)  ; Saturate(value)
  %1244 = call float @dx.op.unary.f32(i32 7, float %1241)  ; Saturate(value)
  %1245 = call float @dx.op.unary.f32(i32 7, float %1242)  ; Saturate(value)
  %1246 = fadd fast float %1243, 0xBFC70A3D80000000
  %1247 = fadd fast float %1244, 0xBFC70A3D80000000
  %1248 = fadd fast float %1245, 0xBFC70A3D80000000
  %1249 = fmul fast float %1246, %7
  %1250 = fmul fast float %1247, %7
  %1251 = fmul fast float %1248, %7
  %1252 = fadd fast float %1249, 0x3FC70A3D80000000
  %1253 = fadd fast float %1250, 0x3FC70A3D80000000
  %1254 = fadd fast float %1251, 0x3FC70A3D80000000
  %1255 = call float @dx.op.unary.f32(i32 7, float %1252)  ; Saturate(value)
  %1256 = call float @dx.op.unary.f32(i32 7, float %1253)  ; Saturate(value)
  %1257 = call float @dx.op.unary.f32(i32 7, float %1254)  ; Saturate(value)
  br label %1258

; <label>:1258                                    ; preds = %1226, %1156
  %1259 = phi float [ %1187, %1156 ], [ %1255, %1226 ]
  %1260 = phi float [ %1188, %1156 ], [ %1256, %1226 ]
  %1261 = phi float [ %1189, %1156 ], [ %1257, %1226 ]
  %1262 = call float @dx.op.binary.f32(i32 36, float %1144, float %1259)  ; FMin(a,b)
  %1263 = call float @dx.op.binary.f32(i32 36, float %1145, float %1260)  ; FMin(a,b)
  %1264 = call float @dx.op.binary.f32(i32 36, float %1146, float %1261)  ; FMin(a,b)
  %1265 = call float @dx.op.binary.f32(i32 36, float %912, float %1027)  ; FMin(a,b)
  %1266 = call float @dx.op.binary.f32(i32 36, float %913, float %1028)  ; FMin(a,b)
  %1267 = call float @dx.op.binary.f32(i32 36, float %914, float %1029)  ; FMin(a,b)
  %1268 = call float @dx.op.binary.f32(i32 36, float %1265, float %1262)  ; FMin(a,b)
  %1269 = call float @dx.op.binary.f32(i32 36, float %1266, float %1263)  ; FMin(a,b)
  %1270 = call float @dx.op.binary.f32(i32 36, float %1267, float %1264)  ; FMin(a,b)
  %1271 = call float @dx.op.binary.f32(i32 36, float %795, float %1268)  ; FMin(a,b)
  %1272 = call float @dx.op.binary.f32(i32 36, float %796, float %1269)  ; FMin(a,b)
  %1273 = call float @dx.op.binary.f32(i32 36, float %797, float %1270)  ; FMin(a,b)
  %1274 = call float @dx.op.binary.f32(i32 35, float %1144, float %1259)  ; FMax(a,b)
  %1275 = call float @dx.op.binary.f32(i32 35, float %1145, float %1260)  ; FMax(a,b)
  %1276 = call float @dx.op.binary.f32(i32 35, float %1146, float %1261)  ; FMax(a,b)
  %1277 = call float @dx.op.binary.f32(i32 35, float %912, float %1027)  ; FMax(a,b)
  %1278 = call float @dx.op.binary.f32(i32 35, float %913, float %1028)  ; FMax(a,b)
  %1279 = call float @dx.op.binary.f32(i32 35, float %914, float %1029)  ; FMax(a,b)
  %1280 = call float @dx.op.binary.f32(i32 35, float %1277, float %1274)  ; FMax(a,b)
  %1281 = call float @dx.op.binary.f32(i32 35, float %1278, float %1275)  ; FMax(a,b)
  %1282 = call float @dx.op.binary.f32(i32 35, float %1279, float %1276)  ; FMax(a,b)
  %1283 = call float @dx.op.binary.f32(i32 35, float %795, float %1280)  ; FMax(a,b)
  %1284 = call float @dx.op.binary.f32(i32 35, float %796, float %1281)  ; FMax(a,b)
  %1285 = call float @dx.op.binary.f32(i32 35, float %797, float %1282)  ; FMax(a,b)
  %1286 = fsub fast float %1283, %1271
  %1287 = fsub fast float %1284, %1272
  %1288 = fsub fast float %1285, %1273
  %1289 = call float @dx.op.unary.f32(i32 6, float %1286)  ; FAbs(value)
  %1290 = call float @dx.op.unary.f32(i32 6, float %1287)  ; FAbs(value)
  %1291 = call float @dx.op.unary.f32(i32 6, float %1288)  ; FAbs(value)
  %1292 = call float @dx.op.binary.f32(i32 35, float %1290, float %1291)  ; FMax(a,b)
  %1293 = call float @dx.op.binary.f32(i32 35, float %1289, float %1292)  ; FMax(a,b)
  %1294 = call float @dx.op.binary.f32(i32 35, float %1284, float %1285)  ; FMax(a,b)
  %1295 = call float @dx.op.binary.f32(i32 35, float %1283, float %1294)  ; FMax(a,b)
  %1296 = fmul fast float %1295, 1.250000e-01
  %1297 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1296)  ; FMax(a,b)
  %1298 = fcmp fast ogt float %1293, %1297
  br i1 %1298, label %1299, label %1360

; <label>:1299                                    ; preds = %1258
  %1300 = fsub fast float %912, %1027
  %1301 = fsub fast float %913, %1028
  %1302 = fsub fast float %914, %1029
  %1303 = call float @dx.op.unary.f32(i32 6, float %1300)  ; FAbs(value)
  %1304 = call float @dx.op.unary.f32(i32 6, float %1301)  ; FAbs(value)
  %1305 = call float @dx.op.unary.f32(i32 6, float %1302)  ; FAbs(value)
  %1306 = call float @dx.op.binary.f32(i32 35, float %1304, float %1305)  ; FMax(a,b)
  %1307 = call float @dx.op.binary.f32(i32 35, float %1303, float %1306)  ; FMax(a,b)
  %1308 = fsub fast float %1144, %1259
  %1309 = fsub fast float %1145, %1260
  %1310 = fsub fast float %1146, %1261
  %1311 = call float @dx.op.unary.f32(i32 6, float %1308)  ; FAbs(value)
  %1312 = call float @dx.op.unary.f32(i32 6, float %1309)  ; FAbs(value)
  %1313 = call float @dx.op.unary.f32(i32 6, float %1310)  ; FAbs(value)
  %1314 = call float @dx.op.binary.f32(i32 35, float %1312, float %1313)  ; FMax(a,b)
  %1315 = call float @dx.op.binary.f32(i32 35, float %1311, float %1314)  ; FMax(a,b)
  %1316 = fcmp fast olt float %1307, %1315
  %1317 = select i1 %1316, float %912, float %1144
  %1318 = select i1 %1316, float %913, float %1145
  %1319 = select i1 %1316, float %914, float %1146
  %1320 = select i1 %1316, float %1027, float %1259
  %1321 = select i1 %1316, float %1028, float %1260
  %1322 = select i1 %1316, float %1029, float %1261
  %1323 = fsub fast float %795, %1320
  %1324 = fsub fast float %796, %1321
  %1325 = fsub fast float %797, %1322
  %1326 = fsub fast float %795, %1317
  %1327 = fsub fast float %796, %1318
  %1328 = fsub fast float %797, %1319
  %1329 = call float @dx.op.dot3.f32(i32 55, float %1326, float %1327, float %1328, float %1323, float %1324, float %1325)  ; Dot3(ax,ay,az,bx,by,bz)
  %1330 = fcmp fast ogt float %1329, 0.000000e+00
  br i1 %1330, label %1331, label %1342

; <label>:1331                                    ; preds = %1299
  %1332 = fsub fast float %1317, %1320
  %1333 = fsub fast float %1318, %1321
  %1334 = fsub fast float %1319, %1322
  %1335 = call float @dx.op.unary.f32(i32 6, float %1332)  ; FAbs(value)
  %1336 = call float @dx.op.unary.f32(i32 6, float %1333)  ; FAbs(value)
  %1337 = call float @dx.op.unary.f32(i32 6, float %1334)  ; FAbs(value)
  %1338 = call float @dx.op.binary.f32(i32 35, float %1336, float %1337)  ; FMax(a,b)
  %1339 = call float @dx.op.binary.f32(i32 35, float %1335, float %1338)  ; FMax(a,b)
  %1340 = fmul fast float %1293, 2.500000e-01
  %1341 = fcmp fast olt float %1339, %1340
  br label %1342

; <label>:1342                                    ; preds = %1331, %1299
  %1343 = phi i1 [ false, %1299 ], [ %1341, %1331 ]
  %1344 = select i1 %1343, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  %1345 = fadd fast float %1317, %1320
  %1346 = fadd fast float %1318, %1321
  %1347 = fadd fast float %1319, %1322
  %1348 = fmul fast float %1345, 5.000000e-01
  %1349 = fmul fast float %1346, 5.000000e-01
  %1350 = fmul fast float %1347, 5.000000e-01
  %1351 = fsub fast float %1348, %795
  %1352 = fsub fast float %1349, %796
  %1353 = fsub fast float %1350, %797
  %1354 = fmul fast float %1344, %1351
  %1355 = fmul fast float %1344, %1352
  %1356 = fmul fast float %1344, %1353
  %1357 = fadd fast float %1354, %795
  %1358 = fadd fast float %1355, %796
  %1359 = fadd fast float %1356, %797
  br label %1360

; <label>:1360                                    ; preds = %1342, %1258
  %1361 = phi float [ %1357, %1342 ], [ %795, %1258 ]
  %1362 = phi float [ %1358, %1342 ], [ %796, %1258 ]
  %1363 = phi float [ %1359, %1342 ], [ %797, %1258 ]
  %1364 = fcmp fast ogt float %1361, 0x3F69A5C380000000
  %1365 = fcmp fast ogt float %1362, 0x3F69A5C380000000
  %1366 = fcmp fast ogt float %1363, 0x3F69A5C380000000
  %1367 = select i1 %1364, float 0.000000e+00, float 1.000000e+00
  %1368 = select i1 %1365, float 0.000000e+00, float 1.000000e+00
  %1369 = select i1 %1366, float 0.000000e+00, float 1.000000e+00
  %1370 = fmul fast float %1361, 0x4029D70A40000000
  %1371 = fmul fast float %1362, 0x4029D70A40000000
  %1372 = fmul fast float %1363, 0x4029D70A40000000
  %1373 = call float @dx.op.binary.f32(i32 35, float %1361, float 0.000000e+00)  ; FMax(a,b)
  %1374 = call float @dx.op.binary.f32(i32 35, float %1362, float 0.000000e+00)  ; FMax(a,b)
  %1375 = call float @dx.op.binary.f32(i32 35, float %1363, float 0.000000e+00)  ; FMax(a,b)
  %1376 = call float @dx.op.unary.f32(i32 23, float %1373)  ; Log(value)
  %1377 = call float @dx.op.unary.f32(i32 23, float %1374)  ; Log(value)
  %1378 = call float @dx.op.unary.f32(i32 23, float %1375)  ; Log(value)
  %1379 = fmul fast float %1376, 0x3FDAAAAAA0000000
  %1380 = fmul fast float %1377, 0x3FDAAAAAA0000000
  %1381 = fmul fast float %1378, 0x3FDAAAAAA0000000
  %1382 = call float @dx.op.unary.f32(i32 21, float %1379)  ; Exp(value)
  %1383 = call float @dx.op.unary.f32(i32 21, float %1380)  ; Exp(value)
  %1384 = call float @dx.op.unary.f32(i32 21, float %1381)  ; Exp(value)
  %1385 = fmul fast float %1382, 0x3FF0E147A0000000
  %1386 = fmul fast float %1383, 0x3FF0E147A0000000
  %1387 = fmul fast float %1384, 0x3FF0E147A0000000
  %1388 = fadd fast float %1385, 0xBFAC28F5C0000000
  %1389 = fadd fast float %1386, 0xBFAC28F5C0000000
  %1390 = fadd fast float %1387, 0xBFAC28F5C0000000
  %1391 = fsub fast float %1370, %1388
  %1392 = fsub fast float %1371, %1389
  %1393 = fsub fast float %1372, %1390
  %1394 = fmul fast float %1391, %1367
  %1395 = fmul fast float %1392, %1368
  %1396 = fmul fast float %1393, %1369
  %1397 = fadd fast float %1394, %1388
  %1398 = fadd fast float %1395, %1389
  %1399 = fadd fast float %1396, %1390
  br label %1400

; <label>:1400                                    ; preds = %1360, %728
  %1401 = phi float [ %723, %728 ], [ %1397, %1360 ]
  %1402 = phi float [ %724, %728 ], [ %1398, %1360 ]
  %1403 = phi float [ %725, %728 ], [ %1399, %1360 ]
  %1404 = phi float [ %729, %728 ], [ %726, %1360 ]
  %1405 = add i32 %27, 1
  %1406 = call i32 @dx.op.binary.i32(i32 37, i32 %1405, i32 0)  ; IMax(a,b)
  %1407 = call i32 @dx.op.binary.i32(i32 38, i32 %1406, i32 %31)  ; IMin(a,b)
  %1408 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %34, i32 %1407, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1409 = extractvalue %dx.types.ResRet.f32 %1408, 0
  %1410 = extractvalue %dx.types.ResRet.f32 %1408, 1
  %1411 = extractvalue %dx.types.ResRet.f32 %1408, 2
  %1412 = extractvalue %dx.types.ResRet.f32 %1408, 3
  %1413 = fcmp fast olt float %1412, 0.000000e+00
  br i1 %1413, label %1414, label %1416

; <label>:1414                                    ; preds = %1400
  %1415 = fsub fast float -1.000000e+00, %1412
  br label %2086

; <label>:1416                                    ; preds = %1400
  %1417 = fadd fast float %5, 1.000000e+00
  %1418 = fadd fast float %6, 1.000000e+00
  %1419 = fsub fast float 1.000000e+00, %5
  %1420 = fmul fast float %9, %1417
  %1421 = fmul fast float %9, %1418
  %1422 = fmul fast float %9, %1419
  %1423 = fmul fast float %1420, %1409
  %1424 = fmul fast float %1421, %1410
  %1425 = fmul fast float %1422, %1411
  %1426 = fcmp fast ult float %10, 5.000000e-01
  br i1 %1426, label %1452, label %1427

; <label>:1427                                    ; preds = %1416
  %1428 = fmul fast float %1423, 0x4004147AE0000000
  %1429 = fmul fast float %1424, 0x4004147AE0000000
  %1430 = fmul fast float %1425, 0x4004147AE0000000
  %1431 = fadd fast float %1428, 0x3F9EB851E0000000
  %1432 = fadd fast float %1429, 0x3F9EB851E0000000
  %1433 = fadd fast float %1430, 0x3F9EB851E0000000
  %1434 = fmul fast float %1431, %1423
  %1435 = fmul fast float %1432, %1424
  %1436 = fmul fast float %1433, %1425
  %1437 = fmul fast float %1423, 0x400370A3E0000000
  %1438 = fmul fast float %1424, 0x400370A3E0000000
  %1439 = fmul fast float %1425, 0x400370A3E0000000
  %1440 = fadd fast float %1437, 0x3FE2E147A0000000
  %1441 = fadd fast float %1438, 0x3FE2E147A0000000
  %1442 = fadd fast float %1439, 0x3FE2E147A0000000
  %1443 = fmul fast float %1440, %1423
  %1444 = fmul fast float %1441, %1424
  %1445 = fmul fast float %1442, %1425
  %1446 = fadd fast float %1443, 0x3FC1EB8520000000
  %1447 = fadd fast float %1444, 0x3FC1EB8520000000
  %1448 = fadd fast float %1445, 0x3FC1EB8520000000
  %1449 = fdiv fast float %1434, %1446
  %1450 = fdiv fast float %1435, %1447
  %1451 = fdiv fast float %1436, %1448
  br label %1452

; <label>:1452                                    ; preds = %1427, %1416
  %1453 = phi float [ %1449, %1427 ], [ %1423, %1416 ]
  %1454 = phi float [ %1450, %1427 ], [ %1424, %1416 ]
  %1455 = phi float [ %1451, %1427 ], [ %1425, %1416 ]
  %1456 = call float @dx.op.unary.f32(i32 7, float %1453)  ; Saturate(value)
  %1457 = call float @dx.op.unary.f32(i32 7, float %1454)  ; Saturate(value)
  %1458 = call float @dx.op.unary.f32(i32 7, float %1455)  ; Saturate(value)
  %1459 = call float @dx.op.dot3.f32(i32 55, float %1456, float %1457, float %1458, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1460 = fsub fast float %1456, %1459
  %1461 = fsub fast float %1457, %1459
  %1462 = fsub fast float %1458, %1459
  %1463 = fmul fast float %1460, %8
  %1464 = fmul fast float %1461, %8
  %1465 = fmul fast float %1462, %8
  %1466 = fadd fast float %1463, %1459
  %1467 = fadd fast float %1464, %1459
  %1468 = fadd fast float %1465, %1459
  %1469 = call float @dx.op.unary.f32(i32 7, float %1466)  ; Saturate(value)
  %1470 = call float @dx.op.unary.f32(i32 7, float %1467)  ; Saturate(value)
  %1471 = call float @dx.op.unary.f32(i32 7, float %1468)  ; Saturate(value)
  %1472 = fadd fast float %1469, 0xBFC70A3D80000000
  %1473 = fadd fast float %1470, 0xBFC70A3D80000000
  %1474 = fadd fast float %1471, 0xBFC70A3D80000000
  %1475 = fmul fast float %1472, %7
  %1476 = fmul fast float %1473, %7
  %1477 = fmul fast float %1474, %7
  %1478 = fadd fast float %1475, 0x3FC70A3D80000000
  %1479 = fadd fast float %1476, 0x3FC70A3D80000000
  %1480 = fadd fast float %1477, 0x3FC70A3D80000000
  %1481 = call float @dx.op.unary.f32(i32 7, float %1478)  ; Saturate(value)
  %1482 = call float @dx.op.unary.f32(i32 7, float %1479)  ; Saturate(value)
  %1483 = call float @dx.op.unary.f32(i32 7, float %1480)  ; Saturate(value)
  %1484 = add i32 %1407, -1
  %1485 = call i32 @dx.op.binary.i32(i32 37, i32 %34, i32 0)  ; IMax(a,b)
  %1486 = call i32 @dx.op.binary.i32(i32 37, i32 %1484, i32 0)  ; IMax(a,b)
  %1487 = call i32 @dx.op.binary.i32(i32 38, i32 %1485, i32 %30)  ; IMin(a,b)
  %1488 = call i32 @dx.op.binary.i32(i32 38, i32 %1486, i32 %31)  ; IMin(a,b)
  %1489 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1487, i32 %1488, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1490 = extractvalue %dx.types.ResRet.f32 %1489, 0
  %1491 = extractvalue %dx.types.ResRet.f32 %1489, 1
  %1492 = extractvalue %dx.types.ResRet.f32 %1489, 2
  %1493 = extractvalue %dx.types.ResRet.f32 %1489, 3
  %1494 = fcmp fast olt float %1493, 0.000000e+00
  br i1 %1494, label %1495, label %1529

; <label>:1495                                    ; preds = %1452
  %1496 = fcmp fast ogt float %1490, 0x3FA4B5DCC0000000
  %1497 = fcmp fast ogt float %1491, 0x3FA4B5DCC0000000
  %1498 = fcmp fast ogt float %1492, 0x3FA4B5DCC0000000
  %1499 = select i1 %1496, float 0.000000e+00, float 1.000000e+00
  %1500 = select i1 %1497, float 0.000000e+00, float 1.000000e+00
  %1501 = select i1 %1498, float 0.000000e+00, float 1.000000e+00
  %1502 = fmul fast float %1490, 0x3FB3D07220000000
  %1503 = fmul fast float %1491, 0x3FB3D07220000000
  %1504 = fmul fast float %1492, 0x3FB3D07220000000
  %1505 = fadd fast float %1490, 0x3FAC28F5C0000000
  %1506 = fadd fast float %1491, 0x3FAC28F5C0000000
  %1507 = fadd fast float %1492, 0x3FAC28F5C0000000
  %1508 = fmul fast float %1505, 0x3FEE54EDE0000000
  %1509 = fmul fast float %1506, 0x3FEE54EDE0000000
  %1510 = fmul fast float %1507, 0x3FEE54EDE0000000
  %1511 = call float @dx.op.unary.f32(i32 23, float %1508)  ; Log(value)
  %1512 = call float @dx.op.unary.f32(i32 23, float %1509)  ; Log(value)
  %1513 = call float @dx.op.unary.f32(i32 23, float %1510)  ; Log(value)
  %1514 = fmul fast float %1511, 0x4003333340000000
  %1515 = fmul fast float %1512, 0x4003333340000000
  %1516 = fmul fast float %1513, 0x4003333340000000
  %1517 = call float @dx.op.unary.f32(i32 21, float %1514)  ; Exp(value)
  %1518 = call float @dx.op.unary.f32(i32 21, float %1515)  ; Exp(value)
  %1519 = call float @dx.op.unary.f32(i32 21, float %1516)  ; Exp(value)
  %1520 = fsub fast float %1502, %1517
  %1521 = fsub fast float %1503, %1518
  %1522 = fsub fast float %1504, %1519
  %1523 = fmul fast float %1520, %1499
  %1524 = fmul fast float %1521, %1500
  %1525 = fmul fast float %1522, %1501
  %1526 = fadd fast float %1523, %1517
  %1527 = fadd fast float %1524, %1518
  %1528 = fadd fast float %1525, %1519
  br label %1597

; <label>:1529                                    ; preds = %1452
  %1530 = fadd fast float %5, 1.000000e+00
  %1531 = fadd fast float %6, 1.000000e+00
  %1532 = fsub fast float 1.000000e+00, %5
  %1533 = fmul fast float %9, %1530
  %1534 = fmul fast float %9, %1531
  %1535 = fmul fast float %9, %1532
  %1536 = fmul fast float %1533, %1490
  %1537 = fmul fast float %1534, %1491
  %1538 = fmul fast float %1535, %1492
  %1539 = fcmp fast ult float %10, 5.000000e-01
  br i1 %1539, label %1565, label %1540

; <label>:1540                                    ; preds = %1529
  %1541 = fmul fast float %1536, 0x4004147AE0000000
  %1542 = fmul fast float %1537, 0x4004147AE0000000
  %1543 = fmul fast float %1538, 0x4004147AE0000000
  %1544 = fadd fast float %1541, 0x3F9EB851E0000000
  %1545 = fadd fast float %1542, 0x3F9EB851E0000000
  %1546 = fadd fast float %1543, 0x3F9EB851E0000000
  %1547 = fmul fast float %1544, %1536
  %1548 = fmul fast float %1545, %1537
  %1549 = fmul fast float %1546, %1538
  %1550 = fmul fast float %1536, 0x400370A3E0000000
  %1551 = fmul fast float %1537, 0x400370A3E0000000
  %1552 = fmul fast float %1538, 0x400370A3E0000000
  %1553 = fadd fast float %1550, 0x3FE2E147A0000000
  %1554 = fadd fast float %1551, 0x3FE2E147A0000000
  %1555 = fadd fast float %1552, 0x3FE2E147A0000000
  %1556 = fmul fast float %1553, %1536
  %1557 = fmul fast float %1554, %1537
  %1558 = fmul fast float %1555, %1538
  %1559 = fadd fast float %1556, 0x3FC1EB8520000000
  %1560 = fadd fast float %1557, 0x3FC1EB8520000000
  %1561 = fadd fast float %1558, 0x3FC1EB8520000000
  %1562 = fdiv fast float %1547, %1559
  %1563 = fdiv fast float %1548, %1560
  %1564 = fdiv fast float %1549, %1561
  br label %1565

; <label>:1565                                    ; preds = %1540, %1529
  %1566 = phi float [ %1562, %1540 ], [ %1536, %1529 ]
  %1567 = phi float [ %1563, %1540 ], [ %1537, %1529 ]
  %1568 = phi float [ %1564, %1540 ], [ %1538, %1529 ]
  %1569 = call float @dx.op.unary.f32(i32 7, float %1566)  ; Saturate(value)
  %1570 = call float @dx.op.unary.f32(i32 7, float %1567)  ; Saturate(value)
  %1571 = call float @dx.op.unary.f32(i32 7, float %1568)  ; Saturate(value)
  %1572 = call float @dx.op.dot3.f32(i32 55, float %1569, float %1570, float %1571, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1573 = fsub fast float %1569, %1572
  %1574 = fsub fast float %1570, %1572
  %1575 = fsub fast float %1571, %1572
  %1576 = fmul fast float %1573, %8
  %1577 = fmul fast float %1574, %8
  %1578 = fmul fast float %1575, %8
  %1579 = fadd fast float %1576, %1572
  %1580 = fadd fast float %1577, %1572
  %1581 = fadd fast float %1578, %1572
  %1582 = call float @dx.op.unary.f32(i32 7, float %1579)  ; Saturate(value)
  %1583 = call float @dx.op.unary.f32(i32 7, float %1580)  ; Saturate(value)
  %1584 = call float @dx.op.unary.f32(i32 7, float %1581)  ; Saturate(value)
  %1585 = fadd fast float %1582, 0xBFC70A3D80000000
  %1586 = fadd fast float %1583, 0xBFC70A3D80000000
  %1587 = fadd fast float %1584, 0xBFC70A3D80000000
  %1588 = fmul fast float %1585, %7
  %1589 = fmul fast float %1586, %7
  %1590 = fmul fast float %1587, %7
  %1591 = fadd fast float %1588, 0x3FC70A3D80000000
  %1592 = fadd fast float %1589, 0x3FC70A3D80000000
  %1593 = fadd fast float %1590, 0x3FC70A3D80000000
  %1594 = call float @dx.op.unary.f32(i32 7, float %1591)  ; Saturate(value)
  %1595 = call float @dx.op.unary.f32(i32 7, float %1592)  ; Saturate(value)
  %1596 = call float @dx.op.unary.f32(i32 7, float %1593)  ; Saturate(value)
  br label %1597

; <label>:1597                                    ; preds = %1565, %1495
  %1598 = phi float [ %1526, %1495 ], [ %1594, %1565 ]
  %1599 = phi float [ %1527, %1495 ], [ %1595, %1565 ]
  %1600 = phi float [ %1528, %1495 ], [ %1596, %1565 ]
  %1601 = add i32 %1407, 1
  %1602 = call i32 @dx.op.binary.i32(i32 37, i32 %1601, i32 0)  ; IMax(a,b)
  %1603 = call i32 @dx.op.binary.i32(i32 38, i32 %1602, i32 %31)  ; IMin(a,b)
  %1604 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1487, i32 %1603, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1605 = extractvalue %dx.types.ResRet.f32 %1604, 0
  %1606 = extractvalue %dx.types.ResRet.f32 %1604, 1
  %1607 = extractvalue %dx.types.ResRet.f32 %1604, 2
  %1608 = extractvalue %dx.types.ResRet.f32 %1604, 3
  %1609 = fcmp fast olt float %1608, 0.000000e+00
  br i1 %1609, label %1610, label %1644

; <label>:1610                                    ; preds = %1597
  %1611 = fcmp fast ogt float %1605, 0x3FA4B5DCC0000000
  %1612 = fcmp fast ogt float %1606, 0x3FA4B5DCC0000000
  %1613 = fcmp fast ogt float %1607, 0x3FA4B5DCC0000000
  %1614 = select i1 %1611, float 0.000000e+00, float 1.000000e+00
  %1615 = select i1 %1612, float 0.000000e+00, float 1.000000e+00
  %1616 = select i1 %1613, float 0.000000e+00, float 1.000000e+00
  %1617 = fmul fast float %1605, 0x3FB3D07220000000
  %1618 = fmul fast float %1606, 0x3FB3D07220000000
  %1619 = fmul fast float %1607, 0x3FB3D07220000000
  %1620 = fadd fast float %1605, 0x3FAC28F5C0000000
  %1621 = fadd fast float %1606, 0x3FAC28F5C0000000
  %1622 = fadd fast float %1607, 0x3FAC28F5C0000000
  %1623 = fmul fast float %1620, 0x3FEE54EDE0000000
  %1624 = fmul fast float %1621, 0x3FEE54EDE0000000
  %1625 = fmul fast float %1622, 0x3FEE54EDE0000000
  %1626 = call float @dx.op.unary.f32(i32 23, float %1623)  ; Log(value)
  %1627 = call float @dx.op.unary.f32(i32 23, float %1624)  ; Log(value)
  %1628 = call float @dx.op.unary.f32(i32 23, float %1625)  ; Log(value)
  %1629 = fmul fast float %1626, 0x4003333340000000
  %1630 = fmul fast float %1627, 0x4003333340000000
  %1631 = fmul fast float %1628, 0x4003333340000000
  %1632 = call float @dx.op.unary.f32(i32 21, float %1629)  ; Exp(value)
  %1633 = call float @dx.op.unary.f32(i32 21, float %1630)  ; Exp(value)
  %1634 = call float @dx.op.unary.f32(i32 21, float %1631)  ; Exp(value)
  %1635 = fsub fast float %1617, %1632
  %1636 = fsub fast float %1618, %1633
  %1637 = fsub fast float %1619, %1634
  %1638 = fmul fast float %1635, %1614
  %1639 = fmul fast float %1636, %1615
  %1640 = fmul fast float %1637, %1616
  %1641 = fadd fast float %1638, %1632
  %1642 = fadd fast float %1639, %1633
  %1643 = fadd fast float %1640, %1634
  br label %1712

; <label>:1644                                    ; preds = %1597
  %1645 = fadd fast float %5, 1.000000e+00
  %1646 = fadd fast float %6, 1.000000e+00
  %1647 = fsub fast float 1.000000e+00, %5
  %1648 = fmul fast float %9, %1645
  %1649 = fmul fast float %9, %1646
  %1650 = fmul fast float %9, %1647
  %1651 = fmul fast float %1648, %1605
  %1652 = fmul fast float %1649, %1606
  %1653 = fmul fast float %1650, %1607
  %1654 = fcmp fast ult float %10, 5.000000e-01
  br i1 %1654, label %1680, label %1655

; <label>:1655                                    ; preds = %1644
  %1656 = fmul fast float %1651, 0x4004147AE0000000
  %1657 = fmul fast float %1652, 0x4004147AE0000000
  %1658 = fmul fast float %1653, 0x4004147AE0000000
  %1659 = fadd fast float %1656, 0x3F9EB851E0000000
  %1660 = fadd fast float %1657, 0x3F9EB851E0000000
  %1661 = fadd fast float %1658, 0x3F9EB851E0000000
  %1662 = fmul fast float %1659, %1651
  %1663 = fmul fast float %1660, %1652
  %1664 = fmul fast float %1661, %1653
  %1665 = fmul fast float %1651, 0x400370A3E0000000
  %1666 = fmul fast float %1652, 0x400370A3E0000000
  %1667 = fmul fast float %1653, 0x400370A3E0000000
  %1668 = fadd fast float %1665, 0x3FE2E147A0000000
  %1669 = fadd fast float %1666, 0x3FE2E147A0000000
  %1670 = fadd fast float %1667, 0x3FE2E147A0000000
  %1671 = fmul fast float %1668, %1651
  %1672 = fmul fast float %1669, %1652
  %1673 = fmul fast float %1670, %1653
  %1674 = fadd fast float %1671, 0x3FC1EB8520000000
  %1675 = fadd fast float %1672, 0x3FC1EB8520000000
  %1676 = fadd fast float %1673, 0x3FC1EB8520000000
  %1677 = fdiv fast float %1662, %1674
  %1678 = fdiv fast float %1663, %1675
  %1679 = fdiv fast float %1664, %1676
  br label %1680

; <label>:1680                                    ; preds = %1655, %1644
  %1681 = phi float [ %1677, %1655 ], [ %1651, %1644 ]
  %1682 = phi float [ %1678, %1655 ], [ %1652, %1644 ]
  %1683 = phi float [ %1679, %1655 ], [ %1653, %1644 ]
  %1684 = call float @dx.op.unary.f32(i32 7, float %1681)  ; Saturate(value)
  %1685 = call float @dx.op.unary.f32(i32 7, float %1682)  ; Saturate(value)
  %1686 = call float @dx.op.unary.f32(i32 7, float %1683)  ; Saturate(value)
  %1687 = call float @dx.op.dot3.f32(i32 55, float %1684, float %1685, float %1686, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1688 = fsub fast float %1684, %1687
  %1689 = fsub fast float %1685, %1687
  %1690 = fsub fast float %1686, %1687
  %1691 = fmul fast float %1688, %8
  %1692 = fmul fast float %1689, %8
  %1693 = fmul fast float %1690, %8
  %1694 = fadd fast float %1691, %1687
  %1695 = fadd fast float %1692, %1687
  %1696 = fadd fast float %1693, %1687
  %1697 = call float @dx.op.unary.f32(i32 7, float %1694)  ; Saturate(value)
  %1698 = call float @dx.op.unary.f32(i32 7, float %1695)  ; Saturate(value)
  %1699 = call float @dx.op.unary.f32(i32 7, float %1696)  ; Saturate(value)
  %1700 = fadd fast float %1697, 0xBFC70A3D80000000
  %1701 = fadd fast float %1698, 0xBFC70A3D80000000
  %1702 = fadd fast float %1699, 0xBFC70A3D80000000
  %1703 = fmul fast float %1700, %7
  %1704 = fmul fast float %1701, %7
  %1705 = fmul fast float %1702, %7
  %1706 = fadd fast float %1703, 0x3FC70A3D80000000
  %1707 = fadd fast float %1704, 0x3FC70A3D80000000
  %1708 = fadd fast float %1705, 0x3FC70A3D80000000
  %1709 = call float @dx.op.unary.f32(i32 7, float %1706)  ; Saturate(value)
  %1710 = call float @dx.op.unary.f32(i32 7, float %1707)  ; Saturate(value)
  %1711 = call float @dx.op.unary.f32(i32 7, float %1708)  ; Saturate(value)
  br label %1712

; <label>:1712                                    ; preds = %1680, %1610
  %1713 = phi float [ %1641, %1610 ], [ %1709, %1680 ]
  %1714 = phi float [ %1642, %1610 ], [ %1710, %1680 ]
  %1715 = phi float [ %1643, %1610 ], [ %1711, %1680 ]
  %1716 = add i32 %34, -1
  %1717 = call i32 @dx.op.binary.i32(i32 37, i32 %1716, i32 0)  ; IMax(a,b)
  %1718 = call i32 @dx.op.binary.i32(i32 37, i32 %1407, i32 0)  ; IMax(a,b)
  %1719 = call i32 @dx.op.binary.i32(i32 38, i32 %1717, i32 %30)  ; IMin(a,b)
  %1720 = call i32 @dx.op.binary.i32(i32 38, i32 %1718, i32 %31)  ; IMin(a,b)
  %1721 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1719, i32 %1720, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1722 = extractvalue %dx.types.ResRet.f32 %1721, 0
  %1723 = extractvalue %dx.types.ResRet.f32 %1721, 1
  %1724 = extractvalue %dx.types.ResRet.f32 %1721, 2
  %1725 = extractvalue %dx.types.ResRet.f32 %1721, 3
  %1726 = fcmp fast olt float %1725, 0.000000e+00
  br i1 %1726, label %1727, label %1761

; <label>:1727                                    ; preds = %1712
  %1728 = fcmp fast ogt float %1722, 0x3FA4B5DCC0000000
  %1729 = fcmp fast ogt float %1723, 0x3FA4B5DCC0000000
  %1730 = fcmp fast ogt float %1724, 0x3FA4B5DCC0000000
  %1731 = select i1 %1728, float 0.000000e+00, float 1.000000e+00
  %1732 = select i1 %1729, float 0.000000e+00, float 1.000000e+00
  %1733 = select i1 %1730, float 0.000000e+00, float 1.000000e+00
  %1734 = fmul fast float %1722, 0x3FB3D07220000000
  %1735 = fmul fast float %1723, 0x3FB3D07220000000
  %1736 = fmul fast float %1724, 0x3FB3D07220000000
  %1737 = fadd fast float %1722, 0x3FAC28F5C0000000
  %1738 = fadd fast float %1723, 0x3FAC28F5C0000000
  %1739 = fadd fast float %1724, 0x3FAC28F5C0000000
  %1740 = fmul fast float %1737, 0x3FEE54EDE0000000
  %1741 = fmul fast float %1738, 0x3FEE54EDE0000000
  %1742 = fmul fast float %1739, 0x3FEE54EDE0000000
  %1743 = call float @dx.op.unary.f32(i32 23, float %1740)  ; Log(value)
  %1744 = call float @dx.op.unary.f32(i32 23, float %1741)  ; Log(value)
  %1745 = call float @dx.op.unary.f32(i32 23, float %1742)  ; Log(value)
  %1746 = fmul fast float %1743, 0x4003333340000000
  %1747 = fmul fast float %1744, 0x4003333340000000
  %1748 = fmul fast float %1745, 0x4003333340000000
  %1749 = call float @dx.op.unary.f32(i32 21, float %1746)  ; Exp(value)
  %1750 = call float @dx.op.unary.f32(i32 21, float %1747)  ; Exp(value)
  %1751 = call float @dx.op.unary.f32(i32 21, float %1748)  ; Exp(value)
  %1752 = fsub fast float %1734, %1749
  %1753 = fsub fast float %1735, %1750
  %1754 = fsub fast float %1736, %1751
  %1755 = fmul fast float %1752, %1731
  %1756 = fmul fast float %1753, %1732
  %1757 = fmul fast float %1754, %1733
  %1758 = fadd fast float %1755, %1749
  %1759 = fadd fast float %1756, %1750
  %1760 = fadd fast float %1757, %1751
  br label %1829

; <label>:1761                                    ; preds = %1712
  %1762 = fadd fast float %5, 1.000000e+00
  %1763 = fadd fast float %6, 1.000000e+00
  %1764 = fsub fast float 1.000000e+00, %5
  %1765 = fmul fast float %9, %1762
  %1766 = fmul fast float %9, %1763
  %1767 = fmul fast float %9, %1764
  %1768 = fmul fast float %1765, %1722
  %1769 = fmul fast float %1766, %1723
  %1770 = fmul fast float %1767, %1724
  %1771 = fcmp fast ult float %10, 5.000000e-01
  br i1 %1771, label %1797, label %1772

; <label>:1772                                    ; preds = %1761
  %1773 = fmul fast float %1768, 0x4004147AE0000000
  %1774 = fmul fast float %1769, 0x4004147AE0000000
  %1775 = fmul fast float %1770, 0x4004147AE0000000
  %1776 = fadd fast float %1773, 0x3F9EB851E0000000
  %1777 = fadd fast float %1774, 0x3F9EB851E0000000
  %1778 = fadd fast float %1775, 0x3F9EB851E0000000
  %1779 = fmul fast float %1776, %1768
  %1780 = fmul fast float %1777, %1769
  %1781 = fmul fast float %1778, %1770
  %1782 = fmul fast float %1768, 0x400370A3E0000000
  %1783 = fmul fast float %1769, 0x400370A3E0000000
  %1784 = fmul fast float %1770, 0x400370A3E0000000
  %1785 = fadd fast float %1782, 0x3FE2E147A0000000
  %1786 = fadd fast float %1783, 0x3FE2E147A0000000
  %1787 = fadd fast float %1784, 0x3FE2E147A0000000
  %1788 = fmul fast float %1785, %1768
  %1789 = fmul fast float %1786, %1769
  %1790 = fmul fast float %1787, %1770
  %1791 = fadd fast float %1788, 0x3FC1EB8520000000
  %1792 = fadd fast float %1789, 0x3FC1EB8520000000
  %1793 = fadd fast float %1790, 0x3FC1EB8520000000
  %1794 = fdiv fast float %1779, %1791
  %1795 = fdiv fast float %1780, %1792
  %1796 = fdiv fast float %1781, %1793
  br label %1797

; <label>:1797                                    ; preds = %1772, %1761
  %1798 = phi float [ %1794, %1772 ], [ %1768, %1761 ]
  %1799 = phi float [ %1795, %1772 ], [ %1769, %1761 ]
  %1800 = phi float [ %1796, %1772 ], [ %1770, %1761 ]
  %1801 = call float @dx.op.unary.f32(i32 7, float %1798)  ; Saturate(value)
  %1802 = call float @dx.op.unary.f32(i32 7, float %1799)  ; Saturate(value)
  %1803 = call float @dx.op.unary.f32(i32 7, float %1800)  ; Saturate(value)
  %1804 = call float @dx.op.dot3.f32(i32 55, float %1801, float %1802, float %1803, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1805 = fsub fast float %1801, %1804
  %1806 = fsub fast float %1802, %1804
  %1807 = fsub fast float %1803, %1804
  %1808 = fmul fast float %1805, %8
  %1809 = fmul fast float %1806, %8
  %1810 = fmul fast float %1807, %8
  %1811 = fadd fast float %1808, %1804
  %1812 = fadd fast float %1809, %1804
  %1813 = fadd fast float %1810, %1804
  %1814 = call float @dx.op.unary.f32(i32 7, float %1811)  ; Saturate(value)
  %1815 = call float @dx.op.unary.f32(i32 7, float %1812)  ; Saturate(value)
  %1816 = call float @dx.op.unary.f32(i32 7, float %1813)  ; Saturate(value)
  %1817 = fadd fast float %1814, 0xBFC70A3D80000000
  %1818 = fadd fast float %1815, 0xBFC70A3D80000000
  %1819 = fadd fast float %1816, 0xBFC70A3D80000000
  %1820 = fmul fast float %1817, %7
  %1821 = fmul fast float %1818, %7
  %1822 = fmul fast float %1819, %7
  %1823 = fadd fast float %1820, 0x3FC70A3D80000000
  %1824 = fadd fast float %1821, 0x3FC70A3D80000000
  %1825 = fadd fast float %1822, 0x3FC70A3D80000000
  %1826 = call float @dx.op.unary.f32(i32 7, float %1823)  ; Saturate(value)
  %1827 = call float @dx.op.unary.f32(i32 7, float %1824)  ; Saturate(value)
  %1828 = call float @dx.op.unary.f32(i32 7, float %1825)  ; Saturate(value)
  br label %1829

; <label>:1829                                    ; preds = %1797, %1727
  %1830 = phi float [ %1758, %1727 ], [ %1826, %1797 ]
  %1831 = phi float [ %1759, %1727 ], [ %1827, %1797 ]
  %1832 = phi float [ %1760, %1727 ], [ %1828, %1797 ]
  %1833 = add i32 %34, 1
  %1834 = call i32 @dx.op.binary.i32(i32 37, i32 %1833, i32 0)  ; IMax(a,b)
  %1835 = call i32 @dx.op.binary.i32(i32 38, i32 %1834, i32 %30)  ; IMin(a,b)
  %1836 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1835, i32 %1720, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1837 = extractvalue %dx.types.ResRet.f32 %1836, 0
  %1838 = extractvalue %dx.types.ResRet.f32 %1836, 1
  %1839 = extractvalue %dx.types.ResRet.f32 %1836, 2
  %1840 = extractvalue %dx.types.ResRet.f32 %1836, 3
  %1841 = fcmp fast olt float %1840, 0.000000e+00
  br i1 %1841, label %1842, label %1876

; <label>:1842                                    ; preds = %1829
  %1843 = fcmp fast ogt float %1837, 0x3FA4B5DCC0000000
  %1844 = fcmp fast ogt float %1838, 0x3FA4B5DCC0000000
  %1845 = fcmp fast ogt float %1839, 0x3FA4B5DCC0000000
  %1846 = select i1 %1843, float 0.000000e+00, float 1.000000e+00
  %1847 = select i1 %1844, float 0.000000e+00, float 1.000000e+00
  %1848 = select i1 %1845, float 0.000000e+00, float 1.000000e+00
  %1849 = fmul fast float %1837, 0x3FB3D07220000000
  %1850 = fmul fast float %1838, 0x3FB3D07220000000
  %1851 = fmul fast float %1839, 0x3FB3D07220000000
  %1852 = fadd fast float %1837, 0x3FAC28F5C0000000
  %1853 = fadd fast float %1838, 0x3FAC28F5C0000000
  %1854 = fadd fast float %1839, 0x3FAC28F5C0000000
  %1855 = fmul fast float %1852, 0x3FEE54EDE0000000
  %1856 = fmul fast float %1853, 0x3FEE54EDE0000000
  %1857 = fmul fast float %1854, 0x3FEE54EDE0000000
  %1858 = call float @dx.op.unary.f32(i32 23, float %1855)  ; Log(value)
  %1859 = call float @dx.op.unary.f32(i32 23, float %1856)  ; Log(value)
  %1860 = call float @dx.op.unary.f32(i32 23, float %1857)  ; Log(value)
  %1861 = fmul fast float %1858, 0x4003333340000000
  %1862 = fmul fast float %1859, 0x4003333340000000
  %1863 = fmul fast float %1860, 0x4003333340000000
  %1864 = call float @dx.op.unary.f32(i32 21, float %1861)  ; Exp(value)
  %1865 = call float @dx.op.unary.f32(i32 21, float %1862)  ; Exp(value)
  %1866 = call float @dx.op.unary.f32(i32 21, float %1863)  ; Exp(value)
  %1867 = fsub fast float %1849, %1864
  %1868 = fsub fast float %1850, %1865
  %1869 = fsub fast float %1851, %1866
  %1870 = fmul fast float %1867, %1846
  %1871 = fmul fast float %1868, %1847
  %1872 = fmul fast float %1869, %1848
  %1873 = fadd fast float %1870, %1864
  %1874 = fadd fast float %1871, %1865
  %1875 = fadd fast float %1872, %1866
  br label %1944

; <label>:1876                                    ; preds = %1829
  %1877 = fadd fast float %5, 1.000000e+00
  %1878 = fadd fast float %6, 1.000000e+00
  %1879 = fsub fast float 1.000000e+00, %5
  %1880 = fmul fast float %9, %1877
  %1881 = fmul fast float %9, %1878
  %1882 = fmul fast float %9, %1879
  %1883 = fmul fast float %1880, %1837
  %1884 = fmul fast float %1881, %1838
  %1885 = fmul fast float %1882, %1839
  %1886 = fcmp fast ult float %10, 5.000000e-01
  br i1 %1886, label %1912, label %1887

; <label>:1887                                    ; preds = %1876
  %1888 = fmul fast float %1883, 0x4004147AE0000000
  %1889 = fmul fast float %1884, 0x4004147AE0000000
  %1890 = fmul fast float %1885, 0x4004147AE0000000
  %1891 = fadd fast float %1888, 0x3F9EB851E0000000
  %1892 = fadd fast float %1889, 0x3F9EB851E0000000
  %1893 = fadd fast float %1890, 0x3F9EB851E0000000
  %1894 = fmul fast float %1891, %1883
  %1895 = fmul fast float %1892, %1884
  %1896 = fmul fast float %1893, %1885
  %1897 = fmul fast float %1883, 0x400370A3E0000000
  %1898 = fmul fast float %1884, 0x400370A3E0000000
  %1899 = fmul fast float %1885, 0x400370A3E0000000
  %1900 = fadd fast float %1897, 0x3FE2E147A0000000
  %1901 = fadd fast float %1898, 0x3FE2E147A0000000
  %1902 = fadd fast float %1899, 0x3FE2E147A0000000
  %1903 = fmul fast float %1900, %1883
  %1904 = fmul fast float %1901, %1884
  %1905 = fmul fast float %1902, %1885
  %1906 = fadd fast float %1903, 0x3FC1EB8520000000
  %1907 = fadd fast float %1904, 0x3FC1EB8520000000
  %1908 = fadd fast float %1905, 0x3FC1EB8520000000
  %1909 = fdiv fast float %1894, %1906
  %1910 = fdiv fast float %1895, %1907
  %1911 = fdiv fast float %1896, %1908
  br label %1912

; <label>:1912                                    ; preds = %1887, %1876
  %1913 = phi float [ %1909, %1887 ], [ %1883, %1876 ]
  %1914 = phi float [ %1910, %1887 ], [ %1884, %1876 ]
  %1915 = phi float [ %1911, %1887 ], [ %1885, %1876 ]
  %1916 = call float @dx.op.unary.f32(i32 7, float %1913)  ; Saturate(value)
  %1917 = call float @dx.op.unary.f32(i32 7, float %1914)  ; Saturate(value)
  %1918 = call float @dx.op.unary.f32(i32 7, float %1915)  ; Saturate(value)
  %1919 = call float @dx.op.dot3.f32(i32 55, float %1916, float %1917, float %1918, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1920 = fsub fast float %1916, %1919
  %1921 = fsub fast float %1917, %1919
  %1922 = fsub fast float %1918, %1919
  %1923 = fmul fast float %1920, %8
  %1924 = fmul fast float %1921, %8
  %1925 = fmul fast float %1922, %8
  %1926 = fadd fast float %1923, %1919
  %1927 = fadd fast float %1924, %1919
  %1928 = fadd fast float %1925, %1919
  %1929 = call float @dx.op.unary.f32(i32 7, float %1926)  ; Saturate(value)
  %1930 = call float @dx.op.unary.f32(i32 7, float %1927)  ; Saturate(value)
  %1931 = call float @dx.op.unary.f32(i32 7, float %1928)  ; Saturate(value)
  %1932 = fadd fast float %1929, 0xBFC70A3D80000000
  %1933 = fadd fast float %1930, 0xBFC70A3D80000000
  %1934 = fadd fast float %1931, 0xBFC70A3D80000000
  %1935 = fmul fast float %1932, %7
  %1936 = fmul fast float %1933, %7
  %1937 = fmul fast float %1934, %7
  %1938 = fadd fast float %1935, 0x3FC70A3D80000000
  %1939 = fadd fast float %1936, 0x3FC70A3D80000000
  %1940 = fadd fast float %1937, 0x3FC70A3D80000000
  %1941 = call float @dx.op.unary.f32(i32 7, float %1938)  ; Saturate(value)
  %1942 = call float @dx.op.unary.f32(i32 7, float %1939)  ; Saturate(value)
  %1943 = call float @dx.op.unary.f32(i32 7, float %1940)  ; Saturate(value)
  br label %1944

; <label>:1944                                    ; preds = %1912, %1842
  %1945 = phi float [ %1873, %1842 ], [ %1941, %1912 ]
  %1946 = phi float [ %1874, %1842 ], [ %1942, %1912 ]
  %1947 = phi float [ %1875, %1842 ], [ %1943, %1912 ]
  %1948 = call float @dx.op.binary.f32(i32 36, float %1830, float %1945)  ; FMin(a,b)
  %1949 = call float @dx.op.binary.f32(i32 36, float %1831, float %1946)  ; FMin(a,b)
  %1950 = call float @dx.op.binary.f32(i32 36, float %1832, float %1947)  ; FMin(a,b)
  %1951 = call float @dx.op.binary.f32(i32 36, float %1598, float %1713)  ; FMin(a,b)
  %1952 = call float @dx.op.binary.f32(i32 36, float %1599, float %1714)  ; FMin(a,b)
  %1953 = call float @dx.op.binary.f32(i32 36, float %1600, float %1715)  ; FMin(a,b)
  %1954 = call float @dx.op.binary.f32(i32 36, float %1951, float %1948)  ; FMin(a,b)
  %1955 = call float @dx.op.binary.f32(i32 36, float %1952, float %1949)  ; FMin(a,b)
  %1956 = call float @dx.op.binary.f32(i32 36, float %1953, float %1950)  ; FMin(a,b)
  %1957 = call float @dx.op.binary.f32(i32 36, float %1481, float %1954)  ; FMin(a,b)
  %1958 = call float @dx.op.binary.f32(i32 36, float %1482, float %1955)  ; FMin(a,b)
  %1959 = call float @dx.op.binary.f32(i32 36, float %1483, float %1956)  ; FMin(a,b)
  %1960 = call float @dx.op.binary.f32(i32 35, float %1830, float %1945)  ; FMax(a,b)
  %1961 = call float @dx.op.binary.f32(i32 35, float %1831, float %1946)  ; FMax(a,b)
  %1962 = call float @dx.op.binary.f32(i32 35, float %1832, float %1947)  ; FMax(a,b)
  %1963 = call float @dx.op.binary.f32(i32 35, float %1598, float %1713)  ; FMax(a,b)
  %1964 = call float @dx.op.binary.f32(i32 35, float %1599, float %1714)  ; FMax(a,b)
  %1965 = call float @dx.op.binary.f32(i32 35, float %1600, float %1715)  ; FMax(a,b)
  %1966 = call float @dx.op.binary.f32(i32 35, float %1963, float %1960)  ; FMax(a,b)
  %1967 = call float @dx.op.binary.f32(i32 35, float %1964, float %1961)  ; FMax(a,b)
  %1968 = call float @dx.op.binary.f32(i32 35, float %1965, float %1962)  ; FMax(a,b)
  %1969 = call float @dx.op.binary.f32(i32 35, float %1481, float %1966)  ; FMax(a,b)
  %1970 = call float @dx.op.binary.f32(i32 35, float %1482, float %1967)  ; FMax(a,b)
  %1971 = call float @dx.op.binary.f32(i32 35, float %1483, float %1968)  ; FMax(a,b)
  %1972 = fsub fast float %1969, %1957
  %1973 = fsub fast float %1970, %1958
  %1974 = fsub fast float %1971, %1959
  %1975 = call float @dx.op.unary.f32(i32 6, float %1972)  ; FAbs(value)
  %1976 = call float @dx.op.unary.f32(i32 6, float %1973)  ; FAbs(value)
  %1977 = call float @dx.op.unary.f32(i32 6, float %1974)  ; FAbs(value)
  %1978 = call float @dx.op.binary.f32(i32 35, float %1976, float %1977)  ; FMax(a,b)
  %1979 = call float @dx.op.binary.f32(i32 35, float %1975, float %1978)  ; FMax(a,b)
  %1980 = call float @dx.op.binary.f32(i32 35, float %1970, float %1971)  ; FMax(a,b)
  %1981 = call float @dx.op.binary.f32(i32 35, float %1969, float %1980)  ; FMax(a,b)
  %1982 = fmul fast float %1981, 1.250000e-01
  %1983 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1982)  ; FMax(a,b)
  %1984 = fcmp fast ogt float %1979, %1983
  br i1 %1984, label %1985, label %2046

; <label>:1985                                    ; preds = %1944
  %1986 = fsub fast float %1598, %1713
  %1987 = fsub fast float %1599, %1714
  %1988 = fsub fast float %1600, %1715
  %1989 = call float @dx.op.unary.f32(i32 6, float %1986)  ; FAbs(value)
  %1990 = call float @dx.op.unary.f32(i32 6, float %1987)  ; FAbs(value)
  %1991 = call float @dx.op.unary.f32(i32 6, float %1988)  ; FAbs(value)
  %1992 = call float @dx.op.binary.f32(i32 35, float %1990, float %1991)  ; FMax(a,b)
  %1993 = call float @dx.op.binary.f32(i32 35, float %1989, float %1992)  ; FMax(a,b)
  %1994 = fsub fast float %1830, %1945
  %1995 = fsub fast float %1831, %1946
  %1996 = fsub fast float %1832, %1947
  %1997 = call float @dx.op.unary.f32(i32 6, float %1994)  ; FAbs(value)
  %1998 = call float @dx.op.unary.f32(i32 6, float %1995)  ; FAbs(value)
  %1999 = call float @dx.op.unary.f32(i32 6, float %1996)  ; FAbs(value)
  %2000 = call float @dx.op.binary.f32(i32 35, float %1998, float %1999)  ; FMax(a,b)
  %2001 = call float @dx.op.binary.f32(i32 35, float %1997, float %2000)  ; FMax(a,b)
  %2002 = fcmp fast olt float %1993, %2001
  %2003 = select i1 %2002, float %1598, float %1830
  %2004 = select i1 %2002, float %1599, float %1831
  %2005 = select i1 %2002, float %1600, float %1832
  %2006 = select i1 %2002, float %1713, float %1945
  %2007 = select i1 %2002, float %1714, float %1946
  %2008 = select i1 %2002, float %1715, float %1947
  %2009 = fsub fast float %1481, %2006
  %2010 = fsub fast float %1482, %2007
  %2011 = fsub fast float %1483, %2008
  %2012 = fsub fast float %1481, %2003
  %2013 = fsub fast float %1482, %2004
  %2014 = fsub fast float %1483, %2005
  %2015 = call float @dx.op.dot3.f32(i32 55, float %2012, float %2013, float %2014, float %2009, float %2010, float %2011)  ; Dot3(ax,ay,az,bx,by,bz)
  %2016 = fcmp fast ogt float %2015, 0.000000e+00
  br i1 %2016, label %2017, label %2028

; <label>:2017                                    ; preds = %1985
  %2018 = fsub fast float %2003, %2006
  %2019 = fsub fast float %2004, %2007
  %2020 = fsub fast float %2005, %2008
  %2021 = call float @dx.op.unary.f32(i32 6, float %2018)  ; FAbs(value)
  %2022 = call float @dx.op.unary.f32(i32 6, float %2019)  ; FAbs(value)
  %2023 = call float @dx.op.unary.f32(i32 6, float %2020)  ; FAbs(value)
  %2024 = call float @dx.op.binary.f32(i32 35, float %2022, float %2023)  ; FMax(a,b)
  %2025 = call float @dx.op.binary.f32(i32 35, float %2021, float %2024)  ; FMax(a,b)
  %2026 = fmul fast float %1979, 2.500000e-01
  %2027 = fcmp fast olt float %2025, %2026
  br label %2028

; <label>:2028                                    ; preds = %2017, %1985
  %2029 = phi i1 [ false, %1985 ], [ %2027, %2017 ]
  %2030 = select i1 %2029, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  %2031 = fadd fast float %2003, %2006
  %2032 = fadd fast float %2004, %2007
  %2033 = fadd fast float %2005, %2008
  %2034 = fmul fast float %2031, 5.000000e-01
  %2035 = fmul fast float %2032, 5.000000e-01
  %2036 = fmul fast float %2033, 5.000000e-01
  %2037 = fsub fast float %2034, %1481
  %2038 = fsub fast float %2035, %1482
  %2039 = fsub fast float %2036, %1483
  %2040 = fmul fast float %2030, %2037
  %2041 = fmul fast float %2030, %2038
  %2042 = fmul fast float %2030, %2039
  %2043 = fadd fast float %2040, %1481
  %2044 = fadd fast float %2041, %1482
  %2045 = fadd fast float %2042, %1483
  br label %2046

; <label>:2046                                    ; preds = %2028, %1944
  %2047 = phi float [ %2043, %2028 ], [ %1481, %1944 ]
  %2048 = phi float [ %2044, %2028 ], [ %1482, %1944 ]
  %2049 = phi float [ %2045, %2028 ], [ %1483, %1944 ]
  %2050 = fcmp fast ogt float %2047, 0x3F69A5C380000000
  %2051 = fcmp fast ogt float %2048, 0x3F69A5C380000000
  %2052 = fcmp fast ogt float %2049, 0x3F69A5C380000000
  %2053 = select i1 %2050, float 0.000000e+00, float 1.000000e+00
  %2054 = select i1 %2051, float 0.000000e+00, float 1.000000e+00
  %2055 = select i1 %2052, float 0.000000e+00, float 1.000000e+00
  %2056 = fmul fast float %2047, 0x4029D70A40000000
  %2057 = fmul fast float %2048, 0x4029D70A40000000
  %2058 = fmul fast float %2049, 0x4029D70A40000000
  %2059 = call float @dx.op.binary.f32(i32 35, float %2047, float 0.000000e+00)  ; FMax(a,b)
  %2060 = call float @dx.op.binary.f32(i32 35, float %2048, float 0.000000e+00)  ; FMax(a,b)
  %2061 = call float @dx.op.binary.f32(i32 35, float %2049, float 0.000000e+00)  ; FMax(a,b)
  %2062 = call float @dx.op.unary.f32(i32 23, float %2059)  ; Log(value)
  %2063 = call float @dx.op.unary.f32(i32 23, float %2060)  ; Log(value)
  %2064 = call float @dx.op.unary.f32(i32 23, float %2061)  ; Log(value)
  %2065 = fmul fast float %2062, 0x3FDAAAAAA0000000
  %2066 = fmul fast float %2063, 0x3FDAAAAAA0000000
  %2067 = fmul fast float %2064, 0x3FDAAAAAA0000000
  %2068 = call float @dx.op.unary.f32(i32 21, float %2065)  ; Exp(value)
  %2069 = call float @dx.op.unary.f32(i32 21, float %2066)  ; Exp(value)
  %2070 = call float @dx.op.unary.f32(i32 21, float %2067)  ; Exp(value)
  %2071 = fmul fast float %2068, 0x3FF0E147A0000000
  %2072 = fmul fast float %2069, 0x3FF0E147A0000000
  %2073 = fmul fast float %2070, 0x3FF0E147A0000000
  %2074 = fadd fast float %2071, 0xBFAC28F5C0000000
  %2075 = fadd fast float %2072, 0xBFAC28F5C0000000
  %2076 = fadd fast float %2073, 0xBFAC28F5C0000000
  %2077 = fsub fast float %2056, %2074
  %2078 = fsub fast float %2057, %2075
  %2079 = fsub fast float %2058, %2076
  %2080 = fmul fast float %2077, %2053
  %2081 = fmul fast float %2078, %2054
  %2082 = fmul fast float %2079, %2055
  %2083 = fadd fast float %2080, %2074
  %2084 = fadd fast float %2081, %2075
  %2085 = fadd fast float %2082, %2076
  br label %2086

; <label>:2086                                    ; preds = %2046, %1414
  %2087 = phi float [ %1409, %1414 ], [ %2083, %2046 ]
  %2088 = phi float [ %1410, %1414 ], [ %2084, %2046 ]
  %2089 = phi float [ %1411, %1414 ], [ %2085, %2046 ]
  %2090 = phi float [ %1415, %1414 ], [ %1412, %2046 ]
  %2091 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %721, i32 %1407, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2092 = extractvalue %dx.types.ResRet.f32 %2091, 0
  %2093 = extractvalue %dx.types.ResRet.f32 %2091, 1
  %2094 = extractvalue %dx.types.ResRet.f32 %2091, 2
  %2095 = extractvalue %dx.types.ResRet.f32 %2091, 3
  %2096 = fcmp fast olt float %2095, 0.000000e+00
  br i1 %2096, label %2097, label %2099

; <label>:2097                                    ; preds = %2086
  %2098 = fsub fast float -1.000000e+00, %2095
  br label %2769

; <label>:2099                                    ; preds = %2086
  %2100 = fadd fast float %5, 1.000000e+00
  %2101 = fadd fast float %6, 1.000000e+00
  %2102 = fsub fast float 1.000000e+00, %5
  %2103 = fmul fast float %9, %2100
  %2104 = fmul fast float %9, %2101
  %2105 = fmul fast float %9, %2102
  %2106 = fmul fast float %2103, %2092
  %2107 = fmul fast float %2104, %2093
  %2108 = fmul fast float %2105, %2094
  %2109 = fcmp fast ult float %10, 5.000000e-01
  br i1 %2109, label %2135, label %2110

; <label>:2110                                    ; preds = %2099
  %2111 = fmul fast float %2106, 0x4004147AE0000000
  %2112 = fmul fast float %2107, 0x4004147AE0000000
  %2113 = fmul fast float %2108, 0x4004147AE0000000
  %2114 = fadd fast float %2111, 0x3F9EB851E0000000
  %2115 = fadd fast float %2112, 0x3F9EB851E0000000
  %2116 = fadd fast float %2113, 0x3F9EB851E0000000
  %2117 = fmul fast float %2114, %2106
  %2118 = fmul fast float %2115, %2107
  %2119 = fmul fast float %2116, %2108
  %2120 = fmul fast float %2106, 0x400370A3E0000000
  %2121 = fmul fast float %2107, 0x400370A3E0000000
  %2122 = fmul fast float %2108, 0x400370A3E0000000
  %2123 = fadd fast float %2120, 0x3FE2E147A0000000
  %2124 = fadd fast float %2121, 0x3FE2E147A0000000
  %2125 = fadd fast float %2122, 0x3FE2E147A0000000
  %2126 = fmul fast float %2123, %2106
  %2127 = fmul fast float %2124, %2107
  %2128 = fmul fast float %2125, %2108
  %2129 = fadd fast float %2126, 0x3FC1EB8520000000
  %2130 = fadd fast float %2127, 0x3FC1EB8520000000
  %2131 = fadd fast float %2128, 0x3FC1EB8520000000
  %2132 = fdiv fast float %2117, %2129
  %2133 = fdiv fast float %2118, %2130
  %2134 = fdiv fast float %2119, %2131
  br label %2135

; <label>:2135                                    ; preds = %2110, %2099
  %2136 = phi float [ %2132, %2110 ], [ %2106, %2099 ]
  %2137 = phi float [ %2133, %2110 ], [ %2107, %2099 ]
  %2138 = phi float [ %2134, %2110 ], [ %2108, %2099 ]
  %2139 = call float @dx.op.unary.f32(i32 7, float %2136)  ; Saturate(value)
  %2140 = call float @dx.op.unary.f32(i32 7, float %2137)  ; Saturate(value)
  %2141 = call float @dx.op.unary.f32(i32 7, float %2138)  ; Saturate(value)
  %2142 = call float @dx.op.dot3.f32(i32 55, float %2139, float %2140, float %2141, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2143 = fsub fast float %2139, %2142
  %2144 = fsub fast float %2140, %2142
  %2145 = fsub fast float %2141, %2142
  %2146 = fmul fast float %2143, %8
  %2147 = fmul fast float %2144, %8
  %2148 = fmul fast float %2145, %8
  %2149 = fadd fast float %2146, %2142
  %2150 = fadd fast float %2147, %2142
  %2151 = fadd fast float %2148, %2142
  %2152 = call float @dx.op.unary.f32(i32 7, float %2149)  ; Saturate(value)
  %2153 = call float @dx.op.unary.f32(i32 7, float %2150)  ; Saturate(value)
  %2154 = call float @dx.op.unary.f32(i32 7, float %2151)  ; Saturate(value)
  %2155 = fadd fast float %2152, 0xBFC70A3D80000000
  %2156 = fadd fast float %2153, 0xBFC70A3D80000000
  %2157 = fadd fast float %2154, 0xBFC70A3D80000000
  %2158 = fmul fast float %2155, %7
  %2159 = fmul fast float %2156, %7
  %2160 = fmul fast float %2157, %7
  %2161 = fadd fast float %2158, 0x3FC70A3D80000000
  %2162 = fadd fast float %2159, 0x3FC70A3D80000000
  %2163 = fadd fast float %2160, 0x3FC70A3D80000000
  %2164 = call float @dx.op.unary.f32(i32 7, float %2161)  ; Saturate(value)
  %2165 = call float @dx.op.unary.f32(i32 7, float %2162)  ; Saturate(value)
  %2166 = call float @dx.op.unary.f32(i32 7, float %2163)  ; Saturate(value)
  %2167 = add i32 %1407, -1
  %2168 = call i32 @dx.op.binary.i32(i32 37, i32 %721, i32 0)  ; IMax(a,b)
  %2169 = call i32 @dx.op.binary.i32(i32 37, i32 %2167, i32 0)  ; IMax(a,b)
  %2170 = call i32 @dx.op.binary.i32(i32 38, i32 %2168, i32 %30)  ; IMin(a,b)
  %2171 = call i32 @dx.op.binary.i32(i32 38, i32 %2169, i32 %31)  ; IMin(a,b)
  %2172 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2170, i32 %2171, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2173 = extractvalue %dx.types.ResRet.f32 %2172, 0
  %2174 = extractvalue %dx.types.ResRet.f32 %2172, 1
  %2175 = extractvalue %dx.types.ResRet.f32 %2172, 2
  %2176 = extractvalue %dx.types.ResRet.f32 %2172, 3
  %2177 = fcmp fast olt float %2176, 0.000000e+00
  br i1 %2177, label %2178, label %2212

; <label>:2178                                    ; preds = %2135
  %2179 = fcmp fast ogt float %2173, 0x3FA4B5DCC0000000
  %2180 = fcmp fast ogt float %2174, 0x3FA4B5DCC0000000
  %2181 = fcmp fast ogt float %2175, 0x3FA4B5DCC0000000
  %2182 = select i1 %2179, float 0.000000e+00, float 1.000000e+00
  %2183 = select i1 %2180, float 0.000000e+00, float 1.000000e+00
  %2184 = select i1 %2181, float 0.000000e+00, float 1.000000e+00
  %2185 = fmul fast float %2173, 0x3FB3D07220000000
  %2186 = fmul fast float %2174, 0x3FB3D07220000000
  %2187 = fmul fast float %2175, 0x3FB3D07220000000
  %2188 = fadd fast float %2173, 0x3FAC28F5C0000000
  %2189 = fadd fast float %2174, 0x3FAC28F5C0000000
  %2190 = fadd fast float %2175, 0x3FAC28F5C0000000
  %2191 = fmul fast float %2188, 0x3FEE54EDE0000000
  %2192 = fmul fast float %2189, 0x3FEE54EDE0000000
  %2193 = fmul fast float %2190, 0x3FEE54EDE0000000
  %2194 = call float @dx.op.unary.f32(i32 23, float %2191)  ; Log(value)
  %2195 = call float @dx.op.unary.f32(i32 23, float %2192)  ; Log(value)
  %2196 = call float @dx.op.unary.f32(i32 23, float %2193)  ; Log(value)
  %2197 = fmul fast float %2194, 0x4003333340000000
  %2198 = fmul fast float %2195, 0x4003333340000000
  %2199 = fmul fast float %2196, 0x4003333340000000
  %2200 = call float @dx.op.unary.f32(i32 21, float %2197)  ; Exp(value)
  %2201 = call float @dx.op.unary.f32(i32 21, float %2198)  ; Exp(value)
  %2202 = call float @dx.op.unary.f32(i32 21, float %2199)  ; Exp(value)
  %2203 = fsub fast float %2185, %2200
  %2204 = fsub fast float %2186, %2201
  %2205 = fsub fast float %2187, %2202
  %2206 = fmul fast float %2203, %2182
  %2207 = fmul fast float %2204, %2183
  %2208 = fmul fast float %2205, %2184
  %2209 = fadd fast float %2206, %2200
  %2210 = fadd fast float %2207, %2201
  %2211 = fadd fast float %2208, %2202
  br label %2280

; <label>:2212                                    ; preds = %2135
  %2213 = fadd fast float %5, 1.000000e+00
  %2214 = fadd fast float %6, 1.000000e+00
  %2215 = fsub fast float 1.000000e+00, %5
  %2216 = fmul fast float %9, %2213
  %2217 = fmul fast float %9, %2214
  %2218 = fmul fast float %9, %2215
  %2219 = fmul fast float %2216, %2173
  %2220 = fmul fast float %2217, %2174
  %2221 = fmul fast float %2218, %2175
  %2222 = fcmp fast ult float %10, 5.000000e-01
  br i1 %2222, label %2248, label %2223

; <label>:2223                                    ; preds = %2212
  %2224 = fmul fast float %2219, 0x4004147AE0000000
  %2225 = fmul fast float %2220, 0x4004147AE0000000
  %2226 = fmul fast float %2221, 0x4004147AE0000000
  %2227 = fadd fast float %2224, 0x3F9EB851E0000000
  %2228 = fadd fast float %2225, 0x3F9EB851E0000000
  %2229 = fadd fast float %2226, 0x3F9EB851E0000000
  %2230 = fmul fast float %2227, %2219
  %2231 = fmul fast float %2228, %2220
  %2232 = fmul fast float %2229, %2221
  %2233 = fmul fast float %2219, 0x400370A3E0000000
  %2234 = fmul fast float %2220, 0x400370A3E0000000
  %2235 = fmul fast float %2221, 0x400370A3E0000000
  %2236 = fadd fast float %2233, 0x3FE2E147A0000000
  %2237 = fadd fast float %2234, 0x3FE2E147A0000000
  %2238 = fadd fast float %2235, 0x3FE2E147A0000000
  %2239 = fmul fast float %2236, %2219
  %2240 = fmul fast float %2237, %2220
  %2241 = fmul fast float %2238, %2221
  %2242 = fadd fast float %2239, 0x3FC1EB8520000000
  %2243 = fadd fast float %2240, 0x3FC1EB8520000000
  %2244 = fadd fast float %2241, 0x3FC1EB8520000000
  %2245 = fdiv fast float %2230, %2242
  %2246 = fdiv fast float %2231, %2243
  %2247 = fdiv fast float %2232, %2244
  br label %2248

; <label>:2248                                    ; preds = %2223, %2212
  %2249 = phi float [ %2245, %2223 ], [ %2219, %2212 ]
  %2250 = phi float [ %2246, %2223 ], [ %2220, %2212 ]
  %2251 = phi float [ %2247, %2223 ], [ %2221, %2212 ]
  %2252 = call float @dx.op.unary.f32(i32 7, float %2249)  ; Saturate(value)
  %2253 = call float @dx.op.unary.f32(i32 7, float %2250)  ; Saturate(value)
  %2254 = call float @dx.op.unary.f32(i32 7, float %2251)  ; Saturate(value)
  %2255 = call float @dx.op.dot3.f32(i32 55, float %2252, float %2253, float %2254, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2256 = fsub fast float %2252, %2255
  %2257 = fsub fast float %2253, %2255
  %2258 = fsub fast float %2254, %2255
  %2259 = fmul fast float %2256, %8
  %2260 = fmul fast float %2257, %8
  %2261 = fmul fast float %2258, %8
  %2262 = fadd fast float %2259, %2255
  %2263 = fadd fast float %2260, %2255
  %2264 = fadd fast float %2261, %2255
  %2265 = call float @dx.op.unary.f32(i32 7, float %2262)  ; Saturate(value)
  %2266 = call float @dx.op.unary.f32(i32 7, float %2263)  ; Saturate(value)
  %2267 = call float @dx.op.unary.f32(i32 7, float %2264)  ; Saturate(value)
  %2268 = fadd fast float %2265, 0xBFC70A3D80000000
  %2269 = fadd fast float %2266, 0xBFC70A3D80000000
  %2270 = fadd fast float %2267, 0xBFC70A3D80000000
  %2271 = fmul fast float %2268, %7
  %2272 = fmul fast float %2269, %7
  %2273 = fmul fast float %2270, %7
  %2274 = fadd fast float %2271, 0x3FC70A3D80000000
  %2275 = fadd fast float %2272, 0x3FC70A3D80000000
  %2276 = fadd fast float %2273, 0x3FC70A3D80000000
  %2277 = call float @dx.op.unary.f32(i32 7, float %2274)  ; Saturate(value)
  %2278 = call float @dx.op.unary.f32(i32 7, float %2275)  ; Saturate(value)
  %2279 = call float @dx.op.unary.f32(i32 7, float %2276)  ; Saturate(value)
  br label %2280

; <label>:2280                                    ; preds = %2248, %2178
  %2281 = phi float [ %2209, %2178 ], [ %2277, %2248 ]
  %2282 = phi float [ %2210, %2178 ], [ %2278, %2248 ]
  %2283 = phi float [ %2211, %2178 ], [ %2279, %2248 ]
  %2284 = add i32 %1407, 1
  %2285 = call i32 @dx.op.binary.i32(i32 37, i32 %2284, i32 0)  ; IMax(a,b)
  %2286 = call i32 @dx.op.binary.i32(i32 38, i32 %2285, i32 %31)  ; IMin(a,b)
  %2287 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2170, i32 %2286, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2288 = extractvalue %dx.types.ResRet.f32 %2287, 0
  %2289 = extractvalue %dx.types.ResRet.f32 %2287, 1
  %2290 = extractvalue %dx.types.ResRet.f32 %2287, 2
  %2291 = extractvalue %dx.types.ResRet.f32 %2287, 3
  %2292 = fcmp fast olt float %2291, 0.000000e+00
  br i1 %2292, label %2293, label %2327

; <label>:2293                                    ; preds = %2280
  %2294 = fcmp fast ogt float %2288, 0x3FA4B5DCC0000000
  %2295 = fcmp fast ogt float %2289, 0x3FA4B5DCC0000000
  %2296 = fcmp fast ogt float %2290, 0x3FA4B5DCC0000000
  %2297 = select i1 %2294, float 0.000000e+00, float 1.000000e+00
  %2298 = select i1 %2295, float 0.000000e+00, float 1.000000e+00
  %2299 = select i1 %2296, float 0.000000e+00, float 1.000000e+00
  %2300 = fmul fast float %2288, 0x3FB3D07220000000
  %2301 = fmul fast float %2289, 0x3FB3D07220000000
  %2302 = fmul fast float %2290, 0x3FB3D07220000000
  %2303 = fadd fast float %2288, 0x3FAC28F5C0000000
  %2304 = fadd fast float %2289, 0x3FAC28F5C0000000
  %2305 = fadd fast float %2290, 0x3FAC28F5C0000000
  %2306 = fmul fast float %2303, 0x3FEE54EDE0000000
  %2307 = fmul fast float %2304, 0x3FEE54EDE0000000
  %2308 = fmul fast float %2305, 0x3FEE54EDE0000000
  %2309 = call float @dx.op.unary.f32(i32 23, float %2306)  ; Log(value)
  %2310 = call float @dx.op.unary.f32(i32 23, float %2307)  ; Log(value)
  %2311 = call float @dx.op.unary.f32(i32 23, float %2308)  ; Log(value)
  %2312 = fmul fast float %2309, 0x4003333340000000
  %2313 = fmul fast float %2310, 0x4003333340000000
  %2314 = fmul fast float %2311, 0x4003333340000000
  %2315 = call float @dx.op.unary.f32(i32 21, float %2312)  ; Exp(value)
  %2316 = call float @dx.op.unary.f32(i32 21, float %2313)  ; Exp(value)
  %2317 = call float @dx.op.unary.f32(i32 21, float %2314)  ; Exp(value)
  %2318 = fsub fast float %2300, %2315
  %2319 = fsub fast float %2301, %2316
  %2320 = fsub fast float %2302, %2317
  %2321 = fmul fast float %2318, %2297
  %2322 = fmul fast float %2319, %2298
  %2323 = fmul fast float %2320, %2299
  %2324 = fadd fast float %2321, %2315
  %2325 = fadd fast float %2322, %2316
  %2326 = fadd fast float %2323, %2317
  br label %2395

; <label>:2327                                    ; preds = %2280
  %2328 = fadd fast float %5, 1.000000e+00
  %2329 = fadd fast float %6, 1.000000e+00
  %2330 = fsub fast float 1.000000e+00, %5
  %2331 = fmul fast float %9, %2328
  %2332 = fmul fast float %9, %2329
  %2333 = fmul fast float %9, %2330
  %2334 = fmul fast float %2331, %2288
  %2335 = fmul fast float %2332, %2289
  %2336 = fmul fast float %2333, %2290
  %2337 = fcmp fast ult float %10, 5.000000e-01
  br i1 %2337, label %2363, label %2338

; <label>:2338                                    ; preds = %2327
  %2339 = fmul fast float %2334, 0x4004147AE0000000
  %2340 = fmul fast float %2335, 0x4004147AE0000000
  %2341 = fmul fast float %2336, 0x4004147AE0000000
  %2342 = fadd fast float %2339, 0x3F9EB851E0000000
  %2343 = fadd fast float %2340, 0x3F9EB851E0000000
  %2344 = fadd fast float %2341, 0x3F9EB851E0000000
  %2345 = fmul fast float %2342, %2334
  %2346 = fmul fast float %2343, %2335
  %2347 = fmul fast float %2344, %2336
  %2348 = fmul fast float %2334, 0x400370A3E0000000
  %2349 = fmul fast float %2335, 0x400370A3E0000000
  %2350 = fmul fast float %2336, 0x400370A3E0000000
  %2351 = fadd fast float %2348, 0x3FE2E147A0000000
  %2352 = fadd fast float %2349, 0x3FE2E147A0000000
  %2353 = fadd fast float %2350, 0x3FE2E147A0000000
  %2354 = fmul fast float %2351, %2334
  %2355 = fmul fast float %2352, %2335
  %2356 = fmul fast float %2353, %2336
  %2357 = fadd fast float %2354, 0x3FC1EB8520000000
  %2358 = fadd fast float %2355, 0x3FC1EB8520000000
  %2359 = fadd fast float %2356, 0x3FC1EB8520000000
  %2360 = fdiv fast float %2345, %2357
  %2361 = fdiv fast float %2346, %2358
  %2362 = fdiv fast float %2347, %2359
  br label %2363

; <label>:2363                                    ; preds = %2338, %2327
  %2364 = phi float [ %2360, %2338 ], [ %2334, %2327 ]
  %2365 = phi float [ %2361, %2338 ], [ %2335, %2327 ]
  %2366 = phi float [ %2362, %2338 ], [ %2336, %2327 ]
  %2367 = call float @dx.op.unary.f32(i32 7, float %2364)  ; Saturate(value)
  %2368 = call float @dx.op.unary.f32(i32 7, float %2365)  ; Saturate(value)
  %2369 = call float @dx.op.unary.f32(i32 7, float %2366)  ; Saturate(value)
  %2370 = call float @dx.op.dot3.f32(i32 55, float %2367, float %2368, float %2369, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2371 = fsub fast float %2367, %2370
  %2372 = fsub fast float %2368, %2370
  %2373 = fsub fast float %2369, %2370
  %2374 = fmul fast float %2371, %8
  %2375 = fmul fast float %2372, %8
  %2376 = fmul fast float %2373, %8
  %2377 = fadd fast float %2374, %2370
  %2378 = fadd fast float %2375, %2370
  %2379 = fadd fast float %2376, %2370
  %2380 = call float @dx.op.unary.f32(i32 7, float %2377)  ; Saturate(value)
  %2381 = call float @dx.op.unary.f32(i32 7, float %2378)  ; Saturate(value)
  %2382 = call float @dx.op.unary.f32(i32 7, float %2379)  ; Saturate(value)
  %2383 = fadd fast float %2380, 0xBFC70A3D80000000
  %2384 = fadd fast float %2381, 0xBFC70A3D80000000
  %2385 = fadd fast float %2382, 0xBFC70A3D80000000
  %2386 = fmul fast float %2383, %7
  %2387 = fmul fast float %2384, %7
  %2388 = fmul fast float %2385, %7
  %2389 = fadd fast float %2386, 0x3FC70A3D80000000
  %2390 = fadd fast float %2387, 0x3FC70A3D80000000
  %2391 = fadd fast float %2388, 0x3FC70A3D80000000
  %2392 = call float @dx.op.unary.f32(i32 7, float %2389)  ; Saturate(value)
  %2393 = call float @dx.op.unary.f32(i32 7, float %2390)  ; Saturate(value)
  %2394 = call float @dx.op.unary.f32(i32 7, float %2391)  ; Saturate(value)
  br label %2395

; <label>:2395                                    ; preds = %2363, %2293
  %2396 = phi float [ %2324, %2293 ], [ %2392, %2363 ]
  %2397 = phi float [ %2325, %2293 ], [ %2393, %2363 ]
  %2398 = phi float [ %2326, %2293 ], [ %2394, %2363 ]
  %2399 = add i32 %721, -1
  %2400 = call i32 @dx.op.binary.i32(i32 37, i32 %2399, i32 0)  ; IMax(a,b)
  %2401 = call i32 @dx.op.binary.i32(i32 37, i32 %1407, i32 0)  ; IMax(a,b)
  %2402 = call i32 @dx.op.binary.i32(i32 38, i32 %2400, i32 %30)  ; IMin(a,b)
  %2403 = call i32 @dx.op.binary.i32(i32 38, i32 %2401, i32 %31)  ; IMin(a,b)
  %2404 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2402, i32 %2403, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2405 = extractvalue %dx.types.ResRet.f32 %2404, 0
  %2406 = extractvalue %dx.types.ResRet.f32 %2404, 1
  %2407 = extractvalue %dx.types.ResRet.f32 %2404, 2
  %2408 = extractvalue %dx.types.ResRet.f32 %2404, 3
  %2409 = fcmp fast olt float %2408, 0.000000e+00
  br i1 %2409, label %2410, label %2444

; <label>:2410                                    ; preds = %2395
  %2411 = fcmp fast ogt float %2405, 0x3FA4B5DCC0000000
  %2412 = fcmp fast ogt float %2406, 0x3FA4B5DCC0000000
  %2413 = fcmp fast ogt float %2407, 0x3FA4B5DCC0000000
  %2414 = select i1 %2411, float 0.000000e+00, float 1.000000e+00
  %2415 = select i1 %2412, float 0.000000e+00, float 1.000000e+00
  %2416 = select i1 %2413, float 0.000000e+00, float 1.000000e+00
  %2417 = fmul fast float %2405, 0x3FB3D07220000000
  %2418 = fmul fast float %2406, 0x3FB3D07220000000
  %2419 = fmul fast float %2407, 0x3FB3D07220000000
  %2420 = fadd fast float %2405, 0x3FAC28F5C0000000
  %2421 = fadd fast float %2406, 0x3FAC28F5C0000000
  %2422 = fadd fast float %2407, 0x3FAC28F5C0000000
  %2423 = fmul fast float %2420, 0x3FEE54EDE0000000
  %2424 = fmul fast float %2421, 0x3FEE54EDE0000000
  %2425 = fmul fast float %2422, 0x3FEE54EDE0000000
  %2426 = call float @dx.op.unary.f32(i32 23, float %2423)  ; Log(value)
  %2427 = call float @dx.op.unary.f32(i32 23, float %2424)  ; Log(value)
  %2428 = call float @dx.op.unary.f32(i32 23, float %2425)  ; Log(value)
  %2429 = fmul fast float %2426, 0x4003333340000000
  %2430 = fmul fast float %2427, 0x4003333340000000
  %2431 = fmul fast float %2428, 0x4003333340000000
  %2432 = call float @dx.op.unary.f32(i32 21, float %2429)  ; Exp(value)
  %2433 = call float @dx.op.unary.f32(i32 21, float %2430)  ; Exp(value)
  %2434 = call float @dx.op.unary.f32(i32 21, float %2431)  ; Exp(value)
  %2435 = fsub fast float %2417, %2432
  %2436 = fsub fast float %2418, %2433
  %2437 = fsub fast float %2419, %2434
  %2438 = fmul fast float %2435, %2414
  %2439 = fmul fast float %2436, %2415
  %2440 = fmul fast float %2437, %2416
  %2441 = fadd fast float %2438, %2432
  %2442 = fadd fast float %2439, %2433
  %2443 = fadd fast float %2440, %2434
  br label %2512

; <label>:2444                                    ; preds = %2395
  %2445 = fadd fast float %5, 1.000000e+00
  %2446 = fadd fast float %6, 1.000000e+00
  %2447 = fsub fast float 1.000000e+00, %5
  %2448 = fmul fast float %9, %2445
  %2449 = fmul fast float %9, %2446
  %2450 = fmul fast float %9, %2447
  %2451 = fmul fast float %2448, %2405
  %2452 = fmul fast float %2449, %2406
  %2453 = fmul fast float %2450, %2407
  %2454 = fcmp fast ult float %10, 5.000000e-01
  br i1 %2454, label %2480, label %2455

; <label>:2455                                    ; preds = %2444
  %2456 = fmul fast float %2451, 0x4004147AE0000000
  %2457 = fmul fast float %2452, 0x4004147AE0000000
  %2458 = fmul fast float %2453, 0x4004147AE0000000
  %2459 = fadd fast float %2456, 0x3F9EB851E0000000
  %2460 = fadd fast float %2457, 0x3F9EB851E0000000
  %2461 = fadd fast float %2458, 0x3F9EB851E0000000
  %2462 = fmul fast float %2459, %2451
  %2463 = fmul fast float %2460, %2452
  %2464 = fmul fast float %2461, %2453
  %2465 = fmul fast float %2451, 0x400370A3E0000000
  %2466 = fmul fast float %2452, 0x400370A3E0000000
  %2467 = fmul fast float %2453, 0x400370A3E0000000
  %2468 = fadd fast float %2465, 0x3FE2E147A0000000
  %2469 = fadd fast float %2466, 0x3FE2E147A0000000
  %2470 = fadd fast float %2467, 0x3FE2E147A0000000
  %2471 = fmul fast float %2468, %2451
  %2472 = fmul fast float %2469, %2452
  %2473 = fmul fast float %2470, %2453
  %2474 = fadd fast float %2471, 0x3FC1EB8520000000
  %2475 = fadd fast float %2472, 0x3FC1EB8520000000
  %2476 = fadd fast float %2473, 0x3FC1EB8520000000
  %2477 = fdiv fast float %2462, %2474
  %2478 = fdiv fast float %2463, %2475
  %2479 = fdiv fast float %2464, %2476
  br label %2480

; <label>:2480                                    ; preds = %2455, %2444
  %2481 = phi float [ %2477, %2455 ], [ %2451, %2444 ]
  %2482 = phi float [ %2478, %2455 ], [ %2452, %2444 ]
  %2483 = phi float [ %2479, %2455 ], [ %2453, %2444 ]
  %2484 = call float @dx.op.unary.f32(i32 7, float %2481)  ; Saturate(value)
  %2485 = call float @dx.op.unary.f32(i32 7, float %2482)  ; Saturate(value)
  %2486 = call float @dx.op.unary.f32(i32 7, float %2483)  ; Saturate(value)
  %2487 = call float @dx.op.dot3.f32(i32 55, float %2484, float %2485, float %2486, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2488 = fsub fast float %2484, %2487
  %2489 = fsub fast float %2485, %2487
  %2490 = fsub fast float %2486, %2487
  %2491 = fmul fast float %2488, %8
  %2492 = fmul fast float %2489, %8
  %2493 = fmul fast float %2490, %8
  %2494 = fadd fast float %2491, %2487
  %2495 = fadd fast float %2492, %2487
  %2496 = fadd fast float %2493, %2487
  %2497 = call float @dx.op.unary.f32(i32 7, float %2494)  ; Saturate(value)
  %2498 = call float @dx.op.unary.f32(i32 7, float %2495)  ; Saturate(value)
  %2499 = call float @dx.op.unary.f32(i32 7, float %2496)  ; Saturate(value)
  %2500 = fadd fast float %2497, 0xBFC70A3D80000000
  %2501 = fadd fast float %2498, 0xBFC70A3D80000000
  %2502 = fadd fast float %2499, 0xBFC70A3D80000000
  %2503 = fmul fast float %2500, %7
  %2504 = fmul fast float %2501, %7
  %2505 = fmul fast float %2502, %7
  %2506 = fadd fast float %2503, 0x3FC70A3D80000000
  %2507 = fadd fast float %2504, 0x3FC70A3D80000000
  %2508 = fadd fast float %2505, 0x3FC70A3D80000000
  %2509 = call float @dx.op.unary.f32(i32 7, float %2506)  ; Saturate(value)
  %2510 = call float @dx.op.unary.f32(i32 7, float %2507)  ; Saturate(value)
  %2511 = call float @dx.op.unary.f32(i32 7, float %2508)  ; Saturate(value)
  br label %2512

; <label>:2512                                    ; preds = %2480, %2410
  %2513 = phi float [ %2441, %2410 ], [ %2509, %2480 ]
  %2514 = phi float [ %2442, %2410 ], [ %2510, %2480 ]
  %2515 = phi float [ %2443, %2410 ], [ %2511, %2480 ]
  %2516 = add i32 %721, 1
  %2517 = call i32 @dx.op.binary.i32(i32 37, i32 %2516, i32 0)  ; IMax(a,b)
  %2518 = call i32 @dx.op.binary.i32(i32 38, i32 %2517, i32 %30)  ; IMin(a,b)
  %2519 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2518, i32 %2403, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2520 = extractvalue %dx.types.ResRet.f32 %2519, 0
  %2521 = extractvalue %dx.types.ResRet.f32 %2519, 1
  %2522 = extractvalue %dx.types.ResRet.f32 %2519, 2
  %2523 = extractvalue %dx.types.ResRet.f32 %2519, 3
  %2524 = fcmp fast olt float %2523, 0.000000e+00
  br i1 %2524, label %2525, label %2559

; <label>:2525                                    ; preds = %2512
  %2526 = fcmp fast ogt float %2520, 0x3FA4B5DCC0000000
  %2527 = fcmp fast ogt float %2521, 0x3FA4B5DCC0000000
  %2528 = fcmp fast ogt float %2522, 0x3FA4B5DCC0000000
  %2529 = select i1 %2526, float 0.000000e+00, float 1.000000e+00
  %2530 = select i1 %2527, float 0.000000e+00, float 1.000000e+00
  %2531 = select i1 %2528, float 0.000000e+00, float 1.000000e+00
  %2532 = fmul fast float %2520, 0x3FB3D07220000000
  %2533 = fmul fast float %2521, 0x3FB3D07220000000
  %2534 = fmul fast float %2522, 0x3FB3D07220000000
  %2535 = fadd fast float %2520, 0x3FAC28F5C0000000
  %2536 = fadd fast float %2521, 0x3FAC28F5C0000000
  %2537 = fadd fast float %2522, 0x3FAC28F5C0000000
  %2538 = fmul fast float %2535, 0x3FEE54EDE0000000
  %2539 = fmul fast float %2536, 0x3FEE54EDE0000000
  %2540 = fmul fast float %2537, 0x3FEE54EDE0000000
  %2541 = call float @dx.op.unary.f32(i32 23, float %2538)  ; Log(value)
  %2542 = call float @dx.op.unary.f32(i32 23, float %2539)  ; Log(value)
  %2543 = call float @dx.op.unary.f32(i32 23, float %2540)  ; Log(value)
  %2544 = fmul fast float %2541, 0x4003333340000000
  %2545 = fmul fast float %2542, 0x4003333340000000
  %2546 = fmul fast float %2543, 0x4003333340000000
  %2547 = call float @dx.op.unary.f32(i32 21, float %2544)  ; Exp(value)
  %2548 = call float @dx.op.unary.f32(i32 21, float %2545)  ; Exp(value)
  %2549 = call float @dx.op.unary.f32(i32 21, float %2546)  ; Exp(value)
  %2550 = fsub fast float %2532, %2547
  %2551 = fsub fast float %2533, %2548
  %2552 = fsub fast float %2534, %2549
  %2553 = fmul fast float %2550, %2529
  %2554 = fmul fast float %2551, %2530
  %2555 = fmul fast float %2552, %2531
  %2556 = fadd fast float %2553, %2547
  %2557 = fadd fast float %2554, %2548
  %2558 = fadd fast float %2555, %2549
  br label %2627

; <label>:2559                                    ; preds = %2512
  %2560 = fadd fast float %5, 1.000000e+00
  %2561 = fadd fast float %6, 1.000000e+00
  %2562 = fsub fast float 1.000000e+00, %5
  %2563 = fmul fast float %9, %2560
  %2564 = fmul fast float %9, %2561
  %2565 = fmul fast float %9, %2562
  %2566 = fmul fast float %2563, %2520
  %2567 = fmul fast float %2564, %2521
  %2568 = fmul fast float %2565, %2522
  %2569 = fcmp fast ult float %10, 5.000000e-01
  br i1 %2569, label %2595, label %2570

; <label>:2570                                    ; preds = %2559
  %2571 = fmul fast float %2566, 0x4004147AE0000000
  %2572 = fmul fast float %2567, 0x4004147AE0000000
  %2573 = fmul fast float %2568, 0x4004147AE0000000
  %2574 = fadd fast float %2571, 0x3F9EB851E0000000
  %2575 = fadd fast float %2572, 0x3F9EB851E0000000
  %2576 = fadd fast float %2573, 0x3F9EB851E0000000
  %2577 = fmul fast float %2574, %2566
  %2578 = fmul fast float %2575, %2567
  %2579 = fmul fast float %2576, %2568
  %2580 = fmul fast float %2566, 0x400370A3E0000000
  %2581 = fmul fast float %2567, 0x400370A3E0000000
  %2582 = fmul fast float %2568, 0x400370A3E0000000
  %2583 = fadd fast float %2580, 0x3FE2E147A0000000
  %2584 = fadd fast float %2581, 0x3FE2E147A0000000
  %2585 = fadd fast float %2582, 0x3FE2E147A0000000
  %2586 = fmul fast float %2583, %2566
  %2587 = fmul fast float %2584, %2567
  %2588 = fmul fast float %2585, %2568
  %2589 = fadd fast float %2586, 0x3FC1EB8520000000
  %2590 = fadd fast float %2587, 0x3FC1EB8520000000
  %2591 = fadd fast float %2588, 0x3FC1EB8520000000
  %2592 = fdiv fast float %2577, %2589
  %2593 = fdiv fast float %2578, %2590
  %2594 = fdiv fast float %2579, %2591
  br label %2595

; <label>:2595                                    ; preds = %2570, %2559
  %2596 = phi float [ %2592, %2570 ], [ %2566, %2559 ]
  %2597 = phi float [ %2593, %2570 ], [ %2567, %2559 ]
  %2598 = phi float [ %2594, %2570 ], [ %2568, %2559 ]
  %2599 = call float @dx.op.unary.f32(i32 7, float %2596)  ; Saturate(value)
  %2600 = call float @dx.op.unary.f32(i32 7, float %2597)  ; Saturate(value)
  %2601 = call float @dx.op.unary.f32(i32 7, float %2598)  ; Saturate(value)
  %2602 = call float @dx.op.dot3.f32(i32 55, float %2599, float %2600, float %2601, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2603 = fsub fast float %2599, %2602
  %2604 = fsub fast float %2600, %2602
  %2605 = fsub fast float %2601, %2602
  %2606 = fmul fast float %2603, %8
  %2607 = fmul fast float %2604, %8
  %2608 = fmul fast float %2605, %8
  %2609 = fadd fast float %2606, %2602
  %2610 = fadd fast float %2607, %2602
  %2611 = fadd fast float %2608, %2602
  %2612 = call float @dx.op.unary.f32(i32 7, float %2609)  ; Saturate(value)
  %2613 = call float @dx.op.unary.f32(i32 7, float %2610)  ; Saturate(value)
  %2614 = call float @dx.op.unary.f32(i32 7, float %2611)  ; Saturate(value)
  %2615 = fadd fast float %2612, 0xBFC70A3D80000000
  %2616 = fadd fast float %2613, 0xBFC70A3D80000000
  %2617 = fadd fast float %2614, 0xBFC70A3D80000000
  %2618 = fmul fast float %2615, %7
  %2619 = fmul fast float %2616, %7
  %2620 = fmul fast float %2617, %7
  %2621 = fadd fast float %2618, 0x3FC70A3D80000000
  %2622 = fadd fast float %2619, 0x3FC70A3D80000000
  %2623 = fadd fast float %2620, 0x3FC70A3D80000000
  %2624 = call float @dx.op.unary.f32(i32 7, float %2621)  ; Saturate(value)
  %2625 = call float @dx.op.unary.f32(i32 7, float %2622)  ; Saturate(value)
  %2626 = call float @dx.op.unary.f32(i32 7, float %2623)  ; Saturate(value)
  br label %2627

; <label>:2627                                    ; preds = %2595, %2525
  %2628 = phi float [ %2556, %2525 ], [ %2624, %2595 ]
  %2629 = phi float [ %2557, %2525 ], [ %2625, %2595 ]
  %2630 = phi float [ %2558, %2525 ], [ %2626, %2595 ]
  %2631 = call float @dx.op.binary.f32(i32 36, float %2513, float %2628)  ; FMin(a,b)
  %2632 = call float @dx.op.binary.f32(i32 36, float %2514, float %2629)  ; FMin(a,b)
  %2633 = call float @dx.op.binary.f32(i32 36, float %2515, float %2630)  ; FMin(a,b)
  %2634 = call float @dx.op.binary.f32(i32 36, float %2281, float %2396)  ; FMin(a,b)
  %2635 = call float @dx.op.binary.f32(i32 36, float %2282, float %2397)  ; FMin(a,b)
  %2636 = call float @dx.op.binary.f32(i32 36, float %2283, float %2398)  ; FMin(a,b)
  %2637 = call float @dx.op.binary.f32(i32 36, float %2634, float %2631)  ; FMin(a,b)
  %2638 = call float @dx.op.binary.f32(i32 36, float %2635, float %2632)  ; FMin(a,b)
  %2639 = call float @dx.op.binary.f32(i32 36, float %2636, float %2633)  ; FMin(a,b)
  %2640 = call float @dx.op.binary.f32(i32 36, float %2164, float %2637)  ; FMin(a,b)
  %2641 = call float @dx.op.binary.f32(i32 36, float %2165, float %2638)  ; FMin(a,b)
  %2642 = call float @dx.op.binary.f32(i32 36, float %2166, float %2639)  ; FMin(a,b)
  %2643 = call float @dx.op.binary.f32(i32 35, float %2513, float %2628)  ; FMax(a,b)
  %2644 = call float @dx.op.binary.f32(i32 35, float %2514, float %2629)  ; FMax(a,b)
  %2645 = call float @dx.op.binary.f32(i32 35, float %2515, float %2630)  ; FMax(a,b)
  %2646 = call float @dx.op.binary.f32(i32 35, float %2281, float %2396)  ; FMax(a,b)
  %2647 = call float @dx.op.binary.f32(i32 35, float %2282, float %2397)  ; FMax(a,b)
  %2648 = call float @dx.op.binary.f32(i32 35, float %2283, float %2398)  ; FMax(a,b)
  %2649 = call float @dx.op.binary.f32(i32 35, float %2646, float %2643)  ; FMax(a,b)
  %2650 = call float @dx.op.binary.f32(i32 35, float %2647, float %2644)  ; FMax(a,b)
  %2651 = call float @dx.op.binary.f32(i32 35, float %2648, float %2645)  ; FMax(a,b)
  %2652 = call float @dx.op.binary.f32(i32 35, float %2164, float %2649)  ; FMax(a,b)
  %2653 = call float @dx.op.binary.f32(i32 35, float %2165, float %2650)  ; FMax(a,b)
  %2654 = call float @dx.op.binary.f32(i32 35, float %2166, float %2651)  ; FMax(a,b)
  %2655 = fsub fast float %2652, %2640
  %2656 = fsub fast float %2653, %2641
  %2657 = fsub fast float %2654, %2642
  %2658 = call float @dx.op.unary.f32(i32 6, float %2655)  ; FAbs(value)
  %2659 = call float @dx.op.unary.f32(i32 6, float %2656)  ; FAbs(value)
  %2660 = call float @dx.op.unary.f32(i32 6, float %2657)  ; FAbs(value)
  %2661 = call float @dx.op.binary.f32(i32 35, float %2659, float %2660)  ; FMax(a,b)
  %2662 = call float @dx.op.binary.f32(i32 35, float %2658, float %2661)  ; FMax(a,b)
  %2663 = call float @dx.op.binary.f32(i32 35, float %2653, float %2654)  ; FMax(a,b)
  %2664 = call float @dx.op.binary.f32(i32 35, float %2652, float %2663)  ; FMax(a,b)
  %2665 = fmul fast float %2664, 1.250000e-01
  %2666 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %2665)  ; FMax(a,b)
  %2667 = fcmp fast ogt float %2662, %2666
  br i1 %2667, label %2668, label %2729

; <label>:2668                                    ; preds = %2627
  %2669 = fsub fast float %2281, %2396
  %2670 = fsub fast float %2282, %2397
  %2671 = fsub fast float %2283, %2398
  %2672 = call float @dx.op.unary.f32(i32 6, float %2669)  ; FAbs(value)
  %2673 = call float @dx.op.unary.f32(i32 6, float %2670)  ; FAbs(value)
  %2674 = call float @dx.op.unary.f32(i32 6, float %2671)  ; FAbs(value)
  %2675 = call float @dx.op.binary.f32(i32 35, float %2673, float %2674)  ; FMax(a,b)
  %2676 = call float @dx.op.binary.f32(i32 35, float %2672, float %2675)  ; FMax(a,b)
  %2677 = fsub fast float %2513, %2628
  %2678 = fsub fast float %2514, %2629
  %2679 = fsub fast float %2515, %2630
  %2680 = call float @dx.op.unary.f32(i32 6, float %2677)  ; FAbs(value)
  %2681 = call float @dx.op.unary.f32(i32 6, float %2678)  ; FAbs(value)
  %2682 = call float @dx.op.unary.f32(i32 6, float %2679)  ; FAbs(value)
  %2683 = call float @dx.op.binary.f32(i32 35, float %2681, float %2682)  ; FMax(a,b)
  %2684 = call float @dx.op.binary.f32(i32 35, float %2680, float %2683)  ; FMax(a,b)
  %2685 = fcmp fast olt float %2676, %2684
  %2686 = select i1 %2685, float %2281, float %2513
  %2687 = select i1 %2685, float %2282, float %2514
  %2688 = select i1 %2685, float %2283, float %2515
  %2689 = select i1 %2685, float %2396, float %2628
  %2690 = select i1 %2685, float %2397, float %2629
  %2691 = select i1 %2685, float %2398, float %2630
  %2692 = fsub fast float %2164, %2689
  %2693 = fsub fast float %2165, %2690
  %2694 = fsub fast float %2166, %2691
  %2695 = fsub fast float %2164, %2686
  %2696 = fsub fast float %2165, %2687
  %2697 = fsub fast float %2166, %2688
  %2698 = call float @dx.op.dot3.f32(i32 55, float %2695, float %2696, float %2697, float %2692, float %2693, float %2694)  ; Dot3(ax,ay,az,bx,by,bz)
  %2699 = fcmp fast ogt float %2698, 0.000000e+00
  br i1 %2699, label %2700, label %2712

; <label>:2700                                    ; preds = %2668
  %2701 = fsub fast float %2686, %2689
  %2702 = fsub fast float %2687, %2690
  %2703 = fsub fast float %2688, %2691
  %2704 = call float @dx.op.unary.f32(i32 6, float %2701)  ; FAbs(value)
  %2705 = call float @dx.op.unary.f32(i32 6, float %2702)  ; FAbs(value)
  %2706 = call float @dx.op.unary.f32(i32 6, float %2703)  ; FAbs(value)
  %2707 = call float @dx.op.binary.f32(i32 35, float %2705, float %2706)  ; FMax(a,b)
  %2708 = call float @dx.op.binary.f32(i32 35, float %2704, float %2707)  ; FMax(a,b)
  %2709 = fmul fast float %2662, 2.500000e-01
  %2710 = fcmp fast olt float %2708, %2709
  %2711 = select i1 %2710, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  br label %2712

; <label>:2712                                    ; preds = %2700, %2668
  %2713 = phi float [ 0x3FC99999A0000000, %2668 ], [ %2711, %2700 ]
  %2714 = fadd fast float %2686, %2689
  %2715 = fadd fast float %2687, %2690
  %2716 = fadd fast float %2688, %2691
  %2717 = fmul fast float %2714, 5.000000e-01
  %2718 = fmul fast float %2715, 5.000000e-01
  %2719 = fmul fast float %2716, 5.000000e-01
  %2720 = fsub fast float %2717, %2164
  %2721 = fsub fast float %2718, %2165
  %2722 = fsub fast float %2719, %2166
  %2723 = fmul fast float %2713, %2720
  %2724 = fmul fast float %2713, %2721
  %2725 = fmul fast float %2713, %2722
  %2726 = fadd fast float %2723, %2164
  %2727 = fadd fast float %2724, %2165
  %2728 = fadd fast float %2725, %2166
  br label %2729

; <label>:2729                                    ; preds = %2712, %2627
  %2730 = phi float [ %2726, %2712 ], [ %2164, %2627 ]
  %2731 = phi float [ %2727, %2712 ], [ %2165, %2627 ]
  %2732 = phi float [ %2728, %2712 ], [ %2166, %2627 ]
  %2733 = fcmp fast ogt float %2730, 0x3F69A5C380000000
  %2734 = fcmp fast ogt float %2731, 0x3F69A5C380000000
  %2735 = fcmp fast ogt float %2732, 0x3F69A5C380000000
  %2736 = select i1 %2733, float 0.000000e+00, float 1.000000e+00
  %2737 = select i1 %2734, float 0.000000e+00, float 1.000000e+00
  %2738 = select i1 %2735, float 0.000000e+00, float 1.000000e+00
  %2739 = fmul fast float %2730, 0x4029D70A40000000
  %2740 = fmul fast float %2731, 0x4029D70A40000000
  %2741 = fmul fast float %2732, 0x4029D70A40000000
  %2742 = call float @dx.op.binary.f32(i32 35, float %2730, float 0.000000e+00)  ; FMax(a,b)
  %2743 = call float @dx.op.binary.f32(i32 35, float %2731, float 0.000000e+00)  ; FMax(a,b)
  %2744 = call float @dx.op.binary.f32(i32 35, float %2732, float 0.000000e+00)  ; FMax(a,b)
  %2745 = call float @dx.op.unary.f32(i32 23, float %2742)  ; Log(value)
  %2746 = call float @dx.op.unary.f32(i32 23, float %2743)  ; Log(value)
  %2747 = call float @dx.op.unary.f32(i32 23, float %2744)  ; Log(value)
  %2748 = fmul fast float %2745, 0x3FDAAAAAA0000000
  %2749 = fmul fast float %2746, 0x3FDAAAAAA0000000
  %2750 = fmul fast float %2747, 0x3FDAAAAAA0000000
  %2751 = call float @dx.op.unary.f32(i32 21, float %2748)  ; Exp(value)
  %2752 = call float @dx.op.unary.f32(i32 21, float %2749)  ; Exp(value)
  %2753 = call float @dx.op.unary.f32(i32 21, float %2750)  ; Exp(value)
  %2754 = fmul fast float %2751, 0x3FF0E147A0000000
  %2755 = fmul fast float %2752, 0x3FF0E147A0000000
  %2756 = fmul fast float %2753, 0x3FF0E147A0000000
  %2757 = fadd fast float %2754, 0xBFAC28F5C0000000
  %2758 = fadd fast float %2755, 0xBFAC28F5C0000000
  %2759 = fadd fast float %2756, 0xBFAC28F5C0000000
  %2760 = fsub fast float %2739, %2757
  %2761 = fsub fast float %2740, %2758
  %2762 = fsub fast float %2741, %2759
  %2763 = fmul fast float %2760, %2736
  %2764 = fmul fast float %2761, %2737
  %2765 = fmul fast float %2762, %2738
  %2766 = fadd fast float %2763, %2757
  %2767 = fadd fast float %2764, %2758
  %2768 = fadd fast float %2765, %2759
  br label %2769

; <label>:2769                                    ; preds = %2729, %2097
  %2770 = phi float [ %2092, %2097 ], [ %2766, %2729 ]
  %2771 = phi float [ %2093, %2097 ], [ %2767, %2729 ]
  %2772 = phi float [ %2094, %2097 ], [ %2768, %2729 ]
  %2773 = phi float [ %2098, %2097 ], [ %2095, %2729 ]
  %2774 = call float @dx.op.unary.f32(i32 27, float %20)  ; Round_ni(value)
  %2775 = call float @dx.op.unary.f32(i32 27, float %21)  ; Round_ni(value)
  %2776 = fptosi float %2774 to i32
  %2777 = fptosi float %2775 to i32
  %2778 = call i32 @dx.op.binary.i32(i32 37, i32 %2776, i32 0)  ; IMax(a,b)
  %2779 = call i32 @dx.op.binary.i32(i32 37, i32 %2777, i32 0)  ; IMax(a,b)
  %2780 = call i32 @dx.op.binary.i32(i32 38, i32 %2778, i32 %30)  ; IMin(a,b)
  %2781 = call i32 @dx.op.binary.i32(i32 38, i32 %2779, i32 %31)  ; IMin(a,b)
  %2782 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2780, i32 %2781, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2783 = extractvalue %dx.types.ResRet.f32 %2782, 0
  %2784 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %34, i32 %35, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2785 = extractvalue %dx.types.ResRet.f32 %2784, 0
  %2786 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %721, i32 %35, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2787 = extractvalue %dx.types.ResRet.f32 %2786, 0
  %2788 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %34, i32 %1407, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2789 = extractvalue %dx.types.ResRet.f32 %2788, 0
  %2790 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %721, i32 %1407, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2791 = extractvalue %dx.types.ResRet.f32 %2790, 0
  %2792 = fsub fast float 1.000000e+00, %28
  %2793 = fsub fast float 1.000000e+00, %29
  %2794 = fmul fast float %2793, %2792
  %2795 = fmul fast float %2793, %28
  %2796 = fmul fast float %2792, %29
  %2797 = fmul fast float %29, %28
  %2798 = fsub fast float 1.000000e+00, %2783
  %2799 = fmul fast float %2798, 0x3FA99999A0000000
  %2800 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %2799)  ; FMax(a,b)
  %2801 = fsub fast float %2785, %2783
  %2802 = fsub fast float %2787, %2783
  %2803 = fsub fast float %2789, %2783
  %2804 = fsub fast float %2791, %2783
  %2805 = call float @dx.op.unary.f32(i32 6, float %2801)  ; FAbs(value)
  %2806 = call float @dx.op.unary.f32(i32 6, float %2802)  ; FAbs(value)
  %2807 = call float @dx.op.unary.f32(i32 6, float %2803)  ; FAbs(value)
  %2808 = call float @dx.op.unary.f32(i32 6, float %2804)  ; FAbs(value)
  %2809 = fdiv fast float %2805, %2800
  %2810 = fdiv fast float %2806, %2800
  %2811 = fdiv fast float %2807, %2800
  %2812 = fdiv fast float %2808, %2800
  %2813 = fsub fast float 1.000000e+00, %2809
  %2814 = fsub fast float 1.000000e+00, %2810
  %2815 = fsub fast float 1.000000e+00, %2811
  %2816 = fsub fast float 1.000000e+00, %2812
  %2817 = call float @dx.op.unary.f32(i32 7, float %2813)  ; Saturate(value)
  %2818 = call float @dx.op.unary.f32(i32 7, float %2814)  ; Saturate(value)
  %2819 = call float @dx.op.unary.f32(i32 7, float %2815)  ; Saturate(value)
  %2820 = call float @dx.op.unary.f32(i32 7, float %2816)  ; Saturate(value)
  %2821 = fmul fast float %2794, %2817
  %2822 = fmul fast float %2795, %2818
  %2823 = fmul fast float %2796, %2819
  %2824 = fmul fast float %2797, %2820
  %2825 = call float @dx.op.dot4.f32(i32 56, float %2821, float %2822, float %2823, float %2824, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %2826 = call float @dx.op.binary.f32(i32 35, float %2825, float 0x3EE4F8B580000000)  ; FMax(a,b)
  %2827 = fdiv fast float %2821, %2826
  %2828 = fdiv fast float %2822, %2826
  %2829 = fdiv fast float %2823, %2826
  %2830 = fdiv fast float %2824, %2826
  %2831 = fcmp fast ogt float %715, 0x3FA4B5DCC0000000
  %2832 = fcmp fast ogt float %716, 0x3FA4B5DCC0000000
  %2833 = fcmp fast ogt float %717, 0x3FA4B5DCC0000000
  %2834 = select i1 %2831, float 0.000000e+00, float 1.000000e+00
  %2835 = select i1 %2832, float 0.000000e+00, float 1.000000e+00
  %2836 = select i1 %2833, float 0.000000e+00, float 1.000000e+00
  %2837 = fmul fast float %715, 0x3FB3D07220000000
  %2838 = fmul fast float %716, 0x3FB3D07220000000
  %2839 = fmul fast float %717, 0x3FB3D07220000000
  %2840 = fadd fast float %715, 0x3FAC28F5C0000000
  %2841 = fadd fast float %716, 0x3FAC28F5C0000000
  %2842 = fadd fast float %717, 0x3FAC28F5C0000000
  %2843 = fmul fast float %2840, 0x3FEE54EDE0000000
  %2844 = fmul fast float %2841, 0x3FEE54EDE0000000
  %2845 = fmul fast float %2842, 0x3FEE54EDE0000000
  %2846 = call float @dx.op.unary.f32(i32 23, float %2843)  ; Log(value)
  %2847 = call float @dx.op.unary.f32(i32 23, float %2844)  ; Log(value)
  %2848 = call float @dx.op.unary.f32(i32 23, float %2845)  ; Log(value)
  %2849 = fmul fast float %2846, 0x4003333340000000
  %2850 = fmul fast float %2847, 0x4003333340000000
  %2851 = fmul fast float %2848, 0x4003333340000000
  %2852 = call float @dx.op.unary.f32(i32 21, float %2849)  ; Exp(value)
  %2853 = call float @dx.op.unary.f32(i32 21, float %2850)  ; Exp(value)
  %2854 = call float @dx.op.unary.f32(i32 21, float %2851)  ; Exp(value)
  %2855 = fsub fast float %2837, %2852
  %2856 = fsub fast float %2838, %2853
  %2857 = fsub fast float %2839, %2854
  %2858 = fmul fast float %2855, %2834
  %2859 = fmul fast float %2856, %2835
  %2860 = fmul fast float %2857, %2836
  %2861 = fadd fast float %2858, %2852
  %2862 = fadd fast float %2859, %2853
  %2863 = fadd fast float %2860, %2854
  %2864 = fmul fast float %2861, %2827
  %2865 = fmul fast float %2862, %2827
  %2866 = fmul fast float %2863, %2827
  %2867 = fcmp fast ogt float %1401, 0x3FA4B5DCC0000000
  %2868 = fcmp fast ogt float %1402, 0x3FA4B5DCC0000000
  %2869 = fcmp fast ogt float %1403, 0x3FA4B5DCC0000000
  %2870 = select i1 %2867, float 0.000000e+00, float 1.000000e+00
  %2871 = select i1 %2868, float 0.000000e+00, float 1.000000e+00
  %2872 = select i1 %2869, float 0.000000e+00, float 1.000000e+00
  %2873 = fmul fast float %1401, 0x3FB3D07220000000
  %2874 = fmul fast float %1402, 0x3FB3D07220000000
  %2875 = fmul fast float %1403, 0x3FB3D07220000000
  %2876 = fadd fast float %1401, 0x3FAC28F5C0000000
  %2877 = fadd fast float %1402, 0x3FAC28F5C0000000
  %2878 = fadd fast float %1403, 0x3FAC28F5C0000000
  %2879 = fmul fast float %2876, 0x3FEE54EDE0000000
  %2880 = fmul fast float %2877, 0x3FEE54EDE0000000
  %2881 = fmul fast float %2878, 0x3FEE54EDE0000000
  %2882 = call float @dx.op.unary.f32(i32 23, float %2879)  ; Log(value)
  %2883 = call float @dx.op.unary.f32(i32 23, float %2880)  ; Log(value)
  %2884 = call float @dx.op.unary.f32(i32 23, float %2881)  ; Log(value)
  %2885 = fmul fast float %2882, 0x4003333340000000
  %2886 = fmul fast float %2883, 0x4003333340000000
  %2887 = fmul fast float %2884, 0x4003333340000000
  %2888 = call float @dx.op.unary.f32(i32 21, float %2885)  ; Exp(value)
  %2889 = call float @dx.op.unary.f32(i32 21, float %2886)  ; Exp(value)
  %2890 = call float @dx.op.unary.f32(i32 21, float %2887)  ; Exp(value)
  %2891 = fsub fast float %2873, %2888
  %2892 = fsub fast float %2874, %2889
  %2893 = fsub fast float %2875, %2890
  %2894 = fmul fast float %2891, %2870
  %2895 = fmul fast float %2892, %2871
  %2896 = fmul fast float %2893, %2872
  %2897 = fadd fast float %2894, %2888
  %2898 = fadd fast float %2895, %2889
  %2899 = fadd fast float %2896, %2890
  %2900 = fmul fast float %2897, %2828
  %2901 = fmul fast float %2898, %2828
  %2902 = fmul fast float %2899, %2828
  %2903 = fadd fast float %2900, %2864
  %2904 = fadd fast float %2901, %2865
  %2905 = fadd fast float %2902, %2866
  %2906 = fcmp fast ogt float %2087, 0x3FA4B5DCC0000000
  %2907 = fcmp fast ogt float %2088, 0x3FA4B5DCC0000000
  %2908 = fcmp fast ogt float %2089, 0x3FA4B5DCC0000000
  %2909 = select i1 %2906, float 0.000000e+00, float 1.000000e+00
  %2910 = select i1 %2907, float 0.000000e+00, float 1.000000e+00
  %2911 = select i1 %2908, float 0.000000e+00, float 1.000000e+00
  %2912 = fmul fast float %2087, 0x3FB3D07220000000
  %2913 = fmul fast float %2088, 0x3FB3D07220000000
  %2914 = fmul fast float %2089, 0x3FB3D07220000000
  %2915 = fadd fast float %2087, 0x3FAC28F5C0000000
  %2916 = fadd fast float %2088, 0x3FAC28F5C0000000
  %2917 = fadd fast float %2089, 0x3FAC28F5C0000000
  %2918 = fmul fast float %2915, 0x3FEE54EDE0000000
  %2919 = fmul fast float %2916, 0x3FEE54EDE0000000
  %2920 = fmul fast float %2917, 0x3FEE54EDE0000000
  %2921 = call float @dx.op.unary.f32(i32 23, float %2918)  ; Log(value)
  %2922 = call float @dx.op.unary.f32(i32 23, float %2919)  ; Log(value)
  %2923 = call float @dx.op.unary.f32(i32 23, float %2920)  ; Log(value)
  %2924 = fmul fast float %2921, 0x4003333340000000
  %2925 = fmul fast float %2922, 0x4003333340000000
  %2926 = fmul fast float %2923, 0x4003333340000000
  %2927 = call float @dx.op.unary.f32(i32 21, float %2924)  ; Exp(value)
  %2928 = call float @dx.op.unary.f32(i32 21, float %2925)  ; Exp(value)
  %2929 = call float @dx.op.unary.f32(i32 21, float %2926)  ; Exp(value)
  %2930 = fsub fast float %2912, %2927
  %2931 = fsub fast float %2913, %2928
  %2932 = fsub fast float %2914, %2929
  %2933 = fmul fast float %2930, %2909
  %2934 = fmul fast float %2931, %2910
  %2935 = fmul fast float %2932, %2911
  %2936 = fadd fast float %2933, %2927
  %2937 = fadd fast float %2934, %2928
  %2938 = fadd fast float %2935, %2929
  %2939 = fmul fast float %2936, %2829
  %2940 = fmul fast float %2937, %2829
  %2941 = fmul fast float %2938, %2829
  %2942 = fadd fast float %2903, %2939
  %2943 = fadd fast float %2904, %2940
  %2944 = fadd fast float %2905, %2941
  %2945 = fcmp fast ogt float %2770, 0x3FA4B5DCC0000000
  %2946 = fcmp fast ogt float %2771, 0x3FA4B5DCC0000000
  %2947 = fcmp fast ogt float %2772, 0x3FA4B5DCC0000000
  %2948 = select i1 %2945, float 0.000000e+00, float 1.000000e+00
  %2949 = select i1 %2946, float 0.000000e+00, float 1.000000e+00
  %2950 = select i1 %2947, float 0.000000e+00, float 1.000000e+00
  %2951 = fmul fast float %2770, 0x3FB3D07220000000
  %2952 = fmul fast float %2771, 0x3FB3D07220000000
  %2953 = fmul fast float %2772, 0x3FB3D07220000000
  %2954 = fadd fast float %2770, 0x3FAC28F5C0000000
  %2955 = fadd fast float %2771, 0x3FAC28F5C0000000
  %2956 = fadd fast float %2772, 0x3FAC28F5C0000000
  %2957 = fmul fast float %2954, 0x3FEE54EDE0000000
  %2958 = fmul fast float %2955, 0x3FEE54EDE0000000
  %2959 = fmul fast float %2956, 0x3FEE54EDE0000000
  %2960 = call float @dx.op.unary.f32(i32 23, float %2957)  ; Log(value)
  %2961 = call float @dx.op.unary.f32(i32 23, float %2958)  ; Log(value)
  %2962 = call float @dx.op.unary.f32(i32 23, float %2959)  ; Log(value)
  %2963 = fmul fast float %2960, 0x4003333340000000
  %2964 = fmul fast float %2961, 0x4003333340000000
  %2965 = fmul fast float %2962, 0x4003333340000000
  %2966 = call float @dx.op.unary.f32(i32 21, float %2963)  ; Exp(value)
  %2967 = call float @dx.op.unary.f32(i32 21, float %2964)  ; Exp(value)
  %2968 = call float @dx.op.unary.f32(i32 21, float %2965)  ; Exp(value)
  %2969 = fsub fast float %2951, %2966
  %2970 = fsub fast float %2952, %2967
  %2971 = fsub fast float %2953, %2968
  %2972 = fmul fast float %2969, %2948
  %2973 = fmul fast float %2970, %2949
  %2974 = fmul fast float %2971, %2950
  %2975 = fadd fast float %2972, %2966
  %2976 = fadd fast float %2973, %2967
  %2977 = fadd fast float %2974, %2968
  %2978 = fmul fast float %2975, %2830
  %2979 = fmul fast float %2976, %2830
  %2980 = fmul fast float %2977, %2830
  %2981 = fadd fast float %2942, %2978
  %2982 = fadd fast float %2943, %2979
  %2983 = fadd fast float %2944, %2980
  %2984 = fcmp fast ogt float %2981, 0x3F69A5C380000000
  %2985 = fcmp fast ogt float %2982, 0x3F69A5C380000000
  %2986 = fcmp fast ogt float %2983, 0x3F69A5C380000000
  %2987 = select i1 %2984, float 0.000000e+00, float 1.000000e+00
  %2988 = select i1 %2985, float 0.000000e+00, float 1.000000e+00
  %2989 = select i1 %2986, float 0.000000e+00, float 1.000000e+00
  %2990 = fmul fast float %2981, 0x4029D70A40000000
  %2991 = fmul fast float %2982, 0x4029D70A40000000
  %2992 = fmul fast float %2983, 0x4029D70A40000000
  %2993 = call float @dx.op.binary.f32(i32 35, float %2981, float 0.000000e+00)  ; FMax(a,b)
  %2994 = call float @dx.op.binary.f32(i32 35, float %2982, float 0.000000e+00)  ; FMax(a,b)
  %2995 = call float @dx.op.binary.f32(i32 35, float %2983, float 0.000000e+00)  ; FMax(a,b)
  %2996 = call float @dx.op.unary.f32(i32 23, float %2993)  ; Log(value)
  %2997 = call float @dx.op.unary.f32(i32 23, float %2994)  ; Log(value)
  %2998 = call float @dx.op.unary.f32(i32 23, float %2995)  ; Log(value)
  %2999 = fmul fast float %2996, 0x3FDAAAAAA0000000
  %3000 = fmul fast float %2997, 0x3FDAAAAAA0000000
  %3001 = fmul fast float %2998, 0x3FDAAAAAA0000000
  %3002 = call float @dx.op.unary.f32(i32 21, float %2999)  ; Exp(value)
  %3003 = call float @dx.op.unary.f32(i32 21, float %3000)  ; Exp(value)
  %3004 = call float @dx.op.unary.f32(i32 21, float %3001)  ; Exp(value)
  %3005 = fmul fast float %3002, 0x3FF0E147A0000000
  %3006 = fmul fast float %3003, 0x3FF0E147A0000000
  %3007 = fmul fast float %3004, 0x3FF0E147A0000000
  %3008 = fadd fast float %3005, 0xBFAC28F5C0000000
  %3009 = fadd fast float %3006, 0xBFAC28F5C0000000
  %3010 = fadd fast float %3007, 0xBFAC28F5C0000000
  %3011 = fsub fast float %2990, %3008
  %3012 = fsub fast float %2991, %3009
  %3013 = fsub fast float %2992, %3010
  %3014 = fmul fast float %3011, %2987
  %3015 = fmul fast float %3012, %2988
  %3016 = fmul fast float %3013, %2989
  %3017 = fadd fast float %3014, %3008
  %3018 = fadd fast float %3015, %3009
  %3019 = fadd fast float %3016, %3010
  %3020 = call float @dx.op.dot4.f32(i32 56, float %718, float %1404, float %2090, float %2773, float %2827, float %2828, float %2829, float %2830)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %3017)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %3018)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %3019)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %3020)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %2783)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 0, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !37, null}
!12 = !{!13, !16, !17, !19, !21, !23, !25, !27, !29, !31, !34}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !15}
!17 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !18, i8 1, i32 1, i8 4, i32 2, i8 0, null}
!18 = !{i32 1}
!19 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !20, i8 1, i32 1, i8 4, i32 3, i8 0, null}
!20 = !{i32 2}
!21 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !22, i8 1, i32 1, i8 4, i32 4, i8 0, null}
!22 = !{i32 3}
!23 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !24, i8 1, i32 1, i8 4, i32 5, i8 0, null}
!24 = !{i32 4}
!25 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !26, i8 1, i32 1, i8 4, i32 6, i8 0, null}
!26 = !{i32 5}
!27 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !28, i8 1, i32 1, i8 4, i32 7, i8 0, null}
!28 = !{i32 6}
!29 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 8, i8 0, null}
!30 = !{i32 7}
!31 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 9, i8 0, !33}
!32 = !{i32 8}
!33 = !{i32 3, i32 15}
!34 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !35, i8 1, i32 1, i8 4, i32 10, i8 0, !36}
!35 = !{i32 9}
!36 = !{i32 3, i32 6}
!37 = !{!38, !39}
!38 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !33}
!39 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !40}
!40 = !{i32 3, i32 1}
