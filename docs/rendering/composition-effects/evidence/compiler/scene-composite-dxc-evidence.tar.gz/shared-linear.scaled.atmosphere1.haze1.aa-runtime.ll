;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float   xyz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: 931522615fe2564da40c2a73d891212a
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %40 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %41 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %42 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %43 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %44 = extractvalue %dx.types.Dimensions %43, 0
  %45 = extractvalue %dx.types.Dimensions %43, 1
  %46 = uitofp i32 %44 to float
  %47 = uitofp i32 %45 to float
  %48 = fmul fast float %46, %41
  %49 = fmul fast float %47, %42
  %50 = fdiv fast float %48, %4
  %51 = fdiv fast float %49, %5
  %52 = fadd fast float %50, -5.000000e-01
  %53 = fadd fast float %51, -5.000000e-01
  %54 = call float @dx.op.unary.f32(i32 27, float %52)  ; Round_ni(value)
  %55 = call float @dx.op.unary.f32(i32 27, float %53)  ; Round_ni(value)
  %56 = fptosi float %54 to i32
  %57 = fptosi float %55 to i32
  %58 = call float @dx.op.unary.f32(i32 22, float %52)  ; Frc(value)
  %59 = call float @dx.op.unary.f32(i32 22, float %53)  ; Frc(value)
  %60 = add i32 %44, -1
  %61 = add i32 %45, -1
  %62 = call i32 @dx.op.binary.i32(i32 37, i32 %56, i32 0)  ; IMax(a,b)
  %63 = call i32 @dx.op.binary.i32(i32 37, i32 %57, i32 0)  ; IMax(a,b)
  %64 = call i32 @dx.op.binary.i32(i32 38, i32 %62, i32 %60)  ; IMin(a,b)
  %65 = call i32 @dx.op.binary.i32(i32 38, i32 %63, i32 %61)  ; IMin(a,b)
  %66 = add i32 %56, 1
  %67 = call i32 @dx.op.binary.i32(i32 37, i32 %66, i32 0)  ; IMax(a,b)
  %68 = call i32 @dx.op.binary.i32(i32 38, i32 %67, i32 %60)  ; IMin(a,b)
  %69 = add i32 %57, 1
  %70 = call i32 @dx.op.binary.i32(i32 37, i32 %69, i32 0)  ; IMax(a,b)
  %71 = call i32 @dx.op.binary.i32(i32 38, i32 %70, i32 %61)  ; IMin(a,b)
  %72 = call float @dx.op.unary.f32(i32 27, float %50)  ; Round_ni(value)
  %73 = call float @dx.op.unary.f32(i32 27, float %51)  ; Round_ni(value)
  %74 = fptosi float %72 to i32
  %75 = fptosi float %73 to i32
  %76 = call i32 @dx.op.binary.i32(i32 37, i32 %74, i32 0)  ; IMax(a,b)
  %77 = call i32 @dx.op.binary.i32(i32 37, i32 %75, i32 0)  ; IMax(a,b)
  %78 = call i32 @dx.op.binary.i32(i32 38, i32 %76, i32 %60)  ; IMin(a,b)
  %79 = call i32 @dx.op.binary.i32(i32 38, i32 %77, i32 %61)  ; IMin(a,b)
  %80 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %78, i32 %79, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %81 = extractvalue %dx.types.ResRet.f32 %80, 0
  %82 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %64, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %83 = extractvalue %dx.types.ResRet.f32 %82, 0
  %84 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %68, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %85 = extractvalue %dx.types.ResRet.f32 %84, 0
  %86 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %64, i32 %71, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %87 = extractvalue %dx.types.ResRet.f32 %86, 0
  %88 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %68, i32 %71, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %89 = extractvalue %dx.types.ResRet.f32 %88, 0
  %90 = fsub fast float 1.000000e+00, %58
  %91 = fsub fast float 1.000000e+00, %59
  %92 = fmul fast float %91, %90
  %93 = fmul fast float %91, %58
  %94 = fmul fast float %90, %59
  %95 = fmul fast float %59, %58
  %96 = fsub fast float 1.000000e+00, %81
  %97 = fmul fast float %96, 0x3FA99999A0000000
  %98 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %97)  ; FMax(a,b)
  %99 = fsub fast float %83, %81
  %100 = call float @dx.op.unary.f32(i32 6, float %99)  ; FAbs(value)
  %101 = fdiv fast float %100, %98
  %102 = fsub fast float 1.000000e+00, %101
  %103 = call float @dx.op.unary.f32(i32 7, float %102)  ; Saturate(value)
  %104 = fsub fast float %85, %81
  %105 = call float @dx.op.unary.f32(i32 6, float %104)  ; FAbs(value)
  %106 = fdiv fast float %105, %98
  %107 = fsub fast float 1.000000e+00, %106
  %108 = call float @dx.op.unary.f32(i32 7, float %107)  ; Saturate(value)
  %109 = fsub fast float %87, %81
  %110 = call float @dx.op.unary.f32(i32 6, float %109)  ; FAbs(value)
  %111 = fdiv fast float %110, %98
  %112 = fsub fast float 1.000000e+00, %111
  %113 = call float @dx.op.unary.f32(i32 7, float %112)  ; Saturate(value)
  %114 = fsub fast float %89, %81
  %115 = call float @dx.op.unary.f32(i32 6, float %114)  ; FAbs(value)
  %116 = fdiv fast float %115, %98
  %117 = fsub fast float 1.000000e+00, %116
  %118 = call float @dx.op.unary.f32(i32 7, float %117)  ; Saturate(value)
  %119 = fmul fast float %92, %103
  %120 = fmul fast float %93, %108
  %121 = fmul fast float %94, %113
  %122 = fmul fast float %95, %118
  %123 = fcmp fast oge float %58, 5.000000e-01
  %124 = zext i1 %123 to i32
  %125 = fcmp fast oge float %59, 5.000000e-01
  %126 = select i1 %125, i32 2, i32 0
  %127 = or i32 %126, %124
  %128 = call float @dx.op.dot4.f32(i32 56, float %119, float %120, float %121, float %122, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %129 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %119)  ; IsFinite(value)
  %130 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %120)  ; IsFinite(value)
  %131 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %121)  ; IsFinite(value)
  %132 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %122)  ; IsFinite(value)
  %133 = and i1 %129, %130
  %134 = and i1 %133, %131
  %135 = and i1 %134, %132
  br i1 %135, label %136, label %153

; <label>:136                                     ; preds = %0
  %137 = fcmp fast oge float %119, 0.000000e+00
  %138 = fcmp fast oge float %120, 0.000000e+00
  %139 = fcmp fast oge float %121, 0.000000e+00
  %140 = fcmp fast oge float %122, 0.000000e+00
  %141 = and i1 %137, %138
  %142 = and i1 %141, %139
  %143 = and i1 %142, %140
  br i1 %143, label %144, label %153

; <label>:144                                     ; preds = %136
  %145 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %128)  ; IsFinite(value)
  %146 = fcmp fast oge float %128, 0x3810000000000000
  %147 = and i1 %146, %145
  br i1 %147, label %148, label %153

; <label>:148                                     ; preds = %144
  %149 = fdiv fast float %119, %128
  %150 = fdiv fast float %120, %128
  %151 = fdiv fast float %121, %128
  %152 = fdiv fast float %122, %128
  br label %162

; <label>:153                                     ; preds = %144, %136, %0
  %154 = icmp eq i32 %127, 0
  %155 = uitofp i1 %154 to float
  %156 = icmp eq i32 %127, 1
  %157 = uitofp i1 %156 to float
  %158 = icmp eq i32 %127, 2
  %159 = uitofp i1 %158 to float
  %160 = icmp eq i32 %127, 3
  %161 = uitofp i1 %160 to float
  br label %162

; <label>:162                                     ; preds = %153, %148
  %163 = phi float [ %149, %148 ], [ %155, %153 ]
  %164 = phi float [ %150, %148 ], [ %157, %153 ]
  %165 = phi float [ %151, %148 ], [ %159, %153 ]
  %166 = phi float [ %152, %148 ], [ %161, %153 ]
  %167 = or i32 %57, %56
  %168 = icmp sgt i32 %167, -1
  br i1 %168, label %169, label %173

; <label>:169                                     ; preds = %162
  %170 = icmp slt i32 %66, %44
  %171 = icmp slt i32 %69, %45
  %172 = and i1 %170, %171
  br label %173

; <label>:173                                     ; preds = %169, %162
  %174 = phi i1 [ false, %162 ], [ %172, %169 ]
  br i1 %174, label %175, label %4114

; <label>:175                                     ; preds = %173
  %176 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %56, i32 %57, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %177 = extractvalue %dx.types.ResRet.f32 %176, 0
  %178 = extractvalue %dx.types.ResRet.f32 %176, 1
  %179 = extractvalue %dx.types.ResRet.f32 %176, 2
  %180 = extractvalue %dx.types.ResRet.f32 %176, 3
  %181 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %66, i32 %57, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %182 = extractvalue %dx.types.ResRet.f32 %181, 0
  %183 = extractvalue %dx.types.ResRet.f32 %181, 1
  %184 = extractvalue %dx.types.ResRet.f32 %181, 2
  %185 = extractvalue %dx.types.ResRet.f32 %181, 3
  %186 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %56, i32 %69, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %187 = extractvalue %dx.types.ResRet.f32 %186, 0
  %188 = extractvalue %dx.types.ResRet.f32 %186, 1
  %189 = extractvalue %dx.types.ResRet.f32 %186, 2
  %190 = extractvalue %dx.types.ResRet.f32 %186, 3
  %191 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %66, i32 %69, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %192 = extractvalue %dx.types.ResRet.f32 %191, 0
  %193 = extractvalue %dx.types.ResRet.f32 %191, 1
  %194 = extractvalue %dx.types.ResRet.f32 %191, 2
  %195 = extractvalue %dx.types.ResRet.f32 %191, 3
  %196 = fcmp fast olt float %180, 0.000000e+00
  br i1 %196, label %197, label %231

; <label>:197                                     ; preds = %175
  %198 = fcmp fast ogt float %177, 0x3FA4B5DCC0000000
  %199 = fcmp fast ogt float %178, 0x3FA4B5DCC0000000
  %200 = fcmp fast ogt float %179, 0x3FA4B5DCC0000000
  %201 = select i1 %198, float 0.000000e+00, float 1.000000e+00
  %202 = select i1 %199, float 0.000000e+00, float 1.000000e+00
  %203 = select i1 %200, float 0.000000e+00, float 1.000000e+00
  %204 = fmul fast float %177, 0x3FB3D07220000000
  %205 = fmul fast float %178, 0x3FB3D07220000000
  %206 = fmul fast float %179, 0x3FB3D07220000000
  %207 = fadd fast float %177, 0x3FAC28F5C0000000
  %208 = fadd fast float %178, 0x3FAC28F5C0000000
  %209 = fadd fast float %179, 0x3FAC28F5C0000000
  %210 = fmul fast float %207, 0x3FEE54EDE0000000
  %211 = fmul fast float %208, 0x3FEE54EDE0000000
  %212 = fmul fast float %209, 0x3FEE54EDE0000000
  %213 = call float @dx.op.unary.f32(i32 23, float %210)  ; Log(value)
  %214 = call float @dx.op.unary.f32(i32 23, float %211)  ; Log(value)
  %215 = call float @dx.op.unary.f32(i32 23, float %212)  ; Log(value)
  %216 = fmul fast float %213, 0x4003333340000000
  %217 = fmul fast float %214, 0x4003333340000000
  %218 = fmul fast float %215, 0x4003333340000000
  %219 = call float @dx.op.unary.f32(i32 21, float %216)  ; Exp(value)
  %220 = call float @dx.op.unary.f32(i32 21, float %217)  ; Exp(value)
  %221 = call float @dx.op.unary.f32(i32 21, float %218)  ; Exp(value)
  %222 = fsub fast float %204, %219
  %223 = fsub fast float %205, %220
  %224 = fsub fast float %206, %221
  %225 = fmul fast float %222, %201
  %226 = fmul fast float %223, %202
  %227 = fmul fast float %224, %203
  %228 = fadd fast float %225, %219
  %229 = fadd fast float %226, %220
  %230 = fadd fast float %227, %221
  br label %446

; <label>:231                                     ; preds = %175
  %232 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %56, i32 %57, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %233 = extractvalue %dx.types.ResRet.f32 %232, 0
  %234 = fcmp fast ogt float %39, 5.000000e-01
  %235 = fcmp fast olt float %233, 1.000000e+00
  %236 = and i1 %234, %235
  br i1 %236, label %237, label %375

; <label>:237                                     ; preds = %231
  %238 = sitofp i32 %56 to float
  %239 = sitofp i32 %57 to float
  %240 = fadd fast float %238, 5.000000e-01
  %241 = fadd fast float %239, 5.000000e-01
  %242 = fdiv fast float %240, %46
  %243 = fdiv fast float %241, %47
  %244 = fmul fast float %242, 2.000000e+00
  %245 = fmul fast float %243, 2.000000e+00
  %246 = fadd fast float %244, -1.000000e+00
  %247 = fsub fast float 1.000000e+00, %245
  %248 = fmul fast float %246, %36
  %249 = call float @dx.op.tertiary.f32(i32 46, float %247, float %32, float %248)  ; FMad(a,b,c)
  %250 = call float @dx.op.tertiary.f32(i32 46, float %233, float %28, float %249)  ; FMad(a,b,c)
  %251 = fadd fast float %250, %24
  %252 = call float @dx.op.unary.f32(i32 6, float %251)  ; FAbs(value)
  %253 = fcmp fast ogt float %252, 0x3EB0C6F7A0000000
  br i1 %253, label %254, label %375

; <label>:254                                     ; preds = %237
  %255 = fmul fast float %246, %35
  %256 = call float @dx.op.tertiary.f32(i32 46, float %247, float %31, float %255)  ; FMad(a,b,c)
  %257 = call float @dx.op.tertiary.f32(i32 46, float %233, float %27, float %256)  ; FMad(a,b,c)
  %258 = fadd fast float %257, %23
  %259 = fmul fast float %246, %34
  %260 = call float @dx.op.tertiary.f32(i32 46, float %247, float %30, float %259)  ; FMad(a,b,c)
  %261 = call float @dx.op.tertiary.f32(i32 46, float %233, float %26, float %260)  ; FMad(a,b,c)
  %262 = fadd fast float %261, %22
  %263 = fmul fast float %246, %33
  %264 = call float @dx.op.tertiary.f32(i32 46, float %247, float %29, float %263)  ; FMad(a,b,c)
  %265 = call float @dx.op.tertiary.f32(i32 46, float %233, float %25, float %264)  ; FMad(a,b,c)
  %266 = fadd fast float %265, %21
  %267 = fdiv fast float %266, %251
  %268 = fdiv fast float %262, %251
  %269 = fdiv fast float %258, %251
  %270 = fsub fast float %267, %18
  %271 = fsub fast float %268, %19
  %272 = fsub fast float %269, %20
  %273 = fmul fast float %270, %270
  %274 = fmul fast float %271, %271
  %275 = fadd fast float %274, %273
  %276 = fmul fast float %272, %272
  %277 = fadd fast float %275, %276
  %278 = call float @dx.op.unary.f32(i32 24, float %277)  ; Sqrt(value)
  %279 = fsub fast float %278, %10
  %280 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %279)  ; FMax(a,b)
  %281 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %281, label %282, label %305

; <label>:282                                     ; preds = %254
  %283 = call float @dx.op.unary.f32(i32 6, float %271)  ; FAbs(value)
  %284 = fmul fast float %283, %12
  %285 = fcmp fast olt float %284, 0x3F50624DE0000000
  br i1 %285, label %286, label %289

; <label>:286                                     ; preds = %282
  %287 = fmul fast float %284, 5.000000e-01
  %288 = fsub fast float 1.000000e+00, %287
  br label %294

; <label>:289                                     ; preds = %282
  %290 = fmul fast float %284, 0xBFF7154760000000
  %291 = call float @dx.op.unary.f32(i32 21, float %290)  ; Exp(value)
  %292 = fsub fast float 1.000000e+00, %291
  %293 = fdiv fast float %292, %284
  br label %294

; <label>:294                                     ; preds = %289, %286
  %295 = phi float [ %288, %286 ], [ %293, %289 ]
  %296 = call float @dx.op.binary.f32(i32 36, float %268, float %19)  ; FMin(a,b)
  %297 = fsub fast float %296, %11
  %298 = fmul fast float %12, %297
  %299 = fsub fast float -0.000000e+00, %298
  %300 = call float @dx.op.binary.f32(i32 35, float %299, float -4.000000e+01)  ; FMax(a,b)
  %301 = call float @dx.op.binary.f32(i32 36, float %300, float 5.000000e+00)  ; FMin(a,b)
  %302 = fmul fast float %301, 0x3FF7154760000000
  %303 = call float @dx.op.unary.f32(i32 21, float %302)  ; Exp(value)
  %304 = fmul fast float %303, %295
  br label %305

; <label>:305                                     ; preds = %294, %254
  %306 = phi float [ %304, %294 ], [ 1.000000e+00, %254 ]
  %307 = fmul fast float %280, %17
  %308 = fmul fast float %307, %306
  %309 = fcmp fast ole float %278, %10
  %310 = fcmp fast olt float %278, 0x3F1A36E2E0000000
  %311 = or i1 %309, %310
  br i1 %311, label %358, label %312

; <label>:312                                     ; preds = %305
  %313 = fdiv fast float %10, %278
  %314 = fmul fast float %313, %270
  %315 = fmul fast float %313, %271
  %316 = fmul fast float %313, %272
  %317 = fadd fast float %314, %18
  %318 = fadd fast float %315, %19
  %319 = fadd fast float %316, %20
  %320 = fadd fast float %317, -9.000000e+02
  %321 = fadd fast float %318, -1.500000e+01
  %322 = fadd fast float %319, -7.500000e+02
  %323 = fmul fast float %320, 0x3F62345680000000
  %324 = fmul fast float %321, 0x3F62345680000000
  %325 = fmul fast float %322, 0x3F62345680000000
  %326 = call float @dx.op.dot3.f32(i32 55, float %323, float %324, float %325, float %323, float %324, float %325)  ; Dot3(ax,ay,az,bx,by,bz)
  %327 = fsub fast float 1.000000e+00, %326
  %328 = call float @dx.op.unary.f32(i32 7, float %327)  ; Saturate(value)
  %329 = fmul fast float %328, %328
  %330 = fadd fast float %317, %267
  %331 = fadd fast float %318, %268
  %332 = fadd fast float %319, %269
  %333 = fmul fast float %330, 0x3F52345680000000
  %334 = fadd fast float %333, -2.000000e+00
  %335 = fmul fast float %331, 0x3F52345680000000
  %336 = fadd fast float %335, 0xBFA1111120000000
  %337 = fmul fast float %332, 0x3F52345680000000
  %338 = fadd fast float %337, 0xBFFAAAAAC0000000
  %339 = call float @dx.op.dot3.f32(i32 55, float %334, float %336, float %338, float %334, float %336, float %338)  ; Dot3(ax,ay,az,bx,by,bz)
  %340 = fsub fast float 1.000000e+00, %339
  %341 = call float @dx.op.unary.f32(i32 7, float %340)  ; Saturate(value)
  %342 = fmul fast float %341, %341
  %343 = fmul fast float %342, 4.000000e+00
  %344 = fadd fast float %343, %329
  %345 = fadd fast float %267, -9.000000e+02
  %346 = fadd fast float %268, -1.500000e+01
  %347 = fadd fast float %269, -7.500000e+02
  %348 = fmul fast float %345, 0x3F62345680000000
  %349 = fmul fast float %346, 0x3F62345680000000
  %350 = fmul fast float %347, 0x3F62345680000000
  %351 = call float @dx.op.dot3.f32(i32 55, float %348, float %349, float %350, float %348, float %349, float %350)  ; Dot3(ax,ay,az,bx,by,bz)
  %352 = fsub fast float 1.000000e+00, %351
  %353 = call float @dx.op.unary.f32(i32 7, float %352)  ; Saturate(value)
  %354 = fmul fast float %353, %353
  %355 = fadd fast float %344, %354
  %356 = fmul fast float %279, 0x3F25D867E0000000
  %357 = fmul fast float %356, %355
  br label %358

; <label>:358                                     ; preds = %312, %305
  %359 = phi float [ %357, %312 ], [ 0.000000e+00, %305 ]
  %360 = fadd fast float %359, %308
  %361 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %360)  ; FMin(a,b)
  %362 = fmul fast float %361, 0xBFF7154760000000
  %363 = call float @dx.op.unary.f32(i32 21, float %362)  ; Exp(value)
  %364 = fsub fast float 1.000000e+00, %363
  %365 = call float @dx.op.binary.f32(i32 36, float %13, float %364)  ; FMin(a,b)
  %366 = fsub fast float %14, %177
  %367 = fsub fast float %15, %178
  %368 = fsub fast float %16, %179
  %369 = fmul fast float %365, %366
  %370 = fmul fast float %365, %367
  %371 = fmul fast float %365, %368
  %372 = fadd fast float %369, %177
  %373 = fadd fast float %370, %178
  %374 = fadd fast float %371, %179
  br label %375

; <label>:375                                     ; preds = %358, %237, %231
  %376 = phi float [ %372, %358 ], [ %177, %237 ], [ %177, %231 ]
  %377 = phi float [ %373, %358 ], [ %178, %237 ], [ %178, %231 ]
  %378 = phi float [ %374, %358 ], [ %179, %237 ], [ %179, %231 ]
  %379 = fadd fast float %6, 1.000000e+00
  %380 = fadd fast float %7, 1.000000e+00
  %381 = fsub fast float 1.000000e+00, %6
  %382 = fmul fast float %37, %379
  %383 = fmul fast float %37, %380
  %384 = fmul fast float %37, %381
  %385 = fmul fast float %382, %376
  %386 = fmul fast float %383, %377
  %387 = fmul fast float %384, %378
  %388 = fcmp fast ult float %38, 5.000000e-01
  br i1 %388, label %414, label %389

; <label>:389                                     ; preds = %375
  %390 = fmul fast float %385, 0x4004147AE0000000
  %391 = fmul fast float %386, 0x4004147AE0000000
  %392 = fmul fast float %387, 0x4004147AE0000000
  %393 = fadd fast float %390, 0x3F9EB851E0000000
  %394 = fadd fast float %391, 0x3F9EB851E0000000
  %395 = fadd fast float %392, 0x3F9EB851E0000000
  %396 = fmul fast float %393, %385
  %397 = fmul fast float %394, %386
  %398 = fmul fast float %395, %387
  %399 = fmul fast float %385, 0x400370A3E0000000
  %400 = fmul fast float %386, 0x400370A3E0000000
  %401 = fmul fast float %387, 0x400370A3E0000000
  %402 = fadd fast float %399, 0x3FE2E147A0000000
  %403 = fadd fast float %400, 0x3FE2E147A0000000
  %404 = fadd fast float %401, 0x3FE2E147A0000000
  %405 = fmul fast float %402, %385
  %406 = fmul fast float %403, %386
  %407 = fmul fast float %404, %387
  %408 = fadd fast float %405, 0x3FC1EB8520000000
  %409 = fadd fast float %406, 0x3FC1EB8520000000
  %410 = fadd fast float %407, 0x3FC1EB8520000000
  %411 = fdiv fast float %396, %408
  %412 = fdiv fast float %397, %409
  %413 = fdiv fast float %398, %410
  br label %414

; <label>:414                                     ; preds = %389, %375
  %415 = phi float [ %411, %389 ], [ %385, %375 ]
  %416 = phi float [ %412, %389 ], [ %386, %375 ]
  %417 = phi float [ %413, %389 ], [ %387, %375 ]
  %418 = call float @dx.op.unary.f32(i32 7, float %415)  ; Saturate(value)
  %419 = call float @dx.op.unary.f32(i32 7, float %416)  ; Saturate(value)
  %420 = call float @dx.op.unary.f32(i32 7, float %417)  ; Saturate(value)
  %421 = call float @dx.op.dot3.f32(i32 55, float %418, float %419, float %420, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %422 = fsub fast float %418, %421
  %423 = fsub fast float %419, %421
  %424 = fsub fast float %420, %421
  %425 = fmul fast float %422, %9
  %426 = fmul fast float %423, %9
  %427 = fmul fast float %424, %9
  %428 = fadd fast float %425, %421
  %429 = fadd fast float %426, %421
  %430 = fadd fast float %427, %421
  %431 = call float @dx.op.unary.f32(i32 7, float %428)  ; Saturate(value)
  %432 = call float @dx.op.unary.f32(i32 7, float %429)  ; Saturate(value)
  %433 = call float @dx.op.unary.f32(i32 7, float %430)  ; Saturate(value)
  %434 = fadd fast float %431, 0xBFC70A3D80000000
  %435 = fadd fast float %432, 0xBFC70A3D80000000
  %436 = fadd fast float %433, 0xBFC70A3D80000000
  %437 = fmul fast float %434, %8
  %438 = fmul fast float %435, %8
  %439 = fmul fast float %436, %8
  %440 = fadd fast float %437, 0x3FC70A3D80000000
  %441 = fadd fast float %438, 0x3FC70A3D80000000
  %442 = fadd fast float %439, 0x3FC70A3D80000000
  %443 = call float @dx.op.unary.f32(i32 7, float %440)  ; Saturate(value)
  %444 = call float @dx.op.unary.f32(i32 7, float %441)  ; Saturate(value)
  %445 = call float @dx.op.unary.f32(i32 7, float %442)  ; Saturate(value)
  br label %446

; <label>:446                                     ; preds = %414, %197
  %447 = phi float [ %228, %197 ], [ %443, %414 ]
  %448 = phi float [ %229, %197 ], [ %444, %414 ]
  %449 = phi float [ %230, %197 ], [ %445, %414 ]
  %450 = fcmp fast olt float %185, 0.000000e+00
  br i1 %450, label %451, label %485

; <label>:451                                     ; preds = %446
  %452 = fcmp fast ogt float %182, 0x3FA4B5DCC0000000
  %453 = fcmp fast ogt float %183, 0x3FA4B5DCC0000000
  %454 = fcmp fast ogt float %184, 0x3FA4B5DCC0000000
  %455 = select i1 %452, float 0.000000e+00, float 1.000000e+00
  %456 = select i1 %453, float 0.000000e+00, float 1.000000e+00
  %457 = select i1 %454, float 0.000000e+00, float 1.000000e+00
  %458 = fmul fast float %182, 0x3FB3D07220000000
  %459 = fmul fast float %183, 0x3FB3D07220000000
  %460 = fmul fast float %184, 0x3FB3D07220000000
  %461 = fadd fast float %182, 0x3FAC28F5C0000000
  %462 = fadd fast float %183, 0x3FAC28F5C0000000
  %463 = fadd fast float %184, 0x3FAC28F5C0000000
  %464 = fmul fast float %461, 0x3FEE54EDE0000000
  %465 = fmul fast float %462, 0x3FEE54EDE0000000
  %466 = fmul fast float %463, 0x3FEE54EDE0000000
  %467 = call float @dx.op.unary.f32(i32 23, float %464)  ; Log(value)
  %468 = call float @dx.op.unary.f32(i32 23, float %465)  ; Log(value)
  %469 = call float @dx.op.unary.f32(i32 23, float %466)  ; Log(value)
  %470 = fmul fast float %467, 0x4003333340000000
  %471 = fmul fast float %468, 0x4003333340000000
  %472 = fmul fast float %469, 0x4003333340000000
  %473 = call float @dx.op.unary.f32(i32 21, float %470)  ; Exp(value)
  %474 = call float @dx.op.unary.f32(i32 21, float %471)  ; Exp(value)
  %475 = call float @dx.op.unary.f32(i32 21, float %472)  ; Exp(value)
  %476 = fsub fast float %458, %473
  %477 = fsub fast float %459, %474
  %478 = fsub fast float %460, %475
  %479 = fmul fast float %476, %455
  %480 = fmul fast float %477, %456
  %481 = fmul fast float %478, %457
  %482 = fadd fast float %479, %473
  %483 = fadd fast float %480, %474
  %484 = fadd fast float %481, %475
  br label %700

; <label>:485                                     ; preds = %446
  %486 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %66, i32 %57, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %487 = extractvalue %dx.types.ResRet.f32 %486, 0
  %488 = fcmp fast ogt float %39, 5.000000e-01
  %489 = fcmp fast olt float %487, 1.000000e+00
  %490 = and i1 %488, %489
  br i1 %490, label %491, label %629

; <label>:491                                     ; preds = %485
  %492 = sitofp i32 %66 to float
  %493 = sitofp i32 %57 to float
  %494 = fadd fast float %492, 5.000000e-01
  %495 = fadd fast float %493, 5.000000e-01
  %496 = fdiv fast float %494, %46
  %497 = fdiv fast float %495, %47
  %498 = fmul fast float %496, 2.000000e+00
  %499 = fmul fast float %497, 2.000000e+00
  %500 = fadd fast float %498, -1.000000e+00
  %501 = fsub fast float 1.000000e+00, %499
  %502 = fmul fast float %500, %36
  %503 = call float @dx.op.tertiary.f32(i32 46, float %501, float %32, float %502)  ; FMad(a,b,c)
  %504 = call float @dx.op.tertiary.f32(i32 46, float %487, float %28, float %503)  ; FMad(a,b,c)
  %505 = fadd fast float %504, %24
  %506 = call float @dx.op.unary.f32(i32 6, float %505)  ; FAbs(value)
  %507 = fcmp fast ogt float %506, 0x3EB0C6F7A0000000
  br i1 %507, label %508, label %629

; <label>:508                                     ; preds = %491
  %509 = fmul fast float %500, %35
  %510 = call float @dx.op.tertiary.f32(i32 46, float %501, float %31, float %509)  ; FMad(a,b,c)
  %511 = call float @dx.op.tertiary.f32(i32 46, float %487, float %27, float %510)  ; FMad(a,b,c)
  %512 = fadd fast float %511, %23
  %513 = fmul fast float %500, %34
  %514 = call float @dx.op.tertiary.f32(i32 46, float %501, float %30, float %513)  ; FMad(a,b,c)
  %515 = call float @dx.op.tertiary.f32(i32 46, float %487, float %26, float %514)  ; FMad(a,b,c)
  %516 = fadd fast float %515, %22
  %517 = fmul fast float %500, %33
  %518 = call float @dx.op.tertiary.f32(i32 46, float %501, float %29, float %517)  ; FMad(a,b,c)
  %519 = call float @dx.op.tertiary.f32(i32 46, float %487, float %25, float %518)  ; FMad(a,b,c)
  %520 = fadd fast float %519, %21
  %521 = fdiv fast float %520, %505
  %522 = fdiv fast float %516, %505
  %523 = fdiv fast float %512, %505
  %524 = fsub fast float %521, %18
  %525 = fsub fast float %522, %19
  %526 = fsub fast float %523, %20
  %527 = fmul fast float %524, %524
  %528 = fmul fast float %525, %525
  %529 = fadd fast float %528, %527
  %530 = fmul fast float %526, %526
  %531 = fadd fast float %529, %530
  %532 = call float @dx.op.unary.f32(i32 24, float %531)  ; Sqrt(value)
  %533 = fsub fast float %532, %10
  %534 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %533)  ; FMax(a,b)
  %535 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %535, label %536, label %559

; <label>:536                                     ; preds = %508
  %537 = call float @dx.op.unary.f32(i32 6, float %525)  ; FAbs(value)
  %538 = fmul fast float %537, %12
  %539 = fcmp fast olt float %538, 0x3F50624DE0000000
  br i1 %539, label %540, label %543

; <label>:540                                     ; preds = %536
  %541 = fmul fast float %538, 5.000000e-01
  %542 = fsub fast float 1.000000e+00, %541
  br label %548

; <label>:543                                     ; preds = %536
  %544 = fmul fast float %538, 0xBFF7154760000000
  %545 = call float @dx.op.unary.f32(i32 21, float %544)  ; Exp(value)
  %546 = fsub fast float 1.000000e+00, %545
  %547 = fdiv fast float %546, %538
  br label %548

; <label>:548                                     ; preds = %543, %540
  %549 = phi float [ %542, %540 ], [ %547, %543 ]
  %550 = call float @dx.op.binary.f32(i32 36, float %522, float %19)  ; FMin(a,b)
  %551 = fsub fast float %550, %11
  %552 = fmul fast float %12, %551
  %553 = fsub fast float -0.000000e+00, %552
  %554 = call float @dx.op.binary.f32(i32 35, float %553, float -4.000000e+01)  ; FMax(a,b)
  %555 = call float @dx.op.binary.f32(i32 36, float %554, float 5.000000e+00)  ; FMin(a,b)
  %556 = fmul fast float %555, 0x3FF7154760000000
  %557 = call float @dx.op.unary.f32(i32 21, float %556)  ; Exp(value)
  %558 = fmul fast float %557, %549
  br label %559

; <label>:559                                     ; preds = %548, %508
  %560 = phi float [ %558, %548 ], [ 1.000000e+00, %508 ]
  %561 = fmul fast float %534, %17
  %562 = fmul fast float %561, %560
  %563 = fcmp fast ole float %532, %10
  %564 = fcmp fast olt float %532, 0x3F1A36E2E0000000
  %565 = or i1 %563, %564
  br i1 %565, label %612, label %566

; <label>:566                                     ; preds = %559
  %567 = fdiv fast float %10, %532
  %568 = fmul fast float %567, %524
  %569 = fmul fast float %567, %525
  %570 = fmul fast float %567, %526
  %571 = fadd fast float %568, %18
  %572 = fadd fast float %569, %19
  %573 = fadd fast float %570, %20
  %574 = fadd fast float %571, -9.000000e+02
  %575 = fadd fast float %572, -1.500000e+01
  %576 = fadd fast float %573, -7.500000e+02
  %577 = fmul fast float %574, 0x3F62345680000000
  %578 = fmul fast float %575, 0x3F62345680000000
  %579 = fmul fast float %576, 0x3F62345680000000
  %580 = call float @dx.op.dot3.f32(i32 55, float %577, float %578, float %579, float %577, float %578, float %579)  ; Dot3(ax,ay,az,bx,by,bz)
  %581 = fsub fast float 1.000000e+00, %580
  %582 = call float @dx.op.unary.f32(i32 7, float %581)  ; Saturate(value)
  %583 = fmul fast float %582, %582
  %584 = fadd fast float %571, %521
  %585 = fadd fast float %572, %522
  %586 = fadd fast float %573, %523
  %587 = fmul fast float %584, 0x3F52345680000000
  %588 = fadd fast float %587, -2.000000e+00
  %589 = fmul fast float %585, 0x3F52345680000000
  %590 = fadd fast float %589, 0xBFA1111120000000
  %591 = fmul fast float %586, 0x3F52345680000000
  %592 = fadd fast float %591, 0xBFFAAAAAC0000000
  %593 = call float @dx.op.dot3.f32(i32 55, float %588, float %590, float %592, float %588, float %590, float %592)  ; Dot3(ax,ay,az,bx,by,bz)
  %594 = fsub fast float 1.000000e+00, %593
  %595 = call float @dx.op.unary.f32(i32 7, float %594)  ; Saturate(value)
  %596 = fmul fast float %595, %595
  %597 = fmul fast float %596, 4.000000e+00
  %598 = fadd fast float %597, %583
  %599 = fadd fast float %521, -9.000000e+02
  %600 = fadd fast float %522, -1.500000e+01
  %601 = fadd fast float %523, -7.500000e+02
  %602 = fmul fast float %599, 0x3F62345680000000
  %603 = fmul fast float %600, 0x3F62345680000000
  %604 = fmul fast float %601, 0x3F62345680000000
  %605 = call float @dx.op.dot3.f32(i32 55, float %602, float %603, float %604, float %602, float %603, float %604)  ; Dot3(ax,ay,az,bx,by,bz)
  %606 = fsub fast float 1.000000e+00, %605
  %607 = call float @dx.op.unary.f32(i32 7, float %606)  ; Saturate(value)
  %608 = fmul fast float %607, %607
  %609 = fadd fast float %598, %608
  %610 = fmul fast float %533, 0x3F25D867E0000000
  %611 = fmul fast float %610, %609
  br label %612

; <label>:612                                     ; preds = %566, %559
  %613 = phi float [ %611, %566 ], [ 0.000000e+00, %559 ]
  %614 = fadd fast float %613, %562
  %615 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %614)  ; FMin(a,b)
  %616 = fmul fast float %615, 0xBFF7154760000000
  %617 = call float @dx.op.unary.f32(i32 21, float %616)  ; Exp(value)
  %618 = fsub fast float 1.000000e+00, %617
  %619 = call float @dx.op.binary.f32(i32 36, float %13, float %618)  ; FMin(a,b)
  %620 = fsub fast float %14, %182
  %621 = fsub fast float %15, %183
  %622 = fsub fast float %16, %184
  %623 = fmul fast float %619, %620
  %624 = fmul fast float %619, %621
  %625 = fmul fast float %619, %622
  %626 = fadd fast float %623, %182
  %627 = fadd fast float %624, %183
  %628 = fadd fast float %625, %184
  br label %629

; <label>:629                                     ; preds = %612, %491, %485
  %630 = phi float [ %626, %612 ], [ %182, %491 ], [ %182, %485 ]
  %631 = phi float [ %627, %612 ], [ %183, %491 ], [ %183, %485 ]
  %632 = phi float [ %628, %612 ], [ %184, %491 ], [ %184, %485 ]
  %633 = fadd fast float %6, 1.000000e+00
  %634 = fadd fast float %7, 1.000000e+00
  %635 = fsub fast float 1.000000e+00, %6
  %636 = fmul fast float %37, %633
  %637 = fmul fast float %37, %634
  %638 = fmul fast float %37, %635
  %639 = fmul fast float %636, %630
  %640 = fmul fast float %637, %631
  %641 = fmul fast float %638, %632
  %642 = fcmp fast ult float %38, 5.000000e-01
  br i1 %642, label %668, label %643

; <label>:643                                     ; preds = %629
  %644 = fmul fast float %639, 0x4004147AE0000000
  %645 = fmul fast float %640, 0x4004147AE0000000
  %646 = fmul fast float %641, 0x4004147AE0000000
  %647 = fadd fast float %644, 0x3F9EB851E0000000
  %648 = fadd fast float %645, 0x3F9EB851E0000000
  %649 = fadd fast float %646, 0x3F9EB851E0000000
  %650 = fmul fast float %647, %639
  %651 = fmul fast float %648, %640
  %652 = fmul fast float %649, %641
  %653 = fmul fast float %639, 0x400370A3E0000000
  %654 = fmul fast float %640, 0x400370A3E0000000
  %655 = fmul fast float %641, 0x400370A3E0000000
  %656 = fadd fast float %653, 0x3FE2E147A0000000
  %657 = fadd fast float %654, 0x3FE2E147A0000000
  %658 = fadd fast float %655, 0x3FE2E147A0000000
  %659 = fmul fast float %656, %639
  %660 = fmul fast float %657, %640
  %661 = fmul fast float %658, %641
  %662 = fadd fast float %659, 0x3FC1EB8520000000
  %663 = fadd fast float %660, 0x3FC1EB8520000000
  %664 = fadd fast float %661, 0x3FC1EB8520000000
  %665 = fdiv fast float %650, %662
  %666 = fdiv fast float %651, %663
  %667 = fdiv fast float %652, %664
  br label %668

; <label>:668                                     ; preds = %643, %629
  %669 = phi float [ %665, %643 ], [ %639, %629 ]
  %670 = phi float [ %666, %643 ], [ %640, %629 ]
  %671 = phi float [ %667, %643 ], [ %641, %629 ]
  %672 = call float @dx.op.unary.f32(i32 7, float %669)  ; Saturate(value)
  %673 = call float @dx.op.unary.f32(i32 7, float %670)  ; Saturate(value)
  %674 = call float @dx.op.unary.f32(i32 7, float %671)  ; Saturate(value)
  %675 = call float @dx.op.dot3.f32(i32 55, float %672, float %673, float %674, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %676 = fsub fast float %672, %675
  %677 = fsub fast float %673, %675
  %678 = fsub fast float %674, %675
  %679 = fmul fast float %676, %9
  %680 = fmul fast float %677, %9
  %681 = fmul fast float %678, %9
  %682 = fadd fast float %679, %675
  %683 = fadd fast float %680, %675
  %684 = fadd fast float %681, %675
  %685 = call float @dx.op.unary.f32(i32 7, float %682)  ; Saturate(value)
  %686 = call float @dx.op.unary.f32(i32 7, float %683)  ; Saturate(value)
  %687 = call float @dx.op.unary.f32(i32 7, float %684)  ; Saturate(value)
  %688 = fadd fast float %685, 0xBFC70A3D80000000
  %689 = fadd fast float %686, 0xBFC70A3D80000000
  %690 = fadd fast float %687, 0xBFC70A3D80000000
  %691 = fmul fast float %688, %8
  %692 = fmul fast float %689, %8
  %693 = fmul fast float %690, %8
  %694 = fadd fast float %691, 0x3FC70A3D80000000
  %695 = fadd fast float %692, 0x3FC70A3D80000000
  %696 = fadd fast float %693, 0x3FC70A3D80000000
  %697 = call float @dx.op.unary.f32(i32 7, float %694)  ; Saturate(value)
  %698 = call float @dx.op.unary.f32(i32 7, float %695)  ; Saturate(value)
  %699 = call float @dx.op.unary.f32(i32 7, float %696)  ; Saturate(value)
  br label %700

; <label>:700                                     ; preds = %668, %451
  %701 = phi float [ %482, %451 ], [ %697, %668 ]
  %702 = phi float [ %483, %451 ], [ %698, %668 ]
  %703 = phi float [ %484, %451 ], [ %699, %668 ]
  %704 = fcmp fast olt float %190, 0.000000e+00
  br i1 %704, label %705, label %739

; <label>:705                                     ; preds = %700
  %706 = fcmp fast ogt float %187, 0x3FA4B5DCC0000000
  %707 = fcmp fast ogt float %188, 0x3FA4B5DCC0000000
  %708 = fcmp fast ogt float %189, 0x3FA4B5DCC0000000
  %709 = select i1 %706, float 0.000000e+00, float 1.000000e+00
  %710 = select i1 %707, float 0.000000e+00, float 1.000000e+00
  %711 = select i1 %708, float 0.000000e+00, float 1.000000e+00
  %712 = fmul fast float %187, 0x3FB3D07220000000
  %713 = fmul fast float %188, 0x3FB3D07220000000
  %714 = fmul fast float %189, 0x3FB3D07220000000
  %715 = fadd fast float %187, 0x3FAC28F5C0000000
  %716 = fadd fast float %188, 0x3FAC28F5C0000000
  %717 = fadd fast float %189, 0x3FAC28F5C0000000
  %718 = fmul fast float %715, 0x3FEE54EDE0000000
  %719 = fmul fast float %716, 0x3FEE54EDE0000000
  %720 = fmul fast float %717, 0x3FEE54EDE0000000
  %721 = call float @dx.op.unary.f32(i32 23, float %718)  ; Log(value)
  %722 = call float @dx.op.unary.f32(i32 23, float %719)  ; Log(value)
  %723 = call float @dx.op.unary.f32(i32 23, float %720)  ; Log(value)
  %724 = fmul fast float %721, 0x4003333340000000
  %725 = fmul fast float %722, 0x4003333340000000
  %726 = fmul fast float %723, 0x4003333340000000
  %727 = call float @dx.op.unary.f32(i32 21, float %724)  ; Exp(value)
  %728 = call float @dx.op.unary.f32(i32 21, float %725)  ; Exp(value)
  %729 = call float @dx.op.unary.f32(i32 21, float %726)  ; Exp(value)
  %730 = fsub fast float %712, %727
  %731 = fsub fast float %713, %728
  %732 = fsub fast float %714, %729
  %733 = fmul fast float %730, %709
  %734 = fmul fast float %731, %710
  %735 = fmul fast float %732, %711
  %736 = fadd fast float %733, %727
  %737 = fadd fast float %734, %728
  %738 = fadd fast float %735, %729
  br label %954

; <label>:739                                     ; preds = %700
  %740 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %56, i32 %69, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %741 = extractvalue %dx.types.ResRet.f32 %740, 0
  %742 = fcmp fast ogt float %39, 5.000000e-01
  %743 = fcmp fast olt float %741, 1.000000e+00
  %744 = and i1 %742, %743
  br i1 %744, label %745, label %883

; <label>:745                                     ; preds = %739
  %746 = sitofp i32 %56 to float
  %747 = sitofp i32 %69 to float
  %748 = fadd fast float %746, 5.000000e-01
  %749 = fadd fast float %747, 5.000000e-01
  %750 = fdiv fast float %748, %46
  %751 = fdiv fast float %749, %47
  %752 = fmul fast float %750, 2.000000e+00
  %753 = fmul fast float %751, 2.000000e+00
  %754 = fadd fast float %752, -1.000000e+00
  %755 = fsub fast float 1.000000e+00, %753
  %756 = fmul fast float %754, %36
  %757 = call float @dx.op.tertiary.f32(i32 46, float %755, float %32, float %756)  ; FMad(a,b,c)
  %758 = call float @dx.op.tertiary.f32(i32 46, float %741, float %28, float %757)  ; FMad(a,b,c)
  %759 = fadd fast float %758, %24
  %760 = call float @dx.op.unary.f32(i32 6, float %759)  ; FAbs(value)
  %761 = fcmp fast ogt float %760, 0x3EB0C6F7A0000000
  br i1 %761, label %762, label %883

; <label>:762                                     ; preds = %745
  %763 = fmul fast float %754, %35
  %764 = call float @dx.op.tertiary.f32(i32 46, float %755, float %31, float %763)  ; FMad(a,b,c)
  %765 = call float @dx.op.tertiary.f32(i32 46, float %741, float %27, float %764)  ; FMad(a,b,c)
  %766 = fadd fast float %765, %23
  %767 = fmul fast float %754, %34
  %768 = call float @dx.op.tertiary.f32(i32 46, float %755, float %30, float %767)  ; FMad(a,b,c)
  %769 = call float @dx.op.tertiary.f32(i32 46, float %741, float %26, float %768)  ; FMad(a,b,c)
  %770 = fadd fast float %769, %22
  %771 = fmul fast float %754, %33
  %772 = call float @dx.op.tertiary.f32(i32 46, float %755, float %29, float %771)  ; FMad(a,b,c)
  %773 = call float @dx.op.tertiary.f32(i32 46, float %741, float %25, float %772)  ; FMad(a,b,c)
  %774 = fadd fast float %773, %21
  %775 = fdiv fast float %774, %759
  %776 = fdiv fast float %770, %759
  %777 = fdiv fast float %766, %759
  %778 = fsub fast float %775, %18
  %779 = fsub fast float %776, %19
  %780 = fsub fast float %777, %20
  %781 = fmul fast float %778, %778
  %782 = fmul fast float %779, %779
  %783 = fadd fast float %782, %781
  %784 = fmul fast float %780, %780
  %785 = fadd fast float %783, %784
  %786 = call float @dx.op.unary.f32(i32 24, float %785)  ; Sqrt(value)
  %787 = fsub fast float %786, %10
  %788 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %787)  ; FMax(a,b)
  %789 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %789, label %790, label %813

; <label>:790                                     ; preds = %762
  %791 = call float @dx.op.unary.f32(i32 6, float %779)  ; FAbs(value)
  %792 = fmul fast float %791, %12
  %793 = fcmp fast olt float %792, 0x3F50624DE0000000
  br i1 %793, label %794, label %797

; <label>:794                                     ; preds = %790
  %795 = fmul fast float %792, 5.000000e-01
  %796 = fsub fast float 1.000000e+00, %795
  br label %802

; <label>:797                                     ; preds = %790
  %798 = fmul fast float %792, 0xBFF7154760000000
  %799 = call float @dx.op.unary.f32(i32 21, float %798)  ; Exp(value)
  %800 = fsub fast float 1.000000e+00, %799
  %801 = fdiv fast float %800, %792
  br label %802

; <label>:802                                     ; preds = %797, %794
  %803 = phi float [ %796, %794 ], [ %801, %797 ]
  %804 = call float @dx.op.binary.f32(i32 36, float %776, float %19)  ; FMin(a,b)
  %805 = fsub fast float %804, %11
  %806 = fmul fast float %12, %805
  %807 = fsub fast float -0.000000e+00, %806
  %808 = call float @dx.op.binary.f32(i32 35, float %807, float -4.000000e+01)  ; FMax(a,b)
  %809 = call float @dx.op.binary.f32(i32 36, float %808, float 5.000000e+00)  ; FMin(a,b)
  %810 = fmul fast float %809, 0x3FF7154760000000
  %811 = call float @dx.op.unary.f32(i32 21, float %810)  ; Exp(value)
  %812 = fmul fast float %811, %803
  br label %813

; <label>:813                                     ; preds = %802, %762
  %814 = phi float [ %812, %802 ], [ 1.000000e+00, %762 ]
  %815 = fmul fast float %788, %17
  %816 = fmul fast float %815, %814
  %817 = fcmp fast ole float %786, %10
  %818 = fcmp fast olt float %786, 0x3F1A36E2E0000000
  %819 = or i1 %817, %818
  br i1 %819, label %866, label %820

; <label>:820                                     ; preds = %813
  %821 = fdiv fast float %10, %786
  %822 = fmul fast float %821, %778
  %823 = fmul fast float %821, %779
  %824 = fmul fast float %821, %780
  %825 = fadd fast float %822, %18
  %826 = fadd fast float %823, %19
  %827 = fadd fast float %824, %20
  %828 = fadd fast float %825, -9.000000e+02
  %829 = fadd fast float %826, -1.500000e+01
  %830 = fadd fast float %827, -7.500000e+02
  %831 = fmul fast float %828, 0x3F62345680000000
  %832 = fmul fast float %829, 0x3F62345680000000
  %833 = fmul fast float %830, 0x3F62345680000000
  %834 = call float @dx.op.dot3.f32(i32 55, float %831, float %832, float %833, float %831, float %832, float %833)  ; Dot3(ax,ay,az,bx,by,bz)
  %835 = fsub fast float 1.000000e+00, %834
  %836 = call float @dx.op.unary.f32(i32 7, float %835)  ; Saturate(value)
  %837 = fmul fast float %836, %836
  %838 = fadd fast float %825, %775
  %839 = fadd fast float %826, %776
  %840 = fadd fast float %827, %777
  %841 = fmul fast float %838, 0x3F52345680000000
  %842 = fadd fast float %841, -2.000000e+00
  %843 = fmul fast float %839, 0x3F52345680000000
  %844 = fadd fast float %843, 0xBFA1111120000000
  %845 = fmul fast float %840, 0x3F52345680000000
  %846 = fadd fast float %845, 0xBFFAAAAAC0000000
  %847 = call float @dx.op.dot3.f32(i32 55, float %842, float %844, float %846, float %842, float %844, float %846)  ; Dot3(ax,ay,az,bx,by,bz)
  %848 = fsub fast float 1.000000e+00, %847
  %849 = call float @dx.op.unary.f32(i32 7, float %848)  ; Saturate(value)
  %850 = fmul fast float %849, %849
  %851 = fmul fast float %850, 4.000000e+00
  %852 = fadd fast float %851, %837
  %853 = fadd fast float %775, -9.000000e+02
  %854 = fadd fast float %776, -1.500000e+01
  %855 = fadd fast float %777, -7.500000e+02
  %856 = fmul fast float %853, 0x3F62345680000000
  %857 = fmul fast float %854, 0x3F62345680000000
  %858 = fmul fast float %855, 0x3F62345680000000
  %859 = call float @dx.op.dot3.f32(i32 55, float %856, float %857, float %858, float %856, float %857, float %858)  ; Dot3(ax,ay,az,bx,by,bz)
  %860 = fsub fast float 1.000000e+00, %859
  %861 = call float @dx.op.unary.f32(i32 7, float %860)  ; Saturate(value)
  %862 = fmul fast float %861, %861
  %863 = fadd fast float %852, %862
  %864 = fmul fast float %787, 0x3F25D867E0000000
  %865 = fmul fast float %864, %863
  br label %866

; <label>:866                                     ; preds = %820, %813
  %867 = phi float [ %865, %820 ], [ 0.000000e+00, %813 ]
  %868 = fadd fast float %867, %816
  %869 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %868)  ; FMin(a,b)
  %870 = fmul fast float %869, 0xBFF7154760000000
  %871 = call float @dx.op.unary.f32(i32 21, float %870)  ; Exp(value)
  %872 = fsub fast float 1.000000e+00, %871
  %873 = call float @dx.op.binary.f32(i32 36, float %13, float %872)  ; FMin(a,b)
  %874 = fsub fast float %14, %187
  %875 = fsub fast float %15, %188
  %876 = fsub fast float %16, %189
  %877 = fmul fast float %873, %874
  %878 = fmul fast float %873, %875
  %879 = fmul fast float %873, %876
  %880 = fadd fast float %877, %187
  %881 = fadd fast float %878, %188
  %882 = fadd fast float %879, %189
  br label %883

; <label>:883                                     ; preds = %866, %745, %739
  %884 = phi float [ %880, %866 ], [ %187, %745 ], [ %187, %739 ]
  %885 = phi float [ %881, %866 ], [ %188, %745 ], [ %188, %739 ]
  %886 = phi float [ %882, %866 ], [ %189, %745 ], [ %189, %739 ]
  %887 = fadd fast float %6, 1.000000e+00
  %888 = fadd fast float %7, 1.000000e+00
  %889 = fsub fast float 1.000000e+00, %6
  %890 = fmul fast float %37, %887
  %891 = fmul fast float %37, %888
  %892 = fmul fast float %37, %889
  %893 = fmul fast float %890, %884
  %894 = fmul fast float %891, %885
  %895 = fmul fast float %892, %886
  %896 = fcmp fast ult float %38, 5.000000e-01
  br i1 %896, label %922, label %897

; <label>:897                                     ; preds = %883
  %898 = fmul fast float %893, 0x4004147AE0000000
  %899 = fmul fast float %894, 0x4004147AE0000000
  %900 = fmul fast float %895, 0x4004147AE0000000
  %901 = fadd fast float %898, 0x3F9EB851E0000000
  %902 = fadd fast float %899, 0x3F9EB851E0000000
  %903 = fadd fast float %900, 0x3F9EB851E0000000
  %904 = fmul fast float %901, %893
  %905 = fmul fast float %902, %894
  %906 = fmul fast float %903, %895
  %907 = fmul fast float %893, 0x400370A3E0000000
  %908 = fmul fast float %894, 0x400370A3E0000000
  %909 = fmul fast float %895, 0x400370A3E0000000
  %910 = fadd fast float %907, 0x3FE2E147A0000000
  %911 = fadd fast float %908, 0x3FE2E147A0000000
  %912 = fadd fast float %909, 0x3FE2E147A0000000
  %913 = fmul fast float %910, %893
  %914 = fmul fast float %911, %894
  %915 = fmul fast float %912, %895
  %916 = fadd fast float %913, 0x3FC1EB8520000000
  %917 = fadd fast float %914, 0x3FC1EB8520000000
  %918 = fadd fast float %915, 0x3FC1EB8520000000
  %919 = fdiv fast float %904, %916
  %920 = fdiv fast float %905, %917
  %921 = fdiv fast float %906, %918
  br label %922

; <label>:922                                     ; preds = %897, %883
  %923 = phi float [ %919, %897 ], [ %893, %883 ]
  %924 = phi float [ %920, %897 ], [ %894, %883 ]
  %925 = phi float [ %921, %897 ], [ %895, %883 ]
  %926 = call float @dx.op.unary.f32(i32 7, float %923)  ; Saturate(value)
  %927 = call float @dx.op.unary.f32(i32 7, float %924)  ; Saturate(value)
  %928 = call float @dx.op.unary.f32(i32 7, float %925)  ; Saturate(value)
  %929 = call float @dx.op.dot3.f32(i32 55, float %926, float %927, float %928, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %930 = fsub fast float %926, %929
  %931 = fsub fast float %927, %929
  %932 = fsub fast float %928, %929
  %933 = fmul fast float %930, %9
  %934 = fmul fast float %931, %9
  %935 = fmul fast float %932, %9
  %936 = fadd fast float %933, %929
  %937 = fadd fast float %934, %929
  %938 = fadd fast float %935, %929
  %939 = call float @dx.op.unary.f32(i32 7, float %936)  ; Saturate(value)
  %940 = call float @dx.op.unary.f32(i32 7, float %937)  ; Saturate(value)
  %941 = call float @dx.op.unary.f32(i32 7, float %938)  ; Saturate(value)
  %942 = fadd fast float %939, 0xBFC70A3D80000000
  %943 = fadd fast float %940, 0xBFC70A3D80000000
  %944 = fadd fast float %941, 0xBFC70A3D80000000
  %945 = fmul fast float %942, %8
  %946 = fmul fast float %943, %8
  %947 = fmul fast float %944, %8
  %948 = fadd fast float %945, 0x3FC70A3D80000000
  %949 = fadd fast float %946, 0x3FC70A3D80000000
  %950 = fadd fast float %947, 0x3FC70A3D80000000
  %951 = call float @dx.op.unary.f32(i32 7, float %948)  ; Saturate(value)
  %952 = call float @dx.op.unary.f32(i32 7, float %949)  ; Saturate(value)
  %953 = call float @dx.op.unary.f32(i32 7, float %950)  ; Saturate(value)
  br label %954

; <label>:954                                     ; preds = %922, %705
  %955 = phi float [ %736, %705 ], [ %951, %922 ]
  %956 = phi float [ %737, %705 ], [ %952, %922 ]
  %957 = phi float [ %738, %705 ], [ %953, %922 ]
  %958 = fcmp fast olt float %195, 0.000000e+00
  br i1 %958, label %959, label %993

; <label>:959                                     ; preds = %954
  %960 = fcmp fast ogt float %192, 0x3FA4B5DCC0000000
  %961 = fcmp fast ogt float %193, 0x3FA4B5DCC0000000
  %962 = fcmp fast ogt float %194, 0x3FA4B5DCC0000000
  %963 = select i1 %960, float 0.000000e+00, float 1.000000e+00
  %964 = select i1 %961, float 0.000000e+00, float 1.000000e+00
  %965 = select i1 %962, float 0.000000e+00, float 1.000000e+00
  %966 = fmul fast float %192, 0x3FB3D07220000000
  %967 = fmul fast float %193, 0x3FB3D07220000000
  %968 = fmul fast float %194, 0x3FB3D07220000000
  %969 = fadd fast float %192, 0x3FAC28F5C0000000
  %970 = fadd fast float %193, 0x3FAC28F5C0000000
  %971 = fadd fast float %194, 0x3FAC28F5C0000000
  %972 = fmul fast float %969, 0x3FEE54EDE0000000
  %973 = fmul fast float %970, 0x3FEE54EDE0000000
  %974 = fmul fast float %971, 0x3FEE54EDE0000000
  %975 = call float @dx.op.unary.f32(i32 23, float %972)  ; Log(value)
  %976 = call float @dx.op.unary.f32(i32 23, float %973)  ; Log(value)
  %977 = call float @dx.op.unary.f32(i32 23, float %974)  ; Log(value)
  %978 = fmul fast float %975, 0x4003333340000000
  %979 = fmul fast float %976, 0x4003333340000000
  %980 = fmul fast float %977, 0x4003333340000000
  %981 = call float @dx.op.unary.f32(i32 21, float %978)  ; Exp(value)
  %982 = call float @dx.op.unary.f32(i32 21, float %979)  ; Exp(value)
  %983 = call float @dx.op.unary.f32(i32 21, float %980)  ; Exp(value)
  %984 = fsub fast float %966, %981
  %985 = fsub fast float %967, %982
  %986 = fsub fast float %968, %983
  %987 = fmul fast float %984, %963
  %988 = fmul fast float %985, %964
  %989 = fmul fast float %986, %965
  %990 = fadd fast float %987, %981
  %991 = fadd fast float %988, %982
  %992 = fadd fast float %989, %983
  br label %1208

; <label>:993                                     ; preds = %954
  %994 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %66, i32 %69, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %995 = extractvalue %dx.types.ResRet.f32 %994, 0
  %996 = fcmp fast ogt float %39, 5.000000e-01
  %997 = fcmp fast olt float %995, 1.000000e+00
  %998 = and i1 %996, %997
  br i1 %998, label %999, label %1137

; <label>:999                                     ; preds = %993
  %1000 = sitofp i32 %66 to float
  %1001 = sitofp i32 %69 to float
  %1002 = fadd fast float %1000, 5.000000e-01
  %1003 = fadd fast float %1001, 5.000000e-01
  %1004 = fdiv fast float %1002, %46
  %1005 = fdiv fast float %1003, %47
  %1006 = fmul fast float %1004, 2.000000e+00
  %1007 = fmul fast float %1005, 2.000000e+00
  %1008 = fadd fast float %1006, -1.000000e+00
  %1009 = fsub fast float 1.000000e+00, %1007
  %1010 = fmul fast float %1008, %36
  %1011 = call float @dx.op.tertiary.f32(i32 46, float %1009, float %32, float %1010)  ; FMad(a,b,c)
  %1012 = call float @dx.op.tertiary.f32(i32 46, float %995, float %28, float %1011)  ; FMad(a,b,c)
  %1013 = fadd fast float %1012, %24
  %1014 = call float @dx.op.unary.f32(i32 6, float %1013)  ; FAbs(value)
  %1015 = fcmp fast ogt float %1014, 0x3EB0C6F7A0000000
  br i1 %1015, label %1016, label %1137

; <label>:1016                                    ; preds = %999
  %1017 = fmul fast float %1008, %35
  %1018 = call float @dx.op.tertiary.f32(i32 46, float %1009, float %31, float %1017)  ; FMad(a,b,c)
  %1019 = call float @dx.op.tertiary.f32(i32 46, float %995, float %27, float %1018)  ; FMad(a,b,c)
  %1020 = fadd fast float %1019, %23
  %1021 = fmul fast float %1008, %34
  %1022 = call float @dx.op.tertiary.f32(i32 46, float %1009, float %30, float %1021)  ; FMad(a,b,c)
  %1023 = call float @dx.op.tertiary.f32(i32 46, float %995, float %26, float %1022)  ; FMad(a,b,c)
  %1024 = fadd fast float %1023, %22
  %1025 = fmul fast float %1008, %33
  %1026 = call float @dx.op.tertiary.f32(i32 46, float %1009, float %29, float %1025)  ; FMad(a,b,c)
  %1027 = call float @dx.op.tertiary.f32(i32 46, float %995, float %25, float %1026)  ; FMad(a,b,c)
  %1028 = fadd fast float %1027, %21
  %1029 = fdiv fast float %1028, %1013
  %1030 = fdiv fast float %1024, %1013
  %1031 = fdiv fast float %1020, %1013
  %1032 = fsub fast float %1029, %18
  %1033 = fsub fast float %1030, %19
  %1034 = fsub fast float %1031, %20
  %1035 = fmul fast float %1032, %1032
  %1036 = fmul fast float %1033, %1033
  %1037 = fadd fast float %1036, %1035
  %1038 = fmul fast float %1034, %1034
  %1039 = fadd fast float %1037, %1038
  %1040 = call float @dx.op.unary.f32(i32 24, float %1039)  ; Sqrt(value)
  %1041 = fsub fast float %1040, %10
  %1042 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1041)  ; FMax(a,b)
  %1043 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %1043, label %1044, label %1067

; <label>:1044                                    ; preds = %1016
  %1045 = call float @dx.op.unary.f32(i32 6, float %1033)  ; FAbs(value)
  %1046 = fmul fast float %1045, %12
  %1047 = fcmp fast olt float %1046, 0x3F50624DE0000000
  br i1 %1047, label %1048, label %1051

; <label>:1048                                    ; preds = %1044
  %1049 = fmul fast float %1046, 5.000000e-01
  %1050 = fsub fast float 1.000000e+00, %1049
  br label %1056

; <label>:1051                                    ; preds = %1044
  %1052 = fmul fast float %1046, 0xBFF7154760000000
  %1053 = call float @dx.op.unary.f32(i32 21, float %1052)  ; Exp(value)
  %1054 = fsub fast float 1.000000e+00, %1053
  %1055 = fdiv fast float %1054, %1046
  br label %1056

; <label>:1056                                    ; preds = %1051, %1048
  %1057 = phi float [ %1050, %1048 ], [ %1055, %1051 ]
  %1058 = call float @dx.op.binary.f32(i32 36, float %1030, float %19)  ; FMin(a,b)
  %1059 = fsub fast float %1058, %11
  %1060 = fmul fast float %12, %1059
  %1061 = fsub fast float -0.000000e+00, %1060
  %1062 = call float @dx.op.binary.f32(i32 35, float %1061, float -4.000000e+01)  ; FMax(a,b)
  %1063 = call float @dx.op.binary.f32(i32 36, float %1062, float 5.000000e+00)  ; FMin(a,b)
  %1064 = fmul fast float %1063, 0x3FF7154760000000
  %1065 = call float @dx.op.unary.f32(i32 21, float %1064)  ; Exp(value)
  %1066 = fmul fast float %1065, %1057
  br label %1067

; <label>:1067                                    ; preds = %1056, %1016
  %1068 = phi float [ %1066, %1056 ], [ 1.000000e+00, %1016 ]
  %1069 = fmul fast float %1042, %17
  %1070 = fmul fast float %1069, %1068
  %1071 = fcmp fast ole float %1040, %10
  %1072 = fcmp fast olt float %1040, 0x3F1A36E2E0000000
  %1073 = or i1 %1071, %1072
  br i1 %1073, label %1120, label %1074

; <label>:1074                                    ; preds = %1067
  %1075 = fdiv fast float %10, %1040
  %1076 = fmul fast float %1075, %1032
  %1077 = fmul fast float %1075, %1033
  %1078 = fmul fast float %1075, %1034
  %1079 = fadd fast float %1076, %18
  %1080 = fadd fast float %1077, %19
  %1081 = fadd fast float %1078, %20
  %1082 = fadd fast float %1079, -9.000000e+02
  %1083 = fadd fast float %1080, -1.500000e+01
  %1084 = fadd fast float %1081, -7.500000e+02
  %1085 = fmul fast float %1082, 0x3F62345680000000
  %1086 = fmul fast float %1083, 0x3F62345680000000
  %1087 = fmul fast float %1084, 0x3F62345680000000
  %1088 = call float @dx.op.dot3.f32(i32 55, float %1085, float %1086, float %1087, float %1085, float %1086, float %1087)  ; Dot3(ax,ay,az,bx,by,bz)
  %1089 = fsub fast float 1.000000e+00, %1088
  %1090 = call float @dx.op.unary.f32(i32 7, float %1089)  ; Saturate(value)
  %1091 = fmul fast float %1090, %1090
  %1092 = fadd fast float %1079, %1029
  %1093 = fadd fast float %1080, %1030
  %1094 = fadd fast float %1081, %1031
  %1095 = fmul fast float %1092, 0x3F52345680000000
  %1096 = fadd fast float %1095, -2.000000e+00
  %1097 = fmul fast float %1093, 0x3F52345680000000
  %1098 = fadd fast float %1097, 0xBFA1111120000000
  %1099 = fmul fast float %1094, 0x3F52345680000000
  %1100 = fadd fast float %1099, 0xBFFAAAAAC0000000
  %1101 = call float @dx.op.dot3.f32(i32 55, float %1096, float %1098, float %1100, float %1096, float %1098, float %1100)  ; Dot3(ax,ay,az,bx,by,bz)
  %1102 = fsub fast float 1.000000e+00, %1101
  %1103 = call float @dx.op.unary.f32(i32 7, float %1102)  ; Saturate(value)
  %1104 = fmul fast float %1103, %1103
  %1105 = fmul fast float %1104, 4.000000e+00
  %1106 = fadd fast float %1105, %1091
  %1107 = fadd fast float %1029, -9.000000e+02
  %1108 = fadd fast float %1030, -1.500000e+01
  %1109 = fadd fast float %1031, -7.500000e+02
  %1110 = fmul fast float %1107, 0x3F62345680000000
  %1111 = fmul fast float %1108, 0x3F62345680000000
  %1112 = fmul fast float %1109, 0x3F62345680000000
  %1113 = call float @dx.op.dot3.f32(i32 55, float %1110, float %1111, float %1112, float %1110, float %1111, float %1112)  ; Dot3(ax,ay,az,bx,by,bz)
  %1114 = fsub fast float 1.000000e+00, %1113
  %1115 = call float @dx.op.unary.f32(i32 7, float %1114)  ; Saturate(value)
  %1116 = fmul fast float %1115, %1115
  %1117 = fadd fast float %1106, %1116
  %1118 = fmul fast float %1041, 0x3F25D867E0000000
  %1119 = fmul fast float %1118, %1117
  br label %1120

; <label>:1120                                    ; preds = %1074, %1067
  %1121 = phi float [ %1119, %1074 ], [ 0.000000e+00, %1067 ]
  %1122 = fadd fast float %1121, %1070
  %1123 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1122)  ; FMin(a,b)
  %1124 = fmul fast float %1123, 0xBFF7154760000000
  %1125 = call float @dx.op.unary.f32(i32 21, float %1124)  ; Exp(value)
  %1126 = fsub fast float 1.000000e+00, %1125
  %1127 = call float @dx.op.binary.f32(i32 36, float %13, float %1126)  ; FMin(a,b)
  %1128 = fsub fast float %14, %192
  %1129 = fsub fast float %15, %193
  %1130 = fsub fast float %16, %194
  %1131 = fmul fast float %1127, %1128
  %1132 = fmul fast float %1127, %1129
  %1133 = fmul fast float %1127, %1130
  %1134 = fadd fast float %1131, %192
  %1135 = fadd fast float %1132, %193
  %1136 = fadd fast float %1133, %194
  br label %1137

; <label>:1137                                    ; preds = %1120, %999, %993
  %1138 = phi float [ %1134, %1120 ], [ %192, %999 ], [ %192, %993 ]
  %1139 = phi float [ %1135, %1120 ], [ %193, %999 ], [ %193, %993 ]
  %1140 = phi float [ %1136, %1120 ], [ %194, %999 ], [ %194, %993 ]
  %1141 = fadd fast float %6, 1.000000e+00
  %1142 = fadd fast float %7, 1.000000e+00
  %1143 = fsub fast float 1.000000e+00, %6
  %1144 = fmul fast float %37, %1141
  %1145 = fmul fast float %37, %1142
  %1146 = fmul fast float %37, %1143
  %1147 = fmul fast float %1144, %1138
  %1148 = fmul fast float %1145, %1139
  %1149 = fmul fast float %1146, %1140
  %1150 = fcmp fast ult float %38, 5.000000e-01
  br i1 %1150, label %1176, label %1151

; <label>:1151                                    ; preds = %1137
  %1152 = fmul fast float %1147, 0x4004147AE0000000
  %1153 = fmul fast float %1148, 0x4004147AE0000000
  %1154 = fmul fast float %1149, 0x4004147AE0000000
  %1155 = fadd fast float %1152, 0x3F9EB851E0000000
  %1156 = fadd fast float %1153, 0x3F9EB851E0000000
  %1157 = fadd fast float %1154, 0x3F9EB851E0000000
  %1158 = fmul fast float %1155, %1147
  %1159 = fmul fast float %1156, %1148
  %1160 = fmul fast float %1157, %1149
  %1161 = fmul fast float %1147, 0x400370A3E0000000
  %1162 = fmul fast float %1148, 0x400370A3E0000000
  %1163 = fmul fast float %1149, 0x400370A3E0000000
  %1164 = fadd fast float %1161, 0x3FE2E147A0000000
  %1165 = fadd fast float %1162, 0x3FE2E147A0000000
  %1166 = fadd fast float %1163, 0x3FE2E147A0000000
  %1167 = fmul fast float %1164, %1147
  %1168 = fmul fast float %1165, %1148
  %1169 = fmul fast float %1166, %1149
  %1170 = fadd fast float %1167, 0x3FC1EB8520000000
  %1171 = fadd fast float %1168, 0x3FC1EB8520000000
  %1172 = fadd fast float %1169, 0x3FC1EB8520000000
  %1173 = fdiv fast float %1158, %1170
  %1174 = fdiv fast float %1159, %1171
  %1175 = fdiv fast float %1160, %1172
  br label %1176

; <label>:1176                                    ; preds = %1151, %1137
  %1177 = phi float [ %1173, %1151 ], [ %1147, %1137 ]
  %1178 = phi float [ %1174, %1151 ], [ %1148, %1137 ]
  %1179 = phi float [ %1175, %1151 ], [ %1149, %1137 ]
  %1180 = call float @dx.op.unary.f32(i32 7, float %1177)  ; Saturate(value)
  %1181 = call float @dx.op.unary.f32(i32 7, float %1178)  ; Saturate(value)
  %1182 = call float @dx.op.unary.f32(i32 7, float %1179)  ; Saturate(value)
  %1183 = call float @dx.op.dot3.f32(i32 55, float %1180, float %1181, float %1182, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1184 = fsub fast float %1180, %1183
  %1185 = fsub fast float %1181, %1183
  %1186 = fsub fast float %1182, %1183
  %1187 = fmul fast float %1184, %9
  %1188 = fmul fast float %1185, %9
  %1189 = fmul fast float %1186, %9
  %1190 = fadd fast float %1187, %1183
  %1191 = fadd fast float %1188, %1183
  %1192 = fadd fast float %1189, %1183
  %1193 = call float @dx.op.unary.f32(i32 7, float %1190)  ; Saturate(value)
  %1194 = call float @dx.op.unary.f32(i32 7, float %1191)  ; Saturate(value)
  %1195 = call float @dx.op.unary.f32(i32 7, float %1192)  ; Saturate(value)
  %1196 = fadd fast float %1193, 0xBFC70A3D80000000
  %1197 = fadd fast float %1194, 0xBFC70A3D80000000
  %1198 = fadd fast float %1195, 0xBFC70A3D80000000
  %1199 = fmul fast float %1196, %8
  %1200 = fmul fast float %1197, %8
  %1201 = fmul fast float %1198, %8
  %1202 = fadd fast float %1199, 0x3FC70A3D80000000
  %1203 = fadd fast float %1200, 0x3FC70A3D80000000
  %1204 = fadd fast float %1201, 0x3FC70A3D80000000
  %1205 = call float @dx.op.unary.f32(i32 7, float %1202)  ; Saturate(value)
  %1206 = call float @dx.op.unary.f32(i32 7, float %1203)  ; Saturate(value)
  %1207 = call float @dx.op.unary.f32(i32 7, float %1204)  ; Saturate(value)
  br label %1208

; <label>:1208                                    ; preds = %1176, %959
  %1209 = phi float [ %990, %959 ], [ %1205, %1176 ]
  %1210 = phi float [ %991, %959 ], [ %1206, %1176 ]
  %1211 = phi float [ %992, %959 ], [ %1207, %1176 ]
  %1212 = fsub fast float -1.000000e+00, %180
  %1213 = select i1 %196, float %1212, float %180
  %1214 = fsub fast float -1.000000e+00, %185
  %1215 = select i1 %450, float %1214, float %185
  %1216 = fsub fast float -1.000000e+00, %190
  %1217 = select i1 %704, float %1216, float %190
  %1218 = fsub fast float -1.000000e+00, %195
  %1219 = select i1 %958, float %1218, float %195
  %1220 = fcmp fast ugt float %3, 0.000000e+00
  br i1 %1220, label %1221, label %10186

; <label>:1221                                    ; preds = %1208
  %1222 = fcmp fast ult float %180, 0.000000e+00
  br i1 %1222, label %1942, label %1223

; <label>:1223                                    ; preds = %1221
  %1224 = fsub fast float 1.000000e+00, %83
  %1225 = fmul fast float %1224, 0x3FA99999A0000000
  %1226 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %1225)  ; FMax(a,b)
  %1227 = fsub fast float %85, %83
  %1228 = call float @dx.op.unary.f32(i32 6, float %1227)  ; FAbs(value)
  %1229 = fdiv fast float %1228, %1226
  %1230 = fsub fast float 1.000000e+00, %1229
  %1231 = call float @dx.op.unary.f32(i32 7, float %1230)  ; Saturate(value)
  %1232 = fcmp fast ugt float %1231, 0.000000e+00
  br i1 %1232, label %1233, label %1243

; <label>:1233                                    ; preds = %1223
  %1234 = fsub fast float %701, %447
  %1235 = fsub fast float %702, %448
  %1236 = fsub fast float %703, %449
  %1237 = fmul fast float %1231, %1234
  %1238 = fmul fast float %1231, %1235
  %1239 = fmul fast float %1231, %1236
  %1240 = fadd fast float %1237, %447
  %1241 = fadd fast float %1238, %448
  %1242 = fadd fast float %1239, %449
  br label %1243

; <label>:1243                                    ; preds = %1233, %1223
  %1244 = phi float [ %1240, %1233 ], [ %447, %1223 ]
  %1245 = phi float [ %1241, %1233 ], [ %448, %1223 ]
  %1246 = phi float [ %1242, %1233 ], [ %449, %1223 ]
  %1247 = add i32 %56, -1
  %1248 = call i32 @dx.op.binary.i32(i32 37, i32 %1247, i32 0)  ; IMax(a,b)
  %1249 = call i32 @dx.op.binary.i32(i32 38, i32 %1248, i32 %60)  ; IMin(a,b)
  %1250 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1249, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1251 = extractvalue %dx.types.ResRet.f32 %1250, 0
  %1252 = fsub fast float %1251, %83
  %1253 = call float @dx.op.unary.f32(i32 6, float %1252)  ; FAbs(value)
  %1254 = fdiv fast float %1253, %1226
  %1255 = fsub fast float 1.000000e+00, %1254
  %1256 = call float @dx.op.unary.f32(i32 7, float %1255)  ; Saturate(value)
  %1257 = fcmp fast ugt float %1256, 0.000000e+00
  br i1 %1257, label %1258, label %1531

; <label>:1258                                    ; preds = %1243
  %1259 = call i32 @dx.op.binary.i32(i32 37, i32 %1249, i32 0)  ; IMax(a,b)
  %1260 = call i32 @dx.op.binary.i32(i32 37, i32 %65, i32 0)  ; IMax(a,b)
  %1261 = call i32 @dx.op.binary.i32(i32 38, i32 %1259, i32 %60)  ; IMin(a,b)
  %1262 = call i32 @dx.op.binary.i32(i32 38, i32 %1260, i32 %61)  ; IMin(a,b)
  %1263 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1261, i32 %1262, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1264 = extractvalue %dx.types.ResRet.f32 %1263, 0
  %1265 = extractvalue %dx.types.ResRet.f32 %1263, 1
  %1266 = extractvalue %dx.types.ResRet.f32 %1263, 2
  %1267 = extractvalue %dx.types.ResRet.f32 %1263, 3
  %1268 = fcmp fast olt float %1267, 0.000000e+00
  br i1 %1268, label %1269, label %1303

; <label>:1269                                    ; preds = %1258
  %1270 = fcmp fast ogt float %1264, 0x3FA4B5DCC0000000
  %1271 = fcmp fast ogt float %1265, 0x3FA4B5DCC0000000
  %1272 = fcmp fast ogt float %1266, 0x3FA4B5DCC0000000
  %1273 = select i1 %1270, float 0.000000e+00, float 1.000000e+00
  %1274 = select i1 %1271, float 0.000000e+00, float 1.000000e+00
  %1275 = select i1 %1272, float 0.000000e+00, float 1.000000e+00
  %1276 = fmul fast float %1264, 0x3FB3D07220000000
  %1277 = fmul fast float %1265, 0x3FB3D07220000000
  %1278 = fmul fast float %1266, 0x3FB3D07220000000
  %1279 = fadd fast float %1264, 0x3FAC28F5C0000000
  %1280 = fadd fast float %1265, 0x3FAC28F5C0000000
  %1281 = fadd fast float %1266, 0x3FAC28F5C0000000
  %1282 = fmul fast float %1279, 0x3FEE54EDE0000000
  %1283 = fmul fast float %1280, 0x3FEE54EDE0000000
  %1284 = fmul fast float %1281, 0x3FEE54EDE0000000
  %1285 = call float @dx.op.unary.f32(i32 23, float %1282)  ; Log(value)
  %1286 = call float @dx.op.unary.f32(i32 23, float %1283)  ; Log(value)
  %1287 = call float @dx.op.unary.f32(i32 23, float %1284)  ; Log(value)
  %1288 = fmul fast float %1285, 0x4003333340000000
  %1289 = fmul fast float %1286, 0x4003333340000000
  %1290 = fmul fast float %1287, 0x4003333340000000
  %1291 = call float @dx.op.unary.f32(i32 21, float %1288)  ; Exp(value)
  %1292 = call float @dx.op.unary.f32(i32 21, float %1289)  ; Exp(value)
  %1293 = call float @dx.op.unary.f32(i32 21, float %1290)  ; Exp(value)
  %1294 = fsub fast float %1276, %1291
  %1295 = fsub fast float %1277, %1292
  %1296 = fsub fast float %1278, %1293
  %1297 = fmul fast float %1294, %1273
  %1298 = fmul fast float %1295, %1274
  %1299 = fmul fast float %1296, %1275
  %1300 = fadd fast float %1297, %1291
  %1301 = fadd fast float %1298, %1292
  %1302 = fadd fast float %1299, %1293
  br label %1518

; <label>:1303                                    ; preds = %1258
  %1304 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1261, i32 %1262, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1305 = extractvalue %dx.types.ResRet.f32 %1304, 0
  %1306 = fcmp fast ogt float %39, 5.000000e-01
  %1307 = fcmp fast olt float %1305, 1.000000e+00
  %1308 = and i1 %1306, %1307
  br i1 %1308, label %1309, label %1447

; <label>:1309                                    ; preds = %1303
  %1310 = sitofp i32 %1261 to float
  %1311 = sitofp i32 %1262 to float
  %1312 = fadd fast float %1310, 5.000000e-01
  %1313 = fadd fast float %1311, 5.000000e-01
  %1314 = fdiv fast float %1312, %46
  %1315 = fdiv fast float %1313, %47
  %1316 = fmul fast float %1314, 2.000000e+00
  %1317 = fmul fast float %1315, 2.000000e+00
  %1318 = fadd fast float %1316, -1.000000e+00
  %1319 = fsub fast float 1.000000e+00, %1317
  %1320 = fmul fast float %1318, %36
  %1321 = call float @dx.op.tertiary.f32(i32 46, float %1319, float %32, float %1320)  ; FMad(a,b,c)
  %1322 = call float @dx.op.tertiary.f32(i32 46, float %1305, float %28, float %1321)  ; FMad(a,b,c)
  %1323 = fadd fast float %1322, %24
  %1324 = call float @dx.op.unary.f32(i32 6, float %1323)  ; FAbs(value)
  %1325 = fcmp fast ogt float %1324, 0x3EB0C6F7A0000000
  br i1 %1325, label %1326, label %1447

; <label>:1326                                    ; preds = %1309
  %1327 = fmul fast float %1318, %35
  %1328 = call float @dx.op.tertiary.f32(i32 46, float %1319, float %31, float %1327)  ; FMad(a,b,c)
  %1329 = call float @dx.op.tertiary.f32(i32 46, float %1305, float %27, float %1328)  ; FMad(a,b,c)
  %1330 = fadd fast float %1329, %23
  %1331 = fmul fast float %1318, %34
  %1332 = call float @dx.op.tertiary.f32(i32 46, float %1319, float %30, float %1331)  ; FMad(a,b,c)
  %1333 = call float @dx.op.tertiary.f32(i32 46, float %1305, float %26, float %1332)  ; FMad(a,b,c)
  %1334 = fadd fast float %1333, %22
  %1335 = fmul fast float %1318, %33
  %1336 = call float @dx.op.tertiary.f32(i32 46, float %1319, float %29, float %1335)  ; FMad(a,b,c)
  %1337 = call float @dx.op.tertiary.f32(i32 46, float %1305, float %25, float %1336)  ; FMad(a,b,c)
  %1338 = fadd fast float %1337, %21
  %1339 = fdiv fast float %1338, %1323
  %1340 = fdiv fast float %1334, %1323
  %1341 = fdiv fast float %1330, %1323
  %1342 = fsub fast float %1339, %18
  %1343 = fsub fast float %1340, %19
  %1344 = fsub fast float %1341, %20
  %1345 = fmul fast float %1342, %1342
  %1346 = fmul fast float %1343, %1343
  %1347 = fadd fast float %1346, %1345
  %1348 = fmul fast float %1344, %1344
  %1349 = fadd fast float %1347, %1348
  %1350 = call float @dx.op.unary.f32(i32 24, float %1349)  ; Sqrt(value)
  %1351 = fsub fast float %1350, %10
  %1352 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1351)  ; FMax(a,b)
  %1353 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %1353, label %1354, label %1377

; <label>:1354                                    ; preds = %1326
  %1355 = call float @dx.op.unary.f32(i32 6, float %1343)  ; FAbs(value)
  %1356 = fmul fast float %1355, %12
  %1357 = fcmp fast olt float %1356, 0x3F50624DE0000000
  br i1 %1357, label %1358, label %1361

; <label>:1358                                    ; preds = %1354
  %1359 = fmul fast float %1356, 5.000000e-01
  %1360 = fsub fast float 1.000000e+00, %1359
  br label %1366

; <label>:1361                                    ; preds = %1354
  %1362 = fmul fast float %1356, 0xBFF7154760000000
  %1363 = call float @dx.op.unary.f32(i32 21, float %1362)  ; Exp(value)
  %1364 = fsub fast float 1.000000e+00, %1363
  %1365 = fdiv fast float %1364, %1356
  br label %1366

; <label>:1366                                    ; preds = %1361, %1358
  %1367 = phi float [ %1360, %1358 ], [ %1365, %1361 ]
  %1368 = call float @dx.op.binary.f32(i32 36, float %1340, float %19)  ; FMin(a,b)
  %1369 = fsub fast float %1368, %11
  %1370 = fmul fast float %12, %1369
  %1371 = fsub fast float -0.000000e+00, %1370
  %1372 = call float @dx.op.binary.f32(i32 35, float %1371, float -4.000000e+01)  ; FMax(a,b)
  %1373 = call float @dx.op.binary.f32(i32 36, float %1372, float 5.000000e+00)  ; FMin(a,b)
  %1374 = fmul fast float %1373, 0x3FF7154760000000
  %1375 = call float @dx.op.unary.f32(i32 21, float %1374)  ; Exp(value)
  %1376 = fmul fast float %1375, %1367
  br label %1377

; <label>:1377                                    ; preds = %1366, %1326
  %1378 = phi float [ %1376, %1366 ], [ 1.000000e+00, %1326 ]
  %1379 = fmul fast float %1352, %17
  %1380 = fmul fast float %1379, %1378
  %1381 = fcmp fast ole float %1350, %10
  %1382 = fcmp fast olt float %1350, 0x3F1A36E2E0000000
  %1383 = or i1 %1381, %1382
  br i1 %1383, label %1430, label %1384

; <label>:1384                                    ; preds = %1377
  %1385 = fdiv fast float %10, %1350
  %1386 = fmul fast float %1385, %1342
  %1387 = fmul fast float %1385, %1343
  %1388 = fmul fast float %1385, %1344
  %1389 = fadd fast float %1386, %18
  %1390 = fadd fast float %1387, %19
  %1391 = fadd fast float %1388, %20
  %1392 = fadd fast float %1389, -9.000000e+02
  %1393 = fadd fast float %1390, -1.500000e+01
  %1394 = fadd fast float %1391, -7.500000e+02
  %1395 = fmul fast float %1392, 0x3F62345680000000
  %1396 = fmul fast float %1393, 0x3F62345680000000
  %1397 = fmul fast float %1394, 0x3F62345680000000
  %1398 = call float @dx.op.dot3.f32(i32 55, float %1395, float %1396, float %1397, float %1395, float %1396, float %1397)  ; Dot3(ax,ay,az,bx,by,bz)
  %1399 = fsub fast float 1.000000e+00, %1398
  %1400 = call float @dx.op.unary.f32(i32 7, float %1399)  ; Saturate(value)
  %1401 = fmul fast float %1400, %1400
  %1402 = fadd fast float %1389, %1339
  %1403 = fadd fast float %1390, %1340
  %1404 = fadd fast float %1391, %1341
  %1405 = fmul fast float %1402, 0x3F52345680000000
  %1406 = fadd fast float %1405, -2.000000e+00
  %1407 = fmul fast float %1403, 0x3F52345680000000
  %1408 = fadd fast float %1407, 0xBFA1111120000000
  %1409 = fmul fast float %1404, 0x3F52345680000000
  %1410 = fadd fast float %1409, 0xBFFAAAAAC0000000
  %1411 = call float @dx.op.dot3.f32(i32 55, float %1406, float %1408, float %1410, float %1406, float %1408, float %1410)  ; Dot3(ax,ay,az,bx,by,bz)
  %1412 = fsub fast float 1.000000e+00, %1411
  %1413 = call float @dx.op.unary.f32(i32 7, float %1412)  ; Saturate(value)
  %1414 = fmul fast float %1413, %1413
  %1415 = fmul fast float %1414, 4.000000e+00
  %1416 = fadd fast float %1415, %1401
  %1417 = fadd fast float %1339, -9.000000e+02
  %1418 = fadd fast float %1340, -1.500000e+01
  %1419 = fadd fast float %1341, -7.500000e+02
  %1420 = fmul fast float %1417, 0x3F62345680000000
  %1421 = fmul fast float %1418, 0x3F62345680000000
  %1422 = fmul fast float %1419, 0x3F62345680000000
  %1423 = call float @dx.op.dot3.f32(i32 55, float %1420, float %1421, float %1422, float %1420, float %1421, float %1422)  ; Dot3(ax,ay,az,bx,by,bz)
  %1424 = fsub fast float 1.000000e+00, %1423
  %1425 = call float @dx.op.unary.f32(i32 7, float %1424)  ; Saturate(value)
  %1426 = fmul fast float %1425, %1425
  %1427 = fadd fast float %1416, %1426
  %1428 = fmul fast float %1351, 0x3F25D867E0000000
  %1429 = fmul fast float %1428, %1427
  br label %1430

; <label>:1430                                    ; preds = %1384, %1377
  %1431 = phi float [ %1429, %1384 ], [ 0.000000e+00, %1377 ]
  %1432 = fadd fast float %1431, %1380
  %1433 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1432)  ; FMin(a,b)
  %1434 = fmul fast float %1433, 0xBFF7154760000000
  %1435 = call float @dx.op.unary.f32(i32 21, float %1434)  ; Exp(value)
  %1436 = fsub fast float 1.000000e+00, %1435
  %1437 = call float @dx.op.binary.f32(i32 36, float %13, float %1436)  ; FMin(a,b)
  %1438 = fsub fast float %14, %1264
  %1439 = fsub fast float %15, %1265
  %1440 = fsub fast float %16, %1266
  %1441 = fmul fast float %1437, %1438
  %1442 = fmul fast float %1437, %1439
  %1443 = fmul fast float %1437, %1440
  %1444 = fadd fast float %1441, %1264
  %1445 = fadd fast float %1442, %1265
  %1446 = fadd fast float %1443, %1266
  br label %1447

; <label>:1447                                    ; preds = %1430, %1309, %1303
  %1448 = phi float [ %1444, %1430 ], [ %1264, %1309 ], [ %1264, %1303 ]
  %1449 = phi float [ %1445, %1430 ], [ %1265, %1309 ], [ %1265, %1303 ]
  %1450 = phi float [ %1446, %1430 ], [ %1266, %1309 ], [ %1266, %1303 ]
  %1451 = fadd fast float %6, 1.000000e+00
  %1452 = fadd fast float %7, 1.000000e+00
  %1453 = fsub fast float 1.000000e+00, %6
  %1454 = fmul fast float %37, %1451
  %1455 = fmul fast float %37, %1452
  %1456 = fmul fast float %37, %1453
  %1457 = fmul fast float %1454, %1448
  %1458 = fmul fast float %1455, %1449
  %1459 = fmul fast float %1456, %1450
  %1460 = fcmp fast ult float %38, 5.000000e-01
  br i1 %1460, label %1486, label %1461

; <label>:1461                                    ; preds = %1447
  %1462 = fmul fast float %1457, 0x4004147AE0000000
  %1463 = fmul fast float %1458, 0x4004147AE0000000
  %1464 = fmul fast float %1459, 0x4004147AE0000000
  %1465 = fadd fast float %1462, 0x3F9EB851E0000000
  %1466 = fadd fast float %1463, 0x3F9EB851E0000000
  %1467 = fadd fast float %1464, 0x3F9EB851E0000000
  %1468 = fmul fast float %1465, %1457
  %1469 = fmul fast float %1466, %1458
  %1470 = fmul fast float %1467, %1459
  %1471 = fmul fast float %1457, 0x400370A3E0000000
  %1472 = fmul fast float %1458, 0x400370A3E0000000
  %1473 = fmul fast float %1459, 0x400370A3E0000000
  %1474 = fadd fast float %1471, 0x3FE2E147A0000000
  %1475 = fadd fast float %1472, 0x3FE2E147A0000000
  %1476 = fadd fast float %1473, 0x3FE2E147A0000000
  %1477 = fmul fast float %1474, %1457
  %1478 = fmul fast float %1475, %1458
  %1479 = fmul fast float %1476, %1459
  %1480 = fadd fast float %1477, 0x3FC1EB8520000000
  %1481 = fadd fast float %1478, 0x3FC1EB8520000000
  %1482 = fadd fast float %1479, 0x3FC1EB8520000000
  %1483 = fdiv fast float %1468, %1480
  %1484 = fdiv fast float %1469, %1481
  %1485 = fdiv fast float %1470, %1482
  br label %1486

; <label>:1486                                    ; preds = %1461, %1447
  %1487 = phi float [ %1483, %1461 ], [ %1457, %1447 ]
  %1488 = phi float [ %1484, %1461 ], [ %1458, %1447 ]
  %1489 = phi float [ %1485, %1461 ], [ %1459, %1447 ]
  %1490 = call float @dx.op.unary.f32(i32 7, float %1487)  ; Saturate(value)
  %1491 = call float @dx.op.unary.f32(i32 7, float %1488)  ; Saturate(value)
  %1492 = call float @dx.op.unary.f32(i32 7, float %1489)  ; Saturate(value)
  %1493 = call float @dx.op.dot3.f32(i32 55, float %1490, float %1491, float %1492, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1494 = fsub fast float %1490, %1493
  %1495 = fsub fast float %1491, %1493
  %1496 = fsub fast float %1492, %1493
  %1497 = fmul fast float %1494, %9
  %1498 = fmul fast float %1495, %9
  %1499 = fmul fast float %1496, %9
  %1500 = fadd fast float %1497, %1493
  %1501 = fadd fast float %1498, %1493
  %1502 = fadd fast float %1499, %1493
  %1503 = call float @dx.op.unary.f32(i32 7, float %1500)  ; Saturate(value)
  %1504 = call float @dx.op.unary.f32(i32 7, float %1501)  ; Saturate(value)
  %1505 = call float @dx.op.unary.f32(i32 7, float %1502)  ; Saturate(value)
  %1506 = fadd fast float %1503, 0xBFC70A3D80000000
  %1507 = fadd fast float %1504, 0xBFC70A3D80000000
  %1508 = fadd fast float %1505, 0xBFC70A3D80000000
  %1509 = fmul fast float %1506, %8
  %1510 = fmul fast float %1507, %8
  %1511 = fmul fast float %1508, %8
  %1512 = fadd fast float %1509, 0x3FC70A3D80000000
  %1513 = fadd fast float %1510, 0x3FC70A3D80000000
  %1514 = fadd fast float %1511, 0x3FC70A3D80000000
  %1515 = call float @dx.op.unary.f32(i32 7, float %1512)  ; Saturate(value)
  %1516 = call float @dx.op.unary.f32(i32 7, float %1513)  ; Saturate(value)
  %1517 = call float @dx.op.unary.f32(i32 7, float %1514)  ; Saturate(value)
  br label %1518

; <label>:1518                                    ; preds = %1486, %1269
  %1519 = phi float [ %1300, %1269 ], [ %1515, %1486 ]
  %1520 = phi float [ %1301, %1269 ], [ %1516, %1486 ]
  %1521 = phi float [ %1302, %1269 ], [ %1517, %1486 ]
  %1522 = fsub fast float %1519, %447
  %1523 = fsub fast float %1520, %448
  %1524 = fsub fast float %1521, %449
  %1525 = fmul fast float %1522, %1256
  %1526 = fmul fast float %1523, %1256
  %1527 = fmul fast float %1524, %1256
  %1528 = fadd fast float %1525, %447
  %1529 = fadd fast float %1526, %448
  %1530 = fadd fast float %1527, %449
  br label %1531

; <label>:1531                                    ; preds = %1518, %1243
  %1532 = phi float [ %1528, %1518 ], [ %447, %1243 ]
  %1533 = phi float [ %1529, %1518 ], [ %448, %1243 ]
  %1534 = phi float [ %1530, %1518 ], [ %449, %1243 ]
  %1535 = fsub fast float %87, %83
  %1536 = call float @dx.op.unary.f32(i32 6, float %1535)  ; FAbs(value)
  %1537 = fdiv fast float %1536, %1226
  %1538 = fsub fast float 1.000000e+00, %1537
  %1539 = call float @dx.op.unary.f32(i32 7, float %1538)  ; Saturate(value)
  %1540 = fcmp fast ugt float %1539, 0.000000e+00
  br i1 %1540, label %1541, label %1551

; <label>:1541                                    ; preds = %1531
  %1542 = fsub fast float %955, %447
  %1543 = fsub fast float %956, %448
  %1544 = fsub fast float %957, %449
  %1545 = fmul fast float %1539, %1542
  %1546 = fmul fast float %1539, %1543
  %1547 = fmul fast float %1539, %1544
  %1548 = fadd fast float %1545, %447
  %1549 = fadd fast float %1546, %448
  %1550 = fadd fast float %1547, %449
  br label %1551

; <label>:1551                                    ; preds = %1541, %1531
  %1552 = phi float [ %1548, %1541 ], [ %447, %1531 ]
  %1553 = phi float [ %1549, %1541 ], [ %448, %1531 ]
  %1554 = phi float [ %1550, %1541 ], [ %449, %1531 ]
  %1555 = add i32 %57, -1
  %1556 = call i32 @dx.op.binary.i32(i32 37, i32 %1555, i32 0)  ; IMax(a,b)
  %1557 = call i32 @dx.op.binary.i32(i32 38, i32 %1556, i32 %61)  ; IMin(a,b)
  %1558 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %64, i32 %1557, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1559 = extractvalue %dx.types.ResRet.f32 %1558, 0
  %1560 = fsub fast float %1559, %83
  %1561 = call float @dx.op.unary.f32(i32 6, float %1560)  ; FAbs(value)
  %1562 = fdiv fast float %1561, %1226
  %1563 = fsub fast float 1.000000e+00, %1562
  %1564 = call float @dx.op.unary.f32(i32 7, float %1563)  ; Saturate(value)
  %1565 = fcmp fast ugt float %1564, 0.000000e+00
  br i1 %1565, label %1566, label %1839

; <label>:1566                                    ; preds = %1551
  %1567 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %1568 = call i32 @dx.op.binary.i32(i32 37, i32 %1557, i32 0)  ; IMax(a,b)
  %1569 = call i32 @dx.op.binary.i32(i32 38, i32 %1567, i32 %60)  ; IMin(a,b)
  %1570 = call i32 @dx.op.binary.i32(i32 38, i32 %1568, i32 %61)  ; IMin(a,b)
  %1571 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1569, i32 %1570, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1572 = extractvalue %dx.types.ResRet.f32 %1571, 0
  %1573 = extractvalue %dx.types.ResRet.f32 %1571, 1
  %1574 = extractvalue %dx.types.ResRet.f32 %1571, 2
  %1575 = extractvalue %dx.types.ResRet.f32 %1571, 3
  %1576 = fcmp fast olt float %1575, 0.000000e+00
  br i1 %1576, label %1577, label %1611

; <label>:1577                                    ; preds = %1566
  %1578 = fcmp fast ogt float %1572, 0x3FA4B5DCC0000000
  %1579 = fcmp fast ogt float %1573, 0x3FA4B5DCC0000000
  %1580 = fcmp fast ogt float %1574, 0x3FA4B5DCC0000000
  %1581 = select i1 %1578, float 0.000000e+00, float 1.000000e+00
  %1582 = select i1 %1579, float 0.000000e+00, float 1.000000e+00
  %1583 = select i1 %1580, float 0.000000e+00, float 1.000000e+00
  %1584 = fmul fast float %1572, 0x3FB3D07220000000
  %1585 = fmul fast float %1573, 0x3FB3D07220000000
  %1586 = fmul fast float %1574, 0x3FB3D07220000000
  %1587 = fadd fast float %1572, 0x3FAC28F5C0000000
  %1588 = fadd fast float %1573, 0x3FAC28F5C0000000
  %1589 = fadd fast float %1574, 0x3FAC28F5C0000000
  %1590 = fmul fast float %1587, 0x3FEE54EDE0000000
  %1591 = fmul fast float %1588, 0x3FEE54EDE0000000
  %1592 = fmul fast float %1589, 0x3FEE54EDE0000000
  %1593 = call float @dx.op.unary.f32(i32 23, float %1590)  ; Log(value)
  %1594 = call float @dx.op.unary.f32(i32 23, float %1591)  ; Log(value)
  %1595 = call float @dx.op.unary.f32(i32 23, float %1592)  ; Log(value)
  %1596 = fmul fast float %1593, 0x4003333340000000
  %1597 = fmul fast float %1594, 0x4003333340000000
  %1598 = fmul fast float %1595, 0x4003333340000000
  %1599 = call float @dx.op.unary.f32(i32 21, float %1596)  ; Exp(value)
  %1600 = call float @dx.op.unary.f32(i32 21, float %1597)  ; Exp(value)
  %1601 = call float @dx.op.unary.f32(i32 21, float %1598)  ; Exp(value)
  %1602 = fsub fast float %1584, %1599
  %1603 = fsub fast float %1585, %1600
  %1604 = fsub fast float %1586, %1601
  %1605 = fmul fast float %1602, %1581
  %1606 = fmul fast float %1603, %1582
  %1607 = fmul fast float %1604, %1583
  %1608 = fadd fast float %1605, %1599
  %1609 = fadd fast float %1606, %1600
  %1610 = fadd fast float %1607, %1601
  br label %1826

; <label>:1611                                    ; preds = %1566
  %1612 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1569, i32 %1570, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1613 = extractvalue %dx.types.ResRet.f32 %1612, 0
  %1614 = fcmp fast ogt float %39, 5.000000e-01
  %1615 = fcmp fast olt float %1613, 1.000000e+00
  %1616 = and i1 %1614, %1615
  br i1 %1616, label %1617, label %1755

; <label>:1617                                    ; preds = %1611
  %1618 = sitofp i32 %1569 to float
  %1619 = sitofp i32 %1570 to float
  %1620 = fadd fast float %1618, 5.000000e-01
  %1621 = fadd fast float %1619, 5.000000e-01
  %1622 = fdiv fast float %1620, %46
  %1623 = fdiv fast float %1621, %47
  %1624 = fmul fast float %1622, 2.000000e+00
  %1625 = fmul fast float %1623, 2.000000e+00
  %1626 = fadd fast float %1624, -1.000000e+00
  %1627 = fsub fast float 1.000000e+00, %1625
  %1628 = fmul fast float %1626, %36
  %1629 = call float @dx.op.tertiary.f32(i32 46, float %1627, float %32, float %1628)  ; FMad(a,b,c)
  %1630 = call float @dx.op.tertiary.f32(i32 46, float %1613, float %28, float %1629)  ; FMad(a,b,c)
  %1631 = fadd fast float %1630, %24
  %1632 = call float @dx.op.unary.f32(i32 6, float %1631)  ; FAbs(value)
  %1633 = fcmp fast ogt float %1632, 0x3EB0C6F7A0000000
  br i1 %1633, label %1634, label %1755

; <label>:1634                                    ; preds = %1617
  %1635 = fmul fast float %1626, %35
  %1636 = call float @dx.op.tertiary.f32(i32 46, float %1627, float %31, float %1635)  ; FMad(a,b,c)
  %1637 = call float @dx.op.tertiary.f32(i32 46, float %1613, float %27, float %1636)  ; FMad(a,b,c)
  %1638 = fadd fast float %1637, %23
  %1639 = fmul fast float %1626, %34
  %1640 = call float @dx.op.tertiary.f32(i32 46, float %1627, float %30, float %1639)  ; FMad(a,b,c)
  %1641 = call float @dx.op.tertiary.f32(i32 46, float %1613, float %26, float %1640)  ; FMad(a,b,c)
  %1642 = fadd fast float %1641, %22
  %1643 = fmul fast float %1626, %33
  %1644 = call float @dx.op.tertiary.f32(i32 46, float %1627, float %29, float %1643)  ; FMad(a,b,c)
  %1645 = call float @dx.op.tertiary.f32(i32 46, float %1613, float %25, float %1644)  ; FMad(a,b,c)
  %1646 = fadd fast float %1645, %21
  %1647 = fdiv fast float %1646, %1631
  %1648 = fdiv fast float %1642, %1631
  %1649 = fdiv fast float %1638, %1631
  %1650 = fsub fast float %1647, %18
  %1651 = fsub fast float %1648, %19
  %1652 = fsub fast float %1649, %20
  %1653 = fmul fast float %1650, %1650
  %1654 = fmul fast float %1651, %1651
  %1655 = fadd fast float %1654, %1653
  %1656 = fmul fast float %1652, %1652
  %1657 = fadd fast float %1655, %1656
  %1658 = call float @dx.op.unary.f32(i32 24, float %1657)  ; Sqrt(value)
  %1659 = fsub fast float %1658, %10
  %1660 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1659)  ; FMax(a,b)
  %1661 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %1661, label %1662, label %1685

; <label>:1662                                    ; preds = %1634
  %1663 = call float @dx.op.unary.f32(i32 6, float %1651)  ; FAbs(value)
  %1664 = fmul fast float %1663, %12
  %1665 = fcmp fast olt float %1664, 0x3F50624DE0000000
  br i1 %1665, label %1666, label %1669

; <label>:1666                                    ; preds = %1662
  %1667 = fmul fast float %1664, 5.000000e-01
  %1668 = fsub fast float 1.000000e+00, %1667
  br label %1674

; <label>:1669                                    ; preds = %1662
  %1670 = fmul fast float %1664, 0xBFF7154760000000
  %1671 = call float @dx.op.unary.f32(i32 21, float %1670)  ; Exp(value)
  %1672 = fsub fast float 1.000000e+00, %1671
  %1673 = fdiv fast float %1672, %1664
  br label %1674

; <label>:1674                                    ; preds = %1669, %1666
  %1675 = phi float [ %1668, %1666 ], [ %1673, %1669 ]
  %1676 = call float @dx.op.binary.f32(i32 36, float %1648, float %19)  ; FMin(a,b)
  %1677 = fsub fast float %1676, %11
  %1678 = fmul fast float %12, %1677
  %1679 = fsub fast float -0.000000e+00, %1678
  %1680 = call float @dx.op.binary.f32(i32 35, float %1679, float -4.000000e+01)  ; FMax(a,b)
  %1681 = call float @dx.op.binary.f32(i32 36, float %1680, float 5.000000e+00)  ; FMin(a,b)
  %1682 = fmul fast float %1681, 0x3FF7154760000000
  %1683 = call float @dx.op.unary.f32(i32 21, float %1682)  ; Exp(value)
  %1684 = fmul fast float %1683, %1675
  br label %1685

; <label>:1685                                    ; preds = %1674, %1634
  %1686 = phi float [ %1684, %1674 ], [ 1.000000e+00, %1634 ]
  %1687 = fmul fast float %1660, %17
  %1688 = fmul fast float %1687, %1686
  %1689 = fcmp fast ole float %1658, %10
  %1690 = fcmp fast olt float %1658, 0x3F1A36E2E0000000
  %1691 = or i1 %1689, %1690
  br i1 %1691, label %1738, label %1692

; <label>:1692                                    ; preds = %1685
  %1693 = fdiv fast float %10, %1658
  %1694 = fmul fast float %1693, %1650
  %1695 = fmul fast float %1693, %1651
  %1696 = fmul fast float %1693, %1652
  %1697 = fadd fast float %1694, %18
  %1698 = fadd fast float %1695, %19
  %1699 = fadd fast float %1696, %20
  %1700 = fadd fast float %1697, -9.000000e+02
  %1701 = fadd fast float %1698, -1.500000e+01
  %1702 = fadd fast float %1699, -7.500000e+02
  %1703 = fmul fast float %1700, 0x3F62345680000000
  %1704 = fmul fast float %1701, 0x3F62345680000000
  %1705 = fmul fast float %1702, 0x3F62345680000000
  %1706 = call float @dx.op.dot3.f32(i32 55, float %1703, float %1704, float %1705, float %1703, float %1704, float %1705)  ; Dot3(ax,ay,az,bx,by,bz)
  %1707 = fsub fast float 1.000000e+00, %1706
  %1708 = call float @dx.op.unary.f32(i32 7, float %1707)  ; Saturate(value)
  %1709 = fmul fast float %1708, %1708
  %1710 = fadd fast float %1697, %1647
  %1711 = fadd fast float %1698, %1648
  %1712 = fadd fast float %1699, %1649
  %1713 = fmul fast float %1710, 0x3F52345680000000
  %1714 = fadd fast float %1713, -2.000000e+00
  %1715 = fmul fast float %1711, 0x3F52345680000000
  %1716 = fadd fast float %1715, 0xBFA1111120000000
  %1717 = fmul fast float %1712, 0x3F52345680000000
  %1718 = fadd fast float %1717, 0xBFFAAAAAC0000000
  %1719 = call float @dx.op.dot3.f32(i32 55, float %1714, float %1716, float %1718, float %1714, float %1716, float %1718)  ; Dot3(ax,ay,az,bx,by,bz)
  %1720 = fsub fast float 1.000000e+00, %1719
  %1721 = call float @dx.op.unary.f32(i32 7, float %1720)  ; Saturate(value)
  %1722 = fmul fast float %1721, %1721
  %1723 = fmul fast float %1722, 4.000000e+00
  %1724 = fadd fast float %1723, %1709
  %1725 = fadd fast float %1647, -9.000000e+02
  %1726 = fadd fast float %1648, -1.500000e+01
  %1727 = fadd fast float %1649, -7.500000e+02
  %1728 = fmul fast float %1725, 0x3F62345680000000
  %1729 = fmul fast float %1726, 0x3F62345680000000
  %1730 = fmul fast float %1727, 0x3F62345680000000
  %1731 = call float @dx.op.dot3.f32(i32 55, float %1728, float %1729, float %1730, float %1728, float %1729, float %1730)  ; Dot3(ax,ay,az,bx,by,bz)
  %1732 = fsub fast float 1.000000e+00, %1731
  %1733 = call float @dx.op.unary.f32(i32 7, float %1732)  ; Saturate(value)
  %1734 = fmul fast float %1733, %1733
  %1735 = fadd fast float %1724, %1734
  %1736 = fmul fast float %1659, 0x3F25D867E0000000
  %1737 = fmul fast float %1736, %1735
  br label %1738

; <label>:1738                                    ; preds = %1692, %1685
  %1739 = phi float [ %1737, %1692 ], [ 0.000000e+00, %1685 ]
  %1740 = fadd fast float %1739, %1688
  %1741 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1740)  ; FMin(a,b)
  %1742 = fmul fast float %1741, 0xBFF7154760000000
  %1743 = call float @dx.op.unary.f32(i32 21, float %1742)  ; Exp(value)
  %1744 = fsub fast float 1.000000e+00, %1743
  %1745 = call float @dx.op.binary.f32(i32 36, float %13, float %1744)  ; FMin(a,b)
  %1746 = fsub fast float %14, %1572
  %1747 = fsub fast float %15, %1573
  %1748 = fsub fast float %16, %1574
  %1749 = fmul fast float %1745, %1746
  %1750 = fmul fast float %1745, %1747
  %1751 = fmul fast float %1745, %1748
  %1752 = fadd fast float %1749, %1572
  %1753 = fadd fast float %1750, %1573
  %1754 = fadd fast float %1751, %1574
  br label %1755

; <label>:1755                                    ; preds = %1738, %1617, %1611
  %1756 = phi float [ %1752, %1738 ], [ %1572, %1617 ], [ %1572, %1611 ]
  %1757 = phi float [ %1753, %1738 ], [ %1573, %1617 ], [ %1573, %1611 ]
  %1758 = phi float [ %1754, %1738 ], [ %1574, %1617 ], [ %1574, %1611 ]
  %1759 = fadd fast float %6, 1.000000e+00
  %1760 = fadd fast float %7, 1.000000e+00
  %1761 = fsub fast float 1.000000e+00, %6
  %1762 = fmul fast float %37, %1759
  %1763 = fmul fast float %37, %1760
  %1764 = fmul fast float %37, %1761
  %1765 = fmul fast float %1762, %1756
  %1766 = fmul fast float %1763, %1757
  %1767 = fmul fast float %1764, %1758
  %1768 = fcmp fast ult float %38, 5.000000e-01
  br i1 %1768, label %1794, label %1769

; <label>:1769                                    ; preds = %1755
  %1770 = fmul fast float %1765, 0x4004147AE0000000
  %1771 = fmul fast float %1766, 0x4004147AE0000000
  %1772 = fmul fast float %1767, 0x4004147AE0000000
  %1773 = fadd fast float %1770, 0x3F9EB851E0000000
  %1774 = fadd fast float %1771, 0x3F9EB851E0000000
  %1775 = fadd fast float %1772, 0x3F9EB851E0000000
  %1776 = fmul fast float %1773, %1765
  %1777 = fmul fast float %1774, %1766
  %1778 = fmul fast float %1775, %1767
  %1779 = fmul fast float %1765, 0x400370A3E0000000
  %1780 = fmul fast float %1766, 0x400370A3E0000000
  %1781 = fmul fast float %1767, 0x400370A3E0000000
  %1782 = fadd fast float %1779, 0x3FE2E147A0000000
  %1783 = fadd fast float %1780, 0x3FE2E147A0000000
  %1784 = fadd fast float %1781, 0x3FE2E147A0000000
  %1785 = fmul fast float %1782, %1765
  %1786 = fmul fast float %1783, %1766
  %1787 = fmul fast float %1784, %1767
  %1788 = fadd fast float %1785, 0x3FC1EB8520000000
  %1789 = fadd fast float %1786, 0x3FC1EB8520000000
  %1790 = fadd fast float %1787, 0x3FC1EB8520000000
  %1791 = fdiv fast float %1776, %1788
  %1792 = fdiv fast float %1777, %1789
  %1793 = fdiv fast float %1778, %1790
  br label %1794

; <label>:1794                                    ; preds = %1769, %1755
  %1795 = phi float [ %1791, %1769 ], [ %1765, %1755 ]
  %1796 = phi float [ %1792, %1769 ], [ %1766, %1755 ]
  %1797 = phi float [ %1793, %1769 ], [ %1767, %1755 ]
  %1798 = call float @dx.op.unary.f32(i32 7, float %1795)  ; Saturate(value)
  %1799 = call float @dx.op.unary.f32(i32 7, float %1796)  ; Saturate(value)
  %1800 = call float @dx.op.unary.f32(i32 7, float %1797)  ; Saturate(value)
  %1801 = call float @dx.op.dot3.f32(i32 55, float %1798, float %1799, float %1800, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1802 = fsub fast float %1798, %1801
  %1803 = fsub fast float %1799, %1801
  %1804 = fsub fast float %1800, %1801
  %1805 = fmul fast float %1802, %9
  %1806 = fmul fast float %1803, %9
  %1807 = fmul fast float %1804, %9
  %1808 = fadd fast float %1805, %1801
  %1809 = fadd fast float %1806, %1801
  %1810 = fadd fast float %1807, %1801
  %1811 = call float @dx.op.unary.f32(i32 7, float %1808)  ; Saturate(value)
  %1812 = call float @dx.op.unary.f32(i32 7, float %1809)  ; Saturate(value)
  %1813 = call float @dx.op.unary.f32(i32 7, float %1810)  ; Saturate(value)
  %1814 = fadd fast float %1811, 0xBFC70A3D80000000
  %1815 = fadd fast float %1812, 0xBFC70A3D80000000
  %1816 = fadd fast float %1813, 0xBFC70A3D80000000
  %1817 = fmul fast float %1814, %8
  %1818 = fmul fast float %1815, %8
  %1819 = fmul fast float %1816, %8
  %1820 = fadd fast float %1817, 0x3FC70A3D80000000
  %1821 = fadd fast float %1818, 0x3FC70A3D80000000
  %1822 = fadd fast float %1819, 0x3FC70A3D80000000
  %1823 = call float @dx.op.unary.f32(i32 7, float %1820)  ; Saturate(value)
  %1824 = call float @dx.op.unary.f32(i32 7, float %1821)  ; Saturate(value)
  %1825 = call float @dx.op.unary.f32(i32 7, float %1822)  ; Saturate(value)
  br label %1826

; <label>:1826                                    ; preds = %1794, %1577
  %1827 = phi float [ %1608, %1577 ], [ %1823, %1794 ]
  %1828 = phi float [ %1609, %1577 ], [ %1824, %1794 ]
  %1829 = phi float [ %1610, %1577 ], [ %1825, %1794 ]
  %1830 = fsub fast float %1827, %447
  %1831 = fsub fast float %1828, %448
  %1832 = fsub fast float %1829, %449
  %1833 = fmul fast float %1830, %1564
  %1834 = fmul fast float %1831, %1564
  %1835 = fmul fast float %1832, %1564
  %1836 = fadd fast float %1833, %447
  %1837 = fadd fast float %1834, %448
  %1838 = fadd fast float %1835, %449
  br label %1839

; <label>:1839                                    ; preds = %1826, %1551
  %1840 = phi float [ %1836, %1826 ], [ %447, %1551 ]
  %1841 = phi float [ %1837, %1826 ], [ %448, %1551 ]
  %1842 = phi float [ %1838, %1826 ], [ %449, %1551 ]
  %1843 = call float @dx.op.binary.f32(i32 36, float %1532, float %1244)  ; FMin(a,b)
  %1844 = call float @dx.op.binary.f32(i32 36, float %1533, float %1245)  ; FMin(a,b)
  %1845 = call float @dx.op.binary.f32(i32 36, float %1534, float %1246)  ; FMin(a,b)
  %1846 = call float @dx.op.binary.f32(i32 36, float %1840, float %1552)  ; FMin(a,b)
  %1847 = call float @dx.op.binary.f32(i32 36, float %1841, float %1553)  ; FMin(a,b)
  %1848 = call float @dx.op.binary.f32(i32 36, float %1842, float %1554)  ; FMin(a,b)
  %1849 = call float @dx.op.binary.f32(i32 36, float %1846, float %1843)  ; FMin(a,b)
  %1850 = call float @dx.op.binary.f32(i32 36, float %1847, float %1844)  ; FMin(a,b)
  %1851 = call float @dx.op.binary.f32(i32 36, float %1848, float %1845)  ; FMin(a,b)
  %1852 = call float @dx.op.binary.f32(i32 36, float %447, float %1849)  ; FMin(a,b)
  %1853 = call float @dx.op.binary.f32(i32 36, float %448, float %1850)  ; FMin(a,b)
  %1854 = call float @dx.op.binary.f32(i32 36, float %449, float %1851)  ; FMin(a,b)
  %1855 = call float @dx.op.binary.f32(i32 35, float %1532, float %1244)  ; FMax(a,b)
  %1856 = call float @dx.op.binary.f32(i32 35, float %1533, float %1245)  ; FMax(a,b)
  %1857 = call float @dx.op.binary.f32(i32 35, float %1534, float %1246)  ; FMax(a,b)
  %1858 = call float @dx.op.binary.f32(i32 35, float %1840, float %1552)  ; FMax(a,b)
  %1859 = call float @dx.op.binary.f32(i32 35, float %1841, float %1553)  ; FMax(a,b)
  %1860 = call float @dx.op.binary.f32(i32 35, float %1842, float %1554)  ; FMax(a,b)
  %1861 = call float @dx.op.binary.f32(i32 35, float %1858, float %1855)  ; FMax(a,b)
  %1862 = call float @dx.op.binary.f32(i32 35, float %1859, float %1856)  ; FMax(a,b)
  %1863 = call float @dx.op.binary.f32(i32 35, float %1860, float %1857)  ; FMax(a,b)
  %1864 = call float @dx.op.binary.f32(i32 35, float %447, float %1861)  ; FMax(a,b)
  %1865 = call float @dx.op.binary.f32(i32 35, float %448, float %1862)  ; FMax(a,b)
  %1866 = call float @dx.op.binary.f32(i32 35, float %449, float %1863)  ; FMax(a,b)
  %1867 = fsub fast float %1864, %1852
  %1868 = fsub fast float %1865, %1853
  %1869 = fsub fast float %1866, %1854
  %1870 = call float @dx.op.unary.f32(i32 6, float %1867)  ; FAbs(value)
  %1871 = call float @dx.op.unary.f32(i32 6, float %1868)  ; FAbs(value)
  %1872 = call float @dx.op.unary.f32(i32 6, float %1869)  ; FAbs(value)
  %1873 = call float @dx.op.binary.f32(i32 35, float %1871, float %1872)  ; FMax(a,b)
  %1874 = call float @dx.op.binary.f32(i32 35, float %1870, float %1873)  ; FMax(a,b)
  %1875 = call float @dx.op.binary.f32(i32 35, float %1865, float %1866)  ; FMax(a,b)
  %1876 = call float @dx.op.binary.f32(i32 35, float %1864, float %1875)  ; FMax(a,b)
  %1877 = fmul fast float %1876, 1.250000e-01
  %1878 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1877)  ; FMax(a,b)
  %1879 = fcmp fast ogt float %1874, %1878
  br i1 %1879, label %1880, label %1942

; <label>:1880                                    ; preds = %1839
  %1881 = fsub fast float %1840, %1552
  %1882 = fsub fast float %1841, %1553
  %1883 = fsub fast float %1842, %1554
  %1884 = call float @dx.op.unary.f32(i32 6, float %1881)  ; FAbs(value)
  %1885 = call float @dx.op.unary.f32(i32 6, float %1882)  ; FAbs(value)
  %1886 = call float @dx.op.unary.f32(i32 6, float %1883)  ; FAbs(value)
  %1887 = call float @dx.op.binary.f32(i32 35, float %1885, float %1886)  ; FMax(a,b)
  %1888 = call float @dx.op.binary.f32(i32 35, float %1884, float %1887)  ; FMax(a,b)
  %1889 = fsub fast float %1532, %1244
  %1890 = fsub fast float %1533, %1245
  %1891 = fsub fast float %1534, %1246
  %1892 = call float @dx.op.unary.f32(i32 6, float %1889)  ; FAbs(value)
  %1893 = call float @dx.op.unary.f32(i32 6, float %1890)  ; FAbs(value)
  %1894 = call float @dx.op.unary.f32(i32 6, float %1891)  ; FAbs(value)
  %1895 = call float @dx.op.binary.f32(i32 35, float %1893, float %1894)  ; FMax(a,b)
  %1896 = call float @dx.op.binary.f32(i32 35, float %1892, float %1895)  ; FMax(a,b)
  %1897 = fcmp fast olt float %1888, %1896
  %1898 = select i1 %1897, float %1840, float %1532
  %1899 = select i1 %1897, float %1841, float %1533
  %1900 = select i1 %1897, float %1842, float %1534
  %1901 = select i1 %1897, float %1552, float %1244
  %1902 = select i1 %1897, float %1553, float %1245
  %1903 = select i1 %1897, float %1554, float %1246
  %1904 = fsub fast float %447, %1901
  %1905 = fsub fast float %448, %1902
  %1906 = fsub fast float %449, %1903
  %1907 = fsub fast float %447, %1898
  %1908 = fsub fast float %448, %1899
  %1909 = fsub fast float %449, %1900
  %1910 = call float @dx.op.dot3.f32(i32 55, float %1907, float %1908, float %1909, float %1904, float %1905, float %1906)  ; Dot3(ax,ay,az,bx,by,bz)
  %1911 = fcmp fast ogt float %1910, 0.000000e+00
  br i1 %1911, label %1912, label %1923

; <label>:1912                                    ; preds = %1880
  %1913 = fsub fast float %1898, %1901
  %1914 = fsub fast float %1899, %1902
  %1915 = fsub fast float %1900, %1903
  %1916 = call float @dx.op.unary.f32(i32 6, float %1913)  ; FAbs(value)
  %1917 = call float @dx.op.unary.f32(i32 6, float %1914)  ; FAbs(value)
  %1918 = call float @dx.op.unary.f32(i32 6, float %1915)  ; FAbs(value)
  %1919 = call float @dx.op.binary.f32(i32 35, float %1917, float %1918)  ; FMax(a,b)
  %1920 = call float @dx.op.binary.f32(i32 35, float %1916, float %1919)  ; FMax(a,b)
  %1921 = fmul fast float %1874, 2.500000e-01
  %1922 = fcmp fast olt float %1920, %1921
  br label %1923

; <label>:1923                                    ; preds = %1912, %1880
  %1924 = phi i1 [ false, %1880 ], [ %1922, %1912 ]
  %1925 = select i1 %1924, float 5.000000e-01, float 1.000000e+00
  %1926 = fmul fast float %1925, %3
  %1927 = fadd fast float %1898, %1901
  %1928 = fadd fast float %1899, %1902
  %1929 = fadd fast float %1900, %1903
  %1930 = fmul fast float %1927, 5.000000e-01
  %1931 = fmul fast float %1928, 5.000000e-01
  %1932 = fmul fast float %1929, 5.000000e-01
  %1933 = fsub fast float %1930, %447
  %1934 = fsub fast float %1931, %448
  %1935 = fsub fast float %1932, %449
  %1936 = fmul fast float %1926, %1933
  %1937 = fmul fast float %1926, %1934
  %1938 = fmul fast float %1926, %1935
  %1939 = fadd fast float %1936, %447
  %1940 = fadd fast float %1937, %448
  %1941 = fadd fast float %1938, %449
  br label %1942

; <label>:1942                                    ; preds = %1923, %1839, %1221
  %1943 = phi float [ %447, %1221 ], [ %1939, %1923 ], [ %447, %1839 ]
  %1944 = phi float [ %448, %1221 ], [ %1940, %1923 ], [ %448, %1839 ]
  %1945 = phi float [ %449, %1221 ], [ %1941, %1923 ], [ %449, %1839 ]
  %1946 = fcmp fast ult float %185, 0.000000e+00
  br i1 %1946, label %2666, label %1947

; <label>:1947                                    ; preds = %1942
  %1948 = add i32 %56, 2
  %1949 = call i32 @dx.op.binary.i32(i32 37, i32 %1948, i32 0)  ; IMax(a,b)
  %1950 = call i32 @dx.op.binary.i32(i32 38, i32 %1949, i32 %60)  ; IMin(a,b)
  %1951 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1950, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1952 = extractvalue %dx.types.ResRet.f32 %1951, 0
  %1953 = fsub fast float 1.000000e+00, %85
  %1954 = fmul fast float %1953, 0x3FA99999A0000000
  %1955 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %1954)  ; FMax(a,b)
  %1956 = fsub fast float %1952, %85
  %1957 = call float @dx.op.unary.f32(i32 6, float %1956)  ; FAbs(value)
  %1958 = fdiv fast float %1957, %1955
  %1959 = fsub fast float 1.000000e+00, %1958
  %1960 = call float @dx.op.unary.f32(i32 7, float %1959)  ; Saturate(value)
  %1961 = fcmp fast ugt float %1960, 0.000000e+00
  br i1 %1961, label %1962, label %2235

; <label>:1962                                    ; preds = %1947
  %1963 = call i32 @dx.op.binary.i32(i32 37, i32 %1950, i32 0)  ; IMax(a,b)
  %1964 = call i32 @dx.op.binary.i32(i32 37, i32 %65, i32 0)  ; IMax(a,b)
  %1965 = call i32 @dx.op.binary.i32(i32 38, i32 %1963, i32 %60)  ; IMin(a,b)
  %1966 = call i32 @dx.op.binary.i32(i32 38, i32 %1964, i32 %61)  ; IMin(a,b)
  %1967 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1965, i32 %1966, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1968 = extractvalue %dx.types.ResRet.f32 %1967, 0
  %1969 = extractvalue %dx.types.ResRet.f32 %1967, 1
  %1970 = extractvalue %dx.types.ResRet.f32 %1967, 2
  %1971 = extractvalue %dx.types.ResRet.f32 %1967, 3
  %1972 = fcmp fast olt float %1971, 0.000000e+00
  br i1 %1972, label %1973, label %2007

; <label>:1973                                    ; preds = %1962
  %1974 = fcmp fast ogt float %1968, 0x3FA4B5DCC0000000
  %1975 = fcmp fast ogt float %1969, 0x3FA4B5DCC0000000
  %1976 = fcmp fast ogt float %1970, 0x3FA4B5DCC0000000
  %1977 = select i1 %1974, float 0.000000e+00, float 1.000000e+00
  %1978 = select i1 %1975, float 0.000000e+00, float 1.000000e+00
  %1979 = select i1 %1976, float 0.000000e+00, float 1.000000e+00
  %1980 = fmul fast float %1968, 0x3FB3D07220000000
  %1981 = fmul fast float %1969, 0x3FB3D07220000000
  %1982 = fmul fast float %1970, 0x3FB3D07220000000
  %1983 = fadd fast float %1968, 0x3FAC28F5C0000000
  %1984 = fadd fast float %1969, 0x3FAC28F5C0000000
  %1985 = fadd fast float %1970, 0x3FAC28F5C0000000
  %1986 = fmul fast float %1983, 0x3FEE54EDE0000000
  %1987 = fmul fast float %1984, 0x3FEE54EDE0000000
  %1988 = fmul fast float %1985, 0x3FEE54EDE0000000
  %1989 = call float @dx.op.unary.f32(i32 23, float %1986)  ; Log(value)
  %1990 = call float @dx.op.unary.f32(i32 23, float %1987)  ; Log(value)
  %1991 = call float @dx.op.unary.f32(i32 23, float %1988)  ; Log(value)
  %1992 = fmul fast float %1989, 0x4003333340000000
  %1993 = fmul fast float %1990, 0x4003333340000000
  %1994 = fmul fast float %1991, 0x4003333340000000
  %1995 = call float @dx.op.unary.f32(i32 21, float %1992)  ; Exp(value)
  %1996 = call float @dx.op.unary.f32(i32 21, float %1993)  ; Exp(value)
  %1997 = call float @dx.op.unary.f32(i32 21, float %1994)  ; Exp(value)
  %1998 = fsub fast float %1980, %1995
  %1999 = fsub fast float %1981, %1996
  %2000 = fsub fast float %1982, %1997
  %2001 = fmul fast float %1998, %1977
  %2002 = fmul fast float %1999, %1978
  %2003 = fmul fast float %2000, %1979
  %2004 = fadd fast float %2001, %1995
  %2005 = fadd fast float %2002, %1996
  %2006 = fadd fast float %2003, %1997
  br label %2222

; <label>:2007                                    ; preds = %1962
  %2008 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1965, i32 %1966, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2009 = extractvalue %dx.types.ResRet.f32 %2008, 0
  %2010 = fcmp fast ogt float %39, 5.000000e-01
  %2011 = fcmp fast olt float %2009, 1.000000e+00
  %2012 = and i1 %2010, %2011
  br i1 %2012, label %2013, label %2151

; <label>:2013                                    ; preds = %2007
  %2014 = sitofp i32 %1965 to float
  %2015 = sitofp i32 %1966 to float
  %2016 = fadd fast float %2014, 5.000000e-01
  %2017 = fadd fast float %2015, 5.000000e-01
  %2018 = fdiv fast float %2016, %46
  %2019 = fdiv fast float %2017, %47
  %2020 = fmul fast float %2018, 2.000000e+00
  %2021 = fmul fast float %2019, 2.000000e+00
  %2022 = fadd fast float %2020, -1.000000e+00
  %2023 = fsub fast float 1.000000e+00, %2021
  %2024 = fmul fast float %2022, %36
  %2025 = call float @dx.op.tertiary.f32(i32 46, float %2023, float %32, float %2024)  ; FMad(a,b,c)
  %2026 = call float @dx.op.tertiary.f32(i32 46, float %2009, float %28, float %2025)  ; FMad(a,b,c)
  %2027 = fadd fast float %2026, %24
  %2028 = call float @dx.op.unary.f32(i32 6, float %2027)  ; FAbs(value)
  %2029 = fcmp fast ogt float %2028, 0x3EB0C6F7A0000000
  br i1 %2029, label %2030, label %2151

; <label>:2030                                    ; preds = %2013
  %2031 = fmul fast float %2022, %35
  %2032 = call float @dx.op.tertiary.f32(i32 46, float %2023, float %31, float %2031)  ; FMad(a,b,c)
  %2033 = call float @dx.op.tertiary.f32(i32 46, float %2009, float %27, float %2032)  ; FMad(a,b,c)
  %2034 = fadd fast float %2033, %23
  %2035 = fmul fast float %2022, %34
  %2036 = call float @dx.op.tertiary.f32(i32 46, float %2023, float %30, float %2035)  ; FMad(a,b,c)
  %2037 = call float @dx.op.tertiary.f32(i32 46, float %2009, float %26, float %2036)  ; FMad(a,b,c)
  %2038 = fadd fast float %2037, %22
  %2039 = fmul fast float %2022, %33
  %2040 = call float @dx.op.tertiary.f32(i32 46, float %2023, float %29, float %2039)  ; FMad(a,b,c)
  %2041 = call float @dx.op.tertiary.f32(i32 46, float %2009, float %25, float %2040)  ; FMad(a,b,c)
  %2042 = fadd fast float %2041, %21
  %2043 = fdiv fast float %2042, %2027
  %2044 = fdiv fast float %2038, %2027
  %2045 = fdiv fast float %2034, %2027
  %2046 = fsub fast float %2043, %18
  %2047 = fsub fast float %2044, %19
  %2048 = fsub fast float %2045, %20
  %2049 = fmul fast float %2046, %2046
  %2050 = fmul fast float %2047, %2047
  %2051 = fadd fast float %2050, %2049
  %2052 = fmul fast float %2048, %2048
  %2053 = fadd fast float %2051, %2052
  %2054 = call float @dx.op.unary.f32(i32 24, float %2053)  ; Sqrt(value)
  %2055 = fsub fast float %2054, %10
  %2056 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2055)  ; FMax(a,b)
  %2057 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %2057, label %2058, label %2081

; <label>:2058                                    ; preds = %2030
  %2059 = call float @dx.op.unary.f32(i32 6, float %2047)  ; FAbs(value)
  %2060 = fmul fast float %2059, %12
  %2061 = fcmp fast olt float %2060, 0x3F50624DE0000000
  br i1 %2061, label %2062, label %2065

; <label>:2062                                    ; preds = %2058
  %2063 = fmul fast float %2060, 5.000000e-01
  %2064 = fsub fast float 1.000000e+00, %2063
  br label %2070

; <label>:2065                                    ; preds = %2058
  %2066 = fmul fast float %2060, 0xBFF7154760000000
  %2067 = call float @dx.op.unary.f32(i32 21, float %2066)  ; Exp(value)
  %2068 = fsub fast float 1.000000e+00, %2067
  %2069 = fdiv fast float %2068, %2060
  br label %2070

; <label>:2070                                    ; preds = %2065, %2062
  %2071 = phi float [ %2064, %2062 ], [ %2069, %2065 ]
  %2072 = call float @dx.op.binary.f32(i32 36, float %2044, float %19)  ; FMin(a,b)
  %2073 = fsub fast float %2072, %11
  %2074 = fmul fast float %12, %2073
  %2075 = fsub fast float -0.000000e+00, %2074
  %2076 = call float @dx.op.binary.f32(i32 35, float %2075, float -4.000000e+01)  ; FMax(a,b)
  %2077 = call float @dx.op.binary.f32(i32 36, float %2076, float 5.000000e+00)  ; FMin(a,b)
  %2078 = fmul fast float %2077, 0x3FF7154760000000
  %2079 = call float @dx.op.unary.f32(i32 21, float %2078)  ; Exp(value)
  %2080 = fmul fast float %2079, %2071
  br label %2081

; <label>:2081                                    ; preds = %2070, %2030
  %2082 = phi float [ %2080, %2070 ], [ 1.000000e+00, %2030 ]
  %2083 = fmul fast float %2056, %17
  %2084 = fmul fast float %2083, %2082
  %2085 = fcmp fast ole float %2054, %10
  %2086 = fcmp fast olt float %2054, 0x3F1A36E2E0000000
  %2087 = or i1 %2085, %2086
  br i1 %2087, label %2134, label %2088

; <label>:2088                                    ; preds = %2081
  %2089 = fdiv fast float %10, %2054
  %2090 = fmul fast float %2089, %2046
  %2091 = fmul fast float %2089, %2047
  %2092 = fmul fast float %2089, %2048
  %2093 = fadd fast float %2090, %18
  %2094 = fadd fast float %2091, %19
  %2095 = fadd fast float %2092, %20
  %2096 = fadd fast float %2093, -9.000000e+02
  %2097 = fadd fast float %2094, -1.500000e+01
  %2098 = fadd fast float %2095, -7.500000e+02
  %2099 = fmul fast float %2096, 0x3F62345680000000
  %2100 = fmul fast float %2097, 0x3F62345680000000
  %2101 = fmul fast float %2098, 0x3F62345680000000
  %2102 = call float @dx.op.dot3.f32(i32 55, float %2099, float %2100, float %2101, float %2099, float %2100, float %2101)  ; Dot3(ax,ay,az,bx,by,bz)
  %2103 = fsub fast float 1.000000e+00, %2102
  %2104 = call float @dx.op.unary.f32(i32 7, float %2103)  ; Saturate(value)
  %2105 = fmul fast float %2104, %2104
  %2106 = fadd fast float %2093, %2043
  %2107 = fadd fast float %2094, %2044
  %2108 = fadd fast float %2095, %2045
  %2109 = fmul fast float %2106, 0x3F52345680000000
  %2110 = fadd fast float %2109, -2.000000e+00
  %2111 = fmul fast float %2107, 0x3F52345680000000
  %2112 = fadd fast float %2111, 0xBFA1111120000000
  %2113 = fmul fast float %2108, 0x3F52345680000000
  %2114 = fadd fast float %2113, 0xBFFAAAAAC0000000
  %2115 = call float @dx.op.dot3.f32(i32 55, float %2110, float %2112, float %2114, float %2110, float %2112, float %2114)  ; Dot3(ax,ay,az,bx,by,bz)
  %2116 = fsub fast float 1.000000e+00, %2115
  %2117 = call float @dx.op.unary.f32(i32 7, float %2116)  ; Saturate(value)
  %2118 = fmul fast float %2117, %2117
  %2119 = fmul fast float %2118, 4.000000e+00
  %2120 = fadd fast float %2119, %2105
  %2121 = fadd fast float %2043, -9.000000e+02
  %2122 = fadd fast float %2044, -1.500000e+01
  %2123 = fadd fast float %2045, -7.500000e+02
  %2124 = fmul fast float %2121, 0x3F62345680000000
  %2125 = fmul fast float %2122, 0x3F62345680000000
  %2126 = fmul fast float %2123, 0x3F62345680000000
  %2127 = call float @dx.op.dot3.f32(i32 55, float %2124, float %2125, float %2126, float %2124, float %2125, float %2126)  ; Dot3(ax,ay,az,bx,by,bz)
  %2128 = fsub fast float 1.000000e+00, %2127
  %2129 = call float @dx.op.unary.f32(i32 7, float %2128)  ; Saturate(value)
  %2130 = fmul fast float %2129, %2129
  %2131 = fadd fast float %2120, %2130
  %2132 = fmul fast float %2055, 0x3F25D867E0000000
  %2133 = fmul fast float %2132, %2131
  br label %2134

; <label>:2134                                    ; preds = %2088, %2081
  %2135 = phi float [ %2133, %2088 ], [ 0.000000e+00, %2081 ]
  %2136 = fadd fast float %2135, %2084
  %2137 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2136)  ; FMin(a,b)
  %2138 = fmul fast float %2137, 0xBFF7154760000000
  %2139 = call float @dx.op.unary.f32(i32 21, float %2138)  ; Exp(value)
  %2140 = fsub fast float 1.000000e+00, %2139
  %2141 = call float @dx.op.binary.f32(i32 36, float %13, float %2140)  ; FMin(a,b)
  %2142 = fsub fast float %14, %1968
  %2143 = fsub fast float %15, %1969
  %2144 = fsub fast float %16, %1970
  %2145 = fmul fast float %2141, %2142
  %2146 = fmul fast float %2141, %2143
  %2147 = fmul fast float %2141, %2144
  %2148 = fadd fast float %2145, %1968
  %2149 = fadd fast float %2146, %1969
  %2150 = fadd fast float %2147, %1970
  br label %2151

; <label>:2151                                    ; preds = %2134, %2013, %2007
  %2152 = phi float [ %2148, %2134 ], [ %1968, %2013 ], [ %1968, %2007 ]
  %2153 = phi float [ %2149, %2134 ], [ %1969, %2013 ], [ %1969, %2007 ]
  %2154 = phi float [ %2150, %2134 ], [ %1970, %2013 ], [ %1970, %2007 ]
  %2155 = fadd fast float %6, 1.000000e+00
  %2156 = fadd fast float %7, 1.000000e+00
  %2157 = fsub fast float 1.000000e+00, %6
  %2158 = fmul fast float %37, %2155
  %2159 = fmul fast float %37, %2156
  %2160 = fmul fast float %37, %2157
  %2161 = fmul fast float %2158, %2152
  %2162 = fmul fast float %2159, %2153
  %2163 = fmul fast float %2160, %2154
  %2164 = fcmp fast ult float %38, 5.000000e-01
  br i1 %2164, label %2190, label %2165

; <label>:2165                                    ; preds = %2151
  %2166 = fmul fast float %2161, 0x4004147AE0000000
  %2167 = fmul fast float %2162, 0x4004147AE0000000
  %2168 = fmul fast float %2163, 0x4004147AE0000000
  %2169 = fadd fast float %2166, 0x3F9EB851E0000000
  %2170 = fadd fast float %2167, 0x3F9EB851E0000000
  %2171 = fadd fast float %2168, 0x3F9EB851E0000000
  %2172 = fmul fast float %2169, %2161
  %2173 = fmul fast float %2170, %2162
  %2174 = fmul fast float %2171, %2163
  %2175 = fmul fast float %2161, 0x400370A3E0000000
  %2176 = fmul fast float %2162, 0x400370A3E0000000
  %2177 = fmul fast float %2163, 0x400370A3E0000000
  %2178 = fadd fast float %2175, 0x3FE2E147A0000000
  %2179 = fadd fast float %2176, 0x3FE2E147A0000000
  %2180 = fadd fast float %2177, 0x3FE2E147A0000000
  %2181 = fmul fast float %2178, %2161
  %2182 = fmul fast float %2179, %2162
  %2183 = fmul fast float %2180, %2163
  %2184 = fadd fast float %2181, 0x3FC1EB8520000000
  %2185 = fadd fast float %2182, 0x3FC1EB8520000000
  %2186 = fadd fast float %2183, 0x3FC1EB8520000000
  %2187 = fdiv fast float %2172, %2184
  %2188 = fdiv fast float %2173, %2185
  %2189 = fdiv fast float %2174, %2186
  br label %2190

; <label>:2190                                    ; preds = %2165, %2151
  %2191 = phi float [ %2187, %2165 ], [ %2161, %2151 ]
  %2192 = phi float [ %2188, %2165 ], [ %2162, %2151 ]
  %2193 = phi float [ %2189, %2165 ], [ %2163, %2151 ]
  %2194 = call float @dx.op.unary.f32(i32 7, float %2191)  ; Saturate(value)
  %2195 = call float @dx.op.unary.f32(i32 7, float %2192)  ; Saturate(value)
  %2196 = call float @dx.op.unary.f32(i32 7, float %2193)  ; Saturate(value)
  %2197 = call float @dx.op.dot3.f32(i32 55, float %2194, float %2195, float %2196, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2198 = fsub fast float %2194, %2197
  %2199 = fsub fast float %2195, %2197
  %2200 = fsub fast float %2196, %2197
  %2201 = fmul fast float %2198, %9
  %2202 = fmul fast float %2199, %9
  %2203 = fmul fast float %2200, %9
  %2204 = fadd fast float %2201, %2197
  %2205 = fadd fast float %2202, %2197
  %2206 = fadd fast float %2203, %2197
  %2207 = call float @dx.op.unary.f32(i32 7, float %2204)  ; Saturate(value)
  %2208 = call float @dx.op.unary.f32(i32 7, float %2205)  ; Saturate(value)
  %2209 = call float @dx.op.unary.f32(i32 7, float %2206)  ; Saturate(value)
  %2210 = fadd fast float %2207, 0xBFC70A3D80000000
  %2211 = fadd fast float %2208, 0xBFC70A3D80000000
  %2212 = fadd fast float %2209, 0xBFC70A3D80000000
  %2213 = fmul fast float %2210, %8
  %2214 = fmul fast float %2211, %8
  %2215 = fmul fast float %2212, %8
  %2216 = fadd fast float %2213, 0x3FC70A3D80000000
  %2217 = fadd fast float %2214, 0x3FC70A3D80000000
  %2218 = fadd fast float %2215, 0x3FC70A3D80000000
  %2219 = call float @dx.op.unary.f32(i32 7, float %2216)  ; Saturate(value)
  %2220 = call float @dx.op.unary.f32(i32 7, float %2217)  ; Saturate(value)
  %2221 = call float @dx.op.unary.f32(i32 7, float %2218)  ; Saturate(value)
  br label %2222

; <label>:2222                                    ; preds = %2190, %1973
  %2223 = phi float [ %2004, %1973 ], [ %2219, %2190 ]
  %2224 = phi float [ %2005, %1973 ], [ %2220, %2190 ]
  %2225 = phi float [ %2006, %1973 ], [ %2221, %2190 ]
  %2226 = fsub fast float %2223, %701
  %2227 = fsub fast float %2224, %702
  %2228 = fsub fast float %2225, %703
  %2229 = fmul fast float %2226, %1960
  %2230 = fmul fast float %2227, %1960
  %2231 = fmul fast float %2228, %1960
  %2232 = fadd fast float %2229, %701
  %2233 = fadd fast float %2230, %702
  %2234 = fadd fast float %2231, %703
  br label %2235

; <label>:2235                                    ; preds = %2222, %1947
  %2236 = phi float [ %2232, %2222 ], [ %701, %1947 ]
  %2237 = phi float [ %2233, %2222 ], [ %702, %1947 ]
  %2238 = phi float [ %2234, %2222 ], [ %703, %1947 ]
  %2239 = fsub fast float %83, %85
  %2240 = call float @dx.op.unary.f32(i32 6, float %2239)  ; FAbs(value)
  %2241 = fdiv fast float %2240, %1955
  %2242 = fsub fast float 1.000000e+00, %2241
  %2243 = call float @dx.op.unary.f32(i32 7, float %2242)  ; Saturate(value)
  %2244 = fcmp fast ugt float %2243, 0.000000e+00
  br i1 %2244, label %2245, label %2255

; <label>:2245                                    ; preds = %2235
  %2246 = fsub fast float %447, %701
  %2247 = fsub fast float %448, %702
  %2248 = fsub fast float %449, %703
  %2249 = fmul fast float %2243, %2246
  %2250 = fmul fast float %2243, %2247
  %2251 = fmul fast float %2243, %2248
  %2252 = fadd fast float %2249, %701
  %2253 = fadd fast float %2250, %702
  %2254 = fadd fast float %2251, %703
  br label %2255

; <label>:2255                                    ; preds = %2245, %2235
  %2256 = phi float [ %2252, %2245 ], [ %701, %2235 ]
  %2257 = phi float [ %2253, %2245 ], [ %702, %2235 ]
  %2258 = phi float [ %2254, %2245 ], [ %703, %2235 ]
  %2259 = fsub fast float %89, %85
  %2260 = call float @dx.op.unary.f32(i32 6, float %2259)  ; FAbs(value)
  %2261 = fdiv fast float %2260, %1955
  %2262 = fsub fast float 1.000000e+00, %2261
  %2263 = call float @dx.op.unary.f32(i32 7, float %2262)  ; Saturate(value)
  %2264 = fcmp fast ugt float %2263, 0.000000e+00
  br i1 %2264, label %2265, label %2275

; <label>:2265                                    ; preds = %2255
  %2266 = fsub fast float %1209, %701
  %2267 = fsub fast float %1210, %702
  %2268 = fsub fast float %1211, %703
  %2269 = fmul fast float %2263, %2266
  %2270 = fmul fast float %2263, %2267
  %2271 = fmul fast float %2263, %2268
  %2272 = fadd fast float %2269, %701
  %2273 = fadd fast float %2270, %702
  %2274 = fadd fast float %2271, %703
  br label %2275

; <label>:2275                                    ; preds = %2265, %2255
  %2276 = phi float [ %2272, %2265 ], [ %701, %2255 ]
  %2277 = phi float [ %2273, %2265 ], [ %702, %2255 ]
  %2278 = phi float [ %2274, %2265 ], [ %703, %2255 ]
  %2279 = add i32 %57, -1
  %2280 = call i32 @dx.op.binary.i32(i32 37, i32 %2279, i32 0)  ; IMax(a,b)
  %2281 = call i32 @dx.op.binary.i32(i32 38, i32 %2280, i32 %61)  ; IMin(a,b)
  %2282 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %68, i32 %2281, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2283 = extractvalue %dx.types.ResRet.f32 %2282, 0
  %2284 = fsub fast float %2283, %85
  %2285 = call float @dx.op.unary.f32(i32 6, float %2284)  ; FAbs(value)
  %2286 = fdiv fast float %2285, %1955
  %2287 = fsub fast float 1.000000e+00, %2286
  %2288 = call float @dx.op.unary.f32(i32 7, float %2287)  ; Saturate(value)
  %2289 = fcmp fast ugt float %2288, 0.000000e+00
  br i1 %2289, label %2290, label %2563

; <label>:2290                                    ; preds = %2275
  %2291 = call i32 @dx.op.binary.i32(i32 37, i32 %68, i32 0)  ; IMax(a,b)
  %2292 = call i32 @dx.op.binary.i32(i32 37, i32 %2281, i32 0)  ; IMax(a,b)
  %2293 = call i32 @dx.op.binary.i32(i32 38, i32 %2291, i32 %60)  ; IMin(a,b)
  %2294 = call i32 @dx.op.binary.i32(i32 38, i32 %2292, i32 %61)  ; IMin(a,b)
  %2295 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2293, i32 %2294, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2296 = extractvalue %dx.types.ResRet.f32 %2295, 0
  %2297 = extractvalue %dx.types.ResRet.f32 %2295, 1
  %2298 = extractvalue %dx.types.ResRet.f32 %2295, 2
  %2299 = extractvalue %dx.types.ResRet.f32 %2295, 3
  %2300 = fcmp fast olt float %2299, 0.000000e+00
  br i1 %2300, label %2301, label %2335

; <label>:2301                                    ; preds = %2290
  %2302 = fcmp fast ogt float %2296, 0x3FA4B5DCC0000000
  %2303 = fcmp fast ogt float %2297, 0x3FA4B5DCC0000000
  %2304 = fcmp fast ogt float %2298, 0x3FA4B5DCC0000000
  %2305 = select i1 %2302, float 0.000000e+00, float 1.000000e+00
  %2306 = select i1 %2303, float 0.000000e+00, float 1.000000e+00
  %2307 = select i1 %2304, float 0.000000e+00, float 1.000000e+00
  %2308 = fmul fast float %2296, 0x3FB3D07220000000
  %2309 = fmul fast float %2297, 0x3FB3D07220000000
  %2310 = fmul fast float %2298, 0x3FB3D07220000000
  %2311 = fadd fast float %2296, 0x3FAC28F5C0000000
  %2312 = fadd fast float %2297, 0x3FAC28F5C0000000
  %2313 = fadd fast float %2298, 0x3FAC28F5C0000000
  %2314 = fmul fast float %2311, 0x3FEE54EDE0000000
  %2315 = fmul fast float %2312, 0x3FEE54EDE0000000
  %2316 = fmul fast float %2313, 0x3FEE54EDE0000000
  %2317 = call float @dx.op.unary.f32(i32 23, float %2314)  ; Log(value)
  %2318 = call float @dx.op.unary.f32(i32 23, float %2315)  ; Log(value)
  %2319 = call float @dx.op.unary.f32(i32 23, float %2316)  ; Log(value)
  %2320 = fmul fast float %2317, 0x4003333340000000
  %2321 = fmul fast float %2318, 0x4003333340000000
  %2322 = fmul fast float %2319, 0x4003333340000000
  %2323 = call float @dx.op.unary.f32(i32 21, float %2320)  ; Exp(value)
  %2324 = call float @dx.op.unary.f32(i32 21, float %2321)  ; Exp(value)
  %2325 = call float @dx.op.unary.f32(i32 21, float %2322)  ; Exp(value)
  %2326 = fsub fast float %2308, %2323
  %2327 = fsub fast float %2309, %2324
  %2328 = fsub fast float %2310, %2325
  %2329 = fmul fast float %2326, %2305
  %2330 = fmul fast float %2327, %2306
  %2331 = fmul fast float %2328, %2307
  %2332 = fadd fast float %2329, %2323
  %2333 = fadd fast float %2330, %2324
  %2334 = fadd fast float %2331, %2325
  br label %2550

; <label>:2335                                    ; preds = %2290
  %2336 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2293, i32 %2294, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2337 = extractvalue %dx.types.ResRet.f32 %2336, 0
  %2338 = fcmp fast ogt float %39, 5.000000e-01
  %2339 = fcmp fast olt float %2337, 1.000000e+00
  %2340 = and i1 %2338, %2339
  br i1 %2340, label %2341, label %2479

; <label>:2341                                    ; preds = %2335
  %2342 = sitofp i32 %2293 to float
  %2343 = sitofp i32 %2294 to float
  %2344 = fadd fast float %2342, 5.000000e-01
  %2345 = fadd fast float %2343, 5.000000e-01
  %2346 = fdiv fast float %2344, %46
  %2347 = fdiv fast float %2345, %47
  %2348 = fmul fast float %2346, 2.000000e+00
  %2349 = fmul fast float %2347, 2.000000e+00
  %2350 = fadd fast float %2348, -1.000000e+00
  %2351 = fsub fast float 1.000000e+00, %2349
  %2352 = fmul fast float %2350, %36
  %2353 = call float @dx.op.tertiary.f32(i32 46, float %2351, float %32, float %2352)  ; FMad(a,b,c)
  %2354 = call float @dx.op.tertiary.f32(i32 46, float %2337, float %28, float %2353)  ; FMad(a,b,c)
  %2355 = fadd fast float %2354, %24
  %2356 = call float @dx.op.unary.f32(i32 6, float %2355)  ; FAbs(value)
  %2357 = fcmp fast ogt float %2356, 0x3EB0C6F7A0000000
  br i1 %2357, label %2358, label %2479

; <label>:2358                                    ; preds = %2341
  %2359 = fmul fast float %2350, %35
  %2360 = call float @dx.op.tertiary.f32(i32 46, float %2351, float %31, float %2359)  ; FMad(a,b,c)
  %2361 = call float @dx.op.tertiary.f32(i32 46, float %2337, float %27, float %2360)  ; FMad(a,b,c)
  %2362 = fadd fast float %2361, %23
  %2363 = fmul fast float %2350, %34
  %2364 = call float @dx.op.tertiary.f32(i32 46, float %2351, float %30, float %2363)  ; FMad(a,b,c)
  %2365 = call float @dx.op.tertiary.f32(i32 46, float %2337, float %26, float %2364)  ; FMad(a,b,c)
  %2366 = fadd fast float %2365, %22
  %2367 = fmul fast float %2350, %33
  %2368 = call float @dx.op.tertiary.f32(i32 46, float %2351, float %29, float %2367)  ; FMad(a,b,c)
  %2369 = call float @dx.op.tertiary.f32(i32 46, float %2337, float %25, float %2368)  ; FMad(a,b,c)
  %2370 = fadd fast float %2369, %21
  %2371 = fdiv fast float %2370, %2355
  %2372 = fdiv fast float %2366, %2355
  %2373 = fdiv fast float %2362, %2355
  %2374 = fsub fast float %2371, %18
  %2375 = fsub fast float %2372, %19
  %2376 = fsub fast float %2373, %20
  %2377 = fmul fast float %2374, %2374
  %2378 = fmul fast float %2375, %2375
  %2379 = fadd fast float %2378, %2377
  %2380 = fmul fast float %2376, %2376
  %2381 = fadd fast float %2379, %2380
  %2382 = call float @dx.op.unary.f32(i32 24, float %2381)  ; Sqrt(value)
  %2383 = fsub fast float %2382, %10
  %2384 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2383)  ; FMax(a,b)
  %2385 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %2385, label %2386, label %2409

; <label>:2386                                    ; preds = %2358
  %2387 = call float @dx.op.unary.f32(i32 6, float %2375)  ; FAbs(value)
  %2388 = fmul fast float %2387, %12
  %2389 = fcmp fast olt float %2388, 0x3F50624DE0000000
  br i1 %2389, label %2390, label %2393

; <label>:2390                                    ; preds = %2386
  %2391 = fmul fast float %2388, 5.000000e-01
  %2392 = fsub fast float 1.000000e+00, %2391
  br label %2398

; <label>:2393                                    ; preds = %2386
  %2394 = fmul fast float %2388, 0xBFF7154760000000
  %2395 = call float @dx.op.unary.f32(i32 21, float %2394)  ; Exp(value)
  %2396 = fsub fast float 1.000000e+00, %2395
  %2397 = fdiv fast float %2396, %2388
  br label %2398

; <label>:2398                                    ; preds = %2393, %2390
  %2399 = phi float [ %2392, %2390 ], [ %2397, %2393 ]
  %2400 = call float @dx.op.binary.f32(i32 36, float %2372, float %19)  ; FMin(a,b)
  %2401 = fsub fast float %2400, %11
  %2402 = fmul fast float %12, %2401
  %2403 = fsub fast float -0.000000e+00, %2402
  %2404 = call float @dx.op.binary.f32(i32 35, float %2403, float -4.000000e+01)  ; FMax(a,b)
  %2405 = call float @dx.op.binary.f32(i32 36, float %2404, float 5.000000e+00)  ; FMin(a,b)
  %2406 = fmul fast float %2405, 0x3FF7154760000000
  %2407 = call float @dx.op.unary.f32(i32 21, float %2406)  ; Exp(value)
  %2408 = fmul fast float %2407, %2399
  br label %2409

; <label>:2409                                    ; preds = %2398, %2358
  %2410 = phi float [ %2408, %2398 ], [ 1.000000e+00, %2358 ]
  %2411 = fmul fast float %2384, %17
  %2412 = fmul fast float %2411, %2410
  %2413 = fcmp fast ole float %2382, %10
  %2414 = fcmp fast olt float %2382, 0x3F1A36E2E0000000
  %2415 = or i1 %2413, %2414
  br i1 %2415, label %2462, label %2416

; <label>:2416                                    ; preds = %2409
  %2417 = fdiv fast float %10, %2382
  %2418 = fmul fast float %2417, %2374
  %2419 = fmul fast float %2417, %2375
  %2420 = fmul fast float %2417, %2376
  %2421 = fadd fast float %2418, %18
  %2422 = fadd fast float %2419, %19
  %2423 = fadd fast float %2420, %20
  %2424 = fadd fast float %2421, -9.000000e+02
  %2425 = fadd fast float %2422, -1.500000e+01
  %2426 = fadd fast float %2423, -7.500000e+02
  %2427 = fmul fast float %2424, 0x3F62345680000000
  %2428 = fmul fast float %2425, 0x3F62345680000000
  %2429 = fmul fast float %2426, 0x3F62345680000000
  %2430 = call float @dx.op.dot3.f32(i32 55, float %2427, float %2428, float %2429, float %2427, float %2428, float %2429)  ; Dot3(ax,ay,az,bx,by,bz)
  %2431 = fsub fast float 1.000000e+00, %2430
  %2432 = call float @dx.op.unary.f32(i32 7, float %2431)  ; Saturate(value)
  %2433 = fmul fast float %2432, %2432
  %2434 = fadd fast float %2421, %2371
  %2435 = fadd fast float %2422, %2372
  %2436 = fadd fast float %2423, %2373
  %2437 = fmul fast float %2434, 0x3F52345680000000
  %2438 = fadd fast float %2437, -2.000000e+00
  %2439 = fmul fast float %2435, 0x3F52345680000000
  %2440 = fadd fast float %2439, 0xBFA1111120000000
  %2441 = fmul fast float %2436, 0x3F52345680000000
  %2442 = fadd fast float %2441, 0xBFFAAAAAC0000000
  %2443 = call float @dx.op.dot3.f32(i32 55, float %2438, float %2440, float %2442, float %2438, float %2440, float %2442)  ; Dot3(ax,ay,az,bx,by,bz)
  %2444 = fsub fast float 1.000000e+00, %2443
  %2445 = call float @dx.op.unary.f32(i32 7, float %2444)  ; Saturate(value)
  %2446 = fmul fast float %2445, %2445
  %2447 = fmul fast float %2446, 4.000000e+00
  %2448 = fadd fast float %2447, %2433
  %2449 = fadd fast float %2371, -9.000000e+02
  %2450 = fadd fast float %2372, -1.500000e+01
  %2451 = fadd fast float %2373, -7.500000e+02
  %2452 = fmul fast float %2449, 0x3F62345680000000
  %2453 = fmul fast float %2450, 0x3F62345680000000
  %2454 = fmul fast float %2451, 0x3F62345680000000
  %2455 = call float @dx.op.dot3.f32(i32 55, float %2452, float %2453, float %2454, float %2452, float %2453, float %2454)  ; Dot3(ax,ay,az,bx,by,bz)
  %2456 = fsub fast float 1.000000e+00, %2455
  %2457 = call float @dx.op.unary.f32(i32 7, float %2456)  ; Saturate(value)
  %2458 = fmul fast float %2457, %2457
  %2459 = fadd fast float %2448, %2458
  %2460 = fmul fast float %2383, 0x3F25D867E0000000
  %2461 = fmul fast float %2460, %2459
  br label %2462

; <label>:2462                                    ; preds = %2416, %2409
  %2463 = phi float [ %2461, %2416 ], [ 0.000000e+00, %2409 ]
  %2464 = fadd fast float %2463, %2412
  %2465 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2464)  ; FMin(a,b)
  %2466 = fmul fast float %2465, 0xBFF7154760000000
  %2467 = call float @dx.op.unary.f32(i32 21, float %2466)  ; Exp(value)
  %2468 = fsub fast float 1.000000e+00, %2467
  %2469 = call float @dx.op.binary.f32(i32 36, float %13, float %2468)  ; FMin(a,b)
  %2470 = fsub fast float %14, %2296
  %2471 = fsub fast float %15, %2297
  %2472 = fsub fast float %16, %2298
  %2473 = fmul fast float %2469, %2470
  %2474 = fmul fast float %2469, %2471
  %2475 = fmul fast float %2469, %2472
  %2476 = fadd fast float %2473, %2296
  %2477 = fadd fast float %2474, %2297
  %2478 = fadd fast float %2475, %2298
  br label %2479

; <label>:2479                                    ; preds = %2462, %2341, %2335
  %2480 = phi float [ %2476, %2462 ], [ %2296, %2341 ], [ %2296, %2335 ]
  %2481 = phi float [ %2477, %2462 ], [ %2297, %2341 ], [ %2297, %2335 ]
  %2482 = phi float [ %2478, %2462 ], [ %2298, %2341 ], [ %2298, %2335 ]
  %2483 = fadd fast float %6, 1.000000e+00
  %2484 = fadd fast float %7, 1.000000e+00
  %2485 = fsub fast float 1.000000e+00, %6
  %2486 = fmul fast float %37, %2483
  %2487 = fmul fast float %37, %2484
  %2488 = fmul fast float %37, %2485
  %2489 = fmul fast float %2486, %2480
  %2490 = fmul fast float %2487, %2481
  %2491 = fmul fast float %2488, %2482
  %2492 = fcmp fast ult float %38, 5.000000e-01
  br i1 %2492, label %2518, label %2493

; <label>:2493                                    ; preds = %2479
  %2494 = fmul fast float %2489, 0x4004147AE0000000
  %2495 = fmul fast float %2490, 0x4004147AE0000000
  %2496 = fmul fast float %2491, 0x4004147AE0000000
  %2497 = fadd fast float %2494, 0x3F9EB851E0000000
  %2498 = fadd fast float %2495, 0x3F9EB851E0000000
  %2499 = fadd fast float %2496, 0x3F9EB851E0000000
  %2500 = fmul fast float %2497, %2489
  %2501 = fmul fast float %2498, %2490
  %2502 = fmul fast float %2499, %2491
  %2503 = fmul fast float %2489, 0x400370A3E0000000
  %2504 = fmul fast float %2490, 0x400370A3E0000000
  %2505 = fmul fast float %2491, 0x400370A3E0000000
  %2506 = fadd fast float %2503, 0x3FE2E147A0000000
  %2507 = fadd fast float %2504, 0x3FE2E147A0000000
  %2508 = fadd fast float %2505, 0x3FE2E147A0000000
  %2509 = fmul fast float %2506, %2489
  %2510 = fmul fast float %2507, %2490
  %2511 = fmul fast float %2508, %2491
  %2512 = fadd fast float %2509, 0x3FC1EB8520000000
  %2513 = fadd fast float %2510, 0x3FC1EB8520000000
  %2514 = fadd fast float %2511, 0x3FC1EB8520000000
  %2515 = fdiv fast float %2500, %2512
  %2516 = fdiv fast float %2501, %2513
  %2517 = fdiv fast float %2502, %2514
  br label %2518

; <label>:2518                                    ; preds = %2493, %2479
  %2519 = phi float [ %2515, %2493 ], [ %2489, %2479 ]
  %2520 = phi float [ %2516, %2493 ], [ %2490, %2479 ]
  %2521 = phi float [ %2517, %2493 ], [ %2491, %2479 ]
  %2522 = call float @dx.op.unary.f32(i32 7, float %2519)  ; Saturate(value)
  %2523 = call float @dx.op.unary.f32(i32 7, float %2520)  ; Saturate(value)
  %2524 = call float @dx.op.unary.f32(i32 7, float %2521)  ; Saturate(value)
  %2525 = call float @dx.op.dot3.f32(i32 55, float %2522, float %2523, float %2524, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2526 = fsub fast float %2522, %2525
  %2527 = fsub fast float %2523, %2525
  %2528 = fsub fast float %2524, %2525
  %2529 = fmul fast float %2526, %9
  %2530 = fmul fast float %2527, %9
  %2531 = fmul fast float %2528, %9
  %2532 = fadd fast float %2529, %2525
  %2533 = fadd fast float %2530, %2525
  %2534 = fadd fast float %2531, %2525
  %2535 = call float @dx.op.unary.f32(i32 7, float %2532)  ; Saturate(value)
  %2536 = call float @dx.op.unary.f32(i32 7, float %2533)  ; Saturate(value)
  %2537 = call float @dx.op.unary.f32(i32 7, float %2534)  ; Saturate(value)
  %2538 = fadd fast float %2535, 0xBFC70A3D80000000
  %2539 = fadd fast float %2536, 0xBFC70A3D80000000
  %2540 = fadd fast float %2537, 0xBFC70A3D80000000
  %2541 = fmul fast float %2538, %8
  %2542 = fmul fast float %2539, %8
  %2543 = fmul fast float %2540, %8
  %2544 = fadd fast float %2541, 0x3FC70A3D80000000
  %2545 = fadd fast float %2542, 0x3FC70A3D80000000
  %2546 = fadd fast float %2543, 0x3FC70A3D80000000
  %2547 = call float @dx.op.unary.f32(i32 7, float %2544)  ; Saturate(value)
  %2548 = call float @dx.op.unary.f32(i32 7, float %2545)  ; Saturate(value)
  %2549 = call float @dx.op.unary.f32(i32 7, float %2546)  ; Saturate(value)
  br label %2550

; <label>:2550                                    ; preds = %2518, %2301
  %2551 = phi float [ %2332, %2301 ], [ %2547, %2518 ]
  %2552 = phi float [ %2333, %2301 ], [ %2548, %2518 ]
  %2553 = phi float [ %2334, %2301 ], [ %2549, %2518 ]
  %2554 = fsub fast float %2551, %701
  %2555 = fsub fast float %2552, %702
  %2556 = fsub fast float %2553, %703
  %2557 = fmul fast float %2554, %2288
  %2558 = fmul fast float %2555, %2288
  %2559 = fmul fast float %2556, %2288
  %2560 = fadd fast float %2557, %701
  %2561 = fadd fast float %2558, %702
  %2562 = fadd fast float %2559, %703
  br label %2563

; <label>:2563                                    ; preds = %2550, %2275
  %2564 = phi float [ %2560, %2550 ], [ %701, %2275 ]
  %2565 = phi float [ %2561, %2550 ], [ %702, %2275 ]
  %2566 = phi float [ %2562, %2550 ], [ %703, %2275 ]
  %2567 = call float @dx.op.binary.f32(i32 36, float %2256, float %2236)  ; FMin(a,b)
  %2568 = call float @dx.op.binary.f32(i32 36, float %2257, float %2237)  ; FMin(a,b)
  %2569 = call float @dx.op.binary.f32(i32 36, float %2258, float %2238)  ; FMin(a,b)
  %2570 = call float @dx.op.binary.f32(i32 36, float %2564, float %2276)  ; FMin(a,b)
  %2571 = call float @dx.op.binary.f32(i32 36, float %2565, float %2277)  ; FMin(a,b)
  %2572 = call float @dx.op.binary.f32(i32 36, float %2566, float %2278)  ; FMin(a,b)
  %2573 = call float @dx.op.binary.f32(i32 36, float %2570, float %2567)  ; FMin(a,b)
  %2574 = call float @dx.op.binary.f32(i32 36, float %2571, float %2568)  ; FMin(a,b)
  %2575 = call float @dx.op.binary.f32(i32 36, float %2572, float %2569)  ; FMin(a,b)
  %2576 = call float @dx.op.binary.f32(i32 36, float %701, float %2573)  ; FMin(a,b)
  %2577 = call float @dx.op.binary.f32(i32 36, float %702, float %2574)  ; FMin(a,b)
  %2578 = call float @dx.op.binary.f32(i32 36, float %703, float %2575)  ; FMin(a,b)
  %2579 = call float @dx.op.binary.f32(i32 35, float %2256, float %2236)  ; FMax(a,b)
  %2580 = call float @dx.op.binary.f32(i32 35, float %2257, float %2237)  ; FMax(a,b)
  %2581 = call float @dx.op.binary.f32(i32 35, float %2258, float %2238)  ; FMax(a,b)
  %2582 = call float @dx.op.binary.f32(i32 35, float %2564, float %2276)  ; FMax(a,b)
  %2583 = call float @dx.op.binary.f32(i32 35, float %2565, float %2277)  ; FMax(a,b)
  %2584 = call float @dx.op.binary.f32(i32 35, float %2566, float %2278)  ; FMax(a,b)
  %2585 = call float @dx.op.binary.f32(i32 35, float %2582, float %2579)  ; FMax(a,b)
  %2586 = call float @dx.op.binary.f32(i32 35, float %2583, float %2580)  ; FMax(a,b)
  %2587 = call float @dx.op.binary.f32(i32 35, float %2584, float %2581)  ; FMax(a,b)
  %2588 = call float @dx.op.binary.f32(i32 35, float %701, float %2585)  ; FMax(a,b)
  %2589 = call float @dx.op.binary.f32(i32 35, float %702, float %2586)  ; FMax(a,b)
  %2590 = call float @dx.op.binary.f32(i32 35, float %703, float %2587)  ; FMax(a,b)
  %2591 = fsub fast float %2588, %2576
  %2592 = fsub fast float %2589, %2577
  %2593 = fsub fast float %2590, %2578
  %2594 = call float @dx.op.unary.f32(i32 6, float %2591)  ; FAbs(value)
  %2595 = call float @dx.op.unary.f32(i32 6, float %2592)  ; FAbs(value)
  %2596 = call float @dx.op.unary.f32(i32 6, float %2593)  ; FAbs(value)
  %2597 = call float @dx.op.binary.f32(i32 35, float %2595, float %2596)  ; FMax(a,b)
  %2598 = call float @dx.op.binary.f32(i32 35, float %2594, float %2597)  ; FMax(a,b)
  %2599 = call float @dx.op.binary.f32(i32 35, float %2589, float %2590)  ; FMax(a,b)
  %2600 = call float @dx.op.binary.f32(i32 35, float %2588, float %2599)  ; FMax(a,b)
  %2601 = fmul fast float %2600, 1.250000e-01
  %2602 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %2601)  ; FMax(a,b)
  %2603 = fcmp fast ogt float %2598, %2602
  br i1 %2603, label %2604, label %2666

; <label>:2604                                    ; preds = %2563
  %2605 = fsub fast float %2564, %2276
  %2606 = fsub fast float %2565, %2277
  %2607 = fsub fast float %2566, %2278
  %2608 = call float @dx.op.unary.f32(i32 6, float %2605)  ; FAbs(value)
  %2609 = call float @dx.op.unary.f32(i32 6, float %2606)  ; FAbs(value)
  %2610 = call float @dx.op.unary.f32(i32 6, float %2607)  ; FAbs(value)
  %2611 = call float @dx.op.binary.f32(i32 35, float %2609, float %2610)  ; FMax(a,b)
  %2612 = call float @dx.op.binary.f32(i32 35, float %2608, float %2611)  ; FMax(a,b)
  %2613 = fsub fast float %2256, %2236
  %2614 = fsub fast float %2257, %2237
  %2615 = fsub fast float %2258, %2238
  %2616 = call float @dx.op.unary.f32(i32 6, float %2613)  ; FAbs(value)
  %2617 = call float @dx.op.unary.f32(i32 6, float %2614)  ; FAbs(value)
  %2618 = call float @dx.op.unary.f32(i32 6, float %2615)  ; FAbs(value)
  %2619 = call float @dx.op.binary.f32(i32 35, float %2617, float %2618)  ; FMax(a,b)
  %2620 = call float @dx.op.binary.f32(i32 35, float %2616, float %2619)  ; FMax(a,b)
  %2621 = fcmp fast olt float %2612, %2620
  %2622 = select i1 %2621, float %2564, float %2256
  %2623 = select i1 %2621, float %2565, float %2257
  %2624 = select i1 %2621, float %2566, float %2258
  %2625 = select i1 %2621, float %2276, float %2236
  %2626 = select i1 %2621, float %2277, float %2237
  %2627 = select i1 %2621, float %2278, float %2238
  %2628 = fsub fast float %701, %2625
  %2629 = fsub fast float %702, %2626
  %2630 = fsub fast float %703, %2627
  %2631 = fsub fast float %701, %2622
  %2632 = fsub fast float %702, %2623
  %2633 = fsub fast float %703, %2624
  %2634 = call float @dx.op.dot3.f32(i32 55, float %2631, float %2632, float %2633, float %2628, float %2629, float %2630)  ; Dot3(ax,ay,az,bx,by,bz)
  %2635 = fcmp fast ogt float %2634, 0.000000e+00
  br i1 %2635, label %2636, label %2647

; <label>:2636                                    ; preds = %2604
  %2637 = fsub fast float %2622, %2625
  %2638 = fsub fast float %2623, %2626
  %2639 = fsub fast float %2624, %2627
  %2640 = call float @dx.op.unary.f32(i32 6, float %2637)  ; FAbs(value)
  %2641 = call float @dx.op.unary.f32(i32 6, float %2638)  ; FAbs(value)
  %2642 = call float @dx.op.unary.f32(i32 6, float %2639)  ; FAbs(value)
  %2643 = call float @dx.op.binary.f32(i32 35, float %2641, float %2642)  ; FMax(a,b)
  %2644 = call float @dx.op.binary.f32(i32 35, float %2640, float %2643)  ; FMax(a,b)
  %2645 = fmul fast float %2598, 2.500000e-01
  %2646 = fcmp fast olt float %2644, %2645
  br label %2647

; <label>:2647                                    ; preds = %2636, %2604
  %2648 = phi i1 [ false, %2604 ], [ %2646, %2636 ]
  %2649 = select i1 %2648, float 5.000000e-01, float 1.000000e+00
  %2650 = fmul fast float %2649, %3
  %2651 = fadd fast float %2622, %2625
  %2652 = fadd fast float %2623, %2626
  %2653 = fadd fast float %2624, %2627
  %2654 = fmul fast float %2651, 5.000000e-01
  %2655 = fmul fast float %2652, 5.000000e-01
  %2656 = fmul fast float %2653, 5.000000e-01
  %2657 = fsub fast float %2654, %701
  %2658 = fsub fast float %2655, %702
  %2659 = fsub fast float %2656, %703
  %2660 = fmul fast float %2650, %2657
  %2661 = fmul fast float %2650, %2658
  %2662 = fmul fast float %2650, %2659
  %2663 = fadd fast float %2660, %701
  %2664 = fadd fast float %2661, %702
  %2665 = fadd fast float %2662, %703
  br label %2666

; <label>:2666                                    ; preds = %2647, %2563, %1942
  %2667 = phi float [ %701, %1942 ], [ %2663, %2647 ], [ %701, %2563 ]
  %2668 = phi float [ %702, %1942 ], [ %2664, %2647 ], [ %702, %2563 ]
  %2669 = phi float [ %703, %1942 ], [ %2665, %2647 ], [ %703, %2563 ]
  %2670 = fcmp fast ult float %190, 0.000000e+00
  br i1 %2670, label %3390, label %2671

; <label>:2671                                    ; preds = %2666
  %2672 = fsub fast float 1.000000e+00, %87
  %2673 = fmul fast float %2672, 0x3FA99999A0000000
  %2674 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %2673)  ; FMax(a,b)
  %2675 = fsub fast float %89, %87
  %2676 = call float @dx.op.unary.f32(i32 6, float %2675)  ; FAbs(value)
  %2677 = fdiv fast float %2676, %2674
  %2678 = fsub fast float 1.000000e+00, %2677
  %2679 = call float @dx.op.unary.f32(i32 7, float %2678)  ; Saturate(value)
  %2680 = fcmp fast ugt float %2679, 0.000000e+00
  br i1 %2680, label %2681, label %2691

; <label>:2681                                    ; preds = %2671
  %2682 = fsub fast float %1209, %955
  %2683 = fsub fast float %1210, %956
  %2684 = fsub fast float %1211, %957
  %2685 = fmul fast float %2679, %2682
  %2686 = fmul fast float %2679, %2683
  %2687 = fmul fast float %2679, %2684
  %2688 = fadd fast float %2685, %955
  %2689 = fadd fast float %2686, %956
  %2690 = fadd fast float %2687, %957
  br label %2691

; <label>:2691                                    ; preds = %2681, %2671
  %2692 = phi float [ %2688, %2681 ], [ %955, %2671 ]
  %2693 = phi float [ %2689, %2681 ], [ %956, %2671 ]
  %2694 = phi float [ %2690, %2681 ], [ %957, %2671 ]
  %2695 = add i32 %56, -1
  %2696 = call i32 @dx.op.binary.i32(i32 37, i32 %2695, i32 0)  ; IMax(a,b)
  %2697 = call i32 @dx.op.binary.i32(i32 38, i32 %2696, i32 %60)  ; IMin(a,b)
  %2698 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2697, i32 %71, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2699 = extractvalue %dx.types.ResRet.f32 %2698, 0
  %2700 = fsub fast float %2699, %87
  %2701 = call float @dx.op.unary.f32(i32 6, float %2700)  ; FAbs(value)
  %2702 = fdiv fast float %2701, %2674
  %2703 = fsub fast float 1.000000e+00, %2702
  %2704 = call float @dx.op.unary.f32(i32 7, float %2703)  ; Saturate(value)
  %2705 = fcmp fast ugt float %2704, 0.000000e+00
  br i1 %2705, label %2706, label %2979

; <label>:2706                                    ; preds = %2691
  %2707 = call i32 @dx.op.binary.i32(i32 37, i32 %2697, i32 0)  ; IMax(a,b)
  %2708 = call i32 @dx.op.binary.i32(i32 37, i32 %71, i32 0)  ; IMax(a,b)
  %2709 = call i32 @dx.op.binary.i32(i32 38, i32 %2707, i32 %60)  ; IMin(a,b)
  %2710 = call i32 @dx.op.binary.i32(i32 38, i32 %2708, i32 %61)  ; IMin(a,b)
  %2711 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2709, i32 %2710, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2712 = extractvalue %dx.types.ResRet.f32 %2711, 0
  %2713 = extractvalue %dx.types.ResRet.f32 %2711, 1
  %2714 = extractvalue %dx.types.ResRet.f32 %2711, 2
  %2715 = extractvalue %dx.types.ResRet.f32 %2711, 3
  %2716 = fcmp fast olt float %2715, 0.000000e+00
  br i1 %2716, label %2717, label %2751

; <label>:2717                                    ; preds = %2706
  %2718 = fcmp fast ogt float %2712, 0x3FA4B5DCC0000000
  %2719 = fcmp fast ogt float %2713, 0x3FA4B5DCC0000000
  %2720 = fcmp fast ogt float %2714, 0x3FA4B5DCC0000000
  %2721 = select i1 %2718, float 0.000000e+00, float 1.000000e+00
  %2722 = select i1 %2719, float 0.000000e+00, float 1.000000e+00
  %2723 = select i1 %2720, float 0.000000e+00, float 1.000000e+00
  %2724 = fmul fast float %2712, 0x3FB3D07220000000
  %2725 = fmul fast float %2713, 0x3FB3D07220000000
  %2726 = fmul fast float %2714, 0x3FB3D07220000000
  %2727 = fadd fast float %2712, 0x3FAC28F5C0000000
  %2728 = fadd fast float %2713, 0x3FAC28F5C0000000
  %2729 = fadd fast float %2714, 0x3FAC28F5C0000000
  %2730 = fmul fast float %2727, 0x3FEE54EDE0000000
  %2731 = fmul fast float %2728, 0x3FEE54EDE0000000
  %2732 = fmul fast float %2729, 0x3FEE54EDE0000000
  %2733 = call float @dx.op.unary.f32(i32 23, float %2730)  ; Log(value)
  %2734 = call float @dx.op.unary.f32(i32 23, float %2731)  ; Log(value)
  %2735 = call float @dx.op.unary.f32(i32 23, float %2732)  ; Log(value)
  %2736 = fmul fast float %2733, 0x4003333340000000
  %2737 = fmul fast float %2734, 0x4003333340000000
  %2738 = fmul fast float %2735, 0x4003333340000000
  %2739 = call float @dx.op.unary.f32(i32 21, float %2736)  ; Exp(value)
  %2740 = call float @dx.op.unary.f32(i32 21, float %2737)  ; Exp(value)
  %2741 = call float @dx.op.unary.f32(i32 21, float %2738)  ; Exp(value)
  %2742 = fsub fast float %2724, %2739
  %2743 = fsub fast float %2725, %2740
  %2744 = fsub fast float %2726, %2741
  %2745 = fmul fast float %2742, %2721
  %2746 = fmul fast float %2743, %2722
  %2747 = fmul fast float %2744, %2723
  %2748 = fadd fast float %2745, %2739
  %2749 = fadd fast float %2746, %2740
  %2750 = fadd fast float %2747, %2741
  br label %2966

; <label>:2751                                    ; preds = %2706
  %2752 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2709, i32 %2710, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2753 = extractvalue %dx.types.ResRet.f32 %2752, 0
  %2754 = fcmp fast ogt float %39, 5.000000e-01
  %2755 = fcmp fast olt float %2753, 1.000000e+00
  %2756 = and i1 %2754, %2755
  br i1 %2756, label %2757, label %2895

; <label>:2757                                    ; preds = %2751
  %2758 = sitofp i32 %2709 to float
  %2759 = sitofp i32 %2710 to float
  %2760 = fadd fast float %2758, 5.000000e-01
  %2761 = fadd fast float %2759, 5.000000e-01
  %2762 = fdiv fast float %2760, %46
  %2763 = fdiv fast float %2761, %47
  %2764 = fmul fast float %2762, 2.000000e+00
  %2765 = fmul fast float %2763, 2.000000e+00
  %2766 = fadd fast float %2764, -1.000000e+00
  %2767 = fsub fast float 1.000000e+00, %2765
  %2768 = fmul fast float %2766, %36
  %2769 = call float @dx.op.tertiary.f32(i32 46, float %2767, float %32, float %2768)  ; FMad(a,b,c)
  %2770 = call float @dx.op.tertiary.f32(i32 46, float %2753, float %28, float %2769)  ; FMad(a,b,c)
  %2771 = fadd fast float %2770, %24
  %2772 = call float @dx.op.unary.f32(i32 6, float %2771)  ; FAbs(value)
  %2773 = fcmp fast ogt float %2772, 0x3EB0C6F7A0000000
  br i1 %2773, label %2774, label %2895

; <label>:2774                                    ; preds = %2757
  %2775 = fmul fast float %2766, %35
  %2776 = call float @dx.op.tertiary.f32(i32 46, float %2767, float %31, float %2775)  ; FMad(a,b,c)
  %2777 = call float @dx.op.tertiary.f32(i32 46, float %2753, float %27, float %2776)  ; FMad(a,b,c)
  %2778 = fadd fast float %2777, %23
  %2779 = fmul fast float %2766, %34
  %2780 = call float @dx.op.tertiary.f32(i32 46, float %2767, float %30, float %2779)  ; FMad(a,b,c)
  %2781 = call float @dx.op.tertiary.f32(i32 46, float %2753, float %26, float %2780)  ; FMad(a,b,c)
  %2782 = fadd fast float %2781, %22
  %2783 = fmul fast float %2766, %33
  %2784 = call float @dx.op.tertiary.f32(i32 46, float %2767, float %29, float %2783)  ; FMad(a,b,c)
  %2785 = call float @dx.op.tertiary.f32(i32 46, float %2753, float %25, float %2784)  ; FMad(a,b,c)
  %2786 = fadd fast float %2785, %21
  %2787 = fdiv fast float %2786, %2771
  %2788 = fdiv fast float %2782, %2771
  %2789 = fdiv fast float %2778, %2771
  %2790 = fsub fast float %2787, %18
  %2791 = fsub fast float %2788, %19
  %2792 = fsub fast float %2789, %20
  %2793 = fmul fast float %2790, %2790
  %2794 = fmul fast float %2791, %2791
  %2795 = fadd fast float %2794, %2793
  %2796 = fmul fast float %2792, %2792
  %2797 = fadd fast float %2795, %2796
  %2798 = call float @dx.op.unary.f32(i32 24, float %2797)  ; Sqrt(value)
  %2799 = fsub fast float %2798, %10
  %2800 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2799)  ; FMax(a,b)
  %2801 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %2801, label %2802, label %2825

; <label>:2802                                    ; preds = %2774
  %2803 = call float @dx.op.unary.f32(i32 6, float %2791)  ; FAbs(value)
  %2804 = fmul fast float %2803, %12
  %2805 = fcmp fast olt float %2804, 0x3F50624DE0000000
  br i1 %2805, label %2806, label %2809

; <label>:2806                                    ; preds = %2802
  %2807 = fmul fast float %2804, 5.000000e-01
  %2808 = fsub fast float 1.000000e+00, %2807
  br label %2814

; <label>:2809                                    ; preds = %2802
  %2810 = fmul fast float %2804, 0xBFF7154760000000
  %2811 = call float @dx.op.unary.f32(i32 21, float %2810)  ; Exp(value)
  %2812 = fsub fast float 1.000000e+00, %2811
  %2813 = fdiv fast float %2812, %2804
  br label %2814

; <label>:2814                                    ; preds = %2809, %2806
  %2815 = phi float [ %2808, %2806 ], [ %2813, %2809 ]
  %2816 = call float @dx.op.binary.f32(i32 36, float %2788, float %19)  ; FMin(a,b)
  %2817 = fsub fast float %2816, %11
  %2818 = fmul fast float %12, %2817
  %2819 = fsub fast float -0.000000e+00, %2818
  %2820 = call float @dx.op.binary.f32(i32 35, float %2819, float -4.000000e+01)  ; FMax(a,b)
  %2821 = call float @dx.op.binary.f32(i32 36, float %2820, float 5.000000e+00)  ; FMin(a,b)
  %2822 = fmul fast float %2821, 0x3FF7154760000000
  %2823 = call float @dx.op.unary.f32(i32 21, float %2822)  ; Exp(value)
  %2824 = fmul fast float %2823, %2815
  br label %2825

; <label>:2825                                    ; preds = %2814, %2774
  %2826 = phi float [ %2824, %2814 ], [ 1.000000e+00, %2774 ]
  %2827 = fmul fast float %2800, %17
  %2828 = fmul fast float %2827, %2826
  %2829 = fcmp fast ole float %2798, %10
  %2830 = fcmp fast olt float %2798, 0x3F1A36E2E0000000
  %2831 = or i1 %2829, %2830
  br i1 %2831, label %2878, label %2832

; <label>:2832                                    ; preds = %2825
  %2833 = fdiv fast float %10, %2798
  %2834 = fmul fast float %2833, %2790
  %2835 = fmul fast float %2833, %2791
  %2836 = fmul fast float %2833, %2792
  %2837 = fadd fast float %2834, %18
  %2838 = fadd fast float %2835, %19
  %2839 = fadd fast float %2836, %20
  %2840 = fadd fast float %2837, -9.000000e+02
  %2841 = fadd fast float %2838, -1.500000e+01
  %2842 = fadd fast float %2839, -7.500000e+02
  %2843 = fmul fast float %2840, 0x3F62345680000000
  %2844 = fmul fast float %2841, 0x3F62345680000000
  %2845 = fmul fast float %2842, 0x3F62345680000000
  %2846 = call float @dx.op.dot3.f32(i32 55, float %2843, float %2844, float %2845, float %2843, float %2844, float %2845)  ; Dot3(ax,ay,az,bx,by,bz)
  %2847 = fsub fast float 1.000000e+00, %2846
  %2848 = call float @dx.op.unary.f32(i32 7, float %2847)  ; Saturate(value)
  %2849 = fmul fast float %2848, %2848
  %2850 = fadd fast float %2837, %2787
  %2851 = fadd fast float %2838, %2788
  %2852 = fadd fast float %2839, %2789
  %2853 = fmul fast float %2850, 0x3F52345680000000
  %2854 = fadd fast float %2853, -2.000000e+00
  %2855 = fmul fast float %2851, 0x3F52345680000000
  %2856 = fadd fast float %2855, 0xBFA1111120000000
  %2857 = fmul fast float %2852, 0x3F52345680000000
  %2858 = fadd fast float %2857, 0xBFFAAAAAC0000000
  %2859 = call float @dx.op.dot3.f32(i32 55, float %2854, float %2856, float %2858, float %2854, float %2856, float %2858)  ; Dot3(ax,ay,az,bx,by,bz)
  %2860 = fsub fast float 1.000000e+00, %2859
  %2861 = call float @dx.op.unary.f32(i32 7, float %2860)  ; Saturate(value)
  %2862 = fmul fast float %2861, %2861
  %2863 = fmul fast float %2862, 4.000000e+00
  %2864 = fadd fast float %2863, %2849
  %2865 = fadd fast float %2787, -9.000000e+02
  %2866 = fadd fast float %2788, -1.500000e+01
  %2867 = fadd fast float %2789, -7.500000e+02
  %2868 = fmul fast float %2865, 0x3F62345680000000
  %2869 = fmul fast float %2866, 0x3F62345680000000
  %2870 = fmul fast float %2867, 0x3F62345680000000
  %2871 = call float @dx.op.dot3.f32(i32 55, float %2868, float %2869, float %2870, float %2868, float %2869, float %2870)  ; Dot3(ax,ay,az,bx,by,bz)
  %2872 = fsub fast float 1.000000e+00, %2871
  %2873 = call float @dx.op.unary.f32(i32 7, float %2872)  ; Saturate(value)
  %2874 = fmul fast float %2873, %2873
  %2875 = fadd fast float %2864, %2874
  %2876 = fmul fast float %2799, 0x3F25D867E0000000
  %2877 = fmul fast float %2876, %2875
  br label %2878

; <label>:2878                                    ; preds = %2832, %2825
  %2879 = phi float [ %2877, %2832 ], [ 0.000000e+00, %2825 ]
  %2880 = fadd fast float %2879, %2828
  %2881 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2880)  ; FMin(a,b)
  %2882 = fmul fast float %2881, 0xBFF7154760000000
  %2883 = call float @dx.op.unary.f32(i32 21, float %2882)  ; Exp(value)
  %2884 = fsub fast float 1.000000e+00, %2883
  %2885 = call float @dx.op.binary.f32(i32 36, float %13, float %2884)  ; FMin(a,b)
  %2886 = fsub fast float %14, %2712
  %2887 = fsub fast float %15, %2713
  %2888 = fsub fast float %16, %2714
  %2889 = fmul fast float %2885, %2886
  %2890 = fmul fast float %2885, %2887
  %2891 = fmul fast float %2885, %2888
  %2892 = fadd fast float %2889, %2712
  %2893 = fadd fast float %2890, %2713
  %2894 = fadd fast float %2891, %2714
  br label %2895

; <label>:2895                                    ; preds = %2878, %2757, %2751
  %2896 = phi float [ %2892, %2878 ], [ %2712, %2757 ], [ %2712, %2751 ]
  %2897 = phi float [ %2893, %2878 ], [ %2713, %2757 ], [ %2713, %2751 ]
  %2898 = phi float [ %2894, %2878 ], [ %2714, %2757 ], [ %2714, %2751 ]
  %2899 = fadd fast float %6, 1.000000e+00
  %2900 = fadd fast float %7, 1.000000e+00
  %2901 = fsub fast float 1.000000e+00, %6
  %2902 = fmul fast float %37, %2899
  %2903 = fmul fast float %37, %2900
  %2904 = fmul fast float %37, %2901
  %2905 = fmul fast float %2902, %2896
  %2906 = fmul fast float %2903, %2897
  %2907 = fmul fast float %2904, %2898
  %2908 = fcmp fast ult float %38, 5.000000e-01
  br i1 %2908, label %2934, label %2909

; <label>:2909                                    ; preds = %2895
  %2910 = fmul fast float %2905, 0x4004147AE0000000
  %2911 = fmul fast float %2906, 0x4004147AE0000000
  %2912 = fmul fast float %2907, 0x4004147AE0000000
  %2913 = fadd fast float %2910, 0x3F9EB851E0000000
  %2914 = fadd fast float %2911, 0x3F9EB851E0000000
  %2915 = fadd fast float %2912, 0x3F9EB851E0000000
  %2916 = fmul fast float %2913, %2905
  %2917 = fmul fast float %2914, %2906
  %2918 = fmul fast float %2915, %2907
  %2919 = fmul fast float %2905, 0x400370A3E0000000
  %2920 = fmul fast float %2906, 0x400370A3E0000000
  %2921 = fmul fast float %2907, 0x400370A3E0000000
  %2922 = fadd fast float %2919, 0x3FE2E147A0000000
  %2923 = fadd fast float %2920, 0x3FE2E147A0000000
  %2924 = fadd fast float %2921, 0x3FE2E147A0000000
  %2925 = fmul fast float %2922, %2905
  %2926 = fmul fast float %2923, %2906
  %2927 = fmul fast float %2924, %2907
  %2928 = fadd fast float %2925, 0x3FC1EB8520000000
  %2929 = fadd fast float %2926, 0x3FC1EB8520000000
  %2930 = fadd fast float %2927, 0x3FC1EB8520000000
  %2931 = fdiv fast float %2916, %2928
  %2932 = fdiv fast float %2917, %2929
  %2933 = fdiv fast float %2918, %2930
  br label %2934

; <label>:2934                                    ; preds = %2909, %2895
  %2935 = phi float [ %2931, %2909 ], [ %2905, %2895 ]
  %2936 = phi float [ %2932, %2909 ], [ %2906, %2895 ]
  %2937 = phi float [ %2933, %2909 ], [ %2907, %2895 ]
  %2938 = call float @dx.op.unary.f32(i32 7, float %2935)  ; Saturate(value)
  %2939 = call float @dx.op.unary.f32(i32 7, float %2936)  ; Saturate(value)
  %2940 = call float @dx.op.unary.f32(i32 7, float %2937)  ; Saturate(value)
  %2941 = call float @dx.op.dot3.f32(i32 55, float %2938, float %2939, float %2940, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2942 = fsub fast float %2938, %2941
  %2943 = fsub fast float %2939, %2941
  %2944 = fsub fast float %2940, %2941
  %2945 = fmul fast float %2942, %9
  %2946 = fmul fast float %2943, %9
  %2947 = fmul fast float %2944, %9
  %2948 = fadd fast float %2945, %2941
  %2949 = fadd fast float %2946, %2941
  %2950 = fadd fast float %2947, %2941
  %2951 = call float @dx.op.unary.f32(i32 7, float %2948)  ; Saturate(value)
  %2952 = call float @dx.op.unary.f32(i32 7, float %2949)  ; Saturate(value)
  %2953 = call float @dx.op.unary.f32(i32 7, float %2950)  ; Saturate(value)
  %2954 = fadd fast float %2951, 0xBFC70A3D80000000
  %2955 = fadd fast float %2952, 0xBFC70A3D80000000
  %2956 = fadd fast float %2953, 0xBFC70A3D80000000
  %2957 = fmul fast float %2954, %8
  %2958 = fmul fast float %2955, %8
  %2959 = fmul fast float %2956, %8
  %2960 = fadd fast float %2957, 0x3FC70A3D80000000
  %2961 = fadd fast float %2958, 0x3FC70A3D80000000
  %2962 = fadd fast float %2959, 0x3FC70A3D80000000
  %2963 = call float @dx.op.unary.f32(i32 7, float %2960)  ; Saturate(value)
  %2964 = call float @dx.op.unary.f32(i32 7, float %2961)  ; Saturate(value)
  %2965 = call float @dx.op.unary.f32(i32 7, float %2962)  ; Saturate(value)
  br label %2966

; <label>:2966                                    ; preds = %2934, %2717
  %2967 = phi float [ %2748, %2717 ], [ %2963, %2934 ]
  %2968 = phi float [ %2749, %2717 ], [ %2964, %2934 ]
  %2969 = phi float [ %2750, %2717 ], [ %2965, %2934 ]
  %2970 = fsub fast float %2967, %955
  %2971 = fsub fast float %2968, %956
  %2972 = fsub fast float %2969, %957
  %2973 = fmul fast float %2970, %2704
  %2974 = fmul fast float %2971, %2704
  %2975 = fmul fast float %2972, %2704
  %2976 = fadd fast float %2973, %955
  %2977 = fadd fast float %2974, %956
  %2978 = fadd fast float %2975, %957
  br label %2979

; <label>:2979                                    ; preds = %2966, %2691
  %2980 = phi float [ %2976, %2966 ], [ %955, %2691 ]
  %2981 = phi float [ %2977, %2966 ], [ %956, %2691 ]
  %2982 = phi float [ %2978, %2966 ], [ %957, %2691 ]
  %2983 = add i32 %57, 2
  %2984 = call i32 @dx.op.binary.i32(i32 37, i32 %2983, i32 0)  ; IMax(a,b)
  %2985 = call i32 @dx.op.binary.i32(i32 38, i32 %2984, i32 %61)  ; IMin(a,b)
  %2986 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %64, i32 %2985, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2987 = extractvalue %dx.types.ResRet.f32 %2986, 0
  %2988 = fsub fast float %2987, %87
  %2989 = call float @dx.op.unary.f32(i32 6, float %2988)  ; FAbs(value)
  %2990 = fdiv fast float %2989, %2674
  %2991 = fsub fast float 1.000000e+00, %2990
  %2992 = call float @dx.op.unary.f32(i32 7, float %2991)  ; Saturate(value)
  %2993 = fcmp fast ugt float %2992, 0.000000e+00
  br i1 %2993, label %2994, label %3267

; <label>:2994                                    ; preds = %2979
  %2995 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %2996 = call i32 @dx.op.binary.i32(i32 37, i32 %2985, i32 0)  ; IMax(a,b)
  %2997 = call i32 @dx.op.binary.i32(i32 38, i32 %2995, i32 %60)  ; IMin(a,b)
  %2998 = call i32 @dx.op.binary.i32(i32 38, i32 %2996, i32 %61)  ; IMin(a,b)
  %2999 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2997, i32 %2998, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3000 = extractvalue %dx.types.ResRet.f32 %2999, 0
  %3001 = extractvalue %dx.types.ResRet.f32 %2999, 1
  %3002 = extractvalue %dx.types.ResRet.f32 %2999, 2
  %3003 = extractvalue %dx.types.ResRet.f32 %2999, 3
  %3004 = fcmp fast olt float %3003, 0.000000e+00
  br i1 %3004, label %3005, label %3039

; <label>:3005                                    ; preds = %2994
  %3006 = fcmp fast ogt float %3000, 0x3FA4B5DCC0000000
  %3007 = fcmp fast ogt float %3001, 0x3FA4B5DCC0000000
  %3008 = fcmp fast ogt float %3002, 0x3FA4B5DCC0000000
  %3009 = select i1 %3006, float 0.000000e+00, float 1.000000e+00
  %3010 = select i1 %3007, float 0.000000e+00, float 1.000000e+00
  %3011 = select i1 %3008, float 0.000000e+00, float 1.000000e+00
  %3012 = fmul fast float %3000, 0x3FB3D07220000000
  %3013 = fmul fast float %3001, 0x3FB3D07220000000
  %3014 = fmul fast float %3002, 0x3FB3D07220000000
  %3015 = fadd fast float %3000, 0x3FAC28F5C0000000
  %3016 = fadd fast float %3001, 0x3FAC28F5C0000000
  %3017 = fadd fast float %3002, 0x3FAC28F5C0000000
  %3018 = fmul fast float %3015, 0x3FEE54EDE0000000
  %3019 = fmul fast float %3016, 0x3FEE54EDE0000000
  %3020 = fmul fast float %3017, 0x3FEE54EDE0000000
  %3021 = call float @dx.op.unary.f32(i32 23, float %3018)  ; Log(value)
  %3022 = call float @dx.op.unary.f32(i32 23, float %3019)  ; Log(value)
  %3023 = call float @dx.op.unary.f32(i32 23, float %3020)  ; Log(value)
  %3024 = fmul fast float %3021, 0x4003333340000000
  %3025 = fmul fast float %3022, 0x4003333340000000
  %3026 = fmul fast float %3023, 0x4003333340000000
  %3027 = call float @dx.op.unary.f32(i32 21, float %3024)  ; Exp(value)
  %3028 = call float @dx.op.unary.f32(i32 21, float %3025)  ; Exp(value)
  %3029 = call float @dx.op.unary.f32(i32 21, float %3026)  ; Exp(value)
  %3030 = fsub fast float %3012, %3027
  %3031 = fsub fast float %3013, %3028
  %3032 = fsub fast float %3014, %3029
  %3033 = fmul fast float %3030, %3009
  %3034 = fmul fast float %3031, %3010
  %3035 = fmul fast float %3032, %3011
  %3036 = fadd fast float %3033, %3027
  %3037 = fadd fast float %3034, %3028
  %3038 = fadd fast float %3035, %3029
  br label %3254

; <label>:3039                                    ; preds = %2994
  %3040 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2997, i32 %2998, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3041 = extractvalue %dx.types.ResRet.f32 %3040, 0
  %3042 = fcmp fast ogt float %39, 5.000000e-01
  %3043 = fcmp fast olt float %3041, 1.000000e+00
  %3044 = and i1 %3042, %3043
  br i1 %3044, label %3045, label %3183

; <label>:3045                                    ; preds = %3039
  %3046 = sitofp i32 %2997 to float
  %3047 = sitofp i32 %2998 to float
  %3048 = fadd fast float %3046, 5.000000e-01
  %3049 = fadd fast float %3047, 5.000000e-01
  %3050 = fdiv fast float %3048, %46
  %3051 = fdiv fast float %3049, %47
  %3052 = fmul fast float %3050, 2.000000e+00
  %3053 = fmul fast float %3051, 2.000000e+00
  %3054 = fadd fast float %3052, -1.000000e+00
  %3055 = fsub fast float 1.000000e+00, %3053
  %3056 = fmul fast float %3054, %36
  %3057 = call float @dx.op.tertiary.f32(i32 46, float %3055, float %32, float %3056)  ; FMad(a,b,c)
  %3058 = call float @dx.op.tertiary.f32(i32 46, float %3041, float %28, float %3057)  ; FMad(a,b,c)
  %3059 = fadd fast float %3058, %24
  %3060 = call float @dx.op.unary.f32(i32 6, float %3059)  ; FAbs(value)
  %3061 = fcmp fast ogt float %3060, 0x3EB0C6F7A0000000
  br i1 %3061, label %3062, label %3183

; <label>:3062                                    ; preds = %3045
  %3063 = fmul fast float %3054, %35
  %3064 = call float @dx.op.tertiary.f32(i32 46, float %3055, float %31, float %3063)  ; FMad(a,b,c)
  %3065 = call float @dx.op.tertiary.f32(i32 46, float %3041, float %27, float %3064)  ; FMad(a,b,c)
  %3066 = fadd fast float %3065, %23
  %3067 = fmul fast float %3054, %34
  %3068 = call float @dx.op.tertiary.f32(i32 46, float %3055, float %30, float %3067)  ; FMad(a,b,c)
  %3069 = call float @dx.op.tertiary.f32(i32 46, float %3041, float %26, float %3068)  ; FMad(a,b,c)
  %3070 = fadd fast float %3069, %22
  %3071 = fmul fast float %3054, %33
  %3072 = call float @dx.op.tertiary.f32(i32 46, float %3055, float %29, float %3071)  ; FMad(a,b,c)
  %3073 = call float @dx.op.tertiary.f32(i32 46, float %3041, float %25, float %3072)  ; FMad(a,b,c)
  %3074 = fadd fast float %3073, %21
  %3075 = fdiv fast float %3074, %3059
  %3076 = fdiv fast float %3070, %3059
  %3077 = fdiv fast float %3066, %3059
  %3078 = fsub fast float %3075, %18
  %3079 = fsub fast float %3076, %19
  %3080 = fsub fast float %3077, %20
  %3081 = fmul fast float %3078, %3078
  %3082 = fmul fast float %3079, %3079
  %3083 = fadd fast float %3082, %3081
  %3084 = fmul fast float %3080, %3080
  %3085 = fadd fast float %3083, %3084
  %3086 = call float @dx.op.unary.f32(i32 24, float %3085)  ; Sqrt(value)
  %3087 = fsub fast float %3086, %10
  %3088 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3087)  ; FMax(a,b)
  %3089 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %3089, label %3090, label %3113

; <label>:3090                                    ; preds = %3062
  %3091 = call float @dx.op.unary.f32(i32 6, float %3079)  ; FAbs(value)
  %3092 = fmul fast float %3091, %12
  %3093 = fcmp fast olt float %3092, 0x3F50624DE0000000
  br i1 %3093, label %3094, label %3097

; <label>:3094                                    ; preds = %3090
  %3095 = fmul fast float %3092, 5.000000e-01
  %3096 = fsub fast float 1.000000e+00, %3095
  br label %3102

; <label>:3097                                    ; preds = %3090
  %3098 = fmul fast float %3092, 0xBFF7154760000000
  %3099 = call float @dx.op.unary.f32(i32 21, float %3098)  ; Exp(value)
  %3100 = fsub fast float 1.000000e+00, %3099
  %3101 = fdiv fast float %3100, %3092
  br label %3102

; <label>:3102                                    ; preds = %3097, %3094
  %3103 = phi float [ %3096, %3094 ], [ %3101, %3097 ]
  %3104 = call float @dx.op.binary.f32(i32 36, float %3076, float %19)  ; FMin(a,b)
  %3105 = fsub fast float %3104, %11
  %3106 = fmul fast float %12, %3105
  %3107 = fsub fast float -0.000000e+00, %3106
  %3108 = call float @dx.op.binary.f32(i32 35, float %3107, float -4.000000e+01)  ; FMax(a,b)
  %3109 = call float @dx.op.binary.f32(i32 36, float %3108, float 5.000000e+00)  ; FMin(a,b)
  %3110 = fmul fast float %3109, 0x3FF7154760000000
  %3111 = call float @dx.op.unary.f32(i32 21, float %3110)  ; Exp(value)
  %3112 = fmul fast float %3111, %3103
  br label %3113

; <label>:3113                                    ; preds = %3102, %3062
  %3114 = phi float [ %3112, %3102 ], [ 1.000000e+00, %3062 ]
  %3115 = fmul fast float %3088, %17
  %3116 = fmul fast float %3115, %3114
  %3117 = fcmp fast ole float %3086, %10
  %3118 = fcmp fast olt float %3086, 0x3F1A36E2E0000000
  %3119 = or i1 %3117, %3118
  br i1 %3119, label %3166, label %3120

; <label>:3120                                    ; preds = %3113
  %3121 = fdiv fast float %10, %3086
  %3122 = fmul fast float %3121, %3078
  %3123 = fmul fast float %3121, %3079
  %3124 = fmul fast float %3121, %3080
  %3125 = fadd fast float %3122, %18
  %3126 = fadd fast float %3123, %19
  %3127 = fadd fast float %3124, %20
  %3128 = fadd fast float %3125, -9.000000e+02
  %3129 = fadd fast float %3126, -1.500000e+01
  %3130 = fadd fast float %3127, -7.500000e+02
  %3131 = fmul fast float %3128, 0x3F62345680000000
  %3132 = fmul fast float %3129, 0x3F62345680000000
  %3133 = fmul fast float %3130, 0x3F62345680000000
  %3134 = call float @dx.op.dot3.f32(i32 55, float %3131, float %3132, float %3133, float %3131, float %3132, float %3133)  ; Dot3(ax,ay,az,bx,by,bz)
  %3135 = fsub fast float 1.000000e+00, %3134
  %3136 = call float @dx.op.unary.f32(i32 7, float %3135)  ; Saturate(value)
  %3137 = fmul fast float %3136, %3136
  %3138 = fadd fast float %3125, %3075
  %3139 = fadd fast float %3126, %3076
  %3140 = fadd fast float %3127, %3077
  %3141 = fmul fast float %3138, 0x3F52345680000000
  %3142 = fadd fast float %3141, -2.000000e+00
  %3143 = fmul fast float %3139, 0x3F52345680000000
  %3144 = fadd fast float %3143, 0xBFA1111120000000
  %3145 = fmul fast float %3140, 0x3F52345680000000
  %3146 = fadd fast float %3145, 0xBFFAAAAAC0000000
  %3147 = call float @dx.op.dot3.f32(i32 55, float %3142, float %3144, float %3146, float %3142, float %3144, float %3146)  ; Dot3(ax,ay,az,bx,by,bz)
  %3148 = fsub fast float 1.000000e+00, %3147
  %3149 = call float @dx.op.unary.f32(i32 7, float %3148)  ; Saturate(value)
  %3150 = fmul fast float %3149, %3149
  %3151 = fmul fast float %3150, 4.000000e+00
  %3152 = fadd fast float %3151, %3137
  %3153 = fadd fast float %3075, -9.000000e+02
  %3154 = fadd fast float %3076, -1.500000e+01
  %3155 = fadd fast float %3077, -7.500000e+02
  %3156 = fmul fast float %3153, 0x3F62345680000000
  %3157 = fmul fast float %3154, 0x3F62345680000000
  %3158 = fmul fast float %3155, 0x3F62345680000000
  %3159 = call float @dx.op.dot3.f32(i32 55, float %3156, float %3157, float %3158, float %3156, float %3157, float %3158)  ; Dot3(ax,ay,az,bx,by,bz)
  %3160 = fsub fast float 1.000000e+00, %3159
  %3161 = call float @dx.op.unary.f32(i32 7, float %3160)  ; Saturate(value)
  %3162 = fmul fast float %3161, %3161
  %3163 = fadd fast float %3152, %3162
  %3164 = fmul fast float %3087, 0x3F25D867E0000000
  %3165 = fmul fast float %3164, %3163
  br label %3166

; <label>:3166                                    ; preds = %3120, %3113
  %3167 = phi float [ %3165, %3120 ], [ 0.000000e+00, %3113 ]
  %3168 = fadd fast float %3167, %3116
  %3169 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3168)  ; FMin(a,b)
  %3170 = fmul fast float %3169, 0xBFF7154760000000
  %3171 = call float @dx.op.unary.f32(i32 21, float %3170)  ; Exp(value)
  %3172 = fsub fast float 1.000000e+00, %3171
  %3173 = call float @dx.op.binary.f32(i32 36, float %13, float %3172)  ; FMin(a,b)
  %3174 = fsub fast float %14, %3000
  %3175 = fsub fast float %15, %3001
  %3176 = fsub fast float %16, %3002
  %3177 = fmul fast float %3173, %3174
  %3178 = fmul fast float %3173, %3175
  %3179 = fmul fast float %3173, %3176
  %3180 = fadd fast float %3177, %3000
  %3181 = fadd fast float %3178, %3001
  %3182 = fadd fast float %3179, %3002
  br label %3183

; <label>:3183                                    ; preds = %3166, %3045, %3039
  %3184 = phi float [ %3180, %3166 ], [ %3000, %3045 ], [ %3000, %3039 ]
  %3185 = phi float [ %3181, %3166 ], [ %3001, %3045 ], [ %3001, %3039 ]
  %3186 = phi float [ %3182, %3166 ], [ %3002, %3045 ], [ %3002, %3039 ]
  %3187 = fadd fast float %6, 1.000000e+00
  %3188 = fadd fast float %7, 1.000000e+00
  %3189 = fsub fast float 1.000000e+00, %6
  %3190 = fmul fast float %37, %3187
  %3191 = fmul fast float %37, %3188
  %3192 = fmul fast float %37, %3189
  %3193 = fmul fast float %3190, %3184
  %3194 = fmul fast float %3191, %3185
  %3195 = fmul fast float %3192, %3186
  %3196 = fcmp fast ult float %38, 5.000000e-01
  br i1 %3196, label %3222, label %3197

; <label>:3197                                    ; preds = %3183
  %3198 = fmul fast float %3193, 0x4004147AE0000000
  %3199 = fmul fast float %3194, 0x4004147AE0000000
  %3200 = fmul fast float %3195, 0x4004147AE0000000
  %3201 = fadd fast float %3198, 0x3F9EB851E0000000
  %3202 = fadd fast float %3199, 0x3F9EB851E0000000
  %3203 = fadd fast float %3200, 0x3F9EB851E0000000
  %3204 = fmul fast float %3201, %3193
  %3205 = fmul fast float %3202, %3194
  %3206 = fmul fast float %3203, %3195
  %3207 = fmul fast float %3193, 0x400370A3E0000000
  %3208 = fmul fast float %3194, 0x400370A3E0000000
  %3209 = fmul fast float %3195, 0x400370A3E0000000
  %3210 = fadd fast float %3207, 0x3FE2E147A0000000
  %3211 = fadd fast float %3208, 0x3FE2E147A0000000
  %3212 = fadd fast float %3209, 0x3FE2E147A0000000
  %3213 = fmul fast float %3210, %3193
  %3214 = fmul fast float %3211, %3194
  %3215 = fmul fast float %3212, %3195
  %3216 = fadd fast float %3213, 0x3FC1EB8520000000
  %3217 = fadd fast float %3214, 0x3FC1EB8520000000
  %3218 = fadd fast float %3215, 0x3FC1EB8520000000
  %3219 = fdiv fast float %3204, %3216
  %3220 = fdiv fast float %3205, %3217
  %3221 = fdiv fast float %3206, %3218
  br label %3222

; <label>:3222                                    ; preds = %3197, %3183
  %3223 = phi float [ %3219, %3197 ], [ %3193, %3183 ]
  %3224 = phi float [ %3220, %3197 ], [ %3194, %3183 ]
  %3225 = phi float [ %3221, %3197 ], [ %3195, %3183 ]
  %3226 = call float @dx.op.unary.f32(i32 7, float %3223)  ; Saturate(value)
  %3227 = call float @dx.op.unary.f32(i32 7, float %3224)  ; Saturate(value)
  %3228 = call float @dx.op.unary.f32(i32 7, float %3225)  ; Saturate(value)
  %3229 = call float @dx.op.dot3.f32(i32 55, float %3226, float %3227, float %3228, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3230 = fsub fast float %3226, %3229
  %3231 = fsub fast float %3227, %3229
  %3232 = fsub fast float %3228, %3229
  %3233 = fmul fast float %3230, %9
  %3234 = fmul fast float %3231, %9
  %3235 = fmul fast float %3232, %9
  %3236 = fadd fast float %3233, %3229
  %3237 = fadd fast float %3234, %3229
  %3238 = fadd fast float %3235, %3229
  %3239 = call float @dx.op.unary.f32(i32 7, float %3236)  ; Saturate(value)
  %3240 = call float @dx.op.unary.f32(i32 7, float %3237)  ; Saturate(value)
  %3241 = call float @dx.op.unary.f32(i32 7, float %3238)  ; Saturate(value)
  %3242 = fadd fast float %3239, 0xBFC70A3D80000000
  %3243 = fadd fast float %3240, 0xBFC70A3D80000000
  %3244 = fadd fast float %3241, 0xBFC70A3D80000000
  %3245 = fmul fast float %3242, %8
  %3246 = fmul fast float %3243, %8
  %3247 = fmul fast float %3244, %8
  %3248 = fadd fast float %3245, 0x3FC70A3D80000000
  %3249 = fadd fast float %3246, 0x3FC70A3D80000000
  %3250 = fadd fast float %3247, 0x3FC70A3D80000000
  %3251 = call float @dx.op.unary.f32(i32 7, float %3248)  ; Saturate(value)
  %3252 = call float @dx.op.unary.f32(i32 7, float %3249)  ; Saturate(value)
  %3253 = call float @dx.op.unary.f32(i32 7, float %3250)  ; Saturate(value)
  br label %3254

; <label>:3254                                    ; preds = %3222, %3005
  %3255 = phi float [ %3036, %3005 ], [ %3251, %3222 ]
  %3256 = phi float [ %3037, %3005 ], [ %3252, %3222 ]
  %3257 = phi float [ %3038, %3005 ], [ %3253, %3222 ]
  %3258 = fsub fast float %3255, %955
  %3259 = fsub fast float %3256, %956
  %3260 = fsub fast float %3257, %957
  %3261 = fmul fast float %3258, %2992
  %3262 = fmul fast float %3259, %2992
  %3263 = fmul fast float %3260, %2992
  %3264 = fadd fast float %3261, %955
  %3265 = fadd fast float %3262, %956
  %3266 = fadd fast float %3263, %957
  br label %3267

; <label>:3267                                    ; preds = %3254, %2979
  %3268 = phi float [ %3264, %3254 ], [ %955, %2979 ]
  %3269 = phi float [ %3265, %3254 ], [ %956, %2979 ]
  %3270 = phi float [ %3266, %3254 ], [ %957, %2979 ]
  %3271 = fsub fast float %83, %87
  %3272 = call float @dx.op.unary.f32(i32 6, float %3271)  ; FAbs(value)
  %3273 = fdiv fast float %3272, %2674
  %3274 = fsub fast float 1.000000e+00, %3273
  %3275 = call float @dx.op.unary.f32(i32 7, float %3274)  ; Saturate(value)
  %3276 = fcmp fast ugt float %3275, 0.000000e+00
  br i1 %3276, label %3277, label %3287

; <label>:3277                                    ; preds = %3267
  %3278 = fsub fast float %447, %955
  %3279 = fsub fast float %448, %956
  %3280 = fsub fast float %449, %957
  %3281 = fmul fast float %3275, %3278
  %3282 = fmul fast float %3275, %3279
  %3283 = fmul fast float %3275, %3280
  %3284 = fadd fast float %3281, %955
  %3285 = fadd fast float %3282, %956
  %3286 = fadd fast float %3283, %957
  br label %3287

; <label>:3287                                    ; preds = %3277, %3267
  %3288 = phi float [ %3284, %3277 ], [ %955, %3267 ]
  %3289 = phi float [ %3285, %3277 ], [ %956, %3267 ]
  %3290 = phi float [ %3286, %3277 ], [ %957, %3267 ]
  %3291 = call float @dx.op.binary.f32(i32 36, float %2980, float %2692)  ; FMin(a,b)
  %3292 = call float @dx.op.binary.f32(i32 36, float %2981, float %2693)  ; FMin(a,b)
  %3293 = call float @dx.op.binary.f32(i32 36, float %2982, float %2694)  ; FMin(a,b)
  %3294 = call float @dx.op.binary.f32(i32 36, float %3288, float %3268)  ; FMin(a,b)
  %3295 = call float @dx.op.binary.f32(i32 36, float %3289, float %3269)  ; FMin(a,b)
  %3296 = call float @dx.op.binary.f32(i32 36, float %3290, float %3270)  ; FMin(a,b)
  %3297 = call float @dx.op.binary.f32(i32 36, float %3294, float %3291)  ; FMin(a,b)
  %3298 = call float @dx.op.binary.f32(i32 36, float %3295, float %3292)  ; FMin(a,b)
  %3299 = call float @dx.op.binary.f32(i32 36, float %3296, float %3293)  ; FMin(a,b)
  %3300 = call float @dx.op.binary.f32(i32 36, float %955, float %3297)  ; FMin(a,b)
  %3301 = call float @dx.op.binary.f32(i32 36, float %956, float %3298)  ; FMin(a,b)
  %3302 = call float @dx.op.binary.f32(i32 36, float %957, float %3299)  ; FMin(a,b)
  %3303 = call float @dx.op.binary.f32(i32 35, float %2980, float %2692)  ; FMax(a,b)
  %3304 = call float @dx.op.binary.f32(i32 35, float %2981, float %2693)  ; FMax(a,b)
  %3305 = call float @dx.op.binary.f32(i32 35, float %2982, float %2694)  ; FMax(a,b)
  %3306 = call float @dx.op.binary.f32(i32 35, float %3288, float %3268)  ; FMax(a,b)
  %3307 = call float @dx.op.binary.f32(i32 35, float %3289, float %3269)  ; FMax(a,b)
  %3308 = call float @dx.op.binary.f32(i32 35, float %3290, float %3270)  ; FMax(a,b)
  %3309 = call float @dx.op.binary.f32(i32 35, float %3306, float %3303)  ; FMax(a,b)
  %3310 = call float @dx.op.binary.f32(i32 35, float %3307, float %3304)  ; FMax(a,b)
  %3311 = call float @dx.op.binary.f32(i32 35, float %3308, float %3305)  ; FMax(a,b)
  %3312 = call float @dx.op.binary.f32(i32 35, float %955, float %3309)  ; FMax(a,b)
  %3313 = call float @dx.op.binary.f32(i32 35, float %956, float %3310)  ; FMax(a,b)
  %3314 = call float @dx.op.binary.f32(i32 35, float %957, float %3311)  ; FMax(a,b)
  %3315 = fsub fast float %3312, %3300
  %3316 = fsub fast float %3313, %3301
  %3317 = fsub fast float %3314, %3302
  %3318 = call float @dx.op.unary.f32(i32 6, float %3315)  ; FAbs(value)
  %3319 = call float @dx.op.unary.f32(i32 6, float %3316)  ; FAbs(value)
  %3320 = call float @dx.op.unary.f32(i32 6, float %3317)  ; FAbs(value)
  %3321 = call float @dx.op.binary.f32(i32 35, float %3319, float %3320)  ; FMax(a,b)
  %3322 = call float @dx.op.binary.f32(i32 35, float %3318, float %3321)  ; FMax(a,b)
  %3323 = call float @dx.op.binary.f32(i32 35, float %3313, float %3314)  ; FMax(a,b)
  %3324 = call float @dx.op.binary.f32(i32 35, float %3312, float %3323)  ; FMax(a,b)
  %3325 = fmul fast float %3324, 1.250000e-01
  %3326 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %3325)  ; FMax(a,b)
  %3327 = fcmp fast ogt float %3322, %3326
  br i1 %3327, label %3328, label %3390

; <label>:3328                                    ; preds = %3287
  %3329 = fsub fast float %3288, %3268
  %3330 = fsub fast float %3289, %3269
  %3331 = fsub fast float %3290, %3270
  %3332 = call float @dx.op.unary.f32(i32 6, float %3329)  ; FAbs(value)
  %3333 = call float @dx.op.unary.f32(i32 6, float %3330)  ; FAbs(value)
  %3334 = call float @dx.op.unary.f32(i32 6, float %3331)  ; FAbs(value)
  %3335 = call float @dx.op.binary.f32(i32 35, float %3333, float %3334)  ; FMax(a,b)
  %3336 = call float @dx.op.binary.f32(i32 35, float %3332, float %3335)  ; FMax(a,b)
  %3337 = fsub fast float %2980, %2692
  %3338 = fsub fast float %2981, %2693
  %3339 = fsub fast float %2982, %2694
  %3340 = call float @dx.op.unary.f32(i32 6, float %3337)  ; FAbs(value)
  %3341 = call float @dx.op.unary.f32(i32 6, float %3338)  ; FAbs(value)
  %3342 = call float @dx.op.unary.f32(i32 6, float %3339)  ; FAbs(value)
  %3343 = call float @dx.op.binary.f32(i32 35, float %3341, float %3342)  ; FMax(a,b)
  %3344 = call float @dx.op.binary.f32(i32 35, float %3340, float %3343)  ; FMax(a,b)
  %3345 = fcmp fast olt float %3336, %3344
  %3346 = select i1 %3345, float %3288, float %2980
  %3347 = select i1 %3345, float %3289, float %2981
  %3348 = select i1 %3345, float %3290, float %2982
  %3349 = select i1 %3345, float %3268, float %2692
  %3350 = select i1 %3345, float %3269, float %2693
  %3351 = select i1 %3345, float %3270, float %2694
  %3352 = fsub fast float %955, %3349
  %3353 = fsub fast float %956, %3350
  %3354 = fsub fast float %957, %3351
  %3355 = fsub fast float %955, %3346
  %3356 = fsub fast float %956, %3347
  %3357 = fsub fast float %957, %3348
  %3358 = call float @dx.op.dot3.f32(i32 55, float %3355, float %3356, float %3357, float %3352, float %3353, float %3354)  ; Dot3(ax,ay,az,bx,by,bz)
  %3359 = fcmp fast ogt float %3358, 0.000000e+00
  br i1 %3359, label %3360, label %3371

; <label>:3360                                    ; preds = %3328
  %3361 = fsub fast float %3346, %3349
  %3362 = fsub fast float %3347, %3350
  %3363 = fsub fast float %3348, %3351
  %3364 = call float @dx.op.unary.f32(i32 6, float %3361)  ; FAbs(value)
  %3365 = call float @dx.op.unary.f32(i32 6, float %3362)  ; FAbs(value)
  %3366 = call float @dx.op.unary.f32(i32 6, float %3363)  ; FAbs(value)
  %3367 = call float @dx.op.binary.f32(i32 35, float %3365, float %3366)  ; FMax(a,b)
  %3368 = call float @dx.op.binary.f32(i32 35, float %3364, float %3367)  ; FMax(a,b)
  %3369 = fmul fast float %3322, 2.500000e-01
  %3370 = fcmp fast olt float %3368, %3369
  br label %3371

; <label>:3371                                    ; preds = %3360, %3328
  %3372 = phi i1 [ false, %3328 ], [ %3370, %3360 ]
  %3373 = select i1 %3372, float 5.000000e-01, float 1.000000e+00
  %3374 = fmul fast float %3373, %3
  %3375 = fadd fast float %3346, %3349
  %3376 = fadd fast float %3347, %3350
  %3377 = fadd fast float %3348, %3351
  %3378 = fmul fast float %3375, 5.000000e-01
  %3379 = fmul fast float %3376, 5.000000e-01
  %3380 = fmul fast float %3377, 5.000000e-01
  %3381 = fsub fast float %3378, %955
  %3382 = fsub fast float %3379, %956
  %3383 = fsub fast float %3380, %957
  %3384 = fmul fast float %3374, %3381
  %3385 = fmul fast float %3374, %3382
  %3386 = fmul fast float %3374, %3383
  %3387 = fadd fast float %3384, %955
  %3388 = fadd fast float %3385, %956
  %3389 = fadd fast float %3386, %957
  br label %3390

; <label>:3390                                    ; preds = %3371, %3287, %2666
  %3391 = phi float [ %955, %2666 ], [ %3387, %3371 ], [ %955, %3287 ]
  %3392 = phi float [ %956, %2666 ], [ %3388, %3371 ], [ %956, %3287 ]
  %3393 = phi float [ %957, %2666 ], [ %3389, %3371 ], [ %957, %3287 ]
  %3394 = fcmp fast ult float %195, 0.000000e+00
  br i1 %3394, label %10186, label %3395

; <label>:3395                                    ; preds = %3390
  %3396 = add i32 %56, 2
  %3397 = call i32 @dx.op.binary.i32(i32 37, i32 %3396, i32 0)  ; IMax(a,b)
  %3398 = call i32 @dx.op.binary.i32(i32 38, i32 %3397, i32 %60)  ; IMin(a,b)
  %3399 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3398, i32 %71, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3400 = extractvalue %dx.types.ResRet.f32 %3399, 0
  %3401 = fsub fast float 1.000000e+00, %89
  %3402 = fmul fast float %3401, 0x3FA99999A0000000
  %3403 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %3402)  ; FMax(a,b)
  %3404 = fsub fast float %3400, %89
  %3405 = call float @dx.op.unary.f32(i32 6, float %3404)  ; FAbs(value)
  %3406 = fdiv fast float %3405, %3403
  %3407 = fsub fast float 1.000000e+00, %3406
  %3408 = call float @dx.op.unary.f32(i32 7, float %3407)  ; Saturate(value)
  %3409 = fcmp fast ugt float %3408, 0.000000e+00
  br i1 %3409, label %3410, label %3683

; <label>:3410                                    ; preds = %3395
  %3411 = call i32 @dx.op.binary.i32(i32 37, i32 %3398, i32 0)  ; IMax(a,b)
  %3412 = call i32 @dx.op.binary.i32(i32 37, i32 %71, i32 0)  ; IMax(a,b)
  %3413 = call i32 @dx.op.binary.i32(i32 38, i32 %3411, i32 %60)  ; IMin(a,b)
  %3414 = call i32 @dx.op.binary.i32(i32 38, i32 %3412, i32 %61)  ; IMin(a,b)
  %3415 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3413, i32 %3414, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3416 = extractvalue %dx.types.ResRet.f32 %3415, 0
  %3417 = extractvalue %dx.types.ResRet.f32 %3415, 1
  %3418 = extractvalue %dx.types.ResRet.f32 %3415, 2
  %3419 = extractvalue %dx.types.ResRet.f32 %3415, 3
  %3420 = fcmp fast olt float %3419, 0.000000e+00
  br i1 %3420, label %3421, label %3455

; <label>:3421                                    ; preds = %3410
  %3422 = fcmp fast ogt float %3416, 0x3FA4B5DCC0000000
  %3423 = fcmp fast ogt float %3417, 0x3FA4B5DCC0000000
  %3424 = fcmp fast ogt float %3418, 0x3FA4B5DCC0000000
  %3425 = select i1 %3422, float 0.000000e+00, float 1.000000e+00
  %3426 = select i1 %3423, float 0.000000e+00, float 1.000000e+00
  %3427 = select i1 %3424, float 0.000000e+00, float 1.000000e+00
  %3428 = fmul fast float %3416, 0x3FB3D07220000000
  %3429 = fmul fast float %3417, 0x3FB3D07220000000
  %3430 = fmul fast float %3418, 0x3FB3D07220000000
  %3431 = fadd fast float %3416, 0x3FAC28F5C0000000
  %3432 = fadd fast float %3417, 0x3FAC28F5C0000000
  %3433 = fadd fast float %3418, 0x3FAC28F5C0000000
  %3434 = fmul fast float %3431, 0x3FEE54EDE0000000
  %3435 = fmul fast float %3432, 0x3FEE54EDE0000000
  %3436 = fmul fast float %3433, 0x3FEE54EDE0000000
  %3437 = call float @dx.op.unary.f32(i32 23, float %3434)  ; Log(value)
  %3438 = call float @dx.op.unary.f32(i32 23, float %3435)  ; Log(value)
  %3439 = call float @dx.op.unary.f32(i32 23, float %3436)  ; Log(value)
  %3440 = fmul fast float %3437, 0x4003333340000000
  %3441 = fmul fast float %3438, 0x4003333340000000
  %3442 = fmul fast float %3439, 0x4003333340000000
  %3443 = call float @dx.op.unary.f32(i32 21, float %3440)  ; Exp(value)
  %3444 = call float @dx.op.unary.f32(i32 21, float %3441)  ; Exp(value)
  %3445 = call float @dx.op.unary.f32(i32 21, float %3442)  ; Exp(value)
  %3446 = fsub fast float %3428, %3443
  %3447 = fsub fast float %3429, %3444
  %3448 = fsub fast float %3430, %3445
  %3449 = fmul fast float %3446, %3425
  %3450 = fmul fast float %3447, %3426
  %3451 = fmul fast float %3448, %3427
  %3452 = fadd fast float %3449, %3443
  %3453 = fadd fast float %3450, %3444
  %3454 = fadd fast float %3451, %3445
  br label %3670

; <label>:3455                                    ; preds = %3410
  %3456 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3413, i32 %3414, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3457 = extractvalue %dx.types.ResRet.f32 %3456, 0
  %3458 = fcmp fast ogt float %39, 5.000000e-01
  %3459 = fcmp fast olt float %3457, 1.000000e+00
  %3460 = and i1 %3458, %3459
  br i1 %3460, label %3461, label %3599

; <label>:3461                                    ; preds = %3455
  %3462 = sitofp i32 %3413 to float
  %3463 = sitofp i32 %3414 to float
  %3464 = fadd fast float %3462, 5.000000e-01
  %3465 = fadd fast float %3463, 5.000000e-01
  %3466 = fdiv fast float %3464, %46
  %3467 = fdiv fast float %3465, %47
  %3468 = fmul fast float %3466, 2.000000e+00
  %3469 = fmul fast float %3467, 2.000000e+00
  %3470 = fadd fast float %3468, -1.000000e+00
  %3471 = fsub fast float 1.000000e+00, %3469
  %3472 = fmul fast float %3470, %36
  %3473 = call float @dx.op.tertiary.f32(i32 46, float %3471, float %32, float %3472)  ; FMad(a,b,c)
  %3474 = call float @dx.op.tertiary.f32(i32 46, float %3457, float %28, float %3473)  ; FMad(a,b,c)
  %3475 = fadd fast float %3474, %24
  %3476 = call float @dx.op.unary.f32(i32 6, float %3475)  ; FAbs(value)
  %3477 = fcmp fast ogt float %3476, 0x3EB0C6F7A0000000
  br i1 %3477, label %3478, label %3599

; <label>:3478                                    ; preds = %3461
  %3479 = fmul fast float %3470, %35
  %3480 = call float @dx.op.tertiary.f32(i32 46, float %3471, float %31, float %3479)  ; FMad(a,b,c)
  %3481 = call float @dx.op.tertiary.f32(i32 46, float %3457, float %27, float %3480)  ; FMad(a,b,c)
  %3482 = fadd fast float %3481, %23
  %3483 = fmul fast float %3470, %34
  %3484 = call float @dx.op.tertiary.f32(i32 46, float %3471, float %30, float %3483)  ; FMad(a,b,c)
  %3485 = call float @dx.op.tertiary.f32(i32 46, float %3457, float %26, float %3484)  ; FMad(a,b,c)
  %3486 = fadd fast float %3485, %22
  %3487 = fmul fast float %3470, %33
  %3488 = call float @dx.op.tertiary.f32(i32 46, float %3471, float %29, float %3487)  ; FMad(a,b,c)
  %3489 = call float @dx.op.tertiary.f32(i32 46, float %3457, float %25, float %3488)  ; FMad(a,b,c)
  %3490 = fadd fast float %3489, %21
  %3491 = fdiv fast float %3490, %3475
  %3492 = fdiv fast float %3486, %3475
  %3493 = fdiv fast float %3482, %3475
  %3494 = fsub fast float %3491, %18
  %3495 = fsub fast float %3492, %19
  %3496 = fsub fast float %3493, %20
  %3497 = fmul fast float %3494, %3494
  %3498 = fmul fast float %3495, %3495
  %3499 = fadd fast float %3498, %3497
  %3500 = fmul fast float %3496, %3496
  %3501 = fadd fast float %3499, %3500
  %3502 = call float @dx.op.unary.f32(i32 24, float %3501)  ; Sqrt(value)
  %3503 = fsub fast float %3502, %10
  %3504 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3503)  ; FMax(a,b)
  %3505 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %3505, label %3506, label %3529

; <label>:3506                                    ; preds = %3478
  %3507 = call float @dx.op.unary.f32(i32 6, float %3495)  ; FAbs(value)
  %3508 = fmul fast float %3507, %12
  %3509 = fcmp fast olt float %3508, 0x3F50624DE0000000
  br i1 %3509, label %3510, label %3513

; <label>:3510                                    ; preds = %3506
  %3511 = fmul fast float %3508, 5.000000e-01
  %3512 = fsub fast float 1.000000e+00, %3511
  br label %3518

; <label>:3513                                    ; preds = %3506
  %3514 = fmul fast float %3508, 0xBFF7154760000000
  %3515 = call float @dx.op.unary.f32(i32 21, float %3514)  ; Exp(value)
  %3516 = fsub fast float 1.000000e+00, %3515
  %3517 = fdiv fast float %3516, %3508
  br label %3518

; <label>:3518                                    ; preds = %3513, %3510
  %3519 = phi float [ %3512, %3510 ], [ %3517, %3513 ]
  %3520 = call float @dx.op.binary.f32(i32 36, float %3492, float %19)  ; FMin(a,b)
  %3521 = fsub fast float %3520, %11
  %3522 = fmul fast float %12, %3521
  %3523 = fsub fast float -0.000000e+00, %3522
  %3524 = call float @dx.op.binary.f32(i32 35, float %3523, float -4.000000e+01)  ; FMax(a,b)
  %3525 = call float @dx.op.binary.f32(i32 36, float %3524, float 5.000000e+00)  ; FMin(a,b)
  %3526 = fmul fast float %3525, 0x3FF7154760000000
  %3527 = call float @dx.op.unary.f32(i32 21, float %3526)  ; Exp(value)
  %3528 = fmul fast float %3527, %3519
  br label %3529

; <label>:3529                                    ; preds = %3518, %3478
  %3530 = phi float [ %3528, %3518 ], [ 1.000000e+00, %3478 ]
  %3531 = fmul fast float %3504, %17
  %3532 = fmul fast float %3531, %3530
  %3533 = fcmp fast ole float %3502, %10
  %3534 = fcmp fast olt float %3502, 0x3F1A36E2E0000000
  %3535 = or i1 %3533, %3534
  br i1 %3535, label %3582, label %3536

; <label>:3536                                    ; preds = %3529
  %3537 = fdiv fast float %10, %3502
  %3538 = fmul fast float %3537, %3494
  %3539 = fmul fast float %3537, %3495
  %3540 = fmul fast float %3537, %3496
  %3541 = fadd fast float %3538, %18
  %3542 = fadd fast float %3539, %19
  %3543 = fadd fast float %3540, %20
  %3544 = fadd fast float %3541, -9.000000e+02
  %3545 = fadd fast float %3542, -1.500000e+01
  %3546 = fadd fast float %3543, -7.500000e+02
  %3547 = fmul fast float %3544, 0x3F62345680000000
  %3548 = fmul fast float %3545, 0x3F62345680000000
  %3549 = fmul fast float %3546, 0x3F62345680000000
  %3550 = call float @dx.op.dot3.f32(i32 55, float %3547, float %3548, float %3549, float %3547, float %3548, float %3549)  ; Dot3(ax,ay,az,bx,by,bz)
  %3551 = fsub fast float 1.000000e+00, %3550
  %3552 = call float @dx.op.unary.f32(i32 7, float %3551)  ; Saturate(value)
  %3553 = fmul fast float %3552, %3552
  %3554 = fadd fast float %3541, %3491
  %3555 = fadd fast float %3542, %3492
  %3556 = fadd fast float %3543, %3493
  %3557 = fmul fast float %3554, 0x3F52345680000000
  %3558 = fadd fast float %3557, -2.000000e+00
  %3559 = fmul fast float %3555, 0x3F52345680000000
  %3560 = fadd fast float %3559, 0xBFA1111120000000
  %3561 = fmul fast float %3556, 0x3F52345680000000
  %3562 = fadd fast float %3561, 0xBFFAAAAAC0000000
  %3563 = call float @dx.op.dot3.f32(i32 55, float %3558, float %3560, float %3562, float %3558, float %3560, float %3562)  ; Dot3(ax,ay,az,bx,by,bz)
  %3564 = fsub fast float 1.000000e+00, %3563
  %3565 = call float @dx.op.unary.f32(i32 7, float %3564)  ; Saturate(value)
  %3566 = fmul fast float %3565, %3565
  %3567 = fmul fast float %3566, 4.000000e+00
  %3568 = fadd fast float %3567, %3553
  %3569 = fadd fast float %3491, -9.000000e+02
  %3570 = fadd fast float %3492, -1.500000e+01
  %3571 = fadd fast float %3493, -7.500000e+02
  %3572 = fmul fast float %3569, 0x3F62345680000000
  %3573 = fmul fast float %3570, 0x3F62345680000000
  %3574 = fmul fast float %3571, 0x3F62345680000000
  %3575 = call float @dx.op.dot3.f32(i32 55, float %3572, float %3573, float %3574, float %3572, float %3573, float %3574)  ; Dot3(ax,ay,az,bx,by,bz)
  %3576 = fsub fast float 1.000000e+00, %3575
  %3577 = call float @dx.op.unary.f32(i32 7, float %3576)  ; Saturate(value)
  %3578 = fmul fast float %3577, %3577
  %3579 = fadd fast float %3568, %3578
  %3580 = fmul fast float %3503, 0x3F25D867E0000000
  %3581 = fmul fast float %3580, %3579
  br label %3582

; <label>:3582                                    ; preds = %3536, %3529
  %3583 = phi float [ %3581, %3536 ], [ 0.000000e+00, %3529 ]
  %3584 = fadd fast float %3583, %3532
  %3585 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3584)  ; FMin(a,b)
  %3586 = fmul fast float %3585, 0xBFF7154760000000
  %3587 = call float @dx.op.unary.f32(i32 21, float %3586)  ; Exp(value)
  %3588 = fsub fast float 1.000000e+00, %3587
  %3589 = call float @dx.op.binary.f32(i32 36, float %13, float %3588)  ; FMin(a,b)
  %3590 = fsub fast float %14, %3416
  %3591 = fsub fast float %15, %3417
  %3592 = fsub fast float %16, %3418
  %3593 = fmul fast float %3589, %3590
  %3594 = fmul fast float %3589, %3591
  %3595 = fmul fast float %3589, %3592
  %3596 = fadd fast float %3593, %3416
  %3597 = fadd fast float %3594, %3417
  %3598 = fadd fast float %3595, %3418
  br label %3599

; <label>:3599                                    ; preds = %3582, %3461, %3455
  %3600 = phi float [ %3596, %3582 ], [ %3416, %3461 ], [ %3416, %3455 ]
  %3601 = phi float [ %3597, %3582 ], [ %3417, %3461 ], [ %3417, %3455 ]
  %3602 = phi float [ %3598, %3582 ], [ %3418, %3461 ], [ %3418, %3455 ]
  %3603 = fadd fast float %6, 1.000000e+00
  %3604 = fadd fast float %7, 1.000000e+00
  %3605 = fsub fast float 1.000000e+00, %6
  %3606 = fmul fast float %37, %3603
  %3607 = fmul fast float %37, %3604
  %3608 = fmul fast float %37, %3605
  %3609 = fmul fast float %3606, %3600
  %3610 = fmul fast float %3607, %3601
  %3611 = fmul fast float %3608, %3602
  %3612 = fcmp fast ult float %38, 5.000000e-01
  br i1 %3612, label %3638, label %3613

; <label>:3613                                    ; preds = %3599
  %3614 = fmul fast float %3609, 0x4004147AE0000000
  %3615 = fmul fast float %3610, 0x4004147AE0000000
  %3616 = fmul fast float %3611, 0x4004147AE0000000
  %3617 = fadd fast float %3614, 0x3F9EB851E0000000
  %3618 = fadd fast float %3615, 0x3F9EB851E0000000
  %3619 = fadd fast float %3616, 0x3F9EB851E0000000
  %3620 = fmul fast float %3617, %3609
  %3621 = fmul fast float %3618, %3610
  %3622 = fmul fast float %3619, %3611
  %3623 = fmul fast float %3609, 0x400370A3E0000000
  %3624 = fmul fast float %3610, 0x400370A3E0000000
  %3625 = fmul fast float %3611, 0x400370A3E0000000
  %3626 = fadd fast float %3623, 0x3FE2E147A0000000
  %3627 = fadd fast float %3624, 0x3FE2E147A0000000
  %3628 = fadd fast float %3625, 0x3FE2E147A0000000
  %3629 = fmul fast float %3626, %3609
  %3630 = fmul fast float %3627, %3610
  %3631 = fmul fast float %3628, %3611
  %3632 = fadd fast float %3629, 0x3FC1EB8520000000
  %3633 = fadd fast float %3630, 0x3FC1EB8520000000
  %3634 = fadd fast float %3631, 0x3FC1EB8520000000
  %3635 = fdiv fast float %3620, %3632
  %3636 = fdiv fast float %3621, %3633
  %3637 = fdiv fast float %3622, %3634
  br label %3638

; <label>:3638                                    ; preds = %3613, %3599
  %3639 = phi float [ %3635, %3613 ], [ %3609, %3599 ]
  %3640 = phi float [ %3636, %3613 ], [ %3610, %3599 ]
  %3641 = phi float [ %3637, %3613 ], [ %3611, %3599 ]
  %3642 = call float @dx.op.unary.f32(i32 7, float %3639)  ; Saturate(value)
  %3643 = call float @dx.op.unary.f32(i32 7, float %3640)  ; Saturate(value)
  %3644 = call float @dx.op.unary.f32(i32 7, float %3641)  ; Saturate(value)
  %3645 = call float @dx.op.dot3.f32(i32 55, float %3642, float %3643, float %3644, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3646 = fsub fast float %3642, %3645
  %3647 = fsub fast float %3643, %3645
  %3648 = fsub fast float %3644, %3645
  %3649 = fmul fast float %3646, %9
  %3650 = fmul fast float %3647, %9
  %3651 = fmul fast float %3648, %9
  %3652 = fadd fast float %3649, %3645
  %3653 = fadd fast float %3650, %3645
  %3654 = fadd fast float %3651, %3645
  %3655 = call float @dx.op.unary.f32(i32 7, float %3652)  ; Saturate(value)
  %3656 = call float @dx.op.unary.f32(i32 7, float %3653)  ; Saturate(value)
  %3657 = call float @dx.op.unary.f32(i32 7, float %3654)  ; Saturate(value)
  %3658 = fadd fast float %3655, 0xBFC70A3D80000000
  %3659 = fadd fast float %3656, 0xBFC70A3D80000000
  %3660 = fadd fast float %3657, 0xBFC70A3D80000000
  %3661 = fmul fast float %3658, %8
  %3662 = fmul fast float %3659, %8
  %3663 = fmul fast float %3660, %8
  %3664 = fadd fast float %3661, 0x3FC70A3D80000000
  %3665 = fadd fast float %3662, 0x3FC70A3D80000000
  %3666 = fadd fast float %3663, 0x3FC70A3D80000000
  %3667 = call float @dx.op.unary.f32(i32 7, float %3664)  ; Saturate(value)
  %3668 = call float @dx.op.unary.f32(i32 7, float %3665)  ; Saturate(value)
  %3669 = call float @dx.op.unary.f32(i32 7, float %3666)  ; Saturate(value)
  br label %3670

; <label>:3670                                    ; preds = %3638, %3421
  %3671 = phi float [ %3452, %3421 ], [ %3667, %3638 ]
  %3672 = phi float [ %3453, %3421 ], [ %3668, %3638 ]
  %3673 = phi float [ %3454, %3421 ], [ %3669, %3638 ]
  %3674 = fsub fast float %3671, %1209
  %3675 = fsub fast float %3672, %1210
  %3676 = fsub fast float %3673, %1211
  %3677 = fmul fast float %3674, %3408
  %3678 = fmul fast float %3675, %3408
  %3679 = fmul fast float %3676, %3408
  %3680 = fadd fast float %3677, %1209
  %3681 = fadd fast float %3678, %1210
  %3682 = fadd fast float %3679, %1211
  br label %3683

; <label>:3683                                    ; preds = %3670, %3395
  %3684 = phi float [ %3680, %3670 ], [ %1209, %3395 ]
  %3685 = phi float [ %3681, %3670 ], [ %1210, %3395 ]
  %3686 = phi float [ %3682, %3670 ], [ %1211, %3395 ]
  %3687 = fsub fast float %87, %89
  %3688 = call float @dx.op.unary.f32(i32 6, float %3687)  ; FAbs(value)
  %3689 = fdiv fast float %3688, %3403
  %3690 = fsub fast float 1.000000e+00, %3689
  %3691 = call float @dx.op.unary.f32(i32 7, float %3690)  ; Saturate(value)
  %3692 = fcmp fast ugt float %3691, 0.000000e+00
  br i1 %3692, label %3693, label %3703

; <label>:3693                                    ; preds = %3683
  %3694 = fsub fast float %955, %1209
  %3695 = fsub fast float %956, %1210
  %3696 = fsub fast float %957, %1211
  %3697 = fmul fast float %3691, %3694
  %3698 = fmul fast float %3691, %3695
  %3699 = fmul fast float %3691, %3696
  %3700 = fadd fast float %3697, %1209
  %3701 = fadd fast float %3698, %1210
  %3702 = fadd fast float %3699, %1211
  br label %3703

; <label>:3703                                    ; preds = %3693, %3683
  %3704 = phi float [ %3700, %3693 ], [ %1209, %3683 ]
  %3705 = phi float [ %3701, %3693 ], [ %1210, %3683 ]
  %3706 = phi float [ %3702, %3693 ], [ %1211, %3683 ]
  %3707 = add i32 %57, 2
  %3708 = call i32 @dx.op.binary.i32(i32 37, i32 %3707, i32 0)  ; IMax(a,b)
  %3709 = call i32 @dx.op.binary.i32(i32 38, i32 %3708, i32 %61)  ; IMin(a,b)
  %3710 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %68, i32 %3709, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3711 = extractvalue %dx.types.ResRet.f32 %3710, 0
  %3712 = fsub fast float %3711, %89
  %3713 = call float @dx.op.unary.f32(i32 6, float %3712)  ; FAbs(value)
  %3714 = fdiv fast float %3713, %3403
  %3715 = fsub fast float 1.000000e+00, %3714
  %3716 = call float @dx.op.unary.f32(i32 7, float %3715)  ; Saturate(value)
  %3717 = fcmp fast ugt float %3716, 0.000000e+00
  br i1 %3717, label %3718, label %3991

; <label>:3718                                    ; preds = %3703
  %3719 = call i32 @dx.op.binary.i32(i32 37, i32 %68, i32 0)  ; IMax(a,b)
  %3720 = call i32 @dx.op.binary.i32(i32 37, i32 %3709, i32 0)  ; IMax(a,b)
  %3721 = call i32 @dx.op.binary.i32(i32 38, i32 %3719, i32 %60)  ; IMin(a,b)
  %3722 = call i32 @dx.op.binary.i32(i32 38, i32 %3720, i32 %61)  ; IMin(a,b)
  %3723 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3721, i32 %3722, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3724 = extractvalue %dx.types.ResRet.f32 %3723, 0
  %3725 = extractvalue %dx.types.ResRet.f32 %3723, 1
  %3726 = extractvalue %dx.types.ResRet.f32 %3723, 2
  %3727 = extractvalue %dx.types.ResRet.f32 %3723, 3
  %3728 = fcmp fast olt float %3727, 0.000000e+00
  br i1 %3728, label %3729, label %3763

; <label>:3729                                    ; preds = %3718
  %3730 = fcmp fast ogt float %3724, 0x3FA4B5DCC0000000
  %3731 = fcmp fast ogt float %3725, 0x3FA4B5DCC0000000
  %3732 = fcmp fast ogt float %3726, 0x3FA4B5DCC0000000
  %3733 = select i1 %3730, float 0.000000e+00, float 1.000000e+00
  %3734 = select i1 %3731, float 0.000000e+00, float 1.000000e+00
  %3735 = select i1 %3732, float 0.000000e+00, float 1.000000e+00
  %3736 = fmul fast float %3724, 0x3FB3D07220000000
  %3737 = fmul fast float %3725, 0x3FB3D07220000000
  %3738 = fmul fast float %3726, 0x3FB3D07220000000
  %3739 = fadd fast float %3724, 0x3FAC28F5C0000000
  %3740 = fadd fast float %3725, 0x3FAC28F5C0000000
  %3741 = fadd fast float %3726, 0x3FAC28F5C0000000
  %3742 = fmul fast float %3739, 0x3FEE54EDE0000000
  %3743 = fmul fast float %3740, 0x3FEE54EDE0000000
  %3744 = fmul fast float %3741, 0x3FEE54EDE0000000
  %3745 = call float @dx.op.unary.f32(i32 23, float %3742)  ; Log(value)
  %3746 = call float @dx.op.unary.f32(i32 23, float %3743)  ; Log(value)
  %3747 = call float @dx.op.unary.f32(i32 23, float %3744)  ; Log(value)
  %3748 = fmul fast float %3745, 0x4003333340000000
  %3749 = fmul fast float %3746, 0x4003333340000000
  %3750 = fmul fast float %3747, 0x4003333340000000
  %3751 = call float @dx.op.unary.f32(i32 21, float %3748)  ; Exp(value)
  %3752 = call float @dx.op.unary.f32(i32 21, float %3749)  ; Exp(value)
  %3753 = call float @dx.op.unary.f32(i32 21, float %3750)  ; Exp(value)
  %3754 = fsub fast float %3736, %3751
  %3755 = fsub fast float %3737, %3752
  %3756 = fsub fast float %3738, %3753
  %3757 = fmul fast float %3754, %3733
  %3758 = fmul fast float %3755, %3734
  %3759 = fmul fast float %3756, %3735
  %3760 = fadd fast float %3757, %3751
  %3761 = fadd fast float %3758, %3752
  %3762 = fadd fast float %3759, %3753
  br label %3978

; <label>:3763                                    ; preds = %3718
  %3764 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3721, i32 %3722, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3765 = extractvalue %dx.types.ResRet.f32 %3764, 0
  %3766 = fcmp fast ogt float %39, 5.000000e-01
  %3767 = fcmp fast olt float %3765, 1.000000e+00
  %3768 = and i1 %3766, %3767
  br i1 %3768, label %3769, label %3907

; <label>:3769                                    ; preds = %3763
  %3770 = sitofp i32 %3721 to float
  %3771 = sitofp i32 %3722 to float
  %3772 = fadd fast float %3770, 5.000000e-01
  %3773 = fadd fast float %3771, 5.000000e-01
  %3774 = fdiv fast float %3772, %46
  %3775 = fdiv fast float %3773, %47
  %3776 = fmul fast float %3774, 2.000000e+00
  %3777 = fmul fast float %3775, 2.000000e+00
  %3778 = fadd fast float %3776, -1.000000e+00
  %3779 = fsub fast float 1.000000e+00, %3777
  %3780 = fmul fast float %3778, %36
  %3781 = call float @dx.op.tertiary.f32(i32 46, float %3779, float %32, float %3780)  ; FMad(a,b,c)
  %3782 = call float @dx.op.tertiary.f32(i32 46, float %3765, float %28, float %3781)  ; FMad(a,b,c)
  %3783 = fadd fast float %3782, %24
  %3784 = call float @dx.op.unary.f32(i32 6, float %3783)  ; FAbs(value)
  %3785 = fcmp fast ogt float %3784, 0x3EB0C6F7A0000000
  br i1 %3785, label %3786, label %3907

; <label>:3786                                    ; preds = %3769
  %3787 = fmul fast float %3778, %35
  %3788 = call float @dx.op.tertiary.f32(i32 46, float %3779, float %31, float %3787)  ; FMad(a,b,c)
  %3789 = call float @dx.op.tertiary.f32(i32 46, float %3765, float %27, float %3788)  ; FMad(a,b,c)
  %3790 = fadd fast float %3789, %23
  %3791 = fmul fast float %3778, %34
  %3792 = call float @dx.op.tertiary.f32(i32 46, float %3779, float %30, float %3791)  ; FMad(a,b,c)
  %3793 = call float @dx.op.tertiary.f32(i32 46, float %3765, float %26, float %3792)  ; FMad(a,b,c)
  %3794 = fadd fast float %3793, %22
  %3795 = fmul fast float %3778, %33
  %3796 = call float @dx.op.tertiary.f32(i32 46, float %3779, float %29, float %3795)  ; FMad(a,b,c)
  %3797 = call float @dx.op.tertiary.f32(i32 46, float %3765, float %25, float %3796)  ; FMad(a,b,c)
  %3798 = fadd fast float %3797, %21
  %3799 = fdiv fast float %3798, %3783
  %3800 = fdiv fast float %3794, %3783
  %3801 = fdiv fast float %3790, %3783
  %3802 = fsub fast float %3799, %18
  %3803 = fsub fast float %3800, %19
  %3804 = fsub fast float %3801, %20
  %3805 = fmul fast float %3802, %3802
  %3806 = fmul fast float %3803, %3803
  %3807 = fadd fast float %3806, %3805
  %3808 = fmul fast float %3804, %3804
  %3809 = fadd fast float %3807, %3808
  %3810 = call float @dx.op.unary.f32(i32 24, float %3809)  ; Sqrt(value)
  %3811 = fsub fast float %3810, %10
  %3812 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3811)  ; FMax(a,b)
  %3813 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %3813, label %3814, label %3837

; <label>:3814                                    ; preds = %3786
  %3815 = call float @dx.op.unary.f32(i32 6, float %3803)  ; FAbs(value)
  %3816 = fmul fast float %3815, %12
  %3817 = fcmp fast olt float %3816, 0x3F50624DE0000000
  br i1 %3817, label %3818, label %3821

; <label>:3818                                    ; preds = %3814
  %3819 = fmul fast float %3816, 5.000000e-01
  %3820 = fsub fast float 1.000000e+00, %3819
  br label %3826

; <label>:3821                                    ; preds = %3814
  %3822 = fmul fast float %3816, 0xBFF7154760000000
  %3823 = call float @dx.op.unary.f32(i32 21, float %3822)  ; Exp(value)
  %3824 = fsub fast float 1.000000e+00, %3823
  %3825 = fdiv fast float %3824, %3816
  br label %3826

; <label>:3826                                    ; preds = %3821, %3818
  %3827 = phi float [ %3820, %3818 ], [ %3825, %3821 ]
  %3828 = call float @dx.op.binary.f32(i32 36, float %3800, float %19)  ; FMin(a,b)
  %3829 = fsub fast float %3828, %11
  %3830 = fmul fast float %12, %3829
  %3831 = fsub fast float -0.000000e+00, %3830
  %3832 = call float @dx.op.binary.f32(i32 35, float %3831, float -4.000000e+01)  ; FMax(a,b)
  %3833 = call float @dx.op.binary.f32(i32 36, float %3832, float 5.000000e+00)  ; FMin(a,b)
  %3834 = fmul fast float %3833, 0x3FF7154760000000
  %3835 = call float @dx.op.unary.f32(i32 21, float %3834)  ; Exp(value)
  %3836 = fmul fast float %3835, %3827
  br label %3837

; <label>:3837                                    ; preds = %3826, %3786
  %3838 = phi float [ %3836, %3826 ], [ 1.000000e+00, %3786 ]
  %3839 = fmul fast float %3812, %17
  %3840 = fmul fast float %3839, %3838
  %3841 = fcmp fast ole float %3810, %10
  %3842 = fcmp fast olt float %3810, 0x3F1A36E2E0000000
  %3843 = or i1 %3841, %3842
  br i1 %3843, label %3890, label %3844

; <label>:3844                                    ; preds = %3837
  %3845 = fdiv fast float %10, %3810
  %3846 = fmul fast float %3845, %3802
  %3847 = fmul fast float %3845, %3803
  %3848 = fmul fast float %3845, %3804
  %3849 = fadd fast float %3846, %18
  %3850 = fadd fast float %3847, %19
  %3851 = fadd fast float %3848, %20
  %3852 = fadd fast float %3849, -9.000000e+02
  %3853 = fadd fast float %3850, -1.500000e+01
  %3854 = fadd fast float %3851, -7.500000e+02
  %3855 = fmul fast float %3852, 0x3F62345680000000
  %3856 = fmul fast float %3853, 0x3F62345680000000
  %3857 = fmul fast float %3854, 0x3F62345680000000
  %3858 = call float @dx.op.dot3.f32(i32 55, float %3855, float %3856, float %3857, float %3855, float %3856, float %3857)  ; Dot3(ax,ay,az,bx,by,bz)
  %3859 = fsub fast float 1.000000e+00, %3858
  %3860 = call float @dx.op.unary.f32(i32 7, float %3859)  ; Saturate(value)
  %3861 = fmul fast float %3860, %3860
  %3862 = fadd fast float %3849, %3799
  %3863 = fadd fast float %3850, %3800
  %3864 = fadd fast float %3851, %3801
  %3865 = fmul fast float %3862, 0x3F52345680000000
  %3866 = fadd fast float %3865, -2.000000e+00
  %3867 = fmul fast float %3863, 0x3F52345680000000
  %3868 = fadd fast float %3867, 0xBFA1111120000000
  %3869 = fmul fast float %3864, 0x3F52345680000000
  %3870 = fadd fast float %3869, 0xBFFAAAAAC0000000
  %3871 = call float @dx.op.dot3.f32(i32 55, float %3866, float %3868, float %3870, float %3866, float %3868, float %3870)  ; Dot3(ax,ay,az,bx,by,bz)
  %3872 = fsub fast float 1.000000e+00, %3871
  %3873 = call float @dx.op.unary.f32(i32 7, float %3872)  ; Saturate(value)
  %3874 = fmul fast float %3873, %3873
  %3875 = fmul fast float %3874, 4.000000e+00
  %3876 = fadd fast float %3875, %3861
  %3877 = fadd fast float %3799, -9.000000e+02
  %3878 = fadd fast float %3800, -1.500000e+01
  %3879 = fadd fast float %3801, -7.500000e+02
  %3880 = fmul fast float %3877, 0x3F62345680000000
  %3881 = fmul fast float %3878, 0x3F62345680000000
  %3882 = fmul fast float %3879, 0x3F62345680000000
  %3883 = call float @dx.op.dot3.f32(i32 55, float %3880, float %3881, float %3882, float %3880, float %3881, float %3882)  ; Dot3(ax,ay,az,bx,by,bz)
  %3884 = fsub fast float 1.000000e+00, %3883
  %3885 = call float @dx.op.unary.f32(i32 7, float %3884)  ; Saturate(value)
  %3886 = fmul fast float %3885, %3885
  %3887 = fadd fast float %3876, %3886
  %3888 = fmul fast float %3811, 0x3F25D867E0000000
  %3889 = fmul fast float %3888, %3887
  br label %3890

; <label>:3890                                    ; preds = %3844, %3837
  %3891 = phi float [ %3889, %3844 ], [ 0.000000e+00, %3837 ]
  %3892 = fadd fast float %3891, %3840
  %3893 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3892)  ; FMin(a,b)
  %3894 = fmul fast float %3893, 0xBFF7154760000000
  %3895 = call float @dx.op.unary.f32(i32 21, float %3894)  ; Exp(value)
  %3896 = fsub fast float 1.000000e+00, %3895
  %3897 = call float @dx.op.binary.f32(i32 36, float %13, float %3896)  ; FMin(a,b)
  %3898 = fsub fast float %14, %3724
  %3899 = fsub fast float %15, %3725
  %3900 = fsub fast float %16, %3726
  %3901 = fmul fast float %3897, %3898
  %3902 = fmul fast float %3897, %3899
  %3903 = fmul fast float %3897, %3900
  %3904 = fadd fast float %3901, %3724
  %3905 = fadd fast float %3902, %3725
  %3906 = fadd fast float %3903, %3726
  br label %3907

; <label>:3907                                    ; preds = %3890, %3769, %3763
  %3908 = phi float [ %3904, %3890 ], [ %3724, %3769 ], [ %3724, %3763 ]
  %3909 = phi float [ %3905, %3890 ], [ %3725, %3769 ], [ %3725, %3763 ]
  %3910 = phi float [ %3906, %3890 ], [ %3726, %3769 ], [ %3726, %3763 ]
  %3911 = fadd fast float %6, 1.000000e+00
  %3912 = fadd fast float %7, 1.000000e+00
  %3913 = fsub fast float 1.000000e+00, %6
  %3914 = fmul fast float %37, %3911
  %3915 = fmul fast float %37, %3912
  %3916 = fmul fast float %37, %3913
  %3917 = fmul fast float %3914, %3908
  %3918 = fmul fast float %3915, %3909
  %3919 = fmul fast float %3916, %3910
  %3920 = fcmp fast ult float %38, 5.000000e-01
  br i1 %3920, label %3946, label %3921

; <label>:3921                                    ; preds = %3907
  %3922 = fmul fast float %3917, 0x4004147AE0000000
  %3923 = fmul fast float %3918, 0x4004147AE0000000
  %3924 = fmul fast float %3919, 0x4004147AE0000000
  %3925 = fadd fast float %3922, 0x3F9EB851E0000000
  %3926 = fadd fast float %3923, 0x3F9EB851E0000000
  %3927 = fadd fast float %3924, 0x3F9EB851E0000000
  %3928 = fmul fast float %3925, %3917
  %3929 = fmul fast float %3926, %3918
  %3930 = fmul fast float %3927, %3919
  %3931 = fmul fast float %3917, 0x400370A3E0000000
  %3932 = fmul fast float %3918, 0x400370A3E0000000
  %3933 = fmul fast float %3919, 0x400370A3E0000000
  %3934 = fadd fast float %3931, 0x3FE2E147A0000000
  %3935 = fadd fast float %3932, 0x3FE2E147A0000000
  %3936 = fadd fast float %3933, 0x3FE2E147A0000000
  %3937 = fmul fast float %3934, %3917
  %3938 = fmul fast float %3935, %3918
  %3939 = fmul fast float %3936, %3919
  %3940 = fadd fast float %3937, 0x3FC1EB8520000000
  %3941 = fadd fast float %3938, 0x3FC1EB8520000000
  %3942 = fadd fast float %3939, 0x3FC1EB8520000000
  %3943 = fdiv fast float %3928, %3940
  %3944 = fdiv fast float %3929, %3941
  %3945 = fdiv fast float %3930, %3942
  br label %3946

; <label>:3946                                    ; preds = %3921, %3907
  %3947 = phi float [ %3943, %3921 ], [ %3917, %3907 ]
  %3948 = phi float [ %3944, %3921 ], [ %3918, %3907 ]
  %3949 = phi float [ %3945, %3921 ], [ %3919, %3907 ]
  %3950 = call float @dx.op.unary.f32(i32 7, float %3947)  ; Saturate(value)
  %3951 = call float @dx.op.unary.f32(i32 7, float %3948)  ; Saturate(value)
  %3952 = call float @dx.op.unary.f32(i32 7, float %3949)  ; Saturate(value)
  %3953 = call float @dx.op.dot3.f32(i32 55, float %3950, float %3951, float %3952, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3954 = fsub fast float %3950, %3953
  %3955 = fsub fast float %3951, %3953
  %3956 = fsub fast float %3952, %3953
  %3957 = fmul fast float %3954, %9
  %3958 = fmul fast float %3955, %9
  %3959 = fmul fast float %3956, %9
  %3960 = fadd fast float %3957, %3953
  %3961 = fadd fast float %3958, %3953
  %3962 = fadd fast float %3959, %3953
  %3963 = call float @dx.op.unary.f32(i32 7, float %3960)  ; Saturate(value)
  %3964 = call float @dx.op.unary.f32(i32 7, float %3961)  ; Saturate(value)
  %3965 = call float @dx.op.unary.f32(i32 7, float %3962)  ; Saturate(value)
  %3966 = fadd fast float %3963, 0xBFC70A3D80000000
  %3967 = fadd fast float %3964, 0xBFC70A3D80000000
  %3968 = fadd fast float %3965, 0xBFC70A3D80000000
  %3969 = fmul fast float %3966, %8
  %3970 = fmul fast float %3967, %8
  %3971 = fmul fast float %3968, %8
  %3972 = fadd fast float %3969, 0x3FC70A3D80000000
  %3973 = fadd fast float %3970, 0x3FC70A3D80000000
  %3974 = fadd fast float %3971, 0x3FC70A3D80000000
  %3975 = call float @dx.op.unary.f32(i32 7, float %3972)  ; Saturate(value)
  %3976 = call float @dx.op.unary.f32(i32 7, float %3973)  ; Saturate(value)
  %3977 = call float @dx.op.unary.f32(i32 7, float %3974)  ; Saturate(value)
  br label %3978

; <label>:3978                                    ; preds = %3946, %3729
  %3979 = phi float [ %3760, %3729 ], [ %3975, %3946 ]
  %3980 = phi float [ %3761, %3729 ], [ %3976, %3946 ]
  %3981 = phi float [ %3762, %3729 ], [ %3977, %3946 ]
  %3982 = fsub fast float %3979, %1209
  %3983 = fsub fast float %3980, %1210
  %3984 = fsub fast float %3981, %1211
  %3985 = fmul fast float %3982, %3716
  %3986 = fmul fast float %3983, %3716
  %3987 = fmul fast float %3984, %3716
  %3988 = fadd fast float %3985, %1209
  %3989 = fadd fast float %3986, %1210
  %3990 = fadd fast float %3987, %1211
  br label %3991

; <label>:3991                                    ; preds = %3978, %3703
  %3992 = phi float [ %3988, %3978 ], [ %1209, %3703 ]
  %3993 = phi float [ %3989, %3978 ], [ %1210, %3703 ]
  %3994 = phi float [ %3990, %3978 ], [ %1211, %3703 ]
  %3995 = fsub fast float %85, %89
  %3996 = call float @dx.op.unary.f32(i32 6, float %3995)  ; FAbs(value)
  %3997 = fdiv fast float %3996, %3403
  %3998 = fsub fast float 1.000000e+00, %3997
  %3999 = call float @dx.op.unary.f32(i32 7, float %3998)  ; Saturate(value)
  %4000 = fcmp fast ugt float %3999, 0.000000e+00
  br i1 %4000, label %4001, label %4011

; <label>:4001                                    ; preds = %3991
  %4002 = fsub fast float %701, %1209
  %4003 = fsub fast float %702, %1210
  %4004 = fsub fast float %703, %1211
  %4005 = fmul fast float %3999, %4002
  %4006 = fmul fast float %3999, %4003
  %4007 = fmul fast float %3999, %4004
  %4008 = fadd fast float %4005, %1209
  %4009 = fadd fast float %4006, %1210
  %4010 = fadd fast float %4007, %1211
  br label %4011

; <label>:4011                                    ; preds = %4001, %3991
  %4012 = phi float [ %4008, %4001 ], [ %1209, %3991 ]
  %4013 = phi float [ %4009, %4001 ], [ %1210, %3991 ]
  %4014 = phi float [ %4010, %4001 ], [ %1211, %3991 ]
  %4015 = call float @dx.op.binary.f32(i32 36, float %3704, float %3684)  ; FMin(a,b)
  %4016 = call float @dx.op.binary.f32(i32 36, float %3705, float %3685)  ; FMin(a,b)
  %4017 = call float @dx.op.binary.f32(i32 36, float %3706, float %3686)  ; FMin(a,b)
  %4018 = call float @dx.op.binary.f32(i32 36, float %4012, float %3992)  ; FMin(a,b)
  %4019 = call float @dx.op.binary.f32(i32 36, float %4013, float %3993)  ; FMin(a,b)
  %4020 = call float @dx.op.binary.f32(i32 36, float %4014, float %3994)  ; FMin(a,b)
  %4021 = call float @dx.op.binary.f32(i32 36, float %4018, float %4015)  ; FMin(a,b)
  %4022 = call float @dx.op.binary.f32(i32 36, float %4019, float %4016)  ; FMin(a,b)
  %4023 = call float @dx.op.binary.f32(i32 36, float %4020, float %4017)  ; FMin(a,b)
  %4024 = call float @dx.op.binary.f32(i32 36, float %1209, float %4021)  ; FMin(a,b)
  %4025 = call float @dx.op.binary.f32(i32 36, float %1210, float %4022)  ; FMin(a,b)
  %4026 = call float @dx.op.binary.f32(i32 36, float %1211, float %4023)  ; FMin(a,b)
  %4027 = call float @dx.op.binary.f32(i32 35, float %3704, float %3684)  ; FMax(a,b)
  %4028 = call float @dx.op.binary.f32(i32 35, float %3705, float %3685)  ; FMax(a,b)
  %4029 = call float @dx.op.binary.f32(i32 35, float %3706, float %3686)  ; FMax(a,b)
  %4030 = call float @dx.op.binary.f32(i32 35, float %4012, float %3992)  ; FMax(a,b)
  %4031 = call float @dx.op.binary.f32(i32 35, float %4013, float %3993)  ; FMax(a,b)
  %4032 = call float @dx.op.binary.f32(i32 35, float %4014, float %3994)  ; FMax(a,b)
  %4033 = call float @dx.op.binary.f32(i32 35, float %4030, float %4027)  ; FMax(a,b)
  %4034 = call float @dx.op.binary.f32(i32 35, float %4031, float %4028)  ; FMax(a,b)
  %4035 = call float @dx.op.binary.f32(i32 35, float %4032, float %4029)  ; FMax(a,b)
  %4036 = call float @dx.op.binary.f32(i32 35, float %1209, float %4033)  ; FMax(a,b)
  %4037 = call float @dx.op.binary.f32(i32 35, float %1210, float %4034)  ; FMax(a,b)
  %4038 = call float @dx.op.binary.f32(i32 35, float %1211, float %4035)  ; FMax(a,b)
  %4039 = fsub fast float %4036, %4024
  %4040 = fsub fast float %4037, %4025
  %4041 = fsub fast float %4038, %4026
  %4042 = call float @dx.op.unary.f32(i32 6, float %4039)  ; FAbs(value)
  %4043 = call float @dx.op.unary.f32(i32 6, float %4040)  ; FAbs(value)
  %4044 = call float @dx.op.unary.f32(i32 6, float %4041)  ; FAbs(value)
  %4045 = call float @dx.op.binary.f32(i32 35, float %4043, float %4044)  ; FMax(a,b)
  %4046 = call float @dx.op.binary.f32(i32 35, float %4042, float %4045)  ; FMax(a,b)
  %4047 = call float @dx.op.binary.f32(i32 35, float %4037, float %4038)  ; FMax(a,b)
  %4048 = call float @dx.op.binary.f32(i32 35, float %4036, float %4047)  ; FMax(a,b)
  %4049 = fmul fast float %4048, 1.250000e-01
  %4050 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %4049)  ; FMax(a,b)
  %4051 = fcmp fast ogt float %4046, %4050
  br i1 %4051, label %4052, label %10186

; <label>:4052                                    ; preds = %4011
  %4053 = fsub fast float %4012, %3992
  %4054 = fsub fast float %4013, %3993
  %4055 = fsub fast float %4014, %3994
  %4056 = call float @dx.op.unary.f32(i32 6, float %4053)  ; FAbs(value)
  %4057 = call float @dx.op.unary.f32(i32 6, float %4054)  ; FAbs(value)
  %4058 = call float @dx.op.unary.f32(i32 6, float %4055)  ; FAbs(value)
  %4059 = call float @dx.op.binary.f32(i32 35, float %4057, float %4058)  ; FMax(a,b)
  %4060 = call float @dx.op.binary.f32(i32 35, float %4056, float %4059)  ; FMax(a,b)
  %4061 = fsub fast float %3704, %3684
  %4062 = fsub fast float %3705, %3685
  %4063 = fsub fast float %3706, %3686
  %4064 = call float @dx.op.unary.f32(i32 6, float %4061)  ; FAbs(value)
  %4065 = call float @dx.op.unary.f32(i32 6, float %4062)  ; FAbs(value)
  %4066 = call float @dx.op.unary.f32(i32 6, float %4063)  ; FAbs(value)
  %4067 = call float @dx.op.binary.f32(i32 35, float %4065, float %4066)  ; FMax(a,b)
  %4068 = call float @dx.op.binary.f32(i32 35, float %4064, float %4067)  ; FMax(a,b)
  %4069 = fcmp fast olt float %4060, %4068
  %4070 = select i1 %4069, float %4012, float %3704
  %4071 = select i1 %4069, float %4013, float %3705
  %4072 = select i1 %4069, float %4014, float %3706
  %4073 = select i1 %4069, float %3992, float %3684
  %4074 = select i1 %4069, float %3993, float %3685
  %4075 = select i1 %4069, float %3994, float %3686
  %4076 = fsub fast float %1209, %4073
  %4077 = fsub fast float %1210, %4074
  %4078 = fsub fast float %1211, %4075
  %4079 = fsub fast float %1209, %4070
  %4080 = fsub fast float %1210, %4071
  %4081 = fsub fast float %1211, %4072
  %4082 = call float @dx.op.dot3.f32(i32 55, float %4079, float %4080, float %4081, float %4076, float %4077, float %4078)  ; Dot3(ax,ay,az,bx,by,bz)
  %4083 = fcmp fast ogt float %4082, 0.000000e+00
  br i1 %4083, label %4084, label %4096

; <label>:4084                                    ; preds = %4052
  %4085 = fsub fast float %4070, %4073
  %4086 = fsub fast float %4071, %4074
  %4087 = fsub fast float %4072, %4075
  %4088 = call float @dx.op.unary.f32(i32 6, float %4085)  ; FAbs(value)
  %4089 = call float @dx.op.unary.f32(i32 6, float %4086)  ; FAbs(value)
  %4090 = call float @dx.op.unary.f32(i32 6, float %4087)  ; FAbs(value)
  %4091 = call float @dx.op.binary.f32(i32 35, float %4089, float %4090)  ; FMax(a,b)
  %4092 = call float @dx.op.binary.f32(i32 35, float %4088, float %4091)  ; FMax(a,b)
  %4093 = fmul fast float %4046, 2.500000e-01
  %4094 = fcmp fast olt float %4092, %4093
  %4095 = select i1 %4094, float 5.000000e-01, float 1.000000e+00
  br label %4096

; <label>:4096                                    ; preds = %4084, %4052
  %4097 = phi float [ 1.000000e+00, %4052 ], [ %4095, %4084 ]
  %4098 = fmul fast float %4097, %3
  %4099 = fadd fast float %4070, %4073
  %4100 = fadd fast float %4071, %4074
  %4101 = fadd fast float %4072, %4075
  %4102 = fmul fast float %4099, 5.000000e-01
  %4103 = fmul fast float %4100, 5.000000e-01
  %4104 = fmul fast float %4101, 5.000000e-01
  %4105 = fsub fast float %4102, %1209
  %4106 = fsub fast float %4103, %1210
  %4107 = fsub fast float %4104, %1211
  %4108 = fmul fast float %4098, %4105
  %4109 = fmul fast float %4098, %4106
  %4110 = fmul fast float %4098, %4107
  %4111 = fadd fast float %4108, %1209
  %4112 = fadd fast float %4109, %1210
  %4113 = fadd fast float %4110, %1211
  br label %10186

; <label>:4114                                    ; preds = %173
  %4115 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %64, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4116 = extractvalue %dx.types.ResRet.f32 %4115, 0
  %4117 = extractvalue %dx.types.ResRet.f32 %4115, 1
  %4118 = extractvalue %dx.types.ResRet.f32 %4115, 2
  %4119 = extractvalue %dx.types.ResRet.f32 %4115, 3
  %4120 = fcmp fast olt float %4119, 0.000000e+00
  br i1 %4120, label %4121, label %4156

; <label>:4121                                    ; preds = %4114
  %4122 = fcmp fast ogt float %4116, 0x3FA4B5DCC0000000
  %4123 = fcmp fast ogt float %4117, 0x3FA4B5DCC0000000
  %4124 = fcmp fast ogt float %4118, 0x3FA4B5DCC0000000
  %4125 = select i1 %4122, float 0.000000e+00, float 1.000000e+00
  %4126 = select i1 %4123, float 0.000000e+00, float 1.000000e+00
  %4127 = select i1 %4124, float 0.000000e+00, float 1.000000e+00
  %4128 = fmul fast float %4116, 0x3FB3D07220000000
  %4129 = fmul fast float %4117, 0x3FB3D07220000000
  %4130 = fmul fast float %4118, 0x3FB3D07220000000
  %4131 = fadd fast float %4116, 0x3FAC28F5C0000000
  %4132 = fadd fast float %4117, 0x3FAC28F5C0000000
  %4133 = fadd fast float %4118, 0x3FAC28F5C0000000
  %4134 = fmul fast float %4131, 0x3FEE54EDE0000000
  %4135 = fmul fast float %4132, 0x3FEE54EDE0000000
  %4136 = fmul fast float %4133, 0x3FEE54EDE0000000
  %4137 = call float @dx.op.unary.f32(i32 23, float %4134)  ; Log(value)
  %4138 = call float @dx.op.unary.f32(i32 23, float %4135)  ; Log(value)
  %4139 = call float @dx.op.unary.f32(i32 23, float %4136)  ; Log(value)
  %4140 = fmul fast float %4137, 0x4003333340000000
  %4141 = fmul fast float %4138, 0x4003333340000000
  %4142 = fmul fast float %4139, 0x4003333340000000
  %4143 = call float @dx.op.unary.f32(i32 21, float %4140)  ; Exp(value)
  %4144 = call float @dx.op.unary.f32(i32 21, float %4141)  ; Exp(value)
  %4145 = call float @dx.op.unary.f32(i32 21, float %4142)  ; Exp(value)
  %4146 = fsub fast float %4128, %4143
  %4147 = fsub fast float %4129, %4144
  %4148 = fsub fast float %4130, %4145
  %4149 = fmul fast float %4146, %4125
  %4150 = fmul fast float %4147, %4126
  %4151 = fmul fast float %4148, %4127
  %4152 = fadd fast float %4149, %4143
  %4153 = fadd fast float %4150, %4144
  %4154 = fadd fast float %4151, %4145
  %4155 = fsub fast float -1.000000e+00, %4119
  br label %5629

; <label>:4156                                    ; preds = %4114
  %4157 = fcmp fast ogt float %39, 5.000000e-01
  %4158 = fcmp fast olt float %83, 1.000000e+00
  %4159 = and i1 %4157, %4158
  br i1 %4159, label %4160, label %4298

; <label>:4160                                    ; preds = %4156
  %4161 = sitofp i32 %64 to float
  %4162 = sitofp i32 %65 to float
  %4163 = fadd fast float %4161, 5.000000e-01
  %4164 = fadd fast float %4162, 5.000000e-01
  %4165 = fdiv fast float %4163, %46
  %4166 = fdiv fast float %4164, %47
  %4167 = fmul fast float %4165, 2.000000e+00
  %4168 = fmul fast float %4166, 2.000000e+00
  %4169 = fadd fast float %4167, -1.000000e+00
  %4170 = fsub fast float 1.000000e+00, %4168
  %4171 = fmul fast float %4169, %36
  %4172 = call float @dx.op.tertiary.f32(i32 46, float %4170, float %32, float %4171)  ; FMad(a,b,c)
  %4173 = call float @dx.op.tertiary.f32(i32 46, float %83, float %28, float %4172)  ; FMad(a,b,c)
  %4174 = fadd fast float %4173, %24
  %4175 = call float @dx.op.unary.f32(i32 6, float %4174)  ; FAbs(value)
  %4176 = fcmp fast ogt float %4175, 0x3EB0C6F7A0000000
  br i1 %4176, label %4177, label %4298

; <label>:4177                                    ; preds = %4160
  %4178 = fmul fast float %4169, %35
  %4179 = call float @dx.op.tertiary.f32(i32 46, float %4170, float %31, float %4178)  ; FMad(a,b,c)
  %4180 = call float @dx.op.tertiary.f32(i32 46, float %83, float %27, float %4179)  ; FMad(a,b,c)
  %4181 = fadd fast float %4180, %23
  %4182 = fmul fast float %4169, %34
  %4183 = call float @dx.op.tertiary.f32(i32 46, float %4170, float %30, float %4182)  ; FMad(a,b,c)
  %4184 = call float @dx.op.tertiary.f32(i32 46, float %83, float %26, float %4183)  ; FMad(a,b,c)
  %4185 = fadd fast float %4184, %22
  %4186 = fmul fast float %4169, %33
  %4187 = call float @dx.op.tertiary.f32(i32 46, float %4170, float %29, float %4186)  ; FMad(a,b,c)
  %4188 = call float @dx.op.tertiary.f32(i32 46, float %83, float %25, float %4187)  ; FMad(a,b,c)
  %4189 = fadd fast float %4188, %21
  %4190 = fdiv fast float %4189, %4174
  %4191 = fdiv fast float %4185, %4174
  %4192 = fdiv fast float %4181, %4174
  %4193 = fsub fast float %4190, %18
  %4194 = fsub fast float %4191, %19
  %4195 = fsub fast float %4192, %20
  %4196 = fmul fast float %4193, %4193
  %4197 = fmul fast float %4194, %4194
  %4198 = fadd fast float %4197, %4196
  %4199 = fmul fast float %4195, %4195
  %4200 = fadd fast float %4198, %4199
  %4201 = call float @dx.op.unary.f32(i32 24, float %4200)  ; Sqrt(value)
  %4202 = fsub fast float %4201, %10
  %4203 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4202)  ; FMax(a,b)
  %4204 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %4204, label %4205, label %4228

; <label>:4205                                    ; preds = %4177
  %4206 = call float @dx.op.unary.f32(i32 6, float %4194)  ; FAbs(value)
  %4207 = fmul fast float %4206, %12
  %4208 = fcmp fast olt float %4207, 0x3F50624DE0000000
  br i1 %4208, label %4209, label %4212

; <label>:4209                                    ; preds = %4205
  %4210 = fmul fast float %4207, 5.000000e-01
  %4211 = fsub fast float 1.000000e+00, %4210
  br label %4217

; <label>:4212                                    ; preds = %4205
  %4213 = fmul fast float %4207, 0xBFF7154760000000
  %4214 = call float @dx.op.unary.f32(i32 21, float %4213)  ; Exp(value)
  %4215 = fsub fast float 1.000000e+00, %4214
  %4216 = fdiv fast float %4215, %4207
  br label %4217

; <label>:4217                                    ; preds = %4212, %4209
  %4218 = phi float [ %4211, %4209 ], [ %4216, %4212 ]
  %4219 = call float @dx.op.binary.f32(i32 36, float %4191, float %19)  ; FMin(a,b)
  %4220 = fsub fast float %4219, %11
  %4221 = fmul fast float %12, %4220
  %4222 = fsub fast float -0.000000e+00, %4221
  %4223 = call float @dx.op.binary.f32(i32 35, float %4222, float -4.000000e+01)  ; FMax(a,b)
  %4224 = call float @dx.op.binary.f32(i32 36, float %4223, float 5.000000e+00)  ; FMin(a,b)
  %4225 = fmul fast float %4224, 0x3FF7154760000000
  %4226 = call float @dx.op.unary.f32(i32 21, float %4225)  ; Exp(value)
  %4227 = fmul fast float %4226, %4218
  br label %4228

; <label>:4228                                    ; preds = %4217, %4177
  %4229 = phi float [ %4227, %4217 ], [ 1.000000e+00, %4177 ]
  %4230 = fmul fast float %4203, %17
  %4231 = fmul fast float %4230, %4229
  %4232 = fcmp fast ole float %4201, %10
  %4233 = fcmp fast olt float %4201, 0x3F1A36E2E0000000
  %4234 = or i1 %4232, %4233
  br i1 %4234, label %4281, label %4235

; <label>:4235                                    ; preds = %4228
  %4236 = fdiv fast float %10, %4201
  %4237 = fmul fast float %4236, %4193
  %4238 = fmul fast float %4236, %4194
  %4239 = fmul fast float %4236, %4195
  %4240 = fadd fast float %4237, %18
  %4241 = fadd fast float %4238, %19
  %4242 = fadd fast float %4239, %20
  %4243 = fadd fast float %4240, -9.000000e+02
  %4244 = fadd fast float %4241, -1.500000e+01
  %4245 = fadd fast float %4242, -7.500000e+02
  %4246 = fmul fast float %4243, 0x3F62345680000000
  %4247 = fmul fast float %4244, 0x3F62345680000000
  %4248 = fmul fast float %4245, 0x3F62345680000000
  %4249 = call float @dx.op.dot3.f32(i32 55, float %4246, float %4247, float %4248, float %4246, float %4247, float %4248)  ; Dot3(ax,ay,az,bx,by,bz)
  %4250 = fsub fast float 1.000000e+00, %4249
  %4251 = call float @dx.op.unary.f32(i32 7, float %4250)  ; Saturate(value)
  %4252 = fmul fast float %4251, %4251
  %4253 = fadd fast float %4240, %4190
  %4254 = fadd fast float %4241, %4191
  %4255 = fadd fast float %4242, %4192
  %4256 = fmul fast float %4253, 0x3F52345680000000
  %4257 = fadd fast float %4256, -2.000000e+00
  %4258 = fmul fast float %4254, 0x3F52345680000000
  %4259 = fadd fast float %4258, 0xBFA1111120000000
  %4260 = fmul fast float %4255, 0x3F52345680000000
  %4261 = fadd fast float %4260, 0xBFFAAAAAC0000000
  %4262 = call float @dx.op.dot3.f32(i32 55, float %4257, float %4259, float %4261, float %4257, float %4259, float %4261)  ; Dot3(ax,ay,az,bx,by,bz)
  %4263 = fsub fast float 1.000000e+00, %4262
  %4264 = call float @dx.op.unary.f32(i32 7, float %4263)  ; Saturate(value)
  %4265 = fmul fast float %4264, %4264
  %4266 = fmul fast float %4265, 4.000000e+00
  %4267 = fadd fast float %4266, %4252
  %4268 = fadd fast float %4190, -9.000000e+02
  %4269 = fadd fast float %4191, -1.500000e+01
  %4270 = fadd fast float %4192, -7.500000e+02
  %4271 = fmul fast float %4268, 0x3F62345680000000
  %4272 = fmul fast float %4269, 0x3F62345680000000
  %4273 = fmul fast float %4270, 0x3F62345680000000
  %4274 = call float @dx.op.dot3.f32(i32 55, float %4271, float %4272, float %4273, float %4271, float %4272, float %4273)  ; Dot3(ax,ay,az,bx,by,bz)
  %4275 = fsub fast float 1.000000e+00, %4274
  %4276 = call float @dx.op.unary.f32(i32 7, float %4275)  ; Saturate(value)
  %4277 = fmul fast float %4276, %4276
  %4278 = fadd fast float %4267, %4277
  %4279 = fmul fast float %4202, 0x3F25D867E0000000
  %4280 = fmul fast float %4279, %4278
  br label %4281

; <label>:4281                                    ; preds = %4235, %4228
  %4282 = phi float [ %4280, %4235 ], [ 0.000000e+00, %4228 ]
  %4283 = fadd fast float %4282, %4231
  %4284 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4283)  ; FMin(a,b)
  %4285 = fmul fast float %4284, 0xBFF7154760000000
  %4286 = call float @dx.op.unary.f32(i32 21, float %4285)  ; Exp(value)
  %4287 = fsub fast float 1.000000e+00, %4286
  %4288 = call float @dx.op.binary.f32(i32 36, float %13, float %4287)  ; FMin(a,b)
  %4289 = fsub fast float %14, %4116
  %4290 = fsub fast float %15, %4117
  %4291 = fsub fast float %16, %4118
  %4292 = fmul fast float %4288, %4289
  %4293 = fmul fast float %4288, %4290
  %4294 = fmul fast float %4288, %4291
  %4295 = fadd fast float %4292, %4116
  %4296 = fadd fast float %4293, %4117
  %4297 = fadd fast float %4294, %4118
  br label %4298

; <label>:4298                                    ; preds = %4281, %4160, %4156
  %4299 = phi float [ %4295, %4281 ], [ %4116, %4160 ], [ %4116, %4156 ]
  %4300 = phi float [ %4296, %4281 ], [ %4117, %4160 ], [ %4117, %4156 ]
  %4301 = phi float [ %4297, %4281 ], [ %4118, %4160 ], [ %4118, %4156 ]
  %4302 = fadd fast float %6, 1.000000e+00
  %4303 = fadd fast float %7, 1.000000e+00
  %4304 = fsub fast float 1.000000e+00, %6
  %4305 = fmul fast float %37, %4302
  %4306 = fmul fast float %37, %4303
  %4307 = fmul fast float %37, %4304
  %4308 = fmul fast float %4305, %4299
  %4309 = fmul fast float %4306, %4300
  %4310 = fmul fast float %4307, %4301
  %4311 = fcmp fast ult float %38, 5.000000e-01
  br i1 %4311, label %4337, label %4312

; <label>:4312                                    ; preds = %4298
  %4313 = fmul fast float %4308, 0x4004147AE0000000
  %4314 = fmul fast float %4309, 0x4004147AE0000000
  %4315 = fmul fast float %4310, 0x4004147AE0000000
  %4316 = fadd fast float %4313, 0x3F9EB851E0000000
  %4317 = fadd fast float %4314, 0x3F9EB851E0000000
  %4318 = fadd fast float %4315, 0x3F9EB851E0000000
  %4319 = fmul fast float %4316, %4308
  %4320 = fmul fast float %4317, %4309
  %4321 = fmul fast float %4318, %4310
  %4322 = fmul fast float %4308, 0x400370A3E0000000
  %4323 = fmul fast float %4309, 0x400370A3E0000000
  %4324 = fmul fast float %4310, 0x400370A3E0000000
  %4325 = fadd fast float %4322, 0x3FE2E147A0000000
  %4326 = fadd fast float %4323, 0x3FE2E147A0000000
  %4327 = fadd fast float %4324, 0x3FE2E147A0000000
  %4328 = fmul fast float %4325, %4308
  %4329 = fmul fast float %4326, %4309
  %4330 = fmul fast float %4327, %4310
  %4331 = fadd fast float %4328, 0x3FC1EB8520000000
  %4332 = fadd fast float %4329, 0x3FC1EB8520000000
  %4333 = fadd fast float %4330, 0x3FC1EB8520000000
  %4334 = fdiv fast float %4319, %4331
  %4335 = fdiv fast float %4320, %4332
  %4336 = fdiv fast float %4321, %4333
  br label %4337

; <label>:4337                                    ; preds = %4312, %4298
  %4338 = phi float [ %4334, %4312 ], [ %4308, %4298 ]
  %4339 = phi float [ %4335, %4312 ], [ %4309, %4298 ]
  %4340 = phi float [ %4336, %4312 ], [ %4310, %4298 ]
  %4341 = call float @dx.op.unary.f32(i32 7, float %4338)  ; Saturate(value)
  %4342 = call float @dx.op.unary.f32(i32 7, float %4339)  ; Saturate(value)
  %4343 = call float @dx.op.unary.f32(i32 7, float %4340)  ; Saturate(value)
  %4344 = call float @dx.op.dot3.f32(i32 55, float %4341, float %4342, float %4343, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4345 = fsub fast float %4341, %4344
  %4346 = fsub fast float %4342, %4344
  %4347 = fsub fast float %4343, %4344
  %4348 = fmul fast float %4345, %9
  %4349 = fmul fast float %4346, %9
  %4350 = fmul fast float %4347, %9
  %4351 = fadd fast float %4348, %4344
  %4352 = fadd fast float %4349, %4344
  %4353 = fadd fast float %4350, %4344
  %4354 = call float @dx.op.unary.f32(i32 7, float %4351)  ; Saturate(value)
  %4355 = call float @dx.op.unary.f32(i32 7, float %4352)  ; Saturate(value)
  %4356 = call float @dx.op.unary.f32(i32 7, float %4353)  ; Saturate(value)
  %4357 = fadd fast float %4354, 0xBFC70A3D80000000
  %4358 = fadd fast float %4355, 0xBFC70A3D80000000
  %4359 = fadd fast float %4356, 0xBFC70A3D80000000
  %4360 = fmul fast float %4357, %8
  %4361 = fmul fast float %4358, %8
  %4362 = fmul fast float %4359, %8
  %4363 = fadd fast float %4360, 0x3FC70A3D80000000
  %4364 = fadd fast float %4361, 0x3FC70A3D80000000
  %4365 = fadd fast float %4362, 0x3FC70A3D80000000
  %4366 = call float @dx.op.unary.f32(i32 7, float %4363)  ; Saturate(value)
  %4367 = call float @dx.op.unary.f32(i32 7, float %4364)  ; Saturate(value)
  %4368 = call float @dx.op.unary.f32(i32 7, float %4365)  ; Saturate(value)
  %4369 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %4369, label %4370, label %5629

; <label>:4370                                    ; preds = %4337
  %4371 = add i32 %65, -1
  %4372 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %4373 = call i32 @dx.op.binary.i32(i32 37, i32 %4371, i32 0)  ; IMax(a,b)
  %4374 = call i32 @dx.op.binary.i32(i32 38, i32 %4372, i32 %60)  ; IMin(a,b)
  %4375 = call i32 @dx.op.binary.i32(i32 38, i32 %4373, i32 %61)  ; IMin(a,b)
  %4376 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4374, i32 %4375, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4377 = extractvalue %dx.types.ResRet.f32 %4376, 0
  %4378 = fsub fast float 1.000000e+00, %83
  %4379 = fmul fast float %4378, 0x3FA99999A0000000
  %4380 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %4379)  ; FMax(a,b)
  %4381 = fsub fast float %4377, %83
  %4382 = call float @dx.op.unary.f32(i32 6, float %4381)  ; FAbs(value)
  %4383 = fdiv fast float %4382, %4380
  %4384 = fsub fast float 1.000000e+00, %4383
  %4385 = call float @dx.op.unary.f32(i32 7, float %4384)  ; Saturate(value)
  %4386 = fcmp fast ugt float %4385, 0.000000e+00
  br i1 %4386, label %4387, label %4660

; <label>:4387                                    ; preds = %4370
  %4388 = call i32 @dx.op.binary.i32(i32 37, i32 %4374, i32 0)  ; IMax(a,b)
  %4389 = call i32 @dx.op.binary.i32(i32 37, i32 %4375, i32 0)  ; IMax(a,b)
  %4390 = call i32 @dx.op.binary.i32(i32 38, i32 %4388, i32 %60)  ; IMin(a,b)
  %4391 = call i32 @dx.op.binary.i32(i32 38, i32 %4389, i32 %61)  ; IMin(a,b)
  %4392 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4390, i32 %4391, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4393 = extractvalue %dx.types.ResRet.f32 %4392, 0
  %4394 = extractvalue %dx.types.ResRet.f32 %4392, 1
  %4395 = extractvalue %dx.types.ResRet.f32 %4392, 2
  %4396 = extractvalue %dx.types.ResRet.f32 %4392, 3
  %4397 = fcmp fast olt float %4396, 0.000000e+00
  br i1 %4397, label %4398, label %4432

; <label>:4398                                    ; preds = %4387
  %4399 = fcmp fast ogt float %4393, 0x3FA4B5DCC0000000
  %4400 = fcmp fast ogt float %4394, 0x3FA4B5DCC0000000
  %4401 = fcmp fast ogt float %4395, 0x3FA4B5DCC0000000
  %4402 = select i1 %4399, float 0.000000e+00, float 1.000000e+00
  %4403 = select i1 %4400, float 0.000000e+00, float 1.000000e+00
  %4404 = select i1 %4401, float 0.000000e+00, float 1.000000e+00
  %4405 = fmul fast float %4393, 0x3FB3D07220000000
  %4406 = fmul fast float %4394, 0x3FB3D07220000000
  %4407 = fmul fast float %4395, 0x3FB3D07220000000
  %4408 = fadd fast float %4393, 0x3FAC28F5C0000000
  %4409 = fadd fast float %4394, 0x3FAC28F5C0000000
  %4410 = fadd fast float %4395, 0x3FAC28F5C0000000
  %4411 = fmul fast float %4408, 0x3FEE54EDE0000000
  %4412 = fmul fast float %4409, 0x3FEE54EDE0000000
  %4413 = fmul fast float %4410, 0x3FEE54EDE0000000
  %4414 = call float @dx.op.unary.f32(i32 23, float %4411)  ; Log(value)
  %4415 = call float @dx.op.unary.f32(i32 23, float %4412)  ; Log(value)
  %4416 = call float @dx.op.unary.f32(i32 23, float %4413)  ; Log(value)
  %4417 = fmul fast float %4414, 0x4003333340000000
  %4418 = fmul fast float %4415, 0x4003333340000000
  %4419 = fmul fast float %4416, 0x4003333340000000
  %4420 = call float @dx.op.unary.f32(i32 21, float %4417)  ; Exp(value)
  %4421 = call float @dx.op.unary.f32(i32 21, float %4418)  ; Exp(value)
  %4422 = call float @dx.op.unary.f32(i32 21, float %4419)  ; Exp(value)
  %4423 = fsub fast float %4405, %4420
  %4424 = fsub fast float %4406, %4421
  %4425 = fsub fast float %4407, %4422
  %4426 = fmul fast float %4423, %4402
  %4427 = fmul fast float %4424, %4403
  %4428 = fmul fast float %4425, %4404
  %4429 = fadd fast float %4426, %4420
  %4430 = fadd fast float %4427, %4421
  %4431 = fadd fast float %4428, %4422
  br label %4647

; <label>:4432                                    ; preds = %4387
  %4433 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4390, i32 %4391, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4434 = extractvalue %dx.types.ResRet.f32 %4433, 0
  %4435 = fcmp fast ogt float %39, 5.000000e-01
  %4436 = fcmp fast olt float %4434, 1.000000e+00
  %4437 = and i1 %4435, %4436
  br i1 %4437, label %4438, label %4576

; <label>:4438                                    ; preds = %4432
  %4439 = sitofp i32 %4390 to float
  %4440 = sitofp i32 %4391 to float
  %4441 = fadd fast float %4439, 5.000000e-01
  %4442 = fadd fast float %4440, 5.000000e-01
  %4443 = fdiv fast float %4441, %46
  %4444 = fdiv fast float %4442, %47
  %4445 = fmul fast float %4443, 2.000000e+00
  %4446 = fmul fast float %4444, 2.000000e+00
  %4447 = fadd fast float %4445, -1.000000e+00
  %4448 = fsub fast float 1.000000e+00, %4446
  %4449 = fmul fast float %4447, %36
  %4450 = call float @dx.op.tertiary.f32(i32 46, float %4448, float %32, float %4449)  ; FMad(a,b,c)
  %4451 = call float @dx.op.tertiary.f32(i32 46, float %4434, float %28, float %4450)  ; FMad(a,b,c)
  %4452 = fadd fast float %4451, %24
  %4453 = call float @dx.op.unary.f32(i32 6, float %4452)  ; FAbs(value)
  %4454 = fcmp fast ogt float %4453, 0x3EB0C6F7A0000000
  br i1 %4454, label %4455, label %4576

; <label>:4455                                    ; preds = %4438
  %4456 = fmul fast float %4447, %35
  %4457 = call float @dx.op.tertiary.f32(i32 46, float %4448, float %31, float %4456)  ; FMad(a,b,c)
  %4458 = call float @dx.op.tertiary.f32(i32 46, float %4434, float %27, float %4457)  ; FMad(a,b,c)
  %4459 = fadd fast float %4458, %23
  %4460 = fmul fast float %4447, %34
  %4461 = call float @dx.op.tertiary.f32(i32 46, float %4448, float %30, float %4460)  ; FMad(a,b,c)
  %4462 = call float @dx.op.tertiary.f32(i32 46, float %4434, float %26, float %4461)  ; FMad(a,b,c)
  %4463 = fadd fast float %4462, %22
  %4464 = fmul fast float %4447, %33
  %4465 = call float @dx.op.tertiary.f32(i32 46, float %4448, float %29, float %4464)  ; FMad(a,b,c)
  %4466 = call float @dx.op.tertiary.f32(i32 46, float %4434, float %25, float %4465)  ; FMad(a,b,c)
  %4467 = fadd fast float %4466, %21
  %4468 = fdiv fast float %4467, %4452
  %4469 = fdiv fast float %4463, %4452
  %4470 = fdiv fast float %4459, %4452
  %4471 = fsub fast float %4468, %18
  %4472 = fsub fast float %4469, %19
  %4473 = fsub fast float %4470, %20
  %4474 = fmul fast float %4471, %4471
  %4475 = fmul fast float %4472, %4472
  %4476 = fadd fast float %4475, %4474
  %4477 = fmul fast float %4473, %4473
  %4478 = fadd fast float %4476, %4477
  %4479 = call float @dx.op.unary.f32(i32 24, float %4478)  ; Sqrt(value)
  %4480 = fsub fast float %4479, %10
  %4481 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4480)  ; FMax(a,b)
  %4482 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %4482, label %4483, label %4506

; <label>:4483                                    ; preds = %4455
  %4484 = call float @dx.op.unary.f32(i32 6, float %4472)  ; FAbs(value)
  %4485 = fmul fast float %4484, %12
  %4486 = fcmp fast olt float %4485, 0x3F50624DE0000000
  br i1 %4486, label %4487, label %4490

; <label>:4487                                    ; preds = %4483
  %4488 = fmul fast float %4485, 5.000000e-01
  %4489 = fsub fast float 1.000000e+00, %4488
  br label %4495

; <label>:4490                                    ; preds = %4483
  %4491 = fmul fast float %4485, 0xBFF7154760000000
  %4492 = call float @dx.op.unary.f32(i32 21, float %4491)  ; Exp(value)
  %4493 = fsub fast float 1.000000e+00, %4492
  %4494 = fdiv fast float %4493, %4485
  br label %4495

; <label>:4495                                    ; preds = %4490, %4487
  %4496 = phi float [ %4489, %4487 ], [ %4494, %4490 ]
  %4497 = call float @dx.op.binary.f32(i32 36, float %4469, float %19)  ; FMin(a,b)
  %4498 = fsub fast float %4497, %11
  %4499 = fmul fast float %12, %4498
  %4500 = fsub fast float -0.000000e+00, %4499
  %4501 = call float @dx.op.binary.f32(i32 35, float %4500, float -4.000000e+01)  ; FMax(a,b)
  %4502 = call float @dx.op.binary.f32(i32 36, float %4501, float 5.000000e+00)  ; FMin(a,b)
  %4503 = fmul fast float %4502, 0x3FF7154760000000
  %4504 = call float @dx.op.unary.f32(i32 21, float %4503)  ; Exp(value)
  %4505 = fmul fast float %4504, %4496
  br label %4506

; <label>:4506                                    ; preds = %4495, %4455
  %4507 = phi float [ %4505, %4495 ], [ 1.000000e+00, %4455 ]
  %4508 = fmul fast float %4481, %17
  %4509 = fmul fast float %4508, %4507
  %4510 = fcmp fast ole float %4479, %10
  %4511 = fcmp fast olt float %4479, 0x3F1A36E2E0000000
  %4512 = or i1 %4510, %4511
  br i1 %4512, label %4559, label %4513

; <label>:4513                                    ; preds = %4506
  %4514 = fdiv fast float %10, %4479
  %4515 = fmul fast float %4514, %4471
  %4516 = fmul fast float %4514, %4472
  %4517 = fmul fast float %4514, %4473
  %4518 = fadd fast float %4515, %18
  %4519 = fadd fast float %4516, %19
  %4520 = fadd fast float %4517, %20
  %4521 = fadd fast float %4518, -9.000000e+02
  %4522 = fadd fast float %4519, -1.500000e+01
  %4523 = fadd fast float %4520, -7.500000e+02
  %4524 = fmul fast float %4521, 0x3F62345680000000
  %4525 = fmul fast float %4522, 0x3F62345680000000
  %4526 = fmul fast float %4523, 0x3F62345680000000
  %4527 = call float @dx.op.dot3.f32(i32 55, float %4524, float %4525, float %4526, float %4524, float %4525, float %4526)  ; Dot3(ax,ay,az,bx,by,bz)
  %4528 = fsub fast float 1.000000e+00, %4527
  %4529 = call float @dx.op.unary.f32(i32 7, float %4528)  ; Saturate(value)
  %4530 = fmul fast float %4529, %4529
  %4531 = fadd fast float %4518, %4468
  %4532 = fadd fast float %4519, %4469
  %4533 = fadd fast float %4520, %4470
  %4534 = fmul fast float %4531, 0x3F52345680000000
  %4535 = fadd fast float %4534, -2.000000e+00
  %4536 = fmul fast float %4532, 0x3F52345680000000
  %4537 = fadd fast float %4536, 0xBFA1111120000000
  %4538 = fmul fast float %4533, 0x3F52345680000000
  %4539 = fadd fast float %4538, 0xBFFAAAAAC0000000
  %4540 = call float @dx.op.dot3.f32(i32 55, float %4535, float %4537, float %4539, float %4535, float %4537, float %4539)  ; Dot3(ax,ay,az,bx,by,bz)
  %4541 = fsub fast float 1.000000e+00, %4540
  %4542 = call float @dx.op.unary.f32(i32 7, float %4541)  ; Saturate(value)
  %4543 = fmul fast float %4542, %4542
  %4544 = fmul fast float %4543, 4.000000e+00
  %4545 = fadd fast float %4544, %4530
  %4546 = fadd fast float %4468, -9.000000e+02
  %4547 = fadd fast float %4469, -1.500000e+01
  %4548 = fadd fast float %4470, -7.500000e+02
  %4549 = fmul fast float %4546, 0x3F62345680000000
  %4550 = fmul fast float %4547, 0x3F62345680000000
  %4551 = fmul fast float %4548, 0x3F62345680000000
  %4552 = call float @dx.op.dot3.f32(i32 55, float %4549, float %4550, float %4551, float %4549, float %4550, float %4551)  ; Dot3(ax,ay,az,bx,by,bz)
  %4553 = fsub fast float 1.000000e+00, %4552
  %4554 = call float @dx.op.unary.f32(i32 7, float %4553)  ; Saturate(value)
  %4555 = fmul fast float %4554, %4554
  %4556 = fadd fast float %4545, %4555
  %4557 = fmul fast float %4480, 0x3F25D867E0000000
  %4558 = fmul fast float %4557, %4556
  br label %4559

; <label>:4559                                    ; preds = %4513, %4506
  %4560 = phi float [ %4558, %4513 ], [ 0.000000e+00, %4506 ]
  %4561 = fadd fast float %4560, %4509
  %4562 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4561)  ; FMin(a,b)
  %4563 = fmul fast float %4562, 0xBFF7154760000000
  %4564 = call float @dx.op.unary.f32(i32 21, float %4563)  ; Exp(value)
  %4565 = fsub fast float 1.000000e+00, %4564
  %4566 = call float @dx.op.binary.f32(i32 36, float %13, float %4565)  ; FMin(a,b)
  %4567 = fsub fast float %14, %4393
  %4568 = fsub fast float %15, %4394
  %4569 = fsub fast float %16, %4395
  %4570 = fmul fast float %4566, %4567
  %4571 = fmul fast float %4566, %4568
  %4572 = fmul fast float %4566, %4569
  %4573 = fadd fast float %4570, %4393
  %4574 = fadd fast float %4571, %4394
  %4575 = fadd fast float %4572, %4395
  br label %4576

; <label>:4576                                    ; preds = %4559, %4438, %4432
  %4577 = phi float [ %4573, %4559 ], [ %4393, %4438 ], [ %4393, %4432 ]
  %4578 = phi float [ %4574, %4559 ], [ %4394, %4438 ], [ %4394, %4432 ]
  %4579 = phi float [ %4575, %4559 ], [ %4395, %4438 ], [ %4395, %4432 ]
  %4580 = fadd fast float %6, 1.000000e+00
  %4581 = fadd fast float %7, 1.000000e+00
  %4582 = fsub fast float 1.000000e+00, %6
  %4583 = fmul fast float %37, %4580
  %4584 = fmul fast float %37, %4581
  %4585 = fmul fast float %37, %4582
  %4586 = fmul fast float %4583, %4577
  %4587 = fmul fast float %4584, %4578
  %4588 = fmul fast float %4585, %4579
  %4589 = fcmp fast ult float %38, 5.000000e-01
  br i1 %4589, label %4615, label %4590

; <label>:4590                                    ; preds = %4576
  %4591 = fmul fast float %4586, 0x4004147AE0000000
  %4592 = fmul fast float %4587, 0x4004147AE0000000
  %4593 = fmul fast float %4588, 0x4004147AE0000000
  %4594 = fadd fast float %4591, 0x3F9EB851E0000000
  %4595 = fadd fast float %4592, 0x3F9EB851E0000000
  %4596 = fadd fast float %4593, 0x3F9EB851E0000000
  %4597 = fmul fast float %4594, %4586
  %4598 = fmul fast float %4595, %4587
  %4599 = fmul fast float %4596, %4588
  %4600 = fmul fast float %4586, 0x400370A3E0000000
  %4601 = fmul fast float %4587, 0x400370A3E0000000
  %4602 = fmul fast float %4588, 0x400370A3E0000000
  %4603 = fadd fast float %4600, 0x3FE2E147A0000000
  %4604 = fadd fast float %4601, 0x3FE2E147A0000000
  %4605 = fadd fast float %4602, 0x3FE2E147A0000000
  %4606 = fmul fast float %4603, %4586
  %4607 = fmul fast float %4604, %4587
  %4608 = fmul fast float %4605, %4588
  %4609 = fadd fast float %4606, 0x3FC1EB8520000000
  %4610 = fadd fast float %4607, 0x3FC1EB8520000000
  %4611 = fadd fast float %4608, 0x3FC1EB8520000000
  %4612 = fdiv fast float %4597, %4609
  %4613 = fdiv fast float %4598, %4610
  %4614 = fdiv fast float %4599, %4611
  br label %4615

; <label>:4615                                    ; preds = %4590, %4576
  %4616 = phi float [ %4612, %4590 ], [ %4586, %4576 ]
  %4617 = phi float [ %4613, %4590 ], [ %4587, %4576 ]
  %4618 = phi float [ %4614, %4590 ], [ %4588, %4576 ]
  %4619 = call float @dx.op.unary.f32(i32 7, float %4616)  ; Saturate(value)
  %4620 = call float @dx.op.unary.f32(i32 7, float %4617)  ; Saturate(value)
  %4621 = call float @dx.op.unary.f32(i32 7, float %4618)  ; Saturate(value)
  %4622 = call float @dx.op.dot3.f32(i32 55, float %4619, float %4620, float %4621, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4623 = fsub fast float %4619, %4622
  %4624 = fsub fast float %4620, %4622
  %4625 = fsub fast float %4621, %4622
  %4626 = fmul fast float %4623, %9
  %4627 = fmul fast float %4624, %9
  %4628 = fmul fast float %4625, %9
  %4629 = fadd fast float %4626, %4622
  %4630 = fadd fast float %4627, %4622
  %4631 = fadd fast float %4628, %4622
  %4632 = call float @dx.op.unary.f32(i32 7, float %4629)  ; Saturate(value)
  %4633 = call float @dx.op.unary.f32(i32 7, float %4630)  ; Saturate(value)
  %4634 = call float @dx.op.unary.f32(i32 7, float %4631)  ; Saturate(value)
  %4635 = fadd fast float %4632, 0xBFC70A3D80000000
  %4636 = fadd fast float %4633, 0xBFC70A3D80000000
  %4637 = fadd fast float %4634, 0xBFC70A3D80000000
  %4638 = fmul fast float %4635, %8
  %4639 = fmul fast float %4636, %8
  %4640 = fmul fast float %4637, %8
  %4641 = fadd fast float %4638, 0x3FC70A3D80000000
  %4642 = fadd fast float %4639, 0x3FC70A3D80000000
  %4643 = fadd fast float %4640, 0x3FC70A3D80000000
  %4644 = call float @dx.op.unary.f32(i32 7, float %4641)  ; Saturate(value)
  %4645 = call float @dx.op.unary.f32(i32 7, float %4642)  ; Saturate(value)
  %4646 = call float @dx.op.unary.f32(i32 7, float %4643)  ; Saturate(value)
  br label %4647

; <label>:4647                                    ; preds = %4615, %4398
  %4648 = phi float [ %4429, %4398 ], [ %4644, %4615 ]
  %4649 = phi float [ %4430, %4398 ], [ %4645, %4615 ]
  %4650 = phi float [ %4431, %4398 ], [ %4646, %4615 ]
  %4651 = fsub fast float %4648, %4366
  %4652 = fsub fast float %4649, %4367
  %4653 = fsub fast float %4650, %4368
  %4654 = fmul fast float %4651, %4385
  %4655 = fmul fast float %4652, %4385
  %4656 = fmul fast float %4653, %4385
  %4657 = fadd fast float %4654, %4366
  %4658 = fadd fast float %4655, %4367
  %4659 = fadd fast float %4656, %4368
  br label %4660

; <label>:4660                                    ; preds = %4647, %4370
  %4661 = phi float [ %4657, %4647 ], [ %4366, %4370 ]
  %4662 = phi float [ %4658, %4647 ], [ %4367, %4370 ]
  %4663 = phi float [ %4659, %4647 ], [ %4368, %4370 ]
  %4664 = add i32 %65, 1
  %4665 = call i32 @dx.op.binary.i32(i32 37, i32 %4664, i32 0)  ; IMax(a,b)
  %4666 = call i32 @dx.op.binary.i32(i32 38, i32 %4665, i32 %61)  ; IMin(a,b)
  %4667 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4374, i32 %4666, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4668 = extractvalue %dx.types.ResRet.f32 %4667, 0
  %4669 = fsub fast float %4668, %83
  %4670 = call float @dx.op.unary.f32(i32 6, float %4669)  ; FAbs(value)
  %4671 = fdiv fast float %4670, %4380
  %4672 = fsub fast float 1.000000e+00, %4671
  %4673 = call float @dx.op.unary.f32(i32 7, float %4672)  ; Saturate(value)
  %4674 = fcmp fast ugt float %4673, 0.000000e+00
  br i1 %4674, label %4675, label %4948

; <label>:4675                                    ; preds = %4660
  %4676 = call i32 @dx.op.binary.i32(i32 37, i32 %4374, i32 0)  ; IMax(a,b)
  %4677 = call i32 @dx.op.binary.i32(i32 37, i32 %4666, i32 0)  ; IMax(a,b)
  %4678 = call i32 @dx.op.binary.i32(i32 38, i32 %4676, i32 %60)  ; IMin(a,b)
  %4679 = call i32 @dx.op.binary.i32(i32 38, i32 %4677, i32 %61)  ; IMin(a,b)
  %4680 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4678, i32 %4679, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4681 = extractvalue %dx.types.ResRet.f32 %4680, 0
  %4682 = extractvalue %dx.types.ResRet.f32 %4680, 1
  %4683 = extractvalue %dx.types.ResRet.f32 %4680, 2
  %4684 = extractvalue %dx.types.ResRet.f32 %4680, 3
  %4685 = fcmp fast olt float %4684, 0.000000e+00
  br i1 %4685, label %4686, label %4720

; <label>:4686                                    ; preds = %4675
  %4687 = fcmp fast ogt float %4681, 0x3FA4B5DCC0000000
  %4688 = fcmp fast ogt float %4682, 0x3FA4B5DCC0000000
  %4689 = fcmp fast ogt float %4683, 0x3FA4B5DCC0000000
  %4690 = select i1 %4687, float 0.000000e+00, float 1.000000e+00
  %4691 = select i1 %4688, float 0.000000e+00, float 1.000000e+00
  %4692 = select i1 %4689, float 0.000000e+00, float 1.000000e+00
  %4693 = fmul fast float %4681, 0x3FB3D07220000000
  %4694 = fmul fast float %4682, 0x3FB3D07220000000
  %4695 = fmul fast float %4683, 0x3FB3D07220000000
  %4696 = fadd fast float %4681, 0x3FAC28F5C0000000
  %4697 = fadd fast float %4682, 0x3FAC28F5C0000000
  %4698 = fadd fast float %4683, 0x3FAC28F5C0000000
  %4699 = fmul fast float %4696, 0x3FEE54EDE0000000
  %4700 = fmul fast float %4697, 0x3FEE54EDE0000000
  %4701 = fmul fast float %4698, 0x3FEE54EDE0000000
  %4702 = call float @dx.op.unary.f32(i32 23, float %4699)  ; Log(value)
  %4703 = call float @dx.op.unary.f32(i32 23, float %4700)  ; Log(value)
  %4704 = call float @dx.op.unary.f32(i32 23, float %4701)  ; Log(value)
  %4705 = fmul fast float %4702, 0x4003333340000000
  %4706 = fmul fast float %4703, 0x4003333340000000
  %4707 = fmul fast float %4704, 0x4003333340000000
  %4708 = call float @dx.op.unary.f32(i32 21, float %4705)  ; Exp(value)
  %4709 = call float @dx.op.unary.f32(i32 21, float %4706)  ; Exp(value)
  %4710 = call float @dx.op.unary.f32(i32 21, float %4707)  ; Exp(value)
  %4711 = fsub fast float %4693, %4708
  %4712 = fsub fast float %4694, %4709
  %4713 = fsub fast float %4695, %4710
  %4714 = fmul fast float %4711, %4690
  %4715 = fmul fast float %4712, %4691
  %4716 = fmul fast float %4713, %4692
  %4717 = fadd fast float %4714, %4708
  %4718 = fadd fast float %4715, %4709
  %4719 = fadd fast float %4716, %4710
  br label %4935

; <label>:4720                                    ; preds = %4675
  %4721 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4678, i32 %4679, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4722 = extractvalue %dx.types.ResRet.f32 %4721, 0
  %4723 = fcmp fast ogt float %39, 5.000000e-01
  %4724 = fcmp fast olt float %4722, 1.000000e+00
  %4725 = and i1 %4723, %4724
  br i1 %4725, label %4726, label %4864

; <label>:4726                                    ; preds = %4720
  %4727 = sitofp i32 %4678 to float
  %4728 = sitofp i32 %4679 to float
  %4729 = fadd fast float %4727, 5.000000e-01
  %4730 = fadd fast float %4728, 5.000000e-01
  %4731 = fdiv fast float %4729, %46
  %4732 = fdiv fast float %4730, %47
  %4733 = fmul fast float %4731, 2.000000e+00
  %4734 = fmul fast float %4732, 2.000000e+00
  %4735 = fadd fast float %4733, -1.000000e+00
  %4736 = fsub fast float 1.000000e+00, %4734
  %4737 = fmul fast float %4735, %36
  %4738 = call float @dx.op.tertiary.f32(i32 46, float %4736, float %32, float %4737)  ; FMad(a,b,c)
  %4739 = call float @dx.op.tertiary.f32(i32 46, float %4722, float %28, float %4738)  ; FMad(a,b,c)
  %4740 = fadd fast float %4739, %24
  %4741 = call float @dx.op.unary.f32(i32 6, float %4740)  ; FAbs(value)
  %4742 = fcmp fast ogt float %4741, 0x3EB0C6F7A0000000
  br i1 %4742, label %4743, label %4864

; <label>:4743                                    ; preds = %4726
  %4744 = fmul fast float %4735, %35
  %4745 = call float @dx.op.tertiary.f32(i32 46, float %4736, float %31, float %4744)  ; FMad(a,b,c)
  %4746 = call float @dx.op.tertiary.f32(i32 46, float %4722, float %27, float %4745)  ; FMad(a,b,c)
  %4747 = fadd fast float %4746, %23
  %4748 = fmul fast float %4735, %34
  %4749 = call float @dx.op.tertiary.f32(i32 46, float %4736, float %30, float %4748)  ; FMad(a,b,c)
  %4750 = call float @dx.op.tertiary.f32(i32 46, float %4722, float %26, float %4749)  ; FMad(a,b,c)
  %4751 = fadd fast float %4750, %22
  %4752 = fmul fast float %4735, %33
  %4753 = call float @dx.op.tertiary.f32(i32 46, float %4736, float %29, float %4752)  ; FMad(a,b,c)
  %4754 = call float @dx.op.tertiary.f32(i32 46, float %4722, float %25, float %4753)  ; FMad(a,b,c)
  %4755 = fadd fast float %4754, %21
  %4756 = fdiv fast float %4755, %4740
  %4757 = fdiv fast float %4751, %4740
  %4758 = fdiv fast float %4747, %4740
  %4759 = fsub fast float %4756, %18
  %4760 = fsub fast float %4757, %19
  %4761 = fsub fast float %4758, %20
  %4762 = fmul fast float %4759, %4759
  %4763 = fmul fast float %4760, %4760
  %4764 = fadd fast float %4763, %4762
  %4765 = fmul fast float %4761, %4761
  %4766 = fadd fast float %4764, %4765
  %4767 = call float @dx.op.unary.f32(i32 24, float %4766)  ; Sqrt(value)
  %4768 = fsub fast float %4767, %10
  %4769 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4768)  ; FMax(a,b)
  %4770 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %4770, label %4771, label %4794

; <label>:4771                                    ; preds = %4743
  %4772 = call float @dx.op.unary.f32(i32 6, float %4760)  ; FAbs(value)
  %4773 = fmul fast float %4772, %12
  %4774 = fcmp fast olt float %4773, 0x3F50624DE0000000
  br i1 %4774, label %4775, label %4778

; <label>:4775                                    ; preds = %4771
  %4776 = fmul fast float %4773, 5.000000e-01
  %4777 = fsub fast float 1.000000e+00, %4776
  br label %4783

; <label>:4778                                    ; preds = %4771
  %4779 = fmul fast float %4773, 0xBFF7154760000000
  %4780 = call float @dx.op.unary.f32(i32 21, float %4779)  ; Exp(value)
  %4781 = fsub fast float 1.000000e+00, %4780
  %4782 = fdiv fast float %4781, %4773
  br label %4783

; <label>:4783                                    ; preds = %4778, %4775
  %4784 = phi float [ %4777, %4775 ], [ %4782, %4778 ]
  %4785 = call float @dx.op.binary.f32(i32 36, float %4757, float %19)  ; FMin(a,b)
  %4786 = fsub fast float %4785, %11
  %4787 = fmul fast float %12, %4786
  %4788 = fsub fast float -0.000000e+00, %4787
  %4789 = call float @dx.op.binary.f32(i32 35, float %4788, float -4.000000e+01)  ; FMax(a,b)
  %4790 = call float @dx.op.binary.f32(i32 36, float %4789, float 5.000000e+00)  ; FMin(a,b)
  %4791 = fmul fast float %4790, 0x3FF7154760000000
  %4792 = call float @dx.op.unary.f32(i32 21, float %4791)  ; Exp(value)
  %4793 = fmul fast float %4792, %4784
  br label %4794

; <label>:4794                                    ; preds = %4783, %4743
  %4795 = phi float [ %4793, %4783 ], [ 1.000000e+00, %4743 ]
  %4796 = fmul fast float %4769, %17
  %4797 = fmul fast float %4796, %4795
  %4798 = fcmp fast ole float %4767, %10
  %4799 = fcmp fast olt float %4767, 0x3F1A36E2E0000000
  %4800 = or i1 %4798, %4799
  br i1 %4800, label %4847, label %4801

; <label>:4801                                    ; preds = %4794
  %4802 = fdiv fast float %10, %4767
  %4803 = fmul fast float %4802, %4759
  %4804 = fmul fast float %4802, %4760
  %4805 = fmul fast float %4802, %4761
  %4806 = fadd fast float %4803, %18
  %4807 = fadd fast float %4804, %19
  %4808 = fadd fast float %4805, %20
  %4809 = fadd fast float %4806, -9.000000e+02
  %4810 = fadd fast float %4807, -1.500000e+01
  %4811 = fadd fast float %4808, -7.500000e+02
  %4812 = fmul fast float %4809, 0x3F62345680000000
  %4813 = fmul fast float %4810, 0x3F62345680000000
  %4814 = fmul fast float %4811, 0x3F62345680000000
  %4815 = call float @dx.op.dot3.f32(i32 55, float %4812, float %4813, float %4814, float %4812, float %4813, float %4814)  ; Dot3(ax,ay,az,bx,by,bz)
  %4816 = fsub fast float 1.000000e+00, %4815
  %4817 = call float @dx.op.unary.f32(i32 7, float %4816)  ; Saturate(value)
  %4818 = fmul fast float %4817, %4817
  %4819 = fadd fast float %4806, %4756
  %4820 = fadd fast float %4807, %4757
  %4821 = fadd fast float %4808, %4758
  %4822 = fmul fast float %4819, 0x3F52345680000000
  %4823 = fadd fast float %4822, -2.000000e+00
  %4824 = fmul fast float %4820, 0x3F52345680000000
  %4825 = fadd fast float %4824, 0xBFA1111120000000
  %4826 = fmul fast float %4821, 0x3F52345680000000
  %4827 = fadd fast float %4826, 0xBFFAAAAAC0000000
  %4828 = call float @dx.op.dot3.f32(i32 55, float %4823, float %4825, float %4827, float %4823, float %4825, float %4827)  ; Dot3(ax,ay,az,bx,by,bz)
  %4829 = fsub fast float 1.000000e+00, %4828
  %4830 = call float @dx.op.unary.f32(i32 7, float %4829)  ; Saturate(value)
  %4831 = fmul fast float %4830, %4830
  %4832 = fmul fast float %4831, 4.000000e+00
  %4833 = fadd fast float %4832, %4818
  %4834 = fadd fast float %4756, -9.000000e+02
  %4835 = fadd fast float %4757, -1.500000e+01
  %4836 = fadd fast float %4758, -7.500000e+02
  %4837 = fmul fast float %4834, 0x3F62345680000000
  %4838 = fmul fast float %4835, 0x3F62345680000000
  %4839 = fmul fast float %4836, 0x3F62345680000000
  %4840 = call float @dx.op.dot3.f32(i32 55, float %4837, float %4838, float %4839, float %4837, float %4838, float %4839)  ; Dot3(ax,ay,az,bx,by,bz)
  %4841 = fsub fast float 1.000000e+00, %4840
  %4842 = call float @dx.op.unary.f32(i32 7, float %4841)  ; Saturate(value)
  %4843 = fmul fast float %4842, %4842
  %4844 = fadd fast float %4833, %4843
  %4845 = fmul fast float %4768, 0x3F25D867E0000000
  %4846 = fmul fast float %4845, %4844
  br label %4847

; <label>:4847                                    ; preds = %4801, %4794
  %4848 = phi float [ %4846, %4801 ], [ 0.000000e+00, %4794 ]
  %4849 = fadd fast float %4848, %4797
  %4850 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4849)  ; FMin(a,b)
  %4851 = fmul fast float %4850, 0xBFF7154760000000
  %4852 = call float @dx.op.unary.f32(i32 21, float %4851)  ; Exp(value)
  %4853 = fsub fast float 1.000000e+00, %4852
  %4854 = call float @dx.op.binary.f32(i32 36, float %13, float %4853)  ; FMin(a,b)
  %4855 = fsub fast float %14, %4681
  %4856 = fsub fast float %15, %4682
  %4857 = fsub fast float %16, %4683
  %4858 = fmul fast float %4854, %4855
  %4859 = fmul fast float %4854, %4856
  %4860 = fmul fast float %4854, %4857
  %4861 = fadd fast float %4858, %4681
  %4862 = fadd fast float %4859, %4682
  %4863 = fadd fast float %4860, %4683
  br label %4864

; <label>:4864                                    ; preds = %4847, %4726, %4720
  %4865 = phi float [ %4861, %4847 ], [ %4681, %4726 ], [ %4681, %4720 ]
  %4866 = phi float [ %4862, %4847 ], [ %4682, %4726 ], [ %4682, %4720 ]
  %4867 = phi float [ %4863, %4847 ], [ %4683, %4726 ], [ %4683, %4720 ]
  %4868 = fadd fast float %6, 1.000000e+00
  %4869 = fadd fast float %7, 1.000000e+00
  %4870 = fsub fast float 1.000000e+00, %6
  %4871 = fmul fast float %37, %4868
  %4872 = fmul fast float %37, %4869
  %4873 = fmul fast float %37, %4870
  %4874 = fmul fast float %4871, %4865
  %4875 = fmul fast float %4872, %4866
  %4876 = fmul fast float %4873, %4867
  %4877 = fcmp fast ult float %38, 5.000000e-01
  br i1 %4877, label %4903, label %4878

; <label>:4878                                    ; preds = %4864
  %4879 = fmul fast float %4874, 0x4004147AE0000000
  %4880 = fmul fast float %4875, 0x4004147AE0000000
  %4881 = fmul fast float %4876, 0x4004147AE0000000
  %4882 = fadd fast float %4879, 0x3F9EB851E0000000
  %4883 = fadd fast float %4880, 0x3F9EB851E0000000
  %4884 = fadd fast float %4881, 0x3F9EB851E0000000
  %4885 = fmul fast float %4882, %4874
  %4886 = fmul fast float %4883, %4875
  %4887 = fmul fast float %4884, %4876
  %4888 = fmul fast float %4874, 0x400370A3E0000000
  %4889 = fmul fast float %4875, 0x400370A3E0000000
  %4890 = fmul fast float %4876, 0x400370A3E0000000
  %4891 = fadd fast float %4888, 0x3FE2E147A0000000
  %4892 = fadd fast float %4889, 0x3FE2E147A0000000
  %4893 = fadd fast float %4890, 0x3FE2E147A0000000
  %4894 = fmul fast float %4891, %4874
  %4895 = fmul fast float %4892, %4875
  %4896 = fmul fast float %4893, %4876
  %4897 = fadd fast float %4894, 0x3FC1EB8520000000
  %4898 = fadd fast float %4895, 0x3FC1EB8520000000
  %4899 = fadd fast float %4896, 0x3FC1EB8520000000
  %4900 = fdiv fast float %4885, %4897
  %4901 = fdiv fast float %4886, %4898
  %4902 = fdiv fast float %4887, %4899
  br label %4903

; <label>:4903                                    ; preds = %4878, %4864
  %4904 = phi float [ %4900, %4878 ], [ %4874, %4864 ]
  %4905 = phi float [ %4901, %4878 ], [ %4875, %4864 ]
  %4906 = phi float [ %4902, %4878 ], [ %4876, %4864 ]
  %4907 = call float @dx.op.unary.f32(i32 7, float %4904)  ; Saturate(value)
  %4908 = call float @dx.op.unary.f32(i32 7, float %4905)  ; Saturate(value)
  %4909 = call float @dx.op.unary.f32(i32 7, float %4906)  ; Saturate(value)
  %4910 = call float @dx.op.dot3.f32(i32 55, float %4907, float %4908, float %4909, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4911 = fsub fast float %4907, %4910
  %4912 = fsub fast float %4908, %4910
  %4913 = fsub fast float %4909, %4910
  %4914 = fmul fast float %4911, %9
  %4915 = fmul fast float %4912, %9
  %4916 = fmul fast float %4913, %9
  %4917 = fadd fast float %4914, %4910
  %4918 = fadd fast float %4915, %4910
  %4919 = fadd fast float %4916, %4910
  %4920 = call float @dx.op.unary.f32(i32 7, float %4917)  ; Saturate(value)
  %4921 = call float @dx.op.unary.f32(i32 7, float %4918)  ; Saturate(value)
  %4922 = call float @dx.op.unary.f32(i32 7, float %4919)  ; Saturate(value)
  %4923 = fadd fast float %4920, 0xBFC70A3D80000000
  %4924 = fadd fast float %4921, 0xBFC70A3D80000000
  %4925 = fadd fast float %4922, 0xBFC70A3D80000000
  %4926 = fmul fast float %4923, %8
  %4927 = fmul fast float %4924, %8
  %4928 = fmul fast float %4925, %8
  %4929 = fadd fast float %4926, 0x3FC70A3D80000000
  %4930 = fadd fast float %4927, 0x3FC70A3D80000000
  %4931 = fadd fast float %4928, 0x3FC70A3D80000000
  %4932 = call float @dx.op.unary.f32(i32 7, float %4929)  ; Saturate(value)
  %4933 = call float @dx.op.unary.f32(i32 7, float %4930)  ; Saturate(value)
  %4934 = call float @dx.op.unary.f32(i32 7, float %4931)  ; Saturate(value)
  br label %4935

; <label>:4935                                    ; preds = %4903, %4686
  %4936 = phi float [ %4717, %4686 ], [ %4932, %4903 ]
  %4937 = phi float [ %4718, %4686 ], [ %4933, %4903 ]
  %4938 = phi float [ %4719, %4686 ], [ %4934, %4903 ]
  %4939 = fsub fast float %4936, %4366
  %4940 = fsub fast float %4937, %4367
  %4941 = fsub fast float %4938, %4368
  %4942 = fmul fast float %4939, %4673
  %4943 = fmul fast float %4940, %4673
  %4944 = fmul fast float %4941, %4673
  %4945 = fadd fast float %4942, %4366
  %4946 = fadd fast float %4943, %4367
  %4947 = fadd fast float %4944, %4368
  br label %4948

; <label>:4948                                    ; preds = %4935, %4660
  %4949 = phi float [ %4945, %4935 ], [ %4366, %4660 ]
  %4950 = phi float [ %4946, %4935 ], [ %4367, %4660 ]
  %4951 = phi float [ %4947, %4935 ], [ %4368, %4660 ]
  %4952 = add i32 %64, -1
  %4953 = call i32 @dx.op.binary.i32(i32 37, i32 %4952, i32 0)  ; IMax(a,b)
  %4954 = call i32 @dx.op.binary.i32(i32 37, i32 %65, i32 0)  ; IMax(a,b)
  %4955 = call i32 @dx.op.binary.i32(i32 38, i32 %4953, i32 %60)  ; IMin(a,b)
  %4956 = call i32 @dx.op.binary.i32(i32 38, i32 %4954, i32 %61)  ; IMin(a,b)
  %4957 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4955, i32 %4956, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4958 = extractvalue %dx.types.ResRet.f32 %4957, 0
  %4959 = fsub fast float %4958, %83
  %4960 = call float @dx.op.unary.f32(i32 6, float %4959)  ; FAbs(value)
  %4961 = fdiv fast float %4960, %4380
  %4962 = fsub fast float 1.000000e+00, %4961
  %4963 = call float @dx.op.unary.f32(i32 7, float %4962)  ; Saturate(value)
  %4964 = fcmp fast ugt float %4963, 0.000000e+00
  br i1 %4964, label %4965, label %5238

; <label>:4965                                    ; preds = %4948
  %4966 = call i32 @dx.op.binary.i32(i32 37, i32 %4955, i32 0)  ; IMax(a,b)
  %4967 = call i32 @dx.op.binary.i32(i32 37, i32 %4956, i32 0)  ; IMax(a,b)
  %4968 = call i32 @dx.op.binary.i32(i32 38, i32 %4966, i32 %60)  ; IMin(a,b)
  %4969 = call i32 @dx.op.binary.i32(i32 38, i32 %4967, i32 %61)  ; IMin(a,b)
  %4970 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4968, i32 %4969, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4971 = extractvalue %dx.types.ResRet.f32 %4970, 0
  %4972 = extractvalue %dx.types.ResRet.f32 %4970, 1
  %4973 = extractvalue %dx.types.ResRet.f32 %4970, 2
  %4974 = extractvalue %dx.types.ResRet.f32 %4970, 3
  %4975 = fcmp fast olt float %4974, 0.000000e+00
  br i1 %4975, label %4976, label %5010

; <label>:4976                                    ; preds = %4965
  %4977 = fcmp fast ogt float %4971, 0x3FA4B5DCC0000000
  %4978 = fcmp fast ogt float %4972, 0x3FA4B5DCC0000000
  %4979 = fcmp fast ogt float %4973, 0x3FA4B5DCC0000000
  %4980 = select i1 %4977, float 0.000000e+00, float 1.000000e+00
  %4981 = select i1 %4978, float 0.000000e+00, float 1.000000e+00
  %4982 = select i1 %4979, float 0.000000e+00, float 1.000000e+00
  %4983 = fmul fast float %4971, 0x3FB3D07220000000
  %4984 = fmul fast float %4972, 0x3FB3D07220000000
  %4985 = fmul fast float %4973, 0x3FB3D07220000000
  %4986 = fadd fast float %4971, 0x3FAC28F5C0000000
  %4987 = fadd fast float %4972, 0x3FAC28F5C0000000
  %4988 = fadd fast float %4973, 0x3FAC28F5C0000000
  %4989 = fmul fast float %4986, 0x3FEE54EDE0000000
  %4990 = fmul fast float %4987, 0x3FEE54EDE0000000
  %4991 = fmul fast float %4988, 0x3FEE54EDE0000000
  %4992 = call float @dx.op.unary.f32(i32 23, float %4989)  ; Log(value)
  %4993 = call float @dx.op.unary.f32(i32 23, float %4990)  ; Log(value)
  %4994 = call float @dx.op.unary.f32(i32 23, float %4991)  ; Log(value)
  %4995 = fmul fast float %4992, 0x4003333340000000
  %4996 = fmul fast float %4993, 0x4003333340000000
  %4997 = fmul fast float %4994, 0x4003333340000000
  %4998 = call float @dx.op.unary.f32(i32 21, float %4995)  ; Exp(value)
  %4999 = call float @dx.op.unary.f32(i32 21, float %4996)  ; Exp(value)
  %5000 = call float @dx.op.unary.f32(i32 21, float %4997)  ; Exp(value)
  %5001 = fsub fast float %4983, %4998
  %5002 = fsub fast float %4984, %4999
  %5003 = fsub fast float %4985, %5000
  %5004 = fmul fast float %5001, %4980
  %5005 = fmul fast float %5002, %4981
  %5006 = fmul fast float %5003, %4982
  %5007 = fadd fast float %5004, %4998
  %5008 = fadd fast float %5005, %4999
  %5009 = fadd fast float %5006, %5000
  br label %5225

; <label>:5010                                    ; preds = %4965
  %5011 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4968, i32 %4969, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5012 = extractvalue %dx.types.ResRet.f32 %5011, 0
  %5013 = fcmp fast ogt float %39, 5.000000e-01
  %5014 = fcmp fast olt float %5012, 1.000000e+00
  %5015 = and i1 %5013, %5014
  br i1 %5015, label %5016, label %5154

; <label>:5016                                    ; preds = %5010
  %5017 = sitofp i32 %4968 to float
  %5018 = sitofp i32 %4969 to float
  %5019 = fadd fast float %5017, 5.000000e-01
  %5020 = fadd fast float %5018, 5.000000e-01
  %5021 = fdiv fast float %5019, %46
  %5022 = fdiv fast float %5020, %47
  %5023 = fmul fast float %5021, 2.000000e+00
  %5024 = fmul fast float %5022, 2.000000e+00
  %5025 = fadd fast float %5023, -1.000000e+00
  %5026 = fsub fast float 1.000000e+00, %5024
  %5027 = fmul fast float %5025, %36
  %5028 = call float @dx.op.tertiary.f32(i32 46, float %5026, float %32, float %5027)  ; FMad(a,b,c)
  %5029 = call float @dx.op.tertiary.f32(i32 46, float %5012, float %28, float %5028)  ; FMad(a,b,c)
  %5030 = fadd fast float %5029, %24
  %5031 = call float @dx.op.unary.f32(i32 6, float %5030)  ; FAbs(value)
  %5032 = fcmp fast ogt float %5031, 0x3EB0C6F7A0000000
  br i1 %5032, label %5033, label %5154

; <label>:5033                                    ; preds = %5016
  %5034 = fmul fast float %5025, %35
  %5035 = call float @dx.op.tertiary.f32(i32 46, float %5026, float %31, float %5034)  ; FMad(a,b,c)
  %5036 = call float @dx.op.tertiary.f32(i32 46, float %5012, float %27, float %5035)  ; FMad(a,b,c)
  %5037 = fadd fast float %5036, %23
  %5038 = fmul fast float %5025, %34
  %5039 = call float @dx.op.tertiary.f32(i32 46, float %5026, float %30, float %5038)  ; FMad(a,b,c)
  %5040 = call float @dx.op.tertiary.f32(i32 46, float %5012, float %26, float %5039)  ; FMad(a,b,c)
  %5041 = fadd fast float %5040, %22
  %5042 = fmul fast float %5025, %33
  %5043 = call float @dx.op.tertiary.f32(i32 46, float %5026, float %29, float %5042)  ; FMad(a,b,c)
  %5044 = call float @dx.op.tertiary.f32(i32 46, float %5012, float %25, float %5043)  ; FMad(a,b,c)
  %5045 = fadd fast float %5044, %21
  %5046 = fdiv fast float %5045, %5030
  %5047 = fdiv fast float %5041, %5030
  %5048 = fdiv fast float %5037, %5030
  %5049 = fsub fast float %5046, %18
  %5050 = fsub fast float %5047, %19
  %5051 = fsub fast float %5048, %20
  %5052 = fmul fast float %5049, %5049
  %5053 = fmul fast float %5050, %5050
  %5054 = fadd fast float %5053, %5052
  %5055 = fmul fast float %5051, %5051
  %5056 = fadd fast float %5054, %5055
  %5057 = call float @dx.op.unary.f32(i32 24, float %5056)  ; Sqrt(value)
  %5058 = fsub fast float %5057, %10
  %5059 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5058)  ; FMax(a,b)
  %5060 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %5060, label %5061, label %5084

; <label>:5061                                    ; preds = %5033
  %5062 = call float @dx.op.unary.f32(i32 6, float %5050)  ; FAbs(value)
  %5063 = fmul fast float %5062, %12
  %5064 = fcmp fast olt float %5063, 0x3F50624DE0000000
  br i1 %5064, label %5065, label %5068

; <label>:5065                                    ; preds = %5061
  %5066 = fmul fast float %5063, 5.000000e-01
  %5067 = fsub fast float 1.000000e+00, %5066
  br label %5073

; <label>:5068                                    ; preds = %5061
  %5069 = fmul fast float %5063, 0xBFF7154760000000
  %5070 = call float @dx.op.unary.f32(i32 21, float %5069)  ; Exp(value)
  %5071 = fsub fast float 1.000000e+00, %5070
  %5072 = fdiv fast float %5071, %5063
  br label %5073

; <label>:5073                                    ; preds = %5068, %5065
  %5074 = phi float [ %5067, %5065 ], [ %5072, %5068 ]
  %5075 = call float @dx.op.binary.f32(i32 36, float %5047, float %19)  ; FMin(a,b)
  %5076 = fsub fast float %5075, %11
  %5077 = fmul fast float %12, %5076
  %5078 = fsub fast float -0.000000e+00, %5077
  %5079 = call float @dx.op.binary.f32(i32 35, float %5078, float -4.000000e+01)  ; FMax(a,b)
  %5080 = call float @dx.op.binary.f32(i32 36, float %5079, float 5.000000e+00)  ; FMin(a,b)
  %5081 = fmul fast float %5080, 0x3FF7154760000000
  %5082 = call float @dx.op.unary.f32(i32 21, float %5081)  ; Exp(value)
  %5083 = fmul fast float %5082, %5074
  br label %5084

; <label>:5084                                    ; preds = %5073, %5033
  %5085 = phi float [ %5083, %5073 ], [ 1.000000e+00, %5033 ]
  %5086 = fmul fast float %5059, %17
  %5087 = fmul fast float %5086, %5085
  %5088 = fcmp fast ole float %5057, %10
  %5089 = fcmp fast olt float %5057, 0x3F1A36E2E0000000
  %5090 = or i1 %5088, %5089
  br i1 %5090, label %5137, label %5091

; <label>:5091                                    ; preds = %5084
  %5092 = fdiv fast float %10, %5057
  %5093 = fmul fast float %5092, %5049
  %5094 = fmul fast float %5092, %5050
  %5095 = fmul fast float %5092, %5051
  %5096 = fadd fast float %5093, %18
  %5097 = fadd fast float %5094, %19
  %5098 = fadd fast float %5095, %20
  %5099 = fadd fast float %5096, -9.000000e+02
  %5100 = fadd fast float %5097, -1.500000e+01
  %5101 = fadd fast float %5098, -7.500000e+02
  %5102 = fmul fast float %5099, 0x3F62345680000000
  %5103 = fmul fast float %5100, 0x3F62345680000000
  %5104 = fmul fast float %5101, 0x3F62345680000000
  %5105 = call float @dx.op.dot3.f32(i32 55, float %5102, float %5103, float %5104, float %5102, float %5103, float %5104)  ; Dot3(ax,ay,az,bx,by,bz)
  %5106 = fsub fast float 1.000000e+00, %5105
  %5107 = call float @dx.op.unary.f32(i32 7, float %5106)  ; Saturate(value)
  %5108 = fmul fast float %5107, %5107
  %5109 = fadd fast float %5096, %5046
  %5110 = fadd fast float %5097, %5047
  %5111 = fadd fast float %5098, %5048
  %5112 = fmul fast float %5109, 0x3F52345680000000
  %5113 = fadd fast float %5112, -2.000000e+00
  %5114 = fmul fast float %5110, 0x3F52345680000000
  %5115 = fadd fast float %5114, 0xBFA1111120000000
  %5116 = fmul fast float %5111, 0x3F52345680000000
  %5117 = fadd fast float %5116, 0xBFFAAAAAC0000000
  %5118 = call float @dx.op.dot3.f32(i32 55, float %5113, float %5115, float %5117, float %5113, float %5115, float %5117)  ; Dot3(ax,ay,az,bx,by,bz)
  %5119 = fsub fast float 1.000000e+00, %5118
  %5120 = call float @dx.op.unary.f32(i32 7, float %5119)  ; Saturate(value)
  %5121 = fmul fast float %5120, %5120
  %5122 = fmul fast float %5121, 4.000000e+00
  %5123 = fadd fast float %5122, %5108
  %5124 = fadd fast float %5046, -9.000000e+02
  %5125 = fadd fast float %5047, -1.500000e+01
  %5126 = fadd fast float %5048, -7.500000e+02
  %5127 = fmul fast float %5124, 0x3F62345680000000
  %5128 = fmul fast float %5125, 0x3F62345680000000
  %5129 = fmul fast float %5126, 0x3F62345680000000
  %5130 = call float @dx.op.dot3.f32(i32 55, float %5127, float %5128, float %5129, float %5127, float %5128, float %5129)  ; Dot3(ax,ay,az,bx,by,bz)
  %5131 = fsub fast float 1.000000e+00, %5130
  %5132 = call float @dx.op.unary.f32(i32 7, float %5131)  ; Saturate(value)
  %5133 = fmul fast float %5132, %5132
  %5134 = fadd fast float %5123, %5133
  %5135 = fmul fast float %5058, 0x3F25D867E0000000
  %5136 = fmul fast float %5135, %5134
  br label %5137

; <label>:5137                                    ; preds = %5091, %5084
  %5138 = phi float [ %5136, %5091 ], [ 0.000000e+00, %5084 ]
  %5139 = fadd fast float %5138, %5087
  %5140 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %5139)  ; FMin(a,b)
  %5141 = fmul fast float %5140, 0xBFF7154760000000
  %5142 = call float @dx.op.unary.f32(i32 21, float %5141)  ; Exp(value)
  %5143 = fsub fast float 1.000000e+00, %5142
  %5144 = call float @dx.op.binary.f32(i32 36, float %13, float %5143)  ; FMin(a,b)
  %5145 = fsub fast float %14, %4971
  %5146 = fsub fast float %15, %4972
  %5147 = fsub fast float %16, %4973
  %5148 = fmul fast float %5144, %5145
  %5149 = fmul fast float %5144, %5146
  %5150 = fmul fast float %5144, %5147
  %5151 = fadd fast float %5148, %4971
  %5152 = fadd fast float %5149, %4972
  %5153 = fadd fast float %5150, %4973
  br label %5154

; <label>:5154                                    ; preds = %5137, %5016, %5010
  %5155 = phi float [ %5151, %5137 ], [ %4971, %5016 ], [ %4971, %5010 ]
  %5156 = phi float [ %5152, %5137 ], [ %4972, %5016 ], [ %4972, %5010 ]
  %5157 = phi float [ %5153, %5137 ], [ %4973, %5016 ], [ %4973, %5010 ]
  %5158 = fadd fast float %6, 1.000000e+00
  %5159 = fadd fast float %7, 1.000000e+00
  %5160 = fsub fast float 1.000000e+00, %6
  %5161 = fmul fast float %37, %5158
  %5162 = fmul fast float %37, %5159
  %5163 = fmul fast float %37, %5160
  %5164 = fmul fast float %5161, %5155
  %5165 = fmul fast float %5162, %5156
  %5166 = fmul fast float %5163, %5157
  %5167 = fcmp fast ult float %38, 5.000000e-01
  br i1 %5167, label %5193, label %5168

; <label>:5168                                    ; preds = %5154
  %5169 = fmul fast float %5164, 0x4004147AE0000000
  %5170 = fmul fast float %5165, 0x4004147AE0000000
  %5171 = fmul fast float %5166, 0x4004147AE0000000
  %5172 = fadd fast float %5169, 0x3F9EB851E0000000
  %5173 = fadd fast float %5170, 0x3F9EB851E0000000
  %5174 = fadd fast float %5171, 0x3F9EB851E0000000
  %5175 = fmul fast float %5172, %5164
  %5176 = fmul fast float %5173, %5165
  %5177 = fmul fast float %5174, %5166
  %5178 = fmul fast float %5164, 0x400370A3E0000000
  %5179 = fmul fast float %5165, 0x400370A3E0000000
  %5180 = fmul fast float %5166, 0x400370A3E0000000
  %5181 = fadd fast float %5178, 0x3FE2E147A0000000
  %5182 = fadd fast float %5179, 0x3FE2E147A0000000
  %5183 = fadd fast float %5180, 0x3FE2E147A0000000
  %5184 = fmul fast float %5181, %5164
  %5185 = fmul fast float %5182, %5165
  %5186 = fmul fast float %5183, %5166
  %5187 = fadd fast float %5184, 0x3FC1EB8520000000
  %5188 = fadd fast float %5185, 0x3FC1EB8520000000
  %5189 = fadd fast float %5186, 0x3FC1EB8520000000
  %5190 = fdiv fast float %5175, %5187
  %5191 = fdiv fast float %5176, %5188
  %5192 = fdiv fast float %5177, %5189
  br label %5193

; <label>:5193                                    ; preds = %5168, %5154
  %5194 = phi float [ %5190, %5168 ], [ %5164, %5154 ]
  %5195 = phi float [ %5191, %5168 ], [ %5165, %5154 ]
  %5196 = phi float [ %5192, %5168 ], [ %5166, %5154 ]
  %5197 = call float @dx.op.unary.f32(i32 7, float %5194)  ; Saturate(value)
  %5198 = call float @dx.op.unary.f32(i32 7, float %5195)  ; Saturate(value)
  %5199 = call float @dx.op.unary.f32(i32 7, float %5196)  ; Saturate(value)
  %5200 = call float @dx.op.dot3.f32(i32 55, float %5197, float %5198, float %5199, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5201 = fsub fast float %5197, %5200
  %5202 = fsub fast float %5198, %5200
  %5203 = fsub fast float %5199, %5200
  %5204 = fmul fast float %5201, %9
  %5205 = fmul fast float %5202, %9
  %5206 = fmul fast float %5203, %9
  %5207 = fadd fast float %5204, %5200
  %5208 = fadd fast float %5205, %5200
  %5209 = fadd fast float %5206, %5200
  %5210 = call float @dx.op.unary.f32(i32 7, float %5207)  ; Saturate(value)
  %5211 = call float @dx.op.unary.f32(i32 7, float %5208)  ; Saturate(value)
  %5212 = call float @dx.op.unary.f32(i32 7, float %5209)  ; Saturate(value)
  %5213 = fadd fast float %5210, 0xBFC70A3D80000000
  %5214 = fadd fast float %5211, 0xBFC70A3D80000000
  %5215 = fadd fast float %5212, 0xBFC70A3D80000000
  %5216 = fmul fast float %5213, %8
  %5217 = fmul fast float %5214, %8
  %5218 = fmul fast float %5215, %8
  %5219 = fadd fast float %5216, 0x3FC70A3D80000000
  %5220 = fadd fast float %5217, 0x3FC70A3D80000000
  %5221 = fadd fast float %5218, 0x3FC70A3D80000000
  %5222 = call float @dx.op.unary.f32(i32 7, float %5219)  ; Saturate(value)
  %5223 = call float @dx.op.unary.f32(i32 7, float %5220)  ; Saturate(value)
  %5224 = call float @dx.op.unary.f32(i32 7, float %5221)  ; Saturate(value)
  br label %5225

; <label>:5225                                    ; preds = %5193, %4976
  %5226 = phi float [ %5007, %4976 ], [ %5222, %5193 ]
  %5227 = phi float [ %5008, %4976 ], [ %5223, %5193 ]
  %5228 = phi float [ %5009, %4976 ], [ %5224, %5193 ]
  %5229 = fsub fast float %5226, %4366
  %5230 = fsub fast float %5227, %4367
  %5231 = fsub fast float %5228, %4368
  %5232 = fmul fast float %5229, %4963
  %5233 = fmul fast float %5230, %4963
  %5234 = fmul fast float %5231, %4963
  %5235 = fadd fast float %5232, %4366
  %5236 = fadd fast float %5233, %4367
  %5237 = fadd fast float %5234, %4368
  br label %5238

; <label>:5238                                    ; preds = %5225, %4948
  %5239 = phi float [ %5235, %5225 ], [ %4366, %4948 ]
  %5240 = phi float [ %5236, %5225 ], [ %4367, %4948 ]
  %5241 = phi float [ %5237, %5225 ], [ %4368, %4948 ]
  %5242 = add i32 %64, 1
  %5243 = call i32 @dx.op.binary.i32(i32 37, i32 %5242, i32 0)  ; IMax(a,b)
  %5244 = call i32 @dx.op.binary.i32(i32 38, i32 %5243, i32 %60)  ; IMin(a,b)
  %5245 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5244, i32 %4956, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5246 = extractvalue %dx.types.ResRet.f32 %5245, 0
  %5247 = fsub fast float %5246, %83
  %5248 = call float @dx.op.unary.f32(i32 6, float %5247)  ; FAbs(value)
  %5249 = fdiv fast float %5248, %4380
  %5250 = fsub fast float 1.000000e+00, %5249
  %5251 = call float @dx.op.unary.f32(i32 7, float %5250)  ; Saturate(value)
  %5252 = fcmp fast ugt float %5251, 0.000000e+00
  br i1 %5252, label %5253, label %5526

; <label>:5253                                    ; preds = %5238
  %5254 = call i32 @dx.op.binary.i32(i32 37, i32 %5244, i32 0)  ; IMax(a,b)
  %5255 = call i32 @dx.op.binary.i32(i32 37, i32 %4956, i32 0)  ; IMax(a,b)
  %5256 = call i32 @dx.op.binary.i32(i32 38, i32 %5254, i32 %60)  ; IMin(a,b)
  %5257 = call i32 @dx.op.binary.i32(i32 38, i32 %5255, i32 %61)  ; IMin(a,b)
  %5258 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %5256, i32 %5257, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5259 = extractvalue %dx.types.ResRet.f32 %5258, 0
  %5260 = extractvalue %dx.types.ResRet.f32 %5258, 1
  %5261 = extractvalue %dx.types.ResRet.f32 %5258, 2
  %5262 = extractvalue %dx.types.ResRet.f32 %5258, 3
  %5263 = fcmp fast olt float %5262, 0.000000e+00
  br i1 %5263, label %5264, label %5298

; <label>:5264                                    ; preds = %5253
  %5265 = fcmp fast ogt float %5259, 0x3FA4B5DCC0000000
  %5266 = fcmp fast ogt float %5260, 0x3FA4B5DCC0000000
  %5267 = fcmp fast ogt float %5261, 0x3FA4B5DCC0000000
  %5268 = select i1 %5265, float 0.000000e+00, float 1.000000e+00
  %5269 = select i1 %5266, float 0.000000e+00, float 1.000000e+00
  %5270 = select i1 %5267, float 0.000000e+00, float 1.000000e+00
  %5271 = fmul fast float %5259, 0x3FB3D07220000000
  %5272 = fmul fast float %5260, 0x3FB3D07220000000
  %5273 = fmul fast float %5261, 0x3FB3D07220000000
  %5274 = fadd fast float %5259, 0x3FAC28F5C0000000
  %5275 = fadd fast float %5260, 0x3FAC28F5C0000000
  %5276 = fadd fast float %5261, 0x3FAC28F5C0000000
  %5277 = fmul fast float %5274, 0x3FEE54EDE0000000
  %5278 = fmul fast float %5275, 0x3FEE54EDE0000000
  %5279 = fmul fast float %5276, 0x3FEE54EDE0000000
  %5280 = call float @dx.op.unary.f32(i32 23, float %5277)  ; Log(value)
  %5281 = call float @dx.op.unary.f32(i32 23, float %5278)  ; Log(value)
  %5282 = call float @dx.op.unary.f32(i32 23, float %5279)  ; Log(value)
  %5283 = fmul fast float %5280, 0x4003333340000000
  %5284 = fmul fast float %5281, 0x4003333340000000
  %5285 = fmul fast float %5282, 0x4003333340000000
  %5286 = call float @dx.op.unary.f32(i32 21, float %5283)  ; Exp(value)
  %5287 = call float @dx.op.unary.f32(i32 21, float %5284)  ; Exp(value)
  %5288 = call float @dx.op.unary.f32(i32 21, float %5285)  ; Exp(value)
  %5289 = fsub fast float %5271, %5286
  %5290 = fsub fast float %5272, %5287
  %5291 = fsub fast float %5273, %5288
  %5292 = fmul fast float %5289, %5268
  %5293 = fmul fast float %5290, %5269
  %5294 = fmul fast float %5291, %5270
  %5295 = fadd fast float %5292, %5286
  %5296 = fadd fast float %5293, %5287
  %5297 = fadd fast float %5294, %5288
  br label %5513

; <label>:5298                                    ; preds = %5253
  %5299 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5256, i32 %5257, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5300 = extractvalue %dx.types.ResRet.f32 %5299, 0
  %5301 = fcmp fast ogt float %39, 5.000000e-01
  %5302 = fcmp fast olt float %5300, 1.000000e+00
  %5303 = and i1 %5301, %5302
  br i1 %5303, label %5304, label %5442

; <label>:5304                                    ; preds = %5298
  %5305 = sitofp i32 %5256 to float
  %5306 = sitofp i32 %5257 to float
  %5307 = fadd fast float %5305, 5.000000e-01
  %5308 = fadd fast float %5306, 5.000000e-01
  %5309 = fdiv fast float %5307, %46
  %5310 = fdiv fast float %5308, %47
  %5311 = fmul fast float %5309, 2.000000e+00
  %5312 = fmul fast float %5310, 2.000000e+00
  %5313 = fadd fast float %5311, -1.000000e+00
  %5314 = fsub fast float 1.000000e+00, %5312
  %5315 = fmul fast float %5313, %36
  %5316 = call float @dx.op.tertiary.f32(i32 46, float %5314, float %32, float %5315)  ; FMad(a,b,c)
  %5317 = call float @dx.op.tertiary.f32(i32 46, float %5300, float %28, float %5316)  ; FMad(a,b,c)
  %5318 = fadd fast float %5317, %24
  %5319 = call float @dx.op.unary.f32(i32 6, float %5318)  ; FAbs(value)
  %5320 = fcmp fast ogt float %5319, 0x3EB0C6F7A0000000
  br i1 %5320, label %5321, label %5442

; <label>:5321                                    ; preds = %5304
  %5322 = fmul fast float %5313, %35
  %5323 = call float @dx.op.tertiary.f32(i32 46, float %5314, float %31, float %5322)  ; FMad(a,b,c)
  %5324 = call float @dx.op.tertiary.f32(i32 46, float %5300, float %27, float %5323)  ; FMad(a,b,c)
  %5325 = fadd fast float %5324, %23
  %5326 = fmul fast float %5313, %34
  %5327 = call float @dx.op.tertiary.f32(i32 46, float %5314, float %30, float %5326)  ; FMad(a,b,c)
  %5328 = call float @dx.op.tertiary.f32(i32 46, float %5300, float %26, float %5327)  ; FMad(a,b,c)
  %5329 = fadd fast float %5328, %22
  %5330 = fmul fast float %5313, %33
  %5331 = call float @dx.op.tertiary.f32(i32 46, float %5314, float %29, float %5330)  ; FMad(a,b,c)
  %5332 = call float @dx.op.tertiary.f32(i32 46, float %5300, float %25, float %5331)  ; FMad(a,b,c)
  %5333 = fadd fast float %5332, %21
  %5334 = fdiv fast float %5333, %5318
  %5335 = fdiv fast float %5329, %5318
  %5336 = fdiv fast float %5325, %5318
  %5337 = fsub fast float %5334, %18
  %5338 = fsub fast float %5335, %19
  %5339 = fsub fast float %5336, %20
  %5340 = fmul fast float %5337, %5337
  %5341 = fmul fast float %5338, %5338
  %5342 = fadd fast float %5341, %5340
  %5343 = fmul fast float %5339, %5339
  %5344 = fadd fast float %5342, %5343
  %5345 = call float @dx.op.unary.f32(i32 24, float %5344)  ; Sqrt(value)
  %5346 = fsub fast float %5345, %10
  %5347 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5346)  ; FMax(a,b)
  %5348 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %5348, label %5349, label %5372

; <label>:5349                                    ; preds = %5321
  %5350 = call float @dx.op.unary.f32(i32 6, float %5338)  ; FAbs(value)
  %5351 = fmul fast float %5350, %12
  %5352 = fcmp fast olt float %5351, 0x3F50624DE0000000
  br i1 %5352, label %5353, label %5356

; <label>:5353                                    ; preds = %5349
  %5354 = fmul fast float %5351, 5.000000e-01
  %5355 = fsub fast float 1.000000e+00, %5354
  br label %5361

; <label>:5356                                    ; preds = %5349
  %5357 = fmul fast float %5351, 0xBFF7154760000000
  %5358 = call float @dx.op.unary.f32(i32 21, float %5357)  ; Exp(value)
  %5359 = fsub fast float 1.000000e+00, %5358
  %5360 = fdiv fast float %5359, %5351
  br label %5361

; <label>:5361                                    ; preds = %5356, %5353
  %5362 = phi float [ %5355, %5353 ], [ %5360, %5356 ]
  %5363 = call float @dx.op.binary.f32(i32 36, float %5335, float %19)  ; FMin(a,b)
  %5364 = fsub fast float %5363, %11
  %5365 = fmul fast float %12, %5364
  %5366 = fsub fast float -0.000000e+00, %5365
  %5367 = call float @dx.op.binary.f32(i32 35, float %5366, float -4.000000e+01)  ; FMax(a,b)
  %5368 = call float @dx.op.binary.f32(i32 36, float %5367, float 5.000000e+00)  ; FMin(a,b)
  %5369 = fmul fast float %5368, 0x3FF7154760000000
  %5370 = call float @dx.op.unary.f32(i32 21, float %5369)  ; Exp(value)
  %5371 = fmul fast float %5370, %5362
  br label %5372

; <label>:5372                                    ; preds = %5361, %5321
  %5373 = phi float [ %5371, %5361 ], [ 1.000000e+00, %5321 ]
  %5374 = fmul fast float %5347, %17
  %5375 = fmul fast float %5374, %5373
  %5376 = fcmp fast ole float %5345, %10
  %5377 = fcmp fast olt float %5345, 0x3F1A36E2E0000000
  %5378 = or i1 %5376, %5377
  br i1 %5378, label %5425, label %5379

; <label>:5379                                    ; preds = %5372
  %5380 = fdiv fast float %10, %5345
  %5381 = fmul fast float %5380, %5337
  %5382 = fmul fast float %5380, %5338
  %5383 = fmul fast float %5380, %5339
  %5384 = fadd fast float %5381, %18
  %5385 = fadd fast float %5382, %19
  %5386 = fadd fast float %5383, %20
  %5387 = fadd fast float %5384, -9.000000e+02
  %5388 = fadd fast float %5385, -1.500000e+01
  %5389 = fadd fast float %5386, -7.500000e+02
  %5390 = fmul fast float %5387, 0x3F62345680000000
  %5391 = fmul fast float %5388, 0x3F62345680000000
  %5392 = fmul fast float %5389, 0x3F62345680000000
  %5393 = call float @dx.op.dot3.f32(i32 55, float %5390, float %5391, float %5392, float %5390, float %5391, float %5392)  ; Dot3(ax,ay,az,bx,by,bz)
  %5394 = fsub fast float 1.000000e+00, %5393
  %5395 = call float @dx.op.unary.f32(i32 7, float %5394)  ; Saturate(value)
  %5396 = fmul fast float %5395, %5395
  %5397 = fadd fast float %5384, %5334
  %5398 = fadd fast float %5385, %5335
  %5399 = fadd fast float %5386, %5336
  %5400 = fmul fast float %5397, 0x3F52345680000000
  %5401 = fadd fast float %5400, -2.000000e+00
  %5402 = fmul fast float %5398, 0x3F52345680000000
  %5403 = fadd fast float %5402, 0xBFA1111120000000
  %5404 = fmul fast float %5399, 0x3F52345680000000
  %5405 = fadd fast float %5404, 0xBFFAAAAAC0000000
  %5406 = call float @dx.op.dot3.f32(i32 55, float %5401, float %5403, float %5405, float %5401, float %5403, float %5405)  ; Dot3(ax,ay,az,bx,by,bz)
  %5407 = fsub fast float 1.000000e+00, %5406
  %5408 = call float @dx.op.unary.f32(i32 7, float %5407)  ; Saturate(value)
  %5409 = fmul fast float %5408, %5408
  %5410 = fmul fast float %5409, 4.000000e+00
  %5411 = fadd fast float %5410, %5396
  %5412 = fadd fast float %5334, -9.000000e+02
  %5413 = fadd fast float %5335, -1.500000e+01
  %5414 = fadd fast float %5336, -7.500000e+02
  %5415 = fmul fast float %5412, 0x3F62345680000000
  %5416 = fmul fast float %5413, 0x3F62345680000000
  %5417 = fmul fast float %5414, 0x3F62345680000000
  %5418 = call float @dx.op.dot3.f32(i32 55, float %5415, float %5416, float %5417, float %5415, float %5416, float %5417)  ; Dot3(ax,ay,az,bx,by,bz)
  %5419 = fsub fast float 1.000000e+00, %5418
  %5420 = call float @dx.op.unary.f32(i32 7, float %5419)  ; Saturate(value)
  %5421 = fmul fast float %5420, %5420
  %5422 = fadd fast float %5411, %5421
  %5423 = fmul fast float %5346, 0x3F25D867E0000000
  %5424 = fmul fast float %5423, %5422
  br label %5425

; <label>:5425                                    ; preds = %5379, %5372
  %5426 = phi float [ %5424, %5379 ], [ 0.000000e+00, %5372 ]
  %5427 = fadd fast float %5426, %5375
  %5428 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %5427)  ; FMin(a,b)
  %5429 = fmul fast float %5428, 0xBFF7154760000000
  %5430 = call float @dx.op.unary.f32(i32 21, float %5429)  ; Exp(value)
  %5431 = fsub fast float 1.000000e+00, %5430
  %5432 = call float @dx.op.binary.f32(i32 36, float %13, float %5431)  ; FMin(a,b)
  %5433 = fsub fast float %14, %5259
  %5434 = fsub fast float %15, %5260
  %5435 = fsub fast float %16, %5261
  %5436 = fmul fast float %5432, %5433
  %5437 = fmul fast float %5432, %5434
  %5438 = fmul fast float %5432, %5435
  %5439 = fadd fast float %5436, %5259
  %5440 = fadd fast float %5437, %5260
  %5441 = fadd fast float %5438, %5261
  br label %5442

; <label>:5442                                    ; preds = %5425, %5304, %5298
  %5443 = phi float [ %5439, %5425 ], [ %5259, %5304 ], [ %5259, %5298 ]
  %5444 = phi float [ %5440, %5425 ], [ %5260, %5304 ], [ %5260, %5298 ]
  %5445 = phi float [ %5441, %5425 ], [ %5261, %5304 ], [ %5261, %5298 ]
  %5446 = fadd fast float %6, 1.000000e+00
  %5447 = fadd fast float %7, 1.000000e+00
  %5448 = fsub fast float 1.000000e+00, %6
  %5449 = fmul fast float %37, %5446
  %5450 = fmul fast float %37, %5447
  %5451 = fmul fast float %37, %5448
  %5452 = fmul fast float %5449, %5443
  %5453 = fmul fast float %5450, %5444
  %5454 = fmul fast float %5451, %5445
  %5455 = fcmp fast ult float %38, 5.000000e-01
  br i1 %5455, label %5481, label %5456

; <label>:5456                                    ; preds = %5442
  %5457 = fmul fast float %5452, 0x4004147AE0000000
  %5458 = fmul fast float %5453, 0x4004147AE0000000
  %5459 = fmul fast float %5454, 0x4004147AE0000000
  %5460 = fadd fast float %5457, 0x3F9EB851E0000000
  %5461 = fadd fast float %5458, 0x3F9EB851E0000000
  %5462 = fadd fast float %5459, 0x3F9EB851E0000000
  %5463 = fmul fast float %5460, %5452
  %5464 = fmul fast float %5461, %5453
  %5465 = fmul fast float %5462, %5454
  %5466 = fmul fast float %5452, 0x400370A3E0000000
  %5467 = fmul fast float %5453, 0x400370A3E0000000
  %5468 = fmul fast float %5454, 0x400370A3E0000000
  %5469 = fadd fast float %5466, 0x3FE2E147A0000000
  %5470 = fadd fast float %5467, 0x3FE2E147A0000000
  %5471 = fadd fast float %5468, 0x3FE2E147A0000000
  %5472 = fmul fast float %5469, %5452
  %5473 = fmul fast float %5470, %5453
  %5474 = fmul fast float %5471, %5454
  %5475 = fadd fast float %5472, 0x3FC1EB8520000000
  %5476 = fadd fast float %5473, 0x3FC1EB8520000000
  %5477 = fadd fast float %5474, 0x3FC1EB8520000000
  %5478 = fdiv fast float %5463, %5475
  %5479 = fdiv fast float %5464, %5476
  %5480 = fdiv fast float %5465, %5477
  br label %5481

; <label>:5481                                    ; preds = %5456, %5442
  %5482 = phi float [ %5478, %5456 ], [ %5452, %5442 ]
  %5483 = phi float [ %5479, %5456 ], [ %5453, %5442 ]
  %5484 = phi float [ %5480, %5456 ], [ %5454, %5442 ]
  %5485 = call float @dx.op.unary.f32(i32 7, float %5482)  ; Saturate(value)
  %5486 = call float @dx.op.unary.f32(i32 7, float %5483)  ; Saturate(value)
  %5487 = call float @dx.op.unary.f32(i32 7, float %5484)  ; Saturate(value)
  %5488 = call float @dx.op.dot3.f32(i32 55, float %5485, float %5486, float %5487, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5489 = fsub fast float %5485, %5488
  %5490 = fsub fast float %5486, %5488
  %5491 = fsub fast float %5487, %5488
  %5492 = fmul fast float %5489, %9
  %5493 = fmul fast float %5490, %9
  %5494 = fmul fast float %5491, %9
  %5495 = fadd fast float %5492, %5488
  %5496 = fadd fast float %5493, %5488
  %5497 = fadd fast float %5494, %5488
  %5498 = call float @dx.op.unary.f32(i32 7, float %5495)  ; Saturate(value)
  %5499 = call float @dx.op.unary.f32(i32 7, float %5496)  ; Saturate(value)
  %5500 = call float @dx.op.unary.f32(i32 7, float %5497)  ; Saturate(value)
  %5501 = fadd fast float %5498, 0xBFC70A3D80000000
  %5502 = fadd fast float %5499, 0xBFC70A3D80000000
  %5503 = fadd fast float %5500, 0xBFC70A3D80000000
  %5504 = fmul fast float %5501, %8
  %5505 = fmul fast float %5502, %8
  %5506 = fmul fast float %5503, %8
  %5507 = fadd fast float %5504, 0x3FC70A3D80000000
  %5508 = fadd fast float %5505, 0x3FC70A3D80000000
  %5509 = fadd fast float %5506, 0x3FC70A3D80000000
  %5510 = call float @dx.op.unary.f32(i32 7, float %5507)  ; Saturate(value)
  %5511 = call float @dx.op.unary.f32(i32 7, float %5508)  ; Saturate(value)
  %5512 = call float @dx.op.unary.f32(i32 7, float %5509)  ; Saturate(value)
  br label %5513

; <label>:5513                                    ; preds = %5481, %5264
  %5514 = phi float [ %5295, %5264 ], [ %5510, %5481 ]
  %5515 = phi float [ %5296, %5264 ], [ %5511, %5481 ]
  %5516 = phi float [ %5297, %5264 ], [ %5512, %5481 ]
  %5517 = fsub fast float %5514, %4366
  %5518 = fsub fast float %5515, %4367
  %5519 = fsub fast float %5516, %4368
  %5520 = fmul fast float %5517, %5251
  %5521 = fmul fast float %5518, %5251
  %5522 = fmul fast float %5519, %5251
  %5523 = fadd fast float %5520, %4366
  %5524 = fadd fast float %5521, %4367
  %5525 = fadd fast float %5522, %4368
  br label %5526

; <label>:5526                                    ; preds = %5513, %5238
  %5527 = phi float [ %5523, %5513 ], [ %4366, %5238 ]
  %5528 = phi float [ %5524, %5513 ], [ %4367, %5238 ]
  %5529 = phi float [ %5525, %5513 ], [ %4368, %5238 ]
  %5530 = call float @dx.op.binary.f32(i32 36, float %5239, float %5527)  ; FMin(a,b)
  %5531 = call float @dx.op.binary.f32(i32 36, float %5240, float %5528)  ; FMin(a,b)
  %5532 = call float @dx.op.binary.f32(i32 36, float %5241, float %5529)  ; FMin(a,b)
  %5533 = call float @dx.op.binary.f32(i32 36, float %4661, float %4949)  ; FMin(a,b)
  %5534 = call float @dx.op.binary.f32(i32 36, float %4662, float %4950)  ; FMin(a,b)
  %5535 = call float @dx.op.binary.f32(i32 36, float %4663, float %4951)  ; FMin(a,b)
  %5536 = call float @dx.op.binary.f32(i32 36, float %5533, float %5530)  ; FMin(a,b)
  %5537 = call float @dx.op.binary.f32(i32 36, float %5534, float %5531)  ; FMin(a,b)
  %5538 = call float @dx.op.binary.f32(i32 36, float %5535, float %5532)  ; FMin(a,b)
  %5539 = call float @dx.op.binary.f32(i32 36, float %4366, float %5536)  ; FMin(a,b)
  %5540 = call float @dx.op.binary.f32(i32 36, float %4367, float %5537)  ; FMin(a,b)
  %5541 = call float @dx.op.binary.f32(i32 36, float %4368, float %5538)  ; FMin(a,b)
  %5542 = call float @dx.op.binary.f32(i32 35, float %5239, float %5527)  ; FMax(a,b)
  %5543 = call float @dx.op.binary.f32(i32 35, float %5240, float %5528)  ; FMax(a,b)
  %5544 = call float @dx.op.binary.f32(i32 35, float %5241, float %5529)  ; FMax(a,b)
  %5545 = call float @dx.op.binary.f32(i32 35, float %4661, float %4949)  ; FMax(a,b)
  %5546 = call float @dx.op.binary.f32(i32 35, float %4662, float %4950)  ; FMax(a,b)
  %5547 = call float @dx.op.binary.f32(i32 35, float %4663, float %4951)  ; FMax(a,b)
  %5548 = call float @dx.op.binary.f32(i32 35, float %5545, float %5542)  ; FMax(a,b)
  %5549 = call float @dx.op.binary.f32(i32 35, float %5546, float %5543)  ; FMax(a,b)
  %5550 = call float @dx.op.binary.f32(i32 35, float %5547, float %5544)  ; FMax(a,b)
  %5551 = call float @dx.op.binary.f32(i32 35, float %4366, float %5548)  ; FMax(a,b)
  %5552 = call float @dx.op.binary.f32(i32 35, float %4367, float %5549)  ; FMax(a,b)
  %5553 = call float @dx.op.binary.f32(i32 35, float %4368, float %5550)  ; FMax(a,b)
  %5554 = fsub fast float %5551, %5539
  %5555 = fsub fast float %5552, %5540
  %5556 = fsub fast float %5553, %5541
  %5557 = call float @dx.op.unary.f32(i32 6, float %5554)  ; FAbs(value)
  %5558 = call float @dx.op.unary.f32(i32 6, float %5555)  ; FAbs(value)
  %5559 = call float @dx.op.unary.f32(i32 6, float %5556)  ; FAbs(value)
  %5560 = call float @dx.op.binary.f32(i32 35, float %5558, float %5559)  ; FMax(a,b)
  %5561 = call float @dx.op.binary.f32(i32 35, float %5557, float %5560)  ; FMax(a,b)
  %5562 = call float @dx.op.binary.f32(i32 35, float %5552, float %5553)  ; FMax(a,b)
  %5563 = call float @dx.op.binary.f32(i32 35, float %5551, float %5562)  ; FMax(a,b)
  %5564 = fmul fast float %5563, 1.250000e-01
  %5565 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %5564)  ; FMax(a,b)
  %5566 = fcmp fast ogt float %5561, %5565
  br i1 %5566, label %5567, label %5629

; <label>:5567                                    ; preds = %5526
  %5568 = fsub fast float %4661, %4949
  %5569 = fsub fast float %4662, %4950
  %5570 = fsub fast float %4663, %4951
  %5571 = call float @dx.op.unary.f32(i32 6, float %5568)  ; FAbs(value)
  %5572 = call float @dx.op.unary.f32(i32 6, float %5569)  ; FAbs(value)
  %5573 = call float @dx.op.unary.f32(i32 6, float %5570)  ; FAbs(value)
  %5574 = call float @dx.op.binary.f32(i32 35, float %5572, float %5573)  ; FMax(a,b)
  %5575 = call float @dx.op.binary.f32(i32 35, float %5571, float %5574)  ; FMax(a,b)
  %5576 = fsub fast float %5239, %5527
  %5577 = fsub fast float %5240, %5528
  %5578 = fsub fast float %5241, %5529
  %5579 = call float @dx.op.unary.f32(i32 6, float %5576)  ; FAbs(value)
  %5580 = call float @dx.op.unary.f32(i32 6, float %5577)  ; FAbs(value)
  %5581 = call float @dx.op.unary.f32(i32 6, float %5578)  ; FAbs(value)
  %5582 = call float @dx.op.binary.f32(i32 35, float %5580, float %5581)  ; FMax(a,b)
  %5583 = call float @dx.op.binary.f32(i32 35, float %5579, float %5582)  ; FMax(a,b)
  %5584 = fcmp fast olt float %5575, %5583
  %5585 = select i1 %5584, float %4661, float %5239
  %5586 = select i1 %5584, float %4662, float %5240
  %5587 = select i1 %5584, float %4663, float %5241
  %5588 = select i1 %5584, float %4949, float %5527
  %5589 = select i1 %5584, float %4950, float %5528
  %5590 = select i1 %5584, float %4951, float %5529
  %5591 = fsub fast float %4366, %5588
  %5592 = fsub fast float %4367, %5589
  %5593 = fsub fast float %4368, %5590
  %5594 = fsub fast float %4366, %5585
  %5595 = fsub fast float %4367, %5586
  %5596 = fsub fast float %4368, %5587
  %5597 = call float @dx.op.dot3.f32(i32 55, float %5594, float %5595, float %5596, float %5591, float %5592, float %5593)  ; Dot3(ax,ay,az,bx,by,bz)
  %5598 = fcmp fast ogt float %5597, 0.000000e+00
  br i1 %5598, label %5599, label %5610

; <label>:5599                                    ; preds = %5567
  %5600 = fsub fast float %5585, %5588
  %5601 = fsub fast float %5586, %5589
  %5602 = fsub fast float %5587, %5590
  %5603 = call float @dx.op.unary.f32(i32 6, float %5600)  ; FAbs(value)
  %5604 = call float @dx.op.unary.f32(i32 6, float %5601)  ; FAbs(value)
  %5605 = call float @dx.op.unary.f32(i32 6, float %5602)  ; FAbs(value)
  %5606 = call float @dx.op.binary.f32(i32 35, float %5604, float %5605)  ; FMax(a,b)
  %5607 = call float @dx.op.binary.f32(i32 35, float %5603, float %5606)  ; FMax(a,b)
  %5608 = fmul fast float %5561, 2.500000e-01
  %5609 = fcmp fast olt float %5607, %5608
  br label %5610

; <label>:5610                                    ; preds = %5599, %5567
  %5611 = phi i1 [ false, %5567 ], [ %5609, %5599 ]
  %5612 = select i1 %5611, float 5.000000e-01, float 1.000000e+00
  %5613 = fmul fast float %5612, %3
  %5614 = fadd fast float %5585, %5588
  %5615 = fadd fast float %5586, %5589
  %5616 = fadd fast float %5587, %5590
  %5617 = fmul fast float %5614, 5.000000e-01
  %5618 = fmul fast float %5615, 5.000000e-01
  %5619 = fmul fast float %5616, 5.000000e-01
  %5620 = fsub fast float %5617, %4366
  %5621 = fsub fast float %5618, %4367
  %5622 = fsub fast float %5619, %4368
  %5623 = fmul fast float %5613, %5620
  %5624 = fmul fast float %5613, %5621
  %5625 = fmul fast float %5613, %5622
  %5626 = fadd fast float %5623, %4366
  %5627 = fadd fast float %5624, %4367
  %5628 = fadd fast float %5625, %4368
  br label %5629

; <label>:5629                                    ; preds = %5610, %5526, %4337, %4121
  %5630 = phi float [ %4152, %4121 ], [ %4366, %4337 ], [ %5626, %5610 ], [ %4366, %5526 ]
  %5631 = phi float [ %4153, %4121 ], [ %4367, %4337 ], [ %5627, %5610 ], [ %4367, %5526 ]
  %5632 = phi float [ %4154, %4121 ], [ %4368, %4337 ], [ %5628, %5610 ], [ %4368, %5526 ]
  %5633 = phi float [ %4155, %4121 ], [ %4119, %4337 ], [ %4119, %5610 ], [ %4119, %5526 ]
  %5634 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %68, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5635 = extractvalue %dx.types.ResRet.f32 %5634, 0
  %5636 = extractvalue %dx.types.ResRet.f32 %5634, 1
  %5637 = extractvalue %dx.types.ResRet.f32 %5634, 2
  %5638 = extractvalue %dx.types.ResRet.f32 %5634, 3
  %5639 = fcmp fast olt float %5638, 0.000000e+00
  br i1 %5639, label %5640, label %5675

; <label>:5640                                    ; preds = %5629
  %5641 = fcmp fast ogt float %5635, 0x3FA4B5DCC0000000
  %5642 = fcmp fast ogt float %5636, 0x3FA4B5DCC0000000
  %5643 = fcmp fast ogt float %5637, 0x3FA4B5DCC0000000
  %5644 = select i1 %5641, float 0.000000e+00, float 1.000000e+00
  %5645 = select i1 %5642, float 0.000000e+00, float 1.000000e+00
  %5646 = select i1 %5643, float 0.000000e+00, float 1.000000e+00
  %5647 = fmul fast float %5635, 0x3FB3D07220000000
  %5648 = fmul fast float %5636, 0x3FB3D07220000000
  %5649 = fmul fast float %5637, 0x3FB3D07220000000
  %5650 = fadd fast float %5635, 0x3FAC28F5C0000000
  %5651 = fadd fast float %5636, 0x3FAC28F5C0000000
  %5652 = fadd fast float %5637, 0x3FAC28F5C0000000
  %5653 = fmul fast float %5650, 0x3FEE54EDE0000000
  %5654 = fmul fast float %5651, 0x3FEE54EDE0000000
  %5655 = fmul fast float %5652, 0x3FEE54EDE0000000
  %5656 = call float @dx.op.unary.f32(i32 23, float %5653)  ; Log(value)
  %5657 = call float @dx.op.unary.f32(i32 23, float %5654)  ; Log(value)
  %5658 = call float @dx.op.unary.f32(i32 23, float %5655)  ; Log(value)
  %5659 = fmul fast float %5656, 0x4003333340000000
  %5660 = fmul fast float %5657, 0x4003333340000000
  %5661 = fmul fast float %5658, 0x4003333340000000
  %5662 = call float @dx.op.unary.f32(i32 21, float %5659)  ; Exp(value)
  %5663 = call float @dx.op.unary.f32(i32 21, float %5660)  ; Exp(value)
  %5664 = call float @dx.op.unary.f32(i32 21, float %5661)  ; Exp(value)
  %5665 = fsub fast float %5647, %5662
  %5666 = fsub fast float %5648, %5663
  %5667 = fsub fast float %5649, %5664
  %5668 = fmul fast float %5665, %5644
  %5669 = fmul fast float %5666, %5645
  %5670 = fmul fast float %5667, %5646
  %5671 = fadd fast float %5668, %5662
  %5672 = fadd fast float %5669, %5663
  %5673 = fadd fast float %5670, %5664
  %5674 = fsub fast float -1.000000e+00, %5638
  br label %7148

; <label>:5675                                    ; preds = %5629
  %5676 = fcmp fast ogt float %39, 5.000000e-01
  %5677 = fcmp fast olt float %85, 1.000000e+00
  %5678 = and i1 %5676, %5677
  br i1 %5678, label %5679, label %5817

; <label>:5679                                    ; preds = %5675
  %5680 = sitofp i32 %68 to float
  %5681 = sitofp i32 %65 to float
  %5682 = fadd fast float %5680, 5.000000e-01
  %5683 = fadd fast float %5681, 5.000000e-01
  %5684 = fdiv fast float %5682, %46
  %5685 = fdiv fast float %5683, %47
  %5686 = fmul fast float %5684, 2.000000e+00
  %5687 = fmul fast float %5685, 2.000000e+00
  %5688 = fadd fast float %5686, -1.000000e+00
  %5689 = fsub fast float 1.000000e+00, %5687
  %5690 = fmul fast float %5688, %36
  %5691 = call float @dx.op.tertiary.f32(i32 46, float %5689, float %32, float %5690)  ; FMad(a,b,c)
  %5692 = call float @dx.op.tertiary.f32(i32 46, float %85, float %28, float %5691)  ; FMad(a,b,c)
  %5693 = fadd fast float %5692, %24
  %5694 = call float @dx.op.unary.f32(i32 6, float %5693)  ; FAbs(value)
  %5695 = fcmp fast ogt float %5694, 0x3EB0C6F7A0000000
  br i1 %5695, label %5696, label %5817

; <label>:5696                                    ; preds = %5679
  %5697 = fmul fast float %5688, %35
  %5698 = call float @dx.op.tertiary.f32(i32 46, float %5689, float %31, float %5697)  ; FMad(a,b,c)
  %5699 = call float @dx.op.tertiary.f32(i32 46, float %85, float %27, float %5698)  ; FMad(a,b,c)
  %5700 = fadd fast float %5699, %23
  %5701 = fmul fast float %5688, %34
  %5702 = call float @dx.op.tertiary.f32(i32 46, float %5689, float %30, float %5701)  ; FMad(a,b,c)
  %5703 = call float @dx.op.tertiary.f32(i32 46, float %85, float %26, float %5702)  ; FMad(a,b,c)
  %5704 = fadd fast float %5703, %22
  %5705 = fmul fast float %5688, %33
  %5706 = call float @dx.op.tertiary.f32(i32 46, float %5689, float %29, float %5705)  ; FMad(a,b,c)
  %5707 = call float @dx.op.tertiary.f32(i32 46, float %85, float %25, float %5706)  ; FMad(a,b,c)
  %5708 = fadd fast float %5707, %21
  %5709 = fdiv fast float %5708, %5693
  %5710 = fdiv fast float %5704, %5693
  %5711 = fdiv fast float %5700, %5693
  %5712 = fsub fast float %5709, %18
  %5713 = fsub fast float %5710, %19
  %5714 = fsub fast float %5711, %20
  %5715 = fmul fast float %5712, %5712
  %5716 = fmul fast float %5713, %5713
  %5717 = fadd fast float %5716, %5715
  %5718 = fmul fast float %5714, %5714
  %5719 = fadd fast float %5717, %5718
  %5720 = call float @dx.op.unary.f32(i32 24, float %5719)  ; Sqrt(value)
  %5721 = fsub fast float %5720, %10
  %5722 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5721)  ; FMax(a,b)
  %5723 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %5723, label %5724, label %5747

; <label>:5724                                    ; preds = %5696
  %5725 = call float @dx.op.unary.f32(i32 6, float %5713)  ; FAbs(value)
  %5726 = fmul fast float %5725, %12
  %5727 = fcmp fast olt float %5726, 0x3F50624DE0000000
  br i1 %5727, label %5728, label %5731

; <label>:5728                                    ; preds = %5724
  %5729 = fmul fast float %5726, 5.000000e-01
  %5730 = fsub fast float 1.000000e+00, %5729
  br label %5736

; <label>:5731                                    ; preds = %5724
  %5732 = fmul fast float %5726, 0xBFF7154760000000
  %5733 = call float @dx.op.unary.f32(i32 21, float %5732)  ; Exp(value)
  %5734 = fsub fast float 1.000000e+00, %5733
  %5735 = fdiv fast float %5734, %5726
  br label %5736

; <label>:5736                                    ; preds = %5731, %5728
  %5737 = phi float [ %5730, %5728 ], [ %5735, %5731 ]
  %5738 = call float @dx.op.binary.f32(i32 36, float %5710, float %19)  ; FMin(a,b)
  %5739 = fsub fast float %5738, %11
  %5740 = fmul fast float %12, %5739
  %5741 = fsub fast float -0.000000e+00, %5740
  %5742 = call float @dx.op.binary.f32(i32 35, float %5741, float -4.000000e+01)  ; FMax(a,b)
  %5743 = call float @dx.op.binary.f32(i32 36, float %5742, float 5.000000e+00)  ; FMin(a,b)
  %5744 = fmul fast float %5743, 0x3FF7154760000000
  %5745 = call float @dx.op.unary.f32(i32 21, float %5744)  ; Exp(value)
  %5746 = fmul fast float %5745, %5737
  br label %5747

; <label>:5747                                    ; preds = %5736, %5696
  %5748 = phi float [ %5746, %5736 ], [ 1.000000e+00, %5696 ]
  %5749 = fmul fast float %5722, %17
  %5750 = fmul fast float %5749, %5748
  %5751 = fcmp fast ole float %5720, %10
  %5752 = fcmp fast olt float %5720, 0x3F1A36E2E0000000
  %5753 = or i1 %5751, %5752
  br i1 %5753, label %5800, label %5754

; <label>:5754                                    ; preds = %5747
  %5755 = fdiv fast float %10, %5720
  %5756 = fmul fast float %5755, %5712
  %5757 = fmul fast float %5755, %5713
  %5758 = fmul fast float %5755, %5714
  %5759 = fadd fast float %5756, %18
  %5760 = fadd fast float %5757, %19
  %5761 = fadd fast float %5758, %20
  %5762 = fadd fast float %5759, -9.000000e+02
  %5763 = fadd fast float %5760, -1.500000e+01
  %5764 = fadd fast float %5761, -7.500000e+02
  %5765 = fmul fast float %5762, 0x3F62345680000000
  %5766 = fmul fast float %5763, 0x3F62345680000000
  %5767 = fmul fast float %5764, 0x3F62345680000000
  %5768 = call float @dx.op.dot3.f32(i32 55, float %5765, float %5766, float %5767, float %5765, float %5766, float %5767)  ; Dot3(ax,ay,az,bx,by,bz)
  %5769 = fsub fast float 1.000000e+00, %5768
  %5770 = call float @dx.op.unary.f32(i32 7, float %5769)  ; Saturate(value)
  %5771 = fmul fast float %5770, %5770
  %5772 = fadd fast float %5759, %5709
  %5773 = fadd fast float %5760, %5710
  %5774 = fadd fast float %5761, %5711
  %5775 = fmul fast float %5772, 0x3F52345680000000
  %5776 = fadd fast float %5775, -2.000000e+00
  %5777 = fmul fast float %5773, 0x3F52345680000000
  %5778 = fadd fast float %5777, 0xBFA1111120000000
  %5779 = fmul fast float %5774, 0x3F52345680000000
  %5780 = fadd fast float %5779, 0xBFFAAAAAC0000000
  %5781 = call float @dx.op.dot3.f32(i32 55, float %5776, float %5778, float %5780, float %5776, float %5778, float %5780)  ; Dot3(ax,ay,az,bx,by,bz)
  %5782 = fsub fast float 1.000000e+00, %5781
  %5783 = call float @dx.op.unary.f32(i32 7, float %5782)  ; Saturate(value)
  %5784 = fmul fast float %5783, %5783
  %5785 = fmul fast float %5784, 4.000000e+00
  %5786 = fadd fast float %5785, %5771
  %5787 = fadd fast float %5709, -9.000000e+02
  %5788 = fadd fast float %5710, -1.500000e+01
  %5789 = fadd fast float %5711, -7.500000e+02
  %5790 = fmul fast float %5787, 0x3F62345680000000
  %5791 = fmul fast float %5788, 0x3F62345680000000
  %5792 = fmul fast float %5789, 0x3F62345680000000
  %5793 = call float @dx.op.dot3.f32(i32 55, float %5790, float %5791, float %5792, float %5790, float %5791, float %5792)  ; Dot3(ax,ay,az,bx,by,bz)
  %5794 = fsub fast float 1.000000e+00, %5793
  %5795 = call float @dx.op.unary.f32(i32 7, float %5794)  ; Saturate(value)
  %5796 = fmul fast float %5795, %5795
  %5797 = fadd fast float %5786, %5796
  %5798 = fmul fast float %5721, 0x3F25D867E0000000
  %5799 = fmul fast float %5798, %5797
  br label %5800

; <label>:5800                                    ; preds = %5754, %5747
  %5801 = phi float [ %5799, %5754 ], [ 0.000000e+00, %5747 ]
  %5802 = fadd fast float %5801, %5750
  %5803 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %5802)  ; FMin(a,b)
  %5804 = fmul fast float %5803, 0xBFF7154760000000
  %5805 = call float @dx.op.unary.f32(i32 21, float %5804)  ; Exp(value)
  %5806 = fsub fast float 1.000000e+00, %5805
  %5807 = call float @dx.op.binary.f32(i32 36, float %13, float %5806)  ; FMin(a,b)
  %5808 = fsub fast float %14, %5635
  %5809 = fsub fast float %15, %5636
  %5810 = fsub fast float %16, %5637
  %5811 = fmul fast float %5807, %5808
  %5812 = fmul fast float %5807, %5809
  %5813 = fmul fast float %5807, %5810
  %5814 = fadd fast float %5811, %5635
  %5815 = fadd fast float %5812, %5636
  %5816 = fadd fast float %5813, %5637
  br label %5817

; <label>:5817                                    ; preds = %5800, %5679, %5675
  %5818 = phi float [ %5814, %5800 ], [ %5635, %5679 ], [ %5635, %5675 ]
  %5819 = phi float [ %5815, %5800 ], [ %5636, %5679 ], [ %5636, %5675 ]
  %5820 = phi float [ %5816, %5800 ], [ %5637, %5679 ], [ %5637, %5675 ]
  %5821 = fadd fast float %6, 1.000000e+00
  %5822 = fadd fast float %7, 1.000000e+00
  %5823 = fsub fast float 1.000000e+00, %6
  %5824 = fmul fast float %37, %5821
  %5825 = fmul fast float %37, %5822
  %5826 = fmul fast float %37, %5823
  %5827 = fmul fast float %5824, %5818
  %5828 = fmul fast float %5825, %5819
  %5829 = fmul fast float %5826, %5820
  %5830 = fcmp fast ult float %38, 5.000000e-01
  br i1 %5830, label %5856, label %5831

; <label>:5831                                    ; preds = %5817
  %5832 = fmul fast float %5827, 0x4004147AE0000000
  %5833 = fmul fast float %5828, 0x4004147AE0000000
  %5834 = fmul fast float %5829, 0x4004147AE0000000
  %5835 = fadd fast float %5832, 0x3F9EB851E0000000
  %5836 = fadd fast float %5833, 0x3F9EB851E0000000
  %5837 = fadd fast float %5834, 0x3F9EB851E0000000
  %5838 = fmul fast float %5835, %5827
  %5839 = fmul fast float %5836, %5828
  %5840 = fmul fast float %5837, %5829
  %5841 = fmul fast float %5827, 0x400370A3E0000000
  %5842 = fmul fast float %5828, 0x400370A3E0000000
  %5843 = fmul fast float %5829, 0x400370A3E0000000
  %5844 = fadd fast float %5841, 0x3FE2E147A0000000
  %5845 = fadd fast float %5842, 0x3FE2E147A0000000
  %5846 = fadd fast float %5843, 0x3FE2E147A0000000
  %5847 = fmul fast float %5844, %5827
  %5848 = fmul fast float %5845, %5828
  %5849 = fmul fast float %5846, %5829
  %5850 = fadd fast float %5847, 0x3FC1EB8520000000
  %5851 = fadd fast float %5848, 0x3FC1EB8520000000
  %5852 = fadd fast float %5849, 0x3FC1EB8520000000
  %5853 = fdiv fast float %5838, %5850
  %5854 = fdiv fast float %5839, %5851
  %5855 = fdiv fast float %5840, %5852
  br label %5856

; <label>:5856                                    ; preds = %5831, %5817
  %5857 = phi float [ %5853, %5831 ], [ %5827, %5817 ]
  %5858 = phi float [ %5854, %5831 ], [ %5828, %5817 ]
  %5859 = phi float [ %5855, %5831 ], [ %5829, %5817 ]
  %5860 = call float @dx.op.unary.f32(i32 7, float %5857)  ; Saturate(value)
  %5861 = call float @dx.op.unary.f32(i32 7, float %5858)  ; Saturate(value)
  %5862 = call float @dx.op.unary.f32(i32 7, float %5859)  ; Saturate(value)
  %5863 = call float @dx.op.dot3.f32(i32 55, float %5860, float %5861, float %5862, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5864 = fsub fast float %5860, %5863
  %5865 = fsub fast float %5861, %5863
  %5866 = fsub fast float %5862, %5863
  %5867 = fmul fast float %5864, %9
  %5868 = fmul fast float %5865, %9
  %5869 = fmul fast float %5866, %9
  %5870 = fadd fast float %5867, %5863
  %5871 = fadd fast float %5868, %5863
  %5872 = fadd fast float %5869, %5863
  %5873 = call float @dx.op.unary.f32(i32 7, float %5870)  ; Saturate(value)
  %5874 = call float @dx.op.unary.f32(i32 7, float %5871)  ; Saturate(value)
  %5875 = call float @dx.op.unary.f32(i32 7, float %5872)  ; Saturate(value)
  %5876 = fadd fast float %5873, 0xBFC70A3D80000000
  %5877 = fadd fast float %5874, 0xBFC70A3D80000000
  %5878 = fadd fast float %5875, 0xBFC70A3D80000000
  %5879 = fmul fast float %5876, %8
  %5880 = fmul fast float %5877, %8
  %5881 = fmul fast float %5878, %8
  %5882 = fadd fast float %5879, 0x3FC70A3D80000000
  %5883 = fadd fast float %5880, 0x3FC70A3D80000000
  %5884 = fadd fast float %5881, 0x3FC70A3D80000000
  %5885 = call float @dx.op.unary.f32(i32 7, float %5882)  ; Saturate(value)
  %5886 = call float @dx.op.unary.f32(i32 7, float %5883)  ; Saturate(value)
  %5887 = call float @dx.op.unary.f32(i32 7, float %5884)  ; Saturate(value)
  %5888 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %5888, label %5889, label %7148

; <label>:5889                                    ; preds = %5856
  %5890 = add i32 %65, -1
  %5891 = call i32 @dx.op.binary.i32(i32 37, i32 %68, i32 0)  ; IMax(a,b)
  %5892 = call i32 @dx.op.binary.i32(i32 37, i32 %5890, i32 0)  ; IMax(a,b)
  %5893 = call i32 @dx.op.binary.i32(i32 38, i32 %5891, i32 %60)  ; IMin(a,b)
  %5894 = call i32 @dx.op.binary.i32(i32 38, i32 %5892, i32 %61)  ; IMin(a,b)
  %5895 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5893, i32 %5894, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5896 = extractvalue %dx.types.ResRet.f32 %5895, 0
  %5897 = fsub fast float 1.000000e+00, %85
  %5898 = fmul fast float %5897, 0x3FA99999A0000000
  %5899 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %5898)  ; FMax(a,b)
  %5900 = fsub fast float %5896, %85
  %5901 = call float @dx.op.unary.f32(i32 6, float %5900)  ; FAbs(value)
  %5902 = fdiv fast float %5901, %5899
  %5903 = fsub fast float 1.000000e+00, %5902
  %5904 = call float @dx.op.unary.f32(i32 7, float %5903)  ; Saturate(value)
  %5905 = fcmp fast ugt float %5904, 0.000000e+00
  br i1 %5905, label %5906, label %6179

; <label>:5906                                    ; preds = %5889
  %5907 = call i32 @dx.op.binary.i32(i32 37, i32 %5893, i32 0)  ; IMax(a,b)
  %5908 = call i32 @dx.op.binary.i32(i32 37, i32 %5894, i32 0)  ; IMax(a,b)
  %5909 = call i32 @dx.op.binary.i32(i32 38, i32 %5907, i32 %60)  ; IMin(a,b)
  %5910 = call i32 @dx.op.binary.i32(i32 38, i32 %5908, i32 %61)  ; IMin(a,b)
  %5911 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %5909, i32 %5910, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5912 = extractvalue %dx.types.ResRet.f32 %5911, 0
  %5913 = extractvalue %dx.types.ResRet.f32 %5911, 1
  %5914 = extractvalue %dx.types.ResRet.f32 %5911, 2
  %5915 = extractvalue %dx.types.ResRet.f32 %5911, 3
  %5916 = fcmp fast olt float %5915, 0.000000e+00
  br i1 %5916, label %5917, label %5951

; <label>:5917                                    ; preds = %5906
  %5918 = fcmp fast ogt float %5912, 0x3FA4B5DCC0000000
  %5919 = fcmp fast ogt float %5913, 0x3FA4B5DCC0000000
  %5920 = fcmp fast ogt float %5914, 0x3FA4B5DCC0000000
  %5921 = select i1 %5918, float 0.000000e+00, float 1.000000e+00
  %5922 = select i1 %5919, float 0.000000e+00, float 1.000000e+00
  %5923 = select i1 %5920, float 0.000000e+00, float 1.000000e+00
  %5924 = fmul fast float %5912, 0x3FB3D07220000000
  %5925 = fmul fast float %5913, 0x3FB3D07220000000
  %5926 = fmul fast float %5914, 0x3FB3D07220000000
  %5927 = fadd fast float %5912, 0x3FAC28F5C0000000
  %5928 = fadd fast float %5913, 0x3FAC28F5C0000000
  %5929 = fadd fast float %5914, 0x3FAC28F5C0000000
  %5930 = fmul fast float %5927, 0x3FEE54EDE0000000
  %5931 = fmul fast float %5928, 0x3FEE54EDE0000000
  %5932 = fmul fast float %5929, 0x3FEE54EDE0000000
  %5933 = call float @dx.op.unary.f32(i32 23, float %5930)  ; Log(value)
  %5934 = call float @dx.op.unary.f32(i32 23, float %5931)  ; Log(value)
  %5935 = call float @dx.op.unary.f32(i32 23, float %5932)  ; Log(value)
  %5936 = fmul fast float %5933, 0x4003333340000000
  %5937 = fmul fast float %5934, 0x4003333340000000
  %5938 = fmul fast float %5935, 0x4003333340000000
  %5939 = call float @dx.op.unary.f32(i32 21, float %5936)  ; Exp(value)
  %5940 = call float @dx.op.unary.f32(i32 21, float %5937)  ; Exp(value)
  %5941 = call float @dx.op.unary.f32(i32 21, float %5938)  ; Exp(value)
  %5942 = fsub fast float %5924, %5939
  %5943 = fsub fast float %5925, %5940
  %5944 = fsub fast float %5926, %5941
  %5945 = fmul fast float %5942, %5921
  %5946 = fmul fast float %5943, %5922
  %5947 = fmul fast float %5944, %5923
  %5948 = fadd fast float %5945, %5939
  %5949 = fadd fast float %5946, %5940
  %5950 = fadd fast float %5947, %5941
  br label %6166

; <label>:5951                                    ; preds = %5906
  %5952 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5909, i32 %5910, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5953 = extractvalue %dx.types.ResRet.f32 %5952, 0
  %5954 = fcmp fast ogt float %39, 5.000000e-01
  %5955 = fcmp fast olt float %5953, 1.000000e+00
  %5956 = and i1 %5954, %5955
  br i1 %5956, label %5957, label %6095

; <label>:5957                                    ; preds = %5951
  %5958 = sitofp i32 %5909 to float
  %5959 = sitofp i32 %5910 to float
  %5960 = fadd fast float %5958, 5.000000e-01
  %5961 = fadd fast float %5959, 5.000000e-01
  %5962 = fdiv fast float %5960, %46
  %5963 = fdiv fast float %5961, %47
  %5964 = fmul fast float %5962, 2.000000e+00
  %5965 = fmul fast float %5963, 2.000000e+00
  %5966 = fadd fast float %5964, -1.000000e+00
  %5967 = fsub fast float 1.000000e+00, %5965
  %5968 = fmul fast float %5966, %36
  %5969 = call float @dx.op.tertiary.f32(i32 46, float %5967, float %32, float %5968)  ; FMad(a,b,c)
  %5970 = call float @dx.op.tertiary.f32(i32 46, float %5953, float %28, float %5969)  ; FMad(a,b,c)
  %5971 = fadd fast float %5970, %24
  %5972 = call float @dx.op.unary.f32(i32 6, float %5971)  ; FAbs(value)
  %5973 = fcmp fast ogt float %5972, 0x3EB0C6F7A0000000
  br i1 %5973, label %5974, label %6095

; <label>:5974                                    ; preds = %5957
  %5975 = fmul fast float %5966, %35
  %5976 = call float @dx.op.tertiary.f32(i32 46, float %5967, float %31, float %5975)  ; FMad(a,b,c)
  %5977 = call float @dx.op.tertiary.f32(i32 46, float %5953, float %27, float %5976)  ; FMad(a,b,c)
  %5978 = fadd fast float %5977, %23
  %5979 = fmul fast float %5966, %34
  %5980 = call float @dx.op.tertiary.f32(i32 46, float %5967, float %30, float %5979)  ; FMad(a,b,c)
  %5981 = call float @dx.op.tertiary.f32(i32 46, float %5953, float %26, float %5980)  ; FMad(a,b,c)
  %5982 = fadd fast float %5981, %22
  %5983 = fmul fast float %5966, %33
  %5984 = call float @dx.op.tertiary.f32(i32 46, float %5967, float %29, float %5983)  ; FMad(a,b,c)
  %5985 = call float @dx.op.tertiary.f32(i32 46, float %5953, float %25, float %5984)  ; FMad(a,b,c)
  %5986 = fadd fast float %5985, %21
  %5987 = fdiv fast float %5986, %5971
  %5988 = fdiv fast float %5982, %5971
  %5989 = fdiv fast float %5978, %5971
  %5990 = fsub fast float %5987, %18
  %5991 = fsub fast float %5988, %19
  %5992 = fsub fast float %5989, %20
  %5993 = fmul fast float %5990, %5990
  %5994 = fmul fast float %5991, %5991
  %5995 = fadd fast float %5994, %5993
  %5996 = fmul fast float %5992, %5992
  %5997 = fadd fast float %5995, %5996
  %5998 = call float @dx.op.unary.f32(i32 24, float %5997)  ; Sqrt(value)
  %5999 = fsub fast float %5998, %10
  %6000 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5999)  ; FMax(a,b)
  %6001 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %6001, label %6002, label %6025

; <label>:6002                                    ; preds = %5974
  %6003 = call float @dx.op.unary.f32(i32 6, float %5991)  ; FAbs(value)
  %6004 = fmul fast float %6003, %12
  %6005 = fcmp fast olt float %6004, 0x3F50624DE0000000
  br i1 %6005, label %6006, label %6009

; <label>:6006                                    ; preds = %6002
  %6007 = fmul fast float %6004, 5.000000e-01
  %6008 = fsub fast float 1.000000e+00, %6007
  br label %6014

; <label>:6009                                    ; preds = %6002
  %6010 = fmul fast float %6004, 0xBFF7154760000000
  %6011 = call float @dx.op.unary.f32(i32 21, float %6010)  ; Exp(value)
  %6012 = fsub fast float 1.000000e+00, %6011
  %6013 = fdiv fast float %6012, %6004
  br label %6014

; <label>:6014                                    ; preds = %6009, %6006
  %6015 = phi float [ %6008, %6006 ], [ %6013, %6009 ]
  %6016 = call float @dx.op.binary.f32(i32 36, float %5988, float %19)  ; FMin(a,b)
  %6017 = fsub fast float %6016, %11
  %6018 = fmul fast float %12, %6017
  %6019 = fsub fast float -0.000000e+00, %6018
  %6020 = call float @dx.op.binary.f32(i32 35, float %6019, float -4.000000e+01)  ; FMax(a,b)
  %6021 = call float @dx.op.binary.f32(i32 36, float %6020, float 5.000000e+00)  ; FMin(a,b)
  %6022 = fmul fast float %6021, 0x3FF7154760000000
  %6023 = call float @dx.op.unary.f32(i32 21, float %6022)  ; Exp(value)
  %6024 = fmul fast float %6023, %6015
  br label %6025

; <label>:6025                                    ; preds = %6014, %5974
  %6026 = phi float [ %6024, %6014 ], [ 1.000000e+00, %5974 ]
  %6027 = fmul fast float %6000, %17
  %6028 = fmul fast float %6027, %6026
  %6029 = fcmp fast ole float %5998, %10
  %6030 = fcmp fast olt float %5998, 0x3F1A36E2E0000000
  %6031 = or i1 %6029, %6030
  br i1 %6031, label %6078, label %6032

; <label>:6032                                    ; preds = %6025
  %6033 = fdiv fast float %10, %5998
  %6034 = fmul fast float %6033, %5990
  %6035 = fmul fast float %6033, %5991
  %6036 = fmul fast float %6033, %5992
  %6037 = fadd fast float %6034, %18
  %6038 = fadd fast float %6035, %19
  %6039 = fadd fast float %6036, %20
  %6040 = fadd fast float %6037, -9.000000e+02
  %6041 = fadd fast float %6038, -1.500000e+01
  %6042 = fadd fast float %6039, -7.500000e+02
  %6043 = fmul fast float %6040, 0x3F62345680000000
  %6044 = fmul fast float %6041, 0x3F62345680000000
  %6045 = fmul fast float %6042, 0x3F62345680000000
  %6046 = call float @dx.op.dot3.f32(i32 55, float %6043, float %6044, float %6045, float %6043, float %6044, float %6045)  ; Dot3(ax,ay,az,bx,by,bz)
  %6047 = fsub fast float 1.000000e+00, %6046
  %6048 = call float @dx.op.unary.f32(i32 7, float %6047)  ; Saturate(value)
  %6049 = fmul fast float %6048, %6048
  %6050 = fadd fast float %6037, %5987
  %6051 = fadd fast float %6038, %5988
  %6052 = fadd fast float %6039, %5989
  %6053 = fmul fast float %6050, 0x3F52345680000000
  %6054 = fadd fast float %6053, -2.000000e+00
  %6055 = fmul fast float %6051, 0x3F52345680000000
  %6056 = fadd fast float %6055, 0xBFA1111120000000
  %6057 = fmul fast float %6052, 0x3F52345680000000
  %6058 = fadd fast float %6057, 0xBFFAAAAAC0000000
  %6059 = call float @dx.op.dot3.f32(i32 55, float %6054, float %6056, float %6058, float %6054, float %6056, float %6058)  ; Dot3(ax,ay,az,bx,by,bz)
  %6060 = fsub fast float 1.000000e+00, %6059
  %6061 = call float @dx.op.unary.f32(i32 7, float %6060)  ; Saturate(value)
  %6062 = fmul fast float %6061, %6061
  %6063 = fmul fast float %6062, 4.000000e+00
  %6064 = fadd fast float %6063, %6049
  %6065 = fadd fast float %5987, -9.000000e+02
  %6066 = fadd fast float %5988, -1.500000e+01
  %6067 = fadd fast float %5989, -7.500000e+02
  %6068 = fmul fast float %6065, 0x3F62345680000000
  %6069 = fmul fast float %6066, 0x3F62345680000000
  %6070 = fmul fast float %6067, 0x3F62345680000000
  %6071 = call float @dx.op.dot3.f32(i32 55, float %6068, float %6069, float %6070, float %6068, float %6069, float %6070)  ; Dot3(ax,ay,az,bx,by,bz)
  %6072 = fsub fast float 1.000000e+00, %6071
  %6073 = call float @dx.op.unary.f32(i32 7, float %6072)  ; Saturate(value)
  %6074 = fmul fast float %6073, %6073
  %6075 = fadd fast float %6064, %6074
  %6076 = fmul fast float %5999, 0x3F25D867E0000000
  %6077 = fmul fast float %6076, %6075
  br label %6078

; <label>:6078                                    ; preds = %6032, %6025
  %6079 = phi float [ %6077, %6032 ], [ 0.000000e+00, %6025 ]
  %6080 = fadd fast float %6079, %6028
  %6081 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %6080)  ; FMin(a,b)
  %6082 = fmul fast float %6081, 0xBFF7154760000000
  %6083 = call float @dx.op.unary.f32(i32 21, float %6082)  ; Exp(value)
  %6084 = fsub fast float 1.000000e+00, %6083
  %6085 = call float @dx.op.binary.f32(i32 36, float %13, float %6084)  ; FMin(a,b)
  %6086 = fsub fast float %14, %5912
  %6087 = fsub fast float %15, %5913
  %6088 = fsub fast float %16, %5914
  %6089 = fmul fast float %6085, %6086
  %6090 = fmul fast float %6085, %6087
  %6091 = fmul fast float %6085, %6088
  %6092 = fadd fast float %6089, %5912
  %6093 = fadd fast float %6090, %5913
  %6094 = fadd fast float %6091, %5914
  br label %6095

; <label>:6095                                    ; preds = %6078, %5957, %5951
  %6096 = phi float [ %6092, %6078 ], [ %5912, %5957 ], [ %5912, %5951 ]
  %6097 = phi float [ %6093, %6078 ], [ %5913, %5957 ], [ %5913, %5951 ]
  %6098 = phi float [ %6094, %6078 ], [ %5914, %5957 ], [ %5914, %5951 ]
  %6099 = fadd fast float %6, 1.000000e+00
  %6100 = fadd fast float %7, 1.000000e+00
  %6101 = fsub fast float 1.000000e+00, %6
  %6102 = fmul fast float %37, %6099
  %6103 = fmul fast float %37, %6100
  %6104 = fmul fast float %37, %6101
  %6105 = fmul fast float %6102, %6096
  %6106 = fmul fast float %6103, %6097
  %6107 = fmul fast float %6104, %6098
  %6108 = fcmp fast ult float %38, 5.000000e-01
  br i1 %6108, label %6134, label %6109

; <label>:6109                                    ; preds = %6095
  %6110 = fmul fast float %6105, 0x4004147AE0000000
  %6111 = fmul fast float %6106, 0x4004147AE0000000
  %6112 = fmul fast float %6107, 0x4004147AE0000000
  %6113 = fadd fast float %6110, 0x3F9EB851E0000000
  %6114 = fadd fast float %6111, 0x3F9EB851E0000000
  %6115 = fadd fast float %6112, 0x3F9EB851E0000000
  %6116 = fmul fast float %6113, %6105
  %6117 = fmul fast float %6114, %6106
  %6118 = fmul fast float %6115, %6107
  %6119 = fmul fast float %6105, 0x400370A3E0000000
  %6120 = fmul fast float %6106, 0x400370A3E0000000
  %6121 = fmul fast float %6107, 0x400370A3E0000000
  %6122 = fadd fast float %6119, 0x3FE2E147A0000000
  %6123 = fadd fast float %6120, 0x3FE2E147A0000000
  %6124 = fadd fast float %6121, 0x3FE2E147A0000000
  %6125 = fmul fast float %6122, %6105
  %6126 = fmul fast float %6123, %6106
  %6127 = fmul fast float %6124, %6107
  %6128 = fadd fast float %6125, 0x3FC1EB8520000000
  %6129 = fadd fast float %6126, 0x3FC1EB8520000000
  %6130 = fadd fast float %6127, 0x3FC1EB8520000000
  %6131 = fdiv fast float %6116, %6128
  %6132 = fdiv fast float %6117, %6129
  %6133 = fdiv fast float %6118, %6130
  br label %6134

; <label>:6134                                    ; preds = %6109, %6095
  %6135 = phi float [ %6131, %6109 ], [ %6105, %6095 ]
  %6136 = phi float [ %6132, %6109 ], [ %6106, %6095 ]
  %6137 = phi float [ %6133, %6109 ], [ %6107, %6095 ]
  %6138 = call float @dx.op.unary.f32(i32 7, float %6135)  ; Saturate(value)
  %6139 = call float @dx.op.unary.f32(i32 7, float %6136)  ; Saturate(value)
  %6140 = call float @dx.op.unary.f32(i32 7, float %6137)  ; Saturate(value)
  %6141 = call float @dx.op.dot3.f32(i32 55, float %6138, float %6139, float %6140, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %6142 = fsub fast float %6138, %6141
  %6143 = fsub fast float %6139, %6141
  %6144 = fsub fast float %6140, %6141
  %6145 = fmul fast float %6142, %9
  %6146 = fmul fast float %6143, %9
  %6147 = fmul fast float %6144, %9
  %6148 = fadd fast float %6145, %6141
  %6149 = fadd fast float %6146, %6141
  %6150 = fadd fast float %6147, %6141
  %6151 = call float @dx.op.unary.f32(i32 7, float %6148)  ; Saturate(value)
  %6152 = call float @dx.op.unary.f32(i32 7, float %6149)  ; Saturate(value)
  %6153 = call float @dx.op.unary.f32(i32 7, float %6150)  ; Saturate(value)
  %6154 = fadd fast float %6151, 0xBFC70A3D80000000
  %6155 = fadd fast float %6152, 0xBFC70A3D80000000
  %6156 = fadd fast float %6153, 0xBFC70A3D80000000
  %6157 = fmul fast float %6154, %8
  %6158 = fmul fast float %6155, %8
  %6159 = fmul fast float %6156, %8
  %6160 = fadd fast float %6157, 0x3FC70A3D80000000
  %6161 = fadd fast float %6158, 0x3FC70A3D80000000
  %6162 = fadd fast float %6159, 0x3FC70A3D80000000
  %6163 = call float @dx.op.unary.f32(i32 7, float %6160)  ; Saturate(value)
  %6164 = call float @dx.op.unary.f32(i32 7, float %6161)  ; Saturate(value)
  %6165 = call float @dx.op.unary.f32(i32 7, float %6162)  ; Saturate(value)
  br label %6166

; <label>:6166                                    ; preds = %6134, %5917
  %6167 = phi float [ %5948, %5917 ], [ %6163, %6134 ]
  %6168 = phi float [ %5949, %5917 ], [ %6164, %6134 ]
  %6169 = phi float [ %5950, %5917 ], [ %6165, %6134 ]
  %6170 = fsub fast float %6167, %5885
  %6171 = fsub fast float %6168, %5886
  %6172 = fsub fast float %6169, %5887
  %6173 = fmul fast float %6170, %5904
  %6174 = fmul fast float %6171, %5904
  %6175 = fmul fast float %6172, %5904
  %6176 = fadd fast float %6173, %5885
  %6177 = fadd fast float %6174, %5886
  %6178 = fadd fast float %6175, %5887
  br label %6179

; <label>:6179                                    ; preds = %6166, %5889
  %6180 = phi float [ %6176, %6166 ], [ %5885, %5889 ]
  %6181 = phi float [ %6177, %6166 ], [ %5886, %5889 ]
  %6182 = phi float [ %6178, %6166 ], [ %5887, %5889 ]
  %6183 = add i32 %65, 1
  %6184 = call i32 @dx.op.binary.i32(i32 37, i32 %6183, i32 0)  ; IMax(a,b)
  %6185 = call i32 @dx.op.binary.i32(i32 38, i32 %6184, i32 %61)  ; IMin(a,b)
  %6186 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5893, i32 %6185, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6187 = extractvalue %dx.types.ResRet.f32 %6186, 0
  %6188 = fsub fast float %6187, %85
  %6189 = call float @dx.op.unary.f32(i32 6, float %6188)  ; FAbs(value)
  %6190 = fdiv fast float %6189, %5899
  %6191 = fsub fast float 1.000000e+00, %6190
  %6192 = call float @dx.op.unary.f32(i32 7, float %6191)  ; Saturate(value)
  %6193 = fcmp fast ugt float %6192, 0.000000e+00
  br i1 %6193, label %6194, label %6467

; <label>:6194                                    ; preds = %6179
  %6195 = call i32 @dx.op.binary.i32(i32 37, i32 %5893, i32 0)  ; IMax(a,b)
  %6196 = call i32 @dx.op.binary.i32(i32 37, i32 %6185, i32 0)  ; IMax(a,b)
  %6197 = call i32 @dx.op.binary.i32(i32 38, i32 %6195, i32 %60)  ; IMin(a,b)
  %6198 = call i32 @dx.op.binary.i32(i32 38, i32 %6196, i32 %61)  ; IMin(a,b)
  %6199 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %6197, i32 %6198, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6200 = extractvalue %dx.types.ResRet.f32 %6199, 0
  %6201 = extractvalue %dx.types.ResRet.f32 %6199, 1
  %6202 = extractvalue %dx.types.ResRet.f32 %6199, 2
  %6203 = extractvalue %dx.types.ResRet.f32 %6199, 3
  %6204 = fcmp fast olt float %6203, 0.000000e+00
  br i1 %6204, label %6205, label %6239

; <label>:6205                                    ; preds = %6194
  %6206 = fcmp fast ogt float %6200, 0x3FA4B5DCC0000000
  %6207 = fcmp fast ogt float %6201, 0x3FA4B5DCC0000000
  %6208 = fcmp fast ogt float %6202, 0x3FA4B5DCC0000000
  %6209 = select i1 %6206, float 0.000000e+00, float 1.000000e+00
  %6210 = select i1 %6207, float 0.000000e+00, float 1.000000e+00
  %6211 = select i1 %6208, float 0.000000e+00, float 1.000000e+00
  %6212 = fmul fast float %6200, 0x3FB3D07220000000
  %6213 = fmul fast float %6201, 0x3FB3D07220000000
  %6214 = fmul fast float %6202, 0x3FB3D07220000000
  %6215 = fadd fast float %6200, 0x3FAC28F5C0000000
  %6216 = fadd fast float %6201, 0x3FAC28F5C0000000
  %6217 = fadd fast float %6202, 0x3FAC28F5C0000000
  %6218 = fmul fast float %6215, 0x3FEE54EDE0000000
  %6219 = fmul fast float %6216, 0x3FEE54EDE0000000
  %6220 = fmul fast float %6217, 0x3FEE54EDE0000000
  %6221 = call float @dx.op.unary.f32(i32 23, float %6218)  ; Log(value)
  %6222 = call float @dx.op.unary.f32(i32 23, float %6219)  ; Log(value)
  %6223 = call float @dx.op.unary.f32(i32 23, float %6220)  ; Log(value)
  %6224 = fmul fast float %6221, 0x4003333340000000
  %6225 = fmul fast float %6222, 0x4003333340000000
  %6226 = fmul fast float %6223, 0x4003333340000000
  %6227 = call float @dx.op.unary.f32(i32 21, float %6224)  ; Exp(value)
  %6228 = call float @dx.op.unary.f32(i32 21, float %6225)  ; Exp(value)
  %6229 = call float @dx.op.unary.f32(i32 21, float %6226)  ; Exp(value)
  %6230 = fsub fast float %6212, %6227
  %6231 = fsub fast float %6213, %6228
  %6232 = fsub fast float %6214, %6229
  %6233 = fmul fast float %6230, %6209
  %6234 = fmul fast float %6231, %6210
  %6235 = fmul fast float %6232, %6211
  %6236 = fadd fast float %6233, %6227
  %6237 = fadd fast float %6234, %6228
  %6238 = fadd fast float %6235, %6229
  br label %6454

; <label>:6239                                    ; preds = %6194
  %6240 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %6197, i32 %6198, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6241 = extractvalue %dx.types.ResRet.f32 %6240, 0
  %6242 = fcmp fast ogt float %39, 5.000000e-01
  %6243 = fcmp fast olt float %6241, 1.000000e+00
  %6244 = and i1 %6242, %6243
  br i1 %6244, label %6245, label %6383

; <label>:6245                                    ; preds = %6239
  %6246 = sitofp i32 %6197 to float
  %6247 = sitofp i32 %6198 to float
  %6248 = fadd fast float %6246, 5.000000e-01
  %6249 = fadd fast float %6247, 5.000000e-01
  %6250 = fdiv fast float %6248, %46
  %6251 = fdiv fast float %6249, %47
  %6252 = fmul fast float %6250, 2.000000e+00
  %6253 = fmul fast float %6251, 2.000000e+00
  %6254 = fadd fast float %6252, -1.000000e+00
  %6255 = fsub fast float 1.000000e+00, %6253
  %6256 = fmul fast float %6254, %36
  %6257 = call float @dx.op.tertiary.f32(i32 46, float %6255, float %32, float %6256)  ; FMad(a,b,c)
  %6258 = call float @dx.op.tertiary.f32(i32 46, float %6241, float %28, float %6257)  ; FMad(a,b,c)
  %6259 = fadd fast float %6258, %24
  %6260 = call float @dx.op.unary.f32(i32 6, float %6259)  ; FAbs(value)
  %6261 = fcmp fast ogt float %6260, 0x3EB0C6F7A0000000
  br i1 %6261, label %6262, label %6383

; <label>:6262                                    ; preds = %6245
  %6263 = fmul fast float %6254, %35
  %6264 = call float @dx.op.tertiary.f32(i32 46, float %6255, float %31, float %6263)  ; FMad(a,b,c)
  %6265 = call float @dx.op.tertiary.f32(i32 46, float %6241, float %27, float %6264)  ; FMad(a,b,c)
  %6266 = fadd fast float %6265, %23
  %6267 = fmul fast float %6254, %34
  %6268 = call float @dx.op.tertiary.f32(i32 46, float %6255, float %30, float %6267)  ; FMad(a,b,c)
  %6269 = call float @dx.op.tertiary.f32(i32 46, float %6241, float %26, float %6268)  ; FMad(a,b,c)
  %6270 = fadd fast float %6269, %22
  %6271 = fmul fast float %6254, %33
  %6272 = call float @dx.op.tertiary.f32(i32 46, float %6255, float %29, float %6271)  ; FMad(a,b,c)
  %6273 = call float @dx.op.tertiary.f32(i32 46, float %6241, float %25, float %6272)  ; FMad(a,b,c)
  %6274 = fadd fast float %6273, %21
  %6275 = fdiv fast float %6274, %6259
  %6276 = fdiv fast float %6270, %6259
  %6277 = fdiv fast float %6266, %6259
  %6278 = fsub fast float %6275, %18
  %6279 = fsub fast float %6276, %19
  %6280 = fsub fast float %6277, %20
  %6281 = fmul fast float %6278, %6278
  %6282 = fmul fast float %6279, %6279
  %6283 = fadd fast float %6282, %6281
  %6284 = fmul fast float %6280, %6280
  %6285 = fadd fast float %6283, %6284
  %6286 = call float @dx.op.unary.f32(i32 24, float %6285)  ; Sqrt(value)
  %6287 = fsub fast float %6286, %10
  %6288 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %6287)  ; FMax(a,b)
  %6289 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %6289, label %6290, label %6313

; <label>:6290                                    ; preds = %6262
  %6291 = call float @dx.op.unary.f32(i32 6, float %6279)  ; FAbs(value)
  %6292 = fmul fast float %6291, %12
  %6293 = fcmp fast olt float %6292, 0x3F50624DE0000000
  br i1 %6293, label %6294, label %6297

; <label>:6294                                    ; preds = %6290
  %6295 = fmul fast float %6292, 5.000000e-01
  %6296 = fsub fast float 1.000000e+00, %6295
  br label %6302

; <label>:6297                                    ; preds = %6290
  %6298 = fmul fast float %6292, 0xBFF7154760000000
  %6299 = call float @dx.op.unary.f32(i32 21, float %6298)  ; Exp(value)
  %6300 = fsub fast float 1.000000e+00, %6299
  %6301 = fdiv fast float %6300, %6292
  br label %6302

; <label>:6302                                    ; preds = %6297, %6294
  %6303 = phi float [ %6296, %6294 ], [ %6301, %6297 ]
  %6304 = call float @dx.op.binary.f32(i32 36, float %6276, float %19)  ; FMin(a,b)
  %6305 = fsub fast float %6304, %11
  %6306 = fmul fast float %12, %6305
  %6307 = fsub fast float -0.000000e+00, %6306
  %6308 = call float @dx.op.binary.f32(i32 35, float %6307, float -4.000000e+01)  ; FMax(a,b)
  %6309 = call float @dx.op.binary.f32(i32 36, float %6308, float 5.000000e+00)  ; FMin(a,b)
  %6310 = fmul fast float %6309, 0x3FF7154760000000
  %6311 = call float @dx.op.unary.f32(i32 21, float %6310)  ; Exp(value)
  %6312 = fmul fast float %6311, %6303
  br label %6313

; <label>:6313                                    ; preds = %6302, %6262
  %6314 = phi float [ %6312, %6302 ], [ 1.000000e+00, %6262 ]
  %6315 = fmul fast float %6288, %17
  %6316 = fmul fast float %6315, %6314
  %6317 = fcmp fast ole float %6286, %10
  %6318 = fcmp fast olt float %6286, 0x3F1A36E2E0000000
  %6319 = or i1 %6317, %6318
  br i1 %6319, label %6366, label %6320

; <label>:6320                                    ; preds = %6313
  %6321 = fdiv fast float %10, %6286
  %6322 = fmul fast float %6321, %6278
  %6323 = fmul fast float %6321, %6279
  %6324 = fmul fast float %6321, %6280
  %6325 = fadd fast float %6322, %18
  %6326 = fadd fast float %6323, %19
  %6327 = fadd fast float %6324, %20
  %6328 = fadd fast float %6325, -9.000000e+02
  %6329 = fadd fast float %6326, -1.500000e+01
  %6330 = fadd fast float %6327, -7.500000e+02
  %6331 = fmul fast float %6328, 0x3F62345680000000
  %6332 = fmul fast float %6329, 0x3F62345680000000
  %6333 = fmul fast float %6330, 0x3F62345680000000
  %6334 = call float @dx.op.dot3.f32(i32 55, float %6331, float %6332, float %6333, float %6331, float %6332, float %6333)  ; Dot3(ax,ay,az,bx,by,bz)
  %6335 = fsub fast float 1.000000e+00, %6334
  %6336 = call float @dx.op.unary.f32(i32 7, float %6335)  ; Saturate(value)
  %6337 = fmul fast float %6336, %6336
  %6338 = fadd fast float %6325, %6275
  %6339 = fadd fast float %6326, %6276
  %6340 = fadd fast float %6327, %6277
  %6341 = fmul fast float %6338, 0x3F52345680000000
  %6342 = fadd fast float %6341, -2.000000e+00
  %6343 = fmul fast float %6339, 0x3F52345680000000
  %6344 = fadd fast float %6343, 0xBFA1111120000000
  %6345 = fmul fast float %6340, 0x3F52345680000000
  %6346 = fadd fast float %6345, 0xBFFAAAAAC0000000
  %6347 = call float @dx.op.dot3.f32(i32 55, float %6342, float %6344, float %6346, float %6342, float %6344, float %6346)  ; Dot3(ax,ay,az,bx,by,bz)
  %6348 = fsub fast float 1.000000e+00, %6347
  %6349 = call float @dx.op.unary.f32(i32 7, float %6348)  ; Saturate(value)
  %6350 = fmul fast float %6349, %6349
  %6351 = fmul fast float %6350, 4.000000e+00
  %6352 = fadd fast float %6351, %6337
  %6353 = fadd fast float %6275, -9.000000e+02
  %6354 = fadd fast float %6276, -1.500000e+01
  %6355 = fadd fast float %6277, -7.500000e+02
  %6356 = fmul fast float %6353, 0x3F62345680000000
  %6357 = fmul fast float %6354, 0x3F62345680000000
  %6358 = fmul fast float %6355, 0x3F62345680000000
  %6359 = call float @dx.op.dot3.f32(i32 55, float %6356, float %6357, float %6358, float %6356, float %6357, float %6358)  ; Dot3(ax,ay,az,bx,by,bz)
  %6360 = fsub fast float 1.000000e+00, %6359
  %6361 = call float @dx.op.unary.f32(i32 7, float %6360)  ; Saturate(value)
  %6362 = fmul fast float %6361, %6361
  %6363 = fadd fast float %6352, %6362
  %6364 = fmul fast float %6287, 0x3F25D867E0000000
  %6365 = fmul fast float %6364, %6363
  br label %6366

; <label>:6366                                    ; preds = %6320, %6313
  %6367 = phi float [ %6365, %6320 ], [ 0.000000e+00, %6313 ]
  %6368 = fadd fast float %6367, %6316
  %6369 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %6368)  ; FMin(a,b)
  %6370 = fmul fast float %6369, 0xBFF7154760000000
  %6371 = call float @dx.op.unary.f32(i32 21, float %6370)  ; Exp(value)
  %6372 = fsub fast float 1.000000e+00, %6371
  %6373 = call float @dx.op.binary.f32(i32 36, float %13, float %6372)  ; FMin(a,b)
  %6374 = fsub fast float %14, %6200
  %6375 = fsub fast float %15, %6201
  %6376 = fsub fast float %16, %6202
  %6377 = fmul fast float %6373, %6374
  %6378 = fmul fast float %6373, %6375
  %6379 = fmul fast float %6373, %6376
  %6380 = fadd fast float %6377, %6200
  %6381 = fadd fast float %6378, %6201
  %6382 = fadd fast float %6379, %6202
  br label %6383

; <label>:6383                                    ; preds = %6366, %6245, %6239
  %6384 = phi float [ %6380, %6366 ], [ %6200, %6245 ], [ %6200, %6239 ]
  %6385 = phi float [ %6381, %6366 ], [ %6201, %6245 ], [ %6201, %6239 ]
  %6386 = phi float [ %6382, %6366 ], [ %6202, %6245 ], [ %6202, %6239 ]
  %6387 = fadd fast float %6, 1.000000e+00
  %6388 = fadd fast float %7, 1.000000e+00
  %6389 = fsub fast float 1.000000e+00, %6
  %6390 = fmul fast float %37, %6387
  %6391 = fmul fast float %37, %6388
  %6392 = fmul fast float %37, %6389
  %6393 = fmul fast float %6390, %6384
  %6394 = fmul fast float %6391, %6385
  %6395 = fmul fast float %6392, %6386
  %6396 = fcmp fast ult float %38, 5.000000e-01
  br i1 %6396, label %6422, label %6397

; <label>:6397                                    ; preds = %6383
  %6398 = fmul fast float %6393, 0x4004147AE0000000
  %6399 = fmul fast float %6394, 0x4004147AE0000000
  %6400 = fmul fast float %6395, 0x4004147AE0000000
  %6401 = fadd fast float %6398, 0x3F9EB851E0000000
  %6402 = fadd fast float %6399, 0x3F9EB851E0000000
  %6403 = fadd fast float %6400, 0x3F9EB851E0000000
  %6404 = fmul fast float %6401, %6393
  %6405 = fmul fast float %6402, %6394
  %6406 = fmul fast float %6403, %6395
  %6407 = fmul fast float %6393, 0x400370A3E0000000
  %6408 = fmul fast float %6394, 0x400370A3E0000000
  %6409 = fmul fast float %6395, 0x400370A3E0000000
  %6410 = fadd fast float %6407, 0x3FE2E147A0000000
  %6411 = fadd fast float %6408, 0x3FE2E147A0000000
  %6412 = fadd fast float %6409, 0x3FE2E147A0000000
  %6413 = fmul fast float %6410, %6393
  %6414 = fmul fast float %6411, %6394
  %6415 = fmul fast float %6412, %6395
  %6416 = fadd fast float %6413, 0x3FC1EB8520000000
  %6417 = fadd fast float %6414, 0x3FC1EB8520000000
  %6418 = fadd fast float %6415, 0x3FC1EB8520000000
  %6419 = fdiv fast float %6404, %6416
  %6420 = fdiv fast float %6405, %6417
  %6421 = fdiv fast float %6406, %6418
  br label %6422

; <label>:6422                                    ; preds = %6397, %6383
  %6423 = phi float [ %6419, %6397 ], [ %6393, %6383 ]
  %6424 = phi float [ %6420, %6397 ], [ %6394, %6383 ]
  %6425 = phi float [ %6421, %6397 ], [ %6395, %6383 ]
  %6426 = call float @dx.op.unary.f32(i32 7, float %6423)  ; Saturate(value)
  %6427 = call float @dx.op.unary.f32(i32 7, float %6424)  ; Saturate(value)
  %6428 = call float @dx.op.unary.f32(i32 7, float %6425)  ; Saturate(value)
  %6429 = call float @dx.op.dot3.f32(i32 55, float %6426, float %6427, float %6428, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %6430 = fsub fast float %6426, %6429
  %6431 = fsub fast float %6427, %6429
  %6432 = fsub fast float %6428, %6429
  %6433 = fmul fast float %6430, %9
  %6434 = fmul fast float %6431, %9
  %6435 = fmul fast float %6432, %9
  %6436 = fadd fast float %6433, %6429
  %6437 = fadd fast float %6434, %6429
  %6438 = fadd fast float %6435, %6429
  %6439 = call float @dx.op.unary.f32(i32 7, float %6436)  ; Saturate(value)
  %6440 = call float @dx.op.unary.f32(i32 7, float %6437)  ; Saturate(value)
  %6441 = call float @dx.op.unary.f32(i32 7, float %6438)  ; Saturate(value)
  %6442 = fadd fast float %6439, 0xBFC70A3D80000000
  %6443 = fadd fast float %6440, 0xBFC70A3D80000000
  %6444 = fadd fast float %6441, 0xBFC70A3D80000000
  %6445 = fmul fast float %6442, %8
  %6446 = fmul fast float %6443, %8
  %6447 = fmul fast float %6444, %8
  %6448 = fadd fast float %6445, 0x3FC70A3D80000000
  %6449 = fadd fast float %6446, 0x3FC70A3D80000000
  %6450 = fadd fast float %6447, 0x3FC70A3D80000000
  %6451 = call float @dx.op.unary.f32(i32 7, float %6448)  ; Saturate(value)
  %6452 = call float @dx.op.unary.f32(i32 7, float %6449)  ; Saturate(value)
  %6453 = call float @dx.op.unary.f32(i32 7, float %6450)  ; Saturate(value)
  br label %6454

; <label>:6454                                    ; preds = %6422, %6205
  %6455 = phi float [ %6236, %6205 ], [ %6451, %6422 ]
  %6456 = phi float [ %6237, %6205 ], [ %6452, %6422 ]
  %6457 = phi float [ %6238, %6205 ], [ %6453, %6422 ]
  %6458 = fsub fast float %6455, %5885
  %6459 = fsub fast float %6456, %5886
  %6460 = fsub fast float %6457, %5887
  %6461 = fmul fast float %6458, %6192
  %6462 = fmul fast float %6459, %6192
  %6463 = fmul fast float %6460, %6192
  %6464 = fadd fast float %6461, %5885
  %6465 = fadd fast float %6462, %5886
  %6466 = fadd fast float %6463, %5887
  br label %6467

; <label>:6467                                    ; preds = %6454, %6179
  %6468 = phi float [ %6464, %6454 ], [ %5885, %6179 ]
  %6469 = phi float [ %6465, %6454 ], [ %5886, %6179 ]
  %6470 = phi float [ %6466, %6454 ], [ %5887, %6179 ]
  %6471 = add i32 %68, -1
  %6472 = call i32 @dx.op.binary.i32(i32 37, i32 %6471, i32 0)  ; IMax(a,b)
  %6473 = call i32 @dx.op.binary.i32(i32 37, i32 %65, i32 0)  ; IMax(a,b)
  %6474 = call i32 @dx.op.binary.i32(i32 38, i32 %6472, i32 %60)  ; IMin(a,b)
  %6475 = call i32 @dx.op.binary.i32(i32 38, i32 %6473, i32 %61)  ; IMin(a,b)
  %6476 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %6474, i32 %6475, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6477 = extractvalue %dx.types.ResRet.f32 %6476, 0
  %6478 = fsub fast float %6477, %85
  %6479 = call float @dx.op.unary.f32(i32 6, float %6478)  ; FAbs(value)
  %6480 = fdiv fast float %6479, %5899
  %6481 = fsub fast float 1.000000e+00, %6480
  %6482 = call float @dx.op.unary.f32(i32 7, float %6481)  ; Saturate(value)
  %6483 = fcmp fast ugt float %6482, 0.000000e+00
  br i1 %6483, label %6484, label %6757

; <label>:6484                                    ; preds = %6467
  %6485 = call i32 @dx.op.binary.i32(i32 37, i32 %6474, i32 0)  ; IMax(a,b)
  %6486 = call i32 @dx.op.binary.i32(i32 37, i32 %6475, i32 0)  ; IMax(a,b)
  %6487 = call i32 @dx.op.binary.i32(i32 38, i32 %6485, i32 %60)  ; IMin(a,b)
  %6488 = call i32 @dx.op.binary.i32(i32 38, i32 %6486, i32 %61)  ; IMin(a,b)
  %6489 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %6487, i32 %6488, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6490 = extractvalue %dx.types.ResRet.f32 %6489, 0
  %6491 = extractvalue %dx.types.ResRet.f32 %6489, 1
  %6492 = extractvalue %dx.types.ResRet.f32 %6489, 2
  %6493 = extractvalue %dx.types.ResRet.f32 %6489, 3
  %6494 = fcmp fast olt float %6493, 0.000000e+00
  br i1 %6494, label %6495, label %6529

; <label>:6495                                    ; preds = %6484
  %6496 = fcmp fast ogt float %6490, 0x3FA4B5DCC0000000
  %6497 = fcmp fast ogt float %6491, 0x3FA4B5DCC0000000
  %6498 = fcmp fast ogt float %6492, 0x3FA4B5DCC0000000
  %6499 = select i1 %6496, float 0.000000e+00, float 1.000000e+00
  %6500 = select i1 %6497, float 0.000000e+00, float 1.000000e+00
  %6501 = select i1 %6498, float 0.000000e+00, float 1.000000e+00
  %6502 = fmul fast float %6490, 0x3FB3D07220000000
  %6503 = fmul fast float %6491, 0x3FB3D07220000000
  %6504 = fmul fast float %6492, 0x3FB3D07220000000
  %6505 = fadd fast float %6490, 0x3FAC28F5C0000000
  %6506 = fadd fast float %6491, 0x3FAC28F5C0000000
  %6507 = fadd fast float %6492, 0x3FAC28F5C0000000
  %6508 = fmul fast float %6505, 0x3FEE54EDE0000000
  %6509 = fmul fast float %6506, 0x3FEE54EDE0000000
  %6510 = fmul fast float %6507, 0x3FEE54EDE0000000
  %6511 = call float @dx.op.unary.f32(i32 23, float %6508)  ; Log(value)
  %6512 = call float @dx.op.unary.f32(i32 23, float %6509)  ; Log(value)
  %6513 = call float @dx.op.unary.f32(i32 23, float %6510)  ; Log(value)
  %6514 = fmul fast float %6511, 0x4003333340000000
  %6515 = fmul fast float %6512, 0x4003333340000000
  %6516 = fmul fast float %6513, 0x4003333340000000
  %6517 = call float @dx.op.unary.f32(i32 21, float %6514)  ; Exp(value)
  %6518 = call float @dx.op.unary.f32(i32 21, float %6515)  ; Exp(value)
  %6519 = call float @dx.op.unary.f32(i32 21, float %6516)  ; Exp(value)
  %6520 = fsub fast float %6502, %6517
  %6521 = fsub fast float %6503, %6518
  %6522 = fsub fast float %6504, %6519
  %6523 = fmul fast float %6520, %6499
  %6524 = fmul fast float %6521, %6500
  %6525 = fmul fast float %6522, %6501
  %6526 = fadd fast float %6523, %6517
  %6527 = fadd fast float %6524, %6518
  %6528 = fadd fast float %6525, %6519
  br label %6744

; <label>:6529                                    ; preds = %6484
  %6530 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %6487, i32 %6488, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6531 = extractvalue %dx.types.ResRet.f32 %6530, 0
  %6532 = fcmp fast ogt float %39, 5.000000e-01
  %6533 = fcmp fast olt float %6531, 1.000000e+00
  %6534 = and i1 %6532, %6533
  br i1 %6534, label %6535, label %6673

; <label>:6535                                    ; preds = %6529
  %6536 = sitofp i32 %6487 to float
  %6537 = sitofp i32 %6488 to float
  %6538 = fadd fast float %6536, 5.000000e-01
  %6539 = fadd fast float %6537, 5.000000e-01
  %6540 = fdiv fast float %6538, %46
  %6541 = fdiv fast float %6539, %47
  %6542 = fmul fast float %6540, 2.000000e+00
  %6543 = fmul fast float %6541, 2.000000e+00
  %6544 = fadd fast float %6542, -1.000000e+00
  %6545 = fsub fast float 1.000000e+00, %6543
  %6546 = fmul fast float %6544, %36
  %6547 = call float @dx.op.tertiary.f32(i32 46, float %6545, float %32, float %6546)  ; FMad(a,b,c)
  %6548 = call float @dx.op.tertiary.f32(i32 46, float %6531, float %28, float %6547)  ; FMad(a,b,c)
  %6549 = fadd fast float %6548, %24
  %6550 = call float @dx.op.unary.f32(i32 6, float %6549)  ; FAbs(value)
  %6551 = fcmp fast ogt float %6550, 0x3EB0C6F7A0000000
  br i1 %6551, label %6552, label %6673

; <label>:6552                                    ; preds = %6535
  %6553 = fmul fast float %6544, %35
  %6554 = call float @dx.op.tertiary.f32(i32 46, float %6545, float %31, float %6553)  ; FMad(a,b,c)
  %6555 = call float @dx.op.tertiary.f32(i32 46, float %6531, float %27, float %6554)  ; FMad(a,b,c)
  %6556 = fadd fast float %6555, %23
  %6557 = fmul fast float %6544, %34
  %6558 = call float @dx.op.tertiary.f32(i32 46, float %6545, float %30, float %6557)  ; FMad(a,b,c)
  %6559 = call float @dx.op.tertiary.f32(i32 46, float %6531, float %26, float %6558)  ; FMad(a,b,c)
  %6560 = fadd fast float %6559, %22
  %6561 = fmul fast float %6544, %33
  %6562 = call float @dx.op.tertiary.f32(i32 46, float %6545, float %29, float %6561)  ; FMad(a,b,c)
  %6563 = call float @dx.op.tertiary.f32(i32 46, float %6531, float %25, float %6562)  ; FMad(a,b,c)
  %6564 = fadd fast float %6563, %21
  %6565 = fdiv fast float %6564, %6549
  %6566 = fdiv fast float %6560, %6549
  %6567 = fdiv fast float %6556, %6549
  %6568 = fsub fast float %6565, %18
  %6569 = fsub fast float %6566, %19
  %6570 = fsub fast float %6567, %20
  %6571 = fmul fast float %6568, %6568
  %6572 = fmul fast float %6569, %6569
  %6573 = fadd fast float %6572, %6571
  %6574 = fmul fast float %6570, %6570
  %6575 = fadd fast float %6573, %6574
  %6576 = call float @dx.op.unary.f32(i32 24, float %6575)  ; Sqrt(value)
  %6577 = fsub fast float %6576, %10
  %6578 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %6577)  ; FMax(a,b)
  %6579 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %6579, label %6580, label %6603

; <label>:6580                                    ; preds = %6552
  %6581 = call float @dx.op.unary.f32(i32 6, float %6569)  ; FAbs(value)
  %6582 = fmul fast float %6581, %12
  %6583 = fcmp fast olt float %6582, 0x3F50624DE0000000
  br i1 %6583, label %6584, label %6587

; <label>:6584                                    ; preds = %6580
  %6585 = fmul fast float %6582, 5.000000e-01
  %6586 = fsub fast float 1.000000e+00, %6585
  br label %6592

; <label>:6587                                    ; preds = %6580
  %6588 = fmul fast float %6582, 0xBFF7154760000000
  %6589 = call float @dx.op.unary.f32(i32 21, float %6588)  ; Exp(value)
  %6590 = fsub fast float 1.000000e+00, %6589
  %6591 = fdiv fast float %6590, %6582
  br label %6592

; <label>:6592                                    ; preds = %6587, %6584
  %6593 = phi float [ %6586, %6584 ], [ %6591, %6587 ]
  %6594 = call float @dx.op.binary.f32(i32 36, float %6566, float %19)  ; FMin(a,b)
  %6595 = fsub fast float %6594, %11
  %6596 = fmul fast float %12, %6595
  %6597 = fsub fast float -0.000000e+00, %6596
  %6598 = call float @dx.op.binary.f32(i32 35, float %6597, float -4.000000e+01)  ; FMax(a,b)
  %6599 = call float @dx.op.binary.f32(i32 36, float %6598, float 5.000000e+00)  ; FMin(a,b)
  %6600 = fmul fast float %6599, 0x3FF7154760000000
  %6601 = call float @dx.op.unary.f32(i32 21, float %6600)  ; Exp(value)
  %6602 = fmul fast float %6601, %6593
  br label %6603

; <label>:6603                                    ; preds = %6592, %6552
  %6604 = phi float [ %6602, %6592 ], [ 1.000000e+00, %6552 ]
  %6605 = fmul fast float %6578, %17
  %6606 = fmul fast float %6605, %6604
  %6607 = fcmp fast ole float %6576, %10
  %6608 = fcmp fast olt float %6576, 0x3F1A36E2E0000000
  %6609 = or i1 %6607, %6608
  br i1 %6609, label %6656, label %6610

; <label>:6610                                    ; preds = %6603
  %6611 = fdiv fast float %10, %6576
  %6612 = fmul fast float %6611, %6568
  %6613 = fmul fast float %6611, %6569
  %6614 = fmul fast float %6611, %6570
  %6615 = fadd fast float %6612, %18
  %6616 = fadd fast float %6613, %19
  %6617 = fadd fast float %6614, %20
  %6618 = fadd fast float %6615, -9.000000e+02
  %6619 = fadd fast float %6616, -1.500000e+01
  %6620 = fadd fast float %6617, -7.500000e+02
  %6621 = fmul fast float %6618, 0x3F62345680000000
  %6622 = fmul fast float %6619, 0x3F62345680000000
  %6623 = fmul fast float %6620, 0x3F62345680000000
  %6624 = call float @dx.op.dot3.f32(i32 55, float %6621, float %6622, float %6623, float %6621, float %6622, float %6623)  ; Dot3(ax,ay,az,bx,by,bz)
  %6625 = fsub fast float 1.000000e+00, %6624
  %6626 = call float @dx.op.unary.f32(i32 7, float %6625)  ; Saturate(value)
  %6627 = fmul fast float %6626, %6626
  %6628 = fadd fast float %6615, %6565
  %6629 = fadd fast float %6616, %6566
  %6630 = fadd fast float %6617, %6567
  %6631 = fmul fast float %6628, 0x3F52345680000000
  %6632 = fadd fast float %6631, -2.000000e+00
  %6633 = fmul fast float %6629, 0x3F52345680000000
  %6634 = fadd fast float %6633, 0xBFA1111120000000
  %6635 = fmul fast float %6630, 0x3F52345680000000
  %6636 = fadd fast float %6635, 0xBFFAAAAAC0000000
  %6637 = call float @dx.op.dot3.f32(i32 55, float %6632, float %6634, float %6636, float %6632, float %6634, float %6636)  ; Dot3(ax,ay,az,bx,by,bz)
  %6638 = fsub fast float 1.000000e+00, %6637
  %6639 = call float @dx.op.unary.f32(i32 7, float %6638)  ; Saturate(value)
  %6640 = fmul fast float %6639, %6639
  %6641 = fmul fast float %6640, 4.000000e+00
  %6642 = fadd fast float %6641, %6627
  %6643 = fadd fast float %6565, -9.000000e+02
  %6644 = fadd fast float %6566, -1.500000e+01
  %6645 = fadd fast float %6567, -7.500000e+02
  %6646 = fmul fast float %6643, 0x3F62345680000000
  %6647 = fmul fast float %6644, 0x3F62345680000000
  %6648 = fmul fast float %6645, 0x3F62345680000000
  %6649 = call float @dx.op.dot3.f32(i32 55, float %6646, float %6647, float %6648, float %6646, float %6647, float %6648)  ; Dot3(ax,ay,az,bx,by,bz)
  %6650 = fsub fast float 1.000000e+00, %6649
  %6651 = call float @dx.op.unary.f32(i32 7, float %6650)  ; Saturate(value)
  %6652 = fmul fast float %6651, %6651
  %6653 = fadd fast float %6642, %6652
  %6654 = fmul fast float %6577, 0x3F25D867E0000000
  %6655 = fmul fast float %6654, %6653
  br label %6656

; <label>:6656                                    ; preds = %6610, %6603
  %6657 = phi float [ %6655, %6610 ], [ 0.000000e+00, %6603 ]
  %6658 = fadd fast float %6657, %6606
  %6659 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %6658)  ; FMin(a,b)
  %6660 = fmul fast float %6659, 0xBFF7154760000000
  %6661 = call float @dx.op.unary.f32(i32 21, float %6660)  ; Exp(value)
  %6662 = fsub fast float 1.000000e+00, %6661
  %6663 = call float @dx.op.binary.f32(i32 36, float %13, float %6662)  ; FMin(a,b)
  %6664 = fsub fast float %14, %6490
  %6665 = fsub fast float %15, %6491
  %6666 = fsub fast float %16, %6492
  %6667 = fmul fast float %6663, %6664
  %6668 = fmul fast float %6663, %6665
  %6669 = fmul fast float %6663, %6666
  %6670 = fadd fast float %6667, %6490
  %6671 = fadd fast float %6668, %6491
  %6672 = fadd fast float %6669, %6492
  br label %6673

; <label>:6673                                    ; preds = %6656, %6535, %6529
  %6674 = phi float [ %6670, %6656 ], [ %6490, %6535 ], [ %6490, %6529 ]
  %6675 = phi float [ %6671, %6656 ], [ %6491, %6535 ], [ %6491, %6529 ]
  %6676 = phi float [ %6672, %6656 ], [ %6492, %6535 ], [ %6492, %6529 ]
  %6677 = fadd fast float %6, 1.000000e+00
  %6678 = fadd fast float %7, 1.000000e+00
  %6679 = fsub fast float 1.000000e+00, %6
  %6680 = fmul fast float %37, %6677
  %6681 = fmul fast float %37, %6678
  %6682 = fmul fast float %37, %6679
  %6683 = fmul fast float %6680, %6674
  %6684 = fmul fast float %6681, %6675
  %6685 = fmul fast float %6682, %6676
  %6686 = fcmp fast ult float %38, 5.000000e-01
  br i1 %6686, label %6712, label %6687

; <label>:6687                                    ; preds = %6673
  %6688 = fmul fast float %6683, 0x4004147AE0000000
  %6689 = fmul fast float %6684, 0x4004147AE0000000
  %6690 = fmul fast float %6685, 0x4004147AE0000000
  %6691 = fadd fast float %6688, 0x3F9EB851E0000000
  %6692 = fadd fast float %6689, 0x3F9EB851E0000000
  %6693 = fadd fast float %6690, 0x3F9EB851E0000000
  %6694 = fmul fast float %6691, %6683
  %6695 = fmul fast float %6692, %6684
  %6696 = fmul fast float %6693, %6685
  %6697 = fmul fast float %6683, 0x400370A3E0000000
  %6698 = fmul fast float %6684, 0x400370A3E0000000
  %6699 = fmul fast float %6685, 0x400370A3E0000000
  %6700 = fadd fast float %6697, 0x3FE2E147A0000000
  %6701 = fadd fast float %6698, 0x3FE2E147A0000000
  %6702 = fadd fast float %6699, 0x3FE2E147A0000000
  %6703 = fmul fast float %6700, %6683
  %6704 = fmul fast float %6701, %6684
  %6705 = fmul fast float %6702, %6685
  %6706 = fadd fast float %6703, 0x3FC1EB8520000000
  %6707 = fadd fast float %6704, 0x3FC1EB8520000000
  %6708 = fadd fast float %6705, 0x3FC1EB8520000000
  %6709 = fdiv fast float %6694, %6706
  %6710 = fdiv fast float %6695, %6707
  %6711 = fdiv fast float %6696, %6708
  br label %6712

; <label>:6712                                    ; preds = %6687, %6673
  %6713 = phi float [ %6709, %6687 ], [ %6683, %6673 ]
  %6714 = phi float [ %6710, %6687 ], [ %6684, %6673 ]
  %6715 = phi float [ %6711, %6687 ], [ %6685, %6673 ]
  %6716 = call float @dx.op.unary.f32(i32 7, float %6713)  ; Saturate(value)
  %6717 = call float @dx.op.unary.f32(i32 7, float %6714)  ; Saturate(value)
  %6718 = call float @dx.op.unary.f32(i32 7, float %6715)  ; Saturate(value)
  %6719 = call float @dx.op.dot3.f32(i32 55, float %6716, float %6717, float %6718, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %6720 = fsub fast float %6716, %6719
  %6721 = fsub fast float %6717, %6719
  %6722 = fsub fast float %6718, %6719
  %6723 = fmul fast float %6720, %9
  %6724 = fmul fast float %6721, %9
  %6725 = fmul fast float %6722, %9
  %6726 = fadd fast float %6723, %6719
  %6727 = fadd fast float %6724, %6719
  %6728 = fadd fast float %6725, %6719
  %6729 = call float @dx.op.unary.f32(i32 7, float %6726)  ; Saturate(value)
  %6730 = call float @dx.op.unary.f32(i32 7, float %6727)  ; Saturate(value)
  %6731 = call float @dx.op.unary.f32(i32 7, float %6728)  ; Saturate(value)
  %6732 = fadd fast float %6729, 0xBFC70A3D80000000
  %6733 = fadd fast float %6730, 0xBFC70A3D80000000
  %6734 = fadd fast float %6731, 0xBFC70A3D80000000
  %6735 = fmul fast float %6732, %8
  %6736 = fmul fast float %6733, %8
  %6737 = fmul fast float %6734, %8
  %6738 = fadd fast float %6735, 0x3FC70A3D80000000
  %6739 = fadd fast float %6736, 0x3FC70A3D80000000
  %6740 = fadd fast float %6737, 0x3FC70A3D80000000
  %6741 = call float @dx.op.unary.f32(i32 7, float %6738)  ; Saturate(value)
  %6742 = call float @dx.op.unary.f32(i32 7, float %6739)  ; Saturate(value)
  %6743 = call float @dx.op.unary.f32(i32 7, float %6740)  ; Saturate(value)
  br label %6744

; <label>:6744                                    ; preds = %6712, %6495
  %6745 = phi float [ %6526, %6495 ], [ %6741, %6712 ]
  %6746 = phi float [ %6527, %6495 ], [ %6742, %6712 ]
  %6747 = phi float [ %6528, %6495 ], [ %6743, %6712 ]
  %6748 = fsub fast float %6745, %5885
  %6749 = fsub fast float %6746, %5886
  %6750 = fsub fast float %6747, %5887
  %6751 = fmul fast float %6748, %6482
  %6752 = fmul fast float %6749, %6482
  %6753 = fmul fast float %6750, %6482
  %6754 = fadd fast float %6751, %5885
  %6755 = fadd fast float %6752, %5886
  %6756 = fadd fast float %6753, %5887
  br label %6757

; <label>:6757                                    ; preds = %6744, %6467
  %6758 = phi float [ %6754, %6744 ], [ %5885, %6467 ]
  %6759 = phi float [ %6755, %6744 ], [ %5886, %6467 ]
  %6760 = phi float [ %6756, %6744 ], [ %5887, %6467 ]
  %6761 = add i32 %68, 1
  %6762 = call i32 @dx.op.binary.i32(i32 37, i32 %6761, i32 0)  ; IMax(a,b)
  %6763 = call i32 @dx.op.binary.i32(i32 38, i32 %6762, i32 %60)  ; IMin(a,b)
  %6764 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %6763, i32 %6475, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6765 = extractvalue %dx.types.ResRet.f32 %6764, 0
  %6766 = fsub fast float %6765, %85
  %6767 = call float @dx.op.unary.f32(i32 6, float %6766)  ; FAbs(value)
  %6768 = fdiv fast float %6767, %5899
  %6769 = fsub fast float 1.000000e+00, %6768
  %6770 = call float @dx.op.unary.f32(i32 7, float %6769)  ; Saturate(value)
  %6771 = fcmp fast ugt float %6770, 0.000000e+00
  br i1 %6771, label %6772, label %7045

; <label>:6772                                    ; preds = %6757
  %6773 = call i32 @dx.op.binary.i32(i32 37, i32 %6763, i32 0)  ; IMax(a,b)
  %6774 = call i32 @dx.op.binary.i32(i32 37, i32 %6475, i32 0)  ; IMax(a,b)
  %6775 = call i32 @dx.op.binary.i32(i32 38, i32 %6773, i32 %60)  ; IMin(a,b)
  %6776 = call i32 @dx.op.binary.i32(i32 38, i32 %6774, i32 %61)  ; IMin(a,b)
  %6777 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %6775, i32 %6776, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6778 = extractvalue %dx.types.ResRet.f32 %6777, 0
  %6779 = extractvalue %dx.types.ResRet.f32 %6777, 1
  %6780 = extractvalue %dx.types.ResRet.f32 %6777, 2
  %6781 = extractvalue %dx.types.ResRet.f32 %6777, 3
  %6782 = fcmp fast olt float %6781, 0.000000e+00
  br i1 %6782, label %6783, label %6817

; <label>:6783                                    ; preds = %6772
  %6784 = fcmp fast ogt float %6778, 0x3FA4B5DCC0000000
  %6785 = fcmp fast ogt float %6779, 0x3FA4B5DCC0000000
  %6786 = fcmp fast ogt float %6780, 0x3FA4B5DCC0000000
  %6787 = select i1 %6784, float 0.000000e+00, float 1.000000e+00
  %6788 = select i1 %6785, float 0.000000e+00, float 1.000000e+00
  %6789 = select i1 %6786, float 0.000000e+00, float 1.000000e+00
  %6790 = fmul fast float %6778, 0x3FB3D07220000000
  %6791 = fmul fast float %6779, 0x3FB3D07220000000
  %6792 = fmul fast float %6780, 0x3FB3D07220000000
  %6793 = fadd fast float %6778, 0x3FAC28F5C0000000
  %6794 = fadd fast float %6779, 0x3FAC28F5C0000000
  %6795 = fadd fast float %6780, 0x3FAC28F5C0000000
  %6796 = fmul fast float %6793, 0x3FEE54EDE0000000
  %6797 = fmul fast float %6794, 0x3FEE54EDE0000000
  %6798 = fmul fast float %6795, 0x3FEE54EDE0000000
  %6799 = call float @dx.op.unary.f32(i32 23, float %6796)  ; Log(value)
  %6800 = call float @dx.op.unary.f32(i32 23, float %6797)  ; Log(value)
  %6801 = call float @dx.op.unary.f32(i32 23, float %6798)  ; Log(value)
  %6802 = fmul fast float %6799, 0x4003333340000000
  %6803 = fmul fast float %6800, 0x4003333340000000
  %6804 = fmul fast float %6801, 0x4003333340000000
  %6805 = call float @dx.op.unary.f32(i32 21, float %6802)  ; Exp(value)
  %6806 = call float @dx.op.unary.f32(i32 21, float %6803)  ; Exp(value)
  %6807 = call float @dx.op.unary.f32(i32 21, float %6804)  ; Exp(value)
  %6808 = fsub fast float %6790, %6805
  %6809 = fsub fast float %6791, %6806
  %6810 = fsub fast float %6792, %6807
  %6811 = fmul fast float %6808, %6787
  %6812 = fmul fast float %6809, %6788
  %6813 = fmul fast float %6810, %6789
  %6814 = fadd fast float %6811, %6805
  %6815 = fadd fast float %6812, %6806
  %6816 = fadd fast float %6813, %6807
  br label %7032

; <label>:6817                                    ; preds = %6772
  %6818 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %6775, i32 %6776, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6819 = extractvalue %dx.types.ResRet.f32 %6818, 0
  %6820 = fcmp fast ogt float %39, 5.000000e-01
  %6821 = fcmp fast olt float %6819, 1.000000e+00
  %6822 = and i1 %6820, %6821
  br i1 %6822, label %6823, label %6961

; <label>:6823                                    ; preds = %6817
  %6824 = sitofp i32 %6775 to float
  %6825 = sitofp i32 %6776 to float
  %6826 = fadd fast float %6824, 5.000000e-01
  %6827 = fadd fast float %6825, 5.000000e-01
  %6828 = fdiv fast float %6826, %46
  %6829 = fdiv fast float %6827, %47
  %6830 = fmul fast float %6828, 2.000000e+00
  %6831 = fmul fast float %6829, 2.000000e+00
  %6832 = fadd fast float %6830, -1.000000e+00
  %6833 = fsub fast float 1.000000e+00, %6831
  %6834 = fmul fast float %6832, %36
  %6835 = call float @dx.op.tertiary.f32(i32 46, float %6833, float %32, float %6834)  ; FMad(a,b,c)
  %6836 = call float @dx.op.tertiary.f32(i32 46, float %6819, float %28, float %6835)  ; FMad(a,b,c)
  %6837 = fadd fast float %6836, %24
  %6838 = call float @dx.op.unary.f32(i32 6, float %6837)  ; FAbs(value)
  %6839 = fcmp fast ogt float %6838, 0x3EB0C6F7A0000000
  br i1 %6839, label %6840, label %6961

; <label>:6840                                    ; preds = %6823
  %6841 = fmul fast float %6832, %35
  %6842 = call float @dx.op.tertiary.f32(i32 46, float %6833, float %31, float %6841)  ; FMad(a,b,c)
  %6843 = call float @dx.op.tertiary.f32(i32 46, float %6819, float %27, float %6842)  ; FMad(a,b,c)
  %6844 = fadd fast float %6843, %23
  %6845 = fmul fast float %6832, %34
  %6846 = call float @dx.op.tertiary.f32(i32 46, float %6833, float %30, float %6845)  ; FMad(a,b,c)
  %6847 = call float @dx.op.tertiary.f32(i32 46, float %6819, float %26, float %6846)  ; FMad(a,b,c)
  %6848 = fadd fast float %6847, %22
  %6849 = fmul fast float %6832, %33
  %6850 = call float @dx.op.tertiary.f32(i32 46, float %6833, float %29, float %6849)  ; FMad(a,b,c)
  %6851 = call float @dx.op.tertiary.f32(i32 46, float %6819, float %25, float %6850)  ; FMad(a,b,c)
  %6852 = fadd fast float %6851, %21
  %6853 = fdiv fast float %6852, %6837
  %6854 = fdiv fast float %6848, %6837
  %6855 = fdiv fast float %6844, %6837
  %6856 = fsub fast float %6853, %18
  %6857 = fsub fast float %6854, %19
  %6858 = fsub fast float %6855, %20
  %6859 = fmul fast float %6856, %6856
  %6860 = fmul fast float %6857, %6857
  %6861 = fadd fast float %6860, %6859
  %6862 = fmul fast float %6858, %6858
  %6863 = fadd fast float %6861, %6862
  %6864 = call float @dx.op.unary.f32(i32 24, float %6863)  ; Sqrt(value)
  %6865 = fsub fast float %6864, %10
  %6866 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %6865)  ; FMax(a,b)
  %6867 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %6867, label %6868, label %6891

; <label>:6868                                    ; preds = %6840
  %6869 = call float @dx.op.unary.f32(i32 6, float %6857)  ; FAbs(value)
  %6870 = fmul fast float %6869, %12
  %6871 = fcmp fast olt float %6870, 0x3F50624DE0000000
  br i1 %6871, label %6872, label %6875

; <label>:6872                                    ; preds = %6868
  %6873 = fmul fast float %6870, 5.000000e-01
  %6874 = fsub fast float 1.000000e+00, %6873
  br label %6880

; <label>:6875                                    ; preds = %6868
  %6876 = fmul fast float %6870, 0xBFF7154760000000
  %6877 = call float @dx.op.unary.f32(i32 21, float %6876)  ; Exp(value)
  %6878 = fsub fast float 1.000000e+00, %6877
  %6879 = fdiv fast float %6878, %6870
  br label %6880

; <label>:6880                                    ; preds = %6875, %6872
  %6881 = phi float [ %6874, %6872 ], [ %6879, %6875 ]
  %6882 = call float @dx.op.binary.f32(i32 36, float %6854, float %19)  ; FMin(a,b)
  %6883 = fsub fast float %6882, %11
  %6884 = fmul fast float %12, %6883
  %6885 = fsub fast float -0.000000e+00, %6884
  %6886 = call float @dx.op.binary.f32(i32 35, float %6885, float -4.000000e+01)  ; FMax(a,b)
  %6887 = call float @dx.op.binary.f32(i32 36, float %6886, float 5.000000e+00)  ; FMin(a,b)
  %6888 = fmul fast float %6887, 0x3FF7154760000000
  %6889 = call float @dx.op.unary.f32(i32 21, float %6888)  ; Exp(value)
  %6890 = fmul fast float %6889, %6881
  br label %6891

; <label>:6891                                    ; preds = %6880, %6840
  %6892 = phi float [ %6890, %6880 ], [ 1.000000e+00, %6840 ]
  %6893 = fmul fast float %6866, %17
  %6894 = fmul fast float %6893, %6892
  %6895 = fcmp fast ole float %6864, %10
  %6896 = fcmp fast olt float %6864, 0x3F1A36E2E0000000
  %6897 = or i1 %6895, %6896
  br i1 %6897, label %6944, label %6898

; <label>:6898                                    ; preds = %6891
  %6899 = fdiv fast float %10, %6864
  %6900 = fmul fast float %6899, %6856
  %6901 = fmul fast float %6899, %6857
  %6902 = fmul fast float %6899, %6858
  %6903 = fadd fast float %6900, %18
  %6904 = fadd fast float %6901, %19
  %6905 = fadd fast float %6902, %20
  %6906 = fadd fast float %6903, -9.000000e+02
  %6907 = fadd fast float %6904, -1.500000e+01
  %6908 = fadd fast float %6905, -7.500000e+02
  %6909 = fmul fast float %6906, 0x3F62345680000000
  %6910 = fmul fast float %6907, 0x3F62345680000000
  %6911 = fmul fast float %6908, 0x3F62345680000000
  %6912 = call float @dx.op.dot3.f32(i32 55, float %6909, float %6910, float %6911, float %6909, float %6910, float %6911)  ; Dot3(ax,ay,az,bx,by,bz)
  %6913 = fsub fast float 1.000000e+00, %6912
  %6914 = call float @dx.op.unary.f32(i32 7, float %6913)  ; Saturate(value)
  %6915 = fmul fast float %6914, %6914
  %6916 = fadd fast float %6903, %6853
  %6917 = fadd fast float %6904, %6854
  %6918 = fadd fast float %6905, %6855
  %6919 = fmul fast float %6916, 0x3F52345680000000
  %6920 = fadd fast float %6919, -2.000000e+00
  %6921 = fmul fast float %6917, 0x3F52345680000000
  %6922 = fadd fast float %6921, 0xBFA1111120000000
  %6923 = fmul fast float %6918, 0x3F52345680000000
  %6924 = fadd fast float %6923, 0xBFFAAAAAC0000000
  %6925 = call float @dx.op.dot3.f32(i32 55, float %6920, float %6922, float %6924, float %6920, float %6922, float %6924)  ; Dot3(ax,ay,az,bx,by,bz)
  %6926 = fsub fast float 1.000000e+00, %6925
  %6927 = call float @dx.op.unary.f32(i32 7, float %6926)  ; Saturate(value)
  %6928 = fmul fast float %6927, %6927
  %6929 = fmul fast float %6928, 4.000000e+00
  %6930 = fadd fast float %6929, %6915
  %6931 = fadd fast float %6853, -9.000000e+02
  %6932 = fadd fast float %6854, -1.500000e+01
  %6933 = fadd fast float %6855, -7.500000e+02
  %6934 = fmul fast float %6931, 0x3F62345680000000
  %6935 = fmul fast float %6932, 0x3F62345680000000
  %6936 = fmul fast float %6933, 0x3F62345680000000
  %6937 = call float @dx.op.dot3.f32(i32 55, float %6934, float %6935, float %6936, float %6934, float %6935, float %6936)  ; Dot3(ax,ay,az,bx,by,bz)
  %6938 = fsub fast float 1.000000e+00, %6937
  %6939 = call float @dx.op.unary.f32(i32 7, float %6938)  ; Saturate(value)
  %6940 = fmul fast float %6939, %6939
  %6941 = fadd fast float %6930, %6940
  %6942 = fmul fast float %6865, 0x3F25D867E0000000
  %6943 = fmul fast float %6942, %6941
  br label %6944

; <label>:6944                                    ; preds = %6898, %6891
  %6945 = phi float [ %6943, %6898 ], [ 0.000000e+00, %6891 ]
  %6946 = fadd fast float %6945, %6894
  %6947 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %6946)  ; FMin(a,b)
  %6948 = fmul fast float %6947, 0xBFF7154760000000
  %6949 = call float @dx.op.unary.f32(i32 21, float %6948)  ; Exp(value)
  %6950 = fsub fast float 1.000000e+00, %6949
  %6951 = call float @dx.op.binary.f32(i32 36, float %13, float %6950)  ; FMin(a,b)
  %6952 = fsub fast float %14, %6778
  %6953 = fsub fast float %15, %6779
  %6954 = fsub fast float %16, %6780
  %6955 = fmul fast float %6951, %6952
  %6956 = fmul fast float %6951, %6953
  %6957 = fmul fast float %6951, %6954
  %6958 = fadd fast float %6955, %6778
  %6959 = fadd fast float %6956, %6779
  %6960 = fadd fast float %6957, %6780
  br label %6961

; <label>:6961                                    ; preds = %6944, %6823, %6817
  %6962 = phi float [ %6958, %6944 ], [ %6778, %6823 ], [ %6778, %6817 ]
  %6963 = phi float [ %6959, %6944 ], [ %6779, %6823 ], [ %6779, %6817 ]
  %6964 = phi float [ %6960, %6944 ], [ %6780, %6823 ], [ %6780, %6817 ]
  %6965 = fadd fast float %6, 1.000000e+00
  %6966 = fadd fast float %7, 1.000000e+00
  %6967 = fsub fast float 1.000000e+00, %6
  %6968 = fmul fast float %37, %6965
  %6969 = fmul fast float %37, %6966
  %6970 = fmul fast float %37, %6967
  %6971 = fmul fast float %6968, %6962
  %6972 = fmul fast float %6969, %6963
  %6973 = fmul fast float %6970, %6964
  %6974 = fcmp fast ult float %38, 5.000000e-01
  br i1 %6974, label %7000, label %6975

; <label>:6975                                    ; preds = %6961
  %6976 = fmul fast float %6971, 0x4004147AE0000000
  %6977 = fmul fast float %6972, 0x4004147AE0000000
  %6978 = fmul fast float %6973, 0x4004147AE0000000
  %6979 = fadd fast float %6976, 0x3F9EB851E0000000
  %6980 = fadd fast float %6977, 0x3F9EB851E0000000
  %6981 = fadd fast float %6978, 0x3F9EB851E0000000
  %6982 = fmul fast float %6979, %6971
  %6983 = fmul fast float %6980, %6972
  %6984 = fmul fast float %6981, %6973
  %6985 = fmul fast float %6971, 0x400370A3E0000000
  %6986 = fmul fast float %6972, 0x400370A3E0000000
  %6987 = fmul fast float %6973, 0x400370A3E0000000
  %6988 = fadd fast float %6985, 0x3FE2E147A0000000
  %6989 = fadd fast float %6986, 0x3FE2E147A0000000
  %6990 = fadd fast float %6987, 0x3FE2E147A0000000
  %6991 = fmul fast float %6988, %6971
  %6992 = fmul fast float %6989, %6972
  %6993 = fmul fast float %6990, %6973
  %6994 = fadd fast float %6991, 0x3FC1EB8520000000
  %6995 = fadd fast float %6992, 0x3FC1EB8520000000
  %6996 = fadd fast float %6993, 0x3FC1EB8520000000
  %6997 = fdiv fast float %6982, %6994
  %6998 = fdiv fast float %6983, %6995
  %6999 = fdiv fast float %6984, %6996
  br label %7000

; <label>:7000                                    ; preds = %6975, %6961
  %7001 = phi float [ %6997, %6975 ], [ %6971, %6961 ]
  %7002 = phi float [ %6998, %6975 ], [ %6972, %6961 ]
  %7003 = phi float [ %6999, %6975 ], [ %6973, %6961 ]
  %7004 = call float @dx.op.unary.f32(i32 7, float %7001)  ; Saturate(value)
  %7005 = call float @dx.op.unary.f32(i32 7, float %7002)  ; Saturate(value)
  %7006 = call float @dx.op.unary.f32(i32 7, float %7003)  ; Saturate(value)
  %7007 = call float @dx.op.dot3.f32(i32 55, float %7004, float %7005, float %7006, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %7008 = fsub fast float %7004, %7007
  %7009 = fsub fast float %7005, %7007
  %7010 = fsub fast float %7006, %7007
  %7011 = fmul fast float %7008, %9
  %7012 = fmul fast float %7009, %9
  %7013 = fmul fast float %7010, %9
  %7014 = fadd fast float %7011, %7007
  %7015 = fadd fast float %7012, %7007
  %7016 = fadd fast float %7013, %7007
  %7017 = call float @dx.op.unary.f32(i32 7, float %7014)  ; Saturate(value)
  %7018 = call float @dx.op.unary.f32(i32 7, float %7015)  ; Saturate(value)
  %7019 = call float @dx.op.unary.f32(i32 7, float %7016)  ; Saturate(value)
  %7020 = fadd fast float %7017, 0xBFC70A3D80000000
  %7021 = fadd fast float %7018, 0xBFC70A3D80000000
  %7022 = fadd fast float %7019, 0xBFC70A3D80000000
  %7023 = fmul fast float %7020, %8
  %7024 = fmul fast float %7021, %8
  %7025 = fmul fast float %7022, %8
  %7026 = fadd fast float %7023, 0x3FC70A3D80000000
  %7027 = fadd fast float %7024, 0x3FC70A3D80000000
  %7028 = fadd fast float %7025, 0x3FC70A3D80000000
  %7029 = call float @dx.op.unary.f32(i32 7, float %7026)  ; Saturate(value)
  %7030 = call float @dx.op.unary.f32(i32 7, float %7027)  ; Saturate(value)
  %7031 = call float @dx.op.unary.f32(i32 7, float %7028)  ; Saturate(value)
  br label %7032

; <label>:7032                                    ; preds = %7000, %6783
  %7033 = phi float [ %6814, %6783 ], [ %7029, %7000 ]
  %7034 = phi float [ %6815, %6783 ], [ %7030, %7000 ]
  %7035 = phi float [ %6816, %6783 ], [ %7031, %7000 ]
  %7036 = fsub fast float %7033, %5885
  %7037 = fsub fast float %7034, %5886
  %7038 = fsub fast float %7035, %5887
  %7039 = fmul fast float %7036, %6770
  %7040 = fmul fast float %7037, %6770
  %7041 = fmul fast float %7038, %6770
  %7042 = fadd fast float %7039, %5885
  %7043 = fadd fast float %7040, %5886
  %7044 = fadd fast float %7041, %5887
  br label %7045

; <label>:7045                                    ; preds = %7032, %6757
  %7046 = phi float [ %7042, %7032 ], [ %5885, %6757 ]
  %7047 = phi float [ %7043, %7032 ], [ %5886, %6757 ]
  %7048 = phi float [ %7044, %7032 ], [ %5887, %6757 ]
  %7049 = call float @dx.op.binary.f32(i32 36, float %6758, float %7046)  ; FMin(a,b)
  %7050 = call float @dx.op.binary.f32(i32 36, float %6759, float %7047)  ; FMin(a,b)
  %7051 = call float @dx.op.binary.f32(i32 36, float %6760, float %7048)  ; FMin(a,b)
  %7052 = call float @dx.op.binary.f32(i32 36, float %6180, float %6468)  ; FMin(a,b)
  %7053 = call float @dx.op.binary.f32(i32 36, float %6181, float %6469)  ; FMin(a,b)
  %7054 = call float @dx.op.binary.f32(i32 36, float %6182, float %6470)  ; FMin(a,b)
  %7055 = call float @dx.op.binary.f32(i32 36, float %7052, float %7049)  ; FMin(a,b)
  %7056 = call float @dx.op.binary.f32(i32 36, float %7053, float %7050)  ; FMin(a,b)
  %7057 = call float @dx.op.binary.f32(i32 36, float %7054, float %7051)  ; FMin(a,b)
  %7058 = call float @dx.op.binary.f32(i32 36, float %5885, float %7055)  ; FMin(a,b)
  %7059 = call float @dx.op.binary.f32(i32 36, float %5886, float %7056)  ; FMin(a,b)
  %7060 = call float @dx.op.binary.f32(i32 36, float %5887, float %7057)  ; FMin(a,b)
  %7061 = call float @dx.op.binary.f32(i32 35, float %6758, float %7046)  ; FMax(a,b)
  %7062 = call float @dx.op.binary.f32(i32 35, float %6759, float %7047)  ; FMax(a,b)
  %7063 = call float @dx.op.binary.f32(i32 35, float %6760, float %7048)  ; FMax(a,b)
  %7064 = call float @dx.op.binary.f32(i32 35, float %6180, float %6468)  ; FMax(a,b)
  %7065 = call float @dx.op.binary.f32(i32 35, float %6181, float %6469)  ; FMax(a,b)
  %7066 = call float @dx.op.binary.f32(i32 35, float %6182, float %6470)  ; FMax(a,b)
  %7067 = call float @dx.op.binary.f32(i32 35, float %7064, float %7061)  ; FMax(a,b)
  %7068 = call float @dx.op.binary.f32(i32 35, float %7065, float %7062)  ; FMax(a,b)
  %7069 = call float @dx.op.binary.f32(i32 35, float %7066, float %7063)  ; FMax(a,b)
  %7070 = call float @dx.op.binary.f32(i32 35, float %5885, float %7067)  ; FMax(a,b)
  %7071 = call float @dx.op.binary.f32(i32 35, float %5886, float %7068)  ; FMax(a,b)
  %7072 = call float @dx.op.binary.f32(i32 35, float %5887, float %7069)  ; FMax(a,b)
  %7073 = fsub fast float %7070, %7058
  %7074 = fsub fast float %7071, %7059
  %7075 = fsub fast float %7072, %7060
  %7076 = call float @dx.op.unary.f32(i32 6, float %7073)  ; FAbs(value)
  %7077 = call float @dx.op.unary.f32(i32 6, float %7074)  ; FAbs(value)
  %7078 = call float @dx.op.unary.f32(i32 6, float %7075)  ; FAbs(value)
  %7079 = call float @dx.op.binary.f32(i32 35, float %7077, float %7078)  ; FMax(a,b)
  %7080 = call float @dx.op.binary.f32(i32 35, float %7076, float %7079)  ; FMax(a,b)
  %7081 = call float @dx.op.binary.f32(i32 35, float %7071, float %7072)  ; FMax(a,b)
  %7082 = call float @dx.op.binary.f32(i32 35, float %7070, float %7081)  ; FMax(a,b)
  %7083 = fmul fast float %7082, 1.250000e-01
  %7084 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %7083)  ; FMax(a,b)
  %7085 = fcmp fast ogt float %7080, %7084
  br i1 %7085, label %7086, label %7148

; <label>:7086                                    ; preds = %7045
  %7087 = fsub fast float %6180, %6468
  %7088 = fsub fast float %6181, %6469
  %7089 = fsub fast float %6182, %6470
  %7090 = call float @dx.op.unary.f32(i32 6, float %7087)  ; FAbs(value)
  %7091 = call float @dx.op.unary.f32(i32 6, float %7088)  ; FAbs(value)
  %7092 = call float @dx.op.unary.f32(i32 6, float %7089)  ; FAbs(value)
  %7093 = call float @dx.op.binary.f32(i32 35, float %7091, float %7092)  ; FMax(a,b)
  %7094 = call float @dx.op.binary.f32(i32 35, float %7090, float %7093)  ; FMax(a,b)
  %7095 = fsub fast float %6758, %7046
  %7096 = fsub fast float %6759, %7047
  %7097 = fsub fast float %6760, %7048
  %7098 = call float @dx.op.unary.f32(i32 6, float %7095)  ; FAbs(value)
  %7099 = call float @dx.op.unary.f32(i32 6, float %7096)  ; FAbs(value)
  %7100 = call float @dx.op.unary.f32(i32 6, float %7097)  ; FAbs(value)
  %7101 = call float @dx.op.binary.f32(i32 35, float %7099, float %7100)  ; FMax(a,b)
  %7102 = call float @dx.op.binary.f32(i32 35, float %7098, float %7101)  ; FMax(a,b)
  %7103 = fcmp fast olt float %7094, %7102
  %7104 = select i1 %7103, float %6180, float %6758
  %7105 = select i1 %7103, float %6181, float %6759
  %7106 = select i1 %7103, float %6182, float %6760
  %7107 = select i1 %7103, float %6468, float %7046
  %7108 = select i1 %7103, float %6469, float %7047
  %7109 = select i1 %7103, float %6470, float %7048
  %7110 = fsub fast float %5885, %7107
  %7111 = fsub fast float %5886, %7108
  %7112 = fsub fast float %5887, %7109
  %7113 = fsub fast float %5885, %7104
  %7114 = fsub fast float %5886, %7105
  %7115 = fsub fast float %5887, %7106
  %7116 = call float @dx.op.dot3.f32(i32 55, float %7113, float %7114, float %7115, float %7110, float %7111, float %7112)  ; Dot3(ax,ay,az,bx,by,bz)
  %7117 = fcmp fast ogt float %7116, 0.000000e+00
  br i1 %7117, label %7118, label %7129

; <label>:7118                                    ; preds = %7086
  %7119 = fsub fast float %7104, %7107
  %7120 = fsub fast float %7105, %7108
  %7121 = fsub fast float %7106, %7109
  %7122 = call float @dx.op.unary.f32(i32 6, float %7119)  ; FAbs(value)
  %7123 = call float @dx.op.unary.f32(i32 6, float %7120)  ; FAbs(value)
  %7124 = call float @dx.op.unary.f32(i32 6, float %7121)  ; FAbs(value)
  %7125 = call float @dx.op.binary.f32(i32 35, float %7123, float %7124)  ; FMax(a,b)
  %7126 = call float @dx.op.binary.f32(i32 35, float %7122, float %7125)  ; FMax(a,b)
  %7127 = fmul fast float %7080, 2.500000e-01
  %7128 = fcmp fast olt float %7126, %7127
  br label %7129

; <label>:7129                                    ; preds = %7118, %7086
  %7130 = phi i1 [ false, %7086 ], [ %7128, %7118 ]
  %7131 = select i1 %7130, float 5.000000e-01, float 1.000000e+00
  %7132 = fmul fast float %7131, %3
  %7133 = fadd fast float %7104, %7107
  %7134 = fadd fast float %7105, %7108
  %7135 = fadd fast float %7106, %7109
  %7136 = fmul fast float %7133, 5.000000e-01
  %7137 = fmul fast float %7134, 5.000000e-01
  %7138 = fmul fast float %7135, 5.000000e-01
  %7139 = fsub fast float %7136, %5885
  %7140 = fsub fast float %7137, %5886
  %7141 = fsub fast float %7138, %5887
  %7142 = fmul fast float %7132, %7139
  %7143 = fmul fast float %7132, %7140
  %7144 = fmul fast float %7132, %7141
  %7145 = fadd fast float %7142, %5885
  %7146 = fadd fast float %7143, %5886
  %7147 = fadd fast float %7144, %5887
  br label %7148

; <label>:7148                                    ; preds = %7129, %7045, %5856, %5640
  %7149 = phi float [ %5671, %5640 ], [ %5885, %5856 ], [ %7145, %7129 ], [ %5885, %7045 ]
  %7150 = phi float [ %5672, %5640 ], [ %5886, %5856 ], [ %7146, %7129 ], [ %5886, %7045 ]
  %7151 = phi float [ %5673, %5640 ], [ %5887, %5856 ], [ %7147, %7129 ], [ %5887, %7045 ]
  %7152 = phi float [ %5674, %5640 ], [ %5638, %5856 ], [ %5638, %7129 ], [ %5638, %7045 ]
  %7153 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %64, i32 %71, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7154 = extractvalue %dx.types.ResRet.f32 %7153, 0
  %7155 = extractvalue %dx.types.ResRet.f32 %7153, 1
  %7156 = extractvalue %dx.types.ResRet.f32 %7153, 2
  %7157 = extractvalue %dx.types.ResRet.f32 %7153, 3
  %7158 = fcmp fast olt float %7157, 0.000000e+00
  br i1 %7158, label %7159, label %7194

; <label>:7159                                    ; preds = %7148
  %7160 = fcmp fast ogt float %7154, 0x3FA4B5DCC0000000
  %7161 = fcmp fast ogt float %7155, 0x3FA4B5DCC0000000
  %7162 = fcmp fast ogt float %7156, 0x3FA4B5DCC0000000
  %7163 = select i1 %7160, float 0.000000e+00, float 1.000000e+00
  %7164 = select i1 %7161, float 0.000000e+00, float 1.000000e+00
  %7165 = select i1 %7162, float 0.000000e+00, float 1.000000e+00
  %7166 = fmul fast float %7154, 0x3FB3D07220000000
  %7167 = fmul fast float %7155, 0x3FB3D07220000000
  %7168 = fmul fast float %7156, 0x3FB3D07220000000
  %7169 = fadd fast float %7154, 0x3FAC28F5C0000000
  %7170 = fadd fast float %7155, 0x3FAC28F5C0000000
  %7171 = fadd fast float %7156, 0x3FAC28F5C0000000
  %7172 = fmul fast float %7169, 0x3FEE54EDE0000000
  %7173 = fmul fast float %7170, 0x3FEE54EDE0000000
  %7174 = fmul fast float %7171, 0x3FEE54EDE0000000
  %7175 = call float @dx.op.unary.f32(i32 23, float %7172)  ; Log(value)
  %7176 = call float @dx.op.unary.f32(i32 23, float %7173)  ; Log(value)
  %7177 = call float @dx.op.unary.f32(i32 23, float %7174)  ; Log(value)
  %7178 = fmul fast float %7175, 0x4003333340000000
  %7179 = fmul fast float %7176, 0x4003333340000000
  %7180 = fmul fast float %7177, 0x4003333340000000
  %7181 = call float @dx.op.unary.f32(i32 21, float %7178)  ; Exp(value)
  %7182 = call float @dx.op.unary.f32(i32 21, float %7179)  ; Exp(value)
  %7183 = call float @dx.op.unary.f32(i32 21, float %7180)  ; Exp(value)
  %7184 = fsub fast float %7166, %7181
  %7185 = fsub fast float %7167, %7182
  %7186 = fsub fast float %7168, %7183
  %7187 = fmul fast float %7184, %7163
  %7188 = fmul fast float %7185, %7164
  %7189 = fmul fast float %7186, %7165
  %7190 = fadd fast float %7187, %7181
  %7191 = fadd fast float %7188, %7182
  %7192 = fadd fast float %7189, %7183
  %7193 = fsub fast float -1.000000e+00, %7157
  br label %8667

; <label>:7194                                    ; preds = %7148
  %7195 = fcmp fast ogt float %39, 5.000000e-01
  %7196 = fcmp fast olt float %87, 1.000000e+00
  %7197 = and i1 %7195, %7196
  br i1 %7197, label %7198, label %7336

; <label>:7198                                    ; preds = %7194
  %7199 = sitofp i32 %64 to float
  %7200 = sitofp i32 %71 to float
  %7201 = fadd fast float %7199, 5.000000e-01
  %7202 = fadd fast float %7200, 5.000000e-01
  %7203 = fdiv fast float %7201, %46
  %7204 = fdiv fast float %7202, %47
  %7205 = fmul fast float %7203, 2.000000e+00
  %7206 = fmul fast float %7204, 2.000000e+00
  %7207 = fadd fast float %7205, -1.000000e+00
  %7208 = fsub fast float 1.000000e+00, %7206
  %7209 = fmul fast float %7207, %36
  %7210 = call float @dx.op.tertiary.f32(i32 46, float %7208, float %32, float %7209)  ; FMad(a,b,c)
  %7211 = call float @dx.op.tertiary.f32(i32 46, float %87, float %28, float %7210)  ; FMad(a,b,c)
  %7212 = fadd fast float %7211, %24
  %7213 = call float @dx.op.unary.f32(i32 6, float %7212)  ; FAbs(value)
  %7214 = fcmp fast ogt float %7213, 0x3EB0C6F7A0000000
  br i1 %7214, label %7215, label %7336

; <label>:7215                                    ; preds = %7198
  %7216 = fmul fast float %7207, %35
  %7217 = call float @dx.op.tertiary.f32(i32 46, float %7208, float %31, float %7216)  ; FMad(a,b,c)
  %7218 = call float @dx.op.tertiary.f32(i32 46, float %87, float %27, float %7217)  ; FMad(a,b,c)
  %7219 = fadd fast float %7218, %23
  %7220 = fmul fast float %7207, %34
  %7221 = call float @dx.op.tertiary.f32(i32 46, float %7208, float %30, float %7220)  ; FMad(a,b,c)
  %7222 = call float @dx.op.tertiary.f32(i32 46, float %87, float %26, float %7221)  ; FMad(a,b,c)
  %7223 = fadd fast float %7222, %22
  %7224 = fmul fast float %7207, %33
  %7225 = call float @dx.op.tertiary.f32(i32 46, float %7208, float %29, float %7224)  ; FMad(a,b,c)
  %7226 = call float @dx.op.tertiary.f32(i32 46, float %87, float %25, float %7225)  ; FMad(a,b,c)
  %7227 = fadd fast float %7226, %21
  %7228 = fdiv fast float %7227, %7212
  %7229 = fdiv fast float %7223, %7212
  %7230 = fdiv fast float %7219, %7212
  %7231 = fsub fast float %7228, %18
  %7232 = fsub fast float %7229, %19
  %7233 = fsub fast float %7230, %20
  %7234 = fmul fast float %7231, %7231
  %7235 = fmul fast float %7232, %7232
  %7236 = fadd fast float %7235, %7234
  %7237 = fmul fast float %7233, %7233
  %7238 = fadd fast float %7236, %7237
  %7239 = call float @dx.op.unary.f32(i32 24, float %7238)  ; Sqrt(value)
  %7240 = fsub fast float %7239, %10
  %7241 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %7240)  ; FMax(a,b)
  %7242 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %7242, label %7243, label %7266

; <label>:7243                                    ; preds = %7215
  %7244 = call float @dx.op.unary.f32(i32 6, float %7232)  ; FAbs(value)
  %7245 = fmul fast float %7244, %12
  %7246 = fcmp fast olt float %7245, 0x3F50624DE0000000
  br i1 %7246, label %7247, label %7250

; <label>:7247                                    ; preds = %7243
  %7248 = fmul fast float %7245, 5.000000e-01
  %7249 = fsub fast float 1.000000e+00, %7248
  br label %7255

; <label>:7250                                    ; preds = %7243
  %7251 = fmul fast float %7245, 0xBFF7154760000000
  %7252 = call float @dx.op.unary.f32(i32 21, float %7251)  ; Exp(value)
  %7253 = fsub fast float 1.000000e+00, %7252
  %7254 = fdiv fast float %7253, %7245
  br label %7255

; <label>:7255                                    ; preds = %7250, %7247
  %7256 = phi float [ %7249, %7247 ], [ %7254, %7250 ]
  %7257 = call float @dx.op.binary.f32(i32 36, float %7229, float %19)  ; FMin(a,b)
  %7258 = fsub fast float %7257, %11
  %7259 = fmul fast float %12, %7258
  %7260 = fsub fast float -0.000000e+00, %7259
  %7261 = call float @dx.op.binary.f32(i32 35, float %7260, float -4.000000e+01)  ; FMax(a,b)
  %7262 = call float @dx.op.binary.f32(i32 36, float %7261, float 5.000000e+00)  ; FMin(a,b)
  %7263 = fmul fast float %7262, 0x3FF7154760000000
  %7264 = call float @dx.op.unary.f32(i32 21, float %7263)  ; Exp(value)
  %7265 = fmul fast float %7264, %7256
  br label %7266

; <label>:7266                                    ; preds = %7255, %7215
  %7267 = phi float [ %7265, %7255 ], [ 1.000000e+00, %7215 ]
  %7268 = fmul fast float %7241, %17
  %7269 = fmul fast float %7268, %7267
  %7270 = fcmp fast ole float %7239, %10
  %7271 = fcmp fast olt float %7239, 0x3F1A36E2E0000000
  %7272 = or i1 %7270, %7271
  br i1 %7272, label %7319, label %7273

; <label>:7273                                    ; preds = %7266
  %7274 = fdiv fast float %10, %7239
  %7275 = fmul fast float %7274, %7231
  %7276 = fmul fast float %7274, %7232
  %7277 = fmul fast float %7274, %7233
  %7278 = fadd fast float %7275, %18
  %7279 = fadd fast float %7276, %19
  %7280 = fadd fast float %7277, %20
  %7281 = fadd fast float %7278, -9.000000e+02
  %7282 = fadd fast float %7279, -1.500000e+01
  %7283 = fadd fast float %7280, -7.500000e+02
  %7284 = fmul fast float %7281, 0x3F62345680000000
  %7285 = fmul fast float %7282, 0x3F62345680000000
  %7286 = fmul fast float %7283, 0x3F62345680000000
  %7287 = call float @dx.op.dot3.f32(i32 55, float %7284, float %7285, float %7286, float %7284, float %7285, float %7286)  ; Dot3(ax,ay,az,bx,by,bz)
  %7288 = fsub fast float 1.000000e+00, %7287
  %7289 = call float @dx.op.unary.f32(i32 7, float %7288)  ; Saturate(value)
  %7290 = fmul fast float %7289, %7289
  %7291 = fadd fast float %7278, %7228
  %7292 = fadd fast float %7279, %7229
  %7293 = fadd fast float %7280, %7230
  %7294 = fmul fast float %7291, 0x3F52345680000000
  %7295 = fadd fast float %7294, -2.000000e+00
  %7296 = fmul fast float %7292, 0x3F52345680000000
  %7297 = fadd fast float %7296, 0xBFA1111120000000
  %7298 = fmul fast float %7293, 0x3F52345680000000
  %7299 = fadd fast float %7298, 0xBFFAAAAAC0000000
  %7300 = call float @dx.op.dot3.f32(i32 55, float %7295, float %7297, float %7299, float %7295, float %7297, float %7299)  ; Dot3(ax,ay,az,bx,by,bz)
  %7301 = fsub fast float 1.000000e+00, %7300
  %7302 = call float @dx.op.unary.f32(i32 7, float %7301)  ; Saturate(value)
  %7303 = fmul fast float %7302, %7302
  %7304 = fmul fast float %7303, 4.000000e+00
  %7305 = fadd fast float %7304, %7290
  %7306 = fadd fast float %7228, -9.000000e+02
  %7307 = fadd fast float %7229, -1.500000e+01
  %7308 = fadd fast float %7230, -7.500000e+02
  %7309 = fmul fast float %7306, 0x3F62345680000000
  %7310 = fmul fast float %7307, 0x3F62345680000000
  %7311 = fmul fast float %7308, 0x3F62345680000000
  %7312 = call float @dx.op.dot3.f32(i32 55, float %7309, float %7310, float %7311, float %7309, float %7310, float %7311)  ; Dot3(ax,ay,az,bx,by,bz)
  %7313 = fsub fast float 1.000000e+00, %7312
  %7314 = call float @dx.op.unary.f32(i32 7, float %7313)  ; Saturate(value)
  %7315 = fmul fast float %7314, %7314
  %7316 = fadd fast float %7305, %7315
  %7317 = fmul fast float %7240, 0x3F25D867E0000000
  %7318 = fmul fast float %7317, %7316
  br label %7319

; <label>:7319                                    ; preds = %7273, %7266
  %7320 = phi float [ %7318, %7273 ], [ 0.000000e+00, %7266 ]
  %7321 = fadd fast float %7320, %7269
  %7322 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %7321)  ; FMin(a,b)
  %7323 = fmul fast float %7322, 0xBFF7154760000000
  %7324 = call float @dx.op.unary.f32(i32 21, float %7323)  ; Exp(value)
  %7325 = fsub fast float 1.000000e+00, %7324
  %7326 = call float @dx.op.binary.f32(i32 36, float %13, float %7325)  ; FMin(a,b)
  %7327 = fsub fast float %14, %7154
  %7328 = fsub fast float %15, %7155
  %7329 = fsub fast float %16, %7156
  %7330 = fmul fast float %7326, %7327
  %7331 = fmul fast float %7326, %7328
  %7332 = fmul fast float %7326, %7329
  %7333 = fadd fast float %7330, %7154
  %7334 = fadd fast float %7331, %7155
  %7335 = fadd fast float %7332, %7156
  br label %7336

; <label>:7336                                    ; preds = %7319, %7198, %7194
  %7337 = phi float [ %7333, %7319 ], [ %7154, %7198 ], [ %7154, %7194 ]
  %7338 = phi float [ %7334, %7319 ], [ %7155, %7198 ], [ %7155, %7194 ]
  %7339 = phi float [ %7335, %7319 ], [ %7156, %7198 ], [ %7156, %7194 ]
  %7340 = fadd fast float %6, 1.000000e+00
  %7341 = fadd fast float %7, 1.000000e+00
  %7342 = fsub fast float 1.000000e+00, %6
  %7343 = fmul fast float %37, %7340
  %7344 = fmul fast float %37, %7341
  %7345 = fmul fast float %37, %7342
  %7346 = fmul fast float %7343, %7337
  %7347 = fmul fast float %7344, %7338
  %7348 = fmul fast float %7345, %7339
  %7349 = fcmp fast ult float %38, 5.000000e-01
  br i1 %7349, label %7375, label %7350

; <label>:7350                                    ; preds = %7336
  %7351 = fmul fast float %7346, 0x4004147AE0000000
  %7352 = fmul fast float %7347, 0x4004147AE0000000
  %7353 = fmul fast float %7348, 0x4004147AE0000000
  %7354 = fadd fast float %7351, 0x3F9EB851E0000000
  %7355 = fadd fast float %7352, 0x3F9EB851E0000000
  %7356 = fadd fast float %7353, 0x3F9EB851E0000000
  %7357 = fmul fast float %7354, %7346
  %7358 = fmul fast float %7355, %7347
  %7359 = fmul fast float %7356, %7348
  %7360 = fmul fast float %7346, 0x400370A3E0000000
  %7361 = fmul fast float %7347, 0x400370A3E0000000
  %7362 = fmul fast float %7348, 0x400370A3E0000000
  %7363 = fadd fast float %7360, 0x3FE2E147A0000000
  %7364 = fadd fast float %7361, 0x3FE2E147A0000000
  %7365 = fadd fast float %7362, 0x3FE2E147A0000000
  %7366 = fmul fast float %7363, %7346
  %7367 = fmul fast float %7364, %7347
  %7368 = fmul fast float %7365, %7348
  %7369 = fadd fast float %7366, 0x3FC1EB8520000000
  %7370 = fadd fast float %7367, 0x3FC1EB8520000000
  %7371 = fadd fast float %7368, 0x3FC1EB8520000000
  %7372 = fdiv fast float %7357, %7369
  %7373 = fdiv fast float %7358, %7370
  %7374 = fdiv fast float %7359, %7371
  br label %7375

; <label>:7375                                    ; preds = %7350, %7336
  %7376 = phi float [ %7372, %7350 ], [ %7346, %7336 ]
  %7377 = phi float [ %7373, %7350 ], [ %7347, %7336 ]
  %7378 = phi float [ %7374, %7350 ], [ %7348, %7336 ]
  %7379 = call float @dx.op.unary.f32(i32 7, float %7376)  ; Saturate(value)
  %7380 = call float @dx.op.unary.f32(i32 7, float %7377)  ; Saturate(value)
  %7381 = call float @dx.op.unary.f32(i32 7, float %7378)  ; Saturate(value)
  %7382 = call float @dx.op.dot3.f32(i32 55, float %7379, float %7380, float %7381, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %7383 = fsub fast float %7379, %7382
  %7384 = fsub fast float %7380, %7382
  %7385 = fsub fast float %7381, %7382
  %7386 = fmul fast float %7383, %9
  %7387 = fmul fast float %7384, %9
  %7388 = fmul fast float %7385, %9
  %7389 = fadd fast float %7386, %7382
  %7390 = fadd fast float %7387, %7382
  %7391 = fadd fast float %7388, %7382
  %7392 = call float @dx.op.unary.f32(i32 7, float %7389)  ; Saturate(value)
  %7393 = call float @dx.op.unary.f32(i32 7, float %7390)  ; Saturate(value)
  %7394 = call float @dx.op.unary.f32(i32 7, float %7391)  ; Saturate(value)
  %7395 = fadd fast float %7392, 0xBFC70A3D80000000
  %7396 = fadd fast float %7393, 0xBFC70A3D80000000
  %7397 = fadd fast float %7394, 0xBFC70A3D80000000
  %7398 = fmul fast float %7395, %8
  %7399 = fmul fast float %7396, %8
  %7400 = fmul fast float %7397, %8
  %7401 = fadd fast float %7398, 0x3FC70A3D80000000
  %7402 = fadd fast float %7399, 0x3FC70A3D80000000
  %7403 = fadd fast float %7400, 0x3FC70A3D80000000
  %7404 = call float @dx.op.unary.f32(i32 7, float %7401)  ; Saturate(value)
  %7405 = call float @dx.op.unary.f32(i32 7, float %7402)  ; Saturate(value)
  %7406 = call float @dx.op.unary.f32(i32 7, float %7403)  ; Saturate(value)
  %7407 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %7407, label %7408, label %8667

; <label>:7408                                    ; preds = %7375
  %7409 = add i32 %71, -1
  %7410 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %7411 = call i32 @dx.op.binary.i32(i32 37, i32 %7409, i32 0)  ; IMax(a,b)
  %7412 = call i32 @dx.op.binary.i32(i32 38, i32 %7410, i32 %60)  ; IMin(a,b)
  %7413 = call i32 @dx.op.binary.i32(i32 38, i32 %7411, i32 %61)  ; IMin(a,b)
  %7414 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %7412, i32 %7413, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7415 = extractvalue %dx.types.ResRet.f32 %7414, 0
  %7416 = fsub fast float 1.000000e+00, %87
  %7417 = fmul fast float %7416, 0x3FA99999A0000000
  %7418 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %7417)  ; FMax(a,b)
  %7419 = fsub fast float %7415, %87
  %7420 = call float @dx.op.unary.f32(i32 6, float %7419)  ; FAbs(value)
  %7421 = fdiv fast float %7420, %7418
  %7422 = fsub fast float 1.000000e+00, %7421
  %7423 = call float @dx.op.unary.f32(i32 7, float %7422)  ; Saturate(value)
  %7424 = fcmp fast ugt float %7423, 0.000000e+00
  br i1 %7424, label %7425, label %7698

; <label>:7425                                    ; preds = %7408
  %7426 = call i32 @dx.op.binary.i32(i32 37, i32 %7412, i32 0)  ; IMax(a,b)
  %7427 = call i32 @dx.op.binary.i32(i32 37, i32 %7413, i32 0)  ; IMax(a,b)
  %7428 = call i32 @dx.op.binary.i32(i32 38, i32 %7426, i32 %60)  ; IMin(a,b)
  %7429 = call i32 @dx.op.binary.i32(i32 38, i32 %7427, i32 %61)  ; IMin(a,b)
  %7430 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %7428, i32 %7429, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7431 = extractvalue %dx.types.ResRet.f32 %7430, 0
  %7432 = extractvalue %dx.types.ResRet.f32 %7430, 1
  %7433 = extractvalue %dx.types.ResRet.f32 %7430, 2
  %7434 = extractvalue %dx.types.ResRet.f32 %7430, 3
  %7435 = fcmp fast olt float %7434, 0.000000e+00
  br i1 %7435, label %7436, label %7470

; <label>:7436                                    ; preds = %7425
  %7437 = fcmp fast ogt float %7431, 0x3FA4B5DCC0000000
  %7438 = fcmp fast ogt float %7432, 0x3FA4B5DCC0000000
  %7439 = fcmp fast ogt float %7433, 0x3FA4B5DCC0000000
  %7440 = select i1 %7437, float 0.000000e+00, float 1.000000e+00
  %7441 = select i1 %7438, float 0.000000e+00, float 1.000000e+00
  %7442 = select i1 %7439, float 0.000000e+00, float 1.000000e+00
  %7443 = fmul fast float %7431, 0x3FB3D07220000000
  %7444 = fmul fast float %7432, 0x3FB3D07220000000
  %7445 = fmul fast float %7433, 0x3FB3D07220000000
  %7446 = fadd fast float %7431, 0x3FAC28F5C0000000
  %7447 = fadd fast float %7432, 0x3FAC28F5C0000000
  %7448 = fadd fast float %7433, 0x3FAC28F5C0000000
  %7449 = fmul fast float %7446, 0x3FEE54EDE0000000
  %7450 = fmul fast float %7447, 0x3FEE54EDE0000000
  %7451 = fmul fast float %7448, 0x3FEE54EDE0000000
  %7452 = call float @dx.op.unary.f32(i32 23, float %7449)  ; Log(value)
  %7453 = call float @dx.op.unary.f32(i32 23, float %7450)  ; Log(value)
  %7454 = call float @dx.op.unary.f32(i32 23, float %7451)  ; Log(value)
  %7455 = fmul fast float %7452, 0x4003333340000000
  %7456 = fmul fast float %7453, 0x4003333340000000
  %7457 = fmul fast float %7454, 0x4003333340000000
  %7458 = call float @dx.op.unary.f32(i32 21, float %7455)  ; Exp(value)
  %7459 = call float @dx.op.unary.f32(i32 21, float %7456)  ; Exp(value)
  %7460 = call float @dx.op.unary.f32(i32 21, float %7457)  ; Exp(value)
  %7461 = fsub fast float %7443, %7458
  %7462 = fsub fast float %7444, %7459
  %7463 = fsub fast float %7445, %7460
  %7464 = fmul fast float %7461, %7440
  %7465 = fmul fast float %7462, %7441
  %7466 = fmul fast float %7463, %7442
  %7467 = fadd fast float %7464, %7458
  %7468 = fadd fast float %7465, %7459
  %7469 = fadd fast float %7466, %7460
  br label %7685

; <label>:7470                                    ; preds = %7425
  %7471 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %7428, i32 %7429, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7472 = extractvalue %dx.types.ResRet.f32 %7471, 0
  %7473 = fcmp fast ogt float %39, 5.000000e-01
  %7474 = fcmp fast olt float %7472, 1.000000e+00
  %7475 = and i1 %7473, %7474
  br i1 %7475, label %7476, label %7614

; <label>:7476                                    ; preds = %7470
  %7477 = sitofp i32 %7428 to float
  %7478 = sitofp i32 %7429 to float
  %7479 = fadd fast float %7477, 5.000000e-01
  %7480 = fadd fast float %7478, 5.000000e-01
  %7481 = fdiv fast float %7479, %46
  %7482 = fdiv fast float %7480, %47
  %7483 = fmul fast float %7481, 2.000000e+00
  %7484 = fmul fast float %7482, 2.000000e+00
  %7485 = fadd fast float %7483, -1.000000e+00
  %7486 = fsub fast float 1.000000e+00, %7484
  %7487 = fmul fast float %7485, %36
  %7488 = call float @dx.op.tertiary.f32(i32 46, float %7486, float %32, float %7487)  ; FMad(a,b,c)
  %7489 = call float @dx.op.tertiary.f32(i32 46, float %7472, float %28, float %7488)  ; FMad(a,b,c)
  %7490 = fadd fast float %7489, %24
  %7491 = call float @dx.op.unary.f32(i32 6, float %7490)  ; FAbs(value)
  %7492 = fcmp fast ogt float %7491, 0x3EB0C6F7A0000000
  br i1 %7492, label %7493, label %7614

; <label>:7493                                    ; preds = %7476
  %7494 = fmul fast float %7485, %35
  %7495 = call float @dx.op.tertiary.f32(i32 46, float %7486, float %31, float %7494)  ; FMad(a,b,c)
  %7496 = call float @dx.op.tertiary.f32(i32 46, float %7472, float %27, float %7495)  ; FMad(a,b,c)
  %7497 = fadd fast float %7496, %23
  %7498 = fmul fast float %7485, %34
  %7499 = call float @dx.op.tertiary.f32(i32 46, float %7486, float %30, float %7498)  ; FMad(a,b,c)
  %7500 = call float @dx.op.tertiary.f32(i32 46, float %7472, float %26, float %7499)  ; FMad(a,b,c)
  %7501 = fadd fast float %7500, %22
  %7502 = fmul fast float %7485, %33
  %7503 = call float @dx.op.tertiary.f32(i32 46, float %7486, float %29, float %7502)  ; FMad(a,b,c)
  %7504 = call float @dx.op.tertiary.f32(i32 46, float %7472, float %25, float %7503)  ; FMad(a,b,c)
  %7505 = fadd fast float %7504, %21
  %7506 = fdiv fast float %7505, %7490
  %7507 = fdiv fast float %7501, %7490
  %7508 = fdiv fast float %7497, %7490
  %7509 = fsub fast float %7506, %18
  %7510 = fsub fast float %7507, %19
  %7511 = fsub fast float %7508, %20
  %7512 = fmul fast float %7509, %7509
  %7513 = fmul fast float %7510, %7510
  %7514 = fadd fast float %7513, %7512
  %7515 = fmul fast float %7511, %7511
  %7516 = fadd fast float %7514, %7515
  %7517 = call float @dx.op.unary.f32(i32 24, float %7516)  ; Sqrt(value)
  %7518 = fsub fast float %7517, %10
  %7519 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %7518)  ; FMax(a,b)
  %7520 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %7520, label %7521, label %7544

; <label>:7521                                    ; preds = %7493
  %7522 = call float @dx.op.unary.f32(i32 6, float %7510)  ; FAbs(value)
  %7523 = fmul fast float %7522, %12
  %7524 = fcmp fast olt float %7523, 0x3F50624DE0000000
  br i1 %7524, label %7525, label %7528

; <label>:7525                                    ; preds = %7521
  %7526 = fmul fast float %7523, 5.000000e-01
  %7527 = fsub fast float 1.000000e+00, %7526
  br label %7533

; <label>:7528                                    ; preds = %7521
  %7529 = fmul fast float %7523, 0xBFF7154760000000
  %7530 = call float @dx.op.unary.f32(i32 21, float %7529)  ; Exp(value)
  %7531 = fsub fast float 1.000000e+00, %7530
  %7532 = fdiv fast float %7531, %7523
  br label %7533

; <label>:7533                                    ; preds = %7528, %7525
  %7534 = phi float [ %7527, %7525 ], [ %7532, %7528 ]
  %7535 = call float @dx.op.binary.f32(i32 36, float %7507, float %19)  ; FMin(a,b)
  %7536 = fsub fast float %7535, %11
  %7537 = fmul fast float %12, %7536
  %7538 = fsub fast float -0.000000e+00, %7537
  %7539 = call float @dx.op.binary.f32(i32 35, float %7538, float -4.000000e+01)  ; FMax(a,b)
  %7540 = call float @dx.op.binary.f32(i32 36, float %7539, float 5.000000e+00)  ; FMin(a,b)
  %7541 = fmul fast float %7540, 0x3FF7154760000000
  %7542 = call float @dx.op.unary.f32(i32 21, float %7541)  ; Exp(value)
  %7543 = fmul fast float %7542, %7534
  br label %7544

; <label>:7544                                    ; preds = %7533, %7493
  %7545 = phi float [ %7543, %7533 ], [ 1.000000e+00, %7493 ]
  %7546 = fmul fast float %7519, %17
  %7547 = fmul fast float %7546, %7545
  %7548 = fcmp fast ole float %7517, %10
  %7549 = fcmp fast olt float %7517, 0x3F1A36E2E0000000
  %7550 = or i1 %7548, %7549
  br i1 %7550, label %7597, label %7551

; <label>:7551                                    ; preds = %7544
  %7552 = fdiv fast float %10, %7517
  %7553 = fmul fast float %7552, %7509
  %7554 = fmul fast float %7552, %7510
  %7555 = fmul fast float %7552, %7511
  %7556 = fadd fast float %7553, %18
  %7557 = fadd fast float %7554, %19
  %7558 = fadd fast float %7555, %20
  %7559 = fadd fast float %7556, -9.000000e+02
  %7560 = fadd fast float %7557, -1.500000e+01
  %7561 = fadd fast float %7558, -7.500000e+02
  %7562 = fmul fast float %7559, 0x3F62345680000000
  %7563 = fmul fast float %7560, 0x3F62345680000000
  %7564 = fmul fast float %7561, 0x3F62345680000000
  %7565 = call float @dx.op.dot3.f32(i32 55, float %7562, float %7563, float %7564, float %7562, float %7563, float %7564)  ; Dot3(ax,ay,az,bx,by,bz)
  %7566 = fsub fast float 1.000000e+00, %7565
  %7567 = call float @dx.op.unary.f32(i32 7, float %7566)  ; Saturate(value)
  %7568 = fmul fast float %7567, %7567
  %7569 = fadd fast float %7556, %7506
  %7570 = fadd fast float %7557, %7507
  %7571 = fadd fast float %7558, %7508
  %7572 = fmul fast float %7569, 0x3F52345680000000
  %7573 = fadd fast float %7572, -2.000000e+00
  %7574 = fmul fast float %7570, 0x3F52345680000000
  %7575 = fadd fast float %7574, 0xBFA1111120000000
  %7576 = fmul fast float %7571, 0x3F52345680000000
  %7577 = fadd fast float %7576, 0xBFFAAAAAC0000000
  %7578 = call float @dx.op.dot3.f32(i32 55, float %7573, float %7575, float %7577, float %7573, float %7575, float %7577)  ; Dot3(ax,ay,az,bx,by,bz)
  %7579 = fsub fast float 1.000000e+00, %7578
  %7580 = call float @dx.op.unary.f32(i32 7, float %7579)  ; Saturate(value)
  %7581 = fmul fast float %7580, %7580
  %7582 = fmul fast float %7581, 4.000000e+00
  %7583 = fadd fast float %7582, %7568
  %7584 = fadd fast float %7506, -9.000000e+02
  %7585 = fadd fast float %7507, -1.500000e+01
  %7586 = fadd fast float %7508, -7.500000e+02
  %7587 = fmul fast float %7584, 0x3F62345680000000
  %7588 = fmul fast float %7585, 0x3F62345680000000
  %7589 = fmul fast float %7586, 0x3F62345680000000
  %7590 = call float @dx.op.dot3.f32(i32 55, float %7587, float %7588, float %7589, float %7587, float %7588, float %7589)  ; Dot3(ax,ay,az,bx,by,bz)
  %7591 = fsub fast float 1.000000e+00, %7590
  %7592 = call float @dx.op.unary.f32(i32 7, float %7591)  ; Saturate(value)
  %7593 = fmul fast float %7592, %7592
  %7594 = fadd fast float %7583, %7593
  %7595 = fmul fast float %7518, 0x3F25D867E0000000
  %7596 = fmul fast float %7595, %7594
  br label %7597

; <label>:7597                                    ; preds = %7551, %7544
  %7598 = phi float [ %7596, %7551 ], [ 0.000000e+00, %7544 ]
  %7599 = fadd fast float %7598, %7547
  %7600 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %7599)  ; FMin(a,b)
  %7601 = fmul fast float %7600, 0xBFF7154760000000
  %7602 = call float @dx.op.unary.f32(i32 21, float %7601)  ; Exp(value)
  %7603 = fsub fast float 1.000000e+00, %7602
  %7604 = call float @dx.op.binary.f32(i32 36, float %13, float %7603)  ; FMin(a,b)
  %7605 = fsub fast float %14, %7431
  %7606 = fsub fast float %15, %7432
  %7607 = fsub fast float %16, %7433
  %7608 = fmul fast float %7604, %7605
  %7609 = fmul fast float %7604, %7606
  %7610 = fmul fast float %7604, %7607
  %7611 = fadd fast float %7608, %7431
  %7612 = fadd fast float %7609, %7432
  %7613 = fadd fast float %7610, %7433
  br label %7614

; <label>:7614                                    ; preds = %7597, %7476, %7470
  %7615 = phi float [ %7611, %7597 ], [ %7431, %7476 ], [ %7431, %7470 ]
  %7616 = phi float [ %7612, %7597 ], [ %7432, %7476 ], [ %7432, %7470 ]
  %7617 = phi float [ %7613, %7597 ], [ %7433, %7476 ], [ %7433, %7470 ]
  %7618 = fadd fast float %6, 1.000000e+00
  %7619 = fadd fast float %7, 1.000000e+00
  %7620 = fsub fast float 1.000000e+00, %6
  %7621 = fmul fast float %37, %7618
  %7622 = fmul fast float %37, %7619
  %7623 = fmul fast float %37, %7620
  %7624 = fmul fast float %7621, %7615
  %7625 = fmul fast float %7622, %7616
  %7626 = fmul fast float %7623, %7617
  %7627 = fcmp fast ult float %38, 5.000000e-01
  br i1 %7627, label %7653, label %7628

; <label>:7628                                    ; preds = %7614
  %7629 = fmul fast float %7624, 0x4004147AE0000000
  %7630 = fmul fast float %7625, 0x4004147AE0000000
  %7631 = fmul fast float %7626, 0x4004147AE0000000
  %7632 = fadd fast float %7629, 0x3F9EB851E0000000
  %7633 = fadd fast float %7630, 0x3F9EB851E0000000
  %7634 = fadd fast float %7631, 0x3F9EB851E0000000
  %7635 = fmul fast float %7632, %7624
  %7636 = fmul fast float %7633, %7625
  %7637 = fmul fast float %7634, %7626
  %7638 = fmul fast float %7624, 0x400370A3E0000000
  %7639 = fmul fast float %7625, 0x400370A3E0000000
  %7640 = fmul fast float %7626, 0x400370A3E0000000
  %7641 = fadd fast float %7638, 0x3FE2E147A0000000
  %7642 = fadd fast float %7639, 0x3FE2E147A0000000
  %7643 = fadd fast float %7640, 0x3FE2E147A0000000
  %7644 = fmul fast float %7641, %7624
  %7645 = fmul fast float %7642, %7625
  %7646 = fmul fast float %7643, %7626
  %7647 = fadd fast float %7644, 0x3FC1EB8520000000
  %7648 = fadd fast float %7645, 0x3FC1EB8520000000
  %7649 = fadd fast float %7646, 0x3FC1EB8520000000
  %7650 = fdiv fast float %7635, %7647
  %7651 = fdiv fast float %7636, %7648
  %7652 = fdiv fast float %7637, %7649
  br label %7653

; <label>:7653                                    ; preds = %7628, %7614
  %7654 = phi float [ %7650, %7628 ], [ %7624, %7614 ]
  %7655 = phi float [ %7651, %7628 ], [ %7625, %7614 ]
  %7656 = phi float [ %7652, %7628 ], [ %7626, %7614 ]
  %7657 = call float @dx.op.unary.f32(i32 7, float %7654)  ; Saturate(value)
  %7658 = call float @dx.op.unary.f32(i32 7, float %7655)  ; Saturate(value)
  %7659 = call float @dx.op.unary.f32(i32 7, float %7656)  ; Saturate(value)
  %7660 = call float @dx.op.dot3.f32(i32 55, float %7657, float %7658, float %7659, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %7661 = fsub fast float %7657, %7660
  %7662 = fsub fast float %7658, %7660
  %7663 = fsub fast float %7659, %7660
  %7664 = fmul fast float %7661, %9
  %7665 = fmul fast float %7662, %9
  %7666 = fmul fast float %7663, %9
  %7667 = fadd fast float %7664, %7660
  %7668 = fadd fast float %7665, %7660
  %7669 = fadd fast float %7666, %7660
  %7670 = call float @dx.op.unary.f32(i32 7, float %7667)  ; Saturate(value)
  %7671 = call float @dx.op.unary.f32(i32 7, float %7668)  ; Saturate(value)
  %7672 = call float @dx.op.unary.f32(i32 7, float %7669)  ; Saturate(value)
  %7673 = fadd fast float %7670, 0xBFC70A3D80000000
  %7674 = fadd fast float %7671, 0xBFC70A3D80000000
  %7675 = fadd fast float %7672, 0xBFC70A3D80000000
  %7676 = fmul fast float %7673, %8
  %7677 = fmul fast float %7674, %8
  %7678 = fmul fast float %7675, %8
  %7679 = fadd fast float %7676, 0x3FC70A3D80000000
  %7680 = fadd fast float %7677, 0x3FC70A3D80000000
  %7681 = fadd fast float %7678, 0x3FC70A3D80000000
  %7682 = call float @dx.op.unary.f32(i32 7, float %7679)  ; Saturate(value)
  %7683 = call float @dx.op.unary.f32(i32 7, float %7680)  ; Saturate(value)
  %7684 = call float @dx.op.unary.f32(i32 7, float %7681)  ; Saturate(value)
  br label %7685

; <label>:7685                                    ; preds = %7653, %7436
  %7686 = phi float [ %7467, %7436 ], [ %7682, %7653 ]
  %7687 = phi float [ %7468, %7436 ], [ %7683, %7653 ]
  %7688 = phi float [ %7469, %7436 ], [ %7684, %7653 ]
  %7689 = fsub fast float %7686, %7404
  %7690 = fsub fast float %7687, %7405
  %7691 = fsub fast float %7688, %7406
  %7692 = fmul fast float %7689, %7423
  %7693 = fmul fast float %7690, %7423
  %7694 = fmul fast float %7691, %7423
  %7695 = fadd fast float %7692, %7404
  %7696 = fadd fast float %7693, %7405
  %7697 = fadd fast float %7694, %7406
  br label %7698

; <label>:7698                                    ; preds = %7685, %7408
  %7699 = phi float [ %7695, %7685 ], [ %7404, %7408 ]
  %7700 = phi float [ %7696, %7685 ], [ %7405, %7408 ]
  %7701 = phi float [ %7697, %7685 ], [ %7406, %7408 ]
  %7702 = add i32 %71, 1
  %7703 = call i32 @dx.op.binary.i32(i32 37, i32 %7702, i32 0)  ; IMax(a,b)
  %7704 = call i32 @dx.op.binary.i32(i32 38, i32 %7703, i32 %61)  ; IMin(a,b)
  %7705 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %7412, i32 %7704, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7706 = extractvalue %dx.types.ResRet.f32 %7705, 0
  %7707 = fsub fast float %7706, %87
  %7708 = call float @dx.op.unary.f32(i32 6, float %7707)  ; FAbs(value)
  %7709 = fdiv fast float %7708, %7418
  %7710 = fsub fast float 1.000000e+00, %7709
  %7711 = call float @dx.op.unary.f32(i32 7, float %7710)  ; Saturate(value)
  %7712 = fcmp fast ugt float %7711, 0.000000e+00
  br i1 %7712, label %7713, label %7986

; <label>:7713                                    ; preds = %7698
  %7714 = call i32 @dx.op.binary.i32(i32 37, i32 %7412, i32 0)  ; IMax(a,b)
  %7715 = call i32 @dx.op.binary.i32(i32 37, i32 %7704, i32 0)  ; IMax(a,b)
  %7716 = call i32 @dx.op.binary.i32(i32 38, i32 %7714, i32 %60)  ; IMin(a,b)
  %7717 = call i32 @dx.op.binary.i32(i32 38, i32 %7715, i32 %61)  ; IMin(a,b)
  %7718 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %7716, i32 %7717, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7719 = extractvalue %dx.types.ResRet.f32 %7718, 0
  %7720 = extractvalue %dx.types.ResRet.f32 %7718, 1
  %7721 = extractvalue %dx.types.ResRet.f32 %7718, 2
  %7722 = extractvalue %dx.types.ResRet.f32 %7718, 3
  %7723 = fcmp fast olt float %7722, 0.000000e+00
  br i1 %7723, label %7724, label %7758

; <label>:7724                                    ; preds = %7713
  %7725 = fcmp fast ogt float %7719, 0x3FA4B5DCC0000000
  %7726 = fcmp fast ogt float %7720, 0x3FA4B5DCC0000000
  %7727 = fcmp fast ogt float %7721, 0x3FA4B5DCC0000000
  %7728 = select i1 %7725, float 0.000000e+00, float 1.000000e+00
  %7729 = select i1 %7726, float 0.000000e+00, float 1.000000e+00
  %7730 = select i1 %7727, float 0.000000e+00, float 1.000000e+00
  %7731 = fmul fast float %7719, 0x3FB3D07220000000
  %7732 = fmul fast float %7720, 0x3FB3D07220000000
  %7733 = fmul fast float %7721, 0x3FB3D07220000000
  %7734 = fadd fast float %7719, 0x3FAC28F5C0000000
  %7735 = fadd fast float %7720, 0x3FAC28F5C0000000
  %7736 = fadd fast float %7721, 0x3FAC28F5C0000000
  %7737 = fmul fast float %7734, 0x3FEE54EDE0000000
  %7738 = fmul fast float %7735, 0x3FEE54EDE0000000
  %7739 = fmul fast float %7736, 0x3FEE54EDE0000000
  %7740 = call float @dx.op.unary.f32(i32 23, float %7737)  ; Log(value)
  %7741 = call float @dx.op.unary.f32(i32 23, float %7738)  ; Log(value)
  %7742 = call float @dx.op.unary.f32(i32 23, float %7739)  ; Log(value)
  %7743 = fmul fast float %7740, 0x4003333340000000
  %7744 = fmul fast float %7741, 0x4003333340000000
  %7745 = fmul fast float %7742, 0x4003333340000000
  %7746 = call float @dx.op.unary.f32(i32 21, float %7743)  ; Exp(value)
  %7747 = call float @dx.op.unary.f32(i32 21, float %7744)  ; Exp(value)
  %7748 = call float @dx.op.unary.f32(i32 21, float %7745)  ; Exp(value)
  %7749 = fsub fast float %7731, %7746
  %7750 = fsub fast float %7732, %7747
  %7751 = fsub fast float %7733, %7748
  %7752 = fmul fast float %7749, %7728
  %7753 = fmul fast float %7750, %7729
  %7754 = fmul fast float %7751, %7730
  %7755 = fadd fast float %7752, %7746
  %7756 = fadd fast float %7753, %7747
  %7757 = fadd fast float %7754, %7748
  br label %7973

; <label>:7758                                    ; preds = %7713
  %7759 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %7716, i32 %7717, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7760 = extractvalue %dx.types.ResRet.f32 %7759, 0
  %7761 = fcmp fast ogt float %39, 5.000000e-01
  %7762 = fcmp fast olt float %7760, 1.000000e+00
  %7763 = and i1 %7761, %7762
  br i1 %7763, label %7764, label %7902

; <label>:7764                                    ; preds = %7758
  %7765 = sitofp i32 %7716 to float
  %7766 = sitofp i32 %7717 to float
  %7767 = fadd fast float %7765, 5.000000e-01
  %7768 = fadd fast float %7766, 5.000000e-01
  %7769 = fdiv fast float %7767, %46
  %7770 = fdiv fast float %7768, %47
  %7771 = fmul fast float %7769, 2.000000e+00
  %7772 = fmul fast float %7770, 2.000000e+00
  %7773 = fadd fast float %7771, -1.000000e+00
  %7774 = fsub fast float 1.000000e+00, %7772
  %7775 = fmul fast float %7773, %36
  %7776 = call float @dx.op.tertiary.f32(i32 46, float %7774, float %32, float %7775)  ; FMad(a,b,c)
  %7777 = call float @dx.op.tertiary.f32(i32 46, float %7760, float %28, float %7776)  ; FMad(a,b,c)
  %7778 = fadd fast float %7777, %24
  %7779 = call float @dx.op.unary.f32(i32 6, float %7778)  ; FAbs(value)
  %7780 = fcmp fast ogt float %7779, 0x3EB0C6F7A0000000
  br i1 %7780, label %7781, label %7902

; <label>:7781                                    ; preds = %7764
  %7782 = fmul fast float %7773, %35
  %7783 = call float @dx.op.tertiary.f32(i32 46, float %7774, float %31, float %7782)  ; FMad(a,b,c)
  %7784 = call float @dx.op.tertiary.f32(i32 46, float %7760, float %27, float %7783)  ; FMad(a,b,c)
  %7785 = fadd fast float %7784, %23
  %7786 = fmul fast float %7773, %34
  %7787 = call float @dx.op.tertiary.f32(i32 46, float %7774, float %30, float %7786)  ; FMad(a,b,c)
  %7788 = call float @dx.op.tertiary.f32(i32 46, float %7760, float %26, float %7787)  ; FMad(a,b,c)
  %7789 = fadd fast float %7788, %22
  %7790 = fmul fast float %7773, %33
  %7791 = call float @dx.op.tertiary.f32(i32 46, float %7774, float %29, float %7790)  ; FMad(a,b,c)
  %7792 = call float @dx.op.tertiary.f32(i32 46, float %7760, float %25, float %7791)  ; FMad(a,b,c)
  %7793 = fadd fast float %7792, %21
  %7794 = fdiv fast float %7793, %7778
  %7795 = fdiv fast float %7789, %7778
  %7796 = fdiv fast float %7785, %7778
  %7797 = fsub fast float %7794, %18
  %7798 = fsub fast float %7795, %19
  %7799 = fsub fast float %7796, %20
  %7800 = fmul fast float %7797, %7797
  %7801 = fmul fast float %7798, %7798
  %7802 = fadd fast float %7801, %7800
  %7803 = fmul fast float %7799, %7799
  %7804 = fadd fast float %7802, %7803
  %7805 = call float @dx.op.unary.f32(i32 24, float %7804)  ; Sqrt(value)
  %7806 = fsub fast float %7805, %10
  %7807 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %7806)  ; FMax(a,b)
  %7808 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %7808, label %7809, label %7832

; <label>:7809                                    ; preds = %7781
  %7810 = call float @dx.op.unary.f32(i32 6, float %7798)  ; FAbs(value)
  %7811 = fmul fast float %7810, %12
  %7812 = fcmp fast olt float %7811, 0x3F50624DE0000000
  br i1 %7812, label %7813, label %7816

; <label>:7813                                    ; preds = %7809
  %7814 = fmul fast float %7811, 5.000000e-01
  %7815 = fsub fast float 1.000000e+00, %7814
  br label %7821

; <label>:7816                                    ; preds = %7809
  %7817 = fmul fast float %7811, 0xBFF7154760000000
  %7818 = call float @dx.op.unary.f32(i32 21, float %7817)  ; Exp(value)
  %7819 = fsub fast float 1.000000e+00, %7818
  %7820 = fdiv fast float %7819, %7811
  br label %7821

; <label>:7821                                    ; preds = %7816, %7813
  %7822 = phi float [ %7815, %7813 ], [ %7820, %7816 ]
  %7823 = call float @dx.op.binary.f32(i32 36, float %7795, float %19)  ; FMin(a,b)
  %7824 = fsub fast float %7823, %11
  %7825 = fmul fast float %12, %7824
  %7826 = fsub fast float -0.000000e+00, %7825
  %7827 = call float @dx.op.binary.f32(i32 35, float %7826, float -4.000000e+01)  ; FMax(a,b)
  %7828 = call float @dx.op.binary.f32(i32 36, float %7827, float 5.000000e+00)  ; FMin(a,b)
  %7829 = fmul fast float %7828, 0x3FF7154760000000
  %7830 = call float @dx.op.unary.f32(i32 21, float %7829)  ; Exp(value)
  %7831 = fmul fast float %7830, %7822
  br label %7832

; <label>:7832                                    ; preds = %7821, %7781
  %7833 = phi float [ %7831, %7821 ], [ 1.000000e+00, %7781 ]
  %7834 = fmul fast float %7807, %17
  %7835 = fmul fast float %7834, %7833
  %7836 = fcmp fast ole float %7805, %10
  %7837 = fcmp fast olt float %7805, 0x3F1A36E2E0000000
  %7838 = or i1 %7836, %7837
  br i1 %7838, label %7885, label %7839

; <label>:7839                                    ; preds = %7832
  %7840 = fdiv fast float %10, %7805
  %7841 = fmul fast float %7840, %7797
  %7842 = fmul fast float %7840, %7798
  %7843 = fmul fast float %7840, %7799
  %7844 = fadd fast float %7841, %18
  %7845 = fadd fast float %7842, %19
  %7846 = fadd fast float %7843, %20
  %7847 = fadd fast float %7844, -9.000000e+02
  %7848 = fadd fast float %7845, -1.500000e+01
  %7849 = fadd fast float %7846, -7.500000e+02
  %7850 = fmul fast float %7847, 0x3F62345680000000
  %7851 = fmul fast float %7848, 0x3F62345680000000
  %7852 = fmul fast float %7849, 0x3F62345680000000
  %7853 = call float @dx.op.dot3.f32(i32 55, float %7850, float %7851, float %7852, float %7850, float %7851, float %7852)  ; Dot3(ax,ay,az,bx,by,bz)
  %7854 = fsub fast float 1.000000e+00, %7853
  %7855 = call float @dx.op.unary.f32(i32 7, float %7854)  ; Saturate(value)
  %7856 = fmul fast float %7855, %7855
  %7857 = fadd fast float %7844, %7794
  %7858 = fadd fast float %7845, %7795
  %7859 = fadd fast float %7846, %7796
  %7860 = fmul fast float %7857, 0x3F52345680000000
  %7861 = fadd fast float %7860, -2.000000e+00
  %7862 = fmul fast float %7858, 0x3F52345680000000
  %7863 = fadd fast float %7862, 0xBFA1111120000000
  %7864 = fmul fast float %7859, 0x3F52345680000000
  %7865 = fadd fast float %7864, 0xBFFAAAAAC0000000
  %7866 = call float @dx.op.dot3.f32(i32 55, float %7861, float %7863, float %7865, float %7861, float %7863, float %7865)  ; Dot3(ax,ay,az,bx,by,bz)
  %7867 = fsub fast float 1.000000e+00, %7866
  %7868 = call float @dx.op.unary.f32(i32 7, float %7867)  ; Saturate(value)
  %7869 = fmul fast float %7868, %7868
  %7870 = fmul fast float %7869, 4.000000e+00
  %7871 = fadd fast float %7870, %7856
  %7872 = fadd fast float %7794, -9.000000e+02
  %7873 = fadd fast float %7795, -1.500000e+01
  %7874 = fadd fast float %7796, -7.500000e+02
  %7875 = fmul fast float %7872, 0x3F62345680000000
  %7876 = fmul fast float %7873, 0x3F62345680000000
  %7877 = fmul fast float %7874, 0x3F62345680000000
  %7878 = call float @dx.op.dot3.f32(i32 55, float %7875, float %7876, float %7877, float %7875, float %7876, float %7877)  ; Dot3(ax,ay,az,bx,by,bz)
  %7879 = fsub fast float 1.000000e+00, %7878
  %7880 = call float @dx.op.unary.f32(i32 7, float %7879)  ; Saturate(value)
  %7881 = fmul fast float %7880, %7880
  %7882 = fadd fast float %7871, %7881
  %7883 = fmul fast float %7806, 0x3F25D867E0000000
  %7884 = fmul fast float %7883, %7882
  br label %7885

; <label>:7885                                    ; preds = %7839, %7832
  %7886 = phi float [ %7884, %7839 ], [ 0.000000e+00, %7832 ]
  %7887 = fadd fast float %7886, %7835
  %7888 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %7887)  ; FMin(a,b)
  %7889 = fmul fast float %7888, 0xBFF7154760000000
  %7890 = call float @dx.op.unary.f32(i32 21, float %7889)  ; Exp(value)
  %7891 = fsub fast float 1.000000e+00, %7890
  %7892 = call float @dx.op.binary.f32(i32 36, float %13, float %7891)  ; FMin(a,b)
  %7893 = fsub fast float %14, %7719
  %7894 = fsub fast float %15, %7720
  %7895 = fsub fast float %16, %7721
  %7896 = fmul fast float %7892, %7893
  %7897 = fmul fast float %7892, %7894
  %7898 = fmul fast float %7892, %7895
  %7899 = fadd fast float %7896, %7719
  %7900 = fadd fast float %7897, %7720
  %7901 = fadd fast float %7898, %7721
  br label %7902

; <label>:7902                                    ; preds = %7885, %7764, %7758
  %7903 = phi float [ %7899, %7885 ], [ %7719, %7764 ], [ %7719, %7758 ]
  %7904 = phi float [ %7900, %7885 ], [ %7720, %7764 ], [ %7720, %7758 ]
  %7905 = phi float [ %7901, %7885 ], [ %7721, %7764 ], [ %7721, %7758 ]
  %7906 = fadd fast float %6, 1.000000e+00
  %7907 = fadd fast float %7, 1.000000e+00
  %7908 = fsub fast float 1.000000e+00, %6
  %7909 = fmul fast float %37, %7906
  %7910 = fmul fast float %37, %7907
  %7911 = fmul fast float %37, %7908
  %7912 = fmul fast float %7909, %7903
  %7913 = fmul fast float %7910, %7904
  %7914 = fmul fast float %7911, %7905
  %7915 = fcmp fast ult float %38, 5.000000e-01
  br i1 %7915, label %7941, label %7916

; <label>:7916                                    ; preds = %7902
  %7917 = fmul fast float %7912, 0x4004147AE0000000
  %7918 = fmul fast float %7913, 0x4004147AE0000000
  %7919 = fmul fast float %7914, 0x4004147AE0000000
  %7920 = fadd fast float %7917, 0x3F9EB851E0000000
  %7921 = fadd fast float %7918, 0x3F9EB851E0000000
  %7922 = fadd fast float %7919, 0x3F9EB851E0000000
  %7923 = fmul fast float %7920, %7912
  %7924 = fmul fast float %7921, %7913
  %7925 = fmul fast float %7922, %7914
  %7926 = fmul fast float %7912, 0x400370A3E0000000
  %7927 = fmul fast float %7913, 0x400370A3E0000000
  %7928 = fmul fast float %7914, 0x400370A3E0000000
  %7929 = fadd fast float %7926, 0x3FE2E147A0000000
  %7930 = fadd fast float %7927, 0x3FE2E147A0000000
  %7931 = fadd fast float %7928, 0x3FE2E147A0000000
  %7932 = fmul fast float %7929, %7912
  %7933 = fmul fast float %7930, %7913
  %7934 = fmul fast float %7931, %7914
  %7935 = fadd fast float %7932, 0x3FC1EB8520000000
  %7936 = fadd fast float %7933, 0x3FC1EB8520000000
  %7937 = fadd fast float %7934, 0x3FC1EB8520000000
  %7938 = fdiv fast float %7923, %7935
  %7939 = fdiv fast float %7924, %7936
  %7940 = fdiv fast float %7925, %7937
  br label %7941

; <label>:7941                                    ; preds = %7916, %7902
  %7942 = phi float [ %7938, %7916 ], [ %7912, %7902 ]
  %7943 = phi float [ %7939, %7916 ], [ %7913, %7902 ]
  %7944 = phi float [ %7940, %7916 ], [ %7914, %7902 ]
  %7945 = call float @dx.op.unary.f32(i32 7, float %7942)  ; Saturate(value)
  %7946 = call float @dx.op.unary.f32(i32 7, float %7943)  ; Saturate(value)
  %7947 = call float @dx.op.unary.f32(i32 7, float %7944)  ; Saturate(value)
  %7948 = call float @dx.op.dot3.f32(i32 55, float %7945, float %7946, float %7947, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %7949 = fsub fast float %7945, %7948
  %7950 = fsub fast float %7946, %7948
  %7951 = fsub fast float %7947, %7948
  %7952 = fmul fast float %7949, %9
  %7953 = fmul fast float %7950, %9
  %7954 = fmul fast float %7951, %9
  %7955 = fadd fast float %7952, %7948
  %7956 = fadd fast float %7953, %7948
  %7957 = fadd fast float %7954, %7948
  %7958 = call float @dx.op.unary.f32(i32 7, float %7955)  ; Saturate(value)
  %7959 = call float @dx.op.unary.f32(i32 7, float %7956)  ; Saturate(value)
  %7960 = call float @dx.op.unary.f32(i32 7, float %7957)  ; Saturate(value)
  %7961 = fadd fast float %7958, 0xBFC70A3D80000000
  %7962 = fadd fast float %7959, 0xBFC70A3D80000000
  %7963 = fadd fast float %7960, 0xBFC70A3D80000000
  %7964 = fmul fast float %7961, %8
  %7965 = fmul fast float %7962, %8
  %7966 = fmul fast float %7963, %8
  %7967 = fadd fast float %7964, 0x3FC70A3D80000000
  %7968 = fadd fast float %7965, 0x3FC70A3D80000000
  %7969 = fadd fast float %7966, 0x3FC70A3D80000000
  %7970 = call float @dx.op.unary.f32(i32 7, float %7967)  ; Saturate(value)
  %7971 = call float @dx.op.unary.f32(i32 7, float %7968)  ; Saturate(value)
  %7972 = call float @dx.op.unary.f32(i32 7, float %7969)  ; Saturate(value)
  br label %7973

; <label>:7973                                    ; preds = %7941, %7724
  %7974 = phi float [ %7755, %7724 ], [ %7970, %7941 ]
  %7975 = phi float [ %7756, %7724 ], [ %7971, %7941 ]
  %7976 = phi float [ %7757, %7724 ], [ %7972, %7941 ]
  %7977 = fsub fast float %7974, %7404
  %7978 = fsub fast float %7975, %7405
  %7979 = fsub fast float %7976, %7406
  %7980 = fmul fast float %7977, %7711
  %7981 = fmul fast float %7978, %7711
  %7982 = fmul fast float %7979, %7711
  %7983 = fadd fast float %7980, %7404
  %7984 = fadd fast float %7981, %7405
  %7985 = fadd fast float %7982, %7406
  br label %7986

; <label>:7986                                    ; preds = %7973, %7698
  %7987 = phi float [ %7983, %7973 ], [ %7404, %7698 ]
  %7988 = phi float [ %7984, %7973 ], [ %7405, %7698 ]
  %7989 = phi float [ %7985, %7973 ], [ %7406, %7698 ]
  %7990 = add i32 %64, -1
  %7991 = call i32 @dx.op.binary.i32(i32 37, i32 %7990, i32 0)  ; IMax(a,b)
  %7992 = call i32 @dx.op.binary.i32(i32 37, i32 %71, i32 0)  ; IMax(a,b)
  %7993 = call i32 @dx.op.binary.i32(i32 38, i32 %7991, i32 %60)  ; IMin(a,b)
  %7994 = call i32 @dx.op.binary.i32(i32 38, i32 %7992, i32 %61)  ; IMin(a,b)
  %7995 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %7993, i32 %7994, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7996 = extractvalue %dx.types.ResRet.f32 %7995, 0
  %7997 = fsub fast float %7996, %87
  %7998 = call float @dx.op.unary.f32(i32 6, float %7997)  ; FAbs(value)
  %7999 = fdiv fast float %7998, %7418
  %8000 = fsub fast float 1.000000e+00, %7999
  %8001 = call float @dx.op.unary.f32(i32 7, float %8000)  ; Saturate(value)
  %8002 = fcmp fast ugt float %8001, 0.000000e+00
  br i1 %8002, label %8003, label %8276

; <label>:8003                                    ; preds = %7986
  %8004 = call i32 @dx.op.binary.i32(i32 37, i32 %7993, i32 0)  ; IMax(a,b)
  %8005 = call i32 @dx.op.binary.i32(i32 37, i32 %7994, i32 0)  ; IMax(a,b)
  %8006 = call i32 @dx.op.binary.i32(i32 38, i32 %8004, i32 %60)  ; IMin(a,b)
  %8007 = call i32 @dx.op.binary.i32(i32 38, i32 %8005, i32 %61)  ; IMin(a,b)
  %8008 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %8006, i32 %8007, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %8009 = extractvalue %dx.types.ResRet.f32 %8008, 0
  %8010 = extractvalue %dx.types.ResRet.f32 %8008, 1
  %8011 = extractvalue %dx.types.ResRet.f32 %8008, 2
  %8012 = extractvalue %dx.types.ResRet.f32 %8008, 3
  %8013 = fcmp fast olt float %8012, 0.000000e+00
  br i1 %8013, label %8014, label %8048

; <label>:8014                                    ; preds = %8003
  %8015 = fcmp fast ogt float %8009, 0x3FA4B5DCC0000000
  %8016 = fcmp fast ogt float %8010, 0x3FA4B5DCC0000000
  %8017 = fcmp fast ogt float %8011, 0x3FA4B5DCC0000000
  %8018 = select i1 %8015, float 0.000000e+00, float 1.000000e+00
  %8019 = select i1 %8016, float 0.000000e+00, float 1.000000e+00
  %8020 = select i1 %8017, float 0.000000e+00, float 1.000000e+00
  %8021 = fmul fast float %8009, 0x3FB3D07220000000
  %8022 = fmul fast float %8010, 0x3FB3D07220000000
  %8023 = fmul fast float %8011, 0x3FB3D07220000000
  %8024 = fadd fast float %8009, 0x3FAC28F5C0000000
  %8025 = fadd fast float %8010, 0x3FAC28F5C0000000
  %8026 = fadd fast float %8011, 0x3FAC28F5C0000000
  %8027 = fmul fast float %8024, 0x3FEE54EDE0000000
  %8028 = fmul fast float %8025, 0x3FEE54EDE0000000
  %8029 = fmul fast float %8026, 0x3FEE54EDE0000000
  %8030 = call float @dx.op.unary.f32(i32 23, float %8027)  ; Log(value)
  %8031 = call float @dx.op.unary.f32(i32 23, float %8028)  ; Log(value)
  %8032 = call float @dx.op.unary.f32(i32 23, float %8029)  ; Log(value)
  %8033 = fmul fast float %8030, 0x4003333340000000
  %8034 = fmul fast float %8031, 0x4003333340000000
  %8035 = fmul fast float %8032, 0x4003333340000000
  %8036 = call float @dx.op.unary.f32(i32 21, float %8033)  ; Exp(value)
  %8037 = call float @dx.op.unary.f32(i32 21, float %8034)  ; Exp(value)
  %8038 = call float @dx.op.unary.f32(i32 21, float %8035)  ; Exp(value)
  %8039 = fsub fast float %8021, %8036
  %8040 = fsub fast float %8022, %8037
  %8041 = fsub fast float %8023, %8038
  %8042 = fmul fast float %8039, %8018
  %8043 = fmul fast float %8040, %8019
  %8044 = fmul fast float %8041, %8020
  %8045 = fadd fast float %8042, %8036
  %8046 = fadd fast float %8043, %8037
  %8047 = fadd fast float %8044, %8038
  br label %8263

; <label>:8048                                    ; preds = %8003
  %8049 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %8006, i32 %8007, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %8050 = extractvalue %dx.types.ResRet.f32 %8049, 0
  %8051 = fcmp fast ogt float %39, 5.000000e-01
  %8052 = fcmp fast olt float %8050, 1.000000e+00
  %8053 = and i1 %8051, %8052
  br i1 %8053, label %8054, label %8192

; <label>:8054                                    ; preds = %8048
  %8055 = sitofp i32 %8006 to float
  %8056 = sitofp i32 %8007 to float
  %8057 = fadd fast float %8055, 5.000000e-01
  %8058 = fadd fast float %8056, 5.000000e-01
  %8059 = fdiv fast float %8057, %46
  %8060 = fdiv fast float %8058, %47
  %8061 = fmul fast float %8059, 2.000000e+00
  %8062 = fmul fast float %8060, 2.000000e+00
  %8063 = fadd fast float %8061, -1.000000e+00
  %8064 = fsub fast float 1.000000e+00, %8062
  %8065 = fmul fast float %8063, %36
  %8066 = call float @dx.op.tertiary.f32(i32 46, float %8064, float %32, float %8065)  ; FMad(a,b,c)
  %8067 = call float @dx.op.tertiary.f32(i32 46, float %8050, float %28, float %8066)  ; FMad(a,b,c)
  %8068 = fadd fast float %8067, %24
  %8069 = call float @dx.op.unary.f32(i32 6, float %8068)  ; FAbs(value)
  %8070 = fcmp fast ogt float %8069, 0x3EB0C6F7A0000000
  br i1 %8070, label %8071, label %8192

; <label>:8071                                    ; preds = %8054
  %8072 = fmul fast float %8063, %35
  %8073 = call float @dx.op.tertiary.f32(i32 46, float %8064, float %31, float %8072)  ; FMad(a,b,c)
  %8074 = call float @dx.op.tertiary.f32(i32 46, float %8050, float %27, float %8073)  ; FMad(a,b,c)
  %8075 = fadd fast float %8074, %23
  %8076 = fmul fast float %8063, %34
  %8077 = call float @dx.op.tertiary.f32(i32 46, float %8064, float %30, float %8076)  ; FMad(a,b,c)
  %8078 = call float @dx.op.tertiary.f32(i32 46, float %8050, float %26, float %8077)  ; FMad(a,b,c)
  %8079 = fadd fast float %8078, %22
  %8080 = fmul fast float %8063, %33
  %8081 = call float @dx.op.tertiary.f32(i32 46, float %8064, float %29, float %8080)  ; FMad(a,b,c)
  %8082 = call float @dx.op.tertiary.f32(i32 46, float %8050, float %25, float %8081)  ; FMad(a,b,c)
  %8083 = fadd fast float %8082, %21
  %8084 = fdiv fast float %8083, %8068
  %8085 = fdiv fast float %8079, %8068
  %8086 = fdiv fast float %8075, %8068
  %8087 = fsub fast float %8084, %18
  %8088 = fsub fast float %8085, %19
  %8089 = fsub fast float %8086, %20
  %8090 = fmul fast float %8087, %8087
  %8091 = fmul fast float %8088, %8088
  %8092 = fadd fast float %8091, %8090
  %8093 = fmul fast float %8089, %8089
  %8094 = fadd fast float %8092, %8093
  %8095 = call float @dx.op.unary.f32(i32 24, float %8094)  ; Sqrt(value)
  %8096 = fsub fast float %8095, %10
  %8097 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %8096)  ; FMax(a,b)
  %8098 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %8098, label %8099, label %8122

; <label>:8099                                    ; preds = %8071
  %8100 = call float @dx.op.unary.f32(i32 6, float %8088)  ; FAbs(value)
  %8101 = fmul fast float %8100, %12
  %8102 = fcmp fast olt float %8101, 0x3F50624DE0000000
  br i1 %8102, label %8103, label %8106

; <label>:8103                                    ; preds = %8099
  %8104 = fmul fast float %8101, 5.000000e-01
  %8105 = fsub fast float 1.000000e+00, %8104
  br label %8111

; <label>:8106                                    ; preds = %8099
  %8107 = fmul fast float %8101, 0xBFF7154760000000
  %8108 = call float @dx.op.unary.f32(i32 21, float %8107)  ; Exp(value)
  %8109 = fsub fast float 1.000000e+00, %8108
  %8110 = fdiv fast float %8109, %8101
  br label %8111

; <label>:8111                                    ; preds = %8106, %8103
  %8112 = phi float [ %8105, %8103 ], [ %8110, %8106 ]
  %8113 = call float @dx.op.binary.f32(i32 36, float %8085, float %19)  ; FMin(a,b)
  %8114 = fsub fast float %8113, %11
  %8115 = fmul fast float %12, %8114
  %8116 = fsub fast float -0.000000e+00, %8115
  %8117 = call float @dx.op.binary.f32(i32 35, float %8116, float -4.000000e+01)  ; FMax(a,b)
  %8118 = call float @dx.op.binary.f32(i32 36, float %8117, float 5.000000e+00)  ; FMin(a,b)
  %8119 = fmul fast float %8118, 0x3FF7154760000000
  %8120 = call float @dx.op.unary.f32(i32 21, float %8119)  ; Exp(value)
  %8121 = fmul fast float %8120, %8112
  br label %8122

; <label>:8122                                    ; preds = %8111, %8071
  %8123 = phi float [ %8121, %8111 ], [ 1.000000e+00, %8071 ]
  %8124 = fmul fast float %8097, %17
  %8125 = fmul fast float %8124, %8123
  %8126 = fcmp fast ole float %8095, %10
  %8127 = fcmp fast olt float %8095, 0x3F1A36E2E0000000
  %8128 = or i1 %8126, %8127
  br i1 %8128, label %8175, label %8129

; <label>:8129                                    ; preds = %8122
  %8130 = fdiv fast float %10, %8095
  %8131 = fmul fast float %8130, %8087
  %8132 = fmul fast float %8130, %8088
  %8133 = fmul fast float %8130, %8089
  %8134 = fadd fast float %8131, %18
  %8135 = fadd fast float %8132, %19
  %8136 = fadd fast float %8133, %20
  %8137 = fadd fast float %8134, -9.000000e+02
  %8138 = fadd fast float %8135, -1.500000e+01
  %8139 = fadd fast float %8136, -7.500000e+02
  %8140 = fmul fast float %8137, 0x3F62345680000000
  %8141 = fmul fast float %8138, 0x3F62345680000000
  %8142 = fmul fast float %8139, 0x3F62345680000000
  %8143 = call float @dx.op.dot3.f32(i32 55, float %8140, float %8141, float %8142, float %8140, float %8141, float %8142)  ; Dot3(ax,ay,az,bx,by,bz)
  %8144 = fsub fast float 1.000000e+00, %8143
  %8145 = call float @dx.op.unary.f32(i32 7, float %8144)  ; Saturate(value)
  %8146 = fmul fast float %8145, %8145
  %8147 = fadd fast float %8134, %8084
  %8148 = fadd fast float %8135, %8085
  %8149 = fadd fast float %8136, %8086
  %8150 = fmul fast float %8147, 0x3F52345680000000
  %8151 = fadd fast float %8150, -2.000000e+00
  %8152 = fmul fast float %8148, 0x3F52345680000000
  %8153 = fadd fast float %8152, 0xBFA1111120000000
  %8154 = fmul fast float %8149, 0x3F52345680000000
  %8155 = fadd fast float %8154, 0xBFFAAAAAC0000000
  %8156 = call float @dx.op.dot3.f32(i32 55, float %8151, float %8153, float %8155, float %8151, float %8153, float %8155)  ; Dot3(ax,ay,az,bx,by,bz)
  %8157 = fsub fast float 1.000000e+00, %8156
  %8158 = call float @dx.op.unary.f32(i32 7, float %8157)  ; Saturate(value)
  %8159 = fmul fast float %8158, %8158
  %8160 = fmul fast float %8159, 4.000000e+00
  %8161 = fadd fast float %8160, %8146
  %8162 = fadd fast float %8084, -9.000000e+02
  %8163 = fadd fast float %8085, -1.500000e+01
  %8164 = fadd fast float %8086, -7.500000e+02
  %8165 = fmul fast float %8162, 0x3F62345680000000
  %8166 = fmul fast float %8163, 0x3F62345680000000
  %8167 = fmul fast float %8164, 0x3F62345680000000
  %8168 = call float @dx.op.dot3.f32(i32 55, float %8165, float %8166, float %8167, float %8165, float %8166, float %8167)  ; Dot3(ax,ay,az,bx,by,bz)
  %8169 = fsub fast float 1.000000e+00, %8168
  %8170 = call float @dx.op.unary.f32(i32 7, float %8169)  ; Saturate(value)
  %8171 = fmul fast float %8170, %8170
  %8172 = fadd fast float %8161, %8171
  %8173 = fmul fast float %8096, 0x3F25D867E0000000
  %8174 = fmul fast float %8173, %8172
  br label %8175

; <label>:8175                                    ; preds = %8129, %8122
  %8176 = phi float [ %8174, %8129 ], [ 0.000000e+00, %8122 ]
  %8177 = fadd fast float %8176, %8125
  %8178 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %8177)  ; FMin(a,b)
  %8179 = fmul fast float %8178, 0xBFF7154760000000
  %8180 = call float @dx.op.unary.f32(i32 21, float %8179)  ; Exp(value)
  %8181 = fsub fast float 1.000000e+00, %8180
  %8182 = call float @dx.op.binary.f32(i32 36, float %13, float %8181)  ; FMin(a,b)
  %8183 = fsub fast float %14, %8009
  %8184 = fsub fast float %15, %8010
  %8185 = fsub fast float %16, %8011
  %8186 = fmul fast float %8182, %8183
  %8187 = fmul fast float %8182, %8184
  %8188 = fmul fast float %8182, %8185
  %8189 = fadd fast float %8186, %8009
  %8190 = fadd fast float %8187, %8010
  %8191 = fadd fast float %8188, %8011
  br label %8192

; <label>:8192                                    ; preds = %8175, %8054, %8048
  %8193 = phi float [ %8189, %8175 ], [ %8009, %8054 ], [ %8009, %8048 ]
  %8194 = phi float [ %8190, %8175 ], [ %8010, %8054 ], [ %8010, %8048 ]
  %8195 = phi float [ %8191, %8175 ], [ %8011, %8054 ], [ %8011, %8048 ]
  %8196 = fadd fast float %6, 1.000000e+00
  %8197 = fadd fast float %7, 1.000000e+00
  %8198 = fsub fast float 1.000000e+00, %6
  %8199 = fmul fast float %37, %8196
  %8200 = fmul fast float %37, %8197
  %8201 = fmul fast float %37, %8198
  %8202 = fmul fast float %8199, %8193
  %8203 = fmul fast float %8200, %8194
  %8204 = fmul fast float %8201, %8195
  %8205 = fcmp fast ult float %38, 5.000000e-01
  br i1 %8205, label %8231, label %8206

; <label>:8206                                    ; preds = %8192
  %8207 = fmul fast float %8202, 0x4004147AE0000000
  %8208 = fmul fast float %8203, 0x4004147AE0000000
  %8209 = fmul fast float %8204, 0x4004147AE0000000
  %8210 = fadd fast float %8207, 0x3F9EB851E0000000
  %8211 = fadd fast float %8208, 0x3F9EB851E0000000
  %8212 = fadd fast float %8209, 0x3F9EB851E0000000
  %8213 = fmul fast float %8210, %8202
  %8214 = fmul fast float %8211, %8203
  %8215 = fmul fast float %8212, %8204
  %8216 = fmul fast float %8202, 0x400370A3E0000000
  %8217 = fmul fast float %8203, 0x400370A3E0000000
  %8218 = fmul fast float %8204, 0x400370A3E0000000
  %8219 = fadd fast float %8216, 0x3FE2E147A0000000
  %8220 = fadd fast float %8217, 0x3FE2E147A0000000
  %8221 = fadd fast float %8218, 0x3FE2E147A0000000
  %8222 = fmul fast float %8219, %8202
  %8223 = fmul fast float %8220, %8203
  %8224 = fmul fast float %8221, %8204
  %8225 = fadd fast float %8222, 0x3FC1EB8520000000
  %8226 = fadd fast float %8223, 0x3FC1EB8520000000
  %8227 = fadd fast float %8224, 0x3FC1EB8520000000
  %8228 = fdiv fast float %8213, %8225
  %8229 = fdiv fast float %8214, %8226
  %8230 = fdiv fast float %8215, %8227
  br label %8231

; <label>:8231                                    ; preds = %8206, %8192
  %8232 = phi float [ %8228, %8206 ], [ %8202, %8192 ]
  %8233 = phi float [ %8229, %8206 ], [ %8203, %8192 ]
  %8234 = phi float [ %8230, %8206 ], [ %8204, %8192 ]
  %8235 = call float @dx.op.unary.f32(i32 7, float %8232)  ; Saturate(value)
  %8236 = call float @dx.op.unary.f32(i32 7, float %8233)  ; Saturate(value)
  %8237 = call float @dx.op.unary.f32(i32 7, float %8234)  ; Saturate(value)
  %8238 = call float @dx.op.dot3.f32(i32 55, float %8235, float %8236, float %8237, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %8239 = fsub fast float %8235, %8238
  %8240 = fsub fast float %8236, %8238
  %8241 = fsub fast float %8237, %8238
  %8242 = fmul fast float %8239, %9
  %8243 = fmul fast float %8240, %9
  %8244 = fmul fast float %8241, %9
  %8245 = fadd fast float %8242, %8238
  %8246 = fadd fast float %8243, %8238
  %8247 = fadd fast float %8244, %8238
  %8248 = call float @dx.op.unary.f32(i32 7, float %8245)  ; Saturate(value)
  %8249 = call float @dx.op.unary.f32(i32 7, float %8246)  ; Saturate(value)
  %8250 = call float @dx.op.unary.f32(i32 7, float %8247)  ; Saturate(value)
  %8251 = fadd fast float %8248, 0xBFC70A3D80000000
  %8252 = fadd fast float %8249, 0xBFC70A3D80000000
  %8253 = fadd fast float %8250, 0xBFC70A3D80000000
  %8254 = fmul fast float %8251, %8
  %8255 = fmul fast float %8252, %8
  %8256 = fmul fast float %8253, %8
  %8257 = fadd fast float %8254, 0x3FC70A3D80000000
  %8258 = fadd fast float %8255, 0x3FC70A3D80000000
  %8259 = fadd fast float %8256, 0x3FC70A3D80000000
  %8260 = call float @dx.op.unary.f32(i32 7, float %8257)  ; Saturate(value)
  %8261 = call float @dx.op.unary.f32(i32 7, float %8258)  ; Saturate(value)
  %8262 = call float @dx.op.unary.f32(i32 7, float %8259)  ; Saturate(value)
  br label %8263

; <label>:8263                                    ; preds = %8231, %8014
  %8264 = phi float [ %8045, %8014 ], [ %8260, %8231 ]
  %8265 = phi float [ %8046, %8014 ], [ %8261, %8231 ]
  %8266 = phi float [ %8047, %8014 ], [ %8262, %8231 ]
  %8267 = fsub fast float %8264, %7404
  %8268 = fsub fast float %8265, %7405
  %8269 = fsub fast float %8266, %7406
  %8270 = fmul fast float %8267, %8001
  %8271 = fmul fast float %8268, %8001
  %8272 = fmul fast float %8269, %8001
  %8273 = fadd fast float %8270, %7404
  %8274 = fadd fast float %8271, %7405
  %8275 = fadd fast float %8272, %7406
  br label %8276

; <label>:8276                                    ; preds = %8263, %7986
  %8277 = phi float [ %8273, %8263 ], [ %7404, %7986 ]
  %8278 = phi float [ %8274, %8263 ], [ %7405, %7986 ]
  %8279 = phi float [ %8275, %8263 ], [ %7406, %7986 ]
  %8280 = add i32 %64, 1
  %8281 = call i32 @dx.op.binary.i32(i32 37, i32 %8280, i32 0)  ; IMax(a,b)
  %8282 = call i32 @dx.op.binary.i32(i32 38, i32 %8281, i32 %60)  ; IMin(a,b)
  %8283 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %8282, i32 %7994, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %8284 = extractvalue %dx.types.ResRet.f32 %8283, 0
  %8285 = fsub fast float %8284, %87
  %8286 = call float @dx.op.unary.f32(i32 6, float %8285)  ; FAbs(value)
  %8287 = fdiv fast float %8286, %7418
  %8288 = fsub fast float 1.000000e+00, %8287
  %8289 = call float @dx.op.unary.f32(i32 7, float %8288)  ; Saturate(value)
  %8290 = fcmp fast ugt float %8289, 0.000000e+00
  br i1 %8290, label %8291, label %8564

; <label>:8291                                    ; preds = %8276
  %8292 = call i32 @dx.op.binary.i32(i32 37, i32 %8282, i32 0)  ; IMax(a,b)
  %8293 = call i32 @dx.op.binary.i32(i32 37, i32 %7994, i32 0)  ; IMax(a,b)
  %8294 = call i32 @dx.op.binary.i32(i32 38, i32 %8292, i32 %60)  ; IMin(a,b)
  %8295 = call i32 @dx.op.binary.i32(i32 38, i32 %8293, i32 %61)  ; IMin(a,b)
  %8296 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %8294, i32 %8295, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %8297 = extractvalue %dx.types.ResRet.f32 %8296, 0
  %8298 = extractvalue %dx.types.ResRet.f32 %8296, 1
  %8299 = extractvalue %dx.types.ResRet.f32 %8296, 2
  %8300 = extractvalue %dx.types.ResRet.f32 %8296, 3
  %8301 = fcmp fast olt float %8300, 0.000000e+00
  br i1 %8301, label %8302, label %8336

; <label>:8302                                    ; preds = %8291
  %8303 = fcmp fast ogt float %8297, 0x3FA4B5DCC0000000
  %8304 = fcmp fast ogt float %8298, 0x3FA4B5DCC0000000
  %8305 = fcmp fast ogt float %8299, 0x3FA4B5DCC0000000
  %8306 = select i1 %8303, float 0.000000e+00, float 1.000000e+00
  %8307 = select i1 %8304, float 0.000000e+00, float 1.000000e+00
  %8308 = select i1 %8305, float 0.000000e+00, float 1.000000e+00
  %8309 = fmul fast float %8297, 0x3FB3D07220000000
  %8310 = fmul fast float %8298, 0x3FB3D07220000000
  %8311 = fmul fast float %8299, 0x3FB3D07220000000
  %8312 = fadd fast float %8297, 0x3FAC28F5C0000000
  %8313 = fadd fast float %8298, 0x3FAC28F5C0000000
  %8314 = fadd fast float %8299, 0x3FAC28F5C0000000
  %8315 = fmul fast float %8312, 0x3FEE54EDE0000000
  %8316 = fmul fast float %8313, 0x3FEE54EDE0000000
  %8317 = fmul fast float %8314, 0x3FEE54EDE0000000
  %8318 = call float @dx.op.unary.f32(i32 23, float %8315)  ; Log(value)
  %8319 = call float @dx.op.unary.f32(i32 23, float %8316)  ; Log(value)
  %8320 = call float @dx.op.unary.f32(i32 23, float %8317)  ; Log(value)
  %8321 = fmul fast float %8318, 0x4003333340000000
  %8322 = fmul fast float %8319, 0x4003333340000000
  %8323 = fmul fast float %8320, 0x4003333340000000
  %8324 = call float @dx.op.unary.f32(i32 21, float %8321)  ; Exp(value)
  %8325 = call float @dx.op.unary.f32(i32 21, float %8322)  ; Exp(value)
  %8326 = call float @dx.op.unary.f32(i32 21, float %8323)  ; Exp(value)
  %8327 = fsub fast float %8309, %8324
  %8328 = fsub fast float %8310, %8325
  %8329 = fsub fast float %8311, %8326
  %8330 = fmul fast float %8327, %8306
  %8331 = fmul fast float %8328, %8307
  %8332 = fmul fast float %8329, %8308
  %8333 = fadd fast float %8330, %8324
  %8334 = fadd fast float %8331, %8325
  %8335 = fadd fast float %8332, %8326
  br label %8551

; <label>:8336                                    ; preds = %8291
  %8337 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %8294, i32 %8295, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %8338 = extractvalue %dx.types.ResRet.f32 %8337, 0
  %8339 = fcmp fast ogt float %39, 5.000000e-01
  %8340 = fcmp fast olt float %8338, 1.000000e+00
  %8341 = and i1 %8339, %8340
  br i1 %8341, label %8342, label %8480

; <label>:8342                                    ; preds = %8336
  %8343 = sitofp i32 %8294 to float
  %8344 = sitofp i32 %8295 to float
  %8345 = fadd fast float %8343, 5.000000e-01
  %8346 = fadd fast float %8344, 5.000000e-01
  %8347 = fdiv fast float %8345, %46
  %8348 = fdiv fast float %8346, %47
  %8349 = fmul fast float %8347, 2.000000e+00
  %8350 = fmul fast float %8348, 2.000000e+00
  %8351 = fadd fast float %8349, -1.000000e+00
  %8352 = fsub fast float 1.000000e+00, %8350
  %8353 = fmul fast float %8351, %36
  %8354 = call float @dx.op.tertiary.f32(i32 46, float %8352, float %32, float %8353)  ; FMad(a,b,c)
  %8355 = call float @dx.op.tertiary.f32(i32 46, float %8338, float %28, float %8354)  ; FMad(a,b,c)
  %8356 = fadd fast float %8355, %24
  %8357 = call float @dx.op.unary.f32(i32 6, float %8356)  ; FAbs(value)
  %8358 = fcmp fast ogt float %8357, 0x3EB0C6F7A0000000
  br i1 %8358, label %8359, label %8480

; <label>:8359                                    ; preds = %8342
  %8360 = fmul fast float %8351, %35
  %8361 = call float @dx.op.tertiary.f32(i32 46, float %8352, float %31, float %8360)  ; FMad(a,b,c)
  %8362 = call float @dx.op.tertiary.f32(i32 46, float %8338, float %27, float %8361)  ; FMad(a,b,c)
  %8363 = fadd fast float %8362, %23
  %8364 = fmul fast float %8351, %34
  %8365 = call float @dx.op.tertiary.f32(i32 46, float %8352, float %30, float %8364)  ; FMad(a,b,c)
  %8366 = call float @dx.op.tertiary.f32(i32 46, float %8338, float %26, float %8365)  ; FMad(a,b,c)
  %8367 = fadd fast float %8366, %22
  %8368 = fmul fast float %8351, %33
  %8369 = call float @dx.op.tertiary.f32(i32 46, float %8352, float %29, float %8368)  ; FMad(a,b,c)
  %8370 = call float @dx.op.tertiary.f32(i32 46, float %8338, float %25, float %8369)  ; FMad(a,b,c)
  %8371 = fadd fast float %8370, %21
  %8372 = fdiv fast float %8371, %8356
  %8373 = fdiv fast float %8367, %8356
  %8374 = fdiv fast float %8363, %8356
  %8375 = fsub fast float %8372, %18
  %8376 = fsub fast float %8373, %19
  %8377 = fsub fast float %8374, %20
  %8378 = fmul fast float %8375, %8375
  %8379 = fmul fast float %8376, %8376
  %8380 = fadd fast float %8379, %8378
  %8381 = fmul fast float %8377, %8377
  %8382 = fadd fast float %8380, %8381
  %8383 = call float @dx.op.unary.f32(i32 24, float %8382)  ; Sqrt(value)
  %8384 = fsub fast float %8383, %10
  %8385 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %8384)  ; FMax(a,b)
  %8386 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %8386, label %8387, label %8410

; <label>:8387                                    ; preds = %8359
  %8388 = call float @dx.op.unary.f32(i32 6, float %8376)  ; FAbs(value)
  %8389 = fmul fast float %8388, %12
  %8390 = fcmp fast olt float %8389, 0x3F50624DE0000000
  br i1 %8390, label %8391, label %8394

; <label>:8391                                    ; preds = %8387
  %8392 = fmul fast float %8389, 5.000000e-01
  %8393 = fsub fast float 1.000000e+00, %8392
  br label %8399

; <label>:8394                                    ; preds = %8387
  %8395 = fmul fast float %8389, 0xBFF7154760000000
  %8396 = call float @dx.op.unary.f32(i32 21, float %8395)  ; Exp(value)
  %8397 = fsub fast float 1.000000e+00, %8396
  %8398 = fdiv fast float %8397, %8389
  br label %8399

; <label>:8399                                    ; preds = %8394, %8391
  %8400 = phi float [ %8393, %8391 ], [ %8398, %8394 ]
  %8401 = call float @dx.op.binary.f32(i32 36, float %8373, float %19)  ; FMin(a,b)
  %8402 = fsub fast float %8401, %11
  %8403 = fmul fast float %12, %8402
  %8404 = fsub fast float -0.000000e+00, %8403
  %8405 = call float @dx.op.binary.f32(i32 35, float %8404, float -4.000000e+01)  ; FMax(a,b)
  %8406 = call float @dx.op.binary.f32(i32 36, float %8405, float 5.000000e+00)  ; FMin(a,b)
  %8407 = fmul fast float %8406, 0x3FF7154760000000
  %8408 = call float @dx.op.unary.f32(i32 21, float %8407)  ; Exp(value)
  %8409 = fmul fast float %8408, %8400
  br label %8410

; <label>:8410                                    ; preds = %8399, %8359
  %8411 = phi float [ %8409, %8399 ], [ 1.000000e+00, %8359 ]
  %8412 = fmul fast float %8385, %17
  %8413 = fmul fast float %8412, %8411
  %8414 = fcmp fast ole float %8383, %10
  %8415 = fcmp fast olt float %8383, 0x3F1A36E2E0000000
  %8416 = or i1 %8414, %8415
  br i1 %8416, label %8463, label %8417

; <label>:8417                                    ; preds = %8410
  %8418 = fdiv fast float %10, %8383
  %8419 = fmul fast float %8418, %8375
  %8420 = fmul fast float %8418, %8376
  %8421 = fmul fast float %8418, %8377
  %8422 = fadd fast float %8419, %18
  %8423 = fadd fast float %8420, %19
  %8424 = fadd fast float %8421, %20
  %8425 = fadd fast float %8422, -9.000000e+02
  %8426 = fadd fast float %8423, -1.500000e+01
  %8427 = fadd fast float %8424, -7.500000e+02
  %8428 = fmul fast float %8425, 0x3F62345680000000
  %8429 = fmul fast float %8426, 0x3F62345680000000
  %8430 = fmul fast float %8427, 0x3F62345680000000
  %8431 = call float @dx.op.dot3.f32(i32 55, float %8428, float %8429, float %8430, float %8428, float %8429, float %8430)  ; Dot3(ax,ay,az,bx,by,bz)
  %8432 = fsub fast float 1.000000e+00, %8431
  %8433 = call float @dx.op.unary.f32(i32 7, float %8432)  ; Saturate(value)
  %8434 = fmul fast float %8433, %8433
  %8435 = fadd fast float %8422, %8372
  %8436 = fadd fast float %8423, %8373
  %8437 = fadd fast float %8424, %8374
  %8438 = fmul fast float %8435, 0x3F52345680000000
  %8439 = fadd fast float %8438, -2.000000e+00
  %8440 = fmul fast float %8436, 0x3F52345680000000
  %8441 = fadd fast float %8440, 0xBFA1111120000000
  %8442 = fmul fast float %8437, 0x3F52345680000000
  %8443 = fadd fast float %8442, 0xBFFAAAAAC0000000
  %8444 = call float @dx.op.dot3.f32(i32 55, float %8439, float %8441, float %8443, float %8439, float %8441, float %8443)  ; Dot3(ax,ay,az,bx,by,bz)
  %8445 = fsub fast float 1.000000e+00, %8444
  %8446 = call float @dx.op.unary.f32(i32 7, float %8445)  ; Saturate(value)
  %8447 = fmul fast float %8446, %8446
  %8448 = fmul fast float %8447, 4.000000e+00
  %8449 = fadd fast float %8448, %8434
  %8450 = fadd fast float %8372, -9.000000e+02
  %8451 = fadd fast float %8373, -1.500000e+01
  %8452 = fadd fast float %8374, -7.500000e+02
  %8453 = fmul fast float %8450, 0x3F62345680000000
  %8454 = fmul fast float %8451, 0x3F62345680000000
  %8455 = fmul fast float %8452, 0x3F62345680000000
  %8456 = call float @dx.op.dot3.f32(i32 55, float %8453, float %8454, float %8455, float %8453, float %8454, float %8455)  ; Dot3(ax,ay,az,bx,by,bz)
  %8457 = fsub fast float 1.000000e+00, %8456
  %8458 = call float @dx.op.unary.f32(i32 7, float %8457)  ; Saturate(value)
  %8459 = fmul fast float %8458, %8458
  %8460 = fadd fast float %8449, %8459
  %8461 = fmul fast float %8384, 0x3F25D867E0000000
  %8462 = fmul fast float %8461, %8460
  br label %8463

; <label>:8463                                    ; preds = %8417, %8410
  %8464 = phi float [ %8462, %8417 ], [ 0.000000e+00, %8410 ]
  %8465 = fadd fast float %8464, %8413
  %8466 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %8465)  ; FMin(a,b)
  %8467 = fmul fast float %8466, 0xBFF7154760000000
  %8468 = call float @dx.op.unary.f32(i32 21, float %8467)  ; Exp(value)
  %8469 = fsub fast float 1.000000e+00, %8468
  %8470 = call float @dx.op.binary.f32(i32 36, float %13, float %8469)  ; FMin(a,b)
  %8471 = fsub fast float %14, %8297
  %8472 = fsub fast float %15, %8298
  %8473 = fsub fast float %16, %8299
  %8474 = fmul fast float %8470, %8471
  %8475 = fmul fast float %8470, %8472
  %8476 = fmul fast float %8470, %8473
  %8477 = fadd fast float %8474, %8297
  %8478 = fadd fast float %8475, %8298
  %8479 = fadd fast float %8476, %8299
  br label %8480

; <label>:8480                                    ; preds = %8463, %8342, %8336
  %8481 = phi float [ %8477, %8463 ], [ %8297, %8342 ], [ %8297, %8336 ]
  %8482 = phi float [ %8478, %8463 ], [ %8298, %8342 ], [ %8298, %8336 ]
  %8483 = phi float [ %8479, %8463 ], [ %8299, %8342 ], [ %8299, %8336 ]
  %8484 = fadd fast float %6, 1.000000e+00
  %8485 = fadd fast float %7, 1.000000e+00
  %8486 = fsub fast float 1.000000e+00, %6
  %8487 = fmul fast float %37, %8484
  %8488 = fmul fast float %37, %8485
  %8489 = fmul fast float %37, %8486
  %8490 = fmul fast float %8487, %8481
  %8491 = fmul fast float %8488, %8482
  %8492 = fmul fast float %8489, %8483
  %8493 = fcmp fast ult float %38, 5.000000e-01
  br i1 %8493, label %8519, label %8494

; <label>:8494                                    ; preds = %8480
  %8495 = fmul fast float %8490, 0x4004147AE0000000
  %8496 = fmul fast float %8491, 0x4004147AE0000000
  %8497 = fmul fast float %8492, 0x4004147AE0000000
  %8498 = fadd fast float %8495, 0x3F9EB851E0000000
  %8499 = fadd fast float %8496, 0x3F9EB851E0000000
  %8500 = fadd fast float %8497, 0x3F9EB851E0000000
  %8501 = fmul fast float %8498, %8490
  %8502 = fmul fast float %8499, %8491
  %8503 = fmul fast float %8500, %8492
  %8504 = fmul fast float %8490, 0x400370A3E0000000
  %8505 = fmul fast float %8491, 0x400370A3E0000000
  %8506 = fmul fast float %8492, 0x400370A3E0000000
  %8507 = fadd fast float %8504, 0x3FE2E147A0000000
  %8508 = fadd fast float %8505, 0x3FE2E147A0000000
  %8509 = fadd fast float %8506, 0x3FE2E147A0000000
  %8510 = fmul fast float %8507, %8490
  %8511 = fmul fast float %8508, %8491
  %8512 = fmul fast float %8509, %8492
  %8513 = fadd fast float %8510, 0x3FC1EB8520000000
  %8514 = fadd fast float %8511, 0x3FC1EB8520000000
  %8515 = fadd fast float %8512, 0x3FC1EB8520000000
  %8516 = fdiv fast float %8501, %8513
  %8517 = fdiv fast float %8502, %8514
  %8518 = fdiv fast float %8503, %8515
  br label %8519

; <label>:8519                                    ; preds = %8494, %8480
  %8520 = phi float [ %8516, %8494 ], [ %8490, %8480 ]
  %8521 = phi float [ %8517, %8494 ], [ %8491, %8480 ]
  %8522 = phi float [ %8518, %8494 ], [ %8492, %8480 ]
  %8523 = call float @dx.op.unary.f32(i32 7, float %8520)  ; Saturate(value)
  %8524 = call float @dx.op.unary.f32(i32 7, float %8521)  ; Saturate(value)
  %8525 = call float @dx.op.unary.f32(i32 7, float %8522)  ; Saturate(value)
  %8526 = call float @dx.op.dot3.f32(i32 55, float %8523, float %8524, float %8525, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %8527 = fsub fast float %8523, %8526
  %8528 = fsub fast float %8524, %8526
  %8529 = fsub fast float %8525, %8526
  %8530 = fmul fast float %8527, %9
  %8531 = fmul fast float %8528, %9
  %8532 = fmul fast float %8529, %9
  %8533 = fadd fast float %8530, %8526
  %8534 = fadd fast float %8531, %8526
  %8535 = fadd fast float %8532, %8526
  %8536 = call float @dx.op.unary.f32(i32 7, float %8533)  ; Saturate(value)
  %8537 = call float @dx.op.unary.f32(i32 7, float %8534)  ; Saturate(value)
  %8538 = call float @dx.op.unary.f32(i32 7, float %8535)  ; Saturate(value)
  %8539 = fadd fast float %8536, 0xBFC70A3D80000000
  %8540 = fadd fast float %8537, 0xBFC70A3D80000000
  %8541 = fadd fast float %8538, 0xBFC70A3D80000000
  %8542 = fmul fast float %8539, %8
  %8543 = fmul fast float %8540, %8
  %8544 = fmul fast float %8541, %8
  %8545 = fadd fast float %8542, 0x3FC70A3D80000000
  %8546 = fadd fast float %8543, 0x3FC70A3D80000000
  %8547 = fadd fast float %8544, 0x3FC70A3D80000000
  %8548 = call float @dx.op.unary.f32(i32 7, float %8545)  ; Saturate(value)
  %8549 = call float @dx.op.unary.f32(i32 7, float %8546)  ; Saturate(value)
  %8550 = call float @dx.op.unary.f32(i32 7, float %8547)  ; Saturate(value)
  br label %8551

; <label>:8551                                    ; preds = %8519, %8302
  %8552 = phi float [ %8333, %8302 ], [ %8548, %8519 ]
  %8553 = phi float [ %8334, %8302 ], [ %8549, %8519 ]
  %8554 = phi float [ %8335, %8302 ], [ %8550, %8519 ]
  %8555 = fsub fast float %8552, %7404
  %8556 = fsub fast float %8553, %7405
  %8557 = fsub fast float %8554, %7406
  %8558 = fmul fast float %8555, %8289
  %8559 = fmul fast float %8556, %8289
  %8560 = fmul fast float %8557, %8289
  %8561 = fadd fast float %8558, %7404
  %8562 = fadd fast float %8559, %7405
  %8563 = fadd fast float %8560, %7406
  br label %8564

; <label>:8564                                    ; preds = %8551, %8276
  %8565 = phi float [ %8561, %8551 ], [ %7404, %8276 ]
  %8566 = phi float [ %8562, %8551 ], [ %7405, %8276 ]
  %8567 = phi float [ %8563, %8551 ], [ %7406, %8276 ]
  %8568 = call float @dx.op.binary.f32(i32 36, float %8277, float %8565)  ; FMin(a,b)
  %8569 = call float @dx.op.binary.f32(i32 36, float %8278, float %8566)  ; FMin(a,b)
  %8570 = call float @dx.op.binary.f32(i32 36, float %8279, float %8567)  ; FMin(a,b)
  %8571 = call float @dx.op.binary.f32(i32 36, float %7699, float %7987)  ; FMin(a,b)
  %8572 = call float @dx.op.binary.f32(i32 36, float %7700, float %7988)  ; FMin(a,b)
  %8573 = call float @dx.op.binary.f32(i32 36, float %7701, float %7989)  ; FMin(a,b)
  %8574 = call float @dx.op.binary.f32(i32 36, float %8571, float %8568)  ; FMin(a,b)
  %8575 = call float @dx.op.binary.f32(i32 36, float %8572, float %8569)  ; FMin(a,b)
  %8576 = call float @dx.op.binary.f32(i32 36, float %8573, float %8570)  ; FMin(a,b)
  %8577 = call float @dx.op.binary.f32(i32 36, float %7404, float %8574)  ; FMin(a,b)
  %8578 = call float @dx.op.binary.f32(i32 36, float %7405, float %8575)  ; FMin(a,b)
  %8579 = call float @dx.op.binary.f32(i32 36, float %7406, float %8576)  ; FMin(a,b)
  %8580 = call float @dx.op.binary.f32(i32 35, float %8277, float %8565)  ; FMax(a,b)
  %8581 = call float @dx.op.binary.f32(i32 35, float %8278, float %8566)  ; FMax(a,b)
  %8582 = call float @dx.op.binary.f32(i32 35, float %8279, float %8567)  ; FMax(a,b)
  %8583 = call float @dx.op.binary.f32(i32 35, float %7699, float %7987)  ; FMax(a,b)
  %8584 = call float @dx.op.binary.f32(i32 35, float %7700, float %7988)  ; FMax(a,b)
  %8585 = call float @dx.op.binary.f32(i32 35, float %7701, float %7989)  ; FMax(a,b)
  %8586 = call float @dx.op.binary.f32(i32 35, float %8583, float %8580)  ; FMax(a,b)
  %8587 = call float @dx.op.binary.f32(i32 35, float %8584, float %8581)  ; FMax(a,b)
  %8588 = call float @dx.op.binary.f32(i32 35, float %8585, float %8582)  ; FMax(a,b)
  %8589 = call float @dx.op.binary.f32(i32 35, float %7404, float %8586)  ; FMax(a,b)
  %8590 = call float @dx.op.binary.f32(i32 35, float %7405, float %8587)  ; FMax(a,b)
  %8591 = call float @dx.op.binary.f32(i32 35, float %7406, float %8588)  ; FMax(a,b)
  %8592 = fsub fast float %8589, %8577
  %8593 = fsub fast float %8590, %8578
  %8594 = fsub fast float %8591, %8579
  %8595 = call float @dx.op.unary.f32(i32 6, float %8592)  ; FAbs(value)
  %8596 = call float @dx.op.unary.f32(i32 6, float %8593)  ; FAbs(value)
  %8597 = call float @dx.op.unary.f32(i32 6, float %8594)  ; FAbs(value)
  %8598 = call float @dx.op.binary.f32(i32 35, float %8596, float %8597)  ; FMax(a,b)
  %8599 = call float @dx.op.binary.f32(i32 35, float %8595, float %8598)  ; FMax(a,b)
  %8600 = call float @dx.op.binary.f32(i32 35, float %8590, float %8591)  ; FMax(a,b)
  %8601 = call float @dx.op.binary.f32(i32 35, float %8589, float %8600)  ; FMax(a,b)
  %8602 = fmul fast float %8601, 1.250000e-01
  %8603 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %8602)  ; FMax(a,b)
  %8604 = fcmp fast ogt float %8599, %8603
  br i1 %8604, label %8605, label %8667

; <label>:8605                                    ; preds = %8564
  %8606 = fsub fast float %7699, %7987
  %8607 = fsub fast float %7700, %7988
  %8608 = fsub fast float %7701, %7989
  %8609 = call float @dx.op.unary.f32(i32 6, float %8606)  ; FAbs(value)
  %8610 = call float @dx.op.unary.f32(i32 6, float %8607)  ; FAbs(value)
  %8611 = call float @dx.op.unary.f32(i32 6, float %8608)  ; FAbs(value)
  %8612 = call float @dx.op.binary.f32(i32 35, float %8610, float %8611)  ; FMax(a,b)
  %8613 = call float @dx.op.binary.f32(i32 35, float %8609, float %8612)  ; FMax(a,b)
  %8614 = fsub fast float %8277, %8565
  %8615 = fsub fast float %8278, %8566
  %8616 = fsub fast float %8279, %8567
  %8617 = call float @dx.op.unary.f32(i32 6, float %8614)  ; FAbs(value)
  %8618 = call float @dx.op.unary.f32(i32 6, float %8615)  ; FAbs(value)
  %8619 = call float @dx.op.unary.f32(i32 6, float %8616)  ; FAbs(value)
  %8620 = call float @dx.op.binary.f32(i32 35, float %8618, float %8619)  ; FMax(a,b)
  %8621 = call float @dx.op.binary.f32(i32 35, float %8617, float %8620)  ; FMax(a,b)
  %8622 = fcmp fast olt float %8613, %8621
  %8623 = select i1 %8622, float %7699, float %8277
  %8624 = select i1 %8622, float %7700, float %8278
  %8625 = select i1 %8622, float %7701, float %8279
  %8626 = select i1 %8622, float %7987, float %8565
  %8627 = select i1 %8622, float %7988, float %8566
  %8628 = select i1 %8622, float %7989, float %8567
  %8629 = fsub fast float %7404, %8626
  %8630 = fsub fast float %7405, %8627
  %8631 = fsub fast float %7406, %8628
  %8632 = fsub fast float %7404, %8623
  %8633 = fsub fast float %7405, %8624
  %8634 = fsub fast float %7406, %8625
  %8635 = call float @dx.op.dot3.f32(i32 55, float %8632, float %8633, float %8634, float %8629, float %8630, float %8631)  ; Dot3(ax,ay,az,bx,by,bz)
  %8636 = fcmp fast ogt float %8635, 0.000000e+00
  br i1 %8636, label %8637, label %8648

; <label>:8637                                    ; preds = %8605
  %8638 = fsub fast float %8623, %8626
  %8639 = fsub fast float %8624, %8627
  %8640 = fsub fast float %8625, %8628
  %8641 = call float @dx.op.unary.f32(i32 6, float %8638)  ; FAbs(value)
  %8642 = call float @dx.op.unary.f32(i32 6, float %8639)  ; FAbs(value)
  %8643 = call float @dx.op.unary.f32(i32 6, float %8640)  ; FAbs(value)
  %8644 = call float @dx.op.binary.f32(i32 35, float %8642, float %8643)  ; FMax(a,b)
  %8645 = call float @dx.op.binary.f32(i32 35, float %8641, float %8644)  ; FMax(a,b)
  %8646 = fmul fast float %8599, 2.500000e-01
  %8647 = fcmp fast olt float %8645, %8646
  br label %8648

; <label>:8648                                    ; preds = %8637, %8605
  %8649 = phi i1 [ false, %8605 ], [ %8647, %8637 ]
  %8650 = select i1 %8649, float 5.000000e-01, float 1.000000e+00
  %8651 = fmul fast float %8650, %3
  %8652 = fadd fast float %8623, %8626
  %8653 = fadd fast float %8624, %8627
  %8654 = fadd fast float %8625, %8628
  %8655 = fmul fast float %8652, 5.000000e-01
  %8656 = fmul fast float %8653, 5.000000e-01
  %8657 = fmul fast float %8654, 5.000000e-01
  %8658 = fsub fast float %8655, %7404
  %8659 = fsub fast float %8656, %7405
  %8660 = fsub fast float %8657, %7406
  %8661 = fmul fast float %8651, %8658
  %8662 = fmul fast float %8651, %8659
  %8663 = fmul fast float %8651, %8660
  %8664 = fadd fast float %8661, %7404
  %8665 = fadd fast float %8662, %7405
  %8666 = fadd fast float %8663, %7406
  br label %8667

; <label>:8667                                    ; preds = %8648, %8564, %7375, %7159
  %8668 = phi float [ %7190, %7159 ], [ %7404, %7375 ], [ %8664, %8648 ], [ %7404, %8564 ]
  %8669 = phi float [ %7191, %7159 ], [ %7405, %7375 ], [ %8665, %8648 ], [ %7405, %8564 ]
  %8670 = phi float [ %7192, %7159 ], [ %7406, %7375 ], [ %8666, %8648 ], [ %7406, %8564 ]
  %8671 = phi float [ %7193, %7159 ], [ %7157, %7375 ], [ %7157, %8648 ], [ %7157, %8564 ]
  %8672 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %68, i32 %71, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %8673 = extractvalue %dx.types.ResRet.f32 %8672, 0
  %8674 = extractvalue %dx.types.ResRet.f32 %8672, 1
  %8675 = extractvalue %dx.types.ResRet.f32 %8672, 2
  %8676 = extractvalue %dx.types.ResRet.f32 %8672, 3
  %8677 = fcmp fast olt float %8676, 0.000000e+00
  br i1 %8677, label %8678, label %8713

; <label>:8678                                    ; preds = %8667
  %8679 = fcmp fast ogt float %8673, 0x3FA4B5DCC0000000
  %8680 = fcmp fast ogt float %8674, 0x3FA4B5DCC0000000
  %8681 = fcmp fast ogt float %8675, 0x3FA4B5DCC0000000
  %8682 = select i1 %8679, float 0.000000e+00, float 1.000000e+00
  %8683 = select i1 %8680, float 0.000000e+00, float 1.000000e+00
  %8684 = select i1 %8681, float 0.000000e+00, float 1.000000e+00
  %8685 = fmul fast float %8673, 0x3FB3D07220000000
  %8686 = fmul fast float %8674, 0x3FB3D07220000000
  %8687 = fmul fast float %8675, 0x3FB3D07220000000
  %8688 = fadd fast float %8673, 0x3FAC28F5C0000000
  %8689 = fadd fast float %8674, 0x3FAC28F5C0000000
  %8690 = fadd fast float %8675, 0x3FAC28F5C0000000
  %8691 = fmul fast float %8688, 0x3FEE54EDE0000000
  %8692 = fmul fast float %8689, 0x3FEE54EDE0000000
  %8693 = fmul fast float %8690, 0x3FEE54EDE0000000
  %8694 = call float @dx.op.unary.f32(i32 23, float %8691)  ; Log(value)
  %8695 = call float @dx.op.unary.f32(i32 23, float %8692)  ; Log(value)
  %8696 = call float @dx.op.unary.f32(i32 23, float %8693)  ; Log(value)
  %8697 = fmul fast float %8694, 0x4003333340000000
  %8698 = fmul fast float %8695, 0x4003333340000000
  %8699 = fmul fast float %8696, 0x4003333340000000
  %8700 = call float @dx.op.unary.f32(i32 21, float %8697)  ; Exp(value)
  %8701 = call float @dx.op.unary.f32(i32 21, float %8698)  ; Exp(value)
  %8702 = call float @dx.op.unary.f32(i32 21, float %8699)  ; Exp(value)
  %8703 = fsub fast float %8685, %8700
  %8704 = fsub fast float %8686, %8701
  %8705 = fsub fast float %8687, %8702
  %8706 = fmul fast float %8703, %8682
  %8707 = fmul fast float %8704, %8683
  %8708 = fmul fast float %8705, %8684
  %8709 = fadd fast float %8706, %8700
  %8710 = fadd fast float %8707, %8701
  %8711 = fadd fast float %8708, %8702
  %8712 = fsub fast float -1.000000e+00, %8676
  br label %10186

; <label>:8713                                    ; preds = %8667
  %8714 = fcmp fast ogt float %39, 5.000000e-01
  %8715 = fcmp fast olt float %89, 1.000000e+00
  %8716 = and i1 %8714, %8715
  br i1 %8716, label %8717, label %8855

; <label>:8717                                    ; preds = %8713
  %8718 = sitofp i32 %68 to float
  %8719 = sitofp i32 %71 to float
  %8720 = fadd fast float %8718, 5.000000e-01
  %8721 = fadd fast float %8719, 5.000000e-01
  %8722 = fdiv fast float %8720, %46
  %8723 = fdiv fast float %8721, %47
  %8724 = fmul fast float %8722, 2.000000e+00
  %8725 = fmul fast float %8723, 2.000000e+00
  %8726 = fadd fast float %8724, -1.000000e+00
  %8727 = fsub fast float 1.000000e+00, %8725
  %8728 = fmul fast float %8726, %36
  %8729 = call float @dx.op.tertiary.f32(i32 46, float %8727, float %32, float %8728)  ; FMad(a,b,c)
  %8730 = call float @dx.op.tertiary.f32(i32 46, float %89, float %28, float %8729)  ; FMad(a,b,c)
  %8731 = fadd fast float %8730, %24
  %8732 = call float @dx.op.unary.f32(i32 6, float %8731)  ; FAbs(value)
  %8733 = fcmp fast ogt float %8732, 0x3EB0C6F7A0000000
  br i1 %8733, label %8734, label %8855

; <label>:8734                                    ; preds = %8717
  %8735 = fmul fast float %8726, %35
  %8736 = call float @dx.op.tertiary.f32(i32 46, float %8727, float %31, float %8735)  ; FMad(a,b,c)
  %8737 = call float @dx.op.tertiary.f32(i32 46, float %89, float %27, float %8736)  ; FMad(a,b,c)
  %8738 = fadd fast float %8737, %23
  %8739 = fmul fast float %8726, %34
  %8740 = call float @dx.op.tertiary.f32(i32 46, float %8727, float %30, float %8739)  ; FMad(a,b,c)
  %8741 = call float @dx.op.tertiary.f32(i32 46, float %89, float %26, float %8740)  ; FMad(a,b,c)
  %8742 = fadd fast float %8741, %22
  %8743 = fmul fast float %8726, %33
  %8744 = call float @dx.op.tertiary.f32(i32 46, float %8727, float %29, float %8743)  ; FMad(a,b,c)
  %8745 = call float @dx.op.tertiary.f32(i32 46, float %89, float %25, float %8744)  ; FMad(a,b,c)
  %8746 = fadd fast float %8745, %21
  %8747 = fdiv fast float %8746, %8731
  %8748 = fdiv fast float %8742, %8731
  %8749 = fdiv fast float %8738, %8731
  %8750 = fsub fast float %8747, %18
  %8751 = fsub fast float %8748, %19
  %8752 = fsub fast float %8749, %20
  %8753 = fmul fast float %8750, %8750
  %8754 = fmul fast float %8751, %8751
  %8755 = fadd fast float %8754, %8753
  %8756 = fmul fast float %8752, %8752
  %8757 = fadd fast float %8755, %8756
  %8758 = call float @dx.op.unary.f32(i32 24, float %8757)  ; Sqrt(value)
  %8759 = fsub fast float %8758, %10
  %8760 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %8759)  ; FMax(a,b)
  %8761 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %8761, label %8762, label %8785

; <label>:8762                                    ; preds = %8734
  %8763 = call float @dx.op.unary.f32(i32 6, float %8751)  ; FAbs(value)
  %8764 = fmul fast float %8763, %12
  %8765 = fcmp fast olt float %8764, 0x3F50624DE0000000
  br i1 %8765, label %8766, label %8769

; <label>:8766                                    ; preds = %8762
  %8767 = fmul fast float %8764, 5.000000e-01
  %8768 = fsub fast float 1.000000e+00, %8767
  br label %8774

; <label>:8769                                    ; preds = %8762
  %8770 = fmul fast float %8764, 0xBFF7154760000000
  %8771 = call float @dx.op.unary.f32(i32 21, float %8770)  ; Exp(value)
  %8772 = fsub fast float 1.000000e+00, %8771
  %8773 = fdiv fast float %8772, %8764
  br label %8774

; <label>:8774                                    ; preds = %8769, %8766
  %8775 = phi float [ %8768, %8766 ], [ %8773, %8769 ]
  %8776 = call float @dx.op.binary.f32(i32 36, float %8748, float %19)  ; FMin(a,b)
  %8777 = fsub fast float %8776, %11
  %8778 = fmul fast float %12, %8777
  %8779 = fsub fast float -0.000000e+00, %8778
  %8780 = call float @dx.op.binary.f32(i32 35, float %8779, float -4.000000e+01)  ; FMax(a,b)
  %8781 = call float @dx.op.binary.f32(i32 36, float %8780, float 5.000000e+00)  ; FMin(a,b)
  %8782 = fmul fast float %8781, 0x3FF7154760000000
  %8783 = call float @dx.op.unary.f32(i32 21, float %8782)  ; Exp(value)
  %8784 = fmul fast float %8783, %8775
  br label %8785

; <label>:8785                                    ; preds = %8774, %8734
  %8786 = phi float [ %8784, %8774 ], [ 1.000000e+00, %8734 ]
  %8787 = fmul fast float %8760, %17
  %8788 = fmul fast float %8787, %8786
  %8789 = fcmp fast ole float %8758, %10
  %8790 = fcmp fast olt float %8758, 0x3F1A36E2E0000000
  %8791 = or i1 %8789, %8790
  br i1 %8791, label %8838, label %8792

; <label>:8792                                    ; preds = %8785
  %8793 = fdiv fast float %10, %8758
  %8794 = fmul fast float %8793, %8750
  %8795 = fmul fast float %8793, %8751
  %8796 = fmul fast float %8793, %8752
  %8797 = fadd fast float %8794, %18
  %8798 = fadd fast float %8795, %19
  %8799 = fadd fast float %8796, %20
  %8800 = fadd fast float %8797, -9.000000e+02
  %8801 = fadd fast float %8798, -1.500000e+01
  %8802 = fadd fast float %8799, -7.500000e+02
  %8803 = fmul fast float %8800, 0x3F62345680000000
  %8804 = fmul fast float %8801, 0x3F62345680000000
  %8805 = fmul fast float %8802, 0x3F62345680000000
  %8806 = call float @dx.op.dot3.f32(i32 55, float %8803, float %8804, float %8805, float %8803, float %8804, float %8805)  ; Dot3(ax,ay,az,bx,by,bz)
  %8807 = fsub fast float 1.000000e+00, %8806
  %8808 = call float @dx.op.unary.f32(i32 7, float %8807)  ; Saturate(value)
  %8809 = fmul fast float %8808, %8808
  %8810 = fadd fast float %8797, %8747
  %8811 = fadd fast float %8798, %8748
  %8812 = fadd fast float %8799, %8749
  %8813 = fmul fast float %8810, 0x3F52345680000000
  %8814 = fadd fast float %8813, -2.000000e+00
  %8815 = fmul fast float %8811, 0x3F52345680000000
  %8816 = fadd fast float %8815, 0xBFA1111120000000
  %8817 = fmul fast float %8812, 0x3F52345680000000
  %8818 = fadd fast float %8817, 0xBFFAAAAAC0000000
  %8819 = call float @dx.op.dot3.f32(i32 55, float %8814, float %8816, float %8818, float %8814, float %8816, float %8818)  ; Dot3(ax,ay,az,bx,by,bz)
  %8820 = fsub fast float 1.000000e+00, %8819
  %8821 = call float @dx.op.unary.f32(i32 7, float %8820)  ; Saturate(value)
  %8822 = fmul fast float %8821, %8821
  %8823 = fmul fast float %8822, 4.000000e+00
  %8824 = fadd fast float %8823, %8809
  %8825 = fadd fast float %8747, -9.000000e+02
  %8826 = fadd fast float %8748, -1.500000e+01
  %8827 = fadd fast float %8749, -7.500000e+02
  %8828 = fmul fast float %8825, 0x3F62345680000000
  %8829 = fmul fast float %8826, 0x3F62345680000000
  %8830 = fmul fast float %8827, 0x3F62345680000000
  %8831 = call float @dx.op.dot3.f32(i32 55, float %8828, float %8829, float %8830, float %8828, float %8829, float %8830)  ; Dot3(ax,ay,az,bx,by,bz)
  %8832 = fsub fast float 1.000000e+00, %8831
  %8833 = call float @dx.op.unary.f32(i32 7, float %8832)  ; Saturate(value)
  %8834 = fmul fast float %8833, %8833
  %8835 = fadd fast float %8824, %8834
  %8836 = fmul fast float %8759, 0x3F25D867E0000000
  %8837 = fmul fast float %8836, %8835
  br label %8838

; <label>:8838                                    ; preds = %8792, %8785
  %8839 = phi float [ %8837, %8792 ], [ 0.000000e+00, %8785 ]
  %8840 = fadd fast float %8839, %8788
  %8841 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %8840)  ; FMin(a,b)
  %8842 = fmul fast float %8841, 0xBFF7154760000000
  %8843 = call float @dx.op.unary.f32(i32 21, float %8842)  ; Exp(value)
  %8844 = fsub fast float 1.000000e+00, %8843
  %8845 = call float @dx.op.binary.f32(i32 36, float %13, float %8844)  ; FMin(a,b)
  %8846 = fsub fast float %14, %8673
  %8847 = fsub fast float %15, %8674
  %8848 = fsub fast float %16, %8675
  %8849 = fmul fast float %8845, %8846
  %8850 = fmul fast float %8845, %8847
  %8851 = fmul fast float %8845, %8848
  %8852 = fadd fast float %8849, %8673
  %8853 = fadd fast float %8850, %8674
  %8854 = fadd fast float %8851, %8675
  br label %8855

; <label>:8855                                    ; preds = %8838, %8717, %8713
  %8856 = phi float [ %8852, %8838 ], [ %8673, %8717 ], [ %8673, %8713 ]
  %8857 = phi float [ %8853, %8838 ], [ %8674, %8717 ], [ %8674, %8713 ]
  %8858 = phi float [ %8854, %8838 ], [ %8675, %8717 ], [ %8675, %8713 ]
  %8859 = fadd fast float %6, 1.000000e+00
  %8860 = fadd fast float %7, 1.000000e+00
  %8861 = fsub fast float 1.000000e+00, %6
  %8862 = fmul fast float %37, %8859
  %8863 = fmul fast float %37, %8860
  %8864 = fmul fast float %37, %8861
  %8865 = fmul fast float %8862, %8856
  %8866 = fmul fast float %8863, %8857
  %8867 = fmul fast float %8864, %8858
  %8868 = fcmp fast ult float %38, 5.000000e-01
  br i1 %8868, label %8894, label %8869

; <label>:8869                                    ; preds = %8855
  %8870 = fmul fast float %8865, 0x4004147AE0000000
  %8871 = fmul fast float %8866, 0x4004147AE0000000
  %8872 = fmul fast float %8867, 0x4004147AE0000000
  %8873 = fadd fast float %8870, 0x3F9EB851E0000000
  %8874 = fadd fast float %8871, 0x3F9EB851E0000000
  %8875 = fadd fast float %8872, 0x3F9EB851E0000000
  %8876 = fmul fast float %8873, %8865
  %8877 = fmul fast float %8874, %8866
  %8878 = fmul fast float %8875, %8867
  %8879 = fmul fast float %8865, 0x400370A3E0000000
  %8880 = fmul fast float %8866, 0x400370A3E0000000
  %8881 = fmul fast float %8867, 0x400370A3E0000000
  %8882 = fadd fast float %8879, 0x3FE2E147A0000000
  %8883 = fadd fast float %8880, 0x3FE2E147A0000000
  %8884 = fadd fast float %8881, 0x3FE2E147A0000000
  %8885 = fmul fast float %8882, %8865
  %8886 = fmul fast float %8883, %8866
  %8887 = fmul fast float %8884, %8867
  %8888 = fadd fast float %8885, 0x3FC1EB8520000000
  %8889 = fadd fast float %8886, 0x3FC1EB8520000000
  %8890 = fadd fast float %8887, 0x3FC1EB8520000000
  %8891 = fdiv fast float %8876, %8888
  %8892 = fdiv fast float %8877, %8889
  %8893 = fdiv fast float %8878, %8890
  br label %8894

; <label>:8894                                    ; preds = %8869, %8855
  %8895 = phi float [ %8891, %8869 ], [ %8865, %8855 ]
  %8896 = phi float [ %8892, %8869 ], [ %8866, %8855 ]
  %8897 = phi float [ %8893, %8869 ], [ %8867, %8855 ]
  %8898 = call float @dx.op.unary.f32(i32 7, float %8895)  ; Saturate(value)
  %8899 = call float @dx.op.unary.f32(i32 7, float %8896)  ; Saturate(value)
  %8900 = call float @dx.op.unary.f32(i32 7, float %8897)  ; Saturate(value)
  %8901 = call float @dx.op.dot3.f32(i32 55, float %8898, float %8899, float %8900, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %8902 = fsub fast float %8898, %8901
  %8903 = fsub fast float %8899, %8901
  %8904 = fsub fast float %8900, %8901
  %8905 = fmul fast float %8902, %9
  %8906 = fmul fast float %8903, %9
  %8907 = fmul fast float %8904, %9
  %8908 = fadd fast float %8905, %8901
  %8909 = fadd fast float %8906, %8901
  %8910 = fadd fast float %8907, %8901
  %8911 = call float @dx.op.unary.f32(i32 7, float %8908)  ; Saturate(value)
  %8912 = call float @dx.op.unary.f32(i32 7, float %8909)  ; Saturate(value)
  %8913 = call float @dx.op.unary.f32(i32 7, float %8910)  ; Saturate(value)
  %8914 = fadd fast float %8911, 0xBFC70A3D80000000
  %8915 = fadd fast float %8912, 0xBFC70A3D80000000
  %8916 = fadd fast float %8913, 0xBFC70A3D80000000
  %8917 = fmul fast float %8914, %8
  %8918 = fmul fast float %8915, %8
  %8919 = fmul fast float %8916, %8
  %8920 = fadd fast float %8917, 0x3FC70A3D80000000
  %8921 = fadd fast float %8918, 0x3FC70A3D80000000
  %8922 = fadd fast float %8919, 0x3FC70A3D80000000
  %8923 = call float @dx.op.unary.f32(i32 7, float %8920)  ; Saturate(value)
  %8924 = call float @dx.op.unary.f32(i32 7, float %8921)  ; Saturate(value)
  %8925 = call float @dx.op.unary.f32(i32 7, float %8922)  ; Saturate(value)
  %8926 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %8926, label %8927, label %10186

; <label>:8927                                    ; preds = %8894
  %8928 = add i32 %71, -1
  %8929 = call i32 @dx.op.binary.i32(i32 37, i32 %68, i32 0)  ; IMax(a,b)
  %8930 = call i32 @dx.op.binary.i32(i32 37, i32 %8928, i32 0)  ; IMax(a,b)
  %8931 = call i32 @dx.op.binary.i32(i32 38, i32 %8929, i32 %60)  ; IMin(a,b)
  %8932 = call i32 @dx.op.binary.i32(i32 38, i32 %8930, i32 %61)  ; IMin(a,b)
  %8933 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %8931, i32 %8932, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %8934 = extractvalue %dx.types.ResRet.f32 %8933, 0
  %8935 = fsub fast float 1.000000e+00, %89
  %8936 = fmul fast float %8935, 0x3FA99999A0000000
  %8937 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %8936)  ; FMax(a,b)
  %8938 = fsub fast float %8934, %89
  %8939 = call float @dx.op.unary.f32(i32 6, float %8938)  ; FAbs(value)
  %8940 = fdiv fast float %8939, %8937
  %8941 = fsub fast float 1.000000e+00, %8940
  %8942 = call float @dx.op.unary.f32(i32 7, float %8941)  ; Saturate(value)
  %8943 = fcmp fast ugt float %8942, 0.000000e+00
  br i1 %8943, label %8944, label %9217

; <label>:8944                                    ; preds = %8927
  %8945 = call i32 @dx.op.binary.i32(i32 37, i32 %8931, i32 0)  ; IMax(a,b)
  %8946 = call i32 @dx.op.binary.i32(i32 37, i32 %8932, i32 0)  ; IMax(a,b)
  %8947 = call i32 @dx.op.binary.i32(i32 38, i32 %8945, i32 %60)  ; IMin(a,b)
  %8948 = call i32 @dx.op.binary.i32(i32 38, i32 %8946, i32 %61)  ; IMin(a,b)
  %8949 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %8947, i32 %8948, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %8950 = extractvalue %dx.types.ResRet.f32 %8949, 0
  %8951 = extractvalue %dx.types.ResRet.f32 %8949, 1
  %8952 = extractvalue %dx.types.ResRet.f32 %8949, 2
  %8953 = extractvalue %dx.types.ResRet.f32 %8949, 3
  %8954 = fcmp fast olt float %8953, 0.000000e+00
  br i1 %8954, label %8955, label %8989

; <label>:8955                                    ; preds = %8944
  %8956 = fcmp fast ogt float %8950, 0x3FA4B5DCC0000000
  %8957 = fcmp fast ogt float %8951, 0x3FA4B5DCC0000000
  %8958 = fcmp fast ogt float %8952, 0x3FA4B5DCC0000000
  %8959 = select i1 %8956, float 0.000000e+00, float 1.000000e+00
  %8960 = select i1 %8957, float 0.000000e+00, float 1.000000e+00
  %8961 = select i1 %8958, float 0.000000e+00, float 1.000000e+00
  %8962 = fmul fast float %8950, 0x3FB3D07220000000
  %8963 = fmul fast float %8951, 0x3FB3D07220000000
  %8964 = fmul fast float %8952, 0x3FB3D07220000000
  %8965 = fadd fast float %8950, 0x3FAC28F5C0000000
  %8966 = fadd fast float %8951, 0x3FAC28F5C0000000
  %8967 = fadd fast float %8952, 0x3FAC28F5C0000000
  %8968 = fmul fast float %8965, 0x3FEE54EDE0000000
  %8969 = fmul fast float %8966, 0x3FEE54EDE0000000
  %8970 = fmul fast float %8967, 0x3FEE54EDE0000000
  %8971 = call float @dx.op.unary.f32(i32 23, float %8968)  ; Log(value)
  %8972 = call float @dx.op.unary.f32(i32 23, float %8969)  ; Log(value)
  %8973 = call float @dx.op.unary.f32(i32 23, float %8970)  ; Log(value)
  %8974 = fmul fast float %8971, 0x4003333340000000
  %8975 = fmul fast float %8972, 0x4003333340000000
  %8976 = fmul fast float %8973, 0x4003333340000000
  %8977 = call float @dx.op.unary.f32(i32 21, float %8974)  ; Exp(value)
  %8978 = call float @dx.op.unary.f32(i32 21, float %8975)  ; Exp(value)
  %8979 = call float @dx.op.unary.f32(i32 21, float %8976)  ; Exp(value)
  %8980 = fsub fast float %8962, %8977
  %8981 = fsub fast float %8963, %8978
  %8982 = fsub fast float %8964, %8979
  %8983 = fmul fast float %8980, %8959
  %8984 = fmul fast float %8981, %8960
  %8985 = fmul fast float %8982, %8961
  %8986 = fadd fast float %8983, %8977
  %8987 = fadd fast float %8984, %8978
  %8988 = fadd fast float %8985, %8979
  br label %9204

; <label>:8989                                    ; preds = %8944
  %8990 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %8947, i32 %8948, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %8991 = extractvalue %dx.types.ResRet.f32 %8990, 0
  %8992 = fcmp fast ogt float %39, 5.000000e-01
  %8993 = fcmp fast olt float %8991, 1.000000e+00
  %8994 = and i1 %8992, %8993
  br i1 %8994, label %8995, label %9133

; <label>:8995                                    ; preds = %8989
  %8996 = sitofp i32 %8947 to float
  %8997 = sitofp i32 %8948 to float
  %8998 = fadd fast float %8996, 5.000000e-01
  %8999 = fadd fast float %8997, 5.000000e-01
  %9000 = fdiv fast float %8998, %46
  %9001 = fdiv fast float %8999, %47
  %9002 = fmul fast float %9000, 2.000000e+00
  %9003 = fmul fast float %9001, 2.000000e+00
  %9004 = fadd fast float %9002, -1.000000e+00
  %9005 = fsub fast float 1.000000e+00, %9003
  %9006 = fmul fast float %9004, %36
  %9007 = call float @dx.op.tertiary.f32(i32 46, float %9005, float %32, float %9006)  ; FMad(a,b,c)
  %9008 = call float @dx.op.tertiary.f32(i32 46, float %8991, float %28, float %9007)  ; FMad(a,b,c)
  %9009 = fadd fast float %9008, %24
  %9010 = call float @dx.op.unary.f32(i32 6, float %9009)  ; FAbs(value)
  %9011 = fcmp fast ogt float %9010, 0x3EB0C6F7A0000000
  br i1 %9011, label %9012, label %9133

; <label>:9012                                    ; preds = %8995
  %9013 = fmul fast float %9004, %35
  %9014 = call float @dx.op.tertiary.f32(i32 46, float %9005, float %31, float %9013)  ; FMad(a,b,c)
  %9015 = call float @dx.op.tertiary.f32(i32 46, float %8991, float %27, float %9014)  ; FMad(a,b,c)
  %9016 = fadd fast float %9015, %23
  %9017 = fmul fast float %9004, %34
  %9018 = call float @dx.op.tertiary.f32(i32 46, float %9005, float %30, float %9017)  ; FMad(a,b,c)
  %9019 = call float @dx.op.tertiary.f32(i32 46, float %8991, float %26, float %9018)  ; FMad(a,b,c)
  %9020 = fadd fast float %9019, %22
  %9021 = fmul fast float %9004, %33
  %9022 = call float @dx.op.tertiary.f32(i32 46, float %9005, float %29, float %9021)  ; FMad(a,b,c)
  %9023 = call float @dx.op.tertiary.f32(i32 46, float %8991, float %25, float %9022)  ; FMad(a,b,c)
  %9024 = fadd fast float %9023, %21
  %9025 = fdiv fast float %9024, %9009
  %9026 = fdiv fast float %9020, %9009
  %9027 = fdiv fast float %9016, %9009
  %9028 = fsub fast float %9025, %18
  %9029 = fsub fast float %9026, %19
  %9030 = fsub fast float %9027, %20
  %9031 = fmul fast float %9028, %9028
  %9032 = fmul fast float %9029, %9029
  %9033 = fadd fast float %9032, %9031
  %9034 = fmul fast float %9030, %9030
  %9035 = fadd fast float %9033, %9034
  %9036 = call float @dx.op.unary.f32(i32 24, float %9035)  ; Sqrt(value)
  %9037 = fsub fast float %9036, %10
  %9038 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %9037)  ; FMax(a,b)
  %9039 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %9039, label %9040, label %9063

; <label>:9040                                    ; preds = %9012
  %9041 = call float @dx.op.unary.f32(i32 6, float %9029)  ; FAbs(value)
  %9042 = fmul fast float %9041, %12
  %9043 = fcmp fast olt float %9042, 0x3F50624DE0000000
  br i1 %9043, label %9044, label %9047

; <label>:9044                                    ; preds = %9040
  %9045 = fmul fast float %9042, 5.000000e-01
  %9046 = fsub fast float 1.000000e+00, %9045
  br label %9052

; <label>:9047                                    ; preds = %9040
  %9048 = fmul fast float %9042, 0xBFF7154760000000
  %9049 = call float @dx.op.unary.f32(i32 21, float %9048)  ; Exp(value)
  %9050 = fsub fast float 1.000000e+00, %9049
  %9051 = fdiv fast float %9050, %9042
  br label %9052

; <label>:9052                                    ; preds = %9047, %9044
  %9053 = phi float [ %9046, %9044 ], [ %9051, %9047 ]
  %9054 = call float @dx.op.binary.f32(i32 36, float %9026, float %19)  ; FMin(a,b)
  %9055 = fsub fast float %9054, %11
  %9056 = fmul fast float %12, %9055
  %9057 = fsub fast float -0.000000e+00, %9056
  %9058 = call float @dx.op.binary.f32(i32 35, float %9057, float -4.000000e+01)  ; FMax(a,b)
  %9059 = call float @dx.op.binary.f32(i32 36, float %9058, float 5.000000e+00)  ; FMin(a,b)
  %9060 = fmul fast float %9059, 0x3FF7154760000000
  %9061 = call float @dx.op.unary.f32(i32 21, float %9060)  ; Exp(value)
  %9062 = fmul fast float %9061, %9053
  br label %9063

; <label>:9063                                    ; preds = %9052, %9012
  %9064 = phi float [ %9062, %9052 ], [ 1.000000e+00, %9012 ]
  %9065 = fmul fast float %9038, %17
  %9066 = fmul fast float %9065, %9064
  %9067 = fcmp fast ole float %9036, %10
  %9068 = fcmp fast olt float %9036, 0x3F1A36E2E0000000
  %9069 = or i1 %9067, %9068
  br i1 %9069, label %9116, label %9070

; <label>:9070                                    ; preds = %9063
  %9071 = fdiv fast float %10, %9036
  %9072 = fmul fast float %9071, %9028
  %9073 = fmul fast float %9071, %9029
  %9074 = fmul fast float %9071, %9030
  %9075 = fadd fast float %9072, %18
  %9076 = fadd fast float %9073, %19
  %9077 = fadd fast float %9074, %20
  %9078 = fadd fast float %9075, -9.000000e+02
  %9079 = fadd fast float %9076, -1.500000e+01
  %9080 = fadd fast float %9077, -7.500000e+02
  %9081 = fmul fast float %9078, 0x3F62345680000000
  %9082 = fmul fast float %9079, 0x3F62345680000000
  %9083 = fmul fast float %9080, 0x3F62345680000000
  %9084 = call float @dx.op.dot3.f32(i32 55, float %9081, float %9082, float %9083, float %9081, float %9082, float %9083)  ; Dot3(ax,ay,az,bx,by,bz)
  %9085 = fsub fast float 1.000000e+00, %9084
  %9086 = call float @dx.op.unary.f32(i32 7, float %9085)  ; Saturate(value)
  %9087 = fmul fast float %9086, %9086
  %9088 = fadd fast float %9075, %9025
  %9089 = fadd fast float %9076, %9026
  %9090 = fadd fast float %9077, %9027
  %9091 = fmul fast float %9088, 0x3F52345680000000
  %9092 = fadd fast float %9091, -2.000000e+00
  %9093 = fmul fast float %9089, 0x3F52345680000000
  %9094 = fadd fast float %9093, 0xBFA1111120000000
  %9095 = fmul fast float %9090, 0x3F52345680000000
  %9096 = fadd fast float %9095, 0xBFFAAAAAC0000000
  %9097 = call float @dx.op.dot3.f32(i32 55, float %9092, float %9094, float %9096, float %9092, float %9094, float %9096)  ; Dot3(ax,ay,az,bx,by,bz)
  %9098 = fsub fast float 1.000000e+00, %9097
  %9099 = call float @dx.op.unary.f32(i32 7, float %9098)  ; Saturate(value)
  %9100 = fmul fast float %9099, %9099
  %9101 = fmul fast float %9100, 4.000000e+00
  %9102 = fadd fast float %9101, %9087
  %9103 = fadd fast float %9025, -9.000000e+02
  %9104 = fadd fast float %9026, -1.500000e+01
  %9105 = fadd fast float %9027, -7.500000e+02
  %9106 = fmul fast float %9103, 0x3F62345680000000
  %9107 = fmul fast float %9104, 0x3F62345680000000
  %9108 = fmul fast float %9105, 0x3F62345680000000
  %9109 = call float @dx.op.dot3.f32(i32 55, float %9106, float %9107, float %9108, float %9106, float %9107, float %9108)  ; Dot3(ax,ay,az,bx,by,bz)
  %9110 = fsub fast float 1.000000e+00, %9109
  %9111 = call float @dx.op.unary.f32(i32 7, float %9110)  ; Saturate(value)
  %9112 = fmul fast float %9111, %9111
  %9113 = fadd fast float %9102, %9112
  %9114 = fmul fast float %9037, 0x3F25D867E0000000
  %9115 = fmul fast float %9114, %9113
  br label %9116

; <label>:9116                                    ; preds = %9070, %9063
  %9117 = phi float [ %9115, %9070 ], [ 0.000000e+00, %9063 ]
  %9118 = fadd fast float %9117, %9066
  %9119 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %9118)  ; FMin(a,b)
  %9120 = fmul fast float %9119, 0xBFF7154760000000
  %9121 = call float @dx.op.unary.f32(i32 21, float %9120)  ; Exp(value)
  %9122 = fsub fast float 1.000000e+00, %9121
  %9123 = call float @dx.op.binary.f32(i32 36, float %13, float %9122)  ; FMin(a,b)
  %9124 = fsub fast float %14, %8950
  %9125 = fsub fast float %15, %8951
  %9126 = fsub fast float %16, %8952
  %9127 = fmul fast float %9123, %9124
  %9128 = fmul fast float %9123, %9125
  %9129 = fmul fast float %9123, %9126
  %9130 = fadd fast float %9127, %8950
  %9131 = fadd fast float %9128, %8951
  %9132 = fadd fast float %9129, %8952
  br label %9133

; <label>:9133                                    ; preds = %9116, %8995, %8989
  %9134 = phi float [ %9130, %9116 ], [ %8950, %8995 ], [ %8950, %8989 ]
  %9135 = phi float [ %9131, %9116 ], [ %8951, %8995 ], [ %8951, %8989 ]
  %9136 = phi float [ %9132, %9116 ], [ %8952, %8995 ], [ %8952, %8989 ]
  %9137 = fadd fast float %6, 1.000000e+00
  %9138 = fadd fast float %7, 1.000000e+00
  %9139 = fsub fast float 1.000000e+00, %6
  %9140 = fmul fast float %37, %9137
  %9141 = fmul fast float %37, %9138
  %9142 = fmul fast float %37, %9139
  %9143 = fmul fast float %9140, %9134
  %9144 = fmul fast float %9141, %9135
  %9145 = fmul fast float %9142, %9136
  %9146 = fcmp fast ult float %38, 5.000000e-01
  br i1 %9146, label %9172, label %9147

; <label>:9147                                    ; preds = %9133
  %9148 = fmul fast float %9143, 0x4004147AE0000000
  %9149 = fmul fast float %9144, 0x4004147AE0000000
  %9150 = fmul fast float %9145, 0x4004147AE0000000
  %9151 = fadd fast float %9148, 0x3F9EB851E0000000
  %9152 = fadd fast float %9149, 0x3F9EB851E0000000
  %9153 = fadd fast float %9150, 0x3F9EB851E0000000
  %9154 = fmul fast float %9151, %9143
  %9155 = fmul fast float %9152, %9144
  %9156 = fmul fast float %9153, %9145
  %9157 = fmul fast float %9143, 0x400370A3E0000000
  %9158 = fmul fast float %9144, 0x400370A3E0000000
  %9159 = fmul fast float %9145, 0x400370A3E0000000
  %9160 = fadd fast float %9157, 0x3FE2E147A0000000
  %9161 = fadd fast float %9158, 0x3FE2E147A0000000
  %9162 = fadd fast float %9159, 0x3FE2E147A0000000
  %9163 = fmul fast float %9160, %9143
  %9164 = fmul fast float %9161, %9144
  %9165 = fmul fast float %9162, %9145
  %9166 = fadd fast float %9163, 0x3FC1EB8520000000
  %9167 = fadd fast float %9164, 0x3FC1EB8520000000
  %9168 = fadd fast float %9165, 0x3FC1EB8520000000
  %9169 = fdiv fast float %9154, %9166
  %9170 = fdiv fast float %9155, %9167
  %9171 = fdiv fast float %9156, %9168
  br label %9172

; <label>:9172                                    ; preds = %9147, %9133
  %9173 = phi float [ %9169, %9147 ], [ %9143, %9133 ]
  %9174 = phi float [ %9170, %9147 ], [ %9144, %9133 ]
  %9175 = phi float [ %9171, %9147 ], [ %9145, %9133 ]
  %9176 = call float @dx.op.unary.f32(i32 7, float %9173)  ; Saturate(value)
  %9177 = call float @dx.op.unary.f32(i32 7, float %9174)  ; Saturate(value)
  %9178 = call float @dx.op.unary.f32(i32 7, float %9175)  ; Saturate(value)
  %9179 = call float @dx.op.dot3.f32(i32 55, float %9176, float %9177, float %9178, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %9180 = fsub fast float %9176, %9179
  %9181 = fsub fast float %9177, %9179
  %9182 = fsub fast float %9178, %9179
  %9183 = fmul fast float %9180, %9
  %9184 = fmul fast float %9181, %9
  %9185 = fmul fast float %9182, %9
  %9186 = fadd fast float %9183, %9179
  %9187 = fadd fast float %9184, %9179
  %9188 = fadd fast float %9185, %9179
  %9189 = call float @dx.op.unary.f32(i32 7, float %9186)  ; Saturate(value)
  %9190 = call float @dx.op.unary.f32(i32 7, float %9187)  ; Saturate(value)
  %9191 = call float @dx.op.unary.f32(i32 7, float %9188)  ; Saturate(value)
  %9192 = fadd fast float %9189, 0xBFC70A3D80000000
  %9193 = fadd fast float %9190, 0xBFC70A3D80000000
  %9194 = fadd fast float %9191, 0xBFC70A3D80000000
  %9195 = fmul fast float %9192, %8
  %9196 = fmul fast float %9193, %8
  %9197 = fmul fast float %9194, %8
  %9198 = fadd fast float %9195, 0x3FC70A3D80000000
  %9199 = fadd fast float %9196, 0x3FC70A3D80000000
  %9200 = fadd fast float %9197, 0x3FC70A3D80000000
  %9201 = call float @dx.op.unary.f32(i32 7, float %9198)  ; Saturate(value)
  %9202 = call float @dx.op.unary.f32(i32 7, float %9199)  ; Saturate(value)
  %9203 = call float @dx.op.unary.f32(i32 7, float %9200)  ; Saturate(value)
  br label %9204

; <label>:9204                                    ; preds = %9172, %8955
  %9205 = phi float [ %8986, %8955 ], [ %9201, %9172 ]
  %9206 = phi float [ %8987, %8955 ], [ %9202, %9172 ]
  %9207 = phi float [ %8988, %8955 ], [ %9203, %9172 ]
  %9208 = fsub fast float %9205, %8923
  %9209 = fsub fast float %9206, %8924
  %9210 = fsub fast float %9207, %8925
  %9211 = fmul fast float %9208, %8942
  %9212 = fmul fast float %9209, %8942
  %9213 = fmul fast float %9210, %8942
  %9214 = fadd fast float %9211, %8923
  %9215 = fadd fast float %9212, %8924
  %9216 = fadd fast float %9213, %8925
  br label %9217

; <label>:9217                                    ; preds = %9204, %8927
  %9218 = phi float [ %9214, %9204 ], [ %8923, %8927 ]
  %9219 = phi float [ %9215, %9204 ], [ %8924, %8927 ]
  %9220 = phi float [ %9216, %9204 ], [ %8925, %8927 ]
  %9221 = add i32 %71, 1
  %9222 = call i32 @dx.op.binary.i32(i32 37, i32 %9221, i32 0)  ; IMax(a,b)
  %9223 = call i32 @dx.op.binary.i32(i32 38, i32 %9222, i32 %61)  ; IMin(a,b)
  %9224 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %8931, i32 %9223, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %9225 = extractvalue %dx.types.ResRet.f32 %9224, 0
  %9226 = fsub fast float %9225, %89
  %9227 = call float @dx.op.unary.f32(i32 6, float %9226)  ; FAbs(value)
  %9228 = fdiv fast float %9227, %8937
  %9229 = fsub fast float 1.000000e+00, %9228
  %9230 = call float @dx.op.unary.f32(i32 7, float %9229)  ; Saturate(value)
  %9231 = fcmp fast ugt float %9230, 0.000000e+00
  br i1 %9231, label %9232, label %9505

; <label>:9232                                    ; preds = %9217
  %9233 = call i32 @dx.op.binary.i32(i32 37, i32 %8931, i32 0)  ; IMax(a,b)
  %9234 = call i32 @dx.op.binary.i32(i32 37, i32 %9223, i32 0)  ; IMax(a,b)
  %9235 = call i32 @dx.op.binary.i32(i32 38, i32 %9233, i32 %60)  ; IMin(a,b)
  %9236 = call i32 @dx.op.binary.i32(i32 38, i32 %9234, i32 %61)  ; IMin(a,b)
  %9237 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %9235, i32 %9236, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %9238 = extractvalue %dx.types.ResRet.f32 %9237, 0
  %9239 = extractvalue %dx.types.ResRet.f32 %9237, 1
  %9240 = extractvalue %dx.types.ResRet.f32 %9237, 2
  %9241 = extractvalue %dx.types.ResRet.f32 %9237, 3
  %9242 = fcmp fast olt float %9241, 0.000000e+00
  br i1 %9242, label %9243, label %9277

; <label>:9243                                    ; preds = %9232
  %9244 = fcmp fast ogt float %9238, 0x3FA4B5DCC0000000
  %9245 = fcmp fast ogt float %9239, 0x3FA4B5DCC0000000
  %9246 = fcmp fast ogt float %9240, 0x3FA4B5DCC0000000
  %9247 = select i1 %9244, float 0.000000e+00, float 1.000000e+00
  %9248 = select i1 %9245, float 0.000000e+00, float 1.000000e+00
  %9249 = select i1 %9246, float 0.000000e+00, float 1.000000e+00
  %9250 = fmul fast float %9238, 0x3FB3D07220000000
  %9251 = fmul fast float %9239, 0x3FB3D07220000000
  %9252 = fmul fast float %9240, 0x3FB3D07220000000
  %9253 = fadd fast float %9238, 0x3FAC28F5C0000000
  %9254 = fadd fast float %9239, 0x3FAC28F5C0000000
  %9255 = fadd fast float %9240, 0x3FAC28F5C0000000
  %9256 = fmul fast float %9253, 0x3FEE54EDE0000000
  %9257 = fmul fast float %9254, 0x3FEE54EDE0000000
  %9258 = fmul fast float %9255, 0x3FEE54EDE0000000
  %9259 = call float @dx.op.unary.f32(i32 23, float %9256)  ; Log(value)
  %9260 = call float @dx.op.unary.f32(i32 23, float %9257)  ; Log(value)
  %9261 = call float @dx.op.unary.f32(i32 23, float %9258)  ; Log(value)
  %9262 = fmul fast float %9259, 0x4003333340000000
  %9263 = fmul fast float %9260, 0x4003333340000000
  %9264 = fmul fast float %9261, 0x4003333340000000
  %9265 = call float @dx.op.unary.f32(i32 21, float %9262)  ; Exp(value)
  %9266 = call float @dx.op.unary.f32(i32 21, float %9263)  ; Exp(value)
  %9267 = call float @dx.op.unary.f32(i32 21, float %9264)  ; Exp(value)
  %9268 = fsub fast float %9250, %9265
  %9269 = fsub fast float %9251, %9266
  %9270 = fsub fast float %9252, %9267
  %9271 = fmul fast float %9268, %9247
  %9272 = fmul fast float %9269, %9248
  %9273 = fmul fast float %9270, %9249
  %9274 = fadd fast float %9271, %9265
  %9275 = fadd fast float %9272, %9266
  %9276 = fadd fast float %9273, %9267
  br label %9492

; <label>:9277                                    ; preds = %9232
  %9278 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %9235, i32 %9236, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %9279 = extractvalue %dx.types.ResRet.f32 %9278, 0
  %9280 = fcmp fast ogt float %39, 5.000000e-01
  %9281 = fcmp fast olt float %9279, 1.000000e+00
  %9282 = and i1 %9280, %9281
  br i1 %9282, label %9283, label %9421

; <label>:9283                                    ; preds = %9277
  %9284 = sitofp i32 %9235 to float
  %9285 = sitofp i32 %9236 to float
  %9286 = fadd fast float %9284, 5.000000e-01
  %9287 = fadd fast float %9285, 5.000000e-01
  %9288 = fdiv fast float %9286, %46
  %9289 = fdiv fast float %9287, %47
  %9290 = fmul fast float %9288, 2.000000e+00
  %9291 = fmul fast float %9289, 2.000000e+00
  %9292 = fadd fast float %9290, -1.000000e+00
  %9293 = fsub fast float 1.000000e+00, %9291
  %9294 = fmul fast float %9292, %36
  %9295 = call float @dx.op.tertiary.f32(i32 46, float %9293, float %32, float %9294)  ; FMad(a,b,c)
  %9296 = call float @dx.op.tertiary.f32(i32 46, float %9279, float %28, float %9295)  ; FMad(a,b,c)
  %9297 = fadd fast float %9296, %24
  %9298 = call float @dx.op.unary.f32(i32 6, float %9297)  ; FAbs(value)
  %9299 = fcmp fast ogt float %9298, 0x3EB0C6F7A0000000
  br i1 %9299, label %9300, label %9421

; <label>:9300                                    ; preds = %9283
  %9301 = fmul fast float %9292, %35
  %9302 = call float @dx.op.tertiary.f32(i32 46, float %9293, float %31, float %9301)  ; FMad(a,b,c)
  %9303 = call float @dx.op.tertiary.f32(i32 46, float %9279, float %27, float %9302)  ; FMad(a,b,c)
  %9304 = fadd fast float %9303, %23
  %9305 = fmul fast float %9292, %34
  %9306 = call float @dx.op.tertiary.f32(i32 46, float %9293, float %30, float %9305)  ; FMad(a,b,c)
  %9307 = call float @dx.op.tertiary.f32(i32 46, float %9279, float %26, float %9306)  ; FMad(a,b,c)
  %9308 = fadd fast float %9307, %22
  %9309 = fmul fast float %9292, %33
  %9310 = call float @dx.op.tertiary.f32(i32 46, float %9293, float %29, float %9309)  ; FMad(a,b,c)
  %9311 = call float @dx.op.tertiary.f32(i32 46, float %9279, float %25, float %9310)  ; FMad(a,b,c)
  %9312 = fadd fast float %9311, %21
  %9313 = fdiv fast float %9312, %9297
  %9314 = fdiv fast float %9308, %9297
  %9315 = fdiv fast float %9304, %9297
  %9316 = fsub fast float %9313, %18
  %9317 = fsub fast float %9314, %19
  %9318 = fsub fast float %9315, %20
  %9319 = fmul fast float %9316, %9316
  %9320 = fmul fast float %9317, %9317
  %9321 = fadd fast float %9320, %9319
  %9322 = fmul fast float %9318, %9318
  %9323 = fadd fast float %9321, %9322
  %9324 = call float @dx.op.unary.f32(i32 24, float %9323)  ; Sqrt(value)
  %9325 = fsub fast float %9324, %10
  %9326 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %9325)  ; FMax(a,b)
  %9327 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %9327, label %9328, label %9351

; <label>:9328                                    ; preds = %9300
  %9329 = call float @dx.op.unary.f32(i32 6, float %9317)  ; FAbs(value)
  %9330 = fmul fast float %9329, %12
  %9331 = fcmp fast olt float %9330, 0x3F50624DE0000000
  br i1 %9331, label %9332, label %9335

; <label>:9332                                    ; preds = %9328
  %9333 = fmul fast float %9330, 5.000000e-01
  %9334 = fsub fast float 1.000000e+00, %9333
  br label %9340

; <label>:9335                                    ; preds = %9328
  %9336 = fmul fast float %9330, 0xBFF7154760000000
  %9337 = call float @dx.op.unary.f32(i32 21, float %9336)  ; Exp(value)
  %9338 = fsub fast float 1.000000e+00, %9337
  %9339 = fdiv fast float %9338, %9330
  br label %9340

; <label>:9340                                    ; preds = %9335, %9332
  %9341 = phi float [ %9334, %9332 ], [ %9339, %9335 ]
  %9342 = call float @dx.op.binary.f32(i32 36, float %9314, float %19)  ; FMin(a,b)
  %9343 = fsub fast float %9342, %11
  %9344 = fmul fast float %12, %9343
  %9345 = fsub fast float -0.000000e+00, %9344
  %9346 = call float @dx.op.binary.f32(i32 35, float %9345, float -4.000000e+01)  ; FMax(a,b)
  %9347 = call float @dx.op.binary.f32(i32 36, float %9346, float 5.000000e+00)  ; FMin(a,b)
  %9348 = fmul fast float %9347, 0x3FF7154760000000
  %9349 = call float @dx.op.unary.f32(i32 21, float %9348)  ; Exp(value)
  %9350 = fmul fast float %9349, %9341
  br label %9351

; <label>:9351                                    ; preds = %9340, %9300
  %9352 = phi float [ %9350, %9340 ], [ 1.000000e+00, %9300 ]
  %9353 = fmul fast float %9326, %17
  %9354 = fmul fast float %9353, %9352
  %9355 = fcmp fast ole float %9324, %10
  %9356 = fcmp fast olt float %9324, 0x3F1A36E2E0000000
  %9357 = or i1 %9355, %9356
  br i1 %9357, label %9404, label %9358

; <label>:9358                                    ; preds = %9351
  %9359 = fdiv fast float %10, %9324
  %9360 = fmul fast float %9359, %9316
  %9361 = fmul fast float %9359, %9317
  %9362 = fmul fast float %9359, %9318
  %9363 = fadd fast float %9360, %18
  %9364 = fadd fast float %9361, %19
  %9365 = fadd fast float %9362, %20
  %9366 = fadd fast float %9363, -9.000000e+02
  %9367 = fadd fast float %9364, -1.500000e+01
  %9368 = fadd fast float %9365, -7.500000e+02
  %9369 = fmul fast float %9366, 0x3F62345680000000
  %9370 = fmul fast float %9367, 0x3F62345680000000
  %9371 = fmul fast float %9368, 0x3F62345680000000
  %9372 = call float @dx.op.dot3.f32(i32 55, float %9369, float %9370, float %9371, float %9369, float %9370, float %9371)  ; Dot3(ax,ay,az,bx,by,bz)
  %9373 = fsub fast float 1.000000e+00, %9372
  %9374 = call float @dx.op.unary.f32(i32 7, float %9373)  ; Saturate(value)
  %9375 = fmul fast float %9374, %9374
  %9376 = fadd fast float %9363, %9313
  %9377 = fadd fast float %9364, %9314
  %9378 = fadd fast float %9365, %9315
  %9379 = fmul fast float %9376, 0x3F52345680000000
  %9380 = fadd fast float %9379, -2.000000e+00
  %9381 = fmul fast float %9377, 0x3F52345680000000
  %9382 = fadd fast float %9381, 0xBFA1111120000000
  %9383 = fmul fast float %9378, 0x3F52345680000000
  %9384 = fadd fast float %9383, 0xBFFAAAAAC0000000
  %9385 = call float @dx.op.dot3.f32(i32 55, float %9380, float %9382, float %9384, float %9380, float %9382, float %9384)  ; Dot3(ax,ay,az,bx,by,bz)
  %9386 = fsub fast float 1.000000e+00, %9385
  %9387 = call float @dx.op.unary.f32(i32 7, float %9386)  ; Saturate(value)
  %9388 = fmul fast float %9387, %9387
  %9389 = fmul fast float %9388, 4.000000e+00
  %9390 = fadd fast float %9389, %9375
  %9391 = fadd fast float %9313, -9.000000e+02
  %9392 = fadd fast float %9314, -1.500000e+01
  %9393 = fadd fast float %9315, -7.500000e+02
  %9394 = fmul fast float %9391, 0x3F62345680000000
  %9395 = fmul fast float %9392, 0x3F62345680000000
  %9396 = fmul fast float %9393, 0x3F62345680000000
  %9397 = call float @dx.op.dot3.f32(i32 55, float %9394, float %9395, float %9396, float %9394, float %9395, float %9396)  ; Dot3(ax,ay,az,bx,by,bz)
  %9398 = fsub fast float 1.000000e+00, %9397
  %9399 = call float @dx.op.unary.f32(i32 7, float %9398)  ; Saturate(value)
  %9400 = fmul fast float %9399, %9399
  %9401 = fadd fast float %9390, %9400
  %9402 = fmul fast float %9325, 0x3F25D867E0000000
  %9403 = fmul fast float %9402, %9401
  br label %9404

; <label>:9404                                    ; preds = %9358, %9351
  %9405 = phi float [ %9403, %9358 ], [ 0.000000e+00, %9351 ]
  %9406 = fadd fast float %9405, %9354
  %9407 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %9406)  ; FMin(a,b)
  %9408 = fmul fast float %9407, 0xBFF7154760000000
  %9409 = call float @dx.op.unary.f32(i32 21, float %9408)  ; Exp(value)
  %9410 = fsub fast float 1.000000e+00, %9409
  %9411 = call float @dx.op.binary.f32(i32 36, float %13, float %9410)  ; FMin(a,b)
  %9412 = fsub fast float %14, %9238
  %9413 = fsub fast float %15, %9239
  %9414 = fsub fast float %16, %9240
  %9415 = fmul fast float %9411, %9412
  %9416 = fmul fast float %9411, %9413
  %9417 = fmul fast float %9411, %9414
  %9418 = fadd fast float %9415, %9238
  %9419 = fadd fast float %9416, %9239
  %9420 = fadd fast float %9417, %9240
  br label %9421

; <label>:9421                                    ; preds = %9404, %9283, %9277
  %9422 = phi float [ %9418, %9404 ], [ %9238, %9283 ], [ %9238, %9277 ]
  %9423 = phi float [ %9419, %9404 ], [ %9239, %9283 ], [ %9239, %9277 ]
  %9424 = phi float [ %9420, %9404 ], [ %9240, %9283 ], [ %9240, %9277 ]
  %9425 = fadd fast float %6, 1.000000e+00
  %9426 = fadd fast float %7, 1.000000e+00
  %9427 = fsub fast float 1.000000e+00, %6
  %9428 = fmul fast float %37, %9425
  %9429 = fmul fast float %37, %9426
  %9430 = fmul fast float %37, %9427
  %9431 = fmul fast float %9428, %9422
  %9432 = fmul fast float %9429, %9423
  %9433 = fmul fast float %9430, %9424
  %9434 = fcmp fast ult float %38, 5.000000e-01
  br i1 %9434, label %9460, label %9435

; <label>:9435                                    ; preds = %9421
  %9436 = fmul fast float %9431, 0x4004147AE0000000
  %9437 = fmul fast float %9432, 0x4004147AE0000000
  %9438 = fmul fast float %9433, 0x4004147AE0000000
  %9439 = fadd fast float %9436, 0x3F9EB851E0000000
  %9440 = fadd fast float %9437, 0x3F9EB851E0000000
  %9441 = fadd fast float %9438, 0x3F9EB851E0000000
  %9442 = fmul fast float %9439, %9431
  %9443 = fmul fast float %9440, %9432
  %9444 = fmul fast float %9441, %9433
  %9445 = fmul fast float %9431, 0x400370A3E0000000
  %9446 = fmul fast float %9432, 0x400370A3E0000000
  %9447 = fmul fast float %9433, 0x400370A3E0000000
  %9448 = fadd fast float %9445, 0x3FE2E147A0000000
  %9449 = fadd fast float %9446, 0x3FE2E147A0000000
  %9450 = fadd fast float %9447, 0x3FE2E147A0000000
  %9451 = fmul fast float %9448, %9431
  %9452 = fmul fast float %9449, %9432
  %9453 = fmul fast float %9450, %9433
  %9454 = fadd fast float %9451, 0x3FC1EB8520000000
  %9455 = fadd fast float %9452, 0x3FC1EB8520000000
  %9456 = fadd fast float %9453, 0x3FC1EB8520000000
  %9457 = fdiv fast float %9442, %9454
  %9458 = fdiv fast float %9443, %9455
  %9459 = fdiv fast float %9444, %9456
  br label %9460

; <label>:9460                                    ; preds = %9435, %9421
  %9461 = phi float [ %9457, %9435 ], [ %9431, %9421 ]
  %9462 = phi float [ %9458, %9435 ], [ %9432, %9421 ]
  %9463 = phi float [ %9459, %9435 ], [ %9433, %9421 ]
  %9464 = call float @dx.op.unary.f32(i32 7, float %9461)  ; Saturate(value)
  %9465 = call float @dx.op.unary.f32(i32 7, float %9462)  ; Saturate(value)
  %9466 = call float @dx.op.unary.f32(i32 7, float %9463)  ; Saturate(value)
  %9467 = call float @dx.op.dot3.f32(i32 55, float %9464, float %9465, float %9466, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %9468 = fsub fast float %9464, %9467
  %9469 = fsub fast float %9465, %9467
  %9470 = fsub fast float %9466, %9467
  %9471 = fmul fast float %9468, %9
  %9472 = fmul fast float %9469, %9
  %9473 = fmul fast float %9470, %9
  %9474 = fadd fast float %9471, %9467
  %9475 = fadd fast float %9472, %9467
  %9476 = fadd fast float %9473, %9467
  %9477 = call float @dx.op.unary.f32(i32 7, float %9474)  ; Saturate(value)
  %9478 = call float @dx.op.unary.f32(i32 7, float %9475)  ; Saturate(value)
  %9479 = call float @dx.op.unary.f32(i32 7, float %9476)  ; Saturate(value)
  %9480 = fadd fast float %9477, 0xBFC70A3D80000000
  %9481 = fadd fast float %9478, 0xBFC70A3D80000000
  %9482 = fadd fast float %9479, 0xBFC70A3D80000000
  %9483 = fmul fast float %9480, %8
  %9484 = fmul fast float %9481, %8
  %9485 = fmul fast float %9482, %8
  %9486 = fadd fast float %9483, 0x3FC70A3D80000000
  %9487 = fadd fast float %9484, 0x3FC70A3D80000000
  %9488 = fadd fast float %9485, 0x3FC70A3D80000000
  %9489 = call float @dx.op.unary.f32(i32 7, float %9486)  ; Saturate(value)
  %9490 = call float @dx.op.unary.f32(i32 7, float %9487)  ; Saturate(value)
  %9491 = call float @dx.op.unary.f32(i32 7, float %9488)  ; Saturate(value)
  br label %9492

; <label>:9492                                    ; preds = %9460, %9243
  %9493 = phi float [ %9274, %9243 ], [ %9489, %9460 ]
  %9494 = phi float [ %9275, %9243 ], [ %9490, %9460 ]
  %9495 = phi float [ %9276, %9243 ], [ %9491, %9460 ]
  %9496 = fsub fast float %9493, %8923
  %9497 = fsub fast float %9494, %8924
  %9498 = fsub fast float %9495, %8925
  %9499 = fmul fast float %9496, %9230
  %9500 = fmul fast float %9497, %9230
  %9501 = fmul fast float %9498, %9230
  %9502 = fadd fast float %9499, %8923
  %9503 = fadd fast float %9500, %8924
  %9504 = fadd fast float %9501, %8925
  br label %9505

; <label>:9505                                    ; preds = %9492, %9217
  %9506 = phi float [ %9502, %9492 ], [ %8923, %9217 ]
  %9507 = phi float [ %9503, %9492 ], [ %8924, %9217 ]
  %9508 = phi float [ %9504, %9492 ], [ %8925, %9217 ]
  %9509 = add i32 %68, -1
  %9510 = call i32 @dx.op.binary.i32(i32 37, i32 %9509, i32 0)  ; IMax(a,b)
  %9511 = call i32 @dx.op.binary.i32(i32 37, i32 %71, i32 0)  ; IMax(a,b)
  %9512 = call i32 @dx.op.binary.i32(i32 38, i32 %9510, i32 %60)  ; IMin(a,b)
  %9513 = call i32 @dx.op.binary.i32(i32 38, i32 %9511, i32 %61)  ; IMin(a,b)
  %9514 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %9512, i32 %9513, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %9515 = extractvalue %dx.types.ResRet.f32 %9514, 0
  %9516 = fsub fast float %9515, %89
  %9517 = call float @dx.op.unary.f32(i32 6, float %9516)  ; FAbs(value)
  %9518 = fdiv fast float %9517, %8937
  %9519 = fsub fast float 1.000000e+00, %9518
  %9520 = call float @dx.op.unary.f32(i32 7, float %9519)  ; Saturate(value)
  %9521 = fcmp fast ugt float %9520, 0.000000e+00
  br i1 %9521, label %9522, label %9795

; <label>:9522                                    ; preds = %9505
  %9523 = call i32 @dx.op.binary.i32(i32 37, i32 %9512, i32 0)  ; IMax(a,b)
  %9524 = call i32 @dx.op.binary.i32(i32 37, i32 %9513, i32 0)  ; IMax(a,b)
  %9525 = call i32 @dx.op.binary.i32(i32 38, i32 %9523, i32 %60)  ; IMin(a,b)
  %9526 = call i32 @dx.op.binary.i32(i32 38, i32 %9524, i32 %61)  ; IMin(a,b)
  %9527 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %9525, i32 %9526, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %9528 = extractvalue %dx.types.ResRet.f32 %9527, 0
  %9529 = extractvalue %dx.types.ResRet.f32 %9527, 1
  %9530 = extractvalue %dx.types.ResRet.f32 %9527, 2
  %9531 = extractvalue %dx.types.ResRet.f32 %9527, 3
  %9532 = fcmp fast olt float %9531, 0.000000e+00
  br i1 %9532, label %9533, label %9567

; <label>:9533                                    ; preds = %9522
  %9534 = fcmp fast ogt float %9528, 0x3FA4B5DCC0000000
  %9535 = fcmp fast ogt float %9529, 0x3FA4B5DCC0000000
  %9536 = fcmp fast ogt float %9530, 0x3FA4B5DCC0000000
  %9537 = select i1 %9534, float 0.000000e+00, float 1.000000e+00
  %9538 = select i1 %9535, float 0.000000e+00, float 1.000000e+00
  %9539 = select i1 %9536, float 0.000000e+00, float 1.000000e+00
  %9540 = fmul fast float %9528, 0x3FB3D07220000000
  %9541 = fmul fast float %9529, 0x3FB3D07220000000
  %9542 = fmul fast float %9530, 0x3FB3D07220000000
  %9543 = fadd fast float %9528, 0x3FAC28F5C0000000
  %9544 = fadd fast float %9529, 0x3FAC28F5C0000000
  %9545 = fadd fast float %9530, 0x3FAC28F5C0000000
  %9546 = fmul fast float %9543, 0x3FEE54EDE0000000
  %9547 = fmul fast float %9544, 0x3FEE54EDE0000000
  %9548 = fmul fast float %9545, 0x3FEE54EDE0000000
  %9549 = call float @dx.op.unary.f32(i32 23, float %9546)  ; Log(value)
  %9550 = call float @dx.op.unary.f32(i32 23, float %9547)  ; Log(value)
  %9551 = call float @dx.op.unary.f32(i32 23, float %9548)  ; Log(value)
  %9552 = fmul fast float %9549, 0x4003333340000000
  %9553 = fmul fast float %9550, 0x4003333340000000
  %9554 = fmul fast float %9551, 0x4003333340000000
  %9555 = call float @dx.op.unary.f32(i32 21, float %9552)  ; Exp(value)
  %9556 = call float @dx.op.unary.f32(i32 21, float %9553)  ; Exp(value)
  %9557 = call float @dx.op.unary.f32(i32 21, float %9554)  ; Exp(value)
  %9558 = fsub fast float %9540, %9555
  %9559 = fsub fast float %9541, %9556
  %9560 = fsub fast float %9542, %9557
  %9561 = fmul fast float %9558, %9537
  %9562 = fmul fast float %9559, %9538
  %9563 = fmul fast float %9560, %9539
  %9564 = fadd fast float %9561, %9555
  %9565 = fadd fast float %9562, %9556
  %9566 = fadd fast float %9563, %9557
  br label %9782

; <label>:9567                                    ; preds = %9522
  %9568 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %9525, i32 %9526, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %9569 = extractvalue %dx.types.ResRet.f32 %9568, 0
  %9570 = fcmp fast ogt float %39, 5.000000e-01
  %9571 = fcmp fast olt float %9569, 1.000000e+00
  %9572 = and i1 %9570, %9571
  br i1 %9572, label %9573, label %9711

; <label>:9573                                    ; preds = %9567
  %9574 = sitofp i32 %9525 to float
  %9575 = sitofp i32 %9526 to float
  %9576 = fadd fast float %9574, 5.000000e-01
  %9577 = fadd fast float %9575, 5.000000e-01
  %9578 = fdiv fast float %9576, %46
  %9579 = fdiv fast float %9577, %47
  %9580 = fmul fast float %9578, 2.000000e+00
  %9581 = fmul fast float %9579, 2.000000e+00
  %9582 = fadd fast float %9580, -1.000000e+00
  %9583 = fsub fast float 1.000000e+00, %9581
  %9584 = fmul fast float %9582, %36
  %9585 = call float @dx.op.tertiary.f32(i32 46, float %9583, float %32, float %9584)  ; FMad(a,b,c)
  %9586 = call float @dx.op.tertiary.f32(i32 46, float %9569, float %28, float %9585)  ; FMad(a,b,c)
  %9587 = fadd fast float %9586, %24
  %9588 = call float @dx.op.unary.f32(i32 6, float %9587)  ; FAbs(value)
  %9589 = fcmp fast ogt float %9588, 0x3EB0C6F7A0000000
  br i1 %9589, label %9590, label %9711

; <label>:9590                                    ; preds = %9573
  %9591 = fmul fast float %9582, %35
  %9592 = call float @dx.op.tertiary.f32(i32 46, float %9583, float %31, float %9591)  ; FMad(a,b,c)
  %9593 = call float @dx.op.tertiary.f32(i32 46, float %9569, float %27, float %9592)  ; FMad(a,b,c)
  %9594 = fadd fast float %9593, %23
  %9595 = fmul fast float %9582, %34
  %9596 = call float @dx.op.tertiary.f32(i32 46, float %9583, float %30, float %9595)  ; FMad(a,b,c)
  %9597 = call float @dx.op.tertiary.f32(i32 46, float %9569, float %26, float %9596)  ; FMad(a,b,c)
  %9598 = fadd fast float %9597, %22
  %9599 = fmul fast float %9582, %33
  %9600 = call float @dx.op.tertiary.f32(i32 46, float %9583, float %29, float %9599)  ; FMad(a,b,c)
  %9601 = call float @dx.op.tertiary.f32(i32 46, float %9569, float %25, float %9600)  ; FMad(a,b,c)
  %9602 = fadd fast float %9601, %21
  %9603 = fdiv fast float %9602, %9587
  %9604 = fdiv fast float %9598, %9587
  %9605 = fdiv fast float %9594, %9587
  %9606 = fsub fast float %9603, %18
  %9607 = fsub fast float %9604, %19
  %9608 = fsub fast float %9605, %20
  %9609 = fmul fast float %9606, %9606
  %9610 = fmul fast float %9607, %9607
  %9611 = fadd fast float %9610, %9609
  %9612 = fmul fast float %9608, %9608
  %9613 = fadd fast float %9611, %9612
  %9614 = call float @dx.op.unary.f32(i32 24, float %9613)  ; Sqrt(value)
  %9615 = fsub fast float %9614, %10
  %9616 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %9615)  ; FMax(a,b)
  %9617 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %9617, label %9618, label %9641

; <label>:9618                                    ; preds = %9590
  %9619 = call float @dx.op.unary.f32(i32 6, float %9607)  ; FAbs(value)
  %9620 = fmul fast float %9619, %12
  %9621 = fcmp fast olt float %9620, 0x3F50624DE0000000
  br i1 %9621, label %9622, label %9625

; <label>:9622                                    ; preds = %9618
  %9623 = fmul fast float %9620, 5.000000e-01
  %9624 = fsub fast float 1.000000e+00, %9623
  br label %9630

; <label>:9625                                    ; preds = %9618
  %9626 = fmul fast float %9620, 0xBFF7154760000000
  %9627 = call float @dx.op.unary.f32(i32 21, float %9626)  ; Exp(value)
  %9628 = fsub fast float 1.000000e+00, %9627
  %9629 = fdiv fast float %9628, %9620
  br label %9630

; <label>:9630                                    ; preds = %9625, %9622
  %9631 = phi float [ %9624, %9622 ], [ %9629, %9625 ]
  %9632 = call float @dx.op.binary.f32(i32 36, float %9604, float %19)  ; FMin(a,b)
  %9633 = fsub fast float %9632, %11
  %9634 = fmul fast float %12, %9633
  %9635 = fsub fast float -0.000000e+00, %9634
  %9636 = call float @dx.op.binary.f32(i32 35, float %9635, float -4.000000e+01)  ; FMax(a,b)
  %9637 = call float @dx.op.binary.f32(i32 36, float %9636, float 5.000000e+00)  ; FMin(a,b)
  %9638 = fmul fast float %9637, 0x3FF7154760000000
  %9639 = call float @dx.op.unary.f32(i32 21, float %9638)  ; Exp(value)
  %9640 = fmul fast float %9639, %9631
  br label %9641

; <label>:9641                                    ; preds = %9630, %9590
  %9642 = phi float [ %9640, %9630 ], [ 1.000000e+00, %9590 ]
  %9643 = fmul fast float %9616, %17
  %9644 = fmul fast float %9643, %9642
  %9645 = fcmp fast ole float %9614, %10
  %9646 = fcmp fast olt float %9614, 0x3F1A36E2E0000000
  %9647 = or i1 %9645, %9646
  br i1 %9647, label %9694, label %9648

; <label>:9648                                    ; preds = %9641
  %9649 = fdiv fast float %10, %9614
  %9650 = fmul fast float %9649, %9606
  %9651 = fmul fast float %9649, %9607
  %9652 = fmul fast float %9649, %9608
  %9653 = fadd fast float %9650, %18
  %9654 = fadd fast float %9651, %19
  %9655 = fadd fast float %9652, %20
  %9656 = fadd fast float %9653, -9.000000e+02
  %9657 = fadd fast float %9654, -1.500000e+01
  %9658 = fadd fast float %9655, -7.500000e+02
  %9659 = fmul fast float %9656, 0x3F62345680000000
  %9660 = fmul fast float %9657, 0x3F62345680000000
  %9661 = fmul fast float %9658, 0x3F62345680000000
  %9662 = call float @dx.op.dot3.f32(i32 55, float %9659, float %9660, float %9661, float %9659, float %9660, float %9661)  ; Dot3(ax,ay,az,bx,by,bz)
  %9663 = fsub fast float 1.000000e+00, %9662
  %9664 = call float @dx.op.unary.f32(i32 7, float %9663)  ; Saturate(value)
  %9665 = fmul fast float %9664, %9664
  %9666 = fadd fast float %9653, %9603
  %9667 = fadd fast float %9654, %9604
  %9668 = fadd fast float %9655, %9605
  %9669 = fmul fast float %9666, 0x3F52345680000000
  %9670 = fadd fast float %9669, -2.000000e+00
  %9671 = fmul fast float %9667, 0x3F52345680000000
  %9672 = fadd fast float %9671, 0xBFA1111120000000
  %9673 = fmul fast float %9668, 0x3F52345680000000
  %9674 = fadd fast float %9673, 0xBFFAAAAAC0000000
  %9675 = call float @dx.op.dot3.f32(i32 55, float %9670, float %9672, float %9674, float %9670, float %9672, float %9674)  ; Dot3(ax,ay,az,bx,by,bz)
  %9676 = fsub fast float 1.000000e+00, %9675
  %9677 = call float @dx.op.unary.f32(i32 7, float %9676)  ; Saturate(value)
  %9678 = fmul fast float %9677, %9677
  %9679 = fmul fast float %9678, 4.000000e+00
  %9680 = fadd fast float %9679, %9665
  %9681 = fadd fast float %9603, -9.000000e+02
  %9682 = fadd fast float %9604, -1.500000e+01
  %9683 = fadd fast float %9605, -7.500000e+02
  %9684 = fmul fast float %9681, 0x3F62345680000000
  %9685 = fmul fast float %9682, 0x3F62345680000000
  %9686 = fmul fast float %9683, 0x3F62345680000000
  %9687 = call float @dx.op.dot3.f32(i32 55, float %9684, float %9685, float %9686, float %9684, float %9685, float %9686)  ; Dot3(ax,ay,az,bx,by,bz)
  %9688 = fsub fast float 1.000000e+00, %9687
  %9689 = call float @dx.op.unary.f32(i32 7, float %9688)  ; Saturate(value)
  %9690 = fmul fast float %9689, %9689
  %9691 = fadd fast float %9680, %9690
  %9692 = fmul fast float %9615, 0x3F25D867E0000000
  %9693 = fmul fast float %9692, %9691
  br label %9694

; <label>:9694                                    ; preds = %9648, %9641
  %9695 = phi float [ %9693, %9648 ], [ 0.000000e+00, %9641 ]
  %9696 = fadd fast float %9695, %9644
  %9697 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %9696)  ; FMin(a,b)
  %9698 = fmul fast float %9697, 0xBFF7154760000000
  %9699 = call float @dx.op.unary.f32(i32 21, float %9698)  ; Exp(value)
  %9700 = fsub fast float 1.000000e+00, %9699
  %9701 = call float @dx.op.binary.f32(i32 36, float %13, float %9700)  ; FMin(a,b)
  %9702 = fsub fast float %14, %9528
  %9703 = fsub fast float %15, %9529
  %9704 = fsub fast float %16, %9530
  %9705 = fmul fast float %9701, %9702
  %9706 = fmul fast float %9701, %9703
  %9707 = fmul fast float %9701, %9704
  %9708 = fadd fast float %9705, %9528
  %9709 = fadd fast float %9706, %9529
  %9710 = fadd fast float %9707, %9530
  br label %9711

; <label>:9711                                    ; preds = %9694, %9573, %9567
  %9712 = phi float [ %9708, %9694 ], [ %9528, %9573 ], [ %9528, %9567 ]
  %9713 = phi float [ %9709, %9694 ], [ %9529, %9573 ], [ %9529, %9567 ]
  %9714 = phi float [ %9710, %9694 ], [ %9530, %9573 ], [ %9530, %9567 ]
  %9715 = fadd fast float %6, 1.000000e+00
  %9716 = fadd fast float %7, 1.000000e+00
  %9717 = fsub fast float 1.000000e+00, %6
  %9718 = fmul fast float %37, %9715
  %9719 = fmul fast float %37, %9716
  %9720 = fmul fast float %37, %9717
  %9721 = fmul fast float %9718, %9712
  %9722 = fmul fast float %9719, %9713
  %9723 = fmul fast float %9720, %9714
  %9724 = fcmp fast ult float %38, 5.000000e-01
  br i1 %9724, label %9750, label %9725

; <label>:9725                                    ; preds = %9711
  %9726 = fmul fast float %9721, 0x4004147AE0000000
  %9727 = fmul fast float %9722, 0x4004147AE0000000
  %9728 = fmul fast float %9723, 0x4004147AE0000000
  %9729 = fadd fast float %9726, 0x3F9EB851E0000000
  %9730 = fadd fast float %9727, 0x3F9EB851E0000000
  %9731 = fadd fast float %9728, 0x3F9EB851E0000000
  %9732 = fmul fast float %9729, %9721
  %9733 = fmul fast float %9730, %9722
  %9734 = fmul fast float %9731, %9723
  %9735 = fmul fast float %9721, 0x400370A3E0000000
  %9736 = fmul fast float %9722, 0x400370A3E0000000
  %9737 = fmul fast float %9723, 0x400370A3E0000000
  %9738 = fadd fast float %9735, 0x3FE2E147A0000000
  %9739 = fadd fast float %9736, 0x3FE2E147A0000000
  %9740 = fadd fast float %9737, 0x3FE2E147A0000000
  %9741 = fmul fast float %9738, %9721
  %9742 = fmul fast float %9739, %9722
  %9743 = fmul fast float %9740, %9723
  %9744 = fadd fast float %9741, 0x3FC1EB8520000000
  %9745 = fadd fast float %9742, 0x3FC1EB8520000000
  %9746 = fadd fast float %9743, 0x3FC1EB8520000000
  %9747 = fdiv fast float %9732, %9744
  %9748 = fdiv fast float %9733, %9745
  %9749 = fdiv fast float %9734, %9746
  br label %9750

; <label>:9750                                    ; preds = %9725, %9711
  %9751 = phi float [ %9747, %9725 ], [ %9721, %9711 ]
  %9752 = phi float [ %9748, %9725 ], [ %9722, %9711 ]
  %9753 = phi float [ %9749, %9725 ], [ %9723, %9711 ]
  %9754 = call float @dx.op.unary.f32(i32 7, float %9751)  ; Saturate(value)
  %9755 = call float @dx.op.unary.f32(i32 7, float %9752)  ; Saturate(value)
  %9756 = call float @dx.op.unary.f32(i32 7, float %9753)  ; Saturate(value)
  %9757 = call float @dx.op.dot3.f32(i32 55, float %9754, float %9755, float %9756, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %9758 = fsub fast float %9754, %9757
  %9759 = fsub fast float %9755, %9757
  %9760 = fsub fast float %9756, %9757
  %9761 = fmul fast float %9758, %9
  %9762 = fmul fast float %9759, %9
  %9763 = fmul fast float %9760, %9
  %9764 = fadd fast float %9761, %9757
  %9765 = fadd fast float %9762, %9757
  %9766 = fadd fast float %9763, %9757
  %9767 = call float @dx.op.unary.f32(i32 7, float %9764)  ; Saturate(value)
  %9768 = call float @dx.op.unary.f32(i32 7, float %9765)  ; Saturate(value)
  %9769 = call float @dx.op.unary.f32(i32 7, float %9766)  ; Saturate(value)
  %9770 = fadd fast float %9767, 0xBFC70A3D80000000
  %9771 = fadd fast float %9768, 0xBFC70A3D80000000
  %9772 = fadd fast float %9769, 0xBFC70A3D80000000
  %9773 = fmul fast float %9770, %8
  %9774 = fmul fast float %9771, %8
  %9775 = fmul fast float %9772, %8
  %9776 = fadd fast float %9773, 0x3FC70A3D80000000
  %9777 = fadd fast float %9774, 0x3FC70A3D80000000
  %9778 = fadd fast float %9775, 0x3FC70A3D80000000
  %9779 = call float @dx.op.unary.f32(i32 7, float %9776)  ; Saturate(value)
  %9780 = call float @dx.op.unary.f32(i32 7, float %9777)  ; Saturate(value)
  %9781 = call float @dx.op.unary.f32(i32 7, float %9778)  ; Saturate(value)
  br label %9782

; <label>:9782                                    ; preds = %9750, %9533
  %9783 = phi float [ %9564, %9533 ], [ %9779, %9750 ]
  %9784 = phi float [ %9565, %9533 ], [ %9780, %9750 ]
  %9785 = phi float [ %9566, %9533 ], [ %9781, %9750 ]
  %9786 = fsub fast float %9783, %8923
  %9787 = fsub fast float %9784, %8924
  %9788 = fsub fast float %9785, %8925
  %9789 = fmul fast float %9786, %9520
  %9790 = fmul fast float %9787, %9520
  %9791 = fmul fast float %9788, %9520
  %9792 = fadd fast float %9789, %8923
  %9793 = fadd fast float %9790, %8924
  %9794 = fadd fast float %9791, %8925
  br label %9795

; <label>:9795                                    ; preds = %9782, %9505
  %9796 = phi float [ %9792, %9782 ], [ %8923, %9505 ]
  %9797 = phi float [ %9793, %9782 ], [ %8924, %9505 ]
  %9798 = phi float [ %9794, %9782 ], [ %8925, %9505 ]
  %9799 = add i32 %68, 1
  %9800 = call i32 @dx.op.binary.i32(i32 37, i32 %9799, i32 0)  ; IMax(a,b)
  %9801 = call i32 @dx.op.binary.i32(i32 38, i32 %9800, i32 %60)  ; IMin(a,b)
  %9802 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %9801, i32 %9513, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %9803 = extractvalue %dx.types.ResRet.f32 %9802, 0
  %9804 = fsub fast float %9803, %89
  %9805 = call float @dx.op.unary.f32(i32 6, float %9804)  ; FAbs(value)
  %9806 = fdiv fast float %9805, %8937
  %9807 = fsub fast float 1.000000e+00, %9806
  %9808 = call float @dx.op.unary.f32(i32 7, float %9807)  ; Saturate(value)
  %9809 = fcmp fast ugt float %9808, 0.000000e+00
  br i1 %9809, label %9810, label %10083

; <label>:9810                                    ; preds = %9795
  %9811 = call i32 @dx.op.binary.i32(i32 37, i32 %9801, i32 0)  ; IMax(a,b)
  %9812 = call i32 @dx.op.binary.i32(i32 37, i32 %9513, i32 0)  ; IMax(a,b)
  %9813 = call i32 @dx.op.binary.i32(i32 38, i32 %9811, i32 %60)  ; IMin(a,b)
  %9814 = call i32 @dx.op.binary.i32(i32 38, i32 %9812, i32 %61)  ; IMin(a,b)
  %9815 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %9813, i32 %9814, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %9816 = extractvalue %dx.types.ResRet.f32 %9815, 0
  %9817 = extractvalue %dx.types.ResRet.f32 %9815, 1
  %9818 = extractvalue %dx.types.ResRet.f32 %9815, 2
  %9819 = extractvalue %dx.types.ResRet.f32 %9815, 3
  %9820 = fcmp fast olt float %9819, 0.000000e+00
  br i1 %9820, label %9821, label %9855

; <label>:9821                                    ; preds = %9810
  %9822 = fcmp fast ogt float %9816, 0x3FA4B5DCC0000000
  %9823 = fcmp fast ogt float %9817, 0x3FA4B5DCC0000000
  %9824 = fcmp fast ogt float %9818, 0x3FA4B5DCC0000000
  %9825 = select i1 %9822, float 0.000000e+00, float 1.000000e+00
  %9826 = select i1 %9823, float 0.000000e+00, float 1.000000e+00
  %9827 = select i1 %9824, float 0.000000e+00, float 1.000000e+00
  %9828 = fmul fast float %9816, 0x3FB3D07220000000
  %9829 = fmul fast float %9817, 0x3FB3D07220000000
  %9830 = fmul fast float %9818, 0x3FB3D07220000000
  %9831 = fadd fast float %9816, 0x3FAC28F5C0000000
  %9832 = fadd fast float %9817, 0x3FAC28F5C0000000
  %9833 = fadd fast float %9818, 0x3FAC28F5C0000000
  %9834 = fmul fast float %9831, 0x3FEE54EDE0000000
  %9835 = fmul fast float %9832, 0x3FEE54EDE0000000
  %9836 = fmul fast float %9833, 0x3FEE54EDE0000000
  %9837 = call float @dx.op.unary.f32(i32 23, float %9834)  ; Log(value)
  %9838 = call float @dx.op.unary.f32(i32 23, float %9835)  ; Log(value)
  %9839 = call float @dx.op.unary.f32(i32 23, float %9836)  ; Log(value)
  %9840 = fmul fast float %9837, 0x4003333340000000
  %9841 = fmul fast float %9838, 0x4003333340000000
  %9842 = fmul fast float %9839, 0x4003333340000000
  %9843 = call float @dx.op.unary.f32(i32 21, float %9840)  ; Exp(value)
  %9844 = call float @dx.op.unary.f32(i32 21, float %9841)  ; Exp(value)
  %9845 = call float @dx.op.unary.f32(i32 21, float %9842)  ; Exp(value)
  %9846 = fsub fast float %9828, %9843
  %9847 = fsub fast float %9829, %9844
  %9848 = fsub fast float %9830, %9845
  %9849 = fmul fast float %9846, %9825
  %9850 = fmul fast float %9847, %9826
  %9851 = fmul fast float %9848, %9827
  %9852 = fadd fast float %9849, %9843
  %9853 = fadd fast float %9850, %9844
  %9854 = fadd fast float %9851, %9845
  br label %10070

; <label>:9855                                    ; preds = %9810
  %9856 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %9813, i32 %9814, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %9857 = extractvalue %dx.types.ResRet.f32 %9856, 0
  %9858 = fcmp fast ogt float %39, 5.000000e-01
  %9859 = fcmp fast olt float %9857, 1.000000e+00
  %9860 = and i1 %9858, %9859
  br i1 %9860, label %9861, label %9999

; <label>:9861                                    ; preds = %9855
  %9862 = sitofp i32 %9813 to float
  %9863 = sitofp i32 %9814 to float
  %9864 = fadd fast float %9862, 5.000000e-01
  %9865 = fadd fast float %9863, 5.000000e-01
  %9866 = fdiv fast float %9864, %46
  %9867 = fdiv fast float %9865, %47
  %9868 = fmul fast float %9866, 2.000000e+00
  %9869 = fmul fast float %9867, 2.000000e+00
  %9870 = fadd fast float %9868, -1.000000e+00
  %9871 = fsub fast float 1.000000e+00, %9869
  %9872 = fmul fast float %9870, %36
  %9873 = call float @dx.op.tertiary.f32(i32 46, float %9871, float %32, float %9872)  ; FMad(a,b,c)
  %9874 = call float @dx.op.tertiary.f32(i32 46, float %9857, float %28, float %9873)  ; FMad(a,b,c)
  %9875 = fadd fast float %9874, %24
  %9876 = call float @dx.op.unary.f32(i32 6, float %9875)  ; FAbs(value)
  %9877 = fcmp fast ogt float %9876, 0x3EB0C6F7A0000000
  br i1 %9877, label %9878, label %9999

; <label>:9878                                    ; preds = %9861
  %9879 = fmul fast float %9870, %35
  %9880 = call float @dx.op.tertiary.f32(i32 46, float %9871, float %31, float %9879)  ; FMad(a,b,c)
  %9881 = call float @dx.op.tertiary.f32(i32 46, float %9857, float %27, float %9880)  ; FMad(a,b,c)
  %9882 = fadd fast float %9881, %23
  %9883 = fmul fast float %9870, %34
  %9884 = call float @dx.op.tertiary.f32(i32 46, float %9871, float %30, float %9883)  ; FMad(a,b,c)
  %9885 = call float @dx.op.tertiary.f32(i32 46, float %9857, float %26, float %9884)  ; FMad(a,b,c)
  %9886 = fadd fast float %9885, %22
  %9887 = fmul fast float %9870, %33
  %9888 = call float @dx.op.tertiary.f32(i32 46, float %9871, float %29, float %9887)  ; FMad(a,b,c)
  %9889 = call float @dx.op.tertiary.f32(i32 46, float %9857, float %25, float %9888)  ; FMad(a,b,c)
  %9890 = fadd fast float %9889, %21
  %9891 = fdiv fast float %9890, %9875
  %9892 = fdiv fast float %9886, %9875
  %9893 = fdiv fast float %9882, %9875
  %9894 = fsub fast float %9891, %18
  %9895 = fsub fast float %9892, %19
  %9896 = fsub fast float %9893, %20
  %9897 = fmul fast float %9894, %9894
  %9898 = fmul fast float %9895, %9895
  %9899 = fadd fast float %9898, %9897
  %9900 = fmul fast float %9896, %9896
  %9901 = fadd fast float %9899, %9900
  %9902 = call float @dx.op.unary.f32(i32 24, float %9901)  ; Sqrt(value)
  %9903 = fsub fast float %9902, %10
  %9904 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %9903)  ; FMax(a,b)
  %9905 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %9905, label %9906, label %9929

; <label>:9906                                    ; preds = %9878
  %9907 = call float @dx.op.unary.f32(i32 6, float %9895)  ; FAbs(value)
  %9908 = fmul fast float %9907, %12
  %9909 = fcmp fast olt float %9908, 0x3F50624DE0000000
  br i1 %9909, label %9910, label %9913

; <label>:9910                                    ; preds = %9906
  %9911 = fmul fast float %9908, 5.000000e-01
  %9912 = fsub fast float 1.000000e+00, %9911
  br label %9918

; <label>:9913                                    ; preds = %9906
  %9914 = fmul fast float %9908, 0xBFF7154760000000
  %9915 = call float @dx.op.unary.f32(i32 21, float %9914)  ; Exp(value)
  %9916 = fsub fast float 1.000000e+00, %9915
  %9917 = fdiv fast float %9916, %9908
  br label %9918

; <label>:9918                                    ; preds = %9913, %9910
  %9919 = phi float [ %9912, %9910 ], [ %9917, %9913 ]
  %9920 = call float @dx.op.binary.f32(i32 36, float %9892, float %19)  ; FMin(a,b)
  %9921 = fsub fast float %9920, %11
  %9922 = fmul fast float %12, %9921
  %9923 = fsub fast float -0.000000e+00, %9922
  %9924 = call float @dx.op.binary.f32(i32 35, float %9923, float -4.000000e+01)  ; FMax(a,b)
  %9925 = call float @dx.op.binary.f32(i32 36, float %9924, float 5.000000e+00)  ; FMin(a,b)
  %9926 = fmul fast float %9925, 0x3FF7154760000000
  %9927 = call float @dx.op.unary.f32(i32 21, float %9926)  ; Exp(value)
  %9928 = fmul fast float %9927, %9919
  br label %9929

; <label>:9929                                    ; preds = %9918, %9878
  %9930 = phi float [ %9928, %9918 ], [ 1.000000e+00, %9878 ]
  %9931 = fmul fast float %9904, %17
  %9932 = fmul fast float %9931, %9930
  %9933 = fcmp fast ole float %9902, %10
  %9934 = fcmp fast olt float %9902, 0x3F1A36E2E0000000
  %9935 = or i1 %9933, %9934
  br i1 %9935, label %9982, label %9936

; <label>:9936                                    ; preds = %9929
  %9937 = fdiv fast float %10, %9902
  %9938 = fmul fast float %9937, %9894
  %9939 = fmul fast float %9937, %9895
  %9940 = fmul fast float %9937, %9896
  %9941 = fadd fast float %9938, %18
  %9942 = fadd fast float %9939, %19
  %9943 = fadd fast float %9940, %20
  %9944 = fadd fast float %9941, -9.000000e+02
  %9945 = fadd fast float %9942, -1.500000e+01
  %9946 = fadd fast float %9943, -7.500000e+02
  %9947 = fmul fast float %9944, 0x3F62345680000000
  %9948 = fmul fast float %9945, 0x3F62345680000000
  %9949 = fmul fast float %9946, 0x3F62345680000000
  %9950 = call float @dx.op.dot3.f32(i32 55, float %9947, float %9948, float %9949, float %9947, float %9948, float %9949)  ; Dot3(ax,ay,az,bx,by,bz)
  %9951 = fsub fast float 1.000000e+00, %9950
  %9952 = call float @dx.op.unary.f32(i32 7, float %9951)  ; Saturate(value)
  %9953 = fmul fast float %9952, %9952
  %9954 = fadd fast float %9941, %9891
  %9955 = fadd fast float %9942, %9892
  %9956 = fadd fast float %9943, %9893
  %9957 = fmul fast float %9954, 0x3F52345680000000
  %9958 = fadd fast float %9957, -2.000000e+00
  %9959 = fmul fast float %9955, 0x3F52345680000000
  %9960 = fadd fast float %9959, 0xBFA1111120000000
  %9961 = fmul fast float %9956, 0x3F52345680000000
  %9962 = fadd fast float %9961, 0xBFFAAAAAC0000000
  %9963 = call float @dx.op.dot3.f32(i32 55, float %9958, float %9960, float %9962, float %9958, float %9960, float %9962)  ; Dot3(ax,ay,az,bx,by,bz)
  %9964 = fsub fast float 1.000000e+00, %9963
  %9965 = call float @dx.op.unary.f32(i32 7, float %9964)  ; Saturate(value)
  %9966 = fmul fast float %9965, %9965
  %9967 = fmul fast float %9966, 4.000000e+00
  %9968 = fadd fast float %9967, %9953
  %9969 = fadd fast float %9891, -9.000000e+02
  %9970 = fadd fast float %9892, -1.500000e+01
  %9971 = fadd fast float %9893, -7.500000e+02
  %9972 = fmul fast float %9969, 0x3F62345680000000
  %9973 = fmul fast float %9970, 0x3F62345680000000
  %9974 = fmul fast float %9971, 0x3F62345680000000
  %9975 = call float @dx.op.dot3.f32(i32 55, float %9972, float %9973, float %9974, float %9972, float %9973, float %9974)  ; Dot3(ax,ay,az,bx,by,bz)
  %9976 = fsub fast float 1.000000e+00, %9975
  %9977 = call float @dx.op.unary.f32(i32 7, float %9976)  ; Saturate(value)
  %9978 = fmul fast float %9977, %9977
  %9979 = fadd fast float %9968, %9978
  %9980 = fmul fast float %9903, 0x3F25D867E0000000
  %9981 = fmul fast float %9980, %9979
  br label %9982

; <label>:9982                                    ; preds = %9936, %9929
  %9983 = phi float [ %9981, %9936 ], [ 0.000000e+00, %9929 ]
  %9984 = fadd fast float %9983, %9932
  %9985 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %9984)  ; FMin(a,b)
  %9986 = fmul fast float %9985, 0xBFF7154760000000
  %9987 = call float @dx.op.unary.f32(i32 21, float %9986)  ; Exp(value)
  %9988 = fsub fast float 1.000000e+00, %9987
  %9989 = call float @dx.op.binary.f32(i32 36, float %13, float %9988)  ; FMin(a,b)
  %9990 = fsub fast float %14, %9816
  %9991 = fsub fast float %15, %9817
  %9992 = fsub fast float %16, %9818
  %9993 = fmul fast float %9989, %9990
  %9994 = fmul fast float %9989, %9991
  %9995 = fmul fast float %9989, %9992
  %9996 = fadd fast float %9993, %9816
  %9997 = fadd fast float %9994, %9817
  %9998 = fadd fast float %9995, %9818
  br label %9999

; <label>:9999                                    ; preds = %9982, %9861, %9855
  %10000 = phi float [ %9996, %9982 ], [ %9816, %9861 ], [ %9816, %9855 ]
  %10001 = phi float [ %9997, %9982 ], [ %9817, %9861 ], [ %9817, %9855 ]
  %10002 = phi float [ %9998, %9982 ], [ %9818, %9861 ], [ %9818, %9855 ]
  %10003 = fadd fast float %6, 1.000000e+00
  %10004 = fadd fast float %7, 1.000000e+00
  %10005 = fsub fast float 1.000000e+00, %6
  %10006 = fmul fast float %37, %10003
  %10007 = fmul fast float %37, %10004
  %10008 = fmul fast float %37, %10005
  %10009 = fmul fast float %10006, %10000
  %10010 = fmul fast float %10007, %10001
  %10011 = fmul fast float %10008, %10002
  %10012 = fcmp fast ult float %38, 5.000000e-01
  br i1 %10012, label %10038, label %10013

; <label>:10013                                   ; preds = %9999
  %10014 = fmul fast float %10009, 0x4004147AE0000000
  %10015 = fmul fast float %10010, 0x4004147AE0000000
  %10016 = fmul fast float %10011, 0x4004147AE0000000
  %10017 = fadd fast float %10014, 0x3F9EB851E0000000
  %10018 = fadd fast float %10015, 0x3F9EB851E0000000
  %10019 = fadd fast float %10016, 0x3F9EB851E0000000
  %10020 = fmul fast float %10017, %10009
  %10021 = fmul fast float %10018, %10010
  %10022 = fmul fast float %10019, %10011
  %10023 = fmul fast float %10009, 0x400370A3E0000000
  %10024 = fmul fast float %10010, 0x400370A3E0000000
  %10025 = fmul fast float %10011, 0x400370A3E0000000
  %10026 = fadd fast float %10023, 0x3FE2E147A0000000
  %10027 = fadd fast float %10024, 0x3FE2E147A0000000
  %10028 = fadd fast float %10025, 0x3FE2E147A0000000
  %10029 = fmul fast float %10026, %10009
  %10030 = fmul fast float %10027, %10010
  %10031 = fmul fast float %10028, %10011
  %10032 = fadd fast float %10029, 0x3FC1EB8520000000
  %10033 = fadd fast float %10030, 0x3FC1EB8520000000
  %10034 = fadd fast float %10031, 0x3FC1EB8520000000
  %10035 = fdiv fast float %10020, %10032
  %10036 = fdiv fast float %10021, %10033
  %10037 = fdiv fast float %10022, %10034
  br label %10038

; <label>:10038                                   ; preds = %10013, %9999
  %10039 = phi float [ %10035, %10013 ], [ %10009, %9999 ]
  %10040 = phi float [ %10036, %10013 ], [ %10010, %9999 ]
  %10041 = phi float [ %10037, %10013 ], [ %10011, %9999 ]
  %10042 = call float @dx.op.unary.f32(i32 7, float %10039)  ; Saturate(value)
  %10043 = call float @dx.op.unary.f32(i32 7, float %10040)  ; Saturate(value)
  %10044 = call float @dx.op.unary.f32(i32 7, float %10041)  ; Saturate(value)
  %10045 = call float @dx.op.dot3.f32(i32 55, float %10042, float %10043, float %10044, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %10046 = fsub fast float %10042, %10045
  %10047 = fsub fast float %10043, %10045
  %10048 = fsub fast float %10044, %10045
  %10049 = fmul fast float %10046, %9
  %10050 = fmul fast float %10047, %9
  %10051 = fmul fast float %10048, %9
  %10052 = fadd fast float %10049, %10045
  %10053 = fadd fast float %10050, %10045
  %10054 = fadd fast float %10051, %10045
  %10055 = call float @dx.op.unary.f32(i32 7, float %10052)  ; Saturate(value)
  %10056 = call float @dx.op.unary.f32(i32 7, float %10053)  ; Saturate(value)
  %10057 = call float @dx.op.unary.f32(i32 7, float %10054)  ; Saturate(value)
  %10058 = fadd fast float %10055, 0xBFC70A3D80000000
  %10059 = fadd fast float %10056, 0xBFC70A3D80000000
  %10060 = fadd fast float %10057, 0xBFC70A3D80000000
  %10061 = fmul fast float %10058, %8
  %10062 = fmul fast float %10059, %8
  %10063 = fmul fast float %10060, %8
  %10064 = fadd fast float %10061, 0x3FC70A3D80000000
  %10065 = fadd fast float %10062, 0x3FC70A3D80000000
  %10066 = fadd fast float %10063, 0x3FC70A3D80000000
  %10067 = call float @dx.op.unary.f32(i32 7, float %10064)  ; Saturate(value)
  %10068 = call float @dx.op.unary.f32(i32 7, float %10065)  ; Saturate(value)
  %10069 = call float @dx.op.unary.f32(i32 7, float %10066)  ; Saturate(value)
  br label %10070

; <label>:10070                                   ; preds = %10038, %9821
  %10071 = phi float [ %9852, %9821 ], [ %10067, %10038 ]
  %10072 = phi float [ %9853, %9821 ], [ %10068, %10038 ]
  %10073 = phi float [ %9854, %9821 ], [ %10069, %10038 ]
  %10074 = fsub fast float %10071, %8923
  %10075 = fsub fast float %10072, %8924
  %10076 = fsub fast float %10073, %8925
  %10077 = fmul fast float %10074, %9808
  %10078 = fmul fast float %10075, %9808
  %10079 = fmul fast float %10076, %9808
  %10080 = fadd fast float %10077, %8923
  %10081 = fadd fast float %10078, %8924
  %10082 = fadd fast float %10079, %8925
  br label %10083

; <label>:10083                                   ; preds = %10070, %9795
  %10084 = phi float [ %10080, %10070 ], [ %8923, %9795 ]
  %10085 = phi float [ %10081, %10070 ], [ %8924, %9795 ]
  %10086 = phi float [ %10082, %10070 ], [ %8925, %9795 ]
  %10087 = call float @dx.op.binary.f32(i32 36, float %9796, float %10084)  ; FMin(a,b)
  %10088 = call float @dx.op.binary.f32(i32 36, float %9797, float %10085)  ; FMin(a,b)
  %10089 = call float @dx.op.binary.f32(i32 36, float %9798, float %10086)  ; FMin(a,b)
  %10090 = call float @dx.op.binary.f32(i32 36, float %9218, float %9506)  ; FMin(a,b)
  %10091 = call float @dx.op.binary.f32(i32 36, float %9219, float %9507)  ; FMin(a,b)
  %10092 = call float @dx.op.binary.f32(i32 36, float %9220, float %9508)  ; FMin(a,b)
  %10093 = call float @dx.op.binary.f32(i32 36, float %10090, float %10087)  ; FMin(a,b)
  %10094 = call float @dx.op.binary.f32(i32 36, float %10091, float %10088)  ; FMin(a,b)
  %10095 = call float @dx.op.binary.f32(i32 36, float %10092, float %10089)  ; FMin(a,b)
  %10096 = call float @dx.op.binary.f32(i32 36, float %8923, float %10093)  ; FMin(a,b)
  %10097 = call float @dx.op.binary.f32(i32 36, float %8924, float %10094)  ; FMin(a,b)
  %10098 = call float @dx.op.binary.f32(i32 36, float %8925, float %10095)  ; FMin(a,b)
  %10099 = call float @dx.op.binary.f32(i32 35, float %9796, float %10084)  ; FMax(a,b)
  %10100 = call float @dx.op.binary.f32(i32 35, float %9797, float %10085)  ; FMax(a,b)
  %10101 = call float @dx.op.binary.f32(i32 35, float %9798, float %10086)  ; FMax(a,b)
  %10102 = call float @dx.op.binary.f32(i32 35, float %9218, float %9506)  ; FMax(a,b)
  %10103 = call float @dx.op.binary.f32(i32 35, float %9219, float %9507)  ; FMax(a,b)
  %10104 = call float @dx.op.binary.f32(i32 35, float %9220, float %9508)  ; FMax(a,b)
  %10105 = call float @dx.op.binary.f32(i32 35, float %10102, float %10099)  ; FMax(a,b)
  %10106 = call float @dx.op.binary.f32(i32 35, float %10103, float %10100)  ; FMax(a,b)
  %10107 = call float @dx.op.binary.f32(i32 35, float %10104, float %10101)  ; FMax(a,b)
  %10108 = call float @dx.op.binary.f32(i32 35, float %8923, float %10105)  ; FMax(a,b)
  %10109 = call float @dx.op.binary.f32(i32 35, float %8924, float %10106)  ; FMax(a,b)
  %10110 = call float @dx.op.binary.f32(i32 35, float %8925, float %10107)  ; FMax(a,b)
  %10111 = fsub fast float %10108, %10096
  %10112 = fsub fast float %10109, %10097
  %10113 = fsub fast float %10110, %10098
  %10114 = call float @dx.op.unary.f32(i32 6, float %10111)  ; FAbs(value)
  %10115 = call float @dx.op.unary.f32(i32 6, float %10112)  ; FAbs(value)
  %10116 = call float @dx.op.unary.f32(i32 6, float %10113)  ; FAbs(value)
  %10117 = call float @dx.op.binary.f32(i32 35, float %10115, float %10116)  ; FMax(a,b)
  %10118 = call float @dx.op.binary.f32(i32 35, float %10114, float %10117)  ; FMax(a,b)
  %10119 = call float @dx.op.binary.f32(i32 35, float %10109, float %10110)  ; FMax(a,b)
  %10120 = call float @dx.op.binary.f32(i32 35, float %10108, float %10119)  ; FMax(a,b)
  %10121 = fmul fast float %10120, 1.250000e-01
  %10122 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %10121)  ; FMax(a,b)
  %10123 = fcmp fast ogt float %10118, %10122
  br i1 %10123, label %10124, label %10186

; <label>:10124                                   ; preds = %10083
  %10125 = fsub fast float %9218, %9506
  %10126 = fsub fast float %9219, %9507
  %10127 = fsub fast float %9220, %9508
  %10128 = call float @dx.op.unary.f32(i32 6, float %10125)  ; FAbs(value)
  %10129 = call float @dx.op.unary.f32(i32 6, float %10126)  ; FAbs(value)
  %10130 = call float @dx.op.unary.f32(i32 6, float %10127)  ; FAbs(value)
  %10131 = call float @dx.op.binary.f32(i32 35, float %10129, float %10130)  ; FMax(a,b)
  %10132 = call float @dx.op.binary.f32(i32 35, float %10128, float %10131)  ; FMax(a,b)
  %10133 = fsub fast float %9796, %10084
  %10134 = fsub fast float %9797, %10085
  %10135 = fsub fast float %9798, %10086
  %10136 = call float @dx.op.unary.f32(i32 6, float %10133)  ; FAbs(value)
  %10137 = call float @dx.op.unary.f32(i32 6, float %10134)  ; FAbs(value)
  %10138 = call float @dx.op.unary.f32(i32 6, float %10135)  ; FAbs(value)
  %10139 = call float @dx.op.binary.f32(i32 35, float %10137, float %10138)  ; FMax(a,b)
  %10140 = call float @dx.op.binary.f32(i32 35, float %10136, float %10139)  ; FMax(a,b)
  %10141 = fcmp fast olt float %10132, %10140
  %10142 = select i1 %10141, float %9218, float %9796
  %10143 = select i1 %10141, float %9219, float %9797
  %10144 = select i1 %10141, float %9220, float %9798
  %10145 = select i1 %10141, float %9506, float %10084
  %10146 = select i1 %10141, float %9507, float %10085
  %10147 = select i1 %10141, float %9508, float %10086
  %10148 = fsub fast float %8923, %10145
  %10149 = fsub fast float %8924, %10146
  %10150 = fsub fast float %8925, %10147
  %10151 = fsub fast float %8923, %10142
  %10152 = fsub fast float %8924, %10143
  %10153 = fsub fast float %8925, %10144
  %10154 = call float @dx.op.dot3.f32(i32 55, float %10151, float %10152, float %10153, float %10148, float %10149, float %10150)  ; Dot3(ax,ay,az,bx,by,bz)
  %10155 = fcmp fast ogt float %10154, 0.000000e+00
  br i1 %10155, label %10156, label %10168

; <label>:10156                                   ; preds = %10124
  %10157 = fsub fast float %10142, %10145
  %10158 = fsub fast float %10143, %10146
  %10159 = fsub fast float %10144, %10147
  %10160 = call float @dx.op.unary.f32(i32 6, float %10157)  ; FAbs(value)
  %10161 = call float @dx.op.unary.f32(i32 6, float %10158)  ; FAbs(value)
  %10162 = call float @dx.op.unary.f32(i32 6, float %10159)  ; FAbs(value)
  %10163 = call float @dx.op.binary.f32(i32 35, float %10161, float %10162)  ; FMax(a,b)
  %10164 = call float @dx.op.binary.f32(i32 35, float %10160, float %10163)  ; FMax(a,b)
  %10165 = fmul fast float %10118, 2.500000e-01
  %10166 = fcmp fast olt float %10164, %10165
  %10167 = select i1 %10166, float 5.000000e-01, float 1.000000e+00
  br label %10168

; <label>:10168                                   ; preds = %10156, %10124
  %10169 = phi float [ 1.000000e+00, %10124 ], [ %10167, %10156 ]
  %10170 = fmul fast float %10169, %3
  %10171 = fadd fast float %10142, %10145
  %10172 = fadd fast float %10143, %10146
  %10173 = fadd fast float %10144, %10147
  %10174 = fmul fast float %10171, 5.000000e-01
  %10175 = fmul fast float %10172, 5.000000e-01
  %10176 = fmul fast float %10173, 5.000000e-01
  %10177 = fsub fast float %10174, %8923
  %10178 = fsub fast float %10175, %8924
  %10179 = fsub fast float %10176, %8925
  %10180 = fmul fast float %10170, %10177
  %10181 = fmul fast float %10170, %10178
  %10182 = fmul fast float %10170, %10179
  %10183 = fadd fast float %10180, %8923
  %10184 = fadd fast float %10181, %8924
  %10185 = fadd fast float %10182, %8925
  br label %10186

; <label>:10186                                   ; preds = %10168, %10083, %8894, %8678, %4096, %4011, %3390, %1208
  %10187 = phi float [ %447, %1208 ], [ %1943, %3390 ], [ %5630, %8678 ], [ %1943, %4096 ], [ %1943, %4011 ], [ %5630, %10083 ], [ %5630, %10168 ], [ %5630, %8894 ]
  %10188 = phi float [ %448, %1208 ], [ %1944, %3390 ], [ %5631, %8678 ], [ %1944, %4096 ], [ %1944, %4011 ], [ %5631, %10083 ], [ %5631, %10168 ], [ %5631, %8894 ]
  %10189 = phi float [ %449, %1208 ], [ %1945, %3390 ], [ %5632, %8678 ], [ %1945, %4096 ], [ %1945, %4011 ], [ %5632, %10083 ], [ %5632, %10168 ], [ %5632, %8894 ]
  %10190 = phi float [ %1213, %1208 ], [ %1213, %3390 ], [ %5633, %8678 ], [ %1213, %4096 ], [ %1213, %4011 ], [ %5633, %10083 ], [ %5633, %10168 ], [ %5633, %8894 ]
  %10191 = phi float [ %701, %1208 ], [ %2667, %3390 ], [ %7149, %8678 ], [ %2667, %4096 ], [ %2667, %4011 ], [ %7149, %10083 ], [ %7149, %10168 ], [ %7149, %8894 ]
  %10192 = phi float [ %702, %1208 ], [ %2668, %3390 ], [ %7150, %8678 ], [ %2668, %4096 ], [ %2668, %4011 ], [ %7150, %10083 ], [ %7150, %10168 ], [ %7150, %8894 ]
  %10193 = phi float [ %703, %1208 ], [ %2669, %3390 ], [ %7151, %8678 ], [ %2669, %4096 ], [ %2669, %4011 ], [ %7151, %10083 ], [ %7151, %10168 ], [ %7151, %8894 ]
  %10194 = phi float [ %1215, %1208 ], [ %1215, %3390 ], [ %7152, %8678 ], [ %1215, %4096 ], [ %1215, %4011 ], [ %7152, %10083 ], [ %7152, %10168 ], [ %7152, %8894 ]
  %10195 = phi float [ %955, %1208 ], [ %3391, %3390 ], [ %8668, %8678 ], [ %3391, %4096 ], [ %3391, %4011 ], [ %8668, %10083 ], [ %8668, %10168 ], [ %8668, %8894 ]
  %10196 = phi float [ %956, %1208 ], [ %3392, %3390 ], [ %8669, %8678 ], [ %3392, %4096 ], [ %3392, %4011 ], [ %8669, %10083 ], [ %8669, %10168 ], [ %8669, %8894 ]
  %10197 = phi float [ %957, %1208 ], [ %3393, %3390 ], [ %8670, %8678 ], [ %3393, %4096 ], [ %3393, %4011 ], [ %8670, %10083 ], [ %8670, %10168 ], [ %8670, %8894 ]
  %10198 = phi float [ %1217, %1208 ], [ %1217, %3390 ], [ %8671, %8678 ], [ %1217, %4096 ], [ %1217, %4011 ], [ %8671, %10083 ], [ %8671, %10168 ], [ %8671, %8894 ]
  %10199 = phi float [ %1209, %1208 ], [ %1209, %3390 ], [ %8709, %8678 ], [ %4111, %4096 ], [ %1209, %4011 ], [ %8923, %10083 ], [ %10183, %10168 ], [ %8923, %8894 ]
  %10200 = phi float [ %1210, %1208 ], [ %1210, %3390 ], [ %8710, %8678 ], [ %4112, %4096 ], [ %1210, %4011 ], [ %8924, %10083 ], [ %10184, %10168 ], [ %8924, %8894 ]
  %10201 = phi float [ %1211, %1208 ], [ %1211, %3390 ], [ %8711, %8678 ], [ %4113, %4096 ], [ %1211, %4011 ], [ %8925, %10083 ], [ %10185, %10168 ], [ %8925, %8894 ]
  %10202 = phi float [ %1219, %1208 ], [ %1219, %3390 ], [ %8712, %8678 ], [ %1219, %4096 ], [ %1219, %4011 ], [ %8676, %10083 ], [ %8676, %10168 ], [ %8676, %8894 ]
  %10203 = fmul fast float %10187, %163
  %10204 = fmul fast float %10188, %163
  %10205 = fmul fast float %10189, %163
  %10206 = fmul fast float %10191, %164
  %10207 = fmul fast float %10192, %164
  %10208 = fmul fast float %10193, %164
  %10209 = fadd fast float %10206, %10203
  %10210 = fadd fast float %10207, %10204
  %10211 = fadd fast float %10208, %10205
  %10212 = fmul fast float %10195, %165
  %10213 = fmul fast float %10196, %165
  %10214 = fmul fast float %10197, %165
  %10215 = fadd fast float %10209, %10212
  %10216 = fadd fast float %10210, %10213
  %10217 = fadd fast float %10211, %10214
  %10218 = fmul fast float %10199, %166
  %10219 = fmul fast float %10200, %166
  %10220 = fmul fast float %10201, %166
  %10221 = fadd fast float %10215, %10218
  %10222 = fadd fast float %10216, %10219
  %10223 = fadd fast float %10217, %10220
  %10224 = fcmp fast ogt float %10221, 0x3F69A5C380000000
  %10225 = fcmp fast ogt float %10222, 0x3F69A5C380000000
  %10226 = fcmp fast ogt float %10223, 0x3F69A5C380000000
  %10227 = select i1 %10224, float 0.000000e+00, float 1.000000e+00
  %10228 = select i1 %10225, float 0.000000e+00, float 1.000000e+00
  %10229 = select i1 %10226, float 0.000000e+00, float 1.000000e+00
  %10230 = fmul fast float %10221, 0x4029D70A40000000
  %10231 = fmul fast float %10222, 0x4029D70A40000000
  %10232 = fmul fast float %10223, 0x4029D70A40000000
  %10233 = call float @dx.op.binary.f32(i32 35, float %10221, float 0.000000e+00)  ; FMax(a,b)
  %10234 = call float @dx.op.binary.f32(i32 35, float %10222, float 0.000000e+00)  ; FMax(a,b)
  %10235 = call float @dx.op.binary.f32(i32 35, float %10223, float 0.000000e+00)  ; FMax(a,b)
  %10236 = call float @dx.op.unary.f32(i32 23, float %10233)  ; Log(value)
  %10237 = call float @dx.op.unary.f32(i32 23, float %10234)  ; Log(value)
  %10238 = call float @dx.op.unary.f32(i32 23, float %10235)  ; Log(value)
  %10239 = fmul fast float %10236, 0x3FDAAAAAA0000000
  %10240 = fmul fast float %10237, 0x3FDAAAAAA0000000
  %10241 = fmul fast float %10238, 0x3FDAAAAAA0000000
  %10242 = call float @dx.op.unary.f32(i32 21, float %10239)  ; Exp(value)
  %10243 = call float @dx.op.unary.f32(i32 21, float %10240)  ; Exp(value)
  %10244 = call float @dx.op.unary.f32(i32 21, float %10241)  ; Exp(value)
  %10245 = fmul fast float %10242, 0x3FF0E147A0000000
  %10246 = fmul fast float %10243, 0x3FF0E147A0000000
  %10247 = fmul fast float %10244, 0x3FF0E147A0000000
  %10248 = fadd fast float %10245, 0xBFAC28F5C0000000
  %10249 = fadd fast float %10246, 0xBFAC28F5C0000000
  %10250 = fadd fast float %10247, 0xBFAC28F5C0000000
  %10251 = fsub fast float %10230, %10248
  %10252 = fsub fast float %10231, %10249
  %10253 = fsub fast float %10232, %10250
  %10254 = fmul fast float %10251, %10227
  %10255 = fmul fast float %10252, %10228
  %10256 = fmul fast float %10253, %10229
  %10257 = fadd fast float %10254, %10248
  %10258 = fadd fast float %10255, %10249
  %10259 = fadd fast float %10256, %10250
  %10260 = call float @dx.op.dot4.f32(i32 56, float %10190, float %10194, float %10198, float %10202, float %163, float %164, float %165, float %166)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %10257)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %10258)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %10259)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %10260)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %81)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare i1 @dx.op.isSpecialFloat.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !37, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, !28}
!36 = !{i32 9}
!37 = !{!38, !39}
!38 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
!39 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !40}
!40 = !{i32 3, i32 1}
