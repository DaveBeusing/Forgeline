;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float   xyz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: 4f7b7a899a9d538629381320f998b005
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %40 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %41 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %42 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %43 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %44 = extractvalue %dx.types.Dimensions %43, 0
  %45 = extractvalue %dx.types.Dimensions %43, 1
  %46 = uitofp i32 %44 to float
  %47 = uitofp i32 %45 to float
  %48 = fmul fast float %46, %41
  %49 = fmul fast float %47, %42
  %50 = fdiv fast float %48, %4
  %51 = fdiv fast float %49, %5
  %52 = fadd fast float %50, -5.000000e-01
  %53 = fadd fast float %51, -5.000000e-01
  %54 = call float @dx.op.unary.f32(i32 27, float %52)  ; Round_ni(value)
  %55 = call float @dx.op.unary.f32(i32 27, float %53)  ; Round_ni(value)
  %56 = fptosi float %54 to i32
  %57 = fptosi float %55 to i32
  %58 = call float @dx.op.unary.f32(i32 22, float %52)  ; Frc(value)
  %59 = call float @dx.op.unary.f32(i32 22, float %53)  ; Frc(value)
  %60 = add i32 %44, -1
  %61 = add i32 %45, -1
  %62 = call i32 @dx.op.binary.i32(i32 37, i32 %56, i32 0)  ; IMax(a,b)
  %63 = call i32 @dx.op.binary.i32(i32 37, i32 %57, i32 0)  ; IMax(a,b)
  %64 = call i32 @dx.op.binary.i32(i32 38, i32 %62, i32 %60)  ; IMin(a,b)
  %65 = call i32 @dx.op.binary.i32(i32 38, i32 %63, i32 %61)  ; IMin(a,b)
  %66 = add i32 %56, 1
  %67 = call i32 @dx.op.binary.i32(i32 37, i32 %66, i32 0)  ; IMax(a,b)
  %68 = call i32 @dx.op.binary.i32(i32 38, i32 %67, i32 %60)  ; IMin(a,b)
  %69 = add i32 %57, 1
  %70 = call i32 @dx.op.binary.i32(i32 37, i32 %69, i32 0)  ; IMax(a,b)
  %71 = call i32 @dx.op.binary.i32(i32 38, i32 %70, i32 %61)  ; IMin(a,b)
  %72 = call float @dx.op.unary.f32(i32 27, float %50)  ; Round_ni(value)
  %73 = call float @dx.op.unary.f32(i32 27, float %51)  ; Round_ni(value)
  %74 = fptosi float %72 to i32
  %75 = fptosi float %73 to i32
  %76 = call i32 @dx.op.binary.i32(i32 37, i32 %74, i32 0)  ; IMax(a,b)
  %77 = call i32 @dx.op.binary.i32(i32 37, i32 %75, i32 0)  ; IMax(a,b)
  %78 = call i32 @dx.op.binary.i32(i32 38, i32 %76, i32 %60)  ; IMin(a,b)
  %79 = call i32 @dx.op.binary.i32(i32 38, i32 %77, i32 %61)  ; IMin(a,b)
  %80 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %78, i32 %79, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %81 = extractvalue %dx.types.ResRet.f32 %80, 0
  %82 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %64, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %83 = extractvalue %dx.types.ResRet.f32 %82, 0
  %84 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %68, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %85 = extractvalue %dx.types.ResRet.f32 %84, 0
  %86 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %64, i32 %71, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %87 = extractvalue %dx.types.ResRet.f32 %86, 0
  %88 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %68, i32 %71, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %89 = extractvalue %dx.types.ResRet.f32 %88, 0
  %90 = fsub fast float 1.000000e+00, %58
  %91 = fsub fast float 1.000000e+00, %59
  %92 = fmul fast float %91, %90
  %93 = fmul fast float %91, %58
  %94 = fmul fast float %90, %59
  %95 = fmul fast float %59, %58
  %96 = fsub fast float 1.000000e+00, %81
  %97 = fmul fast float %96, 0x3FA99999A0000000
  %98 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %97)  ; FMax(a,b)
  %99 = fsub fast float %83, %81
  %100 = call float @dx.op.unary.f32(i32 6, float %99)  ; FAbs(value)
  %101 = fdiv fast float %100, %98
  %102 = fsub fast float 1.000000e+00, %101
  %103 = call float @dx.op.unary.f32(i32 7, float %102)  ; Saturate(value)
  %104 = fsub fast float %85, %81
  %105 = call float @dx.op.unary.f32(i32 6, float %104)  ; FAbs(value)
  %106 = fdiv fast float %105, %98
  %107 = fsub fast float 1.000000e+00, %106
  %108 = call float @dx.op.unary.f32(i32 7, float %107)  ; Saturate(value)
  %109 = fsub fast float %87, %81
  %110 = call float @dx.op.unary.f32(i32 6, float %109)  ; FAbs(value)
  %111 = fdiv fast float %110, %98
  %112 = fsub fast float 1.000000e+00, %111
  %113 = call float @dx.op.unary.f32(i32 7, float %112)  ; Saturate(value)
  %114 = fsub fast float %89, %81
  %115 = call float @dx.op.unary.f32(i32 6, float %114)  ; FAbs(value)
  %116 = fdiv fast float %115, %98
  %117 = fsub fast float 1.000000e+00, %116
  %118 = call float @dx.op.unary.f32(i32 7, float %117)  ; Saturate(value)
  %119 = fmul fast float %92, %103
  %120 = fmul fast float %93, %108
  %121 = fmul fast float %94, %113
  %122 = fmul fast float %95, %118
  %123 = fcmp fast oge float %58, 5.000000e-01
  %124 = zext i1 %123 to i32
  %125 = fcmp fast oge float %59, 5.000000e-01
  %126 = select i1 %125, i32 2, i32 0
  %127 = or i32 %126, %124
  %128 = call float @dx.op.dot4.f32(i32 56, float %119, float %120, float %121, float %122, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %129 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %119)  ; IsFinite(value)
  %130 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %120)  ; IsFinite(value)
  %131 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %121)  ; IsFinite(value)
  %132 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %122)  ; IsFinite(value)
  %133 = and i1 %129, %130
  %134 = and i1 %133, %131
  %135 = and i1 %134, %132
  br i1 %135, label %136, label %153

; <label>:136                                     ; preds = %0
  %137 = fcmp fast oge float %119, 0.000000e+00
  %138 = fcmp fast oge float %120, 0.000000e+00
  %139 = fcmp fast oge float %121, 0.000000e+00
  %140 = fcmp fast oge float %122, 0.000000e+00
  %141 = and i1 %137, %138
  %142 = and i1 %141, %139
  %143 = and i1 %142, %140
  br i1 %143, label %144, label %153

; <label>:144                                     ; preds = %136
  %145 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %128)  ; IsFinite(value)
  %146 = fcmp fast oge float %128, 0x3810000000000000
  %147 = and i1 %146, %145
  br i1 %147, label %148, label %153

; <label>:148                                     ; preds = %144
  %149 = fdiv fast float %119, %128
  %150 = fdiv fast float %120, %128
  %151 = fdiv fast float %121, %128
  %152 = fdiv fast float %122, %128
  br label %162

; <label>:153                                     ; preds = %144, %136, %0
  %154 = icmp eq i32 %127, 0
  %155 = uitofp i1 %154 to float
  %156 = icmp eq i32 %127, 1
  %157 = uitofp i1 %156 to float
  %158 = icmp eq i32 %127, 2
  %159 = uitofp i1 %158 to float
  %160 = icmp eq i32 %127, 3
  %161 = uitofp i1 %160 to float
  br label %162

; <label>:162                                     ; preds = %153, %148
  %163 = phi float [ %149, %148 ], [ %155, %153 ]
  %164 = phi float [ %150, %148 ], [ %157, %153 ]
  %165 = phi float [ %151, %148 ], [ %159, %153 ]
  %166 = phi float [ %152, %148 ], [ %161, %153 ]
  %167 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %64, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %168 = extractvalue %dx.types.ResRet.f32 %167, 0
  %169 = extractvalue %dx.types.ResRet.f32 %167, 1
  %170 = extractvalue %dx.types.ResRet.f32 %167, 2
  %171 = extractvalue %dx.types.ResRet.f32 %167, 3
  %172 = fcmp fast olt float %171, 0.000000e+00
  br i1 %172, label %173, label %175

; <label>:173                                     ; preds = %162
  %174 = fsub fast float -1.000000e+00, %171
  br label %1428

; <label>:175                                     ; preds = %162
  %176 = fcmp fast ogt float %39, 5.000000e-01
  %177 = fcmp fast olt float %83, 1.000000e+00
  %178 = and i1 %176, %177
  br i1 %178, label %179, label %265

; <label>:179                                     ; preds = %175
  %180 = sitofp i32 %64 to float
  %181 = sitofp i32 %65 to float
  %182 = fadd fast float %180, 5.000000e-01
  %183 = fadd fast float %181, 5.000000e-01
  %184 = fdiv fast float %182, %46
  %185 = fdiv fast float %183, %47
  %186 = fmul fast float %184, 2.000000e+00
  %187 = fmul fast float %185, 2.000000e+00
  %188 = fadd fast float %186, -1.000000e+00
  %189 = fsub fast float 1.000000e+00, %187
  %190 = fmul fast float %188, %36
  %191 = call float @dx.op.tertiary.f32(i32 46, float %189, float %32, float %190)  ; FMad(a,b,c)
  %192 = call float @dx.op.tertiary.f32(i32 46, float %83, float %28, float %191)  ; FMad(a,b,c)
  %193 = fadd fast float %192, %24
  %194 = call float @dx.op.unary.f32(i32 6, float %193)  ; FAbs(value)
  %195 = fcmp fast ogt float %194, 0x3EB0C6F7A0000000
  br i1 %195, label %196, label %265

; <label>:196                                     ; preds = %179
  %197 = fmul fast float %188, %35
  %198 = call float @dx.op.tertiary.f32(i32 46, float %189, float %31, float %197)  ; FMad(a,b,c)
  %199 = call float @dx.op.tertiary.f32(i32 46, float %83, float %27, float %198)  ; FMad(a,b,c)
  %200 = fadd fast float %199, %23
  %201 = fmul fast float %188, %34
  %202 = call float @dx.op.tertiary.f32(i32 46, float %189, float %30, float %201)  ; FMad(a,b,c)
  %203 = call float @dx.op.tertiary.f32(i32 46, float %83, float %26, float %202)  ; FMad(a,b,c)
  %204 = fadd fast float %203, %22
  %205 = fmul fast float %188, %33
  %206 = call float @dx.op.tertiary.f32(i32 46, float %189, float %29, float %205)  ; FMad(a,b,c)
  %207 = call float @dx.op.tertiary.f32(i32 46, float %83, float %25, float %206)  ; FMad(a,b,c)
  %208 = fadd fast float %207, %21
  %209 = fdiv fast float %208, %193
  %210 = fdiv fast float %204, %193
  %211 = fdiv fast float %200, %193
  %212 = fsub fast float %209, %18
  %213 = fsub fast float %210, %19
  %214 = fsub fast float %211, %20
  %215 = fmul fast float %212, %212
  %216 = fmul fast float %213, %213
  %217 = fadd fast float %216, %215
  %218 = fmul fast float %214, %214
  %219 = fadd fast float %217, %218
  %220 = call float @dx.op.unary.f32(i32 24, float %219)  ; Sqrt(value)
  %221 = fsub fast float %220, %10
  %222 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %221)  ; FMax(a,b)
  %223 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %223, label %224, label %247

; <label>:224                                     ; preds = %196
  %225 = call float @dx.op.unary.f32(i32 6, float %213)  ; FAbs(value)
  %226 = fmul fast float %225, %12
  %227 = fcmp fast olt float %226, 0x3F50624DE0000000
  br i1 %227, label %228, label %231

; <label>:228                                     ; preds = %224
  %229 = fmul fast float %226, 5.000000e-01
  %230 = fsub fast float 1.000000e+00, %229
  br label %236

; <label>:231                                     ; preds = %224
  %232 = fmul fast float %226, 0xBFF7154760000000
  %233 = call float @dx.op.unary.f32(i32 21, float %232)  ; Exp(value)
  %234 = fsub fast float 1.000000e+00, %233
  %235 = fdiv fast float %234, %226
  br label %236

; <label>:236                                     ; preds = %231, %228
  %237 = phi float [ %230, %228 ], [ %235, %231 ]
  %238 = call float @dx.op.binary.f32(i32 36, float %210, float %19)  ; FMin(a,b)
  %239 = fsub fast float %238, %11
  %240 = fmul fast float %12, %239
  %241 = fsub fast float -0.000000e+00, %240
  %242 = call float @dx.op.binary.f32(i32 35, float %241, float -4.000000e+01)  ; FMax(a,b)
  %243 = call float @dx.op.binary.f32(i32 36, float %242, float 5.000000e+00)  ; FMin(a,b)
  %244 = fmul fast float %243, 0x3FF7154760000000
  %245 = call float @dx.op.unary.f32(i32 21, float %244)  ; Exp(value)
  %246 = fmul fast float %245, %237
  br label %247

; <label>:247                                     ; preds = %236, %196
  %248 = phi float [ %246, %236 ], [ 1.000000e+00, %196 ]
  %249 = fmul fast float %222, %17
  %250 = fmul fast float %249, %248
  %251 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %250)  ; FMin(a,b)
  %252 = fmul fast float %251, 0xBFF7154760000000
  %253 = call float @dx.op.unary.f32(i32 21, float %252)  ; Exp(value)
  %254 = fsub fast float 1.000000e+00, %253
  %255 = call float @dx.op.binary.f32(i32 36, float %13, float %254)  ; FMin(a,b)
  %256 = fsub fast float %14, %168
  %257 = fsub fast float %15, %169
  %258 = fsub fast float %16, %170
  %259 = fmul fast float %255, %256
  %260 = fmul fast float %255, %257
  %261 = fmul fast float %255, %258
  %262 = fadd fast float %259, %168
  %263 = fadd fast float %260, %169
  %264 = fadd fast float %261, %170
  br label %265

; <label>:265                                     ; preds = %247, %179, %175
  %266 = phi float [ %262, %247 ], [ %168, %179 ], [ %168, %175 ]
  %267 = phi float [ %263, %247 ], [ %169, %179 ], [ %169, %175 ]
  %268 = phi float [ %264, %247 ], [ %170, %179 ], [ %170, %175 ]
  %269 = fadd fast float %6, 1.000000e+00
  %270 = fadd fast float %7, 1.000000e+00
  %271 = fsub fast float 1.000000e+00, %6
  %272 = fmul fast float %37, %269
  %273 = fmul fast float %37, %270
  %274 = fmul fast float %37, %271
  %275 = fmul fast float %272, %266
  %276 = fmul fast float %273, %267
  %277 = fmul fast float %274, %268
  %278 = fcmp fast ult float %38, 5.000000e-01
  br i1 %278, label %304, label %279

; <label>:279                                     ; preds = %265
  %280 = fmul fast float %275, 0x4004147AE0000000
  %281 = fmul fast float %276, 0x4004147AE0000000
  %282 = fmul fast float %277, 0x4004147AE0000000
  %283 = fadd fast float %280, 0x3F9EB851E0000000
  %284 = fadd fast float %281, 0x3F9EB851E0000000
  %285 = fadd fast float %282, 0x3F9EB851E0000000
  %286 = fmul fast float %283, %275
  %287 = fmul fast float %284, %276
  %288 = fmul fast float %285, %277
  %289 = fmul fast float %275, 0x400370A3E0000000
  %290 = fmul fast float %276, 0x400370A3E0000000
  %291 = fmul fast float %277, 0x400370A3E0000000
  %292 = fadd fast float %289, 0x3FE2E147A0000000
  %293 = fadd fast float %290, 0x3FE2E147A0000000
  %294 = fadd fast float %291, 0x3FE2E147A0000000
  %295 = fmul fast float %292, %275
  %296 = fmul fast float %293, %276
  %297 = fmul fast float %294, %277
  %298 = fadd fast float %295, 0x3FC1EB8520000000
  %299 = fadd fast float %296, 0x3FC1EB8520000000
  %300 = fadd fast float %297, 0x3FC1EB8520000000
  %301 = fdiv fast float %286, %298
  %302 = fdiv fast float %287, %299
  %303 = fdiv fast float %288, %300
  br label %304

; <label>:304                                     ; preds = %279, %265
  %305 = phi float [ %301, %279 ], [ %275, %265 ]
  %306 = phi float [ %302, %279 ], [ %276, %265 ]
  %307 = phi float [ %303, %279 ], [ %277, %265 ]
  %308 = call float @dx.op.unary.f32(i32 7, float %305)  ; Saturate(value)
  %309 = call float @dx.op.unary.f32(i32 7, float %306)  ; Saturate(value)
  %310 = call float @dx.op.unary.f32(i32 7, float %307)  ; Saturate(value)
  %311 = call float @dx.op.dot3.f32(i32 55, float %308, float %309, float %310, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %312 = fsub fast float %308, %311
  %313 = fsub fast float %309, %311
  %314 = fsub fast float %310, %311
  %315 = fmul fast float %312, %9
  %316 = fmul fast float %313, %9
  %317 = fmul fast float %314, %9
  %318 = fadd fast float %315, %311
  %319 = fadd fast float %316, %311
  %320 = fadd fast float %317, %311
  %321 = call float @dx.op.unary.f32(i32 7, float %318)  ; Saturate(value)
  %322 = call float @dx.op.unary.f32(i32 7, float %319)  ; Saturate(value)
  %323 = call float @dx.op.unary.f32(i32 7, float %320)  ; Saturate(value)
  %324 = fadd fast float %321, 0xBFC70A3D80000000
  %325 = fadd fast float %322, 0xBFC70A3D80000000
  %326 = fadd fast float %323, 0xBFC70A3D80000000
  %327 = fmul fast float %324, %8
  %328 = fmul fast float %325, %8
  %329 = fmul fast float %326, %8
  %330 = fadd fast float %327, 0x3FC70A3D80000000
  %331 = fadd fast float %328, 0x3FC70A3D80000000
  %332 = fadd fast float %329, 0x3FC70A3D80000000
  %333 = call float @dx.op.unary.f32(i32 7, float %330)  ; Saturate(value)
  %334 = call float @dx.op.unary.f32(i32 7, float %331)  ; Saturate(value)
  %335 = call float @dx.op.unary.f32(i32 7, float %332)  ; Saturate(value)
  %336 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %336, label %337, label %1388

; <label>:337                                     ; preds = %304
  %338 = add i32 %65, -1
  %339 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %340 = call i32 @dx.op.binary.i32(i32 37, i32 %338, i32 0)  ; IMax(a,b)
  %341 = call i32 @dx.op.binary.i32(i32 38, i32 %339, i32 %60)  ; IMin(a,b)
  %342 = call i32 @dx.op.binary.i32(i32 38, i32 %340, i32 %61)  ; IMin(a,b)
  %343 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %341, i32 %342, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %344 = extractvalue %dx.types.ResRet.f32 %343, 0
  %345 = fsub fast float 1.000000e+00, %83
  %346 = fmul fast float %345, 0x3FA99999A0000000
  %347 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %346)  ; FMax(a,b)
  %348 = fsub fast float %344, %83
  %349 = call float @dx.op.unary.f32(i32 6, float %348)  ; FAbs(value)
  %350 = fdiv fast float %349, %347
  %351 = fsub fast float 1.000000e+00, %350
  %352 = call float @dx.op.unary.f32(i32 7, float %351)  ; Saturate(value)
  %353 = fcmp fast ugt float %352, 0.000000e+00
  br i1 %353, label %354, label %575

; <label>:354                                     ; preds = %337
  %355 = call i32 @dx.op.binary.i32(i32 37, i32 %341, i32 0)  ; IMax(a,b)
  %356 = call i32 @dx.op.binary.i32(i32 37, i32 %342, i32 0)  ; IMax(a,b)
  %357 = call i32 @dx.op.binary.i32(i32 38, i32 %355, i32 %60)  ; IMin(a,b)
  %358 = call i32 @dx.op.binary.i32(i32 38, i32 %356, i32 %61)  ; IMin(a,b)
  %359 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %357, i32 %358, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %360 = extractvalue %dx.types.ResRet.f32 %359, 0
  %361 = extractvalue %dx.types.ResRet.f32 %359, 1
  %362 = extractvalue %dx.types.ResRet.f32 %359, 2
  %363 = extractvalue %dx.types.ResRet.f32 %359, 3
  %364 = fcmp fast olt float %363, 0.000000e+00
  br i1 %364, label %365, label %399

; <label>:365                                     ; preds = %354
  %366 = fcmp fast ogt float %360, 0x3FA4B5DCC0000000
  %367 = fcmp fast ogt float %361, 0x3FA4B5DCC0000000
  %368 = fcmp fast ogt float %362, 0x3FA4B5DCC0000000
  %369 = select i1 %366, float 0.000000e+00, float 1.000000e+00
  %370 = select i1 %367, float 0.000000e+00, float 1.000000e+00
  %371 = select i1 %368, float 0.000000e+00, float 1.000000e+00
  %372 = fmul fast float %360, 0x3FB3D07220000000
  %373 = fmul fast float %361, 0x3FB3D07220000000
  %374 = fmul fast float %362, 0x3FB3D07220000000
  %375 = fadd fast float %360, 0x3FAC28F5C0000000
  %376 = fadd fast float %361, 0x3FAC28F5C0000000
  %377 = fadd fast float %362, 0x3FAC28F5C0000000
  %378 = fmul fast float %375, 0x3FEE54EDE0000000
  %379 = fmul fast float %376, 0x3FEE54EDE0000000
  %380 = fmul fast float %377, 0x3FEE54EDE0000000
  %381 = call float @dx.op.unary.f32(i32 23, float %378)  ; Log(value)
  %382 = call float @dx.op.unary.f32(i32 23, float %379)  ; Log(value)
  %383 = call float @dx.op.unary.f32(i32 23, float %380)  ; Log(value)
  %384 = fmul fast float %381, 0x4003333340000000
  %385 = fmul fast float %382, 0x4003333340000000
  %386 = fmul fast float %383, 0x4003333340000000
  %387 = call float @dx.op.unary.f32(i32 21, float %384)  ; Exp(value)
  %388 = call float @dx.op.unary.f32(i32 21, float %385)  ; Exp(value)
  %389 = call float @dx.op.unary.f32(i32 21, float %386)  ; Exp(value)
  %390 = fsub fast float %372, %387
  %391 = fsub fast float %373, %388
  %392 = fsub fast float %374, %389
  %393 = fmul fast float %390, %369
  %394 = fmul fast float %391, %370
  %395 = fmul fast float %392, %371
  %396 = fadd fast float %393, %387
  %397 = fadd fast float %394, %388
  %398 = fadd fast float %395, %389
  br label %562

; <label>:399                                     ; preds = %354
  %400 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %357, i32 %358, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %401 = extractvalue %dx.types.ResRet.f32 %400, 0
  %402 = fcmp fast ogt float %39, 5.000000e-01
  %403 = fcmp fast olt float %401, 1.000000e+00
  %404 = and i1 %402, %403
  br i1 %404, label %405, label %491

; <label>:405                                     ; preds = %399
  %406 = sitofp i32 %357 to float
  %407 = sitofp i32 %358 to float
  %408 = fadd fast float %406, 5.000000e-01
  %409 = fadd fast float %407, 5.000000e-01
  %410 = fdiv fast float %408, %46
  %411 = fdiv fast float %409, %47
  %412 = fmul fast float %410, 2.000000e+00
  %413 = fmul fast float %411, 2.000000e+00
  %414 = fadd fast float %412, -1.000000e+00
  %415 = fsub fast float 1.000000e+00, %413
  %416 = fmul fast float %414, %36
  %417 = call float @dx.op.tertiary.f32(i32 46, float %415, float %32, float %416)  ; FMad(a,b,c)
  %418 = call float @dx.op.tertiary.f32(i32 46, float %401, float %28, float %417)  ; FMad(a,b,c)
  %419 = fadd fast float %418, %24
  %420 = call float @dx.op.unary.f32(i32 6, float %419)  ; FAbs(value)
  %421 = fcmp fast ogt float %420, 0x3EB0C6F7A0000000
  br i1 %421, label %422, label %491

; <label>:422                                     ; preds = %405
  %423 = fmul fast float %414, %35
  %424 = call float @dx.op.tertiary.f32(i32 46, float %415, float %31, float %423)  ; FMad(a,b,c)
  %425 = call float @dx.op.tertiary.f32(i32 46, float %401, float %27, float %424)  ; FMad(a,b,c)
  %426 = fadd fast float %425, %23
  %427 = fmul fast float %414, %34
  %428 = call float @dx.op.tertiary.f32(i32 46, float %415, float %30, float %427)  ; FMad(a,b,c)
  %429 = call float @dx.op.tertiary.f32(i32 46, float %401, float %26, float %428)  ; FMad(a,b,c)
  %430 = fadd fast float %429, %22
  %431 = fmul fast float %414, %33
  %432 = call float @dx.op.tertiary.f32(i32 46, float %415, float %29, float %431)  ; FMad(a,b,c)
  %433 = call float @dx.op.tertiary.f32(i32 46, float %401, float %25, float %432)  ; FMad(a,b,c)
  %434 = fadd fast float %433, %21
  %435 = fdiv fast float %434, %419
  %436 = fdiv fast float %430, %419
  %437 = fdiv fast float %426, %419
  %438 = fsub fast float %435, %18
  %439 = fsub fast float %436, %19
  %440 = fsub fast float %437, %20
  %441 = fmul fast float %438, %438
  %442 = fmul fast float %439, %439
  %443 = fadd fast float %442, %441
  %444 = fmul fast float %440, %440
  %445 = fadd fast float %443, %444
  %446 = call float @dx.op.unary.f32(i32 24, float %445)  ; Sqrt(value)
  %447 = fsub fast float %446, %10
  %448 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %447)  ; FMax(a,b)
  %449 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %449, label %450, label %473

; <label>:450                                     ; preds = %422
  %451 = call float @dx.op.unary.f32(i32 6, float %439)  ; FAbs(value)
  %452 = fmul fast float %451, %12
  %453 = fcmp fast olt float %452, 0x3F50624DE0000000
  br i1 %453, label %454, label %457

; <label>:454                                     ; preds = %450
  %455 = fmul fast float %452, 5.000000e-01
  %456 = fsub fast float 1.000000e+00, %455
  br label %462

; <label>:457                                     ; preds = %450
  %458 = fmul fast float %452, 0xBFF7154760000000
  %459 = call float @dx.op.unary.f32(i32 21, float %458)  ; Exp(value)
  %460 = fsub fast float 1.000000e+00, %459
  %461 = fdiv fast float %460, %452
  br label %462

; <label>:462                                     ; preds = %457, %454
  %463 = phi float [ %456, %454 ], [ %461, %457 ]
  %464 = call float @dx.op.binary.f32(i32 36, float %436, float %19)  ; FMin(a,b)
  %465 = fsub fast float %464, %11
  %466 = fmul fast float %12, %465
  %467 = fsub fast float -0.000000e+00, %466
  %468 = call float @dx.op.binary.f32(i32 35, float %467, float -4.000000e+01)  ; FMax(a,b)
  %469 = call float @dx.op.binary.f32(i32 36, float %468, float 5.000000e+00)  ; FMin(a,b)
  %470 = fmul fast float %469, 0x3FF7154760000000
  %471 = call float @dx.op.unary.f32(i32 21, float %470)  ; Exp(value)
  %472 = fmul fast float %471, %463
  br label %473

; <label>:473                                     ; preds = %462, %422
  %474 = phi float [ %472, %462 ], [ 1.000000e+00, %422 ]
  %475 = fmul fast float %448, %17
  %476 = fmul fast float %475, %474
  %477 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %476)  ; FMin(a,b)
  %478 = fmul fast float %477, 0xBFF7154760000000
  %479 = call float @dx.op.unary.f32(i32 21, float %478)  ; Exp(value)
  %480 = fsub fast float 1.000000e+00, %479
  %481 = call float @dx.op.binary.f32(i32 36, float %13, float %480)  ; FMin(a,b)
  %482 = fsub fast float %14, %360
  %483 = fsub fast float %15, %361
  %484 = fsub fast float %16, %362
  %485 = fmul fast float %481, %482
  %486 = fmul fast float %481, %483
  %487 = fmul fast float %481, %484
  %488 = fadd fast float %485, %360
  %489 = fadd fast float %486, %361
  %490 = fadd fast float %487, %362
  br label %491

; <label>:491                                     ; preds = %473, %405, %399
  %492 = phi float [ %488, %473 ], [ %360, %405 ], [ %360, %399 ]
  %493 = phi float [ %489, %473 ], [ %361, %405 ], [ %361, %399 ]
  %494 = phi float [ %490, %473 ], [ %362, %405 ], [ %362, %399 ]
  %495 = fadd fast float %6, 1.000000e+00
  %496 = fadd fast float %7, 1.000000e+00
  %497 = fsub fast float 1.000000e+00, %6
  %498 = fmul fast float %37, %495
  %499 = fmul fast float %37, %496
  %500 = fmul fast float %37, %497
  %501 = fmul fast float %498, %492
  %502 = fmul fast float %499, %493
  %503 = fmul fast float %500, %494
  %504 = fcmp fast ult float %38, 5.000000e-01
  br i1 %504, label %530, label %505

; <label>:505                                     ; preds = %491
  %506 = fmul fast float %501, 0x4004147AE0000000
  %507 = fmul fast float %502, 0x4004147AE0000000
  %508 = fmul fast float %503, 0x4004147AE0000000
  %509 = fadd fast float %506, 0x3F9EB851E0000000
  %510 = fadd fast float %507, 0x3F9EB851E0000000
  %511 = fadd fast float %508, 0x3F9EB851E0000000
  %512 = fmul fast float %509, %501
  %513 = fmul fast float %510, %502
  %514 = fmul fast float %511, %503
  %515 = fmul fast float %501, 0x400370A3E0000000
  %516 = fmul fast float %502, 0x400370A3E0000000
  %517 = fmul fast float %503, 0x400370A3E0000000
  %518 = fadd fast float %515, 0x3FE2E147A0000000
  %519 = fadd fast float %516, 0x3FE2E147A0000000
  %520 = fadd fast float %517, 0x3FE2E147A0000000
  %521 = fmul fast float %518, %501
  %522 = fmul fast float %519, %502
  %523 = fmul fast float %520, %503
  %524 = fadd fast float %521, 0x3FC1EB8520000000
  %525 = fadd fast float %522, 0x3FC1EB8520000000
  %526 = fadd fast float %523, 0x3FC1EB8520000000
  %527 = fdiv fast float %512, %524
  %528 = fdiv fast float %513, %525
  %529 = fdiv fast float %514, %526
  br label %530

; <label>:530                                     ; preds = %505, %491
  %531 = phi float [ %527, %505 ], [ %501, %491 ]
  %532 = phi float [ %528, %505 ], [ %502, %491 ]
  %533 = phi float [ %529, %505 ], [ %503, %491 ]
  %534 = call float @dx.op.unary.f32(i32 7, float %531)  ; Saturate(value)
  %535 = call float @dx.op.unary.f32(i32 7, float %532)  ; Saturate(value)
  %536 = call float @dx.op.unary.f32(i32 7, float %533)  ; Saturate(value)
  %537 = call float @dx.op.dot3.f32(i32 55, float %534, float %535, float %536, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %538 = fsub fast float %534, %537
  %539 = fsub fast float %535, %537
  %540 = fsub fast float %536, %537
  %541 = fmul fast float %538, %9
  %542 = fmul fast float %539, %9
  %543 = fmul fast float %540, %9
  %544 = fadd fast float %541, %537
  %545 = fadd fast float %542, %537
  %546 = fadd fast float %543, %537
  %547 = call float @dx.op.unary.f32(i32 7, float %544)  ; Saturate(value)
  %548 = call float @dx.op.unary.f32(i32 7, float %545)  ; Saturate(value)
  %549 = call float @dx.op.unary.f32(i32 7, float %546)  ; Saturate(value)
  %550 = fadd fast float %547, 0xBFC70A3D80000000
  %551 = fadd fast float %548, 0xBFC70A3D80000000
  %552 = fadd fast float %549, 0xBFC70A3D80000000
  %553 = fmul fast float %550, %8
  %554 = fmul fast float %551, %8
  %555 = fmul fast float %552, %8
  %556 = fadd fast float %553, 0x3FC70A3D80000000
  %557 = fadd fast float %554, 0x3FC70A3D80000000
  %558 = fadd fast float %555, 0x3FC70A3D80000000
  %559 = call float @dx.op.unary.f32(i32 7, float %556)  ; Saturate(value)
  %560 = call float @dx.op.unary.f32(i32 7, float %557)  ; Saturate(value)
  %561 = call float @dx.op.unary.f32(i32 7, float %558)  ; Saturate(value)
  br label %562

; <label>:562                                     ; preds = %530, %365
  %563 = phi float [ %396, %365 ], [ %559, %530 ]
  %564 = phi float [ %397, %365 ], [ %560, %530 ]
  %565 = phi float [ %398, %365 ], [ %561, %530 ]
  %566 = fsub fast float %563, %333
  %567 = fsub fast float %564, %334
  %568 = fsub fast float %565, %335
  %569 = fmul fast float %566, %352
  %570 = fmul fast float %567, %352
  %571 = fmul fast float %568, %352
  %572 = fadd fast float %569, %333
  %573 = fadd fast float %570, %334
  %574 = fadd fast float %571, %335
  br label %575

; <label>:575                                     ; preds = %562, %337
  %576 = phi float [ %572, %562 ], [ %333, %337 ]
  %577 = phi float [ %573, %562 ], [ %334, %337 ]
  %578 = phi float [ %574, %562 ], [ %335, %337 ]
  %579 = add i32 %65, 1
  %580 = call i32 @dx.op.binary.i32(i32 37, i32 %579, i32 0)  ; IMax(a,b)
  %581 = call i32 @dx.op.binary.i32(i32 38, i32 %580, i32 %61)  ; IMin(a,b)
  %582 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %341, i32 %581, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %583 = extractvalue %dx.types.ResRet.f32 %582, 0
  %584 = fsub fast float %583, %83
  %585 = call float @dx.op.unary.f32(i32 6, float %584)  ; FAbs(value)
  %586 = fdiv fast float %585, %347
  %587 = fsub fast float 1.000000e+00, %586
  %588 = call float @dx.op.unary.f32(i32 7, float %587)  ; Saturate(value)
  %589 = fcmp fast ugt float %588, 0.000000e+00
  br i1 %589, label %590, label %811

; <label>:590                                     ; preds = %575
  %591 = call i32 @dx.op.binary.i32(i32 37, i32 %341, i32 0)  ; IMax(a,b)
  %592 = call i32 @dx.op.binary.i32(i32 37, i32 %581, i32 0)  ; IMax(a,b)
  %593 = call i32 @dx.op.binary.i32(i32 38, i32 %591, i32 %60)  ; IMin(a,b)
  %594 = call i32 @dx.op.binary.i32(i32 38, i32 %592, i32 %61)  ; IMin(a,b)
  %595 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %593, i32 %594, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %596 = extractvalue %dx.types.ResRet.f32 %595, 0
  %597 = extractvalue %dx.types.ResRet.f32 %595, 1
  %598 = extractvalue %dx.types.ResRet.f32 %595, 2
  %599 = extractvalue %dx.types.ResRet.f32 %595, 3
  %600 = fcmp fast olt float %599, 0.000000e+00
  br i1 %600, label %601, label %635

; <label>:601                                     ; preds = %590
  %602 = fcmp fast ogt float %596, 0x3FA4B5DCC0000000
  %603 = fcmp fast ogt float %597, 0x3FA4B5DCC0000000
  %604 = fcmp fast ogt float %598, 0x3FA4B5DCC0000000
  %605 = select i1 %602, float 0.000000e+00, float 1.000000e+00
  %606 = select i1 %603, float 0.000000e+00, float 1.000000e+00
  %607 = select i1 %604, float 0.000000e+00, float 1.000000e+00
  %608 = fmul fast float %596, 0x3FB3D07220000000
  %609 = fmul fast float %597, 0x3FB3D07220000000
  %610 = fmul fast float %598, 0x3FB3D07220000000
  %611 = fadd fast float %596, 0x3FAC28F5C0000000
  %612 = fadd fast float %597, 0x3FAC28F5C0000000
  %613 = fadd fast float %598, 0x3FAC28F5C0000000
  %614 = fmul fast float %611, 0x3FEE54EDE0000000
  %615 = fmul fast float %612, 0x3FEE54EDE0000000
  %616 = fmul fast float %613, 0x3FEE54EDE0000000
  %617 = call float @dx.op.unary.f32(i32 23, float %614)  ; Log(value)
  %618 = call float @dx.op.unary.f32(i32 23, float %615)  ; Log(value)
  %619 = call float @dx.op.unary.f32(i32 23, float %616)  ; Log(value)
  %620 = fmul fast float %617, 0x4003333340000000
  %621 = fmul fast float %618, 0x4003333340000000
  %622 = fmul fast float %619, 0x4003333340000000
  %623 = call float @dx.op.unary.f32(i32 21, float %620)  ; Exp(value)
  %624 = call float @dx.op.unary.f32(i32 21, float %621)  ; Exp(value)
  %625 = call float @dx.op.unary.f32(i32 21, float %622)  ; Exp(value)
  %626 = fsub fast float %608, %623
  %627 = fsub fast float %609, %624
  %628 = fsub fast float %610, %625
  %629 = fmul fast float %626, %605
  %630 = fmul fast float %627, %606
  %631 = fmul fast float %628, %607
  %632 = fadd fast float %629, %623
  %633 = fadd fast float %630, %624
  %634 = fadd fast float %631, %625
  br label %798

; <label>:635                                     ; preds = %590
  %636 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %593, i32 %594, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %637 = extractvalue %dx.types.ResRet.f32 %636, 0
  %638 = fcmp fast ogt float %39, 5.000000e-01
  %639 = fcmp fast olt float %637, 1.000000e+00
  %640 = and i1 %638, %639
  br i1 %640, label %641, label %727

; <label>:641                                     ; preds = %635
  %642 = sitofp i32 %593 to float
  %643 = sitofp i32 %594 to float
  %644 = fadd fast float %642, 5.000000e-01
  %645 = fadd fast float %643, 5.000000e-01
  %646 = fdiv fast float %644, %46
  %647 = fdiv fast float %645, %47
  %648 = fmul fast float %646, 2.000000e+00
  %649 = fmul fast float %647, 2.000000e+00
  %650 = fadd fast float %648, -1.000000e+00
  %651 = fsub fast float 1.000000e+00, %649
  %652 = fmul fast float %650, %36
  %653 = call float @dx.op.tertiary.f32(i32 46, float %651, float %32, float %652)  ; FMad(a,b,c)
  %654 = call float @dx.op.tertiary.f32(i32 46, float %637, float %28, float %653)  ; FMad(a,b,c)
  %655 = fadd fast float %654, %24
  %656 = call float @dx.op.unary.f32(i32 6, float %655)  ; FAbs(value)
  %657 = fcmp fast ogt float %656, 0x3EB0C6F7A0000000
  br i1 %657, label %658, label %727

; <label>:658                                     ; preds = %641
  %659 = fmul fast float %650, %35
  %660 = call float @dx.op.tertiary.f32(i32 46, float %651, float %31, float %659)  ; FMad(a,b,c)
  %661 = call float @dx.op.tertiary.f32(i32 46, float %637, float %27, float %660)  ; FMad(a,b,c)
  %662 = fadd fast float %661, %23
  %663 = fmul fast float %650, %34
  %664 = call float @dx.op.tertiary.f32(i32 46, float %651, float %30, float %663)  ; FMad(a,b,c)
  %665 = call float @dx.op.tertiary.f32(i32 46, float %637, float %26, float %664)  ; FMad(a,b,c)
  %666 = fadd fast float %665, %22
  %667 = fmul fast float %650, %33
  %668 = call float @dx.op.tertiary.f32(i32 46, float %651, float %29, float %667)  ; FMad(a,b,c)
  %669 = call float @dx.op.tertiary.f32(i32 46, float %637, float %25, float %668)  ; FMad(a,b,c)
  %670 = fadd fast float %669, %21
  %671 = fdiv fast float %670, %655
  %672 = fdiv fast float %666, %655
  %673 = fdiv fast float %662, %655
  %674 = fsub fast float %671, %18
  %675 = fsub fast float %672, %19
  %676 = fsub fast float %673, %20
  %677 = fmul fast float %674, %674
  %678 = fmul fast float %675, %675
  %679 = fadd fast float %678, %677
  %680 = fmul fast float %676, %676
  %681 = fadd fast float %679, %680
  %682 = call float @dx.op.unary.f32(i32 24, float %681)  ; Sqrt(value)
  %683 = fsub fast float %682, %10
  %684 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %683)  ; FMax(a,b)
  %685 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %685, label %686, label %709

; <label>:686                                     ; preds = %658
  %687 = call float @dx.op.unary.f32(i32 6, float %675)  ; FAbs(value)
  %688 = fmul fast float %687, %12
  %689 = fcmp fast olt float %688, 0x3F50624DE0000000
  br i1 %689, label %690, label %693

; <label>:690                                     ; preds = %686
  %691 = fmul fast float %688, 5.000000e-01
  %692 = fsub fast float 1.000000e+00, %691
  br label %698

; <label>:693                                     ; preds = %686
  %694 = fmul fast float %688, 0xBFF7154760000000
  %695 = call float @dx.op.unary.f32(i32 21, float %694)  ; Exp(value)
  %696 = fsub fast float 1.000000e+00, %695
  %697 = fdiv fast float %696, %688
  br label %698

; <label>:698                                     ; preds = %693, %690
  %699 = phi float [ %692, %690 ], [ %697, %693 ]
  %700 = call float @dx.op.binary.f32(i32 36, float %672, float %19)  ; FMin(a,b)
  %701 = fsub fast float %700, %11
  %702 = fmul fast float %12, %701
  %703 = fsub fast float -0.000000e+00, %702
  %704 = call float @dx.op.binary.f32(i32 35, float %703, float -4.000000e+01)  ; FMax(a,b)
  %705 = call float @dx.op.binary.f32(i32 36, float %704, float 5.000000e+00)  ; FMin(a,b)
  %706 = fmul fast float %705, 0x3FF7154760000000
  %707 = call float @dx.op.unary.f32(i32 21, float %706)  ; Exp(value)
  %708 = fmul fast float %707, %699
  br label %709

; <label>:709                                     ; preds = %698, %658
  %710 = phi float [ %708, %698 ], [ 1.000000e+00, %658 ]
  %711 = fmul fast float %684, %17
  %712 = fmul fast float %711, %710
  %713 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %712)  ; FMin(a,b)
  %714 = fmul fast float %713, 0xBFF7154760000000
  %715 = call float @dx.op.unary.f32(i32 21, float %714)  ; Exp(value)
  %716 = fsub fast float 1.000000e+00, %715
  %717 = call float @dx.op.binary.f32(i32 36, float %13, float %716)  ; FMin(a,b)
  %718 = fsub fast float %14, %596
  %719 = fsub fast float %15, %597
  %720 = fsub fast float %16, %598
  %721 = fmul fast float %717, %718
  %722 = fmul fast float %717, %719
  %723 = fmul fast float %717, %720
  %724 = fadd fast float %721, %596
  %725 = fadd fast float %722, %597
  %726 = fadd fast float %723, %598
  br label %727

; <label>:727                                     ; preds = %709, %641, %635
  %728 = phi float [ %724, %709 ], [ %596, %641 ], [ %596, %635 ]
  %729 = phi float [ %725, %709 ], [ %597, %641 ], [ %597, %635 ]
  %730 = phi float [ %726, %709 ], [ %598, %641 ], [ %598, %635 ]
  %731 = fadd fast float %6, 1.000000e+00
  %732 = fadd fast float %7, 1.000000e+00
  %733 = fsub fast float 1.000000e+00, %6
  %734 = fmul fast float %37, %731
  %735 = fmul fast float %37, %732
  %736 = fmul fast float %37, %733
  %737 = fmul fast float %734, %728
  %738 = fmul fast float %735, %729
  %739 = fmul fast float %736, %730
  %740 = fcmp fast ult float %38, 5.000000e-01
  br i1 %740, label %766, label %741

; <label>:741                                     ; preds = %727
  %742 = fmul fast float %737, 0x4004147AE0000000
  %743 = fmul fast float %738, 0x4004147AE0000000
  %744 = fmul fast float %739, 0x4004147AE0000000
  %745 = fadd fast float %742, 0x3F9EB851E0000000
  %746 = fadd fast float %743, 0x3F9EB851E0000000
  %747 = fadd fast float %744, 0x3F9EB851E0000000
  %748 = fmul fast float %745, %737
  %749 = fmul fast float %746, %738
  %750 = fmul fast float %747, %739
  %751 = fmul fast float %737, 0x400370A3E0000000
  %752 = fmul fast float %738, 0x400370A3E0000000
  %753 = fmul fast float %739, 0x400370A3E0000000
  %754 = fadd fast float %751, 0x3FE2E147A0000000
  %755 = fadd fast float %752, 0x3FE2E147A0000000
  %756 = fadd fast float %753, 0x3FE2E147A0000000
  %757 = fmul fast float %754, %737
  %758 = fmul fast float %755, %738
  %759 = fmul fast float %756, %739
  %760 = fadd fast float %757, 0x3FC1EB8520000000
  %761 = fadd fast float %758, 0x3FC1EB8520000000
  %762 = fadd fast float %759, 0x3FC1EB8520000000
  %763 = fdiv fast float %748, %760
  %764 = fdiv fast float %749, %761
  %765 = fdiv fast float %750, %762
  br label %766

; <label>:766                                     ; preds = %741, %727
  %767 = phi float [ %763, %741 ], [ %737, %727 ]
  %768 = phi float [ %764, %741 ], [ %738, %727 ]
  %769 = phi float [ %765, %741 ], [ %739, %727 ]
  %770 = call float @dx.op.unary.f32(i32 7, float %767)  ; Saturate(value)
  %771 = call float @dx.op.unary.f32(i32 7, float %768)  ; Saturate(value)
  %772 = call float @dx.op.unary.f32(i32 7, float %769)  ; Saturate(value)
  %773 = call float @dx.op.dot3.f32(i32 55, float %770, float %771, float %772, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %774 = fsub fast float %770, %773
  %775 = fsub fast float %771, %773
  %776 = fsub fast float %772, %773
  %777 = fmul fast float %774, %9
  %778 = fmul fast float %775, %9
  %779 = fmul fast float %776, %9
  %780 = fadd fast float %777, %773
  %781 = fadd fast float %778, %773
  %782 = fadd fast float %779, %773
  %783 = call float @dx.op.unary.f32(i32 7, float %780)  ; Saturate(value)
  %784 = call float @dx.op.unary.f32(i32 7, float %781)  ; Saturate(value)
  %785 = call float @dx.op.unary.f32(i32 7, float %782)  ; Saturate(value)
  %786 = fadd fast float %783, 0xBFC70A3D80000000
  %787 = fadd fast float %784, 0xBFC70A3D80000000
  %788 = fadd fast float %785, 0xBFC70A3D80000000
  %789 = fmul fast float %786, %8
  %790 = fmul fast float %787, %8
  %791 = fmul fast float %788, %8
  %792 = fadd fast float %789, 0x3FC70A3D80000000
  %793 = fadd fast float %790, 0x3FC70A3D80000000
  %794 = fadd fast float %791, 0x3FC70A3D80000000
  %795 = call float @dx.op.unary.f32(i32 7, float %792)  ; Saturate(value)
  %796 = call float @dx.op.unary.f32(i32 7, float %793)  ; Saturate(value)
  %797 = call float @dx.op.unary.f32(i32 7, float %794)  ; Saturate(value)
  br label %798

; <label>:798                                     ; preds = %766, %601
  %799 = phi float [ %632, %601 ], [ %795, %766 ]
  %800 = phi float [ %633, %601 ], [ %796, %766 ]
  %801 = phi float [ %634, %601 ], [ %797, %766 ]
  %802 = fsub fast float %799, %333
  %803 = fsub fast float %800, %334
  %804 = fsub fast float %801, %335
  %805 = fmul fast float %802, %588
  %806 = fmul fast float %803, %588
  %807 = fmul fast float %804, %588
  %808 = fadd fast float %805, %333
  %809 = fadd fast float %806, %334
  %810 = fadd fast float %807, %335
  br label %811

; <label>:811                                     ; preds = %798, %575
  %812 = phi float [ %808, %798 ], [ %333, %575 ]
  %813 = phi float [ %809, %798 ], [ %334, %575 ]
  %814 = phi float [ %810, %798 ], [ %335, %575 ]
  %815 = add i32 %64, -1
  %816 = call i32 @dx.op.binary.i32(i32 37, i32 %815, i32 0)  ; IMax(a,b)
  %817 = call i32 @dx.op.binary.i32(i32 37, i32 %65, i32 0)  ; IMax(a,b)
  %818 = call i32 @dx.op.binary.i32(i32 38, i32 %816, i32 %60)  ; IMin(a,b)
  %819 = call i32 @dx.op.binary.i32(i32 38, i32 %817, i32 %61)  ; IMin(a,b)
  %820 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %818, i32 %819, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %821 = extractvalue %dx.types.ResRet.f32 %820, 0
  %822 = fsub fast float %821, %83
  %823 = call float @dx.op.unary.f32(i32 6, float %822)  ; FAbs(value)
  %824 = fdiv fast float %823, %347
  %825 = fsub fast float 1.000000e+00, %824
  %826 = call float @dx.op.unary.f32(i32 7, float %825)  ; Saturate(value)
  %827 = fcmp fast ugt float %826, 0.000000e+00
  br i1 %827, label %828, label %1049

; <label>:828                                     ; preds = %811
  %829 = call i32 @dx.op.binary.i32(i32 37, i32 %818, i32 0)  ; IMax(a,b)
  %830 = call i32 @dx.op.binary.i32(i32 37, i32 %819, i32 0)  ; IMax(a,b)
  %831 = call i32 @dx.op.binary.i32(i32 38, i32 %829, i32 %60)  ; IMin(a,b)
  %832 = call i32 @dx.op.binary.i32(i32 38, i32 %830, i32 %61)  ; IMin(a,b)
  %833 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %831, i32 %832, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %834 = extractvalue %dx.types.ResRet.f32 %833, 0
  %835 = extractvalue %dx.types.ResRet.f32 %833, 1
  %836 = extractvalue %dx.types.ResRet.f32 %833, 2
  %837 = extractvalue %dx.types.ResRet.f32 %833, 3
  %838 = fcmp fast olt float %837, 0.000000e+00
  br i1 %838, label %839, label %873

; <label>:839                                     ; preds = %828
  %840 = fcmp fast ogt float %834, 0x3FA4B5DCC0000000
  %841 = fcmp fast ogt float %835, 0x3FA4B5DCC0000000
  %842 = fcmp fast ogt float %836, 0x3FA4B5DCC0000000
  %843 = select i1 %840, float 0.000000e+00, float 1.000000e+00
  %844 = select i1 %841, float 0.000000e+00, float 1.000000e+00
  %845 = select i1 %842, float 0.000000e+00, float 1.000000e+00
  %846 = fmul fast float %834, 0x3FB3D07220000000
  %847 = fmul fast float %835, 0x3FB3D07220000000
  %848 = fmul fast float %836, 0x3FB3D07220000000
  %849 = fadd fast float %834, 0x3FAC28F5C0000000
  %850 = fadd fast float %835, 0x3FAC28F5C0000000
  %851 = fadd fast float %836, 0x3FAC28F5C0000000
  %852 = fmul fast float %849, 0x3FEE54EDE0000000
  %853 = fmul fast float %850, 0x3FEE54EDE0000000
  %854 = fmul fast float %851, 0x3FEE54EDE0000000
  %855 = call float @dx.op.unary.f32(i32 23, float %852)  ; Log(value)
  %856 = call float @dx.op.unary.f32(i32 23, float %853)  ; Log(value)
  %857 = call float @dx.op.unary.f32(i32 23, float %854)  ; Log(value)
  %858 = fmul fast float %855, 0x4003333340000000
  %859 = fmul fast float %856, 0x4003333340000000
  %860 = fmul fast float %857, 0x4003333340000000
  %861 = call float @dx.op.unary.f32(i32 21, float %858)  ; Exp(value)
  %862 = call float @dx.op.unary.f32(i32 21, float %859)  ; Exp(value)
  %863 = call float @dx.op.unary.f32(i32 21, float %860)  ; Exp(value)
  %864 = fsub fast float %846, %861
  %865 = fsub fast float %847, %862
  %866 = fsub fast float %848, %863
  %867 = fmul fast float %864, %843
  %868 = fmul fast float %865, %844
  %869 = fmul fast float %866, %845
  %870 = fadd fast float %867, %861
  %871 = fadd fast float %868, %862
  %872 = fadd fast float %869, %863
  br label %1036

; <label>:873                                     ; preds = %828
  %874 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %831, i32 %832, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %875 = extractvalue %dx.types.ResRet.f32 %874, 0
  %876 = fcmp fast ogt float %39, 5.000000e-01
  %877 = fcmp fast olt float %875, 1.000000e+00
  %878 = and i1 %876, %877
  br i1 %878, label %879, label %965

; <label>:879                                     ; preds = %873
  %880 = sitofp i32 %831 to float
  %881 = sitofp i32 %832 to float
  %882 = fadd fast float %880, 5.000000e-01
  %883 = fadd fast float %881, 5.000000e-01
  %884 = fdiv fast float %882, %46
  %885 = fdiv fast float %883, %47
  %886 = fmul fast float %884, 2.000000e+00
  %887 = fmul fast float %885, 2.000000e+00
  %888 = fadd fast float %886, -1.000000e+00
  %889 = fsub fast float 1.000000e+00, %887
  %890 = fmul fast float %888, %36
  %891 = call float @dx.op.tertiary.f32(i32 46, float %889, float %32, float %890)  ; FMad(a,b,c)
  %892 = call float @dx.op.tertiary.f32(i32 46, float %875, float %28, float %891)  ; FMad(a,b,c)
  %893 = fadd fast float %892, %24
  %894 = call float @dx.op.unary.f32(i32 6, float %893)  ; FAbs(value)
  %895 = fcmp fast ogt float %894, 0x3EB0C6F7A0000000
  br i1 %895, label %896, label %965

; <label>:896                                     ; preds = %879
  %897 = fmul fast float %888, %35
  %898 = call float @dx.op.tertiary.f32(i32 46, float %889, float %31, float %897)  ; FMad(a,b,c)
  %899 = call float @dx.op.tertiary.f32(i32 46, float %875, float %27, float %898)  ; FMad(a,b,c)
  %900 = fadd fast float %899, %23
  %901 = fmul fast float %888, %34
  %902 = call float @dx.op.tertiary.f32(i32 46, float %889, float %30, float %901)  ; FMad(a,b,c)
  %903 = call float @dx.op.tertiary.f32(i32 46, float %875, float %26, float %902)  ; FMad(a,b,c)
  %904 = fadd fast float %903, %22
  %905 = fmul fast float %888, %33
  %906 = call float @dx.op.tertiary.f32(i32 46, float %889, float %29, float %905)  ; FMad(a,b,c)
  %907 = call float @dx.op.tertiary.f32(i32 46, float %875, float %25, float %906)  ; FMad(a,b,c)
  %908 = fadd fast float %907, %21
  %909 = fdiv fast float %908, %893
  %910 = fdiv fast float %904, %893
  %911 = fdiv fast float %900, %893
  %912 = fsub fast float %909, %18
  %913 = fsub fast float %910, %19
  %914 = fsub fast float %911, %20
  %915 = fmul fast float %912, %912
  %916 = fmul fast float %913, %913
  %917 = fadd fast float %916, %915
  %918 = fmul fast float %914, %914
  %919 = fadd fast float %917, %918
  %920 = call float @dx.op.unary.f32(i32 24, float %919)  ; Sqrt(value)
  %921 = fsub fast float %920, %10
  %922 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %921)  ; FMax(a,b)
  %923 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %923, label %924, label %947

; <label>:924                                     ; preds = %896
  %925 = call float @dx.op.unary.f32(i32 6, float %913)  ; FAbs(value)
  %926 = fmul fast float %925, %12
  %927 = fcmp fast olt float %926, 0x3F50624DE0000000
  br i1 %927, label %928, label %931

; <label>:928                                     ; preds = %924
  %929 = fmul fast float %926, 5.000000e-01
  %930 = fsub fast float 1.000000e+00, %929
  br label %936

; <label>:931                                     ; preds = %924
  %932 = fmul fast float %926, 0xBFF7154760000000
  %933 = call float @dx.op.unary.f32(i32 21, float %932)  ; Exp(value)
  %934 = fsub fast float 1.000000e+00, %933
  %935 = fdiv fast float %934, %926
  br label %936

; <label>:936                                     ; preds = %931, %928
  %937 = phi float [ %930, %928 ], [ %935, %931 ]
  %938 = call float @dx.op.binary.f32(i32 36, float %910, float %19)  ; FMin(a,b)
  %939 = fsub fast float %938, %11
  %940 = fmul fast float %12, %939
  %941 = fsub fast float -0.000000e+00, %940
  %942 = call float @dx.op.binary.f32(i32 35, float %941, float -4.000000e+01)  ; FMax(a,b)
  %943 = call float @dx.op.binary.f32(i32 36, float %942, float 5.000000e+00)  ; FMin(a,b)
  %944 = fmul fast float %943, 0x3FF7154760000000
  %945 = call float @dx.op.unary.f32(i32 21, float %944)  ; Exp(value)
  %946 = fmul fast float %945, %937
  br label %947

; <label>:947                                     ; preds = %936, %896
  %948 = phi float [ %946, %936 ], [ 1.000000e+00, %896 ]
  %949 = fmul fast float %922, %17
  %950 = fmul fast float %949, %948
  %951 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %950)  ; FMin(a,b)
  %952 = fmul fast float %951, 0xBFF7154760000000
  %953 = call float @dx.op.unary.f32(i32 21, float %952)  ; Exp(value)
  %954 = fsub fast float 1.000000e+00, %953
  %955 = call float @dx.op.binary.f32(i32 36, float %13, float %954)  ; FMin(a,b)
  %956 = fsub fast float %14, %834
  %957 = fsub fast float %15, %835
  %958 = fsub fast float %16, %836
  %959 = fmul fast float %955, %956
  %960 = fmul fast float %955, %957
  %961 = fmul fast float %955, %958
  %962 = fadd fast float %959, %834
  %963 = fadd fast float %960, %835
  %964 = fadd fast float %961, %836
  br label %965

; <label>:965                                     ; preds = %947, %879, %873
  %966 = phi float [ %962, %947 ], [ %834, %879 ], [ %834, %873 ]
  %967 = phi float [ %963, %947 ], [ %835, %879 ], [ %835, %873 ]
  %968 = phi float [ %964, %947 ], [ %836, %879 ], [ %836, %873 ]
  %969 = fadd fast float %6, 1.000000e+00
  %970 = fadd fast float %7, 1.000000e+00
  %971 = fsub fast float 1.000000e+00, %6
  %972 = fmul fast float %37, %969
  %973 = fmul fast float %37, %970
  %974 = fmul fast float %37, %971
  %975 = fmul fast float %972, %966
  %976 = fmul fast float %973, %967
  %977 = fmul fast float %974, %968
  %978 = fcmp fast ult float %38, 5.000000e-01
  br i1 %978, label %1004, label %979

; <label>:979                                     ; preds = %965
  %980 = fmul fast float %975, 0x4004147AE0000000
  %981 = fmul fast float %976, 0x4004147AE0000000
  %982 = fmul fast float %977, 0x4004147AE0000000
  %983 = fadd fast float %980, 0x3F9EB851E0000000
  %984 = fadd fast float %981, 0x3F9EB851E0000000
  %985 = fadd fast float %982, 0x3F9EB851E0000000
  %986 = fmul fast float %983, %975
  %987 = fmul fast float %984, %976
  %988 = fmul fast float %985, %977
  %989 = fmul fast float %975, 0x400370A3E0000000
  %990 = fmul fast float %976, 0x400370A3E0000000
  %991 = fmul fast float %977, 0x400370A3E0000000
  %992 = fadd fast float %989, 0x3FE2E147A0000000
  %993 = fadd fast float %990, 0x3FE2E147A0000000
  %994 = fadd fast float %991, 0x3FE2E147A0000000
  %995 = fmul fast float %992, %975
  %996 = fmul fast float %993, %976
  %997 = fmul fast float %994, %977
  %998 = fadd fast float %995, 0x3FC1EB8520000000
  %999 = fadd fast float %996, 0x3FC1EB8520000000
  %1000 = fadd fast float %997, 0x3FC1EB8520000000
  %1001 = fdiv fast float %986, %998
  %1002 = fdiv fast float %987, %999
  %1003 = fdiv fast float %988, %1000
  br label %1004

; <label>:1004                                    ; preds = %979, %965
  %1005 = phi float [ %1001, %979 ], [ %975, %965 ]
  %1006 = phi float [ %1002, %979 ], [ %976, %965 ]
  %1007 = phi float [ %1003, %979 ], [ %977, %965 ]
  %1008 = call float @dx.op.unary.f32(i32 7, float %1005)  ; Saturate(value)
  %1009 = call float @dx.op.unary.f32(i32 7, float %1006)  ; Saturate(value)
  %1010 = call float @dx.op.unary.f32(i32 7, float %1007)  ; Saturate(value)
  %1011 = call float @dx.op.dot3.f32(i32 55, float %1008, float %1009, float %1010, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1012 = fsub fast float %1008, %1011
  %1013 = fsub fast float %1009, %1011
  %1014 = fsub fast float %1010, %1011
  %1015 = fmul fast float %1012, %9
  %1016 = fmul fast float %1013, %9
  %1017 = fmul fast float %1014, %9
  %1018 = fadd fast float %1015, %1011
  %1019 = fadd fast float %1016, %1011
  %1020 = fadd fast float %1017, %1011
  %1021 = call float @dx.op.unary.f32(i32 7, float %1018)  ; Saturate(value)
  %1022 = call float @dx.op.unary.f32(i32 7, float %1019)  ; Saturate(value)
  %1023 = call float @dx.op.unary.f32(i32 7, float %1020)  ; Saturate(value)
  %1024 = fadd fast float %1021, 0xBFC70A3D80000000
  %1025 = fadd fast float %1022, 0xBFC70A3D80000000
  %1026 = fadd fast float %1023, 0xBFC70A3D80000000
  %1027 = fmul fast float %1024, %8
  %1028 = fmul fast float %1025, %8
  %1029 = fmul fast float %1026, %8
  %1030 = fadd fast float %1027, 0x3FC70A3D80000000
  %1031 = fadd fast float %1028, 0x3FC70A3D80000000
  %1032 = fadd fast float %1029, 0x3FC70A3D80000000
  %1033 = call float @dx.op.unary.f32(i32 7, float %1030)  ; Saturate(value)
  %1034 = call float @dx.op.unary.f32(i32 7, float %1031)  ; Saturate(value)
  %1035 = call float @dx.op.unary.f32(i32 7, float %1032)  ; Saturate(value)
  br label %1036

; <label>:1036                                    ; preds = %1004, %839
  %1037 = phi float [ %870, %839 ], [ %1033, %1004 ]
  %1038 = phi float [ %871, %839 ], [ %1034, %1004 ]
  %1039 = phi float [ %872, %839 ], [ %1035, %1004 ]
  %1040 = fsub fast float %1037, %333
  %1041 = fsub fast float %1038, %334
  %1042 = fsub fast float %1039, %335
  %1043 = fmul fast float %1040, %826
  %1044 = fmul fast float %1041, %826
  %1045 = fmul fast float %1042, %826
  %1046 = fadd fast float %1043, %333
  %1047 = fadd fast float %1044, %334
  %1048 = fadd fast float %1045, %335
  br label %1049

; <label>:1049                                    ; preds = %1036, %811
  %1050 = phi float [ %1046, %1036 ], [ %333, %811 ]
  %1051 = phi float [ %1047, %1036 ], [ %334, %811 ]
  %1052 = phi float [ %1048, %1036 ], [ %335, %811 ]
  %1053 = add i32 %64, 1
  %1054 = call i32 @dx.op.binary.i32(i32 37, i32 %1053, i32 0)  ; IMax(a,b)
  %1055 = call i32 @dx.op.binary.i32(i32 38, i32 %1054, i32 %60)  ; IMin(a,b)
  %1056 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1055, i32 %819, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1057 = extractvalue %dx.types.ResRet.f32 %1056, 0
  %1058 = fsub fast float %1057, %83
  %1059 = call float @dx.op.unary.f32(i32 6, float %1058)  ; FAbs(value)
  %1060 = fdiv fast float %1059, %347
  %1061 = fsub fast float 1.000000e+00, %1060
  %1062 = call float @dx.op.unary.f32(i32 7, float %1061)  ; Saturate(value)
  %1063 = fcmp fast ugt float %1062, 0.000000e+00
  br i1 %1063, label %1064, label %1285

; <label>:1064                                    ; preds = %1049
  %1065 = call i32 @dx.op.binary.i32(i32 37, i32 %1055, i32 0)  ; IMax(a,b)
  %1066 = call i32 @dx.op.binary.i32(i32 37, i32 %819, i32 0)  ; IMax(a,b)
  %1067 = call i32 @dx.op.binary.i32(i32 38, i32 %1065, i32 %60)  ; IMin(a,b)
  %1068 = call i32 @dx.op.binary.i32(i32 38, i32 %1066, i32 %61)  ; IMin(a,b)
  %1069 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1067, i32 %1068, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1070 = extractvalue %dx.types.ResRet.f32 %1069, 0
  %1071 = extractvalue %dx.types.ResRet.f32 %1069, 1
  %1072 = extractvalue %dx.types.ResRet.f32 %1069, 2
  %1073 = extractvalue %dx.types.ResRet.f32 %1069, 3
  %1074 = fcmp fast olt float %1073, 0.000000e+00
  br i1 %1074, label %1075, label %1109

; <label>:1075                                    ; preds = %1064
  %1076 = fcmp fast ogt float %1070, 0x3FA4B5DCC0000000
  %1077 = fcmp fast ogt float %1071, 0x3FA4B5DCC0000000
  %1078 = fcmp fast ogt float %1072, 0x3FA4B5DCC0000000
  %1079 = select i1 %1076, float 0.000000e+00, float 1.000000e+00
  %1080 = select i1 %1077, float 0.000000e+00, float 1.000000e+00
  %1081 = select i1 %1078, float 0.000000e+00, float 1.000000e+00
  %1082 = fmul fast float %1070, 0x3FB3D07220000000
  %1083 = fmul fast float %1071, 0x3FB3D07220000000
  %1084 = fmul fast float %1072, 0x3FB3D07220000000
  %1085 = fadd fast float %1070, 0x3FAC28F5C0000000
  %1086 = fadd fast float %1071, 0x3FAC28F5C0000000
  %1087 = fadd fast float %1072, 0x3FAC28F5C0000000
  %1088 = fmul fast float %1085, 0x3FEE54EDE0000000
  %1089 = fmul fast float %1086, 0x3FEE54EDE0000000
  %1090 = fmul fast float %1087, 0x3FEE54EDE0000000
  %1091 = call float @dx.op.unary.f32(i32 23, float %1088)  ; Log(value)
  %1092 = call float @dx.op.unary.f32(i32 23, float %1089)  ; Log(value)
  %1093 = call float @dx.op.unary.f32(i32 23, float %1090)  ; Log(value)
  %1094 = fmul fast float %1091, 0x4003333340000000
  %1095 = fmul fast float %1092, 0x4003333340000000
  %1096 = fmul fast float %1093, 0x4003333340000000
  %1097 = call float @dx.op.unary.f32(i32 21, float %1094)  ; Exp(value)
  %1098 = call float @dx.op.unary.f32(i32 21, float %1095)  ; Exp(value)
  %1099 = call float @dx.op.unary.f32(i32 21, float %1096)  ; Exp(value)
  %1100 = fsub fast float %1082, %1097
  %1101 = fsub fast float %1083, %1098
  %1102 = fsub fast float %1084, %1099
  %1103 = fmul fast float %1100, %1079
  %1104 = fmul fast float %1101, %1080
  %1105 = fmul fast float %1102, %1081
  %1106 = fadd fast float %1103, %1097
  %1107 = fadd fast float %1104, %1098
  %1108 = fadd fast float %1105, %1099
  br label %1272

; <label>:1109                                    ; preds = %1064
  %1110 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1067, i32 %1068, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1111 = extractvalue %dx.types.ResRet.f32 %1110, 0
  %1112 = fcmp fast ogt float %39, 5.000000e-01
  %1113 = fcmp fast olt float %1111, 1.000000e+00
  %1114 = and i1 %1112, %1113
  br i1 %1114, label %1115, label %1201

; <label>:1115                                    ; preds = %1109
  %1116 = sitofp i32 %1067 to float
  %1117 = sitofp i32 %1068 to float
  %1118 = fadd fast float %1116, 5.000000e-01
  %1119 = fadd fast float %1117, 5.000000e-01
  %1120 = fdiv fast float %1118, %46
  %1121 = fdiv fast float %1119, %47
  %1122 = fmul fast float %1120, 2.000000e+00
  %1123 = fmul fast float %1121, 2.000000e+00
  %1124 = fadd fast float %1122, -1.000000e+00
  %1125 = fsub fast float 1.000000e+00, %1123
  %1126 = fmul fast float %1124, %36
  %1127 = call float @dx.op.tertiary.f32(i32 46, float %1125, float %32, float %1126)  ; FMad(a,b,c)
  %1128 = call float @dx.op.tertiary.f32(i32 46, float %1111, float %28, float %1127)  ; FMad(a,b,c)
  %1129 = fadd fast float %1128, %24
  %1130 = call float @dx.op.unary.f32(i32 6, float %1129)  ; FAbs(value)
  %1131 = fcmp fast ogt float %1130, 0x3EB0C6F7A0000000
  br i1 %1131, label %1132, label %1201

; <label>:1132                                    ; preds = %1115
  %1133 = fmul fast float %1124, %35
  %1134 = call float @dx.op.tertiary.f32(i32 46, float %1125, float %31, float %1133)  ; FMad(a,b,c)
  %1135 = call float @dx.op.tertiary.f32(i32 46, float %1111, float %27, float %1134)  ; FMad(a,b,c)
  %1136 = fadd fast float %1135, %23
  %1137 = fmul fast float %1124, %34
  %1138 = call float @dx.op.tertiary.f32(i32 46, float %1125, float %30, float %1137)  ; FMad(a,b,c)
  %1139 = call float @dx.op.tertiary.f32(i32 46, float %1111, float %26, float %1138)  ; FMad(a,b,c)
  %1140 = fadd fast float %1139, %22
  %1141 = fmul fast float %1124, %33
  %1142 = call float @dx.op.tertiary.f32(i32 46, float %1125, float %29, float %1141)  ; FMad(a,b,c)
  %1143 = call float @dx.op.tertiary.f32(i32 46, float %1111, float %25, float %1142)  ; FMad(a,b,c)
  %1144 = fadd fast float %1143, %21
  %1145 = fdiv fast float %1144, %1129
  %1146 = fdiv fast float %1140, %1129
  %1147 = fdiv fast float %1136, %1129
  %1148 = fsub fast float %1145, %18
  %1149 = fsub fast float %1146, %19
  %1150 = fsub fast float %1147, %20
  %1151 = fmul fast float %1148, %1148
  %1152 = fmul fast float %1149, %1149
  %1153 = fadd fast float %1152, %1151
  %1154 = fmul fast float %1150, %1150
  %1155 = fadd fast float %1153, %1154
  %1156 = call float @dx.op.unary.f32(i32 24, float %1155)  ; Sqrt(value)
  %1157 = fsub fast float %1156, %10
  %1158 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1157)  ; FMax(a,b)
  %1159 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %1159, label %1160, label %1183

; <label>:1160                                    ; preds = %1132
  %1161 = call float @dx.op.unary.f32(i32 6, float %1149)  ; FAbs(value)
  %1162 = fmul fast float %1161, %12
  %1163 = fcmp fast olt float %1162, 0x3F50624DE0000000
  br i1 %1163, label %1164, label %1167

; <label>:1164                                    ; preds = %1160
  %1165 = fmul fast float %1162, 5.000000e-01
  %1166 = fsub fast float 1.000000e+00, %1165
  br label %1172

; <label>:1167                                    ; preds = %1160
  %1168 = fmul fast float %1162, 0xBFF7154760000000
  %1169 = call float @dx.op.unary.f32(i32 21, float %1168)  ; Exp(value)
  %1170 = fsub fast float 1.000000e+00, %1169
  %1171 = fdiv fast float %1170, %1162
  br label %1172

; <label>:1172                                    ; preds = %1167, %1164
  %1173 = phi float [ %1166, %1164 ], [ %1171, %1167 ]
  %1174 = call float @dx.op.binary.f32(i32 36, float %1146, float %19)  ; FMin(a,b)
  %1175 = fsub fast float %1174, %11
  %1176 = fmul fast float %12, %1175
  %1177 = fsub fast float -0.000000e+00, %1176
  %1178 = call float @dx.op.binary.f32(i32 35, float %1177, float -4.000000e+01)  ; FMax(a,b)
  %1179 = call float @dx.op.binary.f32(i32 36, float %1178, float 5.000000e+00)  ; FMin(a,b)
  %1180 = fmul fast float %1179, 0x3FF7154760000000
  %1181 = call float @dx.op.unary.f32(i32 21, float %1180)  ; Exp(value)
  %1182 = fmul fast float %1181, %1173
  br label %1183

; <label>:1183                                    ; preds = %1172, %1132
  %1184 = phi float [ %1182, %1172 ], [ 1.000000e+00, %1132 ]
  %1185 = fmul fast float %1158, %17
  %1186 = fmul fast float %1185, %1184
  %1187 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1186)  ; FMin(a,b)
  %1188 = fmul fast float %1187, 0xBFF7154760000000
  %1189 = call float @dx.op.unary.f32(i32 21, float %1188)  ; Exp(value)
  %1190 = fsub fast float 1.000000e+00, %1189
  %1191 = call float @dx.op.binary.f32(i32 36, float %13, float %1190)  ; FMin(a,b)
  %1192 = fsub fast float %14, %1070
  %1193 = fsub fast float %15, %1071
  %1194 = fsub fast float %16, %1072
  %1195 = fmul fast float %1191, %1192
  %1196 = fmul fast float %1191, %1193
  %1197 = fmul fast float %1191, %1194
  %1198 = fadd fast float %1195, %1070
  %1199 = fadd fast float %1196, %1071
  %1200 = fadd fast float %1197, %1072
  br label %1201

; <label>:1201                                    ; preds = %1183, %1115, %1109
  %1202 = phi float [ %1198, %1183 ], [ %1070, %1115 ], [ %1070, %1109 ]
  %1203 = phi float [ %1199, %1183 ], [ %1071, %1115 ], [ %1071, %1109 ]
  %1204 = phi float [ %1200, %1183 ], [ %1072, %1115 ], [ %1072, %1109 ]
  %1205 = fadd fast float %6, 1.000000e+00
  %1206 = fadd fast float %7, 1.000000e+00
  %1207 = fsub fast float 1.000000e+00, %6
  %1208 = fmul fast float %37, %1205
  %1209 = fmul fast float %37, %1206
  %1210 = fmul fast float %37, %1207
  %1211 = fmul fast float %1208, %1202
  %1212 = fmul fast float %1209, %1203
  %1213 = fmul fast float %1210, %1204
  %1214 = fcmp fast ult float %38, 5.000000e-01
  br i1 %1214, label %1240, label %1215

; <label>:1215                                    ; preds = %1201
  %1216 = fmul fast float %1211, 0x4004147AE0000000
  %1217 = fmul fast float %1212, 0x4004147AE0000000
  %1218 = fmul fast float %1213, 0x4004147AE0000000
  %1219 = fadd fast float %1216, 0x3F9EB851E0000000
  %1220 = fadd fast float %1217, 0x3F9EB851E0000000
  %1221 = fadd fast float %1218, 0x3F9EB851E0000000
  %1222 = fmul fast float %1219, %1211
  %1223 = fmul fast float %1220, %1212
  %1224 = fmul fast float %1221, %1213
  %1225 = fmul fast float %1211, 0x400370A3E0000000
  %1226 = fmul fast float %1212, 0x400370A3E0000000
  %1227 = fmul fast float %1213, 0x400370A3E0000000
  %1228 = fadd fast float %1225, 0x3FE2E147A0000000
  %1229 = fadd fast float %1226, 0x3FE2E147A0000000
  %1230 = fadd fast float %1227, 0x3FE2E147A0000000
  %1231 = fmul fast float %1228, %1211
  %1232 = fmul fast float %1229, %1212
  %1233 = fmul fast float %1230, %1213
  %1234 = fadd fast float %1231, 0x3FC1EB8520000000
  %1235 = fadd fast float %1232, 0x3FC1EB8520000000
  %1236 = fadd fast float %1233, 0x3FC1EB8520000000
  %1237 = fdiv fast float %1222, %1234
  %1238 = fdiv fast float %1223, %1235
  %1239 = fdiv fast float %1224, %1236
  br label %1240

; <label>:1240                                    ; preds = %1215, %1201
  %1241 = phi float [ %1237, %1215 ], [ %1211, %1201 ]
  %1242 = phi float [ %1238, %1215 ], [ %1212, %1201 ]
  %1243 = phi float [ %1239, %1215 ], [ %1213, %1201 ]
  %1244 = call float @dx.op.unary.f32(i32 7, float %1241)  ; Saturate(value)
  %1245 = call float @dx.op.unary.f32(i32 7, float %1242)  ; Saturate(value)
  %1246 = call float @dx.op.unary.f32(i32 7, float %1243)  ; Saturate(value)
  %1247 = call float @dx.op.dot3.f32(i32 55, float %1244, float %1245, float %1246, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1248 = fsub fast float %1244, %1247
  %1249 = fsub fast float %1245, %1247
  %1250 = fsub fast float %1246, %1247
  %1251 = fmul fast float %1248, %9
  %1252 = fmul fast float %1249, %9
  %1253 = fmul fast float %1250, %9
  %1254 = fadd fast float %1251, %1247
  %1255 = fadd fast float %1252, %1247
  %1256 = fadd fast float %1253, %1247
  %1257 = call float @dx.op.unary.f32(i32 7, float %1254)  ; Saturate(value)
  %1258 = call float @dx.op.unary.f32(i32 7, float %1255)  ; Saturate(value)
  %1259 = call float @dx.op.unary.f32(i32 7, float %1256)  ; Saturate(value)
  %1260 = fadd fast float %1257, 0xBFC70A3D80000000
  %1261 = fadd fast float %1258, 0xBFC70A3D80000000
  %1262 = fadd fast float %1259, 0xBFC70A3D80000000
  %1263 = fmul fast float %1260, %8
  %1264 = fmul fast float %1261, %8
  %1265 = fmul fast float %1262, %8
  %1266 = fadd fast float %1263, 0x3FC70A3D80000000
  %1267 = fadd fast float %1264, 0x3FC70A3D80000000
  %1268 = fadd fast float %1265, 0x3FC70A3D80000000
  %1269 = call float @dx.op.unary.f32(i32 7, float %1266)  ; Saturate(value)
  %1270 = call float @dx.op.unary.f32(i32 7, float %1267)  ; Saturate(value)
  %1271 = call float @dx.op.unary.f32(i32 7, float %1268)  ; Saturate(value)
  br label %1272

; <label>:1272                                    ; preds = %1240, %1075
  %1273 = phi float [ %1106, %1075 ], [ %1269, %1240 ]
  %1274 = phi float [ %1107, %1075 ], [ %1270, %1240 ]
  %1275 = phi float [ %1108, %1075 ], [ %1271, %1240 ]
  %1276 = fsub fast float %1273, %333
  %1277 = fsub fast float %1274, %334
  %1278 = fsub fast float %1275, %335
  %1279 = fmul fast float %1276, %1062
  %1280 = fmul fast float %1277, %1062
  %1281 = fmul fast float %1278, %1062
  %1282 = fadd fast float %1279, %333
  %1283 = fadd fast float %1280, %334
  %1284 = fadd fast float %1281, %335
  br label %1285

; <label>:1285                                    ; preds = %1272, %1049
  %1286 = phi float [ %1282, %1272 ], [ %333, %1049 ]
  %1287 = phi float [ %1283, %1272 ], [ %334, %1049 ]
  %1288 = phi float [ %1284, %1272 ], [ %335, %1049 ]
  %1289 = call float @dx.op.binary.f32(i32 36, float %1050, float %1286)  ; FMin(a,b)
  %1290 = call float @dx.op.binary.f32(i32 36, float %1051, float %1287)  ; FMin(a,b)
  %1291 = call float @dx.op.binary.f32(i32 36, float %1052, float %1288)  ; FMin(a,b)
  %1292 = call float @dx.op.binary.f32(i32 36, float %576, float %812)  ; FMin(a,b)
  %1293 = call float @dx.op.binary.f32(i32 36, float %577, float %813)  ; FMin(a,b)
  %1294 = call float @dx.op.binary.f32(i32 36, float %578, float %814)  ; FMin(a,b)
  %1295 = call float @dx.op.binary.f32(i32 36, float %1292, float %1289)  ; FMin(a,b)
  %1296 = call float @dx.op.binary.f32(i32 36, float %1293, float %1290)  ; FMin(a,b)
  %1297 = call float @dx.op.binary.f32(i32 36, float %1294, float %1291)  ; FMin(a,b)
  %1298 = call float @dx.op.binary.f32(i32 36, float %333, float %1295)  ; FMin(a,b)
  %1299 = call float @dx.op.binary.f32(i32 36, float %334, float %1296)  ; FMin(a,b)
  %1300 = call float @dx.op.binary.f32(i32 36, float %335, float %1297)  ; FMin(a,b)
  %1301 = call float @dx.op.binary.f32(i32 35, float %1050, float %1286)  ; FMax(a,b)
  %1302 = call float @dx.op.binary.f32(i32 35, float %1051, float %1287)  ; FMax(a,b)
  %1303 = call float @dx.op.binary.f32(i32 35, float %1052, float %1288)  ; FMax(a,b)
  %1304 = call float @dx.op.binary.f32(i32 35, float %576, float %812)  ; FMax(a,b)
  %1305 = call float @dx.op.binary.f32(i32 35, float %577, float %813)  ; FMax(a,b)
  %1306 = call float @dx.op.binary.f32(i32 35, float %578, float %814)  ; FMax(a,b)
  %1307 = call float @dx.op.binary.f32(i32 35, float %1304, float %1301)  ; FMax(a,b)
  %1308 = call float @dx.op.binary.f32(i32 35, float %1305, float %1302)  ; FMax(a,b)
  %1309 = call float @dx.op.binary.f32(i32 35, float %1306, float %1303)  ; FMax(a,b)
  %1310 = call float @dx.op.binary.f32(i32 35, float %333, float %1307)  ; FMax(a,b)
  %1311 = call float @dx.op.binary.f32(i32 35, float %334, float %1308)  ; FMax(a,b)
  %1312 = call float @dx.op.binary.f32(i32 35, float %335, float %1309)  ; FMax(a,b)
  %1313 = fsub fast float %1310, %1298
  %1314 = fsub fast float %1311, %1299
  %1315 = fsub fast float %1312, %1300
  %1316 = call float @dx.op.unary.f32(i32 6, float %1313)  ; FAbs(value)
  %1317 = call float @dx.op.unary.f32(i32 6, float %1314)  ; FAbs(value)
  %1318 = call float @dx.op.unary.f32(i32 6, float %1315)  ; FAbs(value)
  %1319 = call float @dx.op.binary.f32(i32 35, float %1317, float %1318)  ; FMax(a,b)
  %1320 = call float @dx.op.binary.f32(i32 35, float %1316, float %1319)  ; FMax(a,b)
  %1321 = call float @dx.op.binary.f32(i32 35, float %1311, float %1312)  ; FMax(a,b)
  %1322 = call float @dx.op.binary.f32(i32 35, float %1310, float %1321)  ; FMax(a,b)
  %1323 = fmul fast float %1322, 1.250000e-01
  %1324 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1323)  ; FMax(a,b)
  %1325 = fcmp fast ogt float %1320, %1324
  br i1 %1325, label %1326, label %1388

; <label>:1326                                    ; preds = %1285
  %1327 = fsub fast float %576, %812
  %1328 = fsub fast float %577, %813
  %1329 = fsub fast float %578, %814
  %1330 = call float @dx.op.unary.f32(i32 6, float %1327)  ; FAbs(value)
  %1331 = call float @dx.op.unary.f32(i32 6, float %1328)  ; FAbs(value)
  %1332 = call float @dx.op.unary.f32(i32 6, float %1329)  ; FAbs(value)
  %1333 = call float @dx.op.binary.f32(i32 35, float %1331, float %1332)  ; FMax(a,b)
  %1334 = call float @dx.op.binary.f32(i32 35, float %1330, float %1333)  ; FMax(a,b)
  %1335 = fsub fast float %1050, %1286
  %1336 = fsub fast float %1051, %1287
  %1337 = fsub fast float %1052, %1288
  %1338 = call float @dx.op.unary.f32(i32 6, float %1335)  ; FAbs(value)
  %1339 = call float @dx.op.unary.f32(i32 6, float %1336)  ; FAbs(value)
  %1340 = call float @dx.op.unary.f32(i32 6, float %1337)  ; FAbs(value)
  %1341 = call float @dx.op.binary.f32(i32 35, float %1339, float %1340)  ; FMax(a,b)
  %1342 = call float @dx.op.binary.f32(i32 35, float %1338, float %1341)  ; FMax(a,b)
  %1343 = fcmp fast olt float %1334, %1342
  %1344 = select i1 %1343, float %576, float %1050
  %1345 = select i1 %1343, float %577, float %1051
  %1346 = select i1 %1343, float %578, float %1052
  %1347 = select i1 %1343, float %812, float %1286
  %1348 = select i1 %1343, float %813, float %1287
  %1349 = select i1 %1343, float %814, float %1288
  %1350 = fsub fast float %333, %1347
  %1351 = fsub fast float %334, %1348
  %1352 = fsub fast float %335, %1349
  %1353 = fsub fast float %333, %1344
  %1354 = fsub fast float %334, %1345
  %1355 = fsub fast float %335, %1346
  %1356 = call float @dx.op.dot3.f32(i32 55, float %1353, float %1354, float %1355, float %1350, float %1351, float %1352)  ; Dot3(ax,ay,az,bx,by,bz)
  %1357 = fcmp fast ogt float %1356, 0.000000e+00
  br i1 %1357, label %1358, label %1369

; <label>:1358                                    ; preds = %1326
  %1359 = fsub fast float %1344, %1347
  %1360 = fsub fast float %1345, %1348
  %1361 = fsub fast float %1346, %1349
  %1362 = call float @dx.op.unary.f32(i32 6, float %1359)  ; FAbs(value)
  %1363 = call float @dx.op.unary.f32(i32 6, float %1360)  ; FAbs(value)
  %1364 = call float @dx.op.unary.f32(i32 6, float %1361)  ; FAbs(value)
  %1365 = call float @dx.op.binary.f32(i32 35, float %1363, float %1364)  ; FMax(a,b)
  %1366 = call float @dx.op.binary.f32(i32 35, float %1362, float %1365)  ; FMax(a,b)
  %1367 = fmul fast float %1320, 2.500000e-01
  %1368 = fcmp fast olt float %1366, %1367
  br label %1369

; <label>:1369                                    ; preds = %1358, %1326
  %1370 = phi i1 [ false, %1326 ], [ %1368, %1358 ]
  %1371 = select i1 %1370, float 5.000000e-01, float 1.000000e+00
  %1372 = fmul fast float %1371, %3
  %1373 = fadd fast float %1344, %1347
  %1374 = fadd fast float %1345, %1348
  %1375 = fadd fast float %1346, %1349
  %1376 = fmul fast float %1373, 5.000000e-01
  %1377 = fmul fast float %1374, 5.000000e-01
  %1378 = fmul fast float %1375, 5.000000e-01
  %1379 = fsub fast float %1376, %333
  %1380 = fsub fast float %1377, %334
  %1381 = fsub fast float %1378, %335
  %1382 = fmul fast float %1372, %1379
  %1383 = fmul fast float %1372, %1380
  %1384 = fmul fast float %1372, %1381
  %1385 = fadd fast float %1382, %333
  %1386 = fadd fast float %1383, %334
  %1387 = fadd fast float %1384, %335
  br label %1388

; <label>:1388                                    ; preds = %1369, %1285, %304
  %1389 = phi float [ %333, %304 ], [ %1385, %1369 ], [ %333, %1285 ]
  %1390 = phi float [ %334, %304 ], [ %1386, %1369 ], [ %334, %1285 ]
  %1391 = phi float [ %335, %304 ], [ %1387, %1369 ], [ %335, %1285 ]
  %1392 = fcmp fast ogt float %1389, 0x3F69A5C380000000
  %1393 = fcmp fast ogt float %1390, 0x3F69A5C380000000
  %1394 = fcmp fast ogt float %1391, 0x3F69A5C380000000
  %1395 = select i1 %1392, float 0.000000e+00, float 1.000000e+00
  %1396 = select i1 %1393, float 0.000000e+00, float 1.000000e+00
  %1397 = select i1 %1394, float 0.000000e+00, float 1.000000e+00
  %1398 = fmul fast float %1389, 0x4029D70A40000000
  %1399 = fmul fast float %1390, 0x4029D70A40000000
  %1400 = fmul fast float %1391, 0x4029D70A40000000
  %1401 = call float @dx.op.binary.f32(i32 35, float %1389, float 0.000000e+00)  ; FMax(a,b)
  %1402 = call float @dx.op.binary.f32(i32 35, float %1390, float 0.000000e+00)  ; FMax(a,b)
  %1403 = call float @dx.op.binary.f32(i32 35, float %1391, float 0.000000e+00)  ; FMax(a,b)
  %1404 = call float @dx.op.unary.f32(i32 23, float %1401)  ; Log(value)
  %1405 = call float @dx.op.unary.f32(i32 23, float %1402)  ; Log(value)
  %1406 = call float @dx.op.unary.f32(i32 23, float %1403)  ; Log(value)
  %1407 = fmul fast float %1404, 0x3FDAAAAAA0000000
  %1408 = fmul fast float %1405, 0x3FDAAAAAA0000000
  %1409 = fmul fast float %1406, 0x3FDAAAAAA0000000
  %1410 = call float @dx.op.unary.f32(i32 21, float %1407)  ; Exp(value)
  %1411 = call float @dx.op.unary.f32(i32 21, float %1408)  ; Exp(value)
  %1412 = call float @dx.op.unary.f32(i32 21, float %1409)  ; Exp(value)
  %1413 = fmul fast float %1410, 0x3FF0E147A0000000
  %1414 = fmul fast float %1411, 0x3FF0E147A0000000
  %1415 = fmul fast float %1412, 0x3FF0E147A0000000
  %1416 = fadd fast float %1413, 0xBFAC28F5C0000000
  %1417 = fadd fast float %1414, 0xBFAC28F5C0000000
  %1418 = fadd fast float %1415, 0xBFAC28F5C0000000
  %1419 = fsub fast float %1398, %1416
  %1420 = fsub fast float %1399, %1417
  %1421 = fsub fast float %1400, %1418
  %1422 = fmul fast float %1419, %1395
  %1423 = fmul fast float %1420, %1396
  %1424 = fmul fast float %1421, %1397
  %1425 = fadd fast float %1422, %1416
  %1426 = fadd fast float %1423, %1417
  %1427 = fadd fast float %1424, %1418
  br label %1428

; <label>:1428                                    ; preds = %1388, %173
  %1429 = phi float [ %168, %173 ], [ %1425, %1388 ]
  %1430 = phi float [ %169, %173 ], [ %1426, %1388 ]
  %1431 = phi float [ %170, %173 ], [ %1427, %1388 ]
  %1432 = phi float [ %174, %173 ], [ %171, %1388 ]
  %1433 = fcmp fast ogt float %1429, 0x3FA4B5DCC0000000
  %1434 = fcmp fast ogt float %1430, 0x3FA4B5DCC0000000
  %1435 = fcmp fast ogt float %1431, 0x3FA4B5DCC0000000
  %1436 = select i1 %1433, float 0.000000e+00, float 1.000000e+00
  %1437 = select i1 %1434, float 0.000000e+00, float 1.000000e+00
  %1438 = select i1 %1435, float 0.000000e+00, float 1.000000e+00
  %1439 = fmul fast float %1429, 0x3FB3D07220000000
  %1440 = fmul fast float %1430, 0x3FB3D07220000000
  %1441 = fmul fast float %1431, 0x3FB3D07220000000
  %1442 = fadd fast float %1429, 0x3FAC28F5C0000000
  %1443 = fadd fast float %1430, 0x3FAC28F5C0000000
  %1444 = fadd fast float %1431, 0x3FAC28F5C0000000
  %1445 = fmul fast float %1442, 0x3FEE54EDE0000000
  %1446 = fmul fast float %1443, 0x3FEE54EDE0000000
  %1447 = fmul fast float %1444, 0x3FEE54EDE0000000
  %1448 = call float @dx.op.unary.f32(i32 23, float %1445)  ; Log(value)
  %1449 = call float @dx.op.unary.f32(i32 23, float %1446)  ; Log(value)
  %1450 = call float @dx.op.unary.f32(i32 23, float %1447)  ; Log(value)
  %1451 = fmul fast float %1448, 0x4003333340000000
  %1452 = fmul fast float %1449, 0x4003333340000000
  %1453 = fmul fast float %1450, 0x4003333340000000
  %1454 = call float @dx.op.unary.f32(i32 21, float %1451)  ; Exp(value)
  %1455 = call float @dx.op.unary.f32(i32 21, float %1452)  ; Exp(value)
  %1456 = call float @dx.op.unary.f32(i32 21, float %1453)  ; Exp(value)
  %1457 = fsub fast float %1439, %1454
  %1458 = fsub fast float %1440, %1455
  %1459 = fsub fast float %1441, %1456
  %1460 = fmul fast float %1457, %1436
  %1461 = fmul fast float %1458, %1437
  %1462 = fmul fast float %1459, %1438
  %1463 = fadd fast float %1460, %1454
  %1464 = fadd fast float %1461, %1455
  %1465 = fadd fast float %1462, %1456
  %1466 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %68, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1467 = extractvalue %dx.types.ResRet.f32 %1466, 0
  %1468 = extractvalue %dx.types.ResRet.f32 %1466, 1
  %1469 = extractvalue %dx.types.ResRet.f32 %1466, 2
  %1470 = extractvalue %dx.types.ResRet.f32 %1466, 3
  %1471 = fcmp fast olt float %1470, 0.000000e+00
  br i1 %1471, label %1472, label %1474

; <label>:1472                                    ; preds = %1428
  %1473 = fsub fast float -1.000000e+00, %1470
  br label %2727

; <label>:1474                                    ; preds = %1428
  %1475 = fcmp fast ogt float %39, 5.000000e-01
  %1476 = fcmp fast olt float %85, 1.000000e+00
  %1477 = and i1 %1475, %1476
  br i1 %1477, label %1478, label %1564

; <label>:1478                                    ; preds = %1474
  %1479 = sitofp i32 %68 to float
  %1480 = sitofp i32 %65 to float
  %1481 = fadd fast float %1479, 5.000000e-01
  %1482 = fadd fast float %1480, 5.000000e-01
  %1483 = fdiv fast float %1481, %46
  %1484 = fdiv fast float %1482, %47
  %1485 = fmul fast float %1483, 2.000000e+00
  %1486 = fmul fast float %1484, 2.000000e+00
  %1487 = fadd fast float %1485, -1.000000e+00
  %1488 = fsub fast float 1.000000e+00, %1486
  %1489 = fmul fast float %1487, %36
  %1490 = call float @dx.op.tertiary.f32(i32 46, float %1488, float %32, float %1489)  ; FMad(a,b,c)
  %1491 = call float @dx.op.tertiary.f32(i32 46, float %85, float %28, float %1490)  ; FMad(a,b,c)
  %1492 = fadd fast float %1491, %24
  %1493 = call float @dx.op.unary.f32(i32 6, float %1492)  ; FAbs(value)
  %1494 = fcmp fast ogt float %1493, 0x3EB0C6F7A0000000
  br i1 %1494, label %1495, label %1564

; <label>:1495                                    ; preds = %1478
  %1496 = fmul fast float %1487, %35
  %1497 = call float @dx.op.tertiary.f32(i32 46, float %1488, float %31, float %1496)  ; FMad(a,b,c)
  %1498 = call float @dx.op.tertiary.f32(i32 46, float %85, float %27, float %1497)  ; FMad(a,b,c)
  %1499 = fadd fast float %1498, %23
  %1500 = fmul fast float %1487, %34
  %1501 = call float @dx.op.tertiary.f32(i32 46, float %1488, float %30, float %1500)  ; FMad(a,b,c)
  %1502 = call float @dx.op.tertiary.f32(i32 46, float %85, float %26, float %1501)  ; FMad(a,b,c)
  %1503 = fadd fast float %1502, %22
  %1504 = fmul fast float %1487, %33
  %1505 = call float @dx.op.tertiary.f32(i32 46, float %1488, float %29, float %1504)  ; FMad(a,b,c)
  %1506 = call float @dx.op.tertiary.f32(i32 46, float %85, float %25, float %1505)  ; FMad(a,b,c)
  %1507 = fadd fast float %1506, %21
  %1508 = fdiv fast float %1507, %1492
  %1509 = fdiv fast float %1503, %1492
  %1510 = fdiv fast float %1499, %1492
  %1511 = fsub fast float %1508, %18
  %1512 = fsub fast float %1509, %19
  %1513 = fsub fast float %1510, %20
  %1514 = fmul fast float %1511, %1511
  %1515 = fmul fast float %1512, %1512
  %1516 = fadd fast float %1515, %1514
  %1517 = fmul fast float %1513, %1513
  %1518 = fadd fast float %1516, %1517
  %1519 = call float @dx.op.unary.f32(i32 24, float %1518)  ; Sqrt(value)
  %1520 = fsub fast float %1519, %10
  %1521 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1520)  ; FMax(a,b)
  %1522 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %1522, label %1523, label %1546

; <label>:1523                                    ; preds = %1495
  %1524 = call float @dx.op.unary.f32(i32 6, float %1512)  ; FAbs(value)
  %1525 = fmul fast float %1524, %12
  %1526 = fcmp fast olt float %1525, 0x3F50624DE0000000
  br i1 %1526, label %1527, label %1530

; <label>:1527                                    ; preds = %1523
  %1528 = fmul fast float %1525, 5.000000e-01
  %1529 = fsub fast float 1.000000e+00, %1528
  br label %1535

; <label>:1530                                    ; preds = %1523
  %1531 = fmul fast float %1525, 0xBFF7154760000000
  %1532 = call float @dx.op.unary.f32(i32 21, float %1531)  ; Exp(value)
  %1533 = fsub fast float 1.000000e+00, %1532
  %1534 = fdiv fast float %1533, %1525
  br label %1535

; <label>:1535                                    ; preds = %1530, %1527
  %1536 = phi float [ %1529, %1527 ], [ %1534, %1530 ]
  %1537 = call float @dx.op.binary.f32(i32 36, float %1509, float %19)  ; FMin(a,b)
  %1538 = fsub fast float %1537, %11
  %1539 = fmul fast float %12, %1538
  %1540 = fsub fast float -0.000000e+00, %1539
  %1541 = call float @dx.op.binary.f32(i32 35, float %1540, float -4.000000e+01)  ; FMax(a,b)
  %1542 = call float @dx.op.binary.f32(i32 36, float %1541, float 5.000000e+00)  ; FMin(a,b)
  %1543 = fmul fast float %1542, 0x3FF7154760000000
  %1544 = call float @dx.op.unary.f32(i32 21, float %1543)  ; Exp(value)
  %1545 = fmul fast float %1544, %1536
  br label %1546

; <label>:1546                                    ; preds = %1535, %1495
  %1547 = phi float [ %1545, %1535 ], [ 1.000000e+00, %1495 ]
  %1548 = fmul fast float %1521, %17
  %1549 = fmul fast float %1548, %1547
  %1550 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1549)  ; FMin(a,b)
  %1551 = fmul fast float %1550, 0xBFF7154760000000
  %1552 = call float @dx.op.unary.f32(i32 21, float %1551)  ; Exp(value)
  %1553 = fsub fast float 1.000000e+00, %1552
  %1554 = call float @dx.op.binary.f32(i32 36, float %13, float %1553)  ; FMin(a,b)
  %1555 = fsub fast float %14, %1467
  %1556 = fsub fast float %15, %1468
  %1557 = fsub fast float %16, %1469
  %1558 = fmul fast float %1554, %1555
  %1559 = fmul fast float %1554, %1556
  %1560 = fmul fast float %1554, %1557
  %1561 = fadd fast float %1558, %1467
  %1562 = fadd fast float %1559, %1468
  %1563 = fadd fast float %1560, %1469
  br label %1564

; <label>:1564                                    ; preds = %1546, %1478, %1474
  %1565 = phi float [ %1561, %1546 ], [ %1467, %1478 ], [ %1467, %1474 ]
  %1566 = phi float [ %1562, %1546 ], [ %1468, %1478 ], [ %1468, %1474 ]
  %1567 = phi float [ %1563, %1546 ], [ %1469, %1478 ], [ %1469, %1474 ]
  %1568 = fadd fast float %6, 1.000000e+00
  %1569 = fadd fast float %7, 1.000000e+00
  %1570 = fsub fast float 1.000000e+00, %6
  %1571 = fmul fast float %37, %1568
  %1572 = fmul fast float %37, %1569
  %1573 = fmul fast float %37, %1570
  %1574 = fmul fast float %1571, %1565
  %1575 = fmul fast float %1572, %1566
  %1576 = fmul fast float %1573, %1567
  %1577 = fcmp fast ult float %38, 5.000000e-01
  br i1 %1577, label %1603, label %1578

; <label>:1578                                    ; preds = %1564
  %1579 = fmul fast float %1574, 0x4004147AE0000000
  %1580 = fmul fast float %1575, 0x4004147AE0000000
  %1581 = fmul fast float %1576, 0x4004147AE0000000
  %1582 = fadd fast float %1579, 0x3F9EB851E0000000
  %1583 = fadd fast float %1580, 0x3F9EB851E0000000
  %1584 = fadd fast float %1581, 0x3F9EB851E0000000
  %1585 = fmul fast float %1582, %1574
  %1586 = fmul fast float %1583, %1575
  %1587 = fmul fast float %1584, %1576
  %1588 = fmul fast float %1574, 0x400370A3E0000000
  %1589 = fmul fast float %1575, 0x400370A3E0000000
  %1590 = fmul fast float %1576, 0x400370A3E0000000
  %1591 = fadd fast float %1588, 0x3FE2E147A0000000
  %1592 = fadd fast float %1589, 0x3FE2E147A0000000
  %1593 = fadd fast float %1590, 0x3FE2E147A0000000
  %1594 = fmul fast float %1591, %1574
  %1595 = fmul fast float %1592, %1575
  %1596 = fmul fast float %1593, %1576
  %1597 = fadd fast float %1594, 0x3FC1EB8520000000
  %1598 = fadd fast float %1595, 0x3FC1EB8520000000
  %1599 = fadd fast float %1596, 0x3FC1EB8520000000
  %1600 = fdiv fast float %1585, %1597
  %1601 = fdiv fast float %1586, %1598
  %1602 = fdiv fast float %1587, %1599
  br label %1603

; <label>:1603                                    ; preds = %1578, %1564
  %1604 = phi float [ %1600, %1578 ], [ %1574, %1564 ]
  %1605 = phi float [ %1601, %1578 ], [ %1575, %1564 ]
  %1606 = phi float [ %1602, %1578 ], [ %1576, %1564 ]
  %1607 = call float @dx.op.unary.f32(i32 7, float %1604)  ; Saturate(value)
  %1608 = call float @dx.op.unary.f32(i32 7, float %1605)  ; Saturate(value)
  %1609 = call float @dx.op.unary.f32(i32 7, float %1606)  ; Saturate(value)
  %1610 = call float @dx.op.dot3.f32(i32 55, float %1607, float %1608, float %1609, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1611 = fsub fast float %1607, %1610
  %1612 = fsub fast float %1608, %1610
  %1613 = fsub fast float %1609, %1610
  %1614 = fmul fast float %1611, %9
  %1615 = fmul fast float %1612, %9
  %1616 = fmul fast float %1613, %9
  %1617 = fadd fast float %1614, %1610
  %1618 = fadd fast float %1615, %1610
  %1619 = fadd fast float %1616, %1610
  %1620 = call float @dx.op.unary.f32(i32 7, float %1617)  ; Saturate(value)
  %1621 = call float @dx.op.unary.f32(i32 7, float %1618)  ; Saturate(value)
  %1622 = call float @dx.op.unary.f32(i32 7, float %1619)  ; Saturate(value)
  %1623 = fadd fast float %1620, 0xBFC70A3D80000000
  %1624 = fadd fast float %1621, 0xBFC70A3D80000000
  %1625 = fadd fast float %1622, 0xBFC70A3D80000000
  %1626 = fmul fast float %1623, %8
  %1627 = fmul fast float %1624, %8
  %1628 = fmul fast float %1625, %8
  %1629 = fadd fast float %1626, 0x3FC70A3D80000000
  %1630 = fadd fast float %1627, 0x3FC70A3D80000000
  %1631 = fadd fast float %1628, 0x3FC70A3D80000000
  %1632 = call float @dx.op.unary.f32(i32 7, float %1629)  ; Saturate(value)
  %1633 = call float @dx.op.unary.f32(i32 7, float %1630)  ; Saturate(value)
  %1634 = call float @dx.op.unary.f32(i32 7, float %1631)  ; Saturate(value)
  %1635 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %1635, label %1636, label %2687

; <label>:1636                                    ; preds = %1603
  %1637 = add i32 %65, -1
  %1638 = call i32 @dx.op.binary.i32(i32 37, i32 %68, i32 0)  ; IMax(a,b)
  %1639 = call i32 @dx.op.binary.i32(i32 37, i32 %1637, i32 0)  ; IMax(a,b)
  %1640 = call i32 @dx.op.binary.i32(i32 38, i32 %1638, i32 %60)  ; IMin(a,b)
  %1641 = call i32 @dx.op.binary.i32(i32 38, i32 %1639, i32 %61)  ; IMin(a,b)
  %1642 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1640, i32 %1641, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1643 = extractvalue %dx.types.ResRet.f32 %1642, 0
  %1644 = fsub fast float 1.000000e+00, %85
  %1645 = fmul fast float %1644, 0x3FA99999A0000000
  %1646 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %1645)  ; FMax(a,b)
  %1647 = fsub fast float %1643, %85
  %1648 = call float @dx.op.unary.f32(i32 6, float %1647)  ; FAbs(value)
  %1649 = fdiv fast float %1648, %1646
  %1650 = fsub fast float 1.000000e+00, %1649
  %1651 = call float @dx.op.unary.f32(i32 7, float %1650)  ; Saturate(value)
  %1652 = fcmp fast ugt float %1651, 0.000000e+00
  br i1 %1652, label %1653, label %1874

; <label>:1653                                    ; preds = %1636
  %1654 = call i32 @dx.op.binary.i32(i32 37, i32 %1640, i32 0)  ; IMax(a,b)
  %1655 = call i32 @dx.op.binary.i32(i32 37, i32 %1641, i32 0)  ; IMax(a,b)
  %1656 = call i32 @dx.op.binary.i32(i32 38, i32 %1654, i32 %60)  ; IMin(a,b)
  %1657 = call i32 @dx.op.binary.i32(i32 38, i32 %1655, i32 %61)  ; IMin(a,b)
  %1658 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1656, i32 %1657, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1659 = extractvalue %dx.types.ResRet.f32 %1658, 0
  %1660 = extractvalue %dx.types.ResRet.f32 %1658, 1
  %1661 = extractvalue %dx.types.ResRet.f32 %1658, 2
  %1662 = extractvalue %dx.types.ResRet.f32 %1658, 3
  %1663 = fcmp fast olt float %1662, 0.000000e+00
  br i1 %1663, label %1664, label %1698

; <label>:1664                                    ; preds = %1653
  %1665 = fcmp fast ogt float %1659, 0x3FA4B5DCC0000000
  %1666 = fcmp fast ogt float %1660, 0x3FA4B5DCC0000000
  %1667 = fcmp fast ogt float %1661, 0x3FA4B5DCC0000000
  %1668 = select i1 %1665, float 0.000000e+00, float 1.000000e+00
  %1669 = select i1 %1666, float 0.000000e+00, float 1.000000e+00
  %1670 = select i1 %1667, float 0.000000e+00, float 1.000000e+00
  %1671 = fmul fast float %1659, 0x3FB3D07220000000
  %1672 = fmul fast float %1660, 0x3FB3D07220000000
  %1673 = fmul fast float %1661, 0x3FB3D07220000000
  %1674 = fadd fast float %1659, 0x3FAC28F5C0000000
  %1675 = fadd fast float %1660, 0x3FAC28F5C0000000
  %1676 = fadd fast float %1661, 0x3FAC28F5C0000000
  %1677 = fmul fast float %1674, 0x3FEE54EDE0000000
  %1678 = fmul fast float %1675, 0x3FEE54EDE0000000
  %1679 = fmul fast float %1676, 0x3FEE54EDE0000000
  %1680 = call float @dx.op.unary.f32(i32 23, float %1677)  ; Log(value)
  %1681 = call float @dx.op.unary.f32(i32 23, float %1678)  ; Log(value)
  %1682 = call float @dx.op.unary.f32(i32 23, float %1679)  ; Log(value)
  %1683 = fmul fast float %1680, 0x4003333340000000
  %1684 = fmul fast float %1681, 0x4003333340000000
  %1685 = fmul fast float %1682, 0x4003333340000000
  %1686 = call float @dx.op.unary.f32(i32 21, float %1683)  ; Exp(value)
  %1687 = call float @dx.op.unary.f32(i32 21, float %1684)  ; Exp(value)
  %1688 = call float @dx.op.unary.f32(i32 21, float %1685)  ; Exp(value)
  %1689 = fsub fast float %1671, %1686
  %1690 = fsub fast float %1672, %1687
  %1691 = fsub fast float %1673, %1688
  %1692 = fmul fast float %1689, %1668
  %1693 = fmul fast float %1690, %1669
  %1694 = fmul fast float %1691, %1670
  %1695 = fadd fast float %1692, %1686
  %1696 = fadd fast float %1693, %1687
  %1697 = fadd fast float %1694, %1688
  br label %1861

; <label>:1698                                    ; preds = %1653
  %1699 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1656, i32 %1657, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1700 = extractvalue %dx.types.ResRet.f32 %1699, 0
  %1701 = fcmp fast ogt float %39, 5.000000e-01
  %1702 = fcmp fast olt float %1700, 1.000000e+00
  %1703 = and i1 %1701, %1702
  br i1 %1703, label %1704, label %1790

; <label>:1704                                    ; preds = %1698
  %1705 = sitofp i32 %1656 to float
  %1706 = sitofp i32 %1657 to float
  %1707 = fadd fast float %1705, 5.000000e-01
  %1708 = fadd fast float %1706, 5.000000e-01
  %1709 = fdiv fast float %1707, %46
  %1710 = fdiv fast float %1708, %47
  %1711 = fmul fast float %1709, 2.000000e+00
  %1712 = fmul fast float %1710, 2.000000e+00
  %1713 = fadd fast float %1711, -1.000000e+00
  %1714 = fsub fast float 1.000000e+00, %1712
  %1715 = fmul fast float %1713, %36
  %1716 = call float @dx.op.tertiary.f32(i32 46, float %1714, float %32, float %1715)  ; FMad(a,b,c)
  %1717 = call float @dx.op.tertiary.f32(i32 46, float %1700, float %28, float %1716)  ; FMad(a,b,c)
  %1718 = fadd fast float %1717, %24
  %1719 = call float @dx.op.unary.f32(i32 6, float %1718)  ; FAbs(value)
  %1720 = fcmp fast ogt float %1719, 0x3EB0C6F7A0000000
  br i1 %1720, label %1721, label %1790

; <label>:1721                                    ; preds = %1704
  %1722 = fmul fast float %1713, %35
  %1723 = call float @dx.op.tertiary.f32(i32 46, float %1714, float %31, float %1722)  ; FMad(a,b,c)
  %1724 = call float @dx.op.tertiary.f32(i32 46, float %1700, float %27, float %1723)  ; FMad(a,b,c)
  %1725 = fadd fast float %1724, %23
  %1726 = fmul fast float %1713, %34
  %1727 = call float @dx.op.tertiary.f32(i32 46, float %1714, float %30, float %1726)  ; FMad(a,b,c)
  %1728 = call float @dx.op.tertiary.f32(i32 46, float %1700, float %26, float %1727)  ; FMad(a,b,c)
  %1729 = fadd fast float %1728, %22
  %1730 = fmul fast float %1713, %33
  %1731 = call float @dx.op.tertiary.f32(i32 46, float %1714, float %29, float %1730)  ; FMad(a,b,c)
  %1732 = call float @dx.op.tertiary.f32(i32 46, float %1700, float %25, float %1731)  ; FMad(a,b,c)
  %1733 = fadd fast float %1732, %21
  %1734 = fdiv fast float %1733, %1718
  %1735 = fdiv fast float %1729, %1718
  %1736 = fdiv fast float %1725, %1718
  %1737 = fsub fast float %1734, %18
  %1738 = fsub fast float %1735, %19
  %1739 = fsub fast float %1736, %20
  %1740 = fmul fast float %1737, %1737
  %1741 = fmul fast float %1738, %1738
  %1742 = fadd fast float %1741, %1740
  %1743 = fmul fast float %1739, %1739
  %1744 = fadd fast float %1742, %1743
  %1745 = call float @dx.op.unary.f32(i32 24, float %1744)  ; Sqrt(value)
  %1746 = fsub fast float %1745, %10
  %1747 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1746)  ; FMax(a,b)
  %1748 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %1748, label %1749, label %1772

; <label>:1749                                    ; preds = %1721
  %1750 = call float @dx.op.unary.f32(i32 6, float %1738)  ; FAbs(value)
  %1751 = fmul fast float %1750, %12
  %1752 = fcmp fast olt float %1751, 0x3F50624DE0000000
  br i1 %1752, label %1753, label %1756

; <label>:1753                                    ; preds = %1749
  %1754 = fmul fast float %1751, 5.000000e-01
  %1755 = fsub fast float 1.000000e+00, %1754
  br label %1761

; <label>:1756                                    ; preds = %1749
  %1757 = fmul fast float %1751, 0xBFF7154760000000
  %1758 = call float @dx.op.unary.f32(i32 21, float %1757)  ; Exp(value)
  %1759 = fsub fast float 1.000000e+00, %1758
  %1760 = fdiv fast float %1759, %1751
  br label %1761

; <label>:1761                                    ; preds = %1756, %1753
  %1762 = phi float [ %1755, %1753 ], [ %1760, %1756 ]
  %1763 = call float @dx.op.binary.f32(i32 36, float %1735, float %19)  ; FMin(a,b)
  %1764 = fsub fast float %1763, %11
  %1765 = fmul fast float %12, %1764
  %1766 = fsub fast float -0.000000e+00, %1765
  %1767 = call float @dx.op.binary.f32(i32 35, float %1766, float -4.000000e+01)  ; FMax(a,b)
  %1768 = call float @dx.op.binary.f32(i32 36, float %1767, float 5.000000e+00)  ; FMin(a,b)
  %1769 = fmul fast float %1768, 0x3FF7154760000000
  %1770 = call float @dx.op.unary.f32(i32 21, float %1769)  ; Exp(value)
  %1771 = fmul fast float %1770, %1762
  br label %1772

; <label>:1772                                    ; preds = %1761, %1721
  %1773 = phi float [ %1771, %1761 ], [ 1.000000e+00, %1721 ]
  %1774 = fmul fast float %1747, %17
  %1775 = fmul fast float %1774, %1773
  %1776 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1775)  ; FMin(a,b)
  %1777 = fmul fast float %1776, 0xBFF7154760000000
  %1778 = call float @dx.op.unary.f32(i32 21, float %1777)  ; Exp(value)
  %1779 = fsub fast float 1.000000e+00, %1778
  %1780 = call float @dx.op.binary.f32(i32 36, float %13, float %1779)  ; FMin(a,b)
  %1781 = fsub fast float %14, %1659
  %1782 = fsub fast float %15, %1660
  %1783 = fsub fast float %16, %1661
  %1784 = fmul fast float %1780, %1781
  %1785 = fmul fast float %1780, %1782
  %1786 = fmul fast float %1780, %1783
  %1787 = fadd fast float %1784, %1659
  %1788 = fadd fast float %1785, %1660
  %1789 = fadd fast float %1786, %1661
  br label %1790

; <label>:1790                                    ; preds = %1772, %1704, %1698
  %1791 = phi float [ %1787, %1772 ], [ %1659, %1704 ], [ %1659, %1698 ]
  %1792 = phi float [ %1788, %1772 ], [ %1660, %1704 ], [ %1660, %1698 ]
  %1793 = phi float [ %1789, %1772 ], [ %1661, %1704 ], [ %1661, %1698 ]
  %1794 = fadd fast float %6, 1.000000e+00
  %1795 = fadd fast float %7, 1.000000e+00
  %1796 = fsub fast float 1.000000e+00, %6
  %1797 = fmul fast float %37, %1794
  %1798 = fmul fast float %37, %1795
  %1799 = fmul fast float %37, %1796
  %1800 = fmul fast float %1797, %1791
  %1801 = fmul fast float %1798, %1792
  %1802 = fmul fast float %1799, %1793
  %1803 = fcmp fast ult float %38, 5.000000e-01
  br i1 %1803, label %1829, label %1804

; <label>:1804                                    ; preds = %1790
  %1805 = fmul fast float %1800, 0x4004147AE0000000
  %1806 = fmul fast float %1801, 0x4004147AE0000000
  %1807 = fmul fast float %1802, 0x4004147AE0000000
  %1808 = fadd fast float %1805, 0x3F9EB851E0000000
  %1809 = fadd fast float %1806, 0x3F9EB851E0000000
  %1810 = fadd fast float %1807, 0x3F9EB851E0000000
  %1811 = fmul fast float %1808, %1800
  %1812 = fmul fast float %1809, %1801
  %1813 = fmul fast float %1810, %1802
  %1814 = fmul fast float %1800, 0x400370A3E0000000
  %1815 = fmul fast float %1801, 0x400370A3E0000000
  %1816 = fmul fast float %1802, 0x400370A3E0000000
  %1817 = fadd fast float %1814, 0x3FE2E147A0000000
  %1818 = fadd fast float %1815, 0x3FE2E147A0000000
  %1819 = fadd fast float %1816, 0x3FE2E147A0000000
  %1820 = fmul fast float %1817, %1800
  %1821 = fmul fast float %1818, %1801
  %1822 = fmul fast float %1819, %1802
  %1823 = fadd fast float %1820, 0x3FC1EB8520000000
  %1824 = fadd fast float %1821, 0x3FC1EB8520000000
  %1825 = fadd fast float %1822, 0x3FC1EB8520000000
  %1826 = fdiv fast float %1811, %1823
  %1827 = fdiv fast float %1812, %1824
  %1828 = fdiv fast float %1813, %1825
  br label %1829

; <label>:1829                                    ; preds = %1804, %1790
  %1830 = phi float [ %1826, %1804 ], [ %1800, %1790 ]
  %1831 = phi float [ %1827, %1804 ], [ %1801, %1790 ]
  %1832 = phi float [ %1828, %1804 ], [ %1802, %1790 ]
  %1833 = call float @dx.op.unary.f32(i32 7, float %1830)  ; Saturate(value)
  %1834 = call float @dx.op.unary.f32(i32 7, float %1831)  ; Saturate(value)
  %1835 = call float @dx.op.unary.f32(i32 7, float %1832)  ; Saturate(value)
  %1836 = call float @dx.op.dot3.f32(i32 55, float %1833, float %1834, float %1835, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1837 = fsub fast float %1833, %1836
  %1838 = fsub fast float %1834, %1836
  %1839 = fsub fast float %1835, %1836
  %1840 = fmul fast float %1837, %9
  %1841 = fmul fast float %1838, %9
  %1842 = fmul fast float %1839, %9
  %1843 = fadd fast float %1840, %1836
  %1844 = fadd fast float %1841, %1836
  %1845 = fadd fast float %1842, %1836
  %1846 = call float @dx.op.unary.f32(i32 7, float %1843)  ; Saturate(value)
  %1847 = call float @dx.op.unary.f32(i32 7, float %1844)  ; Saturate(value)
  %1848 = call float @dx.op.unary.f32(i32 7, float %1845)  ; Saturate(value)
  %1849 = fadd fast float %1846, 0xBFC70A3D80000000
  %1850 = fadd fast float %1847, 0xBFC70A3D80000000
  %1851 = fadd fast float %1848, 0xBFC70A3D80000000
  %1852 = fmul fast float %1849, %8
  %1853 = fmul fast float %1850, %8
  %1854 = fmul fast float %1851, %8
  %1855 = fadd fast float %1852, 0x3FC70A3D80000000
  %1856 = fadd fast float %1853, 0x3FC70A3D80000000
  %1857 = fadd fast float %1854, 0x3FC70A3D80000000
  %1858 = call float @dx.op.unary.f32(i32 7, float %1855)  ; Saturate(value)
  %1859 = call float @dx.op.unary.f32(i32 7, float %1856)  ; Saturate(value)
  %1860 = call float @dx.op.unary.f32(i32 7, float %1857)  ; Saturate(value)
  br label %1861

; <label>:1861                                    ; preds = %1829, %1664
  %1862 = phi float [ %1695, %1664 ], [ %1858, %1829 ]
  %1863 = phi float [ %1696, %1664 ], [ %1859, %1829 ]
  %1864 = phi float [ %1697, %1664 ], [ %1860, %1829 ]
  %1865 = fsub fast float %1862, %1632
  %1866 = fsub fast float %1863, %1633
  %1867 = fsub fast float %1864, %1634
  %1868 = fmul fast float %1865, %1651
  %1869 = fmul fast float %1866, %1651
  %1870 = fmul fast float %1867, %1651
  %1871 = fadd fast float %1868, %1632
  %1872 = fadd fast float %1869, %1633
  %1873 = fadd fast float %1870, %1634
  br label %1874

; <label>:1874                                    ; preds = %1861, %1636
  %1875 = phi float [ %1871, %1861 ], [ %1632, %1636 ]
  %1876 = phi float [ %1872, %1861 ], [ %1633, %1636 ]
  %1877 = phi float [ %1873, %1861 ], [ %1634, %1636 ]
  %1878 = add i32 %65, 1
  %1879 = call i32 @dx.op.binary.i32(i32 37, i32 %1878, i32 0)  ; IMax(a,b)
  %1880 = call i32 @dx.op.binary.i32(i32 38, i32 %1879, i32 %61)  ; IMin(a,b)
  %1881 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1640, i32 %1880, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1882 = extractvalue %dx.types.ResRet.f32 %1881, 0
  %1883 = fsub fast float %1882, %85
  %1884 = call float @dx.op.unary.f32(i32 6, float %1883)  ; FAbs(value)
  %1885 = fdiv fast float %1884, %1646
  %1886 = fsub fast float 1.000000e+00, %1885
  %1887 = call float @dx.op.unary.f32(i32 7, float %1886)  ; Saturate(value)
  %1888 = fcmp fast ugt float %1887, 0.000000e+00
  br i1 %1888, label %1889, label %2110

; <label>:1889                                    ; preds = %1874
  %1890 = call i32 @dx.op.binary.i32(i32 37, i32 %1640, i32 0)  ; IMax(a,b)
  %1891 = call i32 @dx.op.binary.i32(i32 37, i32 %1880, i32 0)  ; IMax(a,b)
  %1892 = call i32 @dx.op.binary.i32(i32 38, i32 %1890, i32 %60)  ; IMin(a,b)
  %1893 = call i32 @dx.op.binary.i32(i32 38, i32 %1891, i32 %61)  ; IMin(a,b)
  %1894 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1892, i32 %1893, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1895 = extractvalue %dx.types.ResRet.f32 %1894, 0
  %1896 = extractvalue %dx.types.ResRet.f32 %1894, 1
  %1897 = extractvalue %dx.types.ResRet.f32 %1894, 2
  %1898 = extractvalue %dx.types.ResRet.f32 %1894, 3
  %1899 = fcmp fast olt float %1898, 0.000000e+00
  br i1 %1899, label %1900, label %1934

; <label>:1900                                    ; preds = %1889
  %1901 = fcmp fast ogt float %1895, 0x3FA4B5DCC0000000
  %1902 = fcmp fast ogt float %1896, 0x3FA4B5DCC0000000
  %1903 = fcmp fast ogt float %1897, 0x3FA4B5DCC0000000
  %1904 = select i1 %1901, float 0.000000e+00, float 1.000000e+00
  %1905 = select i1 %1902, float 0.000000e+00, float 1.000000e+00
  %1906 = select i1 %1903, float 0.000000e+00, float 1.000000e+00
  %1907 = fmul fast float %1895, 0x3FB3D07220000000
  %1908 = fmul fast float %1896, 0x3FB3D07220000000
  %1909 = fmul fast float %1897, 0x3FB3D07220000000
  %1910 = fadd fast float %1895, 0x3FAC28F5C0000000
  %1911 = fadd fast float %1896, 0x3FAC28F5C0000000
  %1912 = fadd fast float %1897, 0x3FAC28F5C0000000
  %1913 = fmul fast float %1910, 0x3FEE54EDE0000000
  %1914 = fmul fast float %1911, 0x3FEE54EDE0000000
  %1915 = fmul fast float %1912, 0x3FEE54EDE0000000
  %1916 = call float @dx.op.unary.f32(i32 23, float %1913)  ; Log(value)
  %1917 = call float @dx.op.unary.f32(i32 23, float %1914)  ; Log(value)
  %1918 = call float @dx.op.unary.f32(i32 23, float %1915)  ; Log(value)
  %1919 = fmul fast float %1916, 0x4003333340000000
  %1920 = fmul fast float %1917, 0x4003333340000000
  %1921 = fmul fast float %1918, 0x4003333340000000
  %1922 = call float @dx.op.unary.f32(i32 21, float %1919)  ; Exp(value)
  %1923 = call float @dx.op.unary.f32(i32 21, float %1920)  ; Exp(value)
  %1924 = call float @dx.op.unary.f32(i32 21, float %1921)  ; Exp(value)
  %1925 = fsub fast float %1907, %1922
  %1926 = fsub fast float %1908, %1923
  %1927 = fsub fast float %1909, %1924
  %1928 = fmul fast float %1925, %1904
  %1929 = fmul fast float %1926, %1905
  %1930 = fmul fast float %1927, %1906
  %1931 = fadd fast float %1928, %1922
  %1932 = fadd fast float %1929, %1923
  %1933 = fadd fast float %1930, %1924
  br label %2097

; <label>:1934                                    ; preds = %1889
  %1935 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1892, i32 %1893, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1936 = extractvalue %dx.types.ResRet.f32 %1935, 0
  %1937 = fcmp fast ogt float %39, 5.000000e-01
  %1938 = fcmp fast olt float %1936, 1.000000e+00
  %1939 = and i1 %1937, %1938
  br i1 %1939, label %1940, label %2026

; <label>:1940                                    ; preds = %1934
  %1941 = sitofp i32 %1892 to float
  %1942 = sitofp i32 %1893 to float
  %1943 = fadd fast float %1941, 5.000000e-01
  %1944 = fadd fast float %1942, 5.000000e-01
  %1945 = fdiv fast float %1943, %46
  %1946 = fdiv fast float %1944, %47
  %1947 = fmul fast float %1945, 2.000000e+00
  %1948 = fmul fast float %1946, 2.000000e+00
  %1949 = fadd fast float %1947, -1.000000e+00
  %1950 = fsub fast float 1.000000e+00, %1948
  %1951 = fmul fast float %1949, %36
  %1952 = call float @dx.op.tertiary.f32(i32 46, float %1950, float %32, float %1951)  ; FMad(a,b,c)
  %1953 = call float @dx.op.tertiary.f32(i32 46, float %1936, float %28, float %1952)  ; FMad(a,b,c)
  %1954 = fadd fast float %1953, %24
  %1955 = call float @dx.op.unary.f32(i32 6, float %1954)  ; FAbs(value)
  %1956 = fcmp fast ogt float %1955, 0x3EB0C6F7A0000000
  br i1 %1956, label %1957, label %2026

; <label>:1957                                    ; preds = %1940
  %1958 = fmul fast float %1949, %35
  %1959 = call float @dx.op.tertiary.f32(i32 46, float %1950, float %31, float %1958)  ; FMad(a,b,c)
  %1960 = call float @dx.op.tertiary.f32(i32 46, float %1936, float %27, float %1959)  ; FMad(a,b,c)
  %1961 = fadd fast float %1960, %23
  %1962 = fmul fast float %1949, %34
  %1963 = call float @dx.op.tertiary.f32(i32 46, float %1950, float %30, float %1962)  ; FMad(a,b,c)
  %1964 = call float @dx.op.tertiary.f32(i32 46, float %1936, float %26, float %1963)  ; FMad(a,b,c)
  %1965 = fadd fast float %1964, %22
  %1966 = fmul fast float %1949, %33
  %1967 = call float @dx.op.tertiary.f32(i32 46, float %1950, float %29, float %1966)  ; FMad(a,b,c)
  %1968 = call float @dx.op.tertiary.f32(i32 46, float %1936, float %25, float %1967)  ; FMad(a,b,c)
  %1969 = fadd fast float %1968, %21
  %1970 = fdiv fast float %1969, %1954
  %1971 = fdiv fast float %1965, %1954
  %1972 = fdiv fast float %1961, %1954
  %1973 = fsub fast float %1970, %18
  %1974 = fsub fast float %1971, %19
  %1975 = fsub fast float %1972, %20
  %1976 = fmul fast float %1973, %1973
  %1977 = fmul fast float %1974, %1974
  %1978 = fadd fast float %1977, %1976
  %1979 = fmul fast float %1975, %1975
  %1980 = fadd fast float %1978, %1979
  %1981 = call float @dx.op.unary.f32(i32 24, float %1980)  ; Sqrt(value)
  %1982 = fsub fast float %1981, %10
  %1983 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1982)  ; FMax(a,b)
  %1984 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %1984, label %1985, label %2008

; <label>:1985                                    ; preds = %1957
  %1986 = call float @dx.op.unary.f32(i32 6, float %1974)  ; FAbs(value)
  %1987 = fmul fast float %1986, %12
  %1988 = fcmp fast olt float %1987, 0x3F50624DE0000000
  br i1 %1988, label %1989, label %1992

; <label>:1989                                    ; preds = %1985
  %1990 = fmul fast float %1987, 5.000000e-01
  %1991 = fsub fast float 1.000000e+00, %1990
  br label %1997

; <label>:1992                                    ; preds = %1985
  %1993 = fmul fast float %1987, 0xBFF7154760000000
  %1994 = call float @dx.op.unary.f32(i32 21, float %1993)  ; Exp(value)
  %1995 = fsub fast float 1.000000e+00, %1994
  %1996 = fdiv fast float %1995, %1987
  br label %1997

; <label>:1997                                    ; preds = %1992, %1989
  %1998 = phi float [ %1991, %1989 ], [ %1996, %1992 ]
  %1999 = call float @dx.op.binary.f32(i32 36, float %1971, float %19)  ; FMin(a,b)
  %2000 = fsub fast float %1999, %11
  %2001 = fmul fast float %12, %2000
  %2002 = fsub fast float -0.000000e+00, %2001
  %2003 = call float @dx.op.binary.f32(i32 35, float %2002, float -4.000000e+01)  ; FMax(a,b)
  %2004 = call float @dx.op.binary.f32(i32 36, float %2003, float 5.000000e+00)  ; FMin(a,b)
  %2005 = fmul fast float %2004, 0x3FF7154760000000
  %2006 = call float @dx.op.unary.f32(i32 21, float %2005)  ; Exp(value)
  %2007 = fmul fast float %2006, %1998
  br label %2008

; <label>:2008                                    ; preds = %1997, %1957
  %2009 = phi float [ %2007, %1997 ], [ 1.000000e+00, %1957 ]
  %2010 = fmul fast float %1983, %17
  %2011 = fmul fast float %2010, %2009
  %2012 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2011)  ; FMin(a,b)
  %2013 = fmul fast float %2012, 0xBFF7154760000000
  %2014 = call float @dx.op.unary.f32(i32 21, float %2013)  ; Exp(value)
  %2015 = fsub fast float 1.000000e+00, %2014
  %2016 = call float @dx.op.binary.f32(i32 36, float %13, float %2015)  ; FMin(a,b)
  %2017 = fsub fast float %14, %1895
  %2018 = fsub fast float %15, %1896
  %2019 = fsub fast float %16, %1897
  %2020 = fmul fast float %2016, %2017
  %2021 = fmul fast float %2016, %2018
  %2022 = fmul fast float %2016, %2019
  %2023 = fadd fast float %2020, %1895
  %2024 = fadd fast float %2021, %1896
  %2025 = fadd fast float %2022, %1897
  br label %2026

; <label>:2026                                    ; preds = %2008, %1940, %1934
  %2027 = phi float [ %2023, %2008 ], [ %1895, %1940 ], [ %1895, %1934 ]
  %2028 = phi float [ %2024, %2008 ], [ %1896, %1940 ], [ %1896, %1934 ]
  %2029 = phi float [ %2025, %2008 ], [ %1897, %1940 ], [ %1897, %1934 ]
  %2030 = fadd fast float %6, 1.000000e+00
  %2031 = fadd fast float %7, 1.000000e+00
  %2032 = fsub fast float 1.000000e+00, %6
  %2033 = fmul fast float %37, %2030
  %2034 = fmul fast float %37, %2031
  %2035 = fmul fast float %37, %2032
  %2036 = fmul fast float %2033, %2027
  %2037 = fmul fast float %2034, %2028
  %2038 = fmul fast float %2035, %2029
  %2039 = fcmp fast ult float %38, 5.000000e-01
  br i1 %2039, label %2065, label %2040

; <label>:2040                                    ; preds = %2026
  %2041 = fmul fast float %2036, 0x4004147AE0000000
  %2042 = fmul fast float %2037, 0x4004147AE0000000
  %2043 = fmul fast float %2038, 0x4004147AE0000000
  %2044 = fadd fast float %2041, 0x3F9EB851E0000000
  %2045 = fadd fast float %2042, 0x3F9EB851E0000000
  %2046 = fadd fast float %2043, 0x3F9EB851E0000000
  %2047 = fmul fast float %2044, %2036
  %2048 = fmul fast float %2045, %2037
  %2049 = fmul fast float %2046, %2038
  %2050 = fmul fast float %2036, 0x400370A3E0000000
  %2051 = fmul fast float %2037, 0x400370A3E0000000
  %2052 = fmul fast float %2038, 0x400370A3E0000000
  %2053 = fadd fast float %2050, 0x3FE2E147A0000000
  %2054 = fadd fast float %2051, 0x3FE2E147A0000000
  %2055 = fadd fast float %2052, 0x3FE2E147A0000000
  %2056 = fmul fast float %2053, %2036
  %2057 = fmul fast float %2054, %2037
  %2058 = fmul fast float %2055, %2038
  %2059 = fadd fast float %2056, 0x3FC1EB8520000000
  %2060 = fadd fast float %2057, 0x3FC1EB8520000000
  %2061 = fadd fast float %2058, 0x3FC1EB8520000000
  %2062 = fdiv fast float %2047, %2059
  %2063 = fdiv fast float %2048, %2060
  %2064 = fdiv fast float %2049, %2061
  br label %2065

; <label>:2065                                    ; preds = %2040, %2026
  %2066 = phi float [ %2062, %2040 ], [ %2036, %2026 ]
  %2067 = phi float [ %2063, %2040 ], [ %2037, %2026 ]
  %2068 = phi float [ %2064, %2040 ], [ %2038, %2026 ]
  %2069 = call float @dx.op.unary.f32(i32 7, float %2066)  ; Saturate(value)
  %2070 = call float @dx.op.unary.f32(i32 7, float %2067)  ; Saturate(value)
  %2071 = call float @dx.op.unary.f32(i32 7, float %2068)  ; Saturate(value)
  %2072 = call float @dx.op.dot3.f32(i32 55, float %2069, float %2070, float %2071, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2073 = fsub fast float %2069, %2072
  %2074 = fsub fast float %2070, %2072
  %2075 = fsub fast float %2071, %2072
  %2076 = fmul fast float %2073, %9
  %2077 = fmul fast float %2074, %9
  %2078 = fmul fast float %2075, %9
  %2079 = fadd fast float %2076, %2072
  %2080 = fadd fast float %2077, %2072
  %2081 = fadd fast float %2078, %2072
  %2082 = call float @dx.op.unary.f32(i32 7, float %2079)  ; Saturate(value)
  %2083 = call float @dx.op.unary.f32(i32 7, float %2080)  ; Saturate(value)
  %2084 = call float @dx.op.unary.f32(i32 7, float %2081)  ; Saturate(value)
  %2085 = fadd fast float %2082, 0xBFC70A3D80000000
  %2086 = fadd fast float %2083, 0xBFC70A3D80000000
  %2087 = fadd fast float %2084, 0xBFC70A3D80000000
  %2088 = fmul fast float %2085, %8
  %2089 = fmul fast float %2086, %8
  %2090 = fmul fast float %2087, %8
  %2091 = fadd fast float %2088, 0x3FC70A3D80000000
  %2092 = fadd fast float %2089, 0x3FC70A3D80000000
  %2093 = fadd fast float %2090, 0x3FC70A3D80000000
  %2094 = call float @dx.op.unary.f32(i32 7, float %2091)  ; Saturate(value)
  %2095 = call float @dx.op.unary.f32(i32 7, float %2092)  ; Saturate(value)
  %2096 = call float @dx.op.unary.f32(i32 7, float %2093)  ; Saturate(value)
  br label %2097

; <label>:2097                                    ; preds = %2065, %1900
  %2098 = phi float [ %1931, %1900 ], [ %2094, %2065 ]
  %2099 = phi float [ %1932, %1900 ], [ %2095, %2065 ]
  %2100 = phi float [ %1933, %1900 ], [ %2096, %2065 ]
  %2101 = fsub fast float %2098, %1632
  %2102 = fsub fast float %2099, %1633
  %2103 = fsub fast float %2100, %1634
  %2104 = fmul fast float %2101, %1887
  %2105 = fmul fast float %2102, %1887
  %2106 = fmul fast float %2103, %1887
  %2107 = fadd fast float %2104, %1632
  %2108 = fadd fast float %2105, %1633
  %2109 = fadd fast float %2106, %1634
  br label %2110

; <label>:2110                                    ; preds = %2097, %1874
  %2111 = phi float [ %2107, %2097 ], [ %1632, %1874 ]
  %2112 = phi float [ %2108, %2097 ], [ %1633, %1874 ]
  %2113 = phi float [ %2109, %2097 ], [ %1634, %1874 ]
  %2114 = add i32 %68, -1
  %2115 = call i32 @dx.op.binary.i32(i32 37, i32 %2114, i32 0)  ; IMax(a,b)
  %2116 = call i32 @dx.op.binary.i32(i32 37, i32 %65, i32 0)  ; IMax(a,b)
  %2117 = call i32 @dx.op.binary.i32(i32 38, i32 %2115, i32 %60)  ; IMin(a,b)
  %2118 = call i32 @dx.op.binary.i32(i32 38, i32 %2116, i32 %61)  ; IMin(a,b)
  %2119 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2117, i32 %2118, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2120 = extractvalue %dx.types.ResRet.f32 %2119, 0
  %2121 = fsub fast float %2120, %85
  %2122 = call float @dx.op.unary.f32(i32 6, float %2121)  ; FAbs(value)
  %2123 = fdiv fast float %2122, %1646
  %2124 = fsub fast float 1.000000e+00, %2123
  %2125 = call float @dx.op.unary.f32(i32 7, float %2124)  ; Saturate(value)
  %2126 = fcmp fast ugt float %2125, 0.000000e+00
  br i1 %2126, label %2127, label %2348

; <label>:2127                                    ; preds = %2110
  %2128 = call i32 @dx.op.binary.i32(i32 37, i32 %2117, i32 0)  ; IMax(a,b)
  %2129 = call i32 @dx.op.binary.i32(i32 37, i32 %2118, i32 0)  ; IMax(a,b)
  %2130 = call i32 @dx.op.binary.i32(i32 38, i32 %2128, i32 %60)  ; IMin(a,b)
  %2131 = call i32 @dx.op.binary.i32(i32 38, i32 %2129, i32 %61)  ; IMin(a,b)
  %2132 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2130, i32 %2131, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2133 = extractvalue %dx.types.ResRet.f32 %2132, 0
  %2134 = extractvalue %dx.types.ResRet.f32 %2132, 1
  %2135 = extractvalue %dx.types.ResRet.f32 %2132, 2
  %2136 = extractvalue %dx.types.ResRet.f32 %2132, 3
  %2137 = fcmp fast olt float %2136, 0.000000e+00
  br i1 %2137, label %2138, label %2172

; <label>:2138                                    ; preds = %2127
  %2139 = fcmp fast ogt float %2133, 0x3FA4B5DCC0000000
  %2140 = fcmp fast ogt float %2134, 0x3FA4B5DCC0000000
  %2141 = fcmp fast ogt float %2135, 0x3FA4B5DCC0000000
  %2142 = select i1 %2139, float 0.000000e+00, float 1.000000e+00
  %2143 = select i1 %2140, float 0.000000e+00, float 1.000000e+00
  %2144 = select i1 %2141, float 0.000000e+00, float 1.000000e+00
  %2145 = fmul fast float %2133, 0x3FB3D07220000000
  %2146 = fmul fast float %2134, 0x3FB3D07220000000
  %2147 = fmul fast float %2135, 0x3FB3D07220000000
  %2148 = fadd fast float %2133, 0x3FAC28F5C0000000
  %2149 = fadd fast float %2134, 0x3FAC28F5C0000000
  %2150 = fadd fast float %2135, 0x3FAC28F5C0000000
  %2151 = fmul fast float %2148, 0x3FEE54EDE0000000
  %2152 = fmul fast float %2149, 0x3FEE54EDE0000000
  %2153 = fmul fast float %2150, 0x3FEE54EDE0000000
  %2154 = call float @dx.op.unary.f32(i32 23, float %2151)  ; Log(value)
  %2155 = call float @dx.op.unary.f32(i32 23, float %2152)  ; Log(value)
  %2156 = call float @dx.op.unary.f32(i32 23, float %2153)  ; Log(value)
  %2157 = fmul fast float %2154, 0x4003333340000000
  %2158 = fmul fast float %2155, 0x4003333340000000
  %2159 = fmul fast float %2156, 0x4003333340000000
  %2160 = call float @dx.op.unary.f32(i32 21, float %2157)  ; Exp(value)
  %2161 = call float @dx.op.unary.f32(i32 21, float %2158)  ; Exp(value)
  %2162 = call float @dx.op.unary.f32(i32 21, float %2159)  ; Exp(value)
  %2163 = fsub fast float %2145, %2160
  %2164 = fsub fast float %2146, %2161
  %2165 = fsub fast float %2147, %2162
  %2166 = fmul fast float %2163, %2142
  %2167 = fmul fast float %2164, %2143
  %2168 = fmul fast float %2165, %2144
  %2169 = fadd fast float %2166, %2160
  %2170 = fadd fast float %2167, %2161
  %2171 = fadd fast float %2168, %2162
  br label %2335

; <label>:2172                                    ; preds = %2127
  %2173 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2130, i32 %2131, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2174 = extractvalue %dx.types.ResRet.f32 %2173, 0
  %2175 = fcmp fast ogt float %39, 5.000000e-01
  %2176 = fcmp fast olt float %2174, 1.000000e+00
  %2177 = and i1 %2175, %2176
  br i1 %2177, label %2178, label %2264

; <label>:2178                                    ; preds = %2172
  %2179 = sitofp i32 %2130 to float
  %2180 = sitofp i32 %2131 to float
  %2181 = fadd fast float %2179, 5.000000e-01
  %2182 = fadd fast float %2180, 5.000000e-01
  %2183 = fdiv fast float %2181, %46
  %2184 = fdiv fast float %2182, %47
  %2185 = fmul fast float %2183, 2.000000e+00
  %2186 = fmul fast float %2184, 2.000000e+00
  %2187 = fadd fast float %2185, -1.000000e+00
  %2188 = fsub fast float 1.000000e+00, %2186
  %2189 = fmul fast float %2187, %36
  %2190 = call float @dx.op.tertiary.f32(i32 46, float %2188, float %32, float %2189)  ; FMad(a,b,c)
  %2191 = call float @dx.op.tertiary.f32(i32 46, float %2174, float %28, float %2190)  ; FMad(a,b,c)
  %2192 = fadd fast float %2191, %24
  %2193 = call float @dx.op.unary.f32(i32 6, float %2192)  ; FAbs(value)
  %2194 = fcmp fast ogt float %2193, 0x3EB0C6F7A0000000
  br i1 %2194, label %2195, label %2264

; <label>:2195                                    ; preds = %2178
  %2196 = fmul fast float %2187, %35
  %2197 = call float @dx.op.tertiary.f32(i32 46, float %2188, float %31, float %2196)  ; FMad(a,b,c)
  %2198 = call float @dx.op.tertiary.f32(i32 46, float %2174, float %27, float %2197)  ; FMad(a,b,c)
  %2199 = fadd fast float %2198, %23
  %2200 = fmul fast float %2187, %34
  %2201 = call float @dx.op.tertiary.f32(i32 46, float %2188, float %30, float %2200)  ; FMad(a,b,c)
  %2202 = call float @dx.op.tertiary.f32(i32 46, float %2174, float %26, float %2201)  ; FMad(a,b,c)
  %2203 = fadd fast float %2202, %22
  %2204 = fmul fast float %2187, %33
  %2205 = call float @dx.op.tertiary.f32(i32 46, float %2188, float %29, float %2204)  ; FMad(a,b,c)
  %2206 = call float @dx.op.tertiary.f32(i32 46, float %2174, float %25, float %2205)  ; FMad(a,b,c)
  %2207 = fadd fast float %2206, %21
  %2208 = fdiv fast float %2207, %2192
  %2209 = fdiv fast float %2203, %2192
  %2210 = fdiv fast float %2199, %2192
  %2211 = fsub fast float %2208, %18
  %2212 = fsub fast float %2209, %19
  %2213 = fsub fast float %2210, %20
  %2214 = fmul fast float %2211, %2211
  %2215 = fmul fast float %2212, %2212
  %2216 = fadd fast float %2215, %2214
  %2217 = fmul fast float %2213, %2213
  %2218 = fadd fast float %2216, %2217
  %2219 = call float @dx.op.unary.f32(i32 24, float %2218)  ; Sqrt(value)
  %2220 = fsub fast float %2219, %10
  %2221 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2220)  ; FMax(a,b)
  %2222 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %2222, label %2223, label %2246

; <label>:2223                                    ; preds = %2195
  %2224 = call float @dx.op.unary.f32(i32 6, float %2212)  ; FAbs(value)
  %2225 = fmul fast float %2224, %12
  %2226 = fcmp fast olt float %2225, 0x3F50624DE0000000
  br i1 %2226, label %2227, label %2230

; <label>:2227                                    ; preds = %2223
  %2228 = fmul fast float %2225, 5.000000e-01
  %2229 = fsub fast float 1.000000e+00, %2228
  br label %2235

; <label>:2230                                    ; preds = %2223
  %2231 = fmul fast float %2225, 0xBFF7154760000000
  %2232 = call float @dx.op.unary.f32(i32 21, float %2231)  ; Exp(value)
  %2233 = fsub fast float 1.000000e+00, %2232
  %2234 = fdiv fast float %2233, %2225
  br label %2235

; <label>:2235                                    ; preds = %2230, %2227
  %2236 = phi float [ %2229, %2227 ], [ %2234, %2230 ]
  %2237 = call float @dx.op.binary.f32(i32 36, float %2209, float %19)  ; FMin(a,b)
  %2238 = fsub fast float %2237, %11
  %2239 = fmul fast float %12, %2238
  %2240 = fsub fast float -0.000000e+00, %2239
  %2241 = call float @dx.op.binary.f32(i32 35, float %2240, float -4.000000e+01)  ; FMax(a,b)
  %2242 = call float @dx.op.binary.f32(i32 36, float %2241, float 5.000000e+00)  ; FMin(a,b)
  %2243 = fmul fast float %2242, 0x3FF7154760000000
  %2244 = call float @dx.op.unary.f32(i32 21, float %2243)  ; Exp(value)
  %2245 = fmul fast float %2244, %2236
  br label %2246

; <label>:2246                                    ; preds = %2235, %2195
  %2247 = phi float [ %2245, %2235 ], [ 1.000000e+00, %2195 ]
  %2248 = fmul fast float %2221, %17
  %2249 = fmul fast float %2248, %2247
  %2250 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2249)  ; FMin(a,b)
  %2251 = fmul fast float %2250, 0xBFF7154760000000
  %2252 = call float @dx.op.unary.f32(i32 21, float %2251)  ; Exp(value)
  %2253 = fsub fast float 1.000000e+00, %2252
  %2254 = call float @dx.op.binary.f32(i32 36, float %13, float %2253)  ; FMin(a,b)
  %2255 = fsub fast float %14, %2133
  %2256 = fsub fast float %15, %2134
  %2257 = fsub fast float %16, %2135
  %2258 = fmul fast float %2254, %2255
  %2259 = fmul fast float %2254, %2256
  %2260 = fmul fast float %2254, %2257
  %2261 = fadd fast float %2258, %2133
  %2262 = fadd fast float %2259, %2134
  %2263 = fadd fast float %2260, %2135
  br label %2264

; <label>:2264                                    ; preds = %2246, %2178, %2172
  %2265 = phi float [ %2261, %2246 ], [ %2133, %2178 ], [ %2133, %2172 ]
  %2266 = phi float [ %2262, %2246 ], [ %2134, %2178 ], [ %2134, %2172 ]
  %2267 = phi float [ %2263, %2246 ], [ %2135, %2178 ], [ %2135, %2172 ]
  %2268 = fadd fast float %6, 1.000000e+00
  %2269 = fadd fast float %7, 1.000000e+00
  %2270 = fsub fast float 1.000000e+00, %6
  %2271 = fmul fast float %37, %2268
  %2272 = fmul fast float %37, %2269
  %2273 = fmul fast float %37, %2270
  %2274 = fmul fast float %2271, %2265
  %2275 = fmul fast float %2272, %2266
  %2276 = fmul fast float %2273, %2267
  %2277 = fcmp fast ult float %38, 5.000000e-01
  br i1 %2277, label %2303, label %2278

; <label>:2278                                    ; preds = %2264
  %2279 = fmul fast float %2274, 0x4004147AE0000000
  %2280 = fmul fast float %2275, 0x4004147AE0000000
  %2281 = fmul fast float %2276, 0x4004147AE0000000
  %2282 = fadd fast float %2279, 0x3F9EB851E0000000
  %2283 = fadd fast float %2280, 0x3F9EB851E0000000
  %2284 = fadd fast float %2281, 0x3F9EB851E0000000
  %2285 = fmul fast float %2282, %2274
  %2286 = fmul fast float %2283, %2275
  %2287 = fmul fast float %2284, %2276
  %2288 = fmul fast float %2274, 0x400370A3E0000000
  %2289 = fmul fast float %2275, 0x400370A3E0000000
  %2290 = fmul fast float %2276, 0x400370A3E0000000
  %2291 = fadd fast float %2288, 0x3FE2E147A0000000
  %2292 = fadd fast float %2289, 0x3FE2E147A0000000
  %2293 = fadd fast float %2290, 0x3FE2E147A0000000
  %2294 = fmul fast float %2291, %2274
  %2295 = fmul fast float %2292, %2275
  %2296 = fmul fast float %2293, %2276
  %2297 = fadd fast float %2294, 0x3FC1EB8520000000
  %2298 = fadd fast float %2295, 0x3FC1EB8520000000
  %2299 = fadd fast float %2296, 0x3FC1EB8520000000
  %2300 = fdiv fast float %2285, %2297
  %2301 = fdiv fast float %2286, %2298
  %2302 = fdiv fast float %2287, %2299
  br label %2303

; <label>:2303                                    ; preds = %2278, %2264
  %2304 = phi float [ %2300, %2278 ], [ %2274, %2264 ]
  %2305 = phi float [ %2301, %2278 ], [ %2275, %2264 ]
  %2306 = phi float [ %2302, %2278 ], [ %2276, %2264 ]
  %2307 = call float @dx.op.unary.f32(i32 7, float %2304)  ; Saturate(value)
  %2308 = call float @dx.op.unary.f32(i32 7, float %2305)  ; Saturate(value)
  %2309 = call float @dx.op.unary.f32(i32 7, float %2306)  ; Saturate(value)
  %2310 = call float @dx.op.dot3.f32(i32 55, float %2307, float %2308, float %2309, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2311 = fsub fast float %2307, %2310
  %2312 = fsub fast float %2308, %2310
  %2313 = fsub fast float %2309, %2310
  %2314 = fmul fast float %2311, %9
  %2315 = fmul fast float %2312, %9
  %2316 = fmul fast float %2313, %9
  %2317 = fadd fast float %2314, %2310
  %2318 = fadd fast float %2315, %2310
  %2319 = fadd fast float %2316, %2310
  %2320 = call float @dx.op.unary.f32(i32 7, float %2317)  ; Saturate(value)
  %2321 = call float @dx.op.unary.f32(i32 7, float %2318)  ; Saturate(value)
  %2322 = call float @dx.op.unary.f32(i32 7, float %2319)  ; Saturate(value)
  %2323 = fadd fast float %2320, 0xBFC70A3D80000000
  %2324 = fadd fast float %2321, 0xBFC70A3D80000000
  %2325 = fadd fast float %2322, 0xBFC70A3D80000000
  %2326 = fmul fast float %2323, %8
  %2327 = fmul fast float %2324, %8
  %2328 = fmul fast float %2325, %8
  %2329 = fadd fast float %2326, 0x3FC70A3D80000000
  %2330 = fadd fast float %2327, 0x3FC70A3D80000000
  %2331 = fadd fast float %2328, 0x3FC70A3D80000000
  %2332 = call float @dx.op.unary.f32(i32 7, float %2329)  ; Saturate(value)
  %2333 = call float @dx.op.unary.f32(i32 7, float %2330)  ; Saturate(value)
  %2334 = call float @dx.op.unary.f32(i32 7, float %2331)  ; Saturate(value)
  br label %2335

; <label>:2335                                    ; preds = %2303, %2138
  %2336 = phi float [ %2169, %2138 ], [ %2332, %2303 ]
  %2337 = phi float [ %2170, %2138 ], [ %2333, %2303 ]
  %2338 = phi float [ %2171, %2138 ], [ %2334, %2303 ]
  %2339 = fsub fast float %2336, %1632
  %2340 = fsub fast float %2337, %1633
  %2341 = fsub fast float %2338, %1634
  %2342 = fmul fast float %2339, %2125
  %2343 = fmul fast float %2340, %2125
  %2344 = fmul fast float %2341, %2125
  %2345 = fadd fast float %2342, %1632
  %2346 = fadd fast float %2343, %1633
  %2347 = fadd fast float %2344, %1634
  br label %2348

; <label>:2348                                    ; preds = %2335, %2110
  %2349 = phi float [ %2345, %2335 ], [ %1632, %2110 ]
  %2350 = phi float [ %2346, %2335 ], [ %1633, %2110 ]
  %2351 = phi float [ %2347, %2335 ], [ %1634, %2110 ]
  %2352 = add i32 %68, 1
  %2353 = call i32 @dx.op.binary.i32(i32 37, i32 %2352, i32 0)  ; IMax(a,b)
  %2354 = call i32 @dx.op.binary.i32(i32 38, i32 %2353, i32 %60)  ; IMin(a,b)
  %2355 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2354, i32 %2118, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2356 = extractvalue %dx.types.ResRet.f32 %2355, 0
  %2357 = fsub fast float %2356, %85
  %2358 = call float @dx.op.unary.f32(i32 6, float %2357)  ; FAbs(value)
  %2359 = fdiv fast float %2358, %1646
  %2360 = fsub fast float 1.000000e+00, %2359
  %2361 = call float @dx.op.unary.f32(i32 7, float %2360)  ; Saturate(value)
  %2362 = fcmp fast ugt float %2361, 0.000000e+00
  br i1 %2362, label %2363, label %2584

; <label>:2363                                    ; preds = %2348
  %2364 = call i32 @dx.op.binary.i32(i32 37, i32 %2354, i32 0)  ; IMax(a,b)
  %2365 = call i32 @dx.op.binary.i32(i32 37, i32 %2118, i32 0)  ; IMax(a,b)
  %2366 = call i32 @dx.op.binary.i32(i32 38, i32 %2364, i32 %60)  ; IMin(a,b)
  %2367 = call i32 @dx.op.binary.i32(i32 38, i32 %2365, i32 %61)  ; IMin(a,b)
  %2368 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2366, i32 %2367, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2369 = extractvalue %dx.types.ResRet.f32 %2368, 0
  %2370 = extractvalue %dx.types.ResRet.f32 %2368, 1
  %2371 = extractvalue %dx.types.ResRet.f32 %2368, 2
  %2372 = extractvalue %dx.types.ResRet.f32 %2368, 3
  %2373 = fcmp fast olt float %2372, 0.000000e+00
  br i1 %2373, label %2374, label %2408

; <label>:2374                                    ; preds = %2363
  %2375 = fcmp fast ogt float %2369, 0x3FA4B5DCC0000000
  %2376 = fcmp fast ogt float %2370, 0x3FA4B5DCC0000000
  %2377 = fcmp fast ogt float %2371, 0x3FA4B5DCC0000000
  %2378 = select i1 %2375, float 0.000000e+00, float 1.000000e+00
  %2379 = select i1 %2376, float 0.000000e+00, float 1.000000e+00
  %2380 = select i1 %2377, float 0.000000e+00, float 1.000000e+00
  %2381 = fmul fast float %2369, 0x3FB3D07220000000
  %2382 = fmul fast float %2370, 0x3FB3D07220000000
  %2383 = fmul fast float %2371, 0x3FB3D07220000000
  %2384 = fadd fast float %2369, 0x3FAC28F5C0000000
  %2385 = fadd fast float %2370, 0x3FAC28F5C0000000
  %2386 = fadd fast float %2371, 0x3FAC28F5C0000000
  %2387 = fmul fast float %2384, 0x3FEE54EDE0000000
  %2388 = fmul fast float %2385, 0x3FEE54EDE0000000
  %2389 = fmul fast float %2386, 0x3FEE54EDE0000000
  %2390 = call float @dx.op.unary.f32(i32 23, float %2387)  ; Log(value)
  %2391 = call float @dx.op.unary.f32(i32 23, float %2388)  ; Log(value)
  %2392 = call float @dx.op.unary.f32(i32 23, float %2389)  ; Log(value)
  %2393 = fmul fast float %2390, 0x4003333340000000
  %2394 = fmul fast float %2391, 0x4003333340000000
  %2395 = fmul fast float %2392, 0x4003333340000000
  %2396 = call float @dx.op.unary.f32(i32 21, float %2393)  ; Exp(value)
  %2397 = call float @dx.op.unary.f32(i32 21, float %2394)  ; Exp(value)
  %2398 = call float @dx.op.unary.f32(i32 21, float %2395)  ; Exp(value)
  %2399 = fsub fast float %2381, %2396
  %2400 = fsub fast float %2382, %2397
  %2401 = fsub fast float %2383, %2398
  %2402 = fmul fast float %2399, %2378
  %2403 = fmul fast float %2400, %2379
  %2404 = fmul fast float %2401, %2380
  %2405 = fadd fast float %2402, %2396
  %2406 = fadd fast float %2403, %2397
  %2407 = fadd fast float %2404, %2398
  br label %2571

; <label>:2408                                    ; preds = %2363
  %2409 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2366, i32 %2367, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2410 = extractvalue %dx.types.ResRet.f32 %2409, 0
  %2411 = fcmp fast ogt float %39, 5.000000e-01
  %2412 = fcmp fast olt float %2410, 1.000000e+00
  %2413 = and i1 %2411, %2412
  br i1 %2413, label %2414, label %2500

; <label>:2414                                    ; preds = %2408
  %2415 = sitofp i32 %2366 to float
  %2416 = sitofp i32 %2367 to float
  %2417 = fadd fast float %2415, 5.000000e-01
  %2418 = fadd fast float %2416, 5.000000e-01
  %2419 = fdiv fast float %2417, %46
  %2420 = fdiv fast float %2418, %47
  %2421 = fmul fast float %2419, 2.000000e+00
  %2422 = fmul fast float %2420, 2.000000e+00
  %2423 = fadd fast float %2421, -1.000000e+00
  %2424 = fsub fast float 1.000000e+00, %2422
  %2425 = fmul fast float %2423, %36
  %2426 = call float @dx.op.tertiary.f32(i32 46, float %2424, float %32, float %2425)  ; FMad(a,b,c)
  %2427 = call float @dx.op.tertiary.f32(i32 46, float %2410, float %28, float %2426)  ; FMad(a,b,c)
  %2428 = fadd fast float %2427, %24
  %2429 = call float @dx.op.unary.f32(i32 6, float %2428)  ; FAbs(value)
  %2430 = fcmp fast ogt float %2429, 0x3EB0C6F7A0000000
  br i1 %2430, label %2431, label %2500

; <label>:2431                                    ; preds = %2414
  %2432 = fmul fast float %2423, %35
  %2433 = call float @dx.op.tertiary.f32(i32 46, float %2424, float %31, float %2432)  ; FMad(a,b,c)
  %2434 = call float @dx.op.tertiary.f32(i32 46, float %2410, float %27, float %2433)  ; FMad(a,b,c)
  %2435 = fadd fast float %2434, %23
  %2436 = fmul fast float %2423, %34
  %2437 = call float @dx.op.tertiary.f32(i32 46, float %2424, float %30, float %2436)  ; FMad(a,b,c)
  %2438 = call float @dx.op.tertiary.f32(i32 46, float %2410, float %26, float %2437)  ; FMad(a,b,c)
  %2439 = fadd fast float %2438, %22
  %2440 = fmul fast float %2423, %33
  %2441 = call float @dx.op.tertiary.f32(i32 46, float %2424, float %29, float %2440)  ; FMad(a,b,c)
  %2442 = call float @dx.op.tertiary.f32(i32 46, float %2410, float %25, float %2441)  ; FMad(a,b,c)
  %2443 = fadd fast float %2442, %21
  %2444 = fdiv fast float %2443, %2428
  %2445 = fdiv fast float %2439, %2428
  %2446 = fdiv fast float %2435, %2428
  %2447 = fsub fast float %2444, %18
  %2448 = fsub fast float %2445, %19
  %2449 = fsub fast float %2446, %20
  %2450 = fmul fast float %2447, %2447
  %2451 = fmul fast float %2448, %2448
  %2452 = fadd fast float %2451, %2450
  %2453 = fmul fast float %2449, %2449
  %2454 = fadd fast float %2452, %2453
  %2455 = call float @dx.op.unary.f32(i32 24, float %2454)  ; Sqrt(value)
  %2456 = fsub fast float %2455, %10
  %2457 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2456)  ; FMax(a,b)
  %2458 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %2458, label %2459, label %2482

; <label>:2459                                    ; preds = %2431
  %2460 = call float @dx.op.unary.f32(i32 6, float %2448)  ; FAbs(value)
  %2461 = fmul fast float %2460, %12
  %2462 = fcmp fast olt float %2461, 0x3F50624DE0000000
  br i1 %2462, label %2463, label %2466

; <label>:2463                                    ; preds = %2459
  %2464 = fmul fast float %2461, 5.000000e-01
  %2465 = fsub fast float 1.000000e+00, %2464
  br label %2471

; <label>:2466                                    ; preds = %2459
  %2467 = fmul fast float %2461, 0xBFF7154760000000
  %2468 = call float @dx.op.unary.f32(i32 21, float %2467)  ; Exp(value)
  %2469 = fsub fast float 1.000000e+00, %2468
  %2470 = fdiv fast float %2469, %2461
  br label %2471

; <label>:2471                                    ; preds = %2466, %2463
  %2472 = phi float [ %2465, %2463 ], [ %2470, %2466 ]
  %2473 = call float @dx.op.binary.f32(i32 36, float %2445, float %19)  ; FMin(a,b)
  %2474 = fsub fast float %2473, %11
  %2475 = fmul fast float %12, %2474
  %2476 = fsub fast float -0.000000e+00, %2475
  %2477 = call float @dx.op.binary.f32(i32 35, float %2476, float -4.000000e+01)  ; FMax(a,b)
  %2478 = call float @dx.op.binary.f32(i32 36, float %2477, float 5.000000e+00)  ; FMin(a,b)
  %2479 = fmul fast float %2478, 0x3FF7154760000000
  %2480 = call float @dx.op.unary.f32(i32 21, float %2479)  ; Exp(value)
  %2481 = fmul fast float %2480, %2472
  br label %2482

; <label>:2482                                    ; preds = %2471, %2431
  %2483 = phi float [ %2481, %2471 ], [ 1.000000e+00, %2431 ]
  %2484 = fmul fast float %2457, %17
  %2485 = fmul fast float %2484, %2483
  %2486 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2485)  ; FMin(a,b)
  %2487 = fmul fast float %2486, 0xBFF7154760000000
  %2488 = call float @dx.op.unary.f32(i32 21, float %2487)  ; Exp(value)
  %2489 = fsub fast float 1.000000e+00, %2488
  %2490 = call float @dx.op.binary.f32(i32 36, float %13, float %2489)  ; FMin(a,b)
  %2491 = fsub fast float %14, %2369
  %2492 = fsub fast float %15, %2370
  %2493 = fsub fast float %16, %2371
  %2494 = fmul fast float %2490, %2491
  %2495 = fmul fast float %2490, %2492
  %2496 = fmul fast float %2490, %2493
  %2497 = fadd fast float %2494, %2369
  %2498 = fadd fast float %2495, %2370
  %2499 = fadd fast float %2496, %2371
  br label %2500

; <label>:2500                                    ; preds = %2482, %2414, %2408
  %2501 = phi float [ %2497, %2482 ], [ %2369, %2414 ], [ %2369, %2408 ]
  %2502 = phi float [ %2498, %2482 ], [ %2370, %2414 ], [ %2370, %2408 ]
  %2503 = phi float [ %2499, %2482 ], [ %2371, %2414 ], [ %2371, %2408 ]
  %2504 = fadd fast float %6, 1.000000e+00
  %2505 = fadd fast float %7, 1.000000e+00
  %2506 = fsub fast float 1.000000e+00, %6
  %2507 = fmul fast float %37, %2504
  %2508 = fmul fast float %37, %2505
  %2509 = fmul fast float %37, %2506
  %2510 = fmul fast float %2507, %2501
  %2511 = fmul fast float %2508, %2502
  %2512 = fmul fast float %2509, %2503
  %2513 = fcmp fast ult float %38, 5.000000e-01
  br i1 %2513, label %2539, label %2514

; <label>:2514                                    ; preds = %2500
  %2515 = fmul fast float %2510, 0x4004147AE0000000
  %2516 = fmul fast float %2511, 0x4004147AE0000000
  %2517 = fmul fast float %2512, 0x4004147AE0000000
  %2518 = fadd fast float %2515, 0x3F9EB851E0000000
  %2519 = fadd fast float %2516, 0x3F9EB851E0000000
  %2520 = fadd fast float %2517, 0x3F9EB851E0000000
  %2521 = fmul fast float %2518, %2510
  %2522 = fmul fast float %2519, %2511
  %2523 = fmul fast float %2520, %2512
  %2524 = fmul fast float %2510, 0x400370A3E0000000
  %2525 = fmul fast float %2511, 0x400370A3E0000000
  %2526 = fmul fast float %2512, 0x400370A3E0000000
  %2527 = fadd fast float %2524, 0x3FE2E147A0000000
  %2528 = fadd fast float %2525, 0x3FE2E147A0000000
  %2529 = fadd fast float %2526, 0x3FE2E147A0000000
  %2530 = fmul fast float %2527, %2510
  %2531 = fmul fast float %2528, %2511
  %2532 = fmul fast float %2529, %2512
  %2533 = fadd fast float %2530, 0x3FC1EB8520000000
  %2534 = fadd fast float %2531, 0x3FC1EB8520000000
  %2535 = fadd fast float %2532, 0x3FC1EB8520000000
  %2536 = fdiv fast float %2521, %2533
  %2537 = fdiv fast float %2522, %2534
  %2538 = fdiv fast float %2523, %2535
  br label %2539

; <label>:2539                                    ; preds = %2514, %2500
  %2540 = phi float [ %2536, %2514 ], [ %2510, %2500 ]
  %2541 = phi float [ %2537, %2514 ], [ %2511, %2500 ]
  %2542 = phi float [ %2538, %2514 ], [ %2512, %2500 ]
  %2543 = call float @dx.op.unary.f32(i32 7, float %2540)  ; Saturate(value)
  %2544 = call float @dx.op.unary.f32(i32 7, float %2541)  ; Saturate(value)
  %2545 = call float @dx.op.unary.f32(i32 7, float %2542)  ; Saturate(value)
  %2546 = call float @dx.op.dot3.f32(i32 55, float %2543, float %2544, float %2545, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2547 = fsub fast float %2543, %2546
  %2548 = fsub fast float %2544, %2546
  %2549 = fsub fast float %2545, %2546
  %2550 = fmul fast float %2547, %9
  %2551 = fmul fast float %2548, %9
  %2552 = fmul fast float %2549, %9
  %2553 = fadd fast float %2550, %2546
  %2554 = fadd fast float %2551, %2546
  %2555 = fadd fast float %2552, %2546
  %2556 = call float @dx.op.unary.f32(i32 7, float %2553)  ; Saturate(value)
  %2557 = call float @dx.op.unary.f32(i32 7, float %2554)  ; Saturate(value)
  %2558 = call float @dx.op.unary.f32(i32 7, float %2555)  ; Saturate(value)
  %2559 = fadd fast float %2556, 0xBFC70A3D80000000
  %2560 = fadd fast float %2557, 0xBFC70A3D80000000
  %2561 = fadd fast float %2558, 0xBFC70A3D80000000
  %2562 = fmul fast float %2559, %8
  %2563 = fmul fast float %2560, %8
  %2564 = fmul fast float %2561, %8
  %2565 = fadd fast float %2562, 0x3FC70A3D80000000
  %2566 = fadd fast float %2563, 0x3FC70A3D80000000
  %2567 = fadd fast float %2564, 0x3FC70A3D80000000
  %2568 = call float @dx.op.unary.f32(i32 7, float %2565)  ; Saturate(value)
  %2569 = call float @dx.op.unary.f32(i32 7, float %2566)  ; Saturate(value)
  %2570 = call float @dx.op.unary.f32(i32 7, float %2567)  ; Saturate(value)
  br label %2571

; <label>:2571                                    ; preds = %2539, %2374
  %2572 = phi float [ %2405, %2374 ], [ %2568, %2539 ]
  %2573 = phi float [ %2406, %2374 ], [ %2569, %2539 ]
  %2574 = phi float [ %2407, %2374 ], [ %2570, %2539 ]
  %2575 = fsub fast float %2572, %1632
  %2576 = fsub fast float %2573, %1633
  %2577 = fsub fast float %2574, %1634
  %2578 = fmul fast float %2575, %2361
  %2579 = fmul fast float %2576, %2361
  %2580 = fmul fast float %2577, %2361
  %2581 = fadd fast float %2578, %1632
  %2582 = fadd fast float %2579, %1633
  %2583 = fadd fast float %2580, %1634
  br label %2584

; <label>:2584                                    ; preds = %2571, %2348
  %2585 = phi float [ %2581, %2571 ], [ %1632, %2348 ]
  %2586 = phi float [ %2582, %2571 ], [ %1633, %2348 ]
  %2587 = phi float [ %2583, %2571 ], [ %1634, %2348 ]
  %2588 = call float @dx.op.binary.f32(i32 36, float %2349, float %2585)  ; FMin(a,b)
  %2589 = call float @dx.op.binary.f32(i32 36, float %2350, float %2586)  ; FMin(a,b)
  %2590 = call float @dx.op.binary.f32(i32 36, float %2351, float %2587)  ; FMin(a,b)
  %2591 = call float @dx.op.binary.f32(i32 36, float %1875, float %2111)  ; FMin(a,b)
  %2592 = call float @dx.op.binary.f32(i32 36, float %1876, float %2112)  ; FMin(a,b)
  %2593 = call float @dx.op.binary.f32(i32 36, float %1877, float %2113)  ; FMin(a,b)
  %2594 = call float @dx.op.binary.f32(i32 36, float %2591, float %2588)  ; FMin(a,b)
  %2595 = call float @dx.op.binary.f32(i32 36, float %2592, float %2589)  ; FMin(a,b)
  %2596 = call float @dx.op.binary.f32(i32 36, float %2593, float %2590)  ; FMin(a,b)
  %2597 = call float @dx.op.binary.f32(i32 36, float %1632, float %2594)  ; FMin(a,b)
  %2598 = call float @dx.op.binary.f32(i32 36, float %1633, float %2595)  ; FMin(a,b)
  %2599 = call float @dx.op.binary.f32(i32 36, float %1634, float %2596)  ; FMin(a,b)
  %2600 = call float @dx.op.binary.f32(i32 35, float %2349, float %2585)  ; FMax(a,b)
  %2601 = call float @dx.op.binary.f32(i32 35, float %2350, float %2586)  ; FMax(a,b)
  %2602 = call float @dx.op.binary.f32(i32 35, float %2351, float %2587)  ; FMax(a,b)
  %2603 = call float @dx.op.binary.f32(i32 35, float %1875, float %2111)  ; FMax(a,b)
  %2604 = call float @dx.op.binary.f32(i32 35, float %1876, float %2112)  ; FMax(a,b)
  %2605 = call float @dx.op.binary.f32(i32 35, float %1877, float %2113)  ; FMax(a,b)
  %2606 = call float @dx.op.binary.f32(i32 35, float %2603, float %2600)  ; FMax(a,b)
  %2607 = call float @dx.op.binary.f32(i32 35, float %2604, float %2601)  ; FMax(a,b)
  %2608 = call float @dx.op.binary.f32(i32 35, float %2605, float %2602)  ; FMax(a,b)
  %2609 = call float @dx.op.binary.f32(i32 35, float %1632, float %2606)  ; FMax(a,b)
  %2610 = call float @dx.op.binary.f32(i32 35, float %1633, float %2607)  ; FMax(a,b)
  %2611 = call float @dx.op.binary.f32(i32 35, float %1634, float %2608)  ; FMax(a,b)
  %2612 = fsub fast float %2609, %2597
  %2613 = fsub fast float %2610, %2598
  %2614 = fsub fast float %2611, %2599
  %2615 = call float @dx.op.unary.f32(i32 6, float %2612)  ; FAbs(value)
  %2616 = call float @dx.op.unary.f32(i32 6, float %2613)  ; FAbs(value)
  %2617 = call float @dx.op.unary.f32(i32 6, float %2614)  ; FAbs(value)
  %2618 = call float @dx.op.binary.f32(i32 35, float %2616, float %2617)  ; FMax(a,b)
  %2619 = call float @dx.op.binary.f32(i32 35, float %2615, float %2618)  ; FMax(a,b)
  %2620 = call float @dx.op.binary.f32(i32 35, float %2610, float %2611)  ; FMax(a,b)
  %2621 = call float @dx.op.binary.f32(i32 35, float %2609, float %2620)  ; FMax(a,b)
  %2622 = fmul fast float %2621, 1.250000e-01
  %2623 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %2622)  ; FMax(a,b)
  %2624 = fcmp fast ogt float %2619, %2623
  br i1 %2624, label %2625, label %2687

; <label>:2625                                    ; preds = %2584
  %2626 = fsub fast float %1875, %2111
  %2627 = fsub fast float %1876, %2112
  %2628 = fsub fast float %1877, %2113
  %2629 = call float @dx.op.unary.f32(i32 6, float %2626)  ; FAbs(value)
  %2630 = call float @dx.op.unary.f32(i32 6, float %2627)  ; FAbs(value)
  %2631 = call float @dx.op.unary.f32(i32 6, float %2628)  ; FAbs(value)
  %2632 = call float @dx.op.binary.f32(i32 35, float %2630, float %2631)  ; FMax(a,b)
  %2633 = call float @dx.op.binary.f32(i32 35, float %2629, float %2632)  ; FMax(a,b)
  %2634 = fsub fast float %2349, %2585
  %2635 = fsub fast float %2350, %2586
  %2636 = fsub fast float %2351, %2587
  %2637 = call float @dx.op.unary.f32(i32 6, float %2634)  ; FAbs(value)
  %2638 = call float @dx.op.unary.f32(i32 6, float %2635)  ; FAbs(value)
  %2639 = call float @dx.op.unary.f32(i32 6, float %2636)  ; FAbs(value)
  %2640 = call float @dx.op.binary.f32(i32 35, float %2638, float %2639)  ; FMax(a,b)
  %2641 = call float @dx.op.binary.f32(i32 35, float %2637, float %2640)  ; FMax(a,b)
  %2642 = fcmp fast olt float %2633, %2641
  %2643 = select i1 %2642, float %1875, float %2349
  %2644 = select i1 %2642, float %1876, float %2350
  %2645 = select i1 %2642, float %1877, float %2351
  %2646 = select i1 %2642, float %2111, float %2585
  %2647 = select i1 %2642, float %2112, float %2586
  %2648 = select i1 %2642, float %2113, float %2587
  %2649 = fsub fast float %1632, %2646
  %2650 = fsub fast float %1633, %2647
  %2651 = fsub fast float %1634, %2648
  %2652 = fsub fast float %1632, %2643
  %2653 = fsub fast float %1633, %2644
  %2654 = fsub fast float %1634, %2645
  %2655 = call float @dx.op.dot3.f32(i32 55, float %2652, float %2653, float %2654, float %2649, float %2650, float %2651)  ; Dot3(ax,ay,az,bx,by,bz)
  %2656 = fcmp fast ogt float %2655, 0.000000e+00
  br i1 %2656, label %2657, label %2668

; <label>:2657                                    ; preds = %2625
  %2658 = fsub fast float %2643, %2646
  %2659 = fsub fast float %2644, %2647
  %2660 = fsub fast float %2645, %2648
  %2661 = call float @dx.op.unary.f32(i32 6, float %2658)  ; FAbs(value)
  %2662 = call float @dx.op.unary.f32(i32 6, float %2659)  ; FAbs(value)
  %2663 = call float @dx.op.unary.f32(i32 6, float %2660)  ; FAbs(value)
  %2664 = call float @dx.op.binary.f32(i32 35, float %2662, float %2663)  ; FMax(a,b)
  %2665 = call float @dx.op.binary.f32(i32 35, float %2661, float %2664)  ; FMax(a,b)
  %2666 = fmul fast float %2619, 2.500000e-01
  %2667 = fcmp fast olt float %2665, %2666
  br label %2668

; <label>:2668                                    ; preds = %2657, %2625
  %2669 = phi i1 [ false, %2625 ], [ %2667, %2657 ]
  %2670 = select i1 %2669, float 5.000000e-01, float 1.000000e+00
  %2671 = fmul fast float %2670, %3
  %2672 = fadd fast float %2643, %2646
  %2673 = fadd fast float %2644, %2647
  %2674 = fadd fast float %2645, %2648
  %2675 = fmul fast float %2672, 5.000000e-01
  %2676 = fmul fast float %2673, 5.000000e-01
  %2677 = fmul fast float %2674, 5.000000e-01
  %2678 = fsub fast float %2675, %1632
  %2679 = fsub fast float %2676, %1633
  %2680 = fsub fast float %2677, %1634
  %2681 = fmul fast float %2671, %2678
  %2682 = fmul fast float %2671, %2679
  %2683 = fmul fast float %2671, %2680
  %2684 = fadd fast float %2681, %1632
  %2685 = fadd fast float %2682, %1633
  %2686 = fadd fast float %2683, %1634
  br label %2687

; <label>:2687                                    ; preds = %2668, %2584, %1603
  %2688 = phi float [ %1632, %1603 ], [ %2684, %2668 ], [ %1632, %2584 ]
  %2689 = phi float [ %1633, %1603 ], [ %2685, %2668 ], [ %1633, %2584 ]
  %2690 = phi float [ %1634, %1603 ], [ %2686, %2668 ], [ %1634, %2584 ]
  %2691 = fcmp fast ogt float %2688, 0x3F69A5C380000000
  %2692 = fcmp fast ogt float %2689, 0x3F69A5C380000000
  %2693 = fcmp fast ogt float %2690, 0x3F69A5C380000000
  %2694 = select i1 %2691, float 0.000000e+00, float 1.000000e+00
  %2695 = select i1 %2692, float 0.000000e+00, float 1.000000e+00
  %2696 = select i1 %2693, float 0.000000e+00, float 1.000000e+00
  %2697 = fmul fast float %2688, 0x4029D70A40000000
  %2698 = fmul fast float %2689, 0x4029D70A40000000
  %2699 = fmul fast float %2690, 0x4029D70A40000000
  %2700 = call float @dx.op.binary.f32(i32 35, float %2688, float 0.000000e+00)  ; FMax(a,b)
  %2701 = call float @dx.op.binary.f32(i32 35, float %2689, float 0.000000e+00)  ; FMax(a,b)
  %2702 = call float @dx.op.binary.f32(i32 35, float %2690, float 0.000000e+00)  ; FMax(a,b)
  %2703 = call float @dx.op.unary.f32(i32 23, float %2700)  ; Log(value)
  %2704 = call float @dx.op.unary.f32(i32 23, float %2701)  ; Log(value)
  %2705 = call float @dx.op.unary.f32(i32 23, float %2702)  ; Log(value)
  %2706 = fmul fast float %2703, 0x3FDAAAAAA0000000
  %2707 = fmul fast float %2704, 0x3FDAAAAAA0000000
  %2708 = fmul fast float %2705, 0x3FDAAAAAA0000000
  %2709 = call float @dx.op.unary.f32(i32 21, float %2706)  ; Exp(value)
  %2710 = call float @dx.op.unary.f32(i32 21, float %2707)  ; Exp(value)
  %2711 = call float @dx.op.unary.f32(i32 21, float %2708)  ; Exp(value)
  %2712 = fmul fast float %2709, 0x3FF0E147A0000000
  %2713 = fmul fast float %2710, 0x3FF0E147A0000000
  %2714 = fmul fast float %2711, 0x3FF0E147A0000000
  %2715 = fadd fast float %2712, 0xBFAC28F5C0000000
  %2716 = fadd fast float %2713, 0xBFAC28F5C0000000
  %2717 = fadd fast float %2714, 0xBFAC28F5C0000000
  %2718 = fsub fast float %2697, %2715
  %2719 = fsub fast float %2698, %2716
  %2720 = fsub fast float %2699, %2717
  %2721 = fmul fast float %2718, %2694
  %2722 = fmul fast float %2719, %2695
  %2723 = fmul fast float %2720, %2696
  %2724 = fadd fast float %2721, %2715
  %2725 = fadd fast float %2722, %2716
  %2726 = fadd fast float %2723, %2717
  br label %2727

; <label>:2727                                    ; preds = %2687, %1472
  %2728 = phi float [ %1467, %1472 ], [ %2724, %2687 ]
  %2729 = phi float [ %1468, %1472 ], [ %2725, %2687 ]
  %2730 = phi float [ %1469, %1472 ], [ %2726, %2687 ]
  %2731 = phi float [ %1473, %1472 ], [ %1470, %2687 ]
  %2732 = fcmp fast ogt float %2728, 0x3FA4B5DCC0000000
  %2733 = fcmp fast ogt float %2729, 0x3FA4B5DCC0000000
  %2734 = fcmp fast ogt float %2730, 0x3FA4B5DCC0000000
  %2735 = select i1 %2732, float 0.000000e+00, float 1.000000e+00
  %2736 = select i1 %2733, float 0.000000e+00, float 1.000000e+00
  %2737 = select i1 %2734, float 0.000000e+00, float 1.000000e+00
  %2738 = fmul fast float %2728, 0x3FB3D07220000000
  %2739 = fmul fast float %2729, 0x3FB3D07220000000
  %2740 = fmul fast float %2730, 0x3FB3D07220000000
  %2741 = fadd fast float %2728, 0x3FAC28F5C0000000
  %2742 = fadd fast float %2729, 0x3FAC28F5C0000000
  %2743 = fadd fast float %2730, 0x3FAC28F5C0000000
  %2744 = fmul fast float %2741, 0x3FEE54EDE0000000
  %2745 = fmul fast float %2742, 0x3FEE54EDE0000000
  %2746 = fmul fast float %2743, 0x3FEE54EDE0000000
  %2747 = call float @dx.op.unary.f32(i32 23, float %2744)  ; Log(value)
  %2748 = call float @dx.op.unary.f32(i32 23, float %2745)  ; Log(value)
  %2749 = call float @dx.op.unary.f32(i32 23, float %2746)  ; Log(value)
  %2750 = fmul fast float %2747, 0x4003333340000000
  %2751 = fmul fast float %2748, 0x4003333340000000
  %2752 = fmul fast float %2749, 0x4003333340000000
  %2753 = call float @dx.op.unary.f32(i32 21, float %2750)  ; Exp(value)
  %2754 = call float @dx.op.unary.f32(i32 21, float %2751)  ; Exp(value)
  %2755 = call float @dx.op.unary.f32(i32 21, float %2752)  ; Exp(value)
  %2756 = fsub fast float %2738, %2753
  %2757 = fsub fast float %2739, %2754
  %2758 = fsub fast float %2740, %2755
  %2759 = fmul fast float %2756, %2735
  %2760 = fmul fast float %2757, %2736
  %2761 = fmul fast float %2758, %2737
  %2762 = fadd fast float %2759, %2753
  %2763 = fadd fast float %2760, %2754
  %2764 = fadd fast float %2761, %2755
  %2765 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %64, i32 %71, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2766 = extractvalue %dx.types.ResRet.f32 %2765, 0
  %2767 = extractvalue %dx.types.ResRet.f32 %2765, 1
  %2768 = extractvalue %dx.types.ResRet.f32 %2765, 2
  %2769 = extractvalue %dx.types.ResRet.f32 %2765, 3
  %2770 = fcmp fast olt float %2769, 0.000000e+00
  br i1 %2770, label %2771, label %2773

; <label>:2771                                    ; preds = %2727
  %2772 = fsub fast float -1.000000e+00, %2769
  br label %4026

; <label>:2773                                    ; preds = %2727
  %2774 = fcmp fast ogt float %39, 5.000000e-01
  %2775 = fcmp fast olt float %87, 1.000000e+00
  %2776 = and i1 %2774, %2775
  br i1 %2776, label %2777, label %2863

; <label>:2777                                    ; preds = %2773
  %2778 = sitofp i32 %64 to float
  %2779 = sitofp i32 %71 to float
  %2780 = fadd fast float %2778, 5.000000e-01
  %2781 = fadd fast float %2779, 5.000000e-01
  %2782 = fdiv fast float %2780, %46
  %2783 = fdiv fast float %2781, %47
  %2784 = fmul fast float %2782, 2.000000e+00
  %2785 = fmul fast float %2783, 2.000000e+00
  %2786 = fadd fast float %2784, -1.000000e+00
  %2787 = fsub fast float 1.000000e+00, %2785
  %2788 = fmul fast float %2786, %36
  %2789 = call float @dx.op.tertiary.f32(i32 46, float %2787, float %32, float %2788)  ; FMad(a,b,c)
  %2790 = call float @dx.op.tertiary.f32(i32 46, float %87, float %28, float %2789)  ; FMad(a,b,c)
  %2791 = fadd fast float %2790, %24
  %2792 = call float @dx.op.unary.f32(i32 6, float %2791)  ; FAbs(value)
  %2793 = fcmp fast ogt float %2792, 0x3EB0C6F7A0000000
  br i1 %2793, label %2794, label %2863

; <label>:2794                                    ; preds = %2777
  %2795 = fmul fast float %2786, %35
  %2796 = call float @dx.op.tertiary.f32(i32 46, float %2787, float %31, float %2795)  ; FMad(a,b,c)
  %2797 = call float @dx.op.tertiary.f32(i32 46, float %87, float %27, float %2796)  ; FMad(a,b,c)
  %2798 = fadd fast float %2797, %23
  %2799 = fmul fast float %2786, %34
  %2800 = call float @dx.op.tertiary.f32(i32 46, float %2787, float %30, float %2799)  ; FMad(a,b,c)
  %2801 = call float @dx.op.tertiary.f32(i32 46, float %87, float %26, float %2800)  ; FMad(a,b,c)
  %2802 = fadd fast float %2801, %22
  %2803 = fmul fast float %2786, %33
  %2804 = call float @dx.op.tertiary.f32(i32 46, float %2787, float %29, float %2803)  ; FMad(a,b,c)
  %2805 = call float @dx.op.tertiary.f32(i32 46, float %87, float %25, float %2804)  ; FMad(a,b,c)
  %2806 = fadd fast float %2805, %21
  %2807 = fdiv fast float %2806, %2791
  %2808 = fdiv fast float %2802, %2791
  %2809 = fdiv fast float %2798, %2791
  %2810 = fsub fast float %2807, %18
  %2811 = fsub fast float %2808, %19
  %2812 = fsub fast float %2809, %20
  %2813 = fmul fast float %2810, %2810
  %2814 = fmul fast float %2811, %2811
  %2815 = fadd fast float %2814, %2813
  %2816 = fmul fast float %2812, %2812
  %2817 = fadd fast float %2815, %2816
  %2818 = call float @dx.op.unary.f32(i32 24, float %2817)  ; Sqrt(value)
  %2819 = fsub fast float %2818, %10
  %2820 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2819)  ; FMax(a,b)
  %2821 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %2821, label %2822, label %2845

; <label>:2822                                    ; preds = %2794
  %2823 = call float @dx.op.unary.f32(i32 6, float %2811)  ; FAbs(value)
  %2824 = fmul fast float %2823, %12
  %2825 = fcmp fast olt float %2824, 0x3F50624DE0000000
  br i1 %2825, label %2826, label %2829

; <label>:2826                                    ; preds = %2822
  %2827 = fmul fast float %2824, 5.000000e-01
  %2828 = fsub fast float 1.000000e+00, %2827
  br label %2834

; <label>:2829                                    ; preds = %2822
  %2830 = fmul fast float %2824, 0xBFF7154760000000
  %2831 = call float @dx.op.unary.f32(i32 21, float %2830)  ; Exp(value)
  %2832 = fsub fast float 1.000000e+00, %2831
  %2833 = fdiv fast float %2832, %2824
  br label %2834

; <label>:2834                                    ; preds = %2829, %2826
  %2835 = phi float [ %2828, %2826 ], [ %2833, %2829 ]
  %2836 = call float @dx.op.binary.f32(i32 36, float %2808, float %19)  ; FMin(a,b)
  %2837 = fsub fast float %2836, %11
  %2838 = fmul fast float %12, %2837
  %2839 = fsub fast float -0.000000e+00, %2838
  %2840 = call float @dx.op.binary.f32(i32 35, float %2839, float -4.000000e+01)  ; FMax(a,b)
  %2841 = call float @dx.op.binary.f32(i32 36, float %2840, float 5.000000e+00)  ; FMin(a,b)
  %2842 = fmul fast float %2841, 0x3FF7154760000000
  %2843 = call float @dx.op.unary.f32(i32 21, float %2842)  ; Exp(value)
  %2844 = fmul fast float %2843, %2835
  br label %2845

; <label>:2845                                    ; preds = %2834, %2794
  %2846 = phi float [ %2844, %2834 ], [ 1.000000e+00, %2794 ]
  %2847 = fmul fast float %2820, %17
  %2848 = fmul fast float %2847, %2846
  %2849 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2848)  ; FMin(a,b)
  %2850 = fmul fast float %2849, 0xBFF7154760000000
  %2851 = call float @dx.op.unary.f32(i32 21, float %2850)  ; Exp(value)
  %2852 = fsub fast float 1.000000e+00, %2851
  %2853 = call float @dx.op.binary.f32(i32 36, float %13, float %2852)  ; FMin(a,b)
  %2854 = fsub fast float %14, %2766
  %2855 = fsub fast float %15, %2767
  %2856 = fsub fast float %16, %2768
  %2857 = fmul fast float %2853, %2854
  %2858 = fmul fast float %2853, %2855
  %2859 = fmul fast float %2853, %2856
  %2860 = fadd fast float %2857, %2766
  %2861 = fadd fast float %2858, %2767
  %2862 = fadd fast float %2859, %2768
  br label %2863

; <label>:2863                                    ; preds = %2845, %2777, %2773
  %2864 = phi float [ %2860, %2845 ], [ %2766, %2777 ], [ %2766, %2773 ]
  %2865 = phi float [ %2861, %2845 ], [ %2767, %2777 ], [ %2767, %2773 ]
  %2866 = phi float [ %2862, %2845 ], [ %2768, %2777 ], [ %2768, %2773 ]
  %2867 = fadd fast float %6, 1.000000e+00
  %2868 = fadd fast float %7, 1.000000e+00
  %2869 = fsub fast float 1.000000e+00, %6
  %2870 = fmul fast float %37, %2867
  %2871 = fmul fast float %37, %2868
  %2872 = fmul fast float %37, %2869
  %2873 = fmul fast float %2870, %2864
  %2874 = fmul fast float %2871, %2865
  %2875 = fmul fast float %2872, %2866
  %2876 = fcmp fast ult float %38, 5.000000e-01
  br i1 %2876, label %2902, label %2877

; <label>:2877                                    ; preds = %2863
  %2878 = fmul fast float %2873, 0x4004147AE0000000
  %2879 = fmul fast float %2874, 0x4004147AE0000000
  %2880 = fmul fast float %2875, 0x4004147AE0000000
  %2881 = fadd fast float %2878, 0x3F9EB851E0000000
  %2882 = fadd fast float %2879, 0x3F9EB851E0000000
  %2883 = fadd fast float %2880, 0x3F9EB851E0000000
  %2884 = fmul fast float %2881, %2873
  %2885 = fmul fast float %2882, %2874
  %2886 = fmul fast float %2883, %2875
  %2887 = fmul fast float %2873, 0x400370A3E0000000
  %2888 = fmul fast float %2874, 0x400370A3E0000000
  %2889 = fmul fast float %2875, 0x400370A3E0000000
  %2890 = fadd fast float %2887, 0x3FE2E147A0000000
  %2891 = fadd fast float %2888, 0x3FE2E147A0000000
  %2892 = fadd fast float %2889, 0x3FE2E147A0000000
  %2893 = fmul fast float %2890, %2873
  %2894 = fmul fast float %2891, %2874
  %2895 = fmul fast float %2892, %2875
  %2896 = fadd fast float %2893, 0x3FC1EB8520000000
  %2897 = fadd fast float %2894, 0x3FC1EB8520000000
  %2898 = fadd fast float %2895, 0x3FC1EB8520000000
  %2899 = fdiv fast float %2884, %2896
  %2900 = fdiv fast float %2885, %2897
  %2901 = fdiv fast float %2886, %2898
  br label %2902

; <label>:2902                                    ; preds = %2877, %2863
  %2903 = phi float [ %2899, %2877 ], [ %2873, %2863 ]
  %2904 = phi float [ %2900, %2877 ], [ %2874, %2863 ]
  %2905 = phi float [ %2901, %2877 ], [ %2875, %2863 ]
  %2906 = call float @dx.op.unary.f32(i32 7, float %2903)  ; Saturate(value)
  %2907 = call float @dx.op.unary.f32(i32 7, float %2904)  ; Saturate(value)
  %2908 = call float @dx.op.unary.f32(i32 7, float %2905)  ; Saturate(value)
  %2909 = call float @dx.op.dot3.f32(i32 55, float %2906, float %2907, float %2908, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2910 = fsub fast float %2906, %2909
  %2911 = fsub fast float %2907, %2909
  %2912 = fsub fast float %2908, %2909
  %2913 = fmul fast float %2910, %9
  %2914 = fmul fast float %2911, %9
  %2915 = fmul fast float %2912, %9
  %2916 = fadd fast float %2913, %2909
  %2917 = fadd fast float %2914, %2909
  %2918 = fadd fast float %2915, %2909
  %2919 = call float @dx.op.unary.f32(i32 7, float %2916)  ; Saturate(value)
  %2920 = call float @dx.op.unary.f32(i32 7, float %2917)  ; Saturate(value)
  %2921 = call float @dx.op.unary.f32(i32 7, float %2918)  ; Saturate(value)
  %2922 = fadd fast float %2919, 0xBFC70A3D80000000
  %2923 = fadd fast float %2920, 0xBFC70A3D80000000
  %2924 = fadd fast float %2921, 0xBFC70A3D80000000
  %2925 = fmul fast float %2922, %8
  %2926 = fmul fast float %2923, %8
  %2927 = fmul fast float %2924, %8
  %2928 = fadd fast float %2925, 0x3FC70A3D80000000
  %2929 = fadd fast float %2926, 0x3FC70A3D80000000
  %2930 = fadd fast float %2927, 0x3FC70A3D80000000
  %2931 = call float @dx.op.unary.f32(i32 7, float %2928)  ; Saturate(value)
  %2932 = call float @dx.op.unary.f32(i32 7, float %2929)  ; Saturate(value)
  %2933 = call float @dx.op.unary.f32(i32 7, float %2930)  ; Saturate(value)
  %2934 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %2934, label %2935, label %3986

; <label>:2935                                    ; preds = %2902
  %2936 = add i32 %71, -1
  %2937 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %2938 = call i32 @dx.op.binary.i32(i32 37, i32 %2936, i32 0)  ; IMax(a,b)
  %2939 = call i32 @dx.op.binary.i32(i32 38, i32 %2937, i32 %60)  ; IMin(a,b)
  %2940 = call i32 @dx.op.binary.i32(i32 38, i32 %2938, i32 %61)  ; IMin(a,b)
  %2941 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2939, i32 %2940, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2942 = extractvalue %dx.types.ResRet.f32 %2941, 0
  %2943 = fsub fast float 1.000000e+00, %87
  %2944 = fmul fast float %2943, 0x3FA99999A0000000
  %2945 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %2944)  ; FMax(a,b)
  %2946 = fsub fast float %2942, %87
  %2947 = call float @dx.op.unary.f32(i32 6, float %2946)  ; FAbs(value)
  %2948 = fdiv fast float %2947, %2945
  %2949 = fsub fast float 1.000000e+00, %2948
  %2950 = call float @dx.op.unary.f32(i32 7, float %2949)  ; Saturate(value)
  %2951 = fcmp fast ugt float %2950, 0.000000e+00
  br i1 %2951, label %2952, label %3173

; <label>:2952                                    ; preds = %2935
  %2953 = call i32 @dx.op.binary.i32(i32 37, i32 %2939, i32 0)  ; IMax(a,b)
  %2954 = call i32 @dx.op.binary.i32(i32 37, i32 %2940, i32 0)  ; IMax(a,b)
  %2955 = call i32 @dx.op.binary.i32(i32 38, i32 %2953, i32 %60)  ; IMin(a,b)
  %2956 = call i32 @dx.op.binary.i32(i32 38, i32 %2954, i32 %61)  ; IMin(a,b)
  %2957 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2955, i32 %2956, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2958 = extractvalue %dx.types.ResRet.f32 %2957, 0
  %2959 = extractvalue %dx.types.ResRet.f32 %2957, 1
  %2960 = extractvalue %dx.types.ResRet.f32 %2957, 2
  %2961 = extractvalue %dx.types.ResRet.f32 %2957, 3
  %2962 = fcmp fast olt float %2961, 0.000000e+00
  br i1 %2962, label %2963, label %2997

; <label>:2963                                    ; preds = %2952
  %2964 = fcmp fast ogt float %2958, 0x3FA4B5DCC0000000
  %2965 = fcmp fast ogt float %2959, 0x3FA4B5DCC0000000
  %2966 = fcmp fast ogt float %2960, 0x3FA4B5DCC0000000
  %2967 = select i1 %2964, float 0.000000e+00, float 1.000000e+00
  %2968 = select i1 %2965, float 0.000000e+00, float 1.000000e+00
  %2969 = select i1 %2966, float 0.000000e+00, float 1.000000e+00
  %2970 = fmul fast float %2958, 0x3FB3D07220000000
  %2971 = fmul fast float %2959, 0x3FB3D07220000000
  %2972 = fmul fast float %2960, 0x3FB3D07220000000
  %2973 = fadd fast float %2958, 0x3FAC28F5C0000000
  %2974 = fadd fast float %2959, 0x3FAC28F5C0000000
  %2975 = fadd fast float %2960, 0x3FAC28F5C0000000
  %2976 = fmul fast float %2973, 0x3FEE54EDE0000000
  %2977 = fmul fast float %2974, 0x3FEE54EDE0000000
  %2978 = fmul fast float %2975, 0x3FEE54EDE0000000
  %2979 = call float @dx.op.unary.f32(i32 23, float %2976)  ; Log(value)
  %2980 = call float @dx.op.unary.f32(i32 23, float %2977)  ; Log(value)
  %2981 = call float @dx.op.unary.f32(i32 23, float %2978)  ; Log(value)
  %2982 = fmul fast float %2979, 0x4003333340000000
  %2983 = fmul fast float %2980, 0x4003333340000000
  %2984 = fmul fast float %2981, 0x4003333340000000
  %2985 = call float @dx.op.unary.f32(i32 21, float %2982)  ; Exp(value)
  %2986 = call float @dx.op.unary.f32(i32 21, float %2983)  ; Exp(value)
  %2987 = call float @dx.op.unary.f32(i32 21, float %2984)  ; Exp(value)
  %2988 = fsub fast float %2970, %2985
  %2989 = fsub fast float %2971, %2986
  %2990 = fsub fast float %2972, %2987
  %2991 = fmul fast float %2988, %2967
  %2992 = fmul fast float %2989, %2968
  %2993 = fmul fast float %2990, %2969
  %2994 = fadd fast float %2991, %2985
  %2995 = fadd fast float %2992, %2986
  %2996 = fadd fast float %2993, %2987
  br label %3160

; <label>:2997                                    ; preds = %2952
  %2998 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2955, i32 %2956, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2999 = extractvalue %dx.types.ResRet.f32 %2998, 0
  %3000 = fcmp fast ogt float %39, 5.000000e-01
  %3001 = fcmp fast olt float %2999, 1.000000e+00
  %3002 = and i1 %3000, %3001
  br i1 %3002, label %3003, label %3089

; <label>:3003                                    ; preds = %2997
  %3004 = sitofp i32 %2955 to float
  %3005 = sitofp i32 %2956 to float
  %3006 = fadd fast float %3004, 5.000000e-01
  %3007 = fadd fast float %3005, 5.000000e-01
  %3008 = fdiv fast float %3006, %46
  %3009 = fdiv fast float %3007, %47
  %3010 = fmul fast float %3008, 2.000000e+00
  %3011 = fmul fast float %3009, 2.000000e+00
  %3012 = fadd fast float %3010, -1.000000e+00
  %3013 = fsub fast float 1.000000e+00, %3011
  %3014 = fmul fast float %3012, %36
  %3015 = call float @dx.op.tertiary.f32(i32 46, float %3013, float %32, float %3014)  ; FMad(a,b,c)
  %3016 = call float @dx.op.tertiary.f32(i32 46, float %2999, float %28, float %3015)  ; FMad(a,b,c)
  %3017 = fadd fast float %3016, %24
  %3018 = call float @dx.op.unary.f32(i32 6, float %3017)  ; FAbs(value)
  %3019 = fcmp fast ogt float %3018, 0x3EB0C6F7A0000000
  br i1 %3019, label %3020, label %3089

; <label>:3020                                    ; preds = %3003
  %3021 = fmul fast float %3012, %35
  %3022 = call float @dx.op.tertiary.f32(i32 46, float %3013, float %31, float %3021)  ; FMad(a,b,c)
  %3023 = call float @dx.op.tertiary.f32(i32 46, float %2999, float %27, float %3022)  ; FMad(a,b,c)
  %3024 = fadd fast float %3023, %23
  %3025 = fmul fast float %3012, %34
  %3026 = call float @dx.op.tertiary.f32(i32 46, float %3013, float %30, float %3025)  ; FMad(a,b,c)
  %3027 = call float @dx.op.tertiary.f32(i32 46, float %2999, float %26, float %3026)  ; FMad(a,b,c)
  %3028 = fadd fast float %3027, %22
  %3029 = fmul fast float %3012, %33
  %3030 = call float @dx.op.tertiary.f32(i32 46, float %3013, float %29, float %3029)  ; FMad(a,b,c)
  %3031 = call float @dx.op.tertiary.f32(i32 46, float %2999, float %25, float %3030)  ; FMad(a,b,c)
  %3032 = fadd fast float %3031, %21
  %3033 = fdiv fast float %3032, %3017
  %3034 = fdiv fast float %3028, %3017
  %3035 = fdiv fast float %3024, %3017
  %3036 = fsub fast float %3033, %18
  %3037 = fsub fast float %3034, %19
  %3038 = fsub fast float %3035, %20
  %3039 = fmul fast float %3036, %3036
  %3040 = fmul fast float %3037, %3037
  %3041 = fadd fast float %3040, %3039
  %3042 = fmul fast float %3038, %3038
  %3043 = fadd fast float %3041, %3042
  %3044 = call float @dx.op.unary.f32(i32 24, float %3043)  ; Sqrt(value)
  %3045 = fsub fast float %3044, %10
  %3046 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3045)  ; FMax(a,b)
  %3047 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %3047, label %3048, label %3071

; <label>:3048                                    ; preds = %3020
  %3049 = call float @dx.op.unary.f32(i32 6, float %3037)  ; FAbs(value)
  %3050 = fmul fast float %3049, %12
  %3051 = fcmp fast olt float %3050, 0x3F50624DE0000000
  br i1 %3051, label %3052, label %3055

; <label>:3052                                    ; preds = %3048
  %3053 = fmul fast float %3050, 5.000000e-01
  %3054 = fsub fast float 1.000000e+00, %3053
  br label %3060

; <label>:3055                                    ; preds = %3048
  %3056 = fmul fast float %3050, 0xBFF7154760000000
  %3057 = call float @dx.op.unary.f32(i32 21, float %3056)  ; Exp(value)
  %3058 = fsub fast float 1.000000e+00, %3057
  %3059 = fdiv fast float %3058, %3050
  br label %3060

; <label>:3060                                    ; preds = %3055, %3052
  %3061 = phi float [ %3054, %3052 ], [ %3059, %3055 ]
  %3062 = call float @dx.op.binary.f32(i32 36, float %3034, float %19)  ; FMin(a,b)
  %3063 = fsub fast float %3062, %11
  %3064 = fmul fast float %12, %3063
  %3065 = fsub fast float -0.000000e+00, %3064
  %3066 = call float @dx.op.binary.f32(i32 35, float %3065, float -4.000000e+01)  ; FMax(a,b)
  %3067 = call float @dx.op.binary.f32(i32 36, float %3066, float 5.000000e+00)  ; FMin(a,b)
  %3068 = fmul fast float %3067, 0x3FF7154760000000
  %3069 = call float @dx.op.unary.f32(i32 21, float %3068)  ; Exp(value)
  %3070 = fmul fast float %3069, %3061
  br label %3071

; <label>:3071                                    ; preds = %3060, %3020
  %3072 = phi float [ %3070, %3060 ], [ 1.000000e+00, %3020 ]
  %3073 = fmul fast float %3046, %17
  %3074 = fmul fast float %3073, %3072
  %3075 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3074)  ; FMin(a,b)
  %3076 = fmul fast float %3075, 0xBFF7154760000000
  %3077 = call float @dx.op.unary.f32(i32 21, float %3076)  ; Exp(value)
  %3078 = fsub fast float 1.000000e+00, %3077
  %3079 = call float @dx.op.binary.f32(i32 36, float %13, float %3078)  ; FMin(a,b)
  %3080 = fsub fast float %14, %2958
  %3081 = fsub fast float %15, %2959
  %3082 = fsub fast float %16, %2960
  %3083 = fmul fast float %3079, %3080
  %3084 = fmul fast float %3079, %3081
  %3085 = fmul fast float %3079, %3082
  %3086 = fadd fast float %3083, %2958
  %3087 = fadd fast float %3084, %2959
  %3088 = fadd fast float %3085, %2960
  br label %3089

; <label>:3089                                    ; preds = %3071, %3003, %2997
  %3090 = phi float [ %3086, %3071 ], [ %2958, %3003 ], [ %2958, %2997 ]
  %3091 = phi float [ %3087, %3071 ], [ %2959, %3003 ], [ %2959, %2997 ]
  %3092 = phi float [ %3088, %3071 ], [ %2960, %3003 ], [ %2960, %2997 ]
  %3093 = fadd fast float %6, 1.000000e+00
  %3094 = fadd fast float %7, 1.000000e+00
  %3095 = fsub fast float 1.000000e+00, %6
  %3096 = fmul fast float %37, %3093
  %3097 = fmul fast float %37, %3094
  %3098 = fmul fast float %37, %3095
  %3099 = fmul fast float %3096, %3090
  %3100 = fmul fast float %3097, %3091
  %3101 = fmul fast float %3098, %3092
  %3102 = fcmp fast ult float %38, 5.000000e-01
  br i1 %3102, label %3128, label %3103

; <label>:3103                                    ; preds = %3089
  %3104 = fmul fast float %3099, 0x4004147AE0000000
  %3105 = fmul fast float %3100, 0x4004147AE0000000
  %3106 = fmul fast float %3101, 0x4004147AE0000000
  %3107 = fadd fast float %3104, 0x3F9EB851E0000000
  %3108 = fadd fast float %3105, 0x3F9EB851E0000000
  %3109 = fadd fast float %3106, 0x3F9EB851E0000000
  %3110 = fmul fast float %3107, %3099
  %3111 = fmul fast float %3108, %3100
  %3112 = fmul fast float %3109, %3101
  %3113 = fmul fast float %3099, 0x400370A3E0000000
  %3114 = fmul fast float %3100, 0x400370A3E0000000
  %3115 = fmul fast float %3101, 0x400370A3E0000000
  %3116 = fadd fast float %3113, 0x3FE2E147A0000000
  %3117 = fadd fast float %3114, 0x3FE2E147A0000000
  %3118 = fadd fast float %3115, 0x3FE2E147A0000000
  %3119 = fmul fast float %3116, %3099
  %3120 = fmul fast float %3117, %3100
  %3121 = fmul fast float %3118, %3101
  %3122 = fadd fast float %3119, 0x3FC1EB8520000000
  %3123 = fadd fast float %3120, 0x3FC1EB8520000000
  %3124 = fadd fast float %3121, 0x3FC1EB8520000000
  %3125 = fdiv fast float %3110, %3122
  %3126 = fdiv fast float %3111, %3123
  %3127 = fdiv fast float %3112, %3124
  br label %3128

; <label>:3128                                    ; preds = %3103, %3089
  %3129 = phi float [ %3125, %3103 ], [ %3099, %3089 ]
  %3130 = phi float [ %3126, %3103 ], [ %3100, %3089 ]
  %3131 = phi float [ %3127, %3103 ], [ %3101, %3089 ]
  %3132 = call float @dx.op.unary.f32(i32 7, float %3129)  ; Saturate(value)
  %3133 = call float @dx.op.unary.f32(i32 7, float %3130)  ; Saturate(value)
  %3134 = call float @dx.op.unary.f32(i32 7, float %3131)  ; Saturate(value)
  %3135 = call float @dx.op.dot3.f32(i32 55, float %3132, float %3133, float %3134, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3136 = fsub fast float %3132, %3135
  %3137 = fsub fast float %3133, %3135
  %3138 = fsub fast float %3134, %3135
  %3139 = fmul fast float %3136, %9
  %3140 = fmul fast float %3137, %9
  %3141 = fmul fast float %3138, %9
  %3142 = fadd fast float %3139, %3135
  %3143 = fadd fast float %3140, %3135
  %3144 = fadd fast float %3141, %3135
  %3145 = call float @dx.op.unary.f32(i32 7, float %3142)  ; Saturate(value)
  %3146 = call float @dx.op.unary.f32(i32 7, float %3143)  ; Saturate(value)
  %3147 = call float @dx.op.unary.f32(i32 7, float %3144)  ; Saturate(value)
  %3148 = fadd fast float %3145, 0xBFC70A3D80000000
  %3149 = fadd fast float %3146, 0xBFC70A3D80000000
  %3150 = fadd fast float %3147, 0xBFC70A3D80000000
  %3151 = fmul fast float %3148, %8
  %3152 = fmul fast float %3149, %8
  %3153 = fmul fast float %3150, %8
  %3154 = fadd fast float %3151, 0x3FC70A3D80000000
  %3155 = fadd fast float %3152, 0x3FC70A3D80000000
  %3156 = fadd fast float %3153, 0x3FC70A3D80000000
  %3157 = call float @dx.op.unary.f32(i32 7, float %3154)  ; Saturate(value)
  %3158 = call float @dx.op.unary.f32(i32 7, float %3155)  ; Saturate(value)
  %3159 = call float @dx.op.unary.f32(i32 7, float %3156)  ; Saturate(value)
  br label %3160

; <label>:3160                                    ; preds = %3128, %2963
  %3161 = phi float [ %2994, %2963 ], [ %3157, %3128 ]
  %3162 = phi float [ %2995, %2963 ], [ %3158, %3128 ]
  %3163 = phi float [ %2996, %2963 ], [ %3159, %3128 ]
  %3164 = fsub fast float %3161, %2931
  %3165 = fsub fast float %3162, %2932
  %3166 = fsub fast float %3163, %2933
  %3167 = fmul fast float %3164, %2950
  %3168 = fmul fast float %3165, %2950
  %3169 = fmul fast float %3166, %2950
  %3170 = fadd fast float %3167, %2931
  %3171 = fadd fast float %3168, %2932
  %3172 = fadd fast float %3169, %2933
  br label %3173

; <label>:3173                                    ; preds = %3160, %2935
  %3174 = phi float [ %3170, %3160 ], [ %2931, %2935 ]
  %3175 = phi float [ %3171, %3160 ], [ %2932, %2935 ]
  %3176 = phi float [ %3172, %3160 ], [ %2933, %2935 ]
  %3177 = add i32 %71, 1
  %3178 = call i32 @dx.op.binary.i32(i32 37, i32 %3177, i32 0)  ; IMax(a,b)
  %3179 = call i32 @dx.op.binary.i32(i32 38, i32 %3178, i32 %61)  ; IMin(a,b)
  %3180 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2939, i32 %3179, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3181 = extractvalue %dx.types.ResRet.f32 %3180, 0
  %3182 = fsub fast float %3181, %87
  %3183 = call float @dx.op.unary.f32(i32 6, float %3182)  ; FAbs(value)
  %3184 = fdiv fast float %3183, %2945
  %3185 = fsub fast float 1.000000e+00, %3184
  %3186 = call float @dx.op.unary.f32(i32 7, float %3185)  ; Saturate(value)
  %3187 = fcmp fast ugt float %3186, 0.000000e+00
  br i1 %3187, label %3188, label %3409

; <label>:3188                                    ; preds = %3173
  %3189 = call i32 @dx.op.binary.i32(i32 37, i32 %2939, i32 0)  ; IMax(a,b)
  %3190 = call i32 @dx.op.binary.i32(i32 37, i32 %3179, i32 0)  ; IMax(a,b)
  %3191 = call i32 @dx.op.binary.i32(i32 38, i32 %3189, i32 %60)  ; IMin(a,b)
  %3192 = call i32 @dx.op.binary.i32(i32 38, i32 %3190, i32 %61)  ; IMin(a,b)
  %3193 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3191, i32 %3192, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3194 = extractvalue %dx.types.ResRet.f32 %3193, 0
  %3195 = extractvalue %dx.types.ResRet.f32 %3193, 1
  %3196 = extractvalue %dx.types.ResRet.f32 %3193, 2
  %3197 = extractvalue %dx.types.ResRet.f32 %3193, 3
  %3198 = fcmp fast olt float %3197, 0.000000e+00
  br i1 %3198, label %3199, label %3233

; <label>:3199                                    ; preds = %3188
  %3200 = fcmp fast ogt float %3194, 0x3FA4B5DCC0000000
  %3201 = fcmp fast ogt float %3195, 0x3FA4B5DCC0000000
  %3202 = fcmp fast ogt float %3196, 0x3FA4B5DCC0000000
  %3203 = select i1 %3200, float 0.000000e+00, float 1.000000e+00
  %3204 = select i1 %3201, float 0.000000e+00, float 1.000000e+00
  %3205 = select i1 %3202, float 0.000000e+00, float 1.000000e+00
  %3206 = fmul fast float %3194, 0x3FB3D07220000000
  %3207 = fmul fast float %3195, 0x3FB3D07220000000
  %3208 = fmul fast float %3196, 0x3FB3D07220000000
  %3209 = fadd fast float %3194, 0x3FAC28F5C0000000
  %3210 = fadd fast float %3195, 0x3FAC28F5C0000000
  %3211 = fadd fast float %3196, 0x3FAC28F5C0000000
  %3212 = fmul fast float %3209, 0x3FEE54EDE0000000
  %3213 = fmul fast float %3210, 0x3FEE54EDE0000000
  %3214 = fmul fast float %3211, 0x3FEE54EDE0000000
  %3215 = call float @dx.op.unary.f32(i32 23, float %3212)  ; Log(value)
  %3216 = call float @dx.op.unary.f32(i32 23, float %3213)  ; Log(value)
  %3217 = call float @dx.op.unary.f32(i32 23, float %3214)  ; Log(value)
  %3218 = fmul fast float %3215, 0x4003333340000000
  %3219 = fmul fast float %3216, 0x4003333340000000
  %3220 = fmul fast float %3217, 0x4003333340000000
  %3221 = call float @dx.op.unary.f32(i32 21, float %3218)  ; Exp(value)
  %3222 = call float @dx.op.unary.f32(i32 21, float %3219)  ; Exp(value)
  %3223 = call float @dx.op.unary.f32(i32 21, float %3220)  ; Exp(value)
  %3224 = fsub fast float %3206, %3221
  %3225 = fsub fast float %3207, %3222
  %3226 = fsub fast float %3208, %3223
  %3227 = fmul fast float %3224, %3203
  %3228 = fmul fast float %3225, %3204
  %3229 = fmul fast float %3226, %3205
  %3230 = fadd fast float %3227, %3221
  %3231 = fadd fast float %3228, %3222
  %3232 = fadd fast float %3229, %3223
  br label %3396

; <label>:3233                                    ; preds = %3188
  %3234 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3191, i32 %3192, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3235 = extractvalue %dx.types.ResRet.f32 %3234, 0
  %3236 = fcmp fast ogt float %39, 5.000000e-01
  %3237 = fcmp fast olt float %3235, 1.000000e+00
  %3238 = and i1 %3236, %3237
  br i1 %3238, label %3239, label %3325

; <label>:3239                                    ; preds = %3233
  %3240 = sitofp i32 %3191 to float
  %3241 = sitofp i32 %3192 to float
  %3242 = fadd fast float %3240, 5.000000e-01
  %3243 = fadd fast float %3241, 5.000000e-01
  %3244 = fdiv fast float %3242, %46
  %3245 = fdiv fast float %3243, %47
  %3246 = fmul fast float %3244, 2.000000e+00
  %3247 = fmul fast float %3245, 2.000000e+00
  %3248 = fadd fast float %3246, -1.000000e+00
  %3249 = fsub fast float 1.000000e+00, %3247
  %3250 = fmul fast float %3248, %36
  %3251 = call float @dx.op.tertiary.f32(i32 46, float %3249, float %32, float %3250)  ; FMad(a,b,c)
  %3252 = call float @dx.op.tertiary.f32(i32 46, float %3235, float %28, float %3251)  ; FMad(a,b,c)
  %3253 = fadd fast float %3252, %24
  %3254 = call float @dx.op.unary.f32(i32 6, float %3253)  ; FAbs(value)
  %3255 = fcmp fast ogt float %3254, 0x3EB0C6F7A0000000
  br i1 %3255, label %3256, label %3325

; <label>:3256                                    ; preds = %3239
  %3257 = fmul fast float %3248, %35
  %3258 = call float @dx.op.tertiary.f32(i32 46, float %3249, float %31, float %3257)  ; FMad(a,b,c)
  %3259 = call float @dx.op.tertiary.f32(i32 46, float %3235, float %27, float %3258)  ; FMad(a,b,c)
  %3260 = fadd fast float %3259, %23
  %3261 = fmul fast float %3248, %34
  %3262 = call float @dx.op.tertiary.f32(i32 46, float %3249, float %30, float %3261)  ; FMad(a,b,c)
  %3263 = call float @dx.op.tertiary.f32(i32 46, float %3235, float %26, float %3262)  ; FMad(a,b,c)
  %3264 = fadd fast float %3263, %22
  %3265 = fmul fast float %3248, %33
  %3266 = call float @dx.op.tertiary.f32(i32 46, float %3249, float %29, float %3265)  ; FMad(a,b,c)
  %3267 = call float @dx.op.tertiary.f32(i32 46, float %3235, float %25, float %3266)  ; FMad(a,b,c)
  %3268 = fadd fast float %3267, %21
  %3269 = fdiv fast float %3268, %3253
  %3270 = fdiv fast float %3264, %3253
  %3271 = fdiv fast float %3260, %3253
  %3272 = fsub fast float %3269, %18
  %3273 = fsub fast float %3270, %19
  %3274 = fsub fast float %3271, %20
  %3275 = fmul fast float %3272, %3272
  %3276 = fmul fast float %3273, %3273
  %3277 = fadd fast float %3276, %3275
  %3278 = fmul fast float %3274, %3274
  %3279 = fadd fast float %3277, %3278
  %3280 = call float @dx.op.unary.f32(i32 24, float %3279)  ; Sqrt(value)
  %3281 = fsub fast float %3280, %10
  %3282 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3281)  ; FMax(a,b)
  %3283 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %3283, label %3284, label %3307

; <label>:3284                                    ; preds = %3256
  %3285 = call float @dx.op.unary.f32(i32 6, float %3273)  ; FAbs(value)
  %3286 = fmul fast float %3285, %12
  %3287 = fcmp fast olt float %3286, 0x3F50624DE0000000
  br i1 %3287, label %3288, label %3291

; <label>:3288                                    ; preds = %3284
  %3289 = fmul fast float %3286, 5.000000e-01
  %3290 = fsub fast float 1.000000e+00, %3289
  br label %3296

; <label>:3291                                    ; preds = %3284
  %3292 = fmul fast float %3286, 0xBFF7154760000000
  %3293 = call float @dx.op.unary.f32(i32 21, float %3292)  ; Exp(value)
  %3294 = fsub fast float 1.000000e+00, %3293
  %3295 = fdiv fast float %3294, %3286
  br label %3296

; <label>:3296                                    ; preds = %3291, %3288
  %3297 = phi float [ %3290, %3288 ], [ %3295, %3291 ]
  %3298 = call float @dx.op.binary.f32(i32 36, float %3270, float %19)  ; FMin(a,b)
  %3299 = fsub fast float %3298, %11
  %3300 = fmul fast float %12, %3299
  %3301 = fsub fast float -0.000000e+00, %3300
  %3302 = call float @dx.op.binary.f32(i32 35, float %3301, float -4.000000e+01)  ; FMax(a,b)
  %3303 = call float @dx.op.binary.f32(i32 36, float %3302, float 5.000000e+00)  ; FMin(a,b)
  %3304 = fmul fast float %3303, 0x3FF7154760000000
  %3305 = call float @dx.op.unary.f32(i32 21, float %3304)  ; Exp(value)
  %3306 = fmul fast float %3305, %3297
  br label %3307

; <label>:3307                                    ; preds = %3296, %3256
  %3308 = phi float [ %3306, %3296 ], [ 1.000000e+00, %3256 ]
  %3309 = fmul fast float %3282, %17
  %3310 = fmul fast float %3309, %3308
  %3311 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3310)  ; FMin(a,b)
  %3312 = fmul fast float %3311, 0xBFF7154760000000
  %3313 = call float @dx.op.unary.f32(i32 21, float %3312)  ; Exp(value)
  %3314 = fsub fast float 1.000000e+00, %3313
  %3315 = call float @dx.op.binary.f32(i32 36, float %13, float %3314)  ; FMin(a,b)
  %3316 = fsub fast float %14, %3194
  %3317 = fsub fast float %15, %3195
  %3318 = fsub fast float %16, %3196
  %3319 = fmul fast float %3315, %3316
  %3320 = fmul fast float %3315, %3317
  %3321 = fmul fast float %3315, %3318
  %3322 = fadd fast float %3319, %3194
  %3323 = fadd fast float %3320, %3195
  %3324 = fadd fast float %3321, %3196
  br label %3325

; <label>:3325                                    ; preds = %3307, %3239, %3233
  %3326 = phi float [ %3322, %3307 ], [ %3194, %3239 ], [ %3194, %3233 ]
  %3327 = phi float [ %3323, %3307 ], [ %3195, %3239 ], [ %3195, %3233 ]
  %3328 = phi float [ %3324, %3307 ], [ %3196, %3239 ], [ %3196, %3233 ]
  %3329 = fadd fast float %6, 1.000000e+00
  %3330 = fadd fast float %7, 1.000000e+00
  %3331 = fsub fast float 1.000000e+00, %6
  %3332 = fmul fast float %37, %3329
  %3333 = fmul fast float %37, %3330
  %3334 = fmul fast float %37, %3331
  %3335 = fmul fast float %3332, %3326
  %3336 = fmul fast float %3333, %3327
  %3337 = fmul fast float %3334, %3328
  %3338 = fcmp fast ult float %38, 5.000000e-01
  br i1 %3338, label %3364, label %3339

; <label>:3339                                    ; preds = %3325
  %3340 = fmul fast float %3335, 0x4004147AE0000000
  %3341 = fmul fast float %3336, 0x4004147AE0000000
  %3342 = fmul fast float %3337, 0x4004147AE0000000
  %3343 = fadd fast float %3340, 0x3F9EB851E0000000
  %3344 = fadd fast float %3341, 0x3F9EB851E0000000
  %3345 = fadd fast float %3342, 0x3F9EB851E0000000
  %3346 = fmul fast float %3343, %3335
  %3347 = fmul fast float %3344, %3336
  %3348 = fmul fast float %3345, %3337
  %3349 = fmul fast float %3335, 0x400370A3E0000000
  %3350 = fmul fast float %3336, 0x400370A3E0000000
  %3351 = fmul fast float %3337, 0x400370A3E0000000
  %3352 = fadd fast float %3349, 0x3FE2E147A0000000
  %3353 = fadd fast float %3350, 0x3FE2E147A0000000
  %3354 = fadd fast float %3351, 0x3FE2E147A0000000
  %3355 = fmul fast float %3352, %3335
  %3356 = fmul fast float %3353, %3336
  %3357 = fmul fast float %3354, %3337
  %3358 = fadd fast float %3355, 0x3FC1EB8520000000
  %3359 = fadd fast float %3356, 0x3FC1EB8520000000
  %3360 = fadd fast float %3357, 0x3FC1EB8520000000
  %3361 = fdiv fast float %3346, %3358
  %3362 = fdiv fast float %3347, %3359
  %3363 = fdiv fast float %3348, %3360
  br label %3364

; <label>:3364                                    ; preds = %3339, %3325
  %3365 = phi float [ %3361, %3339 ], [ %3335, %3325 ]
  %3366 = phi float [ %3362, %3339 ], [ %3336, %3325 ]
  %3367 = phi float [ %3363, %3339 ], [ %3337, %3325 ]
  %3368 = call float @dx.op.unary.f32(i32 7, float %3365)  ; Saturate(value)
  %3369 = call float @dx.op.unary.f32(i32 7, float %3366)  ; Saturate(value)
  %3370 = call float @dx.op.unary.f32(i32 7, float %3367)  ; Saturate(value)
  %3371 = call float @dx.op.dot3.f32(i32 55, float %3368, float %3369, float %3370, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3372 = fsub fast float %3368, %3371
  %3373 = fsub fast float %3369, %3371
  %3374 = fsub fast float %3370, %3371
  %3375 = fmul fast float %3372, %9
  %3376 = fmul fast float %3373, %9
  %3377 = fmul fast float %3374, %9
  %3378 = fadd fast float %3375, %3371
  %3379 = fadd fast float %3376, %3371
  %3380 = fadd fast float %3377, %3371
  %3381 = call float @dx.op.unary.f32(i32 7, float %3378)  ; Saturate(value)
  %3382 = call float @dx.op.unary.f32(i32 7, float %3379)  ; Saturate(value)
  %3383 = call float @dx.op.unary.f32(i32 7, float %3380)  ; Saturate(value)
  %3384 = fadd fast float %3381, 0xBFC70A3D80000000
  %3385 = fadd fast float %3382, 0xBFC70A3D80000000
  %3386 = fadd fast float %3383, 0xBFC70A3D80000000
  %3387 = fmul fast float %3384, %8
  %3388 = fmul fast float %3385, %8
  %3389 = fmul fast float %3386, %8
  %3390 = fadd fast float %3387, 0x3FC70A3D80000000
  %3391 = fadd fast float %3388, 0x3FC70A3D80000000
  %3392 = fadd fast float %3389, 0x3FC70A3D80000000
  %3393 = call float @dx.op.unary.f32(i32 7, float %3390)  ; Saturate(value)
  %3394 = call float @dx.op.unary.f32(i32 7, float %3391)  ; Saturate(value)
  %3395 = call float @dx.op.unary.f32(i32 7, float %3392)  ; Saturate(value)
  br label %3396

; <label>:3396                                    ; preds = %3364, %3199
  %3397 = phi float [ %3230, %3199 ], [ %3393, %3364 ]
  %3398 = phi float [ %3231, %3199 ], [ %3394, %3364 ]
  %3399 = phi float [ %3232, %3199 ], [ %3395, %3364 ]
  %3400 = fsub fast float %3397, %2931
  %3401 = fsub fast float %3398, %2932
  %3402 = fsub fast float %3399, %2933
  %3403 = fmul fast float %3400, %3186
  %3404 = fmul fast float %3401, %3186
  %3405 = fmul fast float %3402, %3186
  %3406 = fadd fast float %3403, %2931
  %3407 = fadd fast float %3404, %2932
  %3408 = fadd fast float %3405, %2933
  br label %3409

; <label>:3409                                    ; preds = %3396, %3173
  %3410 = phi float [ %3406, %3396 ], [ %2931, %3173 ]
  %3411 = phi float [ %3407, %3396 ], [ %2932, %3173 ]
  %3412 = phi float [ %3408, %3396 ], [ %2933, %3173 ]
  %3413 = add i32 %64, -1
  %3414 = call i32 @dx.op.binary.i32(i32 37, i32 %3413, i32 0)  ; IMax(a,b)
  %3415 = call i32 @dx.op.binary.i32(i32 37, i32 %71, i32 0)  ; IMax(a,b)
  %3416 = call i32 @dx.op.binary.i32(i32 38, i32 %3414, i32 %60)  ; IMin(a,b)
  %3417 = call i32 @dx.op.binary.i32(i32 38, i32 %3415, i32 %61)  ; IMin(a,b)
  %3418 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3416, i32 %3417, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3419 = extractvalue %dx.types.ResRet.f32 %3418, 0
  %3420 = fsub fast float %3419, %87
  %3421 = call float @dx.op.unary.f32(i32 6, float %3420)  ; FAbs(value)
  %3422 = fdiv fast float %3421, %2945
  %3423 = fsub fast float 1.000000e+00, %3422
  %3424 = call float @dx.op.unary.f32(i32 7, float %3423)  ; Saturate(value)
  %3425 = fcmp fast ugt float %3424, 0.000000e+00
  br i1 %3425, label %3426, label %3647

; <label>:3426                                    ; preds = %3409
  %3427 = call i32 @dx.op.binary.i32(i32 37, i32 %3416, i32 0)  ; IMax(a,b)
  %3428 = call i32 @dx.op.binary.i32(i32 37, i32 %3417, i32 0)  ; IMax(a,b)
  %3429 = call i32 @dx.op.binary.i32(i32 38, i32 %3427, i32 %60)  ; IMin(a,b)
  %3430 = call i32 @dx.op.binary.i32(i32 38, i32 %3428, i32 %61)  ; IMin(a,b)
  %3431 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3429, i32 %3430, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3432 = extractvalue %dx.types.ResRet.f32 %3431, 0
  %3433 = extractvalue %dx.types.ResRet.f32 %3431, 1
  %3434 = extractvalue %dx.types.ResRet.f32 %3431, 2
  %3435 = extractvalue %dx.types.ResRet.f32 %3431, 3
  %3436 = fcmp fast olt float %3435, 0.000000e+00
  br i1 %3436, label %3437, label %3471

; <label>:3437                                    ; preds = %3426
  %3438 = fcmp fast ogt float %3432, 0x3FA4B5DCC0000000
  %3439 = fcmp fast ogt float %3433, 0x3FA4B5DCC0000000
  %3440 = fcmp fast ogt float %3434, 0x3FA4B5DCC0000000
  %3441 = select i1 %3438, float 0.000000e+00, float 1.000000e+00
  %3442 = select i1 %3439, float 0.000000e+00, float 1.000000e+00
  %3443 = select i1 %3440, float 0.000000e+00, float 1.000000e+00
  %3444 = fmul fast float %3432, 0x3FB3D07220000000
  %3445 = fmul fast float %3433, 0x3FB3D07220000000
  %3446 = fmul fast float %3434, 0x3FB3D07220000000
  %3447 = fadd fast float %3432, 0x3FAC28F5C0000000
  %3448 = fadd fast float %3433, 0x3FAC28F5C0000000
  %3449 = fadd fast float %3434, 0x3FAC28F5C0000000
  %3450 = fmul fast float %3447, 0x3FEE54EDE0000000
  %3451 = fmul fast float %3448, 0x3FEE54EDE0000000
  %3452 = fmul fast float %3449, 0x3FEE54EDE0000000
  %3453 = call float @dx.op.unary.f32(i32 23, float %3450)  ; Log(value)
  %3454 = call float @dx.op.unary.f32(i32 23, float %3451)  ; Log(value)
  %3455 = call float @dx.op.unary.f32(i32 23, float %3452)  ; Log(value)
  %3456 = fmul fast float %3453, 0x4003333340000000
  %3457 = fmul fast float %3454, 0x4003333340000000
  %3458 = fmul fast float %3455, 0x4003333340000000
  %3459 = call float @dx.op.unary.f32(i32 21, float %3456)  ; Exp(value)
  %3460 = call float @dx.op.unary.f32(i32 21, float %3457)  ; Exp(value)
  %3461 = call float @dx.op.unary.f32(i32 21, float %3458)  ; Exp(value)
  %3462 = fsub fast float %3444, %3459
  %3463 = fsub fast float %3445, %3460
  %3464 = fsub fast float %3446, %3461
  %3465 = fmul fast float %3462, %3441
  %3466 = fmul fast float %3463, %3442
  %3467 = fmul fast float %3464, %3443
  %3468 = fadd fast float %3465, %3459
  %3469 = fadd fast float %3466, %3460
  %3470 = fadd fast float %3467, %3461
  br label %3634

; <label>:3471                                    ; preds = %3426
  %3472 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3429, i32 %3430, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3473 = extractvalue %dx.types.ResRet.f32 %3472, 0
  %3474 = fcmp fast ogt float %39, 5.000000e-01
  %3475 = fcmp fast olt float %3473, 1.000000e+00
  %3476 = and i1 %3474, %3475
  br i1 %3476, label %3477, label %3563

; <label>:3477                                    ; preds = %3471
  %3478 = sitofp i32 %3429 to float
  %3479 = sitofp i32 %3430 to float
  %3480 = fadd fast float %3478, 5.000000e-01
  %3481 = fadd fast float %3479, 5.000000e-01
  %3482 = fdiv fast float %3480, %46
  %3483 = fdiv fast float %3481, %47
  %3484 = fmul fast float %3482, 2.000000e+00
  %3485 = fmul fast float %3483, 2.000000e+00
  %3486 = fadd fast float %3484, -1.000000e+00
  %3487 = fsub fast float 1.000000e+00, %3485
  %3488 = fmul fast float %3486, %36
  %3489 = call float @dx.op.tertiary.f32(i32 46, float %3487, float %32, float %3488)  ; FMad(a,b,c)
  %3490 = call float @dx.op.tertiary.f32(i32 46, float %3473, float %28, float %3489)  ; FMad(a,b,c)
  %3491 = fadd fast float %3490, %24
  %3492 = call float @dx.op.unary.f32(i32 6, float %3491)  ; FAbs(value)
  %3493 = fcmp fast ogt float %3492, 0x3EB0C6F7A0000000
  br i1 %3493, label %3494, label %3563

; <label>:3494                                    ; preds = %3477
  %3495 = fmul fast float %3486, %35
  %3496 = call float @dx.op.tertiary.f32(i32 46, float %3487, float %31, float %3495)  ; FMad(a,b,c)
  %3497 = call float @dx.op.tertiary.f32(i32 46, float %3473, float %27, float %3496)  ; FMad(a,b,c)
  %3498 = fadd fast float %3497, %23
  %3499 = fmul fast float %3486, %34
  %3500 = call float @dx.op.tertiary.f32(i32 46, float %3487, float %30, float %3499)  ; FMad(a,b,c)
  %3501 = call float @dx.op.tertiary.f32(i32 46, float %3473, float %26, float %3500)  ; FMad(a,b,c)
  %3502 = fadd fast float %3501, %22
  %3503 = fmul fast float %3486, %33
  %3504 = call float @dx.op.tertiary.f32(i32 46, float %3487, float %29, float %3503)  ; FMad(a,b,c)
  %3505 = call float @dx.op.tertiary.f32(i32 46, float %3473, float %25, float %3504)  ; FMad(a,b,c)
  %3506 = fadd fast float %3505, %21
  %3507 = fdiv fast float %3506, %3491
  %3508 = fdiv fast float %3502, %3491
  %3509 = fdiv fast float %3498, %3491
  %3510 = fsub fast float %3507, %18
  %3511 = fsub fast float %3508, %19
  %3512 = fsub fast float %3509, %20
  %3513 = fmul fast float %3510, %3510
  %3514 = fmul fast float %3511, %3511
  %3515 = fadd fast float %3514, %3513
  %3516 = fmul fast float %3512, %3512
  %3517 = fadd fast float %3515, %3516
  %3518 = call float @dx.op.unary.f32(i32 24, float %3517)  ; Sqrt(value)
  %3519 = fsub fast float %3518, %10
  %3520 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3519)  ; FMax(a,b)
  %3521 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %3521, label %3522, label %3545

; <label>:3522                                    ; preds = %3494
  %3523 = call float @dx.op.unary.f32(i32 6, float %3511)  ; FAbs(value)
  %3524 = fmul fast float %3523, %12
  %3525 = fcmp fast olt float %3524, 0x3F50624DE0000000
  br i1 %3525, label %3526, label %3529

; <label>:3526                                    ; preds = %3522
  %3527 = fmul fast float %3524, 5.000000e-01
  %3528 = fsub fast float 1.000000e+00, %3527
  br label %3534

; <label>:3529                                    ; preds = %3522
  %3530 = fmul fast float %3524, 0xBFF7154760000000
  %3531 = call float @dx.op.unary.f32(i32 21, float %3530)  ; Exp(value)
  %3532 = fsub fast float 1.000000e+00, %3531
  %3533 = fdiv fast float %3532, %3524
  br label %3534

; <label>:3534                                    ; preds = %3529, %3526
  %3535 = phi float [ %3528, %3526 ], [ %3533, %3529 ]
  %3536 = call float @dx.op.binary.f32(i32 36, float %3508, float %19)  ; FMin(a,b)
  %3537 = fsub fast float %3536, %11
  %3538 = fmul fast float %12, %3537
  %3539 = fsub fast float -0.000000e+00, %3538
  %3540 = call float @dx.op.binary.f32(i32 35, float %3539, float -4.000000e+01)  ; FMax(a,b)
  %3541 = call float @dx.op.binary.f32(i32 36, float %3540, float 5.000000e+00)  ; FMin(a,b)
  %3542 = fmul fast float %3541, 0x3FF7154760000000
  %3543 = call float @dx.op.unary.f32(i32 21, float %3542)  ; Exp(value)
  %3544 = fmul fast float %3543, %3535
  br label %3545

; <label>:3545                                    ; preds = %3534, %3494
  %3546 = phi float [ %3544, %3534 ], [ 1.000000e+00, %3494 ]
  %3547 = fmul fast float %3520, %17
  %3548 = fmul fast float %3547, %3546
  %3549 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3548)  ; FMin(a,b)
  %3550 = fmul fast float %3549, 0xBFF7154760000000
  %3551 = call float @dx.op.unary.f32(i32 21, float %3550)  ; Exp(value)
  %3552 = fsub fast float 1.000000e+00, %3551
  %3553 = call float @dx.op.binary.f32(i32 36, float %13, float %3552)  ; FMin(a,b)
  %3554 = fsub fast float %14, %3432
  %3555 = fsub fast float %15, %3433
  %3556 = fsub fast float %16, %3434
  %3557 = fmul fast float %3553, %3554
  %3558 = fmul fast float %3553, %3555
  %3559 = fmul fast float %3553, %3556
  %3560 = fadd fast float %3557, %3432
  %3561 = fadd fast float %3558, %3433
  %3562 = fadd fast float %3559, %3434
  br label %3563

; <label>:3563                                    ; preds = %3545, %3477, %3471
  %3564 = phi float [ %3560, %3545 ], [ %3432, %3477 ], [ %3432, %3471 ]
  %3565 = phi float [ %3561, %3545 ], [ %3433, %3477 ], [ %3433, %3471 ]
  %3566 = phi float [ %3562, %3545 ], [ %3434, %3477 ], [ %3434, %3471 ]
  %3567 = fadd fast float %6, 1.000000e+00
  %3568 = fadd fast float %7, 1.000000e+00
  %3569 = fsub fast float 1.000000e+00, %6
  %3570 = fmul fast float %37, %3567
  %3571 = fmul fast float %37, %3568
  %3572 = fmul fast float %37, %3569
  %3573 = fmul fast float %3570, %3564
  %3574 = fmul fast float %3571, %3565
  %3575 = fmul fast float %3572, %3566
  %3576 = fcmp fast ult float %38, 5.000000e-01
  br i1 %3576, label %3602, label %3577

; <label>:3577                                    ; preds = %3563
  %3578 = fmul fast float %3573, 0x4004147AE0000000
  %3579 = fmul fast float %3574, 0x4004147AE0000000
  %3580 = fmul fast float %3575, 0x4004147AE0000000
  %3581 = fadd fast float %3578, 0x3F9EB851E0000000
  %3582 = fadd fast float %3579, 0x3F9EB851E0000000
  %3583 = fadd fast float %3580, 0x3F9EB851E0000000
  %3584 = fmul fast float %3581, %3573
  %3585 = fmul fast float %3582, %3574
  %3586 = fmul fast float %3583, %3575
  %3587 = fmul fast float %3573, 0x400370A3E0000000
  %3588 = fmul fast float %3574, 0x400370A3E0000000
  %3589 = fmul fast float %3575, 0x400370A3E0000000
  %3590 = fadd fast float %3587, 0x3FE2E147A0000000
  %3591 = fadd fast float %3588, 0x3FE2E147A0000000
  %3592 = fadd fast float %3589, 0x3FE2E147A0000000
  %3593 = fmul fast float %3590, %3573
  %3594 = fmul fast float %3591, %3574
  %3595 = fmul fast float %3592, %3575
  %3596 = fadd fast float %3593, 0x3FC1EB8520000000
  %3597 = fadd fast float %3594, 0x3FC1EB8520000000
  %3598 = fadd fast float %3595, 0x3FC1EB8520000000
  %3599 = fdiv fast float %3584, %3596
  %3600 = fdiv fast float %3585, %3597
  %3601 = fdiv fast float %3586, %3598
  br label %3602

; <label>:3602                                    ; preds = %3577, %3563
  %3603 = phi float [ %3599, %3577 ], [ %3573, %3563 ]
  %3604 = phi float [ %3600, %3577 ], [ %3574, %3563 ]
  %3605 = phi float [ %3601, %3577 ], [ %3575, %3563 ]
  %3606 = call float @dx.op.unary.f32(i32 7, float %3603)  ; Saturate(value)
  %3607 = call float @dx.op.unary.f32(i32 7, float %3604)  ; Saturate(value)
  %3608 = call float @dx.op.unary.f32(i32 7, float %3605)  ; Saturate(value)
  %3609 = call float @dx.op.dot3.f32(i32 55, float %3606, float %3607, float %3608, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3610 = fsub fast float %3606, %3609
  %3611 = fsub fast float %3607, %3609
  %3612 = fsub fast float %3608, %3609
  %3613 = fmul fast float %3610, %9
  %3614 = fmul fast float %3611, %9
  %3615 = fmul fast float %3612, %9
  %3616 = fadd fast float %3613, %3609
  %3617 = fadd fast float %3614, %3609
  %3618 = fadd fast float %3615, %3609
  %3619 = call float @dx.op.unary.f32(i32 7, float %3616)  ; Saturate(value)
  %3620 = call float @dx.op.unary.f32(i32 7, float %3617)  ; Saturate(value)
  %3621 = call float @dx.op.unary.f32(i32 7, float %3618)  ; Saturate(value)
  %3622 = fadd fast float %3619, 0xBFC70A3D80000000
  %3623 = fadd fast float %3620, 0xBFC70A3D80000000
  %3624 = fadd fast float %3621, 0xBFC70A3D80000000
  %3625 = fmul fast float %3622, %8
  %3626 = fmul fast float %3623, %8
  %3627 = fmul fast float %3624, %8
  %3628 = fadd fast float %3625, 0x3FC70A3D80000000
  %3629 = fadd fast float %3626, 0x3FC70A3D80000000
  %3630 = fadd fast float %3627, 0x3FC70A3D80000000
  %3631 = call float @dx.op.unary.f32(i32 7, float %3628)  ; Saturate(value)
  %3632 = call float @dx.op.unary.f32(i32 7, float %3629)  ; Saturate(value)
  %3633 = call float @dx.op.unary.f32(i32 7, float %3630)  ; Saturate(value)
  br label %3634

; <label>:3634                                    ; preds = %3602, %3437
  %3635 = phi float [ %3468, %3437 ], [ %3631, %3602 ]
  %3636 = phi float [ %3469, %3437 ], [ %3632, %3602 ]
  %3637 = phi float [ %3470, %3437 ], [ %3633, %3602 ]
  %3638 = fsub fast float %3635, %2931
  %3639 = fsub fast float %3636, %2932
  %3640 = fsub fast float %3637, %2933
  %3641 = fmul fast float %3638, %3424
  %3642 = fmul fast float %3639, %3424
  %3643 = fmul fast float %3640, %3424
  %3644 = fadd fast float %3641, %2931
  %3645 = fadd fast float %3642, %2932
  %3646 = fadd fast float %3643, %2933
  br label %3647

; <label>:3647                                    ; preds = %3634, %3409
  %3648 = phi float [ %3644, %3634 ], [ %2931, %3409 ]
  %3649 = phi float [ %3645, %3634 ], [ %2932, %3409 ]
  %3650 = phi float [ %3646, %3634 ], [ %2933, %3409 ]
  %3651 = add i32 %64, 1
  %3652 = call i32 @dx.op.binary.i32(i32 37, i32 %3651, i32 0)  ; IMax(a,b)
  %3653 = call i32 @dx.op.binary.i32(i32 38, i32 %3652, i32 %60)  ; IMin(a,b)
  %3654 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3653, i32 %3417, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3655 = extractvalue %dx.types.ResRet.f32 %3654, 0
  %3656 = fsub fast float %3655, %87
  %3657 = call float @dx.op.unary.f32(i32 6, float %3656)  ; FAbs(value)
  %3658 = fdiv fast float %3657, %2945
  %3659 = fsub fast float 1.000000e+00, %3658
  %3660 = call float @dx.op.unary.f32(i32 7, float %3659)  ; Saturate(value)
  %3661 = fcmp fast ugt float %3660, 0.000000e+00
  br i1 %3661, label %3662, label %3883

; <label>:3662                                    ; preds = %3647
  %3663 = call i32 @dx.op.binary.i32(i32 37, i32 %3653, i32 0)  ; IMax(a,b)
  %3664 = call i32 @dx.op.binary.i32(i32 37, i32 %3417, i32 0)  ; IMax(a,b)
  %3665 = call i32 @dx.op.binary.i32(i32 38, i32 %3663, i32 %60)  ; IMin(a,b)
  %3666 = call i32 @dx.op.binary.i32(i32 38, i32 %3664, i32 %61)  ; IMin(a,b)
  %3667 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3665, i32 %3666, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3668 = extractvalue %dx.types.ResRet.f32 %3667, 0
  %3669 = extractvalue %dx.types.ResRet.f32 %3667, 1
  %3670 = extractvalue %dx.types.ResRet.f32 %3667, 2
  %3671 = extractvalue %dx.types.ResRet.f32 %3667, 3
  %3672 = fcmp fast olt float %3671, 0.000000e+00
  br i1 %3672, label %3673, label %3707

; <label>:3673                                    ; preds = %3662
  %3674 = fcmp fast ogt float %3668, 0x3FA4B5DCC0000000
  %3675 = fcmp fast ogt float %3669, 0x3FA4B5DCC0000000
  %3676 = fcmp fast ogt float %3670, 0x3FA4B5DCC0000000
  %3677 = select i1 %3674, float 0.000000e+00, float 1.000000e+00
  %3678 = select i1 %3675, float 0.000000e+00, float 1.000000e+00
  %3679 = select i1 %3676, float 0.000000e+00, float 1.000000e+00
  %3680 = fmul fast float %3668, 0x3FB3D07220000000
  %3681 = fmul fast float %3669, 0x3FB3D07220000000
  %3682 = fmul fast float %3670, 0x3FB3D07220000000
  %3683 = fadd fast float %3668, 0x3FAC28F5C0000000
  %3684 = fadd fast float %3669, 0x3FAC28F5C0000000
  %3685 = fadd fast float %3670, 0x3FAC28F5C0000000
  %3686 = fmul fast float %3683, 0x3FEE54EDE0000000
  %3687 = fmul fast float %3684, 0x3FEE54EDE0000000
  %3688 = fmul fast float %3685, 0x3FEE54EDE0000000
  %3689 = call float @dx.op.unary.f32(i32 23, float %3686)  ; Log(value)
  %3690 = call float @dx.op.unary.f32(i32 23, float %3687)  ; Log(value)
  %3691 = call float @dx.op.unary.f32(i32 23, float %3688)  ; Log(value)
  %3692 = fmul fast float %3689, 0x4003333340000000
  %3693 = fmul fast float %3690, 0x4003333340000000
  %3694 = fmul fast float %3691, 0x4003333340000000
  %3695 = call float @dx.op.unary.f32(i32 21, float %3692)  ; Exp(value)
  %3696 = call float @dx.op.unary.f32(i32 21, float %3693)  ; Exp(value)
  %3697 = call float @dx.op.unary.f32(i32 21, float %3694)  ; Exp(value)
  %3698 = fsub fast float %3680, %3695
  %3699 = fsub fast float %3681, %3696
  %3700 = fsub fast float %3682, %3697
  %3701 = fmul fast float %3698, %3677
  %3702 = fmul fast float %3699, %3678
  %3703 = fmul fast float %3700, %3679
  %3704 = fadd fast float %3701, %3695
  %3705 = fadd fast float %3702, %3696
  %3706 = fadd fast float %3703, %3697
  br label %3870

; <label>:3707                                    ; preds = %3662
  %3708 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3665, i32 %3666, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3709 = extractvalue %dx.types.ResRet.f32 %3708, 0
  %3710 = fcmp fast ogt float %39, 5.000000e-01
  %3711 = fcmp fast olt float %3709, 1.000000e+00
  %3712 = and i1 %3710, %3711
  br i1 %3712, label %3713, label %3799

; <label>:3713                                    ; preds = %3707
  %3714 = sitofp i32 %3665 to float
  %3715 = sitofp i32 %3666 to float
  %3716 = fadd fast float %3714, 5.000000e-01
  %3717 = fadd fast float %3715, 5.000000e-01
  %3718 = fdiv fast float %3716, %46
  %3719 = fdiv fast float %3717, %47
  %3720 = fmul fast float %3718, 2.000000e+00
  %3721 = fmul fast float %3719, 2.000000e+00
  %3722 = fadd fast float %3720, -1.000000e+00
  %3723 = fsub fast float 1.000000e+00, %3721
  %3724 = fmul fast float %3722, %36
  %3725 = call float @dx.op.tertiary.f32(i32 46, float %3723, float %32, float %3724)  ; FMad(a,b,c)
  %3726 = call float @dx.op.tertiary.f32(i32 46, float %3709, float %28, float %3725)  ; FMad(a,b,c)
  %3727 = fadd fast float %3726, %24
  %3728 = call float @dx.op.unary.f32(i32 6, float %3727)  ; FAbs(value)
  %3729 = fcmp fast ogt float %3728, 0x3EB0C6F7A0000000
  br i1 %3729, label %3730, label %3799

; <label>:3730                                    ; preds = %3713
  %3731 = fmul fast float %3722, %35
  %3732 = call float @dx.op.tertiary.f32(i32 46, float %3723, float %31, float %3731)  ; FMad(a,b,c)
  %3733 = call float @dx.op.tertiary.f32(i32 46, float %3709, float %27, float %3732)  ; FMad(a,b,c)
  %3734 = fadd fast float %3733, %23
  %3735 = fmul fast float %3722, %34
  %3736 = call float @dx.op.tertiary.f32(i32 46, float %3723, float %30, float %3735)  ; FMad(a,b,c)
  %3737 = call float @dx.op.tertiary.f32(i32 46, float %3709, float %26, float %3736)  ; FMad(a,b,c)
  %3738 = fadd fast float %3737, %22
  %3739 = fmul fast float %3722, %33
  %3740 = call float @dx.op.tertiary.f32(i32 46, float %3723, float %29, float %3739)  ; FMad(a,b,c)
  %3741 = call float @dx.op.tertiary.f32(i32 46, float %3709, float %25, float %3740)  ; FMad(a,b,c)
  %3742 = fadd fast float %3741, %21
  %3743 = fdiv fast float %3742, %3727
  %3744 = fdiv fast float %3738, %3727
  %3745 = fdiv fast float %3734, %3727
  %3746 = fsub fast float %3743, %18
  %3747 = fsub fast float %3744, %19
  %3748 = fsub fast float %3745, %20
  %3749 = fmul fast float %3746, %3746
  %3750 = fmul fast float %3747, %3747
  %3751 = fadd fast float %3750, %3749
  %3752 = fmul fast float %3748, %3748
  %3753 = fadd fast float %3751, %3752
  %3754 = call float @dx.op.unary.f32(i32 24, float %3753)  ; Sqrt(value)
  %3755 = fsub fast float %3754, %10
  %3756 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3755)  ; FMax(a,b)
  %3757 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %3757, label %3758, label %3781

; <label>:3758                                    ; preds = %3730
  %3759 = call float @dx.op.unary.f32(i32 6, float %3747)  ; FAbs(value)
  %3760 = fmul fast float %3759, %12
  %3761 = fcmp fast olt float %3760, 0x3F50624DE0000000
  br i1 %3761, label %3762, label %3765

; <label>:3762                                    ; preds = %3758
  %3763 = fmul fast float %3760, 5.000000e-01
  %3764 = fsub fast float 1.000000e+00, %3763
  br label %3770

; <label>:3765                                    ; preds = %3758
  %3766 = fmul fast float %3760, 0xBFF7154760000000
  %3767 = call float @dx.op.unary.f32(i32 21, float %3766)  ; Exp(value)
  %3768 = fsub fast float 1.000000e+00, %3767
  %3769 = fdiv fast float %3768, %3760
  br label %3770

; <label>:3770                                    ; preds = %3765, %3762
  %3771 = phi float [ %3764, %3762 ], [ %3769, %3765 ]
  %3772 = call float @dx.op.binary.f32(i32 36, float %3744, float %19)  ; FMin(a,b)
  %3773 = fsub fast float %3772, %11
  %3774 = fmul fast float %12, %3773
  %3775 = fsub fast float -0.000000e+00, %3774
  %3776 = call float @dx.op.binary.f32(i32 35, float %3775, float -4.000000e+01)  ; FMax(a,b)
  %3777 = call float @dx.op.binary.f32(i32 36, float %3776, float 5.000000e+00)  ; FMin(a,b)
  %3778 = fmul fast float %3777, 0x3FF7154760000000
  %3779 = call float @dx.op.unary.f32(i32 21, float %3778)  ; Exp(value)
  %3780 = fmul fast float %3779, %3771
  br label %3781

; <label>:3781                                    ; preds = %3770, %3730
  %3782 = phi float [ %3780, %3770 ], [ 1.000000e+00, %3730 ]
  %3783 = fmul fast float %3756, %17
  %3784 = fmul fast float %3783, %3782
  %3785 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3784)  ; FMin(a,b)
  %3786 = fmul fast float %3785, 0xBFF7154760000000
  %3787 = call float @dx.op.unary.f32(i32 21, float %3786)  ; Exp(value)
  %3788 = fsub fast float 1.000000e+00, %3787
  %3789 = call float @dx.op.binary.f32(i32 36, float %13, float %3788)  ; FMin(a,b)
  %3790 = fsub fast float %14, %3668
  %3791 = fsub fast float %15, %3669
  %3792 = fsub fast float %16, %3670
  %3793 = fmul fast float %3789, %3790
  %3794 = fmul fast float %3789, %3791
  %3795 = fmul fast float %3789, %3792
  %3796 = fadd fast float %3793, %3668
  %3797 = fadd fast float %3794, %3669
  %3798 = fadd fast float %3795, %3670
  br label %3799

; <label>:3799                                    ; preds = %3781, %3713, %3707
  %3800 = phi float [ %3796, %3781 ], [ %3668, %3713 ], [ %3668, %3707 ]
  %3801 = phi float [ %3797, %3781 ], [ %3669, %3713 ], [ %3669, %3707 ]
  %3802 = phi float [ %3798, %3781 ], [ %3670, %3713 ], [ %3670, %3707 ]
  %3803 = fadd fast float %6, 1.000000e+00
  %3804 = fadd fast float %7, 1.000000e+00
  %3805 = fsub fast float 1.000000e+00, %6
  %3806 = fmul fast float %37, %3803
  %3807 = fmul fast float %37, %3804
  %3808 = fmul fast float %37, %3805
  %3809 = fmul fast float %3806, %3800
  %3810 = fmul fast float %3807, %3801
  %3811 = fmul fast float %3808, %3802
  %3812 = fcmp fast ult float %38, 5.000000e-01
  br i1 %3812, label %3838, label %3813

; <label>:3813                                    ; preds = %3799
  %3814 = fmul fast float %3809, 0x4004147AE0000000
  %3815 = fmul fast float %3810, 0x4004147AE0000000
  %3816 = fmul fast float %3811, 0x4004147AE0000000
  %3817 = fadd fast float %3814, 0x3F9EB851E0000000
  %3818 = fadd fast float %3815, 0x3F9EB851E0000000
  %3819 = fadd fast float %3816, 0x3F9EB851E0000000
  %3820 = fmul fast float %3817, %3809
  %3821 = fmul fast float %3818, %3810
  %3822 = fmul fast float %3819, %3811
  %3823 = fmul fast float %3809, 0x400370A3E0000000
  %3824 = fmul fast float %3810, 0x400370A3E0000000
  %3825 = fmul fast float %3811, 0x400370A3E0000000
  %3826 = fadd fast float %3823, 0x3FE2E147A0000000
  %3827 = fadd fast float %3824, 0x3FE2E147A0000000
  %3828 = fadd fast float %3825, 0x3FE2E147A0000000
  %3829 = fmul fast float %3826, %3809
  %3830 = fmul fast float %3827, %3810
  %3831 = fmul fast float %3828, %3811
  %3832 = fadd fast float %3829, 0x3FC1EB8520000000
  %3833 = fadd fast float %3830, 0x3FC1EB8520000000
  %3834 = fadd fast float %3831, 0x3FC1EB8520000000
  %3835 = fdiv fast float %3820, %3832
  %3836 = fdiv fast float %3821, %3833
  %3837 = fdiv fast float %3822, %3834
  br label %3838

; <label>:3838                                    ; preds = %3813, %3799
  %3839 = phi float [ %3835, %3813 ], [ %3809, %3799 ]
  %3840 = phi float [ %3836, %3813 ], [ %3810, %3799 ]
  %3841 = phi float [ %3837, %3813 ], [ %3811, %3799 ]
  %3842 = call float @dx.op.unary.f32(i32 7, float %3839)  ; Saturate(value)
  %3843 = call float @dx.op.unary.f32(i32 7, float %3840)  ; Saturate(value)
  %3844 = call float @dx.op.unary.f32(i32 7, float %3841)  ; Saturate(value)
  %3845 = call float @dx.op.dot3.f32(i32 55, float %3842, float %3843, float %3844, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3846 = fsub fast float %3842, %3845
  %3847 = fsub fast float %3843, %3845
  %3848 = fsub fast float %3844, %3845
  %3849 = fmul fast float %3846, %9
  %3850 = fmul fast float %3847, %9
  %3851 = fmul fast float %3848, %9
  %3852 = fadd fast float %3849, %3845
  %3853 = fadd fast float %3850, %3845
  %3854 = fadd fast float %3851, %3845
  %3855 = call float @dx.op.unary.f32(i32 7, float %3852)  ; Saturate(value)
  %3856 = call float @dx.op.unary.f32(i32 7, float %3853)  ; Saturate(value)
  %3857 = call float @dx.op.unary.f32(i32 7, float %3854)  ; Saturate(value)
  %3858 = fadd fast float %3855, 0xBFC70A3D80000000
  %3859 = fadd fast float %3856, 0xBFC70A3D80000000
  %3860 = fadd fast float %3857, 0xBFC70A3D80000000
  %3861 = fmul fast float %3858, %8
  %3862 = fmul fast float %3859, %8
  %3863 = fmul fast float %3860, %8
  %3864 = fadd fast float %3861, 0x3FC70A3D80000000
  %3865 = fadd fast float %3862, 0x3FC70A3D80000000
  %3866 = fadd fast float %3863, 0x3FC70A3D80000000
  %3867 = call float @dx.op.unary.f32(i32 7, float %3864)  ; Saturate(value)
  %3868 = call float @dx.op.unary.f32(i32 7, float %3865)  ; Saturate(value)
  %3869 = call float @dx.op.unary.f32(i32 7, float %3866)  ; Saturate(value)
  br label %3870

; <label>:3870                                    ; preds = %3838, %3673
  %3871 = phi float [ %3704, %3673 ], [ %3867, %3838 ]
  %3872 = phi float [ %3705, %3673 ], [ %3868, %3838 ]
  %3873 = phi float [ %3706, %3673 ], [ %3869, %3838 ]
  %3874 = fsub fast float %3871, %2931
  %3875 = fsub fast float %3872, %2932
  %3876 = fsub fast float %3873, %2933
  %3877 = fmul fast float %3874, %3660
  %3878 = fmul fast float %3875, %3660
  %3879 = fmul fast float %3876, %3660
  %3880 = fadd fast float %3877, %2931
  %3881 = fadd fast float %3878, %2932
  %3882 = fadd fast float %3879, %2933
  br label %3883

; <label>:3883                                    ; preds = %3870, %3647
  %3884 = phi float [ %3880, %3870 ], [ %2931, %3647 ]
  %3885 = phi float [ %3881, %3870 ], [ %2932, %3647 ]
  %3886 = phi float [ %3882, %3870 ], [ %2933, %3647 ]
  %3887 = call float @dx.op.binary.f32(i32 36, float %3648, float %3884)  ; FMin(a,b)
  %3888 = call float @dx.op.binary.f32(i32 36, float %3649, float %3885)  ; FMin(a,b)
  %3889 = call float @dx.op.binary.f32(i32 36, float %3650, float %3886)  ; FMin(a,b)
  %3890 = call float @dx.op.binary.f32(i32 36, float %3174, float %3410)  ; FMin(a,b)
  %3891 = call float @dx.op.binary.f32(i32 36, float %3175, float %3411)  ; FMin(a,b)
  %3892 = call float @dx.op.binary.f32(i32 36, float %3176, float %3412)  ; FMin(a,b)
  %3893 = call float @dx.op.binary.f32(i32 36, float %3890, float %3887)  ; FMin(a,b)
  %3894 = call float @dx.op.binary.f32(i32 36, float %3891, float %3888)  ; FMin(a,b)
  %3895 = call float @dx.op.binary.f32(i32 36, float %3892, float %3889)  ; FMin(a,b)
  %3896 = call float @dx.op.binary.f32(i32 36, float %2931, float %3893)  ; FMin(a,b)
  %3897 = call float @dx.op.binary.f32(i32 36, float %2932, float %3894)  ; FMin(a,b)
  %3898 = call float @dx.op.binary.f32(i32 36, float %2933, float %3895)  ; FMin(a,b)
  %3899 = call float @dx.op.binary.f32(i32 35, float %3648, float %3884)  ; FMax(a,b)
  %3900 = call float @dx.op.binary.f32(i32 35, float %3649, float %3885)  ; FMax(a,b)
  %3901 = call float @dx.op.binary.f32(i32 35, float %3650, float %3886)  ; FMax(a,b)
  %3902 = call float @dx.op.binary.f32(i32 35, float %3174, float %3410)  ; FMax(a,b)
  %3903 = call float @dx.op.binary.f32(i32 35, float %3175, float %3411)  ; FMax(a,b)
  %3904 = call float @dx.op.binary.f32(i32 35, float %3176, float %3412)  ; FMax(a,b)
  %3905 = call float @dx.op.binary.f32(i32 35, float %3902, float %3899)  ; FMax(a,b)
  %3906 = call float @dx.op.binary.f32(i32 35, float %3903, float %3900)  ; FMax(a,b)
  %3907 = call float @dx.op.binary.f32(i32 35, float %3904, float %3901)  ; FMax(a,b)
  %3908 = call float @dx.op.binary.f32(i32 35, float %2931, float %3905)  ; FMax(a,b)
  %3909 = call float @dx.op.binary.f32(i32 35, float %2932, float %3906)  ; FMax(a,b)
  %3910 = call float @dx.op.binary.f32(i32 35, float %2933, float %3907)  ; FMax(a,b)
  %3911 = fsub fast float %3908, %3896
  %3912 = fsub fast float %3909, %3897
  %3913 = fsub fast float %3910, %3898
  %3914 = call float @dx.op.unary.f32(i32 6, float %3911)  ; FAbs(value)
  %3915 = call float @dx.op.unary.f32(i32 6, float %3912)  ; FAbs(value)
  %3916 = call float @dx.op.unary.f32(i32 6, float %3913)  ; FAbs(value)
  %3917 = call float @dx.op.binary.f32(i32 35, float %3915, float %3916)  ; FMax(a,b)
  %3918 = call float @dx.op.binary.f32(i32 35, float %3914, float %3917)  ; FMax(a,b)
  %3919 = call float @dx.op.binary.f32(i32 35, float %3909, float %3910)  ; FMax(a,b)
  %3920 = call float @dx.op.binary.f32(i32 35, float %3908, float %3919)  ; FMax(a,b)
  %3921 = fmul fast float %3920, 1.250000e-01
  %3922 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %3921)  ; FMax(a,b)
  %3923 = fcmp fast ogt float %3918, %3922
  br i1 %3923, label %3924, label %3986

; <label>:3924                                    ; preds = %3883
  %3925 = fsub fast float %3174, %3410
  %3926 = fsub fast float %3175, %3411
  %3927 = fsub fast float %3176, %3412
  %3928 = call float @dx.op.unary.f32(i32 6, float %3925)  ; FAbs(value)
  %3929 = call float @dx.op.unary.f32(i32 6, float %3926)  ; FAbs(value)
  %3930 = call float @dx.op.unary.f32(i32 6, float %3927)  ; FAbs(value)
  %3931 = call float @dx.op.binary.f32(i32 35, float %3929, float %3930)  ; FMax(a,b)
  %3932 = call float @dx.op.binary.f32(i32 35, float %3928, float %3931)  ; FMax(a,b)
  %3933 = fsub fast float %3648, %3884
  %3934 = fsub fast float %3649, %3885
  %3935 = fsub fast float %3650, %3886
  %3936 = call float @dx.op.unary.f32(i32 6, float %3933)  ; FAbs(value)
  %3937 = call float @dx.op.unary.f32(i32 6, float %3934)  ; FAbs(value)
  %3938 = call float @dx.op.unary.f32(i32 6, float %3935)  ; FAbs(value)
  %3939 = call float @dx.op.binary.f32(i32 35, float %3937, float %3938)  ; FMax(a,b)
  %3940 = call float @dx.op.binary.f32(i32 35, float %3936, float %3939)  ; FMax(a,b)
  %3941 = fcmp fast olt float %3932, %3940
  %3942 = select i1 %3941, float %3174, float %3648
  %3943 = select i1 %3941, float %3175, float %3649
  %3944 = select i1 %3941, float %3176, float %3650
  %3945 = select i1 %3941, float %3410, float %3884
  %3946 = select i1 %3941, float %3411, float %3885
  %3947 = select i1 %3941, float %3412, float %3886
  %3948 = fsub fast float %2931, %3945
  %3949 = fsub fast float %2932, %3946
  %3950 = fsub fast float %2933, %3947
  %3951 = fsub fast float %2931, %3942
  %3952 = fsub fast float %2932, %3943
  %3953 = fsub fast float %2933, %3944
  %3954 = call float @dx.op.dot3.f32(i32 55, float %3951, float %3952, float %3953, float %3948, float %3949, float %3950)  ; Dot3(ax,ay,az,bx,by,bz)
  %3955 = fcmp fast ogt float %3954, 0.000000e+00
  br i1 %3955, label %3956, label %3967

; <label>:3956                                    ; preds = %3924
  %3957 = fsub fast float %3942, %3945
  %3958 = fsub fast float %3943, %3946
  %3959 = fsub fast float %3944, %3947
  %3960 = call float @dx.op.unary.f32(i32 6, float %3957)  ; FAbs(value)
  %3961 = call float @dx.op.unary.f32(i32 6, float %3958)  ; FAbs(value)
  %3962 = call float @dx.op.unary.f32(i32 6, float %3959)  ; FAbs(value)
  %3963 = call float @dx.op.binary.f32(i32 35, float %3961, float %3962)  ; FMax(a,b)
  %3964 = call float @dx.op.binary.f32(i32 35, float %3960, float %3963)  ; FMax(a,b)
  %3965 = fmul fast float %3918, 2.500000e-01
  %3966 = fcmp fast olt float %3964, %3965
  br label %3967

; <label>:3967                                    ; preds = %3956, %3924
  %3968 = phi i1 [ false, %3924 ], [ %3966, %3956 ]
  %3969 = select i1 %3968, float 5.000000e-01, float 1.000000e+00
  %3970 = fmul fast float %3969, %3
  %3971 = fadd fast float %3942, %3945
  %3972 = fadd fast float %3943, %3946
  %3973 = fadd fast float %3944, %3947
  %3974 = fmul fast float %3971, 5.000000e-01
  %3975 = fmul fast float %3972, 5.000000e-01
  %3976 = fmul fast float %3973, 5.000000e-01
  %3977 = fsub fast float %3974, %2931
  %3978 = fsub fast float %3975, %2932
  %3979 = fsub fast float %3976, %2933
  %3980 = fmul fast float %3970, %3977
  %3981 = fmul fast float %3970, %3978
  %3982 = fmul fast float %3970, %3979
  %3983 = fadd fast float %3980, %2931
  %3984 = fadd fast float %3981, %2932
  %3985 = fadd fast float %3982, %2933
  br label %3986

; <label>:3986                                    ; preds = %3967, %3883, %2902
  %3987 = phi float [ %2931, %2902 ], [ %3983, %3967 ], [ %2931, %3883 ]
  %3988 = phi float [ %2932, %2902 ], [ %3984, %3967 ], [ %2932, %3883 ]
  %3989 = phi float [ %2933, %2902 ], [ %3985, %3967 ], [ %2933, %3883 ]
  %3990 = fcmp fast ogt float %3987, 0x3F69A5C380000000
  %3991 = fcmp fast ogt float %3988, 0x3F69A5C380000000
  %3992 = fcmp fast ogt float %3989, 0x3F69A5C380000000
  %3993 = select i1 %3990, float 0.000000e+00, float 1.000000e+00
  %3994 = select i1 %3991, float 0.000000e+00, float 1.000000e+00
  %3995 = select i1 %3992, float 0.000000e+00, float 1.000000e+00
  %3996 = fmul fast float %3987, 0x4029D70A40000000
  %3997 = fmul fast float %3988, 0x4029D70A40000000
  %3998 = fmul fast float %3989, 0x4029D70A40000000
  %3999 = call float @dx.op.binary.f32(i32 35, float %3987, float 0.000000e+00)  ; FMax(a,b)
  %4000 = call float @dx.op.binary.f32(i32 35, float %3988, float 0.000000e+00)  ; FMax(a,b)
  %4001 = call float @dx.op.binary.f32(i32 35, float %3989, float 0.000000e+00)  ; FMax(a,b)
  %4002 = call float @dx.op.unary.f32(i32 23, float %3999)  ; Log(value)
  %4003 = call float @dx.op.unary.f32(i32 23, float %4000)  ; Log(value)
  %4004 = call float @dx.op.unary.f32(i32 23, float %4001)  ; Log(value)
  %4005 = fmul fast float %4002, 0x3FDAAAAAA0000000
  %4006 = fmul fast float %4003, 0x3FDAAAAAA0000000
  %4007 = fmul fast float %4004, 0x3FDAAAAAA0000000
  %4008 = call float @dx.op.unary.f32(i32 21, float %4005)  ; Exp(value)
  %4009 = call float @dx.op.unary.f32(i32 21, float %4006)  ; Exp(value)
  %4010 = call float @dx.op.unary.f32(i32 21, float %4007)  ; Exp(value)
  %4011 = fmul fast float %4008, 0x3FF0E147A0000000
  %4012 = fmul fast float %4009, 0x3FF0E147A0000000
  %4013 = fmul fast float %4010, 0x3FF0E147A0000000
  %4014 = fadd fast float %4011, 0xBFAC28F5C0000000
  %4015 = fadd fast float %4012, 0xBFAC28F5C0000000
  %4016 = fadd fast float %4013, 0xBFAC28F5C0000000
  %4017 = fsub fast float %3996, %4014
  %4018 = fsub fast float %3997, %4015
  %4019 = fsub fast float %3998, %4016
  %4020 = fmul fast float %4017, %3993
  %4021 = fmul fast float %4018, %3994
  %4022 = fmul fast float %4019, %3995
  %4023 = fadd fast float %4020, %4014
  %4024 = fadd fast float %4021, %4015
  %4025 = fadd fast float %4022, %4016
  br label %4026

; <label>:4026                                    ; preds = %3986, %2771
  %4027 = phi float [ %2766, %2771 ], [ %4023, %3986 ]
  %4028 = phi float [ %2767, %2771 ], [ %4024, %3986 ]
  %4029 = phi float [ %2768, %2771 ], [ %4025, %3986 ]
  %4030 = phi float [ %2772, %2771 ], [ %2769, %3986 ]
  %4031 = fcmp fast ogt float %4027, 0x3FA4B5DCC0000000
  %4032 = fcmp fast ogt float %4028, 0x3FA4B5DCC0000000
  %4033 = fcmp fast ogt float %4029, 0x3FA4B5DCC0000000
  %4034 = select i1 %4031, float 0.000000e+00, float 1.000000e+00
  %4035 = select i1 %4032, float 0.000000e+00, float 1.000000e+00
  %4036 = select i1 %4033, float 0.000000e+00, float 1.000000e+00
  %4037 = fmul fast float %4027, 0x3FB3D07220000000
  %4038 = fmul fast float %4028, 0x3FB3D07220000000
  %4039 = fmul fast float %4029, 0x3FB3D07220000000
  %4040 = fadd fast float %4027, 0x3FAC28F5C0000000
  %4041 = fadd fast float %4028, 0x3FAC28F5C0000000
  %4042 = fadd fast float %4029, 0x3FAC28F5C0000000
  %4043 = fmul fast float %4040, 0x3FEE54EDE0000000
  %4044 = fmul fast float %4041, 0x3FEE54EDE0000000
  %4045 = fmul fast float %4042, 0x3FEE54EDE0000000
  %4046 = call float @dx.op.unary.f32(i32 23, float %4043)  ; Log(value)
  %4047 = call float @dx.op.unary.f32(i32 23, float %4044)  ; Log(value)
  %4048 = call float @dx.op.unary.f32(i32 23, float %4045)  ; Log(value)
  %4049 = fmul fast float %4046, 0x4003333340000000
  %4050 = fmul fast float %4047, 0x4003333340000000
  %4051 = fmul fast float %4048, 0x4003333340000000
  %4052 = call float @dx.op.unary.f32(i32 21, float %4049)  ; Exp(value)
  %4053 = call float @dx.op.unary.f32(i32 21, float %4050)  ; Exp(value)
  %4054 = call float @dx.op.unary.f32(i32 21, float %4051)  ; Exp(value)
  %4055 = fsub fast float %4037, %4052
  %4056 = fsub fast float %4038, %4053
  %4057 = fsub fast float %4039, %4054
  %4058 = fmul fast float %4055, %4034
  %4059 = fmul fast float %4056, %4035
  %4060 = fmul fast float %4057, %4036
  %4061 = fadd fast float %4058, %4052
  %4062 = fadd fast float %4059, %4053
  %4063 = fadd fast float %4060, %4054
  %4064 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %68, i32 %71, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4065 = extractvalue %dx.types.ResRet.f32 %4064, 0
  %4066 = extractvalue %dx.types.ResRet.f32 %4064, 1
  %4067 = extractvalue %dx.types.ResRet.f32 %4064, 2
  %4068 = extractvalue %dx.types.ResRet.f32 %4064, 3
  %4069 = fcmp fast olt float %4068, 0.000000e+00
  br i1 %4069, label %4070, label %4072

; <label>:4070                                    ; preds = %4026
  %4071 = fsub fast float -1.000000e+00, %4068
  br label %5325

; <label>:4072                                    ; preds = %4026
  %4073 = fcmp fast ogt float %39, 5.000000e-01
  %4074 = fcmp fast olt float %89, 1.000000e+00
  %4075 = and i1 %4073, %4074
  br i1 %4075, label %4076, label %4162

; <label>:4076                                    ; preds = %4072
  %4077 = sitofp i32 %68 to float
  %4078 = sitofp i32 %71 to float
  %4079 = fadd fast float %4077, 5.000000e-01
  %4080 = fadd fast float %4078, 5.000000e-01
  %4081 = fdiv fast float %4079, %46
  %4082 = fdiv fast float %4080, %47
  %4083 = fmul fast float %4081, 2.000000e+00
  %4084 = fmul fast float %4082, 2.000000e+00
  %4085 = fadd fast float %4083, -1.000000e+00
  %4086 = fsub fast float 1.000000e+00, %4084
  %4087 = fmul fast float %4085, %36
  %4088 = call float @dx.op.tertiary.f32(i32 46, float %4086, float %32, float %4087)  ; FMad(a,b,c)
  %4089 = call float @dx.op.tertiary.f32(i32 46, float %89, float %28, float %4088)  ; FMad(a,b,c)
  %4090 = fadd fast float %4089, %24
  %4091 = call float @dx.op.unary.f32(i32 6, float %4090)  ; FAbs(value)
  %4092 = fcmp fast ogt float %4091, 0x3EB0C6F7A0000000
  br i1 %4092, label %4093, label %4162

; <label>:4093                                    ; preds = %4076
  %4094 = fmul fast float %4085, %35
  %4095 = call float @dx.op.tertiary.f32(i32 46, float %4086, float %31, float %4094)  ; FMad(a,b,c)
  %4096 = call float @dx.op.tertiary.f32(i32 46, float %89, float %27, float %4095)  ; FMad(a,b,c)
  %4097 = fadd fast float %4096, %23
  %4098 = fmul fast float %4085, %34
  %4099 = call float @dx.op.tertiary.f32(i32 46, float %4086, float %30, float %4098)  ; FMad(a,b,c)
  %4100 = call float @dx.op.tertiary.f32(i32 46, float %89, float %26, float %4099)  ; FMad(a,b,c)
  %4101 = fadd fast float %4100, %22
  %4102 = fmul fast float %4085, %33
  %4103 = call float @dx.op.tertiary.f32(i32 46, float %4086, float %29, float %4102)  ; FMad(a,b,c)
  %4104 = call float @dx.op.tertiary.f32(i32 46, float %89, float %25, float %4103)  ; FMad(a,b,c)
  %4105 = fadd fast float %4104, %21
  %4106 = fdiv fast float %4105, %4090
  %4107 = fdiv fast float %4101, %4090
  %4108 = fdiv fast float %4097, %4090
  %4109 = fsub fast float %4106, %18
  %4110 = fsub fast float %4107, %19
  %4111 = fsub fast float %4108, %20
  %4112 = fmul fast float %4109, %4109
  %4113 = fmul fast float %4110, %4110
  %4114 = fadd fast float %4113, %4112
  %4115 = fmul fast float %4111, %4111
  %4116 = fadd fast float %4114, %4115
  %4117 = call float @dx.op.unary.f32(i32 24, float %4116)  ; Sqrt(value)
  %4118 = fsub fast float %4117, %10
  %4119 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4118)  ; FMax(a,b)
  %4120 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %4120, label %4121, label %4144

; <label>:4121                                    ; preds = %4093
  %4122 = call float @dx.op.unary.f32(i32 6, float %4110)  ; FAbs(value)
  %4123 = fmul fast float %4122, %12
  %4124 = fcmp fast olt float %4123, 0x3F50624DE0000000
  br i1 %4124, label %4125, label %4128

; <label>:4125                                    ; preds = %4121
  %4126 = fmul fast float %4123, 5.000000e-01
  %4127 = fsub fast float 1.000000e+00, %4126
  br label %4133

; <label>:4128                                    ; preds = %4121
  %4129 = fmul fast float %4123, 0xBFF7154760000000
  %4130 = call float @dx.op.unary.f32(i32 21, float %4129)  ; Exp(value)
  %4131 = fsub fast float 1.000000e+00, %4130
  %4132 = fdiv fast float %4131, %4123
  br label %4133

; <label>:4133                                    ; preds = %4128, %4125
  %4134 = phi float [ %4127, %4125 ], [ %4132, %4128 ]
  %4135 = call float @dx.op.binary.f32(i32 36, float %4107, float %19)  ; FMin(a,b)
  %4136 = fsub fast float %4135, %11
  %4137 = fmul fast float %12, %4136
  %4138 = fsub fast float -0.000000e+00, %4137
  %4139 = call float @dx.op.binary.f32(i32 35, float %4138, float -4.000000e+01)  ; FMax(a,b)
  %4140 = call float @dx.op.binary.f32(i32 36, float %4139, float 5.000000e+00)  ; FMin(a,b)
  %4141 = fmul fast float %4140, 0x3FF7154760000000
  %4142 = call float @dx.op.unary.f32(i32 21, float %4141)  ; Exp(value)
  %4143 = fmul fast float %4142, %4134
  br label %4144

; <label>:4144                                    ; preds = %4133, %4093
  %4145 = phi float [ %4143, %4133 ], [ 1.000000e+00, %4093 ]
  %4146 = fmul fast float %4119, %17
  %4147 = fmul fast float %4146, %4145
  %4148 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4147)  ; FMin(a,b)
  %4149 = fmul fast float %4148, 0xBFF7154760000000
  %4150 = call float @dx.op.unary.f32(i32 21, float %4149)  ; Exp(value)
  %4151 = fsub fast float 1.000000e+00, %4150
  %4152 = call float @dx.op.binary.f32(i32 36, float %13, float %4151)  ; FMin(a,b)
  %4153 = fsub fast float %14, %4065
  %4154 = fsub fast float %15, %4066
  %4155 = fsub fast float %16, %4067
  %4156 = fmul fast float %4152, %4153
  %4157 = fmul fast float %4152, %4154
  %4158 = fmul fast float %4152, %4155
  %4159 = fadd fast float %4156, %4065
  %4160 = fadd fast float %4157, %4066
  %4161 = fadd fast float %4158, %4067
  br label %4162

; <label>:4162                                    ; preds = %4144, %4076, %4072
  %4163 = phi float [ %4159, %4144 ], [ %4065, %4076 ], [ %4065, %4072 ]
  %4164 = phi float [ %4160, %4144 ], [ %4066, %4076 ], [ %4066, %4072 ]
  %4165 = phi float [ %4161, %4144 ], [ %4067, %4076 ], [ %4067, %4072 ]
  %4166 = fadd fast float %6, 1.000000e+00
  %4167 = fadd fast float %7, 1.000000e+00
  %4168 = fsub fast float 1.000000e+00, %6
  %4169 = fmul fast float %37, %4166
  %4170 = fmul fast float %37, %4167
  %4171 = fmul fast float %37, %4168
  %4172 = fmul fast float %4169, %4163
  %4173 = fmul fast float %4170, %4164
  %4174 = fmul fast float %4171, %4165
  %4175 = fcmp fast ult float %38, 5.000000e-01
  br i1 %4175, label %4201, label %4176

; <label>:4176                                    ; preds = %4162
  %4177 = fmul fast float %4172, 0x4004147AE0000000
  %4178 = fmul fast float %4173, 0x4004147AE0000000
  %4179 = fmul fast float %4174, 0x4004147AE0000000
  %4180 = fadd fast float %4177, 0x3F9EB851E0000000
  %4181 = fadd fast float %4178, 0x3F9EB851E0000000
  %4182 = fadd fast float %4179, 0x3F9EB851E0000000
  %4183 = fmul fast float %4180, %4172
  %4184 = fmul fast float %4181, %4173
  %4185 = fmul fast float %4182, %4174
  %4186 = fmul fast float %4172, 0x400370A3E0000000
  %4187 = fmul fast float %4173, 0x400370A3E0000000
  %4188 = fmul fast float %4174, 0x400370A3E0000000
  %4189 = fadd fast float %4186, 0x3FE2E147A0000000
  %4190 = fadd fast float %4187, 0x3FE2E147A0000000
  %4191 = fadd fast float %4188, 0x3FE2E147A0000000
  %4192 = fmul fast float %4189, %4172
  %4193 = fmul fast float %4190, %4173
  %4194 = fmul fast float %4191, %4174
  %4195 = fadd fast float %4192, 0x3FC1EB8520000000
  %4196 = fadd fast float %4193, 0x3FC1EB8520000000
  %4197 = fadd fast float %4194, 0x3FC1EB8520000000
  %4198 = fdiv fast float %4183, %4195
  %4199 = fdiv fast float %4184, %4196
  %4200 = fdiv fast float %4185, %4197
  br label %4201

; <label>:4201                                    ; preds = %4176, %4162
  %4202 = phi float [ %4198, %4176 ], [ %4172, %4162 ]
  %4203 = phi float [ %4199, %4176 ], [ %4173, %4162 ]
  %4204 = phi float [ %4200, %4176 ], [ %4174, %4162 ]
  %4205 = call float @dx.op.unary.f32(i32 7, float %4202)  ; Saturate(value)
  %4206 = call float @dx.op.unary.f32(i32 7, float %4203)  ; Saturate(value)
  %4207 = call float @dx.op.unary.f32(i32 7, float %4204)  ; Saturate(value)
  %4208 = call float @dx.op.dot3.f32(i32 55, float %4205, float %4206, float %4207, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4209 = fsub fast float %4205, %4208
  %4210 = fsub fast float %4206, %4208
  %4211 = fsub fast float %4207, %4208
  %4212 = fmul fast float %4209, %9
  %4213 = fmul fast float %4210, %9
  %4214 = fmul fast float %4211, %9
  %4215 = fadd fast float %4212, %4208
  %4216 = fadd fast float %4213, %4208
  %4217 = fadd fast float %4214, %4208
  %4218 = call float @dx.op.unary.f32(i32 7, float %4215)  ; Saturate(value)
  %4219 = call float @dx.op.unary.f32(i32 7, float %4216)  ; Saturate(value)
  %4220 = call float @dx.op.unary.f32(i32 7, float %4217)  ; Saturate(value)
  %4221 = fadd fast float %4218, 0xBFC70A3D80000000
  %4222 = fadd fast float %4219, 0xBFC70A3D80000000
  %4223 = fadd fast float %4220, 0xBFC70A3D80000000
  %4224 = fmul fast float %4221, %8
  %4225 = fmul fast float %4222, %8
  %4226 = fmul fast float %4223, %8
  %4227 = fadd fast float %4224, 0x3FC70A3D80000000
  %4228 = fadd fast float %4225, 0x3FC70A3D80000000
  %4229 = fadd fast float %4226, 0x3FC70A3D80000000
  %4230 = call float @dx.op.unary.f32(i32 7, float %4227)  ; Saturate(value)
  %4231 = call float @dx.op.unary.f32(i32 7, float %4228)  ; Saturate(value)
  %4232 = call float @dx.op.unary.f32(i32 7, float %4229)  ; Saturate(value)
  %4233 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %4233, label %4234, label %5285

; <label>:4234                                    ; preds = %4201
  %4235 = add i32 %71, -1
  %4236 = call i32 @dx.op.binary.i32(i32 37, i32 %68, i32 0)  ; IMax(a,b)
  %4237 = call i32 @dx.op.binary.i32(i32 37, i32 %4235, i32 0)  ; IMax(a,b)
  %4238 = call i32 @dx.op.binary.i32(i32 38, i32 %4236, i32 %60)  ; IMin(a,b)
  %4239 = call i32 @dx.op.binary.i32(i32 38, i32 %4237, i32 %61)  ; IMin(a,b)
  %4240 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4238, i32 %4239, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4241 = extractvalue %dx.types.ResRet.f32 %4240, 0
  %4242 = fsub fast float 1.000000e+00, %89
  %4243 = fmul fast float %4242, 0x3FA99999A0000000
  %4244 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %4243)  ; FMax(a,b)
  %4245 = fsub fast float %4241, %89
  %4246 = call float @dx.op.unary.f32(i32 6, float %4245)  ; FAbs(value)
  %4247 = fdiv fast float %4246, %4244
  %4248 = fsub fast float 1.000000e+00, %4247
  %4249 = call float @dx.op.unary.f32(i32 7, float %4248)  ; Saturate(value)
  %4250 = fcmp fast ugt float %4249, 0.000000e+00
  br i1 %4250, label %4251, label %4472

; <label>:4251                                    ; preds = %4234
  %4252 = call i32 @dx.op.binary.i32(i32 37, i32 %4238, i32 0)  ; IMax(a,b)
  %4253 = call i32 @dx.op.binary.i32(i32 37, i32 %4239, i32 0)  ; IMax(a,b)
  %4254 = call i32 @dx.op.binary.i32(i32 38, i32 %4252, i32 %60)  ; IMin(a,b)
  %4255 = call i32 @dx.op.binary.i32(i32 38, i32 %4253, i32 %61)  ; IMin(a,b)
  %4256 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4254, i32 %4255, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4257 = extractvalue %dx.types.ResRet.f32 %4256, 0
  %4258 = extractvalue %dx.types.ResRet.f32 %4256, 1
  %4259 = extractvalue %dx.types.ResRet.f32 %4256, 2
  %4260 = extractvalue %dx.types.ResRet.f32 %4256, 3
  %4261 = fcmp fast olt float %4260, 0.000000e+00
  br i1 %4261, label %4262, label %4296

; <label>:4262                                    ; preds = %4251
  %4263 = fcmp fast ogt float %4257, 0x3FA4B5DCC0000000
  %4264 = fcmp fast ogt float %4258, 0x3FA4B5DCC0000000
  %4265 = fcmp fast ogt float %4259, 0x3FA4B5DCC0000000
  %4266 = select i1 %4263, float 0.000000e+00, float 1.000000e+00
  %4267 = select i1 %4264, float 0.000000e+00, float 1.000000e+00
  %4268 = select i1 %4265, float 0.000000e+00, float 1.000000e+00
  %4269 = fmul fast float %4257, 0x3FB3D07220000000
  %4270 = fmul fast float %4258, 0x3FB3D07220000000
  %4271 = fmul fast float %4259, 0x3FB3D07220000000
  %4272 = fadd fast float %4257, 0x3FAC28F5C0000000
  %4273 = fadd fast float %4258, 0x3FAC28F5C0000000
  %4274 = fadd fast float %4259, 0x3FAC28F5C0000000
  %4275 = fmul fast float %4272, 0x3FEE54EDE0000000
  %4276 = fmul fast float %4273, 0x3FEE54EDE0000000
  %4277 = fmul fast float %4274, 0x3FEE54EDE0000000
  %4278 = call float @dx.op.unary.f32(i32 23, float %4275)  ; Log(value)
  %4279 = call float @dx.op.unary.f32(i32 23, float %4276)  ; Log(value)
  %4280 = call float @dx.op.unary.f32(i32 23, float %4277)  ; Log(value)
  %4281 = fmul fast float %4278, 0x4003333340000000
  %4282 = fmul fast float %4279, 0x4003333340000000
  %4283 = fmul fast float %4280, 0x4003333340000000
  %4284 = call float @dx.op.unary.f32(i32 21, float %4281)  ; Exp(value)
  %4285 = call float @dx.op.unary.f32(i32 21, float %4282)  ; Exp(value)
  %4286 = call float @dx.op.unary.f32(i32 21, float %4283)  ; Exp(value)
  %4287 = fsub fast float %4269, %4284
  %4288 = fsub fast float %4270, %4285
  %4289 = fsub fast float %4271, %4286
  %4290 = fmul fast float %4287, %4266
  %4291 = fmul fast float %4288, %4267
  %4292 = fmul fast float %4289, %4268
  %4293 = fadd fast float %4290, %4284
  %4294 = fadd fast float %4291, %4285
  %4295 = fadd fast float %4292, %4286
  br label %4459

; <label>:4296                                    ; preds = %4251
  %4297 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4254, i32 %4255, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4298 = extractvalue %dx.types.ResRet.f32 %4297, 0
  %4299 = fcmp fast ogt float %39, 5.000000e-01
  %4300 = fcmp fast olt float %4298, 1.000000e+00
  %4301 = and i1 %4299, %4300
  br i1 %4301, label %4302, label %4388

; <label>:4302                                    ; preds = %4296
  %4303 = sitofp i32 %4254 to float
  %4304 = sitofp i32 %4255 to float
  %4305 = fadd fast float %4303, 5.000000e-01
  %4306 = fadd fast float %4304, 5.000000e-01
  %4307 = fdiv fast float %4305, %46
  %4308 = fdiv fast float %4306, %47
  %4309 = fmul fast float %4307, 2.000000e+00
  %4310 = fmul fast float %4308, 2.000000e+00
  %4311 = fadd fast float %4309, -1.000000e+00
  %4312 = fsub fast float 1.000000e+00, %4310
  %4313 = fmul fast float %4311, %36
  %4314 = call float @dx.op.tertiary.f32(i32 46, float %4312, float %32, float %4313)  ; FMad(a,b,c)
  %4315 = call float @dx.op.tertiary.f32(i32 46, float %4298, float %28, float %4314)  ; FMad(a,b,c)
  %4316 = fadd fast float %4315, %24
  %4317 = call float @dx.op.unary.f32(i32 6, float %4316)  ; FAbs(value)
  %4318 = fcmp fast ogt float %4317, 0x3EB0C6F7A0000000
  br i1 %4318, label %4319, label %4388

; <label>:4319                                    ; preds = %4302
  %4320 = fmul fast float %4311, %35
  %4321 = call float @dx.op.tertiary.f32(i32 46, float %4312, float %31, float %4320)  ; FMad(a,b,c)
  %4322 = call float @dx.op.tertiary.f32(i32 46, float %4298, float %27, float %4321)  ; FMad(a,b,c)
  %4323 = fadd fast float %4322, %23
  %4324 = fmul fast float %4311, %34
  %4325 = call float @dx.op.tertiary.f32(i32 46, float %4312, float %30, float %4324)  ; FMad(a,b,c)
  %4326 = call float @dx.op.tertiary.f32(i32 46, float %4298, float %26, float %4325)  ; FMad(a,b,c)
  %4327 = fadd fast float %4326, %22
  %4328 = fmul fast float %4311, %33
  %4329 = call float @dx.op.tertiary.f32(i32 46, float %4312, float %29, float %4328)  ; FMad(a,b,c)
  %4330 = call float @dx.op.tertiary.f32(i32 46, float %4298, float %25, float %4329)  ; FMad(a,b,c)
  %4331 = fadd fast float %4330, %21
  %4332 = fdiv fast float %4331, %4316
  %4333 = fdiv fast float %4327, %4316
  %4334 = fdiv fast float %4323, %4316
  %4335 = fsub fast float %4332, %18
  %4336 = fsub fast float %4333, %19
  %4337 = fsub fast float %4334, %20
  %4338 = fmul fast float %4335, %4335
  %4339 = fmul fast float %4336, %4336
  %4340 = fadd fast float %4339, %4338
  %4341 = fmul fast float %4337, %4337
  %4342 = fadd fast float %4340, %4341
  %4343 = call float @dx.op.unary.f32(i32 24, float %4342)  ; Sqrt(value)
  %4344 = fsub fast float %4343, %10
  %4345 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4344)  ; FMax(a,b)
  %4346 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %4346, label %4347, label %4370

; <label>:4347                                    ; preds = %4319
  %4348 = call float @dx.op.unary.f32(i32 6, float %4336)  ; FAbs(value)
  %4349 = fmul fast float %4348, %12
  %4350 = fcmp fast olt float %4349, 0x3F50624DE0000000
  br i1 %4350, label %4351, label %4354

; <label>:4351                                    ; preds = %4347
  %4352 = fmul fast float %4349, 5.000000e-01
  %4353 = fsub fast float 1.000000e+00, %4352
  br label %4359

; <label>:4354                                    ; preds = %4347
  %4355 = fmul fast float %4349, 0xBFF7154760000000
  %4356 = call float @dx.op.unary.f32(i32 21, float %4355)  ; Exp(value)
  %4357 = fsub fast float 1.000000e+00, %4356
  %4358 = fdiv fast float %4357, %4349
  br label %4359

; <label>:4359                                    ; preds = %4354, %4351
  %4360 = phi float [ %4353, %4351 ], [ %4358, %4354 ]
  %4361 = call float @dx.op.binary.f32(i32 36, float %4333, float %19)  ; FMin(a,b)
  %4362 = fsub fast float %4361, %11
  %4363 = fmul fast float %12, %4362
  %4364 = fsub fast float -0.000000e+00, %4363
  %4365 = call float @dx.op.binary.f32(i32 35, float %4364, float -4.000000e+01)  ; FMax(a,b)
  %4366 = call float @dx.op.binary.f32(i32 36, float %4365, float 5.000000e+00)  ; FMin(a,b)
  %4367 = fmul fast float %4366, 0x3FF7154760000000
  %4368 = call float @dx.op.unary.f32(i32 21, float %4367)  ; Exp(value)
  %4369 = fmul fast float %4368, %4360
  br label %4370

; <label>:4370                                    ; preds = %4359, %4319
  %4371 = phi float [ %4369, %4359 ], [ 1.000000e+00, %4319 ]
  %4372 = fmul fast float %4345, %17
  %4373 = fmul fast float %4372, %4371
  %4374 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4373)  ; FMin(a,b)
  %4375 = fmul fast float %4374, 0xBFF7154760000000
  %4376 = call float @dx.op.unary.f32(i32 21, float %4375)  ; Exp(value)
  %4377 = fsub fast float 1.000000e+00, %4376
  %4378 = call float @dx.op.binary.f32(i32 36, float %13, float %4377)  ; FMin(a,b)
  %4379 = fsub fast float %14, %4257
  %4380 = fsub fast float %15, %4258
  %4381 = fsub fast float %16, %4259
  %4382 = fmul fast float %4378, %4379
  %4383 = fmul fast float %4378, %4380
  %4384 = fmul fast float %4378, %4381
  %4385 = fadd fast float %4382, %4257
  %4386 = fadd fast float %4383, %4258
  %4387 = fadd fast float %4384, %4259
  br label %4388

; <label>:4388                                    ; preds = %4370, %4302, %4296
  %4389 = phi float [ %4385, %4370 ], [ %4257, %4302 ], [ %4257, %4296 ]
  %4390 = phi float [ %4386, %4370 ], [ %4258, %4302 ], [ %4258, %4296 ]
  %4391 = phi float [ %4387, %4370 ], [ %4259, %4302 ], [ %4259, %4296 ]
  %4392 = fadd fast float %6, 1.000000e+00
  %4393 = fadd fast float %7, 1.000000e+00
  %4394 = fsub fast float 1.000000e+00, %6
  %4395 = fmul fast float %37, %4392
  %4396 = fmul fast float %37, %4393
  %4397 = fmul fast float %37, %4394
  %4398 = fmul fast float %4395, %4389
  %4399 = fmul fast float %4396, %4390
  %4400 = fmul fast float %4397, %4391
  %4401 = fcmp fast ult float %38, 5.000000e-01
  br i1 %4401, label %4427, label %4402

; <label>:4402                                    ; preds = %4388
  %4403 = fmul fast float %4398, 0x4004147AE0000000
  %4404 = fmul fast float %4399, 0x4004147AE0000000
  %4405 = fmul fast float %4400, 0x4004147AE0000000
  %4406 = fadd fast float %4403, 0x3F9EB851E0000000
  %4407 = fadd fast float %4404, 0x3F9EB851E0000000
  %4408 = fadd fast float %4405, 0x3F9EB851E0000000
  %4409 = fmul fast float %4406, %4398
  %4410 = fmul fast float %4407, %4399
  %4411 = fmul fast float %4408, %4400
  %4412 = fmul fast float %4398, 0x400370A3E0000000
  %4413 = fmul fast float %4399, 0x400370A3E0000000
  %4414 = fmul fast float %4400, 0x400370A3E0000000
  %4415 = fadd fast float %4412, 0x3FE2E147A0000000
  %4416 = fadd fast float %4413, 0x3FE2E147A0000000
  %4417 = fadd fast float %4414, 0x3FE2E147A0000000
  %4418 = fmul fast float %4415, %4398
  %4419 = fmul fast float %4416, %4399
  %4420 = fmul fast float %4417, %4400
  %4421 = fadd fast float %4418, 0x3FC1EB8520000000
  %4422 = fadd fast float %4419, 0x3FC1EB8520000000
  %4423 = fadd fast float %4420, 0x3FC1EB8520000000
  %4424 = fdiv fast float %4409, %4421
  %4425 = fdiv fast float %4410, %4422
  %4426 = fdiv fast float %4411, %4423
  br label %4427

; <label>:4427                                    ; preds = %4402, %4388
  %4428 = phi float [ %4424, %4402 ], [ %4398, %4388 ]
  %4429 = phi float [ %4425, %4402 ], [ %4399, %4388 ]
  %4430 = phi float [ %4426, %4402 ], [ %4400, %4388 ]
  %4431 = call float @dx.op.unary.f32(i32 7, float %4428)  ; Saturate(value)
  %4432 = call float @dx.op.unary.f32(i32 7, float %4429)  ; Saturate(value)
  %4433 = call float @dx.op.unary.f32(i32 7, float %4430)  ; Saturate(value)
  %4434 = call float @dx.op.dot3.f32(i32 55, float %4431, float %4432, float %4433, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4435 = fsub fast float %4431, %4434
  %4436 = fsub fast float %4432, %4434
  %4437 = fsub fast float %4433, %4434
  %4438 = fmul fast float %4435, %9
  %4439 = fmul fast float %4436, %9
  %4440 = fmul fast float %4437, %9
  %4441 = fadd fast float %4438, %4434
  %4442 = fadd fast float %4439, %4434
  %4443 = fadd fast float %4440, %4434
  %4444 = call float @dx.op.unary.f32(i32 7, float %4441)  ; Saturate(value)
  %4445 = call float @dx.op.unary.f32(i32 7, float %4442)  ; Saturate(value)
  %4446 = call float @dx.op.unary.f32(i32 7, float %4443)  ; Saturate(value)
  %4447 = fadd fast float %4444, 0xBFC70A3D80000000
  %4448 = fadd fast float %4445, 0xBFC70A3D80000000
  %4449 = fadd fast float %4446, 0xBFC70A3D80000000
  %4450 = fmul fast float %4447, %8
  %4451 = fmul fast float %4448, %8
  %4452 = fmul fast float %4449, %8
  %4453 = fadd fast float %4450, 0x3FC70A3D80000000
  %4454 = fadd fast float %4451, 0x3FC70A3D80000000
  %4455 = fadd fast float %4452, 0x3FC70A3D80000000
  %4456 = call float @dx.op.unary.f32(i32 7, float %4453)  ; Saturate(value)
  %4457 = call float @dx.op.unary.f32(i32 7, float %4454)  ; Saturate(value)
  %4458 = call float @dx.op.unary.f32(i32 7, float %4455)  ; Saturate(value)
  br label %4459

; <label>:4459                                    ; preds = %4427, %4262
  %4460 = phi float [ %4293, %4262 ], [ %4456, %4427 ]
  %4461 = phi float [ %4294, %4262 ], [ %4457, %4427 ]
  %4462 = phi float [ %4295, %4262 ], [ %4458, %4427 ]
  %4463 = fsub fast float %4460, %4230
  %4464 = fsub fast float %4461, %4231
  %4465 = fsub fast float %4462, %4232
  %4466 = fmul fast float %4463, %4249
  %4467 = fmul fast float %4464, %4249
  %4468 = fmul fast float %4465, %4249
  %4469 = fadd fast float %4466, %4230
  %4470 = fadd fast float %4467, %4231
  %4471 = fadd fast float %4468, %4232
  br label %4472

; <label>:4472                                    ; preds = %4459, %4234
  %4473 = phi float [ %4469, %4459 ], [ %4230, %4234 ]
  %4474 = phi float [ %4470, %4459 ], [ %4231, %4234 ]
  %4475 = phi float [ %4471, %4459 ], [ %4232, %4234 ]
  %4476 = add i32 %71, 1
  %4477 = call i32 @dx.op.binary.i32(i32 37, i32 %4476, i32 0)  ; IMax(a,b)
  %4478 = call i32 @dx.op.binary.i32(i32 38, i32 %4477, i32 %61)  ; IMin(a,b)
  %4479 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4238, i32 %4478, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4480 = extractvalue %dx.types.ResRet.f32 %4479, 0
  %4481 = fsub fast float %4480, %89
  %4482 = call float @dx.op.unary.f32(i32 6, float %4481)  ; FAbs(value)
  %4483 = fdiv fast float %4482, %4244
  %4484 = fsub fast float 1.000000e+00, %4483
  %4485 = call float @dx.op.unary.f32(i32 7, float %4484)  ; Saturate(value)
  %4486 = fcmp fast ugt float %4485, 0.000000e+00
  br i1 %4486, label %4487, label %4708

; <label>:4487                                    ; preds = %4472
  %4488 = call i32 @dx.op.binary.i32(i32 37, i32 %4238, i32 0)  ; IMax(a,b)
  %4489 = call i32 @dx.op.binary.i32(i32 37, i32 %4478, i32 0)  ; IMax(a,b)
  %4490 = call i32 @dx.op.binary.i32(i32 38, i32 %4488, i32 %60)  ; IMin(a,b)
  %4491 = call i32 @dx.op.binary.i32(i32 38, i32 %4489, i32 %61)  ; IMin(a,b)
  %4492 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4490, i32 %4491, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4493 = extractvalue %dx.types.ResRet.f32 %4492, 0
  %4494 = extractvalue %dx.types.ResRet.f32 %4492, 1
  %4495 = extractvalue %dx.types.ResRet.f32 %4492, 2
  %4496 = extractvalue %dx.types.ResRet.f32 %4492, 3
  %4497 = fcmp fast olt float %4496, 0.000000e+00
  br i1 %4497, label %4498, label %4532

; <label>:4498                                    ; preds = %4487
  %4499 = fcmp fast ogt float %4493, 0x3FA4B5DCC0000000
  %4500 = fcmp fast ogt float %4494, 0x3FA4B5DCC0000000
  %4501 = fcmp fast ogt float %4495, 0x3FA4B5DCC0000000
  %4502 = select i1 %4499, float 0.000000e+00, float 1.000000e+00
  %4503 = select i1 %4500, float 0.000000e+00, float 1.000000e+00
  %4504 = select i1 %4501, float 0.000000e+00, float 1.000000e+00
  %4505 = fmul fast float %4493, 0x3FB3D07220000000
  %4506 = fmul fast float %4494, 0x3FB3D07220000000
  %4507 = fmul fast float %4495, 0x3FB3D07220000000
  %4508 = fadd fast float %4493, 0x3FAC28F5C0000000
  %4509 = fadd fast float %4494, 0x3FAC28F5C0000000
  %4510 = fadd fast float %4495, 0x3FAC28F5C0000000
  %4511 = fmul fast float %4508, 0x3FEE54EDE0000000
  %4512 = fmul fast float %4509, 0x3FEE54EDE0000000
  %4513 = fmul fast float %4510, 0x3FEE54EDE0000000
  %4514 = call float @dx.op.unary.f32(i32 23, float %4511)  ; Log(value)
  %4515 = call float @dx.op.unary.f32(i32 23, float %4512)  ; Log(value)
  %4516 = call float @dx.op.unary.f32(i32 23, float %4513)  ; Log(value)
  %4517 = fmul fast float %4514, 0x4003333340000000
  %4518 = fmul fast float %4515, 0x4003333340000000
  %4519 = fmul fast float %4516, 0x4003333340000000
  %4520 = call float @dx.op.unary.f32(i32 21, float %4517)  ; Exp(value)
  %4521 = call float @dx.op.unary.f32(i32 21, float %4518)  ; Exp(value)
  %4522 = call float @dx.op.unary.f32(i32 21, float %4519)  ; Exp(value)
  %4523 = fsub fast float %4505, %4520
  %4524 = fsub fast float %4506, %4521
  %4525 = fsub fast float %4507, %4522
  %4526 = fmul fast float %4523, %4502
  %4527 = fmul fast float %4524, %4503
  %4528 = fmul fast float %4525, %4504
  %4529 = fadd fast float %4526, %4520
  %4530 = fadd fast float %4527, %4521
  %4531 = fadd fast float %4528, %4522
  br label %4695

; <label>:4532                                    ; preds = %4487
  %4533 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4490, i32 %4491, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4534 = extractvalue %dx.types.ResRet.f32 %4533, 0
  %4535 = fcmp fast ogt float %39, 5.000000e-01
  %4536 = fcmp fast olt float %4534, 1.000000e+00
  %4537 = and i1 %4535, %4536
  br i1 %4537, label %4538, label %4624

; <label>:4538                                    ; preds = %4532
  %4539 = sitofp i32 %4490 to float
  %4540 = sitofp i32 %4491 to float
  %4541 = fadd fast float %4539, 5.000000e-01
  %4542 = fadd fast float %4540, 5.000000e-01
  %4543 = fdiv fast float %4541, %46
  %4544 = fdiv fast float %4542, %47
  %4545 = fmul fast float %4543, 2.000000e+00
  %4546 = fmul fast float %4544, 2.000000e+00
  %4547 = fadd fast float %4545, -1.000000e+00
  %4548 = fsub fast float 1.000000e+00, %4546
  %4549 = fmul fast float %4547, %36
  %4550 = call float @dx.op.tertiary.f32(i32 46, float %4548, float %32, float %4549)  ; FMad(a,b,c)
  %4551 = call float @dx.op.tertiary.f32(i32 46, float %4534, float %28, float %4550)  ; FMad(a,b,c)
  %4552 = fadd fast float %4551, %24
  %4553 = call float @dx.op.unary.f32(i32 6, float %4552)  ; FAbs(value)
  %4554 = fcmp fast ogt float %4553, 0x3EB0C6F7A0000000
  br i1 %4554, label %4555, label %4624

; <label>:4555                                    ; preds = %4538
  %4556 = fmul fast float %4547, %35
  %4557 = call float @dx.op.tertiary.f32(i32 46, float %4548, float %31, float %4556)  ; FMad(a,b,c)
  %4558 = call float @dx.op.tertiary.f32(i32 46, float %4534, float %27, float %4557)  ; FMad(a,b,c)
  %4559 = fadd fast float %4558, %23
  %4560 = fmul fast float %4547, %34
  %4561 = call float @dx.op.tertiary.f32(i32 46, float %4548, float %30, float %4560)  ; FMad(a,b,c)
  %4562 = call float @dx.op.tertiary.f32(i32 46, float %4534, float %26, float %4561)  ; FMad(a,b,c)
  %4563 = fadd fast float %4562, %22
  %4564 = fmul fast float %4547, %33
  %4565 = call float @dx.op.tertiary.f32(i32 46, float %4548, float %29, float %4564)  ; FMad(a,b,c)
  %4566 = call float @dx.op.tertiary.f32(i32 46, float %4534, float %25, float %4565)  ; FMad(a,b,c)
  %4567 = fadd fast float %4566, %21
  %4568 = fdiv fast float %4567, %4552
  %4569 = fdiv fast float %4563, %4552
  %4570 = fdiv fast float %4559, %4552
  %4571 = fsub fast float %4568, %18
  %4572 = fsub fast float %4569, %19
  %4573 = fsub fast float %4570, %20
  %4574 = fmul fast float %4571, %4571
  %4575 = fmul fast float %4572, %4572
  %4576 = fadd fast float %4575, %4574
  %4577 = fmul fast float %4573, %4573
  %4578 = fadd fast float %4576, %4577
  %4579 = call float @dx.op.unary.f32(i32 24, float %4578)  ; Sqrt(value)
  %4580 = fsub fast float %4579, %10
  %4581 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4580)  ; FMax(a,b)
  %4582 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %4582, label %4583, label %4606

; <label>:4583                                    ; preds = %4555
  %4584 = call float @dx.op.unary.f32(i32 6, float %4572)  ; FAbs(value)
  %4585 = fmul fast float %4584, %12
  %4586 = fcmp fast olt float %4585, 0x3F50624DE0000000
  br i1 %4586, label %4587, label %4590

; <label>:4587                                    ; preds = %4583
  %4588 = fmul fast float %4585, 5.000000e-01
  %4589 = fsub fast float 1.000000e+00, %4588
  br label %4595

; <label>:4590                                    ; preds = %4583
  %4591 = fmul fast float %4585, 0xBFF7154760000000
  %4592 = call float @dx.op.unary.f32(i32 21, float %4591)  ; Exp(value)
  %4593 = fsub fast float 1.000000e+00, %4592
  %4594 = fdiv fast float %4593, %4585
  br label %4595

; <label>:4595                                    ; preds = %4590, %4587
  %4596 = phi float [ %4589, %4587 ], [ %4594, %4590 ]
  %4597 = call float @dx.op.binary.f32(i32 36, float %4569, float %19)  ; FMin(a,b)
  %4598 = fsub fast float %4597, %11
  %4599 = fmul fast float %12, %4598
  %4600 = fsub fast float -0.000000e+00, %4599
  %4601 = call float @dx.op.binary.f32(i32 35, float %4600, float -4.000000e+01)  ; FMax(a,b)
  %4602 = call float @dx.op.binary.f32(i32 36, float %4601, float 5.000000e+00)  ; FMin(a,b)
  %4603 = fmul fast float %4602, 0x3FF7154760000000
  %4604 = call float @dx.op.unary.f32(i32 21, float %4603)  ; Exp(value)
  %4605 = fmul fast float %4604, %4596
  br label %4606

; <label>:4606                                    ; preds = %4595, %4555
  %4607 = phi float [ %4605, %4595 ], [ 1.000000e+00, %4555 ]
  %4608 = fmul fast float %4581, %17
  %4609 = fmul fast float %4608, %4607
  %4610 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4609)  ; FMin(a,b)
  %4611 = fmul fast float %4610, 0xBFF7154760000000
  %4612 = call float @dx.op.unary.f32(i32 21, float %4611)  ; Exp(value)
  %4613 = fsub fast float 1.000000e+00, %4612
  %4614 = call float @dx.op.binary.f32(i32 36, float %13, float %4613)  ; FMin(a,b)
  %4615 = fsub fast float %14, %4493
  %4616 = fsub fast float %15, %4494
  %4617 = fsub fast float %16, %4495
  %4618 = fmul fast float %4614, %4615
  %4619 = fmul fast float %4614, %4616
  %4620 = fmul fast float %4614, %4617
  %4621 = fadd fast float %4618, %4493
  %4622 = fadd fast float %4619, %4494
  %4623 = fadd fast float %4620, %4495
  br label %4624

; <label>:4624                                    ; preds = %4606, %4538, %4532
  %4625 = phi float [ %4621, %4606 ], [ %4493, %4538 ], [ %4493, %4532 ]
  %4626 = phi float [ %4622, %4606 ], [ %4494, %4538 ], [ %4494, %4532 ]
  %4627 = phi float [ %4623, %4606 ], [ %4495, %4538 ], [ %4495, %4532 ]
  %4628 = fadd fast float %6, 1.000000e+00
  %4629 = fadd fast float %7, 1.000000e+00
  %4630 = fsub fast float 1.000000e+00, %6
  %4631 = fmul fast float %37, %4628
  %4632 = fmul fast float %37, %4629
  %4633 = fmul fast float %37, %4630
  %4634 = fmul fast float %4631, %4625
  %4635 = fmul fast float %4632, %4626
  %4636 = fmul fast float %4633, %4627
  %4637 = fcmp fast ult float %38, 5.000000e-01
  br i1 %4637, label %4663, label %4638

; <label>:4638                                    ; preds = %4624
  %4639 = fmul fast float %4634, 0x4004147AE0000000
  %4640 = fmul fast float %4635, 0x4004147AE0000000
  %4641 = fmul fast float %4636, 0x4004147AE0000000
  %4642 = fadd fast float %4639, 0x3F9EB851E0000000
  %4643 = fadd fast float %4640, 0x3F9EB851E0000000
  %4644 = fadd fast float %4641, 0x3F9EB851E0000000
  %4645 = fmul fast float %4642, %4634
  %4646 = fmul fast float %4643, %4635
  %4647 = fmul fast float %4644, %4636
  %4648 = fmul fast float %4634, 0x400370A3E0000000
  %4649 = fmul fast float %4635, 0x400370A3E0000000
  %4650 = fmul fast float %4636, 0x400370A3E0000000
  %4651 = fadd fast float %4648, 0x3FE2E147A0000000
  %4652 = fadd fast float %4649, 0x3FE2E147A0000000
  %4653 = fadd fast float %4650, 0x3FE2E147A0000000
  %4654 = fmul fast float %4651, %4634
  %4655 = fmul fast float %4652, %4635
  %4656 = fmul fast float %4653, %4636
  %4657 = fadd fast float %4654, 0x3FC1EB8520000000
  %4658 = fadd fast float %4655, 0x3FC1EB8520000000
  %4659 = fadd fast float %4656, 0x3FC1EB8520000000
  %4660 = fdiv fast float %4645, %4657
  %4661 = fdiv fast float %4646, %4658
  %4662 = fdiv fast float %4647, %4659
  br label %4663

; <label>:4663                                    ; preds = %4638, %4624
  %4664 = phi float [ %4660, %4638 ], [ %4634, %4624 ]
  %4665 = phi float [ %4661, %4638 ], [ %4635, %4624 ]
  %4666 = phi float [ %4662, %4638 ], [ %4636, %4624 ]
  %4667 = call float @dx.op.unary.f32(i32 7, float %4664)  ; Saturate(value)
  %4668 = call float @dx.op.unary.f32(i32 7, float %4665)  ; Saturate(value)
  %4669 = call float @dx.op.unary.f32(i32 7, float %4666)  ; Saturate(value)
  %4670 = call float @dx.op.dot3.f32(i32 55, float %4667, float %4668, float %4669, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4671 = fsub fast float %4667, %4670
  %4672 = fsub fast float %4668, %4670
  %4673 = fsub fast float %4669, %4670
  %4674 = fmul fast float %4671, %9
  %4675 = fmul fast float %4672, %9
  %4676 = fmul fast float %4673, %9
  %4677 = fadd fast float %4674, %4670
  %4678 = fadd fast float %4675, %4670
  %4679 = fadd fast float %4676, %4670
  %4680 = call float @dx.op.unary.f32(i32 7, float %4677)  ; Saturate(value)
  %4681 = call float @dx.op.unary.f32(i32 7, float %4678)  ; Saturate(value)
  %4682 = call float @dx.op.unary.f32(i32 7, float %4679)  ; Saturate(value)
  %4683 = fadd fast float %4680, 0xBFC70A3D80000000
  %4684 = fadd fast float %4681, 0xBFC70A3D80000000
  %4685 = fadd fast float %4682, 0xBFC70A3D80000000
  %4686 = fmul fast float %4683, %8
  %4687 = fmul fast float %4684, %8
  %4688 = fmul fast float %4685, %8
  %4689 = fadd fast float %4686, 0x3FC70A3D80000000
  %4690 = fadd fast float %4687, 0x3FC70A3D80000000
  %4691 = fadd fast float %4688, 0x3FC70A3D80000000
  %4692 = call float @dx.op.unary.f32(i32 7, float %4689)  ; Saturate(value)
  %4693 = call float @dx.op.unary.f32(i32 7, float %4690)  ; Saturate(value)
  %4694 = call float @dx.op.unary.f32(i32 7, float %4691)  ; Saturate(value)
  br label %4695

; <label>:4695                                    ; preds = %4663, %4498
  %4696 = phi float [ %4529, %4498 ], [ %4692, %4663 ]
  %4697 = phi float [ %4530, %4498 ], [ %4693, %4663 ]
  %4698 = phi float [ %4531, %4498 ], [ %4694, %4663 ]
  %4699 = fsub fast float %4696, %4230
  %4700 = fsub fast float %4697, %4231
  %4701 = fsub fast float %4698, %4232
  %4702 = fmul fast float %4699, %4485
  %4703 = fmul fast float %4700, %4485
  %4704 = fmul fast float %4701, %4485
  %4705 = fadd fast float %4702, %4230
  %4706 = fadd fast float %4703, %4231
  %4707 = fadd fast float %4704, %4232
  br label %4708

; <label>:4708                                    ; preds = %4695, %4472
  %4709 = phi float [ %4705, %4695 ], [ %4230, %4472 ]
  %4710 = phi float [ %4706, %4695 ], [ %4231, %4472 ]
  %4711 = phi float [ %4707, %4695 ], [ %4232, %4472 ]
  %4712 = add i32 %68, -1
  %4713 = call i32 @dx.op.binary.i32(i32 37, i32 %4712, i32 0)  ; IMax(a,b)
  %4714 = call i32 @dx.op.binary.i32(i32 37, i32 %71, i32 0)  ; IMax(a,b)
  %4715 = call i32 @dx.op.binary.i32(i32 38, i32 %4713, i32 %60)  ; IMin(a,b)
  %4716 = call i32 @dx.op.binary.i32(i32 38, i32 %4714, i32 %61)  ; IMin(a,b)
  %4717 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4715, i32 %4716, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4718 = extractvalue %dx.types.ResRet.f32 %4717, 0
  %4719 = fsub fast float %4718, %89
  %4720 = call float @dx.op.unary.f32(i32 6, float %4719)  ; FAbs(value)
  %4721 = fdiv fast float %4720, %4244
  %4722 = fsub fast float 1.000000e+00, %4721
  %4723 = call float @dx.op.unary.f32(i32 7, float %4722)  ; Saturate(value)
  %4724 = fcmp fast ugt float %4723, 0.000000e+00
  br i1 %4724, label %4725, label %4946

; <label>:4725                                    ; preds = %4708
  %4726 = call i32 @dx.op.binary.i32(i32 37, i32 %4715, i32 0)  ; IMax(a,b)
  %4727 = call i32 @dx.op.binary.i32(i32 37, i32 %4716, i32 0)  ; IMax(a,b)
  %4728 = call i32 @dx.op.binary.i32(i32 38, i32 %4726, i32 %60)  ; IMin(a,b)
  %4729 = call i32 @dx.op.binary.i32(i32 38, i32 %4727, i32 %61)  ; IMin(a,b)
  %4730 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4728, i32 %4729, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4731 = extractvalue %dx.types.ResRet.f32 %4730, 0
  %4732 = extractvalue %dx.types.ResRet.f32 %4730, 1
  %4733 = extractvalue %dx.types.ResRet.f32 %4730, 2
  %4734 = extractvalue %dx.types.ResRet.f32 %4730, 3
  %4735 = fcmp fast olt float %4734, 0.000000e+00
  br i1 %4735, label %4736, label %4770

; <label>:4736                                    ; preds = %4725
  %4737 = fcmp fast ogt float %4731, 0x3FA4B5DCC0000000
  %4738 = fcmp fast ogt float %4732, 0x3FA4B5DCC0000000
  %4739 = fcmp fast ogt float %4733, 0x3FA4B5DCC0000000
  %4740 = select i1 %4737, float 0.000000e+00, float 1.000000e+00
  %4741 = select i1 %4738, float 0.000000e+00, float 1.000000e+00
  %4742 = select i1 %4739, float 0.000000e+00, float 1.000000e+00
  %4743 = fmul fast float %4731, 0x3FB3D07220000000
  %4744 = fmul fast float %4732, 0x3FB3D07220000000
  %4745 = fmul fast float %4733, 0x3FB3D07220000000
  %4746 = fadd fast float %4731, 0x3FAC28F5C0000000
  %4747 = fadd fast float %4732, 0x3FAC28F5C0000000
  %4748 = fadd fast float %4733, 0x3FAC28F5C0000000
  %4749 = fmul fast float %4746, 0x3FEE54EDE0000000
  %4750 = fmul fast float %4747, 0x3FEE54EDE0000000
  %4751 = fmul fast float %4748, 0x3FEE54EDE0000000
  %4752 = call float @dx.op.unary.f32(i32 23, float %4749)  ; Log(value)
  %4753 = call float @dx.op.unary.f32(i32 23, float %4750)  ; Log(value)
  %4754 = call float @dx.op.unary.f32(i32 23, float %4751)  ; Log(value)
  %4755 = fmul fast float %4752, 0x4003333340000000
  %4756 = fmul fast float %4753, 0x4003333340000000
  %4757 = fmul fast float %4754, 0x4003333340000000
  %4758 = call float @dx.op.unary.f32(i32 21, float %4755)  ; Exp(value)
  %4759 = call float @dx.op.unary.f32(i32 21, float %4756)  ; Exp(value)
  %4760 = call float @dx.op.unary.f32(i32 21, float %4757)  ; Exp(value)
  %4761 = fsub fast float %4743, %4758
  %4762 = fsub fast float %4744, %4759
  %4763 = fsub fast float %4745, %4760
  %4764 = fmul fast float %4761, %4740
  %4765 = fmul fast float %4762, %4741
  %4766 = fmul fast float %4763, %4742
  %4767 = fadd fast float %4764, %4758
  %4768 = fadd fast float %4765, %4759
  %4769 = fadd fast float %4766, %4760
  br label %4933

; <label>:4770                                    ; preds = %4725
  %4771 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4728, i32 %4729, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4772 = extractvalue %dx.types.ResRet.f32 %4771, 0
  %4773 = fcmp fast ogt float %39, 5.000000e-01
  %4774 = fcmp fast olt float %4772, 1.000000e+00
  %4775 = and i1 %4773, %4774
  br i1 %4775, label %4776, label %4862

; <label>:4776                                    ; preds = %4770
  %4777 = sitofp i32 %4728 to float
  %4778 = sitofp i32 %4729 to float
  %4779 = fadd fast float %4777, 5.000000e-01
  %4780 = fadd fast float %4778, 5.000000e-01
  %4781 = fdiv fast float %4779, %46
  %4782 = fdiv fast float %4780, %47
  %4783 = fmul fast float %4781, 2.000000e+00
  %4784 = fmul fast float %4782, 2.000000e+00
  %4785 = fadd fast float %4783, -1.000000e+00
  %4786 = fsub fast float 1.000000e+00, %4784
  %4787 = fmul fast float %4785, %36
  %4788 = call float @dx.op.tertiary.f32(i32 46, float %4786, float %32, float %4787)  ; FMad(a,b,c)
  %4789 = call float @dx.op.tertiary.f32(i32 46, float %4772, float %28, float %4788)  ; FMad(a,b,c)
  %4790 = fadd fast float %4789, %24
  %4791 = call float @dx.op.unary.f32(i32 6, float %4790)  ; FAbs(value)
  %4792 = fcmp fast ogt float %4791, 0x3EB0C6F7A0000000
  br i1 %4792, label %4793, label %4862

; <label>:4793                                    ; preds = %4776
  %4794 = fmul fast float %4785, %35
  %4795 = call float @dx.op.tertiary.f32(i32 46, float %4786, float %31, float %4794)  ; FMad(a,b,c)
  %4796 = call float @dx.op.tertiary.f32(i32 46, float %4772, float %27, float %4795)  ; FMad(a,b,c)
  %4797 = fadd fast float %4796, %23
  %4798 = fmul fast float %4785, %34
  %4799 = call float @dx.op.tertiary.f32(i32 46, float %4786, float %30, float %4798)  ; FMad(a,b,c)
  %4800 = call float @dx.op.tertiary.f32(i32 46, float %4772, float %26, float %4799)  ; FMad(a,b,c)
  %4801 = fadd fast float %4800, %22
  %4802 = fmul fast float %4785, %33
  %4803 = call float @dx.op.tertiary.f32(i32 46, float %4786, float %29, float %4802)  ; FMad(a,b,c)
  %4804 = call float @dx.op.tertiary.f32(i32 46, float %4772, float %25, float %4803)  ; FMad(a,b,c)
  %4805 = fadd fast float %4804, %21
  %4806 = fdiv fast float %4805, %4790
  %4807 = fdiv fast float %4801, %4790
  %4808 = fdiv fast float %4797, %4790
  %4809 = fsub fast float %4806, %18
  %4810 = fsub fast float %4807, %19
  %4811 = fsub fast float %4808, %20
  %4812 = fmul fast float %4809, %4809
  %4813 = fmul fast float %4810, %4810
  %4814 = fadd fast float %4813, %4812
  %4815 = fmul fast float %4811, %4811
  %4816 = fadd fast float %4814, %4815
  %4817 = call float @dx.op.unary.f32(i32 24, float %4816)  ; Sqrt(value)
  %4818 = fsub fast float %4817, %10
  %4819 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4818)  ; FMax(a,b)
  %4820 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %4820, label %4821, label %4844

; <label>:4821                                    ; preds = %4793
  %4822 = call float @dx.op.unary.f32(i32 6, float %4810)  ; FAbs(value)
  %4823 = fmul fast float %4822, %12
  %4824 = fcmp fast olt float %4823, 0x3F50624DE0000000
  br i1 %4824, label %4825, label %4828

; <label>:4825                                    ; preds = %4821
  %4826 = fmul fast float %4823, 5.000000e-01
  %4827 = fsub fast float 1.000000e+00, %4826
  br label %4833

; <label>:4828                                    ; preds = %4821
  %4829 = fmul fast float %4823, 0xBFF7154760000000
  %4830 = call float @dx.op.unary.f32(i32 21, float %4829)  ; Exp(value)
  %4831 = fsub fast float 1.000000e+00, %4830
  %4832 = fdiv fast float %4831, %4823
  br label %4833

; <label>:4833                                    ; preds = %4828, %4825
  %4834 = phi float [ %4827, %4825 ], [ %4832, %4828 ]
  %4835 = call float @dx.op.binary.f32(i32 36, float %4807, float %19)  ; FMin(a,b)
  %4836 = fsub fast float %4835, %11
  %4837 = fmul fast float %12, %4836
  %4838 = fsub fast float -0.000000e+00, %4837
  %4839 = call float @dx.op.binary.f32(i32 35, float %4838, float -4.000000e+01)  ; FMax(a,b)
  %4840 = call float @dx.op.binary.f32(i32 36, float %4839, float 5.000000e+00)  ; FMin(a,b)
  %4841 = fmul fast float %4840, 0x3FF7154760000000
  %4842 = call float @dx.op.unary.f32(i32 21, float %4841)  ; Exp(value)
  %4843 = fmul fast float %4842, %4834
  br label %4844

; <label>:4844                                    ; preds = %4833, %4793
  %4845 = phi float [ %4843, %4833 ], [ 1.000000e+00, %4793 ]
  %4846 = fmul fast float %4819, %17
  %4847 = fmul fast float %4846, %4845
  %4848 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4847)  ; FMin(a,b)
  %4849 = fmul fast float %4848, 0xBFF7154760000000
  %4850 = call float @dx.op.unary.f32(i32 21, float %4849)  ; Exp(value)
  %4851 = fsub fast float 1.000000e+00, %4850
  %4852 = call float @dx.op.binary.f32(i32 36, float %13, float %4851)  ; FMin(a,b)
  %4853 = fsub fast float %14, %4731
  %4854 = fsub fast float %15, %4732
  %4855 = fsub fast float %16, %4733
  %4856 = fmul fast float %4852, %4853
  %4857 = fmul fast float %4852, %4854
  %4858 = fmul fast float %4852, %4855
  %4859 = fadd fast float %4856, %4731
  %4860 = fadd fast float %4857, %4732
  %4861 = fadd fast float %4858, %4733
  br label %4862

; <label>:4862                                    ; preds = %4844, %4776, %4770
  %4863 = phi float [ %4859, %4844 ], [ %4731, %4776 ], [ %4731, %4770 ]
  %4864 = phi float [ %4860, %4844 ], [ %4732, %4776 ], [ %4732, %4770 ]
  %4865 = phi float [ %4861, %4844 ], [ %4733, %4776 ], [ %4733, %4770 ]
  %4866 = fadd fast float %6, 1.000000e+00
  %4867 = fadd fast float %7, 1.000000e+00
  %4868 = fsub fast float 1.000000e+00, %6
  %4869 = fmul fast float %37, %4866
  %4870 = fmul fast float %37, %4867
  %4871 = fmul fast float %37, %4868
  %4872 = fmul fast float %4869, %4863
  %4873 = fmul fast float %4870, %4864
  %4874 = fmul fast float %4871, %4865
  %4875 = fcmp fast ult float %38, 5.000000e-01
  br i1 %4875, label %4901, label %4876

; <label>:4876                                    ; preds = %4862
  %4877 = fmul fast float %4872, 0x4004147AE0000000
  %4878 = fmul fast float %4873, 0x4004147AE0000000
  %4879 = fmul fast float %4874, 0x4004147AE0000000
  %4880 = fadd fast float %4877, 0x3F9EB851E0000000
  %4881 = fadd fast float %4878, 0x3F9EB851E0000000
  %4882 = fadd fast float %4879, 0x3F9EB851E0000000
  %4883 = fmul fast float %4880, %4872
  %4884 = fmul fast float %4881, %4873
  %4885 = fmul fast float %4882, %4874
  %4886 = fmul fast float %4872, 0x400370A3E0000000
  %4887 = fmul fast float %4873, 0x400370A3E0000000
  %4888 = fmul fast float %4874, 0x400370A3E0000000
  %4889 = fadd fast float %4886, 0x3FE2E147A0000000
  %4890 = fadd fast float %4887, 0x3FE2E147A0000000
  %4891 = fadd fast float %4888, 0x3FE2E147A0000000
  %4892 = fmul fast float %4889, %4872
  %4893 = fmul fast float %4890, %4873
  %4894 = fmul fast float %4891, %4874
  %4895 = fadd fast float %4892, 0x3FC1EB8520000000
  %4896 = fadd fast float %4893, 0x3FC1EB8520000000
  %4897 = fadd fast float %4894, 0x3FC1EB8520000000
  %4898 = fdiv fast float %4883, %4895
  %4899 = fdiv fast float %4884, %4896
  %4900 = fdiv fast float %4885, %4897
  br label %4901

; <label>:4901                                    ; preds = %4876, %4862
  %4902 = phi float [ %4898, %4876 ], [ %4872, %4862 ]
  %4903 = phi float [ %4899, %4876 ], [ %4873, %4862 ]
  %4904 = phi float [ %4900, %4876 ], [ %4874, %4862 ]
  %4905 = call float @dx.op.unary.f32(i32 7, float %4902)  ; Saturate(value)
  %4906 = call float @dx.op.unary.f32(i32 7, float %4903)  ; Saturate(value)
  %4907 = call float @dx.op.unary.f32(i32 7, float %4904)  ; Saturate(value)
  %4908 = call float @dx.op.dot3.f32(i32 55, float %4905, float %4906, float %4907, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4909 = fsub fast float %4905, %4908
  %4910 = fsub fast float %4906, %4908
  %4911 = fsub fast float %4907, %4908
  %4912 = fmul fast float %4909, %9
  %4913 = fmul fast float %4910, %9
  %4914 = fmul fast float %4911, %9
  %4915 = fadd fast float %4912, %4908
  %4916 = fadd fast float %4913, %4908
  %4917 = fadd fast float %4914, %4908
  %4918 = call float @dx.op.unary.f32(i32 7, float %4915)  ; Saturate(value)
  %4919 = call float @dx.op.unary.f32(i32 7, float %4916)  ; Saturate(value)
  %4920 = call float @dx.op.unary.f32(i32 7, float %4917)  ; Saturate(value)
  %4921 = fadd fast float %4918, 0xBFC70A3D80000000
  %4922 = fadd fast float %4919, 0xBFC70A3D80000000
  %4923 = fadd fast float %4920, 0xBFC70A3D80000000
  %4924 = fmul fast float %4921, %8
  %4925 = fmul fast float %4922, %8
  %4926 = fmul fast float %4923, %8
  %4927 = fadd fast float %4924, 0x3FC70A3D80000000
  %4928 = fadd fast float %4925, 0x3FC70A3D80000000
  %4929 = fadd fast float %4926, 0x3FC70A3D80000000
  %4930 = call float @dx.op.unary.f32(i32 7, float %4927)  ; Saturate(value)
  %4931 = call float @dx.op.unary.f32(i32 7, float %4928)  ; Saturate(value)
  %4932 = call float @dx.op.unary.f32(i32 7, float %4929)  ; Saturate(value)
  br label %4933

; <label>:4933                                    ; preds = %4901, %4736
  %4934 = phi float [ %4767, %4736 ], [ %4930, %4901 ]
  %4935 = phi float [ %4768, %4736 ], [ %4931, %4901 ]
  %4936 = phi float [ %4769, %4736 ], [ %4932, %4901 ]
  %4937 = fsub fast float %4934, %4230
  %4938 = fsub fast float %4935, %4231
  %4939 = fsub fast float %4936, %4232
  %4940 = fmul fast float %4937, %4723
  %4941 = fmul fast float %4938, %4723
  %4942 = fmul fast float %4939, %4723
  %4943 = fadd fast float %4940, %4230
  %4944 = fadd fast float %4941, %4231
  %4945 = fadd fast float %4942, %4232
  br label %4946

; <label>:4946                                    ; preds = %4933, %4708
  %4947 = phi float [ %4943, %4933 ], [ %4230, %4708 ]
  %4948 = phi float [ %4944, %4933 ], [ %4231, %4708 ]
  %4949 = phi float [ %4945, %4933 ], [ %4232, %4708 ]
  %4950 = add i32 %68, 1
  %4951 = call i32 @dx.op.binary.i32(i32 37, i32 %4950, i32 0)  ; IMax(a,b)
  %4952 = call i32 @dx.op.binary.i32(i32 38, i32 %4951, i32 %60)  ; IMin(a,b)
  %4953 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4952, i32 %4716, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4954 = extractvalue %dx.types.ResRet.f32 %4953, 0
  %4955 = fsub fast float %4954, %89
  %4956 = call float @dx.op.unary.f32(i32 6, float %4955)  ; FAbs(value)
  %4957 = fdiv fast float %4956, %4244
  %4958 = fsub fast float 1.000000e+00, %4957
  %4959 = call float @dx.op.unary.f32(i32 7, float %4958)  ; Saturate(value)
  %4960 = fcmp fast ugt float %4959, 0.000000e+00
  br i1 %4960, label %4961, label %5182

; <label>:4961                                    ; preds = %4946
  %4962 = call i32 @dx.op.binary.i32(i32 37, i32 %4952, i32 0)  ; IMax(a,b)
  %4963 = call i32 @dx.op.binary.i32(i32 37, i32 %4716, i32 0)  ; IMax(a,b)
  %4964 = call i32 @dx.op.binary.i32(i32 38, i32 %4962, i32 %60)  ; IMin(a,b)
  %4965 = call i32 @dx.op.binary.i32(i32 38, i32 %4963, i32 %61)  ; IMin(a,b)
  %4966 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4964, i32 %4965, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4967 = extractvalue %dx.types.ResRet.f32 %4966, 0
  %4968 = extractvalue %dx.types.ResRet.f32 %4966, 1
  %4969 = extractvalue %dx.types.ResRet.f32 %4966, 2
  %4970 = extractvalue %dx.types.ResRet.f32 %4966, 3
  %4971 = fcmp fast olt float %4970, 0.000000e+00
  br i1 %4971, label %4972, label %5006

; <label>:4972                                    ; preds = %4961
  %4973 = fcmp fast ogt float %4967, 0x3FA4B5DCC0000000
  %4974 = fcmp fast ogt float %4968, 0x3FA4B5DCC0000000
  %4975 = fcmp fast ogt float %4969, 0x3FA4B5DCC0000000
  %4976 = select i1 %4973, float 0.000000e+00, float 1.000000e+00
  %4977 = select i1 %4974, float 0.000000e+00, float 1.000000e+00
  %4978 = select i1 %4975, float 0.000000e+00, float 1.000000e+00
  %4979 = fmul fast float %4967, 0x3FB3D07220000000
  %4980 = fmul fast float %4968, 0x3FB3D07220000000
  %4981 = fmul fast float %4969, 0x3FB3D07220000000
  %4982 = fadd fast float %4967, 0x3FAC28F5C0000000
  %4983 = fadd fast float %4968, 0x3FAC28F5C0000000
  %4984 = fadd fast float %4969, 0x3FAC28F5C0000000
  %4985 = fmul fast float %4982, 0x3FEE54EDE0000000
  %4986 = fmul fast float %4983, 0x3FEE54EDE0000000
  %4987 = fmul fast float %4984, 0x3FEE54EDE0000000
  %4988 = call float @dx.op.unary.f32(i32 23, float %4985)  ; Log(value)
  %4989 = call float @dx.op.unary.f32(i32 23, float %4986)  ; Log(value)
  %4990 = call float @dx.op.unary.f32(i32 23, float %4987)  ; Log(value)
  %4991 = fmul fast float %4988, 0x4003333340000000
  %4992 = fmul fast float %4989, 0x4003333340000000
  %4993 = fmul fast float %4990, 0x4003333340000000
  %4994 = call float @dx.op.unary.f32(i32 21, float %4991)  ; Exp(value)
  %4995 = call float @dx.op.unary.f32(i32 21, float %4992)  ; Exp(value)
  %4996 = call float @dx.op.unary.f32(i32 21, float %4993)  ; Exp(value)
  %4997 = fsub fast float %4979, %4994
  %4998 = fsub fast float %4980, %4995
  %4999 = fsub fast float %4981, %4996
  %5000 = fmul fast float %4997, %4976
  %5001 = fmul fast float %4998, %4977
  %5002 = fmul fast float %4999, %4978
  %5003 = fadd fast float %5000, %4994
  %5004 = fadd fast float %5001, %4995
  %5005 = fadd fast float %5002, %4996
  br label %5169

; <label>:5006                                    ; preds = %4961
  %5007 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4964, i32 %4965, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5008 = extractvalue %dx.types.ResRet.f32 %5007, 0
  %5009 = fcmp fast ogt float %39, 5.000000e-01
  %5010 = fcmp fast olt float %5008, 1.000000e+00
  %5011 = and i1 %5009, %5010
  br i1 %5011, label %5012, label %5098

; <label>:5012                                    ; preds = %5006
  %5013 = sitofp i32 %4964 to float
  %5014 = sitofp i32 %4965 to float
  %5015 = fadd fast float %5013, 5.000000e-01
  %5016 = fadd fast float %5014, 5.000000e-01
  %5017 = fdiv fast float %5015, %46
  %5018 = fdiv fast float %5016, %47
  %5019 = fmul fast float %5017, 2.000000e+00
  %5020 = fmul fast float %5018, 2.000000e+00
  %5021 = fadd fast float %5019, -1.000000e+00
  %5022 = fsub fast float 1.000000e+00, %5020
  %5023 = fmul fast float %5021, %36
  %5024 = call float @dx.op.tertiary.f32(i32 46, float %5022, float %32, float %5023)  ; FMad(a,b,c)
  %5025 = call float @dx.op.tertiary.f32(i32 46, float %5008, float %28, float %5024)  ; FMad(a,b,c)
  %5026 = fadd fast float %5025, %24
  %5027 = call float @dx.op.unary.f32(i32 6, float %5026)  ; FAbs(value)
  %5028 = fcmp fast ogt float %5027, 0x3EB0C6F7A0000000
  br i1 %5028, label %5029, label %5098

; <label>:5029                                    ; preds = %5012
  %5030 = fmul fast float %5021, %35
  %5031 = call float @dx.op.tertiary.f32(i32 46, float %5022, float %31, float %5030)  ; FMad(a,b,c)
  %5032 = call float @dx.op.tertiary.f32(i32 46, float %5008, float %27, float %5031)  ; FMad(a,b,c)
  %5033 = fadd fast float %5032, %23
  %5034 = fmul fast float %5021, %34
  %5035 = call float @dx.op.tertiary.f32(i32 46, float %5022, float %30, float %5034)  ; FMad(a,b,c)
  %5036 = call float @dx.op.tertiary.f32(i32 46, float %5008, float %26, float %5035)  ; FMad(a,b,c)
  %5037 = fadd fast float %5036, %22
  %5038 = fmul fast float %5021, %33
  %5039 = call float @dx.op.tertiary.f32(i32 46, float %5022, float %29, float %5038)  ; FMad(a,b,c)
  %5040 = call float @dx.op.tertiary.f32(i32 46, float %5008, float %25, float %5039)  ; FMad(a,b,c)
  %5041 = fadd fast float %5040, %21
  %5042 = fdiv fast float %5041, %5026
  %5043 = fdiv fast float %5037, %5026
  %5044 = fdiv fast float %5033, %5026
  %5045 = fsub fast float %5042, %18
  %5046 = fsub fast float %5043, %19
  %5047 = fsub fast float %5044, %20
  %5048 = fmul fast float %5045, %5045
  %5049 = fmul fast float %5046, %5046
  %5050 = fadd fast float %5049, %5048
  %5051 = fmul fast float %5047, %5047
  %5052 = fadd fast float %5050, %5051
  %5053 = call float @dx.op.unary.f32(i32 24, float %5052)  ; Sqrt(value)
  %5054 = fsub fast float %5053, %10
  %5055 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5054)  ; FMax(a,b)
  %5056 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %5056, label %5057, label %5080

; <label>:5057                                    ; preds = %5029
  %5058 = call float @dx.op.unary.f32(i32 6, float %5046)  ; FAbs(value)
  %5059 = fmul fast float %5058, %12
  %5060 = fcmp fast olt float %5059, 0x3F50624DE0000000
  br i1 %5060, label %5061, label %5064

; <label>:5061                                    ; preds = %5057
  %5062 = fmul fast float %5059, 5.000000e-01
  %5063 = fsub fast float 1.000000e+00, %5062
  br label %5069

; <label>:5064                                    ; preds = %5057
  %5065 = fmul fast float %5059, 0xBFF7154760000000
  %5066 = call float @dx.op.unary.f32(i32 21, float %5065)  ; Exp(value)
  %5067 = fsub fast float 1.000000e+00, %5066
  %5068 = fdiv fast float %5067, %5059
  br label %5069

; <label>:5069                                    ; preds = %5064, %5061
  %5070 = phi float [ %5063, %5061 ], [ %5068, %5064 ]
  %5071 = call float @dx.op.binary.f32(i32 36, float %5043, float %19)  ; FMin(a,b)
  %5072 = fsub fast float %5071, %11
  %5073 = fmul fast float %12, %5072
  %5074 = fsub fast float -0.000000e+00, %5073
  %5075 = call float @dx.op.binary.f32(i32 35, float %5074, float -4.000000e+01)  ; FMax(a,b)
  %5076 = call float @dx.op.binary.f32(i32 36, float %5075, float 5.000000e+00)  ; FMin(a,b)
  %5077 = fmul fast float %5076, 0x3FF7154760000000
  %5078 = call float @dx.op.unary.f32(i32 21, float %5077)  ; Exp(value)
  %5079 = fmul fast float %5078, %5070
  br label %5080

; <label>:5080                                    ; preds = %5069, %5029
  %5081 = phi float [ %5079, %5069 ], [ 1.000000e+00, %5029 ]
  %5082 = fmul fast float %5055, %17
  %5083 = fmul fast float %5082, %5081
  %5084 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %5083)  ; FMin(a,b)
  %5085 = fmul fast float %5084, 0xBFF7154760000000
  %5086 = call float @dx.op.unary.f32(i32 21, float %5085)  ; Exp(value)
  %5087 = fsub fast float 1.000000e+00, %5086
  %5088 = call float @dx.op.binary.f32(i32 36, float %13, float %5087)  ; FMin(a,b)
  %5089 = fsub fast float %14, %4967
  %5090 = fsub fast float %15, %4968
  %5091 = fsub fast float %16, %4969
  %5092 = fmul fast float %5088, %5089
  %5093 = fmul fast float %5088, %5090
  %5094 = fmul fast float %5088, %5091
  %5095 = fadd fast float %5092, %4967
  %5096 = fadd fast float %5093, %4968
  %5097 = fadd fast float %5094, %4969
  br label %5098

; <label>:5098                                    ; preds = %5080, %5012, %5006
  %5099 = phi float [ %5095, %5080 ], [ %4967, %5012 ], [ %4967, %5006 ]
  %5100 = phi float [ %5096, %5080 ], [ %4968, %5012 ], [ %4968, %5006 ]
  %5101 = phi float [ %5097, %5080 ], [ %4969, %5012 ], [ %4969, %5006 ]
  %5102 = fadd fast float %6, 1.000000e+00
  %5103 = fadd fast float %7, 1.000000e+00
  %5104 = fsub fast float 1.000000e+00, %6
  %5105 = fmul fast float %37, %5102
  %5106 = fmul fast float %37, %5103
  %5107 = fmul fast float %37, %5104
  %5108 = fmul fast float %5105, %5099
  %5109 = fmul fast float %5106, %5100
  %5110 = fmul fast float %5107, %5101
  %5111 = fcmp fast ult float %38, 5.000000e-01
  br i1 %5111, label %5137, label %5112

; <label>:5112                                    ; preds = %5098
  %5113 = fmul fast float %5108, 0x4004147AE0000000
  %5114 = fmul fast float %5109, 0x4004147AE0000000
  %5115 = fmul fast float %5110, 0x4004147AE0000000
  %5116 = fadd fast float %5113, 0x3F9EB851E0000000
  %5117 = fadd fast float %5114, 0x3F9EB851E0000000
  %5118 = fadd fast float %5115, 0x3F9EB851E0000000
  %5119 = fmul fast float %5116, %5108
  %5120 = fmul fast float %5117, %5109
  %5121 = fmul fast float %5118, %5110
  %5122 = fmul fast float %5108, 0x400370A3E0000000
  %5123 = fmul fast float %5109, 0x400370A3E0000000
  %5124 = fmul fast float %5110, 0x400370A3E0000000
  %5125 = fadd fast float %5122, 0x3FE2E147A0000000
  %5126 = fadd fast float %5123, 0x3FE2E147A0000000
  %5127 = fadd fast float %5124, 0x3FE2E147A0000000
  %5128 = fmul fast float %5125, %5108
  %5129 = fmul fast float %5126, %5109
  %5130 = fmul fast float %5127, %5110
  %5131 = fadd fast float %5128, 0x3FC1EB8520000000
  %5132 = fadd fast float %5129, 0x3FC1EB8520000000
  %5133 = fadd fast float %5130, 0x3FC1EB8520000000
  %5134 = fdiv fast float %5119, %5131
  %5135 = fdiv fast float %5120, %5132
  %5136 = fdiv fast float %5121, %5133
  br label %5137

; <label>:5137                                    ; preds = %5112, %5098
  %5138 = phi float [ %5134, %5112 ], [ %5108, %5098 ]
  %5139 = phi float [ %5135, %5112 ], [ %5109, %5098 ]
  %5140 = phi float [ %5136, %5112 ], [ %5110, %5098 ]
  %5141 = call float @dx.op.unary.f32(i32 7, float %5138)  ; Saturate(value)
  %5142 = call float @dx.op.unary.f32(i32 7, float %5139)  ; Saturate(value)
  %5143 = call float @dx.op.unary.f32(i32 7, float %5140)  ; Saturate(value)
  %5144 = call float @dx.op.dot3.f32(i32 55, float %5141, float %5142, float %5143, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5145 = fsub fast float %5141, %5144
  %5146 = fsub fast float %5142, %5144
  %5147 = fsub fast float %5143, %5144
  %5148 = fmul fast float %5145, %9
  %5149 = fmul fast float %5146, %9
  %5150 = fmul fast float %5147, %9
  %5151 = fadd fast float %5148, %5144
  %5152 = fadd fast float %5149, %5144
  %5153 = fadd fast float %5150, %5144
  %5154 = call float @dx.op.unary.f32(i32 7, float %5151)  ; Saturate(value)
  %5155 = call float @dx.op.unary.f32(i32 7, float %5152)  ; Saturate(value)
  %5156 = call float @dx.op.unary.f32(i32 7, float %5153)  ; Saturate(value)
  %5157 = fadd fast float %5154, 0xBFC70A3D80000000
  %5158 = fadd fast float %5155, 0xBFC70A3D80000000
  %5159 = fadd fast float %5156, 0xBFC70A3D80000000
  %5160 = fmul fast float %5157, %8
  %5161 = fmul fast float %5158, %8
  %5162 = fmul fast float %5159, %8
  %5163 = fadd fast float %5160, 0x3FC70A3D80000000
  %5164 = fadd fast float %5161, 0x3FC70A3D80000000
  %5165 = fadd fast float %5162, 0x3FC70A3D80000000
  %5166 = call float @dx.op.unary.f32(i32 7, float %5163)  ; Saturate(value)
  %5167 = call float @dx.op.unary.f32(i32 7, float %5164)  ; Saturate(value)
  %5168 = call float @dx.op.unary.f32(i32 7, float %5165)  ; Saturate(value)
  br label %5169

; <label>:5169                                    ; preds = %5137, %4972
  %5170 = phi float [ %5003, %4972 ], [ %5166, %5137 ]
  %5171 = phi float [ %5004, %4972 ], [ %5167, %5137 ]
  %5172 = phi float [ %5005, %4972 ], [ %5168, %5137 ]
  %5173 = fsub fast float %5170, %4230
  %5174 = fsub fast float %5171, %4231
  %5175 = fsub fast float %5172, %4232
  %5176 = fmul fast float %5173, %4959
  %5177 = fmul fast float %5174, %4959
  %5178 = fmul fast float %5175, %4959
  %5179 = fadd fast float %5176, %4230
  %5180 = fadd fast float %5177, %4231
  %5181 = fadd fast float %5178, %4232
  br label %5182

; <label>:5182                                    ; preds = %5169, %4946
  %5183 = phi float [ %5179, %5169 ], [ %4230, %4946 ]
  %5184 = phi float [ %5180, %5169 ], [ %4231, %4946 ]
  %5185 = phi float [ %5181, %5169 ], [ %4232, %4946 ]
  %5186 = call float @dx.op.binary.f32(i32 36, float %4947, float %5183)  ; FMin(a,b)
  %5187 = call float @dx.op.binary.f32(i32 36, float %4948, float %5184)  ; FMin(a,b)
  %5188 = call float @dx.op.binary.f32(i32 36, float %4949, float %5185)  ; FMin(a,b)
  %5189 = call float @dx.op.binary.f32(i32 36, float %4473, float %4709)  ; FMin(a,b)
  %5190 = call float @dx.op.binary.f32(i32 36, float %4474, float %4710)  ; FMin(a,b)
  %5191 = call float @dx.op.binary.f32(i32 36, float %4475, float %4711)  ; FMin(a,b)
  %5192 = call float @dx.op.binary.f32(i32 36, float %5189, float %5186)  ; FMin(a,b)
  %5193 = call float @dx.op.binary.f32(i32 36, float %5190, float %5187)  ; FMin(a,b)
  %5194 = call float @dx.op.binary.f32(i32 36, float %5191, float %5188)  ; FMin(a,b)
  %5195 = call float @dx.op.binary.f32(i32 36, float %4230, float %5192)  ; FMin(a,b)
  %5196 = call float @dx.op.binary.f32(i32 36, float %4231, float %5193)  ; FMin(a,b)
  %5197 = call float @dx.op.binary.f32(i32 36, float %4232, float %5194)  ; FMin(a,b)
  %5198 = call float @dx.op.binary.f32(i32 35, float %4947, float %5183)  ; FMax(a,b)
  %5199 = call float @dx.op.binary.f32(i32 35, float %4948, float %5184)  ; FMax(a,b)
  %5200 = call float @dx.op.binary.f32(i32 35, float %4949, float %5185)  ; FMax(a,b)
  %5201 = call float @dx.op.binary.f32(i32 35, float %4473, float %4709)  ; FMax(a,b)
  %5202 = call float @dx.op.binary.f32(i32 35, float %4474, float %4710)  ; FMax(a,b)
  %5203 = call float @dx.op.binary.f32(i32 35, float %4475, float %4711)  ; FMax(a,b)
  %5204 = call float @dx.op.binary.f32(i32 35, float %5201, float %5198)  ; FMax(a,b)
  %5205 = call float @dx.op.binary.f32(i32 35, float %5202, float %5199)  ; FMax(a,b)
  %5206 = call float @dx.op.binary.f32(i32 35, float %5203, float %5200)  ; FMax(a,b)
  %5207 = call float @dx.op.binary.f32(i32 35, float %4230, float %5204)  ; FMax(a,b)
  %5208 = call float @dx.op.binary.f32(i32 35, float %4231, float %5205)  ; FMax(a,b)
  %5209 = call float @dx.op.binary.f32(i32 35, float %4232, float %5206)  ; FMax(a,b)
  %5210 = fsub fast float %5207, %5195
  %5211 = fsub fast float %5208, %5196
  %5212 = fsub fast float %5209, %5197
  %5213 = call float @dx.op.unary.f32(i32 6, float %5210)  ; FAbs(value)
  %5214 = call float @dx.op.unary.f32(i32 6, float %5211)  ; FAbs(value)
  %5215 = call float @dx.op.unary.f32(i32 6, float %5212)  ; FAbs(value)
  %5216 = call float @dx.op.binary.f32(i32 35, float %5214, float %5215)  ; FMax(a,b)
  %5217 = call float @dx.op.binary.f32(i32 35, float %5213, float %5216)  ; FMax(a,b)
  %5218 = call float @dx.op.binary.f32(i32 35, float %5208, float %5209)  ; FMax(a,b)
  %5219 = call float @dx.op.binary.f32(i32 35, float %5207, float %5218)  ; FMax(a,b)
  %5220 = fmul fast float %5219, 1.250000e-01
  %5221 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %5220)  ; FMax(a,b)
  %5222 = fcmp fast ogt float %5217, %5221
  br i1 %5222, label %5223, label %5285

; <label>:5223                                    ; preds = %5182
  %5224 = fsub fast float %4473, %4709
  %5225 = fsub fast float %4474, %4710
  %5226 = fsub fast float %4475, %4711
  %5227 = call float @dx.op.unary.f32(i32 6, float %5224)  ; FAbs(value)
  %5228 = call float @dx.op.unary.f32(i32 6, float %5225)  ; FAbs(value)
  %5229 = call float @dx.op.unary.f32(i32 6, float %5226)  ; FAbs(value)
  %5230 = call float @dx.op.binary.f32(i32 35, float %5228, float %5229)  ; FMax(a,b)
  %5231 = call float @dx.op.binary.f32(i32 35, float %5227, float %5230)  ; FMax(a,b)
  %5232 = fsub fast float %4947, %5183
  %5233 = fsub fast float %4948, %5184
  %5234 = fsub fast float %4949, %5185
  %5235 = call float @dx.op.unary.f32(i32 6, float %5232)  ; FAbs(value)
  %5236 = call float @dx.op.unary.f32(i32 6, float %5233)  ; FAbs(value)
  %5237 = call float @dx.op.unary.f32(i32 6, float %5234)  ; FAbs(value)
  %5238 = call float @dx.op.binary.f32(i32 35, float %5236, float %5237)  ; FMax(a,b)
  %5239 = call float @dx.op.binary.f32(i32 35, float %5235, float %5238)  ; FMax(a,b)
  %5240 = fcmp fast olt float %5231, %5239
  %5241 = select i1 %5240, float %4473, float %4947
  %5242 = select i1 %5240, float %4474, float %4948
  %5243 = select i1 %5240, float %4475, float %4949
  %5244 = select i1 %5240, float %4709, float %5183
  %5245 = select i1 %5240, float %4710, float %5184
  %5246 = select i1 %5240, float %4711, float %5185
  %5247 = fsub fast float %4230, %5244
  %5248 = fsub fast float %4231, %5245
  %5249 = fsub fast float %4232, %5246
  %5250 = fsub fast float %4230, %5241
  %5251 = fsub fast float %4231, %5242
  %5252 = fsub fast float %4232, %5243
  %5253 = call float @dx.op.dot3.f32(i32 55, float %5250, float %5251, float %5252, float %5247, float %5248, float %5249)  ; Dot3(ax,ay,az,bx,by,bz)
  %5254 = fcmp fast ogt float %5253, 0.000000e+00
  br i1 %5254, label %5255, label %5267

; <label>:5255                                    ; preds = %5223
  %5256 = fsub fast float %5241, %5244
  %5257 = fsub fast float %5242, %5245
  %5258 = fsub fast float %5243, %5246
  %5259 = call float @dx.op.unary.f32(i32 6, float %5256)  ; FAbs(value)
  %5260 = call float @dx.op.unary.f32(i32 6, float %5257)  ; FAbs(value)
  %5261 = call float @dx.op.unary.f32(i32 6, float %5258)  ; FAbs(value)
  %5262 = call float @dx.op.binary.f32(i32 35, float %5260, float %5261)  ; FMax(a,b)
  %5263 = call float @dx.op.binary.f32(i32 35, float %5259, float %5262)  ; FMax(a,b)
  %5264 = fmul fast float %5217, 2.500000e-01
  %5265 = fcmp fast olt float %5263, %5264
  %5266 = select i1 %5265, float 5.000000e-01, float 1.000000e+00
  br label %5267

; <label>:5267                                    ; preds = %5255, %5223
  %5268 = phi float [ 1.000000e+00, %5223 ], [ %5266, %5255 ]
  %5269 = fmul fast float %5268, %3
  %5270 = fadd fast float %5241, %5244
  %5271 = fadd fast float %5242, %5245
  %5272 = fadd fast float %5243, %5246
  %5273 = fmul fast float %5270, 5.000000e-01
  %5274 = fmul fast float %5271, 5.000000e-01
  %5275 = fmul fast float %5272, 5.000000e-01
  %5276 = fsub fast float %5273, %4230
  %5277 = fsub fast float %5274, %4231
  %5278 = fsub fast float %5275, %4232
  %5279 = fmul fast float %5269, %5276
  %5280 = fmul fast float %5269, %5277
  %5281 = fmul fast float %5269, %5278
  %5282 = fadd fast float %5279, %4230
  %5283 = fadd fast float %5280, %4231
  %5284 = fadd fast float %5281, %4232
  br label %5285

; <label>:5285                                    ; preds = %5267, %5182, %4201
  %5286 = phi float [ %4230, %4201 ], [ %5282, %5267 ], [ %4230, %5182 ]
  %5287 = phi float [ %4231, %4201 ], [ %5283, %5267 ], [ %4231, %5182 ]
  %5288 = phi float [ %4232, %4201 ], [ %5284, %5267 ], [ %4232, %5182 ]
  %5289 = fcmp fast ogt float %5286, 0x3F69A5C380000000
  %5290 = fcmp fast ogt float %5287, 0x3F69A5C380000000
  %5291 = fcmp fast ogt float %5288, 0x3F69A5C380000000
  %5292 = select i1 %5289, float 0.000000e+00, float 1.000000e+00
  %5293 = select i1 %5290, float 0.000000e+00, float 1.000000e+00
  %5294 = select i1 %5291, float 0.000000e+00, float 1.000000e+00
  %5295 = fmul fast float %5286, 0x4029D70A40000000
  %5296 = fmul fast float %5287, 0x4029D70A40000000
  %5297 = fmul fast float %5288, 0x4029D70A40000000
  %5298 = call float @dx.op.binary.f32(i32 35, float %5286, float 0.000000e+00)  ; FMax(a,b)
  %5299 = call float @dx.op.binary.f32(i32 35, float %5287, float 0.000000e+00)  ; FMax(a,b)
  %5300 = call float @dx.op.binary.f32(i32 35, float %5288, float 0.000000e+00)  ; FMax(a,b)
  %5301 = call float @dx.op.unary.f32(i32 23, float %5298)  ; Log(value)
  %5302 = call float @dx.op.unary.f32(i32 23, float %5299)  ; Log(value)
  %5303 = call float @dx.op.unary.f32(i32 23, float %5300)  ; Log(value)
  %5304 = fmul fast float %5301, 0x3FDAAAAAA0000000
  %5305 = fmul fast float %5302, 0x3FDAAAAAA0000000
  %5306 = fmul fast float %5303, 0x3FDAAAAAA0000000
  %5307 = call float @dx.op.unary.f32(i32 21, float %5304)  ; Exp(value)
  %5308 = call float @dx.op.unary.f32(i32 21, float %5305)  ; Exp(value)
  %5309 = call float @dx.op.unary.f32(i32 21, float %5306)  ; Exp(value)
  %5310 = fmul fast float %5307, 0x3FF0E147A0000000
  %5311 = fmul fast float %5308, 0x3FF0E147A0000000
  %5312 = fmul fast float %5309, 0x3FF0E147A0000000
  %5313 = fadd fast float %5310, 0xBFAC28F5C0000000
  %5314 = fadd fast float %5311, 0xBFAC28F5C0000000
  %5315 = fadd fast float %5312, 0xBFAC28F5C0000000
  %5316 = fsub fast float %5295, %5313
  %5317 = fsub fast float %5296, %5314
  %5318 = fsub fast float %5297, %5315
  %5319 = fmul fast float %5316, %5292
  %5320 = fmul fast float %5317, %5293
  %5321 = fmul fast float %5318, %5294
  %5322 = fadd fast float %5319, %5313
  %5323 = fadd fast float %5320, %5314
  %5324 = fadd fast float %5321, %5315
  br label %5325

; <label>:5325                                    ; preds = %5285, %4070
  %5326 = phi float [ %4065, %4070 ], [ %5322, %5285 ]
  %5327 = phi float [ %4066, %4070 ], [ %5323, %5285 ]
  %5328 = phi float [ %4067, %4070 ], [ %5324, %5285 ]
  %5329 = phi float [ %4071, %4070 ], [ %4068, %5285 ]
  %5330 = fcmp fast ogt float %5326, 0x3FA4B5DCC0000000
  %5331 = fcmp fast ogt float %5327, 0x3FA4B5DCC0000000
  %5332 = fcmp fast ogt float %5328, 0x3FA4B5DCC0000000
  %5333 = select i1 %5330, float 0.000000e+00, float 1.000000e+00
  %5334 = select i1 %5331, float 0.000000e+00, float 1.000000e+00
  %5335 = select i1 %5332, float 0.000000e+00, float 1.000000e+00
  %5336 = fmul fast float %5326, 0x3FB3D07220000000
  %5337 = fmul fast float %5327, 0x3FB3D07220000000
  %5338 = fmul fast float %5328, 0x3FB3D07220000000
  %5339 = fadd fast float %5326, 0x3FAC28F5C0000000
  %5340 = fadd fast float %5327, 0x3FAC28F5C0000000
  %5341 = fadd fast float %5328, 0x3FAC28F5C0000000
  %5342 = fmul fast float %5339, 0x3FEE54EDE0000000
  %5343 = fmul fast float %5340, 0x3FEE54EDE0000000
  %5344 = fmul fast float %5341, 0x3FEE54EDE0000000
  %5345 = call float @dx.op.unary.f32(i32 23, float %5342)  ; Log(value)
  %5346 = call float @dx.op.unary.f32(i32 23, float %5343)  ; Log(value)
  %5347 = call float @dx.op.unary.f32(i32 23, float %5344)  ; Log(value)
  %5348 = fmul fast float %5345, 0x4003333340000000
  %5349 = fmul fast float %5346, 0x4003333340000000
  %5350 = fmul fast float %5347, 0x4003333340000000
  %5351 = call float @dx.op.unary.f32(i32 21, float %5348)  ; Exp(value)
  %5352 = call float @dx.op.unary.f32(i32 21, float %5349)  ; Exp(value)
  %5353 = call float @dx.op.unary.f32(i32 21, float %5350)  ; Exp(value)
  %5354 = fsub fast float %5336, %5351
  %5355 = fsub fast float %5337, %5352
  %5356 = fsub fast float %5338, %5353
  %5357 = fmul fast float %5354, %5333
  %5358 = fmul fast float %5355, %5334
  %5359 = fmul fast float %5356, %5335
  %5360 = fadd fast float %5357, %5351
  %5361 = fadd fast float %5358, %5352
  %5362 = fadd fast float %5359, %5353
  %5363 = fmul fast float %1463, %163
  %5364 = fmul fast float %1464, %163
  %5365 = fmul fast float %1465, %163
  %5366 = fmul fast float %2762, %164
  %5367 = fmul fast float %2763, %164
  %5368 = fmul fast float %2764, %164
  %5369 = fadd fast float %5366, %5363
  %5370 = fadd fast float %5367, %5364
  %5371 = fadd fast float %5368, %5365
  %5372 = fmul fast float %4061, %165
  %5373 = fmul fast float %4062, %165
  %5374 = fmul fast float %4063, %165
  %5375 = fadd fast float %5369, %5372
  %5376 = fadd fast float %5370, %5373
  %5377 = fadd fast float %5371, %5374
  %5378 = fmul fast float %5360, %166
  %5379 = fmul fast float %5361, %166
  %5380 = fmul fast float %5362, %166
  %5381 = fadd fast float %5375, %5378
  %5382 = fadd fast float %5376, %5379
  %5383 = fadd fast float %5377, %5380
  %5384 = fcmp fast ogt float %5381, 0x3F69A5C380000000
  %5385 = fcmp fast ogt float %5382, 0x3F69A5C380000000
  %5386 = fcmp fast ogt float %5383, 0x3F69A5C380000000
  %5387 = select i1 %5384, float 0.000000e+00, float 1.000000e+00
  %5388 = select i1 %5385, float 0.000000e+00, float 1.000000e+00
  %5389 = select i1 %5386, float 0.000000e+00, float 1.000000e+00
  %5390 = fmul fast float %5381, 0x4029D70A40000000
  %5391 = fmul fast float %5382, 0x4029D70A40000000
  %5392 = fmul fast float %5383, 0x4029D70A40000000
  %5393 = call float @dx.op.binary.f32(i32 35, float %5381, float 0.000000e+00)  ; FMax(a,b)
  %5394 = call float @dx.op.binary.f32(i32 35, float %5382, float 0.000000e+00)  ; FMax(a,b)
  %5395 = call float @dx.op.binary.f32(i32 35, float %5383, float 0.000000e+00)  ; FMax(a,b)
  %5396 = call float @dx.op.unary.f32(i32 23, float %5393)  ; Log(value)
  %5397 = call float @dx.op.unary.f32(i32 23, float %5394)  ; Log(value)
  %5398 = call float @dx.op.unary.f32(i32 23, float %5395)  ; Log(value)
  %5399 = fmul fast float %5396, 0x3FDAAAAAA0000000
  %5400 = fmul fast float %5397, 0x3FDAAAAAA0000000
  %5401 = fmul fast float %5398, 0x3FDAAAAAA0000000
  %5402 = call float @dx.op.unary.f32(i32 21, float %5399)  ; Exp(value)
  %5403 = call float @dx.op.unary.f32(i32 21, float %5400)  ; Exp(value)
  %5404 = call float @dx.op.unary.f32(i32 21, float %5401)  ; Exp(value)
  %5405 = fmul fast float %5402, 0x3FF0E147A0000000
  %5406 = fmul fast float %5403, 0x3FF0E147A0000000
  %5407 = fmul fast float %5404, 0x3FF0E147A0000000
  %5408 = fadd fast float %5405, 0xBFAC28F5C0000000
  %5409 = fadd fast float %5406, 0xBFAC28F5C0000000
  %5410 = fadd fast float %5407, 0xBFAC28F5C0000000
  %5411 = fsub fast float %5390, %5408
  %5412 = fsub fast float %5391, %5409
  %5413 = fsub fast float %5392, %5410
  %5414 = fmul fast float %5411, %5387
  %5415 = fmul fast float %5412, %5388
  %5416 = fmul fast float %5413, %5389
  %5417 = fadd fast float %5414, %5408
  %5418 = fadd fast float %5415, %5409
  %5419 = fadd fast float %5416, %5410
  %5420 = call float @dx.op.dot4.f32(i32 56, float %1432, float %2731, float %4030, float %5329, float %163, float %164, float %165, float %166)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %5417)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %5418)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %5419)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %5420)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %81)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare i1 @dx.op.isSpecialFloat.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !37, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, !28}
!36 = !{i32 9}
!37 = !{!38, !39}
!38 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
!39 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !40}
!40 = !{i32 3, i32 1}
