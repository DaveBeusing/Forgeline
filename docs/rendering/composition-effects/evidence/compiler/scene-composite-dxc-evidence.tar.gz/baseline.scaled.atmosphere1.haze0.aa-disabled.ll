;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float    yz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: ab18d100cd917abb9a20ad4065af134d
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %40 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %41 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %42 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %43 = extractvalue %dx.types.Dimensions %42, 0
  %44 = extractvalue %dx.types.Dimensions %42, 1
  %45 = uitofp i32 %43 to float
  %46 = uitofp i32 %44 to float
  %47 = fmul fast float %45, %40
  %48 = fmul fast float %46, %41
  %49 = fdiv fast float %47, %3
  %50 = fdiv fast float %48, %4
  %51 = fadd fast float %49, -5.000000e-01
  %52 = fadd fast float %50, -5.000000e-01
  %53 = call float @dx.op.unary.f32(i32 27, float %51)  ; Round_ni(value)
  %54 = call float @dx.op.unary.f32(i32 27, float %52)  ; Round_ni(value)
  %55 = fptosi float %53 to i32
  %56 = fptosi float %54 to i32
  %57 = call float @dx.op.unary.f32(i32 22, float %51)  ; Frc(value)
  %58 = call float @dx.op.unary.f32(i32 22, float %52)  ; Frc(value)
  %59 = add i32 %43, -1
  %60 = add i32 %44, -1
  %61 = call i32 @dx.op.binary.i32(i32 37, i32 %55, i32 0)  ; IMax(a,b)
  %62 = call i32 @dx.op.binary.i32(i32 37, i32 %56, i32 0)  ; IMax(a,b)
  %63 = call i32 @dx.op.binary.i32(i32 38, i32 %61, i32 %59)  ; IMin(a,b)
  %64 = call i32 @dx.op.binary.i32(i32 38, i32 %62, i32 %60)  ; IMin(a,b)
  %65 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %66 = extractvalue %dx.types.ResRet.f32 %65, 0
  %67 = extractvalue %dx.types.ResRet.f32 %65, 1
  %68 = extractvalue %dx.types.ResRet.f32 %65, 2
  %69 = extractvalue %dx.types.ResRet.f32 %65, 3
  %70 = fcmp fast olt float %69, 0.000000e+00
  br i1 %70, label %71, label %73

; <label>:71                                      ; preds = %0
  %72 = fsub fast float -1.000000e+00, %69
  br label %272

; <label>:73                                      ; preds = %0
  %74 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %75 = extractvalue %dx.types.ResRet.f32 %74, 0
  %76 = fcmp fast ogt float %38, 5.000000e-01
  %77 = fcmp fast olt float %75, 1.000000e+00
  %78 = and i1 %76, %77
  br i1 %78, label %79, label %165

; <label>:79                                      ; preds = %73
  %80 = sitofp i32 %63 to float
  %81 = sitofp i32 %64 to float
  %82 = fadd fast float %80, 5.000000e-01
  %83 = fadd fast float %81, 5.000000e-01
  %84 = fdiv fast float %82, %45
  %85 = fdiv fast float %83, %46
  %86 = fmul fast float %84, 2.000000e+00
  %87 = fmul fast float %85, 2.000000e+00
  %88 = fadd fast float %86, -1.000000e+00
  %89 = fsub fast float 1.000000e+00, %87
  %90 = fmul fast float %88, %35
  %91 = call float @dx.op.tertiary.f32(i32 46, float %89, float %31, float %90)  ; FMad(a,b,c)
  %92 = call float @dx.op.tertiary.f32(i32 46, float %75, float %27, float %91)  ; FMad(a,b,c)
  %93 = fadd fast float %92, %23
  %94 = call float @dx.op.unary.f32(i32 6, float %93)  ; FAbs(value)
  %95 = fcmp fast ogt float %94, 0x3EB0C6F7A0000000
  br i1 %95, label %96, label %165

; <label>:96                                      ; preds = %79
  %97 = fmul fast float %88, %34
  %98 = call float @dx.op.tertiary.f32(i32 46, float %89, float %30, float %97)  ; FMad(a,b,c)
  %99 = call float @dx.op.tertiary.f32(i32 46, float %75, float %26, float %98)  ; FMad(a,b,c)
  %100 = fadd fast float %99, %22
  %101 = fmul fast float %88, %33
  %102 = call float @dx.op.tertiary.f32(i32 46, float %89, float %29, float %101)  ; FMad(a,b,c)
  %103 = call float @dx.op.tertiary.f32(i32 46, float %75, float %25, float %102)  ; FMad(a,b,c)
  %104 = fadd fast float %103, %21
  %105 = fmul fast float %88, %32
  %106 = call float @dx.op.tertiary.f32(i32 46, float %89, float %28, float %105)  ; FMad(a,b,c)
  %107 = call float @dx.op.tertiary.f32(i32 46, float %75, float %24, float %106)  ; FMad(a,b,c)
  %108 = fadd fast float %107, %20
  %109 = fdiv fast float %108, %93
  %110 = fdiv fast float %104, %93
  %111 = fdiv fast float %100, %93
  %112 = fsub fast float %109, %17
  %113 = fsub fast float %110, %18
  %114 = fsub fast float %111, %19
  %115 = fmul fast float %112, %112
  %116 = fmul fast float %113, %113
  %117 = fadd fast float %116, %115
  %118 = fmul fast float %114, %114
  %119 = fadd fast float %117, %118
  %120 = call float @dx.op.unary.f32(i32 24, float %119)  ; Sqrt(value)
  %121 = fsub fast float %120, %9
  %122 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %121)  ; FMax(a,b)
  %123 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %123, label %124, label %147

; <label>:124                                     ; preds = %96
  %125 = call float @dx.op.unary.f32(i32 6, float %113)  ; FAbs(value)
  %126 = fmul fast float %125, %11
  %127 = fcmp fast olt float %126, 0x3F50624DE0000000
  br i1 %127, label %128, label %131

; <label>:128                                     ; preds = %124
  %129 = fmul fast float %126, 5.000000e-01
  %130 = fsub fast float 1.000000e+00, %129
  br label %136

; <label>:131                                     ; preds = %124
  %132 = fmul fast float %126, 0xBFF7154760000000
  %133 = call float @dx.op.unary.f32(i32 21, float %132)  ; Exp(value)
  %134 = fsub fast float 1.000000e+00, %133
  %135 = fdiv fast float %134, %126
  br label %136

; <label>:136                                     ; preds = %131, %128
  %137 = phi float [ %130, %128 ], [ %135, %131 ]
  %138 = call float @dx.op.binary.f32(i32 36, float %110, float %18)  ; FMin(a,b)
  %139 = fsub fast float %138, %10
  %140 = fmul fast float %11, %139
  %141 = fsub fast float -0.000000e+00, %140
  %142 = call float @dx.op.binary.f32(i32 35, float %141, float -4.000000e+01)  ; FMax(a,b)
  %143 = call float @dx.op.binary.f32(i32 36, float %142, float 5.000000e+00)  ; FMin(a,b)
  %144 = fmul fast float %143, 0x3FF7154760000000
  %145 = call float @dx.op.unary.f32(i32 21, float %144)  ; Exp(value)
  %146 = fmul fast float %145, %137
  br label %147

; <label>:147                                     ; preds = %136, %96
  %148 = phi float [ %146, %136 ], [ 1.000000e+00, %96 ]
  %149 = fmul fast float %122, %16
  %150 = fmul fast float %149, %148
  %151 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %150)  ; FMin(a,b)
  %152 = fmul fast float %151, 0xBFF7154760000000
  %153 = call float @dx.op.unary.f32(i32 21, float %152)  ; Exp(value)
  %154 = fsub fast float 1.000000e+00, %153
  %155 = call float @dx.op.binary.f32(i32 36, float %12, float %154)  ; FMin(a,b)
  %156 = fsub fast float %13, %66
  %157 = fsub fast float %14, %67
  %158 = fsub fast float %15, %68
  %159 = fmul fast float %155, %156
  %160 = fmul fast float %155, %157
  %161 = fmul fast float %155, %158
  %162 = fadd fast float %159, %66
  %163 = fadd fast float %160, %67
  %164 = fadd fast float %161, %68
  br label %165

; <label>:165                                     ; preds = %147, %79, %73
  %166 = phi float [ %162, %147 ], [ %66, %79 ], [ %66, %73 ]
  %167 = phi float [ %163, %147 ], [ %67, %79 ], [ %67, %73 ]
  %168 = phi float [ %164, %147 ], [ %68, %79 ], [ %68, %73 ]
  %169 = fadd fast float %5, 1.000000e+00
  %170 = fadd fast float %6, 1.000000e+00
  %171 = fsub fast float 1.000000e+00, %5
  %172 = fmul fast float %36, %169
  %173 = fmul fast float %36, %170
  %174 = fmul fast float %36, %171
  %175 = fmul fast float %172, %166
  %176 = fmul fast float %173, %167
  %177 = fmul fast float %174, %168
  %178 = fcmp fast ult float %37, 5.000000e-01
  br i1 %178, label %204, label %179

; <label>:179                                     ; preds = %165
  %180 = fmul fast float %175, 0x4004147AE0000000
  %181 = fmul fast float %176, 0x4004147AE0000000
  %182 = fmul fast float %177, 0x4004147AE0000000
  %183 = fadd fast float %180, 0x3F9EB851E0000000
  %184 = fadd fast float %181, 0x3F9EB851E0000000
  %185 = fadd fast float %182, 0x3F9EB851E0000000
  %186 = fmul fast float %183, %175
  %187 = fmul fast float %184, %176
  %188 = fmul fast float %185, %177
  %189 = fmul fast float %175, 0x400370A3E0000000
  %190 = fmul fast float %176, 0x400370A3E0000000
  %191 = fmul fast float %177, 0x400370A3E0000000
  %192 = fadd fast float %189, 0x3FE2E147A0000000
  %193 = fadd fast float %190, 0x3FE2E147A0000000
  %194 = fadd fast float %191, 0x3FE2E147A0000000
  %195 = fmul fast float %192, %175
  %196 = fmul fast float %193, %176
  %197 = fmul fast float %194, %177
  %198 = fadd fast float %195, 0x3FC1EB8520000000
  %199 = fadd fast float %196, 0x3FC1EB8520000000
  %200 = fadd fast float %197, 0x3FC1EB8520000000
  %201 = fdiv fast float %186, %198
  %202 = fdiv fast float %187, %199
  %203 = fdiv fast float %188, %200
  br label %204

; <label>:204                                     ; preds = %179, %165
  %205 = phi float [ %201, %179 ], [ %175, %165 ]
  %206 = phi float [ %202, %179 ], [ %176, %165 ]
  %207 = phi float [ %203, %179 ], [ %177, %165 ]
  %208 = call float @dx.op.unary.f32(i32 7, float %205)  ; Saturate(value)
  %209 = call float @dx.op.unary.f32(i32 7, float %206)  ; Saturate(value)
  %210 = call float @dx.op.unary.f32(i32 7, float %207)  ; Saturate(value)
  %211 = call float @dx.op.dot3.f32(i32 55, float %208, float %209, float %210, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %212 = fsub fast float %208, %211
  %213 = fsub fast float %209, %211
  %214 = fsub fast float %210, %211
  %215 = fmul fast float %212, %8
  %216 = fmul fast float %213, %8
  %217 = fmul fast float %214, %8
  %218 = fadd fast float %215, %211
  %219 = fadd fast float %216, %211
  %220 = fadd fast float %217, %211
  %221 = call float @dx.op.unary.f32(i32 7, float %218)  ; Saturate(value)
  %222 = call float @dx.op.unary.f32(i32 7, float %219)  ; Saturate(value)
  %223 = call float @dx.op.unary.f32(i32 7, float %220)  ; Saturate(value)
  %224 = fadd fast float %221, 0xBFC70A3D80000000
  %225 = fadd fast float %222, 0xBFC70A3D80000000
  %226 = fadd fast float %223, 0xBFC70A3D80000000
  %227 = fmul fast float %224, %7
  %228 = fmul fast float %225, %7
  %229 = fmul fast float %226, %7
  %230 = fadd fast float %227, 0x3FC70A3D80000000
  %231 = fadd fast float %228, 0x3FC70A3D80000000
  %232 = fadd fast float %229, 0x3FC70A3D80000000
  %233 = call float @dx.op.unary.f32(i32 7, float %230)  ; Saturate(value)
  %234 = call float @dx.op.unary.f32(i32 7, float %231)  ; Saturate(value)
  %235 = call float @dx.op.unary.f32(i32 7, float %232)  ; Saturate(value)
  %236 = fcmp fast ogt float %233, 0x3F69A5C380000000
  %237 = fcmp fast ogt float %234, 0x3F69A5C380000000
  %238 = fcmp fast ogt float %235, 0x3F69A5C380000000
  %239 = select i1 %236, float 0.000000e+00, float 1.000000e+00
  %240 = select i1 %237, float 0.000000e+00, float 1.000000e+00
  %241 = select i1 %238, float 0.000000e+00, float 1.000000e+00
  %242 = fmul fast float %233, 0x4029D70A40000000
  %243 = fmul fast float %234, 0x4029D70A40000000
  %244 = fmul fast float %235, 0x4029D70A40000000
  %245 = call float @dx.op.binary.f32(i32 35, float %233, float 0.000000e+00)  ; FMax(a,b)
  %246 = call float @dx.op.binary.f32(i32 35, float %234, float 0.000000e+00)  ; FMax(a,b)
  %247 = call float @dx.op.binary.f32(i32 35, float %235, float 0.000000e+00)  ; FMax(a,b)
  %248 = call float @dx.op.unary.f32(i32 23, float %245)  ; Log(value)
  %249 = call float @dx.op.unary.f32(i32 23, float %246)  ; Log(value)
  %250 = call float @dx.op.unary.f32(i32 23, float %247)  ; Log(value)
  %251 = fmul fast float %248, 0x3FDAAAAAA0000000
  %252 = fmul fast float %249, 0x3FDAAAAAA0000000
  %253 = fmul fast float %250, 0x3FDAAAAAA0000000
  %254 = call float @dx.op.unary.f32(i32 21, float %251)  ; Exp(value)
  %255 = call float @dx.op.unary.f32(i32 21, float %252)  ; Exp(value)
  %256 = call float @dx.op.unary.f32(i32 21, float %253)  ; Exp(value)
  %257 = fmul fast float %254, 0x3FF0E147A0000000
  %258 = fmul fast float %255, 0x3FF0E147A0000000
  %259 = fmul fast float %256, 0x3FF0E147A0000000
  %260 = fadd fast float %257, 0xBFAC28F5C0000000
  %261 = fadd fast float %258, 0xBFAC28F5C0000000
  %262 = fadd fast float %259, 0xBFAC28F5C0000000
  %263 = fsub fast float %242, %260
  %264 = fsub fast float %243, %261
  %265 = fsub fast float %244, %262
  %266 = fmul fast float %263, %239
  %267 = fmul fast float %264, %240
  %268 = fmul fast float %265, %241
  %269 = fadd fast float %266, %260
  %270 = fadd fast float %267, %261
  %271 = fadd fast float %268, %262
  br label %272

; <label>:272                                     ; preds = %204, %71
  %273 = phi float [ %66, %71 ], [ %269, %204 ]
  %274 = phi float [ %67, %71 ], [ %270, %204 ]
  %275 = phi float [ %68, %71 ], [ %271, %204 ]
  %276 = phi float [ %72, %71 ], [ %69, %204 ]
  %277 = add i32 %55, 1
  %278 = call i32 @dx.op.binary.i32(i32 37, i32 %277, i32 0)  ; IMax(a,b)
  %279 = call i32 @dx.op.binary.i32(i32 38, i32 %278, i32 %59)  ; IMin(a,b)
  %280 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %279, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %281 = extractvalue %dx.types.ResRet.f32 %280, 0
  %282 = extractvalue %dx.types.ResRet.f32 %280, 1
  %283 = extractvalue %dx.types.ResRet.f32 %280, 2
  %284 = extractvalue %dx.types.ResRet.f32 %280, 3
  %285 = fcmp fast olt float %284, 0.000000e+00
  br i1 %285, label %286, label %288

; <label>:286                                     ; preds = %272
  %287 = fsub fast float -1.000000e+00, %284
  br label %487

; <label>:288                                     ; preds = %272
  %289 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %279, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %290 = extractvalue %dx.types.ResRet.f32 %289, 0
  %291 = fcmp fast ogt float %38, 5.000000e-01
  %292 = fcmp fast olt float %290, 1.000000e+00
  %293 = and i1 %291, %292
  br i1 %293, label %294, label %380

; <label>:294                                     ; preds = %288
  %295 = sitofp i32 %279 to float
  %296 = sitofp i32 %64 to float
  %297 = fadd fast float %295, 5.000000e-01
  %298 = fadd fast float %296, 5.000000e-01
  %299 = fdiv fast float %297, %45
  %300 = fdiv fast float %298, %46
  %301 = fmul fast float %299, 2.000000e+00
  %302 = fmul fast float %300, 2.000000e+00
  %303 = fadd fast float %301, -1.000000e+00
  %304 = fsub fast float 1.000000e+00, %302
  %305 = fmul fast float %303, %35
  %306 = call float @dx.op.tertiary.f32(i32 46, float %304, float %31, float %305)  ; FMad(a,b,c)
  %307 = call float @dx.op.tertiary.f32(i32 46, float %290, float %27, float %306)  ; FMad(a,b,c)
  %308 = fadd fast float %307, %23
  %309 = call float @dx.op.unary.f32(i32 6, float %308)  ; FAbs(value)
  %310 = fcmp fast ogt float %309, 0x3EB0C6F7A0000000
  br i1 %310, label %311, label %380

; <label>:311                                     ; preds = %294
  %312 = fmul fast float %303, %34
  %313 = call float @dx.op.tertiary.f32(i32 46, float %304, float %30, float %312)  ; FMad(a,b,c)
  %314 = call float @dx.op.tertiary.f32(i32 46, float %290, float %26, float %313)  ; FMad(a,b,c)
  %315 = fadd fast float %314, %22
  %316 = fmul fast float %303, %33
  %317 = call float @dx.op.tertiary.f32(i32 46, float %304, float %29, float %316)  ; FMad(a,b,c)
  %318 = call float @dx.op.tertiary.f32(i32 46, float %290, float %25, float %317)  ; FMad(a,b,c)
  %319 = fadd fast float %318, %21
  %320 = fmul fast float %303, %32
  %321 = call float @dx.op.tertiary.f32(i32 46, float %304, float %28, float %320)  ; FMad(a,b,c)
  %322 = call float @dx.op.tertiary.f32(i32 46, float %290, float %24, float %321)  ; FMad(a,b,c)
  %323 = fadd fast float %322, %20
  %324 = fdiv fast float %323, %308
  %325 = fdiv fast float %319, %308
  %326 = fdiv fast float %315, %308
  %327 = fsub fast float %324, %17
  %328 = fsub fast float %325, %18
  %329 = fsub fast float %326, %19
  %330 = fmul fast float %327, %327
  %331 = fmul fast float %328, %328
  %332 = fadd fast float %331, %330
  %333 = fmul fast float %329, %329
  %334 = fadd fast float %332, %333
  %335 = call float @dx.op.unary.f32(i32 24, float %334)  ; Sqrt(value)
  %336 = fsub fast float %335, %9
  %337 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %336)  ; FMax(a,b)
  %338 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %338, label %339, label %362

; <label>:339                                     ; preds = %311
  %340 = call float @dx.op.unary.f32(i32 6, float %328)  ; FAbs(value)
  %341 = fmul fast float %340, %11
  %342 = fcmp fast olt float %341, 0x3F50624DE0000000
  br i1 %342, label %343, label %346

; <label>:343                                     ; preds = %339
  %344 = fmul fast float %341, 5.000000e-01
  %345 = fsub fast float 1.000000e+00, %344
  br label %351

; <label>:346                                     ; preds = %339
  %347 = fmul fast float %341, 0xBFF7154760000000
  %348 = call float @dx.op.unary.f32(i32 21, float %347)  ; Exp(value)
  %349 = fsub fast float 1.000000e+00, %348
  %350 = fdiv fast float %349, %341
  br label %351

; <label>:351                                     ; preds = %346, %343
  %352 = phi float [ %345, %343 ], [ %350, %346 ]
  %353 = call float @dx.op.binary.f32(i32 36, float %325, float %18)  ; FMin(a,b)
  %354 = fsub fast float %353, %10
  %355 = fmul fast float %11, %354
  %356 = fsub fast float -0.000000e+00, %355
  %357 = call float @dx.op.binary.f32(i32 35, float %356, float -4.000000e+01)  ; FMax(a,b)
  %358 = call float @dx.op.binary.f32(i32 36, float %357, float 5.000000e+00)  ; FMin(a,b)
  %359 = fmul fast float %358, 0x3FF7154760000000
  %360 = call float @dx.op.unary.f32(i32 21, float %359)  ; Exp(value)
  %361 = fmul fast float %360, %352
  br label %362

; <label>:362                                     ; preds = %351, %311
  %363 = phi float [ %361, %351 ], [ 1.000000e+00, %311 ]
  %364 = fmul fast float %337, %16
  %365 = fmul fast float %364, %363
  %366 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %365)  ; FMin(a,b)
  %367 = fmul fast float %366, 0xBFF7154760000000
  %368 = call float @dx.op.unary.f32(i32 21, float %367)  ; Exp(value)
  %369 = fsub fast float 1.000000e+00, %368
  %370 = call float @dx.op.binary.f32(i32 36, float %12, float %369)  ; FMin(a,b)
  %371 = fsub fast float %13, %281
  %372 = fsub fast float %14, %282
  %373 = fsub fast float %15, %283
  %374 = fmul fast float %370, %371
  %375 = fmul fast float %370, %372
  %376 = fmul fast float %370, %373
  %377 = fadd fast float %374, %281
  %378 = fadd fast float %375, %282
  %379 = fadd fast float %376, %283
  br label %380

; <label>:380                                     ; preds = %362, %294, %288
  %381 = phi float [ %377, %362 ], [ %281, %294 ], [ %281, %288 ]
  %382 = phi float [ %378, %362 ], [ %282, %294 ], [ %282, %288 ]
  %383 = phi float [ %379, %362 ], [ %283, %294 ], [ %283, %288 ]
  %384 = fadd fast float %5, 1.000000e+00
  %385 = fadd fast float %6, 1.000000e+00
  %386 = fsub fast float 1.000000e+00, %5
  %387 = fmul fast float %36, %384
  %388 = fmul fast float %36, %385
  %389 = fmul fast float %36, %386
  %390 = fmul fast float %387, %381
  %391 = fmul fast float %388, %382
  %392 = fmul fast float %389, %383
  %393 = fcmp fast ult float %37, 5.000000e-01
  br i1 %393, label %419, label %394

; <label>:394                                     ; preds = %380
  %395 = fmul fast float %390, 0x4004147AE0000000
  %396 = fmul fast float %391, 0x4004147AE0000000
  %397 = fmul fast float %392, 0x4004147AE0000000
  %398 = fadd fast float %395, 0x3F9EB851E0000000
  %399 = fadd fast float %396, 0x3F9EB851E0000000
  %400 = fadd fast float %397, 0x3F9EB851E0000000
  %401 = fmul fast float %398, %390
  %402 = fmul fast float %399, %391
  %403 = fmul fast float %400, %392
  %404 = fmul fast float %390, 0x400370A3E0000000
  %405 = fmul fast float %391, 0x400370A3E0000000
  %406 = fmul fast float %392, 0x400370A3E0000000
  %407 = fadd fast float %404, 0x3FE2E147A0000000
  %408 = fadd fast float %405, 0x3FE2E147A0000000
  %409 = fadd fast float %406, 0x3FE2E147A0000000
  %410 = fmul fast float %407, %390
  %411 = fmul fast float %408, %391
  %412 = fmul fast float %409, %392
  %413 = fadd fast float %410, 0x3FC1EB8520000000
  %414 = fadd fast float %411, 0x3FC1EB8520000000
  %415 = fadd fast float %412, 0x3FC1EB8520000000
  %416 = fdiv fast float %401, %413
  %417 = fdiv fast float %402, %414
  %418 = fdiv fast float %403, %415
  br label %419

; <label>:419                                     ; preds = %394, %380
  %420 = phi float [ %416, %394 ], [ %390, %380 ]
  %421 = phi float [ %417, %394 ], [ %391, %380 ]
  %422 = phi float [ %418, %394 ], [ %392, %380 ]
  %423 = call float @dx.op.unary.f32(i32 7, float %420)  ; Saturate(value)
  %424 = call float @dx.op.unary.f32(i32 7, float %421)  ; Saturate(value)
  %425 = call float @dx.op.unary.f32(i32 7, float %422)  ; Saturate(value)
  %426 = call float @dx.op.dot3.f32(i32 55, float %423, float %424, float %425, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %427 = fsub fast float %423, %426
  %428 = fsub fast float %424, %426
  %429 = fsub fast float %425, %426
  %430 = fmul fast float %427, %8
  %431 = fmul fast float %428, %8
  %432 = fmul fast float %429, %8
  %433 = fadd fast float %430, %426
  %434 = fadd fast float %431, %426
  %435 = fadd fast float %432, %426
  %436 = call float @dx.op.unary.f32(i32 7, float %433)  ; Saturate(value)
  %437 = call float @dx.op.unary.f32(i32 7, float %434)  ; Saturate(value)
  %438 = call float @dx.op.unary.f32(i32 7, float %435)  ; Saturate(value)
  %439 = fadd fast float %436, 0xBFC70A3D80000000
  %440 = fadd fast float %437, 0xBFC70A3D80000000
  %441 = fadd fast float %438, 0xBFC70A3D80000000
  %442 = fmul fast float %439, %7
  %443 = fmul fast float %440, %7
  %444 = fmul fast float %441, %7
  %445 = fadd fast float %442, 0x3FC70A3D80000000
  %446 = fadd fast float %443, 0x3FC70A3D80000000
  %447 = fadd fast float %444, 0x3FC70A3D80000000
  %448 = call float @dx.op.unary.f32(i32 7, float %445)  ; Saturate(value)
  %449 = call float @dx.op.unary.f32(i32 7, float %446)  ; Saturate(value)
  %450 = call float @dx.op.unary.f32(i32 7, float %447)  ; Saturate(value)
  %451 = fcmp fast ogt float %448, 0x3F69A5C380000000
  %452 = fcmp fast ogt float %449, 0x3F69A5C380000000
  %453 = fcmp fast ogt float %450, 0x3F69A5C380000000
  %454 = select i1 %451, float 0.000000e+00, float 1.000000e+00
  %455 = select i1 %452, float 0.000000e+00, float 1.000000e+00
  %456 = select i1 %453, float 0.000000e+00, float 1.000000e+00
  %457 = fmul fast float %448, 0x4029D70A40000000
  %458 = fmul fast float %449, 0x4029D70A40000000
  %459 = fmul fast float %450, 0x4029D70A40000000
  %460 = call float @dx.op.binary.f32(i32 35, float %448, float 0.000000e+00)  ; FMax(a,b)
  %461 = call float @dx.op.binary.f32(i32 35, float %449, float 0.000000e+00)  ; FMax(a,b)
  %462 = call float @dx.op.binary.f32(i32 35, float %450, float 0.000000e+00)  ; FMax(a,b)
  %463 = call float @dx.op.unary.f32(i32 23, float %460)  ; Log(value)
  %464 = call float @dx.op.unary.f32(i32 23, float %461)  ; Log(value)
  %465 = call float @dx.op.unary.f32(i32 23, float %462)  ; Log(value)
  %466 = fmul fast float %463, 0x3FDAAAAAA0000000
  %467 = fmul fast float %464, 0x3FDAAAAAA0000000
  %468 = fmul fast float %465, 0x3FDAAAAAA0000000
  %469 = call float @dx.op.unary.f32(i32 21, float %466)  ; Exp(value)
  %470 = call float @dx.op.unary.f32(i32 21, float %467)  ; Exp(value)
  %471 = call float @dx.op.unary.f32(i32 21, float %468)  ; Exp(value)
  %472 = fmul fast float %469, 0x3FF0E147A0000000
  %473 = fmul fast float %470, 0x3FF0E147A0000000
  %474 = fmul fast float %471, 0x3FF0E147A0000000
  %475 = fadd fast float %472, 0xBFAC28F5C0000000
  %476 = fadd fast float %473, 0xBFAC28F5C0000000
  %477 = fadd fast float %474, 0xBFAC28F5C0000000
  %478 = fsub fast float %457, %475
  %479 = fsub fast float %458, %476
  %480 = fsub fast float %459, %477
  %481 = fmul fast float %478, %454
  %482 = fmul fast float %479, %455
  %483 = fmul fast float %480, %456
  %484 = fadd fast float %481, %475
  %485 = fadd fast float %482, %476
  %486 = fadd fast float %483, %477
  br label %487

; <label>:487                                     ; preds = %419, %286
  %488 = phi float [ %281, %286 ], [ %484, %419 ]
  %489 = phi float [ %282, %286 ], [ %485, %419 ]
  %490 = phi float [ %283, %286 ], [ %486, %419 ]
  %491 = phi float [ %287, %286 ], [ %284, %419 ]
  %492 = add i32 %56, 1
  %493 = call i32 @dx.op.binary.i32(i32 37, i32 %492, i32 0)  ; IMax(a,b)
  %494 = call i32 @dx.op.binary.i32(i32 38, i32 %493, i32 %60)  ; IMin(a,b)
  %495 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %63, i32 %494, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %496 = extractvalue %dx.types.ResRet.f32 %495, 0
  %497 = extractvalue %dx.types.ResRet.f32 %495, 1
  %498 = extractvalue %dx.types.ResRet.f32 %495, 2
  %499 = extractvalue %dx.types.ResRet.f32 %495, 3
  %500 = fcmp fast olt float %499, 0.000000e+00
  br i1 %500, label %501, label %503

; <label>:501                                     ; preds = %487
  %502 = fsub fast float -1.000000e+00, %499
  br label %702

; <label>:503                                     ; preds = %487
  %504 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %494, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %505 = extractvalue %dx.types.ResRet.f32 %504, 0
  %506 = fcmp fast ogt float %38, 5.000000e-01
  %507 = fcmp fast olt float %505, 1.000000e+00
  %508 = and i1 %506, %507
  br i1 %508, label %509, label %595

; <label>:509                                     ; preds = %503
  %510 = sitofp i32 %63 to float
  %511 = sitofp i32 %494 to float
  %512 = fadd fast float %510, 5.000000e-01
  %513 = fadd fast float %511, 5.000000e-01
  %514 = fdiv fast float %512, %45
  %515 = fdiv fast float %513, %46
  %516 = fmul fast float %514, 2.000000e+00
  %517 = fmul fast float %515, 2.000000e+00
  %518 = fadd fast float %516, -1.000000e+00
  %519 = fsub fast float 1.000000e+00, %517
  %520 = fmul fast float %518, %35
  %521 = call float @dx.op.tertiary.f32(i32 46, float %519, float %31, float %520)  ; FMad(a,b,c)
  %522 = call float @dx.op.tertiary.f32(i32 46, float %505, float %27, float %521)  ; FMad(a,b,c)
  %523 = fadd fast float %522, %23
  %524 = call float @dx.op.unary.f32(i32 6, float %523)  ; FAbs(value)
  %525 = fcmp fast ogt float %524, 0x3EB0C6F7A0000000
  br i1 %525, label %526, label %595

; <label>:526                                     ; preds = %509
  %527 = fmul fast float %518, %34
  %528 = call float @dx.op.tertiary.f32(i32 46, float %519, float %30, float %527)  ; FMad(a,b,c)
  %529 = call float @dx.op.tertiary.f32(i32 46, float %505, float %26, float %528)  ; FMad(a,b,c)
  %530 = fadd fast float %529, %22
  %531 = fmul fast float %518, %33
  %532 = call float @dx.op.tertiary.f32(i32 46, float %519, float %29, float %531)  ; FMad(a,b,c)
  %533 = call float @dx.op.tertiary.f32(i32 46, float %505, float %25, float %532)  ; FMad(a,b,c)
  %534 = fadd fast float %533, %21
  %535 = fmul fast float %518, %32
  %536 = call float @dx.op.tertiary.f32(i32 46, float %519, float %28, float %535)  ; FMad(a,b,c)
  %537 = call float @dx.op.tertiary.f32(i32 46, float %505, float %24, float %536)  ; FMad(a,b,c)
  %538 = fadd fast float %537, %20
  %539 = fdiv fast float %538, %523
  %540 = fdiv fast float %534, %523
  %541 = fdiv fast float %530, %523
  %542 = fsub fast float %539, %17
  %543 = fsub fast float %540, %18
  %544 = fsub fast float %541, %19
  %545 = fmul fast float %542, %542
  %546 = fmul fast float %543, %543
  %547 = fadd fast float %546, %545
  %548 = fmul fast float %544, %544
  %549 = fadd fast float %547, %548
  %550 = call float @dx.op.unary.f32(i32 24, float %549)  ; Sqrt(value)
  %551 = fsub fast float %550, %9
  %552 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %551)  ; FMax(a,b)
  %553 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %553, label %554, label %577

; <label>:554                                     ; preds = %526
  %555 = call float @dx.op.unary.f32(i32 6, float %543)  ; FAbs(value)
  %556 = fmul fast float %555, %11
  %557 = fcmp fast olt float %556, 0x3F50624DE0000000
  br i1 %557, label %558, label %561

; <label>:558                                     ; preds = %554
  %559 = fmul fast float %556, 5.000000e-01
  %560 = fsub fast float 1.000000e+00, %559
  br label %566

; <label>:561                                     ; preds = %554
  %562 = fmul fast float %556, 0xBFF7154760000000
  %563 = call float @dx.op.unary.f32(i32 21, float %562)  ; Exp(value)
  %564 = fsub fast float 1.000000e+00, %563
  %565 = fdiv fast float %564, %556
  br label %566

; <label>:566                                     ; preds = %561, %558
  %567 = phi float [ %560, %558 ], [ %565, %561 ]
  %568 = call float @dx.op.binary.f32(i32 36, float %540, float %18)  ; FMin(a,b)
  %569 = fsub fast float %568, %10
  %570 = fmul fast float %11, %569
  %571 = fsub fast float -0.000000e+00, %570
  %572 = call float @dx.op.binary.f32(i32 35, float %571, float -4.000000e+01)  ; FMax(a,b)
  %573 = call float @dx.op.binary.f32(i32 36, float %572, float 5.000000e+00)  ; FMin(a,b)
  %574 = fmul fast float %573, 0x3FF7154760000000
  %575 = call float @dx.op.unary.f32(i32 21, float %574)  ; Exp(value)
  %576 = fmul fast float %575, %567
  br label %577

; <label>:577                                     ; preds = %566, %526
  %578 = phi float [ %576, %566 ], [ 1.000000e+00, %526 ]
  %579 = fmul fast float %552, %16
  %580 = fmul fast float %579, %578
  %581 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %580)  ; FMin(a,b)
  %582 = fmul fast float %581, 0xBFF7154760000000
  %583 = call float @dx.op.unary.f32(i32 21, float %582)  ; Exp(value)
  %584 = fsub fast float 1.000000e+00, %583
  %585 = call float @dx.op.binary.f32(i32 36, float %12, float %584)  ; FMin(a,b)
  %586 = fsub fast float %13, %496
  %587 = fsub fast float %14, %497
  %588 = fsub fast float %15, %498
  %589 = fmul fast float %585, %586
  %590 = fmul fast float %585, %587
  %591 = fmul fast float %585, %588
  %592 = fadd fast float %589, %496
  %593 = fadd fast float %590, %497
  %594 = fadd fast float %591, %498
  br label %595

; <label>:595                                     ; preds = %577, %509, %503
  %596 = phi float [ %592, %577 ], [ %496, %509 ], [ %496, %503 ]
  %597 = phi float [ %593, %577 ], [ %497, %509 ], [ %497, %503 ]
  %598 = phi float [ %594, %577 ], [ %498, %509 ], [ %498, %503 ]
  %599 = fadd fast float %5, 1.000000e+00
  %600 = fadd fast float %6, 1.000000e+00
  %601 = fsub fast float 1.000000e+00, %5
  %602 = fmul fast float %36, %599
  %603 = fmul fast float %36, %600
  %604 = fmul fast float %36, %601
  %605 = fmul fast float %602, %596
  %606 = fmul fast float %603, %597
  %607 = fmul fast float %604, %598
  %608 = fcmp fast ult float %37, 5.000000e-01
  br i1 %608, label %634, label %609

; <label>:609                                     ; preds = %595
  %610 = fmul fast float %605, 0x4004147AE0000000
  %611 = fmul fast float %606, 0x4004147AE0000000
  %612 = fmul fast float %607, 0x4004147AE0000000
  %613 = fadd fast float %610, 0x3F9EB851E0000000
  %614 = fadd fast float %611, 0x3F9EB851E0000000
  %615 = fadd fast float %612, 0x3F9EB851E0000000
  %616 = fmul fast float %613, %605
  %617 = fmul fast float %614, %606
  %618 = fmul fast float %615, %607
  %619 = fmul fast float %605, 0x400370A3E0000000
  %620 = fmul fast float %606, 0x400370A3E0000000
  %621 = fmul fast float %607, 0x400370A3E0000000
  %622 = fadd fast float %619, 0x3FE2E147A0000000
  %623 = fadd fast float %620, 0x3FE2E147A0000000
  %624 = fadd fast float %621, 0x3FE2E147A0000000
  %625 = fmul fast float %622, %605
  %626 = fmul fast float %623, %606
  %627 = fmul fast float %624, %607
  %628 = fadd fast float %625, 0x3FC1EB8520000000
  %629 = fadd fast float %626, 0x3FC1EB8520000000
  %630 = fadd fast float %627, 0x3FC1EB8520000000
  %631 = fdiv fast float %616, %628
  %632 = fdiv fast float %617, %629
  %633 = fdiv fast float %618, %630
  br label %634

; <label>:634                                     ; preds = %609, %595
  %635 = phi float [ %631, %609 ], [ %605, %595 ]
  %636 = phi float [ %632, %609 ], [ %606, %595 ]
  %637 = phi float [ %633, %609 ], [ %607, %595 ]
  %638 = call float @dx.op.unary.f32(i32 7, float %635)  ; Saturate(value)
  %639 = call float @dx.op.unary.f32(i32 7, float %636)  ; Saturate(value)
  %640 = call float @dx.op.unary.f32(i32 7, float %637)  ; Saturate(value)
  %641 = call float @dx.op.dot3.f32(i32 55, float %638, float %639, float %640, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %642 = fsub fast float %638, %641
  %643 = fsub fast float %639, %641
  %644 = fsub fast float %640, %641
  %645 = fmul fast float %642, %8
  %646 = fmul fast float %643, %8
  %647 = fmul fast float %644, %8
  %648 = fadd fast float %645, %641
  %649 = fadd fast float %646, %641
  %650 = fadd fast float %647, %641
  %651 = call float @dx.op.unary.f32(i32 7, float %648)  ; Saturate(value)
  %652 = call float @dx.op.unary.f32(i32 7, float %649)  ; Saturate(value)
  %653 = call float @dx.op.unary.f32(i32 7, float %650)  ; Saturate(value)
  %654 = fadd fast float %651, 0xBFC70A3D80000000
  %655 = fadd fast float %652, 0xBFC70A3D80000000
  %656 = fadd fast float %653, 0xBFC70A3D80000000
  %657 = fmul fast float %654, %7
  %658 = fmul fast float %655, %7
  %659 = fmul fast float %656, %7
  %660 = fadd fast float %657, 0x3FC70A3D80000000
  %661 = fadd fast float %658, 0x3FC70A3D80000000
  %662 = fadd fast float %659, 0x3FC70A3D80000000
  %663 = call float @dx.op.unary.f32(i32 7, float %660)  ; Saturate(value)
  %664 = call float @dx.op.unary.f32(i32 7, float %661)  ; Saturate(value)
  %665 = call float @dx.op.unary.f32(i32 7, float %662)  ; Saturate(value)
  %666 = fcmp fast ogt float %663, 0x3F69A5C380000000
  %667 = fcmp fast ogt float %664, 0x3F69A5C380000000
  %668 = fcmp fast ogt float %665, 0x3F69A5C380000000
  %669 = select i1 %666, float 0.000000e+00, float 1.000000e+00
  %670 = select i1 %667, float 0.000000e+00, float 1.000000e+00
  %671 = select i1 %668, float 0.000000e+00, float 1.000000e+00
  %672 = fmul fast float %663, 0x4029D70A40000000
  %673 = fmul fast float %664, 0x4029D70A40000000
  %674 = fmul fast float %665, 0x4029D70A40000000
  %675 = call float @dx.op.binary.f32(i32 35, float %663, float 0.000000e+00)  ; FMax(a,b)
  %676 = call float @dx.op.binary.f32(i32 35, float %664, float 0.000000e+00)  ; FMax(a,b)
  %677 = call float @dx.op.binary.f32(i32 35, float %665, float 0.000000e+00)  ; FMax(a,b)
  %678 = call float @dx.op.unary.f32(i32 23, float %675)  ; Log(value)
  %679 = call float @dx.op.unary.f32(i32 23, float %676)  ; Log(value)
  %680 = call float @dx.op.unary.f32(i32 23, float %677)  ; Log(value)
  %681 = fmul fast float %678, 0x3FDAAAAAA0000000
  %682 = fmul fast float %679, 0x3FDAAAAAA0000000
  %683 = fmul fast float %680, 0x3FDAAAAAA0000000
  %684 = call float @dx.op.unary.f32(i32 21, float %681)  ; Exp(value)
  %685 = call float @dx.op.unary.f32(i32 21, float %682)  ; Exp(value)
  %686 = call float @dx.op.unary.f32(i32 21, float %683)  ; Exp(value)
  %687 = fmul fast float %684, 0x3FF0E147A0000000
  %688 = fmul fast float %685, 0x3FF0E147A0000000
  %689 = fmul fast float %686, 0x3FF0E147A0000000
  %690 = fadd fast float %687, 0xBFAC28F5C0000000
  %691 = fadd fast float %688, 0xBFAC28F5C0000000
  %692 = fadd fast float %689, 0xBFAC28F5C0000000
  %693 = fsub fast float %672, %690
  %694 = fsub fast float %673, %691
  %695 = fsub fast float %674, %692
  %696 = fmul fast float %693, %669
  %697 = fmul fast float %694, %670
  %698 = fmul fast float %695, %671
  %699 = fadd fast float %696, %690
  %700 = fadd fast float %697, %691
  %701 = fadd fast float %698, %692
  br label %702

; <label>:702                                     ; preds = %634, %501
  %703 = phi float [ %496, %501 ], [ %699, %634 ]
  %704 = phi float [ %497, %501 ], [ %700, %634 ]
  %705 = phi float [ %498, %501 ], [ %701, %634 ]
  %706 = phi float [ %502, %501 ], [ %499, %634 ]
  %707 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %279, i32 %494, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %708 = extractvalue %dx.types.ResRet.f32 %707, 0
  %709 = extractvalue %dx.types.ResRet.f32 %707, 1
  %710 = extractvalue %dx.types.ResRet.f32 %707, 2
  %711 = extractvalue %dx.types.ResRet.f32 %707, 3
  %712 = fcmp fast olt float %711, 0.000000e+00
  br i1 %712, label %713, label %715

; <label>:713                                     ; preds = %702
  %714 = fsub fast float -1.000000e+00, %711
  br label %914

; <label>:715                                     ; preds = %702
  %716 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %279, i32 %494, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %717 = extractvalue %dx.types.ResRet.f32 %716, 0
  %718 = fcmp fast ogt float %38, 5.000000e-01
  %719 = fcmp fast olt float %717, 1.000000e+00
  %720 = and i1 %718, %719
  br i1 %720, label %721, label %807

; <label>:721                                     ; preds = %715
  %722 = sitofp i32 %279 to float
  %723 = sitofp i32 %494 to float
  %724 = fadd fast float %722, 5.000000e-01
  %725 = fadd fast float %723, 5.000000e-01
  %726 = fdiv fast float %724, %45
  %727 = fdiv fast float %725, %46
  %728 = fmul fast float %726, 2.000000e+00
  %729 = fmul fast float %727, 2.000000e+00
  %730 = fadd fast float %728, -1.000000e+00
  %731 = fsub fast float 1.000000e+00, %729
  %732 = fmul fast float %730, %35
  %733 = call float @dx.op.tertiary.f32(i32 46, float %731, float %31, float %732)  ; FMad(a,b,c)
  %734 = call float @dx.op.tertiary.f32(i32 46, float %717, float %27, float %733)  ; FMad(a,b,c)
  %735 = fadd fast float %734, %23
  %736 = call float @dx.op.unary.f32(i32 6, float %735)  ; FAbs(value)
  %737 = fcmp fast ogt float %736, 0x3EB0C6F7A0000000
  br i1 %737, label %738, label %807

; <label>:738                                     ; preds = %721
  %739 = fmul fast float %730, %34
  %740 = call float @dx.op.tertiary.f32(i32 46, float %731, float %30, float %739)  ; FMad(a,b,c)
  %741 = call float @dx.op.tertiary.f32(i32 46, float %717, float %26, float %740)  ; FMad(a,b,c)
  %742 = fadd fast float %741, %22
  %743 = fmul fast float %730, %33
  %744 = call float @dx.op.tertiary.f32(i32 46, float %731, float %29, float %743)  ; FMad(a,b,c)
  %745 = call float @dx.op.tertiary.f32(i32 46, float %717, float %25, float %744)  ; FMad(a,b,c)
  %746 = fadd fast float %745, %21
  %747 = fmul fast float %730, %32
  %748 = call float @dx.op.tertiary.f32(i32 46, float %731, float %28, float %747)  ; FMad(a,b,c)
  %749 = call float @dx.op.tertiary.f32(i32 46, float %717, float %24, float %748)  ; FMad(a,b,c)
  %750 = fadd fast float %749, %20
  %751 = fdiv fast float %750, %735
  %752 = fdiv fast float %746, %735
  %753 = fdiv fast float %742, %735
  %754 = fsub fast float %751, %17
  %755 = fsub fast float %752, %18
  %756 = fsub fast float %753, %19
  %757 = fmul fast float %754, %754
  %758 = fmul fast float %755, %755
  %759 = fadd fast float %758, %757
  %760 = fmul fast float %756, %756
  %761 = fadd fast float %759, %760
  %762 = call float @dx.op.unary.f32(i32 24, float %761)  ; Sqrt(value)
  %763 = fsub fast float %762, %9
  %764 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %763)  ; FMax(a,b)
  %765 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %765, label %766, label %789

; <label>:766                                     ; preds = %738
  %767 = call float @dx.op.unary.f32(i32 6, float %755)  ; FAbs(value)
  %768 = fmul fast float %767, %11
  %769 = fcmp fast olt float %768, 0x3F50624DE0000000
  br i1 %769, label %770, label %773

; <label>:770                                     ; preds = %766
  %771 = fmul fast float %768, 5.000000e-01
  %772 = fsub fast float 1.000000e+00, %771
  br label %778

; <label>:773                                     ; preds = %766
  %774 = fmul fast float %768, 0xBFF7154760000000
  %775 = call float @dx.op.unary.f32(i32 21, float %774)  ; Exp(value)
  %776 = fsub fast float 1.000000e+00, %775
  %777 = fdiv fast float %776, %768
  br label %778

; <label>:778                                     ; preds = %773, %770
  %779 = phi float [ %772, %770 ], [ %777, %773 ]
  %780 = call float @dx.op.binary.f32(i32 36, float %752, float %18)  ; FMin(a,b)
  %781 = fsub fast float %780, %10
  %782 = fmul fast float %11, %781
  %783 = fsub fast float -0.000000e+00, %782
  %784 = call float @dx.op.binary.f32(i32 35, float %783, float -4.000000e+01)  ; FMax(a,b)
  %785 = call float @dx.op.binary.f32(i32 36, float %784, float 5.000000e+00)  ; FMin(a,b)
  %786 = fmul fast float %785, 0x3FF7154760000000
  %787 = call float @dx.op.unary.f32(i32 21, float %786)  ; Exp(value)
  %788 = fmul fast float %787, %779
  br label %789

; <label>:789                                     ; preds = %778, %738
  %790 = phi float [ %788, %778 ], [ 1.000000e+00, %738 ]
  %791 = fmul fast float %764, %16
  %792 = fmul fast float %791, %790
  %793 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %792)  ; FMin(a,b)
  %794 = fmul fast float %793, 0xBFF7154760000000
  %795 = call float @dx.op.unary.f32(i32 21, float %794)  ; Exp(value)
  %796 = fsub fast float 1.000000e+00, %795
  %797 = call float @dx.op.binary.f32(i32 36, float %12, float %796)  ; FMin(a,b)
  %798 = fsub fast float %13, %708
  %799 = fsub fast float %14, %709
  %800 = fsub fast float %15, %710
  %801 = fmul fast float %797, %798
  %802 = fmul fast float %797, %799
  %803 = fmul fast float %797, %800
  %804 = fadd fast float %801, %708
  %805 = fadd fast float %802, %709
  %806 = fadd fast float %803, %710
  br label %807

; <label>:807                                     ; preds = %789, %721, %715
  %808 = phi float [ %804, %789 ], [ %708, %721 ], [ %708, %715 ]
  %809 = phi float [ %805, %789 ], [ %709, %721 ], [ %709, %715 ]
  %810 = phi float [ %806, %789 ], [ %710, %721 ], [ %710, %715 ]
  %811 = fadd fast float %5, 1.000000e+00
  %812 = fadd fast float %6, 1.000000e+00
  %813 = fsub fast float 1.000000e+00, %5
  %814 = fmul fast float %36, %811
  %815 = fmul fast float %36, %812
  %816 = fmul fast float %36, %813
  %817 = fmul fast float %814, %808
  %818 = fmul fast float %815, %809
  %819 = fmul fast float %816, %810
  %820 = fcmp fast ult float %37, 5.000000e-01
  br i1 %820, label %846, label %821

; <label>:821                                     ; preds = %807
  %822 = fmul fast float %817, 0x4004147AE0000000
  %823 = fmul fast float %818, 0x4004147AE0000000
  %824 = fmul fast float %819, 0x4004147AE0000000
  %825 = fadd fast float %822, 0x3F9EB851E0000000
  %826 = fadd fast float %823, 0x3F9EB851E0000000
  %827 = fadd fast float %824, 0x3F9EB851E0000000
  %828 = fmul fast float %825, %817
  %829 = fmul fast float %826, %818
  %830 = fmul fast float %827, %819
  %831 = fmul fast float %817, 0x400370A3E0000000
  %832 = fmul fast float %818, 0x400370A3E0000000
  %833 = fmul fast float %819, 0x400370A3E0000000
  %834 = fadd fast float %831, 0x3FE2E147A0000000
  %835 = fadd fast float %832, 0x3FE2E147A0000000
  %836 = fadd fast float %833, 0x3FE2E147A0000000
  %837 = fmul fast float %834, %817
  %838 = fmul fast float %835, %818
  %839 = fmul fast float %836, %819
  %840 = fadd fast float %837, 0x3FC1EB8520000000
  %841 = fadd fast float %838, 0x3FC1EB8520000000
  %842 = fadd fast float %839, 0x3FC1EB8520000000
  %843 = fdiv fast float %828, %840
  %844 = fdiv fast float %829, %841
  %845 = fdiv fast float %830, %842
  br label %846

; <label>:846                                     ; preds = %821, %807
  %847 = phi float [ %843, %821 ], [ %817, %807 ]
  %848 = phi float [ %844, %821 ], [ %818, %807 ]
  %849 = phi float [ %845, %821 ], [ %819, %807 ]
  %850 = call float @dx.op.unary.f32(i32 7, float %847)  ; Saturate(value)
  %851 = call float @dx.op.unary.f32(i32 7, float %848)  ; Saturate(value)
  %852 = call float @dx.op.unary.f32(i32 7, float %849)  ; Saturate(value)
  %853 = call float @dx.op.dot3.f32(i32 55, float %850, float %851, float %852, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %854 = fsub fast float %850, %853
  %855 = fsub fast float %851, %853
  %856 = fsub fast float %852, %853
  %857 = fmul fast float %854, %8
  %858 = fmul fast float %855, %8
  %859 = fmul fast float %856, %8
  %860 = fadd fast float %857, %853
  %861 = fadd fast float %858, %853
  %862 = fadd fast float %859, %853
  %863 = call float @dx.op.unary.f32(i32 7, float %860)  ; Saturate(value)
  %864 = call float @dx.op.unary.f32(i32 7, float %861)  ; Saturate(value)
  %865 = call float @dx.op.unary.f32(i32 7, float %862)  ; Saturate(value)
  %866 = fadd fast float %863, 0xBFC70A3D80000000
  %867 = fadd fast float %864, 0xBFC70A3D80000000
  %868 = fadd fast float %865, 0xBFC70A3D80000000
  %869 = fmul fast float %866, %7
  %870 = fmul fast float %867, %7
  %871 = fmul fast float %868, %7
  %872 = fadd fast float %869, 0x3FC70A3D80000000
  %873 = fadd fast float %870, 0x3FC70A3D80000000
  %874 = fadd fast float %871, 0x3FC70A3D80000000
  %875 = call float @dx.op.unary.f32(i32 7, float %872)  ; Saturate(value)
  %876 = call float @dx.op.unary.f32(i32 7, float %873)  ; Saturate(value)
  %877 = call float @dx.op.unary.f32(i32 7, float %874)  ; Saturate(value)
  %878 = fcmp fast ogt float %875, 0x3F69A5C380000000
  %879 = fcmp fast ogt float %876, 0x3F69A5C380000000
  %880 = fcmp fast ogt float %877, 0x3F69A5C380000000
  %881 = select i1 %878, float 0.000000e+00, float 1.000000e+00
  %882 = select i1 %879, float 0.000000e+00, float 1.000000e+00
  %883 = select i1 %880, float 0.000000e+00, float 1.000000e+00
  %884 = fmul fast float %875, 0x4029D70A40000000
  %885 = fmul fast float %876, 0x4029D70A40000000
  %886 = fmul fast float %877, 0x4029D70A40000000
  %887 = call float @dx.op.binary.f32(i32 35, float %875, float 0.000000e+00)  ; FMax(a,b)
  %888 = call float @dx.op.binary.f32(i32 35, float %876, float 0.000000e+00)  ; FMax(a,b)
  %889 = call float @dx.op.binary.f32(i32 35, float %877, float 0.000000e+00)  ; FMax(a,b)
  %890 = call float @dx.op.unary.f32(i32 23, float %887)  ; Log(value)
  %891 = call float @dx.op.unary.f32(i32 23, float %888)  ; Log(value)
  %892 = call float @dx.op.unary.f32(i32 23, float %889)  ; Log(value)
  %893 = fmul fast float %890, 0x3FDAAAAAA0000000
  %894 = fmul fast float %891, 0x3FDAAAAAA0000000
  %895 = fmul fast float %892, 0x3FDAAAAAA0000000
  %896 = call float @dx.op.unary.f32(i32 21, float %893)  ; Exp(value)
  %897 = call float @dx.op.unary.f32(i32 21, float %894)  ; Exp(value)
  %898 = call float @dx.op.unary.f32(i32 21, float %895)  ; Exp(value)
  %899 = fmul fast float %896, 0x3FF0E147A0000000
  %900 = fmul fast float %897, 0x3FF0E147A0000000
  %901 = fmul fast float %898, 0x3FF0E147A0000000
  %902 = fadd fast float %899, 0xBFAC28F5C0000000
  %903 = fadd fast float %900, 0xBFAC28F5C0000000
  %904 = fadd fast float %901, 0xBFAC28F5C0000000
  %905 = fsub fast float %884, %902
  %906 = fsub fast float %885, %903
  %907 = fsub fast float %886, %904
  %908 = fmul fast float %905, %881
  %909 = fmul fast float %906, %882
  %910 = fmul fast float %907, %883
  %911 = fadd fast float %908, %902
  %912 = fadd fast float %909, %903
  %913 = fadd fast float %910, %904
  br label %914

; <label>:914                                     ; preds = %846, %713
  %915 = phi float [ %708, %713 ], [ %911, %846 ]
  %916 = phi float [ %709, %713 ], [ %912, %846 ]
  %917 = phi float [ %710, %713 ], [ %913, %846 ]
  %918 = phi float [ %714, %713 ], [ %711, %846 ]
  %919 = call float @dx.op.unary.f32(i32 27, float %49)  ; Round_ni(value)
  %920 = call float @dx.op.unary.f32(i32 27, float %50)  ; Round_ni(value)
  %921 = fptosi float %919 to i32
  %922 = fptosi float %920 to i32
  %923 = call i32 @dx.op.binary.i32(i32 37, i32 %921, i32 0)  ; IMax(a,b)
  %924 = call i32 @dx.op.binary.i32(i32 37, i32 %922, i32 0)  ; IMax(a,b)
  %925 = call i32 @dx.op.binary.i32(i32 38, i32 %923, i32 %59)  ; IMin(a,b)
  %926 = call i32 @dx.op.binary.i32(i32 38, i32 %924, i32 %60)  ; IMin(a,b)
  %927 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %925, i32 %926, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %928 = extractvalue %dx.types.ResRet.f32 %927, 0
  %929 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %930 = extractvalue %dx.types.ResRet.f32 %929, 0
  %931 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %279, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %932 = extractvalue %dx.types.ResRet.f32 %931, 0
  %933 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %494, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %934 = extractvalue %dx.types.ResRet.f32 %933, 0
  %935 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %279, i32 %494, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %936 = extractvalue %dx.types.ResRet.f32 %935, 0
  %937 = fsub fast float 1.000000e+00, %57
  %938 = fsub fast float 1.000000e+00, %58
  %939 = fmul fast float %938, %937
  %940 = fmul fast float %938, %57
  %941 = fmul fast float %937, %58
  %942 = fmul fast float %58, %57
  %943 = fsub fast float 1.000000e+00, %928
  %944 = fmul fast float %943, 0x3FA99999A0000000
  %945 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %944)  ; FMax(a,b)
  %946 = fsub fast float %930, %928
  %947 = fsub fast float %932, %928
  %948 = fsub fast float %934, %928
  %949 = fsub fast float %936, %928
  %950 = call float @dx.op.unary.f32(i32 6, float %946)  ; FAbs(value)
  %951 = call float @dx.op.unary.f32(i32 6, float %947)  ; FAbs(value)
  %952 = call float @dx.op.unary.f32(i32 6, float %948)  ; FAbs(value)
  %953 = call float @dx.op.unary.f32(i32 6, float %949)  ; FAbs(value)
  %954 = fdiv fast float %950, %945
  %955 = fdiv fast float %951, %945
  %956 = fdiv fast float %952, %945
  %957 = fdiv fast float %953, %945
  %958 = fsub fast float 1.000000e+00, %954
  %959 = fsub fast float 1.000000e+00, %955
  %960 = fsub fast float 1.000000e+00, %956
  %961 = fsub fast float 1.000000e+00, %957
  %962 = call float @dx.op.unary.f32(i32 7, float %958)  ; Saturate(value)
  %963 = call float @dx.op.unary.f32(i32 7, float %959)  ; Saturate(value)
  %964 = call float @dx.op.unary.f32(i32 7, float %960)  ; Saturate(value)
  %965 = call float @dx.op.unary.f32(i32 7, float %961)  ; Saturate(value)
  %966 = fmul fast float %939, %962
  %967 = fmul fast float %940, %963
  %968 = fmul fast float %941, %964
  %969 = fmul fast float %942, %965
  %970 = call float @dx.op.dot4.f32(i32 56, float %966, float %967, float %968, float %969, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %971 = call float @dx.op.binary.f32(i32 35, float %970, float 0x3EE4F8B580000000)  ; FMax(a,b)
  %972 = fdiv fast float %966, %971
  %973 = fdiv fast float %967, %971
  %974 = fdiv fast float %968, %971
  %975 = fdiv fast float %969, %971
  %976 = fcmp fast ogt float %273, 0x3FA4B5DCC0000000
  %977 = fcmp fast ogt float %274, 0x3FA4B5DCC0000000
  %978 = fcmp fast ogt float %275, 0x3FA4B5DCC0000000
  %979 = select i1 %976, float 0.000000e+00, float 1.000000e+00
  %980 = select i1 %977, float 0.000000e+00, float 1.000000e+00
  %981 = select i1 %978, float 0.000000e+00, float 1.000000e+00
  %982 = fmul fast float %273, 0x3FB3D07220000000
  %983 = fmul fast float %274, 0x3FB3D07220000000
  %984 = fmul fast float %275, 0x3FB3D07220000000
  %985 = fadd fast float %273, 0x3FAC28F5C0000000
  %986 = fadd fast float %274, 0x3FAC28F5C0000000
  %987 = fadd fast float %275, 0x3FAC28F5C0000000
  %988 = fmul fast float %985, 0x3FEE54EDE0000000
  %989 = fmul fast float %986, 0x3FEE54EDE0000000
  %990 = fmul fast float %987, 0x3FEE54EDE0000000
  %991 = call float @dx.op.unary.f32(i32 23, float %988)  ; Log(value)
  %992 = call float @dx.op.unary.f32(i32 23, float %989)  ; Log(value)
  %993 = call float @dx.op.unary.f32(i32 23, float %990)  ; Log(value)
  %994 = fmul fast float %991, 0x4003333340000000
  %995 = fmul fast float %992, 0x4003333340000000
  %996 = fmul fast float %993, 0x4003333340000000
  %997 = call float @dx.op.unary.f32(i32 21, float %994)  ; Exp(value)
  %998 = call float @dx.op.unary.f32(i32 21, float %995)  ; Exp(value)
  %999 = call float @dx.op.unary.f32(i32 21, float %996)  ; Exp(value)
  %1000 = fsub fast float %982, %997
  %1001 = fsub fast float %983, %998
  %1002 = fsub fast float %984, %999
  %1003 = fmul fast float %1000, %979
  %1004 = fmul fast float %1001, %980
  %1005 = fmul fast float %1002, %981
  %1006 = fadd fast float %1003, %997
  %1007 = fadd fast float %1004, %998
  %1008 = fadd fast float %1005, %999
  %1009 = fmul fast float %1006, %972
  %1010 = fmul fast float %1007, %972
  %1011 = fmul fast float %1008, %972
  %1012 = fcmp fast ogt float %488, 0x3FA4B5DCC0000000
  %1013 = fcmp fast ogt float %489, 0x3FA4B5DCC0000000
  %1014 = fcmp fast ogt float %490, 0x3FA4B5DCC0000000
  %1015 = select i1 %1012, float 0.000000e+00, float 1.000000e+00
  %1016 = select i1 %1013, float 0.000000e+00, float 1.000000e+00
  %1017 = select i1 %1014, float 0.000000e+00, float 1.000000e+00
  %1018 = fmul fast float %488, 0x3FB3D07220000000
  %1019 = fmul fast float %489, 0x3FB3D07220000000
  %1020 = fmul fast float %490, 0x3FB3D07220000000
  %1021 = fadd fast float %488, 0x3FAC28F5C0000000
  %1022 = fadd fast float %489, 0x3FAC28F5C0000000
  %1023 = fadd fast float %490, 0x3FAC28F5C0000000
  %1024 = fmul fast float %1021, 0x3FEE54EDE0000000
  %1025 = fmul fast float %1022, 0x3FEE54EDE0000000
  %1026 = fmul fast float %1023, 0x3FEE54EDE0000000
  %1027 = call float @dx.op.unary.f32(i32 23, float %1024)  ; Log(value)
  %1028 = call float @dx.op.unary.f32(i32 23, float %1025)  ; Log(value)
  %1029 = call float @dx.op.unary.f32(i32 23, float %1026)  ; Log(value)
  %1030 = fmul fast float %1027, 0x4003333340000000
  %1031 = fmul fast float %1028, 0x4003333340000000
  %1032 = fmul fast float %1029, 0x4003333340000000
  %1033 = call float @dx.op.unary.f32(i32 21, float %1030)  ; Exp(value)
  %1034 = call float @dx.op.unary.f32(i32 21, float %1031)  ; Exp(value)
  %1035 = call float @dx.op.unary.f32(i32 21, float %1032)  ; Exp(value)
  %1036 = fsub fast float %1018, %1033
  %1037 = fsub fast float %1019, %1034
  %1038 = fsub fast float %1020, %1035
  %1039 = fmul fast float %1036, %1015
  %1040 = fmul fast float %1037, %1016
  %1041 = fmul fast float %1038, %1017
  %1042 = fadd fast float %1039, %1033
  %1043 = fadd fast float %1040, %1034
  %1044 = fadd fast float %1041, %1035
  %1045 = fmul fast float %1042, %973
  %1046 = fmul fast float %1043, %973
  %1047 = fmul fast float %1044, %973
  %1048 = fadd fast float %1045, %1009
  %1049 = fadd fast float %1046, %1010
  %1050 = fadd fast float %1047, %1011
  %1051 = fcmp fast ogt float %703, 0x3FA4B5DCC0000000
  %1052 = fcmp fast ogt float %704, 0x3FA4B5DCC0000000
  %1053 = fcmp fast ogt float %705, 0x3FA4B5DCC0000000
  %1054 = select i1 %1051, float 0.000000e+00, float 1.000000e+00
  %1055 = select i1 %1052, float 0.000000e+00, float 1.000000e+00
  %1056 = select i1 %1053, float 0.000000e+00, float 1.000000e+00
  %1057 = fmul fast float %703, 0x3FB3D07220000000
  %1058 = fmul fast float %704, 0x3FB3D07220000000
  %1059 = fmul fast float %705, 0x3FB3D07220000000
  %1060 = fadd fast float %703, 0x3FAC28F5C0000000
  %1061 = fadd fast float %704, 0x3FAC28F5C0000000
  %1062 = fadd fast float %705, 0x3FAC28F5C0000000
  %1063 = fmul fast float %1060, 0x3FEE54EDE0000000
  %1064 = fmul fast float %1061, 0x3FEE54EDE0000000
  %1065 = fmul fast float %1062, 0x3FEE54EDE0000000
  %1066 = call float @dx.op.unary.f32(i32 23, float %1063)  ; Log(value)
  %1067 = call float @dx.op.unary.f32(i32 23, float %1064)  ; Log(value)
  %1068 = call float @dx.op.unary.f32(i32 23, float %1065)  ; Log(value)
  %1069 = fmul fast float %1066, 0x4003333340000000
  %1070 = fmul fast float %1067, 0x4003333340000000
  %1071 = fmul fast float %1068, 0x4003333340000000
  %1072 = call float @dx.op.unary.f32(i32 21, float %1069)  ; Exp(value)
  %1073 = call float @dx.op.unary.f32(i32 21, float %1070)  ; Exp(value)
  %1074 = call float @dx.op.unary.f32(i32 21, float %1071)  ; Exp(value)
  %1075 = fsub fast float %1057, %1072
  %1076 = fsub fast float %1058, %1073
  %1077 = fsub fast float %1059, %1074
  %1078 = fmul fast float %1075, %1054
  %1079 = fmul fast float %1076, %1055
  %1080 = fmul fast float %1077, %1056
  %1081 = fadd fast float %1078, %1072
  %1082 = fadd fast float %1079, %1073
  %1083 = fadd fast float %1080, %1074
  %1084 = fmul fast float %1081, %974
  %1085 = fmul fast float %1082, %974
  %1086 = fmul fast float %1083, %974
  %1087 = fadd fast float %1048, %1084
  %1088 = fadd fast float %1049, %1085
  %1089 = fadd fast float %1050, %1086
  %1090 = fcmp fast ogt float %915, 0x3FA4B5DCC0000000
  %1091 = fcmp fast ogt float %916, 0x3FA4B5DCC0000000
  %1092 = fcmp fast ogt float %917, 0x3FA4B5DCC0000000
  %1093 = select i1 %1090, float 0.000000e+00, float 1.000000e+00
  %1094 = select i1 %1091, float 0.000000e+00, float 1.000000e+00
  %1095 = select i1 %1092, float 0.000000e+00, float 1.000000e+00
  %1096 = fmul fast float %915, 0x3FB3D07220000000
  %1097 = fmul fast float %916, 0x3FB3D07220000000
  %1098 = fmul fast float %917, 0x3FB3D07220000000
  %1099 = fadd fast float %915, 0x3FAC28F5C0000000
  %1100 = fadd fast float %916, 0x3FAC28F5C0000000
  %1101 = fadd fast float %917, 0x3FAC28F5C0000000
  %1102 = fmul fast float %1099, 0x3FEE54EDE0000000
  %1103 = fmul fast float %1100, 0x3FEE54EDE0000000
  %1104 = fmul fast float %1101, 0x3FEE54EDE0000000
  %1105 = call float @dx.op.unary.f32(i32 23, float %1102)  ; Log(value)
  %1106 = call float @dx.op.unary.f32(i32 23, float %1103)  ; Log(value)
  %1107 = call float @dx.op.unary.f32(i32 23, float %1104)  ; Log(value)
  %1108 = fmul fast float %1105, 0x4003333340000000
  %1109 = fmul fast float %1106, 0x4003333340000000
  %1110 = fmul fast float %1107, 0x4003333340000000
  %1111 = call float @dx.op.unary.f32(i32 21, float %1108)  ; Exp(value)
  %1112 = call float @dx.op.unary.f32(i32 21, float %1109)  ; Exp(value)
  %1113 = call float @dx.op.unary.f32(i32 21, float %1110)  ; Exp(value)
  %1114 = fsub fast float %1096, %1111
  %1115 = fsub fast float %1097, %1112
  %1116 = fsub fast float %1098, %1113
  %1117 = fmul fast float %1114, %1093
  %1118 = fmul fast float %1115, %1094
  %1119 = fmul fast float %1116, %1095
  %1120 = fadd fast float %1117, %1111
  %1121 = fadd fast float %1118, %1112
  %1122 = fadd fast float %1119, %1113
  %1123 = fmul fast float %1120, %975
  %1124 = fmul fast float %1121, %975
  %1125 = fmul fast float %1122, %975
  %1126 = fadd fast float %1087, %1123
  %1127 = fadd fast float %1088, %1124
  %1128 = fadd fast float %1089, %1125
  %1129 = fcmp fast ogt float %1126, 0x3F69A5C380000000
  %1130 = fcmp fast ogt float %1127, 0x3F69A5C380000000
  %1131 = fcmp fast ogt float %1128, 0x3F69A5C380000000
  %1132 = select i1 %1129, float 0.000000e+00, float 1.000000e+00
  %1133 = select i1 %1130, float 0.000000e+00, float 1.000000e+00
  %1134 = select i1 %1131, float 0.000000e+00, float 1.000000e+00
  %1135 = fmul fast float %1126, 0x4029D70A40000000
  %1136 = fmul fast float %1127, 0x4029D70A40000000
  %1137 = fmul fast float %1128, 0x4029D70A40000000
  %1138 = call float @dx.op.binary.f32(i32 35, float %1126, float 0.000000e+00)  ; FMax(a,b)
  %1139 = call float @dx.op.binary.f32(i32 35, float %1127, float 0.000000e+00)  ; FMax(a,b)
  %1140 = call float @dx.op.binary.f32(i32 35, float %1128, float 0.000000e+00)  ; FMax(a,b)
  %1141 = call float @dx.op.unary.f32(i32 23, float %1138)  ; Log(value)
  %1142 = call float @dx.op.unary.f32(i32 23, float %1139)  ; Log(value)
  %1143 = call float @dx.op.unary.f32(i32 23, float %1140)  ; Log(value)
  %1144 = fmul fast float %1141, 0x3FDAAAAAA0000000
  %1145 = fmul fast float %1142, 0x3FDAAAAAA0000000
  %1146 = fmul fast float %1143, 0x3FDAAAAAA0000000
  %1147 = call float @dx.op.unary.f32(i32 21, float %1144)  ; Exp(value)
  %1148 = call float @dx.op.unary.f32(i32 21, float %1145)  ; Exp(value)
  %1149 = call float @dx.op.unary.f32(i32 21, float %1146)  ; Exp(value)
  %1150 = fmul fast float %1147, 0x3FF0E147A0000000
  %1151 = fmul fast float %1148, 0x3FF0E147A0000000
  %1152 = fmul fast float %1149, 0x3FF0E147A0000000
  %1153 = fadd fast float %1150, 0xBFAC28F5C0000000
  %1154 = fadd fast float %1151, 0xBFAC28F5C0000000
  %1155 = fadd fast float %1152, 0xBFAC28F5C0000000
  %1156 = fsub fast float %1135, %1153
  %1157 = fsub fast float %1136, %1154
  %1158 = fsub fast float %1137, %1155
  %1159 = fmul fast float %1156, %1132
  %1160 = fmul fast float %1157, %1133
  %1161 = fmul fast float %1158, %1134
  %1162 = fadd fast float %1159, %1153
  %1163 = fadd fast float %1160, %1154
  %1164 = fadd fast float %1161, %1155
  %1165 = call float @dx.op.dot4.f32(i32 56, float %276, float %491, float %706, float %918, float %972, float %973, float %974, float %975)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %1162)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %1163)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %1164)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %1165)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %928)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !38, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, !37}
!36 = !{i32 9}
!37 = !{i32 3, i32 6}
!38 = !{!39, !40}
!39 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
!40 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !41}
!41 = !{i32 3, i32 1}
