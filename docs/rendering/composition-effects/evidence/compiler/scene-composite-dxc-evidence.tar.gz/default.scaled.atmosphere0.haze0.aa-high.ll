;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xy  
; TEXCOORD                 1   xyzw        2     NONE   float       
; TEXCOORD                 2   xyzw        3     NONE   float       
; TEXCOORD                 3   xyzw        4     NONE   float       
; TEXCOORD                 4   xyzw        5     NONE   float       
; TEXCOORD                 5   xyzw        6     NONE   float       
; TEXCOORD                 6   xyzw        7     NONE   float       
; TEXCOORD                 7   xyzw        8     NONE   float       
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float    yz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: 8eb6fa0741ed3557696e53c8ade6c9e1
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %14 = extractvalue %dx.types.Dimensions %13, 0
  %15 = extractvalue %dx.types.Dimensions %13, 1
  %16 = uitofp i32 %14 to float
  %17 = uitofp i32 %15 to float
  %18 = fmul fast float %16, %11
  %19 = fmul fast float %17, %12
  %20 = fdiv fast float %18, %3
  %21 = fdiv fast float %19, %4
  %22 = fadd fast float %20, -5.000000e-01
  %23 = fadd fast float %21, -5.000000e-01
  %24 = call float @dx.op.unary.f32(i32 27, float %22)  ; Round_ni(value)
  %25 = call float @dx.op.unary.f32(i32 27, float %23)  ; Round_ni(value)
  %26 = fptosi float %24 to i32
  %27 = fptosi float %25 to i32
  %28 = call float @dx.op.unary.f32(i32 22, float %22)  ; Frc(value)
  %29 = call float @dx.op.unary.f32(i32 22, float %23)  ; Frc(value)
  %30 = add i32 %14, -1
  %31 = add i32 %15, -1
  %32 = call i32 @dx.op.binary.i32(i32 37, i32 %26, i32 0)  ; IMax(a,b)
  %33 = call i32 @dx.op.binary.i32(i32 37, i32 %27, i32 0)  ; IMax(a,b)
  %34 = call i32 @dx.op.binary.i32(i32 38, i32 %32, i32 %30)  ; IMin(a,b)
  %35 = call i32 @dx.op.binary.i32(i32 38, i32 %33, i32 %31)  ; IMin(a,b)
  %36 = add i32 %26, 1
  %37 = call i32 @dx.op.binary.i32(i32 37, i32 %36, i32 0)  ; IMax(a,b)
  %38 = call i32 @dx.op.binary.i32(i32 38, i32 %37, i32 %30)  ; IMin(a,b)
  %39 = add i32 %27, 1
  %40 = call i32 @dx.op.binary.i32(i32 37, i32 %39, i32 0)  ; IMax(a,b)
  %41 = call i32 @dx.op.binary.i32(i32 38, i32 %40, i32 %31)  ; IMin(a,b)
  %42 = call float @dx.op.unary.f32(i32 27, float %20)  ; Round_ni(value)
  %43 = call float @dx.op.unary.f32(i32 27, float %21)  ; Round_ni(value)
  %44 = fptosi float %42 to i32
  %45 = fptosi float %43 to i32
  %46 = call i32 @dx.op.binary.i32(i32 37, i32 %44, i32 0)  ; IMax(a,b)
  %47 = call i32 @dx.op.binary.i32(i32 37, i32 %45, i32 0)  ; IMax(a,b)
  %48 = call i32 @dx.op.binary.i32(i32 38, i32 %46, i32 %30)  ; IMin(a,b)
  %49 = call i32 @dx.op.binary.i32(i32 38, i32 %47, i32 %31)  ; IMin(a,b)
  %50 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %48, i32 %49, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %51 = extractvalue %dx.types.ResRet.f32 %50, 0
  %52 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %34, i32 %35, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %53 = extractvalue %dx.types.ResRet.f32 %52, 0
  %54 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %38, i32 %35, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %55 = extractvalue %dx.types.ResRet.f32 %54, 0
  %56 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %34, i32 %41, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %57 = extractvalue %dx.types.ResRet.f32 %56, 0
  %58 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %38, i32 %41, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %59 = extractvalue %dx.types.ResRet.f32 %58, 0
  %60 = fsub fast float 1.000000e+00, %28
  %61 = fsub fast float 1.000000e+00, %29
  %62 = fmul fast float %61, %60
  %63 = fmul fast float %61, %28
  %64 = fmul fast float %60, %29
  %65 = fmul fast float %29, %28
  %66 = fsub fast float 1.000000e+00, %51
  %67 = fmul fast float %66, 0x3FA99999A0000000
  %68 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %67)  ; FMax(a,b)
  %69 = fsub fast float %53, %51
  %70 = call float @dx.op.unary.f32(i32 6, float %69)  ; FAbs(value)
  %71 = fdiv fast float %70, %68
  %72 = fsub fast float 1.000000e+00, %71
  %73 = call float @dx.op.unary.f32(i32 7, float %72)  ; Saturate(value)
  %74 = fsub fast float %55, %51
  %75 = call float @dx.op.unary.f32(i32 6, float %74)  ; FAbs(value)
  %76 = fdiv fast float %75, %68
  %77 = fsub fast float 1.000000e+00, %76
  %78 = call float @dx.op.unary.f32(i32 7, float %77)  ; Saturate(value)
  %79 = fsub fast float %57, %51
  %80 = call float @dx.op.unary.f32(i32 6, float %79)  ; FAbs(value)
  %81 = fdiv fast float %80, %68
  %82 = fsub fast float 1.000000e+00, %81
  %83 = call float @dx.op.unary.f32(i32 7, float %82)  ; Saturate(value)
  %84 = fsub fast float %59, %51
  %85 = call float @dx.op.unary.f32(i32 6, float %84)  ; FAbs(value)
  %86 = fdiv fast float %85, %68
  %87 = fsub fast float 1.000000e+00, %86
  %88 = call float @dx.op.unary.f32(i32 7, float %87)  ; Saturate(value)
  %89 = fmul fast float %62, %73
  %90 = fmul fast float %63, %78
  %91 = fmul fast float %64, %83
  %92 = fmul fast float %65, %88
  %93 = fcmp fast oge float %28, 5.000000e-01
  %94 = zext i1 %93 to i32
  %95 = fcmp fast oge float %29, 5.000000e-01
  %96 = select i1 %95, i32 2, i32 0
  %97 = or i32 %96, %94
  %98 = call float @dx.op.dot4.f32(i32 56, float %89, float %90, float %91, float %92, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %99 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %89)  ; IsFinite(value)
  %100 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %90)  ; IsFinite(value)
  %101 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %91)  ; IsFinite(value)
  %102 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %92)  ; IsFinite(value)
  %103 = and i1 %99, %100
  %104 = and i1 %103, %101
  %105 = and i1 %104, %102
  br i1 %105, label %106, label %123

; <label>:106                                     ; preds = %0
  %107 = fcmp fast oge float %89, 0.000000e+00
  %108 = fcmp fast oge float %90, 0.000000e+00
  %109 = fcmp fast oge float %91, 0.000000e+00
  %110 = fcmp fast oge float %92, 0.000000e+00
  %111 = and i1 %107, %108
  %112 = and i1 %111, %109
  %113 = and i1 %112, %110
  br i1 %113, label %114, label %123

; <label>:114                                     ; preds = %106
  %115 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %98)  ; IsFinite(value)
  %116 = fcmp fast oge float %98, 0x3810000000000000
  %117 = and i1 %116, %115
  br i1 %117, label %118, label %123

; <label>:118                                     ; preds = %114
  %119 = fdiv fast float %89, %98
  %120 = fdiv fast float %90, %98
  %121 = fdiv fast float %91, %98
  %122 = fdiv fast float %92, %98
  br label %132

; <label>:123                                     ; preds = %114, %106, %0
  %124 = icmp eq i32 %97, 0
  %125 = uitofp i1 %124 to float
  %126 = icmp eq i32 %97, 1
  %127 = uitofp i1 %126 to float
  %128 = icmp eq i32 %97, 2
  %129 = uitofp i1 %128 to float
  %130 = icmp eq i32 %97, 3
  %131 = uitofp i1 %130 to float
  br label %132

; <label>:132                                     ; preds = %123, %118
  %133 = phi float [ %119, %118 ], [ %125, %123 ]
  %134 = phi float [ %120, %118 ], [ %127, %123 ]
  %135 = phi float [ %121, %118 ], [ %129, %123 ]
  %136 = phi float [ %122, %118 ], [ %131, %123 ]
  %137 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %34, i32 %35, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %138 = extractvalue %dx.types.ResRet.f32 %137, 0
  %139 = extractvalue %dx.types.ResRet.f32 %137, 1
  %140 = extractvalue %dx.types.ResRet.f32 %137, 2
  %141 = extractvalue %dx.types.ResRet.f32 %137, 3
  %142 = fcmp fast olt float %141, 0.000000e+00
  br i1 %142, label %143, label %145

; <label>:143                                     ; preds = %132
  %144 = fsub fast float -1.000000e+00, %141
  br label %922

; <label>:145                                     ; preds = %132
  %146 = fadd fast float %5, 1.000000e+00
  %147 = fadd fast float %6, 1.000000e+00
  %148 = fsub fast float 1.000000e+00, %5
  %149 = fmul fast float %9, %146
  %150 = fmul fast float %9, %147
  %151 = fmul fast float %9, %148
  %152 = fmul fast float %149, %138
  %153 = fmul fast float %150, %139
  %154 = fmul fast float %151, %140
  %155 = fcmp fast ult float %10, 5.000000e-01
  br i1 %155, label %181, label %156

; <label>:156                                     ; preds = %145
  %157 = fmul fast float %152, 0x4004147AE0000000
  %158 = fmul fast float %153, 0x4004147AE0000000
  %159 = fmul fast float %154, 0x4004147AE0000000
  %160 = fadd fast float %157, 0x3F9EB851E0000000
  %161 = fadd fast float %158, 0x3F9EB851E0000000
  %162 = fadd fast float %159, 0x3F9EB851E0000000
  %163 = fmul fast float %160, %152
  %164 = fmul fast float %161, %153
  %165 = fmul fast float %162, %154
  %166 = fmul fast float %152, 0x400370A3E0000000
  %167 = fmul fast float %153, 0x400370A3E0000000
  %168 = fmul fast float %154, 0x400370A3E0000000
  %169 = fadd fast float %166, 0x3FE2E147A0000000
  %170 = fadd fast float %167, 0x3FE2E147A0000000
  %171 = fadd fast float %168, 0x3FE2E147A0000000
  %172 = fmul fast float %169, %152
  %173 = fmul fast float %170, %153
  %174 = fmul fast float %171, %154
  %175 = fadd fast float %172, 0x3FC1EB8520000000
  %176 = fadd fast float %173, 0x3FC1EB8520000000
  %177 = fadd fast float %174, 0x3FC1EB8520000000
  %178 = fdiv fast float %163, %175
  %179 = fdiv fast float %164, %176
  %180 = fdiv fast float %165, %177
  br label %181

; <label>:181                                     ; preds = %156, %145
  %182 = phi float [ %178, %156 ], [ %152, %145 ]
  %183 = phi float [ %179, %156 ], [ %153, %145 ]
  %184 = phi float [ %180, %156 ], [ %154, %145 ]
  %185 = call float @dx.op.unary.f32(i32 7, float %182)  ; Saturate(value)
  %186 = call float @dx.op.unary.f32(i32 7, float %183)  ; Saturate(value)
  %187 = call float @dx.op.unary.f32(i32 7, float %184)  ; Saturate(value)
  %188 = call float @dx.op.dot3.f32(i32 55, float %185, float %186, float %187, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %189 = fsub fast float %185, %188
  %190 = fsub fast float %186, %188
  %191 = fsub fast float %187, %188
  %192 = fmul fast float %189, %8
  %193 = fmul fast float %190, %8
  %194 = fmul fast float %191, %8
  %195 = fadd fast float %192, %188
  %196 = fadd fast float %193, %188
  %197 = fadd fast float %194, %188
  %198 = call float @dx.op.unary.f32(i32 7, float %195)  ; Saturate(value)
  %199 = call float @dx.op.unary.f32(i32 7, float %196)  ; Saturate(value)
  %200 = call float @dx.op.unary.f32(i32 7, float %197)  ; Saturate(value)
  %201 = fadd fast float %198, 0xBFC70A3D80000000
  %202 = fadd fast float %199, 0xBFC70A3D80000000
  %203 = fadd fast float %200, 0xBFC70A3D80000000
  %204 = fmul fast float %201, %7
  %205 = fmul fast float %202, %7
  %206 = fmul fast float %203, %7
  %207 = fadd fast float %204, 0x3FC70A3D80000000
  %208 = fadd fast float %205, 0x3FC70A3D80000000
  %209 = fadd fast float %206, 0x3FC70A3D80000000
  %210 = call float @dx.op.unary.f32(i32 7, float %207)  ; Saturate(value)
  %211 = call float @dx.op.unary.f32(i32 7, float %208)  ; Saturate(value)
  %212 = call float @dx.op.unary.f32(i32 7, float %209)  ; Saturate(value)
  %213 = add i32 %35, -1
  %214 = call i32 @dx.op.binary.i32(i32 37, i32 %34, i32 0)  ; IMax(a,b)
  %215 = call i32 @dx.op.binary.i32(i32 37, i32 %213, i32 0)  ; IMax(a,b)
  %216 = call i32 @dx.op.binary.i32(i32 38, i32 %214, i32 %30)  ; IMin(a,b)
  %217 = call i32 @dx.op.binary.i32(i32 38, i32 %215, i32 %31)  ; IMin(a,b)
  %218 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %216, i32 %217, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %219 = extractvalue %dx.types.ResRet.f32 %218, 0
  %220 = fsub fast float 1.000000e+00, %53
  %221 = fmul fast float %220, 0x3FA99999A0000000
  %222 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %221)  ; FMax(a,b)
  %223 = fsub fast float %219, %53
  %224 = call float @dx.op.unary.f32(i32 6, float %223)  ; FAbs(value)
  %225 = fdiv fast float %224, %222
  %226 = fsub fast float 1.000000e+00, %225
  %227 = call float @dx.op.unary.f32(i32 7, float %226)  ; Saturate(value)
  %228 = fcmp fast ugt float %227, 0.000000e+00
  br i1 %228, label %229, label %355

; <label>:229                                     ; preds = %181
  %230 = call i32 @dx.op.binary.i32(i32 37, i32 %216, i32 0)  ; IMax(a,b)
  %231 = call i32 @dx.op.binary.i32(i32 37, i32 %217, i32 0)  ; IMax(a,b)
  %232 = call i32 @dx.op.binary.i32(i32 38, i32 %230, i32 %30)  ; IMin(a,b)
  %233 = call i32 @dx.op.binary.i32(i32 38, i32 %231, i32 %31)  ; IMin(a,b)
  %234 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %232, i32 %233, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %235 = extractvalue %dx.types.ResRet.f32 %234, 0
  %236 = extractvalue %dx.types.ResRet.f32 %234, 1
  %237 = extractvalue %dx.types.ResRet.f32 %234, 2
  %238 = extractvalue %dx.types.ResRet.f32 %234, 3
  %239 = fcmp fast olt float %238, 0.000000e+00
  br i1 %239, label %240, label %274

; <label>:240                                     ; preds = %229
  %241 = fcmp fast ogt float %235, 0x3FA4B5DCC0000000
  %242 = fcmp fast ogt float %236, 0x3FA4B5DCC0000000
  %243 = fcmp fast ogt float %237, 0x3FA4B5DCC0000000
  %244 = select i1 %241, float 0.000000e+00, float 1.000000e+00
  %245 = select i1 %242, float 0.000000e+00, float 1.000000e+00
  %246 = select i1 %243, float 0.000000e+00, float 1.000000e+00
  %247 = fmul fast float %235, 0x3FB3D07220000000
  %248 = fmul fast float %236, 0x3FB3D07220000000
  %249 = fmul fast float %237, 0x3FB3D07220000000
  %250 = fadd fast float %235, 0x3FAC28F5C0000000
  %251 = fadd fast float %236, 0x3FAC28F5C0000000
  %252 = fadd fast float %237, 0x3FAC28F5C0000000
  %253 = fmul fast float %250, 0x3FEE54EDE0000000
  %254 = fmul fast float %251, 0x3FEE54EDE0000000
  %255 = fmul fast float %252, 0x3FEE54EDE0000000
  %256 = call float @dx.op.unary.f32(i32 23, float %253)  ; Log(value)
  %257 = call float @dx.op.unary.f32(i32 23, float %254)  ; Log(value)
  %258 = call float @dx.op.unary.f32(i32 23, float %255)  ; Log(value)
  %259 = fmul fast float %256, 0x4003333340000000
  %260 = fmul fast float %257, 0x4003333340000000
  %261 = fmul fast float %258, 0x4003333340000000
  %262 = call float @dx.op.unary.f32(i32 21, float %259)  ; Exp(value)
  %263 = call float @dx.op.unary.f32(i32 21, float %260)  ; Exp(value)
  %264 = call float @dx.op.unary.f32(i32 21, float %261)  ; Exp(value)
  %265 = fsub fast float %247, %262
  %266 = fsub fast float %248, %263
  %267 = fsub fast float %249, %264
  %268 = fmul fast float %265, %244
  %269 = fmul fast float %266, %245
  %270 = fmul fast float %267, %246
  %271 = fadd fast float %268, %262
  %272 = fadd fast float %269, %263
  %273 = fadd fast float %270, %264
  br label %342

; <label>:274                                     ; preds = %229
  %275 = fadd fast float %5, 1.000000e+00
  %276 = fadd fast float %6, 1.000000e+00
  %277 = fsub fast float 1.000000e+00, %5
  %278 = fmul fast float %9, %275
  %279 = fmul fast float %9, %276
  %280 = fmul fast float %9, %277
  %281 = fmul fast float %278, %235
  %282 = fmul fast float %279, %236
  %283 = fmul fast float %280, %237
  %284 = fcmp fast ult float %10, 5.000000e-01
  br i1 %284, label %310, label %285

; <label>:285                                     ; preds = %274
  %286 = fmul fast float %281, 0x4004147AE0000000
  %287 = fmul fast float %282, 0x4004147AE0000000
  %288 = fmul fast float %283, 0x4004147AE0000000
  %289 = fadd fast float %286, 0x3F9EB851E0000000
  %290 = fadd fast float %287, 0x3F9EB851E0000000
  %291 = fadd fast float %288, 0x3F9EB851E0000000
  %292 = fmul fast float %289, %281
  %293 = fmul fast float %290, %282
  %294 = fmul fast float %291, %283
  %295 = fmul fast float %281, 0x400370A3E0000000
  %296 = fmul fast float %282, 0x400370A3E0000000
  %297 = fmul fast float %283, 0x400370A3E0000000
  %298 = fadd fast float %295, 0x3FE2E147A0000000
  %299 = fadd fast float %296, 0x3FE2E147A0000000
  %300 = fadd fast float %297, 0x3FE2E147A0000000
  %301 = fmul fast float %298, %281
  %302 = fmul fast float %299, %282
  %303 = fmul fast float %300, %283
  %304 = fadd fast float %301, 0x3FC1EB8520000000
  %305 = fadd fast float %302, 0x3FC1EB8520000000
  %306 = fadd fast float %303, 0x3FC1EB8520000000
  %307 = fdiv fast float %292, %304
  %308 = fdiv fast float %293, %305
  %309 = fdiv fast float %294, %306
  br label %310

; <label>:310                                     ; preds = %285, %274
  %311 = phi float [ %307, %285 ], [ %281, %274 ]
  %312 = phi float [ %308, %285 ], [ %282, %274 ]
  %313 = phi float [ %309, %285 ], [ %283, %274 ]
  %314 = call float @dx.op.unary.f32(i32 7, float %311)  ; Saturate(value)
  %315 = call float @dx.op.unary.f32(i32 7, float %312)  ; Saturate(value)
  %316 = call float @dx.op.unary.f32(i32 7, float %313)  ; Saturate(value)
  %317 = call float @dx.op.dot3.f32(i32 55, float %314, float %315, float %316, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %318 = fsub fast float %314, %317
  %319 = fsub fast float %315, %317
  %320 = fsub fast float %316, %317
  %321 = fmul fast float %318, %8
  %322 = fmul fast float %319, %8
  %323 = fmul fast float %320, %8
  %324 = fadd fast float %321, %317
  %325 = fadd fast float %322, %317
  %326 = fadd fast float %323, %317
  %327 = call float @dx.op.unary.f32(i32 7, float %324)  ; Saturate(value)
  %328 = call float @dx.op.unary.f32(i32 7, float %325)  ; Saturate(value)
  %329 = call float @dx.op.unary.f32(i32 7, float %326)  ; Saturate(value)
  %330 = fadd fast float %327, 0xBFC70A3D80000000
  %331 = fadd fast float %328, 0xBFC70A3D80000000
  %332 = fadd fast float %329, 0xBFC70A3D80000000
  %333 = fmul fast float %330, %7
  %334 = fmul fast float %331, %7
  %335 = fmul fast float %332, %7
  %336 = fadd fast float %333, 0x3FC70A3D80000000
  %337 = fadd fast float %334, 0x3FC70A3D80000000
  %338 = fadd fast float %335, 0x3FC70A3D80000000
  %339 = call float @dx.op.unary.f32(i32 7, float %336)  ; Saturate(value)
  %340 = call float @dx.op.unary.f32(i32 7, float %337)  ; Saturate(value)
  %341 = call float @dx.op.unary.f32(i32 7, float %338)  ; Saturate(value)
  br label %342

; <label>:342                                     ; preds = %310, %240
  %343 = phi float [ %271, %240 ], [ %339, %310 ]
  %344 = phi float [ %272, %240 ], [ %340, %310 ]
  %345 = phi float [ %273, %240 ], [ %341, %310 ]
  %346 = fsub fast float %343, %210
  %347 = fsub fast float %344, %211
  %348 = fsub fast float %345, %212
  %349 = fmul fast float %346, %227
  %350 = fmul fast float %347, %227
  %351 = fmul fast float %348, %227
  %352 = fadd fast float %349, %210
  %353 = fadd fast float %350, %211
  %354 = fadd fast float %351, %212
  br label %355

; <label>:355                                     ; preds = %342, %181
  %356 = phi float [ %352, %342 ], [ %210, %181 ]
  %357 = phi float [ %353, %342 ], [ %211, %181 ]
  %358 = phi float [ %354, %342 ], [ %212, %181 ]
  %359 = add i32 %35, 1
  %360 = call i32 @dx.op.binary.i32(i32 37, i32 %359, i32 0)  ; IMax(a,b)
  %361 = call i32 @dx.op.binary.i32(i32 38, i32 %360, i32 %31)  ; IMin(a,b)
  %362 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %216, i32 %361, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %363 = extractvalue %dx.types.ResRet.f32 %362, 0
  %364 = fsub fast float %363, %53
  %365 = call float @dx.op.unary.f32(i32 6, float %364)  ; FAbs(value)
  %366 = fdiv fast float %365, %222
  %367 = fsub fast float 1.000000e+00, %366
  %368 = call float @dx.op.unary.f32(i32 7, float %367)  ; Saturate(value)
  %369 = fcmp fast ugt float %368, 0.000000e+00
  br i1 %369, label %370, label %496

; <label>:370                                     ; preds = %355
  %371 = call i32 @dx.op.binary.i32(i32 37, i32 %216, i32 0)  ; IMax(a,b)
  %372 = call i32 @dx.op.binary.i32(i32 37, i32 %361, i32 0)  ; IMax(a,b)
  %373 = call i32 @dx.op.binary.i32(i32 38, i32 %371, i32 %30)  ; IMin(a,b)
  %374 = call i32 @dx.op.binary.i32(i32 38, i32 %372, i32 %31)  ; IMin(a,b)
  %375 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %373, i32 %374, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %376 = extractvalue %dx.types.ResRet.f32 %375, 0
  %377 = extractvalue %dx.types.ResRet.f32 %375, 1
  %378 = extractvalue %dx.types.ResRet.f32 %375, 2
  %379 = extractvalue %dx.types.ResRet.f32 %375, 3
  %380 = fcmp fast olt float %379, 0.000000e+00
  br i1 %380, label %381, label %415

; <label>:381                                     ; preds = %370
  %382 = fcmp fast ogt float %376, 0x3FA4B5DCC0000000
  %383 = fcmp fast ogt float %377, 0x3FA4B5DCC0000000
  %384 = fcmp fast ogt float %378, 0x3FA4B5DCC0000000
  %385 = select i1 %382, float 0.000000e+00, float 1.000000e+00
  %386 = select i1 %383, float 0.000000e+00, float 1.000000e+00
  %387 = select i1 %384, float 0.000000e+00, float 1.000000e+00
  %388 = fmul fast float %376, 0x3FB3D07220000000
  %389 = fmul fast float %377, 0x3FB3D07220000000
  %390 = fmul fast float %378, 0x3FB3D07220000000
  %391 = fadd fast float %376, 0x3FAC28F5C0000000
  %392 = fadd fast float %377, 0x3FAC28F5C0000000
  %393 = fadd fast float %378, 0x3FAC28F5C0000000
  %394 = fmul fast float %391, 0x3FEE54EDE0000000
  %395 = fmul fast float %392, 0x3FEE54EDE0000000
  %396 = fmul fast float %393, 0x3FEE54EDE0000000
  %397 = call float @dx.op.unary.f32(i32 23, float %394)  ; Log(value)
  %398 = call float @dx.op.unary.f32(i32 23, float %395)  ; Log(value)
  %399 = call float @dx.op.unary.f32(i32 23, float %396)  ; Log(value)
  %400 = fmul fast float %397, 0x4003333340000000
  %401 = fmul fast float %398, 0x4003333340000000
  %402 = fmul fast float %399, 0x4003333340000000
  %403 = call float @dx.op.unary.f32(i32 21, float %400)  ; Exp(value)
  %404 = call float @dx.op.unary.f32(i32 21, float %401)  ; Exp(value)
  %405 = call float @dx.op.unary.f32(i32 21, float %402)  ; Exp(value)
  %406 = fsub fast float %388, %403
  %407 = fsub fast float %389, %404
  %408 = fsub fast float %390, %405
  %409 = fmul fast float %406, %385
  %410 = fmul fast float %407, %386
  %411 = fmul fast float %408, %387
  %412 = fadd fast float %409, %403
  %413 = fadd fast float %410, %404
  %414 = fadd fast float %411, %405
  br label %483

; <label>:415                                     ; preds = %370
  %416 = fadd fast float %5, 1.000000e+00
  %417 = fadd fast float %6, 1.000000e+00
  %418 = fsub fast float 1.000000e+00, %5
  %419 = fmul fast float %9, %416
  %420 = fmul fast float %9, %417
  %421 = fmul fast float %9, %418
  %422 = fmul fast float %419, %376
  %423 = fmul fast float %420, %377
  %424 = fmul fast float %421, %378
  %425 = fcmp fast ult float %10, 5.000000e-01
  br i1 %425, label %451, label %426

; <label>:426                                     ; preds = %415
  %427 = fmul fast float %422, 0x4004147AE0000000
  %428 = fmul fast float %423, 0x4004147AE0000000
  %429 = fmul fast float %424, 0x4004147AE0000000
  %430 = fadd fast float %427, 0x3F9EB851E0000000
  %431 = fadd fast float %428, 0x3F9EB851E0000000
  %432 = fadd fast float %429, 0x3F9EB851E0000000
  %433 = fmul fast float %430, %422
  %434 = fmul fast float %431, %423
  %435 = fmul fast float %432, %424
  %436 = fmul fast float %422, 0x400370A3E0000000
  %437 = fmul fast float %423, 0x400370A3E0000000
  %438 = fmul fast float %424, 0x400370A3E0000000
  %439 = fadd fast float %436, 0x3FE2E147A0000000
  %440 = fadd fast float %437, 0x3FE2E147A0000000
  %441 = fadd fast float %438, 0x3FE2E147A0000000
  %442 = fmul fast float %439, %422
  %443 = fmul fast float %440, %423
  %444 = fmul fast float %441, %424
  %445 = fadd fast float %442, 0x3FC1EB8520000000
  %446 = fadd fast float %443, 0x3FC1EB8520000000
  %447 = fadd fast float %444, 0x3FC1EB8520000000
  %448 = fdiv fast float %433, %445
  %449 = fdiv fast float %434, %446
  %450 = fdiv fast float %435, %447
  br label %451

; <label>:451                                     ; preds = %426, %415
  %452 = phi float [ %448, %426 ], [ %422, %415 ]
  %453 = phi float [ %449, %426 ], [ %423, %415 ]
  %454 = phi float [ %450, %426 ], [ %424, %415 ]
  %455 = call float @dx.op.unary.f32(i32 7, float %452)  ; Saturate(value)
  %456 = call float @dx.op.unary.f32(i32 7, float %453)  ; Saturate(value)
  %457 = call float @dx.op.unary.f32(i32 7, float %454)  ; Saturate(value)
  %458 = call float @dx.op.dot3.f32(i32 55, float %455, float %456, float %457, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %459 = fsub fast float %455, %458
  %460 = fsub fast float %456, %458
  %461 = fsub fast float %457, %458
  %462 = fmul fast float %459, %8
  %463 = fmul fast float %460, %8
  %464 = fmul fast float %461, %8
  %465 = fadd fast float %462, %458
  %466 = fadd fast float %463, %458
  %467 = fadd fast float %464, %458
  %468 = call float @dx.op.unary.f32(i32 7, float %465)  ; Saturate(value)
  %469 = call float @dx.op.unary.f32(i32 7, float %466)  ; Saturate(value)
  %470 = call float @dx.op.unary.f32(i32 7, float %467)  ; Saturate(value)
  %471 = fadd fast float %468, 0xBFC70A3D80000000
  %472 = fadd fast float %469, 0xBFC70A3D80000000
  %473 = fadd fast float %470, 0xBFC70A3D80000000
  %474 = fmul fast float %471, %7
  %475 = fmul fast float %472, %7
  %476 = fmul fast float %473, %7
  %477 = fadd fast float %474, 0x3FC70A3D80000000
  %478 = fadd fast float %475, 0x3FC70A3D80000000
  %479 = fadd fast float %476, 0x3FC70A3D80000000
  %480 = call float @dx.op.unary.f32(i32 7, float %477)  ; Saturate(value)
  %481 = call float @dx.op.unary.f32(i32 7, float %478)  ; Saturate(value)
  %482 = call float @dx.op.unary.f32(i32 7, float %479)  ; Saturate(value)
  br label %483

; <label>:483                                     ; preds = %451, %381
  %484 = phi float [ %412, %381 ], [ %480, %451 ]
  %485 = phi float [ %413, %381 ], [ %481, %451 ]
  %486 = phi float [ %414, %381 ], [ %482, %451 ]
  %487 = fsub fast float %484, %210
  %488 = fsub fast float %485, %211
  %489 = fsub fast float %486, %212
  %490 = fmul fast float %487, %368
  %491 = fmul fast float %488, %368
  %492 = fmul fast float %489, %368
  %493 = fadd fast float %490, %210
  %494 = fadd fast float %491, %211
  %495 = fadd fast float %492, %212
  br label %496

; <label>:496                                     ; preds = %483, %355
  %497 = phi float [ %493, %483 ], [ %210, %355 ]
  %498 = phi float [ %494, %483 ], [ %211, %355 ]
  %499 = phi float [ %495, %483 ], [ %212, %355 ]
  %500 = add i32 %34, -1
  %501 = call i32 @dx.op.binary.i32(i32 37, i32 %500, i32 0)  ; IMax(a,b)
  %502 = call i32 @dx.op.binary.i32(i32 37, i32 %35, i32 0)  ; IMax(a,b)
  %503 = call i32 @dx.op.binary.i32(i32 38, i32 %501, i32 %30)  ; IMin(a,b)
  %504 = call i32 @dx.op.binary.i32(i32 38, i32 %502, i32 %31)  ; IMin(a,b)
  %505 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %503, i32 %504, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %506 = extractvalue %dx.types.ResRet.f32 %505, 0
  %507 = fsub fast float %506, %53
  %508 = call float @dx.op.unary.f32(i32 6, float %507)  ; FAbs(value)
  %509 = fdiv fast float %508, %222
  %510 = fsub fast float 1.000000e+00, %509
  %511 = call float @dx.op.unary.f32(i32 7, float %510)  ; Saturate(value)
  %512 = fcmp fast ugt float %511, 0.000000e+00
  br i1 %512, label %513, label %639

; <label>:513                                     ; preds = %496
  %514 = call i32 @dx.op.binary.i32(i32 37, i32 %503, i32 0)  ; IMax(a,b)
  %515 = call i32 @dx.op.binary.i32(i32 37, i32 %504, i32 0)  ; IMax(a,b)
  %516 = call i32 @dx.op.binary.i32(i32 38, i32 %514, i32 %30)  ; IMin(a,b)
  %517 = call i32 @dx.op.binary.i32(i32 38, i32 %515, i32 %31)  ; IMin(a,b)
  %518 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %516, i32 %517, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %519 = extractvalue %dx.types.ResRet.f32 %518, 0
  %520 = extractvalue %dx.types.ResRet.f32 %518, 1
  %521 = extractvalue %dx.types.ResRet.f32 %518, 2
  %522 = extractvalue %dx.types.ResRet.f32 %518, 3
  %523 = fcmp fast olt float %522, 0.000000e+00
  br i1 %523, label %524, label %558

; <label>:524                                     ; preds = %513
  %525 = fcmp fast ogt float %519, 0x3FA4B5DCC0000000
  %526 = fcmp fast ogt float %520, 0x3FA4B5DCC0000000
  %527 = fcmp fast ogt float %521, 0x3FA4B5DCC0000000
  %528 = select i1 %525, float 0.000000e+00, float 1.000000e+00
  %529 = select i1 %526, float 0.000000e+00, float 1.000000e+00
  %530 = select i1 %527, float 0.000000e+00, float 1.000000e+00
  %531 = fmul fast float %519, 0x3FB3D07220000000
  %532 = fmul fast float %520, 0x3FB3D07220000000
  %533 = fmul fast float %521, 0x3FB3D07220000000
  %534 = fadd fast float %519, 0x3FAC28F5C0000000
  %535 = fadd fast float %520, 0x3FAC28F5C0000000
  %536 = fadd fast float %521, 0x3FAC28F5C0000000
  %537 = fmul fast float %534, 0x3FEE54EDE0000000
  %538 = fmul fast float %535, 0x3FEE54EDE0000000
  %539 = fmul fast float %536, 0x3FEE54EDE0000000
  %540 = call float @dx.op.unary.f32(i32 23, float %537)  ; Log(value)
  %541 = call float @dx.op.unary.f32(i32 23, float %538)  ; Log(value)
  %542 = call float @dx.op.unary.f32(i32 23, float %539)  ; Log(value)
  %543 = fmul fast float %540, 0x4003333340000000
  %544 = fmul fast float %541, 0x4003333340000000
  %545 = fmul fast float %542, 0x4003333340000000
  %546 = call float @dx.op.unary.f32(i32 21, float %543)  ; Exp(value)
  %547 = call float @dx.op.unary.f32(i32 21, float %544)  ; Exp(value)
  %548 = call float @dx.op.unary.f32(i32 21, float %545)  ; Exp(value)
  %549 = fsub fast float %531, %546
  %550 = fsub fast float %532, %547
  %551 = fsub fast float %533, %548
  %552 = fmul fast float %549, %528
  %553 = fmul fast float %550, %529
  %554 = fmul fast float %551, %530
  %555 = fadd fast float %552, %546
  %556 = fadd fast float %553, %547
  %557 = fadd fast float %554, %548
  br label %626

; <label>:558                                     ; preds = %513
  %559 = fadd fast float %5, 1.000000e+00
  %560 = fadd fast float %6, 1.000000e+00
  %561 = fsub fast float 1.000000e+00, %5
  %562 = fmul fast float %9, %559
  %563 = fmul fast float %9, %560
  %564 = fmul fast float %9, %561
  %565 = fmul fast float %562, %519
  %566 = fmul fast float %563, %520
  %567 = fmul fast float %564, %521
  %568 = fcmp fast ult float %10, 5.000000e-01
  br i1 %568, label %594, label %569

; <label>:569                                     ; preds = %558
  %570 = fmul fast float %565, 0x4004147AE0000000
  %571 = fmul fast float %566, 0x4004147AE0000000
  %572 = fmul fast float %567, 0x4004147AE0000000
  %573 = fadd fast float %570, 0x3F9EB851E0000000
  %574 = fadd fast float %571, 0x3F9EB851E0000000
  %575 = fadd fast float %572, 0x3F9EB851E0000000
  %576 = fmul fast float %573, %565
  %577 = fmul fast float %574, %566
  %578 = fmul fast float %575, %567
  %579 = fmul fast float %565, 0x400370A3E0000000
  %580 = fmul fast float %566, 0x400370A3E0000000
  %581 = fmul fast float %567, 0x400370A3E0000000
  %582 = fadd fast float %579, 0x3FE2E147A0000000
  %583 = fadd fast float %580, 0x3FE2E147A0000000
  %584 = fadd fast float %581, 0x3FE2E147A0000000
  %585 = fmul fast float %582, %565
  %586 = fmul fast float %583, %566
  %587 = fmul fast float %584, %567
  %588 = fadd fast float %585, 0x3FC1EB8520000000
  %589 = fadd fast float %586, 0x3FC1EB8520000000
  %590 = fadd fast float %587, 0x3FC1EB8520000000
  %591 = fdiv fast float %576, %588
  %592 = fdiv fast float %577, %589
  %593 = fdiv fast float %578, %590
  br label %594

; <label>:594                                     ; preds = %569, %558
  %595 = phi float [ %591, %569 ], [ %565, %558 ]
  %596 = phi float [ %592, %569 ], [ %566, %558 ]
  %597 = phi float [ %593, %569 ], [ %567, %558 ]
  %598 = call float @dx.op.unary.f32(i32 7, float %595)  ; Saturate(value)
  %599 = call float @dx.op.unary.f32(i32 7, float %596)  ; Saturate(value)
  %600 = call float @dx.op.unary.f32(i32 7, float %597)  ; Saturate(value)
  %601 = call float @dx.op.dot3.f32(i32 55, float %598, float %599, float %600, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %602 = fsub fast float %598, %601
  %603 = fsub fast float %599, %601
  %604 = fsub fast float %600, %601
  %605 = fmul fast float %602, %8
  %606 = fmul fast float %603, %8
  %607 = fmul fast float %604, %8
  %608 = fadd fast float %605, %601
  %609 = fadd fast float %606, %601
  %610 = fadd fast float %607, %601
  %611 = call float @dx.op.unary.f32(i32 7, float %608)  ; Saturate(value)
  %612 = call float @dx.op.unary.f32(i32 7, float %609)  ; Saturate(value)
  %613 = call float @dx.op.unary.f32(i32 7, float %610)  ; Saturate(value)
  %614 = fadd fast float %611, 0xBFC70A3D80000000
  %615 = fadd fast float %612, 0xBFC70A3D80000000
  %616 = fadd fast float %613, 0xBFC70A3D80000000
  %617 = fmul fast float %614, %7
  %618 = fmul fast float %615, %7
  %619 = fmul fast float %616, %7
  %620 = fadd fast float %617, 0x3FC70A3D80000000
  %621 = fadd fast float %618, 0x3FC70A3D80000000
  %622 = fadd fast float %619, 0x3FC70A3D80000000
  %623 = call float @dx.op.unary.f32(i32 7, float %620)  ; Saturate(value)
  %624 = call float @dx.op.unary.f32(i32 7, float %621)  ; Saturate(value)
  %625 = call float @dx.op.unary.f32(i32 7, float %622)  ; Saturate(value)
  br label %626

; <label>:626                                     ; preds = %594, %524
  %627 = phi float [ %555, %524 ], [ %623, %594 ]
  %628 = phi float [ %556, %524 ], [ %624, %594 ]
  %629 = phi float [ %557, %524 ], [ %625, %594 ]
  %630 = fsub fast float %627, %210
  %631 = fsub fast float %628, %211
  %632 = fsub fast float %629, %212
  %633 = fmul fast float %630, %511
  %634 = fmul fast float %631, %511
  %635 = fmul fast float %632, %511
  %636 = fadd fast float %633, %210
  %637 = fadd fast float %634, %211
  %638 = fadd fast float %635, %212
  br label %639

; <label>:639                                     ; preds = %626, %496
  %640 = phi float [ %636, %626 ], [ %210, %496 ]
  %641 = phi float [ %637, %626 ], [ %211, %496 ]
  %642 = phi float [ %638, %626 ], [ %212, %496 ]
  %643 = add i32 %34, 1
  %644 = call i32 @dx.op.binary.i32(i32 37, i32 %643, i32 0)  ; IMax(a,b)
  %645 = call i32 @dx.op.binary.i32(i32 38, i32 %644, i32 %30)  ; IMin(a,b)
  %646 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %645, i32 %504, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %647 = extractvalue %dx.types.ResRet.f32 %646, 0
  %648 = fsub fast float %647, %53
  %649 = call float @dx.op.unary.f32(i32 6, float %648)  ; FAbs(value)
  %650 = fdiv fast float %649, %222
  %651 = fsub fast float 1.000000e+00, %650
  %652 = call float @dx.op.unary.f32(i32 7, float %651)  ; Saturate(value)
  %653 = fcmp fast ugt float %652, 0.000000e+00
  br i1 %653, label %654, label %780

; <label>:654                                     ; preds = %639
  %655 = call i32 @dx.op.binary.i32(i32 37, i32 %645, i32 0)  ; IMax(a,b)
  %656 = call i32 @dx.op.binary.i32(i32 37, i32 %504, i32 0)  ; IMax(a,b)
  %657 = call i32 @dx.op.binary.i32(i32 38, i32 %655, i32 %30)  ; IMin(a,b)
  %658 = call i32 @dx.op.binary.i32(i32 38, i32 %656, i32 %31)  ; IMin(a,b)
  %659 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %657, i32 %658, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %660 = extractvalue %dx.types.ResRet.f32 %659, 0
  %661 = extractvalue %dx.types.ResRet.f32 %659, 1
  %662 = extractvalue %dx.types.ResRet.f32 %659, 2
  %663 = extractvalue %dx.types.ResRet.f32 %659, 3
  %664 = fcmp fast olt float %663, 0.000000e+00
  br i1 %664, label %665, label %699

; <label>:665                                     ; preds = %654
  %666 = fcmp fast ogt float %660, 0x3FA4B5DCC0000000
  %667 = fcmp fast ogt float %661, 0x3FA4B5DCC0000000
  %668 = fcmp fast ogt float %662, 0x3FA4B5DCC0000000
  %669 = select i1 %666, float 0.000000e+00, float 1.000000e+00
  %670 = select i1 %667, float 0.000000e+00, float 1.000000e+00
  %671 = select i1 %668, float 0.000000e+00, float 1.000000e+00
  %672 = fmul fast float %660, 0x3FB3D07220000000
  %673 = fmul fast float %661, 0x3FB3D07220000000
  %674 = fmul fast float %662, 0x3FB3D07220000000
  %675 = fadd fast float %660, 0x3FAC28F5C0000000
  %676 = fadd fast float %661, 0x3FAC28F5C0000000
  %677 = fadd fast float %662, 0x3FAC28F5C0000000
  %678 = fmul fast float %675, 0x3FEE54EDE0000000
  %679 = fmul fast float %676, 0x3FEE54EDE0000000
  %680 = fmul fast float %677, 0x3FEE54EDE0000000
  %681 = call float @dx.op.unary.f32(i32 23, float %678)  ; Log(value)
  %682 = call float @dx.op.unary.f32(i32 23, float %679)  ; Log(value)
  %683 = call float @dx.op.unary.f32(i32 23, float %680)  ; Log(value)
  %684 = fmul fast float %681, 0x4003333340000000
  %685 = fmul fast float %682, 0x4003333340000000
  %686 = fmul fast float %683, 0x4003333340000000
  %687 = call float @dx.op.unary.f32(i32 21, float %684)  ; Exp(value)
  %688 = call float @dx.op.unary.f32(i32 21, float %685)  ; Exp(value)
  %689 = call float @dx.op.unary.f32(i32 21, float %686)  ; Exp(value)
  %690 = fsub fast float %672, %687
  %691 = fsub fast float %673, %688
  %692 = fsub fast float %674, %689
  %693 = fmul fast float %690, %669
  %694 = fmul fast float %691, %670
  %695 = fmul fast float %692, %671
  %696 = fadd fast float %693, %687
  %697 = fadd fast float %694, %688
  %698 = fadd fast float %695, %689
  br label %767

; <label>:699                                     ; preds = %654
  %700 = fadd fast float %5, 1.000000e+00
  %701 = fadd fast float %6, 1.000000e+00
  %702 = fsub fast float 1.000000e+00, %5
  %703 = fmul fast float %9, %700
  %704 = fmul fast float %9, %701
  %705 = fmul fast float %9, %702
  %706 = fmul fast float %703, %660
  %707 = fmul fast float %704, %661
  %708 = fmul fast float %705, %662
  %709 = fcmp fast ult float %10, 5.000000e-01
  br i1 %709, label %735, label %710

; <label>:710                                     ; preds = %699
  %711 = fmul fast float %706, 0x4004147AE0000000
  %712 = fmul fast float %707, 0x4004147AE0000000
  %713 = fmul fast float %708, 0x4004147AE0000000
  %714 = fadd fast float %711, 0x3F9EB851E0000000
  %715 = fadd fast float %712, 0x3F9EB851E0000000
  %716 = fadd fast float %713, 0x3F9EB851E0000000
  %717 = fmul fast float %714, %706
  %718 = fmul fast float %715, %707
  %719 = fmul fast float %716, %708
  %720 = fmul fast float %706, 0x400370A3E0000000
  %721 = fmul fast float %707, 0x400370A3E0000000
  %722 = fmul fast float %708, 0x400370A3E0000000
  %723 = fadd fast float %720, 0x3FE2E147A0000000
  %724 = fadd fast float %721, 0x3FE2E147A0000000
  %725 = fadd fast float %722, 0x3FE2E147A0000000
  %726 = fmul fast float %723, %706
  %727 = fmul fast float %724, %707
  %728 = fmul fast float %725, %708
  %729 = fadd fast float %726, 0x3FC1EB8520000000
  %730 = fadd fast float %727, 0x3FC1EB8520000000
  %731 = fadd fast float %728, 0x3FC1EB8520000000
  %732 = fdiv fast float %717, %729
  %733 = fdiv fast float %718, %730
  %734 = fdiv fast float %719, %731
  br label %735

; <label>:735                                     ; preds = %710, %699
  %736 = phi float [ %732, %710 ], [ %706, %699 ]
  %737 = phi float [ %733, %710 ], [ %707, %699 ]
  %738 = phi float [ %734, %710 ], [ %708, %699 ]
  %739 = call float @dx.op.unary.f32(i32 7, float %736)  ; Saturate(value)
  %740 = call float @dx.op.unary.f32(i32 7, float %737)  ; Saturate(value)
  %741 = call float @dx.op.unary.f32(i32 7, float %738)  ; Saturate(value)
  %742 = call float @dx.op.dot3.f32(i32 55, float %739, float %740, float %741, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %743 = fsub fast float %739, %742
  %744 = fsub fast float %740, %742
  %745 = fsub fast float %741, %742
  %746 = fmul fast float %743, %8
  %747 = fmul fast float %744, %8
  %748 = fmul fast float %745, %8
  %749 = fadd fast float %746, %742
  %750 = fadd fast float %747, %742
  %751 = fadd fast float %748, %742
  %752 = call float @dx.op.unary.f32(i32 7, float %749)  ; Saturate(value)
  %753 = call float @dx.op.unary.f32(i32 7, float %750)  ; Saturate(value)
  %754 = call float @dx.op.unary.f32(i32 7, float %751)  ; Saturate(value)
  %755 = fadd fast float %752, 0xBFC70A3D80000000
  %756 = fadd fast float %753, 0xBFC70A3D80000000
  %757 = fadd fast float %754, 0xBFC70A3D80000000
  %758 = fmul fast float %755, %7
  %759 = fmul fast float %756, %7
  %760 = fmul fast float %757, %7
  %761 = fadd fast float %758, 0x3FC70A3D80000000
  %762 = fadd fast float %759, 0x3FC70A3D80000000
  %763 = fadd fast float %760, 0x3FC70A3D80000000
  %764 = call float @dx.op.unary.f32(i32 7, float %761)  ; Saturate(value)
  %765 = call float @dx.op.unary.f32(i32 7, float %762)  ; Saturate(value)
  %766 = call float @dx.op.unary.f32(i32 7, float %763)  ; Saturate(value)
  br label %767

; <label>:767                                     ; preds = %735, %665
  %768 = phi float [ %696, %665 ], [ %764, %735 ]
  %769 = phi float [ %697, %665 ], [ %765, %735 ]
  %770 = phi float [ %698, %665 ], [ %766, %735 ]
  %771 = fsub fast float %768, %210
  %772 = fsub fast float %769, %211
  %773 = fsub fast float %770, %212
  %774 = fmul fast float %771, %652
  %775 = fmul fast float %772, %652
  %776 = fmul fast float %773, %652
  %777 = fadd fast float %774, %210
  %778 = fadd fast float %775, %211
  %779 = fadd fast float %776, %212
  br label %780

; <label>:780                                     ; preds = %767, %639
  %781 = phi float [ %777, %767 ], [ %210, %639 ]
  %782 = phi float [ %778, %767 ], [ %211, %639 ]
  %783 = phi float [ %779, %767 ], [ %212, %639 ]
  %784 = call float @dx.op.binary.f32(i32 36, float %640, float %781)  ; FMin(a,b)
  %785 = call float @dx.op.binary.f32(i32 36, float %641, float %782)  ; FMin(a,b)
  %786 = call float @dx.op.binary.f32(i32 36, float %642, float %783)  ; FMin(a,b)
  %787 = call float @dx.op.binary.f32(i32 36, float %356, float %497)  ; FMin(a,b)
  %788 = call float @dx.op.binary.f32(i32 36, float %357, float %498)  ; FMin(a,b)
  %789 = call float @dx.op.binary.f32(i32 36, float %358, float %499)  ; FMin(a,b)
  %790 = call float @dx.op.binary.f32(i32 36, float %787, float %784)  ; FMin(a,b)
  %791 = call float @dx.op.binary.f32(i32 36, float %788, float %785)  ; FMin(a,b)
  %792 = call float @dx.op.binary.f32(i32 36, float %789, float %786)  ; FMin(a,b)
  %793 = call float @dx.op.binary.f32(i32 36, float %210, float %790)  ; FMin(a,b)
  %794 = call float @dx.op.binary.f32(i32 36, float %211, float %791)  ; FMin(a,b)
  %795 = call float @dx.op.binary.f32(i32 36, float %212, float %792)  ; FMin(a,b)
  %796 = call float @dx.op.binary.f32(i32 35, float %640, float %781)  ; FMax(a,b)
  %797 = call float @dx.op.binary.f32(i32 35, float %641, float %782)  ; FMax(a,b)
  %798 = call float @dx.op.binary.f32(i32 35, float %642, float %783)  ; FMax(a,b)
  %799 = call float @dx.op.binary.f32(i32 35, float %356, float %497)  ; FMax(a,b)
  %800 = call float @dx.op.binary.f32(i32 35, float %357, float %498)  ; FMax(a,b)
  %801 = call float @dx.op.binary.f32(i32 35, float %358, float %499)  ; FMax(a,b)
  %802 = call float @dx.op.binary.f32(i32 35, float %799, float %796)  ; FMax(a,b)
  %803 = call float @dx.op.binary.f32(i32 35, float %800, float %797)  ; FMax(a,b)
  %804 = call float @dx.op.binary.f32(i32 35, float %801, float %798)  ; FMax(a,b)
  %805 = call float @dx.op.binary.f32(i32 35, float %210, float %802)  ; FMax(a,b)
  %806 = call float @dx.op.binary.f32(i32 35, float %211, float %803)  ; FMax(a,b)
  %807 = call float @dx.op.binary.f32(i32 35, float %212, float %804)  ; FMax(a,b)
  %808 = fsub fast float %805, %793
  %809 = fsub fast float %806, %794
  %810 = fsub fast float %807, %795
  %811 = call float @dx.op.unary.f32(i32 6, float %808)  ; FAbs(value)
  %812 = call float @dx.op.unary.f32(i32 6, float %809)  ; FAbs(value)
  %813 = call float @dx.op.unary.f32(i32 6, float %810)  ; FAbs(value)
  %814 = call float @dx.op.binary.f32(i32 35, float %812, float %813)  ; FMax(a,b)
  %815 = call float @dx.op.binary.f32(i32 35, float %811, float %814)  ; FMax(a,b)
  %816 = call float @dx.op.binary.f32(i32 35, float %806, float %807)  ; FMax(a,b)
  %817 = call float @dx.op.binary.f32(i32 35, float %805, float %816)  ; FMax(a,b)
  %818 = fmul fast float %817, 1.250000e-01
  %819 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %818)  ; FMax(a,b)
  %820 = fcmp fast ogt float %815, %819
  br i1 %820, label %821, label %882

; <label>:821                                     ; preds = %780
  %822 = fsub fast float %356, %497
  %823 = fsub fast float %357, %498
  %824 = fsub fast float %358, %499
  %825 = call float @dx.op.unary.f32(i32 6, float %822)  ; FAbs(value)
  %826 = call float @dx.op.unary.f32(i32 6, float %823)  ; FAbs(value)
  %827 = call float @dx.op.unary.f32(i32 6, float %824)  ; FAbs(value)
  %828 = call float @dx.op.binary.f32(i32 35, float %826, float %827)  ; FMax(a,b)
  %829 = call float @dx.op.binary.f32(i32 35, float %825, float %828)  ; FMax(a,b)
  %830 = fsub fast float %640, %781
  %831 = fsub fast float %641, %782
  %832 = fsub fast float %642, %783
  %833 = call float @dx.op.unary.f32(i32 6, float %830)  ; FAbs(value)
  %834 = call float @dx.op.unary.f32(i32 6, float %831)  ; FAbs(value)
  %835 = call float @dx.op.unary.f32(i32 6, float %832)  ; FAbs(value)
  %836 = call float @dx.op.binary.f32(i32 35, float %834, float %835)  ; FMax(a,b)
  %837 = call float @dx.op.binary.f32(i32 35, float %833, float %836)  ; FMax(a,b)
  %838 = fcmp fast olt float %829, %837
  %839 = select i1 %838, float %356, float %640
  %840 = select i1 %838, float %357, float %641
  %841 = select i1 %838, float %358, float %642
  %842 = select i1 %838, float %497, float %781
  %843 = select i1 %838, float %498, float %782
  %844 = select i1 %838, float %499, float %783
  %845 = fsub fast float %210, %842
  %846 = fsub fast float %211, %843
  %847 = fsub fast float %212, %844
  %848 = fsub fast float %210, %839
  %849 = fsub fast float %211, %840
  %850 = fsub fast float %212, %841
  %851 = call float @dx.op.dot3.f32(i32 55, float %848, float %849, float %850, float %845, float %846, float %847)  ; Dot3(ax,ay,az,bx,by,bz)
  %852 = fcmp fast ogt float %851, 0.000000e+00
  br i1 %852, label %853, label %864

; <label>:853                                     ; preds = %821
  %854 = fsub fast float %839, %842
  %855 = fsub fast float %840, %843
  %856 = fsub fast float %841, %844
  %857 = call float @dx.op.unary.f32(i32 6, float %854)  ; FAbs(value)
  %858 = call float @dx.op.unary.f32(i32 6, float %855)  ; FAbs(value)
  %859 = call float @dx.op.unary.f32(i32 6, float %856)  ; FAbs(value)
  %860 = call float @dx.op.binary.f32(i32 35, float %858, float %859)  ; FMax(a,b)
  %861 = call float @dx.op.binary.f32(i32 35, float %857, float %860)  ; FMax(a,b)
  %862 = fmul fast float %815, 2.500000e-01
  %863 = fcmp fast olt float %861, %862
  br label %864

; <label>:864                                     ; preds = %853, %821
  %865 = phi i1 [ false, %821 ], [ %863, %853 ]
  %866 = select i1 %865, float 0x3FC3333340000000, float 0x3FD3333340000000
  %867 = fadd fast float %839, %842
  %868 = fadd fast float %840, %843
  %869 = fadd fast float %841, %844
  %870 = fmul fast float %867, 5.000000e-01
  %871 = fmul fast float %868, 5.000000e-01
  %872 = fmul fast float %869, 5.000000e-01
  %873 = fsub fast float %870, %210
  %874 = fsub fast float %871, %211
  %875 = fsub fast float %872, %212
  %876 = fmul fast float %866, %873
  %877 = fmul fast float %866, %874
  %878 = fmul fast float %866, %875
  %879 = fadd fast float %876, %210
  %880 = fadd fast float %877, %211
  %881 = fadd fast float %878, %212
  br label %882

; <label>:882                                     ; preds = %864, %780
  %883 = phi float [ %879, %864 ], [ %210, %780 ]
  %884 = phi float [ %880, %864 ], [ %211, %780 ]
  %885 = phi float [ %881, %864 ], [ %212, %780 ]
  %886 = fcmp fast ogt float %883, 0x3F69A5C380000000
  %887 = fcmp fast ogt float %884, 0x3F69A5C380000000
  %888 = fcmp fast ogt float %885, 0x3F69A5C380000000
  %889 = select i1 %886, float 0.000000e+00, float 1.000000e+00
  %890 = select i1 %887, float 0.000000e+00, float 1.000000e+00
  %891 = select i1 %888, float 0.000000e+00, float 1.000000e+00
  %892 = fmul fast float %883, 0x4029D70A40000000
  %893 = fmul fast float %884, 0x4029D70A40000000
  %894 = fmul fast float %885, 0x4029D70A40000000
  %895 = call float @dx.op.binary.f32(i32 35, float %883, float 0.000000e+00)  ; FMax(a,b)
  %896 = call float @dx.op.binary.f32(i32 35, float %884, float 0.000000e+00)  ; FMax(a,b)
  %897 = call float @dx.op.binary.f32(i32 35, float %885, float 0.000000e+00)  ; FMax(a,b)
  %898 = call float @dx.op.unary.f32(i32 23, float %895)  ; Log(value)
  %899 = call float @dx.op.unary.f32(i32 23, float %896)  ; Log(value)
  %900 = call float @dx.op.unary.f32(i32 23, float %897)  ; Log(value)
  %901 = fmul fast float %898, 0x3FDAAAAAA0000000
  %902 = fmul fast float %899, 0x3FDAAAAAA0000000
  %903 = fmul fast float %900, 0x3FDAAAAAA0000000
  %904 = call float @dx.op.unary.f32(i32 21, float %901)  ; Exp(value)
  %905 = call float @dx.op.unary.f32(i32 21, float %902)  ; Exp(value)
  %906 = call float @dx.op.unary.f32(i32 21, float %903)  ; Exp(value)
  %907 = fmul fast float %904, 0x3FF0E147A0000000
  %908 = fmul fast float %905, 0x3FF0E147A0000000
  %909 = fmul fast float %906, 0x3FF0E147A0000000
  %910 = fadd fast float %907, 0xBFAC28F5C0000000
  %911 = fadd fast float %908, 0xBFAC28F5C0000000
  %912 = fadd fast float %909, 0xBFAC28F5C0000000
  %913 = fsub fast float %892, %910
  %914 = fsub fast float %893, %911
  %915 = fsub fast float %894, %912
  %916 = fmul fast float %913, %889
  %917 = fmul fast float %914, %890
  %918 = fmul fast float %915, %891
  %919 = fadd fast float %916, %910
  %920 = fadd fast float %917, %911
  %921 = fadd fast float %918, %912
  br label %922

; <label>:922                                     ; preds = %882, %143
  %923 = phi float [ %138, %143 ], [ %919, %882 ]
  %924 = phi float [ %139, %143 ], [ %920, %882 ]
  %925 = phi float [ %140, %143 ], [ %921, %882 ]
  %926 = phi float [ %144, %143 ], [ %141, %882 ]
  %927 = fcmp fast ogt float %923, 0x3FA4B5DCC0000000
  %928 = fcmp fast ogt float %924, 0x3FA4B5DCC0000000
  %929 = fcmp fast ogt float %925, 0x3FA4B5DCC0000000
  %930 = select i1 %927, float 0.000000e+00, float 1.000000e+00
  %931 = select i1 %928, float 0.000000e+00, float 1.000000e+00
  %932 = select i1 %929, float 0.000000e+00, float 1.000000e+00
  %933 = fmul fast float %923, 0x3FB3D07220000000
  %934 = fmul fast float %924, 0x3FB3D07220000000
  %935 = fmul fast float %925, 0x3FB3D07220000000
  %936 = fadd fast float %923, 0x3FAC28F5C0000000
  %937 = fadd fast float %924, 0x3FAC28F5C0000000
  %938 = fadd fast float %925, 0x3FAC28F5C0000000
  %939 = fmul fast float %936, 0x3FEE54EDE0000000
  %940 = fmul fast float %937, 0x3FEE54EDE0000000
  %941 = fmul fast float %938, 0x3FEE54EDE0000000
  %942 = call float @dx.op.unary.f32(i32 23, float %939)  ; Log(value)
  %943 = call float @dx.op.unary.f32(i32 23, float %940)  ; Log(value)
  %944 = call float @dx.op.unary.f32(i32 23, float %941)  ; Log(value)
  %945 = fmul fast float %942, 0x4003333340000000
  %946 = fmul fast float %943, 0x4003333340000000
  %947 = fmul fast float %944, 0x4003333340000000
  %948 = call float @dx.op.unary.f32(i32 21, float %945)  ; Exp(value)
  %949 = call float @dx.op.unary.f32(i32 21, float %946)  ; Exp(value)
  %950 = call float @dx.op.unary.f32(i32 21, float %947)  ; Exp(value)
  %951 = fsub fast float %933, %948
  %952 = fsub fast float %934, %949
  %953 = fsub fast float %935, %950
  %954 = fmul fast float %951, %930
  %955 = fmul fast float %952, %931
  %956 = fmul fast float %953, %932
  %957 = fadd fast float %954, %948
  %958 = fadd fast float %955, %949
  %959 = fadd fast float %956, %950
  %960 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %38, i32 %35, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %961 = extractvalue %dx.types.ResRet.f32 %960, 0
  %962 = extractvalue %dx.types.ResRet.f32 %960, 1
  %963 = extractvalue %dx.types.ResRet.f32 %960, 2
  %964 = extractvalue %dx.types.ResRet.f32 %960, 3
  %965 = fcmp fast olt float %964, 0.000000e+00
  br i1 %965, label %966, label %968

; <label>:966                                     ; preds = %922
  %967 = fsub fast float -1.000000e+00, %964
  br label %1745

; <label>:968                                     ; preds = %922
  %969 = fadd fast float %5, 1.000000e+00
  %970 = fadd fast float %6, 1.000000e+00
  %971 = fsub fast float 1.000000e+00, %5
  %972 = fmul fast float %9, %969
  %973 = fmul fast float %9, %970
  %974 = fmul fast float %9, %971
  %975 = fmul fast float %972, %961
  %976 = fmul fast float %973, %962
  %977 = fmul fast float %974, %963
  %978 = fcmp fast ult float %10, 5.000000e-01
  br i1 %978, label %1004, label %979

; <label>:979                                     ; preds = %968
  %980 = fmul fast float %975, 0x4004147AE0000000
  %981 = fmul fast float %976, 0x4004147AE0000000
  %982 = fmul fast float %977, 0x4004147AE0000000
  %983 = fadd fast float %980, 0x3F9EB851E0000000
  %984 = fadd fast float %981, 0x3F9EB851E0000000
  %985 = fadd fast float %982, 0x3F9EB851E0000000
  %986 = fmul fast float %983, %975
  %987 = fmul fast float %984, %976
  %988 = fmul fast float %985, %977
  %989 = fmul fast float %975, 0x400370A3E0000000
  %990 = fmul fast float %976, 0x400370A3E0000000
  %991 = fmul fast float %977, 0x400370A3E0000000
  %992 = fadd fast float %989, 0x3FE2E147A0000000
  %993 = fadd fast float %990, 0x3FE2E147A0000000
  %994 = fadd fast float %991, 0x3FE2E147A0000000
  %995 = fmul fast float %992, %975
  %996 = fmul fast float %993, %976
  %997 = fmul fast float %994, %977
  %998 = fadd fast float %995, 0x3FC1EB8520000000
  %999 = fadd fast float %996, 0x3FC1EB8520000000
  %1000 = fadd fast float %997, 0x3FC1EB8520000000
  %1001 = fdiv fast float %986, %998
  %1002 = fdiv fast float %987, %999
  %1003 = fdiv fast float %988, %1000
  br label %1004

; <label>:1004                                    ; preds = %979, %968
  %1005 = phi float [ %1001, %979 ], [ %975, %968 ]
  %1006 = phi float [ %1002, %979 ], [ %976, %968 ]
  %1007 = phi float [ %1003, %979 ], [ %977, %968 ]
  %1008 = call float @dx.op.unary.f32(i32 7, float %1005)  ; Saturate(value)
  %1009 = call float @dx.op.unary.f32(i32 7, float %1006)  ; Saturate(value)
  %1010 = call float @dx.op.unary.f32(i32 7, float %1007)  ; Saturate(value)
  %1011 = call float @dx.op.dot3.f32(i32 55, float %1008, float %1009, float %1010, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1012 = fsub fast float %1008, %1011
  %1013 = fsub fast float %1009, %1011
  %1014 = fsub fast float %1010, %1011
  %1015 = fmul fast float %1012, %8
  %1016 = fmul fast float %1013, %8
  %1017 = fmul fast float %1014, %8
  %1018 = fadd fast float %1015, %1011
  %1019 = fadd fast float %1016, %1011
  %1020 = fadd fast float %1017, %1011
  %1021 = call float @dx.op.unary.f32(i32 7, float %1018)  ; Saturate(value)
  %1022 = call float @dx.op.unary.f32(i32 7, float %1019)  ; Saturate(value)
  %1023 = call float @dx.op.unary.f32(i32 7, float %1020)  ; Saturate(value)
  %1024 = fadd fast float %1021, 0xBFC70A3D80000000
  %1025 = fadd fast float %1022, 0xBFC70A3D80000000
  %1026 = fadd fast float %1023, 0xBFC70A3D80000000
  %1027 = fmul fast float %1024, %7
  %1028 = fmul fast float %1025, %7
  %1029 = fmul fast float %1026, %7
  %1030 = fadd fast float %1027, 0x3FC70A3D80000000
  %1031 = fadd fast float %1028, 0x3FC70A3D80000000
  %1032 = fadd fast float %1029, 0x3FC70A3D80000000
  %1033 = call float @dx.op.unary.f32(i32 7, float %1030)  ; Saturate(value)
  %1034 = call float @dx.op.unary.f32(i32 7, float %1031)  ; Saturate(value)
  %1035 = call float @dx.op.unary.f32(i32 7, float %1032)  ; Saturate(value)
  %1036 = add i32 %35, -1
  %1037 = call i32 @dx.op.binary.i32(i32 37, i32 %38, i32 0)  ; IMax(a,b)
  %1038 = call i32 @dx.op.binary.i32(i32 37, i32 %1036, i32 0)  ; IMax(a,b)
  %1039 = call i32 @dx.op.binary.i32(i32 38, i32 %1037, i32 %30)  ; IMin(a,b)
  %1040 = call i32 @dx.op.binary.i32(i32 38, i32 %1038, i32 %31)  ; IMin(a,b)
  %1041 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1039, i32 %1040, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1042 = extractvalue %dx.types.ResRet.f32 %1041, 0
  %1043 = fsub fast float 1.000000e+00, %55
  %1044 = fmul fast float %1043, 0x3FA99999A0000000
  %1045 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %1044)  ; FMax(a,b)
  %1046 = fsub fast float %1042, %55
  %1047 = call float @dx.op.unary.f32(i32 6, float %1046)  ; FAbs(value)
  %1048 = fdiv fast float %1047, %1045
  %1049 = fsub fast float 1.000000e+00, %1048
  %1050 = call float @dx.op.unary.f32(i32 7, float %1049)  ; Saturate(value)
  %1051 = fcmp fast ugt float %1050, 0.000000e+00
  br i1 %1051, label %1052, label %1178

; <label>:1052                                    ; preds = %1004
  %1053 = call i32 @dx.op.binary.i32(i32 37, i32 %1039, i32 0)  ; IMax(a,b)
  %1054 = call i32 @dx.op.binary.i32(i32 37, i32 %1040, i32 0)  ; IMax(a,b)
  %1055 = call i32 @dx.op.binary.i32(i32 38, i32 %1053, i32 %30)  ; IMin(a,b)
  %1056 = call i32 @dx.op.binary.i32(i32 38, i32 %1054, i32 %31)  ; IMin(a,b)
  %1057 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1055, i32 %1056, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1058 = extractvalue %dx.types.ResRet.f32 %1057, 0
  %1059 = extractvalue %dx.types.ResRet.f32 %1057, 1
  %1060 = extractvalue %dx.types.ResRet.f32 %1057, 2
  %1061 = extractvalue %dx.types.ResRet.f32 %1057, 3
  %1062 = fcmp fast olt float %1061, 0.000000e+00
  br i1 %1062, label %1063, label %1097

; <label>:1063                                    ; preds = %1052
  %1064 = fcmp fast ogt float %1058, 0x3FA4B5DCC0000000
  %1065 = fcmp fast ogt float %1059, 0x3FA4B5DCC0000000
  %1066 = fcmp fast ogt float %1060, 0x3FA4B5DCC0000000
  %1067 = select i1 %1064, float 0.000000e+00, float 1.000000e+00
  %1068 = select i1 %1065, float 0.000000e+00, float 1.000000e+00
  %1069 = select i1 %1066, float 0.000000e+00, float 1.000000e+00
  %1070 = fmul fast float %1058, 0x3FB3D07220000000
  %1071 = fmul fast float %1059, 0x3FB3D07220000000
  %1072 = fmul fast float %1060, 0x3FB3D07220000000
  %1073 = fadd fast float %1058, 0x3FAC28F5C0000000
  %1074 = fadd fast float %1059, 0x3FAC28F5C0000000
  %1075 = fadd fast float %1060, 0x3FAC28F5C0000000
  %1076 = fmul fast float %1073, 0x3FEE54EDE0000000
  %1077 = fmul fast float %1074, 0x3FEE54EDE0000000
  %1078 = fmul fast float %1075, 0x3FEE54EDE0000000
  %1079 = call float @dx.op.unary.f32(i32 23, float %1076)  ; Log(value)
  %1080 = call float @dx.op.unary.f32(i32 23, float %1077)  ; Log(value)
  %1081 = call float @dx.op.unary.f32(i32 23, float %1078)  ; Log(value)
  %1082 = fmul fast float %1079, 0x4003333340000000
  %1083 = fmul fast float %1080, 0x4003333340000000
  %1084 = fmul fast float %1081, 0x4003333340000000
  %1085 = call float @dx.op.unary.f32(i32 21, float %1082)  ; Exp(value)
  %1086 = call float @dx.op.unary.f32(i32 21, float %1083)  ; Exp(value)
  %1087 = call float @dx.op.unary.f32(i32 21, float %1084)  ; Exp(value)
  %1088 = fsub fast float %1070, %1085
  %1089 = fsub fast float %1071, %1086
  %1090 = fsub fast float %1072, %1087
  %1091 = fmul fast float %1088, %1067
  %1092 = fmul fast float %1089, %1068
  %1093 = fmul fast float %1090, %1069
  %1094 = fadd fast float %1091, %1085
  %1095 = fadd fast float %1092, %1086
  %1096 = fadd fast float %1093, %1087
  br label %1165

; <label>:1097                                    ; preds = %1052
  %1098 = fadd fast float %5, 1.000000e+00
  %1099 = fadd fast float %6, 1.000000e+00
  %1100 = fsub fast float 1.000000e+00, %5
  %1101 = fmul fast float %9, %1098
  %1102 = fmul fast float %9, %1099
  %1103 = fmul fast float %9, %1100
  %1104 = fmul fast float %1101, %1058
  %1105 = fmul fast float %1102, %1059
  %1106 = fmul fast float %1103, %1060
  %1107 = fcmp fast ult float %10, 5.000000e-01
  br i1 %1107, label %1133, label %1108

; <label>:1108                                    ; preds = %1097
  %1109 = fmul fast float %1104, 0x4004147AE0000000
  %1110 = fmul fast float %1105, 0x4004147AE0000000
  %1111 = fmul fast float %1106, 0x4004147AE0000000
  %1112 = fadd fast float %1109, 0x3F9EB851E0000000
  %1113 = fadd fast float %1110, 0x3F9EB851E0000000
  %1114 = fadd fast float %1111, 0x3F9EB851E0000000
  %1115 = fmul fast float %1112, %1104
  %1116 = fmul fast float %1113, %1105
  %1117 = fmul fast float %1114, %1106
  %1118 = fmul fast float %1104, 0x400370A3E0000000
  %1119 = fmul fast float %1105, 0x400370A3E0000000
  %1120 = fmul fast float %1106, 0x400370A3E0000000
  %1121 = fadd fast float %1118, 0x3FE2E147A0000000
  %1122 = fadd fast float %1119, 0x3FE2E147A0000000
  %1123 = fadd fast float %1120, 0x3FE2E147A0000000
  %1124 = fmul fast float %1121, %1104
  %1125 = fmul fast float %1122, %1105
  %1126 = fmul fast float %1123, %1106
  %1127 = fadd fast float %1124, 0x3FC1EB8520000000
  %1128 = fadd fast float %1125, 0x3FC1EB8520000000
  %1129 = fadd fast float %1126, 0x3FC1EB8520000000
  %1130 = fdiv fast float %1115, %1127
  %1131 = fdiv fast float %1116, %1128
  %1132 = fdiv fast float %1117, %1129
  br label %1133

; <label>:1133                                    ; preds = %1108, %1097
  %1134 = phi float [ %1130, %1108 ], [ %1104, %1097 ]
  %1135 = phi float [ %1131, %1108 ], [ %1105, %1097 ]
  %1136 = phi float [ %1132, %1108 ], [ %1106, %1097 ]
  %1137 = call float @dx.op.unary.f32(i32 7, float %1134)  ; Saturate(value)
  %1138 = call float @dx.op.unary.f32(i32 7, float %1135)  ; Saturate(value)
  %1139 = call float @dx.op.unary.f32(i32 7, float %1136)  ; Saturate(value)
  %1140 = call float @dx.op.dot3.f32(i32 55, float %1137, float %1138, float %1139, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1141 = fsub fast float %1137, %1140
  %1142 = fsub fast float %1138, %1140
  %1143 = fsub fast float %1139, %1140
  %1144 = fmul fast float %1141, %8
  %1145 = fmul fast float %1142, %8
  %1146 = fmul fast float %1143, %8
  %1147 = fadd fast float %1144, %1140
  %1148 = fadd fast float %1145, %1140
  %1149 = fadd fast float %1146, %1140
  %1150 = call float @dx.op.unary.f32(i32 7, float %1147)  ; Saturate(value)
  %1151 = call float @dx.op.unary.f32(i32 7, float %1148)  ; Saturate(value)
  %1152 = call float @dx.op.unary.f32(i32 7, float %1149)  ; Saturate(value)
  %1153 = fadd fast float %1150, 0xBFC70A3D80000000
  %1154 = fadd fast float %1151, 0xBFC70A3D80000000
  %1155 = fadd fast float %1152, 0xBFC70A3D80000000
  %1156 = fmul fast float %1153, %7
  %1157 = fmul fast float %1154, %7
  %1158 = fmul fast float %1155, %7
  %1159 = fadd fast float %1156, 0x3FC70A3D80000000
  %1160 = fadd fast float %1157, 0x3FC70A3D80000000
  %1161 = fadd fast float %1158, 0x3FC70A3D80000000
  %1162 = call float @dx.op.unary.f32(i32 7, float %1159)  ; Saturate(value)
  %1163 = call float @dx.op.unary.f32(i32 7, float %1160)  ; Saturate(value)
  %1164 = call float @dx.op.unary.f32(i32 7, float %1161)  ; Saturate(value)
  br label %1165

; <label>:1165                                    ; preds = %1133, %1063
  %1166 = phi float [ %1094, %1063 ], [ %1162, %1133 ]
  %1167 = phi float [ %1095, %1063 ], [ %1163, %1133 ]
  %1168 = phi float [ %1096, %1063 ], [ %1164, %1133 ]
  %1169 = fsub fast float %1166, %1033
  %1170 = fsub fast float %1167, %1034
  %1171 = fsub fast float %1168, %1035
  %1172 = fmul fast float %1169, %1050
  %1173 = fmul fast float %1170, %1050
  %1174 = fmul fast float %1171, %1050
  %1175 = fadd fast float %1172, %1033
  %1176 = fadd fast float %1173, %1034
  %1177 = fadd fast float %1174, %1035
  br label %1178

; <label>:1178                                    ; preds = %1165, %1004
  %1179 = phi float [ %1175, %1165 ], [ %1033, %1004 ]
  %1180 = phi float [ %1176, %1165 ], [ %1034, %1004 ]
  %1181 = phi float [ %1177, %1165 ], [ %1035, %1004 ]
  %1182 = add i32 %35, 1
  %1183 = call i32 @dx.op.binary.i32(i32 37, i32 %1182, i32 0)  ; IMax(a,b)
  %1184 = call i32 @dx.op.binary.i32(i32 38, i32 %1183, i32 %31)  ; IMin(a,b)
  %1185 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1039, i32 %1184, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1186 = extractvalue %dx.types.ResRet.f32 %1185, 0
  %1187 = fsub fast float %1186, %55
  %1188 = call float @dx.op.unary.f32(i32 6, float %1187)  ; FAbs(value)
  %1189 = fdiv fast float %1188, %1045
  %1190 = fsub fast float 1.000000e+00, %1189
  %1191 = call float @dx.op.unary.f32(i32 7, float %1190)  ; Saturate(value)
  %1192 = fcmp fast ugt float %1191, 0.000000e+00
  br i1 %1192, label %1193, label %1319

; <label>:1193                                    ; preds = %1178
  %1194 = call i32 @dx.op.binary.i32(i32 37, i32 %1039, i32 0)  ; IMax(a,b)
  %1195 = call i32 @dx.op.binary.i32(i32 37, i32 %1184, i32 0)  ; IMax(a,b)
  %1196 = call i32 @dx.op.binary.i32(i32 38, i32 %1194, i32 %30)  ; IMin(a,b)
  %1197 = call i32 @dx.op.binary.i32(i32 38, i32 %1195, i32 %31)  ; IMin(a,b)
  %1198 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1196, i32 %1197, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1199 = extractvalue %dx.types.ResRet.f32 %1198, 0
  %1200 = extractvalue %dx.types.ResRet.f32 %1198, 1
  %1201 = extractvalue %dx.types.ResRet.f32 %1198, 2
  %1202 = extractvalue %dx.types.ResRet.f32 %1198, 3
  %1203 = fcmp fast olt float %1202, 0.000000e+00
  br i1 %1203, label %1204, label %1238

; <label>:1204                                    ; preds = %1193
  %1205 = fcmp fast ogt float %1199, 0x3FA4B5DCC0000000
  %1206 = fcmp fast ogt float %1200, 0x3FA4B5DCC0000000
  %1207 = fcmp fast ogt float %1201, 0x3FA4B5DCC0000000
  %1208 = select i1 %1205, float 0.000000e+00, float 1.000000e+00
  %1209 = select i1 %1206, float 0.000000e+00, float 1.000000e+00
  %1210 = select i1 %1207, float 0.000000e+00, float 1.000000e+00
  %1211 = fmul fast float %1199, 0x3FB3D07220000000
  %1212 = fmul fast float %1200, 0x3FB3D07220000000
  %1213 = fmul fast float %1201, 0x3FB3D07220000000
  %1214 = fadd fast float %1199, 0x3FAC28F5C0000000
  %1215 = fadd fast float %1200, 0x3FAC28F5C0000000
  %1216 = fadd fast float %1201, 0x3FAC28F5C0000000
  %1217 = fmul fast float %1214, 0x3FEE54EDE0000000
  %1218 = fmul fast float %1215, 0x3FEE54EDE0000000
  %1219 = fmul fast float %1216, 0x3FEE54EDE0000000
  %1220 = call float @dx.op.unary.f32(i32 23, float %1217)  ; Log(value)
  %1221 = call float @dx.op.unary.f32(i32 23, float %1218)  ; Log(value)
  %1222 = call float @dx.op.unary.f32(i32 23, float %1219)  ; Log(value)
  %1223 = fmul fast float %1220, 0x4003333340000000
  %1224 = fmul fast float %1221, 0x4003333340000000
  %1225 = fmul fast float %1222, 0x4003333340000000
  %1226 = call float @dx.op.unary.f32(i32 21, float %1223)  ; Exp(value)
  %1227 = call float @dx.op.unary.f32(i32 21, float %1224)  ; Exp(value)
  %1228 = call float @dx.op.unary.f32(i32 21, float %1225)  ; Exp(value)
  %1229 = fsub fast float %1211, %1226
  %1230 = fsub fast float %1212, %1227
  %1231 = fsub fast float %1213, %1228
  %1232 = fmul fast float %1229, %1208
  %1233 = fmul fast float %1230, %1209
  %1234 = fmul fast float %1231, %1210
  %1235 = fadd fast float %1232, %1226
  %1236 = fadd fast float %1233, %1227
  %1237 = fadd fast float %1234, %1228
  br label %1306

; <label>:1238                                    ; preds = %1193
  %1239 = fadd fast float %5, 1.000000e+00
  %1240 = fadd fast float %6, 1.000000e+00
  %1241 = fsub fast float 1.000000e+00, %5
  %1242 = fmul fast float %9, %1239
  %1243 = fmul fast float %9, %1240
  %1244 = fmul fast float %9, %1241
  %1245 = fmul fast float %1242, %1199
  %1246 = fmul fast float %1243, %1200
  %1247 = fmul fast float %1244, %1201
  %1248 = fcmp fast ult float %10, 5.000000e-01
  br i1 %1248, label %1274, label %1249

; <label>:1249                                    ; preds = %1238
  %1250 = fmul fast float %1245, 0x4004147AE0000000
  %1251 = fmul fast float %1246, 0x4004147AE0000000
  %1252 = fmul fast float %1247, 0x4004147AE0000000
  %1253 = fadd fast float %1250, 0x3F9EB851E0000000
  %1254 = fadd fast float %1251, 0x3F9EB851E0000000
  %1255 = fadd fast float %1252, 0x3F9EB851E0000000
  %1256 = fmul fast float %1253, %1245
  %1257 = fmul fast float %1254, %1246
  %1258 = fmul fast float %1255, %1247
  %1259 = fmul fast float %1245, 0x400370A3E0000000
  %1260 = fmul fast float %1246, 0x400370A3E0000000
  %1261 = fmul fast float %1247, 0x400370A3E0000000
  %1262 = fadd fast float %1259, 0x3FE2E147A0000000
  %1263 = fadd fast float %1260, 0x3FE2E147A0000000
  %1264 = fadd fast float %1261, 0x3FE2E147A0000000
  %1265 = fmul fast float %1262, %1245
  %1266 = fmul fast float %1263, %1246
  %1267 = fmul fast float %1264, %1247
  %1268 = fadd fast float %1265, 0x3FC1EB8520000000
  %1269 = fadd fast float %1266, 0x3FC1EB8520000000
  %1270 = fadd fast float %1267, 0x3FC1EB8520000000
  %1271 = fdiv fast float %1256, %1268
  %1272 = fdiv fast float %1257, %1269
  %1273 = fdiv fast float %1258, %1270
  br label %1274

; <label>:1274                                    ; preds = %1249, %1238
  %1275 = phi float [ %1271, %1249 ], [ %1245, %1238 ]
  %1276 = phi float [ %1272, %1249 ], [ %1246, %1238 ]
  %1277 = phi float [ %1273, %1249 ], [ %1247, %1238 ]
  %1278 = call float @dx.op.unary.f32(i32 7, float %1275)  ; Saturate(value)
  %1279 = call float @dx.op.unary.f32(i32 7, float %1276)  ; Saturate(value)
  %1280 = call float @dx.op.unary.f32(i32 7, float %1277)  ; Saturate(value)
  %1281 = call float @dx.op.dot3.f32(i32 55, float %1278, float %1279, float %1280, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1282 = fsub fast float %1278, %1281
  %1283 = fsub fast float %1279, %1281
  %1284 = fsub fast float %1280, %1281
  %1285 = fmul fast float %1282, %8
  %1286 = fmul fast float %1283, %8
  %1287 = fmul fast float %1284, %8
  %1288 = fadd fast float %1285, %1281
  %1289 = fadd fast float %1286, %1281
  %1290 = fadd fast float %1287, %1281
  %1291 = call float @dx.op.unary.f32(i32 7, float %1288)  ; Saturate(value)
  %1292 = call float @dx.op.unary.f32(i32 7, float %1289)  ; Saturate(value)
  %1293 = call float @dx.op.unary.f32(i32 7, float %1290)  ; Saturate(value)
  %1294 = fadd fast float %1291, 0xBFC70A3D80000000
  %1295 = fadd fast float %1292, 0xBFC70A3D80000000
  %1296 = fadd fast float %1293, 0xBFC70A3D80000000
  %1297 = fmul fast float %1294, %7
  %1298 = fmul fast float %1295, %7
  %1299 = fmul fast float %1296, %7
  %1300 = fadd fast float %1297, 0x3FC70A3D80000000
  %1301 = fadd fast float %1298, 0x3FC70A3D80000000
  %1302 = fadd fast float %1299, 0x3FC70A3D80000000
  %1303 = call float @dx.op.unary.f32(i32 7, float %1300)  ; Saturate(value)
  %1304 = call float @dx.op.unary.f32(i32 7, float %1301)  ; Saturate(value)
  %1305 = call float @dx.op.unary.f32(i32 7, float %1302)  ; Saturate(value)
  br label %1306

; <label>:1306                                    ; preds = %1274, %1204
  %1307 = phi float [ %1235, %1204 ], [ %1303, %1274 ]
  %1308 = phi float [ %1236, %1204 ], [ %1304, %1274 ]
  %1309 = phi float [ %1237, %1204 ], [ %1305, %1274 ]
  %1310 = fsub fast float %1307, %1033
  %1311 = fsub fast float %1308, %1034
  %1312 = fsub fast float %1309, %1035
  %1313 = fmul fast float %1310, %1191
  %1314 = fmul fast float %1311, %1191
  %1315 = fmul fast float %1312, %1191
  %1316 = fadd fast float %1313, %1033
  %1317 = fadd fast float %1314, %1034
  %1318 = fadd fast float %1315, %1035
  br label %1319

; <label>:1319                                    ; preds = %1306, %1178
  %1320 = phi float [ %1316, %1306 ], [ %1033, %1178 ]
  %1321 = phi float [ %1317, %1306 ], [ %1034, %1178 ]
  %1322 = phi float [ %1318, %1306 ], [ %1035, %1178 ]
  %1323 = add i32 %38, -1
  %1324 = call i32 @dx.op.binary.i32(i32 37, i32 %1323, i32 0)  ; IMax(a,b)
  %1325 = call i32 @dx.op.binary.i32(i32 37, i32 %35, i32 0)  ; IMax(a,b)
  %1326 = call i32 @dx.op.binary.i32(i32 38, i32 %1324, i32 %30)  ; IMin(a,b)
  %1327 = call i32 @dx.op.binary.i32(i32 38, i32 %1325, i32 %31)  ; IMin(a,b)
  %1328 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1326, i32 %1327, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1329 = extractvalue %dx.types.ResRet.f32 %1328, 0
  %1330 = fsub fast float %1329, %55
  %1331 = call float @dx.op.unary.f32(i32 6, float %1330)  ; FAbs(value)
  %1332 = fdiv fast float %1331, %1045
  %1333 = fsub fast float 1.000000e+00, %1332
  %1334 = call float @dx.op.unary.f32(i32 7, float %1333)  ; Saturate(value)
  %1335 = fcmp fast ugt float %1334, 0.000000e+00
  br i1 %1335, label %1336, label %1462

; <label>:1336                                    ; preds = %1319
  %1337 = call i32 @dx.op.binary.i32(i32 37, i32 %1326, i32 0)  ; IMax(a,b)
  %1338 = call i32 @dx.op.binary.i32(i32 37, i32 %1327, i32 0)  ; IMax(a,b)
  %1339 = call i32 @dx.op.binary.i32(i32 38, i32 %1337, i32 %30)  ; IMin(a,b)
  %1340 = call i32 @dx.op.binary.i32(i32 38, i32 %1338, i32 %31)  ; IMin(a,b)
  %1341 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1339, i32 %1340, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1342 = extractvalue %dx.types.ResRet.f32 %1341, 0
  %1343 = extractvalue %dx.types.ResRet.f32 %1341, 1
  %1344 = extractvalue %dx.types.ResRet.f32 %1341, 2
  %1345 = extractvalue %dx.types.ResRet.f32 %1341, 3
  %1346 = fcmp fast olt float %1345, 0.000000e+00
  br i1 %1346, label %1347, label %1381

; <label>:1347                                    ; preds = %1336
  %1348 = fcmp fast ogt float %1342, 0x3FA4B5DCC0000000
  %1349 = fcmp fast ogt float %1343, 0x3FA4B5DCC0000000
  %1350 = fcmp fast ogt float %1344, 0x3FA4B5DCC0000000
  %1351 = select i1 %1348, float 0.000000e+00, float 1.000000e+00
  %1352 = select i1 %1349, float 0.000000e+00, float 1.000000e+00
  %1353 = select i1 %1350, float 0.000000e+00, float 1.000000e+00
  %1354 = fmul fast float %1342, 0x3FB3D07220000000
  %1355 = fmul fast float %1343, 0x3FB3D07220000000
  %1356 = fmul fast float %1344, 0x3FB3D07220000000
  %1357 = fadd fast float %1342, 0x3FAC28F5C0000000
  %1358 = fadd fast float %1343, 0x3FAC28F5C0000000
  %1359 = fadd fast float %1344, 0x3FAC28F5C0000000
  %1360 = fmul fast float %1357, 0x3FEE54EDE0000000
  %1361 = fmul fast float %1358, 0x3FEE54EDE0000000
  %1362 = fmul fast float %1359, 0x3FEE54EDE0000000
  %1363 = call float @dx.op.unary.f32(i32 23, float %1360)  ; Log(value)
  %1364 = call float @dx.op.unary.f32(i32 23, float %1361)  ; Log(value)
  %1365 = call float @dx.op.unary.f32(i32 23, float %1362)  ; Log(value)
  %1366 = fmul fast float %1363, 0x4003333340000000
  %1367 = fmul fast float %1364, 0x4003333340000000
  %1368 = fmul fast float %1365, 0x4003333340000000
  %1369 = call float @dx.op.unary.f32(i32 21, float %1366)  ; Exp(value)
  %1370 = call float @dx.op.unary.f32(i32 21, float %1367)  ; Exp(value)
  %1371 = call float @dx.op.unary.f32(i32 21, float %1368)  ; Exp(value)
  %1372 = fsub fast float %1354, %1369
  %1373 = fsub fast float %1355, %1370
  %1374 = fsub fast float %1356, %1371
  %1375 = fmul fast float %1372, %1351
  %1376 = fmul fast float %1373, %1352
  %1377 = fmul fast float %1374, %1353
  %1378 = fadd fast float %1375, %1369
  %1379 = fadd fast float %1376, %1370
  %1380 = fadd fast float %1377, %1371
  br label %1449

; <label>:1381                                    ; preds = %1336
  %1382 = fadd fast float %5, 1.000000e+00
  %1383 = fadd fast float %6, 1.000000e+00
  %1384 = fsub fast float 1.000000e+00, %5
  %1385 = fmul fast float %9, %1382
  %1386 = fmul fast float %9, %1383
  %1387 = fmul fast float %9, %1384
  %1388 = fmul fast float %1385, %1342
  %1389 = fmul fast float %1386, %1343
  %1390 = fmul fast float %1387, %1344
  %1391 = fcmp fast ult float %10, 5.000000e-01
  br i1 %1391, label %1417, label %1392

; <label>:1392                                    ; preds = %1381
  %1393 = fmul fast float %1388, 0x4004147AE0000000
  %1394 = fmul fast float %1389, 0x4004147AE0000000
  %1395 = fmul fast float %1390, 0x4004147AE0000000
  %1396 = fadd fast float %1393, 0x3F9EB851E0000000
  %1397 = fadd fast float %1394, 0x3F9EB851E0000000
  %1398 = fadd fast float %1395, 0x3F9EB851E0000000
  %1399 = fmul fast float %1396, %1388
  %1400 = fmul fast float %1397, %1389
  %1401 = fmul fast float %1398, %1390
  %1402 = fmul fast float %1388, 0x400370A3E0000000
  %1403 = fmul fast float %1389, 0x400370A3E0000000
  %1404 = fmul fast float %1390, 0x400370A3E0000000
  %1405 = fadd fast float %1402, 0x3FE2E147A0000000
  %1406 = fadd fast float %1403, 0x3FE2E147A0000000
  %1407 = fadd fast float %1404, 0x3FE2E147A0000000
  %1408 = fmul fast float %1405, %1388
  %1409 = fmul fast float %1406, %1389
  %1410 = fmul fast float %1407, %1390
  %1411 = fadd fast float %1408, 0x3FC1EB8520000000
  %1412 = fadd fast float %1409, 0x3FC1EB8520000000
  %1413 = fadd fast float %1410, 0x3FC1EB8520000000
  %1414 = fdiv fast float %1399, %1411
  %1415 = fdiv fast float %1400, %1412
  %1416 = fdiv fast float %1401, %1413
  br label %1417

; <label>:1417                                    ; preds = %1392, %1381
  %1418 = phi float [ %1414, %1392 ], [ %1388, %1381 ]
  %1419 = phi float [ %1415, %1392 ], [ %1389, %1381 ]
  %1420 = phi float [ %1416, %1392 ], [ %1390, %1381 ]
  %1421 = call float @dx.op.unary.f32(i32 7, float %1418)  ; Saturate(value)
  %1422 = call float @dx.op.unary.f32(i32 7, float %1419)  ; Saturate(value)
  %1423 = call float @dx.op.unary.f32(i32 7, float %1420)  ; Saturate(value)
  %1424 = call float @dx.op.dot3.f32(i32 55, float %1421, float %1422, float %1423, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1425 = fsub fast float %1421, %1424
  %1426 = fsub fast float %1422, %1424
  %1427 = fsub fast float %1423, %1424
  %1428 = fmul fast float %1425, %8
  %1429 = fmul fast float %1426, %8
  %1430 = fmul fast float %1427, %8
  %1431 = fadd fast float %1428, %1424
  %1432 = fadd fast float %1429, %1424
  %1433 = fadd fast float %1430, %1424
  %1434 = call float @dx.op.unary.f32(i32 7, float %1431)  ; Saturate(value)
  %1435 = call float @dx.op.unary.f32(i32 7, float %1432)  ; Saturate(value)
  %1436 = call float @dx.op.unary.f32(i32 7, float %1433)  ; Saturate(value)
  %1437 = fadd fast float %1434, 0xBFC70A3D80000000
  %1438 = fadd fast float %1435, 0xBFC70A3D80000000
  %1439 = fadd fast float %1436, 0xBFC70A3D80000000
  %1440 = fmul fast float %1437, %7
  %1441 = fmul fast float %1438, %7
  %1442 = fmul fast float %1439, %7
  %1443 = fadd fast float %1440, 0x3FC70A3D80000000
  %1444 = fadd fast float %1441, 0x3FC70A3D80000000
  %1445 = fadd fast float %1442, 0x3FC70A3D80000000
  %1446 = call float @dx.op.unary.f32(i32 7, float %1443)  ; Saturate(value)
  %1447 = call float @dx.op.unary.f32(i32 7, float %1444)  ; Saturate(value)
  %1448 = call float @dx.op.unary.f32(i32 7, float %1445)  ; Saturate(value)
  br label %1449

; <label>:1449                                    ; preds = %1417, %1347
  %1450 = phi float [ %1378, %1347 ], [ %1446, %1417 ]
  %1451 = phi float [ %1379, %1347 ], [ %1447, %1417 ]
  %1452 = phi float [ %1380, %1347 ], [ %1448, %1417 ]
  %1453 = fsub fast float %1450, %1033
  %1454 = fsub fast float %1451, %1034
  %1455 = fsub fast float %1452, %1035
  %1456 = fmul fast float %1453, %1334
  %1457 = fmul fast float %1454, %1334
  %1458 = fmul fast float %1455, %1334
  %1459 = fadd fast float %1456, %1033
  %1460 = fadd fast float %1457, %1034
  %1461 = fadd fast float %1458, %1035
  br label %1462

; <label>:1462                                    ; preds = %1449, %1319
  %1463 = phi float [ %1459, %1449 ], [ %1033, %1319 ]
  %1464 = phi float [ %1460, %1449 ], [ %1034, %1319 ]
  %1465 = phi float [ %1461, %1449 ], [ %1035, %1319 ]
  %1466 = add i32 %38, 1
  %1467 = call i32 @dx.op.binary.i32(i32 37, i32 %1466, i32 0)  ; IMax(a,b)
  %1468 = call i32 @dx.op.binary.i32(i32 38, i32 %1467, i32 %30)  ; IMin(a,b)
  %1469 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1468, i32 %1327, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1470 = extractvalue %dx.types.ResRet.f32 %1469, 0
  %1471 = fsub fast float %1470, %55
  %1472 = call float @dx.op.unary.f32(i32 6, float %1471)  ; FAbs(value)
  %1473 = fdiv fast float %1472, %1045
  %1474 = fsub fast float 1.000000e+00, %1473
  %1475 = call float @dx.op.unary.f32(i32 7, float %1474)  ; Saturate(value)
  %1476 = fcmp fast ugt float %1475, 0.000000e+00
  br i1 %1476, label %1477, label %1603

; <label>:1477                                    ; preds = %1462
  %1478 = call i32 @dx.op.binary.i32(i32 37, i32 %1468, i32 0)  ; IMax(a,b)
  %1479 = call i32 @dx.op.binary.i32(i32 37, i32 %1327, i32 0)  ; IMax(a,b)
  %1480 = call i32 @dx.op.binary.i32(i32 38, i32 %1478, i32 %30)  ; IMin(a,b)
  %1481 = call i32 @dx.op.binary.i32(i32 38, i32 %1479, i32 %31)  ; IMin(a,b)
  %1482 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1480, i32 %1481, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1483 = extractvalue %dx.types.ResRet.f32 %1482, 0
  %1484 = extractvalue %dx.types.ResRet.f32 %1482, 1
  %1485 = extractvalue %dx.types.ResRet.f32 %1482, 2
  %1486 = extractvalue %dx.types.ResRet.f32 %1482, 3
  %1487 = fcmp fast olt float %1486, 0.000000e+00
  br i1 %1487, label %1488, label %1522

; <label>:1488                                    ; preds = %1477
  %1489 = fcmp fast ogt float %1483, 0x3FA4B5DCC0000000
  %1490 = fcmp fast ogt float %1484, 0x3FA4B5DCC0000000
  %1491 = fcmp fast ogt float %1485, 0x3FA4B5DCC0000000
  %1492 = select i1 %1489, float 0.000000e+00, float 1.000000e+00
  %1493 = select i1 %1490, float 0.000000e+00, float 1.000000e+00
  %1494 = select i1 %1491, float 0.000000e+00, float 1.000000e+00
  %1495 = fmul fast float %1483, 0x3FB3D07220000000
  %1496 = fmul fast float %1484, 0x3FB3D07220000000
  %1497 = fmul fast float %1485, 0x3FB3D07220000000
  %1498 = fadd fast float %1483, 0x3FAC28F5C0000000
  %1499 = fadd fast float %1484, 0x3FAC28F5C0000000
  %1500 = fadd fast float %1485, 0x3FAC28F5C0000000
  %1501 = fmul fast float %1498, 0x3FEE54EDE0000000
  %1502 = fmul fast float %1499, 0x3FEE54EDE0000000
  %1503 = fmul fast float %1500, 0x3FEE54EDE0000000
  %1504 = call float @dx.op.unary.f32(i32 23, float %1501)  ; Log(value)
  %1505 = call float @dx.op.unary.f32(i32 23, float %1502)  ; Log(value)
  %1506 = call float @dx.op.unary.f32(i32 23, float %1503)  ; Log(value)
  %1507 = fmul fast float %1504, 0x4003333340000000
  %1508 = fmul fast float %1505, 0x4003333340000000
  %1509 = fmul fast float %1506, 0x4003333340000000
  %1510 = call float @dx.op.unary.f32(i32 21, float %1507)  ; Exp(value)
  %1511 = call float @dx.op.unary.f32(i32 21, float %1508)  ; Exp(value)
  %1512 = call float @dx.op.unary.f32(i32 21, float %1509)  ; Exp(value)
  %1513 = fsub fast float %1495, %1510
  %1514 = fsub fast float %1496, %1511
  %1515 = fsub fast float %1497, %1512
  %1516 = fmul fast float %1513, %1492
  %1517 = fmul fast float %1514, %1493
  %1518 = fmul fast float %1515, %1494
  %1519 = fadd fast float %1516, %1510
  %1520 = fadd fast float %1517, %1511
  %1521 = fadd fast float %1518, %1512
  br label %1590

; <label>:1522                                    ; preds = %1477
  %1523 = fadd fast float %5, 1.000000e+00
  %1524 = fadd fast float %6, 1.000000e+00
  %1525 = fsub fast float 1.000000e+00, %5
  %1526 = fmul fast float %9, %1523
  %1527 = fmul fast float %9, %1524
  %1528 = fmul fast float %9, %1525
  %1529 = fmul fast float %1526, %1483
  %1530 = fmul fast float %1527, %1484
  %1531 = fmul fast float %1528, %1485
  %1532 = fcmp fast ult float %10, 5.000000e-01
  br i1 %1532, label %1558, label %1533

; <label>:1533                                    ; preds = %1522
  %1534 = fmul fast float %1529, 0x4004147AE0000000
  %1535 = fmul fast float %1530, 0x4004147AE0000000
  %1536 = fmul fast float %1531, 0x4004147AE0000000
  %1537 = fadd fast float %1534, 0x3F9EB851E0000000
  %1538 = fadd fast float %1535, 0x3F9EB851E0000000
  %1539 = fadd fast float %1536, 0x3F9EB851E0000000
  %1540 = fmul fast float %1537, %1529
  %1541 = fmul fast float %1538, %1530
  %1542 = fmul fast float %1539, %1531
  %1543 = fmul fast float %1529, 0x400370A3E0000000
  %1544 = fmul fast float %1530, 0x400370A3E0000000
  %1545 = fmul fast float %1531, 0x400370A3E0000000
  %1546 = fadd fast float %1543, 0x3FE2E147A0000000
  %1547 = fadd fast float %1544, 0x3FE2E147A0000000
  %1548 = fadd fast float %1545, 0x3FE2E147A0000000
  %1549 = fmul fast float %1546, %1529
  %1550 = fmul fast float %1547, %1530
  %1551 = fmul fast float %1548, %1531
  %1552 = fadd fast float %1549, 0x3FC1EB8520000000
  %1553 = fadd fast float %1550, 0x3FC1EB8520000000
  %1554 = fadd fast float %1551, 0x3FC1EB8520000000
  %1555 = fdiv fast float %1540, %1552
  %1556 = fdiv fast float %1541, %1553
  %1557 = fdiv fast float %1542, %1554
  br label %1558

; <label>:1558                                    ; preds = %1533, %1522
  %1559 = phi float [ %1555, %1533 ], [ %1529, %1522 ]
  %1560 = phi float [ %1556, %1533 ], [ %1530, %1522 ]
  %1561 = phi float [ %1557, %1533 ], [ %1531, %1522 ]
  %1562 = call float @dx.op.unary.f32(i32 7, float %1559)  ; Saturate(value)
  %1563 = call float @dx.op.unary.f32(i32 7, float %1560)  ; Saturate(value)
  %1564 = call float @dx.op.unary.f32(i32 7, float %1561)  ; Saturate(value)
  %1565 = call float @dx.op.dot3.f32(i32 55, float %1562, float %1563, float %1564, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1566 = fsub fast float %1562, %1565
  %1567 = fsub fast float %1563, %1565
  %1568 = fsub fast float %1564, %1565
  %1569 = fmul fast float %1566, %8
  %1570 = fmul fast float %1567, %8
  %1571 = fmul fast float %1568, %8
  %1572 = fadd fast float %1569, %1565
  %1573 = fadd fast float %1570, %1565
  %1574 = fadd fast float %1571, %1565
  %1575 = call float @dx.op.unary.f32(i32 7, float %1572)  ; Saturate(value)
  %1576 = call float @dx.op.unary.f32(i32 7, float %1573)  ; Saturate(value)
  %1577 = call float @dx.op.unary.f32(i32 7, float %1574)  ; Saturate(value)
  %1578 = fadd fast float %1575, 0xBFC70A3D80000000
  %1579 = fadd fast float %1576, 0xBFC70A3D80000000
  %1580 = fadd fast float %1577, 0xBFC70A3D80000000
  %1581 = fmul fast float %1578, %7
  %1582 = fmul fast float %1579, %7
  %1583 = fmul fast float %1580, %7
  %1584 = fadd fast float %1581, 0x3FC70A3D80000000
  %1585 = fadd fast float %1582, 0x3FC70A3D80000000
  %1586 = fadd fast float %1583, 0x3FC70A3D80000000
  %1587 = call float @dx.op.unary.f32(i32 7, float %1584)  ; Saturate(value)
  %1588 = call float @dx.op.unary.f32(i32 7, float %1585)  ; Saturate(value)
  %1589 = call float @dx.op.unary.f32(i32 7, float %1586)  ; Saturate(value)
  br label %1590

; <label>:1590                                    ; preds = %1558, %1488
  %1591 = phi float [ %1519, %1488 ], [ %1587, %1558 ]
  %1592 = phi float [ %1520, %1488 ], [ %1588, %1558 ]
  %1593 = phi float [ %1521, %1488 ], [ %1589, %1558 ]
  %1594 = fsub fast float %1591, %1033
  %1595 = fsub fast float %1592, %1034
  %1596 = fsub fast float %1593, %1035
  %1597 = fmul fast float %1594, %1475
  %1598 = fmul fast float %1595, %1475
  %1599 = fmul fast float %1596, %1475
  %1600 = fadd fast float %1597, %1033
  %1601 = fadd fast float %1598, %1034
  %1602 = fadd fast float %1599, %1035
  br label %1603

; <label>:1603                                    ; preds = %1590, %1462
  %1604 = phi float [ %1600, %1590 ], [ %1033, %1462 ]
  %1605 = phi float [ %1601, %1590 ], [ %1034, %1462 ]
  %1606 = phi float [ %1602, %1590 ], [ %1035, %1462 ]
  %1607 = call float @dx.op.binary.f32(i32 36, float %1463, float %1604)  ; FMin(a,b)
  %1608 = call float @dx.op.binary.f32(i32 36, float %1464, float %1605)  ; FMin(a,b)
  %1609 = call float @dx.op.binary.f32(i32 36, float %1465, float %1606)  ; FMin(a,b)
  %1610 = call float @dx.op.binary.f32(i32 36, float %1179, float %1320)  ; FMin(a,b)
  %1611 = call float @dx.op.binary.f32(i32 36, float %1180, float %1321)  ; FMin(a,b)
  %1612 = call float @dx.op.binary.f32(i32 36, float %1181, float %1322)  ; FMin(a,b)
  %1613 = call float @dx.op.binary.f32(i32 36, float %1610, float %1607)  ; FMin(a,b)
  %1614 = call float @dx.op.binary.f32(i32 36, float %1611, float %1608)  ; FMin(a,b)
  %1615 = call float @dx.op.binary.f32(i32 36, float %1612, float %1609)  ; FMin(a,b)
  %1616 = call float @dx.op.binary.f32(i32 36, float %1033, float %1613)  ; FMin(a,b)
  %1617 = call float @dx.op.binary.f32(i32 36, float %1034, float %1614)  ; FMin(a,b)
  %1618 = call float @dx.op.binary.f32(i32 36, float %1035, float %1615)  ; FMin(a,b)
  %1619 = call float @dx.op.binary.f32(i32 35, float %1463, float %1604)  ; FMax(a,b)
  %1620 = call float @dx.op.binary.f32(i32 35, float %1464, float %1605)  ; FMax(a,b)
  %1621 = call float @dx.op.binary.f32(i32 35, float %1465, float %1606)  ; FMax(a,b)
  %1622 = call float @dx.op.binary.f32(i32 35, float %1179, float %1320)  ; FMax(a,b)
  %1623 = call float @dx.op.binary.f32(i32 35, float %1180, float %1321)  ; FMax(a,b)
  %1624 = call float @dx.op.binary.f32(i32 35, float %1181, float %1322)  ; FMax(a,b)
  %1625 = call float @dx.op.binary.f32(i32 35, float %1622, float %1619)  ; FMax(a,b)
  %1626 = call float @dx.op.binary.f32(i32 35, float %1623, float %1620)  ; FMax(a,b)
  %1627 = call float @dx.op.binary.f32(i32 35, float %1624, float %1621)  ; FMax(a,b)
  %1628 = call float @dx.op.binary.f32(i32 35, float %1033, float %1625)  ; FMax(a,b)
  %1629 = call float @dx.op.binary.f32(i32 35, float %1034, float %1626)  ; FMax(a,b)
  %1630 = call float @dx.op.binary.f32(i32 35, float %1035, float %1627)  ; FMax(a,b)
  %1631 = fsub fast float %1628, %1616
  %1632 = fsub fast float %1629, %1617
  %1633 = fsub fast float %1630, %1618
  %1634 = call float @dx.op.unary.f32(i32 6, float %1631)  ; FAbs(value)
  %1635 = call float @dx.op.unary.f32(i32 6, float %1632)  ; FAbs(value)
  %1636 = call float @dx.op.unary.f32(i32 6, float %1633)  ; FAbs(value)
  %1637 = call float @dx.op.binary.f32(i32 35, float %1635, float %1636)  ; FMax(a,b)
  %1638 = call float @dx.op.binary.f32(i32 35, float %1634, float %1637)  ; FMax(a,b)
  %1639 = call float @dx.op.binary.f32(i32 35, float %1629, float %1630)  ; FMax(a,b)
  %1640 = call float @dx.op.binary.f32(i32 35, float %1628, float %1639)  ; FMax(a,b)
  %1641 = fmul fast float %1640, 1.250000e-01
  %1642 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1641)  ; FMax(a,b)
  %1643 = fcmp fast ogt float %1638, %1642
  br i1 %1643, label %1644, label %1705

; <label>:1644                                    ; preds = %1603
  %1645 = fsub fast float %1179, %1320
  %1646 = fsub fast float %1180, %1321
  %1647 = fsub fast float %1181, %1322
  %1648 = call float @dx.op.unary.f32(i32 6, float %1645)  ; FAbs(value)
  %1649 = call float @dx.op.unary.f32(i32 6, float %1646)  ; FAbs(value)
  %1650 = call float @dx.op.unary.f32(i32 6, float %1647)  ; FAbs(value)
  %1651 = call float @dx.op.binary.f32(i32 35, float %1649, float %1650)  ; FMax(a,b)
  %1652 = call float @dx.op.binary.f32(i32 35, float %1648, float %1651)  ; FMax(a,b)
  %1653 = fsub fast float %1463, %1604
  %1654 = fsub fast float %1464, %1605
  %1655 = fsub fast float %1465, %1606
  %1656 = call float @dx.op.unary.f32(i32 6, float %1653)  ; FAbs(value)
  %1657 = call float @dx.op.unary.f32(i32 6, float %1654)  ; FAbs(value)
  %1658 = call float @dx.op.unary.f32(i32 6, float %1655)  ; FAbs(value)
  %1659 = call float @dx.op.binary.f32(i32 35, float %1657, float %1658)  ; FMax(a,b)
  %1660 = call float @dx.op.binary.f32(i32 35, float %1656, float %1659)  ; FMax(a,b)
  %1661 = fcmp fast olt float %1652, %1660
  %1662 = select i1 %1661, float %1179, float %1463
  %1663 = select i1 %1661, float %1180, float %1464
  %1664 = select i1 %1661, float %1181, float %1465
  %1665 = select i1 %1661, float %1320, float %1604
  %1666 = select i1 %1661, float %1321, float %1605
  %1667 = select i1 %1661, float %1322, float %1606
  %1668 = fsub fast float %1033, %1665
  %1669 = fsub fast float %1034, %1666
  %1670 = fsub fast float %1035, %1667
  %1671 = fsub fast float %1033, %1662
  %1672 = fsub fast float %1034, %1663
  %1673 = fsub fast float %1035, %1664
  %1674 = call float @dx.op.dot3.f32(i32 55, float %1671, float %1672, float %1673, float %1668, float %1669, float %1670)  ; Dot3(ax,ay,az,bx,by,bz)
  %1675 = fcmp fast ogt float %1674, 0.000000e+00
  br i1 %1675, label %1676, label %1687

; <label>:1676                                    ; preds = %1644
  %1677 = fsub fast float %1662, %1665
  %1678 = fsub fast float %1663, %1666
  %1679 = fsub fast float %1664, %1667
  %1680 = call float @dx.op.unary.f32(i32 6, float %1677)  ; FAbs(value)
  %1681 = call float @dx.op.unary.f32(i32 6, float %1678)  ; FAbs(value)
  %1682 = call float @dx.op.unary.f32(i32 6, float %1679)  ; FAbs(value)
  %1683 = call float @dx.op.binary.f32(i32 35, float %1681, float %1682)  ; FMax(a,b)
  %1684 = call float @dx.op.binary.f32(i32 35, float %1680, float %1683)  ; FMax(a,b)
  %1685 = fmul fast float %1638, 2.500000e-01
  %1686 = fcmp fast olt float %1684, %1685
  br label %1687

; <label>:1687                                    ; preds = %1676, %1644
  %1688 = phi i1 [ false, %1644 ], [ %1686, %1676 ]
  %1689 = select i1 %1688, float 0x3FC3333340000000, float 0x3FD3333340000000
  %1690 = fadd fast float %1662, %1665
  %1691 = fadd fast float %1663, %1666
  %1692 = fadd fast float %1664, %1667
  %1693 = fmul fast float %1690, 5.000000e-01
  %1694 = fmul fast float %1691, 5.000000e-01
  %1695 = fmul fast float %1692, 5.000000e-01
  %1696 = fsub fast float %1693, %1033
  %1697 = fsub fast float %1694, %1034
  %1698 = fsub fast float %1695, %1035
  %1699 = fmul fast float %1689, %1696
  %1700 = fmul fast float %1689, %1697
  %1701 = fmul fast float %1689, %1698
  %1702 = fadd fast float %1699, %1033
  %1703 = fadd fast float %1700, %1034
  %1704 = fadd fast float %1701, %1035
  br label %1705

; <label>:1705                                    ; preds = %1687, %1603
  %1706 = phi float [ %1702, %1687 ], [ %1033, %1603 ]
  %1707 = phi float [ %1703, %1687 ], [ %1034, %1603 ]
  %1708 = phi float [ %1704, %1687 ], [ %1035, %1603 ]
  %1709 = fcmp fast ogt float %1706, 0x3F69A5C380000000
  %1710 = fcmp fast ogt float %1707, 0x3F69A5C380000000
  %1711 = fcmp fast ogt float %1708, 0x3F69A5C380000000
  %1712 = select i1 %1709, float 0.000000e+00, float 1.000000e+00
  %1713 = select i1 %1710, float 0.000000e+00, float 1.000000e+00
  %1714 = select i1 %1711, float 0.000000e+00, float 1.000000e+00
  %1715 = fmul fast float %1706, 0x4029D70A40000000
  %1716 = fmul fast float %1707, 0x4029D70A40000000
  %1717 = fmul fast float %1708, 0x4029D70A40000000
  %1718 = call float @dx.op.binary.f32(i32 35, float %1706, float 0.000000e+00)  ; FMax(a,b)
  %1719 = call float @dx.op.binary.f32(i32 35, float %1707, float 0.000000e+00)  ; FMax(a,b)
  %1720 = call float @dx.op.binary.f32(i32 35, float %1708, float 0.000000e+00)  ; FMax(a,b)
  %1721 = call float @dx.op.unary.f32(i32 23, float %1718)  ; Log(value)
  %1722 = call float @dx.op.unary.f32(i32 23, float %1719)  ; Log(value)
  %1723 = call float @dx.op.unary.f32(i32 23, float %1720)  ; Log(value)
  %1724 = fmul fast float %1721, 0x3FDAAAAAA0000000
  %1725 = fmul fast float %1722, 0x3FDAAAAAA0000000
  %1726 = fmul fast float %1723, 0x3FDAAAAAA0000000
  %1727 = call float @dx.op.unary.f32(i32 21, float %1724)  ; Exp(value)
  %1728 = call float @dx.op.unary.f32(i32 21, float %1725)  ; Exp(value)
  %1729 = call float @dx.op.unary.f32(i32 21, float %1726)  ; Exp(value)
  %1730 = fmul fast float %1727, 0x3FF0E147A0000000
  %1731 = fmul fast float %1728, 0x3FF0E147A0000000
  %1732 = fmul fast float %1729, 0x3FF0E147A0000000
  %1733 = fadd fast float %1730, 0xBFAC28F5C0000000
  %1734 = fadd fast float %1731, 0xBFAC28F5C0000000
  %1735 = fadd fast float %1732, 0xBFAC28F5C0000000
  %1736 = fsub fast float %1715, %1733
  %1737 = fsub fast float %1716, %1734
  %1738 = fsub fast float %1717, %1735
  %1739 = fmul fast float %1736, %1712
  %1740 = fmul fast float %1737, %1713
  %1741 = fmul fast float %1738, %1714
  %1742 = fadd fast float %1739, %1733
  %1743 = fadd fast float %1740, %1734
  %1744 = fadd fast float %1741, %1735
  br label %1745

; <label>:1745                                    ; preds = %1705, %966
  %1746 = phi float [ %961, %966 ], [ %1742, %1705 ]
  %1747 = phi float [ %962, %966 ], [ %1743, %1705 ]
  %1748 = phi float [ %963, %966 ], [ %1744, %1705 ]
  %1749 = phi float [ %967, %966 ], [ %964, %1705 ]
  %1750 = fcmp fast ogt float %1746, 0x3FA4B5DCC0000000
  %1751 = fcmp fast ogt float %1747, 0x3FA4B5DCC0000000
  %1752 = fcmp fast ogt float %1748, 0x3FA4B5DCC0000000
  %1753 = select i1 %1750, float 0.000000e+00, float 1.000000e+00
  %1754 = select i1 %1751, float 0.000000e+00, float 1.000000e+00
  %1755 = select i1 %1752, float 0.000000e+00, float 1.000000e+00
  %1756 = fmul fast float %1746, 0x3FB3D07220000000
  %1757 = fmul fast float %1747, 0x3FB3D07220000000
  %1758 = fmul fast float %1748, 0x3FB3D07220000000
  %1759 = fadd fast float %1746, 0x3FAC28F5C0000000
  %1760 = fadd fast float %1747, 0x3FAC28F5C0000000
  %1761 = fadd fast float %1748, 0x3FAC28F5C0000000
  %1762 = fmul fast float %1759, 0x3FEE54EDE0000000
  %1763 = fmul fast float %1760, 0x3FEE54EDE0000000
  %1764 = fmul fast float %1761, 0x3FEE54EDE0000000
  %1765 = call float @dx.op.unary.f32(i32 23, float %1762)  ; Log(value)
  %1766 = call float @dx.op.unary.f32(i32 23, float %1763)  ; Log(value)
  %1767 = call float @dx.op.unary.f32(i32 23, float %1764)  ; Log(value)
  %1768 = fmul fast float %1765, 0x4003333340000000
  %1769 = fmul fast float %1766, 0x4003333340000000
  %1770 = fmul fast float %1767, 0x4003333340000000
  %1771 = call float @dx.op.unary.f32(i32 21, float %1768)  ; Exp(value)
  %1772 = call float @dx.op.unary.f32(i32 21, float %1769)  ; Exp(value)
  %1773 = call float @dx.op.unary.f32(i32 21, float %1770)  ; Exp(value)
  %1774 = fsub fast float %1756, %1771
  %1775 = fsub fast float %1757, %1772
  %1776 = fsub fast float %1758, %1773
  %1777 = fmul fast float %1774, %1753
  %1778 = fmul fast float %1775, %1754
  %1779 = fmul fast float %1776, %1755
  %1780 = fadd fast float %1777, %1771
  %1781 = fadd fast float %1778, %1772
  %1782 = fadd fast float %1779, %1773
  %1783 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %34, i32 %41, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1784 = extractvalue %dx.types.ResRet.f32 %1783, 0
  %1785 = extractvalue %dx.types.ResRet.f32 %1783, 1
  %1786 = extractvalue %dx.types.ResRet.f32 %1783, 2
  %1787 = extractvalue %dx.types.ResRet.f32 %1783, 3
  %1788 = fcmp fast olt float %1787, 0.000000e+00
  br i1 %1788, label %1789, label %1791

; <label>:1789                                    ; preds = %1745
  %1790 = fsub fast float -1.000000e+00, %1787
  br label %2568

; <label>:1791                                    ; preds = %1745
  %1792 = fadd fast float %5, 1.000000e+00
  %1793 = fadd fast float %6, 1.000000e+00
  %1794 = fsub fast float 1.000000e+00, %5
  %1795 = fmul fast float %9, %1792
  %1796 = fmul fast float %9, %1793
  %1797 = fmul fast float %9, %1794
  %1798 = fmul fast float %1795, %1784
  %1799 = fmul fast float %1796, %1785
  %1800 = fmul fast float %1797, %1786
  %1801 = fcmp fast ult float %10, 5.000000e-01
  br i1 %1801, label %1827, label %1802

; <label>:1802                                    ; preds = %1791
  %1803 = fmul fast float %1798, 0x4004147AE0000000
  %1804 = fmul fast float %1799, 0x4004147AE0000000
  %1805 = fmul fast float %1800, 0x4004147AE0000000
  %1806 = fadd fast float %1803, 0x3F9EB851E0000000
  %1807 = fadd fast float %1804, 0x3F9EB851E0000000
  %1808 = fadd fast float %1805, 0x3F9EB851E0000000
  %1809 = fmul fast float %1806, %1798
  %1810 = fmul fast float %1807, %1799
  %1811 = fmul fast float %1808, %1800
  %1812 = fmul fast float %1798, 0x400370A3E0000000
  %1813 = fmul fast float %1799, 0x400370A3E0000000
  %1814 = fmul fast float %1800, 0x400370A3E0000000
  %1815 = fadd fast float %1812, 0x3FE2E147A0000000
  %1816 = fadd fast float %1813, 0x3FE2E147A0000000
  %1817 = fadd fast float %1814, 0x3FE2E147A0000000
  %1818 = fmul fast float %1815, %1798
  %1819 = fmul fast float %1816, %1799
  %1820 = fmul fast float %1817, %1800
  %1821 = fadd fast float %1818, 0x3FC1EB8520000000
  %1822 = fadd fast float %1819, 0x3FC1EB8520000000
  %1823 = fadd fast float %1820, 0x3FC1EB8520000000
  %1824 = fdiv fast float %1809, %1821
  %1825 = fdiv fast float %1810, %1822
  %1826 = fdiv fast float %1811, %1823
  br label %1827

; <label>:1827                                    ; preds = %1802, %1791
  %1828 = phi float [ %1824, %1802 ], [ %1798, %1791 ]
  %1829 = phi float [ %1825, %1802 ], [ %1799, %1791 ]
  %1830 = phi float [ %1826, %1802 ], [ %1800, %1791 ]
  %1831 = call float @dx.op.unary.f32(i32 7, float %1828)  ; Saturate(value)
  %1832 = call float @dx.op.unary.f32(i32 7, float %1829)  ; Saturate(value)
  %1833 = call float @dx.op.unary.f32(i32 7, float %1830)  ; Saturate(value)
  %1834 = call float @dx.op.dot3.f32(i32 55, float %1831, float %1832, float %1833, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1835 = fsub fast float %1831, %1834
  %1836 = fsub fast float %1832, %1834
  %1837 = fsub fast float %1833, %1834
  %1838 = fmul fast float %1835, %8
  %1839 = fmul fast float %1836, %8
  %1840 = fmul fast float %1837, %8
  %1841 = fadd fast float %1838, %1834
  %1842 = fadd fast float %1839, %1834
  %1843 = fadd fast float %1840, %1834
  %1844 = call float @dx.op.unary.f32(i32 7, float %1841)  ; Saturate(value)
  %1845 = call float @dx.op.unary.f32(i32 7, float %1842)  ; Saturate(value)
  %1846 = call float @dx.op.unary.f32(i32 7, float %1843)  ; Saturate(value)
  %1847 = fadd fast float %1844, 0xBFC70A3D80000000
  %1848 = fadd fast float %1845, 0xBFC70A3D80000000
  %1849 = fadd fast float %1846, 0xBFC70A3D80000000
  %1850 = fmul fast float %1847, %7
  %1851 = fmul fast float %1848, %7
  %1852 = fmul fast float %1849, %7
  %1853 = fadd fast float %1850, 0x3FC70A3D80000000
  %1854 = fadd fast float %1851, 0x3FC70A3D80000000
  %1855 = fadd fast float %1852, 0x3FC70A3D80000000
  %1856 = call float @dx.op.unary.f32(i32 7, float %1853)  ; Saturate(value)
  %1857 = call float @dx.op.unary.f32(i32 7, float %1854)  ; Saturate(value)
  %1858 = call float @dx.op.unary.f32(i32 7, float %1855)  ; Saturate(value)
  %1859 = add i32 %41, -1
  %1860 = call i32 @dx.op.binary.i32(i32 37, i32 %34, i32 0)  ; IMax(a,b)
  %1861 = call i32 @dx.op.binary.i32(i32 37, i32 %1859, i32 0)  ; IMax(a,b)
  %1862 = call i32 @dx.op.binary.i32(i32 38, i32 %1860, i32 %30)  ; IMin(a,b)
  %1863 = call i32 @dx.op.binary.i32(i32 38, i32 %1861, i32 %31)  ; IMin(a,b)
  %1864 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1862, i32 %1863, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1865 = extractvalue %dx.types.ResRet.f32 %1864, 0
  %1866 = fsub fast float 1.000000e+00, %57
  %1867 = fmul fast float %1866, 0x3FA99999A0000000
  %1868 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %1867)  ; FMax(a,b)
  %1869 = fsub fast float %1865, %57
  %1870 = call float @dx.op.unary.f32(i32 6, float %1869)  ; FAbs(value)
  %1871 = fdiv fast float %1870, %1868
  %1872 = fsub fast float 1.000000e+00, %1871
  %1873 = call float @dx.op.unary.f32(i32 7, float %1872)  ; Saturate(value)
  %1874 = fcmp fast ugt float %1873, 0.000000e+00
  br i1 %1874, label %1875, label %2001

; <label>:1875                                    ; preds = %1827
  %1876 = call i32 @dx.op.binary.i32(i32 37, i32 %1862, i32 0)  ; IMax(a,b)
  %1877 = call i32 @dx.op.binary.i32(i32 37, i32 %1863, i32 0)  ; IMax(a,b)
  %1878 = call i32 @dx.op.binary.i32(i32 38, i32 %1876, i32 %30)  ; IMin(a,b)
  %1879 = call i32 @dx.op.binary.i32(i32 38, i32 %1877, i32 %31)  ; IMin(a,b)
  %1880 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1878, i32 %1879, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1881 = extractvalue %dx.types.ResRet.f32 %1880, 0
  %1882 = extractvalue %dx.types.ResRet.f32 %1880, 1
  %1883 = extractvalue %dx.types.ResRet.f32 %1880, 2
  %1884 = extractvalue %dx.types.ResRet.f32 %1880, 3
  %1885 = fcmp fast olt float %1884, 0.000000e+00
  br i1 %1885, label %1886, label %1920

; <label>:1886                                    ; preds = %1875
  %1887 = fcmp fast ogt float %1881, 0x3FA4B5DCC0000000
  %1888 = fcmp fast ogt float %1882, 0x3FA4B5DCC0000000
  %1889 = fcmp fast ogt float %1883, 0x3FA4B5DCC0000000
  %1890 = select i1 %1887, float 0.000000e+00, float 1.000000e+00
  %1891 = select i1 %1888, float 0.000000e+00, float 1.000000e+00
  %1892 = select i1 %1889, float 0.000000e+00, float 1.000000e+00
  %1893 = fmul fast float %1881, 0x3FB3D07220000000
  %1894 = fmul fast float %1882, 0x3FB3D07220000000
  %1895 = fmul fast float %1883, 0x3FB3D07220000000
  %1896 = fadd fast float %1881, 0x3FAC28F5C0000000
  %1897 = fadd fast float %1882, 0x3FAC28F5C0000000
  %1898 = fadd fast float %1883, 0x3FAC28F5C0000000
  %1899 = fmul fast float %1896, 0x3FEE54EDE0000000
  %1900 = fmul fast float %1897, 0x3FEE54EDE0000000
  %1901 = fmul fast float %1898, 0x3FEE54EDE0000000
  %1902 = call float @dx.op.unary.f32(i32 23, float %1899)  ; Log(value)
  %1903 = call float @dx.op.unary.f32(i32 23, float %1900)  ; Log(value)
  %1904 = call float @dx.op.unary.f32(i32 23, float %1901)  ; Log(value)
  %1905 = fmul fast float %1902, 0x4003333340000000
  %1906 = fmul fast float %1903, 0x4003333340000000
  %1907 = fmul fast float %1904, 0x4003333340000000
  %1908 = call float @dx.op.unary.f32(i32 21, float %1905)  ; Exp(value)
  %1909 = call float @dx.op.unary.f32(i32 21, float %1906)  ; Exp(value)
  %1910 = call float @dx.op.unary.f32(i32 21, float %1907)  ; Exp(value)
  %1911 = fsub fast float %1893, %1908
  %1912 = fsub fast float %1894, %1909
  %1913 = fsub fast float %1895, %1910
  %1914 = fmul fast float %1911, %1890
  %1915 = fmul fast float %1912, %1891
  %1916 = fmul fast float %1913, %1892
  %1917 = fadd fast float %1914, %1908
  %1918 = fadd fast float %1915, %1909
  %1919 = fadd fast float %1916, %1910
  br label %1988

; <label>:1920                                    ; preds = %1875
  %1921 = fadd fast float %5, 1.000000e+00
  %1922 = fadd fast float %6, 1.000000e+00
  %1923 = fsub fast float 1.000000e+00, %5
  %1924 = fmul fast float %9, %1921
  %1925 = fmul fast float %9, %1922
  %1926 = fmul fast float %9, %1923
  %1927 = fmul fast float %1924, %1881
  %1928 = fmul fast float %1925, %1882
  %1929 = fmul fast float %1926, %1883
  %1930 = fcmp fast ult float %10, 5.000000e-01
  br i1 %1930, label %1956, label %1931

; <label>:1931                                    ; preds = %1920
  %1932 = fmul fast float %1927, 0x4004147AE0000000
  %1933 = fmul fast float %1928, 0x4004147AE0000000
  %1934 = fmul fast float %1929, 0x4004147AE0000000
  %1935 = fadd fast float %1932, 0x3F9EB851E0000000
  %1936 = fadd fast float %1933, 0x3F9EB851E0000000
  %1937 = fadd fast float %1934, 0x3F9EB851E0000000
  %1938 = fmul fast float %1935, %1927
  %1939 = fmul fast float %1936, %1928
  %1940 = fmul fast float %1937, %1929
  %1941 = fmul fast float %1927, 0x400370A3E0000000
  %1942 = fmul fast float %1928, 0x400370A3E0000000
  %1943 = fmul fast float %1929, 0x400370A3E0000000
  %1944 = fadd fast float %1941, 0x3FE2E147A0000000
  %1945 = fadd fast float %1942, 0x3FE2E147A0000000
  %1946 = fadd fast float %1943, 0x3FE2E147A0000000
  %1947 = fmul fast float %1944, %1927
  %1948 = fmul fast float %1945, %1928
  %1949 = fmul fast float %1946, %1929
  %1950 = fadd fast float %1947, 0x3FC1EB8520000000
  %1951 = fadd fast float %1948, 0x3FC1EB8520000000
  %1952 = fadd fast float %1949, 0x3FC1EB8520000000
  %1953 = fdiv fast float %1938, %1950
  %1954 = fdiv fast float %1939, %1951
  %1955 = fdiv fast float %1940, %1952
  br label %1956

; <label>:1956                                    ; preds = %1931, %1920
  %1957 = phi float [ %1953, %1931 ], [ %1927, %1920 ]
  %1958 = phi float [ %1954, %1931 ], [ %1928, %1920 ]
  %1959 = phi float [ %1955, %1931 ], [ %1929, %1920 ]
  %1960 = call float @dx.op.unary.f32(i32 7, float %1957)  ; Saturate(value)
  %1961 = call float @dx.op.unary.f32(i32 7, float %1958)  ; Saturate(value)
  %1962 = call float @dx.op.unary.f32(i32 7, float %1959)  ; Saturate(value)
  %1963 = call float @dx.op.dot3.f32(i32 55, float %1960, float %1961, float %1962, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1964 = fsub fast float %1960, %1963
  %1965 = fsub fast float %1961, %1963
  %1966 = fsub fast float %1962, %1963
  %1967 = fmul fast float %1964, %8
  %1968 = fmul fast float %1965, %8
  %1969 = fmul fast float %1966, %8
  %1970 = fadd fast float %1967, %1963
  %1971 = fadd fast float %1968, %1963
  %1972 = fadd fast float %1969, %1963
  %1973 = call float @dx.op.unary.f32(i32 7, float %1970)  ; Saturate(value)
  %1974 = call float @dx.op.unary.f32(i32 7, float %1971)  ; Saturate(value)
  %1975 = call float @dx.op.unary.f32(i32 7, float %1972)  ; Saturate(value)
  %1976 = fadd fast float %1973, 0xBFC70A3D80000000
  %1977 = fadd fast float %1974, 0xBFC70A3D80000000
  %1978 = fadd fast float %1975, 0xBFC70A3D80000000
  %1979 = fmul fast float %1976, %7
  %1980 = fmul fast float %1977, %7
  %1981 = fmul fast float %1978, %7
  %1982 = fadd fast float %1979, 0x3FC70A3D80000000
  %1983 = fadd fast float %1980, 0x3FC70A3D80000000
  %1984 = fadd fast float %1981, 0x3FC70A3D80000000
  %1985 = call float @dx.op.unary.f32(i32 7, float %1982)  ; Saturate(value)
  %1986 = call float @dx.op.unary.f32(i32 7, float %1983)  ; Saturate(value)
  %1987 = call float @dx.op.unary.f32(i32 7, float %1984)  ; Saturate(value)
  br label %1988

; <label>:1988                                    ; preds = %1956, %1886
  %1989 = phi float [ %1917, %1886 ], [ %1985, %1956 ]
  %1990 = phi float [ %1918, %1886 ], [ %1986, %1956 ]
  %1991 = phi float [ %1919, %1886 ], [ %1987, %1956 ]
  %1992 = fsub fast float %1989, %1856
  %1993 = fsub fast float %1990, %1857
  %1994 = fsub fast float %1991, %1858
  %1995 = fmul fast float %1992, %1873
  %1996 = fmul fast float %1993, %1873
  %1997 = fmul fast float %1994, %1873
  %1998 = fadd fast float %1995, %1856
  %1999 = fadd fast float %1996, %1857
  %2000 = fadd fast float %1997, %1858
  br label %2001

; <label>:2001                                    ; preds = %1988, %1827
  %2002 = phi float [ %1998, %1988 ], [ %1856, %1827 ]
  %2003 = phi float [ %1999, %1988 ], [ %1857, %1827 ]
  %2004 = phi float [ %2000, %1988 ], [ %1858, %1827 ]
  %2005 = add i32 %41, 1
  %2006 = call i32 @dx.op.binary.i32(i32 37, i32 %2005, i32 0)  ; IMax(a,b)
  %2007 = call i32 @dx.op.binary.i32(i32 38, i32 %2006, i32 %31)  ; IMin(a,b)
  %2008 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1862, i32 %2007, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2009 = extractvalue %dx.types.ResRet.f32 %2008, 0
  %2010 = fsub fast float %2009, %57
  %2011 = call float @dx.op.unary.f32(i32 6, float %2010)  ; FAbs(value)
  %2012 = fdiv fast float %2011, %1868
  %2013 = fsub fast float 1.000000e+00, %2012
  %2014 = call float @dx.op.unary.f32(i32 7, float %2013)  ; Saturate(value)
  %2015 = fcmp fast ugt float %2014, 0.000000e+00
  br i1 %2015, label %2016, label %2142

; <label>:2016                                    ; preds = %2001
  %2017 = call i32 @dx.op.binary.i32(i32 37, i32 %1862, i32 0)  ; IMax(a,b)
  %2018 = call i32 @dx.op.binary.i32(i32 37, i32 %2007, i32 0)  ; IMax(a,b)
  %2019 = call i32 @dx.op.binary.i32(i32 38, i32 %2017, i32 %30)  ; IMin(a,b)
  %2020 = call i32 @dx.op.binary.i32(i32 38, i32 %2018, i32 %31)  ; IMin(a,b)
  %2021 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2019, i32 %2020, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2022 = extractvalue %dx.types.ResRet.f32 %2021, 0
  %2023 = extractvalue %dx.types.ResRet.f32 %2021, 1
  %2024 = extractvalue %dx.types.ResRet.f32 %2021, 2
  %2025 = extractvalue %dx.types.ResRet.f32 %2021, 3
  %2026 = fcmp fast olt float %2025, 0.000000e+00
  br i1 %2026, label %2027, label %2061

; <label>:2027                                    ; preds = %2016
  %2028 = fcmp fast ogt float %2022, 0x3FA4B5DCC0000000
  %2029 = fcmp fast ogt float %2023, 0x3FA4B5DCC0000000
  %2030 = fcmp fast ogt float %2024, 0x3FA4B5DCC0000000
  %2031 = select i1 %2028, float 0.000000e+00, float 1.000000e+00
  %2032 = select i1 %2029, float 0.000000e+00, float 1.000000e+00
  %2033 = select i1 %2030, float 0.000000e+00, float 1.000000e+00
  %2034 = fmul fast float %2022, 0x3FB3D07220000000
  %2035 = fmul fast float %2023, 0x3FB3D07220000000
  %2036 = fmul fast float %2024, 0x3FB3D07220000000
  %2037 = fadd fast float %2022, 0x3FAC28F5C0000000
  %2038 = fadd fast float %2023, 0x3FAC28F5C0000000
  %2039 = fadd fast float %2024, 0x3FAC28F5C0000000
  %2040 = fmul fast float %2037, 0x3FEE54EDE0000000
  %2041 = fmul fast float %2038, 0x3FEE54EDE0000000
  %2042 = fmul fast float %2039, 0x3FEE54EDE0000000
  %2043 = call float @dx.op.unary.f32(i32 23, float %2040)  ; Log(value)
  %2044 = call float @dx.op.unary.f32(i32 23, float %2041)  ; Log(value)
  %2045 = call float @dx.op.unary.f32(i32 23, float %2042)  ; Log(value)
  %2046 = fmul fast float %2043, 0x4003333340000000
  %2047 = fmul fast float %2044, 0x4003333340000000
  %2048 = fmul fast float %2045, 0x4003333340000000
  %2049 = call float @dx.op.unary.f32(i32 21, float %2046)  ; Exp(value)
  %2050 = call float @dx.op.unary.f32(i32 21, float %2047)  ; Exp(value)
  %2051 = call float @dx.op.unary.f32(i32 21, float %2048)  ; Exp(value)
  %2052 = fsub fast float %2034, %2049
  %2053 = fsub fast float %2035, %2050
  %2054 = fsub fast float %2036, %2051
  %2055 = fmul fast float %2052, %2031
  %2056 = fmul fast float %2053, %2032
  %2057 = fmul fast float %2054, %2033
  %2058 = fadd fast float %2055, %2049
  %2059 = fadd fast float %2056, %2050
  %2060 = fadd fast float %2057, %2051
  br label %2129

; <label>:2061                                    ; preds = %2016
  %2062 = fadd fast float %5, 1.000000e+00
  %2063 = fadd fast float %6, 1.000000e+00
  %2064 = fsub fast float 1.000000e+00, %5
  %2065 = fmul fast float %9, %2062
  %2066 = fmul fast float %9, %2063
  %2067 = fmul fast float %9, %2064
  %2068 = fmul fast float %2065, %2022
  %2069 = fmul fast float %2066, %2023
  %2070 = fmul fast float %2067, %2024
  %2071 = fcmp fast ult float %10, 5.000000e-01
  br i1 %2071, label %2097, label %2072

; <label>:2072                                    ; preds = %2061
  %2073 = fmul fast float %2068, 0x4004147AE0000000
  %2074 = fmul fast float %2069, 0x4004147AE0000000
  %2075 = fmul fast float %2070, 0x4004147AE0000000
  %2076 = fadd fast float %2073, 0x3F9EB851E0000000
  %2077 = fadd fast float %2074, 0x3F9EB851E0000000
  %2078 = fadd fast float %2075, 0x3F9EB851E0000000
  %2079 = fmul fast float %2076, %2068
  %2080 = fmul fast float %2077, %2069
  %2081 = fmul fast float %2078, %2070
  %2082 = fmul fast float %2068, 0x400370A3E0000000
  %2083 = fmul fast float %2069, 0x400370A3E0000000
  %2084 = fmul fast float %2070, 0x400370A3E0000000
  %2085 = fadd fast float %2082, 0x3FE2E147A0000000
  %2086 = fadd fast float %2083, 0x3FE2E147A0000000
  %2087 = fadd fast float %2084, 0x3FE2E147A0000000
  %2088 = fmul fast float %2085, %2068
  %2089 = fmul fast float %2086, %2069
  %2090 = fmul fast float %2087, %2070
  %2091 = fadd fast float %2088, 0x3FC1EB8520000000
  %2092 = fadd fast float %2089, 0x3FC1EB8520000000
  %2093 = fadd fast float %2090, 0x3FC1EB8520000000
  %2094 = fdiv fast float %2079, %2091
  %2095 = fdiv fast float %2080, %2092
  %2096 = fdiv fast float %2081, %2093
  br label %2097

; <label>:2097                                    ; preds = %2072, %2061
  %2098 = phi float [ %2094, %2072 ], [ %2068, %2061 ]
  %2099 = phi float [ %2095, %2072 ], [ %2069, %2061 ]
  %2100 = phi float [ %2096, %2072 ], [ %2070, %2061 ]
  %2101 = call float @dx.op.unary.f32(i32 7, float %2098)  ; Saturate(value)
  %2102 = call float @dx.op.unary.f32(i32 7, float %2099)  ; Saturate(value)
  %2103 = call float @dx.op.unary.f32(i32 7, float %2100)  ; Saturate(value)
  %2104 = call float @dx.op.dot3.f32(i32 55, float %2101, float %2102, float %2103, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2105 = fsub fast float %2101, %2104
  %2106 = fsub fast float %2102, %2104
  %2107 = fsub fast float %2103, %2104
  %2108 = fmul fast float %2105, %8
  %2109 = fmul fast float %2106, %8
  %2110 = fmul fast float %2107, %8
  %2111 = fadd fast float %2108, %2104
  %2112 = fadd fast float %2109, %2104
  %2113 = fadd fast float %2110, %2104
  %2114 = call float @dx.op.unary.f32(i32 7, float %2111)  ; Saturate(value)
  %2115 = call float @dx.op.unary.f32(i32 7, float %2112)  ; Saturate(value)
  %2116 = call float @dx.op.unary.f32(i32 7, float %2113)  ; Saturate(value)
  %2117 = fadd fast float %2114, 0xBFC70A3D80000000
  %2118 = fadd fast float %2115, 0xBFC70A3D80000000
  %2119 = fadd fast float %2116, 0xBFC70A3D80000000
  %2120 = fmul fast float %2117, %7
  %2121 = fmul fast float %2118, %7
  %2122 = fmul fast float %2119, %7
  %2123 = fadd fast float %2120, 0x3FC70A3D80000000
  %2124 = fadd fast float %2121, 0x3FC70A3D80000000
  %2125 = fadd fast float %2122, 0x3FC70A3D80000000
  %2126 = call float @dx.op.unary.f32(i32 7, float %2123)  ; Saturate(value)
  %2127 = call float @dx.op.unary.f32(i32 7, float %2124)  ; Saturate(value)
  %2128 = call float @dx.op.unary.f32(i32 7, float %2125)  ; Saturate(value)
  br label %2129

; <label>:2129                                    ; preds = %2097, %2027
  %2130 = phi float [ %2058, %2027 ], [ %2126, %2097 ]
  %2131 = phi float [ %2059, %2027 ], [ %2127, %2097 ]
  %2132 = phi float [ %2060, %2027 ], [ %2128, %2097 ]
  %2133 = fsub fast float %2130, %1856
  %2134 = fsub fast float %2131, %1857
  %2135 = fsub fast float %2132, %1858
  %2136 = fmul fast float %2133, %2014
  %2137 = fmul fast float %2134, %2014
  %2138 = fmul fast float %2135, %2014
  %2139 = fadd fast float %2136, %1856
  %2140 = fadd fast float %2137, %1857
  %2141 = fadd fast float %2138, %1858
  br label %2142

; <label>:2142                                    ; preds = %2129, %2001
  %2143 = phi float [ %2139, %2129 ], [ %1856, %2001 ]
  %2144 = phi float [ %2140, %2129 ], [ %1857, %2001 ]
  %2145 = phi float [ %2141, %2129 ], [ %1858, %2001 ]
  %2146 = add i32 %34, -1
  %2147 = call i32 @dx.op.binary.i32(i32 37, i32 %2146, i32 0)  ; IMax(a,b)
  %2148 = call i32 @dx.op.binary.i32(i32 37, i32 %41, i32 0)  ; IMax(a,b)
  %2149 = call i32 @dx.op.binary.i32(i32 38, i32 %2147, i32 %30)  ; IMin(a,b)
  %2150 = call i32 @dx.op.binary.i32(i32 38, i32 %2148, i32 %31)  ; IMin(a,b)
  %2151 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2149, i32 %2150, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2152 = extractvalue %dx.types.ResRet.f32 %2151, 0
  %2153 = fsub fast float %2152, %57
  %2154 = call float @dx.op.unary.f32(i32 6, float %2153)  ; FAbs(value)
  %2155 = fdiv fast float %2154, %1868
  %2156 = fsub fast float 1.000000e+00, %2155
  %2157 = call float @dx.op.unary.f32(i32 7, float %2156)  ; Saturate(value)
  %2158 = fcmp fast ugt float %2157, 0.000000e+00
  br i1 %2158, label %2159, label %2285

; <label>:2159                                    ; preds = %2142
  %2160 = call i32 @dx.op.binary.i32(i32 37, i32 %2149, i32 0)  ; IMax(a,b)
  %2161 = call i32 @dx.op.binary.i32(i32 37, i32 %2150, i32 0)  ; IMax(a,b)
  %2162 = call i32 @dx.op.binary.i32(i32 38, i32 %2160, i32 %30)  ; IMin(a,b)
  %2163 = call i32 @dx.op.binary.i32(i32 38, i32 %2161, i32 %31)  ; IMin(a,b)
  %2164 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2162, i32 %2163, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2165 = extractvalue %dx.types.ResRet.f32 %2164, 0
  %2166 = extractvalue %dx.types.ResRet.f32 %2164, 1
  %2167 = extractvalue %dx.types.ResRet.f32 %2164, 2
  %2168 = extractvalue %dx.types.ResRet.f32 %2164, 3
  %2169 = fcmp fast olt float %2168, 0.000000e+00
  br i1 %2169, label %2170, label %2204

; <label>:2170                                    ; preds = %2159
  %2171 = fcmp fast ogt float %2165, 0x3FA4B5DCC0000000
  %2172 = fcmp fast ogt float %2166, 0x3FA4B5DCC0000000
  %2173 = fcmp fast ogt float %2167, 0x3FA4B5DCC0000000
  %2174 = select i1 %2171, float 0.000000e+00, float 1.000000e+00
  %2175 = select i1 %2172, float 0.000000e+00, float 1.000000e+00
  %2176 = select i1 %2173, float 0.000000e+00, float 1.000000e+00
  %2177 = fmul fast float %2165, 0x3FB3D07220000000
  %2178 = fmul fast float %2166, 0x3FB3D07220000000
  %2179 = fmul fast float %2167, 0x3FB3D07220000000
  %2180 = fadd fast float %2165, 0x3FAC28F5C0000000
  %2181 = fadd fast float %2166, 0x3FAC28F5C0000000
  %2182 = fadd fast float %2167, 0x3FAC28F5C0000000
  %2183 = fmul fast float %2180, 0x3FEE54EDE0000000
  %2184 = fmul fast float %2181, 0x3FEE54EDE0000000
  %2185 = fmul fast float %2182, 0x3FEE54EDE0000000
  %2186 = call float @dx.op.unary.f32(i32 23, float %2183)  ; Log(value)
  %2187 = call float @dx.op.unary.f32(i32 23, float %2184)  ; Log(value)
  %2188 = call float @dx.op.unary.f32(i32 23, float %2185)  ; Log(value)
  %2189 = fmul fast float %2186, 0x4003333340000000
  %2190 = fmul fast float %2187, 0x4003333340000000
  %2191 = fmul fast float %2188, 0x4003333340000000
  %2192 = call float @dx.op.unary.f32(i32 21, float %2189)  ; Exp(value)
  %2193 = call float @dx.op.unary.f32(i32 21, float %2190)  ; Exp(value)
  %2194 = call float @dx.op.unary.f32(i32 21, float %2191)  ; Exp(value)
  %2195 = fsub fast float %2177, %2192
  %2196 = fsub fast float %2178, %2193
  %2197 = fsub fast float %2179, %2194
  %2198 = fmul fast float %2195, %2174
  %2199 = fmul fast float %2196, %2175
  %2200 = fmul fast float %2197, %2176
  %2201 = fadd fast float %2198, %2192
  %2202 = fadd fast float %2199, %2193
  %2203 = fadd fast float %2200, %2194
  br label %2272

; <label>:2204                                    ; preds = %2159
  %2205 = fadd fast float %5, 1.000000e+00
  %2206 = fadd fast float %6, 1.000000e+00
  %2207 = fsub fast float 1.000000e+00, %5
  %2208 = fmul fast float %9, %2205
  %2209 = fmul fast float %9, %2206
  %2210 = fmul fast float %9, %2207
  %2211 = fmul fast float %2208, %2165
  %2212 = fmul fast float %2209, %2166
  %2213 = fmul fast float %2210, %2167
  %2214 = fcmp fast ult float %10, 5.000000e-01
  br i1 %2214, label %2240, label %2215

; <label>:2215                                    ; preds = %2204
  %2216 = fmul fast float %2211, 0x4004147AE0000000
  %2217 = fmul fast float %2212, 0x4004147AE0000000
  %2218 = fmul fast float %2213, 0x4004147AE0000000
  %2219 = fadd fast float %2216, 0x3F9EB851E0000000
  %2220 = fadd fast float %2217, 0x3F9EB851E0000000
  %2221 = fadd fast float %2218, 0x3F9EB851E0000000
  %2222 = fmul fast float %2219, %2211
  %2223 = fmul fast float %2220, %2212
  %2224 = fmul fast float %2221, %2213
  %2225 = fmul fast float %2211, 0x400370A3E0000000
  %2226 = fmul fast float %2212, 0x400370A3E0000000
  %2227 = fmul fast float %2213, 0x400370A3E0000000
  %2228 = fadd fast float %2225, 0x3FE2E147A0000000
  %2229 = fadd fast float %2226, 0x3FE2E147A0000000
  %2230 = fadd fast float %2227, 0x3FE2E147A0000000
  %2231 = fmul fast float %2228, %2211
  %2232 = fmul fast float %2229, %2212
  %2233 = fmul fast float %2230, %2213
  %2234 = fadd fast float %2231, 0x3FC1EB8520000000
  %2235 = fadd fast float %2232, 0x3FC1EB8520000000
  %2236 = fadd fast float %2233, 0x3FC1EB8520000000
  %2237 = fdiv fast float %2222, %2234
  %2238 = fdiv fast float %2223, %2235
  %2239 = fdiv fast float %2224, %2236
  br label %2240

; <label>:2240                                    ; preds = %2215, %2204
  %2241 = phi float [ %2237, %2215 ], [ %2211, %2204 ]
  %2242 = phi float [ %2238, %2215 ], [ %2212, %2204 ]
  %2243 = phi float [ %2239, %2215 ], [ %2213, %2204 ]
  %2244 = call float @dx.op.unary.f32(i32 7, float %2241)  ; Saturate(value)
  %2245 = call float @dx.op.unary.f32(i32 7, float %2242)  ; Saturate(value)
  %2246 = call float @dx.op.unary.f32(i32 7, float %2243)  ; Saturate(value)
  %2247 = call float @dx.op.dot3.f32(i32 55, float %2244, float %2245, float %2246, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2248 = fsub fast float %2244, %2247
  %2249 = fsub fast float %2245, %2247
  %2250 = fsub fast float %2246, %2247
  %2251 = fmul fast float %2248, %8
  %2252 = fmul fast float %2249, %8
  %2253 = fmul fast float %2250, %8
  %2254 = fadd fast float %2251, %2247
  %2255 = fadd fast float %2252, %2247
  %2256 = fadd fast float %2253, %2247
  %2257 = call float @dx.op.unary.f32(i32 7, float %2254)  ; Saturate(value)
  %2258 = call float @dx.op.unary.f32(i32 7, float %2255)  ; Saturate(value)
  %2259 = call float @dx.op.unary.f32(i32 7, float %2256)  ; Saturate(value)
  %2260 = fadd fast float %2257, 0xBFC70A3D80000000
  %2261 = fadd fast float %2258, 0xBFC70A3D80000000
  %2262 = fadd fast float %2259, 0xBFC70A3D80000000
  %2263 = fmul fast float %2260, %7
  %2264 = fmul fast float %2261, %7
  %2265 = fmul fast float %2262, %7
  %2266 = fadd fast float %2263, 0x3FC70A3D80000000
  %2267 = fadd fast float %2264, 0x3FC70A3D80000000
  %2268 = fadd fast float %2265, 0x3FC70A3D80000000
  %2269 = call float @dx.op.unary.f32(i32 7, float %2266)  ; Saturate(value)
  %2270 = call float @dx.op.unary.f32(i32 7, float %2267)  ; Saturate(value)
  %2271 = call float @dx.op.unary.f32(i32 7, float %2268)  ; Saturate(value)
  br label %2272

; <label>:2272                                    ; preds = %2240, %2170
  %2273 = phi float [ %2201, %2170 ], [ %2269, %2240 ]
  %2274 = phi float [ %2202, %2170 ], [ %2270, %2240 ]
  %2275 = phi float [ %2203, %2170 ], [ %2271, %2240 ]
  %2276 = fsub fast float %2273, %1856
  %2277 = fsub fast float %2274, %1857
  %2278 = fsub fast float %2275, %1858
  %2279 = fmul fast float %2276, %2157
  %2280 = fmul fast float %2277, %2157
  %2281 = fmul fast float %2278, %2157
  %2282 = fadd fast float %2279, %1856
  %2283 = fadd fast float %2280, %1857
  %2284 = fadd fast float %2281, %1858
  br label %2285

; <label>:2285                                    ; preds = %2272, %2142
  %2286 = phi float [ %2282, %2272 ], [ %1856, %2142 ]
  %2287 = phi float [ %2283, %2272 ], [ %1857, %2142 ]
  %2288 = phi float [ %2284, %2272 ], [ %1858, %2142 ]
  %2289 = add i32 %34, 1
  %2290 = call i32 @dx.op.binary.i32(i32 37, i32 %2289, i32 0)  ; IMax(a,b)
  %2291 = call i32 @dx.op.binary.i32(i32 38, i32 %2290, i32 %30)  ; IMin(a,b)
  %2292 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2291, i32 %2150, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2293 = extractvalue %dx.types.ResRet.f32 %2292, 0
  %2294 = fsub fast float %2293, %57
  %2295 = call float @dx.op.unary.f32(i32 6, float %2294)  ; FAbs(value)
  %2296 = fdiv fast float %2295, %1868
  %2297 = fsub fast float 1.000000e+00, %2296
  %2298 = call float @dx.op.unary.f32(i32 7, float %2297)  ; Saturate(value)
  %2299 = fcmp fast ugt float %2298, 0.000000e+00
  br i1 %2299, label %2300, label %2426

; <label>:2300                                    ; preds = %2285
  %2301 = call i32 @dx.op.binary.i32(i32 37, i32 %2291, i32 0)  ; IMax(a,b)
  %2302 = call i32 @dx.op.binary.i32(i32 37, i32 %2150, i32 0)  ; IMax(a,b)
  %2303 = call i32 @dx.op.binary.i32(i32 38, i32 %2301, i32 %30)  ; IMin(a,b)
  %2304 = call i32 @dx.op.binary.i32(i32 38, i32 %2302, i32 %31)  ; IMin(a,b)
  %2305 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2303, i32 %2304, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2306 = extractvalue %dx.types.ResRet.f32 %2305, 0
  %2307 = extractvalue %dx.types.ResRet.f32 %2305, 1
  %2308 = extractvalue %dx.types.ResRet.f32 %2305, 2
  %2309 = extractvalue %dx.types.ResRet.f32 %2305, 3
  %2310 = fcmp fast olt float %2309, 0.000000e+00
  br i1 %2310, label %2311, label %2345

; <label>:2311                                    ; preds = %2300
  %2312 = fcmp fast ogt float %2306, 0x3FA4B5DCC0000000
  %2313 = fcmp fast ogt float %2307, 0x3FA4B5DCC0000000
  %2314 = fcmp fast ogt float %2308, 0x3FA4B5DCC0000000
  %2315 = select i1 %2312, float 0.000000e+00, float 1.000000e+00
  %2316 = select i1 %2313, float 0.000000e+00, float 1.000000e+00
  %2317 = select i1 %2314, float 0.000000e+00, float 1.000000e+00
  %2318 = fmul fast float %2306, 0x3FB3D07220000000
  %2319 = fmul fast float %2307, 0x3FB3D07220000000
  %2320 = fmul fast float %2308, 0x3FB3D07220000000
  %2321 = fadd fast float %2306, 0x3FAC28F5C0000000
  %2322 = fadd fast float %2307, 0x3FAC28F5C0000000
  %2323 = fadd fast float %2308, 0x3FAC28F5C0000000
  %2324 = fmul fast float %2321, 0x3FEE54EDE0000000
  %2325 = fmul fast float %2322, 0x3FEE54EDE0000000
  %2326 = fmul fast float %2323, 0x3FEE54EDE0000000
  %2327 = call float @dx.op.unary.f32(i32 23, float %2324)  ; Log(value)
  %2328 = call float @dx.op.unary.f32(i32 23, float %2325)  ; Log(value)
  %2329 = call float @dx.op.unary.f32(i32 23, float %2326)  ; Log(value)
  %2330 = fmul fast float %2327, 0x4003333340000000
  %2331 = fmul fast float %2328, 0x4003333340000000
  %2332 = fmul fast float %2329, 0x4003333340000000
  %2333 = call float @dx.op.unary.f32(i32 21, float %2330)  ; Exp(value)
  %2334 = call float @dx.op.unary.f32(i32 21, float %2331)  ; Exp(value)
  %2335 = call float @dx.op.unary.f32(i32 21, float %2332)  ; Exp(value)
  %2336 = fsub fast float %2318, %2333
  %2337 = fsub fast float %2319, %2334
  %2338 = fsub fast float %2320, %2335
  %2339 = fmul fast float %2336, %2315
  %2340 = fmul fast float %2337, %2316
  %2341 = fmul fast float %2338, %2317
  %2342 = fadd fast float %2339, %2333
  %2343 = fadd fast float %2340, %2334
  %2344 = fadd fast float %2341, %2335
  br label %2413

; <label>:2345                                    ; preds = %2300
  %2346 = fadd fast float %5, 1.000000e+00
  %2347 = fadd fast float %6, 1.000000e+00
  %2348 = fsub fast float 1.000000e+00, %5
  %2349 = fmul fast float %9, %2346
  %2350 = fmul fast float %9, %2347
  %2351 = fmul fast float %9, %2348
  %2352 = fmul fast float %2349, %2306
  %2353 = fmul fast float %2350, %2307
  %2354 = fmul fast float %2351, %2308
  %2355 = fcmp fast ult float %10, 5.000000e-01
  br i1 %2355, label %2381, label %2356

; <label>:2356                                    ; preds = %2345
  %2357 = fmul fast float %2352, 0x4004147AE0000000
  %2358 = fmul fast float %2353, 0x4004147AE0000000
  %2359 = fmul fast float %2354, 0x4004147AE0000000
  %2360 = fadd fast float %2357, 0x3F9EB851E0000000
  %2361 = fadd fast float %2358, 0x3F9EB851E0000000
  %2362 = fadd fast float %2359, 0x3F9EB851E0000000
  %2363 = fmul fast float %2360, %2352
  %2364 = fmul fast float %2361, %2353
  %2365 = fmul fast float %2362, %2354
  %2366 = fmul fast float %2352, 0x400370A3E0000000
  %2367 = fmul fast float %2353, 0x400370A3E0000000
  %2368 = fmul fast float %2354, 0x400370A3E0000000
  %2369 = fadd fast float %2366, 0x3FE2E147A0000000
  %2370 = fadd fast float %2367, 0x3FE2E147A0000000
  %2371 = fadd fast float %2368, 0x3FE2E147A0000000
  %2372 = fmul fast float %2369, %2352
  %2373 = fmul fast float %2370, %2353
  %2374 = fmul fast float %2371, %2354
  %2375 = fadd fast float %2372, 0x3FC1EB8520000000
  %2376 = fadd fast float %2373, 0x3FC1EB8520000000
  %2377 = fadd fast float %2374, 0x3FC1EB8520000000
  %2378 = fdiv fast float %2363, %2375
  %2379 = fdiv fast float %2364, %2376
  %2380 = fdiv fast float %2365, %2377
  br label %2381

; <label>:2381                                    ; preds = %2356, %2345
  %2382 = phi float [ %2378, %2356 ], [ %2352, %2345 ]
  %2383 = phi float [ %2379, %2356 ], [ %2353, %2345 ]
  %2384 = phi float [ %2380, %2356 ], [ %2354, %2345 ]
  %2385 = call float @dx.op.unary.f32(i32 7, float %2382)  ; Saturate(value)
  %2386 = call float @dx.op.unary.f32(i32 7, float %2383)  ; Saturate(value)
  %2387 = call float @dx.op.unary.f32(i32 7, float %2384)  ; Saturate(value)
  %2388 = call float @dx.op.dot3.f32(i32 55, float %2385, float %2386, float %2387, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2389 = fsub fast float %2385, %2388
  %2390 = fsub fast float %2386, %2388
  %2391 = fsub fast float %2387, %2388
  %2392 = fmul fast float %2389, %8
  %2393 = fmul fast float %2390, %8
  %2394 = fmul fast float %2391, %8
  %2395 = fadd fast float %2392, %2388
  %2396 = fadd fast float %2393, %2388
  %2397 = fadd fast float %2394, %2388
  %2398 = call float @dx.op.unary.f32(i32 7, float %2395)  ; Saturate(value)
  %2399 = call float @dx.op.unary.f32(i32 7, float %2396)  ; Saturate(value)
  %2400 = call float @dx.op.unary.f32(i32 7, float %2397)  ; Saturate(value)
  %2401 = fadd fast float %2398, 0xBFC70A3D80000000
  %2402 = fadd fast float %2399, 0xBFC70A3D80000000
  %2403 = fadd fast float %2400, 0xBFC70A3D80000000
  %2404 = fmul fast float %2401, %7
  %2405 = fmul fast float %2402, %7
  %2406 = fmul fast float %2403, %7
  %2407 = fadd fast float %2404, 0x3FC70A3D80000000
  %2408 = fadd fast float %2405, 0x3FC70A3D80000000
  %2409 = fadd fast float %2406, 0x3FC70A3D80000000
  %2410 = call float @dx.op.unary.f32(i32 7, float %2407)  ; Saturate(value)
  %2411 = call float @dx.op.unary.f32(i32 7, float %2408)  ; Saturate(value)
  %2412 = call float @dx.op.unary.f32(i32 7, float %2409)  ; Saturate(value)
  br label %2413

; <label>:2413                                    ; preds = %2381, %2311
  %2414 = phi float [ %2342, %2311 ], [ %2410, %2381 ]
  %2415 = phi float [ %2343, %2311 ], [ %2411, %2381 ]
  %2416 = phi float [ %2344, %2311 ], [ %2412, %2381 ]
  %2417 = fsub fast float %2414, %1856
  %2418 = fsub fast float %2415, %1857
  %2419 = fsub fast float %2416, %1858
  %2420 = fmul fast float %2417, %2298
  %2421 = fmul fast float %2418, %2298
  %2422 = fmul fast float %2419, %2298
  %2423 = fadd fast float %2420, %1856
  %2424 = fadd fast float %2421, %1857
  %2425 = fadd fast float %2422, %1858
  br label %2426

; <label>:2426                                    ; preds = %2413, %2285
  %2427 = phi float [ %2423, %2413 ], [ %1856, %2285 ]
  %2428 = phi float [ %2424, %2413 ], [ %1857, %2285 ]
  %2429 = phi float [ %2425, %2413 ], [ %1858, %2285 ]
  %2430 = call float @dx.op.binary.f32(i32 36, float %2286, float %2427)  ; FMin(a,b)
  %2431 = call float @dx.op.binary.f32(i32 36, float %2287, float %2428)  ; FMin(a,b)
  %2432 = call float @dx.op.binary.f32(i32 36, float %2288, float %2429)  ; FMin(a,b)
  %2433 = call float @dx.op.binary.f32(i32 36, float %2002, float %2143)  ; FMin(a,b)
  %2434 = call float @dx.op.binary.f32(i32 36, float %2003, float %2144)  ; FMin(a,b)
  %2435 = call float @dx.op.binary.f32(i32 36, float %2004, float %2145)  ; FMin(a,b)
  %2436 = call float @dx.op.binary.f32(i32 36, float %2433, float %2430)  ; FMin(a,b)
  %2437 = call float @dx.op.binary.f32(i32 36, float %2434, float %2431)  ; FMin(a,b)
  %2438 = call float @dx.op.binary.f32(i32 36, float %2435, float %2432)  ; FMin(a,b)
  %2439 = call float @dx.op.binary.f32(i32 36, float %1856, float %2436)  ; FMin(a,b)
  %2440 = call float @dx.op.binary.f32(i32 36, float %1857, float %2437)  ; FMin(a,b)
  %2441 = call float @dx.op.binary.f32(i32 36, float %1858, float %2438)  ; FMin(a,b)
  %2442 = call float @dx.op.binary.f32(i32 35, float %2286, float %2427)  ; FMax(a,b)
  %2443 = call float @dx.op.binary.f32(i32 35, float %2287, float %2428)  ; FMax(a,b)
  %2444 = call float @dx.op.binary.f32(i32 35, float %2288, float %2429)  ; FMax(a,b)
  %2445 = call float @dx.op.binary.f32(i32 35, float %2002, float %2143)  ; FMax(a,b)
  %2446 = call float @dx.op.binary.f32(i32 35, float %2003, float %2144)  ; FMax(a,b)
  %2447 = call float @dx.op.binary.f32(i32 35, float %2004, float %2145)  ; FMax(a,b)
  %2448 = call float @dx.op.binary.f32(i32 35, float %2445, float %2442)  ; FMax(a,b)
  %2449 = call float @dx.op.binary.f32(i32 35, float %2446, float %2443)  ; FMax(a,b)
  %2450 = call float @dx.op.binary.f32(i32 35, float %2447, float %2444)  ; FMax(a,b)
  %2451 = call float @dx.op.binary.f32(i32 35, float %1856, float %2448)  ; FMax(a,b)
  %2452 = call float @dx.op.binary.f32(i32 35, float %1857, float %2449)  ; FMax(a,b)
  %2453 = call float @dx.op.binary.f32(i32 35, float %1858, float %2450)  ; FMax(a,b)
  %2454 = fsub fast float %2451, %2439
  %2455 = fsub fast float %2452, %2440
  %2456 = fsub fast float %2453, %2441
  %2457 = call float @dx.op.unary.f32(i32 6, float %2454)  ; FAbs(value)
  %2458 = call float @dx.op.unary.f32(i32 6, float %2455)  ; FAbs(value)
  %2459 = call float @dx.op.unary.f32(i32 6, float %2456)  ; FAbs(value)
  %2460 = call float @dx.op.binary.f32(i32 35, float %2458, float %2459)  ; FMax(a,b)
  %2461 = call float @dx.op.binary.f32(i32 35, float %2457, float %2460)  ; FMax(a,b)
  %2462 = call float @dx.op.binary.f32(i32 35, float %2452, float %2453)  ; FMax(a,b)
  %2463 = call float @dx.op.binary.f32(i32 35, float %2451, float %2462)  ; FMax(a,b)
  %2464 = fmul fast float %2463, 1.250000e-01
  %2465 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %2464)  ; FMax(a,b)
  %2466 = fcmp fast ogt float %2461, %2465
  br i1 %2466, label %2467, label %2528

; <label>:2467                                    ; preds = %2426
  %2468 = fsub fast float %2002, %2143
  %2469 = fsub fast float %2003, %2144
  %2470 = fsub fast float %2004, %2145
  %2471 = call float @dx.op.unary.f32(i32 6, float %2468)  ; FAbs(value)
  %2472 = call float @dx.op.unary.f32(i32 6, float %2469)  ; FAbs(value)
  %2473 = call float @dx.op.unary.f32(i32 6, float %2470)  ; FAbs(value)
  %2474 = call float @dx.op.binary.f32(i32 35, float %2472, float %2473)  ; FMax(a,b)
  %2475 = call float @dx.op.binary.f32(i32 35, float %2471, float %2474)  ; FMax(a,b)
  %2476 = fsub fast float %2286, %2427
  %2477 = fsub fast float %2287, %2428
  %2478 = fsub fast float %2288, %2429
  %2479 = call float @dx.op.unary.f32(i32 6, float %2476)  ; FAbs(value)
  %2480 = call float @dx.op.unary.f32(i32 6, float %2477)  ; FAbs(value)
  %2481 = call float @dx.op.unary.f32(i32 6, float %2478)  ; FAbs(value)
  %2482 = call float @dx.op.binary.f32(i32 35, float %2480, float %2481)  ; FMax(a,b)
  %2483 = call float @dx.op.binary.f32(i32 35, float %2479, float %2482)  ; FMax(a,b)
  %2484 = fcmp fast olt float %2475, %2483
  %2485 = select i1 %2484, float %2002, float %2286
  %2486 = select i1 %2484, float %2003, float %2287
  %2487 = select i1 %2484, float %2004, float %2288
  %2488 = select i1 %2484, float %2143, float %2427
  %2489 = select i1 %2484, float %2144, float %2428
  %2490 = select i1 %2484, float %2145, float %2429
  %2491 = fsub fast float %1856, %2488
  %2492 = fsub fast float %1857, %2489
  %2493 = fsub fast float %1858, %2490
  %2494 = fsub fast float %1856, %2485
  %2495 = fsub fast float %1857, %2486
  %2496 = fsub fast float %1858, %2487
  %2497 = call float @dx.op.dot3.f32(i32 55, float %2494, float %2495, float %2496, float %2491, float %2492, float %2493)  ; Dot3(ax,ay,az,bx,by,bz)
  %2498 = fcmp fast ogt float %2497, 0.000000e+00
  br i1 %2498, label %2499, label %2510

; <label>:2499                                    ; preds = %2467
  %2500 = fsub fast float %2485, %2488
  %2501 = fsub fast float %2486, %2489
  %2502 = fsub fast float %2487, %2490
  %2503 = call float @dx.op.unary.f32(i32 6, float %2500)  ; FAbs(value)
  %2504 = call float @dx.op.unary.f32(i32 6, float %2501)  ; FAbs(value)
  %2505 = call float @dx.op.unary.f32(i32 6, float %2502)  ; FAbs(value)
  %2506 = call float @dx.op.binary.f32(i32 35, float %2504, float %2505)  ; FMax(a,b)
  %2507 = call float @dx.op.binary.f32(i32 35, float %2503, float %2506)  ; FMax(a,b)
  %2508 = fmul fast float %2461, 2.500000e-01
  %2509 = fcmp fast olt float %2507, %2508
  br label %2510

; <label>:2510                                    ; preds = %2499, %2467
  %2511 = phi i1 [ false, %2467 ], [ %2509, %2499 ]
  %2512 = select i1 %2511, float 0x3FC3333340000000, float 0x3FD3333340000000
  %2513 = fadd fast float %2485, %2488
  %2514 = fadd fast float %2486, %2489
  %2515 = fadd fast float %2487, %2490
  %2516 = fmul fast float %2513, 5.000000e-01
  %2517 = fmul fast float %2514, 5.000000e-01
  %2518 = fmul fast float %2515, 5.000000e-01
  %2519 = fsub fast float %2516, %1856
  %2520 = fsub fast float %2517, %1857
  %2521 = fsub fast float %2518, %1858
  %2522 = fmul fast float %2512, %2519
  %2523 = fmul fast float %2512, %2520
  %2524 = fmul fast float %2512, %2521
  %2525 = fadd fast float %2522, %1856
  %2526 = fadd fast float %2523, %1857
  %2527 = fadd fast float %2524, %1858
  br label %2528

; <label>:2528                                    ; preds = %2510, %2426
  %2529 = phi float [ %2525, %2510 ], [ %1856, %2426 ]
  %2530 = phi float [ %2526, %2510 ], [ %1857, %2426 ]
  %2531 = phi float [ %2527, %2510 ], [ %1858, %2426 ]
  %2532 = fcmp fast ogt float %2529, 0x3F69A5C380000000
  %2533 = fcmp fast ogt float %2530, 0x3F69A5C380000000
  %2534 = fcmp fast ogt float %2531, 0x3F69A5C380000000
  %2535 = select i1 %2532, float 0.000000e+00, float 1.000000e+00
  %2536 = select i1 %2533, float 0.000000e+00, float 1.000000e+00
  %2537 = select i1 %2534, float 0.000000e+00, float 1.000000e+00
  %2538 = fmul fast float %2529, 0x4029D70A40000000
  %2539 = fmul fast float %2530, 0x4029D70A40000000
  %2540 = fmul fast float %2531, 0x4029D70A40000000
  %2541 = call float @dx.op.binary.f32(i32 35, float %2529, float 0.000000e+00)  ; FMax(a,b)
  %2542 = call float @dx.op.binary.f32(i32 35, float %2530, float 0.000000e+00)  ; FMax(a,b)
  %2543 = call float @dx.op.binary.f32(i32 35, float %2531, float 0.000000e+00)  ; FMax(a,b)
  %2544 = call float @dx.op.unary.f32(i32 23, float %2541)  ; Log(value)
  %2545 = call float @dx.op.unary.f32(i32 23, float %2542)  ; Log(value)
  %2546 = call float @dx.op.unary.f32(i32 23, float %2543)  ; Log(value)
  %2547 = fmul fast float %2544, 0x3FDAAAAAA0000000
  %2548 = fmul fast float %2545, 0x3FDAAAAAA0000000
  %2549 = fmul fast float %2546, 0x3FDAAAAAA0000000
  %2550 = call float @dx.op.unary.f32(i32 21, float %2547)  ; Exp(value)
  %2551 = call float @dx.op.unary.f32(i32 21, float %2548)  ; Exp(value)
  %2552 = call float @dx.op.unary.f32(i32 21, float %2549)  ; Exp(value)
  %2553 = fmul fast float %2550, 0x3FF0E147A0000000
  %2554 = fmul fast float %2551, 0x3FF0E147A0000000
  %2555 = fmul fast float %2552, 0x3FF0E147A0000000
  %2556 = fadd fast float %2553, 0xBFAC28F5C0000000
  %2557 = fadd fast float %2554, 0xBFAC28F5C0000000
  %2558 = fadd fast float %2555, 0xBFAC28F5C0000000
  %2559 = fsub fast float %2538, %2556
  %2560 = fsub fast float %2539, %2557
  %2561 = fsub fast float %2540, %2558
  %2562 = fmul fast float %2559, %2535
  %2563 = fmul fast float %2560, %2536
  %2564 = fmul fast float %2561, %2537
  %2565 = fadd fast float %2562, %2556
  %2566 = fadd fast float %2563, %2557
  %2567 = fadd fast float %2564, %2558
  br label %2568

; <label>:2568                                    ; preds = %2528, %1789
  %2569 = phi float [ %1784, %1789 ], [ %2565, %2528 ]
  %2570 = phi float [ %1785, %1789 ], [ %2566, %2528 ]
  %2571 = phi float [ %1786, %1789 ], [ %2567, %2528 ]
  %2572 = phi float [ %1790, %1789 ], [ %1787, %2528 ]
  %2573 = fcmp fast ogt float %2569, 0x3FA4B5DCC0000000
  %2574 = fcmp fast ogt float %2570, 0x3FA4B5DCC0000000
  %2575 = fcmp fast ogt float %2571, 0x3FA4B5DCC0000000
  %2576 = select i1 %2573, float 0.000000e+00, float 1.000000e+00
  %2577 = select i1 %2574, float 0.000000e+00, float 1.000000e+00
  %2578 = select i1 %2575, float 0.000000e+00, float 1.000000e+00
  %2579 = fmul fast float %2569, 0x3FB3D07220000000
  %2580 = fmul fast float %2570, 0x3FB3D07220000000
  %2581 = fmul fast float %2571, 0x3FB3D07220000000
  %2582 = fadd fast float %2569, 0x3FAC28F5C0000000
  %2583 = fadd fast float %2570, 0x3FAC28F5C0000000
  %2584 = fadd fast float %2571, 0x3FAC28F5C0000000
  %2585 = fmul fast float %2582, 0x3FEE54EDE0000000
  %2586 = fmul fast float %2583, 0x3FEE54EDE0000000
  %2587 = fmul fast float %2584, 0x3FEE54EDE0000000
  %2588 = call float @dx.op.unary.f32(i32 23, float %2585)  ; Log(value)
  %2589 = call float @dx.op.unary.f32(i32 23, float %2586)  ; Log(value)
  %2590 = call float @dx.op.unary.f32(i32 23, float %2587)  ; Log(value)
  %2591 = fmul fast float %2588, 0x4003333340000000
  %2592 = fmul fast float %2589, 0x4003333340000000
  %2593 = fmul fast float %2590, 0x4003333340000000
  %2594 = call float @dx.op.unary.f32(i32 21, float %2591)  ; Exp(value)
  %2595 = call float @dx.op.unary.f32(i32 21, float %2592)  ; Exp(value)
  %2596 = call float @dx.op.unary.f32(i32 21, float %2593)  ; Exp(value)
  %2597 = fsub fast float %2579, %2594
  %2598 = fsub fast float %2580, %2595
  %2599 = fsub fast float %2581, %2596
  %2600 = fmul fast float %2597, %2576
  %2601 = fmul fast float %2598, %2577
  %2602 = fmul fast float %2599, %2578
  %2603 = fadd fast float %2600, %2594
  %2604 = fadd fast float %2601, %2595
  %2605 = fadd fast float %2602, %2596
  %2606 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %38, i32 %41, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2607 = extractvalue %dx.types.ResRet.f32 %2606, 0
  %2608 = extractvalue %dx.types.ResRet.f32 %2606, 1
  %2609 = extractvalue %dx.types.ResRet.f32 %2606, 2
  %2610 = extractvalue %dx.types.ResRet.f32 %2606, 3
  %2611 = fcmp fast olt float %2610, 0.000000e+00
  br i1 %2611, label %2612, label %2614

; <label>:2612                                    ; preds = %2568
  %2613 = fsub fast float -1.000000e+00, %2610
  br label %3391

; <label>:2614                                    ; preds = %2568
  %2615 = fadd fast float %5, 1.000000e+00
  %2616 = fadd fast float %6, 1.000000e+00
  %2617 = fsub fast float 1.000000e+00, %5
  %2618 = fmul fast float %9, %2615
  %2619 = fmul fast float %9, %2616
  %2620 = fmul fast float %9, %2617
  %2621 = fmul fast float %2618, %2607
  %2622 = fmul fast float %2619, %2608
  %2623 = fmul fast float %2620, %2609
  %2624 = fcmp fast ult float %10, 5.000000e-01
  br i1 %2624, label %2650, label %2625

; <label>:2625                                    ; preds = %2614
  %2626 = fmul fast float %2621, 0x4004147AE0000000
  %2627 = fmul fast float %2622, 0x4004147AE0000000
  %2628 = fmul fast float %2623, 0x4004147AE0000000
  %2629 = fadd fast float %2626, 0x3F9EB851E0000000
  %2630 = fadd fast float %2627, 0x3F9EB851E0000000
  %2631 = fadd fast float %2628, 0x3F9EB851E0000000
  %2632 = fmul fast float %2629, %2621
  %2633 = fmul fast float %2630, %2622
  %2634 = fmul fast float %2631, %2623
  %2635 = fmul fast float %2621, 0x400370A3E0000000
  %2636 = fmul fast float %2622, 0x400370A3E0000000
  %2637 = fmul fast float %2623, 0x400370A3E0000000
  %2638 = fadd fast float %2635, 0x3FE2E147A0000000
  %2639 = fadd fast float %2636, 0x3FE2E147A0000000
  %2640 = fadd fast float %2637, 0x3FE2E147A0000000
  %2641 = fmul fast float %2638, %2621
  %2642 = fmul fast float %2639, %2622
  %2643 = fmul fast float %2640, %2623
  %2644 = fadd fast float %2641, 0x3FC1EB8520000000
  %2645 = fadd fast float %2642, 0x3FC1EB8520000000
  %2646 = fadd fast float %2643, 0x3FC1EB8520000000
  %2647 = fdiv fast float %2632, %2644
  %2648 = fdiv fast float %2633, %2645
  %2649 = fdiv fast float %2634, %2646
  br label %2650

; <label>:2650                                    ; preds = %2625, %2614
  %2651 = phi float [ %2647, %2625 ], [ %2621, %2614 ]
  %2652 = phi float [ %2648, %2625 ], [ %2622, %2614 ]
  %2653 = phi float [ %2649, %2625 ], [ %2623, %2614 ]
  %2654 = call float @dx.op.unary.f32(i32 7, float %2651)  ; Saturate(value)
  %2655 = call float @dx.op.unary.f32(i32 7, float %2652)  ; Saturate(value)
  %2656 = call float @dx.op.unary.f32(i32 7, float %2653)  ; Saturate(value)
  %2657 = call float @dx.op.dot3.f32(i32 55, float %2654, float %2655, float %2656, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2658 = fsub fast float %2654, %2657
  %2659 = fsub fast float %2655, %2657
  %2660 = fsub fast float %2656, %2657
  %2661 = fmul fast float %2658, %8
  %2662 = fmul fast float %2659, %8
  %2663 = fmul fast float %2660, %8
  %2664 = fadd fast float %2661, %2657
  %2665 = fadd fast float %2662, %2657
  %2666 = fadd fast float %2663, %2657
  %2667 = call float @dx.op.unary.f32(i32 7, float %2664)  ; Saturate(value)
  %2668 = call float @dx.op.unary.f32(i32 7, float %2665)  ; Saturate(value)
  %2669 = call float @dx.op.unary.f32(i32 7, float %2666)  ; Saturate(value)
  %2670 = fadd fast float %2667, 0xBFC70A3D80000000
  %2671 = fadd fast float %2668, 0xBFC70A3D80000000
  %2672 = fadd fast float %2669, 0xBFC70A3D80000000
  %2673 = fmul fast float %2670, %7
  %2674 = fmul fast float %2671, %7
  %2675 = fmul fast float %2672, %7
  %2676 = fadd fast float %2673, 0x3FC70A3D80000000
  %2677 = fadd fast float %2674, 0x3FC70A3D80000000
  %2678 = fadd fast float %2675, 0x3FC70A3D80000000
  %2679 = call float @dx.op.unary.f32(i32 7, float %2676)  ; Saturate(value)
  %2680 = call float @dx.op.unary.f32(i32 7, float %2677)  ; Saturate(value)
  %2681 = call float @dx.op.unary.f32(i32 7, float %2678)  ; Saturate(value)
  %2682 = add i32 %41, -1
  %2683 = call i32 @dx.op.binary.i32(i32 37, i32 %38, i32 0)  ; IMax(a,b)
  %2684 = call i32 @dx.op.binary.i32(i32 37, i32 %2682, i32 0)  ; IMax(a,b)
  %2685 = call i32 @dx.op.binary.i32(i32 38, i32 %2683, i32 %30)  ; IMin(a,b)
  %2686 = call i32 @dx.op.binary.i32(i32 38, i32 %2684, i32 %31)  ; IMin(a,b)
  %2687 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2685, i32 %2686, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2688 = extractvalue %dx.types.ResRet.f32 %2687, 0
  %2689 = fsub fast float 1.000000e+00, %59
  %2690 = fmul fast float %2689, 0x3FA99999A0000000
  %2691 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %2690)  ; FMax(a,b)
  %2692 = fsub fast float %2688, %59
  %2693 = call float @dx.op.unary.f32(i32 6, float %2692)  ; FAbs(value)
  %2694 = fdiv fast float %2693, %2691
  %2695 = fsub fast float 1.000000e+00, %2694
  %2696 = call float @dx.op.unary.f32(i32 7, float %2695)  ; Saturate(value)
  %2697 = fcmp fast ugt float %2696, 0.000000e+00
  br i1 %2697, label %2698, label %2824

; <label>:2698                                    ; preds = %2650
  %2699 = call i32 @dx.op.binary.i32(i32 37, i32 %2685, i32 0)  ; IMax(a,b)
  %2700 = call i32 @dx.op.binary.i32(i32 37, i32 %2686, i32 0)  ; IMax(a,b)
  %2701 = call i32 @dx.op.binary.i32(i32 38, i32 %2699, i32 %30)  ; IMin(a,b)
  %2702 = call i32 @dx.op.binary.i32(i32 38, i32 %2700, i32 %31)  ; IMin(a,b)
  %2703 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2701, i32 %2702, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2704 = extractvalue %dx.types.ResRet.f32 %2703, 0
  %2705 = extractvalue %dx.types.ResRet.f32 %2703, 1
  %2706 = extractvalue %dx.types.ResRet.f32 %2703, 2
  %2707 = extractvalue %dx.types.ResRet.f32 %2703, 3
  %2708 = fcmp fast olt float %2707, 0.000000e+00
  br i1 %2708, label %2709, label %2743

; <label>:2709                                    ; preds = %2698
  %2710 = fcmp fast ogt float %2704, 0x3FA4B5DCC0000000
  %2711 = fcmp fast ogt float %2705, 0x3FA4B5DCC0000000
  %2712 = fcmp fast ogt float %2706, 0x3FA4B5DCC0000000
  %2713 = select i1 %2710, float 0.000000e+00, float 1.000000e+00
  %2714 = select i1 %2711, float 0.000000e+00, float 1.000000e+00
  %2715 = select i1 %2712, float 0.000000e+00, float 1.000000e+00
  %2716 = fmul fast float %2704, 0x3FB3D07220000000
  %2717 = fmul fast float %2705, 0x3FB3D07220000000
  %2718 = fmul fast float %2706, 0x3FB3D07220000000
  %2719 = fadd fast float %2704, 0x3FAC28F5C0000000
  %2720 = fadd fast float %2705, 0x3FAC28F5C0000000
  %2721 = fadd fast float %2706, 0x3FAC28F5C0000000
  %2722 = fmul fast float %2719, 0x3FEE54EDE0000000
  %2723 = fmul fast float %2720, 0x3FEE54EDE0000000
  %2724 = fmul fast float %2721, 0x3FEE54EDE0000000
  %2725 = call float @dx.op.unary.f32(i32 23, float %2722)  ; Log(value)
  %2726 = call float @dx.op.unary.f32(i32 23, float %2723)  ; Log(value)
  %2727 = call float @dx.op.unary.f32(i32 23, float %2724)  ; Log(value)
  %2728 = fmul fast float %2725, 0x4003333340000000
  %2729 = fmul fast float %2726, 0x4003333340000000
  %2730 = fmul fast float %2727, 0x4003333340000000
  %2731 = call float @dx.op.unary.f32(i32 21, float %2728)  ; Exp(value)
  %2732 = call float @dx.op.unary.f32(i32 21, float %2729)  ; Exp(value)
  %2733 = call float @dx.op.unary.f32(i32 21, float %2730)  ; Exp(value)
  %2734 = fsub fast float %2716, %2731
  %2735 = fsub fast float %2717, %2732
  %2736 = fsub fast float %2718, %2733
  %2737 = fmul fast float %2734, %2713
  %2738 = fmul fast float %2735, %2714
  %2739 = fmul fast float %2736, %2715
  %2740 = fadd fast float %2737, %2731
  %2741 = fadd fast float %2738, %2732
  %2742 = fadd fast float %2739, %2733
  br label %2811

; <label>:2743                                    ; preds = %2698
  %2744 = fadd fast float %5, 1.000000e+00
  %2745 = fadd fast float %6, 1.000000e+00
  %2746 = fsub fast float 1.000000e+00, %5
  %2747 = fmul fast float %9, %2744
  %2748 = fmul fast float %9, %2745
  %2749 = fmul fast float %9, %2746
  %2750 = fmul fast float %2747, %2704
  %2751 = fmul fast float %2748, %2705
  %2752 = fmul fast float %2749, %2706
  %2753 = fcmp fast ult float %10, 5.000000e-01
  br i1 %2753, label %2779, label %2754

; <label>:2754                                    ; preds = %2743
  %2755 = fmul fast float %2750, 0x4004147AE0000000
  %2756 = fmul fast float %2751, 0x4004147AE0000000
  %2757 = fmul fast float %2752, 0x4004147AE0000000
  %2758 = fadd fast float %2755, 0x3F9EB851E0000000
  %2759 = fadd fast float %2756, 0x3F9EB851E0000000
  %2760 = fadd fast float %2757, 0x3F9EB851E0000000
  %2761 = fmul fast float %2758, %2750
  %2762 = fmul fast float %2759, %2751
  %2763 = fmul fast float %2760, %2752
  %2764 = fmul fast float %2750, 0x400370A3E0000000
  %2765 = fmul fast float %2751, 0x400370A3E0000000
  %2766 = fmul fast float %2752, 0x400370A3E0000000
  %2767 = fadd fast float %2764, 0x3FE2E147A0000000
  %2768 = fadd fast float %2765, 0x3FE2E147A0000000
  %2769 = fadd fast float %2766, 0x3FE2E147A0000000
  %2770 = fmul fast float %2767, %2750
  %2771 = fmul fast float %2768, %2751
  %2772 = fmul fast float %2769, %2752
  %2773 = fadd fast float %2770, 0x3FC1EB8520000000
  %2774 = fadd fast float %2771, 0x3FC1EB8520000000
  %2775 = fadd fast float %2772, 0x3FC1EB8520000000
  %2776 = fdiv fast float %2761, %2773
  %2777 = fdiv fast float %2762, %2774
  %2778 = fdiv fast float %2763, %2775
  br label %2779

; <label>:2779                                    ; preds = %2754, %2743
  %2780 = phi float [ %2776, %2754 ], [ %2750, %2743 ]
  %2781 = phi float [ %2777, %2754 ], [ %2751, %2743 ]
  %2782 = phi float [ %2778, %2754 ], [ %2752, %2743 ]
  %2783 = call float @dx.op.unary.f32(i32 7, float %2780)  ; Saturate(value)
  %2784 = call float @dx.op.unary.f32(i32 7, float %2781)  ; Saturate(value)
  %2785 = call float @dx.op.unary.f32(i32 7, float %2782)  ; Saturate(value)
  %2786 = call float @dx.op.dot3.f32(i32 55, float %2783, float %2784, float %2785, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2787 = fsub fast float %2783, %2786
  %2788 = fsub fast float %2784, %2786
  %2789 = fsub fast float %2785, %2786
  %2790 = fmul fast float %2787, %8
  %2791 = fmul fast float %2788, %8
  %2792 = fmul fast float %2789, %8
  %2793 = fadd fast float %2790, %2786
  %2794 = fadd fast float %2791, %2786
  %2795 = fadd fast float %2792, %2786
  %2796 = call float @dx.op.unary.f32(i32 7, float %2793)  ; Saturate(value)
  %2797 = call float @dx.op.unary.f32(i32 7, float %2794)  ; Saturate(value)
  %2798 = call float @dx.op.unary.f32(i32 7, float %2795)  ; Saturate(value)
  %2799 = fadd fast float %2796, 0xBFC70A3D80000000
  %2800 = fadd fast float %2797, 0xBFC70A3D80000000
  %2801 = fadd fast float %2798, 0xBFC70A3D80000000
  %2802 = fmul fast float %2799, %7
  %2803 = fmul fast float %2800, %7
  %2804 = fmul fast float %2801, %7
  %2805 = fadd fast float %2802, 0x3FC70A3D80000000
  %2806 = fadd fast float %2803, 0x3FC70A3D80000000
  %2807 = fadd fast float %2804, 0x3FC70A3D80000000
  %2808 = call float @dx.op.unary.f32(i32 7, float %2805)  ; Saturate(value)
  %2809 = call float @dx.op.unary.f32(i32 7, float %2806)  ; Saturate(value)
  %2810 = call float @dx.op.unary.f32(i32 7, float %2807)  ; Saturate(value)
  br label %2811

; <label>:2811                                    ; preds = %2779, %2709
  %2812 = phi float [ %2740, %2709 ], [ %2808, %2779 ]
  %2813 = phi float [ %2741, %2709 ], [ %2809, %2779 ]
  %2814 = phi float [ %2742, %2709 ], [ %2810, %2779 ]
  %2815 = fsub fast float %2812, %2679
  %2816 = fsub fast float %2813, %2680
  %2817 = fsub fast float %2814, %2681
  %2818 = fmul fast float %2815, %2696
  %2819 = fmul fast float %2816, %2696
  %2820 = fmul fast float %2817, %2696
  %2821 = fadd fast float %2818, %2679
  %2822 = fadd fast float %2819, %2680
  %2823 = fadd fast float %2820, %2681
  br label %2824

; <label>:2824                                    ; preds = %2811, %2650
  %2825 = phi float [ %2821, %2811 ], [ %2679, %2650 ]
  %2826 = phi float [ %2822, %2811 ], [ %2680, %2650 ]
  %2827 = phi float [ %2823, %2811 ], [ %2681, %2650 ]
  %2828 = add i32 %41, 1
  %2829 = call i32 @dx.op.binary.i32(i32 37, i32 %2828, i32 0)  ; IMax(a,b)
  %2830 = call i32 @dx.op.binary.i32(i32 38, i32 %2829, i32 %31)  ; IMin(a,b)
  %2831 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2685, i32 %2830, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2832 = extractvalue %dx.types.ResRet.f32 %2831, 0
  %2833 = fsub fast float %2832, %59
  %2834 = call float @dx.op.unary.f32(i32 6, float %2833)  ; FAbs(value)
  %2835 = fdiv fast float %2834, %2691
  %2836 = fsub fast float 1.000000e+00, %2835
  %2837 = call float @dx.op.unary.f32(i32 7, float %2836)  ; Saturate(value)
  %2838 = fcmp fast ugt float %2837, 0.000000e+00
  br i1 %2838, label %2839, label %2965

; <label>:2839                                    ; preds = %2824
  %2840 = call i32 @dx.op.binary.i32(i32 37, i32 %2685, i32 0)  ; IMax(a,b)
  %2841 = call i32 @dx.op.binary.i32(i32 37, i32 %2830, i32 0)  ; IMax(a,b)
  %2842 = call i32 @dx.op.binary.i32(i32 38, i32 %2840, i32 %30)  ; IMin(a,b)
  %2843 = call i32 @dx.op.binary.i32(i32 38, i32 %2841, i32 %31)  ; IMin(a,b)
  %2844 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2842, i32 %2843, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2845 = extractvalue %dx.types.ResRet.f32 %2844, 0
  %2846 = extractvalue %dx.types.ResRet.f32 %2844, 1
  %2847 = extractvalue %dx.types.ResRet.f32 %2844, 2
  %2848 = extractvalue %dx.types.ResRet.f32 %2844, 3
  %2849 = fcmp fast olt float %2848, 0.000000e+00
  br i1 %2849, label %2850, label %2884

; <label>:2850                                    ; preds = %2839
  %2851 = fcmp fast ogt float %2845, 0x3FA4B5DCC0000000
  %2852 = fcmp fast ogt float %2846, 0x3FA4B5DCC0000000
  %2853 = fcmp fast ogt float %2847, 0x3FA4B5DCC0000000
  %2854 = select i1 %2851, float 0.000000e+00, float 1.000000e+00
  %2855 = select i1 %2852, float 0.000000e+00, float 1.000000e+00
  %2856 = select i1 %2853, float 0.000000e+00, float 1.000000e+00
  %2857 = fmul fast float %2845, 0x3FB3D07220000000
  %2858 = fmul fast float %2846, 0x3FB3D07220000000
  %2859 = fmul fast float %2847, 0x3FB3D07220000000
  %2860 = fadd fast float %2845, 0x3FAC28F5C0000000
  %2861 = fadd fast float %2846, 0x3FAC28F5C0000000
  %2862 = fadd fast float %2847, 0x3FAC28F5C0000000
  %2863 = fmul fast float %2860, 0x3FEE54EDE0000000
  %2864 = fmul fast float %2861, 0x3FEE54EDE0000000
  %2865 = fmul fast float %2862, 0x3FEE54EDE0000000
  %2866 = call float @dx.op.unary.f32(i32 23, float %2863)  ; Log(value)
  %2867 = call float @dx.op.unary.f32(i32 23, float %2864)  ; Log(value)
  %2868 = call float @dx.op.unary.f32(i32 23, float %2865)  ; Log(value)
  %2869 = fmul fast float %2866, 0x4003333340000000
  %2870 = fmul fast float %2867, 0x4003333340000000
  %2871 = fmul fast float %2868, 0x4003333340000000
  %2872 = call float @dx.op.unary.f32(i32 21, float %2869)  ; Exp(value)
  %2873 = call float @dx.op.unary.f32(i32 21, float %2870)  ; Exp(value)
  %2874 = call float @dx.op.unary.f32(i32 21, float %2871)  ; Exp(value)
  %2875 = fsub fast float %2857, %2872
  %2876 = fsub fast float %2858, %2873
  %2877 = fsub fast float %2859, %2874
  %2878 = fmul fast float %2875, %2854
  %2879 = fmul fast float %2876, %2855
  %2880 = fmul fast float %2877, %2856
  %2881 = fadd fast float %2878, %2872
  %2882 = fadd fast float %2879, %2873
  %2883 = fadd fast float %2880, %2874
  br label %2952

; <label>:2884                                    ; preds = %2839
  %2885 = fadd fast float %5, 1.000000e+00
  %2886 = fadd fast float %6, 1.000000e+00
  %2887 = fsub fast float 1.000000e+00, %5
  %2888 = fmul fast float %9, %2885
  %2889 = fmul fast float %9, %2886
  %2890 = fmul fast float %9, %2887
  %2891 = fmul fast float %2888, %2845
  %2892 = fmul fast float %2889, %2846
  %2893 = fmul fast float %2890, %2847
  %2894 = fcmp fast ult float %10, 5.000000e-01
  br i1 %2894, label %2920, label %2895

; <label>:2895                                    ; preds = %2884
  %2896 = fmul fast float %2891, 0x4004147AE0000000
  %2897 = fmul fast float %2892, 0x4004147AE0000000
  %2898 = fmul fast float %2893, 0x4004147AE0000000
  %2899 = fadd fast float %2896, 0x3F9EB851E0000000
  %2900 = fadd fast float %2897, 0x3F9EB851E0000000
  %2901 = fadd fast float %2898, 0x3F9EB851E0000000
  %2902 = fmul fast float %2899, %2891
  %2903 = fmul fast float %2900, %2892
  %2904 = fmul fast float %2901, %2893
  %2905 = fmul fast float %2891, 0x400370A3E0000000
  %2906 = fmul fast float %2892, 0x400370A3E0000000
  %2907 = fmul fast float %2893, 0x400370A3E0000000
  %2908 = fadd fast float %2905, 0x3FE2E147A0000000
  %2909 = fadd fast float %2906, 0x3FE2E147A0000000
  %2910 = fadd fast float %2907, 0x3FE2E147A0000000
  %2911 = fmul fast float %2908, %2891
  %2912 = fmul fast float %2909, %2892
  %2913 = fmul fast float %2910, %2893
  %2914 = fadd fast float %2911, 0x3FC1EB8520000000
  %2915 = fadd fast float %2912, 0x3FC1EB8520000000
  %2916 = fadd fast float %2913, 0x3FC1EB8520000000
  %2917 = fdiv fast float %2902, %2914
  %2918 = fdiv fast float %2903, %2915
  %2919 = fdiv fast float %2904, %2916
  br label %2920

; <label>:2920                                    ; preds = %2895, %2884
  %2921 = phi float [ %2917, %2895 ], [ %2891, %2884 ]
  %2922 = phi float [ %2918, %2895 ], [ %2892, %2884 ]
  %2923 = phi float [ %2919, %2895 ], [ %2893, %2884 ]
  %2924 = call float @dx.op.unary.f32(i32 7, float %2921)  ; Saturate(value)
  %2925 = call float @dx.op.unary.f32(i32 7, float %2922)  ; Saturate(value)
  %2926 = call float @dx.op.unary.f32(i32 7, float %2923)  ; Saturate(value)
  %2927 = call float @dx.op.dot3.f32(i32 55, float %2924, float %2925, float %2926, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2928 = fsub fast float %2924, %2927
  %2929 = fsub fast float %2925, %2927
  %2930 = fsub fast float %2926, %2927
  %2931 = fmul fast float %2928, %8
  %2932 = fmul fast float %2929, %8
  %2933 = fmul fast float %2930, %8
  %2934 = fadd fast float %2931, %2927
  %2935 = fadd fast float %2932, %2927
  %2936 = fadd fast float %2933, %2927
  %2937 = call float @dx.op.unary.f32(i32 7, float %2934)  ; Saturate(value)
  %2938 = call float @dx.op.unary.f32(i32 7, float %2935)  ; Saturate(value)
  %2939 = call float @dx.op.unary.f32(i32 7, float %2936)  ; Saturate(value)
  %2940 = fadd fast float %2937, 0xBFC70A3D80000000
  %2941 = fadd fast float %2938, 0xBFC70A3D80000000
  %2942 = fadd fast float %2939, 0xBFC70A3D80000000
  %2943 = fmul fast float %2940, %7
  %2944 = fmul fast float %2941, %7
  %2945 = fmul fast float %2942, %7
  %2946 = fadd fast float %2943, 0x3FC70A3D80000000
  %2947 = fadd fast float %2944, 0x3FC70A3D80000000
  %2948 = fadd fast float %2945, 0x3FC70A3D80000000
  %2949 = call float @dx.op.unary.f32(i32 7, float %2946)  ; Saturate(value)
  %2950 = call float @dx.op.unary.f32(i32 7, float %2947)  ; Saturate(value)
  %2951 = call float @dx.op.unary.f32(i32 7, float %2948)  ; Saturate(value)
  br label %2952

; <label>:2952                                    ; preds = %2920, %2850
  %2953 = phi float [ %2881, %2850 ], [ %2949, %2920 ]
  %2954 = phi float [ %2882, %2850 ], [ %2950, %2920 ]
  %2955 = phi float [ %2883, %2850 ], [ %2951, %2920 ]
  %2956 = fsub fast float %2953, %2679
  %2957 = fsub fast float %2954, %2680
  %2958 = fsub fast float %2955, %2681
  %2959 = fmul fast float %2956, %2837
  %2960 = fmul fast float %2957, %2837
  %2961 = fmul fast float %2958, %2837
  %2962 = fadd fast float %2959, %2679
  %2963 = fadd fast float %2960, %2680
  %2964 = fadd fast float %2961, %2681
  br label %2965

; <label>:2965                                    ; preds = %2952, %2824
  %2966 = phi float [ %2962, %2952 ], [ %2679, %2824 ]
  %2967 = phi float [ %2963, %2952 ], [ %2680, %2824 ]
  %2968 = phi float [ %2964, %2952 ], [ %2681, %2824 ]
  %2969 = add i32 %38, -1
  %2970 = call i32 @dx.op.binary.i32(i32 37, i32 %2969, i32 0)  ; IMax(a,b)
  %2971 = call i32 @dx.op.binary.i32(i32 37, i32 %41, i32 0)  ; IMax(a,b)
  %2972 = call i32 @dx.op.binary.i32(i32 38, i32 %2970, i32 %30)  ; IMin(a,b)
  %2973 = call i32 @dx.op.binary.i32(i32 38, i32 %2971, i32 %31)  ; IMin(a,b)
  %2974 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2972, i32 %2973, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2975 = extractvalue %dx.types.ResRet.f32 %2974, 0
  %2976 = fsub fast float %2975, %59
  %2977 = call float @dx.op.unary.f32(i32 6, float %2976)  ; FAbs(value)
  %2978 = fdiv fast float %2977, %2691
  %2979 = fsub fast float 1.000000e+00, %2978
  %2980 = call float @dx.op.unary.f32(i32 7, float %2979)  ; Saturate(value)
  %2981 = fcmp fast ugt float %2980, 0.000000e+00
  br i1 %2981, label %2982, label %3108

; <label>:2982                                    ; preds = %2965
  %2983 = call i32 @dx.op.binary.i32(i32 37, i32 %2972, i32 0)  ; IMax(a,b)
  %2984 = call i32 @dx.op.binary.i32(i32 37, i32 %2973, i32 0)  ; IMax(a,b)
  %2985 = call i32 @dx.op.binary.i32(i32 38, i32 %2983, i32 %30)  ; IMin(a,b)
  %2986 = call i32 @dx.op.binary.i32(i32 38, i32 %2984, i32 %31)  ; IMin(a,b)
  %2987 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2985, i32 %2986, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2988 = extractvalue %dx.types.ResRet.f32 %2987, 0
  %2989 = extractvalue %dx.types.ResRet.f32 %2987, 1
  %2990 = extractvalue %dx.types.ResRet.f32 %2987, 2
  %2991 = extractvalue %dx.types.ResRet.f32 %2987, 3
  %2992 = fcmp fast olt float %2991, 0.000000e+00
  br i1 %2992, label %2993, label %3027

; <label>:2993                                    ; preds = %2982
  %2994 = fcmp fast ogt float %2988, 0x3FA4B5DCC0000000
  %2995 = fcmp fast ogt float %2989, 0x3FA4B5DCC0000000
  %2996 = fcmp fast ogt float %2990, 0x3FA4B5DCC0000000
  %2997 = select i1 %2994, float 0.000000e+00, float 1.000000e+00
  %2998 = select i1 %2995, float 0.000000e+00, float 1.000000e+00
  %2999 = select i1 %2996, float 0.000000e+00, float 1.000000e+00
  %3000 = fmul fast float %2988, 0x3FB3D07220000000
  %3001 = fmul fast float %2989, 0x3FB3D07220000000
  %3002 = fmul fast float %2990, 0x3FB3D07220000000
  %3003 = fadd fast float %2988, 0x3FAC28F5C0000000
  %3004 = fadd fast float %2989, 0x3FAC28F5C0000000
  %3005 = fadd fast float %2990, 0x3FAC28F5C0000000
  %3006 = fmul fast float %3003, 0x3FEE54EDE0000000
  %3007 = fmul fast float %3004, 0x3FEE54EDE0000000
  %3008 = fmul fast float %3005, 0x3FEE54EDE0000000
  %3009 = call float @dx.op.unary.f32(i32 23, float %3006)  ; Log(value)
  %3010 = call float @dx.op.unary.f32(i32 23, float %3007)  ; Log(value)
  %3011 = call float @dx.op.unary.f32(i32 23, float %3008)  ; Log(value)
  %3012 = fmul fast float %3009, 0x4003333340000000
  %3013 = fmul fast float %3010, 0x4003333340000000
  %3014 = fmul fast float %3011, 0x4003333340000000
  %3015 = call float @dx.op.unary.f32(i32 21, float %3012)  ; Exp(value)
  %3016 = call float @dx.op.unary.f32(i32 21, float %3013)  ; Exp(value)
  %3017 = call float @dx.op.unary.f32(i32 21, float %3014)  ; Exp(value)
  %3018 = fsub fast float %3000, %3015
  %3019 = fsub fast float %3001, %3016
  %3020 = fsub fast float %3002, %3017
  %3021 = fmul fast float %3018, %2997
  %3022 = fmul fast float %3019, %2998
  %3023 = fmul fast float %3020, %2999
  %3024 = fadd fast float %3021, %3015
  %3025 = fadd fast float %3022, %3016
  %3026 = fadd fast float %3023, %3017
  br label %3095

; <label>:3027                                    ; preds = %2982
  %3028 = fadd fast float %5, 1.000000e+00
  %3029 = fadd fast float %6, 1.000000e+00
  %3030 = fsub fast float 1.000000e+00, %5
  %3031 = fmul fast float %9, %3028
  %3032 = fmul fast float %9, %3029
  %3033 = fmul fast float %9, %3030
  %3034 = fmul fast float %3031, %2988
  %3035 = fmul fast float %3032, %2989
  %3036 = fmul fast float %3033, %2990
  %3037 = fcmp fast ult float %10, 5.000000e-01
  br i1 %3037, label %3063, label %3038

; <label>:3038                                    ; preds = %3027
  %3039 = fmul fast float %3034, 0x4004147AE0000000
  %3040 = fmul fast float %3035, 0x4004147AE0000000
  %3041 = fmul fast float %3036, 0x4004147AE0000000
  %3042 = fadd fast float %3039, 0x3F9EB851E0000000
  %3043 = fadd fast float %3040, 0x3F9EB851E0000000
  %3044 = fadd fast float %3041, 0x3F9EB851E0000000
  %3045 = fmul fast float %3042, %3034
  %3046 = fmul fast float %3043, %3035
  %3047 = fmul fast float %3044, %3036
  %3048 = fmul fast float %3034, 0x400370A3E0000000
  %3049 = fmul fast float %3035, 0x400370A3E0000000
  %3050 = fmul fast float %3036, 0x400370A3E0000000
  %3051 = fadd fast float %3048, 0x3FE2E147A0000000
  %3052 = fadd fast float %3049, 0x3FE2E147A0000000
  %3053 = fadd fast float %3050, 0x3FE2E147A0000000
  %3054 = fmul fast float %3051, %3034
  %3055 = fmul fast float %3052, %3035
  %3056 = fmul fast float %3053, %3036
  %3057 = fadd fast float %3054, 0x3FC1EB8520000000
  %3058 = fadd fast float %3055, 0x3FC1EB8520000000
  %3059 = fadd fast float %3056, 0x3FC1EB8520000000
  %3060 = fdiv fast float %3045, %3057
  %3061 = fdiv fast float %3046, %3058
  %3062 = fdiv fast float %3047, %3059
  br label %3063

; <label>:3063                                    ; preds = %3038, %3027
  %3064 = phi float [ %3060, %3038 ], [ %3034, %3027 ]
  %3065 = phi float [ %3061, %3038 ], [ %3035, %3027 ]
  %3066 = phi float [ %3062, %3038 ], [ %3036, %3027 ]
  %3067 = call float @dx.op.unary.f32(i32 7, float %3064)  ; Saturate(value)
  %3068 = call float @dx.op.unary.f32(i32 7, float %3065)  ; Saturate(value)
  %3069 = call float @dx.op.unary.f32(i32 7, float %3066)  ; Saturate(value)
  %3070 = call float @dx.op.dot3.f32(i32 55, float %3067, float %3068, float %3069, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3071 = fsub fast float %3067, %3070
  %3072 = fsub fast float %3068, %3070
  %3073 = fsub fast float %3069, %3070
  %3074 = fmul fast float %3071, %8
  %3075 = fmul fast float %3072, %8
  %3076 = fmul fast float %3073, %8
  %3077 = fadd fast float %3074, %3070
  %3078 = fadd fast float %3075, %3070
  %3079 = fadd fast float %3076, %3070
  %3080 = call float @dx.op.unary.f32(i32 7, float %3077)  ; Saturate(value)
  %3081 = call float @dx.op.unary.f32(i32 7, float %3078)  ; Saturate(value)
  %3082 = call float @dx.op.unary.f32(i32 7, float %3079)  ; Saturate(value)
  %3083 = fadd fast float %3080, 0xBFC70A3D80000000
  %3084 = fadd fast float %3081, 0xBFC70A3D80000000
  %3085 = fadd fast float %3082, 0xBFC70A3D80000000
  %3086 = fmul fast float %3083, %7
  %3087 = fmul fast float %3084, %7
  %3088 = fmul fast float %3085, %7
  %3089 = fadd fast float %3086, 0x3FC70A3D80000000
  %3090 = fadd fast float %3087, 0x3FC70A3D80000000
  %3091 = fadd fast float %3088, 0x3FC70A3D80000000
  %3092 = call float @dx.op.unary.f32(i32 7, float %3089)  ; Saturate(value)
  %3093 = call float @dx.op.unary.f32(i32 7, float %3090)  ; Saturate(value)
  %3094 = call float @dx.op.unary.f32(i32 7, float %3091)  ; Saturate(value)
  br label %3095

; <label>:3095                                    ; preds = %3063, %2993
  %3096 = phi float [ %3024, %2993 ], [ %3092, %3063 ]
  %3097 = phi float [ %3025, %2993 ], [ %3093, %3063 ]
  %3098 = phi float [ %3026, %2993 ], [ %3094, %3063 ]
  %3099 = fsub fast float %3096, %2679
  %3100 = fsub fast float %3097, %2680
  %3101 = fsub fast float %3098, %2681
  %3102 = fmul fast float %3099, %2980
  %3103 = fmul fast float %3100, %2980
  %3104 = fmul fast float %3101, %2980
  %3105 = fadd fast float %3102, %2679
  %3106 = fadd fast float %3103, %2680
  %3107 = fadd fast float %3104, %2681
  br label %3108

; <label>:3108                                    ; preds = %3095, %2965
  %3109 = phi float [ %3105, %3095 ], [ %2679, %2965 ]
  %3110 = phi float [ %3106, %3095 ], [ %2680, %2965 ]
  %3111 = phi float [ %3107, %3095 ], [ %2681, %2965 ]
  %3112 = add i32 %38, 1
  %3113 = call i32 @dx.op.binary.i32(i32 37, i32 %3112, i32 0)  ; IMax(a,b)
  %3114 = call i32 @dx.op.binary.i32(i32 38, i32 %3113, i32 %30)  ; IMin(a,b)
  %3115 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3114, i32 %2973, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3116 = extractvalue %dx.types.ResRet.f32 %3115, 0
  %3117 = fsub fast float %3116, %59
  %3118 = call float @dx.op.unary.f32(i32 6, float %3117)  ; FAbs(value)
  %3119 = fdiv fast float %3118, %2691
  %3120 = fsub fast float 1.000000e+00, %3119
  %3121 = call float @dx.op.unary.f32(i32 7, float %3120)  ; Saturate(value)
  %3122 = fcmp fast ugt float %3121, 0.000000e+00
  br i1 %3122, label %3123, label %3249

; <label>:3123                                    ; preds = %3108
  %3124 = call i32 @dx.op.binary.i32(i32 37, i32 %3114, i32 0)  ; IMax(a,b)
  %3125 = call i32 @dx.op.binary.i32(i32 37, i32 %2973, i32 0)  ; IMax(a,b)
  %3126 = call i32 @dx.op.binary.i32(i32 38, i32 %3124, i32 %30)  ; IMin(a,b)
  %3127 = call i32 @dx.op.binary.i32(i32 38, i32 %3125, i32 %31)  ; IMin(a,b)
  %3128 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3126, i32 %3127, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3129 = extractvalue %dx.types.ResRet.f32 %3128, 0
  %3130 = extractvalue %dx.types.ResRet.f32 %3128, 1
  %3131 = extractvalue %dx.types.ResRet.f32 %3128, 2
  %3132 = extractvalue %dx.types.ResRet.f32 %3128, 3
  %3133 = fcmp fast olt float %3132, 0.000000e+00
  br i1 %3133, label %3134, label %3168

; <label>:3134                                    ; preds = %3123
  %3135 = fcmp fast ogt float %3129, 0x3FA4B5DCC0000000
  %3136 = fcmp fast ogt float %3130, 0x3FA4B5DCC0000000
  %3137 = fcmp fast ogt float %3131, 0x3FA4B5DCC0000000
  %3138 = select i1 %3135, float 0.000000e+00, float 1.000000e+00
  %3139 = select i1 %3136, float 0.000000e+00, float 1.000000e+00
  %3140 = select i1 %3137, float 0.000000e+00, float 1.000000e+00
  %3141 = fmul fast float %3129, 0x3FB3D07220000000
  %3142 = fmul fast float %3130, 0x3FB3D07220000000
  %3143 = fmul fast float %3131, 0x3FB3D07220000000
  %3144 = fadd fast float %3129, 0x3FAC28F5C0000000
  %3145 = fadd fast float %3130, 0x3FAC28F5C0000000
  %3146 = fadd fast float %3131, 0x3FAC28F5C0000000
  %3147 = fmul fast float %3144, 0x3FEE54EDE0000000
  %3148 = fmul fast float %3145, 0x3FEE54EDE0000000
  %3149 = fmul fast float %3146, 0x3FEE54EDE0000000
  %3150 = call float @dx.op.unary.f32(i32 23, float %3147)  ; Log(value)
  %3151 = call float @dx.op.unary.f32(i32 23, float %3148)  ; Log(value)
  %3152 = call float @dx.op.unary.f32(i32 23, float %3149)  ; Log(value)
  %3153 = fmul fast float %3150, 0x4003333340000000
  %3154 = fmul fast float %3151, 0x4003333340000000
  %3155 = fmul fast float %3152, 0x4003333340000000
  %3156 = call float @dx.op.unary.f32(i32 21, float %3153)  ; Exp(value)
  %3157 = call float @dx.op.unary.f32(i32 21, float %3154)  ; Exp(value)
  %3158 = call float @dx.op.unary.f32(i32 21, float %3155)  ; Exp(value)
  %3159 = fsub fast float %3141, %3156
  %3160 = fsub fast float %3142, %3157
  %3161 = fsub fast float %3143, %3158
  %3162 = fmul fast float %3159, %3138
  %3163 = fmul fast float %3160, %3139
  %3164 = fmul fast float %3161, %3140
  %3165 = fadd fast float %3162, %3156
  %3166 = fadd fast float %3163, %3157
  %3167 = fadd fast float %3164, %3158
  br label %3236

; <label>:3168                                    ; preds = %3123
  %3169 = fadd fast float %5, 1.000000e+00
  %3170 = fadd fast float %6, 1.000000e+00
  %3171 = fsub fast float 1.000000e+00, %5
  %3172 = fmul fast float %9, %3169
  %3173 = fmul fast float %9, %3170
  %3174 = fmul fast float %9, %3171
  %3175 = fmul fast float %3172, %3129
  %3176 = fmul fast float %3173, %3130
  %3177 = fmul fast float %3174, %3131
  %3178 = fcmp fast ult float %10, 5.000000e-01
  br i1 %3178, label %3204, label %3179

; <label>:3179                                    ; preds = %3168
  %3180 = fmul fast float %3175, 0x4004147AE0000000
  %3181 = fmul fast float %3176, 0x4004147AE0000000
  %3182 = fmul fast float %3177, 0x4004147AE0000000
  %3183 = fadd fast float %3180, 0x3F9EB851E0000000
  %3184 = fadd fast float %3181, 0x3F9EB851E0000000
  %3185 = fadd fast float %3182, 0x3F9EB851E0000000
  %3186 = fmul fast float %3183, %3175
  %3187 = fmul fast float %3184, %3176
  %3188 = fmul fast float %3185, %3177
  %3189 = fmul fast float %3175, 0x400370A3E0000000
  %3190 = fmul fast float %3176, 0x400370A3E0000000
  %3191 = fmul fast float %3177, 0x400370A3E0000000
  %3192 = fadd fast float %3189, 0x3FE2E147A0000000
  %3193 = fadd fast float %3190, 0x3FE2E147A0000000
  %3194 = fadd fast float %3191, 0x3FE2E147A0000000
  %3195 = fmul fast float %3192, %3175
  %3196 = fmul fast float %3193, %3176
  %3197 = fmul fast float %3194, %3177
  %3198 = fadd fast float %3195, 0x3FC1EB8520000000
  %3199 = fadd fast float %3196, 0x3FC1EB8520000000
  %3200 = fadd fast float %3197, 0x3FC1EB8520000000
  %3201 = fdiv fast float %3186, %3198
  %3202 = fdiv fast float %3187, %3199
  %3203 = fdiv fast float %3188, %3200
  br label %3204

; <label>:3204                                    ; preds = %3179, %3168
  %3205 = phi float [ %3201, %3179 ], [ %3175, %3168 ]
  %3206 = phi float [ %3202, %3179 ], [ %3176, %3168 ]
  %3207 = phi float [ %3203, %3179 ], [ %3177, %3168 ]
  %3208 = call float @dx.op.unary.f32(i32 7, float %3205)  ; Saturate(value)
  %3209 = call float @dx.op.unary.f32(i32 7, float %3206)  ; Saturate(value)
  %3210 = call float @dx.op.unary.f32(i32 7, float %3207)  ; Saturate(value)
  %3211 = call float @dx.op.dot3.f32(i32 55, float %3208, float %3209, float %3210, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3212 = fsub fast float %3208, %3211
  %3213 = fsub fast float %3209, %3211
  %3214 = fsub fast float %3210, %3211
  %3215 = fmul fast float %3212, %8
  %3216 = fmul fast float %3213, %8
  %3217 = fmul fast float %3214, %8
  %3218 = fadd fast float %3215, %3211
  %3219 = fadd fast float %3216, %3211
  %3220 = fadd fast float %3217, %3211
  %3221 = call float @dx.op.unary.f32(i32 7, float %3218)  ; Saturate(value)
  %3222 = call float @dx.op.unary.f32(i32 7, float %3219)  ; Saturate(value)
  %3223 = call float @dx.op.unary.f32(i32 7, float %3220)  ; Saturate(value)
  %3224 = fadd fast float %3221, 0xBFC70A3D80000000
  %3225 = fadd fast float %3222, 0xBFC70A3D80000000
  %3226 = fadd fast float %3223, 0xBFC70A3D80000000
  %3227 = fmul fast float %3224, %7
  %3228 = fmul fast float %3225, %7
  %3229 = fmul fast float %3226, %7
  %3230 = fadd fast float %3227, 0x3FC70A3D80000000
  %3231 = fadd fast float %3228, 0x3FC70A3D80000000
  %3232 = fadd fast float %3229, 0x3FC70A3D80000000
  %3233 = call float @dx.op.unary.f32(i32 7, float %3230)  ; Saturate(value)
  %3234 = call float @dx.op.unary.f32(i32 7, float %3231)  ; Saturate(value)
  %3235 = call float @dx.op.unary.f32(i32 7, float %3232)  ; Saturate(value)
  br label %3236

; <label>:3236                                    ; preds = %3204, %3134
  %3237 = phi float [ %3165, %3134 ], [ %3233, %3204 ]
  %3238 = phi float [ %3166, %3134 ], [ %3234, %3204 ]
  %3239 = phi float [ %3167, %3134 ], [ %3235, %3204 ]
  %3240 = fsub fast float %3237, %2679
  %3241 = fsub fast float %3238, %2680
  %3242 = fsub fast float %3239, %2681
  %3243 = fmul fast float %3240, %3121
  %3244 = fmul fast float %3241, %3121
  %3245 = fmul fast float %3242, %3121
  %3246 = fadd fast float %3243, %2679
  %3247 = fadd fast float %3244, %2680
  %3248 = fadd fast float %3245, %2681
  br label %3249

; <label>:3249                                    ; preds = %3236, %3108
  %3250 = phi float [ %3246, %3236 ], [ %2679, %3108 ]
  %3251 = phi float [ %3247, %3236 ], [ %2680, %3108 ]
  %3252 = phi float [ %3248, %3236 ], [ %2681, %3108 ]
  %3253 = call float @dx.op.binary.f32(i32 36, float %3109, float %3250)  ; FMin(a,b)
  %3254 = call float @dx.op.binary.f32(i32 36, float %3110, float %3251)  ; FMin(a,b)
  %3255 = call float @dx.op.binary.f32(i32 36, float %3111, float %3252)  ; FMin(a,b)
  %3256 = call float @dx.op.binary.f32(i32 36, float %2825, float %2966)  ; FMin(a,b)
  %3257 = call float @dx.op.binary.f32(i32 36, float %2826, float %2967)  ; FMin(a,b)
  %3258 = call float @dx.op.binary.f32(i32 36, float %2827, float %2968)  ; FMin(a,b)
  %3259 = call float @dx.op.binary.f32(i32 36, float %3256, float %3253)  ; FMin(a,b)
  %3260 = call float @dx.op.binary.f32(i32 36, float %3257, float %3254)  ; FMin(a,b)
  %3261 = call float @dx.op.binary.f32(i32 36, float %3258, float %3255)  ; FMin(a,b)
  %3262 = call float @dx.op.binary.f32(i32 36, float %2679, float %3259)  ; FMin(a,b)
  %3263 = call float @dx.op.binary.f32(i32 36, float %2680, float %3260)  ; FMin(a,b)
  %3264 = call float @dx.op.binary.f32(i32 36, float %2681, float %3261)  ; FMin(a,b)
  %3265 = call float @dx.op.binary.f32(i32 35, float %3109, float %3250)  ; FMax(a,b)
  %3266 = call float @dx.op.binary.f32(i32 35, float %3110, float %3251)  ; FMax(a,b)
  %3267 = call float @dx.op.binary.f32(i32 35, float %3111, float %3252)  ; FMax(a,b)
  %3268 = call float @dx.op.binary.f32(i32 35, float %2825, float %2966)  ; FMax(a,b)
  %3269 = call float @dx.op.binary.f32(i32 35, float %2826, float %2967)  ; FMax(a,b)
  %3270 = call float @dx.op.binary.f32(i32 35, float %2827, float %2968)  ; FMax(a,b)
  %3271 = call float @dx.op.binary.f32(i32 35, float %3268, float %3265)  ; FMax(a,b)
  %3272 = call float @dx.op.binary.f32(i32 35, float %3269, float %3266)  ; FMax(a,b)
  %3273 = call float @dx.op.binary.f32(i32 35, float %3270, float %3267)  ; FMax(a,b)
  %3274 = call float @dx.op.binary.f32(i32 35, float %2679, float %3271)  ; FMax(a,b)
  %3275 = call float @dx.op.binary.f32(i32 35, float %2680, float %3272)  ; FMax(a,b)
  %3276 = call float @dx.op.binary.f32(i32 35, float %2681, float %3273)  ; FMax(a,b)
  %3277 = fsub fast float %3274, %3262
  %3278 = fsub fast float %3275, %3263
  %3279 = fsub fast float %3276, %3264
  %3280 = call float @dx.op.unary.f32(i32 6, float %3277)  ; FAbs(value)
  %3281 = call float @dx.op.unary.f32(i32 6, float %3278)  ; FAbs(value)
  %3282 = call float @dx.op.unary.f32(i32 6, float %3279)  ; FAbs(value)
  %3283 = call float @dx.op.binary.f32(i32 35, float %3281, float %3282)  ; FMax(a,b)
  %3284 = call float @dx.op.binary.f32(i32 35, float %3280, float %3283)  ; FMax(a,b)
  %3285 = call float @dx.op.binary.f32(i32 35, float %3275, float %3276)  ; FMax(a,b)
  %3286 = call float @dx.op.binary.f32(i32 35, float %3274, float %3285)  ; FMax(a,b)
  %3287 = fmul fast float %3286, 1.250000e-01
  %3288 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %3287)  ; FMax(a,b)
  %3289 = fcmp fast ogt float %3284, %3288
  br i1 %3289, label %3290, label %3351

; <label>:3290                                    ; preds = %3249
  %3291 = fsub fast float %2825, %2966
  %3292 = fsub fast float %2826, %2967
  %3293 = fsub fast float %2827, %2968
  %3294 = call float @dx.op.unary.f32(i32 6, float %3291)  ; FAbs(value)
  %3295 = call float @dx.op.unary.f32(i32 6, float %3292)  ; FAbs(value)
  %3296 = call float @dx.op.unary.f32(i32 6, float %3293)  ; FAbs(value)
  %3297 = call float @dx.op.binary.f32(i32 35, float %3295, float %3296)  ; FMax(a,b)
  %3298 = call float @dx.op.binary.f32(i32 35, float %3294, float %3297)  ; FMax(a,b)
  %3299 = fsub fast float %3109, %3250
  %3300 = fsub fast float %3110, %3251
  %3301 = fsub fast float %3111, %3252
  %3302 = call float @dx.op.unary.f32(i32 6, float %3299)  ; FAbs(value)
  %3303 = call float @dx.op.unary.f32(i32 6, float %3300)  ; FAbs(value)
  %3304 = call float @dx.op.unary.f32(i32 6, float %3301)  ; FAbs(value)
  %3305 = call float @dx.op.binary.f32(i32 35, float %3303, float %3304)  ; FMax(a,b)
  %3306 = call float @dx.op.binary.f32(i32 35, float %3302, float %3305)  ; FMax(a,b)
  %3307 = fcmp fast olt float %3298, %3306
  %3308 = select i1 %3307, float %2825, float %3109
  %3309 = select i1 %3307, float %2826, float %3110
  %3310 = select i1 %3307, float %2827, float %3111
  %3311 = select i1 %3307, float %2966, float %3250
  %3312 = select i1 %3307, float %2967, float %3251
  %3313 = select i1 %3307, float %2968, float %3252
  %3314 = fsub fast float %2679, %3311
  %3315 = fsub fast float %2680, %3312
  %3316 = fsub fast float %2681, %3313
  %3317 = fsub fast float %2679, %3308
  %3318 = fsub fast float %2680, %3309
  %3319 = fsub fast float %2681, %3310
  %3320 = call float @dx.op.dot3.f32(i32 55, float %3317, float %3318, float %3319, float %3314, float %3315, float %3316)  ; Dot3(ax,ay,az,bx,by,bz)
  %3321 = fcmp fast ogt float %3320, 0.000000e+00
  br i1 %3321, label %3322, label %3334

; <label>:3322                                    ; preds = %3290
  %3323 = fsub fast float %3308, %3311
  %3324 = fsub fast float %3309, %3312
  %3325 = fsub fast float %3310, %3313
  %3326 = call float @dx.op.unary.f32(i32 6, float %3323)  ; FAbs(value)
  %3327 = call float @dx.op.unary.f32(i32 6, float %3324)  ; FAbs(value)
  %3328 = call float @dx.op.unary.f32(i32 6, float %3325)  ; FAbs(value)
  %3329 = call float @dx.op.binary.f32(i32 35, float %3327, float %3328)  ; FMax(a,b)
  %3330 = call float @dx.op.binary.f32(i32 35, float %3326, float %3329)  ; FMax(a,b)
  %3331 = fmul fast float %3284, 2.500000e-01
  %3332 = fcmp fast olt float %3330, %3331
  %3333 = select i1 %3332, float 0x3FC3333340000000, float 0x3FD3333340000000
  br label %3334

; <label>:3334                                    ; preds = %3322, %3290
  %3335 = phi float [ 0x3FD3333340000000, %3290 ], [ %3333, %3322 ]
  %3336 = fadd fast float %3308, %3311
  %3337 = fadd fast float %3309, %3312
  %3338 = fadd fast float %3310, %3313
  %3339 = fmul fast float %3336, 5.000000e-01
  %3340 = fmul fast float %3337, 5.000000e-01
  %3341 = fmul fast float %3338, 5.000000e-01
  %3342 = fsub fast float %3339, %2679
  %3343 = fsub fast float %3340, %2680
  %3344 = fsub fast float %3341, %2681
  %3345 = fmul fast float %3335, %3342
  %3346 = fmul fast float %3335, %3343
  %3347 = fmul fast float %3335, %3344
  %3348 = fadd fast float %3345, %2679
  %3349 = fadd fast float %3346, %2680
  %3350 = fadd fast float %3347, %2681
  br label %3351

; <label>:3351                                    ; preds = %3334, %3249
  %3352 = phi float [ %3348, %3334 ], [ %2679, %3249 ]
  %3353 = phi float [ %3349, %3334 ], [ %2680, %3249 ]
  %3354 = phi float [ %3350, %3334 ], [ %2681, %3249 ]
  %3355 = fcmp fast ogt float %3352, 0x3F69A5C380000000
  %3356 = fcmp fast ogt float %3353, 0x3F69A5C380000000
  %3357 = fcmp fast ogt float %3354, 0x3F69A5C380000000
  %3358 = select i1 %3355, float 0.000000e+00, float 1.000000e+00
  %3359 = select i1 %3356, float 0.000000e+00, float 1.000000e+00
  %3360 = select i1 %3357, float 0.000000e+00, float 1.000000e+00
  %3361 = fmul fast float %3352, 0x4029D70A40000000
  %3362 = fmul fast float %3353, 0x4029D70A40000000
  %3363 = fmul fast float %3354, 0x4029D70A40000000
  %3364 = call float @dx.op.binary.f32(i32 35, float %3352, float 0.000000e+00)  ; FMax(a,b)
  %3365 = call float @dx.op.binary.f32(i32 35, float %3353, float 0.000000e+00)  ; FMax(a,b)
  %3366 = call float @dx.op.binary.f32(i32 35, float %3354, float 0.000000e+00)  ; FMax(a,b)
  %3367 = call float @dx.op.unary.f32(i32 23, float %3364)  ; Log(value)
  %3368 = call float @dx.op.unary.f32(i32 23, float %3365)  ; Log(value)
  %3369 = call float @dx.op.unary.f32(i32 23, float %3366)  ; Log(value)
  %3370 = fmul fast float %3367, 0x3FDAAAAAA0000000
  %3371 = fmul fast float %3368, 0x3FDAAAAAA0000000
  %3372 = fmul fast float %3369, 0x3FDAAAAAA0000000
  %3373 = call float @dx.op.unary.f32(i32 21, float %3370)  ; Exp(value)
  %3374 = call float @dx.op.unary.f32(i32 21, float %3371)  ; Exp(value)
  %3375 = call float @dx.op.unary.f32(i32 21, float %3372)  ; Exp(value)
  %3376 = fmul fast float %3373, 0x3FF0E147A0000000
  %3377 = fmul fast float %3374, 0x3FF0E147A0000000
  %3378 = fmul fast float %3375, 0x3FF0E147A0000000
  %3379 = fadd fast float %3376, 0xBFAC28F5C0000000
  %3380 = fadd fast float %3377, 0xBFAC28F5C0000000
  %3381 = fadd fast float %3378, 0xBFAC28F5C0000000
  %3382 = fsub fast float %3361, %3379
  %3383 = fsub fast float %3362, %3380
  %3384 = fsub fast float %3363, %3381
  %3385 = fmul fast float %3382, %3358
  %3386 = fmul fast float %3383, %3359
  %3387 = fmul fast float %3384, %3360
  %3388 = fadd fast float %3385, %3379
  %3389 = fadd fast float %3386, %3380
  %3390 = fadd fast float %3387, %3381
  br label %3391

; <label>:3391                                    ; preds = %3351, %2612
  %3392 = phi float [ %2607, %2612 ], [ %3388, %3351 ]
  %3393 = phi float [ %2608, %2612 ], [ %3389, %3351 ]
  %3394 = phi float [ %2609, %2612 ], [ %3390, %3351 ]
  %3395 = phi float [ %2613, %2612 ], [ %2610, %3351 ]
  %3396 = fcmp fast ogt float %3392, 0x3FA4B5DCC0000000
  %3397 = fcmp fast ogt float %3393, 0x3FA4B5DCC0000000
  %3398 = fcmp fast ogt float %3394, 0x3FA4B5DCC0000000
  %3399 = select i1 %3396, float 0.000000e+00, float 1.000000e+00
  %3400 = select i1 %3397, float 0.000000e+00, float 1.000000e+00
  %3401 = select i1 %3398, float 0.000000e+00, float 1.000000e+00
  %3402 = fmul fast float %3392, 0x3FB3D07220000000
  %3403 = fmul fast float %3393, 0x3FB3D07220000000
  %3404 = fmul fast float %3394, 0x3FB3D07220000000
  %3405 = fadd fast float %3392, 0x3FAC28F5C0000000
  %3406 = fadd fast float %3393, 0x3FAC28F5C0000000
  %3407 = fadd fast float %3394, 0x3FAC28F5C0000000
  %3408 = fmul fast float %3405, 0x3FEE54EDE0000000
  %3409 = fmul fast float %3406, 0x3FEE54EDE0000000
  %3410 = fmul fast float %3407, 0x3FEE54EDE0000000
  %3411 = call float @dx.op.unary.f32(i32 23, float %3408)  ; Log(value)
  %3412 = call float @dx.op.unary.f32(i32 23, float %3409)  ; Log(value)
  %3413 = call float @dx.op.unary.f32(i32 23, float %3410)  ; Log(value)
  %3414 = fmul fast float %3411, 0x4003333340000000
  %3415 = fmul fast float %3412, 0x4003333340000000
  %3416 = fmul fast float %3413, 0x4003333340000000
  %3417 = call float @dx.op.unary.f32(i32 21, float %3414)  ; Exp(value)
  %3418 = call float @dx.op.unary.f32(i32 21, float %3415)  ; Exp(value)
  %3419 = call float @dx.op.unary.f32(i32 21, float %3416)  ; Exp(value)
  %3420 = fsub fast float %3402, %3417
  %3421 = fsub fast float %3403, %3418
  %3422 = fsub fast float %3404, %3419
  %3423 = fmul fast float %3420, %3399
  %3424 = fmul fast float %3421, %3400
  %3425 = fmul fast float %3422, %3401
  %3426 = fadd fast float %3423, %3417
  %3427 = fadd fast float %3424, %3418
  %3428 = fadd fast float %3425, %3419
  %3429 = fmul fast float %957, %133
  %3430 = fmul fast float %958, %133
  %3431 = fmul fast float %959, %133
  %3432 = fmul fast float %1780, %134
  %3433 = fmul fast float %1781, %134
  %3434 = fmul fast float %1782, %134
  %3435 = fadd fast float %3432, %3429
  %3436 = fadd fast float %3433, %3430
  %3437 = fadd fast float %3434, %3431
  %3438 = fmul fast float %2603, %135
  %3439 = fmul fast float %2604, %135
  %3440 = fmul fast float %2605, %135
  %3441 = fadd fast float %3435, %3438
  %3442 = fadd fast float %3436, %3439
  %3443 = fadd fast float %3437, %3440
  %3444 = fmul fast float %3426, %136
  %3445 = fmul fast float %3427, %136
  %3446 = fmul fast float %3428, %136
  %3447 = fadd fast float %3441, %3444
  %3448 = fadd fast float %3442, %3445
  %3449 = fadd fast float %3443, %3446
  %3450 = fcmp fast ogt float %3447, 0x3F69A5C380000000
  %3451 = fcmp fast ogt float %3448, 0x3F69A5C380000000
  %3452 = fcmp fast ogt float %3449, 0x3F69A5C380000000
  %3453 = select i1 %3450, float 0.000000e+00, float 1.000000e+00
  %3454 = select i1 %3451, float 0.000000e+00, float 1.000000e+00
  %3455 = select i1 %3452, float 0.000000e+00, float 1.000000e+00
  %3456 = fmul fast float %3447, 0x4029D70A40000000
  %3457 = fmul fast float %3448, 0x4029D70A40000000
  %3458 = fmul fast float %3449, 0x4029D70A40000000
  %3459 = call float @dx.op.binary.f32(i32 35, float %3447, float 0.000000e+00)  ; FMax(a,b)
  %3460 = call float @dx.op.binary.f32(i32 35, float %3448, float 0.000000e+00)  ; FMax(a,b)
  %3461 = call float @dx.op.binary.f32(i32 35, float %3449, float 0.000000e+00)  ; FMax(a,b)
  %3462 = call float @dx.op.unary.f32(i32 23, float %3459)  ; Log(value)
  %3463 = call float @dx.op.unary.f32(i32 23, float %3460)  ; Log(value)
  %3464 = call float @dx.op.unary.f32(i32 23, float %3461)  ; Log(value)
  %3465 = fmul fast float %3462, 0x3FDAAAAAA0000000
  %3466 = fmul fast float %3463, 0x3FDAAAAAA0000000
  %3467 = fmul fast float %3464, 0x3FDAAAAAA0000000
  %3468 = call float @dx.op.unary.f32(i32 21, float %3465)  ; Exp(value)
  %3469 = call float @dx.op.unary.f32(i32 21, float %3466)  ; Exp(value)
  %3470 = call float @dx.op.unary.f32(i32 21, float %3467)  ; Exp(value)
  %3471 = fmul fast float %3468, 0x3FF0E147A0000000
  %3472 = fmul fast float %3469, 0x3FF0E147A0000000
  %3473 = fmul fast float %3470, 0x3FF0E147A0000000
  %3474 = fadd fast float %3471, 0xBFAC28F5C0000000
  %3475 = fadd fast float %3472, 0xBFAC28F5C0000000
  %3476 = fadd fast float %3473, 0xBFAC28F5C0000000
  %3477 = fsub fast float %3456, %3474
  %3478 = fsub fast float %3457, %3475
  %3479 = fsub fast float %3458, %3476
  %3480 = fmul fast float %3477, %3453
  %3481 = fmul fast float %3478, %3454
  %3482 = fmul fast float %3479, %3455
  %3483 = fadd fast float %3480, %3474
  %3484 = fadd fast float %3481, %3475
  %3485 = fadd fast float %3482, %3476
  %3486 = call float @dx.op.dot4.f32(i32 56, float %926, float %1749, float %2572, float %3395, float %133, float %134, float %135, float %136)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %3483)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %3484)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %3485)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %3486)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %51)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare i1 @dx.op.isSpecialFloat.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 0, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !37, null}
!12 = !{!13, !16, !17, !19, !21, !23, !25, !27, !29, !31, !34}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !15}
!17 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !18, i8 1, i32 1, i8 4, i32 2, i8 0, null}
!18 = !{i32 1}
!19 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !20, i8 1, i32 1, i8 4, i32 3, i8 0, null}
!20 = !{i32 2}
!21 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !22, i8 1, i32 1, i8 4, i32 4, i8 0, null}
!22 = !{i32 3}
!23 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !24, i8 1, i32 1, i8 4, i32 5, i8 0, null}
!24 = !{i32 4}
!25 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !26, i8 1, i32 1, i8 4, i32 6, i8 0, null}
!26 = !{i32 5}
!27 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !28, i8 1, i32 1, i8 4, i32 7, i8 0, null}
!28 = !{i32 6}
!29 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 8, i8 0, null}
!30 = !{i32 7}
!31 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 9, i8 0, !33}
!32 = !{i32 8}
!33 = !{i32 3, i32 15}
!34 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !35, i8 1, i32 1, i8 4, i32 10, i8 0, !36}
!35 = !{i32 9}
!36 = !{i32 3, i32 6}
!37 = !{!38, !39}
!38 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !33}
!39 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !40}
!40 = !{i32 3, i32 1}
