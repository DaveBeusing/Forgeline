;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float    yz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: 2e1f40d4deae549b1e06fb525d5ac75f
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %40 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %41 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %42 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %43 = extractvalue %dx.types.Dimensions %42, 0
  %44 = extractvalue %dx.types.Dimensions %42, 1
  %45 = uitofp i32 %43 to float
  %46 = uitofp i32 %44 to float
  %47 = fmul fast float %45, %40
  %48 = fmul fast float %46, %41
  %49 = fdiv fast float %47, %3
  %50 = fdiv fast float %48, %4
  %51 = fadd fast float %49, -5.000000e-01
  %52 = fadd fast float %50, -5.000000e-01
  %53 = call float @dx.op.unary.f32(i32 27, float %51)  ; Round_ni(value)
  %54 = call float @dx.op.unary.f32(i32 27, float %52)  ; Round_ni(value)
  %55 = fptosi float %53 to i32
  %56 = fptosi float %54 to i32
  %57 = call float @dx.op.unary.f32(i32 22, float %51)  ; Frc(value)
  %58 = call float @dx.op.unary.f32(i32 22, float %52)  ; Frc(value)
  %59 = add i32 %43, -1
  %60 = add i32 %44, -1
  %61 = call i32 @dx.op.binary.i32(i32 37, i32 %55, i32 0)  ; IMax(a,b)
  %62 = call i32 @dx.op.binary.i32(i32 37, i32 %56, i32 0)  ; IMax(a,b)
  %63 = call i32 @dx.op.binary.i32(i32 38, i32 %61, i32 %59)  ; IMin(a,b)
  %64 = call i32 @dx.op.binary.i32(i32 38, i32 %62, i32 %60)  ; IMin(a,b)
  %65 = add i32 %55, 1
  %66 = call i32 @dx.op.binary.i32(i32 37, i32 %65, i32 0)  ; IMax(a,b)
  %67 = call i32 @dx.op.binary.i32(i32 38, i32 %66, i32 %59)  ; IMin(a,b)
  %68 = add i32 %56, 1
  %69 = call i32 @dx.op.binary.i32(i32 37, i32 %68, i32 0)  ; IMax(a,b)
  %70 = call i32 @dx.op.binary.i32(i32 38, i32 %69, i32 %60)  ; IMin(a,b)
  %71 = call float @dx.op.unary.f32(i32 27, float %49)  ; Round_ni(value)
  %72 = call float @dx.op.unary.f32(i32 27, float %50)  ; Round_ni(value)
  %73 = fptosi float %71 to i32
  %74 = fptosi float %72 to i32
  %75 = call i32 @dx.op.binary.i32(i32 37, i32 %73, i32 0)  ; IMax(a,b)
  %76 = call i32 @dx.op.binary.i32(i32 37, i32 %74, i32 0)  ; IMax(a,b)
  %77 = call i32 @dx.op.binary.i32(i32 38, i32 %75, i32 %59)  ; IMin(a,b)
  %78 = call i32 @dx.op.binary.i32(i32 38, i32 %76, i32 %60)  ; IMin(a,b)
  %79 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %77, i32 %78, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %80 = extractvalue %dx.types.ResRet.f32 %79, 0
  %81 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %82 = extractvalue %dx.types.ResRet.f32 %81, 0
  %83 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %67, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %84 = extractvalue %dx.types.ResRet.f32 %83, 0
  %85 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %86 = extractvalue %dx.types.ResRet.f32 %85, 0
  %87 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %67, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %88 = extractvalue %dx.types.ResRet.f32 %87, 0
  %89 = fsub fast float 1.000000e+00, %57
  %90 = fsub fast float 1.000000e+00, %58
  %91 = fmul fast float %90, %89
  %92 = fmul fast float %90, %57
  %93 = fmul fast float %89, %58
  %94 = fmul fast float %58, %57
  %95 = fsub fast float 1.000000e+00, %80
  %96 = fmul fast float %95, 0x3FA99999A0000000
  %97 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %96)  ; FMax(a,b)
  %98 = fsub fast float %82, %80
  %99 = call float @dx.op.unary.f32(i32 6, float %98)  ; FAbs(value)
  %100 = fdiv fast float %99, %97
  %101 = fsub fast float 1.000000e+00, %100
  %102 = call float @dx.op.unary.f32(i32 7, float %101)  ; Saturate(value)
  %103 = fsub fast float %84, %80
  %104 = call float @dx.op.unary.f32(i32 6, float %103)  ; FAbs(value)
  %105 = fdiv fast float %104, %97
  %106 = fsub fast float 1.000000e+00, %105
  %107 = call float @dx.op.unary.f32(i32 7, float %106)  ; Saturate(value)
  %108 = fsub fast float %86, %80
  %109 = call float @dx.op.unary.f32(i32 6, float %108)  ; FAbs(value)
  %110 = fdiv fast float %109, %97
  %111 = fsub fast float 1.000000e+00, %110
  %112 = call float @dx.op.unary.f32(i32 7, float %111)  ; Saturate(value)
  %113 = fsub fast float %88, %80
  %114 = call float @dx.op.unary.f32(i32 6, float %113)  ; FAbs(value)
  %115 = fdiv fast float %114, %97
  %116 = fsub fast float 1.000000e+00, %115
  %117 = call float @dx.op.unary.f32(i32 7, float %116)  ; Saturate(value)
  %118 = fmul fast float %91, %102
  %119 = fmul fast float %92, %107
  %120 = fmul fast float %93, %112
  %121 = fmul fast float %94, %117
  %122 = fcmp fast oge float %57, 5.000000e-01
  %123 = zext i1 %122 to i32
  %124 = fcmp fast oge float %58, 5.000000e-01
  %125 = select i1 %124, i32 2, i32 0
  %126 = or i32 %125, %123
  %127 = call float @dx.op.dot4.f32(i32 56, float %118, float %119, float %120, float %121, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %128 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %118)  ; IsFinite(value)
  %129 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %119)  ; IsFinite(value)
  %130 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %120)  ; IsFinite(value)
  %131 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %121)  ; IsFinite(value)
  %132 = and i1 %128, %129
  %133 = and i1 %132, %130
  %134 = and i1 %133, %131
  br i1 %134, label %135, label %152

; <label>:135                                     ; preds = %0
  %136 = fcmp fast oge float %118, 0.000000e+00
  %137 = fcmp fast oge float %119, 0.000000e+00
  %138 = fcmp fast oge float %120, 0.000000e+00
  %139 = fcmp fast oge float %121, 0.000000e+00
  %140 = and i1 %136, %137
  %141 = and i1 %140, %138
  %142 = and i1 %141, %139
  br i1 %142, label %143, label %152

; <label>:143                                     ; preds = %135
  %144 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %127)  ; IsFinite(value)
  %145 = fcmp fast oge float %127, 0x3810000000000000
  %146 = and i1 %145, %144
  br i1 %146, label %147, label %152

; <label>:147                                     ; preds = %143
  %148 = fdiv fast float %118, %127
  %149 = fdiv fast float %119, %127
  %150 = fdiv fast float %120, %127
  %151 = fdiv fast float %121, %127
  br label %161

; <label>:152                                     ; preds = %143, %135, %0
  %153 = icmp eq i32 %126, 0
  %154 = uitofp i1 %153 to float
  %155 = icmp eq i32 %126, 1
  %156 = uitofp i1 %155 to float
  %157 = icmp eq i32 %126, 2
  %158 = uitofp i1 %157 to float
  %159 = icmp eq i32 %126, 3
  %160 = uitofp i1 %159 to float
  br label %161

; <label>:161                                     ; preds = %152, %147
  %162 = phi float [ %148, %147 ], [ %154, %152 ]
  %163 = phi float [ %149, %147 ], [ %156, %152 ]
  %164 = phi float [ %150, %147 ], [ %158, %152 ]
  %165 = phi float [ %151, %147 ], [ %160, %152 ]
  %166 = or i32 %56, %55
  %167 = icmp sgt i32 %166, -1
  br i1 %167, label %168, label %172

; <label>:168                                     ; preds = %161
  %169 = icmp slt i32 %65, %43
  %170 = icmp slt i32 %68, %44
  %171 = and i1 %169, %170
  br label %172

; <label>:172                                     ; preds = %168, %161
  %173 = phi i1 [ false, %161 ], [ %171, %168 ]
  br i1 %173, label %174, label %1011

; <label>:174                                     ; preds = %172
  %175 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %55, i32 %56, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %176 = extractvalue %dx.types.ResRet.f32 %175, 0
  %177 = extractvalue %dx.types.ResRet.f32 %175, 1
  %178 = extractvalue %dx.types.ResRet.f32 %175, 2
  %179 = extractvalue %dx.types.ResRet.f32 %175, 3
  %180 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %65, i32 %56, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %181 = extractvalue %dx.types.ResRet.f32 %180, 0
  %182 = extractvalue %dx.types.ResRet.f32 %180, 1
  %183 = extractvalue %dx.types.ResRet.f32 %180, 2
  %184 = extractvalue %dx.types.ResRet.f32 %180, 3
  %185 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %55, i32 %68, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %186 = extractvalue %dx.types.ResRet.f32 %185, 0
  %187 = extractvalue %dx.types.ResRet.f32 %185, 1
  %188 = extractvalue %dx.types.ResRet.f32 %185, 2
  %189 = extractvalue %dx.types.ResRet.f32 %185, 3
  %190 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %65, i32 %68, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %191 = extractvalue %dx.types.ResRet.f32 %190, 0
  %192 = extractvalue %dx.types.ResRet.f32 %190, 1
  %193 = extractvalue %dx.types.ResRet.f32 %190, 2
  %194 = extractvalue %dx.types.ResRet.f32 %190, 3
  %195 = fcmp fast olt float %179, 0.000000e+00
  br i1 %195, label %196, label %230

; <label>:196                                     ; preds = %174
  %197 = fcmp fast ogt float %176, 0x3FA4B5DCC0000000
  %198 = fcmp fast ogt float %177, 0x3FA4B5DCC0000000
  %199 = fcmp fast ogt float %178, 0x3FA4B5DCC0000000
  %200 = select i1 %197, float 0.000000e+00, float 1.000000e+00
  %201 = select i1 %198, float 0.000000e+00, float 1.000000e+00
  %202 = select i1 %199, float 0.000000e+00, float 1.000000e+00
  %203 = fmul fast float %176, 0x3FB3D07220000000
  %204 = fmul fast float %177, 0x3FB3D07220000000
  %205 = fmul fast float %178, 0x3FB3D07220000000
  %206 = fadd fast float %176, 0x3FAC28F5C0000000
  %207 = fadd fast float %177, 0x3FAC28F5C0000000
  %208 = fadd fast float %178, 0x3FAC28F5C0000000
  %209 = fmul fast float %206, 0x3FEE54EDE0000000
  %210 = fmul fast float %207, 0x3FEE54EDE0000000
  %211 = fmul fast float %208, 0x3FEE54EDE0000000
  %212 = call float @dx.op.unary.f32(i32 23, float %209)  ; Log(value)
  %213 = call float @dx.op.unary.f32(i32 23, float %210)  ; Log(value)
  %214 = call float @dx.op.unary.f32(i32 23, float %211)  ; Log(value)
  %215 = fmul fast float %212, 0x4003333340000000
  %216 = fmul fast float %213, 0x4003333340000000
  %217 = fmul fast float %214, 0x4003333340000000
  %218 = call float @dx.op.unary.f32(i32 21, float %215)  ; Exp(value)
  %219 = call float @dx.op.unary.f32(i32 21, float %216)  ; Exp(value)
  %220 = call float @dx.op.unary.f32(i32 21, float %217)  ; Exp(value)
  %221 = fsub fast float %203, %218
  %222 = fsub fast float %204, %219
  %223 = fsub fast float %205, %220
  %224 = fmul fast float %221, %200
  %225 = fmul fast float %222, %201
  %226 = fmul fast float %223, %202
  %227 = fadd fast float %224, %218
  %228 = fadd fast float %225, %219
  %229 = fadd fast float %226, %220
  br label %393

; <label>:230                                     ; preds = %174
  %231 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %55, i32 %56, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %232 = extractvalue %dx.types.ResRet.f32 %231, 0
  %233 = fcmp fast ogt float %38, 5.000000e-01
  %234 = fcmp fast olt float %232, 1.000000e+00
  %235 = and i1 %233, %234
  br i1 %235, label %236, label %322

; <label>:236                                     ; preds = %230
  %237 = sitofp i32 %55 to float
  %238 = sitofp i32 %56 to float
  %239 = fadd fast float %237, 5.000000e-01
  %240 = fadd fast float %238, 5.000000e-01
  %241 = fdiv fast float %239, %45
  %242 = fdiv fast float %240, %46
  %243 = fmul fast float %241, 2.000000e+00
  %244 = fmul fast float %242, 2.000000e+00
  %245 = fadd fast float %243, -1.000000e+00
  %246 = fsub fast float 1.000000e+00, %244
  %247 = fmul fast float %245, %35
  %248 = call float @dx.op.tertiary.f32(i32 46, float %246, float %31, float %247)  ; FMad(a,b,c)
  %249 = call float @dx.op.tertiary.f32(i32 46, float %232, float %27, float %248)  ; FMad(a,b,c)
  %250 = fadd fast float %249, %23
  %251 = call float @dx.op.unary.f32(i32 6, float %250)  ; FAbs(value)
  %252 = fcmp fast ogt float %251, 0x3EB0C6F7A0000000
  br i1 %252, label %253, label %322

; <label>:253                                     ; preds = %236
  %254 = fmul fast float %245, %34
  %255 = call float @dx.op.tertiary.f32(i32 46, float %246, float %30, float %254)  ; FMad(a,b,c)
  %256 = call float @dx.op.tertiary.f32(i32 46, float %232, float %26, float %255)  ; FMad(a,b,c)
  %257 = fadd fast float %256, %22
  %258 = fmul fast float %245, %33
  %259 = call float @dx.op.tertiary.f32(i32 46, float %246, float %29, float %258)  ; FMad(a,b,c)
  %260 = call float @dx.op.tertiary.f32(i32 46, float %232, float %25, float %259)  ; FMad(a,b,c)
  %261 = fadd fast float %260, %21
  %262 = fmul fast float %245, %32
  %263 = call float @dx.op.tertiary.f32(i32 46, float %246, float %28, float %262)  ; FMad(a,b,c)
  %264 = call float @dx.op.tertiary.f32(i32 46, float %232, float %24, float %263)  ; FMad(a,b,c)
  %265 = fadd fast float %264, %20
  %266 = fdiv fast float %265, %250
  %267 = fdiv fast float %261, %250
  %268 = fdiv fast float %257, %250
  %269 = fsub fast float %266, %17
  %270 = fsub fast float %267, %18
  %271 = fsub fast float %268, %19
  %272 = fmul fast float %269, %269
  %273 = fmul fast float %270, %270
  %274 = fadd fast float %273, %272
  %275 = fmul fast float %271, %271
  %276 = fadd fast float %274, %275
  %277 = call float @dx.op.unary.f32(i32 24, float %276)  ; Sqrt(value)
  %278 = fsub fast float %277, %9
  %279 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %278)  ; FMax(a,b)
  %280 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %280, label %281, label %304

; <label>:281                                     ; preds = %253
  %282 = call float @dx.op.unary.f32(i32 6, float %270)  ; FAbs(value)
  %283 = fmul fast float %282, %11
  %284 = fcmp fast olt float %283, 0x3F50624DE0000000
  br i1 %284, label %285, label %288

; <label>:285                                     ; preds = %281
  %286 = fmul fast float %283, 5.000000e-01
  %287 = fsub fast float 1.000000e+00, %286
  br label %293

; <label>:288                                     ; preds = %281
  %289 = fmul fast float %283, 0xBFF7154760000000
  %290 = call float @dx.op.unary.f32(i32 21, float %289)  ; Exp(value)
  %291 = fsub fast float 1.000000e+00, %290
  %292 = fdiv fast float %291, %283
  br label %293

; <label>:293                                     ; preds = %288, %285
  %294 = phi float [ %287, %285 ], [ %292, %288 ]
  %295 = call float @dx.op.binary.f32(i32 36, float %267, float %18)  ; FMin(a,b)
  %296 = fsub fast float %295, %10
  %297 = fmul fast float %11, %296
  %298 = fsub fast float -0.000000e+00, %297
  %299 = call float @dx.op.binary.f32(i32 35, float %298, float -4.000000e+01)  ; FMax(a,b)
  %300 = call float @dx.op.binary.f32(i32 36, float %299, float 5.000000e+00)  ; FMin(a,b)
  %301 = fmul fast float %300, 0x3FF7154760000000
  %302 = call float @dx.op.unary.f32(i32 21, float %301)  ; Exp(value)
  %303 = fmul fast float %302, %294
  br label %304

; <label>:304                                     ; preds = %293, %253
  %305 = phi float [ %303, %293 ], [ 1.000000e+00, %253 ]
  %306 = fmul fast float %279, %16
  %307 = fmul fast float %306, %305
  %308 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %307)  ; FMin(a,b)
  %309 = fmul fast float %308, 0xBFF7154760000000
  %310 = call float @dx.op.unary.f32(i32 21, float %309)  ; Exp(value)
  %311 = fsub fast float 1.000000e+00, %310
  %312 = call float @dx.op.binary.f32(i32 36, float %12, float %311)  ; FMin(a,b)
  %313 = fsub fast float %13, %176
  %314 = fsub fast float %14, %177
  %315 = fsub fast float %15, %178
  %316 = fmul fast float %312, %313
  %317 = fmul fast float %312, %314
  %318 = fmul fast float %312, %315
  %319 = fadd fast float %316, %176
  %320 = fadd fast float %317, %177
  %321 = fadd fast float %318, %178
  br label %322

; <label>:322                                     ; preds = %304, %236, %230
  %323 = phi float [ %319, %304 ], [ %176, %236 ], [ %176, %230 ]
  %324 = phi float [ %320, %304 ], [ %177, %236 ], [ %177, %230 ]
  %325 = phi float [ %321, %304 ], [ %178, %236 ], [ %178, %230 ]
  %326 = fadd fast float %5, 1.000000e+00
  %327 = fadd fast float %6, 1.000000e+00
  %328 = fsub fast float 1.000000e+00, %5
  %329 = fmul fast float %36, %326
  %330 = fmul fast float %36, %327
  %331 = fmul fast float %36, %328
  %332 = fmul fast float %329, %323
  %333 = fmul fast float %330, %324
  %334 = fmul fast float %331, %325
  %335 = fcmp fast ult float %37, 5.000000e-01
  br i1 %335, label %361, label %336

; <label>:336                                     ; preds = %322
  %337 = fmul fast float %332, 0x4004147AE0000000
  %338 = fmul fast float %333, 0x4004147AE0000000
  %339 = fmul fast float %334, 0x4004147AE0000000
  %340 = fadd fast float %337, 0x3F9EB851E0000000
  %341 = fadd fast float %338, 0x3F9EB851E0000000
  %342 = fadd fast float %339, 0x3F9EB851E0000000
  %343 = fmul fast float %340, %332
  %344 = fmul fast float %341, %333
  %345 = fmul fast float %342, %334
  %346 = fmul fast float %332, 0x400370A3E0000000
  %347 = fmul fast float %333, 0x400370A3E0000000
  %348 = fmul fast float %334, 0x400370A3E0000000
  %349 = fadd fast float %346, 0x3FE2E147A0000000
  %350 = fadd fast float %347, 0x3FE2E147A0000000
  %351 = fadd fast float %348, 0x3FE2E147A0000000
  %352 = fmul fast float %349, %332
  %353 = fmul fast float %350, %333
  %354 = fmul fast float %351, %334
  %355 = fadd fast float %352, 0x3FC1EB8520000000
  %356 = fadd fast float %353, 0x3FC1EB8520000000
  %357 = fadd fast float %354, 0x3FC1EB8520000000
  %358 = fdiv fast float %343, %355
  %359 = fdiv fast float %344, %356
  %360 = fdiv fast float %345, %357
  br label %361

; <label>:361                                     ; preds = %336, %322
  %362 = phi float [ %358, %336 ], [ %332, %322 ]
  %363 = phi float [ %359, %336 ], [ %333, %322 ]
  %364 = phi float [ %360, %336 ], [ %334, %322 ]
  %365 = call float @dx.op.unary.f32(i32 7, float %362)  ; Saturate(value)
  %366 = call float @dx.op.unary.f32(i32 7, float %363)  ; Saturate(value)
  %367 = call float @dx.op.unary.f32(i32 7, float %364)  ; Saturate(value)
  %368 = call float @dx.op.dot3.f32(i32 55, float %365, float %366, float %367, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %369 = fsub fast float %365, %368
  %370 = fsub fast float %366, %368
  %371 = fsub fast float %367, %368
  %372 = fmul fast float %369, %8
  %373 = fmul fast float %370, %8
  %374 = fmul fast float %371, %8
  %375 = fadd fast float %372, %368
  %376 = fadd fast float %373, %368
  %377 = fadd fast float %374, %368
  %378 = call float @dx.op.unary.f32(i32 7, float %375)  ; Saturate(value)
  %379 = call float @dx.op.unary.f32(i32 7, float %376)  ; Saturate(value)
  %380 = call float @dx.op.unary.f32(i32 7, float %377)  ; Saturate(value)
  %381 = fadd fast float %378, 0xBFC70A3D80000000
  %382 = fadd fast float %379, 0xBFC70A3D80000000
  %383 = fadd fast float %380, 0xBFC70A3D80000000
  %384 = fmul fast float %381, %7
  %385 = fmul fast float %382, %7
  %386 = fmul fast float %383, %7
  %387 = fadd fast float %384, 0x3FC70A3D80000000
  %388 = fadd fast float %385, 0x3FC70A3D80000000
  %389 = fadd fast float %386, 0x3FC70A3D80000000
  %390 = call float @dx.op.unary.f32(i32 7, float %387)  ; Saturate(value)
  %391 = call float @dx.op.unary.f32(i32 7, float %388)  ; Saturate(value)
  %392 = call float @dx.op.unary.f32(i32 7, float %389)  ; Saturate(value)
  br label %393

; <label>:393                                     ; preds = %361, %196
  %394 = phi float [ %227, %196 ], [ %390, %361 ]
  %395 = phi float [ %228, %196 ], [ %391, %361 ]
  %396 = phi float [ %229, %196 ], [ %392, %361 ]
  %397 = fcmp fast olt float %184, 0.000000e+00
  br i1 %397, label %398, label %432

; <label>:398                                     ; preds = %393
  %399 = fcmp fast ogt float %181, 0x3FA4B5DCC0000000
  %400 = fcmp fast ogt float %182, 0x3FA4B5DCC0000000
  %401 = fcmp fast ogt float %183, 0x3FA4B5DCC0000000
  %402 = select i1 %399, float 0.000000e+00, float 1.000000e+00
  %403 = select i1 %400, float 0.000000e+00, float 1.000000e+00
  %404 = select i1 %401, float 0.000000e+00, float 1.000000e+00
  %405 = fmul fast float %181, 0x3FB3D07220000000
  %406 = fmul fast float %182, 0x3FB3D07220000000
  %407 = fmul fast float %183, 0x3FB3D07220000000
  %408 = fadd fast float %181, 0x3FAC28F5C0000000
  %409 = fadd fast float %182, 0x3FAC28F5C0000000
  %410 = fadd fast float %183, 0x3FAC28F5C0000000
  %411 = fmul fast float %408, 0x3FEE54EDE0000000
  %412 = fmul fast float %409, 0x3FEE54EDE0000000
  %413 = fmul fast float %410, 0x3FEE54EDE0000000
  %414 = call float @dx.op.unary.f32(i32 23, float %411)  ; Log(value)
  %415 = call float @dx.op.unary.f32(i32 23, float %412)  ; Log(value)
  %416 = call float @dx.op.unary.f32(i32 23, float %413)  ; Log(value)
  %417 = fmul fast float %414, 0x4003333340000000
  %418 = fmul fast float %415, 0x4003333340000000
  %419 = fmul fast float %416, 0x4003333340000000
  %420 = call float @dx.op.unary.f32(i32 21, float %417)  ; Exp(value)
  %421 = call float @dx.op.unary.f32(i32 21, float %418)  ; Exp(value)
  %422 = call float @dx.op.unary.f32(i32 21, float %419)  ; Exp(value)
  %423 = fsub fast float %405, %420
  %424 = fsub fast float %406, %421
  %425 = fsub fast float %407, %422
  %426 = fmul fast float %423, %402
  %427 = fmul fast float %424, %403
  %428 = fmul fast float %425, %404
  %429 = fadd fast float %426, %420
  %430 = fadd fast float %427, %421
  %431 = fadd fast float %428, %422
  br label %595

; <label>:432                                     ; preds = %393
  %433 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %65, i32 %56, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %434 = extractvalue %dx.types.ResRet.f32 %433, 0
  %435 = fcmp fast ogt float %38, 5.000000e-01
  %436 = fcmp fast olt float %434, 1.000000e+00
  %437 = and i1 %435, %436
  br i1 %437, label %438, label %524

; <label>:438                                     ; preds = %432
  %439 = sitofp i32 %65 to float
  %440 = sitofp i32 %56 to float
  %441 = fadd fast float %439, 5.000000e-01
  %442 = fadd fast float %440, 5.000000e-01
  %443 = fdiv fast float %441, %45
  %444 = fdiv fast float %442, %46
  %445 = fmul fast float %443, 2.000000e+00
  %446 = fmul fast float %444, 2.000000e+00
  %447 = fadd fast float %445, -1.000000e+00
  %448 = fsub fast float 1.000000e+00, %446
  %449 = fmul fast float %447, %35
  %450 = call float @dx.op.tertiary.f32(i32 46, float %448, float %31, float %449)  ; FMad(a,b,c)
  %451 = call float @dx.op.tertiary.f32(i32 46, float %434, float %27, float %450)  ; FMad(a,b,c)
  %452 = fadd fast float %451, %23
  %453 = call float @dx.op.unary.f32(i32 6, float %452)  ; FAbs(value)
  %454 = fcmp fast ogt float %453, 0x3EB0C6F7A0000000
  br i1 %454, label %455, label %524

; <label>:455                                     ; preds = %438
  %456 = fmul fast float %447, %34
  %457 = call float @dx.op.tertiary.f32(i32 46, float %448, float %30, float %456)  ; FMad(a,b,c)
  %458 = call float @dx.op.tertiary.f32(i32 46, float %434, float %26, float %457)  ; FMad(a,b,c)
  %459 = fadd fast float %458, %22
  %460 = fmul fast float %447, %33
  %461 = call float @dx.op.tertiary.f32(i32 46, float %448, float %29, float %460)  ; FMad(a,b,c)
  %462 = call float @dx.op.tertiary.f32(i32 46, float %434, float %25, float %461)  ; FMad(a,b,c)
  %463 = fadd fast float %462, %21
  %464 = fmul fast float %447, %32
  %465 = call float @dx.op.tertiary.f32(i32 46, float %448, float %28, float %464)  ; FMad(a,b,c)
  %466 = call float @dx.op.tertiary.f32(i32 46, float %434, float %24, float %465)  ; FMad(a,b,c)
  %467 = fadd fast float %466, %20
  %468 = fdiv fast float %467, %452
  %469 = fdiv fast float %463, %452
  %470 = fdiv fast float %459, %452
  %471 = fsub fast float %468, %17
  %472 = fsub fast float %469, %18
  %473 = fsub fast float %470, %19
  %474 = fmul fast float %471, %471
  %475 = fmul fast float %472, %472
  %476 = fadd fast float %475, %474
  %477 = fmul fast float %473, %473
  %478 = fadd fast float %476, %477
  %479 = call float @dx.op.unary.f32(i32 24, float %478)  ; Sqrt(value)
  %480 = fsub fast float %479, %9
  %481 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %480)  ; FMax(a,b)
  %482 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %482, label %483, label %506

; <label>:483                                     ; preds = %455
  %484 = call float @dx.op.unary.f32(i32 6, float %472)  ; FAbs(value)
  %485 = fmul fast float %484, %11
  %486 = fcmp fast olt float %485, 0x3F50624DE0000000
  br i1 %486, label %487, label %490

; <label>:487                                     ; preds = %483
  %488 = fmul fast float %485, 5.000000e-01
  %489 = fsub fast float 1.000000e+00, %488
  br label %495

; <label>:490                                     ; preds = %483
  %491 = fmul fast float %485, 0xBFF7154760000000
  %492 = call float @dx.op.unary.f32(i32 21, float %491)  ; Exp(value)
  %493 = fsub fast float 1.000000e+00, %492
  %494 = fdiv fast float %493, %485
  br label %495

; <label>:495                                     ; preds = %490, %487
  %496 = phi float [ %489, %487 ], [ %494, %490 ]
  %497 = call float @dx.op.binary.f32(i32 36, float %469, float %18)  ; FMin(a,b)
  %498 = fsub fast float %497, %10
  %499 = fmul fast float %11, %498
  %500 = fsub fast float -0.000000e+00, %499
  %501 = call float @dx.op.binary.f32(i32 35, float %500, float -4.000000e+01)  ; FMax(a,b)
  %502 = call float @dx.op.binary.f32(i32 36, float %501, float 5.000000e+00)  ; FMin(a,b)
  %503 = fmul fast float %502, 0x3FF7154760000000
  %504 = call float @dx.op.unary.f32(i32 21, float %503)  ; Exp(value)
  %505 = fmul fast float %504, %496
  br label %506

; <label>:506                                     ; preds = %495, %455
  %507 = phi float [ %505, %495 ], [ 1.000000e+00, %455 ]
  %508 = fmul fast float %481, %16
  %509 = fmul fast float %508, %507
  %510 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %509)  ; FMin(a,b)
  %511 = fmul fast float %510, 0xBFF7154760000000
  %512 = call float @dx.op.unary.f32(i32 21, float %511)  ; Exp(value)
  %513 = fsub fast float 1.000000e+00, %512
  %514 = call float @dx.op.binary.f32(i32 36, float %12, float %513)  ; FMin(a,b)
  %515 = fsub fast float %13, %181
  %516 = fsub fast float %14, %182
  %517 = fsub fast float %15, %183
  %518 = fmul fast float %514, %515
  %519 = fmul fast float %514, %516
  %520 = fmul fast float %514, %517
  %521 = fadd fast float %518, %181
  %522 = fadd fast float %519, %182
  %523 = fadd fast float %520, %183
  br label %524

; <label>:524                                     ; preds = %506, %438, %432
  %525 = phi float [ %521, %506 ], [ %181, %438 ], [ %181, %432 ]
  %526 = phi float [ %522, %506 ], [ %182, %438 ], [ %182, %432 ]
  %527 = phi float [ %523, %506 ], [ %183, %438 ], [ %183, %432 ]
  %528 = fadd fast float %5, 1.000000e+00
  %529 = fadd fast float %6, 1.000000e+00
  %530 = fsub fast float 1.000000e+00, %5
  %531 = fmul fast float %36, %528
  %532 = fmul fast float %36, %529
  %533 = fmul fast float %36, %530
  %534 = fmul fast float %531, %525
  %535 = fmul fast float %532, %526
  %536 = fmul fast float %533, %527
  %537 = fcmp fast ult float %37, 5.000000e-01
  br i1 %537, label %563, label %538

; <label>:538                                     ; preds = %524
  %539 = fmul fast float %534, 0x4004147AE0000000
  %540 = fmul fast float %535, 0x4004147AE0000000
  %541 = fmul fast float %536, 0x4004147AE0000000
  %542 = fadd fast float %539, 0x3F9EB851E0000000
  %543 = fadd fast float %540, 0x3F9EB851E0000000
  %544 = fadd fast float %541, 0x3F9EB851E0000000
  %545 = fmul fast float %542, %534
  %546 = fmul fast float %543, %535
  %547 = fmul fast float %544, %536
  %548 = fmul fast float %534, 0x400370A3E0000000
  %549 = fmul fast float %535, 0x400370A3E0000000
  %550 = fmul fast float %536, 0x400370A3E0000000
  %551 = fadd fast float %548, 0x3FE2E147A0000000
  %552 = fadd fast float %549, 0x3FE2E147A0000000
  %553 = fadd fast float %550, 0x3FE2E147A0000000
  %554 = fmul fast float %551, %534
  %555 = fmul fast float %552, %535
  %556 = fmul fast float %553, %536
  %557 = fadd fast float %554, 0x3FC1EB8520000000
  %558 = fadd fast float %555, 0x3FC1EB8520000000
  %559 = fadd fast float %556, 0x3FC1EB8520000000
  %560 = fdiv fast float %545, %557
  %561 = fdiv fast float %546, %558
  %562 = fdiv fast float %547, %559
  br label %563

; <label>:563                                     ; preds = %538, %524
  %564 = phi float [ %560, %538 ], [ %534, %524 ]
  %565 = phi float [ %561, %538 ], [ %535, %524 ]
  %566 = phi float [ %562, %538 ], [ %536, %524 ]
  %567 = call float @dx.op.unary.f32(i32 7, float %564)  ; Saturate(value)
  %568 = call float @dx.op.unary.f32(i32 7, float %565)  ; Saturate(value)
  %569 = call float @dx.op.unary.f32(i32 7, float %566)  ; Saturate(value)
  %570 = call float @dx.op.dot3.f32(i32 55, float %567, float %568, float %569, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %571 = fsub fast float %567, %570
  %572 = fsub fast float %568, %570
  %573 = fsub fast float %569, %570
  %574 = fmul fast float %571, %8
  %575 = fmul fast float %572, %8
  %576 = fmul fast float %573, %8
  %577 = fadd fast float %574, %570
  %578 = fadd fast float %575, %570
  %579 = fadd fast float %576, %570
  %580 = call float @dx.op.unary.f32(i32 7, float %577)  ; Saturate(value)
  %581 = call float @dx.op.unary.f32(i32 7, float %578)  ; Saturate(value)
  %582 = call float @dx.op.unary.f32(i32 7, float %579)  ; Saturate(value)
  %583 = fadd fast float %580, 0xBFC70A3D80000000
  %584 = fadd fast float %581, 0xBFC70A3D80000000
  %585 = fadd fast float %582, 0xBFC70A3D80000000
  %586 = fmul fast float %583, %7
  %587 = fmul fast float %584, %7
  %588 = fmul fast float %585, %7
  %589 = fadd fast float %586, 0x3FC70A3D80000000
  %590 = fadd fast float %587, 0x3FC70A3D80000000
  %591 = fadd fast float %588, 0x3FC70A3D80000000
  %592 = call float @dx.op.unary.f32(i32 7, float %589)  ; Saturate(value)
  %593 = call float @dx.op.unary.f32(i32 7, float %590)  ; Saturate(value)
  %594 = call float @dx.op.unary.f32(i32 7, float %591)  ; Saturate(value)
  br label %595

; <label>:595                                     ; preds = %563, %398
  %596 = phi float [ %429, %398 ], [ %592, %563 ]
  %597 = phi float [ %430, %398 ], [ %593, %563 ]
  %598 = phi float [ %431, %398 ], [ %594, %563 ]
  %599 = fcmp fast olt float %189, 0.000000e+00
  br i1 %599, label %600, label %634

; <label>:600                                     ; preds = %595
  %601 = fcmp fast ogt float %186, 0x3FA4B5DCC0000000
  %602 = fcmp fast ogt float %187, 0x3FA4B5DCC0000000
  %603 = fcmp fast ogt float %188, 0x3FA4B5DCC0000000
  %604 = select i1 %601, float 0.000000e+00, float 1.000000e+00
  %605 = select i1 %602, float 0.000000e+00, float 1.000000e+00
  %606 = select i1 %603, float 0.000000e+00, float 1.000000e+00
  %607 = fmul fast float %186, 0x3FB3D07220000000
  %608 = fmul fast float %187, 0x3FB3D07220000000
  %609 = fmul fast float %188, 0x3FB3D07220000000
  %610 = fadd fast float %186, 0x3FAC28F5C0000000
  %611 = fadd fast float %187, 0x3FAC28F5C0000000
  %612 = fadd fast float %188, 0x3FAC28F5C0000000
  %613 = fmul fast float %610, 0x3FEE54EDE0000000
  %614 = fmul fast float %611, 0x3FEE54EDE0000000
  %615 = fmul fast float %612, 0x3FEE54EDE0000000
  %616 = call float @dx.op.unary.f32(i32 23, float %613)  ; Log(value)
  %617 = call float @dx.op.unary.f32(i32 23, float %614)  ; Log(value)
  %618 = call float @dx.op.unary.f32(i32 23, float %615)  ; Log(value)
  %619 = fmul fast float %616, 0x4003333340000000
  %620 = fmul fast float %617, 0x4003333340000000
  %621 = fmul fast float %618, 0x4003333340000000
  %622 = call float @dx.op.unary.f32(i32 21, float %619)  ; Exp(value)
  %623 = call float @dx.op.unary.f32(i32 21, float %620)  ; Exp(value)
  %624 = call float @dx.op.unary.f32(i32 21, float %621)  ; Exp(value)
  %625 = fsub fast float %607, %622
  %626 = fsub fast float %608, %623
  %627 = fsub fast float %609, %624
  %628 = fmul fast float %625, %604
  %629 = fmul fast float %626, %605
  %630 = fmul fast float %627, %606
  %631 = fadd fast float %628, %622
  %632 = fadd fast float %629, %623
  %633 = fadd fast float %630, %624
  br label %797

; <label>:634                                     ; preds = %595
  %635 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %55, i32 %68, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %636 = extractvalue %dx.types.ResRet.f32 %635, 0
  %637 = fcmp fast ogt float %38, 5.000000e-01
  %638 = fcmp fast olt float %636, 1.000000e+00
  %639 = and i1 %637, %638
  br i1 %639, label %640, label %726

; <label>:640                                     ; preds = %634
  %641 = sitofp i32 %55 to float
  %642 = sitofp i32 %68 to float
  %643 = fadd fast float %641, 5.000000e-01
  %644 = fadd fast float %642, 5.000000e-01
  %645 = fdiv fast float %643, %45
  %646 = fdiv fast float %644, %46
  %647 = fmul fast float %645, 2.000000e+00
  %648 = fmul fast float %646, 2.000000e+00
  %649 = fadd fast float %647, -1.000000e+00
  %650 = fsub fast float 1.000000e+00, %648
  %651 = fmul fast float %649, %35
  %652 = call float @dx.op.tertiary.f32(i32 46, float %650, float %31, float %651)  ; FMad(a,b,c)
  %653 = call float @dx.op.tertiary.f32(i32 46, float %636, float %27, float %652)  ; FMad(a,b,c)
  %654 = fadd fast float %653, %23
  %655 = call float @dx.op.unary.f32(i32 6, float %654)  ; FAbs(value)
  %656 = fcmp fast ogt float %655, 0x3EB0C6F7A0000000
  br i1 %656, label %657, label %726

; <label>:657                                     ; preds = %640
  %658 = fmul fast float %649, %34
  %659 = call float @dx.op.tertiary.f32(i32 46, float %650, float %30, float %658)  ; FMad(a,b,c)
  %660 = call float @dx.op.tertiary.f32(i32 46, float %636, float %26, float %659)  ; FMad(a,b,c)
  %661 = fadd fast float %660, %22
  %662 = fmul fast float %649, %33
  %663 = call float @dx.op.tertiary.f32(i32 46, float %650, float %29, float %662)  ; FMad(a,b,c)
  %664 = call float @dx.op.tertiary.f32(i32 46, float %636, float %25, float %663)  ; FMad(a,b,c)
  %665 = fadd fast float %664, %21
  %666 = fmul fast float %649, %32
  %667 = call float @dx.op.tertiary.f32(i32 46, float %650, float %28, float %666)  ; FMad(a,b,c)
  %668 = call float @dx.op.tertiary.f32(i32 46, float %636, float %24, float %667)  ; FMad(a,b,c)
  %669 = fadd fast float %668, %20
  %670 = fdiv fast float %669, %654
  %671 = fdiv fast float %665, %654
  %672 = fdiv fast float %661, %654
  %673 = fsub fast float %670, %17
  %674 = fsub fast float %671, %18
  %675 = fsub fast float %672, %19
  %676 = fmul fast float %673, %673
  %677 = fmul fast float %674, %674
  %678 = fadd fast float %677, %676
  %679 = fmul fast float %675, %675
  %680 = fadd fast float %678, %679
  %681 = call float @dx.op.unary.f32(i32 24, float %680)  ; Sqrt(value)
  %682 = fsub fast float %681, %9
  %683 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %682)  ; FMax(a,b)
  %684 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %684, label %685, label %708

; <label>:685                                     ; preds = %657
  %686 = call float @dx.op.unary.f32(i32 6, float %674)  ; FAbs(value)
  %687 = fmul fast float %686, %11
  %688 = fcmp fast olt float %687, 0x3F50624DE0000000
  br i1 %688, label %689, label %692

; <label>:689                                     ; preds = %685
  %690 = fmul fast float %687, 5.000000e-01
  %691 = fsub fast float 1.000000e+00, %690
  br label %697

; <label>:692                                     ; preds = %685
  %693 = fmul fast float %687, 0xBFF7154760000000
  %694 = call float @dx.op.unary.f32(i32 21, float %693)  ; Exp(value)
  %695 = fsub fast float 1.000000e+00, %694
  %696 = fdiv fast float %695, %687
  br label %697

; <label>:697                                     ; preds = %692, %689
  %698 = phi float [ %691, %689 ], [ %696, %692 ]
  %699 = call float @dx.op.binary.f32(i32 36, float %671, float %18)  ; FMin(a,b)
  %700 = fsub fast float %699, %10
  %701 = fmul fast float %11, %700
  %702 = fsub fast float -0.000000e+00, %701
  %703 = call float @dx.op.binary.f32(i32 35, float %702, float -4.000000e+01)  ; FMax(a,b)
  %704 = call float @dx.op.binary.f32(i32 36, float %703, float 5.000000e+00)  ; FMin(a,b)
  %705 = fmul fast float %704, 0x3FF7154760000000
  %706 = call float @dx.op.unary.f32(i32 21, float %705)  ; Exp(value)
  %707 = fmul fast float %706, %698
  br label %708

; <label>:708                                     ; preds = %697, %657
  %709 = phi float [ %707, %697 ], [ 1.000000e+00, %657 ]
  %710 = fmul fast float %683, %16
  %711 = fmul fast float %710, %709
  %712 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %711)  ; FMin(a,b)
  %713 = fmul fast float %712, 0xBFF7154760000000
  %714 = call float @dx.op.unary.f32(i32 21, float %713)  ; Exp(value)
  %715 = fsub fast float 1.000000e+00, %714
  %716 = call float @dx.op.binary.f32(i32 36, float %12, float %715)  ; FMin(a,b)
  %717 = fsub fast float %13, %186
  %718 = fsub fast float %14, %187
  %719 = fsub fast float %15, %188
  %720 = fmul fast float %716, %717
  %721 = fmul fast float %716, %718
  %722 = fmul fast float %716, %719
  %723 = fadd fast float %720, %186
  %724 = fadd fast float %721, %187
  %725 = fadd fast float %722, %188
  br label %726

; <label>:726                                     ; preds = %708, %640, %634
  %727 = phi float [ %723, %708 ], [ %186, %640 ], [ %186, %634 ]
  %728 = phi float [ %724, %708 ], [ %187, %640 ], [ %187, %634 ]
  %729 = phi float [ %725, %708 ], [ %188, %640 ], [ %188, %634 ]
  %730 = fadd fast float %5, 1.000000e+00
  %731 = fadd fast float %6, 1.000000e+00
  %732 = fsub fast float 1.000000e+00, %5
  %733 = fmul fast float %36, %730
  %734 = fmul fast float %36, %731
  %735 = fmul fast float %36, %732
  %736 = fmul fast float %733, %727
  %737 = fmul fast float %734, %728
  %738 = fmul fast float %735, %729
  %739 = fcmp fast ult float %37, 5.000000e-01
  br i1 %739, label %765, label %740

; <label>:740                                     ; preds = %726
  %741 = fmul fast float %736, 0x4004147AE0000000
  %742 = fmul fast float %737, 0x4004147AE0000000
  %743 = fmul fast float %738, 0x4004147AE0000000
  %744 = fadd fast float %741, 0x3F9EB851E0000000
  %745 = fadd fast float %742, 0x3F9EB851E0000000
  %746 = fadd fast float %743, 0x3F9EB851E0000000
  %747 = fmul fast float %744, %736
  %748 = fmul fast float %745, %737
  %749 = fmul fast float %746, %738
  %750 = fmul fast float %736, 0x400370A3E0000000
  %751 = fmul fast float %737, 0x400370A3E0000000
  %752 = fmul fast float %738, 0x400370A3E0000000
  %753 = fadd fast float %750, 0x3FE2E147A0000000
  %754 = fadd fast float %751, 0x3FE2E147A0000000
  %755 = fadd fast float %752, 0x3FE2E147A0000000
  %756 = fmul fast float %753, %736
  %757 = fmul fast float %754, %737
  %758 = fmul fast float %755, %738
  %759 = fadd fast float %756, 0x3FC1EB8520000000
  %760 = fadd fast float %757, 0x3FC1EB8520000000
  %761 = fadd fast float %758, 0x3FC1EB8520000000
  %762 = fdiv fast float %747, %759
  %763 = fdiv fast float %748, %760
  %764 = fdiv fast float %749, %761
  br label %765

; <label>:765                                     ; preds = %740, %726
  %766 = phi float [ %762, %740 ], [ %736, %726 ]
  %767 = phi float [ %763, %740 ], [ %737, %726 ]
  %768 = phi float [ %764, %740 ], [ %738, %726 ]
  %769 = call float @dx.op.unary.f32(i32 7, float %766)  ; Saturate(value)
  %770 = call float @dx.op.unary.f32(i32 7, float %767)  ; Saturate(value)
  %771 = call float @dx.op.unary.f32(i32 7, float %768)  ; Saturate(value)
  %772 = call float @dx.op.dot3.f32(i32 55, float %769, float %770, float %771, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %773 = fsub fast float %769, %772
  %774 = fsub fast float %770, %772
  %775 = fsub fast float %771, %772
  %776 = fmul fast float %773, %8
  %777 = fmul fast float %774, %8
  %778 = fmul fast float %775, %8
  %779 = fadd fast float %776, %772
  %780 = fadd fast float %777, %772
  %781 = fadd fast float %778, %772
  %782 = call float @dx.op.unary.f32(i32 7, float %779)  ; Saturate(value)
  %783 = call float @dx.op.unary.f32(i32 7, float %780)  ; Saturate(value)
  %784 = call float @dx.op.unary.f32(i32 7, float %781)  ; Saturate(value)
  %785 = fadd fast float %782, 0xBFC70A3D80000000
  %786 = fadd fast float %783, 0xBFC70A3D80000000
  %787 = fadd fast float %784, 0xBFC70A3D80000000
  %788 = fmul fast float %785, %7
  %789 = fmul fast float %786, %7
  %790 = fmul fast float %787, %7
  %791 = fadd fast float %788, 0x3FC70A3D80000000
  %792 = fadd fast float %789, 0x3FC70A3D80000000
  %793 = fadd fast float %790, 0x3FC70A3D80000000
  %794 = call float @dx.op.unary.f32(i32 7, float %791)  ; Saturate(value)
  %795 = call float @dx.op.unary.f32(i32 7, float %792)  ; Saturate(value)
  %796 = call float @dx.op.unary.f32(i32 7, float %793)  ; Saturate(value)
  br label %797

; <label>:797                                     ; preds = %765, %600
  %798 = phi float [ %631, %600 ], [ %794, %765 ]
  %799 = phi float [ %632, %600 ], [ %795, %765 ]
  %800 = phi float [ %633, %600 ], [ %796, %765 ]
  %801 = fcmp fast olt float %194, 0.000000e+00
  br i1 %801, label %802, label %836

; <label>:802                                     ; preds = %797
  %803 = fcmp fast ogt float %191, 0x3FA4B5DCC0000000
  %804 = fcmp fast ogt float %192, 0x3FA4B5DCC0000000
  %805 = fcmp fast ogt float %193, 0x3FA4B5DCC0000000
  %806 = select i1 %803, float 0.000000e+00, float 1.000000e+00
  %807 = select i1 %804, float 0.000000e+00, float 1.000000e+00
  %808 = select i1 %805, float 0.000000e+00, float 1.000000e+00
  %809 = fmul fast float %191, 0x3FB3D07220000000
  %810 = fmul fast float %192, 0x3FB3D07220000000
  %811 = fmul fast float %193, 0x3FB3D07220000000
  %812 = fadd fast float %191, 0x3FAC28F5C0000000
  %813 = fadd fast float %192, 0x3FAC28F5C0000000
  %814 = fadd fast float %193, 0x3FAC28F5C0000000
  %815 = fmul fast float %812, 0x3FEE54EDE0000000
  %816 = fmul fast float %813, 0x3FEE54EDE0000000
  %817 = fmul fast float %814, 0x3FEE54EDE0000000
  %818 = call float @dx.op.unary.f32(i32 23, float %815)  ; Log(value)
  %819 = call float @dx.op.unary.f32(i32 23, float %816)  ; Log(value)
  %820 = call float @dx.op.unary.f32(i32 23, float %817)  ; Log(value)
  %821 = fmul fast float %818, 0x4003333340000000
  %822 = fmul fast float %819, 0x4003333340000000
  %823 = fmul fast float %820, 0x4003333340000000
  %824 = call float @dx.op.unary.f32(i32 21, float %821)  ; Exp(value)
  %825 = call float @dx.op.unary.f32(i32 21, float %822)  ; Exp(value)
  %826 = call float @dx.op.unary.f32(i32 21, float %823)  ; Exp(value)
  %827 = fsub fast float %809, %824
  %828 = fsub fast float %810, %825
  %829 = fsub fast float %811, %826
  %830 = fmul fast float %827, %806
  %831 = fmul fast float %828, %807
  %832 = fmul fast float %829, %808
  %833 = fadd fast float %830, %824
  %834 = fadd fast float %831, %825
  %835 = fadd fast float %832, %826
  br label %999

; <label>:836                                     ; preds = %797
  %837 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %65, i32 %68, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %838 = extractvalue %dx.types.ResRet.f32 %837, 0
  %839 = fcmp fast ogt float %38, 5.000000e-01
  %840 = fcmp fast olt float %838, 1.000000e+00
  %841 = and i1 %839, %840
  br i1 %841, label %842, label %928

; <label>:842                                     ; preds = %836
  %843 = sitofp i32 %65 to float
  %844 = sitofp i32 %68 to float
  %845 = fadd fast float %843, 5.000000e-01
  %846 = fadd fast float %844, 5.000000e-01
  %847 = fdiv fast float %845, %45
  %848 = fdiv fast float %846, %46
  %849 = fmul fast float %847, 2.000000e+00
  %850 = fmul fast float %848, 2.000000e+00
  %851 = fadd fast float %849, -1.000000e+00
  %852 = fsub fast float 1.000000e+00, %850
  %853 = fmul fast float %851, %35
  %854 = call float @dx.op.tertiary.f32(i32 46, float %852, float %31, float %853)  ; FMad(a,b,c)
  %855 = call float @dx.op.tertiary.f32(i32 46, float %838, float %27, float %854)  ; FMad(a,b,c)
  %856 = fadd fast float %855, %23
  %857 = call float @dx.op.unary.f32(i32 6, float %856)  ; FAbs(value)
  %858 = fcmp fast ogt float %857, 0x3EB0C6F7A0000000
  br i1 %858, label %859, label %928

; <label>:859                                     ; preds = %842
  %860 = fmul fast float %851, %34
  %861 = call float @dx.op.tertiary.f32(i32 46, float %852, float %30, float %860)  ; FMad(a,b,c)
  %862 = call float @dx.op.tertiary.f32(i32 46, float %838, float %26, float %861)  ; FMad(a,b,c)
  %863 = fadd fast float %862, %22
  %864 = fmul fast float %851, %33
  %865 = call float @dx.op.tertiary.f32(i32 46, float %852, float %29, float %864)  ; FMad(a,b,c)
  %866 = call float @dx.op.tertiary.f32(i32 46, float %838, float %25, float %865)  ; FMad(a,b,c)
  %867 = fadd fast float %866, %21
  %868 = fmul fast float %851, %32
  %869 = call float @dx.op.tertiary.f32(i32 46, float %852, float %28, float %868)  ; FMad(a,b,c)
  %870 = call float @dx.op.tertiary.f32(i32 46, float %838, float %24, float %869)  ; FMad(a,b,c)
  %871 = fadd fast float %870, %20
  %872 = fdiv fast float %871, %856
  %873 = fdiv fast float %867, %856
  %874 = fdiv fast float %863, %856
  %875 = fsub fast float %872, %17
  %876 = fsub fast float %873, %18
  %877 = fsub fast float %874, %19
  %878 = fmul fast float %875, %875
  %879 = fmul fast float %876, %876
  %880 = fadd fast float %879, %878
  %881 = fmul fast float %877, %877
  %882 = fadd fast float %880, %881
  %883 = call float @dx.op.unary.f32(i32 24, float %882)  ; Sqrt(value)
  %884 = fsub fast float %883, %9
  %885 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %884)  ; FMax(a,b)
  %886 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %886, label %887, label %910

; <label>:887                                     ; preds = %859
  %888 = call float @dx.op.unary.f32(i32 6, float %876)  ; FAbs(value)
  %889 = fmul fast float %888, %11
  %890 = fcmp fast olt float %889, 0x3F50624DE0000000
  br i1 %890, label %891, label %894

; <label>:891                                     ; preds = %887
  %892 = fmul fast float %889, 5.000000e-01
  %893 = fsub fast float 1.000000e+00, %892
  br label %899

; <label>:894                                     ; preds = %887
  %895 = fmul fast float %889, 0xBFF7154760000000
  %896 = call float @dx.op.unary.f32(i32 21, float %895)  ; Exp(value)
  %897 = fsub fast float 1.000000e+00, %896
  %898 = fdiv fast float %897, %889
  br label %899

; <label>:899                                     ; preds = %894, %891
  %900 = phi float [ %893, %891 ], [ %898, %894 ]
  %901 = call float @dx.op.binary.f32(i32 36, float %873, float %18)  ; FMin(a,b)
  %902 = fsub fast float %901, %10
  %903 = fmul fast float %11, %902
  %904 = fsub fast float -0.000000e+00, %903
  %905 = call float @dx.op.binary.f32(i32 35, float %904, float -4.000000e+01)  ; FMax(a,b)
  %906 = call float @dx.op.binary.f32(i32 36, float %905, float 5.000000e+00)  ; FMin(a,b)
  %907 = fmul fast float %906, 0x3FF7154760000000
  %908 = call float @dx.op.unary.f32(i32 21, float %907)  ; Exp(value)
  %909 = fmul fast float %908, %900
  br label %910

; <label>:910                                     ; preds = %899, %859
  %911 = phi float [ %909, %899 ], [ 1.000000e+00, %859 ]
  %912 = fmul fast float %885, %16
  %913 = fmul fast float %912, %911
  %914 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %913)  ; FMin(a,b)
  %915 = fmul fast float %914, 0xBFF7154760000000
  %916 = call float @dx.op.unary.f32(i32 21, float %915)  ; Exp(value)
  %917 = fsub fast float 1.000000e+00, %916
  %918 = call float @dx.op.binary.f32(i32 36, float %12, float %917)  ; FMin(a,b)
  %919 = fsub fast float %13, %191
  %920 = fsub fast float %14, %192
  %921 = fsub fast float %15, %193
  %922 = fmul fast float %918, %919
  %923 = fmul fast float %918, %920
  %924 = fmul fast float %918, %921
  %925 = fadd fast float %922, %191
  %926 = fadd fast float %923, %192
  %927 = fadd fast float %924, %193
  br label %928

; <label>:928                                     ; preds = %910, %842, %836
  %929 = phi float [ %925, %910 ], [ %191, %842 ], [ %191, %836 ]
  %930 = phi float [ %926, %910 ], [ %192, %842 ], [ %192, %836 ]
  %931 = phi float [ %927, %910 ], [ %193, %842 ], [ %193, %836 ]
  %932 = fadd fast float %5, 1.000000e+00
  %933 = fadd fast float %6, 1.000000e+00
  %934 = fsub fast float 1.000000e+00, %5
  %935 = fmul fast float %36, %932
  %936 = fmul fast float %36, %933
  %937 = fmul fast float %36, %934
  %938 = fmul fast float %935, %929
  %939 = fmul fast float %936, %930
  %940 = fmul fast float %937, %931
  %941 = fcmp fast ult float %37, 5.000000e-01
  br i1 %941, label %967, label %942

; <label>:942                                     ; preds = %928
  %943 = fmul fast float %938, 0x4004147AE0000000
  %944 = fmul fast float %939, 0x4004147AE0000000
  %945 = fmul fast float %940, 0x4004147AE0000000
  %946 = fadd fast float %943, 0x3F9EB851E0000000
  %947 = fadd fast float %944, 0x3F9EB851E0000000
  %948 = fadd fast float %945, 0x3F9EB851E0000000
  %949 = fmul fast float %946, %938
  %950 = fmul fast float %947, %939
  %951 = fmul fast float %948, %940
  %952 = fmul fast float %938, 0x400370A3E0000000
  %953 = fmul fast float %939, 0x400370A3E0000000
  %954 = fmul fast float %940, 0x400370A3E0000000
  %955 = fadd fast float %952, 0x3FE2E147A0000000
  %956 = fadd fast float %953, 0x3FE2E147A0000000
  %957 = fadd fast float %954, 0x3FE2E147A0000000
  %958 = fmul fast float %955, %938
  %959 = fmul fast float %956, %939
  %960 = fmul fast float %957, %940
  %961 = fadd fast float %958, 0x3FC1EB8520000000
  %962 = fadd fast float %959, 0x3FC1EB8520000000
  %963 = fadd fast float %960, 0x3FC1EB8520000000
  %964 = fdiv fast float %949, %961
  %965 = fdiv fast float %950, %962
  %966 = fdiv fast float %951, %963
  br label %967

; <label>:967                                     ; preds = %942, %928
  %968 = phi float [ %964, %942 ], [ %938, %928 ]
  %969 = phi float [ %965, %942 ], [ %939, %928 ]
  %970 = phi float [ %966, %942 ], [ %940, %928 ]
  %971 = call float @dx.op.unary.f32(i32 7, float %968)  ; Saturate(value)
  %972 = call float @dx.op.unary.f32(i32 7, float %969)  ; Saturate(value)
  %973 = call float @dx.op.unary.f32(i32 7, float %970)  ; Saturate(value)
  %974 = call float @dx.op.dot3.f32(i32 55, float %971, float %972, float %973, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %975 = fsub fast float %971, %974
  %976 = fsub fast float %972, %974
  %977 = fsub fast float %973, %974
  %978 = fmul fast float %975, %8
  %979 = fmul fast float %976, %8
  %980 = fmul fast float %977, %8
  %981 = fadd fast float %978, %974
  %982 = fadd fast float %979, %974
  %983 = fadd fast float %980, %974
  %984 = call float @dx.op.unary.f32(i32 7, float %981)  ; Saturate(value)
  %985 = call float @dx.op.unary.f32(i32 7, float %982)  ; Saturate(value)
  %986 = call float @dx.op.unary.f32(i32 7, float %983)  ; Saturate(value)
  %987 = fadd fast float %984, 0xBFC70A3D80000000
  %988 = fadd fast float %985, 0xBFC70A3D80000000
  %989 = fadd fast float %986, 0xBFC70A3D80000000
  %990 = fmul fast float %987, %7
  %991 = fmul fast float %988, %7
  %992 = fmul fast float %989, %7
  %993 = fadd fast float %990, 0x3FC70A3D80000000
  %994 = fadd fast float %991, 0x3FC70A3D80000000
  %995 = fadd fast float %992, 0x3FC70A3D80000000
  %996 = call float @dx.op.unary.f32(i32 7, float %993)  ; Saturate(value)
  %997 = call float @dx.op.unary.f32(i32 7, float %994)  ; Saturate(value)
  %998 = call float @dx.op.unary.f32(i32 7, float %995)  ; Saturate(value)
  br label %999

; <label>:999                                     ; preds = %967, %802
  %1000 = phi float [ %833, %802 ], [ %996, %967 ]
  %1001 = phi float [ %834, %802 ], [ %997, %967 ]
  %1002 = phi float [ %835, %802 ], [ %998, %967 ]
  %1003 = fsub fast float -1.000000e+00, %179
  %1004 = select i1 %195, float %1003, float %179
  %1005 = fsub fast float -1.000000e+00, %184
  %1006 = select i1 %397, float %1005, float %184
  %1007 = fsub fast float -1.000000e+00, %189
  %1008 = select i1 %599, float %1007, float %189
  %1009 = fsub fast float -1.000000e+00, %194
  %1010 = select i1 %801, float %1009, float %194
  br label %1835

; <label>:1011                                    ; preds = %172
  %1012 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1013 = extractvalue %dx.types.ResRet.f32 %1012, 0
  %1014 = extractvalue %dx.types.ResRet.f32 %1012, 1
  %1015 = extractvalue %dx.types.ResRet.f32 %1012, 2
  %1016 = extractvalue %dx.types.ResRet.f32 %1012, 3
  %1017 = fcmp fast olt float %1016, 0.000000e+00
  br i1 %1017, label %1018, label %1053

; <label>:1018                                    ; preds = %1011
  %1019 = fcmp fast ogt float %1013, 0x3FA4B5DCC0000000
  %1020 = fcmp fast ogt float %1014, 0x3FA4B5DCC0000000
  %1021 = fcmp fast ogt float %1015, 0x3FA4B5DCC0000000
  %1022 = select i1 %1019, float 0.000000e+00, float 1.000000e+00
  %1023 = select i1 %1020, float 0.000000e+00, float 1.000000e+00
  %1024 = select i1 %1021, float 0.000000e+00, float 1.000000e+00
  %1025 = fmul fast float %1013, 0x3FB3D07220000000
  %1026 = fmul fast float %1014, 0x3FB3D07220000000
  %1027 = fmul fast float %1015, 0x3FB3D07220000000
  %1028 = fadd fast float %1013, 0x3FAC28F5C0000000
  %1029 = fadd fast float %1014, 0x3FAC28F5C0000000
  %1030 = fadd fast float %1015, 0x3FAC28F5C0000000
  %1031 = fmul fast float %1028, 0x3FEE54EDE0000000
  %1032 = fmul fast float %1029, 0x3FEE54EDE0000000
  %1033 = fmul fast float %1030, 0x3FEE54EDE0000000
  %1034 = call float @dx.op.unary.f32(i32 23, float %1031)  ; Log(value)
  %1035 = call float @dx.op.unary.f32(i32 23, float %1032)  ; Log(value)
  %1036 = call float @dx.op.unary.f32(i32 23, float %1033)  ; Log(value)
  %1037 = fmul fast float %1034, 0x4003333340000000
  %1038 = fmul fast float %1035, 0x4003333340000000
  %1039 = fmul fast float %1036, 0x4003333340000000
  %1040 = call float @dx.op.unary.f32(i32 21, float %1037)  ; Exp(value)
  %1041 = call float @dx.op.unary.f32(i32 21, float %1038)  ; Exp(value)
  %1042 = call float @dx.op.unary.f32(i32 21, float %1039)  ; Exp(value)
  %1043 = fsub fast float %1025, %1040
  %1044 = fsub fast float %1026, %1041
  %1045 = fsub fast float %1027, %1042
  %1046 = fmul fast float %1043, %1022
  %1047 = fmul fast float %1044, %1023
  %1048 = fmul fast float %1045, %1024
  %1049 = fadd fast float %1046, %1040
  %1050 = fadd fast float %1047, %1041
  %1051 = fadd fast float %1048, %1042
  %1052 = fsub fast float -1.000000e+00, %1016
  br label %1214

; <label>:1053                                    ; preds = %1011
  %1054 = fcmp fast ogt float %38, 5.000000e-01
  %1055 = fcmp fast olt float %82, 1.000000e+00
  %1056 = and i1 %1054, %1055
  br i1 %1056, label %1057, label %1143

; <label>:1057                                    ; preds = %1053
  %1058 = sitofp i32 %63 to float
  %1059 = sitofp i32 %64 to float
  %1060 = fadd fast float %1058, 5.000000e-01
  %1061 = fadd fast float %1059, 5.000000e-01
  %1062 = fdiv fast float %1060, %45
  %1063 = fdiv fast float %1061, %46
  %1064 = fmul fast float %1062, 2.000000e+00
  %1065 = fmul fast float %1063, 2.000000e+00
  %1066 = fadd fast float %1064, -1.000000e+00
  %1067 = fsub fast float 1.000000e+00, %1065
  %1068 = fmul fast float %1066, %35
  %1069 = call float @dx.op.tertiary.f32(i32 46, float %1067, float %31, float %1068)  ; FMad(a,b,c)
  %1070 = call float @dx.op.tertiary.f32(i32 46, float %82, float %27, float %1069)  ; FMad(a,b,c)
  %1071 = fadd fast float %1070, %23
  %1072 = call float @dx.op.unary.f32(i32 6, float %1071)  ; FAbs(value)
  %1073 = fcmp fast ogt float %1072, 0x3EB0C6F7A0000000
  br i1 %1073, label %1074, label %1143

; <label>:1074                                    ; preds = %1057
  %1075 = fmul fast float %1066, %34
  %1076 = call float @dx.op.tertiary.f32(i32 46, float %1067, float %30, float %1075)  ; FMad(a,b,c)
  %1077 = call float @dx.op.tertiary.f32(i32 46, float %82, float %26, float %1076)  ; FMad(a,b,c)
  %1078 = fadd fast float %1077, %22
  %1079 = fmul fast float %1066, %33
  %1080 = call float @dx.op.tertiary.f32(i32 46, float %1067, float %29, float %1079)  ; FMad(a,b,c)
  %1081 = call float @dx.op.tertiary.f32(i32 46, float %82, float %25, float %1080)  ; FMad(a,b,c)
  %1082 = fadd fast float %1081, %21
  %1083 = fmul fast float %1066, %32
  %1084 = call float @dx.op.tertiary.f32(i32 46, float %1067, float %28, float %1083)  ; FMad(a,b,c)
  %1085 = call float @dx.op.tertiary.f32(i32 46, float %82, float %24, float %1084)  ; FMad(a,b,c)
  %1086 = fadd fast float %1085, %20
  %1087 = fdiv fast float %1086, %1071
  %1088 = fdiv fast float %1082, %1071
  %1089 = fdiv fast float %1078, %1071
  %1090 = fsub fast float %1087, %17
  %1091 = fsub fast float %1088, %18
  %1092 = fsub fast float %1089, %19
  %1093 = fmul fast float %1090, %1090
  %1094 = fmul fast float %1091, %1091
  %1095 = fadd fast float %1094, %1093
  %1096 = fmul fast float %1092, %1092
  %1097 = fadd fast float %1095, %1096
  %1098 = call float @dx.op.unary.f32(i32 24, float %1097)  ; Sqrt(value)
  %1099 = fsub fast float %1098, %9
  %1100 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1099)  ; FMax(a,b)
  %1101 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1101, label %1102, label %1125

; <label>:1102                                    ; preds = %1074
  %1103 = call float @dx.op.unary.f32(i32 6, float %1091)  ; FAbs(value)
  %1104 = fmul fast float %1103, %11
  %1105 = fcmp fast olt float %1104, 0x3F50624DE0000000
  br i1 %1105, label %1106, label %1109

; <label>:1106                                    ; preds = %1102
  %1107 = fmul fast float %1104, 5.000000e-01
  %1108 = fsub fast float 1.000000e+00, %1107
  br label %1114

; <label>:1109                                    ; preds = %1102
  %1110 = fmul fast float %1104, 0xBFF7154760000000
  %1111 = call float @dx.op.unary.f32(i32 21, float %1110)  ; Exp(value)
  %1112 = fsub fast float 1.000000e+00, %1111
  %1113 = fdiv fast float %1112, %1104
  br label %1114

; <label>:1114                                    ; preds = %1109, %1106
  %1115 = phi float [ %1108, %1106 ], [ %1113, %1109 ]
  %1116 = call float @dx.op.binary.f32(i32 36, float %1088, float %18)  ; FMin(a,b)
  %1117 = fsub fast float %1116, %10
  %1118 = fmul fast float %11, %1117
  %1119 = fsub fast float -0.000000e+00, %1118
  %1120 = call float @dx.op.binary.f32(i32 35, float %1119, float -4.000000e+01)  ; FMax(a,b)
  %1121 = call float @dx.op.binary.f32(i32 36, float %1120, float 5.000000e+00)  ; FMin(a,b)
  %1122 = fmul fast float %1121, 0x3FF7154760000000
  %1123 = call float @dx.op.unary.f32(i32 21, float %1122)  ; Exp(value)
  %1124 = fmul fast float %1123, %1115
  br label %1125

; <label>:1125                                    ; preds = %1114, %1074
  %1126 = phi float [ %1124, %1114 ], [ 1.000000e+00, %1074 ]
  %1127 = fmul fast float %1100, %16
  %1128 = fmul fast float %1127, %1126
  %1129 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1128)  ; FMin(a,b)
  %1130 = fmul fast float %1129, 0xBFF7154760000000
  %1131 = call float @dx.op.unary.f32(i32 21, float %1130)  ; Exp(value)
  %1132 = fsub fast float 1.000000e+00, %1131
  %1133 = call float @dx.op.binary.f32(i32 36, float %12, float %1132)  ; FMin(a,b)
  %1134 = fsub fast float %13, %1013
  %1135 = fsub fast float %14, %1014
  %1136 = fsub fast float %15, %1015
  %1137 = fmul fast float %1133, %1134
  %1138 = fmul fast float %1133, %1135
  %1139 = fmul fast float %1133, %1136
  %1140 = fadd fast float %1137, %1013
  %1141 = fadd fast float %1138, %1014
  %1142 = fadd fast float %1139, %1015
  br label %1143

; <label>:1143                                    ; preds = %1125, %1057, %1053
  %1144 = phi float [ %1140, %1125 ], [ %1013, %1057 ], [ %1013, %1053 ]
  %1145 = phi float [ %1141, %1125 ], [ %1014, %1057 ], [ %1014, %1053 ]
  %1146 = phi float [ %1142, %1125 ], [ %1015, %1057 ], [ %1015, %1053 ]
  %1147 = fadd fast float %5, 1.000000e+00
  %1148 = fadd fast float %6, 1.000000e+00
  %1149 = fsub fast float 1.000000e+00, %5
  %1150 = fmul fast float %36, %1147
  %1151 = fmul fast float %36, %1148
  %1152 = fmul fast float %36, %1149
  %1153 = fmul fast float %1150, %1144
  %1154 = fmul fast float %1151, %1145
  %1155 = fmul fast float %1152, %1146
  %1156 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1156, label %1182, label %1157

; <label>:1157                                    ; preds = %1143
  %1158 = fmul fast float %1153, 0x4004147AE0000000
  %1159 = fmul fast float %1154, 0x4004147AE0000000
  %1160 = fmul fast float %1155, 0x4004147AE0000000
  %1161 = fadd fast float %1158, 0x3F9EB851E0000000
  %1162 = fadd fast float %1159, 0x3F9EB851E0000000
  %1163 = fadd fast float %1160, 0x3F9EB851E0000000
  %1164 = fmul fast float %1161, %1153
  %1165 = fmul fast float %1162, %1154
  %1166 = fmul fast float %1163, %1155
  %1167 = fmul fast float %1153, 0x400370A3E0000000
  %1168 = fmul fast float %1154, 0x400370A3E0000000
  %1169 = fmul fast float %1155, 0x400370A3E0000000
  %1170 = fadd fast float %1167, 0x3FE2E147A0000000
  %1171 = fadd fast float %1168, 0x3FE2E147A0000000
  %1172 = fadd fast float %1169, 0x3FE2E147A0000000
  %1173 = fmul fast float %1170, %1153
  %1174 = fmul fast float %1171, %1154
  %1175 = fmul fast float %1172, %1155
  %1176 = fadd fast float %1173, 0x3FC1EB8520000000
  %1177 = fadd fast float %1174, 0x3FC1EB8520000000
  %1178 = fadd fast float %1175, 0x3FC1EB8520000000
  %1179 = fdiv fast float %1164, %1176
  %1180 = fdiv fast float %1165, %1177
  %1181 = fdiv fast float %1166, %1178
  br label %1182

; <label>:1182                                    ; preds = %1157, %1143
  %1183 = phi float [ %1179, %1157 ], [ %1153, %1143 ]
  %1184 = phi float [ %1180, %1157 ], [ %1154, %1143 ]
  %1185 = phi float [ %1181, %1157 ], [ %1155, %1143 ]
  %1186 = call float @dx.op.unary.f32(i32 7, float %1183)  ; Saturate(value)
  %1187 = call float @dx.op.unary.f32(i32 7, float %1184)  ; Saturate(value)
  %1188 = call float @dx.op.unary.f32(i32 7, float %1185)  ; Saturate(value)
  %1189 = call float @dx.op.dot3.f32(i32 55, float %1186, float %1187, float %1188, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1190 = fsub fast float %1186, %1189
  %1191 = fsub fast float %1187, %1189
  %1192 = fsub fast float %1188, %1189
  %1193 = fmul fast float %1190, %8
  %1194 = fmul fast float %1191, %8
  %1195 = fmul fast float %1192, %8
  %1196 = fadd fast float %1193, %1189
  %1197 = fadd fast float %1194, %1189
  %1198 = fadd fast float %1195, %1189
  %1199 = call float @dx.op.unary.f32(i32 7, float %1196)  ; Saturate(value)
  %1200 = call float @dx.op.unary.f32(i32 7, float %1197)  ; Saturate(value)
  %1201 = call float @dx.op.unary.f32(i32 7, float %1198)  ; Saturate(value)
  %1202 = fadd fast float %1199, 0xBFC70A3D80000000
  %1203 = fadd fast float %1200, 0xBFC70A3D80000000
  %1204 = fadd fast float %1201, 0xBFC70A3D80000000
  %1205 = fmul fast float %1202, %7
  %1206 = fmul fast float %1203, %7
  %1207 = fmul fast float %1204, %7
  %1208 = fadd fast float %1205, 0x3FC70A3D80000000
  %1209 = fadd fast float %1206, 0x3FC70A3D80000000
  %1210 = fadd fast float %1207, 0x3FC70A3D80000000
  %1211 = call float @dx.op.unary.f32(i32 7, float %1208)  ; Saturate(value)
  %1212 = call float @dx.op.unary.f32(i32 7, float %1209)  ; Saturate(value)
  %1213 = call float @dx.op.unary.f32(i32 7, float %1210)  ; Saturate(value)
  br label %1214

; <label>:1214                                    ; preds = %1182, %1018
  %1215 = phi float [ %1049, %1018 ], [ %1211, %1182 ]
  %1216 = phi float [ %1050, %1018 ], [ %1212, %1182 ]
  %1217 = phi float [ %1051, %1018 ], [ %1213, %1182 ]
  %1218 = phi float [ %1052, %1018 ], [ %1016, %1182 ]
  %1219 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %67, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1220 = extractvalue %dx.types.ResRet.f32 %1219, 0
  %1221 = extractvalue %dx.types.ResRet.f32 %1219, 1
  %1222 = extractvalue %dx.types.ResRet.f32 %1219, 2
  %1223 = extractvalue %dx.types.ResRet.f32 %1219, 3
  %1224 = fcmp fast olt float %1223, 0.000000e+00
  br i1 %1224, label %1225, label %1260

; <label>:1225                                    ; preds = %1214
  %1226 = fcmp fast ogt float %1220, 0x3FA4B5DCC0000000
  %1227 = fcmp fast ogt float %1221, 0x3FA4B5DCC0000000
  %1228 = fcmp fast ogt float %1222, 0x3FA4B5DCC0000000
  %1229 = select i1 %1226, float 0.000000e+00, float 1.000000e+00
  %1230 = select i1 %1227, float 0.000000e+00, float 1.000000e+00
  %1231 = select i1 %1228, float 0.000000e+00, float 1.000000e+00
  %1232 = fmul fast float %1220, 0x3FB3D07220000000
  %1233 = fmul fast float %1221, 0x3FB3D07220000000
  %1234 = fmul fast float %1222, 0x3FB3D07220000000
  %1235 = fadd fast float %1220, 0x3FAC28F5C0000000
  %1236 = fadd fast float %1221, 0x3FAC28F5C0000000
  %1237 = fadd fast float %1222, 0x3FAC28F5C0000000
  %1238 = fmul fast float %1235, 0x3FEE54EDE0000000
  %1239 = fmul fast float %1236, 0x3FEE54EDE0000000
  %1240 = fmul fast float %1237, 0x3FEE54EDE0000000
  %1241 = call float @dx.op.unary.f32(i32 23, float %1238)  ; Log(value)
  %1242 = call float @dx.op.unary.f32(i32 23, float %1239)  ; Log(value)
  %1243 = call float @dx.op.unary.f32(i32 23, float %1240)  ; Log(value)
  %1244 = fmul fast float %1241, 0x4003333340000000
  %1245 = fmul fast float %1242, 0x4003333340000000
  %1246 = fmul fast float %1243, 0x4003333340000000
  %1247 = call float @dx.op.unary.f32(i32 21, float %1244)  ; Exp(value)
  %1248 = call float @dx.op.unary.f32(i32 21, float %1245)  ; Exp(value)
  %1249 = call float @dx.op.unary.f32(i32 21, float %1246)  ; Exp(value)
  %1250 = fsub fast float %1232, %1247
  %1251 = fsub fast float %1233, %1248
  %1252 = fsub fast float %1234, %1249
  %1253 = fmul fast float %1250, %1229
  %1254 = fmul fast float %1251, %1230
  %1255 = fmul fast float %1252, %1231
  %1256 = fadd fast float %1253, %1247
  %1257 = fadd fast float %1254, %1248
  %1258 = fadd fast float %1255, %1249
  %1259 = fsub fast float -1.000000e+00, %1223
  br label %1421

; <label>:1260                                    ; preds = %1214
  %1261 = fcmp fast ogt float %38, 5.000000e-01
  %1262 = fcmp fast olt float %84, 1.000000e+00
  %1263 = and i1 %1261, %1262
  br i1 %1263, label %1264, label %1350

; <label>:1264                                    ; preds = %1260
  %1265 = sitofp i32 %67 to float
  %1266 = sitofp i32 %64 to float
  %1267 = fadd fast float %1265, 5.000000e-01
  %1268 = fadd fast float %1266, 5.000000e-01
  %1269 = fdiv fast float %1267, %45
  %1270 = fdiv fast float %1268, %46
  %1271 = fmul fast float %1269, 2.000000e+00
  %1272 = fmul fast float %1270, 2.000000e+00
  %1273 = fadd fast float %1271, -1.000000e+00
  %1274 = fsub fast float 1.000000e+00, %1272
  %1275 = fmul fast float %1273, %35
  %1276 = call float @dx.op.tertiary.f32(i32 46, float %1274, float %31, float %1275)  ; FMad(a,b,c)
  %1277 = call float @dx.op.tertiary.f32(i32 46, float %84, float %27, float %1276)  ; FMad(a,b,c)
  %1278 = fadd fast float %1277, %23
  %1279 = call float @dx.op.unary.f32(i32 6, float %1278)  ; FAbs(value)
  %1280 = fcmp fast ogt float %1279, 0x3EB0C6F7A0000000
  br i1 %1280, label %1281, label %1350

; <label>:1281                                    ; preds = %1264
  %1282 = fmul fast float %1273, %34
  %1283 = call float @dx.op.tertiary.f32(i32 46, float %1274, float %30, float %1282)  ; FMad(a,b,c)
  %1284 = call float @dx.op.tertiary.f32(i32 46, float %84, float %26, float %1283)  ; FMad(a,b,c)
  %1285 = fadd fast float %1284, %22
  %1286 = fmul fast float %1273, %33
  %1287 = call float @dx.op.tertiary.f32(i32 46, float %1274, float %29, float %1286)  ; FMad(a,b,c)
  %1288 = call float @dx.op.tertiary.f32(i32 46, float %84, float %25, float %1287)  ; FMad(a,b,c)
  %1289 = fadd fast float %1288, %21
  %1290 = fmul fast float %1273, %32
  %1291 = call float @dx.op.tertiary.f32(i32 46, float %1274, float %28, float %1290)  ; FMad(a,b,c)
  %1292 = call float @dx.op.tertiary.f32(i32 46, float %84, float %24, float %1291)  ; FMad(a,b,c)
  %1293 = fadd fast float %1292, %20
  %1294 = fdiv fast float %1293, %1278
  %1295 = fdiv fast float %1289, %1278
  %1296 = fdiv fast float %1285, %1278
  %1297 = fsub fast float %1294, %17
  %1298 = fsub fast float %1295, %18
  %1299 = fsub fast float %1296, %19
  %1300 = fmul fast float %1297, %1297
  %1301 = fmul fast float %1298, %1298
  %1302 = fadd fast float %1301, %1300
  %1303 = fmul fast float %1299, %1299
  %1304 = fadd fast float %1302, %1303
  %1305 = call float @dx.op.unary.f32(i32 24, float %1304)  ; Sqrt(value)
  %1306 = fsub fast float %1305, %9
  %1307 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1306)  ; FMax(a,b)
  %1308 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1308, label %1309, label %1332

; <label>:1309                                    ; preds = %1281
  %1310 = call float @dx.op.unary.f32(i32 6, float %1298)  ; FAbs(value)
  %1311 = fmul fast float %1310, %11
  %1312 = fcmp fast olt float %1311, 0x3F50624DE0000000
  br i1 %1312, label %1313, label %1316

; <label>:1313                                    ; preds = %1309
  %1314 = fmul fast float %1311, 5.000000e-01
  %1315 = fsub fast float 1.000000e+00, %1314
  br label %1321

; <label>:1316                                    ; preds = %1309
  %1317 = fmul fast float %1311, 0xBFF7154760000000
  %1318 = call float @dx.op.unary.f32(i32 21, float %1317)  ; Exp(value)
  %1319 = fsub fast float 1.000000e+00, %1318
  %1320 = fdiv fast float %1319, %1311
  br label %1321

; <label>:1321                                    ; preds = %1316, %1313
  %1322 = phi float [ %1315, %1313 ], [ %1320, %1316 ]
  %1323 = call float @dx.op.binary.f32(i32 36, float %1295, float %18)  ; FMin(a,b)
  %1324 = fsub fast float %1323, %10
  %1325 = fmul fast float %11, %1324
  %1326 = fsub fast float -0.000000e+00, %1325
  %1327 = call float @dx.op.binary.f32(i32 35, float %1326, float -4.000000e+01)  ; FMax(a,b)
  %1328 = call float @dx.op.binary.f32(i32 36, float %1327, float 5.000000e+00)  ; FMin(a,b)
  %1329 = fmul fast float %1328, 0x3FF7154760000000
  %1330 = call float @dx.op.unary.f32(i32 21, float %1329)  ; Exp(value)
  %1331 = fmul fast float %1330, %1322
  br label %1332

; <label>:1332                                    ; preds = %1321, %1281
  %1333 = phi float [ %1331, %1321 ], [ 1.000000e+00, %1281 ]
  %1334 = fmul fast float %1307, %16
  %1335 = fmul fast float %1334, %1333
  %1336 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1335)  ; FMin(a,b)
  %1337 = fmul fast float %1336, 0xBFF7154760000000
  %1338 = call float @dx.op.unary.f32(i32 21, float %1337)  ; Exp(value)
  %1339 = fsub fast float 1.000000e+00, %1338
  %1340 = call float @dx.op.binary.f32(i32 36, float %12, float %1339)  ; FMin(a,b)
  %1341 = fsub fast float %13, %1220
  %1342 = fsub fast float %14, %1221
  %1343 = fsub fast float %15, %1222
  %1344 = fmul fast float %1340, %1341
  %1345 = fmul fast float %1340, %1342
  %1346 = fmul fast float %1340, %1343
  %1347 = fadd fast float %1344, %1220
  %1348 = fadd fast float %1345, %1221
  %1349 = fadd fast float %1346, %1222
  br label %1350

; <label>:1350                                    ; preds = %1332, %1264, %1260
  %1351 = phi float [ %1347, %1332 ], [ %1220, %1264 ], [ %1220, %1260 ]
  %1352 = phi float [ %1348, %1332 ], [ %1221, %1264 ], [ %1221, %1260 ]
  %1353 = phi float [ %1349, %1332 ], [ %1222, %1264 ], [ %1222, %1260 ]
  %1354 = fadd fast float %5, 1.000000e+00
  %1355 = fadd fast float %6, 1.000000e+00
  %1356 = fsub fast float 1.000000e+00, %5
  %1357 = fmul fast float %36, %1354
  %1358 = fmul fast float %36, %1355
  %1359 = fmul fast float %36, %1356
  %1360 = fmul fast float %1357, %1351
  %1361 = fmul fast float %1358, %1352
  %1362 = fmul fast float %1359, %1353
  %1363 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1363, label %1389, label %1364

; <label>:1364                                    ; preds = %1350
  %1365 = fmul fast float %1360, 0x4004147AE0000000
  %1366 = fmul fast float %1361, 0x4004147AE0000000
  %1367 = fmul fast float %1362, 0x4004147AE0000000
  %1368 = fadd fast float %1365, 0x3F9EB851E0000000
  %1369 = fadd fast float %1366, 0x3F9EB851E0000000
  %1370 = fadd fast float %1367, 0x3F9EB851E0000000
  %1371 = fmul fast float %1368, %1360
  %1372 = fmul fast float %1369, %1361
  %1373 = fmul fast float %1370, %1362
  %1374 = fmul fast float %1360, 0x400370A3E0000000
  %1375 = fmul fast float %1361, 0x400370A3E0000000
  %1376 = fmul fast float %1362, 0x400370A3E0000000
  %1377 = fadd fast float %1374, 0x3FE2E147A0000000
  %1378 = fadd fast float %1375, 0x3FE2E147A0000000
  %1379 = fadd fast float %1376, 0x3FE2E147A0000000
  %1380 = fmul fast float %1377, %1360
  %1381 = fmul fast float %1378, %1361
  %1382 = fmul fast float %1379, %1362
  %1383 = fadd fast float %1380, 0x3FC1EB8520000000
  %1384 = fadd fast float %1381, 0x3FC1EB8520000000
  %1385 = fadd fast float %1382, 0x3FC1EB8520000000
  %1386 = fdiv fast float %1371, %1383
  %1387 = fdiv fast float %1372, %1384
  %1388 = fdiv fast float %1373, %1385
  br label %1389

; <label>:1389                                    ; preds = %1364, %1350
  %1390 = phi float [ %1386, %1364 ], [ %1360, %1350 ]
  %1391 = phi float [ %1387, %1364 ], [ %1361, %1350 ]
  %1392 = phi float [ %1388, %1364 ], [ %1362, %1350 ]
  %1393 = call float @dx.op.unary.f32(i32 7, float %1390)  ; Saturate(value)
  %1394 = call float @dx.op.unary.f32(i32 7, float %1391)  ; Saturate(value)
  %1395 = call float @dx.op.unary.f32(i32 7, float %1392)  ; Saturate(value)
  %1396 = call float @dx.op.dot3.f32(i32 55, float %1393, float %1394, float %1395, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1397 = fsub fast float %1393, %1396
  %1398 = fsub fast float %1394, %1396
  %1399 = fsub fast float %1395, %1396
  %1400 = fmul fast float %1397, %8
  %1401 = fmul fast float %1398, %8
  %1402 = fmul fast float %1399, %8
  %1403 = fadd fast float %1400, %1396
  %1404 = fadd fast float %1401, %1396
  %1405 = fadd fast float %1402, %1396
  %1406 = call float @dx.op.unary.f32(i32 7, float %1403)  ; Saturate(value)
  %1407 = call float @dx.op.unary.f32(i32 7, float %1404)  ; Saturate(value)
  %1408 = call float @dx.op.unary.f32(i32 7, float %1405)  ; Saturate(value)
  %1409 = fadd fast float %1406, 0xBFC70A3D80000000
  %1410 = fadd fast float %1407, 0xBFC70A3D80000000
  %1411 = fadd fast float %1408, 0xBFC70A3D80000000
  %1412 = fmul fast float %1409, %7
  %1413 = fmul fast float %1410, %7
  %1414 = fmul fast float %1411, %7
  %1415 = fadd fast float %1412, 0x3FC70A3D80000000
  %1416 = fadd fast float %1413, 0x3FC70A3D80000000
  %1417 = fadd fast float %1414, 0x3FC70A3D80000000
  %1418 = call float @dx.op.unary.f32(i32 7, float %1415)  ; Saturate(value)
  %1419 = call float @dx.op.unary.f32(i32 7, float %1416)  ; Saturate(value)
  %1420 = call float @dx.op.unary.f32(i32 7, float %1417)  ; Saturate(value)
  br label %1421

; <label>:1421                                    ; preds = %1389, %1225
  %1422 = phi float [ %1256, %1225 ], [ %1418, %1389 ]
  %1423 = phi float [ %1257, %1225 ], [ %1419, %1389 ]
  %1424 = phi float [ %1258, %1225 ], [ %1420, %1389 ]
  %1425 = phi float [ %1259, %1225 ], [ %1223, %1389 ]
  %1426 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %63, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1427 = extractvalue %dx.types.ResRet.f32 %1426, 0
  %1428 = extractvalue %dx.types.ResRet.f32 %1426, 1
  %1429 = extractvalue %dx.types.ResRet.f32 %1426, 2
  %1430 = extractvalue %dx.types.ResRet.f32 %1426, 3
  %1431 = fcmp fast olt float %1430, 0.000000e+00
  br i1 %1431, label %1432, label %1467

; <label>:1432                                    ; preds = %1421
  %1433 = fcmp fast ogt float %1427, 0x3FA4B5DCC0000000
  %1434 = fcmp fast ogt float %1428, 0x3FA4B5DCC0000000
  %1435 = fcmp fast ogt float %1429, 0x3FA4B5DCC0000000
  %1436 = select i1 %1433, float 0.000000e+00, float 1.000000e+00
  %1437 = select i1 %1434, float 0.000000e+00, float 1.000000e+00
  %1438 = select i1 %1435, float 0.000000e+00, float 1.000000e+00
  %1439 = fmul fast float %1427, 0x3FB3D07220000000
  %1440 = fmul fast float %1428, 0x3FB3D07220000000
  %1441 = fmul fast float %1429, 0x3FB3D07220000000
  %1442 = fadd fast float %1427, 0x3FAC28F5C0000000
  %1443 = fadd fast float %1428, 0x3FAC28F5C0000000
  %1444 = fadd fast float %1429, 0x3FAC28F5C0000000
  %1445 = fmul fast float %1442, 0x3FEE54EDE0000000
  %1446 = fmul fast float %1443, 0x3FEE54EDE0000000
  %1447 = fmul fast float %1444, 0x3FEE54EDE0000000
  %1448 = call float @dx.op.unary.f32(i32 23, float %1445)  ; Log(value)
  %1449 = call float @dx.op.unary.f32(i32 23, float %1446)  ; Log(value)
  %1450 = call float @dx.op.unary.f32(i32 23, float %1447)  ; Log(value)
  %1451 = fmul fast float %1448, 0x4003333340000000
  %1452 = fmul fast float %1449, 0x4003333340000000
  %1453 = fmul fast float %1450, 0x4003333340000000
  %1454 = call float @dx.op.unary.f32(i32 21, float %1451)  ; Exp(value)
  %1455 = call float @dx.op.unary.f32(i32 21, float %1452)  ; Exp(value)
  %1456 = call float @dx.op.unary.f32(i32 21, float %1453)  ; Exp(value)
  %1457 = fsub fast float %1439, %1454
  %1458 = fsub fast float %1440, %1455
  %1459 = fsub fast float %1441, %1456
  %1460 = fmul fast float %1457, %1436
  %1461 = fmul fast float %1458, %1437
  %1462 = fmul fast float %1459, %1438
  %1463 = fadd fast float %1460, %1454
  %1464 = fadd fast float %1461, %1455
  %1465 = fadd fast float %1462, %1456
  %1466 = fsub fast float -1.000000e+00, %1430
  br label %1628

; <label>:1467                                    ; preds = %1421
  %1468 = fcmp fast ogt float %38, 5.000000e-01
  %1469 = fcmp fast olt float %86, 1.000000e+00
  %1470 = and i1 %1468, %1469
  br i1 %1470, label %1471, label %1557

; <label>:1471                                    ; preds = %1467
  %1472 = sitofp i32 %63 to float
  %1473 = sitofp i32 %70 to float
  %1474 = fadd fast float %1472, 5.000000e-01
  %1475 = fadd fast float %1473, 5.000000e-01
  %1476 = fdiv fast float %1474, %45
  %1477 = fdiv fast float %1475, %46
  %1478 = fmul fast float %1476, 2.000000e+00
  %1479 = fmul fast float %1477, 2.000000e+00
  %1480 = fadd fast float %1478, -1.000000e+00
  %1481 = fsub fast float 1.000000e+00, %1479
  %1482 = fmul fast float %1480, %35
  %1483 = call float @dx.op.tertiary.f32(i32 46, float %1481, float %31, float %1482)  ; FMad(a,b,c)
  %1484 = call float @dx.op.tertiary.f32(i32 46, float %86, float %27, float %1483)  ; FMad(a,b,c)
  %1485 = fadd fast float %1484, %23
  %1486 = call float @dx.op.unary.f32(i32 6, float %1485)  ; FAbs(value)
  %1487 = fcmp fast ogt float %1486, 0x3EB0C6F7A0000000
  br i1 %1487, label %1488, label %1557

; <label>:1488                                    ; preds = %1471
  %1489 = fmul fast float %1480, %34
  %1490 = call float @dx.op.tertiary.f32(i32 46, float %1481, float %30, float %1489)  ; FMad(a,b,c)
  %1491 = call float @dx.op.tertiary.f32(i32 46, float %86, float %26, float %1490)  ; FMad(a,b,c)
  %1492 = fadd fast float %1491, %22
  %1493 = fmul fast float %1480, %33
  %1494 = call float @dx.op.tertiary.f32(i32 46, float %1481, float %29, float %1493)  ; FMad(a,b,c)
  %1495 = call float @dx.op.tertiary.f32(i32 46, float %86, float %25, float %1494)  ; FMad(a,b,c)
  %1496 = fadd fast float %1495, %21
  %1497 = fmul fast float %1480, %32
  %1498 = call float @dx.op.tertiary.f32(i32 46, float %1481, float %28, float %1497)  ; FMad(a,b,c)
  %1499 = call float @dx.op.tertiary.f32(i32 46, float %86, float %24, float %1498)  ; FMad(a,b,c)
  %1500 = fadd fast float %1499, %20
  %1501 = fdiv fast float %1500, %1485
  %1502 = fdiv fast float %1496, %1485
  %1503 = fdiv fast float %1492, %1485
  %1504 = fsub fast float %1501, %17
  %1505 = fsub fast float %1502, %18
  %1506 = fsub fast float %1503, %19
  %1507 = fmul fast float %1504, %1504
  %1508 = fmul fast float %1505, %1505
  %1509 = fadd fast float %1508, %1507
  %1510 = fmul fast float %1506, %1506
  %1511 = fadd fast float %1509, %1510
  %1512 = call float @dx.op.unary.f32(i32 24, float %1511)  ; Sqrt(value)
  %1513 = fsub fast float %1512, %9
  %1514 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1513)  ; FMax(a,b)
  %1515 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1515, label %1516, label %1539

; <label>:1516                                    ; preds = %1488
  %1517 = call float @dx.op.unary.f32(i32 6, float %1505)  ; FAbs(value)
  %1518 = fmul fast float %1517, %11
  %1519 = fcmp fast olt float %1518, 0x3F50624DE0000000
  br i1 %1519, label %1520, label %1523

; <label>:1520                                    ; preds = %1516
  %1521 = fmul fast float %1518, 5.000000e-01
  %1522 = fsub fast float 1.000000e+00, %1521
  br label %1528

; <label>:1523                                    ; preds = %1516
  %1524 = fmul fast float %1518, 0xBFF7154760000000
  %1525 = call float @dx.op.unary.f32(i32 21, float %1524)  ; Exp(value)
  %1526 = fsub fast float 1.000000e+00, %1525
  %1527 = fdiv fast float %1526, %1518
  br label %1528

; <label>:1528                                    ; preds = %1523, %1520
  %1529 = phi float [ %1522, %1520 ], [ %1527, %1523 ]
  %1530 = call float @dx.op.binary.f32(i32 36, float %1502, float %18)  ; FMin(a,b)
  %1531 = fsub fast float %1530, %10
  %1532 = fmul fast float %11, %1531
  %1533 = fsub fast float -0.000000e+00, %1532
  %1534 = call float @dx.op.binary.f32(i32 35, float %1533, float -4.000000e+01)  ; FMax(a,b)
  %1535 = call float @dx.op.binary.f32(i32 36, float %1534, float 5.000000e+00)  ; FMin(a,b)
  %1536 = fmul fast float %1535, 0x3FF7154760000000
  %1537 = call float @dx.op.unary.f32(i32 21, float %1536)  ; Exp(value)
  %1538 = fmul fast float %1537, %1529
  br label %1539

; <label>:1539                                    ; preds = %1528, %1488
  %1540 = phi float [ %1538, %1528 ], [ 1.000000e+00, %1488 ]
  %1541 = fmul fast float %1514, %16
  %1542 = fmul fast float %1541, %1540
  %1543 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1542)  ; FMin(a,b)
  %1544 = fmul fast float %1543, 0xBFF7154760000000
  %1545 = call float @dx.op.unary.f32(i32 21, float %1544)  ; Exp(value)
  %1546 = fsub fast float 1.000000e+00, %1545
  %1547 = call float @dx.op.binary.f32(i32 36, float %12, float %1546)  ; FMin(a,b)
  %1548 = fsub fast float %13, %1427
  %1549 = fsub fast float %14, %1428
  %1550 = fsub fast float %15, %1429
  %1551 = fmul fast float %1547, %1548
  %1552 = fmul fast float %1547, %1549
  %1553 = fmul fast float %1547, %1550
  %1554 = fadd fast float %1551, %1427
  %1555 = fadd fast float %1552, %1428
  %1556 = fadd fast float %1553, %1429
  br label %1557

; <label>:1557                                    ; preds = %1539, %1471, %1467
  %1558 = phi float [ %1554, %1539 ], [ %1427, %1471 ], [ %1427, %1467 ]
  %1559 = phi float [ %1555, %1539 ], [ %1428, %1471 ], [ %1428, %1467 ]
  %1560 = phi float [ %1556, %1539 ], [ %1429, %1471 ], [ %1429, %1467 ]
  %1561 = fadd fast float %5, 1.000000e+00
  %1562 = fadd fast float %6, 1.000000e+00
  %1563 = fsub fast float 1.000000e+00, %5
  %1564 = fmul fast float %36, %1561
  %1565 = fmul fast float %36, %1562
  %1566 = fmul fast float %36, %1563
  %1567 = fmul fast float %1564, %1558
  %1568 = fmul fast float %1565, %1559
  %1569 = fmul fast float %1566, %1560
  %1570 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1570, label %1596, label %1571

; <label>:1571                                    ; preds = %1557
  %1572 = fmul fast float %1567, 0x4004147AE0000000
  %1573 = fmul fast float %1568, 0x4004147AE0000000
  %1574 = fmul fast float %1569, 0x4004147AE0000000
  %1575 = fadd fast float %1572, 0x3F9EB851E0000000
  %1576 = fadd fast float %1573, 0x3F9EB851E0000000
  %1577 = fadd fast float %1574, 0x3F9EB851E0000000
  %1578 = fmul fast float %1575, %1567
  %1579 = fmul fast float %1576, %1568
  %1580 = fmul fast float %1577, %1569
  %1581 = fmul fast float %1567, 0x400370A3E0000000
  %1582 = fmul fast float %1568, 0x400370A3E0000000
  %1583 = fmul fast float %1569, 0x400370A3E0000000
  %1584 = fadd fast float %1581, 0x3FE2E147A0000000
  %1585 = fadd fast float %1582, 0x3FE2E147A0000000
  %1586 = fadd fast float %1583, 0x3FE2E147A0000000
  %1587 = fmul fast float %1584, %1567
  %1588 = fmul fast float %1585, %1568
  %1589 = fmul fast float %1586, %1569
  %1590 = fadd fast float %1587, 0x3FC1EB8520000000
  %1591 = fadd fast float %1588, 0x3FC1EB8520000000
  %1592 = fadd fast float %1589, 0x3FC1EB8520000000
  %1593 = fdiv fast float %1578, %1590
  %1594 = fdiv fast float %1579, %1591
  %1595 = fdiv fast float %1580, %1592
  br label %1596

; <label>:1596                                    ; preds = %1571, %1557
  %1597 = phi float [ %1593, %1571 ], [ %1567, %1557 ]
  %1598 = phi float [ %1594, %1571 ], [ %1568, %1557 ]
  %1599 = phi float [ %1595, %1571 ], [ %1569, %1557 ]
  %1600 = call float @dx.op.unary.f32(i32 7, float %1597)  ; Saturate(value)
  %1601 = call float @dx.op.unary.f32(i32 7, float %1598)  ; Saturate(value)
  %1602 = call float @dx.op.unary.f32(i32 7, float %1599)  ; Saturate(value)
  %1603 = call float @dx.op.dot3.f32(i32 55, float %1600, float %1601, float %1602, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1604 = fsub fast float %1600, %1603
  %1605 = fsub fast float %1601, %1603
  %1606 = fsub fast float %1602, %1603
  %1607 = fmul fast float %1604, %8
  %1608 = fmul fast float %1605, %8
  %1609 = fmul fast float %1606, %8
  %1610 = fadd fast float %1607, %1603
  %1611 = fadd fast float %1608, %1603
  %1612 = fadd fast float %1609, %1603
  %1613 = call float @dx.op.unary.f32(i32 7, float %1610)  ; Saturate(value)
  %1614 = call float @dx.op.unary.f32(i32 7, float %1611)  ; Saturate(value)
  %1615 = call float @dx.op.unary.f32(i32 7, float %1612)  ; Saturate(value)
  %1616 = fadd fast float %1613, 0xBFC70A3D80000000
  %1617 = fadd fast float %1614, 0xBFC70A3D80000000
  %1618 = fadd fast float %1615, 0xBFC70A3D80000000
  %1619 = fmul fast float %1616, %7
  %1620 = fmul fast float %1617, %7
  %1621 = fmul fast float %1618, %7
  %1622 = fadd fast float %1619, 0x3FC70A3D80000000
  %1623 = fadd fast float %1620, 0x3FC70A3D80000000
  %1624 = fadd fast float %1621, 0x3FC70A3D80000000
  %1625 = call float @dx.op.unary.f32(i32 7, float %1622)  ; Saturate(value)
  %1626 = call float @dx.op.unary.f32(i32 7, float %1623)  ; Saturate(value)
  %1627 = call float @dx.op.unary.f32(i32 7, float %1624)  ; Saturate(value)
  br label %1628

; <label>:1628                                    ; preds = %1596, %1432
  %1629 = phi float [ %1463, %1432 ], [ %1625, %1596 ]
  %1630 = phi float [ %1464, %1432 ], [ %1626, %1596 ]
  %1631 = phi float [ %1465, %1432 ], [ %1627, %1596 ]
  %1632 = phi float [ %1466, %1432 ], [ %1430, %1596 ]
  %1633 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %67, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1634 = extractvalue %dx.types.ResRet.f32 %1633, 0
  %1635 = extractvalue %dx.types.ResRet.f32 %1633, 1
  %1636 = extractvalue %dx.types.ResRet.f32 %1633, 2
  %1637 = extractvalue %dx.types.ResRet.f32 %1633, 3
  %1638 = fcmp fast olt float %1637, 0.000000e+00
  br i1 %1638, label %1639, label %1674

; <label>:1639                                    ; preds = %1628
  %1640 = fcmp fast ogt float %1634, 0x3FA4B5DCC0000000
  %1641 = fcmp fast ogt float %1635, 0x3FA4B5DCC0000000
  %1642 = fcmp fast ogt float %1636, 0x3FA4B5DCC0000000
  %1643 = select i1 %1640, float 0.000000e+00, float 1.000000e+00
  %1644 = select i1 %1641, float 0.000000e+00, float 1.000000e+00
  %1645 = select i1 %1642, float 0.000000e+00, float 1.000000e+00
  %1646 = fmul fast float %1634, 0x3FB3D07220000000
  %1647 = fmul fast float %1635, 0x3FB3D07220000000
  %1648 = fmul fast float %1636, 0x3FB3D07220000000
  %1649 = fadd fast float %1634, 0x3FAC28F5C0000000
  %1650 = fadd fast float %1635, 0x3FAC28F5C0000000
  %1651 = fadd fast float %1636, 0x3FAC28F5C0000000
  %1652 = fmul fast float %1649, 0x3FEE54EDE0000000
  %1653 = fmul fast float %1650, 0x3FEE54EDE0000000
  %1654 = fmul fast float %1651, 0x3FEE54EDE0000000
  %1655 = call float @dx.op.unary.f32(i32 23, float %1652)  ; Log(value)
  %1656 = call float @dx.op.unary.f32(i32 23, float %1653)  ; Log(value)
  %1657 = call float @dx.op.unary.f32(i32 23, float %1654)  ; Log(value)
  %1658 = fmul fast float %1655, 0x4003333340000000
  %1659 = fmul fast float %1656, 0x4003333340000000
  %1660 = fmul fast float %1657, 0x4003333340000000
  %1661 = call float @dx.op.unary.f32(i32 21, float %1658)  ; Exp(value)
  %1662 = call float @dx.op.unary.f32(i32 21, float %1659)  ; Exp(value)
  %1663 = call float @dx.op.unary.f32(i32 21, float %1660)  ; Exp(value)
  %1664 = fsub fast float %1646, %1661
  %1665 = fsub fast float %1647, %1662
  %1666 = fsub fast float %1648, %1663
  %1667 = fmul fast float %1664, %1643
  %1668 = fmul fast float %1665, %1644
  %1669 = fmul fast float %1666, %1645
  %1670 = fadd fast float %1667, %1661
  %1671 = fadd fast float %1668, %1662
  %1672 = fadd fast float %1669, %1663
  %1673 = fsub fast float -1.000000e+00, %1637
  br label %1835

; <label>:1674                                    ; preds = %1628
  %1675 = fcmp fast ogt float %38, 5.000000e-01
  %1676 = fcmp fast olt float %88, 1.000000e+00
  %1677 = and i1 %1675, %1676
  br i1 %1677, label %1678, label %1764

; <label>:1678                                    ; preds = %1674
  %1679 = sitofp i32 %67 to float
  %1680 = sitofp i32 %70 to float
  %1681 = fadd fast float %1679, 5.000000e-01
  %1682 = fadd fast float %1680, 5.000000e-01
  %1683 = fdiv fast float %1681, %45
  %1684 = fdiv fast float %1682, %46
  %1685 = fmul fast float %1683, 2.000000e+00
  %1686 = fmul fast float %1684, 2.000000e+00
  %1687 = fadd fast float %1685, -1.000000e+00
  %1688 = fsub fast float 1.000000e+00, %1686
  %1689 = fmul fast float %1687, %35
  %1690 = call float @dx.op.tertiary.f32(i32 46, float %1688, float %31, float %1689)  ; FMad(a,b,c)
  %1691 = call float @dx.op.tertiary.f32(i32 46, float %88, float %27, float %1690)  ; FMad(a,b,c)
  %1692 = fadd fast float %1691, %23
  %1693 = call float @dx.op.unary.f32(i32 6, float %1692)  ; FAbs(value)
  %1694 = fcmp fast ogt float %1693, 0x3EB0C6F7A0000000
  br i1 %1694, label %1695, label %1764

; <label>:1695                                    ; preds = %1678
  %1696 = fmul fast float %1687, %34
  %1697 = call float @dx.op.tertiary.f32(i32 46, float %1688, float %30, float %1696)  ; FMad(a,b,c)
  %1698 = call float @dx.op.tertiary.f32(i32 46, float %88, float %26, float %1697)  ; FMad(a,b,c)
  %1699 = fadd fast float %1698, %22
  %1700 = fmul fast float %1687, %33
  %1701 = call float @dx.op.tertiary.f32(i32 46, float %1688, float %29, float %1700)  ; FMad(a,b,c)
  %1702 = call float @dx.op.tertiary.f32(i32 46, float %88, float %25, float %1701)  ; FMad(a,b,c)
  %1703 = fadd fast float %1702, %21
  %1704 = fmul fast float %1687, %32
  %1705 = call float @dx.op.tertiary.f32(i32 46, float %1688, float %28, float %1704)  ; FMad(a,b,c)
  %1706 = call float @dx.op.tertiary.f32(i32 46, float %88, float %24, float %1705)  ; FMad(a,b,c)
  %1707 = fadd fast float %1706, %20
  %1708 = fdiv fast float %1707, %1692
  %1709 = fdiv fast float %1703, %1692
  %1710 = fdiv fast float %1699, %1692
  %1711 = fsub fast float %1708, %17
  %1712 = fsub fast float %1709, %18
  %1713 = fsub fast float %1710, %19
  %1714 = fmul fast float %1711, %1711
  %1715 = fmul fast float %1712, %1712
  %1716 = fadd fast float %1715, %1714
  %1717 = fmul fast float %1713, %1713
  %1718 = fadd fast float %1716, %1717
  %1719 = call float @dx.op.unary.f32(i32 24, float %1718)  ; Sqrt(value)
  %1720 = fsub fast float %1719, %9
  %1721 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1720)  ; FMax(a,b)
  %1722 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1722, label %1723, label %1746

; <label>:1723                                    ; preds = %1695
  %1724 = call float @dx.op.unary.f32(i32 6, float %1712)  ; FAbs(value)
  %1725 = fmul fast float %1724, %11
  %1726 = fcmp fast olt float %1725, 0x3F50624DE0000000
  br i1 %1726, label %1727, label %1730

; <label>:1727                                    ; preds = %1723
  %1728 = fmul fast float %1725, 5.000000e-01
  %1729 = fsub fast float 1.000000e+00, %1728
  br label %1735

; <label>:1730                                    ; preds = %1723
  %1731 = fmul fast float %1725, 0xBFF7154760000000
  %1732 = call float @dx.op.unary.f32(i32 21, float %1731)  ; Exp(value)
  %1733 = fsub fast float 1.000000e+00, %1732
  %1734 = fdiv fast float %1733, %1725
  br label %1735

; <label>:1735                                    ; preds = %1730, %1727
  %1736 = phi float [ %1729, %1727 ], [ %1734, %1730 ]
  %1737 = call float @dx.op.binary.f32(i32 36, float %1709, float %18)  ; FMin(a,b)
  %1738 = fsub fast float %1737, %10
  %1739 = fmul fast float %11, %1738
  %1740 = fsub fast float -0.000000e+00, %1739
  %1741 = call float @dx.op.binary.f32(i32 35, float %1740, float -4.000000e+01)  ; FMax(a,b)
  %1742 = call float @dx.op.binary.f32(i32 36, float %1741, float 5.000000e+00)  ; FMin(a,b)
  %1743 = fmul fast float %1742, 0x3FF7154760000000
  %1744 = call float @dx.op.unary.f32(i32 21, float %1743)  ; Exp(value)
  %1745 = fmul fast float %1744, %1736
  br label %1746

; <label>:1746                                    ; preds = %1735, %1695
  %1747 = phi float [ %1745, %1735 ], [ 1.000000e+00, %1695 ]
  %1748 = fmul fast float %1721, %16
  %1749 = fmul fast float %1748, %1747
  %1750 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1749)  ; FMin(a,b)
  %1751 = fmul fast float %1750, 0xBFF7154760000000
  %1752 = call float @dx.op.unary.f32(i32 21, float %1751)  ; Exp(value)
  %1753 = fsub fast float 1.000000e+00, %1752
  %1754 = call float @dx.op.binary.f32(i32 36, float %12, float %1753)  ; FMin(a,b)
  %1755 = fsub fast float %13, %1634
  %1756 = fsub fast float %14, %1635
  %1757 = fsub fast float %15, %1636
  %1758 = fmul fast float %1754, %1755
  %1759 = fmul fast float %1754, %1756
  %1760 = fmul fast float %1754, %1757
  %1761 = fadd fast float %1758, %1634
  %1762 = fadd fast float %1759, %1635
  %1763 = fadd fast float %1760, %1636
  br label %1764

; <label>:1764                                    ; preds = %1746, %1678, %1674
  %1765 = phi float [ %1761, %1746 ], [ %1634, %1678 ], [ %1634, %1674 ]
  %1766 = phi float [ %1762, %1746 ], [ %1635, %1678 ], [ %1635, %1674 ]
  %1767 = phi float [ %1763, %1746 ], [ %1636, %1678 ], [ %1636, %1674 ]
  %1768 = fadd fast float %5, 1.000000e+00
  %1769 = fadd fast float %6, 1.000000e+00
  %1770 = fsub fast float 1.000000e+00, %5
  %1771 = fmul fast float %36, %1768
  %1772 = fmul fast float %36, %1769
  %1773 = fmul fast float %36, %1770
  %1774 = fmul fast float %1771, %1765
  %1775 = fmul fast float %1772, %1766
  %1776 = fmul fast float %1773, %1767
  %1777 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1777, label %1803, label %1778

; <label>:1778                                    ; preds = %1764
  %1779 = fmul fast float %1774, 0x4004147AE0000000
  %1780 = fmul fast float %1775, 0x4004147AE0000000
  %1781 = fmul fast float %1776, 0x4004147AE0000000
  %1782 = fadd fast float %1779, 0x3F9EB851E0000000
  %1783 = fadd fast float %1780, 0x3F9EB851E0000000
  %1784 = fadd fast float %1781, 0x3F9EB851E0000000
  %1785 = fmul fast float %1782, %1774
  %1786 = fmul fast float %1783, %1775
  %1787 = fmul fast float %1784, %1776
  %1788 = fmul fast float %1774, 0x400370A3E0000000
  %1789 = fmul fast float %1775, 0x400370A3E0000000
  %1790 = fmul fast float %1776, 0x400370A3E0000000
  %1791 = fadd fast float %1788, 0x3FE2E147A0000000
  %1792 = fadd fast float %1789, 0x3FE2E147A0000000
  %1793 = fadd fast float %1790, 0x3FE2E147A0000000
  %1794 = fmul fast float %1791, %1774
  %1795 = fmul fast float %1792, %1775
  %1796 = fmul fast float %1793, %1776
  %1797 = fadd fast float %1794, 0x3FC1EB8520000000
  %1798 = fadd fast float %1795, 0x3FC1EB8520000000
  %1799 = fadd fast float %1796, 0x3FC1EB8520000000
  %1800 = fdiv fast float %1785, %1797
  %1801 = fdiv fast float %1786, %1798
  %1802 = fdiv fast float %1787, %1799
  br label %1803

; <label>:1803                                    ; preds = %1778, %1764
  %1804 = phi float [ %1800, %1778 ], [ %1774, %1764 ]
  %1805 = phi float [ %1801, %1778 ], [ %1775, %1764 ]
  %1806 = phi float [ %1802, %1778 ], [ %1776, %1764 ]
  %1807 = call float @dx.op.unary.f32(i32 7, float %1804)  ; Saturate(value)
  %1808 = call float @dx.op.unary.f32(i32 7, float %1805)  ; Saturate(value)
  %1809 = call float @dx.op.unary.f32(i32 7, float %1806)  ; Saturate(value)
  %1810 = call float @dx.op.dot3.f32(i32 55, float %1807, float %1808, float %1809, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1811 = fsub fast float %1807, %1810
  %1812 = fsub fast float %1808, %1810
  %1813 = fsub fast float %1809, %1810
  %1814 = fmul fast float %1811, %8
  %1815 = fmul fast float %1812, %8
  %1816 = fmul fast float %1813, %8
  %1817 = fadd fast float %1814, %1810
  %1818 = fadd fast float %1815, %1810
  %1819 = fadd fast float %1816, %1810
  %1820 = call float @dx.op.unary.f32(i32 7, float %1817)  ; Saturate(value)
  %1821 = call float @dx.op.unary.f32(i32 7, float %1818)  ; Saturate(value)
  %1822 = call float @dx.op.unary.f32(i32 7, float %1819)  ; Saturate(value)
  %1823 = fadd fast float %1820, 0xBFC70A3D80000000
  %1824 = fadd fast float %1821, 0xBFC70A3D80000000
  %1825 = fadd fast float %1822, 0xBFC70A3D80000000
  %1826 = fmul fast float %1823, %7
  %1827 = fmul fast float %1824, %7
  %1828 = fmul fast float %1825, %7
  %1829 = fadd fast float %1826, 0x3FC70A3D80000000
  %1830 = fadd fast float %1827, 0x3FC70A3D80000000
  %1831 = fadd fast float %1828, 0x3FC70A3D80000000
  %1832 = call float @dx.op.unary.f32(i32 7, float %1829)  ; Saturate(value)
  %1833 = call float @dx.op.unary.f32(i32 7, float %1830)  ; Saturate(value)
  %1834 = call float @dx.op.unary.f32(i32 7, float %1831)  ; Saturate(value)
  br label %1835

; <label>:1835                                    ; preds = %1803, %1639, %999
  %1836 = phi float [ %1215, %1639 ], [ %394, %999 ], [ %1215, %1803 ]
  %1837 = phi float [ %1216, %1639 ], [ %395, %999 ], [ %1216, %1803 ]
  %1838 = phi float [ %1217, %1639 ], [ %396, %999 ], [ %1217, %1803 ]
  %1839 = phi float [ %1218, %1639 ], [ %1004, %999 ], [ %1218, %1803 ]
  %1840 = phi float [ %1422, %1639 ], [ %596, %999 ], [ %1422, %1803 ]
  %1841 = phi float [ %1423, %1639 ], [ %597, %999 ], [ %1423, %1803 ]
  %1842 = phi float [ %1424, %1639 ], [ %598, %999 ], [ %1424, %1803 ]
  %1843 = phi float [ %1425, %1639 ], [ %1006, %999 ], [ %1425, %1803 ]
  %1844 = phi float [ %1629, %1639 ], [ %798, %999 ], [ %1629, %1803 ]
  %1845 = phi float [ %1630, %1639 ], [ %799, %999 ], [ %1630, %1803 ]
  %1846 = phi float [ %1631, %1639 ], [ %800, %999 ], [ %1631, %1803 ]
  %1847 = phi float [ %1632, %1639 ], [ %1008, %999 ], [ %1632, %1803 ]
  %1848 = phi float [ %1670, %1639 ], [ %1000, %999 ], [ %1832, %1803 ]
  %1849 = phi float [ %1671, %1639 ], [ %1001, %999 ], [ %1833, %1803 ]
  %1850 = phi float [ %1672, %1639 ], [ %1002, %999 ], [ %1834, %1803 ]
  %1851 = phi float [ %1673, %1639 ], [ %1010, %999 ], [ %1637, %1803 ]
  %1852 = fmul fast float %1836, %162
  %1853 = fmul fast float %1837, %162
  %1854 = fmul fast float %1838, %162
  %1855 = fmul fast float %1840, %163
  %1856 = fmul fast float %1841, %163
  %1857 = fmul fast float %1842, %163
  %1858 = fadd fast float %1855, %1852
  %1859 = fadd fast float %1856, %1853
  %1860 = fadd fast float %1857, %1854
  %1861 = fmul fast float %1844, %164
  %1862 = fmul fast float %1845, %164
  %1863 = fmul fast float %1846, %164
  %1864 = fadd fast float %1858, %1861
  %1865 = fadd fast float %1859, %1862
  %1866 = fadd fast float %1860, %1863
  %1867 = fmul fast float %1848, %165
  %1868 = fmul fast float %1849, %165
  %1869 = fmul fast float %1850, %165
  %1870 = fadd fast float %1864, %1867
  %1871 = fadd fast float %1865, %1868
  %1872 = fadd fast float %1866, %1869
  %1873 = fcmp fast ogt float %1870, 0x3F69A5C380000000
  %1874 = fcmp fast ogt float %1871, 0x3F69A5C380000000
  %1875 = fcmp fast ogt float %1872, 0x3F69A5C380000000
  %1876 = select i1 %1873, float 0.000000e+00, float 1.000000e+00
  %1877 = select i1 %1874, float 0.000000e+00, float 1.000000e+00
  %1878 = select i1 %1875, float 0.000000e+00, float 1.000000e+00
  %1879 = fmul fast float %1870, 0x4029D70A40000000
  %1880 = fmul fast float %1871, 0x4029D70A40000000
  %1881 = fmul fast float %1872, 0x4029D70A40000000
  %1882 = call float @dx.op.binary.f32(i32 35, float %1870, float 0.000000e+00)  ; FMax(a,b)
  %1883 = call float @dx.op.binary.f32(i32 35, float %1871, float 0.000000e+00)  ; FMax(a,b)
  %1884 = call float @dx.op.binary.f32(i32 35, float %1872, float 0.000000e+00)  ; FMax(a,b)
  %1885 = call float @dx.op.unary.f32(i32 23, float %1882)  ; Log(value)
  %1886 = call float @dx.op.unary.f32(i32 23, float %1883)  ; Log(value)
  %1887 = call float @dx.op.unary.f32(i32 23, float %1884)  ; Log(value)
  %1888 = fmul fast float %1885, 0x3FDAAAAAA0000000
  %1889 = fmul fast float %1886, 0x3FDAAAAAA0000000
  %1890 = fmul fast float %1887, 0x3FDAAAAAA0000000
  %1891 = call float @dx.op.unary.f32(i32 21, float %1888)  ; Exp(value)
  %1892 = call float @dx.op.unary.f32(i32 21, float %1889)  ; Exp(value)
  %1893 = call float @dx.op.unary.f32(i32 21, float %1890)  ; Exp(value)
  %1894 = fmul fast float %1891, 0x3FF0E147A0000000
  %1895 = fmul fast float %1892, 0x3FF0E147A0000000
  %1896 = fmul fast float %1893, 0x3FF0E147A0000000
  %1897 = fadd fast float %1894, 0xBFAC28F5C0000000
  %1898 = fadd fast float %1895, 0xBFAC28F5C0000000
  %1899 = fadd fast float %1896, 0xBFAC28F5C0000000
  %1900 = fsub fast float %1879, %1897
  %1901 = fsub fast float %1880, %1898
  %1902 = fsub fast float %1881, %1899
  %1903 = fmul fast float %1900, %1876
  %1904 = fmul fast float %1901, %1877
  %1905 = fmul fast float %1902, %1878
  %1906 = fadd fast float %1903, %1897
  %1907 = fadd fast float %1904, %1898
  %1908 = fadd fast float %1905, %1899
  %1909 = call float @dx.op.dot4.f32(i32 56, float %1839, float %1843, float %1847, float %1851, float %162, float %163, float %164, float %165)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %1906)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %1907)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %1908)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %1909)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %80)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare i1 @dx.op.isSpecialFloat.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !38, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, !37}
!36 = !{i32 9}
!37 = !{i32 3, i32 6}
!38 = !{!39, !40}
!39 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
!40 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !41}
!41 = !{i32 3, i32 1}
