;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xy  
; TEXCOORD                 1   xyzw        2     NONE   float       
; TEXCOORD                 2   xyzw        3     NONE   float       
; TEXCOORD                 3   xyzw        4     NONE   float       
; TEXCOORD                 4   xyzw        5     NONE   float       
; TEXCOORD                 5   xyzw        6     NONE   float       
; TEXCOORD                 6   xyzw        7     NONE   float       
; TEXCOORD                 7   xyzw        8     NONE   float       
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float       
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
;
; shader hash: 95e4e608894dfd712a09d898be8f93d1
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=0
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 1
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39 }
;   output 3 depends on inputs: { 0, 1 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %1, i32 0)  ; GetDimensions(handle,mipLevel)
  %11 = extractvalue %dx.types.Dimensions %10, 0
  %12 = extractvalue %dx.types.Dimensions %10, 1
  %13 = fptosi float %8 to i32
  %14 = fptosi float %9 to i32
  %15 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %13, i32 %14, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %16 = extractvalue %dx.types.ResRet.f32 %15, 0
  %17 = extractvalue %dx.types.ResRet.f32 %15, 1
  %18 = extractvalue %dx.types.ResRet.f32 %15, 2
  %19 = extractvalue %dx.types.ResRet.f32 %15, 3
  %20 = fcmp fast olt float %19, 0.000000e+00
  br i1 %20, label %21, label %23

; <label>:21                                      ; preds = %0
  %22 = fsub fast float -1.000000e+00, %19
  br label %707

; <label>:23                                      ; preds = %0
  %24 = fadd fast float %2, 1.000000e+00
  %25 = fadd fast float %3, 1.000000e+00
  %26 = fsub fast float 1.000000e+00, %2
  %27 = fmul fast float %6, %24
  %28 = fmul fast float %6, %25
  %29 = fmul fast float %6, %26
  %30 = fmul fast float %27, %16
  %31 = fmul fast float %28, %17
  %32 = fmul fast float %29, %18
  %33 = fcmp fast ult float %7, 5.000000e-01
  br i1 %33, label %59, label %34

; <label>:34                                      ; preds = %23
  %35 = fmul fast float %30, 0x4004147AE0000000
  %36 = fmul fast float %31, 0x4004147AE0000000
  %37 = fmul fast float %32, 0x4004147AE0000000
  %38 = fadd fast float %35, 0x3F9EB851E0000000
  %39 = fadd fast float %36, 0x3F9EB851E0000000
  %40 = fadd fast float %37, 0x3F9EB851E0000000
  %41 = fmul fast float %38, %30
  %42 = fmul fast float %39, %31
  %43 = fmul fast float %40, %32
  %44 = fmul fast float %30, 0x400370A3E0000000
  %45 = fmul fast float %31, 0x400370A3E0000000
  %46 = fmul fast float %32, 0x400370A3E0000000
  %47 = fadd fast float %44, 0x3FE2E147A0000000
  %48 = fadd fast float %45, 0x3FE2E147A0000000
  %49 = fadd fast float %46, 0x3FE2E147A0000000
  %50 = fmul fast float %47, %30
  %51 = fmul fast float %48, %31
  %52 = fmul fast float %49, %32
  %53 = fadd fast float %50, 0x3FC1EB8520000000
  %54 = fadd fast float %51, 0x3FC1EB8520000000
  %55 = fadd fast float %52, 0x3FC1EB8520000000
  %56 = fdiv fast float %41, %53
  %57 = fdiv fast float %42, %54
  %58 = fdiv fast float %43, %55
  br label %59

; <label>:59                                      ; preds = %34, %23
  %60 = phi float [ %56, %34 ], [ %30, %23 ]
  %61 = phi float [ %57, %34 ], [ %31, %23 ]
  %62 = phi float [ %58, %34 ], [ %32, %23 ]
  %63 = call float @dx.op.unary.f32(i32 7, float %60)  ; Saturate(value)
  %64 = call float @dx.op.unary.f32(i32 7, float %61)  ; Saturate(value)
  %65 = call float @dx.op.unary.f32(i32 7, float %62)  ; Saturate(value)
  %66 = call float @dx.op.dot3.f32(i32 55, float %63, float %64, float %65, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %67 = fsub fast float %63, %66
  %68 = fsub fast float %64, %66
  %69 = fsub fast float %65, %66
  %70 = fmul fast float %67, %5
  %71 = fmul fast float %68, %5
  %72 = fmul fast float %69, %5
  %73 = fadd fast float %70, %66
  %74 = fadd fast float %71, %66
  %75 = fadd fast float %72, %66
  %76 = call float @dx.op.unary.f32(i32 7, float %73)  ; Saturate(value)
  %77 = call float @dx.op.unary.f32(i32 7, float %74)  ; Saturate(value)
  %78 = call float @dx.op.unary.f32(i32 7, float %75)  ; Saturate(value)
  %79 = fadd fast float %76, 0xBFC70A3D80000000
  %80 = fadd fast float %77, 0xBFC70A3D80000000
  %81 = fadd fast float %78, 0xBFC70A3D80000000
  %82 = fmul fast float %79, %4
  %83 = fmul fast float %80, %4
  %84 = fmul fast float %81, %4
  %85 = fadd fast float %82, 0x3FC70A3D80000000
  %86 = fadd fast float %83, 0x3FC70A3D80000000
  %87 = fadd fast float %84, 0x3FC70A3D80000000
  %88 = call float @dx.op.unary.f32(i32 7, float %85)  ; Saturate(value)
  %89 = call float @dx.op.unary.f32(i32 7, float %86)  ; Saturate(value)
  %90 = call float @dx.op.unary.f32(i32 7, float %87)  ; Saturate(value)
  %91 = add i32 %14, -1
  %92 = add i32 %11, -1
  %93 = add i32 %12, -1
  %94 = call i32 @dx.op.binary.i32(i32 37, i32 %13, i32 0)  ; IMax(a,b)
  %95 = call i32 @dx.op.binary.i32(i32 37, i32 %91, i32 0)  ; IMax(a,b)
  %96 = call i32 @dx.op.binary.i32(i32 38, i32 %94, i32 %92)  ; IMin(a,b)
  %97 = call i32 @dx.op.binary.i32(i32 38, i32 %95, i32 %93)  ; IMin(a,b)
  %98 = call i32 @dx.op.binary.i32(i32 37, i32 %96, i32 0)  ; IMax(a,b)
  %99 = call i32 @dx.op.binary.i32(i32 37, i32 %97, i32 0)  ; IMax(a,b)
  %100 = call i32 @dx.op.binary.i32(i32 38, i32 %98, i32 %92)  ; IMin(a,b)
  %101 = call i32 @dx.op.binary.i32(i32 38, i32 %99, i32 %93)  ; IMin(a,b)
  %102 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %100, i32 %101, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %103 = extractvalue %dx.types.ResRet.f32 %102, 0
  %104 = extractvalue %dx.types.ResRet.f32 %102, 1
  %105 = extractvalue %dx.types.ResRet.f32 %102, 2
  %106 = extractvalue %dx.types.ResRet.f32 %102, 3
  %107 = fcmp fast olt float %106, 0.000000e+00
  br i1 %107, label %108, label %142

; <label>:108                                     ; preds = %59
  %109 = fcmp fast ogt float %103, 0x3FA4B5DCC0000000
  %110 = fcmp fast ogt float %104, 0x3FA4B5DCC0000000
  %111 = fcmp fast ogt float %105, 0x3FA4B5DCC0000000
  %112 = select i1 %109, float 0.000000e+00, float 1.000000e+00
  %113 = select i1 %110, float 0.000000e+00, float 1.000000e+00
  %114 = select i1 %111, float 0.000000e+00, float 1.000000e+00
  %115 = fmul fast float %103, 0x3FB3D07220000000
  %116 = fmul fast float %104, 0x3FB3D07220000000
  %117 = fmul fast float %105, 0x3FB3D07220000000
  %118 = fadd fast float %103, 0x3FAC28F5C0000000
  %119 = fadd fast float %104, 0x3FAC28F5C0000000
  %120 = fadd fast float %105, 0x3FAC28F5C0000000
  %121 = fmul fast float %118, 0x3FEE54EDE0000000
  %122 = fmul fast float %119, 0x3FEE54EDE0000000
  %123 = fmul fast float %120, 0x3FEE54EDE0000000
  %124 = call float @dx.op.unary.f32(i32 23, float %121)  ; Log(value)
  %125 = call float @dx.op.unary.f32(i32 23, float %122)  ; Log(value)
  %126 = call float @dx.op.unary.f32(i32 23, float %123)  ; Log(value)
  %127 = fmul fast float %124, 0x4003333340000000
  %128 = fmul fast float %125, 0x4003333340000000
  %129 = fmul fast float %126, 0x4003333340000000
  %130 = call float @dx.op.unary.f32(i32 21, float %127)  ; Exp(value)
  %131 = call float @dx.op.unary.f32(i32 21, float %128)  ; Exp(value)
  %132 = call float @dx.op.unary.f32(i32 21, float %129)  ; Exp(value)
  %133 = fsub fast float %115, %130
  %134 = fsub fast float %116, %131
  %135 = fsub fast float %117, %132
  %136 = fmul fast float %133, %112
  %137 = fmul fast float %134, %113
  %138 = fmul fast float %135, %114
  %139 = fadd fast float %136, %130
  %140 = fadd fast float %137, %131
  %141 = fadd fast float %138, %132
  br label %210

; <label>:142                                     ; preds = %59
  %143 = fadd fast float %2, 1.000000e+00
  %144 = fadd fast float %3, 1.000000e+00
  %145 = fsub fast float 1.000000e+00, %2
  %146 = fmul fast float %6, %143
  %147 = fmul fast float %6, %144
  %148 = fmul fast float %6, %145
  %149 = fmul fast float %146, %103
  %150 = fmul fast float %147, %104
  %151 = fmul fast float %148, %105
  %152 = fcmp fast ult float %7, 5.000000e-01
  br i1 %152, label %178, label %153

; <label>:153                                     ; preds = %142
  %154 = fmul fast float %149, 0x4004147AE0000000
  %155 = fmul fast float %150, 0x4004147AE0000000
  %156 = fmul fast float %151, 0x4004147AE0000000
  %157 = fadd fast float %154, 0x3F9EB851E0000000
  %158 = fadd fast float %155, 0x3F9EB851E0000000
  %159 = fadd fast float %156, 0x3F9EB851E0000000
  %160 = fmul fast float %157, %149
  %161 = fmul fast float %158, %150
  %162 = fmul fast float %159, %151
  %163 = fmul fast float %149, 0x400370A3E0000000
  %164 = fmul fast float %150, 0x400370A3E0000000
  %165 = fmul fast float %151, 0x400370A3E0000000
  %166 = fadd fast float %163, 0x3FE2E147A0000000
  %167 = fadd fast float %164, 0x3FE2E147A0000000
  %168 = fadd fast float %165, 0x3FE2E147A0000000
  %169 = fmul fast float %166, %149
  %170 = fmul fast float %167, %150
  %171 = fmul fast float %168, %151
  %172 = fadd fast float %169, 0x3FC1EB8520000000
  %173 = fadd fast float %170, 0x3FC1EB8520000000
  %174 = fadd fast float %171, 0x3FC1EB8520000000
  %175 = fdiv fast float %160, %172
  %176 = fdiv fast float %161, %173
  %177 = fdiv fast float %162, %174
  br label %178

; <label>:178                                     ; preds = %153, %142
  %179 = phi float [ %175, %153 ], [ %149, %142 ]
  %180 = phi float [ %176, %153 ], [ %150, %142 ]
  %181 = phi float [ %177, %153 ], [ %151, %142 ]
  %182 = call float @dx.op.unary.f32(i32 7, float %179)  ; Saturate(value)
  %183 = call float @dx.op.unary.f32(i32 7, float %180)  ; Saturate(value)
  %184 = call float @dx.op.unary.f32(i32 7, float %181)  ; Saturate(value)
  %185 = call float @dx.op.dot3.f32(i32 55, float %182, float %183, float %184, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %186 = fsub fast float %182, %185
  %187 = fsub fast float %183, %185
  %188 = fsub fast float %184, %185
  %189 = fmul fast float %186, %5
  %190 = fmul fast float %187, %5
  %191 = fmul fast float %188, %5
  %192 = fadd fast float %189, %185
  %193 = fadd fast float %190, %185
  %194 = fadd fast float %191, %185
  %195 = call float @dx.op.unary.f32(i32 7, float %192)  ; Saturate(value)
  %196 = call float @dx.op.unary.f32(i32 7, float %193)  ; Saturate(value)
  %197 = call float @dx.op.unary.f32(i32 7, float %194)  ; Saturate(value)
  %198 = fadd fast float %195, 0xBFC70A3D80000000
  %199 = fadd fast float %196, 0xBFC70A3D80000000
  %200 = fadd fast float %197, 0xBFC70A3D80000000
  %201 = fmul fast float %198, %4
  %202 = fmul fast float %199, %4
  %203 = fmul fast float %200, %4
  %204 = fadd fast float %201, 0x3FC70A3D80000000
  %205 = fadd fast float %202, 0x3FC70A3D80000000
  %206 = fadd fast float %203, 0x3FC70A3D80000000
  %207 = call float @dx.op.unary.f32(i32 7, float %204)  ; Saturate(value)
  %208 = call float @dx.op.unary.f32(i32 7, float %205)  ; Saturate(value)
  %209 = call float @dx.op.unary.f32(i32 7, float %206)  ; Saturate(value)
  br label %210

; <label>:210                                     ; preds = %178, %108
  %211 = phi float [ %139, %108 ], [ %207, %178 ]
  %212 = phi float [ %140, %108 ], [ %208, %178 ]
  %213 = phi float [ %141, %108 ], [ %209, %178 ]
  %214 = add i32 %14, 1
  %215 = call i32 @dx.op.binary.i32(i32 37, i32 %214, i32 0)  ; IMax(a,b)
  %216 = call i32 @dx.op.binary.i32(i32 38, i32 %215, i32 %93)  ; IMin(a,b)
  %217 = call i32 @dx.op.binary.i32(i32 37, i32 %216, i32 0)  ; IMax(a,b)
  %218 = call i32 @dx.op.binary.i32(i32 38, i32 %217, i32 %93)  ; IMin(a,b)
  %219 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %100, i32 %218, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %220 = extractvalue %dx.types.ResRet.f32 %219, 0
  %221 = extractvalue %dx.types.ResRet.f32 %219, 1
  %222 = extractvalue %dx.types.ResRet.f32 %219, 2
  %223 = extractvalue %dx.types.ResRet.f32 %219, 3
  %224 = fcmp fast olt float %223, 0.000000e+00
  br i1 %224, label %225, label %259

; <label>:225                                     ; preds = %210
  %226 = fcmp fast ogt float %220, 0x3FA4B5DCC0000000
  %227 = fcmp fast ogt float %221, 0x3FA4B5DCC0000000
  %228 = fcmp fast ogt float %222, 0x3FA4B5DCC0000000
  %229 = select i1 %226, float 0.000000e+00, float 1.000000e+00
  %230 = select i1 %227, float 0.000000e+00, float 1.000000e+00
  %231 = select i1 %228, float 0.000000e+00, float 1.000000e+00
  %232 = fmul fast float %220, 0x3FB3D07220000000
  %233 = fmul fast float %221, 0x3FB3D07220000000
  %234 = fmul fast float %222, 0x3FB3D07220000000
  %235 = fadd fast float %220, 0x3FAC28F5C0000000
  %236 = fadd fast float %221, 0x3FAC28F5C0000000
  %237 = fadd fast float %222, 0x3FAC28F5C0000000
  %238 = fmul fast float %235, 0x3FEE54EDE0000000
  %239 = fmul fast float %236, 0x3FEE54EDE0000000
  %240 = fmul fast float %237, 0x3FEE54EDE0000000
  %241 = call float @dx.op.unary.f32(i32 23, float %238)  ; Log(value)
  %242 = call float @dx.op.unary.f32(i32 23, float %239)  ; Log(value)
  %243 = call float @dx.op.unary.f32(i32 23, float %240)  ; Log(value)
  %244 = fmul fast float %241, 0x4003333340000000
  %245 = fmul fast float %242, 0x4003333340000000
  %246 = fmul fast float %243, 0x4003333340000000
  %247 = call float @dx.op.unary.f32(i32 21, float %244)  ; Exp(value)
  %248 = call float @dx.op.unary.f32(i32 21, float %245)  ; Exp(value)
  %249 = call float @dx.op.unary.f32(i32 21, float %246)  ; Exp(value)
  %250 = fsub fast float %232, %247
  %251 = fsub fast float %233, %248
  %252 = fsub fast float %234, %249
  %253 = fmul fast float %250, %229
  %254 = fmul fast float %251, %230
  %255 = fmul fast float %252, %231
  %256 = fadd fast float %253, %247
  %257 = fadd fast float %254, %248
  %258 = fadd fast float %255, %249
  br label %327

; <label>:259                                     ; preds = %210
  %260 = fadd fast float %2, 1.000000e+00
  %261 = fadd fast float %3, 1.000000e+00
  %262 = fsub fast float 1.000000e+00, %2
  %263 = fmul fast float %6, %260
  %264 = fmul fast float %6, %261
  %265 = fmul fast float %6, %262
  %266 = fmul fast float %263, %220
  %267 = fmul fast float %264, %221
  %268 = fmul fast float %265, %222
  %269 = fcmp fast ult float %7, 5.000000e-01
  br i1 %269, label %295, label %270

; <label>:270                                     ; preds = %259
  %271 = fmul fast float %266, 0x4004147AE0000000
  %272 = fmul fast float %267, 0x4004147AE0000000
  %273 = fmul fast float %268, 0x4004147AE0000000
  %274 = fadd fast float %271, 0x3F9EB851E0000000
  %275 = fadd fast float %272, 0x3F9EB851E0000000
  %276 = fadd fast float %273, 0x3F9EB851E0000000
  %277 = fmul fast float %274, %266
  %278 = fmul fast float %275, %267
  %279 = fmul fast float %276, %268
  %280 = fmul fast float %266, 0x400370A3E0000000
  %281 = fmul fast float %267, 0x400370A3E0000000
  %282 = fmul fast float %268, 0x400370A3E0000000
  %283 = fadd fast float %280, 0x3FE2E147A0000000
  %284 = fadd fast float %281, 0x3FE2E147A0000000
  %285 = fadd fast float %282, 0x3FE2E147A0000000
  %286 = fmul fast float %283, %266
  %287 = fmul fast float %284, %267
  %288 = fmul fast float %285, %268
  %289 = fadd fast float %286, 0x3FC1EB8520000000
  %290 = fadd fast float %287, 0x3FC1EB8520000000
  %291 = fadd fast float %288, 0x3FC1EB8520000000
  %292 = fdiv fast float %277, %289
  %293 = fdiv fast float %278, %290
  %294 = fdiv fast float %279, %291
  br label %295

; <label>:295                                     ; preds = %270, %259
  %296 = phi float [ %292, %270 ], [ %266, %259 ]
  %297 = phi float [ %293, %270 ], [ %267, %259 ]
  %298 = phi float [ %294, %270 ], [ %268, %259 ]
  %299 = call float @dx.op.unary.f32(i32 7, float %296)  ; Saturate(value)
  %300 = call float @dx.op.unary.f32(i32 7, float %297)  ; Saturate(value)
  %301 = call float @dx.op.unary.f32(i32 7, float %298)  ; Saturate(value)
  %302 = call float @dx.op.dot3.f32(i32 55, float %299, float %300, float %301, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %303 = fsub fast float %299, %302
  %304 = fsub fast float %300, %302
  %305 = fsub fast float %301, %302
  %306 = fmul fast float %303, %5
  %307 = fmul fast float %304, %5
  %308 = fmul fast float %305, %5
  %309 = fadd fast float %306, %302
  %310 = fadd fast float %307, %302
  %311 = fadd fast float %308, %302
  %312 = call float @dx.op.unary.f32(i32 7, float %309)  ; Saturate(value)
  %313 = call float @dx.op.unary.f32(i32 7, float %310)  ; Saturate(value)
  %314 = call float @dx.op.unary.f32(i32 7, float %311)  ; Saturate(value)
  %315 = fadd fast float %312, 0xBFC70A3D80000000
  %316 = fadd fast float %313, 0xBFC70A3D80000000
  %317 = fadd fast float %314, 0xBFC70A3D80000000
  %318 = fmul fast float %315, %4
  %319 = fmul fast float %316, %4
  %320 = fmul fast float %317, %4
  %321 = fadd fast float %318, 0x3FC70A3D80000000
  %322 = fadd fast float %319, 0x3FC70A3D80000000
  %323 = fadd fast float %320, 0x3FC70A3D80000000
  %324 = call float @dx.op.unary.f32(i32 7, float %321)  ; Saturate(value)
  %325 = call float @dx.op.unary.f32(i32 7, float %322)  ; Saturate(value)
  %326 = call float @dx.op.unary.f32(i32 7, float %323)  ; Saturate(value)
  br label %327

; <label>:327                                     ; preds = %295, %225
  %328 = phi float [ %256, %225 ], [ %324, %295 ]
  %329 = phi float [ %257, %225 ], [ %325, %295 ]
  %330 = phi float [ %258, %225 ], [ %326, %295 ]
  %331 = add i32 %13, -1
  %332 = call i32 @dx.op.binary.i32(i32 37, i32 %331, i32 0)  ; IMax(a,b)
  %333 = call i32 @dx.op.binary.i32(i32 37, i32 %14, i32 0)  ; IMax(a,b)
  %334 = call i32 @dx.op.binary.i32(i32 38, i32 %332, i32 %92)  ; IMin(a,b)
  %335 = call i32 @dx.op.binary.i32(i32 38, i32 %333, i32 %93)  ; IMin(a,b)
  %336 = call i32 @dx.op.binary.i32(i32 37, i32 %334, i32 0)  ; IMax(a,b)
  %337 = call i32 @dx.op.binary.i32(i32 37, i32 %335, i32 0)  ; IMax(a,b)
  %338 = call i32 @dx.op.binary.i32(i32 38, i32 %336, i32 %92)  ; IMin(a,b)
  %339 = call i32 @dx.op.binary.i32(i32 38, i32 %337, i32 %93)  ; IMin(a,b)
  %340 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %338, i32 %339, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %341 = extractvalue %dx.types.ResRet.f32 %340, 0
  %342 = extractvalue %dx.types.ResRet.f32 %340, 1
  %343 = extractvalue %dx.types.ResRet.f32 %340, 2
  %344 = extractvalue %dx.types.ResRet.f32 %340, 3
  %345 = fcmp fast olt float %344, 0.000000e+00
  br i1 %345, label %346, label %380

; <label>:346                                     ; preds = %327
  %347 = fcmp fast ogt float %341, 0x3FA4B5DCC0000000
  %348 = fcmp fast ogt float %342, 0x3FA4B5DCC0000000
  %349 = fcmp fast ogt float %343, 0x3FA4B5DCC0000000
  %350 = select i1 %347, float 0.000000e+00, float 1.000000e+00
  %351 = select i1 %348, float 0.000000e+00, float 1.000000e+00
  %352 = select i1 %349, float 0.000000e+00, float 1.000000e+00
  %353 = fmul fast float %341, 0x3FB3D07220000000
  %354 = fmul fast float %342, 0x3FB3D07220000000
  %355 = fmul fast float %343, 0x3FB3D07220000000
  %356 = fadd fast float %341, 0x3FAC28F5C0000000
  %357 = fadd fast float %342, 0x3FAC28F5C0000000
  %358 = fadd fast float %343, 0x3FAC28F5C0000000
  %359 = fmul fast float %356, 0x3FEE54EDE0000000
  %360 = fmul fast float %357, 0x3FEE54EDE0000000
  %361 = fmul fast float %358, 0x3FEE54EDE0000000
  %362 = call float @dx.op.unary.f32(i32 23, float %359)  ; Log(value)
  %363 = call float @dx.op.unary.f32(i32 23, float %360)  ; Log(value)
  %364 = call float @dx.op.unary.f32(i32 23, float %361)  ; Log(value)
  %365 = fmul fast float %362, 0x4003333340000000
  %366 = fmul fast float %363, 0x4003333340000000
  %367 = fmul fast float %364, 0x4003333340000000
  %368 = call float @dx.op.unary.f32(i32 21, float %365)  ; Exp(value)
  %369 = call float @dx.op.unary.f32(i32 21, float %366)  ; Exp(value)
  %370 = call float @dx.op.unary.f32(i32 21, float %367)  ; Exp(value)
  %371 = fsub fast float %353, %368
  %372 = fsub fast float %354, %369
  %373 = fsub fast float %355, %370
  %374 = fmul fast float %371, %350
  %375 = fmul fast float %372, %351
  %376 = fmul fast float %373, %352
  %377 = fadd fast float %374, %368
  %378 = fadd fast float %375, %369
  %379 = fadd fast float %376, %370
  br label %448

; <label>:380                                     ; preds = %327
  %381 = fadd fast float %2, 1.000000e+00
  %382 = fadd fast float %3, 1.000000e+00
  %383 = fsub fast float 1.000000e+00, %2
  %384 = fmul fast float %6, %381
  %385 = fmul fast float %6, %382
  %386 = fmul fast float %6, %383
  %387 = fmul fast float %384, %341
  %388 = fmul fast float %385, %342
  %389 = fmul fast float %386, %343
  %390 = fcmp fast ult float %7, 5.000000e-01
  br i1 %390, label %416, label %391

; <label>:391                                     ; preds = %380
  %392 = fmul fast float %387, 0x4004147AE0000000
  %393 = fmul fast float %388, 0x4004147AE0000000
  %394 = fmul fast float %389, 0x4004147AE0000000
  %395 = fadd fast float %392, 0x3F9EB851E0000000
  %396 = fadd fast float %393, 0x3F9EB851E0000000
  %397 = fadd fast float %394, 0x3F9EB851E0000000
  %398 = fmul fast float %395, %387
  %399 = fmul fast float %396, %388
  %400 = fmul fast float %397, %389
  %401 = fmul fast float %387, 0x400370A3E0000000
  %402 = fmul fast float %388, 0x400370A3E0000000
  %403 = fmul fast float %389, 0x400370A3E0000000
  %404 = fadd fast float %401, 0x3FE2E147A0000000
  %405 = fadd fast float %402, 0x3FE2E147A0000000
  %406 = fadd fast float %403, 0x3FE2E147A0000000
  %407 = fmul fast float %404, %387
  %408 = fmul fast float %405, %388
  %409 = fmul fast float %406, %389
  %410 = fadd fast float %407, 0x3FC1EB8520000000
  %411 = fadd fast float %408, 0x3FC1EB8520000000
  %412 = fadd fast float %409, 0x3FC1EB8520000000
  %413 = fdiv fast float %398, %410
  %414 = fdiv fast float %399, %411
  %415 = fdiv fast float %400, %412
  br label %416

; <label>:416                                     ; preds = %391, %380
  %417 = phi float [ %413, %391 ], [ %387, %380 ]
  %418 = phi float [ %414, %391 ], [ %388, %380 ]
  %419 = phi float [ %415, %391 ], [ %389, %380 ]
  %420 = call float @dx.op.unary.f32(i32 7, float %417)  ; Saturate(value)
  %421 = call float @dx.op.unary.f32(i32 7, float %418)  ; Saturate(value)
  %422 = call float @dx.op.unary.f32(i32 7, float %419)  ; Saturate(value)
  %423 = call float @dx.op.dot3.f32(i32 55, float %420, float %421, float %422, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %424 = fsub fast float %420, %423
  %425 = fsub fast float %421, %423
  %426 = fsub fast float %422, %423
  %427 = fmul fast float %424, %5
  %428 = fmul fast float %425, %5
  %429 = fmul fast float %426, %5
  %430 = fadd fast float %427, %423
  %431 = fadd fast float %428, %423
  %432 = fadd fast float %429, %423
  %433 = call float @dx.op.unary.f32(i32 7, float %430)  ; Saturate(value)
  %434 = call float @dx.op.unary.f32(i32 7, float %431)  ; Saturate(value)
  %435 = call float @dx.op.unary.f32(i32 7, float %432)  ; Saturate(value)
  %436 = fadd fast float %433, 0xBFC70A3D80000000
  %437 = fadd fast float %434, 0xBFC70A3D80000000
  %438 = fadd fast float %435, 0xBFC70A3D80000000
  %439 = fmul fast float %436, %4
  %440 = fmul fast float %437, %4
  %441 = fmul fast float %438, %4
  %442 = fadd fast float %439, 0x3FC70A3D80000000
  %443 = fadd fast float %440, 0x3FC70A3D80000000
  %444 = fadd fast float %441, 0x3FC70A3D80000000
  %445 = call float @dx.op.unary.f32(i32 7, float %442)  ; Saturate(value)
  %446 = call float @dx.op.unary.f32(i32 7, float %443)  ; Saturate(value)
  %447 = call float @dx.op.unary.f32(i32 7, float %444)  ; Saturate(value)
  br label %448

; <label>:448                                     ; preds = %416, %346
  %449 = phi float [ %377, %346 ], [ %445, %416 ]
  %450 = phi float [ %378, %346 ], [ %446, %416 ]
  %451 = phi float [ %379, %346 ], [ %447, %416 ]
  %452 = add i32 %13, 1
  %453 = call i32 @dx.op.binary.i32(i32 37, i32 %452, i32 0)  ; IMax(a,b)
  %454 = call i32 @dx.op.binary.i32(i32 38, i32 %453, i32 %92)  ; IMin(a,b)
  %455 = call i32 @dx.op.binary.i32(i32 37, i32 %454, i32 0)  ; IMax(a,b)
  %456 = call i32 @dx.op.binary.i32(i32 38, i32 %455, i32 %92)  ; IMin(a,b)
  %457 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %456, i32 %339, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %458 = extractvalue %dx.types.ResRet.f32 %457, 0
  %459 = extractvalue %dx.types.ResRet.f32 %457, 1
  %460 = extractvalue %dx.types.ResRet.f32 %457, 2
  %461 = extractvalue %dx.types.ResRet.f32 %457, 3
  %462 = fcmp fast olt float %461, 0.000000e+00
  br i1 %462, label %463, label %497

; <label>:463                                     ; preds = %448
  %464 = fcmp fast ogt float %458, 0x3FA4B5DCC0000000
  %465 = fcmp fast ogt float %459, 0x3FA4B5DCC0000000
  %466 = fcmp fast ogt float %460, 0x3FA4B5DCC0000000
  %467 = select i1 %464, float 0.000000e+00, float 1.000000e+00
  %468 = select i1 %465, float 0.000000e+00, float 1.000000e+00
  %469 = select i1 %466, float 0.000000e+00, float 1.000000e+00
  %470 = fmul fast float %458, 0x3FB3D07220000000
  %471 = fmul fast float %459, 0x3FB3D07220000000
  %472 = fmul fast float %460, 0x3FB3D07220000000
  %473 = fadd fast float %458, 0x3FAC28F5C0000000
  %474 = fadd fast float %459, 0x3FAC28F5C0000000
  %475 = fadd fast float %460, 0x3FAC28F5C0000000
  %476 = fmul fast float %473, 0x3FEE54EDE0000000
  %477 = fmul fast float %474, 0x3FEE54EDE0000000
  %478 = fmul fast float %475, 0x3FEE54EDE0000000
  %479 = call float @dx.op.unary.f32(i32 23, float %476)  ; Log(value)
  %480 = call float @dx.op.unary.f32(i32 23, float %477)  ; Log(value)
  %481 = call float @dx.op.unary.f32(i32 23, float %478)  ; Log(value)
  %482 = fmul fast float %479, 0x4003333340000000
  %483 = fmul fast float %480, 0x4003333340000000
  %484 = fmul fast float %481, 0x4003333340000000
  %485 = call float @dx.op.unary.f32(i32 21, float %482)  ; Exp(value)
  %486 = call float @dx.op.unary.f32(i32 21, float %483)  ; Exp(value)
  %487 = call float @dx.op.unary.f32(i32 21, float %484)  ; Exp(value)
  %488 = fsub fast float %470, %485
  %489 = fsub fast float %471, %486
  %490 = fsub fast float %472, %487
  %491 = fmul fast float %488, %467
  %492 = fmul fast float %489, %468
  %493 = fmul fast float %490, %469
  %494 = fadd fast float %491, %485
  %495 = fadd fast float %492, %486
  %496 = fadd fast float %493, %487
  br label %565

; <label>:497                                     ; preds = %448
  %498 = fadd fast float %2, 1.000000e+00
  %499 = fadd fast float %3, 1.000000e+00
  %500 = fsub fast float 1.000000e+00, %2
  %501 = fmul fast float %6, %498
  %502 = fmul fast float %6, %499
  %503 = fmul fast float %6, %500
  %504 = fmul fast float %501, %458
  %505 = fmul fast float %502, %459
  %506 = fmul fast float %503, %460
  %507 = fcmp fast ult float %7, 5.000000e-01
  br i1 %507, label %533, label %508

; <label>:508                                     ; preds = %497
  %509 = fmul fast float %504, 0x4004147AE0000000
  %510 = fmul fast float %505, 0x4004147AE0000000
  %511 = fmul fast float %506, 0x4004147AE0000000
  %512 = fadd fast float %509, 0x3F9EB851E0000000
  %513 = fadd fast float %510, 0x3F9EB851E0000000
  %514 = fadd fast float %511, 0x3F9EB851E0000000
  %515 = fmul fast float %512, %504
  %516 = fmul fast float %513, %505
  %517 = fmul fast float %514, %506
  %518 = fmul fast float %504, 0x400370A3E0000000
  %519 = fmul fast float %505, 0x400370A3E0000000
  %520 = fmul fast float %506, 0x400370A3E0000000
  %521 = fadd fast float %518, 0x3FE2E147A0000000
  %522 = fadd fast float %519, 0x3FE2E147A0000000
  %523 = fadd fast float %520, 0x3FE2E147A0000000
  %524 = fmul fast float %521, %504
  %525 = fmul fast float %522, %505
  %526 = fmul fast float %523, %506
  %527 = fadd fast float %524, 0x3FC1EB8520000000
  %528 = fadd fast float %525, 0x3FC1EB8520000000
  %529 = fadd fast float %526, 0x3FC1EB8520000000
  %530 = fdiv fast float %515, %527
  %531 = fdiv fast float %516, %528
  %532 = fdiv fast float %517, %529
  br label %533

; <label>:533                                     ; preds = %508, %497
  %534 = phi float [ %530, %508 ], [ %504, %497 ]
  %535 = phi float [ %531, %508 ], [ %505, %497 ]
  %536 = phi float [ %532, %508 ], [ %506, %497 ]
  %537 = call float @dx.op.unary.f32(i32 7, float %534)  ; Saturate(value)
  %538 = call float @dx.op.unary.f32(i32 7, float %535)  ; Saturate(value)
  %539 = call float @dx.op.unary.f32(i32 7, float %536)  ; Saturate(value)
  %540 = call float @dx.op.dot3.f32(i32 55, float %537, float %538, float %539, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %541 = fsub fast float %537, %540
  %542 = fsub fast float %538, %540
  %543 = fsub fast float %539, %540
  %544 = fmul fast float %541, %5
  %545 = fmul fast float %542, %5
  %546 = fmul fast float %543, %5
  %547 = fadd fast float %544, %540
  %548 = fadd fast float %545, %540
  %549 = fadd fast float %546, %540
  %550 = call float @dx.op.unary.f32(i32 7, float %547)  ; Saturate(value)
  %551 = call float @dx.op.unary.f32(i32 7, float %548)  ; Saturate(value)
  %552 = call float @dx.op.unary.f32(i32 7, float %549)  ; Saturate(value)
  %553 = fadd fast float %550, 0xBFC70A3D80000000
  %554 = fadd fast float %551, 0xBFC70A3D80000000
  %555 = fadd fast float %552, 0xBFC70A3D80000000
  %556 = fmul fast float %553, %4
  %557 = fmul fast float %554, %4
  %558 = fmul fast float %555, %4
  %559 = fadd fast float %556, 0x3FC70A3D80000000
  %560 = fadd fast float %557, 0x3FC70A3D80000000
  %561 = fadd fast float %558, 0x3FC70A3D80000000
  %562 = call float @dx.op.unary.f32(i32 7, float %559)  ; Saturate(value)
  %563 = call float @dx.op.unary.f32(i32 7, float %560)  ; Saturate(value)
  %564 = call float @dx.op.unary.f32(i32 7, float %561)  ; Saturate(value)
  br label %565

; <label>:565                                     ; preds = %533, %463
  %566 = phi float [ %494, %463 ], [ %562, %533 ]
  %567 = phi float [ %495, %463 ], [ %563, %533 ]
  %568 = phi float [ %496, %463 ], [ %564, %533 ]
  %569 = call float @dx.op.binary.f32(i32 36, float %449, float %566)  ; FMin(a,b)
  %570 = call float @dx.op.binary.f32(i32 36, float %450, float %567)  ; FMin(a,b)
  %571 = call float @dx.op.binary.f32(i32 36, float %451, float %568)  ; FMin(a,b)
  %572 = call float @dx.op.binary.f32(i32 36, float %211, float %328)  ; FMin(a,b)
  %573 = call float @dx.op.binary.f32(i32 36, float %212, float %329)  ; FMin(a,b)
  %574 = call float @dx.op.binary.f32(i32 36, float %213, float %330)  ; FMin(a,b)
  %575 = call float @dx.op.binary.f32(i32 36, float %572, float %569)  ; FMin(a,b)
  %576 = call float @dx.op.binary.f32(i32 36, float %573, float %570)  ; FMin(a,b)
  %577 = call float @dx.op.binary.f32(i32 36, float %574, float %571)  ; FMin(a,b)
  %578 = call float @dx.op.binary.f32(i32 36, float %88, float %575)  ; FMin(a,b)
  %579 = call float @dx.op.binary.f32(i32 36, float %89, float %576)  ; FMin(a,b)
  %580 = call float @dx.op.binary.f32(i32 36, float %90, float %577)  ; FMin(a,b)
  %581 = call float @dx.op.binary.f32(i32 35, float %449, float %566)  ; FMax(a,b)
  %582 = call float @dx.op.binary.f32(i32 35, float %450, float %567)  ; FMax(a,b)
  %583 = call float @dx.op.binary.f32(i32 35, float %451, float %568)  ; FMax(a,b)
  %584 = call float @dx.op.binary.f32(i32 35, float %211, float %328)  ; FMax(a,b)
  %585 = call float @dx.op.binary.f32(i32 35, float %212, float %329)  ; FMax(a,b)
  %586 = call float @dx.op.binary.f32(i32 35, float %213, float %330)  ; FMax(a,b)
  %587 = call float @dx.op.binary.f32(i32 35, float %584, float %581)  ; FMax(a,b)
  %588 = call float @dx.op.binary.f32(i32 35, float %585, float %582)  ; FMax(a,b)
  %589 = call float @dx.op.binary.f32(i32 35, float %586, float %583)  ; FMax(a,b)
  %590 = call float @dx.op.binary.f32(i32 35, float %88, float %587)  ; FMax(a,b)
  %591 = call float @dx.op.binary.f32(i32 35, float %89, float %588)  ; FMax(a,b)
  %592 = call float @dx.op.binary.f32(i32 35, float %90, float %589)  ; FMax(a,b)
  %593 = fsub fast float %590, %578
  %594 = fsub fast float %591, %579
  %595 = fsub fast float %592, %580
  %596 = call float @dx.op.unary.f32(i32 6, float %593)  ; FAbs(value)
  %597 = call float @dx.op.unary.f32(i32 6, float %594)  ; FAbs(value)
  %598 = call float @dx.op.unary.f32(i32 6, float %595)  ; FAbs(value)
  %599 = call float @dx.op.binary.f32(i32 35, float %597, float %598)  ; FMax(a,b)
  %600 = call float @dx.op.binary.f32(i32 35, float %596, float %599)  ; FMax(a,b)
  %601 = call float @dx.op.binary.f32(i32 35, float %591, float %592)  ; FMax(a,b)
  %602 = call float @dx.op.binary.f32(i32 35, float %590, float %601)  ; FMax(a,b)
  %603 = fmul fast float %602, 1.250000e-01
  %604 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %603)  ; FMax(a,b)
  %605 = fcmp fast ogt float %600, %604
  br i1 %605, label %606, label %667

; <label>:606                                     ; preds = %565
  %607 = fsub fast float %211, %328
  %608 = fsub fast float %212, %329
  %609 = fsub fast float %213, %330
  %610 = call float @dx.op.unary.f32(i32 6, float %607)  ; FAbs(value)
  %611 = call float @dx.op.unary.f32(i32 6, float %608)  ; FAbs(value)
  %612 = call float @dx.op.unary.f32(i32 6, float %609)  ; FAbs(value)
  %613 = call float @dx.op.binary.f32(i32 35, float %611, float %612)  ; FMax(a,b)
  %614 = call float @dx.op.binary.f32(i32 35, float %610, float %613)  ; FMax(a,b)
  %615 = fsub fast float %449, %566
  %616 = fsub fast float %450, %567
  %617 = fsub fast float %451, %568
  %618 = call float @dx.op.unary.f32(i32 6, float %615)  ; FAbs(value)
  %619 = call float @dx.op.unary.f32(i32 6, float %616)  ; FAbs(value)
  %620 = call float @dx.op.unary.f32(i32 6, float %617)  ; FAbs(value)
  %621 = call float @dx.op.binary.f32(i32 35, float %619, float %620)  ; FMax(a,b)
  %622 = call float @dx.op.binary.f32(i32 35, float %618, float %621)  ; FMax(a,b)
  %623 = fcmp fast olt float %614, %622
  %624 = select i1 %623, float %211, float %449
  %625 = select i1 %623, float %212, float %450
  %626 = select i1 %623, float %213, float %451
  %627 = select i1 %623, float %328, float %566
  %628 = select i1 %623, float %329, float %567
  %629 = select i1 %623, float %330, float %568
  %630 = fsub fast float %88, %627
  %631 = fsub fast float %89, %628
  %632 = fsub fast float %90, %629
  %633 = fsub fast float %88, %624
  %634 = fsub fast float %89, %625
  %635 = fsub fast float %90, %626
  %636 = call float @dx.op.dot3.f32(i32 55, float %633, float %634, float %635, float %630, float %631, float %632)  ; Dot3(ax,ay,az,bx,by,bz)
  %637 = fcmp fast ogt float %636, 0.000000e+00
  br i1 %637, label %638, label %650

; <label>:638                                     ; preds = %606
  %639 = fsub fast float %624, %627
  %640 = fsub fast float %625, %628
  %641 = fsub fast float %626, %629
  %642 = call float @dx.op.unary.f32(i32 6, float %639)  ; FAbs(value)
  %643 = call float @dx.op.unary.f32(i32 6, float %640)  ; FAbs(value)
  %644 = call float @dx.op.unary.f32(i32 6, float %641)  ; FAbs(value)
  %645 = call float @dx.op.binary.f32(i32 35, float %643, float %644)  ; FMax(a,b)
  %646 = call float @dx.op.binary.f32(i32 35, float %642, float %645)  ; FMax(a,b)
  %647 = fmul fast float %600, 2.500000e-01
  %648 = fcmp fast olt float %646, %647
  %649 = select i1 %648, float 0x3FC3333340000000, float 0x3FD3333340000000
  br label %650

; <label>:650                                     ; preds = %638, %606
  %651 = phi float [ 0x3FD3333340000000, %606 ], [ %649, %638 ]
  %652 = fadd fast float %624, %627
  %653 = fadd fast float %625, %628
  %654 = fadd fast float %626, %629
  %655 = fmul fast float %652, 5.000000e-01
  %656 = fmul fast float %653, 5.000000e-01
  %657 = fmul fast float %654, 5.000000e-01
  %658 = fsub fast float %655, %88
  %659 = fsub fast float %656, %89
  %660 = fsub fast float %657, %90
  %661 = fmul fast float %651, %658
  %662 = fmul fast float %651, %659
  %663 = fmul fast float %651, %660
  %664 = fadd fast float %661, %88
  %665 = fadd fast float %662, %89
  %666 = fadd fast float %663, %90
  br label %667

; <label>:667                                     ; preds = %650, %565
  %668 = phi float [ %664, %650 ], [ %88, %565 ]
  %669 = phi float [ %665, %650 ], [ %89, %565 ]
  %670 = phi float [ %666, %650 ], [ %90, %565 ]
  %671 = fcmp fast ogt float %668, 0x3F69A5C380000000
  %672 = fcmp fast ogt float %669, 0x3F69A5C380000000
  %673 = fcmp fast ogt float %670, 0x3F69A5C380000000
  %674 = select i1 %671, float 0.000000e+00, float 1.000000e+00
  %675 = select i1 %672, float 0.000000e+00, float 1.000000e+00
  %676 = select i1 %673, float 0.000000e+00, float 1.000000e+00
  %677 = fmul fast float %668, 0x4029D70A40000000
  %678 = fmul fast float %669, 0x4029D70A40000000
  %679 = fmul fast float %670, 0x4029D70A40000000
  %680 = call float @dx.op.binary.f32(i32 35, float %668, float 0.000000e+00)  ; FMax(a,b)
  %681 = call float @dx.op.binary.f32(i32 35, float %669, float 0.000000e+00)  ; FMax(a,b)
  %682 = call float @dx.op.binary.f32(i32 35, float %670, float 0.000000e+00)  ; FMax(a,b)
  %683 = call float @dx.op.unary.f32(i32 23, float %680)  ; Log(value)
  %684 = call float @dx.op.unary.f32(i32 23, float %681)  ; Log(value)
  %685 = call float @dx.op.unary.f32(i32 23, float %682)  ; Log(value)
  %686 = fmul fast float %683, 0x3FDAAAAAA0000000
  %687 = fmul fast float %684, 0x3FDAAAAAA0000000
  %688 = fmul fast float %685, 0x3FDAAAAAA0000000
  %689 = call float @dx.op.unary.f32(i32 21, float %686)  ; Exp(value)
  %690 = call float @dx.op.unary.f32(i32 21, float %687)  ; Exp(value)
  %691 = call float @dx.op.unary.f32(i32 21, float %688)  ; Exp(value)
  %692 = fmul fast float %689, 0x3FF0E147A0000000
  %693 = fmul fast float %690, 0x3FF0E147A0000000
  %694 = fmul fast float %691, 0x3FF0E147A0000000
  %695 = fadd fast float %692, 0xBFAC28F5C0000000
  %696 = fadd fast float %693, 0xBFAC28F5C0000000
  %697 = fadd fast float %694, 0xBFAC28F5C0000000
  %698 = fsub fast float %677, %695
  %699 = fsub fast float %678, %696
  %700 = fsub fast float %679, %697
  %701 = fmul fast float %698, %674
  %702 = fmul fast float %699, %675
  %703 = fmul fast float %700, %676
  %704 = fadd fast float %701, %695
  %705 = fadd fast float %702, %696
  %706 = fadd fast float %703, %697
  br label %707

; <label>:707                                     ; preds = %667, %21
  %708 = phi float [ %16, %21 ], [ %704, %667 ]
  %709 = phi float [ %17, %21 ], [ %705, %667 ]
  %710 = phi float [ %18, %21 ], [ %706, %667 ]
  %711 = phi float [ %22, %21 ], [ %19, %667 ]
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %708)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %709)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %710)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %711)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!8}
!dx.entryPoints = !{!9}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 0, i32 0, i32 0, i32 0]}
!9 = !{void ()* @PSMain, !"PSMain", !10, !4, null}
!10 = !{!11, !35, null}
!11 = !{!12, !15, !16, !18, !20, !22, !24, !26, !28, !30, !33}
!12 = !{i32 0, !"SV_Position", i8 9, i8 3, !13, i8 4, i32 1, i8 4, i32 0, i8 0, !14}
!13 = !{i32 0}
!14 = !{i32 3, i32 3}
!15 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !13, i8 1, i32 1, i8 4, i32 1, i8 0, !14}
!16 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !17, i8 1, i32 1, i8 4, i32 2, i8 0, null}
!17 = !{i32 1}
!18 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 3, i8 0, null}
!19 = !{i32 2}
!20 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 4, i8 0, null}
!21 = !{i32 3}
!22 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 5, i8 0, null}
!23 = !{i32 4}
!24 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 6, i8 0, null}
!25 = !{i32 5}
!26 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 7, i8 0, null}
!27 = !{i32 6}
!28 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !29, i8 1, i32 1, i8 4, i32 8, i8 0, null}
!29 = !{i32 7}
!30 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !31, i8 1, i32 1, i8 4, i32 9, i8 0, !32}
!31 = !{i32 8}
!32 = !{i32 3, i32 15}
!33 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 10, i8 0, null}
!34 = !{i32 9}
!35 = !{!36}
!36 = !{i32 0, !"SV_Target", i8 9, i8 16, !13, i8 0, i32 1, i8 4, i32 0, i8 0, !32}
