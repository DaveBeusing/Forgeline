;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xy  
; TEXCOORD                 1   xyzw        2     NONE   float       
; TEXCOORD                 2   xyzw        3     NONE   float       
; TEXCOORD                 3   xyzw        4     NONE   float       
; TEXCOORD                 4   xyzw        5     NONE   float       
; TEXCOORD                 5   xyzw        6     NONE   float       
; TEXCOORD                 6   xyzw        7     NONE   float       
; TEXCOORD                 7   xyzw        8     NONE   float       
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float   xyz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: a333e487f3f9fa9899b3da5d47c61189
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 40, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 40, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 40, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %15 = extractvalue %dx.types.Dimensions %14, 0
  %16 = extractvalue %dx.types.Dimensions %14, 1
  %17 = uitofp i32 %15 to float
  %18 = uitofp i32 %16 to float
  %19 = fmul fast float %17, %12
  %20 = fmul fast float %18, %13
  %21 = fdiv fast float %19, %4
  %22 = fdiv fast float %20, %5
  %23 = fadd fast float %21, -5.000000e-01
  %24 = fadd fast float %22, -5.000000e-01
  %25 = call float @dx.op.unary.f32(i32 27, float %23)  ; Round_ni(value)
  %26 = call float @dx.op.unary.f32(i32 27, float %24)  ; Round_ni(value)
  %27 = fptosi float %25 to i32
  %28 = fptosi float %26 to i32
  %29 = call float @dx.op.unary.f32(i32 22, float %23)  ; Frc(value)
  %30 = call float @dx.op.unary.f32(i32 22, float %24)  ; Frc(value)
  %31 = add i32 %15, -1
  %32 = add i32 %16, -1
  %33 = call i32 @dx.op.binary.i32(i32 37, i32 %27, i32 0)  ; IMax(a,b)
  %34 = call i32 @dx.op.binary.i32(i32 37, i32 %28, i32 0)  ; IMax(a,b)
  %35 = call i32 @dx.op.binary.i32(i32 38, i32 %33, i32 %31)  ; IMin(a,b)
  %36 = call i32 @dx.op.binary.i32(i32 38, i32 %34, i32 %32)  ; IMin(a,b)
  %37 = add i32 %27, 1
  %38 = call i32 @dx.op.binary.i32(i32 37, i32 %37, i32 0)  ; IMax(a,b)
  %39 = call i32 @dx.op.binary.i32(i32 38, i32 %38, i32 %31)  ; IMin(a,b)
  %40 = add i32 %28, 1
  %41 = call i32 @dx.op.binary.i32(i32 37, i32 %40, i32 0)  ; IMax(a,b)
  %42 = call i32 @dx.op.binary.i32(i32 38, i32 %41, i32 %32)  ; IMin(a,b)
  %43 = call float @dx.op.unary.f32(i32 27, float %21)  ; Round_ni(value)
  %44 = call float @dx.op.unary.f32(i32 27, float %22)  ; Round_ni(value)
  %45 = fptosi float %43 to i32
  %46 = fptosi float %44 to i32
  %47 = call i32 @dx.op.binary.i32(i32 37, i32 %45, i32 0)  ; IMax(a,b)
  %48 = call i32 @dx.op.binary.i32(i32 37, i32 %46, i32 0)  ; IMax(a,b)
  %49 = call i32 @dx.op.binary.i32(i32 38, i32 %47, i32 %31)  ; IMin(a,b)
  %50 = call i32 @dx.op.binary.i32(i32 38, i32 %48, i32 %32)  ; IMin(a,b)
  %51 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %49, i32 %50, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %52 = extractvalue %dx.types.ResRet.f32 %51, 0
  %53 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %35, i32 %36, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %54 = extractvalue %dx.types.ResRet.f32 %53, 0
  %55 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %39, i32 %36, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %56 = extractvalue %dx.types.ResRet.f32 %55, 0
  %57 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %35, i32 %42, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %58 = extractvalue %dx.types.ResRet.f32 %57, 0
  %59 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %39, i32 %42, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %60 = extractvalue %dx.types.ResRet.f32 %59, 0
  %61 = fsub fast float 1.000000e+00, %29
  %62 = fsub fast float 1.000000e+00, %30
  %63 = fmul fast float %62, %61
  %64 = fmul fast float %62, %29
  %65 = fmul fast float %61, %30
  %66 = fmul fast float %30, %29
  %67 = fsub fast float 1.000000e+00, %52
  %68 = fmul fast float %67, 0x3FA99999A0000000
  %69 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %68)  ; FMax(a,b)
  %70 = fsub fast float %54, %52
  %71 = call float @dx.op.unary.f32(i32 6, float %70)  ; FAbs(value)
  %72 = fdiv fast float %71, %69
  %73 = fsub fast float 1.000000e+00, %72
  %74 = call float @dx.op.unary.f32(i32 7, float %73)  ; Saturate(value)
  %75 = fsub fast float %56, %52
  %76 = call float @dx.op.unary.f32(i32 6, float %75)  ; FAbs(value)
  %77 = fdiv fast float %76, %69
  %78 = fsub fast float 1.000000e+00, %77
  %79 = call float @dx.op.unary.f32(i32 7, float %78)  ; Saturate(value)
  %80 = fsub fast float %58, %52
  %81 = call float @dx.op.unary.f32(i32 6, float %80)  ; FAbs(value)
  %82 = fdiv fast float %81, %69
  %83 = fsub fast float 1.000000e+00, %82
  %84 = call float @dx.op.unary.f32(i32 7, float %83)  ; Saturate(value)
  %85 = fsub fast float %60, %52
  %86 = call float @dx.op.unary.f32(i32 6, float %85)  ; FAbs(value)
  %87 = fdiv fast float %86, %69
  %88 = fsub fast float 1.000000e+00, %87
  %89 = call float @dx.op.unary.f32(i32 7, float %88)  ; Saturate(value)
  %90 = fmul fast float %63, %74
  %91 = fmul fast float %64, %79
  %92 = fmul fast float %65, %84
  %93 = fmul fast float %66, %89
  %94 = fcmp fast oge float %29, 5.000000e-01
  %95 = zext i1 %94 to i32
  %96 = fcmp fast oge float %30, 5.000000e-01
  %97 = select i1 %96, i32 2, i32 0
  %98 = or i32 %97, %95
  %99 = call float @dx.op.dot4.f32(i32 56, float %90, float %91, float %92, float %93, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %100 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %90)  ; IsFinite(value)
  %101 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %91)  ; IsFinite(value)
  %102 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %92)  ; IsFinite(value)
  %103 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %93)  ; IsFinite(value)
  %104 = and i1 %100, %101
  %105 = and i1 %104, %102
  %106 = and i1 %105, %103
  br i1 %106, label %107, label %124

; <label>:107                                     ; preds = %0
  %108 = fcmp fast oge float %90, 0.000000e+00
  %109 = fcmp fast oge float %91, 0.000000e+00
  %110 = fcmp fast oge float %92, 0.000000e+00
  %111 = fcmp fast oge float %93, 0.000000e+00
  %112 = and i1 %108, %109
  %113 = and i1 %112, %110
  %114 = and i1 %113, %111
  br i1 %114, label %115, label %124

; <label>:115                                     ; preds = %107
  %116 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %99)  ; IsFinite(value)
  %117 = fcmp fast oge float %99, 0x3810000000000000
  %118 = and i1 %117, %116
  br i1 %118, label %119, label %124

; <label>:119                                     ; preds = %115
  %120 = fdiv fast float %90, %99
  %121 = fdiv fast float %91, %99
  %122 = fdiv fast float %92, %99
  %123 = fdiv fast float %93, %99
  br label %133

; <label>:124                                     ; preds = %115, %107, %0
  %125 = icmp eq i32 %98, 0
  %126 = uitofp i1 %125 to float
  %127 = icmp eq i32 %98, 1
  %128 = uitofp i1 %127 to float
  %129 = icmp eq i32 %98, 2
  %130 = uitofp i1 %129 to float
  %131 = icmp eq i32 %98, 3
  %132 = uitofp i1 %131 to float
  br label %133

; <label>:133                                     ; preds = %124, %119
  %134 = phi float [ %120, %119 ], [ %126, %124 ]
  %135 = phi float [ %121, %119 ], [ %128, %124 ]
  %136 = phi float [ %122, %119 ], [ %130, %124 ]
  %137 = phi float [ %123, %119 ], [ %132, %124 ]
  %138 = or i32 %28, %27
  %139 = icmp sgt i32 %138, -1
  br i1 %139, label %140, label %144

; <label>:140                                     ; preds = %133
  %141 = icmp slt i32 %37, %15
  %142 = icmp slt i32 %40, %16
  %143 = and i1 %141, %142
  br label %144

; <label>:144                                     ; preds = %140, %133
  %145 = phi i1 [ false, %133 ], [ %143, %140 ]
  br i1 %145, label %146, label %2321

; <label>:146                                     ; preds = %144
  %147 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %27, i32 %28, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %148 = extractvalue %dx.types.ResRet.f32 %147, 0
  %149 = extractvalue %dx.types.ResRet.f32 %147, 1
  %150 = extractvalue %dx.types.ResRet.f32 %147, 2
  %151 = extractvalue %dx.types.ResRet.f32 %147, 3
  %152 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %37, i32 %28, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %153 = extractvalue %dx.types.ResRet.f32 %152, 0
  %154 = extractvalue %dx.types.ResRet.f32 %152, 1
  %155 = extractvalue %dx.types.ResRet.f32 %152, 2
  %156 = extractvalue %dx.types.ResRet.f32 %152, 3
  %157 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %27, i32 %40, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %158 = extractvalue %dx.types.ResRet.f32 %157, 0
  %159 = extractvalue %dx.types.ResRet.f32 %157, 1
  %160 = extractvalue %dx.types.ResRet.f32 %157, 2
  %161 = extractvalue %dx.types.ResRet.f32 %157, 3
  %162 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %37, i32 %40, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %163 = extractvalue %dx.types.ResRet.f32 %162, 0
  %164 = extractvalue %dx.types.ResRet.f32 %162, 1
  %165 = extractvalue %dx.types.ResRet.f32 %162, 2
  %166 = extractvalue %dx.types.ResRet.f32 %162, 3
  %167 = fcmp fast olt float %151, 0.000000e+00
  br i1 %167, label %168, label %202

; <label>:168                                     ; preds = %146
  %169 = fcmp fast ogt float %148, 0x3FA4B5DCC0000000
  %170 = fcmp fast ogt float %149, 0x3FA4B5DCC0000000
  %171 = fcmp fast ogt float %150, 0x3FA4B5DCC0000000
  %172 = select i1 %169, float 0.000000e+00, float 1.000000e+00
  %173 = select i1 %170, float 0.000000e+00, float 1.000000e+00
  %174 = select i1 %171, float 0.000000e+00, float 1.000000e+00
  %175 = fmul fast float %148, 0x3FB3D07220000000
  %176 = fmul fast float %149, 0x3FB3D07220000000
  %177 = fmul fast float %150, 0x3FB3D07220000000
  %178 = fadd fast float %148, 0x3FAC28F5C0000000
  %179 = fadd fast float %149, 0x3FAC28F5C0000000
  %180 = fadd fast float %150, 0x3FAC28F5C0000000
  %181 = fmul fast float %178, 0x3FEE54EDE0000000
  %182 = fmul fast float %179, 0x3FEE54EDE0000000
  %183 = fmul fast float %180, 0x3FEE54EDE0000000
  %184 = call float @dx.op.unary.f32(i32 23, float %181)  ; Log(value)
  %185 = call float @dx.op.unary.f32(i32 23, float %182)  ; Log(value)
  %186 = call float @dx.op.unary.f32(i32 23, float %183)  ; Log(value)
  %187 = fmul fast float %184, 0x4003333340000000
  %188 = fmul fast float %185, 0x4003333340000000
  %189 = fmul fast float %186, 0x4003333340000000
  %190 = call float @dx.op.unary.f32(i32 21, float %187)  ; Exp(value)
  %191 = call float @dx.op.unary.f32(i32 21, float %188)  ; Exp(value)
  %192 = call float @dx.op.unary.f32(i32 21, float %189)  ; Exp(value)
  %193 = fsub fast float %175, %190
  %194 = fsub fast float %176, %191
  %195 = fsub fast float %177, %192
  %196 = fmul fast float %193, %172
  %197 = fmul fast float %194, %173
  %198 = fmul fast float %195, %174
  %199 = fadd fast float %196, %190
  %200 = fadd fast float %197, %191
  %201 = fadd fast float %198, %192
  br label %270

; <label>:202                                     ; preds = %146
  %203 = fadd fast float %6, 1.000000e+00
  %204 = fadd fast float %7, 1.000000e+00
  %205 = fsub fast float 1.000000e+00, %6
  %206 = fmul fast float %10, %203
  %207 = fmul fast float %10, %204
  %208 = fmul fast float %10, %205
  %209 = fmul fast float %206, %148
  %210 = fmul fast float %207, %149
  %211 = fmul fast float %208, %150
  %212 = fcmp fast ult float %11, 5.000000e-01
  br i1 %212, label %238, label %213

; <label>:213                                     ; preds = %202
  %214 = fmul fast float %209, 0x4004147AE0000000
  %215 = fmul fast float %210, 0x4004147AE0000000
  %216 = fmul fast float %211, 0x4004147AE0000000
  %217 = fadd fast float %214, 0x3F9EB851E0000000
  %218 = fadd fast float %215, 0x3F9EB851E0000000
  %219 = fadd fast float %216, 0x3F9EB851E0000000
  %220 = fmul fast float %217, %209
  %221 = fmul fast float %218, %210
  %222 = fmul fast float %219, %211
  %223 = fmul fast float %209, 0x400370A3E0000000
  %224 = fmul fast float %210, 0x400370A3E0000000
  %225 = fmul fast float %211, 0x400370A3E0000000
  %226 = fadd fast float %223, 0x3FE2E147A0000000
  %227 = fadd fast float %224, 0x3FE2E147A0000000
  %228 = fadd fast float %225, 0x3FE2E147A0000000
  %229 = fmul fast float %226, %209
  %230 = fmul fast float %227, %210
  %231 = fmul fast float %228, %211
  %232 = fadd fast float %229, 0x3FC1EB8520000000
  %233 = fadd fast float %230, 0x3FC1EB8520000000
  %234 = fadd fast float %231, 0x3FC1EB8520000000
  %235 = fdiv fast float %220, %232
  %236 = fdiv fast float %221, %233
  %237 = fdiv fast float %222, %234
  br label %238

; <label>:238                                     ; preds = %213, %202
  %239 = phi float [ %235, %213 ], [ %209, %202 ]
  %240 = phi float [ %236, %213 ], [ %210, %202 ]
  %241 = phi float [ %237, %213 ], [ %211, %202 ]
  %242 = call float @dx.op.unary.f32(i32 7, float %239)  ; Saturate(value)
  %243 = call float @dx.op.unary.f32(i32 7, float %240)  ; Saturate(value)
  %244 = call float @dx.op.unary.f32(i32 7, float %241)  ; Saturate(value)
  %245 = call float @dx.op.dot3.f32(i32 55, float %242, float %243, float %244, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %246 = fsub fast float %242, %245
  %247 = fsub fast float %243, %245
  %248 = fsub fast float %244, %245
  %249 = fmul fast float %246, %9
  %250 = fmul fast float %247, %9
  %251 = fmul fast float %248, %9
  %252 = fadd fast float %249, %245
  %253 = fadd fast float %250, %245
  %254 = fadd fast float %251, %245
  %255 = call float @dx.op.unary.f32(i32 7, float %252)  ; Saturate(value)
  %256 = call float @dx.op.unary.f32(i32 7, float %253)  ; Saturate(value)
  %257 = call float @dx.op.unary.f32(i32 7, float %254)  ; Saturate(value)
  %258 = fadd fast float %255, 0xBFC70A3D80000000
  %259 = fadd fast float %256, 0xBFC70A3D80000000
  %260 = fadd fast float %257, 0xBFC70A3D80000000
  %261 = fmul fast float %258, %8
  %262 = fmul fast float %259, %8
  %263 = fmul fast float %260, %8
  %264 = fadd fast float %261, 0x3FC70A3D80000000
  %265 = fadd fast float %262, 0x3FC70A3D80000000
  %266 = fadd fast float %263, 0x3FC70A3D80000000
  %267 = call float @dx.op.unary.f32(i32 7, float %264)  ; Saturate(value)
  %268 = call float @dx.op.unary.f32(i32 7, float %265)  ; Saturate(value)
  %269 = call float @dx.op.unary.f32(i32 7, float %266)  ; Saturate(value)
  br label %270

; <label>:270                                     ; preds = %238, %168
  %271 = phi float [ %199, %168 ], [ %267, %238 ]
  %272 = phi float [ %200, %168 ], [ %268, %238 ]
  %273 = phi float [ %201, %168 ], [ %269, %238 ]
  %274 = fcmp fast olt float %156, 0.000000e+00
  br i1 %274, label %275, label %309

; <label>:275                                     ; preds = %270
  %276 = fcmp fast ogt float %153, 0x3FA4B5DCC0000000
  %277 = fcmp fast ogt float %154, 0x3FA4B5DCC0000000
  %278 = fcmp fast ogt float %155, 0x3FA4B5DCC0000000
  %279 = select i1 %276, float 0.000000e+00, float 1.000000e+00
  %280 = select i1 %277, float 0.000000e+00, float 1.000000e+00
  %281 = select i1 %278, float 0.000000e+00, float 1.000000e+00
  %282 = fmul fast float %153, 0x3FB3D07220000000
  %283 = fmul fast float %154, 0x3FB3D07220000000
  %284 = fmul fast float %155, 0x3FB3D07220000000
  %285 = fadd fast float %153, 0x3FAC28F5C0000000
  %286 = fadd fast float %154, 0x3FAC28F5C0000000
  %287 = fadd fast float %155, 0x3FAC28F5C0000000
  %288 = fmul fast float %285, 0x3FEE54EDE0000000
  %289 = fmul fast float %286, 0x3FEE54EDE0000000
  %290 = fmul fast float %287, 0x3FEE54EDE0000000
  %291 = call float @dx.op.unary.f32(i32 23, float %288)  ; Log(value)
  %292 = call float @dx.op.unary.f32(i32 23, float %289)  ; Log(value)
  %293 = call float @dx.op.unary.f32(i32 23, float %290)  ; Log(value)
  %294 = fmul fast float %291, 0x4003333340000000
  %295 = fmul fast float %292, 0x4003333340000000
  %296 = fmul fast float %293, 0x4003333340000000
  %297 = call float @dx.op.unary.f32(i32 21, float %294)  ; Exp(value)
  %298 = call float @dx.op.unary.f32(i32 21, float %295)  ; Exp(value)
  %299 = call float @dx.op.unary.f32(i32 21, float %296)  ; Exp(value)
  %300 = fsub fast float %282, %297
  %301 = fsub fast float %283, %298
  %302 = fsub fast float %284, %299
  %303 = fmul fast float %300, %279
  %304 = fmul fast float %301, %280
  %305 = fmul fast float %302, %281
  %306 = fadd fast float %303, %297
  %307 = fadd fast float %304, %298
  %308 = fadd fast float %305, %299
  br label %377

; <label>:309                                     ; preds = %270
  %310 = fadd fast float %6, 1.000000e+00
  %311 = fadd fast float %7, 1.000000e+00
  %312 = fsub fast float 1.000000e+00, %6
  %313 = fmul fast float %10, %310
  %314 = fmul fast float %10, %311
  %315 = fmul fast float %10, %312
  %316 = fmul fast float %313, %153
  %317 = fmul fast float %314, %154
  %318 = fmul fast float %315, %155
  %319 = fcmp fast ult float %11, 5.000000e-01
  br i1 %319, label %345, label %320

; <label>:320                                     ; preds = %309
  %321 = fmul fast float %316, 0x4004147AE0000000
  %322 = fmul fast float %317, 0x4004147AE0000000
  %323 = fmul fast float %318, 0x4004147AE0000000
  %324 = fadd fast float %321, 0x3F9EB851E0000000
  %325 = fadd fast float %322, 0x3F9EB851E0000000
  %326 = fadd fast float %323, 0x3F9EB851E0000000
  %327 = fmul fast float %324, %316
  %328 = fmul fast float %325, %317
  %329 = fmul fast float %326, %318
  %330 = fmul fast float %316, 0x400370A3E0000000
  %331 = fmul fast float %317, 0x400370A3E0000000
  %332 = fmul fast float %318, 0x400370A3E0000000
  %333 = fadd fast float %330, 0x3FE2E147A0000000
  %334 = fadd fast float %331, 0x3FE2E147A0000000
  %335 = fadd fast float %332, 0x3FE2E147A0000000
  %336 = fmul fast float %333, %316
  %337 = fmul fast float %334, %317
  %338 = fmul fast float %335, %318
  %339 = fadd fast float %336, 0x3FC1EB8520000000
  %340 = fadd fast float %337, 0x3FC1EB8520000000
  %341 = fadd fast float %338, 0x3FC1EB8520000000
  %342 = fdiv fast float %327, %339
  %343 = fdiv fast float %328, %340
  %344 = fdiv fast float %329, %341
  br label %345

; <label>:345                                     ; preds = %320, %309
  %346 = phi float [ %342, %320 ], [ %316, %309 ]
  %347 = phi float [ %343, %320 ], [ %317, %309 ]
  %348 = phi float [ %344, %320 ], [ %318, %309 ]
  %349 = call float @dx.op.unary.f32(i32 7, float %346)  ; Saturate(value)
  %350 = call float @dx.op.unary.f32(i32 7, float %347)  ; Saturate(value)
  %351 = call float @dx.op.unary.f32(i32 7, float %348)  ; Saturate(value)
  %352 = call float @dx.op.dot3.f32(i32 55, float %349, float %350, float %351, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %353 = fsub fast float %349, %352
  %354 = fsub fast float %350, %352
  %355 = fsub fast float %351, %352
  %356 = fmul fast float %353, %9
  %357 = fmul fast float %354, %9
  %358 = fmul fast float %355, %9
  %359 = fadd fast float %356, %352
  %360 = fadd fast float %357, %352
  %361 = fadd fast float %358, %352
  %362 = call float @dx.op.unary.f32(i32 7, float %359)  ; Saturate(value)
  %363 = call float @dx.op.unary.f32(i32 7, float %360)  ; Saturate(value)
  %364 = call float @dx.op.unary.f32(i32 7, float %361)  ; Saturate(value)
  %365 = fadd fast float %362, 0xBFC70A3D80000000
  %366 = fadd fast float %363, 0xBFC70A3D80000000
  %367 = fadd fast float %364, 0xBFC70A3D80000000
  %368 = fmul fast float %365, %8
  %369 = fmul fast float %366, %8
  %370 = fmul fast float %367, %8
  %371 = fadd fast float %368, 0x3FC70A3D80000000
  %372 = fadd fast float %369, 0x3FC70A3D80000000
  %373 = fadd fast float %370, 0x3FC70A3D80000000
  %374 = call float @dx.op.unary.f32(i32 7, float %371)  ; Saturate(value)
  %375 = call float @dx.op.unary.f32(i32 7, float %372)  ; Saturate(value)
  %376 = call float @dx.op.unary.f32(i32 7, float %373)  ; Saturate(value)
  br label %377

; <label>:377                                     ; preds = %345, %275
  %378 = phi float [ %306, %275 ], [ %374, %345 ]
  %379 = phi float [ %307, %275 ], [ %375, %345 ]
  %380 = phi float [ %308, %275 ], [ %376, %345 ]
  %381 = fcmp fast olt float %161, 0.000000e+00
  br i1 %381, label %382, label %416

; <label>:382                                     ; preds = %377
  %383 = fcmp fast ogt float %158, 0x3FA4B5DCC0000000
  %384 = fcmp fast ogt float %159, 0x3FA4B5DCC0000000
  %385 = fcmp fast ogt float %160, 0x3FA4B5DCC0000000
  %386 = select i1 %383, float 0.000000e+00, float 1.000000e+00
  %387 = select i1 %384, float 0.000000e+00, float 1.000000e+00
  %388 = select i1 %385, float 0.000000e+00, float 1.000000e+00
  %389 = fmul fast float %158, 0x3FB3D07220000000
  %390 = fmul fast float %159, 0x3FB3D07220000000
  %391 = fmul fast float %160, 0x3FB3D07220000000
  %392 = fadd fast float %158, 0x3FAC28F5C0000000
  %393 = fadd fast float %159, 0x3FAC28F5C0000000
  %394 = fadd fast float %160, 0x3FAC28F5C0000000
  %395 = fmul fast float %392, 0x3FEE54EDE0000000
  %396 = fmul fast float %393, 0x3FEE54EDE0000000
  %397 = fmul fast float %394, 0x3FEE54EDE0000000
  %398 = call float @dx.op.unary.f32(i32 23, float %395)  ; Log(value)
  %399 = call float @dx.op.unary.f32(i32 23, float %396)  ; Log(value)
  %400 = call float @dx.op.unary.f32(i32 23, float %397)  ; Log(value)
  %401 = fmul fast float %398, 0x4003333340000000
  %402 = fmul fast float %399, 0x4003333340000000
  %403 = fmul fast float %400, 0x4003333340000000
  %404 = call float @dx.op.unary.f32(i32 21, float %401)  ; Exp(value)
  %405 = call float @dx.op.unary.f32(i32 21, float %402)  ; Exp(value)
  %406 = call float @dx.op.unary.f32(i32 21, float %403)  ; Exp(value)
  %407 = fsub fast float %389, %404
  %408 = fsub fast float %390, %405
  %409 = fsub fast float %391, %406
  %410 = fmul fast float %407, %386
  %411 = fmul fast float %408, %387
  %412 = fmul fast float %409, %388
  %413 = fadd fast float %410, %404
  %414 = fadd fast float %411, %405
  %415 = fadd fast float %412, %406
  br label %484

; <label>:416                                     ; preds = %377
  %417 = fadd fast float %6, 1.000000e+00
  %418 = fadd fast float %7, 1.000000e+00
  %419 = fsub fast float 1.000000e+00, %6
  %420 = fmul fast float %10, %417
  %421 = fmul fast float %10, %418
  %422 = fmul fast float %10, %419
  %423 = fmul fast float %420, %158
  %424 = fmul fast float %421, %159
  %425 = fmul fast float %422, %160
  %426 = fcmp fast ult float %11, 5.000000e-01
  br i1 %426, label %452, label %427

; <label>:427                                     ; preds = %416
  %428 = fmul fast float %423, 0x4004147AE0000000
  %429 = fmul fast float %424, 0x4004147AE0000000
  %430 = fmul fast float %425, 0x4004147AE0000000
  %431 = fadd fast float %428, 0x3F9EB851E0000000
  %432 = fadd fast float %429, 0x3F9EB851E0000000
  %433 = fadd fast float %430, 0x3F9EB851E0000000
  %434 = fmul fast float %431, %423
  %435 = fmul fast float %432, %424
  %436 = fmul fast float %433, %425
  %437 = fmul fast float %423, 0x400370A3E0000000
  %438 = fmul fast float %424, 0x400370A3E0000000
  %439 = fmul fast float %425, 0x400370A3E0000000
  %440 = fadd fast float %437, 0x3FE2E147A0000000
  %441 = fadd fast float %438, 0x3FE2E147A0000000
  %442 = fadd fast float %439, 0x3FE2E147A0000000
  %443 = fmul fast float %440, %423
  %444 = fmul fast float %441, %424
  %445 = fmul fast float %442, %425
  %446 = fadd fast float %443, 0x3FC1EB8520000000
  %447 = fadd fast float %444, 0x3FC1EB8520000000
  %448 = fadd fast float %445, 0x3FC1EB8520000000
  %449 = fdiv fast float %434, %446
  %450 = fdiv fast float %435, %447
  %451 = fdiv fast float %436, %448
  br label %452

; <label>:452                                     ; preds = %427, %416
  %453 = phi float [ %449, %427 ], [ %423, %416 ]
  %454 = phi float [ %450, %427 ], [ %424, %416 ]
  %455 = phi float [ %451, %427 ], [ %425, %416 ]
  %456 = call float @dx.op.unary.f32(i32 7, float %453)  ; Saturate(value)
  %457 = call float @dx.op.unary.f32(i32 7, float %454)  ; Saturate(value)
  %458 = call float @dx.op.unary.f32(i32 7, float %455)  ; Saturate(value)
  %459 = call float @dx.op.dot3.f32(i32 55, float %456, float %457, float %458, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %460 = fsub fast float %456, %459
  %461 = fsub fast float %457, %459
  %462 = fsub fast float %458, %459
  %463 = fmul fast float %460, %9
  %464 = fmul fast float %461, %9
  %465 = fmul fast float %462, %9
  %466 = fadd fast float %463, %459
  %467 = fadd fast float %464, %459
  %468 = fadd fast float %465, %459
  %469 = call float @dx.op.unary.f32(i32 7, float %466)  ; Saturate(value)
  %470 = call float @dx.op.unary.f32(i32 7, float %467)  ; Saturate(value)
  %471 = call float @dx.op.unary.f32(i32 7, float %468)  ; Saturate(value)
  %472 = fadd fast float %469, 0xBFC70A3D80000000
  %473 = fadd fast float %470, 0xBFC70A3D80000000
  %474 = fadd fast float %471, 0xBFC70A3D80000000
  %475 = fmul fast float %472, %8
  %476 = fmul fast float %473, %8
  %477 = fmul fast float %474, %8
  %478 = fadd fast float %475, 0x3FC70A3D80000000
  %479 = fadd fast float %476, 0x3FC70A3D80000000
  %480 = fadd fast float %477, 0x3FC70A3D80000000
  %481 = call float @dx.op.unary.f32(i32 7, float %478)  ; Saturate(value)
  %482 = call float @dx.op.unary.f32(i32 7, float %479)  ; Saturate(value)
  %483 = call float @dx.op.unary.f32(i32 7, float %480)  ; Saturate(value)
  br label %484

; <label>:484                                     ; preds = %452, %382
  %485 = phi float [ %413, %382 ], [ %481, %452 ]
  %486 = phi float [ %414, %382 ], [ %482, %452 ]
  %487 = phi float [ %415, %382 ], [ %483, %452 ]
  %488 = fcmp fast olt float %166, 0.000000e+00
  br i1 %488, label %489, label %523

; <label>:489                                     ; preds = %484
  %490 = fcmp fast ogt float %163, 0x3FA4B5DCC0000000
  %491 = fcmp fast ogt float %164, 0x3FA4B5DCC0000000
  %492 = fcmp fast ogt float %165, 0x3FA4B5DCC0000000
  %493 = select i1 %490, float 0.000000e+00, float 1.000000e+00
  %494 = select i1 %491, float 0.000000e+00, float 1.000000e+00
  %495 = select i1 %492, float 0.000000e+00, float 1.000000e+00
  %496 = fmul fast float %163, 0x3FB3D07220000000
  %497 = fmul fast float %164, 0x3FB3D07220000000
  %498 = fmul fast float %165, 0x3FB3D07220000000
  %499 = fadd fast float %163, 0x3FAC28F5C0000000
  %500 = fadd fast float %164, 0x3FAC28F5C0000000
  %501 = fadd fast float %165, 0x3FAC28F5C0000000
  %502 = fmul fast float %499, 0x3FEE54EDE0000000
  %503 = fmul fast float %500, 0x3FEE54EDE0000000
  %504 = fmul fast float %501, 0x3FEE54EDE0000000
  %505 = call float @dx.op.unary.f32(i32 23, float %502)  ; Log(value)
  %506 = call float @dx.op.unary.f32(i32 23, float %503)  ; Log(value)
  %507 = call float @dx.op.unary.f32(i32 23, float %504)  ; Log(value)
  %508 = fmul fast float %505, 0x4003333340000000
  %509 = fmul fast float %506, 0x4003333340000000
  %510 = fmul fast float %507, 0x4003333340000000
  %511 = call float @dx.op.unary.f32(i32 21, float %508)  ; Exp(value)
  %512 = call float @dx.op.unary.f32(i32 21, float %509)  ; Exp(value)
  %513 = call float @dx.op.unary.f32(i32 21, float %510)  ; Exp(value)
  %514 = fsub fast float %496, %511
  %515 = fsub fast float %497, %512
  %516 = fsub fast float %498, %513
  %517 = fmul fast float %514, %493
  %518 = fmul fast float %515, %494
  %519 = fmul fast float %516, %495
  %520 = fadd fast float %517, %511
  %521 = fadd fast float %518, %512
  %522 = fadd fast float %519, %513
  br label %591

; <label>:523                                     ; preds = %484
  %524 = fadd fast float %6, 1.000000e+00
  %525 = fadd fast float %7, 1.000000e+00
  %526 = fsub fast float 1.000000e+00, %6
  %527 = fmul fast float %10, %524
  %528 = fmul fast float %10, %525
  %529 = fmul fast float %10, %526
  %530 = fmul fast float %527, %163
  %531 = fmul fast float %528, %164
  %532 = fmul fast float %529, %165
  %533 = fcmp fast ult float %11, 5.000000e-01
  br i1 %533, label %559, label %534

; <label>:534                                     ; preds = %523
  %535 = fmul fast float %530, 0x4004147AE0000000
  %536 = fmul fast float %531, 0x4004147AE0000000
  %537 = fmul fast float %532, 0x4004147AE0000000
  %538 = fadd fast float %535, 0x3F9EB851E0000000
  %539 = fadd fast float %536, 0x3F9EB851E0000000
  %540 = fadd fast float %537, 0x3F9EB851E0000000
  %541 = fmul fast float %538, %530
  %542 = fmul fast float %539, %531
  %543 = fmul fast float %540, %532
  %544 = fmul fast float %530, 0x400370A3E0000000
  %545 = fmul fast float %531, 0x400370A3E0000000
  %546 = fmul fast float %532, 0x400370A3E0000000
  %547 = fadd fast float %544, 0x3FE2E147A0000000
  %548 = fadd fast float %545, 0x3FE2E147A0000000
  %549 = fadd fast float %546, 0x3FE2E147A0000000
  %550 = fmul fast float %547, %530
  %551 = fmul fast float %548, %531
  %552 = fmul fast float %549, %532
  %553 = fadd fast float %550, 0x3FC1EB8520000000
  %554 = fadd fast float %551, 0x3FC1EB8520000000
  %555 = fadd fast float %552, 0x3FC1EB8520000000
  %556 = fdiv fast float %541, %553
  %557 = fdiv fast float %542, %554
  %558 = fdiv fast float %543, %555
  br label %559

; <label>:559                                     ; preds = %534, %523
  %560 = phi float [ %556, %534 ], [ %530, %523 ]
  %561 = phi float [ %557, %534 ], [ %531, %523 ]
  %562 = phi float [ %558, %534 ], [ %532, %523 ]
  %563 = call float @dx.op.unary.f32(i32 7, float %560)  ; Saturate(value)
  %564 = call float @dx.op.unary.f32(i32 7, float %561)  ; Saturate(value)
  %565 = call float @dx.op.unary.f32(i32 7, float %562)  ; Saturate(value)
  %566 = call float @dx.op.dot3.f32(i32 55, float %563, float %564, float %565, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %567 = fsub fast float %563, %566
  %568 = fsub fast float %564, %566
  %569 = fsub fast float %565, %566
  %570 = fmul fast float %567, %9
  %571 = fmul fast float %568, %9
  %572 = fmul fast float %569, %9
  %573 = fadd fast float %570, %566
  %574 = fadd fast float %571, %566
  %575 = fadd fast float %572, %566
  %576 = call float @dx.op.unary.f32(i32 7, float %573)  ; Saturate(value)
  %577 = call float @dx.op.unary.f32(i32 7, float %574)  ; Saturate(value)
  %578 = call float @dx.op.unary.f32(i32 7, float %575)  ; Saturate(value)
  %579 = fadd fast float %576, 0xBFC70A3D80000000
  %580 = fadd fast float %577, 0xBFC70A3D80000000
  %581 = fadd fast float %578, 0xBFC70A3D80000000
  %582 = fmul fast float %579, %8
  %583 = fmul fast float %580, %8
  %584 = fmul fast float %581, %8
  %585 = fadd fast float %582, 0x3FC70A3D80000000
  %586 = fadd fast float %583, 0x3FC70A3D80000000
  %587 = fadd fast float %584, 0x3FC70A3D80000000
  %588 = call float @dx.op.unary.f32(i32 7, float %585)  ; Saturate(value)
  %589 = call float @dx.op.unary.f32(i32 7, float %586)  ; Saturate(value)
  %590 = call float @dx.op.unary.f32(i32 7, float %587)  ; Saturate(value)
  br label %591

; <label>:591                                     ; preds = %559, %489
  %592 = phi float [ %520, %489 ], [ %588, %559 ]
  %593 = phi float [ %521, %489 ], [ %589, %559 ]
  %594 = phi float [ %522, %489 ], [ %590, %559 ]
  %595 = fsub fast float -1.000000e+00, %151
  %596 = select i1 %167, float %595, float %151
  %597 = fsub fast float -1.000000e+00, %156
  %598 = select i1 %274, float %597, float %156
  %599 = fsub fast float -1.000000e+00, %161
  %600 = select i1 %381, float %599, float %161
  %601 = fsub fast float -1.000000e+00, %166
  %602 = select i1 %488, float %601, float %166
  %603 = fcmp fast ugt float %3, 0.000000e+00
  br i1 %603, label %604, label %5461

; <label>:604                                     ; preds = %591
  %605 = fcmp fast ult float %151, 0.000000e+00
  br i1 %605, label %1031, label %606

; <label>:606                                     ; preds = %604
  %607 = fsub fast float 1.000000e+00, %54
  %608 = fmul fast float %607, 0x3FA99999A0000000
  %609 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %608)  ; FMax(a,b)
  %610 = fsub fast float %56, %54
  %611 = call float @dx.op.unary.f32(i32 6, float %610)  ; FAbs(value)
  %612 = fdiv fast float %611, %609
  %613 = fsub fast float 1.000000e+00, %612
  %614 = call float @dx.op.unary.f32(i32 7, float %613)  ; Saturate(value)
  %615 = fcmp fast ugt float %614, 0.000000e+00
  br i1 %615, label %616, label %626

; <label>:616                                     ; preds = %606
  %617 = fsub fast float %378, %271
  %618 = fsub fast float %379, %272
  %619 = fsub fast float %380, %273
  %620 = fmul fast float %614, %617
  %621 = fmul fast float %614, %618
  %622 = fmul fast float %614, %619
  %623 = fadd fast float %620, %271
  %624 = fadd fast float %621, %272
  %625 = fadd fast float %622, %273
  br label %626

; <label>:626                                     ; preds = %616, %606
  %627 = phi float [ %623, %616 ], [ %271, %606 ]
  %628 = phi float [ %624, %616 ], [ %272, %606 ]
  %629 = phi float [ %625, %616 ], [ %273, %606 ]
  %630 = add i32 %27, -1
  %631 = call i32 @dx.op.binary.i32(i32 37, i32 %630, i32 0)  ; IMax(a,b)
  %632 = call i32 @dx.op.binary.i32(i32 38, i32 %631, i32 %31)  ; IMin(a,b)
  %633 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %632, i32 %36, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %634 = extractvalue %dx.types.ResRet.f32 %633, 0
  %635 = fsub fast float %634, %54
  %636 = call float @dx.op.unary.f32(i32 6, float %635)  ; FAbs(value)
  %637 = fdiv fast float %636, %609
  %638 = fsub fast float 1.000000e+00, %637
  %639 = call float @dx.op.unary.f32(i32 7, float %638)  ; Saturate(value)
  %640 = fcmp fast ugt float %639, 0.000000e+00
  br i1 %640, label %641, label %767

; <label>:641                                     ; preds = %626
  %642 = call i32 @dx.op.binary.i32(i32 37, i32 %632, i32 0)  ; IMax(a,b)
  %643 = call i32 @dx.op.binary.i32(i32 37, i32 %36, i32 0)  ; IMax(a,b)
  %644 = call i32 @dx.op.binary.i32(i32 38, i32 %642, i32 %31)  ; IMin(a,b)
  %645 = call i32 @dx.op.binary.i32(i32 38, i32 %643, i32 %32)  ; IMin(a,b)
  %646 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %644, i32 %645, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %647 = extractvalue %dx.types.ResRet.f32 %646, 0
  %648 = extractvalue %dx.types.ResRet.f32 %646, 1
  %649 = extractvalue %dx.types.ResRet.f32 %646, 2
  %650 = extractvalue %dx.types.ResRet.f32 %646, 3
  %651 = fcmp fast olt float %650, 0.000000e+00
  br i1 %651, label %652, label %686

; <label>:652                                     ; preds = %641
  %653 = fcmp fast ogt float %647, 0x3FA4B5DCC0000000
  %654 = fcmp fast ogt float %648, 0x3FA4B5DCC0000000
  %655 = fcmp fast ogt float %649, 0x3FA4B5DCC0000000
  %656 = select i1 %653, float 0.000000e+00, float 1.000000e+00
  %657 = select i1 %654, float 0.000000e+00, float 1.000000e+00
  %658 = select i1 %655, float 0.000000e+00, float 1.000000e+00
  %659 = fmul fast float %647, 0x3FB3D07220000000
  %660 = fmul fast float %648, 0x3FB3D07220000000
  %661 = fmul fast float %649, 0x3FB3D07220000000
  %662 = fadd fast float %647, 0x3FAC28F5C0000000
  %663 = fadd fast float %648, 0x3FAC28F5C0000000
  %664 = fadd fast float %649, 0x3FAC28F5C0000000
  %665 = fmul fast float %662, 0x3FEE54EDE0000000
  %666 = fmul fast float %663, 0x3FEE54EDE0000000
  %667 = fmul fast float %664, 0x3FEE54EDE0000000
  %668 = call float @dx.op.unary.f32(i32 23, float %665)  ; Log(value)
  %669 = call float @dx.op.unary.f32(i32 23, float %666)  ; Log(value)
  %670 = call float @dx.op.unary.f32(i32 23, float %667)  ; Log(value)
  %671 = fmul fast float %668, 0x4003333340000000
  %672 = fmul fast float %669, 0x4003333340000000
  %673 = fmul fast float %670, 0x4003333340000000
  %674 = call float @dx.op.unary.f32(i32 21, float %671)  ; Exp(value)
  %675 = call float @dx.op.unary.f32(i32 21, float %672)  ; Exp(value)
  %676 = call float @dx.op.unary.f32(i32 21, float %673)  ; Exp(value)
  %677 = fsub fast float %659, %674
  %678 = fsub fast float %660, %675
  %679 = fsub fast float %661, %676
  %680 = fmul fast float %677, %656
  %681 = fmul fast float %678, %657
  %682 = fmul fast float %679, %658
  %683 = fadd fast float %680, %674
  %684 = fadd fast float %681, %675
  %685 = fadd fast float %682, %676
  br label %754

; <label>:686                                     ; preds = %641
  %687 = fadd fast float %6, 1.000000e+00
  %688 = fadd fast float %7, 1.000000e+00
  %689 = fsub fast float 1.000000e+00, %6
  %690 = fmul fast float %10, %687
  %691 = fmul fast float %10, %688
  %692 = fmul fast float %10, %689
  %693 = fmul fast float %690, %647
  %694 = fmul fast float %691, %648
  %695 = fmul fast float %692, %649
  %696 = fcmp fast ult float %11, 5.000000e-01
  br i1 %696, label %722, label %697

; <label>:697                                     ; preds = %686
  %698 = fmul fast float %693, 0x4004147AE0000000
  %699 = fmul fast float %694, 0x4004147AE0000000
  %700 = fmul fast float %695, 0x4004147AE0000000
  %701 = fadd fast float %698, 0x3F9EB851E0000000
  %702 = fadd fast float %699, 0x3F9EB851E0000000
  %703 = fadd fast float %700, 0x3F9EB851E0000000
  %704 = fmul fast float %701, %693
  %705 = fmul fast float %702, %694
  %706 = fmul fast float %703, %695
  %707 = fmul fast float %693, 0x400370A3E0000000
  %708 = fmul fast float %694, 0x400370A3E0000000
  %709 = fmul fast float %695, 0x400370A3E0000000
  %710 = fadd fast float %707, 0x3FE2E147A0000000
  %711 = fadd fast float %708, 0x3FE2E147A0000000
  %712 = fadd fast float %709, 0x3FE2E147A0000000
  %713 = fmul fast float %710, %693
  %714 = fmul fast float %711, %694
  %715 = fmul fast float %712, %695
  %716 = fadd fast float %713, 0x3FC1EB8520000000
  %717 = fadd fast float %714, 0x3FC1EB8520000000
  %718 = fadd fast float %715, 0x3FC1EB8520000000
  %719 = fdiv fast float %704, %716
  %720 = fdiv fast float %705, %717
  %721 = fdiv fast float %706, %718
  br label %722

; <label>:722                                     ; preds = %697, %686
  %723 = phi float [ %719, %697 ], [ %693, %686 ]
  %724 = phi float [ %720, %697 ], [ %694, %686 ]
  %725 = phi float [ %721, %697 ], [ %695, %686 ]
  %726 = call float @dx.op.unary.f32(i32 7, float %723)  ; Saturate(value)
  %727 = call float @dx.op.unary.f32(i32 7, float %724)  ; Saturate(value)
  %728 = call float @dx.op.unary.f32(i32 7, float %725)  ; Saturate(value)
  %729 = call float @dx.op.dot3.f32(i32 55, float %726, float %727, float %728, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %730 = fsub fast float %726, %729
  %731 = fsub fast float %727, %729
  %732 = fsub fast float %728, %729
  %733 = fmul fast float %730, %9
  %734 = fmul fast float %731, %9
  %735 = fmul fast float %732, %9
  %736 = fadd fast float %733, %729
  %737 = fadd fast float %734, %729
  %738 = fadd fast float %735, %729
  %739 = call float @dx.op.unary.f32(i32 7, float %736)  ; Saturate(value)
  %740 = call float @dx.op.unary.f32(i32 7, float %737)  ; Saturate(value)
  %741 = call float @dx.op.unary.f32(i32 7, float %738)  ; Saturate(value)
  %742 = fadd fast float %739, 0xBFC70A3D80000000
  %743 = fadd fast float %740, 0xBFC70A3D80000000
  %744 = fadd fast float %741, 0xBFC70A3D80000000
  %745 = fmul fast float %742, %8
  %746 = fmul fast float %743, %8
  %747 = fmul fast float %744, %8
  %748 = fadd fast float %745, 0x3FC70A3D80000000
  %749 = fadd fast float %746, 0x3FC70A3D80000000
  %750 = fadd fast float %747, 0x3FC70A3D80000000
  %751 = call float @dx.op.unary.f32(i32 7, float %748)  ; Saturate(value)
  %752 = call float @dx.op.unary.f32(i32 7, float %749)  ; Saturate(value)
  %753 = call float @dx.op.unary.f32(i32 7, float %750)  ; Saturate(value)
  br label %754

; <label>:754                                     ; preds = %722, %652
  %755 = phi float [ %683, %652 ], [ %751, %722 ]
  %756 = phi float [ %684, %652 ], [ %752, %722 ]
  %757 = phi float [ %685, %652 ], [ %753, %722 ]
  %758 = fsub fast float %755, %271
  %759 = fsub fast float %756, %272
  %760 = fsub fast float %757, %273
  %761 = fmul fast float %758, %639
  %762 = fmul fast float %759, %639
  %763 = fmul fast float %760, %639
  %764 = fadd fast float %761, %271
  %765 = fadd fast float %762, %272
  %766 = fadd fast float %763, %273
  br label %767

; <label>:767                                     ; preds = %754, %626
  %768 = phi float [ %764, %754 ], [ %271, %626 ]
  %769 = phi float [ %765, %754 ], [ %272, %626 ]
  %770 = phi float [ %766, %754 ], [ %273, %626 ]
  %771 = fsub fast float %58, %54
  %772 = call float @dx.op.unary.f32(i32 6, float %771)  ; FAbs(value)
  %773 = fdiv fast float %772, %609
  %774 = fsub fast float 1.000000e+00, %773
  %775 = call float @dx.op.unary.f32(i32 7, float %774)  ; Saturate(value)
  %776 = fcmp fast ugt float %775, 0.000000e+00
  br i1 %776, label %777, label %787

; <label>:777                                     ; preds = %767
  %778 = fsub fast float %485, %271
  %779 = fsub fast float %486, %272
  %780 = fsub fast float %487, %273
  %781 = fmul fast float %775, %778
  %782 = fmul fast float %775, %779
  %783 = fmul fast float %775, %780
  %784 = fadd fast float %781, %271
  %785 = fadd fast float %782, %272
  %786 = fadd fast float %783, %273
  br label %787

; <label>:787                                     ; preds = %777, %767
  %788 = phi float [ %784, %777 ], [ %271, %767 ]
  %789 = phi float [ %785, %777 ], [ %272, %767 ]
  %790 = phi float [ %786, %777 ], [ %273, %767 ]
  %791 = add i32 %28, -1
  %792 = call i32 @dx.op.binary.i32(i32 37, i32 %791, i32 0)  ; IMax(a,b)
  %793 = call i32 @dx.op.binary.i32(i32 38, i32 %792, i32 %32)  ; IMin(a,b)
  %794 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %35, i32 %793, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %795 = extractvalue %dx.types.ResRet.f32 %794, 0
  %796 = fsub fast float %795, %54
  %797 = call float @dx.op.unary.f32(i32 6, float %796)  ; FAbs(value)
  %798 = fdiv fast float %797, %609
  %799 = fsub fast float 1.000000e+00, %798
  %800 = call float @dx.op.unary.f32(i32 7, float %799)  ; Saturate(value)
  %801 = fcmp fast ugt float %800, 0.000000e+00
  br i1 %801, label %802, label %928

; <label>:802                                     ; preds = %787
  %803 = call i32 @dx.op.binary.i32(i32 37, i32 %35, i32 0)  ; IMax(a,b)
  %804 = call i32 @dx.op.binary.i32(i32 37, i32 %793, i32 0)  ; IMax(a,b)
  %805 = call i32 @dx.op.binary.i32(i32 38, i32 %803, i32 %31)  ; IMin(a,b)
  %806 = call i32 @dx.op.binary.i32(i32 38, i32 %804, i32 %32)  ; IMin(a,b)
  %807 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %805, i32 %806, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %808 = extractvalue %dx.types.ResRet.f32 %807, 0
  %809 = extractvalue %dx.types.ResRet.f32 %807, 1
  %810 = extractvalue %dx.types.ResRet.f32 %807, 2
  %811 = extractvalue %dx.types.ResRet.f32 %807, 3
  %812 = fcmp fast olt float %811, 0.000000e+00
  br i1 %812, label %813, label %847

; <label>:813                                     ; preds = %802
  %814 = fcmp fast ogt float %808, 0x3FA4B5DCC0000000
  %815 = fcmp fast ogt float %809, 0x3FA4B5DCC0000000
  %816 = fcmp fast ogt float %810, 0x3FA4B5DCC0000000
  %817 = select i1 %814, float 0.000000e+00, float 1.000000e+00
  %818 = select i1 %815, float 0.000000e+00, float 1.000000e+00
  %819 = select i1 %816, float 0.000000e+00, float 1.000000e+00
  %820 = fmul fast float %808, 0x3FB3D07220000000
  %821 = fmul fast float %809, 0x3FB3D07220000000
  %822 = fmul fast float %810, 0x3FB3D07220000000
  %823 = fadd fast float %808, 0x3FAC28F5C0000000
  %824 = fadd fast float %809, 0x3FAC28F5C0000000
  %825 = fadd fast float %810, 0x3FAC28F5C0000000
  %826 = fmul fast float %823, 0x3FEE54EDE0000000
  %827 = fmul fast float %824, 0x3FEE54EDE0000000
  %828 = fmul fast float %825, 0x3FEE54EDE0000000
  %829 = call float @dx.op.unary.f32(i32 23, float %826)  ; Log(value)
  %830 = call float @dx.op.unary.f32(i32 23, float %827)  ; Log(value)
  %831 = call float @dx.op.unary.f32(i32 23, float %828)  ; Log(value)
  %832 = fmul fast float %829, 0x4003333340000000
  %833 = fmul fast float %830, 0x4003333340000000
  %834 = fmul fast float %831, 0x4003333340000000
  %835 = call float @dx.op.unary.f32(i32 21, float %832)  ; Exp(value)
  %836 = call float @dx.op.unary.f32(i32 21, float %833)  ; Exp(value)
  %837 = call float @dx.op.unary.f32(i32 21, float %834)  ; Exp(value)
  %838 = fsub fast float %820, %835
  %839 = fsub fast float %821, %836
  %840 = fsub fast float %822, %837
  %841 = fmul fast float %838, %817
  %842 = fmul fast float %839, %818
  %843 = fmul fast float %840, %819
  %844 = fadd fast float %841, %835
  %845 = fadd fast float %842, %836
  %846 = fadd fast float %843, %837
  br label %915

; <label>:847                                     ; preds = %802
  %848 = fadd fast float %6, 1.000000e+00
  %849 = fadd fast float %7, 1.000000e+00
  %850 = fsub fast float 1.000000e+00, %6
  %851 = fmul fast float %10, %848
  %852 = fmul fast float %10, %849
  %853 = fmul fast float %10, %850
  %854 = fmul fast float %851, %808
  %855 = fmul fast float %852, %809
  %856 = fmul fast float %853, %810
  %857 = fcmp fast ult float %11, 5.000000e-01
  br i1 %857, label %883, label %858

; <label>:858                                     ; preds = %847
  %859 = fmul fast float %854, 0x4004147AE0000000
  %860 = fmul fast float %855, 0x4004147AE0000000
  %861 = fmul fast float %856, 0x4004147AE0000000
  %862 = fadd fast float %859, 0x3F9EB851E0000000
  %863 = fadd fast float %860, 0x3F9EB851E0000000
  %864 = fadd fast float %861, 0x3F9EB851E0000000
  %865 = fmul fast float %862, %854
  %866 = fmul fast float %863, %855
  %867 = fmul fast float %864, %856
  %868 = fmul fast float %854, 0x400370A3E0000000
  %869 = fmul fast float %855, 0x400370A3E0000000
  %870 = fmul fast float %856, 0x400370A3E0000000
  %871 = fadd fast float %868, 0x3FE2E147A0000000
  %872 = fadd fast float %869, 0x3FE2E147A0000000
  %873 = fadd fast float %870, 0x3FE2E147A0000000
  %874 = fmul fast float %871, %854
  %875 = fmul fast float %872, %855
  %876 = fmul fast float %873, %856
  %877 = fadd fast float %874, 0x3FC1EB8520000000
  %878 = fadd fast float %875, 0x3FC1EB8520000000
  %879 = fadd fast float %876, 0x3FC1EB8520000000
  %880 = fdiv fast float %865, %877
  %881 = fdiv fast float %866, %878
  %882 = fdiv fast float %867, %879
  br label %883

; <label>:883                                     ; preds = %858, %847
  %884 = phi float [ %880, %858 ], [ %854, %847 ]
  %885 = phi float [ %881, %858 ], [ %855, %847 ]
  %886 = phi float [ %882, %858 ], [ %856, %847 ]
  %887 = call float @dx.op.unary.f32(i32 7, float %884)  ; Saturate(value)
  %888 = call float @dx.op.unary.f32(i32 7, float %885)  ; Saturate(value)
  %889 = call float @dx.op.unary.f32(i32 7, float %886)  ; Saturate(value)
  %890 = call float @dx.op.dot3.f32(i32 55, float %887, float %888, float %889, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %891 = fsub fast float %887, %890
  %892 = fsub fast float %888, %890
  %893 = fsub fast float %889, %890
  %894 = fmul fast float %891, %9
  %895 = fmul fast float %892, %9
  %896 = fmul fast float %893, %9
  %897 = fadd fast float %894, %890
  %898 = fadd fast float %895, %890
  %899 = fadd fast float %896, %890
  %900 = call float @dx.op.unary.f32(i32 7, float %897)  ; Saturate(value)
  %901 = call float @dx.op.unary.f32(i32 7, float %898)  ; Saturate(value)
  %902 = call float @dx.op.unary.f32(i32 7, float %899)  ; Saturate(value)
  %903 = fadd fast float %900, 0xBFC70A3D80000000
  %904 = fadd fast float %901, 0xBFC70A3D80000000
  %905 = fadd fast float %902, 0xBFC70A3D80000000
  %906 = fmul fast float %903, %8
  %907 = fmul fast float %904, %8
  %908 = fmul fast float %905, %8
  %909 = fadd fast float %906, 0x3FC70A3D80000000
  %910 = fadd fast float %907, 0x3FC70A3D80000000
  %911 = fadd fast float %908, 0x3FC70A3D80000000
  %912 = call float @dx.op.unary.f32(i32 7, float %909)  ; Saturate(value)
  %913 = call float @dx.op.unary.f32(i32 7, float %910)  ; Saturate(value)
  %914 = call float @dx.op.unary.f32(i32 7, float %911)  ; Saturate(value)
  br label %915

; <label>:915                                     ; preds = %883, %813
  %916 = phi float [ %844, %813 ], [ %912, %883 ]
  %917 = phi float [ %845, %813 ], [ %913, %883 ]
  %918 = phi float [ %846, %813 ], [ %914, %883 ]
  %919 = fsub fast float %916, %271
  %920 = fsub fast float %917, %272
  %921 = fsub fast float %918, %273
  %922 = fmul fast float %919, %800
  %923 = fmul fast float %920, %800
  %924 = fmul fast float %921, %800
  %925 = fadd fast float %922, %271
  %926 = fadd fast float %923, %272
  %927 = fadd fast float %924, %273
  br label %928

; <label>:928                                     ; preds = %915, %787
  %929 = phi float [ %925, %915 ], [ %271, %787 ]
  %930 = phi float [ %926, %915 ], [ %272, %787 ]
  %931 = phi float [ %927, %915 ], [ %273, %787 ]
  %932 = call float @dx.op.binary.f32(i32 36, float %768, float %627)  ; FMin(a,b)
  %933 = call float @dx.op.binary.f32(i32 36, float %769, float %628)  ; FMin(a,b)
  %934 = call float @dx.op.binary.f32(i32 36, float %770, float %629)  ; FMin(a,b)
  %935 = call float @dx.op.binary.f32(i32 36, float %929, float %788)  ; FMin(a,b)
  %936 = call float @dx.op.binary.f32(i32 36, float %930, float %789)  ; FMin(a,b)
  %937 = call float @dx.op.binary.f32(i32 36, float %931, float %790)  ; FMin(a,b)
  %938 = call float @dx.op.binary.f32(i32 36, float %935, float %932)  ; FMin(a,b)
  %939 = call float @dx.op.binary.f32(i32 36, float %936, float %933)  ; FMin(a,b)
  %940 = call float @dx.op.binary.f32(i32 36, float %937, float %934)  ; FMin(a,b)
  %941 = call float @dx.op.binary.f32(i32 36, float %271, float %938)  ; FMin(a,b)
  %942 = call float @dx.op.binary.f32(i32 36, float %272, float %939)  ; FMin(a,b)
  %943 = call float @dx.op.binary.f32(i32 36, float %273, float %940)  ; FMin(a,b)
  %944 = call float @dx.op.binary.f32(i32 35, float %768, float %627)  ; FMax(a,b)
  %945 = call float @dx.op.binary.f32(i32 35, float %769, float %628)  ; FMax(a,b)
  %946 = call float @dx.op.binary.f32(i32 35, float %770, float %629)  ; FMax(a,b)
  %947 = call float @dx.op.binary.f32(i32 35, float %929, float %788)  ; FMax(a,b)
  %948 = call float @dx.op.binary.f32(i32 35, float %930, float %789)  ; FMax(a,b)
  %949 = call float @dx.op.binary.f32(i32 35, float %931, float %790)  ; FMax(a,b)
  %950 = call float @dx.op.binary.f32(i32 35, float %947, float %944)  ; FMax(a,b)
  %951 = call float @dx.op.binary.f32(i32 35, float %948, float %945)  ; FMax(a,b)
  %952 = call float @dx.op.binary.f32(i32 35, float %949, float %946)  ; FMax(a,b)
  %953 = call float @dx.op.binary.f32(i32 35, float %271, float %950)  ; FMax(a,b)
  %954 = call float @dx.op.binary.f32(i32 35, float %272, float %951)  ; FMax(a,b)
  %955 = call float @dx.op.binary.f32(i32 35, float %273, float %952)  ; FMax(a,b)
  %956 = fsub fast float %953, %941
  %957 = fsub fast float %954, %942
  %958 = fsub fast float %955, %943
  %959 = call float @dx.op.unary.f32(i32 6, float %956)  ; FAbs(value)
  %960 = call float @dx.op.unary.f32(i32 6, float %957)  ; FAbs(value)
  %961 = call float @dx.op.unary.f32(i32 6, float %958)  ; FAbs(value)
  %962 = call float @dx.op.binary.f32(i32 35, float %960, float %961)  ; FMax(a,b)
  %963 = call float @dx.op.binary.f32(i32 35, float %959, float %962)  ; FMax(a,b)
  %964 = call float @dx.op.binary.f32(i32 35, float %954, float %955)  ; FMax(a,b)
  %965 = call float @dx.op.binary.f32(i32 35, float %953, float %964)  ; FMax(a,b)
  %966 = fmul fast float %965, 1.250000e-01
  %967 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %966)  ; FMax(a,b)
  %968 = fcmp fast ogt float %963, %967
  br i1 %968, label %969, label %1031

; <label>:969                                     ; preds = %928
  %970 = fsub fast float %929, %788
  %971 = fsub fast float %930, %789
  %972 = fsub fast float %931, %790
  %973 = call float @dx.op.unary.f32(i32 6, float %970)  ; FAbs(value)
  %974 = call float @dx.op.unary.f32(i32 6, float %971)  ; FAbs(value)
  %975 = call float @dx.op.unary.f32(i32 6, float %972)  ; FAbs(value)
  %976 = call float @dx.op.binary.f32(i32 35, float %974, float %975)  ; FMax(a,b)
  %977 = call float @dx.op.binary.f32(i32 35, float %973, float %976)  ; FMax(a,b)
  %978 = fsub fast float %768, %627
  %979 = fsub fast float %769, %628
  %980 = fsub fast float %770, %629
  %981 = call float @dx.op.unary.f32(i32 6, float %978)  ; FAbs(value)
  %982 = call float @dx.op.unary.f32(i32 6, float %979)  ; FAbs(value)
  %983 = call float @dx.op.unary.f32(i32 6, float %980)  ; FAbs(value)
  %984 = call float @dx.op.binary.f32(i32 35, float %982, float %983)  ; FMax(a,b)
  %985 = call float @dx.op.binary.f32(i32 35, float %981, float %984)  ; FMax(a,b)
  %986 = fcmp fast olt float %977, %985
  %987 = select i1 %986, float %929, float %768
  %988 = select i1 %986, float %930, float %769
  %989 = select i1 %986, float %931, float %770
  %990 = select i1 %986, float %788, float %627
  %991 = select i1 %986, float %789, float %628
  %992 = select i1 %986, float %790, float %629
  %993 = fsub fast float %271, %990
  %994 = fsub fast float %272, %991
  %995 = fsub fast float %273, %992
  %996 = fsub fast float %271, %987
  %997 = fsub fast float %272, %988
  %998 = fsub fast float %273, %989
  %999 = call float @dx.op.dot3.f32(i32 55, float %996, float %997, float %998, float %993, float %994, float %995)  ; Dot3(ax,ay,az,bx,by,bz)
  %1000 = fcmp fast ogt float %999, 0.000000e+00
  br i1 %1000, label %1001, label %1012

; <label>:1001                                    ; preds = %969
  %1002 = fsub fast float %987, %990
  %1003 = fsub fast float %988, %991
  %1004 = fsub fast float %989, %992
  %1005 = call float @dx.op.unary.f32(i32 6, float %1002)  ; FAbs(value)
  %1006 = call float @dx.op.unary.f32(i32 6, float %1003)  ; FAbs(value)
  %1007 = call float @dx.op.unary.f32(i32 6, float %1004)  ; FAbs(value)
  %1008 = call float @dx.op.binary.f32(i32 35, float %1006, float %1007)  ; FMax(a,b)
  %1009 = call float @dx.op.binary.f32(i32 35, float %1005, float %1008)  ; FMax(a,b)
  %1010 = fmul fast float %963, 2.500000e-01
  %1011 = fcmp fast olt float %1009, %1010
  br label %1012

; <label>:1012                                    ; preds = %1001, %969
  %1013 = phi i1 [ false, %969 ], [ %1011, %1001 ]
  %1014 = select i1 %1013, float 5.000000e-01, float 1.000000e+00
  %1015 = fmul fast float %1014, %3
  %1016 = fadd fast float %987, %990
  %1017 = fadd fast float %988, %991
  %1018 = fadd fast float %989, %992
  %1019 = fmul fast float %1016, 5.000000e-01
  %1020 = fmul fast float %1017, 5.000000e-01
  %1021 = fmul fast float %1018, 5.000000e-01
  %1022 = fsub fast float %1019, %271
  %1023 = fsub fast float %1020, %272
  %1024 = fsub fast float %1021, %273
  %1025 = fmul fast float %1015, %1022
  %1026 = fmul fast float %1015, %1023
  %1027 = fmul fast float %1015, %1024
  %1028 = fadd fast float %1025, %271
  %1029 = fadd fast float %1026, %272
  %1030 = fadd fast float %1027, %273
  br label %1031

; <label>:1031                                    ; preds = %1012, %928, %604
  %1032 = phi float [ %271, %604 ], [ %1028, %1012 ], [ %271, %928 ]
  %1033 = phi float [ %272, %604 ], [ %1029, %1012 ], [ %272, %928 ]
  %1034 = phi float [ %273, %604 ], [ %1030, %1012 ], [ %273, %928 ]
  %1035 = fcmp fast ult float %156, 0.000000e+00
  br i1 %1035, label %1461, label %1036

; <label>:1036                                    ; preds = %1031
  %1037 = add i32 %27, 2
  %1038 = call i32 @dx.op.binary.i32(i32 37, i32 %1037, i32 0)  ; IMax(a,b)
  %1039 = call i32 @dx.op.binary.i32(i32 38, i32 %1038, i32 %31)  ; IMin(a,b)
  %1040 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1039, i32 %36, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1041 = extractvalue %dx.types.ResRet.f32 %1040, 0
  %1042 = fsub fast float 1.000000e+00, %56
  %1043 = fmul fast float %1042, 0x3FA99999A0000000
  %1044 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %1043)  ; FMax(a,b)
  %1045 = fsub fast float %1041, %56
  %1046 = call float @dx.op.unary.f32(i32 6, float %1045)  ; FAbs(value)
  %1047 = fdiv fast float %1046, %1044
  %1048 = fsub fast float 1.000000e+00, %1047
  %1049 = call float @dx.op.unary.f32(i32 7, float %1048)  ; Saturate(value)
  %1050 = fcmp fast ugt float %1049, 0.000000e+00
  br i1 %1050, label %1051, label %1177

; <label>:1051                                    ; preds = %1036
  %1052 = call i32 @dx.op.binary.i32(i32 37, i32 %1039, i32 0)  ; IMax(a,b)
  %1053 = call i32 @dx.op.binary.i32(i32 37, i32 %36, i32 0)  ; IMax(a,b)
  %1054 = call i32 @dx.op.binary.i32(i32 38, i32 %1052, i32 %31)  ; IMin(a,b)
  %1055 = call i32 @dx.op.binary.i32(i32 38, i32 %1053, i32 %32)  ; IMin(a,b)
  %1056 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1054, i32 %1055, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1057 = extractvalue %dx.types.ResRet.f32 %1056, 0
  %1058 = extractvalue %dx.types.ResRet.f32 %1056, 1
  %1059 = extractvalue %dx.types.ResRet.f32 %1056, 2
  %1060 = extractvalue %dx.types.ResRet.f32 %1056, 3
  %1061 = fcmp fast olt float %1060, 0.000000e+00
  br i1 %1061, label %1062, label %1096

; <label>:1062                                    ; preds = %1051
  %1063 = fcmp fast ogt float %1057, 0x3FA4B5DCC0000000
  %1064 = fcmp fast ogt float %1058, 0x3FA4B5DCC0000000
  %1065 = fcmp fast ogt float %1059, 0x3FA4B5DCC0000000
  %1066 = select i1 %1063, float 0.000000e+00, float 1.000000e+00
  %1067 = select i1 %1064, float 0.000000e+00, float 1.000000e+00
  %1068 = select i1 %1065, float 0.000000e+00, float 1.000000e+00
  %1069 = fmul fast float %1057, 0x3FB3D07220000000
  %1070 = fmul fast float %1058, 0x3FB3D07220000000
  %1071 = fmul fast float %1059, 0x3FB3D07220000000
  %1072 = fadd fast float %1057, 0x3FAC28F5C0000000
  %1073 = fadd fast float %1058, 0x3FAC28F5C0000000
  %1074 = fadd fast float %1059, 0x3FAC28F5C0000000
  %1075 = fmul fast float %1072, 0x3FEE54EDE0000000
  %1076 = fmul fast float %1073, 0x3FEE54EDE0000000
  %1077 = fmul fast float %1074, 0x3FEE54EDE0000000
  %1078 = call float @dx.op.unary.f32(i32 23, float %1075)  ; Log(value)
  %1079 = call float @dx.op.unary.f32(i32 23, float %1076)  ; Log(value)
  %1080 = call float @dx.op.unary.f32(i32 23, float %1077)  ; Log(value)
  %1081 = fmul fast float %1078, 0x4003333340000000
  %1082 = fmul fast float %1079, 0x4003333340000000
  %1083 = fmul fast float %1080, 0x4003333340000000
  %1084 = call float @dx.op.unary.f32(i32 21, float %1081)  ; Exp(value)
  %1085 = call float @dx.op.unary.f32(i32 21, float %1082)  ; Exp(value)
  %1086 = call float @dx.op.unary.f32(i32 21, float %1083)  ; Exp(value)
  %1087 = fsub fast float %1069, %1084
  %1088 = fsub fast float %1070, %1085
  %1089 = fsub fast float %1071, %1086
  %1090 = fmul fast float %1087, %1066
  %1091 = fmul fast float %1088, %1067
  %1092 = fmul fast float %1089, %1068
  %1093 = fadd fast float %1090, %1084
  %1094 = fadd fast float %1091, %1085
  %1095 = fadd fast float %1092, %1086
  br label %1164

; <label>:1096                                    ; preds = %1051
  %1097 = fadd fast float %6, 1.000000e+00
  %1098 = fadd fast float %7, 1.000000e+00
  %1099 = fsub fast float 1.000000e+00, %6
  %1100 = fmul fast float %10, %1097
  %1101 = fmul fast float %10, %1098
  %1102 = fmul fast float %10, %1099
  %1103 = fmul fast float %1100, %1057
  %1104 = fmul fast float %1101, %1058
  %1105 = fmul fast float %1102, %1059
  %1106 = fcmp fast ult float %11, 5.000000e-01
  br i1 %1106, label %1132, label %1107

; <label>:1107                                    ; preds = %1096
  %1108 = fmul fast float %1103, 0x4004147AE0000000
  %1109 = fmul fast float %1104, 0x4004147AE0000000
  %1110 = fmul fast float %1105, 0x4004147AE0000000
  %1111 = fadd fast float %1108, 0x3F9EB851E0000000
  %1112 = fadd fast float %1109, 0x3F9EB851E0000000
  %1113 = fadd fast float %1110, 0x3F9EB851E0000000
  %1114 = fmul fast float %1111, %1103
  %1115 = fmul fast float %1112, %1104
  %1116 = fmul fast float %1113, %1105
  %1117 = fmul fast float %1103, 0x400370A3E0000000
  %1118 = fmul fast float %1104, 0x400370A3E0000000
  %1119 = fmul fast float %1105, 0x400370A3E0000000
  %1120 = fadd fast float %1117, 0x3FE2E147A0000000
  %1121 = fadd fast float %1118, 0x3FE2E147A0000000
  %1122 = fadd fast float %1119, 0x3FE2E147A0000000
  %1123 = fmul fast float %1120, %1103
  %1124 = fmul fast float %1121, %1104
  %1125 = fmul fast float %1122, %1105
  %1126 = fadd fast float %1123, 0x3FC1EB8520000000
  %1127 = fadd fast float %1124, 0x3FC1EB8520000000
  %1128 = fadd fast float %1125, 0x3FC1EB8520000000
  %1129 = fdiv fast float %1114, %1126
  %1130 = fdiv fast float %1115, %1127
  %1131 = fdiv fast float %1116, %1128
  br label %1132

; <label>:1132                                    ; preds = %1107, %1096
  %1133 = phi float [ %1129, %1107 ], [ %1103, %1096 ]
  %1134 = phi float [ %1130, %1107 ], [ %1104, %1096 ]
  %1135 = phi float [ %1131, %1107 ], [ %1105, %1096 ]
  %1136 = call float @dx.op.unary.f32(i32 7, float %1133)  ; Saturate(value)
  %1137 = call float @dx.op.unary.f32(i32 7, float %1134)  ; Saturate(value)
  %1138 = call float @dx.op.unary.f32(i32 7, float %1135)  ; Saturate(value)
  %1139 = call float @dx.op.dot3.f32(i32 55, float %1136, float %1137, float %1138, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1140 = fsub fast float %1136, %1139
  %1141 = fsub fast float %1137, %1139
  %1142 = fsub fast float %1138, %1139
  %1143 = fmul fast float %1140, %9
  %1144 = fmul fast float %1141, %9
  %1145 = fmul fast float %1142, %9
  %1146 = fadd fast float %1143, %1139
  %1147 = fadd fast float %1144, %1139
  %1148 = fadd fast float %1145, %1139
  %1149 = call float @dx.op.unary.f32(i32 7, float %1146)  ; Saturate(value)
  %1150 = call float @dx.op.unary.f32(i32 7, float %1147)  ; Saturate(value)
  %1151 = call float @dx.op.unary.f32(i32 7, float %1148)  ; Saturate(value)
  %1152 = fadd fast float %1149, 0xBFC70A3D80000000
  %1153 = fadd fast float %1150, 0xBFC70A3D80000000
  %1154 = fadd fast float %1151, 0xBFC70A3D80000000
  %1155 = fmul fast float %1152, %8
  %1156 = fmul fast float %1153, %8
  %1157 = fmul fast float %1154, %8
  %1158 = fadd fast float %1155, 0x3FC70A3D80000000
  %1159 = fadd fast float %1156, 0x3FC70A3D80000000
  %1160 = fadd fast float %1157, 0x3FC70A3D80000000
  %1161 = call float @dx.op.unary.f32(i32 7, float %1158)  ; Saturate(value)
  %1162 = call float @dx.op.unary.f32(i32 7, float %1159)  ; Saturate(value)
  %1163 = call float @dx.op.unary.f32(i32 7, float %1160)  ; Saturate(value)
  br label %1164

; <label>:1164                                    ; preds = %1132, %1062
  %1165 = phi float [ %1093, %1062 ], [ %1161, %1132 ]
  %1166 = phi float [ %1094, %1062 ], [ %1162, %1132 ]
  %1167 = phi float [ %1095, %1062 ], [ %1163, %1132 ]
  %1168 = fsub fast float %1165, %378
  %1169 = fsub fast float %1166, %379
  %1170 = fsub fast float %1167, %380
  %1171 = fmul fast float %1168, %1049
  %1172 = fmul fast float %1169, %1049
  %1173 = fmul fast float %1170, %1049
  %1174 = fadd fast float %1171, %378
  %1175 = fadd fast float %1172, %379
  %1176 = fadd fast float %1173, %380
  br label %1177

; <label>:1177                                    ; preds = %1164, %1036
  %1178 = phi float [ %1174, %1164 ], [ %378, %1036 ]
  %1179 = phi float [ %1175, %1164 ], [ %379, %1036 ]
  %1180 = phi float [ %1176, %1164 ], [ %380, %1036 ]
  %1181 = fsub fast float %54, %56
  %1182 = call float @dx.op.unary.f32(i32 6, float %1181)  ; FAbs(value)
  %1183 = fdiv fast float %1182, %1044
  %1184 = fsub fast float 1.000000e+00, %1183
  %1185 = call float @dx.op.unary.f32(i32 7, float %1184)  ; Saturate(value)
  %1186 = fcmp fast ugt float %1185, 0.000000e+00
  br i1 %1186, label %1187, label %1197

; <label>:1187                                    ; preds = %1177
  %1188 = fsub fast float %271, %378
  %1189 = fsub fast float %272, %379
  %1190 = fsub fast float %273, %380
  %1191 = fmul fast float %1185, %1188
  %1192 = fmul fast float %1185, %1189
  %1193 = fmul fast float %1185, %1190
  %1194 = fadd fast float %1191, %378
  %1195 = fadd fast float %1192, %379
  %1196 = fadd fast float %1193, %380
  br label %1197

; <label>:1197                                    ; preds = %1187, %1177
  %1198 = phi float [ %1194, %1187 ], [ %378, %1177 ]
  %1199 = phi float [ %1195, %1187 ], [ %379, %1177 ]
  %1200 = phi float [ %1196, %1187 ], [ %380, %1177 ]
  %1201 = fsub fast float %60, %56
  %1202 = call float @dx.op.unary.f32(i32 6, float %1201)  ; FAbs(value)
  %1203 = fdiv fast float %1202, %1044
  %1204 = fsub fast float 1.000000e+00, %1203
  %1205 = call float @dx.op.unary.f32(i32 7, float %1204)  ; Saturate(value)
  %1206 = fcmp fast ugt float %1205, 0.000000e+00
  br i1 %1206, label %1207, label %1217

; <label>:1207                                    ; preds = %1197
  %1208 = fsub fast float %592, %378
  %1209 = fsub fast float %593, %379
  %1210 = fsub fast float %594, %380
  %1211 = fmul fast float %1205, %1208
  %1212 = fmul fast float %1205, %1209
  %1213 = fmul fast float %1205, %1210
  %1214 = fadd fast float %1211, %378
  %1215 = fadd fast float %1212, %379
  %1216 = fadd fast float %1213, %380
  br label %1217

; <label>:1217                                    ; preds = %1207, %1197
  %1218 = phi float [ %1214, %1207 ], [ %378, %1197 ]
  %1219 = phi float [ %1215, %1207 ], [ %379, %1197 ]
  %1220 = phi float [ %1216, %1207 ], [ %380, %1197 ]
  %1221 = add i32 %28, -1
  %1222 = call i32 @dx.op.binary.i32(i32 37, i32 %1221, i32 0)  ; IMax(a,b)
  %1223 = call i32 @dx.op.binary.i32(i32 38, i32 %1222, i32 %32)  ; IMin(a,b)
  %1224 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %39, i32 %1223, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1225 = extractvalue %dx.types.ResRet.f32 %1224, 0
  %1226 = fsub fast float %1225, %56
  %1227 = call float @dx.op.unary.f32(i32 6, float %1226)  ; FAbs(value)
  %1228 = fdiv fast float %1227, %1044
  %1229 = fsub fast float 1.000000e+00, %1228
  %1230 = call float @dx.op.unary.f32(i32 7, float %1229)  ; Saturate(value)
  %1231 = fcmp fast ugt float %1230, 0.000000e+00
  br i1 %1231, label %1232, label %1358

; <label>:1232                                    ; preds = %1217
  %1233 = call i32 @dx.op.binary.i32(i32 37, i32 %39, i32 0)  ; IMax(a,b)
  %1234 = call i32 @dx.op.binary.i32(i32 37, i32 %1223, i32 0)  ; IMax(a,b)
  %1235 = call i32 @dx.op.binary.i32(i32 38, i32 %1233, i32 %31)  ; IMin(a,b)
  %1236 = call i32 @dx.op.binary.i32(i32 38, i32 %1234, i32 %32)  ; IMin(a,b)
  %1237 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1235, i32 %1236, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1238 = extractvalue %dx.types.ResRet.f32 %1237, 0
  %1239 = extractvalue %dx.types.ResRet.f32 %1237, 1
  %1240 = extractvalue %dx.types.ResRet.f32 %1237, 2
  %1241 = extractvalue %dx.types.ResRet.f32 %1237, 3
  %1242 = fcmp fast olt float %1241, 0.000000e+00
  br i1 %1242, label %1243, label %1277

; <label>:1243                                    ; preds = %1232
  %1244 = fcmp fast ogt float %1238, 0x3FA4B5DCC0000000
  %1245 = fcmp fast ogt float %1239, 0x3FA4B5DCC0000000
  %1246 = fcmp fast ogt float %1240, 0x3FA4B5DCC0000000
  %1247 = select i1 %1244, float 0.000000e+00, float 1.000000e+00
  %1248 = select i1 %1245, float 0.000000e+00, float 1.000000e+00
  %1249 = select i1 %1246, float 0.000000e+00, float 1.000000e+00
  %1250 = fmul fast float %1238, 0x3FB3D07220000000
  %1251 = fmul fast float %1239, 0x3FB3D07220000000
  %1252 = fmul fast float %1240, 0x3FB3D07220000000
  %1253 = fadd fast float %1238, 0x3FAC28F5C0000000
  %1254 = fadd fast float %1239, 0x3FAC28F5C0000000
  %1255 = fadd fast float %1240, 0x3FAC28F5C0000000
  %1256 = fmul fast float %1253, 0x3FEE54EDE0000000
  %1257 = fmul fast float %1254, 0x3FEE54EDE0000000
  %1258 = fmul fast float %1255, 0x3FEE54EDE0000000
  %1259 = call float @dx.op.unary.f32(i32 23, float %1256)  ; Log(value)
  %1260 = call float @dx.op.unary.f32(i32 23, float %1257)  ; Log(value)
  %1261 = call float @dx.op.unary.f32(i32 23, float %1258)  ; Log(value)
  %1262 = fmul fast float %1259, 0x4003333340000000
  %1263 = fmul fast float %1260, 0x4003333340000000
  %1264 = fmul fast float %1261, 0x4003333340000000
  %1265 = call float @dx.op.unary.f32(i32 21, float %1262)  ; Exp(value)
  %1266 = call float @dx.op.unary.f32(i32 21, float %1263)  ; Exp(value)
  %1267 = call float @dx.op.unary.f32(i32 21, float %1264)  ; Exp(value)
  %1268 = fsub fast float %1250, %1265
  %1269 = fsub fast float %1251, %1266
  %1270 = fsub fast float %1252, %1267
  %1271 = fmul fast float %1268, %1247
  %1272 = fmul fast float %1269, %1248
  %1273 = fmul fast float %1270, %1249
  %1274 = fadd fast float %1271, %1265
  %1275 = fadd fast float %1272, %1266
  %1276 = fadd fast float %1273, %1267
  br label %1345

; <label>:1277                                    ; preds = %1232
  %1278 = fadd fast float %6, 1.000000e+00
  %1279 = fadd fast float %7, 1.000000e+00
  %1280 = fsub fast float 1.000000e+00, %6
  %1281 = fmul fast float %10, %1278
  %1282 = fmul fast float %10, %1279
  %1283 = fmul fast float %10, %1280
  %1284 = fmul fast float %1281, %1238
  %1285 = fmul fast float %1282, %1239
  %1286 = fmul fast float %1283, %1240
  %1287 = fcmp fast ult float %11, 5.000000e-01
  br i1 %1287, label %1313, label %1288

; <label>:1288                                    ; preds = %1277
  %1289 = fmul fast float %1284, 0x4004147AE0000000
  %1290 = fmul fast float %1285, 0x4004147AE0000000
  %1291 = fmul fast float %1286, 0x4004147AE0000000
  %1292 = fadd fast float %1289, 0x3F9EB851E0000000
  %1293 = fadd fast float %1290, 0x3F9EB851E0000000
  %1294 = fadd fast float %1291, 0x3F9EB851E0000000
  %1295 = fmul fast float %1292, %1284
  %1296 = fmul fast float %1293, %1285
  %1297 = fmul fast float %1294, %1286
  %1298 = fmul fast float %1284, 0x400370A3E0000000
  %1299 = fmul fast float %1285, 0x400370A3E0000000
  %1300 = fmul fast float %1286, 0x400370A3E0000000
  %1301 = fadd fast float %1298, 0x3FE2E147A0000000
  %1302 = fadd fast float %1299, 0x3FE2E147A0000000
  %1303 = fadd fast float %1300, 0x3FE2E147A0000000
  %1304 = fmul fast float %1301, %1284
  %1305 = fmul fast float %1302, %1285
  %1306 = fmul fast float %1303, %1286
  %1307 = fadd fast float %1304, 0x3FC1EB8520000000
  %1308 = fadd fast float %1305, 0x3FC1EB8520000000
  %1309 = fadd fast float %1306, 0x3FC1EB8520000000
  %1310 = fdiv fast float %1295, %1307
  %1311 = fdiv fast float %1296, %1308
  %1312 = fdiv fast float %1297, %1309
  br label %1313

; <label>:1313                                    ; preds = %1288, %1277
  %1314 = phi float [ %1310, %1288 ], [ %1284, %1277 ]
  %1315 = phi float [ %1311, %1288 ], [ %1285, %1277 ]
  %1316 = phi float [ %1312, %1288 ], [ %1286, %1277 ]
  %1317 = call float @dx.op.unary.f32(i32 7, float %1314)  ; Saturate(value)
  %1318 = call float @dx.op.unary.f32(i32 7, float %1315)  ; Saturate(value)
  %1319 = call float @dx.op.unary.f32(i32 7, float %1316)  ; Saturate(value)
  %1320 = call float @dx.op.dot3.f32(i32 55, float %1317, float %1318, float %1319, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1321 = fsub fast float %1317, %1320
  %1322 = fsub fast float %1318, %1320
  %1323 = fsub fast float %1319, %1320
  %1324 = fmul fast float %1321, %9
  %1325 = fmul fast float %1322, %9
  %1326 = fmul fast float %1323, %9
  %1327 = fadd fast float %1324, %1320
  %1328 = fadd fast float %1325, %1320
  %1329 = fadd fast float %1326, %1320
  %1330 = call float @dx.op.unary.f32(i32 7, float %1327)  ; Saturate(value)
  %1331 = call float @dx.op.unary.f32(i32 7, float %1328)  ; Saturate(value)
  %1332 = call float @dx.op.unary.f32(i32 7, float %1329)  ; Saturate(value)
  %1333 = fadd fast float %1330, 0xBFC70A3D80000000
  %1334 = fadd fast float %1331, 0xBFC70A3D80000000
  %1335 = fadd fast float %1332, 0xBFC70A3D80000000
  %1336 = fmul fast float %1333, %8
  %1337 = fmul fast float %1334, %8
  %1338 = fmul fast float %1335, %8
  %1339 = fadd fast float %1336, 0x3FC70A3D80000000
  %1340 = fadd fast float %1337, 0x3FC70A3D80000000
  %1341 = fadd fast float %1338, 0x3FC70A3D80000000
  %1342 = call float @dx.op.unary.f32(i32 7, float %1339)  ; Saturate(value)
  %1343 = call float @dx.op.unary.f32(i32 7, float %1340)  ; Saturate(value)
  %1344 = call float @dx.op.unary.f32(i32 7, float %1341)  ; Saturate(value)
  br label %1345

; <label>:1345                                    ; preds = %1313, %1243
  %1346 = phi float [ %1274, %1243 ], [ %1342, %1313 ]
  %1347 = phi float [ %1275, %1243 ], [ %1343, %1313 ]
  %1348 = phi float [ %1276, %1243 ], [ %1344, %1313 ]
  %1349 = fsub fast float %1346, %378
  %1350 = fsub fast float %1347, %379
  %1351 = fsub fast float %1348, %380
  %1352 = fmul fast float %1349, %1230
  %1353 = fmul fast float %1350, %1230
  %1354 = fmul fast float %1351, %1230
  %1355 = fadd fast float %1352, %378
  %1356 = fadd fast float %1353, %379
  %1357 = fadd fast float %1354, %380
  br label %1358

; <label>:1358                                    ; preds = %1345, %1217
  %1359 = phi float [ %1355, %1345 ], [ %378, %1217 ]
  %1360 = phi float [ %1356, %1345 ], [ %379, %1217 ]
  %1361 = phi float [ %1357, %1345 ], [ %380, %1217 ]
  %1362 = call float @dx.op.binary.f32(i32 36, float %1198, float %1178)  ; FMin(a,b)
  %1363 = call float @dx.op.binary.f32(i32 36, float %1199, float %1179)  ; FMin(a,b)
  %1364 = call float @dx.op.binary.f32(i32 36, float %1200, float %1180)  ; FMin(a,b)
  %1365 = call float @dx.op.binary.f32(i32 36, float %1359, float %1218)  ; FMin(a,b)
  %1366 = call float @dx.op.binary.f32(i32 36, float %1360, float %1219)  ; FMin(a,b)
  %1367 = call float @dx.op.binary.f32(i32 36, float %1361, float %1220)  ; FMin(a,b)
  %1368 = call float @dx.op.binary.f32(i32 36, float %1365, float %1362)  ; FMin(a,b)
  %1369 = call float @dx.op.binary.f32(i32 36, float %1366, float %1363)  ; FMin(a,b)
  %1370 = call float @dx.op.binary.f32(i32 36, float %1367, float %1364)  ; FMin(a,b)
  %1371 = call float @dx.op.binary.f32(i32 36, float %378, float %1368)  ; FMin(a,b)
  %1372 = call float @dx.op.binary.f32(i32 36, float %379, float %1369)  ; FMin(a,b)
  %1373 = call float @dx.op.binary.f32(i32 36, float %380, float %1370)  ; FMin(a,b)
  %1374 = call float @dx.op.binary.f32(i32 35, float %1198, float %1178)  ; FMax(a,b)
  %1375 = call float @dx.op.binary.f32(i32 35, float %1199, float %1179)  ; FMax(a,b)
  %1376 = call float @dx.op.binary.f32(i32 35, float %1200, float %1180)  ; FMax(a,b)
  %1377 = call float @dx.op.binary.f32(i32 35, float %1359, float %1218)  ; FMax(a,b)
  %1378 = call float @dx.op.binary.f32(i32 35, float %1360, float %1219)  ; FMax(a,b)
  %1379 = call float @dx.op.binary.f32(i32 35, float %1361, float %1220)  ; FMax(a,b)
  %1380 = call float @dx.op.binary.f32(i32 35, float %1377, float %1374)  ; FMax(a,b)
  %1381 = call float @dx.op.binary.f32(i32 35, float %1378, float %1375)  ; FMax(a,b)
  %1382 = call float @dx.op.binary.f32(i32 35, float %1379, float %1376)  ; FMax(a,b)
  %1383 = call float @dx.op.binary.f32(i32 35, float %378, float %1380)  ; FMax(a,b)
  %1384 = call float @dx.op.binary.f32(i32 35, float %379, float %1381)  ; FMax(a,b)
  %1385 = call float @dx.op.binary.f32(i32 35, float %380, float %1382)  ; FMax(a,b)
  %1386 = fsub fast float %1383, %1371
  %1387 = fsub fast float %1384, %1372
  %1388 = fsub fast float %1385, %1373
  %1389 = call float @dx.op.unary.f32(i32 6, float %1386)  ; FAbs(value)
  %1390 = call float @dx.op.unary.f32(i32 6, float %1387)  ; FAbs(value)
  %1391 = call float @dx.op.unary.f32(i32 6, float %1388)  ; FAbs(value)
  %1392 = call float @dx.op.binary.f32(i32 35, float %1390, float %1391)  ; FMax(a,b)
  %1393 = call float @dx.op.binary.f32(i32 35, float %1389, float %1392)  ; FMax(a,b)
  %1394 = call float @dx.op.binary.f32(i32 35, float %1384, float %1385)  ; FMax(a,b)
  %1395 = call float @dx.op.binary.f32(i32 35, float %1383, float %1394)  ; FMax(a,b)
  %1396 = fmul fast float %1395, 1.250000e-01
  %1397 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1396)  ; FMax(a,b)
  %1398 = fcmp fast ogt float %1393, %1397
  br i1 %1398, label %1399, label %1461

; <label>:1399                                    ; preds = %1358
  %1400 = fsub fast float %1359, %1218
  %1401 = fsub fast float %1360, %1219
  %1402 = fsub fast float %1361, %1220
  %1403 = call float @dx.op.unary.f32(i32 6, float %1400)  ; FAbs(value)
  %1404 = call float @dx.op.unary.f32(i32 6, float %1401)  ; FAbs(value)
  %1405 = call float @dx.op.unary.f32(i32 6, float %1402)  ; FAbs(value)
  %1406 = call float @dx.op.binary.f32(i32 35, float %1404, float %1405)  ; FMax(a,b)
  %1407 = call float @dx.op.binary.f32(i32 35, float %1403, float %1406)  ; FMax(a,b)
  %1408 = fsub fast float %1198, %1178
  %1409 = fsub fast float %1199, %1179
  %1410 = fsub fast float %1200, %1180
  %1411 = call float @dx.op.unary.f32(i32 6, float %1408)  ; FAbs(value)
  %1412 = call float @dx.op.unary.f32(i32 6, float %1409)  ; FAbs(value)
  %1413 = call float @dx.op.unary.f32(i32 6, float %1410)  ; FAbs(value)
  %1414 = call float @dx.op.binary.f32(i32 35, float %1412, float %1413)  ; FMax(a,b)
  %1415 = call float @dx.op.binary.f32(i32 35, float %1411, float %1414)  ; FMax(a,b)
  %1416 = fcmp fast olt float %1407, %1415
  %1417 = select i1 %1416, float %1359, float %1198
  %1418 = select i1 %1416, float %1360, float %1199
  %1419 = select i1 %1416, float %1361, float %1200
  %1420 = select i1 %1416, float %1218, float %1178
  %1421 = select i1 %1416, float %1219, float %1179
  %1422 = select i1 %1416, float %1220, float %1180
  %1423 = fsub fast float %378, %1420
  %1424 = fsub fast float %379, %1421
  %1425 = fsub fast float %380, %1422
  %1426 = fsub fast float %378, %1417
  %1427 = fsub fast float %379, %1418
  %1428 = fsub fast float %380, %1419
  %1429 = call float @dx.op.dot3.f32(i32 55, float %1426, float %1427, float %1428, float %1423, float %1424, float %1425)  ; Dot3(ax,ay,az,bx,by,bz)
  %1430 = fcmp fast ogt float %1429, 0.000000e+00
  br i1 %1430, label %1431, label %1442

; <label>:1431                                    ; preds = %1399
  %1432 = fsub fast float %1417, %1420
  %1433 = fsub fast float %1418, %1421
  %1434 = fsub fast float %1419, %1422
  %1435 = call float @dx.op.unary.f32(i32 6, float %1432)  ; FAbs(value)
  %1436 = call float @dx.op.unary.f32(i32 6, float %1433)  ; FAbs(value)
  %1437 = call float @dx.op.unary.f32(i32 6, float %1434)  ; FAbs(value)
  %1438 = call float @dx.op.binary.f32(i32 35, float %1436, float %1437)  ; FMax(a,b)
  %1439 = call float @dx.op.binary.f32(i32 35, float %1435, float %1438)  ; FMax(a,b)
  %1440 = fmul fast float %1393, 2.500000e-01
  %1441 = fcmp fast olt float %1439, %1440
  br label %1442

; <label>:1442                                    ; preds = %1431, %1399
  %1443 = phi i1 [ false, %1399 ], [ %1441, %1431 ]
  %1444 = select i1 %1443, float 5.000000e-01, float 1.000000e+00
  %1445 = fmul fast float %1444, %3
  %1446 = fadd fast float %1417, %1420
  %1447 = fadd fast float %1418, %1421
  %1448 = fadd fast float %1419, %1422
  %1449 = fmul fast float %1446, 5.000000e-01
  %1450 = fmul fast float %1447, 5.000000e-01
  %1451 = fmul fast float %1448, 5.000000e-01
  %1452 = fsub fast float %1449, %378
  %1453 = fsub fast float %1450, %379
  %1454 = fsub fast float %1451, %380
  %1455 = fmul fast float %1445, %1452
  %1456 = fmul fast float %1445, %1453
  %1457 = fmul fast float %1445, %1454
  %1458 = fadd fast float %1455, %378
  %1459 = fadd fast float %1456, %379
  %1460 = fadd fast float %1457, %380
  br label %1461

; <label>:1461                                    ; preds = %1442, %1358, %1031
  %1462 = phi float [ %378, %1031 ], [ %1458, %1442 ], [ %378, %1358 ]
  %1463 = phi float [ %379, %1031 ], [ %1459, %1442 ], [ %379, %1358 ]
  %1464 = phi float [ %380, %1031 ], [ %1460, %1442 ], [ %380, %1358 ]
  %1465 = fcmp fast ult float %161, 0.000000e+00
  br i1 %1465, label %1891, label %1466

; <label>:1466                                    ; preds = %1461
  %1467 = fsub fast float 1.000000e+00, %58
  %1468 = fmul fast float %1467, 0x3FA99999A0000000
  %1469 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %1468)  ; FMax(a,b)
  %1470 = fsub fast float %60, %58
  %1471 = call float @dx.op.unary.f32(i32 6, float %1470)  ; FAbs(value)
  %1472 = fdiv fast float %1471, %1469
  %1473 = fsub fast float 1.000000e+00, %1472
  %1474 = call float @dx.op.unary.f32(i32 7, float %1473)  ; Saturate(value)
  %1475 = fcmp fast ugt float %1474, 0.000000e+00
  br i1 %1475, label %1476, label %1486

; <label>:1476                                    ; preds = %1466
  %1477 = fsub fast float %592, %485
  %1478 = fsub fast float %593, %486
  %1479 = fsub fast float %594, %487
  %1480 = fmul fast float %1474, %1477
  %1481 = fmul fast float %1474, %1478
  %1482 = fmul fast float %1474, %1479
  %1483 = fadd fast float %1480, %485
  %1484 = fadd fast float %1481, %486
  %1485 = fadd fast float %1482, %487
  br label %1486

; <label>:1486                                    ; preds = %1476, %1466
  %1487 = phi float [ %1483, %1476 ], [ %485, %1466 ]
  %1488 = phi float [ %1484, %1476 ], [ %486, %1466 ]
  %1489 = phi float [ %1485, %1476 ], [ %487, %1466 ]
  %1490 = add i32 %27, -1
  %1491 = call i32 @dx.op.binary.i32(i32 37, i32 %1490, i32 0)  ; IMax(a,b)
  %1492 = call i32 @dx.op.binary.i32(i32 38, i32 %1491, i32 %31)  ; IMin(a,b)
  %1493 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1492, i32 %42, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1494 = extractvalue %dx.types.ResRet.f32 %1493, 0
  %1495 = fsub fast float %1494, %58
  %1496 = call float @dx.op.unary.f32(i32 6, float %1495)  ; FAbs(value)
  %1497 = fdiv fast float %1496, %1469
  %1498 = fsub fast float 1.000000e+00, %1497
  %1499 = call float @dx.op.unary.f32(i32 7, float %1498)  ; Saturate(value)
  %1500 = fcmp fast ugt float %1499, 0.000000e+00
  br i1 %1500, label %1501, label %1627

; <label>:1501                                    ; preds = %1486
  %1502 = call i32 @dx.op.binary.i32(i32 37, i32 %1492, i32 0)  ; IMax(a,b)
  %1503 = call i32 @dx.op.binary.i32(i32 37, i32 %42, i32 0)  ; IMax(a,b)
  %1504 = call i32 @dx.op.binary.i32(i32 38, i32 %1502, i32 %31)  ; IMin(a,b)
  %1505 = call i32 @dx.op.binary.i32(i32 38, i32 %1503, i32 %32)  ; IMin(a,b)
  %1506 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1504, i32 %1505, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1507 = extractvalue %dx.types.ResRet.f32 %1506, 0
  %1508 = extractvalue %dx.types.ResRet.f32 %1506, 1
  %1509 = extractvalue %dx.types.ResRet.f32 %1506, 2
  %1510 = extractvalue %dx.types.ResRet.f32 %1506, 3
  %1511 = fcmp fast olt float %1510, 0.000000e+00
  br i1 %1511, label %1512, label %1546

; <label>:1512                                    ; preds = %1501
  %1513 = fcmp fast ogt float %1507, 0x3FA4B5DCC0000000
  %1514 = fcmp fast ogt float %1508, 0x3FA4B5DCC0000000
  %1515 = fcmp fast ogt float %1509, 0x3FA4B5DCC0000000
  %1516 = select i1 %1513, float 0.000000e+00, float 1.000000e+00
  %1517 = select i1 %1514, float 0.000000e+00, float 1.000000e+00
  %1518 = select i1 %1515, float 0.000000e+00, float 1.000000e+00
  %1519 = fmul fast float %1507, 0x3FB3D07220000000
  %1520 = fmul fast float %1508, 0x3FB3D07220000000
  %1521 = fmul fast float %1509, 0x3FB3D07220000000
  %1522 = fadd fast float %1507, 0x3FAC28F5C0000000
  %1523 = fadd fast float %1508, 0x3FAC28F5C0000000
  %1524 = fadd fast float %1509, 0x3FAC28F5C0000000
  %1525 = fmul fast float %1522, 0x3FEE54EDE0000000
  %1526 = fmul fast float %1523, 0x3FEE54EDE0000000
  %1527 = fmul fast float %1524, 0x3FEE54EDE0000000
  %1528 = call float @dx.op.unary.f32(i32 23, float %1525)  ; Log(value)
  %1529 = call float @dx.op.unary.f32(i32 23, float %1526)  ; Log(value)
  %1530 = call float @dx.op.unary.f32(i32 23, float %1527)  ; Log(value)
  %1531 = fmul fast float %1528, 0x4003333340000000
  %1532 = fmul fast float %1529, 0x4003333340000000
  %1533 = fmul fast float %1530, 0x4003333340000000
  %1534 = call float @dx.op.unary.f32(i32 21, float %1531)  ; Exp(value)
  %1535 = call float @dx.op.unary.f32(i32 21, float %1532)  ; Exp(value)
  %1536 = call float @dx.op.unary.f32(i32 21, float %1533)  ; Exp(value)
  %1537 = fsub fast float %1519, %1534
  %1538 = fsub fast float %1520, %1535
  %1539 = fsub fast float %1521, %1536
  %1540 = fmul fast float %1537, %1516
  %1541 = fmul fast float %1538, %1517
  %1542 = fmul fast float %1539, %1518
  %1543 = fadd fast float %1540, %1534
  %1544 = fadd fast float %1541, %1535
  %1545 = fadd fast float %1542, %1536
  br label %1614

; <label>:1546                                    ; preds = %1501
  %1547 = fadd fast float %6, 1.000000e+00
  %1548 = fadd fast float %7, 1.000000e+00
  %1549 = fsub fast float 1.000000e+00, %6
  %1550 = fmul fast float %10, %1547
  %1551 = fmul fast float %10, %1548
  %1552 = fmul fast float %10, %1549
  %1553 = fmul fast float %1550, %1507
  %1554 = fmul fast float %1551, %1508
  %1555 = fmul fast float %1552, %1509
  %1556 = fcmp fast ult float %11, 5.000000e-01
  br i1 %1556, label %1582, label %1557

; <label>:1557                                    ; preds = %1546
  %1558 = fmul fast float %1553, 0x4004147AE0000000
  %1559 = fmul fast float %1554, 0x4004147AE0000000
  %1560 = fmul fast float %1555, 0x4004147AE0000000
  %1561 = fadd fast float %1558, 0x3F9EB851E0000000
  %1562 = fadd fast float %1559, 0x3F9EB851E0000000
  %1563 = fadd fast float %1560, 0x3F9EB851E0000000
  %1564 = fmul fast float %1561, %1553
  %1565 = fmul fast float %1562, %1554
  %1566 = fmul fast float %1563, %1555
  %1567 = fmul fast float %1553, 0x400370A3E0000000
  %1568 = fmul fast float %1554, 0x400370A3E0000000
  %1569 = fmul fast float %1555, 0x400370A3E0000000
  %1570 = fadd fast float %1567, 0x3FE2E147A0000000
  %1571 = fadd fast float %1568, 0x3FE2E147A0000000
  %1572 = fadd fast float %1569, 0x3FE2E147A0000000
  %1573 = fmul fast float %1570, %1553
  %1574 = fmul fast float %1571, %1554
  %1575 = fmul fast float %1572, %1555
  %1576 = fadd fast float %1573, 0x3FC1EB8520000000
  %1577 = fadd fast float %1574, 0x3FC1EB8520000000
  %1578 = fadd fast float %1575, 0x3FC1EB8520000000
  %1579 = fdiv fast float %1564, %1576
  %1580 = fdiv fast float %1565, %1577
  %1581 = fdiv fast float %1566, %1578
  br label %1582

; <label>:1582                                    ; preds = %1557, %1546
  %1583 = phi float [ %1579, %1557 ], [ %1553, %1546 ]
  %1584 = phi float [ %1580, %1557 ], [ %1554, %1546 ]
  %1585 = phi float [ %1581, %1557 ], [ %1555, %1546 ]
  %1586 = call float @dx.op.unary.f32(i32 7, float %1583)  ; Saturate(value)
  %1587 = call float @dx.op.unary.f32(i32 7, float %1584)  ; Saturate(value)
  %1588 = call float @dx.op.unary.f32(i32 7, float %1585)  ; Saturate(value)
  %1589 = call float @dx.op.dot3.f32(i32 55, float %1586, float %1587, float %1588, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1590 = fsub fast float %1586, %1589
  %1591 = fsub fast float %1587, %1589
  %1592 = fsub fast float %1588, %1589
  %1593 = fmul fast float %1590, %9
  %1594 = fmul fast float %1591, %9
  %1595 = fmul fast float %1592, %9
  %1596 = fadd fast float %1593, %1589
  %1597 = fadd fast float %1594, %1589
  %1598 = fadd fast float %1595, %1589
  %1599 = call float @dx.op.unary.f32(i32 7, float %1596)  ; Saturate(value)
  %1600 = call float @dx.op.unary.f32(i32 7, float %1597)  ; Saturate(value)
  %1601 = call float @dx.op.unary.f32(i32 7, float %1598)  ; Saturate(value)
  %1602 = fadd fast float %1599, 0xBFC70A3D80000000
  %1603 = fadd fast float %1600, 0xBFC70A3D80000000
  %1604 = fadd fast float %1601, 0xBFC70A3D80000000
  %1605 = fmul fast float %1602, %8
  %1606 = fmul fast float %1603, %8
  %1607 = fmul fast float %1604, %8
  %1608 = fadd fast float %1605, 0x3FC70A3D80000000
  %1609 = fadd fast float %1606, 0x3FC70A3D80000000
  %1610 = fadd fast float %1607, 0x3FC70A3D80000000
  %1611 = call float @dx.op.unary.f32(i32 7, float %1608)  ; Saturate(value)
  %1612 = call float @dx.op.unary.f32(i32 7, float %1609)  ; Saturate(value)
  %1613 = call float @dx.op.unary.f32(i32 7, float %1610)  ; Saturate(value)
  br label %1614

; <label>:1614                                    ; preds = %1582, %1512
  %1615 = phi float [ %1543, %1512 ], [ %1611, %1582 ]
  %1616 = phi float [ %1544, %1512 ], [ %1612, %1582 ]
  %1617 = phi float [ %1545, %1512 ], [ %1613, %1582 ]
  %1618 = fsub fast float %1615, %485
  %1619 = fsub fast float %1616, %486
  %1620 = fsub fast float %1617, %487
  %1621 = fmul fast float %1618, %1499
  %1622 = fmul fast float %1619, %1499
  %1623 = fmul fast float %1620, %1499
  %1624 = fadd fast float %1621, %485
  %1625 = fadd fast float %1622, %486
  %1626 = fadd fast float %1623, %487
  br label %1627

; <label>:1627                                    ; preds = %1614, %1486
  %1628 = phi float [ %1624, %1614 ], [ %485, %1486 ]
  %1629 = phi float [ %1625, %1614 ], [ %486, %1486 ]
  %1630 = phi float [ %1626, %1614 ], [ %487, %1486 ]
  %1631 = add i32 %28, 2
  %1632 = call i32 @dx.op.binary.i32(i32 37, i32 %1631, i32 0)  ; IMax(a,b)
  %1633 = call i32 @dx.op.binary.i32(i32 38, i32 %1632, i32 %32)  ; IMin(a,b)
  %1634 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %35, i32 %1633, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1635 = extractvalue %dx.types.ResRet.f32 %1634, 0
  %1636 = fsub fast float %1635, %58
  %1637 = call float @dx.op.unary.f32(i32 6, float %1636)  ; FAbs(value)
  %1638 = fdiv fast float %1637, %1469
  %1639 = fsub fast float 1.000000e+00, %1638
  %1640 = call float @dx.op.unary.f32(i32 7, float %1639)  ; Saturate(value)
  %1641 = fcmp fast ugt float %1640, 0.000000e+00
  br i1 %1641, label %1642, label %1768

; <label>:1642                                    ; preds = %1627
  %1643 = call i32 @dx.op.binary.i32(i32 37, i32 %35, i32 0)  ; IMax(a,b)
  %1644 = call i32 @dx.op.binary.i32(i32 37, i32 %1633, i32 0)  ; IMax(a,b)
  %1645 = call i32 @dx.op.binary.i32(i32 38, i32 %1643, i32 %31)  ; IMin(a,b)
  %1646 = call i32 @dx.op.binary.i32(i32 38, i32 %1644, i32 %32)  ; IMin(a,b)
  %1647 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1645, i32 %1646, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1648 = extractvalue %dx.types.ResRet.f32 %1647, 0
  %1649 = extractvalue %dx.types.ResRet.f32 %1647, 1
  %1650 = extractvalue %dx.types.ResRet.f32 %1647, 2
  %1651 = extractvalue %dx.types.ResRet.f32 %1647, 3
  %1652 = fcmp fast olt float %1651, 0.000000e+00
  br i1 %1652, label %1653, label %1687

; <label>:1653                                    ; preds = %1642
  %1654 = fcmp fast ogt float %1648, 0x3FA4B5DCC0000000
  %1655 = fcmp fast ogt float %1649, 0x3FA4B5DCC0000000
  %1656 = fcmp fast ogt float %1650, 0x3FA4B5DCC0000000
  %1657 = select i1 %1654, float 0.000000e+00, float 1.000000e+00
  %1658 = select i1 %1655, float 0.000000e+00, float 1.000000e+00
  %1659 = select i1 %1656, float 0.000000e+00, float 1.000000e+00
  %1660 = fmul fast float %1648, 0x3FB3D07220000000
  %1661 = fmul fast float %1649, 0x3FB3D07220000000
  %1662 = fmul fast float %1650, 0x3FB3D07220000000
  %1663 = fadd fast float %1648, 0x3FAC28F5C0000000
  %1664 = fadd fast float %1649, 0x3FAC28F5C0000000
  %1665 = fadd fast float %1650, 0x3FAC28F5C0000000
  %1666 = fmul fast float %1663, 0x3FEE54EDE0000000
  %1667 = fmul fast float %1664, 0x3FEE54EDE0000000
  %1668 = fmul fast float %1665, 0x3FEE54EDE0000000
  %1669 = call float @dx.op.unary.f32(i32 23, float %1666)  ; Log(value)
  %1670 = call float @dx.op.unary.f32(i32 23, float %1667)  ; Log(value)
  %1671 = call float @dx.op.unary.f32(i32 23, float %1668)  ; Log(value)
  %1672 = fmul fast float %1669, 0x4003333340000000
  %1673 = fmul fast float %1670, 0x4003333340000000
  %1674 = fmul fast float %1671, 0x4003333340000000
  %1675 = call float @dx.op.unary.f32(i32 21, float %1672)  ; Exp(value)
  %1676 = call float @dx.op.unary.f32(i32 21, float %1673)  ; Exp(value)
  %1677 = call float @dx.op.unary.f32(i32 21, float %1674)  ; Exp(value)
  %1678 = fsub fast float %1660, %1675
  %1679 = fsub fast float %1661, %1676
  %1680 = fsub fast float %1662, %1677
  %1681 = fmul fast float %1678, %1657
  %1682 = fmul fast float %1679, %1658
  %1683 = fmul fast float %1680, %1659
  %1684 = fadd fast float %1681, %1675
  %1685 = fadd fast float %1682, %1676
  %1686 = fadd fast float %1683, %1677
  br label %1755

; <label>:1687                                    ; preds = %1642
  %1688 = fadd fast float %6, 1.000000e+00
  %1689 = fadd fast float %7, 1.000000e+00
  %1690 = fsub fast float 1.000000e+00, %6
  %1691 = fmul fast float %10, %1688
  %1692 = fmul fast float %10, %1689
  %1693 = fmul fast float %10, %1690
  %1694 = fmul fast float %1691, %1648
  %1695 = fmul fast float %1692, %1649
  %1696 = fmul fast float %1693, %1650
  %1697 = fcmp fast ult float %11, 5.000000e-01
  br i1 %1697, label %1723, label %1698

; <label>:1698                                    ; preds = %1687
  %1699 = fmul fast float %1694, 0x4004147AE0000000
  %1700 = fmul fast float %1695, 0x4004147AE0000000
  %1701 = fmul fast float %1696, 0x4004147AE0000000
  %1702 = fadd fast float %1699, 0x3F9EB851E0000000
  %1703 = fadd fast float %1700, 0x3F9EB851E0000000
  %1704 = fadd fast float %1701, 0x3F9EB851E0000000
  %1705 = fmul fast float %1702, %1694
  %1706 = fmul fast float %1703, %1695
  %1707 = fmul fast float %1704, %1696
  %1708 = fmul fast float %1694, 0x400370A3E0000000
  %1709 = fmul fast float %1695, 0x400370A3E0000000
  %1710 = fmul fast float %1696, 0x400370A3E0000000
  %1711 = fadd fast float %1708, 0x3FE2E147A0000000
  %1712 = fadd fast float %1709, 0x3FE2E147A0000000
  %1713 = fadd fast float %1710, 0x3FE2E147A0000000
  %1714 = fmul fast float %1711, %1694
  %1715 = fmul fast float %1712, %1695
  %1716 = fmul fast float %1713, %1696
  %1717 = fadd fast float %1714, 0x3FC1EB8520000000
  %1718 = fadd fast float %1715, 0x3FC1EB8520000000
  %1719 = fadd fast float %1716, 0x3FC1EB8520000000
  %1720 = fdiv fast float %1705, %1717
  %1721 = fdiv fast float %1706, %1718
  %1722 = fdiv fast float %1707, %1719
  br label %1723

; <label>:1723                                    ; preds = %1698, %1687
  %1724 = phi float [ %1720, %1698 ], [ %1694, %1687 ]
  %1725 = phi float [ %1721, %1698 ], [ %1695, %1687 ]
  %1726 = phi float [ %1722, %1698 ], [ %1696, %1687 ]
  %1727 = call float @dx.op.unary.f32(i32 7, float %1724)  ; Saturate(value)
  %1728 = call float @dx.op.unary.f32(i32 7, float %1725)  ; Saturate(value)
  %1729 = call float @dx.op.unary.f32(i32 7, float %1726)  ; Saturate(value)
  %1730 = call float @dx.op.dot3.f32(i32 55, float %1727, float %1728, float %1729, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1731 = fsub fast float %1727, %1730
  %1732 = fsub fast float %1728, %1730
  %1733 = fsub fast float %1729, %1730
  %1734 = fmul fast float %1731, %9
  %1735 = fmul fast float %1732, %9
  %1736 = fmul fast float %1733, %9
  %1737 = fadd fast float %1734, %1730
  %1738 = fadd fast float %1735, %1730
  %1739 = fadd fast float %1736, %1730
  %1740 = call float @dx.op.unary.f32(i32 7, float %1737)  ; Saturate(value)
  %1741 = call float @dx.op.unary.f32(i32 7, float %1738)  ; Saturate(value)
  %1742 = call float @dx.op.unary.f32(i32 7, float %1739)  ; Saturate(value)
  %1743 = fadd fast float %1740, 0xBFC70A3D80000000
  %1744 = fadd fast float %1741, 0xBFC70A3D80000000
  %1745 = fadd fast float %1742, 0xBFC70A3D80000000
  %1746 = fmul fast float %1743, %8
  %1747 = fmul fast float %1744, %8
  %1748 = fmul fast float %1745, %8
  %1749 = fadd fast float %1746, 0x3FC70A3D80000000
  %1750 = fadd fast float %1747, 0x3FC70A3D80000000
  %1751 = fadd fast float %1748, 0x3FC70A3D80000000
  %1752 = call float @dx.op.unary.f32(i32 7, float %1749)  ; Saturate(value)
  %1753 = call float @dx.op.unary.f32(i32 7, float %1750)  ; Saturate(value)
  %1754 = call float @dx.op.unary.f32(i32 7, float %1751)  ; Saturate(value)
  br label %1755

; <label>:1755                                    ; preds = %1723, %1653
  %1756 = phi float [ %1684, %1653 ], [ %1752, %1723 ]
  %1757 = phi float [ %1685, %1653 ], [ %1753, %1723 ]
  %1758 = phi float [ %1686, %1653 ], [ %1754, %1723 ]
  %1759 = fsub fast float %1756, %485
  %1760 = fsub fast float %1757, %486
  %1761 = fsub fast float %1758, %487
  %1762 = fmul fast float %1759, %1640
  %1763 = fmul fast float %1760, %1640
  %1764 = fmul fast float %1761, %1640
  %1765 = fadd fast float %1762, %485
  %1766 = fadd fast float %1763, %486
  %1767 = fadd fast float %1764, %487
  br label %1768

; <label>:1768                                    ; preds = %1755, %1627
  %1769 = phi float [ %1765, %1755 ], [ %485, %1627 ]
  %1770 = phi float [ %1766, %1755 ], [ %486, %1627 ]
  %1771 = phi float [ %1767, %1755 ], [ %487, %1627 ]
  %1772 = fsub fast float %54, %58
  %1773 = call float @dx.op.unary.f32(i32 6, float %1772)  ; FAbs(value)
  %1774 = fdiv fast float %1773, %1469
  %1775 = fsub fast float 1.000000e+00, %1774
  %1776 = call float @dx.op.unary.f32(i32 7, float %1775)  ; Saturate(value)
  %1777 = fcmp fast ugt float %1776, 0.000000e+00
  br i1 %1777, label %1778, label %1788

; <label>:1778                                    ; preds = %1768
  %1779 = fsub fast float %271, %485
  %1780 = fsub fast float %272, %486
  %1781 = fsub fast float %273, %487
  %1782 = fmul fast float %1776, %1779
  %1783 = fmul fast float %1776, %1780
  %1784 = fmul fast float %1776, %1781
  %1785 = fadd fast float %1782, %485
  %1786 = fadd fast float %1783, %486
  %1787 = fadd fast float %1784, %487
  br label %1788

; <label>:1788                                    ; preds = %1778, %1768
  %1789 = phi float [ %1785, %1778 ], [ %485, %1768 ]
  %1790 = phi float [ %1786, %1778 ], [ %486, %1768 ]
  %1791 = phi float [ %1787, %1778 ], [ %487, %1768 ]
  %1792 = call float @dx.op.binary.f32(i32 36, float %1628, float %1487)  ; FMin(a,b)
  %1793 = call float @dx.op.binary.f32(i32 36, float %1629, float %1488)  ; FMin(a,b)
  %1794 = call float @dx.op.binary.f32(i32 36, float %1630, float %1489)  ; FMin(a,b)
  %1795 = call float @dx.op.binary.f32(i32 36, float %1789, float %1769)  ; FMin(a,b)
  %1796 = call float @dx.op.binary.f32(i32 36, float %1790, float %1770)  ; FMin(a,b)
  %1797 = call float @dx.op.binary.f32(i32 36, float %1791, float %1771)  ; FMin(a,b)
  %1798 = call float @dx.op.binary.f32(i32 36, float %1795, float %1792)  ; FMin(a,b)
  %1799 = call float @dx.op.binary.f32(i32 36, float %1796, float %1793)  ; FMin(a,b)
  %1800 = call float @dx.op.binary.f32(i32 36, float %1797, float %1794)  ; FMin(a,b)
  %1801 = call float @dx.op.binary.f32(i32 36, float %485, float %1798)  ; FMin(a,b)
  %1802 = call float @dx.op.binary.f32(i32 36, float %486, float %1799)  ; FMin(a,b)
  %1803 = call float @dx.op.binary.f32(i32 36, float %487, float %1800)  ; FMin(a,b)
  %1804 = call float @dx.op.binary.f32(i32 35, float %1628, float %1487)  ; FMax(a,b)
  %1805 = call float @dx.op.binary.f32(i32 35, float %1629, float %1488)  ; FMax(a,b)
  %1806 = call float @dx.op.binary.f32(i32 35, float %1630, float %1489)  ; FMax(a,b)
  %1807 = call float @dx.op.binary.f32(i32 35, float %1789, float %1769)  ; FMax(a,b)
  %1808 = call float @dx.op.binary.f32(i32 35, float %1790, float %1770)  ; FMax(a,b)
  %1809 = call float @dx.op.binary.f32(i32 35, float %1791, float %1771)  ; FMax(a,b)
  %1810 = call float @dx.op.binary.f32(i32 35, float %1807, float %1804)  ; FMax(a,b)
  %1811 = call float @dx.op.binary.f32(i32 35, float %1808, float %1805)  ; FMax(a,b)
  %1812 = call float @dx.op.binary.f32(i32 35, float %1809, float %1806)  ; FMax(a,b)
  %1813 = call float @dx.op.binary.f32(i32 35, float %485, float %1810)  ; FMax(a,b)
  %1814 = call float @dx.op.binary.f32(i32 35, float %486, float %1811)  ; FMax(a,b)
  %1815 = call float @dx.op.binary.f32(i32 35, float %487, float %1812)  ; FMax(a,b)
  %1816 = fsub fast float %1813, %1801
  %1817 = fsub fast float %1814, %1802
  %1818 = fsub fast float %1815, %1803
  %1819 = call float @dx.op.unary.f32(i32 6, float %1816)  ; FAbs(value)
  %1820 = call float @dx.op.unary.f32(i32 6, float %1817)  ; FAbs(value)
  %1821 = call float @dx.op.unary.f32(i32 6, float %1818)  ; FAbs(value)
  %1822 = call float @dx.op.binary.f32(i32 35, float %1820, float %1821)  ; FMax(a,b)
  %1823 = call float @dx.op.binary.f32(i32 35, float %1819, float %1822)  ; FMax(a,b)
  %1824 = call float @dx.op.binary.f32(i32 35, float %1814, float %1815)  ; FMax(a,b)
  %1825 = call float @dx.op.binary.f32(i32 35, float %1813, float %1824)  ; FMax(a,b)
  %1826 = fmul fast float %1825, 1.250000e-01
  %1827 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1826)  ; FMax(a,b)
  %1828 = fcmp fast ogt float %1823, %1827
  br i1 %1828, label %1829, label %1891

; <label>:1829                                    ; preds = %1788
  %1830 = fsub fast float %1789, %1769
  %1831 = fsub fast float %1790, %1770
  %1832 = fsub fast float %1791, %1771
  %1833 = call float @dx.op.unary.f32(i32 6, float %1830)  ; FAbs(value)
  %1834 = call float @dx.op.unary.f32(i32 6, float %1831)  ; FAbs(value)
  %1835 = call float @dx.op.unary.f32(i32 6, float %1832)  ; FAbs(value)
  %1836 = call float @dx.op.binary.f32(i32 35, float %1834, float %1835)  ; FMax(a,b)
  %1837 = call float @dx.op.binary.f32(i32 35, float %1833, float %1836)  ; FMax(a,b)
  %1838 = fsub fast float %1628, %1487
  %1839 = fsub fast float %1629, %1488
  %1840 = fsub fast float %1630, %1489
  %1841 = call float @dx.op.unary.f32(i32 6, float %1838)  ; FAbs(value)
  %1842 = call float @dx.op.unary.f32(i32 6, float %1839)  ; FAbs(value)
  %1843 = call float @dx.op.unary.f32(i32 6, float %1840)  ; FAbs(value)
  %1844 = call float @dx.op.binary.f32(i32 35, float %1842, float %1843)  ; FMax(a,b)
  %1845 = call float @dx.op.binary.f32(i32 35, float %1841, float %1844)  ; FMax(a,b)
  %1846 = fcmp fast olt float %1837, %1845
  %1847 = select i1 %1846, float %1789, float %1628
  %1848 = select i1 %1846, float %1790, float %1629
  %1849 = select i1 %1846, float %1791, float %1630
  %1850 = select i1 %1846, float %1769, float %1487
  %1851 = select i1 %1846, float %1770, float %1488
  %1852 = select i1 %1846, float %1771, float %1489
  %1853 = fsub fast float %485, %1850
  %1854 = fsub fast float %486, %1851
  %1855 = fsub fast float %487, %1852
  %1856 = fsub fast float %485, %1847
  %1857 = fsub fast float %486, %1848
  %1858 = fsub fast float %487, %1849
  %1859 = call float @dx.op.dot3.f32(i32 55, float %1856, float %1857, float %1858, float %1853, float %1854, float %1855)  ; Dot3(ax,ay,az,bx,by,bz)
  %1860 = fcmp fast ogt float %1859, 0.000000e+00
  br i1 %1860, label %1861, label %1873

; <label>:1861                                    ; preds = %1829
  %1862 = fsub fast float %1847, %1850
  %1863 = fsub fast float %1848, %1851
  %1864 = fsub fast float %1849, %1852
  %1865 = call float @dx.op.unary.f32(i32 6, float %1862)  ; FAbs(value)
  %1866 = call float @dx.op.unary.f32(i32 6, float %1863)  ; FAbs(value)
  %1867 = call float @dx.op.unary.f32(i32 6, float %1864)  ; FAbs(value)
  %1868 = call float @dx.op.binary.f32(i32 35, float %1866, float %1867)  ; FMax(a,b)
  %1869 = call float @dx.op.binary.f32(i32 35, float %1865, float %1868)  ; FMax(a,b)
  %1870 = fmul fast float %1823, 2.500000e-01
  %1871 = fcmp fast olt float %1869, %1870
  %1872 = select i1 %1871, float 5.000000e-01, float 1.000000e+00
  br label %1873

; <label>:1873                                    ; preds = %1861, %1829
  %1874 = phi float [ 1.000000e+00, %1829 ], [ %1872, %1861 ]
  %1875 = fmul fast float %1874, %3
  %1876 = fadd fast float %1847, %1850
  %1877 = fadd fast float %1848, %1851
  %1878 = fadd fast float %1849, %1852
  %1879 = fmul fast float %1876, 5.000000e-01
  %1880 = fmul fast float %1877, 5.000000e-01
  %1881 = fmul fast float %1878, 5.000000e-01
  %1882 = fsub fast float %1879, %485
  %1883 = fsub fast float %1880, %486
  %1884 = fsub fast float %1881, %487
  %1885 = fmul fast float %1875, %1882
  %1886 = fmul fast float %1875, %1883
  %1887 = fmul fast float %1875, %1884
  %1888 = fadd fast float %1885, %485
  %1889 = fadd fast float %1886, %486
  %1890 = fadd fast float %1887, %487
  br label %1891

; <label>:1891                                    ; preds = %1873, %1788, %1461
  %1892 = phi float [ %485, %1461 ], [ %1888, %1873 ], [ %485, %1788 ]
  %1893 = phi float [ %486, %1461 ], [ %1889, %1873 ], [ %486, %1788 ]
  %1894 = phi float [ %487, %1461 ], [ %1890, %1873 ], [ %487, %1788 ]
  %1895 = fcmp fast ult float %166, 0.000000e+00
  br i1 %1895, label %5461, label %1896

; <label>:1896                                    ; preds = %1891
  %1897 = add i32 %27, 2
  %1898 = call i32 @dx.op.binary.i32(i32 37, i32 %1897, i32 0)  ; IMax(a,b)
  %1899 = call i32 @dx.op.binary.i32(i32 38, i32 %1898, i32 %31)  ; IMin(a,b)
  %1900 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1899, i32 %42, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1901 = extractvalue %dx.types.ResRet.f32 %1900, 0
  %1902 = fsub fast float 1.000000e+00, %60
  %1903 = fmul fast float %1902, 0x3FA99999A0000000
  %1904 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %1903)  ; FMax(a,b)
  %1905 = fsub fast float %1901, %60
  %1906 = call float @dx.op.unary.f32(i32 6, float %1905)  ; FAbs(value)
  %1907 = fdiv fast float %1906, %1904
  %1908 = fsub fast float 1.000000e+00, %1907
  %1909 = call float @dx.op.unary.f32(i32 7, float %1908)  ; Saturate(value)
  %1910 = fcmp fast ugt float %1909, 0.000000e+00
  br i1 %1910, label %1911, label %2037

; <label>:1911                                    ; preds = %1896
  %1912 = call i32 @dx.op.binary.i32(i32 37, i32 %1899, i32 0)  ; IMax(a,b)
  %1913 = call i32 @dx.op.binary.i32(i32 37, i32 %42, i32 0)  ; IMax(a,b)
  %1914 = call i32 @dx.op.binary.i32(i32 38, i32 %1912, i32 %31)  ; IMin(a,b)
  %1915 = call i32 @dx.op.binary.i32(i32 38, i32 %1913, i32 %32)  ; IMin(a,b)
  %1916 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1914, i32 %1915, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1917 = extractvalue %dx.types.ResRet.f32 %1916, 0
  %1918 = extractvalue %dx.types.ResRet.f32 %1916, 1
  %1919 = extractvalue %dx.types.ResRet.f32 %1916, 2
  %1920 = extractvalue %dx.types.ResRet.f32 %1916, 3
  %1921 = fcmp fast olt float %1920, 0.000000e+00
  br i1 %1921, label %1922, label %1956

; <label>:1922                                    ; preds = %1911
  %1923 = fcmp fast ogt float %1917, 0x3FA4B5DCC0000000
  %1924 = fcmp fast ogt float %1918, 0x3FA4B5DCC0000000
  %1925 = fcmp fast ogt float %1919, 0x3FA4B5DCC0000000
  %1926 = select i1 %1923, float 0.000000e+00, float 1.000000e+00
  %1927 = select i1 %1924, float 0.000000e+00, float 1.000000e+00
  %1928 = select i1 %1925, float 0.000000e+00, float 1.000000e+00
  %1929 = fmul fast float %1917, 0x3FB3D07220000000
  %1930 = fmul fast float %1918, 0x3FB3D07220000000
  %1931 = fmul fast float %1919, 0x3FB3D07220000000
  %1932 = fadd fast float %1917, 0x3FAC28F5C0000000
  %1933 = fadd fast float %1918, 0x3FAC28F5C0000000
  %1934 = fadd fast float %1919, 0x3FAC28F5C0000000
  %1935 = fmul fast float %1932, 0x3FEE54EDE0000000
  %1936 = fmul fast float %1933, 0x3FEE54EDE0000000
  %1937 = fmul fast float %1934, 0x3FEE54EDE0000000
  %1938 = call float @dx.op.unary.f32(i32 23, float %1935)  ; Log(value)
  %1939 = call float @dx.op.unary.f32(i32 23, float %1936)  ; Log(value)
  %1940 = call float @dx.op.unary.f32(i32 23, float %1937)  ; Log(value)
  %1941 = fmul fast float %1938, 0x4003333340000000
  %1942 = fmul fast float %1939, 0x4003333340000000
  %1943 = fmul fast float %1940, 0x4003333340000000
  %1944 = call float @dx.op.unary.f32(i32 21, float %1941)  ; Exp(value)
  %1945 = call float @dx.op.unary.f32(i32 21, float %1942)  ; Exp(value)
  %1946 = call float @dx.op.unary.f32(i32 21, float %1943)  ; Exp(value)
  %1947 = fsub fast float %1929, %1944
  %1948 = fsub fast float %1930, %1945
  %1949 = fsub fast float %1931, %1946
  %1950 = fmul fast float %1947, %1926
  %1951 = fmul fast float %1948, %1927
  %1952 = fmul fast float %1949, %1928
  %1953 = fadd fast float %1950, %1944
  %1954 = fadd fast float %1951, %1945
  %1955 = fadd fast float %1952, %1946
  br label %2024

; <label>:1956                                    ; preds = %1911
  %1957 = fadd fast float %6, 1.000000e+00
  %1958 = fadd fast float %7, 1.000000e+00
  %1959 = fsub fast float 1.000000e+00, %6
  %1960 = fmul fast float %10, %1957
  %1961 = fmul fast float %10, %1958
  %1962 = fmul fast float %10, %1959
  %1963 = fmul fast float %1960, %1917
  %1964 = fmul fast float %1961, %1918
  %1965 = fmul fast float %1962, %1919
  %1966 = fcmp fast ult float %11, 5.000000e-01
  br i1 %1966, label %1992, label %1967

; <label>:1967                                    ; preds = %1956
  %1968 = fmul fast float %1963, 0x4004147AE0000000
  %1969 = fmul fast float %1964, 0x4004147AE0000000
  %1970 = fmul fast float %1965, 0x4004147AE0000000
  %1971 = fadd fast float %1968, 0x3F9EB851E0000000
  %1972 = fadd fast float %1969, 0x3F9EB851E0000000
  %1973 = fadd fast float %1970, 0x3F9EB851E0000000
  %1974 = fmul fast float %1971, %1963
  %1975 = fmul fast float %1972, %1964
  %1976 = fmul fast float %1973, %1965
  %1977 = fmul fast float %1963, 0x400370A3E0000000
  %1978 = fmul fast float %1964, 0x400370A3E0000000
  %1979 = fmul fast float %1965, 0x400370A3E0000000
  %1980 = fadd fast float %1977, 0x3FE2E147A0000000
  %1981 = fadd fast float %1978, 0x3FE2E147A0000000
  %1982 = fadd fast float %1979, 0x3FE2E147A0000000
  %1983 = fmul fast float %1980, %1963
  %1984 = fmul fast float %1981, %1964
  %1985 = fmul fast float %1982, %1965
  %1986 = fadd fast float %1983, 0x3FC1EB8520000000
  %1987 = fadd fast float %1984, 0x3FC1EB8520000000
  %1988 = fadd fast float %1985, 0x3FC1EB8520000000
  %1989 = fdiv fast float %1974, %1986
  %1990 = fdiv fast float %1975, %1987
  %1991 = fdiv fast float %1976, %1988
  br label %1992

; <label>:1992                                    ; preds = %1967, %1956
  %1993 = phi float [ %1989, %1967 ], [ %1963, %1956 ]
  %1994 = phi float [ %1990, %1967 ], [ %1964, %1956 ]
  %1995 = phi float [ %1991, %1967 ], [ %1965, %1956 ]
  %1996 = call float @dx.op.unary.f32(i32 7, float %1993)  ; Saturate(value)
  %1997 = call float @dx.op.unary.f32(i32 7, float %1994)  ; Saturate(value)
  %1998 = call float @dx.op.unary.f32(i32 7, float %1995)  ; Saturate(value)
  %1999 = call float @dx.op.dot3.f32(i32 55, float %1996, float %1997, float %1998, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2000 = fsub fast float %1996, %1999
  %2001 = fsub fast float %1997, %1999
  %2002 = fsub fast float %1998, %1999
  %2003 = fmul fast float %2000, %9
  %2004 = fmul fast float %2001, %9
  %2005 = fmul fast float %2002, %9
  %2006 = fadd fast float %2003, %1999
  %2007 = fadd fast float %2004, %1999
  %2008 = fadd fast float %2005, %1999
  %2009 = call float @dx.op.unary.f32(i32 7, float %2006)  ; Saturate(value)
  %2010 = call float @dx.op.unary.f32(i32 7, float %2007)  ; Saturate(value)
  %2011 = call float @dx.op.unary.f32(i32 7, float %2008)  ; Saturate(value)
  %2012 = fadd fast float %2009, 0xBFC70A3D80000000
  %2013 = fadd fast float %2010, 0xBFC70A3D80000000
  %2014 = fadd fast float %2011, 0xBFC70A3D80000000
  %2015 = fmul fast float %2012, %8
  %2016 = fmul fast float %2013, %8
  %2017 = fmul fast float %2014, %8
  %2018 = fadd fast float %2015, 0x3FC70A3D80000000
  %2019 = fadd fast float %2016, 0x3FC70A3D80000000
  %2020 = fadd fast float %2017, 0x3FC70A3D80000000
  %2021 = call float @dx.op.unary.f32(i32 7, float %2018)  ; Saturate(value)
  %2022 = call float @dx.op.unary.f32(i32 7, float %2019)  ; Saturate(value)
  %2023 = call float @dx.op.unary.f32(i32 7, float %2020)  ; Saturate(value)
  br label %2024

; <label>:2024                                    ; preds = %1992, %1922
  %2025 = phi float [ %1953, %1922 ], [ %2021, %1992 ]
  %2026 = phi float [ %1954, %1922 ], [ %2022, %1992 ]
  %2027 = phi float [ %1955, %1922 ], [ %2023, %1992 ]
  %2028 = fsub fast float %2025, %592
  %2029 = fsub fast float %2026, %593
  %2030 = fsub fast float %2027, %594
  %2031 = fmul fast float %2028, %1909
  %2032 = fmul fast float %2029, %1909
  %2033 = fmul fast float %2030, %1909
  %2034 = fadd fast float %2031, %592
  %2035 = fadd fast float %2032, %593
  %2036 = fadd fast float %2033, %594
  br label %2037

; <label>:2037                                    ; preds = %2024, %1896
  %2038 = phi float [ %2034, %2024 ], [ %592, %1896 ]
  %2039 = phi float [ %2035, %2024 ], [ %593, %1896 ]
  %2040 = phi float [ %2036, %2024 ], [ %594, %1896 ]
  %2041 = fsub fast float %58, %60
  %2042 = call float @dx.op.unary.f32(i32 6, float %2041)  ; FAbs(value)
  %2043 = fdiv fast float %2042, %1904
  %2044 = fsub fast float 1.000000e+00, %2043
  %2045 = call float @dx.op.unary.f32(i32 7, float %2044)  ; Saturate(value)
  %2046 = fcmp fast ugt float %2045, 0.000000e+00
  br i1 %2046, label %2047, label %2057

; <label>:2047                                    ; preds = %2037
  %2048 = fsub fast float %485, %592
  %2049 = fsub fast float %486, %593
  %2050 = fsub fast float %487, %594
  %2051 = fmul fast float %2045, %2048
  %2052 = fmul fast float %2045, %2049
  %2053 = fmul fast float %2045, %2050
  %2054 = fadd fast float %2051, %592
  %2055 = fadd fast float %2052, %593
  %2056 = fadd fast float %2053, %594
  br label %2057

; <label>:2057                                    ; preds = %2047, %2037
  %2058 = phi float [ %2054, %2047 ], [ %592, %2037 ]
  %2059 = phi float [ %2055, %2047 ], [ %593, %2037 ]
  %2060 = phi float [ %2056, %2047 ], [ %594, %2037 ]
  %2061 = add i32 %28, 2
  %2062 = call i32 @dx.op.binary.i32(i32 37, i32 %2061, i32 0)  ; IMax(a,b)
  %2063 = call i32 @dx.op.binary.i32(i32 38, i32 %2062, i32 %32)  ; IMin(a,b)
  %2064 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %39, i32 %2063, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2065 = extractvalue %dx.types.ResRet.f32 %2064, 0
  %2066 = fsub fast float %2065, %60
  %2067 = call float @dx.op.unary.f32(i32 6, float %2066)  ; FAbs(value)
  %2068 = fdiv fast float %2067, %1904
  %2069 = fsub fast float 1.000000e+00, %2068
  %2070 = call float @dx.op.unary.f32(i32 7, float %2069)  ; Saturate(value)
  %2071 = fcmp fast ugt float %2070, 0.000000e+00
  br i1 %2071, label %2072, label %2198

; <label>:2072                                    ; preds = %2057
  %2073 = call i32 @dx.op.binary.i32(i32 37, i32 %39, i32 0)  ; IMax(a,b)
  %2074 = call i32 @dx.op.binary.i32(i32 37, i32 %2063, i32 0)  ; IMax(a,b)
  %2075 = call i32 @dx.op.binary.i32(i32 38, i32 %2073, i32 %31)  ; IMin(a,b)
  %2076 = call i32 @dx.op.binary.i32(i32 38, i32 %2074, i32 %32)  ; IMin(a,b)
  %2077 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2075, i32 %2076, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2078 = extractvalue %dx.types.ResRet.f32 %2077, 0
  %2079 = extractvalue %dx.types.ResRet.f32 %2077, 1
  %2080 = extractvalue %dx.types.ResRet.f32 %2077, 2
  %2081 = extractvalue %dx.types.ResRet.f32 %2077, 3
  %2082 = fcmp fast olt float %2081, 0.000000e+00
  br i1 %2082, label %2083, label %2117

; <label>:2083                                    ; preds = %2072
  %2084 = fcmp fast ogt float %2078, 0x3FA4B5DCC0000000
  %2085 = fcmp fast ogt float %2079, 0x3FA4B5DCC0000000
  %2086 = fcmp fast ogt float %2080, 0x3FA4B5DCC0000000
  %2087 = select i1 %2084, float 0.000000e+00, float 1.000000e+00
  %2088 = select i1 %2085, float 0.000000e+00, float 1.000000e+00
  %2089 = select i1 %2086, float 0.000000e+00, float 1.000000e+00
  %2090 = fmul fast float %2078, 0x3FB3D07220000000
  %2091 = fmul fast float %2079, 0x3FB3D07220000000
  %2092 = fmul fast float %2080, 0x3FB3D07220000000
  %2093 = fadd fast float %2078, 0x3FAC28F5C0000000
  %2094 = fadd fast float %2079, 0x3FAC28F5C0000000
  %2095 = fadd fast float %2080, 0x3FAC28F5C0000000
  %2096 = fmul fast float %2093, 0x3FEE54EDE0000000
  %2097 = fmul fast float %2094, 0x3FEE54EDE0000000
  %2098 = fmul fast float %2095, 0x3FEE54EDE0000000
  %2099 = call float @dx.op.unary.f32(i32 23, float %2096)  ; Log(value)
  %2100 = call float @dx.op.unary.f32(i32 23, float %2097)  ; Log(value)
  %2101 = call float @dx.op.unary.f32(i32 23, float %2098)  ; Log(value)
  %2102 = fmul fast float %2099, 0x4003333340000000
  %2103 = fmul fast float %2100, 0x4003333340000000
  %2104 = fmul fast float %2101, 0x4003333340000000
  %2105 = call float @dx.op.unary.f32(i32 21, float %2102)  ; Exp(value)
  %2106 = call float @dx.op.unary.f32(i32 21, float %2103)  ; Exp(value)
  %2107 = call float @dx.op.unary.f32(i32 21, float %2104)  ; Exp(value)
  %2108 = fsub fast float %2090, %2105
  %2109 = fsub fast float %2091, %2106
  %2110 = fsub fast float %2092, %2107
  %2111 = fmul fast float %2108, %2087
  %2112 = fmul fast float %2109, %2088
  %2113 = fmul fast float %2110, %2089
  %2114 = fadd fast float %2111, %2105
  %2115 = fadd fast float %2112, %2106
  %2116 = fadd fast float %2113, %2107
  br label %2185

; <label>:2117                                    ; preds = %2072
  %2118 = fadd fast float %6, 1.000000e+00
  %2119 = fadd fast float %7, 1.000000e+00
  %2120 = fsub fast float 1.000000e+00, %6
  %2121 = fmul fast float %10, %2118
  %2122 = fmul fast float %10, %2119
  %2123 = fmul fast float %10, %2120
  %2124 = fmul fast float %2121, %2078
  %2125 = fmul fast float %2122, %2079
  %2126 = fmul fast float %2123, %2080
  %2127 = fcmp fast ult float %11, 5.000000e-01
  br i1 %2127, label %2153, label %2128

; <label>:2128                                    ; preds = %2117
  %2129 = fmul fast float %2124, 0x4004147AE0000000
  %2130 = fmul fast float %2125, 0x4004147AE0000000
  %2131 = fmul fast float %2126, 0x4004147AE0000000
  %2132 = fadd fast float %2129, 0x3F9EB851E0000000
  %2133 = fadd fast float %2130, 0x3F9EB851E0000000
  %2134 = fadd fast float %2131, 0x3F9EB851E0000000
  %2135 = fmul fast float %2132, %2124
  %2136 = fmul fast float %2133, %2125
  %2137 = fmul fast float %2134, %2126
  %2138 = fmul fast float %2124, 0x400370A3E0000000
  %2139 = fmul fast float %2125, 0x400370A3E0000000
  %2140 = fmul fast float %2126, 0x400370A3E0000000
  %2141 = fadd fast float %2138, 0x3FE2E147A0000000
  %2142 = fadd fast float %2139, 0x3FE2E147A0000000
  %2143 = fadd fast float %2140, 0x3FE2E147A0000000
  %2144 = fmul fast float %2141, %2124
  %2145 = fmul fast float %2142, %2125
  %2146 = fmul fast float %2143, %2126
  %2147 = fadd fast float %2144, 0x3FC1EB8520000000
  %2148 = fadd fast float %2145, 0x3FC1EB8520000000
  %2149 = fadd fast float %2146, 0x3FC1EB8520000000
  %2150 = fdiv fast float %2135, %2147
  %2151 = fdiv fast float %2136, %2148
  %2152 = fdiv fast float %2137, %2149
  br label %2153

; <label>:2153                                    ; preds = %2128, %2117
  %2154 = phi float [ %2150, %2128 ], [ %2124, %2117 ]
  %2155 = phi float [ %2151, %2128 ], [ %2125, %2117 ]
  %2156 = phi float [ %2152, %2128 ], [ %2126, %2117 ]
  %2157 = call float @dx.op.unary.f32(i32 7, float %2154)  ; Saturate(value)
  %2158 = call float @dx.op.unary.f32(i32 7, float %2155)  ; Saturate(value)
  %2159 = call float @dx.op.unary.f32(i32 7, float %2156)  ; Saturate(value)
  %2160 = call float @dx.op.dot3.f32(i32 55, float %2157, float %2158, float %2159, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2161 = fsub fast float %2157, %2160
  %2162 = fsub fast float %2158, %2160
  %2163 = fsub fast float %2159, %2160
  %2164 = fmul fast float %2161, %9
  %2165 = fmul fast float %2162, %9
  %2166 = fmul fast float %2163, %9
  %2167 = fadd fast float %2164, %2160
  %2168 = fadd fast float %2165, %2160
  %2169 = fadd fast float %2166, %2160
  %2170 = call float @dx.op.unary.f32(i32 7, float %2167)  ; Saturate(value)
  %2171 = call float @dx.op.unary.f32(i32 7, float %2168)  ; Saturate(value)
  %2172 = call float @dx.op.unary.f32(i32 7, float %2169)  ; Saturate(value)
  %2173 = fadd fast float %2170, 0xBFC70A3D80000000
  %2174 = fadd fast float %2171, 0xBFC70A3D80000000
  %2175 = fadd fast float %2172, 0xBFC70A3D80000000
  %2176 = fmul fast float %2173, %8
  %2177 = fmul fast float %2174, %8
  %2178 = fmul fast float %2175, %8
  %2179 = fadd fast float %2176, 0x3FC70A3D80000000
  %2180 = fadd fast float %2177, 0x3FC70A3D80000000
  %2181 = fadd fast float %2178, 0x3FC70A3D80000000
  %2182 = call float @dx.op.unary.f32(i32 7, float %2179)  ; Saturate(value)
  %2183 = call float @dx.op.unary.f32(i32 7, float %2180)  ; Saturate(value)
  %2184 = call float @dx.op.unary.f32(i32 7, float %2181)  ; Saturate(value)
  br label %2185

; <label>:2185                                    ; preds = %2153, %2083
  %2186 = phi float [ %2114, %2083 ], [ %2182, %2153 ]
  %2187 = phi float [ %2115, %2083 ], [ %2183, %2153 ]
  %2188 = phi float [ %2116, %2083 ], [ %2184, %2153 ]
  %2189 = fsub fast float %2186, %592
  %2190 = fsub fast float %2187, %593
  %2191 = fsub fast float %2188, %594
  %2192 = fmul fast float %2189, %2070
  %2193 = fmul fast float %2190, %2070
  %2194 = fmul fast float %2191, %2070
  %2195 = fadd fast float %2192, %592
  %2196 = fadd fast float %2193, %593
  %2197 = fadd fast float %2194, %594
  br label %2198

; <label>:2198                                    ; preds = %2185, %2057
  %2199 = phi float [ %2195, %2185 ], [ %592, %2057 ]
  %2200 = phi float [ %2196, %2185 ], [ %593, %2057 ]
  %2201 = phi float [ %2197, %2185 ], [ %594, %2057 ]
  %2202 = fsub fast float %56, %60
  %2203 = call float @dx.op.unary.f32(i32 6, float %2202)  ; FAbs(value)
  %2204 = fdiv fast float %2203, %1904
  %2205 = fsub fast float 1.000000e+00, %2204
  %2206 = call float @dx.op.unary.f32(i32 7, float %2205)  ; Saturate(value)
  %2207 = fcmp fast ugt float %2206, 0.000000e+00
  br i1 %2207, label %2208, label %2218

; <label>:2208                                    ; preds = %2198
  %2209 = fsub fast float %378, %592
  %2210 = fsub fast float %379, %593
  %2211 = fsub fast float %380, %594
  %2212 = fmul fast float %2206, %2209
  %2213 = fmul fast float %2206, %2210
  %2214 = fmul fast float %2206, %2211
  %2215 = fadd fast float %2212, %592
  %2216 = fadd fast float %2213, %593
  %2217 = fadd fast float %2214, %594
  br label %2218

; <label>:2218                                    ; preds = %2208, %2198
  %2219 = phi float [ %2215, %2208 ], [ %592, %2198 ]
  %2220 = phi float [ %2216, %2208 ], [ %593, %2198 ]
  %2221 = phi float [ %2217, %2208 ], [ %594, %2198 ]
  %2222 = call float @dx.op.binary.f32(i32 36, float %2058, float %2038)  ; FMin(a,b)
  %2223 = call float @dx.op.binary.f32(i32 36, float %2059, float %2039)  ; FMin(a,b)
  %2224 = call float @dx.op.binary.f32(i32 36, float %2060, float %2040)  ; FMin(a,b)
  %2225 = call float @dx.op.binary.f32(i32 36, float %2219, float %2199)  ; FMin(a,b)
  %2226 = call float @dx.op.binary.f32(i32 36, float %2220, float %2200)  ; FMin(a,b)
  %2227 = call float @dx.op.binary.f32(i32 36, float %2221, float %2201)  ; FMin(a,b)
  %2228 = call float @dx.op.binary.f32(i32 36, float %2225, float %2222)  ; FMin(a,b)
  %2229 = call float @dx.op.binary.f32(i32 36, float %2226, float %2223)  ; FMin(a,b)
  %2230 = call float @dx.op.binary.f32(i32 36, float %2227, float %2224)  ; FMin(a,b)
  %2231 = call float @dx.op.binary.f32(i32 36, float %592, float %2228)  ; FMin(a,b)
  %2232 = call float @dx.op.binary.f32(i32 36, float %593, float %2229)  ; FMin(a,b)
  %2233 = call float @dx.op.binary.f32(i32 36, float %594, float %2230)  ; FMin(a,b)
  %2234 = call float @dx.op.binary.f32(i32 35, float %2058, float %2038)  ; FMax(a,b)
  %2235 = call float @dx.op.binary.f32(i32 35, float %2059, float %2039)  ; FMax(a,b)
  %2236 = call float @dx.op.binary.f32(i32 35, float %2060, float %2040)  ; FMax(a,b)
  %2237 = call float @dx.op.binary.f32(i32 35, float %2219, float %2199)  ; FMax(a,b)
  %2238 = call float @dx.op.binary.f32(i32 35, float %2220, float %2200)  ; FMax(a,b)
  %2239 = call float @dx.op.binary.f32(i32 35, float %2221, float %2201)  ; FMax(a,b)
  %2240 = call float @dx.op.binary.f32(i32 35, float %2237, float %2234)  ; FMax(a,b)
  %2241 = call float @dx.op.binary.f32(i32 35, float %2238, float %2235)  ; FMax(a,b)
  %2242 = call float @dx.op.binary.f32(i32 35, float %2239, float %2236)  ; FMax(a,b)
  %2243 = call float @dx.op.binary.f32(i32 35, float %592, float %2240)  ; FMax(a,b)
  %2244 = call float @dx.op.binary.f32(i32 35, float %593, float %2241)  ; FMax(a,b)
  %2245 = call float @dx.op.binary.f32(i32 35, float %594, float %2242)  ; FMax(a,b)
  %2246 = fsub fast float %2243, %2231
  %2247 = fsub fast float %2244, %2232
  %2248 = fsub fast float %2245, %2233
  %2249 = call float @dx.op.unary.f32(i32 6, float %2246)  ; FAbs(value)
  %2250 = call float @dx.op.unary.f32(i32 6, float %2247)  ; FAbs(value)
  %2251 = call float @dx.op.unary.f32(i32 6, float %2248)  ; FAbs(value)
  %2252 = call float @dx.op.binary.f32(i32 35, float %2250, float %2251)  ; FMax(a,b)
  %2253 = call float @dx.op.binary.f32(i32 35, float %2249, float %2252)  ; FMax(a,b)
  %2254 = call float @dx.op.binary.f32(i32 35, float %2244, float %2245)  ; FMax(a,b)
  %2255 = call float @dx.op.binary.f32(i32 35, float %2243, float %2254)  ; FMax(a,b)
  %2256 = fmul fast float %2255, 1.250000e-01
  %2257 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %2256)  ; FMax(a,b)
  %2258 = fcmp fast ogt float %2253, %2257
  br i1 %2258, label %2259, label %5461

; <label>:2259                                    ; preds = %2218
  %2260 = fsub fast float %2219, %2199
  %2261 = fsub fast float %2220, %2200
  %2262 = fsub fast float %2221, %2201
  %2263 = call float @dx.op.unary.f32(i32 6, float %2260)  ; FAbs(value)
  %2264 = call float @dx.op.unary.f32(i32 6, float %2261)  ; FAbs(value)
  %2265 = call float @dx.op.unary.f32(i32 6, float %2262)  ; FAbs(value)
  %2266 = call float @dx.op.binary.f32(i32 35, float %2264, float %2265)  ; FMax(a,b)
  %2267 = call float @dx.op.binary.f32(i32 35, float %2263, float %2266)  ; FMax(a,b)
  %2268 = fsub fast float %2058, %2038
  %2269 = fsub fast float %2059, %2039
  %2270 = fsub fast float %2060, %2040
  %2271 = call float @dx.op.unary.f32(i32 6, float %2268)  ; FAbs(value)
  %2272 = call float @dx.op.unary.f32(i32 6, float %2269)  ; FAbs(value)
  %2273 = call float @dx.op.unary.f32(i32 6, float %2270)  ; FAbs(value)
  %2274 = call float @dx.op.binary.f32(i32 35, float %2272, float %2273)  ; FMax(a,b)
  %2275 = call float @dx.op.binary.f32(i32 35, float %2271, float %2274)  ; FMax(a,b)
  %2276 = fcmp fast olt float %2267, %2275
  %2277 = select i1 %2276, float %2219, float %2058
  %2278 = select i1 %2276, float %2220, float %2059
  %2279 = select i1 %2276, float %2221, float %2060
  %2280 = select i1 %2276, float %2199, float %2038
  %2281 = select i1 %2276, float %2200, float %2039
  %2282 = select i1 %2276, float %2201, float %2040
  %2283 = fsub fast float %592, %2280
  %2284 = fsub fast float %593, %2281
  %2285 = fsub fast float %594, %2282
  %2286 = fsub fast float %592, %2277
  %2287 = fsub fast float %593, %2278
  %2288 = fsub fast float %594, %2279
  %2289 = call float @dx.op.dot3.f32(i32 55, float %2286, float %2287, float %2288, float %2283, float %2284, float %2285)  ; Dot3(ax,ay,az,bx,by,bz)
  %2290 = fcmp fast ogt float %2289, 0.000000e+00
  br i1 %2290, label %2291, label %2303

; <label>:2291                                    ; preds = %2259
  %2292 = fsub fast float %2277, %2280
  %2293 = fsub fast float %2278, %2281
  %2294 = fsub fast float %2279, %2282
  %2295 = call float @dx.op.unary.f32(i32 6, float %2292)  ; FAbs(value)
  %2296 = call float @dx.op.unary.f32(i32 6, float %2293)  ; FAbs(value)
  %2297 = call float @dx.op.unary.f32(i32 6, float %2294)  ; FAbs(value)
  %2298 = call float @dx.op.binary.f32(i32 35, float %2296, float %2297)  ; FMax(a,b)
  %2299 = call float @dx.op.binary.f32(i32 35, float %2295, float %2298)  ; FMax(a,b)
  %2300 = fmul fast float %2253, 2.500000e-01
  %2301 = fcmp fast olt float %2299, %2300
  %2302 = select i1 %2301, float 5.000000e-01, float 1.000000e+00
  br label %2303

; <label>:2303                                    ; preds = %2291, %2259
  %2304 = phi float [ 1.000000e+00, %2259 ], [ %2302, %2291 ]
  %2305 = fmul fast float %2304, %3
  %2306 = fadd fast float %2277, %2280
  %2307 = fadd fast float %2278, %2281
  %2308 = fadd fast float %2279, %2282
  %2309 = fmul fast float %2306, 5.000000e-01
  %2310 = fmul fast float %2307, 5.000000e-01
  %2311 = fmul fast float %2308, 5.000000e-01
  %2312 = fsub fast float %2309, %592
  %2313 = fsub fast float %2310, %593
  %2314 = fsub fast float %2311, %594
  %2315 = fmul fast float %2305, %2312
  %2316 = fmul fast float %2305, %2313
  %2317 = fmul fast float %2305, %2314
  %2318 = fadd fast float %2315, %592
  %2319 = fadd fast float %2316, %593
  %2320 = fadd fast float %2317, %594
  br label %5461

; <label>:2321                                    ; preds = %144
  %2322 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %35, i32 %36, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2323 = extractvalue %dx.types.ResRet.f32 %2322, 0
  %2324 = extractvalue %dx.types.ResRet.f32 %2322, 1
  %2325 = extractvalue %dx.types.ResRet.f32 %2322, 2
  %2326 = extractvalue %dx.types.ResRet.f32 %2322, 3
  %2327 = fcmp fast olt float %2326, 0.000000e+00
  br i1 %2327, label %2328, label %2363

; <label>:2328                                    ; preds = %2321
  %2329 = fcmp fast ogt float %2323, 0x3FA4B5DCC0000000
  %2330 = fcmp fast ogt float %2324, 0x3FA4B5DCC0000000
  %2331 = fcmp fast ogt float %2325, 0x3FA4B5DCC0000000
  %2332 = select i1 %2329, float 0.000000e+00, float 1.000000e+00
  %2333 = select i1 %2330, float 0.000000e+00, float 1.000000e+00
  %2334 = select i1 %2331, float 0.000000e+00, float 1.000000e+00
  %2335 = fmul fast float %2323, 0x3FB3D07220000000
  %2336 = fmul fast float %2324, 0x3FB3D07220000000
  %2337 = fmul fast float %2325, 0x3FB3D07220000000
  %2338 = fadd fast float %2323, 0x3FAC28F5C0000000
  %2339 = fadd fast float %2324, 0x3FAC28F5C0000000
  %2340 = fadd fast float %2325, 0x3FAC28F5C0000000
  %2341 = fmul fast float %2338, 0x3FEE54EDE0000000
  %2342 = fmul fast float %2339, 0x3FEE54EDE0000000
  %2343 = fmul fast float %2340, 0x3FEE54EDE0000000
  %2344 = call float @dx.op.unary.f32(i32 23, float %2341)  ; Log(value)
  %2345 = call float @dx.op.unary.f32(i32 23, float %2342)  ; Log(value)
  %2346 = call float @dx.op.unary.f32(i32 23, float %2343)  ; Log(value)
  %2347 = fmul fast float %2344, 0x4003333340000000
  %2348 = fmul fast float %2345, 0x4003333340000000
  %2349 = fmul fast float %2346, 0x4003333340000000
  %2350 = call float @dx.op.unary.f32(i32 21, float %2347)  ; Exp(value)
  %2351 = call float @dx.op.unary.f32(i32 21, float %2348)  ; Exp(value)
  %2352 = call float @dx.op.unary.f32(i32 21, float %2349)  ; Exp(value)
  %2353 = fsub fast float %2335, %2350
  %2354 = fsub fast float %2336, %2351
  %2355 = fsub fast float %2337, %2352
  %2356 = fmul fast float %2353, %2332
  %2357 = fmul fast float %2354, %2333
  %2358 = fmul fast float %2355, %2334
  %2359 = fadd fast float %2356, %2350
  %2360 = fadd fast float %2357, %2351
  %2361 = fadd fast float %2358, %2352
  %2362 = fsub fast float -1.000000e+00, %2326
  br label %3103

; <label>:2363                                    ; preds = %2321
  %2364 = fadd fast float %6, 1.000000e+00
  %2365 = fadd fast float %7, 1.000000e+00
  %2366 = fsub fast float 1.000000e+00, %6
  %2367 = fmul fast float %10, %2364
  %2368 = fmul fast float %10, %2365
  %2369 = fmul fast float %10, %2366
  %2370 = fmul fast float %2367, %2323
  %2371 = fmul fast float %2368, %2324
  %2372 = fmul fast float %2369, %2325
  %2373 = fcmp fast ult float %11, 5.000000e-01
  br i1 %2373, label %2399, label %2374

; <label>:2374                                    ; preds = %2363
  %2375 = fmul fast float %2370, 0x4004147AE0000000
  %2376 = fmul fast float %2371, 0x4004147AE0000000
  %2377 = fmul fast float %2372, 0x4004147AE0000000
  %2378 = fadd fast float %2375, 0x3F9EB851E0000000
  %2379 = fadd fast float %2376, 0x3F9EB851E0000000
  %2380 = fadd fast float %2377, 0x3F9EB851E0000000
  %2381 = fmul fast float %2378, %2370
  %2382 = fmul fast float %2379, %2371
  %2383 = fmul fast float %2380, %2372
  %2384 = fmul fast float %2370, 0x400370A3E0000000
  %2385 = fmul fast float %2371, 0x400370A3E0000000
  %2386 = fmul fast float %2372, 0x400370A3E0000000
  %2387 = fadd fast float %2384, 0x3FE2E147A0000000
  %2388 = fadd fast float %2385, 0x3FE2E147A0000000
  %2389 = fadd fast float %2386, 0x3FE2E147A0000000
  %2390 = fmul fast float %2387, %2370
  %2391 = fmul fast float %2388, %2371
  %2392 = fmul fast float %2389, %2372
  %2393 = fadd fast float %2390, 0x3FC1EB8520000000
  %2394 = fadd fast float %2391, 0x3FC1EB8520000000
  %2395 = fadd fast float %2392, 0x3FC1EB8520000000
  %2396 = fdiv fast float %2381, %2393
  %2397 = fdiv fast float %2382, %2394
  %2398 = fdiv fast float %2383, %2395
  br label %2399

; <label>:2399                                    ; preds = %2374, %2363
  %2400 = phi float [ %2396, %2374 ], [ %2370, %2363 ]
  %2401 = phi float [ %2397, %2374 ], [ %2371, %2363 ]
  %2402 = phi float [ %2398, %2374 ], [ %2372, %2363 ]
  %2403 = call float @dx.op.unary.f32(i32 7, float %2400)  ; Saturate(value)
  %2404 = call float @dx.op.unary.f32(i32 7, float %2401)  ; Saturate(value)
  %2405 = call float @dx.op.unary.f32(i32 7, float %2402)  ; Saturate(value)
  %2406 = call float @dx.op.dot3.f32(i32 55, float %2403, float %2404, float %2405, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2407 = fsub fast float %2403, %2406
  %2408 = fsub fast float %2404, %2406
  %2409 = fsub fast float %2405, %2406
  %2410 = fmul fast float %2407, %9
  %2411 = fmul fast float %2408, %9
  %2412 = fmul fast float %2409, %9
  %2413 = fadd fast float %2410, %2406
  %2414 = fadd fast float %2411, %2406
  %2415 = fadd fast float %2412, %2406
  %2416 = call float @dx.op.unary.f32(i32 7, float %2413)  ; Saturate(value)
  %2417 = call float @dx.op.unary.f32(i32 7, float %2414)  ; Saturate(value)
  %2418 = call float @dx.op.unary.f32(i32 7, float %2415)  ; Saturate(value)
  %2419 = fadd fast float %2416, 0xBFC70A3D80000000
  %2420 = fadd fast float %2417, 0xBFC70A3D80000000
  %2421 = fadd fast float %2418, 0xBFC70A3D80000000
  %2422 = fmul fast float %2419, %8
  %2423 = fmul fast float %2420, %8
  %2424 = fmul fast float %2421, %8
  %2425 = fadd fast float %2422, 0x3FC70A3D80000000
  %2426 = fadd fast float %2423, 0x3FC70A3D80000000
  %2427 = fadd fast float %2424, 0x3FC70A3D80000000
  %2428 = call float @dx.op.unary.f32(i32 7, float %2425)  ; Saturate(value)
  %2429 = call float @dx.op.unary.f32(i32 7, float %2426)  ; Saturate(value)
  %2430 = call float @dx.op.unary.f32(i32 7, float %2427)  ; Saturate(value)
  %2431 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %2431, label %2432, label %3103

; <label>:2432                                    ; preds = %2399
  %2433 = add i32 %36, -1
  %2434 = call i32 @dx.op.binary.i32(i32 37, i32 %35, i32 0)  ; IMax(a,b)
  %2435 = call i32 @dx.op.binary.i32(i32 37, i32 %2433, i32 0)  ; IMax(a,b)
  %2436 = call i32 @dx.op.binary.i32(i32 38, i32 %2434, i32 %31)  ; IMin(a,b)
  %2437 = call i32 @dx.op.binary.i32(i32 38, i32 %2435, i32 %32)  ; IMin(a,b)
  %2438 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2436, i32 %2437, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2439 = extractvalue %dx.types.ResRet.f32 %2438, 0
  %2440 = fsub fast float 1.000000e+00, %54
  %2441 = fmul fast float %2440, 0x3FA99999A0000000
  %2442 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %2441)  ; FMax(a,b)
  %2443 = fsub fast float %2439, %54
  %2444 = call float @dx.op.unary.f32(i32 6, float %2443)  ; FAbs(value)
  %2445 = fdiv fast float %2444, %2442
  %2446 = fsub fast float 1.000000e+00, %2445
  %2447 = call float @dx.op.unary.f32(i32 7, float %2446)  ; Saturate(value)
  %2448 = fcmp fast ugt float %2447, 0.000000e+00
  br i1 %2448, label %2449, label %2575

; <label>:2449                                    ; preds = %2432
  %2450 = call i32 @dx.op.binary.i32(i32 37, i32 %2436, i32 0)  ; IMax(a,b)
  %2451 = call i32 @dx.op.binary.i32(i32 37, i32 %2437, i32 0)  ; IMax(a,b)
  %2452 = call i32 @dx.op.binary.i32(i32 38, i32 %2450, i32 %31)  ; IMin(a,b)
  %2453 = call i32 @dx.op.binary.i32(i32 38, i32 %2451, i32 %32)  ; IMin(a,b)
  %2454 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2452, i32 %2453, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2455 = extractvalue %dx.types.ResRet.f32 %2454, 0
  %2456 = extractvalue %dx.types.ResRet.f32 %2454, 1
  %2457 = extractvalue %dx.types.ResRet.f32 %2454, 2
  %2458 = extractvalue %dx.types.ResRet.f32 %2454, 3
  %2459 = fcmp fast olt float %2458, 0.000000e+00
  br i1 %2459, label %2460, label %2494

; <label>:2460                                    ; preds = %2449
  %2461 = fcmp fast ogt float %2455, 0x3FA4B5DCC0000000
  %2462 = fcmp fast ogt float %2456, 0x3FA4B5DCC0000000
  %2463 = fcmp fast ogt float %2457, 0x3FA4B5DCC0000000
  %2464 = select i1 %2461, float 0.000000e+00, float 1.000000e+00
  %2465 = select i1 %2462, float 0.000000e+00, float 1.000000e+00
  %2466 = select i1 %2463, float 0.000000e+00, float 1.000000e+00
  %2467 = fmul fast float %2455, 0x3FB3D07220000000
  %2468 = fmul fast float %2456, 0x3FB3D07220000000
  %2469 = fmul fast float %2457, 0x3FB3D07220000000
  %2470 = fadd fast float %2455, 0x3FAC28F5C0000000
  %2471 = fadd fast float %2456, 0x3FAC28F5C0000000
  %2472 = fadd fast float %2457, 0x3FAC28F5C0000000
  %2473 = fmul fast float %2470, 0x3FEE54EDE0000000
  %2474 = fmul fast float %2471, 0x3FEE54EDE0000000
  %2475 = fmul fast float %2472, 0x3FEE54EDE0000000
  %2476 = call float @dx.op.unary.f32(i32 23, float %2473)  ; Log(value)
  %2477 = call float @dx.op.unary.f32(i32 23, float %2474)  ; Log(value)
  %2478 = call float @dx.op.unary.f32(i32 23, float %2475)  ; Log(value)
  %2479 = fmul fast float %2476, 0x4003333340000000
  %2480 = fmul fast float %2477, 0x4003333340000000
  %2481 = fmul fast float %2478, 0x4003333340000000
  %2482 = call float @dx.op.unary.f32(i32 21, float %2479)  ; Exp(value)
  %2483 = call float @dx.op.unary.f32(i32 21, float %2480)  ; Exp(value)
  %2484 = call float @dx.op.unary.f32(i32 21, float %2481)  ; Exp(value)
  %2485 = fsub fast float %2467, %2482
  %2486 = fsub fast float %2468, %2483
  %2487 = fsub fast float %2469, %2484
  %2488 = fmul fast float %2485, %2464
  %2489 = fmul fast float %2486, %2465
  %2490 = fmul fast float %2487, %2466
  %2491 = fadd fast float %2488, %2482
  %2492 = fadd fast float %2489, %2483
  %2493 = fadd fast float %2490, %2484
  br label %2562

; <label>:2494                                    ; preds = %2449
  %2495 = fadd fast float %6, 1.000000e+00
  %2496 = fadd fast float %7, 1.000000e+00
  %2497 = fsub fast float 1.000000e+00, %6
  %2498 = fmul fast float %10, %2495
  %2499 = fmul fast float %10, %2496
  %2500 = fmul fast float %10, %2497
  %2501 = fmul fast float %2498, %2455
  %2502 = fmul fast float %2499, %2456
  %2503 = fmul fast float %2500, %2457
  %2504 = fcmp fast ult float %11, 5.000000e-01
  br i1 %2504, label %2530, label %2505

; <label>:2505                                    ; preds = %2494
  %2506 = fmul fast float %2501, 0x4004147AE0000000
  %2507 = fmul fast float %2502, 0x4004147AE0000000
  %2508 = fmul fast float %2503, 0x4004147AE0000000
  %2509 = fadd fast float %2506, 0x3F9EB851E0000000
  %2510 = fadd fast float %2507, 0x3F9EB851E0000000
  %2511 = fadd fast float %2508, 0x3F9EB851E0000000
  %2512 = fmul fast float %2509, %2501
  %2513 = fmul fast float %2510, %2502
  %2514 = fmul fast float %2511, %2503
  %2515 = fmul fast float %2501, 0x400370A3E0000000
  %2516 = fmul fast float %2502, 0x400370A3E0000000
  %2517 = fmul fast float %2503, 0x400370A3E0000000
  %2518 = fadd fast float %2515, 0x3FE2E147A0000000
  %2519 = fadd fast float %2516, 0x3FE2E147A0000000
  %2520 = fadd fast float %2517, 0x3FE2E147A0000000
  %2521 = fmul fast float %2518, %2501
  %2522 = fmul fast float %2519, %2502
  %2523 = fmul fast float %2520, %2503
  %2524 = fadd fast float %2521, 0x3FC1EB8520000000
  %2525 = fadd fast float %2522, 0x3FC1EB8520000000
  %2526 = fadd fast float %2523, 0x3FC1EB8520000000
  %2527 = fdiv fast float %2512, %2524
  %2528 = fdiv fast float %2513, %2525
  %2529 = fdiv fast float %2514, %2526
  br label %2530

; <label>:2530                                    ; preds = %2505, %2494
  %2531 = phi float [ %2527, %2505 ], [ %2501, %2494 ]
  %2532 = phi float [ %2528, %2505 ], [ %2502, %2494 ]
  %2533 = phi float [ %2529, %2505 ], [ %2503, %2494 ]
  %2534 = call float @dx.op.unary.f32(i32 7, float %2531)  ; Saturate(value)
  %2535 = call float @dx.op.unary.f32(i32 7, float %2532)  ; Saturate(value)
  %2536 = call float @dx.op.unary.f32(i32 7, float %2533)  ; Saturate(value)
  %2537 = call float @dx.op.dot3.f32(i32 55, float %2534, float %2535, float %2536, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2538 = fsub fast float %2534, %2537
  %2539 = fsub fast float %2535, %2537
  %2540 = fsub fast float %2536, %2537
  %2541 = fmul fast float %2538, %9
  %2542 = fmul fast float %2539, %9
  %2543 = fmul fast float %2540, %9
  %2544 = fadd fast float %2541, %2537
  %2545 = fadd fast float %2542, %2537
  %2546 = fadd fast float %2543, %2537
  %2547 = call float @dx.op.unary.f32(i32 7, float %2544)  ; Saturate(value)
  %2548 = call float @dx.op.unary.f32(i32 7, float %2545)  ; Saturate(value)
  %2549 = call float @dx.op.unary.f32(i32 7, float %2546)  ; Saturate(value)
  %2550 = fadd fast float %2547, 0xBFC70A3D80000000
  %2551 = fadd fast float %2548, 0xBFC70A3D80000000
  %2552 = fadd fast float %2549, 0xBFC70A3D80000000
  %2553 = fmul fast float %2550, %8
  %2554 = fmul fast float %2551, %8
  %2555 = fmul fast float %2552, %8
  %2556 = fadd fast float %2553, 0x3FC70A3D80000000
  %2557 = fadd fast float %2554, 0x3FC70A3D80000000
  %2558 = fadd fast float %2555, 0x3FC70A3D80000000
  %2559 = call float @dx.op.unary.f32(i32 7, float %2556)  ; Saturate(value)
  %2560 = call float @dx.op.unary.f32(i32 7, float %2557)  ; Saturate(value)
  %2561 = call float @dx.op.unary.f32(i32 7, float %2558)  ; Saturate(value)
  br label %2562

; <label>:2562                                    ; preds = %2530, %2460
  %2563 = phi float [ %2491, %2460 ], [ %2559, %2530 ]
  %2564 = phi float [ %2492, %2460 ], [ %2560, %2530 ]
  %2565 = phi float [ %2493, %2460 ], [ %2561, %2530 ]
  %2566 = fsub fast float %2563, %2428
  %2567 = fsub fast float %2564, %2429
  %2568 = fsub fast float %2565, %2430
  %2569 = fmul fast float %2566, %2447
  %2570 = fmul fast float %2567, %2447
  %2571 = fmul fast float %2568, %2447
  %2572 = fadd fast float %2569, %2428
  %2573 = fadd fast float %2570, %2429
  %2574 = fadd fast float %2571, %2430
  br label %2575

; <label>:2575                                    ; preds = %2562, %2432
  %2576 = phi float [ %2572, %2562 ], [ %2428, %2432 ]
  %2577 = phi float [ %2573, %2562 ], [ %2429, %2432 ]
  %2578 = phi float [ %2574, %2562 ], [ %2430, %2432 ]
  %2579 = add i32 %36, 1
  %2580 = call i32 @dx.op.binary.i32(i32 37, i32 %2579, i32 0)  ; IMax(a,b)
  %2581 = call i32 @dx.op.binary.i32(i32 38, i32 %2580, i32 %32)  ; IMin(a,b)
  %2582 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2436, i32 %2581, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2583 = extractvalue %dx.types.ResRet.f32 %2582, 0
  %2584 = fsub fast float %2583, %54
  %2585 = call float @dx.op.unary.f32(i32 6, float %2584)  ; FAbs(value)
  %2586 = fdiv fast float %2585, %2442
  %2587 = fsub fast float 1.000000e+00, %2586
  %2588 = call float @dx.op.unary.f32(i32 7, float %2587)  ; Saturate(value)
  %2589 = fcmp fast ugt float %2588, 0.000000e+00
  br i1 %2589, label %2590, label %2716

; <label>:2590                                    ; preds = %2575
  %2591 = call i32 @dx.op.binary.i32(i32 37, i32 %2436, i32 0)  ; IMax(a,b)
  %2592 = call i32 @dx.op.binary.i32(i32 37, i32 %2581, i32 0)  ; IMax(a,b)
  %2593 = call i32 @dx.op.binary.i32(i32 38, i32 %2591, i32 %31)  ; IMin(a,b)
  %2594 = call i32 @dx.op.binary.i32(i32 38, i32 %2592, i32 %32)  ; IMin(a,b)
  %2595 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2593, i32 %2594, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2596 = extractvalue %dx.types.ResRet.f32 %2595, 0
  %2597 = extractvalue %dx.types.ResRet.f32 %2595, 1
  %2598 = extractvalue %dx.types.ResRet.f32 %2595, 2
  %2599 = extractvalue %dx.types.ResRet.f32 %2595, 3
  %2600 = fcmp fast olt float %2599, 0.000000e+00
  br i1 %2600, label %2601, label %2635

; <label>:2601                                    ; preds = %2590
  %2602 = fcmp fast ogt float %2596, 0x3FA4B5DCC0000000
  %2603 = fcmp fast ogt float %2597, 0x3FA4B5DCC0000000
  %2604 = fcmp fast ogt float %2598, 0x3FA4B5DCC0000000
  %2605 = select i1 %2602, float 0.000000e+00, float 1.000000e+00
  %2606 = select i1 %2603, float 0.000000e+00, float 1.000000e+00
  %2607 = select i1 %2604, float 0.000000e+00, float 1.000000e+00
  %2608 = fmul fast float %2596, 0x3FB3D07220000000
  %2609 = fmul fast float %2597, 0x3FB3D07220000000
  %2610 = fmul fast float %2598, 0x3FB3D07220000000
  %2611 = fadd fast float %2596, 0x3FAC28F5C0000000
  %2612 = fadd fast float %2597, 0x3FAC28F5C0000000
  %2613 = fadd fast float %2598, 0x3FAC28F5C0000000
  %2614 = fmul fast float %2611, 0x3FEE54EDE0000000
  %2615 = fmul fast float %2612, 0x3FEE54EDE0000000
  %2616 = fmul fast float %2613, 0x3FEE54EDE0000000
  %2617 = call float @dx.op.unary.f32(i32 23, float %2614)  ; Log(value)
  %2618 = call float @dx.op.unary.f32(i32 23, float %2615)  ; Log(value)
  %2619 = call float @dx.op.unary.f32(i32 23, float %2616)  ; Log(value)
  %2620 = fmul fast float %2617, 0x4003333340000000
  %2621 = fmul fast float %2618, 0x4003333340000000
  %2622 = fmul fast float %2619, 0x4003333340000000
  %2623 = call float @dx.op.unary.f32(i32 21, float %2620)  ; Exp(value)
  %2624 = call float @dx.op.unary.f32(i32 21, float %2621)  ; Exp(value)
  %2625 = call float @dx.op.unary.f32(i32 21, float %2622)  ; Exp(value)
  %2626 = fsub fast float %2608, %2623
  %2627 = fsub fast float %2609, %2624
  %2628 = fsub fast float %2610, %2625
  %2629 = fmul fast float %2626, %2605
  %2630 = fmul fast float %2627, %2606
  %2631 = fmul fast float %2628, %2607
  %2632 = fadd fast float %2629, %2623
  %2633 = fadd fast float %2630, %2624
  %2634 = fadd fast float %2631, %2625
  br label %2703

; <label>:2635                                    ; preds = %2590
  %2636 = fadd fast float %6, 1.000000e+00
  %2637 = fadd fast float %7, 1.000000e+00
  %2638 = fsub fast float 1.000000e+00, %6
  %2639 = fmul fast float %10, %2636
  %2640 = fmul fast float %10, %2637
  %2641 = fmul fast float %10, %2638
  %2642 = fmul fast float %2639, %2596
  %2643 = fmul fast float %2640, %2597
  %2644 = fmul fast float %2641, %2598
  %2645 = fcmp fast ult float %11, 5.000000e-01
  br i1 %2645, label %2671, label %2646

; <label>:2646                                    ; preds = %2635
  %2647 = fmul fast float %2642, 0x4004147AE0000000
  %2648 = fmul fast float %2643, 0x4004147AE0000000
  %2649 = fmul fast float %2644, 0x4004147AE0000000
  %2650 = fadd fast float %2647, 0x3F9EB851E0000000
  %2651 = fadd fast float %2648, 0x3F9EB851E0000000
  %2652 = fadd fast float %2649, 0x3F9EB851E0000000
  %2653 = fmul fast float %2650, %2642
  %2654 = fmul fast float %2651, %2643
  %2655 = fmul fast float %2652, %2644
  %2656 = fmul fast float %2642, 0x400370A3E0000000
  %2657 = fmul fast float %2643, 0x400370A3E0000000
  %2658 = fmul fast float %2644, 0x400370A3E0000000
  %2659 = fadd fast float %2656, 0x3FE2E147A0000000
  %2660 = fadd fast float %2657, 0x3FE2E147A0000000
  %2661 = fadd fast float %2658, 0x3FE2E147A0000000
  %2662 = fmul fast float %2659, %2642
  %2663 = fmul fast float %2660, %2643
  %2664 = fmul fast float %2661, %2644
  %2665 = fadd fast float %2662, 0x3FC1EB8520000000
  %2666 = fadd fast float %2663, 0x3FC1EB8520000000
  %2667 = fadd fast float %2664, 0x3FC1EB8520000000
  %2668 = fdiv fast float %2653, %2665
  %2669 = fdiv fast float %2654, %2666
  %2670 = fdiv fast float %2655, %2667
  br label %2671

; <label>:2671                                    ; preds = %2646, %2635
  %2672 = phi float [ %2668, %2646 ], [ %2642, %2635 ]
  %2673 = phi float [ %2669, %2646 ], [ %2643, %2635 ]
  %2674 = phi float [ %2670, %2646 ], [ %2644, %2635 ]
  %2675 = call float @dx.op.unary.f32(i32 7, float %2672)  ; Saturate(value)
  %2676 = call float @dx.op.unary.f32(i32 7, float %2673)  ; Saturate(value)
  %2677 = call float @dx.op.unary.f32(i32 7, float %2674)  ; Saturate(value)
  %2678 = call float @dx.op.dot3.f32(i32 55, float %2675, float %2676, float %2677, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2679 = fsub fast float %2675, %2678
  %2680 = fsub fast float %2676, %2678
  %2681 = fsub fast float %2677, %2678
  %2682 = fmul fast float %2679, %9
  %2683 = fmul fast float %2680, %9
  %2684 = fmul fast float %2681, %9
  %2685 = fadd fast float %2682, %2678
  %2686 = fadd fast float %2683, %2678
  %2687 = fadd fast float %2684, %2678
  %2688 = call float @dx.op.unary.f32(i32 7, float %2685)  ; Saturate(value)
  %2689 = call float @dx.op.unary.f32(i32 7, float %2686)  ; Saturate(value)
  %2690 = call float @dx.op.unary.f32(i32 7, float %2687)  ; Saturate(value)
  %2691 = fadd fast float %2688, 0xBFC70A3D80000000
  %2692 = fadd fast float %2689, 0xBFC70A3D80000000
  %2693 = fadd fast float %2690, 0xBFC70A3D80000000
  %2694 = fmul fast float %2691, %8
  %2695 = fmul fast float %2692, %8
  %2696 = fmul fast float %2693, %8
  %2697 = fadd fast float %2694, 0x3FC70A3D80000000
  %2698 = fadd fast float %2695, 0x3FC70A3D80000000
  %2699 = fadd fast float %2696, 0x3FC70A3D80000000
  %2700 = call float @dx.op.unary.f32(i32 7, float %2697)  ; Saturate(value)
  %2701 = call float @dx.op.unary.f32(i32 7, float %2698)  ; Saturate(value)
  %2702 = call float @dx.op.unary.f32(i32 7, float %2699)  ; Saturate(value)
  br label %2703

; <label>:2703                                    ; preds = %2671, %2601
  %2704 = phi float [ %2632, %2601 ], [ %2700, %2671 ]
  %2705 = phi float [ %2633, %2601 ], [ %2701, %2671 ]
  %2706 = phi float [ %2634, %2601 ], [ %2702, %2671 ]
  %2707 = fsub fast float %2704, %2428
  %2708 = fsub fast float %2705, %2429
  %2709 = fsub fast float %2706, %2430
  %2710 = fmul fast float %2707, %2588
  %2711 = fmul fast float %2708, %2588
  %2712 = fmul fast float %2709, %2588
  %2713 = fadd fast float %2710, %2428
  %2714 = fadd fast float %2711, %2429
  %2715 = fadd fast float %2712, %2430
  br label %2716

; <label>:2716                                    ; preds = %2703, %2575
  %2717 = phi float [ %2713, %2703 ], [ %2428, %2575 ]
  %2718 = phi float [ %2714, %2703 ], [ %2429, %2575 ]
  %2719 = phi float [ %2715, %2703 ], [ %2430, %2575 ]
  %2720 = add i32 %35, -1
  %2721 = call i32 @dx.op.binary.i32(i32 37, i32 %2720, i32 0)  ; IMax(a,b)
  %2722 = call i32 @dx.op.binary.i32(i32 37, i32 %36, i32 0)  ; IMax(a,b)
  %2723 = call i32 @dx.op.binary.i32(i32 38, i32 %2721, i32 %31)  ; IMin(a,b)
  %2724 = call i32 @dx.op.binary.i32(i32 38, i32 %2722, i32 %32)  ; IMin(a,b)
  %2725 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2723, i32 %2724, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2726 = extractvalue %dx.types.ResRet.f32 %2725, 0
  %2727 = fsub fast float %2726, %54
  %2728 = call float @dx.op.unary.f32(i32 6, float %2727)  ; FAbs(value)
  %2729 = fdiv fast float %2728, %2442
  %2730 = fsub fast float 1.000000e+00, %2729
  %2731 = call float @dx.op.unary.f32(i32 7, float %2730)  ; Saturate(value)
  %2732 = fcmp fast ugt float %2731, 0.000000e+00
  br i1 %2732, label %2733, label %2859

; <label>:2733                                    ; preds = %2716
  %2734 = call i32 @dx.op.binary.i32(i32 37, i32 %2723, i32 0)  ; IMax(a,b)
  %2735 = call i32 @dx.op.binary.i32(i32 37, i32 %2724, i32 0)  ; IMax(a,b)
  %2736 = call i32 @dx.op.binary.i32(i32 38, i32 %2734, i32 %31)  ; IMin(a,b)
  %2737 = call i32 @dx.op.binary.i32(i32 38, i32 %2735, i32 %32)  ; IMin(a,b)
  %2738 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2736, i32 %2737, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2739 = extractvalue %dx.types.ResRet.f32 %2738, 0
  %2740 = extractvalue %dx.types.ResRet.f32 %2738, 1
  %2741 = extractvalue %dx.types.ResRet.f32 %2738, 2
  %2742 = extractvalue %dx.types.ResRet.f32 %2738, 3
  %2743 = fcmp fast olt float %2742, 0.000000e+00
  br i1 %2743, label %2744, label %2778

; <label>:2744                                    ; preds = %2733
  %2745 = fcmp fast ogt float %2739, 0x3FA4B5DCC0000000
  %2746 = fcmp fast ogt float %2740, 0x3FA4B5DCC0000000
  %2747 = fcmp fast ogt float %2741, 0x3FA4B5DCC0000000
  %2748 = select i1 %2745, float 0.000000e+00, float 1.000000e+00
  %2749 = select i1 %2746, float 0.000000e+00, float 1.000000e+00
  %2750 = select i1 %2747, float 0.000000e+00, float 1.000000e+00
  %2751 = fmul fast float %2739, 0x3FB3D07220000000
  %2752 = fmul fast float %2740, 0x3FB3D07220000000
  %2753 = fmul fast float %2741, 0x3FB3D07220000000
  %2754 = fadd fast float %2739, 0x3FAC28F5C0000000
  %2755 = fadd fast float %2740, 0x3FAC28F5C0000000
  %2756 = fadd fast float %2741, 0x3FAC28F5C0000000
  %2757 = fmul fast float %2754, 0x3FEE54EDE0000000
  %2758 = fmul fast float %2755, 0x3FEE54EDE0000000
  %2759 = fmul fast float %2756, 0x3FEE54EDE0000000
  %2760 = call float @dx.op.unary.f32(i32 23, float %2757)  ; Log(value)
  %2761 = call float @dx.op.unary.f32(i32 23, float %2758)  ; Log(value)
  %2762 = call float @dx.op.unary.f32(i32 23, float %2759)  ; Log(value)
  %2763 = fmul fast float %2760, 0x4003333340000000
  %2764 = fmul fast float %2761, 0x4003333340000000
  %2765 = fmul fast float %2762, 0x4003333340000000
  %2766 = call float @dx.op.unary.f32(i32 21, float %2763)  ; Exp(value)
  %2767 = call float @dx.op.unary.f32(i32 21, float %2764)  ; Exp(value)
  %2768 = call float @dx.op.unary.f32(i32 21, float %2765)  ; Exp(value)
  %2769 = fsub fast float %2751, %2766
  %2770 = fsub fast float %2752, %2767
  %2771 = fsub fast float %2753, %2768
  %2772 = fmul fast float %2769, %2748
  %2773 = fmul fast float %2770, %2749
  %2774 = fmul fast float %2771, %2750
  %2775 = fadd fast float %2772, %2766
  %2776 = fadd fast float %2773, %2767
  %2777 = fadd fast float %2774, %2768
  br label %2846

; <label>:2778                                    ; preds = %2733
  %2779 = fadd fast float %6, 1.000000e+00
  %2780 = fadd fast float %7, 1.000000e+00
  %2781 = fsub fast float 1.000000e+00, %6
  %2782 = fmul fast float %10, %2779
  %2783 = fmul fast float %10, %2780
  %2784 = fmul fast float %10, %2781
  %2785 = fmul fast float %2782, %2739
  %2786 = fmul fast float %2783, %2740
  %2787 = fmul fast float %2784, %2741
  %2788 = fcmp fast ult float %11, 5.000000e-01
  br i1 %2788, label %2814, label %2789

; <label>:2789                                    ; preds = %2778
  %2790 = fmul fast float %2785, 0x4004147AE0000000
  %2791 = fmul fast float %2786, 0x4004147AE0000000
  %2792 = fmul fast float %2787, 0x4004147AE0000000
  %2793 = fadd fast float %2790, 0x3F9EB851E0000000
  %2794 = fadd fast float %2791, 0x3F9EB851E0000000
  %2795 = fadd fast float %2792, 0x3F9EB851E0000000
  %2796 = fmul fast float %2793, %2785
  %2797 = fmul fast float %2794, %2786
  %2798 = fmul fast float %2795, %2787
  %2799 = fmul fast float %2785, 0x400370A3E0000000
  %2800 = fmul fast float %2786, 0x400370A3E0000000
  %2801 = fmul fast float %2787, 0x400370A3E0000000
  %2802 = fadd fast float %2799, 0x3FE2E147A0000000
  %2803 = fadd fast float %2800, 0x3FE2E147A0000000
  %2804 = fadd fast float %2801, 0x3FE2E147A0000000
  %2805 = fmul fast float %2802, %2785
  %2806 = fmul fast float %2803, %2786
  %2807 = fmul fast float %2804, %2787
  %2808 = fadd fast float %2805, 0x3FC1EB8520000000
  %2809 = fadd fast float %2806, 0x3FC1EB8520000000
  %2810 = fadd fast float %2807, 0x3FC1EB8520000000
  %2811 = fdiv fast float %2796, %2808
  %2812 = fdiv fast float %2797, %2809
  %2813 = fdiv fast float %2798, %2810
  br label %2814

; <label>:2814                                    ; preds = %2789, %2778
  %2815 = phi float [ %2811, %2789 ], [ %2785, %2778 ]
  %2816 = phi float [ %2812, %2789 ], [ %2786, %2778 ]
  %2817 = phi float [ %2813, %2789 ], [ %2787, %2778 ]
  %2818 = call float @dx.op.unary.f32(i32 7, float %2815)  ; Saturate(value)
  %2819 = call float @dx.op.unary.f32(i32 7, float %2816)  ; Saturate(value)
  %2820 = call float @dx.op.unary.f32(i32 7, float %2817)  ; Saturate(value)
  %2821 = call float @dx.op.dot3.f32(i32 55, float %2818, float %2819, float %2820, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2822 = fsub fast float %2818, %2821
  %2823 = fsub fast float %2819, %2821
  %2824 = fsub fast float %2820, %2821
  %2825 = fmul fast float %2822, %9
  %2826 = fmul fast float %2823, %9
  %2827 = fmul fast float %2824, %9
  %2828 = fadd fast float %2825, %2821
  %2829 = fadd fast float %2826, %2821
  %2830 = fadd fast float %2827, %2821
  %2831 = call float @dx.op.unary.f32(i32 7, float %2828)  ; Saturate(value)
  %2832 = call float @dx.op.unary.f32(i32 7, float %2829)  ; Saturate(value)
  %2833 = call float @dx.op.unary.f32(i32 7, float %2830)  ; Saturate(value)
  %2834 = fadd fast float %2831, 0xBFC70A3D80000000
  %2835 = fadd fast float %2832, 0xBFC70A3D80000000
  %2836 = fadd fast float %2833, 0xBFC70A3D80000000
  %2837 = fmul fast float %2834, %8
  %2838 = fmul fast float %2835, %8
  %2839 = fmul fast float %2836, %8
  %2840 = fadd fast float %2837, 0x3FC70A3D80000000
  %2841 = fadd fast float %2838, 0x3FC70A3D80000000
  %2842 = fadd fast float %2839, 0x3FC70A3D80000000
  %2843 = call float @dx.op.unary.f32(i32 7, float %2840)  ; Saturate(value)
  %2844 = call float @dx.op.unary.f32(i32 7, float %2841)  ; Saturate(value)
  %2845 = call float @dx.op.unary.f32(i32 7, float %2842)  ; Saturate(value)
  br label %2846

; <label>:2846                                    ; preds = %2814, %2744
  %2847 = phi float [ %2775, %2744 ], [ %2843, %2814 ]
  %2848 = phi float [ %2776, %2744 ], [ %2844, %2814 ]
  %2849 = phi float [ %2777, %2744 ], [ %2845, %2814 ]
  %2850 = fsub fast float %2847, %2428
  %2851 = fsub fast float %2848, %2429
  %2852 = fsub fast float %2849, %2430
  %2853 = fmul fast float %2850, %2731
  %2854 = fmul fast float %2851, %2731
  %2855 = fmul fast float %2852, %2731
  %2856 = fadd fast float %2853, %2428
  %2857 = fadd fast float %2854, %2429
  %2858 = fadd fast float %2855, %2430
  br label %2859

; <label>:2859                                    ; preds = %2846, %2716
  %2860 = phi float [ %2856, %2846 ], [ %2428, %2716 ]
  %2861 = phi float [ %2857, %2846 ], [ %2429, %2716 ]
  %2862 = phi float [ %2858, %2846 ], [ %2430, %2716 ]
  %2863 = add i32 %35, 1
  %2864 = call i32 @dx.op.binary.i32(i32 37, i32 %2863, i32 0)  ; IMax(a,b)
  %2865 = call i32 @dx.op.binary.i32(i32 38, i32 %2864, i32 %31)  ; IMin(a,b)
  %2866 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2865, i32 %2724, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2867 = extractvalue %dx.types.ResRet.f32 %2866, 0
  %2868 = fsub fast float %2867, %54
  %2869 = call float @dx.op.unary.f32(i32 6, float %2868)  ; FAbs(value)
  %2870 = fdiv fast float %2869, %2442
  %2871 = fsub fast float 1.000000e+00, %2870
  %2872 = call float @dx.op.unary.f32(i32 7, float %2871)  ; Saturate(value)
  %2873 = fcmp fast ugt float %2872, 0.000000e+00
  br i1 %2873, label %2874, label %3000

; <label>:2874                                    ; preds = %2859
  %2875 = call i32 @dx.op.binary.i32(i32 37, i32 %2865, i32 0)  ; IMax(a,b)
  %2876 = call i32 @dx.op.binary.i32(i32 37, i32 %2724, i32 0)  ; IMax(a,b)
  %2877 = call i32 @dx.op.binary.i32(i32 38, i32 %2875, i32 %31)  ; IMin(a,b)
  %2878 = call i32 @dx.op.binary.i32(i32 38, i32 %2876, i32 %32)  ; IMin(a,b)
  %2879 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2877, i32 %2878, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2880 = extractvalue %dx.types.ResRet.f32 %2879, 0
  %2881 = extractvalue %dx.types.ResRet.f32 %2879, 1
  %2882 = extractvalue %dx.types.ResRet.f32 %2879, 2
  %2883 = extractvalue %dx.types.ResRet.f32 %2879, 3
  %2884 = fcmp fast olt float %2883, 0.000000e+00
  br i1 %2884, label %2885, label %2919

; <label>:2885                                    ; preds = %2874
  %2886 = fcmp fast ogt float %2880, 0x3FA4B5DCC0000000
  %2887 = fcmp fast ogt float %2881, 0x3FA4B5DCC0000000
  %2888 = fcmp fast ogt float %2882, 0x3FA4B5DCC0000000
  %2889 = select i1 %2886, float 0.000000e+00, float 1.000000e+00
  %2890 = select i1 %2887, float 0.000000e+00, float 1.000000e+00
  %2891 = select i1 %2888, float 0.000000e+00, float 1.000000e+00
  %2892 = fmul fast float %2880, 0x3FB3D07220000000
  %2893 = fmul fast float %2881, 0x3FB3D07220000000
  %2894 = fmul fast float %2882, 0x3FB3D07220000000
  %2895 = fadd fast float %2880, 0x3FAC28F5C0000000
  %2896 = fadd fast float %2881, 0x3FAC28F5C0000000
  %2897 = fadd fast float %2882, 0x3FAC28F5C0000000
  %2898 = fmul fast float %2895, 0x3FEE54EDE0000000
  %2899 = fmul fast float %2896, 0x3FEE54EDE0000000
  %2900 = fmul fast float %2897, 0x3FEE54EDE0000000
  %2901 = call float @dx.op.unary.f32(i32 23, float %2898)  ; Log(value)
  %2902 = call float @dx.op.unary.f32(i32 23, float %2899)  ; Log(value)
  %2903 = call float @dx.op.unary.f32(i32 23, float %2900)  ; Log(value)
  %2904 = fmul fast float %2901, 0x4003333340000000
  %2905 = fmul fast float %2902, 0x4003333340000000
  %2906 = fmul fast float %2903, 0x4003333340000000
  %2907 = call float @dx.op.unary.f32(i32 21, float %2904)  ; Exp(value)
  %2908 = call float @dx.op.unary.f32(i32 21, float %2905)  ; Exp(value)
  %2909 = call float @dx.op.unary.f32(i32 21, float %2906)  ; Exp(value)
  %2910 = fsub fast float %2892, %2907
  %2911 = fsub fast float %2893, %2908
  %2912 = fsub fast float %2894, %2909
  %2913 = fmul fast float %2910, %2889
  %2914 = fmul fast float %2911, %2890
  %2915 = fmul fast float %2912, %2891
  %2916 = fadd fast float %2913, %2907
  %2917 = fadd fast float %2914, %2908
  %2918 = fadd fast float %2915, %2909
  br label %2987

; <label>:2919                                    ; preds = %2874
  %2920 = fadd fast float %6, 1.000000e+00
  %2921 = fadd fast float %7, 1.000000e+00
  %2922 = fsub fast float 1.000000e+00, %6
  %2923 = fmul fast float %10, %2920
  %2924 = fmul fast float %10, %2921
  %2925 = fmul fast float %10, %2922
  %2926 = fmul fast float %2923, %2880
  %2927 = fmul fast float %2924, %2881
  %2928 = fmul fast float %2925, %2882
  %2929 = fcmp fast ult float %11, 5.000000e-01
  br i1 %2929, label %2955, label %2930

; <label>:2930                                    ; preds = %2919
  %2931 = fmul fast float %2926, 0x4004147AE0000000
  %2932 = fmul fast float %2927, 0x4004147AE0000000
  %2933 = fmul fast float %2928, 0x4004147AE0000000
  %2934 = fadd fast float %2931, 0x3F9EB851E0000000
  %2935 = fadd fast float %2932, 0x3F9EB851E0000000
  %2936 = fadd fast float %2933, 0x3F9EB851E0000000
  %2937 = fmul fast float %2934, %2926
  %2938 = fmul fast float %2935, %2927
  %2939 = fmul fast float %2936, %2928
  %2940 = fmul fast float %2926, 0x400370A3E0000000
  %2941 = fmul fast float %2927, 0x400370A3E0000000
  %2942 = fmul fast float %2928, 0x400370A3E0000000
  %2943 = fadd fast float %2940, 0x3FE2E147A0000000
  %2944 = fadd fast float %2941, 0x3FE2E147A0000000
  %2945 = fadd fast float %2942, 0x3FE2E147A0000000
  %2946 = fmul fast float %2943, %2926
  %2947 = fmul fast float %2944, %2927
  %2948 = fmul fast float %2945, %2928
  %2949 = fadd fast float %2946, 0x3FC1EB8520000000
  %2950 = fadd fast float %2947, 0x3FC1EB8520000000
  %2951 = fadd fast float %2948, 0x3FC1EB8520000000
  %2952 = fdiv fast float %2937, %2949
  %2953 = fdiv fast float %2938, %2950
  %2954 = fdiv fast float %2939, %2951
  br label %2955

; <label>:2955                                    ; preds = %2930, %2919
  %2956 = phi float [ %2952, %2930 ], [ %2926, %2919 ]
  %2957 = phi float [ %2953, %2930 ], [ %2927, %2919 ]
  %2958 = phi float [ %2954, %2930 ], [ %2928, %2919 ]
  %2959 = call float @dx.op.unary.f32(i32 7, float %2956)  ; Saturate(value)
  %2960 = call float @dx.op.unary.f32(i32 7, float %2957)  ; Saturate(value)
  %2961 = call float @dx.op.unary.f32(i32 7, float %2958)  ; Saturate(value)
  %2962 = call float @dx.op.dot3.f32(i32 55, float %2959, float %2960, float %2961, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2963 = fsub fast float %2959, %2962
  %2964 = fsub fast float %2960, %2962
  %2965 = fsub fast float %2961, %2962
  %2966 = fmul fast float %2963, %9
  %2967 = fmul fast float %2964, %9
  %2968 = fmul fast float %2965, %9
  %2969 = fadd fast float %2966, %2962
  %2970 = fadd fast float %2967, %2962
  %2971 = fadd fast float %2968, %2962
  %2972 = call float @dx.op.unary.f32(i32 7, float %2969)  ; Saturate(value)
  %2973 = call float @dx.op.unary.f32(i32 7, float %2970)  ; Saturate(value)
  %2974 = call float @dx.op.unary.f32(i32 7, float %2971)  ; Saturate(value)
  %2975 = fadd fast float %2972, 0xBFC70A3D80000000
  %2976 = fadd fast float %2973, 0xBFC70A3D80000000
  %2977 = fadd fast float %2974, 0xBFC70A3D80000000
  %2978 = fmul fast float %2975, %8
  %2979 = fmul fast float %2976, %8
  %2980 = fmul fast float %2977, %8
  %2981 = fadd fast float %2978, 0x3FC70A3D80000000
  %2982 = fadd fast float %2979, 0x3FC70A3D80000000
  %2983 = fadd fast float %2980, 0x3FC70A3D80000000
  %2984 = call float @dx.op.unary.f32(i32 7, float %2981)  ; Saturate(value)
  %2985 = call float @dx.op.unary.f32(i32 7, float %2982)  ; Saturate(value)
  %2986 = call float @dx.op.unary.f32(i32 7, float %2983)  ; Saturate(value)
  br label %2987

; <label>:2987                                    ; preds = %2955, %2885
  %2988 = phi float [ %2916, %2885 ], [ %2984, %2955 ]
  %2989 = phi float [ %2917, %2885 ], [ %2985, %2955 ]
  %2990 = phi float [ %2918, %2885 ], [ %2986, %2955 ]
  %2991 = fsub fast float %2988, %2428
  %2992 = fsub fast float %2989, %2429
  %2993 = fsub fast float %2990, %2430
  %2994 = fmul fast float %2991, %2872
  %2995 = fmul fast float %2992, %2872
  %2996 = fmul fast float %2993, %2872
  %2997 = fadd fast float %2994, %2428
  %2998 = fadd fast float %2995, %2429
  %2999 = fadd fast float %2996, %2430
  br label %3000

; <label>:3000                                    ; preds = %2987, %2859
  %3001 = phi float [ %2997, %2987 ], [ %2428, %2859 ]
  %3002 = phi float [ %2998, %2987 ], [ %2429, %2859 ]
  %3003 = phi float [ %2999, %2987 ], [ %2430, %2859 ]
  %3004 = call float @dx.op.binary.f32(i32 36, float %2860, float %3001)  ; FMin(a,b)
  %3005 = call float @dx.op.binary.f32(i32 36, float %2861, float %3002)  ; FMin(a,b)
  %3006 = call float @dx.op.binary.f32(i32 36, float %2862, float %3003)  ; FMin(a,b)
  %3007 = call float @dx.op.binary.f32(i32 36, float %2576, float %2717)  ; FMin(a,b)
  %3008 = call float @dx.op.binary.f32(i32 36, float %2577, float %2718)  ; FMin(a,b)
  %3009 = call float @dx.op.binary.f32(i32 36, float %2578, float %2719)  ; FMin(a,b)
  %3010 = call float @dx.op.binary.f32(i32 36, float %3007, float %3004)  ; FMin(a,b)
  %3011 = call float @dx.op.binary.f32(i32 36, float %3008, float %3005)  ; FMin(a,b)
  %3012 = call float @dx.op.binary.f32(i32 36, float %3009, float %3006)  ; FMin(a,b)
  %3013 = call float @dx.op.binary.f32(i32 36, float %2428, float %3010)  ; FMin(a,b)
  %3014 = call float @dx.op.binary.f32(i32 36, float %2429, float %3011)  ; FMin(a,b)
  %3015 = call float @dx.op.binary.f32(i32 36, float %2430, float %3012)  ; FMin(a,b)
  %3016 = call float @dx.op.binary.f32(i32 35, float %2860, float %3001)  ; FMax(a,b)
  %3017 = call float @dx.op.binary.f32(i32 35, float %2861, float %3002)  ; FMax(a,b)
  %3018 = call float @dx.op.binary.f32(i32 35, float %2862, float %3003)  ; FMax(a,b)
  %3019 = call float @dx.op.binary.f32(i32 35, float %2576, float %2717)  ; FMax(a,b)
  %3020 = call float @dx.op.binary.f32(i32 35, float %2577, float %2718)  ; FMax(a,b)
  %3021 = call float @dx.op.binary.f32(i32 35, float %2578, float %2719)  ; FMax(a,b)
  %3022 = call float @dx.op.binary.f32(i32 35, float %3019, float %3016)  ; FMax(a,b)
  %3023 = call float @dx.op.binary.f32(i32 35, float %3020, float %3017)  ; FMax(a,b)
  %3024 = call float @dx.op.binary.f32(i32 35, float %3021, float %3018)  ; FMax(a,b)
  %3025 = call float @dx.op.binary.f32(i32 35, float %2428, float %3022)  ; FMax(a,b)
  %3026 = call float @dx.op.binary.f32(i32 35, float %2429, float %3023)  ; FMax(a,b)
  %3027 = call float @dx.op.binary.f32(i32 35, float %2430, float %3024)  ; FMax(a,b)
  %3028 = fsub fast float %3025, %3013
  %3029 = fsub fast float %3026, %3014
  %3030 = fsub fast float %3027, %3015
  %3031 = call float @dx.op.unary.f32(i32 6, float %3028)  ; FAbs(value)
  %3032 = call float @dx.op.unary.f32(i32 6, float %3029)  ; FAbs(value)
  %3033 = call float @dx.op.unary.f32(i32 6, float %3030)  ; FAbs(value)
  %3034 = call float @dx.op.binary.f32(i32 35, float %3032, float %3033)  ; FMax(a,b)
  %3035 = call float @dx.op.binary.f32(i32 35, float %3031, float %3034)  ; FMax(a,b)
  %3036 = call float @dx.op.binary.f32(i32 35, float %3026, float %3027)  ; FMax(a,b)
  %3037 = call float @dx.op.binary.f32(i32 35, float %3025, float %3036)  ; FMax(a,b)
  %3038 = fmul fast float %3037, 1.250000e-01
  %3039 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %3038)  ; FMax(a,b)
  %3040 = fcmp fast ogt float %3035, %3039
  br i1 %3040, label %3041, label %3103

; <label>:3041                                    ; preds = %3000
  %3042 = fsub fast float %2576, %2717
  %3043 = fsub fast float %2577, %2718
  %3044 = fsub fast float %2578, %2719
  %3045 = call float @dx.op.unary.f32(i32 6, float %3042)  ; FAbs(value)
  %3046 = call float @dx.op.unary.f32(i32 6, float %3043)  ; FAbs(value)
  %3047 = call float @dx.op.unary.f32(i32 6, float %3044)  ; FAbs(value)
  %3048 = call float @dx.op.binary.f32(i32 35, float %3046, float %3047)  ; FMax(a,b)
  %3049 = call float @dx.op.binary.f32(i32 35, float %3045, float %3048)  ; FMax(a,b)
  %3050 = fsub fast float %2860, %3001
  %3051 = fsub fast float %2861, %3002
  %3052 = fsub fast float %2862, %3003
  %3053 = call float @dx.op.unary.f32(i32 6, float %3050)  ; FAbs(value)
  %3054 = call float @dx.op.unary.f32(i32 6, float %3051)  ; FAbs(value)
  %3055 = call float @dx.op.unary.f32(i32 6, float %3052)  ; FAbs(value)
  %3056 = call float @dx.op.binary.f32(i32 35, float %3054, float %3055)  ; FMax(a,b)
  %3057 = call float @dx.op.binary.f32(i32 35, float %3053, float %3056)  ; FMax(a,b)
  %3058 = fcmp fast olt float %3049, %3057
  %3059 = select i1 %3058, float %2576, float %2860
  %3060 = select i1 %3058, float %2577, float %2861
  %3061 = select i1 %3058, float %2578, float %2862
  %3062 = select i1 %3058, float %2717, float %3001
  %3063 = select i1 %3058, float %2718, float %3002
  %3064 = select i1 %3058, float %2719, float %3003
  %3065 = fsub fast float %2428, %3062
  %3066 = fsub fast float %2429, %3063
  %3067 = fsub fast float %2430, %3064
  %3068 = fsub fast float %2428, %3059
  %3069 = fsub fast float %2429, %3060
  %3070 = fsub fast float %2430, %3061
  %3071 = call float @dx.op.dot3.f32(i32 55, float %3068, float %3069, float %3070, float %3065, float %3066, float %3067)  ; Dot3(ax,ay,az,bx,by,bz)
  %3072 = fcmp fast ogt float %3071, 0.000000e+00
  br i1 %3072, label %3073, label %3084

; <label>:3073                                    ; preds = %3041
  %3074 = fsub fast float %3059, %3062
  %3075 = fsub fast float %3060, %3063
  %3076 = fsub fast float %3061, %3064
  %3077 = call float @dx.op.unary.f32(i32 6, float %3074)  ; FAbs(value)
  %3078 = call float @dx.op.unary.f32(i32 6, float %3075)  ; FAbs(value)
  %3079 = call float @dx.op.unary.f32(i32 6, float %3076)  ; FAbs(value)
  %3080 = call float @dx.op.binary.f32(i32 35, float %3078, float %3079)  ; FMax(a,b)
  %3081 = call float @dx.op.binary.f32(i32 35, float %3077, float %3080)  ; FMax(a,b)
  %3082 = fmul fast float %3035, 2.500000e-01
  %3083 = fcmp fast olt float %3081, %3082
  br label %3084

; <label>:3084                                    ; preds = %3073, %3041
  %3085 = phi i1 [ false, %3041 ], [ %3083, %3073 ]
  %3086 = select i1 %3085, float 5.000000e-01, float 1.000000e+00
  %3087 = fmul fast float %3086, %3
  %3088 = fadd fast float %3059, %3062
  %3089 = fadd fast float %3060, %3063
  %3090 = fadd fast float %3061, %3064
  %3091 = fmul fast float %3088, 5.000000e-01
  %3092 = fmul fast float %3089, 5.000000e-01
  %3093 = fmul fast float %3090, 5.000000e-01
  %3094 = fsub fast float %3091, %2428
  %3095 = fsub fast float %3092, %2429
  %3096 = fsub fast float %3093, %2430
  %3097 = fmul fast float %3087, %3094
  %3098 = fmul fast float %3087, %3095
  %3099 = fmul fast float %3087, %3096
  %3100 = fadd fast float %3097, %2428
  %3101 = fadd fast float %3098, %2429
  %3102 = fadd fast float %3099, %2430
  br label %3103

; <label>:3103                                    ; preds = %3084, %3000, %2399, %2328
  %3104 = phi float [ %2359, %2328 ], [ %2428, %2399 ], [ %3100, %3084 ], [ %2428, %3000 ]
  %3105 = phi float [ %2360, %2328 ], [ %2429, %2399 ], [ %3101, %3084 ], [ %2429, %3000 ]
  %3106 = phi float [ %2361, %2328 ], [ %2430, %2399 ], [ %3102, %3084 ], [ %2430, %3000 ]
  %3107 = phi float [ %2362, %2328 ], [ %2326, %2399 ], [ %2326, %3084 ], [ %2326, %3000 ]
  %3108 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %39, i32 %36, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3109 = extractvalue %dx.types.ResRet.f32 %3108, 0
  %3110 = extractvalue %dx.types.ResRet.f32 %3108, 1
  %3111 = extractvalue %dx.types.ResRet.f32 %3108, 2
  %3112 = extractvalue %dx.types.ResRet.f32 %3108, 3
  %3113 = fcmp fast olt float %3112, 0.000000e+00
  br i1 %3113, label %3114, label %3149

; <label>:3114                                    ; preds = %3103
  %3115 = fcmp fast ogt float %3109, 0x3FA4B5DCC0000000
  %3116 = fcmp fast ogt float %3110, 0x3FA4B5DCC0000000
  %3117 = fcmp fast ogt float %3111, 0x3FA4B5DCC0000000
  %3118 = select i1 %3115, float 0.000000e+00, float 1.000000e+00
  %3119 = select i1 %3116, float 0.000000e+00, float 1.000000e+00
  %3120 = select i1 %3117, float 0.000000e+00, float 1.000000e+00
  %3121 = fmul fast float %3109, 0x3FB3D07220000000
  %3122 = fmul fast float %3110, 0x3FB3D07220000000
  %3123 = fmul fast float %3111, 0x3FB3D07220000000
  %3124 = fadd fast float %3109, 0x3FAC28F5C0000000
  %3125 = fadd fast float %3110, 0x3FAC28F5C0000000
  %3126 = fadd fast float %3111, 0x3FAC28F5C0000000
  %3127 = fmul fast float %3124, 0x3FEE54EDE0000000
  %3128 = fmul fast float %3125, 0x3FEE54EDE0000000
  %3129 = fmul fast float %3126, 0x3FEE54EDE0000000
  %3130 = call float @dx.op.unary.f32(i32 23, float %3127)  ; Log(value)
  %3131 = call float @dx.op.unary.f32(i32 23, float %3128)  ; Log(value)
  %3132 = call float @dx.op.unary.f32(i32 23, float %3129)  ; Log(value)
  %3133 = fmul fast float %3130, 0x4003333340000000
  %3134 = fmul fast float %3131, 0x4003333340000000
  %3135 = fmul fast float %3132, 0x4003333340000000
  %3136 = call float @dx.op.unary.f32(i32 21, float %3133)  ; Exp(value)
  %3137 = call float @dx.op.unary.f32(i32 21, float %3134)  ; Exp(value)
  %3138 = call float @dx.op.unary.f32(i32 21, float %3135)  ; Exp(value)
  %3139 = fsub fast float %3121, %3136
  %3140 = fsub fast float %3122, %3137
  %3141 = fsub fast float %3123, %3138
  %3142 = fmul fast float %3139, %3118
  %3143 = fmul fast float %3140, %3119
  %3144 = fmul fast float %3141, %3120
  %3145 = fadd fast float %3142, %3136
  %3146 = fadd fast float %3143, %3137
  %3147 = fadd fast float %3144, %3138
  %3148 = fsub fast float -1.000000e+00, %3112
  br label %3889

; <label>:3149                                    ; preds = %3103
  %3150 = fadd fast float %6, 1.000000e+00
  %3151 = fadd fast float %7, 1.000000e+00
  %3152 = fsub fast float 1.000000e+00, %6
  %3153 = fmul fast float %10, %3150
  %3154 = fmul fast float %10, %3151
  %3155 = fmul fast float %10, %3152
  %3156 = fmul fast float %3153, %3109
  %3157 = fmul fast float %3154, %3110
  %3158 = fmul fast float %3155, %3111
  %3159 = fcmp fast ult float %11, 5.000000e-01
  br i1 %3159, label %3185, label %3160

; <label>:3160                                    ; preds = %3149
  %3161 = fmul fast float %3156, 0x4004147AE0000000
  %3162 = fmul fast float %3157, 0x4004147AE0000000
  %3163 = fmul fast float %3158, 0x4004147AE0000000
  %3164 = fadd fast float %3161, 0x3F9EB851E0000000
  %3165 = fadd fast float %3162, 0x3F9EB851E0000000
  %3166 = fadd fast float %3163, 0x3F9EB851E0000000
  %3167 = fmul fast float %3164, %3156
  %3168 = fmul fast float %3165, %3157
  %3169 = fmul fast float %3166, %3158
  %3170 = fmul fast float %3156, 0x400370A3E0000000
  %3171 = fmul fast float %3157, 0x400370A3E0000000
  %3172 = fmul fast float %3158, 0x400370A3E0000000
  %3173 = fadd fast float %3170, 0x3FE2E147A0000000
  %3174 = fadd fast float %3171, 0x3FE2E147A0000000
  %3175 = fadd fast float %3172, 0x3FE2E147A0000000
  %3176 = fmul fast float %3173, %3156
  %3177 = fmul fast float %3174, %3157
  %3178 = fmul fast float %3175, %3158
  %3179 = fadd fast float %3176, 0x3FC1EB8520000000
  %3180 = fadd fast float %3177, 0x3FC1EB8520000000
  %3181 = fadd fast float %3178, 0x3FC1EB8520000000
  %3182 = fdiv fast float %3167, %3179
  %3183 = fdiv fast float %3168, %3180
  %3184 = fdiv fast float %3169, %3181
  br label %3185

; <label>:3185                                    ; preds = %3160, %3149
  %3186 = phi float [ %3182, %3160 ], [ %3156, %3149 ]
  %3187 = phi float [ %3183, %3160 ], [ %3157, %3149 ]
  %3188 = phi float [ %3184, %3160 ], [ %3158, %3149 ]
  %3189 = call float @dx.op.unary.f32(i32 7, float %3186)  ; Saturate(value)
  %3190 = call float @dx.op.unary.f32(i32 7, float %3187)  ; Saturate(value)
  %3191 = call float @dx.op.unary.f32(i32 7, float %3188)  ; Saturate(value)
  %3192 = call float @dx.op.dot3.f32(i32 55, float %3189, float %3190, float %3191, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3193 = fsub fast float %3189, %3192
  %3194 = fsub fast float %3190, %3192
  %3195 = fsub fast float %3191, %3192
  %3196 = fmul fast float %3193, %9
  %3197 = fmul fast float %3194, %9
  %3198 = fmul fast float %3195, %9
  %3199 = fadd fast float %3196, %3192
  %3200 = fadd fast float %3197, %3192
  %3201 = fadd fast float %3198, %3192
  %3202 = call float @dx.op.unary.f32(i32 7, float %3199)  ; Saturate(value)
  %3203 = call float @dx.op.unary.f32(i32 7, float %3200)  ; Saturate(value)
  %3204 = call float @dx.op.unary.f32(i32 7, float %3201)  ; Saturate(value)
  %3205 = fadd fast float %3202, 0xBFC70A3D80000000
  %3206 = fadd fast float %3203, 0xBFC70A3D80000000
  %3207 = fadd fast float %3204, 0xBFC70A3D80000000
  %3208 = fmul fast float %3205, %8
  %3209 = fmul fast float %3206, %8
  %3210 = fmul fast float %3207, %8
  %3211 = fadd fast float %3208, 0x3FC70A3D80000000
  %3212 = fadd fast float %3209, 0x3FC70A3D80000000
  %3213 = fadd fast float %3210, 0x3FC70A3D80000000
  %3214 = call float @dx.op.unary.f32(i32 7, float %3211)  ; Saturate(value)
  %3215 = call float @dx.op.unary.f32(i32 7, float %3212)  ; Saturate(value)
  %3216 = call float @dx.op.unary.f32(i32 7, float %3213)  ; Saturate(value)
  %3217 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %3217, label %3218, label %3889

; <label>:3218                                    ; preds = %3185
  %3219 = add i32 %36, -1
  %3220 = call i32 @dx.op.binary.i32(i32 37, i32 %39, i32 0)  ; IMax(a,b)
  %3221 = call i32 @dx.op.binary.i32(i32 37, i32 %3219, i32 0)  ; IMax(a,b)
  %3222 = call i32 @dx.op.binary.i32(i32 38, i32 %3220, i32 %31)  ; IMin(a,b)
  %3223 = call i32 @dx.op.binary.i32(i32 38, i32 %3221, i32 %32)  ; IMin(a,b)
  %3224 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3222, i32 %3223, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3225 = extractvalue %dx.types.ResRet.f32 %3224, 0
  %3226 = fsub fast float 1.000000e+00, %56
  %3227 = fmul fast float %3226, 0x3FA99999A0000000
  %3228 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %3227)  ; FMax(a,b)
  %3229 = fsub fast float %3225, %56
  %3230 = call float @dx.op.unary.f32(i32 6, float %3229)  ; FAbs(value)
  %3231 = fdiv fast float %3230, %3228
  %3232 = fsub fast float 1.000000e+00, %3231
  %3233 = call float @dx.op.unary.f32(i32 7, float %3232)  ; Saturate(value)
  %3234 = fcmp fast ugt float %3233, 0.000000e+00
  br i1 %3234, label %3235, label %3361

; <label>:3235                                    ; preds = %3218
  %3236 = call i32 @dx.op.binary.i32(i32 37, i32 %3222, i32 0)  ; IMax(a,b)
  %3237 = call i32 @dx.op.binary.i32(i32 37, i32 %3223, i32 0)  ; IMax(a,b)
  %3238 = call i32 @dx.op.binary.i32(i32 38, i32 %3236, i32 %31)  ; IMin(a,b)
  %3239 = call i32 @dx.op.binary.i32(i32 38, i32 %3237, i32 %32)  ; IMin(a,b)
  %3240 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3238, i32 %3239, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3241 = extractvalue %dx.types.ResRet.f32 %3240, 0
  %3242 = extractvalue %dx.types.ResRet.f32 %3240, 1
  %3243 = extractvalue %dx.types.ResRet.f32 %3240, 2
  %3244 = extractvalue %dx.types.ResRet.f32 %3240, 3
  %3245 = fcmp fast olt float %3244, 0.000000e+00
  br i1 %3245, label %3246, label %3280

; <label>:3246                                    ; preds = %3235
  %3247 = fcmp fast ogt float %3241, 0x3FA4B5DCC0000000
  %3248 = fcmp fast ogt float %3242, 0x3FA4B5DCC0000000
  %3249 = fcmp fast ogt float %3243, 0x3FA4B5DCC0000000
  %3250 = select i1 %3247, float 0.000000e+00, float 1.000000e+00
  %3251 = select i1 %3248, float 0.000000e+00, float 1.000000e+00
  %3252 = select i1 %3249, float 0.000000e+00, float 1.000000e+00
  %3253 = fmul fast float %3241, 0x3FB3D07220000000
  %3254 = fmul fast float %3242, 0x3FB3D07220000000
  %3255 = fmul fast float %3243, 0x3FB3D07220000000
  %3256 = fadd fast float %3241, 0x3FAC28F5C0000000
  %3257 = fadd fast float %3242, 0x3FAC28F5C0000000
  %3258 = fadd fast float %3243, 0x3FAC28F5C0000000
  %3259 = fmul fast float %3256, 0x3FEE54EDE0000000
  %3260 = fmul fast float %3257, 0x3FEE54EDE0000000
  %3261 = fmul fast float %3258, 0x3FEE54EDE0000000
  %3262 = call float @dx.op.unary.f32(i32 23, float %3259)  ; Log(value)
  %3263 = call float @dx.op.unary.f32(i32 23, float %3260)  ; Log(value)
  %3264 = call float @dx.op.unary.f32(i32 23, float %3261)  ; Log(value)
  %3265 = fmul fast float %3262, 0x4003333340000000
  %3266 = fmul fast float %3263, 0x4003333340000000
  %3267 = fmul fast float %3264, 0x4003333340000000
  %3268 = call float @dx.op.unary.f32(i32 21, float %3265)  ; Exp(value)
  %3269 = call float @dx.op.unary.f32(i32 21, float %3266)  ; Exp(value)
  %3270 = call float @dx.op.unary.f32(i32 21, float %3267)  ; Exp(value)
  %3271 = fsub fast float %3253, %3268
  %3272 = fsub fast float %3254, %3269
  %3273 = fsub fast float %3255, %3270
  %3274 = fmul fast float %3271, %3250
  %3275 = fmul fast float %3272, %3251
  %3276 = fmul fast float %3273, %3252
  %3277 = fadd fast float %3274, %3268
  %3278 = fadd fast float %3275, %3269
  %3279 = fadd fast float %3276, %3270
  br label %3348

; <label>:3280                                    ; preds = %3235
  %3281 = fadd fast float %6, 1.000000e+00
  %3282 = fadd fast float %7, 1.000000e+00
  %3283 = fsub fast float 1.000000e+00, %6
  %3284 = fmul fast float %10, %3281
  %3285 = fmul fast float %10, %3282
  %3286 = fmul fast float %10, %3283
  %3287 = fmul fast float %3284, %3241
  %3288 = fmul fast float %3285, %3242
  %3289 = fmul fast float %3286, %3243
  %3290 = fcmp fast ult float %11, 5.000000e-01
  br i1 %3290, label %3316, label %3291

; <label>:3291                                    ; preds = %3280
  %3292 = fmul fast float %3287, 0x4004147AE0000000
  %3293 = fmul fast float %3288, 0x4004147AE0000000
  %3294 = fmul fast float %3289, 0x4004147AE0000000
  %3295 = fadd fast float %3292, 0x3F9EB851E0000000
  %3296 = fadd fast float %3293, 0x3F9EB851E0000000
  %3297 = fadd fast float %3294, 0x3F9EB851E0000000
  %3298 = fmul fast float %3295, %3287
  %3299 = fmul fast float %3296, %3288
  %3300 = fmul fast float %3297, %3289
  %3301 = fmul fast float %3287, 0x400370A3E0000000
  %3302 = fmul fast float %3288, 0x400370A3E0000000
  %3303 = fmul fast float %3289, 0x400370A3E0000000
  %3304 = fadd fast float %3301, 0x3FE2E147A0000000
  %3305 = fadd fast float %3302, 0x3FE2E147A0000000
  %3306 = fadd fast float %3303, 0x3FE2E147A0000000
  %3307 = fmul fast float %3304, %3287
  %3308 = fmul fast float %3305, %3288
  %3309 = fmul fast float %3306, %3289
  %3310 = fadd fast float %3307, 0x3FC1EB8520000000
  %3311 = fadd fast float %3308, 0x3FC1EB8520000000
  %3312 = fadd fast float %3309, 0x3FC1EB8520000000
  %3313 = fdiv fast float %3298, %3310
  %3314 = fdiv fast float %3299, %3311
  %3315 = fdiv fast float %3300, %3312
  br label %3316

; <label>:3316                                    ; preds = %3291, %3280
  %3317 = phi float [ %3313, %3291 ], [ %3287, %3280 ]
  %3318 = phi float [ %3314, %3291 ], [ %3288, %3280 ]
  %3319 = phi float [ %3315, %3291 ], [ %3289, %3280 ]
  %3320 = call float @dx.op.unary.f32(i32 7, float %3317)  ; Saturate(value)
  %3321 = call float @dx.op.unary.f32(i32 7, float %3318)  ; Saturate(value)
  %3322 = call float @dx.op.unary.f32(i32 7, float %3319)  ; Saturate(value)
  %3323 = call float @dx.op.dot3.f32(i32 55, float %3320, float %3321, float %3322, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3324 = fsub fast float %3320, %3323
  %3325 = fsub fast float %3321, %3323
  %3326 = fsub fast float %3322, %3323
  %3327 = fmul fast float %3324, %9
  %3328 = fmul fast float %3325, %9
  %3329 = fmul fast float %3326, %9
  %3330 = fadd fast float %3327, %3323
  %3331 = fadd fast float %3328, %3323
  %3332 = fadd fast float %3329, %3323
  %3333 = call float @dx.op.unary.f32(i32 7, float %3330)  ; Saturate(value)
  %3334 = call float @dx.op.unary.f32(i32 7, float %3331)  ; Saturate(value)
  %3335 = call float @dx.op.unary.f32(i32 7, float %3332)  ; Saturate(value)
  %3336 = fadd fast float %3333, 0xBFC70A3D80000000
  %3337 = fadd fast float %3334, 0xBFC70A3D80000000
  %3338 = fadd fast float %3335, 0xBFC70A3D80000000
  %3339 = fmul fast float %3336, %8
  %3340 = fmul fast float %3337, %8
  %3341 = fmul fast float %3338, %8
  %3342 = fadd fast float %3339, 0x3FC70A3D80000000
  %3343 = fadd fast float %3340, 0x3FC70A3D80000000
  %3344 = fadd fast float %3341, 0x3FC70A3D80000000
  %3345 = call float @dx.op.unary.f32(i32 7, float %3342)  ; Saturate(value)
  %3346 = call float @dx.op.unary.f32(i32 7, float %3343)  ; Saturate(value)
  %3347 = call float @dx.op.unary.f32(i32 7, float %3344)  ; Saturate(value)
  br label %3348

; <label>:3348                                    ; preds = %3316, %3246
  %3349 = phi float [ %3277, %3246 ], [ %3345, %3316 ]
  %3350 = phi float [ %3278, %3246 ], [ %3346, %3316 ]
  %3351 = phi float [ %3279, %3246 ], [ %3347, %3316 ]
  %3352 = fsub fast float %3349, %3214
  %3353 = fsub fast float %3350, %3215
  %3354 = fsub fast float %3351, %3216
  %3355 = fmul fast float %3352, %3233
  %3356 = fmul fast float %3353, %3233
  %3357 = fmul fast float %3354, %3233
  %3358 = fadd fast float %3355, %3214
  %3359 = fadd fast float %3356, %3215
  %3360 = fadd fast float %3357, %3216
  br label %3361

; <label>:3361                                    ; preds = %3348, %3218
  %3362 = phi float [ %3358, %3348 ], [ %3214, %3218 ]
  %3363 = phi float [ %3359, %3348 ], [ %3215, %3218 ]
  %3364 = phi float [ %3360, %3348 ], [ %3216, %3218 ]
  %3365 = add i32 %36, 1
  %3366 = call i32 @dx.op.binary.i32(i32 37, i32 %3365, i32 0)  ; IMax(a,b)
  %3367 = call i32 @dx.op.binary.i32(i32 38, i32 %3366, i32 %32)  ; IMin(a,b)
  %3368 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3222, i32 %3367, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3369 = extractvalue %dx.types.ResRet.f32 %3368, 0
  %3370 = fsub fast float %3369, %56
  %3371 = call float @dx.op.unary.f32(i32 6, float %3370)  ; FAbs(value)
  %3372 = fdiv fast float %3371, %3228
  %3373 = fsub fast float 1.000000e+00, %3372
  %3374 = call float @dx.op.unary.f32(i32 7, float %3373)  ; Saturate(value)
  %3375 = fcmp fast ugt float %3374, 0.000000e+00
  br i1 %3375, label %3376, label %3502

; <label>:3376                                    ; preds = %3361
  %3377 = call i32 @dx.op.binary.i32(i32 37, i32 %3222, i32 0)  ; IMax(a,b)
  %3378 = call i32 @dx.op.binary.i32(i32 37, i32 %3367, i32 0)  ; IMax(a,b)
  %3379 = call i32 @dx.op.binary.i32(i32 38, i32 %3377, i32 %31)  ; IMin(a,b)
  %3380 = call i32 @dx.op.binary.i32(i32 38, i32 %3378, i32 %32)  ; IMin(a,b)
  %3381 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3379, i32 %3380, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3382 = extractvalue %dx.types.ResRet.f32 %3381, 0
  %3383 = extractvalue %dx.types.ResRet.f32 %3381, 1
  %3384 = extractvalue %dx.types.ResRet.f32 %3381, 2
  %3385 = extractvalue %dx.types.ResRet.f32 %3381, 3
  %3386 = fcmp fast olt float %3385, 0.000000e+00
  br i1 %3386, label %3387, label %3421

; <label>:3387                                    ; preds = %3376
  %3388 = fcmp fast ogt float %3382, 0x3FA4B5DCC0000000
  %3389 = fcmp fast ogt float %3383, 0x3FA4B5DCC0000000
  %3390 = fcmp fast ogt float %3384, 0x3FA4B5DCC0000000
  %3391 = select i1 %3388, float 0.000000e+00, float 1.000000e+00
  %3392 = select i1 %3389, float 0.000000e+00, float 1.000000e+00
  %3393 = select i1 %3390, float 0.000000e+00, float 1.000000e+00
  %3394 = fmul fast float %3382, 0x3FB3D07220000000
  %3395 = fmul fast float %3383, 0x3FB3D07220000000
  %3396 = fmul fast float %3384, 0x3FB3D07220000000
  %3397 = fadd fast float %3382, 0x3FAC28F5C0000000
  %3398 = fadd fast float %3383, 0x3FAC28F5C0000000
  %3399 = fadd fast float %3384, 0x3FAC28F5C0000000
  %3400 = fmul fast float %3397, 0x3FEE54EDE0000000
  %3401 = fmul fast float %3398, 0x3FEE54EDE0000000
  %3402 = fmul fast float %3399, 0x3FEE54EDE0000000
  %3403 = call float @dx.op.unary.f32(i32 23, float %3400)  ; Log(value)
  %3404 = call float @dx.op.unary.f32(i32 23, float %3401)  ; Log(value)
  %3405 = call float @dx.op.unary.f32(i32 23, float %3402)  ; Log(value)
  %3406 = fmul fast float %3403, 0x4003333340000000
  %3407 = fmul fast float %3404, 0x4003333340000000
  %3408 = fmul fast float %3405, 0x4003333340000000
  %3409 = call float @dx.op.unary.f32(i32 21, float %3406)  ; Exp(value)
  %3410 = call float @dx.op.unary.f32(i32 21, float %3407)  ; Exp(value)
  %3411 = call float @dx.op.unary.f32(i32 21, float %3408)  ; Exp(value)
  %3412 = fsub fast float %3394, %3409
  %3413 = fsub fast float %3395, %3410
  %3414 = fsub fast float %3396, %3411
  %3415 = fmul fast float %3412, %3391
  %3416 = fmul fast float %3413, %3392
  %3417 = fmul fast float %3414, %3393
  %3418 = fadd fast float %3415, %3409
  %3419 = fadd fast float %3416, %3410
  %3420 = fadd fast float %3417, %3411
  br label %3489

; <label>:3421                                    ; preds = %3376
  %3422 = fadd fast float %6, 1.000000e+00
  %3423 = fadd fast float %7, 1.000000e+00
  %3424 = fsub fast float 1.000000e+00, %6
  %3425 = fmul fast float %10, %3422
  %3426 = fmul fast float %10, %3423
  %3427 = fmul fast float %10, %3424
  %3428 = fmul fast float %3425, %3382
  %3429 = fmul fast float %3426, %3383
  %3430 = fmul fast float %3427, %3384
  %3431 = fcmp fast ult float %11, 5.000000e-01
  br i1 %3431, label %3457, label %3432

; <label>:3432                                    ; preds = %3421
  %3433 = fmul fast float %3428, 0x4004147AE0000000
  %3434 = fmul fast float %3429, 0x4004147AE0000000
  %3435 = fmul fast float %3430, 0x4004147AE0000000
  %3436 = fadd fast float %3433, 0x3F9EB851E0000000
  %3437 = fadd fast float %3434, 0x3F9EB851E0000000
  %3438 = fadd fast float %3435, 0x3F9EB851E0000000
  %3439 = fmul fast float %3436, %3428
  %3440 = fmul fast float %3437, %3429
  %3441 = fmul fast float %3438, %3430
  %3442 = fmul fast float %3428, 0x400370A3E0000000
  %3443 = fmul fast float %3429, 0x400370A3E0000000
  %3444 = fmul fast float %3430, 0x400370A3E0000000
  %3445 = fadd fast float %3442, 0x3FE2E147A0000000
  %3446 = fadd fast float %3443, 0x3FE2E147A0000000
  %3447 = fadd fast float %3444, 0x3FE2E147A0000000
  %3448 = fmul fast float %3445, %3428
  %3449 = fmul fast float %3446, %3429
  %3450 = fmul fast float %3447, %3430
  %3451 = fadd fast float %3448, 0x3FC1EB8520000000
  %3452 = fadd fast float %3449, 0x3FC1EB8520000000
  %3453 = fadd fast float %3450, 0x3FC1EB8520000000
  %3454 = fdiv fast float %3439, %3451
  %3455 = fdiv fast float %3440, %3452
  %3456 = fdiv fast float %3441, %3453
  br label %3457

; <label>:3457                                    ; preds = %3432, %3421
  %3458 = phi float [ %3454, %3432 ], [ %3428, %3421 ]
  %3459 = phi float [ %3455, %3432 ], [ %3429, %3421 ]
  %3460 = phi float [ %3456, %3432 ], [ %3430, %3421 ]
  %3461 = call float @dx.op.unary.f32(i32 7, float %3458)  ; Saturate(value)
  %3462 = call float @dx.op.unary.f32(i32 7, float %3459)  ; Saturate(value)
  %3463 = call float @dx.op.unary.f32(i32 7, float %3460)  ; Saturate(value)
  %3464 = call float @dx.op.dot3.f32(i32 55, float %3461, float %3462, float %3463, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3465 = fsub fast float %3461, %3464
  %3466 = fsub fast float %3462, %3464
  %3467 = fsub fast float %3463, %3464
  %3468 = fmul fast float %3465, %9
  %3469 = fmul fast float %3466, %9
  %3470 = fmul fast float %3467, %9
  %3471 = fadd fast float %3468, %3464
  %3472 = fadd fast float %3469, %3464
  %3473 = fadd fast float %3470, %3464
  %3474 = call float @dx.op.unary.f32(i32 7, float %3471)  ; Saturate(value)
  %3475 = call float @dx.op.unary.f32(i32 7, float %3472)  ; Saturate(value)
  %3476 = call float @dx.op.unary.f32(i32 7, float %3473)  ; Saturate(value)
  %3477 = fadd fast float %3474, 0xBFC70A3D80000000
  %3478 = fadd fast float %3475, 0xBFC70A3D80000000
  %3479 = fadd fast float %3476, 0xBFC70A3D80000000
  %3480 = fmul fast float %3477, %8
  %3481 = fmul fast float %3478, %8
  %3482 = fmul fast float %3479, %8
  %3483 = fadd fast float %3480, 0x3FC70A3D80000000
  %3484 = fadd fast float %3481, 0x3FC70A3D80000000
  %3485 = fadd fast float %3482, 0x3FC70A3D80000000
  %3486 = call float @dx.op.unary.f32(i32 7, float %3483)  ; Saturate(value)
  %3487 = call float @dx.op.unary.f32(i32 7, float %3484)  ; Saturate(value)
  %3488 = call float @dx.op.unary.f32(i32 7, float %3485)  ; Saturate(value)
  br label %3489

; <label>:3489                                    ; preds = %3457, %3387
  %3490 = phi float [ %3418, %3387 ], [ %3486, %3457 ]
  %3491 = phi float [ %3419, %3387 ], [ %3487, %3457 ]
  %3492 = phi float [ %3420, %3387 ], [ %3488, %3457 ]
  %3493 = fsub fast float %3490, %3214
  %3494 = fsub fast float %3491, %3215
  %3495 = fsub fast float %3492, %3216
  %3496 = fmul fast float %3493, %3374
  %3497 = fmul fast float %3494, %3374
  %3498 = fmul fast float %3495, %3374
  %3499 = fadd fast float %3496, %3214
  %3500 = fadd fast float %3497, %3215
  %3501 = fadd fast float %3498, %3216
  br label %3502

; <label>:3502                                    ; preds = %3489, %3361
  %3503 = phi float [ %3499, %3489 ], [ %3214, %3361 ]
  %3504 = phi float [ %3500, %3489 ], [ %3215, %3361 ]
  %3505 = phi float [ %3501, %3489 ], [ %3216, %3361 ]
  %3506 = add i32 %39, -1
  %3507 = call i32 @dx.op.binary.i32(i32 37, i32 %3506, i32 0)  ; IMax(a,b)
  %3508 = call i32 @dx.op.binary.i32(i32 37, i32 %36, i32 0)  ; IMax(a,b)
  %3509 = call i32 @dx.op.binary.i32(i32 38, i32 %3507, i32 %31)  ; IMin(a,b)
  %3510 = call i32 @dx.op.binary.i32(i32 38, i32 %3508, i32 %32)  ; IMin(a,b)
  %3511 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3509, i32 %3510, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3512 = extractvalue %dx.types.ResRet.f32 %3511, 0
  %3513 = fsub fast float %3512, %56
  %3514 = call float @dx.op.unary.f32(i32 6, float %3513)  ; FAbs(value)
  %3515 = fdiv fast float %3514, %3228
  %3516 = fsub fast float 1.000000e+00, %3515
  %3517 = call float @dx.op.unary.f32(i32 7, float %3516)  ; Saturate(value)
  %3518 = fcmp fast ugt float %3517, 0.000000e+00
  br i1 %3518, label %3519, label %3645

; <label>:3519                                    ; preds = %3502
  %3520 = call i32 @dx.op.binary.i32(i32 37, i32 %3509, i32 0)  ; IMax(a,b)
  %3521 = call i32 @dx.op.binary.i32(i32 37, i32 %3510, i32 0)  ; IMax(a,b)
  %3522 = call i32 @dx.op.binary.i32(i32 38, i32 %3520, i32 %31)  ; IMin(a,b)
  %3523 = call i32 @dx.op.binary.i32(i32 38, i32 %3521, i32 %32)  ; IMin(a,b)
  %3524 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3522, i32 %3523, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3525 = extractvalue %dx.types.ResRet.f32 %3524, 0
  %3526 = extractvalue %dx.types.ResRet.f32 %3524, 1
  %3527 = extractvalue %dx.types.ResRet.f32 %3524, 2
  %3528 = extractvalue %dx.types.ResRet.f32 %3524, 3
  %3529 = fcmp fast olt float %3528, 0.000000e+00
  br i1 %3529, label %3530, label %3564

; <label>:3530                                    ; preds = %3519
  %3531 = fcmp fast ogt float %3525, 0x3FA4B5DCC0000000
  %3532 = fcmp fast ogt float %3526, 0x3FA4B5DCC0000000
  %3533 = fcmp fast ogt float %3527, 0x3FA4B5DCC0000000
  %3534 = select i1 %3531, float 0.000000e+00, float 1.000000e+00
  %3535 = select i1 %3532, float 0.000000e+00, float 1.000000e+00
  %3536 = select i1 %3533, float 0.000000e+00, float 1.000000e+00
  %3537 = fmul fast float %3525, 0x3FB3D07220000000
  %3538 = fmul fast float %3526, 0x3FB3D07220000000
  %3539 = fmul fast float %3527, 0x3FB3D07220000000
  %3540 = fadd fast float %3525, 0x3FAC28F5C0000000
  %3541 = fadd fast float %3526, 0x3FAC28F5C0000000
  %3542 = fadd fast float %3527, 0x3FAC28F5C0000000
  %3543 = fmul fast float %3540, 0x3FEE54EDE0000000
  %3544 = fmul fast float %3541, 0x3FEE54EDE0000000
  %3545 = fmul fast float %3542, 0x3FEE54EDE0000000
  %3546 = call float @dx.op.unary.f32(i32 23, float %3543)  ; Log(value)
  %3547 = call float @dx.op.unary.f32(i32 23, float %3544)  ; Log(value)
  %3548 = call float @dx.op.unary.f32(i32 23, float %3545)  ; Log(value)
  %3549 = fmul fast float %3546, 0x4003333340000000
  %3550 = fmul fast float %3547, 0x4003333340000000
  %3551 = fmul fast float %3548, 0x4003333340000000
  %3552 = call float @dx.op.unary.f32(i32 21, float %3549)  ; Exp(value)
  %3553 = call float @dx.op.unary.f32(i32 21, float %3550)  ; Exp(value)
  %3554 = call float @dx.op.unary.f32(i32 21, float %3551)  ; Exp(value)
  %3555 = fsub fast float %3537, %3552
  %3556 = fsub fast float %3538, %3553
  %3557 = fsub fast float %3539, %3554
  %3558 = fmul fast float %3555, %3534
  %3559 = fmul fast float %3556, %3535
  %3560 = fmul fast float %3557, %3536
  %3561 = fadd fast float %3558, %3552
  %3562 = fadd fast float %3559, %3553
  %3563 = fadd fast float %3560, %3554
  br label %3632

; <label>:3564                                    ; preds = %3519
  %3565 = fadd fast float %6, 1.000000e+00
  %3566 = fadd fast float %7, 1.000000e+00
  %3567 = fsub fast float 1.000000e+00, %6
  %3568 = fmul fast float %10, %3565
  %3569 = fmul fast float %10, %3566
  %3570 = fmul fast float %10, %3567
  %3571 = fmul fast float %3568, %3525
  %3572 = fmul fast float %3569, %3526
  %3573 = fmul fast float %3570, %3527
  %3574 = fcmp fast ult float %11, 5.000000e-01
  br i1 %3574, label %3600, label %3575

; <label>:3575                                    ; preds = %3564
  %3576 = fmul fast float %3571, 0x4004147AE0000000
  %3577 = fmul fast float %3572, 0x4004147AE0000000
  %3578 = fmul fast float %3573, 0x4004147AE0000000
  %3579 = fadd fast float %3576, 0x3F9EB851E0000000
  %3580 = fadd fast float %3577, 0x3F9EB851E0000000
  %3581 = fadd fast float %3578, 0x3F9EB851E0000000
  %3582 = fmul fast float %3579, %3571
  %3583 = fmul fast float %3580, %3572
  %3584 = fmul fast float %3581, %3573
  %3585 = fmul fast float %3571, 0x400370A3E0000000
  %3586 = fmul fast float %3572, 0x400370A3E0000000
  %3587 = fmul fast float %3573, 0x400370A3E0000000
  %3588 = fadd fast float %3585, 0x3FE2E147A0000000
  %3589 = fadd fast float %3586, 0x3FE2E147A0000000
  %3590 = fadd fast float %3587, 0x3FE2E147A0000000
  %3591 = fmul fast float %3588, %3571
  %3592 = fmul fast float %3589, %3572
  %3593 = fmul fast float %3590, %3573
  %3594 = fadd fast float %3591, 0x3FC1EB8520000000
  %3595 = fadd fast float %3592, 0x3FC1EB8520000000
  %3596 = fadd fast float %3593, 0x3FC1EB8520000000
  %3597 = fdiv fast float %3582, %3594
  %3598 = fdiv fast float %3583, %3595
  %3599 = fdiv fast float %3584, %3596
  br label %3600

; <label>:3600                                    ; preds = %3575, %3564
  %3601 = phi float [ %3597, %3575 ], [ %3571, %3564 ]
  %3602 = phi float [ %3598, %3575 ], [ %3572, %3564 ]
  %3603 = phi float [ %3599, %3575 ], [ %3573, %3564 ]
  %3604 = call float @dx.op.unary.f32(i32 7, float %3601)  ; Saturate(value)
  %3605 = call float @dx.op.unary.f32(i32 7, float %3602)  ; Saturate(value)
  %3606 = call float @dx.op.unary.f32(i32 7, float %3603)  ; Saturate(value)
  %3607 = call float @dx.op.dot3.f32(i32 55, float %3604, float %3605, float %3606, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3608 = fsub fast float %3604, %3607
  %3609 = fsub fast float %3605, %3607
  %3610 = fsub fast float %3606, %3607
  %3611 = fmul fast float %3608, %9
  %3612 = fmul fast float %3609, %9
  %3613 = fmul fast float %3610, %9
  %3614 = fadd fast float %3611, %3607
  %3615 = fadd fast float %3612, %3607
  %3616 = fadd fast float %3613, %3607
  %3617 = call float @dx.op.unary.f32(i32 7, float %3614)  ; Saturate(value)
  %3618 = call float @dx.op.unary.f32(i32 7, float %3615)  ; Saturate(value)
  %3619 = call float @dx.op.unary.f32(i32 7, float %3616)  ; Saturate(value)
  %3620 = fadd fast float %3617, 0xBFC70A3D80000000
  %3621 = fadd fast float %3618, 0xBFC70A3D80000000
  %3622 = fadd fast float %3619, 0xBFC70A3D80000000
  %3623 = fmul fast float %3620, %8
  %3624 = fmul fast float %3621, %8
  %3625 = fmul fast float %3622, %8
  %3626 = fadd fast float %3623, 0x3FC70A3D80000000
  %3627 = fadd fast float %3624, 0x3FC70A3D80000000
  %3628 = fadd fast float %3625, 0x3FC70A3D80000000
  %3629 = call float @dx.op.unary.f32(i32 7, float %3626)  ; Saturate(value)
  %3630 = call float @dx.op.unary.f32(i32 7, float %3627)  ; Saturate(value)
  %3631 = call float @dx.op.unary.f32(i32 7, float %3628)  ; Saturate(value)
  br label %3632

; <label>:3632                                    ; preds = %3600, %3530
  %3633 = phi float [ %3561, %3530 ], [ %3629, %3600 ]
  %3634 = phi float [ %3562, %3530 ], [ %3630, %3600 ]
  %3635 = phi float [ %3563, %3530 ], [ %3631, %3600 ]
  %3636 = fsub fast float %3633, %3214
  %3637 = fsub fast float %3634, %3215
  %3638 = fsub fast float %3635, %3216
  %3639 = fmul fast float %3636, %3517
  %3640 = fmul fast float %3637, %3517
  %3641 = fmul fast float %3638, %3517
  %3642 = fadd fast float %3639, %3214
  %3643 = fadd fast float %3640, %3215
  %3644 = fadd fast float %3641, %3216
  br label %3645

; <label>:3645                                    ; preds = %3632, %3502
  %3646 = phi float [ %3642, %3632 ], [ %3214, %3502 ]
  %3647 = phi float [ %3643, %3632 ], [ %3215, %3502 ]
  %3648 = phi float [ %3644, %3632 ], [ %3216, %3502 ]
  %3649 = add i32 %39, 1
  %3650 = call i32 @dx.op.binary.i32(i32 37, i32 %3649, i32 0)  ; IMax(a,b)
  %3651 = call i32 @dx.op.binary.i32(i32 38, i32 %3650, i32 %31)  ; IMin(a,b)
  %3652 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3651, i32 %3510, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3653 = extractvalue %dx.types.ResRet.f32 %3652, 0
  %3654 = fsub fast float %3653, %56
  %3655 = call float @dx.op.unary.f32(i32 6, float %3654)  ; FAbs(value)
  %3656 = fdiv fast float %3655, %3228
  %3657 = fsub fast float 1.000000e+00, %3656
  %3658 = call float @dx.op.unary.f32(i32 7, float %3657)  ; Saturate(value)
  %3659 = fcmp fast ugt float %3658, 0.000000e+00
  br i1 %3659, label %3660, label %3786

; <label>:3660                                    ; preds = %3645
  %3661 = call i32 @dx.op.binary.i32(i32 37, i32 %3651, i32 0)  ; IMax(a,b)
  %3662 = call i32 @dx.op.binary.i32(i32 37, i32 %3510, i32 0)  ; IMax(a,b)
  %3663 = call i32 @dx.op.binary.i32(i32 38, i32 %3661, i32 %31)  ; IMin(a,b)
  %3664 = call i32 @dx.op.binary.i32(i32 38, i32 %3662, i32 %32)  ; IMin(a,b)
  %3665 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3663, i32 %3664, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3666 = extractvalue %dx.types.ResRet.f32 %3665, 0
  %3667 = extractvalue %dx.types.ResRet.f32 %3665, 1
  %3668 = extractvalue %dx.types.ResRet.f32 %3665, 2
  %3669 = extractvalue %dx.types.ResRet.f32 %3665, 3
  %3670 = fcmp fast olt float %3669, 0.000000e+00
  br i1 %3670, label %3671, label %3705

; <label>:3671                                    ; preds = %3660
  %3672 = fcmp fast ogt float %3666, 0x3FA4B5DCC0000000
  %3673 = fcmp fast ogt float %3667, 0x3FA4B5DCC0000000
  %3674 = fcmp fast ogt float %3668, 0x3FA4B5DCC0000000
  %3675 = select i1 %3672, float 0.000000e+00, float 1.000000e+00
  %3676 = select i1 %3673, float 0.000000e+00, float 1.000000e+00
  %3677 = select i1 %3674, float 0.000000e+00, float 1.000000e+00
  %3678 = fmul fast float %3666, 0x3FB3D07220000000
  %3679 = fmul fast float %3667, 0x3FB3D07220000000
  %3680 = fmul fast float %3668, 0x3FB3D07220000000
  %3681 = fadd fast float %3666, 0x3FAC28F5C0000000
  %3682 = fadd fast float %3667, 0x3FAC28F5C0000000
  %3683 = fadd fast float %3668, 0x3FAC28F5C0000000
  %3684 = fmul fast float %3681, 0x3FEE54EDE0000000
  %3685 = fmul fast float %3682, 0x3FEE54EDE0000000
  %3686 = fmul fast float %3683, 0x3FEE54EDE0000000
  %3687 = call float @dx.op.unary.f32(i32 23, float %3684)  ; Log(value)
  %3688 = call float @dx.op.unary.f32(i32 23, float %3685)  ; Log(value)
  %3689 = call float @dx.op.unary.f32(i32 23, float %3686)  ; Log(value)
  %3690 = fmul fast float %3687, 0x4003333340000000
  %3691 = fmul fast float %3688, 0x4003333340000000
  %3692 = fmul fast float %3689, 0x4003333340000000
  %3693 = call float @dx.op.unary.f32(i32 21, float %3690)  ; Exp(value)
  %3694 = call float @dx.op.unary.f32(i32 21, float %3691)  ; Exp(value)
  %3695 = call float @dx.op.unary.f32(i32 21, float %3692)  ; Exp(value)
  %3696 = fsub fast float %3678, %3693
  %3697 = fsub fast float %3679, %3694
  %3698 = fsub fast float %3680, %3695
  %3699 = fmul fast float %3696, %3675
  %3700 = fmul fast float %3697, %3676
  %3701 = fmul fast float %3698, %3677
  %3702 = fadd fast float %3699, %3693
  %3703 = fadd fast float %3700, %3694
  %3704 = fadd fast float %3701, %3695
  br label %3773

; <label>:3705                                    ; preds = %3660
  %3706 = fadd fast float %6, 1.000000e+00
  %3707 = fadd fast float %7, 1.000000e+00
  %3708 = fsub fast float 1.000000e+00, %6
  %3709 = fmul fast float %10, %3706
  %3710 = fmul fast float %10, %3707
  %3711 = fmul fast float %10, %3708
  %3712 = fmul fast float %3709, %3666
  %3713 = fmul fast float %3710, %3667
  %3714 = fmul fast float %3711, %3668
  %3715 = fcmp fast ult float %11, 5.000000e-01
  br i1 %3715, label %3741, label %3716

; <label>:3716                                    ; preds = %3705
  %3717 = fmul fast float %3712, 0x4004147AE0000000
  %3718 = fmul fast float %3713, 0x4004147AE0000000
  %3719 = fmul fast float %3714, 0x4004147AE0000000
  %3720 = fadd fast float %3717, 0x3F9EB851E0000000
  %3721 = fadd fast float %3718, 0x3F9EB851E0000000
  %3722 = fadd fast float %3719, 0x3F9EB851E0000000
  %3723 = fmul fast float %3720, %3712
  %3724 = fmul fast float %3721, %3713
  %3725 = fmul fast float %3722, %3714
  %3726 = fmul fast float %3712, 0x400370A3E0000000
  %3727 = fmul fast float %3713, 0x400370A3E0000000
  %3728 = fmul fast float %3714, 0x400370A3E0000000
  %3729 = fadd fast float %3726, 0x3FE2E147A0000000
  %3730 = fadd fast float %3727, 0x3FE2E147A0000000
  %3731 = fadd fast float %3728, 0x3FE2E147A0000000
  %3732 = fmul fast float %3729, %3712
  %3733 = fmul fast float %3730, %3713
  %3734 = fmul fast float %3731, %3714
  %3735 = fadd fast float %3732, 0x3FC1EB8520000000
  %3736 = fadd fast float %3733, 0x3FC1EB8520000000
  %3737 = fadd fast float %3734, 0x3FC1EB8520000000
  %3738 = fdiv fast float %3723, %3735
  %3739 = fdiv fast float %3724, %3736
  %3740 = fdiv fast float %3725, %3737
  br label %3741

; <label>:3741                                    ; preds = %3716, %3705
  %3742 = phi float [ %3738, %3716 ], [ %3712, %3705 ]
  %3743 = phi float [ %3739, %3716 ], [ %3713, %3705 ]
  %3744 = phi float [ %3740, %3716 ], [ %3714, %3705 ]
  %3745 = call float @dx.op.unary.f32(i32 7, float %3742)  ; Saturate(value)
  %3746 = call float @dx.op.unary.f32(i32 7, float %3743)  ; Saturate(value)
  %3747 = call float @dx.op.unary.f32(i32 7, float %3744)  ; Saturate(value)
  %3748 = call float @dx.op.dot3.f32(i32 55, float %3745, float %3746, float %3747, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3749 = fsub fast float %3745, %3748
  %3750 = fsub fast float %3746, %3748
  %3751 = fsub fast float %3747, %3748
  %3752 = fmul fast float %3749, %9
  %3753 = fmul fast float %3750, %9
  %3754 = fmul fast float %3751, %9
  %3755 = fadd fast float %3752, %3748
  %3756 = fadd fast float %3753, %3748
  %3757 = fadd fast float %3754, %3748
  %3758 = call float @dx.op.unary.f32(i32 7, float %3755)  ; Saturate(value)
  %3759 = call float @dx.op.unary.f32(i32 7, float %3756)  ; Saturate(value)
  %3760 = call float @dx.op.unary.f32(i32 7, float %3757)  ; Saturate(value)
  %3761 = fadd fast float %3758, 0xBFC70A3D80000000
  %3762 = fadd fast float %3759, 0xBFC70A3D80000000
  %3763 = fadd fast float %3760, 0xBFC70A3D80000000
  %3764 = fmul fast float %3761, %8
  %3765 = fmul fast float %3762, %8
  %3766 = fmul fast float %3763, %8
  %3767 = fadd fast float %3764, 0x3FC70A3D80000000
  %3768 = fadd fast float %3765, 0x3FC70A3D80000000
  %3769 = fadd fast float %3766, 0x3FC70A3D80000000
  %3770 = call float @dx.op.unary.f32(i32 7, float %3767)  ; Saturate(value)
  %3771 = call float @dx.op.unary.f32(i32 7, float %3768)  ; Saturate(value)
  %3772 = call float @dx.op.unary.f32(i32 7, float %3769)  ; Saturate(value)
  br label %3773

; <label>:3773                                    ; preds = %3741, %3671
  %3774 = phi float [ %3702, %3671 ], [ %3770, %3741 ]
  %3775 = phi float [ %3703, %3671 ], [ %3771, %3741 ]
  %3776 = phi float [ %3704, %3671 ], [ %3772, %3741 ]
  %3777 = fsub fast float %3774, %3214
  %3778 = fsub fast float %3775, %3215
  %3779 = fsub fast float %3776, %3216
  %3780 = fmul fast float %3777, %3658
  %3781 = fmul fast float %3778, %3658
  %3782 = fmul fast float %3779, %3658
  %3783 = fadd fast float %3780, %3214
  %3784 = fadd fast float %3781, %3215
  %3785 = fadd fast float %3782, %3216
  br label %3786

; <label>:3786                                    ; preds = %3773, %3645
  %3787 = phi float [ %3783, %3773 ], [ %3214, %3645 ]
  %3788 = phi float [ %3784, %3773 ], [ %3215, %3645 ]
  %3789 = phi float [ %3785, %3773 ], [ %3216, %3645 ]
  %3790 = call float @dx.op.binary.f32(i32 36, float %3646, float %3787)  ; FMin(a,b)
  %3791 = call float @dx.op.binary.f32(i32 36, float %3647, float %3788)  ; FMin(a,b)
  %3792 = call float @dx.op.binary.f32(i32 36, float %3648, float %3789)  ; FMin(a,b)
  %3793 = call float @dx.op.binary.f32(i32 36, float %3362, float %3503)  ; FMin(a,b)
  %3794 = call float @dx.op.binary.f32(i32 36, float %3363, float %3504)  ; FMin(a,b)
  %3795 = call float @dx.op.binary.f32(i32 36, float %3364, float %3505)  ; FMin(a,b)
  %3796 = call float @dx.op.binary.f32(i32 36, float %3793, float %3790)  ; FMin(a,b)
  %3797 = call float @dx.op.binary.f32(i32 36, float %3794, float %3791)  ; FMin(a,b)
  %3798 = call float @dx.op.binary.f32(i32 36, float %3795, float %3792)  ; FMin(a,b)
  %3799 = call float @dx.op.binary.f32(i32 36, float %3214, float %3796)  ; FMin(a,b)
  %3800 = call float @dx.op.binary.f32(i32 36, float %3215, float %3797)  ; FMin(a,b)
  %3801 = call float @dx.op.binary.f32(i32 36, float %3216, float %3798)  ; FMin(a,b)
  %3802 = call float @dx.op.binary.f32(i32 35, float %3646, float %3787)  ; FMax(a,b)
  %3803 = call float @dx.op.binary.f32(i32 35, float %3647, float %3788)  ; FMax(a,b)
  %3804 = call float @dx.op.binary.f32(i32 35, float %3648, float %3789)  ; FMax(a,b)
  %3805 = call float @dx.op.binary.f32(i32 35, float %3362, float %3503)  ; FMax(a,b)
  %3806 = call float @dx.op.binary.f32(i32 35, float %3363, float %3504)  ; FMax(a,b)
  %3807 = call float @dx.op.binary.f32(i32 35, float %3364, float %3505)  ; FMax(a,b)
  %3808 = call float @dx.op.binary.f32(i32 35, float %3805, float %3802)  ; FMax(a,b)
  %3809 = call float @dx.op.binary.f32(i32 35, float %3806, float %3803)  ; FMax(a,b)
  %3810 = call float @dx.op.binary.f32(i32 35, float %3807, float %3804)  ; FMax(a,b)
  %3811 = call float @dx.op.binary.f32(i32 35, float %3214, float %3808)  ; FMax(a,b)
  %3812 = call float @dx.op.binary.f32(i32 35, float %3215, float %3809)  ; FMax(a,b)
  %3813 = call float @dx.op.binary.f32(i32 35, float %3216, float %3810)  ; FMax(a,b)
  %3814 = fsub fast float %3811, %3799
  %3815 = fsub fast float %3812, %3800
  %3816 = fsub fast float %3813, %3801
  %3817 = call float @dx.op.unary.f32(i32 6, float %3814)  ; FAbs(value)
  %3818 = call float @dx.op.unary.f32(i32 6, float %3815)  ; FAbs(value)
  %3819 = call float @dx.op.unary.f32(i32 6, float %3816)  ; FAbs(value)
  %3820 = call float @dx.op.binary.f32(i32 35, float %3818, float %3819)  ; FMax(a,b)
  %3821 = call float @dx.op.binary.f32(i32 35, float %3817, float %3820)  ; FMax(a,b)
  %3822 = call float @dx.op.binary.f32(i32 35, float %3812, float %3813)  ; FMax(a,b)
  %3823 = call float @dx.op.binary.f32(i32 35, float %3811, float %3822)  ; FMax(a,b)
  %3824 = fmul fast float %3823, 1.250000e-01
  %3825 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %3824)  ; FMax(a,b)
  %3826 = fcmp fast ogt float %3821, %3825
  br i1 %3826, label %3827, label %3889

; <label>:3827                                    ; preds = %3786
  %3828 = fsub fast float %3362, %3503
  %3829 = fsub fast float %3363, %3504
  %3830 = fsub fast float %3364, %3505
  %3831 = call float @dx.op.unary.f32(i32 6, float %3828)  ; FAbs(value)
  %3832 = call float @dx.op.unary.f32(i32 6, float %3829)  ; FAbs(value)
  %3833 = call float @dx.op.unary.f32(i32 6, float %3830)  ; FAbs(value)
  %3834 = call float @dx.op.binary.f32(i32 35, float %3832, float %3833)  ; FMax(a,b)
  %3835 = call float @dx.op.binary.f32(i32 35, float %3831, float %3834)  ; FMax(a,b)
  %3836 = fsub fast float %3646, %3787
  %3837 = fsub fast float %3647, %3788
  %3838 = fsub fast float %3648, %3789
  %3839 = call float @dx.op.unary.f32(i32 6, float %3836)  ; FAbs(value)
  %3840 = call float @dx.op.unary.f32(i32 6, float %3837)  ; FAbs(value)
  %3841 = call float @dx.op.unary.f32(i32 6, float %3838)  ; FAbs(value)
  %3842 = call float @dx.op.binary.f32(i32 35, float %3840, float %3841)  ; FMax(a,b)
  %3843 = call float @dx.op.binary.f32(i32 35, float %3839, float %3842)  ; FMax(a,b)
  %3844 = fcmp fast olt float %3835, %3843
  %3845 = select i1 %3844, float %3362, float %3646
  %3846 = select i1 %3844, float %3363, float %3647
  %3847 = select i1 %3844, float %3364, float %3648
  %3848 = select i1 %3844, float %3503, float %3787
  %3849 = select i1 %3844, float %3504, float %3788
  %3850 = select i1 %3844, float %3505, float %3789
  %3851 = fsub fast float %3214, %3848
  %3852 = fsub fast float %3215, %3849
  %3853 = fsub fast float %3216, %3850
  %3854 = fsub fast float %3214, %3845
  %3855 = fsub fast float %3215, %3846
  %3856 = fsub fast float %3216, %3847
  %3857 = call float @dx.op.dot3.f32(i32 55, float %3854, float %3855, float %3856, float %3851, float %3852, float %3853)  ; Dot3(ax,ay,az,bx,by,bz)
  %3858 = fcmp fast ogt float %3857, 0.000000e+00
  br i1 %3858, label %3859, label %3870

; <label>:3859                                    ; preds = %3827
  %3860 = fsub fast float %3845, %3848
  %3861 = fsub fast float %3846, %3849
  %3862 = fsub fast float %3847, %3850
  %3863 = call float @dx.op.unary.f32(i32 6, float %3860)  ; FAbs(value)
  %3864 = call float @dx.op.unary.f32(i32 6, float %3861)  ; FAbs(value)
  %3865 = call float @dx.op.unary.f32(i32 6, float %3862)  ; FAbs(value)
  %3866 = call float @dx.op.binary.f32(i32 35, float %3864, float %3865)  ; FMax(a,b)
  %3867 = call float @dx.op.binary.f32(i32 35, float %3863, float %3866)  ; FMax(a,b)
  %3868 = fmul fast float %3821, 2.500000e-01
  %3869 = fcmp fast olt float %3867, %3868
  br label %3870

; <label>:3870                                    ; preds = %3859, %3827
  %3871 = phi i1 [ false, %3827 ], [ %3869, %3859 ]
  %3872 = select i1 %3871, float 5.000000e-01, float 1.000000e+00
  %3873 = fmul fast float %3872, %3
  %3874 = fadd fast float %3845, %3848
  %3875 = fadd fast float %3846, %3849
  %3876 = fadd fast float %3847, %3850
  %3877 = fmul fast float %3874, 5.000000e-01
  %3878 = fmul fast float %3875, 5.000000e-01
  %3879 = fmul fast float %3876, 5.000000e-01
  %3880 = fsub fast float %3877, %3214
  %3881 = fsub fast float %3878, %3215
  %3882 = fsub fast float %3879, %3216
  %3883 = fmul fast float %3873, %3880
  %3884 = fmul fast float %3873, %3881
  %3885 = fmul fast float %3873, %3882
  %3886 = fadd fast float %3883, %3214
  %3887 = fadd fast float %3884, %3215
  %3888 = fadd fast float %3885, %3216
  br label %3889

; <label>:3889                                    ; preds = %3870, %3786, %3185, %3114
  %3890 = phi float [ %3145, %3114 ], [ %3214, %3185 ], [ %3886, %3870 ], [ %3214, %3786 ]
  %3891 = phi float [ %3146, %3114 ], [ %3215, %3185 ], [ %3887, %3870 ], [ %3215, %3786 ]
  %3892 = phi float [ %3147, %3114 ], [ %3216, %3185 ], [ %3888, %3870 ], [ %3216, %3786 ]
  %3893 = phi float [ %3148, %3114 ], [ %3112, %3185 ], [ %3112, %3870 ], [ %3112, %3786 ]
  %3894 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %35, i32 %42, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3895 = extractvalue %dx.types.ResRet.f32 %3894, 0
  %3896 = extractvalue %dx.types.ResRet.f32 %3894, 1
  %3897 = extractvalue %dx.types.ResRet.f32 %3894, 2
  %3898 = extractvalue %dx.types.ResRet.f32 %3894, 3
  %3899 = fcmp fast olt float %3898, 0.000000e+00
  br i1 %3899, label %3900, label %3935

; <label>:3900                                    ; preds = %3889
  %3901 = fcmp fast ogt float %3895, 0x3FA4B5DCC0000000
  %3902 = fcmp fast ogt float %3896, 0x3FA4B5DCC0000000
  %3903 = fcmp fast ogt float %3897, 0x3FA4B5DCC0000000
  %3904 = select i1 %3901, float 0.000000e+00, float 1.000000e+00
  %3905 = select i1 %3902, float 0.000000e+00, float 1.000000e+00
  %3906 = select i1 %3903, float 0.000000e+00, float 1.000000e+00
  %3907 = fmul fast float %3895, 0x3FB3D07220000000
  %3908 = fmul fast float %3896, 0x3FB3D07220000000
  %3909 = fmul fast float %3897, 0x3FB3D07220000000
  %3910 = fadd fast float %3895, 0x3FAC28F5C0000000
  %3911 = fadd fast float %3896, 0x3FAC28F5C0000000
  %3912 = fadd fast float %3897, 0x3FAC28F5C0000000
  %3913 = fmul fast float %3910, 0x3FEE54EDE0000000
  %3914 = fmul fast float %3911, 0x3FEE54EDE0000000
  %3915 = fmul fast float %3912, 0x3FEE54EDE0000000
  %3916 = call float @dx.op.unary.f32(i32 23, float %3913)  ; Log(value)
  %3917 = call float @dx.op.unary.f32(i32 23, float %3914)  ; Log(value)
  %3918 = call float @dx.op.unary.f32(i32 23, float %3915)  ; Log(value)
  %3919 = fmul fast float %3916, 0x4003333340000000
  %3920 = fmul fast float %3917, 0x4003333340000000
  %3921 = fmul fast float %3918, 0x4003333340000000
  %3922 = call float @dx.op.unary.f32(i32 21, float %3919)  ; Exp(value)
  %3923 = call float @dx.op.unary.f32(i32 21, float %3920)  ; Exp(value)
  %3924 = call float @dx.op.unary.f32(i32 21, float %3921)  ; Exp(value)
  %3925 = fsub fast float %3907, %3922
  %3926 = fsub fast float %3908, %3923
  %3927 = fsub fast float %3909, %3924
  %3928 = fmul fast float %3925, %3904
  %3929 = fmul fast float %3926, %3905
  %3930 = fmul fast float %3927, %3906
  %3931 = fadd fast float %3928, %3922
  %3932 = fadd fast float %3929, %3923
  %3933 = fadd fast float %3930, %3924
  %3934 = fsub fast float -1.000000e+00, %3898
  br label %4675

; <label>:3935                                    ; preds = %3889
  %3936 = fadd fast float %6, 1.000000e+00
  %3937 = fadd fast float %7, 1.000000e+00
  %3938 = fsub fast float 1.000000e+00, %6
  %3939 = fmul fast float %10, %3936
  %3940 = fmul fast float %10, %3937
  %3941 = fmul fast float %10, %3938
  %3942 = fmul fast float %3939, %3895
  %3943 = fmul fast float %3940, %3896
  %3944 = fmul fast float %3941, %3897
  %3945 = fcmp fast ult float %11, 5.000000e-01
  br i1 %3945, label %3971, label %3946

; <label>:3946                                    ; preds = %3935
  %3947 = fmul fast float %3942, 0x4004147AE0000000
  %3948 = fmul fast float %3943, 0x4004147AE0000000
  %3949 = fmul fast float %3944, 0x4004147AE0000000
  %3950 = fadd fast float %3947, 0x3F9EB851E0000000
  %3951 = fadd fast float %3948, 0x3F9EB851E0000000
  %3952 = fadd fast float %3949, 0x3F9EB851E0000000
  %3953 = fmul fast float %3950, %3942
  %3954 = fmul fast float %3951, %3943
  %3955 = fmul fast float %3952, %3944
  %3956 = fmul fast float %3942, 0x400370A3E0000000
  %3957 = fmul fast float %3943, 0x400370A3E0000000
  %3958 = fmul fast float %3944, 0x400370A3E0000000
  %3959 = fadd fast float %3956, 0x3FE2E147A0000000
  %3960 = fadd fast float %3957, 0x3FE2E147A0000000
  %3961 = fadd fast float %3958, 0x3FE2E147A0000000
  %3962 = fmul fast float %3959, %3942
  %3963 = fmul fast float %3960, %3943
  %3964 = fmul fast float %3961, %3944
  %3965 = fadd fast float %3962, 0x3FC1EB8520000000
  %3966 = fadd fast float %3963, 0x3FC1EB8520000000
  %3967 = fadd fast float %3964, 0x3FC1EB8520000000
  %3968 = fdiv fast float %3953, %3965
  %3969 = fdiv fast float %3954, %3966
  %3970 = fdiv fast float %3955, %3967
  br label %3971

; <label>:3971                                    ; preds = %3946, %3935
  %3972 = phi float [ %3968, %3946 ], [ %3942, %3935 ]
  %3973 = phi float [ %3969, %3946 ], [ %3943, %3935 ]
  %3974 = phi float [ %3970, %3946 ], [ %3944, %3935 ]
  %3975 = call float @dx.op.unary.f32(i32 7, float %3972)  ; Saturate(value)
  %3976 = call float @dx.op.unary.f32(i32 7, float %3973)  ; Saturate(value)
  %3977 = call float @dx.op.unary.f32(i32 7, float %3974)  ; Saturate(value)
  %3978 = call float @dx.op.dot3.f32(i32 55, float %3975, float %3976, float %3977, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3979 = fsub fast float %3975, %3978
  %3980 = fsub fast float %3976, %3978
  %3981 = fsub fast float %3977, %3978
  %3982 = fmul fast float %3979, %9
  %3983 = fmul fast float %3980, %9
  %3984 = fmul fast float %3981, %9
  %3985 = fadd fast float %3982, %3978
  %3986 = fadd fast float %3983, %3978
  %3987 = fadd fast float %3984, %3978
  %3988 = call float @dx.op.unary.f32(i32 7, float %3985)  ; Saturate(value)
  %3989 = call float @dx.op.unary.f32(i32 7, float %3986)  ; Saturate(value)
  %3990 = call float @dx.op.unary.f32(i32 7, float %3987)  ; Saturate(value)
  %3991 = fadd fast float %3988, 0xBFC70A3D80000000
  %3992 = fadd fast float %3989, 0xBFC70A3D80000000
  %3993 = fadd fast float %3990, 0xBFC70A3D80000000
  %3994 = fmul fast float %3991, %8
  %3995 = fmul fast float %3992, %8
  %3996 = fmul fast float %3993, %8
  %3997 = fadd fast float %3994, 0x3FC70A3D80000000
  %3998 = fadd fast float %3995, 0x3FC70A3D80000000
  %3999 = fadd fast float %3996, 0x3FC70A3D80000000
  %4000 = call float @dx.op.unary.f32(i32 7, float %3997)  ; Saturate(value)
  %4001 = call float @dx.op.unary.f32(i32 7, float %3998)  ; Saturate(value)
  %4002 = call float @dx.op.unary.f32(i32 7, float %3999)  ; Saturate(value)
  %4003 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %4003, label %4004, label %4675

; <label>:4004                                    ; preds = %3971
  %4005 = add i32 %42, -1
  %4006 = call i32 @dx.op.binary.i32(i32 37, i32 %35, i32 0)  ; IMax(a,b)
  %4007 = call i32 @dx.op.binary.i32(i32 37, i32 %4005, i32 0)  ; IMax(a,b)
  %4008 = call i32 @dx.op.binary.i32(i32 38, i32 %4006, i32 %31)  ; IMin(a,b)
  %4009 = call i32 @dx.op.binary.i32(i32 38, i32 %4007, i32 %32)  ; IMin(a,b)
  %4010 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4008, i32 %4009, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4011 = extractvalue %dx.types.ResRet.f32 %4010, 0
  %4012 = fsub fast float 1.000000e+00, %58
  %4013 = fmul fast float %4012, 0x3FA99999A0000000
  %4014 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %4013)  ; FMax(a,b)
  %4015 = fsub fast float %4011, %58
  %4016 = call float @dx.op.unary.f32(i32 6, float %4015)  ; FAbs(value)
  %4017 = fdiv fast float %4016, %4014
  %4018 = fsub fast float 1.000000e+00, %4017
  %4019 = call float @dx.op.unary.f32(i32 7, float %4018)  ; Saturate(value)
  %4020 = fcmp fast ugt float %4019, 0.000000e+00
  br i1 %4020, label %4021, label %4147

; <label>:4021                                    ; preds = %4004
  %4022 = call i32 @dx.op.binary.i32(i32 37, i32 %4008, i32 0)  ; IMax(a,b)
  %4023 = call i32 @dx.op.binary.i32(i32 37, i32 %4009, i32 0)  ; IMax(a,b)
  %4024 = call i32 @dx.op.binary.i32(i32 38, i32 %4022, i32 %31)  ; IMin(a,b)
  %4025 = call i32 @dx.op.binary.i32(i32 38, i32 %4023, i32 %32)  ; IMin(a,b)
  %4026 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4024, i32 %4025, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4027 = extractvalue %dx.types.ResRet.f32 %4026, 0
  %4028 = extractvalue %dx.types.ResRet.f32 %4026, 1
  %4029 = extractvalue %dx.types.ResRet.f32 %4026, 2
  %4030 = extractvalue %dx.types.ResRet.f32 %4026, 3
  %4031 = fcmp fast olt float %4030, 0.000000e+00
  br i1 %4031, label %4032, label %4066

; <label>:4032                                    ; preds = %4021
  %4033 = fcmp fast ogt float %4027, 0x3FA4B5DCC0000000
  %4034 = fcmp fast ogt float %4028, 0x3FA4B5DCC0000000
  %4035 = fcmp fast ogt float %4029, 0x3FA4B5DCC0000000
  %4036 = select i1 %4033, float 0.000000e+00, float 1.000000e+00
  %4037 = select i1 %4034, float 0.000000e+00, float 1.000000e+00
  %4038 = select i1 %4035, float 0.000000e+00, float 1.000000e+00
  %4039 = fmul fast float %4027, 0x3FB3D07220000000
  %4040 = fmul fast float %4028, 0x3FB3D07220000000
  %4041 = fmul fast float %4029, 0x3FB3D07220000000
  %4042 = fadd fast float %4027, 0x3FAC28F5C0000000
  %4043 = fadd fast float %4028, 0x3FAC28F5C0000000
  %4044 = fadd fast float %4029, 0x3FAC28F5C0000000
  %4045 = fmul fast float %4042, 0x3FEE54EDE0000000
  %4046 = fmul fast float %4043, 0x3FEE54EDE0000000
  %4047 = fmul fast float %4044, 0x3FEE54EDE0000000
  %4048 = call float @dx.op.unary.f32(i32 23, float %4045)  ; Log(value)
  %4049 = call float @dx.op.unary.f32(i32 23, float %4046)  ; Log(value)
  %4050 = call float @dx.op.unary.f32(i32 23, float %4047)  ; Log(value)
  %4051 = fmul fast float %4048, 0x4003333340000000
  %4052 = fmul fast float %4049, 0x4003333340000000
  %4053 = fmul fast float %4050, 0x4003333340000000
  %4054 = call float @dx.op.unary.f32(i32 21, float %4051)  ; Exp(value)
  %4055 = call float @dx.op.unary.f32(i32 21, float %4052)  ; Exp(value)
  %4056 = call float @dx.op.unary.f32(i32 21, float %4053)  ; Exp(value)
  %4057 = fsub fast float %4039, %4054
  %4058 = fsub fast float %4040, %4055
  %4059 = fsub fast float %4041, %4056
  %4060 = fmul fast float %4057, %4036
  %4061 = fmul fast float %4058, %4037
  %4062 = fmul fast float %4059, %4038
  %4063 = fadd fast float %4060, %4054
  %4064 = fadd fast float %4061, %4055
  %4065 = fadd fast float %4062, %4056
  br label %4134

; <label>:4066                                    ; preds = %4021
  %4067 = fadd fast float %6, 1.000000e+00
  %4068 = fadd fast float %7, 1.000000e+00
  %4069 = fsub fast float 1.000000e+00, %6
  %4070 = fmul fast float %10, %4067
  %4071 = fmul fast float %10, %4068
  %4072 = fmul fast float %10, %4069
  %4073 = fmul fast float %4070, %4027
  %4074 = fmul fast float %4071, %4028
  %4075 = fmul fast float %4072, %4029
  %4076 = fcmp fast ult float %11, 5.000000e-01
  br i1 %4076, label %4102, label %4077

; <label>:4077                                    ; preds = %4066
  %4078 = fmul fast float %4073, 0x4004147AE0000000
  %4079 = fmul fast float %4074, 0x4004147AE0000000
  %4080 = fmul fast float %4075, 0x4004147AE0000000
  %4081 = fadd fast float %4078, 0x3F9EB851E0000000
  %4082 = fadd fast float %4079, 0x3F9EB851E0000000
  %4083 = fadd fast float %4080, 0x3F9EB851E0000000
  %4084 = fmul fast float %4081, %4073
  %4085 = fmul fast float %4082, %4074
  %4086 = fmul fast float %4083, %4075
  %4087 = fmul fast float %4073, 0x400370A3E0000000
  %4088 = fmul fast float %4074, 0x400370A3E0000000
  %4089 = fmul fast float %4075, 0x400370A3E0000000
  %4090 = fadd fast float %4087, 0x3FE2E147A0000000
  %4091 = fadd fast float %4088, 0x3FE2E147A0000000
  %4092 = fadd fast float %4089, 0x3FE2E147A0000000
  %4093 = fmul fast float %4090, %4073
  %4094 = fmul fast float %4091, %4074
  %4095 = fmul fast float %4092, %4075
  %4096 = fadd fast float %4093, 0x3FC1EB8520000000
  %4097 = fadd fast float %4094, 0x3FC1EB8520000000
  %4098 = fadd fast float %4095, 0x3FC1EB8520000000
  %4099 = fdiv fast float %4084, %4096
  %4100 = fdiv fast float %4085, %4097
  %4101 = fdiv fast float %4086, %4098
  br label %4102

; <label>:4102                                    ; preds = %4077, %4066
  %4103 = phi float [ %4099, %4077 ], [ %4073, %4066 ]
  %4104 = phi float [ %4100, %4077 ], [ %4074, %4066 ]
  %4105 = phi float [ %4101, %4077 ], [ %4075, %4066 ]
  %4106 = call float @dx.op.unary.f32(i32 7, float %4103)  ; Saturate(value)
  %4107 = call float @dx.op.unary.f32(i32 7, float %4104)  ; Saturate(value)
  %4108 = call float @dx.op.unary.f32(i32 7, float %4105)  ; Saturate(value)
  %4109 = call float @dx.op.dot3.f32(i32 55, float %4106, float %4107, float %4108, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4110 = fsub fast float %4106, %4109
  %4111 = fsub fast float %4107, %4109
  %4112 = fsub fast float %4108, %4109
  %4113 = fmul fast float %4110, %9
  %4114 = fmul fast float %4111, %9
  %4115 = fmul fast float %4112, %9
  %4116 = fadd fast float %4113, %4109
  %4117 = fadd fast float %4114, %4109
  %4118 = fadd fast float %4115, %4109
  %4119 = call float @dx.op.unary.f32(i32 7, float %4116)  ; Saturate(value)
  %4120 = call float @dx.op.unary.f32(i32 7, float %4117)  ; Saturate(value)
  %4121 = call float @dx.op.unary.f32(i32 7, float %4118)  ; Saturate(value)
  %4122 = fadd fast float %4119, 0xBFC70A3D80000000
  %4123 = fadd fast float %4120, 0xBFC70A3D80000000
  %4124 = fadd fast float %4121, 0xBFC70A3D80000000
  %4125 = fmul fast float %4122, %8
  %4126 = fmul fast float %4123, %8
  %4127 = fmul fast float %4124, %8
  %4128 = fadd fast float %4125, 0x3FC70A3D80000000
  %4129 = fadd fast float %4126, 0x3FC70A3D80000000
  %4130 = fadd fast float %4127, 0x3FC70A3D80000000
  %4131 = call float @dx.op.unary.f32(i32 7, float %4128)  ; Saturate(value)
  %4132 = call float @dx.op.unary.f32(i32 7, float %4129)  ; Saturate(value)
  %4133 = call float @dx.op.unary.f32(i32 7, float %4130)  ; Saturate(value)
  br label %4134

; <label>:4134                                    ; preds = %4102, %4032
  %4135 = phi float [ %4063, %4032 ], [ %4131, %4102 ]
  %4136 = phi float [ %4064, %4032 ], [ %4132, %4102 ]
  %4137 = phi float [ %4065, %4032 ], [ %4133, %4102 ]
  %4138 = fsub fast float %4135, %4000
  %4139 = fsub fast float %4136, %4001
  %4140 = fsub fast float %4137, %4002
  %4141 = fmul fast float %4138, %4019
  %4142 = fmul fast float %4139, %4019
  %4143 = fmul fast float %4140, %4019
  %4144 = fadd fast float %4141, %4000
  %4145 = fadd fast float %4142, %4001
  %4146 = fadd fast float %4143, %4002
  br label %4147

; <label>:4147                                    ; preds = %4134, %4004
  %4148 = phi float [ %4144, %4134 ], [ %4000, %4004 ]
  %4149 = phi float [ %4145, %4134 ], [ %4001, %4004 ]
  %4150 = phi float [ %4146, %4134 ], [ %4002, %4004 ]
  %4151 = add i32 %42, 1
  %4152 = call i32 @dx.op.binary.i32(i32 37, i32 %4151, i32 0)  ; IMax(a,b)
  %4153 = call i32 @dx.op.binary.i32(i32 38, i32 %4152, i32 %32)  ; IMin(a,b)
  %4154 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4008, i32 %4153, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4155 = extractvalue %dx.types.ResRet.f32 %4154, 0
  %4156 = fsub fast float %4155, %58
  %4157 = call float @dx.op.unary.f32(i32 6, float %4156)  ; FAbs(value)
  %4158 = fdiv fast float %4157, %4014
  %4159 = fsub fast float 1.000000e+00, %4158
  %4160 = call float @dx.op.unary.f32(i32 7, float %4159)  ; Saturate(value)
  %4161 = fcmp fast ugt float %4160, 0.000000e+00
  br i1 %4161, label %4162, label %4288

; <label>:4162                                    ; preds = %4147
  %4163 = call i32 @dx.op.binary.i32(i32 37, i32 %4008, i32 0)  ; IMax(a,b)
  %4164 = call i32 @dx.op.binary.i32(i32 37, i32 %4153, i32 0)  ; IMax(a,b)
  %4165 = call i32 @dx.op.binary.i32(i32 38, i32 %4163, i32 %31)  ; IMin(a,b)
  %4166 = call i32 @dx.op.binary.i32(i32 38, i32 %4164, i32 %32)  ; IMin(a,b)
  %4167 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4165, i32 %4166, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4168 = extractvalue %dx.types.ResRet.f32 %4167, 0
  %4169 = extractvalue %dx.types.ResRet.f32 %4167, 1
  %4170 = extractvalue %dx.types.ResRet.f32 %4167, 2
  %4171 = extractvalue %dx.types.ResRet.f32 %4167, 3
  %4172 = fcmp fast olt float %4171, 0.000000e+00
  br i1 %4172, label %4173, label %4207

; <label>:4173                                    ; preds = %4162
  %4174 = fcmp fast ogt float %4168, 0x3FA4B5DCC0000000
  %4175 = fcmp fast ogt float %4169, 0x3FA4B5DCC0000000
  %4176 = fcmp fast ogt float %4170, 0x3FA4B5DCC0000000
  %4177 = select i1 %4174, float 0.000000e+00, float 1.000000e+00
  %4178 = select i1 %4175, float 0.000000e+00, float 1.000000e+00
  %4179 = select i1 %4176, float 0.000000e+00, float 1.000000e+00
  %4180 = fmul fast float %4168, 0x3FB3D07220000000
  %4181 = fmul fast float %4169, 0x3FB3D07220000000
  %4182 = fmul fast float %4170, 0x3FB3D07220000000
  %4183 = fadd fast float %4168, 0x3FAC28F5C0000000
  %4184 = fadd fast float %4169, 0x3FAC28F5C0000000
  %4185 = fadd fast float %4170, 0x3FAC28F5C0000000
  %4186 = fmul fast float %4183, 0x3FEE54EDE0000000
  %4187 = fmul fast float %4184, 0x3FEE54EDE0000000
  %4188 = fmul fast float %4185, 0x3FEE54EDE0000000
  %4189 = call float @dx.op.unary.f32(i32 23, float %4186)  ; Log(value)
  %4190 = call float @dx.op.unary.f32(i32 23, float %4187)  ; Log(value)
  %4191 = call float @dx.op.unary.f32(i32 23, float %4188)  ; Log(value)
  %4192 = fmul fast float %4189, 0x4003333340000000
  %4193 = fmul fast float %4190, 0x4003333340000000
  %4194 = fmul fast float %4191, 0x4003333340000000
  %4195 = call float @dx.op.unary.f32(i32 21, float %4192)  ; Exp(value)
  %4196 = call float @dx.op.unary.f32(i32 21, float %4193)  ; Exp(value)
  %4197 = call float @dx.op.unary.f32(i32 21, float %4194)  ; Exp(value)
  %4198 = fsub fast float %4180, %4195
  %4199 = fsub fast float %4181, %4196
  %4200 = fsub fast float %4182, %4197
  %4201 = fmul fast float %4198, %4177
  %4202 = fmul fast float %4199, %4178
  %4203 = fmul fast float %4200, %4179
  %4204 = fadd fast float %4201, %4195
  %4205 = fadd fast float %4202, %4196
  %4206 = fadd fast float %4203, %4197
  br label %4275

; <label>:4207                                    ; preds = %4162
  %4208 = fadd fast float %6, 1.000000e+00
  %4209 = fadd fast float %7, 1.000000e+00
  %4210 = fsub fast float 1.000000e+00, %6
  %4211 = fmul fast float %10, %4208
  %4212 = fmul fast float %10, %4209
  %4213 = fmul fast float %10, %4210
  %4214 = fmul fast float %4211, %4168
  %4215 = fmul fast float %4212, %4169
  %4216 = fmul fast float %4213, %4170
  %4217 = fcmp fast ult float %11, 5.000000e-01
  br i1 %4217, label %4243, label %4218

; <label>:4218                                    ; preds = %4207
  %4219 = fmul fast float %4214, 0x4004147AE0000000
  %4220 = fmul fast float %4215, 0x4004147AE0000000
  %4221 = fmul fast float %4216, 0x4004147AE0000000
  %4222 = fadd fast float %4219, 0x3F9EB851E0000000
  %4223 = fadd fast float %4220, 0x3F9EB851E0000000
  %4224 = fadd fast float %4221, 0x3F9EB851E0000000
  %4225 = fmul fast float %4222, %4214
  %4226 = fmul fast float %4223, %4215
  %4227 = fmul fast float %4224, %4216
  %4228 = fmul fast float %4214, 0x400370A3E0000000
  %4229 = fmul fast float %4215, 0x400370A3E0000000
  %4230 = fmul fast float %4216, 0x400370A3E0000000
  %4231 = fadd fast float %4228, 0x3FE2E147A0000000
  %4232 = fadd fast float %4229, 0x3FE2E147A0000000
  %4233 = fadd fast float %4230, 0x3FE2E147A0000000
  %4234 = fmul fast float %4231, %4214
  %4235 = fmul fast float %4232, %4215
  %4236 = fmul fast float %4233, %4216
  %4237 = fadd fast float %4234, 0x3FC1EB8520000000
  %4238 = fadd fast float %4235, 0x3FC1EB8520000000
  %4239 = fadd fast float %4236, 0x3FC1EB8520000000
  %4240 = fdiv fast float %4225, %4237
  %4241 = fdiv fast float %4226, %4238
  %4242 = fdiv fast float %4227, %4239
  br label %4243

; <label>:4243                                    ; preds = %4218, %4207
  %4244 = phi float [ %4240, %4218 ], [ %4214, %4207 ]
  %4245 = phi float [ %4241, %4218 ], [ %4215, %4207 ]
  %4246 = phi float [ %4242, %4218 ], [ %4216, %4207 ]
  %4247 = call float @dx.op.unary.f32(i32 7, float %4244)  ; Saturate(value)
  %4248 = call float @dx.op.unary.f32(i32 7, float %4245)  ; Saturate(value)
  %4249 = call float @dx.op.unary.f32(i32 7, float %4246)  ; Saturate(value)
  %4250 = call float @dx.op.dot3.f32(i32 55, float %4247, float %4248, float %4249, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4251 = fsub fast float %4247, %4250
  %4252 = fsub fast float %4248, %4250
  %4253 = fsub fast float %4249, %4250
  %4254 = fmul fast float %4251, %9
  %4255 = fmul fast float %4252, %9
  %4256 = fmul fast float %4253, %9
  %4257 = fadd fast float %4254, %4250
  %4258 = fadd fast float %4255, %4250
  %4259 = fadd fast float %4256, %4250
  %4260 = call float @dx.op.unary.f32(i32 7, float %4257)  ; Saturate(value)
  %4261 = call float @dx.op.unary.f32(i32 7, float %4258)  ; Saturate(value)
  %4262 = call float @dx.op.unary.f32(i32 7, float %4259)  ; Saturate(value)
  %4263 = fadd fast float %4260, 0xBFC70A3D80000000
  %4264 = fadd fast float %4261, 0xBFC70A3D80000000
  %4265 = fadd fast float %4262, 0xBFC70A3D80000000
  %4266 = fmul fast float %4263, %8
  %4267 = fmul fast float %4264, %8
  %4268 = fmul fast float %4265, %8
  %4269 = fadd fast float %4266, 0x3FC70A3D80000000
  %4270 = fadd fast float %4267, 0x3FC70A3D80000000
  %4271 = fadd fast float %4268, 0x3FC70A3D80000000
  %4272 = call float @dx.op.unary.f32(i32 7, float %4269)  ; Saturate(value)
  %4273 = call float @dx.op.unary.f32(i32 7, float %4270)  ; Saturate(value)
  %4274 = call float @dx.op.unary.f32(i32 7, float %4271)  ; Saturate(value)
  br label %4275

; <label>:4275                                    ; preds = %4243, %4173
  %4276 = phi float [ %4204, %4173 ], [ %4272, %4243 ]
  %4277 = phi float [ %4205, %4173 ], [ %4273, %4243 ]
  %4278 = phi float [ %4206, %4173 ], [ %4274, %4243 ]
  %4279 = fsub fast float %4276, %4000
  %4280 = fsub fast float %4277, %4001
  %4281 = fsub fast float %4278, %4002
  %4282 = fmul fast float %4279, %4160
  %4283 = fmul fast float %4280, %4160
  %4284 = fmul fast float %4281, %4160
  %4285 = fadd fast float %4282, %4000
  %4286 = fadd fast float %4283, %4001
  %4287 = fadd fast float %4284, %4002
  br label %4288

; <label>:4288                                    ; preds = %4275, %4147
  %4289 = phi float [ %4285, %4275 ], [ %4000, %4147 ]
  %4290 = phi float [ %4286, %4275 ], [ %4001, %4147 ]
  %4291 = phi float [ %4287, %4275 ], [ %4002, %4147 ]
  %4292 = add i32 %35, -1
  %4293 = call i32 @dx.op.binary.i32(i32 37, i32 %4292, i32 0)  ; IMax(a,b)
  %4294 = call i32 @dx.op.binary.i32(i32 37, i32 %42, i32 0)  ; IMax(a,b)
  %4295 = call i32 @dx.op.binary.i32(i32 38, i32 %4293, i32 %31)  ; IMin(a,b)
  %4296 = call i32 @dx.op.binary.i32(i32 38, i32 %4294, i32 %32)  ; IMin(a,b)
  %4297 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4295, i32 %4296, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4298 = extractvalue %dx.types.ResRet.f32 %4297, 0
  %4299 = fsub fast float %4298, %58
  %4300 = call float @dx.op.unary.f32(i32 6, float %4299)  ; FAbs(value)
  %4301 = fdiv fast float %4300, %4014
  %4302 = fsub fast float 1.000000e+00, %4301
  %4303 = call float @dx.op.unary.f32(i32 7, float %4302)  ; Saturate(value)
  %4304 = fcmp fast ugt float %4303, 0.000000e+00
  br i1 %4304, label %4305, label %4431

; <label>:4305                                    ; preds = %4288
  %4306 = call i32 @dx.op.binary.i32(i32 37, i32 %4295, i32 0)  ; IMax(a,b)
  %4307 = call i32 @dx.op.binary.i32(i32 37, i32 %4296, i32 0)  ; IMax(a,b)
  %4308 = call i32 @dx.op.binary.i32(i32 38, i32 %4306, i32 %31)  ; IMin(a,b)
  %4309 = call i32 @dx.op.binary.i32(i32 38, i32 %4307, i32 %32)  ; IMin(a,b)
  %4310 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4308, i32 %4309, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4311 = extractvalue %dx.types.ResRet.f32 %4310, 0
  %4312 = extractvalue %dx.types.ResRet.f32 %4310, 1
  %4313 = extractvalue %dx.types.ResRet.f32 %4310, 2
  %4314 = extractvalue %dx.types.ResRet.f32 %4310, 3
  %4315 = fcmp fast olt float %4314, 0.000000e+00
  br i1 %4315, label %4316, label %4350

; <label>:4316                                    ; preds = %4305
  %4317 = fcmp fast ogt float %4311, 0x3FA4B5DCC0000000
  %4318 = fcmp fast ogt float %4312, 0x3FA4B5DCC0000000
  %4319 = fcmp fast ogt float %4313, 0x3FA4B5DCC0000000
  %4320 = select i1 %4317, float 0.000000e+00, float 1.000000e+00
  %4321 = select i1 %4318, float 0.000000e+00, float 1.000000e+00
  %4322 = select i1 %4319, float 0.000000e+00, float 1.000000e+00
  %4323 = fmul fast float %4311, 0x3FB3D07220000000
  %4324 = fmul fast float %4312, 0x3FB3D07220000000
  %4325 = fmul fast float %4313, 0x3FB3D07220000000
  %4326 = fadd fast float %4311, 0x3FAC28F5C0000000
  %4327 = fadd fast float %4312, 0x3FAC28F5C0000000
  %4328 = fadd fast float %4313, 0x3FAC28F5C0000000
  %4329 = fmul fast float %4326, 0x3FEE54EDE0000000
  %4330 = fmul fast float %4327, 0x3FEE54EDE0000000
  %4331 = fmul fast float %4328, 0x3FEE54EDE0000000
  %4332 = call float @dx.op.unary.f32(i32 23, float %4329)  ; Log(value)
  %4333 = call float @dx.op.unary.f32(i32 23, float %4330)  ; Log(value)
  %4334 = call float @dx.op.unary.f32(i32 23, float %4331)  ; Log(value)
  %4335 = fmul fast float %4332, 0x4003333340000000
  %4336 = fmul fast float %4333, 0x4003333340000000
  %4337 = fmul fast float %4334, 0x4003333340000000
  %4338 = call float @dx.op.unary.f32(i32 21, float %4335)  ; Exp(value)
  %4339 = call float @dx.op.unary.f32(i32 21, float %4336)  ; Exp(value)
  %4340 = call float @dx.op.unary.f32(i32 21, float %4337)  ; Exp(value)
  %4341 = fsub fast float %4323, %4338
  %4342 = fsub fast float %4324, %4339
  %4343 = fsub fast float %4325, %4340
  %4344 = fmul fast float %4341, %4320
  %4345 = fmul fast float %4342, %4321
  %4346 = fmul fast float %4343, %4322
  %4347 = fadd fast float %4344, %4338
  %4348 = fadd fast float %4345, %4339
  %4349 = fadd fast float %4346, %4340
  br label %4418

; <label>:4350                                    ; preds = %4305
  %4351 = fadd fast float %6, 1.000000e+00
  %4352 = fadd fast float %7, 1.000000e+00
  %4353 = fsub fast float 1.000000e+00, %6
  %4354 = fmul fast float %10, %4351
  %4355 = fmul fast float %10, %4352
  %4356 = fmul fast float %10, %4353
  %4357 = fmul fast float %4354, %4311
  %4358 = fmul fast float %4355, %4312
  %4359 = fmul fast float %4356, %4313
  %4360 = fcmp fast ult float %11, 5.000000e-01
  br i1 %4360, label %4386, label %4361

; <label>:4361                                    ; preds = %4350
  %4362 = fmul fast float %4357, 0x4004147AE0000000
  %4363 = fmul fast float %4358, 0x4004147AE0000000
  %4364 = fmul fast float %4359, 0x4004147AE0000000
  %4365 = fadd fast float %4362, 0x3F9EB851E0000000
  %4366 = fadd fast float %4363, 0x3F9EB851E0000000
  %4367 = fadd fast float %4364, 0x3F9EB851E0000000
  %4368 = fmul fast float %4365, %4357
  %4369 = fmul fast float %4366, %4358
  %4370 = fmul fast float %4367, %4359
  %4371 = fmul fast float %4357, 0x400370A3E0000000
  %4372 = fmul fast float %4358, 0x400370A3E0000000
  %4373 = fmul fast float %4359, 0x400370A3E0000000
  %4374 = fadd fast float %4371, 0x3FE2E147A0000000
  %4375 = fadd fast float %4372, 0x3FE2E147A0000000
  %4376 = fadd fast float %4373, 0x3FE2E147A0000000
  %4377 = fmul fast float %4374, %4357
  %4378 = fmul fast float %4375, %4358
  %4379 = fmul fast float %4376, %4359
  %4380 = fadd fast float %4377, 0x3FC1EB8520000000
  %4381 = fadd fast float %4378, 0x3FC1EB8520000000
  %4382 = fadd fast float %4379, 0x3FC1EB8520000000
  %4383 = fdiv fast float %4368, %4380
  %4384 = fdiv fast float %4369, %4381
  %4385 = fdiv fast float %4370, %4382
  br label %4386

; <label>:4386                                    ; preds = %4361, %4350
  %4387 = phi float [ %4383, %4361 ], [ %4357, %4350 ]
  %4388 = phi float [ %4384, %4361 ], [ %4358, %4350 ]
  %4389 = phi float [ %4385, %4361 ], [ %4359, %4350 ]
  %4390 = call float @dx.op.unary.f32(i32 7, float %4387)  ; Saturate(value)
  %4391 = call float @dx.op.unary.f32(i32 7, float %4388)  ; Saturate(value)
  %4392 = call float @dx.op.unary.f32(i32 7, float %4389)  ; Saturate(value)
  %4393 = call float @dx.op.dot3.f32(i32 55, float %4390, float %4391, float %4392, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4394 = fsub fast float %4390, %4393
  %4395 = fsub fast float %4391, %4393
  %4396 = fsub fast float %4392, %4393
  %4397 = fmul fast float %4394, %9
  %4398 = fmul fast float %4395, %9
  %4399 = fmul fast float %4396, %9
  %4400 = fadd fast float %4397, %4393
  %4401 = fadd fast float %4398, %4393
  %4402 = fadd fast float %4399, %4393
  %4403 = call float @dx.op.unary.f32(i32 7, float %4400)  ; Saturate(value)
  %4404 = call float @dx.op.unary.f32(i32 7, float %4401)  ; Saturate(value)
  %4405 = call float @dx.op.unary.f32(i32 7, float %4402)  ; Saturate(value)
  %4406 = fadd fast float %4403, 0xBFC70A3D80000000
  %4407 = fadd fast float %4404, 0xBFC70A3D80000000
  %4408 = fadd fast float %4405, 0xBFC70A3D80000000
  %4409 = fmul fast float %4406, %8
  %4410 = fmul fast float %4407, %8
  %4411 = fmul fast float %4408, %8
  %4412 = fadd fast float %4409, 0x3FC70A3D80000000
  %4413 = fadd fast float %4410, 0x3FC70A3D80000000
  %4414 = fadd fast float %4411, 0x3FC70A3D80000000
  %4415 = call float @dx.op.unary.f32(i32 7, float %4412)  ; Saturate(value)
  %4416 = call float @dx.op.unary.f32(i32 7, float %4413)  ; Saturate(value)
  %4417 = call float @dx.op.unary.f32(i32 7, float %4414)  ; Saturate(value)
  br label %4418

; <label>:4418                                    ; preds = %4386, %4316
  %4419 = phi float [ %4347, %4316 ], [ %4415, %4386 ]
  %4420 = phi float [ %4348, %4316 ], [ %4416, %4386 ]
  %4421 = phi float [ %4349, %4316 ], [ %4417, %4386 ]
  %4422 = fsub fast float %4419, %4000
  %4423 = fsub fast float %4420, %4001
  %4424 = fsub fast float %4421, %4002
  %4425 = fmul fast float %4422, %4303
  %4426 = fmul fast float %4423, %4303
  %4427 = fmul fast float %4424, %4303
  %4428 = fadd fast float %4425, %4000
  %4429 = fadd fast float %4426, %4001
  %4430 = fadd fast float %4427, %4002
  br label %4431

; <label>:4431                                    ; preds = %4418, %4288
  %4432 = phi float [ %4428, %4418 ], [ %4000, %4288 ]
  %4433 = phi float [ %4429, %4418 ], [ %4001, %4288 ]
  %4434 = phi float [ %4430, %4418 ], [ %4002, %4288 ]
  %4435 = add i32 %35, 1
  %4436 = call i32 @dx.op.binary.i32(i32 37, i32 %4435, i32 0)  ; IMax(a,b)
  %4437 = call i32 @dx.op.binary.i32(i32 38, i32 %4436, i32 %31)  ; IMin(a,b)
  %4438 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4437, i32 %4296, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4439 = extractvalue %dx.types.ResRet.f32 %4438, 0
  %4440 = fsub fast float %4439, %58
  %4441 = call float @dx.op.unary.f32(i32 6, float %4440)  ; FAbs(value)
  %4442 = fdiv fast float %4441, %4014
  %4443 = fsub fast float 1.000000e+00, %4442
  %4444 = call float @dx.op.unary.f32(i32 7, float %4443)  ; Saturate(value)
  %4445 = fcmp fast ugt float %4444, 0.000000e+00
  br i1 %4445, label %4446, label %4572

; <label>:4446                                    ; preds = %4431
  %4447 = call i32 @dx.op.binary.i32(i32 37, i32 %4437, i32 0)  ; IMax(a,b)
  %4448 = call i32 @dx.op.binary.i32(i32 37, i32 %4296, i32 0)  ; IMax(a,b)
  %4449 = call i32 @dx.op.binary.i32(i32 38, i32 %4447, i32 %31)  ; IMin(a,b)
  %4450 = call i32 @dx.op.binary.i32(i32 38, i32 %4448, i32 %32)  ; IMin(a,b)
  %4451 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4449, i32 %4450, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4452 = extractvalue %dx.types.ResRet.f32 %4451, 0
  %4453 = extractvalue %dx.types.ResRet.f32 %4451, 1
  %4454 = extractvalue %dx.types.ResRet.f32 %4451, 2
  %4455 = extractvalue %dx.types.ResRet.f32 %4451, 3
  %4456 = fcmp fast olt float %4455, 0.000000e+00
  br i1 %4456, label %4457, label %4491

; <label>:4457                                    ; preds = %4446
  %4458 = fcmp fast ogt float %4452, 0x3FA4B5DCC0000000
  %4459 = fcmp fast ogt float %4453, 0x3FA4B5DCC0000000
  %4460 = fcmp fast ogt float %4454, 0x3FA4B5DCC0000000
  %4461 = select i1 %4458, float 0.000000e+00, float 1.000000e+00
  %4462 = select i1 %4459, float 0.000000e+00, float 1.000000e+00
  %4463 = select i1 %4460, float 0.000000e+00, float 1.000000e+00
  %4464 = fmul fast float %4452, 0x3FB3D07220000000
  %4465 = fmul fast float %4453, 0x3FB3D07220000000
  %4466 = fmul fast float %4454, 0x3FB3D07220000000
  %4467 = fadd fast float %4452, 0x3FAC28F5C0000000
  %4468 = fadd fast float %4453, 0x3FAC28F5C0000000
  %4469 = fadd fast float %4454, 0x3FAC28F5C0000000
  %4470 = fmul fast float %4467, 0x3FEE54EDE0000000
  %4471 = fmul fast float %4468, 0x3FEE54EDE0000000
  %4472 = fmul fast float %4469, 0x3FEE54EDE0000000
  %4473 = call float @dx.op.unary.f32(i32 23, float %4470)  ; Log(value)
  %4474 = call float @dx.op.unary.f32(i32 23, float %4471)  ; Log(value)
  %4475 = call float @dx.op.unary.f32(i32 23, float %4472)  ; Log(value)
  %4476 = fmul fast float %4473, 0x4003333340000000
  %4477 = fmul fast float %4474, 0x4003333340000000
  %4478 = fmul fast float %4475, 0x4003333340000000
  %4479 = call float @dx.op.unary.f32(i32 21, float %4476)  ; Exp(value)
  %4480 = call float @dx.op.unary.f32(i32 21, float %4477)  ; Exp(value)
  %4481 = call float @dx.op.unary.f32(i32 21, float %4478)  ; Exp(value)
  %4482 = fsub fast float %4464, %4479
  %4483 = fsub fast float %4465, %4480
  %4484 = fsub fast float %4466, %4481
  %4485 = fmul fast float %4482, %4461
  %4486 = fmul fast float %4483, %4462
  %4487 = fmul fast float %4484, %4463
  %4488 = fadd fast float %4485, %4479
  %4489 = fadd fast float %4486, %4480
  %4490 = fadd fast float %4487, %4481
  br label %4559

; <label>:4491                                    ; preds = %4446
  %4492 = fadd fast float %6, 1.000000e+00
  %4493 = fadd fast float %7, 1.000000e+00
  %4494 = fsub fast float 1.000000e+00, %6
  %4495 = fmul fast float %10, %4492
  %4496 = fmul fast float %10, %4493
  %4497 = fmul fast float %10, %4494
  %4498 = fmul fast float %4495, %4452
  %4499 = fmul fast float %4496, %4453
  %4500 = fmul fast float %4497, %4454
  %4501 = fcmp fast ult float %11, 5.000000e-01
  br i1 %4501, label %4527, label %4502

; <label>:4502                                    ; preds = %4491
  %4503 = fmul fast float %4498, 0x4004147AE0000000
  %4504 = fmul fast float %4499, 0x4004147AE0000000
  %4505 = fmul fast float %4500, 0x4004147AE0000000
  %4506 = fadd fast float %4503, 0x3F9EB851E0000000
  %4507 = fadd fast float %4504, 0x3F9EB851E0000000
  %4508 = fadd fast float %4505, 0x3F9EB851E0000000
  %4509 = fmul fast float %4506, %4498
  %4510 = fmul fast float %4507, %4499
  %4511 = fmul fast float %4508, %4500
  %4512 = fmul fast float %4498, 0x400370A3E0000000
  %4513 = fmul fast float %4499, 0x400370A3E0000000
  %4514 = fmul fast float %4500, 0x400370A3E0000000
  %4515 = fadd fast float %4512, 0x3FE2E147A0000000
  %4516 = fadd fast float %4513, 0x3FE2E147A0000000
  %4517 = fadd fast float %4514, 0x3FE2E147A0000000
  %4518 = fmul fast float %4515, %4498
  %4519 = fmul fast float %4516, %4499
  %4520 = fmul fast float %4517, %4500
  %4521 = fadd fast float %4518, 0x3FC1EB8520000000
  %4522 = fadd fast float %4519, 0x3FC1EB8520000000
  %4523 = fadd fast float %4520, 0x3FC1EB8520000000
  %4524 = fdiv fast float %4509, %4521
  %4525 = fdiv fast float %4510, %4522
  %4526 = fdiv fast float %4511, %4523
  br label %4527

; <label>:4527                                    ; preds = %4502, %4491
  %4528 = phi float [ %4524, %4502 ], [ %4498, %4491 ]
  %4529 = phi float [ %4525, %4502 ], [ %4499, %4491 ]
  %4530 = phi float [ %4526, %4502 ], [ %4500, %4491 ]
  %4531 = call float @dx.op.unary.f32(i32 7, float %4528)  ; Saturate(value)
  %4532 = call float @dx.op.unary.f32(i32 7, float %4529)  ; Saturate(value)
  %4533 = call float @dx.op.unary.f32(i32 7, float %4530)  ; Saturate(value)
  %4534 = call float @dx.op.dot3.f32(i32 55, float %4531, float %4532, float %4533, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4535 = fsub fast float %4531, %4534
  %4536 = fsub fast float %4532, %4534
  %4537 = fsub fast float %4533, %4534
  %4538 = fmul fast float %4535, %9
  %4539 = fmul fast float %4536, %9
  %4540 = fmul fast float %4537, %9
  %4541 = fadd fast float %4538, %4534
  %4542 = fadd fast float %4539, %4534
  %4543 = fadd fast float %4540, %4534
  %4544 = call float @dx.op.unary.f32(i32 7, float %4541)  ; Saturate(value)
  %4545 = call float @dx.op.unary.f32(i32 7, float %4542)  ; Saturate(value)
  %4546 = call float @dx.op.unary.f32(i32 7, float %4543)  ; Saturate(value)
  %4547 = fadd fast float %4544, 0xBFC70A3D80000000
  %4548 = fadd fast float %4545, 0xBFC70A3D80000000
  %4549 = fadd fast float %4546, 0xBFC70A3D80000000
  %4550 = fmul fast float %4547, %8
  %4551 = fmul fast float %4548, %8
  %4552 = fmul fast float %4549, %8
  %4553 = fadd fast float %4550, 0x3FC70A3D80000000
  %4554 = fadd fast float %4551, 0x3FC70A3D80000000
  %4555 = fadd fast float %4552, 0x3FC70A3D80000000
  %4556 = call float @dx.op.unary.f32(i32 7, float %4553)  ; Saturate(value)
  %4557 = call float @dx.op.unary.f32(i32 7, float %4554)  ; Saturate(value)
  %4558 = call float @dx.op.unary.f32(i32 7, float %4555)  ; Saturate(value)
  br label %4559

; <label>:4559                                    ; preds = %4527, %4457
  %4560 = phi float [ %4488, %4457 ], [ %4556, %4527 ]
  %4561 = phi float [ %4489, %4457 ], [ %4557, %4527 ]
  %4562 = phi float [ %4490, %4457 ], [ %4558, %4527 ]
  %4563 = fsub fast float %4560, %4000
  %4564 = fsub fast float %4561, %4001
  %4565 = fsub fast float %4562, %4002
  %4566 = fmul fast float %4563, %4444
  %4567 = fmul fast float %4564, %4444
  %4568 = fmul fast float %4565, %4444
  %4569 = fadd fast float %4566, %4000
  %4570 = fadd fast float %4567, %4001
  %4571 = fadd fast float %4568, %4002
  br label %4572

; <label>:4572                                    ; preds = %4559, %4431
  %4573 = phi float [ %4569, %4559 ], [ %4000, %4431 ]
  %4574 = phi float [ %4570, %4559 ], [ %4001, %4431 ]
  %4575 = phi float [ %4571, %4559 ], [ %4002, %4431 ]
  %4576 = call float @dx.op.binary.f32(i32 36, float %4432, float %4573)  ; FMin(a,b)
  %4577 = call float @dx.op.binary.f32(i32 36, float %4433, float %4574)  ; FMin(a,b)
  %4578 = call float @dx.op.binary.f32(i32 36, float %4434, float %4575)  ; FMin(a,b)
  %4579 = call float @dx.op.binary.f32(i32 36, float %4148, float %4289)  ; FMin(a,b)
  %4580 = call float @dx.op.binary.f32(i32 36, float %4149, float %4290)  ; FMin(a,b)
  %4581 = call float @dx.op.binary.f32(i32 36, float %4150, float %4291)  ; FMin(a,b)
  %4582 = call float @dx.op.binary.f32(i32 36, float %4579, float %4576)  ; FMin(a,b)
  %4583 = call float @dx.op.binary.f32(i32 36, float %4580, float %4577)  ; FMin(a,b)
  %4584 = call float @dx.op.binary.f32(i32 36, float %4581, float %4578)  ; FMin(a,b)
  %4585 = call float @dx.op.binary.f32(i32 36, float %4000, float %4582)  ; FMin(a,b)
  %4586 = call float @dx.op.binary.f32(i32 36, float %4001, float %4583)  ; FMin(a,b)
  %4587 = call float @dx.op.binary.f32(i32 36, float %4002, float %4584)  ; FMin(a,b)
  %4588 = call float @dx.op.binary.f32(i32 35, float %4432, float %4573)  ; FMax(a,b)
  %4589 = call float @dx.op.binary.f32(i32 35, float %4433, float %4574)  ; FMax(a,b)
  %4590 = call float @dx.op.binary.f32(i32 35, float %4434, float %4575)  ; FMax(a,b)
  %4591 = call float @dx.op.binary.f32(i32 35, float %4148, float %4289)  ; FMax(a,b)
  %4592 = call float @dx.op.binary.f32(i32 35, float %4149, float %4290)  ; FMax(a,b)
  %4593 = call float @dx.op.binary.f32(i32 35, float %4150, float %4291)  ; FMax(a,b)
  %4594 = call float @dx.op.binary.f32(i32 35, float %4591, float %4588)  ; FMax(a,b)
  %4595 = call float @dx.op.binary.f32(i32 35, float %4592, float %4589)  ; FMax(a,b)
  %4596 = call float @dx.op.binary.f32(i32 35, float %4593, float %4590)  ; FMax(a,b)
  %4597 = call float @dx.op.binary.f32(i32 35, float %4000, float %4594)  ; FMax(a,b)
  %4598 = call float @dx.op.binary.f32(i32 35, float %4001, float %4595)  ; FMax(a,b)
  %4599 = call float @dx.op.binary.f32(i32 35, float %4002, float %4596)  ; FMax(a,b)
  %4600 = fsub fast float %4597, %4585
  %4601 = fsub fast float %4598, %4586
  %4602 = fsub fast float %4599, %4587
  %4603 = call float @dx.op.unary.f32(i32 6, float %4600)  ; FAbs(value)
  %4604 = call float @dx.op.unary.f32(i32 6, float %4601)  ; FAbs(value)
  %4605 = call float @dx.op.unary.f32(i32 6, float %4602)  ; FAbs(value)
  %4606 = call float @dx.op.binary.f32(i32 35, float %4604, float %4605)  ; FMax(a,b)
  %4607 = call float @dx.op.binary.f32(i32 35, float %4603, float %4606)  ; FMax(a,b)
  %4608 = call float @dx.op.binary.f32(i32 35, float %4598, float %4599)  ; FMax(a,b)
  %4609 = call float @dx.op.binary.f32(i32 35, float %4597, float %4608)  ; FMax(a,b)
  %4610 = fmul fast float %4609, 1.250000e-01
  %4611 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %4610)  ; FMax(a,b)
  %4612 = fcmp fast ogt float %4607, %4611
  br i1 %4612, label %4613, label %4675

; <label>:4613                                    ; preds = %4572
  %4614 = fsub fast float %4148, %4289
  %4615 = fsub fast float %4149, %4290
  %4616 = fsub fast float %4150, %4291
  %4617 = call float @dx.op.unary.f32(i32 6, float %4614)  ; FAbs(value)
  %4618 = call float @dx.op.unary.f32(i32 6, float %4615)  ; FAbs(value)
  %4619 = call float @dx.op.unary.f32(i32 6, float %4616)  ; FAbs(value)
  %4620 = call float @dx.op.binary.f32(i32 35, float %4618, float %4619)  ; FMax(a,b)
  %4621 = call float @dx.op.binary.f32(i32 35, float %4617, float %4620)  ; FMax(a,b)
  %4622 = fsub fast float %4432, %4573
  %4623 = fsub fast float %4433, %4574
  %4624 = fsub fast float %4434, %4575
  %4625 = call float @dx.op.unary.f32(i32 6, float %4622)  ; FAbs(value)
  %4626 = call float @dx.op.unary.f32(i32 6, float %4623)  ; FAbs(value)
  %4627 = call float @dx.op.unary.f32(i32 6, float %4624)  ; FAbs(value)
  %4628 = call float @dx.op.binary.f32(i32 35, float %4626, float %4627)  ; FMax(a,b)
  %4629 = call float @dx.op.binary.f32(i32 35, float %4625, float %4628)  ; FMax(a,b)
  %4630 = fcmp fast olt float %4621, %4629
  %4631 = select i1 %4630, float %4148, float %4432
  %4632 = select i1 %4630, float %4149, float %4433
  %4633 = select i1 %4630, float %4150, float %4434
  %4634 = select i1 %4630, float %4289, float %4573
  %4635 = select i1 %4630, float %4290, float %4574
  %4636 = select i1 %4630, float %4291, float %4575
  %4637 = fsub fast float %4000, %4634
  %4638 = fsub fast float %4001, %4635
  %4639 = fsub fast float %4002, %4636
  %4640 = fsub fast float %4000, %4631
  %4641 = fsub fast float %4001, %4632
  %4642 = fsub fast float %4002, %4633
  %4643 = call float @dx.op.dot3.f32(i32 55, float %4640, float %4641, float %4642, float %4637, float %4638, float %4639)  ; Dot3(ax,ay,az,bx,by,bz)
  %4644 = fcmp fast ogt float %4643, 0.000000e+00
  br i1 %4644, label %4645, label %4656

; <label>:4645                                    ; preds = %4613
  %4646 = fsub fast float %4631, %4634
  %4647 = fsub fast float %4632, %4635
  %4648 = fsub fast float %4633, %4636
  %4649 = call float @dx.op.unary.f32(i32 6, float %4646)  ; FAbs(value)
  %4650 = call float @dx.op.unary.f32(i32 6, float %4647)  ; FAbs(value)
  %4651 = call float @dx.op.unary.f32(i32 6, float %4648)  ; FAbs(value)
  %4652 = call float @dx.op.binary.f32(i32 35, float %4650, float %4651)  ; FMax(a,b)
  %4653 = call float @dx.op.binary.f32(i32 35, float %4649, float %4652)  ; FMax(a,b)
  %4654 = fmul fast float %4607, 2.500000e-01
  %4655 = fcmp fast olt float %4653, %4654
  br label %4656

; <label>:4656                                    ; preds = %4645, %4613
  %4657 = phi i1 [ false, %4613 ], [ %4655, %4645 ]
  %4658 = select i1 %4657, float 5.000000e-01, float 1.000000e+00
  %4659 = fmul fast float %4658, %3
  %4660 = fadd fast float %4631, %4634
  %4661 = fadd fast float %4632, %4635
  %4662 = fadd fast float %4633, %4636
  %4663 = fmul fast float %4660, 5.000000e-01
  %4664 = fmul fast float %4661, 5.000000e-01
  %4665 = fmul fast float %4662, 5.000000e-01
  %4666 = fsub fast float %4663, %4000
  %4667 = fsub fast float %4664, %4001
  %4668 = fsub fast float %4665, %4002
  %4669 = fmul fast float %4659, %4666
  %4670 = fmul fast float %4659, %4667
  %4671 = fmul fast float %4659, %4668
  %4672 = fadd fast float %4669, %4000
  %4673 = fadd fast float %4670, %4001
  %4674 = fadd fast float %4671, %4002
  br label %4675

; <label>:4675                                    ; preds = %4656, %4572, %3971, %3900
  %4676 = phi float [ %3931, %3900 ], [ %4000, %3971 ], [ %4672, %4656 ], [ %4000, %4572 ]
  %4677 = phi float [ %3932, %3900 ], [ %4001, %3971 ], [ %4673, %4656 ], [ %4001, %4572 ]
  %4678 = phi float [ %3933, %3900 ], [ %4002, %3971 ], [ %4674, %4656 ], [ %4002, %4572 ]
  %4679 = phi float [ %3934, %3900 ], [ %3898, %3971 ], [ %3898, %4656 ], [ %3898, %4572 ]
  %4680 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %39, i32 %42, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4681 = extractvalue %dx.types.ResRet.f32 %4680, 0
  %4682 = extractvalue %dx.types.ResRet.f32 %4680, 1
  %4683 = extractvalue %dx.types.ResRet.f32 %4680, 2
  %4684 = extractvalue %dx.types.ResRet.f32 %4680, 3
  %4685 = fcmp fast olt float %4684, 0.000000e+00
  br i1 %4685, label %4686, label %4721

; <label>:4686                                    ; preds = %4675
  %4687 = fcmp fast ogt float %4681, 0x3FA4B5DCC0000000
  %4688 = fcmp fast ogt float %4682, 0x3FA4B5DCC0000000
  %4689 = fcmp fast ogt float %4683, 0x3FA4B5DCC0000000
  %4690 = select i1 %4687, float 0.000000e+00, float 1.000000e+00
  %4691 = select i1 %4688, float 0.000000e+00, float 1.000000e+00
  %4692 = select i1 %4689, float 0.000000e+00, float 1.000000e+00
  %4693 = fmul fast float %4681, 0x3FB3D07220000000
  %4694 = fmul fast float %4682, 0x3FB3D07220000000
  %4695 = fmul fast float %4683, 0x3FB3D07220000000
  %4696 = fadd fast float %4681, 0x3FAC28F5C0000000
  %4697 = fadd fast float %4682, 0x3FAC28F5C0000000
  %4698 = fadd fast float %4683, 0x3FAC28F5C0000000
  %4699 = fmul fast float %4696, 0x3FEE54EDE0000000
  %4700 = fmul fast float %4697, 0x3FEE54EDE0000000
  %4701 = fmul fast float %4698, 0x3FEE54EDE0000000
  %4702 = call float @dx.op.unary.f32(i32 23, float %4699)  ; Log(value)
  %4703 = call float @dx.op.unary.f32(i32 23, float %4700)  ; Log(value)
  %4704 = call float @dx.op.unary.f32(i32 23, float %4701)  ; Log(value)
  %4705 = fmul fast float %4702, 0x4003333340000000
  %4706 = fmul fast float %4703, 0x4003333340000000
  %4707 = fmul fast float %4704, 0x4003333340000000
  %4708 = call float @dx.op.unary.f32(i32 21, float %4705)  ; Exp(value)
  %4709 = call float @dx.op.unary.f32(i32 21, float %4706)  ; Exp(value)
  %4710 = call float @dx.op.unary.f32(i32 21, float %4707)  ; Exp(value)
  %4711 = fsub fast float %4693, %4708
  %4712 = fsub fast float %4694, %4709
  %4713 = fsub fast float %4695, %4710
  %4714 = fmul fast float %4711, %4690
  %4715 = fmul fast float %4712, %4691
  %4716 = fmul fast float %4713, %4692
  %4717 = fadd fast float %4714, %4708
  %4718 = fadd fast float %4715, %4709
  %4719 = fadd fast float %4716, %4710
  %4720 = fsub fast float -1.000000e+00, %4684
  br label %5461

; <label>:4721                                    ; preds = %4675
  %4722 = fadd fast float %6, 1.000000e+00
  %4723 = fadd fast float %7, 1.000000e+00
  %4724 = fsub fast float 1.000000e+00, %6
  %4725 = fmul fast float %10, %4722
  %4726 = fmul fast float %10, %4723
  %4727 = fmul fast float %10, %4724
  %4728 = fmul fast float %4725, %4681
  %4729 = fmul fast float %4726, %4682
  %4730 = fmul fast float %4727, %4683
  %4731 = fcmp fast ult float %11, 5.000000e-01
  br i1 %4731, label %4757, label %4732

; <label>:4732                                    ; preds = %4721
  %4733 = fmul fast float %4728, 0x4004147AE0000000
  %4734 = fmul fast float %4729, 0x4004147AE0000000
  %4735 = fmul fast float %4730, 0x4004147AE0000000
  %4736 = fadd fast float %4733, 0x3F9EB851E0000000
  %4737 = fadd fast float %4734, 0x3F9EB851E0000000
  %4738 = fadd fast float %4735, 0x3F9EB851E0000000
  %4739 = fmul fast float %4736, %4728
  %4740 = fmul fast float %4737, %4729
  %4741 = fmul fast float %4738, %4730
  %4742 = fmul fast float %4728, 0x400370A3E0000000
  %4743 = fmul fast float %4729, 0x400370A3E0000000
  %4744 = fmul fast float %4730, 0x400370A3E0000000
  %4745 = fadd fast float %4742, 0x3FE2E147A0000000
  %4746 = fadd fast float %4743, 0x3FE2E147A0000000
  %4747 = fadd fast float %4744, 0x3FE2E147A0000000
  %4748 = fmul fast float %4745, %4728
  %4749 = fmul fast float %4746, %4729
  %4750 = fmul fast float %4747, %4730
  %4751 = fadd fast float %4748, 0x3FC1EB8520000000
  %4752 = fadd fast float %4749, 0x3FC1EB8520000000
  %4753 = fadd fast float %4750, 0x3FC1EB8520000000
  %4754 = fdiv fast float %4739, %4751
  %4755 = fdiv fast float %4740, %4752
  %4756 = fdiv fast float %4741, %4753
  br label %4757

; <label>:4757                                    ; preds = %4732, %4721
  %4758 = phi float [ %4754, %4732 ], [ %4728, %4721 ]
  %4759 = phi float [ %4755, %4732 ], [ %4729, %4721 ]
  %4760 = phi float [ %4756, %4732 ], [ %4730, %4721 ]
  %4761 = call float @dx.op.unary.f32(i32 7, float %4758)  ; Saturate(value)
  %4762 = call float @dx.op.unary.f32(i32 7, float %4759)  ; Saturate(value)
  %4763 = call float @dx.op.unary.f32(i32 7, float %4760)  ; Saturate(value)
  %4764 = call float @dx.op.dot3.f32(i32 55, float %4761, float %4762, float %4763, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4765 = fsub fast float %4761, %4764
  %4766 = fsub fast float %4762, %4764
  %4767 = fsub fast float %4763, %4764
  %4768 = fmul fast float %4765, %9
  %4769 = fmul fast float %4766, %9
  %4770 = fmul fast float %4767, %9
  %4771 = fadd fast float %4768, %4764
  %4772 = fadd fast float %4769, %4764
  %4773 = fadd fast float %4770, %4764
  %4774 = call float @dx.op.unary.f32(i32 7, float %4771)  ; Saturate(value)
  %4775 = call float @dx.op.unary.f32(i32 7, float %4772)  ; Saturate(value)
  %4776 = call float @dx.op.unary.f32(i32 7, float %4773)  ; Saturate(value)
  %4777 = fadd fast float %4774, 0xBFC70A3D80000000
  %4778 = fadd fast float %4775, 0xBFC70A3D80000000
  %4779 = fadd fast float %4776, 0xBFC70A3D80000000
  %4780 = fmul fast float %4777, %8
  %4781 = fmul fast float %4778, %8
  %4782 = fmul fast float %4779, %8
  %4783 = fadd fast float %4780, 0x3FC70A3D80000000
  %4784 = fadd fast float %4781, 0x3FC70A3D80000000
  %4785 = fadd fast float %4782, 0x3FC70A3D80000000
  %4786 = call float @dx.op.unary.f32(i32 7, float %4783)  ; Saturate(value)
  %4787 = call float @dx.op.unary.f32(i32 7, float %4784)  ; Saturate(value)
  %4788 = call float @dx.op.unary.f32(i32 7, float %4785)  ; Saturate(value)
  %4789 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %4789, label %4790, label %5461

; <label>:4790                                    ; preds = %4757
  %4791 = add i32 %42, -1
  %4792 = call i32 @dx.op.binary.i32(i32 37, i32 %39, i32 0)  ; IMax(a,b)
  %4793 = call i32 @dx.op.binary.i32(i32 37, i32 %4791, i32 0)  ; IMax(a,b)
  %4794 = call i32 @dx.op.binary.i32(i32 38, i32 %4792, i32 %31)  ; IMin(a,b)
  %4795 = call i32 @dx.op.binary.i32(i32 38, i32 %4793, i32 %32)  ; IMin(a,b)
  %4796 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4794, i32 %4795, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4797 = extractvalue %dx.types.ResRet.f32 %4796, 0
  %4798 = fsub fast float 1.000000e+00, %60
  %4799 = fmul fast float %4798, 0x3FA99999A0000000
  %4800 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %4799)  ; FMax(a,b)
  %4801 = fsub fast float %4797, %60
  %4802 = call float @dx.op.unary.f32(i32 6, float %4801)  ; FAbs(value)
  %4803 = fdiv fast float %4802, %4800
  %4804 = fsub fast float 1.000000e+00, %4803
  %4805 = call float @dx.op.unary.f32(i32 7, float %4804)  ; Saturate(value)
  %4806 = fcmp fast ugt float %4805, 0.000000e+00
  br i1 %4806, label %4807, label %4933

; <label>:4807                                    ; preds = %4790
  %4808 = call i32 @dx.op.binary.i32(i32 37, i32 %4794, i32 0)  ; IMax(a,b)
  %4809 = call i32 @dx.op.binary.i32(i32 37, i32 %4795, i32 0)  ; IMax(a,b)
  %4810 = call i32 @dx.op.binary.i32(i32 38, i32 %4808, i32 %31)  ; IMin(a,b)
  %4811 = call i32 @dx.op.binary.i32(i32 38, i32 %4809, i32 %32)  ; IMin(a,b)
  %4812 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4810, i32 %4811, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4813 = extractvalue %dx.types.ResRet.f32 %4812, 0
  %4814 = extractvalue %dx.types.ResRet.f32 %4812, 1
  %4815 = extractvalue %dx.types.ResRet.f32 %4812, 2
  %4816 = extractvalue %dx.types.ResRet.f32 %4812, 3
  %4817 = fcmp fast olt float %4816, 0.000000e+00
  br i1 %4817, label %4818, label %4852

; <label>:4818                                    ; preds = %4807
  %4819 = fcmp fast ogt float %4813, 0x3FA4B5DCC0000000
  %4820 = fcmp fast ogt float %4814, 0x3FA4B5DCC0000000
  %4821 = fcmp fast ogt float %4815, 0x3FA4B5DCC0000000
  %4822 = select i1 %4819, float 0.000000e+00, float 1.000000e+00
  %4823 = select i1 %4820, float 0.000000e+00, float 1.000000e+00
  %4824 = select i1 %4821, float 0.000000e+00, float 1.000000e+00
  %4825 = fmul fast float %4813, 0x3FB3D07220000000
  %4826 = fmul fast float %4814, 0x3FB3D07220000000
  %4827 = fmul fast float %4815, 0x3FB3D07220000000
  %4828 = fadd fast float %4813, 0x3FAC28F5C0000000
  %4829 = fadd fast float %4814, 0x3FAC28F5C0000000
  %4830 = fadd fast float %4815, 0x3FAC28F5C0000000
  %4831 = fmul fast float %4828, 0x3FEE54EDE0000000
  %4832 = fmul fast float %4829, 0x3FEE54EDE0000000
  %4833 = fmul fast float %4830, 0x3FEE54EDE0000000
  %4834 = call float @dx.op.unary.f32(i32 23, float %4831)  ; Log(value)
  %4835 = call float @dx.op.unary.f32(i32 23, float %4832)  ; Log(value)
  %4836 = call float @dx.op.unary.f32(i32 23, float %4833)  ; Log(value)
  %4837 = fmul fast float %4834, 0x4003333340000000
  %4838 = fmul fast float %4835, 0x4003333340000000
  %4839 = fmul fast float %4836, 0x4003333340000000
  %4840 = call float @dx.op.unary.f32(i32 21, float %4837)  ; Exp(value)
  %4841 = call float @dx.op.unary.f32(i32 21, float %4838)  ; Exp(value)
  %4842 = call float @dx.op.unary.f32(i32 21, float %4839)  ; Exp(value)
  %4843 = fsub fast float %4825, %4840
  %4844 = fsub fast float %4826, %4841
  %4845 = fsub fast float %4827, %4842
  %4846 = fmul fast float %4843, %4822
  %4847 = fmul fast float %4844, %4823
  %4848 = fmul fast float %4845, %4824
  %4849 = fadd fast float %4846, %4840
  %4850 = fadd fast float %4847, %4841
  %4851 = fadd fast float %4848, %4842
  br label %4920

; <label>:4852                                    ; preds = %4807
  %4853 = fadd fast float %6, 1.000000e+00
  %4854 = fadd fast float %7, 1.000000e+00
  %4855 = fsub fast float 1.000000e+00, %6
  %4856 = fmul fast float %10, %4853
  %4857 = fmul fast float %10, %4854
  %4858 = fmul fast float %10, %4855
  %4859 = fmul fast float %4856, %4813
  %4860 = fmul fast float %4857, %4814
  %4861 = fmul fast float %4858, %4815
  %4862 = fcmp fast ult float %11, 5.000000e-01
  br i1 %4862, label %4888, label %4863

; <label>:4863                                    ; preds = %4852
  %4864 = fmul fast float %4859, 0x4004147AE0000000
  %4865 = fmul fast float %4860, 0x4004147AE0000000
  %4866 = fmul fast float %4861, 0x4004147AE0000000
  %4867 = fadd fast float %4864, 0x3F9EB851E0000000
  %4868 = fadd fast float %4865, 0x3F9EB851E0000000
  %4869 = fadd fast float %4866, 0x3F9EB851E0000000
  %4870 = fmul fast float %4867, %4859
  %4871 = fmul fast float %4868, %4860
  %4872 = fmul fast float %4869, %4861
  %4873 = fmul fast float %4859, 0x400370A3E0000000
  %4874 = fmul fast float %4860, 0x400370A3E0000000
  %4875 = fmul fast float %4861, 0x400370A3E0000000
  %4876 = fadd fast float %4873, 0x3FE2E147A0000000
  %4877 = fadd fast float %4874, 0x3FE2E147A0000000
  %4878 = fadd fast float %4875, 0x3FE2E147A0000000
  %4879 = fmul fast float %4876, %4859
  %4880 = fmul fast float %4877, %4860
  %4881 = fmul fast float %4878, %4861
  %4882 = fadd fast float %4879, 0x3FC1EB8520000000
  %4883 = fadd fast float %4880, 0x3FC1EB8520000000
  %4884 = fadd fast float %4881, 0x3FC1EB8520000000
  %4885 = fdiv fast float %4870, %4882
  %4886 = fdiv fast float %4871, %4883
  %4887 = fdiv fast float %4872, %4884
  br label %4888

; <label>:4888                                    ; preds = %4863, %4852
  %4889 = phi float [ %4885, %4863 ], [ %4859, %4852 ]
  %4890 = phi float [ %4886, %4863 ], [ %4860, %4852 ]
  %4891 = phi float [ %4887, %4863 ], [ %4861, %4852 ]
  %4892 = call float @dx.op.unary.f32(i32 7, float %4889)  ; Saturate(value)
  %4893 = call float @dx.op.unary.f32(i32 7, float %4890)  ; Saturate(value)
  %4894 = call float @dx.op.unary.f32(i32 7, float %4891)  ; Saturate(value)
  %4895 = call float @dx.op.dot3.f32(i32 55, float %4892, float %4893, float %4894, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4896 = fsub fast float %4892, %4895
  %4897 = fsub fast float %4893, %4895
  %4898 = fsub fast float %4894, %4895
  %4899 = fmul fast float %4896, %9
  %4900 = fmul fast float %4897, %9
  %4901 = fmul fast float %4898, %9
  %4902 = fadd fast float %4899, %4895
  %4903 = fadd fast float %4900, %4895
  %4904 = fadd fast float %4901, %4895
  %4905 = call float @dx.op.unary.f32(i32 7, float %4902)  ; Saturate(value)
  %4906 = call float @dx.op.unary.f32(i32 7, float %4903)  ; Saturate(value)
  %4907 = call float @dx.op.unary.f32(i32 7, float %4904)  ; Saturate(value)
  %4908 = fadd fast float %4905, 0xBFC70A3D80000000
  %4909 = fadd fast float %4906, 0xBFC70A3D80000000
  %4910 = fadd fast float %4907, 0xBFC70A3D80000000
  %4911 = fmul fast float %4908, %8
  %4912 = fmul fast float %4909, %8
  %4913 = fmul fast float %4910, %8
  %4914 = fadd fast float %4911, 0x3FC70A3D80000000
  %4915 = fadd fast float %4912, 0x3FC70A3D80000000
  %4916 = fadd fast float %4913, 0x3FC70A3D80000000
  %4917 = call float @dx.op.unary.f32(i32 7, float %4914)  ; Saturate(value)
  %4918 = call float @dx.op.unary.f32(i32 7, float %4915)  ; Saturate(value)
  %4919 = call float @dx.op.unary.f32(i32 7, float %4916)  ; Saturate(value)
  br label %4920

; <label>:4920                                    ; preds = %4888, %4818
  %4921 = phi float [ %4849, %4818 ], [ %4917, %4888 ]
  %4922 = phi float [ %4850, %4818 ], [ %4918, %4888 ]
  %4923 = phi float [ %4851, %4818 ], [ %4919, %4888 ]
  %4924 = fsub fast float %4921, %4786
  %4925 = fsub fast float %4922, %4787
  %4926 = fsub fast float %4923, %4788
  %4927 = fmul fast float %4924, %4805
  %4928 = fmul fast float %4925, %4805
  %4929 = fmul fast float %4926, %4805
  %4930 = fadd fast float %4927, %4786
  %4931 = fadd fast float %4928, %4787
  %4932 = fadd fast float %4929, %4788
  br label %4933

; <label>:4933                                    ; preds = %4920, %4790
  %4934 = phi float [ %4930, %4920 ], [ %4786, %4790 ]
  %4935 = phi float [ %4931, %4920 ], [ %4787, %4790 ]
  %4936 = phi float [ %4932, %4920 ], [ %4788, %4790 ]
  %4937 = add i32 %42, 1
  %4938 = call i32 @dx.op.binary.i32(i32 37, i32 %4937, i32 0)  ; IMax(a,b)
  %4939 = call i32 @dx.op.binary.i32(i32 38, i32 %4938, i32 %32)  ; IMin(a,b)
  %4940 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4794, i32 %4939, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4941 = extractvalue %dx.types.ResRet.f32 %4940, 0
  %4942 = fsub fast float %4941, %60
  %4943 = call float @dx.op.unary.f32(i32 6, float %4942)  ; FAbs(value)
  %4944 = fdiv fast float %4943, %4800
  %4945 = fsub fast float 1.000000e+00, %4944
  %4946 = call float @dx.op.unary.f32(i32 7, float %4945)  ; Saturate(value)
  %4947 = fcmp fast ugt float %4946, 0.000000e+00
  br i1 %4947, label %4948, label %5074

; <label>:4948                                    ; preds = %4933
  %4949 = call i32 @dx.op.binary.i32(i32 37, i32 %4794, i32 0)  ; IMax(a,b)
  %4950 = call i32 @dx.op.binary.i32(i32 37, i32 %4939, i32 0)  ; IMax(a,b)
  %4951 = call i32 @dx.op.binary.i32(i32 38, i32 %4949, i32 %31)  ; IMin(a,b)
  %4952 = call i32 @dx.op.binary.i32(i32 38, i32 %4950, i32 %32)  ; IMin(a,b)
  %4953 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4951, i32 %4952, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4954 = extractvalue %dx.types.ResRet.f32 %4953, 0
  %4955 = extractvalue %dx.types.ResRet.f32 %4953, 1
  %4956 = extractvalue %dx.types.ResRet.f32 %4953, 2
  %4957 = extractvalue %dx.types.ResRet.f32 %4953, 3
  %4958 = fcmp fast olt float %4957, 0.000000e+00
  br i1 %4958, label %4959, label %4993

; <label>:4959                                    ; preds = %4948
  %4960 = fcmp fast ogt float %4954, 0x3FA4B5DCC0000000
  %4961 = fcmp fast ogt float %4955, 0x3FA4B5DCC0000000
  %4962 = fcmp fast ogt float %4956, 0x3FA4B5DCC0000000
  %4963 = select i1 %4960, float 0.000000e+00, float 1.000000e+00
  %4964 = select i1 %4961, float 0.000000e+00, float 1.000000e+00
  %4965 = select i1 %4962, float 0.000000e+00, float 1.000000e+00
  %4966 = fmul fast float %4954, 0x3FB3D07220000000
  %4967 = fmul fast float %4955, 0x3FB3D07220000000
  %4968 = fmul fast float %4956, 0x3FB3D07220000000
  %4969 = fadd fast float %4954, 0x3FAC28F5C0000000
  %4970 = fadd fast float %4955, 0x3FAC28F5C0000000
  %4971 = fadd fast float %4956, 0x3FAC28F5C0000000
  %4972 = fmul fast float %4969, 0x3FEE54EDE0000000
  %4973 = fmul fast float %4970, 0x3FEE54EDE0000000
  %4974 = fmul fast float %4971, 0x3FEE54EDE0000000
  %4975 = call float @dx.op.unary.f32(i32 23, float %4972)  ; Log(value)
  %4976 = call float @dx.op.unary.f32(i32 23, float %4973)  ; Log(value)
  %4977 = call float @dx.op.unary.f32(i32 23, float %4974)  ; Log(value)
  %4978 = fmul fast float %4975, 0x4003333340000000
  %4979 = fmul fast float %4976, 0x4003333340000000
  %4980 = fmul fast float %4977, 0x4003333340000000
  %4981 = call float @dx.op.unary.f32(i32 21, float %4978)  ; Exp(value)
  %4982 = call float @dx.op.unary.f32(i32 21, float %4979)  ; Exp(value)
  %4983 = call float @dx.op.unary.f32(i32 21, float %4980)  ; Exp(value)
  %4984 = fsub fast float %4966, %4981
  %4985 = fsub fast float %4967, %4982
  %4986 = fsub fast float %4968, %4983
  %4987 = fmul fast float %4984, %4963
  %4988 = fmul fast float %4985, %4964
  %4989 = fmul fast float %4986, %4965
  %4990 = fadd fast float %4987, %4981
  %4991 = fadd fast float %4988, %4982
  %4992 = fadd fast float %4989, %4983
  br label %5061

; <label>:4993                                    ; preds = %4948
  %4994 = fadd fast float %6, 1.000000e+00
  %4995 = fadd fast float %7, 1.000000e+00
  %4996 = fsub fast float 1.000000e+00, %6
  %4997 = fmul fast float %10, %4994
  %4998 = fmul fast float %10, %4995
  %4999 = fmul fast float %10, %4996
  %5000 = fmul fast float %4997, %4954
  %5001 = fmul fast float %4998, %4955
  %5002 = fmul fast float %4999, %4956
  %5003 = fcmp fast ult float %11, 5.000000e-01
  br i1 %5003, label %5029, label %5004

; <label>:5004                                    ; preds = %4993
  %5005 = fmul fast float %5000, 0x4004147AE0000000
  %5006 = fmul fast float %5001, 0x4004147AE0000000
  %5007 = fmul fast float %5002, 0x4004147AE0000000
  %5008 = fadd fast float %5005, 0x3F9EB851E0000000
  %5009 = fadd fast float %5006, 0x3F9EB851E0000000
  %5010 = fadd fast float %5007, 0x3F9EB851E0000000
  %5011 = fmul fast float %5008, %5000
  %5012 = fmul fast float %5009, %5001
  %5013 = fmul fast float %5010, %5002
  %5014 = fmul fast float %5000, 0x400370A3E0000000
  %5015 = fmul fast float %5001, 0x400370A3E0000000
  %5016 = fmul fast float %5002, 0x400370A3E0000000
  %5017 = fadd fast float %5014, 0x3FE2E147A0000000
  %5018 = fadd fast float %5015, 0x3FE2E147A0000000
  %5019 = fadd fast float %5016, 0x3FE2E147A0000000
  %5020 = fmul fast float %5017, %5000
  %5021 = fmul fast float %5018, %5001
  %5022 = fmul fast float %5019, %5002
  %5023 = fadd fast float %5020, 0x3FC1EB8520000000
  %5024 = fadd fast float %5021, 0x3FC1EB8520000000
  %5025 = fadd fast float %5022, 0x3FC1EB8520000000
  %5026 = fdiv fast float %5011, %5023
  %5027 = fdiv fast float %5012, %5024
  %5028 = fdiv fast float %5013, %5025
  br label %5029

; <label>:5029                                    ; preds = %5004, %4993
  %5030 = phi float [ %5026, %5004 ], [ %5000, %4993 ]
  %5031 = phi float [ %5027, %5004 ], [ %5001, %4993 ]
  %5032 = phi float [ %5028, %5004 ], [ %5002, %4993 ]
  %5033 = call float @dx.op.unary.f32(i32 7, float %5030)  ; Saturate(value)
  %5034 = call float @dx.op.unary.f32(i32 7, float %5031)  ; Saturate(value)
  %5035 = call float @dx.op.unary.f32(i32 7, float %5032)  ; Saturate(value)
  %5036 = call float @dx.op.dot3.f32(i32 55, float %5033, float %5034, float %5035, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5037 = fsub fast float %5033, %5036
  %5038 = fsub fast float %5034, %5036
  %5039 = fsub fast float %5035, %5036
  %5040 = fmul fast float %5037, %9
  %5041 = fmul fast float %5038, %9
  %5042 = fmul fast float %5039, %9
  %5043 = fadd fast float %5040, %5036
  %5044 = fadd fast float %5041, %5036
  %5045 = fadd fast float %5042, %5036
  %5046 = call float @dx.op.unary.f32(i32 7, float %5043)  ; Saturate(value)
  %5047 = call float @dx.op.unary.f32(i32 7, float %5044)  ; Saturate(value)
  %5048 = call float @dx.op.unary.f32(i32 7, float %5045)  ; Saturate(value)
  %5049 = fadd fast float %5046, 0xBFC70A3D80000000
  %5050 = fadd fast float %5047, 0xBFC70A3D80000000
  %5051 = fadd fast float %5048, 0xBFC70A3D80000000
  %5052 = fmul fast float %5049, %8
  %5053 = fmul fast float %5050, %8
  %5054 = fmul fast float %5051, %8
  %5055 = fadd fast float %5052, 0x3FC70A3D80000000
  %5056 = fadd fast float %5053, 0x3FC70A3D80000000
  %5057 = fadd fast float %5054, 0x3FC70A3D80000000
  %5058 = call float @dx.op.unary.f32(i32 7, float %5055)  ; Saturate(value)
  %5059 = call float @dx.op.unary.f32(i32 7, float %5056)  ; Saturate(value)
  %5060 = call float @dx.op.unary.f32(i32 7, float %5057)  ; Saturate(value)
  br label %5061

; <label>:5061                                    ; preds = %5029, %4959
  %5062 = phi float [ %4990, %4959 ], [ %5058, %5029 ]
  %5063 = phi float [ %4991, %4959 ], [ %5059, %5029 ]
  %5064 = phi float [ %4992, %4959 ], [ %5060, %5029 ]
  %5065 = fsub fast float %5062, %4786
  %5066 = fsub fast float %5063, %4787
  %5067 = fsub fast float %5064, %4788
  %5068 = fmul fast float %5065, %4946
  %5069 = fmul fast float %5066, %4946
  %5070 = fmul fast float %5067, %4946
  %5071 = fadd fast float %5068, %4786
  %5072 = fadd fast float %5069, %4787
  %5073 = fadd fast float %5070, %4788
  br label %5074

; <label>:5074                                    ; preds = %5061, %4933
  %5075 = phi float [ %5071, %5061 ], [ %4786, %4933 ]
  %5076 = phi float [ %5072, %5061 ], [ %4787, %4933 ]
  %5077 = phi float [ %5073, %5061 ], [ %4788, %4933 ]
  %5078 = add i32 %39, -1
  %5079 = call i32 @dx.op.binary.i32(i32 37, i32 %5078, i32 0)  ; IMax(a,b)
  %5080 = call i32 @dx.op.binary.i32(i32 37, i32 %42, i32 0)  ; IMax(a,b)
  %5081 = call i32 @dx.op.binary.i32(i32 38, i32 %5079, i32 %31)  ; IMin(a,b)
  %5082 = call i32 @dx.op.binary.i32(i32 38, i32 %5080, i32 %32)  ; IMin(a,b)
  %5083 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5081, i32 %5082, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5084 = extractvalue %dx.types.ResRet.f32 %5083, 0
  %5085 = fsub fast float %5084, %60
  %5086 = call float @dx.op.unary.f32(i32 6, float %5085)  ; FAbs(value)
  %5087 = fdiv fast float %5086, %4800
  %5088 = fsub fast float 1.000000e+00, %5087
  %5089 = call float @dx.op.unary.f32(i32 7, float %5088)  ; Saturate(value)
  %5090 = fcmp fast ugt float %5089, 0.000000e+00
  br i1 %5090, label %5091, label %5217

; <label>:5091                                    ; preds = %5074
  %5092 = call i32 @dx.op.binary.i32(i32 37, i32 %5081, i32 0)  ; IMax(a,b)
  %5093 = call i32 @dx.op.binary.i32(i32 37, i32 %5082, i32 0)  ; IMax(a,b)
  %5094 = call i32 @dx.op.binary.i32(i32 38, i32 %5092, i32 %31)  ; IMin(a,b)
  %5095 = call i32 @dx.op.binary.i32(i32 38, i32 %5093, i32 %32)  ; IMin(a,b)
  %5096 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %5094, i32 %5095, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5097 = extractvalue %dx.types.ResRet.f32 %5096, 0
  %5098 = extractvalue %dx.types.ResRet.f32 %5096, 1
  %5099 = extractvalue %dx.types.ResRet.f32 %5096, 2
  %5100 = extractvalue %dx.types.ResRet.f32 %5096, 3
  %5101 = fcmp fast olt float %5100, 0.000000e+00
  br i1 %5101, label %5102, label %5136

; <label>:5102                                    ; preds = %5091
  %5103 = fcmp fast ogt float %5097, 0x3FA4B5DCC0000000
  %5104 = fcmp fast ogt float %5098, 0x3FA4B5DCC0000000
  %5105 = fcmp fast ogt float %5099, 0x3FA4B5DCC0000000
  %5106 = select i1 %5103, float 0.000000e+00, float 1.000000e+00
  %5107 = select i1 %5104, float 0.000000e+00, float 1.000000e+00
  %5108 = select i1 %5105, float 0.000000e+00, float 1.000000e+00
  %5109 = fmul fast float %5097, 0x3FB3D07220000000
  %5110 = fmul fast float %5098, 0x3FB3D07220000000
  %5111 = fmul fast float %5099, 0x3FB3D07220000000
  %5112 = fadd fast float %5097, 0x3FAC28F5C0000000
  %5113 = fadd fast float %5098, 0x3FAC28F5C0000000
  %5114 = fadd fast float %5099, 0x3FAC28F5C0000000
  %5115 = fmul fast float %5112, 0x3FEE54EDE0000000
  %5116 = fmul fast float %5113, 0x3FEE54EDE0000000
  %5117 = fmul fast float %5114, 0x3FEE54EDE0000000
  %5118 = call float @dx.op.unary.f32(i32 23, float %5115)  ; Log(value)
  %5119 = call float @dx.op.unary.f32(i32 23, float %5116)  ; Log(value)
  %5120 = call float @dx.op.unary.f32(i32 23, float %5117)  ; Log(value)
  %5121 = fmul fast float %5118, 0x4003333340000000
  %5122 = fmul fast float %5119, 0x4003333340000000
  %5123 = fmul fast float %5120, 0x4003333340000000
  %5124 = call float @dx.op.unary.f32(i32 21, float %5121)  ; Exp(value)
  %5125 = call float @dx.op.unary.f32(i32 21, float %5122)  ; Exp(value)
  %5126 = call float @dx.op.unary.f32(i32 21, float %5123)  ; Exp(value)
  %5127 = fsub fast float %5109, %5124
  %5128 = fsub fast float %5110, %5125
  %5129 = fsub fast float %5111, %5126
  %5130 = fmul fast float %5127, %5106
  %5131 = fmul fast float %5128, %5107
  %5132 = fmul fast float %5129, %5108
  %5133 = fadd fast float %5130, %5124
  %5134 = fadd fast float %5131, %5125
  %5135 = fadd fast float %5132, %5126
  br label %5204

; <label>:5136                                    ; preds = %5091
  %5137 = fadd fast float %6, 1.000000e+00
  %5138 = fadd fast float %7, 1.000000e+00
  %5139 = fsub fast float 1.000000e+00, %6
  %5140 = fmul fast float %10, %5137
  %5141 = fmul fast float %10, %5138
  %5142 = fmul fast float %10, %5139
  %5143 = fmul fast float %5140, %5097
  %5144 = fmul fast float %5141, %5098
  %5145 = fmul fast float %5142, %5099
  %5146 = fcmp fast ult float %11, 5.000000e-01
  br i1 %5146, label %5172, label %5147

; <label>:5147                                    ; preds = %5136
  %5148 = fmul fast float %5143, 0x4004147AE0000000
  %5149 = fmul fast float %5144, 0x4004147AE0000000
  %5150 = fmul fast float %5145, 0x4004147AE0000000
  %5151 = fadd fast float %5148, 0x3F9EB851E0000000
  %5152 = fadd fast float %5149, 0x3F9EB851E0000000
  %5153 = fadd fast float %5150, 0x3F9EB851E0000000
  %5154 = fmul fast float %5151, %5143
  %5155 = fmul fast float %5152, %5144
  %5156 = fmul fast float %5153, %5145
  %5157 = fmul fast float %5143, 0x400370A3E0000000
  %5158 = fmul fast float %5144, 0x400370A3E0000000
  %5159 = fmul fast float %5145, 0x400370A3E0000000
  %5160 = fadd fast float %5157, 0x3FE2E147A0000000
  %5161 = fadd fast float %5158, 0x3FE2E147A0000000
  %5162 = fadd fast float %5159, 0x3FE2E147A0000000
  %5163 = fmul fast float %5160, %5143
  %5164 = fmul fast float %5161, %5144
  %5165 = fmul fast float %5162, %5145
  %5166 = fadd fast float %5163, 0x3FC1EB8520000000
  %5167 = fadd fast float %5164, 0x3FC1EB8520000000
  %5168 = fadd fast float %5165, 0x3FC1EB8520000000
  %5169 = fdiv fast float %5154, %5166
  %5170 = fdiv fast float %5155, %5167
  %5171 = fdiv fast float %5156, %5168
  br label %5172

; <label>:5172                                    ; preds = %5147, %5136
  %5173 = phi float [ %5169, %5147 ], [ %5143, %5136 ]
  %5174 = phi float [ %5170, %5147 ], [ %5144, %5136 ]
  %5175 = phi float [ %5171, %5147 ], [ %5145, %5136 ]
  %5176 = call float @dx.op.unary.f32(i32 7, float %5173)  ; Saturate(value)
  %5177 = call float @dx.op.unary.f32(i32 7, float %5174)  ; Saturate(value)
  %5178 = call float @dx.op.unary.f32(i32 7, float %5175)  ; Saturate(value)
  %5179 = call float @dx.op.dot3.f32(i32 55, float %5176, float %5177, float %5178, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5180 = fsub fast float %5176, %5179
  %5181 = fsub fast float %5177, %5179
  %5182 = fsub fast float %5178, %5179
  %5183 = fmul fast float %5180, %9
  %5184 = fmul fast float %5181, %9
  %5185 = fmul fast float %5182, %9
  %5186 = fadd fast float %5183, %5179
  %5187 = fadd fast float %5184, %5179
  %5188 = fadd fast float %5185, %5179
  %5189 = call float @dx.op.unary.f32(i32 7, float %5186)  ; Saturate(value)
  %5190 = call float @dx.op.unary.f32(i32 7, float %5187)  ; Saturate(value)
  %5191 = call float @dx.op.unary.f32(i32 7, float %5188)  ; Saturate(value)
  %5192 = fadd fast float %5189, 0xBFC70A3D80000000
  %5193 = fadd fast float %5190, 0xBFC70A3D80000000
  %5194 = fadd fast float %5191, 0xBFC70A3D80000000
  %5195 = fmul fast float %5192, %8
  %5196 = fmul fast float %5193, %8
  %5197 = fmul fast float %5194, %8
  %5198 = fadd fast float %5195, 0x3FC70A3D80000000
  %5199 = fadd fast float %5196, 0x3FC70A3D80000000
  %5200 = fadd fast float %5197, 0x3FC70A3D80000000
  %5201 = call float @dx.op.unary.f32(i32 7, float %5198)  ; Saturate(value)
  %5202 = call float @dx.op.unary.f32(i32 7, float %5199)  ; Saturate(value)
  %5203 = call float @dx.op.unary.f32(i32 7, float %5200)  ; Saturate(value)
  br label %5204

; <label>:5204                                    ; preds = %5172, %5102
  %5205 = phi float [ %5133, %5102 ], [ %5201, %5172 ]
  %5206 = phi float [ %5134, %5102 ], [ %5202, %5172 ]
  %5207 = phi float [ %5135, %5102 ], [ %5203, %5172 ]
  %5208 = fsub fast float %5205, %4786
  %5209 = fsub fast float %5206, %4787
  %5210 = fsub fast float %5207, %4788
  %5211 = fmul fast float %5208, %5089
  %5212 = fmul fast float %5209, %5089
  %5213 = fmul fast float %5210, %5089
  %5214 = fadd fast float %5211, %4786
  %5215 = fadd fast float %5212, %4787
  %5216 = fadd fast float %5213, %4788
  br label %5217

; <label>:5217                                    ; preds = %5204, %5074
  %5218 = phi float [ %5214, %5204 ], [ %4786, %5074 ]
  %5219 = phi float [ %5215, %5204 ], [ %4787, %5074 ]
  %5220 = phi float [ %5216, %5204 ], [ %4788, %5074 ]
  %5221 = add i32 %39, 1
  %5222 = call i32 @dx.op.binary.i32(i32 37, i32 %5221, i32 0)  ; IMax(a,b)
  %5223 = call i32 @dx.op.binary.i32(i32 38, i32 %5222, i32 %31)  ; IMin(a,b)
  %5224 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5223, i32 %5082, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5225 = extractvalue %dx.types.ResRet.f32 %5224, 0
  %5226 = fsub fast float %5225, %60
  %5227 = call float @dx.op.unary.f32(i32 6, float %5226)  ; FAbs(value)
  %5228 = fdiv fast float %5227, %4800
  %5229 = fsub fast float 1.000000e+00, %5228
  %5230 = call float @dx.op.unary.f32(i32 7, float %5229)  ; Saturate(value)
  %5231 = fcmp fast ugt float %5230, 0.000000e+00
  br i1 %5231, label %5232, label %5358

; <label>:5232                                    ; preds = %5217
  %5233 = call i32 @dx.op.binary.i32(i32 37, i32 %5223, i32 0)  ; IMax(a,b)
  %5234 = call i32 @dx.op.binary.i32(i32 37, i32 %5082, i32 0)  ; IMax(a,b)
  %5235 = call i32 @dx.op.binary.i32(i32 38, i32 %5233, i32 %31)  ; IMin(a,b)
  %5236 = call i32 @dx.op.binary.i32(i32 38, i32 %5234, i32 %32)  ; IMin(a,b)
  %5237 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %5235, i32 %5236, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5238 = extractvalue %dx.types.ResRet.f32 %5237, 0
  %5239 = extractvalue %dx.types.ResRet.f32 %5237, 1
  %5240 = extractvalue %dx.types.ResRet.f32 %5237, 2
  %5241 = extractvalue %dx.types.ResRet.f32 %5237, 3
  %5242 = fcmp fast olt float %5241, 0.000000e+00
  br i1 %5242, label %5243, label %5277

; <label>:5243                                    ; preds = %5232
  %5244 = fcmp fast ogt float %5238, 0x3FA4B5DCC0000000
  %5245 = fcmp fast ogt float %5239, 0x3FA4B5DCC0000000
  %5246 = fcmp fast ogt float %5240, 0x3FA4B5DCC0000000
  %5247 = select i1 %5244, float 0.000000e+00, float 1.000000e+00
  %5248 = select i1 %5245, float 0.000000e+00, float 1.000000e+00
  %5249 = select i1 %5246, float 0.000000e+00, float 1.000000e+00
  %5250 = fmul fast float %5238, 0x3FB3D07220000000
  %5251 = fmul fast float %5239, 0x3FB3D07220000000
  %5252 = fmul fast float %5240, 0x3FB3D07220000000
  %5253 = fadd fast float %5238, 0x3FAC28F5C0000000
  %5254 = fadd fast float %5239, 0x3FAC28F5C0000000
  %5255 = fadd fast float %5240, 0x3FAC28F5C0000000
  %5256 = fmul fast float %5253, 0x3FEE54EDE0000000
  %5257 = fmul fast float %5254, 0x3FEE54EDE0000000
  %5258 = fmul fast float %5255, 0x3FEE54EDE0000000
  %5259 = call float @dx.op.unary.f32(i32 23, float %5256)  ; Log(value)
  %5260 = call float @dx.op.unary.f32(i32 23, float %5257)  ; Log(value)
  %5261 = call float @dx.op.unary.f32(i32 23, float %5258)  ; Log(value)
  %5262 = fmul fast float %5259, 0x4003333340000000
  %5263 = fmul fast float %5260, 0x4003333340000000
  %5264 = fmul fast float %5261, 0x4003333340000000
  %5265 = call float @dx.op.unary.f32(i32 21, float %5262)  ; Exp(value)
  %5266 = call float @dx.op.unary.f32(i32 21, float %5263)  ; Exp(value)
  %5267 = call float @dx.op.unary.f32(i32 21, float %5264)  ; Exp(value)
  %5268 = fsub fast float %5250, %5265
  %5269 = fsub fast float %5251, %5266
  %5270 = fsub fast float %5252, %5267
  %5271 = fmul fast float %5268, %5247
  %5272 = fmul fast float %5269, %5248
  %5273 = fmul fast float %5270, %5249
  %5274 = fadd fast float %5271, %5265
  %5275 = fadd fast float %5272, %5266
  %5276 = fadd fast float %5273, %5267
  br label %5345

; <label>:5277                                    ; preds = %5232
  %5278 = fadd fast float %6, 1.000000e+00
  %5279 = fadd fast float %7, 1.000000e+00
  %5280 = fsub fast float 1.000000e+00, %6
  %5281 = fmul fast float %10, %5278
  %5282 = fmul fast float %10, %5279
  %5283 = fmul fast float %10, %5280
  %5284 = fmul fast float %5281, %5238
  %5285 = fmul fast float %5282, %5239
  %5286 = fmul fast float %5283, %5240
  %5287 = fcmp fast ult float %11, 5.000000e-01
  br i1 %5287, label %5313, label %5288

; <label>:5288                                    ; preds = %5277
  %5289 = fmul fast float %5284, 0x4004147AE0000000
  %5290 = fmul fast float %5285, 0x4004147AE0000000
  %5291 = fmul fast float %5286, 0x4004147AE0000000
  %5292 = fadd fast float %5289, 0x3F9EB851E0000000
  %5293 = fadd fast float %5290, 0x3F9EB851E0000000
  %5294 = fadd fast float %5291, 0x3F9EB851E0000000
  %5295 = fmul fast float %5292, %5284
  %5296 = fmul fast float %5293, %5285
  %5297 = fmul fast float %5294, %5286
  %5298 = fmul fast float %5284, 0x400370A3E0000000
  %5299 = fmul fast float %5285, 0x400370A3E0000000
  %5300 = fmul fast float %5286, 0x400370A3E0000000
  %5301 = fadd fast float %5298, 0x3FE2E147A0000000
  %5302 = fadd fast float %5299, 0x3FE2E147A0000000
  %5303 = fadd fast float %5300, 0x3FE2E147A0000000
  %5304 = fmul fast float %5301, %5284
  %5305 = fmul fast float %5302, %5285
  %5306 = fmul fast float %5303, %5286
  %5307 = fadd fast float %5304, 0x3FC1EB8520000000
  %5308 = fadd fast float %5305, 0x3FC1EB8520000000
  %5309 = fadd fast float %5306, 0x3FC1EB8520000000
  %5310 = fdiv fast float %5295, %5307
  %5311 = fdiv fast float %5296, %5308
  %5312 = fdiv fast float %5297, %5309
  br label %5313

; <label>:5313                                    ; preds = %5288, %5277
  %5314 = phi float [ %5310, %5288 ], [ %5284, %5277 ]
  %5315 = phi float [ %5311, %5288 ], [ %5285, %5277 ]
  %5316 = phi float [ %5312, %5288 ], [ %5286, %5277 ]
  %5317 = call float @dx.op.unary.f32(i32 7, float %5314)  ; Saturate(value)
  %5318 = call float @dx.op.unary.f32(i32 7, float %5315)  ; Saturate(value)
  %5319 = call float @dx.op.unary.f32(i32 7, float %5316)  ; Saturate(value)
  %5320 = call float @dx.op.dot3.f32(i32 55, float %5317, float %5318, float %5319, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5321 = fsub fast float %5317, %5320
  %5322 = fsub fast float %5318, %5320
  %5323 = fsub fast float %5319, %5320
  %5324 = fmul fast float %5321, %9
  %5325 = fmul fast float %5322, %9
  %5326 = fmul fast float %5323, %9
  %5327 = fadd fast float %5324, %5320
  %5328 = fadd fast float %5325, %5320
  %5329 = fadd fast float %5326, %5320
  %5330 = call float @dx.op.unary.f32(i32 7, float %5327)  ; Saturate(value)
  %5331 = call float @dx.op.unary.f32(i32 7, float %5328)  ; Saturate(value)
  %5332 = call float @dx.op.unary.f32(i32 7, float %5329)  ; Saturate(value)
  %5333 = fadd fast float %5330, 0xBFC70A3D80000000
  %5334 = fadd fast float %5331, 0xBFC70A3D80000000
  %5335 = fadd fast float %5332, 0xBFC70A3D80000000
  %5336 = fmul fast float %5333, %8
  %5337 = fmul fast float %5334, %8
  %5338 = fmul fast float %5335, %8
  %5339 = fadd fast float %5336, 0x3FC70A3D80000000
  %5340 = fadd fast float %5337, 0x3FC70A3D80000000
  %5341 = fadd fast float %5338, 0x3FC70A3D80000000
  %5342 = call float @dx.op.unary.f32(i32 7, float %5339)  ; Saturate(value)
  %5343 = call float @dx.op.unary.f32(i32 7, float %5340)  ; Saturate(value)
  %5344 = call float @dx.op.unary.f32(i32 7, float %5341)  ; Saturate(value)
  br label %5345

; <label>:5345                                    ; preds = %5313, %5243
  %5346 = phi float [ %5274, %5243 ], [ %5342, %5313 ]
  %5347 = phi float [ %5275, %5243 ], [ %5343, %5313 ]
  %5348 = phi float [ %5276, %5243 ], [ %5344, %5313 ]
  %5349 = fsub fast float %5346, %4786
  %5350 = fsub fast float %5347, %4787
  %5351 = fsub fast float %5348, %4788
  %5352 = fmul fast float %5349, %5230
  %5353 = fmul fast float %5350, %5230
  %5354 = fmul fast float %5351, %5230
  %5355 = fadd fast float %5352, %4786
  %5356 = fadd fast float %5353, %4787
  %5357 = fadd fast float %5354, %4788
  br label %5358

; <label>:5358                                    ; preds = %5345, %5217
  %5359 = phi float [ %5355, %5345 ], [ %4786, %5217 ]
  %5360 = phi float [ %5356, %5345 ], [ %4787, %5217 ]
  %5361 = phi float [ %5357, %5345 ], [ %4788, %5217 ]
  %5362 = call float @dx.op.binary.f32(i32 36, float %5218, float %5359)  ; FMin(a,b)
  %5363 = call float @dx.op.binary.f32(i32 36, float %5219, float %5360)  ; FMin(a,b)
  %5364 = call float @dx.op.binary.f32(i32 36, float %5220, float %5361)  ; FMin(a,b)
  %5365 = call float @dx.op.binary.f32(i32 36, float %4934, float %5075)  ; FMin(a,b)
  %5366 = call float @dx.op.binary.f32(i32 36, float %4935, float %5076)  ; FMin(a,b)
  %5367 = call float @dx.op.binary.f32(i32 36, float %4936, float %5077)  ; FMin(a,b)
  %5368 = call float @dx.op.binary.f32(i32 36, float %5365, float %5362)  ; FMin(a,b)
  %5369 = call float @dx.op.binary.f32(i32 36, float %5366, float %5363)  ; FMin(a,b)
  %5370 = call float @dx.op.binary.f32(i32 36, float %5367, float %5364)  ; FMin(a,b)
  %5371 = call float @dx.op.binary.f32(i32 36, float %4786, float %5368)  ; FMin(a,b)
  %5372 = call float @dx.op.binary.f32(i32 36, float %4787, float %5369)  ; FMin(a,b)
  %5373 = call float @dx.op.binary.f32(i32 36, float %4788, float %5370)  ; FMin(a,b)
  %5374 = call float @dx.op.binary.f32(i32 35, float %5218, float %5359)  ; FMax(a,b)
  %5375 = call float @dx.op.binary.f32(i32 35, float %5219, float %5360)  ; FMax(a,b)
  %5376 = call float @dx.op.binary.f32(i32 35, float %5220, float %5361)  ; FMax(a,b)
  %5377 = call float @dx.op.binary.f32(i32 35, float %4934, float %5075)  ; FMax(a,b)
  %5378 = call float @dx.op.binary.f32(i32 35, float %4935, float %5076)  ; FMax(a,b)
  %5379 = call float @dx.op.binary.f32(i32 35, float %4936, float %5077)  ; FMax(a,b)
  %5380 = call float @dx.op.binary.f32(i32 35, float %5377, float %5374)  ; FMax(a,b)
  %5381 = call float @dx.op.binary.f32(i32 35, float %5378, float %5375)  ; FMax(a,b)
  %5382 = call float @dx.op.binary.f32(i32 35, float %5379, float %5376)  ; FMax(a,b)
  %5383 = call float @dx.op.binary.f32(i32 35, float %4786, float %5380)  ; FMax(a,b)
  %5384 = call float @dx.op.binary.f32(i32 35, float %4787, float %5381)  ; FMax(a,b)
  %5385 = call float @dx.op.binary.f32(i32 35, float %4788, float %5382)  ; FMax(a,b)
  %5386 = fsub fast float %5383, %5371
  %5387 = fsub fast float %5384, %5372
  %5388 = fsub fast float %5385, %5373
  %5389 = call float @dx.op.unary.f32(i32 6, float %5386)  ; FAbs(value)
  %5390 = call float @dx.op.unary.f32(i32 6, float %5387)  ; FAbs(value)
  %5391 = call float @dx.op.unary.f32(i32 6, float %5388)  ; FAbs(value)
  %5392 = call float @dx.op.binary.f32(i32 35, float %5390, float %5391)  ; FMax(a,b)
  %5393 = call float @dx.op.binary.f32(i32 35, float %5389, float %5392)  ; FMax(a,b)
  %5394 = call float @dx.op.binary.f32(i32 35, float %5384, float %5385)  ; FMax(a,b)
  %5395 = call float @dx.op.binary.f32(i32 35, float %5383, float %5394)  ; FMax(a,b)
  %5396 = fmul fast float %5395, 1.250000e-01
  %5397 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %5396)  ; FMax(a,b)
  %5398 = fcmp fast ogt float %5393, %5397
  br i1 %5398, label %5399, label %5461

; <label>:5399                                    ; preds = %5358
  %5400 = fsub fast float %4934, %5075
  %5401 = fsub fast float %4935, %5076
  %5402 = fsub fast float %4936, %5077
  %5403 = call float @dx.op.unary.f32(i32 6, float %5400)  ; FAbs(value)
  %5404 = call float @dx.op.unary.f32(i32 6, float %5401)  ; FAbs(value)
  %5405 = call float @dx.op.unary.f32(i32 6, float %5402)  ; FAbs(value)
  %5406 = call float @dx.op.binary.f32(i32 35, float %5404, float %5405)  ; FMax(a,b)
  %5407 = call float @dx.op.binary.f32(i32 35, float %5403, float %5406)  ; FMax(a,b)
  %5408 = fsub fast float %5218, %5359
  %5409 = fsub fast float %5219, %5360
  %5410 = fsub fast float %5220, %5361
  %5411 = call float @dx.op.unary.f32(i32 6, float %5408)  ; FAbs(value)
  %5412 = call float @dx.op.unary.f32(i32 6, float %5409)  ; FAbs(value)
  %5413 = call float @dx.op.unary.f32(i32 6, float %5410)  ; FAbs(value)
  %5414 = call float @dx.op.binary.f32(i32 35, float %5412, float %5413)  ; FMax(a,b)
  %5415 = call float @dx.op.binary.f32(i32 35, float %5411, float %5414)  ; FMax(a,b)
  %5416 = fcmp fast olt float %5407, %5415
  %5417 = select i1 %5416, float %4934, float %5218
  %5418 = select i1 %5416, float %4935, float %5219
  %5419 = select i1 %5416, float %4936, float %5220
  %5420 = select i1 %5416, float %5075, float %5359
  %5421 = select i1 %5416, float %5076, float %5360
  %5422 = select i1 %5416, float %5077, float %5361
  %5423 = fsub fast float %4786, %5420
  %5424 = fsub fast float %4787, %5421
  %5425 = fsub fast float %4788, %5422
  %5426 = fsub fast float %4786, %5417
  %5427 = fsub fast float %4787, %5418
  %5428 = fsub fast float %4788, %5419
  %5429 = call float @dx.op.dot3.f32(i32 55, float %5426, float %5427, float %5428, float %5423, float %5424, float %5425)  ; Dot3(ax,ay,az,bx,by,bz)
  %5430 = fcmp fast ogt float %5429, 0.000000e+00
  br i1 %5430, label %5431, label %5443

; <label>:5431                                    ; preds = %5399
  %5432 = fsub fast float %5417, %5420
  %5433 = fsub fast float %5418, %5421
  %5434 = fsub fast float %5419, %5422
  %5435 = call float @dx.op.unary.f32(i32 6, float %5432)  ; FAbs(value)
  %5436 = call float @dx.op.unary.f32(i32 6, float %5433)  ; FAbs(value)
  %5437 = call float @dx.op.unary.f32(i32 6, float %5434)  ; FAbs(value)
  %5438 = call float @dx.op.binary.f32(i32 35, float %5436, float %5437)  ; FMax(a,b)
  %5439 = call float @dx.op.binary.f32(i32 35, float %5435, float %5438)  ; FMax(a,b)
  %5440 = fmul fast float %5393, 2.500000e-01
  %5441 = fcmp fast olt float %5439, %5440
  %5442 = select i1 %5441, float 5.000000e-01, float 1.000000e+00
  br label %5443

; <label>:5443                                    ; preds = %5431, %5399
  %5444 = phi float [ 1.000000e+00, %5399 ], [ %5442, %5431 ]
  %5445 = fmul fast float %5444, %3
  %5446 = fadd fast float %5417, %5420
  %5447 = fadd fast float %5418, %5421
  %5448 = fadd fast float %5419, %5422
  %5449 = fmul fast float %5446, 5.000000e-01
  %5450 = fmul fast float %5447, 5.000000e-01
  %5451 = fmul fast float %5448, 5.000000e-01
  %5452 = fsub fast float %5449, %4786
  %5453 = fsub fast float %5450, %4787
  %5454 = fsub fast float %5451, %4788
  %5455 = fmul fast float %5445, %5452
  %5456 = fmul fast float %5445, %5453
  %5457 = fmul fast float %5445, %5454
  %5458 = fadd fast float %5455, %4786
  %5459 = fadd fast float %5456, %4787
  %5460 = fadd fast float %5457, %4788
  br label %5461

; <label>:5461                                    ; preds = %5443, %5358, %4757, %4686, %2303, %2218, %1891, %591
  %5462 = phi float [ %271, %591 ], [ %1032, %1891 ], [ %3104, %4686 ], [ %1032, %2303 ], [ %1032, %2218 ], [ %3104, %5358 ], [ %3104, %5443 ], [ %3104, %4757 ]
  %5463 = phi float [ %272, %591 ], [ %1033, %1891 ], [ %3105, %4686 ], [ %1033, %2303 ], [ %1033, %2218 ], [ %3105, %5358 ], [ %3105, %5443 ], [ %3105, %4757 ]
  %5464 = phi float [ %273, %591 ], [ %1034, %1891 ], [ %3106, %4686 ], [ %1034, %2303 ], [ %1034, %2218 ], [ %3106, %5358 ], [ %3106, %5443 ], [ %3106, %4757 ]
  %5465 = phi float [ %596, %591 ], [ %596, %1891 ], [ %3107, %4686 ], [ %596, %2303 ], [ %596, %2218 ], [ %3107, %5358 ], [ %3107, %5443 ], [ %3107, %4757 ]
  %5466 = phi float [ %378, %591 ], [ %1462, %1891 ], [ %3890, %4686 ], [ %1462, %2303 ], [ %1462, %2218 ], [ %3890, %5358 ], [ %3890, %5443 ], [ %3890, %4757 ]
  %5467 = phi float [ %379, %591 ], [ %1463, %1891 ], [ %3891, %4686 ], [ %1463, %2303 ], [ %1463, %2218 ], [ %3891, %5358 ], [ %3891, %5443 ], [ %3891, %4757 ]
  %5468 = phi float [ %380, %591 ], [ %1464, %1891 ], [ %3892, %4686 ], [ %1464, %2303 ], [ %1464, %2218 ], [ %3892, %5358 ], [ %3892, %5443 ], [ %3892, %4757 ]
  %5469 = phi float [ %598, %591 ], [ %598, %1891 ], [ %3893, %4686 ], [ %598, %2303 ], [ %598, %2218 ], [ %3893, %5358 ], [ %3893, %5443 ], [ %3893, %4757 ]
  %5470 = phi float [ %485, %591 ], [ %1892, %1891 ], [ %4676, %4686 ], [ %1892, %2303 ], [ %1892, %2218 ], [ %4676, %5358 ], [ %4676, %5443 ], [ %4676, %4757 ]
  %5471 = phi float [ %486, %591 ], [ %1893, %1891 ], [ %4677, %4686 ], [ %1893, %2303 ], [ %1893, %2218 ], [ %4677, %5358 ], [ %4677, %5443 ], [ %4677, %4757 ]
  %5472 = phi float [ %487, %591 ], [ %1894, %1891 ], [ %4678, %4686 ], [ %1894, %2303 ], [ %1894, %2218 ], [ %4678, %5358 ], [ %4678, %5443 ], [ %4678, %4757 ]
  %5473 = phi float [ %600, %591 ], [ %600, %1891 ], [ %4679, %4686 ], [ %600, %2303 ], [ %600, %2218 ], [ %4679, %5358 ], [ %4679, %5443 ], [ %4679, %4757 ]
  %5474 = phi float [ %592, %591 ], [ %592, %1891 ], [ %4717, %4686 ], [ %2318, %2303 ], [ %592, %2218 ], [ %4786, %5358 ], [ %5458, %5443 ], [ %4786, %4757 ]
  %5475 = phi float [ %593, %591 ], [ %593, %1891 ], [ %4718, %4686 ], [ %2319, %2303 ], [ %593, %2218 ], [ %4787, %5358 ], [ %5459, %5443 ], [ %4787, %4757 ]
  %5476 = phi float [ %594, %591 ], [ %594, %1891 ], [ %4719, %4686 ], [ %2320, %2303 ], [ %594, %2218 ], [ %4788, %5358 ], [ %5460, %5443 ], [ %4788, %4757 ]
  %5477 = phi float [ %602, %591 ], [ %602, %1891 ], [ %4720, %4686 ], [ %602, %2303 ], [ %602, %2218 ], [ %4684, %5358 ], [ %4684, %5443 ], [ %4684, %4757 ]
  %5478 = fmul fast float %5462, %134
  %5479 = fmul fast float %5463, %134
  %5480 = fmul fast float %5464, %134
  %5481 = fmul fast float %5466, %135
  %5482 = fmul fast float %5467, %135
  %5483 = fmul fast float %5468, %135
  %5484 = fadd fast float %5481, %5478
  %5485 = fadd fast float %5482, %5479
  %5486 = fadd fast float %5483, %5480
  %5487 = fmul fast float %5470, %136
  %5488 = fmul fast float %5471, %136
  %5489 = fmul fast float %5472, %136
  %5490 = fadd fast float %5484, %5487
  %5491 = fadd fast float %5485, %5488
  %5492 = fadd fast float %5486, %5489
  %5493 = fmul fast float %5474, %137
  %5494 = fmul fast float %5475, %137
  %5495 = fmul fast float %5476, %137
  %5496 = fadd fast float %5490, %5493
  %5497 = fadd fast float %5491, %5494
  %5498 = fadd fast float %5492, %5495
  %5499 = fcmp fast ogt float %5496, 0x3F69A5C380000000
  %5500 = fcmp fast ogt float %5497, 0x3F69A5C380000000
  %5501 = fcmp fast ogt float %5498, 0x3F69A5C380000000
  %5502 = select i1 %5499, float 0.000000e+00, float 1.000000e+00
  %5503 = select i1 %5500, float 0.000000e+00, float 1.000000e+00
  %5504 = select i1 %5501, float 0.000000e+00, float 1.000000e+00
  %5505 = fmul fast float %5496, 0x4029D70A40000000
  %5506 = fmul fast float %5497, 0x4029D70A40000000
  %5507 = fmul fast float %5498, 0x4029D70A40000000
  %5508 = call float @dx.op.binary.f32(i32 35, float %5496, float 0.000000e+00)  ; FMax(a,b)
  %5509 = call float @dx.op.binary.f32(i32 35, float %5497, float 0.000000e+00)  ; FMax(a,b)
  %5510 = call float @dx.op.binary.f32(i32 35, float %5498, float 0.000000e+00)  ; FMax(a,b)
  %5511 = call float @dx.op.unary.f32(i32 23, float %5508)  ; Log(value)
  %5512 = call float @dx.op.unary.f32(i32 23, float %5509)  ; Log(value)
  %5513 = call float @dx.op.unary.f32(i32 23, float %5510)  ; Log(value)
  %5514 = fmul fast float %5511, 0x3FDAAAAAA0000000
  %5515 = fmul fast float %5512, 0x3FDAAAAAA0000000
  %5516 = fmul fast float %5513, 0x3FDAAAAAA0000000
  %5517 = call float @dx.op.unary.f32(i32 21, float %5514)  ; Exp(value)
  %5518 = call float @dx.op.unary.f32(i32 21, float %5515)  ; Exp(value)
  %5519 = call float @dx.op.unary.f32(i32 21, float %5516)  ; Exp(value)
  %5520 = fmul fast float %5517, 0x3FF0E147A0000000
  %5521 = fmul fast float %5518, 0x3FF0E147A0000000
  %5522 = fmul fast float %5519, 0x3FF0E147A0000000
  %5523 = fadd fast float %5520, 0xBFAC28F5C0000000
  %5524 = fadd fast float %5521, 0xBFAC28F5C0000000
  %5525 = fadd fast float %5522, 0xBFAC28F5C0000000
  %5526 = fsub fast float %5505, %5523
  %5527 = fsub fast float %5506, %5524
  %5528 = fsub fast float %5507, %5525
  %5529 = fmul fast float %5526, %5502
  %5530 = fmul fast float %5527, %5503
  %5531 = fmul fast float %5528, %5504
  %5532 = fadd fast float %5529, %5523
  %5533 = fadd fast float %5530, %5524
  %5534 = fadd fast float %5531, %5525
  %5535 = call float @dx.op.dot4.f32(i32 56, float %5465, float %5469, float %5473, float %5477, float %134, float %135, float %136, float %137)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %5532)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %5533)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %5534)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %5535)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %52)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare i1 @dx.op.isSpecialFloat.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !37, null}
!12 = !{!13, !16, !17, !19, !21, !23, !25, !27, !29, !31, !34}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !15}
!17 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !18, i8 1, i32 1, i8 4, i32 2, i8 0, null}
!18 = !{i32 1}
!19 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !20, i8 1, i32 1, i8 4, i32 3, i8 0, null}
!20 = !{i32 2}
!21 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !22, i8 1, i32 1, i8 4, i32 4, i8 0, null}
!22 = !{i32 3}
!23 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !24, i8 1, i32 1, i8 4, i32 5, i8 0, null}
!24 = !{i32 4}
!25 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !26, i8 1, i32 1, i8 4, i32 6, i8 0, null}
!26 = !{i32 5}
!27 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !28, i8 1, i32 1, i8 4, i32 7, i8 0, null}
!28 = !{i32 6}
!29 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 8, i8 0, null}
!30 = !{i32 7}
!31 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 9, i8 0, !33}
!32 = !{i32 8}
!33 = !{i32 3, i32 15}
!34 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !35, i8 1, i32 1, i8 4, i32 10, i8 0, !36}
!35 = !{i32 9}
!36 = !{i32 3, i32 7}
!37 = !{!38, !39}
!38 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !33}
!39 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !40}
!40 = !{i32 3, i32 1}
