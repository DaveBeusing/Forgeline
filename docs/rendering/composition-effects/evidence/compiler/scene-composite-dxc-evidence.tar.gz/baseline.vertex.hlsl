struct Output {
    float4 Position : SV_Position;
    nointerpolation float4 Settings : TEXCOORD0;
    nointerpolation float4 R0 : TEXCOORD1;
    nointerpolation float4 R1 : TEXCOORD2;
    nointerpolation float4 R2 : TEXCOORD3;
    nointerpolation float4 R3 : TEXCOORD4;
    nointerpolation float4 Camera : TEXCOORD5;
    nointerpolation float4 ColorDensity : TEXCOORD6;
    nointerpolation float4 Fog : TEXCOORD7;
    nointerpolation float4 Grade : TEXCOORD8;
    nointerpolation float4 Post : TEXCOORD9;
};cbuffer Constants : register(b0) {
    float4 Settings; float4 R0; float4 R1; float4 R2; float4 R3;
    float4 Camera; float4 ColorDensity; float4 Fog; float4 Grade; float4 Post;
};
Output VSMain(uint id : SV_VertexID) {
    Output o; float2 uv = float2((id << 1) & 2, id & 2);
    o.Position = float4(uv * float2(2,-2) + float2(-1,1), 0, 1);
    o.Settings=Settings; o.R0=R0; o.R1=R1; o.R2=R2; o.R3=R3;
    o.Camera=Camera; o.ColorDensity=ColorDensity; o.Fog=Fog; o.Grade=Grade; o.Post=Post; return o;
}