;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xy  
; TEXCOORD                 1   xyzw        2     NONE   float       
; TEXCOORD                 2   xyzw        3     NONE   float       
; TEXCOORD                 3   xyzw        4     NONE   float       
; TEXCOORD                 4   xyzw        5     NONE   float       
; TEXCOORD                 5   xyzw        6     NONE   float       
; TEXCOORD                 6   xyzw        7     NONE   float       
; TEXCOORD                 7   xyzw        8     NONE   float       
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float   xyz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: d761b7d05d4241cbea7a3dac8cca9e61
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 40, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 40, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 40, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %15 = extractvalue %dx.types.Dimensions %14, 0
  %16 = extractvalue %dx.types.Dimensions %14, 1
  %17 = uitofp i32 %15 to float
  %18 = uitofp i32 %16 to float
  %19 = fmul fast float %17, %12
  %20 = fmul fast float %18, %13
  %21 = fdiv fast float %19, %4
  %22 = fdiv fast float %20, %5
  %23 = fadd fast float %21, -5.000000e-01
  %24 = fadd fast float %22, -5.000000e-01
  %25 = call float @dx.op.unary.f32(i32 27, float %23)  ; Round_ni(value)
  %26 = call float @dx.op.unary.f32(i32 27, float %24)  ; Round_ni(value)
  %27 = fptosi float %25 to i32
  %28 = fptosi float %26 to i32
  %29 = call float @dx.op.unary.f32(i32 22, float %23)  ; Frc(value)
  %30 = call float @dx.op.unary.f32(i32 22, float %24)  ; Frc(value)
  %31 = add i32 %15, -1
  %32 = add i32 %16, -1
  %33 = call i32 @dx.op.binary.i32(i32 37, i32 %27, i32 0)  ; IMax(a,b)
  %34 = call i32 @dx.op.binary.i32(i32 37, i32 %28, i32 0)  ; IMax(a,b)
  %35 = call i32 @dx.op.binary.i32(i32 38, i32 %33, i32 %31)  ; IMin(a,b)
  %36 = call i32 @dx.op.binary.i32(i32 38, i32 %34, i32 %32)  ; IMin(a,b)
  %37 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %35, i32 %36, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %38 = extractvalue %dx.types.ResRet.f32 %37, 0
  %39 = extractvalue %dx.types.ResRet.f32 %37, 1
  %40 = extractvalue %dx.types.ResRet.f32 %37, 2
  %41 = extractvalue %dx.types.ResRet.f32 %37, 3
  %42 = fcmp fast olt float %41, 0.000000e+00
  br i1 %42, label %43, label %45

; <label>:43                                      ; preds = %0
  %44 = fsub fast float -1.000000e+00, %41
  br label %718

; <label>:45                                      ; preds = %0
  %46 = fadd fast float %6, 1.000000e+00
  %47 = fadd fast float %7, 1.000000e+00
  %48 = fsub fast float 1.000000e+00, %6
  %49 = fmul fast float %10, %46
  %50 = fmul fast float %10, %47
  %51 = fmul fast float %10, %48
  %52 = fmul fast float %49, %38
  %53 = fmul fast float %50, %39
  %54 = fmul fast float %51, %40
  %55 = fcmp fast ult float %11, 5.000000e-01
  br i1 %55, label %81, label %56

; <label>:56                                      ; preds = %45
  %57 = fmul fast float %52, 0x4004147AE0000000
  %58 = fmul fast float %53, 0x4004147AE0000000
  %59 = fmul fast float %54, 0x4004147AE0000000
  %60 = fadd fast float %57, 0x3F9EB851E0000000
  %61 = fadd fast float %58, 0x3F9EB851E0000000
  %62 = fadd fast float %59, 0x3F9EB851E0000000
  %63 = fmul fast float %60, %52
  %64 = fmul fast float %61, %53
  %65 = fmul fast float %62, %54
  %66 = fmul fast float %52, 0x400370A3E0000000
  %67 = fmul fast float %53, 0x400370A3E0000000
  %68 = fmul fast float %54, 0x400370A3E0000000
  %69 = fadd fast float %66, 0x3FE2E147A0000000
  %70 = fadd fast float %67, 0x3FE2E147A0000000
  %71 = fadd fast float %68, 0x3FE2E147A0000000
  %72 = fmul fast float %69, %52
  %73 = fmul fast float %70, %53
  %74 = fmul fast float %71, %54
  %75 = fadd fast float %72, 0x3FC1EB8520000000
  %76 = fadd fast float %73, 0x3FC1EB8520000000
  %77 = fadd fast float %74, 0x3FC1EB8520000000
  %78 = fdiv fast float %63, %75
  %79 = fdiv fast float %64, %76
  %80 = fdiv fast float %65, %77
  br label %81

; <label>:81                                      ; preds = %56, %45
  %82 = phi float [ %78, %56 ], [ %52, %45 ]
  %83 = phi float [ %79, %56 ], [ %53, %45 ]
  %84 = phi float [ %80, %56 ], [ %54, %45 ]
  %85 = call float @dx.op.unary.f32(i32 7, float %82)  ; Saturate(value)
  %86 = call float @dx.op.unary.f32(i32 7, float %83)  ; Saturate(value)
  %87 = call float @dx.op.unary.f32(i32 7, float %84)  ; Saturate(value)
  %88 = call float @dx.op.dot3.f32(i32 55, float %85, float %86, float %87, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %89 = fsub fast float %85, %88
  %90 = fsub fast float %86, %88
  %91 = fsub fast float %87, %88
  %92 = fmul fast float %89, %9
  %93 = fmul fast float %90, %9
  %94 = fmul fast float %91, %9
  %95 = fadd fast float %92, %88
  %96 = fadd fast float %93, %88
  %97 = fadd fast float %94, %88
  %98 = call float @dx.op.unary.f32(i32 7, float %95)  ; Saturate(value)
  %99 = call float @dx.op.unary.f32(i32 7, float %96)  ; Saturate(value)
  %100 = call float @dx.op.unary.f32(i32 7, float %97)  ; Saturate(value)
  %101 = fadd fast float %98, 0xBFC70A3D80000000
  %102 = fadd fast float %99, 0xBFC70A3D80000000
  %103 = fadd fast float %100, 0xBFC70A3D80000000
  %104 = fmul fast float %101, %8
  %105 = fmul fast float %102, %8
  %106 = fmul fast float %103, %8
  %107 = fadd fast float %104, 0x3FC70A3D80000000
  %108 = fadd fast float %105, 0x3FC70A3D80000000
  %109 = fadd fast float %106, 0x3FC70A3D80000000
  %110 = call float @dx.op.unary.f32(i32 7, float %107)  ; Saturate(value)
  %111 = call float @dx.op.unary.f32(i32 7, float %108)  ; Saturate(value)
  %112 = call float @dx.op.unary.f32(i32 7, float %109)  ; Saturate(value)
  %113 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %113, label %114, label %678

; <label>:114                                     ; preds = %81
  %115 = add i32 %36, -1
  %116 = call i32 @dx.op.binary.i32(i32 37, i32 %35, i32 0)  ; IMax(a,b)
  %117 = call i32 @dx.op.binary.i32(i32 37, i32 %115, i32 0)  ; IMax(a,b)
  %118 = call i32 @dx.op.binary.i32(i32 38, i32 %116, i32 %31)  ; IMin(a,b)
  %119 = call i32 @dx.op.binary.i32(i32 38, i32 %117, i32 %32)  ; IMin(a,b)
  %120 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %118, i32 %119, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %121 = extractvalue %dx.types.ResRet.f32 %120, 0
  %122 = extractvalue %dx.types.ResRet.f32 %120, 1
  %123 = extractvalue %dx.types.ResRet.f32 %120, 2
  %124 = extractvalue %dx.types.ResRet.f32 %120, 3
  %125 = fcmp fast olt float %124, 0.000000e+00
  br i1 %125, label %126, label %160

; <label>:126                                     ; preds = %114
  %127 = fcmp fast ogt float %121, 0x3FA4B5DCC0000000
  %128 = fcmp fast ogt float %122, 0x3FA4B5DCC0000000
  %129 = fcmp fast ogt float %123, 0x3FA4B5DCC0000000
  %130 = select i1 %127, float 0.000000e+00, float 1.000000e+00
  %131 = select i1 %128, float 0.000000e+00, float 1.000000e+00
  %132 = select i1 %129, float 0.000000e+00, float 1.000000e+00
  %133 = fmul fast float %121, 0x3FB3D07220000000
  %134 = fmul fast float %122, 0x3FB3D07220000000
  %135 = fmul fast float %123, 0x3FB3D07220000000
  %136 = fadd fast float %121, 0x3FAC28F5C0000000
  %137 = fadd fast float %122, 0x3FAC28F5C0000000
  %138 = fadd fast float %123, 0x3FAC28F5C0000000
  %139 = fmul fast float %136, 0x3FEE54EDE0000000
  %140 = fmul fast float %137, 0x3FEE54EDE0000000
  %141 = fmul fast float %138, 0x3FEE54EDE0000000
  %142 = call float @dx.op.unary.f32(i32 23, float %139)  ; Log(value)
  %143 = call float @dx.op.unary.f32(i32 23, float %140)  ; Log(value)
  %144 = call float @dx.op.unary.f32(i32 23, float %141)  ; Log(value)
  %145 = fmul fast float %142, 0x4003333340000000
  %146 = fmul fast float %143, 0x4003333340000000
  %147 = fmul fast float %144, 0x4003333340000000
  %148 = call float @dx.op.unary.f32(i32 21, float %145)  ; Exp(value)
  %149 = call float @dx.op.unary.f32(i32 21, float %146)  ; Exp(value)
  %150 = call float @dx.op.unary.f32(i32 21, float %147)  ; Exp(value)
  %151 = fsub fast float %133, %148
  %152 = fsub fast float %134, %149
  %153 = fsub fast float %135, %150
  %154 = fmul fast float %151, %130
  %155 = fmul fast float %152, %131
  %156 = fmul fast float %153, %132
  %157 = fadd fast float %154, %148
  %158 = fadd fast float %155, %149
  %159 = fadd fast float %156, %150
  br label %228

; <label>:160                                     ; preds = %114
  %161 = fadd fast float %6, 1.000000e+00
  %162 = fadd fast float %7, 1.000000e+00
  %163 = fsub fast float 1.000000e+00, %6
  %164 = fmul fast float %10, %161
  %165 = fmul fast float %10, %162
  %166 = fmul fast float %10, %163
  %167 = fmul fast float %164, %121
  %168 = fmul fast float %165, %122
  %169 = fmul fast float %166, %123
  %170 = fcmp fast ult float %11, 5.000000e-01
  br i1 %170, label %196, label %171

; <label>:171                                     ; preds = %160
  %172 = fmul fast float %167, 0x4004147AE0000000
  %173 = fmul fast float %168, 0x4004147AE0000000
  %174 = fmul fast float %169, 0x4004147AE0000000
  %175 = fadd fast float %172, 0x3F9EB851E0000000
  %176 = fadd fast float %173, 0x3F9EB851E0000000
  %177 = fadd fast float %174, 0x3F9EB851E0000000
  %178 = fmul fast float %175, %167
  %179 = fmul fast float %176, %168
  %180 = fmul fast float %177, %169
  %181 = fmul fast float %167, 0x400370A3E0000000
  %182 = fmul fast float %168, 0x400370A3E0000000
  %183 = fmul fast float %169, 0x400370A3E0000000
  %184 = fadd fast float %181, 0x3FE2E147A0000000
  %185 = fadd fast float %182, 0x3FE2E147A0000000
  %186 = fadd fast float %183, 0x3FE2E147A0000000
  %187 = fmul fast float %184, %167
  %188 = fmul fast float %185, %168
  %189 = fmul fast float %186, %169
  %190 = fadd fast float %187, 0x3FC1EB8520000000
  %191 = fadd fast float %188, 0x3FC1EB8520000000
  %192 = fadd fast float %189, 0x3FC1EB8520000000
  %193 = fdiv fast float %178, %190
  %194 = fdiv fast float %179, %191
  %195 = fdiv fast float %180, %192
  br label %196

; <label>:196                                     ; preds = %171, %160
  %197 = phi float [ %193, %171 ], [ %167, %160 ]
  %198 = phi float [ %194, %171 ], [ %168, %160 ]
  %199 = phi float [ %195, %171 ], [ %169, %160 ]
  %200 = call float @dx.op.unary.f32(i32 7, float %197)  ; Saturate(value)
  %201 = call float @dx.op.unary.f32(i32 7, float %198)  ; Saturate(value)
  %202 = call float @dx.op.unary.f32(i32 7, float %199)  ; Saturate(value)
  %203 = call float @dx.op.dot3.f32(i32 55, float %200, float %201, float %202, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %204 = fsub fast float %200, %203
  %205 = fsub fast float %201, %203
  %206 = fsub fast float %202, %203
  %207 = fmul fast float %204, %9
  %208 = fmul fast float %205, %9
  %209 = fmul fast float %206, %9
  %210 = fadd fast float %207, %203
  %211 = fadd fast float %208, %203
  %212 = fadd fast float %209, %203
  %213 = call float @dx.op.unary.f32(i32 7, float %210)  ; Saturate(value)
  %214 = call float @dx.op.unary.f32(i32 7, float %211)  ; Saturate(value)
  %215 = call float @dx.op.unary.f32(i32 7, float %212)  ; Saturate(value)
  %216 = fadd fast float %213, 0xBFC70A3D80000000
  %217 = fadd fast float %214, 0xBFC70A3D80000000
  %218 = fadd fast float %215, 0xBFC70A3D80000000
  %219 = fmul fast float %216, %8
  %220 = fmul fast float %217, %8
  %221 = fmul fast float %218, %8
  %222 = fadd fast float %219, 0x3FC70A3D80000000
  %223 = fadd fast float %220, 0x3FC70A3D80000000
  %224 = fadd fast float %221, 0x3FC70A3D80000000
  %225 = call float @dx.op.unary.f32(i32 7, float %222)  ; Saturate(value)
  %226 = call float @dx.op.unary.f32(i32 7, float %223)  ; Saturate(value)
  %227 = call float @dx.op.unary.f32(i32 7, float %224)  ; Saturate(value)
  br label %228

; <label>:228                                     ; preds = %196, %126
  %229 = phi float [ %157, %126 ], [ %225, %196 ]
  %230 = phi float [ %158, %126 ], [ %226, %196 ]
  %231 = phi float [ %159, %126 ], [ %227, %196 ]
  %232 = add i32 %36, 1
  %233 = call i32 @dx.op.binary.i32(i32 37, i32 %232, i32 0)  ; IMax(a,b)
  %234 = call i32 @dx.op.binary.i32(i32 38, i32 %233, i32 %32)  ; IMin(a,b)
  %235 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %118, i32 %234, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %236 = extractvalue %dx.types.ResRet.f32 %235, 0
  %237 = extractvalue %dx.types.ResRet.f32 %235, 1
  %238 = extractvalue %dx.types.ResRet.f32 %235, 2
  %239 = extractvalue %dx.types.ResRet.f32 %235, 3
  %240 = fcmp fast olt float %239, 0.000000e+00
  br i1 %240, label %241, label %275

; <label>:241                                     ; preds = %228
  %242 = fcmp fast ogt float %236, 0x3FA4B5DCC0000000
  %243 = fcmp fast ogt float %237, 0x3FA4B5DCC0000000
  %244 = fcmp fast ogt float %238, 0x3FA4B5DCC0000000
  %245 = select i1 %242, float 0.000000e+00, float 1.000000e+00
  %246 = select i1 %243, float 0.000000e+00, float 1.000000e+00
  %247 = select i1 %244, float 0.000000e+00, float 1.000000e+00
  %248 = fmul fast float %236, 0x3FB3D07220000000
  %249 = fmul fast float %237, 0x3FB3D07220000000
  %250 = fmul fast float %238, 0x3FB3D07220000000
  %251 = fadd fast float %236, 0x3FAC28F5C0000000
  %252 = fadd fast float %237, 0x3FAC28F5C0000000
  %253 = fadd fast float %238, 0x3FAC28F5C0000000
  %254 = fmul fast float %251, 0x3FEE54EDE0000000
  %255 = fmul fast float %252, 0x3FEE54EDE0000000
  %256 = fmul fast float %253, 0x3FEE54EDE0000000
  %257 = call float @dx.op.unary.f32(i32 23, float %254)  ; Log(value)
  %258 = call float @dx.op.unary.f32(i32 23, float %255)  ; Log(value)
  %259 = call float @dx.op.unary.f32(i32 23, float %256)  ; Log(value)
  %260 = fmul fast float %257, 0x4003333340000000
  %261 = fmul fast float %258, 0x4003333340000000
  %262 = fmul fast float %259, 0x4003333340000000
  %263 = call float @dx.op.unary.f32(i32 21, float %260)  ; Exp(value)
  %264 = call float @dx.op.unary.f32(i32 21, float %261)  ; Exp(value)
  %265 = call float @dx.op.unary.f32(i32 21, float %262)  ; Exp(value)
  %266 = fsub fast float %248, %263
  %267 = fsub fast float %249, %264
  %268 = fsub fast float %250, %265
  %269 = fmul fast float %266, %245
  %270 = fmul fast float %267, %246
  %271 = fmul fast float %268, %247
  %272 = fadd fast float %269, %263
  %273 = fadd fast float %270, %264
  %274 = fadd fast float %271, %265
  br label %343

; <label>:275                                     ; preds = %228
  %276 = fadd fast float %6, 1.000000e+00
  %277 = fadd fast float %7, 1.000000e+00
  %278 = fsub fast float 1.000000e+00, %6
  %279 = fmul fast float %10, %276
  %280 = fmul fast float %10, %277
  %281 = fmul fast float %10, %278
  %282 = fmul fast float %279, %236
  %283 = fmul fast float %280, %237
  %284 = fmul fast float %281, %238
  %285 = fcmp fast ult float %11, 5.000000e-01
  br i1 %285, label %311, label %286

; <label>:286                                     ; preds = %275
  %287 = fmul fast float %282, 0x4004147AE0000000
  %288 = fmul fast float %283, 0x4004147AE0000000
  %289 = fmul fast float %284, 0x4004147AE0000000
  %290 = fadd fast float %287, 0x3F9EB851E0000000
  %291 = fadd fast float %288, 0x3F9EB851E0000000
  %292 = fadd fast float %289, 0x3F9EB851E0000000
  %293 = fmul fast float %290, %282
  %294 = fmul fast float %291, %283
  %295 = fmul fast float %292, %284
  %296 = fmul fast float %282, 0x400370A3E0000000
  %297 = fmul fast float %283, 0x400370A3E0000000
  %298 = fmul fast float %284, 0x400370A3E0000000
  %299 = fadd fast float %296, 0x3FE2E147A0000000
  %300 = fadd fast float %297, 0x3FE2E147A0000000
  %301 = fadd fast float %298, 0x3FE2E147A0000000
  %302 = fmul fast float %299, %282
  %303 = fmul fast float %300, %283
  %304 = fmul fast float %301, %284
  %305 = fadd fast float %302, 0x3FC1EB8520000000
  %306 = fadd fast float %303, 0x3FC1EB8520000000
  %307 = fadd fast float %304, 0x3FC1EB8520000000
  %308 = fdiv fast float %293, %305
  %309 = fdiv fast float %294, %306
  %310 = fdiv fast float %295, %307
  br label %311

; <label>:311                                     ; preds = %286, %275
  %312 = phi float [ %308, %286 ], [ %282, %275 ]
  %313 = phi float [ %309, %286 ], [ %283, %275 ]
  %314 = phi float [ %310, %286 ], [ %284, %275 ]
  %315 = call float @dx.op.unary.f32(i32 7, float %312)  ; Saturate(value)
  %316 = call float @dx.op.unary.f32(i32 7, float %313)  ; Saturate(value)
  %317 = call float @dx.op.unary.f32(i32 7, float %314)  ; Saturate(value)
  %318 = call float @dx.op.dot3.f32(i32 55, float %315, float %316, float %317, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %319 = fsub fast float %315, %318
  %320 = fsub fast float %316, %318
  %321 = fsub fast float %317, %318
  %322 = fmul fast float %319, %9
  %323 = fmul fast float %320, %9
  %324 = fmul fast float %321, %9
  %325 = fadd fast float %322, %318
  %326 = fadd fast float %323, %318
  %327 = fadd fast float %324, %318
  %328 = call float @dx.op.unary.f32(i32 7, float %325)  ; Saturate(value)
  %329 = call float @dx.op.unary.f32(i32 7, float %326)  ; Saturate(value)
  %330 = call float @dx.op.unary.f32(i32 7, float %327)  ; Saturate(value)
  %331 = fadd fast float %328, 0xBFC70A3D80000000
  %332 = fadd fast float %329, 0xBFC70A3D80000000
  %333 = fadd fast float %330, 0xBFC70A3D80000000
  %334 = fmul fast float %331, %8
  %335 = fmul fast float %332, %8
  %336 = fmul fast float %333, %8
  %337 = fadd fast float %334, 0x3FC70A3D80000000
  %338 = fadd fast float %335, 0x3FC70A3D80000000
  %339 = fadd fast float %336, 0x3FC70A3D80000000
  %340 = call float @dx.op.unary.f32(i32 7, float %337)  ; Saturate(value)
  %341 = call float @dx.op.unary.f32(i32 7, float %338)  ; Saturate(value)
  %342 = call float @dx.op.unary.f32(i32 7, float %339)  ; Saturate(value)
  br label %343

; <label>:343                                     ; preds = %311, %241
  %344 = phi float [ %272, %241 ], [ %340, %311 ]
  %345 = phi float [ %273, %241 ], [ %341, %311 ]
  %346 = phi float [ %274, %241 ], [ %342, %311 ]
  %347 = add i32 %35, -1
  %348 = call i32 @dx.op.binary.i32(i32 37, i32 %347, i32 0)  ; IMax(a,b)
  %349 = call i32 @dx.op.binary.i32(i32 37, i32 %36, i32 0)  ; IMax(a,b)
  %350 = call i32 @dx.op.binary.i32(i32 38, i32 %348, i32 %31)  ; IMin(a,b)
  %351 = call i32 @dx.op.binary.i32(i32 38, i32 %349, i32 %32)  ; IMin(a,b)
  %352 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %350, i32 %351, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %353 = extractvalue %dx.types.ResRet.f32 %352, 0
  %354 = extractvalue %dx.types.ResRet.f32 %352, 1
  %355 = extractvalue %dx.types.ResRet.f32 %352, 2
  %356 = extractvalue %dx.types.ResRet.f32 %352, 3
  %357 = fcmp fast olt float %356, 0.000000e+00
  br i1 %357, label %358, label %392

; <label>:358                                     ; preds = %343
  %359 = fcmp fast ogt float %353, 0x3FA4B5DCC0000000
  %360 = fcmp fast ogt float %354, 0x3FA4B5DCC0000000
  %361 = fcmp fast ogt float %355, 0x3FA4B5DCC0000000
  %362 = select i1 %359, float 0.000000e+00, float 1.000000e+00
  %363 = select i1 %360, float 0.000000e+00, float 1.000000e+00
  %364 = select i1 %361, float 0.000000e+00, float 1.000000e+00
  %365 = fmul fast float %353, 0x3FB3D07220000000
  %366 = fmul fast float %354, 0x3FB3D07220000000
  %367 = fmul fast float %355, 0x3FB3D07220000000
  %368 = fadd fast float %353, 0x3FAC28F5C0000000
  %369 = fadd fast float %354, 0x3FAC28F5C0000000
  %370 = fadd fast float %355, 0x3FAC28F5C0000000
  %371 = fmul fast float %368, 0x3FEE54EDE0000000
  %372 = fmul fast float %369, 0x3FEE54EDE0000000
  %373 = fmul fast float %370, 0x3FEE54EDE0000000
  %374 = call float @dx.op.unary.f32(i32 23, float %371)  ; Log(value)
  %375 = call float @dx.op.unary.f32(i32 23, float %372)  ; Log(value)
  %376 = call float @dx.op.unary.f32(i32 23, float %373)  ; Log(value)
  %377 = fmul fast float %374, 0x4003333340000000
  %378 = fmul fast float %375, 0x4003333340000000
  %379 = fmul fast float %376, 0x4003333340000000
  %380 = call float @dx.op.unary.f32(i32 21, float %377)  ; Exp(value)
  %381 = call float @dx.op.unary.f32(i32 21, float %378)  ; Exp(value)
  %382 = call float @dx.op.unary.f32(i32 21, float %379)  ; Exp(value)
  %383 = fsub fast float %365, %380
  %384 = fsub fast float %366, %381
  %385 = fsub fast float %367, %382
  %386 = fmul fast float %383, %362
  %387 = fmul fast float %384, %363
  %388 = fmul fast float %385, %364
  %389 = fadd fast float %386, %380
  %390 = fadd fast float %387, %381
  %391 = fadd fast float %388, %382
  br label %460

; <label>:392                                     ; preds = %343
  %393 = fadd fast float %6, 1.000000e+00
  %394 = fadd fast float %7, 1.000000e+00
  %395 = fsub fast float 1.000000e+00, %6
  %396 = fmul fast float %10, %393
  %397 = fmul fast float %10, %394
  %398 = fmul fast float %10, %395
  %399 = fmul fast float %396, %353
  %400 = fmul fast float %397, %354
  %401 = fmul fast float %398, %355
  %402 = fcmp fast ult float %11, 5.000000e-01
  br i1 %402, label %428, label %403

; <label>:403                                     ; preds = %392
  %404 = fmul fast float %399, 0x4004147AE0000000
  %405 = fmul fast float %400, 0x4004147AE0000000
  %406 = fmul fast float %401, 0x4004147AE0000000
  %407 = fadd fast float %404, 0x3F9EB851E0000000
  %408 = fadd fast float %405, 0x3F9EB851E0000000
  %409 = fadd fast float %406, 0x3F9EB851E0000000
  %410 = fmul fast float %407, %399
  %411 = fmul fast float %408, %400
  %412 = fmul fast float %409, %401
  %413 = fmul fast float %399, 0x400370A3E0000000
  %414 = fmul fast float %400, 0x400370A3E0000000
  %415 = fmul fast float %401, 0x400370A3E0000000
  %416 = fadd fast float %413, 0x3FE2E147A0000000
  %417 = fadd fast float %414, 0x3FE2E147A0000000
  %418 = fadd fast float %415, 0x3FE2E147A0000000
  %419 = fmul fast float %416, %399
  %420 = fmul fast float %417, %400
  %421 = fmul fast float %418, %401
  %422 = fadd fast float %419, 0x3FC1EB8520000000
  %423 = fadd fast float %420, 0x3FC1EB8520000000
  %424 = fadd fast float %421, 0x3FC1EB8520000000
  %425 = fdiv fast float %410, %422
  %426 = fdiv fast float %411, %423
  %427 = fdiv fast float %412, %424
  br label %428

; <label>:428                                     ; preds = %403, %392
  %429 = phi float [ %425, %403 ], [ %399, %392 ]
  %430 = phi float [ %426, %403 ], [ %400, %392 ]
  %431 = phi float [ %427, %403 ], [ %401, %392 ]
  %432 = call float @dx.op.unary.f32(i32 7, float %429)  ; Saturate(value)
  %433 = call float @dx.op.unary.f32(i32 7, float %430)  ; Saturate(value)
  %434 = call float @dx.op.unary.f32(i32 7, float %431)  ; Saturate(value)
  %435 = call float @dx.op.dot3.f32(i32 55, float %432, float %433, float %434, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %436 = fsub fast float %432, %435
  %437 = fsub fast float %433, %435
  %438 = fsub fast float %434, %435
  %439 = fmul fast float %436, %9
  %440 = fmul fast float %437, %9
  %441 = fmul fast float %438, %9
  %442 = fadd fast float %439, %435
  %443 = fadd fast float %440, %435
  %444 = fadd fast float %441, %435
  %445 = call float @dx.op.unary.f32(i32 7, float %442)  ; Saturate(value)
  %446 = call float @dx.op.unary.f32(i32 7, float %443)  ; Saturate(value)
  %447 = call float @dx.op.unary.f32(i32 7, float %444)  ; Saturate(value)
  %448 = fadd fast float %445, 0xBFC70A3D80000000
  %449 = fadd fast float %446, 0xBFC70A3D80000000
  %450 = fadd fast float %447, 0xBFC70A3D80000000
  %451 = fmul fast float %448, %8
  %452 = fmul fast float %449, %8
  %453 = fmul fast float %450, %8
  %454 = fadd fast float %451, 0x3FC70A3D80000000
  %455 = fadd fast float %452, 0x3FC70A3D80000000
  %456 = fadd fast float %453, 0x3FC70A3D80000000
  %457 = call float @dx.op.unary.f32(i32 7, float %454)  ; Saturate(value)
  %458 = call float @dx.op.unary.f32(i32 7, float %455)  ; Saturate(value)
  %459 = call float @dx.op.unary.f32(i32 7, float %456)  ; Saturate(value)
  br label %460

; <label>:460                                     ; preds = %428, %358
  %461 = phi float [ %389, %358 ], [ %457, %428 ]
  %462 = phi float [ %390, %358 ], [ %458, %428 ]
  %463 = phi float [ %391, %358 ], [ %459, %428 ]
  %464 = add i32 %35, 1
  %465 = call i32 @dx.op.binary.i32(i32 37, i32 %464, i32 0)  ; IMax(a,b)
  %466 = call i32 @dx.op.binary.i32(i32 38, i32 %465, i32 %31)  ; IMin(a,b)
  %467 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %466, i32 %351, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %468 = extractvalue %dx.types.ResRet.f32 %467, 0
  %469 = extractvalue %dx.types.ResRet.f32 %467, 1
  %470 = extractvalue %dx.types.ResRet.f32 %467, 2
  %471 = extractvalue %dx.types.ResRet.f32 %467, 3
  %472 = fcmp fast olt float %471, 0.000000e+00
  br i1 %472, label %473, label %507

; <label>:473                                     ; preds = %460
  %474 = fcmp fast ogt float %468, 0x3FA4B5DCC0000000
  %475 = fcmp fast ogt float %469, 0x3FA4B5DCC0000000
  %476 = fcmp fast ogt float %470, 0x3FA4B5DCC0000000
  %477 = select i1 %474, float 0.000000e+00, float 1.000000e+00
  %478 = select i1 %475, float 0.000000e+00, float 1.000000e+00
  %479 = select i1 %476, float 0.000000e+00, float 1.000000e+00
  %480 = fmul fast float %468, 0x3FB3D07220000000
  %481 = fmul fast float %469, 0x3FB3D07220000000
  %482 = fmul fast float %470, 0x3FB3D07220000000
  %483 = fadd fast float %468, 0x3FAC28F5C0000000
  %484 = fadd fast float %469, 0x3FAC28F5C0000000
  %485 = fadd fast float %470, 0x3FAC28F5C0000000
  %486 = fmul fast float %483, 0x3FEE54EDE0000000
  %487 = fmul fast float %484, 0x3FEE54EDE0000000
  %488 = fmul fast float %485, 0x3FEE54EDE0000000
  %489 = call float @dx.op.unary.f32(i32 23, float %486)  ; Log(value)
  %490 = call float @dx.op.unary.f32(i32 23, float %487)  ; Log(value)
  %491 = call float @dx.op.unary.f32(i32 23, float %488)  ; Log(value)
  %492 = fmul fast float %489, 0x4003333340000000
  %493 = fmul fast float %490, 0x4003333340000000
  %494 = fmul fast float %491, 0x4003333340000000
  %495 = call float @dx.op.unary.f32(i32 21, float %492)  ; Exp(value)
  %496 = call float @dx.op.unary.f32(i32 21, float %493)  ; Exp(value)
  %497 = call float @dx.op.unary.f32(i32 21, float %494)  ; Exp(value)
  %498 = fsub fast float %480, %495
  %499 = fsub fast float %481, %496
  %500 = fsub fast float %482, %497
  %501 = fmul fast float %498, %477
  %502 = fmul fast float %499, %478
  %503 = fmul fast float %500, %479
  %504 = fadd fast float %501, %495
  %505 = fadd fast float %502, %496
  %506 = fadd fast float %503, %497
  br label %575

; <label>:507                                     ; preds = %460
  %508 = fadd fast float %6, 1.000000e+00
  %509 = fadd fast float %7, 1.000000e+00
  %510 = fsub fast float 1.000000e+00, %6
  %511 = fmul fast float %10, %508
  %512 = fmul fast float %10, %509
  %513 = fmul fast float %10, %510
  %514 = fmul fast float %511, %468
  %515 = fmul fast float %512, %469
  %516 = fmul fast float %513, %470
  %517 = fcmp fast ult float %11, 5.000000e-01
  br i1 %517, label %543, label %518

; <label>:518                                     ; preds = %507
  %519 = fmul fast float %514, 0x4004147AE0000000
  %520 = fmul fast float %515, 0x4004147AE0000000
  %521 = fmul fast float %516, 0x4004147AE0000000
  %522 = fadd fast float %519, 0x3F9EB851E0000000
  %523 = fadd fast float %520, 0x3F9EB851E0000000
  %524 = fadd fast float %521, 0x3F9EB851E0000000
  %525 = fmul fast float %522, %514
  %526 = fmul fast float %523, %515
  %527 = fmul fast float %524, %516
  %528 = fmul fast float %514, 0x400370A3E0000000
  %529 = fmul fast float %515, 0x400370A3E0000000
  %530 = fmul fast float %516, 0x400370A3E0000000
  %531 = fadd fast float %528, 0x3FE2E147A0000000
  %532 = fadd fast float %529, 0x3FE2E147A0000000
  %533 = fadd fast float %530, 0x3FE2E147A0000000
  %534 = fmul fast float %531, %514
  %535 = fmul fast float %532, %515
  %536 = fmul fast float %533, %516
  %537 = fadd fast float %534, 0x3FC1EB8520000000
  %538 = fadd fast float %535, 0x3FC1EB8520000000
  %539 = fadd fast float %536, 0x3FC1EB8520000000
  %540 = fdiv fast float %525, %537
  %541 = fdiv fast float %526, %538
  %542 = fdiv fast float %527, %539
  br label %543

; <label>:543                                     ; preds = %518, %507
  %544 = phi float [ %540, %518 ], [ %514, %507 ]
  %545 = phi float [ %541, %518 ], [ %515, %507 ]
  %546 = phi float [ %542, %518 ], [ %516, %507 ]
  %547 = call float @dx.op.unary.f32(i32 7, float %544)  ; Saturate(value)
  %548 = call float @dx.op.unary.f32(i32 7, float %545)  ; Saturate(value)
  %549 = call float @dx.op.unary.f32(i32 7, float %546)  ; Saturate(value)
  %550 = call float @dx.op.dot3.f32(i32 55, float %547, float %548, float %549, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %551 = fsub fast float %547, %550
  %552 = fsub fast float %548, %550
  %553 = fsub fast float %549, %550
  %554 = fmul fast float %551, %9
  %555 = fmul fast float %552, %9
  %556 = fmul fast float %553, %9
  %557 = fadd fast float %554, %550
  %558 = fadd fast float %555, %550
  %559 = fadd fast float %556, %550
  %560 = call float @dx.op.unary.f32(i32 7, float %557)  ; Saturate(value)
  %561 = call float @dx.op.unary.f32(i32 7, float %558)  ; Saturate(value)
  %562 = call float @dx.op.unary.f32(i32 7, float %559)  ; Saturate(value)
  %563 = fadd fast float %560, 0xBFC70A3D80000000
  %564 = fadd fast float %561, 0xBFC70A3D80000000
  %565 = fadd fast float %562, 0xBFC70A3D80000000
  %566 = fmul fast float %563, %8
  %567 = fmul fast float %564, %8
  %568 = fmul fast float %565, %8
  %569 = fadd fast float %566, 0x3FC70A3D80000000
  %570 = fadd fast float %567, 0x3FC70A3D80000000
  %571 = fadd fast float %568, 0x3FC70A3D80000000
  %572 = call float @dx.op.unary.f32(i32 7, float %569)  ; Saturate(value)
  %573 = call float @dx.op.unary.f32(i32 7, float %570)  ; Saturate(value)
  %574 = call float @dx.op.unary.f32(i32 7, float %571)  ; Saturate(value)
  br label %575

; <label>:575                                     ; preds = %543, %473
  %576 = phi float [ %504, %473 ], [ %572, %543 ]
  %577 = phi float [ %505, %473 ], [ %573, %543 ]
  %578 = phi float [ %506, %473 ], [ %574, %543 ]
  %579 = call float @dx.op.binary.f32(i32 36, float %461, float %576)  ; FMin(a,b)
  %580 = call float @dx.op.binary.f32(i32 36, float %462, float %577)  ; FMin(a,b)
  %581 = call float @dx.op.binary.f32(i32 36, float %463, float %578)  ; FMin(a,b)
  %582 = call float @dx.op.binary.f32(i32 36, float %229, float %344)  ; FMin(a,b)
  %583 = call float @dx.op.binary.f32(i32 36, float %230, float %345)  ; FMin(a,b)
  %584 = call float @dx.op.binary.f32(i32 36, float %231, float %346)  ; FMin(a,b)
  %585 = call float @dx.op.binary.f32(i32 36, float %582, float %579)  ; FMin(a,b)
  %586 = call float @dx.op.binary.f32(i32 36, float %583, float %580)  ; FMin(a,b)
  %587 = call float @dx.op.binary.f32(i32 36, float %584, float %581)  ; FMin(a,b)
  %588 = call float @dx.op.binary.f32(i32 36, float %110, float %585)  ; FMin(a,b)
  %589 = call float @dx.op.binary.f32(i32 36, float %111, float %586)  ; FMin(a,b)
  %590 = call float @dx.op.binary.f32(i32 36, float %112, float %587)  ; FMin(a,b)
  %591 = call float @dx.op.binary.f32(i32 35, float %461, float %576)  ; FMax(a,b)
  %592 = call float @dx.op.binary.f32(i32 35, float %462, float %577)  ; FMax(a,b)
  %593 = call float @dx.op.binary.f32(i32 35, float %463, float %578)  ; FMax(a,b)
  %594 = call float @dx.op.binary.f32(i32 35, float %229, float %344)  ; FMax(a,b)
  %595 = call float @dx.op.binary.f32(i32 35, float %230, float %345)  ; FMax(a,b)
  %596 = call float @dx.op.binary.f32(i32 35, float %231, float %346)  ; FMax(a,b)
  %597 = call float @dx.op.binary.f32(i32 35, float %594, float %591)  ; FMax(a,b)
  %598 = call float @dx.op.binary.f32(i32 35, float %595, float %592)  ; FMax(a,b)
  %599 = call float @dx.op.binary.f32(i32 35, float %596, float %593)  ; FMax(a,b)
  %600 = call float @dx.op.binary.f32(i32 35, float %110, float %597)  ; FMax(a,b)
  %601 = call float @dx.op.binary.f32(i32 35, float %111, float %598)  ; FMax(a,b)
  %602 = call float @dx.op.binary.f32(i32 35, float %112, float %599)  ; FMax(a,b)
  %603 = fsub fast float %600, %588
  %604 = fsub fast float %601, %589
  %605 = fsub fast float %602, %590
  %606 = call float @dx.op.unary.f32(i32 6, float %603)  ; FAbs(value)
  %607 = call float @dx.op.unary.f32(i32 6, float %604)  ; FAbs(value)
  %608 = call float @dx.op.unary.f32(i32 6, float %605)  ; FAbs(value)
  %609 = call float @dx.op.binary.f32(i32 35, float %607, float %608)  ; FMax(a,b)
  %610 = call float @dx.op.binary.f32(i32 35, float %606, float %609)  ; FMax(a,b)
  %611 = call float @dx.op.binary.f32(i32 35, float %601, float %602)  ; FMax(a,b)
  %612 = call float @dx.op.binary.f32(i32 35, float %600, float %611)  ; FMax(a,b)
  %613 = fmul fast float %612, 1.250000e-01
  %614 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %613)  ; FMax(a,b)
  %615 = fcmp fast ogt float %610, %614
  br i1 %615, label %616, label %678

; <label>:616                                     ; preds = %575
  %617 = fsub fast float %229, %344
  %618 = fsub fast float %230, %345
  %619 = fsub fast float %231, %346
  %620 = call float @dx.op.unary.f32(i32 6, float %617)  ; FAbs(value)
  %621 = call float @dx.op.unary.f32(i32 6, float %618)  ; FAbs(value)
  %622 = call float @dx.op.unary.f32(i32 6, float %619)  ; FAbs(value)
  %623 = call float @dx.op.binary.f32(i32 35, float %621, float %622)  ; FMax(a,b)
  %624 = call float @dx.op.binary.f32(i32 35, float %620, float %623)  ; FMax(a,b)
  %625 = fsub fast float %461, %576
  %626 = fsub fast float %462, %577
  %627 = fsub fast float %463, %578
  %628 = call float @dx.op.unary.f32(i32 6, float %625)  ; FAbs(value)
  %629 = call float @dx.op.unary.f32(i32 6, float %626)  ; FAbs(value)
  %630 = call float @dx.op.unary.f32(i32 6, float %627)  ; FAbs(value)
  %631 = call float @dx.op.binary.f32(i32 35, float %629, float %630)  ; FMax(a,b)
  %632 = call float @dx.op.binary.f32(i32 35, float %628, float %631)  ; FMax(a,b)
  %633 = fcmp fast olt float %624, %632
  %634 = select i1 %633, float %229, float %461
  %635 = select i1 %633, float %230, float %462
  %636 = select i1 %633, float %231, float %463
  %637 = select i1 %633, float %344, float %576
  %638 = select i1 %633, float %345, float %577
  %639 = select i1 %633, float %346, float %578
  %640 = fsub fast float %110, %637
  %641 = fsub fast float %111, %638
  %642 = fsub fast float %112, %639
  %643 = fsub fast float %110, %634
  %644 = fsub fast float %111, %635
  %645 = fsub fast float %112, %636
  %646 = call float @dx.op.dot3.f32(i32 55, float %643, float %644, float %645, float %640, float %641, float %642)  ; Dot3(ax,ay,az,bx,by,bz)
  %647 = fcmp fast ogt float %646, 0.000000e+00
  br i1 %647, label %648, label %659

; <label>:648                                     ; preds = %616
  %649 = fsub fast float %634, %637
  %650 = fsub fast float %635, %638
  %651 = fsub fast float %636, %639
  %652 = call float @dx.op.unary.f32(i32 6, float %649)  ; FAbs(value)
  %653 = call float @dx.op.unary.f32(i32 6, float %650)  ; FAbs(value)
  %654 = call float @dx.op.unary.f32(i32 6, float %651)  ; FAbs(value)
  %655 = call float @dx.op.binary.f32(i32 35, float %653, float %654)  ; FMax(a,b)
  %656 = call float @dx.op.binary.f32(i32 35, float %652, float %655)  ; FMax(a,b)
  %657 = fmul fast float %610, 2.500000e-01
  %658 = fcmp fast olt float %656, %657
  br label %659

; <label>:659                                     ; preds = %648, %616
  %660 = phi i1 [ false, %616 ], [ %658, %648 ]
  %661 = select i1 %660, float 5.000000e-01, float 1.000000e+00
  %662 = fmul fast float %661, %3
  %663 = fadd fast float %634, %637
  %664 = fadd fast float %635, %638
  %665 = fadd fast float %636, %639
  %666 = fmul fast float %663, 5.000000e-01
  %667 = fmul fast float %664, 5.000000e-01
  %668 = fmul fast float %665, 5.000000e-01
  %669 = fsub fast float %666, %110
  %670 = fsub fast float %667, %111
  %671 = fsub fast float %668, %112
  %672 = fmul fast float %662, %669
  %673 = fmul fast float %662, %670
  %674 = fmul fast float %662, %671
  %675 = fadd fast float %672, %110
  %676 = fadd fast float %673, %111
  %677 = fadd fast float %674, %112
  br label %678

; <label>:678                                     ; preds = %659, %575, %81
  %679 = phi float [ %675, %659 ], [ %110, %575 ], [ %110, %81 ]
  %680 = phi float [ %676, %659 ], [ %111, %575 ], [ %111, %81 ]
  %681 = phi float [ %677, %659 ], [ %112, %575 ], [ %112, %81 ]
  %682 = fcmp fast ogt float %679, 0x3F69A5C380000000
  %683 = fcmp fast ogt float %680, 0x3F69A5C380000000
  %684 = fcmp fast ogt float %681, 0x3F69A5C380000000
  %685 = select i1 %682, float 0.000000e+00, float 1.000000e+00
  %686 = select i1 %683, float 0.000000e+00, float 1.000000e+00
  %687 = select i1 %684, float 0.000000e+00, float 1.000000e+00
  %688 = fmul fast float %679, 0x4029D70A40000000
  %689 = fmul fast float %680, 0x4029D70A40000000
  %690 = fmul fast float %681, 0x4029D70A40000000
  %691 = call float @dx.op.binary.f32(i32 35, float %679, float 0.000000e+00)  ; FMax(a,b)
  %692 = call float @dx.op.binary.f32(i32 35, float %680, float 0.000000e+00)  ; FMax(a,b)
  %693 = call float @dx.op.binary.f32(i32 35, float %681, float 0.000000e+00)  ; FMax(a,b)
  %694 = call float @dx.op.unary.f32(i32 23, float %691)  ; Log(value)
  %695 = call float @dx.op.unary.f32(i32 23, float %692)  ; Log(value)
  %696 = call float @dx.op.unary.f32(i32 23, float %693)  ; Log(value)
  %697 = fmul fast float %694, 0x3FDAAAAAA0000000
  %698 = fmul fast float %695, 0x3FDAAAAAA0000000
  %699 = fmul fast float %696, 0x3FDAAAAAA0000000
  %700 = call float @dx.op.unary.f32(i32 21, float %697)  ; Exp(value)
  %701 = call float @dx.op.unary.f32(i32 21, float %698)  ; Exp(value)
  %702 = call float @dx.op.unary.f32(i32 21, float %699)  ; Exp(value)
  %703 = fmul fast float %700, 0x3FF0E147A0000000
  %704 = fmul fast float %701, 0x3FF0E147A0000000
  %705 = fmul fast float %702, 0x3FF0E147A0000000
  %706 = fadd fast float %703, 0xBFAC28F5C0000000
  %707 = fadd fast float %704, 0xBFAC28F5C0000000
  %708 = fadd fast float %705, 0xBFAC28F5C0000000
  %709 = fsub fast float %688, %706
  %710 = fsub fast float %689, %707
  %711 = fsub fast float %690, %708
  %712 = fmul fast float %709, %685
  %713 = fmul fast float %710, %686
  %714 = fmul fast float %711, %687
  %715 = fadd fast float %712, %706
  %716 = fadd fast float %713, %707
  %717 = fadd fast float %714, %708
  br label %718

; <label>:718                                     ; preds = %678, %43
  %719 = phi float [ %38, %43 ], [ %715, %678 ]
  %720 = phi float [ %39, %43 ], [ %716, %678 ]
  %721 = phi float [ %40, %43 ], [ %717, %678 ]
  %722 = phi float [ %44, %43 ], [ %41, %678 ]
  %723 = add i32 %27, 1
  %724 = call i32 @dx.op.binary.i32(i32 37, i32 %723, i32 0)  ; IMax(a,b)
  %725 = call i32 @dx.op.binary.i32(i32 38, i32 %724, i32 %31)  ; IMin(a,b)
  %726 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %725, i32 %36, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %727 = extractvalue %dx.types.ResRet.f32 %726, 0
  %728 = extractvalue %dx.types.ResRet.f32 %726, 1
  %729 = extractvalue %dx.types.ResRet.f32 %726, 2
  %730 = extractvalue %dx.types.ResRet.f32 %726, 3
  %731 = fcmp fast olt float %730, 0.000000e+00
  br i1 %731, label %732, label %734

; <label>:732                                     ; preds = %718
  %733 = fsub fast float -1.000000e+00, %730
  br label %1407

; <label>:734                                     ; preds = %718
  %735 = fadd fast float %6, 1.000000e+00
  %736 = fadd fast float %7, 1.000000e+00
  %737 = fsub fast float 1.000000e+00, %6
  %738 = fmul fast float %10, %735
  %739 = fmul fast float %10, %736
  %740 = fmul fast float %10, %737
  %741 = fmul fast float %738, %727
  %742 = fmul fast float %739, %728
  %743 = fmul fast float %740, %729
  %744 = fcmp fast ult float %11, 5.000000e-01
  br i1 %744, label %770, label %745

; <label>:745                                     ; preds = %734
  %746 = fmul fast float %741, 0x4004147AE0000000
  %747 = fmul fast float %742, 0x4004147AE0000000
  %748 = fmul fast float %743, 0x4004147AE0000000
  %749 = fadd fast float %746, 0x3F9EB851E0000000
  %750 = fadd fast float %747, 0x3F9EB851E0000000
  %751 = fadd fast float %748, 0x3F9EB851E0000000
  %752 = fmul fast float %749, %741
  %753 = fmul fast float %750, %742
  %754 = fmul fast float %751, %743
  %755 = fmul fast float %741, 0x400370A3E0000000
  %756 = fmul fast float %742, 0x400370A3E0000000
  %757 = fmul fast float %743, 0x400370A3E0000000
  %758 = fadd fast float %755, 0x3FE2E147A0000000
  %759 = fadd fast float %756, 0x3FE2E147A0000000
  %760 = fadd fast float %757, 0x3FE2E147A0000000
  %761 = fmul fast float %758, %741
  %762 = fmul fast float %759, %742
  %763 = fmul fast float %760, %743
  %764 = fadd fast float %761, 0x3FC1EB8520000000
  %765 = fadd fast float %762, 0x3FC1EB8520000000
  %766 = fadd fast float %763, 0x3FC1EB8520000000
  %767 = fdiv fast float %752, %764
  %768 = fdiv fast float %753, %765
  %769 = fdiv fast float %754, %766
  br label %770

; <label>:770                                     ; preds = %745, %734
  %771 = phi float [ %767, %745 ], [ %741, %734 ]
  %772 = phi float [ %768, %745 ], [ %742, %734 ]
  %773 = phi float [ %769, %745 ], [ %743, %734 ]
  %774 = call float @dx.op.unary.f32(i32 7, float %771)  ; Saturate(value)
  %775 = call float @dx.op.unary.f32(i32 7, float %772)  ; Saturate(value)
  %776 = call float @dx.op.unary.f32(i32 7, float %773)  ; Saturate(value)
  %777 = call float @dx.op.dot3.f32(i32 55, float %774, float %775, float %776, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %778 = fsub fast float %774, %777
  %779 = fsub fast float %775, %777
  %780 = fsub fast float %776, %777
  %781 = fmul fast float %778, %9
  %782 = fmul fast float %779, %9
  %783 = fmul fast float %780, %9
  %784 = fadd fast float %781, %777
  %785 = fadd fast float %782, %777
  %786 = fadd fast float %783, %777
  %787 = call float @dx.op.unary.f32(i32 7, float %784)  ; Saturate(value)
  %788 = call float @dx.op.unary.f32(i32 7, float %785)  ; Saturate(value)
  %789 = call float @dx.op.unary.f32(i32 7, float %786)  ; Saturate(value)
  %790 = fadd fast float %787, 0xBFC70A3D80000000
  %791 = fadd fast float %788, 0xBFC70A3D80000000
  %792 = fadd fast float %789, 0xBFC70A3D80000000
  %793 = fmul fast float %790, %8
  %794 = fmul fast float %791, %8
  %795 = fmul fast float %792, %8
  %796 = fadd fast float %793, 0x3FC70A3D80000000
  %797 = fadd fast float %794, 0x3FC70A3D80000000
  %798 = fadd fast float %795, 0x3FC70A3D80000000
  %799 = call float @dx.op.unary.f32(i32 7, float %796)  ; Saturate(value)
  %800 = call float @dx.op.unary.f32(i32 7, float %797)  ; Saturate(value)
  %801 = call float @dx.op.unary.f32(i32 7, float %798)  ; Saturate(value)
  %802 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %802, label %803, label %1367

; <label>:803                                     ; preds = %770
  %804 = add i32 %36, -1
  %805 = call i32 @dx.op.binary.i32(i32 37, i32 %725, i32 0)  ; IMax(a,b)
  %806 = call i32 @dx.op.binary.i32(i32 37, i32 %804, i32 0)  ; IMax(a,b)
  %807 = call i32 @dx.op.binary.i32(i32 38, i32 %805, i32 %31)  ; IMin(a,b)
  %808 = call i32 @dx.op.binary.i32(i32 38, i32 %806, i32 %32)  ; IMin(a,b)
  %809 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %807, i32 %808, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %810 = extractvalue %dx.types.ResRet.f32 %809, 0
  %811 = extractvalue %dx.types.ResRet.f32 %809, 1
  %812 = extractvalue %dx.types.ResRet.f32 %809, 2
  %813 = extractvalue %dx.types.ResRet.f32 %809, 3
  %814 = fcmp fast olt float %813, 0.000000e+00
  br i1 %814, label %815, label %849

; <label>:815                                     ; preds = %803
  %816 = fcmp fast ogt float %810, 0x3FA4B5DCC0000000
  %817 = fcmp fast ogt float %811, 0x3FA4B5DCC0000000
  %818 = fcmp fast ogt float %812, 0x3FA4B5DCC0000000
  %819 = select i1 %816, float 0.000000e+00, float 1.000000e+00
  %820 = select i1 %817, float 0.000000e+00, float 1.000000e+00
  %821 = select i1 %818, float 0.000000e+00, float 1.000000e+00
  %822 = fmul fast float %810, 0x3FB3D07220000000
  %823 = fmul fast float %811, 0x3FB3D07220000000
  %824 = fmul fast float %812, 0x3FB3D07220000000
  %825 = fadd fast float %810, 0x3FAC28F5C0000000
  %826 = fadd fast float %811, 0x3FAC28F5C0000000
  %827 = fadd fast float %812, 0x3FAC28F5C0000000
  %828 = fmul fast float %825, 0x3FEE54EDE0000000
  %829 = fmul fast float %826, 0x3FEE54EDE0000000
  %830 = fmul fast float %827, 0x3FEE54EDE0000000
  %831 = call float @dx.op.unary.f32(i32 23, float %828)  ; Log(value)
  %832 = call float @dx.op.unary.f32(i32 23, float %829)  ; Log(value)
  %833 = call float @dx.op.unary.f32(i32 23, float %830)  ; Log(value)
  %834 = fmul fast float %831, 0x4003333340000000
  %835 = fmul fast float %832, 0x4003333340000000
  %836 = fmul fast float %833, 0x4003333340000000
  %837 = call float @dx.op.unary.f32(i32 21, float %834)  ; Exp(value)
  %838 = call float @dx.op.unary.f32(i32 21, float %835)  ; Exp(value)
  %839 = call float @dx.op.unary.f32(i32 21, float %836)  ; Exp(value)
  %840 = fsub fast float %822, %837
  %841 = fsub fast float %823, %838
  %842 = fsub fast float %824, %839
  %843 = fmul fast float %840, %819
  %844 = fmul fast float %841, %820
  %845 = fmul fast float %842, %821
  %846 = fadd fast float %843, %837
  %847 = fadd fast float %844, %838
  %848 = fadd fast float %845, %839
  br label %917

; <label>:849                                     ; preds = %803
  %850 = fadd fast float %6, 1.000000e+00
  %851 = fadd fast float %7, 1.000000e+00
  %852 = fsub fast float 1.000000e+00, %6
  %853 = fmul fast float %10, %850
  %854 = fmul fast float %10, %851
  %855 = fmul fast float %10, %852
  %856 = fmul fast float %853, %810
  %857 = fmul fast float %854, %811
  %858 = fmul fast float %855, %812
  %859 = fcmp fast ult float %11, 5.000000e-01
  br i1 %859, label %885, label %860

; <label>:860                                     ; preds = %849
  %861 = fmul fast float %856, 0x4004147AE0000000
  %862 = fmul fast float %857, 0x4004147AE0000000
  %863 = fmul fast float %858, 0x4004147AE0000000
  %864 = fadd fast float %861, 0x3F9EB851E0000000
  %865 = fadd fast float %862, 0x3F9EB851E0000000
  %866 = fadd fast float %863, 0x3F9EB851E0000000
  %867 = fmul fast float %864, %856
  %868 = fmul fast float %865, %857
  %869 = fmul fast float %866, %858
  %870 = fmul fast float %856, 0x400370A3E0000000
  %871 = fmul fast float %857, 0x400370A3E0000000
  %872 = fmul fast float %858, 0x400370A3E0000000
  %873 = fadd fast float %870, 0x3FE2E147A0000000
  %874 = fadd fast float %871, 0x3FE2E147A0000000
  %875 = fadd fast float %872, 0x3FE2E147A0000000
  %876 = fmul fast float %873, %856
  %877 = fmul fast float %874, %857
  %878 = fmul fast float %875, %858
  %879 = fadd fast float %876, 0x3FC1EB8520000000
  %880 = fadd fast float %877, 0x3FC1EB8520000000
  %881 = fadd fast float %878, 0x3FC1EB8520000000
  %882 = fdiv fast float %867, %879
  %883 = fdiv fast float %868, %880
  %884 = fdiv fast float %869, %881
  br label %885

; <label>:885                                     ; preds = %860, %849
  %886 = phi float [ %882, %860 ], [ %856, %849 ]
  %887 = phi float [ %883, %860 ], [ %857, %849 ]
  %888 = phi float [ %884, %860 ], [ %858, %849 ]
  %889 = call float @dx.op.unary.f32(i32 7, float %886)  ; Saturate(value)
  %890 = call float @dx.op.unary.f32(i32 7, float %887)  ; Saturate(value)
  %891 = call float @dx.op.unary.f32(i32 7, float %888)  ; Saturate(value)
  %892 = call float @dx.op.dot3.f32(i32 55, float %889, float %890, float %891, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %893 = fsub fast float %889, %892
  %894 = fsub fast float %890, %892
  %895 = fsub fast float %891, %892
  %896 = fmul fast float %893, %9
  %897 = fmul fast float %894, %9
  %898 = fmul fast float %895, %9
  %899 = fadd fast float %896, %892
  %900 = fadd fast float %897, %892
  %901 = fadd fast float %898, %892
  %902 = call float @dx.op.unary.f32(i32 7, float %899)  ; Saturate(value)
  %903 = call float @dx.op.unary.f32(i32 7, float %900)  ; Saturate(value)
  %904 = call float @dx.op.unary.f32(i32 7, float %901)  ; Saturate(value)
  %905 = fadd fast float %902, 0xBFC70A3D80000000
  %906 = fadd fast float %903, 0xBFC70A3D80000000
  %907 = fadd fast float %904, 0xBFC70A3D80000000
  %908 = fmul fast float %905, %8
  %909 = fmul fast float %906, %8
  %910 = fmul fast float %907, %8
  %911 = fadd fast float %908, 0x3FC70A3D80000000
  %912 = fadd fast float %909, 0x3FC70A3D80000000
  %913 = fadd fast float %910, 0x3FC70A3D80000000
  %914 = call float @dx.op.unary.f32(i32 7, float %911)  ; Saturate(value)
  %915 = call float @dx.op.unary.f32(i32 7, float %912)  ; Saturate(value)
  %916 = call float @dx.op.unary.f32(i32 7, float %913)  ; Saturate(value)
  br label %917

; <label>:917                                     ; preds = %885, %815
  %918 = phi float [ %846, %815 ], [ %914, %885 ]
  %919 = phi float [ %847, %815 ], [ %915, %885 ]
  %920 = phi float [ %848, %815 ], [ %916, %885 ]
  %921 = add i32 %36, 1
  %922 = call i32 @dx.op.binary.i32(i32 37, i32 %921, i32 0)  ; IMax(a,b)
  %923 = call i32 @dx.op.binary.i32(i32 38, i32 %922, i32 %32)  ; IMin(a,b)
  %924 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %807, i32 %923, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %925 = extractvalue %dx.types.ResRet.f32 %924, 0
  %926 = extractvalue %dx.types.ResRet.f32 %924, 1
  %927 = extractvalue %dx.types.ResRet.f32 %924, 2
  %928 = extractvalue %dx.types.ResRet.f32 %924, 3
  %929 = fcmp fast olt float %928, 0.000000e+00
  br i1 %929, label %930, label %964

; <label>:930                                     ; preds = %917
  %931 = fcmp fast ogt float %925, 0x3FA4B5DCC0000000
  %932 = fcmp fast ogt float %926, 0x3FA4B5DCC0000000
  %933 = fcmp fast ogt float %927, 0x3FA4B5DCC0000000
  %934 = select i1 %931, float 0.000000e+00, float 1.000000e+00
  %935 = select i1 %932, float 0.000000e+00, float 1.000000e+00
  %936 = select i1 %933, float 0.000000e+00, float 1.000000e+00
  %937 = fmul fast float %925, 0x3FB3D07220000000
  %938 = fmul fast float %926, 0x3FB3D07220000000
  %939 = fmul fast float %927, 0x3FB3D07220000000
  %940 = fadd fast float %925, 0x3FAC28F5C0000000
  %941 = fadd fast float %926, 0x3FAC28F5C0000000
  %942 = fadd fast float %927, 0x3FAC28F5C0000000
  %943 = fmul fast float %940, 0x3FEE54EDE0000000
  %944 = fmul fast float %941, 0x3FEE54EDE0000000
  %945 = fmul fast float %942, 0x3FEE54EDE0000000
  %946 = call float @dx.op.unary.f32(i32 23, float %943)  ; Log(value)
  %947 = call float @dx.op.unary.f32(i32 23, float %944)  ; Log(value)
  %948 = call float @dx.op.unary.f32(i32 23, float %945)  ; Log(value)
  %949 = fmul fast float %946, 0x4003333340000000
  %950 = fmul fast float %947, 0x4003333340000000
  %951 = fmul fast float %948, 0x4003333340000000
  %952 = call float @dx.op.unary.f32(i32 21, float %949)  ; Exp(value)
  %953 = call float @dx.op.unary.f32(i32 21, float %950)  ; Exp(value)
  %954 = call float @dx.op.unary.f32(i32 21, float %951)  ; Exp(value)
  %955 = fsub fast float %937, %952
  %956 = fsub fast float %938, %953
  %957 = fsub fast float %939, %954
  %958 = fmul fast float %955, %934
  %959 = fmul fast float %956, %935
  %960 = fmul fast float %957, %936
  %961 = fadd fast float %958, %952
  %962 = fadd fast float %959, %953
  %963 = fadd fast float %960, %954
  br label %1032

; <label>:964                                     ; preds = %917
  %965 = fadd fast float %6, 1.000000e+00
  %966 = fadd fast float %7, 1.000000e+00
  %967 = fsub fast float 1.000000e+00, %6
  %968 = fmul fast float %10, %965
  %969 = fmul fast float %10, %966
  %970 = fmul fast float %10, %967
  %971 = fmul fast float %968, %925
  %972 = fmul fast float %969, %926
  %973 = fmul fast float %970, %927
  %974 = fcmp fast ult float %11, 5.000000e-01
  br i1 %974, label %1000, label %975

; <label>:975                                     ; preds = %964
  %976 = fmul fast float %971, 0x4004147AE0000000
  %977 = fmul fast float %972, 0x4004147AE0000000
  %978 = fmul fast float %973, 0x4004147AE0000000
  %979 = fadd fast float %976, 0x3F9EB851E0000000
  %980 = fadd fast float %977, 0x3F9EB851E0000000
  %981 = fadd fast float %978, 0x3F9EB851E0000000
  %982 = fmul fast float %979, %971
  %983 = fmul fast float %980, %972
  %984 = fmul fast float %981, %973
  %985 = fmul fast float %971, 0x400370A3E0000000
  %986 = fmul fast float %972, 0x400370A3E0000000
  %987 = fmul fast float %973, 0x400370A3E0000000
  %988 = fadd fast float %985, 0x3FE2E147A0000000
  %989 = fadd fast float %986, 0x3FE2E147A0000000
  %990 = fadd fast float %987, 0x3FE2E147A0000000
  %991 = fmul fast float %988, %971
  %992 = fmul fast float %989, %972
  %993 = fmul fast float %990, %973
  %994 = fadd fast float %991, 0x3FC1EB8520000000
  %995 = fadd fast float %992, 0x3FC1EB8520000000
  %996 = fadd fast float %993, 0x3FC1EB8520000000
  %997 = fdiv fast float %982, %994
  %998 = fdiv fast float %983, %995
  %999 = fdiv fast float %984, %996
  br label %1000

; <label>:1000                                    ; preds = %975, %964
  %1001 = phi float [ %997, %975 ], [ %971, %964 ]
  %1002 = phi float [ %998, %975 ], [ %972, %964 ]
  %1003 = phi float [ %999, %975 ], [ %973, %964 ]
  %1004 = call float @dx.op.unary.f32(i32 7, float %1001)  ; Saturate(value)
  %1005 = call float @dx.op.unary.f32(i32 7, float %1002)  ; Saturate(value)
  %1006 = call float @dx.op.unary.f32(i32 7, float %1003)  ; Saturate(value)
  %1007 = call float @dx.op.dot3.f32(i32 55, float %1004, float %1005, float %1006, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1008 = fsub fast float %1004, %1007
  %1009 = fsub fast float %1005, %1007
  %1010 = fsub fast float %1006, %1007
  %1011 = fmul fast float %1008, %9
  %1012 = fmul fast float %1009, %9
  %1013 = fmul fast float %1010, %9
  %1014 = fadd fast float %1011, %1007
  %1015 = fadd fast float %1012, %1007
  %1016 = fadd fast float %1013, %1007
  %1017 = call float @dx.op.unary.f32(i32 7, float %1014)  ; Saturate(value)
  %1018 = call float @dx.op.unary.f32(i32 7, float %1015)  ; Saturate(value)
  %1019 = call float @dx.op.unary.f32(i32 7, float %1016)  ; Saturate(value)
  %1020 = fadd fast float %1017, 0xBFC70A3D80000000
  %1021 = fadd fast float %1018, 0xBFC70A3D80000000
  %1022 = fadd fast float %1019, 0xBFC70A3D80000000
  %1023 = fmul fast float %1020, %8
  %1024 = fmul fast float %1021, %8
  %1025 = fmul fast float %1022, %8
  %1026 = fadd fast float %1023, 0x3FC70A3D80000000
  %1027 = fadd fast float %1024, 0x3FC70A3D80000000
  %1028 = fadd fast float %1025, 0x3FC70A3D80000000
  %1029 = call float @dx.op.unary.f32(i32 7, float %1026)  ; Saturate(value)
  %1030 = call float @dx.op.unary.f32(i32 7, float %1027)  ; Saturate(value)
  %1031 = call float @dx.op.unary.f32(i32 7, float %1028)  ; Saturate(value)
  br label %1032

; <label>:1032                                    ; preds = %1000, %930
  %1033 = phi float [ %961, %930 ], [ %1029, %1000 ]
  %1034 = phi float [ %962, %930 ], [ %1030, %1000 ]
  %1035 = phi float [ %963, %930 ], [ %1031, %1000 ]
  %1036 = add i32 %725, -1
  %1037 = call i32 @dx.op.binary.i32(i32 37, i32 %1036, i32 0)  ; IMax(a,b)
  %1038 = call i32 @dx.op.binary.i32(i32 37, i32 %36, i32 0)  ; IMax(a,b)
  %1039 = call i32 @dx.op.binary.i32(i32 38, i32 %1037, i32 %31)  ; IMin(a,b)
  %1040 = call i32 @dx.op.binary.i32(i32 38, i32 %1038, i32 %32)  ; IMin(a,b)
  %1041 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1039, i32 %1040, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1042 = extractvalue %dx.types.ResRet.f32 %1041, 0
  %1043 = extractvalue %dx.types.ResRet.f32 %1041, 1
  %1044 = extractvalue %dx.types.ResRet.f32 %1041, 2
  %1045 = extractvalue %dx.types.ResRet.f32 %1041, 3
  %1046 = fcmp fast olt float %1045, 0.000000e+00
  br i1 %1046, label %1047, label %1081

; <label>:1047                                    ; preds = %1032
  %1048 = fcmp fast ogt float %1042, 0x3FA4B5DCC0000000
  %1049 = fcmp fast ogt float %1043, 0x3FA4B5DCC0000000
  %1050 = fcmp fast ogt float %1044, 0x3FA4B5DCC0000000
  %1051 = select i1 %1048, float 0.000000e+00, float 1.000000e+00
  %1052 = select i1 %1049, float 0.000000e+00, float 1.000000e+00
  %1053 = select i1 %1050, float 0.000000e+00, float 1.000000e+00
  %1054 = fmul fast float %1042, 0x3FB3D07220000000
  %1055 = fmul fast float %1043, 0x3FB3D07220000000
  %1056 = fmul fast float %1044, 0x3FB3D07220000000
  %1057 = fadd fast float %1042, 0x3FAC28F5C0000000
  %1058 = fadd fast float %1043, 0x3FAC28F5C0000000
  %1059 = fadd fast float %1044, 0x3FAC28F5C0000000
  %1060 = fmul fast float %1057, 0x3FEE54EDE0000000
  %1061 = fmul fast float %1058, 0x3FEE54EDE0000000
  %1062 = fmul fast float %1059, 0x3FEE54EDE0000000
  %1063 = call float @dx.op.unary.f32(i32 23, float %1060)  ; Log(value)
  %1064 = call float @dx.op.unary.f32(i32 23, float %1061)  ; Log(value)
  %1065 = call float @dx.op.unary.f32(i32 23, float %1062)  ; Log(value)
  %1066 = fmul fast float %1063, 0x4003333340000000
  %1067 = fmul fast float %1064, 0x4003333340000000
  %1068 = fmul fast float %1065, 0x4003333340000000
  %1069 = call float @dx.op.unary.f32(i32 21, float %1066)  ; Exp(value)
  %1070 = call float @dx.op.unary.f32(i32 21, float %1067)  ; Exp(value)
  %1071 = call float @dx.op.unary.f32(i32 21, float %1068)  ; Exp(value)
  %1072 = fsub fast float %1054, %1069
  %1073 = fsub fast float %1055, %1070
  %1074 = fsub fast float %1056, %1071
  %1075 = fmul fast float %1072, %1051
  %1076 = fmul fast float %1073, %1052
  %1077 = fmul fast float %1074, %1053
  %1078 = fadd fast float %1075, %1069
  %1079 = fadd fast float %1076, %1070
  %1080 = fadd fast float %1077, %1071
  br label %1149

; <label>:1081                                    ; preds = %1032
  %1082 = fadd fast float %6, 1.000000e+00
  %1083 = fadd fast float %7, 1.000000e+00
  %1084 = fsub fast float 1.000000e+00, %6
  %1085 = fmul fast float %10, %1082
  %1086 = fmul fast float %10, %1083
  %1087 = fmul fast float %10, %1084
  %1088 = fmul fast float %1085, %1042
  %1089 = fmul fast float %1086, %1043
  %1090 = fmul fast float %1087, %1044
  %1091 = fcmp fast ult float %11, 5.000000e-01
  br i1 %1091, label %1117, label %1092

; <label>:1092                                    ; preds = %1081
  %1093 = fmul fast float %1088, 0x4004147AE0000000
  %1094 = fmul fast float %1089, 0x4004147AE0000000
  %1095 = fmul fast float %1090, 0x4004147AE0000000
  %1096 = fadd fast float %1093, 0x3F9EB851E0000000
  %1097 = fadd fast float %1094, 0x3F9EB851E0000000
  %1098 = fadd fast float %1095, 0x3F9EB851E0000000
  %1099 = fmul fast float %1096, %1088
  %1100 = fmul fast float %1097, %1089
  %1101 = fmul fast float %1098, %1090
  %1102 = fmul fast float %1088, 0x400370A3E0000000
  %1103 = fmul fast float %1089, 0x400370A3E0000000
  %1104 = fmul fast float %1090, 0x400370A3E0000000
  %1105 = fadd fast float %1102, 0x3FE2E147A0000000
  %1106 = fadd fast float %1103, 0x3FE2E147A0000000
  %1107 = fadd fast float %1104, 0x3FE2E147A0000000
  %1108 = fmul fast float %1105, %1088
  %1109 = fmul fast float %1106, %1089
  %1110 = fmul fast float %1107, %1090
  %1111 = fadd fast float %1108, 0x3FC1EB8520000000
  %1112 = fadd fast float %1109, 0x3FC1EB8520000000
  %1113 = fadd fast float %1110, 0x3FC1EB8520000000
  %1114 = fdiv fast float %1099, %1111
  %1115 = fdiv fast float %1100, %1112
  %1116 = fdiv fast float %1101, %1113
  br label %1117

; <label>:1117                                    ; preds = %1092, %1081
  %1118 = phi float [ %1114, %1092 ], [ %1088, %1081 ]
  %1119 = phi float [ %1115, %1092 ], [ %1089, %1081 ]
  %1120 = phi float [ %1116, %1092 ], [ %1090, %1081 ]
  %1121 = call float @dx.op.unary.f32(i32 7, float %1118)  ; Saturate(value)
  %1122 = call float @dx.op.unary.f32(i32 7, float %1119)  ; Saturate(value)
  %1123 = call float @dx.op.unary.f32(i32 7, float %1120)  ; Saturate(value)
  %1124 = call float @dx.op.dot3.f32(i32 55, float %1121, float %1122, float %1123, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1125 = fsub fast float %1121, %1124
  %1126 = fsub fast float %1122, %1124
  %1127 = fsub fast float %1123, %1124
  %1128 = fmul fast float %1125, %9
  %1129 = fmul fast float %1126, %9
  %1130 = fmul fast float %1127, %9
  %1131 = fadd fast float %1128, %1124
  %1132 = fadd fast float %1129, %1124
  %1133 = fadd fast float %1130, %1124
  %1134 = call float @dx.op.unary.f32(i32 7, float %1131)  ; Saturate(value)
  %1135 = call float @dx.op.unary.f32(i32 7, float %1132)  ; Saturate(value)
  %1136 = call float @dx.op.unary.f32(i32 7, float %1133)  ; Saturate(value)
  %1137 = fadd fast float %1134, 0xBFC70A3D80000000
  %1138 = fadd fast float %1135, 0xBFC70A3D80000000
  %1139 = fadd fast float %1136, 0xBFC70A3D80000000
  %1140 = fmul fast float %1137, %8
  %1141 = fmul fast float %1138, %8
  %1142 = fmul fast float %1139, %8
  %1143 = fadd fast float %1140, 0x3FC70A3D80000000
  %1144 = fadd fast float %1141, 0x3FC70A3D80000000
  %1145 = fadd fast float %1142, 0x3FC70A3D80000000
  %1146 = call float @dx.op.unary.f32(i32 7, float %1143)  ; Saturate(value)
  %1147 = call float @dx.op.unary.f32(i32 7, float %1144)  ; Saturate(value)
  %1148 = call float @dx.op.unary.f32(i32 7, float %1145)  ; Saturate(value)
  br label %1149

; <label>:1149                                    ; preds = %1117, %1047
  %1150 = phi float [ %1078, %1047 ], [ %1146, %1117 ]
  %1151 = phi float [ %1079, %1047 ], [ %1147, %1117 ]
  %1152 = phi float [ %1080, %1047 ], [ %1148, %1117 ]
  %1153 = add i32 %725, 1
  %1154 = call i32 @dx.op.binary.i32(i32 37, i32 %1153, i32 0)  ; IMax(a,b)
  %1155 = call i32 @dx.op.binary.i32(i32 38, i32 %1154, i32 %31)  ; IMin(a,b)
  %1156 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1155, i32 %1040, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1157 = extractvalue %dx.types.ResRet.f32 %1156, 0
  %1158 = extractvalue %dx.types.ResRet.f32 %1156, 1
  %1159 = extractvalue %dx.types.ResRet.f32 %1156, 2
  %1160 = extractvalue %dx.types.ResRet.f32 %1156, 3
  %1161 = fcmp fast olt float %1160, 0.000000e+00
  br i1 %1161, label %1162, label %1196

; <label>:1162                                    ; preds = %1149
  %1163 = fcmp fast ogt float %1157, 0x3FA4B5DCC0000000
  %1164 = fcmp fast ogt float %1158, 0x3FA4B5DCC0000000
  %1165 = fcmp fast ogt float %1159, 0x3FA4B5DCC0000000
  %1166 = select i1 %1163, float 0.000000e+00, float 1.000000e+00
  %1167 = select i1 %1164, float 0.000000e+00, float 1.000000e+00
  %1168 = select i1 %1165, float 0.000000e+00, float 1.000000e+00
  %1169 = fmul fast float %1157, 0x3FB3D07220000000
  %1170 = fmul fast float %1158, 0x3FB3D07220000000
  %1171 = fmul fast float %1159, 0x3FB3D07220000000
  %1172 = fadd fast float %1157, 0x3FAC28F5C0000000
  %1173 = fadd fast float %1158, 0x3FAC28F5C0000000
  %1174 = fadd fast float %1159, 0x3FAC28F5C0000000
  %1175 = fmul fast float %1172, 0x3FEE54EDE0000000
  %1176 = fmul fast float %1173, 0x3FEE54EDE0000000
  %1177 = fmul fast float %1174, 0x3FEE54EDE0000000
  %1178 = call float @dx.op.unary.f32(i32 23, float %1175)  ; Log(value)
  %1179 = call float @dx.op.unary.f32(i32 23, float %1176)  ; Log(value)
  %1180 = call float @dx.op.unary.f32(i32 23, float %1177)  ; Log(value)
  %1181 = fmul fast float %1178, 0x4003333340000000
  %1182 = fmul fast float %1179, 0x4003333340000000
  %1183 = fmul fast float %1180, 0x4003333340000000
  %1184 = call float @dx.op.unary.f32(i32 21, float %1181)  ; Exp(value)
  %1185 = call float @dx.op.unary.f32(i32 21, float %1182)  ; Exp(value)
  %1186 = call float @dx.op.unary.f32(i32 21, float %1183)  ; Exp(value)
  %1187 = fsub fast float %1169, %1184
  %1188 = fsub fast float %1170, %1185
  %1189 = fsub fast float %1171, %1186
  %1190 = fmul fast float %1187, %1166
  %1191 = fmul fast float %1188, %1167
  %1192 = fmul fast float %1189, %1168
  %1193 = fadd fast float %1190, %1184
  %1194 = fadd fast float %1191, %1185
  %1195 = fadd fast float %1192, %1186
  br label %1264

; <label>:1196                                    ; preds = %1149
  %1197 = fadd fast float %6, 1.000000e+00
  %1198 = fadd fast float %7, 1.000000e+00
  %1199 = fsub fast float 1.000000e+00, %6
  %1200 = fmul fast float %10, %1197
  %1201 = fmul fast float %10, %1198
  %1202 = fmul fast float %10, %1199
  %1203 = fmul fast float %1200, %1157
  %1204 = fmul fast float %1201, %1158
  %1205 = fmul fast float %1202, %1159
  %1206 = fcmp fast ult float %11, 5.000000e-01
  br i1 %1206, label %1232, label %1207

; <label>:1207                                    ; preds = %1196
  %1208 = fmul fast float %1203, 0x4004147AE0000000
  %1209 = fmul fast float %1204, 0x4004147AE0000000
  %1210 = fmul fast float %1205, 0x4004147AE0000000
  %1211 = fadd fast float %1208, 0x3F9EB851E0000000
  %1212 = fadd fast float %1209, 0x3F9EB851E0000000
  %1213 = fadd fast float %1210, 0x3F9EB851E0000000
  %1214 = fmul fast float %1211, %1203
  %1215 = fmul fast float %1212, %1204
  %1216 = fmul fast float %1213, %1205
  %1217 = fmul fast float %1203, 0x400370A3E0000000
  %1218 = fmul fast float %1204, 0x400370A3E0000000
  %1219 = fmul fast float %1205, 0x400370A3E0000000
  %1220 = fadd fast float %1217, 0x3FE2E147A0000000
  %1221 = fadd fast float %1218, 0x3FE2E147A0000000
  %1222 = fadd fast float %1219, 0x3FE2E147A0000000
  %1223 = fmul fast float %1220, %1203
  %1224 = fmul fast float %1221, %1204
  %1225 = fmul fast float %1222, %1205
  %1226 = fadd fast float %1223, 0x3FC1EB8520000000
  %1227 = fadd fast float %1224, 0x3FC1EB8520000000
  %1228 = fadd fast float %1225, 0x3FC1EB8520000000
  %1229 = fdiv fast float %1214, %1226
  %1230 = fdiv fast float %1215, %1227
  %1231 = fdiv fast float %1216, %1228
  br label %1232

; <label>:1232                                    ; preds = %1207, %1196
  %1233 = phi float [ %1229, %1207 ], [ %1203, %1196 ]
  %1234 = phi float [ %1230, %1207 ], [ %1204, %1196 ]
  %1235 = phi float [ %1231, %1207 ], [ %1205, %1196 ]
  %1236 = call float @dx.op.unary.f32(i32 7, float %1233)  ; Saturate(value)
  %1237 = call float @dx.op.unary.f32(i32 7, float %1234)  ; Saturate(value)
  %1238 = call float @dx.op.unary.f32(i32 7, float %1235)  ; Saturate(value)
  %1239 = call float @dx.op.dot3.f32(i32 55, float %1236, float %1237, float %1238, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1240 = fsub fast float %1236, %1239
  %1241 = fsub fast float %1237, %1239
  %1242 = fsub fast float %1238, %1239
  %1243 = fmul fast float %1240, %9
  %1244 = fmul fast float %1241, %9
  %1245 = fmul fast float %1242, %9
  %1246 = fadd fast float %1243, %1239
  %1247 = fadd fast float %1244, %1239
  %1248 = fadd fast float %1245, %1239
  %1249 = call float @dx.op.unary.f32(i32 7, float %1246)  ; Saturate(value)
  %1250 = call float @dx.op.unary.f32(i32 7, float %1247)  ; Saturate(value)
  %1251 = call float @dx.op.unary.f32(i32 7, float %1248)  ; Saturate(value)
  %1252 = fadd fast float %1249, 0xBFC70A3D80000000
  %1253 = fadd fast float %1250, 0xBFC70A3D80000000
  %1254 = fadd fast float %1251, 0xBFC70A3D80000000
  %1255 = fmul fast float %1252, %8
  %1256 = fmul fast float %1253, %8
  %1257 = fmul fast float %1254, %8
  %1258 = fadd fast float %1255, 0x3FC70A3D80000000
  %1259 = fadd fast float %1256, 0x3FC70A3D80000000
  %1260 = fadd fast float %1257, 0x3FC70A3D80000000
  %1261 = call float @dx.op.unary.f32(i32 7, float %1258)  ; Saturate(value)
  %1262 = call float @dx.op.unary.f32(i32 7, float %1259)  ; Saturate(value)
  %1263 = call float @dx.op.unary.f32(i32 7, float %1260)  ; Saturate(value)
  br label %1264

; <label>:1264                                    ; preds = %1232, %1162
  %1265 = phi float [ %1193, %1162 ], [ %1261, %1232 ]
  %1266 = phi float [ %1194, %1162 ], [ %1262, %1232 ]
  %1267 = phi float [ %1195, %1162 ], [ %1263, %1232 ]
  %1268 = call float @dx.op.binary.f32(i32 36, float %1150, float %1265)  ; FMin(a,b)
  %1269 = call float @dx.op.binary.f32(i32 36, float %1151, float %1266)  ; FMin(a,b)
  %1270 = call float @dx.op.binary.f32(i32 36, float %1152, float %1267)  ; FMin(a,b)
  %1271 = call float @dx.op.binary.f32(i32 36, float %918, float %1033)  ; FMin(a,b)
  %1272 = call float @dx.op.binary.f32(i32 36, float %919, float %1034)  ; FMin(a,b)
  %1273 = call float @dx.op.binary.f32(i32 36, float %920, float %1035)  ; FMin(a,b)
  %1274 = call float @dx.op.binary.f32(i32 36, float %1271, float %1268)  ; FMin(a,b)
  %1275 = call float @dx.op.binary.f32(i32 36, float %1272, float %1269)  ; FMin(a,b)
  %1276 = call float @dx.op.binary.f32(i32 36, float %1273, float %1270)  ; FMin(a,b)
  %1277 = call float @dx.op.binary.f32(i32 36, float %799, float %1274)  ; FMin(a,b)
  %1278 = call float @dx.op.binary.f32(i32 36, float %800, float %1275)  ; FMin(a,b)
  %1279 = call float @dx.op.binary.f32(i32 36, float %801, float %1276)  ; FMin(a,b)
  %1280 = call float @dx.op.binary.f32(i32 35, float %1150, float %1265)  ; FMax(a,b)
  %1281 = call float @dx.op.binary.f32(i32 35, float %1151, float %1266)  ; FMax(a,b)
  %1282 = call float @dx.op.binary.f32(i32 35, float %1152, float %1267)  ; FMax(a,b)
  %1283 = call float @dx.op.binary.f32(i32 35, float %918, float %1033)  ; FMax(a,b)
  %1284 = call float @dx.op.binary.f32(i32 35, float %919, float %1034)  ; FMax(a,b)
  %1285 = call float @dx.op.binary.f32(i32 35, float %920, float %1035)  ; FMax(a,b)
  %1286 = call float @dx.op.binary.f32(i32 35, float %1283, float %1280)  ; FMax(a,b)
  %1287 = call float @dx.op.binary.f32(i32 35, float %1284, float %1281)  ; FMax(a,b)
  %1288 = call float @dx.op.binary.f32(i32 35, float %1285, float %1282)  ; FMax(a,b)
  %1289 = call float @dx.op.binary.f32(i32 35, float %799, float %1286)  ; FMax(a,b)
  %1290 = call float @dx.op.binary.f32(i32 35, float %800, float %1287)  ; FMax(a,b)
  %1291 = call float @dx.op.binary.f32(i32 35, float %801, float %1288)  ; FMax(a,b)
  %1292 = fsub fast float %1289, %1277
  %1293 = fsub fast float %1290, %1278
  %1294 = fsub fast float %1291, %1279
  %1295 = call float @dx.op.unary.f32(i32 6, float %1292)  ; FAbs(value)
  %1296 = call float @dx.op.unary.f32(i32 6, float %1293)  ; FAbs(value)
  %1297 = call float @dx.op.unary.f32(i32 6, float %1294)  ; FAbs(value)
  %1298 = call float @dx.op.binary.f32(i32 35, float %1296, float %1297)  ; FMax(a,b)
  %1299 = call float @dx.op.binary.f32(i32 35, float %1295, float %1298)  ; FMax(a,b)
  %1300 = call float @dx.op.binary.f32(i32 35, float %1290, float %1291)  ; FMax(a,b)
  %1301 = call float @dx.op.binary.f32(i32 35, float %1289, float %1300)  ; FMax(a,b)
  %1302 = fmul fast float %1301, 1.250000e-01
  %1303 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1302)  ; FMax(a,b)
  %1304 = fcmp fast ogt float %1299, %1303
  br i1 %1304, label %1305, label %1367

; <label>:1305                                    ; preds = %1264
  %1306 = fsub fast float %918, %1033
  %1307 = fsub fast float %919, %1034
  %1308 = fsub fast float %920, %1035
  %1309 = call float @dx.op.unary.f32(i32 6, float %1306)  ; FAbs(value)
  %1310 = call float @dx.op.unary.f32(i32 6, float %1307)  ; FAbs(value)
  %1311 = call float @dx.op.unary.f32(i32 6, float %1308)  ; FAbs(value)
  %1312 = call float @dx.op.binary.f32(i32 35, float %1310, float %1311)  ; FMax(a,b)
  %1313 = call float @dx.op.binary.f32(i32 35, float %1309, float %1312)  ; FMax(a,b)
  %1314 = fsub fast float %1150, %1265
  %1315 = fsub fast float %1151, %1266
  %1316 = fsub fast float %1152, %1267
  %1317 = call float @dx.op.unary.f32(i32 6, float %1314)  ; FAbs(value)
  %1318 = call float @dx.op.unary.f32(i32 6, float %1315)  ; FAbs(value)
  %1319 = call float @dx.op.unary.f32(i32 6, float %1316)  ; FAbs(value)
  %1320 = call float @dx.op.binary.f32(i32 35, float %1318, float %1319)  ; FMax(a,b)
  %1321 = call float @dx.op.binary.f32(i32 35, float %1317, float %1320)  ; FMax(a,b)
  %1322 = fcmp fast olt float %1313, %1321
  %1323 = select i1 %1322, float %918, float %1150
  %1324 = select i1 %1322, float %919, float %1151
  %1325 = select i1 %1322, float %920, float %1152
  %1326 = select i1 %1322, float %1033, float %1265
  %1327 = select i1 %1322, float %1034, float %1266
  %1328 = select i1 %1322, float %1035, float %1267
  %1329 = fsub fast float %799, %1326
  %1330 = fsub fast float %800, %1327
  %1331 = fsub fast float %801, %1328
  %1332 = fsub fast float %799, %1323
  %1333 = fsub fast float %800, %1324
  %1334 = fsub fast float %801, %1325
  %1335 = call float @dx.op.dot3.f32(i32 55, float %1332, float %1333, float %1334, float %1329, float %1330, float %1331)  ; Dot3(ax,ay,az,bx,by,bz)
  %1336 = fcmp fast ogt float %1335, 0.000000e+00
  br i1 %1336, label %1337, label %1348

; <label>:1337                                    ; preds = %1305
  %1338 = fsub fast float %1323, %1326
  %1339 = fsub fast float %1324, %1327
  %1340 = fsub fast float %1325, %1328
  %1341 = call float @dx.op.unary.f32(i32 6, float %1338)  ; FAbs(value)
  %1342 = call float @dx.op.unary.f32(i32 6, float %1339)  ; FAbs(value)
  %1343 = call float @dx.op.unary.f32(i32 6, float %1340)  ; FAbs(value)
  %1344 = call float @dx.op.binary.f32(i32 35, float %1342, float %1343)  ; FMax(a,b)
  %1345 = call float @dx.op.binary.f32(i32 35, float %1341, float %1344)  ; FMax(a,b)
  %1346 = fmul fast float %1299, 2.500000e-01
  %1347 = fcmp fast olt float %1345, %1346
  br label %1348

; <label>:1348                                    ; preds = %1337, %1305
  %1349 = phi i1 [ false, %1305 ], [ %1347, %1337 ]
  %1350 = select i1 %1349, float 5.000000e-01, float 1.000000e+00
  %1351 = fmul fast float %1350, %3
  %1352 = fadd fast float %1323, %1326
  %1353 = fadd fast float %1324, %1327
  %1354 = fadd fast float %1325, %1328
  %1355 = fmul fast float %1352, 5.000000e-01
  %1356 = fmul fast float %1353, 5.000000e-01
  %1357 = fmul fast float %1354, 5.000000e-01
  %1358 = fsub fast float %1355, %799
  %1359 = fsub fast float %1356, %800
  %1360 = fsub fast float %1357, %801
  %1361 = fmul fast float %1351, %1358
  %1362 = fmul fast float %1351, %1359
  %1363 = fmul fast float %1351, %1360
  %1364 = fadd fast float %1361, %799
  %1365 = fadd fast float %1362, %800
  %1366 = fadd fast float %1363, %801
  br label %1367

; <label>:1367                                    ; preds = %1348, %1264, %770
  %1368 = phi float [ %1364, %1348 ], [ %799, %1264 ], [ %799, %770 ]
  %1369 = phi float [ %1365, %1348 ], [ %800, %1264 ], [ %800, %770 ]
  %1370 = phi float [ %1366, %1348 ], [ %801, %1264 ], [ %801, %770 ]
  %1371 = fcmp fast ogt float %1368, 0x3F69A5C380000000
  %1372 = fcmp fast ogt float %1369, 0x3F69A5C380000000
  %1373 = fcmp fast ogt float %1370, 0x3F69A5C380000000
  %1374 = select i1 %1371, float 0.000000e+00, float 1.000000e+00
  %1375 = select i1 %1372, float 0.000000e+00, float 1.000000e+00
  %1376 = select i1 %1373, float 0.000000e+00, float 1.000000e+00
  %1377 = fmul fast float %1368, 0x4029D70A40000000
  %1378 = fmul fast float %1369, 0x4029D70A40000000
  %1379 = fmul fast float %1370, 0x4029D70A40000000
  %1380 = call float @dx.op.binary.f32(i32 35, float %1368, float 0.000000e+00)  ; FMax(a,b)
  %1381 = call float @dx.op.binary.f32(i32 35, float %1369, float 0.000000e+00)  ; FMax(a,b)
  %1382 = call float @dx.op.binary.f32(i32 35, float %1370, float 0.000000e+00)  ; FMax(a,b)
  %1383 = call float @dx.op.unary.f32(i32 23, float %1380)  ; Log(value)
  %1384 = call float @dx.op.unary.f32(i32 23, float %1381)  ; Log(value)
  %1385 = call float @dx.op.unary.f32(i32 23, float %1382)  ; Log(value)
  %1386 = fmul fast float %1383, 0x3FDAAAAAA0000000
  %1387 = fmul fast float %1384, 0x3FDAAAAAA0000000
  %1388 = fmul fast float %1385, 0x3FDAAAAAA0000000
  %1389 = call float @dx.op.unary.f32(i32 21, float %1386)  ; Exp(value)
  %1390 = call float @dx.op.unary.f32(i32 21, float %1387)  ; Exp(value)
  %1391 = call float @dx.op.unary.f32(i32 21, float %1388)  ; Exp(value)
  %1392 = fmul fast float %1389, 0x3FF0E147A0000000
  %1393 = fmul fast float %1390, 0x3FF0E147A0000000
  %1394 = fmul fast float %1391, 0x3FF0E147A0000000
  %1395 = fadd fast float %1392, 0xBFAC28F5C0000000
  %1396 = fadd fast float %1393, 0xBFAC28F5C0000000
  %1397 = fadd fast float %1394, 0xBFAC28F5C0000000
  %1398 = fsub fast float %1377, %1395
  %1399 = fsub fast float %1378, %1396
  %1400 = fsub fast float %1379, %1397
  %1401 = fmul fast float %1398, %1374
  %1402 = fmul fast float %1399, %1375
  %1403 = fmul fast float %1400, %1376
  %1404 = fadd fast float %1401, %1395
  %1405 = fadd fast float %1402, %1396
  %1406 = fadd fast float %1403, %1397
  br label %1407

; <label>:1407                                    ; preds = %1367, %732
  %1408 = phi float [ %727, %732 ], [ %1404, %1367 ]
  %1409 = phi float [ %728, %732 ], [ %1405, %1367 ]
  %1410 = phi float [ %729, %732 ], [ %1406, %1367 ]
  %1411 = phi float [ %733, %732 ], [ %730, %1367 ]
  %1412 = add i32 %28, 1
  %1413 = call i32 @dx.op.binary.i32(i32 37, i32 %1412, i32 0)  ; IMax(a,b)
  %1414 = call i32 @dx.op.binary.i32(i32 38, i32 %1413, i32 %32)  ; IMin(a,b)
  %1415 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %35, i32 %1414, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1416 = extractvalue %dx.types.ResRet.f32 %1415, 0
  %1417 = extractvalue %dx.types.ResRet.f32 %1415, 1
  %1418 = extractvalue %dx.types.ResRet.f32 %1415, 2
  %1419 = extractvalue %dx.types.ResRet.f32 %1415, 3
  %1420 = fcmp fast olt float %1419, 0.000000e+00
  br i1 %1420, label %1421, label %1423

; <label>:1421                                    ; preds = %1407
  %1422 = fsub fast float -1.000000e+00, %1419
  br label %2096

; <label>:1423                                    ; preds = %1407
  %1424 = fadd fast float %6, 1.000000e+00
  %1425 = fadd fast float %7, 1.000000e+00
  %1426 = fsub fast float 1.000000e+00, %6
  %1427 = fmul fast float %10, %1424
  %1428 = fmul fast float %10, %1425
  %1429 = fmul fast float %10, %1426
  %1430 = fmul fast float %1427, %1416
  %1431 = fmul fast float %1428, %1417
  %1432 = fmul fast float %1429, %1418
  %1433 = fcmp fast ult float %11, 5.000000e-01
  br i1 %1433, label %1459, label %1434

; <label>:1434                                    ; preds = %1423
  %1435 = fmul fast float %1430, 0x4004147AE0000000
  %1436 = fmul fast float %1431, 0x4004147AE0000000
  %1437 = fmul fast float %1432, 0x4004147AE0000000
  %1438 = fadd fast float %1435, 0x3F9EB851E0000000
  %1439 = fadd fast float %1436, 0x3F9EB851E0000000
  %1440 = fadd fast float %1437, 0x3F9EB851E0000000
  %1441 = fmul fast float %1438, %1430
  %1442 = fmul fast float %1439, %1431
  %1443 = fmul fast float %1440, %1432
  %1444 = fmul fast float %1430, 0x400370A3E0000000
  %1445 = fmul fast float %1431, 0x400370A3E0000000
  %1446 = fmul fast float %1432, 0x400370A3E0000000
  %1447 = fadd fast float %1444, 0x3FE2E147A0000000
  %1448 = fadd fast float %1445, 0x3FE2E147A0000000
  %1449 = fadd fast float %1446, 0x3FE2E147A0000000
  %1450 = fmul fast float %1447, %1430
  %1451 = fmul fast float %1448, %1431
  %1452 = fmul fast float %1449, %1432
  %1453 = fadd fast float %1450, 0x3FC1EB8520000000
  %1454 = fadd fast float %1451, 0x3FC1EB8520000000
  %1455 = fadd fast float %1452, 0x3FC1EB8520000000
  %1456 = fdiv fast float %1441, %1453
  %1457 = fdiv fast float %1442, %1454
  %1458 = fdiv fast float %1443, %1455
  br label %1459

; <label>:1459                                    ; preds = %1434, %1423
  %1460 = phi float [ %1456, %1434 ], [ %1430, %1423 ]
  %1461 = phi float [ %1457, %1434 ], [ %1431, %1423 ]
  %1462 = phi float [ %1458, %1434 ], [ %1432, %1423 ]
  %1463 = call float @dx.op.unary.f32(i32 7, float %1460)  ; Saturate(value)
  %1464 = call float @dx.op.unary.f32(i32 7, float %1461)  ; Saturate(value)
  %1465 = call float @dx.op.unary.f32(i32 7, float %1462)  ; Saturate(value)
  %1466 = call float @dx.op.dot3.f32(i32 55, float %1463, float %1464, float %1465, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1467 = fsub fast float %1463, %1466
  %1468 = fsub fast float %1464, %1466
  %1469 = fsub fast float %1465, %1466
  %1470 = fmul fast float %1467, %9
  %1471 = fmul fast float %1468, %9
  %1472 = fmul fast float %1469, %9
  %1473 = fadd fast float %1470, %1466
  %1474 = fadd fast float %1471, %1466
  %1475 = fadd fast float %1472, %1466
  %1476 = call float @dx.op.unary.f32(i32 7, float %1473)  ; Saturate(value)
  %1477 = call float @dx.op.unary.f32(i32 7, float %1474)  ; Saturate(value)
  %1478 = call float @dx.op.unary.f32(i32 7, float %1475)  ; Saturate(value)
  %1479 = fadd fast float %1476, 0xBFC70A3D80000000
  %1480 = fadd fast float %1477, 0xBFC70A3D80000000
  %1481 = fadd fast float %1478, 0xBFC70A3D80000000
  %1482 = fmul fast float %1479, %8
  %1483 = fmul fast float %1480, %8
  %1484 = fmul fast float %1481, %8
  %1485 = fadd fast float %1482, 0x3FC70A3D80000000
  %1486 = fadd fast float %1483, 0x3FC70A3D80000000
  %1487 = fadd fast float %1484, 0x3FC70A3D80000000
  %1488 = call float @dx.op.unary.f32(i32 7, float %1485)  ; Saturate(value)
  %1489 = call float @dx.op.unary.f32(i32 7, float %1486)  ; Saturate(value)
  %1490 = call float @dx.op.unary.f32(i32 7, float %1487)  ; Saturate(value)
  %1491 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %1491, label %1492, label %2056

; <label>:1492                                    ; preds = %1459
  %1493 = add i32 %1414, -1
  %1494 = call i32 @dx.op.binary.i32(i32 37, i32 %35, i32 0)  ; IMax(a,b)
  %1495 = call i32 @dx.op.binary.i32(i32 37, i32 %1493, i32 0)  ; IMax(a,b)
  %1496 = call i32 @dx.op.binary.i32(i32 38, i32 %1494, i32 %31)  ; IMin(a,b)
  %1497 = call i32 @dx.op.binary.i32(i32 38, i32 %1495, i32 %32)  ; IMin(a,b)
  %1498 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1496, i32 %1497, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1499 = extractvalue %dx.types.ResRet.f32 %1498, 0
  %1500 = extractvalue %dx.types.ResRet.f32 %1498, 1
  %1501 = extractvalue %dx.types.ResRet.f32 %1498, 2
  %1502 = extractvalue %dx.types.ResRet.f32 %1498, 3
  %1503 = fcmp fast olt float %1502, 0.000000e+00
  br i1 %1503, label %1504, label %1538

; <label>:1504                                    ; preds = %1492
  %1505 = fcmp fast ogt float %1499, 0x3FA4B5DCC0000000
  %1506 = fcmp fast ogt float %1500, 0x3FA4B5DCC0000000
  %1507 = fcmp fast ogt float %1501, 0x3FA4B5DCC0000000
  %1508 = select i1 %1505, float 0.000000e+00, float 1.000000e+00
  %1509 = select i1 %1506, float 0.000000e+00, float 1.000000e+00
  %1510 = select i1 %1507, float 0.000000e+00, float 1.000000e+00
  %1511 = fmul fast float %1499, 0x3FB3D07220000000
  %1512 = fmul fast float %1500, 0x3FB3D07220000000
  %1513 = fmul fast float %1501, 0x3FB3D07220000000
  %1514 = fadd fast float %1499, 0x3FAC28F5C0000000
  %1515 = fadd fast float %1500, 0x3FAC28F5C0000000
  %1516 = fadd fast float %1501, 0x3FAC28F5C0000000
  %1517 = fmul fast float %1514, 0x3FEE54EDE0000000
  %1518 = fmul fast float %1515, 0x3FEE54EDE0000000
  %1519 = fmul fast float %1516, 0x3FEE54EDE0000000
  %1520 = call float @dx.op.unary.f32(i32 23, float %1517)  ; Log(value)
  %1521 = call float @dx.op.unary.f32(i32 23, float %1518)  ; Log(value)
  %1522 = call float @dx.op.unary.f32(i32 23, float %1519)  ; Log(value)
  %1523 = fmul fast float %1520, 0x4003333340000000
  %1524 = fmul fast float %1521, 0x4003333340000000
  %1525 = fmul fast float %1522, 0x4003333340000000
  %1526 = call float @dx.op.unary.f32(i32 21, float %1523)  ; Exp(value)
  %1527 = call float @dx.op.unary.f32(i32 21, float %1524)  ; Exp(value)
  %1528 = call float @dx.op.unary.f32(i32 21, float %1525)  ; Exp(value)
  %1529 = fsub fast float %1511, %1526
  %1530 = fsub fast float %1512, %1527
  %1531 = fsub fast float %1513, %1528
  %1532 = fmul fast float %1529, %1508
  %1533 = fmul fast float %1530, %1509
  %1534 = fmul fast float %1531, %1510
  %1535 = fadd fast float %1532, %1526
  %1536 = fadd fast float %1533, %1527
  %1537 = fadd fast float %1534, %1528
  br label %1606

; <label>:1538                                    ; preds = %1492
  %1539 = fadd fast float %6, 1.000000e+00
  %1540 = fadd fast float %7, 1.000000e+00
  %1541 = fsub fast float 1.000000e+00, %6
  %1542 = fmul fast float %10, %1539
  %1543 = fmul fast float %10, %1540
  %1544 = fmul fast float %10, %1541
  %1545 = fmul fast float %1542, %1499
  %1546 = fmul fast float %1543, %1500
  %1547 = fmul fast float %1544, %1501
  %1548 = fcmp fast ult float %11, 5.000000e-01
  br i1 %1548, label %1574, label %1549

; <label>:1549                                    ; preds = %1538
  %1550 = fmul fast float %1545, 0x4004147AE0000000
  %1551 = fmul fast float %1546, 0x4004147AE0000000
  %1552 = fmul fast float %1547, 0x4004147AE0000000
  %1553 = fadd fast float %1550, 0x3F9EB851E0000000
  %1554 = fadd fast float %1551, 0x3F9EB851E0000000
  %1555 = fadd fast float %1552, 0x3F9EB851E0000000
  %1556 = fmul fast float %1553, %1545
  %1557 = fmul fast float %1554, %1546
  %1558 = fmul fast float %1555, %1547
  %1559 = fmul fast float %1545, 0x400370A3E0000000
  %1560 = fmul fast float %1546, 0x400370A3E0000000
  %1561 = fmul fast float %1547, 0x400370A3E0000000
  %1562 = fadd fast float %1559, 0x3FE2E147A0000000
  %1563 = fadd fast float %1560, 0x3FE2E147A0000000
  %1564 = fadd fast float %1561, 0x3FE2E147A0000000
  %1565 = fmul fast float %1562, %1545
  %1566 = fmul fast float %1563, %1546
  %1567 = fmul fast float %1564, %1547
  %1568 = fadd fast float %1565, 0x3FC1EB8520000000
  %1569 = fadd fast float %1566, 0x3FC1EB8520000000
  %1570 = fadd fast float %1567, 0x3FC1EB8520000000
  %1571 = fdiv fast float %1556, %1568
  %1572 = fdiv fast float %1557, %1569
  %1573 = fdiv fast float %1558, %1570
  br label %1574

; <label>:1574                                    ; preds = %1549, %1538
  %1575 = phi float [ %1571, %1549 ], [ %1545, %1538 ]
  %1576 = phi float [ %1572, %1549 ], [ %1546, %1538 ]
  %1577 = phi float [ %1573, %1549 ], [ %1547, %1538 ]
  %1578 = call float @dx.op.unary.f32(i32 7, float %1575)  ; Saturate(value)
  %1579 = call float @dx.op.unary.f32(i32 7, float %1576)  ; Saturate(value)
  %1580 = call float @dx.op.unary.f32(i32 7, float %1577)  ; Saturate(value)
  %1581 = call float @dx.op.dot3.f32(i32 55, float %1578, float %1579, float %1580, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1582 = fsub fast float %1578, %1581
  %1583 = fsub fast float %1579, %1581
  %1584 = fsub fast float %1580, %1581
  %1585 = fmul fast float %1582, %9
  %1586 = fmul fast float %1583, %9
  %1587 = fmul fast float %1584, %9
  %1588 = fadd fast float %1585, %1581
  %1589 = fadd fast float %1586, %1581
  %1590 = fadd fast float %1587, %1581
  %1591 = call float @dx.op.unary.f32(i32 7, float %1588)  ; Saturate(value)
  %1592 = call float @dx.op.unary.f32(i32 7, float %1589)  ; Saturate(value)
  %1593 = call float @dx.op.unary.f32(i32 7, float %1590)  ; Saturate(value)
  %1594 = fadd fast float %1591, 0xBFC70A3D80000000
  %1595 = fadd fast float %1592, 0xBFC70A3D80000000
  %1596 = fadd fast float %1593, 0xBFC70A3D80000000
  %1597 = fmul fast float %1594, %8
  %1598 = fmul fast float %1595, %8
  %1599 = fmul fast float %1596, %8
  %1600 = fadd fast float %1597, 0x3FC70A3D80000000
  %1601 = fadd fast float %1598, 0x3FC70A3D80000000
  %1602 = fadd fast float %1599, 0x3FC70A3D80000000
  %1603 = call float @dx.op.unary.f32(i32 7, float %1600)  ; Saturate(value)
  %1604 = call float @dx.op.unary.f32(i32 7, float %1601)  ; Saturate(value)
  %1605 = call float @dx.op.unary.f32(i32 7, float %1602)  ; Saturate(value)
  br label %1606

; <label>:1606                                    ; preds = %1574, %1504
  %1607 = phi float [ %1535, %1504 ], [ %1603, %1574 ]
  %1608 = phi float [ %1536, %1504 ], [ %1604, %1574 ]
  %1609 = phi float [ %1537, %1504 ], [ %1605, %1574 ]
  %1610 = add i32 %1414, 1
  %1611 = call i32 @dx.op.binary.i32(i32 37, i32 %1610, i32 0)  ; IMax(a,b)
  %1612 = call i32 @dx.op.binary.i32(i32 38, i32 %1611, i32 %32)  ; IMin(a,b)
  %1613 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1496, i32 %1612, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1614 = extractvalue %dx.types.ResRet.f32 %1613, 0
  %1615 = extractvalue %dx.types.ResRet.f32 %1613, 1
  %1616 = extractvalue %dx.types.ResRet.f32 %1613, 2
  %1617 = extractvalue %dx.types.ResRet.f32 %1613, 3
  %1618 = fcmp fast olt float %1617, 0.000000e+00
  br i1 %1618, label %1619, label %1653

; <label>:1619                                    ; preds = %1606
  %1620 = fcmp fast ogt float %1614, 0x3FA4B5DCC0000000
  %1621 = fcmp fast ogt float %1615, 0x3FA4B5DCC0000000
  %1622 = fcmp fast ogt float %1616, 0x3FA4B5DCC0000000
  %1623 = select i1 %1620, float 0.000000e+00, float 1.000000e+00
  %1624 = select i1 %1621, float 0.000000e+00, float 1.000000e+00
  %1625 = select i1 %1622, float 0.000000e+00, float 1.000000e+00
  %1626 = fmul fast float %1614, 0x3FB3D07220000000
  %1627 = fmul fast float %1615, 0x3FB3D07220000000
  %1628 = fmul fast float %1616, 0x3FB3D07220000000
  %1629 = fadd fast float %1614, 0x3FAC28F5C0000000
  %1630 = fadd fast float %1615, 0x3FAC28F5C0000000
  %1631 = fadd fast float %1616, 0x3FAC28F5C0000000
  %1632 = fmul fast float %1629, 0x3FEE54EDE0000000
  %1633 = fmul fast float %1630, 0x3FEE54EDE0000000
  %1634 = fmul fast float %1631, 0x3FEE54EDE0000000
  %1635 = call float @dx.op.unary.f32(i32 23, float %1632)  ; Log(value)
  %1636 = call float @dx.op.unary.f32(i32 23, float %1633)  ; Log(value)
  %1637 = call float @dx.op.unary.f32(i32 23, float %1634)  ; Log(value)
  %1638 = fmul fast float %1635, 0x4003333340000000
  %1639 = fmul fast float %1636, 0x4003333340000000
  %1640 = fmul fast float %1637, 0x4003333340000000
  %1641 = call float @dx.op.unary.f32(i32 21, float %1638)  ; Exp(value)
  %1642 = call float @dx.op.unary.f32(i32 21, float %1639)  ; Exp(value)
  %1643 = call float @dx.op.unary.f32(i32 21, float %1640)  ; Exp(value)
  %1644 = fsub fast float %1626, %1641
  %1645 = fsub fast float %1627, %1642
  %1646 = fsub fast float %1628, %1643
  %1647 = fmul fast float %1644, %1623
  %1648 = fmul fast float %1645, %1624
  %1649 = fmul fast float %1646, %1625
  %1650 = fadd fast float %1647, %1641
  %1651 = fadd fast float %1648, %1642
  %1652 = fadd fast float %1649, %1643
  br label %1721

; <label>:1653                                    ; preds = %1606
  %1654 = fadd fast float %6, 1.000000e+00
  %1655 = fadd fast float %7, 1.000000e+00
  %1656 = fsub fast float 1.000000e+00, %6
  %1657 = fmul fast float %10, %1654
  %1658 = fmul fast float %10, %1655
  %1659 = fmul fast float %10, %1656
  %1660 = fmul fast float %1657, %1614
  %1661 = fmul fast float %1658, %1615
  %1662 = fmul fast float %1659, %1616
  %1663 = fcmp fast ult float %11, 5.000000e-01
  br i1 %1663, label %1689, label %1664

; <label>:1664                                    ; preds = %1653
  %1665 = fmul fast float %1660, 0x4004147AE0000000
  %1666 = fmul fast float %1661, 0x4004147AE0000000
  %1667 = fmul fast float %1662, 0x4004147AE0000000
  %1668 = fadd fast float %1665, 0x3F9EB851E0000000
  %1669 = fadd fast float %1666, 0x3F9EB851E0000000
  %1670 = fadd fast float %1667, 0x3F9EB851E0000000
  %1671 = fmul fast float %1668, %1660
  %1672 = fmul fast float %1669, %1661
  %1673 = fmul fast float %1670, %1662
  %1674 = fmul fast float %1660, 0x400370A3E0000000
  %1675 = fmul fast float %1661, 0x400370A3E0000000
  %1676 = fmul fast float %1662, 0x400370A3E0000000
  %1677 = fadd fast float %1674, 0x3FE2E147A0000000
  %1678 = fadd fast float %1675, 0x3FE2E147A0000000
  %1679 = fadd fast float %1676, 0x3FE2E147A0000000
  %1680 = fmul fast float %1677, %1660
  %1681 = fmul fast float %1678, %1661
  %1682 = fmul fast float %1679, %1662
  %1683 = fadd fast float %1680, 0x3FC1EB8520000000
  %1684 = fadd fast float %1681, 0x3FC1EB8520000000
  %1685 = fadd fast float %1682, 0x3FC1EB8520000000
  %1686 = fdiv fast float %1671, %1683
  %1687 = fdiv fast float %1672, %1684
  %1688 = fdiv fast float %1673, %1685
  br label %1689

; <label>:1689                                    ; preds = %1664, %1653
  %1690 = phi float [ %1686, %1664 ], [ %1660, %1653 ]
  %1691 = phi float [ %1687, %1664 ], [ %1661, %1653 ]
  %1692 = phi float [ %1688, %1664 ], [ %1662, %1653 ]
  %1693 = call float @dx.op.unary.f32(i32 7, float %1690)  ; Saturate(value)
  %1694 = call float @dx.op.unary.f32(i32 7, float %1691)  ; Saturate(value)
  %1695 = call float @dx.op.unary.f32(i32 7, float %1692)  ; Saturate(value)
  %1696 = call float @dx.op.dot3.f32(i32 55, float %1693, float %1694, float %1695, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1697 = fsub fast float %1693, %1696
  %1698 = fsub fast float %1694, %1696
  %1699 = fsub fast float %1695, %1696
  %1700 = fmul fast float %1697, %9
  %1701 = fmul fast float %1698, %9
  %1702 = fmul fast float %1699, %9
  %1703 = fadd fast float %1700, %1696
  %1704 = fadd fast float %1701, %1696
  %1705 = fadd fast float %1702, %1696
  %1706 = call float @dx.op.unary.f32(i32 7, float %1703)  ; Saturate(value)
  %1707 = call float @dx.op.unary.f32(i32 7, float %1704)  ; Saturate(value)
  %1708 = call float @dx.op.unary.f32(i32 7, float %1705)  ; Saturate(value)
  %1709 = fadd fast float %1706, 0xBFC70A3D80000000
  %1710 = fadd fast float %1707, 0xBFC70A3D80000000
  %1711 = fadd fast float %1708, 0xBFC70A3D80000000
  %1712 = fmul fast float %1709, %8
  %1713 = fmul fast float %1710, %8
  %1714 = fmul fast float %1711, %8
  %1715 = fadd fast float %1712, 0x3FC70A3D80000000
  %1716 = fadd fast float %1713, 0x3FC70A3D80000000
  %1717 = fadd fast float %1714, 0x3FC70A3D80000000
  %1718 = call float @dx.op.unary.f32(i32 7, float %1715)  ; Saturate(value)
  %1719 = call float @dx.op.unary.f32(i32 7, float %1716)  ; Saturate(value)
  %1720 = call float @dx.op.unary.f32(i32 7, float %1717)  ; Saturate(value)
  br label %1721

; <label>:1721                                    ; preds = %1689, %1619
  %1722 = phi float [ %1650, %1619 ], [ %1718, %1689 ]
  %1723 = phi float [ %1651, %1619 ], [ %1719, %1689 ]
  %1724 = phi float [ %1652, %1619 ], [ %1720, %1689 ]
  %1725 = add i32 %35, -1
  %1726 = call i32 @dx.op.binary.i32(i32 37, i32 %1725, i32 0)  ; IMax(a,b)
  %1727 = call i32 @dx.op.binary.i32(i32 37, i32 %1414, i32 0)  ; IMax(a,b)
  %1728 = call i32 @dx.op.binary.i32(i32 38, i32 %1726, i32 %31)  ; IMin(a,b)
  %1729 = call i32 @dx.op.binary.i32(i32 38, i32 %1727, i32 %32)  ; IMin(a,b)
  %1730 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1728, i32 %1729, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1731 = extractvalue %dx.types.ResRet.f32 %1730, 0
  %1732 = extractvalue %dx.types.ResRet.f32 %1730, 1
  %1733 = extractvalue %dx.types.ResRet.f32 %1730, 2
  %1734 = extractvalue %dx.types.ResRet.f32 %1730, 3
  %1735 = fcmp fast olt float %1734, 0.000000e+00
  br i1 %1735, label %1736, label %1770

; <label>:1736                                    ; preds = %1721
  %1737 = fcmp fast ogt float %1731, 0x3FA4B5DCC0000000
  %1738 = fcmp fast ogt float %1732, 0x3FA4B5DCC0000000
  %1739 = fcmp fast ogt float %1733, 0x3FA4B5DCC0000000
  %1740 = select i1 %1737, float 0.000000e+00, float 1.000000e+00
  %1741 = select i1 %1738, float 0.000000e+00, float 1.000000e+00
  %1742 = select i1 %1739, float 0.000000e+00, float 1.000000e+00
  %1743 = fmul fast float %1731, 0x3FB3D07220000000
  %1744 = fmul fast float %1732, 0x3FB3D07220000000
  %1745 = fmul fast float %1733, 0x3FB3D07220000000
  %1746 = fadd fast float %1731, 0x3FAC28F5C0000000
  %1747 = fadd fast float %1732, 0x3FAC28F5C0000000
  %1748 = fadd fast float %1733, 0x3FAC28F5C0000000
  %1749 = fmul fast float %1746, 0x3FEE54EDE0000000
  %1750 = fmul fast float %1747, 0x3FEE54EDE0000000
  %1751 = fmul fast float %1748, 0x3FEE54EDE0000000
  %1752 = call float @dx.op.unary.f32(i32 23, float %1749)  ; Log(value)
  %1753 = call float @dx.op.unary.f32(i32 23, float %1750)  ; Log(value)
  %1754 = call float @dx.op.unary.f32(i32 23, float %1751)  ; Log(value)
  %1755 = fmul fast float %1752, 0x4003333340000000
  %1756 = fmul fast float %1753, 0x4003333340000000
  %1757 = fmul fast float %1754, 0x4003333340000000
  %1758 = call float @dx.op.unary.f32(i32 21, float %1755)  ; Exp(value)
  %1759 = call float @dx.op.unary.f32(i32 21, float %1756)  ; Exp(value)
  %1760 = call float @dx.op.unary.f32(i32 21, float %1757)  ; Exp(value)
  %1761 = fsub fast float %1743, %1758
  %1762 = fsub fast float %1744, %1759
  %1763 = fsub fast float %1745, %1760
  %1764 = fmul fast float %1761, %1740
  %1765 = fmul fast float %1762, %1741
  %1766 = fmul fast float %1763, %1742
  %1767 = fadd fast float %1764, %1758
  %1768 = fadd fast float %1765, %1759
  %1769 = fadd fast float %1766, %1760
  br label %1838

; <label>:1770                                    ; preds = %1721
  %1771 = fadd fast float %6, 1.000000e+00
  %1772 = fadd fast float %7, 1.000000e+00
  %1773 = fsub fast float 1.000000e+00, %6
  %1774 = fmul fast float %10, %1771
  %1775 = fmul fast float %10, %1772
  %1776 = fmul fast float %10, %1773
  %1777 = fmul fast float %1774, %1731
  %1778 = fmul fast float %1775, %1732
  %1779 = fmul fast float %1776, %1733
  %1780 = fcmp fast ult float %11, 5.000000e-01
  br i1 %1780, label %1806, label %1781

; <label>:1781                                    ; preds = %1770
  %1782 = fmul fast float %1777, 0x4004147AE0000000
  %1783 = fmul fast float %1778, 0x4004147AE0000000
  %1784 = fmul fast float %1779, 0x4004147AE0000000
  %1785 = fadd fast float %1782, 0x3F9EB851E0000000
  %1786 = fadd fast float %1783, 0x3F9EB851E0000000
  %1787 = fadd fast float %1784, 0x3F9EB851E0000000
  %1788 = fmul fast float %1785, %1777
  %1789 = fmul fast float %1786, %1778
  %1790 = fmul fast float %1787, %1779
  %1791 = fmul fast float %1777, 0x400370A3E0000000
  %1792 = fmul fast float %1778, 0x400370A3E0000000
  %1793 = fmul fast float %1779, 0x400370A3E0000000
  %1794 = fadd fast float %1791, 0x3FE2E147A0000000
  %1795 = fadd fast float %1792, 0x3FE2E147A0000000
  %1796 = fadd fast float %1793, 0x3FE2E147A0000000
  %1797 = fmul fast float %1794, %1777
  %1798 = fmul fast float %1795, %1778
  %1799 = fmul fast float %1796, %1779
  %1800 = fadd fast float %1797, 0x3FC1EB8520000000
  %1801 = fadd fast float %1798, 0x3FC1EB8520000000
  %1802 = fadd fast float %1799, 0x3FC1EB8520000000
  %1803 = fdiv fast float %1788, %1800
  %1804 = fdiv fast float %1789, %1801
  %1805 = fdiv fast float %1790, %1802
  br label %1806

; <label>:1806                                    ; preds = %1781, %1770
  %1807 = phi float [ %1803, %1781 ], [ %1777, %1770 ]
  %1808 = phi float [ %1804, %1781 ], [ %1778, %1770 ]
  %1809 = phi float [ %1805, %1781 ], [ %1779, %1770 ]
  %1810 = call float @dx.op.unary.f32(i32 7, float %1807)  ; Saturate(value)
  %1811 = call float @dx.op.unary.f32(i32 7, float %1808)  ; Saturate(value)
  %1812 = call float @dx.op.unary.f32(i32 7, float %1809)  ; Saturate(value)
  %1813 = call float @dx.op.dot3.f32(i32 55, float %1810, float %1811, float %1812, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1814 = fsub fast float %1810, %1813
  %1815 = fsub fast float %1811, %1813
  %1816 = fsub fast float %1812, %1813
  %1817 = fmul fast float %1814, %9
  %1818 = fmul fast float %1815, %9
  %1819 = fmul fast float %1816, %9
  %1820 = fadd fast float %1817, %1813
  %1821 = fadd fast float %1818, %1813
  %1822 = fadd fast float %1819, %1813
  %1823 = call float @dx.op.unary.f32(i32 7, float %1820)  ; Saturate(value)
  %1824 = call float @dx.op.unary.f32(i32 7, float %1821)  ; Saturate(value)
  %1825 = call float @dx.op.unary.f32(i32 7, float %1822)  ; Saturate(value)
  %1826 = fadd fast float %1823, 0xBFC70A3D80000000
  %1827 = fadd fast float %1824, 0xBFC70A3D80000000
  %1828 = fadd fast float %1825, 0xBFC70A3D80000000
  %1829 = fmul fast float %1826, %8
  %1830 = fmul fast float %1827, %8
  %1831 = fmul fast float %1828, %8
  %1832 = fadd fast float %1829, 0x3FC70A3D80000000
  %1833 = fadd fast float %1830, 0x3FC70A3D80000000
  %1834 = fadd fast float %1831, 0x3FC70A3D80000000
  %1835 = call float @dx.op.unary.f32(i32 7, float %1832)  ; Saturate(value)
  %1836 = call float @dx.op.unary.f32(i32 7, float %1833)  ; Saturate(value)
  %1837 = call float @dx.op.unary.f32(i32 7, float %1834)  ; Saturate(value)
  br label %1838

; <label>:1838                                    ; preds = %1806, %1736
  %1839 = phi float [ %1767, %1736 ], [ %1835, %1806 ]
  %1840 = phi float [ %1768, %1736 ], [ %1836, %1806 ]
  %1841 = phi float [ %1769, %1736 ], [ %1837, %1806 ]
  %1842 = add i32 %35, 1
  %1843 = call i32 @dx.op.binary.i32(i32 37, i32 %1842, i32 0)  ; IMax(a,b)
  %1844 = call i32 @dx.op.binary.i32(i32 38, i32 %1843, i32 %31)  ; IMin(a,b)
  %1845 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1844, i32 %1729, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1846 = extractvalue %dx.types.ResRet.f32 %1845, 0
  %1847 = extractvalue %dx.types.ResRet.f32 %1845, 1
  %1848 = extractvalue %dx.types.ResRet.f32 %1845, 2
  %1849 = extractvalue %dx.types.ResRet.f32 %1845, 3
  %1850 = fcmp fast olt float %1849, 0.000000e+00
  br i1 %1850, label %1851, label %1885

; <label>:1851                                    ; preds = %1838
  %1852 = fcmp fast ogt float %1846, 0x3FA4B5DCC0000000
  %1853 = fcmp fast ogt float %1847, 0x3FA4B5DCC0000000
  %1854 = fcmp fast ogt float %1848, 0x3FA4B5DCC0000000
  %1855 = select i1 %1852, float 0.000000e+00, float 1.000000e+00
  %1856 = select i1 %1853, float 0.000000e+00, float 1.000000e+00
  %1857 = select i1 %1854, float 0.000000e+00, float 1.000000e+00
  %1858 = fmul fast float %1846, 0x3FB3D07220000000
  %1859 = fmul fast float %1847, 0x3FB3D07220000000
  %1860 = fmul fast float %1848, 0x3FB3D07220000000
  %1861 = fadd fast float %1846, 0x3FAC28F5C0000000
  %1862 = fadd fast float %1847, 0x3FAC28F5C0000000
  %1863 = fadd fast float %1848, 0x3FAC28F5C0000000
  %1864 = fmul fast float %1861, 0x3FEE54EDE0000000
  %1865 = fmul fast float %1862, 0x3FEE54EDE0000000
  %1866 = fmul fast float %1863, 0x3FEE54EDE0000000
  %1867 = call float @dx.op.unary.f32(i32 23, float %1864)  ; Log(value)
  %1868 = call float @dx.op.unary.f32(i32 23, float %1865)  ; Log(value)
  %1869 = call float @dx.op.unary.f32(i32 23, float %1866)  ; Log(value)
  %1870 = fmul fast float %1867, 0x4003333340000000
  %1871 = fmul fast float %1868, 0x4003333340000000
  %1872 = fmul fast float %1869, 0x4003333340000000
  %1873 = call float @dx.op.unary.f32(i32 21, float %1870)  ; Exp(value)
  %1874 = call float @dx.op.unary.f32(i32 21, float %1871)  ; Exp(value)
  %1875 = call float @dx.op.unary.f32(i32 21, float %1872)  ; Exp(value)
  %1876 = fsub fast float %1858, %1873
  %1877 = fsub fast float %1859, %1874
  %1878 = fsub fast float %1860, %1875
  %1879 = fmul fast float %1876, %1855
  %1880 = fmul fast float %1877, %1856
  %1881 = fmul fast float %1878, %1857
  %1882 = fadd fast float %1879, %1873
  %1883 = fadd fast float %1880, %1874
  %1884 = fadd fast float %1881, %1875
  br label %1953

; <label>:1885                                    ; preds = %1838
  %1886 = fadd fast float %6, 1.000000e+00
  %1887 = fadd fast float %7, 1.000000e+00
  %1888 = fsub fast float 1.000000e+00, %6
  %1889 = fmul fast float %10, %1886
  %1890 = fmul fast float %10, %1887
  %1891 = fmul fast float %10, %1888
  %1892 = fmul fast float %1889, %1846
  %1893 = fmul fast float %1890, %1847
  %1894 = fmul fast float %1891, %1848
  %1895 = fcmp fast ult float %11, 5.000000e-01
  br i1 %1895, label %1921, label %1896

; <label>:1896                                    ; preds = %1885
  %1897 = fmul fast float %1892, 0x4004147AE0000000
  %1898 = fmul fast float %1893, 0x4004147AE0000000
  %1899 = fmul fast float %1894, 0x4004147AE0000000
  %1900 = fadd fast float %1897, 0x3F9EB851E0000000
  %1901 = fadd fast float %1898, 0x3F9EB851E0000000
  %1902 = fadd fast float %1899, 0x3F9EB851E0000000
  %1903 = fmul fast float %1900, %1892
  %1904 = fmul fast float %1901, %1893
  %1905 = fmul fast float %1902, %1894
  %1906 = fmul fast float %1892, 0x400370A3E0000000
  %1907 = fmul fast float %1893, 0x400370A3E0000000
  %1908 = fmul fast float %1894, 0x400370A3E0000000
  %1909 = fadd fast float %1906, 0x3FE2E147A0000000
  %1910 = fadd fast float %1907, 0x3FE2E147A0000000
  %1911 = fadd fast float %1908, 0x3FE2E147A0000000
  %1912 = fmul fast float %1909, %1892
  %1913 = fmul fast float %1910, %1893
  %1914 = fmul fast float %1911, %1894
  %1915 = fadd fast float %1912, 0x3FC1EB8520000000
  %1916 = fadd fast float %1913, 0x3FC1EB8520000000
  %1917 = fadd fast float %1914, 0x3FC1EB8520000000
  %1918 = fdiv fast float %1903, %1915
  %1919 = fdiv fast float %1904, %1916
  %1920 = fdiv fast float %1905, %1917
  br label %1921

; <label>:1921                                    ; preds = %1896, %1885
  %1922 = phi float [ %1918, %1896 ], [ %1892, %1885 ]
  %1923 = phi float [ %1919, %1896 ], [ %1893, %1885 ]
  %1924 = phi float [ %1920, %1896 ], [ %1894, %1885 ]
  %1925 = call float @dx.op.unary.f32(i32 7, float %1922)  ; Saturate(value)
  %1926 = call float @dx.op.unary.f32(i32 7, float %1923)  ; Saturate(value)
  %1927 = call float @dx.op.unary.f32(i32 7, float %1924)  ; Saturate(value)
  %1928 = call float @dx.op.dot3.f32(i32 55, float %1925, float %1926, float %1927, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1929 = fsub fast float %1925, %1928
  %1930 = fsub fast float %1926, %1928
  %1931 = fsub fast float %1927, %1928
  %1932 = fmul fast float %1929, %9
  %1933 = fmul fast float %1930, %9
  %1934 = fmul fast float %1931, %9
  %1935 = fadd fast float %1932, %1928
  %1936 = fadd fast float %1933, %1928
  %1937 = fadd fast float %1934, %1928
  %1938 = call float @dx.op.unary.f32(i32 7, float %1935)  ; Saturate(value)
  %1939 = call float @dx.op.unary.f32(i32 7, float %1936)  ; Saturate(value)
  %1940 = call float @dx.op.unary.f32(i32 7, float %1937)  ; Saturate(value)
  %1941 = fadd fast float %1938, 0xBFC70A3D80000000
  %1942 = fadd fast float %1939, 0xBFC70A3D80000000
  %1943 = fadd fast float %1940, 0xBFC70A3D80000000
  %1944 = fmul fast float %1941, %8
  %1945 = fmul fast float %1942, %8
  %1946 = fmul fast float %1943, %8
  %1947 = fadd fast float %1944, 0x3FC70A3D80000000
  %1948 = fadd fast float %1945, 0x3FC70A3D80000000
  %1949 = fadd fast float %1946, 0x3FC70A3D80000000
  %1950 = call float @dx.op.unary.f32(i32 7, float %1947)  ; Saturate(value)
  %1951 = call float @dx.op.unary.f32(i32 7, float %1948)  ; Saturate(value)
  %1952 = call float @dx.op.unary.f32(i32 7, float %1949)  ; Saturate(value)
  br label %1953

; <label>:1953                                    ; preds = %1921, %1851
  %1954 = phi float [ %1882, %1851 ], [ %1950, %1921 ]
  %1955 = phi float [ %1883, %1851 ], [ %1951, %1921 ]
  %1956 = phi float [ %1884, %1851 ], [ %1952, %1921 ]
  %1957 = call float @dx.op.binary.f32(i32 36, float %1839, float %1954)  ; FMin(a,b)
  %1958 = call float @dx.op.binary.f32(i32 36, float %1840, float %1955)  ; FMin(a,b)
  %1959 = call float @dx.op.binary.f32(i32 36, float %1841, float %1956)  ; FMin(a,b)
  %1960 = call float @dx.op.binary.f32(i32 36, float %1607, float %1722)  ; FMin(a,b)
  %1961 = call float @dx.op.binary.f32(i32 36, float %1608, float %1723)  ; FMin(a,b)
  %1962 = call float @dx.op.binary.f32(i32 36, float %1609, float %1724)  ; FMin(a,b)
  %1963 = call float @dx.op.binary.f32(i32 36, float %1960, float %1957)  ; FMin(a,b)
  %1964 = call float @dx.op.binary.f32(i32 36, float %1961, float %1958)  ; FMin(a,b)
  %1965 = call float @dx.op.binary.f32(i32 36, float %1962, float %1959)  ; FMin(a,b)
  %1966 = call float @dx.op.binary.f32(i32 36, float %1488, float %1963)  ; FMin(a,b)
  %1967 = call float @dx.op.binary.f32(i32 36, float %1489, float %1964)  ; FMin(a,b)
  %1968 = call float @dx.op.binary.f32(i32 36, float %1490, float %1965)  ; FMin(a,b)
  %1969 = call float @dx.op.binary.f32(i32 35, float %1839, float %1954)  ; FMax(a,b)
  %1970 = call float @dx.op.binary.f32(i32 35, float %1840, float %1955)  ; FMax(a,b)
  %1971 = call float @dx.op.binary.f32(i32 35, float %1841, float %1956)  ; FMax(a,b)
  %1972 = call float @dx.op.binary.f32(i32 35, float %1607, float %1722)  ; FMax(a,b)
  %1973 = call float @dx.op.binary.f32(i32 35, float %1608, float %1723)  ; FMax(a,b)
  %1974 = call float @dx.op.binary.f32(i32 35, float %1609, float %1724)  ; FMax(a,b)
  %1975 = call float @dx.op.binary.f32(i32 35, float %1972, float %1969)  ; FMax(a,b)
  %1976 = call float @dx.op.binary.f32(i32 35, float %1973, float %1970)  ; FMax(a,b)
  %1977 = call float @dx.op.binary.f32(i32 35, float %1974, float %1971)  ; FMax(a,b)
  %1978 = call float @dx.op.binary.f32(i32 35, float %1488, float %1975)  ; FMax(a,b)
  %1979 = call float @dx.op.binary.f32(i32 35, float %1489, float %1976)  ; FMax(a,b)
  %1980 = call float @dx.op.binary.f32(i32 35, float %1490, float %1977)  ; FMax(a,b)
  %1981 = fsub fast float %1978, %1966
  %1982 = fsub fast float %1979, %1967
  %1983 = fsub fast float %1980, %1968
  %1984 = call float @dx.op.unary.f32(i32 6, float %1981)  ; FAbs(value)
  %1985 = call float @dx.op.unary.f32(i32 6, float %1982)  ; FAbs(value)
  %1986 = call float @dx.op.unary.f32(i32 6, float %1983)  ; FAbs(value)
  %1987 = call float @dx.op.binary.f32(i32 35, float %1985, float %1986)  ; FMax(a,b)
  %1988 = call float @dx.op.binary.f32(i32 35, float %1984, float %1987)  ; FMax(a,b)
  %1989 = call float @dx.op.binary.f32(i32 35, float %1979, float %1980)  ; FMax(a,b)
  %1990 = call float @dx.op.binary.f32(i32 35, float %1978, float %1989)  ; FMax(a,b)
  %1991 = fmul fast float %1990, 1.250000e-01
  %1992 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1991)  ; FMax(a,b)
  %1993 = fcmp fast ogt float %1988, %1992
  br i1 %1993, label %1994, label %2056

; <label>:1994                                    ; preds = %1953
  %1995 = fsub fast float %1607, %1722
  %1996 = fsub fast float %1608, %1723
  %1997 = fsub fast float %1609, %1724
  %1998 = call float @dx.op.unary.f32(i32 6, float %1995)  ; FAbs(value)
  %1999 = call float @dx.op.unary.f32(i32 6, float %1996)  ; FAbs(value)
  %2000 = call float @dx.op.unary.f32(i32 6, float %1997)  ; FAbs(value)
  %2001 = call float @dx.op.binary.f32(i32 35, float %1999, float %2000)  ; FMax(a,b)
  %2002 = call float @dx.op.binary.f32(i32 35, float %1998, float %2001)  ; FMax(a,b)
  %2003 = fsub fast float %1839, %1954
  %2004 = fsub fast float %1840, %1955
  %2005 = fsub fast float %1841, %1956
  %2006 = call float @dx.op.unary.f32(i32 6, float %2003)  ; FAbs(value)
  %2007 = call float @dx.op.unary.f32(i32 6, float %2004)  ; FAbs(value)
  %2008 = call float @dx.op.unary.f32(i32 6, float %2005)  ; FAbs(value)
  %2009 = call float @dx.op.binary.f32(i32 35, float %2007, float %2008)  ; FMax(a,b)
  %2010 = call float @dx.op.binary.f32(i32 35, float %2006, float %2009)  ; FMax(a,b)
  %2011 = fcmp fast olt float %2002, %2010
  %2012 = select i1 %2011, float %1607, float %1839
  %2013 = select i1 %2011, float %1608, float %1840
  %2014 = select i1 %2011, float %1609, float %1841
  %2015 = select i1 %2011, float %1722, float %1954
  %2016 = select i1 %2011, float %1723, float %1955
  %2017 = select i1 %2011, float %1724, float %1956
  %2018 = fsub fast float %1488, %2015
  %2019 = fsub fast float %1489, %2016
  %2020 = fsub fast float %1490, %2017
  %2021 = fsub fast float %1488, %2012
  %2022 = fsub fast float %1489, %2013
  %2023 = fsub fast float %1490, %2014
  %2024 = call float @dx.op.dot3.f32(i32 55, float %2021, float %2022, float %2023, float %2018, float %2019, float %2020)  ; Dot3(ax,ay,az,bx,by,bz)
  %2025 = fcmp fast ogt float %2024, 0.000000e+00
  br i1 %2025, label %2026, label %2037

; <label>:2026                                    ; preds = %1994
  %2027 = fsub fast float %2012, %2015
  %2028 = fsub fast float %2013, %2016
  %2029 = fsub fast float %2014, %2017
  %2030 = call float @dx.op.unary.f32(i32 6, float %2027)  ; FAbs(value)
  %2031 = call float @dx.op.unary.f32(i32 6, float %2028)  ; FAbs(value)
  %2032 = call float @dx.op.unary.f32(i32 6, float %2029)  ; FAbs(value)
  %2033 = call float @dx.op.binary.f32(i32 35, float %2031, float %2032)  ; FMax(a,b)
  %2034 = call float @dx.op.binary.f32(i32 35, float %2030, float %2033)  ; FMax(a,b)
  %2035 = fmul fast float %1988, 2.500000e-01
  %2036 = fcmp fast olt float %2034, %2035
  br label %2037

; <label>:2037                                    ; preds = %2026, %1994
  %2038 = phi i1 [ false, %1994 ], [ %2036, %2026 ]
  %2039 = select i1 %2038, float 5.000000e-01, float 1.000000e+00
  %2040 = fmul fast float %2039, %3
  %2041 = fadd fast float %2012, %2015
  %2042 = fadd fast float %2013, %2016
  %2043 = fadd fast float %2014, %2017
  %2044 = fmul fast float %2041, 5.000000e-01
  %2045 = fmul fast float %2042, 5.000000e-01
  %2046 = fmul fast float %2043, 5.000000e-01
  %2047 = fsub fast float %2044, %1488
  %2048 = fsub fast float %2045, %1489
  %2049 = fsub fast float %2046, %1490
  %2050 = fmul fast float %2040, %2047
  %2051 = fmul fast float %2040, %2048
  %2052 = fmul fast float %2040, %2049
  %2053 = fadd fast float %2050, %1488
  %2054 = fadd fast float %2051, %1489
  %2055 = fadd fast float %2052, %1490
  br label %2056

; <label>:2056                                    ; preds = %2037, %1953, %1459
  %2057 = phi float [ %2053, %2037 ], [ %1488, %1953 ], [ %1488, %1459 ]
  %2058 = phi float [ %2054, %2037 ], [ %1489, %1953 ], [ %1489, %1459 ]
  %2059 = phi float [ %2055, %2037 ], [ %1490, %1953 ], [ %1490, %1459 ]
  %2060 = fcmp fast ogt float %2057, 0x3F69A5C380000000
  %2061 = fcmp fast ogt float %2058, 0x3F69A5C380000000
  %2062 = fcmp fast ogt float %2059, 0x3F69A5C380000000
  %2063 = select i1 %2060, float 0.000000e+00, float 1.000000e+00
  %2064 = select i1 %2061, float 0.000000e+00, float 1.000000e+00
  %2065 = select i1 %2062, float 0.000000e+00, float 1.000000e+00
  %2066 = fmul fast float %2057, 0x4029D70A40000000
  %2067 = fmul fast float %2058, 0x4029D70A40000000
  %2068 = fmul fast float %2059, 0x4029D70A40000000
  %2069 = call float @dx.op.binary.f32(i32 35, float %2057, float 0.000000e+00)  ; FMax(a,b)
  %2070 = call float @dx.op.binary.f32(i32 35, float %2058, float 0.000000e+00)  ; FMax(a,b)
  %2071 = call float @dx.op.binary.f32(i32 35, float %2059, float 0.000000e+00)  ; FMax(a,b)
  %2072 = call float @dx.op.unary.f32(i32 23, float %2069)  ; Log(value)
  %2073 = call float @dx.op.unary.f32(i32 23, float %2070)  ; Log(value)
  %2074 = call float @dx.op.unary.f32(i32 23, float %2071)  ; Log(value)
  %2075 = fmul fast float %2072, 0x3FDAAAAAA0000000
  %2076 = fmul fast float %2073, 0x3FDAAAAAA0000000
  %2077 = fmul fast float %2074, 0x3FDAAAAAA0000000
  %2078 = call float @dx.op.unary.f32(i32 21, float %2075)  ; Exp(value)
  %2079 = call float @dx.op.unary.f32(i32 21, float %2076)  ; Exp(value)
  %2080 = call float @dx.op.unary.f32(i32 21, float %2077)  ; Exp(value)
  %2081 = fmul fast float %2078, 0x3FF0E147A0000000
  %2082 = fmul fast float %2079, 0x3FF0E147A0000000
  %2083 = fmul fast float %2080, 0x3FF0E147A0000000
  %2084 = fadd fast float %2081, 0xBFAC28F5C0000000
  %2085 = fadd fast float %2082, 0xBFAC28F5C0000000
  %2086 = fadd fast float %2083, 0xBFAC28F5C0000000
  %2087 = fsub fast float %2066, %2084
  %2088 = fsub fast float %2067, %2085
  %2089 = fsub fast float %2068, %2086
  %2090 = fmul fast float %2087, %2063
  %2091 = fmul fast float %2088, %2064
  %2092 = fmul fast float %2089, %2065
  %2093 = fadd fast float %2090, %2084
  %2094 = fadd fast float %2091, %2085
  %2095 = fadd fast float %2092, %2086
  br label %2096

; <label>:2096                                    ; preds = %2056, %1421
  %2097 = phi float [ %1416, %1421 ], [ %2093, %2056 ]
  %2098 = phi float [ %1417, %1421 ], [ %2094, %2056 ]
  %2099 = phi float [ %1418, %1421 ], [ %2095, %2056 ]
  %2100 = phi float [ %1422, %1421 ], [ %1419, %2056 ]
  %2101 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %725, i32 %1414, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2102 = extractvalue %dx.types.ResRet.f32 %2101, 0
  %2103 = extractvalue %dx.types.ResRet.f32 %2101, 1
  %2104 = extractvalue %dx.types.ResRet.f32 %2101, 2
  %2105 = extractvalue %dx.types.ResRet.f32 %2101, 3
  %2106 = fcmp fast olt float %2105, 0.000000e+00
  br i1 %2106, label %2107, label %2109

; <label>:2107                                    ; preds = %2096
  %2108 = fsub fast float -1.000000e+00, %2105
  br label %2782

; <label>:2109                                    ; preds = %2096
  %2110 = fadd fast float %6, 1.000000e+00
  %2111 = fadd fast float %7, 1.000000e+00
  %2112 = fsub fast float 1.000000e+00, %6
  %2113 = fmul fast float %10, %2110
  %2114 = fmul fast float %10, %2111
  %2115 = fmul fast float %10, %2112
  %2116 = fmul fast float %2113, %2102
  %2117 = fmul fast float %2114, %2103
  %2118 = fmul fast float %2115, %2104
  %2119 = fcmp fast ult float %11, 5.000000e-01
  br i1 %2119, label %2145, label %2120

; <label>:2120                                    ; preds = %2109
  %2121 = fmul fast float %2116, 0x4004147AE0000000
  %2122 = fmul fast float %2117, 0x4004147AE0000000
  %2123 = fmul fast float %2118, 0x4004147AE0000000
  %2124 = fadd fast float %2121, 0x3F9EB851E0000000
  %2125 = fadd fast float %2122, 0x3F9EB851E0000000
  %2126 = fadd fast float %2123, 0x3F9EB851E0000000
  %2127 = fmul fast float %2124, %2116
  %2128 = fmul fast float %2125, %2117
  %2129 = fmul fast float %2126, %2118
  %2130 = fmul fast float %2116, 0x400370A3E0000000
  %2131 = fmul fast float %2117, 0x400370A3E0000000
  %2132 = fmul fast float %2118, 0x400370A3E0000000
  %2133 = fadd fast float %2130, 0x3FE2E147A0000000
  %2134 = fadd fast float %2131, 0x3FE2E147A0000000
  %2135 = fadd fast float %2132, 0x3FE2E147A0000000
  %2136 = fmul fast float %2133, %2116
  %2137 = fmul fast float %2134, %2117
  %2138 = fmul fast float %2135, %2118
  %2139 = fadd fast float %2136, 0x3FC1EB8520000000
  %2140 = fadd fast float %2137, 0x3FC1EB8520000000
  %2141 = fadd fast float %2138, 0x3FC1EB8520000000
  %2142 = fdiv fast float %2127, %2139
  %2143 = fdiv fast float %2128, %2140
  %2144 = fdiv fast float %2129, %2141
  br label %2145

; <label>:2145                                    ; preds = %2120, %2109
  %2146 = phi float [ %2142, %2120 ], [ %2116, %2109 ]
  %2147 = phi float [ %2143, %2120 ], [ %2117, %2109 ]
  %2148 = phi float [ %2144, %2120 ], [ %2118, %2109 ]
  %2149 = call float @dx.op.unary.f32(i32 7, float %2146)  ; Saturate(value)
  %2150 = call float @dx.op.unary.f32(i32 7, float %2147)  ; Saturate(value)
  %2151 = call float @dx.op.unary.f32(i32 7, float %2148)  ; Saturate(value)
  %2152 = call float @dx.op.dot3.f32(i32 55, float %2149, float %2150, float %2151, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2153 = fsub fast float %2149, %2152
  %2154 = fsub fast float %2150, %2152
  %2155 = fsub fast float %2151, %2152
  %2156 = fmul fast float %2153, %9
  %2157 = fmul fast float %2154, %9
  %2158 = fmul fast float %2155, %9
  %2159 = fadd fast float %2156, %2152
  %2160 = fadd fast float %2157, %2152
  %2161 = fadd fast float %2158, %2152
  %2162 = call float @dx.op.unary.f32(i32 7, float %2159)  ; Saturate(value)
  %2163 = call float @dx.op.unary.f32(i32 7, float %2160)  ; Saturate(value)
  %2164 = call float @dx.op.unary.f32(i32 7, float %2161)  ; Saturate(value)
  %2165 = fadd fast float %2162, 0xBFC70A3D80000000
  %2166 = fadd fast float %2163, 0xBFC70A3D80000000
  %2167 = fadd fast float %2164, 0xBFC70A3D80000000
  %2168 = fmul fast float %2165, %8
  %2169 = fmul fast float %2166, %8
  %2170 = fmul fast float %2167, %8
  %2171 = fadd fast float %2168, 0x3FC70A3D80000000
  %2172 = fadd fast float %2169, 0x3FC70A3D80000000
  %2173 = fadd fast float %2170, 0x3FC70A3D80000000
  %2174 = call float @dx.op.unary.f32(i32 7, float %2171)  ; Saturate(value)
  %2175 = call float @dx.op.unary.f32(i32 7, float %2172)  ; Saturate(value)
  %2176 = call float @dx.op.unary.f32(i32 7, float %2173)  ; Saturate(value)
  %2177 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %2177, label %2178, label %2742

; <label>:2178                                    ; preds = %2145
  %2179 = add i32 %1414, -1
  %2180 = call i32 @dx.op.binary.i32(i32 37, i32 %725, i32 0)  ; IMax(a,b)
  %2181 = call i32 @dx.op.binary.i32(i32 37, i32 %2179, i32 0)  ; IMax(a,b)
  %2182 = call i32 @dx.op.binary.i32(i32 38, i32 %2180, i32 %31)  ; IMin(a,b)
  %2183 = call i32 @dx.op.binary.i32(i32 38, i32 %2181, i32 %32)  ; IMin(a,b)
  %2184 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2182, i32 %2183, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2185 = extractvalue %dx.types.ResRet.f32 %2184, 0
  %2186 = extractvalue %dx.types.ResRet.f32 %2184, 1
  %2187 = extractvalue %dx.types.ResRet.f32 %2184, 2
  %2188 = extractvalue %dx.types.ResRet.f32 %2184, 3
  %2189 = fcmp fast olt float %2188, 0.000000e+00
  br i1 %2189, label %2190, label %2224

; <label>:2190                                    ; preds = %2178
  %2191 = fcmp fast ogt float %2185, 0x3FA4B5DCC0000000
  %2192 = fcmp fast ogt float %2186, 0x3FA4B5DCC0000000
  %2193 = fcmp fast ogt float %2187, 0x3FA4B5DCC0000000
  %2194 = select i1 %2191, float 0.000000e+00, float 1.000000e+00
  %2195 = select i1 %2192, float 0.000000e+00, float 1.000000e+00
  %2196 = select i1 %2193, float 0.000000e+00, float 1.000000e+00
  %2197 = fmul fast float %2185, 0x3FB3D07220000000
  %2198 = fmul fast float %2186, 0x3FB3D07220000000
  %2199 = fmul fast float %2187, 0x3FB3D07220000000
  %2200 = fadd fast float %2185, 0x3FAC28F5C0000000
  %2201 = fadd fast float %2186, 0x3FAC28F5C0000000
  %2202 = fadd fast float %2187, 0x3FAC28F5C0000000
  %2203 = fmul fast float %2200, 0x3FEE54EDE0000000
  %2204 = fmul fast float %2201, 0x3FEE54EDE0000000
  %2205 = fmul fast float %2202, 0x3FEE54EDE0000000
  %2206 = call float @dx.op.unary.f32(i32 23, float %2203)  ; Log(value)
  %2207 = call float @dx.op.unary.f32(i32 23, float %2204)  ; Log(value)
  %2208 = call float @dx.op.unary.f32(i32 23, float %2205)  ; Log(value)
  %2209 = fmul fast float %2206, 0x4003333340000000
  %2210 = fmul fast float %2207, 0x4003333340000000
  %2211 = fmul fast float %2208, 0x4003333340000000
  %2212 = call float @dx.op.unary.f32(i32 21, float %2209)  ; Exp(value)
  %2213 = call float @dx.op.unary.f32(i32 21, float %2210)  ; Exp(value)
  %2214 = call float @dx.op.unary.f32(i32 21, float %2211)  ; Exp(value)
  %2215 = fsub fast float %2197, %2212
  %2216 = fsub fast float %2198, %2213
  %2217 = fsub fast float %2199, %2214
  %2218 = fmul fast float %2215, %2194
  %2219 = fmul fast float %2216, %2195
  %2220 = fmul fast float %2217, %2196
  %2221 = fadd fast float %2218, %2212
  %2222 = fadd fast float %2219, %2213
  %2223 = fadd fast float %2220, %2214
  br label %2292

; <label>:2224                                    ; preds = %2178
  %2225 = fadd fast float %6, 1.000000e+00
  %2226 = fadd fast float %7, 1.000000e+00
  %2227 = fsub fast float 1.000000e+00, %6
  %2228 = fmul fast float %10, %2225
  %2229 = fmul fast float %10, %2226
  %2230 = fmul fast float %10, %2227
  %2231 = fmul fast float %2228, %2185
  %2232 = fmul fast float %2229, %2186
  %2233 = fmul fast float %2230, %2187
  %2234 = fcmp fast ult float %11, 5.000000e-01
  br i1 %2234, label %2260, label %2235

; <label>:2235                                    ; preds = %2224
  %2236 = fmul fast float %2231, 0x4004147AE0000000
  %2237 = fmul fast float %2232, 0x4004147AE0000000
  %2238 = fmul fast float %2233, 0x4004147AE0000000
  %2239 = fadd fast float %2236, 0x3F9EB851E0000000
  %2240 = fadd fast float %2237, 0x3F9EB851E0000000
  %2241 = fadd fast float %2238, 0x3F9EB851E0000000
  %2242 = fmul fast float %2239, %2231
  %2243 = fmul fast float %2240, %2232
  %2244 = fmul fast float %2241, %2233
  %2245 = fmul fast float %2231, 0x400370A3E0000000
  %2246 = fmul fast float %2232, 0x400370A3E0000000
  %2247 = fmul fast float %2233, 0x400370A3E0000000
  %2248 = fadd fast float %2245, 0x3FE2E147A0000000
  %2249 = fadd fast float %2246, 0x3FE2E147A0000000
  %2250 = fadd fast float %2247, 0x3FE2E147A0000000
  %2251 = fmul fast float %2248, %2231
  %2252 = fmul fast float %2249, %2232
  %2253 = fmul fast float %2250, %2233
  %2254 = fadd fast float %2251, 0x3FC1EB8520000000
  %2255 = fadd fast float %2252, 0x3FC1EB8520000000
  %2256 = fadd fast float %2253, 0x3FC1EB8520000000
  %2257 = fdiv fast float %2242, %2254
  %2258 = fdiv fast float %2243, %2255
  %2259 = fdiv fast float %2244, %2256
  br label %2260

; <label>:2260                                    ; preds = %2235, %2224
  %2261 = phi float [ %2257, %2235 ], [ %2231, %2224 ]
  %2262 = phi float [ %2258, %2235 ], [ %2232, %2224 ]
  %2263 = phi float [ %2259, %2235 ], [ %2233, %2224 ]
  %2264 = call float @dx.op.unary.f32(i32 7, float %2261)  ; Saturate(value)
  %2265 = call float @dx.op.unary.f32(i32 7, float %2262)  ; Saturate(value)
  %2266 = call float @dx.op.unary.f32(i32 7, float %2263)  ; Saturate(value)
  %2267 = call float @dx.op.dot3.f32(i32 55, float %2264, float %2265, float %2266, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2268 = fsub fast float %2264, %2267
  %2269 = fsub fast float %2265, %2267
  %2270 = fsub fast float %2266, %2267
  %2271 = fmul fast float %2268, %9
  %2272 = fmul fast float %2269, %9
  %2273 = fmul fast float %2270, %9
  %2274 = fadd fast float %2271, %2267
  %2275 = fadd fast float %2272, %2267
  %2276 = fadd fast float %2273, %2267
  %2277 = call float @dx.op.unary.f32(i32 7, float %2274)  ; Saturate(value)
  %2278 = call float @dx.op.unary.f32(i32 7, float %2275)  ; Saturate(value)
  %2279 = call float @dx.op.unary.f32(i32 7, float %2276)  ; Saturate(value)
  %2280 = fadd fast float %2277, 0xBFC70A3D80000000
  %2281 = fadd fast float %2278, 0xBFC70A3D80000000
  %2282 = fadd fast float %2279, 0xBFC70A3D80000000
  %2283 = fmul fast float %2280, %8
  %2284 = fmul fast float %2281, %8
  %2285 = fmul fast float %2282, %8
  %2286 = fadd fast float %2283, 0x3FC70A3D80000000
  %2287 = fadd fast float %2284, 0x3FC70A3D80000000
  %2288 = fadd fast float %2285, 0x3FC70A3D80000000
  %2289 = call float @dx.op.unary.f32(i32 7, float %2286)  ; Saturate(value)
  %2290 = call float @dx.op.unary.f32(i32 7, float %2287)  ; Saturate(value)
  %2291 = call float @dx.op.unary.f32(i32 7, float %2288)  ; Saturate(value)
  br label %2292

; <label>:2292                                    ; preds = %2260, %2190
  %2293 = phi float [ %2221, %2190 ], [ %2289, %2260 ]
  %2294 = phi float [ %2222, %2190 ], [ %2290, %2260 ]
  %2295 = phi float [ %2223, %2190 ], [ %2291, %2260 ]
  %2296 = add i32 %1414, 1
  %2297 = call i32 @dx.op.binary.i32(i32 37, i32 %2296, i32 0)  ; IMax(a,b)
  %2298 = call i32 @dx.op.binary.i32(i32 38, i32 %2297, i32 %32)  ; IMin(a,b)
  %2299 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2182, i32 %2298, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2300 = extractvalue %dx.types.ResRet.f32 %2299, 0
  %2301 = extractvalue %dx.types.ResRet.f32 %2299, 1
  %2302 = extractvalue %dx.types.ResRet.f32 %2299, 2
  %2303 = extractvalue %dx.types.ResRet.f32 %2299, 3
  %2304 = fcmp fast olt float %2303, 0.000000e+00
  br i1 %2304, label %2305, label %2339

; <label>:2305                                    ; preds = %2292
  %2306 = fcmp fast ogt float %2300, 0x3FA4B5DCC0000000
  %2307 = fcmp fast ogt float %2301, 0x3FA4B5DCC0000000
  %2308 = fcmp fast ogt float %2302, 0x3FA4B5DCC0000000
  %2309 = select i1 %2306, float 0.000000e+00, float 1.000000e+00
  %2310 = select i1 %2307, float 0.000000e+00, float 1.000000e+00
  %2311 = select i1 %2308, float 0.000000e+00, float 1.000000e+00
  %2312 = fmul fast float %2300, 0x3FB3D07220000000
  %2313 = fmul fast float %2301, 0x3FB3D07220000000
  %2314 = fmul fast float %2302, 0x3FB3D07220000000
  %2315 = fadd fast float %2300, 0x3FAC28F5C0000000
  %2316 = fadd fast float %2301, 0x3FAC28F5C0000000
  %2317 = fadd fast float %2302, 0x3FAC28F5C0000000
  %2318 = fmul fast float %2315, 0x3FEE54EDE0000000
  %2319 = fmul fast float %2316, 0x3FEE54EDE0000000
  %2320 = fmul fast float %2317, 0x3FEE54EDE0000000
  %2321 = call float @dx.op.unary.f32(i32 23, float %2318)  ; Log(value)
  %2322 = call float @dx.op.unary.f32(i32 23, float %2319)  ; Log(value)
  %2323 = call float @dx.op.unary.f32(i32 23, float %2320)  ; Log(value)
  %2324 = fmul fast float %2321, 0x4003333340000000
  %2325 = fmul fast float %2322, 0x4003333340000000
  %2326 = fmul fast float %2323, 0x4003333340000000
  %2327 = call float @dx.op.unary.f32(i32 21, float %2324)  ; Exp(value)
  %2328 = call float @dx.op.unary.f32(i32 21, float %2325)  ; Exp(value)
  %2329 = call float @dx.op.unary.f32(i32 21, float %2326)  ; Exp(value)
  %2330 = fsub fast float %2312, %2327
  %2331 = fsub fast float %2313, %2328
  %2332 = fsub fast float %2314, %2329
  %2333 = fmul fast float %2330, %2309
  %2334 = fmul fast float %2331, %2310
  %2335 = fmul fast float %2332, %2311
  %2336 = fadd fast float %2333, %2327
  %2337 = fadd fast float %2334, %2328
  %2338 = fadd fast float %2335, %2329
  br label %2407

; <label>:2339                                    ; preds = %2292
  %2340 = fadd fast float %6, 1.000000e+00
  %2341 = fadd fast float %7, 1.000000e+00
  %2342 = fsub fast float 1.000000e+00, %6
  %2343 = fmul fast float %10, %2340
  %2344 = fmul fast float %10, %2341
  %2345 = fmul fast float %10, %2342
  %2346 = fmul fast float %2343, %2300
  %2347 = fmul fast float %2344, %2301
  %2348 = fmul fast float %2345, %2302
  %2349 = fcmp fast ult float %11, 5.000000e-01
  br i1 %2349, label %2375, label %2350

; <label>:2350                                    ; preds = %2339
  %2351 = fmul fast float %2346, 0x4004147AE0000000
  %2352 = fmul fast float %2347, 0x4004147AE0000000
  %2353 = fmul fast float %2348, 0x4004147AE0000000
  %2354 = fadd fast float %2351, 0x3F9EB851E0000000
  %2355 = fadd fast float %2352, 0x3F9EB851E0000000
  %2356 = fadd fast float %2353, 0x3F9EB851E0000000
  %2357 = fmul fast float %2354, %2346
  %2358 = fmul fast float %2355, %2347
  %2359 = fmul fast float %2356, %2348
  %2360 = fmul fast float %2346, 0x400370A3E0000000
  %2361 = fmul fast float %2347, 0x400370A3E0000000
  %2362 = fmul fast float %2348, 0x400370A3E0000000
  %2363 = fadd fast float %2360, 0x3FE2E147A0000000
  %2364 = fadd fast float %2361, 0x3FE2E147A0000000
  %2365 = fadd fast float %2362, 0x3FE2E147A0000000
  %2366 = fmul fast float %2363, %2346
  %2367 = fmul fast float %2364, %2347
  %2368 = fmul fast float %2365, %2348
  %2369 = fadd fast float %2366, 0x3FC1EB8520000000
  %2370 = fadd fast float %2367, 0x3FC1EB8520000000
  %2371 = fadd fast float %2368, 0x3FC1EB8520000000
  %2372 = fdiv fast float %2357, %2369
  %2373 = fdiv fast float %2358, %2370
  %2374 = fdiv fast float %2359, %2371
  br label %2375

; <label>:2375                                    ; preds = %2350, %2339
  %2376 = phi float [ %2372, %2350 ], [ %2346, %2339 ]
  %2377 = phi float [ %2373, %2350 ], [ %2347, %2339 ]
  %2378 = phi float [ %2374, %2350 ], [ %2348, %2339 ]
  %2379 = call float @dx.op.unary.f32(i32 7, float %2376)  ; Saturate(value)
  %2380 = call float @dx.op.unary.f32(i32 7, float %2377)  ; Saturate(value)
  %2381 = call float @dx.op.unary.f32(i32 7, float %2378)  ; Saturate(value)
  %2382 = call float @dx.op.dot3.f32(i32 55, float %2379, float %2380, float %2381, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2383 = fsub fast float %2379, %2382
  %2384 = fsub fast float %2380, %2382
  %2385 = fsub fast float %2381, %2382
  %2386 = fmul fast float %2383, %9
  %2387 = fmul fast float %2384, %9
  %2388 = fmul fast float %2385, %9
  %2389 = fadd fast float %2386, %2382
  %2390 = fadd fast float %2387, %2382
  %2391 = fadd fast float %2388, %2382
  %2392 = call float @dx.op.unary.f32(i32 7, float %2389)  ; Saturate(value)
  %2393 = call float @dx.op.unary.f32(i32 7, float %2390)  ; Saturate(value)
  %2394 = call float @dx.op.unary.f32(i32 7, float %2391)  ; Saturate(value)
  %2395 = fadd fast float %2392, 0xBFC70A3D80000000
  %2396 = fadd fast float %2393, 0xBFC70A3D80000000
  %2397 = fadd fast float %2394, 0xBFC70A3D80000000
  %2398 = fmul fast float %2395, %8
  %2399 = fmul fast float %2396, %8
  %2400 = fmul fast float %2397, %8
  %2401 = fadd fast float %2398, 0x3FC70A3D80000000
  %2402 = fadd fast float %2399, 0x3FC70A3D80000000
  %2403 = fadd fast float %2400, 0x3FC70A3D80000000
  %2404 = call float @dx.op.unary.f32(i32 7, float %2401)  ; Saturate(value)
  %2405 = call float @dx.op.unary.f32(i32 7, float %2402)  ; Saturate(value)
  %2406 = call float @dx.op.unary.f32(i32 7, float %2403)  ; Saturate(value)
  br label %2407

; <label>:2407                                    ; preds = %2375, %2305
  %2408 = phi float [ %2336, %2305 ], [ %2404, %2375 ]
  %2409 = phi float [ %2337, %2305 ], [ %2405, %2375 ]
  %2410 = phi float [ %2338, %2305 ], [ %2406, %2375 ]
  %2411 = add i32 %725, -1
  %2412 = call i32 @dx.op.binary.i32(i32 37, i32 %2411, i32 0)  ; IMax(a,b)
  %2413 = call i32 @dx.op.binary.i32(i32 37, i32 %1414, i32 0)  ; IMax(a,b)
  %2414 = call i32 @dx.op.binary.i32(i32 38, i32 %2412, i32 %31)  ; IMin(a,b)
  %2415 = call i32 @dx.op.binary.i32(i32 38, i32 %2413, i32 %32)  ; IMin(a,b)
  %2416 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2414, i32 %2415, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2417 = extractvalue %dx.types.ResRet.f32 %2416, 0
  %2418 = extractvalue %dx.types.ResRet.f32 %2416, 1
  %2419 = extractvalue %dx.types.ResRet.f32 %2416, 2
  %2420 = extractvalue %dx.types.ResRet.f32 %2416, 3
  %2421 = fcmp fast olt float %2420, 0.000000e+00
  br i1 %2421, label %2422, label %2456

; <label>:2422                                    ; preds = %2407
  %2423 = fcmp fast ogt float %2417, 0x3FA4B5DCC0000000
  %2424 = fcmp fast ogt float %2418, 0x3FA4B5DCC0000000
  %2425 = fcmp fast ogt float %2419, 0x3FA4B5DCC0000000
  %2426 = select i1 %2423, float 0.000000e+00, float 1.000000e+00
  %2427 = select i1 %2424, float 0.000000e+00, float 1.000000e+00
  %2428 = select i1 %2425, float 0.000000e+00, float 1.000000e+00
  %2429 = fmul fast float %2417, 0x3FB3D07220000000
  %2430 = fmul fast float %2418, 0x3FB3D07220000000
  %2431 = fmul fast float %2419, 0x3FB3D07220000000
  %2432 = fadd fast float %2417, 0x3FAC28F5C0000000
  %2433 = fadd fast float %2418, 0x3FAC28F5C0000000
  %2434 = fadd fast float %2419, 0x3FAC28F5C0000000
  %2435 = fmul fast float %2432, 0x3FEE54EDE0000000
  %2436 = fmul fast float %2433, 0x3FEE54EDE0000000
  %2437 = fmul fast float %2434, 0x3FEE54EDE0000000
  %2438 = call float @dx.op.unary.f32(i32 23, float %2435)  ; Log(value)
  %2439 = call float @dx.op.unary.f32(i32 23, float %2436)  ; Log(value)
  %2440 = call float @dx.op.unary.f32(i32 23, float %2437)  ; Log(value)
  %2441 = fmul fast float %2438, 0x4003333340000000
  %2442 = fmul fast float %2439, 0x4003333340000000
  %2443 = fmul fast float %2440, 0x4003333340000000
  %2444 = call float @dx.op.unary.f32(i32 21, float %2441)  ; Exp(value)
  %2445 = call float @dx.op.unary.f32(i32 21, float %2442)  ; Exp(value)
  %2446 = call float @dx.op.unary.f32(i32 21, float %2443)  ; Exp(value)
  %2447 = fsub fast float %2429, %2444
  %2448 = fsub fast float %2430, %2445
  %2449 = fsub fast float %2431, %2446
  %2450 = fmul fast float %2447, %2426
  %2451 = fmul fast float %2448, %2427
  %2452 = fmul fast float %2449, %2428
  %2453 = fadd fast float %2450, %2444
  %2454 = fadd fast float %2451, %2445
  %2455 = fadd fast float %2452, %2446
  br label %2524

; <label>:2456                                    ; preds = %2407
  %2457 = fadd fast float %6, 1.000000e+00
  %2458 = fadd fast float %7, 1.000000e+00
  %2459 = fsub fast float 1.000000e+00, %6
  %2460 = fmul fast float %10, %2457
  %2461 = fmul fast float %10, %2458
  %2462 = fmul fast float %10, %2459
  %2463 = fmul fast float %2460, %2417
  %2464 = fmul fast float %2461, %2418
  %2465 = fmul fast float %2462, %2419
  %2466 = fcmp fast ult float %11, 5.000000e-01
  br i1 %2466, label %2492, label %2467

; <label>:2467                                    ; preds = %2456
  %2468 = fmul fast float %2463, 0x4004147AE0000000
  %2469 = fmul fast float %2464, 0x4004147AE0000000
  %2470 = fmul fast float %2465, 0x4004147AE0000000
  %2471 = fadd fast float %2468, 0x3F9EB851E0000000
  %2472 = fadd fast float %2469, 0x3F9EB851E0000000
  %2473 = fadd fast float %2470, 0x3F9EB851E0000000
  %2474 = fmul fast float %2471, %2463
  %2475 = fmul fast float %2472, %2464
  %2476 = fmul fast float %2473, %2465
  %2477 = fmul fast float %2463, 0x400370A3E0000000
  %2478 = fmul fast float %2464, 0x400370A3E0000000
  %2479 = fmul fast float %2465, 0x400370A3E0000000
  %2480 = fadd fast float %2477, 0x3FE2E147A0000000
  %2481 = fadd fast float %2478, 0x3FE2E147A0000000
  %2482 = fadd fast float %2479, 0x3FE2E147A0000000
  %2483 = fmul fast float %2480, %2463
  %2484 = fmul fast float %2481, %2464
  %2485 = fmul fast float %2482, %2465
  %2486 = fadd fast float %2483, 0x3FC1EB8520000000
  %2487 = fadd fast float %2484, 0x3FC1EB8520000000
  %2488 = fadd fast float %2485, 0x3FC1EB8520000000
  %2489 = fdiv fast float %2474, %2486
  %2490 = fdiv fast float %2475, %2487
  %2491 = fdiv fast float %2476, %2488
  br label %2492

; <label>:2492                                    ; preds = %2467, %2456
  %2493 = phi float [ %2489, %2467 ], [ %2463, %2456 ]
  %2494 = phi float [ %2490, %2467 ], [ %2464, %2456 ]
  %2495 = phi float [ %2491, %2467 ], [ %2465, %2456 ]
  %2496 = call float @dx.op.unary.f32(i32 7, float %2493)  ; Saturate(value)
  %2497 = call float @dx.op.unary.f32(i32 7, float %2494)  ; Saturate(value)
  %2498 = call float @dx.op.unary.f32(i32 7, float %2495)  ; Saturate(value)
  %2499 = call float @dx.op.dot3.f32(i32 55, float %2496, float %2497, float %2498, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2500 = fsub fast float %2496, %2499
  %2501 = fsub fast float %2497, %2499
  %2502 = fsub fast float %2498, %2499
  %2503 = fmul fast float %2500, %9
  %2504 = fmul fast float %2501, %9
  %2505 = fmul fast float %2502, %9
  %2506 = fadd fast float %2503, %2499
  %2507 = fadd fast float %2504, %2499
  %2508 = fadd fast float %2505, %2499
  %2509 = call float @dx.op.unary.f32(i32 7, float %2506)  ; Saturate(value)
  %2510 = call float @dx.op.unary.f32(i32 7, float %2507)  ; Saturate(value)
  %2511 = call float @dx.op.unary.f32(i32 7, float %2508)  ; Saturate(value)
  %2512 = fadd fast float %2509, 0xBFC70A3D80000000
  %2513 = fadd fast float %2510, 0xBFC70A3D80000000
  %2514 = fadd fast float %2511, 0xBFC70A3D80000000
  %2515 = fmul fast float %2512, %8
  %2516 = fmul fast float %2513, %8
  %2517 = fmul fast float %2514, %8
  %2518 = fadd fast float %2515, 0x3FC70A3D80000000
  %2519 = fadd fast float %2516, 0x3FC70A3D80000000
  %2520 = fadd fast float %2517, 0x3FC70A3D80000000
  %2521 = call float @dx.op.unary.f32(i32 7, float %2518)  ; Saturate(value)
  %2522 = call float @dx.op.unary.f32(i32 7, float %2519)  ; Saturate(value)
  %2523 = call float @dx.op.unary.f32(i32 7, float %2520)  ; Saturate(value)
  br label %2524

; <label>:2524                                    ; preds = %2492, %2422
  %2525 = phi float [ %2453, %2422 ], [ %2521, %2492 ]
  %2526 = phi float [ %2454, %2422 ], [ %2522, %2492 ]
  %2527 = phi float [ %2455, %2422 ], [ %2523, %2492 ]
  %2528 = add i32 %725, 1
  %2529 = call i32 @dx.op.binary.i32(i32 37, i32 %2528, i32 0)  ; IMax(a,b)
  %2530 = call i32 @dx.op.binary.i32(i32 38, i32 %2529, i32 %31)  ; IMin(a,b)
  %2531 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2530, i32 %2415, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2532 = extractvalue %dx.types.ResRet.f32 %2531, 0
  %2533 = extractvalue %dx.types.ResRet.f32 %2531, 1
  %2534 = extractvalue %dx.types.ResRet.f32 %2531, 2
  %2535 = extractvalue %dx.types.ResRet.f32 %2531, 3
  %2536 = fcmp fast olt float %2535, 0.000000e+00
  br i1 %2536, label %2537, label %2571

; <label>:2537                                    ; preds = %2524
  %2538 = fcmp fast ogt float %2532, 0x3FA4B5DCC0000000
  %2539 = fcmp fast ogt float %2533, 0x3FA4B5DCC0000000
  %2540 = fcmp fast ogt float %2534, 0x3FA4B5DCC0000000
  %2541 = select i1 %2538, float 0.000000e+00, float 1.000000e+00
  %2542 = select i1 %2539, float 0.000000e+00, float 1.000000e+00
  %2543 = select i1 %2540, float 0.000000e+00, float 1.000000e+00
  %2544 = fmul fast float %2532, 0x3FB3D07220000000
  %2545 = fmul fast float %2533, 0x3FB3D07220000000
  %2546 = fmul fast float %2534, 0x3FB3D07220000000
  %2547 = fadd fast float %2532, 0x3FAC28F5C0000000
  %2548 = fadd fast float %2533, 0x3FAC28F5C0000000
  %2549 = fadd fast float %2534, 0x3FAC28F5C0000000
  %2550 = fmul fast float %2547, 0x3FEE54EDE0000000
  %2551 = fmul fast float %2548, 0x3FEE54EDE0000000
  %2552 = fmul fast float %2549, 0x3FEE54EDE0000000
  %2553 = call float @dx.op.unary.f32(i32 23, float %2550)  ; Log(value)
  %2554 = call float @dx.op.unary.f32(i32 23, float %2551)  ; Log(value)
  %2555 = call float @dx.op.unary.f32(i32 23, float %2552)  ; Log(value)
  %2556 = fmul fast float %2553, 0x4003333340000000
  %2557 = fmul fast float %2554, 0x4003333340000000
  %2558 = fmul fast float %2555, 0x4003333340000000
  %2559 = call float @dx.op.unary.f32(i32 21, float %2556)  ; Exp(value)
  %2560 = call float @dx.op.unary.f32(i32 21, float %2557)  ; Exp(value)
  %2561 = call float @dx.op.unary.f32(i32 21, float %2558)  ; Exp(value)
  %2562 = fsub fast float %2544, %2559
  %2563 = fsub fast float %2545, %2560
  %2564 = fsub fast float %2546, %2561
  %2565 = fmul fast float %2562, %2541
  %2566 = fmul fast float %2563, %2542
  %2567 = fmul fast float %2564, %2543
  %2568 = fadd fast float %2565, %2559
  %2569 = fadd fast float %2566, %2560
  %2570 = fadd fast float %2567, %2561
  br label %2639

; <label>:2571                                    ; preds = %2524
  %2572 = fadd fast float %6, 1.000000e+00
  %2573 = fadd fast float %7, 1.000000e+00
  %2574 = fsub fast float 1.000000e+00, %6
  %2575 = fmul fast float %10, %2572
  %2576 = fmul fast float %10, %2573
  %2577 = fmul fast float %10, %2574
  %2578 = fmul fast float %2575, %2532
  %2579 = fmul fast float %2576, %2533
  %2580 = fmul fast float %2577, %2534
  %2581 = fcmp fast ult float %11, 5.000000e-01
  br i1 %2581, label %2607, label %2582

; <label>:2582                                    ; preds = %2571
  %2583 = fmul fast float %2578, 0x4004147AE0000000
  %2584 = fmul fast float %2579, 0x4004147AE0000000
  %2585 = fmul fast float %2580, 0x4004147AE0000000
  %2586 = fadd fast float %2583, 0x3F9EB851E0000000
  %2587 = fadd fast float %2584, 0x3F9EB851E0000000
  %2588 = fadd fast float %2585, 0x3F9EB851E0000000
  %2589 = fmul fast float %2586, %2578
  %2590 = fmul fast float %2587, %2579
  %2591 = fmul fast float %2588, %2580
  %2592 = fmul fast float %2578, 0x400370A3E0000000
  %2593 = fmul fast float %2579, 0x400370A3E0000000
  %2594 = fmul fast float %2580, 0x400370A3E0000000
  %2595 = fadd fast float %2592, 0x3FE2E147A0000000
  %2596 = fadd fast float %2593, 0x3FE2E147A0000000
  %2597 = fadd fast float %2594, 0x3FE2E147A0000000
  %2598 = fmul fast float %2595, %2578
  %2599 = fmul fast float %2596, %2579
  %2600 = fmul fast float %2597, %2580
  %2601 = fadd fast float %2598, 0x3FC1EB8520000000
  %2602 = fadd fast float %2599, 0x3FC1EB8520000000
  %2603 = fadd fast float %2600, 0x3FC1EB8520000000
  %2604 = fdiv fast float %2589, %2601
  %2605 = fdiv fast float %2590, %2602
  %2606 = fdiv fast float %2591, %2603
  br label %2607

; <label>:2607                                    ; preds = %2582, %2571
  %2608 = phi float [ %2604, %2582 ], [ %2578, %2571 ]
  %2609 = phi float [ %2605, %2582 ], [ %2579, %2571 ]
  %2610 = phi float [ %2606, %2582 ], [ %2580, %2571 ]
  %2611 = call float @dx.op.unary.f32(i32 7, float %2608)  ; Saturate(value)
  %2612 = call float @dx.op.unary.f32(i32 7, float %2609)  ; Saturate(value)
  %2613 = call float @dx.op.unary.f32(i32 7, float %2610)  ; Saturate(value)
  %2614 = call float @dx.op.dot3.f32(i32 55, float %2611, float %2612, float %2613, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2615 = fsub fast float %2611, %2614
  %2616 = fsub fast float %2612, %2614
  %2617 = fsub fast float %2613, %2614
  %2618 = fmul fast float %2615, %9
  %2619 = fmul fast float %2616, %9
  %2620 = fmul fast float %2617, %9
  %2621 = fadd fast float %2618, %2614
  %2622 = fadd fast float %2619, %2614
  %2623 = fadd fast float %2620, %2614
  %2624 = call float @dx.op.unary.f32(i32 7, float %2621)  ; Saturate(value)
  %2625 = call float @dx.op.unary.f32(i32 7, float %2622)  ; Saturate(value)
  %2626 = call float @dx.op.unary.f32(i32 7, float %2623)  ; Saturate(value)
  %2627 = fadd fast float %2624, 0xBFC70A3D80000000
  %2628 = fadd fast float %2625, 0xBFC70A3D80000000
  %2629 = fadd fast float %2626, 0xBFC70A3D80000000
  %2630 = fmul fast float %2627, %8
  %2631 = fmul fast float %2628, %8
  %2632 = fmul fast float %2629, %8
  %2633 = fadd fast float %2630, 0x3FC70A3D80000000
  %2634 = fadd fast float %2631, 0x3FC70A3D80000000
  %2635 = fadd fast float %2632, 0x3FC70A3D80000000
  %2636 = call float @dx.op.unary.f32(i32 7, float %2633)  ; Saturate(value)
  %2637 = call float @dx.op.unary.f32(i32 7, float %2634)  ; Saturate(value)
  %2638 = call float @dx.op.unary.f32(i32 7, float %2635)  ; Saturate(value)
  br label %2639

; <label>:2639                                    ; preds = %2607, %2537
  %2640 = phi float [ %2568, %2537 ], [ %2636, %2607 ]
  %2641 = phi float [ %2569, %2537 ], [ %2637, %2607 ]
  %2642 = phi float [ %2570, %2537 ], [ %2638, %2607 ]
  %2643 = call float @dx.op.binary.f32(i32 36, float %2525, float %2640)  ; FMin(a,b)
  %2644 = call float @dx.op.binary.f32(i32 36, float %2526, float %2641)  ; FMin(a,b)
  %2645 = call float @dx.op.binary.f32(i32 36, float %2527, float %2642)  ; FMin(a,b)
  %2646 = call float @dx.op.binary.f32(i32 36, float %2293, float %2408)  ; FMin(a,b)
  %2647 = call float @dx.op.binary.f32(i32 36, float %2294, float %2409)  ; FMin(a,b)
  %2648 = call float @dx.op.binary.f32(i32 36, float %2295, float %2410)  ; FMin(a,b)
  %2649 = call float @dx.op.binary.f32(i32 36, float %2646, float %2643)  ; FMin(a,b)
  %2650 = call float @dx.op.binary.f32(i32 36, float %2647, float %2644)  ; FMin(a,b)
  %2651 = call float @dx.op.binary.f32(i32 36, float %2648, float %2645)  ; FMin(a,b)
  %2652 = call float @dx.op.binary.f32(i32 36, float %2174, float %2649)  ; FMin(a,b)
  %2653 = call float @dx.op.binary.f32(i32 36, float %2175, float %2650)  ; FMin(a,b)
  %2654 = call float @dx.op.binary.f32(i32 36, float %2176, float %2651)  ; FMin(a,b)
  %2655 = call float @dx.op.binary.f32(i32 35, float %2525, float %2640)  ; FMax(a,b)
  %2656 = call float @dx.op.binary.f32(i32 35, float %2526, float %2641)  ; FMax(a,b)
  %2657 = call float @dx.op.binary.f32(i32 35, float %2527, float %2642)  ; FMax(a,b)
  %2658 = call float @dx.op.binary.f32(i32 35, float %2293, float %2408)  ; FMax(a,b)
  %2659 = call float @dx.op.binary.f32(i32 35, float %2294, float %2409)  ; FMax(a,b)
  %2660 = call float @dx.op.binary.f32(i32 35, float %2295, float %2410)  ; FMax(a,b)
  %2661 = call float @dx.op.binary.f32(i32 35, float %2658, float %2655)  ; FMax(a,b)
  %2662 = call float @dx.op.binary.f32(i32 35, float %2659, float %2656)  ; FMax(a,b)
  %2663 = call float @dx.op.binary.f32(i32 35, float %2660, float %2657)  ; FMax(a,b)
  %2664 = call float @dx.op.binary.f32(i32 35, float %2174, float %2661)  ; FMax(a,b)
  %2665 = call float @dx.op.binary.f32(i32 35, float %2175, float %2662)  ; FMax(a,b)
  %2666 = call float @dx.op.binary.f32(i32 35, float %2176, float %2663)  ; FMax(a,b)
  %2667 = fsub fast float %2664, %2652
  %2668 = fsub fast float %2665, %2653
  %2669 = fsub fast float %2666, %2654
  %2670 = call float @dx.op.unary.f32(i32 6, float %2667)  ; FAbs(value)
  %2671 = call float @dx.op.unary.f32(i32 6, float %2668)  ; FAbs(value)
  %2672 = call float @dx.op.unary.f32(i32 6, float %2669)  ; FAbs(value)
  %2673 = call float @dx.op.binary.f32(i32 35, float %2671, float %2672)  ; FMax(a,b)
  %2674 = call float @dx.op.binary.f32(i32 35, float %2670, float %2673)  ; FMax(a,b)
  %2675 = call float @dx.op.binary.f32(i32 35, float %2665, float %2666)  ; FMax(a,b)
  %2676 = call float @dx.op.binary.f32(i32 35, float %2664, float %2675)  ; FMax(a,b)
  %2677 = fmul fast float %2676, 1.250000e-01
  %2678 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %2677)  ; FMax(a,b)
  %2679 = fcmp fast ogt float %2674, %2678
  br i1 %2679, label %2680, label %2742

; <label>:2680                                    ; preds = %2639
  %2681 = fsub fast float %2293, %2408
  %2682 = fsub fast float %2294, %2409
  %2683 = fsub fast float %2295, %2410
  %2684 = call float @dx.op.unary.f32(i32 6, float %2681)  ; FAbs(value)
  %2685 = call float @dx.op.unary.f32(i32 6, float %2682)  ; FAbs(value)
  %2686 = call float @dx.op.unary.f32(i32 6, float %2683)  ; FAbs(value)
  %2687 = call float @dx.op.binary.f32(i32 35, float %2685, float %2686)  ; FMax(a,b)
  %2688 = call float @dx.op.binary.f32(i32 35, float %2684, float %2687)  ; FMax(a,b)
  %2689 = fsub fast float %2525, %2640
  %2690 = fsub fast float %2526, %2641
  %2691 = fsub fast float %2527, %2642
  %2692 = call float @dx.op.unary.f32(i32 6, float %2689)  ; FAbs(value)
  %2693 = call float @dx.op.unary.f32(i32 6, float %2690)  ; FAbs(value)
  %2694 = call float @dx.op.unary.f32(i32 6, float %2691)  ; FAbs(value)
  %2695 = call float @dx.op.binary.f32(i32 35, float %2693, float %2694)  ; FMax(a,b)
  %2696 = call float @dx.op.binary.f32(i32 35, float %2692, float %2695)  ; FMax(a,b)
  %2697 = fcmp fast olt float %2688, %2696
  %2698 = select i1 %2697, float %2293, float %2525
  %2699 = select i1 %2697, float %2294, float %2526
  %2700 = select i1 %2697, float %2295, float %2527
  %2701 = select i1 %2697, float %2408, float %2640
  %2702 = select i1 %2697, float %2409, float %2641
  %2703 = select i1 %2697, float %2410, float %2642
  %2704 = fsub fast float %2174, %2701
  %2705 = fsub fast float %2175, %2702
  %2706 = fsub fast float %2176, %2703
  %2707 = fsub fast float %2174, %2698
  %2708 = fsub fast float %2175, %2699
  %2709 = fsub fast float %2176, %2700
  %2710 = call float @dx.op.dot3.f32(i32 55, float %2707, float %2708, float %2709, float %2704, float %2705, float %2706)  ; Dot3(ax,ay,az,bx,by,bz)
  %2711 = fcmp fast ogt float %2710, 0.000000e+00
  br i1 %2711, label %2712, label %2724

; <label>:2712                                    ; preds = %2680
  %2713 = fsub fast float %2698, %2701
  %2714 = fsub fast float %2699, %2702
  %2715 = fsub fast float %2700, %2703
  %2716 = call float @dx.op.unary.f32(i32 6, float %2713)  ; FAbs(value)
  %2717 = call float @dx.op.unary.f32(i32 6, float %2714)  ; FAbs(value)
  %2718 = call float @dx.op.unary.f32(i32 6, float %2715)  ; FAbs(value)
  %2719 = call float @dx.op.binary.f32(i32 35, float %2717, float %2718)  ; FMax(a,b)
  %2720 = call float @dx.op.binary.f32(i32 35, float %2716, float %2719)  ; FMax(a,b)
  %2721 = fmul fast float %2674, 2.500000e-01
  %2722 = fcmp fast olt float %2720, %2721
  %2723 = select i1 %2722, float 5.000000e-01, float 1.000000e+00
  br label %2724

; <label>:2724                                    ; preds = %2712, %2680
  %2725 = phi float [ 1.000000e+00, %2680 ], [ %2723, %2712 ]
  %2726 = fmul fast float %2725, %3
  %2727 = fadd fast float %2698, %2701
  %2728 = fadd fast float %2699, %2702
  %2729 = fadd fast float %2700, %2703
  %2730 = fmul fast float %2727, 5.000000e-01
  %2731 = fmul fast float %2728, 5.000000e-01
  %2732 = fmul fast float %2729, 5.000000e-01
  %2733 = fsub fast float %2730, %2174
  %2734 = fsub fast float %2731, %2175
  %2735 = fsub fast float %2732, %2176
  %2736 = fmul fast float %2726, %2733
  %2737 = fmul fast float %2726, %2734
  %2738 = fmul fast float %2726, %2735
  %2739 = fadd fast float %2736, %2174
  %2740 = fadd fast float %2737, %2175
  %2741 = fadd fast float %2738, %2176
  br label %2742

; <label>:2742                                    ; preds = %2724, %2639, %2145
  %2743 = phi float [ %2739, %2724 ], [ %2174, %2639 ], [ %2174, %2145 ]
  %2744 = phi float [ %2740, %2724 ], [ %2175, %2639 ], [ %2175, %2145 ]
  %2745 = phi float [ %2741, %2724 ], [ %2176, %2639 ], [ %2176, %2145 ]
  %2746 = fcmp fast ogt float %2743, 0x3F69A5C380000000
  %2747 = fcmp fast ogt float %2744, 0x3F69A5C380000000
  %2748 = fcmp fast ogt float %2745, 0x3F69A5C380000000
  %2749 = select i1 %2746, float 0.000000e+00, float 1.000000e+00
  %2750 = select i1 %2747, float 0.000000e+00, float 1.000000e+00
  %2751 = select i1 %2748, float 0.000000e+00, float 1.000000e+00
  %2752 = fmul fast float %2743, 0x4029D70A40000000
  %2753 = fmul fast float %2744, 0x4029D70A40000000
  %2754 = fmul fast float %2745, 0x4029D70A40000000
  %2755 = call float @dx.op.binary.f32(i32 35, float %2743, float 0.000000e+00)  ; FMax(a,b)
  %2756 = call float @dx.op.binary.f32(i32 35, float %2744, float 0.000000e+00)  ; FMax(a,b)
  %2757 = call float @dx.op.binary.f32(i32 35, float %2745, float 0.000000e+00)  ; FMax(a,b)
  %2758 = call float @dx.op.unary.f32(i32 23, float %2755)  ; Log(value)
  %2759 = call float @dx.op.unary.f32(i32 23, float %2756)  ; Log(value)
  %2760 = call float @dx.op.unary.f32(i32 23, float %2757)  ; Log(value)
  %2761 = fmul fast float %2758, 0x3FDAAAAAA0000000
  %2762 = fmul fast float %2759, 0x3FDAAAAAA0000000
  %2763 = fmul fast float %2760, 0x3FDAAAAAA0000000
  %2764 = call float @dx.op.unary.f32(i32 21, float %2761)  ; Exp(value)
  %2765 = call float @dx.op.unary.f32(i32 21, float %2762)  ; Exp(value)
  %2766 = call float @dx.op.unary.f32(i32 21, float %2763)  ; Exp(value)
  %2767 = fmul fast float %2764, 0x3FF0E147A0000000
  %2768 = fmul fast float %2765, 0x3FF0E147A0000000
  %2769 = fmul fast float %2766, 0x3FF0E147A0000000
  %2770 = fadd fast float %2767, 0xBFAC28F5C0000000
  %2771 = fadd fast float %2768, 0xBFAC28F5C0000000
  %2772 = fadd fast float %2769, 0xBFAC28F5C0000000
  %2773 = fsub fast float %2752, %2770
  %2774 = fsub fast float %2753, %2771
  %2775 = fsub fast float %2754, %2772
  %2776 = fmul fast float %2773, %2749
  %2777 = fmul fast float %2774, %2750
  %2778 = fmul fast float %2775, %2751
  %2779 = fadd fast float %2776, %2770
  %2780 = fadd fast float %2777, %2771
  %2781 = fadd fast float %2778, %2772
  br label %2782

; <label>:2782                                    ; preds = %2742, %2107
  %2783 = phi float [ %2102, %2107 ], [ %2779, %2742 ]
  %2784 = phi float [ %2103, %2107 ], [ %2780, %2742 ]
  %2785 = phi float [ %2104, %2107 ], [ %2781, %2742 ]
  %2786 = phi float [ %2108, %2107 ], [ %2105, %2742 ]
  %2787 = call float @dx.op.unary.f32(i32 27, float %21)  ; Round_ni(value)
  %2788 = call float @dx.op.unary.f32(i32 27, float %22)  ; Round_ni(value)
  %2789 = fptosi float %2787 to i32
  %2790 = fptosi float %2788 to i32
  %2791 = call i32 @dx.op.binary.i32(i32 37, i32 %2789, i32 0)  ; IMax(a,b)
  %2792 = call i32 @dx.op.binary.i32(i32 37, i32 %2790, i32 0)  ; IMax(a,b)
  %2793 = call i32 @dx.op.binary.i32(i32 38, i32 %2791, i32 %31)  ; IMin(a,b)
  %2794 = call i32 @dx.op.binary.i32(i32 38, i32 %2792, i32 %32)  ; IMin(a,b)
  %2795 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2793, i32 %2794, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2796 = extractvalue %dx.types.ResRet.f32 %2795, 0
  %2797 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %35, i32 %36, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2798 = extractvalue %dx.types.ResRet.f32 %2797, 0
  %2799 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %725, i32 %36, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2800 = extractvalue %dx.types.ResRet.f32 %2799, 0
  %2801 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %35, i32 %1414, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2802 = extractvalue %dx.types.ResRet.f32 %2801, 0
  %2803 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %725, i32 %1414, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2804 = extractvalue %dx.types.ResRet.f32 %2803, 0
  %2805 = fsub fast float 1.000000e+00, %29
  %2806 = fsub fast float 1.000000e+00, %30
  %2807 = fmul fast float %2806, %2805
  %2808 = fmul fast float %2806, %29
  %2809 = fmul fast float %2805, %30
  %2810 = fmul fast float %30, %29
  %2811 = fsub fast float 1.000000e+00, %2796
  %2812 = fmul fast float %2811, 0x3FA99999A0000000
  %2813 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %2812)  ; FMax(a,b)
  %2814 = fsub fast float %2798, %2796
  %2815 = fsub fast float %2800, %2796
  %2816 = fsub fast float %2802, %2796
  %2817 = fsub fast float %2804, %2796
  %2818 = call float @dx.op.unary.f32(i32 6, float %2814)  ; FAbs(value)
  %2819 = call float @dx.op.unary.f32(i32 6, float %2815)  ; FAbs(value)
  %2820 = call float @dx.op.unary.f32(i32 6, float %2816)  ; FAbs(value)
  %2821 = call float @dx.op.unary.f32(i32 6, float %2817)  ; FAbs(value)
  %2822 = fdiv fast float %2818, %2813
  %2823 = fdiv fast float %2819, %2813
  %2824 = fdiv fast float %2820, %2813
  %2825 = fdiv fast float %2821, %2813
  %2826 = fsub fast float 1.000000e+00, %2822
  %2827 = fsub fast float 1.000000e+00, %2823
  %2828 = fsub fast float 1.000000e+00, %2824
  %2829 = fsub fast float 1.000000e+00, %2825
  %2830 = call float @dx.op.unary.f32(i32 7, float %2826)  ; Saturate(value)
  %2831 = call float @dx.op.unary.f32(i32 7, float %2827)  ; Saturate(value)
  %2832 = call float @dx.op.unary.f32(i32 7, float %2828)  ; Saturate(value)
  %2833 = call float @dx.op.unary.f32(i32 7, float %2829)  ; Saturate(value)
  %2834 = fmul fast float %2807, %2830
  %2835 = fmul fast float %2808, %2831
  %2836 = fmul fast float %2809, %2832
  %2837 = fmul fast float %2810, %2833
  %2838 = call float @dx.op.dot4.f32(i32 56, float %2834, float %2835, float %2836, float %2837, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %2839 = call float @dx.op.binary.f32(i32 35, float %2838, float 0x3EE4F8B580000000)  ; FMax(a,b)
  %2840 = fdiv fast float %2834, %2839
  %2841 = fdiv fast float %2835, %2839
  %2842 = fdiv fast float %2836, %2839
  %2843 = fdiv fast float %2837, %2839
  %2844 = fcmp fast ogt float %719, 0x3FA4B5DCC0000000
  %2845 = fcmp fast ogt float %720, 0x3FA4B5DCC0000000
  %2846 = fcmp fast ogt float %721, 0x3FA4B5DCC0000000
  %2847 = select i1 %2844, float 0.000000e+00, float 1.000000e+00
  %2848 = select i1 %2845, float 0.000000e+00, float 1.000000e+00
  %2849 = select i1 %2846, float 0.000000e+00, float 1.000000e+00
  %2850 = fmul fast float %719, 0x3FB3D07220000000
  %2851 = fmul fast float %720, 0x3FB3D07220000000
  %2852 = fmul fast float %721, 0x3FB3D07220000000
  %2853 = fadd fast float %719, 0x3FAC28F5C0000000
  %2854 = fadd fast float %720, 0x3FAC28F5C0000000
  %2855 = fadd fast float %721, 0x3FAC28F5C0000000
  %2856 = fmul fast float %2853, 0x3FEE54EDE0000000
  %2857 = fmul fast float %2854, 0x3FEE54EDE0000000
  %2858 = fmul fast float %2855, 0x3FEE54EDE0000000
  %2859 = call float @dx.op.unary.f32(i32 23, float %2856)  ; Log(value)
  %2860 = call float @dx.op.unary.f32(i32 23, float %2857)  ; Log(value)
  %2861 = call float @dx.op.unary.f32(i32 23, float %2858)  ; Log(value)
  %2862 = fmul fast float %2859, 0x4003333340000000
  %2863 = fmul fast float %2860, 0x4003333340000000
  %2864 = fmul fast float %2861, 0x4003333340000000
  %2865 = call float @dx.op.unary.f32(i32 21, float %2862)  ; Exp(value)
  %2866 = call float @dx.op.unary.f32(i32 21, float %2863)  ; Exp(value)
  %2867 = call float @dx.op.unary.f32(i32 21, float %2864)  ; Exp(value)
  %2868 = fsub fast float %2850, %2865
  %2869 = fsub fast float %2851, %2866
  %2870 = fsub fast float %2852, %2867
  %2871 = fmul fast float %2868, %2847
  %2872 = fmul fast float %2869, %2848
  %2873 = fmul fast float %2870, %2849
  %2874 = fadd fast float %2871, %2865
  %2875 = fadd fast float %2872, %2866
  %2876 = fadd fast float %2873, %2867
  %2877 = fmul fast float %2874, %2840
  %2878 = fmul fast float %2875, %2840
  %2879 = fmul fast float %2876, %2840
  %2880 = fcmp fast ogt float %1408, 0x3FA4B5DCC0000000
  %2881 = fcmp fast ogt float %1409, 0x3FA4B5DCC0000000
  %2882 = fcmp fast ogt float %1410, 0x3FA4B5DCC0000000
  %2883 = select i1 %2880, float 0.000000e+00, float 1.000000e+00
  %2884 = select i1 %2881, float 0.000000e+00, float 1.000000e+00
  %2885 = select i1 %2882, float 0.000000e+00, float 1.000000e+00
  %2886 = fmul fast float %1408, 0x3FB3D07220000000
  %2887 = fmul fast float %1409, 0x3FB3D07220000000
  %2888 = fmul fast float %1410, 0x3FB3D07220000000
  %2889 = fadd fast float %1408, 0x3FAC28F5C0000000
  %2890 = fadd fast float %1409, 0x3FAC28F5C0000000
  %2891 = fadd fast float %1410, 0x3FAC28F5C0000000
  %2892 = fmul fast float %2889, 0x3FEE54EDE0000000
  %2893 = fmul fast float %2890, 0x3FEE54EDE0000000
  %2894 = fmul fast float %2891, 0x3FEE54EDE0000000
  %2895 = call float @dx.op.unary.f32(i32 23, float %2892)  ; Log(value)
  %2896 = call float @dx.op.unary.f32(i32 23, float %2893)  ; Log(value)
  %2897 = call float @dx.op.unary.f32(i32 23, float %2894)  ; Log(value)
  %2898 = fmul fast float %2895, 0x4003333340000000
  %2899 = fmul fast float %2896, 0x4003333340000000
  %2900 = fmul fast float %2897, 0x4003333340000000
  %2901 = call float @dx.op.unary.f32(i32 21, float %2898)  ; Exp(value)
  %2902 = call float @dx.op.unary.f32(i32 21, float %2899)  ; Exp(value)
  %2903 = call float @dx.op.unary.f32(i32 21, float %2900)  ; Exp(value)
  %2904 = fsub fast float %2886, %2901
  %2905 = fsub fast float %2887, %2902
  %2906 = fsub fast float %2888, %2903
  %2907 = fmul fast float %2904, %2883
  %2908 = fmul fast float %2905, %2884
  %2909 = fmul fast float %2906, %2885
  %2910 = fadd fast float %2907, %2901
  %2911 = fadd fast float %2908, %2902
  %2912 = fadd fast float %2909, %2903
  %2913 = fmul fast float %2910, %2841
  %2914 = fmul fast float %2911, %2841
  %2915 = fmul fast float %2912, %2841
  %2916 = fadd fast float %2913, %2877
  %2917 = fadd fast float %2914, %2878
  %2918 = fadd fast float %2915, %2879
  %2919 = fcmp fast ogt float %2097, 0x3FA4B5DCC0000000
  %2920 = fcmp fast ogt float %2098, 0x3FA4B5DCC0000000
  %2921 = fcmp fast ogt float %2099, 0x3FA4B5DCC0000000
  %2922 = select i1 %2919, float 0.000000e+00, float 1.000000e+00
  %2923 = select i1 %2920, float 0.000000e+00, float 1.000000e+00
  %2924 = select i1 %2921, float 0.000000e+00, float 1.000000e+00
  %2925 = fmul fast float %2097, 0x3FB3D07220000000
  %2926 = fmul fast float %2098, 0x3FB3D07220000000
  %2927 = fmul fast float %2099, 0x3FB3D07220000000
  %2928 = fadd fast float %2097, 0x3FAC28F5C0000000
  %2929 = fadd fast float %2098, 0x3FAC28F5C0000000
  %2930 = fadd fast float %2099, 0x3FAC28F5C0000000
  %2931 = fmul fast float %2928, 0x3FEE54EDE0000000
  %2932 = fmul fast float %2929, 0x3FEE54EDE0000000
  %2933 = fmul fast float %2930, 0x3FEE54EDE0000000
  %2934 = call float @dx.op.unary.f32(i32 23, float %2931)  ; Log(value)
  %2935 = call float @dx.op.unary.f32(i32 23, float %2932)  ; Log(value)
  %2936 = call float @dx.op.unary.f32(i32 23, float %2933)  ; Log(value)
  %2937 = fmul fast float %2934, 0x4003333340000000
  %2938 = fmul fast float %2935, 0x4003333340000000
  %2939 = fmul fast float %2936, 0x4003333340000000
  %2940 = call float @dx.op.unary.f32(i32 21, float %2937)  ; Exp(value)
  %2941 = call float @dx.op.unary.f32(i32 21, float %2938)  ; Exp(value)
  %2942 = call float @dx.op.unary.f32(i32 21, float %2939)  ; Exp(value)
  %2943 = fsub fast float %2925, %2940
  %2944 = fsub fast float %2926, %2941
  %2945 = fsub fast float %2927, %2942
  %2946 = fmul fast float %2943, %2922
  %2947 = fmul fast float %2944, %2923
  %2948 = fmul fast float %2945, %2924
  %2949 = fadd fast float %2946, %2940
  %2950 = fadd fast float %2947, %2941
  %2951 = fadd fast float %2948, %2942
  %2952 = fmul fast float %2949, %2842
  %2953 = fmul fast float %2950, %2842
  %2954 = fmul fast float %2951, %2842
  %2955 = fadd fast float %2916, %2952
  %2956 = fadd fast float %2917, %2953
  %2957 = fadd fast float %2918, %2954
  %2958 = fcmp fast ogt float %2783, 0x3FA4B5DCC0000000
  %2959 = fcmp fast ogt float %2784, 0x3FA4B5DCC0000000
  %2960 = fcmp fast ogt float %2785, 0x3FA4B5DCC0000000
  %2961 = select i1 %2958, float 0.000000e+00, float 1.000000e+00
  %2962 = select i1 %2959, float 0.000000e+00, float 1.000000e+00
  %2963 = select i1 %2960, float 0.000000e+00, float 1.000000e+00
  %2964 = fmul fast float %2783, 0x3FB3D07220000000
  %2965 = fmul fast float %2784, 0x3FB3D07220000000
  %2966 = fmul fast float %2785, 0x3FB3D07220000000
  %2967 = fadd fast float %2783, 0x3FAC28F5C0000000
  %2968 = fadd fast float %2784, 0x3FAC28F5C0000000
  %2969 = fadd fast float %2785, 0x3FAC28F5C0000000
  %2970 = fmul fast float %2967, 0x3FEE54EDE0000000
  %2971 = fmul fast float %2968, 0x3FEE54EDE0000000
  %2972 = fmul fast float %2969, 0x3FEE54EDE0000000
  %2973 = call float @dx.op.unary.f32(i32 23, float %2970)  ; Log(value)
  %2974 = call float @dx.op.unary.f32(i32 23, float %2971)  ; Log(value)
  %2975 = call float @dx.op.unary.f32(i32 23, float %2972)  ; Log(value)
  %2976 = fmul fast float %2973, 0x4003333340000000
  %2977 = fmul fast float %2974, 0x4003333340000000
  %2978 = fmul fast float %2975, 0x4003333340000000
  %2979 = call float @dx.op.unary.f32(i32 21, float %2976)  ; Exp(value)
  %2980 = call float @dx.op.unary.f32(i32 21, float %2977)  ; Exp(value)
  %2981 = call float @dx.op.unary.f32(i32 21, float %2978)  ; Exp(value)
  %2982 = fsub fast float %2964, %2979
  %2983 = fsub fast float %2965, %2980
  %2984 = fsub fast float %2966, %2981
  %2985 = fmul fast float %2982, %2961
  %2986 = fmul fast float %2983, %2962
  %2987 = fmul fast float %2984, %2963
  %2988 = fadd fast float %2985, %2979
  %2989 = fadd fast float %2986, %2980
  %2990 = fadd fast float %2987, %2981
  %2991 = fmul fast float %2988, %2843
  %2992 = fmul fast float %2989, %2843
  %2993 = fmul fast float %2990, %2843
  %2994 = fadd fast float %2955, %2991
  %2995 = fadd fast float %2956, %2992
  %2996 = fadd fast float %2957, %2993
  %2997 = fcmp fast ogt float %2994, 0x3F69A5C380000000
  %2998 = fcmp fast ogt float %2995, 0x3F69A5C380000000
  %2999 = fcmp fast ogt float %2996, 0x3F69A5C380000000
  %3000 = select i1 %2997, float 0.000000e+00, float 1.000000e+00
  %3001 = select i1 %2998, float 0.000000e+00, float 1.000000e+00
  %3002 = select i1 %2999, float 0.000000e+00, float 1.000000e+00
  %3003 = fmul fast float %2994, 0x4029D70A40000000
  %3004 = fmul fast float %2995, 0x4029D70A40000000
  %3005 = fmul fast float %2996, 0x4029D70A40000000
  %3006 = call float @dx.op.binary.f32(i32 35, float %2994, float 0.000000e+00)  ; FMax(a,b)
  %3007 = call float @dx.op.binary.f32(i32 35, float %2995, float 0.000000e+00)  ; FMax(a,b)
  %3008 = call float @dx.op.binary.f32(i32 35, float %2996, float 0.000000e+00)  ; FMax(a,b)
  %3009 = call float @dx.op.unary.f32(i32 23, float %3006)  ; Log(value)
  %3010 = call float @dx.op.unary.f32(i32 23, float %3007)  ; Log(value)
  %3011 = call float @dx.op.unary.f32(i32 23, float %3008)  ; Log(value)
  %3012 = fmul fast float %3009, 0x3FDAAAAAA0000000
  %3013 = fmul fast float %3010, 0x3FDAAAAAA0000000
  %3014 = fmul fast float %3011, 0x3FDAAAAAA0000000
  %3015 = call float @dx.op.unary.f32(i32 21, float %3012)  ; Exp(value)
  %3016 = call float @dx.op.unary.f32(i32 21, float %3013)  ; Exp(value)
  %3017 = call float @dx.op.unary.f32(i32 21, float %3014)  ; Exp(value)
  %3018 = fmul fast float %3015, 0x3FF0E147A0000000
  %3019 = fmul fast float %3016, 0x3FF0E147A0000000
  %3020 = fmul fast float %3017, 0x3FF0E147A0000000
  %3021 = fadd fast float %3018, 0xBFAC28F5C0000000
  %3022 = fadd fast float %3019, 0xBFAC28F5C0000000
  %3023 = fadd fast float %3020, 0xBFAC28F5C0000000
  %3024 = fsub fast float %3003, %3021
  %3025 = fsub fast float %3004, %3022
  %3026 = fsub fast float %3005, %3023
  %3027 = fmul fast float %3024, %3000
  %3028 = fmul fast float %3025, %3001
  %3029 = fmul fast float %3026, %3002
  %3030 = fadd fast float %3027, %3021
  %3031 = fadd fast float %3028, %3022
  %3032 = fadd fast float %3029, %3023
  %3033 = call float @dx.op.dot4.f32(i32 56, float %722, float %1411, float %2100, float %2786, float %2840, float %2841, float %2842, float %2843)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %3030)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %3031)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %3032)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %3033)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %2796)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !37, null}
!12 = !{!13, !16, !17, !19, !21, !23, !25, !27, !29, !31, !34}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !15}
!17 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !18, i8 1, i32 1, i8 4, i32 2, i8 0, null}
!18 = !{i32 1}
!19 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !20, i8 1, i32 1, i8 4, i32 3, i8 0, null}
!20 = !{i32 2}
!21 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !22, i8 1, i32 1, i8 4, i32 4, i8 0, null}
!22 = !{i32 3}
!23 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !24, i8 1, i32 1, i8 4, i32 5, i8 0, null}
!24 = !{i32 4}
!25 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !26, i8 1, i32 1, i8 4, i32 6, i8 0, null}
!26 = !{i32 5}
!27 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !28, i8 1, i32 1, i8 4, i32 7, i8 0, null}
!28 = !{i32 6}
!29 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 8, i8 0, null}
!30 = !{i32 7}
!31 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 9, i8 0, !33}
!32 = !{i32 8}
!33 = !{i32 3, i32 15}
!34 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !35, i8 1, i32 1, i8 4, i32 10, i8 0, !36}
!35 = !{i32 9}
!36 = !{i32 3, i32 7}
!37 = !{!38, !39}
!38 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !33}
!39 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !40}
!40 = !{i32 3, i32 1}
