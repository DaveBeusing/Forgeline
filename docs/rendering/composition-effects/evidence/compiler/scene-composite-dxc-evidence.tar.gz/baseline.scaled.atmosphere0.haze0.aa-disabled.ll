;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xy  
; TEXCOORD                 1   xyzw        2     NONE   float       
; TEXCOORD                 2   xyzw        3     NONE   float       
; TEXCOORD                 3   xyzw        4     NONE   float       
; TEXCOORD                 4   xyzw        5     NONE   float       
; TEXCOORD                 5   xyzw        6     NONE   float       
; TEXCOORD                 6   xyzw        7     NONE   float       
; TEXCOORD                 7   xyzw        8     NONE   float       
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float    yz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: 7d3ff674ba9fd981c6da10c5c7daa972
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %14 = extractvalue %dx.types.Dimensions %13, 0
  %15 = extractvalue %dx.types.Dimensions %13, 1
  %16 = uitofp i32 %14 to float
  %17 = uitofp i32 %15 to float
  %18 = fmul fast float %16, %11
  %19 = fmul fast float %17, %12
  %20 = fdiv fast float %18, %3
  %21 = fdiv fast float %19, %4
  %22 = fadd fast float %20, -5.000000e-01
  %23 = fadd fast float %21, -5.000000e-01
  %24 = call float @dx.op.unary.f32(i32 27, float %22)  ; Round_ni(value)
  %25 = call float @dx.op.unary.f32(i32 27, float %23)  ; Round_ni(value)
  %26 = fptosi float %24 to i32
  %27 = fptosi float %25 to i32
  %28 = call float @dx.op.unary.f32(i32 22, float %22)  ; Frc(value)
  %29 = call float @dx.op.unary.f32(i32 22, float %23)  ; Frc(value)
  %30 = add i32 %14, -1
  %31 = add i32 %15, -1
  %32 = call i32 @dx.op.binary.i32(i32 37, i32 %26, i32 0)  ; IMax(a,b)
  %33 = call i32 @dx.op.binary.i32(i32 37, i32 %27, i32 0)  ; IMax(a,b)
  %34 = call i32 @dx.op.binary.i32(i32 38, i32 %32, i32 %30)  ; IMin(a,b)
  %35 = call i32 @dx.op.binary.i32(i32 38, i32 %33, i32 %31)  ; IMin(a,b)
  %36 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %34, i32 %35, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %37 = extractvalue %dx.types.ResRet.f32 %36, 0
  %38 = extractvalue %dx.types.ResRet.f32 %36, 1
  %39 = extractvalue %dx.types.ResRet.f32 %36, 2
  %40 = extractvalue %dx.types.ResRet.f32 %36, 3
  %41 = fcmp fast olt float %40, 0.000000e+00
  br i1 %41, label %42, label %44

; <label>:42                                      ; preds = %0
  %43 = fsub fast float -1.000000e+00, %40
  br label %148

; <label>:44                                      ; preds = %0
  %45 = fadd fast float %5, 1.000000e+00
  %46 = fadd fast float %6, 1.000000e+00
  %47 = fsub fast float 1.000000e+00, %5
  %48 = fmul fast float %9, %45
  %49 = fmul fast float %9, %46
  %50 = fmul fast float %9, %47
  %51 = fmul fast float %48, %37
  %52 = fmul fast float %49, %38
  %53 = fmul fast float %50, %39
  %54 = fcmp fast ult float %10, 5.000000e-01
  br i1 %54, label %80, label %55

; <label>:55                                      ; preds = %44
  %56 = fmul fast float %51, 0x4004147AE0000000
  %57 = fmul fast float %52, 0x4004147AE0000000
  %58 = fmul fast float %53, 0x4004147AE0000000
  %59 = fadd fast float %56, 0x3F9EB851E0000000
  %60 = fadd fast float %57, 0x3F9EB851E0000000
  %61 = fadd fast float %58, 0x3F9EB851E0000000
  %62 = fmul fast float %59, %51
  %63 = fmul fast float %60, %52
  %64 = fmul fast float %61, %53
  %65 = fmul fast float %51, 0x400370A3E0000000
  %66 = fmul fast float %52, 0x400370A3E0000000
  %67 = fmul fast float %53, 0x400370A3E0000000
  %68 = fadd fast float %65, 0x3FE2E147A0000000
  %69 = fadd fast float %66, 0x3FE2E147A0000000
  %70 = fadd fast float %67, 0x3FE2E147A0000000
  %71 = fmul fast float %68, %51
  %72 = fmul fast float %69, %52
  %73 = fmul fast float %70, %53
  %74 = fadd fast float %71, 0x3FC1EB8520000000
  %75 = fadd fast float %72, 0x3FC1EB8520000000
  %76 = fadd fast float %73, 0x3FC1EB8520000000
  %77 = fdiv fast float %62, %74
  %78 = fdiv fast float %63, %75
  %79 = fdiv fast float %64, %76
  br label %80

; <label>:80                                      ; preds = %55, %44
  %81 = phi float [ %77, %55 ], [ %51, %44 ]
  %82 = phi float [ %78, %55 ], [ %52, %44 ]
  %83 = phi float [ %79, %55 ], [ %53, %44 ]
  %84 = call float @dx.op.unary.f32(i32 7, float %81)  ; Saturate(value)
  %85 = call float @dx.op.unary.f32(i32 7, float %82)  ; Saturate(value)
  %86 = call float @dx.op.unary.f32(i32 7, float %83)  ; Saturate(value)
  %87 = call float @dx.op.dot3.f32(i32 55, float %84, float %85, float %86, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %88 = fsub fast float %84, %87
  %89 = fsub fast float %85, %87
  %90 = fsub fast float %86, %87
  %91 = fmul fast float %88, %8
  %92 = fmul fast float %89, %8
  %93 = fmul fast float %90, %8
  %94 = fadd fast float %91, %87
  %95 = fadd fast float %92, %87
  %96 = fadd fast float %93, %87
  %97 = call float @dx.op.unary.f32(i32 7, float %94)  ; Saturate(value)
  %98 = call float @dx.op.unary.f32(i32 7, float %95)  ; Saturate(value)
  %99 = call float @dx.op.unary.f32(i32 7, float %96)  ; Saturate(value)
  %100 = fadd fast float %97, 0xBFC70A3D80000000
  %101 = fadd fast float %98, 0xBFC70A3D80000000
  %102 = fadd fast float %99, 0xBFC70A3D80000000
  %103 = fmul fast float %100, %7
  %104 = fmul fast float %101, %7
  %105 = fmul fast float %102, %7
  %106 = fadd fast float %103, 0x3FC70A3D80000000
  %107 = fadd fast float %104, 0x3FC70A3D80000000
  %108 = fadd fast float %105, 0x3FC70A3D80000000
  %109 = call float @dx.op.unary.f32(i32 7, float %106)  ; Saturate(value)
  %110 = call float @dx.op.unary.f32(i32 7, float %107)  ; Saturate(value)
  %111 = call float @dx.op.unary.f32(i32 7, float %108)  ; Saturate(value)
  %112 = fcmp fast ogt float %109, 0x3F69A5C380000000
  %113 = fcmp fast ogt float %110, 0x3F69A5C380000000
  %114 = fcmp fast ogt float %111, 0x3F69A5C380000000
  %115 = select i1 %112, float 0.000000e+00, float 1.000000e+00
  %116 = select i1 %113, float 0.000000e+00, float 1.000000e+00
  %117 = select i1 %114, float 0.000000e+00, float 1.000000e+00
  %118 = fmul fast float %109, 0x4029D70A40000000
  %119 = fmul fast float %110, 0x4029D70A40000000
  %120 = fmul fast float %111, 0x4029D70A40000000
  %121 = call float @dx.op.binary.f32(i32 35, float %109, float 0.000000e+00)  ; FMax(a,b)
  %122 = call float @dx.op.binary.f32(i32 35, float %110, float 0.000000e+00)  ; FMax(a,b)
  %123 = call float @dx.op.binary.f32(i32 35, float %111, float 0.000000e+00)  ; FMax(a,b)
  %124 = call float @dx.op.unary.f32(i32 23, float %121)  ; Log(value)
  %125 = call float @dx.op.unary.f32(i32 23, float %122)  ; Log(value)
  %126 = call float @dx.op.unary.f32(i32 23, float %123)  ; Log(value)
  %127 = fmul fast float %124, 0x3FDAAAAAA0000000
  %128 = fmul fast float %125, 0x3FDAAAAAA0000000
  %129 = fmul fast float %126, 0x3FDAAAAAA0000000
  %130 = call float @dx.op.unary.f32(i32 21, float %127)  ; Exp(value)
  %131 = call float @dx.op.unary.f32(i32 21, float %128)  ; Exp(value)
  %132 = call float @dx.op.unary.f32(i32 21, float %129)  ; Exp(value)
  %133 = fmul fast float %130, 0x3FF0E147A0000000
  %134 = fmul fast float %131, 0x3FF0E147A0000000
  %135 = fmul fast float %132, 0x3FF0E147A0000000
  %136 = fadd fast float %133, 0xBFAC28F5C0000000
  %137 = fadd fast float %134, 0xBFAC28F5C0000000
  %138 = fadd fast float %135, 0xBFAC28F5C0000000
  %139 = fsub fast float %118, %136
  %140 = fsub fast float %119, %137
  %141 = fsub fast float %120, %138
  %142 = fmul fast float %139, %115
  %143 = fmul fast float %140, %116
  %144 = fmul fast float %141, %117
  %145 = fadd fast float %142, %136
  %146 = fadd fast float %143, %137
  %147 = fadd fast float %144, %138
  br label %148

; <label>:148                                     ; preds = %80, %42
  %149 = phi float [ %37, %42 ], [ %145, %80 ]
  %150 = phi float [ %38, %42 ], [ %146, %80 ]
  %151 = phi float [ %39, %42 ], [ %147, %80 ]
  %152 = phi float [ %43, %42 ], [ %40, %80 ]
  %153 = add i32 %26, 1
  %154 = call i32 @dx.op.binary.i32(i32 37, i32 %153, i32 0)  ; IMax(a,b)
  %155 = call i32 @dx.op.binary.i32(i32 38, i32 %154, i32 %30)  ; IMin(a,b)
  %156 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %155, i32 %35, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %157 = extractvalue %dx.types.ResRet.f32 %156, 0
  %158 = extractvalue %dx.types.ResRet.f32 %156, 1
  %159 = extractvalue %dx.types.ResRet.f32 %156, 2
  %160 = extractvalue %dx.types.ResRet.f32 %156, 3
  %161 = fcmp fast olt float %160, 0.000000e+00
  br i1 %161, label %162, label %164

; <label>:162                                     ; preds = %148
  %163 = fsub fast float -1.000000e+00, %160
  br label %268

; <label>:164                                     ; preds = %148
  %165 = fadd fast float %5, 1.000000e+00
  %166 = fadd fast float %6, 1.000000e+00
  %167 = fsub fast float 1.000000e+00, %5
  %168 = fmul fast float %9, %165
  %169 = fmul fast float %9, %166
  %170 = fmul fast float %9, %167
  %171 = fmul fast float %168, %157
  %172 = fmul fast float %169, %158
  %173 = fmul fast float %170, %159
  %174 = fcmp fast ult float %10, 5.000000e-01
  br i1 %174, label %200, label %175

; <label>:175                                     ; preds = %164
  %176 = fmul fast float %171, 0x4004147AE0000000
  %177 = fmul fast float %172, 0x4004147AE0000000
  %178 = fmul fast float %173, 0x4004147AE0000000
  %179 = fadd fast float %176, 0x3F9EB851E0000000
  %180 = fadd fast float %177, 0x3F9EB851E0000000
  %181 = fadd fast float %178, 0x3F9EB851E0000000
  %182 = fmul fast float %179, %171
  %183 = fmul fast float %180, %172
  %184 = fmul fast float %181, %173
  %185 = fmul fast float %171, 0x400370A3E0000000
  %186 = fmul fast float %172, 0x400370A3E0000000
  %187 = fmul fast float %173, 0x400370A3E0000000
  %188 = fadd fast float %185, 0x3FE2E147A0000000
  %189 = fadd fast float %186, 0x3FE2E147A0000000
  %190 = fadd fast float %187, 0x3FE2E147A0000000
  %191 = fmul fast float %188, %171
  %192 = fmul fast float %189, %172
  %193 = fmul fast float %190, %173
  %194 = fadd fast float %191, 0x3FC1EB8520000000
  %195 = fadd fast float %192, 0x3FC1EB8520000000
  %196 = fadd fast float %193, 0x3FC1EB8520000000
  %197 = fdiv fast float %182, %194
  %198 = fdiv fast float %183, %195
  %199 = fdiv fast float %184, %196
  br label %200

; <label>:200                                     ; preds = %175, %164
  %201 = phi float [ %197, %175 ], [ %171, %164 ]
  %202 = phi float [ %198, %175 ], [ %172, %164 ]
  %203 = phi float [ %199, %175 ], [ %173, %164 ]
  %204 = call float @dx.op.unary.f32(i32 7, float %201)  ; Saturate(value)
  %205 = call float @dx.op.unary.f32(i32 7, float %202)  ; Saturate(value)
  %206 = call float @dx.op.unary.f32(i32 7, float %203)  ; Saturate(value)
  %207 = call float @dx.op.dot3.f32(i32 55, float %204, float %205, float %206, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %208 = fsub fast float %204, %207
  %209 = fsub fast float %205, %207
  %210 = fsub fast float %206, %207
  %211 = fmul fast float %208, %8
  %212 = fmul fast float %209, %8
  %213 = fmul fast float %210, %8
  %214 = fadd fast float %211, %207
  %215 = fadd fast float %212, %207
  %216 = fadd fast float %213, %207
  %217 = call float @dx.op.unary.f32(i32 7, float %214)  ; Saturate(value)
  %218 = call float @dx.op.unary.f32(i32 7, float %215)  ; Saturate(value)
  %219 = call float @dx.op.unary.f32(i32 7, float %216)  ; Saturate(value)
  %220 = fadd fast float %217, 0xBFC70A3D80000000
  %221 = fadd fast float %218, 0xBFC70A3D80000000
  %222 = fadd fast float %219, 0xBFC70A3D80000000
  %223 = fmul fast float %220, %7
  %224 = fmul fast float %221, %7
  %225 = fmul fast float %222, %7
  %226 = fadd fast float %223, 0x3FC70A3D80000000
  %227 = fadd fast float %224, 0x3FC70A3D80000000
  %228 = fadd fast float %225, 0x3FC70A3D80000000
  %229 = call float @dx.op.unary.f32(i32 7, float %226)  ; Saturate(value)
  %230 = call float @dx.op.unary.f32(i32 7, float %227)  ; Saturate(value)
  %231 = call float @dx.op.unary.f32(i32 7, float %228)  ; Saturate(value)
  %232 = fcmp fast ogt float %229, 0x3F69A5C380000000
  %233 = fcmp fast ogt float %230, 0x3F69A5C380000000
  %234 = fcmp fast ogt float %231, 0x3F69A5C380000000
  %235 = select i1 %232, float 0.000000e+00, float 1.000000e+00
  %236 = select i1 %233, float 0.000000e+00, float 1.000000e+00
  %237 = select i1 %234, float 0.000000e+00, float 1.000000e+00
  %238 = fmul fast float %229, 0x4029D70A40000000
  %239 = fmul fast float %230, 0x4029D70A40000000
  %240 = fmul fast float %231, 0x4029D70A40000000
  %241 = call float @dx.op.binary.f32(i32 35, float %229, float 0.000000e+00)  ; FMax(a,b)
  %242 = call float @dx.op.binary.f32(i32 35, float %230, float 0.000000e+00)  ; FMax(a,b)
  %243 = call float @dx.op.binary.f32(i32 35, float %231, float 0.000000e+00)  ; FMax(a,b)
  %244 = call float @dx.op.unary.f32(i32 23, float %241)  ; Log(value)
  %245 = call float @dx.op.unary.f32(i32 23, float %242)  ; Log(value)
  %246 = call float @dx.op.unary.f32(i32 23, float %243)  ; Log(value)
  %247 = fmul fast float %244, 0x3FDAAAAAA0000000
  %248 = fmul fast float %245, 0x3FDAAAAAA0000000
  %249 = fmul fast float %246, 0x3FDAAAAAA0000000
  %250 = call float @dx.op.unary.f32(i32 21, float %247)  ; Exp(value)
  %251 = call float @dx.op.unary.f32(i32 21, float %248)  ; Exp(value)
  %252 = call float @dx.op.unary.f32(i32 21, float %249)  ; Exp(value)
  %253 = fmul fast float %250, 0x3FF0E147A0000000
  %254 = fmul fast float %251, 0x3FF0E147A0000000
  %255 = fmul fast float %252, 0x3FF0E147A0000000
  %256 = fadd fast float %253, 0xBFAC28F5C0000000
  %257 = fadd fast float %254, 0xBFAC28F5C0000000
  %258 = fadd fast float %255, 0xBFAC28F5C0000000
  %259 = fsub fast float %238, %256
  %260 = fsub fast float %239, %257
  %261 = fsub fast float %240, %258
  %262 = fmul fast float %259, %235
  %263 = fmul fast float %260, %236
  %264 = fmul fast float %261, %237
  %265 = fadd fast float %262, %256
  %266 = fadd fast float %263, %257
  %267 = fadd fast float %264, %258
  br label %268

; <label>:268                                     ; preds = %200, %162
  %269 = phi float [ %157, %162 ], [ %265, %200 ]
  %270 = phi float [ %158, %162 ], [ %266, %200 ]
  %271 = phi float [ %159, %162 ], [ %267, %200 ]
  %272 = phi float [ %163, %162 ], [ %160, %200 ]
  %273 = add i32 %27, 1
  %274 = call i32 @dx.op.binary.i32(i32 37, i32 %273, i32 0)  ; IMax(a,b)
  %275 = call i32 @dx.op.binary.i32(i32 38, i32 %274, i32 %31)  ; IMin(a,b)
  %276 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %34, i32 %275, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %277 = extractvalue %dx.types.ResRet.f32 %276, 0
  %278 = extractvalue %dx.types.ResRet.f32 %276, 1
  %279 = extractvalue %dx.types.ResRet.f32 %276, 2
  %280 = extractvalue %dx.types.ResRet.f32 %276, 3
  %281 = fcmp fast olt float %280, 0.000000e+00
  br i1 %281, label %282, label %284

; <label>:282                                     ; preds = %268
  %283 = fsub fast float -1.000000e+00, %280
  br label %388

; <label>:284                                     ; preds = %268
  %285 = fadd fast float %5, 1.000000e+00
  %286 = fadd fast float %6, 1.000000e+00
  %287 = fsub fast float 1.000000e+00, %5
  %288 = fmul fast float %9, %285
  %289 = fmul fast float %9, %286
  %290 = fmul fast float %9, %287
  %291 = fmul fast float %288, %277
  %292 = fmul fast float %289, %278
  %293 = fmul fast float %290, %279
  %294 = fcmp fast ult float %10, 5.000000e-01
  br i1 %294, label %320, label %295

; <label>:295                                     ; preds = %284
  %296 = fmul fast float %291, 0x4004147AE0000000
  %297 = fmul fast float %292, 0x4004147AE0000000
  %298 = fmul fast float %293, 0x4004147AE0000000
  %299 = fadd fast float %296, 0x3F9EB851E0000000
  %300 = fadd fast float %297, 0x3F9EB851E0000000
  %301 = fadd fast float %298, 0x3F9EB851E0000000
  %302 = fmul fast float %299, %291
  %303 = fmul fast float %300, %292
  %304 = fmul fast float %301, %293
  %305 = fmul fast float %291, 0x400370A3E0000000
  %306 = fmul fast float %292, 0x400370A3E0000000
  %307 = fmul fast float %293, 0x400370A3E0000000
  %308 = fadd fast float %305, 0x3FE2E147A0000000
  %309 = fadd fast float %306, 0x3FE2E147A0000000
  %310 = fadd fast float %307, 0x3FE2E147A0000000
  %311 = fmul fast float %308, %291
  %312 = fmul fast float %309, %292
  %313 = fmul fast float %310, %293
  %314 = fadd fast float %311, 0x3FC1EB8520000000
  %315 = fadd fast float %312, 0x3FC1EB8520000000
  %316 = fadd fast float %313, 0x3FC1EB8520000000
  %317 = fdiv fast float %302, %314
  %318 = fdiv fast float %303, %315
  %319 = fdiv fast float %304, %316
  br label %320

; <label>:320                                     ; preds = %295, %284
  %321 = phi float [ %317, %295 ], [ %291, %284 ]
  %322 = phi float [ %318, %295 ], [ %292, %284 ]
  %323 = phi float [ %319, %295 ], [ %293, %284 ]
  %324 = call float @dx.op.unary.f32(i32 7, float %321)  ; Saturate(value)
  %325 = call float @dx.op.unary.f32(i32 7, float %322)  ; Saturate(value)
  %326 = call float @dx.op.unary.f32(i32 7, float %323)  ; Saturate(value)
  %327 = call float @dx.op.dot3.f32(i32 55, float %324, float %325, float %326, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %328 = fsub fast float %324, %327
  %329 = fsub fast float %325, %327
  %330 = fsub fast float %326, %327
  %331 = fmul fast float %328, %8
  %332 = fmul fast float %329, %8
  %333 = fmul fast float %330, %8
  %334 = fadd fast float %331, %327
  %335 = fadd fast float %332, %327
  %336 = fadd fast float %333, %327
  %337 = call float @dx.op.unary.f32(i32 7, float %334)  ; Saturate(value)
  %338 = call float @dx.op.unary.f32(i32 7, float %335)  ; Saturate(value)
  %339 = call float @dx.op.unary.f32(i32 7, float %336)  ; Saturate(value)
  %340 = fadd fast float %337, 0xBFC70A3D80000000
  %341 = fadd fast float %338, 0xBFC70A3D80000000
  %342 = fadd fast float %339, 0xBFC70A3D80000000
  %343 = fmul fast float %340, %7
  %344 = fmul fast float %341, %7
  %345 = fmul fast float %342, %7
  %346 = fadd fast float %343, 0x3FC70A3D80000000
  %347 = fadd fast float %344, 0x3FC70A3D80000000
  %348 = fadd fast float %345, 0x3FC70A3D80000000
  %349 = call float @dx.op.unary.f32(i32 7, float %346)  ; Saturate(value)
  %350 = call float @dx.op.unary.f32(i32 7, float %347)  ; Saturate(value)
  %351 = call float @dx.op.unary.f32(i32 7, float %348)  ; Saturate(value)
  %352 = fcmp fast ogt float %349, 0x3F69A5C380000000
  %353 = fcmp fast ogt float %350, 0x3F69A5C380000000
  %354 = fcmp fast ogt float %351, 0x3F69A5C380000000
  %355 = select i1 %352, float 0.000000e+00, float 1.000000e+00
  %356 = select i1 %353, float 0.000000e+00, float 1.000000e+00
  %357 = select i1 %354, float 0.000000e+00, float 1.000000e+00
  %358 = fmul fast float %349, 0x4029D70A40000000
  %359 = fmul fast float %350, 0x4029D70A40000000
  %360 = fmul fast float %351, 0x4029D70A40000000
  %361 = call float @dx.op.binary.f32(i32 35, float %349, float 0.000000e+00)  ; FMax(a,b)
  %362 = call float @dx.op.binary.f32(i32 35, float %350, float 0.000000e+00)  ; FMax(a,b)
  %363 = call float @dx.op.binary.f32(i32 35, float %351, float 0.000000e+00)  ; FMax(a,b)
  %364 = call float @dx.op.unary.f32(i32 23, float %361)  ; Log(value)
  %365 = call float @dx.op.unary.f32(i32 23, float %362)  ; Log(value)
  %366 = call float @dx.op.unary.f32(i32 23, float %363)  ; Log(value)
  %367 = fmul fast float %364, 0x3FDAAAAAA0000000
  %368 = fmul fast float %365, 0x3FDAAAAAA0000000
  %369 = fmul fast float %366, 0x3FDAAAAAA0000000
  %370 = call float @dx.op.unary.f32(i32 21, float %367)  ; Exp(value)
  %371 = call float @dx.op.unary.f32(i32 21, float %368)  ; Exp(value)
  %372 = call float @dx.op.unary.f32(i32 21, float %369)  ; Exp(value)
  %373 = fmul fast float %370, 0x3FF0E147A0000000
  %374 = fmul fast float %371, 0x3FF0E147A0000000
  %375 = fmul fast float %372, 0x3FF0E147A0000000
  %376 = fadd fast float %373, 0xBFAC28F5C0000000
  %377 = fadd fast float %374, 0xBFAC28F5C0000000
  %378 = fadd fast float %375, 0xBFAC28F5C0000000
  %379 = fsub fast float %358, %376
  %380 = fsub fast float %359, %377
  %381 = fsub fast float %360, %378
  %382 = fmul fast float %379, %355
  %383 = fmul fast float %380, %356
  %384 = fmul fast float %381, %357
  %385 = fadd fast float %382, %376
  %386 = fadd fast float %383, %377
  %387 = fadd fast float %384, %378
  br label %388

; <label>:388                                     ; preds = %320, %282
  %389 = phi float [ %277, %282 ], [ %385, %320 ]
  %390 = phi float [ %278, %282 ], [ %386, %320 ]
  %391 = phi float [ %279, %282 ], [ %387, %320 ]
  %392 = phi float [ %283, %282 ], [ %280, %320 ]
  %393 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %155, i32 %275, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %394 = extractvalue %dx.types.ResRet.f32 %393, 0
  %395 = extractvalue %dx.types.ResRet.f32 %393, 1
  %396 = extractvalue %dx.types.ResRet.f32 %393, 2
  %397 = extractvalue %dx.types.ResRet.f32 %393, 3
  %398 = fcmp fast olt float %397, 0.000000e+00
  br i1 %398, label %399, label %401

; <label>:399                                     ; preds = %388
  %400 = fsub fast float -1.000000e+00, %397
  br label %505

; <label>:401                                     ; preds = %388
  %402 = fadd fast float %5, 1.000000e+00
  %403 = fadd fast float %6, 1.000000e+00
  %404 = fsub fast float 1.000000e+00, %5
  %405 = fmul fast float %9, %402
  %406 = fmul fast float %9, %403
  %407 = fmul fast float %9, %404
  %408 = fmul fast float %405, %394
  %409 = fmul fast float %406, %395
  %410 = fmul fast float %407, %396
  %411 = fcmp fast ult float %10, 5.000000e-01
  br i1 %411, label %437, label %412

; <label>:412                                     ; preds = %401
  %413 = fmul fast float %408, 0x4004147AE0000000
  %414 = fmul fast float %409, 0x4004147AE0000000
  %415 = fmul fast float %410, 0x4004147AE0000000
  %416 = fadd fast float %413, 0x3F9EB851E0000000
  %417 = fadd fast float %414, 0x3F9EB851E0000000
  %418 = fadd fast float %415, 0x3F9EB851E0000000
  %419 = fmul fast float %416, %408
  %420 = fmul fast float %417, %409
  %421 = fmul fast float %418, %410
  %422 = fmul fast float %408, 0x400370A3E0000000
  %423 = fmul fast float %409, 0x400370A3E0000000
  %424 = fmul fast float %410, 0x400370A3E0000000
  %425 = fadd fast float %422, 0x3FE2E147A0000000
  %426 = fadd fast float %423, 0x3FE2E147A0000000
  %427 = fadd fast float %424, 0x3FE2E147A0000000
  %428 = fmul fast float %425, %408
  %429 = fmul fast float %426, %409
  %430 = fmul fast float %427, %410
  %431 = fadd fast float %428, 0x3FC1EB8520000000
  %432 = fadd fast float %429, 0x3FC1EB8520000000
  %433 = fadd fast float %430, 0x3FC1EB8520000000
  %434 = fdiv fast float %419, %431
  %435 = fdiv fast float %420, %432
  %436 = fdiv fast float %421, %433
  br label %437

; <label>:437                                     ; preds = %412, %401
  %438 = phi float [ %434, %412 ], [ %408, %401 ]
  %439 = phi float [ %435, %412 ], [ %409, %401 ]
  %440 = phi float [ %436, %412 ], [ %410, %401 ]
  %441 = call float @dx.op.unary.f32(i32 7, float %438)  ; Saturate(value)
  %442 = call float @dx.op.unary.f32(i32 7, float %439)  ; Saturate(value)
  %443 = call float @dx.op.unary.f32(i32 7, float %440)  ; Saturate(value)
  %444 = call float @dx.op.dot3.f32(i32 55, float %441, float %442, float %443, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %445 = fsub fast float %441, %444
  %446 = fsub fast float %442, %444
  %447 = fsub fast float %443, %444
  %448 = fmul fast float %445, %8
  %449 = fmul fast float %446, %8
  %450 = fmul fast float %447, %8
  %451 = fadd fast float %448, %444
  %452 = fadd fast float %449, %444
  %453 = fadd fast float %450, %444
  %454 = call float @dx.op.unary.f32(i32 7, float %451)  ; Saturate(value)
  %455 = call float @dx.op.unary.f32(i32 7, float %452)  ; Saturate(value)
  %456 = call float @dx.op.unary.f32(i32 7, float %453)  ; Saturate(value)
  %457 = fadd fast float %454, 0xBFC70A3D80000000
  %458 = fadd fast float %455, 0xBFC70A3D80000000
  %459 = fadd fast float %456, 0xBFC70A3D80000000
  %460 = fmul fast float %457, %7
  %461 = fmul fast float %458, %7
  %462 = fmul fast float %459, %7
  %463 = fadd fast float %460, 0x3FC70A3D80000000
  %464 = fadd fast float %461, 0x3FC70A3D80000000
  %465 = fadd fast float %462, 0x3FC70A3D80000000
  %466 = call float @dx.op.unary.f32(i32 7, float %463)  ; Saturate(value)
  %467 = call float @dx.op.unary.f32(i32 7, float %464)  ; Saturate(value)
  %468 = call float @dx.op.unary.f32(i32 7, float %465)  ; Saturate(value)
  %469 = fcmp fast ogt float %466, 0x3F69A5C380000000
  %470 = fcmp fast ogt float %467, 0x3F69A5C380000000
  %471 = fcmp fast ogt float %468, 0x3F69A5C380000000
  %472 = select i1 %469, float 0.000000e+00, float 1.000000e+00
  %473 = select i1 %470, float 0.000000e+00, float 1.000000e+00
  %474 = select i1 %471, float 0.000000e+00, float 1.000000e+00
  %475 = fmul fast float %466, 0x4029D70A40000000
  %476 = fmul fast float %467, 0x4029D70A40000000
  %477 = fmul fast float %468, 0x4029D70A40000000
  %478 = call float @dx.op.binary.f32(i32 35, float %466, float 0.000000e+00)  ; FMax(a,b)
  %479 = call float @dx.op.binary.f32(i32 35, float %467, float 0.000000e+00)  ; FMax(a,b)
  %480 = call float @dx.op.binary.f32(i32 35, float %468, float 0.000000e+00)  ; FMax(a,b)
  %481 = call float @dx.op.unary.f32(i32 23, float %478)  ; Log(value)
  %482 = call float @dx.op.unary.f32(i32 23, float %479)  ; Log(value)
  %483 = call float @dx.op.unary.f32(i32 23, float %480)  ; Log(value)
  %484 = fmul fast float %481, 0x3FDAAAAAA0000000
  %485 = fmul fast float %482, 0x3FDAAAAAA0000000
  %486 = fmul fast float %483, 0x3FDAAAAAA0000000
  %487 = call float @dx.op.unary.f32(i32 21, float %484)  ; Exp(value)
  %488 = call float @dx.op.unary.f32(i32 21, float %485)  ; Exp(value)
  %489 = call float @dx.op.unary.f32(i32 21, float %486)  ; Exp(value)
  %490 = fmul fast float %487, 0x3FF0E147A0000000
  %491 = fmul fast float %488, 0x3FF0E147A0000000
  %492 = fmul fast float %489, 0x3FF0E147A0000000
  %493 = fadd fast float %490, 0xBFAC28F5C0000000
  %494 = fadd fast float %491, 0xBFAC28F5C0000000
  %495 = fadd fast float %492, 0xBFAC28F5C0000000
  %496 = fsub fast float %475, %493
  %497 = fsub fast float %476, %494
  %498 = fsub fast float %477, %495
  %499 = fmul fast float %496, %472
  %500 = fmul fast float %497, %473
  %501 = fmul fast float %498, %474
  %502 = fadd fast float %499, %493
  %503 = fadd fast float %500, %494
  %504 = fadd fast float %501, %495
  br label %505

; <label>:505                                     ; preds = %437, %399
  %506 = phi float [ %394, %399 ], [ %502, %437 ]
  %507 = phi float [ %395, %399 ], [ %503, %437 ]
  %508 = phi float [ %396, %399 ], [ %504, %437 ]
  %509 = phi float [ %400, %399 ], [ %397, %437 ]
  %510 = call float @dx.op.unary.f32(i32 27, float %20)  ; Round_ni(value)
  %511 = call float @dx.op.unary.f32(i32 27, float %21)  ; Round_ni(value)
  %512 = fptosi float %510 to i32
  %513 = fptosi float %511 to i32
  %514 = call i32 @dx.op.binary.i32(i32 37, i32 %512, i32 0)  ; IMax(a,b)
  %515 = call i32 @dx.op.binary.i32(i32 37, i32 %513, i32 0)  ; IMax(a,b)
  %516 = call i32 @dx.op.binary.i32(i32 38, i32 %514, i32 %30)  ; IMin(a,b)
  %517 = call i32 @dx.op.binary.i32(i32 38, i32 %515, i32 %31)  ; IMin(a,b)
  %518 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %516, i32 %517, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %519 = extractvalue %dx.types.ResRet.f32 %518, 0
  %520 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %34, i32 %35, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %521 = extractvalue %dx.types.ResRet.f32 %520, 0
  %522 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %155, i32 %35, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %523 = extractvalue %dx.types.ResRet.f32 %522, 0
  %524 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %34, i32 %275, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %525 = extractvalue %dx.types.ResRet.f32 %524, 0
  %526 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %155, i32 %275, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %527 = extractvalue %dx.types.ResRet.f32 %526, 0
  %528 = fsub fast float 1.000000e+00, %28
  %529 = fsub fast float 1.000000e+00, %29
  %530 = fmul fast float %529, %528
  %531 = fmul fast float %529, %28
  %532 = fmul fast float %528, %29
  %533 = fmul fast float %29, %28
  %534 = fsub fast float 1.000000e+00, %519
  %535 = fmul fast float %534, 0x3FA99999A0000000
  %536 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %535)  ; FMax(a,b)
  %537 = fsub fast float %521, %519
  %538 = fsub fast float %523, %519
  %539 = fsub fast float %525, %519
  %540 = fsub fast float %527, %519
  %541 = call float @dx.op.unary.f32(i32 6, float %537)  ; FAbs(value)
  %542 = call float @dx.op.unary.f32(i32 6, float %538)  ; FAbs(value)
  %543 = call float @dx.op.unary.f32(i32 6, float %539)  ; FAbs(value)
  %544 = call float @dx.op.unary.f32(i32 6, float %540)  ; FAbs(value)
  %545 = fdiv fast float %541, %536
  %546 = fdiv fast float %542, %536
  %547 = fdiv fast float %543, %536
  %548 = fdiv fast float %544, %536
  %549 = fsub fast float 1.000000e+00, %545
  %550 = fsub fast float 1.000000e+00, %546
  %551 = fsub fast float 1.000000e+00, %547
  %552 = fsub fast float 1.000000e+00, %548
  %553 = call float @dx.op.unary.f32(i32 7, float %549)  ; Saturate(value)
  %554 = call float @dx.op.unary.f32(i32 7, float %550)  ; Saturate(value)
  %555 = call float @dx.op.unary.f32(i32 7, float %551)  ; Saturate(value)
  %556 = call float @dx.op.unary.f32(i32 7, float %552)  ; Saturate(value)
  %557 = fmul fast float %530, %553
  %558 = fmul fast float %531, %554
  %559 = fmul fast float %532, %555
  %560 = fmul fast float %533, %556
  %561 = call float @dx.op.dot4.f32(i32 56, float %557, float %558, float %559, float %560, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %562 = call float @dx.op.binary.f32(i32 35, float %561, float 0x3EE4F8B580000000)  ; FMax(a,b)
  %563 = fdiv fast float %557, %562
  %564 = fdiv fast float %558, %562
  %565 = fdiv fast float %559, %562
  %566 = fdiv fast float %560, %562
  %567 = fcmp fast ogt float %149, 0x3FA4B5DCC0000000
  %568 = fcmp fast ogt float %150, 0x3FA4B5DCC0000000
  %569 = fcmp fast ogt float %151, 0x3FA4B5DCC0000000
  %570 = select i1 %567, float 0.000000e+00, float 1.000000e+00
  %571 = select i1 %568, float 0.000000e+00, float 1.000000e+00
  %572 = select i1 %569, float 0.000000e+00, float 1.000000e+00
  %573 = fmul fast float %149, 0x3FB3D07220000000
  %574 = fmul fast float %150, 0x3FB3D07220000000
  %575 = fmul fast float %151, 0x3FB3D07220000000
  %576 = fadd fast float %149, 0x3FAC28F5C0000000
  %577 = fadd fast float %150, 0x3FAC28F5C0000000
  %578 = fadd fast float %151, 0x3FAC28F5C0000000
  %579 = fmul fast float %576, 0x3FEE54EDE0000000
  %580 = fmul fast float %577, 0x3FEE54EDE0000000
  %581 = fmul fast float %578, 0x3FEE54EDE0000000
  %582 = call float @dx.op.unary.f32(i32 23, float %579)  ; Log(value)
  %583 = call float @dx.op.unary.f32(i32 23, float %580)  ; Log(value)
  %584 = call float @dx.op.unary.f32(i32 23, float %581)  ; Log(value)
  %585 = fmul fast float %582, 0x4003333340000000
  %586 = fmul fast float %583, 0x4003333340000000
  %587 = fmul fast float %584, 0x4003333340000000
  %588 = call float @dx.op.unary.f32(i32 21, float %585)  ; Exp(value)
  %589 = call float @dx.op.unary.f32(i32 21, float %586)  ; Exp(value)
  %590 = call float @dx.op.unary.f32(i32 21, float %587)  ; Exp(value)
  %591 = fsub fast float %573, %588
  %592 = fsub fast float %574, %589
  %593 = fsub fast float %575, %590
  %594 = fmul fast float %591, %570
  %595 = fmul fast float %592, %571
  %596 = fmul fast float %593, %572
  %597 = fadd fast float %594, %588
  %598 = fadd fast float %595, %589
  %599 = fadd fast float %596, %590
  %600 = fmul fast float %597, %563
  %601 = fmul fast float %598, %563
  %602 = fmul fast float %599, %563
  %603 = fcmp fast ogt float %269, 0x3FA4B5DCC0000000
  %604 = fcmp fast ogt float %270, 0x3FA4B5DCC0000000
  %605 = fcmp fast ogt float %271, 0x3FA4B5DCC0000000
  %606 = select i1 %603, float 0.000000e+00, float 1.000000e+00
  %607 = select i1 %604, float 0.000000e+00, float 1.000000e+00
  %608 = select i1 %605, float 0.000000e+00, float 1.000000e+00
  %609 = fmul fast float %269, 0x3FB3D07220000000
  %610 = fmul fast float %270, 0x3FB3D07220000000
  %611 = fmul fast float %271, 0x3FB3D07220000000
  %612 = fadd fast float %269, 0x3FAC28F5C0000000
  %613 = fadd fast float %270, 0x3FAC28F5C0000000
  %614 = fadd fast float %271, 0x3FAC28F5C0000000
  %615 = fmul fast float %612, 0x3FEE54EDE0000000
  %616 = fmul fast float %613, 0x3FEE54EDE0000000
  %617 = fmul fast float %614, 0x3FEE54EDE0000000
  %618 = call float @dx.op.unary.f32(i32 23, float %615)  ; Log(value)
  %619 = call float @dx.op.unary.f32(i32 23, float %616)  ; Log(value)
  %620 = call float @dx.op.unary.f32(i32 23, float %617)  ; Log(value)
  %621 = fmul fast float %618, 0x4003333340000000
  %622 = fmul fast float %619, 0x4003333340000000
  %623 = fmul fast float %620, 0x4003333340000000
  %624 = call float @dx.op.unary.f32(i32 21, float %621)  ; Exp(value)
  %625 = call float @dx.op.unary.f32(i32 21, float %622)  ; Exp(value)
  %626 = call float @dx.op.unary.f32(i32 21, float %623)  ; Exp(value)
  %627 = fsub fast float %609, %624
  %628 = fsub fast float %610, %625
  %629 = fsub fast float %611, %626
  %630 = fmul fast float %627, %606
  %631 = fmul fast float %628, %607
  %632 = fmul fast float %629, %608
  %633 = fadd fast float %630, %624
  %634 = fadd fast float %631, %625
  %635 = fadd fast float %632, %626
  %636 = fmul fast float %633, %564
  %637 = fmul fast float %634, %564
  %638 = fmul fast float %635, %564
  %639 = fadd fast float %636, %600
  %640 = fadd fast float %637, %601
  %641 = fadd fast float %638, %602
  %642 = fcmp fast ogt float %389, 0x3FA4B5DCC0000000
  %643 = fcmp fast ogt float %390, 0x3FA4B5DCC0000000
  %644 = fcmp fast ogt float %391, 0x3FA4B5DCC0000000
  %645 = select i1 %642, float 0.000000e+00, float 1.000000e+00
  %646 = select i1 %643, float 0.000000e+00, float 1.000000e+00
  %647 = select i1 %644, float 0.000000e+00, float 1.000000e+00
  %648 = fmul fast float %389, 0x3FB3D07220000000
  %649 = fmul fast float %390, 0x3FB3D07220000000
  %650 = fmul fast float %391, 0x3FB3D07220000000
  %651 = fadd fast float %389, 0x3FAC28F5C0000000
  %652 = fadd fast float %390, 0x3FAC28F5C0000000
  %653 = fadd fast float %391, 0x3FAC28F5C0000000
  %654 = fmul fast float %651, 0x3FEE54EDE0000000
  %655 = fmul fast float %652, 0x3FEE54EDE0000000
  %656 = fmul fast float %653, 0x3FEE54EDE0000000
  %657 = call float @dx.op.unary.f32(i32 23, float %654)  ; Log(value)
  %658 = call float @dx.op.unary.f32(i32 23, float %655)  ; Log(value)
  %659 = call float @dx.op.unary.f32(i32 23, float %656)  ; Log(value)
  %660 = fmul fast float %657, 0x4003333340000000
  %661 = fmul fast float %658, 0x4003333340000000
  %662 = fmul fast float %659, 0x4003333340000000
  %663 = call float @dx.op.unary.f32(i32 21, float %660)  ; Exp(value)
  %664 = call float @dx.op.unary.f32(i32 21, float %661)  ; Exp(value)
  %665 = call float @dx.op.unary.f32(i32 21, float %662)  ; Exp(value)
  %666 = fsub fast float %648, %663
  %667 = fsub fast float %649, %664
  %668 = fsub fast float %650, %665
  %669 = fmul fast float %666, %645
  %670 = fmul fast float %667, %646
  %671 = fmul fast float %668, %647
  %672 = fadd fast float %669, %663
  %673 = fadd fast float %670, %664
  %674 = fadd fast float %671, %665
  %675 = fmul fast float %672, %565
  %676 = fmul fast float %673, %565
  %677 = fmul fast float %674, %565
  %678 = fadd fast float %639, %675
  %679 = fadd fast float %640, %676
  %680 = fadd fast float %641, %677
  %681 = fcmp fast ogt float %506, 0x3FA4B5DCC0000000
  %682 = fcmp fast ogt float %507, 0x3FA4B5DCC0000000
  %683 = fcmp fast ogt float %508, 0x3FA4B5DCC0000000
  %684 = select i1 %681, float 0.000000e+00, float 1.000000e+00
  %685 = select i1 %682, float 0.000000e+00, float 1.000000e+00
  %686 = select i1 %683, float 0.000000e+00, float 1.000000e+00
  %687 = fmul fast float %506, 0x3FB3D07220000000
  %688 = fmul fast float %507, 0x3FB3D07220000000
  %689 = fmul fast float %508, 0x3FB3D07220000000
  %690 = fadd fast float %506, 0x3FAC28F5C0000000
  %691 = fadd fast float %507, 0x3FAC28F5C0000000
  %692 = fadd fast float %508, 0x3FAC28F5C0000000
  %693 = fmul fast float %690, 0x3FEE54EDE0000000
  %694 = fmul fast float %691, 0x3FEE54EDE0000000
  %695 = fmul fast float %692, 0x3FEE54EDE0000000
  %696 = call float @dx.op.unary.f32(i32 23, float %693)  ; Log(value)
  %697 = call float @dx.op.unary.f32(i32 23, float %694)  ; Log(value)
  %698 = call float @dx.op.unary.f32(i32 23, float %695)  ; Log(value)
  %699 = fmul fast float %696, 0x4003333340000000
  %700 = fmul fast float %697, 0x4003333340000000
  %701 = fmul fast float %698, 0x4003333340000000
  %702 = call float @dx.op.unary.f32(i32 21, float %699)  ; Exp(value)
  %703 = call float @dx.op.unary.f32(i32 21, float %700)  ; Exp(value)
  %704 = call float @dx.op.unary.f32(i32 21, float %701)  ; Exp(value)
  %705 = fsub fast float %687, %702
  %706 = fsub fast float %688, %703
  %707 = fsub fast float %689, %704
  %708 = fmul fast float %705, %684
  %709 = fmul fast float %706, %685
  %710 = fmul fast float %707, %686
  %711 = fadd fast float %708, %702
  %712 = fadd fast float %709, %703
  %713 = fadd fast float %710, %704
  %714 = fmul fast float %711, %566
  %715 = fmul fast float %712, %566
  %716 = fmul fast float %713, %566
  %717 = fadd fast float %678, %714
  %718 = fadd fast float %679, %715
  %719 = fadd fast float %680, %716
  %720 = fcmp fast ogt float %717, 0x3F69A5C380000000
  %721 = fcmp fast ogt float %718, 0x3F69A5C380000000
  %722 = fcmp fast ogt float %719, 0x3F69A5C380000000
  %723 = select i1 %720, float 0.000000e+00, float 1.000000e+00
  %724 = select i1 %721, float 0.000000e+00, float 1.000000e+00
  %725 = select i1 %722, float 0.000000e+00, float 1.000000e+00
  %726 = fmul fast float %717, 0x4029D70A40000000
  %727 = fmul fast float %718, 0x4029D70A40000000
  %728 = fmul fast float %719, 0x4029D70A40000000
  %729 = call float @dx.op.binary.f32(i32 35, float %717, float 0.000000e+00)  ; FMax(a,b)
  %730 = call float @dx.op.binary.f32(i32 35, float %718, float 0.000000e+00)  ; FMax(a,b)
  %731 = call float @dx.op.binary.f32(i32 35, float %719, float 0.000000e+00)  ; FMax(a,b)
  %732 = call float @dx.op.unary.f32(i32 23, float %729)  ; Log(value)
  %733 = call float @dx.op.unary.f32(i32 23, float %730)  ; Log(value)
  %734 = call float @dx.op.unary.f32(i32 23, float %731)  ; Log(value)
  %735 = fmul fast float %732, 0x3FDAAAAAA0000000
  %736 = fmul fast float %733, 0x3FDAAAAAA0000000
  %737 = fmul fast float %734, 0x3FDAAAAAA0000000
  %738 = call float @dx.op.unary.f32(i32 21, float %735)  ; Exp(value)
  %739 = call float @dx.op.unary.f32(i32 21, float %736)  ; Exp(value)
  %740 = call float @dx.op.unary.f32(i32 21, float %737)  ; Exp(value)
  %741 = fmul fast float %738, 0x3FF0E147A0000000
  %742 = fmul fast float %739, 0x3FF0E147A0000000
  %743 = fmul fast float %740, 0x3FF0E147A0000000
  %744 = fadd fast float %741, 0xBFAC28F5C0000000
  %745 = fadd fast float %742, 0xBFAC28F5C0000000
  %746 = fadd fast float %743, 0xBFAC28F5C0000000
  %747 = fsub fast float %726, %744
  %748 = fsub fast float %727, %745
  %749 = fsub fast float %728, %746
  %750 = fmul fast float %747, %723
  %751 = fmul fast float %748, %724
  %752 = fmul fast float %749, %725
  %753 = fadd fast float %750, %744
  %754 = fadd fast float %751, %745
  %755 = fadd fast float %752, %746
  %756 = call float @dx.op.dot4.f32(i32 56, float %152, float %272, float %392, float %509, float %563, float %564, float %565, float %566)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %753)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %754)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %755)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %756)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %519)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 0, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !37, null}
!12 = !{!13, !16, !17, !19, !21, !23, !25, !27, !29, !31, !34}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !15}
!17 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !18, i8 1, i32 1, i8 4, i32 2, i8 0, null}
!18 = !{i32 1}
!19 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !20, i8 1, i32 1, i8 4, i32 3, i8 0, null}
!20 = !{i32 2}
!21 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !22, i8 1, i32 1, i8 4, i32 4, i8 0, null}
!22 = !{i32 3}
!23 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !24, i8 1, i32 1, i8 4, i32 5, i8 0, null}
!24 = !{i32 4}
!25 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !26, i8 1, i32 1, i8 4, i32 6, i8 0, null}
!26 = !{i32 5}
!27 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !28, i8 1, i32 1, i8 4, i32 7, i8 0, null}
!28 = !{i32 6}
!29 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 8, i8 0, null}
!30 = !{i32 7}
!31 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 9, i8 0, !33}
!32 = !{i32 8}
!33 = !{i32 3, i32 15}
!34 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !35, i8 1, i32 1, i8 4, i32 10, i8 0, !36}
!35 = !{i32 9}
!36 = !{i32 3, i32 6}
!37 = !{!38, !39}
!38 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !33}
!39 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !40}
!40 = !{i32 3, i32 1}
