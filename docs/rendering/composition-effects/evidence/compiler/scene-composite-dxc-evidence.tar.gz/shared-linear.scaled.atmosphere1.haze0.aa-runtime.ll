;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float   xyz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: 3a00658c1a863d2155ba79ce3eda3365
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %40 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %41 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %42 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %43 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %44 = extractvalue %dx.types.Dimensions %43, 0
  %45 = extractvalue %dx.types.Dimensions %43, 1
  %46 = uitofp i32 %44 to float
  %47 = uitofp i32 %45 to float
  %48 = fmul fast float %46, %41
  %49 = fmul fast float %47, %42
  %50 = fdiv fast float %48, %4
  %51 = fdiv fast float %49, %5
  %52 = fadd fast float %50, -5.000000e-01
  %53 = fadd fast float %51, -5.000000e-01
  %54 = call float @dx.op.unary.f32(i32 27, float %52)  ; Round_ni(value)
  %55 = call float @dx.op.unary.f32(i32 27, float %53)  ; Round_ni(value)
  %56 = fptosi float %54 to i32
  %57 = fptosi float %55 to i32
  %58 = call float @dx.op.unary.f32(i32 22, float %52)  ; Frc(value)
  %59 = call float @dx.op.unary.f32(i32 22, float %53)  ; Frc(value)
  %60 = add i32 %44, -1
  %61 = add i32 %45, -1
  %62 = call i32 @dx.op.binary.i32(i32 37, i32 %56, i32 0)  ; IMax(a,b)
  %63 = call i32 @dx.op.binary.i32(i32 37, i32 %57, i32 0)  ; IMax(a,b)
  %64 = call i32 @dx.op.binary.i32(i32 38, i32 %62, i32 %60)  ; IMin(a,b)
  %65 = call i32 @dx.op.binary.i32(i32 38, i32 %63, i32 %61)  ; IMin(a,b)
  %66 = add i32 %56, 1
  %67 = call i32 @dx.op.binary.i32(i32 37, i32 %66, i32 0)  ; IMax(a,b)
  %68 = call i32 @dx.op.binary.i32(i32 38, i32 %67, i32 %60)  ; IMin(a,b)
  %69 = add i32 %57, 1
  %70 = call i32 @dx.op.binary.i32(i32 37, i32 %69, i32 0)  ; IMax(a,b)
  %71 = call i32 @dx.op.binary.i32(i32 38, i32 %70, i32 %61)  ; IMin(a,b)
  %72 = call float @dx.op.unary.f32(i32 27, float %50)  ; Round_ni(value)
  %73 = call float @dx.op.unary.f32(i32 27, float %51)  ; Round_ni(value)
  %74 = fptosi float %72 to i32
  %75 = fptosi float %73 to i32
  %76 = call i32 @dx.op.binary.i32(i32 37, i32 %74, i32 0)  ; IMax(a,b)
  %77 = call i32 @dx.op.binary.i32(i32 37, i32 %75, i32 0)  ; IMax(a,b)
  %78 = call i32 @dx.op.binary.i32(i32 38, i32 %76, i32 %60)  ; IMin(a,b)
  %79 = call i32 @dx.op.binary.i32(i32 38, i32 %77, i32 %61)  ; IMin(a,b)
  %80 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %78, i32 %79, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %81 = extractvalue %dx.types.ResRet.f32 %80, 0
  %82 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %64, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %83 = extractvalue %dx.types.ResRet.f32 %82, 0
  %84 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %68, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %85 = extractvalue %dx.types.ResRet.f32 %84, 0
  %86 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %64, i32 %71, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %87 = extractvalue %dx.types.ResRet.f32 %86, 0
  %88 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %68, i32 %71, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %89 = extractvalue %dx.types.ResRet.f32 %88, 0
  %90 = fsub fast float 1.000000e+00, %58
  %91 = fsub fast float 1.000000e+00, %59
  %92 = fmul fast float %91, %90
  %93 = fmul fast float %91, %58
  %94 = fmul fast float %90, %59
  %95 = fmul fast float %59, %58
  %96 = fsub fast float 1.000000e+00, %81
  %97 = fmul fast float %96, 0x3FA99999A0000000
  %98 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %97)  ; FMax(a,b)
  %99 = fsub fast float %83, %81
  %100 = call float @dx.op.unary.f32(i32 6, float %99)  ; FAbs(value)
  %101 = fdiv fast float %100, %98
  %102 = fsub fast float 1.000000e+00, %101
  %103 = call float @dx.op.unary.f32(i32 7, float %102)  ; Saturate(value)
  %104 = fsub fast float %85, %81
  %105 = call float @dx.op.unary.f32(i32 6, float %104)  ; FAbs(value)
  %106 = fdiv fast float %105, %98
  %107 = fsub fast float 1.000000e+00, %106
  %108 = call float @dx.op.unary.f32(i32 7, float %107)  ; Saturate(value)
  %109 = fsub fast float %87, %81
  %110 = call float @dx.op.unary.f32(i32 6, float %109)  ; FAbs(value)
  %111 = fdiv fast float %110, %98
  %112 = fsub fast float 1.000000e+00, %111
  %113 = call float @dx.op.unary.f32(i32 7, float %112)  ; Saturate(value)
  %114 = fsub fast float %89, %81
  %115 = call float @dx.op.unary.f32(i32 6, float %114)  ; FAbs(value)
  %116 = fdiv fast float %115, %98
  %117 = fsub fast float 1.000000e+00, %116
  %118 = call float @dx.op.unary.f32(i32 7, float %117)  ; Saturate(value)
  %119 = fmul fast float %92, %103
  %120 = fmul fast float %93, %108
  %121 = fmul fast float %94, %113
  %122 = fmul fast float %95, %118
  %123 = fcmp fast oge float %58, 5.000000e-01
  %124 = zext i1 %123 to i32
  %125 = fcmp fast oge float %59, 5.000000e-01
  %126 = select i1 %125, i32 2, i32 0
  %127 = or i32 %126, %124
  %128 = call float @dx.op.dot4.f32(i32 56, float %119, float %120, float %121, float %122, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %129 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %119)  ; IsFinite(value)
  %130 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %120)  ; IsFinite(value)
  %131 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %121)  ; IsFinite(value)
  %132 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %122)  ; IsFinite(value)
  %133 = and i1 %129, %130
  %134 = and i1 %133, %131
  %135 = and i1 %134, %132
  br i1 %135, label %136, label %153

; <label>:136                                     ; preds = %0
  %137 = fcmp fast oge float %119, 0.000000e+00
  %138 = fcmp fast oge float %120, 0.000000e+00
  %139 = fcmp fast oge float %121, 0.000000e+00
  %140 = fcmp fast oge float %122, 0.000000e+00
  %141 = and i1 %137, %138
  %142 = and i1 %141, %139
  %143 = and i1 %142, %140
  br i1 %143, label %144, label %153

; <label>:144                                     ; preds = %136
  %145 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %128)  ; IsFinite(value)
  %146 = fcmp fast oge float %128, 0x3810000000000000
  %147 = and i1 %146, %145
  br i1 %147, label %148, label %153

; <label>:148                                     ; preds = %144
  %149 = fdiv fast float %119, %128
  %150 = fdiv fast float %120, %128
  %151 = fdiv fast float %121, %128
  %152 = fdiv fast float %122, %128
  br label %162

; <label>:153                                     ; preds = %144, %136, %0
  %154 = icmp eq i32 %127, 0
  %155 = uitofp i1 %154 to float
  %156 = icmp eq i32 %127, 1
  %157 = uitofp i1 %156 to float
  %158 = icmp eq i32 %127, 2
  %159 = uitofp i1 %158 to float
  %160 = icmp eq i32 %127, 3
  %161 = uitofp i1 %160 to float
  br label %162

; <label>:162                                     ; preds = %153, %148
  %163 = phi float [ %149, %148 ], [ %155, %153 ]
  %164 = phi float [ %150, %148 ], [ %157, %153 ]
  %165 = phi float [ %151, %148 ], [ %159, %153 ]
  %166 = phi float [ %152, %148 ], [ %161, %153 ]
  %167 = or i32 %57, %56
  %168 = icmp sgt i32 %167, -1
  br i1 %168, label %169, label %173

; <label>:169                                     ; preds = %162
  %170 = icmp slt i32 %66, %44
  %171 = icmp slt i32 %69, %45
  %172 = and i1 %170, %171
  br label %173

; <label>:173                                     ; preds = %169, %162
  %174 = phi i1 [ false, %162 ], [ %172, %169 ]
  br i1 %174, label %175, label %3490

; <label>:175                                     ; preds = %173
  %176 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %56, i32 %57, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %177 = extractvalue %dx.types.ResRet.f32 %176, 0
  %178 = extractvalue %dx.types.ResRet.f32 %176, 1
  %179 = extractvalue %dx.types.ResRet.f32 %176, 2
  %180 = extractvalue %dx.types.ResRet.f32 %176, 3
  %181 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %66, i32 %57, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %182 = extractvalue %dx.types.ResRet.f32 %181, 0
  %183 = extractvalue %dx.types.ResRet.f32 %181, 1
  %184 = extractvalue %dx.types.ResRet.f32 %181, 2
  %185 = extractvalue %dx.types.ResRet.f32 %181, 3
  %186 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %56, i32 %69, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %187 = extractvalue %dx.types.ResRet.f32 %186, 0
  %188 = extractvalue %dx.types.ResRet.f32 %186, 1
  %189 = extractvalue %dx.types.ResRet.f32 %186, 2
  %190 = extractvalue %dx.types.ResRet.f32 %186, 3
  %191 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %66, i32 %69, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %192 = extractvalue %dx.types.ResRet.f32 %191, 0
  %193 = extractvalue %dx.types.ResRet.f32 %191, 1
  %194 = extractvalue %dx.types.ResRet.f32 %191, 2
  %195 = extractvalue %dx.types.ResRet.f32 %191, 3
  %196 = fcmp fast olt float %180, 0.000000e+00
  br i1 %196, label %197, label %231

; <label>:197                                     ; preds = %175
  %198 = fcmp fast ogt float %177, 0x3FA4B5DCC0000000
  %199 = fcmp fast ogt float %178, 0x3FA4B5DCC0000000
  %200 = fcmp fast ogt float %179, 0x3FA4B5DCC0000000
  %201 = select i1 %198, float 0.000000e+00, float 1.000000e+00
  %202 = select i1 %199, float 0.000000e+00, float 1.000000e+00
  %203 = select i1 %200, float 0.000000e+00, float 1.000000e+00
  %204 = fmul fast float %177, 0x3FB3D07220000000
  %205 = fmul fast float %178, 0x3FB3D07220000000
  %206 = fmul fast float %179, 0x3FB3D07220000000
  %207 = fadd fast float %177, 0x3FAC28F5C0000000
  %208 = fadd fast float %178, 0x3FAC28F5C0000000
  %209 = fadd fast float %179, 0x3FAC28F5C0000000
  %210 = fmul fast float %207, 0x3FEE54EDE0000000
  %211 = fmul fast float %208, 0x3FEE54EDE0000000
  %212 = fmul fast float %209, 0x3FEE54EDE0000000
  %213 = call float @dx.op.unary.f32(i32 23, float %210)  ; Log(value)
  %214 = call float @dx.op.unary.f32(i32 23, float %211)  ; Log(value)
  %215 = call float @dx.op.unary.f32(i32 23, float %212)  ; Log(value)
  %216 = fmul fast float %213, 0x4003333340000000
  %217 = fmul fast float %214, 0x4003333340000000
  %218 = fmul fast float %215, 0x4003333340000000
  %219 = call float @dx.op.unary.f32(i32 21, float %216)  ; Exp(value)
  %220 = call float @dx.op.unary.f32(i32 21, float %217)  ; Exp(value)
  %221 = call float @dx.op.unary.f32(i32 21, float %218)  ; Exp(value)
  %222 = fsub fast float %204, %219
  %223 = fsub fast float %205, %220
  %224 = fsub fast float %206, %221
  %225 = fmul fast float %222, %201
  %226 = fmul fast float %223, %202
  %227 = fmul fast float %224, %203
  %228 = fadd fast float %225, %219
  %229 = fadd fast float %226, %220
  %230 = fadd fast float %227, %221
  br label %394

; <label>:231                                     ; preds = %175
  %232 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %56, i32 %57, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %233 = extractvalue %dx.types.ResRet.f32 %232, 0
  %234 = fcmp fast ogt float %39, 5.000000e-01
  %235 = fcmp fast olt float %233, 1.000000e+00
  %236 = and i1 %234, %235
  br i1 %236, label %237, label %323

; <label>:237                                     ; preds = %231
  %238 = sitofp i32 %56 to float
  %239 = sitofp i32 %57 to float
  %240 = fadd fast float %238, 5.000000e-01
  %241 = fadd fast float %239, 5.000000e-01
  %242 = fdiv fast float %240, %46
  %243 = fdiv fast float %241, %47
  %244 = fmul fast float %242, 2.000000e+00
  %245 = fmul fast float %243, 2.000000e+00
  %246 = fadd fast float %244, -1.000000e+00
  %247 = fsub fast float 1.000000e+00, %245
  %248 = fmul fast float %246, %36
  %249 = call float @dx.op.tertiary.f32(i32 46, float %247, float %32, float %248)  ; FMad(a,b,c)
  %250 = call float @dx.op.tertiary.f32(i32 46, float %233, float %28, float %249)  ; FMad(a,b,c)
  %251 = fadd fast float %250, %24
  %252 = call float @dx.op.unary.f32(i32 6, float %251)  ; FAbs(value)
  %253 = fcmp fast ogt float %252, 0x3EB0C6F7A0000000
  br i1 %253, label %254, label %323

; <label>:254                                     ; preds = %237
  %255 = fmul fast float %246, %35
  %256 = call float @dx.op.tertiary.f32(i32 46, float %247, float %31, float %255)  ; FMad(a,b,c)
  %257 = call float @dx.op.tertiary.f32(i32 46, float %233, float %27, float %256)  ; FMad(a,b,c)
  %258 = fadd fast float %257, %23
  %259 = fmul fast float %246, %34
  %260 = call float @dx.op.tertiary.f32(i32 46, float %247, float %30, float %259)  ; FMad(a,b,c)
  %261 = call float @dx.op.tertiary.f32(i32 46, float %233, float %26, float %260)  ; FMad(a,b,c)
  %262 = fadd fast float %261, %22
  %263 = fmul fast float %246, %33
  %264 = call float @dx.op.tertiary.f32(i32 46, float %247, float %29, float %263)  ; FMad(a,b,c)
  %265 = call float @dx.op.tertiary.f32(i32 46, float %233, float %25, float %264)  ; FMad(a,b,c)
  %266 = fadd fast float %265, %21
  %267 = fdiv fast float %266, %251
  %268 = fdiv fast float %262, %251
  %269 = fdiv fast float %258, %251
  %270 = fsub fast float %267, %18
  %271 = fsub fast float %268, %19
  %272 = fsub fast float %269, %20
  %273 = fmul fast float %270, %270
  %274 = fmul fast float %271, %271
  %275 = fadd fast float %274, %273
  %276 = fmul fast float %272, %272
  %277 = fadd fast float %275, %276
  %278 = call float @dx.op.unary.f32(i32 24, float %277)  ; Sqrt(value)
  %279 = fsub fast float %278, %10
  %280 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %279)  ; FMax(a,b)
  %281 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %281, label %282, label %305

; <label>:282                                     ; preds = %254
  %283 = call float @dx.op.unary.f32(i32 6, float %271)  ; FAbs(value)
  %284 = fmul fast float %283, %12
  %285 = fcmp fast olt float %284, 0x3F50624DE0000000
  br i1 %285, label %286, label %289

; <label>:286                                     ; preds = %282
  %287 = fmul fast float %284, 5.000000e-01
  %288 = fsub fast float 1.000000e+00, %287
  br label %294

; <label>:289                                     ; preds = %282
  %290 = fmul fast float %284, 0xBFF7154760000000
  %291 = call float @dx.op.unary.f32(i32 21, float %290)  ; Exp(value)
  %292 = fsub fast float 1.000000e+00, %291
  %293 = fdiv fast float %292, %284
  br label %294

; <label>:294                                     ; preds = %289, %286
  %295 = phi float [ %288, %286 ], [ %293, %289 ]
  %296 = call float @dx.op.binary.f32(i32 36, float %268, float %19)  ; FMin(a,b)
  %297 = fsub fast float %296, %11
  %298 = fmul fast float %12, %297
  %299 = fsub fast float -0.000000e+00, %298
  %300 = call float @dx.op.binary.f32(i32 35, float %299, float -4.000000e+01)  ; FMax(a,b)
  %301 = call float @dx.op.binary.f32(i32 36, float %300, float 5.000000e+00)  ; FMin(a,b)
  %302 = fmul fast float %301, 0x3FF7154760000000
  %303 = call float @dx.op.unary.f32(i32 21, float %302)  ; Exp(value)
  %304 = fmul fast float %303, %295
  br label %305

; <label>:305                                     ; preds = %294, %254
  %306 = phi float [ %304, %294 ], [ 1.000000e+00, %254 ]
  %307 = fmul fast float %280, %17
  %308 = fmul fast float %307, %306
  %309 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %308)  ; FMin(a,b)
  %310 = fmul fast float %309, 0xBFF7154760000000
  %311 = call float @dx.op.unary.f32(i32 21, float %310)  ; Exp(value)
  %312 = fsub fast float 1.000000e+00, %311
  %313 = call float @dx.op.binary.f32(i32 36, float %13, float %312)  ; FMin(a,b)
  %314 = fsub fast float %14, %177
  %315 = fsub fast float %15, %178
  %316 = fsub fast float %16, %179
  %317 = fmul fast float %313, %314
  %318 = fmul fast float %313, %315
  %319 = fmul fast float %313, %316
  %320 = fadd fast float %317, %177
  %321 = fadd fast float %318, %178
  %322 = fadd fast float %319, %179
  br label %323

; <label>:323                                     ; preds = %305, %237, %231
  %324 = phi float [ %320, %305 ], [ %177, %237 ], [ %177, %231 ]
  %325 = phi float [ %321, %305 ], [ %178, %237 ], [ %178, %231 ]
  %326 = phi float [ %322, %305 ], [ %179, %237 ], [ %179, %231 ]
  %327 = fadd fast float %6, 1.000000e+00
  %328 = fadd fast float %7, 1.000000e+00
  %329 = fsub fast float 1.000000e+00, %6
  %330 = fmul fast float %37, %327
  %331 = fmul fast float %37, %328
  %332 = fmul fast float %37, %329
  %333 = fmul fast float %330, %324
  %334 = fmul fast float %331, %325
  %335 = fmul fast float %332, %326
  %336 = fcmp fast ult float %38, 5.000000e-01
  br i1 %336, label %362, label %337

; <label>:337                                     ; preds = %323
  %338 = fmul fast float %333, 0x4004147AE0000000
  %339 = fmul fast float %334, 0x4004147AE0000000
  %340 = fmul fast float %335, 0x4004147AE0000000
  %341 = fadd fast float %338, 0x3F9EB851E0000000
  %342 = fadd fast float %339, 0x3F9EB851E0000000
  %343 = fadd fast float %340, 0x3F9EB851E0000000
  %344 = fmul fast float %341, %333
  %345 = fmul fast float %342, %334
  %346 = fmul fast float %343, %335
  %347 = fmul fast float %333, 0x400370A3E0000000
  %348 = fmul fast float %334, 0x400370A3E0000000
  %349 = fmul fast float %335, 0x400370A3E0000000
  %350 = fadd fast float %347, 0x3FE2E147A0000000
  %351 = fadd fast float %348, 0x3FE2E147A0000000
  %352 = fadd fast float %349, 0x3FE2E147A0000000
  %353 = fmul fast float %350, %333
  %354 = fmul fast float %351, %334
  %355 = fmul fast float %352, %335
  %356 = fadd fast float %353, 0x3FC1EB8520000000
  %357 = fadd fast float %354, 0x3FC1EB8520000000
  %358 = fadd fast float %355, 0x3FC1EB8520000000
  %359 = fdiv fast float %344, %356
  %360 = fdiv fast float %345, %357
  %361 = fdiv fast float %346, %358
  br label %362

; <label>:362                                     ; preds = %337, %323
  %363 = phi float [ %359, %337 ], [ %333, %323 ]
  %364 = phi float [ %360, %337 ], [ %334, %323 ]
  %365 = phi float [ %361, %337 ], [ %335, %323 ]
  %366 = call float @dx.op.unary.f32(i32 7, float %363)  ; Saturate(value)
  %367 = call float @dx.op.unary.f32(i32 7, float %364)  ; Saturate(value)
  %368 = call float @dx.op.unary.f32(i32 7, float %365)  ; Saturate(value)
  %369 = call float @dx.op.dot3.f32(i32 55, float %366, float %367, float %368, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %370 = fsub fast float %366, %369
  %371 = fsub fast float %367, %369
  %372 = fsub fast float %368, %369
  %373 = fmul fast float %370, %9
  %374 = fmul fast float %371, %9
  %375 = fmul fast float %372, %9
  %376 = fadd fast float %373, %369
  %377 = fadd fast float %374, %369
  %378 = fadd fast float %375, %369
  %379 = call float @dx.op.unary.f32(i32 7, float %376)  ; Saturate(value)
  %380 = call float @dx.op.unary.f32(i32 7, float %377)  ; Saturate(value)
  %381 = call float @dx.op.unary.f32(i32 7, float %378)  ; Saturate(value)
  %382 = fadd fast float %379, 0xBFC70A3D80000000
  %383 = fadd fast float %380, 0xBFC70A3D80000000
  %384 = fadd fast float %381, 0xBFC70A3D80000000
  %385 = fmul fast float %382, %8
  %386 = fmul fast float %383, %8
  %387 = fmul fast float %384, %8
  %388 = fadd fast float %385, 0x3FC70A3D80000000
  %389 = fadd fast float %386, 0x3FC70A3D80000000
  %390 = fadd fast float %387, 0x3FC70A3D80000000
  %391 = call float @dx.op.unary.f32(i32 7, float %388)  ; Saturate(value)
  %392 = call float @dx.op.unary.f32(i32 7, float %389)  ; Saturate(value)
  %393 = call float @dx.op.unary.f32(i32 7, float %390)  ; Saturate(value)
  br label %394

; <label>:394                                     ; preds = %362, %197
  %395 = phi float [ %228, %197 ], [ %391, %362 ]
  %396 = phi float [ %229, %197 ], [ %392, %362 ]
  %397 = phi float [ %230, %197 ], [ %393, %362 ]
  %398 = fcmp fast olt float %185, 0.000000e+00
  br i1 %398, label %399, label %433

; <label>:399                                     ; preds = %394
  %400 = fcmp fast ogt float %182, 0x3FA4B5DCC0000000
  %401 = fcmp fast ogt float %183, 0x3FA4B5DCC0000000
  %402 = fcmp fast ogt float %184, 0x3FA4B5DCC0000000
  %403 = select i1 %400, float 0.000000e+00, float 1.000000e+00
  %404 = select i1 %401, float 0.000000e+00, float 1.000000e+00
  %405 = select i1 %402, float 0.000000e+00, float 1.000000e+00
  %406 = fmul fast float %182, 0x3FB3D07220000000
  %407 = fmul fast float %183, 0x3FB3D07220000000
  %408 = fmul fast float %184, 0x3FB3D07220000000
  %409 = fadd fast float %182, 0x3FAC28F5C0000000
  %410 = fadd fast float %183, 0x3FAC28F5C0000000
  %411 = fadd fast float %184, 0x3FAC28F5C0000000
  %412 = fmul fast float %409, 0x3FEE54EDE0000000
  %413 = fmul fast float %410, 0x3FEE54EDE0000000
  %414 = fmul fast float %411, 0x3FEE54EDE0000000
  %415 = call float @dx.op.unary.f32(i32 23, float %412)  ; Log(value)
  %416 = call float @dx.op.unary.f32(i32 23, float %413)  ; Log(value)
  %417 = call float @dx.op.unary.f32(i32 23, float %414)  ; Log(value)
  %418 = fmul fast float %415, 0x4003333340000000
  %419 = fmul fast float %416, 0x4003333340000000
  %420 = fmul fast float %417, 0x4003333340000000
  %421 = call float @dx.op.unary.f32(i32 21, float %418)  ; Exp(value)
  %422 = call float @dx.op.unary.f32(i32 21, float %419)  ; Exp(value)
  %423 = call float @dx.op.unary.f32(i32 21, float %420)  ; Exp(value)
  %424 = fsub fast float %406, %421
  %425 = fsub fast float %407, %422
  %426 = fsub fast float %408, %423
  %427 = fmul fast float %424, %403
  %428 = fmul fast float %425, %404
  %429 = fmul fast float %426, %405
  %430 = fadd fast float %427, %421
  %431 = fadd fast float %428, %422
  %432 = fadd fast float %429, %423
  br label %596

; <label>:433                                     ; preds = %394
  %434 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %66, i32 %57, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %435 = extractvalue %dx.types.ResRet.f32 %434, 0
  %436 = fcmp fast ogt float %39, 5.000000e-01
  %437 = fcmp fast olt float %435, 1.000000e+00
  %438 = and i1 %436, %437
  br i1 %438, label %439, label %525

; <label>:439                                     ; preds = %433
  %440 = sitofp i32 %66 to float
  %441 = sitofp i32 %57 to float
  %442 = fadd fast float %440, 5.000000e-01
  %443 = fadd fast float %441, 5.000000e-01
  %444 = fdiv fast float %442, %46
  %445 = fdiv fast float %443, %47
  %446 = fmul fast float %444, 2.000000e+00
  %447 = fmul fast float %445, 2.000000e+00
  %448 = fadd fast float %446, -1.000000e+00
  %449 = fsub fast float 1.000000e+00, %447
  %450 = fmul fast float %448, %36
  %451 = call float @dx.op.tertiary.f32(i32 46, float %449, float %32, float %450)  ; FMad(a,b,c)
  %452 = call float @dx.op.tertiary.f32(i32 46, float %435, float %28, float %451)  ; FMad(a,b,c)
  %453 = fadd fast float %452, %24
  %454 = call float @dx.op.unary.f32(i32 6, float %453)  ; FAbs(value)
  %455 = fcmp fast ogt float %454, 0x3EB0C6F7A0000000
  br i1 %455, label %456, label %525

; <label>:456                                     ; preds = %439
  %457 = fmul fast float %448, %35
  %458 = call float @dx.op.tertiary.f32(i32 46, float %449, float %31, float %457)  ; FMad(a,b,c)
  %459 = call float @dx.op.tertiary.f32(i32 46, float %435, float %27, float %458)  ; FMad(a,b,c)
  %460 = fadd fast float %459, %23
  %461 = fmul fast float %448, %34
  %462 = call float @dx.op.tertiary.f32(i32 46, float %449, float %30, float %461)  ; FMad(a,b,c)
  %463 = call float @dx.op.tertiary.f32(i32 46, float %435, float %26, float %462)  ; FMad(a,b,c)
  %464 = fadd fast float %463, %22
  %465 = fmul fast float %448, %33
  %466 = call float @dx.op.tertiary.f32(i32 46, float %449, float %29, float %465)  ; FMad(a,b,c)
  %467 = call float @dx.op.tertiary.f32(i32 46, float %435, float %25, float %466)  ; FMad(a,b,c)
  %468 = fadd fast float %467, %21
  %469 = fdiv fast float %468, %453
  %470 = fdiv fast float %464, %453
  %471 = fdiv fast float %460, %453
  %472 = fsub fast float %469, %18
  %473 = fsub fast float %470, %19
  %474 = fsub fast float %471, %20
  %475 = fmul fast float %472, %472
  %476 = fmul fast float %473, %473
  %477 = fadd fast float %476, %475
  %478 = fmul fast float %474, %474
  %479 = fadd fast float %477, %478
  %480 = call float @dx.op.unary.f32(i32 24, float %479)  ; Sqrt(value)
  %481 = fsub fast float %480, %10
  %482 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %481)  ; FMax(a,b)
  %483 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %483, label %484, label %507

; <label>:484                                     ; preds = %456
  %485 = call float @dx.op.unary.f32(i32 6, float %473)  ; FAbs(value)
  %486 = fmul fast float %485, %12
  %487 = fcmp fast olt float %486, 0x3F50624DE0000000
  br i1 %487, label %488, label %491

; <label>:488                                     ; preds = %484
  %489 = fmul fast float %486, 5.000000e-01
  %490 = fsub fast float 1.000000e+00, %489
  br label %496

; <label>:491                                     ; preds = %484
  %492 = fmul fast float %486, 0xBFF7154760000000
  %493 = call float @dx.op.unary.f32(i32 21, float %492)  ; Exp(value)
  %494 = fsub fast float 1.000000e+00, %493
  %495 = fdiv fast float %494, %486
  br label %496

; <label>:496                                     ; preds = %491, %488
  %497 = phi float [ %490, %488 ], [ %495, %491 ]
  %498 = call float @dx.op.binary.f32(i32 36, float %470, float %19)  ; FMin(a,b)
  %499 = fsub fast float %498, %11
  %500 = fmul fast float %12, %499
  %501 = fsub fast float -0.000000e+00, %500
  %502 = call float @dx.op.binary.f32(i32 35, float %501, float -4.000000e+01)  ; FMax(a,b)
  %503 = call float @dx.op.binary.f32(i32 36, float %502, float 5.000000e+00)  ; FMin(a,b)
  %504 = fmul fast float %503, 0x3FF7154760000000
  %505 = call float @dx.op.unary.f32(i32 21, float %504)  ; Exp(value)
  %506 = fmul fast float %505, %497
  br label %507

; <label>:507                                     ; preds = %496, %456
  %508 = phi float [ %506, %496 ], [ 1.000000e+00, %456 ]
  %509 = fmul fast float %482, %17
  %510 = fmul fast float %509, %508
  %511 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %510)  ; FMin(a,b)
  %512 = fmul fast float %511, 0xBFF7154760000000
  %513 = call float @dx.op.unary.f32(i32 21, float %512)  ; Exp(value)
  %514 = fsub fast float 1.000000e+00, %513
  %515 = call float @dx.op.binary.f32(i32 36, float %13, float %514)  ; FMin(a,b)
  %516 = fsub fast float %14, %182
  %517 = fsub fast float %15, %183
  %518 = fsub fast float %16, %184
  %519 = fmul fast float %515, %516
  %520 = fmul fast float %515, %517
  %521 = fmul fast float %515, %518
  %522 = fadd fast float %519, %182
  %523 = fadd fast float %520, %183
  %524 = fadd fast float %521, %184
  br label %525

; <label>:525                                     ; preds = %507, %439, %433
  %526 = phi float [ %522, %507 ], [ %182, %439 ], [ %182, %433 ]
  %527 = phi float [ %523, %507 ], [ %183, %439 ], [ %183, %433 ]
  %528 = phi float [ %524, %507 ], [ %184, %439 ], [ %184, %433 ]
  %529 = fadd fast float %6, 1.000000e+00
  %530 = fadd fast float %7, 1.000000e+00
  %531 = fsub fast float 1.000000e+00, %6
  %532 = fmul fast float %37, %529
  %533 = fmul fast float %37, %530
  %534 = fmul fast float %37, %531
  %535 = fmul fast float %532, %526
  %536 = fmul fast float %533, %527
  %537 = fmul fast float %534, %528
  %538 = fcmp fast ult float %38, 5.000000e-01
  br i1 %538, label %564, label %539

; <label>:539                                     ; preds = %525
  %540 = fmul fast float %535, 0x4004147AE0000000
  %541 = fmul fast float %536, 0x4004147AE0000000
  %542 = fmul fast float %537, 0x4004147AE0000000
  %543 = fadd fast float %540, 0x3F9EB851E0000000
  %544 = fadd fast float %541, 0x3F9EB851E0000000
  %545 = fadd fast float %542, 0x3F9EB851E0000000
  %546 = fmul fast float %543, %535
  %547 = fmul fast float %544, %536
  %548 = fmul fast float %545, %537
  %549 = fmul fast float %535, 0x400370A3E0000000
  %550 = fmul fast float %536, 0x400370A3E0000000
  %551 = fmul fast float %537, 0x400370A3E0000000
  %552 = fadd fast float %549, 0x3FE2E147A0000000
  %553 = fadd fast float %550, 0x3FE2E147A0000000
  %554 = fadd fast float %551, 0x3FE2E147A0000000
  %555 = fmul fast float %552, %535
  %556 = fmul fast float %553, %536
  %557 = fmul fast float %554, %537
  %558 = fadd fast float %555, 0x3FC1EB8520000000
  %559 = fadd fast float %556, 0x3FC1EB8520000000
  %560 = fadd fast float %557, 0x3FC1EB8520000000
  %561 = fdiv fast float %546, %558
  %562 = fdiv fast float %547, %559
  %563 = fdiv fast float %548, %560
  br label %564

; <label>:564                                     ; preds = %539, %525
  %565 = phi float [ %561, %539 ], [ %535, %525 ]
  %566 = phi float [ %562, %539 ], [ %536, %525 ]
  %567 = phi float [ %563, %539 ], [ %537, %525 ]
  %568 = call float @dx.op.unary.f32(i32 7, float %565)  ; Saturate(value)
  %569 = call float @dx.op.unary.f32(i32 7, float %566)  ; Saturate(value)
  %570 = call float @dx.op.unary.f32(i32 7, float %567)  ; Saturate(value)
  %571 = call float @dx.op.dot3.f32(i32 55, float %568, float %569, float %570, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %572 = fsub fast float %568, %571
  %573 = fsub fast float %569, %571
  %574 = fsub fast float %570, %571
  %575 = fmul fast float %572, %9
  %576 = fmul fast float %573, %9
  %577 = fmul fast float %574, %9
  %578 = fadd fast float %575, %571
  %579 = fadd fast float %576, %571
  %580 = fadd fast float %577, %571
  %581 = call float @dx.op.unary.f32(i32 7, float %578)  ; Saturate(value)
  %582 = call float @dx.op.unary.f32(i32 7, float %579)  ; Saturate(value)
  %583 = call float @dx.op.unary.f32(i32 7, float %580)  ; Saturate(value)
  %584 = fadd fast float %581, 0xBFC70A3D80000000
  %585 = fadd fast float %582, 0xBFC70A3D80000000
  %586 = fadd fast float %583, 0xBFC70A3D80000000
  %587 = fmul fast float %584, %8
  %588 = fmul fast float %585, %8
  %589 = fmul fast float %586, %8
  %590 = fadd fast float %587, 0x3FC70A3D80000000
  %591 = fadd fast float %588, 0x3FC70A3D80000000
  %592 = fadd fast float %589, 0x3FC70A3D80000000
  %593 = call float @dx.op.unary.f32(i32 7, float %590)  ; Saturate(value)
  %594 = call float @dx.op.unary.f32(i32 7, float %591)  ; Saturate(value)
  %595 = call float @dx.op.unary.f32(i32 7, float %592)  ; Saturate(value)
  br label %596

; <label>:596                                     ; preds = %564, %399
  %597 = phi float [ %430, %399 ], [ %593, %564 ]
  %598 = phi float [ %431, %399 ], [ %594, %564 ]
  %599 = phi float [ %432, %399 ], [ %595, %564 ]
  %600 = fcmp fast olt float %190, 0.000000e+00
  br i1 %600, label %601, label %635

; <label>:601                                     ; preds = %596
  %602 = fcmp fast ogt float %187, 0x3FA4B5DCC0000000
  %603 = fcmp fast ogt float %188, 0x3FA4B5DCC0000000
  %604 = fcmp fast ogt float %189, 0x3FA4B5DCC0000000
  %605 = select i1 %602, float 0.000000e+00, float 1.000000e+00
  %606 = select i1 %603, float 0.000000e+00, float 1.000000e+00
  %607 = select i1 %604, float 0.000000e+00, float 1.000000e+00
  %608 = fmul fast float %187, 0x3FB3D07220000000
  %609 = fmul fast float %188, 0x3FB3D07220000000
  %610 = fmul fast float %189, 0x3FB3D07220000000
  %611 = fadd fast float %187, 0x3FAC28F5C0000000
  %612 = fadd fast float %188, 0x3FAC28F5C0000000
  %613 = fadd fast float %189, 0x3FAC28F5C0000000
  %614 = fmul fast float %611, 0x3FEE54EDE0000000
  %615 = fmul fast float %612, 0x3FEE54EDE0000000
  %616 = fmul fast float %613, 0x3FEE54EDE0000000
  %617 = call float @dx.op.unary.f32(i32 23, float %614)  ; Log(value)
  %618 = call float @dx.op.unary.f32(i32 23, float %615)  ; Log(value)
  %619 = call float @dx.op.unary.f32(i32 23, float %616)  ; Log(value)
  %620 = fmul fast float %617, 0x4003333340000000
  %621 = fmul fast float %618, 0x4003333340000000
  %622 = fmul fast float %619, 0x4003333340000000
  %623 = call float @dx.op.unary.f32(i32 21, float %620)  ; Exp(value)
  %624 = call float @dx.op.unary.f32(i32 21, float %621)  ; Exp(value)
  %625 = call float @dx.op.unary.f32(i32 21, float %622)  ; Exp(value)
  %626 = fsub fast float %608, %623
  %627 = fsub fast float %609, %624
  %628 = fsub fast float %610, %625
  %629 = fmul fast float %626, %605
  %630 = fmul fast float %627, %606
  %631 = fmul fast float %628, %607
  %632 = fadd fast float %629, %623
  %633 = fadd fast float %630, %624
  %634 = fadd fast float %631, %625
  br label %798

; <label>:635                                     ; preds = %596
  %636 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %56, i32 %69, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %637 = extractvalue %dx.types.ResRet.f32 %636, 0
  %638 = fcmp fast ogt float %39, 5.000000e-01
  %639 = fcmp fast olt float %637, 1.000000e+00
  %640 = and i1 %638, %639
  br i1 %640, label %641, label %727

; <label>:641                                     ; preds = %635
  %642 = sitofp i32 %56 to float
  %643 = sitofp i32 %69 to float
  %644 = fadd fast float %642, 5.000000e-01
  %645 = fadd fast float %643, 5.000000e-01
  %646 = fdiv fast float %644, %46
  %647 = fdiv fast float %645, %47
  %648 = fmul fast float %646, 2.000000e+00
  %649 = fmul fast float %647, 2.000000e+00
  %650 = fadd fast float %648, -1.000000e+00
  %651 = fsub fast float 1.000000e+00, %649
  %652 = fmul fast float %650, %36
  %653 = call float @dx.op.tertiary.f32(i32 46, float %651, float %32, float %652)  ; FMad(a,b,c)
  %654 = call float @dx.op.tertiary.f32(i32 46, float %637, float %28, float %653)  ; FMad(a,b,c)
  %655 = fadd fast float %654, %24
  %656 = call float @dx.op.unary.f32(i32 6, float %655)  ; FAbs(value)
  %657 = fcmp fast ogt float %656, 0x3EB0C6F7A0000000
  br i1 %657, label %658, label %727

; <label>:658                                     ; preds = %641
  %659 = fmul fast float %650, %35
  %660 = call float @dx.op.tertiary.f32(i32 46, float %651, float %31, float %659)  ; FMad(a,b,c)
  %661 = call float @dx.op.tertiary.f32(i32 46, float %637, float %27, float %660)  ; FMad(a,b,c)
  %662 = fadd fast float %661, %23
  %663 = fmul fast float %650, %34
  %664 = call float @dx.op.tertiary.f32(i32 46, float %651, float %30, float %663)  ; FMad(a,b,c)
  %665 = call float @dx.op.tertiary.f32(i32 46, float %637, float %26, float %664)  ; FMad(a,b,c)
  %666 = fadd fast float %665, %22
  %667 = fmul fast float %650, %33
  %668 = call float @dx.op.tertiary.f32(i32 46, float %651, float %29, float %667)  ; FMad(a,b,c)
  %669 = call float @dx.op.tertiary.f32(i32 46, float %637, float %25, float %668)  ; FMad(a,b,c)
  %670 = fadd fast float %669, %21
  %671 = fdiv fast float %670, %655
  %672 = fdiv fast float %666, %655
  %673 = fdiv fast float %662, %655
  %674 = fsub fast float %671, %18
  %675 = fsub fast float %672, %19
  %676 = fsub fast float %673, %20
  %677 = fmul fast float %674, %674
  %678 = fmul fast float %675, %675
  %679 = fadd fast float %678, %677
  %680 = fmul fast float %676, %676
  %681 = fadd fast float %679, %680
  %682 = call float @dx.op.unary.f32(i32 24, float %681)  ; Sqrt(value)
  %683 = fsub fast float %682, %10
  %684 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %683)  ; FMax(a,b)
  %685 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %685, label %686, label %709

; <label>:686                                     ; preds = %658
  %687 = call float @dx.op.unary.f32(i32 6, float %675)  ; FAbs(value)
  %688 = fmul fast float %687, %12
  %689 = fcmp fast olt float %688, 0x3F50624DE0000000
  br i1 %689, label %690, label %693

; <label>:690                                     ; preds = %686
  %691 = fmul fast float %688, 5.000000e-01
  %692 = fsub fast float 1.000000e+00, %691
  br label %698

; <label>:693                                     ; preds = %686
  %694 = fmul fast float %688, 0xBFF7154760000000
  %695 = call float @dx.op.unary.f32(i32 21, float %694)  ; Exp(value)
  %696 = fsub fast float 1.000000e+00, %695
  %697 = fdiv fast float %696, %688
  br label %698

; <label>:698                                     ; preds = %693, %690
  %699 = phi float [ %692, %690 ], [ %697, %693 ]
  %700 = call float @dx.op.binary.f32(i32 36, float %672, float %19)  ; FMin(a,b)
  %701 = fsub fast float %700, %11
  %702 = fmul fast float %12, %701
  %703 = fsub fast float -0.000000e+00, %702
  %704 = call float @dx.op.binary.f32(i32 35, float %703, float -4.000000e+01)  ; FMax(a,b)
  %705 = call float @dx.op.binary.f32(i32 36, float %704, float 5.000000e+00)  ; FMin(a,b)
  %706 = fmul fast float %705, 0x3FF7154760000000
  %707 = call float @dx.op.unary.f32(i32 21, float %706)  ; Exp(value)
  %708 = fmul fast float %707, %699
  br label %709

; <label>:709                                     ; preds = %698, %658
  %710 = phi float [ %708, %698 ], [ 1.000000e+00, %658 ]
  %711 = fmul fast float %684, %17
  %712 = fmul fast float %711, %710
  %713 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %712)  ; FMin(a,b)
  %714 = fmul fast float %713, 0xBFF7154760000000
  %715 = call float @dx.op.unary.f32(i32 21, float %714)  ; Exp(value)
  %716 = fsub fast float 1.000000e+00, %715
  %717 = call float @dx.op.binary.f32(i32 36, float %13, float %716)  ; FMin(a,b)
  %718 = fsub fast float %14, %187
  %719 = fsub fast float %15, %188
  %720 = fsub fast float %16, %189
  %721 = fmul fast float %717, %718
  %722 = fmul fast float %717, %719
  %723 = fmul fast float %717, %720
  %724 = fadd fast float %721, %187
  %725 = fadd fast float %722, %188
  %726 = fadd fast float %723, %189
  br label %727

; <label>:727                                     ; preds = %709, %641, %635
  %728 = phi float [ %724, %709 ], [ %187, %641 ], [ %187, %635 ]
  %729 = phi float [ %725, %709 ], [ %188, %641 ], [ %188, %635 ]
  %730 = phi float [ %726, %709 ], [ %189, %641 ], [ %189, %635 ]
  %731 = fadd fast float %6, 1.000000e+00
  %732 = fadd fast float %7, 1.000000e+00
  %733 = fsub fast float 1.000000e+00, %6
  %734 = fmul fast float %37, %731
  %735 = fmul fast float %37, %732
  %736 = fmul fast float %37, %733
  %737 = fmul fast float %734, %728
  %738 = fmul fast float %735, %729
  %739 = fmul fast float %736, %730
  %740 = fcmp fast ult float %38, 5.000000e-01
  br i1 %740, label %766, label %741

; <label>:741                                     ; preds = %727
  %742 = fmul fast float %737, 0x4004147AE0000000
  %743 = fmul fast float %738, 0x4004147AE0000000
  %744 = fmul fast float %739, 0x4004147AE0000000
  %745 = fadd fast float %742, 0x3F9EB851E0000000
  %746 = fadd fast float %743, 0x3F9EB851E0000000
  %747 = fadd fast float %744, 0x3F9EB851E0000000
  %748 = fmul fast float %745, %737
  %749 = fmul fast float %746, %738
  %750 = fmul fast float %747, %739
  %751 = fmul fast float %737, 0x400370A3E0000000
  %752 = fmul fast float %738, 0x400370A3E0000000
  %753 = fmul fast float %739, 0x400370A3E0000000
  %754 = fadd fast float %751, 0x3FE2E147A0000000
  %755 = fadd fast float %752, 0x3FE2E147A0000000
  %756 = fadd fast float %753, 0x3FE2E147A0000000
  %757 = fmul fast float %754, %737
  %758 = fmul fast float %755, %738
  %759 = fmul fast float %756, %739
  %760 = fadd fast float %757, 0x3FC1EB8520000000
  %761 = fadd fast float %758, 0x3FC1EB8520000000
  %762 = fadd fast float %759, 0x3FC1EB8520000000
  %763 = fdiv fast float %748, %760
  %764 = fdiv fast float %749, %761
  %765 = fdiv fast float %750, %762
  br label %766

; <label>:766                                     ; preds = %741, %727
  %767 = phi float [ %763, %741 ], [ %737, %727 ]
  %768 = phi float [ %764, %741 ], [ %738, %727 ]
  %769 = phi float [ %765, %741 ], [ %739, %727 ]
  %770 = call float @dx.op.unary.f32(i32 7, float %767)  ; Saturate(value)
  %771 = call float @dx.op.unary.f32(i32 7, float %768)  ; Saturate(value)
  %772 = call float @dx.op.unary.f32(i32 7, float %769)  ; Saturate(value)
  %773 = call float @dx.op.dot3.f32(i32 55, float %770, float %771, float %772, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %774 = fsub fast float %770, %773
  %775 = fsub fast float %771, %773
  %776 = fsub fast float %772, %773
  %777 = fmul fast float %774, %9
  %778 = fmul fast float %775, %9
  %779 = fmul fast float %776, %9
  %780 = fadd fast float %777, %773
  %781 = fadd fast float %778, %773
  %782 = fadd fast float %779, %773
  %783 = call float @dx.op.unary.f32(i32 7, float %780)  ; Saturate(value)
  %784 = call float @dx.op.unary.f32(i32 7, float %781)  ; Saturate(value)
  %785 = call float @dx.op.unary.f32(i32 7, float %782)  ; Saturate(value)
  %786 = fadd fast float %783, 0xBFC70A3D80000000
  %787 = fadd fast float %784, 0xBFC70A3D80000000
  %788 = fadd fast float %785, 0xBFC70A3D80000000
  %789 = fmul fast float %786, %8
  %790 = fmul fast float %787, %8
  %791 = fmul fast float %788, %8
  %792 = fadd fast float %789, 0x3FC70A3D80000000
  %793 = fadd fast float %790, 0x3FC70A3D80000000
  %794 = fadd fast float %791, 0x3FC70A3D80000000
  %795 = call float @dx.op.unary.f32(i32 7, float %792)  ; Saturate(value)
  %796 = call float @dx.op.unary.f32(i32 7, float %793)  ; Saturate(value)
  %797 = call float @dx.op.unary.f32(i32 7, float %794)  ; Saturate(value)
  br label %798

; <label>:798                                     ; preds = %766, %601
  %799 = phi float [ %632, %601 ], [ %795, %766 ]
  %800 = phi float [ %633, %601 ], [ %796, %766 ]
  %801 = phi float [ %634, %601 ], [ %797, %766 ]
  %802 = fcmp fast olt float %195, 0.000000e+00
  br i1 %802, label %803, label %837

; <label>:803                                     ; preds = %798
  %804 = fcmp fast ogt float %192, 0x3FA4B5DCC0000000
  %805 = fcmp fast ogt float %193, 0x3FA4B5DCC0000000
  %806 = fcmp fast ogt float %194, 0x3FA4B5DCC0000000
  %807 = select i1 %804, float 0.000000e+00, float 1.000000e+00
  %808 = select i1 %805, float 0.000000e+00, float 1.000000e+00
  %809 = select i1 %806, float 0.000000e+00, float 1.000000e+00
  %810 = fmul fast float %192, 0x3FB3D07220000000
  %811 = fmul fast float %193, 0x3FB3D07220000000
  %812 = fmul fast float %194, 0x3FB3D07220000000
  %813 = fadd fast float %192, 0x3FAC28F5C0000000
  %814 = fadd fast float %193, 0x3FAC28F5C0000000
  %815 = fadd fast float %194, 0x3FAC28F5C0000000
  %816 = fmul fast float %813, 0x3FEE54EDE0000000
  %817 = fmul fast float %814, 0x3FEE54EDE0000000
  %818 = fmul fast float %815, 0x3FEE54EDE0000000
  %819 = call float @dx.op.unary.f32(i32 23, float %816)  ; Log(value)
  %820 = call float @dx.op.unary.f32(i32 23, float %817)  ; Log(value)
  %821 = call float @dx.op.unary.f32(i32 23, float %818)  ; Log(value)
  %822 = fmul fast float %819, 0x4003333340000000
  %823 = fmul fast float %820, 0x4003333340000000
  %824 = fmul fast float %821, 0x4003333340000000
  %825 = call float @dx.op.unary.f32(i32 21, float %822)  ; Exp(value)
  %826 = call float @dx.op.unary.f32(i32 21, float %823)  ; Exp(value)
  %827 = call float @dx.op.unary.f32(i32 21, float %824)  ; Exp(value)
  %828 = fsub fast float %810, %825
  %829 = fsub fast float %811, %826
  %830 = fsub fast float %812, %827
  %831 = fmul fast float %828, %807
  %832 = fmul fast float %829, %808
  %833 = fmul fast float %830, %809
  %834 = fadd fast float %831, %825
  %835 = fadd fast float %832, %826
  %836 = fadd fast float %833, %827
  br label %1000

; <label>:837                                     ; preds = %798
  %838 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %66, i32 %69, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %839 = extractvalue %dx.types.ResRet.f32 %838, 0
  %840 = fcmp fast ogt float %39, 5.000000e-01
  %841 = fcmp fast olt float %839, 1.000000e+00
  %842 = and i1 %840, %841
  br i1 %842, label %843, label %929

; <label>:843                                     ; preds = %837
  %844 = sitofp i32 %66 to float
  %845 = sitofp i32 %69 to float
  %846 = fadd fast float %844, 5.000000e-01
  %847 = fadd fast float %845, 5.000000e-01
  %848 = fdiv fast float %846, %46
  %849 = fdiv fast float %847, %47
  %850 = fmul fast float %848, 2.000000e+00
  %851 = fmul fast float %849, 2.000000e+00
  %852 = fadd fast float %850, -1.000000e+00
  %853 = fsub fast float 1.000000e+00, %851
  %854 = fmul fast float %852, %36
  %855 = call float @dx.op.tertiary.f32(i32 46, float %853, float %32, float %854)  ; FMad(a,b,c)
  %856 = call float @dx.op.tertiary.f32(i32 46, float %839, float %28, float %855)  ; FMad(a,b,c)
  %857 = fadd fast float %856, %24
  %858 = call float @dx.op.unary.f32(i32 6, float %857)  ; FAbs(value)
  %859 = fcmp fast ogt float %858, 0x3EB0C6F7A0000000
  br i1 %859, label %860, label %929

; <label>:860                                     ; preds = %843
  %861 = fmul fast float %852, %35
  %862 = call float @dx.op.tertiary.f32(i32 46, float %853, float %31, float %861)  ; FMad(a,b,c)
  %863 = call float @dx.op.tertiary.f32(i32 46, float %839, float %27, float %862)  ; FMad(a,b,c)
  %864 = fadd fast float %863, %23
  %865 = fmul fast float %852, %34
  %866 = call float @dx.op.tertiary.f32(i32 46, float %853, float %30, float %865)  ; FMad(a,b,c)
  %867 = call float @dx.op.tertiary.f32(i32 46, float %839, float %26, float %866)  ; FMad(a,b,c)
  %868 = fadd fast float %867, %22
  %869 = fmul fast float %852, %33
  %870 = call float @dx.op.tertiary.f32(i32 46, float %853, float %29, float %869)  ; FMad(a,b,c)
  %871 = call float @dx.op.tertiary.f32(i32 46, float %839, float %25, float %870)  ; FMad(a,b,c)
  %872 = fadd fast float %871, %21
  %873 = fdiv fast float %872, %857
  %874 = fdiv fast float %868, %857
  %875 = fdiv fast float %864, %857
  %876 = fsub fast float %873, %18
  %877 = fsub fast float %874, %19
  %878 = fsub fast float %875, %20
  %879 = fmul fast float %876, %876
  %880 = fmul fast float %877, %877
  %881 = fadd fast float %880, %879
  %882 = fmul fast float %878, %878
  %883 = fadd fast float %881, %882
  %884 = call float @dx.op.unary.f32(i32 24, float %883)  ; Sqrt(value)
  %885 = fsub fast float %884, %10
  %886 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %885)  ; FMax(a,b)
  %887 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %887, label %888, label %911

; <label>:888                                     ; preds = %860
  %889 = call float @dx.op.unary.f32(i32 6, float %877)  ; FAbs(value)
  %890 = fmul fast float %889, %12
  %891 = fcmp fast olt float %890, 0x3F50624DE0000000
  br i1 %891, label %892, label %895

; <label>:892                                     ; preds = %888
  %893 = fmul fast float %890, 5.000000e-01
  %894 = fsub fast float 1.000000e+00, %893
  br label %900

; <label>:895                                     ; preds = %888
  %896 = fmul fast float %890, 0xBFF7154760000000
  %897 = call float @dx.op.unary.f32(i32 21, float %896)  ; Exp(value)
  %898 = fsub fast float 1.000000e+00, %897
  %899 = fdiv fast float %898, %890
  br label %900

; <label>:900                                     ; preds = %895, %892
  %901 = phi float [ %894, %892 ], [ %899, %895 ]
  %902 = call float @dx.op.binary.f32(i32 36, float %874, float %19)  ; FMin(a,b)
  %903 = fsub fast float %902, %11
  %904 = fmul fast float %12, %903
  %905 = fsub fast float -0.000000e+00, %904
  %906 = call float @dx.op.binary.f32(i32 35, float %905, float -4.000000e+01)  ; FMax(a,b)
  %907 = call float @dx.op.binary.f32(i32 36, float %906, float 5.000000e+00)  ; FMin(a,b)
  %908 = fmul fast float %907, 0x3FF7154760000000
  %909 = call float @dx.op.unary.f32(i32 21, float %908)  ; Exp(value)
  %910 = fmul fast float %909, %901
  br label %911

; <label>:911                                     ; preds = %900, %860
  %912 = phi float [ %910, %900 ], [ 1.000000e+00, %860 ]
  %913 = fmul fast float %886, %17
  %914 = fmul fast float %913, %912
  %915 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %914)  ; FMin(a,b)
  %916 = fmul fast float %915, 0xBFF7154760000000
  %917 = call float @dx.op.unary.f32(i32 21, float %916)  ; Exp(value)
  %918 = fsub fast float 1.000000e+00, %917
  %919 = call float @dx.op.binary.f32(i32 36, float %13, float %918)  ; FMin(a,b)
  %920 = fsub fast float %14, %192
  %921 = fsub fast float %15, %193
  %922 = fsub fast float %16, %194
  %923 = fmul fast float %919, %920
  %924 = fmul fast float %919, %921
  %925 = fmul fast float %919, %922
  %926 = fadd fast float %923, %192
  %927 = fadd fast float %924, %193
  %928 = fadd fast float %925, %194
  br label %929

; <label>:929                                     ; preds = %911, %843, %837
  %930 = phi float [ %926, %911 ], [ %192, %843 ], [ %192, %837 ]
  %931 = phi float [ %927, %911 ], [ %193, %843 ], [ %193, %837 ]
  %932 = phi float [ %928, %911 ], [ %194, %843 ], [ %194, %837 ]
  %933 = fadd fast float %6, 1.000000e+00
  %934 = fadd fast float %7, 1.000000e+00
  %935 = fsub fast float 1.000000e+00, %6
  %936 = fmul fast float %37, %933
  %937 = fmul fast float %37, %934
  %938 = fmul fast float %37, %935
  %939 = fmul fast float %936, %930
  %940 = fmul fast float %937, %931
  %941 = fmul fast float %938, %932
  %942 = fcmp fast ult float %38, 5.000000e-01
  br i1 %942, label %968, label %943

; <label>:943                                     ; preds = %929
  %944 = fmul fast float %939, 0x4004147AE0000000
  %945 = fmul fast float %940, 0x4004147AE0000000
  %946 = fmul fast float %941, 0x4004147AE0000000
  %947 = fadd fast float %944, 0x3F9EB851E0000000
  %948 = fadd fast float %945, 0x3F9EB851E0000000
  %949 = fadd fast float %946, 0x3F9EB851E0000000
  %950 = fmul fast float %947, %939
  %951 = fmul fast float %948, %940
  %952 = fmul fast float %949, %941
  %953 = fmul fast float %939, 0x400370A3E0000000
  %954 = fmul fast float %940, 0x400370A3E0000000
  %955 = fmul fast float %941, 0x400370A3E0000000
  %956 = fadd fast float %953, 0x3FE2E147A0000000
  %957 = fadd fast float %954, 0x3FE2E147A0000000
  %958 = fadd fast float %955, 0x3FE2E147A0000000
  %959 = fmul fast float %956, %939
  %960 = fmul fast float %957, %940
  %961 = fmul fast float %958, %941
  %962 = fadd fast float %959, 0x3FC1EB8520000000
  %963 = fadd fast float %960, 0x3FC1EB8520000000
  %964 = fadd fast float %961, 0x3FC1EB8520000000
  %965 = fdiv fast float %950, %962
  %966 = fdiv fast float %951, %963
  %967 = fdiv fast float %952, %964
  br label %968

; <label>:968                                     ; preds = %943, %929
  %969 = phi float [ %965, %943 ], [ %939, %929 ]
  %970 = phi float [ %966, %943 ], [ %940, %929 ]
  %971 = phi float [ %967, %943 ], [ %941, %929 ]
  %972 = call float @dx.op.unary.f32(i32 7, float %969)  ; Saturate(value)
  %973 = call float @dx.op.unary.f32(i32 7, float %970)  ; Saturate(value)
  %974 = call float @dx.op.unary.f32(i32 7, float %971)  ; Saturate(value)
  %975 = call float @dx.op.dot3.f32(i32 55, float %972, float %973, float %974, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %976 = fsub fast float %972, %975
  %977 = fsub fast float %973, %975
  %978 = fsub fast float %974, %975
  %979 = fmul fast float %976, %9
  %980 = fmul fast float %977, %9
  %981 = fmul fast float %978, %9
  %982 = fadd fast float %979, %975
  %983 = fadd fast float %980, %975
  %984 = fadd fast float %981, %975
  %985 = call float @dx.op.unary.f32(i32 7, float %982)  ; Saturate(value)
  %986 = call float @dx.op.unary.f32(i32 7, float %983)  ; Saturate(value)
  %987 = call float @dx.op.unary.f32(i32 7, float %984)  ; Saturate(value)
  %988 = fadd fast float %985, 0xBFC70A3D80000000
  %989 = fadd fast float %986, 0xBFC70A3D80000000
  %990 = fadd fast float %987, 0xBFC70A3D80000000
  %991 = fmul fast float %988, %8
  %992 = fmul fast float %989, %8
  %993 = fmul fast float %990, %8
  %994 = fadd fast float %991, 0x3FC70A3D80000000
  %995 = fadd fast float %992, 0x3FC70A3D80000000
  %996 = fadd fast float %993, 0x3FC70A3D80000000
  %997 = call float @dx.op.unary.f32(i32 7, float %994)  ; Saturate(value)
  %998 = call float @dx.op.unary.f32(i32 7, float %995)  ; Saturate(value)
  %999 = call float @dx.op.unary.f32(i32 7, float %996)  ; Saturate(value)
  br label %1000

; <label>:1000                                    ; preds = %968, %803
  %1001 = phi float [ %834, %803 ], [ %997, %968 ]
  %1002 = phi float [ %835, %803 ], [ %998, %968 ]
  %1003 = phi float [ %836, %803 ], [ %999, %968 ]
  %1004 = fsub fast float -1.000000e+00, %180
  %1005 = select i1 %196, float %1004, float %180
  %1006 = fsub fast float -1.000000e+00, %185
  %1007 = select i1 %398, float %1006, float %185
  %1008 = fsub fast float -1.000000e+00, %190
  %1009 = select i1 %600, float %1008, float %190
  %1010 = fsub fast float -1.000000e+00, %195
  %1011 = select i1 %802, float %1010, float %195
  %1012 = fcmp fast ugt float %3, 0.000000e+00
  br i1 %1012, label %1013, label %8522

; <label>:1013                                    ; preds = %1000
  %1014 = fcmp fast ult float %180, 0.000000e+00
  br i1 %1014, label %1630, label %1015

; <label>:1015                                    ; preds = %1013
  %1016 = fsub fast float 1.000000e+00, %83
  %1017 = fmul fast float %1016, 0x3FA99999A0000000
  %1018 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %1017)  ; FMax(a,b)
  %1019 = fsub fast float %85, %83
  %1020 = call float @dx.op.unary.f32(i32 6, float %1019)  ; FAbs(value)
  %1021 = fdiv fast float %1020, %1018
  %1022 = fsub fast float 1.000000e+00, %1021
  %1023 = call float @dx.op.unary.f32(i32 7, float %1022)  ; Saturate(value)
  %1024 = fcmp fast ugt float %1023, 0.000000e+00
  br i1 %1024, label %1025, label %1035

; <label>:1025                                    ; preds = %1015
  %1026 = fsub fast float %597, %395
  %1027 = fsub fast float %598, %396
  %1028 = fsub fast float %599, %397
  %1029 = fmul fast float %1023, %1026
  %1030 = fmul fast float %1023, %1027
  %1031 = fmul fast float %1023, %1028
  %1032 = fadd fast float %1029, %395
  %1033 = fadd fast float %1030, %396
  %1034 = fadd fast float %1031, %397
  br label %1035

; <label>:1035                                    ; preds = %1025, %1015
  %1036 = phi float [ %1032, %1025 ], [ %395, %1015 ]
  %1037 = phi float [ %1033, %1025 ], [ %396, %1015 ]
  %1038 = phi float [ %1034, %1025 ], [ %397, %1015 ]
  %1039 = add i32 %56, -1
  %1040 = call i32 @dx.op.binary.i32(i32 37, i32 %1039, i32 0)  ; IMax(a,b)
  %1041 = call i32 @dx.op.binary.i32(i32 38, i32 %1040, i32 %60)  ; IMin(a,b)
  %1042 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1041, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1043 = extractvalue %dx.types.ResRet.f32 %1042, 0
  %1044 = fsub fast float %1043, %83
  %1045 = call float @dx.op.unary.f32(i32 6, float %1044)  ; FAbs(value)
  %1046 = fdiv fast float %1045, %1018
  %1047 = fsub fast float 1.000000e+00, %1046
  %1048 = call float @dx.op.unary.f32(i32 7, float %1047)  ; Saturate(value)
  %1049 = fcmp fast ugt float %1048, 0.000000e+00
  br i1 %1049, label %1050, label %1271

; <label>:1050                                    ; preds = %1035
  %1051 = call i32 @dx.op.binary.i32(i32 37, i32 %1041, i32 0)  ; IMax(a,b)
  %1052 = call i32 @dx.op.binary.i32(i32 37, i32 %65, i32 0)  ; IMax(a,b)
  %1053 = call i32 @dx.op.binary.i32(i32 38, i32 %1051, i32 %60)  ; IMin(a,b)
  %1054 = call i32 @dx.op.binary.i32(i32 38, i32 %1052, i32 %61)  ; IMin(a,b)
  %1055 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1053, i32 %1054, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1056 = extractvalue %dx.types.ResRet.f32 %1055, 0
  %1057 = extractvalue %dx.types.ResRet.f32 %1055, 1
  %1058 = extractvalue %dx.types.ResRet.f32 %1055, 2
  %1059 = extractvalue %dx.types.ResRet.f32 %1055, 3
  %1060 = fcmp fast olt float %1059, 0.000000e+00
  br i1 %1060, label %1061, label %1095

; <label>:1061                                    ; preds = %1050
  %1062 = fcmp fast ogt float %1056, 0x3FA4B5DCC0000000
  %1063 = fcmp fast ogt float %1057, 0x3FA4B5DCC0000000
  %1064 = fcmp fast ogt float %1058, 0x3FA4B5DCC0000000
  %1065 = select i1 %1062, float 0.000000e+00, float 1.000000e+00
  %1066 = select i1 %1063, float 0.000000e+00, float 1.000000e+00
  %1067 = select i1 %1064, float 0.000000e+00, float 1.000000e+00
  %1068 = fmul fast float %1056, 0x3FB3D07220000000
  %1069 = fmul fast float %1057, 0x3FB3D07220000000
  %1070 = fmul fast float %1058, 0x3FB3D07220000000
  %1071 = fadd fast float %1056, 0x3FAC28F5C0000000
  %1072 = fadd fast float %1057, 0x3FAC28F5C0000000
  %1073 = fadd fast float %1058, 0x3FAC28F5C0000000
  %1074 = fmul fast float %1071, 0x3FEE54EDE0000000
  %1075 = fmul fast float %1072, 0x3FEE54EDE0000000
  %1076 = fmul fast float %1073, 0x3FEE54EDE0000000
  %1077 = call float @dx.op.unary.f32(i32 23, float %1074)  ; Log(value)
  %1078 = call float @dx.op.unary.f32(i32 23, float %1075)  ; Log(value)
  %1079 = call float @dx.op.unary.f32(i32 23, float %1076)  ; Log(value)
  %1080 = fmul fast float %1077, 0x4003333340000000
  %1081 = fmul fast float %1078, 0x4003333340000000
  %1082 = fmul fast float %1079, 0x4003333340000000
  %1083 = call float @dx.op.unary.f32(i32 21, float %1080)  ; Exp(value)
  %1084 = call float @dx.op.unary.f32(i32 21, float %1081)  ; Exp(value)
  %1085 = call float @dx.op.unary.f32(i32 21, float %1082)  ; Exp(value)
  %1086 = fsub fast float %1068, %1083
  %1087 = fsub fast float %1069, %1084
  %1088 = fsub fast float %1070, %1085
  %1089 = fmul fast float %1086, %1065
  %1090 = fmul fast float %1087, %1066
  %1091 = fmul fast float %1088, %1067
  %1092 = fadd fast float %1089, %1083
  %1093 = fadd fast float %1090, %1084
  %1094 = fadd fast float %1091, %1085
  br label %1258

; <label>:1095                                    ; preds = %1050
  %1096 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1053, i32 %1054, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1097 = extractvalue %dx.types.ResRet.f32 %1096, 0
  %1098 = fcmp fast ogt float %39, 5.000000e-01
  %1099 = fcmp fast olt float %1097, 1.000000e+00
  %1100 = and i1 %1098, %1099
  br i1 %1100, label %1101, label %1187

; <label>:1101                                    ; preds = %1095
  %1102 = sitofp i32 %1053 to float
  %1103 = sitofp i32 %1054 to float
  %1104 = fadd fast float %1102, 5.000000e-01
  %1105 = fadd fast float %1103, 5.000000e-01
  %1106 = fdiv fast float %1104, %46
  %1107 = fdiv fast float %1105, %47
  %1108 = fmul fast float %1106, 2.000000e+00
  %1109 = fmul fast float %1107, 2.000000e+00
  %1110 = fadd fast float %1108, -1.000000e+00
  %1111 = fsub fast float 1.000000e+00, %1109
  %1112 = fmul fast float %1110, %36
  %1113 = call float @dx.op.tertiary.f32(i32 46, float %1111, float %32, float %1112)  ; FMad(a,b,c)
  %1114 = call float @dx.op.tertiary.f32(i32 46, float %1097, float %28, float %1113)  ; FMad(a,b,c)
  %1115 = fadd fast float %1114, %24
  %1116 = call float @dx.op.unary.f32(i32 6, float %1115)  ; FAbs(value)
  %1117 = fcmp fast ogt float %1116, 0x3EB0C6F7A0000000
  br i1 %1117, label %1118, label %1187

; <label>:1118                                    ; preds = %1101
  %1119 = fmul fast float %1110, %35
  %1120 = call float @dx.op.tertiary.f32(i32 46, float %1111, float %31, float %1119)  ; FMad(a,b,c)
  %1121 = call float @dx.op.tertiary.f32(i32 46, float %1097, float %27, float %1120)  ; FMad(a,b,c)
  %1122 = fadd fast float %1121, %23
  %1123 = fmul fast float %1110, %34
  %1124 = call float @dx.op.tertiary.f32(i32 46, float %1111, float %30, float %1123)  ; FMad(a,b,c)
  %1125 = call float @dx.op.tertiary.f32(i32 46, float %1097, float %26, float %1124)  ; FMad(a,b,c)
  %1126 = fadd fast float %1125, %22
  %1127 = fmul fast float %1110, %33
  %1128 = call float @dx.op.tertiary.f32(i32 46, float %1111, float %29, float %1127)  ; FMad(a,b,c)
  %1129 = call float @dx.op.tertiary.f32(i32 46, float %1097, float %25, float %1128)  ; FMad(a,b,c)
  %1130 = fadd fast float %1129, %21
  %1131 = fdiv fast float %1130, %1115
  %1132 = fdiv fast float %1126, %1115
  %1133 = fdiv fast float %1122, %1115
  %1134 = fsub fast float %1131, %18
  %1135 = fsub fast float %1132, %19
  %1136 = fsub fast float %1133, %20
  %1137 = fmul fast float %1134, %1134
  %1138 = fmul fast float %1135, %1135
  %1139 = fadd fast float %1138, %1137
  %1140 = fmul fast float %1136, %1136
  %1141 = fadd fast float %1139, %1140
  %1142 = call float @dx.op.unary.f32(i32 24, float %1141)  ; Sqrt(value)
  %1143 = fsub fast float %1142, %10
  %1144 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1143)  ; FMax(a,b)
  %1145 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %1145, label %1146, label %1169

; <label>:1146                                    ; preds = %1118
  %1147 = call float @dx.op.unary.f32(i32 6, float %1135)  ; FAbs(value)
  %1148 = fmul fast float %1147, %12
  %1149 = fcmp fast olt float %1148, 0x3F50624DE0000000
  br i1 %1149, label %1150, label %1153

; <label>:1150                                    ; preds = %1146
  %1151 = fmul fast float %1148, 5.000000e-01
  %1152 = fsub fast float 1.000000e+00, %1151
  br label %1158

; <label>:1153                                    ; preds = %1146
  %1154 = fmul fast float %1148, 0xBFF7154760000000
  %1155 = call float @dx.op.unary.f32(i32 21, float %1154)  ; Exp(value)
  %1156 = fsub fast float 1.000000e+00, %1155
  %1157 = fdiv fast float %1156, %1148
  br label %1158

; <label>:1158                                    ; preds = %1153, %1150
  %1159 = phi float [ %1152, %1150 ], [ %1157, %1153 ]
  %1160 = call float @dx.op.binary.f32(i32 36, float %1132, float %19)  ; FMin(a,b)
  %1161 = fsub fast float %1160, %11
  %1162 = fmul fast float %12, %1161
  %1163 = fsub fast float -0.000000e+00, %1162
  %1164 = call float @dx.op.binary.f32(i32 35, float %1163, float -4.000000e+01)  ; FMax(a,b)
  %1165 = call float @dx.op.binary.f32(i32 36, float %1164, float 5.000000e+00)  ; FMin(a,b)
  %1166 = fmul fast float %1165, 0x3FF7154760000000
  %1167 = call float @dx.op.unary.f32(i32 21, float %1166)  ; Exp(value)
  %1168 = fmul fast float %1167, %1159
  br label %1169

; <label>:1169                                    ; preds = %1158, %1118
  %1170 = phi float [ %1168, %1158 ], [ 1.000000e+00, %1118 ]
  %1171 = fmul fast float %1144, %17
  %1172 = fmul fast float %1171, %1170
  %1173 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1172)  ; FMin(a,b)
  %1174 = fmul fast float %1173, 0xBFF7154760000000
  %1175 = call float @dx.op.unary.f32(i32 21, float %1174)  ; Exp(value)
  %1176 = fsub fast float 1.000000e+00, %1175
  %1177 = call float @dx.op.binary.f32(i32 36, float %13, float %1176)  ; FMin(a,b)
  %1178 = fsub fast float %14, %1056
  %1179 = fsub fast float %15, %1057
  %1180 = fsub fast float %16, %1058
  %1181 = fmul fast float %1177, %1178
  %1182 = fmul fast float %1177, %1179
  %1183 = fmul fast float %1177, %1180
  %1184 = fadd fast float %1181, %1056
  %1185 = fadd fast float %1182, %1057
  %1186 = fadd fast float %1183, %1058
  br label %1187

; <label>:1187                                    ; preds = %1169, %1101, %1095
  %1188 = phi float [ %1184, %1169 ], [ %1056, %1101 ], [ %1056, %1095 ]
  %1189 = phi float [ %1185, %1169 ], [ %1057, %1101 ], [ %1057, %1095 ]
  %1190 = phi float [ %1186, %1169 ], [ %1058, %1101 ], [ %1058, %1095 ]
  %1191 = fadd fast float %6, 1.000000e+00
  %1192 = fadd fast float %7, 1.000000e+00
  %1193 = fsub fast float 1.000000e+00, %6
  %1194 = fmul fast float %37, %1191
  %1195 = fmul fast float %37, %1192
  %1196 = fmul fast float %37, %1193
  %1197 = fmul fast float %1194, %1188
  %1198 = fmul fast float %1195, %1189
  %1199 = fmul fast float %1196, %1190
  %1200 = fcmp fast ult float %38, 5.000000e-01
  br i1 %1200, label %1226, label %1201

; <label>:1201                                    ; preds = %1187
  %1202 = fmul fast float %1197, 0x4004147AE0000000
  %1203 = fmul fast float %1198, 0x4004147AE0000000
  %1204 = fmul fast float %1199, 0x4004147AE0000000
  %1205 = fadd fast float %1202, 0x3F9EB851E0000000
  %1206 = fadd fast float %1203, 0x3F9EB851E0000000
  %1207 = fadd fast float %1204, 0x3F9EB851E0000000
  %1208 = fmul fast float %1205, %1197
  %1209 = fmul fast float %1206, %1198
  %1210 = fmul fast float %1207, %1199
  %1211 = fmul fast float %1197, 0x400370A3E0000000
  %1212 = fmul fast float %1198, 0x400370A3E0000000
  %1213 = fmul fast float %1199, 0x400370A3E0000000
  %1214 = fadd fast float %1211, 0x3FE2E147A0000000
  %1215 = fadd fast float %1212, 0x3FE2E147A0000000
  %1216 = fadd fast float %1213, 0x3FE2E147A0000000
  %1217 = fmul fast float %1214, %1197
  %1218 = fmul fast float %1215, %1198
  %1219 = fmul fast float %1216, %1199
  %1220 = fadd fast float %1217, 0x3FC1EB8520000000
  %1221 = fadd fast float %1218, 0x3FC1EB8520000000
  %1222 = fadd fast float %1219, 0x3FC1EB8520000000
  %1223 = fdiv fast float %1208, %1220
  %1224 = fdiv fast float %1209, %1221
  %1225 = fdiv fast float %1210, %1222
  br label %1226

; <label>:1226                                    ; preds = %1201, %1187
  %1227 = phi float [ %1223, %1201 ], [ %1197, %1187 ]
  %1228 = phi float [ %1224, %1201 ], [ %1198, %1187 ]
  %1229 = phi float [ %1225, %1201 ], [ %1199, %1187 ]
  %1230 = call float @dx.op.unary.f32(i32 7, float %1227)  ; Saturate(value)
  %1231 = call float @dx.op.unary.f32(i32 7, float %1228)  ; Saturate(value)
  %1232 = call float @dx.op.unary.f32(i32 7, float %1229)  ; Saturate(value)
  %1233 = call float @dx.op.dot3.f32(i32 55, float %1230, float %1231, float %1232, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1234 = fsub fast float %1230, %1233
  %1235 = fsub fast float %1231, %1233
  %1236 = fsub fast float %1232, %1233
  %1237 = fmul fast float %1234, %9
  %1238 = fmul fast float %1235, %9
  %1239 = fmul fast float %1236, %9
  %1240 = fadd fast float %1237, %1233
  %1241 = fadd fast float %1238, %1233
  %1242 = fadd fast float %1239, %1233
  %1243 = call float @dx.op.unary.f32(i32 7, float %1240)  ; Saturate(value)
  %1244 = call float @dx.op.unary.f32(i32 7, float %1241)  ; Saturate(value)
  %1245 = call float @dx.op.unary.f32(i32 7, float %1242)  ; Saturate(value)
  %1246 = fadd fast float %1243, 0xBFC70A3D80000000
  %1247 = fadd fast float %1244, 0xBFC70A3D80000000
  %1248 = fadd fast float %1245, 0xBFC70A3D80000000
  %1249 = fmul fast float %1246, %8
  %1250 = fmul fast float %1247, %8
  %1251 = fmul fast float %1248, %8
  %1252 = fadd fast float %1249, 0x3FC70A3D80000000
  %1253 = fadd fast float %1250, 0x3FC70A3D80000000
  %1254 = fadd fast float %1251, 0x3FC70A3D80000000
  %1255 = call float @dx.op.unary.f32(i32 7, float %1252)  ; Saturate(value)
  %1256 = call float @dx.op.unary.f32(i32 7, float %1253)  ; Saturate(value)
  %1257 = call float @dx.op.unary.f32(i32 7, float %1254)  ; Saturate(value)
  br label %1258

; <label>:1258                                    ; preds = %1226, %1061
  %1259 = phi float [ %1092, %1061 ], [ %1255, %1226 ]
  %1260 = phi float [ %1093, %1061 ], [ %1256, %1226 ]
  %1261 = phi float [ %1094, %1061 ], [ %1257, %1226 ]
  %1262 = fsub fast float %1259, %395
  %1263 = fsub fast float %1260, %396
  %1264 = fsub fast float %1261, %397
  %1265 = fmul fast float %1262, %1048
  %1266 = fmul fast float %1263, %1048
  %1267 = fmul fast float %1264, %1048
  %1268 = fadd fast float %1265, %395
  %1269 = fadd fast float %1266, %396
  %1270 = fadd fast float %1267, %397
  br label %1271

; <label>:1271                                    ; preds = %1258, %1035
  %1272 = phi float [ %1268, %1258 ], [ %395, %1035 ]
  %1273 = phi float [ %1269, %1258 ], [ %396, %1035 ]
  %1274 = phi float [ %1270, %1258 ], [ %397, %1035 ]
  %1275 = fsub fast float %87, %83
  %1276 = call float @dx.op.unary.f32(i32 6, float %1275)  ; FAbs(value)
  %1277 = fdiv fast float %1276, %1018
  %1278 = fsub fast float 1.000000e+00, %1277
  %1279 = call float @dx.op.unary.f32(i32 7, float %1278)  ; Saturate(value)
  %1280 = fcmp fast ugt float %1279, 0.000000e+00
  br i1 %1280, label %1281, label %1291

; <label>:1281                                    ; preds = %1271
  %1282 = fsub fast float %799, %395
  %1283 = fsub fast float %800, %396
  %1284 = fsub fast float %801, %397
  %1285 = fmul fast float %1279, %1282
  %1286 = fmul fast float %1279, %1283
  %1287 = fmul fast float %1279, %1284
  %1288 = fadd fast float %1285, %395
  %1289 = fadd fast float %1286, %396
  %1290 = fadd fast float %1287, %397
  br label %1291

; <label>:1291                                    ; preds = %1281, %1271
  %1292 = phi float [ %1288, %1281 ], [ %395, %1271 ]
  %1293 = phi float [ %1289, %1281 ], [ %396, %1271 ]
  %1294 = phi float [ %1290, %1281 ], [ %397, %1271 ]
  %1295 = add i32 %57, -1
  %1296 = call i32 @dx.op.binary.i32(i32 37, i32 %1295, i32 0)  ; IMax(a,b)
  %1297 = call i32 @dx.op.binary.i32(i32 38, i32 %1296, i32 %61)  ; IMin(a,b)
  %1298 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %64, i32 %1297, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1299 = extractvalue %dx.types.ResRet.f32 %1298, 0
  %1300 = fsub fast float %1299, %83
  %1301 = call float @dx.op.unary.f32(i32 6, float %1300)  ; FAbs(value)
  %1302 = fdiv fast float %1301, %1018
  %1303 = fsub fast float 1.000000e+00, %1302
  %1304 = call float @dx.op.unary.f32(i32 7, float %1303)  ; Saturate(value)
  %1305 = fcmp fast ugt float %1304, 0.000000e+00
  br i1 %1305, label %1306, label %1527

; <label>:1306                                    ; preds = %1291
  %1307 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %1308 = call i32 @dx.op.binary.i32(i32 37, i32 %1297, i32 0)  ; IMax(a,b)
  %1309 = call i32 @dx.op.binary.i32(i32 38, i32 %1307, i32 %60)  ; IMin(a,b)
  %1310 = call i32 @dx.op.binary.i32(i32 38, i32 %1308, i32 %61)  ; IMin(a,b)
  %1311 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1309, i32 %1310, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1312 = extractvalue %dx.types.ResRet.f32 %1311, 0
  %1313 = extractvalue %dx.types.ResRet.f32 %1311, 1
  %1314 = extractvalue %dx.types.ResRet.f32 %1311, 2
  %1315 = extractvalue %dx.types.ResRet.f32 %1311, 3
  %1316 = fcmp fast olt float %1315, 0.000000e+00
  br i1 %1316, label %1317, label %1351

; <label>:1317                                    ; preds = %1306
  %1318 = fcmp fast ogt float %1312, 0x3FA4B5DCC0000000
  %1319 = fcmp fast ogt float %1313, 0x3FA4B5DCC0000000
  %1320 = fcmp fast ogt float %1314, 0x3FA4B5DCC0000000
  %1321 = select i1 %1318, float 0.000000e+00, float 1.000000e+00
  %1322 = select i1 %1319, float 0.000000e+00, float 1.000000e+00
  %1323 = select i1 %1320, float 0.000000e+00, float 1.000000e+00
  %1324 = fmul fast float %1312, 0x3FB3D07220000000
  %1325 = fmul fast float %1313, 0x3FB3D07220000000
  %1326 = fmul fast float %1314, 0x3FB3D07220000000
  %1327 = fadd fast float %1312, 0x3FAC28F5C0000000
  %1328 = fadd fast float %1313, 0x3FAC28F5C0000000
  %1329 = fadd fast float %1314, 0x3FAC28F5C0000000
  %1330 = fmul fast float %1327, 0x3FEE54EDE0000000
  %1331 = fmul fast float %1328, 0x3FEE54EDE0000000
  %1332 = fmul fast float %1329, 0x3FEE54EDE0000000
  %1333 = call float @dx.op.unary.f32(i32 23, float %1330)  ; Log(value)
  %1334 = call float @dx.op.unary.f32(i32 23, float %1331)  ; Log(value)
  %1335 = call float @dx.op.unary.f32(i32 23, float %1332)  ; Log(value)
  %1336 = fmul fast float %1333, 0x4003333340000000
  %1337 = fmul fast float %1334, 0x4003333340000000
  %1338 = fmul fast float %1335, 0x4003333340000000
  %1339 = call float @dx.op.unary.f32(i32 21, float %1336)  ; Exp(value)
  %1340 = call float @dx.op.unary.f32(i32 21, float %1337)  ; Exp(value)
  %1341 = call float @dx.op.unary.f32(i32 21, float %1338)  ; Exp(value)
  %1342 = fsub fast float %1324, %1339
  %1343 = fsub fast float %1325, %1340
  %1344 = fsub fast float %1326, %1341
  %1345 = fmul fast float %1342, %1321
  %1346 = fmul fast float %1343, %1322
  %1347 = fmul fast float %1344, %1323
  %1348 = fadd fast float %1345, %1339
  %1349 = fadd fast float %1346, %1340
  %1350 = fadd fast float %1347, %1341
  br label %1514

; <label>:1351                                    ; preds = %1306
  %1352 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1309, i32 %1310, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1353 = extractvalue %dx.types.ResRet.f32 %1352, 0
  %1354 = fcmp fast ogt float %39, 5.000000e-01
  %1355 = fcmp fast olt float %1353, 1.000000e+00
  %1356 = and i1 %1354, %1355
  br i1 %1356, label %1357, label %1443

; <label>:1357                                    ; preds = %1351
  %1358 = sitofp i32 %1309 to float
  %1359 = sitofp i32 %1310 to float
  %1360 = fadd fast float %1358, 5.000000e-01
  %1361 = fadd fast float %1359, 5.000000e-01
  %1362 = fdiv fast float %1360, %46
  %1363 = fdiv fast float %1361, %47
  %1364 = fmul fast float %1362, 2.000000e+00
  %1365 = fmul fast float %1363, 2.000000e+00
  %1366 = fadd fast float %1364, -1.000000e+00
  %1367 = fsub fast float 1.000000e+00, %1365
  %1368 = fmul fast float %1366, %36
  %1369 = call float @dx.op.tertiary.f32(i32 46, float %1367, float %32, float %1368)  ; FMad(a,b,c)
  %1370 = call float @dx.op.tertiary.f32(i32 46, float %1353, float %28, float %1369)  ; FMad(a,b,c)
  %1371 = fadd fast float %1370, %24
  %1372 = call float @dx.op.unary.f32(i32 6, float %1371)  ; FAbs(value)
  %1373 = fcmp fast ogt float %1372, 0x3EB0C6F7A0000000
  br i1 %1373, label %1374, label %1443

; <label>:1374                                    ; preds = %1357
  %1375 = fmul fast float %1366, %35
  %1376 = call float @dx.op.tertiary.f32(i32 46, float %1367, float %31, float %1375)  ; FMad(a,b,c)
  %1377 = call float @dx.op.tertiary.f32(i32 46, float %1353, float %27, float %1376)  ; FMad(a,b,c)
  %1378 = fadd fast float %1377, %23
  %1379 = fmul fast float %1366, %34
  %1380 = call float @dx.op.tertiary.f32(i32 46, float %1367, float %30, float %1379)  ; FMad(a,b,c)
  %1381 = call float @dx.op.tertiary.f32(i32 46, float %1353, float %26, float %1380)  ; FMad(a,b,c)
  %1382 = fadd fast float %1381, %22
  %1383 = fmul fast float %1366, %33
  %1384 = call float @dx.op.tertiary.f32(i32 46, float %1367, float %29, float %1383)  ; FMad(a,b,c)
  %1385 = call float @dx.op.tertiary.f32(i32 46, float %1353, float %25, float %1384)  ; FMad(a,b,c)
  %1386 = fadd fast float %1385, %21
  %1387 = fdiv fast float %1386, %1371
  %1388 = fdiv fast float %1382, %1371
  %1389 = fdiv fast float %1378, %1371
  %1390 = fsub fast float %1387, %18
  %1391 = fsub fast float %1388, %19
  %1392 = fsub fast float %1389, %20
  %1393 = fmul fast float %1390, %1390
  %1394 = fmul fast float %1391, %1391
  %1395 = fadd fast float %1394, %1393
  %1396 = fmul fast float %1392, %1392
  %1397 = fadd fast float %1395, %1396
  %1398 = call float @dx.op.unary.f32(i32 24, float %1397)  ; Sqrt(value)
  %1399 = fsub fast float %1398, %10
  %1400 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1399)  ; FMax(a,b)
  %1401 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %1401, label %1402, label %1425

; <label>:1402                                    ; preds = %1374
  %1403 = call float @dx.op.unary.f32(i32 6, float %1391)  ; FAbs(value)
  %1404 = fmul fast float %1403, %12
  %1405 = fcmp fast olt float %1404, 0x3F50624DE0000000
  br i1 %1405, label %1406, label %1409

; <label>:1406                                    ; preds = %1402
  %1407 = fmul fast float %1404, 5.000000e-01
  %1408 = fsub fast float 1.000000e+00, %1407
  br label %1414

; <label>:1409                                    ; preds = %1402
  %1410 = fmul fast float %1404, 0xBFF7154760000000
  %1411 = call float @dx.op.unary.f32(i32 21, float %1410)  ; Exp(value)
  %1412 = fsub fast float 1.000000e+00, %1411
  %1413 = fdiv fast float %1412, %1404
  br label %1414

; <label>:1414                                    ; preds = %1409, %1406
  %1415 = phi float [ %1408, %1406 ], [ %1413, %1409 ]
  %1416 = call float @dx.op.binary.f32(i32 36, float %1388, float %19)  ; FMin(a,b)
  %1417 = fsub fast float %1416, %11
  %1418 = fmul fast float %12, %1417
  %1419 = fsub fast float -0.000000e+00, %1418
  %1420 = call float @dx.op.binary.f32(i32 35, float %1419, float -4.000000e+01)  ; FMax(a,b)
  %1421 = call float @dx.op.binary.f32(i32 36, float %1420, float 5.000000e+00)  ; FMin(a,b)
  %1422 = fmul fast float %1421, 0x3FF7154760000000
  %1423 = call float @dx.op.unary.f32(i32 21, float %1422)  ; Exp(value)
  %1424 = fmul fast float %1423, %1415
  br label %1425

; <label>:1425                                    ; preds = %1414, %1374
  %1426 = phi float [ %1424, %1414 ], [ 1.000000e+00, %1374 ]
  %1427 = fmul fast float %1400, %17
  %1428 = fmul fast float %1427, %1426
  %1429 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1428)  ; FMin(a,b)
  %1430 = fmul fast float %1429, 0xBFF7154760000000
  %1431 = call float @dx.op.unary.f32(i32 21, float %1430)  ; Exp(value)
  %1432 = fsub fast float 1.000000e+00, %1431
  %1433 = call float @dx.op.binary.f32(i32 36, float %13, float %1432)  ; FMin(a,b)
  %1434 = fsub fast float %14, %1312
  %1435 = fsub fast float %15, %1313
  %1436 = fsub fast float %16, %1314
  %1437 = fmul fast float %1433, %1434
  %1438 = fmul fast float %1433, %1435
  %1439 = fmul fast float %1433, %1436
  %1440 = fadd fast float %1437, %1312
  %1441 = fadd fast float %1438, %1313
  %1442 = fadd fast float %1439, %1314
  br label %1443

; <label>:1443                                    ; preds = %1425, %1357, %1351
  %1444 = phi float [ %1440, %1425 ], [ %1312, %1357 ], [ %1312, %1351 ]
  %1445 = phi float [ %1441, %1425 ], [ %1313, %1357 ], [ %1313, %1351 ]
  %1446 = phi float [ %1442, %1425 ], [ %1314, %1357 ], [ %1314, %1351 ]
  %1447 = fadd fast float %6, 1.000000e+00
  %1448 = fadd fast float %7, 1.000000e+00
  %1449 = fsub fast float 1.000000e+00, %6
  %1450 = fmul fast float %37, %1447
  %1451 = fmul fast float %37, %1448
  %1452 = fmul fast float %37, %1449
  %1453 = fmul fast float %1450, %1444
  %1454 = fmul fast float %1451, %1445
  %1455 = fmul fast float %1452, %1446
  %1456 = fcmp fast ult float %38, 5.000000e-01
  br i1 %1456, label %1482, label %1457

; <label>:1457                                    ; preds = %1443
  %1458 = fmul fast float %1453, 0x4004147AE0000000
  %1459 = fmul fast float %1454, 0x4004147AE0000000
  %1460 = fmul fast float %1455, 0x4004147AE0000000
  %1461 = fadd fast float %1458, 0x3F9EB851E0000000
  %1462 = fadd fast float %1459, 0x3F9EB851E0000000
  %1463 = fadd fast float %1460, 0x3F9EB851E0000000
  %1464 = fmul fast float %1461, %1453
  %1465 = fmul fast float %1462, %1454
  %1466 = fmul fast float %1463, %1455
  %1467 = fmul fast float %1453, 0x400370A3E0000000
  %1468 = fmul fast float %1454, 0x400370A3E0000000
  %1469 = fmul fast float %1455, 0x400370A3E0000000
  %1470 = fadd fast float %1467, 0x3FE2E147A0000000
  %1471 = fadd fast float %1468, 0x3FE2E147A0000000
  %1472 = fadd fast float %1469, 0x3FE2E147A0000000
  %1473 = fmul fast float %1470, %1453
  %1474 = fmul fast float %1471, %1454
  %1475 = fmul fast float %1472, %1455
  %1476 = fadd fast float %1473, 0x3FC1EB8520000000
  %1477 = fadd fast float %1474, 0x3FC1EB8520000000
  %1478 = fadd fast float %1475, 0x3FC1EB8520000000
  %1479 = fdiv fast float %1464, %1476
  %1480 = fdiv fast float %1465, %1477
  %1481 = fdiv fast float %1466, %1478
  br label %1482

; <label>:1482                                    ; preds = %1457, %1443
  %1483 = phi float [ %1479, %1457 ], [ %1453, %1443 ]
  %1484 = phi float [ %1480, %1457 ], [ %1454, %1443 ]
  %1485 = phi float [ %1481, %1457 ], [ %1455, %1443 ]
  %1486 = call float @dx.op.unary.f32(i32 7, float %1483)  ; Saturate(value)
  %1487 = call float @dx.op.unary.f32(i32 7, float %1484)  ; Saturate(value)
  %1488 = call float @dx.op.unary.f32(i32 7, float %1485)  ; Saturate(value)
  %1489 = call float @dx.op.dot3.f32(i32 55, float %1486, float %1487, float %1488, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1490 = fsub fast float %1486, %1489
  %1491 = fsub fast float %1487, %1489
  %1492 = fsub fast float %1488, %1489
  %1493 = fmul fast float %1490, %9
  %1494 = fmul fast float %1491, %9
  %1495 = fmul fast float %1492, %9
  %1496 = fadd fast float %1493, %1489
  %1497 = fadd fast float %1494, %1489
  %1498 = fadd fast float %1495, %1489
  %1499 = call float @dx.op.unary.f32(i32 7, float %1496)  ; Saturate(value)
  %1500 = call float @dx.op.unary.f32(i32 7, float %1497)  ; Saturate(value)
  %1501 = call float @dx.op.unary.f32(i32 7, float %1498)  ; Saturate(value)
  %1502 = fadd fast float %1499, 0xBFC70A3D80000000
  %1503 = fadd fast float %1500, 0xBFC70A3D80000000
  %1504 = fadd fast float %1501, 0xBFC70A3D80000000
  %1505 = fmul fast float %1502, %8
  %1506 = fmul fast float %1503, %8
  %1507 = fmul fast float %1504, %8
  %1508 = fadd fast float %1505, 0x3FC70A3D80000000
  %1509 = fadd fast float %1506, 0x3FC70A3D80000000
  %1510 = fadd fast float %1507, 0x3FC70A3D80000000
  %1511 = call float @dx.op.unary.f32(i32 7, float %1508)  ; Saturate(value)
  %1512 = call float @dx.op.unary.f32(i32 7, float %1509)  ; Saturate(value)
  %1513 = call float @dx.op.unary.f32(i32 7, float %1510)  ; Saturate(value)
  br label %1514

; <label>:1514                                    ; preds = %1482, %1317
  %1515 = phi float [ %1348, %1317 ], [ %1511, %1482 ]
  %1516 = phi float [ %1349, %1317 ], [ %1512, %1482 ]
  %1517 = phi float [ %1350, %1317 ], [ %1513, %1482 ]
  %1518 = fsub fast float %1515, %395
  %1519 = fsub fast float %1516, %396
  %1520 = fsub fast float %1517, %397
  %1521 = fmul fast float %1518, %1304
  %1522 = fmul fast float %1519, %1304
  %1523 = fmul fast float %1520, %1304
  %1524 = fadd fast float %1521, %395
  %1525 = fadd fast float %1522, %396
  %1526 = fadd fast float %1523, %397
  br label %1527

; <label>:1527                                    ; preds = %1514, %1291
  %1528 = phi float [ %1524, %1514 ], [ %395, %1291 ]
  %1529 = phi float [ %1525, %1514 ], [ %396, %1291 ]
  %1530 = phi float [ %1526, %1514 ], [ %397, %1291 ]
  %1531 = call float @dx.op.binary.f32(i32 36, float %1272, float %1036)  ; FMin(a,b)
  %1532 = call float @dx.op.binary.f32(i32 36, float %1273, float %1037)  ; FMin(a,b)
  %1533 = call float @dx.op.binary.f32(i32 36, float %1274, float %1038)  ; FMin(a,b)
  %1534 = call float @dx.op.binary.f32(i32 36, float %1528, float %1292)  ; FMin(a,b)
  %1535 = call float @dx.op.binary.f32(i32 36, float %1529, float %1293)  ; FMin(a,b)
  %1536 = call float @dx.op.binary.f32(i32 36, float %1530, float %1294)  ; FMin(a,b)
  %1537 = call float @dx.op.binary.f32(i32 36, float %1534, float %1531)  ; FMin(a,b)
  %1538 = call float @dx.op.binary.f32(i32 36, float %1535, float %1532)  ; FMin(a,b)
  %1539 = call float @dx.op.binary.f32(i32 36, float %1536, float %1533)  ; FMin(a,b)
  %1540 = call float @dx.op.binary.f32(i32 36, float %395, float %1537)  ; FMin(a,b)
  %1541 = call float @dx.op.binary.f32(i32 36, float %396, float %1538)  ; FMin(a,b)
  %1542 = call float @dx.op.binary.f32(i32 36, float %397, float %1539)  ; FMin(a,b)
  %1543 = call float @dx.op.binary.f32(i32 35, float %1272, float %1036)  ; FMax(a,b)
  %1544 = call float @dx.op.binary.f32(i32 35, float %1273, float %1037)  ; FMax(a,b)
  %1545 = call float @dx.op.binary.f32(i32 35, float %1274, float %1038)  ; FMax(a,b)
  %1546 = call float @dx.op.binary.f32(i32 35, float %1528, float %1292)  ; FMax(a,b)
  %1547 = call float @dx.op.binary.f32(i32 35, float %1529, float %1293)  ; FMax(a,b)
  %1548 = call float @dx.op.binary.f32(i32 35, float %1530, float %1294)  ; FMax(a,b)
  %1549 = call float @dx.op.binary.f32(i32 35, float %1546, float %1543)  ; FMax(a,b)
  %1550 = call float @dx.op.binary.f32(i32 35, float %1547, float %1544)  ; FMax(a,b)
  %1551 = call float @dx.op.binary.f32(i32 35, float %1548, float %1545)  ; FMax(a,b)
  %1552 = call float @dx.op.binary.f32(i32 35, float %395, float %1549)  ; FMax(a,b)
  %1553 = call float @dx.op.binary.f32(i32 35, float %396, float %1550)  ; FMax(a,b)
  %1554 = call float @dx.op.binary.f32(i32 35, float %397, float %1551)  ; FMax(a,b)
  %1555 = fsub fast float %1552, %1540
  %1556 = fsub fast float %1553, %1541
  %1557 = fsub fast float %1554, %1542
  %1558 = call float @dx.op.unary.f32(i32 6, float %1555)  ; FAbs(value)
  %1559 = call float @dx.op.unary.f32(i32 6, float %1556)  ; FAbs(value)
  %1560 = call float @dx.op.unary.f32(i32 6, float %1557)  ; FAbs(value)
  %1561 = call float @dx.op.binary.f32(i32 35, float %1559, float %1560)  ; FMax(a,b)
  %1562 = call float @dx.op.binary.f32(i32 35, float %1558, float %1561)  ; FMax(a,b)
  %1563 = call float @dx.op.binary.f32(i32 35, float %1553, float %1554)  ; FMax(a,b)
  %1564 = call float @dx.op.binary.f32(i32 35, float %1552, float %1563)  ; FMax(a,b)
  %1565 = fmul fast float %1564, 1.250000e-01
  %1566 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1565)  ; FMax(a,b)
  %1567 = fcmp fast ogt float %1562, %1566
  br i1 %1567, label %1568, label %1630

; <label>:1568                                    ; preds = %1527
  %1569 = fsub fast float %1528, %1292
  %1570 = fsub fast float %1529, %1293
  %1571 = fsub fast float %1530, %1294
  %1572 = call float @dx.op.unary.f32(i32 6, float %1569)  ; FAbs(value)
  %1573 = call float @dx.op.unary.f32(i32 6, float %1570)  ; FAbs(value)
  %1574 = call float @dx.op.unary.f32(i32 6, float %1571)  ; FAbs(value)
  %1575 = call float @dx.op.binary.f32(i32 35, float %1573, float %1574)  ; FMax(a,b)
  %1576 = call float @dx.op.binary.f32(i32 35, float %1572, float %1575)  ; FMax(a,b)
  %1577 = fsub fast float %1272, %1036
  %1578 = fsub fast float %1273, %1037
  %1579 = fsub fast float %1274, %1038
  %1580 = call float @dx.op.unary.f32(i32 6, float %1577)  ; FAbs(value)
  %1581 = call float @dx.op.unary.f32(i32 6, float %1578)  ; FAbs(value)
  %1582 = call float @dx.op.unary.f32(i32 6, float %1579)  ; FAbs(value)
  %1583 = call float @dx.op.binary.f32(i32 35, float %1581, float %1582)  ; FMax(a,b)
  %1584 = call float @dx.op.binary.f32(i32 35, float %1580, float %1583)  ; FMax(a,b)
  %1585 = fcmp fast olt float %1576, %1584
  %1586 = select i1 %1585, float %1528, float %1272
  %1587 = select i1 %1585, float %1529, float %1273
  %1588 = select i1 %1585, float %1530, float %1274
  %1589 = select i1 %1585, float %1292, float %1036
  %1590 = select i1 %1585, float %1293, float %1037
  %1591 = select i1 %1585, float %1294, float %1038
  %1592 = fsub fast float %395, %1589
  %1593 = fsub fast float %396, %1590
  %1594 = fsub fast float %397, %1591
  %1595 = fsub fast float %395, %1586
  %1596 = fsub fast float %396, %1587
  %1597 = fsub fast float %397, %1588
  %1598 = call float @dx.op.dot3.f32(i32 55, float %1595, float %1596, float %1597, float %1592, float %1593, float %1594)  ; Dot3(ax,ay,az,bx,by,bz)
  %1599 = fcmp fast ogt float %1598, 0.000000e+00
  br i1 %1599, label %1600, label %1611

; <label>:1600                                    ; preds = %1568
  %1601 = fsub fast float %1586, %1589
  %1602 = fsub fast float %1587, %1590
  %1603 = fsub fast float %1588, %1591
  %1604 = call float @dx.op.unary.f32(i32 6, float %1601)  ; FAbs(value)
  %1605 = call float @dx.op.unary.f32(i32 6, float %1602)  ; FAbs(value)
  %1606 = call float @dx.op.unary.f32(i32 6, float %1603)  ; FAbs(value)
  %1607 = call float @dx.op.binary.f32(i32 35, float %1605, float %1606)  ; FMax(a,b)
  %1608 = call float @dx.op.binary.f32(i32 35, float %1604, float %1607)  ; FMax(a,b)
  %1609 = fmul fast float %1562, 2.500000e-01
  %1610 = fcmp fast olt float %1608, %1609
  br label %1611

; <label>:1611                                    ; preds = %1600, %1568
  %1612 = phi i1 [ false, %1568 ], [ %1610, %1600 ]
  %1613 = select i1 %1612, float 5.000000e-01, float 1.000000e+00
  %1614 = fmul fast float %1613, %3
  %1615 = fadd fast float %1586, %1589
  %1616 = fadd fast float %1587, %1590
  %1617 = fadd fast float %1588, %1591
  %1618 = fmul fast float %1615, 5.000000e-01
  %1619 = fmul fast float %1616, 5.000000e-01
  %1620 = fmul fast float %1617, 5.000000e-01
  %1621 = fsub fast float %1618, %395
  %1622 = fsub fast float %1619, %396
  %1623 = fsub fast float %1620, %397
  %1624 = fmul fast float %1614, %1621
  %1625 = fmul fast float %1614, %1622
  %1626 = fmul fast float %1614, %1623
  %1627 = fadd fast float %1624, %395
  %1628 = fadd fast float %1625, %396
  %1629 = fadd fast float %1626, %397
  br label %1630

; <label>:1630                                    ; preds = %1611, %1527, %1013
  %1631 = phi float [ %395, %1013 ], [ %1627, %1611 ], [ %395, %1527 ]
  %1632 = phi float [ %396, %1013 ], [ %1628, %1611 ], [ %396, %1527 ]
  %1633 = phi float [ %397, %1013 ], [ %1629, %1611 ], [ %397, %1527 ]
  %1634 = fcmp fast ult float %185, 0.000000e+00
  br i1 %1634, label %2250, label %1635

; <label>:1635                                    ; preds = %1630
  %1636 = add i32 %56, 2
  %1637 = call i32 @dx.op.binary.i32(i32 37, i32 %1636, i32 0)  ; IMax(a,b)
  %1638 = call i32 @dx.op.binary.i32(i32 38, i32 %1637, i32 %60)  ; IMin(a,b)
  %1639 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1638, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1640 = extractvalue %dx.types.ResRet.f32 %1639, 0
  %1641 = fsub fast float 1.000000e+00, %85
  %1642 = fmul fast float %1641, 0x3FA99999A0000000
  %1643 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %1642)  ; FMax(a,b)
  %1644 = fsub fast float %1640, %85
  %1645 = call float @dx.op.unary.f32(i32 6, float %1644)  ; FAbs(value)
  %1646 = fdiv fast float %1645, %1643
  %1647 = fsub fast float 1.000000e+00, %1646
  %1648 = call float @dx.op.unary.f32(i32 7, float %1647)  ; Saturate(value)
  %1649 = fcmp fast ugt float %1648, 0.000000e+00
  br i1 %1649, label %1650, label %1871

; <label>:1650                                    ; preds = %1635
  %1651 = call i32 @dx.op.binary.i32(i32 37, i32 %1638, i32 0)  ; IMax(a,b)
  %1652 = call i32 @dx.op.binary.i32(i32 37, i32 %65, i32 0)  ; IMax(a,b)
  %1653 = call i32 @dx.op.binary.i32(i32 38, i32 %1651, i32 %60)  ; IMin(a,b)
  %1654 = call i32 @dx.op.binary.i32(i32 38, i32 %1652, i32 %61)  ; IMin(a,b)
  %1655 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1653, i32 %1654, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1656 = extractvalue %dx.types.ResRet.f32 %1655, 0
  %1657 = extractvalue %dx.types.ResRet.f32 %1655, 1
  %1658 = extractvalue %dx.types.ResRet.f32 %1655, 2
  %1659 = extractvalue %dx.types.ResRet.f32 %1655, 3
  %1660 = fcmp fast olt float %1659, 0.000000e+00
  br i1 %1660, label %1661, label %1695

; <label>:1661                                    ; preds = %1650
  %1662 = fcmp fast ogt float %1656, 0x3FA4B5DCC0000000
  %1663 = fcmp fast ogt float %1657, 0x3FA4B5DCC0000000
  %1664 = fcmp fast ogt float %1658, 0x3FA4B5DCC0000000
  %1665 = select i1 %1662, float 0.000000e+00, float 1.000000e+00
  %1666 = select i1 %1663, float 0.000000e+00, float 1.000000e+00
  %1667 = select i1 %1664, float 0.000000e+00, float 1.000000e+00
  %1668 = fmul fast float %1656, 0x3FB3D07220000000
  %1669 = fmul fast float %1657, 0x3FB3D07220000000
  %1670 = fmul fast float %1658, 0x3FB3D07220000000
  %1671 = fadd fast float %1656, 0x3FAC28F5C0000000
  %1672 = fadd fast float %1657, 0x3FAC28F5C0000000
  %1673 = fadd fast float %1658, 0x3FAC28F5C0000000
  %1674 = fmul fast float %1671, 0x3FEE54EDE0000000
  %1675 = fmul fast float %1672, 0x3FEE54EDE0000000
  %1676 = fmul fast float %1673, 0x3FEE54EDE0000000
  %1677 = call float @dx.op.unary.f32(i32 23, float %1674)  ; Log(value)
  %1678 = call float @dx.op.unary.f32(i32 23, float %1675)  ; Log(value)
  %1679 = call float @dx.op.unary.f32(i32 23, float %1676)  ; Log(value)
  %1680 = fmul fast float %1677, 0x4003333340000000
  %1681 = fmul fast float %1678, 0x4003333340000000
  %1682 = fmul fast float %1679, 0x4003333340000000
  %1683 = call float @dx.op.unary.f32(i32 21, float %1680)  ; Exp(value)
  %1684 = call float @dx.op.unary.f32(i32 21, float %1681)  ; Exp(value)
  %1685 = call float @dx.op.unary.f32(i32 21, float %1682)  ; Exp(value)
  %1686 = fsub fast float %1668, %1683
  %1687 = fsub fast float %1669, %1684
  %1688 = fsub fast float %1670, %1685
  %1689 = fmul fast float %1686, %1665
  %1690 = fmul fast float %1687, %1666
  %1691 = fmul fast float %1688, %1667
  %1692 = fadd fast float %1689, %1683
  %1693 = fadd fast float %1690, %1684
  %1694 = fadd fast float %1691, %1685
  br label %1858

; <label>:1695                                    ; preds = %1650
  %1696 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1653, i32 %1654, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1697 = extractvalue %dx.types.ResRet.f32 %1696, 0
  %1698 = fcmp fast ogt float %39, 5.000000e-01
  %1699 = fcmp fast olt float %1697, 1.000000e+00
  %1700 = and i1 %1698, %1699
  br i1 %1700, label %1701, label %1787

; <label>:1701                                    ; preds = %1695
  %1702 = sitofp i32 %1653 to float
  %1703 = sitofp i32 %1654 to float
  %1704 = fadd fast float %1702, 5.000000e-01
  %1705 = fadd fast float %1703, 5.000000e-01
  %1706 = fdiv fast float %1704, %46
  %1707 = fdiv fast float %1705, %47
  %1708 = fmul fast float %1706, 2.000000e+00
  %1709 = fmul fast float %1707, 2.000000e+00
  %1710 = fadd fast float %1708, -1.000000e+00
  %1711 = fsub fast float 1.000000e+00, %1709
  %1712 = fmul fast float %1710, %36
  %1713 = call float @dx.op.tertiary.f32(i32 46, float %1711, float %32, float %1712)  ; FMad(a,b,c)
  %1714 = call float @dx.op.tertiary.f32(i32 46, float %1697, float %28, float %1713)  ; FMad(a,b,c)
  %1715 = fadd fast float %1714, %24
  %1716 = call float @dx.op.unary.f32(i32 6, float %1715)  ; FAbs(value)
  %1717 = fcmp fast ogt float %1716, 0x3EB0C6F7A0000000
  br i1 %1717, label %1718, label %1787

; <label>:1718                                    ; preds = %1701
  %1719 = fmul fast float %1710, %35
  %1720 = call float @dx.op.tertiary.f32(i32 46, float %1711, float %31, float %1719)  ; FMad(a,b,c)
  %1721 = call float @dx.op.tertiary.f32(i32 46, float %1697, float %27, float %1720)  ; FMad(a,b,c)
  %1722 = fadd fast float %1721, %23
  %1723 = fmul fast float %1710, %34
  %1724 = call float @dx.op.tertiary.f32(i32 46, float %1711, float %30, float %1723)  ; FMad(a,b,c)
  %1725 = call float @dx.op.tertiary.f32(i32 46, float %1697, float %26, float %1724)  ; FMad(a,b,c)
  %1726 = fadd fast float %1725, %22
  %1727 = fmul fast float %1710, %33
  %1728 = call float @dx.op.tertiary.f32(i32 46, float %1711, float %29, float %1727)  ; FMad(a,b,c)
  %1729 = call float @dx.op.tertiary.f32(i32 46, float %1697, float %25, float %1728)  ; FMad(a,b,c)
  %1730 = fadd fast float %1729, %21
  %1731 = fdiv fast float %1730, %1715
  %1732 = fdiv fast float %1726, %1715
  %1733 = fdiv fast float %1722, %1715
  %1734 = fsub fast float %1731, %18
  %1735 = fsub fast float %1732, %19
  %1736 = fsub fast float %1733, %20
  %1737 = fmul fast float %1734, %1734
  %1738 = fmul fast float %1735, %1735
  %1739 = fadd fast float %1738, %1737
  %1740 = fmul fast float %1736, %1736
  %1741 = fadd fast float %1739, %1740
  %1742 = call float @dx.op.unary.f32(i32 24, float %1741)  ; Sqrt(value)
  %1743 = fsub fast float %1742, %10
  %1744 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1743)  ; FMax(a,b)
  %1745 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %1745, label %1746, label %1769

; <label>:1746                                    ; preds = %1718
  %1747 = call float @dx.op.unary.f32(i32 6, float %1735)  ; FAbs(value)
  %1748 = fmul fast float %1747, %12
  %1749 = fcmp fast olt float %1748, 0x3F50624DE0000000
  br i1 %1749, label %1750, label %1753

; <label>:1750                                    ; preds = %1746
  %1751 = fmul fast float %1748, 5.000000e-01
  %1752 = fsub fast float 1.000000e+00, %1751
  br label %1758

; <label>:1753                                    ; preds = %1746
  %1754 = fmul fast float %1748, 0xBFF7154760000000
  %1755 = call float @dx.op.unary.f32(i32 21, float %1754)  ; Exp(value)
  %1756 = fsub fast float 1.000000e+00, %1755
  %1757 = fdiv fast float %1756, %1748
  br label %1758

; <label>:1758                                    ; preds = %1753, %1750
  %1759 = phi float [ %1752, %1750 ], [ %1757, %1753 ]
  %1760 = call float @dx.op.binary.f32(i32 36, float %1732, float %19)  ; FMin(a,b)
  %1761 = fsub fast float %1760, %11
  %1762 = fmul fast float %12, %1761
  %1763 = fsub fast float -0.000000e+00, %1762
  %1764 = call float @dx.op.binary.f32(i32 35, float %1763, float -4.000000e+01)  ; FMax(a,b)
  %1765 = call float @dx.op.binary.f32(i32 36, float %1764, float 5.000000e+00)  ; FMin(a,b)
  %1766 = fmul fast float %1765, 0x3FF7154760000000
  %1767 = call float @dx.op.unary.f32(i32 21, float %1766)  ; Exp(value)
  %1768 = fmul fast float %1767, %1759
  br label %1769

; <label>:1769                                    ; preds = %1758, %1718
  %1770 = phi float [ %1768, %1758 ], [ 1.000000e+00, %1718 ]
  %1771 = fmul fast float %1744, %17
  %1772 = fmul fast float %1771, %1770
  %1773 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1772)  ; FMin(a,b)
  %1774 = fmul fast float %1773, 0xBFF7154760000000
  %1775 = call float @dx.op.unary.f32(i32 21, float %1774)  ; Exp(value)
  %1776 = fsub fast float 1.000000e+00, %1775
  %1777 = call float @dx.op.binary.f32(i32 36, float %13, float %1776)  ; FMin(a,b)
  %1778 = fsub fast float %14, %1656
  %1779 = fsub fast float %15, %1657
  %1780 = fsub fast float %16, %1658
  %1781 = fmul fast float %1777, %1778
  %1782 = fmul fast float %1777, %1779
  %1783 = fmul fast float %1777, %1780
  %1784 = fadd fast float %1781, %1656
  %1785 = fadd fast float %1782, %1657
  %1786 = fadd fast float %1783, %1658
  br label %1787

; <label>:1787                                    ; preds = %1769, %1701, %1695
  %1788 = phi float [ %1784, %1769 ], [ %1656, %1701 ], [ %1656, %1695 ]
  %1789 = phi float [ %1785, %1769 ], [ %1657, %1701 ], [ %1657, %1695 ]
  %1790 = phi float [ %1786, %1769 ], [ %1658, %1701 ], [ %1658, %1695 ]
  %1791 = fadd fast float %6, 1.000000e+00
  %1792 = fadd fast float %7, 1.000000e+00
  %1793 = fsub fast float 1.000000e+00, %6
  %1794 = fmul fast float %37, %1791
  %1795 = fmul fast float %37, %1792
  %1796 = fmul fast float %37, %1793
  %1797 = fmul fast float %1794, %1788
  %1798 = fmul fast float %1795, %1789
  %1799 = fmul fast float %1796, %1790
  %1800 = fcmp fast ult float %38, 5.000000e-01
  br i1 %1800, label %1826, label %1801

; <label>:1801                                    ; preds = %1787
  %1802 = fmul fast float %1797, 0x4004147AE0000000
  %1803 = fmul fast float %1798, 0x4004147AE0000000
  %1804 = fmul fast float %1799, 0x4004147AE0000000
  %1805 = fadd fast float %1802, 0x3F9EB851E0000000
  %1806 = fadd fast float %1803, 0x3F9EB851E0000000
  %1807 = fadd fast float %1804, 0x3F9EB851E0000000
  %1808 = fmul fast float %1805, %1797
  %1809 = fmul fast float %1806, %1798
  %1810 = fmul fast float %1807, %1799
  %1811 = fmul fast float %1797, 0x400370A3E0000000
  %1812 = fmul fast float %1798, 0x400370A3E0000000
  %1813 = fmul fast float %1799, 0x400370A3E0000000
  %1814 = fadd fast float %1811, 0x3FE2E147A0000000
  %1815 = fadd fast float %1812, 0x3FE2E147A0000000
  %1816 = fadd fast float %1813, 0x3FE2E147A0000000
  %1817 = fmul fast float %1814, %1797
  %1818 = fmul fast float %1815, %1798
  %1819 = fmul fast float %1816, %1799
  %1820 = fadd fast float %1817, 0x3FC1EB8520000000
  %1821 = fadd fast float %1818, 0x3FC1EB8520000000
  %1822 = fadd fast float %1819, 0x3FC1EB8520000000
  %1823 = fdiv fast float %1808, %1820
  %1824 = fdiv fast float %1809, %1821
  %1825 = fdiv fast float %1810, %1822
  br label %1826

; <label>:1826                                    ; preds = %1801, %1787
  %1827 = phi float [ %1823, %1801 ], [ %1797, %1787 ]
  %1828 = phi float [ %1824, %1801 ], [ %1798, %1787 ]
  %1829 = phi float [ %1825, %1801 ], [ %1799, %1787 ]
  %1830 = call float @dx.op.unary.f32(i32 7, float %1827)  ; Saturate(value)
  %1831 = call float @dx.op.unary.f32(i32 7, float %1828)  ; Saturate(value)
  %1832 = call float @dx.op.unary.f32(i32 7, float %1829)  ; Saturate(value)
  %1833 = call float @dx.op.dot3.f32(i32 55, float %1830, float %1831, float %1832, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1834 = fsub fast float %1830, %1833
  %1835 = fsub fast float %1831, %1833
  %1836 = fsub fast float %1832, %1833
  %1837 = fmul fast float %1834, %9
  %1838 = fmul fast float %1835, %9
  %1839 = fmul fast float %1836, %9
  %1840 = fadd fast float %1837, %1833
  %1841 = fadd fast float %1838, %1833
  %1842 = fadd fast float %1839, %1833
  %1843 = call float @dx.op.unary.f32(i32 7, float %1840)  ; Saturate(value)
  %1844 = call float @dx.op.unary.f32(i32 7, float %1841)  ; Saturate(value)
  %1845 = call float @dx.op.unary.f32(i32 7, float %1842)  ; Saturate(value)
  %1846 = fadd fast float %1843, 0xBFC70A3D80000000
  %1847 = fadd fast float %1844, 0xBFC70A3D80000000
  %1848 = fadd fast float %1845, 0xBFC70A3D80000000
  %1849 = fmul fast float %1846, %8
  %1850 = fmul fast float %1847, %8
  %1851 = fmul fast float %1848, %8
  %1852 = fadd fast float %1849, 0x3FC70A3D80000000
  %1853 = fadd fast float %1850, 0x3FC70A3D80000000
  %1854 = fadd fast float %1851, 0x3FC70A3D80000000
  %1855 = call float @dx.op.unary.f32(i32 7, float %1852)  ; Saturate(value)
  %1856 = call float @dx.op.unary.f32(i32 7, float %1853)  ; Saturate(value)
  %1857 = call float @dx.op.unary.f32(i32 7, float %1854)  ; Saturate(value)
  br label %1858

; <label>:1858                                    ; preds = %1826, %1661
  %1859 = phi float [ %1692, %1661 ], [ %1855, %1826 ]
  %1860 = phi float [ %1693, %1661 ], [ %1856, %1826 ]
  %1861 = phi float [ %1694, %1661 ], [ %1857, %1826 ]
  %1862 = fsub fast float %1859, %597
  %1863 = fsub fast float %1860, %598
  %1864 = fsub fast float %1861, %599
  %1865 = fmul fast float %1862, %1648
  %1866 = fmul fast float %1863, %1648
  %1867 = fmul fast float %1864, %1648
  %1868 = fadd fast float %1865, %597
  %1869 = fadd fast float %1866, %598
  %1870 = fadd fast float %1867, %599
  br label %1871

; <label>:1871                                    ; preds = %1858, %1635
  %1872 = phi float [ %1868, %1858 ], [ %597, %1635 ]
  %1873 = phi float [ %1869, %1858 ], [ %598, %1635 ]
  %1874 = phi float [ %1870, %1858 ], [ %599, %1635 ]
  %1875 = fsub fast float %83, %85
  %1876 = call float @dx.op.unary.f32(i32 6, float %1875)  ; FAbs(value)
  %1877 = fdiv fast float %1876, %1643
  %1878 = fsub fast float 1.000000e+00, %1877
  %1879 = call float @dx.op.unary.f32(i32 7, float %1878)  ; Saturate(value)
  %1880 = fcmp fast ugt float %1879, 0.000000e+00
  br i1 %1880, label %1881, label %1891

; <label>:1881                                    ; preds = %1871
  %1882 = fsub fast float %395, %597
  %1883 = fsub fast float %396, %598
  %1884 = fsub fast float %397, %599
  %1885 = fmul fast float %1879, %1882
  %1886 = fmul fast float %1879, %1883
  %1887 = fmul fast float %1879, %1884
  %1888 = fadd fast float %1885, %597
  %1889 = fadd fast float %1886, %598
  %1890 = fadd fast float %1887, %599
  br label %1891

; <label>:1891                                    ; preds = %1881, %1871
  %1892 = phi float [ %1888, %1881 ], [ %597, %1871 ]
  %1893 = phi float [ %1889, %1881 ], [ %598, %1871 ]
  %1894 = phi float [ %1890, %1881 ], [ %599, %1871 ]
  %1895 = fsub fast float %89, %85
  %1896 = call float @dx.op.unary.f32(i32 6, float %1895)  ; FAbs(value)
  %1897 = fdiv fast float %1896, %1643
  %1898 = fsub fast float 1.000000e+00, %1897
  %1899 = call float @dx.op.unary.f32(i32 7, float %1898)  ; Saturate(value)
  %1900 = fcmp fast ugt float %1899, 0.000000e+00
  br i1 %1900, label %1901, label %1911

; <label>:1901                                    ; preds = %1891
  %1902 = fsub fast float %1001, %597
  %1903 = fsub fast float %1002, %598
  %1904 = fsub fast float %1003, %599
  %1905 = fmul fast float %1899, %1902
  %1906 = fmul fast float %1899, %1903
  %1907 = fmul fast float %1899, %1904
  %1908 = fadd fast float %1905, %597
  %1909 = fadd fast float %1906, %598
  %1910 = fadd fast float %1907, %599
  br label %1911

; <label>:1911                                    ; preds = %1901, %1891
  %1912 = phi float [ %1908, %1901 ], [ %597, %1891 ]
  %1913 = phi float [ %1909, %1901 ], [ %598, %1891 ]
  %1914 = phi float [ %1910, %1901 ], [ %599, %1891 ]
  %1915 = add i32 %57, -1
  %1916 = call i32 @dx.op.binary.i32(i32 37, i32 %1915, i32 0)  ; IMax(a,b)
  %1917 = call i32 @dx.op.binary.i32(i32 38, i32 %1916, i32 %61)  ; IMin(a,b)
  %1918 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %68, i32 %1917, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1919 = extractvalue %dx.types.ResRet.f32 %1918, 0
  %1920 = fsub fast float %1919, %85
  %1921 = call float @dx.op.unary.f32(i32 6, float %1920)  ; FAbs(value)
  %1922 = fdiv fast float %1921, %1643
  %1923 = fsub fast float 1.000000e+00, %1922
  %1924 = call float @dx.op.unary.f32(i32 7, float %1923)  ; Saturate(value)
  %1925 = fcmp fast ugt float %1924, 0.000000e+00
  br i1 %1925, label %1926, label %2147

; <label>:1926                                    ; preds = %1911
  %1927 = call i32 @dx.op.binary.i32(i32 37, i32 %68, i32 0)  ; IMax(a,b)
  %1928 = call i32 @dx.op.binary.i32(i32 37, i32 %1917, i32 0)  ; IMax(a,b)
  %1929 = call i32 @dx.op.binary.i32(i32 38, i32 %1927, i32 %60)  ; IMin(a,b)
  %1930 = call i32 @dx.op.binary.i32(i32 38, i32 %1928, i32 %61)  ; IMin(a,b)
  %1931 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1929, i32 %1930, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1932 = extractvalue %dx.types.ResRet.f32 %1931, 0
  %1933 = extractvalue %dx.types.ResRet.f32 %1931, 1
  %1934 = extractvalue %dx.types.ResRet.f32 %1931, 2
  %1935 = extractvalue %dx.types.ResRet.f32 %1931, 3
  %1936 = fcmp fast olt float %1935, 0.000000e+00
  br i1 %1936, label %1937, label %1971

; <label>:1937                                    ; preds = %1926
  %1938 = fcmp fast ogt float %1932, 0x3FA4B5DCC0000000
  %1939 = fcmp fast ogt float %1933, 0x3FA4B5DCC0000000
  %1940 = fcmp fast ogt float %1934, 0x3FA4B5DCC0000000
  %1941 = select i1 %1938, float 0.000000e+00, float 1.000000e+00
  %1942 = select i1 %1939, float 0.000000e+00, float 1.000000e+00
  %1943 = select i1 %1940, float 0.000000e+00, float 1.000000e+00
  %1944 = fmul fast float %1932, 0x3FB3D07220000000
  %1945 = fmul fast float %1933, 0x3FB3D07220000000
  %1946 = fmul fast float %1934, 0x3FB3D07220000000
  %1947 = fadd fast float %1932, 0x3FAC28F5C0000000
  %1948 = fadd fast float %1933, 0x3FAC28F5C0000000
  %1949 = fadd fast float %1934, 0x3FAC28F5C0000000
  %1950 = fmul fast float %1947, 0x3FEE54EDE0000000
  %1951 = fmul fast float %1948, 0x3FEE54EDE0000000
  %1952 = fmul fast float %1949, 0x3FEE54EDE0000000
  %1953 = call float @dx.op.unary.f32(i32 23, float %1950)  ; Log(value)
  %1954 = call float @dx.op.unary.f32(i32 23, float %1951)  ; Log(value)
  %1955 = call float @dx.op.unary.f32(i32 23, float %1952)  ; Log(value)
  %1956 = fmul fast float %1953, 0x4003333340000000
  %1957 = fmul fast float %1954, 0x4003333340000000
  %1958 = fmul fast float %1955, 0x4003333340000000
  %1959 = call float @dx.op.unary.f32(i32 21, float %1956)  ; Exp(value)
  %1960 = call float @dx.op.unary.f32(i32 21, float %1957)  ; Exp(value)
  %1961 = call float @dx.op.unary.f32(i32 21, float %1958)  ; Exp(value)
  %1962 = fsub fast float %1944, %1959
  %1963 = fsub fast float %1945, %1960
  %1964 = fsub fast float %1946, %1961
  %1965 = fmul fast float %1962, %1941
  %1966 = fmul fast float %1963, %1942
  %1967 = fmul fast float %1964, %1943
  %1968 = fadd fast float %1965, %1959
  %1969 = fadd fast float %1966, %1960
  %1970 = fadd fast float %1967, %1961
  br label %2134

; <label>:1971                                    ; preds = %1926
  %1972 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1929, i32 %1930, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1973 = extractvalue %dx.types.ResRet.f32 %1972, 0
  %1974 = fcmp fast ogt float %39, 5.000000e-01
  %1975 = fcmp fast olt float %1973, 1.000000e+00
  %1976 = and i1 %1974, %1975
  br i1 %1976, label %1977, label %2063

; <label>:1977                                    ; preds = %1971
  %1978 = sitofp i32 %1929 to float
  %1979 = sitofp i32 %1930 to float
  %1980 = fadd fast float %1978, 5.000000e-01
  %1981 = fadd fast float %1979, 5.000000e-01
  %1982 = fdiv fast float %1980, %46
  %1983 = fdiv fast float %1981, %47
  %1984 = fmul fast float %1982, 2.000000e+00
  %1985 = fmul fast float %1983, 2.000000e+00
  %1986 = fadd fast float %1984, -1.000000e+00
  %1987 = fsub fast float 1.000000e+00, %1985
  %1988 = fmul fast float %1986, %36
  %1989 = call float @dx.op.tertiary.f32(i32 46, float %1987, float %32, float %1988)  ; FMad(a,b,c)
  %1990 = call float @dx.op.tertiary.f32(i32 46, float %1973, float %28, float %1989)  ; FMad(a,b,c)
  %1991 = fadd fast float %1990, %24
  %1992 = call float @dx.op.unary.f32(i32 6, float %1991)  ; FAbs(value)
  %1993 = fcmp fast ogt float %1992, 0x3EB0C6F7A0000000
  br i1 %1993, label %1994, label %2063

; <label>:1994                                    ; preds = %1977
  %1995 = fmul fast float %1986, %35
  %1996 = call float @dx.op.tertiary.f32(i32 46, float %1987, float %31, float %1995)  ; FMad(a,b,c)
  %1997 = call float @dx.op.tertiary.f32(i32 46, float %1973, float %27, float %1996)  ; FMad(a,b,c)
  %1998 = fadd fast float %1997, %23
  %1999 = fmul fast float %1986, %34
  %2000 = call float @dx.op.tertiary.f32(i32 46, float %1987, float %30, float %1999)  ; FMad(a,b,c)
  %2001 = call float @dx.op.tertiary.f32(i32 46, float %1973, float %26, float %2000)  ; FMad(a,b,c)
  %2002 = fadd fast float %2001, %22
  %2003 = fmul fast float %1986, %33
  %2004 = call float @dx.op.tertiary.f32(i32 46, float %1987, float %29, float %2003)  ; FMad(a,b,c)
  %2005 = call float @dx.op.tertiary.f32(i32 46, float %1973, float %25, float %2004)  ; FMad(a,b,c)
  %2006 = fadd fast float %2005, %21
  %2007 = fdiv fast float %2006, %1991
  %2008 = fdiv fast float %2002, %1991
  %2009 = fdiv fast float %1998, %1991
  %2010 = fsub fast float %2007, %18
  %2011 = fsub fast float %2008, %19
  %2012 = fsub fast float %2009, %20
  %2013 = fmul fast float %2010, %2010
  %2014 = fmul fast float %2011, %2011
  %2015 = fadd fast float %2014, %2013
  %2016 = fmul fast float %2012, %2012
  %2017 = fadd fast float %2015, %2016
  %2018 = call float @dx.op.unary.f32(i32 24, float %2017)  ; Sqrt(value)
  %2019 = fsub fast float %2018, %10
  %2020 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2019)  ; FMax(a,b)
  %2021 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %2021, label %2022, label %2045

; <label>:2022                                    ; preds = %1994
  %2023 = call float @dx.op.unary.f32(i32 6, float %2011)  ; FAbs(value)
  %2024 = fmul fast float %2023, %12
  %2025 = fcmp fast olt float %2024, 0x3F50624DE0000000
  br i1 %2025, label %2026, label %2029

; <label>:2026                                    ; preds = %2022
  %2027 = fmul fast float %2024, 5.000000e-01
  %2028 = fsub fast float 1.000000e+00, %2027
  br label %2034

; <label>:2029                                    ; preds = %2022
  %2030 = fmul fast float %2024, 0xBFF7154760000000
  %2031 = call float @dx.op.unary.f32(i32 21, float %2030)  ; Exp(value)
  %2032 = fsub fast float 1.000000e+00, %2031
  %2033 = fdiv fast float %2032, %2024
  br label %2034

; <label>:2034                                    ; preds = %2029, %2026
  %2035 = phi float [ %2028, %2026 ], [ %2033, %2029 ]
  %2036 = call float @dx.op.binary.f32(i32 36, float %2008, float %19)  ; FMin(a,b)
  %2037 = fsub fast float %2036, %11
  %2038 = fmul fast float %12, %2037
  %2039 = fsub fast float -0.000000e+00, %2038
  %2040 = call float @dx.op.binary.f32(i32 35, float %2039, float -4.000000e+01)  ; FMax(a,b)
  %2041 = call float @dx.op.binary.f32(i32 36, float %2040, float 5.000000e+00)  ; FMin(a,b)
  %2042 = fmul fast float %2041, 0x3FF7154760000000
  %2043 = call float @dx.op.unary.f32(i32 21, float %2042)  ; Exp(value)
  %2044 = fmul fast float %2043, %2035
  br label %2045

; <label>:2045                                    ; preds = %2034, %1994
  %2046 = phi float [ %2044, %2034 ], [ 1.000000e+00, %1994 ]
  %2047 = fmul fast float %2020, %17
  %2048 = fmul fast float %2047, %2046
  %2049 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2048)  ; FMin(a,b)
  %2050 = fmul fast float %2049, 0xBFF7154760000000
  %2051 = call float @dx.op.unary.f32(i32 21, float %2050)  ; Exp(value)
  %2052 = fsub fast float 1.000000e+00, %2051
  %2053 = call float @dx.op.binary.f32(i32 36, float %13, float %2052)  ; FMin(a,b)
  %2054 = fsub fast float %14, %1932
  %2055 = fsub fast float %15, %1933
  %2056 = fsub fast float %16, %1934
  %2057 = fmul fast float %2053, %2054
  %2058 = fmul fast float %2053, %2055
  %2059 = fmul fast float %2053, %2056
  %2060 = fadd fast float %2057, %1932
  %2061 = fadd fast float %2058, %1933
  %2062 = fadd fast float %2059, %1934
  br label %2063

; <label>:2063                                    ; preds = %2045, %1977, %1971
  %2064 = phi float [ %2060, %2045 ], [ %1932, %1977 ], [ %1932, %1971 ]
  %2065 = phi float [ %2061, %2045 ], [ %1933, %1977 ], [ %1933, %1971 ]
  %2066 = phi float [ %2062, %2045 ], [ %1934, %1977 ], [ %1934, %1971 ]
  %2067 = fadd fast float %6, 1.000000e+00
  %2068 = fadd fast float %7, 1.000000e+00
  %2069 = fsub fast float 1.000000e+00, %6
  %2070 = fmul fast float %37, %2067
  %2071 = fmul fast float %37, %2068
  %2072 = fmul fast float %37, %2069
  %2073 = fmul fast float %2070, %2064
  %2074 = fmul fast float %2071, %2065
  %2075 = fmul fast float %2072, %2066
  %2076 = fcmp fast ult float %38, 5.000000e-01
  br i1 %2076, label %2102, label %2077

; <label>:2077                                    ; preds = %2063
  %2078 = fmul fast float %2073, 0x4004147AE0000000
  %2079 = fmul fast float %2074, 0x4004147AE0000000
  %2080 = fmul fast float %2075, 0x4004147AE0000000
  %2081 = fadd fast float %2078, 0x3F9EB851E0000000
  %2082 = fadd fast float %2079, 0x3F9EB851E0000000
  %2083 = fadd fast float %2080, 0x3F9EB851E0000000
  %2084 = fmul fast float %2081, %2073
  %2085 = fmul fast float %2082, %2074
  %2086 = fmul fast float %2083, %2075
  %2087 = fmul fast float %2073, 0x400370A3E0000000
  %2088 = fmul fast float %2074, 0x400370A3E0000000
  %2089 = fmul fast float %2075, 0x400370A3E0000000
  %2090 = fadd fast float %2087, 0x3FE2E147A0000000
  %2091 = fadd fast float %2088, 0x3FE2E147A0000000
  %2092 = fadd fast float %2089, 0x3FE2E147A0000000
  %2093 = fmul fast float %2090, %2073
  %2094 = fmul fast float %2091, %2074
  %2095 = fmul fast float %2092, %2075
  %2096 = fadd fast float %2093, 0x3FC1EB8520000000
  %2097 = fadd fast float %2094, 0x3FC1EB8520000000
  %2098 = fadd fast float %2095, 0x3FC1EB8520000000
  %2099 = fdiv fast float %2084, %2096
  %2100 = fdiv fast float %2085, %2097
  %2101 = fdiv fast float %2086, %2098
  br label %2102

; <label>:2102                                    ; preds = %2077, %2063
  %2103 = phi float [ %2099, %2077 ], [ %2073, %2063 ]
  %2104 = phi float [ %2100, %2077 ], [ %2074, %2063 ]
  %2105 = phi float [ %2101, %2077 ], [ %2075, %2063 ]
  %2106 = call float @dx.op.unary.f32(i32 7, float %2103)  ; Saturate(value)
  %2107 = call float @dx.op.unary.f32(i32 7, float %2104)  ; Saturate(value)
  %2108 = call float @dx.op.unary.f32(i32 7, float %2105)  ; Saturate(value)
  %2109 = call float @dx.op.dot3.f32(i32 55, float %2106, float %2107, float %2108, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2110 = fsub fast float %2106, %2109
  %2111 = fsub fast float %2107, %2109
  %2112 = fsub fast float %2108, %2109
  %2113 = fmul fast float %2110, %9
  %2114 = fmul fast float %2111, %9
  %2115 = fmul fast float %2112, %9
  %2116 = fadd fast float %2113, %2109
  %2117 = fadd fast float %2114, %2109
  %2118 = fadd fast float %2115, %2109
  %2119 = call float @dx.op.unary.f32(i32 7, float %2116)  ; Saturate(value)
  %2120 = call float @dx.op.unary.f32(i32 7, float %2117)  ; Saturate(value)
  %2121 = call float @dx.op.unary.f32(i32 7, float %2118)  ; Saturate(value)
  %2122 = fadd fast float %2119, 0xBFC70A3D80000000
  %2123 = fadd fast float %2120, 0xBFC70A3D80000000
  %2124 = fadd fast float %2121, 0xBFC70A3D80000000
  %2125 = fmul fast float %2122, %8
  %2126 = fmul fast float %2123, %8
  %2127 = fmul fast float %2124, %8
  %2128 = fadd fast float %2125, 0x3FC70A3D80000000
  %2129 = fadd fast float %2126, 0x3FC70A3D80000000
  %2130 = fadd fast float %2127, 0x3FC70A3D80000000
  %2131 = call float @dx.op.unary.f32(i32 7, float %2128)  ; Saturate(value)
  %2132 = call float @dx.op.unary.f32(i32 7, float %2129)  ; Saturate(value)
  %2133 = call float @dx.op.unary.f32(i32 7, float %2130)  ; Saturate(value)
  br label %2134

; <label>:2134                                    ; preds = %2102, %1937
  %2135 = phi float [ %1968, %1937 ], [ %2131, %2102 ]
  %2136 = phi float [ %1969, %1937 ], [ %2132, %2102 ]
  %2137 = phi float [ %1970, %1937 ], [ %2133, %2102 ]
  %2138 = fsub fast float %2135, %597
  %2139 = fsub fast float %2136, %598
  %2140 = fsub fast float %2137, %599
  %2141 = fmul fast float %2138, %1924
  %2142 = fmul fast float %2139, %1924
  %2143 = fmul fast float %2140, %1924
  %2144 = fadd fast float %2141, %597
  %2145 = fadd fast float %2142, %598
  %2146 = fadd fast float %2143, %599
  br label %2147

; <label>:2147                                    ; preds = %2134, %1911
  %2148 = phi float [ %2144, %2134 ], [ %597, %1911 ]
  %2149 = phi float [ %2145, %2134 ], [ %598, %1911 ]
  %2150 = phi float [ %2146, %2134 ], [ %599, %1911 ]
  %2151 = call float @dx.op.binary.f32(i32 36, float %1892, float %1872)  ; FMin(a,b)
  %2152 = call float @dx.op.binary.f32(i32 36, float %1893, float %1873)  ; FMin(a,b)
  %2153 = call float @dx.op.binary.f32(i32 36, float %1894, float %1874)  ; FMin(a,b)
  %2154 = call float @dx.op.binary.f32(i32 36, float %2148, float %1912)  ; FMin(a,b)
  %2155 = call float @dx.op.binary.f32(i32 36, float %2149, float %1913)  ; FMin(a,b)
  %2156 = call float @dx.op.binary.f32(i32 36, float %2150, float %1914)  ; FMin(a,b)
  %2157 = call float @dx.op.binary.f32(i32 36, float %2154, float %2151)  ; FMin(a,b)
  %2158 = call float @dx.op.binary.f32(i32 36, float %2155, float %2152)  ; FMin(a,b)
  %2159 = call float @dx.op.binary.f32(i32 36, float %2156, float %2153)  ; FMin(a,b)
  %2160 = call float @dx.op.binary.f32(i32 36, float %597, float %2157)  ; FMin(a,b)
  %2161 = call float @dx.op.binary.f32(i32 36, float %598, float %2158)  ; FMin(a,b)
  %2162 = call float @dx.op.binary.f32(i32 36, float %599, float %2159)  ; FMin(a,b)
  %2163 = call float @dx.op.binary.f32(i32 35, float %1892, float %1872)  ; FMax(a,b)
  %2164 = call float @dx.op.binary.f32(i32 35, float %1893, float %1873)  ; FMax(a,b)
  %2165 = call float @dx.op.binary.f32(i32 35, float %1894, float %1874)  ; FMax(a,b)
  %2166 = call float @dx.op.binary.f32(i32 35, float %2148, float %1912)  ; FMax(a,b)
  %2167 = call float @dx.op.binary.f32(i32 35, float %2149, float %1913)  ; FMax(a,b)
  %2168 = call float @dx.op.binary.f32(i32 35, float %2150, float %1914)  ; FMax(a,b)
  %2169 = call float @dx.op.binary.f32(i32 35, float %2166, float %2163)  ; FMax(a,b)
  %2170 = call float @dx.op.binary.f32(i32 35, float %2167, float %2164)  ; FMax(a,b)
  %2171 = call float @dx.op.binary.f32(i32 35, float %2168, float %2165)  ; FMax(a,b)
  %2172 = call float @dx.op.binary.f32(i32 35, float %597, float %2169)  ; FMax(a,b)
  %2173 = call float @dx.op.binary.f32(i32 35, float %598, float %2170)  ; FMax(a,b)
  %2174 = call float @dx.op.binary.f32(i32 35, float %599, float %2171)  ; FMax(a,b)
  %2175 = fsub fast float %2172, %2160
  %2176 = fsub fast float %2173, %2161
  %2177 = fsub fast float %2174, %2162
  %2178 = call float @dx.op.unary.f32(i32 6, float %2175)  ; FAbs(value)
  %2179 = call float @dx.op.unary.f32(i32 6, float %2176)  ; FAbs(value)
  %2180 = call float @dx.op.unary.f32(i32 6, float %2177)  ; FAbs(value)
  %2181 = call float @dx.op.binary.f32(i32 35, float %2179, float %2180)  ; FMax(a,b)
  %2182 = call float @dx.op.binary.f32(i32 35, float %2178, float %2181)  ; FMax(a,b)
  %2183 = call float @dx.op.binary.f32(i32 35, float %2173, float %2174)  ; FMax(a,b)
  %2184 = call float @dx.op.binary.f32(i32 35, float %2172, float %2183)  ; FMax(a,b)
  %2185 = fmul fast float %2184, 1.250000e-01
  %2186 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %2185)  ; FMax(a,b)
  %2187 = fcmp fast ogt float %2182, %2186
  br i1 %2187, label %2188, label %2250

; <label>:2188                                    ; preds = %2147
  %2189 = fsub fast float %2148, %1912
  %2190 = fsub fast float %2149, %1913
  %2191 = fsub fast float %2150, %1914
  %2192 = call float @dx.op.unary.f32(i32 6, float %2189)  ; FAbs(value)
  %2193 = call float @dx.op.unary.f32(i32 6, float %2190)  ; FAbs(value)
  %2194 = call float @dx.op.unary.f32(i32 6, float %2191)  ; FAbs(value)
  %2195 = call float @dx.op.binary.f32(i32 35, float %2193, float %2194)  ; FMax(a,b)
  %2196 = call float @dx.op.binary.f32(i32 35, float %2192, float %2195)  ; FMax(a,b)
  %2197 = fsub fast float %1892, %1872
  %2198 = fsub fast float %1893, %1873
  %2199 = fsub fast float %1894, %1874
  %2200 = call float @dx.op.unary.f32(i32 6, float %2197)  ; FAbs(value)
  %2201 = call float @dx.op.unary.f32(i32 6, float %2198)  ; FAbs(value)
  %2202 = call float @dx.op.unary.f32(i32 6, float %2199)  ; FAbs(value)
  %2203 = call float @dx.op.binary.f32(i32 35, float %2201, float %2202)  ; FMax(a,b)
  %2204 = call float @dx.op.binary.f32(i32 35, float %2200, float %2203)  ; FMax(a,b)
  %2205 = fcmp fast olt float %2196, %2204
  %2206 = select i1 %2205, float %2148, float %1892
  %2207 = select i1 %2205, float %2149, float %1893
  %2208 = select i1 %2205, float %2150, float %1894
  %2209 = select i1 %2205, float %1912, float %1872
  %2210 = select i1 %2205, float %1913, float %1873
  %2211 = select i1 %2205, float %1914, float %1874
  %2212 = fsub fast float %597, %2209
  %2213 = fsub fast float %598, %2210
  %2214 = fsub fast float %599, %2211
  %2215 = fsub fast float %597, %2206
  %2216 = fsub fast float %598, %2207
  %2217 = fsub fast float %599, %2208
  %2218 = call float @dx.op.dot3.f32(i32 55, float %2215, float %2216, float %2217, float %2212, float %2213, float %2214)  ; Dot3(ax,ay,az,bx,by,bz)
  %2219 = fcmp fast ogt float %2218, 0.000000e+00
  br i1 %2219, label %2220, label %2231

; <label>:2220                                    ; preds = %2188
  %2221 = fsub fast float %2206, %2209
  %2222 = fsub fast float %2207, %2210
  %2223 = fsub fast float %2208, %2211
  %2224 = call float @dx.op.unary.f32(i32 6, float %2221)  ; FAbs(value)
  %2225 = call float @dx.op.unary.f32(i32 6, float %2222)  ; FAbs(value)
  %2226 = call float @dx.op.unary.f32(i32 6, float %2223)  ; FAbs(value)
  %2227 = call float @dx.op.binary.f32(i32 35, float %2225, float %2226)  ; FMax(a,b)
  %2228 = call float @dx.op.binary.f32(i32 35, float %2224, float %2227)  ; FMax(a,b)
  %2229 = fmul fast float %2182, 2.500000e-01
  %2230 = fcmp fast olt float %2228, %2229
  br label %2231

; <label>:2231                                    ; preds = %2220, %2188
  %2232 = phi i1 [ false, %2188 ], [ %2230, %2220 ]
  %2233 = select i1 %2232, float 5.000000e-01, float 1.000000e+00
  %2234 = fmul fast float %2233, %3
  %2235 = fadd fast float %2206, %2209
  %2236 = fadd fast float %2207, %2210
  %2237 = fadd fast float %2208, %2211
  %2238 = fmul fast float %2235, 5.000000e-01
  %2239 = fmul fast float %2236, 5.000000e-01
  %2240 = fmul fast float %2237, 5.000000e-01
  %2241 = fsub fast float %2238, %597
  %2242 = fsub fast float %2239, %598
  %2243 = fsub fast float %2240, %599
  %2244 = fmul fast float %2234, %2241
  %2245 = fmul fast float %2234, %2242
  %2246 = fmul fast float %2234, %2243
  %2247 = fadd fast float %2244, %597
  %2248 = fadd fast float %2245, %598
  %2249 = fadd fast float %2246, %599
  br label %2250

; <label>:2250                                    ; preds = %2231, %2147, %1630
  %2251 = phi float [ %597, %1630 ], [ %2247, %2231 ], [ %597, %2147 ]
  %2252 = phi float [ %598, %1630 ], [ %2248, %2231 ], [ %598, %2147 ]
  %2253 = phi float [ %599, %1630 ], [ %2249, %2231 ], [ %599, %2147 ]
  %2254 = fcmp fast ult float %190, 0.000000e+00
  br i1 %2254, label %2870, label %2255

; <label>:2255                                    ; preds = %2250
  %2256 = fsub fast float 1.000000e+00, %87
  %2257 = fmul fast float %2256, 0x3FA99999A0000000
  %2258 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %2257)  ; FMax(a,b)
  %2259 = fsub fast float %89, %87
  %2260 = call float @dx.op.unary.f32(i32 6, float %2259)  ; FAbs(value)
  %2261 = fdiv fast float %2260, %2258
  %2262 = fsub fast float 1.000000e+00, %2261
  %2263 = call float @dx.op.unary.f32(i32 7, float %2262)  ; Saturate(value)
  %2264 = fcmp fast ugt float %2263, 0.000000e+00
  br i1 %2264, label %2265, label %2275

; <label>:2265                                    ; preds = %2255
  %2266 = fsub fast float %1001, %799
  %2267 = fsub fast float %1002, %800
  %2268 = fsub fast float %1003, %801
  %2269 = fmul fast float %2263, %2266
  %2270 = fmul fast float %2263, %2267
  %2271 = fmul fast float %2263, %2268
  %2272 = fadd fast float %2269, %799
  %2273 = fadd fast float %2270, %800
  %2274 = fadd fast float %2271, %801
  br label %2275

; <label>:2275                                    ; preds = %2265, %2255
  %2276 = phi float [ %2272, %2265 ], [ %799, %2255 ]
  %2277 = phi float [ %2273, %2265 ], [ %800, %2255 ]
  %2278 = phi float [ %2274, %2265 ], [ %801, %2255 ]
  %2279 = add i32 %56, -1
  %2280 = call i32 @dx.op.binary.i32(i32 37, i32 %2279, i32 0)  ; IMax(a,b)
  %2281 = call i32 @dx.op.binary.i32(i32 38, i32 %2280, i32 %60)  ; IMin(a,b)
  %2282 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2281, i32 %71, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2283 = extractvalue %dx.types.ResRet.f32 %2282, 0
  %2284 = fsub fast float %2283, %87
  %2285 = call float @dx.op.unary.f32(i32 6, float %2284)  ; FAbs(value)
  %2286 = fdiv fast float %2285, %2258
  %2287 = fsub fast float 1.000000e+00, %2286
  %2288 = call float @dx.op.unary.f32(i32 7, float %2287)  ; Saturate(value)
  %2289 = fcmp fast ugt float %2288, 0.000000e+00
  br i1 %2289, label %2290, label %2511

; <label>:2290                                    ; preds = %2275
  %2291 = call i32 @dx.op.binary.i32(i32 37, i32 %2281, i32 0)  ; IMax(a,b)
  %2292 = call i32 @dx.op.binary.i32(i32 37, i32 %71, i32 0)  ; IMax(a,b)
  %2293 = call i32 @dx.op.binary.i32(i32 38, i32 %2291, i32 %60)  ; IMin(a,b)
  %2294 = call i32 @dx.op.binary.i32(i32 38, i32 %2292, i32 %61)  ; IMin(a,b)
  %2295 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2293, i32 %2294, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2296 = extractvalue %dx.types.ResRet.f32 %2295, 0
  %2297 = extractvalue %dx.types.ResRet.f32 %2295, 1
  %2298 = extractvalue %dx.types.ResRet.f32 %2295, 2
  %2299 = extractvalue %dx.types.ResRet.f32 %2295, 3
  %2300 = fcmp fast olt float %2299, 0.000000e+00
  br i1 %2300, label %2301, label %2335

; <label>:2301                                    ; preds = %2290
  %2302 = fcmp fast ogt float %2296, 0x3FA4B5DCC0000000
  %2303 = fcmp fast ogt float %2297, 0x3FA4B5DCC0000000
  %2304 = fcmp fast ogt float %2298, 0x3FA4B5DCC0000000
  %2305 = select i1 %2302, float 0.000000e+00, float 1.000000e+00
  %2306 = select i1 %2303, float 0.000000e+00, float 1.000000e+00
  %2307 = select i1 %2304, float 0.000000e+00, float 1.000000e+00
  %2308 = fmul fast float %2296, 0x3FB3D07220000000
  %2309 = fmul fast float %2297, 0x3FB3D07220000000
  %2310 = fmul fast float %2298, 0x3FB3D07220000000
  %2311 = fadd fast float %2296, 0x3FAC28F5C0000000
  %2312 = fadd fast float %2297, 0x3FAC28F5C0000000
  %2313 = fadd fast float %2298, 0x3FAC28F5C0000000
  %2314 = fmul fast float %2311, 0x3FEE54EDE0000000
  %2315 = fmul fast float %2312, 0x3FEE54EDE0000000
  %2316 = fmul fast float %2313, 0x3FEE54EDE0000000
  %2317 = call float @dx.op.unary.f32(i32 23, float %2314)  ; Log(value)
  %2318 = call float @dx.op.unary.f32(i32 23, float %2315)  ; Log(value)
  %2319 = call float @dx.op.unary.f32(i32 23, float %2316)  ; Log(value)
  %2320 = fmul fast float %2317, 0x4003333340000000
  %2321 = fmul fast float %2318, 0x4003333340000000
  %2322 = fmul fast float %2319, 0x4003333340000000
  %2323 = call float @dx.op.unary.f32(i32 21, float %2320)  ; Exp(value)
  %2324 = call float @dx.op.unary.f32(i32 21, float %2321)  ; Exp(value)
  %2325 = call float @dx.op.unary.f32(i32 21, float %2322)  ; Exp(value)
  %2326 = fsub fast float %2308, %2323
  %2327 = fsub fast float %2309, %2324
  %2328 = fsub fast float %2310, %2325
  %2329 = fmul fast float %2326, %2305
  %2330 = fmul fast float %2327, %2306
  %2331 = fmul fast float %2328, %2307
  %2332 = fadd fast float %2329, %2323
  %2333 = fadd fast float %2330, %2324
  %2334 = fadd fast float %2331, %2325
  br label %2498

; <label>:2335                                    ; preds = %2290
  %2336 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2293, i32 %2294, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2337 = extractvalue %dx.types.ResRet.f32 %2336, 0
  %2338 = fcmp fast ogt float %39, 5.000000e-01
  %2339 = fcmp fast olt float %2337, 1.000000e+00
  %2340 = and i1 %2338, %2339
  br i1 %2340, label %2341, label %2427

; <label>:2341                                    ; preds = %2335
  %2342 = sitofp i32 %2293 to float
  %2343 = sitofp i32 %2294 to float
  %2344 = fadd fast float %2342, 5.000000e-01
  %2345 = fadd fast float %2343, 5.000000e-01
  %2346 = fdiv fast float %2344, %46
  %2347 = fdiv fast float %2345, %47
  %2348 = fmul fast float %2346, 2.000000e+00
  %2349 = fmul fast float %2347, 2.000000e+00
  %2350 = fadd fast float %2348, -1.000000e+00
  %2351 = fsub fast float 1.000000e+00, %2349
  %2352 = fmul fast float %2350, %36
  %2353 = call float @dx.op.tertiary.f32(i32 46, float %2351, float %32, float %2352)  ; FMad(a,b,c)
  %2354 = call float @dx.op.tertiary.f32(i32 46, float %2337, float %28, float %2353)  ; FMad(a,b,c)
  %2355 = fadd fast float %2354, %24
  %2356 = call float @dx.op.unary.f32(i32 6, float %2355)  ; FAbs(value)
  %2357 = fcmp fast ogt float %2356, 0x3EB0C6F7A0000000
  br i1 %2357, label %2358, label %2427

; <label>:2358                                    ; preds = %2341
  %2359 = fmul fast float %2350, %35
  %2360 = call float @dx.op.tertiary.f32(i32 46, float %2351, float %31, float %2359)  ; FMad(a,b,c)
  %2361 = call float @dx.op.tertiary.f32(i32 46, float %2337, float %27, float %2360)  ; FMad(a,b,c)
  %2362 = fadd fast float %2361, %23
  %2363 = fmul fast float %2350, %34
  %2364 = call float @dx.op.tertiary.f32(i32 46, float %2351, float %30, float %2363)  ; FMad(a,b,c)
  %2365 = call float @dx.op.tertiary.f32(i32 46, float %2337, float %26, float %2364)  ; FMad(a,b,c)
  %2366 = fadd fast float %2365, %22
  %2367 = fmul fast float %2350, %33
  %2368 = call float @dx.op.tertiary.f32(i32 46, float %2351, float %29, float %2367)  ; FMad(a,b,c)
  %2369 = call float @dx.op.tertiary.f32(i32 46, float %2337, float %25, float %2368)  ; FMad(a,b,c)
  %2370 = fadd fast float %2369, %21
  %2371 = fdiv fast float %2370, %2355
  %2372 = fdiv fast float %2366, %2355
  %2373 = fdiv fast float %2362, %2355
  %2374 = fsub fast float %2371, %18
  %2375 = fsub fast float %2372, %19
  %2376 = fsub fast float %2373, %20
  %2377 = fmul fast float %2374, %2374
  %2378 = fmul fast float %2375, %2375
  %2379 = fadd fast float %2378, %2377
  %2380 = fmul fast float %2376, %2376
  %2381 = fadd fast float %2379, %2380
  %2382 = call float @dx.op.unary.f32(i32 24, float %2381)  ; Sqrt(value)
  %2383 = fsub fast float %2382, %10
  %2384 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2383)  ; FMax(a,b)
  %2385 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %2385, label %2386, label %2409

; <label>:2386                                    ; preds = %2358
  %2387 = call float @dx.op.unary.f32(i32 6, float %2375)  ; FAbs(value)
  %2388 = fmul fast float %2387, %12
  %2389 = fcmp fast olt float %2388, 0x3F50624DE0000000
  br i1 %2389, label %2390, label %2393

; <label>:2390                                    ; preds = %2386
  %2391 = fmul fast float %2388, 5.000000e-01
  %2392 = fsub fast float 1.000000e+00, %2391
  br label %2398

; <label>:2393                                    ; preds = %2386
  %2394 = fmul fast float %2388, 0xBFF7154760000000
  %2395 = call float @dx.op.unary.f32(i32 21, float %2394)  ; Exp(value)
  %2396 = fsub fast float 1.000000e+00, %2395
  %2397 = fdiv fast float %2396, %2388
  br label %2398

; <label>:2398                                    ; preds = %2393, %2390
  %2399 = phi float [ %2392, %2390 ], [ %2397, %2393 ]
  %2400 = call float @dx.op.binary.f32(i32 36, float %2372, float %19)  ; FMin(a,b)
  %2401 = fsub fast float %2400, %11
  %2402 = fmul fast float %12, %2401
  %2403 = fsub fast float -0.000000e+00, %2402
  %2404 = call float @dx.op.binary.f32(i32 35, float %2403, float -4.000000e+01)  ; FMax(a,b)
  %2405 = call float @dx.op.binary.f32(i32 36, float %2404, float 5.000000e+00)  ; FMin(a,b)
  %2406 = fmul fast float %2405, 0x3FF7154760000000
  %2407 = call float @dx.op.unary.f32(i32 21, float %2406)  ; Exp(value)
  %2408 = fmul fast float %2407, %2399
  br label %2409

; <label>:2409                                    ; preds = %2398, %2358
  %2410 = phi float [ %2408, %2398 ], [ 1.000000e+00, %2358 ]
  %2411 = fmul fast float %2384, %17
  %2412 = fmul fast float %2411, %2410
  %2413 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2412)  ; FMin(a,b)
  %2414 = fmul fast float %2413, 0xBFF7154760000000
  %2415 = call float @dx.op.unary.f32(i32 21, float %2414)  ; Exp(value)
  %2416 = fsub fast float 1.000000e+00, %2415
  %2417 = call float @dx.op.binary.f32(i32 36, float %13, float %2416)  ; FMin(a,b)
  %2418 = fsub fast float %14, %2296
  %2419 = fsub fast float %15, %2297
  %2420 = fsub fast float %16, %2298
  %2421 = fmul fast float %2417, %2418
  %2422 = fmul fast float %2417, %2419
  %2423 = fmul fast float %2417, %2420
  %2424 = fadd fast float %2421, %2296
  %2425 = fadd fast float %2422, %2297
  %2426 = fadd fast float %2423, %2298
  br label %2427

; <label>:2427                                    ; preds = %2409, %2341, %2335
  %2428 = phi float [ %2424, %2409 ], [ %2296, %2341 ], [ %2296, %2335 ]
  %2429 = phi float [ %2425, %2409 ], [ %2297, %2341 ], [ %2297, %2335 ]
  %2430 = phi float [ %2426, %2409 ], [ %2298, %2341 ], [ %2298, %2335 ]
  %2431 = fadd fast float %6, 1.000000e+00
  %2432 = fadd fast float %7, 1.000000e+00
  %2433 = fsub fast float 1.000000e+00, %6
  %2434 = fmul fast float %37, %2431
  %2435 = fmul fast float %37, %2432
  %2436 = fmul fast float %37, %2433
  %2437 = fmul fast float %2434, %2428
  %2438 = fmul fast float %2435, %2429
  %2439 = fmul fast float %2436, %2430
  %2440 = fcmp fast ult float %38, 5.000000e-01
  br i1 %2440, label %2466, label %2441

; <label>:2441                                    ; preds = %2427
  %2442 = fmul fast float %2437, 0x4004147AE0000000
  %2443 = fmul fast float %2438, 0x4004147AE0000000
  %2444 = fmul fast float %2439, 0x4004147AE0000000
  %2445 = fadd fast float %2442, 0x3F9EB851E0000000
  %2446 = fadd fast float %2443, 0x3F9EB851E0000000
  %2447 = fadd fast float %2444, 0x3F9EB851E0000000
  %2448 = fmul fast float %2445, %2437
  %2449 = fmul fast float %2446, %2438
  %2450 = fmul fast float %2447, %2439
  %2451 = fmul fast float %2437, 0x400370A3E0000000
  %2452 = fmul fast float %2438, 0x400370A3E0000000
  %2453 = fmul fast float %2439, 0x400370A3E0000000
  %2454 = fadd fast float %2451, 0x3FE2E147A0000000
  %2455 = fadd fast float %2452, 0x3FE2E147A0000000
  %2456 = fadd fast float %2453, 0x3FE2E147A0000000
  %2457 = fmul fast float %2454, %2437
  %2458 = fmul fast float %2455, %2438
  %2459 = fmul fast float %2456, %2439
  %2460 = fadd fast float %2457, 0x3FC1EB8520000000
  %2461 = fadd fast float %2458, 0x3FC1EB8520000000
  %2462 = fadd fast float %2459, 0x3FC1EB8520000000
  %2463 = fdiv fast float %2448, %2460
  %2464 = fdiv fast float %2449, %2461
  %2465 = fdiv fast float %2450, %2462
  br label %2466

; <label>:2466                                    ; preds = %2441, %2427
  %2467 = phi float [ %2463, %2441 ], [ %2437, %2427 ]
  %2468 = phi float [ %2464, %2441 ], [ %2438, %2427 ]
  %2469 = phi float [ %2465, %2441 ], [ %2439, %2427 ]
  %2470 = call float @dx.op.unary.f32(i32 7, float %2467)  ; Saturate(value)
  %2471 = call float @dx.op.unary.f32(i32 7, float %2468)  ; Saturate(value)
  %2472 = call float @dx.op.unary.f32(i32 7, float %2469)  ; Saturate(value)
  %2473 = call float @dx.op.dot3.f32(i32 55, float %2470, float %2471, float %2472, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2474 = fsub fast float %2470, %2473
  %2475 = fsub fast float %2471, %2473
  %2476 = fsub fast float %2472, %2473
  %2477 = fmul fast float %2474, %9
  %2478 = fmul fast float %2475, %9
  %2479 = fmul fast float %2476, %9
  %2480 = fadd fast float %2477, %2473
  %2481 = fadd fast float %2478, %2473
  %2482 = fadd fast float %2479, %2473
  %2483 = call float @dx.op.unary.f32(i32 7, float %2480)  ; Saturate(value)
  %2484 = call float @dx.op.unary.f32(i32 7, float %2481)  ; Saturate(value)
  %2485 = call float @dx.op.unary.f32(i32 7, float %2482)  ; Saturate(value)
  %2486 = fadd fast float %2483, 0xBFC70A3D80000000
  %2487 = fadd fast float %2484, 0xBFC70A3D80000000
  %2488 = fadd fast float %2485, 0xBFC70A3D80000000
  %2489 = fmul fast float %2486, %8
  %2490 = fmul fast float %2487, %8
  %2491 = fmul fast float %2488, %8
  %2492 = fadd fast float %2489, 0x3FC70A3D80000000
  %2493 = fadd fast float %2490, 0x3FC70A3D80000000
  %2494 = fadd fast float %2491, 0x3FC70A3D80000000
  %2495 = call float @dx.op.unary.f32(i32 7, float %2492)  ; Saturate(value)
  %2496 = call float @dx.op.unary.f32(i32 7, float %2493)  ; Saturate(value)
  %2497 = call float @dx.op.unary.f32(i32 7, float %2494)  ; Saturate(value)
  br label %2498

; <label>:2498                                    ; preds = %2466, %2301
  %2499 = phi float [ %2332, %2301 ], [ %2495, %2466 ]
  %2500 = phi float [ %2333, %2301 ], [ %2496, %2466 ]
  %2501 = phi float [ %2334, %2301 ], [ %2497, %2466 ]
  %2502 = fsub fast float %2499, %799
  %2503 = fsub fast float %2500, %800
  %2504 = fsub fast float %2501, %801
  %2505 = fmul fast float %2502, %2288
  %2506 = fmul fast float %2503, %2288
  %2507 = fmul fast float %2504, %2288
  %2508 = fadd fast float %2505, %799
  %2509 = fadd fast float %2506, %800
  %2510 = fadd fast float %2507, %801
  br label %2511

; <label>:2511                                    ; preds = %2498, %2275
  %2512 = phi float [ %2508, %2498 ], [ %799, %2275 ]
  %2513 = phi float [ %2509, %2498 ], [ %800, %2275 ]
  %2514 = phi float [ %2510, %2498 ], [ %801, %2275 ]
  %2515 = add i32 %57, 2
  %2516 = call i32 @dx.op.binary.i32(i32 37, i32 %2515, i32 0)  ; IMax(a,b)
  %2517 = call i32 @dx.op.binary.i32(i32 38, i32 %2516, i32 %61)  ; IMin(a,b)
  %2518 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %64, i32 %2517, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2519 = extractvalue %dx.types.ResRet.f32 %2518, 0
  %2520 = fsub fast float %2519, %87
  %2521 = call float @dx.op.unary.f32(i32 6, float %2520)  ; FAbs(value)
  %2522 = fdiv fast float %2521, %2258
  %2523 = fsub fast float 1.000000e+00, %2522
  %2524 = call float @dx.op.unary.f32(i32 7, float %2523)  ; Saturate(value)
  %2525 = fcmp fast ugt float %2524, 0.000000e+00
  br i1 %2525, label %2526, label %2747

; <label>:2526                                    ; preds = %2511
  %2527 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %2528 = call i32 @dx.op.binary.i32(i32 37, i32 %2517, i32 0)  ; IMax(a,b)
  %2529 = call i32 @dx.op.binary.i32(i32 38, i32 %2527, i32 %60)  ; IMin(a,b)
  %2530 = call i32 @dx.op.binary.i32(i32 38, i32 %2528, i32 %61)  ; IMin(a,b)
  %2531 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2529, i32 %2530, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2532 = extractvalue %dx.types.ResRet.f32 %2531, 0
  %2533 = extractvalue %dx.types.ResRet.f32 %2531, 1
  %2534 = extractvalue %dx.types.ResRet.f32 %2531, 2
  %2535 = extractvalue %dx.types.ResRet.f32 %2531, 3
  %2536 = fcmp fast olt float %2535, 0.000000e+00
  br i1 %2536, label %2537, label %2571

; <label>:2537                                    ; preds = %2526
  %2538 = fcmp fast ogt float %2532, 0x3FA4B5DCC0000000
  %2539 = fcmp fast ogt float %2533, 0x3FA4B5DCC0000000
  %2540 = fcmp fast ogt float %2534, 0x3FA4B5DCC0000000
  %2541 = select i1 %2538, float 0.000000e+00, float 1.000000e+00
  %2542 = select i1 %2539, float 0.000000e+00, float 1.000000e+00
  %2543 = select i1 %2540, float 0.000000e+00, float 1.000000e+00
  %2544 = fmul fast float %2532, 0x3FB3D07220000000
  %2545 = fmul fast float %2533, 0x3FB3D07220000000
  %2546 = fmul fast float %2534, 0x3FB3D07220000000
  %2547 = fadd fast float %2532, 0x3FAC28F5C0000000
  %2548 = fadd fast float %2533, 0x3FAC28F5C0000000
  %2549 = fadd fast float %2534, 0x3FAC28F5C0000000
  %2550 = fmul fast float %2547, 0x3FEE54EDE0000000
  %2551 = fmul fast float %2548, 0x3FEE54EDE0000000
  %2552 = fmul fast float %2549, 0x3FEE54EDE0000000
  %2553 = call float @dx.op.unary.f32(i32 23, float %2550)  ; Log(value)
  %2554 = call float @dx.op.unary.f32(i32 23, float %2551)  ; Log(value)
  %2555 = call float @dx.op.unary.f32(i32 23, float %2552)  ; Log(value)
  %2556 = fmul fast float %2553, 0x4003333340000000
  %2557 = fmul fast float %2554, 0x4003333340000000
  %2558 = fmul fast float %2555, 0x4003333340000000
  %2559 = call float @dx.op.unary.f32(i32 21, float %2556)  ; Exp(value)
  %2560 = call float @dx.op.unary.f32(i32 21, float %2557)  ; Exp(value)
  %2561 = call float @dx.op.unary.f32(i32 21, float %2558)  ; Exp(value)
  %2562 = fsub fast float %2544, %2559
  %2563 = fsub fast float %2545, %2560
  %2564 = fsub fast float %2546, %2561
  %2565 = fmul fast float %2562, %2541
  %2566 = fmul fast float %2563, %2542
  %2567 = fmul fast float %2564, %2543
  %2568 = fadd fast float %2565, %2559
  %2569 = fadd fast float %2566, %2560
  %2570 = fadd fast float %2567, %2561
  br label %2734

; <label>:2571                                    ; preds = %2526
  %2572 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2529, i32 %2530, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2573 = extractvalue %dx.types.ResRet.f32 %2572, 0
  %2574 = fcmp fast ogt float %39, 5.000000e-01
  %2575 = fcmp fast olt float %2573, 1.000000e+00
  %2576 = and i1 %2574, %2575
  br i1 %2576, label %2577, label %2663

; <label>:2577                                    ; preds = %2571
  %2578 = sitofp i32 %2529 to float
  %2579 = sitofp i32 %2530 to float
  %2580 = fadd fast float %2578, 5.000000e-01
  %2581 = fadd fast float %2579, 5.000000e-01
  %2582 = fdiv fast float %2580, %46
  %2583 = fdiv fast float %2581, %47
  %2584 = fmul fast float %2582, 2.000000e+00
  %2585 = fmul fast float %2583, 2.000000e+00
  %2586 = fadd fast float %2584, -1.000000e+00
  %2587 = fsub fast float 1.000000e+00, %2585
  %2588 = fmul fast float %2586, %36
  %2589 = call float @dx.op.tertiary.f32(i32 46, float %2587, float %32, float %2588)  ; FMad(a,b,c)
  %2590 = call float @dx.op.tertiary.f32(i32 46, float %2573, float %28, float %2589)  ; FMad(a,b,c)
  %2591 = fadd fast float %2590, %24
  %2592 = call float @dx.op.unary.f32(i32 6, float %2591)  ; FAbs(value)
  %2593 = fcmp fast ogt float %2592, 0x3EB0C6F7A0000000
  br i1 %2593, label %2594, label %2663

; <label>:2594                                    ; preds = %2577
  %2595 = fmul fast float %2586, %35
  %2596 = call float @dx.op.tertiary.f32(i32 46, float %2587, float %31, float %2595)  ; FMad(a,b,c)
  %2597 = call float @dx.op.tertiary.f32(i32 46, float %2573, float %27, float %2596)  ; FMad(a,b,c)
  %2598 = fadd fast float %2597, %23
  %2599 = fmul fast float %2586, %34
  %2600 = call float @dx.op.tertiary.f32(i32 46, float %2587, float %30, float %2599)  ; FMad(a,b,c)
  %2601 = call float @dx.op.tertiary.f32(i32 46, float %2573, float %26, float %2600)  ; FMad(a,b,c)
  %2602 = fadd fast float %2601, %22
  %2603 = fmul fast float %2586, %33
  %2604 = call float @dx.op.tertiary.f32(i32 46, float %2587, float %29, float %2603)  ; FMad(a,b,c)
  %2605 = call float @dx.op.tertiary.f32(i32 46, float %2573, float %25, float %2604)  ; FMad(a,b,c)
  %2606 = fadd fast float %2605, %21
  %2607 = fdiv fast float %2606, %2591
  %2608 = fdiv fast float %2602, %2591
  %2609 = fdiv fast float %2598, %2591
  %2610 = fsub fast float %2607, %18
  %2611 = fsub fast float %2608, %19
  %2612 = fsub fast float %2609, %20
  %2613 = fmul fast float %2610, %2610
  %2614 = fmul fast float %2611, %2611
  %2615 = fadd fast float %2614, %2613
  %2616 = fmul fast float %2612, %2612
  %2617 = fadd fast float %2615, %2616
  %2618 = call float @dx.op.unary.f32(i32 24, float %2617)  ; Sqrt(value)
  %2619 = fsub fast float %2618, %10
  %2620 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2619)  ; FMax(a,b)
  %2621 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %2621, label %2622, label %2645

; <label>:2622                                    ; preds = %2594
  %2623 = call float @dx.op.unary.f32(i32 6, float %2611)  ; FAbs(value)
  %2624 = fmul fast float %2623, %12
  %2625 = fcmp fast olt float %2624, 0x3F50624DE0000000
  br i1 %2625, label %2626, label %2629

; <label>:2626                                    ; preds = %2622
  %2627 = fmul fast float %2624, 5.000000e-01
  %2628 = fsub fast float 1.000000e+00, %2627
  br label %2634

; <label>:2629                                    ; preds = %2622
  %2630 = fmul fast float %2624, 0xBFF7154760000000
  %2631 = call float @dx.op.unary.f32(i32 21, float %2630)  ; Exp(value)
  %2632 = fsub fast float 1.000000e+00, %2631
  %2633 = fdiv fast float %2632, %2624
  br label %2634

; <label>:2634                                    ; preds = %2629, %2626
  %2635 = phi float [ %2628, %2626 ], [ %2633, %2629 ]
  %2636 = call float @dx.op.binary.f32(i32 36, float %2608, float %19)  ; FMin(a,b)
  %2637 = fsub fast float %2636, %11
  %2638 = fmul fast float %12, %2637
  %2639 = fsub fast float -0.000000e+00, %2638
  %2640 = call float @dx.op.binary.f32(i32 35, float %2639, float -4.000000e+01)  ; FMax(a,b)
  %2641 = call float @dx.op.binary.f32(i32 36, float %2640, float 5.000000e+00)  ; FMin(a,b)
  %2642 = fmul fast float %2641, 0x3FF7154760000000
  %2643 = call float @dx.op.unary.f32(i32 21, float %2642)  ; Exp(value)
  %2644 = fmul fast float %2643, %2635
  br label %2645

; <label>:2645                                    ; preds = %2634, %2594
  %2646 = phi float [ %2644, %2634 ], [ 1.000000e+00, %2594 ]
  %2647 = fmul fast float %2620, %17
  %2648 = fmul fast float %2647, %2646
  %2649 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2648)  ; FMin(a,b)
  %2650 = fmul fast float %2649, 0xBFF7154760000000
  %2651 = call float @dx.op.unary.f32(i32 21, float %2650)  ; Exp(value)
  %2652 = fsub fast float 1.000000e+00, %2651
  %2653 = call float @dx.op.binary.f32(i32 36, float %13, float %2652)  ; FMin(a,b)
  %2654 = fsub fast float %14, %2532
  %2655 = fsub fast float %15, %2533
  %2656 = fsub fast float %16, %2534
  %2657 = fmul fast float %2653, %2654
  %2658 = fmul fast float %2653, %2655
  %2659 = fmul fast float %2653, %2656
  %2660 = fadd fast float %2657, %2532
  %2661 = fadd fast float %2658, %2533
  %2662 = fadd fast float %2659, %2534
  br label %2663

; <label>:2663                                    ; preds = %2645, %2577, %2571
  %2664 = phi float [ %2660, %2645 ], [ %2532, %2577 ], [ %2532, %2571 ]
  %2665 = phi float [ %2661, %2645 ], [ %2533, %2577 ], [ %2533, %2571 ]
  %2666 = phi float [ %2662, %2645 ], [ %2534, %2577 ], [ %2534, %2571 ]
  %2667 = fadd fast float %6, 1.000000e+00
  %2668 = fadd fast float %7, 1.000000e+00
  %2669 = fsub fast float 1.000000e+00, %6
  %2670 = fmul fast float %37, %2667
  %2671 = fmul fast float %37, %2668
  %2672 = fmul fast float %37, %2669
  %2673 = fmul fast float %2670, %2664
  %2674 = fmul fast float %2671, %2665
  %2675 = fmul fast float %2672, %2666
  %2676 = fcmp fast ult float %38, 5.000000e-01
  br i1 %2676, label %2702, label %2677

; <label>:2677                                    ; preds = %2663
  %2678 = fmul fast float %2673, 0x4004147AE0000000
  %2679 = fmul fast float %2674, 0x4004147AE0000000
  %2680 = fmul fast float %2675, 0x4004147AE0000000
  %2681 = fadd fast float %2678, 0x3F9EB851E0000000
  %2682 = fadd fast float %2679, 0x3F9EB851E0000000
  %2683 = fadd fast float %2680, 0x3F9EB851E0000000
  %2684 = fmul fast float %2681, %2673
  %2685 = fmul fast float %2682, %2674
  %2686 = fmul fast float %2683, %2675
  %2687 = fmul fast float %2673, 0x400370A3E0000000
  %2688 = fmul fast float %2674, 0x400370A3E0000000
  %2689 = fmul fast float %2675, 0x400370A3E0000000
  %2690 = fadd fast float %2687, 0x3FE2E147A0000000
  %2691 = fadd fast float %2688, 0x3FE2E147A0000000
  %2692 = fadd fast float %2689, 0x3FE2E147A0000000
  %2693 = fmul fast float %2690, %2673
  %2694 = fmul fast float %2691, %2674
  %2695 = fmul fast float %2692, %2675
  %2696 = fadd fast float %2693, 0x3FC1EB8520000000
  %2697 = fadd fast float %2694, 0x3FC1EB8520000000
  %2698 = fadd fast float %2695, 0x3FC1EB8520000000
  %2699 = fdiv fast float %2684, %2696
  %2700 = fdiv fast float %2685, %2697
  %2701 = fdiv fast float %2686, %2698
  br label %2702

; <label>:2702                                    ; preds = %2677, %2663
  %2703 = phi float [ %2699, %2677 ], [ %2673, %2663 ]
  %2704 = phi float [ %2700, %2677 ], [ %2674, %2663 ]
  %2705 = phi float [ %2701, %2677 ], [ %2675, %2663 ]
  %2706 = call float @dx.op.unary.f32(i32 7, float %2703)  ; Saturate(value)
  %2707 = call float @dx.op.unary.f32(i32 7, float %2704)  ; Saturate(value)
  %2708 = call float @dx.op.unary.f32(i32 7, float %2705)  ; Saturate(value)
  %2709 = call float @dx.op.dot3.f32(i32 55, float %2706, float %2707, float %2708, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2710 = fsub fast float %2706, %2709
  %2711 = fsub fast float %2707, %2709
  %2712 = fsub fast float %2708, %2709
  %2713 = fmul fast float %2710, %9
  %2714 = fmul fast float %2711, %9
  %2715 = fmul fast float %2712, %9
  %2716 = fadd fast float %2713, %2709
  %2717 = fadd fast float %2714, %2709
  %2718 = fadd fast float %2715, %2709
  %2719 = call float @dx.op.unary.f32(i32 7, float %2716)  ; Saturate(value)
  %2720 = call float @dx.op.unary.f32(i32 7, float %2717)  ; Saturate(value)
  %2721 = call float @dx.op.unary.f32(i32 7, float %2718)  ; Saturate(value)
  %2722 = fadd fast float %2719, 0xBFC70A3D80000000
  %2723 = fadd fast float %2720, 0xBFC70A3D80000000
  %2724 = fadd fast float %2721, 0xBFC70A3D80000000
  %2725 = fmul fast float %2722, %8
  %2726 = fmul fast float %2723, %8
  %2727 = fmul fast float %2724, %8
  %2728 = fadd fast float %2725, 0x3FC70A3D80000000
  %2729 = fadd fast float %2726, 0x3FC70A3D80000000
  %2730 = fadd fast float %2727, 0x3FC70A3D80000000
  %2731 = call float @dx.op.unary.f32(i32 7, float %2728)  ; Saturate(value)
  %2732 = call float @dx.op.unary.f32(i32 7, float %2729)  ; Saturate(value)
  %2733 = call float @dx.op.unary.f32(i32 7, float %2730)  ; Saturate(value)
  br label %2734

; <label>:2734                                    ; preds = %2702, %2537
  %2735 = phi float [ %2568, %2537 ], [ %2731, %2702 ]
  %2736 = phi float [ %2569, %2537 ], [ %2732, %2702 ]
  %2737 = phi float [ %2570, %2537 ], [ %2733, %2702 ]
  %2738 = fsub fast float %2735, %799
  %2739 = fsub fast float %2736, %800
  %2740 = fsub fast float %2737, %801
  %2741 = fmul fast float %2738, %2524
  %2742 = fmul fast float %2739, %2524
  %2743 = fmul fast float %2740, %2524
  %2744 = fadd fast float %2741, %799
  %2745 = fadd fast float %2742, %800
  %2746 = fadd fast float %2743, %801
  br label %2747

; <label>:2747                                    ; preds = %2734, %2511
  %2748 = phi float [ %2744, %2734 ], [ %799, %2511 ]
  %2749 = phi float [ %2745, %2734 ], [ %800, %2511 ]
  %2750 = phi float [ %2746, %2734 ], [ %801, %2511 ]
  %2751 = fsub fast float %83, %87
  %2752 = call float @dx.op.unary.f32(i32 6, float %2751)  ; FAbs(value)
  %2753 = fdiv fast float %2752, %2258
  %2754 = fsub fast float 1.000000e+00, %2753
  %2755 = call float @dx.op.unary.f32(i32 7, float %2754)  ; Saturate(value)
  %2756 = fcmp fast ugt float %2755, 0.000000e+00
  br i1 %2756, label %2757, label %2767

; <label>:2757                                    ; preds = %2747
  %2758 = fsub fast float %395, %799
  %2759 = fsub fast float %396, %800
  %2760 = fsub fast float %397, %801
  %2761 = fmul fast float %2755, %2758
  %2762 = fmul fast float %2755, %2759
  %2763 = fmul fast float %2755, %2760
  %2764 = fadd fast float %2761, %799
  %2765 = fadd fast float %2762, %800
  %2766 = fadd fast float %2763, %801
  br label %2767

; <label>:2767                                    ; preds = %2757, %2747
  %2768 = phi float [ %2764, %2757 ], [ %799, %2747 ]
  %2769 = phi float [ %2765, %2757 ], [ %800, %2747 ]
  %2770 = phi float [ %2766, %2757 ], [ %801, %2747 ]
  %2771 = call float @dx.op.binary.f32(i32 36, float %2512, float %2276)  ; FMin(a,b)
  %2772 = call float @dx.op.binary.f32(i32 36, float %2513, float %2277)  ; FMin(a,b)
  %2773 = call float @dx.op.binary.f32(i32 36, float %2514, float %2278)  ; FMin(a,b)
  %2774 = call float @dx.op.binary.f32(i32 36, float %2768, float %2748)  ; FMin(a,b)
  %2775 = call float @dx.op.binary.f32(i32 36, float %2769, float %2749)  ; FMin(a,b)
  %2776 = call float @dx.op.binary.f32(i32 36, float %2770, float %2750)  ; FMin(a,b)
  %2777 = call float @dx.op.binary.f32(i32 36, float %2774, float %2771)  ; FMin(a,b)
  %2778 = call float @dx.op.binary.f32(i32 36, float %2775, float %2772)  ; FMin(a,b)
  %2779 = call float @dx.op.binary.f32(i32 36, float %2776, float %2773)  ; FMin(a,b)
  %2780 = call float @dx.op.binary.f32(i32 36, float %799, float %2777)  ; FMin(a,b)
  %2781 = call float @dx.op.binary.f32(i32 36, float %800, float %2778)  ; FMin(a,b)
  %2782 = call float @dx.op.binary.f32(i32 36, float %801, float %2779)  ; FMin(a,b)
  %2783 = call float @dx.op.binary.f32(i32 35, float %2512, float %2276)  ; FMax(a,b)
  %2784 = call float @dx.op.binary.f32(i32 35, float %2513, float %2277)  ; FMax(a,b)
  %2785 = call float @dx.op.binary.f32(i32 35, float %2514, float %2278)  ; FMax(a,b)
  %2786 = call float @dx.op.binary.f32(i32 35, float %2768, float %2748)  ; FMax(a,b)
  %2787 = call float @dx.op.binary.f32(i32 35, float %2769, float %2749)  ; FMax(a,b)
  %2788 = call float @dx.op.binary.f32(i32 35, float %2770, float %2750)  ; FMax(a,b)
  %2789 = call float @dx.op.binary.f32(i32 35, float %2786, float %2783)  ; FMax(a,b)
  %2790 = call float @dx.op.binary.f32(i32 35, float %2787, float %2784)  ; FMax(a,b)
  %2791 = call float @dx.op.binary.f32(i32 35, float %2788, float %2785)  ; FMax(a,b)
  %2792 = call float @dx.op.binary.f32(i32 35, float %799, float %2789)  ; FMax(a,b)
  %2793 = call float @dx.op.binary.f32(i32 35, float %800, float %2790)  ; FMax(a,b)
  %2794 = call float @dx.op.binary.f32(i32 35, float %801, float %2791)  ; FMax(a,b)
  %2795 = fsub fast float %2792, %2780
  %2796 = fsub fast float %2793, %2781
  %2797 = fsub fast float %2794, %2782
  %2798 = call float @dx.op.unary.f32(i32 6, float %2795)  ; FAbs(value)
  %2799 = call float @dx.op.unary.f32(i32 6, float %2796)  ; FAbs(value)
  %2800 = call float @dx.op.unary.f32(i32 6, float %2797)  ; FAbs(value)
  %2801 = call float @dx.op.binary.f32(i32 35, float %2799, float %2800)  ; FMax(a,b)
  %2802 = call float @dx.op.binary.f32(i32 35, float %2798, float %2801)  ; FMax(a,b)
  %2803 = call float @dx.op.binary.f32(i32 35, float %2793, float %2794)  ; FMax(a,b)
  %2804 = call float @dx.op.binary.f32(i32 35, float %2792, float %2803)  ; FMax(a,b)
  %2805 = fmul fast float %2804, 1.250000e-01
  %2806 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %2805)  ; FMax(a,b)
  %2807 = fcmp fast ogt float %2802, %2806
  br i1 %2807, label %2808, label %2870

; <label>:2808                                    ; preds = %2767
  %2809 = fsub fast float %2768, %2748
  %2810 = fsub fast float %2769, %2749
  %2811 = fsub fast float %2770, %2750
  %2812 = call float @dx.op.unary.f32(i32 6, float %2809)  ; FAbs(value)
  %2813 = call float @dx.op.unary.f32(i32 6, float %2810)  ; FAbs(value)
  %2814 = call float @dx.op.unary.f32(i32 6, float %2811)  ; FAbs(value)
  %2815 = call float @dx.op.binary.f32(i32 35, float %2813, float %2814)  ; FMax(a,b)
  %2816 = call float @dx.op.binary.f32(i32 35, float %2812, float %2815)  ; FMax(a,b)
  %2817 = fsub fast float %2512, %2276
  %2818 = fsub fast float %2513, %2277
  %2819 = fsub fast float %2514, %2278
  %2820 = call float @dx.op.unary.f32(i32 6, float %2817)  ; FAbs(value)
  %2821 = call float @dx.op.unary.f32(i32 6, float %2818)  ; FAbs(value)
  %2822 = call float @dx.op.unary.f32(i32 6, float %2819)  ; FAbs(value)
  %2823 = call float @dx.op.binary.f32(i32 35, float %2821, float %2822)  ; FMax(a,b)
  %2824 = call float @dx.op.binary.f32(i32 35, float %2820, float %2823)  ; FMax(a,b)
  %2825 = fcmp fast olt float %2816, %2824
  %2826 = select i1 %2825, float %2768, float %2512
  %2827 = select i1 %2825, float %2769, float %2513
  %2828 = select i1 %2825, float %2770, float %2514
  %2829 = select i1 %2825, float %2748, float %2276
  %2830 = select i1 %2825, float %2749, float %2277
  %2831 = select i1 %2825, float %2750, float %2278
  %2832 = fsub fast float %799, %2829
  %2833 = fsub fast float %800, %2830
  %2834 = fsub fast float %801, %2831
  %2835 = fsub fast float %799, %2826
  %2836 = fsub fast float %800, %2827
  %2837 = fsub fast float %801, %2828
  %2838 = call float @dx.op.dot3.f32(i32 55, float %2835, float %2836, float %2837, float %2832, float %2833, float %2834)  ; Dot3(ax,ay,az,bx,by,bz)
  %2839 = fcmp fast ogt float %2838, 0.000000e+00
  br i1 %2839, label %2840, label %2851

; <label>:2840                                    ; preds = %2808
  %2841 = fsub fast float %2826, %2829
  %2842 = fsub fast float %2827, %2830
  %2843 = fsub fast float %2828, %2831
  %2844 = call float @dx.op.unary.f32(i32 6, float %2841)  ; FAbs(value)
  %2845 = call float @dx.op.unary.f32(i32 6, float %2842)  ; FAbs(value)
  %2846 = call float @dx.op.unary.f32(i32 6, float %2843)  ; FAbs(value)
  %2847 = call float @dx.op.binary.f32(i32 35, float %2845, float %2846)  ; FMax(a,b)
  %2848 = call float @dx.op.binary.f32(i32 35, float %2844, float %2847)  ; FMax(a,b)
  %2849 = fmul fast float %2802, 2.500000e-01
  %2850 = fcmp fast olt float %2848, %2849
  br label %2851

; <label>:2851                                    ; preds = %2840, %2808
  %2852 = phi i1 [ false, %2808 ], [ %2850, %2840 ]
  %2853 = select i1 %2852, float 5.000000e-01, float 1.000000e+00
  %2854 = fmul fast float %2853, %3
  %2855 = fadd fast float %2826, %2829
  %2856 = fadd fast float %2827, %2830
  %2857 = fadd fast float %2828, %2831
  %2858 = fmul fast float %2855, 5.000000e-01
  %2859 = fmul fast float %2856, 5.000000e-01
  %2860 = fmul fast float %2857, 5.000000e-01
  %2861 = fsub fast float %2858, %799
  %2862 = fsub fast float %2859, %800
  %2863 = fsub fast float %2860, %801
  %2864 = fmul fast float %2854, %2861
  %2865 = fmul fast float %2854, %2862
  %2866 = fmul fast float %2854, %2863
  %2867 = fadd fast float %2864, %799
  %2868 = fadd fast float %2865, %800
  %2869 = fadd fast float %2866, %801
  br label %2870

; <label>:2870                                    ; preds = %2851, %2767, %2250
  %2871 = phi float [ %799, %2250 ], [ %2867, %2851 ], [ %799, %2767 ]
  %2872 = phi float [ %800, %2250 ], [ %2868, %2851 ], [ %800, %2767 ]
  %2873 = phi float [ %801, %2250 ], [ %2869, %2851 ], [ %801, %2767 ]
  %2874 = fcmp fast ult float %195, 0.000000e+00
  br i1 %2874, label %8522, label %2875

; <label>:2875                                    ; preds = %2870
  %2876 = add i32 %56, 2
  %2877 = call i32 @dx.op.binary.i32(i32 37, i32 %2876, i32 0)  ; IMax(a,b)
  %2878 = call i32 @dx.op.binary.i32(i32 38, i32 %2877, i32 %60)  ; IMin(a,b)
  %2879 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2878, i32 %71, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2880 = extractvalue %dx.types.ResRet.f32 %2879, 0
  %2881 = fsub fast float 1.000000e+00, %89
  %2882 = fmul fast float %2881, 0x3FA99999A0000000
  %2883 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %2882)  ; FMax(a,b)
  %2884 = fsub fast float %2880, %89
  %2885 = call float @dx.op.unary.f32(i32 6, float %2884)  ; FAbs(value)
  %2886 = fdiv fast float %2885, %2883
  %2887 = fsub fast float 1.000000e+00, %2886
  %2888 = call float @dx.op.unary.f32(i32 7, float %2887)  ; Saturate(value)
  %2889 = fcmp fast ugt float %2888, 0.000000e+00
  br i1 %2889, label %2890, label %3111

; <label>:2890                                    ; preds = %2875
  %2891 = call i32 @dx.op.binary.i32(i32 37, i32 %2878, i32 0)  ; IMax(a,b)
  %2892 = call i32 @dx.op.binary.i32(i32 37, i32 %71, i32 0)  ; IMax(a,b)
  %2893 = call i32 @dx.op.binary.i32(i32 38, i32 %2891, i32 %60)  ; IMin(a,b)
  %2894 = call i32 @dx.op.binary.i32(i32 38, i32 %2892, i32 %61)  ; IMin(a,b)
  %2895 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2893, i32 %2894, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2896 = extractvalue %dx.types.ResRet.f32 %2895, 0
  %2897 = extractvalue %dx.types.ResRet.f32 %2895, 1
  %2898 = extractvalue %dx.types.ResRet.f32 %2895, 2
  %2899 = extractvalue %dx.types.ResRet.f32 %2895, 3
  %2900 = fcmp fast olt float %2899, 0.000000e+00
  br i1 %2900, label %2901, label %2935

; <label>:2901                                    ; preds = %2890
  %2902 = fcmp fast ogt float %2896, 0x3FA4B5DCC0000000
  %2903 = fcmp fast ogt float %2897, 0x3FA4B5DCC0000000
  %2904 = fcmp fast ogt float %2898, 0x3FA4B5DCC0000000
  %2905 = select i1 %2902, float 0.000000e+00, float 1.000000e+00
  %2906 = select i1 %2903, float 0.000000e+00, float 1.000000e+00
  %2907 = select i1 %2904, float 0.000000e+00, float 1.000000e+00
  %2908 = fmul fast float %2896, 0x3FB3D07220000000
  %2909 = fmul fast float %2897, 0x3FB3D07220000000
  %2910 = fmul fast float %2898, 0x3FB3D07220000000
  %2911 = fadd fast float %2896, 0x3FAC28F5C0000000
  %2912 = fadd fast float %2897, 0x3FAC28F5C0000000
  %2913 = fadd fast float %2898, 0x3FAC28F5C0000000
  %2914 = fmul fast float %2911, 0x3FEE54EDE0000000
  %2915 = fmul fast float %2912, 0x3FEE54EDE0000000
  %2916 = fmul fast float %2913, 0x3FEE54EDE0000000
  %2917 = call float @dx.op.unary.f32(i32 23, float %2914)  ; Log(value)
  %2918 = call float @dx.op.unary.f32(i32 23, float %2915)  ; Log(value)
  %2919 = call float @dx.op.unary.f32(i32 23, float %2916)  ; Log(value)
  %2920 = fmul fast float %2917, 0x4003333340000000
  %2921 = fmul fast float %2918, 0x4003333340000000
  %2922 = fmul fast float %2919, 0x4003333340000000
  %2923 = call float @dx.op.unary.f32(i32 21, float %2920)  ; Exp(value)
  %2924 = call float @dx.op.unary.f32(i32 21, float %2921)  ; Exp(value)
  %2925 = call float @dx.op.unary.f32(i32 21, float %2922)  ; Exp(value)
  %2926 = fsub fast float %2908, %2923
  %2927 = fsub fast float %2909, %2924
  %2928 = fsub fast float %2910, %2925
  %2929 = fmul fast float %2926, %2905
  %2930 = fmul fast float %2927, %2906
  %2931 = fmul fast float %2928, %2907
  %2932 = fadd fast float %2929, %2923
  %2933 = fadd fast float %2930, %2924
  %2934 = fadd fast float %2931, %2925
  br label %3098

; <label>:2935                                    ; preds = %2890
  %2936 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2893, i32 %2894, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2937 = extractvalue %dx.types.ResRet.f32 %2936, 0
  %2938 = fcmp fast ogt float %39, 5.000000e-01
  %2939 = fcmp fast olt float %2937, 1.000000e+00
  %2940 = and i1 %2938, %2939
  br i1 %2940, label %2941, label %3027

; <label>:2941                                    ; preds = %2935
  %2942 = sitofp i32 %2893 to float
  %2943 = sitofp i32 %2894 to float
  %2944 = fadd fast float %2942, 5.000000e-01
  %2945 = fadd fast float %2943, 5.000000e-01
  %2946 = fdiv fast float %2944, %46
  %2947 = fdiv fast float %2945, %47
  %2948 = fmul fast float %2946, 2.000000e+00
  %2949 = fmul fast float %2947, 2.000000e+00
  %2950 = fadd fast float %2948, -1.000000e+00
  %2951 = fsub fast float 1.000000e+00, %2949
  %2952 = fmul fast float %2950, %36
  %2953 = call float @dx.op.tertiary.f32(i32 46, float %2951, float %32, float %2952)  ; FMad(a,b,c)
  %2954 = call float @dx.op.tertiary.f32(i32 46, float %2937, float %28, float %2953)  ; FMad(a,b,c)
  %2955 = fadd fast float %2954, %24
  %2956 = call float @dx.op.unary.f32(i32 6, float %2955)  ; FAbs(value)
  %2957 = fcmp fast ogt float %2956, 0x3EB0C6F7A0000000
  br i1 %2957, label %2958, label %3027

; <label>:2958                                    ; preds = %2941
  %2959 = fmul fast float %2950, %35
  %2960 = call float @dx.op.tertiary.f32(i32 46, float %2951, float %31, float %2959)  ; FMad(a,b,c)
  %2961 = call float @dx.op.tertiary.f32(i32 46, float %2937, float %27, float %2960)  ; FMad(a,b,c)
  %2962 = fadd fast float %2961, %23
  %2963 = fmul fast float %2950, %34
  %2964 = call float @dx.op.tertiary.f32(i32 46, float %2951, float %30, float %2963)  ; FMad(a,b,c)
  %2965 = call float @dx.op.tertiary.f32(i32 46, float %2937, float %26, float %2964)  ; FMad(a,b,c)
  %2966 = fadd fast float %2965, %22
  %2967 = fmul fast float %2950, %33
  %2968 = call float @dx.op.tertiary.f32(i32 46, float %2951, float %29, float %2967)  ; FMad(a,b,c)
  %2969 = call float @dx.op.tertiary.f32(i32 46, float %2937, float %25, float %2968)  ; FMad(a,b,c)
  %2970 = fadd fast float %2969, %21
  %2971 = fdiv fast float %2970, %2955
  %2972 = fdiv fast float %2966, %2955
  %2973 = fdiv fast float %2962, %2955
  %2974 = fsub fast float %2971, %18
  %2975 = fsub fast float %2972, %19
  %2976 = fsub fast float %2973, %20
  %2977 = fmul fast float %2974, %2974
  %2978 = fmul fast float %2975, %2975
  %2979 = fadd fast float %2978, %2977
  %2980 = fmul fast float %2976, %2976
  %2981 = fadd fast float %2979, %2980
  %2982 = call float @dx.op.unary.f32(i32 24, float %2981)  ; Sqrt(value)
  %2983 = fsub fast float %2982, %10
  %2984 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2983)  ; FMax(a,b)
  %2985 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %2985, label %2986, label %3009

; <label>:2986                                    ; preds = %2958
  %2987 = call float @dx.op.unary.f32(i32 6, float %2975)  ; FAbs(value)
  %2988 = fmul fast float %2987, %12
  %2989 = fcmp fast olt float %2988, 0x3F50624DE0000000
  br i1 %2989, label %2990, label %2993

; <label>:2990                                    ; preds = %2986
  %2991 = fmul fast float %2988, 5.000000e-01
  %2992 = fsub fast float 1.000000e+00, %2991
  br label %2998

; <label>:2993                                    ; preds = %2986
  %2994 = fmul fast float %2988, 0xBFF7154760000000
  %2995 = call float @dx.op.unary.f32(i32 21, float %2994)  ; Exp(value)
  %2996 = fsub fast float 1.000000e+00, %2995
  %2997 = fdiv fast float %2996, %2988
  br label %2998

; <label>:2998                                    ; preds = %2993, %2990
  %2999 = phi float [ %2992, %2990 ], [ %2997, %2993 ]
  %3000 = call float @dx.op.binary.f32(i32 36, float %2972, float %19)  ; FMin(a,b)
  %3001 = fsub fast float %3000, %11
  %3002 = fmul fast float %12, %3001
  %3003 = fsub fast float -0.000000e+00, %3002
  %3004 = call float @dx.op.binary.f32(i32 35, float %3003, float -4.000000e+01)  ; FMax(a,b)
  %3005 = call float @dx.op.binary.f32(i32 36, float %3004, float 5.000000e+00)  ; FMin(a,b)
  %3006 = fmul fast float %3005, 0x3FF7154760000000
  %3007 = call float @dx.op.unary.f32(i32 21, float %3006)  ; Exp(value)
  %3008 = fmul fast float %3007, %2999
  br label %3009

; <label>:3009                                    ; preds = %2998, %2958
  %3010 = phi float [ %3008, %2998 ], [ 1.000000e+00, %2958 ]
  %3011 = fmul fast float %2984, %17
  %3012 = fmul fast float %3011, %3010
  %3013 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3012)  ; FMin(a,b)
  %3014 = fmul fast float %3013, 0xBFF7154760000000
  %3015 = call float @dx.op.unary.f32(i32 21, float %3014)  ; Exp(value)
  %3016 = fsub fast float 1.000000e+00, %3015
  %3017 = call float @dx.op.binary.f32(i32 36, float %13, float %3016)  ; FMin(a,b)
  %3018 = fsub fast float %14, %2896
  %3019 = fsub fast float %15, %2897
  %3020 = fsub fast float %16, %2898
  %3021 = fmul fast float %3017, %3018
  %3022 = fmul fast float %3017, %3019
  %3023 = fmul fast float %3017, %3020
  %3024 = fadd fast float %3021, %2896
  %3025 = fadd fast float %3022, %2897
  %3026 = fadd fast float %3023, %2898
  br label %3027

; <label>:3027                                    ; preds = %3009, %2941, %2935
  %3028 = phi float [ %3024, %3009 ], [ %2896, %2941 ], [ %2896, %2935 ]
  %3029 = phi float [ %3025, %3009 ], [ %2897, %2941 ], [ %2897, %2935 ]
  %3030 = phi float [ %3026, %3009 ], [ %2898, %2941 ], [ %2898, %2935 ]
  %3031 = fadd fast float %6, 1.000000e+00
  %3032 = fadd fast float %7, 1.000000e+00
  %3033 = fsub fast float 1.000000e+00, %6
  %3034 = fmul fast float %37, %3031
  %3035 = fmul fast float %37, %3032
  %3036 = fmul fast float %37, %3033
  %3037 = fmul fast float %3034, %3028
  %3038 = fmul fast float %3035, %3029
  %3039 = fmul fast float %3036, %3030
  %3040 = fcmp fast ult float %38, 5.000000e-01
  br i1 %3040, label %3066, label %3041

; <label>:3041                                    ; preds = %3027
  %3042 = fmul fast float %3037, 0x4004147AE0000000
  %3043 = fmul fast float %3038, 0x4004147AE0000000
  %3044 = fmul fast float %3039, 0x4004147AE0000000
  %3045 = fadd fast float %3042, 0x3F9EB851E0000000
  %3046 = fadd fast float %3043, 0x3F9EB851E0000000
  %3047 = fadd fast float %3044, 0x3F9EB851E0000000
  %3048 = fmul fast float %3045, %3037
  %3049 = fmul fast float %3046, %3038
  %3050 = fmul fast float %3047, %3039
  %3051 = fmul fast float %3037, 0x400370A3E0000000
  %3052 = fmul fast float %3038, 0x400370A3E0000000
  %3053 = fmul fast float %3039, 0x400370A3E0000000
  %3054 = fadd fast float %3051, 0x3FE2E147A0000000
  %3055 = fadd fast float %3052, 0x3FE2E147A0000000
  %3056 = fadd fast float %3053, 0x3FE2E147A0000000
  %3057 = fmul fast float %3054, %3037
  %3058 = fmul fast float %3055, %3038
  %3059 = fmul fast float %3056, %3039
  %3060 = fadd fast float %3057, 0x3FC1EB8520000000
  %3061 = fadd fast float %3058, 0x3FC1EB8520000000
  %3062 = fadd fast float %3059, 0x3FC1EB8520000000
  %3063 = fdiv fast float %3048, %3060
  %3064 = fdiv fast float %3049, %3061
  %3065 = fdiv fast float %3050, %3062
  br label %3066

; <label>:3066                                    ; preds = %3041, %3027
  %3067 = phi float [ %3063, %3041 ], [ %3037, %3027 ]
  %3068 = phi float [ %3064, %3041 ], [ %3038, %3027 ]
  %3069 = phi float [ %3065, %3041 ], [ %3039, %3027 ]
  %3070 = call float @dx.op.unary.f32(i32 7, float %3067)  ; Saturate(value)
  %3071 = call float @dx.op.unary.f32(i32 7, float %3068)  ; Saturate(value)
  %3072 = call float @dx.op.unary.f32(i32 7, float %3069)  ; Saturate(value)
  %3073 = call float @dx.op.dot3.f32(i32 55, float %3070, float %3071, float %3072, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3074 = fsub fast float %3070, %3073
  %3075 = fsub fast float %3071, %3073
  %3076 = fsub fast float %3072, %3073
  %3077 = fmul fast float %3074, %9
  %3078 = fmul fast float %3075, %9
  %3079 = fmul fast float %3076, %9
  %3080 = fadd fast float %3077, %3073
  %3081 = fadd fast float %3078, %3073
  %3082 = fadd fast float %3079, %3073
  %3083 = call float @dx.op.unary.f32(i32 7, float %3080)  ; Saturate(value)
  %3084 = call float @dx.op.unary.f32(i32 7, float %3081)  ; Saturate(value)
  %3085 = call float @dx.op.unary.f32(i32 7, float %3082)  ; Saturate(value)
  %3086 = fadd fast float %3083, 0xBFC70A3D80000000
  %3087 = fadd fast float %3084, 0xBFC70A3D80000000
  %3088 = fadd fast float %3085, 0xBFC70A3D80000000
  %3089 = fmul fast float %3086, %8
  %3090 = fmul fast float %3087, %8
  %3091 = fmul fast float %3088, %8
  %3092 = fadd fast float %3089, 0x3FC70A3D80000000
  %3093 = fadd fast float %3090, 0x3FC70A3D80000000
  %3094 = fadd fast float %3091, 0x3FC70A3D80000000
  %3095 = call float @dx.op.unary.f32(i32 7, float %3092)  ; Saturate(value)
  %3096 = call float @dx.op.unary.f32(i32 7, float %3093)  ; Saturate(value)
  %3097 = call float @dx.op.unary.f32(i32 7, float %3094)  ; Saturate(value)
  br label %3098

; <label>:3098                                    ; preds = %3066, %2901
  %3099 = phi float [ %2932, %2901 ], [ %3095, %3066 ]
  %3100 = phi float [ %2933, %2901 ], [ %3096, %3066 ]
  %3101 = phi float [ %2934, %2901 ], [ %3097, %3066 ]
  %3102 = fsub fast float %3099, %1001
  %3103 = fsub fast float %3100, %1002
  %3104 = fsub fast float %3101, %1003
  %3105 = fmul fast float %3102, %2888
  %3106 = fmul fast float %3103, %2888
  %3107 = fmul fast float %3104, %2888
  %3108 = fadd fast float %3105, %1001
  %3109 = fadd fast float %3106, %1002
  %3110 = fadd fast float %3107, %1003
  br label %3111

; <label>:3111                                    ; preds = %3098, %2875
  %3112 = phi float [ %3108, %3098 ], [ %1001, %2875 ]
  %3113 = phi float [ %3109, %3098 ], [ %1002, %2875 ]
  %3114 = phi float [ %3110, %3098 ], [ %1003, %2875 ]
  %3115 = fsub fast float %87, %89
  %3116 = call float @dx.op.unary.f32(i32 6, float %3115)  ; FAbs(value)
  %3117 = fdiv fast float %3116, %2883
  %3118 = fsub fast float 1.000000e+00, %3117
  %3119 = call float @dx.op.unary.f32(i32 7, float %3118)  ; Saturate(value)
  %3120 = fcmp fast ugt float %3119, 0.000000e+00
  br i1 %3120, label %3121, label %3131

; <label>:3121                                    ; preds = %3111
  %3122 = fsub fast float %799, %1001
  %3123 = fsub fast float %800, %1002
  %3124 = fsub fast float %801, %1003
  %3125 = fmul fast float %3119, %3122
  %3126 = fmul fast float %3119, %3123
  %3127 = fmul fast float %3119, %3124
  %3128 = fadd fast float %3125, %1001
  %3129 = fadd fast float %3126, %1002
  %3130 = fadd fast float %3127, %1003
  br label %3131

; <label>:3131                                    ; preds = %3121, %3111
  %3132 = phi float [ %3128, %3121 ], [ %1001, %3111 ]
  %3133 = phi float [ %3129, %3121 ], [ %1002, %3111 ]
  %3134 = phi float [ %3130, %3121 ], [ %1003, %3111 ]
  %3135 = add i32 %57, 2
  %3136 = call i32 @dx.op.binary.i32(i32 37, i32 %3135, i32 0)  ; IMax(a,b)
  %3137 = call i32 @dx.op.binary.i32(i32 38, i32 %3136, i32 %61)  ; IMin(a,b)
  %3138 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %68, i32 %3137, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3139 = extractvalue %dx.types.ResRet.f32 %3138, 0
  %3140 = fsub fast float %3139, %89
  %3141 = call float @dx.op.unary.f32(i32 6, float %3140)  ; FAbs(value)
  %3142 = fdiv fast float %3141, %2883
  %3143 = fsub fast float 1.000000e+00, %3142
  %3144 = call float @dx.op.unary.f32(i32 7, float %3143)  ; Saturate(value)
  %3145 = fcmp fast ugt float %3144, 0.000000e+00
  br i1 %3145, label %3146, label %3367

; <label>:3146                                    ; preds = %3131
  %3147 = call i32 @dx.op.binary.i32(i32 37, i32 %68, i32 0)  ; IMax(a,b)
  %3148 = call i32 @dx.op.binary.i32(i32 37, i32 %3137, i32 0)  ; IMax(a,b)
  %3149 = call i32 @dx.op.binary.i32(i32 38, i32 %3147, i32 %60)  ; IMin(a,b)
  %3150 = call i32 @dx.op.binary.i32(i32 38, i32 %3148, i32 %61)  ; IMin(a,b)
  %3151 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3149, i32 %3150, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3152 = extractvalue %dx.types.ResRet.f32 %3151, 0
  %3153 = extractvalue %dx.types.ResRet.f32 %3151, 1
  %3154 = extractvalue %dx.types.ResRet.f32 %3151, 2
  %3155 = extractvalue %dx.types.ResRet.f32 %3151, 3
  %3156 = fcmp fast olt float %3155, 0.000000e+00
  br i1 %3156, label %3157, label %3191

; <label>:3157                                    ; preds = %3146
  %3158 = fcmp fast ogt float %3152, 0x3FA4B5DCC0000000
  %3159 = fcmp fast ogt float %3153, 0x3FA4B5DCC0000000
  %3160 = fcmp fast ogt float %3154, 0x3FA4B5DCC0000000
  %3161 = select i1 %3158, float 0.000000e+00, float 1.000000e+00
  %3162 = select i1 %3159, float 0.000000e+00, float 1.000000e+00
  %3163 = select i1 %3160, float 0.000000e+00, float 1.000000e+00
  %3164 = fmul fast float %3152, 0x3FB3D07220000000
  %3165 = fmul fast float %3153, 0x3FB3D07220000000
  %3166 = fmul fast float %3154, 0x3FB3D07220000000
  %3167 = fadd fast float %3152, 0x3FAC28F5C0000000
  %3168 = fadd fast float %3153, 0x3FAC28F5C0000000
  %3169 = fadd fast float %3154, 0x3FAC28F5C0000000
  %3170 = fmul fast float %3167, 0x3FEE54EDE0000000
  %3171 = fmul fast float %3168, 0x3FEE54EDE0000000
  %3172 = fmul fast float %3169, 0x3FEE54EDE0000000
  %3173 = call float @dx.op.unary.f32(i32 23, float %3170)  ; Log(value)
  %3174 = call float @dx.op.unary.f32(i32 23, float %3171)  ; Log(value)
  %3175 = call float @dx.op.unary.f32(i32 23, float %3172)  ; Log(value)
  %3176 = fmul fast float %3173, 0x4003333340000000
  %3177 = fmul fast float %3174, 0x4003333340000000
  %3178 = fmul fast float %3175, 0x4003333340000000
  %3179 = call float @dx.op.unary.f32(i32 21, float %3176)  ; Exp(value)
  %3180 = call float @dx.op.unary.f32(i32 21, float %3177)  ; Exp(value)
  %3181 = call float @dx.op.unary.f32(i32 21, float %3178)  ; Exp(value)
  %3182 = fsub fast float %3164, %3179
  %3183 = fsub fast float %3165, %3180
  %3184 = fsub fast float %3166, %3181
  %3185 = fmul fast float %3182, %3161
  %3186 = fmul fast float %3183, %3162
  %3187 = fmul fast float %3184, %3163
  %3188 = fadd fast float %3185, %3179
  %3189 = fadd fast float %3186, %3180
  %3190 = fadd fast float %3187, %3181
  br label %3354

; <label>:3191                                    ; preds = %3146
  %3192 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3149, i32 %3150, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3193 = extractvalue %dx.types.ResRet.f32 %3192, 0
  %3194 = fcmp fast ogt float %39, 5.000000e-01
  %3195 = fcmp fast olt float %3193, 1.000000e+00
  %3196 = and i1 %3194, %3195
  br i1 %3196, label %3197, label %3283

; <label>:3197                                    ; preds = %3191
  %3198 = sitofp i32 %3149 to float
  %3199 = sitofp i32 %3150 to float
  %3200 = fadd fast float %3198, 5.000000e-01
  %3201 = fadd fast float %3199, 5.000000e-01
  %3202 = fdiv fast float %3200, %46
  %3203 = fdiv fast float %3201, %47
  %3204 = fmul fast float %3202, 2.000000e+00
  %3205 = fmul fast float %3203, 2.000000e+00
  %3206 = fadd fast float %3204, -1.000000e+00
  %3207 = fsub fast float 1.000000e+00, %3205
  %3208 = fmul fast float %3206, %36
  %3209 = call float @dx.op.tertiary.f32(i32 46, float %3207, float %32, float %3208)  ; FMad(a,b,c)
  %3210 = call float @dx.op.tertiary.f32(i32 46, float %3193, float %28, float %3209)  ; FMad(a,b,c)
  %3211 = fadd fast float %3210, %24
  %3212 = call float @dx.op.unary.f32(i32 6, float %3211)  ; FAbs(value)
  %3213 = fcmp fast ogt float %3212, 0x3EB0C6F7A0000000
  br i1 %3213, label %3214, label %3283

; <label>:3214                                    ; preds = %3197
  %3215 = fmul fast float %3206, %35
  %3216 = call float @dx.op.tertiary.f32(i32 46, float %3207, float %31, float %3215)  ; FMad(a,b,c)
  %3217 = call float @dx.op.tertiary.f32(i32 46, float %3193, float %27, float %3216)  ; FMad(a,b,c)
  %3218 = fadd fast float %3217, %23
  %3219 = fmul fast float %3206, %34
  %3220 = call float @dx.op.tertiary.f32(i32 46, float %3207, float %30, float %3219)  ; FMad(a,b,c)
  %3221 = call float @dx.op.tertiary.f32(i32 46, float %3193, float %26, float %3220)  ; FMad(a,b,c)
  %3222 = fadd fast float %3221, %22
  %3223 = fmul fast float %3206, %33
  %3224 = call float @dx.op.tertiary.f32(i32 46, float %3207, float %29, float %3223)  ; FMad(a,b,c)
  %3225 = call float @dx.op.tertiary.f32(i32 46, float %3193, float %25, float %3224)  ; FMad(a,b,c)
  %3226 = fadd fast float %3225, %21
  %3227 = fdiv fast float %3226, %3211
  %3228 = fdiv fast float %3222, %3211
  %3229 = fdiv fast float %3218, %3211
  %3230 = fsub fast float %3227, %18
  %3231 = fsub fast float %3228, %19
  %3232 = fsub fast float %3229, %20
  %3233 = fmul fast float %3230, %3230
  %3234 = fmul fast float %3231, %3231
  %3235 = fadd fast float %3234, %3233
  %3236 = fmul fast float %3232, %3232
  %3237 = fadd fast float %3235, %3236
  %3238 = call float @dx.op.unary.f32(i32 24, float %3237)  ; Sqrt(value)
  %3239 = fsub fast float %3238, %10
  %3240 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3239)  ; FMax(a,b)
  %3241 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %3241, label %3242, label %3265

; <label>:3242                                    ; preds = %3214
  %3243 = call float @dx.op.unary.f32(i32 6, float %3231)  ; FAbs(value)
  %3244 = fmul fast float %3243, %12
  %3245 = fcmp fast olt float %3244, 0x3F50624DE0000000
  br i1 %3245, label %3246, label %3249

; <label>:3246                                    ; preds = %3242
  %3247 = fmul fast float %3244, 5.000000e-01
  %3248 = fsub fast float 1.000000e+00, %3247
  br label %3254

; <label>:3249                                    ; preds = %3242
  %3250 = fmul fast float %3244, 0xBFF7154760000000
  %3251 = call float @dx.op.unary.f32(i32 21, float %3250)  ; Exp(value)
  %3252 = fsub fast float 1.000000e+00, %3251
  %3253 = fdiv fast float %3252, %3244
  br label %3254

; <label>:3254                                    ; preds = %3249, %3246
  %3255 = phi float [ %3248, %3246 ], [ %3253, %3249 ]
  %3256 = call float @dx.op.binary.f32(i32 36, float %3228, float %19)  ; FMin(a,b)
  %3257 = fsub fast float %3256, %11
  %3258 = fmul fast float %12, %3257
  %3259 = fsub fast float -0.000000e+00, %3258
  %3260 = call float @dx.op.binary.f32(i32 35, float %3259, float -4.000000e+01)  ; FMax(a,b)
  %3261 = call float @dx.op.binary.f32(i32 36, float %3260, float 5.000000e+00)  ; FMin(a,b)
  %3262 = fmul fast float %3261, 0x3FF7154760000000
  %3263 = call float @dx.op.unary.f32(i32 21, float %3262)  ; Exp(value)
  %3264 = fmul fast float %3263, %3255
  br label %3265

; <label>:3265                                    ; preds = %3254, %3214
  %3266 = phi float [ %3264, %3254 ], [ 1.000000e+00, %3214 ]
  %3267 = fmul fast float %3240, %17
  %3268 = fmul fast float %3267, %3266
  %3269 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3268)  ; FMin(a,b)
  %3270 = fmul fast float %3269, 0xBFF7154760000000
  %3271 = call float @dx.op.unary.f32(i32 21, float %3270)  ; Exp(value)
  %3272 = fsub fast float 1.000000e+00, %3271
  %3273 = call float @dx.op.binary.f32(i32 36, float %13, float %3272)  ; FMin(a,b)
  %3274 = fsub fast float %14, %3152
  %3275 = fsub fast float %15, %3153
  %3276 = fsub fast float %16, %3154
  %3277 = fmul fast float %3273, %3274
  %3278 = fmul fast float %3273, %3275
  %3279 = fmul fast float %3273, %3276
  %3280 = fadd fast float %3277, %3152
  %3281 = fadd fast float %3278, %3153
  %3282 = fadd fast float %3279, %3154
  br label %3283

; <label>:3283                                    ; preds = %3265, %3197, %3191
  %3284 = phi float [ %3280, %3265 ], [ %3152, %3197 ], [ %3152, %3191 ]
  %3285 = phi float [ %3281, %3265 ], [ %3153, %3197 ], [ %3153, %3191 ]
  %3286 = phi float [ %3282, %3265 ], [ %3154, %3197 ], [ %3154, %3191 ]
  %3287 = fadd fast float %6, 1.000000e+00
  %3288 = fadd fast float %7, 1.000000e+00
  %3289 = fsub fast float 1.000000e+00, %6
  %3290 = fmul fast float %37, %3287
  %3291 = fmul fast float %37, %3288
  %3292 = fmul fast float %37, %3289
  %3293 = fmul fast float %3290, %3284
  %3294 = fmul fast float %3291, %3285
  %3295 = fmul fast float %3292, %3286
  %3296 = fcmp fast ult float %38, 5.000000e-01
  br i1 %3296, label %3322, label %3297

; <label>:3297                                    ; preds = %3283
  %3298 = fmul fast float %3293, 0x4004147AE0000000
  %3299 = fmul fast float %3294, 0x4004147AE0000000
  %3300 = fmul fast float %3295, 0x4004147AE0000000
  %3301 = fadd fast float %3298, 0x3F9EB851E0000000
  %3302 = fadd fast float %3299, 0x3F9EB851E0000000
  %3303 = fadd fast float %3300, 0x3F9EB851E0000000
  %3304 = fmul fast float %3301, %3293
  %3305 = fmul fast float %3302, %3294
  %3306 = fmul fast float %3303, %3295
  %3307 = fmul fast float %3293, 0x400370A3E0000000
  %3308 = fmul fast float %3294, 0x400370A3E0000000
  %3309 = fmul fast float %3295, 0x400370A3E0000000
  %3310 = fadd fast float %3307, 0x3FE2E147A0000000
  %3311 = fadd fast float %3308, 0x3FE2E147A0000000
  %3312 = fadd fast float %3309, 0x3FE2E147A0000000
  %3313 = fmul fast float %3310, %3293
  %3314 = fmul fast float %3311, %3294
  %3315 = fmul fast float %3312, %3295
  %3316 = fadd fast float %3313, 0x3FC1EB8520000000
  %3317 = fadd fast float %3314, 0x3FC1EB8520000000
  %3318 = fadd fast float %3315, 0x3FC1EB8520000000
  %3319 = fdiv fast float %3304, %3316
  %3320 = fdiv fast float %3305, %3317
  %3321 = fdiv fast float %3306, %3318
  br label %3322

; <label>:3322                                    ; preds = %3297, %3283
  %3323 = phi float [ %3319, %3297 ], [ %3293, %3283 ]
  %3324 = phi float [ %3320, %3297 ], [ %3294, %3283 ]
  %3325 = phi float [ %3321, %3297 ], [ %3295, %3283 ]
  %3326 = call float @dx.op.unary.f32(i32 7, float %3323)  ; Saturate(value)
  %3327 = call float @dx.op.unary.f32(i32 7, float %3324)  ; Saturate(value)
  %3328 = call float @dx.op.unary.f32(i32 7, float %3325)  ; Saturate(value)
  %3329 = call float @dx.op.dot3.f32(i32 55, float %3326, float %3327, float %3328, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3330 = fsub fast float %3326, %3329
  %3331 = fsub fast float %3327, %3329
  %3332 = fsub fast float %3328, %3329
  %3333 = fmul fast float %3330, %9
  %3334 = fmul fast float %3331, %9
  %3335 = fmul fast float %3332, %9
  %3336 = fadd fast float %3333, %3329
  %3337 = fadd fast float %3334, %3329
  %3338 = fadd fast float %3335, %3329
  %3339 = call float @dx.op.unary.f32(i32 7, float %3336)  ; Saturate(value)
  %3340 = call float @dx.op.unary.f32(i32 7, float %3337)  ; Saturate(value)
  %3341 = call float @dx.op.unary.f32(i32 7, float %3338)  ; Saturate(value)
  %3342 = fadd fast float %3339, 0xBFC70A3D80000000
  %3343 = fadd fast float %3340, 0xBFC70A3D80000000
  %3344 = fadd fast float %3341, 0xBFC70A3D80000000
  %3345 = fmul fast float %3342, %8
  %3346 = fmul fast float %3343, %8
  %3347 = fmul fast float %3344, %8
  %3348 = fadd fast float %3345, 0x3FC70A3D80000000
  %3349 = fadd fast float %3346, 0x3FC70A3D80000000
  %3350 = fadd fast float %3347, 0x3FC70A3D80000000
  %3351 = call float @dx.op.unary.f32(i32 7, float %3348)  ; Saturate(value)
  %3352 = call float @dx.op.unary.f32(i32 7, float %3349)  ; Saturate(value)
  %3353 = call float @dx.op.unary.f32(i32 7, float %3350)  ; Saturate(value)
  br label %3354

; <label>:3354                                    ; preds = %3322, %3157
  %3355 = phi float [ %3188, %3157 ], [ %3351, %3322 ]
  %3356 = phi float [ %3189, %3157 ], [ %3352, %3322 ]
  %3357 = phi float [ %3190, %3157 ], [ %3353, %3322 ]
  %3358 = fsub fast float %3355, %1001
  %3359 = fsub fast float %3356, %1002
  %3360 = fsub fast float %3357, %1003
  %3361 = fmul fast float %3358, %3144
  %3362 = fmul fast float %3359, %3144
  %3363 = fmul fast float %3360, %3144
  %3364 = fadd fast float %3361, %1001
  %3365 = fadd fast float %3362, %1002
  %3366 = fadd fast float %3363, %1003
  br label %3367

; <label>:3367                                    ; preds = %3354, %3131
  %3368 = phi float [ %3364, %3354 ], [ %1001, %3131 ]
  %3369 = phi float [ %3365, %3354 ], [ %1002, %3131 ]
  %3370 = phi float [ %3366, %3354 ], [ %1003, %3131 ]
  %3371 = fsub fast float %85, %89
  %3372 = call float @dx.op.unary.f32(i32 6, float %3371)  ; FAbs(value)
  %3373 = fdiv fast float %3372, %2883
  %3374 = fsub fast float 1.000000e+00, %3373
  %3375 = call float @dx.op.unary.f32(i32 7, float %3374)  ; Saturate(value)
  %3376 = fcmp fast ugt float %3375, 0.000000e+00
  br i1 %3376, label %3377, label %3387

; <label>:3377                                    ; preds = %3367
  %3378 = fsub fast float %597, %1001
  %3379 = fsub fast float %598, %1002
  %3380 = fsub fast float %599, %1003
  %3381 = fmul fast float %3375, %3378
  %3382 = fmul fast float %3375, %3379
  %3383 = fmul fast float %3375, %3380
  %3384 = fadd fast float %3381, %1001
  %3385 = fadd fast float %3382, %1002
  %3386 = fadd fast float %3383, %1003
  br label %3387

; <label>:3387                                    ; preds = %3377, %3367
  %3388 = phi float [ %3384, %3377 ], [ %1001, %3367 ]
  %3389 = phi float [ %3385, %3377 ], [ %1002, %3367 ]
  %3390 = phi float [ %3386, %3377 ], [ %1003, %3367 ]
  %3391 = call float @dx.op.binary.f32(i32 36, float %3132, float %3112)  ; FMin(a,b)
  %3392 = call float @dx.op.binary.f32(i32 36, float %3133, float %3113)  ; FMin(a,b)
  %3393 = call float @dx.op.binary.f32(i32 36, float %3134, float %3114)  ; FMin(a,b)
  %3394 = call float @dx.op.binary.f32(i32 36, float %3388, float %3368)  ; FMin(a,b)
  %3395 = call float @dx.op.binary.f32(i32 36, float %3389, float %3369)  ; FMin(a,b)
  %3396 = call float @dx.op.binary.f32(i32 36, float %3390, float %3370)  ; FMin(a,b)
  %3397 = call float @dx.op.binary.f32(i32 36, float %3394, float %3391)  ; FMin(a,b)
  %3398 = call float @dx.op.binary.f32(i32 36, float %3395, float %3392)  ; FMin(a,b)
  %3399 = call float @dx.op.binary.f32(i32 36, float %3396, float %3393)  ; FMin(a,b)
  %3400 = call float @dx.op.binary.f32(i32 36, float %1001, float %3397)  ; FMin(a,b)
  %3401 = call float @dx.op.binary.f32(i32 36, float %1002, float %3398)  ; FMin(a,b)
  %3402 = call float @dx.op.binary.f32(i32 36, float %1003, float %3399)  ; FMin(a,b)
  %3403 = call float @dx.op.binary.f32(i32 35, float %3132, float %3112)  ; FMax(a,b)
  %3404 = call float @dx.op.binary.f32(i32 35, float %3133, float %3113)  ; FMax(a,b)
  %3405 = call float @dx.op.binary.f32(i32 35, float %3134, float %3114)  ; FMax(a,b)
  %3406 = call float @dx.op.binary.f32(i32 35, float %3388, float %3368)  ; FMax(a,b)
  %3407 = call float @dx.op.binary.f32(i32 35, float %3389, float %3369)  ; FMax(a,b)
  %3408 = call float @dx.op.binary.f32(i32 35, float %3390, float %3370)  ; FMax(a,b)
  %3409 = call float @dx.op.binary.f32(i32 35, float %3406, float %3403)  ; FMax(a,b)
  %3410 = call float @dx.op.binary.f32(i32 35, float %3407, float %3404)  ; FMax(a,b)
  %3411 = call float @dx.op.binary.f32(i32 35, float %3408, float %3405)  ; FMax(a,b)
  %3412 = call float @dx.op.binary.f32(i32 35, float %1001, float %3409)  ; FMax(a,b)
  %3413 = call float @dx.op.binary.f32(i32 35, float %1002, float %3410)  ; FMax(a,b)
  %3414 = call float @dx.op.binary.f32(i32 35, float %1003, float %3411)  ; FMax(a,b)
  %3415 = fsub fast float %3412, %3400
  %3416 = fsub fast float %3413, %3401
  %3417 = fsub fast float %3414, %3402
  %3418 = call float @dx.op.unary.f32(i32 6, float %3415)  ; FAbs(value)
  %3419 = call float @dx.op.unary.f32(i32 6, float %3416)  ; FAbs(value)
  %3420 = call float @dx.op.unary.f32(i32 6, float %3417)  ; FAbs(value)
  %3421 = call float @dx.op.binary.f32(i32 35, float %3419, float %3420)  ; FMax(a,b)
  %3422 = call float @dx.op.binary.f32(i32 35, float %3418, float %3421)  ; FMax(a,b)
  %3423 = call float @dx.op.binary.f32(i32 35, float %3413, float %3414)  ; FMax(a,b)
  %3424 = call float @dx.op.binary.f32(i32 35, float %3412, float %3423)  ; FMax(a,b)
  %3425 = fmul fast float %3424, 1.250000e-01
  %3426 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %3425)  ; FMax(a,b)
  %3427 = fcmp fast ogt float %3422, %3426
  br i1 %3427, label %3428, label %8522

; <label>:3428                                    ; preds = %3387
  %3429 = fsub fast float %3388, %3368
  %3430 = fsub fast float %3389, %3369
  %3431 = fsub fast float %3390, %3370
  %3432 = call float @dx.op.unary.f32(i32 6, float %3429)  ; FAbs(value)
  %3433 = call float @dx.op.unary.f32(i32 6, float %3430)  ; FAbs(value)
  %3434 = call float @dx.op.unary.f32(i32 6, float %3431)  ; FAbs(value)
  %3435 = call float @dx.op.binary.f32(i32 35, float %3433, float %3434)  ; FMax(a,b)
  %3436 = call float @dx.op.binary.f32(i32 35, float %3432, float %3435)  ; FMax(a,b)
  %3437 = fsub fast float %3132, %3112
  %3438 = fsub fast float %3133, %3113
  %3439 = fsub fast float %3134, %3114
  %3440 = call float @dx.op.unary.f32(i32 6, float %3437)  ; FAbs(value)
  %3441 = call float @dx.op.unary.f32(i32 6, float %3438)  ; FAbs(value)
  %3442 = call float @dx.op.unary.f32(i32 6, float %3439)  ; FAbs(value)
  %3443 = call float @dx.op.binary.f32(i32 35, float %3441, float %3442)  ; FMax(a,b)
  %3444 = call float @dx.op.binary.f32(i32 35, float %3440, float %3443)  ; FMax(a,b)
  %3445 = fcmp fast olt float %3436, %3444
  %3446 = select i1 %3445, float %3388, float %3132
  %3447 = select i1 %3445, float %3389, float %3133
  %3448 = select i1 %3445, float %3390, float %3134
  %3449 = select i1 %3445, float %3368, float %3112
  %3450 = select i1 %3445, float %3369, float %3113
  %3451 = select i1 %3445, float %3370, float %3114
  %3452 = fsub fast float %1001, %3449
  %3453 = fsub fast float %1002, %3450
  %3454 = fsub fast float %1003, %3451
  %3455 = fsub fast float %1001, %3446
  %3456 = fsub fast float %1002, %3447
  %3457 = fsub fast float %1003, %3448
  %3458 = call float @dx.op.dot3.f32(i32 55, float %3455, float %3456, float %3457, float %3452, float %3453, float %3454)  ; Dot3(ax,ay,az,bx,by,bz)
  %3459 = fcmp fast ogt float %3458, 0.000000e+00
  br i1 %3459, label %3460, label %3472

; <label>:3460                                    ; preds = %3428
  %3461 = fsub fast float %3446, %3449
  %3462 = fsub fast float %3447, %3450
  %3463 = fsub fast float %3448, %3451
  %3464 = call float @dx.op.unary.f32(i32 6, float %3461)  ; FAbs(value)
  %3465 = call float @dx.op.unary.f32(i32 6, float %3462)  ; FAbs(value)
  %3466 = call float @dx.op.unary.f32(i32 6, float %3463)  ; FAbs(value)
  %3467 = call float @dx.op.binary.f32(i32 35, float %3465, float %3466)  ; FMax(a,b)
  %3468 = call float @dx.op.binary.f32(i32 35, float %3464, float %3467)  ; FMax(a,b)
  %3469 = fmul fast float %3422, 2.500000e-01
  %3470 = fcmp fast olt float %3468, %3469
  %3471 = select i1 %3470, float 5.000000e-01, float 1.000000e+00
  br label %3472

; <label>:3472                                    ; preds = %3460, %3428
  %3473 = phi float [ 1.000000e+00, %3428 ], [ %3471, %3460 ]
  %3474 = fmul fast float %3473, %3
  %3475 = fadd fast float %3446, %3449
  %3476 = fadd fast float %3447, %3450
  %3477 = fadd fast float %3448, %3451
  %3478 = fmul fast float %3475, 5.000000e-01
  %3479 = fmul fast float %3476, 5.000000e-01
  %3480 = fmul fast float %3477, 5.000000e-01
  %3481 = fsub fast float %3478, %1001
  %3482 = fsub fast float %3479, %1002
  %3483 = fsub fast float %3480, %1003
  %3484 = fmul fast float %3474, %3481
  %3485 = fmul fast float %3474, %3482
  %3486 = fmul fast float %3474, %3483
  %3487 = fadd fast float %3484, %1001
  %3488 = fadd fast float %3485, %1002
  %3489 = fadd fast float %3486, %1003
  br label %8522

; <label>:3490                                    ; preds = %173
  %3491 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %64, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3492 = extractvalue %dx.types.ResRet.f32 %3491, 0
  %3493 = extractvalue %dx.types.ResRet.f32 %3491, 1
  %3494 = extractvalue %dx.types.ResRet.f32 %3491, 2
  %3495 = extractvalue %dx.types.ResRet.f32 %3491, 3
  %3496 = fcmp fast olt float %3495, 0.000000e+00
  br i1 %3496, label %3497, label %3532

; <label>:3497                                    ; preds = %3490
  %3498 = fcmp fast ogt float %3492, 0x3FA4B5DCC0000000
  %3499 = fcmp fast ogt float %3493, 0x3FA4B5DCC0000000
  %3500 = fcmp fast ogt float %3494, 0x3FA4B5DCC0000000
  %3501 = select i1 %3498, float 0.000000e+00, float 1.000000e+00
  %3502 = select i1 %3499, float 0.000000e+00, float 1.000000e+00
  %3503 = select i1 %3500, float 0.000000e+00, float 1.000000e+00
  %3504 = fmul fast float %3492, 0x3FB3D07220000000
  %3505 = fmul fast float %3493, 0x3FB3D07220000000
  %3506 = fmul fast float %3494, 0x3FB3D07220000000
  %3507 = fadd fast float %3492, 0x3FAC28F5C0000000
  %3508 = fadd fast float %3493, 0x3FAC28F5C0000000
  %3509 = fadd fast float %3494, 0x3FAC28F5C0000000
  %3510 = fmul fast float %3507, 0x3FEE54EDE0000000
  %3511 = fmul fast float %3508, 0x3FEE54EDE0000000
  %3512 = fmul fast float %3509, 0x3FEE54EDE0000000
  %3513 = call float @dx.op.unary.f32(i32 23, float %3510)  ; Log(value)
  %3514 = call float @dx.op.unary.f32(i32 23, float %3511)  ; Log(value)
  %3515 = call float @dx.op.unary.f32(i32 23, float %3512)  ; Log(value)
  %3516 = fmul fast float %3513, 0x4003333340000000
  %3517 = fmul fast float %3514, 0x4003333340000000
  %3518 = fmul fast float %3515, 0x4003333340000000
  %3519 = call float @dx.op.unary.f32(i32 21, float %3516)  ; Exp(value)
  %3520 = call float @dx.op.unary.f32(i32 21, float %3517)  ; Exp(value)
  %3521 = call float @dx.op.unary.f32(i32 21, float %3518)  ; Exp(value)
  %3522 = fsub fast float %3504, %3519
  %3523 = fsub fast float %3505, %3520
  %3524 = fsub fast float %3506, %3521
  %3525 = fmul fast float %3522, %3501
  %3526 = fmul fast float %3523, %3502
  %3527 = fmul fast float %3524, %3503
  %3528 = fadd fast float %3525, %3519
  %3529 = fadd fast float %3526, %3520
  %3530 = fadd fast float %3527, %3521
  %3531 = fsub fast float -1.000000e+00, %3495
  br label %4745

; <label>:3532                                    ; preds = %3490
  %3533 = fcmp fast ogt float %39, 5.000000e-01
  %3534 = fcmp fast olt float %83, 1.000000e+00
  %3535 = and i1 %3533, %3534
  br i1 %3535, label %3536, label %3622

; <label>:3536                                    ; preds = %3532
  %3537 = sitofp i32 %64 to float
  %3538 = sitofp i32 %65 to float
  %3539 = fadd fast float %3537, 5.000000e-01
  %3540 = fadd fast float %3538, 5.000000e-01
  %3541 = fdiv fast float %3539, %46
  %3542 = fdiv fast float %3540, %47
  %3543 = fmul fast float %3541, 2.000000e+00
  %3544 = fmul fast float %3542, 2.000000e+00
  %3545 = fadd fast float %3543, -1.000000e+00
  %3546 = fsub fast float 1.000000e+00, %3544
  %3547 = fmul fast float %3545, %36
  %3548 = call float @dx.op.tertiary.f32(i32 46, float %3546, float %32, float %3547)  ; FMad(a,b,c)
  %3549 = call float @dx.op.tertiary.f32(i32 46, float %83, float %28, float %3548)  ; FMad(a,b,c)
  %3550 = fadd fast float %3549, %24
  %3551 = call float @dx.op.unary.f32(i32 6, float %3550)  ; FAbs(value)
  %3552 = fcmp fast ogt float %3551, 0x3EB0C6F7A0000000
  br i1 %3552, label %3553, label %3622

; <label>:3553                                    ; preds = %3536
  %3554 = fmul fast float %3545, %35
  %3555 = call float @dx.op.tertiary.f32(i32 46, float %3546, float %31, float %3554)  ; FMad(a,b,c)
  %3556 = call float @dx.op.tertiary.f32(i32 46, float %83, float %27, float %3555)  ; FMad(a,b,c)
  %3557 = fadd fast float %3556, %23
  %3558 = fmul fast float %3545, %34
  %3559 = call float @dx.op.tertiary.f32(i32 46, float %3546, float %30, float %3558)  ; FMad(a,b,c)
  %3560 = call float @dx.op.tertiary.f32(i32 46, float %83, float %26, float %3559)  ; FMad(a,b,c)
  %3561 = fadd fast float %3560, %22
  %3562 = fmul fast float %3545, %33
  %3563 = call float @dx.op.tertiary.f32(i32 46, float %3546, float %29, float %3562)  ; FMad(a,b,c)
  %3564 = call float @dx.op.tertiary.f32(i32 46, float %83, float %25, float %3563)  ; FMad(a,b,c)
  %3565 = fadd fast float %3564, %21
  %3566 = fdiv fast float %3565, %3550
  %3567 = fdiv fast float %3561, %3550
  %3568 = fdiv fast float %3557, %3550
  %3569 = fsub fast float %3566, %18
  %3570 = fsub fast float %3567, %19
  %3571 = fsub fast float %3568, %20
  %3572 = fmul fast float %3569, %3569
  %3573 = fmul fast float %3570, %3570
  %3574 = fadd fast float %3573, %3572
  %3575 = fmul fast float %3571, %3571
  %3576 = fadd fast float %3574, %3575
  %3577 = call float @dx.op.unary.f32(i32 24, float %3576)  ; Sqrt(value)
  %3578 = fsub fast float %3577, %10
  %3579 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3578)  ; FMax(a,b)
  %3580 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %3580, label %3581, label %3604

; <label>:3581                                    ; preds = %3553
  %3582 = call float @dx.op.unary.f32(i32 6, float %3570)  ; FAbs(value)
  %3583 = fmul fast float %3582, %12
  %3584 = fcmp fast olt float %3583, 0x3F50624DE0000000
  br i1 %3584, label %3585, label %3588

; <label>:3585                                    ; preds = %3581
  %3586 = fmul fast float %3583, 5.000000e-01
  %3587 = fsub fast float 1.000000e+00, %3586
  br label %3593

; <label>:3588                                    ; preds = %3581
  %3589 = fmul fast float %3583, 0xBFF7154760000000
  %3590 = call float @dx.op.unary.f32(i32 21, float %3589)  ; Exp(value)
  %3591 = fsub fast float 1.000000e+00, %3590
  %3592 = fdiv fast float %3591, %3583
  br label %3593

; <label>:3593                                    ; preds = %3588, %3585
  %3594 = phi float [ %3587, %3585 ], [ %3592, %3588 ]
  %3595 = call float @dx.op.binary.f32(i32 36, float %3567, float %19)  ; FMin(a,b)
  %3596 = fsub fast float %3595, %11
  %3597 = fmul fast float %12, %3596
  %3598 = fsub fast float -0.000000e+00, %3597
  %3599 = call float @dx.op.binary.f32(i32 35, float %3598, float -4.000000e+01)  ; FMax(a,b)
  %3600 = call float @dx.op.binary.f32(i32 36, float %3599, float 5.000000e+00)  ; FMin(a,b)
  %3601 = fmul fast float %3600, 0x3FF7154760000000
  %3602 = call float @dx.op.unary.f32(i32 21, float %3601)  ; Exp(value)
  %3603 = fmul fast float %3602, %3594
  br label %3604

; <label>:3604                                    ; preds = %3593, %3553
  %3605 = phi float [ %3603, %3593 ], [ 1.000000e+00, %3553 ]
  %3606 = fmul fast float %3579, %17
  %3607 = fmul fast float %3606, %3605
  %3608 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3607)  ; FMin(a,b)
  %3609 = fmul fast float %3608, 0xBFF7154760000000
  %3610 = call float @dx.op.unary.f32(i32 21, float %3609)  ; Exp(value)
  %3611 = fsub fast float 1.000000e+00, %3610
  %3612 = call float @dx.op.binary.f32(i32 36, float %13, float %3611)  ; FMin(a,b)
  %3613 = fsub fast float %14, %3492
  %3614 = fsub fast float %15, %3493
  %3615 = fsub fast float %16, %3494
  %3616 = fmul fast float %3612, %3613
  %3617 = fmul fast float %3612, %3614
  %3618 = fmul fast float %3612, %3615
  %3619 = fadd fast float %3616, %3492
  %3620 = fadd fast float %3617, %3493
  %3621 = fadd fast float %3618, %3494
  br label %3622

; <label>:3622                                    ; preds = %3604, %3536, %3532
  %3623 = phi float [ %3619, %3604 ], [ %3492, %3536 ], [ %3492, %3532 ]
  %3624 = phi float [ %3620, %3604 ], [ %3493, %3536 ], [ %3493, %3532 ]
  %3625 = phi float [ %3621, %3604 ], [ %3494, %3536 ], [ %3494, %3532 ]
  %3626 = fadd fast float %6, 1.000000e+00
  %3627 = fadd fast float %7, 1.000000e+00
  %3628 = fsub fast float 1.000000e+00, %6
  %3629 = fmul fast float %37, %3626
  %3630 = fmul fast float %37, %3627
  %3631 = fmul fast float %37, %3628
  %3632 = fmul fast float %3629, %3623
  %3633 = fmul fast float %3630, %3624
  %3634 = fmul fast float %3631, %3625
  %3635 = fcmp fast ult float %38, 5.000000e-01
  br i1 %3635, label %3661, label %3636

; <label>:3636                                    ; preds = %3622
  %3637 = fmul fast float %3632, 0x4004147AE0000000
  %3638 = fmul fast float %3633, 0x4004147AE0000000
  %3639 = fmul fast float %3634, 0x4004147AE0000000
  %3640 = fadd fast float %3637, 0x3F9EB851E0000000
  %3641 = fadd fast float %3638, 0x3F9EB851E0000000
  %3642 = fadd fast float %3639, 0x3F9EB851E0000000
  %3643 = fmul fast float %3640, %3632
  %3644 = fmul fast float %3641, %3633
  %3645 = fmul fast float %3642, %3634
  %3646 = fmul fast float %3632, 0x400370A3E0000000
  %3647 = fmul fast float %3633, 0x400370A3E0000000
  %3648 = fmul fast float %3634, 0x400370A3E0000000
  %3649 = fadd fast float %3646, 0x3FE2E147A0000000
  %3650 = fadd fast float %3647, 0x3FE2E147A0000000
  %3651 = fadd fast float %3648, 0x3FE2E147A0000000
  %3652 = fmul fast float %3649, %3632
  %3653 = fmul fast float %3650, %3633
  %3654 = fmul fast float %3651, %3634
  %3655 = fadd fast float %3652, 0x3FC1EB8520000000
  %3656 = fadd fast float %3653, 0x3FC1EB8520000000
  %3657 = fadd fast float %3654, 0x3FC1EB8520000000
  %3658 = fdiv fast float %3643, %3655
  %3659 = fdiv fast float %3644, %3656
  %3660 = fdiv fast float %3645, %3657
  br label %3661

; <label>:3661                                    ; preds = %3636, %3622
  %3662 = phi float [ %3658, %3636 ], [ %3632, %3622 ]
  %3663 = phi float [ %3659, %3636 ], [ %3633, %3622 ]
  %3664 = phi float [ %3660, %3636 ], [ %3634, %3622 ]
  %3665 = call float @dx.op.unary.f32(i32 7, float %3662)  ; Saturate(value)
  %3666 = call float @dx.op.unary.f32(i32 7, float %3663)  ; Saturate(value)
  %3667 = call float @dx.op.unary.f32(i32 7, float %3664)  ; Saturate(value)
  %3668 = call float @dx.op.dot3.f32(i32 55, float %3665, float %3666, float %3667, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3669 = fsub fast float %3665, %3668
  %3670 = fsub fast float %3666, %3668
  %3671 = fsub fast float %3667, %3668
  %3672 = fmul fast float %3669, %9
  %3673 = fmul fast float %3670, %9
  %3674 = fmul fast float %3671, %9
  %3675 = fadd fast float %3672, %3668
  %3676 = fadd fast float %3673, %3668
  %3677 = fadd fast float %3674, %3668
  %3678 = call float @dx.op.unary.f32(i32 7, float %3675)  ; Saturate(value)
  %3679 = call float @dx.op.unary.f32(i32 7, float %3676)  ; Saturate(value)
  %3680 = call float @dx.op.unary.f32(i32 7, float %3677)  ; Saturate(value)
  %3681 = fadd fast float %3678, 0xBFC70A3D80000000
  %3682 = fadd fast float %3679, 0xBFC70A3D80000000
  %3683 = fadd fast float %3680, 0xBFC70A3D80000000
  %3684 = fmul fast float %3681, %8
  %3685 = fmul fast float %3682, %8
  %3686 = fmul fast float %3683, %8
  %3687 = fadd fast float %3684, 0x3FC70A3D80000000
  %3688 = fadd fast float %3685, 0x3FC70A3D80000000
  %3689 = fadd fast float %3686, 0x3FC70A3D80000000
  %3690 = call float @dx.op.unary.f32(i32 7, float %3687)  ; Saturate(value)
  %3691 = call float @dx.op.unary.f32(i32 7, float %3688)  ; Saturate(value)
  %3692 = call float @dx.op.unary.f32(i32 7, float %3689)  ; Saturate(value)
  %3693 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %3693, label %3694, label %4745

; <label>:3694                                    ; preds = %3661
  %3695 = add i32 %65, -1
  %3696 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %3697 = call i32 @dx.op.binary.i32(i32 37, i32 %3695, i32 0)  ; IMax(a,b)
  %3698 = call i32 @dx.op.binary.i32(i32 38, i32 %3696, i32 %60)  ; IMin(a,b)
  %3699 = call i32 @dx.op.binary.i32(i32 38, i32 %3697, i32 %61)  ; IMin(a,b)
  %3700 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3698, i32 %3699, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3701 = extractvalue %dx.types.ResRet.f32 %3700, 0
  %3702 = fsub fast float 1.000000e+00, %83
  %3703 = fmul fast float %3702, 0x3FA99999A0000000
  %3704 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %3703)  ; FMax(a,b)
  %3705 = fsub fast float %3701, %83
  %3706 = call float @dx.op.unary.f32(i32 6, float %3705)  ; FAbs(value)
  %3707 = fdiv fast float %3706, %3704
  %3708 = fsub fast float 1.000000e+00, %3707
  %3709 = call float @dx.op.unary.f32(i32 7, float %3708)  ; Saturate(value)
  %3710 = fcmp fast ugt float %3709, 0.000000e+00
  br i1 %3710, label %3711, label %3932

; <label>:3711                                    ; preds = %3694
  %3712 = call i32 @dx.op.binary.i32(i32 37, i32 %3698, i32 0)  ; IMax(a,b)
  %3713 = call i32 @dx.op.binary.i32(i32 37, i32 %3699, i32 0)  ; IMax(a,b)
  %3714 = call i32 @dx.op.binary.i32(i32 38, i32 %3712, i32 %60)  ; IMin(a,b)
  %3715 = call i32 @dx.op.binary.i32(i32 38, i32 %3713, i32 %61)  ; IMin(a,b)
  %3716 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3714, i32 %3715, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3717 = extractvalue %dx.types.ResRet.f32 %3716, 0
  %3718 = extractvalue %dx.types.ResRet.f32 %3716, 1
  %3719 = extractvalue %dx.types.ResRet.f32 %3716, 2
  %3720 = extractvalue %dx.types.ResRet.f32 %3716, 3
  %3721 = fcmp fast olt float %3720, 0.000000e+00
  br i1 %3721, label %3722, label %3756

; <label>:3722                                    ; preds = %3711
  %3723 = fcmp fast ogt float %3717, 0x3FA4B5DCC0000000
  %3724 = fcmp fast ogt float %3718, 0x3FA4B5DCC0000000
  %3725 = fcmp fast ogt float %3719, 0x3FA4B5DCC0000000
  %3726 = select i1 %3723, float 0.000000e+00, float 1.000000e+00
  %3727 = select i1 %3724, float 0.000000e+00, float 1.000000e+00
  %3728 = select i1 %3725, float 0.000000e+00, float 1.000000e+00
  %3729 = fmul fast float %3717, 0x3FB3D07220000000
  %3730 = fmul fast float %3718, 0x3FB3D07220000000
  %3731 = fmul fast float %3719, 0x3FB3D07220000000
  %3732 = fadd fast float %3717, 0x3FAC28F5C0000000
  %3733 = fadd fast float %3718, 0x3FAC28F5C0000000
  %3734 = fadd fast float %3719, 0x3FAC28F5C0000000
  %3735 = fmul fast float %3732, 0x3FEE54EDE0000000
  %3736 = fmul fast float %3733, 0x3FEE54EDE0000000
  %3737 = fmul fast float %3734, 0x3FEE54EDE0000000
  %3738 = call float @dx.op.unary.f32(i32 23, float %3735)  ; Log(value)
  %3739 = call float @dx.op.unary.f32(i32 23, float %3736)  ; Log(value)
  %3740 = call float @dx.op.unary.f32(i32 23, float %3737)  ; Log(value)
  %3741 = fmul fast float %3738, 0x4003333340000000
  %3742 = fmul fast float %3739, 0x4003333340000000
  %3743 = fmul fast float %3740, 0x4003333340000000
  %3744 = call float @dx.op.unary.f32(i32 21, float %3741)  ; Exp(value)
  %3745 = call float @dx.op.unary.f32(i32 21, float %3742)  ; Exp(value)
  %3746 = call float @dx.op.unary.f32(i32 21, float %3743)  ; Exp(value)
  %3747 = fsub fast float %3729, %3744
  %3748 = fsub fast float %3730, %3745
  %3749 = fsub fast float %3731, %3746
  %3750 = fmul fast float %3747, %3726
  %3751 = fmul fast float %3748, %3727
  %3752 = fmul fast float %3749, %3728
  %3753 = fadd fast float %3750, %3744
  %3754 = fadd fast float %3751, %3745
  %3755 = fadd fast float %3752, %3746
  br label %3919

; <label>:3756                                    ; preds = %3711
  %3757 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3714, i32 %3715, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3758 = extractvalue %dx.types.ResRet.f32 %3757, 0
  %3759 = fcmp fast ogt float %39, 5.000000e-01
  %3760 = fcmp fast olt float %3758, 1.000000e+00
  %3761 = and i1 %3759, %3760
  br i1 %3761, label %3762, label %3848

; <label>:3762                                    ; preds = %3756
  %3763 = sitofp i32 %3714 to float
  %3764 = sitofp i32 %3715 to float
  %3765 = fadd fast float %3763, 5.000000e-01
  %3766 = fadd fast float %3764, 5.000000e-01
  %3767 = fdiv fast float %3765, %46
  %3768 = fdiv fast float %3766, %47
  %3769 = fmul fast float %3767, 2.000000e+00
  %3770 = fmul fast float %3768, 2.000000e+00
  %3771 = fadd fast float %3769, -1.000000e+00
  %3772 = fsub fast float 1.000000e+00, %3770
  %3773 = fmul fast float %3771, %36
  %3774 = call float @dx.op.tertiary.f32(i32 46, float %3772, float %32, float %3773)  ; FMad(a,b,c)
  %3775 = call float @dx.op.tertiary.f32(i32 46, float %3758, float %28, float %3774)  ; FMad(a,b,c)
  %3776 = fadd fast float %3775, %24
  %3777 = call float @dx.op.unary.f32(i32 6, float %3776)  ; FAbs(value)
  %3778 = fcmp fast ogt float %3777, 0x3EB0C6F7A0000000
  br i1 %3778, label %3779, label %3848

; <label>:3779                                    ; preds = %3762
  %3780 = fmul fast float %3771, %35
  %3781 = call float @dx.op.tertiary.f32(i32 46, float %3772, float %31, float %3780)  ; FMad(a,b,c)
  %3782 = call float @dx.op.tertiary.f32(i32 46, float %3758, float %27, float %3781)  ; FMad(a,b,c)
  %3783 = fadd fast float %3782, %23
  %3784 = fmul fast float %3771, %34
  %3785 = call float @dx.op.tertiary.f32(i32 46, float %3772, float %30, float %3784)  ; FMad(a,b,c)
  %3786 = call float @dx.op.tertiary.f32(i32 46, float %3758, float %26, float %3785)  ; FMad(a,b,c)
  %3787 = fadd fast float %3786, %22
  %3788 = fmul fast float %3771, %33
  %3789 = call float @dx.op.tertiary.f32(i32 46, float %3772, float %29, float %3788)  ; FMad(a,b,c)
  %3790 = call float @dx.op.tertiary.f32(i32 46, float %3758, float %25, float %3789)  ; FMad(a,b,c)
  %3791 = fadd fast float %3790, %21
  %3792 = fdiv fast float %3791, %3776
  %3793 = fdiv fast float %3787, %3776
  %3794 = fdiv fast float %3783, %3776
  %3795 = fsub fast float %3792, %18
  %3796 = fsub fast float %3793, %19
  %3797 = fsub fast float %3794, %20
  %3798 = fmul fast float %3795, %3795
  %3799 = fmul fast float %3796, %3796
  %3800 = fadd fast float %3799, %3798
  %3801 = fmul fast float %3797, %3797
  %3802 = fadd fast float %3800, %3801
  %3803 = call float @dx.op.unary.f32(i32 24, float %3802)  ; Sqrt(value)
  %3804 = fsub fast float %3803, %10
  %3805 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3804)  ; FMax(a,b)
  %3806 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %3806, label %3807, label %3830

; <label>:3807                                    ; preds = %3779
  %3808 = call float @dx.op.unary.f32(i32 6, float %3796)  ; FAbs(value)
  %3809 = fmul fast float %3808, %12
  %3810 = fcmp fast olt float %3809, 0x3F50624DE0000000
  br i1 %3810, label %3811, label %3814

; <label>:3811                                    ; preds = %3807
  %3812 = fmul fast float %3809, 5.000000e-01
  %3813 = fsub fast float 1.000000e+00, %3812
  br label %3819

; <label>:3814                                    ; preds = %3807
  %3815 = fmul fast float %3809, 0xBFF7154760000000
  %3816 = call float @dx.op.unary.f32(i32 21, float %3815)  ; Exp(value)
  %3817 = fsub fast float 1.000000e+00, %3816
  %3818 = fdiv fast float %3817, %3809
  br label %3819

; <label>:3819                                    ; preds = %3814, %3811
  %3820 = phi float [ %3813, %3811 ], [ %3818, %3814 ]
  %3821 = call float @dx.op.binary.f32(i32 36, float %3793, float %19)  ; FMin(a,b)
  %3822 = fsub fast float %3821, %11
  %3823 = fmul fast float %12, %3822
  %3824 = fsub fast float -0.000000e+00, %3823
  %3825 = call float @dx.op.binary.f32(i32 35, float %3824, float -4.000000e+01)  ; FMax(a,b)
  %3826 = call float @dx.op.binary.f32(i32 36, float %3825, float 5.000000e+00)  ; FMin(a,b)
  %3827 = fmul fast float %3826, 0x3FF7154760000000
  %3828 = call float @dx.op.unary.f32(i32 21, float %3827)  ; Exp(value)
  %3829 = fmul fast float %3828, %3820
  br label %3830

; <label>:3830                                    ; preds = %3819, %3779
  %3831 = phi float [ %3829, %3819 ], [ 1.000000e+00, %3779 ]
  %3832 = fmul fast float %3805, %17
  %3833 = fmul fast float %3832, %3831
  %3834 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3833)  ; FMin(a,b)
  %3835 = fmul fast float %3834, 0xBFF7154760000000
  %3836 = call float @dx.op.unary.f32(i32 21, float %3835)  ; Exp(value)
  %3837 = fsub fast float 1.000000e+00, %3836
  %3838 = call float @dx.op.binary.f32(i32 36, float %13, float %3837)  ; FMin(a,b)
  %3839 = fsub fast float %14, %3717
  %3840 = fsub fast float %15, %3718
  %3841 = fsub fast float %16, %3719
  %3842 = fmul fast float %3838, %3839
  %3843 = fmul fast float %3838, %3840
  %3844 = fmul fast float %3838, %3841
  %3845 = fadd fast float %3842, %3717
  %3846 = fadd fast float %3843, %3718
  %3847 = fadd fast float %3844, %3719
  br label %3848

; <label>:3848                                    ; preds = %3830, %3762, %3756
  %3849 = phi float [ %3845, %3830 ], [ %3717, %3762 ], [ %3717, %3756 ]
  %3850 = phi float [ %3846, %3830 ], [ %3718, %3762 ], [ %3718, %3756 ]
  %3851 = phi float [ %3847, %3830 ], [ %3719, %3762 ], [ %3719, %3756 ]
  %3852 = fadd fast float %6, 1.000000e+00
  %3853 = fadd fast float %7, 1.000000e+00
  %3854 = fsub fast float 1.000000e+00, %6
  %3855 = fmul fast float %37, %3852
  %3856 = fmul fast float %37, %3853
  %3857 = fmul fast float %37, %3854
  %3858 = fmul fast float %3855, %3849
  %3859 = fmul fast float %3856, %3850
  %3860 = fmul fast float %3857, %3851
  %3861 = fcmp fast ult float %38, 5.000000e-01
  br i1 %3861, label %3887, label %3862

; <label>:3862                                    ; preds = %3848
  %3863 = fmul fast float %3858, 0x4004147AE0000000
  %3864 = fmul fast float %3859, 0x4004147AE0000000
  %3865 = fmul fast float %3860, 0x4004147AE0000000
  %3866 = fadd fast float %3863, 0x3F9EB851E0000000
  %3867 = fadd fast float %3864, 0x3F9EB851E0000000
  %3868 = fadd fast float %3865, 0x3F9EB851E0000000
  %3869 = fmul fast float %3866, %3858
  %3870 = fmul fast float %3867, %3859
  %3871 = fmul fast float %3868, %3860
  %3872 = fmul fast float %3858, 0x400370A3E0000000
  %3873 = fmul fast float %3859, 0x400370A3E0000000
  %3874 = fmul fast float %3860, 0x400370A3E0000000
  %3875 = fadd fast float %3872, 0x3FE2E147A0000000
  %3876 = fadd fast float %3873, 0x3FE2E147A0000000
  %3877 = fadd fast float %3874, 0x3FE2E147A0000000
  %3878 = fmul fast float %3875, %3858
  %3879 = fmul fast float %3876, %3859
  %3880 = fmul fast float %3877, %3860
  %3881 = fadd fast float %3878, 0x3FC1EB8520000000
  %3882 = fadd fast float %3879, 0x3FC1EB8520000000
  %3883 = fadd fast float %3880, 0x3FC1EB8520000000
  %3884 = fdiv fast float %3869, %3881
  %3885 = fdiv fast float %3870, %3882
  %3886 = fdiv fast float %3871, %3883
  br label %3887

; <label>:3887                                    ; preds = %3862, %3848
  %3888 = phi float [ %3884, %3862 ], [ %3858, %3848 ]
  %3889 = phi float [ %3885, %3862 ], [ %3859, %3848 ]
  %3890 = phi float [ %3886, %3862 ], [ %3860, %3848 ]
  %3891 = call float @dx.op.unary.f32(i32 7, float %3888)  ; Saturate(value)
  %3892 = call float @dx.op.unary.f32(i32 7, float %3889)  ; Saturate(value)
  %3893 = call float @dx.op.unary.f32(i32 7, float %3890)  ; Saturate(value)
  %3894 = call float @dx.op.dot3.f32(i32 55, float %3891, float %3892, float %3893, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3895 = fsub fast float %3891, %3894
  %3896 = fsub fast float %3892, %3894
  %3897 = fsub fast float %3893, %3894
  %3898 = fmul fast float %3895, %9
  %3899 = fmul fast float %3896, %9
  %3900 = fmul fast float %3897, %9
  %3901 = fadd fast float %3898, %3894
  %3902 = fadd fast float %3899, %3894
  %3903 = fadd fast float %3900, %3894
  %3904 = call float @dx.op.unary.f32(i32 7, float %3901)  ; Saturate(value)
  %3905 = call float @dx.op.unary.f32(i32 7, float %3902)  ; Saturate(value)
  %3906 = call float @dx.op.unary.f32(i32 7, float %3903)  ; Saturate(value)
  %3907 = fadd fast float %3904, 0xBFC70A3D80000000
  %3908 = fadd fast float %3905, 0xBFC70A3D80000000
  %3909 = fadd fast float %3906, 0xBFC70A3D80000000
  %3910 = fmul fast float %3907, %8
  %3911 = fmul fast float %3908, %8
  %3912 = fmul fast float %3909, %8
  %3913 = fadd fast float %3910, 0x3FC70A3D80000000
  %3914 = fadd fast float %3911, 0x3FC70A3D80000000
  %3915 = fadd fast float %3912, 0x3FC70A3D80000000
  %3916 = call float @dx.op.unary.f32(i32 7, float %3913)  ; Saturate(value)
  %3917 = call float @dx.op.unary.f32(i32 7, float %3914)  ; Saturate(value)
  %3918 = call float @dx.op.unary.f32(i32 7, float %3915)  ; Saturate(value)
  br label %3919

; <label>:3919                                    ; preds = %3887, %3722
  %3920 = phi float [ %3753, %3722 ], [ %3916, %3887 ]
  %3921 = phi float [ %3754, %3722 ], [ %3917, %3887 ]
  %3922 = phi float [ %3755, %3722 ], [ %3918, %3887 ]
  %3923 = fsub fast float %3920, %3690
  %3924 = fsub fast float %3921, %3691
  %3925 = fsub fast float %3922, %3692
  %3926 = fmul fast float %3923, %3709
  %3927 = fmul fast float %3924, %3709
  %3928 = fmul fast float %3925, %3709
  %3929 = fadd fast float %3926, %3690
  %3930 = fadd fast float %3927, %3691
  %3931 = fadd fast float %3928, %3692
  br label %3932

; <label>:3932                                    ; preds = %3919, %3694
  %3933 = phi float [ %3929, %3919 ], [ %3690, %3694 ]
  %3934 = phi float [ %3930, %3919 ], [ %3691, %3694 ]
  %3935 = phi float [ %3931, %3919 ], [ %3692, %3694 ]
  %3936 = add i32 %65, 1
  %3937 = call i32 @dx.op.binary.i32(i32 37, i32 %3936, i32 0)  ; IMax(a,b)
  %3938 = call i32 @dx.op.binary.i32(i32 38, i32 %3937, i32 %61)  ; IMin(a,b)
  %3939 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3698, i32 %3938, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3940 = extractvalue %dx.types.ResRet.f32 %3939, 0
  %3941 = fsub fast float %3940, %83
  %3942 = call float @dx.op.unary.f32(i32 6, float %3941)  ; FAbs(value)
  %3943 = fdiv fast float %3942, %3704
  %3944 = fsub fast float 1.000000e+00, %3943
  %3945 = call float @dx.op.unary.f32(i32 7, float %3944)  ; Saturate(value)
  %3946 = fcmp fast ugt float %3945, 0.000000e+00
  br i1 %3946, label %3947, label %4168

; <label>:3947                                    ; preds = %3932
  %3948 = call i32 @dx.op.binary.i32(i32 37, i32 %3698, i32 0)  ; IMax(a,b)
  %3949 = call i32 @dx.op.binary.i32(i32 37, i32 %3938, i32 0)  ; IMax(a,b)
  %3950 = call i32 @dx.op.binary.i32(i32 38, i32 %3948, i32 %60)  ; IMin(a,b)
  %3951 = call i32 @dx.op.binary.i32(i32 38, i32 %3949, i32 %61)  ; IMin(a,b)
  %3952 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3950, i32 %3951, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3953 = extractvalue %dx.types.ResRet.f32 %3952, 0
  %3954 = extractvalue %dx.types.ResRet.f32 %3952, 1
  %3955 = extractvalue %dx.types.ResRet.f32 %3952, 2
  %3956 = extractvalue %dx.types.ResRet.f32 %3952, 3
  %3957 = fcmp fast olt float %3956, 0.000000e+00
  br i1 %3957, label %3958, label %3992

; <label>:3958                                    ; preds = %3947
  %3959 = fcmp fast ogt float %3953, 0x3FA4B5DCC0000000
  %3960 = fcmp fast ogt float %3954, 0x3FA4B5DCC0000000
  %3961 = fcmp fast ogt float %3955, 0x3FA4B5DCC0000000
  %3962 = select i1 %3959, float 0.000000e+00, float 1.000000e+00
  %3963 = select i1 %3960, float 0.000000e+00, float 1.000000e+00
  %3964 = select i1 %3961, float 0.000000e+00, float 1.000000e+00
  %3965 = fmul fast float %3953, 0x3FB3D07220000000
  %3966 = fmul fast float %3954, 0x3FB3D07220000000
  %3967 = fmul fast float %3955, 0x3FB3D07220000000
  %3968 = fadd fast float %3953, 0x3FAC28F5C0000000
  %3969 = fadd fast float %3954, 0x3FAC28F5C0000000
  %3970 = fadd fast float %3955, 0x3FAC28F5C0000000
  %3971 = fmul fast float %3968, 0x3FEE54EDE0000000
  %3972 = fmul fast float %3969, 0x3FEE54EDE0000000
  %3973 = fmul fast float %3970, 0x3FEE54EDE0000000
  %3974 = call float @dx.op.unary.f32(i32 23, float %3971)  ; Log(value)
  %3975 = call float @dx.op.unary.f32(i32 23, float %3972)  ; Log(value)
  %3976 = call float @dx.op.unary.f32(i32 23, float %3973)  ; Log(value)
  %3977 = fmul fast float %3974, 0x4003333340000000
  %3978 = fmul fast float %3975, 0x4003333340000000
  %3979 = fmul fast float %3976, 0x4003333340000000
  %3980 = call float @dx.op.unary.f32(i32 21, float %3977)  ; Exp(value)
  %3981 = call float @dx.op.unary.f32(i32 21, float %3978)  ; Exp(value)
  %3982 = call float @dx.op.unary.f32(i32 21, float %3979)  ; Exp(value)
  %3983 = fsub fast float %3965, %3980
  %3984 = fsub fast float %3966, %3981
  %3985 = fsub fast float %3967, %3982
  %3986 = fmul fast float %3983, %3962
  %3987 = fmul fast float %3984, %3963
  %3988 = fmul fast float %3985, %3964
  %3989 = fadd fast float %3986, %3980
  %3990 = fadd fast float %3987, %3981
  %3991 = fadd fast float %3988, %3982
  br label %4155

; <label>:3992                                    ; preds = %3947
  %3993 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3950, i32 %3951, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3994 = extractvalue %dx.types.ResRet.f32 %3993, 0
  %3995 = fcmp fast ogt float %39, 5.000000e-01
  %3996 = fcmp fast olt float %3994, 1.000000e+00
  %3997 = and i1 %3995, %3996
  br i1 %3997, label %3998, label %4084

; <label>:3998                                    ; preds = %3992
  %3999 = sitofp i32 %3950 to float
  %4000 = sitofp i32 %3951 to float
  %4001 = fadd fast float %3999, 5.000000e-01
  %4002 = fadd fast float %4000, 5.000000e-01
  %4003 = fdiv fast float %4001, %46
  %4004 = fdiv fast float %4002, %47
  %4005 = fmul fast float %4003, 2.000000e+00
  %4006 = fmul fast float %4004, 2.000000e+00
  %4007 = fadd fast float %4005, -1.000000e+00
  %4008 = fsub fast float 1.000000e+00, %4006
  %4009 = fmul fast float %4007, %36
  %4010 = call float @dx.op.tertiary.f32(i32 46, float %4008, float %32, float %4009)  ; FMad(a,b,c)
  %4011 = call float @dx.op.tertiary.f32(i32 46, float %3994, float %28, float %4010)  ; FMad(a,b,c)
  %4012 = fadd fast float %4011, %24
  %4013 = call float @dx.op.unary.f32(i32 6, float %4012)  ; FAbs(value)
  %4014 = fcmp fast ogt float %4013, 0x3EB0C6F7A0000000
  br i1 %4014, label %4015, label %4084

; <label>:4015                                    ; preds = %3998
  %4016 = fmul fast float %4007, %35
  %4017 = call float @dx.op.tertiary.f32(i32 46, float %4008, float %31, float %4016)  ; FMad(a,b,c)
  %4018 = call float @dx.op.tertiary.f32(i32 46, float %3994, float %27, float %4017)  ; FMad(a,b,c)
  %4019 = fadd fast float %4018, %23
  %4020 = fmul fast float %4007, %34
  %4021 = call float @dx.op.tertiary.f32(i32 46, float %4008, float %30, float %4020)  ; FMad(a,b,c)
  %4022 = call float @dx.op.tertiary.f32(i32 46, float %3994, float %26, float %4021)  ; FMad(a,b,c)
  %4023 = fadd fast float %4022, %22
  %4024 = fmul fast float %4007, %33
  %4025 = call float @dx.op.tertiary.f32(i32 46, float %4008, float %29, float %4024)  ; FMad(a,b,c)
  %4026 = call float @dx.op.tertiary.f32(i32 46, float %3994, float %25, float %4025)  ; FMad(a,b,c)
  %4027 = fadd fast float %4026, %21
  %4028 = fdiv fast float %4027, %4012
  %4029 = fdiv fast float %4023, %4012
  %4030 = fdiv fast float %4019, %4012
  %4031 = fsub fast float %4028, %18
  %4032 = fsub fast float %4029, %19
  %4033 = fsub fast float %4030, %20
  %4034 = fmul fast float %4031, %4031
  %4035 = fmul fast float %4032, %4032
  %4036 = fadd fast float %4035, %4034
  %4037 = fmul fast float %4033, %4033
  %4038 = fadd fast float %4036, %4037
  %4039 = call float @dx.op.unary.f32(i32 24, float %4038)  ; Sqrt(value)
  %4040 = fsub fast float %4039, %10
  %4041 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4040)  ; FMax(a,b)
  %4042 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %4042, label %4043, label %4066

; <label>:4043                                    ; preds = %4015
  %4044 = call float @dx.op.unary.f32(i32 6, float %4032)  ; FAbs(value)
  %4045 = fmul fast float %4044, %12
  %4046 = fcmp fast olt float %4045, 0x3F50624DE0000000
  br i1 %4046, label %4047, label %4050

; <label>:4047                                    ; preds = %4043
  %4048 = fmul fast float %4045, 5.000000e-01
  %4049 = fsub fast float 1.000000e+00, %4048
  br label %4055

; <label>:4050                                    ; preds = %4043
  %4051 = fmul fast float %4045, 0xBFF7154760000000
  %4052 = call float @dx.op.unary.f32(i32 21, float %4051)  ; Exp(value)
  %4053 = fsub fast float 1.000000e+00, %4052
  %4054 = fdiv fast float %4053, %4045
  br label %4055

; <label>:4055                                    ; preds = %4050, %4047
  %4056 = phi float [ %4049, %4047 ], [ %4054, %4050 ]
  %4057 = call float @dx.op.binary.f32(i32 36, float %4029, float %19)  ; FMin(a,b)
  %4058 = fsub fast float %4057, %11
  %4059 = fmul fast float %12, %4058
  %4060 = fsub fast float -0.000000e+00, %4059
  %4061 = call float @dx.op.binary.f32(i32 35, float %4060, float -4.000000e+01)  ; FMax(a,b)
  %4062 = call float @dx.op.binary.f32(i32 36, float %4061, float 5.000000e+00)  ; FMin(a,b)
  %4063 = fmul fast float %4062, 0x3FF7154760000000
  %4064 = call float @dx.op.unary.f32(i32 21, float %4063)  ; Exp(value)
  %4065 = fmul fast float %4064, %4056
  br label %4066

; <label>:4066                                    ; preds = %4055, %4015
  %4067 = phi float [ %4065, %4055 ], [ 1.000000e+00, %4015 ]
  %4068 = fmul fast float %4041, %17
  %4069 = fmul fast float %4068, %4067
  %4070 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4069)  ; FMin(a,b)
  %4071 = fmul fast float %4070, 0xBFF7154760000000
  %4072 = call float @dx.op.unary.f32(i32 21, float %4071)  ; Exp(value)
  %4073 = fsub fast float 1.000000e+00, %4072
  %4074 = call float @dx.op.binary.f32(i32 36, float %13, float %4073)  ; FMin(a,b)
  %4075 = fsub fast float %14, %3953
  %4076 = fsub fast float %15, %3954
  %4077 = fsub fast float %16, %3955
  %4078 = fmul fast float %4074, %4075
  %4079 = fmul fast float %4074, %4076
  %4080 = fmul fast float %4074, %4077
  %4081 = fadd fast float %4078, %3953
  %4082 = fadd fast float %4079, %3954
  %4083 = fadd fast float %4080, %3955
  br label %4084

; <label>:4084                                    ; preds = %4066, %3998, %3992
  %4085 = phi float [ %4081, %4066 ], [ %3953, %3998 ], [ %3953, %3992 ]
  %4086 = phi float [ %4082, %4066 ], [ %3954, %3998 ], [ %3954, %3992 ]
  %4087 = phi float [ %4083, %4066 ], [ %3955, %3998 ], [ %3955, %3992 ]
  %4088 = fadd fast float %6, 1.000000e+00
  %4089 = fadd fast float %7, 1.000000e+00
  %4090 = fsub fast float 1.000000e+00, %6
  %4091 = fmul fast float %37, %4088
  %4092 = fmul fast float %37, %4089
  %4093 = fmul fast float %37, %4090
  %4094 = fmul fast float %4091, %4085
  %4095 = fmul fast float %4092, %4086
  %4096 = fmul fast float %4093, %4087
  %4097 = fcmp fast ult float %38, 5.000000e-01
  br i1 %4097, label %4123, label %4098

; <label>:4098                                    ; preds = %4084
  %4099 = fmul fast float %4094, 0x4004147AE0000000
  %4100 = fmul fast float %4095, 0x4004147AE0000000
  %4101 = fmul fast float %4096, 0x4004147AE0000000
  %4102 = fadd fast float %4099, 0x3F9EB851E0000000
  %4103 = fadd fast float %4100, 0x3F9EB851E0000000
  %4104 = fadd fast float %4101, 0x3F9EB851E0000000
  %4105 = fmul fast float %4102, %4094
  %4106 = fmul fast float %4103, %4095
  %4107 = fmul fast float %4104, %4096
  %4108 = fmul fast float %4094, 0x400370A3E0000000
  %4109 = fmul fast float %4095, 0x400370A3E0000000
  %4110 = fmul fast float %4096, 0x400370A3E0000000
  %4111 = fadd fast float %4108, 0x3FE2E147A0000000
  %4112 = fadd fast float %4109, 0x3FE2E147A0000000
  %4113 = fadd fast float %4110, 0x3FE2E147A0000000
  %4114 = fmul fast float %4111, %4094
  %4115 = fmul fast float %4112, %4095
  %4116 = fmul fast float %4113, %4096
  %4117 = fadd fast float %4114, 0x3FC1EB8520000000
  %4118 = fadd fast float %4115, 0x3FC1EB8520000000
  %4119 = fadd fast float %4116, 0x3FC1EB8520000000
  %4120 = fdiv fast float %4105, %4117
  %4121 = fdiv fast float %4106, %4118
  %4122 = fdiv fast float %4107, %4119
  br label %4123

; <label>:4123                                    ; preds = %4098, %4084
  %4124 = phi float [ %4120, %4098 ], [ %4094, %4084 ]
  %4125 = phi float [ %4121, %4098 ], [ %4095, %4084 ]
  %4126 = phi float [ %4122, %4098 ], [ %4096, %4084 ]
  %4127 = call float @dx.op.unary.f32(i32 7, float %4124)  ; Saturate(value)
  %4128 = call float @dx.op.unary.f32(i32 7, float %4125)  ; Saturate(value)
  %4129 = call float @dx.op.unary.f32(i32 7, float %4126)  ; Saturate(value)
  %4130 = call float @dx.op.dot3.f32(i32 55, float %4127, float %4128, float %4129, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4131 = fsub fast float %4127, %4130
  %4132 = fsub fast float %4128, %4130
  %4133 = fsub fast float %4129, %4130
  %4134 = fmul fast float %4131, %9
  %4135 = fmul fast float %4132, %9
  %4136 = fmul fast float %4133, %9
  %4137 = fadd fast float %4134, %4130
  %4138 = fadd fast float %4135, %4130
  %4139 = fadd fast float %4136, %4130
  %4140 = call float @dx.op.unary.f32(i32 7, float %4137)  ; Saturate(value)
  %4141 = call float @dx.op.unary.f32(i32 7, float %4138)  ; Saturate(value)
  %4142 = call float @dx.op.unary.f32(i32 7, float %4139)  ; Saturate(value)
  %4143 = fadd fast float %4140, 0xBFC70A3D80000000
  %4144 = fadd fast float %4141, 0xBFC70A3D80000000
  %4145 = fadd fast float %4142, 0xBFC70A3D80000000
  %4146 = fmul fast float %4143, %8
  %4147 = fmul fast float %4144, %8
  %4148 = fmul fast float %4145, %8
  %4149 = fadd fast float %4146, 0x3FC70A3D80000000
  %4150 = fadd fast float %4147, 0x3FC70A3D80000000
  %4151 = fadd fast float %4148, 0x3FC70A3D80000000
  %4152 = call float @dx.op.unary.f32(i32 7, float %4149)  ; Saturate(value)
  %4153 = call float @dx.op.unary.f32(i32 7, float %4150)  ; Saturate(value)
  %4154 = call float @dx.op.unary.f32(i32 7, float %4151)  ; Saturate(value)
  br label %4155

; <label>:4155                                    ; preds = %4123, %3958
  %4156 = phi float [ %3989, %3958 ], [ %4152, %4123 ]
  %4157 = phi float [ %3990, %3958 ], [ %4153, %4123 ]
  %4158 = phi float [ %3991, %3958 ], [ %4154, %4123 ]
  %4159 = fsub fast float %4156, %3690
  %4160 = fsub fast float %4157, %3691
  %4161 = fsub fast float %4158, %3692
  %4162 = fmul fast float %4159, %3945
  %4163 = fmul fast float %4160, %3945
  %4164 = fmul fast float %4161, %3945
  %4165 = fadd fast float %4162, %3690
  %4166 = fadd fast float %4163, %3691
  %4167 = fadd fast float %4164, %3692
  br label %4168

; <label>:4168                                    ; preds = %4155, %3932
  %4169 = phi float [ %4165, %4155 ], [ %3690, %3932 ]
  %4170 = phi float [ %4166, %4155 ], [ %3691, %3932 ]
  %4171 = phi float [ %4167, %4155 ], [ %3692, %3932 ]
  %4172 = add i32 %64, -1
  %4173 = call i32 @dx.op.binary.i32(i32 37, i32 %4172, i32 0)  ; IMax(a,b)
  %4174 = call i32 @dx.op.binary.i32(i32 37, i32 %65, i32 0)  ; IMax(a,b)
  %4175 = call i32 @dx.op.binary.i32(i32 38, i32 %4173, i32 %60)  ; IMin(a,b)
  %4176 = call i32 @dx.op.binary.i32(i32 38, i32 %4174, i32 %61)  ; IMin(a,b)
  %4177 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4175, i32 %4176, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4178 = extractvalue %dx.types.ResRet.f32 %4177, 0
  %4179 = fsub fast float %4178, %83
  %4180 = call float @dx.op.unary.f32(i32 6, float %4179)  ; FAbs(value)
  %4181 = fdiv fast float %4180, %3704
  %4182 = fsub fast float 1.000000e+00, %4181
  %4183 = call float @dx.op.unary.f32(i32 7, float %4182)  ; Saturate(value)
  %4184 = fcmp fast ugt float %4183, 0.000000e+00
  br i1 %4184, label %4185, label %4406

; <label>:4185                                    ; preds = %4168
  %4186 = call i32 @dx.op.binary.i32(i32 37, i32 %4175, i32 0)  ; IMax(a,b)
  %4187 = call i32 @dx.op.binary.i32(i32 37, i32 %4176, i32 0)  ; IMax(a,b)
  %4188 = call i32 @dx.op.binary.i32(i32 38, i32 %4186, i32 %60)  ; IMin(a,b)
  %4189 = call i32 @dx.op.binary.i32(i32 38, i32 %4187, i32 %61)  ; IMin(a,b)
  %4190 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4188, i32 %4189, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4191 = extractvalue %dx.types.ResRet.f32 %4190, 0
  %4192 = extractvalue %dx.types.ResRet.f32 %4190, 1
  %4193 = extractvalue %dx.types.ResRet.f32 %4190, 2
  %4194 = extractvalue %dx.types.ResRet.f32 %4190, 3
  %4195 = fcmp fast olt float %4194, 0.000000e+00
  br i1 %4195, label %4196, label %4230

; <label>:4196                                    ; preds = %4185
  %4197 = fcmp fast ogt float %4191, 0x3FA4B5DCC0000000
  %4198 = fcmp fast ogt float %4192, 0x3FA4B5DCC0000000
  %4199 = fcmp fast ogt float %4193, 0x3FA4B5DCC0000000
  %4200 = select i1 %4197, float 0.000000e+00, float 1.000000e+00
  %4201 = select i1 %4198, float 0.000000e+00, float 1.000000e+00
  %4202 = select i1 %4199, float 0.000000e+00, float 1.000000e+00
  %4203 = fmul fast float %4191, 0x3FB3D07220000000
  %4204 = fmul fast float %4192, 0x3FB3D07220000000
  %4205 = fmul fast float %4193, 0x3FB3D07220000000
  %4206 = fadd fast float %4191, 0x3FAC28F5C0000000
  %4207 = fadd fast float %4192, 0x3FAC28F5C0000000
  %4208 = fadd fast float %4193, 0x3FAC28F5C0000000
  %4209 = fmul fast float %4206, 0x3FEE54EDE0000000
  %4210 = fmul fast float %4207, 0x3FEE54EDE0000000
  %4211 = fmul fast float %4208, 0x3FEE54EDE0000000
  %4212 = call float @dx.op.unary.f32(i32 23, float %4209)  ; Log(value)
  %4213 = call float @dx.op.unary.f32(i32 23, float %4210)  ; Log(value)
  %4214 = call float @dx.op.unary.f32(i32 23, float %4211)  ; Log(value)
  %4215 = fmul fast float %4212, 0x4003333340000000
  %4216 = fmul fast float %4213, 0x4003333340000000
  %4217 = fmul fast float %4214, 0x4003333340000000
  %4218 = call float @dx.op.unary.f32(i32 21, float %4215)  ; Exp(value)
  %4219 = call float @dx.op.unary.f32(i32 21, float %4216)  ; Exp(value)
  %4220 = call float @dx.op.unary.f32(i32 21, float %4217)  ; Exp(value)
  %4221 = fsub fast float %4203, %4218
  %4222 = fsub fast float %4204, %4219
  %4223 = fsub fast float %4205, %4220
  %4224 = fmul fast float %4221, %4200
  %4225 = fmul fast float %4222, %4201
  %4226 = fmul fast float %4223, %4202
  %4227 = fadd fast float %4224, %4218
  %4228 = fadd fast float %4225, %4219
  %4229 = fadd fast float %4226, %4220
  br label %4393

; <label>:4230                                    ; preds = %4185
  %4231 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4188, i32 %4189, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4232 = extractvalue %dx.types.ResRet.f32 %4231, 0
  %4233 = fcmp fast ogt float %39, 5.000000e-01
  %4234 = fcmp fast olt float %4232, 1.000000e+00
  %4235 = and i1 %4233, %4234
  br i1 %4235, label %4236, label %4322

; <label>:4236                                    ; preds = %4230
  %4237 = sitofp i32 %4188 to float
  %4238 = sitofp i32 %4189 to float
  %4239 = fadd fast float %4237, 5.000000e-01
  %4240 = fadd fast float %4238, 5.000000e-01
  %4241 = fdiv fast float %4239, %46
  %4242 = fdiv fast float %4240, %47
  %4243 = fmul fast float %4241, 2.000000e+00
  %4244 = fmul fast float %4242, 2.000000e+00
  %4245 = fadd fast float %4243, -1.000000e+00
  %4246 = fsub fast float 1.000000e+00, %4244
  %4247 = fmul fast float %4245, %36
  %4248 = call float @dx.op.tertiary.f32(i32 46, float %4246, float %32, float %4247)  ; FMad(a,b,c)
  %4249 = call float @dx.op.tertiary.f32(i32 46, float %4232, float %28, float %4248)  ; FMad(a,b,c)
  %4250 = fadd fast float %4249, %24
  %4251 = call float @dx.op.unary.f32(i32 6, float %4250)  ; FAbs(value)
  %4252 = fcmp fast ogt float %4251, 0x3EB0C6F7A0000000
  br i1 %4252, label %4253, label %4322

; <label>:4253                                    ; preds = %4236
  %4254 = fmul fast float %4245, %35
  %4255 = call float @dx.op.tertiary.f32(i32 46, float %4246, float %31, float %4254)  ; FMad(a,b,c)
  %4256 = call float @dx.op.tertiary.f32(i32 46, float %4232, float %27, float %4255)  ; FMad(a,b,c)
  %4257 = fadd fast float %4256, %23
  %4258 = fmul fast float %4245, %34
  %4259 = call float @dx.op.tertiary.f32(i32 46, float %4246, float %30, float %4258)  ; FMad(a,b,c)
  %4260 = call float @dx.op.tertiary.f32(i32 46, float %4232, float %26, float %4259)  ; FMad(a,b,c)
  %4261 = fadd fast float %4260, %22
  %4262 = fmul fast float %4245, %33
  %4263 = call float @dx.op.tertiary.f32(i32 46, float %4246, float %29, float %4262)  ; FMad(a,b,c)
  %4264 = call float @dx.op.tertiary.f32(i32 46, float %4232, float %25, float %4263)  ; FMad(a,b,c)
  %4265 = fadd fast float %4264, %21
  %4266 = fdiv fast float %4265, %4250
  %4267 = fdiv fast float %4261, %4250
  %4268 = fdiv fast float %4257, %4250
  %4269 = fsub fast float %4266, %18
  %4270 = fsub fast float %4267, %19
  %4271 = fsub fast float %4268, %20
  %4272 = fmul fast float %4269, %4269
  %4273 = fmul fast float %4270, %4270
  %4274 = fadd fast float %4273, %4272
  %4275 = fmul fast float %4271, %4271
  %4276 = fadd fast float %4274, %4275
  %4277 = call float @dx.op.unary.f32(i32 24, float %4276)  ; Sqrt(value)
  %4278 = fsub fast float %4277, %10
  %4279 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4278)  ; FMax(a,b)
  %4280 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %4280, label %4281, label %4304

; <label>:4281                                    ; preds = %4253
  %4282 = call float @dx.op.unary.f32(i32 6, float %4270)  ; FAbs(value)
  %4283 = fmul fast float %4282, %12
  %4284 = fcmp fast olt float %4283, 0x3F50624DE0000000
  br i1 %4284, label %4285, label %4288

; <label>:4285                                    ; preds = %4281
  %4286 = fmul fast float %4283, 5.000000e-01
  %4287 = fsub fast float 1.000000e+00, %4286
  br label %4293

; <label>:4288                                    ; preds = %4281
  %4289 = fmul fast float %4283, 0xBFF7154760000000
  %4290 = call float @dx.op.unary.f32(i32 21, float %4289)  ; Exp(value)
  %4291 = fsub fast float 1.000000e+00, %4290
  %4292 = fdiv fast float %4291, %4283
  br label %4293

; <label>:4293                                    ; preds = %4288, %4285
  %4294 = phi float [ %4287, %4285 ], [ %4292, %4288 ]
  %4295 = call float @dx.op.binary.f32(i32 36, float %4267, float %19)  ; FMin(a,b)
  %4296 = fsub fast float %4295, %11
  %4297 = fmul fast float %12, %4296
  %4298 = fsub fast float -0.000000e+00, %4297
  %4299 = call float @dx.op.binary.f32(i32 35, float %4298, float -4.000000e+01)  ; FMax(a,b)
  %4300 = call float @dx.op.binary.f32(i32 36, float %4299, float 5.000000e+00)  ; FMin(a,b)
  %4301 = fmul fast float %4300, 0x3FF7154760000000
  %4302 = call float @dx.op.unary.f32(i32 21, float %4301)  ; Exp(value)
  %4303 = fmul fast float %4302, %4294
  br label %4304

; <label>:4304                                    ; preds = %4293, %4253
  %4305 = phi float [ %4303, %4293 ], [ 1.000000e+00, %4253 ]
  %4306 = fmul fast float %4279, %17
  %4307 = fmul fast float %4306, %4305
  %4308 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4307)  ; FMin(a,b)
  %4309 = fmul fast float %4308, 0xBFF7154760000000
  %4310 = call float @dx.op.unary.f32(i32 21, float %4309)  ; Exp(value)
  %4311 = fsub fast float 1.000000e+00, %4310
  %4312 = call float @dx.op.binary.f32(i32 36, float %13, float %4311)  ; FMin(a,b)
  %4313 = fsub fast float %14, %4191
  %4314 = fsub fast float %15, %4192
  %4315 = fsub fast float %16, %4193
  %4316 = fmul fast float %4312, %4313
  %4317 = fmul fast float %4312, %4314
  %4318 = fmul fast float %4312, %4315
  %4319 = fadd fast float %4316, %4191
  %4320 = fadd fast float %4317, %4192
  %4321 = fadd fast float %4318, %4193
  br label %4322

; <label>:4322                                    ; preds = %4304, %4236, %4230
  %4323 = phi float [ %4319, %4304 ], [ %4191, %4236 ], [ %4191, %4230 ]
  %4324 = phi float [ %4320, %4304 ], [ %4192, %4236 ], [ %4192, %4230 ]
  %4325 = phi float [ %4321, %4304 ], [ %4193, %4236 ], [ %4193, %4230 ]
  %4326 = fadd fast float %6, 1.000000e+00
  %4327 = fadd fast float %7, 1.000000e+00
  %4328 = fsub fast float 1.000000e+00, %6
  %4329 = fmul fast float %37, %4326
  %4330 = fmul fast float %37, %4327
  %4331 = fmul fast float %37, %4328
  %4332 = fmul fast float %4329, %4323
  %4333 = fmul fast float %4330, %4324
  %4334 = fmul fast float %4331, %4325
  %4335 = fcmp fast ult float %38, 5.000000e-01
  br i1 %4335, label %4361, label %4336

; <label>:4336                                    ; preds = %4322
  %4337 = fmul fast float %4332, 0x4004147AE0000000
  %4338 = fmul fast float %4333, 0x4004147AE0000000
  %4339 = fmul fast float %4334, 0x4004147AE0000000
  %4340 = fadd fast float %4337, 0x3F9EB851E0000000
  %4341 = fadd fast float %4338, 0x3F9EB851E0000000
  %4342 = fadd fast float %4339, 0x3F9EB851E0000000
  %4343 = fmul fast float %4340, %4332
  %4344 = fmul fast float %4341, %4333
  %4345 = fmul fast float %4342, %4334
  %4346 = fmul fast float %4332, 0x400370A3E0000000
  %4347 = fmul fast float %4333, 0x400370A3E0000000
  %4348 = fmul fast float %4334, 0x400370A3E0000000
  %4349 = fadd fast float %4346, 0x3FE2E147A0000000
  %4350 = fadd fast float %4347, 0x3FE2E147A0000000
  %4351 = fadd fast float %4348, 0x3FE2E147A0000000
  %4352 = fmul fast float %4349, %4332
  %4353 = fmul fast float %4350, %4333
  %4354 = fmul fast float %4351, %4334
  %4355 = fadd fast float %4352, 0x3FC1EB8520000000
  %4356 = fadd fast float %4353, 0x3FC1EB8520000000
  %4357 = fadd fast float %4354, 0x3FC1EB8520000000
  %4358 = fdiv fast float %4343, %4355
  %4359 = fdiv fast float %4344, %4356
  %4360 = fdiv fast float %4345, %4357
  br label %4361

; <label>:4361                                    ; preds = %4336, %4322
  %4362 = phi float [ %4358, %4336 ], [ %4332, %4322 ]
  %4363 = phi float [ %4359, %4336 ], [ %4333, %4322 ]
  %4364 = phi float [ %4360, %4336 ], [ %4334, %4322 ]
  %4365 = call float @dx.op.unary.f32(i32 7, float %4362)  ; Saturate(value)
  %4366 = call float @dx.op.unary.f32(i32 7, float %4363)  ; Saturate(value)
  %4367 = call float @dx.op.unary.f32(i32 7, float %4364)  ; Saturate(value)
  %4368 = call float @dx.op.dot3.f32(i32 55, float %4365, float %4366, float %4367, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4369 = fsub fast float %4365, %4368
  %4370 = fsub fast float %4366, %4368
  %4371 = fsub fast float %4367, %4368
  %4372 = fmul fast float %4369, %9
  %4373 = fmul fast float %4370, %9
  %4374 = fmul fast float %4371, %9
  %4375 = fadd fast float %4372, %4368
  %4376 = fadd fast float %4373, %4368
  %4377 = fadd fast float %4374, %4368
  %4378 = call float @dx.op.unary.f32(i32 7, float %4375)  ; Saturate(value)
  %4379 = call float @dx.op.unary.f32(i32 7, float %4376)  ; Saturate(value)
  %4380 = call float @dx.op.unary.f32(i32 7, float %4377)  ; Saturate(value)
  %4381 = fadd fast float %4378, 0xBFC70A3D80000000
  %4382 = fadd fast float %4379, 0xBFC70A3D80000000
  %4383 = fadd fast float %4380, 0xBFC70A3D80000000
  %4384 = fmul fast float %4381, %8
  %4385 = fmul fast float %4382, %8
  %4386 = fmul fast float %4383, %8
  %4387 = fadd fast float %4384, 0x3FC70A3D80000000
  %4388 = fadd fast float %4385, 0x3FC70A3D80000000
  %4389 = fadd fast float %4386, 0x3FC70A3D80000000
  %4390 = call float @dx.op.unary.f32(i32 7, float %4387)  ; Saturate(value)
  %4391 = call float @dx.op.unary.f32(i32 7, float %4388)  ; Saturate(value)
  %4392 = call float @dx.op.unary.f32(i32 7, float %4389)  ; Saturate(value)
  br label %4393

; <label>:4393                                    ; preds = %4361, %4196
  %4394 = phi float [ %4227, %4196 ], [ %4390, %4361 ]
  %4395 = phi float [ %4228, %4196 ], [ %4391, %4361 ]
  %4396 = phi float [ %4229, %4196 ], [ %4392, %4361 ]
  %4397 = fsub fast float %4394, %3690
  %4398 = fsub fast float %4395, %3691
  %4399 = fsub fast float %4396, %3692
  %4400 = fmul fast float %4397, %4183
  %4401 = fmul fast float %4398, %4183
  %4402 = fmul fast float %4399, %4183
  %4403 = fadd fast float %4400, %3690
  %4404 = fadd fast float %4401, %3691
  %4405 = fadd fast float %4402, %3692
  br label %4406

; <label>:4406                                    ; preds = %4393, %4168
  %4407 = phi float [ %4403, %4393 ], [ %3690, %4168 ]
  %4408 = phi float [ %4404, %4393 ], [ %3691, %4168 ]
  %4409 = phi float [ %4405, %4393 ], [ %3692, %4168 ]
  %4410 = add i32 %64, 1
  %4411 = call i32 @dx.op.binary.i32(i32 37, i32 %4410, i32 0)  ; IMax(a,b)
  %4412 = call i32 @dx.op.binary.i32(i32 38, i32 %4411, i32 %60)  ; IMin(a,b)
  %4413 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4412, i32 %4176, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4414 = extractvalue %dx.types.ResRet.f32 %4413, 0
  %4415 = fsub fast float %4414, %83
  %4416 = call float @dx.op.unary.f32(i32 6, float %4415)  ; FAbs(value)
  %4417 = fdiv fast float %4416, %3704
  %4418 = fsub fast float 1.000000e+00, %4417
  %4419 = call float @dx.op.unary.f32(i32 7, float %4418)  ; Saturate(value)
  %4420 = fcmp fast ugt float %4419, 0.000000e+00
  br i1 %4420, label %4421, label %4642

; <label>:4421                                    ; preds = %4406
  %4422 = call i32 @dx.op.binary.i32(i32 37, i32 %4412, i32 0)  ; IMax(a,b)
  %4423 = call i32 @dx.op.binary.i32(i32 37, i32 %4176, i32 0)  ; IMax(a,b)
  %4424 = call i32 @dx.op.binary.i32(i32 38, i32 %4422, i32 %60)  ; IMin(a,b)
  %4425 = call i32 @dx.op.binary.i32(i32 38, i32 %4423, i32 %61)  ; IMin(a,b)
  %4426 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4424, i32 %4425, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4427 = extractvalue %dx.types.ResRet.f32 %4426, 0
  %4428 = extractvalue %dx.types.ResRet.f32 %4426, 1
  %4429 = extractvalue %dx.types.ResRet.f32 %4426, 2
  %4430 = extractvalue %dx.types.ResRet.f32 %4426, 3
  %4431 = fcmp fast olt float %4430, 0.000000e+00
  br i1 %4431, label %4432, label %4466

; <label>:4432                                    ; preds = %4421
  %4433 = fcmp fast ogt float %4427, 0x3FA4B5DCC0000000
  %4434 = fcmp fast ogt float %4428, 0x3FA4B5DCC0000000
  %4435 = fcmp fast ogt float %4429, 0x3FA4B5DCC0000000
  %4436 = select i1 %4433, float 0.000000e+00, float 1.000000e+00
  %4437 = select i1 %4434, float 0.000000e+00, float 1.000000e+00
  %4438 = select i1 %4435, float 0.000000e+00, float 1.000000e+00
  %4439 = fmul fast float %4427, 0x3FB3D07220000000
  %4440 = fmul fast float %4428, 0x3FB3D07220000000
  %4441 = fmul fast float %4429, 0x3FB3D07220000000
  %4442 = fadd fast float %4427, 0x3FAC28F5C0000000
  %4443 = fadd fast float %4428, 0x3FAC28F5C0000000
  %4444 = fadd fast float %4429, 0x3FAC28F5C0000000
  %4445 = fmul fast float %4442, 0x3FEE54EDE0000000
  %4446 = fmul fast float %4443, 0x3FEE54EDE0000000
  %4447 = fmul fast float %4444, 0x3FEE54EDE0000000
  %4448 = call float @dx.op.unary.f32(i32 23, float %4445)  ; Log(value)
  %4449 = call float @dx.op.unary.f32(i32 23, float %4446)  ; Log(value)
  %4450 = call float @dx.op.unary.f32(i32 23, float %4447)  ; Log(value)
  %4451 = fmul fast float %4448, 0x4003333340000000
  %4452 = fmul fast float %4449, 0x4003333340000000
  %4453 = fmul fast float %4450, 0x4003333340000000
  %4454 = call float @dx.op.unary.f32(i32 21, float %4451)  ; Exp(value)
  %4455 = call float @dx.op.unary.f32(i32 21, float %4452)  ; Exp(value)
  %4456 = call float @dx.op.unary.f32(i32 21, float %4453)  ; Exp(value)
  %4457 = fsub fast float %4439, %4454
  %4458 = fsub fast float %4440, %4455
  %4459 = fsub fast float %4441, %4456
  %4460 = fmul fast float %4457, %4436
  %4461 = fmul fast float %4458, %4437
  %4462 = fmul fast float %4459, %4438
  %4463 = fadd fast float %4460, %4454
  %4464 = fadd fast float %4461, %4455
  %4465 = fadd fast float %4462, %4456
  br label %4629

; <label>:4466                                    ; preds = %4421
  %4467 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4424, i32 %4425, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4468 = extractvalue %dx.types.ResRet.f32 %4467, 0
  %4469 = fcmp fast ogt float %39, 5.000000e-01
  %4470 = fcmp fast olt float %4468, 1.000000e+00
  %4471 = and i1 %4469, %4470
  br i1 %4471, label %4472, label %4558

; <label>:4472                                    ; preds = %4466
  %4473 = sitofp i32 %4424 to float
  %4474 = sitofp i32 %4425 to float
  %4475 = fadd fast float %4473, 5.000000e-01
  %4476 = fadd fast float %4474, 5.000000e-01
  %4477 = fdiv fast float %4475, %46
  %4478 = fdiv fast float %4476, %47
  %4479 = fmul fast float %4477, 2.000000e+00
  %4480 = fmul fast float %4478, 2.000000e+00
  %4481 = fadd fast float %4479, -1.000000e+00
  %4482 = fsub fast float 1.000000e+00, %4480
  %4483 = fmul fast float %4481, %36
  %4484 = call float @dx.op.tertiary.f32(i32 46, float %4482, float %32, float %4483)  ; FMad(a,b,c)
  %4485 = call float @dx.op.tertiary.f32(i32 46, float %4468, float %28, float %4484)  ; FMad(a,b,c)
  %4486 = fadd fast float %4485, %24
  %4487 = call float @dx.op.unary.f32(i32 6, float %4486)  ; FAbs(value)
  %4488 = fcmp fast ogt float %4487, 0x3EB0C6F7A0000000
  br i1 %4488, label %4489, label %4558

; <label>:4489                                    ; preds = %4472
  %4490 = fmul fast float %4481, %35
  %4491 = call float @dx.op.tertiary.f32(i32 46, float %4482, float %31, float %4490)  ; FMad(a,b,c)
  %4492 = call float @dx.op.tertiary.f32(i32 46, float %4468, float %27, float %4491)  ; FMad(a,b,c)
  %4493 = fadd fast float %4492, %23
  %4494 = fmul fast float %4481, %34
  %4495 = call float @dx.op.tertiary.f32(i32 46, float %4482, float %30, float %4494)  ; FMad(a,b,c)
  %4496 = call float @dx.op.tertiary.f32(i32 46, float %4468, float %26, float %4495)  ; FMad(a,b,c)
  %4497 = fadd fast float %4496, %22
  %4498 = fmul fast float %4481, %33
  %4499 = call float @dx.op.tertiary.f32(i32 46, float %4482, float %29, float %4498)  ; FMad(a,b,c)
  %4500 = call float @dx.op.tertiary.f32(i32 46, float %4468, float %25, float %4499)  ; FMad(a,b,c)
  %4501 = fadd fast float %4500, %21
  %4502 = fdiv fast float %4501, %4486
  %4503 = fdiv fast float %4497, %4486
  %4504 = fdiv fast float %4493, %4486
  %4505 = fsub fast float %4502, %18
  %4506 = fsub fast float %4503, %19
  %4507 = fsub fast float %4504, %20
  %4508 = fmul fast float %4505, %4505
  %4509 = fmul fast float %4506, %4506
  %4510 = fadd fast float %4509, %4508
  %4511 = fmul fast float %4507, %4507
  %4512 = fadd fast float %4510, %4511
  %4513 = call float @dx.op.unary.f32(i32 24, float %4512)  ; Sqrt(value)
  %4514 = fsub fast float %4513, %10
  %4515 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4514)  ; FMax(a,b)
  %4516 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %4516, label %4517, label %4540

; <label>:4517                                    ; preds = %4489
  %4518 = call float @dx.op.unary.f32(i32 6, float %4506)  ; FAbs(value)
  %4519 = fmul fast float %4518, %12
  %4520 = fcmp fast olt float %4519, 0x3F50624DE0000000
  br i1 %4520, label %4521, label %4524

; <label>:4521                                    ; preds = %4517
  %4522 = fmul fast float %4519, 5.000000e-01
  %4523 = fsub fast float 1.000000e+00, %4522
  br label %4529

; <label>:4524                                    ; preds = %4517
  %4525 = fmul fast float %4519, 0xBFF7154760000000
  %4526 = call float @dx.op.unary.f32(i32 21, float %4525)  ; Exp(value)
  %4527 = fsub fast float 1.000000e+00, %4526
  %4528 = fdiv fast float %4527, %4519
  br label %4529

; <label>:4529                                    ; preds = %4524, %4521
  %4530 = phi float [ %4523, %4521 ], [ %4528, %4524 ]
  %4531 = call float @dx.op.binary.f32(i32 36, float %4503, float %19)  ; FMin(a,b)
  %4532 = fsub fast float %4531, %11
  %4533 = fmul fast float %12, %4532
  %4534 = fsub fast float -0.000000e+00, %4533
  %4535 = call float @dx.op.binary.f32(i32 35, float %4534, float -4.000000e+01)  ; FMax(a,b)
  %4536 = call float @dx.op.binary.f32(i32 36, float %4535, float 5.000000e+00)  ; FMin(a,b)
  %4537 = fmul fast float %4536, 0x3FF7154760000000
  %4538 = call float @dx.op.unary.f32(i32 21, float %4537)  ; Exp(value)
  %4539 = fmul fast float %4538, %4530
  br label %4540

; <label>:4540                                    ; preds = %4529, %4489
  %4541 = phi float [ %4539, %4529 ], [ 1.000000e+00, %4489 ]
  %4542 = fmul fast float %4515, %17
  %4543 = fmul fast float %4542, %4541
  %4544 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4543)  ; FMin(a,b)
  %4545 = fmul fast float %4544, 0xBFF7154760000000
  %4546 = call float @dx.op.unary.f32(i32 21, float %4545)  ; Exp(value)
  %4547 = fsub fast float 1.000000e+00, %4546
  %4548 = call float @dx.op.binary.f32(i32 36, float %13, float %4547)  ; FMin(a,b)
  %4549 = fsub fast float %14, %4427
  %4550 = fsub fast float %15, %4428
  %4551 = fsub fast float %16, %4429
  %4552 = fmul fast float %4548, %4549
  %4553 = fmul fast float %4548, %4550
  %4554 = fmul fast float %4548, %4551
  %4555 = fadd fast float %4552, %4427
  %4556 = fadd fast float %4553, %4428
  %4557 = fadd fast float %4554, %4429
  br label %4558

; <label>:4558                                    ; preds = %4540, %4472, %4466
  %4559 = phi float [ %4555, %4540 ], [ %4427, %4472 ], [ %4427, %4466 ]
  %4560 = phi float [ %4556, %4540 ], [ %4428, %4472 ], [ %4428, %4466 ]
  %4561 = phi float [ %4557, %4540 ], [ %4429, %4472 ], [ %4429, %4466 ]
  %4562 = fadd fast float %6, 1.000000e+00
  %4563 = fadd fast float %7, 1.000000e+00
  %4564 = fsub fast float 1.000000e+00, %6
  %4565 = fmul fast float %37, %4562
  %4566 = fmul fast float %37, %4563
  %4567 = fmul fast float %37, %4564
  %4568 = fmul fast float %4565, %4559
  %4569 = fmul fast float %4566, %4560
  %4570 = fmul fast float %4567, %4561
  %4571 = fcmp fast ult float %38, 5.000000e-01
  br i1 %4571, label %4597, label %4572

; <label>:4572                                    ; preds = %4558
  %4573 = fmul fast float %4568, 0x4004147AE0000000
  %4574 = fmul fast float %4569, 0x4004147AE0000000
  %4575 = fmul fast float %4570, 0x4004147AE0000000
  %4576 = fadd fast float %4573, 0x3F9EB851E0000000
  %4577 = fadd fast float %4574, 0x3F9EB851E0000000
  %4578 = fadd fast float %4575, 0x3F9EB851E0000000
  %4579 = fmul fast float %4576, %4568
  %4580 = fmul fast float %4577, %4569
  %4581 = fmul fast float %4578, %4570
  %4582 = fmul fast float %4568, 0x400370A3E0000000
  %4583 = fmul fast float %4569, 0x400370A3E0000000
  %4584 = fmul fast float %4570, 0x400370A3E0000000
  %4585 = fadd fast float %4582, 0x3FE2E147A0000000
  %4586 = fadd fast float %4583, 0x3FE2E147A0000000
  %4587 = fadd fast float %4584, 0x3FE2E147A0000000
  %4588 = fmul fast float %4585, %4568
  %4589 = fmul fast float %4586, %4569
  %4590 = fmul fast float %4587, %4570
  %4591 = fadd fast float %4588, 0x3FC1EB8520000000
  %4592 = fadd fast float %4589, 0x3FC1EB8520000000
  %4593 = fadd fast float %4590, 0x3FC1EB8520000000
  %4594 = fdiv fast float %4579, %4591
  %4595 = fdiv fast float %4580, %4592
  %4596 = fdiv fast float %4581, %4593
  br label %4597

; <label>:4597                                    ; preds = %4572, %4558
  %4598 = phi float [ %4594, %4572 ], [ %4568, %4558 ]
  %4599 = phi float [ %4595, %4572 ], [ %4569, %4558 ]
  %4600 = phi float [ %4596, %4572 ], [ %4570, %4558 ]
  %4601 = call float @dx.op.unary.f32(i32 7, float %4598)  ; Saturate(value)
  %4602 = call float @dx.op.unary.f32(i32 7, float %4599)  ; Saturate(value)
  %4603 = call float @dx.op.unary.f32(i32 7, float %4600)  ; Saturate(value)
  %4604 = call float @dx.op.dot3.f32(i32 55, float %4601, float %4602, float %4603, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4605 = fsub fast float %4601, %4604
  %4606 = fsub fast float %4602, %4604
  %4607 = fsub fast float %4603, %4604
  %4608 = fmul fast float %4605, %9
  %4609 = fmul fast float %4606, %9
  %4610 = fmul fast float %4607, %9
  %4611 = fadd fast float %4608, %4604
  %4612 = fadd fast float %4609, %4604
  %4613 = fadd fast float %4610, %4604
  %4614 = call float @dx.op.unary.f32(i32 7, float %4611)  ; Saturate(value)
  %4615 = call float @dx.op.unary.f32(i32 7, float %4612)  ; Saturate(value)
  %4616 = call float @dx.op.unary.f32(i32 7, float %4613)  ; Saturate(value)
  %4617 = fadd fast float %4614, 0xBFC70A3D80000000
  %4618 = fadd fast float %4615, 0xBFC70A3D80000000
  %4619 = fadd fast float %4616, 0xBFC70A3D80000000
  %4620 = fmul fast float %4617, %8
  %4621 = fmul fast float %4618, %8
  %4622 = fmul fast float %4619, %8
  %4623 = fadd fast float %4620, 0x3FC70A3D80000000
  %4624 = fadd fast float %4621, 0x3FC70A3D80000000
  %4625 = fadd fast float %4622, 0x3FC70A3D80000000
  %4626 = call float @dx.op.unary.f32(i32 7, float %4623)  ; Saturate(value)
  %4627 = call float @dx.op.unary.f32(i32 7, float %4624)  ; Saturate(value)
  %4628 = call float @dx.op.unary.f32(i32 7, float %4625)  ; Saturate(value)
  br label %4629

; <label>:4629                                    ; preds = %4597, %4432
  %4630 = phi float [ %4463, %4432 ], [ %4626, %4597 ]
  %4631 = phi float [ %4464, %4432 ], [ %4627, %4597 ]
  %4632 = phi float [ %4465, %4432 ], [ %4628, %4597 ]
  %4633 = fsub fast float %4630, %3690
  %4634 = fsub fast float %4631, %3691
  %4635 = fsub fast float %4632, %3692
  %4636 = fmul fast float %4633, %4419
  %4637 = fmul fast float %4634, %4419
  %4638 = fmul fast float %4635, %4419
  %4639 = fadd fast float %4636, %3690
  %4640 = fadd fast float %4637, %3691
  %4641 = fadd fast float %4638, %3692
  br label %4642

; <label>:4642                                    ; preds = %4629, %4406
  %4643 = phi float [ %4639, %4629 ], [ %3690, %4406 ]
  %4644 = phi float [ %4640, %4629 ], [ %3691, %4406 ]
  %4645 = phi float [ %4641, %4629 ], [ %3692, %4406 ]
  %4646 = call float @dx.op.binary.f32(i32 36, float %4407, float %4643)  ; FMin(a,b)
  %4647 = call float @dx.op.binary.f32(i32 36, float %4408, float %4644)  ; FMin(a,b)
  %4648 = call float @dx.op.binary.f32(i32 36, float %4409, float %4645)  ; FMin(a,b)
  %4649 = call float @dx.op.binary.f32(i32 36, float %3933, float %4169)  ; FMin(a,b)
  %4650 = call float @dx.op.binary.f32(i32 36, float %3934, float %4170)  ; FMin(a,b)
  %4651 = call float @dx.op.binary.f32(i32 36, float %3935, float %4171)  ; FMin(a,b)
  %4652 = call float @dx.op.binary.f32(i32 36, float %4649, float %4646)  ; FMin(a,b)
  %4653 = call float @dx.op.binary.f32(i32 36, float %4650, float %4647)  ; FMin(a,b)
  %4654 = call float @dx.op.binary.f32(i32 36, float %4651, float %4648)  ; FMin(a,b)
  %4655 = call float @dx.op.binary.f32(i32 36, float %3690, float %4652)  ; FMin(a,b)
  %4656 = call float @dx.op.binary.f32(i32 36, float %3691, float %4653)  ; FMin(a,b)
  %4657 = call float @dx.op.binary.f32(i32 36, float %3692, float %4654)  ; FMin(a,b)
  %4658 = call float @dx.op.binary.f32(i32 35, float %4407, float %4643)  ; FMax(a,b)
  %4659 = call float @dx.op.binary.f32(i32 35, float %4408, float %4644)  ; FMax(a,b)
  %4660 = call float @dx.op.binary.f32(i32 35, float %4409, float %4645)  ; FMax(a,b)
  %4661 = call float @dx.op.binary.f32(i32 35, float %3933, float %4169)  ; FMax(a,b)
  %4662 = call float @dx.op.binary.f32(i32 35, float %3934, float %4170)  ; FMax(a,b)
  %4663 = call float @dx.op.binary.f32(i32 35, float %3935, float %4171)  ; FMax(a,b)
  %4664 = call float @dx.op.binary.f32(i32 35, float %4661, float %4658)  ; FMax(a,b)
  %4665 = call float @dx.op.binary.f32(i32 35, float %4662, float %4659)  ; FMax(a,b)
  %4666 = call float @dx.op.binary.f32(i32 35, float %4663, float %4660)  ; FMax(a,b)
  %4667 = call float @dx.op.binary.f32(i32 35, float %3690, float %4664)  ; FMax(a,b)
  %4668 = call float @dx.op.binary.f32(i32 35, float %3691, float %4665)  ; FMax(a,b)
  %4669 = call float @dx.op.binary.f32(i32 35, float %3692, float %4666)  ; FMax(a,b)
  %4670 = fsub fast float %4667, %4655
  %4671 = fsub fast float %4668, %4656
  %4672 = fsub fast float %4669, %4657
  %4673 = call float @dx.op.unary.f32(i32 6, float %4670)  ; FAbs(value)
  %4674 = call float @dx.op.unary.f32(i32 6, float %4671)  ; FAbs(value)
  %4675 = call float @dx.op.unary.f32(i32 6, float %4672)  ; FAbs(value)
  %4676 = call float @dx.op.binary.f32(i32 35, float %4674, float %4675)  ; FMax(a,b)
  %4677 = call float @dx.op.binary.f32(i32 35, float %4673, float %4676)  ; FMax(a,b)
  %4678 = call float @dx.op.binary.f32(i32 35, float %4668, float %4669)  ; FMax(a,b)
  %4679 = call float @dx.op.binary.f32(i32 35, float %4667, float %4678)  ; FMax(a,b)
  %4680 = fmul fast float %4679, 1.250000e-01
  %4681 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %4680)  ; FMax(a,b)
  %4682 = fcmp fast ogt float %4677, %4681
  br i1 %4682, label %4683, label %4745

; <label>:4683                                    ; preds = %4642
  %4684 = fsub fast float %3933, %4169
  %4685 = fsub fast float %3934, %4170
  %4686 = fsub fast float %3935, %4171
  %4687 = call float @dx.op.unary.f32(i32 6, float %4684)  ; FAbs(value)
  %4688 = call float @dx.op.unary.f32(i32 6, float %4685)  ; FAbs(value)
  %4689 = call float @dx.op.unary.f32(i32 6, float %4686)  ; FAbs(value)
  %4690 = call float @dx.op.binary.f32(i32 35, float %4688, float %4689)  ; FMax(a,b)
  %4691 = call float @dx.op.binary.f32(i32 35, float %4687, float %4690)  ; FMax(a,b)
  %4692 = fsub fast float %4407, %4643
  %4693 = fsub fast float %4408, %4644
  %4694 = fsub fast float %4409, %4645
  %4695 = call float @dx.op.unary.f32(i32 6, float %4692)  ; FAbs(value)
  %4696 = call float @dx.op.unary.f32(i32 6, float %4693)  ; FAbs(value)
  %4697 = call float @dx.op.unary.f32(i32 6, float %4694)  ; FAbs(value)
  %4698 = call float @dx.op.binary.f32(i32 35, float %4696, float %4697)  ; FMax(a,b)
  %4699 = call float @dx.op.binary.f32(i32 35, float %4695, float %4698)  ; FMax(a,b)
  %4700 = fcmp fast olt float %4691, %4699
  %4701 = select i1 %4700, float %3933, float %4407
  %4702 = select i1 %4700, float %3934, float %4408
  %4703 = select i1 %4700, float %3935, float %4409
  %4704 = select i1 %4700, float %4169, float %4643
  %4705 = select i1 %4700, float %4170, float %4644
  %4706 = select i1 %4700, float %4171, float %4645
  %4707 = fsub fast float %3690, %4704
  %4708 = fsub fast float %3691, %4705
  %4709 = fsub fast float %3692, %4706
  %4710 = fsub fast float %3690, %4701
  %4711 = fsub fast float %3691, %4702
  %4712 = fsub fast float %3692, %4703
  %4713 = call float @dx.op.dot3.f32(i32 55, float %4710, float %4711, float %4712, float %4707, float %4708, float %4709)  ; Dot3(ax,ay,az,bx,by,bz)
  %4714 = fcmp fast ogt float %4713, 0.000000e+00
  br i1 %4714, label %4715, label %4726

; <label>:4715                                    ; preds = %4683
  %4716 = fsub fast float %4701, %4704
  %4717 = fsub fast float %4702, %4705
  %4718 = fsub fast float %4703, %4706
  %4719 = call float @dx.op.unary.f32(i32 6, float %4716)  ; FAbs(value)
  %4720 = call float @dx.op.unary.f32(i32 6, float %4717)  ; FAbs(value)
  %4721 = call float @dx.op.unary.f32(i32 6, float %4718)  ; FAbs(value)
  %4722 = call float @dx.op.binary.f32(i32 35, float %4720, float %4721)  ; FMax(a,b)
  %4723 = call float @dx.op.binary.f32(i32 35, float %4719, float %4722)  ; FMax(a,b)
  %4724 = fmul fast float %4677, 2.500000e-01
  %4725 = fcmp fast olt float %4723, %4724
  br label %4726

; <label>:4726                                    ; preds = %4715, %4683
  %4727 = phi i1 [ false, %4683 ], [ %4725, %4715 ]
  %4728 = select i1 %4727, float 5.000000e-01, float 1.000000e+00
  %4729 = fmul fast float %4728, %3
  %4730 = fadd fast float %4701, %4704
  %4731 = fadd fast float %4702, %4705
  %4732 = fadd fast float %4703, %4706
  %4733 = fmul fast float %4730, 5.000000e-01
  %4734 = fmul fast float %4731, 5.000000e-01
  %4735 = fmul fast float %4732, 5.000000e-01
  %4736 = fsub fast float %4733, %3690
  %4737 = fsub fast float %4734, %3691
  %4738 = fsub fast float %4735, %3692
  %4739 = fmul fast float %4729, %4736
  %4740 = fmul fast float %4729, %4737
  %4741 = fmul fast float %4729, %4738
  %4742 = fadd fast float %4739, %3690
  %4743 = fadd fast float %4740, %3691
  %4744 = fadd fast float %4741, %3692
  br label %4745

; <label>:4745                                    ; preds = %4726, %4642, %3661, %3497
  %4746 = phi float [ %3528, %3497 ], [ %3690, %3661 ], [ %4742, %4726 ], [ %3690, %4642 ]
  %4747 = phi float [ %3529, %3497 ], [ %3691, %3661 ], [ %4743, %4726 ], [ %3691, %4642 ]
  %4748 = phi float [ %3530, %3497 ], [ %3692, %3661 ], [ %4744, %4726 ], [ %3692, %4642 ]
  %4749 = phi float [ %3531, %3497 ], [ %3495, %3661 ], [ %3495, %4726 ], [ %3495, %4642 ]
  %4750 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %68, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4751 = extractvalue %dx.types.ResRet.f32 %4750, 0
  %4752 = extractvalue %dx.types.ResRet.f32 %4750, 1
  %4753 = extractvalue %dx.types.ResRet.f32 %4750, 2
  %4754 = extractvalue %dx.types.ResRet.f32 %4750, 3
  %4755 = fcmp fast olt float %4754, 0.000000e+00
  br i1 %4755, label %4756, label %4791

; <label>:4756                                    ; preds = %4745
  %4757 = fcmp fast ogt float %4751, 0x3FA4B5DCC0000000
  %4758 = fcmp fast ogt float %4752, 0x3FA4B5DCC0000000
  %4759 = fcmp fast ogt float %4753, 0x3FA4B5DCC0000000
  %4760 = select i1 %4757, float 0.000000e+00, float 1.000000e+00
  %4761 = select i1 %4758, float 0.000000e+00, float 1.000000e+00
  %4762 = select i1 %4759, float 0.000000e+00, float 1.000000e+00
  %4763 = fmul fast float %4751, 0x3FB3D07220000000
  %4764 = fmul fast float %4752, 0x3FB3D07220000000
  %4765 = fmul fast float %4753, 0x3FB3D07220000000
  %4766 = fadd fast float %4751, 0x3FAC28F5C0000000
  %4767 = fadd fast float %4752, 0x3FAC28F5C0000000
  %4768 = fadd fast float %4753, 0x3FAC28F5C0000000
  %4769 = fmul fast float %4766, 0x3FEE54EDE0000000
  %4770 = fmul fast float %4767, 0x3FEE54EDE0000000
  %4771 = fmul fast float %4768, 0x3FEE54EDE0000000
  %4772 = call float @dx.op.unary.f32(i32 23, float %4769)  ; Log(value)
  %4773 = call float @dx.op.unary.f32(i32 23, float %4770)  ; Log(value)
  %4774 = call float @dx.op.unary.f32(i32 23, float %4771)  ; Log(value)
  %4775 = fmul fast float %4772, 0x4003333340000000
  %4776 = fmul fast float %4773, 0x4003333340000000
  %4777 = fmul fast float %4774, 0x4003333340000000
  %4778 = call float @dx.op.unary.f32(i32 21, float %4775)  ; Exp(value)
  %4779 = call float @dx.op.unary.f32(i32 21, float %4776)  ; Exp(value)
  %4780 = call float @dx.op.unary.f32(i32 21, float %4777)  ; Exp(value)
  %4781 = fsub fast float %4763, %4778
  %4782 = fsub fast float %4764, %4779
  %4783 = fsub fast float %4765, %4780
  %4784 = fmul fast float %4781, %4760
  %4785 = fmul fast float %4782, %4761
  %4786 = fmul fast float %4783, %4762
  %4787 = fadd fast float %4784, %4778
  %4788 = fadd fast float %4785, %4779
  %4789 = fadd fast float %4786, %4780
  %4790 = fsub fast float -1.000000e+00, %4754
  br label %6004

; <label>:4791                                    ; preds = %4745
  %4792 = fcmp fast ogt float %39, 5.000000e-01
  %4793 = fcmp fast olt float %85, 1.000000e+00
  %4794 = and i1 %4792, %4793
  br i1 %4794, label %4795, label %4881

; <label>:4795                                    ; preds = %4791
  %4796 = sitofp i32 %68 to float
  %4797 = sitofp i32 %65 to float
  %4798 = fadd fast float %4796, 5.000000e-01
  %4799 = fadd fast float %4797, 5.000000e-01
  %4800 = fdiv fast float %4798, %46
  %4801 = fdiv fast float %4799, %47
  %4802 = fmul fast float %4800, 2.000000e+00
  %4803 = fmul fast float %4801, 2.000000e+00
  %4804 = fadd fast float %4802, -1.000000e+00
  %4805 = fsub fast float 1.000000e+00, %4803
  %4806 = fmul fast float %4804, %36
  %4807 = call float @dx.op.tertiary.f32(i32 46, float %4805, float %32, float %4806)  ; FMad(a,b,c)
  %4808 = call float @dx.op.tertiary.f32(i32 46, float %85, float %28, float %4807)  ; FMad(a,b,c)
  %4809 = fadd fast float %4808, %24
  %4810 = call float @dx.op.unary.f32(i32 6, float %4809)  ; FAbs(value)
  %4811 = fcmp fast ogt float %4810, 0x3EB0C6F7A0000000
  br i1 %4811, label %4812, label %4881

; <label>:4812                                    ; preds = %4795
  %4813 = fmul fast float %4804, %35
  %4814 = call float @dx.op.tertiary.f32(i32 46, float %4805, float %31, float %4813)  ; FMad(a,b,c)
  %4815 = call float @dx.op.tertiary.f32(i32 46, float %85, float %27, float %4814)  ; FMad(a,b,c)
  %4816 = fadd fast float %4815, %23
  %4817 = fmul fast float %4804, %34
  %4818 = call float @dx.op.tertiary.f32(i32 46, float %4805, float %30, float %4817)  ; FMad(a,b,c)
  %4819 = call float @dx.op.tertiary.f32(i32 46, float %85, float %26, float %4818)  ; FMad(a,b,c)
  %4820 = fadd fast float %4819, %22
  %4821 = fmul fast float %4804, %33
  %4822 = call float @dx.op.tertiary.f32(i32 46, float %4805, float %29, float %4821)  ; FMad(a,b,c)
  %4823 = call float @dx.op.tertiary.f32(i32 46, float %85, float %25, float %4822)  ; FMad(a,b,c)
  %4824 = fadd fast float %4823, %21
  %4825 = fdiv fast float %4824, %4809
  %4826 = fdiv fast float %4820, %4809
  %4827 = fdiv fast float %4816, %4809
  %4828 = fsub fast float %4825, %18
  %4829 = fsub fast float %4826, %19
  %4830 = fsub fast float %4827, %20
  %4831 = fmul fast float %4828, %4828
  %4832 = fmul fast float %4829, %4829
  %4833 = fadd fast float %4832, %4831
  %4834 = fmul fast float %4830, %4830
  %4835 = fadd fast float %4833, %4834
  %4836 = call float @dx.op.unary.f32(i32 24, float %4835)  ; Sqrt(value)
  %4837 = fsub fast float %4836, %10
  %4838 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4837)  ; FMax(a,b)
  %4839 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %4839, label %4840, label %4863

; <label>:4840                                    ; preds = %4812
  %4841 = call float @dx.op.unary.f32(i32 6, float %4829)  ; FAbs(value)
  %4842 = fmul fast float %4841, %12
  %4843 = fcmp fast olt float %4842, 0x3F50624DE0000000
  br i1 %4843, label %4844, label %4847

; <label>:4844                                    ; preds = %4840
  %4845 = fmul fast float %4842, 5.000000e-01
  %4846 = fsub fast float 1.000000e+00, %4845
  br label %4852

; <label>:4847                                    ; preds = %4840
  %4848 = fmul fast float %4842, 0xBFF7154760000000
  %4849 = call float @dx.op.unary.f32(i32 21, float %4848)  ; Exp(value)
  %4850 = fsub fast float 1.000000e+00, %4849
  %4851 = fdiv fast float %4850, %4842
  br label %4852

; <label>:4852                                    ; preds = %4847, %4844
  %4853 = phi float [ %4846, %4844 ], [ %4851, %4847 ]
  %4854 = call float @dx.op.binary.f32(i32 36, float %4826, float %19)  ; FMin(a,b)
  %4855 = fsub fast float %4854, %11
  %4856 = fmul fast float %12, %4855
  %4857 = fsub fast float -0.000000e+00, %4856
  %4858 = call float @dx.op.binary.f32(i32 35, float %4857, float -4.000000e+01)  ; FMax(a,b)
  %4859 = call float @dx.op.binary.f32(i32 36, float %4858, float 5.000000e+00)  ; FMin(a,b)
  %4860 = fmul fast float %4859, 0x3FF7154760000000
  %4861 = call float @dx.op.unary.f32(i32 21, float %4860)  ; Exp(value)
  %4862 = fmul fast float %4861, %4853
  br label %4863

; <label>:4863                                    ; preds = %4852, %4812
  %4864 = phi float [ %4862, %4852 ], [ 1.000000e+00, %4812 ]
  %4865 = fmul fast float %4838, %17
  %4866 = fmul fast float %4865, %4864
  %4867 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4866)  ; FMin(a,b)
  %4868 = fmul fast float %4867, 0xBFF7154760000000
  %4869 = call float @dx.op.unary.f32(i32 21, float %4868)  ; Exp(value)
  %4870 = fsub fast float 1.000000e+00, %4869
  %4871 = call float @dx.op.binary.f32(i32 36, float %13, float %4870)  ; FMin(a,b)
  %4872 = fsub fast float %14, %4751
  %4873 = fsub fast float %15, %4752
  %4874 = fsub fast float %16, %4753
  %4875 = fmul fast float %4871, %4872
  %4876 = fmul fast float %4871, %4873
  %4877 = fmul fast float %4871, %4874
  %4878 = fadd fast float %4875, %4751
  %4879 = fadd fast float %4876, %4752
  %4880 = fadd fast float %4877, %4753
  br label %4881

; <label>:4881                                    ; preds = %4863, %4795, %4791
  %4882 = phi float [ %4878, %4863 ], [ %4751, %4795 ], [ %4751, %4791 ]
  %4883 = phi float [ %4879, %4863 ], [ %4752, %4795 ], [ %4752, %4791 ]
  %4884 = phi float [ %4880, %4863 ], [ %4753, %4795 ], [ %4753, %4791 ]
  %4885 = fadd fast float %6, 1.000000e+00
  %4886 = fadd fast float %7, 1.000000e+00
  %4887 = fsub fast float 1.000000e+00, %6
  %4888 = fmul fast float %37, %4885
  %4889 = fmul fast float %37, %4886
  %4890 = fmul fast float %37, %4887
  %4891 = fmul fast float %4888, %4882
  %4892 = fmul fast float %4889, %4883
  %4893 = fmul fast float %4890, %4884
  %4894 = fcmp fast ult float %38, 5.000000e-01
  br i1 %4894, label %4920, label %4895

; <label>:4895                                    ; preds = %4881
  %4896 = fmul fast float %4891, 0x4004147AE0000000
  %4897 = fmul fast float %4892, 0x4004147AE0000000
  %4898 = fmul fast float %4893, 0x4004147AE0000000
  %4899 = fadd fast float %4896, 0x3F9EB851E0000000
  %4900 = fadd fast float %4897, 0x3F9EB851E0000000
  %4901 = fadd fast float %4898, 0x3F9EB851E0000000
  %4902 = fmul fast float %4899, %4891
  %4903 = fmul fast float %4900, %4892
  %4904 = fmul fast float %4901, %4893
  %4905 = fmul fast float %4891, 0x400370A3E0000000
  %4906 = fmul fast float %4892, 0x400370A3E0000000
  %4907 = fmul fast float %4893, 0x400370A3E0000000
  %4908 = fadd fast float %4905, 0x3FE2E147A0000000
  %4909 = fadd fast float %4906, 0x3FE2E147A0000000
  %4910 = fadd fast float %4907, 0x3FE2E147A0000000
  %4911 = fmul fast float %4908, %4891
  %4912 = fmul fast float %4909, %4892
  %4913 = fmul fast float %4910, %4893
  %4914 = fadd fast float %4911, 0x3FC1EB8520000000
  %4915 = fadd fast float %4912, 0x3FC1EB8520000000
  %4916 = fadd fast float %4913, 0x3FC1EB8520000000
  %4917 = fdiv fast float %4902, %4914
  %4918 = fdiv fast float %4903, %4915
  %4919 = fdiv fast float %4904, %4916
  br label %4920

; <label>:4920                                    ; preds = %4895, %4881
  %4921 = phi float [ %4917, %4895 ], [ %4891, %4881 ]
  %4922 = phi float [ %4918, %4895 ], [ %4892, %4881 ]
  %4923 = phi float [ %4919, %4895 ], [ %4893, %4881 ]
  %4924 = call float @dx.op.unary.f32(i32 7, float %4921)  ; Saturate(value)
  %4925 = call float @dx.op.unary.f32(i32 7, float %4922)  ; Saturate(value)
  %4926 = call float @dx.op.unary.f32(i32 7, float %4923)  ; Saturate(value)
  %4927 = call float @dx.op.dot3.f32(i32 55, float %4924, float %4925, float %4926, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4928 = fsub fast float %4924, %4927
  %4929 = fsub fast float %4925, %4927
  %4930 = fsub fast float %4926, %4927
  %4931 = fmul fast float %4928, %9
  %4932 = fmul fast float %4929, %9
  %4933 = fmul fast float %4930, %9
  %4934 = fadd fast float %4931, %4927
  %4935 = fadd fast float %4932, %4927
  %4936 = fadd fast float %4933, %4927
  %4937 = call float @dx.op.unary.f32(i32 7, float %4934)  ; Saturate(value)
  %4938 = call float @dx.op.unary.f32(i32 7, float %4935)  ; Saturate(value)
  %4939 = call float @dx.op.unary.f32(i32 7, float %4936)  ; Saturate(value)
  %4940 = fadd fast float %4937, 0xBFC70A3D80000000
  %4941 = fadd fast float %4938, 0xBFC70A3D80000000
  %4942 = fadd fast float %4939, 0xBFC70A3D80000000
  %4943 = fmul fast float %4940, %8
  %4944 = fmul fast float %4941, %8
  %4945 = fmul fast float %4942, %8
  %4946 = fadd fast float %4943, 0x3FC70A3D80000000
  %4947 = fadd fast float %4944, 0x3FC70A3D80000000
  %4948 = fadd fast float %4945, 0x3FC70A3D80000000
  %4949 = call float @dx.op.unary.f32(i32 7, float %4946)  ; Saturate(value)
  %4950 = call float @dx.op.unary.f32(i32 7, float %4947)  ; Saturate(value)
  %4951 = call float @dx.op.unary.f32(i32 7, float %4948)  ; Saturate(value)
  %4952 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %4952, label %4953, label %6004

; <label>:4953                                    ; preds = %4920
  %4954 = add i32 %65, -1
  %4955 = call i32 @dx.op.binary.i32(i32 37, i32 %68, i32 0)  ; IMax(a,b)
  %4956 = call i32 @dx.op.binary.i32(i32 37, i32 %4954, i32 0)  ; IMax(a,b)
  %4957 = call i32 @dx.op.binary.i32(i32 38, i32 %4955, i32 %60)  ; IMin(a,b)
  %4958 = call i32 @dx.op.binary.i32(i32 38, i32 %4956, i32 %61)  ; IMin(a,b)
  %4959 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4957, i32 %4958, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4960 = extractvalue %dx.types.ResRet.f32 %4959, 0
  %4961 = fsub fast float 1.000000e+00, %85
  %4962 = fmul fast float %4961, 0x3FA99999A0000000
  %4963 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %4962)  ; FMax(a,b)
  %4964 = fsub fast float %4960, %85
  %4965 = call float @dx.op.unary.f32(i32 6, float %4964)  ; FAbs(value)
  %4966 = fdiv fast float %4965, %4963
  %4967 = fsub fast float 1.000000e+00, %4966
  %4968 = call float @dx.op.unary.f32(i32 7, float %4967)  ; Saturate(value)
  %4969 = fcmp fast ugt float %4968, 0.000000e+00
  br i1 %4969, label %4970, label %5191

; <label>:4970                                    ; preds = %4953
  %4971 = call i32 @dx.op.binary.i32(i32 37, i32 %4957, i32 0)  ; IMax(a,b)
  %4972 = call i32 @dx.op.binary.i32(i32 37, i32 %4958, i32 0)  ; IMax(a,b)
  %4973 = call i32 @dx.op.binary.i32(i32 38, i32 %4971, i32 %60)  ; IMin(a,b)
  %4974 = call i32 @dx.op.binary.i32(i32 38, i32 %4972, i32 %61)  ; IMin(a,b)
  %4975 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4973, i32 %4974, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4976 = extractvalue %dx.types.ResRet.f32 %4975, 0
  %4977 = extractvalue %dx.types.ResRet.f32 %4975, 1
  %4978 = extractvalue %dx.types.ResRet.f32 %4975, 2
  %4979 = extractvalue %dx.types.ResRet.f32 %4975, 3
  %4980 = fcmp fast olt float %4979, 0.000000e+00
  br i1 %4980, label %4981, label %5015

; <label>:4981                                    ; preds = %4970
  %4982 = fcmp fast ogt float %4976, 0x3FA4B5DCC0000000
  %4983 = fcmp fast ogt float %4977, 0x3FA4B5DCC0000000
  %4984 = fcmp fast ogt float %4978, 0x3FA4B5DCC0000000
  %4985 = select i1 %4982, float 0.000000e+00, float 1.000000e+00
  %4986 = select i1 %4983, float 0.000000e+00, float 1.000000e+00
  %4987 = select i1 %4984, float 0.000000e+00, float 1.000000e+00
  %4988 = fmul fast float %4976, 0x3FB3D07220000000
  %4989 = fmul fast float %4977, 0x3FB3D07220000000
  %4990 = fmul fast float %4978, 0x3FB3D07220000000
  %4991 = fadd fast float %4976, 0x3FAC28F5C0000000
  %4992 = fadd fast float %4977, 0x3FAC28F5C0000000
  %4993 = fadd fast float %4978, 0x3FAC28F5C0000000
  %4994 = fmul fast float %4991, 0x3FEE54EDE0000000
  %4995 = fmul fast float %4992, 0x3FEE54EDE0000000
  %4996 = fmul fast float %4993, 0x3FEE54EDE0000000
  %4997 = call float @dx.op.unary.f32(i32 23, float %4994)  ; Log(value)
  %4998 = call float @dx.op.unary.f32(i32 23, float %4995)  ; Log(value)
  %4999 = call float @dx.op.unary.f32(i32 23, float %4996)  ; Log(value)
  %5000 = fmul fast float %4997, 0x4003333340000000
  %5001 = fmul fast float %4998, 0x4003333340000000
  %5002 = fmul fast float %4999, 0x4003333340000000
  %5003 = call float @dx.op.unary.f32(i32 21, float %5000)  ; Exp(value)
  %5004 = call float @dx.op.unary.f32(i32 21, float %5001)  ; Exp(value)
  %5005 = call float @dx.op.unary.f32(i32 21, float %5002)  ; Exp(value)
  %5006 = fsub fast float %4988, %5003
  %5007 = fsub fast float %4989, %5004
  %5008 = fsub fast float %4990, %5005
  %5009 = fmul fast float %5006, %4985
  %5010 = fmul fast float %5007, %4986
  %5011 = fmul fast float %5008, %4987
  %5012 = fadd fast float %5009, %5003
  %5013 = fadd fast float %5010, %5004
  %5014 = fadd fast float %5011, %5005
  br label %5178

; <label>:5015                                    ; preds = %4970
  %5016 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4973, i32 %4974, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5017 = extractvalue %dx.types.ResRet.f32 %5016, 0
  %5018 = fcmp fast ogt float %39, 5.000000e-01
  %5019 = fcmp fast olt float %5017, 1.000000e+00
  %5020 = and i1 %5018, %5019
  br i1 %5020, label %5021, label %5107

; <label>:5021                                    ; preds = %5015
  %5022 = sitofp i32 %4973 to float
  %5023 = sitofp i32 %4974 to float
  %5024 = fadd fast float %5022, 5.000000e-01
  %5025 = fadd fast float %5023, 5.000000e-01
  %5026 = fdiv fast float %5024, %46
  %5027 = fdiv fast float %5025, %47
  %5028 = fmul fast float %5026, 2.000000e+00
  %5029 = fmul fast float %5027, 2.000000e+00
  %5030 = fadd fast float %5028, -1.000000e+00
  %5031 = fsub fast float 1.000000e+00, %5029
  %5032 = fmul fast float %5030, %36
  %5033 = call float @dx.op.tertiary.f32(i32 46, float %5031, float %32, float %5032)  ; FMad(a,b,c)
  %5034 = call float @dx.op.tertiary.f32(i32 46, float %5017, float %28, float %5033)  ; FMad(a,b,c)
  %5035 = fadd fast float %5034, %24
  %5036 = call float @dx.op.unary.f32(i32 6, float %5035)  ; FAbs(value)
  %5037 = fcmp fast ogt float %5036, 0x3EB0C6F7A0000000
  br i1 %5037, label %5038, label %5107

; <label>:5038                                    ; preds = %5021
  %5039 = fmul fast float %5030, %35
  %5040 = call float @dx.op.tertiary.f32(i32 46, float %5031, float %31, float %5039)  ; FMad(a,b,c)
  %5041 = call float @dx.op.tertiary.f32(i32 46, float %5017, float %27, float %5040)  ; FMad(a,b,c)
  %5042 = fadd fast float %5041, %23
  %5043 = fmul fast float %5030, %34
  %5044 = call float @dx.op.tertiary.f32(i32 46, float %5031, float %30, float %5043)  ; FMad(a,b,c)
  %5045 = call float @dx.op.tertiary.f32(i32 46, float %5017, float %26, float %5044)  ; FMad(a,b,c)
  %5046 = fadd fast float %5045, %22
  %5047 = fmul fast float %5030, %33
  %5048 = call float @dx.op.tertiary.f32(i32 46, float %5031, float %29, float %5047)  ; FMad(a,b,c)
  %5049 = call float @dx.op.tertiary.f32(i32 46, float %5017, float %25, float %5048)  ; FMad(a,b,c)
  %5050 = fadd fast float %5049, %21
  %5051 = fdiv fast float %5050, %5035
  %5052 = fdiv fast float %5046, %5035
  %5053 = fdiv fast float %5042, %5035
  %5054 = fsub fast float %5051, %18
  %5055 = fsub fast float %5052, %19
  %5056 = fsub fast float %5053, %20
  %5057 = fmul fast float %5054, %5054
  %5058 = fmul fast float %5055, %5055
  %5059 = fadd fast float %5058, %5057
  %5060 = fmul fast float %5056, %5056
  %5061 = fadd fast float %5059, %5060
  %5062 = call float @dx.op.unary.f32(i32 24, float %5061)  ; Sqrt(value)
  %5063 = fsub fast float %5062, %10
  %5064 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5063)  ; FMax(a,b)
  %5065 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %5065, label %5066, label %5089

; <label>:5066                                    ; preds = %5038
  %5067 = call float @dx.op.unary.f32(i32 6, float %5055)  ; FAbs(value)
  %5068 = fmul fast float %5067, %12
  %5069 = fcmp fast olt float %5068, 0x3F50624DE0000000
  br i1 %5069, label %5070, label %5073

; <label>:5070                                    ; preds = %5066
  %5071 = fmul fast float %5068, 5.000000e-01
  %5072 = fsub fast float 1.000000e+00, %5071
  br label %5078

; <label>:5073                                    ; preds = %5066
  %5074 = fmul fast float %5068, 0xBFF7154760000000
  %5075 = call float @dx.op.unary.f32(i32 21, float %5074)  ; Exp(value)
  %5076 = fsub fast float 1.000000e+00, %5075
  %5077 = fdiv fast float %5076, %5068
  br label %5078

; <label>:5078                                    ; preds = %5073, %5070
  %5079 = phi float [ %5072, %5070 ], [ %5077, %5073 ]
  %5080 = call float @dx.op.binary.f32(i32 36, float %5052, float %19)  ; FMin(a,b)
  %5081 = fsub fast float %5080, %11
  %5082 = fmul fast float %12, %5081
  %5083 = fsub fast float -0.000000e+00, %5082
  %5084 = call float @dx.op.binary.f32(i32 35, float %5083, float -4.000000e+01)  ; FMax(a,b)
  %5085 = call float @dx.op.binary.f32(i32 36, float %5084, float 5.000000e+00)  ; FMin(a,b)
  %5086 = fmul fast float %5085, 0x3FF7154760000000
  %5087 = call float @dx.op.unary.f32(i32 21, float %5086)  ; Exp(value)
  %5088 = fmul fast float %5087, %5079
  br label %5089

; <label>:5089                                    ; preds = %5078, %5038
  %5090 = phi float [ %5088, %5078 ], [ 1.000000e+00, %5038 ]
  %5091 = fmul fast float %5064, %17
  %5092 = fmul fast float %5091, %5090
  %5093 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %5092)  ; FMin(a,b)
  %5094 = fmul fast float %5093, 0xBFF7154760000000
  %5095 = call float @dx.op.unary.f32(i32 21, float %5094)  ; Exp(value)
  %5096 = fsub fast float 1.000000e+00, %5095
  %5097 = call float @dx.op.binary.f32(i32 36, float %13, float %5096)  ; FMin(a,b)
  %5098 = fsub fast float %14, %4976
  %5099 = fsub fast float %15, %4977
  %5100 = fsub fast float %16, %4978
  %5101 = fmul fast float %5097, %5098
  %5102 = fmul fast float %5097, %5099
  %5103 = fmul fast float %5097, %5100
  %5104 = fadd fast float %5101, %4976
  %5105 = fadd fast float %5102, %4977
  %5106 = fadd fast float %5103, %4978
  br label %5107

; <label>:5107                                    ; preds = %5089, %5021, %5015
  %5108 = phi float [ %5104, %5089 ], [ %4976, %5021 ], [ %4976, %5015 ]
  %5109 = phi float [ %5105, %5089 ], [ %4977, %5021 ], [ %4977, %5015 ]
  %5110 = phi float [ %5106, %5089 ], [ %4978, %5021 ], [ %4978, %5015 ]
  %5111 = fadd fast float %6, 1.000000e+00
  %5112 = fadd fast float %7, 1.000000e+00
  %5113 = fsub fast float 1.000000e+00, %6
  %5114 = fmul fast float %37, %5111
  %5115 = fmul fast float %37, %5112
  %5116 = fmul fast float %37, %5113
  %5117 = fmul fast float %5114, %5108
  %5118 = fmul fast float %5115, %5109
  %5119 = fmul fast float %5116, %5110
  %5120 = fcmp fast ult float %38, 5.000000e-01
  br i1 %5120, label %5146, label %5121

; <label>:5121                                    ; preds = %5107
  %5122 = fmul fast float %5117, 0x4004147AE0000000
  %5123 = fmul fast float %5118, 0x4004147AE0000000
  %5124 = fmul fast float %5119, 0x4004147AE0000000
  %5125 = fadd fast float %5122, 0x3F9EB851E0000000
  %5126 = fadd fast float %5123, 0x3F9EB851E0000000
  %5127 = fadd fast float %5124, 0x3F9EB851E0000000
  %5128 = fmul fast float %5125, %5117
  %5129 = fmul fast float %5126, %5118
  %5130 = fmul fast float %5127, %5119
  %5131 = fmul fast float %5117, 0x400370A3E0000000
  %5132 = fmul fast float %5118, 0x400370A3E0000000
  %5133 = fmul fast float %5119, 0x400370A3E0000000
  %5134 = fadd fast float %5131, 0x3FE2E147A0000000
  %5135 = fadd fast float %5132, 0x3FE2E147A0000000
  %5136 = fadd fast float %5133, 0x3FE2E147A0000000
  %5137 = fmul fast float %5134, %5117
  %5138 = fmul fast float %5135, %5118
  %5139 = fmul fast float %5136, %5119
  %5140 = fadd fast float %5137, 0x3FC1EB8520000000
  %5141 = fadd fast float %5138, 0x3FC1EB8520000000
  %5142 = fadd fast float %5139, 0x3FC1EB8520000000
  %5143 = fdiv fast float %5128, %5140
  %5144 = fdiv fast float %5129, %5141
  %5145 = fdiv fast float %5130, %5142
  br label %5146

; <label>:5146                                    ; preds = %5121, %5107
  %5147 = phi float [ %5143, %5121 ], [ %5117, %5107 ]
  %5148 = phi float [ %5144, %5121 ], [ %5118, %5107 ]
  %5149 = phi float [ %5145, %5121 ], [ %5119, %5107 ]
  %5150 = call float @dx.op.unary.f32(i32 7, float %5147)  ; Saturate(value)
  %5151 = call float @dx.op.unary.f32(i32 7, float %5148)  ; Saturate(value)
  %5152 = call float @dx.op.unary.f32(i32 7, float %5149)  ; Saturate(value)
  %5153 = call float @dx.op.dot3.f32(i32 55, float %5150, float %5151, float %5152, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5154 = fsub fast float %5150, %5153
  %5155 = fsub fast float %5151, %5153
  %5156 = fsub fast float %5152, %5153
  %5157 = fmul fast float %5154, %9
  %5158 = fmul fast float %5155, %9
  %5159 = fmul fast float %5156, %9
  %5160 = fadd fast float %5157, %5153
  %5161 = fadd fast float %5158, %5153
  %5162 = fadd fast float %5159, %5153
  %5163 = call float @dx.op.unary.f32(i32 7, float %5160)  ; Saturate(value)
  %5164 = call float @dx.op.unary.f32(i32 7, float %5161)  ; Saturate(value)
  %5165 = call float @dx.op.unary.f32(i32 7, float %5162)  ; Saturate(value)
  %5166 = fadd fast float %5163, 0xBFC70A3D80000000
  %5167 = fadd fast float %5164, 0xBFC70A3D80000000
  %5168 = fadd fast float %5165, 0xBFC70A3D80000000
  %5169 = fmul fast float %5166, %8
  %5170 = fmul fast float %5167, %8
  %5171 = fmul fast float %5168, %8
  %5172 = fadd fast float %5169, 0x3FC70A3D80000000
  %5173 = fadd fast float %5170, 0x3FC70A3D80000000
  %5174 = fadd fast float %5171, 0x3FC70A3D80000000
  %5175 = call float @dx.op.unary.f32(i32 7, float %5172)  ; Saturate(value)
  %5176 = call float @dx.op.unary.f32(i32 7, float %5173)  ; Saturate(value)
  %5177 = call float @dx.op.unary.f32(i32 7, float %5174)  ; Saturate(value)
  br label %5178

; <label>:5178                                    ; preds = %5146, %4981
  %5179 = phi float [ %5012, %4981 ], [ %5175, %5146 ]
  %5180 = phi float [ %5013, %4981 ], [ %5176, %5146 ]
  %5181 = phi float [ %5014, %4981 ], [ %5177, %5146 ]
  %5182 = fsub fast float %5179, %4949
  %5183 = fsub fast float %5180, %4950
  %5184 = fsub fast float %5181, %4951
  %5185 = fmul fast float %5182, %4968
  %5186 = fmul fast float %5183, %4968
  %5187 = fmul fast float %5184, %4968
  %5188 = fadd fast float %5185, %4949
  %5189 = fadd fast float %5186, %4950
  %5190 = fadd fast float %5187, %4951
  br label %5191

; <label>:5191                                    ; preds = %5178, %4953
  %5192 = phi float [ %5188, %5178 ], [ %4949, %4953 ]
  %5193 = phi float [ %5189, %5178 ], [ %4950, %4953 ]
  %5194 = phi float [ %5190, %5178 ], [ %4951, %4953 ]
  %5195 = add i32 %65, 1
  %5196 = call i32 @dx.op.binary.i32(i32 37, i32 %5195, i32 0)  ; IMax(a,b)
  %5197 = call i32 @dx.op.binary.i32(i32 38, i32 %5196, i32 %61)  ; IMin(a,b)
  %5198 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4957, i32 %5197, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5199 = extractvalue %dx.types.ResRet.f32 %5198, 0
  %5200 = fsub fast float %5199, %85
  %5201 = call float @dx.op.unary.f32(i32 6, float %5200)  ; FAbs(value)
  %5202 = fdiv fast float %5201, %4963
  %5203 = fsub fast float 1.000000e+00, %5202
  %5204 = call float @dx.op.unary.f32(i32 7, float %5203)  ; Saturate(value)
  %5205 = fcmp fast ugt float %5204, 0.000000e+00
  br i1 %5205, label %5206, label %5427

; <label>:5206                                    ; preds = %5191
  %5207 = call i32 @dx.op.binary.i32(i32 37, i32 %4957, i32 0)  ; IMax(a,b)
  %5208 = call i32 @dx.op.binary.i32(i32 37, i32 %5197, i32 0)  ; IMax(a,b)
  %5209 = call i32 @dx.op.binary.i32(i32 38, i32 %5207, i32 %60)  ; IMin(a,b)
  %5210 = call i32 @dx.op.binary.i32(i32 38, i32 %5208, i32 %61)  ; IMin(a,b)
  %5211 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %5209, i32 %5210, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5212 = extractvalue %dx.types.ResRet.f32 %5211, 0
  %5213 = extractvalue %dx.types.ResRet.f32 %5211, 1
  %5214 = extractvalue %dx.types.ResRet.f32 %5211, 2
  %5215 = extractvalue %dx.types.ResRet.f32 %5211, 3
  %5216 = fcmp fast olt float %5215, 0.000000e+00
  br i1 %5216, label %5217, label %5251

; <label>:5217                                    ; preds = %5206
  %5218 = fcmp fast ogt float %5212, 0x3FA4B5DCC0000000
  %5219 = fcmp fast ogt float %5213, 0x3FA4B5DCC0000000
  %5220 = fcmp fast ogt float %5214, 0x3FA4B5DCC0000000
  %5221 = select i1 %5218, float 0.000000e+00, float 1.000000e+00
  %5222 = select i1 %5219, float 0.000000e+00, float 1.000000e+00
  %5223 = select i1 %5220, float 0.000000e+00, float 1.000000e+00
  %5224 = fmul fast float %5212, 0x3FB3D07220000000
  %5225 = fmul fast float %5213, 0x3FB3D07220000000
  %5226 = fmul fast float %5214, 0x3FB3D07220000000
  %5227 = fadd fast float %5212, 0x3FAC28F5C0000000
  %5228 = fadd fast float %5213, 0x3FAC28F5C0000000
  %5229 = fadd fast float %5214, 0x3FAC28F5C0000000
  %5230 = fmul fast float %5227, 0x3FEE54EDE0000000
  %5231 = fmul fast float %5228, 0x3FEE54EDE0000000
  %5232 = fmul fast float %5229, 0x3FEE54EDE0000000
  %5233 = call float @dx.op.unary.f32(i32 23, float %5230)  ; Log(value)
  %5234 = call float @dx.op.unary.f32(i32 23, float %5231)  ; Log(value)
  %5235 = call float @dx.op.unary.f32(i32 23, float %5232)  ; Log(value)
  %5236 = fmul fast float %5233, 0x4003333340000000
  %5237 = fmul fast float %5234, 0x4003333340000000
  %5238 = fmul fast float %5235, 0x4003333340000000
  %5239 = call float @dx.op.unary.f32(i32 21, float %5236)  ; Exp(value)
  %5240 = call float @dx.op.unary.f32(i32 21, float %5237)  ; Exp(value)
  %5241 = call float @dx.op.unary.f32(i32 21, float %5238)  ; Exp(value)
  %5242 = fsub fast float %5224, %5239
  %5243 = fsub fast float %5225, %5240
  %5244 = fsub fast float %5226, %5241
  %5245 = fmul fast float %5242, %5221
  %5246 = fmul fast float %5243, %5222
  %5247 = fmul fast float %5244, %5223
  %5248 = fadd fast float %5245, %5239
  %5249 = fadd fast float %5246, %5240
  %5250 = fadd fast float %5247, %5241
  br label %5414

; <label>:5251                                    ; preds = %5206
  %5252 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5209, i32 %5210, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5253 = extractvalue %dx.types.ResRet.f32 %5252, 0
  %5254 = fcmp fast ogt float %39, 5.000000e-01
  %5255 = fcmp fast olt float %5253, 1.000000e+00
  %5256 = and i1 %5254, %5255
  br i1 %5256, label %5257, label %5343

; <label>:5257                                    ; preds = %5251
  %5258 = sitofp i32 %5209 to float
  %5259 = sitofp i32 %5210 to float
  %5260 = fadd fast float %5258, 5.000000e-01
  %5261 = fadd fast float %5259, 5.000000e-01
  %5262 = fdiv fast float %5260, %46
  %5263 = fdiv fast float %5261, %47
  %5264 = fmul fast float %5262, 2.000000e+00
  %5265 = fmul fast float %5263, 2.000000e+00
  %5266 = fadd fast float %5264, -1.000000e+00
  %5267 = fsub fast float 1.000000e+00, %5265
  %5268 = fmul fast float %5266, %36
  %5269 = call float @dx.op.tertiary.f32(i32 46, float %5267, float %32, float %5268)  ; FMad(a,b,c)
  %5270 = call float @dx.op.tertiary.f32(i32 46, float %5253, float %28, float %5269)  ; FMad(a,b,c)
  %5271 = fadd fast float %5270, %24
  %5272 = call float @dx.op.unary.f32(i32 6, float %5271)  ; FAbs(value)
  %5273 = fcmp fast ogt float %5272, 0x3EB0C6F7A0000000
  br i1 %5273, label %5274, label %5343

; <label>:5274                                    ; preds = %5257
  %5275 = fmul fast float %5266, %35
  %5276 = call float @dx.op.tertiary.f32(i32 46, float %5267, float %31, float %5275)  ; FMad(a,b,c)
  %5277 = call float @dx.op.tertiary.f32(i32 46, float %5253, float %27, float %5276)  ; FMad(a,b,c)
  %5278 = fadd fast float %5277, %23
  %5279 = fmul fast float %5266, %34
  %5280 = call float @dx.op.tertiary.f32(i32 46, float %5267, float %30, float %5279)  ; FMad(a,b,c)
  %5281 = call float @dx.op.tertiary.f32(i32 46, float %5253, float %26, float %5280)  ; FMad(a,b,c)
  %5282 = fadd fast float %5281, %22
  %5283 = fmul fast float %5266, %33
  %5284 = call float @dx.op.tertiary.f32(i32 46, float %5267, float %29, float %5283)  ; FMad(a,b,c)
  %5285 = call float @dx.op.tertiary.f32(i32 46, float %5253, float %25, float %5284)  ; FMad(a,b,c)
  %5286 = fadd fast float %5285, %21
  %5287 = fdiv fast float %5286, %5271
  %5288 = fdiv fast float %5282, %5271
  %5289 = fdiv fast float %5278, %5271
  %5290 = fsub fast float %5287, %18
  %5291 = fsub fast float %5288, %19
  %5292 = fsub fast float %5289, %20
  %5293 = fmul fast float %5290, %5290
  %5294 = fmul fast float %5291, %5291
  %5295 = fadd fast float %5294, %5293
  %5296 = fmul fast float %5292, %5292
  %5297 = fadd fast float %5295, %5296
  %5298 = call float @dx.op.unary.f32(i32 24, float %5297)  ; Sqrt(value)
  %5299 = fsub fast float %5298, %10
  %5300 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5299)  ; FMax(a,b)
  %5301 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %5301, label %5302, label %5325

; <label>:5302                                    ; preds = %5274
  %5303 = call float @dx.op.unary.f32(i32 6, float %5291)  ; FAbs(value)
  %5304 = fmul fast float %5303, %12
  %5305 = fcmp fast olt float %5304, 0x3F50624DE0000000
  br i1 %5305, label %5306, label %5309

; <label>:5306                                    ; preds = %5302
  %5307 = fmul fast float %5304, 5.000000e-01
  %5308 = fsub fast float 1.000000e+00, %5307
  br label %5314

; <label>:5309                                    ; preds = %5302
  %5310 = fmul fast float %5304, 0xBFF7154760000000
  %5311 = call float @dx.op.unary.f32(i32 21, float %5310)  ; Exp(value)
  %5312 = fsub fast float 1.000000e+00, %5311
  %5313 = fdiv fast float %5312, %5304
  br label %5314

; <label>:5314                                    ; preds = %5309, %5306
  %5315 = phi float [ %5308, %5306 ], [ %5313, %5309 ]
  %5316 = call float @dx.op.binary.f32(i32 36, float %5288, float %19)  ; FMin(a,b)
  %5317 = fsub fast float %5316, %11
  %5318 = fmul fast float %12, %5317
  %5319 = fsub fast float -0.000000e+00, %5318
  %5320 = call float @dx.op.binary.f32(i32 35, float %5319, float -4.000000e+01)  ; FMax(a,b)
  %5321 = call float @dx.op.binary.f32(i32 36, float %5320, float 5.000000e+00)  ; FMin(a,b)
  %5322 = fmul fast float %5321, 0x3FF7154760000000
  %5323 = call float @dx.op.unary.f32(i32 21, float %5322)  ; Exp(value)
  %5324 = fmul fast float %5323, %5315
  br label %5325

; <label>:5325                                    ; preds = %5314, %5274
  %5326 = phi float [ %5324, %5314 ], [ 1.000000e+00, %5274 ]
  %5327 = fmul fast float %5300, %17
  %5328 = fmul fast float %5327, %5326
  %5329 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %5328)  ; FMin(a,b)
  %5330 = fmul fast float %5329, 0xBFF7154760000000
  %5331 = call float @dx.op.unary.f32(i32 21, float %5330)  ; Exp(value)
  %5332 = fsub fast float 1.000000e+00, %5331
  %5333 = call float @dx.op.binary.f32(i32 36, float %13, float %5332)  ; FMin(a,b)
  %5334 = fsub fast float %14, %5212
  %5335 = fsub fast float %15, %5213
  %5336 = fsub fast float %16, %5214
  %5337 = fmul fast float %5333, %5334
  %5338 = fmul fast float %5333, %5335
  %5339 = fmul fast float %5333, %5336
  %5340 = fadd fast float %5337, %5212
  %5341 = fadd fast float %5338, %5213
  %5342 = fadd fast float %5339, %5214
  br label %5343

; <label>:5343                                    ; preds = %5325, %5257, %5251
  %5344 = phi float [ %5340, %5325 ], [ %5212, %5257 ], [ %5212, %5251 ]
  %5345 = phi float [ %5341, %5325 ], [ %5213, %5257 ], [ %5213, %5251 ]
  %5346 = phi float [ %5342, %5325 ], [ %5214, %5257 ], [ %5214, %5251 ]
  %5347 = fadd fast float %6, 1.000000e+00
  %5348 = fadd fast float %7, 1.000000e+00
  %5349 = fsub fast float 1.000000e+00, %6
  %5350 = fmul fast float %37, %5347
  %5351 = fmul fast float %37, %5348
  %5352 = fmul fast float %37, %5349
  %5353 = fmul fast float %5350, %5344
  %5354 = fmul fast float %5351, %5345
  %5355 = fmul fast float %5352, %5346
  %5356 = fcmp fast ult float %38, 5.000000e-01
  br i1 %5356, label %5382, label %5357

; <label>:5357                                    ; preds = %5343
  %5358 = fmul fast float %5353, 0x4004147AE0000000
  %5359 = fmul fast float %5354, 0x4004147AE0000000
  %5360 = fmul fast float %5355, 0x4004147AE0000000
  %5361 = fadd fast float %5358, 0x3F9EB851E0000000
  %5362 = fadd fast float %5359, 0x3F9EB851E0000000
  %5363 = fadd fast float %5360, 0x3F9EB851E0000000
  %5364 = fmul fast float %5361, %5353
  %5365 = fmul fast float %5362, %5354
  %5366 = fmul fast float %5363, %5355
  %5367 = fmul fast float %5353, 0x400370A3E0000000
  %5368 = fmul fast float %5354, 0x400370A3E0000000
  %5369 = fmul fast float %5355, 0x400370A3E0000000
  %5370 = fadd fast float %5367, 0x3FE2E147A0000000
  %5371 = fadd fast float %5368, 0x3FE2E147A0000000
  %5372 = fadd fast float %5369, 0x3FE2E147A0000000
  %5373 = fmul fast float %5370, %5353
  %5374 = fmul fast float %5371, %5354
  %5375 = fmul fast float %5372, %5355
  %5376 = fadd fast float %5373, 0x3FC1EB8520000000
  %5377 = fadd fast float %5374, 0x3FC1EB8520000000
  %5378 = fadd fast float %5375, 0x3FC1EB8520000000
  %5379 = fdiv fast float %5364, %5376
  %5380 = fdiv fast float %5365, %5377
  %5381 = fdiv fast float %5366, %5378
  br label %5382

; <label>:5382                                    ; preds = %5357, %5343
  %5383 = phi float [ %5379, %5357 ], [ %5353, %5343 ]
  %5384 = phi float [ %5380, %5357 ], [ %5354, %5343 ]
  %5385 = phi float [ %5381, %5357 ], [ %5355, %5343 ]
  %5386 = call float @dx.op.unary.f32(i32 7, float %5383)  ; Saturate(value)
  %5387 = call float @dx.op.unary.f32(i32 7, float %5384)  ; Saturate(value)
  %5388 = call float @dx.op.unary.f32(i32 7, float %5385)  ; Saturate(value)
  %5389 = call float @dx.op.dot3.f32(i32 55, float %5386, float %5387, float %5388, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5390 = fsub fast float %5386, %5389
  %5391 = fsub fast float %5387, %5389
  %5392 = fsub fast float %5388, %5389
  %5393 = fmul fast float %5390, %9
  %5394 = fmul fast float %5391, %9
  %5395 = fmul fast float %5392, %9
  %5396 = fadd fast float %5393, %5389
  %5397 = fadd fast float %5394, %5389
  %5398 = fadd fast float %5395, %5389
  %5399 = call float @dx.op.unary.f32(i32 7, float %5396)  ; Saturate(value)
  %5400 = call float @dx.op.unary.f32(i32 7, float %5397)  ; Saturate(value)
  %5401 = call float @dx.op.unary.f32(i32 7, float %5398)  ; Saturate(value)
  %5402 = fadd fast float %5399, 0xBFC70A3D80000000
  %5403 = fadd fast float %5400, 0xBFC70A3D80000000
  %5404 = fadd fast float %5401, 0xBFC70A3D80000000
  %5405 = fmul fast float %5402, %8
  %5406 = fmul fast float %5403, %8
  %5407 = fmul fast float %5404, %8
  %5408 = fadd fast float %5405, 0x3FC70A3D80000000
  %5409 = fadd fast float %5406, 0x3FC70A3D80000000
  %5410 = fadd fast float %5407, 0x3FC70A3D80000000
  %5411 = call float @dx.op.unary.f32(i32 7, float %5408)  ; Saturate(value)
  %5412 = call float @dx.op.unary.f32(i32 7, float %5409)  ; Saturate(value)
  %5413 = call float @dx.op.unary.f32(i32 7, float %5410)  ; Saturate(value)
  br label %5414

; <label>:5414                                    ; preds = %5382, %5217
  %5415 = phi float [ %5248, %5217 ], [ %5411, %5382 ]
  %5416 = phi float [ %5249, %5217 ], [ %5412, %5382 ]
  %5417 = phi float [ %5250, %5217 ], [ %5413, %5382 ]
  %5418 = fsub fast float %5415, %4949
  %5419 = fsub fast float %5416, %4950
  %5420 = fsub fast float %5417, %4951
  %5421 = fmul fast float %5418, %5204
  %5422 = fmul fast float %5419, %5204
  %5423 = fmul fast float %5420, %5204
  %5424 = fadd fast float %5421, %4949
  %5425 = fadd fast float %5422, %4950
  %5426 = fadd fast float %5423, %4951
  br label %5427

; <label>:5427                                    ; preds = %5414, %5191
  %5428 = phi float [ %5424, %5414 ], [ %4949, %5191 ]
  %5429 = phi float [ %5425, %5414 ], [ %4950, %5191 ]
  %5430 = phi float [ %5426, %5414 ], [ %4951, %5191 ]
  %5431 = add i32 %68, -1
  %5432 = call i32 @dx.op.binary.i32(i32 37, i32 %5431, i32 0)  ; IMax(a,b)
  %5433 = call i32 @dx.op.binary.i32(i32 37, i32 %65, i32 0)  ; IMax(a,b)
  %5434 = call i32 @dx.op.binary.i32(i32 38, i32 %5432, i32 %60)  ; IMin(a,b)
  %5435 = call i32 @dx.op.binary.i32(i32 38, i32 %5433, i32 %61)  ; IMin(a,b)
  %5436 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5434, i32 %5435, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5437 = extractvalue %dx.types.ResRet.f32 %5436, 0
  %5438 = fsub fast float %5437, %85
  %5439 = call float @dx.op.unary.f32(i32 6, float %5438)  ; FAbs(value)
  %5440 = fdiv fast float %5439, %4963
  %5441 = fsub fast float 1.000000e+00, %5440
  %5442 = call float @dx.op.unary.f32(i32 7, float %5441)  ; Saturate(value)
  %5443 = fcmp fast ugt float %5442, 0.000000e+00
  br i1 %5443, label %5444, label %5665

; <label>:5444                                    ; preds = %5427
  %5445 = call i32 @dx.op.binary.i32(i32 37, i32 %5434, i32 0)  ; IMax(a,b)
  %5446 = call i32 @dx.op.binary.i32(i32 37, i32 %5435, i32 0)  ; IMax(a,b)
  %5447 = call i32 @dx.op.binary.i32(i32 38, i32 %5445, i32 %60)  ; IMin(a,b)
  %5448 = call i32 @dx.op.binary.i32(i32 38, i32 %5446, i32 %61)  ; IMin(a,b)
  %5449 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %5447, i32 %5448, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5450 = extractvalue %dx.types.ResRet.f32 %5449, 0
  %5451 = extractvalue %dx.types.ResRet.f32 %5449, 1
  %5452 = extractvalue %dx.types.ResRet.f32 %5449, 2
  %5453 = extractvalue %dx.types.ResRet.f32 %5449, 3
  %5454 = fcmp fast olt float %5453, 0.000000e+00
  br i1 %5454, label %5455, label %5489

; <label>:5455                                    ; preds = %5444
  %5456 = fcmp fast ogt float %5450, 0x3FA4B5DCC0000000
  %5457 = fcmp fast ogt float %5451, 0x3FA4B5DCC0000000
  %5458 = fcmp fast ogt float %5452, 0x3FA4B5DCC0000000
  %5459 = select i1 %5456, float 0.000000e+00, float 1.000000e+00
  %5460 = select i1 %5457, float 0.000000e+00, float 1.000000e+00
  %5461 = select i1 %5458, float 0.000000e+00, float 1.000000e+00
  %5462 = fmul fast float %5450, 0x3FB3D07220000000
  %5463 = fmul fast float %5451, 0x3FB3D07220000000
  %5464 = fmul fast float %5452, 0x3FB3D07220000000
  %5465 = fadd fast float %5450, 0x3FAC28F5C0000000
  %5466 = fadd fast float %5451, 0x3FAC28F5C0000000
  %5467 = fadd fast float %5452, 0x3FAC28F5C0000000
  %5468 = fmul fast float %5465, 0x3FEE54EDE0000000
  %5469 = fmul fast float %5466, 0x3FEE54EDE0000000
  %5470 = fmul fast float %5467, 0x3FEE54EDE0000000
  %5471 = call float @dx.op.unary.f32(i32 23, float %5468)  ; Log(value)
  %5472 = call float @dx.op.unary.f32(i32 23, float %5469)  ; Log(value)
  %5473 = call float @dx.op.unary.f32(i32 23, float %5470)  ; Log(value)
  %5474 = fmul fast float %5471, 0x4003333340000000
  %5475 = fmul fast float %5472, 0x4003333340000000
  %5476 = fmul fast float %5473, 0x4003333340000000
  %5477 = call float @dx.op.unary.f32(i32 21, float %5474)  ; Exp(value)
  %5478 = call float @dx.op.unary.f32(i32 21, float %5475)  ; Exp(value)
  %5479 = call float @dx.op.unary.f32(i32 21, float %5476)  ; Exp(value)
  %5480 = fsub fast float %5462, %5477
  %5481 = fsub fast float %5463, %5478
  %5482 = fsub fast float %5464, %5479
  %5483 = fmul fast float %5480, %5459
  %5484 = fmul fast float %5481, %5460
  %5485 = fmul fast float %5482, %5461
  %5486 = fadd fast float %5483, %5477
  %5487 = fadd fast float %5484, %5478
  %5488 = fadd fast float %5485, %5479
  br label %5652

; <label>:5489                                    ; preds = %5444
  %5490 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5447, i32 %5448, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5491 = extractvalue %dx.types.ResRet.f32 %5490, 0
  %5492 = fcmp fast ogt float %39, 5.000000e-01
  %5493 = fcmp fast olt float %5491, 1.000000e+00
  %5494 = and i1 %5492, %5493
  br i1 %5494, label %5495, label %5581

; <label>:5495                                    ; preds = %5489
  %5496 = sitofp i32 %5447 to float
  %5497 = sitofp i32 %5448 to float
  %5498 = fadd fast float %5496, 5.000000e-01
  %5499 = fadd fast float %5497, 5.000000e-01
  %5500 = fdiv fast float %5498, %46
  %5501 = fdiv fast float %5499, %47
  %5502 = fmul fast float %5500, 2.000000e+00
  %5503 = fmul fast float %5501, 2.000000e+00
  %5504 = fadd fast float %5502, -1.000000e+00
  %5505 = fsub fast float 1.000000e+00, %5503
  %5506 = fmul fast float %5504, %36
  %5507 = call float @dx.op.tertiary.f32(i32 46, float %5505, float %32, float %5506)  ; FMad(a,b,c)
  %5508 = call float @dx.op.tertiary.f32(i32 46, float %5491, float %28, float %5507)  ; FMad(a,b,c)
  %5509 = fadd fast float %5508, %24
  %5510 = call float @dx.op.unary.f32(i32 6, float %5509)  ; FAbs(value)
  %5511 = fcmp fast ogt float %5510, 0x3EB0C6F7A0000000
  br i1 %5511, label %5512, label %5581

; <label>:5512                                    ; preds = %5495
  %5513 = fmul fast float %5504, %35
  %5514 = call float @dx.op.tertiary.f32(i32 46, float %5505, float %31, float %5513)  ; FMad(a,b,c)
  %5515 = call float @dx.op.tertiary.f32(i32 46, float %5491, float %27, float %5514)  ; FMad(a,b,c)
  %5516 = fadd fast float %5515, %23
  %5517 = fmul fast float %5504, %34
  %5518 = call float @dx.op.tertiary.f32(i32 46, float %5505, float %30, float %5517)  ; FMad(a,b,c)
  %5519 = call float @dx.op.tertiary.f32(i32 46, float %5491, float %26, float %5518)  ; FMad(a,b,c)
  %5520 = fadd fast float %5519, %22
  %5521 = fmul fast float %5504, %33
  %5522 = call float @dx.op.tertiary.f32(i32 46, float %5505, float %29, float %5521)  ; FMad(a,b,c)
  %5523 = call float @dx.op.tertiary.f32(i32 46, float %5491, float %25, float %5522)  ; FMad(a,b,c)
  %5524 = fadd fast float %5523, %21
  %5525 = fdiv fast float %5524, %5509
  %5526 = fdiv fast float %5520, %5509
  %5527 = fdiv fast float %5516, %5509
  %5528 = fsub fast float %5525, %18
  %5529 = fsub fast float %5526, %19
  %5530 = fsub fast float %5527, %20
  %5531 = fmul fast float %5528, %5528
  %5532 = fmul fast float %5529, %5529
  %5533 = fadd fast float %5532, %5531
  %5534 = fmul fast float %5530, %5530
  %5535 = fadd fast float %5533, %5534
  %5536 = call float @dx.op.unary.f32(i32 24, float %5535)  ; Sqrt(value)
  %5537 = fsub fast float %5536, %10
  %5538 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5537)  ; FMax(a,b)
  %5539 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %5539, label %5540, label %5563

; <label>:5540                                    ; preds = %5512
  %5541 = call float @dx.op.unary.f32(i32 6, float %5529)  ; FAbs(value)
  %5542 = fmul fast float %5541, %12
  %5543 = fcmp fast olt float %5542, 0x3F50624DE0000000
  br i1 %5543, label %5544, label %5547

; <label>:5544                                    ; preds = %5540
  %5545 = fmul fast float %5542, 5.000000e-01
  %5546 = fsub fast float 1.000000e+00, %5545
  br label %5552

; <label>:5547                                    ; preds = %5540
  %5548 = fmul fast float %5542, 0xBFF7154760000000
  %5549 = call float @dx.op.unary.f32(i32 21, float %5548)  ; Exp(value)
  %5550 = fsub fast float 1.000000e+00, %5549
  %5551 = fdiv fast float %5550, %5542
  br label %5552

; <label>:5552                                    ; preds = %5547, %5544
  %5553 = phi float [ %5546, %5544 ], [ %5551, %5547 ]
  %5554 = call float @dx.op.binary.f32(i32 36, float %5526, float %19)  ; FMin(a,b)
  %5555 = fsub fast float %5554, %11
  %5556 = fmul fast float %12, %5555
  %5557 = fsub fast float -0.000000e+00, %5556
  %5558 = call float @dx.op.binary.f32(i32 35, float %5557, float -4.000000e+01)  ; FMax(a,b)
  %5559 = call float @dx.op.binary.f32(i32 36, float %5558, float 5.000000e+00)  ; FMin(a,b)
  %5560 = fmul fast float %5559, 0x3FF7154760000000
  %5561 = call float @dx.op.unary.f32(i32 21, float %5560)  ; Exp(value)
  %5562 = fmul fast float %5561, %5553
  br label %5563

; <label>:5563                                    ; preds = %5552, %5512
  %5564 = phi float [ %5562, %5552 ], [ 1.000000e+00, %5512 ]
  %5565 = fmul fast float %5538, %17
  %5566 = fmul fast float %5565, %5564
  %5567 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %5566)  ; FMin(a,b)
  %5568 = fmul fast float %5567, 0xBFF7154760000000
  %5569 = call float @dx.op.unary.f32(i32 21, float %5568)  ; Exp(value)
  %5570 = fsub fast float 1.000000e+00, %5569
  %5571 = call float @dx.op.binary.f32(i32 36, float %13, float %5570)  ; FMin(a,b)
  %5572 = fsub fast float %14, %5450
  %5573 = fsub fast float %15, %5451
  %5574 = fsub fast float %16, %5452
  %5575 = fmul fast float %5571, %5572
  %5576 = fmul fast float %5571, %5573
  %5577 = fmul fast float %5571, %5574
  %5578 = fadd fast float %5575, %5450
  %5579 = fadd fast float %5576, %5451
  %5580 = fadd fast float %5577, %5452
  br label %5581

; <label>:5581                                    ; preds = %5563, %5495, %5489
  %5582 = phi float [ %5578, %5563 ], [ %5450, %5495 ], [ %5450, %5489 ]
  %5583 = phi float [ %5579, %5563 ], [ %5451, %5495 ], [ %5451, %5489 ]
  %5584 = phi float [ %5580, %5563 ], [ %5452, %5495 ], [ %5452, %5489 ]
  %5585 = fadd fast float %6, 1.000000e+00
  %5586 = fadd fast float %7, 1.000000e+00
  %5587 = fsub fast float 1.000000e+00, %6
  %5588 = fmul fast float %37, %5585
  %5589 = fmul fast float %37, %5586
  %5590 = fmul fast float %37, %5587
  %5591 = fmul fast float %5588, %5582
  %5592 = fmul fast float %5589, %5583
  %5593 = fmul fast float %5590, %5584
  %5594 = fcmp fast ult float %38, 5.000000e-01
  br i1 %5594, label %5620, label %5595

; <label>:5595                                    ; preds = %5581
  %5596 = fmul fast float %5591, 0x4004147AE0000000
  %5597 = fmul fast float %5592, 0x4004147AE0000000
  %5598 = fmul fast float %5593, 0x4004147AE0000000
  %5599 = fadd fast float %5596, 0x3F9EB851E0000000
  %5600 = fadd fast float %5597, 0x3F9EB851E0000000
  %5601 = fadd fast float %5598, 0x3F9EB851E0000000
  %5602 = fmul fast float %5599, %5591
  %5603 = fmul fast float %5600, %5592
  %5604 = fmul fast float %5601, %5593
  %5605 = fmul fast float %5591, 0x400370A3E0000000
  %5606 = fmul fast float %5592, 0x400370A3E0000000
  %5607 = fmul fast float %5593, 0x400370A3E0000000
  %5608 = fadd fast float %5605, 0x3FE2E147A0000000
  %5609 = fadd fast float %5606, 0x3FE2E147A0000000
  %5610 = fadd fast float %5607, 0x3FE2E147A0000000
  %5611 = fmul fast float %5608, %5591
  %5612 = fmul fast float %5609, %5592
  %5613 = fmul fast float %5610, %5593
  %5614 = fadd fast float %5611, 0x3FC1EB8520000000
  %5615 = fadd fast float %5612, 0x3FC1EB8520000000
  %5616 = fadd fast float %5613, 0x3FC1EB8520000000
  %5617 = fdiv fast float %5602, %5614
  %5618 = fdiv fast float %5603, %5615
  %5619 = fdiv fast float %5604, %5616
  br label %5620

; <label>:5620                                    ; preds = %5595, %5581
  %5621 = phi float [ %5617, %5595 ], [ %5591, %5581 ]
  %5622 = phi float [ %5618, %5595 ], [ %5592, %5581 ]
  %5623 = phi float [ %5619, %5595 ], [ %5593, %5581 ]
  %5624 = call float @dx.op.unary.f32(i32 7, float %5621)  ; Saturate(value)
  %5625 = call float @dx.op.unary.f32(i32 7, float %5622)  ; Saturate(value)
  %5626 = call float @dx.op.unary.f32(i32 7, float %5623)  ; Saturate(value)
  %5627 = call float @dx.op.dot3.f32(i32 55, float %5624, float %5625, float %5626, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5628 = fsub fast float %5624, %5627
  %5629 = fsub fast float %5625, %5627
  %5630 = fsub fast float %5626, %5627
  %5631 = fmul fast float %5628, %9
  %5632 = fmul fast float %5629, %9
  %5633 = fmul fast float %5630, %9
  %5634 = fadd fast float %5631, %5627
  %5635 = fadd fast float %5632, %5627
  %5636 = fadd fast float %5633, %5627
  %5637 = call float @dx.op.unary.f32(i32 7, float %5634)  ; Saturate(value)
  %5638 = call float @dx.op.unary.f32(i32 7, float %5635)  ; Saturate(value)
  %5639 = call float @dx.op.unary.f32(i32 7, float %5636)  ; Saturate(value)
  %5640 = fadd fast float %5637, 0xBFC70A3D80000000
  %5641 = fadd fast float %5638, 0xBFC70A3D80000000
  %5642 = fadd fast float %5639, 0xBFC70A3D80000000
  %5643 = fmul fast float %5640, %8
  %5644 = fmul fast float %5641, %8
  %5645 = fmul fast float %5642, %8
  %5646 = fadd fast float %5643, 0x3FC70A3D80000000
  %5647 = fadd fast float %5644, 0x3FC70A3D80000000
  %5648 = fadd fast float %5645, 0x3FC70A3D80000000
  %5649 = call float @dx.op.unary.f32(i32 7, float %5646)  ; Saturate(value)
  %5650 = call float @dx.op.unary.f32(i32 7, float %5647)  ; Saturate(value)
  %5651 = call float @dx.op.unary.f32(i32 7, float %5648)  ; Saturate(value)
  br label %5652

; <label>:5652                                    ; preds = %5620, %5455
  %5653 = phi float [ %5486, %5455 ], [ %5649, %5620 ]
  %5654 = phi float [ %5487, %5455 ], [ %5650, %5620 ]
  %5655 = phi float [ %5488, %5455 ], [ %5651, %5620 ]
  %5656 = fsub fast float %5653, %4949
  %5657 = fsub fast float %5654, %4950
  %5658 = fsub fast float %5655, %4951
  %5659 = fmul fast float %5656, %5442
  %5660 = fmul fast float %5657, %5442
  %5661 = fmul fast float %5658, %5442
  %5662 = fadd fast float %5659, %4949
  %5663 = fadd fast float %5660, %4950
  %5664 = fadd fast float %5661, %4951
  br label %5665

; <label>:5665                                    ; preds = %5652, %5427
  %5666 = phi float [ %5662, %5652 ], [ %4949, %5427 ]
  %5667 = phi float [ %5663, %5652 ], [ %4950, %5427 ]
  %5668 = phi float [ %5664, %5652 ], [ %4951, %5427 ]
  %5669 = add i32 %68, 1
  %5670 = call i32 @dx.op.binary.i32(i32 37, i32 %5669, i32 0)  ; IMax(a,b)
  %5671 = call i32 @dx.op.binary.i32(i32 38, i32 %5670, i32 %60)  ; IMin(a,b)
  %5672 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5671, i32 %5435, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5673 = extractvalue %dx.types.ResRet.f32 %5672, 0
  %5674 = fsub fast float %5673, %85
  %5675 = call float @dx.op.unary.f32(i32 6, float %5674)  ; FAbs(value)
  %5676 = fdiv fast float %5675, %4963
  %5677 = fsub fast float 1.000000e+00, %5676
  %5678 = call float @dx.op.unary.f32(i32 7, float %5677)  ; Saturate(value)
  %5679 = fcmp fast ugt float %5678, 0.000000e+00
  br i1 %5679, label %5680, label %5901

; <label>:5680                                    ; preds = %5665
  %5681 = call i32 @dx.op.binary.i32(i32 37, i32 %5671, i32 0)  ; IMax(a,b)
  %5682 = call i32 @dx.op.binary.i32(i32 37, i32 %5435, i32 0)  ; IMax(a,b)
  %5683 = call i32 @dx.op.binary.i32(i32 38, i32 %5681, i32 %60)  ; IMin(a,b)
  %5684 = call i32 @dx.op.binary.i32(i32 38, i32 %5682, i32 %61)  ; IMin(a,b)
  %5685 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %5683, i32 %5684, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5686 = extractvalue %dx.types.ResRet.f32 %5685, 0
  %5687 = extractvalue %dx.types.ResRet.f32 %5685, 1
  %5688 = extractvalue %dx.types.ResRet.f32 %5685, 2
  %5689 = extractvalue %dx.types.ResRet.f32 %5685, 3
  %5690 = fcmp fast olt float %5689, 0.000000e+00
  br i1 %5690, label %5691, label %5725

; <label>:5691                                    ; preds = %5680
  %5692 = fcmp fast ogt float %5686, 0x3FA4B5DCC0000000
  %5693 = fcmp fast ogt float %5687, 0x3FA4B5DCC0000000
  %5694 = fcmp fast ogt float %5688, 0x3FA4B5DCC0000000
  %5695 = select i1 %5692, float 0.000000e+00, float 1.000000e+00
  %5696 = select i1 %5693, float 0.000000e+00, float 1.000000e+00
  %5697 = select i1 %5694, float 0.000000e+00, float 1.000000e+00
  %5698 = fmul fast float %5686, 0x3FB3D07220000000
  %5699 = fmul fast float %5687, 0x3FB3D07220000000
  %5700 = fmul fast float %5688, 0x3FB3D07220000000
  %5701 = fadd fast float %5686, 0x3FAC28F5C0000000
  %5702 = fadd fast float %5687, 0x3FAC28F5C0000000
  %5703 = fadd fast float %5688, 0x3FAC28F5C0000000
  %5704 = fmul fast float %5701, 0x3FEE54EDE0000000
  %5705 = fmul fast float %5702, 0x3FEE54EDE0000000
  %5706 = fmul fast float %5703, 0x3FEE54EDE0000000
  %5707 = call float @dx.op.unary.f32(i32 23, float %5704)  ; Log(value)
  %5708 = call float @dx.op.unary.f32(i32 23, float %5705)  ; Log(value)
  %5709 = call float @dx.op.unary.f32(i32 23, float %5706)  ; Log(value)
  %5710 = fmul fast float %5707, 0x4003333340000000
  %5711 = fmul fast float %5708, 0x4003333340000000
  %5712 = fmul fast float %5709, 0x4003333340000000
  %5713 = call float @dx.op.unary.f32(i32 21, float %5710)  ; Exp(value)
  %5714 = call float @dx.op.unary.f32(i32 21, float %5711)  ; Exp(value)
  %5715 = call float @dx.op.unary.f32(i32 21, float %5712)  ; Exp(value)
  %5716 = fsub fast float %5698, %5713
  %5717 = fsub fast float %5699, %5714
  %5718 = fsub fast float %5700, %5715
  %5719 = fmul fast float %5716, %5695
  %5720 = fmul fast float %5717, %5696
  %5721 = fmul fast float %5718, %5697
  %5722 = fadd fast float %5719, %5713
  %5723 = fadd fast float %5720, %5714
  %5724 = fadd fast float %5721, %5715
  br label %5888

; <label>:5725                                    ; preds = %5680
  %5726 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5683, i32 %5684, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5727 = extractvalue %dx.types.ResRet.f32 %5726, 0
  %5728 = fcmp fast ogt float %39, 5.000000e-01
  %5729 = fcmp fast olt float %5727, 1.000000e+00
  %5730 = and i1 %5728, %5729
  br i1 %5730, label %5731, label %5817

; <label>:5731                                    ; preds = %5725
  %5732 = sitofp i32 %5683 to float
  %5733 = sitofp i32 %5684 to float
  %5734 = fadd fast float %5732, 5.000000e-01
  %5735 = fadd fast float %5733, 5.000000e-01
  %5736 = fdiv fast float %5734, %46
  %5737 = fdiv fast float %5735, %47
  %5738 = fmul fast float %5736, 2.000000e+00
  %5739 = fmul fast float %5737, 2.000000e+00
  %5740 = fadd fast float %5738, -1.000000e+00
  %5741 = fsub fast float 1.000000e+00, %5739
  %5742 = fmul fast float %5740, %36
  %5743 = call float @dx.op.tertiary.f32(i32 46, float %5741, float %32, float %5742)  ; FMad(a,b,c)
  %5744 = call float @dx.op.tertiary.f32(i32 46, float %5727, float %28, float %5743)  ; FMad(a,b,c)
  %5745 = fadd fast float %5744, %24
  %5746 = call float @dx.op.unary.f32(i32 6, float %5745)  ; FAbs(value)
  %5747 = fcmp fast ogt float %5746, 0x3EB0C6F7A0000000
  br i1 %5747, label %5748, label %5817

; <label>:5748                                    ; preds = %5731
  %5749 = fmul fast float %5740, %35
  %5750 = call float @dx.op.tertiary.f32(i32 46, float %5741, float %31, float %5749)  ; FMad(a,b,c)
  %5751 = call float @dx.op.tertiary.f32(i32 46, float %5727, float %27, float %5750)  ; FMad(a,b,c)
  %5752 = fadd fast float %5751, %23
  %5753 = fmul fast float %5740, %34
  %5754 = call float @dx.op.tertiary.f32(i32 46, float %5741, float %30, float %5753)  ; FMad(a,b,c)
  %5755 = call float @dx.op.tertiary.f32(i32 46, float %5727, float %26, float %5754)  ; FMad(a,b,c)
  %5756 = fadd fast float %5755, %22
  %5757 = fmul fast float %5740, %33
  %5758 = call float @dx.op.tertiary.f32(i32 46, float %5741, float %29, float %5757)  ; FMad(a,b,c)
  %5759 = call float @dx.op.tertiary.f32(i32 46, float %5727, float %25, float %5758)  ; FMad(a,b,c)
  %5760 = fadd fast float %5759, %21
  %5761 = fdiv fast float %5760, %5745
  %5762 = fdiv fast float %5756, %5745
  %5763 = fdiv fast float %5752, %5745
  %5764 = fsub fast float %5761, %18
  %5765 = fsub fast float %5762, %19
  %5766 = fsub fast float %5763, %20
  %5767 = fmul fast float %5764, %5764
  %5768 = fmul fast float %5765, %5765
  %5769 = fadd fast float %5768, %5767
  %5770 = fmul fast float %5766, %5766
  %5771 = fadd fast float %5769, %5770
  %5772 = call float @dx.op.unary.f32(i32 24, float %5771)  ; Sqrt(value)
  %5773 = fsub fast float %5772, %10
  %5774 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5773)  ; FMax(a,b)
  %5775 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %5775, label %5776, label %5799

; <label>:5776                                    ; preds = %5748
  %5777 = call float @dx.op.unary.f32(i32 6, float %5765)  ; FAbs(value)
  %5778 = fmul fast float %5777, %12
  %5779 = fcmp fast olt float %5778, 0x3F50624DE0000000
  br i1 %5779, label %5780, label %5783

; <label>:5780                                    ; preds = %5776
  %5781 = fmul fast float %5778, 5.000000e-01
  %5782 = fsub fast float 1.000000e+00, %5781
  br label %5788

; <label>:5783                                    ; preds = %5776
  %5784 = fmul fast float %5778, 0xBFF7154760000000
  %5785 = call float @dx.op.unary.f32(i32 21, float %5784)  ; Exp(value)
  %5786 = fsub fast float 1.000000e+00, %5785
  %5787 = fdiv fast float %5786, %5778
  br label %5788

; <label>:5788                                    ; preds = %5783, %5780
  %5789 = phi float [ %5782, %5780 ], [ %5787, %5783 ]
  %5790 = call float @dx.op.binary.f32(i32 36, float %5762, float %19)  ; FMin(a,b)
  %5791 = fsub fast float %5790, %11
  %5792 = fmul fast float %12, %5791
  %5793 = fsub fast float -0.000000e+00, %5792
  %5794 = call float @dx.op.binary.f32(i32 35, float %5793, float -4.000000e+01)  ; FMax(a,b)
  %5795 = call float @dx.op.binary.f32(i32 36, float %5794, float 5.000000e+00)  ; FMin(a,b)
  %5796 = fmul fast float %5795, 0x3FF7154760000000
  %5797 = call float @dx.op.unary.f32(i32 21, float %5796)  ; Exp(value)
  %5798 = fmul fast float %5797, %5789
  br label %5799

; <label>:5799                                    ; preds = %5788, %5748
  %5800 = phi float [ %5798, %5788 ], [ 1.000000e+00, %5748 ]
  %5801 = fmul fast float %5774, %17
  %5802 = fmul fast float %5801, %5800
  %5803 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %5802)  ; FMin(a,b)
  %5804 = fmul fast float %5803, 0xBFF7154760000000
  %5805 = call float @dx.op.unary.f32(i32 21, float %5804)  ; Exp(value)
  %5806 = fsub fast float 1.000000e+00, %5805
  %5807 = call float @dx.op.binary.f32(i32 36, float %13, float %5806)  ; FMin(a,b)
  %5808 = fsub fast float %14, %5686
  %5809 = fsub fast float %15, %5687
  %5810 = fsub fast float %16, %5688
  %5811 = fmul fast float %5807, %5808
  %5812 = fmul fast float %5807, %5809
  %5813 = fmul fast float %5807, %5810
  %5814 = fadd fast float %5811, %5686
  %5815 = fadd fast float %5812, %5687
  %5816 = fadd fast float %5813, %5688
  br label %5817

; <label>:5817                                    ; preds = %5799, %5731, %5725
  %5818 = phi float [ %5814, %5799 ], [ %5686, %5731 ], [ %5686, %5725 ]
  %5819 = phi float [ %5815, %5799 ], [ %5687, %5731 ], [ %5687, %5725 ]
  %5820 = phi float [ %5816, %5799 ], [ %5688, %5731 ], [ %5688, %5725 ]
  %5821 = fadd fast float %6, 1.000000e+00
  %5822 = fadd fast float %7, 1.000000e+00
  %5823 = fsub fast float 1.000000e+00, %6
  %5824 = fmul fast float %37, %5821
  %5825 = fmul fast float %37, %5822
  %5826 = fmul fast float %37, %5823
  %5827 = fmul fast float %5824, %5818
  %5828 = fmul fast float %5825, %5819
  %5829 = fmul fast float %5826, %5820
  %5830 = fcmp fast ult float %38, 5.000000e-01
  br i1 %5830, label %5856, label %5831

; <label>:5831                                    ; preds = %5817
  %5832 = fmul fast float %5827, 0x4004147AE0000000
  %5833 = fmul fast float %5828, 0x4004147AE0000000
  %5834 = fmul fast float %5829, 0x4004147AE0000000
  %5835 = fadd fast float %5832, 0x3F9EB851E0000000
  %5836 = fadd fast float %5833, 0x3F9EB851E0000000
  %5837 = fadd fast float %5834, 0x3F9EB851E0000000
  %5838 = fmul fast float %5835, %5827
  %5839 = fmul fast float %5836, %5828
  %5840 = fmul fast float %5837, %5829
  %5841 = fmul fast float %5827, 0x400370A3E0000000
  %5842 = fmul fast float %5828, 0x400370A3E0000000
  %5843 = fmul fast float %5829, 0x400370A3E0000000
  %5844 = fadd fast float %5841, 0x3FE2E147A0000000
  %5845 = fadd fast float %5842, 0x3FE2E147A0000000
  %5846 = fadd fast float %5843, 0x3FE2E147A0000000
  %5847 = fmul fast float %5844, %5827
  %5848 = fmul fast float %5845, %5828
  %5849 = fmul fast float %5846, %5829
  %5850 = fadd fast float %5847, 0x3FC1EB8520000000
  %5851 = fadd fast float %5848, 0x3FC1EB8520000000
  %5852 = fadd fast float %5849, 0x3FC1EB8520000000
  %5853 = fdiv fast float %5838, %5850
  %5854 = fdiv fast float %5839, %5851
  %5855 = fdiv fast float %5840, %5852
  br label %5856

; <label>:5856                                    ; preds = %5831, %5817
  %5857 = phi float [ %5853, %5831 ], [ %5827, %5817 ]
  %5858 = phi float [ %5854, %5831 ], [ %5828, %5817 ]
  %5859 = phi float [ %5855, %5831 ], [ %5829, %5817 ]
  %5860 = call float @dx.op.unary.f32(i32 7, float %5857)  ; Saturate(value)
  %5861 = call float @dx.op.unary.f32(i32 7, float %5858)  ; Saturate(value)
  %5862 = call float @dx.op.unary.f32(i32 7, float %5859)  ; Saturate(value)
  %5863 = call float @dx.op.dot3.f32(i32 55, float %5860, float %5861, float %5862, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5864 = fsub fast float %5860, %5863
  %5865 = fsub fast float %5861, %5863
  %5866 = fsub fast float %5862, %5863
  %5867 = fmul fast float %5864, %9
  %5868 = fmul fast float %5865, %9
  %5869 = fmul fast float %5866, %9
  %5870 = fadd fast float %5867, %5863
  %5871 = fadd fast float %5868, %5863
  %5872 = fadd fast float %5869, %5863
  %5873 = call float @dx.op.unary.f32(i32 7, float %5870)  ; Saturate(value)
  %5874 = call float @dx.op.unary.f32(i32 7, float %5871)  ; Saturate(value)
  %5875 = call float @dx.op.unary.f32(i32 7, float %5872)  ; Saturate(value)
  %5876 = fadd fast float %5873, 0xBFC70A3D80000000
  %5877 = fadd fast float %5874, 0xBFC70A3D80000000
  %5878 = fadd fast float %5875, 0xBFC70A3D80000000
  %5879 = fmul fast float %5876, %8
  %5880 = fmul fast float %5877, %8
  %5881 = fmul fast float %5878, %8
  %5882 = fadd fast float %5879, 0x3FC70A3D80000000
  %5883 = fadd fast float %5880, 0x3FC70A3D80000000
  %5884 = fadd fast float %5881, 0x3FC70A3D80000000
  %5885 = call float @dx.op.unary.f32(i32 7, float %5882)  ; Saturate(value)
  %5886 = call float @dx.op.unary.f32(i32 7, float %5883)  ; Saturate(value)
  %5887 = call float @dx.op.unary.f32(i32 7, float %5884)  ; Saturate(value)
  br label %5888

; <label>:5888                                    ; preds = %5856, %5691
  %5889 = phi float [ %5722, %5691 ], [ %5885, %5856 ]
  %5890 = phi float [ %5723, %5691 ], [ %5886, %5856 ]
  %5891 = phi float [ %5724, %5691 ], [ %5887, %5856 ]
  %5892 = fsub fast float %5889, %4949
  %5893 = fsub fast float %5890, %4950
  %5894 = fsub fast float %5891, %4951
  %5895 = fmul fast float %5892, %5678
  %5896 = fmul fast float %5893, %5678
  %5897 = fmul fast float %5894, %5678
  %5898 = fadd fast float %5895, %4949
  %5899 = fadd fast float %5896, %4950
  %5900 = fadd fast float %5897, %4951
  br label %5901

; <label>:5901                                    ; preds = %5888, %5665
  %5902 = phi float [ %5898, %5888 ], [ %4949, %5665 ]
  %5903 = phi float [ %5899, %5888 ], [ %4950, %5665 ]
  %5904 = phi float [ %5900, %5888 ], [ %4951, %5665 ]
  %5905 = call float @dx.op.binary.f32(i32 36, float %5666, float %5902)  ; FMin(a,b)
  %5906 = call float @dx.op.binary.f32(i32 36, float %5667, float %5903)  ; FMin(a,b)
  %5907 = call float @dx.op.binary.f32(i32 36, float %5668, float %5904)  ; FMin(a,b)
  %5908 = call float @dx.op.binary.f32(i32 36, float %5192, float %5428)  ; FMin(a,b)
  %5909 = call float @dx.op.binary.f32(i32 36, float %5193, float %5429)  ; FMin(a,b)
  %5910 = call float @dx.op.binary.f32(i32 36, float %5194, float %5430)  ; FMin(a,b)
  %5911 = call float @dx.op.binary.f32(i32 36, float %5908, float %5905)  ; FMin(a,b)
  %5912 = call float @dx.op.binary.f32(i32 36, float %5909, float %5906)  ; FMin(a,b)
  %5913 = call float @dx.op.binary.f32(i32 36, float %5910, float %5907)  ; FMin(a,b)
  %5914 = call float @dx.op.binary.f32(i32 36, float %4949, float %5911)  ; FMin(a,b)
  %5915 = call float @dx.op.binary.f32(i32 36, float %4950, float %5912)  ; FMin(a,b)
  %5916 = call float @dx.op.binary.f32(i32 36, float %4951, float %5913)  ; FMin(a,b)
  %5917 = call float @dx.op.binary.f32(i32 35, float %5666, float %5902)  ; FMax(a,b)
  %5918 = call float @dx.op.binary.f32(i32 35, float %5667, float %5903)  ; FMax(a,b)
  %5919 = call float @dx.op.binary.f32(i32 35, float %5668, float %5904)  ; FMax(a,b)
  %5920 = call float @dx.op.binary.f32(i32 35, float %5192, float %5428)  ; FMax(a,b)
  %5921 = call float @dx.op.binary.f32(i32 35, float %5193, float %5429)  ; FMax(a,b)
  %5922 = call float @dx.op.binary.f32(i32 35, float %5194, float %5430)  ; FMax(a,b)
  %5923 = call float @dx.op.binary.f32(i32 35, float %5920, float %5917)  ; FMax(a,b)
  %5924 = call float @dx.op.binary.f32(i32 35, float %5921, float %5918)  ; FMax(a,b)
  %5925 = call float @dx.op.binary.f32(i32 35, float %5922, float %5919)  ; FMax(a,b)
  %5926 = call float @dx.op.binary.f32(i32 35, float %4949, float %5923)  ; FMax(a,b)
  %5927 = call float @dx.op.binary.f32(i32 35, float %4950, float %5924)  ; FMax(a,b)
  %5928 = call float @dx.op.binary.f32(i32 35, float %4951, float %5925)  ; FMax(a,b)
  %5929 = fsub fast float %5926, %5914
  %5930 = fsub fast float %5927, %5915
  %5931 = fsub fast float %5928, %5916
  %5932 = call float @dx.op.unary.f32(i32 6, float %5929)  ; FAbs(value)
  %5933 = call float @dx.op.unary.f32(i32 6, float %5930)  ; FAbs(value)
  %5934 = call float @dx.op.unary.f32(i32 6, float %5931)  ; FAbs(value)
  %5935 = call float @dx.op.binary.f32(i32 35, float %5933, float %5934)  ; FMax(a,b)
  %5936 = call float @dx.op.binary.f32(i32 35, float %5932, float %5935)  ; FMax(a,b)
  %5937 = call float @dx.op.binary.f32(i32 35, float %5927, float %5928)  ; FMax(a,b)
  %5938 = call float @dx.op.binary.f32(i32 35, float %5926, float %5937)  ; FMax(a,b)
  %5939 = fmul fast float %5938, 1.250000e-01
  %5940 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %5939)  ; FMax(a,b)
  %5941 = fcmp fast ogt float %5936, %5940
  br i1 %5941, label %5942, label %6004

; <label>:5942                                    ; preds = %5901
  %5943 = fsub fast float %5192, %5428
  %5944 = fsub fast float %5193, %5429
  %5945 = fsub fast float %5194, %5430
  %5946 = call float @dx.op.unary.f32(i32 6, float %5943)  ; FAbs(value)
  %5947 = call float @dx.op.unary.f32(i32 6, float %5944)  ; FAbs(value)
  %5948 = call float @dx.op.unary.f32(i32 6, float %5945)  ; FAbs(value)
  %5949 = call float @dx.op.binary.f32(i32 35, float %5947, float %5948)  ; FMax(a,b)
  %5950 = call float @dx.op.binary.f32(i32 35, float %5946, float %5949)  ; FMax(a,b)
  %5951 = fsub fast float %5666, %5902
  %5952 = fsub fast float %5667, %5903
  %5953 = fsub fast float %5668, %5904
  %5954 = call float @dx.op.unary.f32(i32 6, float %5951)  ; FAbs(value)
  %5955 = call float @dx.op.unary.f32(i32 6, float %5952)  ; FAbs(value)
  %5956 = call float @dx.op.unary.f32(i32 6, float %5953)  ; FAbs(value)
  %5957 = call float @dx.op.binary.f32(i32 35, float %5955, float %5956)  ; FMax(a,b)
  %5958 = call float @dx.op.binary.f32(i32 35, float %5954, float %5957)  ; FMax(a,b)
  %5959 = fcmp fast olt float %5950, %5958
  %5960 = select i1 %5959, float %5192, float %5666
  %5961 = select i1 %5959, float %5193, float %5667
  %5962 = select i1 %5959, float %5194, float %5668
  %5963 = select i1 %5959, float %5428, float %5902
  %5964 = select i1 %5959, float %5429, float %5903
  %5965 = select i1 %5959, float %5430, float %5904
  %5966 = fsub fast float %4949, %5963
  %5967 = fsub fast float %4950, %5964
  %5968 = fsub fast float %4951, %5965
  %5969 = fsub fast float %4949, %5960
  %5970 = fsub fast float %4950, %5961
  %5971 = fsub fast float %4951, %5962
  %5972 = call float @dx.op.dot3.f32(i32 55, float %5969, float %5970, float %5971, float %5966, float %5967, float %5968)  ; Dot3(ax,ay,az,bx,by,bz)
  %5973 = fcmp fast ogt float %5972, 0.000000e+00
  br i1 %5973, label %5974, label %5985

; <label>:5974                                    ; preds = %5942
  %5975 = fsub fast float %5960, %5963
  %5976 = fsub fast float %5961, %5964
  %5977 = fsub fast float %5962, %5965
  %5978 = call float @dx.op.unary.f32(i32 6, float %5975)  ; FAbs(value)
  %5979 = call float @dx.op.unary.f32(i32 6, float %5976)  ; FAbs(value)
  %5980 = call float @dx.op.unary.f32(i32 6, float %5977)  ; FAbs(value)
  %5981 = call float @dx.op.binary.f32(i32 35, float %5979, float %5980)  ; FMax(a,b)
  %5982 = call float @dx.op.binary.f32(i32 35, float %5978, float %5981)  ; FMax(a,b)
  %5983 = fmul fast float %5936, 2.500000e-01
  %5984 = fcmp fast olt float %5982, %5983
  br label %5985

; <label>:5985                                    ; preds = %5974, %5942
  %5986 = phi i1 [ false, %5942 ], [ %5984, %5974 ]
  %5987 = select i1 %5986, float 5.000000e-01, float 1.000000e+00
  %5988 = fmul fast float %5987, %3
  %5989 = fadd fast float %5960, %5963
  %5990 = fadd fast float %5961, %5964
  %5991 = fadd fast float %5962, %5965
  %5992 = fmul fast float %5989, 5.000000e-01
  %5993 = fmul fast float %5990, 5.000000e-01
  %5994 = fmul fast float %5991, 5.000000e-01
  %5995 = fsub fast float %5992, %4949
  %5996 = fsub fast float %5993, %4950
  %5997 = fsub fast float %5994, %4951
  %5998 = fmul fast float %5988, %5995
  %5999 = fmul fast float %5988, %5996
  %6000 = fmul fast float %5988, %5997
  %6001 = fadd fast float %5998, %4949
  %6002 = fadd fast float %5999, %4950
  %6003 = fadd fast float %6000, %4951
  br label %6004

; <label>:6004                                    ; preds = %5985, %5901, %4920, %4756
  %6005 = phi float [ %4787, %4756 ], [ %4949, %4920 ], [ %6001, %5985 ], [ %4949, %5901 ]
  %6006 = phi float [ %4788, %4756 ], [ %4950, %4920 ], [ %6002, %5985 ], [ %4950, %5901 ]
  %6007 = phi float [ %4789, %4756 ], [ %4951, %4920 ], [ %6003, %5985 ], [ %4951, %5901 ]
  %6008 = phi float [ %4790, %4756 ], [ %4754, %4920 ], [ %4754, %5985 ], [ %4754, %5901 ]
  %6009 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %64, i32 %71, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6010 = extractvalue %dx.types.ResRet.f32 %6009, 0
  %6011 = extractvalue %dx.types.ResRet.f32 %6009, 1
  %6012 = extractvalue %dx.types.ResRet.f32 %6009, 2
  %6013 = extractvalue %dx.types.ResRet.f32 %6009, 3
  %6014 = fcmp fast olt float %6013, 0.000000e+00
  br i1 %6014, label %6015, label %6050

; <label>:6015                                    ; preds = %6004
  %6016 = fcmp fast ogt float %6010, 0x3FA4B5DCC0000000
  %6017 = fcmp fast ogt float %6011, 0x3FA4B5DCC0000000
  %6018 = fcmp fast ogt float %6012, 0x3FA4B5DCC0000000
  %6019 = select i1 %6016, float 0.000000e+00, float 1.000000e+00
  %6020 = select i1 %6017, float 0.000000e+00, float 1.000000e+00
  %6021 = select i1 %6018, float 0.000000e+00, float 1.000000e+00
  %6022 = fmul fast float %6010, 0x3FB3D07220000000
  %6023 = fmul fast float %6011, 0x3FB3D07220000000
  %6024 = fmul fast float %6012, 0x3FB3D07220000000
  %6025 = fadd fast float %6010, 0x3FAC28F5C0000000
  %6026 = fadd fast float %6011, 0x3FAC28F5C0000000
  %6027 = fadd fast float %6012, 0x3FAC28F5C0000000
  %6028 = fmul fast float %6025, 0x3FEE54EDE0000000
  %6029 = fmul fast float %6026, 0x3FEE54EDE0000000
  %6030 = fmul fast float %6027, 0x3FEE54EDE0000000
  %6031 = call float @dx.op.unary.f32(i32 23, float %6028)  ; Log(value)
  %6032 = call float @dx.op.unary.f32(i32 23, float %6029)  ; Log(value)
  %6033 = call float @dx.op.unary.f32(i32 23, float %6030)  ; Log(value)
  %6034 = fmul fast float %6031, 0x4003333340000000
  %6035 = fmul fast float %6032, 0x4003333340000000
  %6036 = fmul fast float %6033, 0x4003333340000000
  %6037 = call float @dx.op.unary.f32(i32 21, float %6034)  ; Exp(value)
  %6038 = call float @dx.op.unary.f32(i32 21, float %6035)  ; Exp(value)
  %6039 = call float @dx.op.unary.f32(i32 21, float %6036)  ; Exp(value)
  %6040 = fsub fast float %6022, %6037
  %6041 = fsub fast float %6023, %6038
  %6042 = fsub fast float %6024, %6039
  %6043 = fmul fast float %6040, %6019
  %6044 = fmul fast float %6041, %6020
  %6045 = fmul fast float %6042, %6021
  %6046 = fadd fast float %6043, %6037
  %6047 = fadd fast float %6044, %6038
  %6048 = fadd fast float %6045, %6039
  %6049 = fsub fast float -1.000000e+00, %6013
  br label %7263

; <label>:6050                                    ; preds = %6004
  %6051 = fcmp fast ogt float %39, 5.000000e-01
  %6052 = fcmp fast olt float %87, 1.000000e+00
  %6053 = and i1 %6051, %6052
  br i1 %6053, label %6054, label %6140

; <label>:6054                                    ; preds = %6050
  %6055 = sitofp i32 %64 to float
  %6056 = sitofp i32 %71 to float
  %6057 = fadd fast float %6055, 5.000000e-01
  %6058 = fadd fast float %6056, 5.000000e-01
  %6059 = fdiv fast float %6057, %46
  %6060 = fdiv fast float %6058, %47
  %6061 = fmul fast float %6059, 2.000000e+00
  %6062 = fmul fast float %6060, 2.000000e+00
  %6063 = fadd fast float %6061, -1.000000e+00
  %6064 = fsub fast float 1.000000e+00, %6062
  %6065 = fmul fast float %6063, %36
  %6066 = call float @dx.op.tertiary.f32(i32 46, float %6064, float %32, float %6065)  ; FMad(a,b,c)
  %6067 = call float @dx.op.tertiary.f32(i32 46, float %87, float %28, float %6066)  ; FMad(a,b,c)
  %6068 = fadd fast float %6067, %24
  %6069 = call float @dx.op.unary.f32(i32 6, float %6068)  ; FAbs(value)
  %6070 = fcmp fast ogt float %6069, 0x3EB0C6F7A0000000
  br i1 %6070, label %6071, label %6140

; <label>:6071                                    ; preds = %6054
  %6072 = fmul fast float %6063, %35
  %6073 = call float @dx.op.tertiary.f32(i32 46, float %6064, float %31, float %6072)  ; FMad(a,b,c)
  %6074 = call float @dx.op.tertiary.f32(i32 46, float %87, float %27, float %6073)  ; FMad(a,b,c)
  %6075 = fadd fast float %6074, %23
  %6076 = fmul fast float %6063, %34
  %6077 = call float @dx.op.tertiary.f32(i32 46, float %6064, float %30, float %6076)  ; FMad(a,b,c)
  %6078 = call float @dx.op.tertiary.f32(i32 46, float %87, float %26, float %6077)  ; FMad(a,b,c)
  %6079 = fadd fast float %6078, %22
  %6080 = fmul fast float %6063, %33
  %6081 = call float @dx.op.tertiary.f32(i32 46, float %6064, float %29, float %6080)  ; FMad(a,b,c)
  %6082 = call float @dx.op.tertiary.f32(i32 46, float %87, float %25, float %6081)  ; FMad(a,b,c)
  %6083 = fadd fast float %6082, %21
  %6084 = fdiv fast float %6083, %6068
  %6085 = fdiv fast float %6079, %6068
  %6086 = fdiv fast float %6075, %6068
  %6087 = fsub fast float %6084, %18
  %6088 = fsub fast float %6085, %19
  %6089 = fsub fast float %6086, %20
  %6090 = fmul fast float %6087, %6087
  %6091 = fmul fast float %6088, %6088
  %6092 = fadd fast float %6091, %6090
  %6093 = fmul fast float %6089, %6089
  %6094 = fadd fast float %6092, %6093
  %6095 = call float @dx.op.unary.f32(i32 24, float %6094)  ; Sqrt(value)
  %6096 = fsub fast float %6095, %10
  %6097 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %6096)  ; FMax(a,b)
  %6098 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %6098, label %6099, label %6122

; <label>:6099                                    ; preds = %6071
  %6100 = call float @dx.op.unary.f32(i32 6, float %6088)  ; FAbs(value)
  %6101 = fmul fast float %6100, %12
  %6102 = fcmp fast olt float %6101, 0x3F50624DE0000000
  br i1 %6102, label %6103, label %6106

; <label>:6103                                    ; preds = %6099
  %6104 = fmul fast float %6101, 5.000000e-01
  %6105 = fsub fast float 1.000000e+00, %6104
  br label %6111

; <label>:6106                                    ; preds = %6099
  %6107 = fmul fast float %6101, 0xBFF7154760000000
  %6108 = call float @dx.op.unary.f32(i32 21, float %6107)  ; Exp(value)
  %6109 = fsub fast float 1.000000e+00, %6108
  %6110 = fdiv fast float %6109, %6101
  br label %6111

; <label>:6111                                    ; preds = %6106, %6103
  %6112 = phi float [ %6105, %6103 ], [ %6110, %6106 ]
  %6113 = call float @dx.op.binary.f32(i32 36, float %6085, float %19)  ; FMin(a,b)
  %6114 = fsub fast float %6113, %11
  %6115 = fmul fast float %12, %6114
  %6116 = fsub fast float -0.000000e+00, %6115
  %6117 = call float @dx.op.binary.f32(i32 35, float %6116, float -4.000000e+01)  ; FMax(a,b)
  %6118 = call float @dx.op.binary.f32(i32 36, float %6117, float 5.000000e+00)  ; FMin(a,b)
  %6119 = fmul fast float %6118, 0x3FF7154760000000
  %6120 = call float @dx.op.unary.f32(i32 21, float %6119)  ; Exp(value)
  %6121 = fmul fast float %6120, %6112
  br label %6122

; <label>:6122                                    ; preds = %6111, %6071
  %6123 = phi float [ %6121, %6111 ], [ 1.000000e+00, %6071 ]
  %6124 = fmul fast float %6097, %17
  %6125 = fmul fast float %6124, %6123
  %6126 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %6125)  ; FMin(a,b)
  %6127 = fmul fast float %6126, 0xBFF7154760000000
  %6128 = call float @dx.op.unary.f32(i32 21, float %6127)  ; Exp(value)
  %6129 = fsub fast float 1.000000e+00, %6128
  %6130 = call float @dx.op.binary.f32(i32 36, float %13, float %6129)  ; FMin(a,b)
  %6131 = fsub fast float %14, %6010
  %6132 = fsub fast float %15, %6011
  %6133 = fsub fast float %16, %6012
  %6134 = fmul fast float %6130, %6131
  %6135 = fmul fast float %6130, %6132
  %6136 = fmul fast float %6130, %6133
  %6137 = fadd fast float %6134, %6010
  %6138 = fadd fast float %6135, %6011
  %6139 = fadd fast float %6136, %6012
  br label %6140

; <label>:6140                                    ; preds = %6122, %6054, %6050
  %6141 = phi float [ %6137, %6122 ], [ %6010, %6054 ], [ %6010, %6050 ]
  %6142 = phi float [ %6138, %6122 ], [ %6011, %6054 ], [ %6011, %6050 ]
  %6143 = phi float [ %6139, %6122 ], [ %6012, %6054 ], [ %6012, %6050 ]
  %6144 = fadd fast float %6, 1.000000e+00
  %6145 = fadd fast float %7, 1.000000e+00
  %6146 = fsub fast float 1.000000e+00, %6
  %6147 = fmul fast float %37, %6144
  %6148 = fmul fast float %37, %6145
  %6149 = fmul fast float %37, %6146
  %6150 = fmul fast float %6147, %6141
  %6151 = fmul fast float %6148, %6142
  %6152 = fmul fast float %6149, %6143
  %6153 = fcmp fast ult float %38, 5.000000e-01
  br i1 %6153, label %6179, label %6154

; <label>:6154                                    ; preds = %6140
  %6155 = fmul fast float %6150, 0x4004147AE0000000
  %6156 = fmul fast float %6151, 0x4004147AE0000000
  %6157 = fmul fast float %6152, 0x4004147AE0000000
  %6158 = fadd fast float %6155, 0x3F9EB851E0000000
  %6159 = fadd fast float %6156, 0x3F9EB851E0000000
  %6160 = fadd fast float %6157, 0x3F9EB851E0000000
  %6161 = fmul fast float %6158, %6150
  %6162 = fmul fast float %6159, %6151
  %6163 = fmul fast float %6160, %6152
  %6164 = fmul fast float %6150, 0x400370A3E0000000
  %6165 = fmul fast float %6151, 0x400370A3E0000000
  %6166 = fmul fast float %6152, 0x400370A3E0000000
  %6167 = fadd fast float %6164, 0x3FE2E147A0000000
  %6168 = fadd fast float %6165, 0x3FE2E147A0000000
  %6169 = fadd fast float %6166, 0x3FE2E147A0000000
  %6170 = fmul fast float %6167, %6150
  %6171 = fmul fast float %6168, %6151
  %6172 = fmul fast float %6169, %6152
  %6173 = fadd fast float %6170, 0x3FC1EB8520000000
  %6174 = fadd fast float %6171, 0x3FC1EB8520000000
  %6175 = fadd fast float %6172, 0x3FC1EB8520000000
  %6176 = fdiv fast float %6161, %6173
  %6177 = fdiv fast float %6162, %6174
  %6178 = fdiv fast float %6163, %6175
  br label %6179

; <label>:6179                                    ; preds = %6154, %6140
  %6180 = phi float [ %6176, %6154 ], [ %6150, %6140 ]
  %6181 = phi float [ %6177, %6154 ], [ %6151, %6140 ]
  %6182 = phi float [ %6178, %6154 ], [ %6152, %6140 ]
  %6183 = call float @dx.op.unary.f32(i32 7, float %6180)  ; Saturate(value)
  %6184 = call float @dx.op.unary.f32(i32 7, float %6181)  ; Saturate(value)
  %6185 = call float @dx.op.unary.f32(i32 7, float %6182)  ; Saturate(value)
  %6186 = call float @dx.op.dot3.f32(i32 55, float %6183, float %6184, float %6185, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %6187 = fsub fast float %6183, %6186
  %6188 = fsub fast float %6184, %6186
  %6189 = fsub fast float %6185, %6186
  %6190 = fmul fast float %6187, %9
  %6191 = fmul fast float %6188, %9
  %6192 = fmul fast float %6189, %9
  %6193 = fadd fast float %6190, %6186
  %6194 = fadd fast float %6191, %6186
  %6195 = fadd fast float %6192, %6186
  %6196 = call float @dx.op.unary.f32(i32 7, float %6193)  ; Saturate(value)
  %6197 = call float @dx.op.unary.f32(i32 7, float %6194)  ; Saturate(value)
  %6198 = call float @dx.op.unary.f32(i32 7, float %6195)  ; Saturate(value)
  %6199 = fadd fast float %6196, 0xBFC70A3D80000000
  %6200 = fadd fast float %6197, 0xBFC70A3D80000000
  %6201 = fadd fast float %6198, 0xBFC70A3D80000000
  %6202 = fmul fast float %6199, %8
  %6203 = fmul fast float %6200, %8
  %6204 = fmul fast float %6201, %8
  %6205 = fadd fast float %6202, 0x3FC70A3D80000000
  %6206 = fadd fast float %6203, 0x3FC70A3D80000000
  %6207 = fadd fast float %6204, 0x3FC70A3D80000000
  %6208 = call float @dx.op.unary.f32(i32 7, float %6205)  ; Saturate(value)
  %6209 = call float @dx.op.unary.f32(i32 7, float %6206)  ; Saturate(value)
  %6210 = call float @dx.op.unary.f32(i32 7, float %6207)  ; Saturate(value)
  %6211 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %6211, label %6212, label %7263

; <label>:6212                                    ; preds = %6179
  %6213 = add i32 %71, -1
  %6214 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %6215 = call i32 @dx.op.binary.i32(i32 37, i32 %6213, i32 0)  ; IMax(a,b)
  %6216 = call i32 @dx.op.binary.i32(i32 38, i32 %6214, i32 %60)  ; IMin(a,b)
  %6217 = call i32 @dx.op.binary.i32(i32 38, i32 %6215, i32 %61)  ; IMin(a,b)
  %6218 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %6216, i32 %6217, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6219 = extractvalue %dx.types.ResRet.f32 %6218, 0
  %6220 = fsub fast float 1.000000e+00, %87
  %6221 = fmul fast float %6220, 0x3FA99999A0000000
  %6222 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %6221)  ; FMax(a,b)
  %6223 = fsub fast float %6219, %87
  %6224 = call float @dx.op.unary.f32(i32 6, float %6223)  ; FAbs(value)
  %6225 = fdiv fast float %6224, %6222
  %6226 = fsub fast float 1.000000e+00, %6225
  %6227 = call float @dx.op.unary.f32(i32 7, float %6226)  ; Saturate(value)
  %6228 = fcmp fast ugt float %6227, 0.000000e+00
  br i1 %6228, label %6229, label %6450

; <label>:6229                                    ; preds = %6212
  %6230 = call i32 @dx.op.binary.i32(i32 37, i32 %6216, i32 0)  ; IMax(a,b)
  %6231 = call i32 @dx.op.binary.i32(i32 37, i32 %6217, i32 0)  ; IMax(a,b)
  %6232 = call i32 @dx.op.binary.i32(i32 38, i32 %6230, i32 %60)  ; IMin(a,b)
  %6233 = call i32 @dx.op.binary.i32(i32 38, i32 %6231, i32 %61)  ; IMin(a,b)
  %6234 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %6232, i32 %6233, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6235 = extractvalue %dx.types.ResRet.f32 %6234, 0
  %6236 = extractvalue %dx.types.ResRet.f32 %6234, 1
  %6237 = extractvalue %dx.types.ResRet.f32 %6234, 2
  %6238 = extractvalue %dx.types.ResRet.f32 %6234, 3
  %6239 = fcmp fast olt float %6238, 0.000000e+00
  br i1 %6239, label %6240, label %6274

; <label>:6240                                    ; preds = %6229
  %6241 = fcmp fast ogt float %6235, 0x3FA4B5DCC0000000
  %6242 = fcmp fast ogt float %6236, 0x3FA4B5DCC0000000
  %6243 = fcmp fast ogt float %6237, 0x3FA4B5DCC0000000
  %6244 = select i1 %6241, float 0.000000e+00, float 1.000000e+00
  %6245 = select i1 %6242, float 0.000000e+00, float 1.000000e+00
  %6246 = select i1 %6243, float 0.000000e+00, float 1.000000e+00
  %6247 = fmul fast float %6235, 0x3FB3D07220000000
  %6248 = fmul fast float %6236, 0x3FB3D07220000000
  %6249 = fmul fast float %6237, 0x3FB3D07220000000
  %6250 = fadd fast float %6235, 0x3FAC28F5C0000000
  %6251 = fadd fast float %6236, 0x3FAC28F5C0000000
  %6252 = fadd fast float %6237, 0x3FAC28F5C0000000
  %6253 = fmul fast float %6250, 0x3FEE54EDE0000000
  %6254 = fmul fast float %6251, 0x3FEE54EDE0000000
  %6255 = fmul fast float %6252, 0x3FEE54EDE0000000
  %6256 = call float @dx.op.unary.f32(i32 23, float %6253)  ; Log(value)
  %6257 = call float @dx.op.unary.f32(i32 23, float %6254)  ; Log(value)
  %6258 = call float @dx.op.unary.f32(i32 23, float %6255)  ; Log(value)
  %6259 = fmul fast float %6256, 0x4003333340000000
  %6260 = fmul fast float %6257, 0x4003333340000000
  %6261 = fmul fast float %6258, 0x4003333340000000
  %6262 = call float @dx.op.unary.f32(i32 21, float %6259)  ; Exp(value)
  %6263 = call float @dx.op.unary.f32(i32 21, float %6260)  ; Exp(value)
  %6264 = call float @dx.op.unary.f32(i32 21, float %6261)  ; Exp(value)
  %6265 = fsub fast float %6247, %6262
  %6266 = fsub fast float %6248, %6263
  %6267 = fsub fast float %6249, %6264
  %6268 = fmul fast float %6265, %6244
  %6269 = fmul fast float %6266, %6245
  %6270 = fmul fast float %6267, %6246
  %6271 = fadd fast float %6268, %6262
  %6272 = fadd fast float %6269, %6263
  %6273 = fadd fast float %6270, %6264
  br label %6437

; <label>:6274                                    ; preds = %6229
  %6275 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %6232, i32 %6233, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6276 = extractvalue %dx.types.ResRet.f32 %6275, 0
  %6277 = fcmp fast ogt float %39, 5.000000e-01
  %6278 = fcmp fast olt float %6276, 1.000000e+00
  %6279 = and i1 %6277, %6278
  br i1 %6279, label %6280, label %6366

; <label>:6280                                    ; preds = %6274
  %6281 = sitofp i32 %6232 to float
  %6282 = sitofp i32 %6233 to float
  %6283 = fadd fast float %6281, 5.000000e-01
  %6284 = fadd fast float %6282, 5.000000e-01
  %6285 = fdiv fast float %6283, %46
  %6286 = fdiv fast float %6284, %47
  %6287 = fmul fast float %6285, 2.000000e+00
  %6288 = fmul fast float %6286, 2.000000e+00
  %6289 = fadd fast float %6287, -1.000000e+00
  %6290 = fsub fast float 1.000000e+00, %6288
  %6291 = fmul fast float %6289, %36
  %6292 = call float @dx.op.tertiary.f32(i32 46, float %6290, float %32, float %6291)  ; FMad(a,b,c)
  %6293 = call float @dx.op.tertiary.f32(i32 46, float %6276, float %28, float %6292)  ; FMad(a,b,c)
  %6294 = fadd fast float %6293, %24
  %6295 = call float @dx.op.unary.f32(i32 6, float %6294)  ; FAbs(value)
  %6296 = fcmp fast ogt float %6295, 0x3EB0C6F7A0000000
  br i1 %6296, label %6297, label %6366

; <label>:6297                                    ; preds = %6280
  %6298 = fmul fast float %6289, %35
  %6299 = call float @dx.op.tertiary.f32(i32 46, float %6290, float %31, float %6298)  ; FMad(a,b,c)
  %6300 = call float @dx.op.tertiary.f32(i32 46, float %6276, float %27, float %6299)  ; FMad(a,b,c)
  %6301 = fadd fast float %6300, %23
  %6302 = fmul fast float %6289, %34
  %6303 = call float @dx.op.tertiary.f32(i32 46, float %6290, float %30, float %6302)  ; FMad(a,b,c)
  %6304 = call float @dx.op.tertiary.f32(i32 46, float %6276, float %26, float %6303)  ; FMad(a,b,c)
  %6305 = fadd fast float %6304, %22
  %6306 = fmul fast float %6289, %33
  %6307 = call float @dx.op.tertiary.f32(i32 46, float %6290, float %29, float %6306)  ; FMad(a,b,c)
  %6308 = call float @dx.op.tertiary.f32(i32 46, float %6276, float %25, float %6307)  ; FMad(a,b,c)
  %6309 = fadd fast float %6308, %21
  %6310 = fdiv fast float %6309, %6294
  %6311 = fdiv fast float %6305, %6294
  %6312 = fdiv fast float %6301, %6294
  %6313 = fsub fast float %6310, %18
  %6314 = fsub fast float %6311, %19
  %6315 = fsub fast float %6312, %20
  %6316 = fmul fast float %6313, %6313
  %6317 = fmul fast float %6314, %6314
  %6318 = fadd fast float %6317, %6316
  %6319 = fmul fast float %6315, %6315
  %6320 = fadd fast float %6318, %6319
  %6321 = call float @dx.op.unary.f32(i32 24, float %6320)  ; Sqrt(value)
  %6322 = fsub fast float %6321, %10
  %6323 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %6322)  ; FMax(a,b)
  %6324 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %6324, label %6325, label %6348

; <label>:6325                                    ; preds = %6297
  %6326 = call float @dx.op.unary.f32(i32 6, float %6314)  ; FAbs(value)
  %6327 = fmul fast float %6326, %12
  %6328 = fcmp fast olt float %6327, 0x3F50624DE0000000
  br i1 %6328, label %6329, label %6332

; <label>:6329                                    ; preds = %6325
  %6330 = fmul fast float %6327, 5.000000e-01
  %6331 = fsub fast float 1.000000e+00, %6330
  br label %6337

; <label>:6332                                    ; preds = %6325
  %6333 = fmul fast float %6327, 0xBFF7154760000000
  %6334 = call float @dx.op.unary.f32(i32 21, float %6333)  ; Exp(value)
  %6335 = fsub fast float 1.000000e+00, %6334
  %6336 = fdiv fast float %6335, %6327
  br label %6337

; <label>:6337                                    ; preds = %6332, %6329
  %6338 = phi float [ %6331, %6329 ], [ %6336, %6332 ]
  %6339 = call float @dx.op.binary.f32(i32 36, float %6311, float %19)  ; FMin(a,b)
  %6340 = fsub fast float %6339, %11
  %6341 = fmul fast float %12, %6340
  %6342 = fsub fast float -0.000000e+00, %6341
  %6343 = call float @dx.op.binary.f32(i32 35, float %6342, float -4.000000e+01)  ; FMax(a,b)
  %6344 = call float @dx.op.binary.f32(i32 36, float %6343, float 5.000000e+00)  ; FMin(a,b)
  %6345 = fmul fast float %6344, 0x3FF7154760000000
  %6346 = call float @dx.op.unary.f32(i32 21, float %6345)  ; Exp(value)
  %6347 = fmul fast float %6346, %6338
  br label %6348

; <label>:6348                                    ; preds = %6337, %6297
  %6349 = phi float [ %6347, %6337 ], [ 1.000000e+00, %6297 ]
  %6350 = fmul fast float %6323, %17
  %6351 = fmul fast float %6350, %6349
  %6352 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %6351)  ; FMin(a,b)
  %6353 = fmul fast float %6352, 0xBFF7154760000000
  %6354 = call float @dx.op.unary.f32(i32 21, float %6353)  ; Exp(value)
  %6355 = fsub fast float 1.000000e+00, %6354
  %6356 = call float @dx.op.binary.f32(i32 36, float %13, float %6355)  ; FMin(a,b)
  %6357 = fsub fast float %14, %6235
  %6358 = fsub fast float %15, %6236
  %6359 = fsub fast float %16, %6237
  %6360 = fmul fast float %6356, %6357
  %6361 = fmul fast float %6356, %6358
  %6362 = fmul fast float %6356, %6359
  %6363 = fadd fast float %6360, %6235
  %6364 = fadd fast float %6361, %6236
  %6365 = fadd fast float %6362, %6237
  br label %6366

; <label>:6366                                    ; preds = %6348, %6280, %6274
  %6367 = phi float [ %6363, %6348 ], [ %6235, %6280 ], [ %6235, %6274 ]
  %6368 = phi float [ %6364, %6348 ], [ %6236, %6280 ], [ %6236, %6274 ]
  %6369 = phi float [ %6365, %6348 ], [ %6237, %6280 ], [ %6237, %6274 ]
  %6370 = fadd fast float %6, 1.000000e+00
  %6371 = fadd fast float %7, 1.000000e+00
  %6372 = fsub fast float 1.000000e+00, %6
  %6373 = fmul fast float %37, %6370
  %6374 = fmul fast float %37, %6371
  %6375 = fmul fast float %37, %6372
  %6376 = fmul fast float %6373, %6367
  %6377 = fmul fast float %6374, %6368
  %6378 = fmul fast float %6375, %6369
  %6379 = fcmp fast ult float %38, 5.000000e-01
  br i1 %6379, label %6405, label %6380

; <label>:6380                                    ; preds = %6366
  %6381 = fmul fast float %6376, 0x4004147AE0000000
  %6382 = fmul fast float %6377, 0x4004147AE0000000
  %6383 = fmul fast float %6378, 0x4004147AE0000000
  %6384 = fadd fast float %6381, 0x3F9EB851E0000000
  %6385 = fadd fast float %6382, 0x3F9EB851E0000000
  %6386 = fadd fast float %6383, 0x3F9EB851E0000000
  %6387 = fmul fast float %6384, %6376
  %6388 = fmul fast float %6385, %6377
  %6389 = fmul fast float %6386, %6378
  %6390 = fmul fast float %6376, 0x400370A3E0000000
  %6391 = fmul fast float %6377, 0x400370A3E0000000
  %6392 = fmul fast float %6378, 0x400370A3E0000000
  %6393 = fadd fast float %6390, 0x3FE2E147A0000000
  %6394 = fadd fast float %6391, 0x3FE2E147A0000000
  %6395 = fadd fast float %6392, 0x3FE2E147A0000000
  %6396 = fmul fast float %6393, %6376
  %6397 = fmul fast float %6394, %6377
  %6398 = fmul fast float %6395, %6378
  %6399 = fadd fast float %6396, 0x3FC1EB8520000000
  %6400 = fadd fast float %6397, 0x3FC1EB8520000000
  %6401 = fadd fast float %6398, 0x3FC1EB8520000000
  %6402 = fdiv fast float %6387, %6399
  %6403 = fdiv fast float %6388, %6400
  %6404 = fdiv fast float %6389, %6401
  br label %6405

; <label>:6405                                    ; preds = %6380, %6366
  %6406 = phi float [ %6402, %6380 ], [ %6376, %6366 ]
  %6407 = phi float [ %6403, %6380 ], [ %6377, %6366 ]
  %6408 = phi float [ %6404, %6380 ], [ %6378, %6366 ]
  %6409 = call float @dx.op.unary.f32(i32 7, float %6406)  ; Saturate(value)
  %6410 = call float @dx.op.unary.f32(i32 7, float %6407)  ; Saturate(value)
  %6411 = call float @dx.op.unary.f32(i32 7, float %6408)  ; Saturate(value)
  %6412 = call float @dx.op.dot3.f32(i32 55, float %6409, float %6410, float %6411, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %6413 = fsub fast float %6409, %6412
  %6414 = fsub fast float %6410, %6412
  %6415 = fsub fast float %6411, %6412
  %6416 = fmul fast float %6413, %9
  %6417 = fmul fast float %6414, %9
  %6418 = fmul fast float %6415, %9
  %6419 = fadd fast float %6416, %6412
  %6420 = fadd fast float %6417, %6412
  %6421 = fadd fast float %6418, %6412
  %6422 = call float @dx.op.unary.f32(i32 7, float %6419)  ; Saturate(value)
  %6423 = call float @dx.op.unary.f32(i32 7, float %6420)  ; Saturate(value)
  %6424 = call float @dx.op.unary.f32(i32 7, float %6421)  ; Saturate(value)
  %6425 = fadd fast float %6422, 0xBFC70A3D80000000
  %6426 = fadd fast float %6423, 0xBFC70A3D80000000
  %6427 = fadd fast float %6424, 0xBFC70A3D80000000
  %6428 = fmul fast float %6425, %8
  %6429 = fmul fast float %6426, %8
  %6430 = fmul fast float %6427, %8
  %6431 = fadd fast float %6428, 0x3FC70A3D80000000
  %6432 = fadd fast float %6429, 0x3FC70A3D80000000
  %6433 = fadd fast float %6430, 0x3FC70A3D80000000
  %6434 = call float @dx.op.unary.f32(i32 7, float %6431)  ; Saturate(value)
  %6435 = call float @dx.op.unary.f32(i32 7, float %6432)  ; Saturate(value)
  %6436 = call float @dx.op.unary.f32(i32 7, float %6433)  ; Saturate(value)
  br label %6437

; <label>:6437                                    ; preds = %6405, %6240
  %6438 = phi float [ %6271, %6240 ], [ %6434, %6405 ]
  %6439 = phi float [ %6272, %6240 ], [ %6435, %6405 ]
  %6440 = phi float [ %6273, %6240 ], [ %6436, %6405 ]
  %6441 = fsub fast float %6438, %6208
  %6442 = fsub fast float %6439, %6209
  %6443 = fsub fast float %6440, %6210
  %6444 = fmul fast float %6441, %6227
  %6445 = fmul fast float %6442, %6227
  %6446 = fmul fast float %6443, %6227
  %6447 = fadd fast float %6444, %6208
  %6448 = fadd fast float %6445, %6209
  %6449 = fadd fast float %6446, %6210
  br label %6450

; <label>:6450                                    ; preds = %6437, %6212
  %6451 = phi float [ %6447, %6437 ], [ %6208, %6212 ]
  %6452 = phi float [ %6448, %6437 ], [ %6209, %6212 ]
  %6453 = phi float [ %6449, %6437 ], [ %6210, %6212 ]
  %6454 = add i32 %71, 1
  %6455 = call i32 @dx.op.binary.i32(i32 37, i32 %6454, i32 0)  ; IMax(a,b)
  %6456 = call i32 @dx.op.binary.i32(i32 38, i32 %6455, i32 %61)  ; IMin(a,b)
  %6457 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %6216, i32 %6456, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6458 = extractvalue %dx.types.ResRet.f32 %6457, 0
  %6459 = fsub fast float %6458, %87
  %6460 = call float @dx.op.unary.f32(i32 6, float %6459)  ; FAbs(value)
  %6461 = fdiv fast float %6460, %6222
  %6462 = fsub fast float 1.000000e+00, %6461
  %6463 = call float @dx.op.unary.f32(i32 7, float %6462)  ; Saturate(value)
  %6464 = fcmp fast ugt float %6463, 0.000000e+00
  br i1 %6464, label %6465, label %6686

; <label>:6465                                    ; preds = %6450
  %6466 = call i32 @dx.op.binary.i32(i32 37, i32 %6216, i32 0)  ; IMax(a,b)
  %6467 = call i32 @dx.op.binary.i32(i32 37, i32 %6456, i32 0)  ; IMax(a,b)
  %6468 = call i32 @dx.op.binary.i32(i32 38, i32 %6466, i32 %60)  ; IMin(a,b)
  %6469 = call i32 @dx.op.binary.i32(i32 38, i32 %6467, i32 %61)  ; IMin(a,b)
  %6470 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %6468, i32 %6469, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6471 = extractvalue %dx.types.ResRet.f32 %6470, 0
  %6472 = extractvalue %dx.types.ResRet.f32 %6470, 1
  %6473 = extractvalue %dx.types.ResRet.f32 %6470, 2
  %6474 = extractvalue %dx.types.ResRet.f32 %6470, 3
  %6475 = fcmp fast olt float %6474, 0.000000e+00
  br i1 %6475, label %6476, label %6510

; <label>:6476                                    ; preds = %6465
  %6477 = fcmp fast ogt float %6471, 0x3FA4B5DCC0000000
  %6478 = fcmp fast ogt float %6472, 0x3FA4B5DCC0000000
  %6479 = fcmp fast ogt float %6473, 0x3FA4B5DCC0000000
  %6480 = select i1 %6477, float 0.000000e+00, float 1.000000e+00
  %6481 = select i1 %6478, float 0.000000e+00, float 1.000000e+00
  %6482 = select i1 %6479, float 0.000000e+00, float 1.000000e+00
  %6483 = fmul fast float %6471, 0x3FB3D07220000000
  %6484 = fmul fast float %6472, 0x3FB3D07220000000
  %6485 = fmul fast float %6473, 0x3FB3D07220000000
  %6486 = fadd fast float %6471, 0x3FAC28F5C0000000
  %6487 = fadd fast float %6472, 0x3FAC28F5C0000000
  %6488 = fadd fast float %6473, 0x3FAC28F5C0000000
  %6489 = fmul fast float %6486, 0x3FEE54EDE0000000
  %6490 = fmul fast float %6487, 0x3FEE54EDE0000000
  %6491 = fmul fast float %6488, 0x3FEE54EDE0000000
  %6492 = call float @dx.op.unary.f32(i32 23, float %6489)  ; Log(value)
  %6493 = call float @dx.op.unary.f32(i32 23, float %6490)  ; Log(value)
  %6494 = call float @dx.op.unary.f32(i32 23, float %6491)  ; Log(value)
  %6495 = fmul fast float %6492, 0x4003333340000000
  %6496 = fmul fast float %6493, 0x4003333340000000
  %6497 = fmul fast float %6494, 0x4003333340000000
  %6498 = call float @dx.op.unary.f32(i32 21, float %6495)  ; Exp(value)
  %6499 = call float @dx.op.unary.f32(i32 21, float %6496)  ; Exp(value)
  %6500 = call float @dx.op.unary.f32(i32 21, float %6497)  ; Exp(value)
  %6501 = fsub fast float %6483, %6498
  %6502 = fsub fast float %6484, %6499
  %6503 = fsub fast float %6485, %6500
  %6504 = fmul fast float %6501, %6480
  %6505 = fmul fast float %6502, %6481
  %6506 = fmul fast float %6503, %6482
  %6507 = fadd fast float %6504, %6498
  %6508 = fadd fast float %6505, %6499
  %6509 = fadd fast float %6506, %6500
  br label %6673

; <label>:6510                                    ; preds = %6465
  %6511 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %6468, i32 %6469, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6512 = extractvalue %dx.types.ResRet.f32 %6511, 0
  %6513 = fcmp fast ogt float %39, 5.000000e-01
  %6514 = fcmp fast olt float %6512, 1.000000e+00
  %6515 = and i1 %6513, %6514
  br i1 %6515, label %6516, label %6602

; <label>:6516                                    ; preds = %6510
  %6517 = sitofp i32 %6468 to float
  %6518 = sitofp i32 %6469 to float
  %6519 = fadd fast float %6517, 5.000000e-01
  %6520 = fadd fast float %6518, 5.000000e-01
  %6521 = fdiv fast float %6519, %46
  %6522 = fdiv fast float %6520, %47
  %6523 = fmul fast float %6521, 2.000000e+00
  %6524 = fmul fast float %6522, 2.000000e+00
  %6525 = fadd fast float %6523, -1.000000e+00
  %6526 = fsub fast float 1.000000e+00, %6524
  %6527 = fmul fast float %6525, %36
  %6528 = call float @dx.op.tertiary.f32(i32 46, float %6526, float %32, float %6527)  ; FMad(a,b,c)
  %6529 = call float @dx.op.tertiary.f32(i32 46, float %6512, float %28, float %6528)  ; FMad(a,b,c)
  %6530 = fadd fast float %6529, %24
  %6531 = call float @dx.op.unary.f32(i32 6, float %6530)  ; FAbs(value)
  %6532 = fcmp fast ogt float %6531, 0x3EB0C6F7A0000000
  br i1 %6532, label %6533, label %6602

; <label>:6533                                    ; preds = %6516
  %6534 = fmul fast float %6525, %35
  %6535 = call float @dx.op.tertiary.f32(i32 46, float %6526, float %31, float %6534)  ; FMad(a,b,c)
  %6536 = call float @dx.op.tertiary.f32(i32 46, float %6512, float %27, float %6535)  ; FMad(a,b,c)
  %6537 = fadd fast float %6536, %23
  %6538 = fmul fast float %6525, %34
  %6539 = call float @dx.op.tertiary.f32(i32 46, float %6526, float %30, float %6538)  ; FMad(a,b,c)
  %6540 = call float @dx.op.tertiary.f32(i32 46, float %6512, float %26, float %6539)  ; FMad(a,b,c)
  %6541 = fadd fast float %6540, %22
  %6542 = fmul fast float %6525, %33
  %6543 = call float @dx.op.tertiary.f32(i32 46, float %6526, float %29, float %6542)  ; FMad(a,b,c)
  %6544 = call float @dx.op.tertiary.f32(i32 46, float %6512, float %25, float %6543)  ; FMad(a,b,c)
  %6545 = fadd fast float %6544, %21
  %6546 = fdiv fast float %6545, %6530
  %6547 = fdiv fast float %6541, %6530
  %6548 = fdiv fast float %6537, %6530
  %6549 = fsub fast float %6546, %18
  %6550 = fsub fast float %6547, %19
  %6551 = fsub fast float %6548, %20
  %6552 = fmul fast float %6549, %6549
  %6553 = fmul fast float %6550, %6550
  %6554 = fadd fast float %6553, %6552
  %6555 = fmul fast float %6551, %6551
  %6556 = fadd fast float %6554, %6555
  %6557 = call float @dx.op.unary.f32(i32 24, float %6556)  ; Sqrt(value)
  %6558 = fsub fast float %6557, %10
  %6559 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %6558)  ; FMax(a,b)
  %6560 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %6560, label %6561, label %6584

; <label>:6561                                    ; preds = %6533
  %6562 = call float @dx.op.unary.f32(i32 6, float %6550)  ; FAbs(value)
  %6563 = fmul fast float %6562, %12
  %6564 = fcmp fast olt float %6563, 0x3F50624DE0000000
  br i1 %6564, label %6565, label %6568

; <label>:6565                                    ; preds = %6561
  %6566 = fmul fast float %6563, 5.000000e-01
  %6567 = fsub fast float 1.000000e+00, %6566
  br label %6573

; <label>:6568                                    ; preds = %6561
  %6569 = fmul fast float %6563, 0xBFF7154760000000
  %6570 = call float @dx.op.unary.f32(i32 21, float %6569)  ; Exp(value)
  %6571 = fsub fast float 1.000000e+00, %6570
  %6572 = fdiv fast float %6571, %6563
  br label %6573

; <label>:6573                                    ; preds = %6568, %6565
  %6574 = phi float [ %6567, %6565 ], [ %6572, %6568 ]
  %6575 = call float @dx.op.binary.f32(i32 36, float %6547, float %19)  ; FMin(a,b)
  %6576 = fsub fast float %6575, %11
  %6577 = fmul fast float %12, %6576
  %6578 = fsub fast float -0.000000e+00, %6577
  %6579 = call float @dx.op.binary.f32(i32 35, float %6578, float -4.000000e+01)  ; FMax(a,b)
  %6580 = call float @dx.op.binary.f32(i32 36, float %6579, float 5.000000e+00)  ; FMin(a,b)
  %6581 = fmul fast float %6580, 0x3FF7154760000000
  %6582 = call float @dx.op.unary.f32(i32 21, float %6581)  ; Exp(value)
  %6583 = fmul fast float %6582, %6574
  br label %6584

; <label>:6584                                    ; preds = %6573, %6533
  %6585 = phi float [ %6583, %6573 ], [ 1.000000e+00, %6533 ]
  %6586 = fmul fast float %6559, %17
  %6587 = fmul fast float %6586, %6585
  %6588 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %6587)  ; FMin(a,b)
  %6589 = fmul fast float %6588, 0xBFF7154760000000
  %6590 = call float @dx.op.unary.f32(i32 21, float %6589)  ; Exp(value)
  %6591 = fsub fast float 1.000000e+00, %6590
  %6592 = call float @dx.op.binary.f32(i32 36, float %13, float %6591)  ; FMin(a,b)
  %6593 = fsub fast float %14, %6471
  %6594 = fsub fast float %15, %6472
  %6595 = fsub fast float %16, %6473
  %6596 = fmul fast float %6592, %6593
  %6597 = fmul fast float %6592, %6594
  %6598 = fmul fast float %6592, %6595
  %6599 = fadd fast float %6596, %6471
  %6600 = fadd fast float %6597, %6472
  %6601 = fadd fast float %6598, %6473
  br label %6602

; <label>:6602                                    ; preds = %6584, %6516, %6510
  %6603 = phi float [ %6599, %6584 ], [ %6471, %6516 ], [ %6471, %6510 ]
  %6604 = phi float [ %6600, %6584 ], [ %6472, %6516 ], [ %6472, %6510 ]
  %6605 = phi float [ %6601, %6584 ], [ %6473, %6516 ], [ %6473, %6510 ]
  %6606 = fadd fast float %6, 1.000000e+00
  %6607 = fadd fast float %7, 1.000000e+00
  %6608 = fsub fast float 1.000000e+00, %6
  %6609 = fmul fast float %37, %6606
  %6610 = fmul fast float %37, %6607
  %6611 = fmul fast float %37, %6608
  %6612 = fmul fast float %6609, %6603
  %6613 = fmul fast float %6610, %6604
  %6614 = fmul fast float %6611, %6605
  %6615 = fcmp fast ult float %38, 5.000000e-01
  br i1 %6615, label %6641, label %6616

; <label>:6616                                    ; preds = %6602
  %6617 = fmul fast float %6612, 0x4004147AE0000000
  %6618 = fmul fast float %6613, 0x4004147AE0000000
  %6619 = fmul fast float %6614, 0x4004147AE0000000
  %6620 = fadd fast float %6617, 0x3F9EB851E0000000
  %6621 = fadd fast float %6618, 0x3F9EB851E0000000
  %6622 = fadd fast float %6619, 0x3F9EB851E0000000
  %6623 = fmul fast float %6620, %6612
  %6624 = fmul fast float %6621, %6613
  %6625 = fmul fast float %6622, %6614
  %6626 = fmul fast float %6612, 0x400370A3E0000000
  %6627 = fmul fast float %6613, 0x400370A3E0000000
  %6628 = fmul fast float %6614, 0x400370A3E0000000
  %6629 = fadd fast float %6626, 0x3FE2E147A0000000
  %6630 = fadd fast float %6627, 0x3FE2E147A0000000
  %6631 = fadd fast float %6628, 0x3FE2E147A0000000
  %6632 = fmul fast float %6629, %6612
  %6633 = fmul fast float %6630, %6613
  %6634 = fmul fast float %6631, %6614
  %6635 = fadd fast float %6632, 0x3FC1EB8520000000
  %6636 = fadd fast float %6633, 0x3FC1EB8520000000
  %6637 = fadd fast float %6634, 0x3FC1EB8520000000
  %6638 = fdiv fast float %6623, %6635
  %6639 = fdiv fast float %6624, %6636
  %6640 = fdiv fast float %6625, %6637
  br label %6641

; <label>:6641                                    ; preds = %6616, %6602
  %6642 = phi float [ %6638, %6616 ], [ %6612, %6602 ]
  %6643 = phi float [ %6639, %6616 ], [ %6613, %6602 ]
  %6644 = phi float [ %6640, %6616 ], [ %6614, %6602 ]
  %6645 = call float @dx.op.unary.f32(i32 7, float %6642)  ; Saturate(value)
  %6646 = call float @dx.op.unary.f32(i32 7, float %6643)  ; Saturate(value)
  %6647 = call float @dx.op.unary.f32(i32 7, float %6644)  ; Saturate(value)
  %6648 = call float @dx.op.dot3.f32(i32 55, float %6645, float %6646, float %6647, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %6649 = fsub fast float %6645, %6648
  %6650 = fsub fast float %6646, %6648
  %6651 = fsub fast float %6647, %6648
  %6652 = fmul fast float %6649, %9
  %6653 = fmul fast float %6650, %9
  %6654 = fmul fast float %6651, %9
  %6655 = fadd fast float %6652, %6648
  %6656 = fadd fast float %6653, %6648
  %6657 = fadd fast float %6654, %6648
  %6658 = call float @dx.op.unary.f32(i32 7, float %6655)  ; Saturate(value)
  %6659 = call float @dx.op.unary.f32(i32 7, float %6656)  ; Saturate(value)
  %6660 = call float @dx.op.unary.f32(i32 7, float %6657)  ; Saturate(value)
  %6661 = fadd fast float %6658, 0xBFC70A3D80000000
  %6662 = fadd fast float %6659, 0xBFC70A3D80000000
  %6663 = fadd fast float %6660, 0xBFC70A3D80000000
  %6664 = fmul fast float %6661, %8
  %6665 = fmul fast float %6662, %8
  %6666 = fmul fast float %6663, %8
  %6667 = fadd fast float %6664, 0x3FC70A3D80000000
  %6668 = fadd fast float %6665, 0x3FC70A3D80000000
  %6669 = fadd fast float %6666, 0x3FC70A3D80000000
  %6670 = call float @dx.op.unary.f32(i32 7, float %6667)  ; Saturate(value)
  %6671 = call float @dx.op.unary.f32(i32 7, float %6668)  ; Saturate(value)
  %6672 = call float @dx.op.unary.f32(i32 7, float %6669)  ; Saturate(value)
  br label %6673

; <label>:6673                                    ; preds = %6641, %6476
  %6674 = phi float [ %6507, %6476 ], [ %6670, %6641 ]
  %6675 = phi float [ %6508, %6476 ], [ %6671, %6641 ]
  %6676 = phi float [ %6509, %6476 ], [ %6672, %6641 ]
  %6677 = fsub fast float %6674, %6208
  %6678 = fsub fast float %6675, %6209
  %6679 = fsub fast float %6676, %6210
  %6680 = fmul fast float %6677, %6463
  %6681 = fmul fast float %6678, %6463
  %6682 = fmul fast float %6679, %6463
  %6683 = fadd fast float %6680, %6208
  %6684 = fadd fast float %6681, %6209
  %6685 = fadd fast float %6682, %6210
  br label %6686

; <label>:6686                                    ; preds = %6673, %6450
  %6687 = phi float [ %6683, %6673 ], [ %6208, %6450 ]
  %6688 = phi float [ %6684, %6673 ], [ %6209, %6450 ]
  %6689 = phi float [ %6685, %6673 ], [ %6210, %6450 ]
  %6690 = add i32 %64, -1
  %6691 = call i32 @dx.op.binary.i32(i32 37, i32 %6690, i32 0)  ; IMax(a,b)
  %6692 = call i32 @dx.op.binary.i32(i32 37, i32 %71, i32 0)  ; IMax(a,b)
  %6693 = call i32 @dx.op.binary.i32(i32 38, i32 %6691, i32 %60)  ; IMin(a,b)
  %6694 = call i32 @dx.op.binary.i32(i32 38, i32 %6692, i32 %61)  ; IMin(a,b)
  %6695 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %6693, i32 %6694, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6696 = extractvalue %dx.types.ResRet.f32 %6695, 0
  %6697 = fsub fast float %6696, %87
  %6698 = call float @dx.op.unary.f32(i32 6, float %6697)  ; FAbs(value)
  %6699 = fdiv fast float %6698, %6222
  %6700 = fsub fast float 1.000000e+00, %6699
  %6701 = call float @dx.op.unary.f32(i32 7, float %6700)  ; Saturate(value)
  %6702 = fcmp fast ugt float %6701, 0.000000e+00
  br i1 %6702, label %6703, label %6924

; <label>:6703                                    ; preds = %6686
  %6704 = call i32 @dx.op.binary.i32(i32 37, i32 %6693, i32 0)  ; IMax(a,b)
  %6705 = call i32 @dx.op.binary.i32(i32 37, i32 %6694, i32 0)  ; IMax(a,b)
  %6706 = call i32 @dx.op.binary.i32(i32 38, i32 %6704, i32 %60)  ; IMin(a,b)
  %6707 = call i32 @dx.op.binary.i32(i32 38, i32 %6705, i32 %61)  ; IMin(a,b)
  %6708 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %6706, i32 %6707, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6709 = extractvalue %dx.types.ResRet.f32 %6708, 0
  %6710 = extractvalue %dx.types.ResRet.f32 %6708, 1
  %6711 = extractvalue %dx.types.ResRet.f32 %6708, 2
  %6712 = extractvalue %dx.types.ResRet.f32 %6708, 3
  %6713 = fcmp fast olt float %6712, 0.000000e+00
  br i1 %6713, label %6714, label %6748

; <label>:6714                                    ; preds = %6703
  %6715 = fcmp fast ogt float %6709, 0x3FA4B5DCC0000000
  %6716 = fcmp fast ogt float %6710, 0x3FA4B5DCC0000000
  %6717 = fcmp fast ogt float %6711, 0x3FA4B5DCC0000000
  %6718 = select i1 %6715, float 0.000000e+00, float 1.000000e+00
  %6719 = select i1 %6716, float 0.000000e+00, float 1.000000e+00
  %6720 = select i1 %6717, float 0.000000e+00, float 1.000000e+00
  %6721 = fmul fast float %6709, 0x3FB3D07220000000
  %6722 = fmul fast float %6710, 0x3FB3D07220000000
  %6723 = fmul fast float %6711, 0x3FB3D07220000000
  %6724 = fadd fast float %6709, 0x3FAC28F5C0000000
  %6725 = fadd fast float %6710, 0x3FAC28F5C0000000
  %6726 = fadd fast float %6711, 0x3FAC28F5C0000000
  %6727 = fmul fast float %6724, 0x3FEE54EDE0000000
  %6728 = fmul fast float %6725, 0x3FEE54EDE0000000
  %6729 = fmul fast float %6726, 0x3FEE54EDE0000000
  %6730 = call float @dx.op.unary.f32(i32 23, float %6727)  ; Log(value)
  %6731 = call float @dx.op.unary.f32(i32 23, float %6728)  ; Log(value)
  %6732 = call float @dx.op.unary.f32(i32 23, float %6729)  ; Log(value)
  %6733 = fmul fast float %6730, 0x4003333340000000
  %6734 = fmul fast float %6731, 0x4003333340000000
  %6735 = fmul fast float %6732, 0x4003333340000000
  %6736 = call float @dx.op.unary.f32(i32 21, float %6733)  ; Exp(value)
  %6737 = call float @dx.op.unary.f32(i32 21, float %6734)  ; Exp(value)
  %6738 = call float @dx.op.unary.f32(i32 21, float %6735)  ; Exp(value)
  %6739 = fsub fast float %6721, %6736
  %6740 = fsub fast float %6722, %6737
  %6741 = fsub fast float %6723, %6738
  %6742 = fmul fast float %6739, %6718
  %6743 = fmul fast float %6740, %6719
  %6744 = fmul fast float %6741, %6720
  %6745 = fadd fast float %6742, %6736
  %6746 = fadd fast float %6743, %6737
  %6747 = fadd fast float %6744, %6738
  br label %6911

; <label>:6748                                    ; preds = %6703
  %6749 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %6706, i32 %6707, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6750 = extractvalue %dx.types.ResRet.f32 %6749, 0
  %6751 = fcmp fast ogt float %39, 5.000000e-01
  %6752 = fcmp fast olt float %6750, 1.000000e+00
  %6753 = and i1 %6751, %6752
  br i1 %6753, label %6754, label %6840

; <label>:6754                                    ; preds = %6748
  %6755 = sitofp i32 %6706 to float
  %6756 = sitofp i32 %6707 to float
  %6757 = fadd fast float %6755, 5.000000e-01
  %6758 = fadd fast float %6756, 5.000000e-01
  %6759 = fdiv fast float %6757, %46
  %6760 = fdiv fast float %6758, %47
  %6761 = fmul fast float %6759, 2.000000e+00
  %6762 = fmul fast float %6760, 2.000000e+00
  %6763 = fadd fast float %6761, -1.000000e+00
  %6764 = fsub fast float 1.000000e+00, %6762
  %6765 = fmul fast float %6763, %36
  %6766 = call float @dx.op.tertiary.f32(i32 46, float %6764, float %32, float %6765)  ; FMad(a,b,c)
  %6767 = call float @dx.op.tertiary.f32(i32 46, float %6750, float %28, float %6766)  ; FMad(a,b,c)
  %6768 = fadd fast float %6767, %24
  %6769 = call float @dx.op.unary.f32(i32 6, float %6768)  ; FAbs(value)
  %6770 = fcmp fast ogt float %6769, 0x3EB0C6F7A0000000
  br i1 %6770, label %6771, label %6840

; <label>:6771                                    ; preds = %6754
  %6772 = fmul fast float %6763, %35
  %6773 = call float @dx.op.tertiary.f32(i32 46, float %6764, float %31, float %6772)  ; FMad(a,b,c)
  %6774 = call float @dx.op.tertiary.f32(i32 46, float %6750, float %27, float %6773)  ; FMad(a,b,c)
  %6775 = fadd fast float %6774, %23
  %6776 = fmul fast float %6763, %34
  %6777 = call float @dx.op.tertiary.f32(i32 46, float %6764, float %30, float %6776)  ; FMad(a,b,c)
  %6778 = call float @dx.op.tertiary.f32(i32 46, float %6750, float %26, float %6777)  ; FMad(a,b,c)
  %6779 = fadd fast float %6778, %22
  %6780 = fmul fast float %6763, %33
  %6781 = call float @dx.op.tertiary.f32(i32 46, float %6764, float %29, float %6780)  ; FMad(a,b,c)
  %6782 = call float @dx.op.tertiary.f32(i32 46, float %6750, float %25, float %6781)  ; FMad(a,b,c)
  %6783 = fadd fast float %6782, %21
  %6784 = fdiv fast float %6783, %6768
  %6785 = fdiv fast float %6779, %6768
  %6786 = fdiv fast float %6775, %6768
  %6787 = fsub fast float %6784, %18
  %6788 = fsub fast float %6785, %19
  %6789 = fsub fast float %6786, %20
  %6790 = fmul fast float %6787, %6787
  %6791 = fmul fast float %6788, %6788
  %6792 = fadd fast float %6791, %6790
  %6793 = fmul fast float %6789, %6789
  %6794 = fadd fast float %6792, %6793
  %6795 = call float @dx.op.unary.f32(i32 24, float %6794)  ; Sqrt(value)
  %6796 = fsub fast float %6795, %10
  %6797 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %6796)  ; FMax(a,b)
  %6798 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %6798, label %6799, label %6822

; <label>:6799                                    ; preds = %6771
  %6800 = call float @dx.op.unary.f32(i32 6, float %6788)  ; FAbs(value)
  %6801 = fmul fast float %6800, %12
  %6802 = fcmp fast olt float %6801, 0x3F50624DE0000000
  br i1 %6802, label %6803, label %6806

; <label>:6803                                    ; preds = %6799
  %6804 = fmul fast float %6801, 5.000000e-01
  %6805 = fsub fast float 1.000000e+00, %6804
  br label %6811

; <label>:6806                                    ; preds = %6799
  %6807 = fmul fast float %6801, 0xBFF7154760000000
  %6808 = call float @dx.op.unary.f32(i32 21, float %6807)  ; Exp(value)
  %6809 = fsub fast float 1.000000e+00, %6808
  %6810 = fdiv fast float %6809, %6801
  br label %6811

; <label>:6811                                    ; preds = %6806, %6803
  %6812 = phi float [ %6805, %6803 ], [ %6810, %6806 ]
  %6813 = call float @dx.op.binary.f32(i32 36, float %6785, float %19)  ; FMin(a,b)
  %6814 = fsub fast float %6813, %11
  %6815 = fmul fast float %12, %6814
  %6816 = fsub fast float -0.000000e+00, %6815
  %6817 = call float @dx.op.binary.f32(i32 35, float %6816, float -4.000000e+01)  ; FMax(a,b)
  %6818 = call float @dx.op.binary.f32(i32 36, float %6817, float 5.000000e+00)  ; FMin(a,b)
  %6819 = fmul fast float %6818, 0x3FF7154760000000
  %6820 = call float @dx.op.unary.f32(i32 21, float %6819)  ; Exp(value)
  %6821 = fmul fast float %6820, %6812
  br label %6822

; <label>:6822                                    ; preds = %6811, %6771
  %6823 = phi float [ %6821, %6811 ], [ 1.000000e+00, %6771 ]
  %6824 = fmul fast float %6797, %17
  %6825 = fmul fast float %6824, %6823
  %6826 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %6825)  ; FMin(a,b)
  %6827 = fmul fast float %6826, 0xBFF7154760000000
  %6828 = call float @dx.op.unary.f32(i32 21, float %6827)  ; Exp(value)
  %6829 = fsub fast float 1.000000e+00, %6828
  %6830 = call float @dx.op.binary.f32(i32 36, float %13, float %6829)  ; FMin(a,b)
  %6831 = fsub fast float %14, %6709
  %6832 = fsub fast float %15, %6710
  %6833 = fsub fast float %16, %6711
  %6834 = fmul fast float %6830, %6831
  %6835 = fmul fast float %6830, %6832
  %6836 = fmul fast float %6830, %6833
  %6837 = fadd fast float %6834, %6709
  %6838 = fadd fast float %6835, %6710
  %6839 = fadd fast float %6836, %6711
  br label %6840

; <label>:6840                                    ; preds = %6822, %6754, %6748
  %6841 = phi float [ %6837, %6822 ], [ %6709, %6754 ], [ %6709, %6748 ]
  %6842 = phi float [ %6838, %6822 ], [ %6710, %6754 ], [ %6710, %6748 ]
  %6843 = phi float [ %6839, %6822 ], [ %6711, %6754 ], [ %6711, %6748 ]
  %6844 = fadd fast float %6, 1.000000e+00
  %6845 = fadd fast float %7, 1.000000e+00
  %6846 = fsub fast float 1.000000e+00, %6
  %6847 = fmul fast float %37, %6844
  %6848 = fmul fast float %37, %6845
  %6849 = fmul fast float %37, %6846
  %6850 = fmul fast float %6847, %6841
  %6851 = fmul fast float %6848, %6842
  %6852 = fmul fast float %6849, %6843
  %6853 = fcmp fast ult float %38, 5.000000e-01
  br i1 %6853, label %6879, label %6854

; <label>:6854                                    ; preds = %6840
  %6855 = fmul fast float %6850, 0x4004147AE0000000
  %6856 = fmul fast float %6851, 0x4004147AE0000000
  %6857 = fmul fast float %6852, 0x4004147AE0000000
  %6858 = fadd fast float %6855, 0x3F9EB851E0000000
  %6859 = fadd fast float %6856, 0x3F9EB851E0000000
  %6860 = fadd fast float %6857, 0x3F9EB851E0000000
  %6861 = fmul fast float %6858, %6850
  %6862 = fmul fast float %6859, %6851
  %6863 = fmul fast float %6860, %6852
  %6864 = fmul fast float %6850, 0x400370A3E0000000
  %6865 = fmul fast float %6851, 0x400370A3E0000000
  %6866 = fmul fast float %6852, 0x400370A3E0000000
  %6867 = fadd fast float %6864, 0x3FE2E147A0000000
  %6868 = fadd fast float %6865, 0x3FE2E147A0000000
  %6869 = fadd fast float %6866, 0x3FE2E147A0000000
  %6870 = fmul fast float %6867, %6850
  %6871 = fmul fast float %6868, %6851
  %6872 = fmul fast float %6869, %6852
  %6873 = fadd fast float %6870, 0x3FC1EB8520000000
  %6874 = fadd fast float %6871, 0x3FC1EB8520000000
  %6875 = fadd fast float %6872, 0x3FC1EB8520000000
  %6876 = fdiv fast float %6861, %6873
  %6877 = fdiv fast float %6862, %6874
  %6878 = fdiv fast float %6863, %6875
  br label %6879

; <label>:6879                                    ; preds = %6854, %6840
  %6880 = phi float [ %6876, %6854 ], [ %6850, %6840 ]
  %6881 = phi float [ %6877, %6854 ], [ %6851, %6840 ]
  %6882 = phi float [ %6878, %6854 ], [ %6852, %6840 ]
  %6883 = call float @dx.op.unary.f32(i32 7, float %6880)  ; Saturate(value)
  %6884 = call float @dx.op.unary.f32(i32 7, float %6881)  ; Saturate(value)
  %6885 = call float @dx.op.unary.f32(i32 7, float %6882)  ; Saturate(value)
  %6886 = call float @dx.op.dot3.f32(i32 55, float %6883, float %6884, float %6885, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %6887 = fsub fast float %6883, %6886
  %6888 = fsub fast float %6884, %6886
  %6889 = fsub fast float %6885, %6886
  %6890 = fmul fast float %6887, %9
  %6891 = fmul fast float %6888, %9
  %6892 = fmul fast float %6889, %9
  %6893 = fadd fast float %6890, %6886
  %6894 = fadd fast float %6891, %6886
  %6895 = fadd fast float %6892, %6886
  %6896 = call float @dx.op.unary.f32(i32 7, float %6893)  ; Saturate(value)
  %6897 = call float @dx.op.unary.f32(i32 7, float %6894)  ; Saturate(value)
  %6898 = call float @dx.op.unary.f32(i32 7, float %6895)  ; Saturate(value)
  %6899 = fadd fast float %6896, 0xBFC70A3D80000000
  %6900 = fadd fast float %6897, 0xBFC70A3D80000000
  %6901 = fadd fast float %6898, 0xBFC70A3D80000000
  %6902 = fmul fast float %6899, %8
  %6903 = fmul fast float %6900, %8
  %6904 = fmul fast float %6901, %8
  %6905 = fadd fast float %6902, 0x3FC70A3D80000000
  %6906 = fadd fast float %6903, 0x3FC70A3D80000000
  %6907 = fadd fast float %6904, 0x3FC70A3D80000000
  %6908 = call float @dx.op.unary.f32(i32 7, float %6905)  ; Saturate(value)
  %6909 = call float @dx.op.unary.f32(i32 7, float %6906)  ; Saturate(value)
  %6910 = call float @dx.op.unary.f32(i32 7, float %6907)  ; Saturate(value)
  br label %6911

; <label>:6911                                    ; preds = %6879, %6714
  %6912 = phi float [ %6745, %6714 ], [ %6908, %6879 ]
  %6913 = phi float [ %6746, %6714 ], [ %6909, %6879 ]
  %6914 = phi float [ %6747, %6714 ], [ %6910, %6879 ]
  %6915 = fsub fast float %6912, %6208
  %6916 = fsub fast float %6913, %6209
  %6917 = fsub fast float %6914, %6210
  %6918 = fmul fast float %6915, %6701
  %6919 = fmul fast float %6916, %6701
  %6920 = fmul fast float %6917, %6701
  %6921 = fadd fast float %6918, %6208
  %6922 = fadd fast float %6919, %6209
  %6923 = fadd fast float %6920, %6210
  br label %6924

; <label>:6924                                    ; preds = %6911, %6686
  %6925 = phi float [ %6921, %6911 ], [ %6208, %6686 ]
  %6926 = phi float [ %6922, %6911 ], [ %6209, %6686 ]
  %6927 = phi float [ %6923, %6911 ], [ %6210, %6686 ]
  %6928 = add i32 %64, 1
  %6929 = call i32 @dx.op.binary.i32(i32 37, i32 %6928, i32 0)  ; IMax(a,b)
  %6930 = call i32 @dx.op.binary.i32(i32 38, i32 %6929, i32 %60)  ; IMin(a,b)
  %6931 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %6930, i32 %6694, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6932 = extractvalue %dx.types.ResRet.f32 %6931, 0
  %6933 = fsub fast float %6932, %87
  %6934 = call float @dx.op.unary.f32(i32 6, float %6933)  ; FAbs(value)
  %6935 = fdiv fast float %6934, %6222
  %6936 = fsub fast float 1.000000e+00, %6935
  %6937 = call float @dx.op.unary.f32(i32 7, float %6936)  ; Saturate(value)
  %6938 = fcmp fast ugt float %6937, 0.000000e+00
  br i1 %6938, label %6939, label %7160

; <label>:6939                                    ; preds = %6924
  %6940 = call i32 @dx.op.binary.i32(i32 37, i32 %6930, i32 0)  ; IMax(a,b)
  %6941 = call i32 @dx.op.binary.i32(i32 37, i32 %6694, i32 0)  ; IMax(a,b)
  %6942 = call i32 @dx.op.binary.i32(i32 38, i32 %6940, i32 %60)  ; IMin(a,b)
  %6943 = call i32 @dx.op.binary.i32(i32 38, i32 %6941, i32 %61)  ; IMin(a,b)
  %6944 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %6942, i32 %6943, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6945 = extractvalue %dx.types.ResRet.f32 %6944, 0
  %6946 = extractvalue %dx.types.ResRet.f32 %6944, 1
  %6947 = extractvalue %dx.types.ResRet.f32 %6944, 2
  %6948 = extractvalue %dx.types.ResRet.f32 %6944, 3
  %6949 = fcmp fast olt float %6948, 0.000000e+00
  br i1 %6949, label %6950, label %6984

; <label>:6950                                    ; preds = %6939
  %6951 = fcmp fast ogt float %6945, 0x3FA4B5DCC0000000
  %6952 = fcmp fast ogt float %6946, 0x3FA4B5DCC0000000
  %6953 = fcmp fast ogt float %6947, 0x3FA4B5DCC0000000
  %6954 = select i1 %6951, float 0.000000e+00, float 1.000000e+00
  %6955 = select i1 %6952, float 0.000000e+00, float 1.000000e+00
  %6956 = select i1 %6953, float 0.000000e+00, float 1.000000e+00
  %6957 = fmul fast float %6945, 0x3FB3D07220000000
  %6958 = fmul fast float %6946, 0x3FB3D07220000000
  %6959 = fmul fast float %6947, 0x3FB3D07220000000
  %6960 = fadd fast float %6945, 0x3FAC28F5C0000000
  %6961 = fadd fast float %6946, 0x3FAC28F5C0000000
  %6962 = fadd fast float %6947, 0x3FAC28F5C0000000
  %6963 = fmul fast float %6960, 0x3FEE54EDE0000000
  %6964 = fmul fast float %6961, 0x3FEE54EDE0000000
  %6965 = fmul fast float %6962, 0x3FEE54EDE0000000
  %6966 = call float @dx.op.unary.f32(i32 23, float %6963)  ; Log(value)
  %6967 = call float @dx.op.unary.f32(i32 23, float %6964)  ; Log(value)
  %6968 = call float @dx.op.unary.f32(i32 23, float %6965)  ; Log(value)
  %6969 = fmul fast float %6966, 0x4003333340000000
  %6970 = fmul fast float %6967, 0x4003333340000000
  %6971 = fmul fast float %6968, 0x4003333340000000
  %6972 = call float @dx.op.unary.f32(i32 21, float %6969)  ; Exp(value)
  %6973 = call float @dx.op.unary.f32(i32 21, float %6970)  ; Exp(value)
  %6974 = call float @dx.op.unary.f32(i32 21, float %6971)  ; Exp(value)
  %6975 = fsub fast float %6957, %6972
  %6976 = fsub fast float %6958, %6973
  %6977 = fsub fast float %6959, %6974
  %6978 = fmul fast float %6975, %6954
  %6979 = fmul fast float %6976, %6955
  %6980 = fmul fast float %6977, %6956
  %6981 = fadd fast float %6978, %6972
  %6982 = fadd fast float %6979, %6973
  %6983 = fadd fast float %6980, %6974
  br label %7147

; <label>:6984                                    ; preds = %6939
  %6985 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %6942, i32 %6943, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6986 = extractvalue %dx.types.ResRet.f32 %6985, 0
  %6987 = fcmp fast ogt float %39, 5.000000e-01
  %6988 = fcmp fast olt float %6986, 1.000000e+00
  %6989 = and i1 %6987, %6988
  br i1 %6989, label %6990, label %7076

; <label>:6990                                    ; preds = %6984
  %6991 = sitofp i32 %6942 to float
  %6992 = sitofp i32 %6943 to float
  %6993 = fadd fast float %6991, 5.000000e-01
  %6994 = fadd fast float %6992, 5.000000e-01
  %6995 = fdiv fast float %6993, %46
  %6996 = fdiv fast float %6994, %47
  %6997 = fmul fast float %6995, 2.000000e+00
  %6998 = fmul fast float %6996, 2.000000e+00
  %6999 = fadd fast float %6997, -1.000000e+00
  %7000 = fsub fast float 1.000000e+00, %6998
  %7001 = fmul fast float %6999, %36
  %7002 = call float @dx.op.tertiary.f32(i32 46, float %7000, float %32, float %7001)  ; FMad(a,b,c)
  %7003 = call float @dx.op.tertiary.f32(i32 46, float %6986, float %28, float %7002)  ; FMad(a,b,c)
  %7004 = fadd fast float %7003, %24
  %7005 = call float @dx.op.unary.f32(i32 6, float %7004)  ; FAbs(value)
  %7006 = fcmp fast ogt float %7005, 0x3EB0C6F7A0000000
  br i1 %7006, label %7007, label %7076

; <label>:7007                                    ; preds = %6990
  %7008 = fmul fast float %6999, %35
  %7009 = call float @dx.op.tertiary.f32(i32 46, float %7000, float %31, float %7008)  ; FMad(a,b,c)
  %7010 = call float @dx.op.tertiary.f32(i32 46, float %6986, float %27, float %7009)  ; FMad(a,b,c)
  %7011 = fadd fast float %7010, %23
  %7012 = fmul fast float %6999, %34
  %7013 = call float @dx.op.tertiary.f32(i32 46, float %7000, float %30, float %7012)  ; FMad(a,b,c)
  %7014 = call float @dx.op.tertiary.f32(i32 46, float %6986, float %26, float %7013)  ; FMad(a,b,c)
  %7015 = fadd fast float %7014, %22
  %7016 = fmul fast float %6999, %33
  %7017 = call float @dx.op.tertiary.f32(i32 46, float %7000, float %29, float %7016)  ; FMad(a,b,c)
  %7018 = call float @dx.op.tertiary.f32(i32 46, float %6986, float %25, float %7017)  ; FMad(a,b,c)
  %7019 = fadd fast float %7018, %21
  %7020 = fdiv fast float %7019, %7004
  %7021 = fdiv fast float %7015, %7004
  %7022 = fdiv fast float %7011, %7004
  %7023 = fsub fast float %7020, %18
  %7024 = fsub fast float %7021, %19
  %7025 = fsub fast float %7022, %20
  %7026 = fmul fast float %7023, %7023
  %7027 = fmul fast float %7024, %7024
  %7028 = fadd fast float %7027, %7026
  %7029 = fmul fast float %7025, %7025
  %7030 = fadd fast float %7028, %7029
  %7031 = call float @dx.op.unary.f32(i32 24, float %7030)  ; Sqrt(value)
  %7032 = fsub fast float %7031, %10
  %7033 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %7032)  ; FMax(a,b)
  %7034 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %7034, label %7035, label %7058

; <label>:7035                                    ; preds = %7007
  %7036 = call float @dx.op.unary.f32(i32 6, float %7024)  ; FAbs(value)
  %7037 = fmul fast float %7036, %12
  %7038 = fcmp fast olt float %7037, 0x3F50624DE0000000
  br i1 %7038, label %7039, label %7042

; <label>:7039                                    ; preds = %7035
  %7040 = fmul fast float %7037, 5.000000e-01
  %7041 = fsub fast float 1.000000e+00, %7040
  br label %7047

; <label>:7042                                    ; preds = %7035
  %7043 = fmul fast float %7037, 0xBFF7154760000000
  %7044 = call float @dx.op.unary.f32(i32 21, float %7043)  ; Exp(value)
  %7045 = fsub fast float 1.000000e+00, %7044
  %7046 = fdiv fast float %7045, %7037
  br label %7047

; <label>:7047                                    ; preds = %7042, %7039
  %7048 = phi float [ %7041, %7039 ], [ %7046, %7042 ]
  %7049 = call float @dx.op.binary.f32(i32 36, float %7021, float %19)  ; FMin(a,b)
  %7050 = fsub fast float %7049, %11
  %7051 = fmul fast float %12, %7050
  %7052 = fsub fast float -0.000000e+00, %7051
  %7053 = call float @dx.op.binary.f32(i32 35, float %7052, float -4.000000e+01)  ; FMax(a,b)
  %7054 = call float @dx.op.binary.f32(i32 36, float %7053, float 5.000000e+00)  ; FMin(a,b)
  %7055 = fmul fast float %7054, 0x3FF7154760000000
  %7056 = call float @dx.op.unary.f32(i32 21, float %7055)  ; Exp(value)
  %7057 = fmul fast float %7056, %7048
  br label %7058

; <label>:7058                                    ; preds = %7047, %7007
  %7059 = phi float [ %7057, %7047 ], [ 1.000000e+00, %7007 ]
  %7060 = fmul fast float %7033, %17
  %7061 = fmul fast float %7060, %7059
  %7062 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %7061)  ; FMin(a,b)
  %7063 = fmul fast float %7062, 0xBFF7154760000000
  %7064 = call float @dx.op.unary.f32(i32 21, float %7063)  ; Exp(value)
  %7065 = fsub fast float 1.000000e+00, %7064
  %7066 = call float @dx.op.binary.f32(i32 36, float %13, float %7065)  ; FMin(a,b)
  %7067 = fsub fast float %14, %6945
  %7068 = fsub fast float %15, %6946
  %7069 = fsub fast float %16, %6947
  %7070 = fmul fast float %7066, %7067
  %7071 = fmul fast float %7066, %7068
  %7072 = fmul fast float %7066, %7069
  %7073 = fadd fast float %7070, %6945
  %7074 = fadd fast float %7071, %6946
  %7075 = fadd fast float %7072, %6947
  br label %7076

; <label>:7076                                    ; preds = %7058, %6990, %6984
  %7077 = phi float [ %7073, %7058 ], [ %6945, %6990 ], [ %6945, %6984 ]
  %7078 = phi float [ %7074, %7058 ], [ %6946, %6990 ], [ %6946, %6984 ]
  %7079 = phi float [ %7075, %7058 ], [ %6947, %6990 ], [ %6947, %6984 ]
  %7080 = fadd fast float %6, 1.000000e+00
  %7081 = fadd fast float %7, 1.000000e+00
  %7082 = fsub fast float 1.000000e+00, %6
  %7083 = fmul fast float %37, %7080
  %7084 = fmul fast float %37, %7081
  %7085 = fmul fast float %37, %7082
  %7086 = fmul fast float %7083, %7077
  %7087 = fmul fast float %7084, %7078
  %7088 = fmul fast float %7085, %7079
  %7089 = fcmp fast ult float %38, 5.000000e-01
  br i1 %7089, label %7115, label %7090

; <label>:7090                                    ; preds = %7076
  %7091 = fmul fast float %7086, 0x4004147AE0000000
  %7092 = fmul fast float %7087, 0x4004147AE0000000
  %7093 = fmul fast float %7088, 0x4004147AE0000000
  %7094 = fadd fast float %7091, 0x3F9EB851E0000000
  %7095 = fadd fast float %7092, 0x3F9EB851E0000000
  %7096 = fadd fast float %7093, 0x3F9EB851E0000000
  %7097 = fmul fast float %7094, %7086
  %7098 = fmul fast float %7095, %7087
  %7099 = fmul fast float %7096, %7088
  %7100 = fmul fast float %7086, 0x400370A3E0000000
  %7101 = fmul fast float %7087, 0x400370A3E0000000
  %7102 = fmul fast float %7088, 0x400370A3E0000000
  %7103 = fadd fast float %7100, 0x3FE2E147A0000000
  %7104 = fadd fast float %7101, 0x3FE2E147A0000000
  %7105 = fadd fast float %7102, 0x3FE2E147A0000000
  %7106 = fmul fast float %7103, %7086
  %7107 = fmul fast float %7104, %7087
  %7108 = fmul fast float %7105, %7088
  %7109 = fadd fast float %7106, 0x3FC1EB8520000000
  %7110 = fadd fast float %7107, 0x3FC1EB8520000000
  %7111 = fadd fast float %7108, 0x3FC1EB8520000000
  %7112 = fdiv fast float %7097, %7109
  %7113 = fdiv fast float %7098, %7110
  %7114 = fdiv fast float %7099, %7111
  br label %7115

; <label>:7115                                    ; preds = %7090, %7076
  %7116 = phi float [ %7112, %7090 ], [ %7086, %7076 ]
  %7117 = phi float [ %7113, %7090 ], [ %7087, %7076 ]
  %7118 = phi float [ %7114, %7090 ], [ %7088, %7076 ]
  %7119 = call float @dx.op.unary.f32(i32 7, float %7116)  ; Saturate(value)
  %7120 = call float @dx.op.unary.f32(i32 7, float %7117)  ; Saturate(value)
  %7121 = call float @dx.op.unary.f32(i32 7, float %7118)  ; Saturate(value)
  %7122 = call float @dx.op.dot3.f32(i32 55, float %7119, float %7120, float %7121, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %7123 = fsub fast float %7119, %7122
  %7124 = fsub fast float %7120, %7122
  %7125 = fsub fast float %7121, %7122
  %7126 = fmul fast float %7123, %9
  %7127 = fmul fast float %7124, %9
  %7128 = fmul fast float %7125, %9
  %7129 = fadd fast float %7126, %7122
  %7130 = fadd fast float %7127, %7122
  %7131 = fadd fast float %7128, %7122
  %7132 = call float @dx.op.unary.f32(i32 7, float %7129)  ; Saturate(value)
  %7133 = call float @dx.op.unary.f32(i32 7, float %7130)  ; Saturate(value)
  %7134 = call float @dx.op.unary.f32(i32 7, float %7131)  ; Saturate(value)
  %7135 = fadd fast float %7132, 0xBFC70A3D80000000
  %7136 = fadd fast float %7133, 0xBFC70A3D80000000
  %7137 = fadd fast float %7134, 0xBFC70A3D80000000
  %7138 = fmul fast float %7135, %8
  %7139 = fmul fast float %7136, %8
  %7140 = fmul fast float %7137, %8
  %7141 = fadd fast float %7138, 0x3FC70A3D80000000
  %7142 = fadd fast float %7139, 0x3FC70A3D80000000
  %7143 = fadd fast float %7140, 0x3FC70A3D80000000
  %7144 = call float @dx.op.unary.f32(i32 7, float %7141)  ; Saturate(value)
  %7145 = call float @dx.op.unary.f32(i32 7, float %7142)  ; Saturate(value)
  %7146 = call float @dx.op.unary.f32(i32 7, float %7143)  ; Saturate(value)
  br label %7147

; <label>:7147                                    ; preds = %7115, %6950
  %7148 = phi float [ %6981, %6950 ], [ %7144, %7115 ]
  %7149 = phi float [ %6982, %6950 ], [ %7145, %7115 ]
  %7150 = phi float [ %6983, %6950 ], [ %7146, %7115 ]
  %7151 = fsub fast float %7148, %6208
  %7152 = fsub fast float %7149, %6209
  %7153 = fsub fast float %7150, %6210
  %7154 = fmul fast float %7151, %6937
  %7155 = fmul fast float %7152, %6937
  %7156 = fmul fast float %7153, %6937
  %7157 = fadd fast float %7154, %6208
  %7158 = fadd fast float %7155, %6209
  %7159 = fadd fast float %7156, %6210
  br label %7160

; <label>:7160                                    ; preds = %7147, %6924
  %7161 = phi float [ %7157, %7147 ], [ %6208, %6924 ]
  %7162 = phi float [ %7158, %7147 ], [ %6209, %6924 ]
  %7163 = phi float [ %7159, %7147 ], [ %6210, %6924 ]
  %7164 = call float @dx.op.binary.f32(i32 36, float %6925, float %7161)  ; FMin(a,b)
  %7165 = call float @dx.op.binary.f32(i32 36, float %6926, float %7162)  ; FMin(a,b)
  %7166 = call float @dx.op.binary.f32(i32 36, float %6927, float %7163)  ; FMin(a,b)
  %7167 = call float @dx.op.binary.f32(i32 36, float %6451, float %6687)  ; FMin(a,b)
  %7168 = call float @dx.op.binary.f32(i32 36, float %6452, float %6688)  ; FMin(a,b)
  %7169 = call float @dx.op.binary.f32(i32 36, float %6453, float %6689)  ; FMin(a,b)
  %7170 = call float @dx.op.binary.f32(i32 36, float %7167, float %7164)  ; FMin(a,b)
  %7171 = call float @dx.op.binary.f32(i32 36, float %7168, float %7165)  ; FMin(a,b)
  %7172 = call float @dx.op.binary.f32(i32 36, float %7169, float %7166)  ; FMin(a,b)
  %7173 = call float @dx.op.binary.f32(i32 36, float %6208, float %7170)  ; FMin(a,b)
  %7174 = call float @dx.op.binary.f32(i32 36, float %6209, float %7171)  ; FMin(a,b)
  %7175 = call float @dx.op.binary.f32(i32 36, float %6210, float %7172)  ; FMin(a,b)
  %7176 = call float @dx.op.binary.f32(i32 35, float %6925, float %7161)  ; FMax(a,b)
  %7177 = call float @dx.op.binary.f32(i32 35, float %6926, float %7162)  ; FMax(a,b)
  %7178 = call float @dx.op.binary.f32(i32 35, float %6927, float %7163)  ; FMax(a,b)
  %7179 = call float @dx.op.binary.f32(i32 35, float %6451, float %6687)  ; FMax(a,b)
  %7180 = call float @dx.op.binary.f32(i32 35, float %6452, float %6688)  ; FMax(a,b)
  %7181 = call float @dx.op.binary.f32(i32 35, float %6453, float %6689)  ; FMax(a,b)
  %7182 = call float @dx.op.binary.f32(i32 35, float %7179, float %7176)  ; FMax(a,b)
  %7183 = call float @dx.op.binary.f32(i32 35, float %7180, float %7177)  ; FMax(a,b)
  %7184 = call float @dx.op.binary.f32(i32 35, float %7181, float %7178)  ; FMax(a,b)
  %7185 = call float @dx.op.binary.f32(i32 35, float %6208, float %7182)  ; FMax(a,b)
  %7186 = call float @dx.op.binary.f32(i32 35, float %6209, float %7183)  ; FMax(a,b)
  %7187 = call float @dx.op.binary.f32(i32 35, float %6210, float %7184)  ; FMax(a,b)
  %7188 = fsub fast float %7185, %7173
  %7189 = fsub fast float %7186, %7174
  %7190 = fsub fast float %7187, %7175
  %7191 = call float @dx.op.unary.f32(i32 6, float %7188)  ; FAbs(value)
  %7192 = call float @dx.op.unary.f32(i32 6, float %7189)  ; FAbs(value)
  %7193 = call float @dx.op.unary.f32(i32 6, float %7190)  ; FAbs(value)
  %7194 = call float @dx.op.binary.f32(i32 35, float %7192, float %7193)  ; FMax(a,b)
  %7195 = call float @dx.op.binary.f32(i32 35, float %7191, float %7194)  ; FMax(a,b)
  %7196 = call float @dx.op.binary.f32(i32 35, float %7186, float %7187)  ; FMax(a,b)
  %7197 = call float @dx.op.binary.f32(i32 35, float %7185, float %7196)  ; FMax(a,b)
  %7198 = fmul fast float %7197, 1.250000e-01
  %7199 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %7198)  ; FMax(a,b)
  %7200 = fcmp fast ogt float %7195, %7199
  br i1 %7200, label %7201, label %7263

; <label>:7201                                    ; preds = %7160
  %7202 = fsub fast float %6451, %6687
  %7203 = fsub fast float %6452, %6688
  %7204 = fsub fast float %6453, %6689
  %7205 = call float @dx.op.unary.f32(i32 6, float %7202)  ; FAbs(value)
  %7206 = call float @dx.op.unary.f32(i32 6, float %7203)  ; FAbs(value)
  %7207 = call float @dx.op.unary.f32(i32 6, float %7204)  ; FAbs(value)
  %7208 = call float @dx.op.binary.f32(i32 35, float %7206, float %7207)  ; FMax(a,b)
  %7209 = call float @dx.op.binary.f32(i32 35, float %7205, float %7208)  ; FMax(a,b)
  %7210 = fsub fast float %6925, %7161
  %7211 = fsub fast float %6926, %7162
  %7212 = fsub fast float %6927, %7163
  %7213 = call float @dx.op.unary.f32(i32 6, float %7210)  ; FAbs(value)
  %7214 = call float @dx.op.unary.f32(i32 6, float %7211)  ; FAbs(value)
  %7215 = call float @dx.op.unary.f32(i32 6, float %7212)  ; FAbs(value)
  %7216 = call float @dx.op.binary.f32(i32 35, float %7214, float %7215)  ; FMax(a,b)
  %7217 = call float @dx.op.binary.f32(i32 35, float %7213, float %7216)  ; FMax(a,b)
  %7218 = fcmp fast olt float %7209, %7217
  %7219 = select i1 %7218, float %6451, float %6925
  %7220 = select i1 %7218, float %6452, float %6926
  %7221 = select i1 %7218, float %6453, float %6927
  %7222 = select i1 %7218, float %6687, float %7161
  %7223 = select i1 %7218, float %6688, float %7162
  %7224 = select i1 %7218, float %6689, float %7163
  %7225 = fsub fast float %6208, %7222
  %7226 = fsub fast float %6209, %7223
  %7227 = fsub fast float %6210, %7224
  %7228 = fsub fast float %6208, %7219
  %7229 = fsub fast float %6209, %7220
  %7230 = fsub fast float %6210, %7221
  %7231 = call float @dx.op.dot3.f32(i32 55, float %7228, float %7229, float %7230, float %7225, float %7226, float %7227)  ; Dot3(ax,ay,az,bx,by,bz)
  %7232 = fcmp fast ogt float %7231, 0.000000e+00
  br i1 %7232, label %7233, label %7244

; <label>:7233                                    ; preds = %7201
  %7234 = fsub fast float %7219, %7222
  %7235 = fsub fast float %7220, %7223
  %7236 = fsub fast float %7221, %7224
  %7237 = call float @dx.op.unary.f32(i32 6, float %7234)  ; FAbs(value)
  %7238 = call float @dx.op.unary.f32(i32 6, float %7235)  ; FAbs(value)
  %7239 = call float @dx.op.unary.f32(i32 6, float %7236)  ; FAbs(value)
  %7240 = call float @dx.op.binary.f32(i32 35, float %7238, float %7239)  ; FMax(a,b)
  %7241 = call float @dx.op.binary.f32(i32 35, float %7237, float %7240)  ; FMax(a,b)
  %7242 = fmul fast float %7195, 2.500000e-01
  %7243 = fcmp fast olt float %7241, %7242
  br label %7244

; <label>:7244                                    ; preds = %7233, %7201
  %7245 = phi i1 [ false, %7201 ], [ %7243, %7233 ]
  %7246 = select i1 %7245, float 5.000000e-01, float 1.000000e+00
  %7247 = fmul fast float %7246, %3
  %7248 = fadd fast float %7219, %7222
  %7249 = fadd fast float %7220, %7223
  %7250 = fadd fast float %7221, %7224
  %7251 = fmul fast float %7248, 5.000000e-01
  %7252 = fmul fast float %7249, 5.000000e-01
  %7253 = fmul fast float %7250, 5.000000e-01
  %7254 = fsub fast float %7251, %6208
  %7255 = fsub fast float %7252, %6209
  %7256 = fsub fast float %7253, %6210
  %7257 = fmul fast float %7247, %7254
  %7258 = fmul fast float %7247, %7255
  %7259 = fmul fast float %7247, %7256
  %7260 = fadd fast float %7257, %6208
  %7261 = fadd fast float %7258, %6209
  %7262 = fadd fast float %7259, %6210
  br label %7263

; <label>:7263                                    ; preds = %7244, %7160, %6179, %6015
  %7264 = phi float [ %6046, %6015 ], [ %6208, %6179 ], [ %7260, %7244 ], [ %6208, %7160 ]
  %7265 = phi float [ %6047, %6015 ], [ %6209, %6179 ], [ %7261, %7244 ], [ %6209, %7160 ]
  %7266 = phi float [ %6048, %6015 ], [ %6210, %6179 ], [ %7262, %7244 ], [ %6210, %7160 ]
  %7267 = phi float [ %6049, %6015 ], [ %6013, %6179 ], [ %6013, %7244 ], [ %6013, %7160 ]
  %7268 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %68, i32 %71, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7269 = extractvalue %dx.types.ResRet.f32 %7268, 0
  %7270 = extractvalue %dx.types.ResRet.f32 %7268, 1
  %7271 = extractvalue %dx.types.ResRet.f32 %7268, 2
  %7272 = extractvalue %dx.types.ResRet.f32 %7268, 3
  %7273 = fcmp fast olt float %7272, 0.000000e+00
  br i1 %7273, label %7274, label %7309

; <label>:7274                                    ; preds = %7263
  %7275 = fcmp fast ogt float %7269, 0x3FA4B5DCC0000000
  %7276 = fcmp fast ogt float %7270, 0x3FA4B5DCC0000000
  %7277 = fcmp fast ogt float %7271, 0x3FA4B5DCC0000000
  %7278 = select i1 %7275, float 0.000000e+00, float 1.000000e+00
  %7279 = select i1 %7276, float 0.000000e+00, float 1.000000e+00
  %7280 = select i1 %7277, float 0.000000e+00, float 1.000000e+00
  %7281 = fmul fast float %7269, 0x3FB3D07220000000
  %7282 = fmul fast float %7270, 0x3FB3D07220000000
  %7283 = fmul fast float %7271, 0x3FB3D07220000000
  %7284 = fadd fast float %7269, 0x3FAC28F5C0000000
  %7285 = fadd fast float %7270, 0x3FAC28F5C0000000
  %7286 = fadd fast float %7271, 0x3FAC28F5C0000000
  %7287 = fmul fast float %7284, 0x3FEE54EDE0000000
  %7288 = fmul fast float %7285, 0x3FEE54EDE0000000
  %7289 = fmul fast float %7286, 0x3FEE54EDE0000000
  %7290 = call float @dx.op.unary.f32(i32 23, float %7287)  ; Log(value)
  %7291 = call float @dx.op.unary.f32(i32 23, float %7288)  ; Log(value)
  %7292 = call float @dx.op.unary.f32(i32 23, float %7289)  ; Log(value)
  %7293 = fmul fast float %7290, 0x4003333340000000
  %7294 = fmul fast float %7291, 0x4003333340000000
  %7295 = fmul fast float %7292, 0x4003333340000000
  %7296 = call float @dx.op.unary.f32(i32 21, float %7293)  ; Exp(value)
  %7297 = call float @dx.op.unary.f32(i32 21, float %7294)  ; Exp(value)
  %7298 = call float @dx.op.unary.f32(i32 21, float %7295)  ; Exp(value)
  %7299 = fsub fast float %7281, %7296
  %7300 = fsub fast float %7282, %7297
  %7301 = fsub fast float %7283, %7298
  %7302 = fmul fast float %7299, %7278
  %7303 = fmul fast float %7300, %7279
  %7304 = fmul fast float %7301, %7280
  %7305 = fadd fast float %7302, %7296
  %7306 = fadd fast float %7303, %7297
  %7307 = fadd fast float %7304, %7298
  %7308 = fsub fast float -1.000000e+00, %7272
  br label %8522

; <label>:7309                                    ; preds = %7263
  %7310 = fcmp fast ogt float %39, 5.000000e-01
  %7311 = fcmp fast olt float %89, 1.000000e+00
  %7312 = and i1 %7310, %7311
  br i1 %7312, label %7313, label %7399

; <label>:7313                                    ; preds = %7309
  %7314 = sitofp i32 %68 to float
  %7315 = sitofp i32 %71 to float
  %7316 = fadd fast float %7314, 5.000000e-01
  %7317 = fadd fast float %7315, 5.000000e-01
  %7318 = fdiv fast float %7316, %46
  %7319 = fdiv fast float %7317, %47
  %7320 = fmul fast float %7318, 2.000000e+00
  %7321 = fmul fast float %7319, 2.000000e+00
  %7322 = fadd fast float %7320, -1.000000e+00
  %7323 = fsub fast float 1.000000e+00, %7321
  %7324 = fmul fast float %7322, %36
  %7325 = call float @dx.op.tertiary.f32(i32 46, float %7323, float %32, float %7324)  ; FMad(a,b,c)
  %7326 = call float @dx.op.tertiary.f32(i32 46, float %89, float %28, float %7325)  ; FMad(a,b,c)
  %7327 = fadd fast float %7326, %24
  %7328 = call float @dx.op.unary.f32(i32 6, float %7327)  ; FAbs(value)
  %7329 = fcmp fast ogt float %7328, 0x3EB0C6F7A0000000
  br i1 %7329, label %7330, label %7399

; <label>:7330                                    ; preds = %7313
  %7331 = fmul fast float %7322, %35
  %7332 = call float @dx.op.tertiary.f32(i32 46, float %7323, float %31, float %7331)  ; FMad(a,b,c)
  %7333 = call float @dx.op.tertiary.f32(i32 46, float %89, float %27, float %7332)  ; FMad(a,b,c)
  %7334 = fadd fast float %7333, %23
  %7335 = fmul fast float %7322, %34
  %7336 = call float @dx.op.tertiary.f32(i32 46, float %7323, float %30, float %7335)  ; FMad(a,b,c)
  %7337 = call float @dx.op.tertiary.f32(i32 46, float %89, float %26, float %7336)  ; FMad(a,b,c)
  %7338 = fadd fast float %7337, %22
  %7339 = fmul fast float %7322, %33
  %7340 = call float @dx.op.tertiary.f32(i32 46, float %7323, float %29, float %7339)  ; FMad(a,b,c)
  %7341 = call float @dx.op.tertiary.f32(i32 46, float %89, float %25, float %7340)  ; FMad(a,b,c)
  %7342 = fadd fast float %7341, %21
  %7343 = fdiv fast float %7342, %7327
  %7344 = fdiv fast float %7338, %7327
  %7345 = fdiv fast float %7334, %7327
  %7346 = fsub fast float %7343, %18
  %7347 = fsub fast float %7344, %19
  %7348 = fsub fast float %7345, %20
  %7349 = fmul fast float %7346, %7346
  %7350 = fmul fast float %7347, %7347
  %7351 = fadd fast float %7350, %7349
  %7352 = fmul fast float %7348, %7348
  %7353 = fadd fast float %7351, %7352
  %7354 = call float @dx.op.unary.f32(i32 24, float %7353)  ; Sqrt(value)
  %7355 = fsub fast float %7354, %10
  %7356 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %7355)  ; FMax(a,b)
  %7357 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %7357, label %7358, label %7381

; <label>:7358                                    ; preds = %7330
  %7359 = call float @dx.op.unary.f32(i32 6, float %7347)  ; FAbs(value)
  %7360 = fmul fast float %7359, %12
  %7361 = fcmp fast olt float %7360, 0x3F50624DE0000000
  br i1 %7361, label %7362, label %7365

; <label>:7362                                    ; preds = %7358
  %7363 = fmul fast float %7360, 5.000000e-01
  %7364 = fsub fast float 1.000000e+00, %7363
  br label %7370

; <label>:7365                                    ; preds = %7358
  %7366 = fmul fast float %7360, 0xBFF7154760000000
  %7367 = call float @dx.op.unary.f32(i32 21, float %7366)  ; Exp(value)
  %7368 = fsub fast float 1.000000e+00, %7367
  %7369 = fdiv fast float %7368, %7360
  br label %7370

; <label>:7370                                    ; preds = %7365, %7362
  %7371 = phi float [ %7364, %7362 ], [ %7369, %7365 ]
  %7372 = call float @dx.op.binary.f32(i32 36, float %7344, float %19)  ; FMin(a,b)
  %7373 = fsub fast float %7372, %11
  %7374 = fmul fast float %12, %7373
  %7375 = fsub fast float -0.000000e+00, %7374
  %7376 = call float @dx.op.binary.f32(i32 35, float %7375, float -4.000000e+01)  ; FMax(a,b)
  %7377 = call float @dx.op.binary.f32(i32 36, float %7376, float 5.000000e+00)  ; FMin(a,b)
  %7378 = fmul fast float %7377, 0x3FF7154760000000
  %7379 = call float @dx.op.unary.f32(i32 21, float %7378)  ; Exp(value)
  %7380 = fmul fast float %7379, %7371
  br label %7381

; <label>:7381                                    ; preds = %7370, %7330
  %7382 = phi float [ %7380, %7370 ], [ 1.000000e+00, %7330 ]
  %7383 = fmul fast float %7356, %17
  %7384 = fmul fast float %7383, %7382
  %7385 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %7384)  ; FMin(a,b)
  %7386 = fmul fast float %7385, 0xBFF7154760000000
  %7387 = call float @dx.op.unary.f32(i32 21, float %7386)  ; Exp(value)
  %7388 = fsub fast float 1.000000e+00, %7387
  %7389 = call float @dx.op.binary.f32(i32 36, float %13, float %7388)  ; FMin(a,b)
  %7390 = fsub fast float %14, %7269
  %7391 = fsub fast float %15, %7270
  %7392 = fsub fast float %16, %7271
  %7393 = fmul fast float %7389, %7390
  %7394 = fmul fast float %7389, %7391
  %7395 = fmul fast float %7389, %7392
  %7396 = fadd fast float %7393, %7269
  %7397 = fadd fast float %7394, %7270
  %7398 = fadd fast float %7395, %7271
  br label %7399

; <label>:7399                                    ; preds = %7381, %7313, %7309
  %7400 = phi float [ %7396, %7381 ], [ %7269, %7313 ], [ %7269, %7309 ]
  %7401 = phi float [ %7397, %7381 ], [ %7270, %7313 ], [ %7270, %7309 ]
  %7402 = phi float [ %7398, %7381 ], [ %7271, %7313 ], [ %7271, %7309 ]
  %7403 = fadd fast float %6, 1.000000e+00
  %7404 = fadd fast float %7, 1.000000e+00
  %7405 = fsub fast float 1.000000e+00, %6
  %7406 = fmul fast float %37, %7403
  %7407 = fmul fast float %37, %7404
  %7408 = fmul fast float %37, %7405
  %7409 = fmul fast float %7406, %7400
  %7410 = fmul fast float %7407, %7401
  %7411 = fmul fast float %7408, %7402
  %7412 = fcmp fast ult float %38, 5.000000e-01
  br i1 %7412, label %7438, label %7413

; <label>:7413                                    ; preds = %7399
  %7414 = fmul fast float %7409, 0x4004147AE0000000
  %7415 = fmul fast float %7410, 0x4004147AE0000000
  %7416 = fmul fast float %7411, 0x4004147AE0000000
  %7417 = fadd fast float %7414, 0x3F9EB851E0000000
  %7418 = fadd fast float %7415, 0x3F9EB851E0000000
  %7419 = fadd fast float %7416, 0x3F9EB851E0000000
  %7420 = fmul fast float %7417, %7409
  %7421 = fmul fast float %7418, %7410
  %7422 = fmul fast float %7419, %7411
  %7423 = fmul fast float %7409, 0x400370A3E0000000
  %7424 = fmul fast float %7410, 0x400370A3E0000000
  %7425 = fmul fast float %7411, 0x400370A3E0000000
  %7426 = fadd fast float %7423, 0x3FE2E147A0000000
  %7427 = fadd fast float %7424, 0x3FE2E147A0000000
  %7428 = fadd fast float %7425, 0x3FE2E147A0000000
  %7429 = fmul fast float %7426, %7409
  %7430 = fmul fast float %7427, %7410
  %7431 = fmul fast float %7428, %7411
  %7432 = fadd fast float %7429, 0x3FC1EB8520000000
  %7433 = fadd fast float %7430, 0x3FC1EB8520000000
  %7434 = fadd fast float %7431, 0x3FC1EB8520000000
  %7435 = fdiv fast float %7420, %7432
  %7436 = fdiv fast float %7421, %7433
  %7437 = fdiv fast float %7422, %7434
  br label %7438

; <label>:7438                                    ; preds = %7413, %7399
  %7439 = phi float [ %7435, %7413 ], [ %7409, %7399 ]
  %7440 = phi float [ %7436, %7413 ], [ %7410, %7399 ]
  %7441 = phi float [ %7437, %7413 ], [ %7411, %7399 ]
  %7442 = call float @dx.op.unary.f32(i32 7, float %7439)  ; Saturate(value)
  %7443 = call float @dx.op.unary.f32(i32 7, float %7440)  ; Saturate(value)
  %7444 = call float @dx.op.unary.f32(i32 7, float %7441)  ; Saturate(value)
  %7445 = call float @dx.op.dot3.f32(i32 55, float %7442, float %7443, float %7444, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %7446 = fsub fast float %7442, %7445
  %7447 = fsub fast float %7443, %7445
  %7448 = fsub fast float %7444, %7445
  %7449 = fmul fast float %7446, %9
  %7450 = fmul fast float %7447, %9
  %7451 = fmul fast float %7448, %9
  %7452 = fadd fast float %7449, %7445
  %7453 = fadd fast float %7450, %7445
  %7454 = fadd fast float %7451, %7445
  %7455 = call float @dx.op.unary.f32(i32 7, float %7452)  ; Saturate(value)
  %7456 = call float @dx.op.unary.f32(i32 7, float %7453)  ; Saturate(value)
  %7457 = call float @dx.op.unary.f32(i32 7, float %7454)  ; Saturate(value)
  %7458 = fadd fast float %7455, 0xBFC70A3D80000000
  %7459 = fadd fast float %7456, 0xBFC70A3D80000000
  %7460 = fadd fast float %7457, 0xBFC70A3D80000000
  %7461 = fmul fast float %7458, %8
  %7462 = fmul fast float %7459, %8
  %7463 = fmul fast float %7460, %8
  %7464 = fadd fast float %7461, 0x3FC70A3D80000000
  %7465 = fadd fast float %7462, 0x3FC70A3D80000000
  %7466 = fadd fast float %7463, 0x3FC70A3D80000000
  %7467 = call float @dx.op.unary.f32(i32 7, float %7464)  ; Saturate(value)
  %7468 = call float @dx.op.unary.f32(i32 7, float %7465)  ; Saturate(value)
  %7469 = call float @dx.op.unary.f32(i32 7, float %7466)  ; Saturate(value)
  %7470 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %7470, label %7471, label %8522

; <label>:7471                                    ; preds = %7438
  %7472 = add i32 %71, -1
  %7473 = call i32 @dx.op.binary.i32(i32 37, i32 %68, i32 0)  ; IMax(a,b)
  %7474 = call i32 @dx.op.binary.i32(i32 37, i32 %7472, i32 0)  ; IMax(a,b)
  %7475 = call i32 @dx.op.binary.i32(i32 38, i32 %7473, i32 %60)  ; IMin(a,b)
  %7476 = call i32 @dx.op.binary.i32(i32 38, i32 %7474, i32 %61)  ; IMin(a,b)
  %7477 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %7475, i32 %7476, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7478 = extractvalue %dx.types.ResRet.f32 %7477, 0
  %7479 = fsub fast float 1.000000e+00, %89
  %7480 = fmul fast float %7479, 0x3FA99999A0000000
  %7481 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %7480)  ; FMax(a,b)
  %7482 = fsub fast float %7478, %89
  %7483 = call float @dx.op.unary.f32(i32 6, float %7482)  ; FAbs(value)
  %7484 = fdiv fast float %7483, %7481
  %7485 = fsub fast float 1.000000e+00, %7484
  %7486 = call float @dx.op.unary.f32(i32 7, float %7485)  ; Saturate(value)
  %7487 = fcmp fast ugt float %7486, 0.000000e+00
  br i1 %7487, label %7488, label %7709

; <label>:7488                                    ; preds = %7471
  %7489 = call i32 @dx.op.binary.i32(i32 37, i32 %7475, i32 0)  ; IMax(a,b)
  %7490 = call i32 @dx.op.binary.i32(i32 37, i32 %7476, i32 0)  ; IMax(a,b)
  %7491 = call i32 @dx.op.binary.i32(i32 38, i32 %7489, i32 %60)  ; IMin(a,b)
  %7492 = call i32 @dx.op.binary.i32(i32 38, i32 %7490, i32 %61)  ; IMin(a,b)
  %7493 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %7491, i32 %7492, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7494 = extractvalue %dx.types.ResRet.f32 %7493, 0
  %7495 = extractvalue %dx.types.ResRet.f32 %7493, 1
  %7496 = extractvalue %dx.types.ResRet.f32 %7493, 2
  %7497 = extractvalue %dx.types.ResRet.f32 %7493, 3
  %7498 = fcmp fast olt float %7497, 0.000000e+00
  br i1 %7498, label %7499, label %7533

; <label>:7499                                    ; preds = %7488
  %7500 = fcmp fast ogt float %7494, 0x3FA4B5DCC0000000
  %7501 = fcmp fast ogt float %7495, 0x3FA4B5DCC0000000
  %7502 = fcmp fast ogt float %7496, 0x3FA4B5DCC0000000
  %7503 = select i1 %7500, float 0.000000e+00, float 1.000000e+00
  %7504 = select i1 %7501, float 0.000000e+00, float 1.000000e+00
  %7505 = select i1 %7502, float 0.000000e+00, float 1.000000e+00
  %7506 = fmul fast float %7494, 0x3FB3D07220000000
  %7507 = fmul fast float %7495, 0x3FB3D07220000000
  %7508 = fmul fast float %7496, 0x3FB3D07220000000
  %7509 = fadd fast float %7494, 0x3FAC28F5C0000000
  %7510 = fadd fast float %7495, 0x3FAC28F5C0000000
  %7511 = fadd fast float %7496, 0x3FAC28F5C0000000
  %7512 = fmul fast float %7509, 0x3FEE54EDE0000000
  %7513 = fmul fast float %7510, 0x3FEE54EDE0000000
  %7514 = fmul fast float %7511, 0x3FEE54EDE0000000
  %7515 = call float @dx.op.unary.f32(i32 23, float %7512)  ; Log(value)
  %7516 = call float @dx.op.unary.f32(i32 23, float %7513)  ; Log(value)
  %7517 = call float @dx.op.unary.f32(i32 23, float %7514)  ; Log(value)
  %7518 = fmul fast float %7515, 0x4003333340000000
  %7519 = fmul fast float %7516, 0x4003333340000000
  %7520 = fmul fast float %7517, 0x4003333340000000
  %7521 = call float @dx.op.unary.f32(i32 21, float %7518)  ; Exp(value)
  %7522 = call float @dx.op.unary.f32(i32 21, float %7519)  ; Exp(value)
  %7523 = call float @dx.op.unary.f32(i32 21, float %7520)  ; Exp(value)
  %7524 = fsub fast float %7506, %7521
  %7525 = fsub fast float %7507, %7522
  %7526 = fsub fast float %7508, %7523
  %7527 = fmul fast float %7524, %7503
  %7528 = fmul fast float %7525, %7504
  %7529 = fmul fast float %7526, %7505
  %7530 = fadd fast float %7527, %7521
  %7531 = fadd fast float %7528, %7522
  %7532 = fadd fast float %7529, %7523
  br label %7696

; <label>:7533                                    ; preds = %7488
  %7534 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %7491, i32 %7492, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7535 = extractvalue %dx.types.ResRet.f32 %7534, 0
  %7536 = fcmp fast ogt float %39, 5.000000e-01
  %7537 = fcmp fast olt float %7535, 1.000000e+00
  %7538 = and i1 %7536, %7537
  br i1 %7538, label %7539, label %7625

; <label>:7539                                    ; preds = %7533
  %7540 = sitofp i32 %7491 to float
  %7541 = sitofp i32 %7492 to float
  %7542 = fadd fast float %7540, 5.000000e-01
  %7543 = fadd fast float %7541, 5.000000e-01
  %7544 = fdiv fast float %7542, %46
  %7545 = fdiv fast float %7543, %47
  %7546 = fmul fast float %7544, 2.000000e+00
  %7547 = fmul fast float %7545, 2.000000e+00
  %7548 = fadd fast float %7546, -1.000000e+00
  %7549 = fsub fast float 1.000000e+00, %7547
  %7550 = fmul fast float %7548, %36
  %7551 = call float @dx.op.tertiary.f32(i32 46, float %7549, float %32, float %7550)  ; FMad(a,b,c)
  %7552 = call float @dx.op.tertiary.f32(i32 46, float %7535, float %28, float %7551)  ; FMad(a,b,c)
  %7553 = fadd fast float %7552, %24
  %7554 = call float @dx.op.unary.f32(i32 6, float %7553)  ; FAbs(value)
  %7555 = fcmp fast ogt float %7554, 0x3EB0C6F7A0000000
  br i1 %7555, label %7556, label %7625

; <label>:7556                                    ; preds = %7539
  %7557 = fmul fast float %7548, %35
  %7558 = call float @dx.op.tertiary.f32(i32 46, float %7549, float %31, float %7557)  ; FMad(a,b,c)
  %7559 = call float @dx.op.tertiary.f32(i32 46, float %7535, float %27, float %7558)  ; FMad(a,b,c)
  %7560 = fadd fast float %7559, %23
  %7561 = fmul fast float %7548, %34
  %7562 = call float @dx.op.tertiary.f32(i32 46, float %7549, float %30, float %7561)  ; FMad(a,b,c)
  %7563 = call float @dx.op.tertiary.f32(i32 46, float %7535, float %26, float %7562)  ; FMad(a,b,c)
  %7564 = fadd fast float %7563, %22
  %7565 = fmul fast float %7548, %33
  %7566 = call float @dx.op.tertiary.f32(i32 46, float %7549, float %29, float %7565)  ; FMad(a,b,c)
  %7567 = call float @dx.op.tertiary.f32(i32 46, float %7535, float %25, float %7566)  ; FMad(a,b,c)
  %7568 = fadd fast float %7567, %21
  %7569 = fdiv fast float %7568, %7553
  %7570 = fdiv fast float %7564, %7553
  %7571 = fdiv fast float %7560, %7553
  %7572 = fsub fast float %7569, %18
  %7573 = fsub fast float %7570, %19
  %7574 = fsub fast float %7571, %20
  %7575 = fmul fast float %7572, %7572
  %7576 = fmul fast float %7573, %7573
  %7577 = fadd fast float %7576, %7575
  %7578 = fmul fast float %7574, %7574
  %7579 = fadd fast float %7577, %7578
  %7580 = call float @dx.op.unary.f32(i32 24, float %7579)  ; Sqrt(value)
  %7581 = fsub fast float %7580, %10
  %7582 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %7581)  ; FMax(a,b)
  %7583 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %7583, label %7584, label %7607

; <label>:7584                                    ; preds = %7556
  %7585 = call float @dx.op.unary.f32(i32 6, float %7573)  ; FAbs(value)
  %7586 = fmul fast float %7585, %12
  %7587 = fcmp fast olt float %7586, 0x3F50624DE0000000
  br i1 %7587, label %7588, label %7591

; <label>:7588                                    ; preds = %7584
  %7589 = fmul fast float %7586, 5.000000e-01
  %7590 = fsub fast float 1.000000e+00, %7589
  br label %7596

; <label>:7591                                    ; preds = %7584
  %7592 = fmul fast float %7586, 0xBFF7154760000000
  %7593 = call float @dx.op.unary.f32(i32 21, float %7592)  ; Exp(value)
  %7594 = fsub fast float 1.000000e+00, %7593
  %7595 = fdiv fast float %7594, %7586
  br label %7596

; <label>:7596                                    ; preds = %7591, %7588
  %7597 = phi float [ %7590, %7588 ], [ %7595, %7591 ]
  %7598 = call float @dx.op.binary.f32(i32 36, float %7570, float %19)  ; FMin(a,b)
  %7599 = fsub fast float %7598, %11
  %7600 = fmul fast float %12, %7599
  %7601 = fsub fast float -0.000000e+00, %7600
  %7602 = call float @dx.op.binary.f32(i32 35, float %7601, float -4.000000e+01)  ; FMax(a,b)
  %7603 = call float @dx.op.binary.f32(i32 36, float %7602, float 5.000000e+00)  ; FMin(a,b)
  %7604 = fmul fast float %7603, 0x3FF7154760000000
  %7605 = call float @dx.op.unary.f32(i32 21, float %7604)  ; Exp(value)
  %7606 = fmul fast float %7605, %7597
  br label %7607

; <label>:7607                                    ; preds = %7596, %7556
  %7608 = phi float [ %7606, %7596 ], [ 1.000000e+00, %7556 ]
  %7609 = fmul fast float %7582, %17
  %7610 = fmul fast float %7609, %7608
  %7611 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %7610)  ; FMin(a,b)
  %7612 = fmul fast float %7611, 0xBFF7154760000000
  %7613 = call float @dx.op.unary.f32(i32 21, float %7612)  ; Exp(value)
  %7614 = fsub fast float 1.000000e+00, %7613
  %7615 = call float @dx.op.binary.f32(i32 36, float %13, float %7614)  ; FMin(a,b)
  %7616 = fsub fast float %14, %7494
  %7617 = fsub fast float %15, %7495
  %7618 = fsub fast float %16, %7496
  %7619 = fmul fast float %7615, %7616
  %7620 = fmul fast float %7615, %7617
  %7621 = fmul fast float %7615, %7618
  %7622 = fadd fast float %7619, %7494
  %7623 = fadd fast float %7620, %7495
  %7624 = fadd fast float %7621, %7496
  br label %7625

; <label>:7625                                    ; preds = %7607, %7539, %7533
  %7626 = phi float [ %7622, %7607 ], [ %7494, %7539 ], [ %7494, %7533 ]
  %7627 = phi float [ %7623, %7607 ], [ %7495, %7539 ], [ %7495, %7533 ]
  %7628 = phi float [ %7624, %7607 ], [ %7496, %7539 ], [ %7496, %7533 ]
  %7629 = fadd fast float %6, 1.000000e+00
  %7630 = fadd fast float %7, 1.000000e+00
  %7631 = fsub fast float 1.000000e+00, %6
  %7632 = fmul fast float %37, %7629
  %7633 = fmul fast float %37, %7630
  %7634 = fmul fast float %37, %7631
  %7635 = fmul fast float %7632, %7626
  %7636 = fmul fast float %7633, %7627
  %7637 = fmul fast float %7634, %7628
  %7638 = fcmp fast ult float %38, 5.000000e-01
  br i1 %7638, label %7664, label %7639

; <label>:7639                                    ; preds = %7625
  %7640 = fmul fast float %7635, 0x4004147AE0000000
  %7641 = fmul fast float %7636, 0x4004147AE0000000
  %7642 = fmul fast float %7637, 0x4004147AE0000000
  %7643 = fadd fast float %7640, 0x3F9EB851E0000000
  %7644 = fadd fast float %7641, 0x3F9EB851E0000000
  %7645 = fadd fast float %7642, 0x3F9EB851E0000000
  %7646 = fmul fast float %7643, %7635
  %7647 = fmul fast float %7644, %7636
  %7648 = fmul fast float %7645, %7637
  %7649 = fmul fast float %7635, 0x400370A3E0000000
  %7650 = fmul fast float %7636, 0x400370A3E0000000
  %7651 = fmul fast float %7637, 0x400370A3E0000000
  %7652 = fadd fast float %7649, 0x3FE2E147A0000000
  %7653 = fadd fast float %7650, 0x3FE2E147A0000000
  %7654 = fadd fast float %7651, 0x3FE2E147A0000000
  %7655 = fmul fast float %7652, %7635
  %7656 = fmul fast float %7653, %7636
  %7657 = fmul fast float %7654, %7637
  %7658 = fadd fast float %7655, 0x3FC1EB8520000000
  %7659 = fadd fast float %7656, 0x3FC1EB8520000000
  %7660 = fadd fast float %7657, 0x3FC1EB8520000000
  %7661 = fdiv fast float %7646, %7658
  %7662 = fdiv fast float %7647, %7659
  %7663 = fdiv fast float %7648, %7660
  br label %7664

; <label>:7664                                    ; preds = %7639, %7625
  %7665 = phi float [ %7661, %7639 ], [ %7635, %7625 ]
  %7666 = phi float [ %7662, %7639 ], [ %7636, %7625 ]
  %7667 = phi float [ %7663, %7639 ], [ %7637, %7625 ]
  %7668 = call float @dx.op.unary.f32(i32 7, float %7665)  ; Saturate(value)
  %7669 = call float @dx.op.unary.f32(i32 7, float %7666)  ; Saturate(value)
  %7670 = call float @dx.op.unary.f32(i32 7, float %7667)  ; Saturate(value)
  %7671 = call float @dx.op.dot3.f32(i32 55, float %7668, float %7669, float %7670, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %7672 = fsub fast float %7668, %7671
  %7673 = fsub fast float %7669, %7671
  %7674 = fsub fast float %7670, %7671
  %7675 = fmul fast float %7672, %9
  %7676 = fmul fast float %7673, %9
  %7677 = fmul fast float %7674, %9
  %7678 = fadd fast float %7675, %7671
  %7679 = fadd fast float %7676, %7671
  %7680 = fadd fast float %7677, %7671
  %7681 = call float @dx.op.unary.f32(i32 7, float %7678)  ; Saturate(value)
  %7682 = call float @dx.op.unary.f32(i32 7, float %7679)  ; Saturate(value)
  %7683 = call float @dx.op.unary.f32(i32 7, float %7680)  ; Saturate(value)
  %7684 = fadd fast float %7681, 0xBFC70A3D80000000
  %7685 = fadd fast float %7682, 0xBFC70A3D80000000
  %7686 = fadd fast float %7683, 0xBFC70A3D80000000
  %7687 = fmul fast float %7684, %8
  %7688 = fmul fast float %7685, %8
  %7689 = fmul fast float %7686, %8
  %7690 = fadd fast float %7687, 0x3FC70A3D80000000
  %7691 = fadd fast float %7688, 0x3FC70A3D80000000
  %7692 = fadd fast float %7689, 0x3FC70A3D80000000
  %7693 = call float @dx.op.unary.f32(i32 7, float %7690)  ; Saturate(value)
  %7694 = call float @dx.op.unary.f32(i32 7, float %7691)  ; Saturate(value)
  %7695 = call float @dx.op.unary.f32(i32 7, float %7692)  ; Saturate(value)
  br label %7696

; <label>:7696                                    ; preds = %7664, %7499
  %7697 = phi float [ %7530, %7499 ], [ %7693, %7664 ]
  %7698 = phi float [ %7531, %7499 ], [ %7694, %7664 ]
  %7699 = phi float [ %7532, %7499 ], [ %7695, %7664 ]
  %7700 = fsub fast float %7697, %7467
  %7701 = fsub fast float %7698, %7468
  %7702 = fsub fast float %7699, %7469
  %7703 = fmul fast float %7700, %7486
  %7704 = fmul fast float %7701, %7486
  %7705 = fmul fast float %7702, %7486
  %7706 = fadd fast float %7703, %7467
  %7707 = fadd fast float %7704, %7468
  %7708 = fadd fast float %7705, %7469
  br label %7709

; <label>:7709                                    ; preds = %7696, %7471
  %7710 = phi float [ %7706, %7696 ], [ %7467, %7471 ]
  %7711 = phi float [ %7707, %7696 ], [ %7468, %7471 ]
  %7712 = phi float [ %7708, %7696 ], [ %7469, %7471 ]
  %7713 = add i32 %71, 1
  %7714 = call i32 @dx.op.binary.i32(i32 37, i32 %7713, i32 0)  ; IMax(a,b)
  %7715 = call i32 @dx.op.binary.i32(i32 38, i32 %7714, i32 %61)  ; IMin(a,b)
  %7716 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %7475, i32 %7715, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7717 = extractvalue %dx.types.ResRet.f32 %7716, 0
  %7718 = fsub fast float %7717, %89
  %7719 = call float @dx.op.unary.f32(i32 6, float %7718)  ; FAbs(value)
  %7720 = fdiv fast float %7719, %7481
  %7721 = fsub fast float 1.000000e+00, %7720
  %7722 = call float @dx.op.unary.f32(i32 7, float %7721)  ; Saturate(value)
  %7723 = fcmp fast ugt float %7722, 0.000000e+00
  br i1 %7723, label %7724, label %7945

; <label>:7724                                    ; preds = %7709
  %7725 = call i32 @dx.op.binary.i32(i32 37, i32 %7475, i32 0)  ; IMax(a,b)
  %7726 = call i32 @dx.op.binary.i32(i32 37, i32 %7715, i32 0)  ; IMax(a,b)
  %7727 = call i32 @dx.op.binary.i32(i32 38, i32 %7725, i32 %60)  ; IMin(a,b)
  %7728 = call i32 @dx.op.binary.i32(i32 38, i32 %7726, i32 %61)  ; IMin(a,b)
  %7729 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %7727, i32 %7728, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7730 = extractvalue %dx.types.ResRet.f32 %7729, 0
  %7731 = extractvalue %dx.types.ResRet.f32 %7729, 1
  %7732 = extractvalue %dx.types.ResRet.f32 %7729, 2
  %7733 = extractvalue %dx.types.ResRet.f32 %7729, 3
  %7734 = fcmp fast olt float %7733, 0.000000e+00
  br i1 %7734, label %7735, label %7769

; <label>:7735                                    ; preds = %7724
  %7736 = fcmp fast ogt float %7730, 0x3FA4B5DCC0000000
  %7737 = fcmp fast ogt float %7731, 0x3FA4B5DCC0000000
  %7738 = fcmp fast ogt float %7732, 0x3FA4B5DCC0000000
  %7739 = select i1 %7736, float 0.000000e+00, float 1.000000e+00
  %7740 = select i1 %7737, float 0.000000e+00, float 1.000000e+00
  %7741 = select i1 %7738, float 0.000000e+00, float 1.000000e+00
  %7742 = fmul fast float %7730, 0x3FB3D07220000000
  %7743 = fmul fast float %7731, 0x3FB3D07220000000
  %7744 = fmul fast float %7732, 0x3FB3D07220000000
  %7745 = fadd fast float %7730, 0x3FAC28F5C0000000
  %7746 = fadd fast float %7731, 0x3FAC28F5C0000000
  %7747 = fadd fast float %7732, 0x3FAC28F5C0000000
  %7748 = fmul fast float %7745, 0x3FEE54EDE0000000
  %7749 = fmul fast float %7746, 0x3FEE54EDE0000000
  %7750 = fmul fast float %7747, 0x3FEE54EDE0000000
  %7751 = call float @dx.op.unary.f32(i32 23, float %7748)  ; Log(value)
  %7752 = call float @dx.op.unary.f32(i32 23, float %7749)  ; Log(value)
  %7753 = call float @dx.op.unary.f32(i32 23, float %7750)  ; Log(value)
  %7754 = fmul fast float %7751, 0x4003333340000000
  %7755 = fmul fast float %7752, 0x4003333340000000
  %7756 = fmul fast float %7753, 0x4003333340000000
  %7757 = call float @dx.op.unary.f32(i32 21, float %7754)  ; Exp(value)
  %7758 = call float @dx.op.unary.f32(i32 21, float %7755)  ; Exp(value)
  %7759 = call float @dx.op.unary.f32(i32 21, float %7756)  ; Exp(value)
  %7760 = fsub fast float %7742, %7757
  %7761 = fsub fast float %7743, %7758
  %7762 = fsub fast float %7744, %7759
  %7763 = fmul fast float %7760, %7739
  %7764 = fmul fast float %7761, %7740
  %7765 = fmul fast float %7762, %7741
  %7766 = fadd fast float %7763, %7757
  %7767 = fadd fast float %7764, %7758
  %7768 = fadd fast float %7765, %7759
  br label %7932

; <label>:7769                                    ; preds = %7724
  %7770 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %7727, i32 %7728, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7771 = extractvalue %dx.types.ResRet.f32 %7770, 0
  %7772 = fcmp fast ogt float %39, 5.000000e-01
  %7773 = fcmp fast olt float %7771, 1.000000e+00
  %7774 = and i1 %7772, %7773
  br i1 %7774, label %7775, label %7861

; <label>:7775                                    ; preds = %7769
  %7776 = sitofp i32 %7727 to float
  %7777 = sitofp i32 %7728 to float
  %7778 = fadd fast float %7776, 5.000000e-01
  %7779 = fadd fast float %7777, 5.000000e-01
  %7780 = fdiv fast float %7778, %46
  %7781 = fdiv fast float %7779, %47
  %7782 = fmul fast float %7780, 2.000000e+00
  %7783 = fmul fast float %7781, 2.000000e+00
  %7784 = fadd fast float %7782, -1.000000e+00
  %7785 = fsub fast float 1.000000e+00, %7783
  %7786 = fmul fast float %7784, %36
  %7787 = call float @dx.op.tertiary.f32(i32 46, float %7785, float %32, float %7786)  ; FMad(a,b,c)
  %7788 = call float @dx.op.tertiary.f32(i32 46, float %7771, float %28, float %7787)  ; FMad(a,b,c)
  %7789 = fadd fast float %7788, %24
  %7790 = call float @dx.op.unary.f32(i32 6, float %7789)  ; FAbs(value)
  %7791 = fcmp fast ogt float %7790, 0x3EB0C6F7A0000000
  br i1 %7791, label %7792, label %7861

; <label>:7792                                    ; preds = %7775
  %7793 = fmul fast float %7784, %35
  %7794 = call float @dx.op.tertiary.f32(i32 46, float %7785, float %31, float %7793)  ; FMad(a,b,c)
  %7795 = call float @dx.op.tertiary.f32(i32 46, float %7771, float %27, float %7794)  ; FMad(a,b,c)
  %7796 = fadd fast float %7795, %23
  %7797 = fmul fast float %7784, %34
  %7798 = call float @dx.op.tertiary.f32(i32 46, float %7785, float %30, float %7797)  ; FMad(a,b,c)
  %7799 = call float @dx.op.tertiary.f32(i32 46, float %7771, float %26, float %7798)  ; FMad(a,b,c)
  %7800 = fadd fast float %7799, %22
  %7801 = fmul fast float %7784, %33
  %7802 = call float @dx.op.tertiary.f32(i32 46, float %7785, float %29, float %7801)  ; FMad(a,b,c)
  %7803 = call float @dx.op.tertiary.f32(i32 46, float %7771, float %25, float %7802)  ; FMad(a,b,c)
  %7804 = fadd fast float %7803, %21
  %7805 = fdiv fast float %7804, %7789
  %7806 = fdiv fast float %7800, %7789
  %7807 = fdiv fast float %7796, %7789
  %7808 = fsub fast float %7805, %18
  %7809 = fsub fast float %7806, %19
  %7810 = fsub fast float %7807, %20
  %7811 = fmul fast float %7808, %7808
  %7812 = fmul fast float %7809, %7809
  %7813 = fadd fast float %7812, %7811
  %7814 = fmul fast float %7810, %7810
  %7815 = fadd fast float %7813, %7814
  %7816 = call float @dx.op.unary.f32(i32 24, float %7815)  ; Sqrt(value)
  %7817 = fsub fast float %7816, %10
  %7818 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %7817)  ; FMax(a,b)
  %7819 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %7819, label %7820, label %7843

; <label>:7820                                    ; preds = %7792
  %7821 = call float @dx.op.unary.f32(i32 6, float %7809)  ; FAbs(value)
  %7822 = fmul fast float %7821, %12
  %7823 = fcmp fast olt float %7822, 0x3F50624DE0000000
  br i1 %7823, label %7824, label %7827

; <label>:7824                                    ; preds = %7820
  %7825 = fmul fast float %7822, 5.000000e-01
  %7826 = fsub fast float 1.000000e+00, %7825
  br label %7832

; <label>:7827                                    ; preds = %7820
  %7828 = fmul fast float %7822, 0xBFF7154760000000
  %7829 = call float @dx.op.unary.f32(i32 21, float %7828)  ; Exp(value)
  %7830 = fsub fast float 1.000000e+00, %7829
  %7831 = fdiv fast float %7830, %7822
  br label %7832

; <label>:7832                                    ; preds = %7827, %7824
  %7833 = phi float [ %7826, %7824 ], [ %7831, %7827 ]
  %7834 = call float @dx.op.binary.f32(i32 36, float %7806, float %19)  ; FMin(a,b)
  %7835 = fsub fast float %7834, %11
  %7836 = fmul fast float %12, %7835
  %7837 = fsub fast float -0.000000e+00, %7836
  %7838 = call float @dx.op.binary.f32(i32 35, float %7837, float -4.000000e+01)  ; FMax(a,b)
  %7839 = call float @dx.op.binary.f32(i32 36, float %7838, float 5.000000e+00)  ; FMin(a,b)
  %7840 = fmul fast float %7839, 0x3FF7154760000000
  %7841 = call float @dx.op.unary.f32(i32 21, float %7840)  ; Exp(value)
  %7842 = fmul fast float %7841, %7833
  br label %7843

; <label>:7843                                    ; preds = %7832, %7792
  %7844 = phi float [ %7842, %7832 ], [ 1.000000e+00, %7792 ]
  %7845 = fmul fast float %7818, %17
  %7846 = fmul fast float %7845, %7844
  %7847 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %7846)  ; FMin(a,b)
  %7848 = fmul fast float %7847, 0xBFF7154760000000
  %7849 = call float @dx.op.unary.f32(i32 21, float %7848)  ; Exp(value)
  %7850 = fsub fast float 1.000000e+00, %7849
  %7851 = call float @dx.op.binary.f32(i32 36, float %13, float %7850)  ; FMin(a,b)
  %7852 = fsub fast float %14, %7730
  %7853 = fsub fast float %15, %7731
  %7854 = fsub fast float %16, %7732
  %7855 = fmul fast float %7851, %7852
  %7856 = fmul fast float %7851, %7853
  %7857 = fmul fast float %7851, %7854
  %7858 = fadd fast float %7855, %7730
  %7859 = fadd fast float %7856, %7731
  %7860 = fadd fast float %7857, %7732
  br label %7861

; <label>:7861                                    ; preds = %7843, %7775, %7769
  %7862 = phi float [ %7858, %7843 ], [ %7730, %7775 ], [ %7730, %7769 ]
  %7863 = phi float [ %7859, %7843 ], [ %7731, %7775 ], [ %7731, %7769 ]
  %7864 = phi float [ %7860, %7843 ], [ %7732, %7775 ], [ %7732, %7769 ]
  %7865 = fadd fast float %6, 1.000000e+00
  %7866 = fadd fast float %7, 1.000000e+00
  %7867 = fsub fast float 1.000000e+00, %6
  %7868 = fmul fast float %37, %7865
  %7869 = fmul fast float %37, %7866
  %7870 = fmul fast float %37, %7867
  %7871 = fmul fast float %7868, %7862
  %7872 = fmul fast float %7869, %7863
  %7873 = fmul fast float %7870, %7864
  %7874 = fcmp fast ult float %38, 5.000000e-01
  br i1 %7874, label %7900, label %7875

; <label>:7875                                    ; preds = %7861
  %7876 = fmul fast float %7871, 0x4004147AE0000000
  %7877 = fmul fast float %7872, 0x4004147AE0000000
  %7878 = fmul fast float %7873, 0x4004147AE0000000
  %7879 = fadd fast float %7876, 0x3F9EB851E0000000
  %7880 = fadd fast float %7877, 0x3F9EB851E0000000
  %7881 = fadd fast float %7878, 0x3F9EB851E0000000
  %7882 = fmul fast float %7879, %7871
  %7883 = fmul fast float %7880, %7872
  %7884 = fmul fast float %7881, %7873
  %7885 = fmul fast float %7871, 0x400370A3E0000000
  %7886 = fmul fast float %7872, 0x400370A3E0000000
  %7887 = fmul fast float %7873, 0x400370A3E0000000
  %7888 = fadd fast float %7885, 0x3FE2E147A0000000
  %7889 = fadd fast float %7886, 0x3FE2E147A0000000
  %7890 = fadd fast float %7887, 0x3FE2E147A0000000
  %7891 = fmul fast float %7888, %7871
  %7892 = fmul fast float %7889, %7872
  %7893 = fmul fast float %7890, %7873
  %7894 = fadd fast float %7891, 0x3FC1EB8520000000
  %7895 = fadd fast float %7892, 0x3FC1EB8520000000
  %7896 = fadd fast float %7893, 0x3FC1EB8520000000
  %7897 = fdiv fast float %7882, %7894
  %7898 = fdiv fast float %7883, %7895
  %7899 = fdiv fast float %7884, %7896
  br label %7900

; <label>:7900                                    ; preds = %7875, %7861
  %7901 = phi float [ %7897, %7875 ], [ %7871, %7861 ]
  %7902 = phi float [ %7898, %7875 ], [ %7872, %7861 ]
  %7903 = phi float [ %7899, %7875 ], [ %7873, %7861 ]
  %7904 = call float @dx.op.unary.f32(i32 7, float %7901)  ; Saturate(value)
  %7905 = call float @dx.op.unary.f32(i32 7, float %7902)  ; Saturate(value)
  %7906 = call float @dx.op.unary.f32(i32 7, float %7903)  ; Saturate(value)
  %7907 = call float @dx.op.dot3.f32(i32 55, float %7904, float %7905, float %7906, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %7908 = fsub fast float %7904, %7907
  %7909 = fsub fast float %7905, %7907
  %7910 = fsub fast float %7906, %7907
  %7911 = fmul fast float %7908, %9
  %7912 = fmul fast float %7909, %9
  %7913 = fmul fast float %7910, %9
  %7914 = fadd fast float %7911, %7907
  %7915 = fadd fast float %7912, %7907
  %7916 = fadd fast float %7913, %7907
  %7917 = call float @dx.op.unary.f32(i32 7, float %7914)  ; Saturate(value)
  %7918 = call float @dx.op.unary.f32(i32 7, float %7915)  ; Saturate(value)
  %7919 = call float @dx.op.unary.f32(i32 7, float %7916)  ; Saturate(value)
  %7920 = fadd fast float %7917, 0xBFC70A3D80000000
  %7921 = fadd fast float %7918, 0xBFC70A3D80000000
  %7922 = fadd fast float %7919, 0xBFC70A3D80000000
  %7923 = fmul fast float %7920, %8
  %7924 = fmul fast float %7921, %8
  %7925 = fmul fast float %7922, %8
  %7926 = fadd fast float %7923, 0x3FC70A3D80000000
  %7927 = fadd fast float %7924, 0x3FC70A3D80000000
  %7928 = fadd fast float %7925, 0x3FC70A3D80000000
  %7929 = call float @dx.op.unary.f32(i32 7, float %7926)  ; Saturate(value)
  %7930 = call float @dx.op.unary.f32(i32 7, float %7927)  ; Saturate(value)
  %7931 = call float @dx.op.unary.f32(i32 7, float %7928)  ; Saturate(value)
  br label %7932

; <label>:7932                                    ; preds = %7900, %7735
  %7933 = phi float [ %7766, %7735 ], [ %7929, %7900 ]
  %7934 = phi float [ %7767, %7735 ], [ %7930, %7900 ]
  %7935 = phi float [ %7768, %7735 ], [ %7931, %7900 ]
  %7936 = fsub fast float %7933, %7467
  %7937 = fsub fast float %7934, %7468
  %7938 = fsub fast float %7935, %7469
  %7939 = fmul fast float %7936, %7722
  %7940 = fmul fast float %7937, %7722
  %7941 = fmul fast float %7938, %7722
  %7942 = fadd fast float %7939, %7467
  %7943 = fadd fast float %7940, %7468
  %7944 = fadd fast float %7941, %7469
  br label %7945

; <label>:7945                                    ; preds = %7932, %7709
  %7946 = phi float [ %7942, %7932 ], [ %7467, %7709 ]
  %7947 = phi float [ %7943, %7932 ], [ %7468, %7709 ]
  %7948 = phi float [ %7944, %7932 ], [ %7469, %7709 ]
  %7949 = add i32 %68, -1
  %7950 = call i32 @dx.op.binary.i32(i32 37, i32 %7949, i32 0)  ; IMax(a,b)
  %7951 = call i32 @dx.op.binary.i32(i32 37, i32 %71, i32 0)  ; IMax(a,b)
  %7952 = call i32 @dx.op.binary.i32(i32 38, i32 %7950, i32 %60)  ; IMin(a,b)
  %7953 = call i32 @dx.op.binary.i32(i32 38, i32 %7951, i32 %61)  ; IMin(a,b)
  %7954 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %7952, i32 %7953, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7955 = extractvalue %dx.types.ResRet.f32 %7954, 0
  %7956 = fsub fast float %7955, %89
  %7957 = call float @dx.op.unary.f32(i32 6, float %7956)  ; FAbs(value)
  %7958 = fdiv fast float %7957, %7481
  %7959 = fsub fast float 1.000000e+00, %7958
  %7960 = call float @dx.op.unary.f32(i32 7, float %7959)  ; Saturate(value)
  %7961 = fcmp fast ugt float %7960, 0.000000e+00
  br i1 %7961, label %7962, label %8183

; <label>:7962                                    ; preds = %7945
  %7963 = call i32 @dx.op.binary.i32(i32 37, i32 %7952, i32 0)  ; IMax(a,b)
  %7964 = call i32 @dx.op.binary.i32(i32 37, i32 %7953, i32 0)  ; IMax(a,b)
  %7965 = call i32 @dx.op.binary.i32(i32 38, i32 %7963, i32 %60)  ; IMin(a,b)
  %7966 = call i32 @dx.op.binary.i32(i32 38, i32 %7964, i32 %61)  ; IMin(a,b)
  %7967 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %7965, i32 %7966, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7968 = extractvalue %dx.types.ResRet.f32 %7967, 0
  %7969 = extractvalue %dx.types.ResRet.f32 %7967, 1
  %7970 = extractvalue %dx.types.ResRet.f32 %7967, 2
  %7971 = extractvalue %dx.types.ResRet.f32 %7967, 3
  %7972 = fcmp fast olt float %7971, 0.000000e+00
  br i1 %7972, label %7973, label %8007

; <label>:7973                                    ; preds = %7962
  %7974 = fcmp fast ogt float %7968, 0x3FA4B5DCC0000000
  %7975 = fcmp fast ogt float %7969, 0x3FA4B5DCC0000000
  %7976 = fcmp fast ogt float %7970, 0x3FA4B5DCC0000000
  %7977 = select i1 %7974, float 0.000000e+00, float 1.000000e+00
  %7978 = select i1 %7975, float 0.000000e+00, float 1.000000e+00
  %7979 = select i1 %7976, float 0.000000e+00, float 1.000000e+00
  %7980 = fmul fast float %7968, 0x3FB3D07220000000
  %7981 = fmul fast float %7969, 0x3FB3D07220000000
  %7982 = fmul fast float %7970, 0x3FB3D07220000000
  %7983 = fadd fast float %7968, 0x3FAC28F5C0000000
  %7984 = fadd fast float %7969, 0x3FAC28F5C0000000
  %7985 = fadd fast float %7970, 0x3FAC28F5C0000000
  %7986 = fmul fast float %7983, 0x3FEE54EDE0000000
  %7987 = fmul fast float %7984, 0x3FEE54EDE0000000
  %7988 = fmul fast float %7985, 0x3FEE54EDE0000000
  %7989 = call float @dx.op.unary.f32(i32 23, float %7986)  ; Log(value)
  %7990 = call float @dx.op.unary.f32(i32 23, float %7987)  ; Log(value)
  %7991 = call float @dx.op.unary.f32(i32 23, float %7988)  ; Log(value)
  %7992 = fmul fast float %7989, 0x4003333340000000
  %7993 = fmul fast float %7990, 0x4003333340000000
  %7994 = fmul fast float %7991, 0x4003333340000000
  %7995 = call float @dx.op.unary.f32(i32 21, float %7992)  ; Exp(value)
  %7996 = call float @dx.op.unary.f32(i32 21, float %7993)  ; Exp(value)
  %7997 = call float @dx.op.unary.f32(i32 21, float %7994)  ; Exp(value)
  %7998 = fsub fast float %7980, %7995
  %7999 = fsub fast float %7981, %7996
  %8000 = fsub fast float %7982, %7997
  %8001 = fmul fast float %7998, %7977
  %8002 = fmul fast float %7999, %7978
  %8003 = fmul fast float %8000, %7979
  %8004 = fadd fast float %8001, %7995
  %8005 = fadd fast float %8002, %7996
  %8006 = fadd fast float %8003, %7997
  br label %8170

; <label>:8007                                    ; preds = %7962
  %8008 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %7965, i32 %7966, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %8009 = extractvalue %dx.types.ResRet.f32 %8008, 0
  %8010 = fcmp fast ogt float %39, 5.000000e-01
  %8011 = fcmp fast olt float %8009, 1.000000e+00
  %8012 = and i1 %8010, %8011
  br i1 %8012, label %8013, label %8099

; <label>:8013                                    ; preds = %8007
  %8014 = sitofp i32 %7965 to float
  %8015 = sitofp i32 %7966 to float
  %8016 = fadd fast float %8014, 5.000000e-01
  %8017 = fadd fast float %8015, 5.000000e-01
  %8018 = fdiv fast float %8016, %46
  %8019 = fdiv fast float %8017, %47
  %8020 = fmul fast float %8018, 2.000000e+00
  %8021 = fmul fast float %8019, 2.000000e+00
  %8022 = fadd fast float %8020, -1.000000e+00
  %8023 = fsub fast float 1.000000e+00, %8021
  %8024 = fmul fast float %8022, %36
  %8025 = call float @dx.op.tertiary.f32(i32 46, float %8023, float %32, float %8024)  ; FMad(a,b,c)
  %8026 = call float @dx.op.tertiary.f32(i32 46, float %8009, float %28, float %8025)  ; FMad(a,b,c)
  %8027 = fadd fast float %8026, %24
  %8028 = call float @dx.op.unary.f32(i32 6, float %8027)  ; FAbs(value)
  %8029 = fcmp fast ogt float %8028, 0x3EB0C6F7A0000000
  br i1 %8029, label %8030, label %8099

; <label>:8030                                    ; preds = %8013
  %8031 = fmul fast float %8022, %35
  %8032 = call float @dx.op.tertiary.f32(i32 46, float %8023, float %31, float %8031)  ; FMad(a,b,c)
  %8033 = call float @dx.op.tertiary.f32(i32 46, float %8009, float %27, float %8032)  ; FMad(a,b,c)
  %8034 = fadd fast float %8033, %23
  %8035 = fmul fast float %8022, %34
  %8036 = call float @dx.op.tertiary.f32(i32 46, float %8023, float %30, float %8035)  ; FMad(a,b,c)
  %8037 = call float @dx.op.tertiary.f32(i32 46, float %8009, float %26, float %8036)  ; FMad(a,b,c)
  %8038 = fadd fast float %8037, %22
  %8039 = fmul fast float %8022, %33
  %8040 = call float @dx.op.tertiary.f32(i32 46, float %8023, float %29, float %8039)  ; FMad(a,b,c)
  %8041 = call float @dx.op.tertiary.f32(i32 46, float %8009, float %25, float %8040)  ; FMad(a,b,c)
  %8042 = fadd fast float %8041, %21
  %8043 = fdiv fast float %8042, %8027
  %8044 = fdiv fast float %8038, %8027
  %8045 = fdiv fast float %8034, %8027
  %8046 = fsub fast float %8043, %18
  %8047 = fsub fast float %8044, %19
  %8048 = fsub fast float %8045, %20
  %8049 = fmul fast float %8046, %8046
  %8050 = fmul fast float %8047, %8047
  %8051 = fadd fast float %8050, %8049
  %8052 = fmul fast float %8048, %8048
  %8053 = fadd fast float %8051, %8052
  %8054 = call float @dx.op.unary.f32(i32 24, float %8053)  ; Sqrt(value)
  %8055 = fsub fast float %8054, %10
  %8056 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %8055)  ; FMax(a,b)
  %8057 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %8057, label %8058, label %8081

; <label>:8058                                    ; preds = %8030
  %8059 = call float @dx.op.unary.f32(i32 6, float %8047)  ; FAbs(value)
  %8060 = fmul fast float %8059, %12
  %8061 = fcmp fast olt float %8060, 0x3F50624DE0000000
  br i1 %8061, label %8062, label %8065

; <label>:8062                                    ; preds = %8058
  %8063 = fmul fast float %8060, 5.000000e-01
  %8064 = fsub fast float 1.000000e+00, %8063
  br label %8070

; <label>:8065                                    ; preds = %8058
  %8066 = fmul fast float %8060, 0xBFF7154760000000
  %8067 = call float @dx.op.unary.f32(i32 21, float %8066)  ; Exp(value)
  %8068 = fsub fast float 1.000000e+00, %8067
  %8069 = fdiv fast float %8068, %8060
  br label %8070

; <label>:8070                                    ; preds = %8065, %8062
  %8071 = phi float [ %8064, %8062 ], [ %8069, %8065 ]
  %8072 = call float @dx.op.binary.f32(i32 36, float %8044, float %19)  ; FMin(a,b)
  %8073 = fsub fast float %8072, %11
  %8074 = fmul fast float %12, %8073
  %8075 = fsub fast float -0.000000e+00, %8074
  %8076 = call float @dx.op.binary.f32(i32 35, float %8075, float -4.000000e+01)  ; FMax(a,b)
  %8077 = call float @dx.op.binary.f32(i32 36, float %8076, float 5.000000e+00)  ; FMin(a,b)
  %8078 = fmul fast float %8077, 0x3FF7154760000000
  %8079 = call float @dx.op.unary.f32(i32 21, float %8078)  ; Exp(value)
  %8080 = fmul fast float %8079, %8071
  br label %8081

; <label>:8081                                    ; preds = %8070, %8030
  %8082 = phi float [ %8080, %8070 ], [ 1.000000e+00, %8030 ]
  %8083 = fmul fast float %8056, %17
  %8084 = fmul fast float %8083, %8082
  %8085 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %8084)  ; FMin(a,b)
  %8086 = fmul fast float %8085, 0xBFF7154760000000
  %8087 = call float @dx.op.unary.f32(i32 21, float %8086)  ; Exp(value)
  %8088 = fsub fast float 1.000000e+00, %8087
  %8089 = call float @dx.op.binary.f32(i32 36, float %13, float %8088)  ; FMin(a,b)
  %8090 = fsub fast float %14, %7968
  %8091 = fsub fast float %15, %7969
  %8092 = fsub fast float %16, %7970
  %8093 = fmul fast float %8089, %8090
  %8094 = fmul fast float %8089, %8091
  %8095 = fmul fast float %8089, %8092
  %8096 = fadd fast float %8093, %7968
  %8097 = fadd fast float %8094, %7969
  %8098 = fadd fast float %8095, %7970
  br label %8099

; <label>:8099                                    ; preds = %8081, %8013, %8007
  %8100 = phi float [ %8096, %8081 ], [ %7968, %8013 ], [ %7968, %8007 ]
  %8101 = phi float [ %8097, %8081 ], [ %7969, %8013 ], [ %7969, %8007 ]
  %8102 = phi float [ %8098, %8081 ], [ %7970, %8013 ], [ %7970, %8007 ]
  %8103 = fadd fast float %6, 1.000000e+00
  %8104 = fadd fast float %7, 1.000000e+00
  %8105 = fsub fast float 1.000000e+00, %6
  %8106 = fmul fast float %37, %8103
  %8107 = fmul fast float %37, %8104
  %8108 = fmul fast float %37, %8105
  %8109 = fmul fast float %8106, %8100
  %8110 = fmul fast float %8107, %8101
  %8111 = fmul fast float %8108, %8102
  %8112 = fcmp fast ult float %38, 5.000000e-01
  br i1 %8112, label %8138, label %8113

; <label>:8113                                    ; preds = %8099
  %8114 = fmul fast float %8109, 0x4004147AE0000000
  %8115 = fmul fast float %8110, 0x4004147AE0000000
  %8116 = fmul fast float %8111, 0x4004147AE0000000
  %8117 = fadd fast float %8114, 0x3F9EB851E0000000
  %8118 = fadd fast float %8115, 0x3F9EB851E0000000
  %8119 = fadd fast float %8116, 0x3F9EB851E0000000
  %8120 = fmul fast float %8117, %8109
  %8121 = fmul fast float %8118, %8110
  %8122 = fmul fast float %8119, %8111
  %8123 = fmul fast float %8109, 0x400370A3E0000000
  %8124 = fmul fast float %8110, 0x400370A3E0000000
  %8125 = fmul fast float %8111, 0x400370A3E0000000
  %8126 = fadd fast float %8123, 0x3FE2E147A0000000
  %8127 = fadd fast float %8124, 0x3FE2E147A0000000
  %8128 = fadd fast float %8125, 0x3FE2E147A0000000
  %8129 = fmul fast float %8126, %8109
  %8130 = fmul fast float %8127, %8110
  %8131 = fmul fast float %8128, %8111
  %8132 = fadd fast float %8129, 0x3FC1EB8520000000
  %8133 = fadd fast float %8130, 0x3FC1EB8520000000
  %8134 = fadd fast float %8131, 0x3FC1EB8520000000
  %8135 = fdiv fast float %8120, %8132
  %8136 = fdiv fast float %8121, %8133
  %8137 = fdiv fast float %8122, %8134
  br label %8138

; <label>:8138                                    ; preds = %8113, %8099
  %8139 = phi float [ %8135, %8113 ], [ %8109, %8099 ]
  %8140 = phi float [ %8136, %8113 ], [ %8110, %8099 ]
  %8141 = phi float [ %8137, %8113 ], [ %8111, %8099 ]
  %8142 = call float @dx.op.unary.f32(i32 7, float %8139)  ; Saturate(value)
  %8143 = call float @dx.op.unary.f32(i32 7, float %8140)  ; Saturate(value)
  %8144 = call float @dx.op.unary.f32(i32 7, float %8141)  ; Saturate(value)
  %8145 = call float @dx.op.dot3.f32(i32 55, float %8142, float %8143, float %8144, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %8146 = fsub fast float %8142, %8145
  %8147 = fsub fast float %8143, %8145
  %8148 = fsub fast float %8144, %8145
  %8149 = fmul fast float %8146, %9
  %8150 = fmul fast float %8147, %9
  %8151 = fmul fast float %8148, %9
  %8152 = fadd fast float %8149, %8145
  %8153 = fadd fast float %8150, %8145
  %8154 = fadd fast float %8151, %8145
  %8155 = call float @dx.op.unary.f32(i32 7, float %8152)  ; Saturate(value)
  %8156 = call float @dx.op.unary.f32(i32 7, float %8153)  ; Saturate(value)
  %8157 = call float @dx.op.unary.f32(i32 7, float %8154)  ; Saturate(value)
  %8158 = fadd fast float %8155, 0xBFC70A3D80000000
  %8159 = fadd fast float %8156, 0xBFC70A3D80000000
  %8160 = fadd fast float %8157, 0xBFC70A3D80000000
  %8161 = fmul fast float %8158, %8
  %8162 = fmul fast float %8159, %8
  %8163 = fmul fast float %8160, %8
  %8164 = fadd fast float %8161, 0x3FC70A3D80000000
  %8165 = fadd fast float %8162, 0x3FC70A3D80000000
  %8166 = fadd fast float %8163, 0x3FC70A3D80000000
  %8167 = call float @dx.op.unary.f32(i32 7, float %8164)  ; Saturate(value)
  %8168 = call float @dx.op.unary.f32(i32 7, float %8165)  ; Saturate(value)
  %8169 = call float @dx.op.unary.f32(i32 7, float %8166)  ; Saturate(value)
  br label %8170

; <label>:8170                                    ; preds = %8138, %7973
  %8171 = phi float [ %8004, %7973 ], [ %8167, %8138 ]
  %8172 = phi float [ %8005, %7973 ], [ %8168, %8138 ]
  %8173 = phi float [ %8006, %7973 ], [ %8169, %8138 ]
  %8174 = fsub fast float %8171, %7467
  %8175 = fsub fast float %8172, %7468
  %8176 = fsub fast float %8173, %7469
  %8177 = fmul fast float %8174, %7960
  %8178 = fmul fast float %8175, %7960
  %8179 = fmul fast float %8176, %7960
  %8180 = fadd fast float %8177, %7467
  %8181 = fadd fast float %8178, %7468
  %8182 = fadd fast float %8179, %7469
  br label %8183

; <label>:8183                                    ; preds = %8170, %7945
  %8184 = phi float [ %8180, %8170 ], [ %7467, %7945 ]
  %8185 = phi float [ %8181, %8170 ], [ %7468, %7945 ]
  %8186 = phi float [ %8182, %8170 ], [ %7469, %7945 ]
  %8187 = add i32 %68, 1
  %8188 = call i32 @dx.op.binary.i32(i32 37, i32 %8187, i32 0)  ; IMax(a,b)
  %8189 = call i32 @dx.op.binary.i32(i32 38, i32 %8188, i32 %60)  ; IMin(a,b)
  %8190 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %8189, i32 %7953, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %8191 = extractvalue %dx.types.ResRet.f32 %8190, 0
  %8192 = fsub fast float %8191, %89
  %8193 = call float @dx.op.unary.f32(i32 6, float %8192)  ; FAbs(value)
  %8194 = fdiv fast float %8193, %7481
  %8195 = fsub fast float 1.000000e+00, %8194
  %8196 = call float @dx.op.unary.f32(i32 7, float %8195)  ; Saturate(value)
  %8197 = fcmp fast ugt float %8196, 0.000000e+00
  br i1 %8197, label %8198, label %8419

; <label>:8198                                    ; preds = %8183
  %8199 = call i32 @dx.op.binary.i32(i32 37, i32 %8189, i32 0)  ; IMax(a,b)
  %8200 = call i32 @dx.op.binary.i32(i32 37, i32 %7953, i32 0)  ; IMax(a,b)
  %8201 = call i32 @dx.op.binary.i32(i32 38, i32 %8199, i32 %60)  ; IMin(a,b)
  %8202 = call i32 @dx.op.binary.i32(i32 38, i32 %8200, i32 %61)  ; IMin(a,b)
  %8203 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %8201, i32 %8202, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %8204 = extractvalue %dx.types.ResRet.f32 %8203, 0
  %8205 = extractvalue %dx.types.ResRet.f32 %8203, 1
  %8206 = extractvalue %dx.types.ResRet.f32 %8203, 2
  %8207 = extractvalue %dx.types.ResRet.f32 %8203, 3
  %8208 = fcmp fast olt float %8207, 0.000000e+00
  br i1 %8208, label %8209, label %8243

; <label>:8209                                    ; preds = %8198
  %8210 = fcmp fast ogt float %8204, 0x3FA4B5DCC0000000
  %8211 = fcmp fast ogt float %8205, 0x3FA4B5DCC0000000
  %8212 = fcmp fast ogt float %8206, 0x3FA4B5DCC0000000
  %8213 = select i1 %8210, float 0.000000e+00, float 1.000000e+00
  %8214 = select i1 %8211, float 0.000000e+00, float 1.000000e+00
  %8215 = select i1 %8212, float 0.000000e+00, float 1.000000e+00
  %8216 = fmul fast float %8204, 0x3FB3D07220000000
  %8217 = fmul fast float %8205, 0x3FB3D07220000000
  %8218 = fmul fast float %8206, 0x3FB3D07220000000
  %8219 = fadd fast float %8204, 0x3FAC28F5C0000000
  %8220 = fadd fast float %8205, 0x3FAC28F5C0000000
  %8221 = fadd fast float %8206, 0x3FAC28F5C0000000
  %8222 = fmul fast float %8219, 0x3FEE54EDE0000000
  %8223 = fmul fast float %8220, 0x3FEE54EDE0000000
  %8224 = fmul fast float %8221, 0x3FEE54EDE0000000
  %8225 = call float @dx.op.unary.f32(i32 23, float %8222)  ; Log(value)
  %8226 = call float @dx.op.unary.f32(i32 23, float %8223)  ; Log(value)
  %8227 = call float @dx.op.unary.f32(i32 23, float %8224)  ; Log(value)
  %8228 = fmul fast float %8225, 0x4003333340000000
  %8229 = fmul fast float %8226, 0x4003333340000000
  %8230 = fmul fast float %8227, 0x4003333340000000
  %8231 = call float @dx.op.unary.f32(i32 21, float %8228)  ; Exp(value)
  %8232 = call float @dx.op.unary.f32(i32 21, float %8229)  ; Exp(value)
  %8233 = call float @dx.op.unary.f32(i32 21, float %8230)  ; Exp(value)
  %8234 = fsub fast float %8216, %8231
  %8235 = fsub fast float %8217, %8232
  %8236 = fsub fast float %8218, %8233
  %8237 = fmul fast float %8234, %8213
  %8238 = fmul fast float %8235, %8214
  %8239 = fmul fast float %8236, %8215
  %8240 = fadd fast float %8237, %8231
  %8241 = fadd fast float %8238, %8232
  %8242 = fadd fast float %8239, %8233
  br label %8406

; <label>:8243                                    ; preds = %8198
  %8244 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %8201, i32 %8202, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %8245 = extractvalue %dx.types.ResRet.f32 %8244, 0
  %8246 = fcmp fast ogt float %39, 5.000000e-01
  %8247 = fcmp fast olt float %8245, 1.000000e+00
  %8248 = and i1 %8246, %8247
  br i1 %8248, label %8249, label %8335

; <label>:8249                                    ; preds = %8243
  %8250 = sitofp i32 %8201 to float
  %8251 = sitofp i32 %8202 to float
  %8252 = fadd fast float %8250, 5.000000e-01
  %8253 = fadd fast float %8251, 5.000000e-01
  %8254 = fdiv fast float %8252, %46
  %8255 = fdiv fast float %8253, %47
  %8256 = fmul fast float %8254, 2.000000e+00
  %8257 = fmul fast float %8255, 2.000000e+00
  %8258 = fadd fast float %8256, -1.000000e+00
  %8259 = fsub fast float 1.000000e+00, %8257
  %8260 = fmul fast float %8258, %36
  %8261 = call float @dx.op.tertiary.f32(i32 46, float %8259, float %32, float %8260)  ; FMad(a,b,c)
  %8262 = call float @dx.op.tertiary.f32(i32 46, float %8245, float %28, float %8261)  ; FMad(a,b,c)
  %8263 = fadd fast float %8262, %24
  %8264 = call float @dx.op.unary.f32(i32 6, float %8263)  ; FAbs(value)
  %8265 = fcmp fast ogt float %8264, 0x3EB0C6F7A0000000
  br i1 %8265, label %8266, label %8335

; <label>:8266                                    ; preds = %8249
  %8267 = fmul fast float %8258, %35
  %8268 = call float @dx.op.tertiary.f32(i32 46, float %8259, float %31, float %8267)  ; FMad(a,b,c)
  %8269 = call float @dx.op.tertiary.f32(i32 46, float %8245, float %27, float %8268)  ; FMad(a,b,c)
  %8270 = fadd fast float %8269, %23
  %8271 = fmul fast float %8258, %34
  %8272 = call float @dx.op.tertiary.f32(i32 46, float %8259, float %30, float %8271)  ; FMad(a,b,c)
  %8273 = call float @dx.op.tertiary.f32(i32 46, float %8245, float %26, float %8272)  ; FMad(a,b,c)
  %8274 = fadd fast float %8273, %22
  %8275 = fmul fast float %8258, %33
  %8276 = call float @dx.op.tertiary.f32(i32 46, float %8259, float %29, float %8275)  ; FMad(a,b,c)
  %8277 = call float @dx.op.tertiary.f32(i32 46, float %8245, float %25, float %8276)  ; FMad(a,b,c)
  %8278 = fadd fast float %8277, %21
  %8279 = fdiv fast float %8278, %8263
  %8280 = fdiv fast float %8274, %8263
  %8281 = fdiv fast float %8270, %8263
  %8282 = fsub fast float %8279, %18
  %8283 = fsub fast float %8280, %19
  %8284 = fsub fast float %8281, %20
  %8285 = fmul fast float %8282, %8282
  %8286 = fmul fast float %8283, %8283
  %8287 = fadd fast float %8286, %8285
  %8288 = fmul fast float %8284, %8284
  %8289 = fadd fast float %8287, %8288
  %8290 = call float @dx.op.unary.f32(i32 24, float %8289)  ; Sqrt(value)
  %8291 = fsub fast float %8290, %10
  %8292 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %8291)  ; FMax(a,b)
  %8293 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %8293, label %8294, label %8317

; <label>:8294                                    ; preds = %8266
  %8295 = call float @dx.op.unary.f32(i32 6, float %8283)  ; FAbs(value)
  %8296 = fmul fast float %8295, %12
  %8297 = fcmp fast olt float %8296, 0x3F50624DE0000000
  br i1 %8297, label %8298, label %8301

; <label>:8298                                    ; preds = %8294
  %8299 = fmul fast float %8296, 5.000000e-01
  %8300 = fsub fast float 1.000000e+00, %8299
  br label %8306

; <label>:8301                                    ; preds = %8294
  %8302 = fmul fast float %8296, 0xBFF7154760000000
  %8303 = call float @dx.op.unary.f32(i32 21, float %8302)  ; Exp(value)
  %8304 = fsub fast float 1.000000e+00, %8303
  %8305 = fdiv fast float %8304, %8296
  br label %8306

; <label>:8306                                    ; preds = %8301, %8298
  %8307 = phi float [ %8300, %8298 ], [ %8305, %8301 ]
  %8308 = call float @dx.op.binary.f32(i32 36, float %8280, float %19)  ; FMin(a,b)
  %8309 = fsub fast float %8308, %11
  %8310 = fmul fast float %12, %8309
  %8311 = fsub fast float -0.000000e+00, %8310
  %8312 = call float @dx.op.binary.f32(i32 35, float %8311, float -4.000000e+01)  ; FMax(a,b)
  %8313 = call float @dx.op.binary.f32(i32 36, float %8312, float 5.000000e+00)  ; FMin(a,b)
  %8314 = fmul fast float %8313, 0x3FF7154760000000
  %8315 = call float @dx.op.unary.f32(i32 21, float %8314)  ; Exp(value)
  %8316 = fmul fast float %8315, %8307
  br label %8317

; <label>:8317                                    ; preds = %8306, %8266
  %8318 = phi float [ %8316, %8306 ], [ 1.000000e+00, %8266 ]
  %8319 = fmul fast float %8292, %17
  %8320 = fmul fast float %8319, %8318
  %8321 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %8320)  ; FMin(a,b)
  %8322 = fmul fast float %8321, 0xBFF7154760000000
  %8323 = call float @dx.op.unary.f32(i32 21, float %8322)  ; Exp(value)
  %8324 = fsub fast float 1.000000e+00, %8323
  %8325 = call float @dx.op.binary.f32(i32 36, float %13, float %8324)  ; FMin(a,b)
  %8326 = fsub fast float %14, %8204
  %8327 = fsub fast float %15, %8205
  %8328 = fsub fast float %16, %8206
  %8329 = fmul fast float %8325, %8326
  %8330 = fmul fast float %8325, %8327
  %8331 = fmul fast float %8325, %8328
  %8332 = fadd fast float %8329, %8204
  %8333 = fadd fast float %8330, %8205
  %8334 = fadd fast float %8331, %8206
  br label %8335

; <label>:8335                                    ; preds = %8317, %8249, %8243
  %8336 = phi float [ %8332, %8317 ], [ %8204, %8249 ], [ %8204, %8243 ]
  %8337 = phi float [ %8333, %8317 ], [ %8205, %8249 ], [ %8205, %8243 ]
  %8338 = phi float [ %8334, %8317 ], [ %8206, %8249 ], [ %8206, %8243 ]
  %8339 = fadd fast float %6, 1.000000e+00
  %8340 = fadd fast float %7, 1.000000e+00
  %8341 = fsub fast float 1.000000e+00, %6
  %8342 = fmul fast float %37, %8339
  %8343 = fmul fast float %37, %8340
  %8344 = fmul fast float %37, %8341
  %8345 = fmul fast float %8342, %8336
  %8346 = fmul fast float %8343, %8337
  %8347 = fmul fast float %8344, %8338
  %8348 = fcmp fast ult float %38, 5.000000e-01
  br i1 %8348, label %8374, label %8349

; <label>:8349                                    ; preds = %8335
  %8350 = fmul fast float %8345, 0x4004147AE0000000
  %8351 = fmul fast float %8346, 0x4004147AE0000000
  %8352 = fmul fast float %8347, 0x4004147AE0000000
  %8353 = fadd fast float %8350, 0x3F9EB851E0000000
  %8354 = fadd fast float %8351, 0x3F9EB851E0000000
  %8355 = fadd fast float %8352, 0x3F9EB851E0000000
  %8356 = fmul fast float %8353, %8345
  %8357 = fmul fast float %8354, %8346
  %8358 = fmul fast float %8355, %8347
  %8359 = fmul fast float %8345, 0x400370A3E0000000
  %8360 = fmul fast float %8346, 0x400370A3E0000000
  %8361 = fmul fast float %8347, 0x400370A3E0000000
  %8362 = fadd fast float %8359, 0x3FE2E147A0000000
  %8363 = fadd fast float %8360, 0x3FE2E147A0000000
  %8364 = fadd fast float %8361, 0x3FE2E147A0000000
  %8365 = fmul fast float %8362, %8345
  %8366 = fmul fast float %8363, %8346
  %8367 = fmul fast float %8364, %8347
  %8368 = fadd fast float %8365, 0x3FC1EB8520000000
  %8369 = fadd fast float %8366, 0x3FC1EB8520000000
  %8370 = fadd fast float %8367, 0x3FC1EB8520000000
  %8371 = fdiv fast float %8356, %8368
  %8372 = fdiv fast float %8357, %8369
  %8373 = fdiv fast float %8358, %8370
  br label %8374

; <label>:8374                                    ; preds = %8349, %8335
  %8375 = phi float [ %8371, %8349 ], [ %8345, %8335 ]
  %8376 = phi float [ %8372, %8349 ], [ %8346, %8335 ]
  %8377 = phi float [ %8373, %8349 ], [ %8347, %8335 ]
  %8378 = call float @dx.op.unary.f32(i32 7, float %8375)  ; Saturate(value)
  %8379 = call float @dx.op.unary.f32(i32 7, float %8376)  ; Saturate(value)
  %8380 = call float @dx.op.unary.f32(i32 7, float %8377)  ; Saturate(value)
  %8381 = call float @dx.op.dot3.f32(i32 55, float %8378, float %8379, float %8380, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %8382 = fsub fast float %8378, %8381
  %8383 = fsub fast float %8379, %8381
  %8384 = fsub fast float %8380, %8381
  %8385 = fmul fast float %8382, %9
  %8386 = fmul fast float %8383, %9
  %8387 = fmul fast float %8384, %9
  %8388 = fadd fast float %8385, %8381
  %8389 = fadd fast float %8386, %8381
  %8390 = fadd fast float %8387, %8381
  %8391 = call float @dx.op.unary.f32(i32 7, float %8388)  ; Saturate(value)
  %8392 = call float @dx.op.unary.f32(i32 7, float %8389)  ; Saturate(value)
  %8393 = call float @dx.op.unary.f32(i32 7, float %8390)  ; Saturate(value)
  %8394 = fadd fast float %8391, 0xBFC70A3D80000000
  %8395 = fadd fast float %8392, 0xBFC70A3D80000000
  %8396 = fadd fast float %8393, 0xBFC70A3D80000000
  %8397 = fmul fast float %8394, %8
  %8398 = fmul fast float %8395, %8
  %8399 = fmul fast float %8396, %8
  %8400 = fadd fast float %8397, 0x3FC70A3D80000000
  %8401 = fadd fast float %8398, 0x3FC70A3D80000000
  %8402 = fadd fast float %8399, 0x3FC70A3D80000000
  %8403 = call float @dx.op.unary.f32(i32 7, float %8400)  ; Saturate(value)
  %8404 = call float @dx.op.unary.f32(i32 7, float %8401)  ; Saturate(value)
  %8405 = call float @dx.op.unary.f32(i32 7, float %8402)  ; Saturate(value)
  br label %8406

; <label>:8406                                    ; preds = %8374, %8209
  %8407 = phi float [ %8240, %8209 ], [ %8403, %8374 ]
  %8408 = phi float [ %8241, %8209 ], [ %8404, %8374 ]
  %8409 = phi float [ %8242, %8209 ], [ %8405, %8374 ]
  %8410 = fsub fast float %8407, %7467
  %8411 = fsub fast float %8408, %7468
  %8412 = fsub fast float %8409, %7469
  %8413 = fmul fast float %8410, %8196
  %8414 = fmul fast float %8411, %8196
  %8415 = fmul fast float %8412, %8196
  %8416 = fadd fast float %8413, %7467
  %8417 = fadd fast float %8414, %7468
  %8418 = fadd fast float %8415, %7469
  br label %8419

; <label>:8419                                    ; preds = %8406, %8183
  %8420 = phi float [ %8416, %8406 ], [ %7467, %8183 ]
  %8421 = phi float [ %8417, %8406 ], [ %7468, %8183 ]
  %8422 = phi float [ %8418, %8406 ], [ %7469, %8183 ]
  %8423 = call float @dx.op.binary.f32(i32 36, float %8184, float %8420)  ; FMin(a,b)
  %8424 = call float @dx.op.binary.f32(i32 36, float %8185, float %8421)  ; FMin(a,b)
  %8425 = call float @dx.op.binary.f32(i32 36, float %8186, float %8422)  ; FMin(a,b)
  %8426 = call float @dx.op.binary.f32(i32 36, float %7710, float %7946)  ; FMin(a,b)
  %8427 = call float @dx.op.binary.f32(i32 36, float %7711, float %7947)  ; FMin(a,b)
  %8428 = call float @dx.op.binary.f32(i32 36, float %7712, float %7948)  ; FMin(a,b)
  %8429 = call float @dx.op.binary.f32(i32 36, float %8426, float %8423)  ; FMin(a,b)
  %8430 = call float @dx.op.binary.f32(i32 36, float %8427, float %8424)  ; FMin(a,b)
  %8431 = call float @dx.op.binary.f32(i32 36, float %8428, float %8425)  ; FMin(a,b)
  %8432 = call float @dx.op.binary.f32(i32 36, float %7467, float %8429)  ; FMin(a,b)
  %8433 = call float @dx.op.binary.f32(i32 36, float %7468, float %8430)  ; FMin(a,b)
  %8434 = call float @dx.op.binary.f32(i32 36, float %7469, float %8431)  ; FMin(a,b)
  %8435 = call float @dx.op.binary.f32(i32 35, float %8184, float %8420)  ; FMax(a,b)
  %8436 = call float @dx.op.binary.f32(i32 35, float %8185, float %8421)  ; FMax(a,b)
  %8437 = call float @dx.op.binary.f32(i32 35, float %8186, float %8422)  ; FMax(a,b)
  %8438 = call float @dx.op.binary.f32(i32 35, float %7710, float %7946)  ; FMax(a,b)
  %8439 = call float @dx.op.binary.f32(i32 35, float %7711, float %7947)  ; FMax(a,b)
  %8440 = call float @dx.op.binary.f32(i32 35, float %7712, float %7948)  ; FMax(a,b)
  %8441 = call float @dx.op.binary.f32(i32 35, float %8438, float %8435)  ; FMax(a,b)
  %8442 = call float @dx.op.binary.f32(i32 35, float %8439, float %8436)  ; FMax(a,b)
  %8443 = call float @dx.op.binary.f32(i32 35, float %8440, float %8437)  ; FMax(a,b)
  %8444 = call float @dx.op.binary.f32(i32 35, float %7467, float %8441)  ; FMax(a,b)
  %8445 = call float @dx.op.binary.f32(i32 35, float %7468, float %8442)  ; FMax(a,b)
  %8446 = call float @dx.op.binary.f32(i32 35, float %7469, float %8443)  ; FMax(a,b)
  %8447 = fsub fast float %8444, %8432
  %8448 = fsub fast float %8445, %8433
  %8449 = fsub fast float %8446, %8434
  %8450 = call float @dx.op.unary.f32(i32 6, float %8447)  ; FAbs(value)
  %8451 = call float @dx.op.unary.f32(i32 6, float %8448)  ; FAbs(value)
  %8452 = call float @dx.op.unary.f32(i32 6, float %8449)  ; FAbs(value)
  %8453 = call float @dx.op.binary.f32(i32 35, float %8451, float %8452)  ; FMax(a,b)
  %8454 = call float @dx.op.binary.f32(i32 35, float %8450, float %8453)  ; FMax(a,b)
  %8455 = call float @dx.op.binary.f32(i32 35, float %8445, float %8446)  ; FMax(a,b)
  %8456 = call float @dx.op.binary.f32(i32 35, float %8444, float %8455)  ; FMax(a,b)
  %8457 = fmul fast float %8456, 1.250000e-01
  %8458 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %8457)  ; FMax(a,b)
  %8459 = fcmp fast ogt float %8454, %8458
  br i1 %8459, label %8460, label %8522

; <label>:8460                                    ; preds = %8419
  %8461 = fsub fast float %7710, %7946
  %8462 = fsub fast float %7711, %7947
  %8463 = fsub fast float %7712, %7948
  %8464 = call float @dx.op.unary.f32(i32 6, float %8461)  ; FAbs(value)
  %8465 = call float @dx.op.unary.f32(i32 6, float %8462)  ; FAbs(value)
  %8466 = call float @dx.op.unary.f32(i32 6, float %8463)  ; FAbs(value)
  %8467 = call float @dx.op.binary.f32(i32 35, float %8465, float %8466)  ; FMax(a,b)
  %8468 = call float @dx.op.binary.f32(i32 35, float %8464, float %8467)  ; FMax(a,b)
  %8469 = fsub fast float %8184, %8420
  %8470 = fsub fast float %8185, %8421
  %8471 = fsub fast float %8186, %8422
  %8472 = call float @dx.op.unary.f32(i32 6, float %8469)  ; FAbs(value)
  %8473 = call float @dx.op.unary.f32(i32 6, float %8470)  ; FAbs(value)
  %8474 = call float @dx.op.unary.f32(i32 6, float %8471)  ; FAbs(value)
  %8475 = call float @dx.op.binary.f32(i32 35, float %8473, float %8474)  ; FMax(a,b)
  %8476 = call float @dx.op.binary.f32(i32 35, float %8472, float %8475)  ; FMax(a,b)
  %8477 = fcmp fast olt float %8468, %8476
  %8478 = select i1 %8477, float %7710, float %8184
  %8479 = select i1 %8477, float %7711, float %8185
  %8480 = select i1 %8477, float %7712, float %8186
  %8481 = select i1 %8477, float %7946, float %8420
  %8482 = select i1 %8477, float %7947, float %8421
  %8483 = select i1 %8477, float %7948, float %8422
  %8484 = fsub fast float %7467, %8481
  %8485 = fsub fast float %7468, %8482
  %8486 = fsub fast float %7469, %8483
  %8487 = fsub fast float %7467, %8478
  %8488 = fsub fast float %7468, %8479
  %8489 = fsub fast float %7469, %8480
  %8490 = call float @dx.op.dot3.f32(i32 55, float %8487, float %8488, float %8489, float %8484, float %8485, float %8486)  ; Dot3(ax,ay,az,bx,by,bz)
  %8491 = fcmp fast ogt float %8490, 0.000000e+00
  br i1 %8491, label %8492, label %8504

; <label>:8492                                    ; preds = %8460
  %8493 = fsub fast float %8478, %8481
  %8494 = fsub fast float %8479, %8482
  %8495 = fsub fast float %8480, %8483
  %8496 = call float @dx.op.unary.f32(i32 6, float %8493)  ; FAbs(value)
  %8497 = call float @dx.op.unary.f32(i32 6, float %8494)  ; FAbs(value)
  %8498 = call float @dx.op.unary.f32(i32 6, float %8495)  ; FAbs(value)
  %8499 = call float @dx.op.binary.f32(i32 35, float %8497, float %8498)  ; FMax(a,b)
  %8500 = call float @dx.op.binary.f32(i32 35, float %8496, float %8499)  ; FMax(a,b)
  %8501 = fmul fast float %8454, 2.500000e-01
  %8502 = fcmp fast olt float %8500, %8501
  %8503 = select i1 %8502, float 5.000000e-01, float 1.000000e+00
  br label %8504

; <label>:8504                                    ; preds = %8492, %8460
  %8505 = phi float [ 1.000000e+00, %8460 ], [ %8503, %8492 ]
  %8506 = fmul fast float %8505, %3
  %8507 = fadd fast float %8478, %8481
  %8508 = fadd fast float %8479, %8482
  %8509 = fadd fast float %8480, %8483
  %8510 = fmul fast float %8507, 5.000000e-01
  %8511 = fmul fast float %8508, 5.000000e-01
  %8512 = fmul fast float %8509, 5.000000e-01
  %8513 = fsub fast float %8510, %7467
  %8514 = fsub fast float %8511, %7468
  %8515 = fsub fast float %8512, %7469
  %8516 = fmul fast float %8506, %8513
  %8517 = fmul fast float %8506, %8514
  %8518 = fmul fast float %8506, %8515
  %8519 = fadd fast float %8516, %7467
  %8520 = fadd fast float %8517, %7468
  %8521 = fadd fast float %8518, %7469
  br label %8522

; <label>:8522                                    ; preds = %8504, %8419, %7438, %7274, %3472, %3387, %2870, %1000
  %8523 = phi float [ %395, %1000 ], [ %1631, %2870 ], [ %4746, %7274 ], [ %1631, %3472 ], [ %1631, %3387 ], [ %4746, %8419 ], [ %4746, %8504 ], [ %4746, %7438 ]
  %8524 = phi float [ %396, %1000 ], [ %1632, %2870 ], [ %4747, %7274 ], [ %1632, %3472 ], [ %1632, %3387 ], [ %4747, %8419 ], [ %4747, %8504 ], [ %4747, %7438 ]
  %8525 = phi float [ %397, %1000 ], [ %1633, %2870 ], [ %4748, %7274 ], [ %1633, %3472 ], [ %1633, %3387 ], [ %4748, %8419 ], [ %4748, %8504 ], [ %4748, %7438 ]
  %8526 = phi float [ %1005, %1000 ], [ %1005, %2870 ], [ %4749, %7274 ], [ %1005, %3472 ], [ %1005, %3387 ], [ %4749, %8419 ], [ %4749, %8504 ], [ %4749, %7438 ]
  %8527 = phi float [ %597, %1000 ], [ %2251, %2870 ], [ %6005, %7274 ], [ %2251, %3472 ], [ %2251, %3387 ], [ %6005, %8419 ], [ %6005, %8504 ], [ %6005, %7438 ]
  %8528 = phi float [ %598, %1000 ], [ %2252, %2870 ], [ %6006, %7274 ], [ %2252, %3472 ], [ %2252, %3387 ], [ %6006, %8419 ], [ %6006, %8504 ], [ %6006, %7438 ]
  %8529 = phi float [ %599, %1000 ], [ %2253, %2870 ], [ %6007, %7274 ], [ %2253, %3472 ], [ %2253, %3387 ], [ %6007, %8419 ], [ %6007, %8504 ], [ %6007, %7438 ]
  %8530 = phi float [ %1007, %1000 ], [ %1007, %2870 ], [ %6008, %7274 ], [ %1007, %3472 ], [ %1007, %3387 ], [ %6008, %8419 ], [ %6008, %8504 ], [ %6008, %7438 ]
  %8531 = phi float [ %799, %1000 ], [ %2871, %2870 ], [ %7264, %7274 ], [ %2871, %3472 ], [ %2871, %3387 ], [ %7264, %8419 ], [ %7264, %8504 ], [ %7264, %7438 ]
  %8532 = phi float [ %800, %1000 ], [ %2872, %2870 ], [ %7265, %7274 ], [ %2872, %3472 ], [ %2872, %3387 ], [ %7265, %8419 ], [ %7265, %8504 ], [ %7265, %7438 ]
  %8533 = phi float [ %801, %1000 ], [ %2873, %2870 ], [ %7266, %7274 ], [ %2873, %3472 ], [ %2873, %3387 ], [ %7266, %8419 ], [ %7266, %8504 ], [ %7266, %7438 ]
  %8534 = phi float [ %1009, %1000 ], [ %1009, %2870 ], [ %7267, %7274 ], [ %1009, %3472 ], [ %1009, %3387 ], [ %7267, %8419 ], [ %7267, %8504 ], [ %7267, %7438 ]
  %8535 = phi float [ %1001, %1000 ], [ %1001, %2870 ], [ %7305, %7274 ], [ %3487, %3472 ], [ %1001, %3387 ], [ %7467, %8419 ], [ %8519, %8504 ], [ %7467, %7438 ]
  %8536 = phi float [ %1002, %1000 ], [ %1002, %2870 ], [ %7306, %7274 ], [ %3488, %3472 ], [ %1002, %3387 ], [ %7468, %8419 ], [ %8520, %8504 ], [ %7468, %7438 ]
  %8537 = phi float [ %1003, %1000 ], [ %1003, %2870 ], [ %7307, %7274 ], [ %3489, %3472 ], [ %1003, %3387 ], [ %7469, %8419 ], [ %8521, %8504 ], [ %7469, %7438 ]
  %8538 = phi float [ %1011, %1000 ], [ %1011, %2870 ], [ %7308, %7274 ], [ %1011, %3472 ], [ %1011, %3387 ], [ %7272, %8419 ], [ %7272, %8504 ], [ %7272, %7438 ]
  %8539 = fmul fast float %8523, %163
  %8540 = fmul fast float %8524, %163
  %8541 = fmul fast float %8525, %163
  %8542 = fmul fast float %8527, %164
  %8543 = fmul fast float %8528, %164
  %8544 = fmul fast float %8529, %164
  %8545 = fadd fast float %8542, %8539
  %8546 = fadd fast float %8543, %8540
  %8547 = fadd fast float %8544, %8541
  %8548 = fmul fast float %8531, %165
  %8549 = fmul fast float %8532, %165
  %8550 = fmul fast float %8533, %165
  %8551 = fadd fast float %8545, %8548
  %8552 = fadd fast float %8546, %8549
  %8553 = fadd fast float %8547, %8550
  %8554 = fmul fast float %8535, %166
  %8555 = fmul fast float %8536, %166
  %8556 = fmul fast float %8537, %166
  %8557 = fadd fast float %8551, %8554
  %8558 = fadd fast float %8552, %8555
  %8559 = fadd fast float %8553, %8556
  %8560 = fcmp fast ogt float %8557, 0x3F69A5C380000000
  %8561 = fcmp fast ogt float %8558, 0x3F69A5C380000000
  %8562 = fcmp fast ogt float %8559, 0x3F69A5C380000000
  %8563 = select i1 %8560, float 0.000000e+00, float 1.000000e+00
  %8564 = select i1 %8561, float 0.000000e+00, float 1.000000e+00
  %8565 = select i1 %8562, float 0.000000e+00, float 1.000000e+00
  %8566 = fmul fast float %8557, 0x4029D70A40000000
  %8567 = fmul fast float %8558, 0x4029D70A40000000
  %8568 = fmul fast float %8559, 0x4029D70A40000000
  %8569 = call float @dx.op.binary.f32(i32 35, float %8557, float 0.000000e+00)  ; FMax(a,b)
  %8570 = call float @dx.op.binary.f32(i32 35, float %8558, float 0.000000e+00)  ; FMax(a,b)
  %8571 = call float @dx.op.binary.f32(i32 35, float %8559, float 0.000000e+00)  ; FMax(a,b)
  %8572 = call float @dx.op.unary.f32(i32 23, float %8569)  ; Log(value)
  %8573 = call float @dx.op.unary.f32(i32 23, float %8570)  ; Log(value)
  %8574 = call float @dx.op.unary.f32(i32 23, float %8571)  ; Log(value)
  %8575 = fmul fast float %8572, 0x3FDAAAAAA0000000
  %8576 = fmul fast float %8573, 0x3FDAAAAAA0000000
  %8577 = fmul fast float %8574, 0x3FDAAAAAA0000000
  %8578 = call float @dx.op.unary.f32(i32 21, float %8575)  ; Exp(value)
  %8579 = call float @dx.op.unary.f32(i32 21, float %8576)  ; Exp(value)
  %8580 = call float @dx.op.unary.f32(i32 21, float %8577)  ; Exp(value)
  %8581 = fmul fast float %8578, 0x3FF0E147A0000000
  %8582 = fmul fast float %8579, 0x3FF0E147A0000000
  %8583 = fmul fast float %8580, 0x3FF0E147A0000000
  %8584 = fadd fast float %8581, 0xBFAC28F5C0000000
  %8585 = fadd fast float %8582, 0xBFAC28F5C0000000
  %8586 = fadd fast float %8583, 0xBFAC28F5C0000000
  %8587 = fsub fast float %8566, %8584
  %8588 = fsub fast float %8567, %8585
  %8589 = fsub fast float %8568, %8586
  %8590 = fmul fast float %8587, %8563
  %8591 = fmul fast float %8588, %8564
  %8592 = fmul fast float %8589, %8565
  %8593 = fadd fast float %8590, %8584
  %8594 = fadd fast float %8591, %8585
  %8595 = fadd fast float %8592, %8586
  %8596 = call float @dx.op.dot4.f32(i32 56, float %8526, float %8530, float %8534, float %8538, float %163, float %164, float %165, float %166)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %8593)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %8594)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %8595)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %8596)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %81)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare i1 @dx.op.isSpecialFloat.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !37, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, !28}
!36 = !{i32 9}
!37 = !{!38, !39}
!38 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
!39 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !40}
!40 = !{i32 3, i32 1}
