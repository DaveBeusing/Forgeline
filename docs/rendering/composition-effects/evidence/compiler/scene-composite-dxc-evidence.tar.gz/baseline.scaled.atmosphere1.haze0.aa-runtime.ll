;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float   xyz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: 12d88719ec47d0c7584a6563f32e9f45
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %40 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %41 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %42 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %43 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %44 = extractvalue %dx.types.Dimensions %43, 0
  %45 = extractvalue %dx.types.Dimensions %43, 1
  %46 = uitofp i32 %44 to float
  %47 = uitofp i32 %45 to float
  %48 = fmul fast float %46, %41
  %49 = fmul fast float %47, %42
  %50 = fdiv fast float %48, %4
  %51 = fdiv fast float %49, %5
  %52 = fadd fast float %50, -5.000000e-01
  %53 = fadd fast float %51, -5.000000e-01
  %54 = call float @dx.op.unary.f32(i32 27, float %52)  ; Round_ni(value)
  %55 = call float @dx.op.unary.f32(i32 27, float %53)  ; Round_ni(value)
  %56 = fptosi float %54 to i32
  %57 = fptosi float %55 to i32
  %58 = call float @dx.op.unary.f32(i32 22, float %52)  ; Frc(value)
  %59 = call float @dx.op.unary.f32(i32 22, float %53)  ; Frc(value)
  %60 = add i32 %44, -1
  %61 = add i32 %45, -1
  %62 = call i32 @dx.op.binary.i32(i32 37, i32 %56, i32 0)  ; IMax(a,b)
  %63 = call i32 @dx.op.binary.i32(i32 37, i32 %57, i32 0)  ; IMax(a,b)
  %64 = call i32 @dx.op.binary.i32(i32 38, i32 %62, i32 %60)  ; IMin(a,b)
  %65 = call i32 @dx.op.binary.i32(i32 38, i32 %63, i32 %61)  ; IMin(a,b)
  %66 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %64, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %67 = extractvalue %dx.types.ResRet.f32 %66, 0
  %68 = extractvalue %dx.types.ResRet.f32 %66, 1
  %69 = extractvalue %dx.types.ResRet.f32 %66, 2
  %70 = extractvalue %dx.types.ResRet.f32 %66, 3
  %71 = fcmp fast olt float %70, 0.000000e+00
  br i1 %71, label %72, label %74

; <label>:72                                      ; preds = %0
  %73 = fsub fast float -1.000000e+00, %70
  br label %1222

; <label>:74                                      ; preds = %0
  %75 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %64, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %76 = extractvalue %dx.types.ResRet.f32 %75, 0
  %77 = fcmp fast ogt float %39, 5.000000e-01
  %78 = fcmp fast olt float %76, 1.000000e+00
  %79 = and i1 %77, %78
  br i1 %79, label %80, label %166

; <label>:80                                      ; preds = %74
  %81 = sitofp i32 %64 to float
  %82 = sitofp i32 %65 to float
  %83 = fadd fast float %81, 5.000000e-01
  %84 = fadd fast float %82, 5.000000e-01
  %85 = fdiv fast float %83, %46
  %86 = fdiv fast float %84, %47
  %87 = fmul fast float %85, 2.000000e+00
  %88 = fmul fast float %86, 2.000000e+00
  %89 = fadd fast float %87, -1.000000e+00
  %90 = fsub fast float 1.000000e+00, %88
  %91 = fmul fast float %89, %36
  %92 = call float @dx.op.tertiary.f32(i32 46, float %90, float %32, float %91)  ; FMad(a,b,c)
  %93 = call float @dx.op.tertiary.f32(i32 46, float %76, float %28, float %92)  ; FMad(a,b,c)
  %94 = fadd fast float %93, %24
  %95 = call float @dx.op.unary.f32(i32 6, float %94)  ; FAbs(value)
  %96 = fcmp fast ogt float %95, 0x3EB0C6F7A0000000
  br i1 %96, label %97, label %166

; <label>:97                                      ; preds = %80
  %98 = fmul fast float %89, %35
  %99 = call float @dx.op.tertiary.f32(i32 46, float %90, float %31, float %98)  ; FMad(a,b,c)
  %100 = call float @dx.op.tertiary.f32(i32 46, float %76, float %27, float %99)  ; FMad(a,b,c)
  %101 = fadd fast float %100, %23
  %102 = fmul fast float %89, %34
  %103 = call float @dx.op.tertiary.f32(i32 46, float %90, float %30, float %102)  ; FMad(a,b,c)
  %104 = call float @dx.op.tertiary.f32(i32 46, float %76, float %26, float %103)  ; FMad(a,b,c)
  %105 = fadd fast float %104, %22
  %106 = fmul fast float %89, %33
  %107 = call float @dx.op.tertiary.f32(i32 46, float %90, float %29, float %106)  ; FMad(a,b,c)
  %108 = call float @dx.op.tertiary.f32(i32 46, float %76, float %25, float %107)  ; FMad(a,b,c)
  %109 = fadd fast float %108, %21
  %110 = fdiv fast float %109, %94
  %111 = fdiv fast float %105, %94
  %112 = fdiv fast float %101, %94
  %113 = fsub fast float %110, %18
  %114 = fsub fast float %111, %19
  %115 = fsub fast float %112, %20
  %116 = fmul fast float %113, %113
  %117 = fmul fast float %114, %114
  %118 = fadd fast float %117, %116
  %119 = fmul fast float %115, %115
  %120 = fadd fast float %118, %119
  %121 = call float @dx.op.unary.f32(i32 24, float %120)  ; Sqrt(value)
  %122 = fsub fast float %121, %10
  %123 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %122)  ; FMax(a,b)
  %124 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %124, label %125, label %148

; <label>:125                                     ; preds = %97
  %126 = call float @dx.op.unary.f32(i32 6, float %114)  ; FAbs(value)
  %127 = fmul fast float %126, %12
  %128 = fcmp fast olt float %127, 0x3F50624DE0000000
  br i1 %128, label %129, label %132

; <label>:129                                     ; preds = %125
  %130 = fmul fast float %127, 5.000000e-01
  %131 = fsub fast float 1.000000e+00, %130
  br label %137

; <label>:132                                     ; preds = %125
  %133 = fmul fast float %127, 0xBFF7154760000000
  %134 = call float @dx.op.unary.f32(i32 21, float %133)  ; Exp(value)
  %135 = fsub fast float 1.000000e+00, %134
  %136 = fdiv fast float %135, %127
  br label %137

; <label>:137                                     ; preds = %132, %129
  %138 = phi float [ %131, %129 ], [ %136, %132 ]
  %139 = call float @dx.op.binary.f32(i32 36, float %111, float %19)  ; FMin(a,b)
  %140 = fsub fast float %139, %11
  %141 = fmul fast float %12, %140
  %142 = fsub fast float -0.000000e+00, %141
  %143 = call float @dx.op.binary.f32(i32 35, float %142, float -4.000000e+01)  ; FMax(a,b)
  %144 = call float @dx.op.binary.f32(i32 36, float %143, float 5.000000e+00)  ; FMin(a,b)
  %145 = fmul fast float %144, 0x3FF7154760000000
  %146 = call float @dx.op.unary.f32(i32 21, float %145)  ; Exp(value)
  %147 = fmul fast float %146, %138
  br label %148

; <label>:148                                     ; preds = %137, %97
  %149 = phi float [ %147, %137 ], [ 1.000000e+00, %97 ]
  %150 = fmul fast float %123, %17
  %151 = fmul fast float %150, %149
  %152 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %151)  ; FMin(a,b)
  %153 = fmul fast float %152, 0xBFF7154760000000
  %154 = call float @dx.op.unary.f32(i32 21, float %153)  ; Exp(value)
  %155 = fsub fast float 1.000000e+00, %154
  %156 = call float @dx.op.binary.f32(i32 36, float %13, float %155)  ; FMin(a,b)
  %157 = fsub fast float %14, %67
  %158 = fsub fast float %15, %68
  %159 = fsub fast float %16, %69
  %160 = fmul fast float %156, %157
  %161 = fmul fast float %156, %158
  %162 = fmul fast float %156, %159
  %163 = fadd fast float %160, %67
  %164 = fadd fast float %161, %68
  %165 = fadd fast float %162, %69
  br label %166

; <label>:166                                     ; preds = %148, %80, %74
  %167 = phi float [ %163, %148 ], [ %67, %80 ], [ %67, %74 ]
  %168 = phi float [ %164, %148 ], [ %68, %80 ], [ %68, %74 ]
  %169 = phi float [ %165, %148 ], [ %69, %80 ], [ %69, %74 ]
  %170 = fadd fast float %6, 1.000000e+00
  %171 = fadd fast float %7, 1.000000e+00
  %172 = fsub fast float 1.000000e+00, %6
  %173 = fmul fast float %37, %170
  %174 = fmul fast float %37, %171
  %175 = fmul fast float %37, %172
  %176 = fmul fast float %173, %167
  %177 = fmul fast float %174, %168
  %178 = fmul fast float %175, %169
  %179 = fcmp fast ult float %38, 5.000000e-01
  br i1 %179, label %205, label %180

; <label>:180                                     ; preds = %166
  %181 = fmul fast float %176, 0x4004147AE0000000
  %182 = fmul fast float %177, 0x4004147AE0000000
  %183 = fmul fast float %178, 0x4004147AE0000000
  %184 = fadd fast float %181, 0x3F9EB851E0000000
  %185 = fadd fast float %182, 0x3F9EB851E0000000
  %186 = fadd fast float %183, 0x3F9EB851E0000000
  %187 = fmul fast float %184, %176
  %188 = fmul fast float %185, %177
  %189 = fmul fast float %186, %178
  %190 = fmul fast float %176, 0x400370A3E0000000
  %191 = fmul fast float %177, 0x400370A3E0000000
  %192 = fmul fast float %178, 0x400370A3E0000000
  %193 = fadd fast float %190, 0x3FE2E147A0000000
  %194 = fadd fast float %191, 0x3FE2E147A0000000
  %195 = fadd fast float %192, 0x3FE2E147A0000000
  %196 = fmul fast float %193, %176
  %197 = fmul fast float %194, %177
  %198 = fmul fast float %195, %178
  %199 = fadd fast float %196, 0x3FC1EB8520000000
  %200 = fadd fast float %197, 0x3FC1EB8520000000
  %201 = fadd fast float %198, 0x3FC1EB8520000000
  %202 = fdiv fast float %187, %199
  %203 = fdiv fast float %188, %200
  %204 = fdiv fast float %189, %201
  br label %205

; <label>:205                                     ; preds = %180, %166
  %206 = phi float [ %202, %180 ], [ %176, %166 ]
  %207 = phi float [ %203, %180 ], [ %177, %166 ]
  %208 = phi float [ %204, %180 ], [ %178, %166 ]
  %209 = call float @dx.op.unary.f32(i32 7, float %206)  ; Saturate(value)
  %210 = call float @dx.op.unary.f32(i32 7, float %207)  ; Saturate(value)
  %211 = call float @dx.op.unary.f32(i32 7, float %208)  ; Saturate(value)
  %212 = call float @dx.op.dot3.f32(i32 55, float %209, float %210, float %211, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %213 = fsub fast float %209, %212
  %214 = fsub fast float %210, %212
  %215 = fsub fast float %211, %212
  %216 = fmul fast float %213, %9
  %217 = fmul fast float %214, %9
  %218 = fmul fast float %215, %9
  %219 = fadd fast float %216, %212
  %220 = fadd fast float %217, %212
  %221 = fadd fast float %218, %212
  %222 = call float @dx.op.unary.f32(i32 7, float %219)  ; Saturate(value)
  %223 = call float @dx.op.unary.f32(i32 7, float %220)  ; Saturate(value)
  %224 = call float @dx.op.unary.f32(i32 7, float %221)  ; Saturate(value)
  %225 = fadd fast float %222, 0xBFC70A3D80000000
  %226 = fadd fast float %223, 0xBFC70A3D80000000
  %227 = fadd fast float %224, 0xBFC70A3D80000000
  %228 = fmul fast float %225, %8
  %229 = fmul fast float %226, %8
  %230 = fmul fast float %227, %8
  %231 = fadd fast float %228, 0x3FC70A3D80000000
  %232 = fadd fast float %229, 0x3FC70A3D80000000
  %233 = fadd fast float %230, 0x3FC70A3D80000000
  %234 = call float @dx.op.unary.f32(i32 7, float %231)  ; Saturate(value)
  %235 = call float @dx.op.unary.f32(i32 7, float %232)  ; Saturate(value)
  %236 = call float @dx.op.unary.f32(i32 7, float %233)  ; Saturate(value)
  %237 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %237, label %238, label %1182

; <label>:238                                     ; preds = %205
  %239 = add i32 %65, -1
  %240 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %241 = call i32 @dx.op.binary.i32(i32 37, i32 %239, i32 0)  ; IMax(a,b)
  %242 = call i32 @dx.op.binary.i32(i32 38, i32 %240, i32 %60)  ; IMin(a,b)
  %243 = call i32 @dx.op.binary.i32(i32 38, i32 %241, i32 %61)  ; IMin(a,b)
  %244 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %242, i32 %243, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %245 = extractvalue %dx.types.ResRet.f32 %244, 0
  %246 = extractvalue %dx.types.ResRet.f32 %244, 1
  %247 = extractvalue %dx.types.ResRet.f32 %244, 2
  %248 = extractvalue %dx.types.ResRet.f32 %244, 3
  %249 = fcmp fast olt float %248, 0.000000e+00
  br i1 %249, label %250, label %284

; <label>:250                                     ; preds = %238
  %251 = fcmp fast ogt float %245, 0x3FA4B5DCC0000000
  %252 = fcmp fast ogt float %246, 0x3FA4B5DCC0000000
  %253 = fcmp fast ogt float %247, 0x3FA4B5DCC0000000
  %254 = select i1 %251, float 0.000000e+00, float 1.000000e+00
  %255 = select i1 %252, float 0.000000e+00, float 1.000000e+00
  %256 = select i1 %253, float 0.000000e+00, float 1.000000e+00
  %257 = fmul fast float %245, 0x3FB3D07220000000
  %258 = fmul fast float %246, 0x3FB3D07220000000
  %259 = fmul fast float %247, 0x3FB3D07220000000
  %260 = fadd fast float %245, 0x3FAC28F5C0000000
  %261 = fadd fast float %246, 0x3FAC28F5C0000000
  %262 = fadd fast float %247, 0x3FAC28F5C0000000
  %263 = fmul fast float %260, 0x3FEE54EDE0000000
  %264 = fmul fast float %261, 0x3FEE54EDE0000000
  %265 = fmul fast float %262, 0x3FEE54EDE0000000
  %266 = call float @dx.op.unary.f32(i32 23, float %263)  ; Log(value)
  %267 = call float @dx.op.unary.f32(i32 23, float %264)  ; Log(value)
  %268 = call float @dx.op.unary.f32(i32 23, float %265)  ; Log(value)
  %269 = fmul fast float %266, 0x4003333340000000
  %270 = fmul fast float %267, 0x4003333340000000
  %271 = fmul fast float %268, 0x4003333340000000
  %272 = call float @dx.op.unary.f32(i32 21, float %269)  ; Exp(value)
  %273 = call float @dx.op.unary.f32(i32 21, float %270)  ; Exp(value)
  %274 = call float @dx.op.unary.f32(i32 21, float %271)  ; Exp(value)
  %275 = fsub fast float %257, %272
  %276 = fsub fast float %258, %273
  %277 = fsub fast float %259, %274
  %278 = fmul fast float %275, %254
  %279 = fmul fast float %276, %255
  %280 = fmul fast float %277, %256
  %281 = fadd fast float %278, %272
  %282 = fadd fast float %279, %273
  %283 = fadd fast float %280, %274
  br label %447

; <label>:284                                     ; preds = %238
  %285 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %242, i32 %243, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %286 = extractvalue %dx.types.ResRet.f32 %285, 0
  %287 = fcmp fast ogt float %39, 5.000000e-01
  %288 = fcmp fast olt float %286, 1.000000e+00
  %289 = and i1 %287, %288
  br i1 %289, label %290, label %376

; <label>:290                                     ; preds = %284
  %291 = sitofp i32 %242 to float
  %292 = sitofp i32 %243 to float
  %293 = fadd fast float %291, 5.000000e-01
  %294 = fadd fast float %292, 5.000000e-01
  %295 = fdiv fast float %293, %46
  %296 = fdiv fast float %294, %47
  %297 = fmul fast float %295, 2.000000e+00
  %298 = fmul fast float %296, 2.000000e+00
  %299 = fadd fast float %297, -1.000000e+00
  %300 = fsub fast float 1.000000e+00, %298
  %301 = fmul fast float %299, %36
  %302 = call float @dx.op.tertiary.f32(i32 46, float %300, float %32, float %301)  ; FMad(a,b,c)
  %303 = call float @dx.op.tertiary.f32(i32 46, float %286, float %28, float %302)  ; FMad(a,b,c)
  %304 = fadd fast float %303, %24
  %305 = call float @dx.op.unary.f32(i32 6, float %304)  ; FAbs(value)
  %306 = fcmp fast ogt float %305, 0x3EB0C6F7A0000000
  br i1 %306, label %307, label %376

; <label>:307                                     ; preds = %290
  %308 = fmul fast float %299, %35
  %309 = call float @dx.op.tertiary.f32(i32 46, float %300, float %31, float %308)  ; FMad(a,b,c)
  %310 = call float @dx.op.tertiary.f32(i32 46, float %286, float %27, float %309)  ; FMad(a,b,c)
  %311 = fadd fast float %310, %23
  %312 = fmul fast float %299, %34
  %313 = call float @dx.op.tertiary.f32(i32 46, float %300, float %30, float %312)  ; FMad(a,b,c)
  %314 = call float @dx.op.tertiary.f32(i32 46, float %286, float %26, float %313)  ; FMad(a,b,c)
  %315 = fadd fast float %314, %22
  %316 = fmul fast float %299, %33
  %317 = call float @dx.op.tertiary.f32(i32 46, float %300, float %29, float %316)  ; FMad(a,b,c)
  %318 = call float @dx.op.tertiary.f32(i32 46, float %286, float %25, float %317)  ; FMad(a,b,c)
  %319 = fadd fast float %318, %21
  %320 = fdiv fast float %319, %304
  %321 = fdiv fast float %315, %304
  %322 = fdiv fast float %311, %304
  %323 = fsub fast float %320, %18
  %324 = fsub fast float %321, %19
  %325 = fsub fast float %322, %20
  %326 = fmul fast float %323, %323
  %327 = fmul fast float %324, %324
  %328 = fadd fast float %327, %326
  %329 = fmul fast float %325, %325
  %330 = fadd fast float %328, %329
  %331 = call float @dx.op.unary.f32(i32 24, float %330)  ; Sqrt(value)
  %332 = fsub fast float %331, %10
  %333 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %332)  ; FMax(a,b)
  %334 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %334, label %335, label %358

; <label>:335                                     ; preds = %307
  %336 = call float @dx.op.unary.f32(i32 6, float %324)  ; FAbs(value)
  %337 = fmul fast float %336, %12
  %338 = fcmp fast olt float %337, 0x3F50624DE0000000
  br i1 %338, label %339, label %342

; <label>:339                                     ; preds = %335
  %340 = fmul fast float %337, 5.000000e-01
  %341 = fsub fast float 1.000000e+00, %340
  br label %347

; <label>:342                                     ; preds = %335
  %343 = fmul fast float %337, 0xBFF7154760000000
  %344 = call float @dx.op.unary.f32(i32 21, float %343)  ; Exp(value)
  %345 = fsub fast float 1.000000e+00, %344
  %346 = fdiv fast float %345, %337
  br label %347

; <label>:347                                     ; preds = %342, %339
  %348 = phi float [ %341, %339 ], [ %346, %342 ]
  %349 = call float @dx.op.binary.f32(i32 36, float %321, float %19)  ; FMin(a,b)
  %350 = fsub fast float %349, %11
  %351 = fmul fast float %12, %350
  %352 = fsub fast float -0.000000e+00, %351
  %353 = call float @dx.op.binary.f32(i32 35, float %352, float -4.000000e+01)  ; FMax(a,b)
  %354 = call float @dx.op.binary.f32(i32 36, float %353, float 5.000000e+00)  ; FMin(a,b)
  %355 = fmul fast float %354, 0x3FF7154760000000
  %356 = call float @dx.op.unary.f32(i32 21, float %355)  ; Exp(value)
  %357 = fmul fast float %356, %348
  br label %358

; <label>:358                                     ; preds = %347, %307
  %359 = phi float [ %357, %347 ], [ 1.000000e+00, %307 ]
  %360 = fmul fast float %333, %17
  %361 = fmul fast float %360, %359
  %362 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %361)  ; FMin(a,b)
  %363 = fmul fast float %362, 0xBFF7154760000000
  %364 = call float @dx.op.unary.f32(i32 21, float %363)  ; Exp(value)
  %365 = fsub fast float 1.000000e+00, %364
  %366 = call float @dx.op.binary.f32(i32 36, float %13, float %365)  ; FMin(a,b)
  %367 = fsub fast float %14, %245
  %368 = fsub fast float %15, %246
  %369 = fsub fast float %16, %247
  %370 = fmul fast float %366, %367
  %371 = fmul fast float %366, %368
  %372 = fmul fast float %366, %369
  %373 = fadd fast float %370, %245
  %374 = fadd fast float %371, %246
  %375 = fadd fast float %372, %247
  br label %376

; <label>:376                                     ; preds = %358, %290, %284
  %377 = phi float [ %373, %358 ], [ %245, %290 ], [ %245, %284 ]
  %378 = phi float [ %374, %358 ], [ %246, %290 ], [ %246, %284 ]
  %379 = phi float [ %375, %358 ], [ %247, %290 ], [ %247, %284 ]
  %380 = fadd fast float %6, 1.000000e+00
  %381 = fadd fast float %7, 1.000000e+00
  %382 = fsub fast float 1.000000e+00, %6
  %383 = fmul fast float %37, %380
  %384 = fmul fast float %37, %381
  %385 = fmul fast float %37, %382
  %386 = fmul fast float %383, %377
  %387 = fmul fast float %384, %378
  %388 = fmul fast float %385, %379
  %389 = fcmp fast ult float %38, 5.000000e-01
  br i1 %389, label %415, label %390

; <label>:390                                     ; preds = %376
  %391 = fmul fast float %386, 0x4004147AE0000000
  %392 = fmul fast float %387, 0x4004147AE0000000
  %393 = fmul fast float %388, 0x4004147AE0000000
  %394 = fadd fast float %391, 0x3F9EB851E0000000
  %395 = fadd fast float %392, 0x3F9EB851E0000000
  %396 = fadd fast float %393, 0x3F9EB851E0000000
  %397 = fmul fast float %394, %386
  %398 = fmul fast float %395, %387
  %399 = fmul fast float %396, %388
  %400 = fmul fast float %386, 0x400370A3E0000000
  %401 = fmul fast float %387, 0x400370A3E0000000
  %402 = fmul fast float %388, 0x400370A3E0000000
  %403 = fadd fast float %400, 0x3FE2E147A0000000
  %404 = fadd fast float %401, 0x3FE2E147A0000000
  %405 = fadd fast float %402, 0x3FE2E147A0000000
  %406 = fmul fast float %403, %386
  %407 = fmul fast float %404, %387
  %408 = fmul fast float %405, %388
  %409 = fadd fast float %406, 0x3FC1EB8520000000
  %410 = fadd fast float %407, 0x3FC1EB8520000000
  %411 = fadd fast float %408, 0x3FC1EB8520000000
  %412 = fdiv fast float %397, %409
  %413 = fdiv fast float %398, %410
  %414 = fdiv fast float %399, %411
  br label %415

; <label>:415                                     ; preds = %390, %376
  %416 = phi float [ %412, %390 ], [ %386, %376 ]
  %417 = phi float [ %413, %390 ], [ %387, %376 ]
  %418 = phi float [ %414, %390 ], [ %388, %376 ]
  %419 = call float @dx.op.unary.f32(i32 7, float %416)  ; Saturate(value)
  %420 = call float @dx.op.unary.f32(i32 7, float %417)  ; Saturate(value)
  %421 = call float @dx.op.unary.f32(i32 7, float %418)  ; Saturate(value)
  %422 = call float @dx.op.dot3.f32(i32 55, float %419, float %420, float %421, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %423 = fsub fast float %419, %422
  %424 = fsub fast float %420, %422
  %425 = fsub fast float %421, %422
  %426 = fmul fast float %423, %9
  %427 = fmul fast float %424, %9
  %428 = fmul fast float %425, %9
  %429 = fadd fast float %426, %422
  %430 = fadd fast float %427, %422
  %431 = fadd fast float %428, %422
  %432 = call float @dx.op.unary.f32(i32 7, float %429)  ; Saturate(value)
  %433 = call float @dx.op.unary.f32(i32 7, float %430)  ; Saturate(value)
  %434 = call float @dx.op.unary.f32(i32 7, float %431)  ; Saturate(value)
  %435 = fadd fast float %432, 0xBFC70A3D80000000
  %436 = fadd fast float %433, 0xBFC70A3D80000000
  %437 = fadd fast float %434, 0xBFC70A3D80000000
  %438 = fmul fast float %435, %8
  %439 = fmul fast float %436, %8
  %440 = fmul fast float %437, %8
  %441 = fadd fast float %438, 0x3FC70A3D80000000
  %442 = fadd fast float %439, 0x3FC70A3D80000000
  %443 = fadd fast float %440, 0x3FC70A3D80000000
  %444 = call float @dx.op.unary.f32(i32 7, float %441)  ; Saturate(value)
  %445 = call float @dx.op.unary.f32(i32 7, float %442)  ; Saturate(value)
  %446 = call float @dx.op.unary.f32(i32 7, float %443)  ; Saturate(value)
  br label %447

; <label>:447                                     ; preds = %415, %250
  %448 = phi float [ %281, %250 ], [ %444, %415 ]
  %449 = phi float [ %282, %250 ], [ %445, %415 ]
  %450 = phi float [ %283, %250 ], [ %446, %415 ]
  %451 = add i32 %65, 1
  %452 = call i32 @dx.op.binary.i32(i32 37, i32 %451, i32 0)  ; IMax(a,b)
  %453 = call i32 @dx.op.binary.i32(i32 38, i32 %452, i32 %61)  ; IMin(a,b)
  %454 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %242, i32 %453, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %455 = extractvalue %dx.types.ResRet.f32 %454, 0
  %456 = extractvalue %dx.types.ResRet.f32 %454, 1
  %457 = extractvalue %dx.types.ResRet.f32 %454, 2
  %458 = extractvalue %dx.types.ResRet.f32 %454, 3
  %459 = fcmp fast olt float %458, 0.000000e+00
  br i1 %459, label %460, label %494

; <label>:460                                     ; preds = %447
  %461 = fcmp fast ogt float %455, 0x3FA4B5DCC0000000
  %462 = fcmp fast ogt float %456, 0x3FA4B5DCC0000000
  %463 = fcmp fast ogt float %457, 0x3FA4B5DCC0000000
  %464 = select i1 %461, float 0.000000e+00, float 1.000000e+00
  %465 = select i1 %462, float 0.000000e+00, float 1.000000e+00
  %466 = select i1 %463, float 0.000000e+00, float 1.000000e+00
  %467 = fmul fast float %455, 0x3FB3D07220000000
  %468 = fmul fast float %456, 0x3FB3D07220000000
  %469 = fmul fast float %457, 0x3FB3D07220000000
  %470 = fadd fast float %455, 0x3FAC28F5C0000000
  %471 = fadd fast float %456, 0x3FAC28F5C0000000
  %472 = fadd fast float %457, 0x3FAC28F5C0000000
  %473 = fmul fast float %470, 0x3FEE54EDE0000000
  %474 = fmul fast float %471, 0x3FEE54EDE0000000
  %475 = fmul fast float %472, 0x3FEE54EDE0000000
  %476 = call float @dx.op.unary.f32(i32 23, float %473)  ; Log(value)
  %477 = call float @dx.op.unary.f32(i32 23, float %474)  ; Log(value)
  %478 = call float @dx.op.unary.f32(i32 23, float %475)  ; Log(value)
  %479 = fmul fast float %476, 0x4003333340000000
  %480 = fmul fast float %477, 0x4003333340000000
  %481 = fmul fast float %478, 0x4003333340000000
  %482 = call float @dx.op.unary.f32(i32 21, float %479)  ; Exp(value)
  %483 = call float @dx.op.unary.f32(i32 21, float %480)  ; Exp(value)
  %484 = call float @dx.op.unary.f32(i32 21, float %481)  ; Exp(value)
  %485 = fsub fast float %467, %482
  %486 = fsub fast float %468, %483
  %487 = fsub fast float %469, %484
  %488 = fmul fast float %485, %464
  %489 = fmul fast float %486, %465
  %490 = fmul fast float %487, %466
  %491 = fadd fast float %488, %482
  %492 = fadd fast float %489, %483
  %493 = fadd fast float %490, %484
  br label %657

; <label>:494                                     ; preds = %447
  %495 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %242, i32 %453, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %496 = extractvalue %dx.types.ResRet.f32 %495, 0
  %497 = fcmp fast ogt float %39, 5.000000e-01
  %498 = fcmp fast olt float %496, 1.000000e+00
  %499 = and i1 %497, %498
  br i1 %499, label %500, label %586

; <label>:500                                     ; preds = %494
  %501 = sitofp i32 %242 to float
  %502 = sitofp i32 %453 to float
  %503 = fadd fast float %501, 5.000000e-01
  %504 = fadd fast float %502, 5.000000e-01
  %505 = fdiv fast float %503, %46
  %506 = fdiv fast float %504, %47
  %507 = fmul fast float %505, 2.000000e+00
  %508 = fmul fast float %506, 2.000000e+00
  %509 = fadd fast float %507, -1.000000e+00
  %510 = fsub fast float 1.000000e+00, %508
  %511 = fmul fast float %509, %36
  %512 = call float @dx.op.tertiary.f32(i32 46, float %510, float %32, float %511)  ; FMad(a,b,c)
  %513 = call float @dx.op.tertiary.f32(i32 46, float %496, float %28, float %512)  ; FMad(a,b,c)
  %514 = fadd fast float %513, %24
  %515 = call float @dx.op.unary.f32(i32 6, float %514)  ; FAbs(value)
  %516 = fcmp fast ogt float %515, 0x3EB0C6F7A0000000
  br i1 %516, label %517, label %586

; <label>:517                                     ; preds = %500
  %518 = fmul fast float %509, %35
  %519 = call float @dx.op.tertiary.f32(i32 46, float %510, float %31, float %518)  ; FMad(a,b,c)
  %520 = call float @dx.op.tertiary.f32(i32 46, float %496, float %27, float %519)  ; FMad(a,b,c)
  %521 = fadd fast float %520, %23
  %522 = fmul fast float %509, %34
  %523 = call float @dx.op.tertiary.f32(i32 46, float %510, float %30, float %522)  ; FMad(a,b,c)
  %524 = call float @dx.op.tertiary.f32(i32 46, float %496, float %26, float %523)  ; FMad(a,b,c)
  %525 = fadd fast float %524, %22
  %526 = fmul fast float %509, %33
  %527 = call float @dx.op.tertiary.f32(i32 46, float %510, float %29, float %526)  ; FMad(a,b,c)
  %528 = call float @dx.op.tertiary.f32(i32 46, float %496, float %25, float %527)  ; FMad(a,b,c)
  %529 = fadd fast float %528, %21
  %530 = fdiv fast float %529, %514
  %531 = fdiv fast float %525, %514
  %532 = fdiv fast float %521, %514
  %533 = fsub fast float %530, %18
  %534 = fsub fast float %531, %19
  %535 = fsub fast float %532, %20
  %536 = fmul fast float %533, %533
  %537 = fmul fast float %534, %534
  %538 = fadd fast float %537, %536
  %539 = fmul fast float %535, %535
  %540 = fadd fast float %538, %539
  %541 = call float @dx.op.unary.f32(i32 24, float %540)  ; Sqrt(value)
  %542 = fsub fast float %541, %10
  %543 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %542)  ; FMax(a,b)
  %544 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %544, label %545, label %568

; <label>:545                                     ; preds = %517
  %546 = call float @dx.op.unary.f32(i32 6, float %534)  ; FAbs(value)
  %547 = fmul fast float %546, %12
  %548 = fcmp fast olt float %547, 0x3F50624DE0000000
  br i1 %548, label %549, label %552

; <label>:549                                     ; preds = %545
  %550 = fmul fast float %547, 5.000000e-01
  %551 = fsub fast float 1.000000e+00, %550
  br label %557

; <label>:552                                     ; preds = %545
  %553 = fmul fast float %547, 0xBFF7154760000000
  %554 = call float @dx.op.unary.f32(i32 21, float %553)  ; Exp(value)
  %555 = fsub fast float 1.000000e+00, %554
  %556 = fdiv fast float %555, %547
  br label %557

; <label>:557                                     ; preds = %552, %549
  %558 = phi float [ %551, %549 ], [ %556, %552 ]
  %559 = call float @dx.op.binary.f32(i32 36, float %531, float %19)  ; FMin(a,b)
  %560 = fsub fast float %559, %11
  %561 = fmul fast float %12, %560
  %562 = fsub fast float -0.000000e+00, %561
  %563 = call float @dx.op.binary.f32(i32 35, float %562, float -4.000000e+01)  ; FMax(a,b)
  %564 = call float @dx.op.binary.f32(i32 36, float %563, float 5.000000e+00)  ; FMin(a,b)
  %565 = fmul fast float %564, 0x3FF7154760000000
  %566 = call float @dx.op.unary.f32(i32 21, float %565)  ; Exp(value)
  %567 = fmul fast float %566, %558
  br label %568

; <label>:568                                     ; preds = %557, %517
  %569 = phi float [ %567, %557 ], [ 1.000000e+00, %517 ]
  %570 = fmul fast float %543, %17
  %571 = fmul fast float %570, %569
  %572 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %571)  ; FMin(a,b)
  %573 = fmul fast float %572, 0xBFF7154760000000
  %574 = call float @dx.op.unary.f32(i32 21, float %573)  ; Exp(value)
  %575 = fsub fast float 1.000000e+00, %574
  %576 = call float @dx.op.binary.f32(i32 36, float %13, float %575)  ; FMin(a,b)
  %577 = fsub fast float %14, %455
  %578 = fsub fast float %15, %456
  %579 = fsub fast float %16, %457
  %580 = fmul fast float %576, %577
  %581 = fmul fast float %576, %578
  %582 = fmul fast float %576, %579
  %583 = fadd fast float %580, %455
  %584 = fadd fast float %581, %456
  %585 = fadd fast float %582, %457
  br label %586

; <label>:586                                     ; preds = %568, %500, %494
  %587 = phi float [ %583, %568 ], [ %455, %500 ], [ %455, %494 ]
  %588 = phi float [ %584, %568 ], [ %456, %500 ], [ %456, %494 ]
  %589 = phi float [ %585, %568 ], [ %457, %500 ], [ %457, %494 ]
  %590 = fadd fast float %6, 1.000000e+00
  %591 = fadd fast float %7, 1.000000e+00
  %592 = fsub fast float 1.000000e+00, %6
  %593 = fmul fast float %37, %590
  %594 = fmul fast float %37, %591
  %595 = fmul fast float %37, %592
  %596 = fmul fast float %593, %587
  %597 = fmul fast float %594, %588
  %598 = fmul fast float %595, %589
  %599 = fcmp fast ult float %38, 5.000000e-01
  br i1 %599, label %625, label %600

; <label>:600                                     ; preds = %586
  %601 = fmul fast float %596, 0x4004147AE0000000
  %602 = fmul fast float %597, 0x4004147AE0000000
  %603 = fmul fast float %598, 0x4004147AE0000000
  %604 = fadd fast float %601, 0x3F9EB851E0000000
  %605 = fadd fast float %602, 0x3F9EB851E0000000
  %606 = fadd fast float %603, 0x3F9EB851E0000000
  %607 = fmul fast float %604, %596
  %608 = fmul fast float %605, %597
  %609 = fmul fast float %606, %598
  %610 = fmul fast float %596, 0x400370A3E0000000
  %611 = fmul fast float %597, 0x400370A3E0000000
  %612 = fmul fast float %598, 0x400370A3E0000000
  %613 = fadd fast float %610, 0x3FE2E147A0000000
  %614 = fadd fast float %611, 0x3FE2E147A0000000
  %615 = fadd fast float %612, 0x3FE2E147A0000000
  %616 = fmul fast float %613, %596
  %617 = fmul fast float %614, %597
  %618 = fmul fast float %615, %598
  %619 = fadd fast float %616, 0x3FC1EB8520000000
  %620 = fadd fast float %617, 0x3FC1EB8520000000
  %621 = fadd fast float %618, 0x3FC1EB8520000000
  %622 = fdiv fast float %607, %619
  %623 = fdiv fast float %608, %620
  %624 = fdiv fast float %609, %621
  br label %625

; <label>:625                                     ; preds = %600, %586
  %626 = phi float [ %622, %600 ], [ %596, %586 ]
  %627 = phi float [ %623, %600 ], [ %597, %586 ]
  %628 = phi float [ %624, %600 ], [ %598, %586 ]
  %629 = call float @dx.op.unary.f32(i32 7, float %626)  ; Saturate(value)
  %630 = call float @dx.op.unary.f32(i32 7, float %627)  ; Saturate(value)
  %631 = call float @dx.op.unary.f32(i32 7, float %628)  ; Saturate(value)
  %632 = call float @dx.op.dot3.f32(i32 55, float %629, float %630, float %631, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %633 = fsub fast float %629, %632
  %634 = fsub fast float %630, %632
  %635 = fsub fast float %631, %632
  %636 = fmul fast float %633, %9
  %637 = fmul fast float %634, %9
  %638 = fmul fast float %635, %9
  %639 = fadd fast float %636, %632
  %640 = fadd fast float %637, %632
  %641 = fadd fast float %638, %632
  %642 = call float @dx.op.unary.f32(i32 7, float %639)  ; Saturate(value)
  %643 = call float @dx.op.unary.f32(i32 7, float %640)  ; Saturate(value)
  %644 = call float @dx.op.unary.f32(i32 7, float %641)  ; Saturate(value)
  %645 = fadd fast float %642, 0xBFC70A3D80000000
  %646 = fadd fast float %643, 0xBFC70A3D80000000
  %647 = fadd fast float %644, 0xBFC70A3D80000000
  %648 = fmul fast float %645, %8
  %649 = fmul fast float %646, %8
  %650 = fmul fast float %647, %8
  %651 = fadd fast float %648, 0x3FC70A3D80000000
  %652 = fadd fast float %649, 0x3FC70A3D80000000
  %653 = fadd fast float %650, 0x3FC70A3D80000000
  %654 = call float @dx.op.unary.f32(i32 7, float %651)  ; Saturate(value)
  %655 = call float @dx.op.unary.f32(i32 7, float %652)  ; Saturate(value)
  %656 = call float @dx.op.unary.f32(i32 7, float %653)  ; Saturate(value)
  br label %657

; <label>:657                                     ; preds = %625, %460
  %658 = phi float [ %491, %460 ], [ %654, %625 ]
  %659 = phi float [ %492, %460 ], [ %655, %625 ]
  %660 = phi float [ %493, %460 ], [ %656, %625 ]
  %661 = add i32 %64, -1
  %662 = call i32 @dx.op.binary.i32(i32 37, i32 %661, i32 0)  ; IMax(a,b)
  %663 = call i32 @dx.op.binary.i32(i32 37, i32 %65, i32 0)  ; IMax(a,b)
  %664 = call i32 @dx.op.binary.i32(i32 38, i32 %662, i32 %60)  ; IMin(a,b)
  %665 = call i32 @dx.op.binary.i32(i32 38, i32 %663, i32 %61)  ; IMin(a,b)
  %666 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %664, i32 %665, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %667 = extractvalue %dx.types.ResRet.f32 %666, 0
  %668 = extractvalue %dx.types.ResRet.f32 %666, 1
  %669 = extractvalue %dx.types.ResRet.f32 %666, 2
  %670 = extractvalue %dx.types.ResRet.f32 %666, 3
  %671 = fcmp fast olt float %670, 0.000000e+00
  br i1 %671, label %672, label %706

; <label>:672                                     ; preds = %657
  %673 = fcmp fast ogt float %667, 0x3FA4B5DCC0000000
  %674 = fcmp fast ogt float %668, 0x3FA4B5DCC0000000
  %675 = fcmp fast ogt float %669, 0x3FA4B5DCC0000000
  %676 = select i1 %673, float 0.000000e+00, float 1.000000e+00
  %677 = select i1 %674, float 0.000000e+00, float 1.000000e+00
  %678 = select i1 %675, float 0.000000e+00, float 1.000000e+00
  %679 = fmul fast float %667, 0x3FB3D07220000000
  %680 = fmul fast float %668, 0x3FB3D07220000000
  %681 = fmul fast float %669, 0x3FB3D07220000000
  %682 = fadd fast float %667, 0x3FAC28F5C0000000
  %683 = fadd fast float %668, 0x3FAC28F5C0000000
  %684 = fadd fast float %669, 0x3FAC28F5C0000000
  %685 = fmul fast float %682, 0x3FEE54EDE0000000
  %686 = fmul fast float %683, 0x3FEE54EDE0000000
  %687 = fmul fast float %684, 0x3FEE54EDE0000000
  %688 = call float @dx.op.unary.f32(i32 23, float %685)  ; Log(value)
  %689 = call float @dx.op.unary.f32(i32 23, float %686)  ; Log(value)
  %690 = call float @dx.op.unary.f32(i32 23, float %687)  ; Log(value)
  %691 = fmul fast float %688, 0x4003333340000000
  %692 = fmul fast float %689, 0x4003333340000000
  %693 = fmul fast float %690, 0x4003333340000000
  %694 = call float @dx.op.unary.f32(i32 21, float %691)  ; Exp(value)
  %695 = call float @dx.op.unary.f32(i32 21, float %692)  ; Exp(value)
  %696 = call float @dx.op.unary.f32(i32 21, float %693)  ; Exp(value)
  %697 = fsub fast float %679, %694
  %698 = fsub fast float %680, %695
  %699 = fsub fast float %681, %696
  %700 = fmul fast float %697, %676
  %701 = fmul fast float %698, %677
  %702 = fmul fast float %699, %678
  %703 = fadd fast float %700, %694
  %704 = fadd fast float %701, %695
  %705 = fadd fast float %702, %696
  br label %869

; <label>:706                                     ; preds = %657
  %707 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %664, i32 %665, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %708 = extractvalue %dx.types.ResRet.f32 %707, 0
  %709 = fcmp fast ogt float %39, 5.000000e-01
  %710 = fcmp fast olt float %708, 1.000000e+00
  %711 = and i1 %709, %710
  br i1 %711, label %712, label %798

; <label>:712                                     ; preds = %706
  %713 = sitofp i32 %664 to float
  %714 = sitofp i32 %665 to float
  %715 = fadd fast float %713, 5.000000e-01
  %716 = fadd fast float %714, 5.000000e-01
  %717 = fdiv fast float %715, %46
  %718 = fdiv fast float %716, %47
  %719 = fmul fast float %717, 2.000000e+00
  %720 = fmul fast float %718, 2.000000e+00
  %721 = fadd fast float %719, -1.000000e+00
  %722 = fsub fast float 1.000000e+00, %720
  %723 = fmul fast float %721, %36
  %724 = call float @dx.op.tertiary.f32(i32 46, float %722, float %32, float %723)  ; FMad(a,b,c)
  %725 = call float @dx.op.tertiary.f32(i32 46, float %708, float %28, float %724)  ; FMad(a,b,c)
  %726 = fadd fast float %725, %24
  %727 = call float @dx.op.unary.f32(i32 6, float %726)  ; FAbs(value)
  %728 = fcmp fast ogt float %727, 0x3EB0C6F7A0000000
  br i1 %728, label %729, label %798

; <label>:729                                     ; preds = %712
  %730 = fmul fast float %721, %35
  %731 = call float @dx.op.tertiary.f32(i32 46, float %722, float %31, float %730)  ; FMad(a,b,c)
  %732 = call float @dx.op.tertiary.f32(i32 46, float %708, float %27, float %731)  ; FMad(a,b,c)
  %733 = fadd fast float %732, %23
  %734 = fmul fast float %721, %34
  %735 = call float @dx.op.tertiary.f32(i32 46, float %722, float %30, float %734)  ; FMad(a,b,c)
  %736 = call float @dx.op.tertiary.f32(i32 46, float %708, float %26, float %735)  ; FMad(a,b,c)
  %737 = fadd fast float %736, %22
  %738 = fmul fast float %721, %33
  %739 = call float @dx.op.tertiary.f32(i32 46, float %722, float %29, float %738)  ; FMad(a,b,c)
  %740 = call float @dx.op.tertiary.f32(i32 46, float %708, float %25, float %739)  ; FMad(a,b,c)
  %741 = fadd fast float %740, %21
  %742 = fdiv fast float %741, %726
  %743 = fdiv fast float %737, %726
  %744 = fdiv fast float %733, %726
  %745 = fsub fast float %742, %18
  %746 = fsub fast float %743, %19
  %747 = fsub fast float %744, %20
  %748 = fmul fast float %745, %745
  %749 = fmul fast float %746, %746
  %750 = fadd fast float %749, %748
  %751 = fmul fast float %747, %747
  %752 = fadd fast float %750, %751
  %753 = call float @dx.op.unary.f32(i32 24, float %752)  ; Sqrt(value)
  %754 = fsub fast float %753, %10
  %755 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %754)  ; FMax(a,b)
  %756 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %756, label %757, label %780

; <label>:757                                     ; preds = %729
  %758 = call float @dx.op.unary.f32(i32 6, float %746)  ; FAbs(value)
  %759 = fmul fast float %758, %12
  %760 = fcmp fast olt float %759, 0x3F50624DE0000000
  br i1 %760, label %761, label %764

; <label>:761                                     ; preds = %757
  %762 = fmul fast float %759, 5.000000e-01
  %763 = fsub fast float 1.000000e+00, %762
  br label %769

; <label>:764                                     ; preds = %757
  %765 = fmul fast float %759, 0xBFF7154760000000
  %766 = call float @dx.op.unary.f32(i32 21, float %765)  ; Exp(value)
  %767 = fsub fast float 1.000000e+00, %766
  %768 = fdiv fast float %767, %759
  br label %769

; <label>:769                                     ; preds = %764, %761
  %770 = phi float [ %763, %761 ], [ %768, %764 ]
  %771 = call float @dx.op.binary.f32(i32 36, float %743, float %19)  ; FMin(a,b)
  %772 = fsub fast float %771, %11
  %773 = fmul fast float %12, %772
  %774 = fsub fast float -0.000000e+00, %773
  %775 = call float @dx.op.binary.f32(i32 35, float %774, float -4.000000e+01)  ; FMax(a,b)
  %776 = call float @dx.op.binary.f32(i32 36, float %775, float 5.000000e+00)  ; FMin(a,b)
  %777 = fmul fast float %776, 0x3FF7154760000000
  %778 = call float @dx.op.unary.f32(i32 21, float %777)  ; Exp(value)
  %779 = fmul fast float %778, %770
  br label %780

; <label>:780                                     ; preds = %769, %729
  %781 = phi float [ %779, %769 ], [ 1.000000e+00, %729 ]
  %782 = fmul fast float %755, %17
  %783 = fmul fast float %782, %781
  %784 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %783)  ; FMin(a,b)
  %785 = fmul fast float %784, 0xBFF7154760000000
  %786 = call float @dx.op.unary.f32(i32 21, float %785)  ; Exp(value)
  %787 = fsub fast float 1.000000e+00, %786
  %788 = call float @dx.op.binary.f32(i32 36, float %13, float %787)  ; FMin(a,b)
  %789 = fsub fast float %14, %667
  %790 = fsub fast float %15, %668
  %791 = fsub fast float %16, %669
  %792 = fmul fast float %788, %789
  %793 = fmul fast float %788, %790
  %794 = fmul fast float %788, %791
  %795 = fadd fast float %792, %667
  %796 = fadd fast float %793, %668
  %797 = fadd fast float %794, %669
  br label %798

; <label>:798                                     ; preds = %780, %712, %706
  %799 = phi float [ %795, %780 ], [ %667, %712 ], [ %667, %706 ]
  %800 = phi float [ %796, %780 ], [ %668, %712 ], [ %668, %706 ]
  %801 = phi float [ %797, %780 ], [ %669, %712 ], [ %669, %706 ]
  %802 = fadd fast float %6, 1.000000e+00
  %803 = fadd fast float %7, 1.000000e+00
  %804 = fsub fast float 1.000000e+00, %6
  %805 = fmul fast float %37, %802
  %806 = fmul fast float %37, %803
  %807 = fmul fast float %37, %804
  %808 = fmul fast float %805, %799
  %809 = fmul fast float %806, %800
  %810 = fmul fast float %807, %801
  %811 = fcmp fast ult float %38, 5.000000e-01
  br i1 %811, label %837, label %812

; <label>:812                                     ; preds = %798
  %813 = fmul fast float %808, 0x4004147AE0000000
  %814 = fmul fast float %809, 0x4004147AE0000000
  %815 = fmul fast float %810, 0x4004147AE0000000
  %816 = fadd fast float %813, 0x3F9EB851E0000000
  %817 = fadd fast float %814, 0x3F9EB851E0000000
  %818 = fadd fast float %815, 0x3F9EB851E0000000
  %819 = fmul fast float %816, %808
  %820 = fmul fast float %817, %809
  %821 = fmul fast float %818, %810
  %822 = fmul fast float %808, 0x400370A3E0000000
  %823 = fmul fast float %809, 0x400370A3E0000000
  %824 = fmul fast float %810, 0x400370A3E0000000
  %825 = fadd fast float %822, 0x3FE2E147A0000000
  %826 = fadd fast float %823, 0x3FE2E147A0000000
  %827 = fadd fast float %824, 0x3FE2E147A0000000
  %828 = fmul fast float %825, %808
  %829 = fmul fast float %826, %809
  %830 = fmul fast float %827, %810
  %831 = fadd fast float %828, 0x3FC1EB8520000000
  %832 = fadd fast float %829, 0x3FC1EB8520000000
  %833 = fadd fast float %830, 0x3FC1EB8520000000
  %834 = fdiv fast float %819, %831
  %835 = fdiv fast float %820, %832
  %836 = fdiv fast float %821, %833
  br label %837

; <label>:837                                     ; preds = %812, %798
  %838 = phi float [ %834, %812 ], [ %808, %798 ]
  %839 = phi float [ %835, %812 ], [ %809, %798 ]
  %840 = phi float [ %836, %812 ], [ %810, %798 ]
  %841 = call float @dx.op.unary.f32(i32 7, float %838)  ; Saturate(value)
  %842 = call float @dx.op.unary.f32(i32 7, float %839)  ; Saturate(value)
  %843 = call float @dx.op.unary.f32(i32 7, float %840)  ; Saturate(value)
  %844 = call float @dx.op.dot3.f32(i32 55, float %841, float %842, float %843, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %845 = fsub fast float %841, %844
  %846 = fsub fast float %842, %844
  %847 = fsub fast float %843, %844
  %848 = fmul fast float %845, %9
  %849 = fmul fast float %846, %9
  %850 = fmul fast float %847, %9
  %851 = fadd fast float %848, %844
  %852 = fadd fast float %849, %844
  %853 = fadd fast float %850, %844
  %854 = call float @dx.op.unary.f32(i32 7, float %851)  ; Saturate(value)
  %855 = call float @dx.op.unary.f32(i32 7, float %852)  ; Saturate(value)
  %856 = call float @dx.op.unary.f32(i32 7, float %853)  ; Saturate(value)
  %857 = fadd fast float %854, 0xBFC70A3D80000000
  %858 = fadd fast float %855, 0xBFC70A3D80000000
  %859 = fadd fast float %856, 0xBFC70A3D80000000
  %860 = fmul fast float %857, %8
  %861 = fmul fast float %858, %8
  %862 = fmul fast float %859, %8
  %863 = fadd fast float %860, 0x3FC70A3D80000000
  %864 = fadd fast float %861, 0x3FC70A3D80000000
  %865 = fadd fast float %862, 0x3FC70A3D80000000
  %866 = call float @dx.op.unary.f32(i32 7, float %863)  ; Saturate(value)
  %867 = call float @dx.op.unary.f32(i32 7, float %864)  ; Saturate(value)
  %868 = call float @dx.op.unary.f32(i32 7, float %865)  ; Saturate(value)
  br label %869

; <label>:869                                     ; preds = %837, %672
  %870 = phi float [ %703, %672 ], [ %866, %837 ]
  %871 = phi float [ %704, %672 ], [ %867, %837 ]
  %872 = phi float [ %705, %672 ], [ %868, %837 ]
  %873 = add i32 %64, 1
  %874 = call i32 @dx.op.binary.i32(i32 37, i32 %873, i32 0)  ; IMax(a,b)
  %875 = call i32 @dx.op.binary.i32(i32 38, i32 %874, i32 %60)  ; IMin(a,b)
  %876 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %875, i32 %665, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %877 = extractvalue %dx.types.ResRet.f32 %876, 0
  %878 = extractvalue %dx.types.ResRet.f32 %876, 1
  %879 = extractvalue %dx.types.ResRet.f32 %876, 2
  %880 = extractvalue %dx.types.ResRet.f32 %876, 3
  %881 = fcmp fast olt float %880, 0.000000e+00
  br i1 %881, label %882, label %916

; <label>:882                                     ; preds = %869
  %883 = fcmp fast ogt float %877, 0x3FA4B5DCC0000000
  %884 = fcmp fast ogt float %878, 0x3FA4B5DCC0000000
  %885 = fcmp fast ogt float %879, 0x3FA4B5DCC0000000
  %886 = select i1 %883, float 0.000000e+00, float 1.000000e+00
  %887 = select i1 %884, float 0.000000e+00, float 1.000000e+00
  %888 = select i1 %885, float 0.000000e+00, float 1.000000e+00
  %889 = fmul fast float %877, 0x3FB3D07220000000
  %890 = fmul fast float %878, 0x3FB3D07220000000
  %891 = fmul fast float %879, 0x3FB3D07220000000
  %892 = fadd fast float %877, 0x3FAC28F5C0000000
  %893 = fadd fast float %878, 0x3FAC28F5C0000000
  %894 = fadd fast float %879, 0x3FAC28F5C0000000
  %895 = fmul fast float %892, 0x3FEE54EDE0000000
  %896 = fmul fast float %893, 0x3FEE54EDE0000000
  %897 = fmul fast float %894, 0x3FEE54EDE0000000
  %898 = call float @dx.op.unary.f32(i32 23, float %895)  ; Log(value)
  %899 = call float @dx.op.unary.f32(i32 23, float %896)  ; Log(value)
  %900 = call float @dx.op.unary.f32(i32 23, float %897)  ; Log(value)
  %901 = fmul fast float %898, 0x4003333340000000
  %902 = fmul fast float %899, 0x4003333340000000
  %903 = fmul fast float %900, 0x4003333340000000
  %904 = call float @dx.op.unary.f32(i32 21, float %901)  ; Exp(value)
  %905 = call float @dx.op.unary.f32(i32 21, float %902)  ; Exp(value)
  %906 = call float @dx.op.unary.f32(i32 21, float %903)  ; Exp(value)
  %907 = fsub fast float %889, %904
  %908 = fsub fast float %890, %905
  %909 = fsub fast float %891, %906
  %910 = fmul fast float %907, %886
  %911 = fmul fast float %908, %887
  %912 = fmul fast float %909, %888
  %913 = fadd fast float %910, %904
  %914 = fadd fast float %911, %905
  %915 = fadd fast float %912, %906
  br label %1079

; <label>:916                                     ; preds = %869
  %917 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %875, i32 %665, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %918 = extractvalue %dx.types.ResRet.f32 %917, 0
  %919 = fcmp fast ogt float %39, 5.000000e-01
  %920 = fcmp fast olt float %918, 1.000000e+00
  %921 = and i1 %919, %920
  br i1 %921, label %922, label %1008

; <label>:922                                     ; preds = %916
  %923 = sitofp i32 %875 to float
  %924 = sitofp i32 %665 to float
  %925 = fadd fast float %923, 5.000000e-01
  %926 = fadd fast float %924, 5.000000e-01
  %927 = fdiv fast float %925, %46
  %928 = fdiv fast float %926, %47
  %929 = fmul fast float %927, 2.000000e+00
  %930 = fmul fast float %928, 2.000000e+00
  %931 = fadd fast float %929, -1.000000e+00
  %932 = fsub fast float 1.000000e+00, %930
  %933 = fmul fast float %931, %36
  %934 = call float @dx.op.tertiary.f32(i32 46, float %932, float %32, float %933)  ; FMad(a,b,c)
  %935 = call float @dx.op.tertiary.f32(i32 46, float %918, float %28, float %934)  ; FMad(a,b,c)
  %936 = fadd fast float %935, %24
  %937 = call float @dx.op.unary.f32(i32 6, float %936)  ; FAbs(value)
  %938 = fcmp fast ogt float %937, 0x3EB0C6F7A0000000
  br i1 %938, label %939, label %1008

; <label>:939                                     ; preds = %922
  %940 = fmul fast float %931, %35
  %941 = call float @dx.op.tertiary.f32(i32 46, float %932, float %31, float %940)  ; FMad(a,b,c)
  %942 = call float @dx.op.tertiary.f32(i32 46, float %918, float %27, float %941)  ; FMad(a,b,c)
  %943 = fadd fast float %942, %23
  %944 = fmul fast float %931, %34
  %945 = call float @dx.op.tertiary.f32(i32 46, float %932, float %30, float %944)  ; FMad(a,b,c)
  %946 = call float @dx.op.tertiary.f32(i32 46, float %918, float %26, float %945)  ; FMad(a,b,c)
  %947 = fadd fast float %946, %22
  %948 = fmul fast float %931, %33
  %949 = call float @dx.op.tertiary.f32(i32 46, float %932, float %29, float %948)  ; FMad(a,b,c)
  %950 = call float @dx.op.tertiary.f32(i32 46, float %918, float %25, float %949)  ; FMad(a,b,c)
  %951 = fadd fast float %950, %21
  %952 = fdiv fast float %951, %936
  %953 = fdiv fast float %947, %936
  %954 = fdiv fast float %943, %936
  %955 = fsub fast float %952, %18
  %956 = fsub fast float %953, %19
  %957 = fsub fast float %954, %20
  %958 = fmul fast float %955, %955
  %959 = fmul fast float %956, %956
  %960 = fadd fast float %959, %958
  %961 = fmul fast float %957, %957
  %962 = fadd fast float %960, %961
  %963 = call float @dx.op.unary.f32(i32 24, float %962)  ; Sqrt(value)
  %964 = fsub fast float %963, %10
  %965 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %964)  ; FMax(a,b)
  %966 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %966, label %967, label %990

; <label>:967                                     ; preds = %939
  %968 = call float @dx.op.unary.f32(i32 6, float %956)  ; FAbs(value)
  %969 = fmul fast float %968, %12
  %970 = fcmp fast olt float %969, 0x3F50624DE0000000
  br i1 %970, label %971, label %974

; <label>:971                                     ; preds = %967
  %972 = fmul fast float %969, 5.000000e-01
  %973 = fsub fast float 1.000000e+00, %972
  br label %979

; <label>:974                                     ; preds = %967
  %975 = fmul fast float %969, 0xBFF7154760000000
  %976 = call float @dx.op.unary.f32(i32 21, float %975)  ; Exp(value)
  %977 = fsub fast float 1.000000e+00, %976
  %978 = fdiv fast float %977, %969
  br label %979

; <label>:979                                     ; preds = %974, %971
  %980 = phi float [ %973, %971 ], [ %978, %974 ]
  %981 = call float @dx.op.binary.f32(i32 36, float %953, float %19)  ; FMin(a,b)
  %982 = fsub fast float %981, %11
  %983 = fmul fast float %12, %982
  %984 = fsub fast float -0.000000e+00, %983
  %985 = call float @dx.op.binary.f32(i32 35, float %984, float -4.000000e+01)  ; FMax(a,b)
  %986 = call float @dx.op.binary.f32(i32 36, float %985, float 5.000000e+00)  ; FMin(a,b)
  %987 = fmul fast float %986, 0x3FF7154760000000
  %988 = call float @dx.op.unary.f32(i32 21, float %987)  ; Exp(value)
  %989 = fmul fast float %988, %980
  br label %990

; <label>:990                                     ; preds = %979, %939
  %991 = phi float [ %989, %979 ], [ 1.000000e+00, %939 ]
  %992 = fmul fast float %965, %17
  %993 = fmul fast float %992, %991
  %994 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %993)  ; FMin(a,b)
  %995 = fmul fast float %994, 0xBFF7154760000000
  %996 = call float @dx.op.unary.f32(i32 21, float %995)  ; Exp(value)
  %997 = fsub fast float 1.000000e+00, %996
  %998 = call float @dx.op.binary.f32(i32 36, float %13, float %997)  ; FMin(a,b)
  %999 = fsub fast float %14, %877
  %1000 = fsub fast float %15, %878
  %1001 = fsub fast float %16, %879
  %1002 = fmul fast float %998, %999
  %1003 = fmul fast float %998, %1000
  %1004 = fmul fast float %998, %1001
  %1005 = fadd fast float %1002, %877
  %1006 = fadd fast float %1003, %878
  %1007 = fadd fast float %1004, %879
  br label %1008

; <label>:1008                                    ; preds = %990, %922, %916
  %1009 = phi float [ %1005, %990 ], [ %877, %922 ], [ %877, %916 ]
  %1010 = phi float [ %1006, %990 ], [ %878, %922 ], [ %878, %916 ]
  %1011 = phi float [ %1007, %990 ], [ %879, %922 ], [ %879, %916 ]
  %1012 = fadd fast float %6, 1.000000e+00
  %1013 = fadd fast float %7, 1.000000e+00
  %1014 = fsub fast float 1.000000e+00, %6
  %1015 = fmul fast float %37, %1012
  %1016 = fmul fast float %37, %1013
  %1017 = fmul fast float %37, %1014
  %1018 = fmul fast float %1015, %1009
  %1019 = fmul fast float %1016, %1010
  %1020 = fmul fast float %1017, %1011
  %1021 = fcmp fast ult float %38, 5.000000e-01
  br i1 %1021, label %1047, label %1022

; <label>:1022                                    ; preds = %1008
  %1023 = fmul fast float %1018, 0x4004147AE0000000
  %1024 = fmul fast float %1019, 0x4004147AE0000000
  %1025 = fmul fast float %1020, 0x4004147AE0000000
  %1026 = fadd fast float %1023, 0x3F9EB851E0000000
  %1027 = fadd fast float %1024, 0x3F9EB851E0000000
  %1028 = fadd fast float %1025, 0x3F9EB851E0000000
  %1029 = fmul fast float %1026, %1018
  %1030 = fmul fast float %1027, %1019
  %1031 = fmul fast float %1028, %1020
  %1032 = fmul fast float %1018, 0x400370A3E0000000
  %1033 = fmul fast float %1019, 0x400370A3E0000000
  %1034 = fmul fast float %1020, 0x400370A3E0000000
  %1035 = fadd fast float %1032, 0x3FE2E147A0000000
  %1036 = fadd fast float %1033, 0x3FE2E147A0000000
  %1037 = fadd fast float %1034, 0x3FE2E147A0000000
  %1038 = fmul fast float %1035, %1018
  %1039 = fmul fast float %1036, %1019
  %1040 = fmul fast float %1037, %1020
  %1041 = fadd fast float %1038, 0x3FC1EB8520000000
  %1042 = fadd fast float %1039, 0x3FC1EB8520000000
  %1043 = fadd fast float %1040, 0x3FC1EB8520000000
  %1044 = fdiv fast float %1029, %1041
  %1045 = fdiv fast float %1030, %1042
  %1046 = fdiv fast float %1031, %1043
  br label %1047

; <label>:1047                                    ; preds = %1022, %1008
  %1048 = phi float [ %1044, %1022 ], [ %1018, %1008 ]
  %1049 = phi float [ %1045, %1022 ], [ %1019, %1008 ]
  %1050 = phi float [ %1046, %1022 ], [ %1020, %1008 ]
  %1051 = call float @dx.op.unary.f32(i32 7, float %1048)  ; Saturate(value)
  %1052 = call float @dx.op.unary.f32(i32 7, float %1049)  ; Saturate(value)
  %1053 = call float @dx.op.unary.f32(i32 7, float %1050)  ; Saturate(value)
  %1054 = call float @dx.op.dot3.f32(i32 55, float %1051, float %1052, float %1053, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1055 = fsub fast float %1051, %1054
  %1056 = fsub fast float %1052, %1054
  %1057 = fsub fast float %1053, %1054
  %1058 = fmul fast float %1055, %9
  %1059 = fmul fast float %1056, %9
  %1060 = fmul fast float %1057, %9
  %1061 = fadd fast float %1058, %1054
  %1062 = fadd fast float %1059, %1054
  %1063 = fadd fast float %1060, %1054
  %1064 = call float @dx.op.unary.f32(i32 7, float %1061)  ; Saturate(value)
  %1065 = call float @dx.op.unary.f32(i32 7, float %1062)  ; Saturate(value)
  %1066 = call float @dx.op.unary.f32(i32 7, float %1063)  ; Saturate(value)
  %1067 = fadd fast float %1064, 0xBFC70A3D80000000
  %1068 = fadd fast float %1065, 0xBFC70A3D80000000
  %1069 = fadd fast float %1066, 0xBFC70A3D80000000
  %1070 = fmul fast float %1067, %8
  %1071 = fmul fast float %1068, %8
  %1072 = fmul fast float %1069, %8
  %1073 = fadd fast float %1070, 0x3FC70A3D80000000
  %1074 = fadd fast float %1071, 0x3FC70A3D80000000
  %1075 = fadd fast float %1072, 0x3FC70A3D80000000
  %1076 = call float @dx.op.unary.f32(i32 7, float %1073)  ; Saturate(value)
  %1077 = call float @dx.op.unary.f32(i32 7, float %1074)  ; Saturate(value)
  %1078 = call float @dx.op.unary.f32(i32 7, float %1075)  ; Saturate(value)
  br label %1079

; <label>:1079                                    ; preds = %1047, %882
  %1080 = phi float [ %913, %882 ], [ %1076, %1047 ]
  %1081 = phi float [ %914, %882 ], [ %1077, %1047 ]
  %1082 = phi float [ %915, %882 ], [ %1078, %1047 ]
  %1083 = call float @dx.op.binary.f32(i32 36, float %870, float %1080)  ; FMin(a,b)
  %1084 = call float @dx.op.binary.f32(i32 36, float %871, float %1081)  ; FMin(a,b)
  %1085 = call float @dx.op.binary.f32(i32 36, float %872, float %1082)  ; FMin(a,b)
  %1086 = call float @dx.op.binary.f32(i32 36, float %448, float %658)  ; FMin(a,b)
  %1087 = call float @dx.op.binary.f32(i32 36, float %449, float %659)  ; FMin(a,b)
  %1088 = call float @dx.op.binary.f32(i32 36, float %450, float %660)  ; FMin(a,b)
  %1089 = call float @dx.op.binary.f32(i32 36, float %1086, float %1083)  ; FMin(a,b)
  %1090 = call float @dx.op.binary.f32(i32 36, float %1087, float %1084)  ; FMin(a,b)
  %1091 = call float @dx.op.binary.f32(i32 36, float %1088, float %1085)  ; FMin(a,b)
  %1092 = call float @dx.op.binary.f32(i32 36, float %234, float %1089)  ; FMin(a,b)
  %1093 = call float @dx.op.binary.f32(i32 36, float %235, float %1090)  ; FMin(a,b)
  %1094 = call float @dx.op.binary.f32(i32 36, float %236, float %1091)  ; FMin(a,b)
  %1095 = call float @dx.op.binary.f32(i32 35, float %870, float %1080)  ; FMax(a,b)
  %1096 = call float @dx.op.binary.f32(i32 35, float %871, float %1081)  ; FMax(a,b)
  %1097 = call float @dx.op.binary.f32(i32 35, float %872, float %1082)  ; FMax(a,b)
  %1098 = call float @dx.op.binary.f32(i32 35, float %448, float %658)  ; FMax(a,b)
  %1099 = call float @dx.op.binary.f32(i32 35, float %449, float %659)  ; FMax(a,b)
  %1100 = call float @dx.op.binary.f32(i32 35, float %450, float %660)  ; FMax(a,b)
  %1101 = call float @dx.op.binary.f32(i32 35, float %1098, float %1095)  ; FMax(a,b)
  %1102 = call float @dx.op.binary.f32(i32 35, float %1099, float %1096)  ; FMax(a,b)
  %1103 = call float @dx.op.binary.f32(i32 35, float %1100, float %1097)  ; FMax(a,b)
  %1104 = call float @dx.op.binary.f32(i32 35, float %234, float %1101)  ; FMax(a,b)
  %1105 = call float @dx.op.binary.f32(i32 35, float %235, float %1102)  ; FMax(a,b)
  %1106 = call float @dx.op.binary.f32(i32 35, float %236, float %1103)  ; FMax(a,b)
  %1107 = fsub fast float %1104, %1092
  %1108 = fsub fast float %1105, %1093
  %1109 = fsub fast float %1106, %1094
  %1110 = call float @dx.op.unary.f32(i32 6, float %1107)  ; FAbs(value)
  %1111 = call float @dx.op.unary.f32(i32 6, float %1108)  ; FAbs(value)
  %1112 = call float @dx.op.unary.f32(i32 6, float %1109)  ; FAbs(value)
  %1113 = call float @dx.op.binary.f32(i32 35, float %1111, float %1112)  ; FMax(a,b)
  %1114 = call float @dx.op.binary.f32(i32 35, float %1110, float %1113)  ; FMax(a,b)
  %1115 = call float @dx.op.binary.f32(i32 35, float %1105, float %1106)  ; FMax(a,b)
  %1116 = call float @dx.op.binary.f32(i32 35, float %1104, float %1115)  ; FMax(a,b)
  %1117 = fmul fast float %1116, 1.250000e-01
  %1118 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1117)  ; FMax(a,b)
  %1119 = fcmp fast ogt float %1114, %1118
  br i1 %1119, label %1120, label %1182

; <label>:1120                                    ; preds = %1079
  %1121 = fsub fast float %448, %658
  %1122 = fsub fast float %449, %659
  %1123 = fsub fast float %450, %660
  %1124 = call float @dx.op.unary.f32(i32 6, float %1121)  ; FAbs(value)
  %1125 = call float @dx.op.unary.f32(i32 6, float %1122)  ; FAbs(value)
  %1126 = call float @dx.op.unary.f32(i32 6, float %1123)  ; FAbs(value)
  %1127 = call float @dx.op.binary.f32(i32 35, float %1125, float %1126)  ; FMax(a,b)
  %1128 = call float @dx.op.binary.f32(i32 35, float %1124, float %1127)  ; FMax(a,b)
  %1129 = fsub fast float %870, %1080
  %1130 = fsub fast float %871, %1081
  %1131 = fsub fast float %872, %1082
  %1132 = call float @dx.op.unary.f32(i32 6, float %1129)  ; FAbs(value)
  %1133 = call float @dx.op.unary.f32(i32 6, float %1130)  ; FAbs(value)
  %1134 = call float @dx.op.unary.f32(i32 6, float %1131)  ; FAbs(value)
  %1135 = call float @dx.op.binary.f32(i32 35, float %1133, float %1134)  ; FMax(a,b)
  %1136 = call float @dx.op.binary.f32(i32 35, float %1132, float %1135)  ; FMax(a,b)
  %1137 = fcmp fast olt float %1128, %1136
  %1138 = select i1 %1137, float %448, float %870
  %1139 = select i1 %1137, float %449, float %871
  %1140 = select i1 %1137, float %450, float %872
  %1141 = select i1 %1137, float %658, float %1080
  %1142 = select i1 %1137, float %659, float %1081
  %1143 = select i1 %1137, float %660, float %1082
  %1144 = fsub fast float %234, %1141
  %1145 = fsub fast float %235, %1142
  %1146 = fsub fast float %236, %1143
  %1147 = fsub fast float %234, %1138
  %1148 = fsub fast float %235, %1139
  %1149 = fsub fast float %236, %1140
  %1150 = call float @dx.op.dot3.f32(i32 55, float %1147, float %1148, float %1149, float %1144, float %1145, float %1146)  ; Dot3(ax,ay,az,bx,by,bz)
  %1151 = fcmp fast ogt float %1150, 0.000000e+00
  br i1 %1151, label %1152, label %1163

; <label>:1152                                    ; preds = %1120
  %1153 = fsub fast float %1138, %1141
  %1154 = fsub fast float %1139, %1142
  %1155 = fsub fast float %1140, %1143
  %1156 = call float @dx.op.unary.f32(i32 6, float %1153)  ; FAbs(value)
  %1157 = call float @dx.op.unary.f32(i32 6, float %1154)  ; FAbs(value)
  %1158 = call float @dx.op.unary.f32(i32 6, float %1155)  ; FAbs(value)
  %1159 = call float @dx.op.binary.f32(i32 35, float %1157, float %1158)  ; FMax(a,b)
  %1160 = call float @dx.op.binary.f32(i32 35, float %1156, float %1159)  ; FMax(a,b)
  %1161 = fmul fast float %1114, 2.500000e-01
  %1162 = fcmp fast olt float %1160, %1161
  br label %1163

; <label>:1163                                    ; preds = %1152, %1120
  %1164 = phi i1 [ false, %1120 ], [ %1162, %1152 ]
  %1165 = select i1 %1164, float 5.000000e-01, float 1.000000e+00
  %1166 = fmul fast float %1165, %3
  %1167 = fadd fast float %1138, %1141
  %1168 = fadd fast float %1139, %1142
  %1169 = fadd fast float %1140, %1143
  %1170 = fmul fast float %1167, 5.000000e-01
  %1171 = fmul fast float %1168, 5.000000e-01
  %1172 = fmul fast float %1169, 5.000000e-01
  %1173 = fsub fast float %1170, %234
  %1174 = fsub fast float %1171, %235
  %1175 = fsub fast float %1172, %236
  %1176 = fmul fast float %1166, %1173
  %1177 = fmul fast float %1166, %1174
  %1178 = fmul fast float %1166, %1175
  %1179 = fadd fast float %1176, %234
  %1180 = fadd fast float %1177, %235
  %1181 = fadd fast float %1178, %236
  br label %1182

; <label>:1182                                    ; preds = %1163, %1079, %205
  %1183 = phi float [ %1179, %1163 ], [ %234, %1079 ], [ %234, %205 ]
  %1184 = phi float [ %1180, %1163 ], [ %235, %1079 ], [ %235, %205 ]
  %1185 = phi float [ %1181, %1163 ], [ %236, %1079 ], [ %236, %205 ]
  %1186 = fcmp fast ogt float %1183, 0x3F69A5C380000000
  %1187 = fcmp fast ogt float %1184, 0x3F69A5C380000000
  %1188 = fcmp fast ogt float %1185, 0x3F69A5C380000000
  %1189 = select i1 %1186, float 0.000000e+00, float 1.000000e+00
  %1190 = select i1 %1187, float 0.000000e+00, float 1.000000e+00
  %1191 = select i1 %1188, float 0.000000e+00, float 1.000000e+00
  %1192 = fmul fast float %1183, 0x4029D70A40000000
  %1193 = fmul fast float %1184, 0x4029D70A40000000
  %1194 = fmul fast float %1185, 0x4029D70A40000000
  %1195 = call float @dx.op.binary.f32(i32 35, float %1183, float 0.000000e+00)  ; FMax(a,b)
  %1196 = call float @dx.op.binary.f32(i32 35, float %1184, float 0.000000e+00)  ; FMax(a,b)
  %1197 = call float @dx.op.binary.f32(i32 35, float %1185, float 0.000000e+00)  ; FMax(a,b)
  %1198 = call float @dx.op.unary.f32(i32 23, float %1195)  ; Log(value)
  %1199 = call float @dx.op.unary.f32(i32 23, float %1196)  ; Log(value)
  %1200 = call float @dx.op.unary.f32(i32 23, float %1197)  ; Log(value)
  %1201 = fmul fast float %1198, 0x3FDAAAAAA0000000
  %1202 = fmul fast float %1199, 0x3FDAAAAAA0000000
  %1203 = fmul fast float %1200, 0x3FDAAAAAA0000000
  %1204 = call float @dx.op.unary.f32(i32 21, float %1201)  ; Exp(value)
  %1205 = call float @dx.op.unary.f32(i32 21, float %1202)  ; Exp(value)
  %1206 = call float @dx.op.unary.f32(i32 21, float %1203)  ; Exp(value)
  %1207 = fmul fast float %1204, 0x3FF0E147A0000000
  %1208 = fmul fast float %1205, 0x3FF0E147A0000000
  %1209 = fmul fast float %1206, 0x3FF0E147A0000000
  %1210 = fadd fast float %1207, 0xBFAC28F5C0000000
  %1211 = fadd fast float %1208, 0xBFAC28F5C0000000
  %1212 = fadd fast float %1209, 0xBFAC28F5C0000000
  %1213 = fsub fast float %1192, %1210
  %1214 = fsub fast float %1193, %1211
  %1215 = fsub fast float %1194, %1212
  %1216 = fmul fast float %1213, %1189
  %1217 = fmul fast float %1214, %1190
  %1218 = fmul fast float %1215, %1191
  %1219 = fadd fast float %1216, %1210
  %1220 = fadd fast float %1217, %1211
  %1221 = fadd fast float %1218, %1212
  br label %1222

; <label>:1222                                    ; preds = %1182, %72
  %1223 = phi float [ %67, %72 ], [ %1219, %1182 ]
  %1224 = phi float [ %68, %72 ], [ %1220, %1182 ]
  %1225 = phi float [ %69, %72 ], [ %1221, %1182 ]
  %1226 = phi float [ %73, %72 ], [ %70, %1182 ]
  %1227 = add i32 %56, 1
  %1228 = call i32 @dx.op.binary.i32(i32 37, i32 %1227, i32 0)  ; IMax(a,b)
  %1229 = call i32 @dx.op.binary.i32(i32 38, i32 %1228, i32 %60)  ; IMin(a,b)
  %1230 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1229, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1231 = extractvalue %dx.types.ResRet.f32 %1230, 0
  %1232 = extractvalue %dx.types.ResRet.f32 %1230, 1
  %1233 = extractvalue %dx.types.ResRet.f32 %1230, 2
  %1234 = extractvalue %dx.types.ResRet.f32 %1230, 3
  %1235 = fcmp fast olt float %1234, 0.000000e+00
  br i1 %1235, label %1236, label %1238

; <label>:1236                                    ; preds = %1222
  %1237 = fsub fast float -1.000000e+00, %1234
  br label %2386

; <label>:1238                                    ; preds = %1222
  %1239 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1229, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1240 = extractvalue %dx.types.ResRet.f32 %1239, 0
  %1241 = fcmp fast ogt float %39, 5.000000e-01
  %1242 = fcmp fast olt float %1240, 1.000000e+00
  %1243 = and i1 %1241, %1242
  br i1 %1243, label %1244, label %1330

; <label>:1244                                    ; preds = %1238
  %1245 = sitofp i32 %1229 to float
  %1246 = sitofp i32 %65 to float
  %1247 = fadd fast float %1245, 5.000000e-01
  %1248 = fadd fast float %1246, 5.000000e-01
  %1249 = fdiv fast float %1247, %46
  %1250 = fdiv fast float %1248, %47
  %1251 = fmul fast float %1249, 2.000000e+00
  %1252 = fmul fast float %1250, 2.000000e+00
  %1253 = fadd fast float %1251, -1.000000e+00
  %1254 = fsub fast float 1.000000e+00, %1252
  %1255 = fmul fast float %1253, %36
  %1256 = call float @dx.op.tertiary.f32(i32 46, float %1254, float %32, float %1255)  ; FMad(a,b,c)
  %1257 = call float @dx.op.tertiary.f32(i32 46, float %1240, float %28, float %1256)  ; FMad(a,b,c)
  %1258 = fadd fast float %1257, %24
  %1259 = call float @dx.op.unary.f32(i32 6, float %1258)  ; FAbs(value)
  %1260 = fcmp fast ogt float %1259, 0x3EB0C6F7A0000000
  br i1 %1260, label %1261, label %1330

; <label>:1261                                    ; preds = %1244
  %1262 = fmul fast float %1253, %35
  %1263 = call float @dx.op.tertiary.f32(i32 46, float %1254, float %31, float %1262)  ; FMad(a,b,c)
  %1264 = call float @dx.op.tertiary.f32(i32 46, float %1240, float %27, float %1263)  ; FMad(a,b,c)
  %1265 = fadd fast float %1264, %23
  %1266 = fmul fast float %1253, %34
  %1267 = call float @dx.op.tertiary.f32(i32 46, float %1254, float %30, float %1266)  ; FMad(a,b,c)
  %1268 = call float @dx.op.tertiary.f32(i32 46, float %1240, float %26, float %1267)  ; FMad(a,b,c)
  %1269 = fadd fast float %1268, %22
  %1270 = fmul fast float %1253, %33
  %1271 = call float @dx.op.tertiary.f32(i32 46, float %1254, float %29, float %1270)  ; FMad(a,b,c)
  %1272 = call float @dx.op.tertiary.f32(i32 46, float %1240, float %25, float %1271)  ; FMad(a,b,c)
  %1273 = fadd fast float %1272, %21
  %1274 = fdiv fast float %1273, %1258
  %1275 = fdiv fast float %1269, %1258
  %1276 = fdiv fast float %1265, %1258
  %1277 = fsub fast float %1274, %18
  %1278 = fsub fast float %1275, %19
  %1279 = fsub fast float %1276, %20
  %1280 = fmul fast float %1277, %1277
  %1281 = fmul fast float %1278, %1278
  %1282 = fadd fast float %1281, %1280
  %1283 = fmul fast float %1279, %1279
  %1284 = fadd fast float %1282, %1283
  %1285 = call float @dx.op.unary.f32(i32 24, float %1284)  ; Sqrt(value)
  %1286 = fsub fast float %1285, %10
  %1287 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1286)  ; FMax(a,b)
  %1288 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %1288, label %1289, label %1312

; <label>:1289                                    ; preds = %1261
  %1290 = call float @dx.op.unary.f32(i32 6, float %1278)  ; FAbs(value)
  %1291 = fmul fast float %1290, %12
  %1292 = fcmp fast olt float %1291, 0x3F50624DE0000000
  br i1 %1292, label %1293, label %1296

; <label>:1293                                    ; preds = %1289
  %1294 = fmul fast float %1291, 5.000000e-01
  %1295 = fsub fast float 1.000000e+00, %1294
  br label %1301

; <label>:1296                                    ; preds = %1289
  %1297 = fmul fast float %1291, 0xBFF7154760000000
  %1298 = call float @dx.op.unary.f32(i32 21, float %1297)  ; Exp(value)
  %1299 = fsub fast float 1.000000e+00, %1298
  %1300 = fdiv fast float %1299, %1291
  br label %1301

; <label>:1301                                    ; preds = %1296, %1293
  %1302 = phi float [ %1295, %1293 ], [ %1300, %1296 ]
  %1303 = call float @dx.op.binary.f32(i32 36, float %1275, float %19)  ; FMin(a,b)
  %1304 = fsub fast float %1303, %11
  %1305 = fmul fast float %12, %1304
  %1306 = fsub fast float -0.000000e+00, %1305
  %1307 = call float @dx.op.binary.f32(i32 35, float %1306, float -4.000000e+01)  ; FMax(a,b)
  %1308 = call float @dx.op.binary.f32(i32 36, float %1307, float 5.000000e+00)  ; FMin(a,b)
  %1309 = fmul fast float %1308, 0x3FF7154760000000
  %1310 = call float @dx.op.unary.f32(i32 21, float %1309)  ; Exp(value)
  %1311 = fmul fast float %1310, %1302
  br label %1312

; <label>:1312                                    ; preds = %1301, %1261
  %1313 = phi float [ %1311, %1301 ], [ 1.000000e+00, %1261 ]
  %1314 = fmul fast float %1287, %17
  %1315 = fmul fast float %1314, %1313
  %1316 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1315)  ; FMin(a,b)
  %1317 = fmul fast float %1316, 0xBFF7154760000000
  %1318 = call float @dx.op.unary.f32(i32 21, float %1317)  ; Exp(value)
  %1319 = fsub fast float 1.000000e+00, %1318
  %1320 = call float @dx.op.binary.f32(i32 36, float %13, float %1319)  ; FMin(a,b)
  %1321 = fsub fast float %14, %1231
  %1322 = fsub fast float %15, %1232
  %1323 = fsub fast float %16, %1233
  %1324 = fmul fast float %1320, %1321
  %1325 = fmul fast float %1320, %1322
  %1326 = fmul fast float %1320, %1323
  %1327 = fadd fast float %1324, %1231
  %1328 = fadd fast float %1325, %1232
  %1329 = fadd fast float %1326, %1233
  br label %1330

; <label>:1330                                    ; preds = %1312, %1244, %1238
  %1331 = phi float [ %1327, %1312 ], [ %1231, %1244 ], [ %1231, %1238 ]
  %1332 = phi float [ %1328, %1312 ], [ %1232, %1244 ], [ %1232, %1238 ]
  %1333 = phi float [ %1329, %1312 ], [ %1233, %1244 ], [ %1233, %1238 ]
  %1334 = fadd fast float %6, 1.000000e+00
  %1335 = fadd fast float %7, 1.000000e+00
  %1336 = fsub fast float 1.000000e+00, %6
  %1337 = fmul fast float %37, %1334
  %1338 = fmul fast float %37, %1335
  %1339 = fmul fast float %37, %1336
  %1340 = fmul fast float %1337, %1331
  %1341 = fmul fast float %1338, %1332
  %1342 = fmul fast float %1339, %1333
  %1343 = fcmp fast ult float %38, 5.000000e-01
  br i1 %1343, label %1369, label %1344

; <label>:1344                                    ; preds = %1330
  %1345 = fmul fast float %1340, 0x4004147AE0000000
  %1346 = fmul fast float %1341, 0x4004147AE0000000
  %1347 = fmul fast float %1342, 0x4004147AE0000000
  %1348 = fadd fast float %1345, 0x3F9EB851E0000000
  %1349 = fadd fast float %1346, 0x3F9EB851E0000000
  %1350 = fadd fast float %1347, 0x3F9EB851E0000000
  %1351 = fmul fast float %1348, %1340
  %1352 = fmul fast float %1349, %1341
  %1353 = fmul fast float %1350, %1342
  %1354 = fmul fast float %1340, 0x400370A3E0000000
  %1355 = fmul fast float %1341, 0x400370A3E0000000
  %1356 = fmul fast float %1342, 0x400370A3E0000000
  %1357 = fadd fast float %1354, 0x3FE2E147A0000000
  %1358 = fadd fast float %1355, 0x3FE2E147A0000000
  %1359 = fadd fast float %1356, 0x3FE2E147A0000000
  %1360 = fmul fast float %1357, %1340
  %1361 = fmul fast float %1358, %1341
  %1362 = fmul fast float %1359, %1342
  %1363 = fadd fast float %1360, 0x3FC1EB8520000000
  %1364 = fadd fast float %1361, 0x3FC1EB8520000000
  %1365 = fadd fast float %1362, 0x3FC1EB8520000000
  %1366 = fdiv fast float %1351, %1363
  %1367 = fdiv fast float %1352, %1364
  %1368 = fdiv fast float %1353, %1365
  br label %1369

; <label>:1369                                    ; preds = %1344, %1330
  %1370 = phi float [ %1366, %1344 ], [ %1340, %1330 ]
  %1371 = phi float [ %1367, %1344 ], [ %1341, %1330 ]
  %1372 = phi float [ %1368, %1344 ], [ %1342, %1330 ]
  %1373 = call float @dx.op.unary.f32(i32 7, float %1370)  ; Saturate(value)
  %1374 = call float @dx.op.unary.f32(i32 7, float %1371)  ; Saturate(value)
  %1375 = call float @dx.op.unary.f32(i32 7, float %1372)  ; Saturate(value)
  %1376 = call float @dx.op.dot3.f32(i32 55, float %1373, float %1374, float %1375, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1377 = fsub fast float %1373, %1376
  %1378 = fsub fast float %1374, %1376
  %1379 = fsub fast float %1375, %1376
  %1380 = fmul fast float %1377, %9
  %1381 = fmul fast float %1378, %9
  %1382 = fmul fast float %1379, %9
  %1383 = fadd fast float %1380, %1376
  %1384 = fadd fast float %1381, %1376
  %1385 = fadd fast float %1382, %1376
  %1386 = call float @dx.op.unary.f32(i32 7, float %1383)  ; Saturate(value)
  %1387 = call float @dx.op.unary.f32(i32 7, float %1384)  ; Saturate(value)
  %1388 = call float @dx.op.unary.f32(i32 7, float %1385)  ; Saturate(value)
  %1389 = fadd fast float %1386, 0xBFC70A3D80000000
  %1390 = fadd fast float %1387, 0xBFC70A3D80000000
  %1391 = fadd fast float %1388, 0xBFC70A3D80000000
  %1392 = fmul fast float %1389, %8
  %1393 = fmul fast float %1390, %8
  %1394 = fmul fast float %1391, %8
  %1395 = fadd fast float %1392, 0x3FC70A3D80000000
  %1396 = fadd fast float %1393, 0x3FC70A3D80000000
  %1397 = fadd fast float %1394, 0x3FC70A3D80000000
  %1398 = call float @dx.op.unary.f32(i32 7, float %1395)  ; Saturate(value)
  %1399 = call float @dx.op.unary.f32(i32 7, float %1396)  ; Saturate(value)
  %1400 = call float @dx.op.unary.f32(i32 7, float %1397)  ; Saturate(value)
  %1401 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %1401, label %1402, label %2346

; <label>:1402                                    ; preds = %1369
  %1403 = add i32 %65, -1
  %1404 = call i32 @dx.op.binary.i32(i32 37, i32 %1229, i32 0)  ; IMax(a,b)
  %1405 = call i32 @dx.op.binary.i32(i32 37, i32 %1403, i32 0)  ; IMax(a,b)
  %1406 = call i32 @dx.op.binary.i32(i32 38, i32 %1404, i32 %60)  ; IMin(a,b)
  %1407 = call i32 @dx.op.binary.i32(i32 38, i32 %1405, i32 %61)  ; IMin(a,b)
  %1408 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1406, i32 %1407, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1409 = extractvalue %dx.types.ResRet.f32 %1408, 0
  %1410 = extractvalue %dx.types.ResRet.f32 %1408, 1
  %1411 = extractvalue %dx.types.ResRet.f32 %1408, 2
  %1412 = extractvalue %dx.types.ResRet.f32 %1408, 3
  %1413 = fcmp fast olt float %1412, 0.000000e+00
  br i1 %1413, label %1414, label %1448

; <label>:1414                                    ; preds = %1402
  %1415 = fcmp fast ogt float %1409, 0x3FA4B5DCC0000000
  %1416 = fcmp fast ogt float %1410, 0x3FA4B5DCC0000000
  %1417 = fcmp fast ogt float %1411, 0x3FA4B5DCC0000000
  %1418 = select i1 %1415, float 0.000000e+00, float 1.000000e+00
  %1419 = select i1 %1416, float 0.000000e+00, float 1.000000e+00
  %1420 = select i1 %1417, float 0.000000e+00, float 1.000000e+00
  %1421 = fmul fast float %1409, 0x3FB3D07220000000
  %1422 = fmul fast float %1410, 0x3FB3D07220000000
  %1423 = fmul fast float %1411, 0x3FB3D07220000000
  %1424 = fadd fast float %1409, 0x3FAC28F5C0000000
  %1425 = fadd fast float %1410, 0x3FAC28F5C0000000
  %1426 = fadd fast float %1411, 0x3FAC28F5C0000000
  %1427 = fmul fast float %1424, 0x3FEE54EDE0000000
  %1428 = fmul fast float %1425, 0x3FEE54EDE0000000
  %1429 = fmul fast float %1426, 0x3FEE54EDE0000000
  %1430 = call float @dx.op.unary.f32(i32 23, float %1427)  ; Log(value)
  %1431 = call float @dx.op.unary.f32(i32 23, float %1428)  ; Log(value)
  %1432 = call float @dx.op.unary.f32(i32 23, float %1429)  ; Log(value)
  %1433 = fmul fast float %1430, 0x4003333340000000
  %1434 = fmul fast float %1431, 0x4003333340000000
  %1435 = fmul fast float %1432, 0x4003333340000000
  %1436 = call float @dx.op.unary.f32(i32 21, float %1433)  ; Exp(value)
  %1437 = call float @dx.op.unary.f32(i32 21, float %1434)  ; Exp(value)
  %1438 = call float @dx.op.unary.f32(i32 21, float %1435)  ; Exp(value)
  %1439 = fsub fast float %1421, %1436
  %1440 = fsub fast float %1422, %1437
  %1441 = fsub fast float %1423, %1438
  %1442 = fmul fast float %1439, %1418
  %1443 = fmul fast float %1440, %1419
  %1444 = fmul fast float %1441, %1420
  %1445 = fadd fast float %1442, %1436
  %1446 = fadd fast float %1443, %1437
  %1447 = fadd fast float %1444, %1438
  br label %1611

; <label>:1448                                    ; preds = %1402
  %1449 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1406, i32 %1407, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1450 = extractvalue %dx.types.ResRet.f32 %1449, 0
  %1451 = fcmp fast ogt float %39, 5.000000e-01
  %1452 = fcmp fast olt float %1450, 1.000000e+00
  %1453 = and i1 %1451, %1452
  br i1 %1453, label %1454, label %1540

; <label>:1454                                    ; preds = %1448
  %1455 = sitofp i32 %1406 to float
  %1456 = sitofp i32 %1407 to float
  %1457 = fadd fast float %1455, 5.000000e-01
  %1458 = fadd fast float %1456, 5.000000e-01
  %1459 = fdiv fast float %1457, %46
  %1460 = fdiv fast float %1458, %47
  %1461 = fmul fast float %1459, 2.000000e+00
  %1462 = fmul fast float %1460, 2.000000e+00
  %1463 = fadd fast float %1461, -1.000000e+00
  %1464 = fsub fast float 1.000000e+00, %1462
  %1465 = fmul fast float %1463, %36
  %1466 = call float @dx.op.tertiary.f32(i32 46, float %1464, float %32, float %1465)  ; FMad(a,b,c)
  %1467 = call float @dx.op.tertiary.f32(i32 46, float %1450, float %28, float %1466)  ; FMad(a,b,c)
  %1468 = fadd fast float %1467, %24
  %1469 = call float @dx.op.unary.f32(i32 6, float %1468)  ; FAbs(value)
  %1470 = fcmp fast ogt float %1469, 0x3EB0C6F7A0000000
  br i1 %1470, label %1471, label %1540

; <label>:1471                                    ; preds = %1454
  %1472 = fmul fast float %1463, %35
  %1473 = call float @dx.op.tertiary.f32(i32 46, float %1464, float %31, float %1472)  ; FMad(a,b,c)
  %1474 = call float @dx.op.tertiary.f32(i32 46, float %1450, float %27, float %1473)  ; FMad(a,b,c)
  %1475 = fadd fast float %1474, %23
  %1476 = fmul fast float %1463, %34
  %1477 = call float @dx.op.tertiary.f32(i32 46, float %1464, float %30, float %1476)  ; FMad(a,b,c)
  %1478 = call float @dx.op.tertiary.f32(i32 46, float %1450, float %26, float %1477)  ; FMad(a,b,c)
  %1479 = fadd fast float %1478, %22
  %1480 = fmul fast float %1463, %33
  %1481 = call float @dx.op.tertiary.f32(i32 46, float %1464, float %29, float %1480)  ; FMad(a,b,c)
  %1482 = call float @dx.op.tertiary.f32(i32 46, float %1450, float %25, float %1481)  ; FMad(a,b,c)
  %1483 = fadd fast float %1482, %21
  %1484 = fdiv fast float %1483, %1468
  %1485 = fdiv fast float %1479, %1468
  %1486 = fdiv fast float %1475, %1468
  %1487 = fsub fast float %1484, %18
  %1488 = fsub fast float %1485, %19
  %1489 = fsub fast float %1486, %20
  %1490 = fmul fast float %1487, %1487
  %1491 = fmul fast float %1488, %1488
  %1492 = fadd fast float %1491, %1490
  %1493 = fmul fast float %1489, %1489
  %1494 = fadd fast float %1492, %1493
  %1495 = call float @dx.op.unary.f32(i32 24, float %1494)  ; Sqrt(value)
  %1496 = fsub fast float %1495, %10
  %1497 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1496)  ; FMax(a,b)
  %1498 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %1498, label %1499, label %1522

; <label>:1499                                    ; preds = %1471
  %1500 = call float @dx.op.unary.f32(i32 6, float %1488)  ; FAbs(value)
  %1501 = fmul fast float %1500, %12
  %1502 = fcmp fast olt float %1501, 0x3F50624DE0000000
  br i1 %1502, label %1503, label %1506

; <label>:1503                                    ; preds = %1499
  %1504 = fmul fast float %1501, 5.000000e-01
  %1505 = fsub fast float 1.000000e+00, %1504
  br label %1511

; <label>:1506                                    ; preds = %1499
  %1507 = fmul fast float %1501, 0xBFF7154760000000
  %1508 = call float @dx.op.unary.f32(i32 21, float %1507)  ; Exp(value)
  %1509 = fsub fast float 1.000000e+00, %1508
  %1510 = fdiv fast float %1509, %1501
  br label %1511

; <label>:1511                                    ; preds = %1506, %1503
  %1512 = phi float [ %1505, %1503 ], [ %1510, %1506 ]
  %1513 = call float @dx.op.binary.f32(i32 36, float %1485, float %19)  ; FMin(a,b)
  %1514 = fsub fast float %1513, %11
  %1515 = fmul fast float %12, %1514
  %1516 = fsub fast float -0.000000e+00, %1515
  %1517 = call float @dx.op.binary.f32(i32 35, float %1516, float -4.000000e+01)  ; FMax(a,b)
  %1518 = call float @dx.op.binary.f32(i32 36, float %1517, float 5.000000e+00)  ; FMin(a,b)
  %1519 = fmul fast float %1518, 0x3FF7154760000000
  %1520 = call float @dx.op.unary.f32(i32 21, float %1519)  ; Exp(value)
  %1521 = fmul fast float %1520, %1512
  br label %1522

; <label>:1522                                    ; preds = %1511, %1471
  %1523 = phi float [ %1521, %1511 ], [ 1.000000e+00, %1471 ]
  %1524 = fmul fast float %1497, %17
  %1525 = fmul fast float %1524, %1523
  %1526 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1525)  ; FMin(a,b)
  %1527 = fmul fast float %1526, 0xBFF7154760000000
  %1528 = call float @dx.op.unary.f32(i32 21, float %1527)  ; Exp(value)
  %1529 = fsub fast float 1.000000e+00, %1528
  %1530 = call float @dx.op.binary.f32(i32 36, float %13, float %1529)  ; FMin(a,b)
  %1531 = fsub fast float %14, %1409
  %1532 = fsub fast float %15, %1410
  %1533 = fsub fast float %16, %1411
  %1534 = fmul fast float %1530, %1531
  %1535 = fmul fast float %1530, %1532
  %1536 = fmul fast float %1530, %1533
  %1537 = fadd fast float %1534, %1409
  %1538 = fadd fast float %1535, %1410
  %1539 = fadd fast float %1536, %1411
  br label %1540

; <label>:1540                                    ; preds = %1522, %1454, %1448
  %1541 = phi float [ %1537, %1522 ], [ %1409, %1454 ], [ %1409, %1448 ]
  %1542 = phi float [ %1538, %1522 ], [ %1410, %1454 ], [ %1410, %1448 ]
  %1543 = phi float [ %1539, %1522 ], [ %1411, %1454 ], [ %1411, %1448 ]
  %1544 = fadd fast float %6, 1.000000e+00
  %1545 = fadd fast float %7, 1.000000e+00
  %1546 = fsub fast float 1.000000e+00, %6
  %1547 = fmul fast float %37, %1544
  %1548 = fmul fast float %37, %1545
  %1549 = fmul fast float %37, %1546
  %1550 = fmul fast float %1547, %1541
  %1551 = fmul fast float %1548, %1542
  %1552 = fmul fast float %1549, %1543
  %1553 = fcmp fast ult float %38, 5.000000e-01
  br i1 %1553, label %1579, label %1554

; <label>:1554                                    ; preds = %1540
  %1555 = fmul fast float %1550, 0x4004147AE0000000
  %1556 = fmul fast float %1551, 0x4004147AE0000000
  %1557 = fmul fast float %1552, 0x4004147AE0000000
  %1558 = fadd fast float %1555, 0x3F9EB851E0000000
  %1559 = fadd fast float %1556, 0x3F9EB851E0000000
  %1560 = fadd fast float %1557, 0x3F9EB851E0000000
  %1561 = fmul fast float %1558, %1550
  %1562 = fmul fast float %1559, %1551
  %1563 = fmul fast float %1560, %1552
  %1564 = fmul fast float %1550, 0x400370A3E0000000
  %1565 = fmul fast float %1551, 0x400370A3E0000000
  %1566 = fmul fast float %1552, 0x400370A3E0000000
  %1567 = fadd fast float %1564, 0x3FE2E147A0000000
  %1568 = fadd fast float %1565, 0x3FE2E147A0000000
  %1569 = fadd fast float %1566, 0x3FE2E147A0000000
  %1570 = fmul fast float %1567, %1550
  %1571 = fmul fast float %1568, %1551
  %1572 = fmul fast float %1569, %1552
  %1573 = fadd fast float %1570, 0x3FC1EB8520000000
  %1574 = fadd fast float %1571, 0x3FC1EB8520000000
  %1575 = fadd fast float %1572, 0x3FC1EB8520000000
  %1576 = fdiv fast float %1561, %1573
  %1577 = fdiv fast float %1562, %1574
  %1578 = fdiv fast float %1563, %1575
  br label %1579

; <label>:1579                                    ; preds = %1554, %1540
  %1580 = phi float [ %1576, %1554 ], [ %1550, %1540 ]
  %1581 = phi float [ %1577, %1554 ], [ %1551, %1540 ]
  %1582 = phi float [ %1578, %1554 ], [ %1552, %1540 ]
  %1583 = call float @dx.op.unary.f32(i32 7, float %1580)  ; Saturate(value)
  %1584 = call float @dx.op.unary.f32(i32 7, float %1581)  ; Saturate(value)
  %1585 = call float @dx.op.unary.f32(i32 7, float %1582)  ; Saturate(value)
  %1586 = call float @dx.op.dot3.f32(i32 55, float %1583, float %1584, float %1585, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1587 = fsub fast float %1583, %1586
  %1588 = fsub fast float %1584, %1586
  %1589 = fsub fast float %1585, %1586
  %1590 = fmul fast float %1587, %9
  %1591 = fmul fast float %1588, %9
  %1592 = fmul fast float %1589, %9
  %1593 = fadd fast float %1590, %1586
  %1594 = fadd fast float %1591, %1586
  %1595 = fadd fast float %1592, %1586
  %1596 = call float @dx.op.unary.f32(i32 7, float %1593)  ; Saturate(value)
  %1597 = call float @dx.op.unary.f32(i32 7, float %1594)  ; Saturate(value)
  %1598 = call float @dx.op.unary.f32(i32 7, float %1595)  ; Saturate(value)
  %1599 = fadd fast float %1596, 0xBFC70A3D80000000
  %1600 = fadd fast float %1597, 0xBFC70A3D80000000
  %1601 = fadd fast float %1598, 0xBFC70A3D80000000
  %1602 = fmul fast float %1599, %8
  %1603 = fmul fast float %1600, %8
  %1604 = fmul fast float %1601, %8
  %1605 = fadd fast float %1602, 0x3FC70A3D80000000
  %1606 = fadd fast float %1603, 0x3FC70A3D80000000
  %1607 = fadd fast float %1604, 0x3FC70A3D80000000
  %1608 = call float @dx.op.unary.f32(i32 7, float %1605)  ; Saturate(value)
  %1609 = call float @dx.op.unary.f32(i32 7, float %1606)  ; Saturate(value)
  %1610 = call float @dx.op.unary.f32(i32 7, float %1607)  ; Saturate(value)
  br label %1611

; <label>:1611                                    ; preds = %1579, %1414
  %1612 = phi float [ %1445, %1414 ], [ %1608, %1579 ]
  %1613 = phi float [ %1446, %1414 ], [ %1609, %1579 ]
  %1614 = phi float [ %1447, %1414 ], [ %1610, %1579 ]
  %1615 = add i32 %65, 1
  %1616 = call i32 @dx.op.binary.i32(i32 37, i32 %1615, i32 0)  ; IMax(a,b)
  %1617 = call i32 @dx.op.binary.i32(i32 38, i32 %1616, i32 %61)  ; IMin(a,b)
  %1618 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1406, i32 %1617, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1619 = extractvalue %dx.types.ResRet.f32 %1618, 0
  %1620 = extractvalue %dx.types.ResRet.f32 %1618, 1
  %1621 = extractvalue %dx.types.ResRet.f32 %1618, 2
  %1622 = extractvalue %dx.types.ResRet.f32 %1618, 3
  %1623 = fcmp fast olt float %1622, 0.000000e+00
  br i1 %1623, label %1624, label %1658

; <label>:1624                                    ; preds = %1611
  %1625 = fcmp fast ogt float %1619, 0x3FA4B5DCC0000000
  %1626 = fcmp fast ogt float %1620, 0x3FA4B5DCC0000000
  %1627 = fcmp fast ogt float %1621, 0x3FA4B5DCC0000000
  %1628 = select i1 %1625, float 0.000000e+00, float 1.000000e+00
  %1629 = select i1 %1626, float 0.000000e+00, float 1.000000e+00
  %1630 = select i1 %1627, float 0.000000e+00, float 1.000000e+00
  %1631 = fmul fast float %1619, 0x3FB3D07220000000
  %1632 = fmul fast float %1620, 0x3FB3D07220000000
  %1633 = fmul fast float %1621, 0x3FB3D07220000000
  %1634 = fadd fast float %1619, 0x3FAC28F5C0000000
  %1635 = fadd fast float %1620, 0x3FAC28F5C0000000
  %1636 = fadd fast float %1621, 0x3FAC28F5C0000000
  %1637 = fmul fast float %1634, 0x3FEE54EDE0000000
  %1638 = fmul fast float %1635, 0x3FEE54EDE0000000
  %1639 = fmul fast float %1636, 0x3FEE54EDE0000000
  %1640 = call float @dx.op.unary.f32(i32 23, float %1637)  ; Log(value)
  %1641 = call float @dx.op.unary.f32(i32 23, float %1638)  ; Log(value)
  %1642 = call float @dx.op.unary.f32(i32 23, float %1639)  ; Log(value)
  %1643 = fmul fast float %1640, 0x4003333340000000
  %1644 = fmul fast float %1641, 0x4003333340000000
  %1645 = fmul fast float %1642, 0x4003333340000000
  %1646 = call float @dx.op.unary.f32(i32 21, float %1643)  ; Exp(value)
  %1647 = call float @dx.op.unary.f32(i32 21, float %1644)  ; Exp(value)
  %1648 = call float @dx.op.unary.f32(i32 21, float %1645)  ; Exp(value)
  %1649 = fsub fast float %1631, %1646
  %1650 = fsub fast float %1632, %1647
  %1651 = fsub fast float %1633, %1648
  %1652 = fmul fast float %1649, %1628
  %1653 = fmul fast float %1650, %1629
  %1654 = fmul fast float %1651, %1630
  %1655 = fadd fast float %1652, %1646
  %1656 = fadd fast float %1653, %1647
  %1657 = fadd fast float %1654, %1648
  br label %1821

; <label>:1658                                    ; preds = %1611
  %1659 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1406, i32 %1617, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1660 = extractvalue %dx.types.ResRet.f32 %1659, 0
  %1661 = fcmp fast ogt float %39, 5.000000e-01
  %1662 = fcmp fast olt float %1660, 1.000000e+00
  %1663 = and i1 %1661, %1662
  br i1 %1663, label %1664, label %1750

; <label>:1664                                    ; preds = %1658
  %1665 = sitofp i32 %1406 to float
  %1666 = sitofp i32 %1617 to float
  %1667 = fadd fast float %1665, 5.000000e-01
  %1668 = fadd fast float %1666, 5.000000e-01
  %1669 = fdiv fast float %1667, %46
  %1670 = fdiv fast float %1668, %47
  %1671 = fmul fast float %1669, 2.000000e+00
  %1672 = fmul fast float %1670, 2.000000e+00
  %1673 = fadd fast float %1671, -1.000000e+00
  %1674 = fsub fast float 1.000000e+00, %1672
  %1675 = fmul fast float %1673, %36
  %1676 = call float @dx.op.tertiary.f32(i32 46, float %1674, float %32, float %1675)  ; FMad(a,b,c)
  %1677 = call float @dx.op.tertiary.f32(i32 46, float %1660, float %28, float %1676)  ; FMad(a,b,c)
  %1678 = fadd fast float %1677, %24
  %1679 = call float @dx.op.unary.f32(i32 6, float %1678)  ; FAbs(value)
  %1680 = fcmp fast ogt float %1679, 0x3EB0C6F7A0000000
  br i1 %1680, label %1681, label %1750

; <label>:1681                                    ; preds = %1664
  %1682 = fmul fast float %1673, %35
  %1683 = call float @dx.op.tertiary.f32(i32 46, float %1674, float %31, float %1682)  ; FMad(a,b,c)
  %1684 = call float @dx.op.tertiary.f32(i32 46, float %1660, float %27, float %1683)  ; FMad(a,b,c)
  %1685 = fadd fast float %1684, %23
  %1686 = fmul fast float %1673, %34
  %1687 = call float @dx.op.tertiary.f32(i32 46, float %1674, float %30, float %1686)  ; FMad(a,b,c)
  %1688 = call float @dx.op.tertiary.f32(i32 46, float %1660, float %26, float %1687)  ; FMad(a,b,c)
  %1689 = fadd fast float %1688, %22
  %1690 = fmul fast float %1673, %33
  %1691 = call float @dx.op.tertiary.f32(i32 46, float %1674, float %29, float %1690)  ; FMad(a,b,c)
  %1692 = call float @dx.op.tertiary.f32(i32 46, float %1660, float %25, float %1691)  ; FMad(a,b,c)
  %1693 = fadd fast float %1692, %21
  %1694 = fdiv fast float %1693, %1678
  %1695 = fdiv fast float %1689, %1678
  %1696 = fdiv fast float %1685, %1678
  %1697 = fsub fast float %1694, %18
  %1698 = fsub fast float %1695, %19
  %1699 = fsub fast float %1696, %20
  %1700 = fmul fast float %1697, %1697
  %1701 = fmul fast float %1698, %1698
  %1702 = fadd fast float %1701, %1700
  %1703 = fmul fast float %1699, %1699
  %1704 = fadd fast float %1702, %1703
  %1705 = call float @dx.op.unary.f32(i32 24, float %1704)  ; Sqrt(value)
  %1706 = fsub fast float %1705, %10
  %1707 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1706)  ; FMax(a,b)
  %1708 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %1708, label %1709, label %1732

; <label>:1709                                    ; preds = %1681
  %1710 = call float @dx.op.unary.f32(i32 6, float %1698)  ; FAbs(value)
  %1711 = fmul fast float %1710, %12
  %1712 = fcmp fast olt float %1711, 0x3F50624DE0000000
  br i1 %1712, label %1713, label %1716

; <label>:1713                                    ; preds = %1709
  %1714 = fmul fast float %1711, 5.000000e-01
  %1715 = fsub fast float 1.000000e+00, %1714
  br label %1721

; <label>:1716                                    ; preds = %1709
  %1717 = fmul fast float %1711, 0xBFF7154760000000
  %1718 = call float @dx.op.unary.f32(i32 21, float %1717)  ; Exp(value)
  %1719 = fsub fast float 1.000000e+00, %1718
  %1720 = fdiv fast float %1719, %1711
  br label %1721

; <label>:1721                                    ; preds = %1716, %1713
  %1722 = phi float [ %1715, %1713 ], [ %1720, %1716 ]
  %1723 = call float @dx.op.binary.f32(i32 36, float %1695, float %19)  ; FMin(a,b)
  %1724 = fsub fast float %1723, %11
  %1725 = fmul fast float %12, %1724
  %1726 = fsub fast float -0.000000e+00, %1725
  %1727 = call float @dx.op.binary.f32(i32 35, float %1726, float -4.000000e+01)  ; FMax(a,b)
  %1728 = call float @dx.op.binary.f32(i32 36, float %1727, float 5.000000e+00)  ; FMin(a,b)
  %1729 = fmul fast float %1728, 0x3FF7154760000000
  %1730 = call float @dx.op.unary.f32(i32 21, float %1729)  ; Exp(value)
  %1731 = fmul fast float %1730, %1722
  br label %1732

; <label>:1732                                    ; preds = %1721, %1681
  %1733 = phi float [ %1731, %1721 ], [ 1.000000e+00, %1681 ]
  %1734 = fmul fast float %1707, %17
  %1735 = fmul fast float %1734, %1733
  %1736 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1735)  ; FMin(a,b)
  %1737 = fmul fast float %1736, 0xBFF7154760000000
  %1738 = call float @dx.op.unary.f32(i32 21, float %1737)  ; Exp(value)
  %1739 = fsub fast float 1.000000e+00, %1738
  %1740 = call float @dx.op.binary.f32(i32 36, float %13, float %1739)  ; FMin(a,b)
  %1741 = fsub fast float %14, %1619
  %1742 = fsub fast float %15, %1620
  %1743 = fsub fast float %16, %1621
  %1744 = fmul fast float %1740, %1741
  %1745 = fmul fast float %1740, %1742
  %1746 = fmul fast float %1740, %1743
  %1747 = fadd fast float %1744, %1619
  %1748 = fadd fast float %1745, %1620
  %1749 = fadd fast float %1746, %1621
  br label %1750

; <label>:1750                                    ; preds = %1732, %1664, %1658
  %1751 = phi float [ %1747, %1732 ], [ %1619, %1664 ], [ %1619, %1658 ]
  %1752 = phi float [ %1748, %1732 ], [ %1620, %1664 ], [ %1620, %1658 ]
  %1753 = phi float [ %1749, %1732 ], [ %1621, %1664 ], [ %1621, %1658 ]
  %1754 = fadd fast float %6, 1.000000e+00
  %1755 = fadd fast float %7, 1.000000e+00
  %1756 = fsub fast float 1.000000e+00, %6
  %1757 = fmul fast float %37, %1754
  %1758 = fmul fast float %37, %1755
  %1759 = fmul fast float %37, %1756
  %1760 = fmul fast float %1757, %1751
  %1761 = fmul fast float %1758, %1752
  %1762 = fmul fast float %1759, %1753
  %1763 = fcmp fast ult float %38, 5.000000e-01
  br i1 %1763, label %1789, label %1764

; <label>:1764                                    ; preds = %1750
  %1765 = fmul fast float %1760, 0x4004147AE0000000
  %1766 = fmul fast float %1761, 0x4004147AE0000000
  %1767 = fmul fast float %1762, 0x4004147AE0000000
  %1768 = fadd fast float %1765, 0x3F9EB851E0000000
  %1769 = fadd fast float %1766, 0x3F9EB851E0000000
  %1770 = fadd fast float %1767, 0x3F9EB851E0000000
  %1771 = fmul fast float %1768, %1760
  %1772 = fmul fast float %1769, %1761
  %1773 = fmul fast float %1770, %1762
  %1774 = fmul fast float %1760, 0x400370A3E0000000
  %1775 = fmul fast float %1761, 0x400370A3E0000000
  %1776 = fmul fast float %1762, 0x400370A3E0000000
  %1777 = fadd fast float %1774, 0x3FE2E147A0000000
  %1778 = fadd fast float %1775, 0x3FE2E147A0000000
  %1779 = fadd fast float %1776, 0x3FE2E147A0000000
  %1780 = fmul fast float %1777, %1760
  %1781 = fmul fast float %1778, %1761
  %1782 = fmul fast float %1779, %1762
  %1783 = fadd fast float %1780, 0x3FC1EB8520000000
  %1784 = fadd fast float %1781, 0x3FC1EB8520000000
  %1785 = fadd fast float %1782, 0x3FC1EB8520000000
  %1786 = fdiv fast float %1771, %1783
  %1787 = fdiv fast float %1772, %1784
  %1788 = fdiv fast float %1773, %1785
  br label %1789

; <label>:1789                                    ; preds = %1764, %1750
  %1790 = phi float [ %1786, %1764 ], [ %1760, %1750 ]
  %1791 = phi float [ %1787, %1764 ], [ %1761, %1750 ]
  %1792 = phi float [ %1788, %1764 ], [ %1762, %1750 ]
  %1793 = call float @dx.op.unary.f32(i32 7, float %1790)  ; Saturate(value)
  %1794 = call float @dx.op.unary.f32(i32 7, float %1791)  ; Saturate(value)
  %1795 = call float @dx.op.unary.f32(i32 7, float %1792)  ; Saturate(value)
  %1796 = call float @dx.op.dot3.f32(i32 55, float %1793, float %1794, float %1795, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1797 = fsub fast float %1793, %1796
  %1798 = fsub fast float %1794, %1796
  %1799 = fsub fast float %1795, %1796
  %1800 = fmul fast float %1797, %9
  %1801 = fmul fast float %1798, %9
  %1802 = fmul fast float %1799, %9
  %1803 = fadd fast float %1800, %1796
  %1804 = fadd fast float %1801, %1796
  %1805 = fadd fast float %1802, %1796
  %1806 = call float @dx.op.unary.f32(i32 7, float %1803)  ; Saturate(value)
  %1807 = call float @dx.op.unary.f32(i32 7, float %1804)  ; Saturate(value)
  %1808 = call float @dx.op.unary.f32(i32 7, float %1805)  ; Saturate(value)
  %1809 = fadd fast float %1806, 0xBFC70A3D80000000
  %1810 = fadd fast float %1807, 0xBFC70A3D80000000
  %1811 = fadd fast float %1808, 0xBFC70A3D80000000
  %1812 = fmul fast float %1809, %8
  %1813 = fmul fast float %1810, %8
  %1814 = fmul fast float %1811, %8
  %1815 = fadd fast float %1812, 0x3FC70A3D80000000
  %1816 = fadd fast float %1813, 0x3FC70A3D80000000
  %1817 = fadd fast float %1814, 0x3FC70A3D80000000
  %1818 = call float @dx.op.unary.f32(i32 7, float %1815)  ; Saturate(value)
  %1819 = call float @dx.op.unary.f32(i32 7, float %1816)  ; Saturate(value)
  %1820 = call float @dx.op.unary.f32(i32 7, float %1817)  ; Saturate(value)
  br label %1821

; <label>:1821                                    ; preds = %1789, %1624
  %1822 = phi float [ %1655, %1624 ], [ %1818, %1789 ]
  %1823 = phi float [ %1656, %1624 ], [ %1819, %1789 ]
  %1824 = phi float [ %1657, %1624 ], [ %1820, %1789 ]
  %1825 = add i32 %1229, -1
  %1826 = call i32 @dx.op.binary.i32(i32 37, i32 %1825, i32 0)  ; IMax(a,b)
  %1827 = call i32 @dx.op.binary.i32(i32 37, i32 %65, i32 0)  ; IMax(a,b)
  %1828 = call i32 @dx.op.binary.i32(i32 38, i32 %1826, i32 %60)  ; IMin(a,b)
  %1829 = call i32 @dx.op.binary.i32(i32 38, i32 %1827, i32 %61)  ; IMin(a,b)
  %1830 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1828, i32 %1829, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1831 = extractvalue %dx.types.ResRet.f32 %1830, 0
  %1832 = extractvalue %dx.types.ResRet.f32 %1830, 1
  %1833 = extractvalue %dx.types.ResRet.f32 %1830, 2
  %1834 = extractvalue %dx.types.ResRet.f32 %1830, 3
  %1835 = fcmp fast olt float %1834, 0.000000e+00
  br i1 %1835, label %1836, label %1870

; <label>:1836                                    ; preds = %1821
  %1837 = fcmp fast ogt float %1831, 0x3FA4B5DCC0000000
  %1838 = fcmp fast ogt float %1832, 0x3FA4B5DCC0000000
  %1839 = fcmp fast ogt float %1833, 0x3FA4B5DCC0000000
  %1840 = select i1 %1837, float 0.000000e+00, float 1.000000e+00
  %1841 = select i1 %1838, float 0.000000e+00, float 1.000000e+00
  %1842 = select i1 %1839, float 0.000000e+00, float 1.000000e+00
  %1843 = fmul fast float %1831, 0x3FB3D07220000000
  %1844 = fmul fast float %1832, 0x3FB3D07220000000
  %1845 = fmul fast float %1833, 0x3FB3D07220000000
  %1846 = fadd fast float %1831, 0x3FAC28F5C0000000
  %1847 = fadd fast float %1832, 0x3FAC28F5C0000000
  %1848 = fadd fast float %1833, 0x3FAC28F5C0000000
  %1849 = fmul fast float %1846, 0x3FEE54EDE0000000
  %1850 = fmul fast float %1847, 0x3FEE54EDE0000000
  %1851 = fmul fast float %1848, 0x3FEE54EDE0000000
  %1852 = call float @dx.op.unary.f32(i32 23, float %1849)  ; Log(value)
  %1853 = call float @dx.op.unary.f32(i32 23, float %1850)  ; Log(value)
  %1854 = call float @dx.op.unary.f32(i32 23, float %1851)  ; Log(value)
  %1855 = fmul fast float %1852, 0x4003333340000000
  %1856 = fmul fast float %1853, 0x4003333340000000
  %1857 = fmul fast float %1854, 0x4003333340000000
  %1858 = call float @dx.op.unary.f32(i32 21, float %1855)  ; Exp(value)
  %1859 = call float @dx.op.unary.f32(i32 21, float %1856)  ; Exp(value)
  %1860 = call float @dx.op.unary.f32(i32 21, float %1857)  ; Exp(value)
  %1861 = fsub fast float %1843, %1858
  %1862 = fsub fast float %1844, %1859
  %1863 = fsub fast float %1845, %1860
  %1864 = fmul fast float %1861, %1840
  %1865 = fmul fast float %1862, %1841
  %1866 = fmul fast float %1863, %1842
  %1867 = fadd fast float %1864, %1858
  %1868 = fadd fast float %1865, %1859
  %1869 = fadd fast float %1866, %1860
  br label %2033

; <label>:1870                                    ; preds = %1821
  %1871 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1828, i32 %1829, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1872 = extractvalue %dx.types.ResRet.f32 %1871, 0
  %1873 = fcmp fast ogt float %39, 5.000000e-01
  %1874 = fcmp fast olt float %1872, 1.000000e+00
  %1875 = and i1 %1873, %1874
  br i1 %1875, label %1876, label %1962

; <label>:1876                                    ; preds = %1870
  %1877 = sitofp i32 %1828 to float
  %1878 = sitofp i32 %1829 to float
  %1879 = fadd fast float %1877, 5.000000e-01
  %1880 = fadd fast float %1878, 5.000000e-01
  %1881 = fdiv fast float %1879, %46
  %1882 = fdiv fast float %1880, %47
  %1883 = fmul fast float %1881, 2.000000e+00
  %1884 = fmul fast float %1882, 2.000000e+00
  %1885 = fadd fast float %1883, -1.000000e+00
  %1886 = fsub fast float 1.000000e+00, %1884
  %1887 = fmul fast float %1885, %36
  %1888 = call float @dx.op.tertiary.f32(i32 46, float %1886, float %32, float %1887)  ; FMad(a,b,c)
  %1889 = call float @dx.op.tertiary.f32(i32 46, float %1872, float %28, float %1888)  ; FMad(a,b,c)
  %1890 = fadd fast float %1889, %24
  %1891 = call float @dx.op.unary.f32(i32 6, float %1890)  ; FAbs(value)
  %1892 = fcmp fast ogt float %1891, 0x3EB0C6F7A0000000
  br i1 %1892, label %1893, label %1962

; <label>:1893                                    ; preds = %1876
  %1894 = fmul fast float %1885, %35
  %1895 = call float @dx.op.tertiary.f32(i32 46, float %1886, float %31, float %1894)  ; FMad(a,b,c)
  %1896 = call float @dx.op.tertiary.f32(i32 46, float %1872, float %27, float %1895)  ; FMad(a,b,c)
  %1897 = fadd fast float %1896, %23
  %1898 = fmul fast float %1885, %34
  %1899 = call float @dx.op.tertiary.f32(i32 46, float %1886, float %30, float %1898)  ; FMad(a,b,c)
  %1900 = call float @dx.op.tertiary.f32(i32 46, float %1872, float %26, float %1899)  ; FMad(a,b,c)
  %1901 = fadd fast float %1900, %22
  %1902 = fmul fast float %1885, %33
  %1903 = call float @dx.op.tertiary.f32(i32 46, float %1886, float %29, float %1902)  ; FMad(a,b,c)
  %1904 = call float @dx.op.tertiary.f32(i32 46, float %1872, float %25, float %1903)  ; FMad(a,b,c)
  %1905 = fadd fast float %1904, %21
  %1906 = fdiv fast float %1905, %1890
  %1907 = fdiv fast float %1901, %1890
  %1908 = fdiv fast float %1897, %1890
  %1909 = fsub fast float %1906, %18
  %1910 = fsub fast float %1907, %19
  %1911 = fsub fast float %1908, %20
  %1912 = fmul fast float %1909, %1909
  %1913 = fmul fast float %1910, %1910
  %1914 = fadd fast float %1913, %1912
  %1915 = fmul fast float %1911, %1911
  %1916 = fadd fast float %1914, %1915
  %1917 = call float @dx.op.unary.f32(i32 24, float %1916)  ; Sqrt(value)
  %1918 = fsub fast float %1917, %10
  %1919 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1918)  ; FMax(a,b)
  %1920 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %1920, label %1921, label %1944

; <label>:1921                                    ; preds = %1893
  %1922 = call float @dx.op.unary.f32(i32 6, float %1910)  ; FAbs(value)
  %1923 = fmul fast float %1922, %12
  %1924 = fcmp fast olt float %1923, 0x3F50624DE0000000
  br i1 %1924, label %1925, label %1928

; <label>:1925                                    ; preds = %1921
  %1926 = fmul fast float %1923, 5.000000e-01
  %1927 = fsub fast float 1.000000e+00, %1926
  br label %1933

; <label>:1928                                    ; preds = %1921
  %1929 = fmul fast float %1923, 0xBFF7154760000000
  %1930 = call float @dx.op.unary.f32(i32 21, float %1929)  ; Exp(value)
  %1931 = fsub fast float 1.000000e+00, %1930
  %1932 = fdiv fast float %1931, %1923
  br label %1933

; <label>:1933                                    ; preds = %1928, %1925
  %1934 = phi float [ %1927, %1925 ], [ %1932, %1928 ]
  %1935 = call float @dx.op.binary.f32(i32 36, float %1907, float %19)  ; FMin(a,b)
  %1936 = fsub fast float %1935, %11
  %1937 = fmul fast float %12, %1936
  %1938 = fsub fast float -0.000000e+00, %1937
  %1939 = call float @dx.op.binary.f32(i32 35, float %1938, float -4.000000e+01)  ; FMax(a,b)
  %1940 = call float @dx.op.binary.f32(i32 36, float %1939, float 5.000000e+00)  ; FMin(a,b)
  %1941 = fmul fast float %1940, 0x3FF7154760000000
  %1942 = call float @dx.op.unary.f32(i32 21, float %1941)  ; Exp(value)
  %1943 = fmul fast float %1942, %1934
  br label %1944

; <label>:1944                                    ; preds = %1933, %1893
  %1945 = phi float [ %1943, %1933 ], [ 1.000000e+00, %1893 ]
  %1946 = fmul fast float %1919, %17
  %1947 = fmul fast float %1946, %1945
  %1948 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1947)  ; FMin(a,b)
  %1949 = fmul fast float %1948, 0xBFF7154760000000
  %1950 = call float @dx.op.unary.f32(i32 21, float %1949)  ; Exp(value)
  %1951 = fsub fast float 1.000000e+00, %1950
  %1952 = call float @dx.op.binary.f32(i32 36, float %13, float %1951)  ; FMin(a,b)
  %1953 = fsub fast float %14, %1831
  %1954 = fsub fast float %15, %1832
  %1955 = fsub fast float %16, %1833
  %1956 = fmul fast float %1952, %1953
  %1957 = fmul fast float %1952, %1954
  %1958 = fmul fast float %1952, %1955
  %1959 = fadd fast float %1956, %1831
  %1960 = fadd fast float %1957, %1832
  %1961 = fadd fast float %1958, %1833
  br label %1962

; <label>:1962                                    ; preds = %1944, %1876, %1870
  %1963 = phi float [ %1959, %1944 ], [ %1831, %1876 ], [ %1831, %1870 ]
  %1964 = phi float [ %1960, %1944 ], [ %1832, %1876 ], [ %1832, %1870 ]
  %1965 = phi float [ %1961, %1944 ], [ %1833, %1876 ], [ %1833, %1870 ]
  %1966 = fadd fast float %6, 1.000000e+00
  %1967 = fadd fast float %7, 1.000000e+00
  %1968 = fsub fast float 1.000000e+00, %6
  %1969 = fmul fast float %37, %1966
  %1970 = fmul fast float %37, %1967
  %1971 = fmul fast float %37, %1968
  %1972 = fmul fast float %1969, %1963
  %1973 = fmul fast float %1970, %1964
  %1974 = fmul fast float %1971, %1965
  %1975 = fcmp fast ult float %38, 5.000000e-01
  br i1 %1975, label %2001, label %1976

; <label>:1976                                    ; preds = %1962
  %1977 = fmul fast float %1972, 0x4004147AE0000000
  %1978 = fmul fast float %1973, 0x4004147AE0000000
  %1979 = fmul fast float %1974, 0x4004147AE0000000
  %1980 = fadd fast float %1977, 0x3F9EB851E0000000
  %1981 = fadd fast float %1978, 0x3F9EB851E0000000
  %1982 = fadd fast float %1979, 0x3F9EB851E0000000
  %1983 = fmul fast float %1980, %1972
  %1984 = fmul fast float %1981, %1973
  %1985 = fmul fast float %1982, %1974
  %1986 = fmul fast float %1972, 0x400370A3E0000000
  %1987 = fmul fast float %1973, 0x400370A3E0000000
  %1988 = fmul fast float %1974, 0x400370A3E0000000
  %1989 = fadd fast float %1986, 0x3FE2E147A0000000
  %1990 = fadd fast float %1987, 0x3FE2E147A0000000
  %1991 = fadd fast float %1988, 0x3FE2E147A0000000
  %1992 = fmul fast float %1989, %1972
  %1993 = fmul fast float %1990, %1973
  %1994 = fmul fast float %1991, %1974
  %1995 = fadd fast float %1992, 0x3FC1EB8520000000
  %1996 = fadd fast float %1993, 0x3FC1EB8520000000
  %1997 = fadd fast float %1994, 0x3FC1EB8520000000
  %1998 = fdiv fast float %1983, %1995
  %1999 = fdiv fast float %1984, %1996
  %2000 = fdiv fast float %1985, %1997
  br label %2001

; <label>:2001                                    ; preds = %1976, %1962
  %2002 = phi float [ %1998, %1976 ], [ %1972, %1962 ]
  %2003 = phi float [ %1999, %1976 ], [ %1973, %1962 ]
  %2004 = phi float [ %2000, %1976 ], [ %1974, %1962 ]
  %2005 = call float @dx.op.unary.f32(i32 7, float %2002)  ; Saturate(value)
  %2006 = call float @dx.op.unary.f32(i32 7, float %2003)  ; Saturate(value)
  %2007 = call float @dx.op.unary.f32(i32 7, float %2004)  ; Saturate(value)
  %2008 = call float @dx.op.dot3.f32(i32 55, float %2005, float %2006, float %2007, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2009 = fsub fast float %2005, %2008
  %2010 = fsub fast float %2006, %2008
  %2011 = fsub fast float %2007, %2008
  %2012 = fmul fast float %2009, %9
  %2013 = fmul fast float %2010, %9
  %2014 = fmul fast float %2011, %9
  %2015 = fadd fast float %2012, %2008
  %2016 = fadd fast float %2013, %2008
  %2017 = fadd fast float %2014, %2008
  %2018 = call float @dx.op.unary.f32(i32 7, float %2015)  ; Saturate(value)
  %2019 = call float @dx.op.unary.f32(i32 7, float %2016)  ; Saturate(value)
  %2020 = call float @dx.op.unary.f32(i32 7, float %2017)  ; Saturate(value)
  %2021 = fadd fast float %2018, 0xBFC70A3D80000000
  %2022 = fadd fast float %2019, 0xBFC70A3D80000000
  %2023 = fadd fast float %2020, 0xBFC70A3D80000000
  %2024 = fmul fast float %2021, %8
  %2025 = fmul fast float %2022, %8
  %2026 = fmul fast float %2023, %8
  %2027 = fadd fast float %2024, 0x3FC70A3D80000000
  %2028 = fadd fast float %2025, 0x3FC70A3D80000000
  %2029 = fadd fast float %2026, 0x3FC70A3D80000000
  %2030 = call float @dx.op.unary.f32(i32 7, float %2027)  ; Saturate(value)
  %2031 = call float @dx.op.unary.f32(i32 7, float %2028)  ; Saturate(value)
  %2032 = call float @dx.op.unary.f32(i32 7, float %2029)  ; Saturate(value)
  br label %2033

; <label>:2033                                    ; preds = %2001, %1836
  %2034 = phi float [ %1867, %1836 ], [ %2030, %2001 ]
  %2035 = phi float [ %1868, %1836 ], [ %2031, %2001 ]
  %2036 = phi float [ %1869, %1836 ], [ %2032, %2001 ]
  %2037 = add i32 %1229, 1
  %2038 = call i32 @dx.op.binary.i32(i32 37, i32 %2037, i32 0)  ; IMax(a,b)
  %2039 = call i32 @dx.op.binary.i32(i32 38, i32 %2038, i32 %60)  ; IMin(a,b)
  %2040 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2039, i32 %1829, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2041 = extractvalue %dx.types.ResRet.f32 %2040, 0
  %2042 = extractvalue %dx.types.ResRet.f32 %2040, 1
  %2043 = extractvalue %dx.types.ResRet.f32 %2040, 2
  %2044 = extractvalue %dx.types.ResRet.f32 %2040, 3
  %2045 = fcmp fast olt float %2044, 0.000000e+00
  br i1 %2045, label %2046, label %2080

; <label>:2046                                    ; preds = %2033
  %2047 = fcmp fast ogt float %2041, 0x3FA4B5DCC0000000
  %2048 = fcmp fast ogt float %2042, 0x3FA4B5DCC0000000
  %2049 = fcmp fast ogt float %2043, 0x3FA4B5DCC0000000
  %2050 = select i1 %2047, float 0.000000e+00, float 1.000000e+00
  %2051 = select i1 %2048, float 0.000000e+00, float 1.000000e+00
  %2052 = select i1 %2049, float 0.000000e+00, float 1.000000e+00
  %2053 = fmul fast float %2041, 0x3FB3D07220000000
  %2054 = fmul fast float %2042, 0x3FB3D07220000000
  %2055 = fmul fast float %2043, 0x3FB3D07220000000
  %2056 = fadd fast float %2041, 0x3FAC28F5C0000000
  %2057 = fadd fast float %2042, 0x3FAC28F5C0000000
  %2058 = fadd fast float %2043, 0x3FAC28F5C0000000
  %2059 = fmul fast float %2056, 0x3FEE54EDE0000000
  %2060 = fmul fast float %2057, 0x3FEE54EDE0000000
  %2061 = fmul fast float %2058, 0x3FEE54EDE0000000
  %2062 = call float @dx.op.unary.f32(i32 23, float %2059)  ; Log(value)
  %2063 = call float @dx.op.unary.f32(i32 23, float %2060)  ; Log(value)
  %2064 = call float @dx.op.unary.f32(i32 23, float %2061)  ; Log(value)
  %2065 = fmul fast float %2062, 0x4003333340000000
  %2066 = fmul fast float %2063, 0x4003333340000000
  %2067 = fmul fast float %2064, 0x4003333340000000
  %2068 = call float @dx.op.unary.f32(i32 21, float %2065)  ; Exp(value)
  %2069 = call float @dx.op.unary.f32(i32 21, float %2066)  ; Exp(value)
  %2070 = call float @dx.op.unary.f32(i32 21, float %2067)  ; Exp(value)
  %2071 = fsub fast float %2053, %2068
  %2072 = fsub fast float %2054, %2069
  %2073 = fsub fast float %2055, %2070
  %2074 = fmul fast float %2071, %2050
  %2075 = fmul fast float %2072, %2051
  %2076 = fmul fast float %2073, %2052
  %2077 = fadd fast float %2074, %2068
  %2078 = fadd fast float %2075, %2069
  %2079 = fadd fast float %2076, %2070
  br label %2243

; <label>:2080                                    ; preds = %2033
  %2081 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2039, i32 %1829, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2082 = extractvalue %dx.types.ResRet.f32 %2081, 0
  %2083 = fcmp fast ogt float %39, 5.000000e-01
  %2084 = fcmp fast olt float %2082, 1.000000e+00
  %2085 = and i1 %2083, %2084
  br i1 %2085, label %2086, label %2172

; <label>:2086                                    ; preds = %2080
  %2087 = sitofp i32 %2039 to float
  %2088 = sitofp i32 %1829 to float
  %2089 = fadd fast float %2087, 5.000000e-01
  %2090 = fadd fast float %2088, 5.000000e-01
  %2091 = fdiv fast float %2089, %46
  %2092 = fdiv fast float %2090, %47
  %2093 = fmul fast float %2091, 2.000000e+00
  %2094 = fmul fast float %2092, 2.000000e+00
  %2095 = fadd fast float %2093, -1.000000e+00
  %2096 = fsub fast float 1.000000e+00, %2094
  %2097 = fmul fast float %2095, %36
  %2098 = call float @dx.op.tertiary.f32(i32 46, float %2096, float %32, float %2097)  ; FMad(a,b,c)
  %2099 = call float @dx.op.tertiary.f32(i32 46, float %2082, float %28, float %2098)  ; FMad(a,b,c)
  %2100 = fadd fast float %2099, %24
  %2101 = call float @dx.op.unary.f32(i32 6, float %2100)  ; FAbs(value)
  %2102 = fcmp fast ogt float %2101, 0x3EB0C6F7A0000000
  br i1 %2102, label %2103, label %2172

; <label>:2103                                    ; preds = %2086
  %2104 = fmul fast float %2095, %35
  %2105 = call float @dx.op.tertiary.f32(i32 46, float %2096, float %31, float %2104)  ; FMad(a,b,c)
  %2106 = call float @dx.op.tertiary.f32(i32 46, float %2082, float %27, float %2105)  ; FMad(a,b,c)
  %2107 = fadd fast float %2106, %23
  %2108 = fmul fast float %2095, %34
  %2109 = call float @dx.op.tertiary.f32(i32 46, float %2096, float %30, float %2108)  ; FMad(a,b,c)
  %2110 = call float @dx.op.tertiary.f32(i32 46, float %2082, float %26, float %2109)  ; FMad(a,b,c)
  %2111 = fadd fast float %2110, %22
  %2112 = fmul fast float %2095, %33
  %2113 = call float @dx.op.tertiary.f32(i32 46, float %2096, float %29, float %2112)  ; FMad(a,b,c)
  %2114 = call float @dx.op.tertiary.f32(i32 46, float %2082, float %25, float %2113)  ; FMad(a,b,c)
  %2115 = fadd fast float %2114, %21
  %2116 = fdiv fast float %2115, %2100
  %2117 = fdiv fast float %2111, %2100
  %2118 = fdiv fast float %2107, %2100
  %2119 = fsub fast float %2116, %18
  %2120 = fsub fast float %2117, %19
  %2121 = fsub fast float %2118, %20
  %2122 = fmul fast float %2119, %2119
  %2123 = fmul fast float %2120, %2120
  %2124 = fadd fast float %2123, %2122
  %2125 = fmul fast float %2121, %2121
  %2126 = fadd fast float %2124, %2125
  %2127 = call float @dx.op.unary.f32(i32 24, float %2126)  ; Sqrt(value)
  %2128 = fsub fast float %2127, %10
  %2129 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2128)  ; FMax(a,b)
  %2130 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %2130, label %2131, label %2154

; <label>:2131                                    ; preds = %2103
  %2132 = call float @dx.op.unary.f32(i32 6, float %2120)  ; FAbs(value)
  %2133 = fmul fast float %2132, %12
  %2134 = fcmp fast olt float %2133, 0x3F50624DE0000000
  br i1 %2134, label %2135, label %2138

; <label>:2135                                    ; preds = %2131
  %2136 = fmul fast float %2133, 5.000000e-01
  %2137 = fsub fast float 1.000000e+00, %2136
  br label %2143

; <label>:2138                                    ; preds = %2131
  %2139 = fmul fast float %2133, 0xBFF7154760000000
  %2140 = call float @dx.op.unary.f32(i32 21, float %2139)  ; Exp(value)
  %2141 = fsub fast float 1.000000e+00, %2140
  %2142 = fdiv fast float %2141, %2133
  br label %2143

; <label>:2143                                    ; preds = %2138, %2135
  %2144 = phi float [ %2137, %2135 ], [ %2142, %2138 ]
  %2145 = call float @dx.op.binary.f32(i32 36, float %2117, float %19)  ; FMin(a,b)
  %2146 = fsub fast float %2145, %11
  %2147 = fmul fast float %12, %2146
  %2148 = fsub fast float -0.000000e+00, %2147
  %2149 = call float @dx.op.binary.f32(i32 35, float %2148, float -4.000000e+01)  ; FMax(a,b)
  %2150 = call float @dx.op.binary.f32(i32 36, float %2149, float 5.000000e+00)  ; FMin(a,b)
  %2151 = fmul fast float %2150, 0x3FF7154760000000
  %2152 = call float @dx.op.unary.f32(i32 21, float %2151)  ; Exp(value)
  %2153 = fmul fast float %2152, %2144
  br label %2154

; <label>:2154                                    ; preds = %2143, %2103
  %2155 = phi float [ %2153, %2143 ], [ 1.000000e+00, %2103 ]
  %2156 = fmul fast float %2129, %17
  %2157 = fmul fast float %2156, %2155
  %2158 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2157)  ; FMin(a,b)
  %2159 = fmul fast float %2158, 0xBFF7154760000000
  %2160 = call float @dx.op.unary.f32(i32 21, float %2159)  ; Exp(value)
  %2161 = fsub fast float 1.000000e+00, %2160
  %2162 = call float @dx.op.binary.f32(i32 36, float %13, float %2161)  ; FMin(a,b)
  %2163 = fsub fast float %14, %2041
  %2164 = fsub fast float %15, %2042
  %2165 = fsub fast float %16, %2043
  %2166 = fmul fast float %2162, %2163
  %2167 = fmul fast float %2162, %2164
  %2168 = fmul fast float %2162, %2165
  %2169 = fadd fast float %2166, %2041
  %2170 = fadd fast float %2167, %2042
  %2171 = fadd fast float %2168, %2043
  br label %2172

; <label>:2172                                    ; preds = %2154, %2086, %2080
  %2173 = phi float [ %2169, %2154 ], [ %2041, %2086 ], [ %2041, %2080 ]
  %2174 = phi float [ %2170, %2154 ], [ %2042, %2086 ], [ %2042, %2080 ]
  %2175 = phi float [ %2171, %2154 ], [ %2043, %2086 ], [ %2043, %2080 ]
  %2176 = fadd fast float %6, 1.000000e+00
  %2177 = fadd fast float %7, 1.000000e+00
  %2178 = fsub fast float 1.000000e+00, %6
  %2179 = fmul fast float %37, %2176
  %2180 = fmul fast float %37, %2177
  %2181 = fmul fast float %37, %2178
  %2182 = fmul fast float %2179, %2173
  %2183 = fmul fast float %2180, %2174
  %2184 = fmul fast float %2181, %2175
  %2185 = fcmp fast ult float %38, 5.000000e-01
  br i1 %2185, label %2211, label %2186

; <label>:2186                                    ; preds = %2172
  %2187 = fmul fast float %2182, 0x4004147AE0000000
  %2188 = fmul fast float %2183, 0x4004147AE0000000
  %2189 = fmul fast float %2184, 0x4004147AE0000000
  %2190 = fadd fast float %2187, 0x3F9EB851E0000000
  %2191 = fadd fast float %2188, 0x3F9EB851E0000000
  %2192 = fadd fast float %2189, 0x3F9EB851E0000000
  %2193 = fmul fast float %2190, %2182
  %2194 = fmul fast float %2191, %2183
  %2195 = fmul fast float %2192, %2184
  %2196 = fmul fast float %2182, 0x400370A3E0000000
  %2197 = fmul fast float %2183, 0x400370A3E0000000
  %2198 = fmul fast float %2184, 0x400370A3E0000000
  %2199 = fadd fast float %2196, 0x3FE2E147A0000000
  %2200 = fadd fast float %2197, 0x3FE2E147A0000000
  %2201 = fadd fast float %2198, 0x3FE2E147A0000000
  %2202 = fmul fast float %2199, %2182
  %2203 = fmul fast float %2200, %2183
  %2204 = fmul fast float %2201, %2184
  %2205 = fadd fast float %2202, 0x3FC1EB8520000000
  %2206 = fadd fast float %2203, 0x3FC1EB8520000000
  %2207 = fadd fast float %2204, 0x3FC1EB8520000000
  %2208 = fdiv fast float %2193, %2205
  %2209 = fdiv fast float %2194, %2206
  %2210 = fdiv fast float %2195, %2207
  br label %2211

; <label>:2211                                    ; preds = %2186, %2172
  %2212 = phi float [ %2208, %2186 ], [ %2182, %2172 ]
  %2213 = phi float [ %2209, %2186 ], [ %2183, %2172 ]
  %2214 = phi float [ %2210, %2186 ], [ %2184, %2172 ]
  %2215 = call float @dx.op.unary.f32(i32 7, float %2212)  ; Saturate(value)
  %2216 = call float @dx.op.unary.f32(i32 7, float %2213)  ; Saturate(value)
  %2217 = call float @dx.op.unary.f32(i32 7, float %2214)  ; Saturate(value)
  %2218 = call float @dx.op.dot3.f32(i32 55, float %2215, float %2216, float %2217, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2219 = fsub fast float %2215, %2218
  %2220 = fsub fast float %2216, %2218
  %2221 = fsub fast float %2217, %2218
  %2222 = fmul fast float %2219, %9
  %2223 = fmul fast float %2220, %9
  %2224 = fmul fast float %2221, %9
  %2225 = fadd fast float %2222, %2218
  %2226 = fadd fast float %2223, %2218
  %2227 = fadd fast float %2224, %2218
  %2228 = call float @dx.op.unary.f32(i32 7, float %2225)  ; Saturate(value)
  %2229 = call float @dx.op.unary.f32(i32 7, float %2226)  ; Saturate(value)
  %2230 = call float @dx.op.unary.f32(i32 7, float %2227)  ; Saturate(value)
  %2231 = fadd fast float %2228, 0xBFC70A3D80000000
  %2232 = fadd fast float %2229, 0xBFC70A3D80000000
  %2233 = fadd fast float %2230, 0xBFC70A3D80000000
  %2234 = fmul fast float %2231, %8
  %2235 = fmul fast float %2232, %8
  %2236 = fmul fast float %2233, %8
  %2237 = fadd fast float %2234, 0x3FC70A3D80000000
  %2238 = fadd fast float %2235, 0x3FC70A3D80000000
  %2239 = fadd fast float %2236, 0x3FC70A3D80000000
  %2240 = call float @dx.op.unary.f32(i32 7, float %2237)  ; Saturate(value)
  %2241 = call float @dx.op.unary.f32(i32 7, float %2238)  ; Saturate(value)
  %2242 = call float @dx.op.unary.f32(i32 7, float %2239)  ; Saturate(value)
  br label %2243

; <label>:2243                                    ; preds = %2211, %2046
  %2244 = phi float [ %2077, %2046 ], [ %2240, %2211 ]
  %2245 = phi float [ %2078, %2046 ], [ %2241, %2211 ]
  %2246 = phi float [ %2079, %2046 ], [ %2242, %2211 ]
  %2247 = call float @dx.op.binary.f32(i32 36, float %2034, float %2244)  ; FMin(a,b)
  %2248 = call float @dx.op.binary.f32(i32 36, float %2035, float %2245)  ; FMin(a,b)
  %2249 = call float @dx.op.binary.f32(i32 36, float %2036, float %2246)  ; FMin(a,b)
  %2250 = call float @dx.op.binary.f32(i32 36, float %1612, float %1822)  ; FMin(a,b)
  %2251 = call float @dx.op.binary.f32(i32 36, float %1613, float %1823)  ; FMin(a,b)
  %2252 = call float @dx.op.binary.f32(i32 36, float %1614, float %1824)  ; FMin(a,b)
  %2253 = call float @dx.op.binary.f32(i32 36, float %2250, float %2247)  ; FMin(a,b)
  %2254 = call float @dx.op.binary.f32(i32 36, float %2251, float %2248)  ; FMin(a,b)
  %2255 = call float @dx.op.binary.f32(i32 36, float %2252, float %2249)  ; FMin(a,b)
  %2256 = call float @dx.op.binary.f32(i32 36, float %1398, float %2253)  ; FMin(a,b)
  %2257 = call float @dx.op.binary.f32(i32 36, float %1399, float %2254)  ; FMin(a,b)
  %2258 = call float @dx.op.binary.f32(i32 36, float %1400, float %2255)  ; FMin(a,b)
  %2259 = call float @dx.op.binary.f32(i32 35, float %2034, float %2244)  ; FMax(a,b)
  %2260 = call float @dx.op.binary.f32(i32 35, float %2035, float %2245)  ; FMax(a,b)
  %2261 = call float @dx.op.binary.f32(i32 35, float %2036, float %2246)  ; FMax(a,b)
  %2262 = call float @dx.op.binary.f32(i32 35, float %1612, float %1822)  ; FMax(a,b)
  %2263 = call float @dx.op.binary.f32(i32 35, float %1613, float %1823)  ; FMax(a,b)
  %2264 = call float @dx.op.binary.f32(i32 35, float %1614, float %1824)  ; FMax(a,b)
  %2265 = call float @dx.op.binary.f32(i32 35, float %2262, float %2259)  ; FMax(a,b)
  %2266 = call float @dx.op.binary.f32(i32 35, float %2263, float %2260)  ; FMax(a,b)
  %2267 = call float @dx.op.binary.f32(i32 35, float %2264, float %2261)  ; FMax(a,b)
  %2268 = call float @dx.op.binary.f32(i32 35, float %1398, float %2265)  ; FMax(a,b)
  %2269 = call float @dx.op.binary.f32(i32 35, float %1399, float %2266)  ; FMax(a,b)
  %2270 = call float @dx.op.binary.f32(i32 35, float %1400, float %2267)  ; FMax(a,b)
  %2271 = fsub fast float %2268, %2256
  %2272 = fsub fast float %2269, %2257
  %2273 = fsub fast float %2270, %2258
  %2274 = call float @dx.op.unary.f32(i32 6, float %2271)  ; FAbs(value)
  %2275 = call float @dx.op.unary.f32(i32 6, float %2272)  ; FAbs(value)
  %2276 = call float @dx.op.unary.f32(i32 6, float %2273)  ; FAbs(value)
  %2277 = call float @dx.op.binary.f32(i32 35, float %2275, float %2276)  ; FMax(a,b)
  %2278 = call float @dx.op.binary.f32(i32 35, float %2274, float %2277)  ; FMax(a,b)
  %2279 = call float @dx.op.binary.f32(i32 35, float %2269, float %2270)  ; FMax(a,b)
  %2280 = call float @dx.op.binary.f32(i32 35, float %2268, float %2279)  ; FMax(a,b)
  %2281 = fmul fast float %2280, 1.250000e-01
  %2282 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %2281)  ; FMax(a,b)
  %2283 = fcmp fast ogt float %2278, %2282
  br i1 %2283, label %2284, label %2346

; <label>:2284                                    ; preds = %2243
  %2285 = fsub fast float %1612, %1822
  %2286 = fsub fast float %1613, %1823
  %2287 = fsub fast float %1614, %1824
  %2288 = call float @dx.op.unary.f32(i32 6, float %2285)  ; FAbs(value)
  %2289 = call float @dx.op.unary.f32(i32 6, float %2286)  ; FAbs(value)
  %2290 = call float @dx.op.unary.f32(i32 6, float %2287)  ; FAbs(value)
  %2291 = call float @dx.op.binary.f32(i32 35, float %2289, float %2290)  ; FMax(a,b)
  %2292 = call float @dx.op.binary.f32(i32 35, float %2288, float %2291)  ; FMax(a,b)
  %2293 = fsub fast float %2034, %2244
  %2294 = fsub fast float %2035, %2245
  %2295 = fsub fast float %2036, %2246
  %2296 = call float @dx.op.unary.f32(i32 6, float %2293)  ; FAbs(value)
  %2297 = call float @dx.op.unary.f32(i32 6, float %2294)  ; FAbs(value)
  %2298 = call float @dx.op.unary.f32(i32 6, float %2295)  ; FAbs(value)
  %2299 = call float @dx.op.binary.f32(i32 35, float %2297, float %2298)  ; FMax(a,b)
  %2300 = call float @dx.op.binary.f32(i32 35, float %2296, float %2299)  ; FMax(a,b)
  %2301 = fcmp fast olt float %2292, %2300
  %2302 = select i1 %2301, float %1612, float %2034
  %2303 = select i1 %2301, float %1613, float %2035
  %2304 = select i1 %2301, float %1614, float %2036
  %2305 = select i1 %2301, float %1822, float %2244
  %2306 = select i1 %2301, float %1823, float %2245
  %2307 = select i1 %2301, float %1824, float %2246
  %2308 = fsub fast float %1398, %2305
  %2309 = fsub fast float %1399, %2306
  %2310 = fsub fast float %1400, %2307
  %2311 = fsub fast float %1398, %2302
  %2312 = fsub fast float %1399, %2303
  %2313 = fsub fast float %1400, %2304
  %2314 = call float @dx.op.dot3.f32(i32 55, float %2311, float %2312, float %2313, float %2308, float %2309, float %2310)  ; Dot3(ax,ay,az,bx,by,bz)
  %2315 = fcmp fast ogt float %2314, 0.000000e+00
  br i1 %2315, label %2316, label %2327

; <label>:2316                                    ; preds = %2284
  %2317 = fsub fast float %2302, %2305
  %2318 = fsub fast float %2303, %2306
  %2319 = fsub fast float %2304, %2307
  %2320 = call float @dx.op.unary.f32(i32 6, float %2317)  ; FAbs(value)
  %2321 = call float @dx.op.unary.f32(i32 6, float %2318)  ; FAbs(value)
  %2322 = call float @dx.op.unary.f32(i32 6, float %2319)  ; FAbs(value)
  %2323 = call float @dx.op.binary.f32(i32 35, float %2321, float %2322)  ; FMax(a,b)
  %2324 = call float @dx.op.binary.f32(i32 35, float %2320, float %2323)  ; FMax(a,b)
  %2325 = fmul fast float %2278, 2.500000e-01
  %2326 = fcmp fast olt float %2324, %2325
  br label %2327

; <label>:2327                                    ; preds = %2316, %2284
  %2328 = phi i1 [ false, %2284 ], [ %2326, %2316 ]
  %2329 = select i1 %2328, float 5.000000e-01, float 1.000000e+00
  %2330 = fmul fast float %2329, %3
  %2331 = fadd fast float %2302, %2305
  %2332 = fadd fast float %2303, %2306
  %2333 = fadd fast float %2304, %2307
  %2334 = fmul fast float %2331, 5.000000e-01
  %2335 = fmul fast float %2332, 5.000000e-01
  %2336 = fmul fast float %2333, 5.000000e-01
  %2337 = fsub fast float %2334, %1398
  %2338 = fsub fast float %2335, %1399
  %2339 = fsub fast float %2336, %1400
  %2340 = fmul fast float %2330, %2337
  %2341 = fmul fast float %2330, %2338
  %2342 = fmul fast float %2330, %2339
  %2343 = fadd fast float %2340, %1398
  %2344 = fadd fast float %2341, %1399
  %2345 = fadd fast float %2342, %1400
  br label %2346

; <label>:2346                                    ; preds = %2327, %2243, %1369
  %2347 = phi float [ %2343, %2327 ], [ %1398, %2243 ], [ %1398, %1369 ]
  %2348 = phi float [ %2344, %2327 ], [ %1399, %2243 ], [ %1399, %1369 ]
  %2349 = phi float [ %2345, %2327 ], [ %1400, %2243 ], [ %1400, %1369 ]
  %2350 = fcmp fast ogt float %2347, 0x3F69A5C380000000
  %2351 = fcmp fast ogt float %2348, 0x3F69A5C380000000
  %2352 = fcmp fast ogt float %2349, 0x3F69A5C380000000
  %2353 = select i1 %2350, float 0.000000e+00, float 1.000000e+00
  %2354 = select i1 %2351, float 0.000000e+00, float 1.000000e+00
  %2355 = select i1 %2352, float 0.000000e+00, float 1.000000e+00
  %2356 = fmul fast float %2347, 0x4029D70A40000000
  %2357 = fmul fast float %2348, 0x4029D70A40000000
  %2358 = fmul fast float %2349, 0x4029D70A40000000
  %2359 = call float @dx.op.binary.f32(i32 35, float %2347, float 0.000000e+00)  ; FMax(a,b)
  %2360 = call float @dx.op.binary.f32(i32 35, float %2348, float 0.000000e+00)  ; FMax(a,b)
  %2361 = call float @dx.op.binary.f32(i32 35, float %2349, float 0.000000e+00)  ; FMax(a,b)
  %2362 = call float @dx.op.unary.f32(i32 23, float %2359)  ; Log(value)
  %2363 = call float @dx.op.unary.f32(i32 23, float %2360)  ; Log(value)
  %2364 = call float @dx.op.unary.f32(i32 23, float %2361)  ; Log(value)
  %2365 = fmul fast float %2362, 0x3FDAAAAAA0000000
  %2366 = fmul fast float %2363, 0x3FDAAAAAA0000000
  %2367 = fmul fast float %2364, 0x3FDAAAAAA0000000
  %2368 = call float @dx.op.unary.f32(i32 21, float %2365)  ; Exp(value)
  %2369 = call float @dx.op.unary.f32(i32 21, float %2366)  ; Exp(value)
  %2370 = call float @dx.op.unary.f32(i32 21, float %2367)  ; Exp(value)
  %2371 = fmul fast float %2368, 0x3FF0E147A0000000
  %2372 = fmul fast float %2369, 0x3FF0E147A0000000
  %2373 = fmul fast float %2370, 0x3FF0E147A0000000
  %2374 = fadd fast float %2371, 0xBFAC28F5C0000000
  %2375 = fadd fast float %2372, 0xBFAC28F5C0000000
  %2376 = fadd fast float %2373, 0xBFAC28F5C0000000
  %2377 = fsub fast float %2356, %2374
  %2378 = fsub fast float %2357, %2375
  %2379 = fsub fast float %2358, %2376
  %2380 = fmul fast float %2377, %2353
  %2381 = fmul fast float %2378, %2354
  %2382 = fmul fast float %2379, %2355
  %2383 = fadd fast float %2380, %2374
  %2384 = fadd fast float %2381, %2375
  %2385 = fadd fast float %2382, %2376
  br label %2386

; <label>:2386                                    ; preds = %2346, %1236
  %2387 = phi float [ %1231, %1236 ], [ %2383, %2346 ]
  %2388 = phi float [ %1232, %1236 ], [ %2384, %2346 ]
  %2389 = phi float [ %1233, %1236 ], [ %2385, %2346 ]
  %2390 = phi float [ %1237, %1236 ], [ %1234, %2346 ]
  %2391 = add i32 %57, 1
  %2392 = call i32 @dx.op.binary.i32(i32 37, i32 %2391, i32 0)  ; IMax(a,b)
  %2393 = call i32 @dx.op.binary.i32(i32 38, i32 %2392, i32 %61)  ; IMin(a,b)
  %2394 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %64, i32 %2393, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2395 = extractvalue %dx.types.ResRet.f32 %2394, 0
  %2396 = extractvalue %dx.types.ResRet.f32 %2394, 1
  %2397 = extractvalue %dx.types.ResRet.f32 %2394, 2
  %2398 = extractvalue %dx.types.ResRet.f32 %2394, 3
  %2399 = fcmp fast olt float %2398, 0.000000e+00
  br i1 %2399, label %2400, label %2402

; <label>:2400                                    ; preds = %2386
  %2401 = fsub fast float -1.000000e+00, %2398
  br label %3550

; <label>:2402                                    ; preds = %2386
  %2403 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %64, i32 %2393, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2404 = extractvalue %dx.types.ResRet.f32 %2403, 0
  %2405 = fcmp fast ogt float %39, 5.000000e-01
  %2406 = fcmp fast olt float %2404, 1.000000e+00
  %2407 = and i1 %2405, %2406
  br i1 %2407, label %2408, label %2494

; <label>:2408                                    ; preds = %2402
  %2409 = sitofp i32 %64 to float
  %2410 = sitofp i32 %2393 to float
  %2411 = fadd fast float %2409, 5.000000e-01
  %2412 = fadd fast float %2410, 5.000000e-01
  %2413 = fdiv fast float %2411, %46
  %2414 = fdiv fast float %2412, %47
  %2415 = fmul fast float %2413, 2.000000e+00
  %2416 = fmul fast float %2414, 2.000000e+00
  %2417 = fadd fast float %2415, -1.000000e+00
  %2418 = fsub fast float 1.000000e+00, %2416
  %2419 = fmul fast float %2417, %36
  %2420 = call float @dx.op.tertiary.f32(i32 46, float %2418, float %32, float %2419)  ; FMad(a,b,c)
  %2421 = call float @dx.op.tertiary.f32(i32 46, float %2404, float %28, float %2420)  ; FMad(a,b,c)
  %2422 = fadd fast float %2421, %24
  %2423 = call float @dx.op.unary.f32(i32 6, float %2422)  ; FAbs(value)
  %2424 = fcmp fast ogt float %2423, 0x3EB0C6F7A0000000
  br i1 %2424, label %2425, label %2494

; <label>:2425                                    ; preds = %2408
  %2426 = fmul fast float %2417, %35
  %2427 = call float @dx.op.tertiary.f32(i32 46, float %2418, float %31, float %2426)  ; FMad(a,b,c)
  %2428 = call float @dx.op.tertiary.f32(i32 46, float %2404, float %27, float %2427)  ; FMad(a,b,c)
  %2429 = fadd fast float %2428, %23
  %2430 = fmul fast float %2417, %34
  %2431 = call float @dx.op.tertiary.f32(i32 46, float %2418, float %30, float %2430)  ; FMad(a,b,c)
  %2432 = call float @dx.op.tertiary.f32(i32 46, float %2404, float %26, float %2431)  ; FMad(a,b,c)
  %2433 = fadd fast float %2432, %22
  %2434 = fmul fast float %2417, %33
  %2435 = call float @dx.op.tertiary.f32(i32 46, float %2418, float %29, float %2434)  ; FMad(a,b,c)
  %2436 = call float @dx.op.tertiary.f32(i32 46, float %2404, float %25, float %2435)  ; FMad(a,b,c)
  %2437 = fadd fast float %2436, %21
  %2438 = fdiv fast float %2437, %2422
  %2439 = fdiv fast float %2433, %2422
  %2440 = fdiv fast float %2429, %2422
  %2441 = fsub fast float %2438, %18
  %2442 = fsub fast float %2439, %19
  %2443 = fsub fast float %2440, %20
  %2444 = fmul fast float %2441, %2441
  %2445 = fmul fast float %2442, %2442
  %2446 = fadd fast float %2445, %2444
  %2447 = fmul fast float %2443, %2443
  %2448 = fadd fast float %2446, %2447
  %2449 = call float @dx.op.unary.f32(i32 24, float %2448)  ; Sqrt(value)
  %2450 = fsub fast float %2449, %10
  %2451 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2450)  ; FMax(a,b)
  %2452 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %2452, label %2453, label %2476

; <label>:2453                                    ; preds = %2425
  %2454 = call float @dx.op.unary.f32(i32 6, float %2442)  ; FAbs(value)
  %2455 = fmul fast float %2454, %12
  %2456 = fcmp fast olt float %2455, 0x3F50624DE0000000
  br i1 %2456, label %2457, label %2460

; <label>:2457                                    ; preds = %2453
  %2458 = fmul fast float %2455, 5.000000e-01
  %2459 = fsub fast float 1.000000e+00, %2458
  br label %2465

; <label>:2460                                    ; preds = %2453
  %2461 = fmul fast float %2455, 0xBFF7154760000000
  %2462 = call float @dx.op.unary.f32(i32 21, float %2461)  ; Exp(value)
  %2463 = fsub fast float 1.000000e+00, %2462
  %2464 = fdiv fast float %2463, %2455
  br label %2465

; <label>:2465                                    ; preds = %2460, %2457
  %2466 = phi float [ %2459, %2457 ], [ %2464, %2460 ]
  %2467 = call float @dx.op.binary.f32(i32 36, float %2439, float %19)  ; FMin(a,b)
  %2468 = fsub fast float %2467, %11
  %2469 = fmul fast float %12, %2468
  %2470 = fsub fast float -0.000000e+00, %2469
  %2471 = call float @dx.op.binary.f32(i32 35, float %2470, float -4.000000e+01)  ; FMax(a,b)
  %2472 = call float @dx.op.binary.f32(i32 36, float %2471, float 5.000000e+00)  ; FMin(a,b)
  %2473 = fmul fast float %2472, 0x3FF7154760000000
  %2474 = call float @dx.op.unary.f32(i32 21, float %2473)  ; Exp(value)
  %2475 = fmul fast float %2474, %2466
  br label %2476

; <label>:2476                                    ; preds = %2465, %2425
  %2477 = phi float [ %2475, %2465 ], [ 1.000000e+00, %2425 ]
  %2478 = fmul fast float %2451, %17
  %2479 = fmul fast float %2478, %2477
  %2480 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2479)  ; FMin(a,b)
  %2481 = fmul fast float %2480, 0xBFF7154760000000
  %2482 = call float @dx.op.unary.f32(i32 21, float %2481)  ; Exp(value)
  %2483 = fsub fast float 1.000000e+00, %2482
  %2484 = call float @dx.op.binary.f32(i32 36, float %13, float %2483)  ; FMin(a,b)
  %2485 = fsub fast float %14, %2395
  %2486 = fsub fast float %15, %2396
  %2487 = fsub fast float %16, %2397
  %2488 = fmul fast float %2484, %2485
  %2489 = fmul fast float %2484, %2486
  %2490 = fmul fast float %2484, %2487
  %2491 = fadd fast float %2488, %2395
  %2492 = fadd fast float %2489, %2396
  %2493 = fadd fast float %2490, %2397
  br label %2494

; <label>:2494                                    ; preds = %2476, %2408, %2402
  %2495 = phi float [ %2491, %2476 ], [ %2395, %2408 ], [ %2395, %2402 ]
  %2496 = phi float [ %2492, %2476 ], [ %2396, %2408 ], [ %2396, %2402 ]
  %2497 = phi float [ %2493, %2476 ], [ %2397, %2408 ], [ %2397, %2402 ]
  %2498 = fadd fast float %6, 1.000000e+00
  %2499 = fadd fast float %7, 1.000000e+00
  %2500 = fsub fast float 1.000000e+00, %6
  %2501 = fmul fast float %37, %2498
  %2502 = fmul fast float %37, %2499
  %2503 = fmul fast float %37, %2500
  %2504 = fmul fast float %2501, %2495
  %2505 = fmul fast float %2502, %2496
  %2506 = fmul fast float %2503, %2497
  %2507 = fcmp fast ult float %38, 5.000000e-01
  br i1 %2507, label %2533, label %2508

; <label>:2508                                    ; preds = %2494
  %2509 = fmul fast float %2504, 0x4004147AE0000000
  %2510 = fmul fast float %2505, 0x4004147AE0000000
  %2511 = fmul fast float %2506, 0x4004147AE0000000
  %2512 = fadd fast float %2509, 0x3F9EB851E0000000
  %2513 = fadd fast float %2510, 0x3F9EB851E0000000
  %2514 = fadd fast float %2511, 0x3F9EB851E0000000
  %2515 = fmul fast float %2512, %2504
  %2516 = fmul fast float %2513, %2505
  %2517 = fmul fast float %2514, %2506
  %2518 = fmul fast float %2504, 0x400370A3E0000000
  %2519 = fmul fast float %2505, 0x400370A3E0000000
  %2520 = fmul fast float %2506, 0x400370A3E0000000
  %2521 = fadd fast float %2518, 0x3FE2E147A0000000
  %2522 = fadd fast float %2519, 0x3FE2E147A0000000
  %2523 = fadd fast float %2520, 0x3FE2E147A0000000
  %2524 = fmul fast float %2521, %2504
  %2525 = fmul fast float %2522, %2505
  %2526 = fmul fast float %2523, %2506
  %2527 = fadd fast float %2524, 0x3FC1EB8520000000
  %2528 = fadd fast float %2525, 0x3FC1EB8520000000
  %2529 = fadd fast float %2526, 0x3FC1EB8520000000
  %2530 = fdiv fast float %2515, %2527
  %2531 = fdiv fast float %2516, %2528
  %2532 = fdiv fast float %2517, %2529
  br label %2533

; <label>:2533                                    ; preds = %2508, %2494
  %2534 = phi float [ %2530, %2508 ], [ %2504, %2494 ]
  %2535 = phi float [ %2531, %2508 ], [ %2505, %2494 ]
  %2536 = phi float [ %2532, %2508 ], [ %2506, %2494 ]
  %2537 = call float @dx.op.unary.f32(i32 7, float %2534)  ; Saturate(value)
  %2538 = call float @dx.op.unary.f32(i32 7, float %2535)  ; Saturate(value)
  %2539 = call float @dx.op.unary.f32(i32 7, float %2536)  ; Saturate(value)
  %2540 = call float @dx.op.dot3.f32(i32 55, float %2537, float %2538, float %2539, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2541 = fsub fast float %2537, %2540
  %2542 = fsub fast float %2538, %2540
  %2543 = fsub fast float %2539, %2540
  %2544 = fmul fast float %2541, %9
  %2545 = fmul fast float %2542, %9
  %2546 = fmul fast float %2543, %9
  %2547 = fadd fast float %2544, %2540
  %2548 = fadd fast float %2545, %2540
  %2549 = fadd fast float %2546, %2540
  %2550 = call float @dx.op.unary.f32(i32 7, float %2547)  ; Saturate(value)
  %2551 = call float @dx.op.unary.f32(i32 7, float %2548)  ; Saturate(value)
  %2552 = call float @dx.op.unary.f32(i32 7, float %2549)  ; Saturate(value)
  %2553 = fadd fast float %2550, 0xBFC70A3D80000000
  %2554 = fadd fast float %2551, 0xBFC70A3D80000000
  %2555 = fadd fast float %2552, 0xBFC70A3D80000000
  %2556 = fmul fast float %2553, %8
  %2557 = fmul fast float %2554, %8
  %2558 = fmul fast float %2555, %8
  %2559 = fadd fast float %2556, 0x3FC70A3D80000000
  %2560 = fadd fast float %2557, 0x3FC70A3D80000000
  %2561 = fadd fast float %2558, 0x3FC70A3D80000000
  %2562 = call float @dx.op.unary.f32(i32 7, float %2559)  ; Saturate(value)
  %2563 = call float @dx.op.unary.f32(i32 7, float %2560)  ; Saturate(value)
  %2564 = call float @dx.op.unary.f32(i32 7, float %2561)  ; Saturate(value)
  %2565 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %2565, label %2566, label %3510

; <label>:2566                                    ; preds = %2533
  %2567 = add i32 %2393, -1
  %2568 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %2569 = call i32 @dx.op.binary.i32(i32 37, i32 %2567, i32 0)  ; IMax(a,b)
  %2570 = call i32 @dx.op.binary.i32(i32 38, i32 %2568, i32 %60)  ; IMin(a,b)
  %2571 = call i32 @dx.op.binary.i32(i32 38, i32 %2569, i32 %61)  ; IMin(a,b)
  %2572 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2570, i32 %2571, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2573 = extractvalue %dx.types.ResRet.f32 %2572, 0
  %2574 = extractvalue %dx.types.ResRet.f32 %2572, 1
  %2575 = extractvalue %dx.types.ResRet.f32 %2572, 2
  %2576 = extractvalue %dx.types.ResRet.f32 %2572, 3
  %2577 = fcmp fast olt float %2576, 0.000000e+00
  br i1 %2577, label %2578, label %2612

; <label>:2578                                    ; preds = %2566
  %2579 = fcmp fast ogt float %2573, 0x3FA4B5DCC0000000
  %2580 = fcmp fast ogt float %2574, 0x3FA4B5DCC0000000
  %2581 = fcmp fast ogt float %2575, 0x3FA4B5DCC0000000
  %2582 = select i1 %2579, float 0.000000e+00, float 1.000000e+00
  %2583 = select i1 %2580, float 0.000000e+00, float 1.000000e+00
  %2584 = select i1 %2581, float 0.000000e+00, float 1.000000e+00
  %2585 = fmul fast float %2573, 0x3FB3D07220000000
  %2586 = fmul fast float %2574, 0x3FB3D07220000000
  %2587 = fmul fast float %2575, 0x3FB3D07220000000
  %2588 = fadd fast float %2573, 0x3FAC28F5C0000000
  %2589 = fadd fast float %2574, 0x3FAC28F5C0000000
  %2590 = fadd fast float %2575, 0x3FAC28F5C0000000
  %2591 = fmul fast float %2588, 0x3FEE54EDE0000000
  %2592 = fmul fast float %2589, 0x3FEE54EDE0000000
  %2593 = fmul fast float %2590, 0x3FEE54EDE0000000
  %2594 = call float @dx.op.unary.f32(i32 23, float %2591)  ; Log(value)
  %2595 = call float @dx.op.unary.f32(i32 23, float %2592)  ; Log(value)
  %2596 = call float @dx.op.unary.f32(i32 23, float %2593)  ; Log(value)
  %2597 = fmul fast float %2594, 0x4003333340000000
  %2598 = fmul fast float %2595, 0x4003333340000000
  %2599 = fmul fast float %2596, 0x4003333340000000
  %2600 = call float @dx.op.unary.f32(i32 21, float %2597)  ; Exp(value)
  %2601 = call float @dx.op.unary.f32(i32 21, float %2598)  ; Exp(value)
  %2602 = call float @dx.op.unary.f32(i32 21, float %2599)  ; Exp(value)
  %2603 = fsub fast float %2585, %2600
  %2604 = fsub fast float %2586, %2601
  %2605 = fsub fast float %2587, %2602
  %2606 = fmul fast float %2603, %2582
  %2607 = fmul fast float %2604, %2583
  %2608 = fmul fast float %2605, %2584
  %2609 = fadd fast float %2606, %2600
  %2610 = fadd fast float %2607, %2601
  %2611 = fadd fast float %2608, %2602
  br label %2775

; <label>:2612                                    ; preds = %2566
  %2613 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2570, i32 %2571, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2614 = extractvalue %dx.types.ResRet.f32 %2613, 0
  %2615 = fcmp fast ogt float %39, 5.000000e-01
  %2616 = fcmp fast olt float %2614, 1.000000e+00
  %2617 = and i1 %2615, %2616
  br i1 %2617, label %2618, label %2704

; <label>:2618                                    ; preds = %2612
  %2619 = sitofp i32 %2570 to float
  %2620 = sitofp i32 %2571 to float
  %2621 = fadd fast float %2619, 5.000000e-01
  %2622 = fadd fast float %2620, 5.000000e-01
  %2623 = fdiv fast float %2621, %46
  %2624 = fdiv fast float %2622, %47
  %2625 = fmul fast float %2623, 2.000000e+00
  %2626 = fmul fast float %2624, 2.000000e+00
  %2627 = fadd fast float %2625, -1.000000e+00
  %2628 = fsub fast float 1.000000e+00, %2626
  %2629 = fmul fast float %2627, %36
  %2630 = call float @dx.op.tertiary.f32(i32 46, float %2628, float %32, float %2629)  ; FMad(a,b,c)
  %2631 = call float @dx.op.tertiary.f32(i32 46, float %2614, float %28, float %2630)  ; FMad(a,b,c)
  %2632 = fadd fast float %2631, %24
  %2633 = call float @dx.op.unary.f32(i32 6, float %2632)  ; FAbs(value)
  %2634 = fcmp fast ogt float %2633, 0x3EB0C6F7A0000000
  br i1 %2634, label %2635, label %2704

; <label>:2635                                    ; preds = %2618
  %2636 = fmul fast float %2627, %35
  %2637 = call float @dx.op.tertiary.f32(i32 46, float %2628, float %31, float %2636)  ; FMad(a,b,c)
  %2638 = call float @dx.op.tertiary.f32(i32 46, float %2614, float %27, float %2637)  ; FMad(a,b,c)
  %2639 = fadd fast float %2638, %23
  %2640 = fmul fast float %2627, %34
  %2641 = call float @dx.op.tertiary.f32(i32 46, float %2628, float %30, float %2640)  ; FMad(a,b,c)
  %2642 = call float @dx.op.tertiary.f32(i32 46, float %2614, float %26, float %2641)  ; FMad(a,b,c)
  %2643 = fadd fast float %2642, %22
  %2644 = fmul fast float %2627, %33
  %2645 = call float @dx.op.tertiary.f32(i32 46, float %2628, float %29, float %2644)  ; FMad(a,b,c)
  %2646 = call float @dx.op.tertiary.f32(i32 46, float %2614, float %25, float %2645)  ; FMad(a,b,c)
  %2647 = fadd fast float %2646, %21
  %2648 = fdiv fast float %2647, %2632
  %2649 = fdiv fast float %2643, %2632
  %2650 = fdiv fast float %2639, %2632
  %2651 = fsub fast float %2648, %18
  %2652 = fsub fast float %2649, %19
  %2653 = fsub fast float %2650, %20
  %2654 = fmul fast float %2651, %2651
  %2655 = fmul fast float %2652, %2652
  %2656 = fadd fast float %2655, %2654
  %2657 = fmul fast float %2653, %2653
  %2658 = fadd fast float %2656, %2657
  %2659 = call float @dx.op.unary.f32(i32 24, float %2658)  ; Sqrt(value)
  %2660 = fsub fast float %2659, %10
  %2661 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2660)  ; FMax(a,b)
  %2662 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %2662, label %2663, label %2686

; <label>:2663                                    ; preds = %2635
  %2664 = call float @dx.op.unary.f32(i32 6, float %2652)  ; FAbs(value)
  %2665 = fmul fast float %2664, %12
  %2666 = fcmp fast olt float %2665, 0x3F50624DE0000000
  br i1 %2666, label %2667, label %2670

; <label>:2667                                    ; preds = %2663
  %2668 = fmul fast float %2665, 5.000000e-01
  %2669 = fsub fast float 1.000000e+00, %2668
  br label %2675

; <label>:2670                                    ; preds = %2663
  %2671 = fmul fast float %2665, 0xBFF7154760000000
  %2672 = call float @dx.op.unary.f32(i32 21, float %2671)  ; Exp(value)
  %2673 = fsub fast float 1.000000e+00, %2672
  %2674 = fdiv fast float %2673, %2665
  br label %2675

; <label>:2675                                    ; preds = %2670, %2667
  %2676 = phi float [ %2669, %2667 ], [ %2674, %2670 ]
  %2677 = call float @dx.op.binary.f32(i32 36, float %2649, float %19)  ; FMin(a,b)
  %2678 = fsub fast float %2677, %11
  %2679 = fmul fast float %12, %2678
  %2680 = fsub fast float -0.000000e+00, %2679
  %2681 = call float @dx.op.binary.f32(i32 35, float %2680, float -4.000000e+01)  ; FMax(a,b)
  %2682 = call float @dx.op.binary.f32(i32 36, float %2681, float 5.000000e+00)  ; FMin(a,b)
  %2683 = fmul fast float %2682, 0x3FF7154760000000
  %2684 = call float @dx.op.unary.f32(i32 21, float %2683)  ; Exp(value)
  %2685 = fmul fast float %2684, %2676
  br label %2686

; <label>:2686                                    ; preds = %2675, %2635
  %2687 = phi float [ %2685, %2675 ], [ 1.000000e+00, %2635 ]
  %2688 = fmul fast float %2661, %17
  %2689 = fmul fast float %2688, %2687
  %2690 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2689)  ; FMin(a,b)
  %2691 = fmul fast float %2690, 0xBFF7154760000000
  %2692 = call float @dx.op.unary.f32(i32 21, float %2691)  ; Exp(value)
  %2693 = fsub fast float 1.000000e+00, %2692
  %2694 = call float @dx.op.binary.f32(i32 36, float %13, float %2693)  ; FMin(a,b)
  %2695 = fsub fast float %14, %2573
  %2696 = fsub fast float %15, %2574
  %2697 = fsub fast float %16, %2575
  %2698 = fmul fast float %2694, %2695
  %2699 = fmul fast float %2694, %2696
  %2700 = fmul fast float %2694, %2697
  %2701 = fadd fast float %2698, %2573
  %2702 = fadd fast float %2699, %2574
  %2703 = fadd fast float %2700, %2575
  br label %2704

; <label>:2704                                    ; preds = %2686, %2618, %2612
  %2705 = phi float [ %2701, %2686 ], [ %2573, %2618 ], [ %2573, %2612 ]
  %2706 = phi float [ %2702, %2686 ], [ %2574, %2618 ], [ %2574, %2612 ]
  %2707 = phi float [ %2703, %2686 ], [ %2575, %2618 ], [ %2575, %2612 ]
  %2708 = fadd fast float %6, 1.000000e+00
  %2709 = fadd fast float %7, 1.000000e+00
  %2710 = fsub fast float 1.000000e+00, %6
  %2711 = fmul fast float %37, %2708
  %2712 = fmul fast float %37, %2709
  %2713 = fmul fast float %37, %2710
  %2714 = fmul fast float %2711, %2705
  %2715 = fmul fast float %2712, %2706
  %2716 = fmul fast float %2713, %2707
  %2717 = fcmp fast ult float %38, 5.000000e-01
  br i1 %2717, label %2743, label %2718

; <label>:2718                                    ; preds = %2704
  %2719 = fmul fast float %2714, 0x4004147AE0000000
  %2720 = fmul fast float %2715, 0x4004147AE0000000
  %2721 = fmul fast float %2716, 0x4004147AE0000000
  %2722 = fadd fast float %2719, 0x3F9EB851E0000000
  %2723 = fadd fast float %2720, 0x3F9EB851E0000000
  %2724 = fadd fast float %2721, 0x3F9EB851E0000000
  %2725 = fmul fast float %2722, %2714
  %2726 = fmul fast float %2723, %2715
  %2727 = fmul fast float %2724, %2716
  %2728 = fmul fast float %2714, 0x400370A3E0000000
  %2729 = fmul fast float %2715, 0x400370A3E0000000
  %2730 = fmul fast float %2716, 0x400370A3E0000000
  %2731 = fadd fast float %2728, 0x3FE2E147A0000000
  %2732 = fadd fast float %2729, 0x3FE2E147A0000000
  %2733 = fadd fast float %2730, 0x3FE2E147A0000000
  %2734 = fmul fast float %2731, %2714
  %2735 = fmul fast float %2732, %2715
  %2736 = fmul fast float %2733, %2716
  %2737 = fadd fast float %2734, 0x3FC1EB8520000000
  %2738 = fadd fast float %2735, 0x3FC1EB8520000000
  %2739 = fadd fast float %2736, 0x3FC1EB8520000000
  %2740 = fdiv fast float %2725, %2737
  %2741 = fdiv fast float %2726, %2738
  %2742 = fdiv fast float %2727, %2739
  br label %2743

; <label>:2743                                    ; preds = %2718, %2704
  %2744 = phi float [ %2740, %2718 ], [ %2714, %2704 ]
  %2745 = phi float [ %2741, %2718 ], [ %2715, %2704 ]
  %2746 = phi float [ %2742, %2718 ], [ %2716, %2704 ]
  %2747 = call float @dx.op.unary.f32(i32 7, float %2744)  ; Saturate(value)
  %2748 = call float @dx.op.unary.f32(i32 7, float %2745)  ; Saturate(value)
  %2749 = call float @dx.op.unary.f32(i32 7, float %2746)  ; Saturate(value)
  %2750 = call float @dx.op.dot3.f32(i32 55, float %2747, float %2748, float %2749, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2751 = fsub fast float %2747, %2750
  %2752 = fsub fast float %2748, %2750
  %2753 = fsub fast float %2749, %2750
  %2754 = fmul fast float %2751, %9
  %2755 = fmul fast float %2752, %9
  %2756 = fmul fast float %2753, %9
  %2757 = fadd fast float %2754, %2750
  %2758 = fadd fast float %2755, %2750
  %2759 = fadd fast float %2756, %2750
  %2760 = call float @dx.op.unary.f32(i32 7, float %2757)  ; Saturate(value)
  %2761 = call float @dx.op.unary.f32(i32 7, float %2758)  ; Saturate(value)
  %2762 = call float @dx.op.unary.f32(i32 7, float %2759)  ; Saturate(value)
  %2763 = fadd fast float %2760, 0xBFC70A3D80000000
  %2764 = fadd fast float %2761, 0xBFC70A3D80000000
  %2765 = fadd fast float %2762, 0xBFC70A3D80000000
  %2766 = fmul fast float %2763, %8
  %2767 = fmul fast float %2764, %8
  %2768 = fmul fast float %2765, %8
  %2769 = fadd fast float %2766, 0x3FC70A3D80000000
  %2770 = fadd fast float %2767, 0x3FC70A3D80000000
  %2771 = fadd fast float %2768, 0x3FC70A3D80000000
  %2772 = call float @dx.op.unary.f32(i32 7, float %2769)  ; Saturate(value)
  %2773 = call float @dx.op.unary.f32(i32 7, float %2770)  ; Saturate(value)
  %2774 = call float @dx.op.unary.f32(i32 7, float %2771)  ; Saturate(value)
  br label %2775

; <label>:2775                                    ; preds = %2743, %2578
  %2776 = phi float [ %2609, %2578 ], [ %2772, %2743 ]
  %2777 = phi float [ %2610, %2578 ], [ %2773, %2743 ]
  %2778 = phi float [ %2611, %2578 ], [ %2774, %2743 ]
  %2779 = add i32 %2393, 1
  %2780 = call i32 @dx.op.binary.i32(i32 37, i32 %2779, i32 0)  ; IMax(a,b)
  %2781 = call i32 @dx.op.binary.i32(i32 38, i32 %2780, i32 %61)  ; IMin(a,b)
  %2782 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2570, i32 %2781, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2783 = extractvalue %dx.types.ResRet.f32 %2782, 0
  %2784 = extractvalue %dx.types.ResRet.f32 %2782, 1
  %2785 = extractvalue %dx.types.ResRet.f32 %2782, 2
  %2786 = extractvalue %dx.types.ResRet.f32 %2782, 3
  %2787 = fcmp fast olt float %2786, 0.000000e+00
  br i1 %2787, label %2788, label %2822

; <label>:2788                                    ; preds = %2775
  %2789 = fcmp fast ogt float %2783, 0x3FA4B5DCC0000000
  %2790 = fcmp fast ogt float %2784, 0x3FA4B5DCC0000000
  %2791 = fcmp fast ogt float %2785, 0x3FA4B5DCC0000000
  %2792 = select i1 %2789, float 0.000000e+00, float 1.000000e+00
  %2793 = select i1 %2790, float 0.000000e+00, float 1.000000e+00
  %2794 = select i1 %2791, float 0.000000e+00, float 1.000000e+00
  %2795 = fmul fast float %2783, 0x3FB3D07220000000
  %2796 = fmul fast float %2784, 0x3FB3D07220000000
  %2797 = fmul fast float %2785, 0x3FB3D07220000000
  %2798 = fadd fast float %2783, 0x3FAC28F5C0000000
  %2799 = fadd fast float %2784, 0x3FAC28F5C0000000
  %2800 = fadd fast float %2785, 0x3FAC28F5C0000000
  %2801 = fmul fast float %2798, 0x3FEE54EDE0000000
  %2802 = fmul fast float %2799, 0x3FEE54EDE0000000
  %2803 = fmul fast float %2800, 0x3FEE54EDE0000000
  %2804 = call float @dx.op.unary.f32(i32 23, float %2801)  ; Log(value)
  %2805 = call float @dx.op.unary.f32(i32 23, float %2802)  ; Log(value)
  %2806 = call float @dx.op.unary.f32(i32 23, float %2803)  ; Log(value)
  %2807 = fmul fast float %2804, 0x4003333340000000
  %2808 = fmul fast float %2805, 0x4003333340000000
  %2809 = fmul fast float %2806, 0x4003333340000000
  %2810 = call float @dx.op.unary.f32(i32 21, float %2807)  ; Exp(value)
  %2811 = call float @dx.op.unary.f32(i32 21, float %2808)  ; Exp(value)
  %2812 = call float @dx.op.unary.f32(i32 21, float %2809)  ; Exp(value)
  %2813 = fsub fast float %2795, %2810
  %2814 = fsub fast float %2796, %2811
  %2815 = fsub fast float %2797, %2812
  %2816 = fmul fast float %2813, %2792
  %2817 = fmul fast float %2814, %2793
  %2818 = fmul fast float %2815, %2794
  %2819 = fadd fast float %2816, %2810
  %2820 = fadd fast float %2817, %2811
  %2821 = fadd fast float %2818, %2812
  br label %2985

; <label>:2822                                    ; preds = %2775
  %2823 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2570, i32 %2781, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2824 = extractvalue %dx.types.ResRet.f32 %2823, 0
  %2825 = fcmp fast ogt float %39, 5.000000e-01
  %2826 = fcmp fast olt float %2824, 1.000000e+00
  %2827 = and i1 %2825, %2826
  br i1 %2827, label %2828, label %2914

; <label>:2828                                    ; preds = %2822
  %2829 = sitofp i32 %2570 to float
  %2830 = sitofp i32 %2781 to float
  %2831 = fadd fast float %2829, 5.000000e-01
  %2832 = fadd fast float %2830, 5.000000e-01
  %2833 = fdiv fast float %2831, %46
  %2834 = fdiv fast float %2832, %47
  %2835 = fmul fast float %2833, 2.000000e+00
  %2836 = fmul fast float %2834, 2.000000e+00
  %2837 = fadd fast float %2835, -1.000000e+00
  %2838 = fsub fast float 1.000000e+00, %2836
  %2839 = fmul fast float %2837, %36
  %2840 = call float @dx.op.tertiary.f32(i32 46, float %2838, float %32, float %2839)  ; FMad(a,b,c)
  %2841 = call float @dx.op.tertiary.f32(i32 46, float %2824, float %28, float %2840)  ; FMad(a,b,c)
  %2842 = fadd fast float %2841, %24
  %2843 = call float @dx.op.unary.f32(i32 6, float %2842)  ; FAbs(value)
  %2844 = fcmp fast ogt float %2843, 0x3EB0C6F7A0000000
  br i1 %2844, label %2845, label %2914

; <label>:2845                                    ; preds = %2828
  %2846 = fmul fast float %2837, %35
  %2847 = call float @dx.op.tertiary.f32(i32 46, float %2838, float %31, float %2846)  ; FMad(a,b,c)
  %2848 = call float @dx.op.tertiary.f32(i32 46, float %2824, float %27, float %2847)  ; FMad(a,b,c)
  %2849 = fadd fast float %2848, %23
  %2850 = fmul fast float %2837, %34
  %2851 = call float @dx.op.tertiary.f32(i32 46, float %2838, float %30, float %2850)  ; FMad(a,b,c)
  %2852 = call float @dx.op.tertiary.f32(i32 46, float %2824, float %26, float %2851)  ; FMad(a,b,c)
  %2853 = fadd fast float %2852, %22
  %2854 = fmul fast float %2837, %33
  %2855 = call float @dx.op.tertiary.f32(i32 46, float %2838, float %29, float %2854)  ; FMad(a,b,c)
  %2856 = call float @dx.op.tertiary.f32(i32 46, float %2824, float %25, float %2855)  ; FMad(a,b,c)
  %2857 = fadd fast float %2856, %21
  %2858 = fdiv fast float %2857, %2842
  %2859 = fdiv fast float %2853, %2842
  %2860 = fdiv fast float %2849, %2842
  %2861 = fsub fast float %2858, %18
  %2862 = fsub fast float %2859, %19
  %2863 = fsub fast float %2860, %20
  %2864 = fmul fast float %2861, %2861
  %2865 = fmul fast float %2862, %2862
  %2866 = fadd fast float %2865, %2864
  %2867 = fmul fast float %2863, %2863
  %2868 = fadd fast float %2866, %2867
  %2869 = call float @dx.op.unary.f32(i32 24, float %2868)  ; Sqrt(value)
  %2870 = fsub fast float %2869, %10
  %2871 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2870)  ; FMax(a,b)
  %2872 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %2872, label %2873, label %2896

; <label>:2873                                    ; preds = %2845
  %2874 = call float @dx.op.unary.f32(i32 6, float %2862)  ; FAbs(value)
  %2875 = fmul fast float %2874, %12
  %2876 = fcmp fast olt float %2875, 0x3F50624DE0000000
  br i1 %2876, label %2877, label %2880

; <label>:2877                                    ; preds = %2873
  %2878 = fmul fast float %2875, 5.000000e-01
  %2879 = fsub fast float 1.000000e+00, %2878
  br label %2885

; <label>:2880                                    ; preds = %2873
  %2881 = fmul fast float %2875, 0xBFF7154760000000
  %2882 = call float @dx.op.unary.f32(i32 21, float %2881)  ; Exp(value)
  %2883 = fsub fast float 1.000000e+00, %2882
  %2884 = fdiv fast float %2883, %2875
  br label %2885

; <label>:2885                                    ; preds = %2880, %2877
  %2886 = phi float [ %2879, %2877 ], [ %2884, %2880 ]
  %2887 = call float @dx.op.binary.f32(i32 36, float %2859, float %19)  ; FMin(a,b)
  %2888 = fsub fast float %2887, %11
  %2889 = fmul fast float %12, %2888
  %2890 = fsub fast float -0.000000e+00, %2889
  %2891 = call float @dx.op.binary.f32(i32 35, float %2890, float -4.000000e+01)  ; FMax(a,b)
  %2892 = call float @dx.op.binary.f32(i32 36, float %2891, float 5.000000e+00)  ; FMin(a,b)
  %2893 = fmul fast float %2892, 0x3FF7154760000000
  %2894 = call float @dx.op.unary.f32(i32 21, float %2893)  ; Exp(value)
  %2895 = fmul fast float %2894, %2886
  br label %2896

; <label>:2896                                    ; preds = %2885, %2845
  %2897 = phi float [ %2895, %2885 ], [ 1.000000e+00, %2845 ]
  %2898 = fmul fast float %2871, %17
  %2899 = fmul fast float %2898, %2897
  %2900 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2899)  ; FMin(a,b)
  %2901 = fmul fast float %2900, 0xBFF7154760000000
  %2902 = call float @dx.op.unary.f32(i32 21, float %2901)  ; Exp(value)
  %2903 = fsub fast float 1.000000e+00, %2902
  %2904 = call float @dx.op.binary.f32(i32 36, float %13, float %2903)  ; FMin(a,b)
  %2905 = fsub fast float %14, %2783
  %2906 = fsub fast float %15, %2784
  %2907 = fsub fast float %16, %2785
  %2908 = fmul fast float %2904, %2905
  %2909 = fmul fast float %2904, %2906
  %2910 = fmul fast float %2904, %2907
  %2911 = fadd fast float %2908, %2783
  %2912 = fadd fast float %2909, %2784
  %2913 = fadd fast float %2910, %2785
  br label %2914

; <label>:2914                                    ; preds = %2896, %2828, %2822
  %2915 = phi float [ %2911, %2896 ], [ %2783, %2828 ], [ %2783, %2822 ]
  %2916 = phi float [ %2912, %2896 ], [ %2784, %2828 ], [ %2784, %2822 ]
  %2917 = phi float [ %2913, %2896 ], [ %2785, %2828 ], [ %2785, %2822 ]
  %2918 = fadd fast float %6, 1.000000e+00
  %2919 = fadd fast float %7, 1.000000e+00
  %2920 = fsub fast float 1.000000e+00, %6
  %2921 = fmul fast float %37, %2918
  %2922 = fmul fast float %37, %2919
  %2923 = fmul fast float %37, %2920
  %2924 = fmul fast float %2921, %2915
  %2925 = fmul fast float %2922, %2916
  %2926 = fmul fast float %2923, %2917
  %2927 = fcmp fast ult float %38, 5.000000e-01
  br i1 %2927, label %2953, label %2928

; <label>:2928                                    ; preds = %2914
  %2929 = fmul fast float %2924, 0x4004147AE0000000
  %2930 = fmul fast float %2925, 0x4004147AE0000000
  %2931 = fmul fast float %2926, 0x4004147AE0000000
  %2932 = fadd fast float %2929, 0x3F9EB851E0000000
  %2933 = fadd fast float %2930, 0x3F9EB851E0000000
  %2934 = fadd fast float %2931, 0x3F9EB851E0000000
  %2935 = fmul fast float %2932, %2924
  %2936 = fmul fast float %2933, %2925
  %2937 = fmul fast float %2934, %2926
  %2938 = fmul fast float %2924, 0x400370A3E0000000
  %2939 = fmul fast float %2925, 0x400370A3E0000000
  %2940 = fmul fast float %2926, 0x400370A3E0000000
  %2941 = fadd fast float %2938, 0x3FE2E147A0000000
  %2942 = fadd fast float %2939, 0x3FE2E147A0000000
  %2943 = fadd fast float %2940, 0x3FE2E147A0000000
  %2944 = fmul fast float %2941, %2924
  %2945 = fmul fast float %2942, %2925
  %2946 = fmul fast float %2943, %2926
  %2947 = fadd fast float %2944, 0x3FC1EB8520000000
  %2948 = fadd fast float %2945, 0x3FC1EB8520000000
  %2949 = fadd fast float %2946, 0x3FC1EB8520000000
  %2950 = fdiv fast float %2935, %2947
  %2951 = fdiv fast float %2936, %2948
  %2952 = fdiv fast float %2937, %2949
  br label %2953

; <label>:2953                                    ; preds = %2928, %2914
  %2954 = phi float [ %2950, %2928 ], [ %2924, %2914 ]
  %2955 = phi float [ %2951, %2928 ], [ %2925, %2914 ]
  %2956 = phi float [ %2952, %2928 ], [ %2926, %2914 ]
  %2957 = call float @dx.op.unary.f32(i32 7, float %2954)  ; Saturate(value)
  %2958 = call float @dx.op.unary.f32(i32 7, float %2955)  ; Saturate(value)
  %2959 = call float @dx.op.unary.f32(i32 7, float %2956)  ; Saturate(value)
  %2960 = call float @dx.op.dot3.f32(i32 55, float %2957, float %2958, float %2959, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2961 = fsub fast float %2957, %2960
  %2962 = fsub fast float %2958, %2960
  %2963 = fsub fast float %2959, %2960
  %2964 = fmul fast float %2961, %9
  %2965 = fmul fast float %2962, %9
  %2966 = fmul fast float %2963, %9
  %2967 = fadd fast float %2964, %2960
  %2968 = fadd fast float %2965, %2960
  %2969 = fadd fast float %2966, %2960
  %2970 = call float @dx.op.unary.f32(i32 7, float %2967)  ; Saturate(value)
  %2971 = call float @dx.op.unary.f32(i32 7, float %2968)  ; Saturate(value)
  %2972 = call float @dx.op.unary.f32(i32 7, float %2969)  ; Saturate(value)
  %2973 = fadd fast float %2970, 0xBFC70A3D80000000
  %2974 = fadd fast float %2971, 0xBFC70A3D80000000
  %2975 = fadd fast float %2972, 0xBFC70A3D80000000
  %2976 = fmul fast float %2973, %8
  %2977 = fmul fast float %2974, %8
  %2978 = fmul fast float %2975, %8
  %2979 = fadd fast float %2976, 0x3FC70A3D80000000
  %2980 = fadd fast float %2977, 0x3FC70A3D80000000
  %2981 = fadd fast float %2978, 0x3FC70A3D80000000
  %2982 = call float @dx.op.unary.f32(i32 7, float %2979)  ; Saturate(value)
  %2983 = call float @dx.op.unary.f32(i32 7, float %2980)  ; Saturate(value)
  %2984 = call float @dx.op.unary.f32(i32 7, float %2981)  ; Saturate(value)
  br label %2985

; <label>:2985                                    ; preds = %2953, %2788
  %2986 = phi float [ %2819, %2788 ], [ %2982, %2953 ]
  %2987 = phi float [ %2820, %2788 ], [ %2983, %2953 ]
  %2988 = phi float [ %2821, %2788 ], [ %2984, %2953 ]
  %2989 = add i32 %64, -1
  %2990 = call i32 @dx.op.binary.i32(i32 37, i32 %2989, i32 0)  ; IMax(a,b)
  %2991 = call i32 @dx.op.binary.i32(i32 37, i32 %2393, i32 0)  ; IMax(a,b)
  %2992 = call i32 @dx.op.binary.i32(i32 38, i32 %2990, i32 %60)  ; IMin(a,b)
  %2993 = call i32 @dx.op.binary.i32(i32 38, i32 %2991, i32 %61)  ; IMin(a,b)
  %2994 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2992, i32 %2993, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2995 = extractvalue %dx.types.ResRet.f32 %2994, 0
  %2996 = extractvalue %dx.types.ResRet.f32 %2994, 1
  %2997 = extractvalue %dx.types.ResRet.f32 %2994, 2
  %2998 = extractvalue %dx.types.ResRet.f32 %2994, 3
  %2999 = fcmp fast olt float %2998, 0.000000e+00
  br i1 %2999, label %3000, label %3034

; <label>:3000                                    ; preds = %2985
  %3001 = fcmp fast ogt float %2995, 0x3FA4B5DCC0000000
  %3002 = fcmp fast ogt float %2996, 0x3FA4B5DCC0000000
  %3003 = fcmp fast ogt float %2997, 0x3FA4B5DCC0000000
  %3004 = select i1 %3001, float 0.000000e+00, float 1.000000e+00
  %3005 = select i1 %3002, float 0.000000e+00, float 1.000000e+00
  %3006 = select i1 %3003, float 0.000000e+00, float 1.000000e+00
  %3007 = fmul fast float %2995, 0x3FB3D07220000000
  %3008 = fmul fast float %2996, 0x3FB3D07220000000
  %3009 = fmul fast float %2997, 0x3FB3D07220000000
  %3010 = fadd fast float %2995, 0x3FAC28F5C0000000
  %3011 = fadd fast float %2996, 0x3FAC28F5C0000000
  %3012 = fadd fast float %2997, 0x3FAC28F5C0000000
  %3013 = fmul fast float %3010, 0x3FEE54EDE0000000
  %3014 = fmul fast float %3011, 0x3FEE54EDE0000000
  %3015 = fmul fast float %3012, 0x3FEE54EDE0000000
  %3016 = call float @dx.op.unary.f32(i32 23, float %3013)  ; Log(value)
  %3017 = call float @dx.op.unary.f32(i32 23, float %3014)  ; Log(value)
  %3018 = call float @dx.op.unary.f32(i32 23, float %3015)  ; Log(value)
  %3019 = fmul fast float %3016, 0x4003333340000000
  %3020 = fmul fast float %3017, 0x4003333340000000
  %3021 = fmul fast float %3018, 0x4003333340000000
  %3022 = call float @dx.op.unary.f32(i32 21, float %3019)  ; Exp(value)
  %3023 = call float @dx.op.unary.f32(i32 21, float %3020)  ; Exp(value)
  %3024 = call float @dx.op.unary.f32(i32 21, float %3021)  ; Exp(value)
  %3025 = fsub fast float %3007, %3022
  %3026 = fsub fast float %3008, %3023
  %3027 = fsub fast float %3009, %3024
  %3028 = fmul fast float %3025, %3004
  %3029 = fmul fast float %3026, %3005
  %3030 = fmul fast float %3027, %3006
  %3031 = fadd fast float %3028, %3022
  %3032 = fadd fast float %3029, %3023
  %3033 = fadd fast float %3030, %3024
  br label %3197

; <label>:3034                                    ; preds = %2985
  %3035 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2992, i32 %2993, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3036 = extractvalue %dx.types.ResRet.f32 %3035, 0
  %3037 = fcmp fast ogt float %39, 5.000000e-01
  %3038 = fcmp fast olt float %3036, 1.000000e+00
  %3039 = and i1 %3037, %3038
  br i1 %3039, label %3040, label %3126

; <label>:3040                                    ; preds = %3034
  %3041 = sitofp i32 %2992 to float
  %3042 = sitofp i32 %2993 to float
  %3043 = fadd fast float %3041, 5.000000e-01
  %3044 = fadd fast float %3042, 5.000000e-01
  %3045 = fdiv fast float %3043, %46
  %3046 = fdiv fast float %3044, %47
  %3047 = fmul fast float %3045, 2.000000e+00
  %3048 = fmul fast float %3046, 2.000000e+00
  %3049 = fadd fast float %3047, -1.000000e+00
  %3050 = fsub fast float 1.000000e+00, %3048
  %3051 = fmul fast float %3049, %36
  %3052 = call float @dx.op.tertiary.f32(i32 46, float %3050, float %32, float %3051)  ; FMad(a,b,c)
  %3053 = call float @dx.op.tertiary.f32(i32 46, float %3036, float %28, float %3052)  ; FMad(a,b,c)
  %3054 = fadd fast float %3053, %24
  %3055 = call float @dx.op.unary.f32(i32 6, float %3054)  ; FAbs(value)
  %3056 = fcmp fast ogt float %3055, 0x3EB0C6F7A0000000
  br i1 %3056, label %3057, label %3126

; <label>:3057                                    ; preds = %3040
  %3058 = fmul fast float %3049, %35
  %3059 = call float @dx.op.tertiary.f32(i32 46, float %3050, float %31, float %3058)  ; FMad(a,b,c)
  %3060 = call float @dx.op.tertiary.f32(i32 46, float %3036, float %27, float %3059)  ; FMad(a,b,c)
  %3061 = fadd fast float %3060, %23
  %3062 = fmul fast float %3049, %34
  %3063 = call float @dx.op.tertiary.f32(i32 46, float %3050, float %30, float %3062)  ; FMad(a,b,c)
  %3064 = call float @dx.op.tertiary.f32(i32 46, float %3036, float %26, float %3063)  ; FMad(a,b,c)
  %3065 = fadd fast float %3064, %22
  %3066 = fmul fast float %3049, %33
  %3067 = call float @dx.op.tertiary.f32(i32 46, float %3050, float %29, float %3066)  ; FMad(a,b,c)
  %3068 = call float @dx.op.tertiary.f32(i32 46, float %3036, float %25, float %3067)  ; FMad(a,b,c)
  %3069 = fadd fast float %3068, %21
  %3070 = fdiv fast float %3069, %3054
  %3071 = fdiv fast float %3065, %3054
  %3072 = fdiv fast float %3061, %3054
  %3073 = fsub fast float %3070, %18
  %3074 = fsub fast float %3071, %19
  %3075 = fsub fast float %3072, %20
  %3076 = fmul fast float %3073, %3073
  %3077 = fmul fast float %3074, %3074
  %3078 = fadd fast float %3077, %3076
  %3079 = fmul fast float %3075, %3075
  %3080 = fadd fast float %3078, %3079
  %3081 = call float @dx.op.unary.f32(i32 24, float %3080)  ; Sqrt(value)
  %3082 = fsub fast float %3081, %10
  %3083 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3082)  ; FMax(a,b)
  %3084 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %3084, label %3085, label %3108

; <label>:3085                                    ; preds = %3057
  %3086 = call float @dx.op.unary.f32(i32 6, float %3074)  ; FAbs(value)
  %3087 = fmul fast float %3086, %12
  %3088 = fcmp fast olt float %3087, 0x3F50624DE0000000
  br i1 %3088, label %3089, label %3092

; <label>:3089                                    ; preds = %3085
  %3090 = fmul fast float %3087, 5.000000e-01
  %3091 = fsub fast float 1.000000e+00, %3090
  br label %3097

; <label>:3092                                    ; preds = %3085
  %3093 = fmul fast float %3087, 0xBFF7154760000000
  %3094 = call float @dx.op.unary.f32(i32 21, float %3093)  ; Exp(value)
  %3095 = fsub fast float 1.000000e+00, %3094
  %3096 = fdiv fast float %3095, %3087
  br label %3097

; <label>:3097                                    ; preds = %3092, %3089
  %3098 = phi float [ %3091, %3089 ], [ %3096, %3092 ]
  %3099 = call float @dx.op.binary.f32(i32 36, float %3071, float %19)  ; FMin(a,b)
  %3100 = fsub fast float %3099, %11
  %3101 = fmul fast float %12, %3100
  %3102 = fsub fast float -0.000000e+00, %3101
  %3103 = call float @dx.op.binary.f32(i32 35, float %3102, float -4.000000e+01)  ; FMax(a,b)
  %3104 = call float @dx.op.binary.f32(i32 36, float %3103, float 5.000000e+00)  ; FMin(a,b)
  %3105 = fmul fast float %3104, 0x3FF7154760000000
  %3106 = call float @dx.op.unary.f32(i32 21, float %3105)  ; Exp(value)
  %3107 = fmul fast float %3106, %3098
  br label %3108

; <label>:3108                                    ; preds = %3097, %3057
  %3109 = phi float [ %3107, %3097 ], [ 1.000000e+00, %3057 ]
  %3110 = fmul fast float %3083, %17
  %3111 = fmul fast float %3110, %3109
  %3112 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3111)  ; FMin(a,b)
  %3113 = fmul fast float %3112, 0xBFF7154760000000
  %3114 = call float @dx.op.unary.f32(i32 21, float %3113)  ; Exp(value)
  %3115 = fsub fast float 1.000000e+00, %3114
  %3116 = call float @dx.op.binary.f32(i32 36, float %13, float %3115)  ; FMin(a,b)
  %3117 = fsub fast float %14, %2995
  %3118 = fsub fast float %15, %2996
  %3119 = fsub fast float %16, %2997
  %3120 = fmul fast float %3116, %3117
  %3121 = fmul fast float %3116, %3118
  %3122 = fmul fast float %3116, %3119
  %3123 = fadd fast float %3120, %2995
  %3124 = fadd fast float %3121, %2996
  %3125 = fadd fast float %3122, %2997
  br label %3126

; <label>:3126                                    ; preds = %3108, %3040, %3034
  %3127 = phi float [ %3123, %3108 ], [ %2995, %3040 ], [ %2995, %3034 ]
  %3128 = phi float [ %3124, %3108 ], [ %2996, %3040 ], [ %2996, %3034 ]
  %3129 = phi float [ %3125, %3108 ], [ %2997, %3040 ], [ %2997, %3034 ]
  %3130 = fadd fast float %6, 1.000000e+00
  %3131 = fadd fast float %7, 1.000000e+00
  %3132 = fsub fast float 1.000000e+00, %6
  %3133 = fmul fast float %37, %3130
  %3134 = fmul fast float %37, %3131
  %3135 = fmul fast float %37, %3132
  %3136 = fmul fast float %3133, %3127
  %3137 = fmul fast float %3134, %3128
  %3138 = fmul fast float %3135, %3129
  %3139 = fcmp fast ult float %38, 5.000000e-01
  br i1 %3139, label %3165, label %3140

; <label>:3140                                    ; preds = %3126
  %3141 = fmul fast float %3136, 0x4004147AE0000000
  %3142 = fmul fast float %3137, 0x4004147AE0000000
  %3143 = fmul fast float %3138, 0x4004147AE0000000
  %3144 = fadd fast float %3141, 0x3F9EB851E0000000
  %3145 = fadd fast float %3142, 0x3F9EB851E0000000
  %3146 = fadd fast float %3143, 0x3F9EB851E0000000
  %3147 = fmul fast float %3144, %3136
  %3148 = fmul fast float %3145, %3137
  %3149 = fmul fast float %3146, %3138
  %3150 = fmul fast float %3136, 0x400370A3E0000000
  %3151 = fmul fast float %3137, 0x400370A3E0000000
  %3152 = fmul fast float %3138, 0x400370A3E0000000
  %3153 = fadd fast float %3150, 0x3FE2E147A0000000
  %3154 = fadd fast float %3151, 0x3FE2E147A0000000
  %3155 = fadd fast float %3152, 0x3FE2E147A0000000
  %3156 = fmul fast float %3153, %3136
  %3157 = fmul fast float %3154, %3137
  %3158 = fmul fast float %3155, %3138
  %3159 = fadd fast float %3156, 0x3FC1EB8520000000
  %3160 = fadd fast float %3157, 0x3FC1EB8520000000
  %3161 = fadd fast float %3158, 0x3FC1EB8520000000
  %3162 = fdiv fast float %3147, %3159
  %3163 = fdiv fast float %3148, %3160
  %3164 = fdiv fast float %3149, %3161
  br label %3165

; <label>:3165                                    ; preds = %3140, %3126
  %3166 = phi float [ %3162, %3140 ], [ %3136, %3126 ]
  %3167 = phi float [ %3163, %3140 ], [ %3137, %3126 ]
  %3168 = phi float [ %3164, %3140 ], [ %3138, %3126 ]
  %3169 = call float @dx.op.unary.f32(i32 7, float %3166)  ; Saturate(value)
  %3170 = call float @dx.op.unary.f32(i32 7, float %3167)  ; Saturate(value)
  %3171 = call float @dx.op.unary.f32(i32 7, float %3168)  ; Saturate(value)
  %3172 = call float @dx.op.dot3.f32(i32 55, float %3169, float %3170, float %3171, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3173 = fsub fast float %3169, %3172
  %3174 = fsub fast float %3170, %3172
  %3175 = fsub fast float %3171, %3172
  %3176 = fmul fast float %3173, %9
  %3177 = fmul fast float %3174, %9
  %3178 = fmul fast float %3175, %9
  %3179 = fadd fast float %3176, %3172
  %3180 = fadd fast float %3177, %3172
  %3181 = fadd fast float %3178, %3172
  %3182 = call float @dx.op.unary.f32(i32 7, float %3179)  ; Saturate(value)
  %3183 = call float @dx.op.unary.f32(i32 7, float %3180)  ; Saturate(value)
  %3184 = call float @dx.op.unary.f32(i32 7, float %3181)  ; Saturate(value)
  %3185 = fadd fast float %3182, 0xBFC70A3D80000000
  %3186 = fadd fast float %3183, 0xBFC70A3D80000000
  %3187 = fadd fast float %3184, 0xBFC70A3D80000000
  %3188 = fmul fast float %3185, %8
  %3189 = fmul fast float %3186, %8
  %3190 = fmul fast float %3187, %8
  %3191 = fadd fast float %3188, 0x3FC70A3D80000000
  %3192 = fadd fast float %3189, 0x3FC70A3D80000000
  %3193 = fadd fast float %3190, 0x3FC70A3D80000000
  %3194 = call float @dx.op.unary.f32(i32 7, float %3191)  ; Saturate(value)
  %3195 = call float @dx.op.unary.f32(i32 7, float %3192)  ; Saturate(value)
  %3196 = call float @dx.op.unary.f32(i32 7, float %3193)  ; Saturate(value)
  br label %3197

; <label>:3197                                    ; preds = %3165, %3000
  %3198 = phi float [ %3031, %3000 ], [ %3194, %3165 ]
  %3199 = phi float [ %3032, %3000 ], [ %3195, %3165 ]
  %3200 = phi float [ %3033, %3000 ], [ %3196, %3165 ]
  %3201 = add i32 %64, 1
  %3202 = call i32 @dx.op.binary.i32(i32 37, i32 %3201, i32 0)  ; IMax(a,b)
  %3203 = call i32 @dx.op.binary.i32(i32 38, i32 %3202, i32 %60)  ; IMin(a,b)
  %3204 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3203, i32 %2993, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3205 = extractvalue %dx.types.ResRet.f32 %3204, 0
  %3206 = extractvalue %dx.types.ResRet.f32 %3204, 1
  %3207 = extractvalue %dx.types.ResRet.f32 %3204, 2
  %3208 = extractvalue %dx.types.ResRet.f32 %3204, 3
  %3209 = fcmp fast olt float %3208, 0.000000e+00
  br i1 %3209, label %3210, label %3244

; <label>:3210                                    ; preds = %3197
  %3211 = fcmp fast ogt float %3205, 0x3FA4B5DCC0000000
  %3212 = fcmp fast ogt float %3206, 0x3FA4B5DCC0000000
  %3213 = fcmp fast ogt float %3207, 0x3FA4B5DCC0000000
  %3214 = select i1 %3211, float 0.000000e+00, float 1.000000e+00
  %3215 = select i1 %3212, float 0.000000e+00, float 1.000000e+00
  %3216 = select i1 %3213, float 0.000000e+00, float 1.000000e+00
  %3217 = fmul fast float %3205, 0x3FB3D07220000000
  %3218 = fmul fast float %3206, 0x3FB3D07220000000
  %3219 = fmul fast float %3207, 0x3FB3D07220000000
  %3220 = fadd fast float %3205, 0x3FAC28F5C0000000
  %3221 = fadd fast float %3206, 0x3FAC28F5C0000000
  %3222 = fadd fast float %3207, 0x3FAC28F5C0000000
  %3223 = fmul fast float %3220, 0x3FEE54EDE0000000
  %3224 = fmul fast float %3221, 0x3FEE54EDE0000000
  %3225 = fmul fast float %3222, 0x3FEE54EDE0000000
  %3226 = call float @dx.op.unary.f32(i32 23, float %3223)  ; Log(value)
  %3227 = call float @dx.op.unary.f32(i32 23, float %3224)  ; Log(value)
  %3228 = call float @dx.op.unary.f32(i32 23, float %3225)  ; Log(value)
  %3229 = fmul fast float %3226, 0x4003333340000000
  %3230 = fmul fast float %3227, 0x4003333340000000
  %3231 = fmul fast float %3228, 0x4003333340000000
  %3232 = call float @dx.op.unary.f32(i32 21, float %3229)  ; Exp(value)
  %3233 = call float @dx.op.unary.f32(i32 21, float %3230)  ; Exp(value)
  %3234 = call float @dx.op.unary.f32(i32 21, float %3231)  ; Exp(value)
  %3235 = fsub fast float %3217, %3232
  %3236 = fsub fast float %3218, %3233
  %3237 = fsub fast float %3219, %3234
  %3238 = fmul fast float %3235, %3214
  %3239 = fmul fast float %3236, %3215
  %3240 = fmul fast float %3237, %3216
  %3241 = fadd fast float %3238, %3232
  %3242 = fadd fast float %3239, %3233
  %3243 = fadd fast float %3240, %3234
  br label %3407

; <label>:3244                                    ; preds = %3197
  %3245 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3203, i32 %2993, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3246 = extractvalue %dx.types.ResRet.f32 %3245, 0
  %3247 = fcmp fast ogt float %39, 5.000000e-01
  %3248 = fcmp fast olt float %3246, 1.000000e+00
  %3249 = and i1 %3247, %3248
  br i1 %3249, label %3250, label %3336

; <label>:3250                                    ; preds = %3244
  %3251 = sitofp i32 %3203 to float
  %3252 = sitofp i32 %2993 to float
  %3253 = fadd fast float %3251, 5.000000e-01
  %3254 = fadd fast float %3252, 5.000000e-01
  %3255 = fdiv fast float %3253, %46
  %3256 = fdiv fast float %3254, %47
  %3257 = fmul fast float %3255, 2.000000e+00
  %3258 = fmul fast float %3256, 2.000000e+00
  %3259 = fadd fast float %3257, -1.000000e+00
  %3260 = fsub fast float 1.000000e+00, %3258
  %3261 = fmul fast float %3259, %36
  %3262 = call float @dx.op.tertiary.f32(i32 46, float %3260, float %32, float %3261)  ; FMad(a,b,c)
  %3263 = call float @dx.op.tertiary.f32(i32 46, float %3246, float %28, float %3262)  ; FMad(a,b,c)
  %3264 = fadd fast float %3263, %24
  %3265 = call float @dx.op.unary.f32(i32 6, float %3264)  ; FAbs(value)
  %3266 = fcmp fast ogt float %3265, 0x3EB0C6F7A0000000
  br i1 %3266, label %3267, label %3336

; <label>:3267                                    ; preds = %3250
  %3268 = fmul fast float %3259, %35
  %3269 = call float @dx.op.tertiary.f32(i32 46, float %3260, float %31, float %3268)  ; FMad(a,b,c)
  %3270 = call float @dx.op.tertiary.f32(i32 46, float %3246, float %27, float %3269)  ; FMad(a,b,c)
  %3271 = fadd fast float %3270, %23
  %3272 = fmul fast float %3259, %34
  %3273 = call float @dx.op.tertiary.f32(i32 46, float %3260, float %30, float %3272)  ; FMad(a,b,c)
  %3274 = call float @dx.op.tertiary.f32(i32 46, float %3246, float %26, float %3273)  ; FMad(a,b,c)
  %3275 = fadd fast float %3274, %22
  %3276 = fmul fast float %3259, %33
  %3277 = call float @dx.op.tertiary.f32(i32 46, float %3260, float %29, float %3276)  ; FMad(a,b,c)
  %3278 = call float @dx.op.tertiary.f32(i32 46, float %3246, float %25, float %3277)  ; FMad(a,b,c)
  %3279 = fadd fast float %3278, %21
  %3280 = fdiv fast float %3279, %3264
  %3281 = fdiv fast float %3275, %3264
  %3282 = fdiv fast float %3271, %3264
  %3283 = fsub fast float %3280, %18
  %3284 = fsub fast float %3281, %19
  %3285 = fsub fast float %3282, %20
  %3286 = fmul fast float %3283, %3283
  %3287 = fmul fast float %3284, %3284
  %3288 = fadd fast float %3287, %3286
  %3289 = fmul fast float %3285, %3285
  %3290 = fadd fast float %3288, %3289
  %3291 = call float @dx.op.unary.f32(i32 24, float %3290)  ; Sqrt(value)
  %3292 = fsub fast float %3291, %10
  %3293 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3292)  ; FMax(a,b)
  %3294 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %3294, label %3295, label %3318

; <label>:3295                                    ; preds = %3267
  %3296 = call float @dx.op.unary.f32(i32 6, float %3284)  ; FAbs(value)
  %3297 = fmul fast float %3296, %12
  %3298 = fcmp fast olt float %3297, 0x3F50624DE0000000
  br i1 %3298, label %3299, label %3302

; <label>:3299                                    ; preds = %3295
  %3300 = fmul fast float %3297, 5.000000e-01
  %3301 = fsub fast float 1.000000e+00, %3300
  br label %3307

; <label>:3302                                    ; preds = %3295
  %3303 = fmul fast float %3297, 0xBFF7154760000000
  %3304 = call float @dx.op.unary.f32(i32 21, float %3303)  ; Exp(value)
  %3305 = fsub fast float 1.000000e+00, %3304
  %3306 = fdiv fast float %3305, %3297
  br label %3307

; <label>:3307                                    ; preds = %3302, %3299
  %3308 = phi float [ %3301, %3299 ], [ %3306, %3302 ]
  %3309 = call float @dx.op.binary.f32(i32 36, float %3281, float %19)  ; FMin(a,b)
  %3310 = fsub fast float %3309, %11
  %3311 = fmul fast float %12, %3310
  %3312 = fsub fast float -0.000000e+00, %3311
  %3313 = call float @dx.op.binary.f32(i32 35, float %3312, float -4.000000e+01)  ; FMax(a,b)
  %3314 = call float @dx.op.binary.f32(i32 36, float %3313, float 5.000000e+00)  ; FMin(a,b)
  %3315 = fmul fast float %3314, 0x3FF7154760000000
  %3316 = call float @dx.op.unary.f32(i32 21, float %3315)  ; Exp(value)
  %3317 = fmul fast float %3316, %3308
  br label %3318

; <label>:3318                                    ; preds = %3307, %3267
  %3319 = phi float [ %3317, %3307 ], [ 1.000000e+00, %3267 ]
  %3320 = fmul fast float %3293, %17
  %3321 = fmul fast float %3320, %3319
  %3322 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3321)  ; FMin(a,b)
  %3323 = fmul fast float %3322, 0xBFF7154760000000
  %3324 = call float @dx.op.unary.f32(i32 21, float %3323)  ; Exp(value)
  %3325 = fsub fast float 1.000000e+00, %3324
  %3326 = call float @dx.op.binary.f32(i32 36, float %13, float %3325)  ; FMin(a,b)
  %3327 = fsub fast float %14, %3205
  %3328 = fsub fast float %15, %3206
  %3329 = fsub fast float %16, %3207
  %3330 = fmul fast float %3326, %3327
  %3331 = fmul fast float %3326, %3328
  %3332 = fmul fast float %3326, %3329
  %3333 = fadd fast float %3330, %3205
  %3334 = fadd fast float %3331, %3206
  %3335 = fadd fast float %3332, %3207
  br label %3336

; <label>:3336                                    ; preds = %3318, %3250, %3244
  %3337 = phi float [ %3333, %3318 ], [ %3205, %3250 ], [ %3205, %3244 ]
  %3338 = phi float [ %3334, %3318 ], [ %3206, %3250 ], [ %3206, %3244 ]
  %3339 = phi float [ %3335, %3318 ], [ %3207, %3250 ], [ %3207, %3244 ]
  %3340 = fadd fast float %6, 1.000000e+00
  %3341 = fadd fast float %7, 1.000000e+00
  %3342 = fsub fast float 1.000000e+00, %6
  %3343 = fmul fast float %37, %3340
  %3344 = fmul fast float %37, %3341
  %3345 = fmul fast float %37, %3342
  %3346 = fmul fast float %3343, %3337
  %3347 = fmul fast float %3344, %3338
  %3348 = fmul fast float %3345, %3339
  %3349 = fcmp fast ult float %38, 5.000000e-01
  br i1 %3349, label %3375, label %3350

; <label>:3350                                    ; preds = %3336
  %3351 = fmul fast float %3346, 0x4004147AE0000000
  %3352 = fmul fast float %3347, 0x4004147AE0000000
  %3353 = fmul fast float %3348, 0x4004147AE0000000
  %3354 = fadd fast float %3351, 0x3F9EB851E0000000
  %3355 = fadd fast float %3352, 0x3F9EB851E0000000
  %3356 = fadd fast float %3353, 0x3F9EB851E0000000
  %3357 = fmul fast float %3354, %3346
  %3358 = fmul fast float %3355, %3347
  %3359 = fmul fast float %3356, %3348
  %3360 = fmul fast float %3346, 0x400370A3E0000000
  %3361 = fmul fast float %3347, 0x400370A3E0000000
  %3362 = fmul fast float %3348, 0x400370A3E0000000
  %3363 = fadd fast float %3360, 0x3FE2E147A0000000
  %3364 = fadd fast float %3361, 0x3FE2E147A0000000
  %3365 = fadd fast float %3362, 0x3FE2E147A0000000
  %3366 = fmul fast float %3363, %3346
  %3367 = fmul fast float %3364, %3347
  %3368 = fmul fast float %3365, %3348
  %3369 = fadd fast float %3366, 0x3FC1EB8520000000
  %3370 = fadd fast float %3367, 0x3FC1EB8520000000
  %3371 = fadd fast float %3368, 0x3FC1EB8520000000
  %3372 = fdiv fast float %3357, %3369
  %3373 = fdiv fast float %3358, %3370
  %3374 = fdiv fast float %3359, %3371
  br label %3375

; <label>:3375                                    ; preds = %3350, %3336
  %3376 = phi float [ %3372, %3350 ], [ %3346, %3336 ]
  %3377 = phi float [ %3373, %3350 ], [ %3347, %3336 ]
  %3378 = phi float [ %3374, %3350 ], [ %3348, %3336 ]
  %3379 = call float @dx.op.unary.f32(i32 7, float %3376)  ; Saturate(value)
  %3380 = call float @dx.op.unary.f32(i32 7, float %3377)  ; Saturate(value)
  %3381 = call float @dx.op.unary.f32(i32 7, float %3378)  ; Saturate(value)
  %3382 = call float @dx.op.dot3.f32(i32 55, float %3379, float %3380, float %3381, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3383 = fsub fast float %3379, %3382
  %3384 = fsub fast float %3380, %3382
  %3385 = fsub fast float %3381, %3382
  %3386 = fmul fast float %3383, %9
  %3387 = fmul fast float %3384, %9
  %3388 = fmul fast float %3385, %9
  %3389 = fadd fast float %3386, %3382
  %3390 = fadd fast float %3387, %3382
  %3391 = fadd fast float %3388, %3382
  %3392 = call float @dx.op.unary.f32(i32 7, float %3389)  ; Saturate(value)
  %3393 = call float @dx.op.unary.f32(i32 7, float %3390)  ; Saturate(value)
  %3394 = call float @dx.op.unary.f32(i32 7, float %3391)  ; Saturate(value)
  %3395 = fadd fast float %3392, 0xBFC70A3D80000000
  %3396 = fadd fast float %3393, 0xBFC70A3D80000000
  %3397 = fadd fast float %3394, 0xBFC70A3D80000000
  %3398 = fmul fast float %3395, %8
  %3399 = fmul fast float %3396, %8
  %3400 = fmul fast float %3397, %8
  %3401 = fadd fast float %3398, 0x3FC70A3D80000000
  %3402 = fadd fast float %3399, 0x3FC70A3D80000000
  %3403 = fadd fast float %3400, 0x3FC70A3D80000000
  %3404 = call float @dx.op.unary.f32(i32 7, float %3401)  ; Saturate(value)
  %3405 = call float @dx.op.unary.f32(i32 7, float %3402)  ; Saturate(value)
  %3406 = call float @dx.op.unary.f32(i32 7, float %3403)  ; Saturate(value)
  br label %3407

; <label>:3407                                    ; preds = %3375, %3210
  %3408 = phi float [ %3241, %3210 ], [ %3404, %3375 ]
  %3409 = phi float [ %3242, %3210 ], [ %3405, %3375 ]
  %3410 = phi float [ %3243, %3210 ], [ %3406, %3375 ]
  %3411 = call float @dx.op.binary.f32(i32 36, float %3198, float %3408)  ; FMin(a,b)
  %3412 = call float @dx.op.binary.f32(i32 36, float %3199, float %3409)  ; FMin(a,b)
  %3413 = call float @dx.op.binary.f32(i32 36, float %3200, float %3410)  ; FMin(a,b)
  %3414 = call float @dx.op.binary.f32(i32 36, float %2776, float %2986)  ; FMin(a,b)
  %3415 = call float @dx.op.binary.f32(i32 36, float %2777, float %2987)  ; FMin(a,b)
  %3416 = call float @dx.op.binary.f32(i32 36, float %2778, float %2988)  ; FMin(a,b)
  %3417 = call float @dx.op.binary.f32(i32 36, float %3414, float %3411)  ; FMin(a,b)
  %3418 = call float @dx.op.binary.f32(i32 36, float %3415, float %3412)  ; FMin(a,b)
  %3419 = call float @dx.op.binary.f32(i32 36, float %3416, float %3413)  ; FMin(a,b)
  %3420 = call float @dx.op.binary.f32(i32 36, float %2562, float %3417)  ; FMin(a,b)
  %3421 = call float @dx.op.binary.f32(i32 36, float %2563, float %3418)  ; FMin(a,b)
  %3422 = call float @dx.op.binary.f32(i32 36, float %2564, float %3419)  ; FMin(a,b)
  %3423 = call float @dx.op.binary.f32(i32 35, float %3198, float %3408)  ; FMax(a,b)
  %3424 = call float @dx.op.binary.f32(i32 35, float %3199, float %3409)  ; FMax(a,b)
  %3425 = call float @dx.op.binary.f32(i32 35, float %3200, float %3410)  ; FMax(a,b)
  %3426 = call float @dx.op.binary.f32(i32 35, float %2776, float %2986)  ; FMax(a,b)
  %3427 = call float @dx.op.binary.f32(i32 35, float %2777, float %2987)  ; FMax(a,b)
  %3428 = call float @dx.op.binary.f32(i32 35, float %2778, float %2988)  ; FMax(a,b)
  %3429 = call float @dx.op.binary.f32(i32 35, float %3426, float %3423)  ; FMax(a,b)
  %3430 = call float @dx.op.binary.f32(i32 35, float %3427, float %3424)  ; FMax(a,b)
  %3431 = call float @dx.op.binary.f32(i32 35, float %3428, float %3425)  ; FMax(a,b)
  %3432 = call float @dx.op.binary.f32(i32 35, float %2562, float %3429)  ; FMax(a,b)
  %3433 = call float @dx.op.binary.f32(i32 35, float %2563, float %3430)  ; FMax(a,b)
  %3434 = call float @dx.op.binary.f32(i32 35, float %2564, float %3431)  ; FMax(a,b)
  %3435 = fsub fast float %3432, %3420
  %3436 = fsub fast float %3433, %3421
  %3437 = fsub fast float %3434, %3422
  %3438 = call float @dx.op.unary.f32(i32 6, float %3435)  ; FAbs(value)
  %3439 = call float @dx.op.unary.f32(i32 6, float %3436)  ; FAbs(value)
  %3440 = call float @dx.op.unary.f32(i32 6, float %3437)  ; FAbs(value)
  %3441 = call float @dx.op.binary.f32(i32 35, float %3439, float %3440)  ; FMax(a,b)
  %3442 = call float @dx.op.binary.f32(i32 35, float %3438, float %3441)  ; FMax(a,b)
  %3443 = call float @dx.op.binary.f32(i32 35, float %3433, float %3434)  ; FMax(a,b)
  %3444 = call float @dx.op.binary.f32(i32 35, float %3432, float %3443)  ; FMax(a,b)
  %3445 = fmul fast float %3444, 1.250000e-01
  %3446 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %3445)  ; FMax(a,b)
  %3447 = fcmp fast ogt float %3442, %3446
  br i1 %3447, label %3448, label %3510

; <label>:3448                                    ; preds = %3407
  %3449 = fsub fast float %2776, %2986
  %3450 = fsub fast float %2777, %2987
  %3451 = fsub fast float %2778, %2988
  %3452 = call float @dx.op.unary.f32(i32 6, float %3449)  ; FAbs(value)
  %3453 = call float @dx.op.unary.f32(i32 6, float %3450)  ; FAbs(value)
  %3454 = call float @dx.op.unary.f32(i32 6, float %3451)  ; FAbs(value)
  %3455 = call float @dx.op.binary.f32(i32 35, float %3453, float %3454)  ; FMax(a,b)
  %3456 = call float @dx.op.binary.f32(i32 35, float %3452, float %3455)  ; FMax(a,b)
  %3457 = fsub fast float %3198, %3408
  %3458 = fsub fast float %3199, %3409
  %3459 = fsub fast float %3200, %3410
  %3460 = call float @dx.op.unary.f32(i32 6, float %3457)  ; FAbs(value)
  %3461 = call float @dx.op.unary.f32(i32 6, float %3458)  ; FAbs(value)
  %3462 = call float @dx.op.unary.f32(i32 6, float %3459)  ; FAbs(value)
  %3463 = call float @dx.op.binary.f32(i32 35, float %3461, float %3462)  ; FMax(a,b)
  %3464 = call float @dx.op.binary.f32(i32 35, float %3460, float %3463)  ; FMax(a,b)
  %3465 = fcmp fast olt float %3456, %3464
  %3466 = select i1 %3465, float %2776, float %3198
  %3467 = select i1 %3465, float %2777, float %3199
  %3468 = select i1 %3465, float %2778, float %3200
  %3469 = select i1 %3465, float %2986, float %3408
  %3470 = select i1 %3465, float %2987, float %3409
  %3471 = select i1 %3465, float %2988, float %3410
  %3472 = fsub fast float %2562, %3469
  %3473 = fsub fast float %2563, %3470
  %3474 = fsub fast float %2564, %3471
  %3475 = fsub fast float %2562, %3466
  %3476 = fsub fast float %2563, %3467
  %3477 = fsub fast float %2564, %3468
  %3478 = call float @dx.op.dot3.f32(i32 55, float %3475, float %3476, float %3477, float %3472, float %3473, float %3474)  ; Dot3(ax,ay,az,bx,by,bz)
  %3479 = fcmp fast ogt float %3478, 0.000000e+00
  br i1 %3479, label %3480, label %3491

; <label>:3480                                    ; preds = %3448
  %3481 = fsub fast float %3466, %3469
  %3482 = fsub fast float %3467, %3470
  %3483 = fsub fast float %3468, %3471
  %3484 = call float @dx.op.unary.f32(i32 6, float %3481)  ; FAbs(value)
  %3485 = call float @dx.op.unary.f32(i32 6, float %3482)  ; FAbs(value)
  %3486 = call float @dx.op.unary.f32(i32 6, float %3483)  ; FAbs(value)
  %3487 = call float @dx.op.binary.f32(i32 35, float %3485, float %3486)  ; FMax(a,b)
  %3488 = call float @dx.op.binary.f32(i32 35, float %3484, float %3487)  ; FMax(a,b)
  %3489 = fmul fast float %3442, 2.500000e-01
  %3490 = fcmp fast olt float %3488, %3489
  br label %3491

; <label>:3491                                    ; preds = %3480, %3448
  %3492 = phi i1 [ false, %3448 ], [ %3490, %3480 ]
  %3493 = select i1 %3492, float 5.000000e-01, float 1.000000e+00
  %3494 = fmul fast float %3493, %3
  %3495 = fadd fast float %3466, %3469
  %3496 = fadd fast float %3467, %3470
  %3497 = fadd fast float %3468, %3471
  %3498 = fmul fast float %3495, 5.000000e-01
  %3499 = fmul fast float %3496, 5.000000e-01
  %3500 = fmul fast float %3497, 5.000000e-01
  %3501 = fsub fast float %3498, %2562
  %3502 = fsub fast float %3499, %2563
  %3503 = fsub fast float %3500, %2564
  %3504 = fmul fast float %3494, %3501
  %3505 = fmul fast float %3494, %3502
  %3506 = fmul fast float %3494, %3503
  %3507 = fadd fast float %3504, %2562
  %3508 = fadd fast float %3505, %2563
  %3509 = fadd fast float %3506, %2564
  br label %3510

; <label>:3510                                    ; preds = %3491, %3407, %2533
  %3511 = phi float [ %3507, %3491 ], [ %2562, %3407 ], [ %2562, %2533 ]
  %3512 = phi float [ %3508, %3491 ], [ %2563, %3407 ], [ %2563, %2533 ]
  %3513 = phi float [ %3509, %3491 ], [ %2564, %3407 ], [ %2564, %2533 ]
  %3514 = fcmp fast ogt float %3511, 0x3F69A5C380000000
  %3515 = fcmp fast ogt float %3512, 0x3F69A5C380000000
  %3516 = fcmp fast ogt float %3513, 0x3F69A5C380000000
  %3517 = select i1 %3514, float 0.000000e+00, float 1.000000e+00
  %3518 = select i1 %3515, float 0.000000e+00, float 1.000000e+00
  %3519 = select i1 %3516, float 0.000000e+00, float 1.000000e+00
  %3520 = fmul fast float %3511, 0x4029D70A40000000
  %3521 = fmul fast float %3512, 0x4029D70A40000000
  %3522 = fmul fast float %3513, 0x4029D70A40000000
  %3523 = call float @dx.op.binary.f32(i32 35, float %3511, float 0.000000e+00)  ; FMax(a,b)
  %3524 = call float @dx.op.binary.f32(i32 35, float %3512, float 0.000000e+00)  ; FMax(a,b)
  %3525 = call float @dx.op.binary.f32(i32 35, float %3513, float 0.000000e+00)  ; FMax(a,b)
  %3526 = call float @dx.op.unary.f32(i32 23, float %3523)  ; Log(value)
  %3527 = call float @dx.op.unary.f32(i32 23, float %3524)  ; Log(value)
  %3528 = call float @dx.op.unary.f32(i32 23, float %3525)  ; Log(value)
  %3529 = fmul fast float %3526, 0x3FDAAAAAA0000000
  %3530 = fmul fast float %3527, 0x3FDAAAAAA0000000
  %3531 = fmul fast float %3528, 0x3FDAAAAAA0000000
  %3532 = call float @dx.op.unary.f32(i32 21, float %3529)  ; Exp(value)
  %3533 = call float @dx.op.unary.f32(i32 21, float %3530)  ; Exp(value)
  %3534 = call float @dx.op.unary.f32(i32 21, float %3531)  ; Exp(value)
  %3535 = fmul fast float %3532, 0x3FF0E147A0000000
  %3536 = fmul fast float %3533, 0x3FF0E147A0000000
  %3537 = fmul fast float %3534, 0x3FF0E147A0000000
  %3538 = fadd fast float %3535, 0xBFAC28F5C0000000
  %3539 = fadd fast float %3536, 0xBFAC28F5C0000000
  %3540 = fadd fast float %3537, 0xBFAC28F5C0000000
  %3541 = fsub fast float %3520, %3538
  %3542 = fsub fast float %3521, %3539
  %3543 = fsub fast float %3522, %3540
  %3544 = fmul fast float %3541, %3517
  %3545 = fmul fast float %3542, %3518
  %3546 = fmul fast float %3543, %3519
  %3547 = fadd fast float %3544, %3538
  %3548 = fadd fast float %3545, %3539
  %3549 = fadd fast float %3546, %3540
  br label %3550

; <label>:3550                                    ; preds = %3510, %2400
  %3551 = phi float [ %2395, %2400 ], [ %3547, %3510 ]
  %3552 = phi float [ %2396, %2400 ], [ %3548, %3510 ]
  %3553 = phi float [ %2397, %2400 ], [ %3549, %3510 ]
  %3554 = phi float [ %2401, %2400 ], [ %2398, %3510 ]
  %3555 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1229, i32 %2393, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3556 = extractvalue %dx.types.ResRet.f32 %3555, 0
  %3557 = extractvalue %dx.types.ResRet.f32 %3555, 1
  %3558 = extractvalue %dx.types.ResRet.f32 %3555, 2
  %3559 = extractvalue %dx.types.ResRet.f32 %3555, 3
  %3560 = fcmp fast olt float %3559, 0.000000e+00
  br i1 %3560, label %3561, label %3563

; <label>:3561                                    ; preds = %3550
  %3562 = fsub fast float -1.000000e+00, %3559
  br label %4711

; <label>:3563                                    ; preds = %3550
  %3564 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1229, i32 %2393, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3565 = extractvalue %dx.types.ResRet.f32 %3564, 0
  %3566 = fcmp fast ogt float %39, 5.000000e-01
  %3567 = fcmp fast olt float %3565, 1.000000e+00
  %3568 = and i1 %3566, %3567
  br i1 %3568, label %3569, label %3655

; <label>:3569                                    ; preds = %3563
  %3570 = sitofp i32 %1229 to float
  %3571 = sitofp i32 %2393 to float
  %3572 = fadd fast float %3570, 5.000000e-01
  %3573 = fadd fast float %3571, 5.000000e-01
  %3574 = fdiv fast float %3572, %46
  %3575 = fdiv fast float %3573, %47
  %3576 = fmul fast float %3574, 2.000000e+00
  %3577 = fmul fast float %3575, 2.000000e+00
  %3578 = fadd fast float %3576, -1.000000e+00
  %3579 = fsub fast float 1.000000e+00, %3577
  %3580 = fmul fast float %3578, %36
  %3581 = call float @dx.op.tertiary.f32(i32 46, float %3579, float %32, float %3580)  ; FMad(a,b,c)
  %3582 = call float @dx.op.tertiary.f32(i32 46, float %3565, float %28, float %3581)  ; FMad(a,b,c)
  %3583 = fadd fast float %3582, %24
  %3584 = call float @dx.op.unary.f32(i32 6, float %3583)  ; FAbs(value)
  %3585 = fcmp fast ogt float %3584, 0x3EB0C6F7A0000000
  br i1 %3585, label %3586, label %3655

; <label>:3586                                    ; preds = %3569
  %3587 = fmul fast float %3578, %35
  %3588 = call float @dx.op.tertiary.f32(i32 46, float %3579, float %31, float %3587)  ; FMad(a,b,c)
  %3589 = call float @dx.op.tertiary.f32(i32 46, float %3565, float %27, float %3588)  ; FMad(a,b,c)
  %3590 = fadd fast float %3589, %23
  %3591 = fmul fast float %3578, %34
  %3592 = call float @dx.op.tertiary.f32(i32 46, float %3579, float %30, float %3591)  ; FMad(a,b,c)
  %3593 = call float @dx.op.tertiary.f32(i32 46, float %3565, float %26, float %3592)  ; FMad(a,b,c)
  %3594 = fadd fast float %3593, %22
  %3595 = fmul fast float %3578, %33
  %3596 = call float @dx.op.tertiary.f32(i32 46, float %3579, float %29, float %3595)  ; FMad(a,b,c)
  %3597 = call float @dx.op.tertiary.f32(i32 46, float %3565, float %25, float %3596)  ; FMad(a,b,c)
  %3598 = fadd fast float %3597, %21
  %3599 = fdiv fast float %3598, %3583
  %3600 = fdiv fast float %3594, %3583
  %3601 = fdiv fast float %3590, %3583
  %3602 = fsub fast float %3599, %18
  %3603 = fsub fast float %3600, %19
  %3604 = fsub fast float %3601, %20
  %3605 = fmul fast float %3602, %3602
  %3606 = fmul fast float %3603, %3603
  %3607 = fadd fast float %3606, %3605
  %3608 = fmul fast float %3604, %3604
  %3609 = fadd fast float %3607, %3608
  %3610 = call float @dx.op.unary.f32(i32 24, float %3609)  ; Sqrt(value)
  %3611 = fsub fast float %3610, %10
  %3612 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3611)  ; FMax(a,b)
  %3613 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %3613, label %3614, label %3637

; <label>:3614                                    ; preds = %3586
  %3615 = call float @dx.op.unary.f32(i32 6, float %3603)  ; FAbs(value)
  %3616 = fmul fast float %3615, %12
  %3617 = fcmp fast olt float %3616, 0x3F50624DE0000000
  br i1 %3617, label %3618, label %3621

; <label>:3618                                    ; preds = %3614
  %3619 = fmul fast float %3616, 5.000000e-01
  %3620 = fsub fast float 1.000000e+00, %3619
  br label %3626

; <label>:3621                                    ; preds = %3614
  %3622 = fmul fast float %3616, 0xBFF7154760000000
  %3623 = call float @dx.op.unary.f32(i32 21, float %3622)  ; Exp(value)
  %3624 = fsub fast float 1.000000e+00, %3623
  %3625 = fdiv fast float %3624, %3616
  br label %3626

; <label>:3626                                    ; preds = %3621, %3618
  %3627 = phi float [ %3620, %3618 ], [ %3625, %3621 ]
  %3628 = call float @dx.op.binary.f32(i32 36, float %3600, float %19)  ; FMin(a,b)
  %3629 = fsub fast float %3628, %11
  %3630 = fmul fast float %12, %3629
  %3631 = fsub fast float -0.000000e+00, %3630
  %3632 = call float @dx.op.binary.f32(i32 35, float %3631, float -4.000000e+01)  ; FMax(a,b)
  %3633 = call float @dx.op.binary.f32(i32 36, float %3632, float 5.000000e+00)  ; FMin(a,b)
  %3634 = fmul fast float %3633, 0x3FF7154760000000
  %3635 = call float @dx.op.unary.f32(i32 21, float %3634)  ; Exp(value)
  %3636 = fmul fast float %3635, %3627
  br label %3637

; <label>:3637                                    ; preds = %3626, %3586
  %3638 = phi float [ %3636, %3626 ], [ 1.000000e+00, %3586 ]
  %3639 = fmul fast float %3612, %17
  %3640 = fmul fast float %3639, %3638
  %3641 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3640)  ; FMin(a,b)
  %3642 = fmul fast float %3641, 0xBFF7154760000000
  %3643 = call float @dx.op.unary.f32(i32 21, float %3642)  ; Exp(value)
  %3644 = fsub fast float 1.000000e+00, %3643
  %3645 = call float @dx.op.binary.f32(i32 36, float %13, float %3644)  ; FMin(a,b)
  %3646 = fsub fast float %14, %3556
  %3647 = fsub fast float %15, %3557
  %3648 = fsub fast float %16, %3558
  %3649 = fmul fast float %3645, %3646
  %3650 = fmul fast float %3645, %3647
  %3651 = fmul fast float %3645, %3648
  %3652 = fadd fast float %3649, %3556
  %3653 = fadd fast float %3650, %3557
  %3654 = fadd fast float %3651, %3558
  br label %3655

; <label>:3655                                    ; preds = %3637, %3569, %3563
  %3656 = phi float [ %3652, %3637 ], [ %3556, %3569 ], [ %3556, %3563 ]
  %3657 = phi float [ %3653, %3637 ], [ %3557, %3569 ], [ %3557, %3563 ]
  %3658 = phi float [ %3654, %3637 ], [ %3558, %3569 ], [ %3558, %3563 ]
  %3659 = fadd fast float %6, 1.000000e+00
  %3660 = fadd fast float %7, 1.000000e+00
  %3661 = fsub fast float 1.000000e+00, %6
  %3662 = fmul fast float %37, %3659
  %3663 = fmul fast float %37, %3660
  %3664 = fmul fast float %37, %3661
  %3665 = fmul fast float %3662, %3656
  %3666 = fmul fast float %3663, %3657
  %3667 = fmul fast float %3664, %3658
  %3668 = fcmp fast ult float %38, 5.000000e-01
  br i1 %3668, label %3694, label %3669

; <label>:3669                                    ; preds = %3655
  %3670 = fmul fast float %3665, 0x4004147AE0000000
  %3671 = fmul fast float %3666, 0x4004147AE0000000
  %3672 = fmul fast float %3667, 0x4004147AE0000000
  %3673 = fadd fast float %3670, 0x3F9EB851E0000000
  %3674 = fadd fast float %3671, 0x3F9EB851E0000000
  %3675 = fadd fast float %3672, 0x3F9EB851E0000000
  %3676 = fmul fast float %3673, %3665
  %3677 = fmul fast float %3674, %3666
  %3678 = fmul fast float %3675, %3667
  %3679 = fmul fast float %3665, 0x400370A3E0000000
  %3680 = fmul fast float %3666, 0x400370A3E0000000
  %3681 = fmul fast float %3667, 0x400370A3E0000000
  %3682 = fadd fast float %3679, 0x3FE2E147A0000000
  %3683 = fadd fast float %3680, 0x3FE2E147A0000000
  %3684 = fadd fast float %3681, 0x3FE2E147A0000000
  %3685 = fmul fast float %3682, %3665
  %3686 = fmul fast float %3683, %3666
  %3687 = fmul fast float %3684, %3667
  %3688 = fadd fast float %3685, 0x3FC1EB8520000000
  %3689 = fadd fast float %3686, 0x3FC1EB8520000000
  %3690 = fadd fast float %3687, 0x3FC1EB8520000000
  %3691 = fdiv fast float %3676, %3688
  %3692 = fdiv fast float %3677, %3689
  %3693 = fdiv fast float %3678, %3690
  br label %3694

; <label>:3694                                    ; preds = %3669, %3655
  %3695 = phi float [ %3691, %3669 ], [ %3665, %3655 ]
  %3696 = phi float [ %3692, %3669 ], [ %3666, %3655 ]
  %3697 = phi float [ %3693, %3669 ], [ %3667, %3655 ]
  %3698 = call float @dx.op.unary.f32(i32 7, float %3695)  ; Saturate(value)
  %3699 = call float @dx.op.unary.f32(i32 7, float %3696)  ; Saturate(value)
  %3700 = call float @dx.op.unary.f32(i32 7, float %3697)  ; Saturate(value)
  %3701 = call float @dx.op.dot3.f32(i32 55, float %3698, float %3699, float %3700, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3702 = fsub fast float %3698, %3701
  %3703 = fsub fast float %3699, %3701
  %3704 = fsub fast float %3700, %3701
  %3705 = fmul fast float %3702, %9
  %3706 = fmul fast float %3703, %9
  %3707 = fmul fast float %3704, %9
  %3708 = fadd fast float %3705, %3701
  %3709 = fadd fast float %3706, %3701
  %3710 = fadd fast float %3707, %3701
  %3711 = call float @dx.op.unary.f32(i32 7, float %3708)  ; Saturate(value)
  %3712 = call float @dx.op.unary.f32(i32 7, float %3709)  ; Saturate(value)
  %3713 = call float @dx.op.unary.f32(i32 7, float %3710)  ; Saturate(value)
  %3714 = fadd fast float %3711, 0xBFC70A3D80000000
  %3715 = fadd fast float %3712, 0xBFC70A3D80000000
  %3716 = fadd fast float %3713, 0xBFC70A3D80000000
  %3717 = fmul fast float %3714, %8
  %3718 = fmul fast float %3715, %8
  %3719 = fmul fast float %3716, %8
  %3720 = fadd fast float %3717, 0x3FC70A3D80000000
  %3721 = fadd fast float %3718, 0x3FC70A3D80000000
  %3722 = fadd fast float %3719, 0x3FC70A3D80000000
  %3723 = call float @dx.op.unary.f32(i32 7, float %3720)  ; Saturate(value)
  %3724 = call float @dx.op.unary.f32(i32 7, float %3721)  ; Saturate(value)
  %3725 = call float @dx.op.unary.f32(i32 7, float %3722)  ; Saturate(value)
  %3726 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %3726, label %3727, label %4671

; <label>:3727                                    ; preds = %3694
  %3728 = add i32 %2393, -1
  %3729 = call i32 @dx.op.binary.i32(i32 37, i32 %1229, i32 0)  ; IMax(a,b)
  %3730 = call i32 @dx.op.binary.i32(i32 37, i32 %3728, i32 0)  ; IMax(a,b)
  %3731 = call i32 @dx.op.binary.i32(i32 38, i32 %3729, i32 %60)  ; IMin(a,b)
  %3732 = call i32 @dx.op.binary.i32(i32 38, i32 %3730, i32 %61)  ; IMin(a,b)
  %3733 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3731, i32 %3732, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3734 = extractvalue %dx.types.ResRet.f32 %3733, 0
  %3735 = extractvalue %dx.types.ResRet.f32 %3733, 1
  %3736 = extractvalue %dx.types.ResRet.f32 %3733, 2
  %3737 = extractvalue %dx.types.ResRet.f32 %3733, 3
  %3738 = fcmp fast olt float %3737, 0.000000e+00
  br i1 %3738, label %3739, label %3773

; <label>:3739                                    ; preds = %3727
  %3740 = fcmp fast ogt float %3734, 0x3FA4B5DCC0000000
  %3741 = fcmp fast ogt float %3735, 0x3FA4B5DCC0000000
  %3742 = fcmp fast ogt float %3736, 0x3FA4B5DCC0000000
  %3743 = select i1 %3740, float 0.000000e+00, float 1.000000e+00
  %3744 = select i1 %3741, float 0.000000e+00, float 1.000000e+00
  %3745 = select i1 %3742, float 0.000000e+00, float 1.000000e+00
  %3746 = fmul fast float %3734, 0x3FB3D07220000000
  %3747 = fmul fast float %3735, 0x3FB3D07220000000
  %3748 = fmul fast float %3736, 0x3FB3D07220000000
  %3749 = fadd fast float %3734, 0x3FAC28F5C0000000
  %3750 = fadd fast float %3735, 0x3FAC28F5C0000000
  %3751 = fadd fast float %3736, 0x3FAC28F5C0000000
  %3752 = fmul fast float %3749, 0x3FEE54EDE0000000
  %3753 = fmul fast float %3750, 0x3FEE54EDE0000000
  %3754 = fmul fast float %3751, 0x3FEE54EDE0000000
  %3755 = call float @dx.op.unary.f32(i32 23, float %3752)  ; Log(value)
  %3756 = call float @dx.op.unary.f32(i32 23, float %3753)  ; Log(value)
  %3757 = call float @dx.op.unary.f32(i32 23, float %3754)  ; Log(value)
  %3758 = fmul fast float %3755, 0x4003333340000000
  %3759 = fmul fast float %3756, 0x4003333340000000
  %3760 = fmul fast float %3757, 0x4003333340000000
  %3761 = call float @dx.op.unary.f32(i32 21, float %3758)  ; Exp(value)
  %3762 = call float @dx.op.unary.f32(i32 21, float %3759)  ; Exp(value)
  %3763 = call float @dx.op.unary.f32(i32 21, float %3760)  ; Exp(value)
  %3764 = fsub fast float %3746, %3761
  %3765 = fsub fast float %3747, %3762
  %3766 = fsub fast float %3748, %3763
  %3767 = fmul fast float %3764, %3743
  %3768 = fmul fast float %3765, %3744
  %3769 = fmul fast float %3766, %3745
  %3770 = fadd fast float %3767, %3761
  %3771 = fadd fast float %3768, %3762
  %3772 = fadd fast float %3769, %3763
  br label %3936

; <label>:3773                                    ; preds = %3727
  %3774 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3731, i32 %3732, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3775 = extractvalue %dx.types.ResRet.f32 %3774, 0
  %3776 = fcmp fast ogt float %39, 5.000000e-01
  %3777 = fcmp fast olt float %3775, 1.000000e+00
  %3778 = and i1 %3776, %3777
  br i1 %3778, label %3779, label %3865

; <label>:3779                                    ; preds = %3773
  %3780 = sitofp i32 %3731 to float
  %3781 = sitofp i32 %3732 to float
  %3782 = fadd fast float %3780, 5.000000e-01
  %3783 = fadd fast float %3781, 5.000000e-01
  %3784 = fdiv fast float %3782, %46
  %3785 = fdiv fast float %3783, %47
  %3786 = fmul fast float %3784, 2.000000e+00
  %3787 = fmul fast float %3785, 2.000000e+00
  %3788 = fadd fast float %3786, -1.000000e+00
  %3789 = fsub fast float 1.000000e+00, %3787
  %3790 = fmul fast float %3788, %36
  %3791 = call float @dx.op.tertiary.f32(i32 46, float %3789, float %32, float %3790)  ; FMad(a,b,c)
  %3792 = call float @dx.op.tertiary.f32(i32 46, float %3775, float %28, float %3791)  ; FMad(a,b,c)
  %3793 = fadd fast float %3792, %24
  %3794 = call float @dx.op.unary.f32(i32 6, float %3793)  ; FAbs(value)
  %3795 = fcmp fast ogt float %3794, 0x3EB0C6F7A0000000
  br i1 %3795, label %3796, label %3865

; <label>:3796                                    ; preds = %3779
  %3797 = fmul fast float %3788, %35
  %3798 = call float @dx.op.tertiary.f32(i32 46, float %3789, float %31, float %3797)  ; FMad(a,b,c)
  %3799 = call float @dx.op.tertiary.f32(i32 46, float %3775, float %27, float %3798)  ; FMad(a,b,c)
  %3800 = fadd fast float %3799, %23
  %3801 = fmul fast float %3788, %34
  %3802 = call float @dx.op.tertiary.f32(i32 46, float %3789, float %30, float %3801)  ; FMad(a,b,c)
  %3803 = call float @dx.op.tertiary.f32(i32 46, float %3775, float %26, float %3802)  ; FMad(a,b,c)
  %3804 = fadd fast float %3803, %22
  %3805 = fmul fast float %3788, %33
  %3806 = call float @dx.op.tertiary.f32(i32 46, float %3789, float %29, float %3805)  ; FMad(a,b,c)
  %3807 = call float @dx.op.tertiary.f32(i32 46, float %3775, float %25, float %3806)  ; FMad(a,b,c)
  %3808 = fadd fast float %3807, %21
  %3809 = fdiv fast float %3808, %3793
  %3810 = fdiv fast float %3804, %3793
  %3811 = fdiv fast float %3800, %3793
  %3812 = fsub fast float %3809, %18
  %3813 = fsub fast float %3810, %19
  %3814 = fsub fast float %3811, %20
  %3815 = fmul fast float %3812, %3812
  %3816 = fmul fast float %3813, %3813
  %3817 = fadd fast float %3816, %3815
  %3818 = fmul fast float %3814, %3814
  %3819 = fadd fast float %3817, %3818
  %3820 = call float @dx.op.unary.f32(i32 24, float %3819)  ; Sqrt(value)
  %3821 = fsub fast float %3820, %10
  %3822 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3821)  ; FMax(a,b)
  %3823 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %3823, label %3824, label %3847

; <label>:3824                                    ; preds = %3796
  %3825 = call float @dx.op.unary.f32(i32 6, float %3813)  ; FAbs(value)
  %3826 = fmul fast float %3825, %12
  %3827 = fcmp fast olt float %3826, 0x3F50624DE0000000
  br i1 %3827, label %3828, label %3831

; <label>:3828                                    ; preds = %3824
  %3829 = fmul fast float %3826, 5.000000e-01
  %3830 = fsub fast float 1.000000e+00, %3829
  br label %3836

; <label>:3831                                    ; preds = %3824
  %3832 = fmul fast float %3826, 0xBFF7154760000000
  %3833 = call float @dx.op.unary.f32(i32 21, float %3832)  ; Exp(value)
  %3834 = fsub fast float 1.000000e+00, %3833
  %3835 = fdiv fast float %3834, %3826
  br label %3836

; <label>:3836                                    ; preds = %3831, %3828
  %3837 = phi float [ %3830, %3828 ], [ %3835, %3831 ]
  %3838 = call float @dx.op.binary.f32(i32 36, float %3810, float %19)  ; FMin(a,b)
  %3839 = fsub fast float %3838, %11
  %3840 = fmul fast float %12, %3839
  %3841 = fsub fast float -0.000000e+00, %3840
  %3842 = call float @dx.op.binary.f32(i32 35, float %3841, float -4.000000e+01)  ; FMax(a,b)
  %3843 = call float @dx.op.binary.f32(i32 36, float %3842, float 5.000000e+00)  ; FMin(a,b)
  %3844 = fmul fast float %3843, 0x3FF7154760000000
  %3845 = call float @dx.op.unary.f32(i32 21, float %3844)  ; Exp(value)
  %3846 = fmul fast float %3845, %3837
  br label %3847

; <label>:3847                                    ; preds = %3836, %3796
  %3848 = phi float [ %3846, %3836 ], [ 1.000000e+00, %3796 ]
  %3849 = fmul fast float %3822, %17
  %3850 = fmul fast float %3849, %3848
  %3851 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3850)  ; FMin(a,b)
  %3852 = fmul fast float %3851, 0xBFF7154760000000
  %3853 = call float @dx.op.unary.f32(i32 21, float %3852)  ; Exp(value)
  %3854 = fsub fast float 1.000000e+00, %3853
  %3855 = call float @dx.op.binary.f32(i32 36, float %13, float %3854)  ; FMin(a,b)
  %3856 = fsub fast float %14, %3734
  %3857 = fsub fast float %15, %3735
  %3858 = fsub fast float %16, %3736
  %3859 = fmul fast float %3855, %3856
  %3860 = fmul fast float %3855, %3857
  %3861 = fmul fast float %3855, %3858
  %3862 = fadd fast float %3859, %3734
  %3863 = fadd fast float %3860, %3735
  %3864 = fadd fast float %3861, %3736
  br label %3865

; <label>:3865                                    ; preds = %3847, %3779, %3773
  %3866 = phi float [ %3862, %3847 ], [ %3734, %3779 ], [ %3734, %3773 ]
  %3867 = phi float [ %3863, %3847 ], [ %3735, %3779 ], [ %3735, %3773 ]
  %3868 = phi float [ %3864, %3847 ], [ %3736, %3779 ], [ %3736, %3773 ]
  %3869 = fadd fast float %6, 1.000000e+00
  %3870 = fadd fast float %7, 1.000000e+00
  %3871 = fsub fast float 1.000000e+00, %6
  %3872 = fmul fast float %37, %3869
  %3873 = fmul fast float %37, %3870
  %3874 = fmul fast float %37, %3871
  %3875 = fmul fast float %3872, %3866
  %3876 = fmul fast float %3873, %3867
  %3877 = fmul fast float %3874, %3868
  %3878 = fcmp fast ult float %38, 5.000000e-01
  br i1 %3878, label %3904, label %3879

; <label>:3879                                    ; preds = %3865
  %3880 = fmul fast float %3875, 0x4004147AE0000000
  %3881 = fmul fast float %3876, 0x4004147AE0000000
  %3882 = fmul fast float %3877, 0x4004147AE0000000
  %3883 = fadd fast float %3880, 0x3F9EB851E0000000
  %3884 = fadd fast float %3881, 0x3F9EB851E0000000
  %3885 = fadd fast float %3882, 0x3F9EB851E0000000
  %3886 = fmul fast float %3883, %3875
  %3887 = fmul fast float %3884, %3876
  %3888 = fmul fast float %3885, %3877
  %3889 = fmul fast float %3875, 0x400370A3E0000000
  %3890 = fmul fast float %3876, 0x400370A3E0000000
  %3891 = fmul fast float %3877, 0x400370A3E0000000
  %3892 = fadd fast float %3889, 0x3FE2E147A0000000
  %3893 = fadd fast float %3890, 0x3FE2E147A0000000
  %3894 = fadd fast float %3891, 0x3FE2E147A0000000
  %3895 = fmul fast float %3892, %3875
  %3896 = fmul fast float %3893, %3876
  %3897 = fmul fast float %3894, %3877
  %3898 = fadd fast float %3895, 0x3FC1EB8520000000
  %3899 = fadd fast float %3896, 0x3FC1EB8520000000
  %3900 = fadd fast float %3897, 0x3FC1EB8520000000
  %3901 = fdiv fast float %3886, %3898
  %3902 = fdiv fast float %3887, %3899
  %3903 = fdiv fast float %3888, %3900
  br label %3904

; <label>:3904                                    ; preds = %3879, %3865
  %3905 = phi float [ %3901, %3879 ], [ %3875, %3865 ]
  %3906 = phi float [ %3902, %3879 ], [ %3876, %3865 ]
  %3907 = phi float [ %3903, %3879 ], [ %3877, %3865 ]
  %3908 = call float @dx.op.unary.f32(i32 7, float %3905)  ; Saturate(value)
  %3909 = call float @dx.op.unary.f32(i32 7, float %3906)  ; Saturate(value)
  %3910 = call float @dx.op.unary.f32(i32 7, float %3907)  ; Saturate(value)
  %3911 = call float @dx.op.dot3.f32(i32 55, float %3908, float %3909, float %3910, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3912 = fsub fast float %3908, %3911
  %3913 = fsub fast float %3909, %3911
  %3914 = fsub fast float %3910, %3911
  %3915 = fmul fast float %3912, %9
  %3916 = fmul fast float %3913, %9
  %3917 = fmul fast float %3914, %9
  %3918 = fadd fast float %3915, %3911
  %3919 = fadd fast float %3916, %3911
  %3920 = fadd fast float %3917, %3911
  %3921 = call float @dx.op.unary.f32(i32 7, float %3918)  ; Saturate(value)
  %3922 = call float @dx.op.unary.f32(i32 7, float %3919)  ; Saturate(value)
  %3923 = call float @dx.op.unary.f32(i32 7, float %3920)  ; Saturate(value)
  %3924 = fadd fast float %3921, 0xBFC70A3D80000000
  %3925 = fadd fast float %3922, 0xBFC70A3D80000000
  %3926 = fadd fast float %3923, 0xBFC70A3D80000000
  %3927 = fmul fast float %3924, %8
  %3928 = fmul fast float %3925, %8
  %3929 = fmul fast float %3926, %8
  %3930 = fadd fast float %3927, 0x3FC70A3D80000000
  %3931 = fadd fast float %3928, 0x3FC70A3D80000000
  %3932 = fadd fast float %3929, 0x3FC70A3D80000000
  %3933 = call float @dx.op.unary.f32(i32 7, float %3930)  ; Saturate(value)
  %3934 = call float @dx.op.unary.f32(i32 7, float %3931)  ; Saturate(value)
  %3935 = call float @dx.op.unary.f32(i32 7, float %3932)  ; Saturate(value)
  br label %3936

; <label>:3936                                    ; preds = %3904, %3739
  %3937 = phi float [ %3770, %3739 ], [ %3933, %3904 ]
  %3938 = phi float [ %3771, %3739 ], [ %3934, %3904 ]
  %3939 = phi float [ %3772, %3739 ], [ %3935, %3904 ]
  %3940 = add i32 %2393, 1
  %3941 = call i32 @dx.op.binary.i32(i32 37, i32 %3940, i32 0)  ; IMax(a,b)
  %3942 = call i32 @dx.op.binary.i32(i32 38, i32 %3941, i32 %61)  ; IMin(a,b)
  %3943 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3731, i32 %3942, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3944 = extractvalue %dx.types.ResRet.f32 %3943, 0
  %3945 = extractvalue %dx.types.ResRet.f32 %3943, 1
  %3946 = extractvalue %dx.types.ResRet.f32 %3943, 2
  %3947 = extractvalue %dx.types.ResRet.f32 %3943, 3
  %3948 = fcmp fast olt float %3947, 0.000000e+00
  br i1 %3948, label %3949, label %3983

; <label>:3949                                    ; preds = %3936
  %3950 = fcmp fast ogt float %3944, 0x3FA4B5DCC0000000
  %3951 = fcmp fast ogt float %3945, 0x3FA4B5DCC0000000
  %3952 = fcmp fast ogt float %3946, 0x3FA4B5DCC0000000
  %3953 = select i1 %3950, float 0.000000e+00, float 1.000000e+00
  %3954 = select i1 %3951, float 0.000000e+00, float 1.000000e+00
  %3955 = select i1 %3952, float 0.000000e+00, float 1.000000e+00
  %3956 = fmul fast float %3944, 0x3FB3D07220000000
  %3957 = fmul fast float %3945, 0x3FB3D07220000000
  %3958 = fmul fast float %3946, 0x3FB3D07220000000
  %3959 = fadd fast float %3944, 0x3FAC28F5C0000000
  %3960 = fadd fast float %3945, 0x3FAC28F5C0000000
  %3961 = fadd fast float %3946, 0x3FAC28F5C0000000
  %3962 = fmul fast float %3959, 0x3FEE54EDE0000000
  %3963 = fmul fast float %3960, 0x3FEE54EDE0000000
  %3964 = fmul fast float %3961, 0x3FEE54EDE0000000
  %3965 = call float @dx.op.unary.f32(i32 23, float %3962)  ; Log(value)
  %3966 = call float @dx.op.unary.f32(i32 23, float %3963)  ; Log(value)
  %3967 = call float @dx.op.unary.f32(i32 23, float %3964)  ; Log(value)
  %3968 = fmul fast float %3965, 0x4003333340000000
  %3969 = fmul fast float %3966, 0x4003333340000000
  %3970 = fmul fast float %3967, 0x4003333340000000
  %3971 = call float @dx.op.unary.f32(i32 21, float %3968)  ; Exp(value)
  %3972 = call float @dx.op.unary.f32(i32 21, float %3969)  ; Exp(value)
  %3973 = call float @dx.op.unary.f32(i32 21, float %3970)  ; Exp(value)
  %3974 = fsub fast float %3956, %3971
  %3975 = fsub fast float %3957, %3972
  %3976 = fsub fast float %3958, %3973
  %3977 = fmul fast float %3974, %3953
  %3978 = fmul fast float %3975, %3954
  %3979 = fmul fast float %3976, %3955
  %3980 = fadd fast float %3977, %3971
  %3981 = fadd fast float %3978, %3972
  %3982 = fadd fast float %3979, %3973
  br label %4146

; <label>:3983                                    ; preds = %3936
  %3984 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3731, i32 %3942, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3985 = extractvalue %dx.types.ResRet.f32 %3984, 0
  %3986 = fcmp fast ogt float %39, 5.000000e-01
  %3987 = fcmp fast olt float %3985, 1.000000e+00
  %3988 = and i1 %3986, %3987
  br i1 %3988, label %3989, label %4075

; <label>:3989                                    ; preds = %3983
  %3990 = sitofp i32 %3731 to float
  %3991 = sitofp i32 %3942 to float
  %3992 = fadd fast float %3990, 5.000000e-01
  %3993 = fadd fast float %3991, 5.000000e-01
  %3994 = fdiv fast float %3992, %46
  %3995 = fdiv fast float %3993, %47
  %3996 = fmul fast float %3994, 2.000000e+00
  %3997 = fmul fast float %3995, 2.000000e+00
  %3998 = fadd fast float %3996, -1.000000e+00
  %3999 = fsub fast float 1.000000e+00, %3997
  %4000 = fmul fast float %3998, %36
  %4001 = call float @dx.op.tertiary.f32(i32 46, float %3999, float %32, float %4000)  ; FMad(a,b,c)
  %4002 = call float @dx.op.tertiary.f32(i32 46, float %3985, float %28, float %4001)  ; FMad(a,b,c)
  %4003 = fadd fast float %4002, %24
  %4004 = call float @dx.op.unary.f32(i32 6, float %4003)  ; FAbs(value)
  %4005 = fcmp fast ogt float %4004, 0x3EB0C6F7A0000000
  br i1 %4005, label %4006, label %4075

; <label>:4006                                    ; preds = %3989
  %4007 = fmul fast float %3998, %35
  %4008 = call float @dx.op.tertiary.f32(i32 46, float %3999, float %31, float %4007)  ; FMad(a,b,c)
  %4009 = call float @dx.op.tertiary.f32(i32 46, float %3985, float %27, float %4008)  ; FMad(a,b,c)
  %4010 = fadd fast float %4009, %23
  %4011 = fmul fast float %3998, %34
  %4012 = call float @dx.op.tertiary.f32(i32 46, float %3999, float %30, float %4011)  ; FMad(a,b,c)
  %4013 = call float @dx.op.tertiary.f32(i32 46, float %3985, float %26, float %4012)  ; FMad(a,b,c)
  %4014 = fadd fast float %4013, %22
  %4015 = fmul fast float %3998, %33
  %4016 = call float @dx.op.tertiary.f32(i32 46, float %3999, float %29, float %4015)  ; FMad(a,b,c)
  %4017 = call float @dx.op.tertiary.f32(i32 46, float %3985, float %25, float %4016)  ; FMad(a,b,c)
  %4018 = fadd fast float %4017, %21
  %4019 = fdiv fast float %4018, %4003
  %4020 = fdiv fast float %4014, %4003
  %4021 = fdiv fast float %4010, %4003
  %4022 = fsub fast float %4019, %18
  %4023 = fsub fast float %4020, %19
  %4024 = fsub fast float %4021, %20
  %4025 = fmul fast float %4022, %4022
  %4026 = fmul fast float %4023, %4023
  %4027 = fadd fast float %4026, %4025
  %4028 = fmul fast float %4024, %4024
  %4029 = fadd fast float %4027, %4028
  %4030 = call float @dx.op.unary.f32(i32 24, float %4029)  ; Sqrt(value)
  %4031 = fsub fast float %4030, %10
  %4032 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4031)  ; FMax(a,b)
  %4033 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %4033, label %4034, label %4057

; <label>:4034                                    ; preds = %4006
  %4035 = call float @dx.op.unary.f32(i32 6, float %4023)  ; FAbs(value)
  %4036 = fmul fast float %4035, %12
  %4037 = fcmp fast olt float %4036, 0x3F50624DE0000000
  br i1 %4037, label %4038, label %4041

; <label>:4038                                    ; preds = %4034
  %4039 = fmul fast float %4036, 5.000000e-01
  %4040 = fsub fast float 1.000000e+00, %4039
  br label %4046

; <label>:4041                                    ; preds = %4034
  %4042 = fmul fast float %4036, 0xBFF7154760000000
  %4043 = call float @dx.op.unary.f32(i32 21, float %4042)  ; Exp(value)
  %4044 = fsub fast float 1.000000e+00, %4043
  %4045 = fdiv fast float %4044, %4036
  br label %4046

; <label>:4046                                    ; preds = %4041, %4038
  %4047 = phi float [ %4040, %4038 ], [ %4045, %4041 ]
  %4048 = call float @dx.op.binary.f32(i32 36, float %4020, float %19)  ; FMin(a,b)
  %4049 = fsub fast float %4048, %11
  %4050 = fmul fast float %12, %4049
  %4051 = fsub fast float -0.000000e+00, %4050
  %4052 = call float @dx.op.binary.f32(i32 35, float %4051, float -4.000000e+01)  ; FMax(a,b)
  %4053 = call float @dx.op.binary.f32(i32 36, float %4052, float 5.000000e+00)  ; FMin(a,b)
  %4054 = fmul fast float %4053, 0x3FF7154760000000
  %4055 = call float @dx.op.unary.f32(i32 21, float %4054)  ; Exp(value)
  %4056 = fmul fast float %4055, %4047
  br label %4057

; <label>:4057                                    ; preds = %4046, %4006
  %4058 = phi float [ %4056, %4046 ], [ 1.000000e+00, %4006 ]
  %4059 = fmul fast float %4032, %17
  %4060 = fmul fast float %4059, %4058
  %4061 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4060)  ; FMin(a,b)
  %4062 = fmul fast float %4061, 0xBFF7154760000000
  %4063 = call float @dx.op.unary.f32(i32 21, float %4062)  ; Exp(value)
  %4064 = fsub fast float 1.000000e+00, %4063
  %4065 = call float @dx.op.binary.f32(i32 36, float %13, float %4064)  ; FMin(a,b)
  %4066 = fsub fast float %14, %3944
  %4067 = fsub fast float %15, %3945
  %4068 = fsub fast float %16, %3946
  %4069 = fmul fast float %4065, %4066
  %4070 = fmul fast float %4065, %4067
  %4071 = fmul fast float %4065, %4068
  %4072 = fadd fast float %4069, %3944
  %4073 = fadd fast float %4070, %3945
  %4074 = fadd fast float %4071, %3946
  br label %4075

; <label>:4075                                    ; preds = %4057, %3989, %3983
  %4076 = phi float [ %4072, %4057 ], [ %3944, %3989 ], [ %3944, %3983 ]
  %4077 = phi float [ %4073, %4057 ], [ %3945, %3989 ], [ %3945, %3983 ]
  %4078 = phi float [ %4074, %4057 ], [ %3946, %3989 ], [ %3946, %3983 ]
  %4079 = fadd fast float %6, 1.000000e+00
  %4080 = fadd fast float %7, 1.000000e+00
  %4081 = fsub fast float 1.000000e+00, %6
  %4082 = fmul fast float %37, %4079
  %4083 = fmul fast float %37, %4080
  %4084 = fmul fast float %37, %4081
  %4085 = fmul fast float %4082, %4076
  %4086 = fmul fast float %4083, %4077
  %4087 = fmul fast float %4084, %4078
  %4088 = fcmp fast ult float %38, 5.000000e-01
  br i1 %4088, label %4114, label %4089

; <label>:4089                                    ; preds = %4075
  %4090 = fmul fast float %4085, 0x4004147AE0000000
  %4091 = fmul fast float %4086, 0x4004147AE0000000
  %4092 = fmul fast float %4087, 0x4004147AE0000000
  %4093 = fadd fast float %4090, 0x3F9EB851E0000000
  %4094 = fadd fast float %4091, 0x3F9EB851E0000000
  %4095 = fadd fast float %4092, 0x3F9EB851E0000000
  %4096 = fmul fast float %4093, %4085
  %4097 = fmul fast float %4094, %4086
  %4098 = fmul fast float %4095, %4087
  %4099 = fmul fast float %4085, 0x400370A3E0000000
  %4100 = fmul fast float %4086, 0x400370A3E0000000
  %4101 = fmul fast float %4087, 0x400370A3E0000000
  %4102 = fadd fast float %4099, 0x3FE2E147A0000000
  %4103 = fadd fast float %4100, 0x3FE2E147A0000000
  %4104 = fadd fast float %4101, 0x3FE2E147A0000000
  %4105 = fmul fast float %4102, %4085
  %4106 = fmul fast float %4103, %4086
  %4107 = fmul fast float %4104, %4087
  %4108 = fadd fast float %4105, 0x3FC1EB8520000000
  %4109 = fadd fast float %4106, 0x3FC1EB8520000000
  %4110 = fadd fast float %4107, 0x3FC1EB8520000000
  %4111 = fdiv fast float %4096, %4108
  %4112 = fdiv fast float %4097, %4109
  %4113 = fdiv fast float %4098, %4110
  br label %4114

; <label>:4114                                    ; preds = %4089, %4075
  %4115 = phi float [ %4111, %4089 ], [ %4085, %4075 ]
  %4116 = phi float [ %4112, %4089 ], [ %4086, %4075 ]
  %4117 = phi float [ %4113, %4089 ], [ %4087, %4075 ]
  %4118 = call float @dx.op.unary.f32(i32 7, float %4115)  ; Saturate(value)
  %4119 = call float @dx.op.unary.f32(i32 7, float %4116)  ; Saturate(value)
  %4120 = call float @dx.op.unary.f32(i32 7, float %4117)  ; Saturate(value)
  %4121 = call float @dx.op.dot3.f32(i32 55, float %4118, float %4119, float %4120, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4122 = fsub fast float %4118, %4121
  %4123 = fsub fast float %4119, %4121
  %4124 = fsub fast float %4120, %4121
  %4125 = fmul fast float %4122, %9
  %4126 = fmul fast float %4123, %9
  %4127 = fmul fast float %4124, %9
  %4128 = fadd fast float %4125, %4121
  %4129 = fadd fast float %4126, %4121
  %4130 = fadd fast float %4127, %4121
  %4131 = call float @dx.op.unary.f32(i32 7, float %4128)  ; Saturate(value)
  %4132 = call float @dx.op.unary.f32(i32 7, float %4129)  ; Saturate(value)
  %4133 = call float @dx.op.unary.f32(i32 7, float %4130)  ; Saturate(value)
  %4134 = fadd fast float %4131, 0xBFC70A3D80000000
  %4135 = fadd fast float %4132, 0xBFC70A3D80000000
  %4136 = fadd fast float %4133, 0xBFC70A3D80000000
  %4137 = fmul fast float %4134, %8
  %4138 = fmul fast float %4135, %8
  %4139 = fmul fast float %4136, %8
  %4140 = fadd fast float %4137, 0x3FC70A3D80000000
  %4141 = fadd fast float %4138, 0x3FC70A3D80000000
  %4142 = fadd fast float %4139, 0x3FC70A3D80000000
  %4143 = call float @dx.op.unary.f32(i32 7, float %4140)  ; Saturate(value)
  %4144 = call float @dx.op.unary.f32(i32 7, float %4141)  ; Saturate(value)
  %4145 = call float @dx.op.unary.f32(i32 7, float %4142)  ; Saturate(value)
  br label %4146

; <label>:4146                                    ; preds = %4114, %3949
  %4147 = phi float [ %3980, %3949 ], [ %4143, %4114 ]
  %4148 = phi float [ %3981, %3949 ], [ %4144, %4114 ]
  %4149 = phi float [ %3982, %3949 ], [ %4145, %4114 ]
  %4150 = add i32 %1229, -1
  %4151 = call i32 @dx.op.binary.i32(i32 37, i32 %4150, i32 0)  ; IMax(a,b)
  %4152 = call i32 @dx.op.binary.i32(i32 37, i32 %2393, i32 0)  ; IMax(a,b)
  %4153 = call i32 @dx.op.binary.i32(i32 38, i32 %4151, i32 %60)  ; IMin(a,b)
  %4154 = call i32 @dx.op.binary.i32(i32 38, i32 %4152, i32 %61)  ; IMin(a,b)
  %4155 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4153, i32 %4154, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4156 = extractvalue %dx.types.ResRet.f32 %4155, 0
  %4157 = extractvalue %dx.types.ResRet.f32 %4155, 1
  %4158 = extractvalue %dx.types.ResRet.f32 %4155, 2
  %4159 = extractvalue %dx.types.ResRet.f32 %4155, 3
  %4160 = fcmp fast olt float %4159, 0.000000e+00
  br i1 %4160, label %4161, label %4195

; <label>:4161                                    ; preds = %4146
  %4162 = fcmp fast ogt float %4156, 0x3FA4B5DCC0000000
  %4163 = fcmp fast ogt float %4157, 0x3FA4B5DCC0000000
  %4164 = fcmp fast ogt float %4158, 0x3FA4B5DCC0000000
  %4165 = select i1 %4162, float 0.000000e+00, float 1.000000e+00
  %4166 = select i1 %4163, float 0.000000e+00, float 1.000000e+00
  %4167 = select i1 %4164, float 0.000000e+00, float 1.000000e+00
  %4168 = fmul fast float %4156, 0x3FB3D07220000000
  %4169 = fmul fast float %4157, 0x3FB3D07220000000
  %4170 = fmul fast float %4158, 0x3FB3D07220000000
  %4171 = fadd fast float %4156, 0x3FAC28F5C0000000
  %4172 = fadd fast float %4157, 0x3FAC28F5C0000000
  %4173 = fadd fast float %4158, 0x3FAC28F5C0000000
  %4174 = fmul fast float %4171, 0x3FEE54EDE0000000
  %4175 = fmul fast float %4172, 0x3FEE54EDE0000000
  %4176 = fmul fast float %4173, 0x3FEE54EDE0000000
  %4177 = call float @dx.op.unary.f32(i32 23, float %4174)  ; Log(value)
  %4178 = call float @dx.op.unary.f32(i32 23, float %4175)  ; Log(value)
  %4179 = call float @dx.op.unary.f32(i32 23, float %4176)  ; Log(value)
  %4180 = fmul fast float %4177, 0x4003333340000000
  %4181 = fmul fast float %4178, 0x4003333340000000
  %4182 = fmul fast float %4179, 0x4003333340000000
  %4183 = call float @dx.op.unary.f32(i32 21, float %4180)  ; Exp(value)
  %4184 = call float @dx.op.unary.f32(i32 21, float %4181)  ; Exp(value)
  %4185 = call float @dx.op.unary.f32(i32 21, float %4182)  ; Exp(value)
  %4186 = fsub fast float %4168, %4183
  %4187 = fsub fast float %4169, %4184
  %4188 = fsub fast float %4170, %4185
  %4189 = fmul fast float %4186, %4165
  %4190 = fmul fast float %4187, %4166
  %4191 = fmul fast float %4188, %4167
  %4192 = fadd fast float %4189, %4183
  %4193 = fadd fast float %4190, %4184
  %4194 = fadd fast float %4191, %4185
  br label %4358

; <label>:4195                                    ; preds = %4146
  %4196 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4153, i32 %4154, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4197 = extractvalue %dx.types.ResRet.f32 %4196, 0
  %4198 = fcmp fast ogt float %39, 5.000000e-01
  %4199 = fcmp fast olt float %4197, 1.000000e+00
  %4200 = and i1 %4198, %4199
  br i1 %4200, label %4201, label %4287

; <label>:4201                                    ; preds = %4195
  %4202 = sitofp i32 %4153 to float
  %4203 = sitofp i32 %4154 to float
  %4204 = fadd fast float %4202, 5.000000e-01
  %4205 = fadd fast float %4203, 5.000000e-01
  %4206 = fdiv fast float %4204, %46
  %4207 = fdiv fast float %4205, %47
  %4208 = fmul fast float %4206, 2.000000e+00
  %4209 = fmul fast float %4207, 2.000000e+00
  %4210 = fadd fast float %4208, -1.000000e+00
  %4211 = fsub fast float 1.000000e+00, %4209
  %4212 = fmul fast float %4210, %36
  %4213 = call float @dx.op.tertiary.f32(i32 46, float %4211, float %32, float %4212)  ; FMad(a,b,c)
  %4214 = call float @dx.op.tertiary.f32(i32 46, float %4197, float %28, float %4213)  ; FMad(a,b,c)
  %4215 = fadd fast float %4214, %24
  %4216 = call float @dx.op.unary.f32(i32 6, float %4215)  ; FAbs(value)
  %4217 = fcmp fast ogt float %4216, 0x3EB0C6F7A0000000
  br i1 %4217, label %4218, label %4287

; <label>:4218                                    ; preds = %4201
  %4219 = fmul fast float %4210, %35
  %4220 = call float @dx.op.tertiary.f32(i32 46, float %4211, float %31, float %4219)  ; FMad(a,b,c)
  %4221 = call float @dx.op.tertiary.f32(i32 46, float %4197, float %27, float %4220)  ; FMad(a,b,c)
  %4222 = fadd fast float %4221, %23
  %4223 = fmul fast float %4210, %34
  %4224 = call float @dx.op.tertiary.f32(i32 46, float %4211, float %30, float %4223)  ; FMad(a,b,c)
  %4225 = call float @dx.op.tertiary.f32(i32 46, float %4197, float %26, float %4224)  ; FMad(a,b,c)
  %4226 = fadd fast float %4225, %22
  %4227 = fmul fast float %4210, %33
  %4228 = call float @dx.op.tertiary.f32(i32 46, float %4211, float %29, float %4227)  ; FMad(a,b,c)
  %4229 = call float @dx.op.tertiary.f32(i32 46, float %4197, float %25, float %4228)  ; FMad(a,b,c)
  %4230 = fadd fast float %4229, %21
  %4231 = fdiv fast float %4230, %4215
  %4232 = fdiv fast float %4226, %4215
  %4233 = fdiv fast float %4222, %4215
  %4234 = fsub fast float %4231, %18
  %4235 = fsub fast float %4232, %19
  %4236 = fsub fast float %4233, %20
  %4237 = fmul fast float %4234, %4234
  %4238 = fmul fast float %4235, %4235
  %4239 = fadd fast float %4238, %4237
  %4240 = fmul fast float %4236, %4236
  %4241 = fadd fast float %4239, %4240
  %4242 = call float @dx.op.unary.f32(i32 24, float %4241)  ; Sqrt(value)
  %4243 = fsub fast float %4242, %10
  %4244 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4243)  ; FMax(a,b)
  %4245 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %4245, label %4246, label %4269

; <label>:4246                                    ; preds = %4218
  %4247 = call float @dx.op.unary.f32(i32 6, float %4235)  ; FAbs(value)
  %4248 = fmul fast float %4247, %12
  %4249 = fcmp fast olt float %4248, 0x3F50624DE0000000
  br i1 %4249, label %4250, label %4253

; <label>:4250                                    ; preds = %4246
  %4251 = fmul fast float %4248, 5.000000e-01
  %4252 = fsub fast float 1.000000e+00, %4251
  br label %4258

; <label>:4253                                    ; preds = %4246
  %4254 = fmul fast float %4248, 0xBFF7154760000000
  %4255 = call float @dx.op.unary.f32(i32 21, float %4254)  ; Exp(value)
  %4256 = fsub fast float 1.000000e+00, %4255
  %4257 = fdiv fast float %4256, %4248
  br label %4258

; <label>:4258                                    ; preds = %4253, %4250
  %4259 = phi float [ %4252, %4250 ], [ %4257, %4253 ]
  %4260 = call float @dx.op.binary.f32(i32 36, float %4232, float %19)  ; FMin(a,b)
  %4261 = fsub fast float %4260, %11
  %4262 = fmul fast float %12, %4261
  %4263 = fsub fast float -0.000000e+00, %4262
  %4264 = call float @dx.op.binary.f32(i32 35, float %4263, float -4.000000e+01)  ; FMax(a,b)
  %4265 = call float @dx.op.binary.f32(i32 36, float %4264, float 5.000000e+00)  ; FMin(a,b)
  %4266 = fmul fast float %4265, 0x3FF7154760000000
  %4267 = call float @dx.op.unary.f32(i32 21, float %4266)  ; Exp(value)
  %4268 = fmul fast float %4267, %4259
  br label %4269

; <label>:4269                                    ; preds = %4258, %4218
  %4270 = phi float [ %4268, %4258 ], [ 1.000000e+00, %4218 ]
  %4271 = fmul fast float %4244, %17
  %4272 = fmul fast float %4271, %4270
  %4273 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4272)  ; FMin(a,b)
  %4274 = fmul fast float %4273, 0xBFF7154760000000
  %4275 = call float @dx.op.unary.f32(i32 21, float %4274)  ; Exp(value)
  %4276 = fsub fast float 1.000000e+00, %4275
  %4277 = call float @dx.op.binary.f32(i32 36, float %13, float %4276)  ; FMin(a,b)
  %4278 = fsub fast float %14, %4156
  %4279 = fsub fast float %15, %4157
  %4280 = fsub fast float %16, %4158
  %4281 = fmul fast float %4277, %4278
  %4282 = fmul fast float %4277, %4279
  %4283 = fmul fast float %4277, %4280
  %4284 = fadd fast float %4281, %4156
  %4285 = fadd fast float %4282, %4157
  %4286 = fadd fast float %4283, %4158
  br label %4287

; <label>:4287                                    ; preds = %4269, %4201, %4195
  %4288 = phi float [ %4284, %4269 ], [ %4156, %4201 ], [ %4156, %4195 ]
  %4289 = phi float [ %4285, %4269 ], [ %4157, %4201 ], [ %4157, %4195 ]
  %4290 = phi float [ %4286, %4269 ], [ %4158, %4201 ], [ %4158, %4195 ]
  %4291 = fadd fast float %6, 1.000000e+00
  %4292 = fadd fast float %7, 1.000000e+00
  %4293 = fsub fast float 1.000000e+00, %6
  %4294 = fmul fast float %37, %4291
  %4295 = fmul fast float %37, %4292
  %4296 = fmul fast float %37, %4293
  %4297 = fmul fast float %4294, %4288
  %4298 = fmul fast float %4295, %4289
  %4299 = fmul fast float %4296, %4290
  %4300 = fcmp fast ult float %38, 5.000000e-01
  br i1 %4300, label %4326, label %4301

; <label>:4301                                    ; preds = %4287
  %4302 = fmul fast float %4297, 0x4004147AE0000000
  %4303 = fmul fast float %4298, 0x4004147AE0000000
  %4304 = fmul fast float %4299, 0x4004147AE0000000
  %4305 = fadd fast float %4302, 0x3F9EB851E0000000
  %4306 = fadd fast float %4303, 0x3F9EB851E0000000
  %4307 = fadd fast float %4304, 0x3F9EB851E0000000
  %4308 = fmul fast float %4305, %4297
  %4309 = fmul fast float %4306, %4298
  %4310 = fmul fast float %4307, %4299
  %4311 = fmul fast float %4297, 0x400370A3E0000000
  %4312 = fmul fast float %4298, 0x400370A3E0000000
  %4313 = fmul fast float %4299, 0x400370A3E0000000
  %4314 = fadd fast float %4311, 0x3FE2E147A0000000
  %4315 = fadd fast float %4312, 0x3FE2E147A0000000
  %4316 = fadd fast float %4313, 0x3FE2E147A0000000
  %4317 = fmul fast float %4314, %4297
  %4318 = fmul fast float %4315, %4298
  %4319 = fmul fast float %4316, %4299
  %4320 = fadd fast float %4317, 0x3FC1EB8520000000
  %4321 = fadd fast float %4318, 0x3FC1EB8520000000
  %4322 = fadd fast float %4319, 0x3FC1EB8520000000
  %4323 = fdiv fast float %4308, %4320
  %4324 = fdiv fast float %4309, %4321
  %4325 = fdiv fast float %4310, %4322
  br label %4326

; <label>:4326                                    ; preds = %4301, %4287
  %4327 = phi float [ %4323, %4301 ], [ %4297, %4287 ]
  %4328 = phi float [ %4324, %4301 ], [ %4298, %4287 ]
  %4329 = phi float [ %4325, %4301 ], [ %4299, %4287 ]
  %4330 = call float @dx.op.unary.f32(i32 7, float %4327)  ; Saturate(value)
  %4331 = call float @dx.op.unary.f32(i32 7, float %4328)  ; Saturate(value)
  %4332 = call float @dx.op.unary.f32(i32 7, float %4329)  ; Saturate(value)
  %4333 = call float @dx.op.dot3.f32(i32 55, float %4330, float %4331, float %4332, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4334 = fsub fast float %4330, %4333
  %4335 = fsub fast float %4331, %4333
  %4336 = fsub fast float %4332, %4333
  %4337 = fmul fast float %4334, %9
  %4338 = fmul fast float %4335, %9
  %4339 = fmul fast float %4336, %9
  %4340 = fadd fast float %4337, %4333
  %4341 = fadd fast float %4338, %4333
  %4342 = fadd fast float %4339, %4333
  %4343 = call float @dx.op.unary.f32(i32 7, float %4340)  ; Saturate(value)
  %4344 = call float @dx.op.unary.f32(i32 7, float %4341)  ; Saturate(value)
  %4345 = call float @dx.op.unary.f32(i32 7, float %4342)  ; Saturate(value)
  %4346 = fadd fast float %4343, 0xBFC70A3D80000000
  %4347 = fadd fast float %4344, 0xBFC70A3D80000000
  %4348 = fadd fast float %4345, 0xBFC70A3D80000000
  %4349 = fmul fast float %4346, %8
  %4350 = fmul fast float %4347, %8
  %4351 = fmul fast float %4348, %8
  %4352 = fadd fast float %4349, 0x3FC70A3D80000000
  %4353 = fadd fast float %4350, 0x3FC70A3D80000000
  %4354 = fadd fast float %4351, 0x3FC70A3D80000000
  %4355 = call float @dx.op.unary.f32(i32 7, float %4352)  ; Saturate(value)
  %4356 = call float @dx.op.unary.f32(i32 7, float %4353)  ; Saturate(value)
  %4357 = call float @dx.op.unary.f32(i32 7, float %4354)  ; Saturate(value)
  br label %4358

; <label>:4358                                    ; preds = %4326, %4161
  %4359 = phi float [ %4192, %4161 ], [ %4355, %4326 ]
  %4360 = phi float [ %4193, %4161 ], [ %4356, %4326 ]
  %4361 = phi float [ %4194, %4161 ], [ %4357, %4326 ]
  %4362 = add i32 %1229, 1
  %4363 = call i32 @dx.op.binary.i32(i32 37, i32 %4362, i32 0)  ; IMax(a,b)
  %4364 = call i32 @dx.op.binary.i32(i32 38, i32 %4363, i32 %60)  ; IMin(a,b)
  %4365 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4364, i32 %4154, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4366 = extractvalue %dx.types.ResRet.f32 %4365, 0
  %4367 = extractvalue %dx.types.ResRet.f32 %4365, 1
  %4368 = extractvalue %dx.types.ResRet.f32 %4365, 2
  %4369 = extractvalue %dx.types.ResRet.f32 %4365, 3
  %4370 = fcmp fast olt float %4369, 0.000000e+00
  br i1 %4370, label %4371, label %4405

; <label>:4371                                    ; preds = %4358
  %4372 = fcmp fast ogt float %4366, 0x3FA4B5DCC0000000
  %4373 = fcmp fast ogt float %4367, 0x3FA4B5DCC0000000
  %4374 = fcmp fast ogt float %4368, 0x3FA4B5DCC0000000
  %4375 = select i1 %4372, float 0.000000e+00, float 1.000000e+00
  %4376 = select i1 %4373, float 0.000000e+00, float 1.000000e+00
  %4377 = select i1 %4374, float 0.000000e+00, float 1.000000e+00
  %4378 = fmul fast float %4366, 0x3FB3D07220000000
  %4379 = fmul fast float %4367, 0x3FB3D07220000000
  %4380 = fmul fast float %4368, 0x3FB3D07220000000
  %4381 = fadd fast float %4366, 0x3FAC28F5C0000000
  %4382 = fadd fast float %4367, 0x3FAC28F5C0000000
  %4383 = fadd fast float %4368, 0x3FAC28F5C0000000
  %4384 = fmul fast float %4381, 0x3FEE54EDE0000000
  %4385 = fmul fast float %4382, 0x3FEE54EDE0000000
  %4386 = fmul fast float %4383, 0x3FEE54EDE0000000
  %4387 = call float @dx.op.unary.f32(i32 23, float %4384)  ; Log(value)
  %4388 = call float @dx.op.unary.f32(i32 23, float %4385)  ; Log(value)
  %4389 = call float @dx.op.unary.f32(i32 23, float %4386)  ; Log(value)
  %4390 = fmul fast float %4387, 0x4003333340000000
  %4391 = fmul fast float %4388, 0x4003333340000000
  %4392 = fmul fast float %4389, 0x4003333340000000
  %4393 = call float @dx.op.unary.f32(i32 21, float %4390)  ; Exp(value)
  %4394 = call float @dx.op.unary.f32(i32 21, float %4391)  ; Exp(value)
  %4395 = call float @dx.op.unary.f32(i32 21, float %4392)  ; Exp(value)
  %4396 = fsub fast float %4378, %4393
  %4397 = fsub fast float %4379, %4394
  %4398 = fsub fast float %4380, %4395
  %4399 = fmul fast float %4396, %4375
  %4400 = fmul fast float %4397, %4376
  %4401 = fmul fast float %4398, %4377
  %4402 = fadd fast float %4399, %4393
  %4403 = fadd fast float %4400, %4394
  %4404 = fadd fast float %4401, %4395
  br label %4568

; <label>:4405                                    ; preds = %4358
  %4406 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4364, i32 %4154, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4407 = extractvalue %dx.types.ResRet.f32 %4406, 0
  %4408 = fcmp fast ogt float %39, 5.000000e-01
  %4409 = fcmp fast olt float %4407, 1.000000e+00
  %4410 = and i1 %4408, %4409
  br i1 %4410, label %4411, label %4497

; <label>:4411                                    ; preds = %4405
  %4412 = sitofp i32 %4364 to float
  %4413 = sitofp i32 %4154 to float
  %4414 = fadd fast float %4412, 5.000000e-01
  %4415 = fadd fast float %4413, 5.000000e-01
  %4416 = fdiv fast float %4414, %46
  %4417 = fdiv fast float %4415, %47
  %4418 = fmul fast float %4416, 2.000000e+00
  %4419 = fmul fast float %4417, 2.000000e+00
  %4420 = fadd fast float %4418, -1.000000e+00
  %4421 = fsub fast float 1.000000e+00, %4419
  %4422 = fmul fast float %4420, %36
  %4423 = call float @dx.op.tertiary.f32(i32 46, float %4421, float %32, float %4422)  ; FMad(a,b,c)
  %4424 = call float @dx.op.tertiary.f32(i32 46, float %4407, float %28, float %4423)  ; FMad(a,b,c)
  %4425 = fadd fast float %4424, %24
  %4426 = call float @dx.op.unary.f32(i32 6, float %4425)  ; FAbs(value)
  %4427 = fcmp fast ogt float %4426, 0x3EB0C6F7A0000000
  br i1 %4427, label %4428, label %4497

; <label>:4428                                    ; preds = %4411
  %4429 = fmul fast float %4420, %35
  %4430 = call float @dx.op.tertiary.f32(i32 46, float %4421, float %31, float %4429)  ; FMad(a,b,c)
  %4431 = call float @dx.op.tertiary.f32(i32 46, float %4407, float %27, float %4430)  ; FMad(a,b,c)
  %4432 = fadd fast float %4431, %23
  %4433 = fmul fast float %4420, %34
  %4434 = call float @dx.op.tertiary.f32(i32 46, float %4421, float %30, float %4433)  ; FMad(a,b,c)
  %4435 = call float @dx.op.tertiary.f32(i32 46, float %4407, float %26, float %4434)  ; FMad(a,b,c)
  %4436 = fadd fast float %4435, %22
  %4437 = fmul fast float %4420, %33
  %4438 = call float @dx.op.tertiary.f32(i32 46, float %4421, float %29, float %4437)  ; FMad(a,b,c)
  %4439 = call float @dx.op.tertiary.f32(i32 46, float %4407, float %25, float %4438)  ; FMad(a,b,c)
  %4440 = fadd fast float %4439, %21
  %4441 = fdiv fast float %4440, %4425
  %4442 = fdiv fast float %4436, %4425
  %4443 = fdiv fast float %4432, %4425
  %4444 = fsub fast float %4441, %18
  %4445 = fsub fast float %4442, %19
  %4446 = fsub fast float %4443, %20
  %4447 = fmul fast float %4444, %4444
  %4448 = fmul fast float %4445, %4445
  %4449 = fadd fast float %4448, %4447
  %4450 = fmul fast float %4446, %4446
  %4451 = fadd fast float %4449, %4450
  %4452 = call float @dx.op.unary.f32(i32 24, float %4451)  ; Sqrt(value)
  %4453 = fsub fast float %4452, %10
  %4454 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4453)  ; FMax(a,b)
  %4455 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %4455, label %4456, label %4479

; <label>:4456                                    ; preds = %4428
  %4457 = call float @dx.op.unary.f32(i32 6, float %4445)  ; FAbs(value)
  %4458 = fmul fast float %4457, %12
  %4459 = fcmp fast olt float %4458, 0x3F50624DE0000000
  br i1 %4459, label %4460, label %4463

; <label>:4460                                    ; preds = %4456
  %4461 = fmul fast float %4458, 5.000000e-01
  %4462 = fsub fast float 1.000000e+00, %4461
  br label %4468

; <label>:4463                                    ; preds = %4456
  %4464 = fmul fast float %4458, 0xBFF7154760000000
  %4465 = call float @dx.op.unary.f32(i32 21, float %4464)  ; Exp(value)
  %4466 = fsub fast float 1.000000e+00, %4465
  %4467 = fdiv fast float %4466, %4458
  br label %4468

; <label>:4468                                    ; preds = %4463, %4460
  %4469 = phi float [ %4462, %4460 ], [ %4467, %4463 ]
  %4470 = call float @dx.op.binary.f32(i32 36, float %4442, float %19)  ; FMin(a,b)
  %4471 = fsub fast float %4470, %11
  %4472 = fmul fast float %12, %4471
  %4473 = fsub fast float -0.000000e+00, %4472
  %4474 = call float @dx.op.binary.f32(i32 35, float %4473, float -4.000000e+01)  ; FMax(a,b)
  %4475 = call float @dx.op.binary.f32(i32 36, float %4474, float 5.000000e+00)  ; FMin(a,b)
  %4476 = fmul fast float %4475, 0x3FF7154760000000
  %4477 = call float @dx.op.unary.f32(i32 21, float %4476)  ; Exp(value)
  %4478 = fmul fast float %4477, %4469
  br label %4479

; <label>:4479                                    ; preds = %4468, %4428
  %4480 = phi float [ %4478, %4468 ], [ 1.000000e+00, %4428 ]
  %4481 = fmul fast float %4454, %17
  %4482 = fmul fast float %4481, %4480
  %4483 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4482)  ; FMin(a,b)
  %4484 = fmul fast float %4483, 0xBFF7154760000000
  %4485 = call float @dx.op.unary.f32(i32 21, float %4484)  ; Exp(value)
  %4486 = fsub fast float 1.000000e+00, %4485
  %4487 = call float @dx.op.binary.f32(i32 36, float %13, float %4486)  ; FMin(a,b)
  %4488 = fsub fast float %14, %4366
  %4489 = fsub fast float %15, %4367
  %4490 = fsub fast float %16, %4368
  %4491 = fmul fast float %4487, %4488
  %4492 = fmul fast float %4487, %4489
  %4493 = fmul fast float %4487, %4490
  %4494 = fadd fast float %4491, %4366
  %4495 = fadd fast float %4492, %4367
  %4496 = fadd fast float %4493, %4368
  br label %4497

; <label>:4497                                    ; preds = %4479, %4411, %4405
  %4498 = phi float [ %4494, %4479 ], [ %4366, %4411 ], [ %4366, %4405 ]
  %4499 = phi float [ %4495, %4479 ], [ %4367, %4411 ], [ %4367, %4405 ]
  %4500 = phi float [ %4496, %4479 ], [ %4368, %4411 ], [ %4368, %4405 ]
  %4501 = fadd fast float %6, 1.000000e+00
  %4502 = fadd fast float %7, 1.000000e+00
  %4503 = fsub fast float 1.000000e+00, %6
  %4504 = fmul fast float %37, %4501
  %4505 = fmul fast float %37, %4502
  %4506 = fmul fast float %37, %4503
  %4507 = fmul fast float %4504, %4498
  %4508 = fmul fast float %4505, %4499
  %4509 = fmul fast float %4506, %4500
  %4510 = fcmp fast ult float %38, 5.000000e-01
  br i1 %4510, label %4536, label %4511

; <label>:4511                                    ; preds = %4497
  %4512 = fmul fast float %4507, 0x4004147AE0000000
  %4513 = fmul fast float %4508, 0x4004147AE0000000
  %4514 = fmul fast float %4509, 0x4004147AE0000000
  %4515 = fadd fast float %4512, 0x3F9EB851E0000000
  %4516 = fadd fast float %4513, 0x3F9EB851E0000000
  %4517 = fadd fast float %4514, 0x3F9EB851E0000000
  %4518 = fmul fast float %4515, %4507
  %4519 = fmul fast float %4516, %4508
  %4520 = fmul fast float %4517, %4509
  %4521 = fmul fast float %4507, 0x400370A3E0000000
  %4522 = fmul fast float %4508, 0x400370A3E0000000
  %4523 = fmul fast float %4509, 0x400370A3E0000000
  %4524 = fadd fast float %4521, 0x3FE2E147A0000000
  %4525 = fadd fast float %4522, 0x3FE2E147A0000000
  %4526 = fadd fast float %4523, 0x3FE2E147A0000000
  %4527 = fmul fast float %4524, %4507
  %4528 = fmul fast float %4525, %4508
  %4529 = fmul fast float %4526, %4509
  %4530 = fadd fast float %4527, 0x3FC1EB8520000000
  %4531 = fadd fast float %4528, 0x3FC1EB8520000000
  %4532 = fadd fast float %4529, 0x3FC1EB8520000000
  %4533 = fdiv fast float %4518, %4530
  %4534 = fdiv fast float %4519, %4531
  %4535 = fdiv fast float %4520, %4532
  br label %4536

; <label>:4536                                    ; preds = %4511, %4497
  %4537 = phi float [ %4533, %4511 ], [ %4507, %4497 ]
  %4538 = phi float [ %4534, %4511 ], [ %4508, %4497 ]
  %4539 = phi float [ %4535, %4511 ], [ %4509, %4497 ]
  %4540 = call float @dx.op.unary.f32(i32 7, float %4537)  ; Saturate(value)
  %4541 = call float @dx.op.unary.f32(i32 7, float %4538)  ; Saturate(value)
  %4542 = call float @dx.op.unary.f32(i32 7, float %4539)  ; Saturate(value)
  %4543 = call float @dx.op.dot3.f32(i32 55, float %4540, float %4541, float %4542, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4544 = fsub fast float %4540, %4543
  %4545 = fsub fast float %4541, %4543
  %4546 = fsub fast float %4542, %4543
  %4547 = fmul fast float %4544, %9
  %4548 = fmul fast float %4545, %9
  %4549 = fmul fast float %4546, %9
  %4550 = fadd fast float %4547, %4543
  %4551 = fadd fast float %4548, %4543
  %4552 = fadd fast float %4549, %4543
  %4553 = call float @dx.op.unary.f32(i32 7, float %4550)  ; Saturate(value)
  %4554 = call float @dx.op.unary.f32(i32 7, float %4551)  ; Saturate(value)
  %4555 = call float @dx.op.unary.f32(i32 7, float %4552)  ; Saturate(value)
  %4556 = fadd fast float %4553, 0xBFC70A3D80000000
  %4557 = fadd fast float %4554, 0xBFC70A3D80000000
  %4558 = fadd fast float %4555, 0xBFC70A3D80000000
  %4559 = fmul fast float %4556, %8
  %4560 = fmul fast float %4557, %8
  %4561 = fmul fast float %4558, %8
  %4562 = fadd fast float %4559, 0x3FC70A3D80000000
  %4563 = fadd fast float %4560, 0x3FC70A3D80000000
  %4564 = fadd fast float %4561, 0x3FC70A3D80000000
  %4565 = call float @dx.op.unary.f32(i32 7, float %4562)  ; Saturate(value)
  %4566 = call float @dx.op.unary.f32(i32 7, float %4563)  ; Saturate(value)
  %4567 = call float @dx.op.unary.f32(i32 7, float %4564)  ; Saturate(value)
  br label %4568

; <label>:4568                                    ; preds = %4536, %4371
  %4569 = phi float [ %4402, %4371 ], [ %4565, %4536 ]
  %4570 = phi float [ %4403, %4371 ], [ %4566, %4536 ]
  %4571 = phi float [ %4404, %4371 ], [ %4567, %4536 ]
  %4572 = call float @dx.op.binary.f32(i32 36, float %4359, float %4569)  ; FMin(a,b)
  %4573 = call float @dx.op.binary.f32(i32 36, float %4360, float %4570)  ; FMin(a,b)
  %4574 = call float @dx.op.binary.f32(i32 36, float %4361, float %4571)  ; FMin(a,b)
  %4575 = call float @dx.op.binary.f32(i32 36, float %3937, float %4147)  ; FMin(a,b)
  %4576 = call float @dx.op.binary.f32(i32 36, float %3938, float %4148)  ; FMin(a,b)
  %4577 = call float @dx.op.binary.f32(i32 36, float %3939, float %4149)  ; FMin(a,b)
  %4578 = call float @dx.op.binary.f32(i32 36, float %4575, float %4572)  ; FMin(a,b)
  %4579 = call float @dx.op.binary.f32(i32 36, float %4576, float %4573)  ; FMin(a,b)
  %4580 = call float @dx.op.binary.f32(i32 36, float %4577, float %4574)  ; FMin(a,b)
  %4581 = call float @dx.op.binary.f32(i32 36, float %3723, float %4578)  ; FMin(a,b)
  %4582 = call float @dx.op.binary.f32(i32 36, float %3724, float %4579)  ; FMin(a,b)
  %4583 = call float @dx.op.binary.f32(i32 36, float %3725, float %4580)  ; FMin(a,b)
  %4584 = call float @dx.op.binary.f32(i32 35, float %4359, float %4569)  ; FMax(a,b)
  %4585 = call float @dx.op.binary.f32(i32 35, float %4360, float %4570)  ; FMax(a,b)
  %4586 = call float @dx.op.binary.f32(i32 35, float %4361, float %4571)  ; FMax(a,b)
  %4587 = call float @dx.op.binary.f32(i32 35, float %3937, float %4147)  ; FMax(a,b)
  %4588 = call float @dx.op.binary.f32(i32 35, float %3938, float %4148)  ; FMax(a,b)
  %4589 = call float @dx.op.binary.f32(i32 35, float %3939, float %4149)  ; FMax(a,b)
  %4590 = call float @dx.op.binary.f32(i32 35, float %4587, float %4584)  ; FMax(a,b)
  %4591 = call float @dx.op.binary.f32(i32 35, float %4588, float %4585)  ; FMax(a,b)
  %4592 = call float @dx.op.binary.f32(i32 35, float %4589, float %4586)  ; FMax(a,b)
  %4593 = call float @dx.op.binary.f32(i32 35, float %3723, float %4590)  ; FMax(a,b)
  %4594 = call float @dx.op.binary.f32(i32 35, float %3724, float %4591)  ; FMax(a,b)
  %4595 = call float @dx.op.binary.f32(i32 35, float %3725, float %4592)  ; FMax(a,b)
  %4596 = fsub fast float %4593, %4581
  %4597 = fsub fast float %4594, %4582
  %4598 = fsub fast float %4595, %4583
  %4599 = call float @dx.op.unary.f32(i32 6, float %4596)  ; FAbs(value)
  %4600 = call float @dx.op.unary.f32(i32 6, float %4597)  ; FAbs(value)
  %4601 = call float @dx.op.unary.f32(i32 6, float %4598)  ; FAbs(value)
  %4602 = call float @dx.op.binary.f32(i32 35, float %4600, float %4601)  ; FMax(a,b)
  %4603 = call float @dx.op.binary.f32(i32 35, float %4599, float %4602)  ; FMax(a,b)
  %4604 = call float @dx.op.binary.f32(i32 35, float %4594, float %4595)  ; FMax(a,b)
  %4605 = call float @dx.op.binary.f32(i32 35, float %4593, float %4604)  ; FMax(a,b)
  %4606 = fmul fast float %4605, 1.250000e-01
  %4607 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %4606)  ; FMax(a,b)
  %4608 = fcmp fast ogt float %4603, %4607
  br i1 %4608, label %4609, label %4671

; <label>:4609                                    ; preds = %4568
  %4610 = fsub fast float %3937, %4147
  %4611 = fsub fast float %3938, %4148
  %4612 = fsub fast float %3939, %4149
  %4613 = call float @dx.op.unary.f32(i32 6, float %4610)  ; FAbs(value)
  %4614 = call float @dx.op.unary.f32(i32 6, float %4611)  ; FAbs(value)
  %4615 = call float @dx.op.unary.f32(i32 6, float %4612)  ; FAbs(value)
  %4616 = call float @dx.op.binary.f32(i32 35, float %4614, float %4615)  ; FMax(a,b)
  %4617 = call float @dx.op.binary.f32(i32 35, float %4613, float %4616)  ; FMax(a,b)
  %4618 = fsub fast float %4359, %4569
  %4619 = fsub fast float %4360, %4570
  %4620 = fsub fast float %4361, %4571
  %4621 = call float @dx.op.unary.f32(i32 6, float %4618)  ; FAbs(value)
  %4622 = call float @dx.op.unary.f32(i32 6, float %4619)  ; FAbs(value)
  %4623 = call float @dx.op.unary.f32(i32 6, float %4620)  ; FAbs(value)
  %4624 = call float @dx.op.binary.f32(i32 35, float %4622, float %4623)  ; FMax(a,b)
  %4625 = call float @dx.op.binary.f32(i32 35, float %4621, float %4624)  ; FMax(a,b)
  %4626 = fcmp fast olt float %4617, %4625
  %4627 = select i1 %4626, float %3937, float %4359
  %4628 = select i1 %4626, float %3938, float %4360
  %4629 = select i1 %4626, float %3939, float %4361
  %4630 = select i1 %4626, float %4147, float %4569
  %4631 = select i1 %4626, float %4148, float %4570
  %4632 = select i1 %4626, float %4149, float %4571
  %4633 = fsub fast float %3723, %4630
  %4634 = fsub fast float %3724, %4631
  %4635 = fsub fast float %3725, %4632
  %4636 = fsub fast float %3723, %4627
  %4637 = fsub fast float %3724, %4628
  %4638 = fsub fast float %3725, %4629
  %4639 = call float @dx.op.dot3.f32(i32 55, float %4636, float %4637, float %4638, float %4633, float %4634, float %4635)  ; Dot3(ax,ay,az,bx,by,bz)
  %4640 = fcmp fast ogt float %4639, 0.000000e+00
  br i1 %4640, label %4641, label %4653

; <label>:4641                                    ; preds = %4609
  %4642 = fsub fast float %4627, %4630
  %4643 = fsub fast float %4628, %4631
  %4644 = fsub fast float %4629, %4632
  %4645 = call float @dx.op.unary.f32(i32 6, float %4642)  ; FAbs(value)
  %4646 = call float @dx.op.unary.f32(i32 6, float %4643)  ; FAbs(value)
  %4647 = call float @dx.op.unary.f32(i32 6, float %4644)  ; FAbs(value)
  %4648 = call float @dx.op.binary.f32(i32 35, float %4646, float %4647)  ; FMax(a,b)
  %4649 = call float @dx.op.binary.f32(i32 35, float %4645, float %4648)  ; FMax(a,b)
  %4650 = fmul fast float %4603, 2.500000e-01
  %4651 = fcmp fast olt float %4649, %4650
  %4652 = select i1 %4651, float 5.000000e-01, float 1.000000e+00
  br label %4653

; <label>:4653                                    ; preds = %4641, %4609
  %4654 = phi float [ 1.000000e+00, %4609 ], [ %4652, %4641 ]
  %4655 = fmul fast float %4654, %3
  %4656 = fadd fast float %4627, %4630
  %4657 = fadd fast float %4628, %4631
  %4658 = fadd fast float %4629, %4632
  %4659 = fmul fast float %4656, 5.000000e-01
  %4660 = fmul fast float %4657, 5.000000e-01
  %4661 = fmul fast float %4658, 5.000000e-01
  %4662 = fsub fast float %4659, %3723
  %4663 = fsub fast float %4660, %3724
  %4664 = fsub fast float %4661, %3725
  %4665 = fmul fast float %4655, %4662
  %4666 = fmul fast float %4655, %4663
  %4667 = fmul fast float %4655, %4664
  %4668 = fadd fast float %4665, %3723
  %4669 = fadd fast float %4666, %3724
  %4670 = fadd fast float %4667, %3725
  br label %4671

; <label>:4671                                    ; preds = %4653, %4568, %3694
  %4672 = phi float [ %4668, %4653 ], [ %3723, %4568 ], [ %3723, %3694 ]
  %4673 = phi float [ %4669, %4653 ], [ %3724, %4568 ], [ %3724, %3694 ]
  %4674 = phi float [ %4670, %4653 ], [ %3725, %4568 ], [ %3725, %3694 ]
  %4675 = fcmp fast ogt float %4672, 0x3F69A5C380000000
  %4676 = fcmp fast ogt float %4673, 0x3F69A5C380000000
  %4677 = fcmp fast ogt float %4674, 0x3F69A5C380000000
  %4678 = select i1 %4675, float 0.000000e+00, float 1.000000e+00
  %4679 = select i1 %4676, float 0.000000e+00, float 1.000000e+00
  %4680 = select i1 %4677, float 0.000000e+00, float 1.000000e+00
  %4681 = fmul fast float %4672, 0x4029D70A40000000
  %4682 = fmul fast float %4673, 0x4029D70A40000000
  %4683 = fmul fast float %4674, 0x4029D70A40000000
  %4684 = call float @dx.op.binary.f32(i32 35, float %4672, float 0.000000e+00)  ; FMax(a,b)
  %4685 = call float @dx.op.binary.f32(i32 35, float %4673, float 0.000000e+00)  ; FMax(a,b)
  %4686 = call float @dx.op.binary.f32(i32 35, float %4674, float 0.000000e+00)  ; FMax(a,b)
  %4687 = call float @dx.op.unary.f32(i32 23, float %4684)  ; Log(value)
  %4688 = call float @dx.op.unary.f32(i32 23, float %4685)  ; Log(value)
  %4689 = call float @dx.op.unary.f32(i32 23, float %4686)  ; Log(value)
  %4690 = fmul fast float %4687, 0x3FDAAAAAA0000000
  %4691 = fmul fast float %4688, 0x3FDAAAAAA0000000
  %4692 = fmul fast float %4689, 0x3FDAAAAAA0000000
  %4693 = call float @dx.op.unary.f32(i32 21, float %4690)  ; Exp(value)
  %4694 = call float @dx.op.unary.f32(i32 21, float %4691)  ; Exp(value)
  %4695 = call float @dx.op.unary.f32(i32 21, float %4692)  ; Exp(value)
  %4696 = fmul fast float %4693, 0x3FF0E147A0000000
  %4697 = fmul fast float %4694, 0x3FF0E147A0000000
  %4698 = fmul fast float %4695, 0x3FF0E147A0000000
  %4699 = fadd fast float %4696, 0xBFAC28F5C0000000
  %4700 = fadd fast float %4697, 0xBFAC28F5C0000000
  %4701 = fadd fast float %4698, 0xBFAC28F5C0000000
  %4702 = fsub fast float %4681, %4699
  %4703 = fsub fast float %4682, %4700
  %4704 = fsub fast float %4683, %4701
  %4705 = fmul fast float %4702, %4678
  %4706 = fmul fast float %4703, %4679
  %4707 = fmul fast float %4704, %4680
  %4708 = fadd fast float %4705, %4699
  %4709 = fadd fast float %4706, %4700
  %4710 = fadd fast float %4707, %4701
  br label %4711

; <label>:4711                                    ; preds = %4671, %3561
  %4712 = phi float [ %3556, %3561 ], [ %4708, %4671 ]
  %4713 = phi float [ %3557, %3561 ], [ %4709, %4671 ]
  %4714 = phi float [ %3558, %3561 ], [ %4710, %4671 ]
  %4715 = phi float [ %3562, %3561 ], [ %3559, %4671 ]
  %4716 = call float @dx.op.unary.f32(i32 27, float %50)  ; Round_ni(value)
  %4717 = call float @dx.op.unary.f32(i32 27, float %51)  ; Round_ni(value)
  %4718 = fptosi float %4716 to i32
  %4719 = fptosi float %4717 to i32
  %4720 = call i32 @dx.op.binary.i32(i32 37, i32 %4718, i32 0)  ; IMax(a,b)
  %4721 = call i32 @dx.op.binary.i32(i32 37, i32 %4719, i32 0)  ; IMax(a,b)
  %4722 = call i32 @dx.op.binary.i32(i32 38, i32 %4720, i32 %60)  ; IMin(a,b)
  %4723 = call i32 @dx.op.binary.i32(i32 38, i32 %4721, i32 %61)  ; IMin(a,b)
  %4724 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4722, i32 %4723, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4725 = extractvalue %dx.types.ResRet.f32 %4724, 0
  %4726 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %64, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4727 = extractvalue %dx.types.ResRet.f32 %4726, 0
  %4728 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1229, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4729 = extractvalue %dx.types.ResRet.f32 %4728, 0
  %4730 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %64, i32 %2393, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4731 = extractvalue %dx.types.ResRet.f32 %4730, 0
  %4732 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1229, i32 %2393, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4733 = extractvalue %dx.types.ResRet.f32 %4732, 0
  %4734 = fsub fast float 1.000000e+00, %58
  %4735 = fsub fast float 1.000000e+00, %59
  %4736 = fmul fast float %4735, %4734
  %4737 = fmul fast float %4735, %58
  %4738 = fmul fast float %4734, %59
  %4739 = fmul fast float %59, %58
  %4740 = fsub fast float 1.000000e+00, %4725
  %4741 = fmul fast float %4740, 0x3FA99999A0000000
  %4742 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %4741)  ; FMax(a,b)
  %4743 = fsub fast float %4727, %4725
  %4744 = fsub fast float %4729, %4725
  %4745 = fsub fast float %4731, %4725
  %4746 = fsub fast float %4733, %4725
  %4747 = call float @dx.op.unary.f32(i32 6, float %4743)  ; FAbs(value)
  %4748 = call float @dx.op.unary.f32(i32 6, float %4744)  ; FAbs(value)
  %4749 = call float @dx.op.unary.f32(i32 6, float %4745)  ; FAbs(value)
  %4750 = call float @dx.op.unary.f32(i32 6, float %4746)  ; FAbs(value)
  %4751 = fdiv fast float %4747, %4742
  %4752 = fdiv fast float %4748, %4742
  %4753 = fdiv fast float %4749, %4742
  %4754 = fdiv fast float %4750, %4742
  %4755 = fsub fast float 1.000000e+00, %4751
  %4756 = fsub fast float 1.000000e+00, %4752
  %4757 = fsub fast float 1.000000e+00, %4753
  %4758 = fsub fast float 1.000000e+00, %4754
  %4759 = call float @dx.op.unary.f32(i32 7, float %4755)  ; Saturate(value)
  %4760 = call float @dx.op.unary.f32(i32 7, float %4756)  ; Saturate(value)
  %4761 = call float @dx.op.unary.f32(i32 7, float %4757)  ; Saturate(value)
  %4762 = call float @dx.op.unary.f32(i32 7, float %4758)  ; Saturate(value)
  %4763 = fmul fast float %4736, %4759
  %4764 = fmul fast float %4737, %4760
  %4765 = fmul fast float %4738, %4761
  %4766 = fmul fast float %4739, %4762
  %4767 = call float @dx.op.dot4.f32(i32 56, float %4763, float %4764, float %4765, float %4766, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %4768 = call float @dx.op.binary.f32(i32 35, float %4767, float 0x3EE4F8B580000000)  ; FMax(a,b)
  %4769 = fdiv fast float %4763, %4768
  %4770 = fdiv fast float %4764, %4768
  %4771 = fdiv fast float %4765, %4768
  %4772 = fdiv fast float %4766, %4768
  %4773 = fcmp fast ogt float %1223, 0x3FA4B5DCC0000000
  %4774 = fcmp fast ogt float %1224, 0x3FA4B5DCC0000000
  %4775 = fcmp fast ogt float %1225, 0x3FA4B5DCC0000000
  %4776 = select i1 %4773, float 0.000000e+00, float 1.000000e+00
  %4777 = select i1 %4774, float 0.000000e+00, float 1.000000e+00
  %4778 = select i1 %4775, float 0.000000e+00, float 1.000000e+00
  %4779 = fmul fast float %1223, 0x3FB3D07220000000
  %4780 = fmul fast float %1224, 0x3FB3D07220000000
  %4781 = fmul fast float %1225, 0x3FB3D07220000000
  %4782 = fadd fast float %1223, 0x3FAC28F5C0000000
  %4783 = fadd fast float %1224, 0x3FAC28F5C0000000
  %4784 = fadd fast float %1225, 0x3FAC28F5C0000000
  %4785 = fmul fast float %4782, 0x3FEE54EDE0000000
  %4786 = fmul fast float %4783, 0x3FEE54EDE0000000
  %4787 = fmul fast float %4784, 0x3FEE54EDE0000000
  %4788 = call float @dx.op.unary.f32(i32 23, float %4785)  ; Log(value)
  %4789 = call float @dx.op.unary.f32(i32 23, float %4786)  ; Log(value)
  %4790 = call float @dx.op.unary.f32(i32 23, float %4787)  ; Log(value)
  %4791 = fmul fast float %4788, 0x4003333340000000
  %4792 = fmul fast float %4789, 0x4003333340000000
  %4793 = fmul fast float %4790, 0x4003333340000000
  %4794 = call float @dx.op.unary.f32(i32 21, float %4791)  ; Exp(value)
  %4795 = call float @dx.op.unary.f32(i32 21, float %4792)  ; Exp(value)
  %4796 = call float @dx.op.unary.f32(i32 21, float %4793)  ; Exp(value)
  %4797 = fsub fast float %4779, %4794
  %4798 = fsub fast float %4780, %4795
  %4799 = fsub fast float %4781, %4796
  %4800 = fmul fast float %4797, %4776
  %4801 = fmul fast float %4798, %4777
  %4802 = fmul fast float %4799, %4778
  %4803 = fadd fast float %4800, %4794
  %4804 = fadd fast float %4801, %4795
  %4805 = fadd fast float %4802, %4796
  %4806 = fmul fast float %4803, %4769
  %4807 = fmul fast float %4804, %4769
  %4808 = fmul fast float %4805, %4769
  %4809 = fcmp fast ogt float %2387, 0x3FA4B5DCC0000000
  %4810 = fcmp fast ogt float %2388, 0x3FA4B5DCC0000000
  %4811 = fcmp fast ogt float %2389, 0x3FA4B5DCC0000000
  %4812 = select i1 %4809, float 0.000000e+00, float 1.000000e+00
  %4813 = select i1 %4810, float 0.000000e+00, float 1.000000e+00
  %4814 = select i1 %4811, float 0.000000e+00, float 1.000000e+00
  %4815 = fmul fast float %2387, 0x3FB3D07220000000
  %4816 = fmul fast float %2388, 0x3FB3D07220000000
  %4817 = fmul fast float %2389, 0x3FB3D07220000000
  %4818 = fadd fast float %2387, 0x3FAC28F5C0000000
  %4819 = fadd fast float %2388, 0x3FAC28F5C0000000
  %4820 = fadd fast float %2389, 0x3FAC28F5C0000000
  %4821 = fmul fast float %4818, 0x3FEE54EDE0000000
  %4822 = fmul fast float %4819, 0x3FEE54EDE0000000
  %4823 = fmul fast float %4820, 0x3FEE54EDE0000000
  %4824 = call float @dx.op.unary.f32(i32 23, float %4821)  ; Log(value)
  %4825 = call float @dx.op.unary.f32(i32 23, float %4822)  ; Log(value)
  %4826 = call float @dx.op.unary.f32(i32 23, float %4823)  ; Log(value)
  %4827 = fmul fast float %4824, 0x4003333340000000
  %4828 = fmul fast float %4825, 0x4003333340000000
  %4829 = fmul fast float %4826, 0x4003333340000000
  %4830 = call float @dx.op.unary.f32(i32 21, float %4827)  ; Exp(value)
  %4831 = call float @dx.op.unary.f32(i32 21, float %4828)  ; Exp(value)
  %4832 = call float @dx.op.unary.f32(i32 21, float %4829)  ; Exp(value)
  %4833 = fsub fast float %4815, %4830
  %4834 = fsub fast float %4816, %4831
  %4835 = fsub fast float %4817, %4832
  %4836 = fmul fast float %4833, %4812
  %4837 = fmul fast float %4834, %4813
  %4838 = fmul fast float %4835, %4814
  %4839 = fadd fast float %4836, %4830
  %4840 = fadd fast float %4837, %4831
  %4841 = fadd fast float %4838, %4832
  %4842 = fmul fast float %4839, %4770
  %4843 = fmul fast float %4840, %4770
  %4844 = fmul fast float %4841, %4770
  %4845 = fadd fast float %4842, %4806
  %4846 = fadd fast float %4843, %4807
  %4847 = fadd fast float %4844, %4808
  %4848 = fcmp fast ogt float %3551, 0x3FA4B5DCC0000000
  %4849 = fcmp fast ogt float %3552, 0x3FA4B5DCC0000000
  %4850 = fcmp fast ogt float %3553, 0x3FA4B5DCC0000000
  %4851 = select i1 %4848, float 0.000000e+00, float 1.000000e+00
  %4852 = select i1 %4849, float 0.000000e+00, float 1.000000e+00
  %4853 = select i1 %4850, float 0.000000e+00, float 1.000000e+00
  %4854 = fmul fast float %3551, 0x3FB3D07220000000
  %4855 = fmul fast float %3552, 0x3FB3D07220000000
  %4856 = fmul fast float %3553, 0x3FB3D07220000000
  %4857 = fadd fast float %3551, 0x3FAC28F5C0000000
  %4858 = fadd fast float %3552, 0x3FAC28F5C0000000
  %4859 = fadd fast float %3553, 0x3FAC28F5C0000000
  %4860 = fmul fast float %4857, 0x3FEE54EDE0000000
  %4861 = fmul fast float %4858, 0x3FEE54EDE0000000
  %4862 = fmul fast float %4859, 0x3FEE54EDE0000000
  %4863 = call float @dx.op.unary.f32(i32 23, float %4860)  ; Log(value)
  %4864 = call float @dx.op.unary.f32(i32 23, float %4861)  ; Log(value)
  %4865 = call float @dx.op.unary.f32(i32 23, float %4862)  ; Log(value)
  %4866 = fmul fast float %4863, 0x4003333340000000
  %4867 = fmul fast float %4864, 0x4003333340000000
  %4868 = fmul fast float %4865, 0x4003333340000000
  %4869 = call float @dx.op.unary.f32(i32 21, float %4866)  ; Exp(value)
  %4870 = call float @dx.op.unary.f32(i32 21, float %4867)  ; Exp(value)
  %4871 = call float @dx.op.unary.f32(i32 21, float %4868)  ; Exp(value)
  %4872 = fsub fast float %4854, %4869
  %4873 = fsub fast float %4855, %4870
  %4874 = fsub fast float %4856, %4871
  %4875 = fmul fast float %4872, %4851
  %4876 = fmul fast float %4873, %4852
  %4877 = fmul fast float %4874, %4853
  %4878 = fadd fast float %4875, %4869
  %4879 = fadd fast float %4876, %4870
  %4880 = fadd fast float %4877, %4871
  %4881 = fmul fast float %4878, %4771
  %4882 = fmul fast float %4879, %4771
  %4883 = fmul fast float %4880, %4771
  %4884 = fadd fast float %4845, %4881
  %4885 = fadd fast float %4846, %4882
  %4886 = fadd fast float %4847, %4883
  %4887 = fcmp fast ogt float %4712, 0x3FA4B5DCC0000000
  %4888 = fcmp fast ogt float %4713, 0x3FA4B5DCC0000000
  %4889 = fcmp fast ogt float %4714, 0x3FA4B5DCC0000000
  %4890 = select i1 %4887, float 0.000000e+00, float 1.000000e+00
  %4891 = select i1 %4888, float 0.000000e+00, float 1.000000e+00
  %4892 = select i1 %4889, float 0.000000e+00, float 1.000000e+00
  %4893 = fmul fast float %4712, 0x3FB3D07220000000
  %4894 = fmul fast float %4713, 0x3FB3D07220000000
  %4895 = fmul fast float %4714, 0x3FB3D07220000000
  %4896 = fadd fast float %4712, 0x3FAC28F5C0000000
  %4897 = fadd fast float %4713, 0x3FAC28F5C0000000
  %4898 = fadd fast float %4714, 0x3FAC28F5C0000000
  %4899 = fmul fast float %4896, 0x3FEE54EDE0000000
  %4900 = fmul fast float %4897, 0x3FEE54EDE0000000
  %4901 = fmul fast float %4898, 0x3FEE54EDE0000000
  %4902 = call float @dx.op.unary.f32(i32 23, float %4899)  ; Log(value)
  %4903 = call float @dx.op.unary.f32(i32 23, float %4900)  ; Log(value)
  %4904 = call float @dx.op.unary.f32(i32 23, float %4901)  ; Log(value)
  %4905 = fmul fast float %4902, 0x4003333340000000
  %4906 = fmul fast float %4903, 0x4003333340000000
  %4907 = fmul fast float %4904, 0x4003333340000000
  %4908 = call float @dx.op.unary.f32(i32 21, float %4905)  ; Exp(value)
  %4909 = call float @dx.op.unary.f32(i32 21, float %4906)  ; Exp(value)
  %4910 = call float @dx.op.unary.f32(i32 21, float %4907)  ; Exp(value)
  %4911 = fsub fast float %4893, %4908
  %4912 = fsub fast float %4894, %4909
  %4913 = fsub fast float %4895, %4910
  %4914 = fmul fast float %4911, %4890
  %4915 = fmul fast float %4912, %4891
  %4916 = fmul fast float %4913, %4892
  %4917 = fadd fast float %4914, %4908
  %4918 = fadd fast float %4915, %4909
  %4919 = fadd fast float %4916, %4910
  %4920 = fmul fast float %4917, %4772
  %4921 = fmul fast float %4918, %4772
  %4922 = fmul fast float %4919, %4772
  %4923 = fadd fast float %4884, %4920
  %4924 = fadd fast float %4885, %4921
  %4925 = fadd fast float %4886, %4922
  %4926 = fcmp fast ogt float %4923, 0x3F69A5C380000000
  %4927 = fcmp fast ogt float %4924, 0x3F69A5C380000000
  %4928 = fcmp fast ogt float %4925, 0x3F69A5C380000000
  %4929 = select i1 %4926, float 0.000000e+00, float 1.000000e+00
  %4930 = select i1 %4927, float 0.000000e+00, float 1.000000e+00
  %4931 = select i1 %4928, float 0.000000e+00, float 1.000000e+00
  %4932 = fmul fast float %4923, 0x4029D70A40000000
  %4933 = fmul fast float %4924, 0x4029D70A40000000
  %4934 = fmul fast float %4925, 0x4029D70A40000000
  %4935 = call float @dx.op.binary.f32(i32 35, float %4923, float 0.000000e+00)  ; FMax(a,b)
  %4936 = call float @dx.op.binary.f32(i32 35, float %4924, float 0.000000e+00)  ; FMax(a,b)
  %4937 = call float @dx.op.binary.f32(i32 35, float %4925, float 0.000000e+00)  ; FMax(a,b)
  %4938 = call float @dx.op.unary.f32(i32 23, float %4935)  ; Log(value)
  %4939 = call float @dx.op.unary.f32(i32 23, float %4936)  ; Log(value)
  %4940 = call float @dx.op.unary.f32(i32 23, float %4937)  ; Log(value)
  %4941 = fmul fast float %4938, 0x3FDAAAAAA0000000
  %4942 = fmul fast float %4939, 0x3FDAAAAAA0000000
  %4943 = fmul fast float %4940, 0x3FDAAAAAA0000000
  %4944 = call float @dx.op.unary.f32(i32 21, float %4941)  ; Exp(value)
  %4945 = call float @dx.op.unary.f32(i32 21, float %4942)  ; Exp(value)
  %4946 = call float @dx.op.unary.f32(i32 21, float %4943)  ; Exp(value)
  %4947 = fmul fast float %4944, 0x3FF0E147A0000000
  %4948 = fmul fast float %4945, 0x3FF0E147A0000000
  %4949 = fmul fast float %4946, 0x3FF0E147A0000000
  %4950 = fadd fast float %4947, 0xBFAC28F5C0000000
  %4951 = fadd fast float %4948, 0xBFAC28F5C0000000
  %4952 = fadd fast float %4949, 0xBFAC28F5C0000000
  %4953 = fsub fast float %4932, %4950
  %4954 = fsub fast float %4933, %4951
  %4955 = fsub fast float %4934, %4952
  %4956 = fmul fast float %4953, %4929
  %4957 = fmul fast float %4954, %4930
  %4958 = fmul fast float %4955, %4931
  %4959 = fadd fast float %4956, %4950
  %4960 = fadd fast float %4957, %4951
  %4961 = fadd fast float %4958, %4952
  %4962 = call float @dx.op.dot4.f32(i32 56, float %1226, float %2390, float %3554, float %4715, float %4769, float %4770, float %4771, float %4772)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %4959)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %4960)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %4961)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %4962)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %4725)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !37, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, !28}
!36 = !{i32 9}
!37 = !{!38, !39}
!38 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
!39 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !40}
!40 = !{i32 3, i32 1}
