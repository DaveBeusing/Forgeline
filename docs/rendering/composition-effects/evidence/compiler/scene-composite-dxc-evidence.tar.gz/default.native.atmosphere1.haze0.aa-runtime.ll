;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float   x   
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
;
; shader hash: 8d9999eae69d90058cba02692854d4cb
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=0
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 1
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40 }
;   output 3 depends on inputs: { 0, 1 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %40 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %41 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %42 = extractvalue %dx.types.Dimensions %41, 0
  %43 = extractvalue %dx.types.Dimensions %41, 1
  %44 = fptosi float %39 to i32
  %45 = fptosi float %40 to i32
  %46 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %44, i32 %45, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %47 = extractvalue %dx.types.ResRet.f32 %46, 0
  %48 = extractvalue %dx.types.ResRet.f32 %46, 1
  %49 = extractvalue %dx.types.ResRet.f32 %46, 2
  %50 = extractvalue %dx.types.ResRet.f32 %46, 3
  %51 = fcmp fast olt float %50, 0.000000e+00
  br i1 %51, label %52, label %54

; <label>:52                                      ; preds = %0
  %53 = fsub fast float -1.000000e+00, %50
  br label %1226

; <label>:54                                      ; preds = %0
  %55 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %44, i32 %45, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %56 = extractvalue %dx.types.ResRet.f32 %55, 0
  %57 = fcmp fast ogt float %37, 5.000000e-01
  %58 = fcmp fast olt float %56, 1.000000e+00
  %59 = and i1 %57, %58
  br i1 %59, label %60, label %148

; <label>:60                                      ; preds = %54
  %61 = sitofp i32 %44 to float
  %62 = sitofp i32 %45 to float
  %63 = fadd fast float %61, 5.000000e-01
  %64 = fadd fast float %62, 5.000000e-01
  %65 = uitofp i32 %42 to float
  %66 = uitofp i32 %43 to float
  %67 = fdiv fast float %63, %65
  %68 = fdiv fast float %64, %66
  %69 = fmul fast float %67, 2.000000e+00
  %70 = fmul fast float %68, 2.000000e+00
  %71 = fadd fast float %69, -1.000000e+00
  %72 = fsub fast float 1.000000e+00, %70
  %73 = fmul fast float %71, %34
  %74 = call float @dx.op.tertiary.f32(i32 46, float %72, float %30, float %73)  ; FMad(a,b,c)
  %75 = call float @dx.op.tertiary.f32(i32 46, float %56, float %26, float %74)  ; FMad(a,b,c)
  %76 = fadd fast float %75, %22
  %77 = call float @dx.op.unary.f32(i32 6, float %76)  ; FAbs(value)
  %78 = fcmp fast ogt float %77, 0x3EB0C6F7A0000000
  br i1 %78, label %79, label %148

; <label>:79                                      ; preds = %60
  %80 = fmul fast float %71, %33
  %81 = call float @dx.op.tertiary.f32(i32 46, float %72, float %29, float %80)  ; FMad(a,b,c)
  %82 = call float @dx.op.tertiary.f32(i32 46, float %56, float %25, float %81)  ; FMad(a,b,c)
  %83 = fadd fast float %82, %21
  %84 = fmul fast float %71, %32
  %85 = call float @dx.op.tertiary.f32(i32 46, float %72, float %28, float %84)  ; FMad(a,b,c)
  %86 = call float @dx.op.tertiary.f32(i32 46, float %56, float %24, float %85)  ; FMad(a,b,c)
  %87 = fadd fast float %86, %20
  %88 = fmul fast float %71, %31
  %89 = call float @dx.op.tertiary.f32(i32 46, float %72, float %27, float %88)  ; FMad(a,b,c)
  %90 = call float @dx.op.tertiary.f32(i32 46, float %56, float %23, float %89)  ; FMad(a,b,c)
  %91 = fadd fast float %90, %19
  %92 = fdiv fast float %91, %76
  %93 = fdiv fast float %87, %76
  %94 = fdiv fast float %83, %76
  %95 = fsub fast float %92, %16
  %96 = fsub fast float %93, %17
  %97 = fsub fast float %94, %18
  %98 = fmul fast float %95, %95
  %99 = fmul fast float %96, %96
  %100 = fadd fast float %99, %98
  %101 = fmul fast float %97, %97
  %102 = fadd fast float %100, %101
  %103 = call float @dx.op.unary.f32(i32 24, float %102)  ; Sqrt(value)
  %104 = fsub fast float %103, %8
  %105 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %104)  ; FMax(a,b)
  %106 = fcmp fast ogt float %38, 1.500000e+00
  br i1 %106, label %107, label %130

; <label>:107                                     ; preds = %79
  %108 = call float @dx.op.unary.f32(i32 6, float %96)  ; FAbs(value)
  %109 = fmul fast float %108, %10
  %110 = fcmp fast olt float %109, 0x3F50624DE0000000
  br i1 %110, label %111, label %114

; <label>:111                                     ; preds = %107
  %112 = fmul fast float %109, 5.000000e-01
  %113 = fsub fast float 1.000000e+00, %112
  br label %119

; <label>:114                                     ; preds = %107
  %115 = fmul fast float %109, 0xBFF7154760000000
  %116 = call float @dx.op.unary.f32(i32 21, float %115)  ; Exp(value)
  %117 = fsub fast float 1.000000e+00, %116
  %118 = fdiv fast float %117, %109
  br label %119

; <label>:119                                     ; preds = %114, %111
  %120 = phi float [ %113, %111 ], [ %118, %114 ]
  %121 = call float @dx.op.binary.f32(i32 36, float %93, float %17)  ; FMin(a,b)
  %122 = fsub fast float %121, %9
  %123 = fmul fast float %10, %122
  %124 = fsub fast float -0.000000e+00, %123
  %125 = call float @dx.op.binary.f32(i32 35, float %124, float -4.000000e+01)  ; FMax(a,b)
  %126 = call float @dx.op.binary.f32(i32 36, float %125, float 5.000000e+00)  ; FMin(a,b)
  %127 = fmul fast float %126, 0x3FF7154760000000
  %128 = call float @dx.op.unary.f32(i32 21, float %127)  ; Exp(value)
  %129 = fmul fast float %128, %120
  br label %130

; <label>:130                                     ; preds = %119, %79
  %131 = phi float [ %129, %119 ], [ 1.000000e+00, %79 ]
  %132 = fmul fast float %105, %15
  %133 = fmul fast float %132, %131
  %134 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %133)  ; FMin(a,b)
  %135 = fmul fast float %134, 0xBFF7154760000000
  %136 = call float @dx.op.unary.f32(i32 21, float %135)  ; Exp(value)
  %137 = fsub fast float 1.000000e+00, %136
  %138 = call float @dx.op.binary.f32(i32 36, float %11, float %137)  ; FMin(a,b)
  %139 = fsub fast float %12, %47
  %140 = fsub fast float %13, %48
  %141 = fsub fast float %14, %49
  %142 = fmul fast float %138, %139
  %143 = fmul fast float %138, %140
  %144 = fmul fast float %138, %141
  %145 = fadd fast float %142, %47
  %146 = fadd fast float %143, %48
  %147 = fadd fast float %144, %49
  br label %148

; <label>:148                                     ; preds = %130, %60, %54
  %149 = phi float [ %145, %130 ], [ %47, %60 ], [ %47, %54 ]
  %150 = phi float [ %146, %130 ], [ %48, %60 ], [ %48, %54 ]
  %151 = phi float [ %147, %130 ], [ %49, %60 ], [ %49, %54 ]
  %152 = fadd fast float %4, 1.000000e+00
  %153 = fadd fast float %5, 1.000000e+00
  %154 = fsub fast float 1.000000e+00, %4
  %155 = fmul fast float %35, %152
  %156 = fmul fast float %35, %153
  %157 = fmul fast float %35, %154
  %158 = fmul fast float %155, %149
  %159 = fmul fast float %156, %150
  %160 = fmul fast float %157, %151
  %161 = fcmp fast ult float %36, 5.000000e-01
  br i1 %161, label %187, label %162

; <label>:162                                     ; preds = %148
  %163 = fmul fast float %158, 0x4004147AE0000000
  %164 = fmul fast float %159, 0x4004147AE0000000
  %165 = fmul fast float %160, 0x4004147AE0000000
  %166 = fadd fast float %163, 0x3F9EB851E0000000
  %167 = fadd fast float %164, 0x3F9EB851E0000000
  %168 = fadd fast float %165, 0x3F9EB851E0000000
  %169 = fmul fast float %166, %158
  %170 = fmul fast float %167, %159
  %171 = fmul fast float %168, %160
  %172 = fmul fast float %158, 0x400370A3E0000000
  %173 = fmul fast float %159, 0x400370A3E0000000
  %174 = fmul fast float %160, 0x400370A3E0000000
  %175 = fadd fast float %172, 0x3FE2E147A0000000
  %176 = fadd fast float %173, 0x3FE2E147A0000000
  %177 = fadd fast float %174, 0x3FE2E147A0000000
  %178 = fmul fast float %175, %158
  %179 = fmul fast float %176, %159
  %180 = fmul fast float %177, %160
  %181 = fadd fast float %178, 0x3FC1EB8520000000
  %182 = fadd fast float %179, 0x3FC1EB8520000000
  %183 = fadd fast float %180, 0x3FC1EB8520000000
  %184 = fdiv fast float %169, %181
  %185 = fdiv fast float %170, %182
  %186 = fdiv fast float %171, %183
  br label %187

; <label>:187                                     ; preds = %162, %148
  %188 = phi float [ %184, %162 ], [ %158, %148 ]
  %189 = phi float [ %185, %162 ], [ %159, %148 ]
  %190 = phi float [ %186, %162 ], [ %160, %148 ]
  %191 = call float @dx.op.unary.f32(i32 7, float %188)  ; Saturate(value)
  %192 = call float @dx.op.unary.f32(i32 7, float %189)  ; Saturate(value)
  %193 = call float @dx.op.unary.f32(i32 7, float %190)  ; Saturate(value)
  %194 = call float @dx.op.dot3.f32(i32 55, float %191, float %192, float %193, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %195 = fsub fast float %191, %194
  %196 = fsub fast float %192, %194
  %197 = fsub fast float %193, %194
  %198 = fmul fast float %195, %7
  %199 = fmul fast float %196, %7
  %200 = fmul fast float %197, %7
  %201 = fadd fast float %198, %194
  %202 = fadd fast float %199, %194
  %203 = fadd fast float %200, %194
  %204 = call float @dx.op.unary.f32(i32 7, float %201)  ; Saturate(value)
  %205 = call float @dx.op.unary.f32(i32 7, float %202)  ; Saturate(value)
  %206 = call float @dx.op.unary.f32(i32 7, float %203)  ; Saturate(value)
  %207 = fadd fast float %204, 0xBFC70A3D80000000
  %208 = fadd fast float %205, 0xBFC70A3D80000000
  %209 = fadd fast float %206, 0xBFC70A3D80000000
  %210 = fmul fast float %207, %6
  %211 = fmul fast float %208, %6
  %212 = fmul fast float %209, %6
  %213 = fadd fast float %210, 0x3FC70A3D80000000
  %214 = fadd fast float %211, 0x3FC70A3D80000000
  %215 = fadd fast float %212, 0x3FC70A3D80000000
  %216 = call float @dx.op.unary.f32(i32 7, float %213)  ; Saturate(value)
  %217 = call float @dx.op.unary.f32(i32 7, float %214)  ; Saturate(value)
  %218 = call float @dx.op.unary.f32(i32 7, float %215)  ; Saturate(value)
  %219 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %219, label %220, label %1186

; <label>:220                                     ; preds = %187
  %221 = add i32 %45, -1
  %222 = add i32 %42, -1
  %223 = add i32 %43, -1
  %224 = call i32 @dx.op.binary.i32(i32 37, i32 %44, i32 0)  ; IMax(a,b)
  %225 = call i32 @dx.op.binary.i32(i32 37, i32 %221, i32 0)  ; IMax(a,b)
  %226 = call i32 @dx.op.binary.i32(i32 38, i32 %224, i32 %222)  ; IMin(a,b)
  %227 = call i32 @dx.op.binary.i32(i32 38, i32 %225, i32 %223)  ; IMin(a,b)
  %228 = call i32 @dx.op.binary.i32(i32 37, i32 %226, i32 0)  ; IMax(a,b)
  %229 = call i32 @dx.op.binary.i32(i32 37, i32 %227, i32 0)  ; IMax(a,b)
  %230 = call i32 @dx.op.binary.i32(i32 38, i32 %228, i32 %222)  ; IMin(a,b)
  %231 = call i32 @dx.op.binary.i32(i32 38, i32 %229, i32 %223)  ; IMin(a,b)
  %232 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %230, i32 %231, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %233 = extractvalue %dx.types.ResRet.f32 %232, 0
  %234 = extractvalue %dx.types.ResRet.f32 %232, 1
  %235 = extractvalue %dx.types.ResRet.f32 %232, 2
  %236 = extractvalue %dx.types.ResRet.f32 %232, 3
  %237 = fcmp fast olt float %236, 0.000000e+00
  br i1 %237, label %238, label %272

; <label>:238                                     ; preds = %220
  %239 = fcmp fast ogt float %233, 0x3FA4B5DCC0000000
  %240 = fcmp fast ogt float %234, 0x3FA4B5DCC0000000
  %241 = fcmp fast ogt float %235, 0x3FA4B5DCC0000000
  %242 = select i1 %239, float 0.000000e+00, float 1.000000e+00
  %243 = select i1 %240, float 0.000000e+00, float 1.000000e+00
  %244 = select i1 %241, float 0.000000e+00, float 1.000000e+00
  %245 = fmul fast float %233, 0x3FB3D07220000000
  %246 = fmul fast float %234, 0x3FB3D07220000000
  %247 = fmul fast float %235, 0x3FB3D07220000000
  %248 = fadd fast float %233, 0x3FAC28F5C0000000
  %249 = fadd fast float %234, 0x3FAC28F5C0000000
  %250 = fadd fast float %235, 0x3FAC28F5C0000000
  %251 = fmul fast float %248, 0x3FEE54EDE0000000
  %252 = fmul fast float %249, 0x3FEE54EDE0000000
  %253 = fmul fast float %250, 0x3FEE54EDE0000000
  %254 = call float @dx.op.unary.f32(i32 23, float %251)  ; Log(value)
  %255 = call float @dx.op.unary.f32(i32 23, float %252)  ; Log(value)
  %256 = call float @dx.op.unary.f32(i32 23, float %253)  ; Log(value)
  %257 = fmul fast float %254, 0x4003333340000000
  %258 = fmul fast float %255, 0x4003333340000000
  %259 = fmul fast float %256, 0x4003333340000000
  %260 = call float @dx.op.unary.f32(i32 21, float %257)  ; Exp(value)
  %261 = call float @dx.op.unary.f32(i32 21, float %258)  ; Exp(value)
  %262 = call float @dx.op.unary.f32(i32 21, float %259)  ; Exp(value)
  %263 = fsub fast float %245, %260
  %264 = fsub fast float %246, %261
  %265 = fsub fast float %247, %262
  %266 = fmul fast float %263, %242
  %267 = fmul fast float %264, %243
  %268 = fmul fast float %265, %244
  %269 = fadd fast float %266, %260
  %270 = fadd fast float %267, %261
  %271 = fadd fast float %268, %262
  br label %437

; <label>:272                                     ; preds = %220
  %273 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %230, i32 %231, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %274 = extractvalue %dx.types.ResRet.f32 %273, 0
  %275 = fcmp fast ogt float %37, 5.000000e-01
  %276 = fcmp fast olt float %274, 1.000000e+00
  %277 = and i1 %275, %276
  br i1 %277, label %278, label %366

; <label>:278                                     ; preds = %272
  %279 = sitofp i32 %230 to float
  %280 = sitofp i32 %231 to float
  %281 = fadd fast float %279, 5.000000e-01
  %282 = fadd fast float %280, 5.000000e-01
  %283 = uitofp i32 %42 to float
  %284 = uitofp i32 %43 to float
  %285 = fdiv fast float %281, %283
  %286 = fdiv fast float %282, %284
  %287 = fmul fast float %285, 2.000000e+00
  %288 = fmul fast float %286, 2.000000e+00
  %289 = fadd fast float %287, -1.000000e+00
  %290 = fsub fast float 1.000000e+00, %288
  %291 = fmul fast float %289, %34
  %292 = call float @dx.op.tertiary.f32(i32 46, float %290, float %30, float %291)  ; FMad(a,b,c)
  %293 = call float @dx.op.tertiary.f32(i32 46, float %274, float %26, float %292)  ; FMad(a,b,c)
  %294 = fadd fast float %293, %22
  %295 = call float @dx.op.unary.f32(i32 6, float %294)  ; FAbs(value)
  %296 = fcmp fast ogt float %295, 0x3EB0C6F7A0000000
  br i1 %296, label %297, label %366

; <label>:297                                     ; preds = %278
  %298 = fmul fast float %289, %33
  %299 = call float @dx.op.tertiary.f32(i32 46, float %290, float %29, float %298)  ; FMad(a,b,c)
  %300 = call float @dx.op.tertiary.f32(i32 46, float %274, float %25, float %299)  ; FMad(a,b,c)
  %301 = fadd fast float %300, %21
  %302 = fmul fast float %289, %32
  %303 = call float @dx.op.tertiary.f32(i32 46, float %290, float %28, float %302)  ; FMad(a,b,c)
  %304 = call float @dx.op.tertiary.f32(i32 46, float %274, float %24, float %303)  ; FMad(a,b,c)
  %305 = fadd fast float %304, %20
  %306 = fmul fast float %289, %31
  %307 = call float @dx.op.tertiary.f32(i32 46, float %290, float %27, float %306)  ; FMad(a,b,c)
  %308 = call float @dx.op.tertiary.f32(i32 46, float %274, float %23, float %307)  ; FMad(a,b,c)
  %309 = fadd fast float %308, %19
  %310 = fdiv fast float %309, %294
  %311 = fdiv fast float %305, %294
  %312 = fdiv fast float %301, %294
  %313 = fsub fast float %310, %16
  %314 = fsub fast float %311, %17
  %315 = fsub fast float %312, %18
  %316 = fmul fast float %313, %313
  %317 = fmul fast float %314, %314
  %318 = fadd fast float %317, %316
  %319 = fmul fast float %315, %315
  %320 = fadd fast float %318, %319
  %321 = call float @dx.op.unary.f32(i32 24, float %320)  ; Sqrt(value)
  %322 = fsub fast float %321, %8
  %323 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %322)  ; FMax(a,b)
  %324 = fcmp fast ogt float %38, 1.500000e+00
  br i1 %324, label %325, label %348

; <label>:325                                     ; preds = %297
  %326 = call float @dx.op.unary.f32(i32 6, float %314)  ; FAbs(value)
  %327 = fmul fast float %326, %10
  %328 = fcmp fast olt float %327, 0x3F50624DE0000000
  br i1 %328, label %329, label %332

; <label>:329                                     ; preds = %325
  %330 = fmul fast float %327, 5.000000e-01
  %331 = fsub fast float 1.000000e+00, %330
  br label %337

; <label>:332                                     ; preds = %325
  %333 = fmul fast float %327, 0xBFF7154760000000
  %334 = call float @dx.op.unary.f32(i32 21, float %333)  ; Exp(value)
  %335 = fsub fast float 1.000000e+00, %334
  %336 = fdiv fast float %335, %327
  br label %337

; <label>:337                                     ; preds = %332, %329
  %338 = phi float [ %331, %329 ], [ %336, %332 ]
  %339 = call float @dx.op.binary.f32(i32 36, float %311, float %17)  ; FMin(a,b)
  %340 = fsub fast float %339, %9
  %341 = fmul fast float %10, %340
  %342 = fsub fast float -0.000000e+00, %341
  %343 = call float @dx.op.binary.f32(i32 35, float %342, float -4.000000e+01)  ; FMax(a,b)
  %344 = call float @dx.op.binary.f32(i32 36, float %343, float 5.000000e+00)  ; FMin(a,b)
  %345 = fmul fast float %344, 0x3FF7154760000000
  %346 = call float @dx.op.unary.f32(i32 21, float %345)  ; Exp(value)
  %347 = fmul fast float %346, %338
  br label %348

; <label>:348                                     ; preds = %337, %297
  %349 = phi float [ %347, %337 ], [ 1.000000e+00, %297 ]
  %350 = fmul fast float %323, %15
  %351 = fmul fast float %350, %349
  %352 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %351)  ; FMin(a,b)
  %353 = fmul fast float %352, 0xBFF7154760000000
  %354 = call float @dx.op.unary.f32(i32 21, float %353)  ; Exp(value)
  %355 = fsub fast float 1.000000e+00, %354
  %356 = call float @dx.op.binary.f32(i32 36, float %11, float %355)  ; FMin(a,b)
  %357 = fsub fast float %12, %233
  %358 = fsub fast float %13, %234
  %359 = fsub fast float %14, %235
  %360 = fmul fast float %356, %357
  %361 = fmul fast float %356, %358
  %362 = fmul fast float %356, %359
  %363 = fadd fast float %360, %233
  %364 = fadd fast float %361, %234
  %365 = fadd fast float %362, %235
  br label %366

; <label>:366                                     ; preds = %348, %278, %272
  %367 = phi float [ %363, %348 ], [ %233, %278 ], [ %233, %272 ]
  %368 = phi float [ %364, %348 ], [ %234, %278 ], [ %234, %272 ]
  %369 = phi float [ %365, %348 ], [ %235, %278 ], [ %235, %272 ]
  %370 = fadd fast float %4, 1.000000e+00
  %371 = fadd fast float %5, 1.000000e+00
  %372 = fsub fast float 1.000000e+00, %4
  %373 = fmul fast float %35, %370
  %374 = fmul fast float %35, %371
  %375 = fmul fast float %35, %372
  %376 = fmul fast float %373, %367
  %377 = fmul fast float %374, %368
  %378 = fmul fast float %375, %369
  %379 = fcmp fast ult float %36, 5.000000e-01
  br i1 %379, label %405, label %380

; <label>:380                                     ; preds = %366
  %381 = fmul fast float %376, 0x4004147AE0000000
  %382 = fmul fast float %377, 0x4004147AE0000000
  %383 = fmul fast float %378, 0x4004147AE0000000
  %384 = fadd fast float %381, 0x3F9EB851E0000000
  %385 = fadd fast float %382, 0x3F9EB851E0000000
  %386 = fadd fast float %383, 0x3F9EB851E0000000
  %387 = fmul fast float %384, %376
  %388 = fmul fast float %385, %377
  %389 = fmul fast float %386, %378
  %390 = fmul fast float %376, 0x400370A3E0000000
  %391 = fmul fast float %377, 0x400370A3E0000000
  %392 = fmul fast float %378, 0x400370A3E0000000
  %393 = fadd fast float %390, 0x3FE2E147A0000000
  %394 = fadd fast float %391, 0x3FE2E147A0000000
  %395 = fadd fast float %392, 0x3FE2E147A0000000
  %396 = fmul fast float %393, %376
  %397 = fmul fast float %394, %377
  %398 = fmul fast float %395, %378
  %399 = fadd fast float %396, 0x3FC1EB8520000000
  %400 = fadd fast float %397, 0x3FC1EB8520000000
  %401 = fadd fast float %398, 0x3FC1EB8520000000
  %402 = fdiv fast float %387, %399
  %403 = fdiv fast float %388, %400
  %404 = fdiv fast float %389, %401
  br label %405

; <label>:405                                     ; preds = %380, %366
  %406 = phi float [ %402, %380 ], [ %376, %366 ]
  %407 = phi float [ %403, %380 ], [ %377, %366 ]
  %408 = phi float [ %404, %380 ], [ %378, %366 ]
  %409 = call float @dx.op.unary.f32(i32 7, float %406)  ; Saturate(value)
  %410 = call float @dx.op.unary.f32(i32 7, float %407)  ; Saturate(value)
  %411 = call float @dx.op.unary.f32(i32 7, float %408)  ; Saturate(value)
  %412 = call float @dx.op.dot3.f32(i32 55, float %409, float %410, float %411, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %413 = fsub fast float %409, %412
  %414 = fsub fast float %410, %412
  %415 = fsub fast float %411, %412
  %416 = fmul fast float %413, %7
  %417 = fmul fast float %414, %7
  %418 = fmul fast float %415, %7
  %419 = fadd fast float %416, %412
  %420 = fadd fast float %417, %412
  %421 = fadd fast float %418, %412
  %422 = call float @dx.op.unary.f32(i32 7, float %419)  ; Saturate(value)
  %423 = call float @dx.op.unary.f32(i32 7, float %420)  ; Saturate(value)
  %424 = call float @dx.op.unary.f32(i32 7, float %421)  ; Saturate(value)
  %425 = fadd fast float %422, 0xBFC70A3D80000000
  %426 = fadd fast float %423, 0xBFC70A3D80000000
  %427 = fadd fast float %424, 0xBFC70A3D80000000
  %428 = fmul fast float %425, %6
  %429 = fmul fast float %426, %6
  %430 = fmul fast float %427, %6
  %431 = fadd fast float %428, 0x3FC70A3D80000000
  %432 = fadd fast float %429, 0x3FC70A3D80000000
  %433 = fadd fast float %430, 0x3FC70A3D80000000
  %434 = call float @dx.op.unary.f32(i32 7, float %431)  ; Saturate(value)
  %435 = call float @dx.op.unary.f32(i32 7, float %432)  ; Saturate(value)
  %436 = call float @dx.op.unary.f32(i32 7, float %433)  ; Saturate(value)
  br label %437

; <label>:437                                     ; preds = %405, %238
  %438 = phi float [ %269, %238 ], [ %434, %405 ]
  %439 = phi float [ %270, %238 ], [ %435, %405 ]
  %440 = phi float [ %271, %238 ], [ %436, %405 ]
  %441 = add i32 %45, 1
  %442 = call i32 @dx.op.binary.i32(i32 37, i32 %441, i32 0)  ; IMax(a,b)
  %443 = call i32 @dx.op.binary.i32(i32 38, i32 %442, i32 %223)  ; IMin(a,b)
  %444 = call i32 @dx.op.binary.i32(i32 37, i32 %443, i32 0)  ; IMax(a,b)
  %445 = call i32 @dx.op.binary.i32(i32 38, i32 %444, i32 %223)  ; IMin(a,b)
  %446 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %230, i32 %445, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %447 = extractvalue %dx.types.ResRet.f32 %446, 0
  %448 = extractvalue %dx.types.ResRet.f32 %446, 1
  %449 = extractvalue %dx.types.ResRet.f32 %446, 2
  %450 = extractvalue %dx.types.ResRet.f32 %446, 3
  %451 = fcmp fast olt float %450, 0.000000e+00
  br i1 %451, label %452, label %486

; <label>:452                                     ; preds = %437
  %453 = fcmp fast ogt float %447, 0x3FA4B5DCC0000000
  %454 = fcmp fast ogt float %448, 0x3FA4B5DCC0000000
  %455 = fcmp fast ogt float %449, 0x3FA4B5DCC0000000
  %456 = select i1 %453, float 0.000000e+00, float 1.000000e+00
  %457 = select i1 %454, float 0.000000e+00, float 1.000000e+00
  %458 = select i1 %455, float 0.000000e+00, float 1.000000e+00
  %459 = fmul fast float %447, 0x3FB3D07220000000
  %460 = fmul fast float %448, 0x3FB3D07220000000
  %461 = fmul fast float %449, 0x3FB3D07220000000
  %462 = fadd fast float %447, 0x3FAC28F5C0000000
  %463 = fadd fast float %448, 0x3FAC28F5C0000000
  %464 = fadd fast float %449, 0x3FAC28F5C0000000
  %465 = fmul fast float %462, 0x3FEE54EDE0000000
  %466 = fmul fast float %463, 0x3FEE54EDE0000000
  %467 = fmul fast float %464, 0x3FEE54EDE0000000
  %468 = call float @dx.op.unary.f32(i32 23, float %465)  ; Log(value)
  %469 = call float @dx.op.unary.f32(i32 23, float %466)  ; Log(value)
  %470 = call float @dx.op.unary.f32(i32 23, float %467)  ; Log(value)
  %471 = fmul fast float %468, 0x4003333340000000
  %472 = fmul fast float %469, 0x4003333340000000
  %473 = fmul fast float %470, 0x4003333340000000
  %474 = call float @dx.op.unary.f32(i32 21, float %471)  ; Exp(value)
  %475 = call float @dx.op.unary.f32(i32 21, float %472)  ; Exp(value)
  %476 = call float @dx.op.unary.f32(i32 21, float %473)  ; Exp(value)
  %477 = fsub fast float %459, %474
  %478 = fsub fast float %460, %475
  %479 = fsub fast float %461, %476
  %480 = fmul fast float %477, %456
  %481 = fmul fast float %478, %457
  %482 = fmul fast float %479, %458
  %483 = fadd fast float %480, %474
  %484 = fadd fast float %481, %475
  %485 = fadd fast float %482, %476
  br label %651

; <label>:486                                     ; preds = %437
  %487 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %230, i32 %445, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %488 = extractvalue %dx.types.ResRet.f32 %487, 0
  %489 = fcmp fast ogt float %37, 5.000000e-01
  %490 = fcmp fast olt float %488, 1.000000e+00
  %491 = and i1 %489, %490
  br i1 %491, label %492, label %580

; <label>:492                                     ; preds = %486
  %493 = sitofp i32 %230 to float
  %494 = sitofp i32 %445 to float
  %495 = fadd fast float %493, 5.000000e-01
  %496 = fadd fast float %494, 5.000000e-01
  %497 = uitofp i32 %42 to float
  %498 = uitofp i32 %43 to float
  %499 = fdiv fast float %495, %497
  %500 = fdiv fast float %496, %498
  %501 = fmul fast float %499, 2.000000e+00
  %502 = fmul fast float %500, 2.000000e+00
  %503 = fadd fast float %501, -1.000000e+00
  %504 = fsub fast float 1.000000e+00, %502
  %505 = fmul fast float %503, %34
  %506 = call float @dx.op.tertiary.f32(i32 46, float %504, float %30, float %505)  ; FMad(a,b,c)
  %507 = call float @dx.op.tertiary.f32(i32 46, float %488, float %26, float %506)  ; FMad(a,b,c)
  %508 = fadd fast float %507, %22
  %509 = call float @dx.op.unary.f32(i32 6, float %508)  ; FAbs(value)
  %510 = fcmp fast ogt float %509, 0x3EB0C6F7A0000000
  br i1 %510, label %511, label %580

; <label>:511                                     ; preds = %492
  %512 = fmul fast float %503, %33
  %513 = call float @dx.op.tertiary.f32(i32 46, float %504, float %29, float %512)  ; FMad(a,b,c)
  %514 = call float @dx.op.tertiary.f32(i32 46, float %488, float %25, float %513)  ; FMad(a,b,c)
  %515 = fadd fast float %514, %21
  %516 = fmul fast float %503, %32
  %517 = call float @dx.op.tertiary.f32(i32 46, float %504, float %28, float %516)  ; FMad(a,b,c)
  %518 = call float @dx.op.tertiary.f32(i32 46, float %488, float %24, float %517)  ; FMad(a,b,c)
  %519 = fadd fast float %518, %20
  %520 = fmul fast float %503, %31
  %521 = call float @dx.op.tertiary.f32(i32 46, float %504, float %27, float %520)  ; FMad(a,b,c)
  %522 = call float @dx.op.tertiary.f32(i32 46, float %488, float %23, float %521)  ; FMad(a,b,c)
  %523 = fadd fast float %522, %19
  %524 = fdiv fast float %523, %508
  %525 = fdiv fast float %519, %508
  %526 = fdiv fast float %515, %508
  %527 = fsub fast float %524, %16
  %528 = fsub fast float %525, %17
  %529 = fsub fast float %526, %18
  %530 = fmul fast float %527, %527
  %531 = fmul fast float %528, %528
  %532 = fadd fast float %531, %530
  %533 = fmul fast float %529, %529
  %534 = fadd fast float %532, %533
  %535 = call float @dx.op.unary.f32(i32 24, float %534)  ; Sqrt(value)
  %536 = fsub fast float %535, %8
  %537 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %536)  ; FMax(a,b)
  %538 = fcmp fast ogt float %38, 1.500000e+00
  br i1 %538, label %539, label %562

; <label>:539                                     ; preds = %511
  %540 = call float @dx.op.unary.f32(i32 6, float %528)  ; FAbs(value)
  %541 = fmul fast float %540, %10
  %542 = fcmp fast olt float %541, 0x3F50624DE0000000
  br i1 %542, label %543, label %546

; <label>:543                                     ; preds = %539
  %544 = fmul fast float %541, 5.000000e-01
  %545 = fsub fast float 1.000000e+00, %544
  br label %551

; <label>:546                                     ; preds = %539
  %547 = fmul fast float %541, 0xBFF7154760000000
  %548 = call float @dx.op.unary.f32(i32 21, float %547)  ; Exp(value)
  %549 = fsub fast float 1.000000e+00, %548
  %550 = fdiv fast float %549, %541
  br label %551

; <label>:551                                     ; preds = %546, %543
  %552 = phi float [ %545, %543 ], [ %550, %546 ]
  %553 = call float @dx.op.binary.f32(i32 36, float %525, float %17)  ; FMin(a,b)
  %554 = fsub fast float %553, %9
  %555 = fmul fast float %10, %554
  %556 = fsub fast float -0.000000e+00, %555
  %557 = call float @dx.op.binary.f32(i32 35, float %556, float -4.000000e+01)  ; FMax(a,b)
  %558 = call float @dx.op.binary.f32(i32 36, float %557, float 5.000000e+00)  ; FMin(a,b)
  %559 = fmul fast float %558, 0x3FF7154760000000
  %560 = call float @dx.op.unary.f32(i32 21, float %559)  ; Exp(value)
  %561 = fmul fast float %560, %552
  br label %562

; <label>:562                                     ; preds = %551, %511
  %563 = phi float [ %561, %551 ], [ 1.000000e+00, %511 ]
  %564 = fmul fast float %537, %15
  %565 = fmul fast float %564, %563
  %566 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %565)  ; FMin(a,b)
  %567 = fmul fast float %566, 0xBFF7154760000000
  %568 = call float @dx.op.unary.f32(i32 21, float %567)  ; Exp(value)
  %569 = fsub fast float 1.000000e+00, %568
  %570 = call float @dx.op.binary.f32(i32 36, float %11, float %569)  ; FMin(a,b)
  %571 = fsub fast float %12, %447
  %572 = fsub fast float %13, %448
  %573 = fsub fast float %14, %449
  %574 = fmul fast float %570, %571
  %575 = fmul fast float %570, %572
  %576 = fmul fast float %570, %573
  %577 = fadd fast float %574, %447
  %578 = fadd fast float %575, %448
  %579 = fadd fast float %576, %449
  br label %580

; <label>:580                                     ; preds = %562, %492, %486
  %581 = phi float [ %577, %562 ], [ %447, %492 ], [ %447, %486 ]
  %582 = phi float [ %578, %562 ], [ %448, %492 ], [ %448, %486 ]
  %583 = phi float [ %579, %562 ], [ %449, %492 ], [ %449, %486 ]
  %584 = fadd fast float %4, 1.000000e+00
  %585 = fadd fast float %5, 1.000000e+00
  %586 = fsub fast float 1.000000e+00, %4
  %587 = fmul fast float %35, %584
  %588 = fmul fast float %35, %585
  %589 = fmul fast float %35, %586
  %590 = fmul fast float %587, %581
  %591 = fmul fast float %588, %582
  %592 = fmul fast float %589, %583
  %593 = fcmp fast ult float %36, 5.000000e-01
  br i1 %593, label %619, label %594

; <label>:594                                     ; preds = %580
  %595 = fmul fast float %590, 0x4004147AE0000000
  %596 = fmul fast float %591, 0x4004147AE0000000
  %597 = fmul fast float %592, 0x4004147AE0000000
  %598 = fadd fast float %595, 0x3F9EB851E0000000
  %599 = fadd fast float %596, 0x3F9EB851E0000000
  %600 = fadd fast float %597, 0x3F9EB851E0000000
  %601 = fmul fast float %598, %590
  %602 = fmul fast float %599, %591
  %603 = fmul fast float %600, %592
  %604 = fmul fast float %590, 0x400370A3E0000000
  %605 = fmul fast float %591, 0x400370A3E0000000
  %606 = fmul fast float %592, 0x400370A3E0000000
  %607 = fadd fast float %604, 0x3FE2E147A0000000
  %608 = fadd fast float %605, 0x3FE2E147A0000000
  %609 = fadd fast float %606, 0x3FE2E147A0000000
  %610 = fmul fast float %607, %590
  %611 = fmul fast float %608, %591
  %612 = fmul fast float %609, %592
  %613 = fadd fast float %610, 0x3FC1EB8520000000
  %614 = fadd fast float %611, 0x3FC1EB8520000000
  %615 = fadd fast float %612, 0x3FC1EB8520000000
  %616 = fdiv fast float %601, %613
  %617 = fdiv fast float %602, %614
  %618 = fdiv fast float %603, %615
  br label %619

; <label>:619                                     ; preds = %594, %580
  %620 = phi float [ %616, %594 ], [ %590, %580 ]
  %621 = phi float [ %617, %594 ], [ %591, %580 ]
  %622 = phi float [ %618, %594 ], [ %592, %580 ]
  %623 = call float @dx.op.unary.f32(i32 7, float %620)  ; Saturate(value)
  %624 = call float @dx.op.unary.f32(i32 7, float %621)  ; Saturate(value)
  %625 = call float @dx.op.unary.f32(i32 7, float %622)  ; Saturate(value)
  %626 = call float @dx.op.dot3.f32(i32 55, float %623, float %624, float %625, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %627 = fsub fast float %623, %626
  %628 = fsub fast float %624, %626
  %629 = fsub fast float %625, %626
  %630 = fmul fast float %627, %7
  %631 = fmul fast float %628, %7
  %632 = fmul fast float %629, %7
  %633 = fadd fast float %630, %626
  %634 = fadd fast float %631, %626
  %635 = fadd fast float %632, %626
  %636 = call float @dx.op.unary.f32(i32 7, float %633)  ; Saturate(value)
  %637 = call float @dx.op.unary.f32(i32 7, float %634)  ; Saturate(value)
  %638 = call float @dx.op.unary.f32(i32 7, float %635)  ; Saturate(value)
  %639 = fadd fast float %636, 0xBFC70A3D80000000
  %640 = fadd fast float %637, 0xBFC70A3D80000000
  %641 = fadd fast float %638, 0xBFC70A3D80000000
  %642 = fmul fast float %639, %6
  %643 = fmul fast float %640, %6
  %644 = fmul fast float %641, %6
  %645 = fadd fast float %642, 0x3FC70A3D80000000
  %646 = fadd fast float %643, 0x3FC70A3D80000000
  %647 = fadd fast float %644, 0x3FC70A3D80000000
  %648 = call float @dx.op.unary.f32(i32 7, float %645)  ; Saturate(value)
  %649 = call float @dx.op.unary.f32(i32 7, float %646)  ; Saturate(value)
  %650 = call float @dx.op.unary.f32(i32 7, float %647)  ; Saturate(value)
  br label %651

; <label>:651                                     ; preds = %619, %452
  %652 = phi float [ %483, %452 ], [ %648, %619 ]
  %653 = phi float [ %484, %452 ], [ %649, %619 ]
  %654 = phi float [ %485, %452 ], [ %650, %619 ]
  %655 = add i32 %44, -1
  %656 = call i32 @dx.op.binary.i32(i32 37, i32 %655, i32 0)  ; IMax(a,b)
  %657 = call i32 @dx.op.binary.i32(i32 37, i32 %45, i32 0)  ; IMax(a,b)
  %658 = call i32 @dx.op.binary.i32(i32 38, i32 %656, i32 %222)  ; IMin(a,b)
  %659 = call i32 @dx.op.binary.i32(i32 38, i32 %657, i32 %223)  ; IMin(a,b)
  %660 = call i32 @dx.op.binary.i32(i32 37, i32 %658, i32 0)  ; IMax(a,b)
  %661 = call i32 @dx.op.binary.i32(i32 37, i32 %659, i32 0)  ; IMax(a,b)
  %662 = call i32 @dx.op.binary.i32(i32 38, i32 %660, i32 %222)  ; IMin(a,b)
  %663 = call i32 @dx.op.binary.i32(i32 38, i32 %661, i32 %223)  ; IMin(a,b)
  %664 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %662, i32 %663, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %665 = extractvalue %dx.types.ResRet.f32 %664, 0
  %666 = extractvalue %dx.types.ResRet.f32 %664, 1
  %667 = extractvalue %dx.types.ResRet.f32 %664, 2
  %668 = extractvalue %dx.types.ResRet.f32 %664, 3
  %669 = fcmp fast olt float %668, 0.000000e+00
  br i1 %669, label %670, label %704

; <label>:670                                     ; preds = %651
  %671 = fcmp fast ogt float %665, 0x3FA4B5DCC0000000
  %672 = fcmp fast ogt float %666, 0x3FA4B5DCC0000000
  %673 = fcmp fast ogt float %667, 0x3FA4B5DCC0000000
  %674 = select i1 %671, float 0.000000e+00, float 1.000000e+00
  %675 = select i1 %672, float 0.000000e+00, float 1.000000e+00
  %676 = select i1 %673, float 0.000000e+00, float 1.000000e+00
  %677 = fmul fast float %665, 0x3FB3D07220000000
  %678 = fmul fast float %666, 0x3FB3D07220000000
  %679 = fmul fast float %667, 0x3FB3D07220000000
  %680 = fadd fast float %665, 0x3FAC28F5C0000000
  %681 = fadd fast float %666, 0x3FAC28F5C0000000
  %682 = fadd fast float %667, 0x3FAC28F5C0000000
  %683 = fmul fast float %680, 0x3FEE54EDE0000000
  %684 = fmul fast float %681, 0x3FEE54EDE0000000
  %685 = fmul fast float %682, 0x3FEE54EDE0000000
  %686 = call float @dx.op.unary.f32(i32 23, float %683)  ; Log(value)
  %687 = call float @dx.op.unary.f32(i32 23, float %684)  ; Log(value)
  %688 = call float @dx.op.unary.f32(i32 23, float %685)  ; Log(value)
  %689 = fmul fast float %686, 0x4003333340000000
  %690 = fmul fast float %687, 0x4003333340000000
  %691 = fmul fast float %688, 0x4003333340000000
  %692 = call float @dx.op.unary.f32(i32 21, float %689)  ; Exp(value)
  %693 = call float @dx.op.unary.f32(i32 21, float %690)  ; Exp(value)
  %694 = call float @dx.op.unary.f32(i32 21, float %691)  ; Exp(value)
  %695 = fsub fast float %677, %692
  %696 = fsub fast float %678, %693
  %697 = fsub fast float %679, %694
  %698 = fmul fast float %695, %674
  %699 = fmul fast float %696, %675
  %700 = fmul fast float %697, %676
  %701 = fadd fast float %698, %692
  %702 = fadd fast float %699, %693
  %703 = fadd fast float %700, %694
  br label %869

; <label>:704                                     ; preds = %651
  %705 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %662, i32 %663, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %706 = extractvalue %dx.types.ResRet.f32 %705, 0
  %707 = fcmp fast ogt float %37, 5.000000e-01
  %708 = fcmp fast olt float %706, 1.000000e+00
  %709 = and i1 %707, %708
  br i1 %709, label %710, label %798

; <label>:710                                     ; preds = %704
  %711 = sitofp i32 %662 to float
  %712 = sitofp i32 %663 to float
  %713 = fadd fast float %711, 5.000000e-01
  %714 = fadd fast float %712, 5.000000e-01
  %715 = uitofp i32 %42 to float
  %716 = uitofp i32 %43 to float
  %717 = fdiv fast float %713, %715
  %718 = fdiv fast float %714, %716
  %719 = fmul fast float %717, 2.000000e+00
  %720 = fmul fast float %718, 2.000000e+00
  %721 = fadd fast float %719, -1.000000e+00
  %722 = fsub fast float 1.000000e+00, %720
  %723 = fmul fast float %721, %34
  %724 = call float @dx.op.tertiary.f32(i32 46, float %722, float %30, float %723)  ; FMad(a,b,c)
  %725 = call float @dx.op.tertiary.f32(i32 46, float %706, float %26, float %724)  ; FMad(a,b,c)
  %726 = fadd fast float %725, %22
  %727 = call float @dx.op.unary.f32(i32 6, float %726)  ; FAbs(value)
  %728 = fcmp fast ogt float %727, 0x3EB0C6F7A0000000
  br i1 %728, label %729, label %798

; <label>:729                                     ; preds = %710
  %730 = fmul fast float %721, %33
  %731 = call float @dx.op.tertiary.f32(i32 46, float %722, float %29, float %730)  ; FMad(a,b,c)
  %732 = call float @dx.op.tertiary.f32(i32 46, float %706, float %25, float %731)  ; FMad(a,b,c)
  %733 = fadd fast float %732, %21
  %734 = fmul fast float %721, %32
  %735 = call float @dx.op.tertiary.f32(i32 46, float %722, float %28, float %734)  ; FMad(a,b,c)
  %736 = call float @dx.op.tertiary.f32(i32 46, float %706, float %24, float %735)  ; FMad(a,b,c)
  %737 = fadd fast float %736, %20
  %738 = fmul fast float %721, %31
  %739 = call float @dx.op.tertiary.f32(i32 46, float %722, float %27, float %738)  ; FMad(a,b,c)
  %740 = call float @dx.op.tertiary.f32(i32 46, float %706, float %23, float %739)  ; FMad(a,b,c)
  %741 = fadd fast float %740, %19
  %742 = fdiv fast float %741, %726
  %743 = fdiv fast float %737, %726
  %744 = fdiv fast float %733, %726
  %745 = fsub fast float %742, %16
  %746 = fsub fast float %743, %17
  %747 = fsub fast float %744, %18
  %748 = fmul fast float %745, %745
  %749 = fmul fast float %746, %746
  %750 = fadd fast float %749, %748
  %751 = fmul fast float %747, %747
  %752 = fadd fast float %750, %751
  %753 = call float @dx.op.unary.f32(i32 24, float %752)  ; Sqrt(value)
  %754 = fsub fast float %753, %8
  %755 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %754)  ; FMax(a,b)
  %756 = fcmp fast ogt float %38, 1.500000e+00
  br i1 %756, label %757, label %780

; <label>:757                                     ; preds = %729
  %758 = call float @dx.op.unary.f32(i32 6, float %746)  ; FAbs(value)
  %759 = fmul fast float %758, %10
  %760 = fcmp fast olt float %759, 0x3F50624DE0000000
  br i1 %760, label %761, label %764

; <label>:761                                     ; preds = %757
  %762 = fmul fast float %759, 5.000000e-01
  %763 = fsub fast float 1.000000e+00, %762
  br label %769

; <label>:764                                     ; preds = %757
  %765 = fmul fast float %759, 0xBFF7154760000000
  %766 = call float @dx.op.unary.f32(i32 21, float %765)  ; Exp(value)
  %767 = fsub fast float 1.000000e+00, %766
  %768 = fdiv fast float %767, %759
  br label %769

; <label>:769                                     ; preds = %764, %761
  %770 = phi float [ %763, %761 ], [ %768, %764 ]
  %771 = call float @dx.op.binary.f32(i32 36, float %743, float %17)  ; FMin(a,b)
  %772 = fsub fast float %771, %9
  %773 = fmul fast float %10, %772
  %774 = fsub fast float -0.000000e+00, %773
  %775 = call float @dx.op.binary.f32(i32 35, float %774, float -4.000000e+01)  ; FMax(a,b)
  %776 = call float @dx.op.binary.f32(i32 36, float %775, float 5.000000e+00)  ; FMin(a,b)
  %777 = fmul fast float %776, 0x3FF7154760000000
  %778 = call float @dx.op.unary.f32(i32 21, float %777)  ; Exp(value)
  %779 = fmul fast float %778, %770
  br label %780

; <label>:780                                     ; preds = %769, %729
  %781 = phi float [ %779, %769 ], [ 1.000000e+00, %729 ]
  %782 = fmul fast float %755, %15
  %783 = fmul fast float %782, %781
  %784 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %783)  ; FMin(a,b)
  %785 = fmul fast float %784, 0xBFF7154760000000
  %786 = call float @dx.op.unary.f32(i32 21, float %785)  ; Exp(value)
  %787 = fsub fast float 1.000000e+00, %786
  %788 = call float @dx.op.binary.f32(i32 36, float %11, float %787)  ; FMin(a,b)
  %789 = fsub fast float %12, %665
  %790 = fsub fast float %13, %666
  %791 = fsub fast float %14, %667
  %792 = fmul fast float %788, %789
  %793 = fmul fast float %788, %790
  %794 = fmul fast float %788, %791
  %795 = fadd fast float %792, %665
  %796 = fadd fast float %793, %666
  %797 = fadd fast float %794, %667
  br label %798

; <label>:798                                     ; preds = %780, %710, %704
  %799 = phi float [ %795, %780 ], [ %665, %710 ], [ %665, %704 ]
  %800 = phi float [ %796, %780 ], [ %666, %710 ], [ %666, %704 ]
  %801 = phi float [ %797, %780 ], [ %667, %710 ], [ %667, %704 ]
  %802 = fadd fast float %4, 1.000000e+00
  %803 = fadd fast float %5, 1.000000e+00
  %804 = fsub fast float 1.000000e+00, %4
  %805 = fmul fast float %35, %802
  %806 = fmul fast float %35, %803
  %807 = fmul fast float %35, %804
  %808 = fmul fast float %805, %799
  %809 = fmul fast float %806, %800
  %810 = fmul fast float %807, %801
  %811 = fcmp fast ult float %36, 5.000000e-01
  br i1 %811, label %837, label %812

; <label>:812                                     ; preds = %798
  %813 = fmul fast float %808, 0x4004147AE0000000
  %814 = fmul fast float %809, 0x4004147AE0000000
  %815 = fmul fast float %810, 0x4004147AE0000000
  %816 = fadd fast float %813, 0x3F9EB851E0000000
  %817 = fadd fast float %814, 0x3F9EB851E0000000
  %818 = fadd fast float %815, 0x3F9EB851E0000000
  %819 = fmul fast float %816, %808
  %820 = fmul fast float %817, %809
  %821 = fmul fast float %818, %810
  %822 = fmul fast float %808, 0x400370A3E0000000
  %823 = fmul fast float %809, 0x400370A3E0000000
  %824 = fmul fast float %810, 0x400370A3E0000000
  %825 = fadd fast float %822, 0x3FE2E147A0000000
  %826 = fadd fast float %823, 0x3FE2E147A0000000
  %827 = fadd fast float %824, 0x3FE2E147A0000000
  %828 = fmul fast float %825, %808
  %829 = fmul fast float %826, %809
  %830 = fmul fast float %827, %810
  %831 = fadd fast float %828, 0x3FC1EB8520000000
  %832 = fadd fast float %829, 0x3FC1EB8520000000
  %833 = fadd fast float %830, 0x3FC1EB8520000000
  %834 = fdiv fast float %819, %831
  %835 = fdiv fast float %820, %832
  %836 = fdiv fast float %821, %833
  br label %837

; <label>:837                                     ; preds = %812, %798
  %838 = phi float [ %834, %812 ], [ %808, %798 ]
  %839 = phi float [ %835, %812 ], [ %809, %798 ]
  %840 = phi float [ %836, %812 ], [ %810, %798 ]
  %841 = call float @dx.op.unary.f32(i32 7, float %838)  ; Saturate(value)
  %842 = call float @dx.op.unary.f32(i32 7, float %839)  ; Saturate(value)
  %843 = call float @dx.op.unary.f32(i32 7, float %840)  ; Saturate(value)
  %844 = call float @dx.op.dot3.f32(i32 55, float %841, float %842, float %843, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %845 = fsub fast float %841, %844
  %846 = fsub fast float %842, %844
  %847 = fsub fast float %843, %844
  %848 = fmul fast float %845, %7
  %849 = fmul fast float %846, %7
  %850 = fmul fast float %847, %7
  %851 = fadd fast float %848, %844
  %852 = fadd fast float %849, %844
  %853 = fadd fast float %850, %844
  %854 = call float @dx.op.unary.f32(i32 7, float %851)  ; Saturate(value)
  %855 = call float @dx.op.unary.f32(i32 7, float %852)  ; Saturate(value)
  %856 = call float @dx.op.unary.f32(i32 7, float %853)  ; Saturate(value)
  %857 = fadd fast float %854, 0xBFC70A3D80000000
  %858 = fadd fast float %855, 0xBFC70A3D80000000
  %859 = fadd fast float %856, 0xBFC70A3D80000000
  %860 = fmul fast float %857, %6
  %861 = fmul fast float %858, %6
  %862 = fmul fast float %859, %6
  %863 = fadd fast float %860, 0x3FC70A3D80000000
  %864 = fadd fast float %861, 0x3FC70A3D80000000
  %865 = fadd fast float %862, 0x3FC70A3D80000000
  %866 = call float @dx.op.unary.f32(i32 7, float %863)  ; Saturate(value)
  %867 = call float @dx.op.unary.f32(i32 7, float %864)  ; Saturate(value)
  %868 = call float @dx.op.unary.f32(i32 7, float %865)  ; Saturate(value)
  br label %869

; <label>:869                                     ; preds = %837, %670
  %870 = phi float [ %701, %670 ], [ %866, %837 ]
  %871 = phi float [ %702, %670 ], [ %867, %837 ]
  %872 = phi float [ %703, %670 ], [ %868, %837 ]
  %873 = add i32 %44, 1
  %874 = call i32 @dx.op.binary.i32(i32 37, i32 %873, i32 0)  ; IMax(a,b)
  %875 = call i32 @dx.op.binary.i32(i32 38, i32 %874, i32 %222)  ; IMin(a,b)
  %876 = call i32 @dx.op.binary.i32(i32 37, i32 %875, i32 0)  ; IMax(a,b)
  %877 = call i32 @dx.op.binary.i32(i32 38, i32 %876, i32 %222)  ; IMin(a,b)
  %878 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %877, i32 %663, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %879 = extractvalue %dx.types.ResRet.f32 %878, 0
  %880 = extractvalue %dx.types.ResRet.f32 %878, 1
  %881 = extractvalue %dx.types.ResRet.f32 %878, 2
  %882 = extractvalue %dx.types.ResRet.f32 %878, 3
  %883 = fcmp fast olt float %882, 0.000000e+00
  br i1 %883, label %884, label %918

; <label>:884                                     ; preds = %869
  %885 = fcmp fast ogt float %879, 0x3FA4B5DCC0000000
  %886 = fcmp fast ogt float %880, 0x3FA4B5DCC0000000
  %887 = fcmp fast ogt float %881, 0x3FA4B5DCC0000000
  %888 = select i1 %885, float 0.000000e+00, float 1.000000e+00
  %889 = select i1 %886, float 0.000000e+00, float 1.000000e+00
  %890 = select i1 %887, float 0.000000e+00, float 1.000000e+00
  %891 = fmul fast float %879, 0x3FB3D07220000000
  %892 = fmul fast float %880, 0x3FB3D07220000000
  %893 = fmul fast float %881, 0x3FB3D07220000000
  %894 = fadd fast float %879, 0x3FAC28F5C0000000
  %895 = fadd fast float %880, 0x3FAC28F5C0000000
  %896 = fadd fast float %881, 0x3FAC28F5C0000000
  %897 = fmul fast float %894, 0x3FEE54EDE0000000
  %898 = fmul fast float %895, 0x3FEE54EDE0000000
  %899 = fmul fast float %896, 0x3FEE54EDE0000000
  %900 = call float @dx.op.unary.f32(i32 23, float %897)  ; Log(value)
  %901 = call float @dx.op.unary.f32(i32 23, float %898)  ; Log(value)
  %902 = call float @dx.op.unary.f32(i32 23, float %899)  ; Log(value)
  %903 = fmul fast float %900, 0x4003333340000000
  %904 = fmul fast float %901, 0x4003333340000000
  %905 = fmul fast float %902, 0x4003333340000000
  %906 = call float @dx.op.unary.f32(i32 21, float %903)  ; Exp(value)
  %907 = call float @dx.op.unary.f32(i32 21, float %904)  ; Exp(value)
  %908 = call float @dx.op.unary.f32(i32 21, float %905)  ; Exp(value)
  %909 = fsub fast float %891, %906
  %910 = fsub fast float %892, %907
  %911 = fsub fast float %893, %908
  %912 = fmul fast float %909, %888
  %913 = fmul fast float %910, %889
  %914 = fmul fast float %911, %890
  %915 = fadd fast float %912, %906
  %916 = fadd fast float %913, %907
  %917 = fadd fast float %914, %908
  br label %1083

; <label>:918                                     ; preds = %869
  %919 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %877, i32 %663, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %920 = extractvalue %dx.types.ResRet.f32 %919, 0
  %921 = fcmp fast ogt float %37, 5.000000e-01
  %922 = fcmp fast olt float %920, 1.000000e+00
  %923 = and i1 %921, %922
  br i1 %923, label %924, label %1012

; <label>:924                                     ; preds = %918
  %925 = sitofp i32 %877 to float
  %926 = sitofp i32 %663 to float
  %927 = fadd fast float %925, 5.000000e-01
  %928 = fadd fast float %926, 5.000000e-01
  %929 = uitofp i32 %42 to float
  %930 = uitofp i32 %43 to float
  %931 = fdiv fast float %927, %929
  %932 = fdiv fast float %928, %930
  %933 = fmul fast float %931, 2.000000e+00
  %934 = fmul fast float %932, 2.000000e+00
  %935 = fadd fast float %933, -1.000000e+00
  %936 = fsub fast float 1.000000e+00, %934
  %937 = fmul fast float %935, %34
  %938 = call float @dx.op.tertiary.f32(i32 46, float %936, float %30, float %937)  ; FMad(a,b,c)
  %939 = call float @dx.op.tertiary.f32(i32 46, float %920, float %26, float %938)  ; FMad(a,b,c)
  %940 = fadd fast float %939, %22
  %941 = call float @dx.op.unary.f32(i32 6, float %940)  ; FAbs(value)
  %942 = fcmp fast ogt float %941, 0x3EB0C6F7A0000000
  br i1 %942, label %943, label %1012

; <label>:943                                     ; preds = %924
  %944 = fmul fast float %935, %33
  %945 = call float @dx.op.tertiary.f32(i32 46, float %936, float %29, float %944)  ; FMad(a,b,c)
  %946 = call float @dx.op.tertiary.f32(i32 46, float %920, float %25, float %945)  ; FMad(a,b,c)
  %947 = fadd fast float %946, %21
  %948 = fmul fast float %935, %32
  %949 = call float @dx.op.tertiary.f32(i32 46, float %936, float %28, float %948)  ; FMad(a,b,c)
  %950 = call float @dx.op.tertiary.f32(i32 46, float %920, float %24, float %949)  ; FMad(a,b,c)
  %951 = fadd fast float %950, %20
  %952 = fmul fast float %935, %31
  %953 = call float @dx.op.tertiary.f32(i32 46, float %936, float %27, float %952)  ; FMad(a,b,c)
  %954 = call float @dx.op.tertiary.f32(i32 46, float %920, float %23, float %953)  ; FMad(a,b,c)
  %955 = fadd fast float %954, %19
  %956 = fdiv fast float %955, %940
  %957 = fdiv fast float %951, %940
  %958 = fdiv fast float %947, %940
  %959 = fsub fast float %956, %16
  %960 = fsub fast float %957, %17
  %961 = fsub fast float %958, %18
  %962 = fmul fast float %959, %959
  %963 = fmul fast float %960, %960
  %964 = fadd fast float %963, %962
  %965 = fmul fast float %961, %961
  %966 = fadd fast float %964, %965
  %967 = call float @dx.op.unary.f32(i32 24, float %966)  ; Sqrt(value)
  %968 = fsub fast float %967, %8
  %969 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %968)  ; FMax(a,b)
  %970 = fcmp fast ogt float %38, 1.500000e+00
  br i1 %970, label %971, label %994

; <label>:971                                     ; preds = %943
  %972 = call float @dx.op.unary.f32(i32 6, float %960)  ; FAbs(value)
  %973 = fmul fast float %972, %10
  %974 = fcmp fast olt float %973, 0x3F50624DE0000000
  br i1 %974, label %975, label %978

; <label>:975                                     ; preds = %971
  %976 = fmul fast float %973, 5.000000e-01
  %977 = fsub fast float 1.000000e+00, %976
  br label %983

; <label>:978                                     ; preds = %971
  %979 = fmul fast float %973, 0xBFF7154760000000
  %980 = call float @dx.op.unary.f32(i32 21, float %979)  ; Exp(value)
  %981 = fsub fast float 1.000000e+00, %980
  %982 = fdiv fast float %981, %973
  br label %983

; <label>:983                                     ; preds = %978, %975
  %984 = phi float [ %977, %975 ], [ %982, %978 ]
  %985 = call float @dx.op.binary.f32(i32 36, float %957, float %17)  ; FMin(a,b)
  %986 = fsub fast float %985, %9
  %987 = fmul fast float %10, %986
  %988 = fsub fast float -0.000000e+00, %987
  %989 = call float @dx.op.binary.f32(i32 35, float %988, float -4.000000e+01)  ; FMax(a,b)
  %990 = call float @dx.op.binary.f32(i32 36, float %989, float 5.000000e+00)  ; FMin(a,b)
  %991 = fmul fast float %990, 0x3FF7154760000000
  %992 = call float @dx.op.unary.f32(i32 21, float %991)  ; Exp(value)
  %993 = fmul fast float %992, %984
  br label %994

; <label>:994                                     ; preds = %983, %943
  %995 = phi float [ %993, %983 ], [ 1.000000e+00, %943 ]
  %996 = fmul fast float %969, %15
  %997 = fmul fast float %996, %995
  %998 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %997)  ; FMin(a,b)
  %999 = fmul fast float %998, 0xBFF7154760000000
  %1000 = call float @dx.op.unary.f32(i32 21, float %999)  ; Exp(value)
  %1001 = fsub fast float 1.000000e+00, %1000
  %1002 = call float @dx.op.binary.f32(i32 36, float %11, float %1001)  ; FMin(a,b)
  %1003 = fsub fast float %12, %879
  %1004 = fsub fast float %13, %880
  %1005 = fsub fast float %14, %881
  %1006 = fmul fast float %1002, %1003
  %1007 = fmul fast float %1002, %1004
  %1008 = fmul fast float %1002, %1005
  %1009 = fadd fast float %1006, %879
  %1010 = fadd fast float %1007, %880
  %1011 = fadd fast float %1008, %881
  br label %1012

; <label>:1012                                    ; preds = %994, %924, %918
  %1013 = phi float [ %1009, %994 ], [ %879, %924 ], [ %879, %918 ]
  %1014 = phi float [ %1010, %994 ], [ %880, %924 ], [ %880, %918 ]
  %1015 = phi float [ %1011, %994 ], [ %881, %924 ], [ %881, %918 ]
  %1016 = fadd fast float %4, 1.000000e+00
  %1017 = fadd fast float %5, 1.000000e+00
  %1018 = fsub fast float 1.000000e+00, %4
  %1019 = fmul fast float %35, %1016
  %1020 = fmul fast float %35, %1017
  %1021 = fmul fast float %35, %1018
  %1022 = fmul fast float %1019, %1013
  %1023 = fmul fast float %1020, %1014
  %1024 = fmul fast float %1021, %1015
  %1025 = fcmp fast ult float %36, 5.000000e-01
  br i1 %1025, label %1051, label %1026

; <label>:1026                                    ; preds = %1012
  %1027 = fmul fast float %1022, 0x4004147AE0000000
  %1028 = fmul fast float %1023, 0x4004147AE0000000
  %1029 = fmul fast float %1024, 0x4004147AE0000000
  %1030 = fadd fast float %1027, 0x3F9EB851E0000000
  %1031 = fadd fast float %1028, 0x3F9EB851E0000000
  %1032 = fadd fast float %1029, 0x3F9EB851E0000000
  %1033 = fmul fast float %1030, %1022
  %1034 = fmul fast float %1031, %1023
  %1035 = fmul fast float %1032, %1024
  %1036 = fmul fast float %1022, 0x400370A3E0000000
  %1037 = fmul fast float %1023, 0x400370A3E0000000
  %1038 = fmul fast float %1024, 0x400370A3E0000000
  %1039 = fadd fast float %1036, 0x3FE2E147A0000000
  %1040 = fadd fast float %1037, 0x3FE2E147A0000000
  %1041 = fadd fast float %1038, 0x3FE2E147A0000000
  %1042 = fmul fast float %1039, %1022
  %1043 = fmul fast float %1040, %1023
  %1044 = fmul fast float %1041, %1024
  %1045 = fadd fast float %1042, 0x3FC1EB8520000000
  %1046 = fadd fast float %1043, 0x3FC1EB8520000000
  %1047 = fadd fast float %1044, 0x3FC1EB8520000000
  %1048 = fdiv fast float %1033, %1045
  %1049 = fdiv fast float %1034, %1046
  %1050 = fdiv fast float %1035, %1047
  br label %1051

; <label>:1051                                    ; preds = %1026, %1012
  %1052 = phi float [ %1048, %1026 ], [ %1022, %1012 ]
  %1053 = phi float [ %1049, %1026 ], [ %1023, %1012 ]
  %1054 = phi float [ %1050, %1026 ], [ %1024, %1012 ]
  %1055 = call float @dx.op.unary.f32(i32 7, float %1052)  ; Saturate(value)
  %1056 = call float @dx.op.unary.f32(i32 7, float %1053)  ; Saturate(value)
  %1057 = call float @dx.op.unary.f32(i32 7, float %1054)  ; Saturate(value)
  %1058 = call float @dx.op.dot3.f32(i32 55, float %1055, float %1056, float %1057, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1059 = fsub fast float %1055, %1058
  %1060 = fsub fast float %1056, %1058
  %1061 = fsub fast float %1057, %1058
  %1062 = fmul fast float %1059, %7
  %1063 = fmul fast float %1060, %7
  %1064 = fmul fast float %1061, %7
  %1065 = fadd fast float %1062, %1058
  %1066 = fadd fast float %1063, %1058
  %1067 = fadd fast float %1064, %1058
  %1068 = call float @dx.op.unary.f32(i32 7, float %1065)  ; Saturate(value)
  %1069 = call float @dx.op.unary.f32(i32 7, float %1066)  ; Saturate(value)
  %1070 = call float @dx.op.unary.f32(i32 7, float %1067)  ; Saturate(value)
  %1071 = fadd fast float %1068, 0xBFC70A3D80000000
  %1072 = fadd fast float %1069, 0xBFC70A3D80000000
  %1073 = fadd fast float %1070, 0xBFC70A3D80000000
  %1074 = fmul fast float %1071, %6
  %1075 = fmul fast float %1072, %6
  %1076 = fmul fast float %1073, %6
  %1077 = fadd fast float %1074, 0x3FC70A3D80000000
  %1078 = fadd fast float %1075, 0x3FC70A3D80000000
  %1079 = fadd fast float %1076, 0x3FC70A3D80000000
  %1080 = call float @dx.op.unary.f32(i32 7, float %1077)  ; Saturate(value)
  %1081 = call float @dx.op.unary.f32(i32 7, float %1078)  ; Saturate(value)
  %1082 = call float @dx.op.unary.f32(i32 7, float %1079)  ; Saturate(value)
  br label %1083

; <label>:1083                                    ; preds = %1051, %884
  %1084 = phi float [ %915, %884 ], [ %1080, %1051 ]
  %1085 = phi float [ %916, %884 ], [ %1081, %1051 ]
  %1086 = phi float [ %917, %884 ], [ %1082, %1051 ]
  %1087 = call float @dx.op.binary.f32(i32 36, float %870, float %1084)  ; FMin(a,b)
  %1088 = call float @dx.op.binary.f32(i32 36, float %871, float %1085)  ; FMin(a,b)
  %1089 = call float @dx.op.binary.f32(i32 36, float %872, float %1086)  ; FMin(a,b)
  %1090 = call float @dx.op.binary.f32(i32 36, float %438, float %652)  ; FMin(a,b)
  %1091 = call float @dx.op.binary.f32(i32 36, float %439, float %653)  ; FMin(a,b)
  %1092 = call float @dx.op.binary.f32(i32 36, float %440, float %654)  ; FMin(a,b)
  %1093 = call float @dx.op.binary.f32(i32 36, float %1090, float %1087)  ; FMin(a,b)
  %1094 = call float @dx.op.binary.f32(i32 36, float %1091, float %1088)  ; FMin(a,b)
  %1095 = call float @dx.op.binary.f32(i32 36, float %1092, float %1089)  ; FMin(a,b)
  %1096 = call float @dx.op.binary.f32(i32 36, float %216, float %1093)  ; FMin(a,b)
  %1097 = call float @dx.op.binary.f32(i32 36, float %217, float %1094)  ; FMin(a,b)
  %1098 = call float @dx.op.binary.f32(i32 36, float %218, float %1095)  ; FMin(a,b)
  %1099 = call float @dx.op.binary.f32(i32 35, float %870, float %1084)  ; FMax(a,b)
  %1100 = call float @dx.op.binary.f32(i32 35, float %871, float %1085)  ; FMax(a,b)
  %1101 = call float @dx.op.binary.f32(i32 35, float %872, float %1086)  ; FMax(a,b)
  %1102 = call float @dx.op.binary.f32(i32 35, float %438, float %652)  ; FMax(a,b)
  %1103 = call float @dx.op.binary.f32(i32 35, float %439, float %653)  ; FMax(a,b)
  %1104 = call float @dx.op.binary.f32(i32 35, float %440, float %654)  ; FMax(a,b)
  %1105 = call float @dx.op.binary.f32(i32 35, float %1102, float %1099)  ; FMax(a,b)
  %1106 = call float @dx.op.binary.f32(i32 35, float %1103, float %1100)  ; FMax(a,b)
  %1107 = call float @dx.op.binary.f32(i32 35, float %1104, float %1101)  ; FMax(a,b)
  %1108 = call float @dx.op.binary.f32(i32 35, float %216, float %1105)  ; FMax(a,b)
  %1109 = call float @dx.op.binary.f32(i32 35, float %217, float %1106)  ; FMax(a,b)
  %1110 = call float @dx.op.binary.f32(i32 35, float %218, float %1107)  ; FMax(a,b)
  %1111 = fsub fast float %1108, %1096
  %1112 = fsub fast float %1109, %1097
  %1113 = fsub fast float %1110, %1098
  %1114 = call float @dx.op.unary.f32(i32 6, float %1111)  ; FAbs(value)
  %1115 = call float @dx.op.unary.f32(i32 6, float %1112)  ; FAbs(value)
  %1116 = call float @dx.op.unary.f32(i32 6, float %1113)  ; FAbs(value)
  %1117 = call float @dx.op.binary.f32(i32 35, float %1115, float %1116)  ; FMax(a,b)
  %1118 = call float @dx.op.binary.f32(i32 35, float %1114, float %1117)  ; FMax(a,b)
  %1119 = call float @dx.op.binary.f32(i32 35, float %1109, float %1110)  ; FMax(a,b)
  %1120 = call float @dx.op.binary.f32(i32 35, float %1108, float %1119)  ; FMax(a,b)
  %1121 = fmul fast float %1120, 1.250000e-01
  %1122 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1121)  ; FMax(a,b)
  %1123 = fcmp fast ogt float %1118, %1122
  br i1 %1123, label %1124, label %1186

; <label>:1124                                    ; preds = %1083
  %1125 = fsub fast float %438, %652
  %1126 = fsub fast float %439, %653
  %1127 = fsub fast float %440, %654
  %1128 = call float @dx.op.unary.f32(i32 6, float %1125)  ; FAbs(value)
  %1129 = call float @dx.op.unary.f32(i32 6, float %1126)  ; FAbs(value)
  %1130 = call float @dx.op.unary.f32(i32 6, float %1127)  ; FAbs(value)
  %1131 = call float @dx.op.binary.f32(i32 35, float %1129, float %1130)  ; FMax(a,b)
  %1132 = call float @dx.op.binary.f32(i32 35, float %1128, float %1131)  ; FMax(a,b)
  %1133 = fsub fast float %870, %1084
  %1134 = fsub fast float %871, %1085
  %1135 = fsub fast float %872, %1086
  %1136 = call float @dx.op.unary.f32(i32 6, float %1133)  ; FAbs(value)
  %1137 = call float @dx.op.unary.f32(i32 6, float %1134)  ; FAbs(value)
  %1138 = call float @dx.op.unary.f32(i32 6, float %1135)  ; FAbs(value)
  %1139 = call float @dx.op.binary.f32(i32 35, float %1137, float %1138)  ; FMax(a,b)
  %1140 = call float @dx.op.binary.f32(i32 35, float %1136, float %1139)  ; FMax(a,b)
  %1141 = fcmp fast olt float %1132, %1140
  %1142 = select i1 %1141, float %438, float %870
  %1143 = select i1 %1141, float %439, float %871
  %1144 = select i1 %1141, float %440, float %872
  %1145 = select i1 %1141, float %652, float %1084
  %1146 = select i1 %1141, float %653, float %1085
  %1147 = select i1 %1141, float %654, float %1086
  %1148 = fsub fast float %216, %1145
  %1149 = fsub fast float %217, %1146
  %1150 = fsub fast float %218, %1147
  %1151 = fsub fast float %216, %1142
  %1152 = fsub fast float %217, %1143
  %1153 = fsub fast float %218, %1144
  %1154 = call float @dx.op.dot3.f32(i32 55, float %1151, float %1152, float %1153, float %1148, float %1149, float %1150)  ; Dot3(ax,ay,az,bx,by,bz)
  %1155 = fcmp fast ogt float %1154, 0.000000e+00
  br i1 %1155, label %1156, label %1168

; <label>:1156                                    ; preds = %1124
  %1157 = fsub fast float %1142, %1145
  %1158 = fsub fast float %1143, %1146
  %1159 = fsub fast float %1144, %1147
  %1160 = call float @dx.op.unary.f32(i32 6, float %1157)  ; FAbs(value)
  %1161 = call float @dx.op.unary.f32(i32 6, float %1158)  ; FAbs(value)
  %1162 = call float @dx.op.unary.f32(i32 6, float %1159)  ; FAbs(value)
  %1163 = call float @dx.op.binary.f32(i32 35, float %1161, float %1162)  ; FMax(a,b)
  %1164 = call float @dx.op.binary.f32(i32 35, float %1160, float %1163)  ; FMax(a,b)
  %1165 = fmul fast float %1118, 2.500000e-01
  %1166 = fcmp fast olt float %1164, %1165
  %1167 = select i1 %1166, float 5.000000e-01, float 1.000000e+00
  br label %1168

; <label>:1168                                    ; preds = %1156, %1124
  %1169 = phi float [ 1.000000e+00, %1124 ], [ %1167, %1156 ]
  %1170 = fmul fast float %1169, %3
  %1171 = fadd fast float %1142, %1145
  %1172 = fadd fast float %1143, %1146
  %1173 = fadd fast float %1144, %1147
  %1174 = fmul fast float %1171, 5.000000e-01
  %1175 = fmul fast float %1172, 5.000000e-01
  %1176 = fmul fast float %1173, 5.000000e-01
  %1177 = fsub fast float %1174, %216
  %1178 = fsub fast float %1175, %217
  %1179 = fsub fast float %1176, %218
  %1180 = fmul fast float %1170, %1177
  %1181 = fmul fast float %1170, %1178
  %1182 = fmul fast float %1170, %1179
  %1183 = fadd fast float %1180, %216
  %1184 = fadd fast float %1181, %217
  %1185 = fadd fast float %1182, %218
  br label %1186

; <label>:1186                                    ; preds = %1168, %1083, %187
  %1187 = phi float [ %216, %187 ], [ %1183, %1168 ], [ %216, %1083 ]
  %1188 = phi float [ %217, %187 ], [ %1184, %1168 ], [ %217, %1083 ]
  %1189 = phi float [ %218, %187 ], [ %1185, %1168 ], [ %218, %1083 ]
  %1190 = fcmp fast ogt float %1187, 0x3F69A5C380000000
  %1191 = fcmp fast ogt float %1188, 0x3F69A5C380000000
  %1192 = fcmp fast ogt float %1189, 0x3F69A5C380000000
  %1193 = select i1 %1190, float 0.000000e+00, float 1.000000e+00
  %1194 = select i1 %1191, float 0.000000e+00, float 1.000000e+00
  %1195 = select i1 %1192, float 0.000000e+00, float 1.000000e+00
  %1196 = fmul fast float %1187, 0x4029D70A40000000
  %1197 = fmul fast float %1188, 0x4029D70A40000000
  %1198 = fmul fast float %1189, 0x4029D70A40000000
  %1199 = call float @dx.op.binary.f32(i32 35, float %1187, float 0.000000e+00)  ; FMax(a,b)
  %1200 = call float @dx.op.binary.f32(i32 35, float %1188, float 0.000000e+00)  ; FMax(a,b)
  %1201 = call float @dx.op.binary.f32(i32 35, float %1189, float 0.000000e+00)  ; FMax(a,b)
  %1202 = call float @dx.op.unary.f32(i32 23, float %1199)  ; Log(value)
  %1203 = call float @dx.op.unary.f32(i32 23, float %1200)  ; Log(value)
  %1204 = call float @dx.op.unary.f32(i32 23, float %1201)  ; Log(value)
  %1205 = fmul fast float %1202, 0x3FDAAAAAA0000000
  %1206 = fmul fast float %1203, 0x3FDAAAAAA0000000
  %1207 = fmul fast float %1204, 0x3FDAAAAAA0000000
  %1208 = call float @dx.op.unary.f32(i32 21, float %1205)  ; Exp(value)
  %1209 = call float @dx.op.unary.f32(i32 21, float %1206)  ; Exp(value)
  %1210 = call float @dx.op.unary.f32(i32 21, float %1207)  ; Exp(value)
  %1211 = fmul fast float %1208, 0x3FF0E147A0000000
  %1212 = fmul fast float %1209, 0x3FF0E147A0000000
  %1213 = fmul fast float %1210, 0x3FF0E147A0000000
  %1214 = fadd fast float %1211, 0xBFAC28F5C0000000
  %1215 = fadd fast float %1212, 0xBFAC28F5C0000000
  %1216 = fadd fast float %1213, 0xBFAC28F5C0000000
  %1217 = fsub fast float %1196, %1214
  %1218 = fsub fast float %1197, %1215
  %1219 = fsub fast float %1198, %1216
  %1220 = fmul fast float %1217, %1193
  %1221 = fmul fast float %1218, %1194
  %1222 = fmul fast float %1219, %1195
  %1223 = fadd fast float %1220, %1214
  %1224 = fadd fast float %1221, %1215
  %1225 = fadd fast float %1222, %1216
  br label %1226

; <label>:1226                                    ; preds = %1186, %52
  %1227 = phi float [ %47, %52 ], [ %1223, %1186 ]
  %1228 = phi float [ %48, %52 ], [ %1224, %1186 ]
  %1229 = phi float [ %49, %52 ], [ %1225, %1186 ]
  %1230 = phi float [ %53, %52 ], [ %50, %1186 ]
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %1227)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %1228)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %1229)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %1230)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 0, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !38, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, !37}
!36 = !{i32 9}
!37 = !{i32 3, i32 1}
!38 = !{!39}
!39 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
