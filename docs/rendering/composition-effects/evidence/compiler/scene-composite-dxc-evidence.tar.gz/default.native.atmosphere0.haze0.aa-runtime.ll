;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xy  
; TEXCOORD                 1   xyzw        2     NONE   float       
; TEXCOORD                 2   xyzw        3     NONE   float       
; TEXCOORD                 3   xyzw        4     NONE   float       
; TEXCOORD                 4   xyzw        5     NONE   float       
; TEXCOORD                 5   xyzw        6     NONE   float       
; TEXCOORD                 6   xyzw        7     NONE   float       
; TEXCOORD                 7   xyzw        8     NONE   float       
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float   x   
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
;
; shader hash: 457f3101bb946127980e030b9b79c1ca
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=0
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 1
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 40 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 40 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 40 }
;   output 3 depends on inputs: { 0, 1 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %1, i32 0)  ; GetDimensions(handle,mipLevel)
  %12 = extractvalue %dx.types.Dimensions %11, 0
  %13 = extractvalue %dx.types.Dimensions %11, 1
  %14 = fptosi float %9 to i32
  %15 = fptosi float %10 to i32
  %16 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %14, i32 %15, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %17 = extractvalue %dx.types.ResRet.f32 %16, 0
  %18 = extractvalue %dx.types.ResRet.f32 %16, 1
  %19 = extractvalue %dx.types.ResRet.f32 %16, 2
  %20 = extractvalue %dx.types.ResRet.f32 %16, 3
  %21 = fcmp fast olt float %20, 0.000000e+00
  br i1 %21, label %22, label %24

; <label>:22                                      ; preds = %0
  %23 = fsub fast float -1.000000e+00, %20
  br label %711

; <label>:24                                      ; preds = %0
  %25 = fadd fast float %3, 1.000000e+00
  %26 = fadd fast float %4, 1.000000e+00
  %27 = fsub fast float 1.000000e+00, %3
  %28 = fmul fast float %7, %25
  %29 = fmul fast float %7, %26
  %30 = fmul fast float %7, %27
  %31 = fmul fast float %28, %17
  %32 = fmul fast float %29, %18
  %33 = fmul fast float %30, %19
  %34 = fcmp fast ult float %8, 5.000000e-01
  br i1 %34, label %60, label %35

; <label>:35                                      ; preds = %24
  %36 = fmul fast float %31, 0x4004147AE0000000
  %37 = fmul fast float %32, 0x4004147AE0000000
  %38 = fmul fast float %33, 0x4004147AE0000000
  %39 = fadd fast float %36, 0x3F9EB851E0000000
  %40 = fadd fast float %37, 0x3F9EB851E0000000
  %41 = fadd fast float %38, 0x3F9EB851E0000000
  %42 = fmul fast float %39, %31
  %43 = fmul fast float %40, %32
  %44 = fmul fast float %41, %33
  %45 = fmul fast float %31, 0x400370A3E0000000
  %46 = fmul fast float %32, 0x400370A3E0000000
  %47 = fmul fast float %33, 0x400370A3E0000000
  %48 = fadd fast float %45, 0x3FE2E147A0000000
  %49 = fadd fast float %46, 0x3FE2E147A0000000
  %50 = fadd fast float %47, 0x3FE2E147A0000000
  %51 = fmul fast float %48, %31
  %52 = fmul fast float %49, %32
  %53 = fmul fast float %50, %33
  %54 = fadd fast float %51, 0x3FC1EB8520000000
  %55 = fadd fast float %52, 0x3FC1EB8520000000
  %56 = fadd fast float %53, 0x3FC1EB8520000000
  %57 = fdiv fast float %42, %54
  %58 = fdiv fast float %43, %55
  %59 = fdiv fast float %44, %56
  br label %60

; <label>:60                                      ; preds = %35, %24
  %61 = phi float [ %57, %35 ], [ %31, %24 ]
  %62 = phi float [ %58, %35 ], [ %32, %24 ]
  %63 = phi float [ %59, %35 ], [ %33, %24 ]
  %64 = call float @dx.op.unary.f32(i32 7, float %61)  ; Saturate(value)
  %65 = call float @dx.op.unary.f32(i32 7, float %62)  ; Saturate(value)
  %66 = call float @dx.op.unary.f32(i32 7, float %63)  ; Saturate(value)
  %67 = call float @dx.op.dot3.f32(i32 55, float %64, float %65, float %66, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %68 = fsub fast float %64, %67
  %69 = fsub fast float %65, %67
  %70 = fsub fast float %66, %67
  %71 = fmul fast float %68, %6
  %72 = fmul fast float %69, %6
  %73 = fmul fast float %70, %6
  %74 = fadd fast float %71, %67
  %75 = fadd fast float %72, %67
  %76 = fadd fast float %73, %67
  %77 = call float @dx.op.unary.f32(i32 7, float %74)  ; Saturate(value)
  %78 = call float @dx.op.unary.f32(i32 7, float %75)  ; Saturate(value)
  %79 = call float @dx.op.unary.f32(i32 7, float %76)  ; Saturate(value)
  %80 = fadd fast float %77, 0xBFC70A3D80000000
  %81 = fadd fast float %78, 0xBFC70A3D80000000
  %82 = fadd fast float %79, 0xBFC70A3D80000000
  %83 = fmul fast float %80, %5
  %84 = fmul fast float %81, %5
  %85 = fmul fast float %82, %5
  %86 = fadd fast float %83, 0x3FC70A3D80000000
  %87 = fadd fast float %84, 0x3FC70A3D80000000
  %88 = fadd fast float %85, 0x3FC70A3D80000000
  %89 = call float @dx.op.unary.f32(i32 7, float %86)  ; Saturate(value)
  %90 = call float @dx.op.unary.f32(i32 7, float %87)  ; Saturate(value)
  %91 = call float @dx.op.unary.f32(i32 7, float %88)  ; Saturate(value)
  %92 = fcmp fast ogt float %2, 0.000000e+00
  br i1 %92, label %93, label %671

; <label>:93                                      ; preds = %60
  %94 = add i32 %15, -1
  %95 = add i32 %12, -1
  %96 = add i32 %13, -1
  %97 = call i32 @dx.op.binary.i32(i32 37, i32 %14, i32 0)  ; IMax(a,b)
  %98 = call i32 @dx.op.binary.i32(i32 37, i32 %94, i32 0)  ; IMax(a,b)
  %99 = call i32 @dx.op.binary.i32(i32 38, i32 %97, i32 %95)  ; IMin(a,b)
  %100 = call i32 @dx.op.binary.i32(i32 38, i32 %98, i32 %96)  ; IMin(a,b)
  %101 = call i32 @dx.op.binary.i32(i32 37, i32 %99, i32 0)  ; IMax(a,b)
  %102 = call i32 @dx.op.binary.i32(i32 37, i32 %100, i32 0)  ; IMax(a,b)
  %103 = call i32 @dx.op.binary.i32(i32 38, i32 %101, i32 %95)  ; IMin(a,b)
  %104 = call i32 @dx.op.binary.i32(i32 38, i32 %102, i32 %96)  ; IMin(a,b)
  %105 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %103, i32 %104, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %106 = extractvalue %dx.types.ResRet.f32 %105, 0
  %107 = extractvalue %dx.types.ResRet.f32 %105, 1
  %108 = extractvalue %dx.types.ResRet.f32 %105, 2
  %109 = extractvalue %dx.types.ResRet.f32 %105, 3
  %110 = fcmp fast olt float %109, 0.000000e+00
  br i1 %110, label %111, label %145

; <label>:111                                     ; preds = %93
  %112 = fcmp fast ogt float %106, 0x3FA4B5DCC0000000
  %113 = fcmp fast ogt float %107, 0x3FA4B5DCC0000000
  %114 = fcmp fast ogt float %108, 0x3FA4B5DCC0000000
  %115 = select i1 %112, float 0.000000e+00, float 1.000000e+00
  %116 = select i1 %113, float 0.000000e+00, float 1.000000e+00
  %117 = select i1 %114, float 0.000000e+00, float 1.000000e+00
  %118 = fmul fast float %106, 0x3FB3D07220000000
  %119 = fmul fast float %107, 0x3FB3D07220000000
  %120 = fmul fast float %108, 0x3FB3D07220000000
  %121 = fadd fast float %106, 0x3FAC28F5C0000000
  %122 = fadd fast float %107, 0x3FAC28F5C0000000
  %123 = fadd fast float %108, 0x3FAC28F5C0000000
  %124 = fmul fast float %121, 0x3FEE54EDE0000000
  %125 = fmul fast float %122, 0x3FEE54EDE0000000
  %126 = fmul fast float %123, 0x3FEE54EDE0000000
  %127 = call float @dx.op.unary.f32(i32 23, float %124)  ; Log(value)
  %128 = call float @dx.op.unary.f32(i32 23, float %125)  ; Log(value)
  %129 = call float @dx.op.unary.f32(i32 23, float %126)  ; Log(value)
  %130 = fmul fast float %127, 0x4003333340000000
  %131 = fmul fast float %128, 0x4003333340000000
  %132 = fmul fast float %129, 0x4003333340000000
  %133 = call float @dx.op.unary.f32(i32 21, float %130)  ; Exp(value)
  %134 = call float @dx.op.unary.f32(i32 21, float %131)  ; Exp(value)
  %135 = call float @dx.op.unary.f32(i32 21, float %132)  ; Exp(value)
  %136 = fsub fast float %118, %133
  %137 = fsub fast float %119, %134
  %138 = fsub fast float %120, %135
  %139 = fmul fast float %136, %115
  %140 = fmul fast float %137, %116
  %141 = fmul fast float %138, %117
  %142 = fadd fast float %139, %133
  %143 = fadd fast float %140, %134
  %144 = fadd fast float %141, %135
  br label %213

; <label>:145                                     ; preds = %93
  %146 = fadd fast float %3, 1.000000e+00
  %147 = fadd fast float %4, 1.000000e+00
  %148 = fsub fast float 1.000000e+00, %3
  %149 = fmul fast float %7, %146
  %150 = fmul fast float %7, %147
  %151 = fmul fast float %7, %148
  %152 = fmul fast float %149, %106
  %153 = fmul fast float %150, %107
  %154 = fmul fast float %151, %108
  %155 = fcmp fast ult float %8, 5.000000e-01
  br i1 %155, label %181, label %156

; <label>:156                                     ; preds = %145
  %157 = fmul fast float %152, 0x4004147AE0000000
  %158 = fmul fast float %153, 0x4004147AE0000000
  %159 = fmul fast float %154, 0x4004147AE0000000
  %160 = fadd fast float %157, 0x3F9EB851E0000000
  %161 = fadd fast float %158, 0x3F9EB851E0000000
  %162 = fadd fast float %159, 0x3F9EB851E0000000
  %163 = fmul fast float %160, %152
  %164 = fmul fast float %161, %153
  %165 = fmul fast float %162, %154
  %166 = fmul fast float %152, 0x400370A3E0000000
  %167 = fmul fast float %153, 0x400370A3E0000000
  %168 = fmul fast float %154, 0x400370A3E0000000
  %169 = fadd fast float %166, 0x3FE2E147A0000000
  %170 = fadd fast float %167, 0x3FE2E147A0000000
  %171 = fadd fast float %168, 0x3FE2E147A0000000
  %172 = fmul fast float %169, %152
  %173 = fmul fast float %170, %153
  %174 = fmul fast float %171, %154
  %175 = fadd fast float %172, 0x3FC1EB8520000000
  %176 = fadd fast float %173, 0x3FC1EB8520000000
  %177 = fadd fast float %174, 0x3FC1EB8520000000
  %178 = fdiv fast float %163, %175
  %179 = fdiv fast float %164, %176
  %180 = fdiv fast float %165, %177
  br label %181

; <label>:181                                     ; preds = %156, %145
  %182 = phi float [ %178, %156 ], [ %152, %145 ]
  %183 = phi float [ %179, %156 ], [ %153, %145 ]
  %184 = phi float [ %180, %156 ], [ %154, %145 ]
  %185 = call float @dx.op.unary.f32(i32 7, float %182)  ; Saturate(value)
  %186 = call float @dx.op.unary.f32(i32 7, float %183)  ; Saturate(value)
  %187 = call float @dx.op.unary.f32(i32 7, float %184)  ; Saturate(value)
  %188 = call float @dx.op.dot3.f32(i32 55, float %185, float %186, float %187, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %189 = fsub fast float %185, %188
  %190 = fsub fast float %186, %188
  %191 = fsub fast float %187, %188
  %192 = fmul fast float %189, %6
  %193 = fmul fast float %190, %6
  %194 = fmul fast float %191, %6
  %195 = fadd fast float %192, %188
  %196 = fadd fast float %193, %188
  %197 = fadd fast float %194, %188
  %198 = call float @dx.op.unary.f32(i32 7, float %195)  ; Saturate(value)
  %199 = call float @dx.op.unary.f32(i32 7, float %196)  ; Saturate(value)
  %200 = call float @dx.op.unary.f32(i32 7, float %197)  ; Saturate(value)
  %201 = fadd fast float %198, 0xBFC70A3D80000000
  %202 = fadd fast float %199, 0xBFC70A3D80000000
  %203 = fadd fast float %200, 0xBFC70A3D80000000
  %204 = fmul fast float %201, %5
  %205 = fmul fast float %202, %5
  %206 = fmul fast float %203, %5
  %207 = fadd fast float %204, 0x3FC70A3D80000000
  %208 = fadd fast float %205, 0x3FC70A3D80000000
  %209 = fadd fast float %206, 0x3FC70A3D80000000
  %210 = call float @dx.op.unary.f32(i32 7, float %207)  ; Saturate(value)
  %211 = call float @dx.op.unary.f32(i32 7, float %208)  ; Saturate(value)
  %212 = call float @dx.op.unary.f32(i32 7, float %209)  ; Saturate(value)
  br label %213

; <label>:213                                     ; preds = %181, %111
  %214 = phi float [ %142, %111 ], [ %210, %181 ]
  %215 = phi float [ %143, %111 ], [ %211, %181 ]
  %216 = phi float [ %144, %111 ], [ %212, %181 ]
  %217 = add i32 %15, 1
  %218 = call i32 @dx.op.binary.i32(i32 37, i32 %217, i32 0)  ; IMax(a,b)
  %219 = call i32 @dx.op.binary.i32(i32 38, i32 %218, i32 %96)  ; IMin(a,b)
  %220 = call i32 @dx.op.binary.i32(i32 37, i32 %219, i32 0)  ; IMax(a,b)
  %221 = call i32 @dx.op.binary.i32(i32 38, i32 %220, i32 %96)  ; IMin(a,b)
  %222 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %103, i32 %221, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %223 = extractvalue %dx.types.ResRet.f32 %222, 0
  %224 = extractvalue %dx.types.ResRet.f32 %222, 1
  %225 = extractvalue %dx.types.ResRet.f32 %222, 2
  %226 = extractvalue %dx.types.ResRet.f32 %222, 3
  %227 = fcmp fast olt float %226, 0.000000e+00
  br i1 %227, label %228, label %262

; <label>:228                                     ; preds = %213
  %229 = fcmp fast ogt float %223, 0x3FA4B5DCC0000000
  %230 = fcmp fast ogt float %224, 0x3FA4B5DCC0000000
  %231 = fcmp fast ogt float %225, 0x3FA4B5DCC0000000
  %232 = select i1 %229, float 0.000000e+00, float 1.000000e+00
  %233 = select i1 %230, float 0.000000e+00, float 1.000000e+00
  %234 = select i1 %231, float 0.000000e+00, float 1.000000e+00
  %235 = fmul fast float %223, 0x3FB3D07220000000
  %236 = fmul fast float %224, 0x3FB3D07220000000
  %237 = fmul fast float %225, 0x3FB3D07220000000
  %238 = fadd fast float %223, 0x3FAC28F5C0000000
  %239 = fadd fast float %224, 0x3FAC28F5C0000000
  %240 = fadd fast float %225, 0x3FAC28F5C0000000
  %241 = fmul fast float %238, 0x3FEE54EDE0000000
  %242 = fmul fast float %239, 0x3FEE54EDE0000000
  %243 = fmul fast float %240, 0x3FEE54EDE0000000
  %244 = call float @dx.op.unary.f32(i32 23, float %241)  ; Log(value)
  %245 = call float @dx.op.unary.f32(i32 23, float %242)  ; Log(value)
  %246 = call float @dx.op.unary.f32(i32 23, float %243)  ; Log(value)
  %247 = fmul fast float %244, 0x4003333340000000
  %248 = fmul fast float %245, 0x4003333340000000
  %249 = fmul fast float %246, 0x4003333340000000
  %250 = call float @dx.op.unary.f32(i32 21, float %247)  ; Exp(value)
  %251 = call float @dx.op.unary.f32(i32 21, float %248)  ; Exp(value)
  %252 = call float @dx.op.unary.f32(i32 21, float %249)  ; Exp(value)
  %253 = fsub fast float %235, %250
  %254 = fsub fast float %236, %251
  %255 = fsub fast float %237, %252
  %256 = fmul fast float %253, %232
  %257 = fmul fast float %254, %233
  %258 = fmul fast float %255, %234
  %259 = fadd fast float %256, %250
  %260 = fadd fast float %257, %251
  %261 = fadd fast float %258, %252
  br label %330

; <label>:262                                     ; preds = %213
  %263 = fadd fast float %3, 1.000000e+00
  %264 = fadd fast float %4, 1.000000e+00
  %265 = fsub fast float 1.000000e+00, %3
  %266 = fmul fast float %7, %263
  %267 = fmul fast float %7, %264
  %268 = fmul fast float %7, %265
  %269 = fmul fast float %266, %223
  %270 = fmul fast float %267, %224
  %271 = fmul fast float %268, %225
  %272 = fcmp fast ult float %8, 5.000000e-01
  br i1 %272, label %298, label %273

; <label>:273                                     ; preds = %262
  %274 = fmul fast float %269, 0x4004147AE0000000
  %275 = fmul fast float %270, 0x4004147AE0000000
  %276 = fmul fast float %271, 0x4004147AE0000000
  %277 = fadd fast float %274, 0x3F9EB851E0000000
  %278 = fadd fast float %275, 0x3F9EB851E0000000
  %279 = fadd fast float %276, 0x3F9EB851E0000000
  %280 = fmul fast float %277, %269
  %281 = fmul fast float %278, %270
  %282 = fmul fast float %279, %271
  %283 = fmul fast float %269, 0x400370A3E0000000
  %284 = fmul fast float %270, 0x400370A3E0000000
  %285 = fmul fast float %271, 0x400370A3E0000000
  %286 = fadd fast float %283, 0x3FE2E147A0000000
  %287 = fadd fast float %284, 0x3FE2E147A0000000
  %288 = fadd fast float %285, 0x3FE2E147A0000000
  %289 = fmul fast float %286, %269
  %290 = fmul fast float %287, %270
  %291 = fmul fast float %288, %271
  %292 = fadd fast float %289, 0x3FC1EB8520000000
  %293 = fadd fast float %290, 0x3FC1EB8520000000
  %294 = fadd fast float %291, 0x3FC1EB8520000000
  %295 = fdiv fast float %280, %292
  %296 = fdiv fast float %281, %293
  %297 = fdiv fast float %282, %294
  br label %298

; <label>:298                                     ; preds = %273, %262
  %299 = phi float [ %295, %273 ], [ %269, %262 ]
  %300 = phi float [ %296, %273 ], [ %270, %262 ]
  %301 = phi float [ %297, %273 ], [ %271, %262 ]
  %302 = call float @dx.op.unary.f32(i32 7, float %299)  ; Saturate(value)
  %303 = call float @dx.op.unary.f32(i32 7, float %300)  ; Saturate(value)
  %304 = call float @dx.op.unary.f32(i32 7, float %301)  ; Saturate(value)
  %305 = call float @dx.op.dot3.f32(i32 55, float %302, float %303, float %304, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %306 = fsub fast float %302, %305
  %307 = fsub fast float %303, %305
  %308 = fsub fast float %304, %305
  %309 = fmul fast float %306, %6
  %310 = fmul fast float %307, %6
  %311 = fmul fast float %308, %6
  %312 = fadd fast float %309, %305
  %313 = fadd fast float %310, %305
  %314 = fadd fast float %311, %305
  %315 = call float @dx.op.unary.f32(i32 7, float %312)  ; Saturate(value)
  %316 = call float @dx.op.unary.f32(i32 7, float %313)  ; Saturate(value)
  %317 = call float @dx.op.unary.f32(i32 7, float %314)  ; Saturate(value)
  %318 = fadd fast float %315, 0xBFC70A3D80000000
  %319 = fadd fast float %316, 0xBFC70A3D80000000
  %320 = fadd fast float %317, 0xBFC70A3D80000000
  %321 = fmul fast float %318, %5
  %322 = fmul fast float %319, %5
  %323 = fmul fast float %320, %5
  %324 = fadd fast float %321, 0x3FC70A3D80000000
  %325 = fadd fast float %322, 0x3FC70A3D80000000
  %326 = fadd fast float %323, 0x3FC70A3D80000000
  %327 = call float @dx.op.unary.f32(i32 7, float %324)  ; Saturate(value)
  %328 = call float @dx.op.unary.f32(i32 7, float %325)  ; Saturate(value)
  %329 = call float @dx.op.unary.f32(i32 7, float %326)  ; Saturate(value)
  br label %330

; <label>:330                                     ; preds = %298, %228
  %331 = phi float [ %259, %228 ], [ %327, %298 ]
  %332 = phi float [ %260, %228 ], [ %328, %298 ]
  %333 = phi float [ %261, %228 ], [ %329, %298 ]
  %334 = add i32 %14, -1
  %335 = call i32 @dx.op.binary.i32(i32 37, i32 %334, i32 0)  ; IMax(a,b)
  %336 = call i32 @dx.op.binary.i32(i32 37, i32 %15, i32 0)  ; IMax(a,b)
  %337 = call i32 @dx.op.binary.i32(i32 38, i32 %335, i32 %95)  ; IMin(a,b)
  %338 = call i32 @dx.op.binary.i32(i32 38, i32 %336, i32 %96)  ; IMin(a,b)
  %339 = call i32 @dx.op.binary.i32(i32 37, i32 %337, i32 0)  ; IMax(a,b)
  %340 = call i32 @dx.op.binary.i32(i32 37, i32 %338, i32 0)  ; IMax(a,b)
  %341 = call i32 @dx.op.binary.i32(i32 38, i32 %339, i32 %95)  ; IMin(a,b)
  %342 = call i32 @dx.op.binary.i32(i32 38, i32 %340, i32 %96)  ; IMin(a,b)
  %343 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %341, i32 %342, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %344 = extractvalue %dx.types.ResRet.f32 %343, 0
  %345 = extractvalue %dx.types.ResRet.f32 %343, 1
  %346 = extractvalue %dx.types.ResRet.f32 %343, 2
  %347 = extractvalue %dx.types.ResRet.f32 %343, 3
  %348 = fcmp fast olt float %347, 0.000000e+00
  br i1 %348, label %349, label %383

; <label>:349                                     ; preds = %330
  %350 = fcmp fast ogt float %344, 0x3FA4B5DCC0000000
  %351 = fcmp fast ogt float %345, 0x3FA4B5DCC0000000
  %352 = fcmp fast ogt float %346, 0x3FA4B5DCC0000000
  %353 = select i1 %350, float 0.000000e+00, float 1.000000e+00
  %354 = select i1 %351, float 0.000000e+00, float 1.000000e+00
  %355 = select i1 %352, float 0.000000e+00, float 1.000000e+00
  %356 = fmul fast float %344, 0x3FB3D07220000000
  %357 = fmul fast float %345, 0x3FB3D07220000000
  %358 = fmul fast float %346, 0x3FB3D07220000000
  %359 = fadd fast float %344, 0x3FAC28F5C0000000
  %360 = fadd fast float %345, 0x3FAC28F5C0000000
  %361 = fadd fast float %346, 0x3FAC28F5C0000000
  %362 = fmul fast float %359, 0x3FEE54EDE0000000
  %363 = fmul fast float %360, 0x3FEE54EDE0000000
  %364 = fmul fast float %361, 0x3FEE54EDE0000000
  %365 = call float @dx.op.unary.f32(i32 23, float %362)  ; Log(value)
  %366 = call float @dx.op.unary.f32(i32 23, float %363)  ; Log(value)
  %367 = call float @dx.op.unary.f32(i32 23, float %364)  ; Log(value)
  %368 = fmul fast float %365, 0x4003333340000000
  %369 = fmul fast float %366, 0x4003333340000000
  %370 = fmul fast float %367, 0x4003333340000000
  %371 = call float @dx.op.unary.f32(i32 21, float %368)  ; Exp(value)
  %372 = call float @dx.op.unary.f32(i32 21, float %369)  ; Exp(value)
  %373 = call float @dx.op.unary.f32(i32 21, float %370)  ; Exp(value)
  %374 = fsub fast float %356, %371
  %375 = fsub fast float %357, %372
  %376 = fsub fast float %358, %373
  %377 = fmul fast float %374, %353
  %378 = fmul fast float %375, %354
  %379 = fmul fast float %376, %355
  %380 = fadd fast float %377, %371
  %381 = fadd fast float %378, %372
  %382 = fadd fast float %379, %373
  br label %451

; <label>:383                                     ; preds = %330
  %384 = fadd fast float %3, 1.000000e+00
  %385 = fadd fast float %4, 1.000000e+00
  %386 = fsub fast float 1.000000e+00, %3
  %387 = fmul fast float %7, %384
  %388 = fmul fast float %7, %385
  %389 = fmul fast float %7, %386
  %390 = fmul fast float %387, %344
  %391 = fmul fast float %388, %345
  %392 = fmul fast float %389, %346
  %393 = fcmp fast ult float %8, 5.000000e-01
  br i1 %393, label %419, label %394

; <label>:394                                     ; preds = %383
  %395 = fmul fast float %390, 0x4004147AE0000000
  %396 = fmul fast float %391, 0x4004147AE0000000
  %397 = fmul fast float %392, 0x4004147AE0000000
  %398 = fadd fast float %395, 0x3F9EB851E0000000
  %399 = fadd fast float %396, 0x3F9EB851E0000000
  %400 = fadd fast float %397, 0x3F9EB851E0000000
  %401 = fmul fast float %398, %390
  %402 = fmul fast float %399, %391
  %403 = fmul fast float %400, %392
  %404 = fmul fast float %390, 0x400370A3E0000000
  %405 = fmul fast float %391, 0x400370A3E0000000
  %406 = fmul fast float %392, 0x400370A3E0000000
  %407 = fadd fast float %404, 0x3FE2E147A0000000
  %408 = fadd fast float %405, 0x3FE2E147A0000000
  %409 = fadd fast float %406, 0x3FE2E147A0000000
  %410 = fmul fast float %407, %390
  %411 = fmul fast float %408, %391
  %412 = fmul fast float %409, %392
  %413 = fadd fast float %410, 0x3FC1EB8520000000
  %414 = fadd fast float %411, 0x3FC1EB8520000000
  %415 = fadd fast float %412, 0x3FC1EB8520000000
  %416 = fdiv fast float %401, %413
  %417 = fdiv fast float %402, %414
  %418 = fdiv fast float %403, %415
  br label %419

; <label>:419                                     ; preds = %394, %383
  %420 = phi float [ %416, %394 ], [ %390, %383 ]
  %421 = phi float [ %417, %394 ], [ %391, %383 ]
  %422 = phi float [ %418, %394 ], [ %392, %383 ]
  %423 = call float @dx.op.unary.f32(i32 7, float %420)  ; Saturate(value)
  %424 = call float @dx.op.unary.f32(i32 7, float %421)  ; Saturate(value)
  %425 = call float @dx.op.unary.f32(i32 7, float %422)  ; Saturate(value)
  %426 = call float @dx.op.dot3.f32(i32 55, float %423, float %424, float %425, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %427 = fsub fast float %423, %426
  %428 = fsub fast float %424, %426
  %429 = fsub fast float %425, %426
  %430 = fmul fast float %427, %6
  %431 = fmul fast float %428, %6
  %432 = fmul fast float %429, %6
  %433 = fadd fast float %430, %426
  %434 = fadd fast float %431, %426
  %435 = fadd fast float %432, %426
  %436 = call float @dx.op.unary.f32(i32 7, float %433)  ; Saturate(value)
  %437 = call float @dx.op.unary.f32(i32 7, float %434)  ; Saturate(value)
  %438 = call float @dx.op.unary.f32(i32 7, float %435)  ; Saturate(value)
  %439 = fadd fast float %436, 0xBFC70A3D80000000
  %440 = fadd fast float %437, 0xBFC70A3D80000000
  %441 = fadd fast float %438, 0xBFC70A3D80000000
  %442 = fmul fast float %439, %5
  %443 = fmul fast float %440, %5
  %444 = fmul fast float %441, %5
  %445 = fadd fast float %442, 0x3FC70A3D80000000
  %446 = fadd fast float %443, 0x3FC70A3D80000000
  %447 = fadd fast float %444, 0x3FC70A3D80000000
  %448 = call float @dx.op.unary.f32(i32 7, float %445)  ; Saturate(value)
  %449 = call float @dx.op.unary.f32(i32 7, float %446)  ; Saturate(value)
  %450 = call float @dx.op.unary.f32(i32 7, float %447)  ; Saturate(value)
  br label %451

; <label>:451                                     ; preds = %419, %349
  %452 = phi float [ %380, %349 ], [ %448, %419 ]
  %453 = phi float [ %381, %349 ], [ %449, %419 ]
  %454 = phi float [ %382, %349 ], [ %450, %419 ]
  %455 = add i32 %14, 1
  %456 = call i32 @dx.op.binary.i32(i32 37, i32 %455, i32 0)  ; IMax(a,b)
  %457 = call i32 @dx.op.binary.i32(i32 38, i32 %456, i32 %95)  ; IMin(a,b)
  %458 = call i32 @dx.op.binary.i32(i32 37, i32 %457, i32 0)  ; IMax(a,b)
  %459 = call i32 @dx.op.binary.i32(i32 38, i32 %458, i32 %95)  ; IMin(a,b)
  %460 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %459, i32 %342, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %461 = extractvalue %dx.types.ResRet.f32 %460, 0
  %462 = extractvalue %dx.types.ResRet.f32 %460, 1
  %463 = extractvalue %dx.types.ResRet.f32 %460, 2
  %464 = extractvalue %dx.types.ResRet.f32 %460, 3
  %465 = fcmp fast olt float %464, 0.000000e+00
  br i1 %465, label %466, label %500

; <label>:466                                     ; preds = %451
  %467 = fcmp fast ogt float %461, 0x3FA4B5DCC0000000
  %468 = fcmp fast ogt float %462, 0x3FA4B5DCC0000000
  %469 = fcmp fast ogt float %463, 0x3FA4B5DCC0000000
  %470 = select i1 %467, float 0.000000e+00, float 1.000000e+00
  %471 = select i1 %468, float 0.000000e+00, float 1.000000e+00
  %472 = select i1 %469, float 0.000000e+00, float 1.000000e+00
  %473 = fmul fast float %461, 0x3FB3D07220000000
  %474 = fmul fast float %462, 0x3FB3D07220000000
  %475 = fmul fast float %463, 0x3FB3D07220000000
  %476 = fadd fast float %461, 0x3FAC28F5C0000000
  %477 = fadd fast float %462, 0x3FAC28F5C0000000
  %478 = fadd fast float %463, 0x3FAC28F5C0000000
  %479 = fmul fast float %476, 0x3FEE54EDE0000000
  %480 = fmul fast float %477, 0x3FEE54EDE0000000
  %481 = fmul fast float %478, 0x3FEE54EDE0000000
  %482 = call float @dx.op.unary.f32(i32 23, float %479)  ; Log(value)
  %483 = call float @dx.op.unary.f32(i32 23, float %480)  ; Log(value)
  %484 = call float @dx.op.unary.f32(i32 23, float %481)  ; Log(value)
  %485 = fmul fast float %482, 0x4003333340000000
  %486 = fmul fast float %483, 0x4003333340000000
  %487 = fmul fast float %484, 0x4003333340000000
  %488 = call float @dx.op.unary.f32(i32 21, float %485)  ; Exp(value)
  %489 = call float @dx.op.unary.f32(i32 21, float %486)  ; Exp(value)
  %490 = call float @dx.op.unary.f32(i32 21, float %487)  ; Exp(value)
  %491 = fsub fast float %473, %488
  %492 = fsub fast float %474, %489
  %493 = fsub fast float %475, %490
  %494 = fmul fast float %491, %470
  %495 = fmul fast float %492, %471
  %496 = fmul fast float %493, %472
  %497 = fadd fast float %494, %488
  %498 = fadd fast float %495, %489
  %499 = fadd fast float %496, %490
  br label %568

; <label>:500                                     ; preds = %451
  %501 = fadd fast float %3, 1.000000e+00
  %502 = fadd fast float %4, 1.000000e+00
  %503 = fsub fast float 1.000000e+00, %3
  %504 = fmul fast float %7, %501
  %505 = fmul fast float %7, %502
  %506 = fmul fast float %7, %503
  %507 = fmul fast float %504, %461
  %508 = fmul fast float %505, %462
  %509 = fmul fast float %506, %463
  %510 = fcmp fast ult float %8, 5.000000e-01
  br i1 %510, label %536, label %511

; <label>:511                                     ; preds = %500
  %512 = fmul fast float %507, 0x4004147AE0000000
  %513 = fmul fast float %508, 0x4004147AE0000000
  %514 = fmul fast float %509, 0x4004147AE0000000
  %515 = fadd fast float %512, 0x3F9EB851E0000000
  %516 = fadd fast float %513, 0x3F9EB851E0000000
  %517 = fadd fast float %514, 0x3F9EB851E0000000
  %518 = fmul fast float %515, %507
  %519 = fmul fast float %516, %508
  %520 = fmul fast float %517, %509
  %521 = fmul fast float %507, 0x400370A3E0000000
  %522 = fmul fast float %508, 0x400370A3E0000000
  %523 = fmul fast float %509, 0x400370A3E0000000
  %524 = fadd fast float %521, 0x3FE2E147A0000000
  %525 = fadd fast float %522, 0x3FE2E147A0000000
  %526 = fadd fast float %523, 0x3FE2E147A0000000
  %527 = fmul fast float %524, %507
  %528 = fmul fast float %525, %508
  %529 = fmul fast float %526, %509
  %530 = fadd fast float %527, 0x3FC1EB8520000000
  %531 = fadd fast float %528, 0x3FC1EB8520000000
  %532 = fadd fast float %529, 0x3FC1EB8520000000
  %533 = fdiv fast float %518, %530
  %534 = fdiv fast float %519, %531
  %535 = fdiv fast float %520, %532
  br label %536

; <label>:536                                     ; preds = %511, %500
  %537 = phi float [ %533, %511 ], [ %507, %500 ]
  %538 = phi float [ %534, %511 ], [ %508, %500 ]
  %539 = phi float [ %535, %511 ], [ %509, %500 ]
  %540 = call float @dx.op.unary.f32(i32 7, float %537)  ; Saturate(value)
  %541 = call float @dx.op.unary.f32(i32 7, float %538)  ; Saturate(value)
  %542 = call float @dx.op.unary.f32(i32 7, float %539)  ; Saturate(value)
  %543 = call float @dx.op.dot3.f32(i32 55, float %540, float %541, float %542, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %544 = fsub fast float %540, %543
  %545 = fsub fast float %541, %543
  %546 = fsub fast float %542, %543
  %547 = fmul fast float %544, %6
  %548 = fmul fast float %545, %6
  %549 = fmul fast float %546, %6
  %550 = fadd fast float %547, %543
  %551 = fadd fast float %548, %543
  %552 = fadd fast float %549, %543
  %553 = call float @dx.op.unary.f32(i32 7, float %550)  ; Saturate(value)
  %554 = call float @dx.op.unary.f32(i32 7, float %551)  ; Saturate(value)
  %555 = call float @dx.op.unary.f32(i32 7, float %552)  ; Saturate(value)
  %556 = fadd fast float %553, 0xBFC70A3D80000000
  %557 = fadd fast float %554, 0xBFC70A3D80000000
  %558 = fadd fast float %555, 0xBFC70A3D80000000
  %559 = fmul fast float %556, %5
  %560 = fmul fast float %557, %5
  %561 = fmul fast float %558, %5
  %562 = fadd fast float %559, 0x3FC70A3D80000000
  %563 = fadd fast float %560, 0x3FC70A3D80000000
  %564 = fadd fast float %561, 0x3FC70A3D80000000
  %565 = call float @dx.op.unary.f32(i32 7, float %562)  ; Saturate(value)
  %566 = call float @dx.op.unary.f32(i32 7, float %563)  ; Saturate(value)
  %567 = call float @dx.op.unary.f32(i32 7, float %564)  ; Saturate(value)
  br label %568

; <label>:568                                     ; preds = %536, %466
  %569 = phi float [ %497, %466 ], [ %565, %536 ]
  %570 = phi float [ %498, %466 ], [ %566, %536 ]
  %571 = phi float [ %499, %466 ], [ %567, %536 ]
  %572 = call float @dx.op.binary.f32(i32 36, float %452, float %569)  ; FMin(a,b)
  %573 = call float @dx.op.binary.f32(i32 36, float %453, float %570)  ; FMin(a,b)
  %574 = call float @dx.op.binary.f32(i32 36, float %454, float %571)  ; FMin(a,b)
  %575 = call float @dx.op.binary.f32(i32 36, float %214, float %331)  ; FMin(a,b)
  %576 = call float @dx.op.binary.f32(i32 36, float %215, float %332)  ; FMin(a,b)
  %577 = call float @dx.op.binary.f32(i32 36, float %216, float %333)  ; FMin(a,b)
  %578 = call float @dx.op.binary.f32(i32 36, float %575, float %572)  ; FMin(a,b)
  %579 = call float @dx.op.binary.f32(i32 36, float %576, float %573)  ; FMin(a,b)
  %580 = call float @dx.op.binary.f32(i32 36, float %577, float %574)  ; FMin(a,b)
  %581 = call float @dx.op.binary.f32(i32 36, float %89, float %578)  ; FMin(a,b)
  %582 = call float @dx.op.binary.f32(i32 36, float %90, float %579)  ; FMin(a,b)
  %583 = call float @dx.op.binary.f32(i32 36, float %91, float %580)  ; FMin(a,b)
  %584 = call float @dx.op.binary.f32(i32 35, float %452, float %569)  ; FMax(a,b)
  %585 = call float @dx.op.binary.f32(i32 35, float %453, float %570)  ; FMax(a,b)
  %586 = call float @dx.op.binary.f32(i32 35, float %454, float %571)  ; FMax(a,b)
  %587 = call float @dx.op.binary.f32(i32 35, float %214, float %331)  ; FMax(a,b)
  %588 = call float @dx.op.binary.f32(i32 35, float %215, float %332)  ; FMax(a,b)
  %589 = call float @dx.op.binary.f32(i32 35, float %216, float %333)  ; FMax(a,b)
  %590 = call float @dx.op.binary.f32(i32 35, float %587, float %584)  ; FMax(a,b)
  %591 = call float @dx.op.binary.f32(i32 35, float %588, float %585)  ; FMax(a,b)
  %592 = call float @dx.op.binary.f32(i32 35, float %589, float %586)  ; FMax(a,b)
  %593 = call float @dx.op.binary.f32(i32 35, float %89, float %590)  ; FMax(a,b)
  %594 = call float @dx.op.binary.f32(i32 35, float %90, float %591)  ; FMax(a,b)
  %595 = call float @dx.op.binary.f32(i32 35, float %91, float %592)  ; FMax(a,b)
  %596 = fsub fast float %593, %581
  %597 = fsub fast float %594, %582
  %598 = fsub fast float %595, %583
  %599 = call float @dx.op.unary.f32(i32 6, float %596)  ; FAbs(value)
  %600 = call float @dx.op.unary.f32(i32 6, float %597)  ; FAbs(value)
  %601 = call float @dx.op.unary.f32(i32 6, float %598)  ; FAbs(value)
  %602 = call float @dx.op.binary.f32(i32 35, float %600, float %601)  ; FMax(a,b)
  %603 = call float @dx.op.binary.f32(i32 35, float %599, float %602)  ; FMax(a,b)
  %604 = call float @dx.op.binary.f32(i32 35, float %594, float %595)  ; FMax(a,b)
  %605 = call float @dx.op.binary.f32(i32 35, float %593, float %604)  ; FMax(a,b)
  %606 = fmul fast float %605, 1.250000e-01
  %607 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %606)  ; FMax(a,b)
  %608 = fcmp fast ogt float %603, %607
  br i1 %608, label %609, label %671

; <label>:609                                     ; preds = %568
  %610 = fsub fast float %214, %331
  %611 = fsub fast float %215, %332
  %612 = fsub fast float %216, %333
  %613 = call float @dx.op.unary.f32(i32 6, float %610)  ; FAbs(value)
  %614 = call float @dx.op.unary.f32(i32 6, float %611)  ; FAbs(value)
  %615 = call float @dx.op.unary.f32(i32 6, float %612)  ; FAbs(value)
  %616 = call float @dx.op.binary.f32(i32 35, float %614, float %615)  ; FMax(a,b)
  %617 = call float @dx.op.binary.f32(i32 35, float %613, float %616)  ; FMax(a,b)
  %618 = fsub fast float %452, %569
  %619 = fsub fast float %453, %570
  %620 = fsub fast float %454, %571
  %621 = call float @dx.op.unary.f32(i32 6, float %618)  ; FAbs(value)
  %622 = call float @dx.op.unary.f32(i32 6, float %619)  ; FAbs(value)
  %623 = call float @dx.op.unary.f32(i32 6, float %620)  ; FAbs(value)
  %624 = call float @dx.op.binary.f32(i32 35, float %622, float %623)  ; FMax(a,b)
  %625 = call float @dx.op.binary.f32(i32 35, float %621, float %624)  ; FMax(a,b)
  %626 = fcmp fast olt float %617, %625
  %627 = select i1 %626, float %214, float %452
  %628 = select i1 %626, float %215, float %453
  %629 = select i1 %626, float %216, float %454
  %630 = select i1 %626, float %331, float %569
  %631 = select i1 %626, float %332, float %570
  %632 = select i1 %626, float %333, float %571
  %633 = fsub fast float %89, %630
  %634 = fsub fast float %90, %631
  %635 = fsub fast float %91, %632
  %636 = fsub fast float %89, %627
  %637 = fsub fast float %90, %628
  %638 = fsub fast float %91, %629
  %639 = call float @dx.op.dot3.f32(i32 55, float %636, float %637, float %638, float %633, float %634, float %635)  ; Dot3(ax,ay,az,bx,by,bz)
  %640 = fcmp fast ogt float %639, 0.000000e+00
  br i1 %640, label %641, label %653

; <label>:641                                     ; preds = %609
  %642 = fsub fast float %627, %630
  %643 = fsub fast float %628, %631
  %644 = fsub fast float %629, %632
  %645 = call float @dx.op.unary.f32(i32 6, float %642)  ; FAbs(value)
  %646 = call float @dx.op.unary.f32(i32 6, float %643)  ; FAbs(value)
  %647 = call float @dx.op.unary.f32(i32 6, float %644)  ; FAbs(value)
  %648 = call float @dx.op.binary.f32(i32 35, float %646, float %647)  ; FMax(a,b)
  %649 = call float @dx.op.binary.f32(i32 35, float %645, float %648)  ; FMax(a,b)
  %650 = fmul fast float %603, 2.500000e-01
  %651 = fcmp fast olt float %649, %650
  %652 = select i1 %651, float 5.000000e-01, float 1.000000e+00
  br label %653

; <label>:653                                     ; preds = %641, %609
  %654 = phi float [ 1.000000e+00, %609 ], [ %652, %641 ]
  %655 = fmul fast float %654, %2
  %656 = fadd fast float %627, %630
  %657 = fadd fast float %628, %631
  %658 = fadd fast float %629, %632
  %659 = fmul fast float %656, 5.000000e-01
  %660 = fmul fast float %657, 5.000000e-01
  %661 = fmul fast float %658, 5.000000e-01
  %662 = fsub fast float %659, %89
  %663 = fsub fast float %660, %90
  %664 = fsub fast float %661, %91
  %665 = fmul fast float %655, %662
  %666 = fmul fast float %655, %663
  %667 = fmul fast float %655, %664
  %668 = fadd fast float %665, %89
  %669 = fadd fast float %666, %90
  %670 = fadd fast float %667, %91
  br label %671

; <label>:671                                     ; preds = %653, %568, %60
  %672 = phi float [ %89, %60 ], [ %668, %653 ], [ %89, %568 ]
  %673 = phi float [ %90, %60 ], [ %669, %653 ], [ %90, %568 ]
  %674 = phi float [ %91, %60 ], [ %670, %653 ], [ %91, %568 ]
  %675 = fcmp fast ogt float %672, 0x3F69A5C380000000
  %676 = fcmp fast ogt float %673, 0x3F69A5C380000000
  %677 = fcmp fast ogt float %674, 0x3F69A5C380000000
  %678 = select i1 %675, float 0.000000e+00, float 1.000000e+00
  %679 = select i1 %676, float 0.000000e+00, float 1.000000e+00
  %680 = select i1 %677, float 0.000000e+00, float 1.000000e+00
  %681 = fmul fast float %672, 0x4029D70A40000000
  %682 = fmul fast float %673, 0x4029D70A40000000
  %683 = fmul fast float %674, 0x4029D70A40000000
  %684 = call float @dx.op.binary.f32(i32 35, float %672, float 0.000000e+00)  ; FMax(a,b)
  %685 = call float @dx.op.binary.f32(i32 35, float %673, float 0.000000e+00)  ; FMax(a,b)
  %686 = call float @dx.op.binary.f32(i32 35, float %674, float 0.000000e+00)  ; FMax(a,b)
  %687 = call float @dx.op.unary.f32(i32 23, float %684)  ; Log(value)
  %688 = call float @dx.op.unary.f32(i32 23, float %685)  ; Log(value)
  %689 = call float @dx.op.unary.f32(i32 23, float %686)  ; Log(value)
  %690 = fmul fast float %687, 0x3FDAAAAAA0000000
  %691 = fmul fast float %688, 0x3FDAAAAAA0000000
  %692 = fmul fast float %689, 0x3FDAAAAAA0000000
  %693 = call float @dx.op.unary.f32(i32 21, float %690)  ; Exp(value)
  %694 = call float @dx.op.unary.f32(i32 21, float %691)  ; Exp(value)
  %695 = call float @dx.op.unary.f32(i32 21, float %692)  ; Exp(value)
  %696 = fmul fast float %693, 0x3FF0E147A0000000
  %697 = fmul fast float %694, 0x3FF0E147A0000000
  %698 = fmul fast float %695, 0x3FF0E147A0000000
  %699 = fadd fast float %696, 0xBFAC28F5C0000000
  %700 = fadd fast float %697, 0xBFAC28F5C0000000
  %701 = fadd fast float %698, 0xBFAC28F5C0000000
  %702 = fsub fast float %681, %699
  %703 = fsub fast float %682, %700
  %704 = fsub fast float %683, %701
  %705 = fmul fast float %702, %678
  %706 = fmul fast float %703, %679
  %707 = fmul fast float %704, %680
  %708 = fadd fast float %705, %699
  %709 = fadd fast float %706, %700
  %710 = fadd fast float %707, %701
  br label %711

; <label>:711                                     ; preds = %671, %22
  %712 = phi float [ %17, %22 ], [ %708, %671 ]
  %713 = phi float [ %18, %22 ], [ %709, %671 ]
  %714 = phi float [ %19, %22 ], [ %710, %671 ]
  %715 = phi float [ %23, %22 ], [ %20, %671 ]
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %712)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %713)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %714)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %715)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!8}
!dx.entryPoints = !{!9}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 0, i32 0]}
!9 = !{void ()* @PSMain, !"PSMain", !10, !4, null}
!10 = !{!11, !36, null}
!11 = !{!12, !15, !16, !18, !20, !22, !24, !26, !28, !30, !33}
!12 = !{i32 0, !"SV_Position", i8 9, i8 3, !13, i8 4, i32 1, i8 4, i32 0, i8 0, !14}
!13 = !{i32 0}
!14 = !{i32 3, i32 3}
!15 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !13, i8 1, i32 1, i8 4, i32 1, i8 0, !14}
!16 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !17, i8 1, i32 1, i8 4, i32 2, i8 0, null}
!17 = !{i32 1}
!18 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 3, i8 0, null}
!19 = !{i32 2}
!20 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 4, i8 0, null}
!21 = !{i32 3}
!22 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 5, i8 0, null}
!23 = !{i32 4}
!24 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 6, i8 0, null}
!25 = !{i32 5}
!26 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 7, i8 0, null}
!27 = !{i32 6}
!28 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !29, i8 1, i32 1, i8 4, i32 8, i8 0, null}
!29 = !{i32 7}
!30 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !31, i8 1, i32 1, i8 4, i32 9, i8 0, !32}
!31 = !{i32 8}
!32 = !{i32 3, i32 15}
!33 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 10, i8 0, !35}
!34 = !{i32 9}
!35 = !{i32 3, i32 1}
!36 = !{!37}
!37 = !{i32 0, !"SV_Target", i8 9, i8 16, !13, i8 0, i32 1, i8 4, i32 0, i8 0, !32}
