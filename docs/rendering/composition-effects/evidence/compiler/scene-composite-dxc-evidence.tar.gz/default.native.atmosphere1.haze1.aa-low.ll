;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float       
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
;
; shader hash: 076163b2d576c714108d5dbece755051
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=0
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 1
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39 }
;   output 3 depends on inputs: { 0, 1 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %40 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %41 = extractvalue %dx.types.Dimensions %40, 0
  %42 = extractvalue %dx.types.Dimensions %40, 1
  %43 = fptosi float %38 to i32
  %44 = fptosi float %39 to i32
  %45 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %43, i32 %44, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %46 = extractvalue %dx.types.ResRet.f32 %45, 0
  %47 = extractvalue %dx.types.ResRet.f32 %45, 1
  %48 = extractvalue %dx.types.ResRet.f32 %45, 2
  %49 = extractvalue %dx.types.ResRet.f32 %45, 3
  %50 = fcmp fast olt float %49, 0.000000e+00
  br i1 %50, label %51, label %53

; <label>:51                                      ; preds = %0
  %52 = fsub fast float -1.000000e+00, %49
  br label %1482

; <label>:53                                      ; preds = %0
  %54 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %43, i32 %44, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %55 = extractvalue %dx.types.ResRet.f32 %54, 0
  %56 = fcmp fast ogt float %36, 5.000000e-01
  %57 = fcmp fast olt float %55, 1.000000e+00
  %58 = and i1 %56, %57
  br i1 %58, label %59, label %199

; <label>:59                                      ; preds = %53
  %60 = sitofp i32 %43 to float
  %61 = sitofp i32 %44 to float
  %62 = fadd fast float %60, 5.000000e-01
  %63 = fadd fast float %61, 5.000000e-01
  %64 = uitofp i32 %41 to float
  %65 = uitofp i32 %42 to float
  %66 = fdiv fast float %62, %64
  %67 = fdiv fast float %63, %65
  %68 = fmul fast float %66, 2.000000e+00
  %69 = fmul fast float %67, 2.000000e+00
  %70 = fadd fast float %68, -1.000000e+00
  %71 = fsub fast float 1.000000e+00, %69
  %72 = fmul fast float %70, %33
  %73 = call float @dx.op.tertiary.f32(i32 46, float %71, float %29, float %72)  ; FMad(a,b,c)
  %74 = call float @dx.op.tertiary.f32(i32 46, float %55, float %25, float %73)  ; FMad(a,b,c)
  %75 = fadd fast float %74, %21
  %76 = call float @dx.op.unary.f32(i32 6, float %75)  ; FAbs(value)
  %77 = fcmp fast ogt float %76, 0x3EB0C6F7A0000000
  br i1 %77, label %78, label %199

; <label>:78                                      ; preds = %59
  %79 = fmul fast float %70, %32
  %80 = call float @dx.op.tertiary.f32(i32 46, float %71, float %28, float %79)  ; FMad(a,b,c)
  %81 = call float @dx.op.tertiary.f32(i32 46, float %55, float %24, float %80)  ; FMad(a,b,c)
  %82 = fadd fast float %81, %20
  %83 = fmul fast float %70, %31
  %84 = call float @dx.op.tertiary.f32(i32 46, float %71, float %27, float %83)  ; FMad(a,b,c)
  %85 = call float @dx.op.tertiary.f32(i32 46, float %55, float %23, float %84)  ; FMad(a,b,c)
  %86 = fadd fast float %85, %19
  %87 = fmul fast float %70, %30
  %88 = call float @dx.op.tertiary.f32(i32 46, float %71, float %26, float %87)  ; FMad(a,b,c)
  %89 = call float @dx.op.tertiary.f32(i32 46, float %55, float %22, float %88)  ; FMad(a,b,c)
  %90 = fadd fast float %89, %18
  %91 = fdiv fast float %90, %75
  %92 = fdiv fast float %86, %75
  %93 = fdiv fast float %82, %75
  %94 = fsub fast float %91, %15
  %95 = fsub fast float %92, %16
  %96 = fsub fast float %93, %17
  %97 = fmul fast float %94, %94
  %98 = fmul fast float %95, %95
  %99 = fadd fast float %98, %97
  %100 = fmul fast float %96, %96
  %101 = fadd fast float %99, %100
  %102 = call float @dx.op.unary.f32(i32 24, float %101)  ; Sqrt(value)
  %103 = fsub fast float %102, %7
  %104 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %103)  ; FMax(a,b)
  %105 = fcmp fast ogt float %37, 1.500000e+00
  br i1 %105, label %106, label %129

; <label>:106                                     ; preds = %78
  %107 = call float @dx.op.unary.f32(i32 6, float %95)  ; FAbs(value)
  %108 = fmul fast float %107, %9
  %109 = fcmp fast olt float %108, 0x3F50624DE0000000
  br i1 %109, label %110, label %113

; <label>:110                                     ; preds = %106
  %111 = fmul fast float %108, 5.000000e-01
  %112 = fsub fast float 1.000000e+00, %111
  br label %118

; <label>:113                                     ; preds = %106
  %114 = fmul fast float %108, 0xBFF7154760000000
  %115 = call float @dx.op.unary.f32(i32 21, float %114)  ; Exp(value)
  %116 = fsub fast float 1.000000e+00, %115
  %117 = fdiv fast float %116, %108
  br label %118

; <label>:118                                     ; preds = %113, %110
  %119 = phi float [ %112, %110 ], [ %117, %113 ]
  %120 = call float @dx.op.binary.f32(i32 36, float %92, float %16)  ; FMin(a,b)
  %121 = fsub fast float %120, %8
  %122 = fmul fast float %9, %121
  %123 = fsub fast float -0.000000e+00, %122
  %124 = call float @dx.op.binary.f32(i32 35, float %123, float -4.000000e+01)  ; FMax(a,b)
  %125 = call float @dx.op.binary.f32(i32 36, float %124, float 5.000000e+00)  ; FMin(a,b)
  %126 = fmul fast float %125, 0x3FF7154760000000
  %127 = call float @dx.op.unary.f32(i32 21, float %126)  ; Exp(value)
  %128 = fmul fast float %127, %119
  br label %129

; <label>:129                                     ; preds = %118, %78
  %130 = phi float [ %128, %118 ], [ 1.000000e+00, %78 ]
  %131 = fmul fast float %104, %14
  %132 = fmul fast float %131, %130
  %133 = fcmp fast ole float %102, %7
  %134 = fcmp fast olt float %102, 0x3F1A36E2E0000000
  %135 = or i1 %133, %134
  br i1 %135, label %182, label %136

; <label>:136                                     ; preds = %129
  %137 = fdiv fast float %7, %102
  %138 = fmul fast float %137, %94
  %139 = fmul fast float %137, %95
  %140 = fmul fast float %137, %96
  %141 = fadd fast float %138, %15
  %142 = fadd fast float %139, %16
  %143 = fadd fast float %140, %17
  %144 = fadd fast float %141, -9.000000e+02
  %145 = fadd fast float %142, -1.500000e+01
  %146 = fadd fast float %143, -7.500000e+02
  %147 = fmul fast float %144, 0x3F62345680000000
  %148 = fmul fast float %145, 0x3F62345680000000
  %149 = fmul fast float %146, 0x3F62345680000000
  %150 = call float @dx.op.dot3.f32(i32 55, float %147, float %148, float %149, float %147, float %148, float %149)  ; Dot3(ax,ay,az,bx,by,bz)
  %151 = fsub fast float 1.000000e+00, %150
  %152 = call float @dx.op.unary.f32(i32 7, float %151)  ; Saturate(value)
  %153 = fmul fast float %152, %152
  %154 = fadd fast float %141, %91
  %155 = fadd fast float %142, %92
  %156 = fadd fast float %143, %93
  %157 = fmul fast float %154, 0x3F52345680000000
  %158 = fadd fast float %157, -2.000000e+00
  %159 = fmul fast float %155, 0x3F52345680000000
  %160 = fadd fast float %159, 0xBFA1111120000000
  %161 = fmul fast float %156, 0x3F52345680000000
  %162 = fadd fast float %161, 0xBFFAAAAAC0000000
  %163 = call float @dx.op.dot3.f32(i32 55, float %158, float %160, float %162, float %158, float %160, float %162)  ; Dot3(ax,ay,az,bx,by,bz)
  %164 = fsub fast float 1.000000e+00, %163
  %165 = call float @dx.op.unary.f32(i32 7, float %164)  ; Saturate(value)
  %166 = fmul fast float %165, %165
  %167 = fmul fast float %166, 4.000000e+00
  %168 = fadd fast float %167, %153
  %169 = fadd fast float %91, -9.000000e+02
  %170 = fadd fast float %92, -1.500000e+01
  %171 = fadd fast float %93, -7.500000e+02
  %172 = fmul fast float %169, 0x3F62345680000000
  %173 = fmul fast float %170, 0x3F62345680000000
  %174 = fmul fast float %171, 0x3F62345680000000
  %175 = call float @dx.op.dot3.f32(i32 55, float %172, float %173, float %174, float %172, float %173, float %174)  ; Dot3(ax,ay,az,bx,by,bz)
  %176 = fsub fast float 1.000000e+00, %175
  %177 = call float @dx.op.unary.f32(i32 7, float %176)  ; Saturate(value)
  %178 = fmul fast float %177, %177
  %179 = fadd fast float %168, %178
  %180 = fmul fast float %103, 0x3F25D867E0000000
  %181 = fmul fast float %180, %179
  br label %182

; <label>:182                                     ; preds = %136, %129
  %183 = phi float [ %181, %136 ], [ 0.000000e+00, %129 ]
  %184 = fadd fast float %183, %132
  %185 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %184)  ; FMin(a,b)
  %186 = fmul fast float %185, 0xBFF7154760000000
  %187 = call float @dx.op.unary.f32(i32 21, float %186)  ; Exp(value)
  %188 = fsub fast float 1.000000e+00, %187
  %189 = call float @dx.op.binary.f32(i32 36, float %10, float %188)  ; FMin(a,b)
  %190 = fsub fast float %11, %46
  %191 = fsub fast float %12, %47
  %192 = fsub fast float %13, %48
  %193 = fmul fast float %189, %190
  %194 = fmul fast float %189, %191
  %195 = fmul fast float %189, %192
  %196 = fadd fast float %193, %46
  %197 = fadd fast float %194, %47
  %198 = fadd fast float %195, %48
  br label %199

; <label>:199                                     ; preds = %182, %59, %53
  %200 = phi float [ %196, %182 ], [ %46, %59 ], [ %46, %53 ]
  %201 = phi float [ %197, %182 ], [ %47, %59 ], [ %47, %53 ]
  %202 = phi float [ %198, %182 ], [ %48, %59 ], [ %48, %53 ]
  %203 = fadd fast float %3, 1.000000e+00
  %204 = fadd fast float %4, 1.000000e+00
  %205 = fsub fast float 1.000000e+00, %3
  %206 = fmul fast float %34, %203
  %207 = fmul fast float %34, %204
  %208 = fmul fast float %34, %205
  %209 = fmul fast float %206, %200
  %210 = fmul fast float %207, %201
  %211 = fmul fast float %208, %202
  %212 = fcmp fast ult float %35, 5.000000e-01
  br i1 %212, label %238, label %213

; <label>:213                                     ; preds = %199
  %214 = fmul fast float %209, 0x4004147AE0000000
  %215 = fmul fast float %210, 0x4004147AE0000000
  %216 = fmul fast float %211, 0x4004147AE0000000
  %217 = fadd fast float %214, 0x3F9EB851E0000000
  %218 = fadd fast float %215, 0x3F9EB851E0000000
  %219 = fadd fast float %216, 0x3F9EB851E0000000
  %220 = fmul fast float %217, %209
  %221 = fmul fast float %218, %210
  %222 = fmul fast float %219, %211
  %223 = fmul fast float %209, 0x400370A3E0000000
  %224 = fmul fast float %210, 0x400370A3E0000000
  %225 = fmul fast float %211, 0x400370A3E0000000
  %226 = fadd fast float %223, 0x3FE2E147A0000000
  %227 = fadd fast float %224, 0x3FE2E147A0000000
  %228 = fadd fast float %225, 0x3FE2E147A0000000
  %229 = fmul fast float %226, %209
  %230 = fmul fast float %227, %210
  %231 = fmul fast float %228, %211
  %232 = fadd fast float %229, 0x3FC1EB8520000000
  %233 = fadd fast float %230, 0x3FC1EB8520000000
  %234 = fadd fast float %231, 0x3FC1EB8520000000
  %235 = fdiv fast float %220, %232
  %236 = fdiv fast float %221, %233
  %237 = fdiv fast float %222, %234
  br label %238

; <label>:238                                     ; preds = %213, %199
  %239 = phi float [ %235, %213 ], [ %209, %199 ]
  %240 = phi float [ %236, %213 ], [ %210, %199 ]
  %241 = phi float [ %237, %213 ], [ %211, %199 ]
  %242 = call float @dx.op.unary.f32(i32 7, float %239)  ; Saturate(value)
  %243 = call float @dx.op.unary.f32(i32 7, float %240)  ; Saturate(value)
  %244 = call float @dx.op.unary.f32(i32 7, float %241)  ; Saturate(value)
  %245 = call float @dx.op.dot3.f32(i32 55, float %242, float %243, float %244, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %246 = fsub fast float %242, %245
  %247 = fsub fast float %243, %245
  %248 = fsub fast float %244, %245
  %249 = fmul fast float %246, %6
  %250 = fmul fast float %247, %6
  %251 = fmul fast float %248, %6
  %252 = fadd fast float %249, %245
  %253 = fadd fast float %250, %245
  %254 = fadd fast float %251, %245
  %255 = call float @dx.op.unary.f32(i32 7, float %252)  ; Saturate(value)
  %256 = call float @dx.op.unary.f32(i32 7, float %253)  ; Saturate(value)
  %257 = call float @dx.op.unary.f32(i32 7, float %254)  ; Saturate(value)
  %258 = fadd fast float %255, 0xBFC70A3D80000000
  %259 = fadd fast float %256, 0xBFC70A3D80000000
  %260 = fadd fast float %257, 0xBFC70A3D80000000
  %261 = fmul fast float %258, %5
  %262 = fmul fast float %259, %5
  %263 = fmul fast float %260, %5
  %264 = fadd fast float %261, 0x3FC70A3D80000000
  %265 = fadd fast float %262, 0x3FC70A3D80000000
  %266 = fadd fast float %263, 0x3FC70A3D80000000
  %267 = call float @dx.op.unary.f32(i32 7, float %264)  ; Saturate(value)
  %268 = call float @dx.op.unary.f32(i32 7, float %265)  ; Saturate(value)
  %269 = call float @dx.op.unary.f32(i32 7, float %266)  ; Saturate(value)
  %270 = add i32 %44, -1
  %271 = add i32 %41, -1
  %272 = add i32 %42, -1
  %273 = call i32 @dx.op.binary.i32(i32 37, i32 %43, i32 0)  ; IMax(a,b)
  %274 = call i32 @dx.op.binary.i32(i32 37, i32 %270, i32 0)  ; IMax(a,b)
  %275 = call i32 @dx.op.binary.i32(i32 38, i32 %273, i32 %271)  ; IMin(a,b)
  %276 = call i32 @dx.op.binary.i32(i32 38, i32 %274, i32 %272)  ; IMin(a,b)
  %277 = call i32 @dx.op.binary.i32(i32 37, i32 %275, i32 0)  ; IMax(a,b)
  %278 = call i32 @dx.op.binary.i32(i32 37, i32 %276, i32 0)  ; IMax(a,b)
  %279 = call i32 @dx.op.binary.i32(i32 38, i32 %277, i32 %271)  ; IMin(a,b)
  %280 = call i32 @dx.op.binary.i32(i32 38, i32 %278, i32 %272)  ; IMin(a,b)
  %281 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %279, i32 %280, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %282 = extractvalue %dx.types.ResRet.f32 %281, 0
  %283 = extractvalue %dx.types.ResRet.f32 %281, 1
  %284 = extractvalue %dx.types.ResRet.f32 %281, 2
  %285 = extractvalue %dx.types.ResRet.f32 %281, 3
  %286 = fcmp fast olt float %285, 0.000000e+00
  br i1 %286, label %287, label %321

; <label>:287                                     ; preds = %238
  %288 = fcmp fast ogt float %282, 0x3FA4B5DCC0000000
  %289 = fcmp fast ogt float %283, 0x3FA4B5DCC0000000
  %290 = fcmp fast ogt float %284, 0x3FA4B5DCC0000000
  %291 = select i1 %288, float 0.000000e+00, float 1.000000e+00
  %292 = select i1 %289, float 0.000000e+00, float 1.000000e+00
  %293 = select i1 %290, float 0.000000e+00, float 1.000000e+00
  %294 = fmul fast float %282, 0x3FB3D07220000000
  %295 = fmul fast float %283, 0x3FB3D07220000000
  %296 = fmul fast float %284, 0x3FB3D07220000000
  %297 = fadd fast float %282, 0x3FAC28F5C0000000
  %298 = fadd fast float %283, 0x3FAC28F5C0000000
  %299 = fadd fast float %284, 0x3FAC28F5C0000000
  %300 = fmul fast float %297, 0x3FEE54EDE0000000
  %301 = fmul fast float %298, 0x3FEE54EDE0000000
  %302 = fmul fast float %299, 0x3FEE54EDE0000000
  %303 = call float @dx.op.unary.f32(i32 23, float %300)  ; Log(value)
  %304 = call float @dx.op.unary.f32(i32 23, float %301)  ; Log(value)
  %305 = call float @dx.op.unary.f32(i32 23, float %302)  ; Log(value)
  %306 = fmul fast float %303, 0x4003333340000000
  %307 = fmul fast float %304, 0x4003333340000000
  %308 = fmul fast float %305, 0x4003333340000000
  %309 = call float @dx.op.unary.f32(i32 21, float %306)  ; Exp(value)
  %310 = call float @dx.op.unary.f32(i32 21, float %307)  ; Exp(value)
  %311 = call float @dx.op.unary.f32(i32 21, float %308)  ; Exp(value)
  %312 = fsub fast float %294, %309
  %313 = fsub fast float %295, %310
  %314 = fsub fast float %296, %311
  %315 = fmul fast float %312, %291
  %316 = fmul fast float %313, %292
  %317 = fmul fast float %314, %293
  %318 = fadd fast float %315, %309
  %319 = fadd fast float %316, %310
  %320 = fadd fast float %317, %311
  br label %538

; <label>:321                                     ; preds = %238
  %322 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %279, i32 %280, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %323 = extractvalue %dx.types.ResRet.f32 %322, 0
  %324 = fcmp fast ogt float %36, 5.000000e-01
  %325 = fcmp fast olt float %323, 1.000000e+00
  %326 = and i1 %324, %325
  br i1 %326, label %327, label %467

; <label>:327                                     ; preds = %321
  %328 = sitofp i32 %279 to float
  %329 = sitofp i32 %280 to float
  %330 = fadd fast float %328, 5.000000e-01
  %331 = fadd fast float %329, 5.000000e-01
  %332 = uitofp i32 %41 to float
  %333 = uitofp i32 %42 to float
  %334 = fdiv fast float %330, %332
  %335 = fdiv fast float %331, %333
  %336 = fmul fast float %334, 2.000000e+00
  %337 = fmul fast float %335, 2.000000e+00
  %338 = fadd fast float %336, -1.000000e+00
  %339 = fsub fast float 1.000000e+00, %337
  %340 = fmul fast float %338, %33
  %341 = call float @dx.op.tertiary.f32(i32 46, float %339, float %29, float %340)  ; FMad(a,b,c)
  %342 = call float @dx.op.tertiary.f32(i32 46, float %323, float %25, float %341)  ; FMad(a,b,c)
  %343 = fadd fast float %342, %21
  %344 = call float @dx.op.unary.f32(i32 6, float %343)  ; FAbs(value)
  %345 = fcmp fast ogt float %344, 0x3EB0C6F7A0000000
  br i1 %345, label %346, label %467

; <label>:346                                     ; preds = %327
  %347 = fmul fast float %338, %32
  %348 = call float @dx.op.tertiary.f32(i32 46, float %339, float %28, float %347)  ; FMad(a,b,c)
  %349 = call float @dx.op.tertiary.f32(i32 46, float %323, float %24, float %348)  ; FMad(a,b,c)
  %350 = fadd fast float %349, %20
  %351 = fmul fast float %338, %31
  %352 = call float @dx.op.tertiary.f32(i32 46, float %339, float %27, float %351)  ; FMad(a,b,c)
  %353 = call float @dx.op.tertiary.f32(i32 46, float %323, float %23, float %352)  ; FMad(a,b,c)
  %354 = fadd fast float %353, %19
  %355 = fmul fast float %338, %30
  %356 = call float @dx.op.tertiary.f32(i32 46, float %339, float %26, float %355)  ; FMad(a,b,c)
  %357 = call float @dx.op.tertiary.f32(i32 46, float %323, float %22, float %356)  ; FMad(a,b,c)
  %358 = fadd fast float %357, %18
  %359 = fdiv fast float %358, %343
  %360 = fdiv fast float %354, %343
  %361 = fdiv fast float %350, %343
  %362 = fsub fast float %359, %15
  %363 = fsub fast float %360, %16
  %364 = fsub fast float %361, %17
  %365 = fmul fast float %362, %362
  %366 = fmul fast float %363, %363
  %367 = fadd fast float %366, %365
  %368 = fmul fast float %364, %364
  %369 = fadd fast float %367, %368
  %370 = call float @dx.op.unary.f32(i32 24, float %369)  ; Sqrt(value)
  %371 = fsub fast float %370, %7
  %372 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %371)  ; FMax(a,b)
  %373 = fcmp fast ogt float %37, 1.500000e+00
  br i1 %373, label %374, label %397

; <label>:374                                     ; preds = %346
  %375 = call float @dx.op.unary.f32(i32 6, float %363)  ; FAbs(value)
  %376 = fmul fast float %375, %9
  %377 = fcmp fast olt float %376, 0x3F50624DE0000000
  br i1 %377, label %378, label %381

; <label>:378                                     ; preds = %374
  %379 = fmul fast float %376, 5.000000e-01
  %380 = fsub fast float 1.000000e+00, %379
  br label %386

; <label>:381                                     ; preds = %374
  %382 = fmul fast float %376, 0xBFF7154760000000
  %383 = call float @dx.op.unary.f32(i32 21, float %382)  ; Exp(value)
  %384 = fsub fast float 1.000000e+00, %383
  %385 = fdiv fast float %384, %376
  br label %386

; <label>:386                                     ; preds = %381, %378
  %387 = phi float [ %380, %378 ], [ %385, %381 ]
  %388 = call float @dx.op.binary.f32(i32 36, float %360, float %16)  ; FMin(a,b)
  %389 = fsub fast float %388, %8
  %390 = fmul fast float %9, %389
  %391 = fsub fast float -0.000000e+00, %390
  %392 = call float @dx.op.binary.f32(i32 35, float %391, float -4.000000e+01)  ; FMax(a,b)
  %393 = call float @dx.op.binary.f32(i32 36, float %392, float 5.000000e+00)  ; FMin(a,b)
  %394 = fmul fast float %393, 0x3FF7154760000000
  %395 = call float @dx.op.unary.f32(i32 21, float %394)  ; Exp(value)
  %396 = fmul fast float %395, %387
  br label %397

; <label>:397                                     ; preds = %386, %346
  %398 = phi float [ %396, %386 ], [ 1.000000e+00, %346 ]
  %399 = fmul fast float %372, %14
  %400 = fmul fast float %399, %398
  %401 = fcmp fast ole float %370, %7
  %402 = fcmp fast olt float %370, 0x3F1A36E2E0000000
  %403 = or i1 %401, %402
  br i1 %403, label %450, label %404

; <label>:404                                     ; preds = %397
  %405 = fdiv fast float %7, %370
  %406 = fmul fast float %405, %362
  %407 = fmul fast float %405, %363
  %408 = fmul fast float %405, %364
  %409 = fadd fast float %406, %15
  %410 = fadd fast float %407, %16
  %411 = fadd fast float %408, %17
  %412 = fadd fast float %409, -9.000000e+02
  %413 = fadd fast float %410, -1.500000e+01
  %414 = fadd fast float %411, -7.500000e+02
  %415 = fmul fast float %412, 0x3F62345680000000
  %416 = fmul fast float %413, 0x3F62345680000000
  %417 = fmul fast float %414, 0x3F62345680000000
  %418 = call float @dx.op.dot3.f32(i32 55, float %415, float %416, float %417, float %415, float %416, float %417)  ; Dot3(ax,ay,az,bx,by,bz)
  %419 = fsub fast float 1.000000e+00, %418
  %420 = call float @dx.op.unary.f32(i32 7, float %419)  ; Saturate(value)
  %421 = fmul fast float %420, %420
  %422 = fadd fast float %409, %359
  %423 = fadd fast float %410, %360
  %424 = fadd fast float %411, %361
  %425 = fmul fast float %422, 0x3F52345680000000
  %426 = fadd fast float %425, -2.000000e+00
  %427 = fmul fast float %423, 0x3F52345680000000
  %428 = fadd fast float %427, 0xBFA1111120000000
  %429 = fmul fast float %424, 0x3F52345680000000
  %430 = fadd fast float %429, 0xBFFAAAAAC0000000
  %431 = call float @dx.op.dot3.f32(i32 55, float %426, float %428, float %430, float %426, float %428, float %430)  ; Dot3(ax,ay,az,bx,by,bz)
  %432 = fsub fast float 1.000000e+00, %431
  %433 = call float @dx.op.unary.f32(i32 7, float %432)  ; Saturate(value)
  %434 = fmul fast float %433, %433
  %435 = fmul fast float %434, 4.000000e+00
  %436 = fadd fast float %435, %421
  %437 = fadd fast float %359, -9.000000e+02
  %438 = fadd fast float %360, -1.500000e+01
  %439 = fadd fast float %361, -7.500000e+02
  %440 = fmul fast float %437, 0x3F62345680000000
  %441 = fmul fast float %438, 0x3F62345680000000
  %442 = fmul fast float %439, 0x3F62345680000000
  %443 = call float @dx.op.dot3.f32(i32 55, float %440, float %441, float %442, float %440, float %441, float %442)  ; Dot3(ax,ay,az,bx,by,bz)
  %444 = fsub fast float 1.000000e+00, %443
  %445 = call float @dx.op.unary.f32(i32 7, float %444)  ; Saturate(value)
  %446 = fmul fast float %445, %445
  %447 = fadd fast float %436, %446
  %448 = fmul fast float %371, 0x3F25D867E0000000
  %449 = fmul fast float %448, %447
  br label %450

; <label>:450                                     ; preds = %404, %397
  %451 = phi float [ %449, %404 ], [ 0.000000e+00, %397 ]
  %452 = fadd fast float %451, %400
  %453 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %452)  ; FMin(a,b)
  %454 = fmul fast float %453, 0xBFF7154760000000
  %455 = call float @dx.op.unary.f32(i32 21, float %454)  ; Exp(value)
  %456 = fsub fast float 1.000000e+00, %455
  %457 = call float @dx.op.binary.f32(i32 36, float %10, float %456)  ; FMin(a,b)
  %458 = fsub fast float %11, %282
  %459 = fsub fast float %12, %283
  %460 = fsub fast float %13, %284
  %461 = fmul fast float %457, %458
  %462 = fmul fast float %457, %459
  %463 = fmul fast float %457, %460
  %464 = fadd fast float %461, %282
  %465 = fadd fast float %462, %283
  %466 = fadd fast float %463, %284
  br label %467

; <label>:467                                     ; preds = %450, %327, %321
  %468 = phi float [ %464, %450 ], [ %282, %327 ], [ %282, %321 ]
  %469 = phi float [ %465, %450 ], [ %283, %327 ], [ %283, %321 ]
  %470 = phi float [ %466, %450 ], [ %284, %327 ], [ %284, %321 ]
  %471 = fadd fast float %3, 1.000000e+00
  %472 = fadd fast float %4, 1.000000e+00
  %473 = fsub fast float 1.000000e+00, %3
  %474 = fmul fast float %34, %471
  %475 = fmul fast float %34, %472
  %476 = fmul fast float %34, %473
  %477 = fmul fast float %474, %468
  %478 = fmul fast float %475, %469
  %479 = fmul fast float %476, %470
  %480 = fcmp fast ult float %35, 5.000000e-01
  br i1 %480, label %506, label %481

; <label>:481                                     ; preds = %467
  %482 = fmul fast float %477, 0x4004147AE0000000
  %483 = fmul fast float %478, 0x4004147AE0000000
  %484 = fmul fast float %479, 0x4004147AE0000000
  %485 = fadd fast float %482, 0x3F9EB851E0000000
  %486 = fadd fast float %483, 0x3F9EB851E0000000
  %487 = fadd fast float %484, 0x3F9EB851E0000000
  %488 = fmul fast float %485, %477
  %489 = fmul fast float %486, %478
  %490 = fmul fast float %487, %479
  %491 = fmul fast float %477, 0x400370A3E0000000
  %492 = fmul fast float %478, 0x400370A3E0000000
  %493 = fmul fast float %479, 0x400370A3E0000000
  %494 = fadd fast float %491, 0x3FE2E147A0000000
  %495 = fadd fast float %492, 0x3FE2E147A0000000
  %496 = fadd fast float %493, 0x3FE2E147A0000000
  %497 = fmul fast float %494, %477
  %498 = fmul fast float %495, %478
  %499 = fmul fast float %496, %479
  %500 = fadd fast float %497, 0x3FC1EB8520000000
  %501 = fadd fast float %498, 0x3FC1EB8520000000
  %502 = fadd fast float %499, 0x3FC1EB8520000000
  %503 = fdiv fast float %488, %500
  %504 = fdiv fast float %489, %501
  %505 = fdiv fast float %490, %502
  br label %506

; <label>:506                                     ; preds = %481, %467
  %507 = phi float [ %503, %481 ], [ %477, %467 ]
  %508 = phi float [ %504, %481 ], [ %478, %467 ]
  %509 = phi float [ %505, %481 ], [ %479, %467 ]
  %510 = call float @dx.op.unary.f32(i32 7, float %507)  ; Saturate(value)
  %511 = call float @dx.op.unary.f32(i32 7, float %508)  ; Saturate(value)
  %512 = call float @dx.op.unary.f32(i32 7, float %509)  ; Saturate(value)
  %513 = call float @dx.op.dot3.f32(i32 55, float %510, float %511, float %512, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %514 = fsub fast float %510, %513
  %515 = fsub fast float %511, %513
  %516 = fsub fast float %512, %513
  %517 = fmul fast float %514, %6
  %518 = fmul fast float %515, %6
  %519 = fmul fast float %516, %6
  %520 = fadd fast float %517, %513
  %521 = fadd fast float %518, %513
  %522 = fadd fast float %519, %513
  %523 = call float @dx.op.unary.f32(i32 7, float %520)  ; Saturate(value)
  %524 = call float @dx.op.unary.f32(i32 7, float %521)  ; Saturate(value)
  %525 = call float @dx.op.unary.f32(i32 7, float %522)  ; Saturate(value)
  %526 = fadd fast float %523, 0xBFC70A3D80000000
  %527 = fadd fast float %524, 0xBFC70A3D80000000
  %528 = fadd fast float %525, 0xBFC70A3D80000000
  %529 = fmul fast float %526, %5
  %530 = fmul fast float %527, %5
  %531 = fmul fast float %528, %5
  %532 = fadd fast float %529, 0x3FC70A3D80000000
  %533 = fadd fast float %530, 0x3FC70A3D80000000
  %534 = fadd fast float %531, 0x3FC70A3D80000000
  %535 = call float @dx.op.unary.f32(i32 7, float %532)  ; Saturate(value)
  %536 = call float @dx.op.unary.f32(i32 7, float %533)  ; Saturate(value)
  %537 = call float @dx.op.unary.f32(i32 7, float %534)  ; Saturate(value)
  br label %538

; <label>:538                                     ; preds = %506, %287
  %539 = phi float [ %318, %287 ], [ %535, %506 ]
  %540 = phi float [ %319, %287 ], [ %536, %506 ]
  %541 = phi float [ %320, %287 ], [ %537, %506 ]
  %542 = add i32 %44, 1
  %543 = call i32 @dx.op.binary.i32(i32 37, i32 %542, i32 0)  ; IMax(a,b)
  %544 = call i32 @dx.op.binary.i32(i32 38, i32 %543, i32 %272)  ; IMin(a,b)
  %545 = call i32 @dx.op.binary.i32(i32 37, i32 %544, i32 0)  ; IMax(a,b)
  %546 = call i32 @dx.op.binary.i32(i32 38, i32 %545, i32 %272)  ; IMin(a,b)
  %547 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %279, i32 %546, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %548 = extractvalue %dx.types.ResRet.f32 %547, 0
  %549 = extractvalue %dx.types.ResRet.f32 %547, 1
  %550 = extractvalue %dx.types.ResRet.f32 %547, 2
  %551 = extractvalue %dx.types.ResRet.f32 %547, 3
  %552 = fcmp fast olt float %551, 0.000000e+00
  br i1 %552, label %553, label %587

; <label>:553                                     ; preds = %538
  %554 = fcmp fast ogt float %548, 0x3FA4B5DCC0000000
  %555 = fcmp fast ogt float %549, 0x3FA4B5DCC0000000
  %556 = fcmp fast ogt float %550, 0x3FA4B5DCC0000000
  %557 = select i1 %554, float 0.000000e+00, float 1.000000e+00
  %558 = select i1 %555, float 0.000000e+00, float 1.000000e+00
  %559 = select i1 %556, float 0.000000e+00, float 1.000000e+00
  %560 = fmul fast float %548, 0x3FB3D07220000000
  %561 = fmul fast float %549, 0x3FB3D07220000000
  %562 = fmul fast float %550, 0x3FB3D07220000000
  %563 = fadd fast float %548, 0x3FAC28F5C0000000
  %564 = fadd fast float %549, 0x3FAC28F5C0000000
  %565 = fadd fast float %550, 0x3FAC28F5C0000000
  %566 = fmul fast float %563, 0x3FEE54EDE0000000
  %567 = fmul fast float %564, 0x3FEE54EDE0000000
  %568 = fmul fast float %565, 0x3FEE54EDE0000000
  %569 = call float @dx.op.unary.f32(i32 23, float %566)  ; Log(value)
  %570 = call float @dx.op.unary.f32(i32 23, float %567)  ; Log(value)
  %571 = call float @dx.op.unary.f32(i32 23, float %568)  ; Log(value)
  %572 = fmul fast float %569, 0x4003333340000000
  %573 = fmul fast float %570, 0x4003333340000000
  %574 = fmul fast float %571, 0x4003333340000000
  %575 = call float @dx.op.unary.f32(i32 21, float %572)  ; Exp(value)
  %576 = call float @dx.op.unary.f32(i32 21, float %573)  ; Exp(value)
  %577 = call float @dx.op.unary.f32(i32 21, float %574)  ; Exp(value)
  %578 = fsub fast float %560, %575
  %579 = fsub fast float %561, %576
  %580 = fsub fast float %562, %577
  %581 = fmul fast float %578, %557
  %582 = fmul fast float %579, %558
  %583 = fmul fast float %580, %559
  %584 = fadd fast float %581, %575
  %585 = fadd fast float %582, %576
  %586 = fadd fast float %583, %577
  br label %804

; <label>:587                                     ; preds = %538
  %588 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %279, i32 %546, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %589 = extractvalue %dx.types.ResRet.f32 %588, 0
  %590 = fcmp fast ogt float %36, 5.000000e-01
  %591 = fcmp fast olt float %589, 1.000000e+00
  %592 = and i1 %590, %591
  br i1 %592, label %593, label %733

; <label>:593                                     ; preds = %587
  %594 = sitofp i32 %279 to float
  %595 = sitofp i32 %546 to float
  %596 = fadd fast float %594, 5.000000e-01
  %597 = fadd fast float %595, 5.000000e-01
  %598 = uitofp i32 %41 to float
  %599 = uitofp i32 %42 to float
  %600 = fdiv fast float %596, %598
  %601 = fdiv fast float %597, %599
  %602 = fmul fast float %600, 2.000000e+00
  %603 = fmul fast float %601, 2.000000e+00
  %604 = fadd fast float %602, -1.000000e+00
  %605 = fsub fast float 1.000000e+00, %603
  %606 = fmul fast float %604, %33
  %607 = call float @dx.op.tertiary.f32(i32 46, float %605, float %29, float %606)  ; FMad(a,b,c)
  %608 = call float @dx.op.tertiary.f32(i32 46, float %589, float %25, float %607)  ; FMad(a,b,c)
  %609 = fadd fast float %608, %21
  %610 = call float @dx.op.unary.f32(i32 6, float %609)  ; FAbs(value)
  %611 = fcmp fast ogt float %610, 0x3EB0C6F7A0000000
  br i1 %611, label %612, label %733

; <label>:612                                     ; preds = %593
  %613 = fmul fast float %604, %32
  %614 = call float @dx.op.tertiary.f32(i32 46, float %605, float %28, float %613)  ; FMad(a,b,c)
  %615 = call float @dx.op.tertiary.f32(i32 46, float %589, float %24, float %614)  ; FMad(a,b,c)
  %616 = fadd fast float %615, %20
  %617 = fmul fast float %604, %31
  %618 = call float @dx.op.tertiary.f32(i32 46, float %605, float %27, float %617)  ; FMad(a,b,c)
  %619 = call float @dx.op.tertiary.f32(i32 46, float %589, float %23, float %618)  ; FMad(a,b,c)
  %620 = fadd fast float %619, %19
  %621 = fmul fast float %604, %30
  %622 = call float @dx.op.tertiary.f32(i32 46, float %605, float %26, float %621)  ; FMad(a,b,c)
  %623 = call float @dx.op.tertiary.f32(i32 46, float %589, float %22, float %622)  ; FMad(a,b,c)
  %624 = fadd fast float %623, %18
  %625 = fdiv fast float %624, %609
  %626 = fdiv fast float %620, %609
  %627 = fdiv fast float %616, %609
  %628 = fsub fast float %625, %15
  %629 = fsub fast float %626, %16
  %630 = fsub fast float %627, %17
  %631 = fmul fast float %628, %628
  %632 = fmul fast float %629, %629
  %633 = fadd fast float %632, %631
  %634 = fmul fast float %630, %630
  %635 = fadd fast float %633, %634
  %636 = call float @dx.op.unary.f32(i32 24, float %635)  ; Sqrt(value)
  %637 = fsub fast float %636, %7
  %638 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %637)  ; FMax(a,b)
  %639 = fcmp fast ogt float %37, 1.500000e+00
  br i1 %639, label %640, label %663

; <label>:640                                     ; preds = %612
  %641 = call float @dx.op.unary.f32(i32 6, float %629)  ; FAbs(value)
  %642 = fmul fast float %641, %9
  %643 = fcmp fast olt float %642, 0x3F50624DE0000000
  br i1 %643, label %644, label %647

; <label>:644                                     ; preds = %640
  %645 = fmul fast float %642, 5.000000e-01
  %646 = fsub fast float 1.000000e+00, %645
  br label %652

; <label>:647                                     ; preds = %640
  %648 = fmul fast float %642, 0xBFF7154760000000
  %649 = call float @dx.op.unary.f32(i32 21, float %648)  ; Exp(value)
  %650 = fsub fast float 1.000000e+00, %649
  %651 = fdiv fast float %650, %642
  br label %652

; <label>:652                                     ; preds = %647, %644
  %653 = phi float [ %646, %644 ], [ %651, %647 ]
  %654 = call float @dx.op.binary.f32(i32 36, float %626, float %16)  ; FMin(a,b)
  %655 = fsub fast float %654, %8
  %656 = fmul fast float %9, %655
  %657 = fsub fast float -0.000000e+00, %656
  %658 = call float @dx.op.binary.f32(i32 35, float %657, float -4.000000e+01)  ; FMax(a,b)
  %659 = call float @dx.op.binary.f32(i32 36, float %658, float 5.000000e+00)  ; FMin(a,b)
  %660 = fmul fast float %659, 0x3FF7154760000000
  %661 = call float @dx.op.unary.f32(i32 21, float %660)  ; Exp(value)
  %662 = fmul fast float %661, %653
  br label %663

; <label>:663                                     ; preds = %652, %612
  %664 = phi float [ %662, %652 ], [ 1.000000e+00, %612 ]
  %665 = fmul fast float %638, %14
  %666 = fmul fast float %665, %664
  %667 = fcmp fast ole float %636, %7
  %668 = fcmp fast olt float %636, 0x3F1A36E2E0000000
  %669 = or i1 %667, %668
  br i1 %669, label %716, label %670

; <label>:670                                     ; preds = %663
  %671 = fdiv fast float %7, %636
  %672 = fmul fast float %671, %628
  %673 = fmul fast float %671, %629
  %674 = fmul fast float %671, %630
  %675 = fadd fast float %672, %15
  %676 = fadd fast float %673, %16
  %677 = fadd fast float %674, %17
  %678 = fadd fast float %675, -9.000000e+02
  %679 = fadd fast float %676, -1.500000e+01
  %680 = fadd fast float %677, -7.500000e+02
  %681 = fmul fast float %678, 0x3F62345680000000
  %682 = fmul fast float %679, 0x3F62345680000000
  %683 = fmul fast float %680, 0x3F62345680000000
  %684 = call float @dx.op.dot3.f32(i32 55, float %681, float %682, float %683, float %681, float %682, float %683)  ; Dot3(ax,ay,az,bx,by,bz)
  %685 = fsub fast float 1.000000e+00, %684
  %686 = call float @dx.op.unary.f32(i32 7, float %685)  ; Saturate(value)
  %687 = fmul fast float %686, %686
  %688 = fadd fast float %675, %625
  %689 = fadd fast float %676, %626
  %690 = fadd fast float %677, %627
  %691 = fmul fast float %688, 0x3F52345680000000
  %692 = fadd fast float %691, -2.000000e+00
  %693 = fmul fast float %689, 0x3F52345680000000
  %694 = fadd fast float %693, 0xBFA1111120000000
  %695 = fmul fast float %690, 0x3F52345680000000
  %696 = fadd fast float %695, 0xBFFAAAAAC0000000
  %697 = call float @dx.op.dot3.f32(i32 55, float %692, float %694, float %696, float %692, float %694, float %696)  ; Dot3(ax,ay,az,bx,by,bz)
  %698 = fsub fast float 1.000000e+00, %697
  %699 = call float @dx.op.unary.f32(i32 7, float %698)  ; Saturate(value)
  %700 = fmul fast float %699, %699
  %701 = fmul fast float %700, 4.000000e+00
  %702 = fadd fast float %701, %687
  %703 = fadd fast float %625, -9.000000e+02
  %704 = fadd fast float %626, -1.500000e+01
  %705 = fadd fast float %627, -7.500000e+02
  %706 = fmul fast float %703, 0x3F62345680000000
  %707 = fmul fast float %704, 0x3F62345680000000
  %708 = fmul fast float %705, 0x3F62345680000000
  %709 = call float @dx.op.dot3.f32(i32 55, float %706, float %707, float %708, float %706, float %707, float %708)  ; Dot3(ax,ay,az,bx,by,bz)
  %710 = fsub fast float 1.000000e+00, %709
  %711 = call float @dx.op.unary.f32(i32 7, float %710)  ; Saturate(value)
  %712 = fmul fast float %711, %711
  %713 = fadd fast float %702, %712
  %714 = fmul fast float %637, 0x3F25D867E0000000
  %715 = fmul fast float %714, %713
  br label %716

; <label>:716                                     ; preds = %670, %663
  %717 = phi float [ %715, %670 ], [ 0.000000e+00, %663 ]
  %718 = fadd fast float %717, %666
  %719 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %718)  ; FMin(a,b)
  %720 = fmul fast float %719, 0xBFF7154760000000
  %721 = call float @dx.op.unary.f32(i32 21, float %720)  ; Exp(value)
  %722 = fsub fast float 1.000000e+00, %721
  %723 = call float @dx.op.binary.f32(i32 36, float %10, float %722)  ; FMin(a,b)
  %724 = fsub fast float %11, %548
  %725 = fsub fast float %12, %549
  %726 = fsub fast float %13, %550
  %727 = fmul fast float %723, %724
  %728 = fmul fast float %723, %725
  %729 = fmul fast float %723, %726
  %730 = fadd fast float %727, %548
  %731 = fadd fast float %728, %549
  %732 = fadd fast float %729, %550
  br label %733

; <label>:733                                     ; preds = %716, %593, %587
  %734 = phi float [ %730, %716 ], [ %548, %593 ], [ %548, %587 ]
  %735 = phi float [ %731, %716 ], [ %549, %593 ], [ %549, %587 ]
  %736 = phi float [ %732, %716 ], [ %550, %593 ], [ %550, %587 ]
  %737 = fadd fast float %3, 1.000000e+00
  %738 = fadd fast float %4, 1.000000e+00
  %739 = fsub fast float 1.000000e+00, %3
  %740 = fmul fast float %34, %737
  %741 = fmul fast float %34, %738
  %742 = fmul fast float %34, %739
  %743 = fmul fast float %740, %734
  %744 = fmul fast float %741, %735
  %745 = fmul fast float %742, %736
  %746 = fcmp fast ult float %35, 5.000000e-01
  br i1 %746, label %772, label %747

; <label>:747                                     ; preds = %733
  %748 = fmul fast float %743, 0x4004147AE0000000
  %749 = fmul fast float %744, 0x4004147AE0000000
  %750 = fmul fast float %745, 0x4004147AE0000000
  %751 = fadd fast float %748, 0x3F9EB851E0000000
  %752 = fadd fast float %749, 0x3F9EB851E0000000
  %753 = fadd fast float %750, 0x3F9EB851E0000000
  %754 = fmul fast float %751, %743
  %755 = fmul fast float %752, %744
  %756 = fmul fast float %753, %745
  %757 = fmul fast float %743, 0x400370A3E0000000
  %758 = fmul fast float %744, 0x400370A3E0000000
  %759 = fmul fast float %745, 0x400370A3E0000000
  %760 = fadd fast float %757, 0x3FE2E147A0000000
  %761 = fadd fast float %758, 0x3FE2E147A0000000
  %762 = fadd fast float %759, 0x3FE2E147A0000000
  %763 = fmul fast float %760, %743
  %764 = fmul fast float %761, %744
  %765 = fmul fast float %762, %745
  %766 = fadd fast float %763, 0x3FC1EB8520000000
  %767 = fadd fast float %764, 0x3FC1EB8520000000
  %768 = fadd fast float %765, 0x3FC1EB8520000000
  %769 = fdiv fast float %754, %766
  %770 = fdiv fast float %755, %767
  %771 = fdiv fast float %756, %768
  br label %772

; <label>:772                                     ; preds = %747, %733
  %773 = phi float [ %769, %747 ], [ %743, %733 ]
  %774 = phi float [ %770, %747 ], [ %744, %733 ]
  %775 = phi float [ %771, %747 ], [ %745, %733 ]
  %776 = call float @dx.op.unary.f32(i32 7, float %773)  ; Saturate(value)
  %777 = call float @dx.op.unary.f32(i32 7, float %774)  ; Saturate(value)
  %778 = call float @dx.op.unary.f32(i32 7, float %775)  ; Saturate(value)
  %779 = call float @dx.op.dot3.f32(i32 55, float %776, float %777, float %778, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %780 = fsub fast float %776, %779
  %781 = fsub fast float %777, %779
  %782 = fsub fast float %778, %779
  %783 = fmul fast float %780, %6
  %784 = fmul fast float %781, %6
  %785 = fmul fast float %782, %6
  %786 = fadd fast float %783, %779
  %787 = fadd fast float %784, %779
  %788 = fadd fast float %785, %779
  %789 = call float @dx.op.unary.f32(i32 7, float %786)  ; Saturate(value)
  %790 = call float @dx.op.unary.f32(i32 7, float %787)  ; Saturate(value)
  %791 = call float @dx.op.unary.f32(i32 7, float %788)  ; Saturate(value)
  %792 = fadd fast float %789, 0xBFC70A3D80000000
  %793 = fadd fast float %790, 0xBFC70A3D80000000
  %794 = fadd fast float %791, 0xBFC70A3D80000000
  %795 = fmul fast float %792, %5
  %796 = fmul fast float %793, %5
  %797 = fmul fast float %794, %5
  %798 = fadd fast float %795, 0x3FC70A3D80000000
  %799 = fadd fast float %796, 0x3FC70A3D80000000
  %800 = fadd fast float %797, 0x3FC70A3D80000000
  %801 = call float @dx.op.unary.f32(i32 7, float %798)  ; Saturate(value)
  %802 = call float @dx.op.unary.f32(i32 7, float %799)  ; Saturate(value)
  %803 = call float @dx.op.unary.f32(i32 7, float %800)  ; Saturate(value)
  br label %804

; <label>:804                                     ; preds = %772, %553
  %805 = phi float [ %584, %553 ], [ %801, %772 ]
  %806 = phi float [ %585, %553 ], [ %802, %772 ]
  %807 = phi float [ %586, %553 ], [ %803, %772 ]
  %808 = add i32 %43, -1
  %809 = call i32 @dx.op.binary.i32(i32 37, i32 %808, i32 0)  ; IMax(a,b)
  %810 = call i32 @dx.op.binary.i32(i32 37, i32 %44, i32 0)  ; IMax(a,b)
  %811 = call i32 @dx.op.binary.i32(i32 38, i32 %809, i32 %271)  ; IMin(a,b)
  %812 = call i32 @dx.op.binary.i32(i32 38, i32 %810, i32 %272)  ; IMin(a,b)
  %813 = call i32 @dx.op.binary.i32(i32 37, i32 %811, i32 0)  ; IMax(a,b)
  %814 = call i32 @dx.op.binary.i32(i32 37, i32 %812, i32 0)  ; IMax(a,b)
  %815 = call i32 @dx.op.binary.i32(i32 38, i32 %813, i32 %271)  ; IMin(a,b)
  %816 = call i32 @dx.op.binary.i32(i32 38, i32 %814, i32 %272)  ; IMin(a,b)
  %817 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %815, i32 %816, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %818 = extractvalue %dx.types.ResRet.f32 %817, 0
  %819 = extractvalue %dx.types.ResRet.f32 %817, 1
  %820 = extractvalue %dx.types.ResRet.f32 %817, 2
  %821 = extractvalue %dx.types.ResRet.f32 %817, 3
  %822 = fcmp fast olt float %821, 0.000000e+00
  br i1 %822, label %823, label %857

; <label>:823                                     ; preds = %804
  %824 = fcmp fast ogt float %818, 0x3FA4B5DCC0000000
  %825 = fcmp fast ogt float %819, 0x3FA4B5DCC0000000
  %826 = fcmp fast ogt float %820, 0x3FA4B5DCC0000000
  %827 = select i1 %824, float 0.000000e+00, float 1.000000e+00
  %828 = select i1 %825, float 0.000000e+00, float 1.000000e+00
  %829 = select i1 %826, float 0.000000e+00, float 1.000000e+00
  %830 = fmul fast float %818, 0x3FB3D07220000000
  %831 = fmul fast float %819, 0x3FB3D07220000000
  %832 = fmul fast float %820, 0x3FB3D07220000000
  %833 = fadd fast float %818, 0x3FAC28F5C0000000
  %834 = fadd fast float %819, 0x3FAC28F5C0000000
  %835 = fadd fast float %820, 0x3FAC28F5C0000000
  %836 = fmul fast float %833, 0x3FEE54EDE0000000
  %837 = fmul fast float %834, 0x3FEE54EDE0000000
  %838 = fmul fast float %835, 0x3FEE54EDE0000000
  %839 = call float @dx.op.unary.f32(i32 23, float %836)  ; Log(value)
  %840 = call float @dx.op.unary.f32(i32 23, float %837)  ; Log(value)
  %841 = call float @dx.op.unary.f32(i32 23, float %838)  ; Log(value)
  %842 = fmul fast float %839, 0x4003333340000000
  %843 = fmul fast float %840, 0x4003333340000000
  %844 = fmul fast float %841, 0x4003333340000000
  %845 = call float @dx.op.unary.f32(i32 21, float %842)  ; Exp(value)
  %846 = call float @dx.op.unary.f32(i32 21, float %843)  ; Exp(value)
  %847 = call float @dx.op.unary.f32(i32 21, float %844)  ; Exp(value)
  %848 = fsub fast float %830, %845
  %849 = fsub fast float %831, %846
  %850 = fsub fast float %832, %847
  %851 = fmul fast float %848, %827
  %852 = fmul fast float %849, %828
  %853 = fmul fast float %850, %829
  %854 = fadd fast float %851, %845
  %855 = fadd fast float %852, %846
  %856 = fadd fast float %853, %847
  br label %1074

; <label>:857                                     ; preds = %804
  %858 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %815, i32 %816, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %859 = extractvalue %dx.types.ResRet.f32 %858, 0
  %860 = fcmp fast ogt float %36, 5.000000e-01
  %861 = fcmp fast olt float %859, 1.000000e+00
  %862 = and i1 %860, %861
  br i1 %862, label %863, label %1003

; <label>:863                                     ; preds = %857
  %864 = sitofp i32 %815 to float
  %865 = sitofp i32 %816 to float
  %866 = fadd fast float %864, 5.000000e-01
  %867 = fadd fast float %865, 5.000000e-01
  %868 = uitofp i32 %41 to float
  %869 = uitofp i32 %42 to float
  %870 = fdiv fast float %866, %868
  %871 = fdiv fast float %867, %869
  %872 = fmul fast float %870, 2.000000e+00
  %873 = fmul fast float %871, 2.000000e+00
  %874 = fadd fast float %872, -1.000000e+00
  %875 = fsub fast float 1.000000e+00, %873
  %876 = fmul fast float %874, %33
  %877 = call float @dx.op.tertiary.f32(i32 46, float %875, float %29, float %876)  ; FMad(a,b,c)
  %878 = call float @dx.op.tertiary.f32(i32 46, float %859, float %25, float %877)  ; FMad(a,b,c)
  %879 = fadd fast float %878, %21
  %880 = call float @dx.op.unary.f32(i32 6, float %879)  ; FAbs(value)
  %881 = fcmp fast ogt float %880, 0x3EB0C6F7A0000000
  br i1 %881, label %882, label %1003

; <label>:882                                     ; preds = %863
  %883 = fmul fast float %874, %32
  %884 = call float @dx.op.tertiary.f32(i32 46, float %875, float %28, float %883)  ; FMad(a,b,c)
  %885 = call float @dx.op.tertiary.f32(i32 46, float %859, float %24, float %884)  ; FMad(a,b,c)
  %886 = fadd fast float %885, %20
  %887 = fmul fast float %874, %31
  %888 = call float @dx.op.tertiary.f32(i32 46, float %875, float %27, float %887)  ; FMad(a,b,c)
  %889 = call float @dx.op.tertiary.f32(i32 46, float %859, float %23, float %888)  ; FMad(a,b,c)
  %890 = fadd fast float %889, %19
  %891 = fmul fast float %874, %30
  %892 = call float @dx.op.tertiary.f32(i32 46, float %875, float %26, float %891)  ; FMad(a,b,c)
  %893 = call float @dx.op.tertiary.f32(i32 46, float %859, float %22, float %892)  ; FMad(a,b,c)
  %894 = fadd fast float %893, %18
  %895 = fdiv fast float %894, %879
  %896 = fdiv fast float %890, %879
  %897 = fdiv fast float %886, %879
  %898 = fsub fast float %895, %15
  %899 = fsub fast float %896, %16
  %900 = fsub fast float %897, %17
  %901 = fmul fast float %898, %898
  %902 = fmul fast float %899, %899
  %903 = fadd fast float %902, %901
  %904 = fmul fast float %900, %900
  %905 = fadd fast float %903, %904
  %906 = call float @dx.op.unary.f32(i32 24, float %905)  ; Sqrt(value)
  %907 = fsub fast float %906, %7
  %908 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %907)  ; FMax(a,b)
  %909 = fcmp fast ogt float %37, 1.500000e+00
  br i1 %909, label %910, label %933

; <label>:910                                     ; preds = %882
  %911 = call float @dx.op.unary.f32(i32 6, float %899)  ; FAbs(value)
  %912 = fmul fast float %911, %9
  %913 = fcmp fast olt float %912, 0x3F50624DE0000000
  br i1 %913, label %914, label %917

; <label>:914                                     ; preds = %910
  %915 = fmul fast float %912, 5.000000e-01
  %916 = fsub fast float 1.000000e+00, %915
  br label %922

; <label>:917                                     ; preds = %910
  %918 = fmul fast float %912, 0xBFF7154760000000
  %919 = call float @dx.op.unary.f32(i32 21, float %918)  ; Exp(value)
  %920 = fsub fast float 1.000000e+00, %919
  %921 = fdiv fast float %920, %912
  br label %922

; <label>:922                                     ; preds = %917, %914
  %923 = phi float [ %916, %914 ], [ %921, %917 ]
  %924 = call float @dx.op.binary.f32(i32 36, float %896, float %16)  ; FMin(a,b)
  %925 = fsub fast float %924, %8
  %926 = fmul fast float %9, %925
  %927 = fsub fast float -0.000000e+00, %926
  %928 = call float @dx.op.binary.f32(i32 35, float %927, float -4.000000e+01)  ; FMax(a,b)
  %929 = call float @dx.op.binary.f32(i32 36, float %928, float 5.000000e+00)  ; FMin(a,b)
  %930 = fmul fast float %929, 0x3FF7154760000000
  %931 = call float @dx.op.unary.f32(i32 21, float %930)  ; Exp(value)
  %932 = fmul fast float %931, %923
  br label %933

; <label>:933                                     ; preds = %922, %882
  %934 = phi float [ %932, %922 ], [ 1.000000e+00, %882 ]
  %935 = fmul fast float %908, %14
  %936 = fmul fast float %935, %934
  %937 = fcmp fast ole float %906, %7
  %938 = fcmp fast olt float %906, 0x3F1A36E2E0000000
  %939 = or i1 %937, %938
  br i1 %939, label %986, label %940

; <label>:940                                     ; preds = %933
  %941 = fdiv fast float %7, %906
  %942 = fmul fast float %941, %898
  %943 = fmul fast float %941, %899
  %944 = fmul fast float %941, %900
  %945 = fadd fast float %942, %15
  %946 = fadd fast float %943, %16
  %947 = fadd fast float %944, %17
  %948 = fadd fast float %945, -9.000000e+02
  %949 = fadd fast float %946, -1.500000e+01
  %950 = fadd fast float %947, -7.500000e+02
  %951 = fmul fast float %948, 0x3F62345680000000
  %952 = fmul fast float %949, 0x3F62345680000000
  %953 = fmul fast float %950, 0x3F62345680000000
  %954 = call float @dx.op.dot3.f32(i32 55, float %951, float %952, float %953, float %951, float %952, float %953)  ; Dot3(ax,ay,az,bx,by,bz)
  %955 = fsub fast float 1.000000e+00, %954
  %956 = call float @dx.op.unary.f32(i32 7, float %955)  ; Saturate(value)
  %957 = fmul fast float %956, %956
  %958 = fadd fast float %945, %895
  %959 = fadd fast float %946, %896
  %960 = fadd fast float %947, %897
  %961 = fmul fast float %958, 0x3F52345680000000
  %962 = fadd fast float %961, -2.000000e+00
  %963 = fmul fast float %959, 0x3F52345680000000
  %964 = fadd fast float %963, 0xBFA1111120000000
  %965 = fmul fast float %960, 0x3F52345680000000
  %966 = fadd fast float %965, 0xBFFAAAAAC0000000
  %967 = call float @dx.op.dot3.f32(i32 55, float %962, float %964, float %966, float %962, float %964, float %966)  ; Dot3(ax,ay,az,bx,by,bz)
  %968 = fsub fast float 1.000000e+00, %967
  %969 = call float @dx.op.unary.f32(i32 7, float %968)  ; Saturate(value)
  %970 = fmul fast float %969, %969
  %971 = fmul fast float %970, 4.000000e+00
  %972 = fadd fast float %971, %957
  %973 = fadd fast float %895, -9.000000e+02
  %974 = fadd fast float %896, -1.500000e+01
  %975 = fadd fast float %897, -7.500000e+02
  %976 = fmul fast float %973, 0x3F62345680000000
  %977 = fmul fast float %974, 0x3F62345680000000
  %978 = fmul fast float %975, 0x3F62345680000000
  %979 = call float @dx.op.dot3.f32(i32 55, float %976, float %977, float %978, float %976, float %977, float %978)  ; Dot3(ax,ay,az,bx,by,bz)
  %980 = fsub fast float 1.000000e+00, %979
  %981 = call float @dx.op.unary.f32(i32 7, float %980)  ; Saturate(value)
  %982 = fmul fast float %981, %981
  %983 = fadd fast float %972, %982
  %984 = fmul fast float %907, 0x3F25D867E0000000
  %985 = fmul fast float %984, %983
  br label %986

; <label>:986                                     ; preds = %940, %933
  %987 = phi float [ %985, %940 ], [ 0.000000e+00, %933 ]
  %988 = fadd fast float %987, %936
  %989 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %988)  ; FMin(a,b)
  %990 = fmul fast float %989, 0xBFF7154760000000
  %991 = call float @dx.op.unary.f32(i32 21, float %990)  ; Exp(value)
  %992 = fsub fast float 1.000000e+00, %991
  %993 = call float @dx.op.binary.f32(i32 36, float %10, float %992)  ; FMin(a,b)
  %994 = fsub fast float %11, %818
  %995 = fsub fast float %12, %819
  %996 = fsub fast float %13, %820
  %997 = fmul fast float %993, %994
  %998 = fmul fast float %993, %995
  %999 = fmul fast float %993, %996
  %1000 = fadd fast float %997, %818
  %1001 = fadd fast float %998, %819
  %1002 = fadd fast float %999, %820
  br label %1003

; <label>:1003                                    ; preds = %986, %863, %857
  %1004 = phi float [ %1000, %986 ], [ %818, %863 ], [ %818, %857 ]
  %1005 = phi float [ %1001, %986 ], [ %819, %863 ], [ %819, %857 ]
  %1006 = phi float [ %1002, %986 ], [ %820, %863 ], [ %820, %857 ]
  %1007 = fadd fast float %3, 1.000000e+00
  %1008 = fadd fast float %4, 1.000000e+00
  %1009 = fsub fast float 1.000000e+00, %3
  %1010 = fmul fast float %34, %1007
  %1011 = fmul fast float %34, %1008
  %1012 = fmul fast float %34, %1009
  %1013 = fmul fast float %1010, %1004
  %1014 = fmul fast float %1011, %1005
  %1015 = fmul fast float %1012, %1006
  %1016 = fcmp fast ult float %35, 5.000000e-01
  br i1 %1016, label %1042, label %1017

; <label>:1017                                    ; preds = %1003
  %1018 = fmul fast float %1013, 0x4004147AE0000000
  %1019 = fmul fast float %1014, 0x4004147AE0000000
  %1020 = fmul fast float %1015, 0x4004147AE0000000
  %1021 = fadd fast float %1018, 0x3F9EB851E0000000
  %1022 = fadd fast float %1019, 0x3F9EB851E0000000
  %1023 = fadd fast float %1020, 0x3F9EB851E0000000
  %1024 = fmul fast float %1021, %1013
  %1025 = fmul fast float %1022, %1014
  %1026 = fmul fast float %1023, %1015
  %1027 = fmul fast float %1013, 0x400370A3E0000000
  %1028 = fmul fast float %1014, 0x400370A3E0000000
  %1029 = fmul fast float %1015, 0x400370A3E0000000
  %1030 = fadd fast float %1027, 0x3FE2E147A0000000
  %1031 = fadd fast float %1028, 0x3FE2E147A0000000
  %1032 = fadd fast float %1029, 0x3FE2E147A0000000
  %1033 = fmul fast float %1030, %1013
  %1034 = fmul fast float %1031, %1014
  %1035 = fmul fast float %1032, %1015
  %1036 = fadd fast float %1033, 0x3FC1EB8520000000
  %1037 = fadd fast float %1034, 0x3FC1EB8520000000
  %1038 = fadd fast float %1035, 0x3FC1EB8520000000
  %1039 = fdiv fast float %1024, %1036
  %1040 = fdiv fast float %1025, %1037
  %1041 = fdiv fast float %1026, %1038
  br label %1042

; <label>:1042                                    ; preds = %1017, %1003
  %1043 = phi float [ %1039, %1017 ], [ %1013, %1003 ]
  %1044 = phi float [ %1040, %1017 ], [ %1014, %1003 ]
  %1045 = phi float [ %1041, %1017 ], [ %1015, %1003 ]
  %1046 = call float @dx.op.unary.f32(i32 7, float %1043)  ; Saturate(value)
  %1047 = call float @dx.op.unary.f32(i32 7, float %1044)  ; Saturate(value)
  %1048 = call float @dx.op.unary.f32(i32 7, float %1045)  ; Saturate(value)
  %1049 = call float @dx.op.dot3.f32(i32 55, float %1046, float %1047, float %1048, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1050 = fsub fast float %1046, %1049
  %1051 = fsub fast float %1047, %1049
  %1052 = fsub fast float %1048, %1049
  %1053 = fmul fast float %1050, %6
  %1054 = fmul fast float %1051, %6
  %1055 = fmul fast float %1052, %6
  %1056 = fadd fast float %1053, %1049
  %1057 = fadd fast float %1054, %1049
  %1058 = fadd fast float %1055, %1049
  %1059 = call float @dx.op.unary.f32(i32 7, float %1056)  ; Saturate(value)
  %1060 = call float @dx.op.unary.f32(i32 7, float %1057)  ; Saturate(value)
  %1061 = call float @dx.op.unary.f32(i32 7, float %1058)  ; Saturate(value)
  %1062 = fadd fast float %1059, 0xBFC70A3D80000000
  %1063 = fadd fast float %1060, 0xBFC70A3D80000000
  %1064 = fadd fast float %1061, 0xBFC70A3D80000000
  %1065 = fmul fast float %1062, %5
  %1066 = fmul fast float %1063, %5
  %1067 = fmul fast float %1064, %5
  %1068 = fadd fast float %1065, 0x3FC70A3D80000000
  %1069 = fadd fast float %1066, 0x3FC70A3D80000000
  %1070 = fadd fast float %1067, 0x3FC70A3D80000000
  %1071 = call float @dx.op.unary.f32(i32 7, float %1068)  ; Saturate(value)
  %1072 = call float @dx.op.unary.f32(i32 7, float %1069)  ; Saturate(value)
  %1073 = call float @dx.op.unary.f32(i32 7, float %1070)  ; Saturate(value)
  br label %1074

; <label>:1074                                    ; preds = %1042, %823
  %1075 = phi float [ %854, %823 ], [ %1071, %1042 ]
  %1076 = phi float [ %855, %823 ], [ %1072, %1042 ]
  %1077 = phi float [ %856, %823 ], [ %1073, %1042 ]
  %1078 = add i32 %43, 1
  %1079 = call i32 @dx.op.binary.i32(i32 37, i32 %1078, i32 0)  ; IMax(a,b)
  %1080 = call i32 @dx.op.binary.i32(i32 38, i32 %1079, i32 %271)  ; IMin(a,b)
  %1081 = call i32 @dx.op.binary.i32(i32 37, i32 %1080, i32 0)  ; IMax(a,b)
  %1082 = call i32 @dx.op.binary.i32(i32 38, i32 %1081, i32 %271)  ; IMin(a,b)
  %1083 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1082, i32 %816, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1084 = extractvalue %dx.types.ResRet.f32 %1083, 0
  %1085 = extractvalue %dx.types.ResRet.f32 %1083, 1
  %1086 = extractvalue %dx.types.ResRet.f32 %1083, 2
  %1087 = extractvalue %dx.types.ResRet.f32 %1083, 3
  %1088 = fcmp fast olt float %1087, 0.000000e+00
  br i1 %1088, label %1089, label %1123

; <label>:1089                                    ; preds = %1074
  %1090 = fcmp fast ogt float %1084, 0x3FA4B5DCC0000000
  %1091 = fcmp fast ogt float %1085, 0x3FA4B5DCC0000000
  %1092 = fcmp fast ogt float %1086, 0x3FA4B5DCC0000000
  %1093 = select i1 %1090, float 0.000000e+00, float 1.000000e+00
  %1094 = select i1 %1091, float 0.000000e+00, float 1.000000e+00
  %1095 = select i1 %1092, float 0.000000e+00, float 1.000000e+00
  %1096 = fmul fast float %1084, 0x3FB3D07220000000
  %1097 = fmul fast float %1085, 0x3FB3D07220000000
  %1098 = fmul fast float %1086, 0x3FB3D07220000000
  %1099 = fadd fast float %1084, 0x3FAC28F5C0000000
  %1100 = fadd fast float %1085, 0x3FAC28F5C0000000
  %1101 = fadd fast float %1086, 0x3FAC28F5C0000000
  %1102 = fmul fast float %1099, 0x3FEE54EDE0000000
  %1103 = fmul fast float %1100, 0x3FEE54EDE0000000
  %1104 = fmul fast float %1101, 0x3FEE54EDE0000000
  %1105 = call float @dx.op.unary.f32(i32 23, float %1102)  ; Log(value)
  %1106 = call float @dx.op.unary.f32(i32 23, float %1103)  ; Log(value)
  %1107 = call float @dx.op.unary.f32(i32 23, float %1104)  ; Log(value)
  %1108 = fmul fast float %1105, 0x4003333340000000
  %1109 = fmul fast float %1106, 0x4003333340000000
  %1110 = fmul fast float %1107, 0x4003333340000000
  %1111 = call float @dx.op.unary.f32(i32 21, float %1108)  ; Exp(value)
  %1112 = call float @dx.op.unary.f32(i32 21, float %1109)  ; Exp(value)
  %1113 = call float @dx.op.unary.f32(i32 21, float %1110)  ; Exp(value)
  %1114 = fsub fast float %1096, %1111
  %1115 = fsub fast float %1097, %1112
  %1116 = fsub fast float %1098, %1113
  %1117 = fmul fast float %1114, %1093
  %1118 = fmul fast float %1115, %1094
  %1119 = fmul fast float %1116, %1095
  %1120 = fadd fast float %1117, %1111
  %1121 = fadd fast float %1118, %1112
  %1122 = fadd fast float %1119, %1113
  br label %1340

; <label>:1123                                    ; preds = %1074
  %1124 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1082, i32 %816, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1125 = extractvalue %dx.types.ResRet.f32 %1124, 0
  %1126 = fcmp fast ogt float %36, 5.000000e-01
  %1127 = fcmp fast olt float %1125, 1.000000e+00
  %1128 = and i1 %1126, %1127
  br i1 %1128, label %1129, label %1269

; <label>:1129                                    ; preds = %1123
  %1130 = sitofp i32 %1082 to float
  %1131 = sitofp i32 %816 to float
  %1132 = fadd fast float %1130, 5.000000e-01
  %1133 = fadd fast float %1131, 5.000000e-01
  %1134 = uitofp i32 %41 to float
  %1135 = uitofp i32 %42 to float
  %1136 = fdiv fast float %1132, %1134
  %1137 = fdiv fast float %1133, %1135
  %1138 = fmul fast float %1136, 2.000000e+00
  %1139 = fmul fast float %1137, 2.000000e+00
  %1140 = fadd fast float %1138, -1.000000e+00
  %1141 = fsub fast float 1.000000e+00, %1139
  %1142 = fmul fast float %1140, %33
  %1143 = call float @dx.op.tertiary.f32(i32 46, float %1141, float %29, float %1142)  ; FMad(a,b,c)
  %1144 = call float @dx.op.tertiary.f32(i32 46, float %1125, float %25, float %1143)  ; FMad(a,b,c)
  %1145 = fadd fast float %1144, %21
  %1146 = call float @dx.op.unary.f32(i32 6, float %1145)  ; FAbs(value)
  %1147 = fcmp fast ogt float %1146, 0x3EB0C6F7A0000000
  br i1 %1147, label %1148, label %1269

; <label>:1148                                    ; preds = %1129
  %1149 = fmul fast float %1140, %32
  %1150 = call float @dx.op.tertiary.f32(i32 46, float %1141, float %28, float %1149)  ; FMad(a,b,c)
  %1151 = call float @dx.op.tertiary.f32(i32 46, float %1125, float %24, float %1150)  ; FMad(a,b,c)
  %1152 = fadd fast float %1151, %20
  %1153 = fmul fast float %1140, %31
  %1154 = call float @dx.op.tertiary.f32(i32 46, float %1141, float %27, float %1153)  ; FMad(a,b,c)
  %1155 = call float @dx.op.tertiary.f32(i32 46, float %1125, float %23, float %1154)  ; FMad(a,b,c)
  %1156 = fadd fast float %1155, %19
  %1157 = fmul fast float %1140, %30
  %1158 = call float @dx.op.tertiary.f32(i32 46, float %1141, float %26, float %1157)  ; FMad(a,b,c)
  %1159 = call float @dx.op.tertiary.f32(i32 46, float %1125, float %22, float %1158)  ; FMad(a,b,c)
  %1160 = fadd fast float %1159, %18
  %1161 = fdiv fast float %1160, %1145
  %1162 = fdiv fast float %1156, %1145
  %1163 = fdiv fast float %1152, %1145
  %1164 = fsub fast float %1161, %15
  %1165 = fsub fast float %1162, %16
  %1166 = fsub fast float %1163, %17
  %1167 = fmul fast float %1164, %1164
  %1168 = fmul fast float %1165, %1165
  %1169 = fadd fast float %1168, %1167
  %1170 = fmul fast float %1166, %1166
  %1171 = fadd fast float %1169, %1170
  %1172 = call float @dx.op.unary.f32(i32 24, float %1171)  ; Sqrt(value)
  %1173 = fsub fast float %1172, %7
  %1174 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1173)  ; FMax(a,b)
  %1175 = fcmp fast ogt float %37, 1.500000e+00
  br i1 %1175, label %1176, label %1199

; <label>:1176                                    ; preds = %1148
  %1177 = call float @dx.op.unary.f32(i32 6, float %1165)  ; FAbs(value)
  %1178 = fmul fast float %1177, %9
  %1179 = fcmp fast olt float %1178, 0x3F50624DE0000000
  br i1 %1179, label %1180, label %1183

; <label>:1180                                    ; preds = %1176
  %1181 = fmul fast float %1178, 5.000000e-01
  %1182 = fsub fast float 1.000000e+00, %1181
  br label %1188

; <label>:1183                                    ; preds = %1176
  %1184 = fmul fast float %1178, 0xBFF7154760000000
  %1185 = call float @dx.op.unary.f32(i32 21, float %1184)  ; Exp(value)
  %1186 = fsub fast float 1.000000e+00, %1185
  %1187 = fdiv fast float %1186, %1178
  br label %1188

; <label>:1188                                    ; preds = %1183, %1180
  %1189 = phi float [ %1182, %1180 ], [ %1187, %1183 ]
  %1190 = call float @dx.op.binary.f32(i32 36, float %1162, float %16)  ; FMin(a,b)
  %1191 = fsub fast float %1190, %8
  %1192 = fmul fast float %9, %1191
  %1193 = fsub fast float -0.000000e+00, %1192
  %1194 = call float @dx.op.binary.f32(i32 35, float %1193, float -4.000000e+01)  ; FMax(a,b)
  %1195 = call float @dx.op.binary.f32(i32 36, float %1194, float 5.000000e+00)  ; FMin(a,b)
  %1196 = fmul fast float %1195, 0x3FF7154760000000
  %1197 = call float @dx.op.unary.f32(i32 21, float %1196)  ; Exp(value)
  %1198 = fmul fast float %1197, %1189
  br label %1199

; <label>:1199                                    ; preds = %1188, %1148
  %1200 = phi float [ %1198, %1188 ], [ 1.000000e+00, %1148 ]
  %1201 = fmul fast float %1174, %14
  %1202 = fmul fast float %1201, %1200
  %1203 = fcmp fast ole float %1172, %7
  %1204 = fcmp fast olt float %1172, 0x3F1A36E2E0000000
  %1205 = or i1 %1203, %1204
  br i1 %1205, label %1252, label %1206

; <label>:1206                                    ; preds = %1199
  %1207 = fdiv fast float %7, %1172
  %1208 = fmul fast float %1207, %1164
  %1209 = fmul fast float %1207, %1165
  %1210 = fmul fast float %1207, %1166
  %1211 = fadd fast float %1208, %15
  %1212 = fadd fast float %1209, %16
  %1213 = fadd fast float %1210, %17
  %1214 = fadd fast float %1211, -9.000000e+02
  %1215 = fadd fast float %1212, -1.500000e+01
  %1216 = fadd fast float %1213, -7.500000e+02
  %1217 = fmul fast float %1214, 0x3F62345680000000
  %1218 = fmul fast float %1215, 0x3F62345680000000
  %1219 = fmul fast float %1216, 0x3F62345680000000
  %1220 = call float @dx.op.dot3.f32(i32 55, float %1217, float %1218, float %1219, float %1217, float %1218, float %1219)  ; Dot3(ax,ay,az,bx,by,bz)
  %1221 = fsub fast float 1.000000e+00, %1220
  %1222 = call float @dx.op.unary.f32(i32 7, float %1221)  ; Saturate(value)
  %1223 = fmul fast float %1222, %1222
  %1224 = fadd fast float %1211, %1161
  %1225 = fadd fast float %1212, %1162
  %1226 = fadd fast float %1213, %1163
  %1227 = fmul fast float %1224, 0x3F52345680000000
  %1228 = fadd fast float %1227, -2.000000e+00
  %1229 = fmul fast float %1225, 0x3F52345680000000
  %1230 = fadd fast float %1229, 0xBFA1111120000000
  %1231 = fmul fast float %1226, 0x3F52345680000000
  %1232 = fadd fast float %1231, 0xBFFAAAAAC0000000
  %1233 = call float @dx.op.dot3.f32(i32 55, float %1228, float %1230, float %1232, float %1228, float %1230, float %1232)  ; Dot3(ax,ay,az,bx,by,bz)
  %1234 = fsub fast float 1.000000e+00, %1233
  %1235 = call float @dx.op.unary.f32(i32 7, float %1234)  ; Saturate(value)
  %1236 = fmul fast float %1235, %1235
  %1237 = fmul fast float %1236, 4.000000e+00
  %1238 = fadd fast float %1237, %1223
  %1239 = fadd fast float %1161, -9.000000e+02
  %1240 = fadd fast float %1162, -1.500000e+01
  %1241 = fadd fast float %1163, -7.500000e+02
  %1242 = fmul fast float %1239, 0x3F62345680000000
  %1243 = fmul fast float %1240, 0x3F62345680000000
  %1244 = fmul fast float %1241, 0x3F62345680000000
  %1245 = call float @dx.op.dot3.f32(i32 55, float %1242, float %1243, float %1244, float %1242, float %1243, float %1244)  ; Dot3(ax,ay,az,bx,by,bz)
  %1246 = fsub fast float 1.000000e+00, %1245
  %1247 = call float @dx.op.unary.f32(i32 7, float %1246)  ; Saturate(value)
  %1248 = fmul fast float %1247, %1247
  %1249 = fadd fast float %1238, %1248
  %1250 = fmul fast float %1173, 0x3F25D867E0000000
  %1251 = fmul fast float %1250, %1249
  br label %1252

; <label>:1252                                    ; preds = %1206, %1199
  %1253 = phi float [ %1251, %1206 ], [ 0.000000e+00, %1199 ]
  %1254 = fadd fast float %1253, %1202
  %1255 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1254)  ; FMin(a,b)
  %1256 = fmul fast float %1255, 0xBFF7154760000000
  %1257 = call float @dx.op.unary.f32(i32 21, float %1256)  ; Exp(value)
  %1258 = fsub fast float 1.000000e+00, %1257
  %1259 = call float @dx.op.binary.f32(i32 36, float %10, float %1258)  ; FMin(a,b)
  %1260 = fsub fast float %11, %1084
  %1261 = fsub fast float %12, %1085
  %1262 = fsub fast float %13, %1086
  %1263 = fmul fast float %1259, %1260
  %1264 = fmul fast float %1259, %1261
  %1265 = fmul fast float %1259, %1262
  %1266 = fadd fast float %1263, %1084
  %1267 = fadd fast float %1264, %1085
  %1268 = fadd fast float %1265, %1086
  br label %1269

; <label>:1269                                    ; preds = %1252, %1129, %1123
  %1270 = phi float [ %1266, %1252 ], [ %1084, %1129 ], [ %1084, %1123 ]
  %1271 = phi float [ %1267, %1252 ], [ %1085, %1129 ], [ %1085, %1123 ]
  %1272 = phi float [ %1268, %1252 ], [ %1086, %1129 ], [ %1086, %1123 ]
  %1273 = fadd fast float %3, 1.000000e+00
  %1274 = fadd fast float %4, 1.000000e+00
  %1275 = fsub fast float 1.000000e+00, %3
  %1276 = fmul fast float %34, %1273
  %1277 = fmul fast float %34, %1274
  %1278 = fmul fast float %34, %1275
  %1279 = fmul fast float %1276, %1270
  %1280 = fmul fast float %1277, %1271
  %1281 = fmul fast float %1278, %1272
  %1282 = fcmp fast ult float %35, 5.000000e-01
  br i1 %1282, label %1308, label %1283

; <label>:1283                                    ; preds = %1269
  %1284 = fmul fast float %1279, 0x4004147AE0000000
  %1285 = fmul fast float %1280, 0x4004147AE0000000
  %1286 = fmul fast float %1281, 0x4004147AE0000000
  %1287 = fadd fast float %1284, 0x3F9EB851E0000000
  %1288 = fadd fast float %1285, 0x3F9EB851E0000000
  %1289 = fadd fast float %1286, 0x3F9EB851E0000000
  %1290 = fmul fast float %1287, %1279
  %1291 = fmul fast float %1288, %1280
  %1292 = fmul fast float %1289, %1281
  %1293 = fmul fast float %1279, 0x400370A3E0000000
  %1294 = fmul fast float %1280, 0x400370A3E0000000
  %1295 = fmul fast float %1281, 0x400370A3E0000000
  %1296 = fadd fast float %1293, 0x3FE2E147A0000000
  %1297 = fadd fast float %1294, 0x3FE2E147A0000000
  %1298 = fadd fast float %1295, 0x3FE2E147A0000000
  %1299 = fmul fast float %1296, %1279
  %1300 = fmul fast float %1297, %1280
  %1301 = fmul fast float %1298, %1281
  %1302 = fadd fast float %1299, 0x3FC1EB8520000000
  %1303 = fadd fast float %1300, 0x3FC1EB8520000000
  %1304 = fadd fast float %1301, 0x3FC1EB8520000000
  %1305 = fdiv fast float %1290, %1302
  %1306 = fdiv fast float %1291, %1303
  %1307 = fdiv fast float %1292, %1304
  br label %1308

; <label>:1308                                    ; preds = %1283, %1269
  %1309 = phi float [ %1305, %1283 ], [ %1279, %1269 ]
  %1310 = phi float [ %1306, %1283 ], [ %1280, %1269 ]
  %1311 = phi float [ %1307, %1283 ], [ %1281, %1269 ]
  %1312 = call float @dx.op.unary.f32(i32 7, float %1309)  ; Saturate(value)
  %1313 = call float @dx.op.unary.f32(i32 7, float %1310)  ; Saturate(value)
  %1314 = call float @dx.op.unary.f32(i32 7, float %1311)  ; Saturate(value)
  %1315 = call float @dx.op.dot3.f32(i32 55, float %1312, float %1313, float %1314, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1316 = fsub fast float %1312, %1315
  %1317 = fsub fast float %1313, %1315
  %1318 = fsub fast float %1314, %1315
  %1319 = fmul fast float %1316, %6
  %1320 = fmul fast float %1317, %6
  %1321 = fmul fast float %1318, %6
  %1322 = fadd fast float %1319, %1315
  %1323 = fadd fast float %1320, %1315
  %1324 = fadd fast float %1321, %1315
  %1325 = call float @dx.op.unary.f32(i32 7, float %1322)  ; Saturate(value)
  %1326 = call float @dx.op.unary.f32(i32 7, float %1323)  ; Saturate(value)
  %1327 = call float @dx.op.unary.f32(i32 7, float %1324)  ; Saturate(value)
  %1328 = fadd fast float %1325, 0xBFC70A3D80000000
  %1329 = fadd fast float %1326, 0xBFC70A3D80000000
  %1330 = fadd fast float %1327, 0xBFC70A3D80000000
  %1331 = fmul fast float %1328, %5
  %1332 = fmul fast float %1329, %5
  %1333 = fmul fast float %1330, %5
  %1334 = fadd fast float %1331, 0x3FC70A3D80000000
  %1335 = fadd fast float %1332, 0x3FC70A3D80000000
  %1336 = fadd fast float %1333, 0x3FC70A3D80000000
  %1337 = call float @dx.op.unary.f32(i32 7, float %1334)  ; Saturate(value)
  %1338 = call float @dx.op.unary.f32(i32 7, float %1335)  ; Saturate(value)
  %1339 = call float @dx.op.unary.f32(i32 7, float %1336)  ; Saturate(value)
  br label %1340

; <label>:1340                                    ; preds = %1308, %1089
  %1341 = phi float [ %1120, %1089 ], [ %1337, %1308 ]
  %1342 = phi float [ %1121, %1089 ], [ %1338, %1308 ]
  %1343 = phi float [ %1122, %1089 ], [ %1339, %1308 ]
  %1344 = call float @dx.op.binary.f32(i32 36, float %1075, float %1341)  ; FMin(a,b)
  %1345 = call float @dx.op.binary.f32(i32 36, float %1076, float %1342)  ; FMin(a,b)
  %1346 = call float @dx.op.binary.f32(i32 36, float %1077, float %1343)  ; FMin(a,b)
  %1347 = call float @dx.op.binary.f32(i32 36, float %539, float %805)  ; FMin(a,b)
  %1348 = call float @dx.op.binary.f32(i32 36, float %540, float %806)  ; FMin(a,b)
  %1349 = call float @dx.op.binary.f32(i32 36, float %541, float %807)  ; FMin(a,b)
  %1350 = call float @dx.op.binary.f32(i32 36, float %1347, float %1344)  ; FMin(a,b)
  %1351 = call float @dx.op.binary.f32(i32 36, float %1348, float %1345)  ; FMin(a,b)
  %1352 = call float @dx.op.binary.f32(i32 36, float %1349, float %1346)  ; FMin(a,b)
  %1353 = call float @dx.op.binary.f32(i32 36, float %267, float %1350)  ; FMin(a,b)
  %1354 = call float @dx.op.binary.f32(i32 36, float %268, float %1351)  ; FMin(a,b)
  %1355 = call float @dx.op.binary.f32(i32 36, float %269, float %1352)  ; FMin(a,b)
  %1356 = call float @dx.op.binary.f32(i32 35, float %1075, float %1341)  ; FMax(a,b)
  %1357 = call float @dx.op.binary.f32(i32 35, float %1076, float %1342)  ; FMax(a,b)
  %1358 = call float @dx.op.binary.f32(i32 35, float %1077, float %1343)  ; FMax(a,b)
  %1359 = call float @dx.op.binary.f32(i32 35, float %539, float %805)  ; FMax(a,b)
  %1360 = call float @dx.op.binary.f32(i32 35, float %540, float %806)  ; FMax(a,b)
  %1361 = call float @dx.op.binary.f32(i32 35, float %541, float %807)  ; FMax(a,b)
  %1362 = call float @dx.op.binary.f32(i32 35, float %1359, float %1356)  ; FMax(a,b)
  %1363 = call float @dx.op.binary.f32(i32 35, float %1360, float %1357)  ; FMax(a,b)
  %1364 = call float @dx.op.binary.f32(i32 35, float %1361, float %1358)  ; FMax(a,b)
  %1365 = call float @dx.op.binary.f32(i32 35, float %267, float %1362)  ; FMax(a,b)
  %1366 = call float @dx.op.binary.f32(i32 35, float %268, float %1363)  ; FMax(a,b)
  %1367 = call float @dx.op.binary.f32(i32 35, float %269, float %1364)  ; FMax(a,b)
  %1368 = fsub fast float %1365, %1353
  %1369 = fsub fast float %1366, %1354
  %1370 = fsub fast float %1367, %1355
  %1371 = call float @dx.op.unary.f32(i32 6, float %1368)  ; FAbs(value)
  %1372 = call float @dx.op.unary.f32(i32 6, float %1369)  ; FAbs(value)
  %1373 = call float @dx.op.unary.f32(i32 6, float %1370)  ; FAbs(value)
  %1374 = call float @dx.op.binary.f32(i32 35, float %1372, float %1373)  ; FMax(a,b)
  %1375 = call float @dx.op.binary.f32(i32 35, float %1371, float %1374)  ; FMax(a,b)
  %1376 = call float @dx.op.binary.f32(i32 35, float %1366, float %1367)  ; FMax(a,b)
  %1377 = call float @dx.op.binary.f32(i32 35, float %1365, float %1376)  ; FMax(a,b)
  %1378 = fmul fast float %1377, 1.250000e-01
  %1379 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1378)  ; FMax(a,b)
  %1380 = fcmp fast ogt float %1375, %1379
  br i1 %1380, label %1381, label %1442

; <label>:1381                                    ; preds = %1340
  %1382 = fsub fast float %539, %805
  %1383 = fsub fast float %540, %806
  %1384 = fsub fast float %541, %807
  %1385 = call float @dx.op.unary.f32(i32 6, float %1382)  ; FAbs(value)
  %1386 = call float @dx.op.unary.f32(i32 6, float %1383)  ; FAbs(value)
  %1387 = call float @dx.op.unary.f32(i32 6, float %1384)  ; FAbs(value)
  %1388 = call float @dx.op.binary.f32(i32 35, float %1386, float %1387)  ; FMax(a,b)
  %1389 = call float @dx.op.binary.f32(i32 35, float %1385, float %1388)  ; FMax(a,b)
  %1390 = fsub fast float %1075, %1341
  %1391 = fsub fast float %1076, %1342
  %1392 = fsub fast float %1077, %1343
  %1393 = call float @dx.op.unary.f32(i32 6, float %1390)  ; FAbs(value)
  %1394 = call float @dx.op.unary.f32(i32 6, float %1391)  ; FAbs(value)
  %1395 = call float @dx.op.unary.f32(i32 6, float %1392)  ; FAbs(value)
  %1396 = call float @dx.op.binary.f32(i32 35, float %1394, float %1395)  ; FMax(a,b)
  %1397 = call float @dx.op.binary.f32(i32 35, float %1393, float %1396)  ; FMax(a,b)
  %1398 = fcmp fast olt float %1389, %1397
  %1399 = select i1 %1398, float %539, float %1075
  %1400 = select i1 %1398, float %540, float %1076
  %1401 = select i1 %1398, float %541, float %1077
  %1402 = select i1 %1398, float %805, float %1341
  %1403 = select i1 %1398, float %806, float %1342
  %1404 = select i1 %1398, float %807, float %1343
  %1405 = fsub fast float %267, %1402
  %1406 = fsub fast float %268, %1403
  %1407 = fsub fast float %269, %1404
  %1408 = fsub fast float %267, %1399
  %1409 = fsub fast float %268, %1400
  %1410 = fsub fast float %269, %1401
  %1411 = call float @dx.op.dot3.f32(i32 55, float %1408, float %1409, float %1410, float %1405, float %1406, float %1407)  ; Dot3(ax,ay,az,bx,by,bz)
  %1412 = fcmp fast ogt float %1411, 0.000000e+00
  br i1 %1412, label %1413, label %1425

; <label>:1413                                    ; preds = %1381
  %1414 = fsub fast float %1399, %1402
  %1415 = fsub fast float %1400, %1403
  %1416 = fsub fast float %1401, %1404
  %1417 = call float @dx.op.unary.f32(i32 6, float %1414)  ; FAbs(value)
  %1418 = call float @dx.op.unary.f32(i32 6, float %1415)  ; FAbs(value)
  %1419 = call float @dx.op.unary.f32(i32 6, float %1416)  ; FAbs(value)
  %1420 = call float @dx.op.binary.f32(i32 35, float %1418, float %1419)  ; FMax(a,b)
  %1421 = call float @dx.op.binary.f32(i32 35, float %1417, float %1420)  ; FMax(a,b)
  %1422 = fmul fast float %1375, 2.500000e-01
  %1423 = fcmp fast olt float %1421, %1422
  %1424 = select i1 %1423, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  br label %1425

; <label>:1425                                    ; preds = %1413, %1381
  %1426 = phi float [ 0x3FC99999A0000000, %1381 ], [ %1424, %1413 ]
  %1427 = fadd fast float %1399, %1402
  %1428 = fadd fast float %1400, %1403
  %1429 = fadd fast float %1401, %1404
  %1430 = fmul fast float %1427, 5.000000e-01
  %1431 = fmul fast float %1428, 5.000000e-01
  %1432 = fmul fast float %1429, 5.000000e-01
  %1433 = fsub fast float %1430, %267
  %1434 = fsub fast float %1431, %268
  %1435 = fsub fast float %1432, %269
  %1436 = fmul fast float %1426, %1433
  %1437 = fmul fast float %1426, %1434
  %1438 = fmul fast float %1426, %1435
  %1439 = fadd fast float %1436, %267
  %1440 = fadd fast float %1437, %268
  %1441 = fadd fast float %1438, %269
  br label %1442

; <label>:1442                                    ; preds = %1425, %1340
  %1443 = phi float [ %1439, %1425 ], [ %267, %1340 ]
  %1444 = phi float [ %1440, %1425 ], [ %268, %1340 ]
  %1445 = phi float [ %1441, %1425 ], [ %269, %1340 ]
  %1446 = fcmp fast ogt float %1443, 0x3F69A5C380000000
  %1447 = fcmp fast ogt float %1444, 0x3F69A5C380000000
  %1448 = fcmp fast ogt float %1445, 0x3F69A5C380000000
  %1449 = select i1 %1446, float 0.000000e+00, float 1.000000e+00
  %1450 = select i1 %1447, float 0.000000e+00, float 1.000000e+00
  %1451 = select i1 %1448, float 0.000000e+00, float 1.000000e+00
  %1452 = fmul fast float %1443, 0x4029D70A40000000
  %1453 = fmul fast float %1444, 0x4029D70A40000000
  %1454 = fmul fast float %1445, 0x4029D70A40000000
  %1455 = call float @dx.op.binary.f32(i32 35, float %1443, float 0.000000e+00)  ; FMax(a,b)
  %1456 = call float @dx.op.binary.f32(i32 35, float %1444, float 0.000000e+00)  ; FMax(a,b)
  %1457 = call float @dx.op.binary.f32(i32 35, float %1445, float 0.000000e+00)  ; FMax(a,b)
  %1458 = call float @dx.op.unary.f32(i32 23, float %1455)  ; Log(value)
  %1459 = call float @dx.op.unary.f32(i32 23, float %1456)  ; Log(value)
  %1460 = call float @dx.op.unary.f32(i32 23, float %1457)  ; Log(value)
  %1461 = fmul fast float %1458, 0x3FDAAAAAA0000000
  %1462 = fmul fast float %1459, 0x3FDAAAAAA0000000
  %1463 = fmul fast float %1460, 0x3FDAAAAAA0000000
  %1464 = call float @dx.op.unary.f32(i32 21, float %1461)  ; Exp(value)
  %1465 = call float @dx.op.unary.f32(i32 21, float %1462)  ; Exp(value)
  %1466 = call float @dx.op.unary.f32(i32 21, float %1463)  ; Exp(value)
  %1467 = fmul fast float %1464, 0x3FF0E147A0000000
  %1468 = fmul fast float %1465, 0x3FF0E147A0000000
  %1469 = fmul fast float %1466, 0x3FF0E147A0000000
  %1470 = fadd fast float %1467, 0xBFAC28F5C0000000
  %1471 = fadd fast float %1468, 0xBFAC28F5C0000000
  %1472 = fadd fast float %1469, 0xBFAC28F5C0000000
  %1473 = fsub fast float %1452, %1470
  %1474 = fsub fast float %1453, %1471
  %1475 = fsub fast float %1454, %1472
  %1476 = fmul fast float %1473, %1449
  %1477 = fmul fast float %1474, %1450
  %1478 = fmul fast float %1475, %1451
  %1479 = fadd fast float %1476, %1470
  %1480 = fadd fast float %1477, %1471
  %1481 = fadd fast float %1478, %1472
  br label %1482

; <label>:1482                                    ; preds = %1442, %51
  %1483 = phi float [ %46, %51 ], [ %1479, %1442 ]
  %1484 = phi float [ %47, %51 ], [ %1480, %1442 ]
  %1485 = phi float [ %48, %51 ], [ %1481, %1442 ]
  %1486 = phi float [ %52, %51 ], [ %49, %1442 ]
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %1483)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %1484)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %1485)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %1486)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 0, i32 0, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !37, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, null}
!36 = !{i32 9}
!37 = !{!38}
!38 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
