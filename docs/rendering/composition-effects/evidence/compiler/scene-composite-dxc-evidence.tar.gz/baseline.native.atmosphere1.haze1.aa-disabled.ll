;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float       
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
;
; shader hash: d113375fe469694e609087c0a115ee28
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=0
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 1
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39 }
;   output 3 depends on inputs: { 0, 1 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %40 = extractvalue %dx.types.Dimensions %39, 0
  %41 = extractvalue %dx.types.Dimensions %39, 1
  %42 = fptosi float %37 to i32
  %43 = fptosi float %38 to i32
  %44 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %42, i32 %43, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %45 = extractvalue %dx.types.ResRet.f32 %44, 0
  %46 = extractvalue %dx.types.ResRet.f32 %44, 1
  %47 = extractvalue %dx.types.ResRet.f32 %44, 2
  %48 = extractvalue %dx.types.ResRet.f32 %44, 3
  %49 = fcmp fast olt float %48, 0.000000e+00
  br i1 %49, label %50, label %52

; <label>:50                                      ; preds = %0
  %51 = fsub fast float -1.000000e+00, %48
  br label %306

; <label>:52                                      ; preds = %0
  %53 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %54 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %42, i32 %43, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %55 = extractvalue %dx.types.ResRet.f32 %54, 0
  %56 = fcmp fast ogt float %53, 5.000000e-01
  %57 = fcmp fast olt float %55, 1.000000e+00
  %58 = and i1 %56, %57
  br i1 %58, label %59, label %199

; <label>:59                                      ; preds = %52
  %60 = sitofp i32 %42 to float
  %61 = sitofp i32 %43 to float
  %62 = fadd fast float %60, 5.000000e-01
  %63 = fadd fast float %61, 5.000000e-01
  %64 = uitofp i32 %40 to float
  %65 = uitofp i32 %41 to float
  %66 = fdiv fast float %62, %64
  %67 = fdiv fast float %63, %65
  %68 = fmul fast float %66, 2.000000e+00
  %69 = fmul fast float %67, 2.000000e+00
  %70 = fadd fast float %68, -1.000000e+00
  %71 = fsub fast float 1.000000e+00, %69
  %72 = fmul fast float %70, %33
  %73 = call float @dx.op.tertiary.f32(i32 46, float %71, float %29, float %72)  ; FMad(a,b,c)
  %74 = call float @dx.op.tertiary.f32(i32 46, float %55, float %25, float %73)  ; FMad(a,b,c)
  %75 = fadd fast float %74, %21
  %76 = call float @dx.op.unary.f32(i32 6, float %75)  ; FAbs(value)
  %77 = fcmp fast ogt float %76, 0x3EB0C6F7A0000000
  br i1 %77, label %78, label %199

; <label>:78                                      ; preds = %59
  %79 = fmul fast float %70, %32
  %80 = call float @dx.op.tertiary.f32(i32 46, float %71, float %28, float %79)  ; FMad(a,b,c)
  %81 = call float @dx.op.tertiary.f32(i32 46, float %55, float %24, float %80)  ; FMad(a,b,c)
  %82 = fadd fast float %81, %20
  %83 = fmul fast float %70, %31
  %84 = call float @dx.op.tertiary.f32(i32 46, float %71, float %27, float %83)  ; FMad(a,b,c)
  %85 = call float @dx.op.tertiary.f32(i32 46, float %55, float %23, float %84)  ; FMad(a,b,c)
  %86 = fadd fast float %85, %19
  %87 = fmul fast float %70, %30
  %88 = call float @dx.op.tertiary.f32(i32 46, float %71, float %26, float %87)  ; FMad(a,b,c)
  %89 = call float @dx.op.tertiary.f32(i32 46, float %55, float %22, float %88)  ; FMad(a,b,c)
  %90 = fadd fast float %89, %18
  %91 = fdiv fast float %90, %75
  %92 = fdiv fast float %86, %75
  %93 = fdiv fast float %82, %75
  %94 = fsub fast float %91, %15
  %95 = fsub fast float %92, %16
  %96 = fsub fast float %93, %17
  %97 = fmul fast float %94, %94
  %98 = fmul fast float %95, %95
  %99 = fadd fast float %98, %97
  %100 = fmul fast float %96, %96
  %101 = fadd fast float %99, %100
  %102 = call float @dx.op.unary.f32(i32 24, float %101)  ; Sqrt(value)
  %103 = fsub fast float %102, %7
  %104 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %103)  ; FMax(a,b)
  %105 = fcmp fast ogt float %36, 1.500000e+00
  br i1 %105, label %106, label %129

; <label>:106                                     ; preds = %78
  %107 = call float @dx.op.unary.f32(i32 6, float %95)  ; FAbs(value)
  %108 = fmul fast float %107, %9
  %109 = fcmp fast olt float %108, 0x3F50624DE0000000
  br i1 %109, label %110, label %113

; <label>:110                                     ; preds = %106
  %111 = fmul fast float %108, 5.000000e-01
  %112 = fsub fast float 1.000000e+00, %111
  br label %118

; <label>:113                                     ; preds = %106
  %114 = fmul fast float %108, 0xBFF7154760000000
  %115 = call float @dx.op.unary.f32(i32 21, float %114)  ; Exp(value)
  %116 = fsub fast float 1.000000e+00, %115
  %117 = fdiv fast float %116, %108
  br label %118

; <label>:118                                     ; preds = %113, %110
  %119 = phi float [ %112, %110 ], [ %117, %113 ]
  %120 = call float @dx.op.binary.f32(i32 36, float %92, float %16)  ; FMin(a,b)
  %121 = fsub fast float %120, %8
  %122 = fmul fast float %9, %121
  %123 = fsub fast float -0.000000e+00, %122
  %124 = call float @dx.op.binary.f32(i32 35, float %123, float -4.000000e+01)  ; FMax(a,b)
  %125 = call float @dx.op.binary.f32(i32 36, float %124, float 5.000000e+00)  ; FMin(a,b)
  %126 = fmul fast float %125, 0x3FF7154760000000
  %127 = call float @dx.op.unary.f32(i32 21, float %126)  ; Exp(value)
  %128 = fmul fast float %127, %119
  br label %129

; <label>:129                                     ; preds = %118, %78
  %130 = phi float [ %128, %118 ], [ 1.000000e+00, %78 ]
  %131 = fmul fast float %104, %14
  %132 = fmul fast float %131, %130
  %133 = fcmp fast ole float %102, %7
  %134 = fcmp fast olt float %102, 0x3F1A36E2E0000000
  %135 = or i1 %133, %134
  br i1 %135, label %182, label %136

; <label>:136                                     ; preds = %129
  %137 = fdiv fast float %7, %102
  %138 = fmul fast float %137, %94
  %139 = fmul fast float %137, %95
  %140 = fmul fast float %137, %96
  %141 = fadd fast float %138, %15
  %142 = fadd fast float %139, %16
  %143 = fadd fast float %140, %17
  %144 = fadd fast float %141, -9.000000e+02
  %145 = fadd fast float %142, -1.500000e+01
  %146 = fadd fast float %143, -7.500000e+02
  %147 = fmul fast float %144, 0x3F62345680000000
  %148 = fmul fast float %145, 0x3F62345680000000
  %149 = fmul fast float %146, 0x3F62345680000000
  %150 = call float @dx.op.dot3.f32(i32 55, float %147, float %148, float %149, float %147, float %148, float %149)  ; Dot3(ax,ay,az,bx,by,bz)
  %151 = fsub fast float 1.000000e+00, %150
  %152 = call float @dx.op.unary.f32(i32 7, float %151)  ; Saturate(value)
  %153 = fmul fast float %152, %152
  %154 = fadd fast float %141, %91
  %155 = fadd fast float %142, %92
  %156 = fadd fast float %143, %93
  %157 = fmul fast float %154, 0x3F52345680000000
  %158 = fadd fast float %157, -2.000000e+00
  %159 = fmul fast float %155, 0x3F52345680000000
  %160 = fadd fast float %159, 0xBFA1111120000000
  %161 = fmul fast float %156, 0x3F52345680000000
  %162 = fadd fast float %161, 0xBFFAAAAAC0000000
  %163 = call float @dx.op.dot3.f32(i32 55, float %158, float %160, float %162, float %158, float %160, float %162)  ; Dot3(ax,ay,az,bx,by,bz)
  %164 = fsub fast float 1.000000e+00, %163
  %165 = call float @dx.op.unary.f32(i32 7, float %164)  ; Saturate(value)
  %166 = fmul fast float %165, %165
  %167 = fmul fast float %166, 4.000000e+00
  %168 = fadd fast float %167, %153
  %169 = fadd fast float %91, -9.000000e+02
  %170 = fadd fast float %92, -1.500000e+01
  %171 = fadd fast float %93, -7.500000e+02
  %172 = fmul fast float %169, 0x3F62345680000000
  %173 = fmul fast float %170, 0x3F62345680000000
  %174 = fmul fast float %171, 0x3F62345680000000
  %175 = call float @dx.op.dot3.f32(i32 55, float %172, float %173, float %174, float %172, float %173, float %174)  ; Dot3(ax,ay,az,bx,by,bz)
  %176 = fsub fast float 1.000000e+00, %175
  %177 = call float @dx.op.unary.f32(i32 7, float %176)  ; Saturate(value)
  %178 = fmul fast float %177, %177
  %179 = fadd fast float %168, %178
  %180 = fmul fast float %103, 0x3F25D867E0000000
  %181 = fmul fast float %180, %179
  br label %182

; <label>:182                                     ; preds = %136, %129
  %183 = phi float [ %181, %136 ], [ 0.000000e+00, %129 ]
  %184 = fadd fast float %183, %132
  %185 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %184)  ; FMin(a,b)
  %186 = fmul fast float %185, 0xBFF7154760000000
  %187 = call float @dx.op.unary.f32(i32 21, float %186)  ; Exp(value)
  %188 = fsub fast float 1.000000e+00, %187
  %189 = call float @dx.op.binary.f32(i32 36, float %10, float %188)  ; FMin(a,b)
  %190 = fsub fast float %11, %45
  %191 = fsub fast float %12, %46
  %192 = fsub fast float %13, %47
  %193 = fmul fast float %189, %190
  %194 = fmul fast float %189, %191
  %195 = fmul fast float %189, %192
  %196 = fadd fast float %193, %45
  %197 = fadd fast float %194, %46
  %198 = fadd fast float %195, %47
  br label %199

; <label>:199                                     ; preds = %182, %59, %52
  %200 = phi float [ %196, %182 ], [ %45, %59 ], [ %45, %52 ]
  %201 = phi float [ %197, %182 ], [ %46, %59 ], [ %46, %52 ]
  %202 = phi float [ %198, %182 ], [ %47, %59 ], [ %47, %52 ]
  %203 = fadd fast float %3, 1.000000e+00
  %204 = fadd fast float %4, 1.000000e+00
  %205 = fsub fast float 1.000000e+00, %3
  %206 = fmul fast float %34, %203
  %207 = fmul fast float %34, %204
  %208 = fmul fast float %34, %205
  %209 = fmul fast float %206, %200
  %210 = fmul fast float %207, %201
  %211 = fmul fast float %208, %202
  %212 = fcmp fast ult float %35, 5.000000e-01
  br i1 %212, label %238, label %213

; <label>:213                                     ; preds = %199
  %214 = fmul fast float %209, 0x4004147AE0000000
  %215 = fmul fast float %210, 0x4004147AE0000000
  %216 = fmul fast float %211, 0x4004147AE0000000
  %217 = fadd fast float %214, 0x3F9EB851E0000000
  %218 = fadd fast float %215, 0x3F9EB851E0000000
  %219 = fadd fast float %216, 0x3F9EB851E0000000
  %220 = fmul fast float %217, %209
  %221 = fmul fast float %218, %210
  %222 = fmul fast float %219, %211
  %223 = fmul fast float %209, 0x400370A3E0000000
  %224 = fmul fast float %210, 0x400370A3E0000000
  %225 = fmul fast float %211, 0x400370A3E0000000
  %226 = fadd fast float %223, 0x3FE2E147A0000000
  %227 = fadd fast float %224, 0x3FE2E147A0000000
  %228 = fadd fast float %225, 0x3FE2E147A0000000
  %229 = fmul fast float %226, %209
  %230 = fmul fast float %227, %210
  %231 = fmul fast float %228, %211
  %232 = fadd fast float %229, 0x3FC1EB8520000000
  %233 = fadd fast float %230, 0x3FC1EB8520000000
  %234 = fadd fast float %231, 0x3FC1EB8520000000
  %235 = fdiv fast float %220, %232
  %236 = fdiv fast float %221, %233
  %237 = fdiv fast float %222, %234
  br label %238

; <label>:238                                     ; preds = %213, %199
  %239 = phi float [ %235, %213 ], [ %209, %199 ]
  %240 = phi float [ %236, %213 ], [ %210, %199 ]
  %241 = phi float [ %237, %213 ], [ %211, %199 ]
  %242 = call float @dx.op.unary.f32(i32 7, float %239)  ; Saturate(value)
  %243 = call float @dx.op.unary.f32(i32 7, float %240)  ; Saturate(value)
  %244 = call float @dx.op.unary.f32(i32 7, float %241)  ; Saturate(value)
  %245 = call float @dx.op.dot3.f32(i32 55, float %242, float %243, float %244, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %246 = fsub fast float %242, %245
  %247 = fsub fast float %243, %245
  %248 = fsub fast float %244, %245
  %249 = fmul fast float %246, %6
  %250 = fmul fast float %247, %6
  %251 = fmul fast float %248, %6
  %252 = fadd fast float %249, %245
  %253 = fadd fast float %250, %245
  %254 = fadd fast float %251, %245
  %255 = call float @dx.op.unary.f32(i32 7, float %252)  ; Saturate(value)
  %256 = call float @dx.op.unary.f32(i32 7, float %253)  ; Saturate(value)
  %257 = call float @dx.op.unary.f32(i32 7, float %254)  ; Saturate(value)
  %258 = fadd fast float %255, 0xBFC70A3D80000000
  %259 = fadd fast float %256, 0xBFC70A3D80000000
  %260 = fadd fast float %257, 0xBFC70A3D80000000
  %261 = fmul fast float %258, %5
  %262 = fmul fast float %259, %5
  %263 = fmul fast float %260, %5
  %264 = fadd fast float %261, 0x3FC70A3D80000000
  %265 = fadd fast float %262, 0x3FC70A3D80000000
  %266 = fadd fast float %263, 0x3FC70A3D80000000
  %267 = call float @dx.op.unary.f32(i32 7, float %264)  ; Saturate(value)
  %268 = call float @dx.op.unary.f32(i32 7, float %265)  ; Saturate(value)
  %269 = call float @dx.op.unary.f32(i32 7, float %266)  ; Saturate(value)
  %270 = fcmp fast ogt float %267, 0x3F69A5C380000000
  %271 = fcmp fast ogt float %268, 0x3F69A5C380000000
  %272 = fcmp fast ogt float %269, 0x3F69A5C380000000
  %273 = select i1 %270, float 0.000000e+00, float 1.000000e+00
  %274 = select i1 %271, float 0.000000e+00, float 1.000000e+00
  %275 = select i1 %272, float 0.000000e+00, float 1.000000e+00
  %276 = fmul fast float %267, 0x4029D70A40000000
  %277 = fmul fast float %268, 0x4029D70A40000000
  %278 = fmul fast float %269, 0x4029D70A40000000
  %279 = call float @dx.op.binary.f32(i32 35, float %267, float 0.000000e+00)  ; FMax(a,b)
  %280 = call float @dx.op.binary.f32(i32 35, float %268, float 0.000000e+00)  ; FMax(a,b)
  %281 = call float @dx.op.binary.f32(i32 35, float %269, float 0.000000e+00)  ; FMax(a,b)
  %282 = call float @dx.op.unary.f32(i32 23, float %279)  ; Log(value)
  %283 = call float @dx.op.unary.f32(i32 23, float %280)  ; Log(value)
  %284 = call float @dx.op.unary.f32(i32 23, float %281)  ; Log(value)
  %285 = fmul fast float %282, 0x3FDAAAAAA0000000
  %286 = fmul fast float %283, 0x3FDAAAAAA0000000
  %287 = fmul fast float %284, 0x3FDAAAAAA0000000
  %288 = call float @dx.op.unary.f32(i32 21, float %285)  ; Exp(value)
  %289 = call float @dx.op.unary.f32(i32 21, float %286)  ; Exp(value)
  %290 = call float @dx.op.unary.f32(i32 21, float %287)  ; Exp(value)
  %291 = fmul fast float %288, 0x3FF0E147A0000000
  %292 = fmul fast float %289, 0x3FF0E147A0000000
  %293 = fmul fast float %290, 0x3FF0E147A0000000
  %294 = fadd fast float %291, 0xBFAC28F5C0000000
  %295 = fadd fast float %292, 0xBFAC28F5C0000000
  %296 = fadd fast float %293, 0xBFAC28F5C0000000
  %297 = fsub fast float %276, %294
  %298 = fsub fast float %277, %295
  %299 = fsub fast float %278, %296
  %300 = fmul fast float %297, %273
  %301 = fmul fast float %298, %274
  %302 = fmul fast float %299, %275
  %303 = fadd fast float %300, %294
  %304 = fadd fast float %301, %295
  %305 = fadd fast float %302, %296
  br label %306

; <label>:306                                     ; preds = %238, %50
  %307 = phi float [ %45, %50 ], [ %303, %238 ]
  %308 = phi float [ %46, %50 ], [ %304, %238 ]
  %309 = phi float [ %47, %50 ], [ %305, %238 ]
  %310 = phi float [ %51, %50 ], [ %48, %238 ]
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %307)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %308)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %309)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %310)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 0, i32 0, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !37, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, null}
!36 = !{i32 9}
!37 = !{!38}
!38 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
