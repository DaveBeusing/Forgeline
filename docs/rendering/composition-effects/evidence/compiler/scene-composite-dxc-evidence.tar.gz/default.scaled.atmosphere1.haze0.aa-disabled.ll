;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float    yz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: 62039762408c073c51df59b724a5c679
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %40 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %41 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %42 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %43 = extractvalue %dx.types.Dimensions %42, 0
  %44 = extractvalue %dx.types.Dimensions %42, 1
  %45 = uitofp i32 %43 to float
  %46 = uitofp i32 %44 to float
  %47 = fmul fast float %45, %40
  %48 = fmul fast float %46, %41
  %49 = fdiv fast float %47, %3
  %50 = fdiv fast float %48, %4
  %51 = fadd fast float %49, -5.000000e-01
  %52 = fadd fast float %50, -5.000000e-01
  %53 = call float @dx.op.unary.f32(i32 27, float %51)  ; Round_ni(value)
  %54 = call float @dx.op.unary.f32(i32 27, float %52)  ; Round_ni(value)
  %55 = fptosi float %53 to i32
  %56 = fptosi float %54 to i32
  %57 = call float @dx.op.unary.f32(i32 22, float %51)  ; Frc(value)
  %58 = call float @dx.op.unary.f32(i32 22, float %52)  ; Frc(value)
  %59 = add i32 %43, -1
  %60 = add i32 %44, -1
  %61 = call i32 @dx.op.binary.i32(i32 37, i32 %55, i32 0)  ; IMax(a,b)
  %62 = call i32 @dx.op.binary.i32(i32 37, i32 %56, i32 0)  ; IMax(a,b)
  %63 = call i32 @dx.op.binary.i32(i32 38, i32 %61, i32 %59)  ; IMin(a,b)
  %64 = call i32 @dx.op.binary.i32(i32 38, i32 %62, i32 %60)  ; IMin(a,b)
  %65 = add i32 %55, 1
  %66 = call i32 @dx.op.binary.i32(i32 37, i32 %65, i32 0)  ; IMax(a,b)
  %67 = call i32 @dx.op.binary.i32(i32 38, i32 %66, i32 %59)  ; IMin(a,b)
  %68 = add i32 %56, 1
  %69 = call i32 @dx.op.binary.i32(i32 37, i32 %68, i32 0)  ; IMax(a,b)
  %70 = call i32 @dx.op.binary.i32(i32 38, i32 %69, i32 %60)  ; IMin(a,b)
  %71 = call float @dx.op.unary.f32(i32 27, float %49)  ; Round_ni(value)
  %72 = call float @dx.op.unary.f32(i32 27, float %50)  ; Round_ni(value)
  %73 = fptosi float %71 to i32
  %74 = fptosi float %72 to i32
  %75 = call i32 @dx.op.binary.i32(i32 37, i32 %73, i32 0)  ; IMax(a,b)
  %76 = call i32 @dx.op.binary.i32(i32 37, i32 %74, i32 0)  ; IMax(a,b)
  %77 = call i32 @dx.op.binary.i32(i32 38, i32 %75, i32 %59)  ; IMin(a,b)
  %78 = call i32 @dx.op.binary.i32(i32 38, i32 %76, i32 %60)  ; IMin(a,b)
  %79 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %77, i32 %78, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %80 = extractvalue %dx.types.ResRet.f32 %79, 0
  %81 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %82 = extractvalue %dx.types.ResRet.f32 %81, 0
  %83 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %67, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %84 = extractvalue %dx.types.ResRet.f32 %83, 0
  %85 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %86 = extractvalue %dx.types.ResRet.f32 %85, 0
  %87 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %67, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %88 = extractvalue %dx.types.ResRet.f32 %87, 0
  %89 = fsub fast float 1.000000e+00, %57
  %90 = fsub fast float 1.000000e+00, %58
  %91 = fmul fast float %90, %89
  %92 = fmul fast float %90, %57
  %93 = fmul fast float %89, %58
  %94 = fmul fast float %58, %57
  %95 = fsub fast float 1.000000e+00, %80
  %96 = fmul fast float %95, 0x3FA99999A0000000
  %97 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %96)  ; FMax(a,b)
  %98 = fsub fast float %82, %80
  %99 = call float @dx.op.unary.f32(i32 6, float %98)  ; FAbs(value)
  %100 = fdiv fast float %99, %97
  %101 = fsub fast float 1.000000e+00, %100
  %102 = call float @dx.op.unary.f32(i32 7, float %101)  ; Saturate(value)
  %103 = fsub fast float %84, %80
  %104 = call float @dx.op.unary.f32(i32 6, float %103)  ; FAbs(value)
  %105 = fdiv fast float %104, %97
  %106 = fsub fast float 1.000000e+00, %105
  %107 = call float @dx.op.unary.f32(i32 7, float %106)  ; Saturate(value)
  %108 = fsub fast float %86, %80
  %109 = call float @dx.op.unary.f32(i32 6, float %108)  ; FAbs(value)
  %110 = fdiv fast float %109, %97
  %111 = fsub fast float 1.000000e+00, %110
  %112 = call float @dx.op.unary.f32(i32 7, float %111)  ; Saturate(value)
  %113 = fsub fast float %88, %80
  %114 = call float @dx.op.unary.f32(i32 6, float %113)  ; FAbs(value)
  %115 = fdiv fast float %114, %97
  %116 = fsub fast float 1.000000e+00, %115
  %117 = call float @dx.op.unary.f32(i32 7, float %116)  ; Saturate(value)
  %118 = fmul fast float %91, %102
  %119 = fmul fast float %92, %107
  %120 = fmul fast float %93, %112
  %121 = fmul fast float %94, %117
  %122 = fcmp fast oge float %57, 5.000000e-01
  %123 = zext i1 %122 to i32
  %124 = fcmp fast oge float %58, 5.000000e-01
  %125 = select i1 %124, i32 2, i32 0
  %126 = or i32 %125, %123
  %127 = call float @dx.op.dot4.f32(i32 56, float %118, float %119, float %120, float %121, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %128 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %118)  ; IsFinite(value)
  %129 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %119)  ; IsFinite(value)
  %130 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %120)  ; IsFinite(value)
  %131 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %121)  ; IsFinite(value)
  %132 = and i1 %128, %129
  %133 = and i1 %132, %130
  %134 = and i1 %133, %131
  br i1 %134, label %135, label %152

; <label>:135                                     ; preds = %0
  %136 = fcmp fast oge float %118, 0.000000e+00
  %137 = fcmp fast oge float %119, 0.000000e+00
  %138 = fcmp fast oge float %120, 0.000000e+00
  %139 = fcmp fast oge float %121, 0.000000e+00
  %140 = and i1 %136, %137
  %141 = and i1 %140, %138
  %142 = and i1 %141, %139
  br i1 %142, label %143, label %152

; <label>:143                                     ; preds = %135
  %144 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %127)  ; IsFinite(value)
  %145 = fcmp fast oge float %127, 0x3810000000000000
  %146 = and i1 %145, %144
  br i1 %146, label %147, label %152

; <label>:147                                     ; preds = %143
  %148 = fdiv fast float %118, %127
  %149 = fdiv fast float %119, %127
  %150 = fdiv fast float %120, %127
  %151 = fdiv fast float %121, %127
  br label %161

; <label>:152                                     ; preds = %143, %135, %0
  %153 = icmp eq i32 %126, 0
  %154 = uitofp i1 %153 to float
  %155 = icmp eq i32 %126, 1
  %156 = uitofp i1 %155 to float
  %157 = icmp eq i32 %126, 2
  %158 = uitofp i1 %157 to float
  %159 = icmp eq i32 %126, 3
  %160 = uitofp i1 %159 to float
  br label %161

; <label>:161                                     ; preds = %152, %147
  %162 = phi float [ %148, %147 ], [ %154, %152 ]
  %163 = phi float [ %149, %147 ], [ %156, %152 ]
  %164 = phi float [ %150, %147 ], [ %158, %152 ]
  %165 = phi float [ %151, %147 ], [ %160, %152 ]
  %166 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %167 = extractvalue %dx.types.ResRet.f32 %166, 0
  %168 = extractvalue %dx.types.ResRet.f32 %166, 1
  %169 = extractvalue %dx.types.ResRet.f32 %166, 2
  %170 = extractvalue %dx.types.ResRet.f32 %166, 3
  %171 = fcmp fast olt float %170, 0.000000e+00
  br i1 %171, label %172, label %174

; <label>:172                                     ; preds = %161
  %173 = fsub fast float -1.000000e+00, %170
  br label %371

; <label>:174                                     ; preds = %161
  %175 = fcmp fast ogt float %38, 5.000000e-01
  %176 = fcmp fast olt float %82, 1.000000e+00
  %177 = and i1 %175, %176
  br i1 %177, label %178, label %264

; <label>:178                                     ; preds = %174
  %179 = sitofp i32 %63 to float
  %180 = sitofp i32 %64 to float
  %181 = fadd fast float %179, 5.000000e-01
  %182 = fadd fast float %180, 5.000000e-01
  %183 = fdiv fast float %181, %45
  %184 = fdiv fast float %182, %46
  %185 = fmul fast float %183, 2.000000e+00
  %186 = fmul fast float %184, 2.000000e+00
  %187 = fadd fast float %185, -1.000000e+00
  %188 = fsub fast float 1.000000e+00, %186
  %189 = fmul fast float %187, %35
  %190 = call float @dx.op.tertiary.f32(i32 46, float %188, float %31, float %189)  ; FMad(a,b,c)
  %191 = call float @dx.op.tertiary.f32(i32 46, float %82, float %27, float %190)  ; FMad(a,b,c)
  %192 = fadd fast float %191, %23
  %193 = call float @dx.op.unary.f32(i32 6, float %192)  ; FAbs(value)
  %194 = fcmp fast ogt float %193, 0x3EB0C6F7A0000000
  br i1 %194, label %195, label %264

; <label>:195                                     ; preds = %178
  %196 = fmul fast float %187, %34
  %197 = call float @dx.op.tertiary.f32(i32 46, float %188, float %30, float %196)  ; FMad(a,b,c)
  %198 = call float @dx.op.tertiary.f32(i32 46, float %82, float %26, float %197)  ; FMad(a,b,c)
  %199 = fadd fast float %198, %22
  %200 = fmul fast float %187, %33
  %201 = call float @dx.op.tertiary.f32(i32 46, float %188, float %29, float %200)  ; FMad(a,b,c)
  %202 = call float @dx.op.tertiary.f32(i32 46, float %82, float %25, float %201)  ; FMad(a,b,c)
  %203 = fadd fast float %202, %21
  %204 = fmul fast float %187, %32
  %205 = call float @dx.op.tertiary.f32(i32 46, float %188, float %28, float %204)  ; FMad(a,b,c)
  %206 = call float @dx.op.tertiary.f32(i32 46, float %82, float %24, float %205)  ; FMad(a,b,c)
  %207 = fadd fast float %206, %20
  %208 = fdiv fast float %207, %192
  %209 = fdiv fast float %203, %192
  %210 = fdiv fast float %199, %192
  %211 = fsub fast float %208, %17
  %212 = fsub fast float %209, %18
  %213 = fsub fast float %210, %19
  %214 = fmul fast float %211, %211
  %215 = fmul fast float %212, %212
  %216 = fadd fast float %215, %214
  %217 = fmul fast float %213, %213
  %218 = fadd fast float %216, %217
  %219 = call float @dx.op.unary.f32(i32 24, float %218)  ; Sqrt(value)
  %220 = fsub fast float %219, %9
  %221 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %220)  ; FMax(a,b)
  %222 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %222, label %223, label %246

; <label>:223                                     ; preds = %195
  %224 = call float @dx.op.unary.f32(i32 6, float %212)  ; FAbs(value)
  %225 = fmul fast float %224, %11
  %226 = fcmp fast olt float %225, 0x3F50624DE0000000
  br i1 %226, label %227, label %230

; <label>:227                                     ; preds = %223
  %228 = fmul fast float %225, 5.000000e-01
  %229 = fsub fast float 1.000000e+00, %228
  br label %235

; <label>:230                                     ; preds = %223
  %231 = fmul fast float %225, 0xBFF7154760000000
  %232 = call float @dx.op.unary.f32(i32 21, float %231)  ; Exp(value)
  %233 = fsub fast float 1.000000e+00, %232
  %234 = fdiv fast float %233, %225
  br label %235

; <label>:235                                     ; preds = %230, %227
  %236 = phi float [ %229, %227 ], [ %234, %230 ]
  %237 = call float @dx.op.binary.f32(i32 36, float %209, float %18)  ; FMin(a,b)
  %238 = fsub fast float %237, %10
  %239 = fmul fast float %11, %238
  %240 = fsub fast float -0.000000e+00, %239
  %241 = call float @dx.op.binary.f32(i32 35, float %240, float -4.000000e+01)  ; FMax(a,b)
  %242 = call float @dx.op.binary.f32(i32 36, float %241, float 5.000000e+00)  ; FMin(a,b)
  %243 = fmul fast float %242, 0x3FF7154760000000
  %244 = call float @dx.op.unary.f32(i32 21, float %243)  ; Exp(value)
  %245 = fmul fast float %244, %236
  br label %246

; <label>:246                                     ; preds = %235, %195
  %247 = phi float [ %245, %235 ], [ 1.000000e+00, %195 ]
  %248 = fmul fast float %221, %16
  %249 = fmul fast float %248, %247
  %250 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %249)  ; FMin(a,b)
  %251 = fmul fast float %250, 0xBFF7154760000000
  %252 = call float @dx.op.unary.f32(i32 21, float %251)  ; Exp(value)
  %253 = fsub fast float 1.000000e+00, %252
  %254 = call float @dx.op.binary.f32(i32 36, float %12, float %253)  ; FMin(a,b)
  %255 = fsub fast float %13, %167
  %256 = fsub fast float %14, %168
  %257 = fsub fast float %15, %169
  %258 = fmul fast float %254, %255
  %259 = fmul fast float %254, %256
  %260 = fmul fast float %254, %257
  %261 = fadd fast float %258, %167
  %262 = fadd fast float %259, %168
  %263 = fadd fast float %260, %169
  br label %264

; <label>:264                                     ; preds = %246, %178, %174
  %265 = phi float [ %261, %246 ], [ %167, %178 ], [ %167, %174 ]
  %266 = phi float [ %262, %246 ], [ %168, %178 ], [ %168, %174 ]
  %267 = phi float [ %263, %246 ], [ %169, %178 ], [ %169, %174 ]
  %268 = fadd fast float %5, 1.000000e+00
  %269 = fadd fast float %6, 1.000000e+00
  %270 = fsub fast float 1.000000e+00, %5
  %271 = fmul fast float %36, %268
  %272 = fmul fast float %36, %269
  %273 = fmul fast float %36, %270
  %274 = fmul fast float %271, %265
  %275 = fmul fast float %272, %266
  %276 = fmul fast float %273, %267
  %277 = fcmp fast ult float %37, 5.000000e-01
  br i1 %277, label %303, label %278

; <label>:278                                     ; preds = %264
  %279 = fmul fast float %274, 0x4004147AE0000000
  %280 = fmul fast float %275, 0x4004147AE0000000
  %281 = fmul fast float %276, 0x4004147AE0000000
  %282 = fadd fast float %279, 0x3F9EB851E0000000
  %283 = fadd fast float %280, 0x3F9EB851E0000000
  %284 = fadd fast float %281, 0x3F9EB851E0000000
  %285 = fmul fast float %282, %274
  %286 = fmul fast float %283, %275
  %287 = fmul fast float %284, %276
  %288 = fmul fast float %274, 0x400370A3E0000000
  %289 = fmul fast float %275, 0x400370A3E0000000
  %290 = fmul fast float %276, 0x400370A3E0000000
  %291 = fadd fast float %288, 0x3FE2E147A0000000
  %292 = fadd fast float %289, 0x3FE2E147A0000000
  %293 = fadd fast float %290, 0x3FE2E147A0000000
  %294 = fmul fast float %291, %274
  %295 = fmul fast float %292, %275
  %296 = fmul fast float %293, %276
  %297 = fadd fast float %294, 0x3FC1EB8520000000
  %298 = fadd fast float %295, 0x3FC1EB8520000000
  %299 = fadd fast float %296, 0x3FC1EB8520000000
  %300 = fdiv fast float %285, %297
  %301 = fdiv fast float %286, %298
  %302 = fdiv fast float %287, %299
  br label %303

; <label>:303                                     ; preds = %278, %264
  %304 = phi float [ %300, %278 ], [ %274, %264 ]
  %305 = phi float [ %301, %278 ], [ %275, %264 ]
  %306 = phi float [ %302, %278 ], [ %276, %264 ]
  %307 = call float @dx.op.unary.f32(i32 7, float %304)  ; Saturate(value)
  %308 = call float @dx.op.unary.f32(i32 7, float %305)  ; Saturate(value)
  %309 = call float @dx.op.unary.f32(i32 7, float %306)  ; Saturate(value)
  %310 = call float @dx.op.dot3.f32(i32 55, float %307, float %308, float %309, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %311 = fsub fast float %307, %310
  %312 = fsub fast float %308, %310
  %313 = fsub fast float %309, %310
  %314 = fmul fast float %311, %8
  %315 = fmul fast float %312, %8
  %316 = fmul fast float %313, %8
  %317 = fadd fast float %314, %310
  %318 = fadd fast float %315, %310
  %319 = fadd fast float %316, %310
  %320 = call float @dx.op.unary.f32(i32 7, float %317)  ; Saturate(value)
  %321 = call float @dx.op.unary.f32(i32 7, float %318)  ; Saturate(value)
  %322 = call float @dx.op.unary.f32(i32 7, float %319)  ; Saturate(value)
  %323 = fadd fast float %320, 0xBFC70A3D80000000
  %324 = fadd fast float %321, 0xBFC70A3D80000000
  %325 = fadd fast float %322, 0xBFC70A3D80000000
  %326 = fmul fast float %323, %7
  %327 = fmul fast float %324, %7
  %328 = fmul fast float %325, %7
  %329 = fadd fast float %326, 0x3FC70A3D80000000
  %330 = fadd fast float %327, 0x3FC70A3D80000000
  %331 = fadd fast float %328, 0x3FC70A3D80000000
  %332 = call float @dx.op.unary.f32(i32 7, float %329)  ; Saturate(value)
  %333 = call float @dx.op.unary.f32(i32 7, float %330)  ; Saturate(value)
  %334 = call float @dx.op.unary.f32(i32 7, float %331)  ; Saturate(value)
  %335 = fcmp fast ogt float %332, 0x3F69A5C380000000
  %336 = fcmp fast ogt float %333, 0x3F69A5C380000000
  %337 = fcmp fast ogt float %334, 0x3F69A5C380000000
  %338 = select i1 %335, float 0.000000e+00, float 1.000000e+00
  %339 = select i1 %336, float 0.000000e+00, float 1.000000e+00
  %340 = select i1 %337, float 0.000000e+00, float 1.000000e+00
  %341 = fmul fast float %332, 0x4029D70A40000000
  %342 = fmul fast float %333, 0x4029D70A40000000
  %343 = fmul fast float %334, 0x4029D70A40000000
  %344 = call float @dx.op.binary.f32(i32 35, float %332, float 0.000000e+00)  ; FMax(a,b)
  %345 = call float @dx.op.binary.f32(i32 35, float %333, float 0.000000e+00)  ; FMax(a,b)
  %346 = call float @dx.op.binary.f32(i32 35, float %334, float 0.000000e+00)  ; FMax(a,b)
  %347 = call float @dx.op.unary.f32(i32 23, float %344)  ; Log(value)
  %348 = call float @dx.op.unary.f32(i32 23, float %345)  ; Log(value)
  %349 = call float @dx.op.unary.f32(i32 23, float %346)  ; Log(value)
  %350 = fmul fast float %347, 0x3FDAAAAAA0000000
  %351 = fmul fast float %348, 0x3FDAAAAAA0000000
  %352 = fmul fast float %349, 0x3FDAAAAAA0000000
  %353 = call float @dx.op.unary.f32(i32 21, float %350)  ; Exp(value)
  %354 = call float @dx.op.unary.f32(i32 21, float %351)  ; Exp(value)
  %355 = call float @dx.op.unary.f32(i32 21, float %352)  ; Exp(value)
  %356 = fmul fast float %353, 0x3FF0E147A0000000
  %357 = fmul fast float %354, 0x3FF0E147A0000000
  %358 = fmul fast float %355, 0x3FF0E147A0000000
  %359 = fadd fast float %356, 0xBFAC28F5C0000000
  %360 = fadd fast float %357, 0xBFAC28F5C0000000
  %361 = fadd fast float %358, 0xBFAC28F5C0000000
  %362 = fsub fast float %341, %359
  %363 = fsub fast float %342, %360
  %364 = fsub fast float %343, %361
  %365 = fmul fast float %362, %338
  %366 = fmul fast float %363, %339
  %367 = fmul fast float %364, %340
  %368 = fadd fast float %365, %359
  %369 = fadd fast float %366, %360
  %370 = fadd fast float %367, %361
  br label %371

; <label>:371                                     ; preds = %303, %172
  %372 = phi float [ %167, %172 ], [ %368, %303 ]
  %373 = phi float [ %168, %172 ], [ %369, %303 ]
  %374 = phi float [ %169, %172 ], [ %370, %303 ]
  %375 = phi float [ %173, %172 ], [ %170, %303 ]
  %376 = fcmp fast ogt float %372, 0x3FA4B5DCC0000000
  %377 = fcmp fast ogt float %373, 0x3FA4B5DCC0000000
  %378 = fcmp fast ogt float %374, 0x3FA4B5DCC0000000
  %379 = select i1 %376, float 0.000000e+00, float 1.000000e+00
  %380 = select i1 %377, float 0.000000e+00, float 1.000000e+00
  %381 = select i1 %378, float 0.000000e+00, float 1.000000e+00
  %382 = fmul fast float %372, 0x3FB3D07220000000
  %383 = fmul fast float %373, 0x3FB3D07220000000
  %384 = fmul fast float %374, 0x3FB3D07220000000
  %385 = fadd fast float %372, 0x3FAC28F5C0000000
  %386 = fadd fast float %373, 0x3FAC28F5C0000000
  %387 = fadd fast float %374, 0x3FAC28F5C0000000
  %388 = fmul fast float %385, 0x3FEE54EDE0000000
  %389 = fmul fast float %386, 0x3FEE54EDE0000000
  %390 = fmul fast float %387, 0x3FEE54EDE0000000
  %391 = call float @dx.op.unary.f32(i32 23, float %388)  ; Log(value)
  %392 = call float @dx.op.unary.f32(i32 23, float %389)  ; Log(value)
  %393 = call float @dx.op.unary.f32(i32 23, float %390)  ; Log(value)
  %394 = fmul fast float %391, 0x4003333340000000
  %395 = fmul fast float %392, 0x4003333340000000
  %396 = fmul fast float %393, 0x4003333340000000
  %397 = call float @dx.op.unary.f32(i32 21, float %394)  ; Exp(value)
  %398 = call float @dx.op.unary.f32(i32 21, float %395)  ; Exp(value)
  %399 = call float @dx.op.unary.f32(i32 21, float %396)  ; Exp(value)
  %400 = fsub fast float %382, %397
  %401 = fsub fast float %383, %398
  %402 = fsub fast float %384, %399
  %403 = fmul fast float %400, %379
  %404 = fmul fast float %401, %380
  %405 = fmul fast float %402, %381
  %406 = fadd fast float %403, %397
  %407 = fadd fast float %404, %398
  %408 = fadd fast float %405, %399
  %409 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %67, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %410 = extractvalue %dx.types.ResRet.f32 %409, 0
  %411 = extractvalue %dx.types.ResRet.f32 %409, 1
  %412 = extractvalue %dx.types.ResRet.f32 %409, 2
  %413 = extractvalue %dx.types.ResRet.f32 %409, 3
  %414 = fcmp fast olt float %413, 0.000000e+00
  br i1 %414, label %415, label %417

; <label>:415                                     ; preds = %371
  %416 = fsub fast float -1.000000e+00, %413
  br label %614

; <label>:417                                     ; preds = %371
  %418 = fcmp fast ogt float %38, 5.000000e-01
  %419 = fcmp fast olt float %84, 1.000000e+00
  %420 = and i1 %418, %419
  br i1 %420, label %421, label %507

; <label>:421                                     ; preds = %417
  %422 = sitofp i32 %67 to float
  %423 = sitofp i32 %64 to float
  %424 = fadd fast float %422, 5.000000e-01
  %425 = fadd fast float %423, 5.000000e-01
  %426 = fdiv fast float %424, %45
  %427 = fdiv fast float %425, %46
  %428 = fmul fast float %426, 2.000000e+00
  %429 = fmul fast float %427, 2.000000e+00
  %430 = fadd fast float %428, -1.000000e+00
  %431 = fsub fast float 1.000000e+00, %429
  %432 = fmul fast float %430, %35
  %433 = call float @dx.op.tertiary.f32(i32 46, float %431, float %31, float %432)  ; FMad(a,b,c)
  %434 = call float @dx.op.tertiary.f32(i32 46, float %84, float %27, float %433)  ; FMad(a,b,c)
  %435 = fadd fast float %434, %23
  %436 = call float @dx.op.unary.f32(i32 6, float %435)  ; FAbs(value)
  %437 = fcmp fast ogt float %436, 0x3EB0C6F7A0000000
  br i1 %437, label %438, label %507

; <label>:438                                     ; preds = %421
  %439 = fmul fast float %430, %34
  %440 = call float @dx.op.tertiary.f32(i32 46, float %431, float %30, float %439)  ; FMad(a,b,c)
  %441 = call float @dx.op.tertiary.f32(i32 46, float %84, float %26, float %440)  ; FMad(a,b,c)
  %442 = fadd fast float %441, %22
  %443 = fmul fast float %430, %33
  %444 = call float @dx.op.tertiary.f32(i32 46, float %431, float %29, float %443)  ; FMad(a,b,c)
  %445 = call float @dx.op.tertiary.f32(i32 46, float %84, float %25, float %444)  ; FMad(a,b,c)
  %446 = fadd fast float %445, %21
  %447 = fmul fast float %430, %32
  %448 = call float @dx.op.tertiary.f32(i32 46, float %431, float %28, float %447)  ; FMad(a,b,c)
  %449 = call float @dx.op.tertiary.f32(i32 46, float %84, float %24, float %448)  ; FMad(a,b,c)
  %450 = fadd fast float %449, %20
  %451 = fdiv fast float %450, %435
  %452 = fdiv fast float %446, %435
  %453 = fdiv fast float %442, %435
  %454 = fsub fast float %451, %17
  %455 = fsub fast float %452, %18
  %456 = fsub fast float %453, %19
  %457 = fmul fast float %454, %454
  %458 = fmul fast float %455, %455
  %459 = fadd fast float %458, %457
  %460 = fmul fast float %456, %456
  %461 = fadd fast float %459, %460
  %462 = call float @dx.op.unary.f32(i32 24, float %461)  ; Sqrt(value)
  %463 = fsub fast float %462, %9
  %464 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %463)  ; FMax(a,b)
  %465 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %465, label %466, label %489

; <label>:466                                     ; preds = %438
  %467 = call float @dx.op.unary.f32(i32 6, float %455)  ; FAbs(value)
  %468 = fmul fast float %467, %11
  %469 = fcmp fast olt float %468, 0x3F50624DE0000000
  br i1 %469, label %470, label %473

; <label>:470                                     ; preds = %466
  %471 = fmul fast float %468, 5.000000e-01
  %472 = fsub fast float 1.000000e+00, %471
  br label %478

; <label>:473                                     ; preds = %466
  %474 = fmul fast float %468, 0xBFF7154760000000
  %475 = call float @dx.op.unary.f32(i32 21, float %474)  ; Exp(value)
  %476 = fsub fast float 1.000000e+00, %475
  %477 = fdiv fast float %476, %468
  br label %478

; <label>:478                                     ; preds = %473, %470
  %479 = phi float [ %472, %470 ], [ %477, %473 ]
  %480 = call float @dx.op.binary.f32(i32 36, float %452, float %18)  ; FMin(a,b)
  %481 = fsub fast float %480, %10
  %482 = fmul fast float %11, %481
  %483 = fsub fast float -0.000000e+00, %482
  %484 = call float @dx.op.binary.f32(i32 35, float %483, float -4.000000e+01)  ; FMax(a,b)
  %485 = call float @dx.op.binary.f32(i32 36, float %484, float 5.000000e+00)  ; FMin(a,b)
  %486 = fmul fast float %485, 0x3FF7154760000000
  %487 = call float @dx.op.unary.f32(i32 21, float %486)  ; Exp(value)
  %488 = fmul fast float %487, %479
  br label %489

; <label>:489                                     ; preds = %478, %438
  %490 = phi float [ %488, %478 ], [ 1.000000e+00, %438 ]
  %491 = fmul fast float %464, %16
  %492 = fmul fast float %491, %490
  %493 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %492)  ; FMin(a,b)
  %494 = fmul fast float %493, 0xBFF7154760000000
  %495 = call float @dx.op.unary.f32(i32 21, float %494)  ; Exp(value)
  %496 = fsub fast float 1.000000e+00, %495
  %497 = call float @dx.op.binary.f32(i32 36, float %12, float %496)  ; FMin(a,b)
  %498 = fsub fast float %13, %410
  %499 = fsub fast float %14, %411
  %500 = fsub fast float %15, %412
  %501 = fmul fast float %497, %498
  %502 = fmul fast float %497, %499
  %503 = fmul fast float %497, %500
  %504 = fadd fast float %501, %410
  %505 = fadd fast float %502, %411
  %506 = fadd fast float %503, %412
  br label %507

; <label>:507                                     ; preds = %489, %421, %417
  %508 = phi float [ %504, %489 ], [ %410, %421 ], [ %410, %417 ]
  %509 = phi float [ %505, %489 ], [ %411, %421 ], [ %411, %417 ]
  %510 = phi float [ %506, %489 ], [ %412, %421 ], [ %412, %417 ]
  %511 = fadd fast float %5, 1.000000e+00
  %512 = fadd fast float %6, 1.000000e+00
  %513 = fsub fast float 1.000000e+00, %5
  %514 = fmul fast float %36, %511
  %515 = fmul fast float %36, %512
  %516 = fmul fast float %36, %513
  %517 = fmul fast float %514, %508
  %518 = fmul fast float %515, %509
  %519 = fmul fast float %516, %510
  %520 = fcmp fast ult float %37, 5.000000e-01
  br i1 %520, label %546, label %521

; <label>:521                                     ; preds = %507
  %522 = fmul fast float %517, 0x4004147AE0000000
  %523 = fmul fast float %518, 0x4004147AE0000000
  %524 = fmul fast float %519, 0x4004147AE0000000
  %525 = fadd fast float %522, 0x3F9EB851E0000000
  %526 = fadd fast float %523, 0x3F9EB851E0000000
  %527 = fadd fast float %524, 0x3F9EB851E0000000
  %528 = fmul fast float %525, %517
  %529 = fmul fast float %526, %518
  %530 = fmul fast float %527, %519
  %531 = fmul fast float %517, 0x400370A3E0000000
  %532 = fmul fast float %518, 0x400370A3E0000000
  %533 = fmul fast float %519, 0x400370A3E0000000
  %534 = fadd fast float %531, 0x3FE2E147A0000000
  %535 = fadd fast float %532, 0x3FE2E147A0000000
  %536 = fadd fast float %533, 0x3FE2E147A0000000
  %537 = fmul fast float %534, %517
  %538 = fmul fast float %535, %518
  %539 = fmul fast float %536, %519
  %540 = fadd fast float %537, 0x3FC1EB8520000000
  %541 = fadd fast float %538, 0x3FC1EB8520000000
  %542 = fadd fast float %539, 0x3FC1EB8520000000
  %543 = fdiv fast float %528, %540
  %544 = fdiv fast float %529, %541
  %545 = fdiv fast float %530, %542
  br label %546

; <label>:546                                     ; preds = %521, %507
  %547 = phi float [ %543, %521 ], [ %517, %507 ]
  %548 = phi float [ %544, %521 ], [ %518, %507 ]
  %549 = phi float [ %545, %521 ], [ %519, %507 ]
  %550 = call float @dx.op.unary.f32(i32 7, float %547)  ; Saturate(value)
  %551 = call float @dx.op.unary.f32(i32 7, float %548)  ; Saturate(value)
  %552 = call float @dx.op.unary.f32(i32 7, float %549)  ; Saturate(value)
  %553 = call float @dx.op.dot3.f32(i32 55, float %550, float %551, float %552, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %554 = fsub fast float %550, %553
  %555 = fsub fast float %551, %553
  %556 = fsub fast float %552, %553
  %557 = fmul fast float %554, %8
  %558 = fmul fast float %555, %8
  %559 = fmul fast float %556, %8
  %560 = fadd fast float %557, %553
  %561 = fadd fast float %558, %553
  %562 = fadd fast float %559, %553
  %563 = call float @dx.op.unary.f32(i32 7, float %560)  ; Saturate(value)
  %564 = call float @dx.op.unary.f32(i32 7, float %561)  ; Saturate(value)
  %565 = call float @dx.op.unary.f32(i32 7, float %562)  ; Saturate(value)
  %566 = fadd fast float %563, 0xBFC70A3D80000000
  %567 = fadd fast float %564, 0xBFC70A3D80000000
  %568 = fadd fast float %565, 0xBFC70A3D80000000
  %569 = fmul fast float %566, %7
  %570 = fmul fast float %567, %7
  %571 = fmul fast float %568, %7
  %572 = fadd fast float %569, 0x3FC70A3D80000000
  %573 = fadd fast float %570, 0x3FC70A3D80000000
  %574 = fadd fast float %571, 0x3FC70A3D80000000
  %575 = call float @dx.op.unary.f32(i32 7, float %572)  ; Saturate(value)
  %576 = call float @dx.op.unary.f32(i32 7, float %573)  ; Saturate(value)
  %577 = call float @dx.op.unary.f32(i32 7, float %574)  ; Saturate(value)
  %578 = fcmp fast ogt float %575, 0x3F69A5C380000000
  %579 = fcmp fast ogt float %576, 0x3F69A5C380000000
  %580 = fcmp fast ogt float %577, 0x3F69A5C380000000
  %581 = select i1 %578, float 0.000000e+00, float 1.000000e+00
  %582 = select i1 %579, float 0.000000e+00, float 1.000000e+00
  %583 = select i1 %580, float 0.000000e+00, float 1.000000e+00
  %584 = fmul fast float %575, 0x4029D70A40000000
  %585 = fmul fast float %576, 0x4029D70A40000000
  %586 = fmul fast float %577, 0x4029D70A40000000
  %587 = call float @dx.op.binary.f32(i32 35, float %575, float 0.000000e+00)  ; FMax(a,b)
  %588 = call float @dx.op.binary.f32(i32 35, float %576, float 0.000000e+00)  ; FMax(a,b)
  %589 = call float @dx.op.binary.f32(i32 35, float %577, float 0.000000e+00)  ; FMax(a,b)
  %590 = call float @dx.op.unary.f32(i32 23, float %587)  ; Log(value)
  %591 = call float @dx.op.unary.f32(i32 23, float %588)  ; Log(value)
  %592 = call float @dx.op.unary.f32(i32 23, float %589)  ; Log(value)
  %593 = fmul fast float %590, 0x3FDAAAAAA0000000
  %594 = fmul fast float %591, 0x3FDAAAAAA0000000
  %595 = fmul fast float %592, 0x3FDAAAAAA0000000
  %596 = call float @dx.op.unary.f32(i32 21, float %593)  ; Exp(value)
  %597 = call float @dx.op.unary.f32(i32 21, float %594)  ; Exp(value)
  %598 = call float @dx.op.unary.f32(i32 21, float %595)  ; Exp(value)
  %599 = fmul fast float %596, 0x3FF0E147A0000000
  %600 = fmul fast float %597, 0x3FF0E147A0000000
  %601 = fmul fast float %598, 0x3FF0E147A0000000
  %602 = fadd fast float %599, 0xBFAC28F5C0000000
  %603 = fadd fast float %600, 0xBFAC28F5C0000000
  %604 = fadd fast float %601, 0xBFAC28F5C0000000
  %605 = fsub fast float %584, %602
  %606 = fsub fast float %585, %603
  %607 = fsub fast float %586, %604
  %608 = fmul fast float %605, %581
  %609 = fmul fast float %606, %582
  %610 = fmul fast float %607, %583
  %611 = fadd fast float %608, %602
  %612 = fadd fast float %609, %603
  %613 = fadd fast float %610, %604
  br label %614

; <label>:614                                     ; preds = %546, %415
  %615 = phi float [ %410, %415 ], [ %611, %546 ]
  %616 = phi float [ %411, %415 ], [ %612, %546 ]
  %617 = phi float [ %412, %415 ], [ %613, %546 ]
  %618 = phi float [ %416, %415 ], [ %413, %546 ]
  %619 = fcmp fast ogt float %615, 0x3FA4B5DCC0000000
  %620 = fcmp fast ogt float %616, 0x3FA4B5DCC0000000
  %621 = fcmp fast ogt float %617, 0x3FA4B5DCC0000000
  %622 = select i1 %619, float 0.000000e+00, float 1.000000e+00
  %623 = select i1 %620, float 0.000000e+00, float 1.000000e+00
  %624 = select i1 %621, float 0.000000e+00, float 1.000000e+00
  %625 = fmul fast float %615, 0x3FB3D07220000000
  %626 = fmul fast float %616, 0x3FB3D07220000000
  %627 = fmul fast float %617, 0x3FB3D07220000000
  %628 = fadd fast float %615, 0x3FAC28F5C0000000
  %629 = fadd fast float %616, 0x3FAC28F5C0000000
  %630 = fadd fast float %617, 0x3FAC28F5C0000000
  %631 = fmul fast float %628, 0x3FEE54EDE0000000
  %632 = fmul fast float %629, 0x3FEE54EDE0000000
  %633 = fmul fast float %630, 0x3FEE54EDE0000000
  %634 = call float @dx.op.unary.f32(i32 23, float %631)  ; Log(value)
  %635 = call float @dx.op.unary.f32(i32 23, float %632)  ; Log(value)
  %636 = call float @dx.op.unary.f32(i32 23, float %633)  ; Log(value)
  %637 = fmul fast float %634, 0x4003333340000000
  %638 = fmul fast float %635, 0x4003333340000000
  %639 = fmul fast float %636, 0x4003333340000000
  %640 = call float @dx.op.unary.f32(i32 21, float %637)  ; Exp(value)
  %641 = call float @dx.op.unary.f32(i32 21, float %638)  ; Exp(value)
  %642 = call float @dx.op.unary.f32(i32 21, float %639)  ; Exp(value)
  %643 = fsub fast float %625, %640
  %644 = fsub fast float %626, %641
  %645 = fsub fast float %627, %642
  %646 = fmul fast float %643, %622
  %647 = fmul fast float %644, %623
  %648 = fmul fast float %645, %624
  %649 = fadd fast float %646, %640
  %650 = fadd fast float %647, %641
  %651 = fadd fast float %648, %642
  %652 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %63, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %653 = extractvalue %dx.types.ResRet.f32 %652, 0
  %654 = extractvalue %dx.types.ResRet.f32 %652, 1
  %655 = extractvalue %dx.types.ResRet.f32 %652, 2
  %656 = extractvalue %dx.types.ResRet.f32 %652, 3
  %657 = fcmp fast olt float %656, 0.000000e+00
  br i1 %657, label %658, label %660

; <label>:658                                     ; preds = %614
  %659 = fsub fast float -1.000000e+00, %656
  br label %857

; <label>:660                                     ; preds = %614
  %661 = fcmp fast ogt float %38, 5.000000e-01
  %662 = fcmp fast olt float %86, 1.000000e+00
  %663 = and i1 %661, %662
  br i1 %663, label %664, label %750

; <label>:664                                     ; preds = %660
  %665 = sitofp i32 %63 to float
  %666 = sitofp i32 %70 to float
  %667 = fadd fast float %665, 5.000000e-01
  %668 = fadd fast float %666, 5.000000e-01
  %669 = fdiv fast float %667, %45
  %670 = fdiv fast float %668, %46
  %671 = fmul fast float %669, 2.000000e+00
  %672 = fmul fast float %670, 2.000000e+00
  %673 = fadd fast float %671, -1.000000e+00
  %674 = fsub fast float 1.000000e+00, %672
  %675 = fmul fast float %673, %35
  %676 = call float @dx.op.tertiary.f32(i32 46, float %674, float %31, float %675)  ; FMad(a,b,c)
  %677 = call float @dx.op.tertiary.f32(i32 46, float %86, float %27, float %676)  ; FMad(a,b,c)
  %678 = fadd fast float %677, %23
  %679 = call float @dx.op.unary.f32(i32 6, float %678)  ; FAbs(value)
  %680 = fcmp fast ogt float %679, 0x3EB0C6F7A0000000
  br i1 %680, label %681, label %750

; <label>:681                                     ; preds = %664
  %682 = fmul fast float %673, %34
  %683 = call float @dx.op.tertiary.f32(i32 46, float %674, float %30, float %682)  ; FMad(a,b,c)
  %684 = call float @dx.op.tertiary.f32(i32 46, float %86, float %26, float %683)  ; FMad(a,b,c)
  %685 = fadd fast float %684, %22
  %686 = fmul fast float %673, %33
  %687 = call float @dx.op.tertiary.f32(i32 46, float %674, float %29, float %686)  ; FMad(a,b,c)
  %688 = call float @dx.op.tertiary.f32(i32 46, float %86, float %25, float %687)  ; FMad(a,b,c)
  %689 = fadd fast float %688, %21
  %690 = fmul fast float %673, %32
  %691 = call float @dx.op.tertiary.f32(i32 46, float %674, float %28, float %690)  ; FMad(a,b,c)
  %692 = call float @dx.op.tertiary.f32(i32 46, float %86, float %24, float %691)  ; FMad(a,b,c)
  %693 = fadd fast float %692, %20
  %694 = fdiv fast float %693, %678
  %695 = fdiv fast float %689, %678
  %696 = fdiv fast float %685, %678
  %697 = fsub fast float %694, %17
  %698 = fsub fast float %695, %18
  %699 = fsub fast float %696, %19
  %700 = fmul fast float %697, %697
  %701 = fmul fast float %698, %698
  %702 = fadd fast float %701, %700
  %703 = fmul fast float %699, %699
  %704 = fadd fast float %702, %703
  %705 = call float @dx.op.unary.f32(i32 24, float %704)  ; Sqrt(value)
  %706 = fsub fast float %705, %9
  %707 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %706)  ; FMax(a,b)
  %708 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %708, label %709, label %732

; <label>:709                                     ; preds = %681
  %710 = call float @dx.op.unary.f32(i32 6, float %698)  ; FAbs(value)
  %711 = fmul fast float %710, %11
  %712 = fcmp fast olt float %711, 0x3F50624DE0000000
  br i1 %712, label %713, label %716

; <label>:713                                     ; preds = %709
  %714 = fmul fast float %711, 5.000000e-01
  %715 = fsub fast float 1.000000e+00, %714
  br label %721

; <label>:716                                     ; preds = %709
  %717 = fmul fast float %711, 0xBFF7154760000000
  %718 = call float @dx.op.unary.f32(i32 21, float %717)  ; Exp(value)
  %719 = fsub fast float 1.000000e+00, %718
  %720 = fdiv fast float %719, %711
  br label %721

; <label>:721                                     ; preds = %716, %713
  %722 = phi float [ %715, %713 ], [ %720, %716 ]
  %723 = call float @dx.op.binary.f32(i32 36, float %695, float %18)  ; FMin(a,b)
  %724 = fsub fast float %723, %10
  %725 = fmul fast float %11, %724
  %726 = fsub fast float -0.000000e+00, %725
  %727 = call float @dx.op.binary.f32(i32 35, float %726, float -4.000000e+01)  ; FMax(a,b)
  %728 = call float @dx.op.binary.f32(i32 36, float %727, float 5.000000e+00)  ; FMin(a,b)
  %729 = fmul fast float %728, 0x3FF7154760000000
  %730 = call float @dx.op.unary.f32(i32 21, float %729)  ; Exp(value)
  %731 = fmul fast float %730, %722
  br label %732

; <label>:732                                     ; preds = %721, %681
  %733 = phi float [ %731, %721 ], [ 1.000000e+00, %681 ]
  %734 = fmul fast float %707, %16
  %735 = fmul fast float %734, %733
  %736 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %735)  ; FMin(a,b)
  %737 = fmul fast float %736, 0xBFF7154760000000
  %738 = call float @dx.op.unary.f32(i32 21, float %737)  ; Exp(value)
  %739 = fsub fast float 1.000000e+00, %738
  %740 = call float @dx.op.binary.f32(i32 36, float %12, float %739)  ; FMin(a,b)
  %741 = fsub fast float %13, %653
  %742 = fsub fast float %14, %654
  %743 = fsub fast float %15, %655
  %744 = fmul fast float %740, %741
  %745 = fmul fast float %740, %742
  %746 = fmul fast float %740, %743
  %747 = fadd fast float %744, %653
  %748 = fadd fast float %745, %654
  %749 = fadd fast float %746, %655
  br label %750

; <label>:750                                     ; preds = %732, %664, %660
  %751 = phi float [ %747, %732 ], [ %653, %664 ], [ %653, %660 ]
  %752 = phi float [ %748, %732 ], [ %654, %664 ], [ %654, %660 ]
  %753 = phi float [ %749, %732 ], [ %655, %664 ], [ %655, %660 ]
  %754 = fadd fast float %5, 1.000000e+00
  %755 = fadd fast float %6, 1.000000e+00
  %756 = fsub fast float 1.000000e+00, %5
  %757 = fmul fast float %36, %754
  %758 = fmul fast float %36, %755
  %759 = fmul fast float %36, %756
  %760 = fmul fast float %757, %751
  %761 = fmul fast float %758, %752
  %762 = fmul fast float %759, %753
  %763 = fcmp fast ult float %37, 5.000000e-01
  br i1 %763, label %789, label %764

; <label>:764                                     ; preds = %750
  %765 = fmul fast float %760, 0x4004147AE0000000
  %766 = fmul fast float %761, 0x4004147AE0000000
  %767 = fmul fast float %762, 0x4004147AE0000000
  %768 = fadd fast float %765, 0x3F9EB851E0000000
  %769 = fadd fast float %766, 0x3F9EB851E0000000
  %770 = fadd fast float %767, 0x3F9EB851E0000000
  %771 = fmul fast float %768, %760
  %772 = fmul fast float %769, %761
  %773 = fmul fast float %770, %762
  %774 = fmul fast float %760, 0x400370A3E0000000
  %775 = fmul fast float %761, 0x400370A3E0000000
  %776 = fmul fast float %762, 0x400370A3E0000000
  %777 = fadd fast float %774, 0x3FE2E147A0000000
  %778 = fadd fast float %775, 0x3FE2E147A0000000
  %779 = fadd fast float %776, 0x3FE2E147A0000000
  %780 = fmul fast float %777, %760
  %781 = fmul fast float %778, %761
  %782 = fmul fast float %779, %762
  %783 = fadd fast float %780, 0x3FC1EB8520000000
  %784 = fadd fast float %781, 0x3FC1EB8520000000
  %785 = fadd fast float %782, 0x3FC1EB8520000000
  %786 = fdiv fast float %771, %783
  %787 = fdiv fast float %772, %784
  %788 = fdiv fast float %773, %785
  br label %789

; <label>:789                                     ; preds = %764, %750
  %790 = phi float [ %786, %764 ], [ %760, %750 ]
  %791 = phi float [ %787, %764 ], [ %761, %750 ]
  %792 = phi float [ %788, %764 ], [ %762, %750 ]
  %793 = call float @dx.op.unary.f32(i32 7, float %790)  ; Saturate(value)
  %794 = call float @dx.op.unary.f32(i32 7, float %791)  ; Saturate(value)
  %795 = call float @dx.op.unary.f32(i32 7, float %792)  ; Saturate(value)
  %796 = call float @dx.op.dot3.f32(i32 55, float %793, float %794, float %795, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %797 = fsub fast float %793, %796
  %798 = fsub fast float %794, %796
  %799 = fsub fast float %795, %796
  %800 = fmul fast float %797, %8
  %801 = fmul fast float %798, %8
  %802 = fmul fast float %799, %8
  %803 = fadd fast float %800, %796
  %804 = fadd fast float %801, %796
  %805 = fadd fast float %802, %796
  %806 = call float @dx.op.unary.f32(i32 7, float %803)  ; Saturate(value)
  %807 = call float @dx.op.unary.f32(i32 7, float %804)  ; Saturate(value)
  %808 = call float @dx.op.unary.f32(i32 7, float %805)  ; Saturate(value)
  %809 = fadd fast float %806, 0xBFC70A3D80000000
  %810 = fadd fast float %807, 0xBFC70A3D80000000
  %811 = fadd fast float %808, 0xBFC70A3D80000000
  %812 = fmul fast float %809, %7
  %813 = fmul fast float %810, %7
  %814 = fmul fast float %811, %7
  %815 = fadd fast float %812, 0x3FC70A3D80000000
  %816 = fadd fast float %813, 0x3FC70A3D80000000
  %817 = fadd fast float %814, 0x3FC70A3D80000000
  %818 = call float @dx.op.unary.f32(i32 7, float %815)  ; Saturate(value)
  %819 = call float @dx.op.unary.f32(i32 7, float %816)  ; Saturate(value)
  %820 = call float @dx.op.unary.f32(i32 7, float %817)  ; Saturate(value)
  %821 = fcmp fast ogt float %818, 0x3F69A5C380000000
  %822 = fcmp fast ogt float %819, 0x3F69A5C380000000
  %823 = fcmp fast ogt float %820, 0x3F69A5C380000000
  %824 = select i1 %821, float 0.000000e+00, float 1.000000e+00
  %825 = select i1 %822, float 0.000000e+00, float 1.000000e+00
  %826 = select i1 %823, float 0.000000e+00, float 1.000000e+00
  %827 = fmul fast float %818, 0x4029D70A40000000
  %828 = fmul fast float %819, 0x4029D70A40000000
  %829 = fmul fast float %820, 0x4029D70A40000000
  %830 = call float @dx.op.binary.f32(i32 35, float %818, float 0.000000e+00)  ; FMax(a,b)
  %831 = call float @dx.op.binary.f32(i32 35, float %819, float 0.000000e+00)  ; FMax(a,b)
  %832 = call float @dx.op.binary.f32(i32 35, float %820, float 0.000000e+00)  ; FMax(a,b)
  %833 = call float @dx.op.unary.f32(i32 23, float %830)  ; Log(value)
  %834 = call float @dx.op.unary.f32(i32 23, float %831)  ; Log(value)
  %835 = call float @dx.op.unary.f32(i32 23, float %832)  ; Log(value)
  %836 = fmul fast float %833, 0x3FDAAAAAA0000000
  %837 = fmul fast float %834, 0x3FDAAAAAA0000000
  %838 = fmul fast float %835, 0x3FDAAAAAA0000000
  %839 = call float @dx.op.unary.f32(i32 21, float %836)  ; Exp(value)
  %840 = call float @dx.op.unary.f32(i32 21, float %837)  ; Exp(value)
  %841 = call float @dx.op.unary.f32(i32 21, float %838)  ; Exp(value)
  %842 = fmul fast float %839, 0x3FF0E147A0000000
  %843 = fmul fast float %840, 0x3FF0E147A0000000
  %844 = fmul fast float %841, 0x3FF0E147A0000000
  %845 = fadd fast float %842, 0xBFAC28F5C0000000
  %846 = fadd fast float %843, 0xBFAC28F5C0000000
  %847 = fadd fast float %844, 0xBFAC28F5C0000000
  %848 = fsub fast float %827, %845
  %849 = fsub fast float %828, %846
  %850 = fsub fast float %829, %847
  %851 = fmul fast float %848, %824
  %852 = fmul fast float %849, %825
  %853 = fmul fast float %850, %826
  %854 = fadd fast float %851, %845
  %855 = fadd fast float %852, %846
  %856 = fadd fast float %853, %847
  br label %857

; <label>:857                                     ; preds = %789, %658
  %858 = phi float [ %653, %658 ], [ %854, %789 ]
  %859 = phi float [ %654, %658 ], [ %855, %789 ]
  %860 = phi float [ %655, %658 ], [ %856, %789 ]
  %861 = phi float [ %659, %658 ], [ %656, %789 ]
  %862 = fcmp fast ogt float %858, 0x3FA4B5DCC0000000
  %863 = fcmp fast ogt float %859, 0x3FA4B5DCC0000000
  %864 = fcmp fast ogt float %860, 0x3FA4B5DCC0000000
  %865 = select i1 %862, float 0.000000e+00, float 1.000000e+00
  %866 = select i1 %863, float 0.000000e+00, float 1.000000e+00
  %867 = select i1 %864, float 0.000000e+00, float 1.000000e+00
  %868 = fmul fast float %858, 0x3FB3D07220000000
  %869 = fmul fast float %859, 0x3FB3D07220000000
  %870 = fmul fast float %860, 0x3FB3D07220000000
  %871 = fadd fast float %858, 0x3FAC28F5C0000000
  %872 = fadd fast float %859, 0x3FAC28F5C0000000
  %873 = fadd fast float %860, 0x3FAC28F5C0000000
  %874 = fmul fast float %871, 0x3FEE54EDE0000000
  %875 = fmul fast float %872, 0x3FEE54EDE0000000
  %876 = fmul fast float %873, 0x3FEE54EDE0000000
  %877 = call float @dx.op.unary.f32(i32 23, float %874)  ; Log(value)
  %878 = call float @dx.op.unary.f32(i32 23, float %875)  ; Log(value)
  %879 = call float @dx.op.unary.f32(i32 23, float %876)  ; Log(value)
  %880 = fmul fast float %877, 0x4003333340000000
  %881 = fmul fast float %878, 0x4003333340000000
  %882 = fmul fast float %879, 0x4003333340000000
  %883 = call float @dx.op.unary.f32(i32 21, float %880)  ; Exp(value)
  %884 = call float @dx.op.unary.f32(i32 21, float %881)  ; Exp(value)
  %885 = call float @dx.op.unary.f32(i32 21, float %882)  ; Exp(value)
  %886 = fsub fast float %868, %883
  %887 = fsub fast float %869, %884
  %888 = fsub fast float %870, %885
  %889 = fmul fast float %886, %865
  %890 = fmul fast float %887, %866
  %891 = fmul fast float %888, %867
  %892 = fadd fast float %889, %883
  %893 = fadd fast float %890, %884
  %894 = fadd fast float %891, %885
  %895 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %67, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %896 = extractvalue %dx.types.ResRet.f32 %895, 0
  %897 = extractvalue %dx.types.ResRet.f32 %895, 1
  %898 = extractvalue %dx.types.ResRet.f32 %895, 2
  %899 = extractvalue %dx.types.ResRet.f32 %895, 3
  %900 = fcmp fast olt float %899, 0.000000e+00
  br i1 %900, label %901, label %903

; <label>:901                                     ; preds = %857
  %902 = fsub fast float -1.000000e+00, %899
  br label %1100

; <label>:903                                     ; preds = %857
  %904 = fcmp fast ogt float %38, 5.000000e-01
  %905 = fcmp fast olt float %88, 1.000000e+00
  %906 = and i1 %904, %905
  br i1 %906, label %907, label %993

; <label>:907                                     ; preds = %903
  %908 = sitofp i32 %67 to float
  %909 = sitofp i32 %70 to float
  %910 = fadd fast float %908, 5.000000e-01
  %911 = fadd fast float %909, 5.000000e-01
  %912 = fdiv fast float %910, %45
  %913 = fdiv fast float %911, %46
  %914 = fmul fast float %912, 2.000000e+00
  %915 = fmul fast float %913, 2.000000e+00
  %916 = fadd fast float %914, -1.000000e+00
  %917 = fsub fast float 1.000000e+00, %915
  %918 = fmul fast float %916, %35
  %919 = call float @dx.op.tertiary.f32(i32 46, float %917, float %31, float %918)  ; FMad(a,b,c)
  %920 = call float @dx.op.tertiary.f32(i32 46, float %88, float %27, float %919)  ; FMad(a,b,c)
  %921 = fadd fast float %920, %23
  %922 = call float @dx.op.unary.f32(i32 6, float %921)  ; FAbs(value)
  %923 = fcmp fast ogt float %922, 0x3EB0C6F7A0000000
  br i1 %923, label %924, label %993

; <label>:924                                     ; preds = %907
  %925 = fmul fast float %916, %34
  %926 = call float @dx.op.tertiary.f32(i32 46, float %917, float %30, float %925)  ; FMad(a,b,c)
  %927 = call float @dx.op.tertiary.f32(i32 46, float %88, float %26, float %926)  ; FMad(a,b,c)
  %928 = fadd fast float %927, %22
  %929 = fmul fast float %916, %33
  %930 = call float @dx.op.tertiary.f32(i32 46, float %917, float %29, float %929)  ; FMad(a,b,c)
  %931 = call float @dx.op.tertiary.f32(i32 46, float %88, float %25, float %930)  ; FMad(a,b,c)
  %932 = fadd fast float %931, %21
  %933 = fmul fast float %916, %32
  %934 = call float @dx.op.tertiary.f32(i32 46, float %917, float %28, float %933)  ; FMad(a,b,c)
  %935 = call float @dx.op.tertiary.f32(i32 46, float %88, float %24, float %934)  ; FMad(a,b,c)
  %936 = fadd fast float %935, %20
  %937 = fdiv fast float %936, %921
  %938 = fdiv fast float %932, %921
  %939 = fdiv fast float %928, %921
  %940 = fsub fast float %937, %17
  %941 = fsub fast float %938, %18
  %942 = fsub fast float %939, %19
  %943 = fmul fast float %940, %940
  %944 = fmul fast float %941, %941
  %945 = fadd fast float %944, %943
  %946 = fmul fast float %942, %942
  %947 = fadd fast float %945, %946
  %948 = call float @dx.op.unary.f32(i32 24, float %947)  ; Sqrt(value)
  %949 = fsub fast float %948, %9
  %950 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %949)  ; FMax(a,b)
  %951 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %951, label %952, label %975

; <label>:952                                     ; preds = %924
  %953 = call float @dx.op.unary.f32(i32 6, float %941)  ; FAbs(value)
  %954 = fmul fast float %953, %11
  %955 = fcmp fast olt float %954, 0x3F50624DE0000000
  br i1 %955, label %956, label %959

; <label>:956                                     ; preds = %952
  %957 = fmul fast float %954, 5.000000e-01
  %958 = fsub fast float 1.000000e+00, %957
  br label %964

; <label>:959                                     ; preds = %952
  %960 = fmul fast float %954, 0xBFF7154760000000
  %961 = call float @dx.op.unary.f32(i32 21, float %960)  ; Exp(value)
  %962 = fsub fast float 1.000000e+00, %961
  %963 = fdiv fast float %962, %954
  br label %964

; <label>:964                                     ; preds = %959, %956
  %965 = phi float [ %958, %956 ], [ %963, %959 ]
  %966 = call float @dx.op.binary.f32(i32 36, float %938, float %18)  ; FMin(a,b)
  %967 = fsub fast float %966, %10
  %968 = fmul fast float %11, %967
  %969 = fsub fast float -0.000000e+00, %968
  %970 = call float @dx.op.binary.f32(i32 35, float %969, float -4.000000e+01)  ; FMax(a,b)
  %971 = call float @dx.op.binary.f32(i32 36, float %970, float 5.000000e+00)  ; FMin(a,b)
  %972 = fmul fast float %971, 0x3FF7154760000000
  %973 = call float @dx.op.unary.f32(i32 21, float %972)  ; Exp(value)
  %974 = fmul fast float %973, %965
  br label %975

; <label>:975                                     ; preds = %964, %924
  %976 = phi float [ %974, %964 ], [ 1.000000e+00, %924 ]
  %977 = fmul fast float %950, %16
  %978 = fmul fast float %977, %976
  %979 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %978)  ; FMin(a,b)
  %980 = fmul fast float %979, 0xBFF7154760000000
  %981 = call float @dx.op.unary.f32(i32 21, float %980)  ; Exp(value)
  %982 = fsub fast float 1.000000e+00, %981
  %983 = call float @dx.op.binary.f32(i32 36, float %12, float %982)  ; FMin(a,b)
  %984 = fsub fast float %13, %896
  %985 = fsub fast float %14, %897
  %986 = fsub fast float %15, %898
  %987 = fmul fast float %983, %984
  %988 = fmul fast float %983, %985
  %989 = fmul fast float %983, %986
  %990 = fadd fast float %987, %896
  %991 = fadd fast float %988, %897
  %992 = fadd fast float %989, %898
  br label %993

; <label>:993                                     ; preds = %975, %907, %903
  %994 = phi float [ %990, %975 ], [ %896, %907 ], [ %896, %903 ]
  %995 = phi float [ %991, %975 ], [ %897, %907 ], [ %897, %903 ]
  %996 = phi float [ %992, %975 ], [ %898, %907 ], [ %898, %903 ]
  %997 = fadd fast float %5, 1.000000e+00
  %998 = fadd fast float %6, 1.000000e+00
  %999 = fsub fast float 1.000000e+00, %5
  %1000 = fmul fast float %36, %997
  %1001 = fmul fast float %36, %998
  %1002 = fmul fast float %36, %999
  %1003 = fmul fast float %1000, %994
  %1004 = fmul fast float %1001, %995
  %1005 = fmul fast float %1002, %996
  %1006 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1006, label %1032, label %1007

; <label>:1007                                    ; preds = %993
  %1008 = fmul fast float %1003, 0x4004147AE0000000
  %1009 = fmul fast float %1004, 0x4004147AE0000000
  %1010 = fmul fast float %1005, 0x4004147AE0000000
  %1011 = fadd fast float %1008, 0x3F9EB851E0000000
  %1012 = fadd fast float %1009, 0x3F9EB851E0000000
  %1013 = fadd fast float %1010, 0x3F9EB851E0000000
  %1014 = fmul fast float %1011, %1003
  %1015 = fmul fast float %1012, %1004
  %1016 = fmul fast float %1013, %1005
  %1017 = fmul fast float %1003, 0x400370A3E0000000
  %1018 = fmul fast float %1004, 0x400370A3E0000000
  %1019 = fmul fast float %1005, 0x400370A3E0000000
  %1020 = fadd fast float %1017, 0x3FE2E147A0000000
  %1021 = fadd fast float %1018, 0x3FE2E147A0000000
  %1022 = fadd fast float %1019, 0x3FE2E147A0000000
  %1023 = fmul fast float %1020, %1003
  %1024 = fmul fast float %1021, %1004
  %1025 = fmul fast float %1022, %1005
  %1026 = fadd fast float %1023, 0x3FC1EB8520000000
  %1027 = fadd fast float %1024, 0x3FC1EB8520000000
  %1028 = fadd fast float %1025, 0x3FC1EB8520000000
  %1029 = fdiv fast float %1014, %1026
  %1030 = fdiv fast float %1015, %1027
  %1031 = fdiv fast float %1016, %1028
  br label %1032

; <label>:1032                                    ; preds = %1007, %993
  %1033 = phi float [ %1029, %1007 ], [ %1003, %993 ]
  %1034 = phi float [ %1030, %1007 ], [ %1004, %993 ]
  %1035 = phi float [ %1031, %1007 ], [ %1005, %993 ]
  %1036 = call float @dx.op.unary.f32(i32 7, float %1033)  ; Saturate(value)
  %1037 = call float @dx.op.unary.f32(i32 7, float %1034)  ; Saturate(value)
  %1038 = call float @dx.op.unary.f32(i32 7, float %1035)  ; Saturate(value)
  %1039 = call float @dx.op.dot3.f32(i32 55, float %1036, float %1037, float %1038, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1040 = fsub fast float %1036, %1039
  %1041 = fsub fast float %1037, %1039
  %1042 = fsub fast float %1038, %1039
  %1043 = fmul fast float %1040, %8
  %1044 = fmul fast float %1041, %8
  %1045 = fmul fast float %1042, %8
  %1046 = fadd fast float %1043, %1039
  %1047 = fadd fast float %1044, %1039
  %1048 = fadd fast float %1045, %1039
  %1049 = call float @dx.op.unary.f32(i32 7, float %1046)  ; Saturate(value)
  %1050 = call float @dx.op.unary.f32(i32 7, float %1047)  ; Saturate(value)
  %1051 = call float @dx.op.unary.f32(i32 7, float %1048)  ; Saturate(value)
  %1052 = fadd fast float %1049, 0xBFC70A3D80000000
  %1053 = fadd fast float %1050, 0xBFC70A3D80000000
  %1054 = fadd fast float %1051, 0xBFC70A3D80000000
  %1055 = fmul fast float %1052, %7
  %1056 = fmul fast float %1053, %7
  %1057 = fmul fast float %1054, %7
  %1058 = fadd fast float %1055, 0x3FC70A3D80000000
  %1059 = fadd fast float %1056, 0x3FC70A3D80000000
  %1060 = fadd fast float %1057, 0x3FC70A3D80000000
  %1061 = call float @dx.op.unary.f32(i32 7, float %1058)  ; Saturate(value)
  %1062 = call float @dx.op.unary.f32(i32 7, float %1059)  ; Saturate(value)
  %1063 = call float @dx.op.unary.f32(i32 7, float %1060)  ; Saturate(value)
  %1064 = fcmp fast ogt float %1061, 0x3F69A5C380000000
  %1065 = fcmp fast ogt float %1062, 0x3F69A5C380000000
  %1066 = fcmp fast ogt float %1063, 0x3F69A5C380000000
  %1067 = select i1 %1064, float 0.000000e+00, float 1.000000e+00
  %1068 = select i1 %1065, float 0.000000e+00, float 1.000000e+00
  %1069 = select i1 %1066, float 0.000000e+00, float 1.000000e+00
  %1070 = fmul fast float %1061, 0x4029D70A40000000
  %1071 = fmul fast float %1062, 0x4029D70A40000000
  %1072 = fmul fast float %1063, 0x4029D70A40000000
  %1073 = call float @dx.op.binary.f32(i32 35, float %1061, float 0.000000e+00)  ; FMax(a,b)
  %1074 = call float @dx.op.binary.f32(i32 35, float %1062, float 0.000000e+00)  ; FMax(a,b)
  %1075 = call float @dx.op.binary.f32(i32 35, float %1063, float 0.000000e+00)  ; FMax(a,b)
  %1076 = call float @dx.op.unary.f32(i32 23, float %1073)  ; Log(value)
  %1077 = call float @dx.op.unary.f32(i32 23, float %1074)  ; Log(value)
  %1078 = call float @dx.op.unary.f32(i32 23, float %1075)  ; Log(value)
  %1079 = fmul fast float %1076, 0x3FDAAAAAA0000000
  %1080 = fmul fast float %1077, 0x3FDAAAAAA0000000
  %1081 = fmul fast float %1078, 0x3FDAAAAAA0000000
  %1082 = call float @dx.op.unary.f32(i32 21, float %1079)  ; Exp(value)
  %1083 = call float @dx.op.unary.f32(i32 21, float %1080)  ; Exp(value)
  %1084 = call float @dx.op.unary.f32(i32 21, float %1081)  ; Exp(value)
  %1085 = fmul fast float %1082, 0x3FF0E147A0000000
  %1086 = fmul fast float %1083, 0x3FF0E147A0000000
  %1087 = fmul fast float %1084, 0x3FF0E147A0000000
  %1088 = fadd fast float %1085, 0xBFAC28F5C0000000
  %1089 = fadd fast float %1086, 0xBFAC28F5C0000000
  %1090 = fadd fast float %1087, 0xBFAC28F5C0000000
  %1091 = fsub fast float %1070, %1088
  %1092 = fsub fast float %1071, %1089
  %1093 = fsub fast float %1072, %1090
  %1094 = fmul fast float %1091, %1067
  %1095 = fmul fast float %1092, %1068
  %1096 = fmul fast float %1093, %1069
  %1097 = fadd fast float %1094, %1088
  %1098 = fadd fast float %1095, %1089
  %1099 = fadd fast float %1096, %1090
  br label %1100

; <label>:1100                                    ; preds = %1032, %901
  %1101 = phi float [ %896, %901 ], [ %1097, %1032 ]
  %1102 = phi float [ %897, %901 ], [ %1098, %1032 ]
  %1103 = phi float [ %898, %901 ], [ %1099, %1032 ]
  %1104 = phi float [ %902, %901 ], [ %899, %1032 ]
  %1105 = fcmp fast ogt float %1101, 0x3FA4B5DCC0000000
  %1106 = fcmp fast ogt float %1102, 0x3FA4B5DCC0000000
  %1107 = fcmp fast ogt float %1103, 0x3FA4B5DCC0000000
  %1108 = select i1 %1105, float 0.000000e+00, float 1.000000e+00
  %1109 = select i1 %1106, float 0.000000e+00, float 1.000000e+00
  %1110 = select i1 %1107, float 0.000000e+00, float 1.000000e+00
  %1111 = fmul fast float %1101, 0x3FB3D07220000000
  %1112 = fmul fast float %1102, 0x3FB3D07220000000
  %1113 = fmul fast float %1103, 0x3FB3D07220000000
  %1114 = fadd fast float %1101, 0x3FAC28F5C0000000
  %1115 = fadd fast float %1102, 0x3FAC28F5C0000000
  %1116 = fadd fast float %1103, 0x3FAC28F5C0000000
  %1117 = fmul fast float %1114, 0x3FEE54EDE0000000
  %1118 = fmul fast float %1115, 0x3FEE54EDE0000000
  %1119 = fmul fast float %1116, 0x3FEE54EDE0000000
  %1120 = call float @dx.op.unary.f32(i32 23, float %1117)  ; Log(value)
  %1121 = call float @dx.op.unary.f32(i32 23, float %1118)  ; Log(value)
  %1122 = call float @dx.op.unary.f32(i32 23, float %1119)  ; Log(value)
  %1123 = fmul fast float %1120, 0x4003333340000000
  %1124 = fmul fast float %1121, 0x4003333340000000
  %1125 = fmul fast float %1122, 0x4003333340000000
  %1126 = call float @dx.op.unary.f32(i32 21, float %1123)  ; Exp(value)
  %1127 = call float @dx.op.unary.f32(i32 21, float %1124)  ; Exp(value)
  %1128 = call float @dx.op.unary.f32(i32 21, float %1125)  ; Exp(value)
  %1129 = fsub fast float %1111, %1126
  %1130 = fsub fast float %1112, %1127
  %1131 = fsub fast float %1113, %1128
  %1132 = fmul fast float %1129, %1108
  %1133 = fmul fast float %1130, %1109
  %1134 = fmul fast float %1131, %1110
  %1135 = fadd fast float %1132, %1126
  %1136 = fadd fast float %1133, %1127
  %1137 = fadd fast float %1134, %1128
  %1138 = fmul fast float %406, %162
  %1139 = fmul fast float %407, %162
  %1140 = fmul fast float %408, %162
  %1141 = fmul fast float %649, %163
  %1142 = fmul fast float %650, %163
  %1143 = fmul fast float %651, %163
  %1144 = fadd fast float %1141, %1138
  %1145 = fadd fast float %1142, %1139
  %1146 = fadd fast float %1143, %1140
  %1147 = fmul fast float %892, %164
  %1148 = fmul fast float %893, %164
  %1149 = fmul fast float %894, %164
  %1150 = fadd fast float %1144, %1147
  %1151 = fadd fast float %1145, %1148
  %1152 = fadd fast float %1146, %1149
  %1153 = fmul fast float %1135, %165
  %1154 = fmul fast float %1136, %165
  %1155 = fmul fast float %1137, %165
  %1156 = fadd fast float %1150, %1153
  %1157 = fadd fast float %1151, %1154
  %1158 = fadd fast float %1152, %1155
  %1159 = fcmp fast ogt float %1156, 0x3F69A5C380000000
  %1160 = fcmp fast ogt float %1157, 0x3F69A5C380000000
  %1161 = fcmp fast ogt float %1158, 0x3F69A5C380000000
  %1162 = select i1 %1159, float 0.000000e+00, float 1.000000e+00
  %1163 = select i1 %1160, float 0.000000e+00, float 1.000000e+00
  %1164 = select i1 %1161, float 0.000000e+00, float 1.000000e+00
  %1165 = fmul fast float %1156, 0x4029D70A40000000
  %1166 = fmul fast float %1157, 0x4029D70A40000000
  %1167 = fmul fast float %1158, 0x4029D70A40000000
  %1168 = call float @dx.op.binary.f32(i32 35, float %1156, float 0.000000e+00)  ; FMax(a,b)
  %1169 = call float @dx.op.binary.f32(i32 35, float %1157, float 0.000000e+00)  ; FMax(a,b)
  %1170 = call float @dx.op.binary.f32(i32 35, float %1158, float 0.000000e+00)  ; FMax(a,b)
  %1171 = call float @dx.op.unary.f32(i32 23, float %1168)  ; Log(value)
  %1172 = call float @dx.op.unary.f32(i32 23, float %1169)  ; Log(value)
  %1173 = call float @dx.op.unary.f32(i32 23, float %1170)  ; Log(value)
  %1174 = fmul fast float %1171, 0x3FDAAAAAA0000000
  %1175 = fmul fast float %1172, 0x3FDAAAAAA0000000
  %1176 = fmul fast float %1173, 0x3FDAAAAAA0000000
  %1177 = call float @dx.op.unary.f32(i32 21, float %1174)  ; Exp(value)
  %1178 = call float @dx.op.unary.f32(i32 21, float %1175)  ; Exp(value)
  %1179 = call float @dx.op.unary.f32(i32 21, float %1176)  ; Exp(value)
  %1180 = fmul fast float %1177, 0x3FF0E147A0000000
  %1181 = fmul fast float %1178, 0x3FF0E147A0000000
  %1182 = fmul fast float %1179, 0x3FF0E147A0000000
  %1183 = fadd fast float %1180, 0xBFAC28F5C0000000
  %1184 = fadd fast float %1181, 0xBFAC28F5C0000000
  %1185 = fadd fast float %1182, 0xBFAC28F5C0000000
  %1186 = fsub fast float %1165, %1183
  %1187 = fsub fast float %1166, %1184
  %1188 = fsub fast float %1167, %1185
  %1189 = fmul fast float %1186, %1162
  %1190 = fmul fast float %1187, %1163
  %1191 = fmul fast float %1188, %1164
  %1192 = fadd fast float %1189, %1183
  %1193 = fadd fast float %1190, %1184
  %1194 = fadd fast float %1191, %1185
  %1195 = call float @dx.op.dot4.f32(i32 56, float %375, float %618, float %861, float %1104, float %162, float %163, float %164, float %165)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %1192)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %1193)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %1194)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %1195)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %80)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare i1 @dx.op.isSpecialFloat.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !38, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, !37}
!36 = !{i32 9}
!37 = !{i32 3, i32 6}
!38 = !{!39, !40}
!39 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
!40 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !41}
!41 = !{i32 3, i32 1}
