;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float    yz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: 9dad2ab70eab952cf3275dc5981d1c17
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %40 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %41 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %42 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %43 = extractvalue %dx.types.Dimensions %42, 0
  %44 = extractvalue %dx.types.Dimensions %42, 1
  %45 = uitofp i32 %43 to float
  %46 = uitofp i32 %44 to float
  %47 = fmul fast float %45, %40
  %48 = fmul fast float %46, %41
  %49 = fdiv fast float %47, %3
  %50 = fdiv fast float %48, %4
  %51 = fadd fast float %49, -5.000000e-01
  %52 = fadd fast float %50, -5.000000e-01
  %53 = call float @dx.op.unary.f32(i32 27, float %51)  ; Round_ni(value)
  %54 = call float @dx.op.unary.f32(i32 27, float %52)  ; Round_ni(value)
  %55 = fptosi float %53 to i32
  %56 = fptosi float %54 to i32
  %57 = call float @dx.op.unary.f32(i32 22, float %51)  ; Frc(value)
  %58 = call float @dx.op.unary.f32(i32 22, float %52)  ; Frc(value)
  %59 = add i32 %43, -1
  %60 = add i32 %44, -1
  %61 = call i32 @dx.op.binary.i32(i32 37, i32 %55, i32 0)  ; IMax(a,b)
  %62 = call i32 @dx.op.binary.i32(i32 37, i32 %56, i32 0)  ; IMax(a,b)
  %63 = call i32 @dx.op.binary.i32(i32 38, i32 %61, i32 %59)  ; IMin(a,b)
  %64 = call i32 @dx.op.binary.i32(i32 38, i32 %62, i32 %60)  ; IMin(a,b)
  %65 = add i32 %55, 1
  %66 = call i32 @dx.op.binary.i32(i32 37, i32 %65, i32 0)  ; IMax(a,b)
  %67 = call i32 @dx.op.binary.i32(i32 38, i32 %66, i32 %59)  ; IMin(a,b)
  %68 = add i32 %56, 1
  %69 = call i32 @dx.op.binary.i32(i32 37, i32 %68, i32 0)  ; IMax(a,b)
  %70 = call i32 @dx.op.binary.i32(i32 38, i32 %69, i32 %60)  ; IMin(a,b)
  %71 = call float @dx.op.unary.f32(i32 27, float %49)  ; Round_ni(value)
  %72 = call float @dx.op.unary.f32(i32 27, float %50)  ; Round_ni(value)
  %73 = fptosi float %71 to i32
  %74 = fptosi float %72 to i32
  %75 = call i32 @dx.op.binary.i32(i32 37, i32 %73, i32 0)  ; IMax(a,b)
  %76 = call i32 @dx.op.binary.i32(i32 37, i32 %74, i32 0)  ; IMax(a,b)
  %77 = call i32 @dx.op.binary.i32(i32 38, i32 %75, i32 %59)  ; IMin(a,b)
  %78 = call i32 @dx.op.binary.i32(i32 38, i32 %76, i32 %60)  ; IMin(a,b)
  %79 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %77, i32 %78, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %80 = extractvalue %dx.types.ResRet.f32 %79, 0
  %81 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %82 = extractvalue %dx.types.ResRet.f32 %81, 0
  %83 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %67, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %84 = extractvalue %dx.types.ResRet.f32 %83, 0
  %85 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %86 = extractvalue %dx.types.ResRet.f32 %85, 0
  %87 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %67, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %88 = extractvalue %dx.types.ResRet.f32 %87, 0
  %89 = fsub fast float 1.000000e+00, %57
  %90 = fsub fast float 1.000000e+00, %58
  %91 = fmul fast float %90, %89
  %92 = fmul fast float %90, %57
  %93 = fmul fast float %89, %58
  %94 = fmul fast float %58, %57
  %95 = fsub fast float 1.000000e+00, %80
  %96 = fmul fast float %95, 0x3FA99999A0000000
  %97 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %96)  ; FMax(a,b)
  %98 = fsub fast float %82, %80
  %99 = call float @dx.op.unary.f32(i32 6, float %98)  ; FAbs(value)
  %100 = fdiv fast float %99, %97
  %101 = fsub fast float 1.000000e+00, %100
  %102 = call float @dx.op.unary.f32(i32 7, float %101)  ; Saturate(value)
  %103 = fsub fast float %84, %80
  %104 = call float @dx.op.unary.f32(i32 6, float %103)  ; FAbs(value)
  %105 = fdiv fast float %104, %97
  %106 = fsub fast float 1.000000e+00, %105
  %107 = call float @dx.op.unary.f32(i32 7, float %106)  ; Saturate(value)
  %108 = fsub fast float %86, %80
  %109 = call float @dx.op.unary.f32(i32 6, float %108)  ; FAbs(value)
  %110 = fdiv fast float %109, %97
  %111 = fsub fast float 1.000000e+00, %110
  %112 = call float @dx.op.unary.f32(i32 7, float %111)  ; Saturate(value)
  %113 = fsub fast float %88, %80
  %114 = call float @dx.op.unary.f32(i32 6, float %113)  ; FAbs(value)
  %115 = fdiv fast float %114, %97
  %116 = fsub fast float 1.000000e+00, %115
  %117 = call float @dx.op.unary.f32(i32 7, float %116)  ; Saturate(value)
  %118 = fmul fast float %91, %102
  %119 = fmul fast float %92, %107
  %120 = fmul fast float %93, %112
  %121 = fmul fast float %94, %117
  %122 = fcmp fast oge float %57, 5.000000e-01
  %123 = zext i1 %122 to i32
  %124 = fcmp fast oge float %58, 5.000000e-01
  %125 = select i1 %124, i32 2, i32 0
  %126 = or i32 %125, %123
  %127 = call float @dx.op.dot4.f32(i32 56, float %118, float %119, float %120, float %121, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %128 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %118)  ; IsFinite(value)
  %129 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %119)  ; IsFinite(value)
  %130 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %120)  ; IsFinite(value)
  %131 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %121)  ; IsFinite(value)
  %132 = and i1 %128, %129
  %133 = and i1 %132, %130
  %134 = and i1 %133, %131
  br i1 %134, label %135, label %152

; <label>:135                                     ; preds = %0
  %136 = fcmp fast oge float %118, 0.000000e+00
  %137 = fcmp fast oge float %119, 0.000000e+00
  %138 = fcmp fast oge float %120, 0.000000e+00
  %139 = fcmp fast oge float %121, 0.000000e+00
  %140 = and i1 %136, %137
  %141 = and i1 %140, %138
  %142 = and i1 %141, %139
  br i1 %142, label %143, label %152

; <label>:143                                     ; preds = %135
  %144 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %127)  ; IsFinite(value)
  %145 = fcmp fast oge float %127, 0x3810000000000000
  %146 = and i1 %145, %144
  br i1 %146, label %147, label %152

; <label>:147                                     ; preds = %143
  %148 = fdiv fast float %118, %127
  %149 = fdiv fast float %119, %127
  %150 = fdiv fast float %120, %127
  %151 = fdiv fast float %121, %127
  br label %161

; <label>:152                                     ; preds = %143, %135, %0
  %153 = icmp eq i32 %126, 0
  %154 = uitofp i1 %153 to float
  %155 = icmp eq i32 %126, 1
  %156 = uitofp i1 %155 to float
  %157 = icmp eq i32 %126, 2
  %158 = uitofp i1 %157 to float
  %159 = icmp eq i32 %126, 3
  %160 = uitofp i1 %159 to float
  br label %161

; <label>:161                                     ; preds = %152, %147
  %162 = phi float [ %148, %147 ], [ %154, %152 ]
  %163 = phi float [ %149, %147 ], [ %156, %152 ]
  %164 = phi float [ %150, %147 ], [ %158, %152 ]
  %165 = phi float [ %151, %147 ], [ %160, %152 ]
  %166 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %167 = extractvalue %dx.types.ResRet.f32 %166, 0
  %168 = extractvalue %dx.types.ResRet.f32 %166, 1
  %169 = extractvalue %dx.types.ResRet.f32 %166, 2
  %170 = extractvalue %dx.types.ResRet.f32 %166, 3
  %171 = fcmp fast olt float %170, 0.000000e+00
  br i1 %171, label %172, label %174

; <label>:172                                     ; preds = %161
  %173 = fsub fast float -1.000000e+00, %170
  br label %423

; <label>:174                                     ; preds = %161
  %175 = fcmp fast ogt float %38, 5.000000e-01
  %176 = fcmp fast olt float %82, 1.000000e+00
  %177 = and i1 %175, %176
  br i1 %177, label %178, label %316

; <label>:178                                     ; preds = %174
  %179 = sitofp i32 %63 to float
  %180 = sitofp i32 %64 to float
  %181 = fadd fast float %179, 5.000000e-01
  %182 = fadd fast float %180, 5.000000e-01
  %183 = fdiv fast float %181, %45
  %184 = fdiv fast float %182, %46
  %185 = fmul fast float %183, 2.000000e+00
  %186 = fmul fast float %184, 2.000000e+00
  %187 = fadd fast float %185, -1.000000e+00
  %188 = fsub fast float 1.000000e+00, %186
  %189 = fmul fast float %187, %35
  %190 = call float @dx.op.tertiary.f32(i32 46, float %188, float %31, float %189)  ; FMad(a,b,c)
  %191 = call float @dx.op.tertiary.f32(i32 46, float %82, float %27, float %190)  ; FMad(a,b,c)
  %192 = fadd fast float %191, %23
  %193 = call float @dx.op.unary.f32(i32 6, float %192)  ; FAbs(value)
  %194 = fcmp fast ogt float %193, 0x3EB0C6F7A0000000
  br i1 %194, label %195, label %316

; <label>:195                                     ; preds = %178
  %196 = fmul fast float %187, %34
  %197 = call float @dx.op.tertiary.f32(i32 46, float %188, float %30, float %196)  ; FMad(a,b,c)
  %198 = call float @dx.op.tertiary.f32(i32 46, float %82, float %26, float %197)  ; FMad(a,b,c)
  %199 = fadd fast float %198, %22
  %200 = fmul fast float %187, %33
  %201 = call float @dx.op.tertiary.f32(i32 46, float %188, float %29, float %200)  ; FMad(a,b,c)
  %202 = call float @dx.op.tertiary.f32(i32 46, float %82, float %25, float %201)  ; FMad(a,b,c)
  %203 = fadd fast float %202, %21
  %204 = fmul fast float %187, %32
  %205 = call float @dx.op.tertiary.f32(i32 46, float %188, float %28, float %204)  ; FMad(a,b,c)
  %206 = call float @dx.op.tertiary.f32(i32 46, float %82, float %24, float %205)  ; FMad(a,b,c)
  %207 = fadd fast float %206, %20
  %208 = fdiv fast float %207, %192
  %209 = fdiv fast float %203, %192
  %210 = fdiv fast float %199, %192
  %211 = fsub fast float %208, %17
  %212 = fsub fast float %209, %18
  %213 = fsub fast float %210, %19
  %214 = fmul fast float %211, %211
  %215 = fmul fast float %212, %212
  %216 = fadd fast float %215, %214
  %217 = fmul fast float %213, %213
  %218 = fadd fast float %216, %217
  %219 = call float @dx.op.unary.f32(i32 24, float %218)  ; Sqrt(value)
  %220 = fsub fast float %219, %9
  %221 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %220)  ; FMax(a,b)
  %222 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %222, label %223, label %246

; <label>:223                                     ; preds = %195
  %224 = call float @dx.op.unary.f32(i32 6, float %212)  ; FAbs(value)
  %225 = fmul fast float %224, %11
  %226 = fcmp fast olt float %225, 0x3F50624DE0000000
  br i1 %226, label %227, label %230

; <label>:227                                     ; preds = %223
  %228 = fmul fast float %225, 5.000000e-01
  %229 = fsub fast float 1.000000e+00, %228
  br label %235

; <label>:230                                     ; preds = %223
  %231 = fmul fast float %225, 0xBFF7154760000000
  %232 = call float @dx.op.unary.f32(i32 21, float %231)  ; Exp(value)
  %233 = fsub fast float 1.000000e+00, %232
  %234 = fdiv fast float %233, %225
  br label %235

; <label>:235                                     ; preds = %230, %227
  %236 = phi float [ %229, %227 ], [ %234, %230 ]
  %237 = call float @dx.op.binary.f32(i32 36, float %209, float %18)  ; FMin(a,b)
  %238 = fsub fast float %237, %10
  %239 = fmul fast float %11, %238
  %240 = fsub fast float -0.000000e+00, %239
  %241 = call float @dx.op.binary.f32(i32 35, float %240, float -4.000000e+01)  ; FMax(a,b)
  %242 = call float @dx.op.binary.f32(i32 36, float %241, float 5.000000e+00)  ; FMin(a,b)
  %243 = fmul fast float %242, 0x3FF7154760000000
  %244 = call float @dx.op.unary.f32(i32 21, float %243)  ; Exp(value)
  %245 = fmul fast float %244, %236
  br label %246

; <label>:246                                     ; preds = %235, %195
  %247 = phi float [ %245, %235 ], [ 1.000000e+00, %195 ]
  %248 = fmul fast float %221, %16
  %249 = fmul fast float %248, %247
  %250 = fcmp fast ole float %219, %9
  %251 = fcmp fast olt float %219, 0x3F1A36E2E0000000
  %252 = or i1 %250, %251
  br i1 %252, label %299, label %253

; <label>:253                                     ; preds = %246
  %254 = fdiv fast float %9, %219
  %255 = fmul fast float %254, %211
  %256 = fmul fast float %254, %212
  %257 = fmul fast float %254, %213
  %258 = fadd fast float %255, %17
  %259 = fadd fast float %256, %18
  %260 = fadd fast float %257, %19
  %261 = fadd fast float %258, -9.000000e+02
  %262 = fadd fast float %259, -1.500000e+01
  %263 = fadd fast float %260, -7.500000e+02
  %264 = fmul fast float %261, 0x3F62345680000000
  %265 = fmul fast float %262, 0x3F62345680000000
  %266 = fmul fast float %263, 0x3F62345680000000
  %267 = call float @dx.op.dot3.f32(i32 55, float %264, float %265, float %266, float %264, float %265, float %266)  ; Dot3(ax,ay,az,bx,by,bz)
  %268 = fsub fast float 1.000000e+00, %267
  %269 = call float @dx.op.unary.f32(i32 7, float %268)  ; Saturate(value)
  %270 = fmul fast float %269, %269
  %271 = fadd fast float %258, %208
  %272 = fadd fast float %259, %209
  %273 = fadd fast float %260, %210
  %274 = fmul fast float %271, 0x3F52345680000000
  %275 = fadd fast float %274, -2.000000e+00
  %276 = fmul fast float %272, 0x3F52345680000000
  %277 = fadd fast float %276, 0xBFA1111120000000
  %278 = fmul fast float %273, 0x3F52345680000000
  %279 = fadd fast float %278, 0xBFFAAAAAC0000000
  %280 = call float @dx.op.dot3.f32(i32 55, float %275, float %277, float %279, float %275, float %277, float %279)  ; Dot3(ax,ay,az,bx,by,bz)
  %281 = fsub fast float 1.000000e+00, %280
  %282 = call float @dx.op.unary.f32(i32 7, float %281)  ; Saturate(value)
  %283 = fmul fast float %282, %282
  %284 = fmul fast float %283, 4.000000e+00
  %285 = fadd fast float %284, %270
  %286 = fadd fast float %208, -9.000000e+02
  %287 = fadd fast float %209, -1.500000e+01
  %288 = fadd fast float %210, -7.500000e+02
  %289 = fmul fast float %286, 0x3F62345680000000
  %290 = fmul fast float %287, 0x3F62345680000000
  %291 = fmul fast float %288, 0x3F62345680000000
  %292 = call float @dx.op.dot3.f32(i32 55, float %289, float %290, float %291, float %289, float %290, float %291)  ; Dot3(ax,ay,az,bx,by,bz)
  %293 = fsub fast float 1.000000e+00, %292
  %294 = call float @dx.op.unary.f32(i32 7, float %293)  ; Saturate(value)
  %295 = fmul fast float %294, %294
  %296 = fadd fast float %285, %295
  %297 = fmul fast float %220, 0x3F25D867E0000000
  %298 = fmul fast float %297, %296
  br label %299

; <label>:299                                     ; preds = %253, %246
  %300 = phi float [ %298, %253 ], [ 0.000000e+00, %246 ]
  %301 = fadd fast float %300, %249
  %302 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %301)  ; FMin(a,b)
  %303 = fmul fast float %302, 0xBFF7154760000000
  %304 = call float @dx.op.unary.f32(i32 21, float %303)  ; Exp(value)
  %305 = fsub fast float 1.000000e+00, %304
  %306 = call float @dx.op.binary.f32(i32 36, float %12, float %305)  ; FMin(a,b)
  %307 = fsub fast float %13, %167
  %308 = fsub fast float %14, %168
  %309 = fsub fast float %15, %169
  %310 = fmul fast float %306, %307
  %311 = fmul fast float %306, %308
  %312 = fmul fast float %306, %309
  %313 = fadd fast float %310, %167
  %314 = fadd fast float %311, %168
  %315 = fadd fast float %312, %169
  br label %316

; <label>:316                                     ; preds = %299, %178, %174
  %317 = phi float [ %313, %299 ], [ %167, %178 ], [ %167, %174 ]
  %318 = phi float [ %314, %299 ], [ %168, %178 ], [ %168, %174 ]
  %319 = phi float [ %315, %299 ], [ %169, %178 ], [ %169, %174 ]
  %320 = fadd fast float %5, 1.000000e+00
  %321 = fadd fast float %6, 1.000000e+00
  %322 = fsub fast float 1.000000e+00, %5
  %323 = fmul fast float %36, %320
  %324 = fmul fast float %36, %321
  %325 = fmul fast float %36, %322
  %326 = fmul fast float %323, %317
  %327 = fmul fast float %324, %318
  %328 = fmul fast float %325, %319
  %329 = fcmp fast ult float %37, 5.000000e-01
  br i1 %329, label %355, label %330

; <label>:330                                     ; preds = %316
  %331 = fmul fast float %326, 0x4004147AE0000000
  %332 = fmul fast float %327, 0x4004147AE0000000
  %333 = fmul fast float %328, 0x4004147AE0000000
  %334 = fadd fast float %331, 0x3F9EB851E0000000
  %335 = fadd fast float %332, 0x3F9EB851E0000000
  %336 = fadd fast float %333, 0x3F9EB851E0000000
  %337 = fmul fast float %334, %326
  %338 = fmul fast float %335, %327
  %339 = fmul fast float %336, %328
  %340 = fmul fast float %326, 0x400370A3E0000000
  %341 = fmul fast float %327, 0x400370A3E0000000
  %342 = fmul fast float %328, 0x400370A3E0000000
  %343 = fadd fast float %340, 0x3FE2E147A0000000
  %344 = fadd fast float %341, 0x3FE2E147A0000000
  %345 = fadd fast float %342, 0x3FE2E147A0000000
  %346 = fmul fast float %343, %326
  %347 = fmul fast float %344, %327
  %348 = fmul fast float %345, %328
  %349 = fadd fast float %346, 0x3FC1EB8520000000
  %350 = fadd fast float %347, 0x3FC1EB8520000000
  %351 = fadd fast float %348, 0x3FC1EB8520000000
  %352 = fdiv fast float %337, %349
  %353 = fdiv fast float %338, %350
  %354 = fdiv fast float %339, %351
  br label %355

; <label>:355                                     ; preds = %330, %316
  %356 = phi float [ %352, %330 ], [ %326, %316 ]
  %357 = phi float [ %353, %330 ], [ %327, %316 ]
  %358 = phi float [ %354, %330 ], [ %328, %316 ]
  %359 = call float @dx.op.unary.f32(i32 7, float %356)  ; Saturate(value)
  %360 = call float @dx.op.unary.f32(i32 7, float %357)  ; Saturate(value)
  %361 = call float @dx.op.unary.f32(i32 7, float %358)  ; Saturate(value)
  %362 = call float @dx.op.dot3.f32(i32 55, float %359, float %360, float %361, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %363 = fsub fast float %359, %362
  %364 = fsub fast float %360, %362
  %365 = fsub fast float %361, %362
  %366 = fmul fast float %363, %8
  %367 = fmul fast float %364, %8
  %368 = fmul fast float %365, %8
  %369 = fadd fast float %366, %362
  %370 = fadd fast float %367, %362
  %371 = fadd fast float %368, %362
  %372 = call float @dx.op.unary.f32(i32 7, float %369)  ; Saturate(value)
  %373 = call float @dx.op.unary.f32(i32 7, float %370)  ; Saturate(value)
  %374 = call float @dx.op.unary.f32(i32 7, float %371)  ; Saturate(value)
  %375 = fadd fast float %372, 0xBFC70A3D80000000
  %376 = fadd fast float %373, 0xBFC70A3D80000000
  %377 = fadd fast float %374, 0xBFC70A3D80000000
  %378 = fmul fast float %375, %7
  %379 = fmul fast float %376, %7
  %380 = fmul fast float %377, %7
  %381 = fadd fast float %378, 0x3FC70A3D80000000
  %382 = fadd fast float %379, 0x3FC70A3D80000000
  %383 = fadd fast float %380, 0x3FC70A3D80000000
  %384 = call float @dx.op.unary.f32(i32 7, float %381)  ; Saturate(value)
  %385 = call float @dx.op.unary.f32(i32 7, float %382)  ; Saturate(value)
  %386 = call float @dx.op.unary.f32(i32 7, float %383)  ; Saturate(value)
  %387 = fcmp fast ogt float %384, 0x3F69A5C380000000
  %388 = fcmp fast ogt float %385, 0x3F69A5C380000000
  %389 = fcmp fast ogt float %386, 0x3F69A5C380000000
  %390 = select i1 %387, float 0.000000e+00, float 1.000000e+00
  %391 = select i1 %388, float 0.000000e+00, float 1.000000e+00
  %392 = select i1 %389, float 0.000000e+00, float 1.000000e+00
  %393 = fmul fast float %384, 0x4029D70A40000000
  %394 = fmul fast float %385, 0x4029D70A40000000
  %395 = fmul fast float %386, 0x4029D70A40000000
  %396 = call float @dx.op.binary.f32(i32 35, float %384, float 0.000000e+00)  ; FMax(a,b)
  %397 = call float @dx.op.binary.f32(i32 35, float %385, float 0.000000e+00)  ; FMax(a,b)
  %398 = call float @dx.op.binary.f32(i32 35, float %386, float 0.000000e+00)  ; FMax(a,b)
  %399 = call float @dx.op.unary.f32(i32 23, float %396)  ; Log(value)
  %400 = call float @dx.op.unary.f32(i32 23, float %397)  ; Log(value)
  %401 = call float @dx.op.unary.f32(i32 23, float %398)  ; Log(value)
  %402 = fmul fast float %399, 0x3FDAAAAAA0000000
  %403 = fmul fast float %400, 0x3FDAAAAAA0000000
  %404 = fmul fast float %401, 0x3FDAAAAAA0000000
  %405 = call float @dx.op.unary.f32(i32 21, float %402)  ; Exp(value)
  %406 = call float @dx.op.unary.f32(i32 21, float %403)  ; Exp(value)
  %407 = call float @dx.op.unary.f32(i32 21, float %404)  ; Exp(value)
  %408 = fmul fast float %405, 0x3FF0E147A0000000
  %409 = fmul fast float %406, 0x3FF0E147A0000000
  %410 = fmul fast float %407, 0x3FF0E147A0000000
  %411 = fadd fast float %408, 0xBFAC28F5C0000000
  %412 = fadd fast float %409, 0xBFAC28F5C0000000
  %413 = fadd fast float %410, 0xBFAC28F5C0000000
  %414 = fsub fast float %393, %411
  %415 = fsub fast float %394, %412
  %416 = fsub fast float %395, %413
  %417 = fmul fast float %414, %390
  %418 = fmul fast float %415, %391
  %419 = fmul fast float %416, %392
  %420 = fadd fast float %417, %411
  %421 = fadd fast float %418, %412
  %422 = fadd fast float %419, %413
  br label %423

; <label>:423                                     ; preds = %355, %172
  %424 = phi float [ %167, %172 ], [ %420, %355 ]
  %425 = phi float [ %168, %172 ], [ %421, %355 ]
  %426 = phi float [ %169, %172 ], [ %422, %355 ]
  %427 = phi float [ %173, %172 ], [ %170, %355 ]
  %428 = fcmp fast ogt float %424, 0x3FA4B5DCC0000000
  %429 = fcmp fast ogt float %425, 0x3FA4B5DCC0000000
  %430 = fcmp fast ogt float %426, 0x3FA4B5DCC0000000
  %431 = select i1 %428, float 0.000000e+00, float 1.000000e+00
  %432 = select i1 %429, float 0.000000e+00, float 1.000000e+00
  %433 = select i1 %430, float 0.000000e+00, float 1.000000e+00
  %434 = fmul fast float %424, 0x3FB3D07220000000
  %435 = fmul fast float %425, 0x3FB3D07220000000
  %436 = fmul fast float %426, 0x3FB3D07220000000
  %437 = fadd fast float %424, 0x3FAC28F5C0000000
  %438 = fadd fast float %425, 0x3FAC28F5C0000000
  %439 = fadd fast float %426, 0x3FAC28F5C0000000
  %440 = fmul fast float %437, 0x3FEE54EDE0000000
  %441 = fmul fast float %438, 0x3FEE54EDE0000000
  %442 = fmul fast float %439, 0x3FEE54EDE0000000
  %443 = call float @dx.op.unary.f32(i32 23, float %440)  ; Log(value)
  %444 = call float @dx.op.unary.f32(i32 23, float %441)  ; Log(value)
  %445 = call float @dx.op.unary.f32(i32 23, float %442)  ; Log(value)
  %446 = fmul fast float %443, 0x4003333340000000
  %447 = fmul fast float %444, 0x4003333340000000
  %448 = fmul fast float %445, 0x4003333340000000
  %449 = call float @dx.op.unary.f32(i32 21, float %446)  ; Exp(value)
  %450 = call float @dx.op.unary.f32(i32 21, float %447)  ; Exp(value)
  %451 = call float @dx.op.unary.f32(i32 21, float %448)  ; Exp(value)
  %452 = fsub fast float %434, %449
  %453 = fsub fast float %435, %450
  %454 = fsub fast float %436, %451
  %455 = fmul fast float %452, %431
  %456 = fmul fast float %453, %432
  %457 = fmul fast float %454, %433
  %458 = fadd fast float %455, %449
  %459 = fadd fast float %456, %450
  %460 = fadd fast float %457, %451
  %461 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %67, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %462 = extractvalue %dx.types.ResRet.f32 %461, 0
  %463 = extractvalue %dx.types.ResRet.f32 %461, 1
  %464 = extractvalue %dx.types.ResRet.f32 %461, 2
  %465 = extractvalue %dx.types.ResRet.f32 %461, 3
  %466 = fcmp fast olt float %465, 0.000000e+00
  br i1 %466, label %467, label %469

; <label>:467                                     ; preds = %423
  %468 = fsub fast float -1.000000e+00, %465
  br label %718

; <label>:469                                     ; preds = %423
  %470 = fcmp fast ogt float %38, 5.000000e-01
  %471 = fcmp fast olt float %84, 1.000000e+00
  %472 = and i1 %470, %471
  br i1 %472, label %473, label %611

; <label>:473                                     ; preds = %469
  %474 = sitofp i32 %67 to float
  %475 = sitofp i32 %64 to float
  %476 = fadd fast float %474, 5.000000e-01
  %477 = fadd fast float %475, 5.000000e-01
  %478 = fdiv fast float %476, %45
  %479 = fdiv fast float %477, %46
  %480 = fmul fast float %478, 2.000000e+00
  %481 = fmul fast float %479, 2.000000e+00
  %482 = fadd fast float %480, -1.000000e+00
  %483 = fsub fast float 1.000000e+00, %481
  %484 = fmul fast float %482, %35
  %485 = call float @dx.op.tertiary.f32(i32 46, float %483, float %31, float %484)  ; FMad(a,b,c)
  %486 = call float @dx.op.tertiary.f32(i32 46, float %84, float %27, float %485)  ; FMad(a,b,c)
  %487 = fadd fast float %486, %23
  %488 = call float @dx.op.unary.f32(i32 6, float %487)  ; FAbs(value)
  %489 = fcmp fast ogt float %488, 0x3EB0C6F7A0000000
  br i1 %489, label %490, label %611

; <label>:490                                     ; preds = %473
  %491 = fmul fast float %482, %34
  %492 = call float @dx.op.tertiary.f32(i32 46, float %483, float %30, float %491)  ; FMad(a,b,c)
  %493 = call float @dx.op.tertiary.f32(i32 46, float %84, float %26, float %492)  ; FMad(a,b,c)
  %494 = fadd fast float %493, %22
  %495 = fmul fast float %482, %33
  %496 = call float @dx.op.tertiary.f32(i32 46, float %483, float %29, float %495)  ; FMad(a,b,c)
  %497 = call float @dx.op.tertiary.f32(i32 46, float %84, float %25, float %496)  ; FMad(a,b,c)
  %498 = fadd fast float %497, %21
  %499 = fmul fast float %482, %32
  %500 = call float @dx.op.tertiary.f32(i32 46, float %483, float %28, float %499)  ; FMad(a,b,c)
  %501 = call float @dx.op.tertiary.f32(i32 46, float %84, float %24, float %500)  ; FMad(a,b,c)
  %502 = fadd fast float %501, %20
  %503 = fdiv fast float %502, %487
  %504 = fdiv fast float %498, %487
  %505 = fdiv fast float %494, %487
  %506 = fsub fast float %503, %17
  %507 = fsub fast float %504, %18
  %508 = fsub fast float %505, %19
  %509 = fmul fast float %506, %506
  %510 = fmul fast float %507, %507
  %511 = fadd fast float %510, %509
  %512 = fmul fast float %508, %508
  %513 = fadd fast float %511, %512
  %514 = call float @dx.op.unary.f32(i32 24, float %513)  ; Sqrt(value)
  %515 = fsub fast float %514, %9
  %516 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %515)  ; FMax(a,b)
  %517 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %517, label %518, label %541

; <label>:518                                     ; preds = %490
  %519 = call float @dx.op.unary.f32(i32 6, float %507)  ; FAbs(value)
  %520 = fmul fast float %519, %11
  %521 = fcmp fast olt float %520, 0x3F50624DE0000000
  br i1 %521, label %522, label %525

; <label>:522                                     ; preds = %518
  %523 = fmul fast float %520, 5.000000e-01
  %524 = fsub fast float 1.000000e+00, %523
  br label %530

; <label>:525                                     ; preds = %518
  %526 = fmul fast float %520, 0xBFF7154760000000
  %527 = call float @dx.op.unary.f32(i32 21, float %526)  ; Exp(value)
  %528 = fsub fast float 1.000000e+00, %527
  %529 = fdiv fast float %528, %520
  br label %530

; <label>:530                                     ; preds = %525, %522
  %531 = phi float [ %524, %522 ], [ %529, %525 ]
  %532 = call float @dx.op.binary.f32(i32 36, float %504, float %18)  ; FMin(a,b)
  %533 = fsub fast float %532, %10
  %534 = fmul fast float %11, %533
  %535 = fsub fast float -0.000000e+00, %534
  %536 = call float @dx.op.binary.f32(i32 35, float %535, float -4.000000e+01)  ; FMax(a,b)
  %537 = call float @dx.op.binary.f32(i32 36, float %536, float 5.000000e+00)  ; FMin(a,b)
  %538 = fmul fast float %537, 0x3FF7154760000000
  %539 = call float @dx.op.unary.f32(i32 21, float %538)  ; Exp(value)
  %540 = fmul fast float %539, %531
  br label %541

; <label>:541                                     ; preds = %530, %490
  %542 = phi float [ %540, %530 ], [ 1.000000e+00, %490 ]
  %543 = fmul fast float %516, %16
  %544 = fmul fast float %543, %542
  %545 = fcmp fast ole float %514, %9
  %546 = fcmp fast olt float %514, 0x3F1A36E2E0000000
  %547 = or i1 %545, %546
  br i1 %547, label %594, label %548

; <label>:548                                     ; preds = %541
  %549 = fdiv fast float %9, %514
  %550 = fmul fast float %549, %506
  %551 = fmul fast float %549, %507
  %552 = fmul fast float %549, %508
  %553 = fadd fast float %550, %17
  %554 = fadd fast float %551, %18
  %555 = fadd fast float %552, %19
  %556 = fadd fast float %553, -9.000000e+02
  %557 = fadd fast float %554, -1.500000e+01
  %558 = fadd fast float %555, -7.500000e+02
  %559 = fmul fast float %556, 0x3F62345680000000
  %560 = fmul fast float %557, 0x3F62345680000000
  %561 = fmul fast float %558, 0x3F62345680000000
  %562 = call float @dx.op.dot3.f32(i32 55, float %559, float %560, float %561, float %559, float %560, float %561)  ; Dot3(ax,ay,az,bx,by,bz)
  %563 = fsub fast float 1.000000e+00, %562
  %564 = call float @dx.op.unary.f32(i32 7, float %563)  ; Saturate(value)
  %565 = fmul fast float %564, %564
  %566 = fadd fast float %553, %503
  %567 = fadd fast float %554, %504
  %568 = fadd fast float %555, %505
  %569 = fmul fast float %566, 0x3F52345680000000
  %570 = fadd fast float %569, -2.000000e+00
  %571 = fmul fast float %567, 0x3F52345680000000
  %572 = fadd fast float %571, 0xBFA1111120000000
  %573 = fmul fast float %568, 0x3F52345680000000
  %574 = fadd fast float %573, 0xBFFAAAAAC0000000
  %575 = call float @dx.op.dot3.f32(i32 55, float %570, float %572, float %574, float %570, float %572, float %574)  ; Dot3(ax,ay,az,bx,by,bz)
  %576 = fsub fast float 1.000000e+00, %575
  %577 = call float @dx.op.unary.f32(i32 7, float %576)  ; Saturate(value)
  %578 = fmul fast float %577, %577
  %579 = fmul fast float %578, 4.000000e+00
  %580 = fadd fast float %579, %565
  %581 = fadd fast float %503, -9.000000e+02
  %582 = fadd fast float %504, -1.500000e+01
  %583 = fadd fast float %505, -7.500000e+02
  %584 = fmul fast float %581, 0x3F62345680000000
  %585 = fmul fast float %582, 0x3F62345680000000
  %586 = fmul fast float %583, 0x3F62345680000000
  %587 = call float @dx.op.dot3.f32(i32 55, float %584, float %585, float %586, float %584, float %585, float %586)  ; Dot3(ax,ay,az,bx,by,bz)
  %588 = fsub fast float 1.000000e+00, %587
  %589 = call float @dx.op.unary.f32(i32 7, float %588)  ; Saturate(value)
  %590 = fmul fast float %589, %589
  %591 = fadd fast float %580, %590
  %592 = fmul fast float %515, 0x3F25D867E0000000
  %593 = fmul fast float %592, %591
  br label %594

; <label>:594                                     ; preds = %548, %541
  %595 = phi float [ %593, %548 ], [ 0.000000e+00, %541 ]
  %596 = fadd fast float %595, %544
  %597 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %596)  ; FMin(a,b)
  %598 = fmul fast float %597, 0xBFF7154760000000
  %599 = call float @dx.op.unary.f32(i32 21, float %598)  ; Exp(value)
  %600 = fsub fast float 1.000000e+00, %599
  %601 = call float @dx.op.binary.f32(i32 36, float %12, float %600)  ; FMin(a,b)
  %602 = fsub fast float %13, %462
  %603 = fsub fast float %14, %463
  %604 = fsub fast float %15, %464
  %605 = fmul fast float %601, %602
  %606 = fmul fast float %601, %603
  %607 = fmul fast float %601, %604
  %608 = fadd fast float %605, %462
  %609 = fadd fast float %606, %463
  %610 = fadd fast float %607, %464
  br label %611

; <label>:611                                     ; preds = %594, %473, %469
  %612 = phi float [ %608, %594 ], [ %462, %473 ], [ %462, %469 ]
  %613 = phi float [ %609, %594 ], [ %463, %473 ], [ %463, %469 ]
  %614 = phi float [ %610, %594 ], [ %464, %473 ], [ %464, %469 ]
  %615 = fadd fast float %5, 1.000000e+00
  %616 = fadd fast float %6, 1.000000e+00
  %617 = fsub fast float 1.000000e+00, %5
  %618 = fmul fast float %36, %615
  %619 = fmul fast float %36, %616
  %620 = fmul fast float %36, %617
  %621 = fmul fast float %618, %612
  %622 = fmul fast float %619, %613
  %623 = fmul fast float %620, %614
  %624 = fcmp fast ult float %37, 5.000000e-01
  br i1 %624, label %650, label %625

; <label>:625                                     ; preds = %611
  %626 = fmul fast float %621, 0x4004147AE0000000
  %627 = fmul fast float %622, 0x4004147AE0000000
  %628 = fmul fast float %623, 0x4004147AE0000000
  %629 = fadd fast float %626, 0x3F9EB851E0000000
  %630 = fadd fast float %627, 0x3F9EB851E0000000
  %631 = fadd fast float %628, 0x3F9EB851E0000000
  %632 = fmul fast float %629, %621
  %633 = fmul fast float %630, %622
  %634 = fmul fast float %631, %623
  %635 = fmul fast float %621, 0x400370A3E0000000
  %636 = fmul fast float %622, 0x400370A3E0000000
  %637 = fmul fast float %623, 0x400370A3E0000000
  %638 = fadd fast float %635, 0x3FE2E147A0000000
  %639 = fadd fast float %636, 0x3FE2E147A0000000
  %640 = fadd fast float %637, 0x3FE2E147A0000000
  %641 = fmul fast float %638, %621
  %642 = fmul fast float %639, %622
  %643 = fmul fast float %640, %623
  %644 = fadd fast float %641, 0x3FC1EB8520000000
  %645 = fadd fast float %642, 0x3FC1EB8520000000
  %646 = fadd fast float %643, 0x3FC1EB8520000000
  %647 = fdiv fast float %632, %644
  %648 = fdiv fast float %633, %645
  %649 = fdiv fast float %634, %646
  br label %650

; <label>:650                                     ; preds = %625, %611
  %651 = phi float [ %647, %625 ], [ %621, %611 ]
  %652 = phi float [ %648, %625 ], [ %622, %611 ]
  %653 = phi float [ %649, %625 ], [ %623, %611 ]
  %654 = call float @dx.op.unary.f32(i32 7, float %651)  ; Saturate(value)
  %655 = call float @dx.op.unary.f32(i32 7, float %652)  ; Saturate(value)
  %656 = call float @dx.op.unary.f32(i32 7, float %653)  ; Saturate(value)
  %657 = call float @dx.op.dot3.f32(i32 55, float %654, float %655, float %656, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %658 = fsub fast float %654, %657
  %659 = fsub fast float %655, %657
  %660 = fsub fast float %656, %657
  %661 = fmul fast float %658, %8
  %662 = fmul fast float %659, %8
  %663 = fmul fast float %660, %8
  %664 = fadd fast float %661, %657
  %665 = fadd fast float %662, %657
  %666 = fadd fast float %663, %657
  %667 = call float @dx.op.unary.f32(i32 7, float %664)  ; Saturate(value)
  %668 = call float @dx.op.unary.f32(i32 7, float %665)  ; Saturate(value)
  %669 = call float @dx.op.unary.f32(i32 7, float %666)  ; Saturate(value)
  %670 = fadd fast float %667, 0xBFC70A3D80000000
  %671 = fadd fast float %668, 0xBFC70A3D80000000
  %672 = fadd fast float %669, 0xBFC70A3D80000000
  %673 = fmul fast float %670, %7
  %674 = fmul fast float %671, %7
  %675 = fmul fast float %672, %7
  %676 = fadd fast float %673, 0x3FC70A3D80000000
  %677 = fadd fast float %674, 0x3FC70A3D80000000
  %678 = fadd fast float %675, 0x3FC70A3D80000000
  %679 = call float @dx.op.unary.f32(i32 7, float %676)  ; Saturate(value)
  %680 = call float @dx.op.unary.f32(i32 7, float %677)  ; Saturate(value)
  %681 = call float @dx.op.unary.f32(i32 7, float %678)  ; Saturate(value)
  %682 = fcmp fast ogt float %679, 0x3F69A5C380000000
  %683 = fcmp fast ogt float %680, 0x3F69A5C380000000
  %684 = fcmp fast ogt float %681, 0x3F69A5C380000000
  %685 = select i1 %682, float 0.000000e+00, float 1.000000e+00
  %686 = select i1 %683, float 0.000000e+00, float 1.000000e+00
  %687 = select i1 %684, float 0.000000e+00, float 1.000000e+00
  %688 = fmul fast float %679, 0x4029D70A40000000
  %689 = fmul fast float %680, 0x4029D70A40000000
  %690 = fmul fast float %681, 0x4029D70A40000000
  %691 = call float @dx.op.binary.f32(i32 35, float %679, float 0.000000e+00)  ; FMax(a,b)
  %692 = call float @dx.op.binary.f32(i32 35, float %680, float 0.000000e+00)  ; FMax(a,b)
  %693 = call float @dx.op.binary.f32(i32 35, float %681, float 0.000000e+00)  ; FMax(a,b)
  %694 = call float @dx.op.unary.f32(i32 23, float %691)  ; Log(value)
  %695 = call float @dx.op.unary.f32(i32 23, float %692)  ; Log(value)
  %696 = call float @dx.op.unary.f32(i32 23, float %693)  ; Log(value)
  %697 = fmul fast float %694, 0x3FDAAAAAA0000000
  %698 = fmul fast float %695, 0x3FDAAAAAA0000000
  %699 = fmul fast float %696, 0x3FDAAAAAA0000000
  %700 = call float @dx.op.unary.f32(i32 21, float %697)  ; Exp(value)
  %701 = call float @dx.op.unary.f32(i32 21, float %698)  ; Exp(value)
  %702 = call float @dx.op.unary.f32(i32 21, float %699)  ; Exp(value)
  %703 = fmul fast float %700, 0x3FF0E147A0000000
  %704 = fmul fast float %701, 0x3FF0E147A0000000
  %705 = fmul fast float %702, 0x3FF0E147A0000000
  %706 = fadd fast float %703, 0xBFAC28F5C0000000
  %707 = fadd fast float %704, 0xBFAC28F5C0000000
  %708 = fadd fast float %705, 0xBFAC28F5C0000000
  %709 = fsub fast float %688, %706
  %710 = fsub fast float %689, %707
  %711 = fsub fast float %690, %708
  %712 = fmul fast float %709, %685
  %713 = fmul fast float %710, %686
  %714 = fmul fast float %711, %687
  %715 = fadd fast float %712, %706
  %716 = fadd fast float %713, %707
  %717 = fadd fast float %714, %708
  br label %718

; <label>:718                                     ; preds = %650, %467
  %719 = phi float [ %462, %467 ], [ %715, %650 ]
  %720 = phi float [ %463, %467 ], [ %716, %650 ]
  %721 = phi float [ %464, %467 ], [ %717, %650 ]
  %722 = phi float [ %468, %467 ], [ %465, %650 ]
  %723 = fcmp fast ogt float %719, 0x3FA4B5DCC0000000
  %724 = fcmp fast ogt float %720, 0x3FA4B5DCC0000000
  %725 = fcmp fast ogt float %721, 0x3FA4B5DCC0000000
  %726 = select i1 %723, float 0.000000e+00, float 1.000000e+00
  %727 = select i1 %724, float 0.000000e+00, float 1.000000e+00
  %728 = select i1 %725, float 0.000000e+00, float 1.000000e+00
  %729 = fmul fast float %719, 0x3FB3D07220000000
  %730 = fmul fast float %720, 0x3FB3D07220000000
  %731 = fmul fast float %721, 0x3FB3D07220000000
  %732 = fadd fast float %719, 0x3FAC28F5C0000000
  %733 = fadd fast float %720, 0x3FAC28F5C0000000
  %734 = fadd fast float %721, 0x3FAC28F5C0000000
  %735 = fmul fast float %732, 0x3FEE54EDE0000000
  %736 = fmul fast float %733, 0x3FEE54EDE0000000
  %737 = fmul fast float %734, 0x3FEE54EDE0000000
  %738 = call float @dx.op.unary.f32(i32 23, float %735)  ; Log(value)
  %739 = call float @dx.op.unary.f32(i32 23, float %736)  ; Log(value)
  %740 = call float @dx.op.unary.f32(i32 23, float %737)  ; Log(value)
  %741 = fmul fast float %738, 0x4003333340000000
  %742 = fmul fast float %739, 0x4003333340000000
  %743 = fmul fast float %740, 0x4003333340000000
  %744 = call float @dx.op.unary.f32(i32 21, float %741)  ; Exp(value)
  %745 = call float @dx.op.unary.f32(i32 21, float %742)  ; Exp(value)
  %746 = call float @dx.op.unary.f32(i32 21, float %743)  ; Exp(value)
  %747 = fsub fast float %729, %744
  %748 = fsub fast float %730, %745
  %749 = fsub fast float %731, %746
  %750 = fmul fast float %747, %726
  %751 = fmul fast float %748, %727
  %752 = fmul fast float %749, %728
  %753 = fadd fast float %750, %744
  %754 = fadd fast float %751, %745
  %755 = fadd fast float %752, %746
  %756 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %63, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %757 = extractvalue %dx.types.ResRet.f32 %756, 0
  %758 = extractvalue %dx.types.ResRet.f32 %756, 1
  %759 = extractvalue %dx.types.ResRet.f32 %756, 2
  %760 = extractvalue %dx.types.ResRet.f32 %756, 3
  %761 = fcmp fast olt float %760, 0.000000e+00
  br i1 %761, label %762, label %764

; <label>:762                                     ; preds = %718
  %763 = fsub fast float -1.000000e+00, %760
  br label %1013

; <label>:764                                     ; preds = %718
  %765 = fcmp fast ogt float %38, 5.000000e-01
  %766 = fcmp fast olt float %86, 1.000000e+00
  %767 = and i1 %765, %766
  br i1 %767, label %768, label %906

; <label>:768                                     ; preds = %764
  %769 = sitofp i32 %63 to float
  %770 = sitofp i32 %70 to float
  %771 = fadd fast float %769, 5.000000e-01
  %772 = fadd fast float %770, 5.000000e-01
  %773 = fdiv fast float %771, %45
  %774 = fdiv fast float %772, %46
  %775 = fmul fast float %773, 2.000000e+00
  %776 = fmul fast float %774, 2.000000e+00
  %777 = fadd fast float %775, -1.000000e+00
  %778 = fsub fast float 1.000000e+00, %776
  %779 = fmul fast float %777, %35
  %780 = call float @dx.op.tertiary.f32(i32 46, float %778, float %31, float %779)  ; FMad(a,b,c)
  %781 = call float @dx.op.tertiary.f32(i32 46, float %86, float %27, float %780)  ; FMad(a,b,c)
  %782 = fadd fast float %781, %23
  %783 = call float @dx.op.unary.f32(i32 6, float %782)  ; FAbs(value)
  %784 = fcmp fast ogt float %783, 0x3EB0C6F7A0000000
  br i1 %784, label %785, label %906

; <label>:785                                     ; preds = %768
  %786 = fmul fast float %777, %34
  %787 = call float @dx.op.tertiary.f32(i32 46, float %778, float %30, float %786)  ; FMad(a,b,c)
  %788 = call float @dx.op.tertiary.f32(i32 46, float %86, float %26, float %787)  ; FMad(a,b,c)
  %789 = fadd fast float %788, %22
  %790 = fmul fast float %777, %33
  %791 = call float @dx.op.tertiary.f32(i32 46, float %778, float %29, float %790)  ; FMad(a,b,c)
  %792 = call float @dx.op.tertiary.f32(i32 46, float %86, float %25, float %791)  ; FMad(a,b,c)
  %793 = fadd fast float %792, %21
  %794 = fmul fast float %777, %32
  %795 = call float @dx.op.tertiary.f32(i32 46, float %778, float %28, float %794)  ; FMad(a,b,c)
  %796 = call float @dx.op.tertiary.f32(i32 46, float %86, float %24, float %795)  ; FMad(a,b,c)
  %797 = fadd fast float %796, %20
  %798 = fdiv fast float %797, %782
  %799 = fdiv fast float %793, %782
  %800 = fdiv fast float %789, %782
  %801 = fsub fast float %798, %17
  %802 = fsub fast float %799, %18
  %803 = fsub fast float %800, %19
  %804 = fmul fast float %801, %801
  %805 = fmul fast float %802, %802
  %806 = fadd fast float %805, %804
  %807 = fmul fast float %803, %803
  %808 = fadd fast float %806, %807
  %809 = call float @dx.op.unary.f32(i32 24, float %808)  ; Sqrt(value)
  %810 = fsub fast float %809, %9
  %811 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %810)  ; FMax(a,b)
  %812 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %812, label %813, label %836

; <label>:813                                     ; preds = %785
  %814 = call float @dx.op.unary.f32(i32 6, float %802)  ; FAbs(value)
  %815 = fmul fast float %814, %11
  %816 = fcmp fast olt float %815, 0x3F50624DE0000000
  br i1 %816, label %817, label %820

; <label>:817                                     ; preds = %813
  %818 = fmul fast float %815, 5.000000e-01
  %819 = fsub fast float 1.000000e+00, %818
  br label %825

; <label>:820                                     ; preds = %813
  %821 = fmul fast float %815, 0xBFF7154760000000
  %822 = call float @dx.op.unary.f32(i32 21, float %821)  ; Exp(value)
  %823 = fsub fast float 1.000000e+00, %822
  %824 = fdiv fast float %823, %815
  br label %825

; <label>:825                                     ; preds = %820, %817
  %826 = phi float [ %819, %817 ], [ %824, %820 ]
  %827 = call float @dx.op.binary.f32(i32 36, float %799, float %18)  ; FMin(a,b)
  %828 = fsub fast float %827, %10
  %829 = fmul fast float %11, %828
  %830 = fsub fast float -0.000000e+00, %829
  %831 = call float @dx.op.binary.f32(i32 35, float %830, float -4.000000e+01)  ; FMax(a,b)
  %832 = call float @dx.op.binary.f32(i32 36, float %831, float 5.000000e+00)  ; FMin(a,b)
  %833 = fmul fast float %832, 0x3FF7154760000000
  %834 = call float @dx.op.unary.f32(i32 21, float %833)  ; Exp(value)
  %835 = fmul fast float %834, %826
  br label %836

; <label>:836                                     ; preds = %825, %785
  %837 = phi float [ %835, %825 ], [ 1.000000e+00, %785 ]
  %838 = fmul fast float %811, %16
  %839 = fmul fast float %838, %837
  %840 = fcmp fast ole float %809, %9
  %841 = fcmp fast olt float %809, 0x3F1A36E2E0000000
  %842 = or i1 %840, %841
  br i1 %842, label %889, label %843

; <label>:843                                     ; preds = %836
  %844 = fdiv fast float %9, %809
  %845 = fmul fast float %844, %801
  %846 = fmul fast float %844, %802
  %847 = fmul fast float %844, %803
  %848 = fadd fast float %845, %17
  %849 = fadd fast float %846, %18
  %850 = fadd fast float %847, %19
  %851 = fadd fast float %848, -9.000000e+02
  %852 = fadd fast float %849, -1.500000e+01
  %853 = fadd fast float %850, -7.500000e+02
  %854 = fmul fast float %851, 0x3F62345680000000
  %855 = fmul fast float %852, 0x3F62345680000000
  %856 = fmul fast float %853, 0x3F62345680000000
  %857 = call float @dx.op.dot3.f32(i32 55, float %854, float %855, float %856, float %854, float %855, float %856)  ; Dot3(ax,ay,az,bx,by,bz)
  %858 = fsub fast float 1.000000e+00, %857
  %859 = call float @dx.op.unary.f32(i32 7, float %858)  ; Saturate(value)
  %860 = fmul fast float %859, %859
  %861 = fadd fast float %848, %798
  %862 = fadd fast float %849, %799
  %863 = fadd fast float %850, %800
  %864 = fmul fast float %861, 0x3F52345680000000
  %865 = fadd fast float %864, -2.000000e+00
  %866 = fmul fast float %862, 0x3F52345680000000
  %867 = fadd fast float %866, 0xBFA1111120000000
  %868 = fmul fast float %863, 0x3F52345680000000
  %869 = fadd fast float %868, 0xBFFAAAAAC0000000
  %870 = call float @dx.op.dot3.f32(i32 55, float %865, float %867, float %869, float %865, float %867, float %869)  ; Dot3(ax,ay,az,bx,by,bz)
  %871 = fsub fast float 1.000000e+00, %870
  %872 = call float @dx.op.unary.f32(i32 7, float %871)  ; Saturate(value)
  %873 = fmul fast float %872, %872
  %874 = fmul fast float %873, 4.000000e+00
  %875 = fadd fast float %874, %860
  %876 = fadd fast float %798, -9.000000e+02
  %877 = fadd fast float %799, -1.500000e+01
  %878 = fadd fast float %800, -7.500000e+02
  %879 = fmul fast float %876, 0x3F62345680000000
  %880 = fmul fast float %877, 0x3F62345680000000
  %881 = fmul fast float %878, 0x3F62345680000000
  %882 = call float @dx.op.dot3.f32(i32 55, float %879, float %880, float %881, float %879, float %880, float %881)  ; Dot3(ax,ay,az,bx,by,bz)
  %883 = fsub fast float 1.000000e+00, %882
  %884 = call float @dx.op.unary.f32(i32 7, float %883)  ; Saturate(value)
  %885 = fmul fast float %884, %884
  %886 = fadd fast float %875, %885
  %887 = fmul fast float %810, 0x3F25D867E0000000
  %888 = fmul fast float %887, %886
  br label %889

; <label>:889                                     ; preds = %843, %836
  %890 = phi float [ %888, %843 ], [ 0.000000e+00, %836 ]
  %891 = fadd fast float %890, %839
  %892 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %891)  ; FMin(a,b)
  %893 = fmul fast float %892, 0xBFF7154760000000
  %894 = call float @dx.op.unary.f32(i32 21, float %893)  ; Exp(value)
  %895 = fsub fast float 1.000000e+00, %894
  %896 = call float @dx.op.binary.f32(i32 36, float %12, float %895)  ; FMin(a,b)
  %897 = fsub fast float %13, %757
  %898 = fsub fast float %14, %758
  %899 = fsub fast float %15, %759
  %900 = fmul fast float %896, %897
  %901 = fmul fast float %896, %898
  %902 = fmul fast float %896, %899
  %903 = fadd fast float %900, %757
  %904 = fadd fast float %901, %758
  %905 = fadd fast float %902, %759
  br label %906

; <label>:906                                     ; preds = %889, %768, %764
  %907 = phi float [ %903, %889 ], [ %757, %768 ], [ %757, %764 ]
  %908 = phi float [ %904, %889 ], [ %758, %768 ], [ %758, %764 ]
  %909 = phi float [ %905, %889 ], [ %759, %768 ], [ %759, %764 ]
  %910 = fadd fast float %5, 1.000000e+00
  %911 = fadd fast float %6, 1.000000e+00
  %912 = fsub fast float 1.000000e+00, %5
  %913 = fmul fast float %36, %910
  %914 = fmul fast float %36, %911
  %915 = fmul fast float %36, %912
  %916 = fmul fast float %913, %907
  %917 = fmul fast float %914, %908
  %918 = fmul fast float %915, %909
  %919 = fcmp fast ult float %37, 5.000000e-01
  br i1 %919, label %945, label %920

; <label>:920                                     ; preds = %906
  %921 = fmul fast float %916, 0x4004147AE0000000
  %922 = fmul fast float %917, 0x4004147AE0000000
  %923 = fmul fast float %918, 0x4004147AE0000000
  %924 = fadd fast float %921, 0x3F9EB851E0000000
  %925 = fadd fast float %922, 0x3F9EB851E0000000
  %926 = fadd fast float %923, 0x3F9EB851E0000000
  %927 = fmul fast float %924, %916
  %928 = fmul fast float %925, %917
  %929 = fmul fast float %926, %918
  %930 = fmul fast float %916, 0x400370A3E0000000
  %931 = fmul fast float %917, 0x400370A3E0000000
  %932 = fmul fast float %918, 0x400370A3E0000000
  %933 = fadd fast float %930, 0x3FE2E147A0000000
  %934 = fadd fast float %931, 0x3FE2E147A0000000
  %935 = fadd fast float %932, 0x3FE2E147A0000000
  %936 = fmul fast float %933, %916
  %937 = fmul fast float %934, %917
  %938 = fmul fast float %935, %918
  %939 = fadd fast float %936, 0x3FC1EB8520000000
  %940 = fadd fast float %937, 0x3FC1EB8520000000
  %941 = fadd fast float %938, 0x3FC1EB8520000000
  %942 = fdiv fast float %927, %939
  %943 = fdiv fast float %928, %940
  %944 = fdiv fast float %929, %941
  br label %945

; <label>:945                                     ; preds = %920, %906
  %946 = phi float [ %942, %920 ], [ %916, %906 ]
  %947 = phi float [ %943, %920 ], [ %917, %906 ]
  %948 = phi float [ %944, %920 ], [ %918, %906 ]
  %949 = call float @dx.op.unary.f32(i32 7, float %946)  ; Saturate(value)
  %950 = call float @dx.op.unary.f32(i32 7, float %947)  ; Saturate(value)
  %951 = call float @dx.op.unary.f32(i32 7, float %948)  ; Saturate(value)
  %952 = call float @dx.op.dot3.f32(i32 55, float %949, float %950, float %951, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %953 = fsub fast float %949, %952
  %954 = fsub fast float %950, %952
  %955 = fsub fast float %951, %952
  %956 = fmul fast float %953, %8
  %957 = fmul fast float %954, %8
  %958 = fmul fast float %955, %8
  %959 = fadd fast float %956, %952
  %960 = fadd fast float %957, %952
  %961 = fadd fast float %958, %952
  %962 = call float @dx.op.unary.f32(i32 7, float %959)  ; Saturate(value)
  %963 = call float @dx.op.unary.f32(i32 7, float %960)  ; Saturate(value)
  %964 = call float @dx.op.unary.f32(i32 7, float %961)  ; Saturate(value)
  %965 = fadd fast float %962, 0xBFC70A3D80000000
  %966 = fadd fast float %963, 0xBFC70A3D80000000
  %967 = fadd fast float %964, 0xBFC70A3D80000000
  %968 = fmul fast float %965, %7
  %969 = fmul fast float %966, %7
  %970 = fmul fast float %967, %7
  %971 = fadd fast float %968, 0x3FC70A3D80000000
  %972 = fadd fast float %969, 0x3FC70A3D80000000
  %973 = fadd fast float %970, 0x3FC70A3D80000000
  %974 = call float @dx.op.unary.f32(i32 7, float %971)  ; Saturate(value)
  %975 = call float @dx.op.unary.f32(i32 7, float %972)  ; Saturate(value)
  %976 = call float @dx.op.unary.f32(i32 7, float %973)  ; Saturate(value)
  %977 = fcmp fast ogt float %974, 0x3F69A5C380000000
  %978 = fcmp fast ogt float %975, 0x3F69A5C380000000
  %979 = fcmp fast ogt float %976, 0x3F69A5C380000000
  %980 = select i1 %977, float 0.000000e+00, float 1.000000e+00
  %981 = select i1 %978, float 0.000000e+00, float 1.000000e+00
  %982 = select i1 %979, float 0.000000e+00, float 1.000000e+00
  %983 = fmul fast float %974, 0x4029D70A40000000
  %984 = fmul fast float %975, 0x4029D70A40000000
  %985 = fmul fast float %976, 0x4029D70A40000000
  %986 = call float @dx.op.binary.f32(i32 35, float %974, float 0.000000e+00)  ; FMax(a,b)
  %987 = call float @dx.op.binary.f32(i32 35, float %975, float 0.000000e+00)  ; FMax(a,b)
  %988 = call float @dx.op.binary.f32(i32 35, float %976, float 0.000000e+00)  ; FMax(a,b)
  %989 = call float @dx.op.unary.f32(i32 23, float %986)  ; Log(value)
  %990 = call float @dx.op.unary.f32(i32 23, float %987)  ; Log(value)
  %991 = call float @dx.op.unary.f32(i32 23, float %988)  ; Log(value)
  %992 = fmul fast float %989, 0x3FDAAAAAA0000000
  %993 = fmul fast float %990, 0x3FDAAAAAA0000000
  %994 = fmul fast float %991, 0x3FDAAAAAA0000000
  %995 = call float @dx.op.unary.f32(i32 21, float %992)  ; Exp(value)
  %996 = call float @dx.op.unary.f32(i32 21, float %993)  ; Exp(value)
  %997 = call float @dx.op.unary.f32(i32 21, float %994)  ; Exp(value)
  %998 = fmul fast float %995, 0x3FF0E147A0000000
  %999 = fmul fast float %996, 0x3FF0E147A0000000
  %1000 = fmul fast float %997, 0x3FF0E147A0000000
  %1001 = fadd fast float %998, 0xBFAC28F5C0000000
  %1002 = fadd fast float %999, 0xBFAC28F5C0000000
  %1003 = fadd fast float %1000, 0xBFAC28F5C0000000
  %1004 = fsub fast float %983, %1001
  %1005 = fsub fast float %984, %1002
  %1006 = fsub fast float %985, %1003
  %1007 = fmul fast float %1004, %980
  %1008 = fmul fast float %1005, %981
  %1009 = fmul fast float %1006, %982
  %1010 = fadd fast float %1007, %1001
  %1011 = fadd fast float %1008, %1002
  %1012 = fadd fast float %1009, %1003
  br label %1013

; <label>:1013                                    ; preds = %945, %762
  %1014 = phi float [ %757, %762 ], [ %1010, %945 ]
  %1015 = phi float [ %758, %762 ], [ %1011, %945 ]
  %1016 = phi float [ %759, %762 ], [ %1012, %945 ]
  %1017 = phi float [ %763, %762 ], [ %760, %945 ]
  %1018 = fcmp fast ogt float %1014, 0x3FA4B5DCC0000000
  %1019 = fcmp fast ogt float %1015, 0x3FA4B5DCC0000000
  %1020 = fcmp fast ogt float %1016, 0x3FA4B5DCC0000000
  %1021 = select i1 %1018, float 0.000000e+00, float 1.000000e+00
  %1022 = select i1 %1019, float 0.000000e+00, float 1.000000e+00
  %1023 = select i1 %1020, float 0.000000e+00, float 1.000000e+00
  %1024 = fmul fast float %1014, 0x3FB3D07220000000
  %1025 = fmul fast float %1015, 0x3FB3D07220000000
  %1026 = fmul fast float %1016, 0x3FB3D07220000000
  %1027 = fadd fast float %1014, 0x3FAC28F5C0000000
  %1028 = fadd fast float %1015, 0x3FAC28F5C0000000
  %1029 = fadd fast float %1016, 0x3FAC28F5C0000000
  %1030 = fmul fast float %1027, 0x3FEE54EDE0000000
  %1031 = fmul fast float %1028, 0x3FEE54EDE0000000
  %1032 = fmul fast float %1029, 0x3FEE54EDE0000000
  %1033 = call float @dx.op.unary.f32(i32 23, float %1030)  ; Log(value)
  %1034 = call float @dx.op.unary.f32(i32 23, float %1031)  ; Log(value)
  %1035 = call float @dx.op.unary.f32(i32 23, float %1032)  ; Log(value)
  %1036 = fmul fast float %1033, 0x4003333340000000
  %1037 = fmul fast float %1034, 0x4003333340000000
  %1038 = fmul fast float %1035, 0x4003333340000000
  %1039 = call float @dx.op.unary.f32(i32 21, float %1036)  ; Exp(value)
  %1040 = call float @dx.op.unary.f32(i32 21, float %1037)  ; Exp(value)
  %1041 = call float @dx.op.unary.f32(i32 21, float %1038)  ; Exp(value)
  %1042 = fsub fast float %1024, %1039
  %1043 = fsub fast float %1025, %1040
  %1044 = fsub fast float %1026, %1041
  %1045 = fmul fast float %1042, %1021
  %1046 = fmul fast float %1043, %1022
  %1047 = fmul fast float %1044, %1023
  %1048 = fadd fast float %1045, %1039
  %1049 = fadd fast float %1046, %1040
  %1050 = fadd fast float %1047, %1041
  %1051 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %67, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1052 = extractvalue %dx.types.ResRet.f32 %1051, 0
  %1053 = extractvalue %dx.types.ResRet.f32 %1051, 1
  %1054 = extractvalue %dx.types.ResRet.f32 %1051, 2
  %1055 = extractvalue %dx.types.ResRet.f32 %1051, 3
  %1056 = fcmp fast olt float %1055, 0.000000e+00
  br i1 %1056, label %1057, label %1059

; <label>:1057                                    ; preds = %1013
  %1058 = fsub fast float -1.000000e+00, %1055
  br label %1308

; <label>:1059                                    ; preds = %1013
  %1060 = fcmp fast ogt float %38, 5.000000e-01
  %1061 = fcmp fast olt float %88, 1.000000e+00
  %1062 = and i1 %1060, %1061
  br i1 %1062, label %1063, label %1201

; <label>:1063                                    ; preds = %1059
  %1064 = sitofp i32 %67 to float
  %1065 = sitofp i32 %70 to float
  %1066 = fadd fast float %1064, 5.000000e-01
  %1067 = fadd fast float %1065, 5.000000e-01
  %1068 = fdiv fast float %1066, %45
  %1069 = fdiv fast float %1067, %46
  %1070 = fmul fast float %1068, 2.000000e+00
  %1071 = fmul fast float %1069, 2.000000e+00
  %1072 = fadd fast float %1070, -1.000000e+00
  %1073 = fsub fast float 1.000000e+00, %1071
  %1074 = fmul fast float %1072, %35
  %1075 = call float @dx.op.tertiary.f32(i32 46, float %1073, float %31, float %1074)  ; FMad(a,b,c)
  %1076 = call float @dx.op.tertiary.f32(i32 46, float %88, float %27, float %1075)  ; FMad(a,b,c)
  %1077 = fadd fast float %1076, %23
  %1078 = call float @dx.op.unary.f32(i32 6, float %1077)  ; FAbs(value)
  %1079 = fcmp fast ogt float %1078, 0x3EB0C6F7A0000000
  br i1 %1079, label %1080, label %1201

; <label>:1080                                    ; preds = %1063
  %1081 = fmul fast float %1072, %34
  %1082 = call float @dx.op.tertiary.f32(i32 46, float %1073, float %30, float %1081)  ; FMad(a,b,c)
  %1083 = call float @dx.op.tertiary.f32(i32 46, float %88, float %26, float %1082)  ; FMad(a,b,c)
  %1084 = fadd fast float %1083, %22
  %1085 = fmul fast float %1072, %33
  %1086 = call float @dx.op.tertiary.f32(i32 46, float %1073, float %29, float %1085)  ; FMad(a,b,c)
  %1087 = call float @dx.op.tertiary.f32(i32 46, float %88, float %25, float %1086)  ; FMad(a,b,c)
  %1088 = fadd fast float %1087, %21
  %1089 = fmul fast float %1072, %32
  %1090 = call float @dx.op.tertiary.f32(i32 46, float %1073, float %28, float %1089)  ; FMad(a,b,c)
  %1091 = call float @dx.op.tertiary.f32(i32 46, float %88, float %24, float %1090)  ; FMad(a,b,c)
  %1092 = fadd fast float %1091, %20
  %1093 = fdiv fast float %1092, %1077
  %1094 = fdiv fast float %1088, %1077
  %1095 = fdiv fast float %1084, %1077
  %1096 = fsub fast float %1093, %17
  %1097 = fsub fast float %1094, %18
  %1098 = fsub fast float %1095, %19
  %1099 = fmul fast float %1096, %1096
  %1100 = fmul fast float %1097, %1097
  %1101 = fadd fast float %1100, %1099
  %1102 = fmul fast float %1098, %1098
  %1103 = fadd fast float %1101, %1102
  %1104 = call float @dx.op.unary.f32(i32 24, float %1103)  ; Sqrt(value)
  %1105 = fsub fast float %1104, %9
  %1106 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1105)  ; FMax(a,b)
  %1107 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1107, label %1108, label %1131

; <label>:1108                                    ; preds = %1080
  %1109 = call float @dx.op.unary.f32(i32 6, float %1097)  ; FAbs(value)
  %1110 = fmul fast float %1109, %11
  %1111 = fcmp fast olt float %1110, 0x3F50624DE0000000
  br i1 %1111, label %1112, label %1115

; <label>:1112                                    ; preds = %1108
  %1113 = fmul fast float %1110, 5.000000e-01
  %1114 = fsub fast float 1.000000e+00, %1113
  br label %1120

; <label>:1115                                    ; preds = %1108
  %1116 = fmul fast float %1110, 0xBFF7154760000000
  %1117 = call float @dx.op.unary.f32(i32 21, float %1116)  ; Exp(value)
  %1118 = fsub fast float 1.000000e+00, %1117
  %1119 = fdiv fast float %1118, %1110
  br label %1120

; <label>:1120                                    ; preds = %1115, %1112
  %1121 = phi float [ %1114, %1112 ], [ %1119, %1115 ]
  %1122 = call float @dx.op.binary.f32(i32 36, float %1094, float %18)  ; FMin(a,b)
  %1123 = fsub fast float %1122, %10
  %1124 = fmul fast float %11, %1123
  %1125 = fsub fast float -0.000000e+00, %1124
  %1126 = call float @dx.op.binary.f32(i32 35, float %1125, float -4.000000e+01)  ; FMax(a,b)
  %1127 = call float @dx.op.binary.f32(i32 36, float %1126, float 5.000000e+00)  ; FMin(a,b)
  %1128 = fmul fast float %1127, 0x3FF7154760000000
  %1129 = call float @dx.op.unary.f32(i32 21, float %1128)  ; Exp(value)
  %1130 = fmul fast float %1129, %1121
  br label %1131

; <label>:1131                                    ; preds = %1120, %1080
  %1132 = phi float [ %1130, %1120 ], [ 1.000000e+00, %1080 ]
  %1133 = fmul fast float %1106, %16
  %1134 = fmul fast float %1133, %1132
  %1135 = fcmp fast ole float %1104, %9
  %1136 = fcmp fast olt float %1104, 0x3F1A36E2E0000000
  %1137 = or i1 %1135, %1136
  br i1 %1137, label %1184, label %1138

; <label>:1138                                    ; preds = %1131
  %1139 = fdiv fast float %9, %1104
  %1140 = fmul fast float %1139, %1096
  %1141 = fmul fast float %1139, %1097
  %1142 = fmul fast float %1139, %1098
  %1143 = fadd fast float %1140, %17
  %1144 = fadd fast float %1141, %18
  %1145 = fadd fast float %1142, %19
  %1146 = fadd fast float %1143, -9.000000e+02
  %1147 = fadd fast float %1144, -1.500000e+01
  %1148 = fadd fast float %1145, -7.500000e+02
  %1149 = fmul fast float %1146, 0x3F62345680000000
  %1150 = fmul fast float %1147, 0x3F62345680000000
  %1151 = fmul fast float %1148, 0x3F62345680000000
  %1152 = call float @dx.op.dot3.f32(i32 55, float %1149, float %1150, float %1151, float %1149, float %1150, float %1151)  ; Dot3(ax,ay,az,bx,by,bz)
  %1153 = fsub fast float 1.000000e+00, %1152
  %1154 = call float @dx.op.unary.f32(i32 7, float %1153)  ; Saturate(value)
  %1155 = fmul fast float %1154, %1154
  %1156 = fadd fast float %1143, %1093
  %1157 = fadd fast float %1144, %1094
  %1158 = fadd fast float %1145, %1095
  %1159 = fmul fast float %1156, 0x3F52345680000000
  %1160 = fadd fast float %1159, -2.000000e+00
  %1161 = fmul fast float %1157, 0x3F52345680000000
  %1162 = fadd fast float %1161, 0xBFA1111120000000
  %1163 = fmul fast float %1158, 0x3F52345680000000
  %1164 = fadd fast float %1163, 0xBFFAAAAAC0000000
  %1165 = call float @dx.op.dot3.f32(i32 55, float %1160, float %1162, float %1164, float %1160, float %1162, float %1164)  ; Dot3(ax,ay,az,bx,by,bz)
  %1166 = fsub fast float 1.000000e+00, %1165
  %1167 = call float @dx.op.unary.f32(i32 7, float %1166)  ; Saturate(value)
  %1168 = fmul fast float %1167, %1167
  %1169 = fmul fast float %1168, 4.000000e+00
  %1170 = fadd fast float %1169, %1155
  %1171 = fadd fast float %1093, -9.000000e+02
  %1172 = fadd fast float %1094, -1.500000e+01
  %1173 = fadd fast float %1095, -7.500000e+02
  %1174 = fmul fast float %1171, 0x3F62345680000000
  %1175 = fmul fast float %1172, 0x3F62345680000000
  %1176 = fmul fast float %1173, 0x3F62345680000000
  %1177 = call float @dx.op.dot3.f32(i32 55, float %1174, float %1175, float %1176, float %1174, float %1175, float %1176)  ; Dot3(ax,ay,az,bx,by,bz)
  %1178 = fsub fast float 1.000000e+00, %1177
  %1179 = call float @dx.op.unary.f32(i32 7, float %1178)  ; Saturate(value)
  %1180 = fmul fast float %1179, %1179
  %1181 = fadd fast float %1170, %1180
  %1182 = fmul fast float %1105, 0x3F25D867E0000000
  %1183 = fmul fast float %1182, %1181
  br label %1184

; <label>:1184                                    ; preds = %1138, %1131
  %1185 = phi float [ %1183, %1138 ], [ 0.000000e+00, %1131 ]
  %1186 = fadd fast float %1185, %1134
  %1187 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1186)  ; FMin(a,b)
  %1188 = fmul fast float %1187, 0xBFF7154760000000
  %1189 = call float @dx.op.unary.f32(i32 21, float %1188)  ; Exp(value)
  %1190 = fsub fast float 1.000000e+00, %1189
  %1191 = call float @dx.op.binary.f32(i32 36, float %12, float %1190)  ; FMin(a,b)
  %1192 = fsub fast float %13, %1052
  %1193 = fsub fast float %14, %1053
  %1194 = fsub fast float %15, %1054
  %1195 = fmul fast float %1191, %1192
  %1196 = fmul fast float %1191, %1193
  %1197 = fmul fast float %1191, %1194
  %1198 = fadd fast float %1195, %1052
  %1199 = fadd fast float %1196, %1053
  %1200 = fadd fast float %1197, %1054
  br label %1201

; <label>:1201                                    ; preds = %1184, %1063, %1059
  %1202 = phi float [ %1198, %1184 ], [ %1052, %1063 ], [ %1052, %1059 ]
  %1203 = phi float [ %1199, %1184 ], [ %1053, %1063 ], [ %1053, %1059 ]
  %1204 = phi float [ %1200, %1184 ], [ %1054, %1063 ], [ %1054, %1059 ]
  %1205 = fadd fast float %5, 1.000000e+00
  %1206 = fadd fast float %6, 1.000000e+00
  %1207 = fsub fast float 1.000000e+00, %5
  %1208 = fmul fast float %36, %1205
  %1209 = fmul fast float %36, %1206
  %1210 = fmul fast float %36, %1207
  %1211 = fmul fast float %1208, %1202
  %1212 = fmul fast float %1209, %1203
  %1213 = fmul fast float %1210, %1204
  %1214 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1214, label %1240, label %1215

; <label>:1215                                    ; preds = %1201
  %1216 = fmul fast float %1211, 0x4004147AE0000000
  %1217 = fmul fast float %1212, 0x4004147AE0000000
  %1218 = fmul fast float %1213, 0x4004147AE0000000
  %1219 = fadd fast float %1216, 0x3F9EB851E0000000
  %1220 = fadd fast float %1217, 0x3F9EB851E0000000
  %1221 = fadd fast float %1218, 0x3F9EB851E0000000
  %1222 = fmul fast float %1219, %1211
  %1223 = fmul fast float %1220, %1212
  %1224 = fmul fast float %1221, %1213
  %1225 = fmul fast float %1211, 0x400370A3E0000000
  %1226 = fmul fast float %1212, 0x400370A3E0000000
  %1227 = fmul fast float %1213, 0x400370A3E0000000
  %1228 = fadd fast float %1225, 0x3FE2E147A0000000
  %1229 = fadd fast float %1226, 0x3FE2E147A0000000
  %1230 = fadd fast float %1227, 0x3FE2E147A0000000
  %1231 = fmul fast float %1228, %1211
  %1232 = fmul fast float %1229, %1212
  %1233 = fmul fast float %1230, %1213
  %1234 = fadd fast float %1231, 0x3FC1EB8520000000
  %1235 = fadd fast float %1232, 0x3FC1EB8520000000
  %1236 = fadd fast float %1233, 0x3FC1EB8520000000
  %1237 = fdiv fast float %1222, %1234
  %1238 = fdiv fast float %1223, %1235
  %1239 = fdiv fast float %1224, %1236
  br label %1240

; <label>:1240                                    ; preds = %1215, %1201
  %1241 = phi float [ %1237, %1215 ], [ %1211, %1201 ]
  %1242 = phi float [ %1238, %1215 ], [ %1212, %1201 ]
  %1243 = phi float [ %1239, %1215 ], [ %1213, %1201 ]
  %1244 = call float @dx.op.unary.f32(i32 7, float %1241)  ; Saturate(value)
  %1245 = call float @dx.op.unary.f32(i32 7, float %1242)  ; Saturate(value)
  %1246 = call float @dx.op.unary.f32(i32 7, float %1243)  ; Saturate(value)
  %1247 = call float @dx.op.dot3.f32(i32 55, float %1244, float %1245, float %1246, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1248 = fsub fast float %1244, %1247
  %1249 = fsub fast float %1245, %1247
  %1250 = fsub fast float %1246, %1247
  %1251 = fmul fast float %1248, %8
  %1252 = fmul fast float %1249, %8
  %1253 = fmul fast float %1250, %8
  %1254 = fadd fast float %1251, %1247
  %1255 = fadd fast float %1252, %1247
  %1256 = fadd fast float %1253, %1247
  %1257 = call float @dx.op.unary.f32(i32 7, float %1254)  ; Saturate(value)
  %1258 = call float @dx.op.unary.f32(i32 7, float %1255)  ; Saturate(value)
  %1259 = call float @dx.op.unary.f32(i32 7, float %1256)  ; Saturate(value)
  %1260 = fadd fast float %1257, 0xBFC70A3D80000000
  %1261 = fadd fast float %1258, 0xBFC70A3D80000000
  %1262 = fadd fast float %1259, 0xBFC70A3D80000000
  %1263 = fmul fast float %1260, %7
  %1264 = fmul fast float %1261, %7
  %1265 = fmul fast float %1262, %7
  %1266 = fadd fast float %1263, 0x3FC70A3D80000000
  %1267 = fadd fast float %1264, 0x3FC70A3D80000000
  %1268 = fadd fast float %1265, 0x3FC70A3D80000000
  %1269 = call float @dx.op.unary.f32(i32 7, float %1266)  ; Saturate(value)
  %1270 = call float @dx.op.unary.f32(i32 7, float %1267)  ; Saturate(value)
  %1271 = call float @dx.op.unary.f32(i32 7, float %1268)  ; Saturate(value)
  %1272 = fcmp fast ogt float %1269, 0x3F69A5C380000000
  %1273 = fcmp fast ogt float %1270, 0x3F69A5C380000000
  %1274 = fcmp fast ogt float %1271, 0x3F69A5C380000000
  %1275 = select i1 %1272, float 0.000000e+00, float 1.000000e+00
  %1276 = select i1 %1273, float 0.000000e+00, float 1.000000e+00
  %1277 = select i1 %1274, float 0.000000e+00, float 1.000000e+00
  %1278 = fmul fast float %1269, 0x4029D70A40000000
  %1279 = fmul fast float %1270, 0x4029D70A40000000
  %1280 = fmul fast float %1271, 0x4029D70A40000000
  %1281 = call float @dx.op.binary.f32(i32 35, float %1269, float 0.000000e+00)  ; FMax(a,b)
  %1282 = call float @dx.op.binary.f32(i32 35, float %1270, float 0.000000e+00)  ; FMax(a,b)
  %1283 = call float @dx.op.binary.f32(i32 35, float %1271, float 0.000000e+00)  ; FMax(a,b)
  %1284 = call float @dx.op.unary.f32(i32 23, float %1281)  ; Log(value)
  %1285 = call float @dx.op.unary.f32(i32 23, float %1282)  ; Log(value)
  %1286 = call float @dx.op.unary.f32(i32 23, float %1283)  ; Log(value)
  %1287 = fmul fast float %1284, 0x3FDAAAAAA0000000
  %1288 = fmul fast float %1285, 0x3FDAAAAAA0000000
  %1289 = fmul fast float %1286, 0x3FDAAAAAA0000000
  %1290 = call float @dx.op.unary.f32(i32 21, float %1287)  ; Exp(value)
  %1291 = call float @dx.op.unary.f32(i32 21, float %1288)  ; Exp(value)
  %1292 = call float @dx.op.unary.f32(i32 21, float %1289)  ; Exp(value)
  %1293 = fmul fast float %1290, 0x3FF0E147A0000000
  %1294 = fmul fast float %1291, 0x3FF0E147A0000000
  %1295 = fmul fast float %1292, 0x3FF0E147A0000000
  %1296 = fadd fast float %1293, 0xBFAC28F5C0000000
  %1297 = fadd fast float %1294, 0xBFAC28F5C0000000
  %1298 = fadd fast float %1295, 0xBFAC28F5C0000000
  %1299 = fsub fast float %1278, %1296
  %1300 = fsub fast float %1279, %1297
  %1301 = fsub fast float %1280, %1298
  %1302 = fmul fast float %1299, %1275
  %1303 = fmul fast float %1300, %1276
  %1304 = fmul fast float %1301, %1277
  %1305 = fadd fast float %1302, %1296
  %1306 = fadd fast float %1303, %1297
  %1307 = fadd fast float %1304, %1298
  br label %1308

; <label>:1308                                    ; preds = %1240, %1057
  %1309 = phi float [ %1052, %1057 ], [ %1305, %1240 ]
  %1310 = phi float [ %1053, %1057 ], [ %1306, %1240 ]
  %1311 = phi float [ %1054, %1057 ], [ %1307, %1240 ]
  %1312 = phi float [ %1058, %1057 ], [ %1055, %1240 ]
  %1313 = fcmp fast ogt float %1309, 0x3FA4B5DCC0000000
  %1314 = fcmp fast ogt float %1310, 0x3FA4B5DCC0000000
  %1315 = fcmp fast ogt float %1311, 0x3FA4B5DCC0000000
  %1316 = select i1 %1313, float 0.000000e+00, float 1.000000e+00
  %1317 = select i1 %1314, float 0.000000e+00, float 1.000000e+00
  %1318 = select i1 %1315, float 0.000000e+00, float 1.000000e+00
  %1319 = fmul fast float %1309, 0x3FB3D07220000000
  %1320 = fmul fast float %1310, 0x3FB3D07220000000
  %1321 = fmul fast float %1311, 0x3FB3D07220000000
  %1322 = fadd fast float %1309, 0x3FAC28F5C0000000
  %1323 = fadd fast float %1310, 0x3FAC28F5C0000000
  %1324 = fadd fast float %1311, 0x3FAC28F5C0000000
  %1325 = fmul fast float %1322, 0x3FEE54EDE0000000
  %1326 = fmul fast float %1323, 0x3FEE54EDE0000000
  %1327 = fmul fast float %1324, 0x3FEE54EDE0000000
  %1328 = call float @dx.op.unary.f32(i32 23, float %1325)  ; Log(value)
  %1329 = call float @dx.op.unary.f32(i32 23, float %1326)  ; Log(value)
  %1330 = call float @dx.op.unary.f32(i32 23, float %1327)  ; Log(value)
  %1331 = fmul fast float %1328, 0x4003333340000000
  %1332 = fmul fast float %1329, 0x4003333340000000
  %1333 = fmul fast float %1330, 0x4003333340000000
  %1334 = call float @dx.op.unary.f32(i32 21, float %1331)  ; Exp(value)
  %1335 = call float @dx.op.unary.f32(i32 21, float %1332)  ; Exp(value)
  %1336 = call float @dx.op.unary.f32(i32 21, float %1333)  ; Exp(value)
  %1337 = fsub fast float %1319, %1334
  %1338 = fsub fast float %1320, %1335
  %1339 = fsub fast float %1321, %1336
  %1340 = fmul fast float %1337, %1316
  %1341 = fmul fast float %1338, %1317
  %1342 = fmul fast float %1339, %1318
  %1343 = fadd fast float %1340, %1334
  %1344 = fadd fast float %1341, %1335
  %1345 = fadd fast float %1342, %1336
  %1346 = fmul fast float %458, %162
  %1347 = fmul fast float %459, %162
  %1348 = fmul fast float %460, %162
  %1349 = fmul fast float %753, %163
  %1350 = fmul fast float %754, %163
  %1351 = fmul fast float %755, %163
  %1352 = fadd fast float %1349, %1346
  %1353 = fadd fast float %1350, %1347
  %1354 = fadd fast float %1351, %1348
  %1355 = fmul fast float %1048, %164
  %1356 = fmul fast float %1049, %164
  %1357 = fmul fast float %1050, %164
  %1358 = fadd fast float %1352, %1355
  %1359 = fadd fast float %1353, %1356
  %1360 = fadd fast float %1354, %1357
  %1361 = fmul fast float %1343, %165
  %1362 = fmul fast float %1344, %165
  %1363 = fmul fast float %1345, %165
  %1364 = fadd fast float %1358, %1361
  %1365 = fadd fast float %1359, %1362
  %1366 = fadd fast float %1360, %1363
  %1367 = fcmp fast ogt float %1364, 0x3F69A5C380000000
  %1368 = fcmp fast ogt float %1365, 0x3F69A5C380000000
  %1369 = fcmp fast ogt float %1366, 0x3F69A5C380000000
  %1370 = select i1 %1367, float 0.000000e+00, float 1.000000e+00
  %1371 = select i1 %1368, float 0.000000e+00, float 1.000000e+00
  %1372 = select i1 %1369, float 0.000000e+00, float 1.000000e+00
  %1373 = fmul fast float %1364, 0x4029D70A40000000
  %1374 = fmul fast float %1365, 0x4029D70A40000000
  %1375 = fmul fast float %1366, 0x4029D70A40000000
  %1376 = call float @dx.op.binary.f32(i32 35, float %1364, float 0.000000e+00)  ; FMax(a,b)
  %1377 = call float @dx.op.binary.f32(i32 35, float %1365, float 0.000000e+00)  ; FMax(a,b)
  %1378 = call float @dx.op.binary.f32(i32 35, float %1366, float 0.000000e+00)  ; FMax(a,b)
  %1379 = call float @dx.op.unary.f32(i32 23, float %1376)  ; Log(value)
  %1380 = call float @dx.op.unary.f32(i32 23, float %1377)  ; Log(value)
  %1381 = call float @dx.op.unary.f32(i32 23, float %1378)  ; Log(value)
  %1382 = fmul fast float %1379, 0x3FDAAAAAA0000000
  %1383 = fmul fast float %1380, 0x3FDAAAAAA0000000
  %1384 = fmul fast float %1381, 0x3FDAAAAAA0000000
  %1385 = call float @dx.op.unary.f32(i32 21, float %1382)  ; Exp(value)
  %1386 = call float @dx.op.unary.f32(i32 21, float %1383)  ; Exp(value)
  %1387 = call float @dx.op.unary.f32(i32 21, float %1384)  ; Exp(value)
  %1388 = fmul fast float %1385, 0x3FF0E147A0000000
  %1389 = fmul fast float %1386, 0x3FF0E147A0000000
  %1390 = fmul fast float %1387, 0x3FF0E147A0000000
  %1391 = fadd fast float %1388, 0xBFAC28F5C0000000
  %1392 = fadd fast float %1389, 0xBFAC28F5C0000000
  %1393 = fadd fast float %1390, 0xBFAC28F5C0000000
  %1394 = fsub fast float %1373, %1391
  %1395 = fsub fast float %1374, %1392
  %1396 = fsub fast float %1375, %1393
  %1397 = fmul fast float %1394, %1370
  %1398 = fmul fast float %1395, %1371
  %1399 = fmul fast float %1396, %1372
  %1400 = fadd fast float %1397, %1391
  %1401 = fadd fast float %1398, %1392
  %1402 = fadd fast float %1399, %1393
  %1403 = call float @dx.op.dot4.f32(i32 56, float %427, float %722, float %1017, float %1312, float %162, float %163, float %164, float %165)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %1400)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %1401)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %1402)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %1403)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %80)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare i1 @dx.op.isSpecialFloat.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !38, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, !37}
!36 = !{i32 9}
!37 = !{i32 3, i32 6}
!38 = !{!39, !40}
!39 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
!40 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !41}
!41 = !{i32 3, i32 1}
