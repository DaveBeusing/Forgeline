;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float   x   
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
;
; shader hash: 586bd6daffcd8f67f2155401adccc6a5
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=0
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 1
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40 }
;   output 3 depends on inputs: { 0, 1 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %40 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %41 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %42 = extractvalue %dx.types.Dimensions %41, 0
  %43 = extractvalue %dx.types.Dimensions %41, 1
  %44 = fptosi float %39 to i32
  %45 = fptosi float %40 to i32
  %46 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %44, i32 %45, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %47 = extractvalue %dx.types.ResRet.f32 %46, 0
  %48 = extractvalue %dx.types.ResRet.f32 %46, 1
  %49 = extractvalue %dx.types.ResRet.f32 %46, 2
  %50 = extractvalue %dx.types.ResRet.f32 %46, 3
  %51 = fcmp fast olt float %50, 0.000000e+00
  br i1 %51, label %52, label %54

; <label>:52                                      ; preds = %0
  %53 = fsub fast float -1.000000e+00, %50
  br label %1474

; <label>:54                                      ; preds = %0
  %55 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %44, i32 %45, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %56 = extractvalue %dx.types.ResRet.f32 %55, 0
  %57 = fcmp fast ogt float %37, 5.000000e-01
  %58 = fcmp fast olt float %56, 1.000000e+00
  %59 = and i1 %57, %58
  br i1 %59, label %60, label %200

; <label>:60                                      ; preds = %54
  %61 = sitofp i32 %44 to float
  %62 = sitofp i32 %45 to float
  %63 = fadd fast float %61, 5.000000e-01
  %64 = fadd fast float %62, 5.000000e-01
  %65 = uitofp i32 %42 to float
  %66 = uitofp i32 %43 to float
  %67 = fdiv fast float %63, %65
  %68 = fdiv fast float %64, %66
  %69 = fmul fast float %67, 2.000000e+00
  %70 = fmul fast float %68, 2.000000e+00
  %71 = fadd fast float %69, -1.000000e+00
  %72 = fsub fast float 1.000000e+00, %70
  %73 = fmul fast float %71, %34
  %74 = call float @dx.op.tertiary.f32(i32 46, float %72, float %30, float %73)  ; FMad(a,b,c)
  %75 = call float @dx.op.tertiary.f32(i32 46, float %56, float %26, float %74)  ; FMad(a,b,c)
  %76 = fadd fast float %75, %22
  %77 = call float @dx.op.unary.f32(i32 6, float %76)  ; FAbs(value)
  %78 = fcmp fast ogt float %77, 0x3EB0C6F7A0000000
  br i1 %78, label %79, label %200

; <label>:79                                      ; preds = %60
  %80 = fmul fast float %71, %33
  %81 = call float @dx.op.tertiary.f32(i32 46, float %72, float %29, float %80)  ; FMad(a,b,c)
  %82 = call float @dx.op.tertiary.f32(i32 46, float %56, float %25, float %81)  ; FMad(a,b,c)
  %83 = fadd fast float %82, %21
  %84 = fmul fast float %71, %32
  %85 = call float @dx.op.tertiary.f32(i32 46, float %72, float %28, float %84)  ; FMad(a,b,c)
  %86 = call float @dx.op.tertiary.f32(i32 46, float %56, float %24, float %85)  ; FMad(a,b,c)
  %87 = fadd fast float %86, %20
  %88 = fmul fast float %71, %31
  %89 = call float @dx.op.tertiary.f32(i32 46, float %72, float %27, float %88)  ; FMad(a,b,c)
  %90 = call float @dx.op.tertiary.f32(i32 46, float %56, float %23, float %89)  ; FMad(a,b,c)
  %91 = fadd fast float %90, %19
  %92 = fdiv fast float %91, %76
  %93 = fdiv fast float %87, %76
  %94 = fdiv fast float %83, %76
  %95 = fsub fast float %92, %16
  %96 = fsub fast float %93, %17
  %97 = fsub fast float %94, %18
  %98 = fmul fast float %95, %95
  %99 = fmul fast float %96, %96
  %100 = fadd fast float %99, %98
  %101 = fmul fast float %97, %97
  %102 = fadd fast float %100, %101
  %103 = call float @dx.op.unary.f32(i32 24, float %102)  ; Sqrt(value)
  %104 = fsub fast float %103, %8
  %105 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %104)  ; FMax(a,b)
  %106 = fcmp fast ogt float %38, 1.500000e+00
  br i1 %106, label %107, label %130

; <label>:107                                     ; preds = %79
  %108 = call float @dx.op.unary.f32(i32 6, float %96)  ; FAbs(value)
  %109 = fmul fast float %108, %10
  %110 = fcmp fast olt float %109, 0x3F50624DE0000000
  br i1 %110, label %111, label %114

; <label>:111                                     ; preds = %107
  %112 = fmul fast float %109, 5.000000e-01
  %113 = fsub fast float 1.000000e+00, %112
  br label %119

; <label>:114                                     ; preds = %107
  %115 = fmul fast float %109, 0xBFF7154760000000
  %116 = call float @dx.op.unary.f32(i32 21, float %115)  ; Exp(value)
  %117 = fsub fast float 1.000000e+00, %116
  %118 = fdiv fast float %117, %109
  br label %119

; <label>:119                                     ; preds = %114, %111
  %120 = phi float [ %113, %111 ], [ %118, %114 ]
  %121 = call float @dx.op.binary.f32(i32 36, float %93, float %17)  ; FMin(a,b)
  %122 = fsub fast float %121, %9
  %123 = fmul fast float %10, %122
  %124 = fsub fast float -0.000000e+00, %123
  %125 = call float @dx.op.binary.f32(i32 35, float %124, float -4.000000e+01)  ; FMax(a,b)
  %126 = call float @dx.op.binary.f32(i32 36, float %125, float 5.000000e+00)  ; FMin(a,b)
  %127 = fmul fast float %126, 0x3FF7154760000000
  %128 = call float @dx.op.unary.f32(i32 21, float %127)  ; Exp(value)
  %129 = fmul fast float %128, %120
  br label %130

; <label>:130                                     ; preds = %119, %79
  %131 = phi float [ %129, %119 ], [ 1.000000e+00, %79 ]
  %132 = fmul fast float %105, %15
  %133 = fmul fast float %132, %131
  %134 = fcmp fast ole float %103, %8
  %135 = fcmp fast olt float %103, 0x3F1A36E2E0000000
  %136 = or i1 %134, %135
  br i1 %136, label %183, label %137

; <label>:137                                     ; preds = %130
  %138 = fdiv fast float %8, %103
  %139 = fmul fast float %138, %95
  %140 = fmul fast float %138, %96
  %141 = fmul fast float %138, %97
  %142 = fadd fast float %139, %16
  %143 = fadd fast float %140, %17
  %144 = fadd fast float %141, %18
  %145 = fadd fast float %142, -9.000000e+02
  %146 = fadd fast float %143, -1.500000e+01
  %147 = fadd fast float %144, -7.500000e+02
  %148 = fmul fast float %145, 0x3F62345680000000
  %149 = fmul fast float %146, 0x3F62345680000000
  %150 = fmul fast float %147, 0x3F62345680000000
  %151 = call float @dx.op.dot3.f32(i32 55, float %148, float %149, float %150, float %148, float %149, float %150)  ; Dot3(ax,ay,az,bx,by,bz)
  %152 = fsub fast float 1.000000e+00, %151
  %153 = call float @dx.op.unary.f32(i32 7, float %152)  ; Saturate(value)
  %154 = fmul fast float %153, %153
  %155 = fadd fast float %142, %92
  %156 = fadd fast float %143, %93
  %157 = fadd fast float %144, %94
  %158 = fmul fast float %155, 0x3F52345680000000
  %159 = fadd fast float %158, -2.000000e+00
  %160 = fmul fast float %156, 0x3F52345680000000
  %161 = fadd fast float %160, 0xBFA1111120000000
  %162 = fmul fast float %157, 0x3F52345680000000
  %163 = fadd fast float %162, 0xBFFAAAAAC0000000
  %164 = call float @dx.op.dot3.f32(i32 55, float %159, float %161, float %163, float %159, float %161, float %163)  ; Dot3(ax,ay,az,bx,by,bz)
  %165 = fsub fast float 1.000000e+00, %164
  %166 = call float @dx.op.unary.f32(i32 7, float %165)  ; Saturate(value)
  %167 = fmul fast float %166, %166
  %168 = fmul fast float %167, 4.000000e+00
  %169 = fadd fast float %168, %154
  %170 = fadd fast float %92, -9.000000e+02
  %171 = fadd fast float %93, -1.500000e+01
  %172 = fadd fast float %94, -7.500000e+02
  %173 = fmul fast float %170, 0x3F62345680000000
  %174 = fmul fast float %171, 0x3F62345680000000
  %175 = fmul fast float %172, 0x3F62345680000000
  %176 = call float @dx.op.dot3.f32(i32 55, float %173, float %174, float %175, float %173, float %174, float %175)  ; Dot3(ax,ay,az,bx,by,bz)
  %177 = fsub fast float 1.000000e+00, %176
  %178 = call float @dx.op.unary.f32(i32 7, float %177)  ; Saturate(value)
  %179 = fmul fast float %178, %178
  %180 = fadd fast float %169, %179
  %181 = fmul fast float %104, 0x3F25D867E0000000
  %182 = fmul fast float %181, %180
  br label %183

; <label>:183                                     ; preds = %137, %130
  %184 = phi float [ %182, %137 ], [ 0.000000e+00, %130 ]
  %185 = fadd fast float %184, %133
  %186 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %185)  ; FMin(a,b)
  %187 = fmul fast float %186, 0xBFF7154760000000
  %188 = call float @dx.op.unary.f32(i32 21, float %187)  ; Exp(value)
  %189 = fsub fast float 1.000000e+00, %188
  %190 = call float @dx.op.binary.f32(i32 36, float %11, float %189)  ; FMin(a,b)
  %191 = fsub fast float %12, %47
  %192 = fsub fast float %13, %48
  %193 = fsub fast float %14, %49
  %194 = fmul fast float %190, %191
  %195 = fmul fast float %190, %192
  %196 = fmul fast float %190, %193
  %197 = fadd fast float %194, %47
  %198 = fadd fast float %195, %48
  %199 = fadd fast float %196, %49
  br label %200

; <label>:200                                     ; preds = %183, %60, %54
  %201 = phi float [ %197, %183 ], [ %47, %60 ], [ %47, %54 ]
  %202 = phi float [ %198, %183 ], [ %48, %60 ], [ %48, %54 ]
  %203 = phi float [ %199, %183 ], [ %49, %60 ], [ %49, %54 ]
  %204 = fadd fast float %4, 1.000000e+00
  %205 = fadd fast float %5, 1.000000e+00
  %206 = fsub fast float 1.000000e+00, %4
  %207 = fmul fast float %35, %204
  %208 = fmul fast float %35, %205
  %209 = fmul fast float %35, %206
  %210 = fmul fast float %207, %201
  %211 = fmul fast float %208, %202
  %212 = fmul fast float %209, %203
  %213 = fcmp fast ult float %36, 5.000000e-01
  br i1 %213, label %239, label %214

; <label>:214                                     ; preds = %200
  %215 = fmul fast float %210, 0x4004147AE0000000
  %216 = fmul fast float %211, 0x4004147AE0000000
  %217 = fmul fast float %212, 0x4004147AE0000000
  %218 = fadd fast float %215, 0x3F9EB851E0000000
  %219 = fadd fast float %216, 0x3F9EB851E0000000
  %220 = fadd fast float %217, 0x3F9EB851E0000000
  %221 = fmul fast float %218, %210
  %222 = fmul fast float %219, %211
  %223 = fmul fast float %220, %212
  %224 = fmul fast float %210, 0x400370A3E0000000
  %225 = fmul fast float %211, 0x400370A3E0000000
  %226 = fmul fast float %212, 0x400370A3E0000000
  %227 = fadd fast float %224, 0x3FE2E147A0000000
  %228 = fadd fast float %225, 0x3FE2E147A0000000
  %229 = fadd fast float %226, 0x3FE2E147A0000000
  %230 = fmul fast float %227, %210
  %231 = fmul fast float %228, %211
  %232 = fmul fast float %229, %212
  %233 = fadd fast float %230, 0x3FC1EB8520000000
  %234 = fadd fast float %231, 0x3FC1EB8520000000
  %235 = fadd fast float %232, 0x3FC1EB8520000000
  %236 = fdiv fast float %221, %233
  %237 = fdiv fast float %222, %234
  %238 = fdiv fast float %223, %235
  br label %239

; <label>:239                                     ; preds = %214, %200
  %240 = phi float [ %236, %214 ], [ %210, %200 ]
  %241 = phi float [ %237, %214 ], [ %211, %200 ]
  %242 = phi float [ %238, %214 ], [ %212, %200 ]
  %243 = call float @dx.op.unary.f32(i32 7, float %240)  ; Saturate(value)
  %244 = call float @dx.op.unary.f32(i32 7, float %241)  ; Saturate(value)
  %245 = call float @dx.op.unary.f32(i32 7, float %242)  ; Saturate(value)
  %246 = call float @dx.op.dot3.f32(i32 55, float %243, float %244, float %245, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %247 = fsub fast float %243, %246
  %248 = fsub fast float %244, %246
  %249 = fsub fast float %245, %246
  %250 = fmul fast float %247, %7
  %251 = fmul fast float %248, %7
  %252 = fmul fast float %249, %7
  %253 = fadd fast float %250, %246
  %254 = fadd fast float %251, %246
  %255 = fadd fast float %252, %246
  %256 = call float @dx.op.unary.f32(i32 7, float %253)  ; Saturate(value)
  %257 = call float @dx.op.unary.f32(i32 7, float %254)  ; Saturate(value)
  %258 = call float @dx.op.unary.f32(i32 7, float %255)  ; Saturate(value)
  %259 = fadd fast float %256, 0xBFC70A3D80000000
  %260 = fadd fast float %257, 0xBFC70A3D80000000
  %261 = fadd fast float %258, 0xBFC70A3D80000000
  %262 = fmul fast float %259, %6
  %263 = fmul fast float %260, %6
  %264 = fmul fast float %261, %6
  %265 = fadd fast float %262, 0x3FC70A3D80000000
  %266 = fadd fast float %263, 0x3FC70A3D80000000
  %267 = fadd fast float %264, 0x3FC70A3D80000000
  %268 = call float @dx.op.unary.f32(i32 7, float %265)  ; Saturate(value)
  %269 = call float @dx.op.unary.f32(i32 7, float %266)  ; Saturate(value)
  %270 = call float @dx.op.unary.f32(i32 7, float %267)  ; Saturate(value)
  %271 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %271, label %272, label %1434

; <label>:272                                     ; preds = %239
  %273 = add i32 %45, -1
  %274 = add i32 %42, -1
  %275 = add i32 %43, -1
  %276 = call i32 @dx.op.binary.i32(i32 37, i32 %44, i32 0)  ; IMax(a,b)
  %277 = call i32 @dx.op.binary.i32(i32 37, i32 %273, i32 0)  ; IMax(a,b)
  %278 = call i32 @dx.op.binary.i32(i32 38, i32 %276, i32 %274)  ; IMin(a,b)
  %279 = call i32 @dx.op.binary.i32(i32 38, i32 %277, i32 %275)  ; IMin(a,b)
  %280 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %278, i32 %279, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %281 = extractvalue %dx.types.ResRet.f32 %280, 0
  %282 = extractvalue %dx.types.ResRet.f32 %280, 1
  %283 = extractvalue %dx.types.ResRet.f32 %280, 2
  %284 = extractvalue %dx.types.ResRet.f32 %280, 3
  %285 = fcmp fast olt float %284, 0.000000e+00
  br i1 %285, label %286, label %320

; <label>:286                                     ; preds = %272
  %287 = fcmp fast ogt float %281, 0x3FA4B5DCC0000000
  %288 = fcmp fast ogt float %282, 0x3FA4B5DCC0000000
  %289 = fcmp fast ogt float %283, 0x3FA4B5DCC0000000
  %290 = select i1 %287, float 0.000000e+00, float 1.000000e+00
  %291 = select i1 %288, float 0.000000e+00, float 1.000000e+00
  %292 = select i1 %289, float 0.000000e+00, float 1.000000e+00
  %293 = fmul fast float %281, 0x3FB3D07220000000
  %294 = fmul fast float %282, 0x3FB3D07220000000
  %295 = fmul fast float %283, 0x3FB3D07220000000
  %296 = fadd fast float %281, 0x3FAC28F5C0000000
  %297 = fadd fast float %282, 0x3FAC28F5C0000000
  %298 = fadd fast float %283, 0x3FAC28F5C0000000
  %299 = fmul fast float %296, 0x3FEE54EDE0000000
  %300 = fmul fast float %297, 0x3FEE54EDE0000000
  %301 = fmul fast float %298, 0x3FEE54EDE0000000
  %302 = call float @dx.op.unary.f32(i32 23, float %299)  ; Log(value)
  %303 = call float @dx.op.unary.f32(i32 23, float %300)  ; Log(value)
  %304 = call float @dx.op.unary.f32(i32 23, float %301)  ; Log(value)
  %305 = fmul fast float %302, 0x4003333340000000
  %306 = fmul fast float %303, 0x4003333340000000
  %307 = fmul fast float %304, 0x4003333340000000
  %308 = call float @dx.op.unary.f32(i32 21, float %305)  ; Exp(value)
  %309 = call float @dx.op.unary.f32(i32 21, float %306)  ; Exp(value)
  %310 = call float @dx.op.unary.f32(i32 21, float %307)  ; Exp(value)
  %311 = fsub fast float %293, %308
  %312 = fsub fast float %294, %309
  %313 = fsub fast float %295, %310
  %314 = fmul fast float %311, %290
  %315 = fmul fast float %312, %291
  %316 = fmul fast float %313, %292
  %317 = fadd fast float %314, %308
  %318 = fadd fast float %315, %309
  %319 = fadd fast float %316, %310
  br label %537

; <label>:320                                     ; preds = %272
  %321 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %278, i32 %279, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %322 = extractvalue %dx.types.ResRet.f32 %321, 0
  %323 = fcmp fast ogt float %37, 5.000000e-01
  %324 = fcmp fast olt float %322, 1.000000e+00
  %325 = and i1 %323, %324
  br i1 %325, label %326, label %466

; <label>:326                                     ; preds = %320
  %327 = sitofp i32 %278 to float
  %328 = sitofp i32 %279 to float
  %329 = fadd fast float %327, 5.000000e-01
  %330 = fadd fast float %328, 5.000000e-01
  %331 = uitofp i32 %42 to float
  %332 = uitofp i32 %43 to float
  %333 = fdiv fast float %329, %331
  %334 = fdiv fast float %330, %332
  %335 = fmul fast float %333, 2.000000e+00
  %336 = fmul fast float %334, 2.000000e+00
  %337 = fadd fast float %335, -1.000000e+00
  %338 = fsub fast float 1.000000e+00, %336
  %339 = fmul fast float %337, %34
  %340 = call float @dx.op.tertiary.f32(i32 46, float %338, float %30, float %339)  ; FMad(a,b,c)
  %341 = call float @dx.op.tertiary.f32(i32 46, float %322, float %26, float %340)  ; FMad(a,b,c)
  %342 = fadd fast float %341, %22
  %343 = call float @dx.op.unary.f32(i32 6, float %342)  ; FAbs(value)
  %344 = fcmp fast ogt float %343, 0x3EB0C6F7A0000000
  br i1 %344, label %345, label %466

; <label>:345                                     ; preds = %326
  %346 = fmul fast float %337, %33
  %347 = call float @dx.op.tertiary.f32(i32 46, float %338, float %29, float %346)  ; FMad(a,b,c)
  %348 = call float @dx.op.tertiary.f32(i32 46, float %322, float %25, float %347)  ; FMad(a,b,c)
  %349 = fadd fast float %348, %21
  %350 = fmul fast float %337, %32
  %351 = call float @dx.op.tertiary.f32(i32 46, float %338, float %28, float %350)  ; FMad(a,b,c)
  %352 = call float @dx.op.tertiary.f32(i32 46, float %322, float %24, float %351)  ; FMad(a,b,c)
  %353 = fadd fast float %352, %20
  %354 = fmul fast float %337, %31
  %355 = call float @dx.op.tertiary.f32(i32 46, float %338, float %27, float %354)  ; FMad(a,b,c)
  %356 = call float @dx.op.tertiary.f32(i32 46, float %322, float %23, float %355)  ; FMad(a,b,c)
  %357 = fadd fast float %356, %19
  %358 = fdiv fast float %357, %342
  %359 = fdiv fast float %353, %342
  %360 = fdiv fast float %349, %342
  %361 = fsub fast float %358, %16
  %362 = fsub fast float %359, %17
  %363 = fsub fast float %360, %18
  %364 = fmul fast float %361, %361
  %365 = fmul fast float %362, %362
  %366 = fadd fast float %365, %364
  %367 = fmul fast float %363, %363
  %368 = fadd fast float %366, %367
  %369 = call float @dx.op.unary.f32(i32 24, float %368)  ; Sqrt(value)
  %370 = fsub fast float %369, %8
  %371 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %370)  ; FMax(a,b)
  %372 = fcmp fast ogt float %38, 1.500000e+00
  br i1 %372, label %373, label %396

; <label>:373                                     ; preds = %345
  %374 = call float @dx.op.unary.f32(i32 6, float %362)  ; FAbs(value)
  %375 = fmul fast float %374, %10
  %376 = fcmp fast olt float %375, 0x3F50624DE0000000
  br i1 %376, label %377, label %380

; <label>:377                                     ; preds = %373
  %378 = fmul fast float %375, 5.000000e-01
  %379 = fsub fast float 1.000000e+00, %378
  br label %385

; <label>:380                                     ; preds = %373
  %381 = fmul fast float %375, 0xBFF7154760000000
  %382 = call float @dx.op.unary.f32(i32 21, float %381)  ; Exp(value)
  %383 = fsub fast float 1.000000e+00, %382
  %384 = fdiv fast float %383, %375
  br label %385

; <label>:385                                     ; preds = %380, %377
  %386 = phi float [ %379, %377 ], [ %384, %380 ]
  %387 = call float @dx.op.binary.f32(i32 36, float %359, float %17)  ; FMin(a,b)
  %388 = fsub fast float %387, %9
  %389 = fmul fast float %10, %388
  %390 = fsub fast float -0.000000e+00, %389
  %391 = call float @dx.op.binary.f32(i32 35, float %390, float -4.000000e+01)  ; FMax(a,b)
  %392 = call float @dx.op.binary.f32(i32 36, float %391, float 5.000000e+00)  ; FMin(a,b)
  %393 = fmul fast float %392, 0x3FF7154760000000
  %394 = call float @dx.op.unary.f32(i32 21, float %393)  ; Exp(value)
  %395 = fmul fast float %394, %386
  br label %396

; <label>:396                                     ; preds = %385, %345
  %397 = phi float [ %395, %385 ], [ 1.000000e+00, %345 ]
  %398 = fmul fast float %371, %15
  %399 = fmul fast float %398, %397
  %400 = fcmp fast ole float %369, %8
  %401 = fcmp fast olt float %369, 0x3F1A36E2E0000000
  %402 = or i1 %400, %401
  br i1 %402, label %449, label %403

; <label>:403                                     ; preds = %396
  %404 = fdiv fast float %8, %369
  %405 = fmul fast float %404, %361
  %406 = fmul fast float %404, %362
  %407 = fmul fast float %404, %363
  %408 = fadd fast float %405, %16
  %409 = fadd fast float %406, %17
  %410 = fadd fast float %407, %18
  %411 = fadd fast float %408, -9.000000e+02
  %412 = fadd fast float %409, -1.500000e+01
  %413 = fadd fast float %410, -7.500000e+02
  %414 = fmul fast float %411, 0x3F62345680000000
  %415 = fmul fast float %412, 0x3F62345680000000
  %416 = fmul fast float %413, 0x3F62345680000000
  %417 = call float @dx.op.dot3.f32(i32 55, float %414, float %415, float %416, float %414, float %415, float %416)  ; Dot3(ax,ay,az,bx,by,bz)
  %418 = fsub fast float 1.000000e+00, %417
  %419 = call float @dx.op.unary.f32(i32 7, float %418)  ; Saturate(value)
  %420 = fmul fast float %419, %419
  %421 = fadd fast float %408, %358
  %422 = fadd fast float %409, %359
  %423 = fadd fast float %410, %360
  %424 = fmul fast float %421, 0x3F52345680000000
  %425 = fadd fast float %424, -2.000000e+00
  %426 = fmul fast float %422, 0x3F52345680000000
  %427 = fadd fast float %426, 0xBFA1111120000000
  %428 = fmul fast float %423, 0x3F52345680000000
  %429 = fadd fast float %428, 0xBFFAAAAAC0000000
  %430 = call float @dx.op.dot3.f32(i32 55, float %425, float %427, float %429, float %425, float %427, float %429)  ; Dot3(ax,ay,az,bx,by,bz)
  %431 = fsub fast float 1.000000e+00, %430
  %432 = call float @dx.op.unary.f32(i32 7, float %431)  ; Saturate(value)
  %433 = fmul fast float %432, %432
  %434 = fmul fast float %433, 4.000000e+00
  %435 = fadd fast float %434, %420
  %436 = fadd fast float %358, -9.000000e+02
  %437 = fadd fast float %359, -1.500000e+01
  %438 = fadd fast float %360, -7.500000e+02
  %439 = fmul fast float %436, 0x3F62345680000000
  %440 = fmul fast float %437, 0x3F62345680000000
  %441 = fmul fast float %438, 0x3F62345680000000
  %442 = call float @dx.op.dot3.f32(i32 55, float %439, float %440, float %441, float %439, float %440, float %441)  ; Dot3(ax,ay,az,bx,by,bz)
  %443 = fsub fast float 1.000000e+00, %442
  %444 = call float @dx.op.unary.f32(i32 7, float %443)  ; Saturate(value)
  %445 = fmul fast float %444, %444
  %446 = fadd fast float %435, %445
  %447 = fmul fast float %370, 0x3F25D867E0000000
  %448 = fmul fast float %447, %446
  br label %449

; <label>:449                                     ; preds = %403, %396
  %450 = phi float [ %448, %403 ], [ 0.000000e+00, %396 ]
  %451 = fadd fast float %450, %399
  %452 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %451)  ; FMin(a,b)
  %453 = fmul fast float %452, 0xBFF7154760000000
  %454 = call float @dx.op.unary.f32(i32 21, float %453)  ; Exp(value)
  %455 = fsub fast float 1.000000e+00, %454
  %456 = call float @dx.op.binary.f32(i32 36, float %11, float %455)  ; FMin(a,b)
  %457 = fsub fast float %12, %281
  %458 = fsub fast float %13, %282
  %459 = fsub fast float %14, %283
  %460 = fmul fast float %456, %457
  %461 = fmul fast float %456, %458
  %462 = fmul fast float %456, %459
  %463 = fadd fast float %460, %281
  %464 = fadd fast float %461, %282
  %465 = fadd fast float %462, %283
  br label %466

; <label>:466                                     ; preds = %449, %326, %320
  %467 = phi float [ %463, %449 ], [ %281, %326 ], [ %281, %320 ]
  %468 = phi float [ %464, %449 ], [ %282, %326 ], [ %282, %320 ]
  %469 = phi float [ %465, %449 ], [ %283, %326 ], [ %283, %320 ]
  %470 = fadd fast float %4, 1.000000e+00
  %471 = fadd fast float %5, 1.000000e+00
  %472 = fsub fast float 1.000000e+00, %4
  %473 = fmul fast float %35, %470
  %474 = fmul fast float %35, %471
  %475 = fmul fast float %35, %472
  %476 = fmul fast float %473, %467
  %477 = fmul fast float %474, %468
  %478 = fmul fast float %475, %469
  %479 = fcmp fast ult float %36, 5.000000e-01
  br i1 %479, label %505, label %480

; <label>:480                                     ; preds = %466
  %481 = fmul fast float %476, 0x4004147AE0000000
  %482 = fmul fast float %477, 0x4004147AE0000000
  %483 = fmul fast float %478, 0x4004147AE0000000
  %484 = fadd fast float %481, 0x3F9EB851E0000000
  %485 = fadd fast float %482, 0x3F9EB851E0000000
  %486 = fadd fast float %483, 0x3F9EB851E0000000
  %487 = fmul fast float %484, %476
  %488 = fmul fast float %485, %477
  %489 = fmul fast float %486, %478
  %490 = fmul fast float %476, 0x400370A3E0000000
  %491 = fmul fast float %477, 0x400370A3E0000000
  %492 = fmul fast float %478, 0x400370A3E0000000
  %493 = fadd fast float %490, 0x3FE2E147A0000000
  %494 = fadd fast float %491, 0x3FE2E147A0000000
  %495 = fadd fast float %492, 0x3FE2E147A0000000
  %496 = fmul fast float %493, %476
  %497 = fmul fast float %494, %477
  %498 = fmul fast float %495, %478
  %499 = fadd fast float %496, 0x3FC1EB8520000000
  %500 = fadd fast float %497, 0x3FC1EB8520000000
  %501 = fadd fast float %498, 0x3FC1EB8520000000
  %502 = fdiv fast float %487, %499
  %503 = fdiv fast float %488, %500
  %504 = fdiv fast float %489, %501
  br label %505

; <label>:505                                     ; preds = %480, %466
  %506 = phi float [ %502, %480 ], [ %476, %466 ]
  %507 = phi float [ %503, %480 ], [ %477, %466 ]
  %508 = phi float [ %504, %480 ], [ %478, %466 ]
  %509 = call float @dx.op.unary.f32(i32 7, float %506)  ; Saturate(value)
  %510 = call float @dx.op.unary.f32(i32 7, float %507)  ; Saturate(value)
  %511 = call float @dx.op.unary.f32(i32 7, float %508)  ; Saturate(value)
  %512 = call float @dx.op.dot3.f32(i32 55, float %509, float %510, float %511, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %513 = fsub fast float %509, %512
  %514 = fsub fast float %510, %512
  %515 = fsub fast float %511, %512
  %516 = fmul fast float %513, %7
  %517 = fmul fast float %514, %7
  %518 = fmul fast float %515, %7
  %519 = fadd fast float %516, %512
  %520 = fadd fast float %517, %512
  %521 = fadd fast float %518, %512
  %522 = call float @dx.op.unary.f32(i32 7, float %519)  ; Saturate(value)
  %523 = call float @dx.op.unary.f32(i32 7, float %520)  ; Saturate(value)
  %524 = call float @dx.op.unary.f32(i32 7, float %521)  ; Saturate(value)
  %525 = fadd fast float %522, 0xBFC70A3D80000000
  %526 = fadd fast float %523, 0xBFC70A3D80000000
  %527 = fadd fast float %524, 0xBFC70A3D80000000
  %528 = fmul fast float %525, %6
  %529 = fmul fast float %526, %6
  %530 = fmul fast float %527, %6
  %531 = fadd fast float %528, 0x3FC70A3D80000000
  %532 = fadd fast float %529, 0x3FC70A3D80000000
  %533 = fadd fast float %530, 0x3FC70A3D80000000
  %534 = call float @dx.op.unary.f32(i32 7, float %531)  ; Saturate(value)
  %535 = call float @dx.op.unary.f32(i32 7, float %532)  ; Saturate(value)
  %536 = call float @dx.op.unary.f32(i32 7, float %533)  ; Saturate(value)
  br label %537

; <label>:537                                     ; preds = %505, %286
  %538 = phi float [ %317, %286 ], [ %534, %505 ]
  %539 = phi float [ %318, %286 ], [ %535, %505 ]
  %540 = phi float [ %319, %286 ], [ %536, %505 ]
  %541 = add i32 %45, 1
  %542 = call i32 @dx.op.binary.i32(i32 37, i32 %541, i32 0)  ; IMax(a,b)
  %543 = call i32 @dx.op.binary.i32(i32 38, i32 %542, i32 %275)  ; IMin(a,b)
  %544 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %278, i32 %543, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %545 = extractvalue %dx.types.ResRet.f32 %544, 0
  %546 = extractvalue %dx.types.ResRet.f32 %544, 1
  %547 = extractvalue %dx.types.ResRet.f32 %544, 2
  %548 = extractvalue %dx.types.ResRet.f32 %544, 3
  %549 = fcmp fast olt float %548, 0.000000e+00
  br i1 %549, label %550, label %584

; <label>:550                                     ; preds = %537
  %551 = fcmp fast ogt float %545, 0x3FA4B5DCC0000000
  %552 = fcmp fast ogt float %546, 0x3FA4B5DCC0000000
  %553 = fcmp fast ogt float %547, 0x3FA4B5DCC0000000
  %554 = select i1 %551, float 0.000000e+00, float 1.000000e+00
  %555 = select i1 %552, float 0.000000e+00, float 1.000000e+00
  %556 = select i1 %553, float 0.000000e+00, float 1.000000e+00
  %557 = fmul fast float %545, 0x3FB3D07220000000
  %558 = fmul fast float %546, 0x3FB3D07220000000
  %559 = fmul fast float %547, 0x3FB3D07220000000
  %560 = fadd fast float %545, 0x3FAC28F5C0000000
  %561 = fadd fast float %546, 0x3FAC28F5C0000000
  %562 = fadd fast float %547, 0x3FAC28F5C0000000
  %563 = fmul fast float %560, 0x3FEE54EDE0000000
  %564 = fmul fast float %561, 0x3FEE54EDE0000000
  %565 = fmul fast float %562, 0x3FEE54EDE0000000
  %566 = call float @dx.op.unary.f32(i32 23, float %563)  ; Log(value)
  %567 = call float @dx.op.unary.f32(i32 23, float %564)  ; Log(value)
  %568 = call float @dx.op.unary.f32(i32 23, float %565)  ; Log(value)
  %569 = fmul fast float %566, 0x4003333340000000
  %570 = fmul fast float %567, 0x4003333340000000
  %571 = fmul fast float %568, 0x4003333340000000
  %572 = call float @dx.op.unary.f32(i32 21, float %569)  ; Exp(value)
  %573 = call float @dx.op.unary.f32(i32 21, float %570)  ; Exp(value)
  %574 = call float @dx.op.unary.f32(i32 21, float %571)  ; Exp(value)
  %575 = fsub fast float %557, %572
  %576 = fsub fast float %558, %573
  %577 = fsub fast float %559, %574
  %578 = fmul fast float %575, %554
  %579 = fmul fast float %576, %555
  %580 = fmul fast float %577, %556
  %581 = fadd fast float %578, %572
  %582 = fadd fast float %579, %573
  %583 = fadd fast float %580, %574
  br label %801

; <label>:584                                     ; preds = %537
  %585 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %278, i32 %543, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %586 = extractvalue %dx.types.ResRet.f32 %585, 0
  %587 = fcmp fast ogt float %37, 5.000000e-01
  %588 = fcmp fast olt float %586, 1.000000e+00
  %589 = and i1 %587, %588
  br i1 %589, label %590, label %730

; <label>:590                                     ; preds = %584
  %591 = sitofp i32 %278 to float
  %592 = sitofp i32 %543 to float
  %593 = fadd fast float %591, 5.000000e-01
  %594 = fadd fast float %592, 5.000000e-01
  %595 = uitofp i32 %42 to float
  %596 = uitofp i32 %43 to float
  %597 = fdiv fast float %593, %595
  %598 = fdiv fast float %594, %596
  %599 = fmul fast float %597, 2.000000e+00
  %600 = fmul fast float %598, 2.000000e+00
  %601 = fadd fast float %599, -1.000000e+00
  %602 = fsub fast float 1.000000e+00, %600
  %603 = fmul fast float %601, %34
  %604 = call float @dx.op.tertiary.f32(i32 46, float %602, float %30, float %603)  ; FMad(a,b,c)
  %605 = call float @dx.op.tertiary.f32(i32 46, float %586, float %26, float %604)  ; FMad(a,b,c)
  %606 = fadd fast float %605, %22
  %607 = call float @dx.op.unary.f32(i32 6, float %606)  ; FAbs(value)
  %608 = fcmp fast ogt float %607, 0x3EB0C6F7A0000000
  br i1 %608, label %609, label %730

; <label>:609                                     ; preds = %590
  %610 = fmul fast float %601, %33
  %611 = call float @dx.op.tertiary.f32(i32 46, float %602, float %29, float %610)  ; FMad(a,b,c)
  %612 = call float @dx.op.tertiary.f32(i32 46, float %586, float %25, float %611)  ; FMad(a,b,c)
  %613 = fadd fast float %612, %21
  %614 = fmul fast float %601, %32
  %615 = call float @dx.op.tertiary.f32(i32 46, float %602, float %28, float %614)  ; FMad(a,b,c)
  %616 = call float @dx.op.tertiary.f32(i32 46, float %586, float %24, float %615)  ; FMad(a,b,c)
  %617 = fadd fast float %616, %20
  %618 = fmul fast float %601, %31
  %619 = call float @dx.op.tertiary.f32(i32 46, float %602, float %27, float %618)  ; FMad(a,b,c)
  %620 = call float @dx.op.tertiary.f32(i32 46, float %586, float %23, float %619)  ; FMad(a,b,c)
  %621 = fadd fast float %620, %19
  %622 = fdiv fast float %621, %606
  %623 = fdiv fast float %617, %606
  %624 = fdiv fast float %613, %606
  %625 = fsub fast float %622, %16
  %626 = fsub fast float %623, %17
  %627 = fsub fast float %624, %18
  %628 = fmul fast float %625, %625
  %629 = fmul fast float %626, %626
  %630 = fadd fast float %629, %628
  %631 = fmul fast float %627, %627
  %632 = fadd fast float %630, %631
  %633 = call float @dx.op.unary.f32(i32 24, float %632)  ; Sqrt(value)
  %634 = fsub fast float %633, %8
  %635 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %634)  ; FMax(a,b)
  %636 = fcmp fast ogt float %38, 1.500000e+00
  br i1 %636, label %637, label %660

; <label>:637                                     ; preds = %609
  %638 = call float @dx.op.unary.f32(i32 6, float %626)  ; FAbs(value)
  %639 = fmul fast float %638, %10
  %640 = fcmp fast olt float %639, 0x3F50624DE0000000
  br i1 %640, label %641, label %644

; <label>:641                                     ; preds = %637
  %642 = fmul fast float %639, 5.000000e-01
  %643 = fsub fast float 1.000000e+00, %642
  br label %649

; <label>:644                                     ; preds = %637
  %645 = fmul fast float %639, 0xBFF7154760000000
  %646 = call float @dx.op.unary.f32(i32 21, float %645)  ; Exp(value)
  %647 = fsub fast float 1.000000e+00, %646
  %648 = fdiv fast float %647, %639
  br label %649

; <label>:649                                     ; preds = %644, %641
  %650 = phi float [ %643, %641 ], [ %648, %644 ]
  %651 = call float @dx.op.binary.f32(i32 36, float %623, float %17)  ; FMin(a,b)
  %652 = fsub fast float %651, %9
  %653 = fmul fast float %10, %652
  %654 = fsub fast float -0.000000e+00, %653
  %655 = call float @dx.op.binary.f32(i32 35, float %654, float -4.000000e+01)  ; FMax(a,b)
  %656 = call float @dx.op.binary.f32(i32 36, float %655, float 5.000000e+00)  ; FMin(a,b)
  %657 = fmul fast float %656, 0x3FF7154760000000
  %658 = call float @dx.op.unary.f32(i32 21, float %657)  ; Exp(value)
  %659 = fmul fast float %658, %650
  br label %660

; <label>:660                                     ; preds = %649, %609
  %661 = phi float [ %659, %649 ], [ 1.000000e+00, %609 ]
  %662 = fmul fast float %635, %15
  %663 = fmul fast float %662, %661
  %664 = fcmp fast ole float %633, %8
  %665 = fcmp fast olt float %633, 0x3F1A36E2E0000000
  %666 = or i1 %664, %665
  br i1 %666, label %713, label %667

; <label>:667                                     ; preds = %660
  %668 = fdiv fast float %8, %633
  %669 = fmul fast float %668, %625
  %670 = fmul fast float %668, %626
  %671 = fmul fast float %668, %627
  %672 = fadd fast float %669, %16
  %673 = fadd fast float %670, %17
  %674 = fadd fast float %671, %18
  %675 = fadd fast float %672, -9.000000e+02
  %676 = fadd fast float %673, -1.500000e+01
  %677 = fadd fast float %674, -7.500000e+02
  %678 = fmul fast float %675, 0x3F62345680000000
  %679 = fmul fast float %676, 0x3F62345680000000
  %680 = fmul fast float %677, 0x3F62345680000000
  %681 = call float @dx.op.dot3.f32(i32 55, float %678, float %679, float %680, float %678, float %679, float %680)  ; Dot3(ax,ay,az,bx,by,bz)
  %682 = fsub fast float 1.000000e+00, %681
  %683 = call float @dx.op.unary.f32(i32 7, float %682)  ; Saturate(value)
  %684 = fmul fast float %683, %683
  %685 = fadd fast float %672, %622
  %686 = fadd fast float %673, %623
  %687 = fadd fast float %674, %624
  %688 = fmul fast float %685, 0x3F52345680000000
  %689 = fadd fast float %688, -2.000000e+00
  %690 = fmul fast float %686, 0x3F52345680000000
  %691 = fadd fast float %690, 0xBFA1111120000000
  %692 = fmul fast float %687, 0x3F52345680000000
  %693 = fadd fast float %692, 0xBFFAAAAAC0000000
  %694 = call float @dx.op.dot3.f32(i32 55, float %689, float %691, float %693, float %689, float %691, float %693)  ; Dot3(ax,ay,az,bx,by,bz)
  %695 = fsub fast float 1.000000e+00, %694
  %696 = call float @dx.op.unary.f32(i32 7, float %695)  ; Saturate(value)
  %697 = fmul fast float %696, %696
  %698 = fmul fast float %697, 4.000000e+00
  %699 = fadd fast float %698, %684
  %700 = fadd fast float %622, -9.000000e+02
  %701 = fadd fast float %623, -1.500000e+01
  %702 = fadd fast float %624, -7.500000e+02
  %703 = fmul fast float %700, 0x3F62345680000000
  %704 = fmul fast float %701, 0x3F62345680000000
  %705 = fmul fast float %702, 0x3F62345680000000
  %706 = call float @dx.op.dot3.f32(i32 55, float %703, float %704, float %705, float %703, float %704, float %705)  ; Dot3(ax,ay,az,bx,by,bz)
  %707 = fsub fast float 1.000000e+00, %706
  %708 = call float @dx.op.unary.f32(i32 7, float %707)  ; Saturate(value)
  %709 = fmul fast float %708, %708
  %710 = fadd fast float %699, %709
  %711 = fmul fast float %634, 0x3F25D867E0000000
  %712 = fmul fast float %711, %710
  br label %713

; <label>:713                                     ; preds = %667, %660
  %714 = phi float [ %712, %667 ], [ 0.000000e+00, %660 ]
  %715 = fadd fast float %714, %663
  %716 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %715)  ; FMin(a,b)
  %717 = fmul fast float %716, 0xBFF7154760000000
  %718 = call float @dx.op.unary.f32(i32 21, float %717)  ; Exp(value)
  %719 = fsub fast float 1.000000e+00, %718
  %720 = call float @dx.op.binary.f32(i32 36, float %11, float %719)  ; FMin(a,b)
  %721 = fsub fast float %12, %545
  %722 = fsub fast float %13, %546
  %723 = fsub fast float %14, %547
  %724 = fmul fast float %720, %721
  %725 = fmul fast float %720, %722
  %726 = fmul fast float %720, %723
  %727 = fadd fast float %724, %545
  %728 = fadd fast float %725, %546
  %729 = fadd fast float %726, %547
  br label %730

; <label>:730                                     ; preds = %713, %590, %584
  %731 = phi float [ %727, %713 ], [ %545, %590 ], [ %545, %584 ]
  %732 = phi float [ %728, %713 ], [ %546, %590 ], [ %546, %584 ]
  %733 = phi float [ %729, %713 ], [ %547, %590 ], [ %547, %584 ]
  %734 = fadd fast float %4, 1.000000e+00
  %735 = fadd fast float %5, 1.000000e+00
  %736 = fsub fast float 1.000000e+00, %4
  %737 = fmul fast float %35, %734
  %738 = fmul fast float %35, %735
  %739 = fmul fast float %35, %736
  %740 = fmul fast float %737, %731
  %741 = fmul fast float %738, %732
  %742 = fmul fast float %739, %733
  %743 = fcmp fast ult float %36, 5.000000e-01
  br i1 %743, label %769, label %744

; <label>:744                                     ; preds = %730
  %745 = fmul fast float %740, 0x4004147AE0000000
  %746 = fmul fast float %741, 0x4004147AE0000000
  %747 = fmul fast float %742, 0x4004147AE0000000
  %748 = fadd fast float %745, 0x3F9EB851E0000000
  %749 = fadd fast float %746, 0x3F9EB851E0000000
  %750 = fadd fast float %747, 0x3F9EB851E0000000
  %751 = fmul fast float %748, %740
  %752 = fmul fast float %749, %741
  %753 = fmul fast float %750, %742
  %754 = fmul fast float %740, 0x400370A3E0000000
  %755 = fmul fast float %741, 0x400370A3E0000000
  %756 = fmul fast float %742, 0x400370A3E0000000
  %757 = fadd fast float %754, 0x3FE2E147A0000000
  %758 = fadd fast float %755, 0x3FE2E147A0000000
  %759 = fadd fast float %756, 0x3FE2E147A0000000
  %760 = fmul fast float %757, %740
  %761 = fmul fast float %758, %741
  %762 = fmul fast float %759, %742
  %763 = fadd fast float %760, 0x3FC1EB8520000000
  %764 = fadd fast float %761, 0x3FC1EB8520000000
  %765 = fadd fast float %762, 0x3FC1EB8520000000
  %766 = fdiv fast float %751, %763
  %767 = fdiv fast float %752, %764
  %768 = fdiv fast float %753, %765
  br label %769

; <label>:769                                     ; preds = %744, %730
  %770 = phi float [ %766, %744 ], [ %740, %730 ]
  %771 = phi float [ %767, %744 ], [ %741, %730 ]
  %772 = phi float [ %768, %744 ], [ %742, %730 ]
  %773 = call float @dx.op.unary.f32(i32 7, float %770)  ; Saturate(value)
  %774 = call float @dx.op.unary.f32(i32 7, float %771)  ; Saturate(value)
  %775 = call float @dx.op.unary.f32(i32 7, float %772)  ; Saturate(value)
  %776 = call float @dx.op.dot3.f32(i32 55, float %773, float %774, float %775, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %777 = fsub fast float %773, %776
  %778 = fsub fast float %774, %776
  %779 = fsub fast float %775, %776
  %780 = fmul fast float %777, %7
  %781 = fmul fast float %778, %7
  %782 = fmul fast float %779, %7
  %783 = fadd fast float %780, %776
  %784 = fadd fast float %781, %776
  %785 = fadd fast float %782, %776
  %786 = call float @dx.op.unary.f32(i32 7, float %783)  ; Saturate(value)
  %787 = call float @dx.op.unary.f32(i32 7, float %784)  ; Saturate(value)
  %788 = call float @dx.op.unary.f32(i32 7, float %785)  ; Saturate(value)
  %789 = fadd fast float %786, 0xBFC70A3D80000000
  %790 = fadd fast float %787, 0xBFC70A3D80000000
  %791 = fadd fast float %788, 0xBFC70A3D80000000
  %792 = fmul fast float %789, %6
  %793 = fmul fast float %790, %6
  %794 = fmul fast float %791, %6
  %795 = fadd fast float %792, 0x3FC70A3D80000000
  %796 = fadd fast float %793, 0x3FC70A3D80000000
  %797 = fadd fast float %794, 0x3FC70A3D80000000
  %798 = call float @dx.op.unary.f32(i32 7, float %795)  ; Saturate(value)
  %799 = call float @dx.op.unary.f32(i32 7, float %796)  ; Saturate(value)
  %800 = call float @dx.op.unary.f32(i32 7, float %797)  ; Saturate(value)
  br label %801

; <label>:801                                     ; preds = %769, %550
  %802 = phi float [ %581, %550 ], [ %798, %769 ]
  %803 = phi float [ %582, %550 ], [ %799, %769 ]
  %804 = phi float [ %583, %550 ], [ %800, %769 ]
  %805 = add i32 %44, -1
  %806 = call i32 @dx.op.binary.i32(i32 37, i32 %805, i32 0)  ; IMax(a,b)
  %807 = call i32 @dx.op.binary.i32(i32 37, i32 %45, i32 0)  ; IMax(a,b)
  %808 = call i32 @dx.op.binary.i32(i32 38, i32 %806, i32 %274)  ; IMin(a,b)
  %809 = call i32 @dx.op.binary.i32(i32 38, i32 %807, i32 %275)  ; IMin(a,b)
  %810 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %808, i32 %809, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %811 = extractvalue %dx.types.ResRet.f32 %810, 0
  %812 = extractvalue %dx.types.ResRet.f32 %810, 1
  %813 = extractvalue %dx.types.ResRet.f32 %810, 2
  %814 = extractvalue %dx.types.ResRet.f32 %810, 3
  %815 = fcmp fast olt float %814, 0.000000e+00
  br i1 %815, label %816, label %850

; <label>:816                                     ; preds = %801
  %817 = fcmp fast ogt float %811, 0x3FA4B5DCC0000000
  %818 = fcmp fast ogt float %812, 0x3FA4B5DCC0000000
  %819 = fcmp fast ogt float %813, 0x3FA4B5DCC0000000
  %820 = select i1 %817, float 0.000000e+00, float 1.000000e+00
  %821 = select i1 %818, float 0.000000e+00, float 1.000000e+00
  %822 = select i1 %819, float 0.000000e+00, float 1.000000e+00
  %823 = fmul fast float %811, 0x3FB3D07220000000
  %824 = fmul fast float %812, 0x3FB3D07220000000
  %825 = fmul fast float %813, 0x3FB3D07220000000
  %826 = fadd fast float %811, 0x3FAC28F5C0000000
  %827 = fadd fast float %812, 0x3FAC28F5C0000000
  %828 = fadd fast float %813, 0x3FAC28F5C0000000
  %829 = fmul fast float %826, 0x3FEE54EDE0000000
  %830 = fmul fast float %827, 0x3FEE54EDE0000000
  %831 = fmul fast float %828, 0x3FEE54EDE0000000
  %832 = call float @dx.op.unary.f32(i32 23, float %829)  ; Log(value)
  %833 = call float @dx.op.unary.f32(i32 23, float %830)  ; Log(value)
  %834 = call float @dx.op.unary.f32(i32 23, float %831)  ; Log(value)
  %835 = fmul fast float %832, 0x4003333340000000
  %836 = fmul fast float %833, 0x4003333340000000
  %837 = fmul fast float %834, 0x4003333340000000
  %838 = call float @dx.op.unary.f32(i32 21, float %835)  ; Exp(value)
  %839 = call float @dx.op.unary.f32(i32 21, float %836)  ; Exp(value)
  %840 = call float @dx.op.unary.f32(i32 21, float %837)  ; Exp(value)
  %841 = fsub fast float %823, %838
  %842 = fsub fast float %824, %839
  %843 = fsub fast float %825, %840
  %844 = fmul fast float %841, %820
  %845 = fmul fast float %842, %821
  %846 = fmul fast float %843, %822
  %847 = fadd fast float %844, %838
  %848 = fadd fast float %845, %839
  %849 = fadd fast float %846, %840
  br label %1067

; <label>:850                                     ; preds = %801
  %851 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %808, i32 %809, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %852 = extractvalue %dx.types.ResRet.f32 %851, 0
  %853 = fcmp fast ogt float %37, 5.000000e-01
  %854 = fcmp fast olt float %852, 1.000000e+00
  %855 = and i1 %853, %854
  br i1 %855, label %856, label %996

; <label>:856                                     ; preds = %850
  %857 = sitofp i32 %808 to float
  %858 = sitofp i32 %809 to float
  %859 = fadd fast float %857, 5.000000e-01
  %860 = fadd fast float %858, 5.000000e-01
  %861 = uitofp i32 %42 to float
  %862 = uitofp i32 %43 to float
  %863 = fdiv fast float %859, %861
  %864 = fdiv fast float %860, %862
  %865 = fmul fast float %863, 2.000000e+00
  %866 = fmul fast float %864, 2.000000e+00
  %867 = fadd fast float %865, -1.000000e+00
  %868 = fsub fast float 1.000000e+00, %866
  %869 = fmul fast float %867, %34
  %870 = call float @dx.op.tertiary.f32(i32 46, float %868, float %30, float %869)  ; FMad(a,b,c)
  %871 = call float @dx.op.tertiary.f32(i32 46, float %852, float %26, float %870)  ; FMad(a,b,c)
  %872 = fadd fast float %871, %22
  %873 = call float @dx.op.unary.f32(i32 6, float %872)  ; FAbs(value)
  %874 = fcmp fast ogt float %873, 0x3EB0C6F7A0000000
  br i1 %874, label %875, label %996

; <label>:875                                     ; preds = %856
  %876 = fmul fast float %867, %33
  %877 = call float @dx.op.tertiary.f32(i32 46, float %868, float %29, float %876)  ; FMad(a,b,c)
  %878 = call float @dx.op.tertiary.f32(i32 46, float %852, float %25, float %877)  ; FMad(a,b,c)
  %879 = fadd fast float %878, %21
  %880 = fmul fast float %867, %32
  %881 = call float @dx.op.tertiary.f32(i32 46, float %868, float %28, float %880)  ; FMad(a,b,c)
  %882 = call float @dx.op.tertiary.f32(i32 46, float %852, float %24, float %881)  ; FMad(a,b,c)
  %883 = fadd fast float %882, %20
  %884 = fmul fast float %867, %31
  %885 = call float @dx.op.tertiary.f32(i32 46, float %868, float %27, float %884)  ; FMad(a,b,c)
  %886 = call float @dx.op.tertiary.f32(i32 46, float %852, float %23, float %885)  ; FMad(a,b,c)
  %887 = fadd fast float %886, %19
  %888 = fdiv fast float %887, %872
  %889 = fdiv fast float %883, %872
  %890 = fdiv fast float %879, %872
  %891 = fsub fast float %888, %16
  %892 = fsub fast float %889, %17
  %893 = fsub fast float %890, %18
  %894 = fmul fast float %891, %891
  %895 = fmul fast float %892, %892
  %896 = fadd fast float %895, %894
  %897 = fmul fast float %893, %893
  %898 = fadd fast float %896, %897
  %899 = call float @dx.op.unary.f32(i32 24, float %898)  ; Sqrt(value)
  %900 = fsub fast float %899, %8
  %901 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %900)  ; FMax(a,b)
  %902 = fcmp fast ogt float %38, 1.500000e+00
  br i1 %902, label %903, label %926

; <label>:903                                     ; preds = %875
  %904 = call float @dx.op.unary.f32(i32 6, float %892)  ; FAbs(value)
  %905 = fmul fast float %904, %10
  %906 = fcmp fast olt float %905, 0x3F50624DE0000000
  br i1 %906, label %907, label %910

; <label>:907                                     ; preds = %903
  %908 = fmul fast float %905, 5.000000e-01
  %909 = fsub fast float 1.000000e+00, %908
  br label %915

; <label>:910                                     ; preds = %903
  %911 = fmul fast float %905, 0xBFF7154760000000
  %912 = call float @dx.op.unary.f32(i32 21, float %911)  ; Exp(value)
  %913 = fsub fast float 1.000000e+00, %912
  %914 = fdiv fast float %913, %905
  br label %915

; <label>:915                                     ; preds = %910, %907
  %916 = phi float [ %909, %907 ], [ %914, %910 ]
  %917 = call float @dx.op.binary.f32(i32 36, float %889, float %17)  ; FMin(a,b)
  %918 = fsub fast float %917, %9
  %919 = fmul fast float %10, %918
  %920 = fsub fast float -0.000000e+00, %919
  %921 = call float @dx.op.binary.f32(i32 35, float %920, float -4.000000e+01)  ; FMax(a,b)
  %922 = call float @dx.op.binary.f32(i32 36, float %921, float 5.000000e+00)  ; FMin(a,b)
  %923 = fmul fast float %922, 0x3FF7154760000000
  %924 = call float @dx.op.unary.f32(i32 21, float %923)  ; Exp(value)
  %925 = fmul fast float %924, %916
  br label %926

; <label>:926                                     ; preds = %915, %875
  %927 = phi float [ %925, %915 ], [ 1.000000e+00, %875 ]
  %928 = fmul fast float %901, %15
  %929 = fmul fast float %928, %927
  %930 = fcmp fast ole float %899, %8
  %931 = fcmp fast olt float %899, 0x3F1A36E2E0000000
  %932 = or i1 %930, %931
  br i1 %932, label %979, label %933

; <label>:933                                     ; preds = %926
  %934 = fdiv fast float %8, %899
  %935 = fmul fast float %934, %891
  %936 = fmul fast float %934, %892
  %937 = fmul fast float %934, %893
  %938 = fadd fast float %935, %16
  %939 = fadd fast float %936, %17
  %940 = fadd fast float %937, %18
  %941 = fadd fast float %938, -9.000000e+02
  %942 = fadd fast float %939, -1.500000e+01
  %943 = fadd fast float %940, -7.500000e+02
  %944 = fmul fast float %941, 0x3F62345680000000
  %945 = fmul fast float %942, 0x3F62345680000000
  %946 = fmul fast float %943, 0x3F62345680000000
  %947 = call float @dx.op.dot3.f32(i32 55, float %944, float %945, float %946, float %944, float %945, float %946)  ; Dot3(ax,ay,az,bx,by,bz)
  %948 = fsub fast float 1.000000e+00, %947
  %949 = call float @dx.op.unary.f32(i32 7, float %948)  ; Saturate(value)
  %950 = fmul fast float %949, %949
  %951 = fadd fast float %938, %888
  %952 = fadd fast float %939, %889
  %953 = fadd fast float %940, %890
  %954 = fmul fast float %951, 0x3F52345680000000
  %955 = fadd fast float %954, -2.000000e+00
  %956 = fmul fast float %952, 0x3F52345680000000
  %957 = fadd fast float %956, 0xBFA1111120000000
  %958 = fmul fast float %953, 0x3F52345680000000
  %959 = fadd fast float %958, 0xBFFAAAAAC0000000
  %960 = call float @dx.op.dot3.f32(i32 55, float %955, float %957, float %959, float %955, float %957, float %959)  ; Dot3(ax,ay,az,bx,by,bz)
  %961 = fsub fast float 1.000000e+00, %960
  %962 = call float @dx.op.unary.f32(i32 7, float %961)  ; Saturate(value)
  %963 = fmul fast float %962, %962
  %964 = fmul fast float %963, 4.000000e+00
  %965 = fadd fast float %964, %950
  %966 = fadd fast float %888, -9.000000e+02
  %967 = fadd fast float %889, -1.500000e+01
  %968 = fadd fast float %890, -7.500000e+02
  %969 = fmul fast float %966, 0x3F62345680000000
  %970 = fmul fast float %967, 0x3F62345680000000
  %971 = fmul fast float %968, 0x3F62345680000000
  %972 = call float @dx.op.dot3.f32(i32 55, float %969, float %970, float %971, float %969, float %970, float %971)  ; Dot3(ax,ay,az,bx,by,bz)
  %973 = fsub fast float 1.000000e+00, %972
  %974 = call float @dx.op.unary.f32(i32 7, float %973)  ; Saturate(value)
  %975 = fmul fast float %974, %974
  %976 = fadd fast float %965, %975
  %977 = fmul fast float %900, 0x3F25D867E0000000
  %978 = fmul fast float %977, %976
  br label %979

; <label>:979                                     ; preds = %933, %926
  %980 = phi float [ %978, %933 ], [ 0.000000e+00, %926 ]
  %981 = fadd fast float %980, %929
  %982 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %981)  ; FMin(a,b)
  %983 = fmul fast float %982, 0xBFF7154760000000
  %984 = call float @dx.op.unary.f32(i32 21, float %983)  ; Exp(value)
  %985 = fsub fast float 1.000000e+00, %984
  %986 = call float @dx.op.binary.f32(i32 36, float %11, float %985)  ; FMin(a,b)
  %987 = fsub fast float %12, %811
  %988 = fsub fast float %13, %812
  %989 = fsub fast float %14, %813
  %990 = fmul fast float %986, %987
  %991 = fmul fast float %986, %988
  %992 = fmul fast float %986, %989
  %993 = fadd fast float %990, %811
  %994 = fadd fast float %991, %812
  %995 = fadd fast float %992, %813
  br label %996

; <label>:996                                     ; preds = %979, %856, %850
  %997 = phi float [ %993, %979 ], [ %811, %856 ], [ %811, %850 ]
  %998 = phi float [ %994, %979 ], [ %812, %856 ], [ %812, %850 ]
  %999 = phi float [ %995, %979 ], [ %813, %856 ], [ %813, %850 ]
  %1000 = fadd fast float %4, 1.000000e+00
  %1001 = fadd fast float %5, 1.000000e+00
  %1002 = fsub fast float 1.000000e+00, %4
  %1003 = fmul fast float %35, %1000
  %1004 = fmul fast float %35, %1001
  %1005 = fmul fast float %35, %1002
  %1006 = fmul fast float %1003, %997
  %1007 = fmul fast float %1004, %998
  %1008 = fmul fast float %1005, %999
  %1009 = fcmp fast ult float %36, 5.000000e-01
  br i1 %1009, label %1035, label %1010

; <label>:1010                                    ; preds = %996
  %1011 = fmul fast float %1006, 0x4004147AE0000000
  %1012 = fmul fast float %1007, 0x4004147AE0000000
  %1013 = fmul fast float %1008, 0x4004147AE0000000
  %1014 = fadd fast float %1011, 0x3F9EB851E0000000
  %1015 = fadd fast float %1012, 0x3F9EB851E0000000
  %1016 = fadd fast float %1013, 0x3F9EB851E0000000
  %1017 = fmul fast float %1014, %1006
  %1018 = fmul fast float %1015, %1007
  %1019 = fmul fast float %1016, %1008
  %1020 = fmul fast float %1006, 0x400370A3E0000000
  %1021 = fmul fast float %1007, 0x400370A3E0000000
  %1022 = fmul fast float %1008, 0x400370A3E0000000
  %1023 = fadd fast float %1020, 0x3FE2E147A0000000
  %1024 = fadd fast float %1021, 0x3FE2E147A0000000
  %1025 = fadd fast float %1022, 0x3FE2E147A0000000
  %1026 = fmul fast float %1023, %1006
  %1027 = fmul fast float %1024, %1007
  %1028 = fmul fast float %1025, %1008
  %1029 = fadd fast float %1026, 0x3FC1EB8520000000
  %1030 = fadd fast float %1027, 0x3FC1EB8520000000
  %1031 = fadd fast float %1028, 0x3FC1EB8520000000
  %1032 = fdiv fast float %1017, %1029
  %1033 = fdiv fast float %1018, %1030
  %1034 = fdiv fast float %1019, %1031
  br label %1035

; <label>:1035                                    ; preds = %1010, %996
  %1036 = phi float [ %1032, %1010 ], [ %1006, %996 ]
  %1037 = phi float [ %1033, %1010 ], [ %1007, %996 ]
  %1038 = phi float [ %1034, %1010 ], [ %1008, %996 ]
  %1039 = call float @dx.op.unary.f32(i32 7, float %1036)  ; Saturate(value)
  %1040 = call float @dx.op.unary.f32(i32 7, float %1037)  ; Saturate(value)
  %1041 = call float @dx.op.unary.f32(i32 7, float %1038)  ; Saturate(value)
  %1042 = call float @dx.op.dot3.f32(i32 55, float %1039, float %1040, float %1041, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1043 = fsub fast float %1039, %1042
  %1044 = fsub fast float %1040, %1042
  %1045 = fsub fast float %1041, %1042
  %1046 = fmul fast float %1043, %7
  %1047 = fmul fast float %1044, %7
  %1048 = fmul fast float %1045, %7
  %1049 = fadd fast float %1046, %1042
  %1050 = fadd fast float %1047, %1042
  %1051 = fadd fast float %1048, %1042
  %1052 = call float @dx.op.unary.f32(i32 7, float %1049)  ; Saturate(value)
  %1053 = call float @dx.op.unary.f32(i32 7, float %1050)  ; Saturate(value)
  %1054 = call float @dx.op.unary.f32(i32 7, float %1051)  ; Saturate(value)
  %1055 = fadd fast float %1052, 0xBFC70A3D80000000
  %1056 = fadd fast float %1053, 0xBFC70A3D80000000
  %1057 = fadd fast float %1054, 0xBFC70A3D80000000
  %1058 = fmul fast float %1055, %6
  %1059 = fmul fast float %1056, %6
  %1060 = fmul fast float %1057, %6
  %1061 = fadd fast float %1058, 0x3FC70A3D80000000
  %1062 = fadd fast float %1059, 0x3FC70A3D80000000
  %1063 = fadd fast float %1060, 0x3FC70A3D80000000
  %1064 = call float @dx.op.unary.f32(i32 7, float %1061)  ; Saturate(value)
  %1065 = call float @dx.op.unary.f32(i32 7, float %1062)  ; Saturate(value)
  %1066 = call float @dx.op.unary.f32(i32 7, float %1063)  ; Saturate(value)
  br label %1067

; <label>:1067                                    ; preds = %1035, %816
  %1068 = phi float [ %847, %816 ], [ %1064, %1035 ]
  %1069 = phi float [ %848, %816 ], [ %1065, %1035 ]
  %1070 = phi float [ %849, %816 ], [ %1066, %1035 ]
  %1071 = add i32 %44, 1
  %1072 = call i32 @dx.op.binary.i32(i32 37, i32 %1071, i32 0)  ; IMax(a,b)
  %1073 = call i32 @dx.op.binary.i32(i32 38, i32 %1072, i32 %274)  ; IMin(a,b)
  %1074 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1073, i32 %809, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1075 = extractvalue %dx.types.ResRet.f32 %1074, 0
  %1076 = extractvalue %dx.types.ResRet.f32 %1074, 1
  %1077 = extractvalue %dx.types.ResRet.f32 %1074, 2
  %1078 = extractvalue %dx.types.ResRet.f32 %1074, 3
  %1079 = fcmp fast olt float %1078, 0.000000e+00
  br i1 %1079, label %1080, label %1114

; <label>:1080                                    ; preds = %1067
  %1081 = fcmp fast ogt float %1075, 0x3FA4B5DCC0000000
  %1082 = fcmp fast ogt float %1076, 0x3FA4B5DCC0000000
  %1083 = fcmp fast ogt float %1077, 0x3FA4B5DCC0000000
  %1084 = select i1 %1081, float 0.000000e+00, float 1.000000e+00
  %1085 = select i1 %1082, float 0.000000e+00, float 1.000000e+00
  %1086 = select i1 %1083, float 0.000000e+00, float 1.000000e+00
  %1087 = fmul fast float %1075, 0x3FB3D07220000000
  %1088 = fmul fast float %1076, 0x3FB3D07220000000
  %1089 = fmul fast float %1077, 0x3FB3D07220000000
  %1090 = fadd fast float %1075, 0x3FAC28F5C0000000
  %1091 = fadd fast float %1076, 0x3FAC28F5C0000000
  %1092 = fadd fast float %1077, 0x3FAC28F5C0000000
  %1093 = fmul fast float %1090, 0x3FEE54EDE0000000
  %1094 = fmul fast float %1091, 0x3FEE54EDE0000000
  %1095 = fmul fast float %1092, 0x3FEE54EDE0000000
  %1096 = call float @dx.op.unary.f32(i32 23, float %1093)  ; Log(value)
  %1097 = call float @dx.op.unary.f32(i32 23, float %1094)  ; Log(value)
  %1098 = call float @dx.op.unary.f32(i32 23, float %1095)  ; Log(value)
  %1099 = fmul fast float %1096, 0x4003333340000000
  %1100 = fmul fast float %1097, 0x4003333340000000
  %1101 = fmul fast float %1098, 0x4003333340000000
  %1102 = call float @dx.op.unary.f32(i32 21, float %1099)  ; Exp(value)
  %1103 = call float @dx.op.unary.f32(i32 21, float %1100)  ; Exp(value)
  %1104 = call float @dx.op.unary.f32(i32 21, float %1101)  ; Exp(value)
  %1105 = fsub fast float %1087, %1102
  %1106 = fsub fast float %1088, %1103
  %1107 = fsub fast float %1089, %1104
  %1108 = fmul fast float %1105, %1084
  %1109 = fmul fast float %1106, %1085
  %1110 = fmul fast float %1107, %1086
  %1111 = fadd fast float %1108, %1102
  %1112 = fadd fast float %1109, %1103
  %1113 = fadd fast float %1110, %1104
  br label %1331

; <label>:1114                                    ; preds = %1067
  %1115 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1073, i32 %809, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1116 = extractvalue %dx.types.ResRet.f32 %1115, 0
  %1117 = fcmp fast ogt float %37, 5.000000e-01
  %1118 = fcmp fast olt float %1116, 1.000000e+00
  %1119 = and i1 %1117, %1118
  br i1 %1119, label %1120, label %1260

; <label>:1120                                    ; preds = %1114
  %1121 = sitofp i32 %1073 to float
  %1122 = sitofp i32 %809 to float
  %1123 = fadd fast float %1121, 5.000000e-01
  %1124 = fadd fast float %1122, 5.000000e-01
  %1125 = uitofp i32 %42 to float
  %1126 = uitofp i32 %43 to float
  %1127 = fdiv fast float %1123, %1125
  %1128 = fdiv fast float %1124, %1126
  %1129 = fmul fast float %1127, 2.000000e+00
  %1130 = fmul fast float %1128, 2.000000e+00
  %1131 = fadd fast float %1129, -1.000000e+00
  %1132 = fsub fast float 1.000000e+00, %1130
  %1133 = fmul fast float %1131, %34
  %1134 = call float @dx.op.tertiary.f32(i32 46, float %1132, float %30, float %1133)  ; FMad(a,b,c)
  %1135 = call float @dx.op.tertiary.f32(i32 46, float %1116, float %26, float %1134)  ; FMad(a,b,c)
  %1136 = fadd fast float %1135, %22
  %1137 = call float @dx.op.unary.f32(i32 6, float %1136)  ; FAbs(value)
  %1138 = fcmp fast ogt float %1137, 0x3EB0C6F7A0000000
  br i1 %1138, label %1139, label %1260

; <label>:1139                                    ; preds = %1120
  %1140 = fmul fast float %1131, %33
  %1141 = call float @dx.op.tertiary.f32(i32 46, float %1132, float %29, float %1140)  ; FMad(a,b,c)
  %1142 = call float @dx.op.tertiary.f32(i32 46, float %1116, float %25, float %1141)  ; FMad(a,b,c)
  %1143 = fadd fast float %1142, %21
  %1144 = fmul fast float %1131, %32
  %1145 = call float @dx.op.tertiary.f32(i32 46, float %1132, float %28, float %1144)  ; FMad(a,b,c)
  %1146 = call float @dx.op.tertiary.f32(i32 46, float %1116, float %24, float %1145)  ; FMad(a,b,c)
  %1147 = fadd fast float %1146, %20
  %1148 = fmul fast float %1131, %31
  %1149 = call float @dx.op.tertiary.f32(i32 46, float %1132, float %27, float %1148)  ; FMad(a,b,c)
  %1150 = call float @dx.op.tertiary.f32(i32 46, float %1116, float %23, float %1149)  ; FMad(a,b,c)
  %1151 = fadd fast float %1150, %19
  %1152 = fdiv fast float %1151, %1136
  %1153 = fdiv fast float %1147, %1136
  %1154 = fdiv fast float %1143, %1136
  %1155 = fsub fast float %1152, %16
  %1156 = fsub fast float %1153, %17
  %1157 = fsub fast float %1154, %18
  %1158 = fmul fast float %1155, %1155
  %1159 = fmul fast float %1156, %1156
  %1160 = fadd fast float %1159, %1158
  %1161 = fmul fast float %1157, %1157
  %1162 = fadd fast float %1160, %1161
  %1163 = call float @dx.op.unary.f32(i32 24, float %1162)  ; Sqrt(value)
  %1164 = fsub fast float %1163, %8
  %1165 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1164)  ; FMax(a,b)
  %1166 = fcmp fast ogt float %38, 1.500000e+00
  br i1 %1166, label %1167, label %1190

; <label>:1167                                    ; preds = %1139
  %1168 = call float @dx.op.unary.f32(i32 6, float %1156)  ; FAbs(value)
  %1169 = fmul fast float %1168, %10
  %1170 = fcmp fast olt float %1169, 0x3F50624DE0000000
  br i1 %1170, label %1171, label %1174

; <label>:1171                                    ; preds = %1167
  %1172 = fmul fast float %1169, 5.000000e-01
  %1173 = fsub fast float 1.000000e+00, %1172
  br label %1179

; <label>:1174                                    ; preds = %1167
  %1175 = fmul fast float %1169, 0xBFF7154760000000
  %1176 = call float @dx.op.unary.f32(i32 21, float %1175)  ; Exp(value)
  %1177 = fsub fast float 1.000000e+00, %1176
  %1178 = fdiv fast float %1177, %1169
  br label %1179

; <label>:1179                                    ; preds = %1174, %1171
  %1180 = phi float [ %1173, %1171 ], [ %1178, %1174 ]
  %1181 = call float @dx.op.binary.f32(i32 36, float %1153, float %17)  ; FMin(a,b)
  %1182 = fsub fast float %1181, %9
  %1183 = fmul fast float %10, %1182
  %1184 = fsub fast float -0.000000e+00, %1183
  %1185 = call float @dx.op.binary.f32(i32 35, float %1184, float -4.000000e+01)  ; FMax(a,b)
  %1186 = call float @dx.op.binary.f32(i32 36, float %1185, float 5.000000e+00)  ; FMin(a,b)
  %1187 = fmul fast float %1186, 0x3FF7154760000000
  %1188 = call float @dx.op.unary.f32(i32 21, float %1187)  ; Exp(value)
  %1189 = fmul fast float %1188, %1180
  br label %1190

; <label>:1190                                    ; preds = %1179, %1139
  %1191 = phi float [ %1189, %1179 ], [ 1.000000e+00, %1139 ]
  %1192 = fmul fast float %1165, %15
  %1193 = fmul fast float %1192, %1191
  %1194 = fcmp fast ole float %1163, %8
  %1195 = fcmp fast olt float %1163, 0x3F1A36E2E0000000
  %1196 = or i1 %1194, %1195
  br i1 %1196, label %1243, label %1197

; <label>:1197                                    ; preds = %1190
  %1198 = fdiv fast float %8, %1163
  %1199 = fmul fast float %1198, %1155
  %1200 = fmul fast float %1198, %1156
  %1201 = fmul fast float %1198, %1157
  %1202 = fadd fast float %1199, %16
  %1203 = fadd fast float %1200, %17
  %1204 = fadd fast float %1201, %18
  %1205 = fadd fast float %1202, -9.000000e+02
  %1206 = fadd fast float %1203, -1.500000e+01
  %1207 = fadd fast float %1204, -7.500000e+02
  %1208 = fmul fast float %1205, 0x3F62345680000000
  %1209 = fmul fast float %1206, 0x3F62345680000000
  %1210 = fmul fast float %1207, 0x3F62345680000000
  %1211 = call float @dx.op.dot3.f32(i32 55, float %1208, float %1209, float %1210, float %1208, float %1209, float %1210)  ; Dot3(ax,ay,az,bx,by,bz)
  %1212 = fsub fast float 1.000000e+00, %1211
  %1213 = call float @dx.op.unary.f32(i32 7, float %1212)  ; Saturate(value)
  %1214 = fmul fast float %1213, %1213
  %1215 = fadd fast float %1202, %1152
  %1216 = fadd fast float %1203, %1153
  %1217 = fadd fast float %1204, %1154
  %1218 = fmul fast float %1215, 0x3F52345680000000
  %1219 = fadd fast float %1218, -2.000000e+00
  %1220 = fmul fast float %1216, 0x3F52345680000000
  %1221 = fadd fast float %1220, 0xBFA1111120000000
  %1222 = fmul fast float %1217, 0x3F52345680000000
  %1223 = fadd fast float %1222, 0xBFFAAAAAC0000000
  %1224 = call float @dx.op.dot3.f32(i32 55, float %1219, float %1221, float %1223, float %1219, float %1221, float %1223)  ; Dot3(ax,ay,az,bx,by,bz)
  %1225 = fsub fast float 1.000000e+00, %1224
  %1226 = call float @dx.op.unary.f32(i32 7, float %1225)  ; Saturate(value)
  %1227 = fmul fast float %1226, %1226
  %1228 = fmul fast float %1227, 4.000000e+00
  %1229 = fadd fast float %1228, %1214
  %1230 = fadd fast float %1152, -9.000000e+02
  %1231 = fadd fast float %1153, -1.500000e+01
  %1232 = fadd fast float %1154, -7.500000e+02
  %1233 = fmul fast float %1230, 0x3F62345680000000
  %1234 = fmul fast float %1231, 0x3F62345680000000
  %1235 = fmul fast float %1232, 0x3F62345680000000
  %1236 = call float @dx.op.dot3.f32(i32 55, float %1233, float %1234, float %1235, float %1233, float %1234, float %1235)  ; Dot3(ax,ay,az,bx,by,bz)
  %1237 = fsub fast float 1.000000e+00, %1236
  %1238 = call float @dx.op.unary.f32(i32 7, float %1237)  ; Saturate(value)
  %1239 = fmul fast float %1238, %1238
  %1240 = fadd fast float %1229, %1239
  %1241 = fmul fast float %1164, 0x3F25D867E0000000
  %1242 = fmul fast float %1241, %1240
  br label %1243

; <label>:1243                                    ; preds = %1197, %1190
  %1244 = phi float [ %1242, %1197 ], [ 0.000000e+00, %1190 ]
  %1245 = fadd fast float %1244, %1193
  %1246 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1245)  ; FMin(a,b)
  %1247 = fmul fast float %1246, 0xBFF7154760000000
  %1248 = call float @dx.op.unary.f32(i32 21, float %1247)  ; Exp(value)
  %1249 = fsub fast float 1.000000e+00, %1248
  %1250 = call float @dx.op.binary.f32(i32 36, float %11, float %1249)  ; FMin(a,b)
  %1251 = fsub fast float %12, %1075
  %1252 = fsub fast float %13, %1076
  %1253 = fsub fast float %14, %1077
  %1254 = fmul fast float %1250, %1251
  %1255 = fmul fast float %1250, %1252
  %1256 = fmul fast float %1250, %1253
  %1257 = fadd fast float %1254, %1075
  %1258 = fadd fast float %1255, %1076
  %1259 = fadd fast float %1256, %1077
  br label %1260

; <label>:1260                                    ; preds = %1243, %1120, %1114
  %1261 = phi float [ %1257, %1243 ], [ %1075, %1120 ], [ %1075, %1114 ]
  %1262 = phi float [ %1258, %1243 ], [ %1076, %1120 ], [ %1076, %1114 ]
  %1263 = phi float [ %1259, %1243 ], [ %1077, %1120 ], [ %1077, %1114 ]
  %1264 = fadd fast float %4, 1.000000e+00
  %1265 = fadd fast float %5, 1.000000e+00
  %1266 = fsub fast float 1.000000e+00, %4
  %1267 = fmul fast float %35, %1264
  %1268 = fmul fast float %35, %1265
  %1269 = fmul fast float %35, %1266
  %1270 = fmul fast float %1267, %1261
  %1271 = fmul fast float %1268, %1262
  %1272 = fmul fast float %1269, %1263
  %1273 = fcmp fast ult float %36, 5.000000e-01
  br i1 %1273, label %1299, label %1274

; <label>:1274                                    ; preds = %1260
  %1275 = fmul fast float %1270, 0x4004147AE0000000
  %1276 = fmul fast float %1271, 0x4004147AE0000000
  %1277 = fmul fast float %1272, 0x4004147AE0000000
  %1278 = fadd fast float %1275, 0x3F9EB851E0000000
  %1279 = fadd fast float %1276, 0x3F9EB851E0000000
  %1280 = fadd fast float %1277, 0x3F9EB851E0000000
  %1281 = fmul fast float %1278, %1270
  %1282 = fmul fast float %1279, %1271
  %1283 = fmul fast float %1280, %1272
  %1284 = fmul fast float %1270, 0x400370A3E0000000
  %1285 = fmul fast float %1271, 0x400370A3E0000000
  %1286 = fmul fast float %1272, 0x400370A3E0000000
  %1287 = fadd fast float %1284, 0x3FE2E147A0000000
  %1288 = fadd fast float %1285, 0x3FE2E147A0000000
  %1289 = fadd fast float %1286, 0x3FE2E147A0000000
  %1290 = fmul fast float %1287, %1270
  %1291 = fmul fast float %1288, %1271
  %1292 = fmul fast float %1289, %1272
  %1293 = fadd fast float %1290, 0x3FC1EB8520000000
  %1294 = fadd fast float %1291, 0x3FC1EB8520000000
  %1295 = fadd fast float %1292, 0x3FC1EB8520000000
  %1296 = fdiv fast float %1281, %1293
  %1297 = fdiv fast float %1282, %1294
  %1298 = fdiv fast float %1283, %1295
  br label %1299

; <label>:1299                                    ; preds = %1274, %1260
  %1300 = phi float [ %1296, %1274 ], [ %1270, %1260 ]
  %1301 = phi float [ %1297, %1274 ], [ %1271, %1260 ]
  %1302 = phi float [ %1298, %1274 ], [ %1272, %1260 ]
  %1303 = call float @dx.op.unary.f32(i32 7, float %1300)  ; Saturate(value)
  %1304 = call float @dx.op.unary.f32(i32 7, float %1301)  ; Saturate(value)
  %1305 = call float @dx.op.unary.f32(i32 7, float %1302)  ; Saturate(value)
  %1306 = call float @dx.op.dot3.f32(i32 55, float %1303, float %1304, float %1305, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1307 = fsub fast float %1303, %1306
  %1308 = fsub fast float %1304, %1306
  %1309 = fsub fast float %1305, %1306
  %1310 = fmul fast float %1307, %7
  %1311 = fmul fast float %1308, %7
  %1312 = fmul fast float %1309, %7
  %1313 = fadd fast float %1310, %1306
  %1314 = fadd fast float %1311, %1306
  %1315 = fadd fast float %1312, %1306
  %1316 = call float @dx.op.unary.f32(i32 7, float %1313)  ; Saturate(value)
  %1317 = call float @dx.op.unary.f32(i32 7, float %1314)  ; Saturate(value)
  %1318 = call float @dx.op.unary.f32(i32 7, float %1315)  ; Saturate(value)
  %1319 = fadd fast float %1316, 0xBFC70A3D80000000
  %1320 = fadd fast float %1317, 0xBFC70A3D80000000
  %1321 = fadd fast float %1318, 0xBFC70A3D80000000
  %1322 = fmul fast float %1319, %6
  %1323 = fmul fast float %1320, %6
  %1324 = fmul fast float %1321, %6
  %1325 = fadd fast float %1322, 0x3FC70A3D80000000
  %1326 = fadd fast float %1323, 0x3FC70A3D80000000
  %1327 = fadd fast float %1324, 0x3FC70A3D80000000
  %1328 = call float @dx.op.unary.f32(i32 7, float %1325)  ; Saturate(value)
  %1329 = call float @dx.op.unary.f32(i32 7, float %1326)  ; Saturate(value)
  %1330 = call float @dx.op.unary.f32(i32 7, float %1327)  ; Saturate(value)
  br label %1331

; <label>:1331                                    ; preds = %1299, %1080
  %1332 = phi float [ %1111, %1080 ], [ %1328, %1299 ]
  %1333 = phi float [ %1112, %1080 ], [ %1329, %1299 ]
  %1334 = phi float [ %1113, %1080 ], [ %1330, %1299 ]
  %1335 = call float @dx.op.binary.f32(i32 36, float %1068, float %1332)  ; FMin(a,b)
  %1336 = call float @dx.op.binary.f32(i32 36, float %1069, float %1333)  ; FMin(a,b)
  %1337 = call float @dx.op.binary.f32(i32 36, float %1070, float %1334)  ; FMin(a,b)
  %1338 = call float @dx.op.binary.f32(i32 36, float %538, float %802)  ; FMin(a,b)
  %1339 = call float @dx.op.binary.f32(i32 36, float %539, float %803)  ; FMin(a,b)
  %1340 = call float @dx.op.binary.f32(i32 36, float %540, float %804)  ; FMin(a,b)
  %1341 = call float @dx.op.binary.f32(i32 36, float %1338, float %1335)  ; FMin(a,b)
  %1342 = call float @dx.op.binary.f32(i32 36, float %1339, float %1336)  ; FMin(a,b)
  %1343 = call float @dx.op.binary.f32(i32 36, float %1340, float %1337)  ; FMin(a,b)
  %1344 = call float @dx.op.binary.f32(i32 36, float %268, float %1341)  ; FMin(a,b)
  %1345 = call float @dx.op.binary.f32(i32 36, float %269, float %1342)  ; FMin(a,b)
  %1346 = call float @dx.op.binary.f32(i32 36, float %270, float %1343)  ; FMin(a,b)
  %1347 = call float @dx.op.binary.f32(i32 35, float %1068, float %1332)  ; FMax(a,b)
  %1348 = call float @dx.op.binary.f32(i32 35, float %1069, float %1333)  ; FMax(a,b)
  %1349 = call float @dx.op.binary.f32(i32 35, float %1070, float %1334)  ; FMax(a,b)
  %1350 = call float @dx.op.binary.f32(i32 35, float %538, float %802)  ; FMax(a,b)
  %1351 = call float @dx.op.binary.f32(i32 35, float %539, float %803)  ; FMax(a,b)
  %1352 = call float @dx.op.binary.f32(i32 35, float %540, float %804)  ; FMax(a,b)
  %1353 = call float @dx.op.binary.f32(i32 35, float %1350, float %1347)  ; FMax(a,b)
  %1354 = call float @dx.op.binary.f32(i32 35, float %1351, float %1348)  ; FMax(a,b)
  %1355 = call float @dx.op.binary.f32(i32 35, float %1352, float %1349)  ; FMax(a,b)
  %1356 = call float @dx.op.binary.f32(i32 35, float %268, float %1353)  ; FMax(a,b)
  %1357 = call float @dx.op.binary.f32(i32 35, float %269, float %1354)  ; FMax(a,b)
  %1358 = call float @dx.op.binary.f32(i32 35, float %270, float %1355)  ; FMax(a,b)
  %1359 = fsub fast float %1356, %1344
  %1360 = fsub fast float %1357, %1345
  %1361 = fsub fast float %1358, %1346
  %1362 = call float @dx.op.unary.f32(i32 6, float %1359)  ; FAbs(value)
  %1363 = call float @dx.op.unary.f32(i32 6, float %1360)  ; FAbs(value)
  %1364 = call float @dx.op.unary.f32(i32 6, float %1361)  ; FAbs(value)
  %1365 = call float @dx.op.binary.f32(i32 35, float %1363, float %1364)  ; FMax(a,b)
  %1366 = call float @dx.op.binary.f32(i32 35, float %1362, float %1365)  ; FMax(a,b)
  %1367 = call float @dx.op.binary.f32(i32 35, float %1357, float %1358)  ; FMax(a,b)
  %1368 = call float @dx.op.binary.f32(i32 35, float %1356, float %1367)  ; FMax(a,b)
  %1369 = fmul fast float %1368, 1.250000e-01
  %1370 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1369)  ; FMax(a,b)
  %1371 = fcmp fast ogt float %1366, %1370
  br i1 %1371, label %1372, label %1434

; <label>:1372                                    ; preds = %1331
  %1373 = fsub fast float %538, %802
  %1374 = fsub fast float %539, %803
  %1375 = fsub fast float %540, %804
  %1376 = call float @dx.op.unary.f32(i32 6, float %1373)  ; FAbs(value)
  %1377 = call float @dx.op.unary.f32(i32 6, float %1374)  ; FAbs(value)
  %1378 = call float @dx.op.unary.f32(i32 6, float %1375)  ; FAbs(value)
  %1379 = call float @dx.op.binary.f32(i32 35, float %1377, float %1378)  ; FMax(a,b)
  %1380 = call float @dx.op.binary.f32(i32 35, float %1376, float %1379)  ; FMax(a,b)
  %1381 = fsub fast float %1068, %1332
  %1382 = fsub fast float %1069, %1333
  %1383 = fsub fast float %1070, %1334
  %1384 = call float @dx.op.unary.f32(i32 6, float %1381)  ; FAbs(value)
  %1385 = call float @dx.op.unary.f32(i32 6, float %1382)  ; FAbs(value)
  %1386 = call float @dx.op.unary.f32(i32 6, float %1383)  ; FAbs(value)
  %1387 = call float @dx.op.binary.f32(i32 35, float %1385, float %1386)  ; FMax(a,b)
  %1388 = call float @dx.op.binary.f32(i32 35, float %1384, float %1387)  ; FMax(a,b)
  %1389 = fcmp fast olt float %1380, %1388
  %1390 = select i1 %1389, float %538, float %1068
  %1391 = select i1 %1389, float %539, float %1069
  %1392 = select i1 %1389, float %540, float %1070
  %1393 = select i1 %1389, float %802, float %1332
  %1394 = select i1 %1389, float %803, float %1333
  %1395 = select i1 %1389, float %804, float %1334
  %1396 = fsub fast float %268, %1393
  %1397 = fsub fast float %269, %1394
  %1398 = fsub fast float %270, %1395
  %1399 = fsub fast float %268, %1390
  %1400 = fsub fast float %269, %1391
  %1401 = fsub fast float %270, %1392
  %1402 = call float @dx.op.dot3.f32(i32 55, float %1399, float %1400, float %1401, float %1396, float %1397, float %1398)  ; Dot3(ax,ay,az,bx,by,bz)
  %1403 = fcmp fast ogt float %1402, 0.000000e+00
  br i1 %1403, label %1404, label %1416

; <label>:1404                                    ; preds = %1372
  %1405 = fsub fast float %1390, %1393
  %1406 = fsub fast float %1391, %1394
  %1407 = fsub fast float %1392, %1395
  %1408 = call float @dx.op.unary.f32(i32 6, float %1405)  ; FAbs(value)
  %1409 = call float @dx.op.unary.f32(i32 6, float %1406)  ; FAbs(value)
  %1410 = call float @dx.op.unary.f32(i32 6, float %1407)  ; FAbs(value)
  %1411 = call float @dx.op.binary.f32(i32 35, float %1409, float %1410)  ; FMax(a,b)
  %1412 = call float @dx.op.binary.f32(i32 35, float %1408, float %1411)  ; FMax(a,b)
  %1413 = fmul fast float %1366, 2.500000e-01
  %1414 = fcmp fast olt float %1412, %1413
  %1415 = select i1 %1414, float 5.000000e-01, float 1.000000e+00
  br label %1416

; <label>:1416                                    ; preds = %1404, %1372
  %1417 = phi float [ 1.000000e+00, %1372 ], [ %1415, %1404 ]
  %1418 = fmul fast float %1417, %3
  %1419 = fadd fast float %1390, %1393
  %1420 = fadd fast float %1391, %1394
  %1421 = fadd fast float %1392, %1395
  %1422 = fmul fast float %1419, 5.000000e-01
  %1423 = fmul fast float %1420, 5.000000e-01
  %1424 = fmul fast float %1421, 5.000000e-01
  %1425 = fsub fast float %1422, %268
  %1426 = fsub fast float %1423, %269
  %1427 = fsub fast float %1424, %270
  %1428 = fmul fast float %1418, %1425
  %1429 = fmul fast float %1418, %1426
  %1430 = fmul fast float %1418, %1427
  %1431 = fadd fast float %1428, %268
  %1432 = fadd fast float %1429, %269
  %1433 = fadd fast float %1430, %270
  br label %1434

; <label>:1434                                    ; preds = %1416, %1331, %239
  %1435 = phi float [ %1431, %1416 ], [ %268, %1331 ], [ %268, %239 ]
  %1436 = phi float [ %1432, %1416 ], [ %269, %1331 ], [ %269, %239 ]
  %1437 = phi float [ %1433, %1416 ], [ %270, %1331 ], [ %270, %239 ]
  %1438 = fcmp fast ogt float %1435, 0x3F69A5C380000000
  %1439 = fcmp fast ogt float %1436, 0x3F69A5C380000000
  %1440 = fcmp fast ogt float %1437, 0x3F69A5C380000000
  %1441 = select i1 %1438, float 0.000000e+00, float 1.000000e+00
  %1442 = select i1 %1439, float 0.000000e+00, float 1.000000e+00
  %1443 = select i1 %1440, float 0.000000e+00, float 1.000000e+00
  %1444 = fmul fast float %1435, 0x4029D70A40000000
  %1445 = fmul fast float %1436, 0x4029D70A40000000
  %1446 = fmul fast float %1437, 0x4029D70A40000000
  %1447 = call float @dx.op.binary.f32(i32 35, float %1435, float 0.000000e+00)  ; FMax(a,b)
  %1448 = call float @dx.op.binary.f32(i32 35, float %1436, float 0.000000e+00)  ; FMax(a,b)
  %1449 = call float @dx.op.binary.f32(i32 35, float %1437, float 0.000000e+00)  ; FMax(a,b)
  %1450 = call float @dx.op.unary.f32(i32 23, float %1447)  ; Log(value)
  %1451 = call float @dx.op.unary.f32(i32 23, float %1448)  ; Log(value)
  %1452 = call float @dx.op.unary.f32(i32 23, float %1449)  ; Log(value)
  %1453 = fmul fast float %1450, 0x3FDAAAAAA0000000
  %1454 = fmul fast float %1451, 0x3FDAAAAAA0000000
  %1455 = fmul fast float %1452, 0x3FDAAAAAA0000000
  %1456 = call float @dx.op.unary.f32(i32 21, float %1453)  ; Exp(value)
  %1457 = call float @dx.op.unary.f32(i32 21, float %1454)  ; Exp(value)
  %1458 = call float @dx.op.unary.f32(i32 21, float %1455)  ; Exp(value)
  %1459 = fmul fast float %1456, 0x3FF0E147A0000000
  %1460 = fmul fast float %1457, 0x3FF0E147A0000000
  %1461 = fmul fast float %1458, 0x3FF0E147A0000000
  %1462 = fadd fast float %1459, 0xBFAC28F5C0000000
  %1463 = fadd fast float %1460, 0xBFAC28F5C0000000
  %1464 = fadd fast float %1461, 0xBFAC28F5C0000000
  %1465 = fsub fast float %1444, %1462
  %1466 = fsub fast float %1445, %1463
  %1467 = fsub fast float %1446, %1464
  %1468 = fmul fast float %1465, %1441
  %1469 = fmul fast float %1466, %1442
  %1470 = fmul fast float %1467, %1443
  %1471 = fadd fast float %1468, %1462
  %1472 = fadd fast float %1469, %1463
  %1473 = fadd fast float %1470, %1464
  br label %1474

; <label>:1474                                    ; preds = %1434, %52
  %1475 = phi float [ %47, %52 ], [ %1471, %1434 ]
  %1476 = phi float [ %48, %52 ], [ %1472, %1434 ]
  %1477 = phi float [ %49, %52 ], [ %1473, %1434 ]
  %1478 = phi float [ %53, %52 ], [ %50, %1434 ]
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %1475)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %1476)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %1477)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %1478)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 0, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !38, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, !37}
!36 = !{i32 9}
!37 = !{i32 3, i32 1}
!38 = !{!39}
!39 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
