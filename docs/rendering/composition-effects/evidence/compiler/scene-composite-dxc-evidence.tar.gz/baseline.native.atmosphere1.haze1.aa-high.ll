;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float       
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
;
; shader hash: e9388689e7295b8d850789896b9859be
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=0
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 1
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39 }
;   output 3 depends on inputs: { 0, 1 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %40 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %41 = extractvalue %dx.types.Dimensions %40, 0
  %42 = extractvalue %dx.types.Dimensions %40, 1
  %43 = fptosi float %38 to i32
  %44 = fptosi float %39 to i32
  %45 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %43, i32 %44, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %46 = extractvalue %dx.types.ResRet.f32 %45, 0
  %47 = extractvalue %dx.types.ResRet.f32 %45, 1
  %48 = extractvalue %dx.types.ResRet.f32 %45, 2
  %49 = extractvalue %dx.types.ResRet.f32 %45, 3
  %50 = fcmp fast olt float %49, 0.000000e+00
  br i1 %50, label %51, label %53

; <label>:51                                      ; preds = %0
  %52 = fsub fast float -1.000000e+00, %49
  br label %1470

; <label>:53                                      ; preds = %0
  %54 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %43, i32 %44, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %55 = extractvalue %dx.types.ResRet.f32 %54, 0
  %56 = fcmp fast ogt float %36, 5.000000e-01
  %57 = fcmp fast olt float %55, 1.000000e+00
  %58 = and i1 %56, %57
  br i1 %58, label %59, label %199

; <label>:59                                      ; preds = %53
  %60 = sitofp i32 %43 to float
  %61 = sitofp i32 %44 to float
  %62 = fadd fast float %60, 5.000000e-01
  %63 = fadd fast float %61, 5.000000e-01
  %64 = uitofp i32 %41 to float
  %65 = uitofp i32 %42 to float
  %66 = fdiv fast float %62, %64
  %67 = fdiv fast float %63, %65
  %68 = fmul fast float %66, 2.000000e+00
  %69 = fmul fast float %67, 2.000000e+00
  %70 = fadd fast float %68, -1.000000e+00
  %71 = fsub fast float 1.000000e+00, %69
  %72 = fmul fast float %70, %33
  %73 = call float @dx.op.tertiary.f32(i32 46, float %71, float %29, float %72)  ; FMad(a,b,c)
  %74 = call float @dx.op.tertiary.f32(i32 46, float %55, float %25, float %73)  ; FMad(a,b,c)
  %75 = fadd fast float %74, %21
  %76 = call float @dx.op.unary.f32(i32 6, float %75)  ; FAbs(value)
  %77 = fcmp fast ogt float %76, 0x3EB0C6F7A0000000
  br i1 %77, label %78, label %199

; <label>:78                                      ; preds = %59
  %79 = fmul fast float %70, %32
  %80 = call float @dx.op.tertiary.f32(i32 46, float %71, float %28, float %79)  ; FMad(a,b,c)
  %81 = call float @dx.op.tertiary.f32(i32 46, float %55, float %24, float %80)  ; FMad(a,b,c)
  %82 = fadd fast float %81, %20
  %83 = fmul fast float %70, %31
  %84 = call float @dx.op.tertiary.f32(i32 46, float %71, float %27, float %83)  ; FMad(a,b,c)
  %85 = call float @dx.op.tertiary.f32(i32 46, float %55, float %23, float %84)  ; FMad(a,b,c)
  %86 = fadd fast float %85, %19
  %87 = fmul fast float %70, %30
  %88 = call float @dx.op.tertiary.f32(i32 46, float %71, float %26, float %87)  ; FMad(a,b,c)
  %89 = call float @dx.op.tertiary.f32(i32 46, float %55, float %22, float %88)  ; FMad(a,b,c)
  %90 = fadd fast float %89, %18
  %91 = fdiv fast float %90, %75
  %92 = fdiv fast float %86, %75
  %93 = fdiv fast float %82, %75
  %94 = fsub fast float %91, %15
  %95 = fsub fast float %92, %16
  %96 = fsub fast float %93, %17
  %97 = fmul fast float %94, %94
  %98 = fmul fast float %95, %95
  %99 = fadd fast float %98, %97
  %100 = fmul fast float %96, %96
  %101 = fadd fast float %99, %100
  %102 = call float @dx.op.unary.f32(i32 24, float %101)  ; Sqrt(value)
  %103 = fsub fast float %102, %7
  %104 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %103)  ; FMax(a,b)
  %105 = fcmp fast ogt float %37, 1.500000e+00
  br i1 %105, label %106, label %129

; <label>:106                                     ; preds = %78
  %107 = call float @dx.op.unary.f32(i32 6, float %95)  ; FAbs(value)
  %108 = fmul fast float %107, %9
  %109 = fcmp fast olt float %108, 0x3F50624DE0000000
  br i1 %109, label %110, label %113

; <label>:110                                     ; preds = %106
  %111 = fmul fast float %108, 5.000000e-01
  %112 = fsub fast float 1.000000e+00, %111
  br label %118

; <label>:113                                     ; preds = %106
  %114 = fmul fast float %108, 0xBFF7154760000000
  %115 = call float @dx.op.unary.f32(i32 21, float %114)  ; Exp(value)
  %116 = fsub fast float 1.000000e+00, %115
  %117 = fdiv fast float %116, %108
  br label %118

; <label>:118                                     ; preds = %113, %110
  %119 = phi float [ %112, %110 ], [ %117, %113 ]
  %120 = call float @dx.op.binary.f32(i32 36, float %92, float %16)  ; FMin(a,b)
  %121 = fsub fast float %120, %8
  %122 = fmul fast float %9, %121
  %123 = fsub fast float -0.000000e+00, %122
  %124 = call float @dx.op.binary.f32(i32 35, float %123, float -4.000000e+01)  ; FMax(a,b)
  %125 = call float @dx.op.binary.f32(i32 36, float %124, float 5.000000e+00)  ; FMin(a,b)
  %126 = fmul fast float %125, 0x3FF7154760000000
  %127 = call float @dx.op.unary.f32(i32 21, float %126)  ; Exp(value)
  %128 = fmul fast float %127, %119
  br label %129

; <label>:129                                     ; preds = %118, %78
  %130 = phi float [ %128, %118 ], [ 1.000000e+00, %78 ]
  %131 = fmul fast float %104, %14
  %132 = fmul fast float %131, %130
  %133 = fcmp fast ole float %102, %7
  %134 = fcmp fast olt float %102, 0x3F1A36E2E0000000
  %135 = or i1 %133, %134
  br i1 %135, label %182, label %136

; <label>:136                                     ; preds = %129
  %137 = fdiv fast float %7, %102
  %138 = fmul fast float %137, %94
  %139 = fmul fast float %137, %95
  %140 = fmul fast float %137, %96
  %141 = fadd fast float %138, %15
  %142 = fadd fast float %139, %16
  %143 = fadd fast float %140, %17
  %144 = fadd fast float %141, -9.000000e+02
  %145 = fadd fast float %142, -1.500000e+01
  %146 = fadd fast float %143, -7.500000e+02
  %147 = fmul fast float %144, 0x3F62345680000000
  %148 = fmul fast float %145, 0x3F62345680000000
  %149 = fmul fast float %146, 0x3F62345680000000
  %150 = call float @dx.op.dot3.f32(i32 55, float %147, float %148, float %149, float %147, float %148, float %149)  ; Dot3(ax,ay,az,bx,by,bz)
  %151 = fsub fast float 1.000000e+00, %150
  %152 = call float @dx.op.unary.f32(i32 7, float %151)  ; Saturate(value)
  %153 = fmul fast float %152, %152
  %154 = fadd fast float %141, %91
  %155 = fadd fast float %142, %92
  %156 = fadd fast float %143, %93
  %157 = fmul fast float %154, 0x3F52345680000000
  %158 = fadd fast float %157, -2.000000e+00
  %159 = fmul fast float %155, 0x3F52345680000000
  %160 = fadd fast float %159, 0xBFA1111120000000
  %161 = fmul fast float %156, 0x3F52345680000000
  %162 = fadd fast float %161, 0xBFFAAAAAC0000000
  %163 = call float @dx.op.dot3.f32(i32 55, float %158, float %160, float %162, float %158, float %160, float %162)  ; Dot3(ax,ay,az,bx,by,bz)
  %164 = fsub fast float 1.000000e+00, %163
  %165 = call float @dx.op.unary.f32(i32 7, float %164)  ; Saturate(value)
  %166 = fmul fast float %165, %165
  %167 = fmul fast float %166, 4.000000e+00
  %168 = fadd fast float %167, %153
  %169 = fadd fast float %91, -9.000000e+02
  %170 = fadd fast float %92, -1.500000e+01
  %171 = fadd fast float %93, -7.500000e+02
  %172 = fmul fast float %169, 0x3F62345680000000
  %173 = fmul fast float %170, 0x3F62345680000000
  %174 = fmul fast float %171, 0x3F62345680000000
  %175 = call float @dx.op.dot3.f32(i32 55, float %172, float %173, float %174, float %172, float %173, float %174)  ; Dot3(ax,ay,az,bx,by,bz)
  %176 = fsub fast float 1.000000e+00, %175
  %177 = call float @dx.op.unary.f32(i32 7, float %176)  ; Saturate(value)
  %178 = fmul fast float %177, %177
  %179 = fadd fast float %168, %178
  %180 = fmul fast float %103, 0x3F25D867E0000000
  %181 = fmul fast float %180, %179
  br label %182

; <label>:182                                     ; preds = %136, %129
  %183 = phi float [ %181, %136 ], [ 0.000000e+00, %129 ]
  %184 = fadd fast float %183, %132
  %185 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %184)  ; FMin(a,b)
  %186 = fmul fast float %185, 0xBFF7154760000000
  %187 = call float @dx.op.unary.f32(i32 21, float %186)  ; Exp(value)
  %188 = fsub fast float 1.000000e+00, %187
  %189 = call float @dx.op.binary.f32(i32 36, float %10, float %188)  ; FMin(a,b)
  %190 = fsub fast float %11, %46
  %191 = fsub fast float %12, %47
  %192 = fsub fast float %13, %48
  %193 = fmul fast float %189, %190
  %194 = fmul fast float %189, %191
  %195 = fmul fast float %189, %192
  %196 = fadd fast float %193, %46
  %197 = fadd fast float %194, %47
  %198 = fadd fast float %195, %48
  br label %199

; <label>:199                                     ; preds = %182, %59, %53
  %200 = phi float [ %196, %182 ], [ %46, %59 ], [ %46, %53 ]
  %201 = phi float [ %197, %182 ], [ %47, %59 ], [ %47, %53 ]
  %202 = phi float [ %198, %182 ], [ %48, %59 ], [ %48, %53 ]
  %203 = fadd fast float %3, 1.000000e+00
  %204 = fadd fast float %4, 1.000000e+00
  %205 = fsub fast float 1.000000e+00, %3
  %206 = fmul fast float %34, %203
  %207 = fmul fast float %34, %204
  %208 = fmul fast float %34, %205
  %209 = fmul fast float %206, %200
  %210 = fmul fast float %207, %201
  %211 = fmul fast float %208, %202
  %212 = fcmp fast ult float %35, 5.000000e-01
  br i1 %212, label %238, label %213

; <label>:213                                     ; preds = %199
  %214 = fmul fast float %209, 0x4004147AE0000000
  %215 = fmul fast float %210, 0x4004147AE0000000
  %216 = fmul fast float %211, 0x4004147AE0000000
  %217 = fadd fast float %214, 0x3F9EB851E0000000
  %218 = fadd fast float %215, 0x3F9EB851E0000000
  %219 = fadd fast float %216, 0x3F9EB851E0000000
  %220 = fmul fast float %217, %209
  %221 = fmul fast float %218, %210
  %222 = fmul fast float %219, %211
  %223 = fmul fast float %209, 0x400370A3E0000000
  %224 = fmul fast float %210, 0x400370A3E0000000
  %225 = fmul fast float %211, 0x400370A3E0000000
  %226 = fadd fast float %223, 0x3FE2E147A0000000
  %227 = fadd fast float %224, 0x3FE2E147A0000000
  %228 = fadd fast float %225, 0x3FE2E147A0000000
  %229 = fmul fast float %226, %209
  %230 = fmul fast float %227, %210
  %231 = fmul fast float %228, %211
  %232 = fadd fast float %229, 0x3FC1EB8520000000
  %233 = fadd fast float %230, 0x3FC1EB8520000000
  %234 = fadd fast float %231, 0x3FC1EB8520000000
  %235 = fdiv fast float %220, %232
  %236 = fdiv fast float %221, %233
  %237 = fdiv fast float %222, %234
  br label %238

; <label>:238                                     ; preds = %213, %199
  %239 = phi float [ %235, %213 ], [ %209, %199 ]
  %240 = phi float [ %236, %213 ], [ %210, %199 ]
  %241 = phi float [ %237, %213 ], [ %211, %199 ]
  %242 = call float @dx.op.unary.f32(i32 7, float %239)  ; Saturate(value)
  %243 = call float @dx.op.unary.f32(i32 7, float %240)  ; Saturate(value)
  %244 = call float @dx.op.unary.f32(i32 7, float %241)  ; Saturate(value)
  %245 = call float @dx.op.dot3.f32(i32 55, float %242, float %243, float %244, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %246 = fsub fast float %242, %245
  %247 = fsub fast float %243, %245
  %248 = fsub fast float %244, %245
  %249 = fmul fast float %246, %6
  %250 = fmul fast float %247, %6
  %251 = fmul fast float %248, %6
  %252 = fadd fast float %249, %245
  %253 = fadd fast float %250, %245
  %254 = fadd fast float %251, %245
  %255 = call float @dx.op.unary.f32(i32 7, float %252)  ; Saturate(value)
  %256 = call float @dx.op.unary.f32(i32 7, float %253)  ; Saturate(value)
  %257 = call float @dx.op.unary.f32(i32 7, float %254)  ; Saturate(value)
  %258 = fadd fast float %255, 0xBFC70A3D80000000
  %259 = fadd fast float %256, 0xBFC70A3D80000000
  %260 = fadd fast float %257, 0xBFC70A3D80000000
  %261 = fmul fast float %258, %5
  %262 = fmul fast float %259, %5
  %263 = fmul fast float %260, %5
  %264 = fadd fast float %261, 0x3FC70A3D80000000
  %265 = fadd fast float %262, 0x3FC70A3D80000000
  %266 = fadd fast float %263, 0x3FC70A3D80000000
  %267 = call float @dx.op.unary.f32(i32 7, float %264)  ; Saturate(value)
  %268 = call float @dx.op.unary.f32(i32 7, float %265)  ; Saturate(value)
  %269 = call float @dx.op.unary.f32(i32 7, float %266)  ; Saturate(value)
  %270 = add i32 %44, -1
  %271 = add i32 %41, -1
  %272 = add i32 %42, -1
  %273 = call i32 @dx.op.binary.i32(i32 37, i32 %43, i32 0)  ; IMax(a,b)
  %274 = call i32 @dx.op.binary.i32(i32 37, i32 %270, i32 0)  ; IMax(a,b)
  %275 = call i32 @dx.op.binary.i32(i32 38, i32 %273, i32 %271)  ; IMin(a,b)
  %276 = call i32 @dx.op.binary.i32(i32 38, i32 %274, i32 %272)  ; IMin(a,b)
  %277 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %275, i32 %276, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %278 = extractvalue %dx.types.ResRet.f32 %277, 0
  %279 = extractvalue %dx.types.ResRet.f32 %277, 1
  %280 = extractvalue %dx.types.ResRet.f32 %277, 2
  %281 = extractvalue %dx.types.ResRet.f32 %277, 3
  %282 = fcmp fast olt float %281, 0.000000e+00
  br i1 %282, label %283, label %317

; <label>:283                                     ; preds = %238
  %284 = fcmp fast ogt float %278, 0x3FA4B5DCC0000000
  %285 = fcmp fast ogt float %279, 0x3FA4B5DCC0000000
  %286 = fcmp fast ogt float %280, 0x3FA4B5DCC0000000
  %287 = select i1 %284, float 0.000000e+00, float 1.000000e+00
  %288 = select i1 %285, float 0.000000e+00, float 1.000000e+00
  %289 = select i1 %286, float 0.000000e+00, float 1.000000e+00
  %290 = fmul fast float %278, 0x3FB3D07220000000
  %291 = fmul fast float %279, 0x3FB3D07220000000
  %292 = fmul fast float %280, 0x3FB3D07220000000
  %293 = fadd fast float %278, 0x3FAC28F5C0000000
  %294 = fadd fast float %279, 0x3FAC28F5C0000000
  %295 = fadd fast float %280, 0x3FAC28F5C0000000
  %296 = fmul fast float %293, 0x3FEE54EDE0000000
  %297 = fmul fast float %294, 0x3FEE54EDE0000000
  %298 = fmul fast float %295, 0x3FEE54EDE0000000
  %299 = call float @dx.op.unary.f32(i32 23, float %296)  ; Log(value)
  %300 = call float @dx.op.unary.f32(i32 23, float %297)  ; Log(value)
  %301 = call float @dx.op.unary.f32(i32 23, float %298)  ; Log(value)
  %302 = fmul fast float %299, 0x4003333340000000
  %303 = fmul fast float %300, 0x4003333340000000
  %304 = fmul fast float %301, 0x4003333340000000
  %305 = call float @dx.op.unary.f32(i32 21, float %302)  ; Exp(value)
  %306 = call float @dx.op.unary.f32(i32 21, float %303)  ; Exp(value)
  %307 = call float @dx.op.unary.f32(i32 21, float %304)  ; Exp(value)
  %308 = fsub fast float %290, %305
  %309 = fsub fast float %291, %306
  %310 = fsub fast float %292, %307
  %311 = fmul fast float %308, %287
  %312 = fmul fast float %309, %288
  %313 = fmul fast float %310, %289
  %314 = fadd fast float %311, %305
  %315 = fadd fast float %312, %306
  %316 = fadd fast float %313, %307
  br label %534

; <label>:317                                     ; preds = %238
  %318 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %275, i32 %276, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %319 = extractvalue %dx.types.ResRet.f32 %318, 0
  %320 = fcmp fast ogt float %36, 5.000000e-01
  %321 = fcmp fast olt float %319, 1.000000e+00
  %322 = and i1 %320, %321
  br i1 %322, label %323, label %463

; <label>:323                                     ; preds = %317
  %324 = sitofp i32 %275 to float
  %325 = sitofp i32 %276 to float
  %326 = fadd fast float %324, 5.000000e-01
  %327 = fadd fast float %325, 5.000000e-01
  %328 = uitofp i32 %41 to float
  %329 = uitofp i32 %42 to float
  %330 = fdiv fast float %326, %328
  %331 = fdiv fast float %327, %329
  %332 = fmul fast float %330, 2.000000e+00
  %333 = fmul fast float %331, 2.000000e+00
  %334 = fadd fast float %332, -1.000000e+00
  %335 = fsub fast float 1.000000e+00, %333
  %336 = fmul fast float %334, %33
  %337 = call float @dx.op.tertiary.f32(i32 46, float %335, float %29, float %336)  ; FMad(a,b,c)
  %338 = call float @dx.op.tertiary.f32(i32 46, float %319, float %25, float %337)  ; FMad(a,b,c)
  %339 = fadd fast float %338, %21
  %340 = call float @dx.op.unary.f32(i32 6, float %339)  ; FAbs(value)
  %341 = fcmp fast ogt float %340, 0x3EB0C6F7A0000000
  br i1 %341, label %342, label %463

; <label>:342                                     ; preds = %323
  %343 = fmul fast float %334, %32
  %344 = call float @dx.op.tertiary.f32(i32 46, float %335, float %28, float %343)  ; FMad(a,b,c)
  %345 = call float @dx.op.tertiary.f32(i32 46, float %319, float %24, float %344)  ; FMad(a,b,c)
  %346 = fadd fast float %345, %20
  %347 = fmul fast float %334, %31
  %348 = call float @dx.op.tertiary.f32(i32 46, float %335, float %27, float %347)  ; FMad(a,b,c)
  %349 = call float @dx.op.tertiary.f32(i32 46, float %319, float %23, float %348)  ; FMad(a,b,c)
  %350 = fadd fast float %349, %19
  %351 = fmul fast float %334, %30
  %352 = call float @dx.op.tertiary.f32(i32 46, float %335, float %26, float %351)  ; FMad(a,b,c)
  %353 = call float @dx.op.tertiary.f32(i32 46, float %319, float %22, float %352)  ; FMad(a,b,c)
  %354 = fadd fast float %353, %18
  %355 = fdiv fast float %354, %339
  %356 = fdiv fast float %350, %339
  %357 = fdiv fast float %346, %339
  %358 = fsub fast float %355, %15
  %359 = fsub fast float %356, %16
  %360 = fsub fast float %357, %17
  %361 = fmul fast float %358, %358
  %362 = fmul fast float %359, %359
  %363 = fadd fast float %362, %361
  %364 = fmul fast float %360, %360
  %365 = fadd fast float %363, %364
  %366 = call float @dx.op.unary.f32(i32 24, float %365)  ; Sqrt(value)
  %367 = fsub fast float %366, %7
  %368 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %367)  ; FMax(a,b)
  %369 = fcmp fast ogt float %37, 1.500000e+00
  br i1 %369, label %370, label %393

; <label>:370                                     ; preds = %342
  %371 = call float @dx.op.unary.f32(i32 6, float %359)  ; FAbs(value)
  %372 = fmul fast float %371, %9
  %373 = fcmp fast olt float %372, 0x3F50624DE0000000
  br i1 %373, label %374, label %377

; <label>:374                                     ; preds = %370
  %375 = fmul fast float %372, 5.000000e-01
  %376 = fsub fast float 1.000000e+00, %375
  br label %382

; <label>:377                                     ; preds = %370
  %378 = fmul fast float %372, 0xBFF7154760000000
  %379 = call float @dx.op.unary.f32(i32 21, float %378)  ; Exp(value)
  %380 = fsub fast float 1.000000e+00, %379
  %381 = fdiv fast float %380, %372
  br label %382

; <label>:382                                     ; preds = %377, %374
  %383 = phi float [ %376, %374 ], [ %381, %377 ]
  %384 = call float @dx.op.binary.f32(i32 36, float %356, float %16)  ; FMin(a,b)
  %385 = fsub fast float %384, %8
  %386 = fmul fast float %9, %385
  %387 = fsub fast float -0.000000e+00, %386
  %388 = call float @dx.op.binary.f32(i32 35, float %387, float -4.000000e+01)  ; FMax(a,b)
  %389 = call float @dx.op.binary.f32(i32 36, float %388, float 5.000000e+00)  ; FMin(a,b)
  %390 = fmul fast float %389, 0x3FF7154760000000
  %391 = call float @dx.op.unary.f32(i32 21, float %390)  ; Exp(value)
  %392 = fmul fast float %391, %383
  br label %393

; <label>:393                                     ; preds = %382, %342
  %394 = phi float [ %392, %382 ], [ 1.000000e+00, %342 ]
  %395 = fmul fast float %368, %14
  %396 = fmul fast float %395, %394
  %397 = fcmp fast ole float %366, %7
  %398 = fcmp fast olt float %366, 0x3F1A36E2E0000000
  %399 = or i1 %397, %398
  br i1 %399, label %446, label %400

; <label>:400                                     ; preds = %393
  %401 = fdiv fast float %7, %366
  %402 = fmul fast float %401, %358
  %403 = fmul fast float %401, %359
  %404 = fmul fast float %401, %360
  %405 = fadd fast float %402, %15
  %406 = fadd fast float %403, %16
  %407 = fadd fast float %404, %17
  %408 = fadd fast float %405, -9.000000e+02
  %409 = fadd fast float %406, -1.500000e+01
  %410 = fadd fast float %407, -7.500000e+02
  %411 = fmul fast float %408, 0x3F62345680000000
  %412 = fmul fast float %409, 0x3F62345680000000
  %413 = fmul fast float %410, 0x3F62345680000000
  %414 = call float @dx.op.dot3.f32(i32 55, float %411, float %412, float %413, float %411, float %412, float %413)  ; Dot3(ax,ay,az,bx,by,bz)
  %415 = fsub fast float 1.000000e+00, %414
  %416 = call float @dx.op.unary.f32(i32 7, float %415)  ; Saturate(value)
  %417 = fmul fast float %416, %416
  %418 = fadd fast float %405, %355
  %419 = fadd fast float %406, %356
  %420 = fadd fast float %407, %357
  %421 = fmul fast float %418, 0x3F52345680000000
  %422 = fadd fast float %421, -2.000000e+00
  %423 = fmul fast float %419, 0x3F52345680000000
  %424 = fadd fast float %423, 0xBFA1111120000000
  %425 = fmul fast float %420, 0x3F52345680000000
  %426 = fadd fast float %425, 0xBFFAAAAAC0000000
  %427 = call float @dx.op.dot3.f32(i32 55, float %422, float %424, float %426, float %422, float %424, float %426)  ; Dot3(ax,ay,az,bx,by,bz)
  %428 = fsub fast float 1.000000e+00, %427
  %429 = call float @dx.op.unary.f32(i32 7, float %428)  ; Saturate(value)
  %430 = fmul fast float %429, %429
  %431 = fmul fast float %430, 4.000000e+00
  %432 = fadd fast float %431, %417
  %433 = fadd fast float %355, -9.000000e+02
  %434 = fadd fast float %356, -1.500000e+01
  %435 = fadd fast float %357, -7.500000e+02
  %436 = fmul fast float %433, 0x3F62345680000000
  %437 = fmul fast float %434, 0x3F62345680000000
  %438 = fmul fast float %435, 0x3F62345680000000
  %439 = call float @dx.op.dot3.f32(i32 55, float %436, float %437, float %438, float %436, float %437, float %438)  ; Dot3(ax,ay,az,bx,by,bz)
  %440 = fsub fast float 1.000000e+00, %439
  %441 = call float @dx.op.unary.f32(i32 7, float %440)  ; Saturate(value)
  %442 = fmul fast float %441, %441
  %443 = fadd fast float %432, %442
  %444 = fmul fast float %367, 0x3F25D867E0000000
  %445 = fmul fast float %444, %443
  br label %446

; <label>:446                                     ; preds = %400, %393
  %447 = phi float [ %445, %400 ], [ 0.000000e+00, %393 ]
  %448 = fadd fast float %447, %396
  %449 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %448)  ; FMin(a,b)
  %450 = fmul fast float %449, 0xBFF7154760000000
  %451 = call float @dx.op.unary.f32(i32 21, float %450)  ; Exp(value)
  %452 = fsub fast float 1.000000e+00, %451
  %453 = call float @dx.op.binary.f32(i32 36, float %10, float %452)  ; FMin(a,b)
  %454 = fsub fast float %11, %278
  %455 = fsub fast float %12, %279
  %456 = fsub fast float %13, %280
  %457 = fmul fast float %453, %454
  %458 = fmul fast float %453, %455
  %459 = fmul fast float %453, %456
  %460 = fadd fast float %457, %278
  %461 = fadd fast float %458, %279
  %462 = fadd fast float %459, %280
  br label %463

; <label>:463                                     ; preds = %446, %323, %317
  %464 = phi float [ %460, %446 ], [ %278, %323 ], [ %278, %317 ]
  %465 = phi float [ %461, %446 ], [ %279, %323 ], [ %279, %317 ]
  %466 = phi float [ %462, %446 ], [ %280, %323 ], [ %280, %317 ]
  %467 = fadd fast float %3, 1.000000e+00
  %468 = fadd fast float %4, 1.000000e+00
  %469 = fsub fast float 1.000000e+00, %3
  %470 = fmul fast float %34, %467
  %471 = fmul fast float %34, %468
  %472 = fmul fast float %34, %469
  %473 = fmul fast float %470, %464
  %474 = fmul fast float %471, %465
  %475 = fmul fast float %472, %466
  %476 = fcmp fast ult float %35, 5.000000e-01
  br i1 %476, label %502, label %477

; <label>:477                                     ; preds = %463
  %478 = fmul fast float %473, 0x4004147AE0000000
  %479 = fmul fast float %474, 0x4004147AE0000000
  %480 = fmul fast float %475, 0x4004147AE0000000
  %481 = fadd fast float %478, 0x3F9EB851E0000000
  %482 = fadd fast float %479, 0x3F9EB851E0000000
  %483 = fadd fast float %480, 0x3F9EB851E0000000
  %484 = fmul fast float %481, %473
  %485 = fmul fast float %482, %474
  %486 = fmul fast float %483, %475
  %487 = fmul fast float %473, 0x400370A3E0000000
  %488 = fmul fast float %474, 0x400370A3E0000000
  %489 = fmul fast float %475, 0x400370A3E0000000
  %490 = fadd fast float %487, 0x3FE2E147A0000000
  %491 = fadd fast float %488, 0x3FE2E147A0000000
  %492 = fadd fast float %489, 0x3FE2E147A0000000
  %493 = fmul fast float %490, %473
  %494 = fmul fast float %491, %474
  %495 = fmul fast float %492, %475
  %496 = fadd fast float %493, 0x3FC1EB8520000000
  %497 = fadd fast float %494, 0x3FC1EB8520000000
  %498 = fadd fast float %495, 0x3FC1EB8520000000
  %499 = fdiv fast float %484, %496
  %500 = fdiv fast float %485, %497
  %501 = fdiv fast float %486, %498
  br label %502

; <label>:502                                     ; preds = %477, %463
  %503 = phi float [ %499, %477 ], [ %473, %463 ]
  %504 = phi float [ %500, %477 ], [ %474, %463 ]
  %505 = phi float [ %501, %477 ], [ %475, %463 ]
  %506 = call float @dx.op.unary.f32(i32 7, float %503)  ; Saturate(value)
  %507 = call float @dx.op.unary.f32(i32 7, float %504)  ; Saturate(value)
  %508 = call float @dx.op.unary.f32(i32 7, float %505)  ; Saturate(value)
  %509 = call float @dx.op.dot3.f32(i32 55, float %506, float %507, float %508, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %510 = fsub fast float %506, %509
  %511 = fsub fast float %507, %509
  %512 = fsub fast float %508, %509
  %513 = fmul fast float %510, %6
  %514 = fmul fast float %511, %6
  %515 = fmul fast float %512, %6
  %516 = fadd fast float %513, %509
  %517 = fadd fast float %514, %509
  %518 = fadd fast float %515, %509
  %519 = call float @dx.op.unary.f32(i32 7, float %516)  ; Saturate(value)
  %520 = call float @dx.op.unary.f32(i32 7, float %517)  ; Saturate(value)
  %521 = call float @dx.op.unary.f32(i32 7, float %518)  ; Saturate(value)
  %522 = fadd fast float %519, 0xBFC70A3D80000000
  %523 = fadd fast float %520, 0xBFC70A3D80000000
  %524 = fadd fast float %521, 0xBFC70A3D80000000
  %525 = fmul fast float %522, %5
  %526 = fmul fast float %523, %5
  %527 = fmul fast float %524, %5
  %528 = fadd fast float %525, 0x3FC70A3D80000000
  %529 = fadd fast float %526, 0x3FC70A3D80000000
  %530 = fadd fast float %527, 0x3FC70A3D80000000
  %531 = call float @dx.op.unary.f32(i32 7, float %528)  ; Saturate(value)
  %532 = call float @dx.op.unary.f32(i32 7, float %529)  ; Saturate(value)
  %533 = call float @dx.op.unary.f32(i32 7, float %530)  ; Saturate(value)
  br label %534

; <label>:534                                     ; preds = %502, %283
  %535 = phi float [ %314, %283 ], [ %531, %502 ]
  %536 = phi float [ %315, %283 ], [ %532, %502 ]
  %537 = phi float [ %316, %283 ], [ %533, %502 ]
  %538 = add i32 %44, 1
  %539 = call i32 @dx.op.binary.i32(i32 37, i32 %538, i32 0)  ; IMax(a,b)
  %540 = call i32 @dx.op.binary.i32(i32 38, i32 %539, i32 %272)  ; IMin(a,b)
  %541 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %275, i32 %540, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %542 = extractvalue %dx.types.ResRet.f32 %541, 0
  %543 = extractvalue %dx.types.ResRet.f32 %541, 1
  %544 = extractvalue %dx.types.ResRet.f32 %541, 2
  %545 = extractvalue %dx.types.ResRet.f32 %541, 3
  %546 = fcmp fast olt float %545, 0.000000e+00
  br i1 %546, label %547, label %581

; <label>:547                                     ; preds = %534
  %548 = fcmp fast ogt float %542, 0x3FA4B5DCC0000000
  %549 = fcmp fast ogt float %543, 0x3FA4B5DCC0000000
  %550 = fcmp fast ogt float %544, 0x3FA4B5DCC0000000
  %551 = select i1 %548, float 0.000000e+00, float 1.000000e+00
  %552 = select i1 %549, float 0.000000e+00, float 1.000000e+00
  %553 = select i1 %550, float 0.000000e+00, float 1.000000e+00
  %554 = fmul fast float %542, 0x3FB3D07220000000
  %555 = fmul fast float %543, 0x3FB3D07220000000
  %556 = fmul fast float %544, 0x3FB3D07220000000
  %557 = fadd fast float %542, 0x3FAC28F5C0000000
  %558 = fadd fast float %543, 0x3FAC28F5C0000000
  %559 = fadd fast float %544, 0x3FAC28F5C0000000
  %560 = fmul fast float %557, 0x3FEE54EDE0000000
  %561 = fmul fast float %558, 0x3FEE54EDE0000000
  %562 = fmul fast float %559, 0x3FEE54EDE0000000
  %563 = call float @dx.op.unary.f32(i32 23, float %560)  ; Log(value)
  %564 = call float @dx.op.unary.f32(i32 23, float %561)  ; Log(value)
  %565 = call float @dx.op.unary.f32(i32 23, float %562)  ; Log(value)
  %566 = fmul fast float %563, 0x4003333340000000
  %567 = fmul fast float %564, 0x4003333340000000
  %568 = fmul fast float %565, 0x4003333340000000
  %569 = call float @dx.op.unary.f32(i32 21, float %566)  ; Exp(value)
  %570 = call float @dx.op.unary.f32(i32 21, float %567)  ; Exp(value)
  %571 = call float @dx.op.unary.f32(i32 21, float %568)  ; Exp(value)
  %572 = fsub fast float %554, %569
  %573 = fsub fast float %555, %570
  %574 = fsub fast float %556, %571
  %575 = fmul fast float %572, %551
  %576 = fmul fast float %573, %552
  %577 = fmul fast float %574, %553
  %578 = fadd fast float %575, %569
  %579 = fadd fast float %576, %570
  %580 = fadd fast float %577, %571
  br label %798

; <label>:581                                     ; preds = %534
  %582 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %275, i32 %540, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %583 = extractvalue %dx.types.ResRet.f32 %582, 0
  %584 = fcmp fast ogt float %36, 5.000000e-01
  %585 = fcmp fast olt float %583, 1.000000e+00
  %586 = and i1 %584, %585
  br i1 %586, label %587, label %727

; <label>:587                                     ; preds = %581
  %588 = sitofp i32 %275 to float
  %589 = sitofp i32 %540 to float
  %590 = fadd fast float %588, 5.000000e-01
  %591 = fadd fast float %589, 5.000000e-01
  %592 = uitofp i32 %41 to float
  %593 = uitofp i32 %42 to float
  %594 = fdiv fast float %590, %592
  %595 = fdiv fast float %591, %593
  %596 = fmul fast float %594, 2.000000e+00
  %597 = fmul fast float %595, 2.000000e+00
  %598 = fadd fast float %596, -1.000000e+00
  %599 = fsub fast float 1.000000e+00, %597
  %600 = fmul fast float %598, %33
  %601 = call float @dx.op.tertiary.f32(i32 46, float %599, float %29, float %600)  ; FMad(a,b,c)
  %602 = call float @dx.op.tertiary.f32(i32 46, float %583, float %25, float %601)  ; FMad(a,b,c)
  %603 = fadd fast float %602, %21
  %604 = call float @dx.op.unary.f32(i32 6, float %603)  ; FAbs(value)
  %605 = fcmp fast ogt float %604, 0x3EB0C6F7A0000000
  br i1 %605, label %606, label %727

; <label>:606                                     ; preds = %587
  %607 = fmul fast float %598, %32
  %608 = call float @dx.op.tertiary.f32(i32 46, float %599, float %28, float %607)  ; FMad(a,b,c)
  %609 = call float @dx.op.tertiary.f32(i32 46, float %583, float %24, float %608)  ; FMad(a,b,c)
  %610 = fadd fast float %609, %20
  %611 = fmul fast float %598, %31
  %612 = call float @dx.op.tertiary.f32(i32 46, float %599, float %27, float %611)  ; FMad(a,b,c)
  %613 = call float @dx.op.tertiary.f32(i32 46, float %583, float %23, float %612)  ; FMad(a,b,c)
  %614 = fadd fast float %613, %19
  %615 = fmul fast float %598, %30
  %616 = call float @dx.op.tertiary.f32(i32 46, float %599, float %26, float %615)  ; FMad(a,b,c)
  %617 = call float @dx.op.tertiary.f32(i32 46, float %583, float %22, float %616)  ; FMad(a,b,c)
  %618 = fadd fast float %617, %18
  %619 = fdiv fast float %618, %603
  %620 = fdiv fast float %614, %603
  %621 = fdiv fast float %610, %603
  %622 = fsub fast float %619, %15
  %623 = fsub fast float %620, %16
  %624 = fsub fast float %621, %17
  %625 = fmul fast float %622, %622
  %626 = fmul fast float %623, %623
  %627 = fadd fast float %626, %625
  %628 = fmul fast float %624, %624
  %629 = fadd fast float %627, %628
  %630 = call float @dx.op.unary.f32(i32 24, float %629)  ; Sqrt(value)
  %631 = fsub fast float %630, %7
  %632 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %631)  ; FMax(a,b)
  %633 = fcmp fast ogt float %37, 1.500000e+00
  br i1 %633, label %634, label %657

; <label>:634                                     ; preds = %606
  %635 = call float @dx.op.unary.f32(i32 6, float %623)  ; FAbs(value)
  %636 = fmul fast float %635, %9
  %637 = fcmp fast olt float %636, 0x3F50624DE0000000
  br i1 %637, label %638, label %641

; <label>:638                                     ; preds = %634
  %639 = fmul fast float %636, 5.000000e-01
  %640 = fsub fast float 1.000000e+00, %639
  br label %646

; <label>:641                                     ; preds = %634
  %642 = fmul fast float %636, 0xBFF7154760000000
  %643 = call float @dx.op.unary.f32(i32 21, float %642)  ; Exp(value)
  %644 = fsub fast float 1.000000e+00, %643
  %645 = fdiv fast float %644, %636
  br label %646

; <label>:646                                     ; preds = %641, %638
  %647 = phi float [ %640, %638 ], [ %645, %641 ]
  %648 = call float @dx.op.binary.f32(i32 36, float %620, float %16)  ; FMin(a,b)
  %649 = fsub fast float %648, %8
  %650 = fmul fast float %9, %649
  %651 = fsub fast float -0.000000e+00, %650
  %652 = call float @dx.op.binary.f32(i32 35, float %651, float -4.000000e+01)  ; FMax(a,b)
  %653 = call float @dx.op.binary.f32(i32 36, float %652, float 5.000000e+00)  ; FMin(a,b)
  %654 = fmul fast float %653, 0x3FF7154760000000
  %655 = call float @dx.op.unary.f32(i32 21, float %654)  ; Exp(value)
  %656 = fmul fast float %655, %647
  br label %657

; <label>:657                                     ; preds = %646, %606
  %658 = phi float [ %656, %646 ], [ 1.000000e+00, %606 ]
  %659 = fmul fast float %632, %14
  %660 = fmul fast float %659, %658
  %661 = fcmp fast ole float %630, %7
  %662 = fcmp fast olt float %630, 0x3F1A36E2E0000000
  %663 = or i1 %661, %662
  br i1 %663, label %710, label %664

; <label>:664                                     ; preds = %657
  %665 = fdiv fast float %7, %630
  %666 = fmul fast float %665, %622
  %667 = fmul fast float %665, %623
  %668 = fmul fast float %665, %624
  %669 = fadd fast float %666, %15
  %670 = fadd fast float %667, %16
  %671 = fadd fast float %668, %17
  %672 = fadd fast float %669, -9.000000e+02
  %673 = fadd fast float %670, -1.500000e+01
  %674 = fadd fast float %671, -7.500000e+02
  %675 = fmul fast float %672, 0x3F62345680000000
  %676 = fmul fast float %673, 0x3F62345680000000
  %677 = fmul fast float %674, 0x3F62345680000000
  %678 = call float @dx.op.dot3.f32(i32 55, float %675, float %676, float %677, float %675, float %676, float %677)  ; Dot3(ax,ay,az,bx,by,bz)
  %679 = fsub fast float 1.000000e+00, %678
  %680 = call float @dx.op.unary.f32(i32 7, float %679)  ; Saturate(value)
  %681 = fmul fast float %680, %680
  %682 = fadd fast float %669, %619
  %683 = fadd fast float %670, %620
  %684 = fadd fast float %671, %621
  %685 = fmul fast float %682, 0x3F52345680000000
  %686 = fadd fast float %685, -2.000000e+00
  %687 = fmul fast float %683, 0x3F52345680000000
  %688 = fadd fast float %687, 0xBFA1111120000000
  %689 = fmul fast float %684, 0x3F52345680000000
  %690 = fadd fast float %689, 0xBFFAAAAAC0000000
  %691 = call float @dx.op.dot3.f32(i32 55, float %686, float %688, float %690, float %686, float %688, float %690)  ; Dot3(ax,ay,az,bx,by,bz)
  %692 = fsub fast float 1.000000e+00, %691
  %693 = call float @dx.op.unary.f32(i32 7, float %692)  ; Saturate(value)
  %694 = fmul fast float %693, %693
  %695 = fmul fast float %694, 4.000000e+00
  %696 = fadd fast float %695, %681
  %697 = fadd fast float %619, -9.000000e+02
  %698 = fadd fast float %620, -1.500000e+01
  %699 = fadd fast float %621, -7.500000e+02
  %700 = fmul fast float %697, 0x3F62345680000000
  %701 = fmul fast float %698, 0x3F62345680000000
  %702 = fmul fast float %699, 0x3F62345680000000
  %703 = call float @dx.op.dot3.f32(i32 55, float %700, float %701, float %702, float %700, float %701, float %702)  ; Dot3(ax,ay,az,bx,by,bz)
  %704 = fsub fast float 1.000000e+00, %703
  %705 = call float @dx.op.unary.f32(i32 7, float %704)  ; Saturate(value)
  %706 = fmul fast float %705, %705
  %707 = fadd fast float %696, %706
  %708 = fmul fast float %631, 0x3F25D867E0000000
  %709 = fmul fast float %708, %707
  br label %710

; <label>:710                                     ; preds = %664, %657
  %711 = phi float [ %709, %664 ], [ 0.000000e+00, %657 ]
  %712 = fadd fast float %711, %660
  %713 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %712)  ; FMin(a,b)
  %714 = fmul fast float %713, 0xBFF7154760000000
  %715 = call float @dx.op.unary.f32(i32 21, float %714)  ; Exp(value)
  %716 = fsub fast float 1.000000e+00, %715
  %717 = call float @dx.op.binary.f32(i32 36, float %10, float %716)  ; FMin(a,b)
  %718 = fsub fast float %11, %542
  %719 = fsub fast float %12, %543
  %720 = fsub fast float %13, %544
  %721 = fmul fast float %717, %718
  %722 = fmul fast float %717, %719
  %723 = fmul fast float %717, %720
  %724 = fadd fast float %721, %542
  %725 = fadd fast float %722, %543
  %726 = fadd fast float %723, %544
  br label %727

; <label>:727                                     ; preds = %710, %587, %581
  %728 = phi float [ %724, %710 ], [ %542, %587 ], [ %542, %581 ]
  %729 = phi float [ %725, %710 ], [ %543, %587 ], [ %543, %581 ]
  %730 = phi float [ %726, %710 ], [ %544, %587 ], [ %544, %581 ]
  %731 = fadd fast float %3, 1.000000e+00
  %732 = fadd fast float %4, 1.000000e+00
  %733 = fsub fast float 1.000000e+00, %3
  %734 = fmul fast float %34, %731
  %735 = fmul fast float %34, %732
  %736 = fmul fast float %34, %733
  %737 = fmul fast float %734, %728
  %738 = fmul fast float %735, %729
  %739 = fmul fast float %736, %730
  %740 = fcmp fast ult float %35, 5.000000e-01
  br i1 %740, label %766, label %741

; <label>:741                                     ; preds = %727
  %742 = fmul fast float %737, 0x4004147AE0000000
  %743 = fmul fast float %738, 0x4004147AE0000000
  %744 = fmul fast float %739, 0x4004147AE0000000
  %745 = fadd fast float %742, 0x3F9EB851E0000000
  %746 = fadd fast float %743, 0x3F9EB851E0000000
  %747 = fadd fast float %744, 0x3F9EB851E0000000
  %748 = fmul fast float %745, %737
  %749 = fmul fast float %746, %738
  %750 = fmul fast float %747, %739
  %751 = fmul fast float %737, 0x400370A3E0000000
  %752 = fmul fast float %738, 0x400370A3E0000000
  %753 = fmul fast float %739, 0x400370A3E0000000
  %754 = fadd fast float %751, 0x3FE2E147A0000000
  %755 = fadd fast float %752, 0x3FE2E147A0000000
  %756 = fadd fast float %753, 0x3FE2E147A0000000
  %757 = fmul fast float %754, %737
  %758 = fmul fast float %755, %738
  %759 = fmul fast float %756, %739
  %760 = fadd fast float %757, 0x3FC1EB8520000000
  %761 = fadd fast float %758, 0x3FC1EB8520000000
  %762 = fadd fast float %759, 0x3FC1EB8520000000
  %763 = fdiv fast float %748, %760
  %764 = fdiv fast float %749, %761
  %765 = fdiv fast float %750, %762
  br label %766

; <label>:766                                     ; preds = %741, %727
  %767 = phi float [ %763, %741 ], [ %737, %727 ]
  %768 = phi float [ %764, %741 ], [ %738, %727 ]
  %769 = phi float [ %765, %741 ], [ %739, %727 ]
  %770 = call float @dx.op.unary.f32(i32 7, float %767)  ; Saturate(value)
  %771 = call float @dx.op.unary.f32(i32 7, float %768)  ; Saturate(value)
  %772 = call float @dx.op.unary.f32(i32 7, float %769)  ; Saturate(value)
  %773 = call float @dx.op.dot3.f32(i32 55, float %770, float %771, float %772, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %774 = fsub fast float %770, %773
  %775 = fsub fast float %771, %773
  %776 = fsub fast float %772, %773
  %777 = fmul fast float %774, %6
  %778 = fmul fast float %775, %6
  %779 = fmul fast float %776, %6
  %780 = fadd fast float %777, %773
  %781 = fadd fast float %778, %773
  %782 = fadd fast float %779, %773
  %783 = call float @dx.op.unary.f32(i32 7, float %780)  ; Saturate(value)
  %784 = call float @dx.op.unary.f32(i32 7, float %781)  ; Saturate(value)
  %785 = call float @dx.op.unary.f32(i32 7, float %782)  ; Saturate(value)
  %786 = fadd fast float %783, 0xBFC70A3D80000000
  %787 = fadd fast float %784, 0xBFC70A3D80000000
  %788 = fadd fast float %785, 0xBFC70A3D80000000
  %789 = fmul fast float %786, %5
  %790 = fmul fast float %787, %5
  %791 = fmul fast float %788, %5
  %792 = fadd fast float %789, 0x3FC70A3D80000000
  %793 = fadd fast float %790, 0x3FC70A3D80000000
  %794 = fadd fast float %791, 0x3FC70A3D80000000
  %795 = call float @dx.op.unary.f32(i32 7, float %792)  ; Saturate(value)
  %796 = call float @dx.op.unary.f32(i32 7, float %793)  ; Saturate(value)
  %797 = call float @dx.op.unary.f32(i32 7, float %794)  ; Saturate(value)
  br label %798

; <label>:798                                     ; preds = %766, %547
  %799 = phi float [ %578, %547 ], [ %795, %766 ]
  %800 = phi float [ %579, %547 ], [ %796, %766 ]
  %801 = phi float [ %580, %547 ], [ %797, %766 ]
  %802 = add i32 %43, -1
  %803 = call i32 @dx.op.binary.i32(i32 37, i32 %802, i32 0)  ; IMax(a,b)
  %804 = call i32 @dx.op.binary.i32(i32 37, i32 %44, i32 0)  ; IMax(a,b)
  %805 = call i32 @dx.op.binary.i32(i32 38, i32 %803, i32 %271)  ; IMin(a,b)
  %806 = call i32 @dx.op.binary.i32(i32 38, i32 %804, i32 %272)  ; IMin(a,b)
  %807 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %805, i32 %806, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %808 = extractvalue %dx.types.ResRet.f32 %807, 0
  %809 = extractvalue %dx.types.ResRet.f32 %807, 1
  %810 = extractvalue %dx.types.ResRet.f32 %807, 2
  %811 = extractvalue %dx.types.ResRet.f32 %807, 3
  %812 = fcmp fast olt float %811, 0.000000e+00
  br i1 %812, label %813, label %847

; <label>:813                                     ; preds = %798
  %814 = fcmp fast ogt float %808, 0x3FA4B5DCC0000000
  %815 = fcmp fast ogt float %809, 0x3FA4B5DCC0000000
  %816 = fcmp fast ogt float %810, 0x3FA4B5DCC0000000
  %817 = select i1 %814, float 0.000000e+00, float 1.000000e+00
  %818 = select i1 %815, float 0.000000e+00, float 1.000000e+00
  %819 = select i1 %816, float 0.000000e+00, float 1.000000e+00
  %820 = fmul fast float %808, 0x3FB3D07220000000
  %821 = fmul fast float %809, 0x3FB3D07220000000
  %822 = fmul fast float %810, 0x3FB3D07220000000
  %823 = fadd fast float %808, 0x3FAC28F5C0000000
  %824 = fadd fast float %809, 0x3FAC28F5C0000000
  %825 = fadd fast float %810, 0x3FAC28F5C0000000
  %826 = fmul fast float %823, 0x3FEE54EDE0000000
  %827 = fmul fast float %824, 0x3FEE54EDE0000000
  %828 = fmul fast float %825, 0x3FEE54EDE0000000
  %829 = call float @dx.op.unary.f32(i32 23, float %826)  ; Log(value)
  %830 = call float @dx.op.unary.f32(i32 23, float %827)  ; Log(value)
  %831 = call float @dx.op.unary.f32(i32 23, float %828)  ; Log(value)
  %832 = fmul fast float %829, 0x4003333340000000
  %833 = fmul fast float %830, 0x4003333340000000
  %834 = fmul fast float %831, 0x4003333340000000
  %835 = call float @dx.op.unary.f32(i32 21, float %832)  ; Exp(value)
  %836 = call float @dx.op.unary.f32(i32 21, float %833)  ; Exp(value)
  %837 = call float @dx.op.unary.f32(i32 21, float %834)  ; Exp(value)
  %838 = fsub fast float %820, %835
  %839 = fsub fast float %821, %836
  %840 = fsub fast float %822, %837
  %841 = fmul fast float %838, %817
  %842 = fmul fast float %839, %818
  %843 = fmul fast float %840, %819
  %844 = fadd fast float %841, %835
  %845 = fadd fast float %842, %836
  %846 = fadd fast float %843, %837
  br label %1064

; <label>:847                                     ; preds = %798
  %848 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %805, i32 %806, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %849 = extractvalue %dx.types.ResRet.f32 %848, 0
  %850 = fcmp fast ogt float %36, 5.000000e-01
  %851 = fcmp fast olt float %849, 1.000000e+00
  %852 = and i1 %850, %851
  br i1 %852, label %853, label %993

; <label>:853                                     ; preds = %847
  %854 = sitofp i32 %805 to float
  %855 = sitofp i32 %806 to float
  %856 = fadd fast float %854, 5.000000e-01
  %857 = fadd fast float %855, 5.000000e-01
  %858 = uitofp i32 %41 to float
  %859 = uitofp i32 %42 to float
  %860 = fdiv fast float %856, %858
  %861 = fdiv fast float %857, %859
  %862 = fmul fast float %860, 2.000000e+00
  %863 = fmul fast float %861, 2.000000e+00
  %864 = fadd fast float %862, -1.000000e+00
  %865 = fsub fast float 1.000000e+00, %863
  %866 = fmul fast float %864, %33
  %867 = call float @dx.op.tertiary.f32(i32 46, float %865, float %29, float %866)  ; FMad(a,b,c)
  %868 = call float @dx.op.tertiary.f32(i32 46, float %849, float %25, float %867)  ; FMad(a,b,c)
  %869 = fadd fast float %868, %21
  %870 = call float @dx.op.unary.f32(i32 6, float %869)  ; FAbs(value)
  %871 = fcmp fast ogt float %870, 0x3EB0C6F7A0000000
  br i1 %871, label %872, label %993

; <label>:872                                     ; preds = %853
  %873 = fmul fast float %864, %32
  %874 = call float @dx.op.tertiary.f32(i32 46, float %865, float %28, float %873)  ; FMad(a,b,c)
  %875 = call float @dx.op.tertiary.f32(i32 46, float %849, float %24, float %874)  ; FMad(a,b,c)
  %876 = fadd fast float %875, %20
  %877 = fmul fast float %864, %31
  %878 = call float @dx.op.tertiary.f32(i32 46, float %865, float %27, float %877)  ; FMad(a,b,c)
  %879 = call float @dx.op.tertiary.f32(i32 46, float %849, float %23, float %878)  ; FMad(a,b,c)
  %880 = fadd fast float %879, %19
  %881 = fmul fast float %864, %30
  %882 = call float @dx.op.tertiary.f32(i32 46, float %865, float %26, float %881)  ; FMad(a,b,c)
  %883 = call float @dx.op.tertiary.f32(i32 46, float %849, float %22, float %882)  ; FMad(a,b,c)
  %884 = fadd fast float %883, %18
  %885 = fdiv fast float %884, %869
  %886 = fdiv fast float %880, %869
  %887 = fdiv fast float %876, %869
  %888 = fsub fast float %885, %15
  %889 = fsub fast float %886, %16
  %890 = fsub fast float %887, %17
  %891 = fmul fast float %888, %888
  %892 = fmul fast float %889, %889
  %893 = fadd fast float %892, %891
  %894 = fmul fast float %890, %890
  %895 = fadd fast float %893, %894
  %896 = call float @dx.op.unary.f32(i32 24, float %895)  ; Sqrt(value)
  %897 = fsub fast float %896, %7
  %898 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %897)  ; FMax(a,b)
  %899 = fcmp fast ogt float %37, 1.500000e+00
  br i1 %899, label %900, label %923

; <label>:900                                     ; preds = %872
  %901 = call float @dx.op.unary.f32(i32 6, float %889)  ; FAbs(value)
  %902 = fmul fast float %901, %9
  %903 = fcmp fast olt float %902, 0x3F50624DE0000000
  br i1 %903, label %904, label %907

; <label>:904                                     ; preds = %900
  %905 = fmul fast float %902, 5.000000e-01
  %906 = fsub fast float 1.000000e+00, %905
  br label %912

; <label>:907                                     ; preds = %900
  %908 = fmul fast float %902, 0xBFF7154760000000
  %909 = call float @dx.op.unary.f32(i32 21, float %908)  ; Exp(value)
  %910 = fsub fast float 1.000000e+00, %909
  %911 = fdiv fast float %910, %902
  br label %912

; <label>:912                                     ; preds = %907, %904
  %913 = phi float [ %906, %904 ], [ %911, %907 ]
  %914 = call float @dx.op.binary.f32(i32 36, float %886, float %16)  ; FMin(a,b)
  %915 = fsub fast float %914, %8
  %916 = fmul fast float %9, %915
  %917 = fsub fast float -0.000000e+00, %916
  %918 = call float @dx.op.binary.f32(i32 35, float %917, float -4.000000e+01)  ; FMax(a,b)
  %919 = call float @dx.op.binary.f32(i32 36, float %918, float 5.000000e+00)  ; FMin(a,b)
  %920 = fmul fast float %919, 0x3FF7154760000000
  %921 = call float @dx.op.unary.f32(i32 21, float %920)  ; Exp(value)
  %922 = fmul fast float %921, %913
  br label %923

; <label>:923                                     ; preds = %912, %872
  %924 = phi float [ %922, %912 ], [ 1.000000e+00, %872 ]
  %925 = fmul fast float %898, %14
  %926 = fmul fast float %925, %924
  %927 = fcmp fast ole float %896, %7
  %928 = fcmp fast olt float %896, 0x3F1A36E2E0000000
  %929 = or i1 %927, %928
  br i1 %929, label %976, label %930

; <label>:930                                     ; preds = %923
  %931 = fdiv fast float %7, %896
  %932 = fmul fast float %931, %888
  %933 = fmul fast float %931, %889
  %934 = fmul fast float %931, %890
  %935 = fadd fast float %932, %15
  %936 = fadd fast float %933, %16
  %937 = fadd fast float %934, %17
  %938 = fadd fast float %935, -9.000000e+02
  %939 = fadd fast float %936, -1.500000e+01
  %940 = fadd fast float %937, -7.500000e+02
  %941 = fmul fast float %938, 0x3F62345680000000
  %942 = fmul fast float %939, 0x3F62345680000000
  %943 = fmul fast float %940, 0x3F62345680000000
  %944 = call float @dx.op.dot3.f32(i32 55, float %941, float %942, float %943, float %941, float %942, float %943)  ; Dot3(ax,ay,az,bx,by,bz)
  %945 = fsub fast float 1.000000e+00, %944
  %946 = call float @dx.op.unary.f32(i32 7, float %945)  ; Saturate(value)
  %947 = fmul fast float %946, %946
  %948 = fadd fast float %935, %885
  %949 = fadd fast float %936, %886
  %950 = fadd fast float %937, %887
  %951 = fmul fast float %948, 0x3F52345680000000
  %952 = fadd fast float %951, -2.000000e+00
  %953 = fmul fast float %949, 0x3F52345680000000
  %954 = fadd fast float %953, 0xBFA1111120000000
  %955 = fmul fast float %950, 0x3F52345680000000
  %956 = fadd fast float %955, 0xBFFAAAAAC0000000
  %957 = call float @dx.op.dot3.f32(i32 55, float %952, float %954, float %956, float %952, float %954, float %956)  ; Dot3(ax,ay,az,bx,by,bz)
  %958 = fsub fast float 1.000000e+00, %957
  %959 = call float @dx.op.unary.f32(i32 7, float %958)  ; Saturate(value)
  %960 = fmul fast float %959, %959
  %961 = fmul fast float %960, 4.000000e+00
  %962 = fadd fast float %961, %947
  %963 = fadd fast float %885, -9.000000e+02
  %964 = fadd fast float %886, -1.500000e+01
  %965 = fadd fast float %887, -7.500000e+02
  %966 = fmul fast float %963, 0x3F62345680000000
  %967 = fmul fast float %964, 0x3F62345680000000
  %968 = fmul fast float %965, 0x3F62345680000000
  %969 = call float @dx.op.dot3.f32(i32 55, float %966, float %967, float %968, float %966, float %967, float %968)  ; Dot3(ax,ay,az,bx,by,bz)
  %970 = fsub fast float 1.000000e+00, %969
  %971 = call float @dx.op.unary.f32(i32 7, float %970)  ; Saturate(value)
  %972 = fmul fast float %971, %971
  %973 = fadd fast float %962, %972
  %974 = fmul fast float %897, 0x3F25D867E0000000
  %975 = fmul fast float %974, %973
  br label %976

; <label>:976                                     ; preds = %930, %923
  %977 = phi float [ %975, %930 ], [ 0.000000e+00, %923 ]
  %978 = fadd fast float %977, %926
  %979 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %978)  ; FMin(a,b)
  %980 = fmul fast float %979, 0xBFF7154760000000
  %981 = call float @dx.op.unary.f32(i32 21, float %980)  ; Exp(value)
  %982 = fsub fast float 1.000000e+00, %981
  %983 = call float @dx.op.binary.f32(i32 36, float %10, float %982)  ; FMin(a,b)
  %984 = fsub fast float %11, %808
  %985 = fsub fast float %12, %809
  %986 = fsub fast float %13, %810
  %987 = fmul fast float %983, %984
  %988 = fmul fast float %983, %985
  %989 = fmul fast float %983, %986
  %990 = fadd fast float %987, %808
  %991 = fadd fast float %988, %809
  %992 = fadd fast float %989, %810
  br label %993

; <label>:993                                     ; preds = %976, %853, %847
  %994 = phi float [ %990, %976 ], [ %808, %853 ], [ %808, %847 ]
  %995 = phi float [ %991, %976 ], [ %809, %853 ], [ %809, %847 ]
  %996 = phi float [ %992, %976 ], [ %810, %853 ], [ %810, %847 ]
  %997 = fadd fast float %3, 1.000000e+00
  %998 = fadd fast float %4, 1.000000e+00
  %999 = fsub fast float 1.000000e+00, %3
  %1000 = fmul fast float %34, %997
  %1001 = fmul fast float %34, %998
  %1002 = fmul fast float %34, %999
  %1003 = fmul fast float %1000, %994
  %1004 = fmul fast float %1001, %995
  %1005 = fmul fast float %1002, %996
  %1006 = fcmp fast ult float %35, 5.000000e-01
  br i1 %1006, label %1032, label %1007

; <label>:1007                                    ; preds = %993
  %1008 = fmul fast float %1003, 0x4004147AE0000000
  %1009 = fmul fast float %1004, 0x4004147AE0000000
  %1010 = fmul fast float %1005, 0x4004147AE0000000
  %1011 = fadd fast float %1008, 0x3F9EB851E0000000
  %1012 = fadd fast float %1009, 0x3F9EB851E0000000
  %1013 = fadd fast float %1010, 0x3F9EB851E0000000
  %1014 = fmul fast float %1011, %1003
  %1015 = fmul fast float %1012, %1004
  %1016 = fmul fast float %1013, %1005
  %1017 = fmul fast float %1003, 0x400370A3E0000000
  %1018 = fmul fast float %1004, 0x400370A3E0000000
  %1019 = fmul fast float %1005, 0x400370A3E0000000
  %1020 = fadd fast float %1017, 0x3FE2E147A0000000
  %1021 = fadd fast float %1018, 0x3FE2E147A0000000
  %1022 = fadd fast float %1019, 0x3FE2E147A0000000
  %1023 = fmul fast float %1020, %1003
  %1024 = fmul fast float %1021, %1004
  %1025 = fmul fast float %1022, %1005
  %1026 = fadd fast float %1023, 0x3FC1EB8520000000
  %1027 = fadd fast float %1024, 0x3FC1EB8520000000
  %1028 = fadd fast float %1025, 0x3FC1EB8520000000
  %1029 = fdiv fast float %1014, %1026
  %1030 = fdiv fast float %1015, %1027
  %1031 = fdiv fast float %1016, %1028
  br label %1032

; <label>:1032                                    ; preds = %1007, %993
  %1033 = phi float [ %1029, %1007 ], [ %1003, %993 ]
  %1034 = phi float [ %1030, %1007 ], [ %1004, %993 ]
  %1035 = phi float [ %1031, %1007 ], [ %1005, %993 ]
  %1036 = call float @dx.op.unary.f32(i32 7, float %1033)  ; Saturate(value)
  %1037 = call float @dx.op.unary.f32(i32 7, float %1034)  ; Saturate(value)
  %1038 = call float @dx.op.unary.f32(i32 7, float %1035)  ; Saturate(value)
  %1039 = call float @dx.op.dot3.f32(i32 55, float %1036, float %1037, float %1038, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1040 = fsub fast float %1036, %1039
  %1041 = fsub fast float %1037, %1039
  %1042 = fsub fast float %1038, %1039
  %1043 = fmul fast float %1040, %6
  %1044 = fmul fast float %1041, %6
  %1045 = fmul fast float %1042, %6
  %1046 = fadd fast float %1043, %1039
  %1047 = fadd fast float %1044, %1039
  %1048 = fadd fast float %1045, %1039
  %1049 = call float @dx.op.unary.f32(i32 7, float %1046)  ; Saturate(value)
  %1050 = call float @dx.op.unary.f32(i32 7, float %1047)  ; Saturate(value)
  %1051 = call float @dx.op.unary.f32(i32 7, float %1048)  ; Saturate(value)
  %1052 = fadd fast float %1049, 0xBFC70A3D80000000
  %1053 = fadd fast float %1050, 0xBFC70A3D80000000
  %1054 = fadd fast float %1051, 0xBFC70A3D80000000
  %1055 = fmul fast float %1052, %5
  %1056 = fmul fast float %1053, %5
  %1057 = fmul fast float %1054, %5
  %1058 = fadd fast float %1055, 0x3FC70A3D80000000
  %1059 = fadd fast float %1056, 0x3FC70A3D80000000
  %1060 = fadd fast float %1057, 0x3FC70A3D80000000
  %1061 = call float @dx.op.unary.f32(i32 7, float %1058)  ; Saturate(value)
  %1062 = call float @dx.op.unary.f32(i32 7, float %1059)  ; Saturate(value)
  %1063 = call float @dx.op.unary.f32(i32 7, float %1060)  ; Saturate(value)
  br label %1064

; <label>:1064                                    ; preds = %1032, %813
  %1065 = phi float [ %844, %813 ], [ %1061, %1032 ]
  %1066 = phi float [ %845, %813 ], [ %1062, %1032 ]
  %1067 = phi float [ %846, %813 ], [ %1063, %1032 ]
  %1068 = add i32 %43, 1
  %1069 = call i32 @dx.op.binary.i32(i32 37, i32 %1068, i32 0)  ; IMax(a,b)
  %1070 = call i32 @dx.op.binary.i32(i32 38, i32 %1069, i32 %271)  ; IMin(a,b)
  %1071 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1070, i32 %806, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1072 = extractvalue %dx.types.ResRet.f32 %1071, 0
  %1073 = extractvalue %dx.types.ResRet.f32 %1071, 1
  %1074 = extractvalue %dx.types.ResRet.f32 %1071, 2
  %1075 = extractvalue %dx.types.ResRet.f32 %1071, 3
  %1076 = fcmp fast olt float %1075, 0.000000e+00
  br i1 %1076, label %1077, label %1111

; <label>:1077                                    ; preds = %1064
  %1078 = fcmp fast ogt float %1072, 0x3FA4B5DCC0000000
  %1079 = fcmp fast ogt float %1073, 0x3FA4B5DCC0000000
  %1080 = fcmp fast ogt float %1074, 0x3FA4B5DCC0000000
  %1081 = select i1 %1078, float 0.000000e+00, float 1.000000e+00
  %1082 = select i1 %1079, float 0.000000e+00, float 1.000000e+00
  %1083 = select i1 %1080, float 0.000000e+00, float 1.000000e+00
  %1084 = fmul fast float %1072, 0x3FB3D07220000000
  %1085 = fmul fast float %1073, 0x3FB3D07220000000
  %1086 = fmul fast float %1074, 0x3FB3D07220000000
  %1087 = fadd fast float %1072, 0x3FAC28F5C0000000
  %1088 = fadd fast float %1073, 0x3FAC28F5C0000000
  %1089 = fadd fast float %1074, 0x3FAC28F5C0000000
  %1090 = fmul fast float %1087, 0x3FEE54EDE0000000
  %1091 = fmul fast float %1088, 0x3FEE54EDE0000000
  %1092 = fmul fast float %1089, 0x3FEE54EDE0000000
  %1093 = call float @dx.op.unary.f32(i32 23, float %1090)  ; Log(value)
  %1094 = call float @dx.op.unary.f32(i32 23, float %1091)  ; Log(value)
  %1095 = call float @dx.op.unary.f32(i32 23, float %1092)  ; Log(value)
  %1096 = fmul fast float %1093, 0x4003333340000000
  %1097 = fmul fast float %1094, 0x4003333340000000
  %1098 = fmul fast float %1095, 0x4003333340000000
  %1099 = call float @dx.op.unary.f32(i32 21, float %1096)  ; Exp(value)
  %1100 = call float @dx.op.unary.f32(i32 21, float %1097)  ; Exp(value)
  %1101 = call float @dx.op.unary.f32(i32 21, float %1098)  ; Exp(value)
  %1102 = fsub fast float %1084, %1099
  %1103 = fsub fast float %1085, %1100
  %1104 = fsub fast float %1086, %1101
  %1105 = fmul fast float %1102, %1081
  %1106 = fmul fast float %1103, %1082
  %1107 = fmul fast float %1104, %1083
  %1108 = fadd fast float %1105, %1099
  %1109 = fadd fast float %1106, %1100
  %1110 = fadd fast float %1107, %1101
  br label %1328

; <label>:1111                                    ; preds = %1064
  %1112 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1070, i32 %806, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1113 = extractvalue %dx.types.ResRet.f32 %1112, 0
  %1114 = fcmp fast ogt float %36, 5.000000e-01
  %1115 = fcmp fast olt float %1113, 1.000000e+00
  %1116 = and i1 %1114, %1115
  br i1 %1116, label %1117, label %1257

; <label>:1117                                    ; preds = %1111
  %1118 = sitofp i32 %1070 to float
  %1119 = sitofp i32 %806 to float
  %1120 = fadd fast float %1118, 5.000000e-01
  %1121 = fadd fast float %1119, 5.000000e-01
  %1122 = uitofp i32 %41 to float
  %1123 = uitofp i32 %42 to float
  %1124 = fdiv fast float %1120, %1122
  %1125 = fdiv fast float %1121, %1123
  %1126 = fmul fast float %1124, 2.000000e+00
  %1127 = fmul fast float %1125, 2.000000e+00
  %1128 = fadd fast float %1126, -1.000000e+00
  %1129 = fsub fast float 1.000000e+00, %1127
  %1130 = fmul fast float %1128, %33
  %1131 = call float @dx.op.tertiary.f32(i32 46, float %1129, float %29, float %1130)  ; FMad(a,b,c)
  %1132 = call float @dx.op.tertiary.f32(i32 46, float %1113, float %25, float %1131)  ; FMad(a,b,c)
  %1133 = fadd fast float %1132, %21
  %1134 = call float @dx.op.unary.f32(i32 6, float %1133)  ; FAbs(value)
  %1135 = fcmp fast ogt float %1134, 0x3EB0C6F7A0000000
  br i1 %1135, label %1136, label %1257

; <label>:1136                                    ; preds = %1117
  %1137 = fmul fast float %1128, %32
  %1138 = call float @dx.op.tertiary.f32(i32 46, float %1129, float %28, float %1137)  ; FMad(a,b,c)
  %1139 = call float @dx.op.tertiary.f32(i32 46, float %1113, float %24, float %1138)  ; FMad(a,b,c)
  %1140 = fadd fast float %1139, %20
  %1141 = fmul fast float %1128, %31
  %1142 = call float @dx.op.tertiary.f32(i32 46, float %1129, float %27, float %1141)  ; FMad(a,b,c)
  %1143 = call float @dx.op.tertiary.f32(i32 46, float %1113, float %23, float %1142)  ; FMad(a,b,c)
  %1144 = fadd fast float %1143, %19
  %1145 = fmul fast float %1128, %30
  %1146 = call float @dx.op.tertiary.f32(i32 46, float %1129, float %26, float %1145)  ; FMad(a,b,c)
  %1147 = call float @dx.op.tertiary.f32(i32 46, float %1113, float %22, float %1146)  ; FMad(a,b,c)
  %1148 = fadd fast float %1147, %18
  %1149 = fdiv fast float %1148, %1133
  %1150 = fdiv fast float %1144, %1133
  %1151 = fdiv fast float %1140, %1133
  %1152 = fsub fast float %1149, %15
  %1153 = fsub fast float %1150, %16
  %1154 = fsub fast float %1151, %17
  %1155 = fmul fast float %1152, %1152
  %1156 = fmul fast float %1153, %1153
  %1157 = fadd fast float %1156, %1155
  %1158 = fmul fast float %1154, %1154
  %1159 = fadd fast float %1157, %1158
  %1160 = call float @dx.op.unary.f32(i32 24, float %1159)  ; Sqrt(value)
  %1161 = fsub fast float %1160, %7
  %1162 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1161)  ; FMax(a,b)
  %1163 = fcmp fast ogt float %37, 1.500000e+00
  br i1 %1163, label %1164, label %1187

; <label>:1164                                    ; preds = %1136
  %1165 = call float @dx.op.unary.f32(i32 6, float %1153)  ; FAbs(value)
  %1166 = fmul fast float %1165, %9
  %1167 = fcmp fast olt float %1166, 0x3F50624DE0000000
  br i1 %1167, label %1168, label %1171

; <label>:1168                                    ; preds = %1164
  %1169 = fmul fast float %1166, 5.000000e-01
  %1170 = fsub fast float 1.000000e+00, %1169
  br label %1176

; <label>:1171                                    ; preds = %1164
  %1172 = fmul fast float %1166, 0xBFF7154760000000
  %1173 = call float @dx.op.unary.f32(i32 21, float %1172)  ; Exp(value)
  %1174 = fsub fast float 1.000000e+00, %1173
  %1175 = fdiv fast float %1174, %1166
  br label %1176

; <label>:1176                                    ; preds = %1171, %1168
  %1177 = phi float [ %1170, %1168 ], [ %1175, %1171 ]
  %1178 = call float @dx.op.binary.f32(i32 36, float %1150, float %16)  ; FMin(a,b)
  %1179 = fsub fast float %1178, %8
  %1180 = fmul fast float %9, %1179
  %1181 = fsub fast float -0.000000e+00, %1180
  %1182 = call float @dx.op.binary.f32(i32 35, float %1181, float -4.000000e+01)  ; FMax(a,b)
  %1183 = call float @dx.op.binary.f32(i32 36, float %1182, float 5.000000e+00)  ; FMin(a,b)
  %1184 = fmul fast float %1183, 0x3FF7154760000000
  %1185 = call float @dx.op.unary.f32(i32 21, float %1184)  ; Exp(value)
  %1186 = fmul fast float %1185, %1177
  br label %1187

; <label>:1187                                    ; preds = %1176, %1136
  %1188 = phi float [ %1186, %1176 ], [ 1.000000e+00, %1136 ]
  %1189 = fmul fast float %1162, %14
  %1190 = fmul fast float %1189, %1188
  %1191 = fcmp fast ole float %1160, %7
  %1192 = fcmp fast olt float %1160, 0x3F1A36E2E0000000
  %1193 = or i1 %1191, %1192
  br i1 %1193, label %1240, label %1194

; <label>:1194                                    ; preds = %1187
  %1195 = fdiv fast float %7, %1160
  %1196 = fmul fast float %1195, %1152
  %1197 = fmul fast float %1195, %1153
  %1198 = fmul fast float %1195, %1154
  %1199 = fadd fast float %1196, %15
  %1200 = fadd fast float %1197, %16
  %1201 = fadd fast float %1198, %17
  %1202 = fadd fast float %1199, -9.000000e+02
  %1203 = fadd fast float %1200, -1.500000e+01
  %1204 = fadd fast float %1201, -7.500000e+02
  %1205 = fmul fast float %1202, 0x3F62345680000000
  %1206 = fmul fast float %1203, 0x3F62345680000000
  %1207 = fmul fast float %1204, 0x3F62345680000000
  %1208 = call float @dx.op.dot3.f32(i32 55, float %1205, float %1206, float %1207, float %1205, float %1206, float %1207)  ; Dot3(ax,ay,az,bx,by,bz)
  %1209 = fsub fast float 1.000000e+00, %1208
  %1210 = call float @dx.op.unary.f32(i32 7, float %1209)  ; Saturate(value)
  %1211 = fmul fast float %1210, %1210
  %1212 = fadd fast float %1199, %1149
  %1213 = fadd fast float %1200, %1150
  %1214 = fadd fast float %1201, %1151
  %1215 = fmul fast float %1212, 0x3F52345680000000
  %1216 = fadd fast float %1215, -2.000000e+00
  %1217 = fmul fast float %1213, 0x3F52345680000000
  %1218 = fadd fast float %1217, 0xBFA1111120000000
  %1219 = fmul fast float %1214, 0x3F52345680000000
  %1220 = fadd fast float %1219, 0xBFFAAAAAC0000000
  %1221 = call float @dx.op.dot3.f32(i32 55, float %1216, float %1218, float %1220, float %1216, float %1218, float %1220)  ; Dot3(ax,ay,az,bx,by,bz)
  %1222 = fsub fast float 1.000000e+00, %1221
  %1223 = call float @dx.op.unary.f32(i32 7, float %1222)  ; Saturate(value)
  %1224 = fmul fast float %1223, %1223
  %1225 = fmul fast float %1224, 4.000000e+00
  %1226 = fadd fast float %1225, %1211
  %1227 = fadd fast float %1149, -9.000000e+02
  %1228 = fadd fast float %1150, -1.500000e+01
  %1229 = fadd fast float %1151, -7.500000e+02
  %1230 = fmul fast float %1227, 0x3F62345680000000
  %1231 = fmul fast float %1228, 0x3F62345680000000
  %1232 = fmul fast float %1229, 0x3F62345680000000
  %1233 = call float @dx.op.dot3.f32(i32 55, float %1230, float %1231, float %1232, float %1230, float %1231, float %1232)  ; Dot3(ax,ay,az,bx,by,bz)
  %1234 = fsub fast float 1.000000e+00, %1233
  %1235 = call float @dx.op.unary.f32(i32 7, float %1234)  ; Saturate(value)
  %1236 = fmul fast float %1235, %1235
  %1237 = fadd fast float %1226, %1236
  %1238 = fmul fast float %1161, 0x3F25D867E0000000
  %1239 = fmul fast float %1238, %1237
  br label %1240

; <label>:1240                                    ; preds = %1194, %1187
  %1241 = phi float [ %1239, %1194 ], [ 0.000000e+00, %1187 ]
  %1242 = fadd fast float %1241, %1190
  %1243 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1242)  ; FMin(a,b)
  %1244 = fmul fast float %1243, 0xBFF7154760000000
  %1245 = call float @dx.op.unary.f32(i32 21, float %1244)  ; Exp(value)
  %1246 = fsub fast float 1.000000e+00, %1245
  %1247 = call float @dx.op.binary.f32(i32 36, float %10, float %1246)  ; FMin(a,b)
  %1248 = fsub fast float %11, %1072
  %1249 = fsub fast float %12, %1073
  %1250 = fsub fast float %13, %1074
  %1251 = fmul fast float %1247, %1248
  %1252 = fmul fast float %1247, %1249
  %1253 = fmul fast float %1247, %1250
  %1254 = fadd fast float %1251, %1072
  %1255 = fadd fast float %1252, %1073
  %1256 = fadd fast float %1253, %1074
  br label %1257

; <label>:1257                                    ; preds = %1240, %1117, %1111
  %1258 = phi float [ %1254, %1240 ], [ %1072, %1117 ], [ %1072, %1111 ]
  %1259 = phi float [ %1255, %1240 ], [ %1073, %1117 ], [ %1073, %1111 ]
  %1260 = phi float [ %1256, %1240 ], [ %1074, %1117 ], [ %1074, %1111 ]
  %1261 = fadd fast float %3, 1.000000e+00
  %1262 = fadd fast float %4, 1.000000e+00
  %1263 = fsub fast float 1.000000e+00, %3
  %1264 = fmul fast float %34, %1261
  %1265 = fmul fast float %34, %1262
  %1266 = fmul fast float %34, %1263
  %1267 = fmul fast float %1264, %1258
  %1268 = fmul fast float %1265, %1259
  %1269 = fmul fast float %1266, %1260
  %1270 = fcmp fast ult float %35, 5.000000e-01
  br i1 %1270, label %1296, label %1271

; <label>:1271                                    ; preds = %1257
  %1272 = fmul fast float %1267, 0x4004147AE0000000
  %1273 = fmul fast float %1268, 0x4004147AE0000000
  %1274 = fmul fast float %1269, 0x4004147AE0000000
  %1275 = fadd fast float %1272, 0x3F9EB851E0000000
  %1276 = fadd fast float %1273, 0x3F9EB851E0000000
  %1277 = fadd fast float %1274, 0x3F9EB851E0000000
  %1278 = fmul fast float %1275, %1267
  %1279 = fmul fast float %1276, %1268
  %1280 = fmul fast float %1277, %1269
  %1281 = fmul fast float %1267, 0x400370A3E0000000
  %1282 = fmul fast float %1268, 0x400370A3E0000000
  %1283 = fmul fast float %1269, 0x400370A3E0000000
  %1284 = fadd fast float %1281, 0x3FE2E147A0000000
  %1285 = fadd fast float %1282, 0x3FE2E147A0000000
  %1286 = fadd fast float %1283, 0x3FE2E147A0000000
  %1287 = fmul fast float %1284, %1267
  %1288 = fmul fast float %1285, %1268
  %1289 = fmul fast float %1286, %1269
  %1290 = fadd fast float %1287, 0x3FC1EB8520000000
  %1291 = fadd fast float %1288, 0x3FC1EB8520000000
  %1292 = fadd fast float %1289, 0x3FC1EB8520000000
  %1293 = fdiv fast float %1278, %1290
  %1294 = fdiv fast float %1279, %1291
  %1295 = fdiv fast float %1280, %1292
  br label %1296

; <label>:1296                                    ; preds = %1271, %1257
  %1297 = phi float [ %1293, %1271 ], [ %1267, %1257 ]
  %1298 = phi float [ %1294, %1271 ], [ %1268, %1257 ]
  %1299 = phi float [ %1295, %1271 ], [ %1269, %1257 ]
  %1300 = call float @dx.op.unary.f32(i32 7, float %1297)  ; Saturate(value)
  %1301 = call float @dx.op.unary.f32(i32 7, float %1298)  ; Saturate(value)
  %1302 = call float @dx.op.unary.f32(i32 7, float %1299)  ; Saturate(value)
  %1303 = call float @dx.op.dot3.f32(i32 55, float %1300, float %1301, float %1302, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1304 = fsub fast float %1300, %1303
  %1305 = fsub fast float %1301, %1303
  %1306 = fsub fast float %1302, %1303
  %1307 = fmul fast float %1304, %6
  %1308 = fmul fast float %1305, %6
  %1309 = fmul fast float %1306, %6
  %1310 = fadd fast float %1307, %1303
  %1311 = fadd fast float %1308, %1303
  %1312 = fadd fast float %1309, %1303
  %1313 = call float @dx.op.unary.f32(i32 7, float %1310)  ; Saturate(value)
  %1314 = call float @dx.op.unary.f32(i32 7, float %1311)  ; Saturate(value)
  %1315 = call float @dx.op.unary.f32(i32 7, float %1312)  ; Saturate(value)
  %1316 = fadd fast float %1313, 0xBFC70A3D80000000
  %1317 = fadd fast float %1314, 0xBFC70A3D80000000
  %1318 = fadd fast float %1315, 0xBFC70A3D80000000
  %1319 = fmul fast float %1316, %5
  %1320 = fmul fast float %1317, %5
  %1321 = fmul fast float %1318, %5
  %1322 = fadd fast float %1319, 0x3FC70A3D80000000
  %1323 = fadd fast float %1320, 0x3FC70A3D80000000
  %1324 = fadd fast float %1321, 0x3FC70A3D80000000
  %1325 = call float @dx.op.unary.f32(i32 7, float %1322)  ; Saturate(value)
  %1326 = call float @dx.op.unary.f32(i32 7, float %1323)  ; Saturate(value)
  %1327 = call float @dx.op.unary.f32(i32 7, float %1324)  ; Saturate(value)
  br label %1328

; <label>:1328                                    ; preds = %1296, %1077
  %1329 = phi float [ %1108, %1077 ], [ %1325, %1296 ]
  %1330 = phi float [ %1109, %1077 ], [ %1326, %1296 ]
  %1331 = phi float [ %1110, %1077 ], [ %1327, %1296 ]
  %1332 = call float @dx.op.binary.f32(i32 36, float %1065, float %1329)  ; FMin(a,b)
  %1333 = call float @dx.op.binary.f32(i32 36, float %1066, float %1330)  ; FMin(a,b)
  %1334 = call float @dx.op.binary.f32(i32 36, float %1067, float %1331)  ; FMin(a,b)
  %1335 = call float @dx.op.binary.f32(i32 36, float %535, float %799)  ; FMin(a,b)
  %1336 = call float @dx.op.binary.f32(i32 36, float %536, float %800)  ; FMin(a,b)
  %1337 = call float @dx.op.binary.f32(i32 36, float %537, float %801)  ; FMin(a,b)
  %1338 = call float @dx.op.binary.f32(i32 36, float %1335, float %1332)  ; FMin(a,b)
  %1339 = call float @dx.op.binary.f32(i32 36, float %1336, float %1333)  ; FMin(a,b)
  %1340 = call float @dx.op.binary.f32(i32 36, float %1337, float %1334)  ; FMin(a,b)
  %1341 = call float @dx.op.binary.f32(i32 36, float %267, float %1338)  ; FMin(a,b)
  %1342 = call float @dx.op.binary.f32(i32 36, float %268, float %1339)  ; FMin(a,b)
  %1343 = call float @dx.op.binary.f32(i32 36, float %269, float %1340)  ; FMin(a,b)
  %1344 = call float @dx.op.binary.f32(i32 35, float %1065, float %1329)  ; FMax(a,b)
  %1345 = call float @dx.op.binary.f32(i32 35, float %1066, float %1330)  ; FMax(a,b)
  %1346 = call float @dx.op.binary.f32(i32 35, float %1067, float %1331)  ; FMax(a,b)
  %1347 = call float @dx.op.binary.f32(i32 35, float %535, float %799)  ; FMax(a,b)
  %1348 = call float @dx.op.binary.f32(i32 35, float %536, float %800)  ; FMax(a,b)
  %1349 = call float @dx.op.binary.f32(i32 35, float %537, float %801)  ; FMax(a,b)
  %1350 = call float @dx.op.binary.f32(i32 35, float %1347, float %1344)  ; FMax(a,b)
  %1351 = call float @dx.op.binary.f32(i32 35, float %1348, float %1345)  ; FMax(a,b)
  %1352 = call float @dx.op.binary.f32(i32 35, float %1349, float %1346)  ; FMax(a,b)
  %1353 = call float @dx.op.binary.f32(i32 35, float %267, float %1350)  ; FMax(a,b)
  %1354 = call float @dx.op.binary.f32(i32 35, float %268, float %1351)  ; FMax(a,b)
  %1355 = call float @dx.op.binary.f32(i32 35, float %269, float %1352)  ; FMax(a,b)
  %1356 = fsub fast float %1353, %1341
  %1357 = fsub fast float %1354, %1342
  %1358 = fsub fast float %1355, %1343
  %1359 = call float @dx.op.unary.f32(i32 6, float %1356)  ; FAbs(value)
  %1360 = call float @dx.op.unary.f32(i32 6, float %1357)  ; FAbs(value)
  %1361 = call float @dx.op.unary.f32(i32 6, float %1358)  ; FAbs(value)
  %1362 = call float @dx.op.binary.f32(i32 35, float %1360, float %1361)  ; FMax(a,b)
  %1363 = call float @dx.op.binary.f32(i32 35, float %1359, float %1362)  ; FMax(a,b)
  %1364 = call float @dx.op.binary.f32(i32 35, float %1354, float %1355)  ; FMax(a,b)
  %1365 = call float @dx.op.binary.f32(i32 35, float %1353, float %1364)  ; FMax(a,b)
  %1366 = fmul fast float %1365, 1.250000e-01
  %1367 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1366)  ; FMax(a,b)
  %1368 = fcmp fast ogt float %1363, %1367
  br i1 %1368, label %1369, label %1430

; <label>:1369                                    ; preds = %1328
  %1370 = fsub fast float %535, %799
  %1371 = fsub fast float %536, %800
  %1372 = fsub fast float %537, %801
  %1373 = call float @dx.op.unary.f32(i32 6, float %1370)  ; FAbs(value)
  %1374 = call float @dx.op.unary.f32(i32 6, float %1371)  ; FAbs(value)
  %1375 = call float @dx.op.unary.f32(i32 6, float %1372)  ; FAbs(value)
  %1376 = call float @dx.op.binary.f32(i32 35, float %1374, float %1375)  ; FMax(a,b)
  %1377 = call float @dx.op.binary.f32(i32 35, float %1373, float %1376)  ; FMax(a,b)
  %1378 = fsub fast float %1065, %1329
  %1379 = fsub fast float %1066, %1330
  %1380 = fsub fast float %1067, %1331
  %1381 = call float @dx.op.unary.f32(i32 6, float %1378)  ; FAbs(value)
  %1382 = call float @dx.op.unary.f32(i32 6, float %1379)  ; FAbs(value)
  %1383 = call float @dx.op.unary.f32(i32 6, float %1380)  ; FAbs(value)
  %1384 = call float @dx.op.binary.f32(i32 35, float %1382, float %1383)  ; FMax(a,b)
  %1385 = call float @dx.op.binary.f32(i32 35, float %1381, float %1384)  ; FMax(a,b)
  %1386 = fcmp fast olt float %1377, %1385
  %1387 = select i1 %1386, float %535, float %1065
  %1388 = select i1 %1386, float %536, float %1066
  %1389 = select i1 %1386, float %537, float %1067
  %1390 = select i1 %1386, float %799, float %1329
  %1391 = select i1 %1386, float %800, float %1330
  %1392 = select i1 %1386, float %801, float %1331
  %1393 = fsub fast float %267, %1390
  %1394 = fsub fast float %268, %1391
  %1395 = fsub fast float %269, %1392
  %1396 = fsub fast float %267, %1387
  %1397 = fsub fast float %268, %1388
  %1398 = fsub fast float %269, %1389
  %1399 = call float @dx.op.dot3.f32(i32 55, float %1396, float %1397, float %1398, float %1393, float %1394, float %1395)  ; Dot3(ax,ay,az,bx,by,bz)
  %1400 = fcmp fast ogt float %1399, 0.000000e+00
  br i1 %1400, label %1401, label %1413

; <label>:1401                                    ; preds = %1369
  %1402 = fsub fast float %1387, %1390
  %1403 = fsub fast float %1388, %1391
  %1404 = fsub fast float %1389, %1392
  %1405 = call float @dx.op.unary.f32(i32 6, float %1402)  ; FAbs(value)
  %1406 = call float @dx.op.unary.f32(i32 6, float %1403)  ; FAbs(value)
  %1407 = call float @dx.op.unary.f32(i32 6, float %1404)  ; FAbs(value)
  %1408 = call float @dx.op.binary.f32(i32 35, float %1406, float %1407)  ; FMax(a,b)
  %1409 = call float @dx.op.binary.f32(i32 35, float %1405, float %1408)  ; FMax(a,b)
  %1410 = fmul fast float %1363, 2.500000e-01
  %1411 = fcmp fast olt float %1409, %1410
  %1412 = select i1 %1411, float 0x3FC3333340000000, float 0x3FD3333340000000
  br label %1413

; <label>:1413                                    ; preds = %1401, %1369
  %1414 = phi float [ 0x3FD3333340000000, %1369 ], [ %1412, %1401 ]
  %1415 = fadd fast float %1387, %1390
  %1416 = fadd fast float %1388, %1391
  %1417 = fadd fast float %1389, %1392
  %1418 = fmul fast float %1415, 5.000000e-01
  %1419 = fmul fast float %1416, 5.000000e-01
  %1420 = fmul fast float %1417, 5.000000e-01
  %1421 = fsub fast float %1418, %267
  %1422 = fsub fast float %1419, %268
  %1423 = fsub fast float %1420, %269
  %1424 = fmul fast float %1414, %1421
  %1425 = fmul fast float %1414, %1422
  %1426 = fmul fast float %1414, %1423
  %1427 = fadd fast float %1424, %267
  %1428 = fadd fast float %1425, %268
  %1429 = fadd fast float %1426, %269
  br label %1430

; <label>:1430                                    ; preds = %1413, %1328
  %1431 = phi float [ %1427, %1413 ], [ %267, %1328 ]
  %1432 = phi float [ %1428, %1413 ], [ %268, %1328 ]
  %1433 = phi float [ %1429, %1413 ], [ %269, %1328 ]
  %1434 = fcmp fast ogt float %1431, 0x3F69A5C380000000
  %1435 = fcmp fast ogt float %1432, 0x3F69A5C380000000
  %1436 = fcmp fast ogt float %1433, 0x3F69A5C380000000
  %1437 = select i1 %1434, float 0.000000e+00, float 1.000000e+00
  %1438 = select i1 %1435, float 0.000000e+00, float 1.000000e+00
  %1439 = select i1 %1436, float 0.000000e+00, float 1.000000e+00
  %1440 = fmul fast float %1431, 0x4029D70A40000000
  %1441 = fmul fast float %1432, 0x4029D70A40000000
  %1442 = fmul fast float %1433, 0x4029D70A40000000
  %1443 = call float @dx.op.binary.f32(i32 35, float %1431, float 0.000000e+00)  ; FMax(a,b)
  %1444 = call float @dx.op.binary.f32(i32 35, float %1432, float 0.000000e+00)  ; FMax(a,b)
  %1445 = call float @dx.op.binary.f32(i32 35, float %1433, float 0.000000e+00)  ; FMax(a,b)
  %1446 = call float @dx.op.unary.f32(i32 23, float %1443)  ; Log(value)
  %1447 = call float @dx.op.unary.f32(i32 23, float %1444)  ; Log(value)
  %1448 = call float @dx.op.unary.f32(i32 23, float %1445)  ; Log(value)
  %1449 = fmul fast float %1446, 0x3FDAAAAAA0000000
  %1450 = fmul fast float %1447, 0x3FDAAAAAA0000000
  %1451 = fmul fast float %1448, 0x3FDAAAAAA0000000
  %1452 = call float @dx.op.unary.f32(i32 21, float %1449)  ; Exp(value)
  %1453 = call float @dx.op.unary.f32(i32 21, float %1450)  ; Exp(value)
  %1454 = call float @dx.op.unary.f32(i32 21, float %1451)  ; Exp(value)
  %1455 = fmul fast float %1452, 0x3FF0E147A0000000
  %1456 = fmul fast float %1453, 0x3FF0E147A0000000
  %1457 = fmul fast float %1454, 0x3FF0E147A0000000
  %1458 = fadd fast float %1455, 0xBFAC28F5C0000000
  %1459 = fadd fast float %1456, 0xBFAC28F5C0000000
  %1460 = fadd fast float %1457, 0xBFAC28F5C0000000
  %1461 = fsub fast float %1440, %1458
  %1462 = fsub fast float %1441, %1459
  %1463 = fsub fast float %1442, %1460
  %1464 = fmul fast float %1461, %1437
  %1465 = fmul fast float %1462, %1438
  %1466 = fmul fast float %1463, %1439
  %1467 = fadd fast float %1464, %1458
  %1468 = fadd fast float %1465, %1459
  %1469 = fadd fast float %1466, %1460
  br label %1470

; <label>:1470                                    ; preds = %1430, %51
  %1471 = phi float [ %46, %51 ], [ %1467, %1430 ]
  %1472 = phi float [ %47, %51 ], [ %1468, %1430 ]
  %1473 = phi float [ %48, %51 ], [ %1469, %1430 ]
  %1474 = phi float [ %52, %51 ], [ %49, %1430 ]
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %1471)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %1472)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %1473)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %1474)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 0, i32 0, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !37, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, null}
!36 = !{i32 9}
!37 = !{!38}
!38 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
