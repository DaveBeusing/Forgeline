;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float       
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
;
; shader hash: a535c561e4716b8a2009ddc91cce62d7
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=0
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 1
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39 }
;   output 3 depends on inputs: { 0, 1 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %40 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %41 = extractvalue %dx.types.Dimensions %40, 0
  %42 = extractvalue %dx.types.Dimensions %40, 1
  %43 = fptosi float %38 to i32
  %44 = fptosi float %39 to i32
  %45 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %43, i32 %44, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %46 = extractvalue %dx.types.ResRet.f32 %45, 0
  %47 = extractvalue %dx.types.ResRet.f32 %45, 1
  %48 = extractvalue %dx.types.ResRet.f32 %45, 2
  %49 = extractvalue %dx.types.ResRet.f32 %45, 3
  %50 = fcmp fast olt float %49, 0.000000e+00
  br i1 %50, label %51, label %53

; <label>:51                                      ; preds = %0
  %52 = fsub fast float -1.000000e+00, %49
  br label %1222

; <label>:53                                      ; preds = %0
  %54 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %43, i32 %44, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %55 = extractvalue %dx.types.ResRet.f32 %54, 0
  %56 = fcmp fast ogt float %36, 5.000000e-01
  %57 = fcmp fast olt float %55, 1.000000e+00
  %58 = and i1 %56, %57
  br i1 %58, label %59, label %147

; <label>:59                                      ; preds = %53
  %60 = sitofp i32 %43 to float
  %61 = sitofp i32 %44 to float
  %62 = fadd fast float %60, 5.000000e-01
  %63 = fadd fast float %61, 5.000000e-01
  %64 = uitofp i32 %41 to float
  %65 = uitofp i32 %42 to float
  %66 = fdiv fast float %62, %64
  %67 = fdiv fast float %63, %65
  %68 = fmul fast float %66, 2.000000e+00
  %69 = fmul fast float %67, 2.000000e+00
  %70 = fadd fast float %68, -1.000000e+00
  %71 = fsub fast float 1.000000e+00, %69
  %72 = fmul fast float %70, %33
  %73 = call float @dx.op.tertiary.f32(i32 46, float %71, float %29, float %72)  ; FMad(a,b,c)
  %74 = call float @dx.op.tertiary.f32(i32 46, float %55, float %25, float %73)  ; FMad(a,b,c)
  %75 = fadd fast float %74, %21
  %76 = call float @dx.op.unary.f32(i32 6, float %75)  ; FAbs(value)
  %77 = fcmp fast ogt float %76, 0x3EB0C6F7A0000000
  br i1 %77, label %78, label %147

; <label>:78                                      ; preds = %59
  %79 = fmul fast float %70, %32
  %80 = call float @dx.op.tertiary.f32(i32 46, float %71, float %28, float %79)  ; FMad(a,b,c)
  %81 = call float @dx.op.tertiary.f32(i32 46, float %55, float %24, float %80)  ; FMad(a,b,c)
  %82 = fadd fast float %81, %20
  %83 = fmul fast float %70, %31
  %84 = call float @dx.op.tertiary.f32(i32 46, float %71, float %27, float %83)  ; FMad(a,b,c)
  %85 = call float @dx.op.tertiary.f32(i32 46, float %55, float %23, float %84)  ; FMad(a,b,c)
  %86 = fadd fast float %85, %19
  %87 = fmul fast float %70, %30
  %88 = call float @dx.op.tertiary.f32(i32 46, float %71, float %26, float %87)  ; FMad(a,b,c)
  %89 = call float @dx.op.tertiary.f32(i32 46, float %55, float %22, float %88)  ; FMad(a,b,c)
  %90 = fadd fast float %89, %18
  %91 = fdiv fast float %90, %75
  %92 = fdiv fast float %86, %75
  %93 = fdiv fast float %82, %75
  %94 = fsub fast float %91, %15
  %95 = fsub fast float %92, %16
  %96 = fsub fast float %93, %17
  %97 = fmul fast float %94, %94
  %98 = fmul fast float %95, %95
  %99 = fadd fast float %98, %97
  %100 = fmul fast float %96, %96
  %101 = fadd fast float %99, %100
  %102 = call float @dx.op.unary.f32(i32 24, float %101)  ; Sqrt(value)
  %103 = fsub fast float %102, %7
  %104 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %103)  ; FMax(a,b)
  %105 = fcmp fast ogt float %37, 1.500000e+00
  br i1 %105, label %106, label %129

; <label>:106                                     ; preds = %78
  %107 = call float @dx.op.unary.f32(i32 6, float %95)  ; FAbs(value)
  %108 = fmul fast float %107, %9
  %109 = fcmp fast olt float %108, 0x3F50624DE0000000
  br i1 %109, label %110, label %113

; <label>:110                                     ; preds = %106
  %111 = fmul fast float %108, 5.000000e-01
  %112 = fsub fast float 1.000000e+00, %111
  br label %118

; <label>:113                                     ; preds = %106
  %114 = fmul fast float %108, 0xBFF7154760000000
  %115 = call float @dx.op.unary.f32(i32 21, float %114)  ; Exp(value)
  %116 = fsub fast float 1.000000e+00, %115
  %117 = fdiv fast float %116, %108
  br label %118

; <label>:118                                     ; preds = %113, %110
  %119 = phi float [ %112, %110 ], [ %117, %113 ]
  %120 = call float @dx.op.binary.f32(i32 36, float %92, float %16)  ; FMin(a,b)
  %121 = fsub fast float %120, %8
  %122 = fmul fast float %9, %121
  %123 = fsub fast float -0.000000e+00, %122
  %124 = call float @dx.op.binary.f32(i32 35, float %123, float -4.000000e+01)  ; FMax(a,b)
  %125 = call float @dx.op.binary.f32(i32 36, float %124, float 5.000000e+00)  ; FMin(a,b)
  %126 = fmul fast float %125, 0x3FF7154760000000
  %127 = call float @dx.op.unary.f32(i32 21, float %126)  ; Exp(value)
  %128 = fmul fast float %127, %119
  br label %129

; <label>:129                                     ; preds = %118, %78
  %130 = phi float [ %128, %118 ], [ 1.000000e+00, %78 ]
  %131 = fmul fast float %104, %14
  %132 = fmul fast float %131, %130
  %133 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %132)  ; FMin(a,b)
  %134 = fmul fast float %133, 0xBFF7154760000000
  %135 = call float @dx.op.unary.f32(i32 21, float %134)  ; Exp(value)
  %136 = fsub fast float 1.000000e+00, %135
  %137 = call float @dx.op.binary.f32(i32 36, float %10, float %136)  ; FMin(a,b)
  %138 = fsub fast float %11, %46
  %139 = fsub fast float %12, %47
  %140 = fsub fast float %13, %48
  %141 = fmul fast float %137, %138
  %142 = fmul fast float %137, %139
  %143 = fmul fast float %137, %140
  %144 = fadd fast float %141, %46
  %145 = fadd fast float %142, %47
  %146 = fadd fast float %143, %48
  br label %147

; <label>:147                                     ; preds = %129, %59, %53
  %148 = phi float [ %144, %129 ], [ %46, %59 ], [ %46, %53 ]
  %149 = phi float [ %145, %129 ], [ %47, %59 ], [ %47, %53 ]
  %150 = phi float [ %146, %129 ], [ %48, %59 ], [ %48, %53 ]
  %151 = fadd fast float %3, 1.000000e+00
  %152 = fadd fast float %4, 1.000000e+00
  %153 = fsub fast float 1.000000e+00, %3
  %154 = fmul fast float %34, %151
  %155 = fmul fast float %34, %152
  %156 = fmul fast float %34, %153
  %157 = fmul fast float %154, %148
  %158 = fmul fast float %155, %149
  %159 = fmul fast float %156, %150
  %160 = fcmp fast ult float %35, 5.000000e-01
  br i1 %160, label %186, label %161

; <label>:161                                     ; preds = %147
  %162 = fmul fast float %157, 0x4004147AE0000000
  %163 = fmul fast float %158, 0x4004147AE0000000
  %164 = fmul fast float %159, 0x4004147AE0000000
  %165 = fadd fast float %162, 0x3F9EB851E0000000
  %166 = fadd fast float %163, 0x3F9EB851E0000000
  %167 = fadd fast float %164, 0x3F9EB851E0000000
  %168 = fmul fast float %165, %157
  %169 = fmul fast float %166, %158
  %170 = fmul fast float %167, %159
  %171 = fmul fast float %157, 0x400370A3E0000000
  %172 = fmul fast float %158, 0x400370A3E0000000
  %173 = fmul fast float %159, 0x400370A3E0000000
  %174 = fadd fast float %171, 0x3FE2E147A0000000
  %175 = fadd fast float %172, 0x3FE2E147A0000000
  %176 = fadd fast float %173, 0x3FE2E147A0000000
  %177 = fmul fast float %174, %157
  %178 = fmul fast float %175, %158
  %179 = fmul fast float %176, %159
  %180 = fadd fast float %177, 0x3FC1EB8520000000
  %181 = fadd fast float %178, 0x3FC1EB8520000000
  %182 = fadd fast float %179, 0x3FC1EB8520000000
  %183 = fdiv fast float %168, %180
  %184 = fdiv fast float %169, %181
  %185 = fdiv fast float %170, %182
  br label %186

; <label>:186                                     ; preds = %161, %147
  %187 = phi float [ %183, %161 ], [ %157, %147 ]
  %188 = phi float [ %184, %161 ], [ %158, %147 ]
  %189 = phi float [ %185, %161 ], [ %159, %147 ]
  %190 = call float @dx.op.unary.f32(i32 7, float %187)  ; Saturate(value)
  %191 = call float @dx.op.unary.f32(i32 7, float %188)  ; Saturate(value)
  %192 = call float @dx.op.unary.f32(i32 7, float %189)  ; Saturate(value)
  %193 = call float @dx.op.dot3.f32(i32 55, float %190, float %191, float %192, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %194 = fsub fast float %190, %193
  %195 = fsub fast float %191, %193
  %196 = fsub fast float %192, %193
  %197 = fmul fast float %194, %6
  %198 = fmul fast float %195, %6
  %199 = fmul fast float %196, %6
  %200 = fadd fast float %197, %193
  %201 = fadd fast float %198, %193
  %202 = fadd fast float %199, %193
  %203 = call float @dx.op.unary.f32(i32 7, float %200)  ; Saturate(value)
  %204 = call float @dx.op.unary.f32(i32 7, float %201)  ; Saturate(value)
  %205 = call float @dx.op.unary.f32(i32 7, float %202)  ; Saturate(value)
  %206 = fadd fast float %203, 0xBFC70A3D80000000
  %207 = fadd fast float %204, 0xBFC70A3D80000000
  %208 = fadd fast float %205, 0xBFC70A3D80000000
  %209 = fmul fast float %206, %5
  %210 = fmul fast float %207, %5
  %211 = fmul fast float %208, %5
  %212 = fadd fast float %209, 0x3FC70A3D80000000
  %213 = fadd fast float %210, 0x3FC70A3D80000000
  %214 = fadd fast float %211, 0x3FC70A3D80000000
  %215 = call float @dx.op.unary.f32(i32 7, float %212)  ; Saturate(value)
  %216 = call float @dx.op.unary.f32(i32 7, float %213)  ; Saturate(value)
  %217 = call float @dx.op.unary.f32(i32 7, float %214)  ; Saturate(value)
  %218 = add i32 %44, -1
  %219 = add i32 %41, -1
  %220 = add i32 %42, -1
  %221 = call i32 @dx.op.binary.i32(i32 37, i32 %43, i32 0)  ; IMax(a,b)
  %222 = call i32 @dx.op.binary.i32(i32 37, i32 %218, i32 0)  ; IMax(a,b)
  %223 = call i32 @dx.op.binary.i32(i32 38, i32 %221, i32 %219)  ; IMin(a,b)
  %224 = call i32 @dx.op.binary.i32(i32 38, i32 %222, i32 %220)  ; IMin(a,b)
  %225 = call i32 @dx.op.binary.i32(i32 37, i32 %223, i32 0)  ; IMax(a,b)
  %226 = call i32 @dx.op.binary.i32(i32 37, i32 %224, i32 0)  ; IMax(a,b)
  %227 = call i32 @dx.op.binary.i32(i32 38, i32 %225, i32 %219)  ; IMin(a,b)
  %228 = call i32 @dx.op.binary.i32(i32 38, i32 %226, i32 %220)  ; IMin(a,b)
  %229 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %227, i32 %228, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %230 = extractvalue %dx.types.ResRet.f32 %229, 0
  %231 = extractvalue %dx.types.ResRet.f32 %229, 1
  %232 = extractvalue %dx.types.ResRet.f32 %229, 2
  %233 = extractvalue %dx.types.ResRet.f32 %229, 3
  %234 = fcmp fast olt float %233, 0.000000e+00
  br i1 %234, label %235, label %269

; <label>:235                                     ; preds = %186
  %236 = fcmp fast ogt float %230, 0x3FA4B5DCC0000000
  %237 = fcmp fast ogt float %231, 0x3FA4B5DCC0000000
  %238 = fcmp fast ogt float %232, 0x3FA4B5DCC0000000
  %239 = select i1 %236, float 0.000000e+00, float 1.000000e+00
  %240 = select i1 %237, float 0.000000e+00, float 1.000000e+00
  %241 = select i1 %238, float 0.000000e+00, float 1.000000e+00
  %242 = fmul fast float %230, 0x3FB3D07220000000
  %243 = fmul fast float %231, 0x3FB3D07220000000
  %244 = fmul fast float %232, 0x3FB3D07220000000
  %245 = fadd fast float %230, 0x3FAC28F5C0000000
  %246 = fadd fast float %231, 0x3FAC28F5C0000000
  %247 = fadd fast float %232, 0x3FAC28F5C0000000
  %248 = fmul fast float %245, 0x3FEE54EDE0000000
  %249 = fmul fast float %246, 0x3FEE54EDE0000000
  %250 = fmul fast float %247, 0x3FEE54EDE0000000
  %251 = call float @dx.op.unary.f32(i32 23, float %248)  ; Log(value)
  %252 = call float @dx.op.unary.f32(i32 23, float %249)  ; Log(value)
  %253 = call float @dx.op.unary.f32(i32 23, float %250)  ; Log(value)
  %254 = fmul fast float %251, 0x4003333340000000
  %255 = fmul fast float %252, 0x4003333340000000
  %256 = fmul fast float %253, 0x4003333340000000
  %257 = call float @dx.op.unary.f32(i32 21, float %254)  ; Exp(value)
  %258 = call float @dx.op.unary.f32(i32 21, float %255)  ; Exp(value)
  %259 = call float @dx.op.unary.f32(i32 21, float %256)  ; Exp(value)
  %260 = fsub fast float %242, %257
  %261 = fsub fast float %243, %258
  %262 = fsub fast float %244, %259
  %263 = fmul fast float %260, %239
  %264 = fmul fast float %261, %240
  %265 = fmul fast float %262, %241
  %266 = fadd fast float %263, %257
  %267 = fadd fast float %264, %258
  %268 = fadd fast float %265, %259
  br label %434

; <label>:269                                     ; preds = %186
  %270 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %227, i32 %228, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %271 = extractvalue %dx.types.ResRet.f32 %270, 0
  %272 = fcmp fast ogt float %36, 5.000000e-01
  %273 = fcmp fast olt float %271, 1.000000e+00
  %274 = and i1 %272, %273
  br i1 %274, label %275, label %363

; <label>:275                                     ; preds = %269
  %276 = sitofp i32 %227 to float
  %277 = sitofp i32 %228 to float
  %278 = fadd fast float %276, 5.000000e-01
  %279 = fadd fast float %277, 5.000000e-01
  %280 = uitofp i32 %41 to float
  %281 = uitofp i32 %42 to float
  %282 = fdiv fast float %278, %280
  %283 = fdiv fast float %279, %281
  %284 = fmul fast float %282, 2.000000e+00
  %285 = fmul fast float %283, 2.000000e+00
  %286 = fadd fast float %284, -1.000000e+00
  %287 = fsub fast float 1.000000e+00, %285
  %288 = fmul fast float %286, %33
  %289 = call float @dx.op.tertiary.f32(i32 46, float %287, float %29, float %288)  ; FMad(a,b,c)
  %290 = call float @dx.op.tertiary.f32(i32 46, float %271, float %25, float %289)  ; FMad(a,b,c)
  %291 = fadd fast float %290, %21
  %292 = call float @dx.op.unary.f32(i32 6, float %291)  ; FAbs(value)
  %293 = fcmp fast ogt float %292, 0x3EB0C6F7A0000000
  br i1 %293, label %294, label %363

; <label>:294                                     ; preds = %275
  %295 = fmul fast float %286, %32
  %296 = call float @dx.op.tertiary.f32(i32 46, float %287, float %28, float %295)  ; FMad(a,b,c)
  %297 = call float @dx.op.tertiary.f32(i32 46, float %271, float %24, float %296)  ; FMad(a,b,c)
  %298 = fadd fast float %297, %20
  %299 = fmul fast float %286, %31
  %300 = call float @dx.op.tertiary.f32(i32 46, float %287, float %27, float %299)  ; FMad(a,b,c)
  %301 = call float @dx.op.tertiary.f32(i32 46, float %271, float %23, float %300)  ; FMad(a,b,c)
  %302 = fadd fast float %301, %19
  %303 = fmul fast float %286, %30
  %304 = call float @dx.op.tertiary.f32(i32 46, float %287, float %26, float %303)  ; FMad(a,b,c)
  %305 = call float @dx.op.tertiary.f32(i32 46, float %271, float %22, float %304)  ; FMad(a,b,c)
  %306 = fadd fast float %305, %18
  %307 = fdiv fast float %306, %291
  %308 = fdiv fast float %302, %291
  %309 = fdiv fast float %298, %291
  %310 = fsub fast float %307, %15
  %311 = fsub fast float %308, %16
  %312 = fsub fast float %309, %17
  %313 = fmul fast float %310, %310
  %314 = fmul fast float %311, %311
  %315 = fadd fast float %314, %313
  %316 = fmul fast float %312, %312
  %317 = fadd fast float %315, %316
  %318 = call float @dx.op.unary.f32(i32 24, float %317)  ; Sqrt(value)
  %319 = fsub fast float %318, %7
  %320 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %319)  ; FMax(a,b)
  %321 = fcmp fast ogt float %37, 1.500000e+00
  br i1 %321, label %322, label %345

; <label>:322                                     ; preds = %294
  %323 = call float @dx.op.unary.f32(i32 6, float %311)  ; FAbs(value)
  %324 = fmul fast float %323, %9
  %325 = fcmp fast olt float %324, 0x3F50624DE0000000
  br i1 %325, label %326, label %329

; <label>:326                                     ; preds = %322
  %327 = fmul fast float %324, 5.000000e-01
  %328 = fsub fast float 1.000000e+00, %327
  br label %334

; <label>:329                                     ; preds = %322
  %330 = fmul fast float %324, 0xBFF7154760000000
  %331 = call float @dx.op.unary.f32(i32 21, float %330)  ; Exp(value)
  %332 = fsub fast float 1.000000e+00, %331
  %333 = fdiv fast float %332, %324
  br label %334

; <label>:334                                     ; preds = %329, %326
  %335 = phi float [ %328, %326 ], [ %333, %329 ]
  %336 = call float @dx.op.binary.f32(i32 36, float %308, float %16)  ; FMin(a,b)
  %337 = fsub fast float %336, %8
  %338 = fmul fast float %9, %337
  %339 = fsub fast float -0.000000e+00, %338
  %340 = call float @dx.op.binary.f32(i32 35, float %339, float -4.000000e+01)  ; FMax(a,b)
  %341 = call float @dx.op.binary.f32(i32 36, float %340, float 5.000000e+00)  ; FMin(a,b)
  %342 = fmul fast float %341, 0x3FF7154760000000
  %343 = call float @dx.op.unary.f32(i32 21, float %342)  ; Exp(value)
  %344 = fmul fast float %343, %335
  br label %345

; <label>:345                                     ; preds = %334, %294
  %346 = phi float [ %344, %334 ], [ 1.000000e+00, %294 ]
  %347 = fmul fast float %320, %14
  %348 = fmul fast float %347, %346
  %349 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %348)  ; FMin(a,b)
  %350 = fmul fast float %349, 0xBFF7154760000000
  %351 = call float @dx.op.unary.f32(i32 21, float %350)  ; Exp(value)
  %352 = fsub fast float 1.000000e+00, %351
  %353 = call float @dx.op.binary.f32(i32 36, float %10, float %352)  ; FMin(a,b)
  %354 = fsub fast float %11, %230
  %355 = fsub fast float %12, %231
  %356 = fsub fast float %13, %232
  %357 = fmul fast float %353, %354
  %358 = fmul fast float %353, %355
  %359 = fmul fast float %353, %356
  %360 = fadd fast float %357, %230
  %361 = fadd fast float %358, %231
  %362 = fadd fast float %359, %232
  br label %363

; <label>:363                                     ; preds = %345, %275, %269
  %364 = phi float [ %360, %345 ], [ %230, %275 ], [ %230, %269 ]
  %365 = phi float [ %361, %345 ], [ %231, %275 ], [ %231, %269 ]
  %366 = phi float [ %362, %345 ], [ %232, %275 ], [ %232, %269 ]
  %367 = fadd fast float %3, 1.000000e+00
  %368 = fadd fast float %4, 1.000000e+00
  %369 = fsub fast float 1.000000e+00, %3
  %370 = fmul fast float %34, %367
  %371 = fmul fast float %34, %368
  %372 = fmul fast float %34, %369
  %373 = fmul fast float %370, %364
  %374 = fmul fast float %371, %365
  %375 = fmul fast float %372, %366
  %376 = fcmp fast ult float %35, 5.000000e-01
  br i1 %376, label %402, label %377

; <label>:377                                     ; preds = %363
  %378 = fmul fast float %373, 0x4004147AE0000000
  %379 = fmul fast float %374, 0x4004147AE0000000
  %380 = fmul fast float %375, 0x4004147AE0000000
  %381 = fadd fast float %378, 0x3F9EB851E0000000
  %382 = fadd fast float %379, 0x3F9EB851E0000000
  %383 = fadd fast float %380, 0x3F9EB851E0000000
  %384 = fmul fast float %381, %373
  %385 = fmul fast float %382, %374
  %386 = fmul fast float %383, %375
  %387 = fmul fast float %373, 0x400370A3E0000000
  %388 = fmul fast float %374, 0x400370A3E0000000
  %389 = fmul fast float %375, 0x400370A3E0000000
  %390 = fadd fast float %387, 0x3FE2E147A0000000
  %391 = fadd fast float %388, 0x3FE2E147A0000000
  %392 = fadd fast float %389, 0x3FE2E147A0000000
  %393 = fmul fast float %390, %373
  %394 = fmul fast float %391, %374
  %395 = fmul fast float %392, %375
  %396 = fadd fast float %393, 0x3FC1EB8520000000
  %397 = fadd fast float %394, 0x3FC1EB8520000000
  %398 = fadd fast float %395, 0x3FC1EB8520000000
  %399 = fdiv fast float %384, %396
  %400 = fdiv fast float %385, %397
  %401 = fdiv fast float %386, %398
  br label %402

; <label>:402                                     ; preds = %377, %363
  %403 = phi float [ %399, %377 ], [ %373, %363 ]
  %404 = phi float [ %400, %377 ], [ %374, %363 ]
  %405 = phi float [ %401, %377 ], [ %375, %363 ]
  %406 = call float @dx.op.unary.f32(i32 7, float %403)  ; Saturate(value)
  %407 = call float @dx.op.unary.f32(i32 7, float %404)  ; Saturate(value)
  %408 = call float @dx.op.unary.f32(i32 7, float %405)  ; Saturate(value)
  %409 = call float @dx.op.dot3.f32(i32 55, float %406, float %407, float %408, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %410 = fsub fast float %406, %409
  %411 = fsub fast float %407, %409
  %412 = fsub fast float %408, %409
  %413 = fmul fast float %410, %6
  %414 = fmul fast float %411, %6
  %415 = fmul fast float %412, %6
  %416 = fadd fast float %413, %409
  %417 = fadd fast float %414, %409
  %418 = fadd fast float %415, %409
  %419 = call float @dx.op.unary.f32(i32 7, float %416)  ; Saturate(value)
  %420 = call float @dx.op.unary.f32(i32 7, float %417)  ; Saturate(value)
  %421 = call float @dx.op.unary.f32(i32 7, float %418)  ; Saturate(value)
  %422 = fadd fast float %419, 0xBFC70A3D80000000
  %423 = fadd fast float %420, 0xBFC70A3D80000000
  %424 = fadd fast float %421, 0xBFC70A3D80000000
  %425 = fmul fast float %422, %5
  %426 = fmul fast float %423, %5
  %427 = fmul fast float %424, %5
  %428 = fadd fast float %425, 0x3FC70A3D80000000
  %429 = fadd fast float %426, 0x3FC70A3D80000000
  %430 = fadd fast float %427, 0x3FC70A3D80000000
  %431 = call float @dx.op.unary.f32(i32 7, float %428)  ; Saturate(value)
  %432 = call float @dx.op.unary.f32(i32 7, float %429)  ; Saturate(value)
  %433 = call float @dx.op.unary.f32(i32 7, float %430)  ; Saturate(value)
  br label %434

; <label>:434                                     ; preds = %402, %235
  %435 = phi float [ %266, %235 ], [ %431, %402 ]
  %436 = phi float [ %267, %235 ], [ %432, %402 ]
  %437 = phi float [ %268, %235 ], [ %433, %402 ]
  %438 = add i32 %44, 1
  %439 = call i32 @dx.op.binary.i32(i32 37, i32 %438, i32 0)  ; IMax(a,b)
  %440 = call i32 @dx.op.binary.i32(i32 38, i32 %439, i32 %220)  ; IMin(a,b)
  %441 = call i32 @dx.op.binary.i32(i32 37, i32 %440, i32 0)  ; IMax(a,b)
  %442 = call i32 @dx.op.binary.i32(i32 38, i32 %441, i32 %220)  ; IMin(a,b)
  %443 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %227, i32 %442, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %444 = extractvalue %dx.types.ResRet.f32 %443, 0
  %445 = extractvalue %dx.types.ResRet.f32 %443, 1
  %446 = extractvalue %dx.types.ResRet.f32 %443, 2
  %447 = extractvalue %dx.types.ResRet.f32 %443, 3
  %448 = fcmp fast olt float %447, 0.000000e+00
  br i1 %448, label %449, label %483

; <label>:449                                     ; preds = %434
  %450 = fcmp fast ogt float %444, 0x3FA4B5DCC0000000
  %451 = fcmp fast ogt float %445, 0x3FA4B5DCC0000000
  %452 = fcmp fast ogt float %446, 0x3FA4B5DCC0000000
  %453 = select i1 %450, float 0.000000e+00, float 1.000000e+00
  %454 = select i1 %451, float 0.000000e+00, float 1.000000e+00
  %455 = select i1 %452, float 0.000000e+00, float 1.000000e+00
  %456 = fmul fast float %444, 0x3FB3D07220000000
  %457 = fmul fast float %445, 0x3FB3D07220000000
  %458 = fmul fast float %446, 0x3FB3D07220000000
  %459 = fadd fast float %444, 0x3FAC28F5C0000000
  %460 = fadd fast float %445, 0x3FAC28F5C0000000
  %461 = fadd fast float %446, 0x3FAC28F5C0000000
  %462 = fmul fast float %459, 0x3FEE54EDE0000000
  %463 = fmul fast float %460, 0x3FEE54EDE0000000
  %464 = fmul fast float %461, 0x3FEE54EDE0000000
  %465 = call float @dx.op.unary.f32(i32 23, float %462)  ; Log(value)
  %466 = call float @dx.op.unary.f32(i32 23, float %463)  ; Log(value)
  %467 = call float @dx.op.unary.f32(i32 23, float %464)  ; Log(value)
  %468 = fmul fast float %465, 0x4003333340000000
  %469 = fmul fast float %466, 0x4003333340000000
  %470 = fmul fast float %467, 0x4003333340000000
  %471 = call float @dx.op.unary.f32(i32 21, float %468)  ; Exp(value)
  %472 = call float @dx.op.unary.f32(i32 21, float %469)  ; Exp(value)
  %473 = call float @dx.op.unary.f32(i32 21, float %470)  ; Exp(value)
  %474 = fsub fast float %456, %471
  %475 = fsub fast float %457, %472
  %476 = fsub fast float %458, %473
  %477 = fmul fast float %474, %453
  %478 = fmul fast float %475, %454
  %479 = fmul fast float %476, %455
  %480 = fadd fast float %477, %471
  %481 = fadd fast float %478, %472
  %482 = fadd fast float %479, %473
  br label %648

; <label>:483                                     ; preds = %434
  %484 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %227, i32 %442, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %485 = extractvalue %dx.types.ResRet.f32 %484, 0
  %486 = fcmp fast ogt float %36, 5.000000e-01
  %487 = fcmp fast olt float %485, 1.000000e+00
  %488 = and i1 %486, %487
  br i1 %488, label %489, label %577

; <label>:489                                     ; preds = %483
  %490 = sitofp i32 %227 to float
  %491 = sitofp i32 %442 to float
  %492 = fadd fast float %490, 5.000000e-01
  %493 = fadd fast float %491, 5.000000e-01
  %494 = uitofp i32 %41 to float
  %495 = uitofp i32 %42 to float
  %496 = fdiv fast float %492, %494
  %497 = fdiv fast float %493, %495
  %498 = fmul fast float %496, 2.000000e+00
  %499 = fmul fast float %497, 2.000000e+00
  %500 = fadd fast float %498, -1.000000e+00
  %501 = fsub fast float 1.000000e+00, %499
  %502 = fmul fast float %500, %33
  %503 = call float @dx.op.tertiary.f32(i32 46, float %501, float %29, float %502)  ; FMad(a,b,c)
  %504 = call float @dx.op.tertiary.f32(i32 46, float %485, float %25, float %503)  ; FMad(a,b,c)
  %505 = fadd fast float %504, %21
  %506 = call float @dx.op.unary.f32(i32 6, float %505)  ; FAbs(value)
  %507 = fcmp fast ogt float %506, 0x3EB0C6F7A0000000
  br i1 %507, label %508, label %577

; <label>:508                                     ; preds = %489
  %509 = fmul fast float %500, %32
  %510 = call float @dx.op.tertiary.f32(i32 46, float %501, float %28, float %509)  ; FMad(a,b,c)
  %511 = call float @dx.op.tertiary.f32(i32 46, float %485, float %24, float %510)  ; FMad(a,b,c)
  %512 = fadd fast float %511, %20
  %513 = fmul fast float %500, %31
  %514 = call float @dx.op.tertiary.f32(i32 46, float %501, float %27, float %513)  ; FMad(a,b,c)
  %515 = call float @dx.op.tertiary.f32(i32 46, float %485, float %23, float %514)  ; FMad(a,b,c)
  %516 = fadd fast float %515, %19
  %517 = fmul fast float %500, %30
  %518 = call float @dx.op.tertiary.f32(i32 46, float %501, float %26, float %517)  ; FMad(a,b,c)
  %519 = call float @dx.op.tertiary.f32(i32 46, float %485, float %22, float %518)  ; FMad(a,b,c)
  %520 = fadd fast float %519, %18
  %521 = fdiv fast float %520, %505
  %522 = fdiv fast float %516, %505
  %523 = fdiv fast float %512, %505
  %524 = fsub fast float %521, %15
  %525 = fsub fast float %522, %16
  %526 = fsub fast float %523, %17
  %527 = fmul fast float %524, %524
  %528 = fmul fast float %525, %525
  %529 = fadd fast float %528, %527
  %530 = fmul fast float %526, %526
  %531 = fadd fast float %529, %530
  %532 = call float @dx.op.unary.f32(i32 24, float %531)  ; Sqrt(value)
  %533 = fsub fast float %532, %7
  %534 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %533)  ; FMax(a,b)
  %535 = fcmp fast ogt float %37, 1.500000e+00
  br i1 %535, label %536, label %559

; <label>:536                                     ; preds = %508
  %537 = call float @dx.op.unary.f32(i32 6, float %525)  ; FAbs(value)
  %538 = fmul fast float %537, %9
  %539 = fcmp fast olt float %538, 0x3F50624DE0000000
  br i1 %539, label %540, label %543

; <label>:540                                     ; preds = %536
  %541 = fmul fast float %538, 5.000000e-01
  %542 = fsub fast float 1.000000e+00, %541
  br label %548

; <label>:543                                     ; preds = %536
  %544 = fmul fast float %538, 0xBFF7154760000000
  %545 = call float @dx.op.unary.f32(i32 21, float %544)  ; Exp(value)
  %546 = fsub fast float 1.000000e+00, %545
  %547 = fdiv fast float %546, %538
  br label %548

; <label>:548                                     ; preds = %543, %540
  %549 = phi float [ %542, %540 ], [ %547, %543 ]
  %550 = call float @dx.op.binary.f32(i32 36, float %522, float %16)  ; FMin(a,b)
  %551 = fsub fast float %550, %8
  %552 = fmul fast float %9, %551
  %553 = fsub fast float -0.000000e+00, %552
  %554 = call float @dx.op.binary.f32(i32 35, float %553, float -4.000000e+01)  ; FMax(a,b)
  %555 = call float @dx.op.binary.f32(i32 36, float %554, float 5.000000e+00)  ; FMin(a,b)
  %556 = fmul fast float %555, 0x3FF7154760000000
  %557 = call float @dx.op.unary.f32(i32 21, float %556)  ; Exp(value)
  %558 = fmul fast float %557, %549
  br label %559

; <label>:559                                     ; preds = %548, %508
  %560 = phi float [ %558, %548 ], [ 1.000000e+00, %508 ]
  %561 = fmul fast float %534, %14
  %562 = fmul fast float %561, %560
  %563 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %562)  ; FMin(a,b)
  %564 = fmul fast float %563, 0xBFF7154760000000
  %565 = call float @dx.op.unary.f32(i32 21, float %564)  ; Exp(value)
  %566 = fsub fast float 1.000000e+00, %565
  %567 = call float @dx.op.binary.f32(i32 36, float %10, float %566)  ; FMin(a,b)
  %568 = fsub fast float %11, %444
  %569 = fsub fast float %12, %445
  %570 = fsub fast float %13, %446
  %571 = fmul fast float %567, %568
  %572 = fmul fast float %567, %569
  %573 = fmul fast float %567, %570
  %574 = fadd fast float %571, %444
  %575 = fadd fast float %572, %445
  %576 = fadd fast float %573, %446
  br label %577

; <label>:577                                     ; preds = %559, %489, %483
  %578 = phi float [ %574, %559 ], [ %444, %489 ], [ %444, %483 ]
  %579 = phi float [ %575, %559 ], [ %445, %489 ], [ %445, %483 ]
  %580 = phi float [ %576, %559 ], [ %446, %489 ], [ %446, %483 ]
  %581 = fadd fast float %3, 1.000000e+00
  %582 = fadd fast float %4, 1.000000e+00
  %583 = fsub fast float 1.000000e+00, %3
  %584 = fmul fast float %34, %581
  %585 = fmul fast float %34, %582
  %586 = fmul fast float %34, %583
  %587 = fmul fast float %584, %578
  %588 = fmul fast float %585, %579
  %589 = fmul fast float %586, %580
  %590 = fcmp fast ult float %35, 5.000000e-01
  br i1 %590, label %616, label %591

; <label>:591                                     ; preds = %577
  %592 = fmul fast float %587, 0x4004147AE0000000
  %593 = fmul fast float %588, 0x4004147AE0000000
  %594 = fmul fast float %589, 0x4004147AE0000000
  %595 = fadd fast float %592, 0x3F9EB851E0000000
  %596 = fadd fast float %593, 0x3F9EB851E0000000
  %597 = fadd fast float %594, 0x3F9EB851E0000000
  %598 = fmul fast float %595, %587
  %599 = fmul fast float %596, %588
  %600 = fmul fast float %597, %589
  %601 = fmul fast float %587, 0x400370A3E0000000
  %602 = fmul fast float %588, 0x400370A3E0000000
  %603 = fmul fast float %589, 0x400370A3E0000000
  %604 = fadd fast float %601, 0x3FE2E147A0000000
  %605 = fadd fast float %602, 0x3FE2E147A0000000
  %606 = fadd fast float %603, 0x3FE2E147A0000000
  %607 = fmul fast float %604, %587
  %608 = fmul fast float %605, %588
  %609 = fmul fast float %606, %589
  %610 = fadd fast float %607, 0x3FC1EB8520000000
  %611 = fadd fast float %608, 0x3FC1EB8520000000
  %612 = fadd fast float %609, 0x3FC1EB8520000000
  %613 = fdiv fast float %598, %610
  %614 = fdiv fast float %599, %611
  %615 = fdiv fast float %600, %612
  br label %616

; <label>:616                                     ; preds = %591, %577
  %617 = phi float [ %613, %591 ], [ %587, %577 ]
  %618 = phi float [ %614, %591 ], [ %588, %577 ]
  %619 = phi float [ %615, %591 ], [ %589, %577 ]
  %620 = call float @dx.op.unary.f32(i32 7, float %617)  ; Saturate(value)
  %621 = call float @dx.op.unary.f32(i32 7, float %618)  ; Saturate(value)
  %622 = call float @dx.op.unary.f32(i32 7, float %619)  ; Saturate(value)
  %623 = call float @dx.op.dot3.f32(i32 55, float %620, float %621, float %622, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %624 = fsub fast float %620, %623
  %625 = fsub fast float %621, %623
  %626 = fsub fast float %622, %623
  %627 = fmul fast float %624, %6
  %628 = fmul fast float %625, %6
  %629 = fmul fast float %626, %6
  %630 = fadd fast float %627, %623
  %631 = fadd fast float %628, %623
  %632 = fadd fast float %629, %623
  %633 = call float @dx.op.unary.f32(i32 7, float %630)  ; Saturate(value)
  %634 = call float @dx.op.unary.f32(i32 7, float %631)  ; Saturate(value)
  %635 = call float @dx.op.unary.f32(i32 7, float %632)  ; Saturate(value)
  %636 = fadd fast float %633, 0xBFC70A3D80000000
  %637 = fadd fast float %634, 0xBFC70A3D80000000
  %638 = fadd fast float %635, 0xBFC70A3D80000000
  %639 = fmul fast float %636, %5
  %640 = fmul fast float %637, %5
  %641 = fmul fast float %638, %5
  %642 = fadd fast float %639, 0x3FC70A3D80000000
  %643 = fadd fast float %640, 0x3FC70A3D80000000
  %644 = fadd fast float %641, 0x3FC70A3D80000000
  %645 = call float @dx.op.unary.f32(i32 7, float %642)  ; Saturate(value)
  %646 = call float @dx.op.unary.f32(i32 7, float %643)  ; Saturate(value)
  %647 = call float @dx.op.unary.f32(i32 7, float %644)  ; Saturate(value)
  br label %648

; <label>:648                                     ; preds = %616, %449
  %649 = phi float [ %480, %449 ], [ %645, %616 ]
  %650 = phi float [ %481, %449 ], [ %646, %616 ]
  %651 = phi float [ %482, %449 ], [ %647, %616 ]
  %652 = add i32 %43, -1
  %653 = call i32 @dx.op.binary.i32(i32 37, i32 %652, i32 0)  ; IMax(a,b)
  %654 = call i32 @dx.op.binary.i32(i32 37, i32 %44, i32 0)  ; IMax(a,b)
  %655 = call i32 @dx.op.binary.i32(i32 38, i32 %653, i32 %219)  ; IMin(a,b)
  %656 = call i32 @dx.op.binary.i32(i32 38, i32 %654, i32 %220)  ; IMin(a,b)
  %657 = call i32 @dx.op.binary.i32(i32 37, i32 %655, i32 0)  ; IMax(a,b)
  %658 = call i32 @dx.op.binary.i32(i32 37, i32 %656, i32 0)  ; IMax(a,b)
  %659 = call i32 @dx.op.binary.i32(i32 38, i32 %657, i32 %219)  ; IMin(a,b)
  %660 = call i32 @dx.op.binary.i32(i32 38, i32 %658, i32 %220)  ; IMin(a,b)
  %661 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %659, i32 %660, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %662 = extractvalue %dx.types.ResRet.f32 %661, 0
  %663 = extractvalue %dx.types.ResRet.f32 %661, 1
  %664 = extractvalue %dx.types.ResRet.f32 %661, 2
  %665 = extractvalue %dx.types.ResRet.f32 %661, 3
  %666 = fcmp fast olt float %665, 0.000000e+00
  br i1 %666, label %667, label %701

; <label>:667                                     ; preds = %648
  %668 = fcmp fast ogt float %662, 0x3FA4B5DCC0000000
  %669 = fcmp fast ogt float %663, 0x3FA4B5DCC0000000
  %670 = fcmp fast ogt float %664, 0x3FA4B5DCC0000000
  %671 = select i1 %668, float 0.000000e+00, float 1.000000e+00
  %672 = select i1 %669, float 0.000000e+00, float 1.000000e+00
  %673 = select i1 %670, float 0.000000e+00, float 1.000000e+00
  %674 = fmul fast float %662, 0x3FB3D07220000000
  %675 = fmul fast float %663, 0x3FB3D07220000000
  %676 = fmul fast float %664, 0x3FB3D07220000000
  %677 = fadd fast float %662, 0x3FAC28F5C0000000
  %678 = fadd fast float %663, 0x3FAC28F5C0000000
  %679 = fadd fast float %664, 0x3FAC28F5C0000000
  %680 = fmul fast float %677, 0x3FEE54EDE0000000
  %681 = fmul fast float %678, 0x3FEE54EDE0000000
  %682 = fmul fast float %679, 0x3FEE54EDE0000000
  %683 = call float @dx.op.unary.f32(i32 23, float %680)  ; Log(value)
  %684 = call float @dx.op.unary.f32(i32 23, float %681)  ; Log(value)
  %685 = call float @dx.op.unary.f32(i32 23, float %682)  ; Log(value)
  %686 = fmul fast float %683, 0x4003333340000000
  %687 = fmul fast float %684, 0x4003333340000000
  %688 = fmul fast float %685, 0x4003333340000000
  %689 = call float @dx.op.unary.f32(i32 21, float %686)  ; Exp(value)
  %690 = call float @dx.op.unary.f32(i32 21, float %687)  ; Exp(value)
  %691 = call float @dx.op.unary.f32(i32 21, float %688)  ; Exp(value)
  %692 = fsub fast float %674, %689
  %693 = fsub fast float %675, %690
  %694 = fsub fast float %676, %691
  %695 = fmul fast float %692, %671
  %696 = fmul fast float %693, %672
  %697 = fmul fast float %694, %673
  %698 = fadd fast float %695, %689
  %699 = fadd fast float %696, %690
  %700 = fadd fast float %697, %691
  br label %866

; <label>:701                                     ; preds = %648
  %702 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %659, i32 %660, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %703 = extractvalue %dx.types.ResRet.f32 %702, 0
  %704 = fcmp fast ogt float %36, 5.000000e-01
  %705 = fcmp fast olt float %703, 1.000000e+00
  %706 = and i1 %704, %705
  br i1 %706, label %707, label %795

; <label>:707                                     ; preds = %701
  %708 = sitofp i32 %659 to float
  %709 = sitofp i32 %660 to float
  %710 = fadd fast float %708, 5.000000e-01
  %711 = fadd fast float %709, 5.000000e-01
  %712 = uitofp i32 %41 to float
  %713 = uitofp i32 %42 to float
  %714 = fdiv fast float %710, %712
  %715 = fdiv fast float %711, %713
  %716 = fmul fast float %714, 2.000000e+00
  %717 = fmul fast float %715, 2.000000e+00
  %718 = fadd fast float %716, -1.000000e+00
  %719 = fsub fast float 1.000000e+00, %717
  %720 = fmul fast float %718, %33
  %721 = call float @dx.op.tertiary.f32(i32 46, float %719, float %29, float %720)  ; FMad(a,b,c)
  %722 = call float @dx.op.tertiary.f32(i32 46, float %703, float %25, float %721)  ; FMad(a,b,c)
  %723 = fadd fast float %722, %21
  %724 = call float @dx.op.unary.f32(i32 6, float %723)  ; FAbs(value)
  %725 = fcmp fast ogt float %724, 0x3EB0C6F7A0000000
  br i1 %725, label %726, label %795

; <label>:726                                     ; preds = %707
  %727 = fmul fast float %718, %32
  %728 = call float @dx.op.tertiary.f32(i32 46, float %719, float %28, float %727)  ; FMad(a,b,c)
  %729 = call float @dx.op.tertiary.f32(i32 46, float %703, float %24, float %728)  ; FMad(a,b,c)
  %730 = fadd fast float %729, %20
  %731 = fmul fast float %718, %31
  %732 = call float @dx.op.tertiary.f32(i32 46, float %719, float %27, float %731)  ; FMad(a,b,c)
  %733 = call float @dx.op.tertiary.f32(i32 46, float %703, float %23, float %732)  ; FMad(a,b,c)
  %734 = fadd fast float %733, %19
  %735 = fmul fast float %718, %30
  %736 = call float @dx.op.tertiary.f32(i32 46, float %719, float %26, float %735)  ; FMad(a,b,c)
  %737 = call float @dx.op.tertiary.f32(i32 46, float %703, float %22, float %736)  ; FMad(a,b,c)
  %738 = fadd fast float %737, %18
  %739 = fdiv fast float %738, %723
  %740 = fdiv fast float %734, %723
  %741 = fdiv fast float %730, %723
  %742 = fsub fast float %739, %15
  %743 = fsub fast float %740, %16
  %744 = fsub fast float %741, %17
  %745 = fmul fast float %742, %742
  %746 = fmul fast float %743, %743
  %747 = fadd fast float %746, %745
  %748 = fmul fast float %744, %744
  %749 = fadd fast float %747, %748
  %750 = call float @dx.op.unary.f32(i32 24, float %749)  ; Sqrt(value)
  %751 = fsub fast float %750, %7
  %752 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %751)  ; FMax(a,b)
  %753 = fcmp fast ogt float %37, 1.500000e+00
  br i1 %753, label %754, label %777

; <label>:754                                     ; preds = %726
  %755 = call float @dx.op.unary.f32(i32 6, float %743)  ; FAbs(value)
  %756 = fmul fast float %755, %9
  %757 = fcmp fast olt float %756, 0x3F50624DE0000000
  br i1 %757, label %758, label %761

; <label>:758                                     ; preds = %754
  %759 = fmul fast float %756, 5.000000e-01
  %760 = fsub fast float 1.000000e+00, %759
  br label %766

; <label>:761                                     ; preds = %754
  %762 = fmul fast float %756, 0xBFF7154760000000
  %763 = call float @dx.op.unary.f32(i32 21, float %762)  ; Exp(value)
  %764 = fsub fast float 1.000000e+00, %763
  %765 = fdiv fast float %764, %756
  br label %766

; <label>:766                                     ; preds = %761, %758
  %767 = phi float [ %760, %758 ], [ %765, %761 ]
  %768 = call float @dx.op.binary.f32(i32 36, float %740, float %16)  ; FMin(a,b)
  %769 = fsub fast float %768, %8
  %770 = fmul fast float %9, %769
  %771 = fsub fast float -0.000000e+00, %770
  %772 = call float @dx.op.binary.f32(i32 35, float %771, float -4.000000e+01)  ; FMax(a,b)
  %773 = call float @dx.op.binary.f32(i32 36, float %772, float 5.000000e+00)  ; FMin(a,b)
  %774 = fmul fast float %773, 0x3FF7154760000000
  %775 = call float @dx.op.unary.f32(i32 21, float %774)  ; Exp(value)
  %776 = fmul fast float %775, %767
  br label %777

; <label>:777                                     ; preds = %766, %726
  %778 = phi float [ %776, %766 ], [ 1.000000e+00, %726 ]
  %779 = fmul fast float %752, %14
  %780 = fmul fast float %779, %778
  %781 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %780)  ; FMin(a,b)
  %782 = fmul fast float %781, 0xBFF7154760000000
  %783 = call float @dx.op.unary.f32(i32 21, float %782)  ; Exp(value)
  %784 = fsub fast float 1.000000e+00, %783
  %785 = call float @dx.op.binary.f32(i32 36, float %10, float %784)  ; FMin(a,b)
  %786 = fsub fast float %11, %662
  %787 = fsub fast float %12, %663
  %788 = fsub fast float %13, %664
  %789 = fmul fast float %785, %786
  %790 = fmul fast float %785, %787
  %791 = fmul fast float %785, %788
  %792 = fadd fast float %789, %662
  %793 = fadd fast float %790, %663
  %794 = fadd fast float %791, %664
  br label %795

; <label>:795                                     ; preds = %777, %707, %701
  %796 = phi float [ %792, %777 ], [ %662, %707 ], [ %662, %701 ]
  %797 = phi float [ %793, %777 ], [ %663, %707 ], [ %663, %701 ]
  %798 = phi float [ %794, %777 ], [ %664, %707 ], [ %664, %701 ]
  %799 = fadd fast float %3, 1.000000e+00
  %800 = fadd fast float %4, 1.000000e+00
  %801 = fsub fast float 1.000000e+00, %3
  %802 = fmul fast float %34, %799
  %803 = fmul fast float %34, %800
  %804 = fmul fast float %34, %801
  %805 = fmul fast float %802, %796
  %806 = fmul fast float %803, %797
  %807 = fmul fast float %804, %798
  %808 = fcmp fast ult float %35, 5.000000e-01
  br i1 %808, label %834, label %809

; <label>:809                                     ; preds = %795
  %810 = fmul fast float %805, 0x4004147AE0000000
  %811 = fmul fast float %806, 0x4004147AE0000000
  %812 = fmul fast float %807, 0x4004147AE0000000
  %813 = fadd fast float %810, 0x3F9EB851E0000000
  %814 = fadd fast float %811, 0x3F9EB851E0000000
  %815 = fadd fast float %812, 0x3F9EB851E0000000
  %816 = fmul fast float %813, %805
  %817 = fmul fast float %814, %806
  %818 = fmul fast float %815, %807
  %819 = fmul fast float %805, 0x400370A3E0000000
  %820 = fmul fast float %806, 0x400370A3E0000000
  %821 = fmul fast float %807, 0x400370A3E0000000
  %822 = fadd fast float %819, 0x3FE2E147A0000000
  %823 = fadd fast float %820, 0x3FE2E147A0000000
  %824 = fadd fast float %821, 0x3FE2E147A0000000
  %825 = fmul fast float %822, %805
  %826 = fmul fast float %823, %806
  %827 = fmul fast float %824, %807
  %828 = fadd fast float %825, 0x3FC1EB8520000000
  %829 = fadd fast float %826, 0x3FC1EB8520000000
  %830 = fadd fast float %827, 0x3FC1EB8520000000
  %831 = fdiv fast float %816, %828
  %832 = fdiv fast float %817, %829
  %833 = fdiv fast float %818, %830
  br label %834

; <label>:834                                     ; preds = %809, %795
  %835 = phi float [ %831, %809 ], [ %805, %795 ]
  %836 = phi float [ %832, %809 ], [ %806, %795 ]
  %837 = phi float [ %833, %809 ], [ %807, %795 ]
  %838 = call float @dx.op.unary.f32(i32 7, float %835)  ; Saturate(value)
  %839 = call float @dx.op.unary.f32(i32 7, float %836)  ; Saturate(value)
  %840 = call float @dx.op.unary.f32(i32 7, float %837)  ; Saturate(value)
  %841 = call float @dx.op.dot3.f32(i32 55, float %838, float %839, float %840, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %842 = fsub fast float %838, %841
  %843 = fsub fast float %839, %841
  %844 = fsub fast float %840, %841
  %845 = fmul fast float %842, %6
  %846 = fmul fast float %843, %6
  %847 = fmul fast float %844, %6
  %848 = fadd fast float %845, %841
  %849 = fadd fast float %846, %841
  %850 = fadd fast float %847, %841
  %851 = call float @dx.op.unary.f32(i32 7, float %848)  ; Saturate(value)
  %852 = call float @dx.op.unary.f32(i32 7, float %849)  ; Saturate(value)
  %853 = call float @dx.op.unary.f32(i32 7, float %850)  ; Saturate(value)
  %854 = fadd fast float %851, 0xBFC70A3D80000000
  %855 = fadd fast float %852, 0xBFC70A3D80000000
  %856 = fadd fast float %853, 0xBFC70A3D80000000
  %857 = fmul fast float %854, %5
  %858 = fmul fast float %855, %5
  %859 = fmul fast float %856, %5
  %860 = fadd fast float %857, 0x3FC70A3D80000000
  %861 = fadd fast float %858, 0x3FC70A3D80000000
  %862 = fadd fast float %859, 0x3FC70A3D80000000
  %863 = call float @dx.op.unary.f32(i32 7, float %860)  ; Saturate(value)
  %864 = call float @dx.op.unary.f32(i32 7, float %861)  ; Saturate(value)
  %865 = call float @dx.op.unary.f32(i32 7, float %862)  ; Saturate(value)
  br label %866

; <label>:866                                     ; preds = %834, %667
  %867 = phi float [ %698, %667 ], [ %863, %834 ]
  %868 = phi float [ %699, %667 ], [ %864, %834 ]
  %869 = phi float [ %700, %667 ], [ %865, %834 ]
  %870 = add i32 %43, 1
  %871 = call i32 @dx.op.binary.i32(i32 37, i32 %870, i32 0)  ; IMax(a,b)
  %872 = call i32 @dx.op.binary.i32(i32 38, i32 %871, i32 %219)  ; IMin(a,b)
  %873 = call i32 @dx.op.binary.i32(i32 37, i32 %872, i32 0)  ; IMax(a,b)
  %874 = call i32 @dx.op.binary.i32(i32 38, i32 %873, i32 %219)  ; IMin(a,b)
  %875 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %874, i32 %660, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %876 = extractvalue %dx.types.ResRet.f32 %875, 0
  %877 = extractvalue %dx.types.ResRet.f32 %875, 1
  %878 = extractvalue %dx.types.ResRet.f32 %875, 2
  %879 = extractvalue %dx.types.ResRet.f32 %875, 3
  %880 = fcmp fast olt float %879, 0.000000e+00
  br i1 %880, label %881, label %915

; <label>:881                                     ; preds = %866
  %882 = fcmp fast ogt float %876, 0x3FA4B5DCC0000000
  %883 = fcmp fast ogt float %877, 0x3FA4B5DCC0000000
  %884 = fcmp fast ogt float %878, 0x3FA4B5DCC0000000
  %885 = select i1 %882, float 0.000000e+00, float 1.000000e+00
  %886 = select i1 %883, float 0.000000e+00, float 1.000000e+00
  %887 = select i1 %884, float 0.000000e+00, float 1.000000e+00
  %888 = fmul fast float %876, 0x3FB3D07220000000
  %889 = fmul fast float %877, 0x3FB3D07220000000
  %890 = fmul fast float %878, 0x3FB3D07220000000
  %891 = fadd fast float %876, 0x3FAC28F5C0000000
  %892 = fadd fast float %877, 0x3FAC28F5C0000000
  %893 = fadd fast float %878, 0x3FAC28F5C0000000
  %894 = fmul fast float %891, 0x3FEE54EDE0000000
  %895 = fmul fast float %892, 0x3FEE54EDE0000000
  %896 = fmul fast float %893, 0x3FEE54EDE0000000
  %897 = call float @dx.op.unary.f32(i32 23, float %894)  ; Log(value)
  %898 = call float @dx.op.unary.f32(i32 23, float %895)  ; Log(value)
  %899 = call float @dx.op.unary.f32(i32 23, float %896)  ; Log(value)
  %900 = fmul fast float %897, 0x4003333340000000
  %901 = fmul fast float %898, 0x4003333340000000
  %902 = fmul fast float %899, 0x4003333340000000
  %903 = call float @dx.op.unary.f32(i32 21, float %900)  ; Exp(value)
  %904 = call float @dx.op.unary.f32(i32 21, float %901)  ; Exp(value)
  %905 = call float @dx.op.unary.f32(i32 21, float %902)  ; Exp(value)
  %906 = fsub fast float %888, %903
  %907 = fsub fast float %889, %904
  %908 = fsub fast float %890, %905
  %909 = fmul fast float %906, %885
  %910 = fmul fast float %907, %886
  %911 = fmul fast float %908, %887
  %912 = fadd fast float %909, %903
  %913 = fadd fast float %910, %904
  %914 = fadd fast float %911, %905
  br label %1080

; <label>:915                                     ; preds = %866
  %916 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %874, i32 %660, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %917 = extractvalue %dx.types.ResRet.f32 %916, 0
  %918 = fcmp fast ogt float %36, 5.000000e-01
  %919 = fcmp fast olt float %917, 1.000000e+00
  %920 = and i1 %918, %919
  br i1 %920, label %921, label %1009

; <label>:921                                     ; preds = %915
  %922 = sitofp i32 %874 to float
  %923 = sitofp i32 %660 to float
  %924 = fadd fast float %922, 5.000000e-01
  %925 = fadd fast float %923, 5.000000e-01
  %926 = uitofp i32 %41 to float
  %927 = uitofp i32 %42 to float
  %928 = fdiv fast float %924, %926
  %929 = fdiv fast float %925, %927
  %930 = fmul fast float %928, 2.000000e+00
  %931 = fmul fast float %929, 2.000000e+00
  %932 = fadd fast float %930, -1.000000e+00
  %933 = fsub fast float 1.000000e+00, %931
  %934 = fmul fast float %932, %33
  %935 = call float @dx.op.tertiary.f32(i32 46, float %933, float %29, float %934)  ; FMad(a,b,c)
  %936 = call float @dx.op.tertiary.f32(i32 46, float %917, float %25, float %935)  ; FMad(a,b,c)
  %937 = fadd fast float %936, %21
  %938 = call float @dx.op.unary.f32(i32 6, float %937)  ; FAbs(value)
  %939 = fcmp fast ogt float %938, 0x3EB0C6F7A0000000
  br i1 %939, label %940, label %1009

; <label>:940                                     ; preds = %921
  %941 = fmul fast float %932, %32
  %942 = call float @dx.op.tertiary.f32(i32 46, float %933, float %28, float %941)  ; FMad(a,b,c)
  %943 = call float @dx.op.tertiary.f32(i32 46, float %917, float %24, float %942)  ; FMad(a,b,c)
  %944 = fadd fast float %943, %20
  %945 = fmul fast float %932, %31
  %946 = call float @dx.op.tertiary.f32(i32 46, float %933, float %27, float %945)  ; FMad(a,b,c)
  %947 = call float @dx.op.tertiary.f32(i32 46, float %917, float %23, float %946)  ; FMad(a,b,c)
  %948 = fadd fast float %947, %19
  %949 = fmul fast float %932, %30
  %950 = call float @dx.op.tertiary.f32(i32 46, float %933, float %26, float %949)  ; FMad(a,b,c)
  %951 = call float @dx.op.tertiary.f32(i32 46, float %917, float %22, float %950)  ; FMad(a,b,c)
  %952 = fadd fast float %951, %18
  %953 = fdiv fast float %952, %937
  %954 = fdiv fast float %948, %937
  %955 = fdiv fast float %944, %937
  %956 = fsub fast float %953, %15
  %957 = fsub fast float %954, %16
  %958 = fsub fast float %955, %17
  %959 = fmul fast float %956, %956
  %960 = fmul fast float %957, %957
  %961 = fadd fast float %960, %959
  %962 = fmul fast float %958, %958
  %963 = fadd fast float %961, %962
  %964 = call float @dx.op.unary.f32(i32 24, float %963)  ; Sqrt(value)
  %965 = fsub fast float %964, %7
  %966 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %965)  ; FMax(a,b)
  %967 = fcmp fast ogt float %37, 1.500000e+00
  br i1 %967, label %968, label %991

; <label>:968                                     ; preds = %940
  %969 = call float @dx.op.unary.f32(i32 6, float %957)  ; FAbs(value)
  %970 = fmul fast float %969, %9
  %971 = fcmp fast olt float %970, 0x3F50624DE0000000
  br i1 %971, label %972, label %975

; <label>:972                                     ; preds = %968
  %973 = fmul fast float %970, 5.000000e-01
  %974 = fsub fast float 1.000000e+00, %973
  br label %980

; <label>:975                                     ; preds = %968
  %976 = fmul fast float %970, 0xBFF7154760000000
  %977 = call float @dx.op.unary.f32(i32 21, float %976)  ; Exp(value)
  %978 = fsub fast float 1.000000e+00, %977
  %979 = fdiv fast float %978, %970
  br label %980

; <label>:980                                     ; preds = %975, %972
  %981 = phi float [ %974, %972 ], [ %979, %975 ]
  %982 = call float @dx.op.binary.f32(i32 36, float %954, float %16)  ; FMin(a,b)
  %983 = fsub fast float %982, %8
  %984 = fmul fast float %9, %983
  %985 = fsub fast float -0.000000e+00, %984
  %986 = call float @dx.op.binary.f32(i32 35, float %985, float -4.000000e+01)  ; FMax(a,b)
  %987 = call float @dx.op.binary.f32(i32 36, float %986, float 5.000000e+00)  ; FMin(a,b)
  %988 = fmul fast float %987, 0x3FF7154760000000
  %989 = call float @dx.op.unary.f32(i32 21, float %988)  ; Exp(value)
  %990 = fmul fast float %989, %981
  br label %991

; <label>:991                                     ; preds = %980, %940
  %992 = phi float [ %990, %980 ], [ 1.000000e+00, %940 ]
  %993 = fmul fast float %966, %14
  %994 = fmul fast float %993, %992
  %995 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %994)  ; FMin(a,b)
  %996 = fmul fast float %995, 0xBFF7154760000000
  %997 = call float @dx.op.unary.f32(i32 21, float %996)  ; Exp(value)
  %998 = fsub fast float 1.000000e+00, %997
  %999 = call float @dx.op.binary.f32(i32 36, float %10, float %998)  ; FMin(a,b)
  %1000 = fsub fast float %11, %876
  %1001 = fsub fast float %12, %877
  %1002 = fsub fast float %13, %878
  %1003 = fmul fast float %999, %1000
  %1004 = fmul fast float %999, %1001
  %1005 = fmul fast float %999, %1002
  %1006 = fadd fast float %1003, %876
  %1007 = fadd fast float %1004, %877
  %1008 = fadd fast float %1005, %878
  br label %1009

; <label>:1009                                    ; preds = %991, %921, %915
  %1010 = phi float [ %1006, %991 ], [ %876, %921 ], [ %876, %915 ]
  %1011 = phi float [ %1007, %991 ], [ %877, %921 ], [ %877, %915 ]
  %1012 = phi float [ %1008, %991 ], [ %878, %921 ], [ %878, %915 ]
  %1013 = fadd fast float %3, 1.000000e+00
  %1014 = fadd fast float %4, 1.000000e+00
  %1015 = fsub fast float 1.000000e+00, %3
  %1016 = fmul fast float %34, %1013
  %1017 = fmul fast float %34, %1014
  %1018 = fmul fast float %34, %1015
  %1019 = fmul fast float %1016, %1010
  %1020 = fmul fast float %1017, %1011
  %1021 = fmul fast float %1018, %1012
  %1022 = fcmp fast ult float %35, 5.000000e-01
  br i1 %1022, label %1048, label %1023

; <label>:1023                                    ; preds = %1009
  %1024 = fmul fast float %1019, 0x4004147AE0000000
  %1025 = fmul fast float %1020, 0x4004147AE0000000
  %1026 = fmul fast float %1021, 0x4004147AE0000000
  %1027 = fadd fast float %1024, 0x3F9EB851E0000000
  %1028 = fadd fast float %1025, 0x3F9EB851E0000000
  %1029 = fadd fast float %1026, 0x3F9EB851E0000000
  %1030 = fmul fast float %1027, %1019
  %1031 = fmul fast float %1028, %1020
  %1032 = fmul fast float %1029, %1021
  %1033 = fmul fast float %1019, 0x400370A3E0000000
  %1034 = fmul fast float %1020, 0x400370A3E0000000
  %1035 = fmul fast float %1021, 0x400370A3E0000000
  %1036 = fadd fast float %1033, 0x3FE2E147A0000000
  %1037 = fadd fast float %1034, 0x3FE2E147A0000000
  %1038 = fadd fast float %1035, 0x3FE2E147A0000000
  %1039 = fmul fast float %1036, %1019
  %1040 = fmul fast float %1037, %1020
  %1041 = fmul fast float %1038, %1021
  %1042 = fadd fast float %1039, 0x3FC1EB8520000000
  %1043 = fadd fast float %1040, 0x3FC1EB8520000000
  %1044 = fadd fast float %1041, 0x3FC1EB8520000000
  %1045 = fdiv fast float %1030, %1042
  %1046 = fdiv fast float %1031, %1043
  %1047 = fdiv fast float %1032, %1044
  br label %1048

; <label>:1048                                    ; preds = %1023, %1009
  %1049 = phi float [ %1045, %1023 ], [ %1019, %1009 ]
  %1050 = phi float [ %1046, %1023 ], [ %1020, %1009 ]
  %1051 = phi float [ %1047, %1023 ], [ %1021, %1009 ]
  %1052 = call float @dx.op.unary.f32(i32 7, float %1049)  ; Saturate(value)
  %1053 = call float @dx.op.unary.f32(i32 7, float %1050)  ; Saturate(value)
  %1054 = call float @dx.op.unary.f32(i32 7, float %1051)  ; Saturate(value)
  %1055 = call float @dx.op.dot3.f32(i32 55, float %1052, float %1053, float %1054, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1056 = fsub fast float %1052, %1055
  %1057 = fsub fast float %1053, %1055
  %1058 = fsub fast float %1054, %1055
  %1059 = fmul fast float %1056, %6
  %1060 = fmul fast float %1057, %6
  %1061 = fmul fast float %1058, %6
  %1062 = fadd fast float %1059, %1055
  %1063 = fadd fast float %1060, %1055
  %1064 = fadd fast float %1061, %1055
  %1065 = call float @dx.op.unary.f32(i32 7, float %1062)  ; Saturate(value)
  %1066 = call float @dx.op.unary.f32(i32 7, float %1063)  ; Saturate(value)
  %1067 = call float @dx.op.unary.f32(i32 7, float %1064)  ; Saturate(value)
  %1068 = fadd fast float %1065, 0xBFC70A3D80000000
  %1069 = fadd fast float %1066, 0xBFC70A3D80000000
  %1070 = fadd fast float %1067, 0xBFC70A3D80000000
  %1071 = fmul fast float %1068, %5
  %1072 = fmul fast float %1069, %5
  %1073 = fmul fast float %1070, %5
  %1074 = fadd fast float %1071, 0x3FC70A3D80000000
  %1075 = fadd fast float %1072, 0x3FC70A3D80000000
  %1076 = fadd fast float %1073, 0x3FC70A3D80000000
  %1077 = call float @dx.op.unary.f32(i32 7, float %1074)  ; Saturate(value)
  %1078 = call float @dx.op.unary.f32(i32 7, float %1075)  ; Saturate(value)
  %1079 = call float @dx.op.unary.f32(i32 7, float %1076)  ; Saturate(value)
  br label %1080

; <label>:1080                                    ; preds = %1048, %881
  %1081 = phi float [ %912, %881 ], [ %1077, %1048 ]
  %1082 = phi float [ %913, %881 ], [ %1078, %1048 ]
  %1083 = phi float [ %914, %881 ], [ %1079, %1048 ]
  %1084 = call float @dx.op.binary.f32(i32 36, float %867, float %1081)  ; FMin(a,b)
  %1085 = call float @dx.op.binary.f32(i32 36, float %868, float %1082)  ; FMin(a,b)
  %1086 = call float @dx.op.binary.f32(i32 36, float %869, float %1083)  ; FMin(a,b)
  %1087 = call float @dx.op.binary.f32(i32 36, float %435, float %649)  ; FMin(a,b)
  %1088 = call float @dx.op.binary.f32(i32 36, float %436, float %650)  ; FMin(a,b)
  %1089 = call float @dx.op.binary.f32(i32 36, float %437, float %651)  ; FMin(a,b)
  %1090 = call float @dx.op.binary.f32(i32 36, float %1087, float %1084)  ; FMin(a,b)
  %1091 = call float @dx.op.binary.f32(i32 36, float %1088, float %1085)  ; FMin(a,b)
  %1092 = call float @dx.op.binary.f32(i32 36, float %1089, float %1086)  ; FMin(a,b)
  %1093 = call float @dx.op.binary.f32(i32 36, float %215, float %1090)  ; FMin(a,b)
  %1094 = call float @dx.op.binary.f32(i32 36, float %216, float %1091)  ; FMin(a,b)
  %1095 = call float @dx.op.binary.f32(i32 36, float %217, float %1092)  ; FMin(a,b)
  %1096 = call float @dx.op.binary.f32(i32 35, float %867, float %1081)  ; FMax(a,b)
  %1097 = call float @dx.op.binary.f32(i32 35, float %868, float %1082)  ; FMax(a,b)
  %1098 = call float @dx.op.binary.f32(i32 35, float %869, float %1083)  ; FMax(a,b)
  %1099 = call float @dx.op.binary.f32(i32 35, float %435, float %649)  ; FMax(a,b)
  %1100 = call float @dx.op.binary.f32(i32 35, float %436, float %650)  ; FMax(a,b)
  %1101 = call float @dx.op.binary.f32(i32 35, float %437, float %651)  ; FMax(a,b)
  %1102 = call float @dx.op.binary.f32(i32 35, float %1099, float %1096)  ; FMax(a,b)
  %1103 = call float @dx.op.binary.f32(i32 35, float %1100, float %1097)  ; FMax(a,b)
  %1104 = call float @dx.op.binary.f32(i32 35, float %1101, float %1098)  ; FMax(a,b)
  %1105 = call float @dx.op.binary.f32(i32 35, float %215, float %1102)  ; FMax(a,b)
  %1106 = call float @dx.op.binary.f32(i32 35, float %216, float %1103)  ; FMax(a,b)
  %1107 = call float @dx.op.binary.f32(i32 35, float %217, float %1104)  ; FMax(a,b)
  %1108 = fsub fast float %1105, %1093
  %1109 = fsub fast float %1106, %1094
  %1110 = fsub fast float %1107, %1095
  %1111 = call float @dx.op.unary.f32(i32 6, float %1108)  ; FAbs(value)
  %1112 = call float @dx.op.unary.f32(i32 6, float %1109)  ; FAbs(value)
  %1113 = call float @dx.op.unary.f32(i32 6, float %1110)  ; FAbs(value)
  %1114 = call float @dx.op.binary.f32(i32 35, float %1112, float %1113)  ; FMax(a,b)
  %1115 = call float @dx.op.binary.f32(i32 35, float %1111, float %1114)  ; FMax(a,b)
  %1116 = call float @dx.op.binary.f32(i32 35, float %1106, float %1107)  ; FMax(a,b)
  %1117 = call float @dx.op.binary.f32(i32 35, float %1105, float %1116)  ; FMax(a,b)
  %1118 = fmul fast float %1117, 1.250000e-01
  %1119 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1118)  ; FMax(a,b)
  %1120 = fcmp fast ogt float %1115, %1119
  br i1 %1120, label %1121, label %1182

; <label>:1121                                    ; preds = %1080
  %1122 = fsub fast float %435, %649
  %1123 = fsub fast float %436, %650
  %1124 = fsub fast float %437, %651
  %1125 = call float @dx.op.unary.f32(i32 6, float %1122)  ; FAbs(value)
  %1126 = call float @dx.op.unary.f32(i32 6, float %1123)  ; FAbs(value)
  %1127 = call float @dx.op.unary.f32(i32 6, float %1124)  ; FAbs(value)
  %1128 = call float @dx.op.binary.f32(i32 35, float %1126, float %1127)  ; FMax(a,b)
  %1129 = call float @dx.op.binary.f32(i32 35, float %1125, float %1128)  ; FMax(a,b)
  %1130 = fsub fast float %867, %1081
  %1131 = fsub fast float %868, %1082
  %1132 = fsub fast float %869, %1083
  %1133 = call float @dx.op.unary.f32(i32 6, float %1130)  ; FAbs(value)
  %1134 = call float @dx.op.unary.f32(i32 6, float %1131)  ; FAbs(value)
  %1135 = call float @dx.op.unary.f32(i32 6, float %1132)  ; FAbs(value)
  %1136 = call float @dx.op.binary.f32(i32 35, float %1134, float %1135)  ; FMax(a,b)
  %1137 = call float @dx.op.binary.f32(i32 35, float %1133, float %1136)  ; FMax(a,b)
  %1138 = fcmp fast olt float %1129, %1137
  %1139 = select i1 %1138, float %435, float %867
  %1140 = select i1 %1138, float %436, float %868
  %1141 = select i1 %1138, float %437, float %869
  %1142 = select i1 %1138, float %649, float %1081
  %1143 = select i1 %1138, float %650, float %1082
  %1144 = select i1 %1138, float %651, float %1083
  %1145 = fsub fast float %215, %1142
  %1146 = fsub fast float %216, %1143
  %1147 = fsub fast float %217, %1144
  %1148 = fsub fast float %215, %1139
  %1149 = fsub fast float %216, %1140
  %1150 = fsub fast float %217, %1141
  %1151 = call float @dx.op.dot3.f32(i32 55, float %1148, float %1149, float %1150, float %1145, float %1146, float %1147)  ; Dot3(ax,ay,az,bx,by,bz)
  %1152 = fcmp fast ogt float %1151, 0.000000e+00
  br i1 %1152, label %1153, label %1165

; <label>:1153                                    ; preds = %1121
  %1154 = fsub fast float %1139, %1142
  %1155 = fsub fast float %1140, %1143
  %1156 = fsub fast float %1141, %1144
  %1157 = call float @dx.op.unary.f32(i32 6, float %1154)  ; FAbs(value)
  %1158 = call float @dx.op.unary.f32(i32 6, float %1155)  ; FAbs(value)
  %1159 = call float @dx.op.unary.f32(i32 6, float %1156)  ; FAbs(value)
  %1160 = call float @dx.op.binary.f32(i32 35, float %1158, float %1159)  ; FMax(a,b)
  %1161 = call float @dx.op.binary.f32(i32 35, float %1157, float %1160)  ; FMax(a,b)
  %1162 = fmul fast float %1115, 2.500000e-01
  %1163 = fcmp fast olt float %1161, %1162
  %1164 = select i1 %1163, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  br label %1165

; <label>:1165                                    ; preds = %1153, %1121
  %1166 = phi float [ 0x3FC99999A0000000, %1121 ], [ %1164, %1153 ]
  %1167 = fadd fast float %1139, %1142
  %1168 = fadd fast float %1140, %1143
  %1169 = fadd fast float %1141, %1144
  %1170 = fmul fast float %1167, 5.000000e-01
  %1171 = fmul fast float %1168, 5.000000e-01
  %1172 = fmul fast float %1169, 5.000000e-01
  %1173 = fsub fast float %1170, %215
  %1174 = fsub fast float %1171, %216
  %1175 = fsub fast float %1172, %217
  %1176 = fmul fast float %1166, %1173
  %1177 = fmul fast float %1166, %1174
  %1178 = fmul fast float %1166, %1175
  %1179 = fadd fast float %1176, %215
  %1180 = fadd fast float %1177, %216
  %1181 = fadd fast float %1178, %217
  br label %1182

; <label>:1182                                    ; preds = %1165, %1080
  %1183 = phi float [ %1179, %1165 ], [ %215, %1080 ]
  %1184 = phi float [ %1180, %1165 ], [ %216, %1080 ]
  %1185 = phi float [ %1181, %1165 ], [ %217, %1080 ]
  %1186 = fcmp fast ogt float %1183, 0x3F69A5C380000000
  %1187 = fcmp fast ogt float %1184, 0x3F69A5C380000000
  %1188 = fcmp fast ogt float %1185, 0x3F69A5C380000000
  %1189 = select i1 %1186, float 0.000000e+00, float 1.000000e+00
  %1190 = select i1 %1187, float 0.000000e+00, float 1.000000e+00
  %1191 = select i1 %1188, float 0.000000e+00, float 1.000000e+00
  %1192 = fmul fast float %1183, 0x4029D70A40000000
  %1193 = fmul fast float %1184, 0x4029D70A40000000
  %1194 = fmul fast float %1185, 0x4029D70A40000000
  %1195 = call float @dx.op.binary.f32(i32 35, float %1183, float 0.000000e+00)  ; FMax(a,b)
  %1196 = call float @dx.op.binary.f32(i32 35, float %1184, float 0.000000e+00)  ; FMax(a,b)
  %1197 = call float @dx.op.binary.f32(i32 35, float %1185, float 0.000000e+00)  ; FMax(a,b)
  %1198 = call float @dx.op.unary.f32(i32 23, float %1195)  ; Log(value)
  %1199 = call float @dx.op.unary.f32(i32 23, float %1196)  ; Log(value)
  %1200 = call float @dx.op.unary.f32(i32 23, float %1197)  ; Log(value)
  %1201 = fmul fast float %1198, 0x3FDAAAAAA0000000
  %1202 = fmul fast float %1199, 0x3FDAAAAAA0000000
  %1203 = fmul fast float %1200, 0x3FDAAAAAA0000000
  %1204 = call float @dx.op.unary.f32(i32 21, float %1201)  ; Exp(value)
  %1205 = call float @dx.op.unary.f32(i32 21, float %1202)  ; Exp(value)
  %1206 = call float @dx.op.unary.f32(i32 21, float %1203)  ; Exp(value)
  %1207 = fmul fast float %1204, 0x3FF0E147A0000000
  %1208 = fmul fast float %1205, 0x3FF0E147A0000000
  %1209 = fmul fast float %1206, 0x3FF0E147A0000000
  %1210 = fadd fast float %1207, 0xBFAC28F5C0000000
  %1211 = fadd fast float %1208, 0xBFAC28F5C0000000
  %1212 = fadd fast float %1209, 0xBFAC28F5C0000000
  %1213 = fsub fast float %1192, %1210
  %1214 = fsub fast float %1193, %1211
  %1215 = fsub fast float %1194, %1212
  %1216 = fmul fast float %1213, %1189
  %1217 = fmul fast float %1214, %1190
  %1218 = fmul fast float %1215, %1191
  %1219 = fadd fast float %1216, %1210
  %1220 = fadd fast float %1217, %1211
  %1221 = fadd fast float %1218, %1212
  br label %1222

; <label>:1222                                    ; preds = %1182, %51
  %1223 = phi float [ %46, %51 ], [ %1219, %1182 ]
  %1224 = phi float [ %47, %51 ], [ %1220, %1182 ]
  %1225 = phi float [ %48, %51 ], [ %1221, %1182 ]
  %1226 = phi float [ %52, %51 ], [ %49, %1182 ]
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %1223)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %1224)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %1225)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %1226)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 0, i32 0, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !37, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, null}
!36 = !{i32 9}
!37 = !{!38}
!38 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
