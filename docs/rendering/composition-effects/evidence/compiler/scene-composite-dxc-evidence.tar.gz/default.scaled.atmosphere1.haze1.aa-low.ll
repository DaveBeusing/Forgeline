;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float    yz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: beabbb754beb6f4881f36dd39539b33d
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %40 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %41 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %42 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %43 = extractvalue %dx.types.Dimensions %42, 0
  %44 = extractvalue %dx.types.Dimensions %42, 1
  %45 = uitofp i32 %43 to float
  %46 = uitofp i32 %44 to float
  %47 = fmul fast float %45, %40
  %48 = fmul fast float %46, %41
  %49 = fdiv fast float %47, %3
  %50 = fdiv fast float %48, %4
  %51 = fadd fast float %49, -5.000000e-01
  %52 = fadd fast float %50, -5.000000e-01
  %53 = call float @dx.op.unary.f32(i32 27, float %51)  ; Round_ni(value)
  %54 = call float @dx.op.unary.f32(i32 27, float %52)  ; Round_ni(value)
  %55 = fptosi float %53 to i32
  %56 = fptosi float %54 to i32
  %57 = call float @dx.op.unary.f32(i32 22, float %51)  ; Frc(value)
  %58 = call float @dx.op.unary.f32(i32 22, float %52)  ; Frc(value)
  %59 = add i32 %43, -1
  %60 = add i32 %44, -1
  %61 = call i32 @dx.op.binary.i32(i32 37, i32 %55, i32 0)  ; IMax(a,b)
  %62 = call i32 @dx.op.binary.i32(i32 37, i32 %56, i32 0)  ; IMax(a,b)
  %63 = call i32 @dx.op.binary.i32(i32 38, i32 %61, i32 %59)  ; IMin(a,b)
  %64 = call i32 @dx.op.binary.i32(i32 38, i32 %62, i32 %60)  ; IMin(a,b)
  %65 = add i32 %55, 1
  %66 = call i32 @dx.op.binary.i32(i32 37, i32 %65, i32 0)  ; IMax(a,b)
  %67 = call i32 @dx.op.binary.i32(i32 38, i32 %66, i32 %59)  ; IMin(a,b)
  %68 = add i32 %56, 1
  %69 = call i32 @dx.op.binary.i32(i32 37, i32 %68, i32 0)  ; IMax(a,b)
  %70 = call i32 @dx.op.binary.i32(i32 38, i32 %69, i32 %60)  ; IMin(a,b)
  %71 = call float @dx.op.unary.f32(i32 27, float %49)  ; Round_ni(value)
  %72 = call float @dx.op.unary.f32(i32 27, float %50)  ; Round_ni(value)
  %73 = fptosi float %71 to i32
  %74 = fptosi float %72 to i32
  %75 = call i32 @dx.op.binary.i32(i32 37, i32 %73, i32 0)  ; IMax(a,b)
  %76 = call i32 @dx.op.binary.i32(i32 37, i32 %74, i32 0)  ; IMax(a,b)
  %77 = call i32 @dx.op.binary.i32(i32 38, i32 %75, i32 %59)  ; IMin(a,b)
  %78 = call i32 @dx.op.binary.i32(i32 38, i32 %76, i32 %60)  ; IMin(a,b)
  %79 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %77, i32 %78, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %80 = extractvalue %dx.types.ResRet.f32 %79, 0
  %81 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %82 = extractvalue %dx.types.ResRet.f32 %81, 0
  %83 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %67, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %84 = extractvalue %dx.types.ResRet.f32 %83, 0
  %85 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %86 = extractvalue %dx.types.ResRet.f32 %85, 0
  %87 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %67, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %88 = extractvalue %dx.types.ResRet.f32 %87, 0
  %89 = fsub fast float 1.000000e+00, %57
  %90 = fsub fast float 1.000000e+00, %58
  %91 = fmul fast float %90, %89
  %92 = fmul fast float %90, %57
  %93 = fmul fast float %89, %58
  %94 = fmul fast float %58, %57
  %95 = fsub fast float 1.000000e+00, %80
  %96 = fmul fast float %95, 0x3FA99999A0000000
  %97 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %96)  ; FMax(a,b)
  %98 = fsub fast float %82, %80
  %99 = call float @dx.op.unary.f32(i32 6, float %98)  ; FAbs(value)
  %100 = fdiv fast float %99, %97
  %101 = fsub fast float 1.000000e+00, %100
  %102 = call float @dx.op.unary.f32(i32 7, float %101)  ; Saturate(value)
  %103 = fsub fast float %84, %80
  %104 = call float @dx.op.unary.f32(i32 6, float %103)  ; FAbs(value)
  %105 = fdiv fast float %104, %97
  %106 = fsub fast float 1.000000e+00, %105
  %107 = call float @dx.op.unary.f32(i32 7, float %106)  ; Saturate(value)
  %108 = fsub fast float %86, %80
  %109 = call float @dx.op.unary.f32(i32 6, float %108)  ; FAbs(value)
  %110 = fdiv fast float %109, %97
  %111 = fsub fast float 1.000000e+00, %110
  %112 = call float @dx.op.unary.f32(i32 7, float %111)  ; Saturate(value)
  %113 = fsub fast float %88, %80
  %114 = call float @dx.op.unary.f32(i32 6, float %113)  ; FAbs(value)
  %115 = fdiv fast float %114, %97
  %116 = fsub fast float 1.000000e+00, %115
  %117 = call float @dx.op.unary.f32(i32 7, float %116)  ; Saturate(value)
  %118 = fmul fast float %91, %102
  %119 = fmul fast float %92, %107
  %120 = fmul fast float %93, %112
  %121 = fmul fast float %94, %117
  %122 = fcmp fast oge float %57, 5.000000e-01
  %123 = zext i1 %122 to i32
  %124 = fcmp fast oge float %58, 5.000000e-01
  %125 = select i1 %124, i32 2, i32 0
  %126 = or i32 %125, %123
  %127 = call float @dx.op.dot4.f32(i32 56, float %118, float %119, float %120, float %121, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %128 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %118)  ; IsFinite(value)
  %129 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %119)  ; IsFinite(value)
  %130 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %120)  ; IsFinite(value)
  %131 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %121)  ; IsFinite(value)
  %132 = and i1 %128, %129
  %133 = and i1 %132, %130
  %134 = and i1 %133, %131
  br i1 %134, label %135, label %152

; <label>:135                                     ; preds = %0
  %136 = fcmp fast oge float %118, 0.000000e+00
  %137 = fcmp fast oge float %119, 0.000000e+00
  %138 = fcmp fast oge float %120, 0.000000e+00
  %139 = fcmp fast oge float %121, 0.000000e+00
  %140 = and i1 %136, %137
  %141 = and i1 %140, %138
  %142 = and i1 %141, %139
  br i1 %142, label %143, label %152

; <label>:143                                     ; preds = %135
  %144 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %127)  ; IsFinite(value)
  %145 = fcmp fast oge float %127, 0x3810000000000000
  %146 = and i1 %145, %144
  br i1 %146, label %147, label %152

; <label>:147                                     ; preds = %143
  %148 = fdiv fast float %118, %127
  %149 = fdiv fast float %119, %127
  %150 = fdiv fast float %120, %127
  %151 = fdiv fast float %121, %127
  br label %161

; <label>:152                                     ; preds = %143, %135, %0
  %153 = icmp eq i32 %126, 0
  %154 = uitofp i1 %153 to float
  %155 = icmp eq i32 %126, 1
  %156 = uitofp i1 %155 to float
  %157 = icmp eq i32 %126, 2
  %158 = uitofp i1 %157 to float
  %159 = icmp eq i32 %126, 3
  %160 = uitofp i1 %159 to float
  br label %161

; <label>:161                                     ; preds = %152, %147
  %162 = phi float [ %148, %147 ], [ %154, %152 ]
  %163 = phi float [ %149, %147 ], [ %156, %152 ]
  %164 = phi float [ %150, %147 ], [ %158, %152 ]
  %165 = phi float [ %151, %147 ], [ %160, %152 ]
  %166 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %167 = extractvalue %dx.types.ResRet.f32 %166, 0
  %168 = extractvalue %dx.types.ResRet.f32 %166, 1
  %169 = extractvalue %dx.types.ResRet.f32 %166, 2
  %170 = extractvalue %dx.types.ResRet.f32 %166, 3
  %171 = fcmp fast olt float %170, 0.000000e+00
  br i1 %171, label %172, label %174

; <label>:172                                     ; preds = %161
  %173 = fsub fast float -1.000000e+00, %170
  br label %1684

; <label>:174                                     ; preds = %161
  %175 = fcmp fast ogt float %38, 5.000000e-01
  %176 = fcmp fast olt float %82, 1.000000e+00
  %177 = and i1 %175, %176
  br i1 %177, label %178, label %316

; <label>:178                                     ; preds = %174
  %179 = sitofp i32 %63 to float
  %180 = sitofp i32 %64 to float
  %181 = fadd fast float %179, 5.000000e-01
  %182 = fadd fast float %180, 5.000000e-01
  %183 = fdiv fast float %181, %45
  %184 = fdiv fast float %182, %46
  %185 = fmul fast float %183, 2.000000e+00
  %186 = fmul fast float %184, 2.000000e+00
  %187 = fadd fast float %185, -1.000000e+00
  %188 = fsub fast float 1.000000e+00, %186
  %189 = fmul fast float %187, %35
  %190 = call float @dx.op.tertiary.f32(i32 46, float %188, float %31, float %189)  ; FMad(a,b,c)
  %191 = call float @dx.op.tertiary.f32(i32 46, float %82, float %27, float %190)  ; FMad(a,b,c)
  %192 = fadd fast float %191, %23
  %193 = call float @dx.op.unary.f32(i32 6, float %192)  ; FAbs(value)
  %194 = fcmp fast ogt float %193, 0x3EB0C6F7A0000000
  br i1 %194, label %195, label %316

; <label>:195                                     ; preds = %178
  %196 = fmul fast float %187, %34
  %197 = call float @dx.op.tertiary.f32(i32 46, float %188, float %30, float %196)  ; FMad(a,b,c)
  %198 = call float @dx.op.tertiary.f32(i32 46, float %82, float %26, float %197)  ; FMad(a,b,c)
  %199 = fadd fast float %198, %22
  %200 = fmul fast float %187, %33
  %201 = call float @dx.op.tertiary.f32(i32 46, float %188, float %29, float %200)  ; FMad(a,b,c)
  %202 = call float @dx.op.tertiary.f32(i32 46, float %82, float %25, float %201)  ; FMad(a,b,c)
  %203 = fadd fast float %202, %21
  %204 = fmul fast float %187, %32
  %205 = call float @dx.op.tertiary.f32(i32 46, float %188, float %28, float %204)  ; FMad(a,b,c)
  %206 = call float @dx.op.tertiary.f32(i32 46, float %82, float %24, float %205)  ; FMad(a,b,c)
  %207 = fadd fast float %206, %20
  %208 = fdiv fast float %207, %192
  %209 = fdiv fast float %203, %192
  %210 = fdiv fast float %199, %192
  %211 = fsub fast float %208, %17
  %212 = fsub fast float %209, %18
  %213 = fsub fast float %210, %19
  %214 = fmul fast float %211, %211
  %215 = fmul fast float %212, %212
  %216 = fadd fast float %215, %214
  %217 = fmul fast float %213, %213
  %218 = fadd fast float %216, %217
  %219 = call float @dx.op.unary.f32(i32 24, float %218)  ; Sqrt(value)
  %220 = fsub fast float %219, %9
  %221 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %220)  ; FMax(a,b)
  %222 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %222, label %223, label %246

; <label>:223                                     ; preds = %195
  %224 = call float @dx.op.unary.f32(i32 6, float %212)  ; FAbs(value)
  %225 = fmul fast float %224, %11
  %226 = fcmp fast olt float %225, 0x3F50624DE0000000
  br i1 %226, label %227, label %230

; <label>:227                                     ; preds = %223
  %228 = fmul fast float %225, 5.000000e-01
  %229 = fsub fast float 1.000000e+00, %228
  br label %235

; <label>:230                                     ; preds = %223
  %231 = fmul fast float %225, 0xBFF7154760000000
  %232 = call float @dx.op.unary.f32(i32 21, float %231)  ; Exp(value)
  %233 = fsub fast float 1.000000e+00, %232
  %234 = fdiv fast float %233, %225
  br label %235

; <label>:235                                     ; preds = %230, %227
  %236 = phi float [ %229, %227 ], [ %234, %230 ]
  %237 = call float @dx.op.binary.f32(i32 36, float %209, float %18)  ; FMin(a,b)
  %238 = fsub fast float %237, %10
  %239 = fmul fast float %11, %238
  %240 = fsub fast float -0.000000e+00, %239
  %241 = call float @dx.op.binary.f32(i32 35, float %240, float -4.000000e+01)  ; FMax(a,b)
  %242 = call float @dx.op.binary.f32(i32 36, float %241, float 5.000000e+00)  ; FMin(a,b)
  %243 = fmul fast float %242, 0x3FF7154760000000
  %244 = call float @dx.op.unary.f32(i32 21, float %243)  ; Exp(value)
  %245 = fmul fast float %244, %236
  br label %246

; <label>:246                                     ; preds = %235, %195
  %247 = phi float [ %245, %235 ], [ 1.000000e+00, %195 ]
  %248 = fmul fast float %221, %16
  %249 = fmul fast float %248, %247
  %250 = fcmp fast ole float %219, %9
  %251 = fcmp fast olt float %219, 0x3F1A36E2E0000000
  %252 = or i1 %250, %251
  br i1 %252, label %299, label %253

; <label>:253                                     ; preds = %246
  %254 = fdiv fast float %9, %219
  %255 = fmul fast float %254, %211
  %256 = fmul fast float %254, %212
  %257 = fmul fast float %254, %213
  %258 = fadd fast float %255, %17
  %259 = fadd fast float %256, %18
  %260 = fadd fast float %257, %19
  %261 = fadd fast float %258, -9.000000e+02
  %262 = fadd fast float %259, -1.500000e+01
  %263 = fadd fast float %260, -7.500000e+02
  %264 = fmul fast float %261, 0x3F62345680000000
  %265 = fmul fast float %262, 0x3F62345680000000
  %266 = fmul fast float %263, 0x3F62345680000000
  %267 = call float @dx.op.dot3.f32(i32 55, float %264, float %265, float %266, float %264, float %265, float %266)  ; Dot3(ax,ay,az,bx,by,bz)
  %268 = fsub fast float 1.000000e+00, %267
  %269 = call float @dx.op.unary.f32(i32 7, float %268)  ; Saturate(value)
  %270 = fmul fast float %269, %269
  %271 = fadd fast float %258, %208
  %272 = fadd fast float %259, %209
  %273 = fadd fast float %260, %210
  %274 = fmul fast float %271, 0x3F52345680000000
  %275 = fadd fast float %274, -2.000000e+00
  %276 = fmul fast float %272, 0x3F52345680000000
  %277 = fadd fast float %276, 0xBFA1111120000000
  %278 = fmul fast float %273, 0x3F52345680000000
  %279 = fadd fast float %278, 0xBFFAAAAAC0000000
  %280 = call float @dx.op.dot3.f32(i32 55, float %275, float %277, float %279, float %275, float %277, float %279)  ; Dot3(ax,ay,az,bx,by,bz)
  %281 = fsub fast float 1.000000e+00, %280
  %282 = call float @dx.op.unary.f32(i32 7, float %281)  ; Saturate(value)
  %283 = fmul fast float %282, %282
  %284 = fmul fast float %283, 4.000000e+00
  %285 = fadd fast float %284, %270
  %286 = fadd fast float %208, -9.000000e+02
  %287 = fadd fast float %209, -1.500000e+01
  %288 = fadd fast float %210, -7.500000e+02
  %289 = fmul fast float %286, 0x3F62345680000000
  %290 = fmul fast float %287, 0x3F62345680000000
  %291 = fmul fast float %288, 0x3F62345680000000
  %292 = call float @dx.op.dot3.f32(i32 55, float %289, float %290, float %291, float %289, float %290, float %291)  ; Dot3(ax,ay,az,bx,by,bz)
  %293 = fsub fast float 1.000000e+00, %292
  %294 = call float @dx.op.unary.f32(i32 7, float %293)  ; Saturate(value)
  %295 = fmul fast float %294, %294
  %296 = fadd fast float %285, %295
  %297 = fmul fast float %220, 0x3F25D867E0000000
  %298 = fmul fast float %297, %296
  br label %299

; <label>:299                                     ; preds = %253, %246
  %300 = phi float [ %298, %253 ], [ 0.000000e+00, %246 ]
  %301 = fadd fast float %300, %249
  %302 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %301)  ; FMin(a,b)
  %303 = fmul fast float %302, 0xBFF7154760000000
  %304 = call float @dx.op.unary.f32(i32 21, float %303)  ; Exp(value)
  %305 = fsub fast float 1.000000e+00, %304
  %306 = call float @dx.op.binary.f32(i32 36, float %12, float %305)  ; FMin(a,b)
  %307 = fsub fast float %13, %167
  %308 = fsub fast float %14, %168
  %309 = fsub fast float %15, %169
  %310 = fmul fast float %306, %307
  %311 = fmul fast float %306, %308
  %312 = fmul fast float %306, %309
  %313 = fadd fast float %310, %167
  %314 = fadd fast float %311, %168
  %315 = fadd fast float %312, %169
  br label %316

; <label>:316                                     ; preds = %299, %178, %174
  %317 = phi float [ %313, %299 ], [ %167, %178 ], [ %167, %174 ]
  %318 = phi float [ %314, %299 ], [ %168, %178 ], [ %168, %174 ]
  %319 = phi float [ %315, %299 ], [ %169, %178 ], [ %169, %174 ]
  %320 = fadd fast float %5, 1.000000e+00
  %321 = fadd fast float %6, 1.000000e+00
  %322 = fsub fast float 1.000000e+00, %5
  %323 = fmul fast float %36, %320
  %324 = fmul fast float %36, %321
  %325 = fmul fast float %36, %322
  %326 = fmul fast float %323, %317
  %327 = fmul fast float %324, %318
  %328 = fmul fast float %325, %319
  %329 = fcmp fast ult float %37, 5.000000e-01
  br i1 %329, label %355, label %330

; <label>:330                                     ; preds = %316
  %331 = fmul fast float %326, 0x4004147AE0000000
  %332 = fmul fast float %327, 0x4004147AE0000000
  %333 = fmul fast float %328, 0x4004147AE0000000
  %334 = fadd fast float %331, 0x3F9EB851E0000000
  %335 = fadd fast float %332, 0x3F9EB851E0000000
  %336 = fadd fast float %333, 0x3F9EB851E0000000
  %337 = fmul fast float %334, %326
  %338 = fmul fast float %335, %327
  %339 = fmul fast float %336, %328
  %340 = fmul fast float %326, 0x400370A3E0000000
  %341 = fmul fast float %327, 0x400370A3E0000000
  %342 = fmul fast float %328, 0x400370A3E0000000
  %343 = fadd fast float %340, 0x3FE2E147A0000000
  %344 = fadd fast float %341, 0x3FE2E147A0000000
  %345 = fadd fast float %342, 0x3FE2E147A0000000
  %346 = fmul fast float %343, %326
  %347 = fmul fast float %344, %327
  %348 = fmul fast float %345, %328
  %349 = fadd fast float %346, 0x3FC1EB8520000000
  %350 = fadd fast float %347, 0x3FC1EB8520000000
  %351 = fadd fast float %348, 0x3FC1EB8520000000
  %352 = fdiv fast float %337, %349
  %353 = fdiv fast float %338, %350
  %354 = fdiv fast float %339, %351
  br label %355

; <label>:355                                     ; preds = %330, %316
  %356 = phi float [ %352, %330 ], [ %326, %316 ]
  %357 = phi float [ %353, %330 ], [ %327, %316 ]
  %358 = phi float [ %354, %330 ], [ %328, %316 ]
  %359 = call float @dx.op.unary.f32(i32 7, float %356)  ; Saturate(value)
  %360 = call float @dx.op.unary.f32(i32 7, float %357)  ; Saturate(value)
  %361 = call float @dx.op.unary.f32(i32 7, float %358)  ; Saturate(value)
  %362 = call float @dx.op.dot3.f32(i32 55, float %359, float %360, float %361, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %363 = fsub fast float %359, %362
  %364 = fsub fast float %360, %362
  %365 = fsub fast float %361, %362
  %366 = fmul fast float %363, %8
  %367 = fmul fast float %364, %8
  %368 = fmul fast float %365, %8
  %369 = fadd fast float %366, %362
  %370 = fadd fast float %367, %362
  %371 = fadd fast float %368, %362
  %372 = call float @dx.op.unary.f32(i32 7, float %369)  ; Saturate(value)
  %373 = call float @dx.op.unary.f32(i32 7, float %370)  ; Saturate(value)
  %374 = call float @dx.op.unary.f32(i32 7, float %371)  ; Saturate(value)
  %375 = fadd fast float %372, 0xBFC70A3D80000000
  %376 = fadd fast float %373, 0xBFC70A3D80000000
  %377 = fadd fast float %374, 0xBFC70A3D80000000
  %378 = fmul fast float %375, %7
  %379 = fmul fast float %376, %7
  %380 = fmul fast float %377, %7
  %381 = fadd fast float %378, 0x3FC70A3D80000000
  %382 = fadd fast float %379, 0x3FC70A3D80000000
  %383 = fadd fast float %380, 0x3FC70A3D80000000
  %384 = call float @dx.op.unary.f32(i32 7, float %381)  ; Saturate(value)
  %385 = call float @dx.op.unary.f32(i32 7, float %382)  ; Saturate(value)
  %386 = call float @dx.op.unary.f32(i32 7, float %383)  ; Saturate(value)
  %387 = add i32 %64, -1
  %388 = call i32 @dx.op.binary.i32(i32 37, i32 %63, i32 0)  ; IMax(a,b)
  %389 = call i32 @dx.op.binary.i32(i32 37, i32 %387, i32 0)  ; IMax(a,b)
  %390 = call i32 @dx.op.binary.i32(i32 38, i32 %388, i32 %59)  ; IMin(a,b)
  %391 = call i32 @dx.op.binary.i32(i32 38, i32 %389, i32 %60)  ; IMin(a,b)
  %392 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %390, i32 %391, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %393 = extractvalue %dx.types.ResRet.f32 %392, 0
  %394 = fsub fast float 1.000000e+00, %82
  %395 = fmul fast float %394, 0x3FA99999A0000000
  %396 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %395)  ; FMax(a,b)
  %397 = fsub fast float %393, %82
  %398 = call float @dx.op.unary.f32(i32 6, float %397)  ; FAbs(value)
  %399 = fdiv fast float %398, %396
  %400 = fsub fast float 1.000000e+00, %399
  %401 = call float @dx.op.unary.f32(i32 7, float %400)  ; Saturate(value)
  %402 = fcmp fast ugt float %401, 0.000000e+00
  br i1 %402, label %403, label %676

; <label>:403                                     ; preds = %355
  %404 = call i32 @dx.op.binary.i32(i32 37, i32 %390, i32 0)  ; IMax(a,b)
  %405 = call i32 @dx.op.binary.i32(i32 37, i32 %391, i32 0)  ; IMax(a,b)
  %406 = call i32 @dx.op.binary.i32(i32 38, i32 %404, i32 %59)  ; IMin(a,b)
  %407 = call i32 @dx.op.binary.i32(i32 38, i32 %405, i32 %60)  ; IMin(a,b)
  %408 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %406, i32 %407, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %409 = extractvalue %dx.types.ResRet.f32 %408, 0
  %410 = extractvalue %dx.types.ResRet.f32 %408, 1
  %411 = extractvalue %dx.types.ResRet.f32 %408, 2
  %412 = extractvalue %dx.types.ResRet.f32 %408, 3
  %413 = fcmp fast olt float %412, 0.000000e+00
  br i1 %413, label %414, label %448

; <label>:414                                     ; preds = %403
  %415 = fcmp fast ogt float %409, 0x3FA4B5DCC0000000
  %416 = fcmp fast ogt float %410, 0x3FA4B5DCC0000000
  %417 = fcmp fast ogt float %411, 0x3FA4B5DCC0000000
  %418 = select i1 %415, float 0.000000e+00, float 1.000000e+00
  %419 = select i1 %416, float 0.000000e+00, float 1.000000e+00
  %420 = select i1 %417, float 0.000000e+00, float 1.000000e+00
  %421 = fmul fast float %409, 0x3FB3D07220000000
  %422 = fmul fast float %410, 0x3FB3D07220000000
  %423 = fmul fast float %411, 0x3FB3D07220000000
  %424 = fadd fast float %409, 0x3FAC28F5C0000000
  %425 = fadd fast float %410, 0x3FAC28F5C0000000
  %426 = fadd fast float %411, 0x3FAC28F5C0000000
  %427 = fmul fast float %424, 0x3FEE54EDE0000000
  %428 = fmul fast float %425, 0x3FEE54EDE0000000
  %429 = fmul fast float %426, 0x3FEE54EDE0000000
  %430 = call float @dx.op.unary.f32(i32 23, float %427)  ; Log(value)
  %431 = call float @dx.op.unary.f32(i32 23, float %428)  ; Log(value)
  %432 = call float @dx.op.unary.f32(i32 23, float %429)  ; Log(value)
  %433 = fmul fast float %430, 0x4003333340000000
  %434 = fmul fast float %431, 0x4003333340000000
  %435 = fmul fast float %432, 0x4003333340000000
  %436 = call float @dx.op.unary.f32(i32 21, float %433)  ; Exp(value)
  %437 = call float @dx.op.unary.f32(i32 21, float %434)  ; Exp(value)
  %438 = call float @dx.op.unary.f32(i32 21, float %435)  ; Exp(value)
  %439 = fsub fast float %421, %436
  %440 = fsub fast float %422, %437
  %441 = fsub fast float %423, %438
  %442 = fmul fast float %439, %418
  %443 = fmul fast float %440, %419
  %444 = fmul fast float %441, %420
  %445 = fadd fast float %442, %436
  %446 = fadd fast float %443, %437
  %447 = fadd fast float %444, %438
  br label %663

; <label>:448                                     ; preds = %403
  %449 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %406, i32 %407, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %450 = extractvalue %dx.types.ResRet.f32 %449, 0
  %451 = fcmp fast ogt float %38, 5.000000e-01
  %452 = fcmp fast olt float %450, 1.000000e+00
  %453 = and i1 %451, %452
  br i1 %453, label %454, label %592

; <label>:454                                     ; preds = %448
  %455 = sitofp i32 %406 to float
  %456 = sitofp i32 %407 to float
  %457 = fadd fast float %455, 5.000000e-01
  %458 = fadd fast float %456, 5.000000e-01
  %459 = fdiv fast float %457, %45
  %460 = fdiv fast float %458, %46
  %461 = fmul fast float %459, 2.000000e+00
  %462 = fmul fast float %460, 2.000000e+00
  %463 = fadd fast float %461, -1.000000e+00
  %464 = fsub fast float 1.000000e+00, %462
  %465 = fmul fast float %463, %35
  %466 = call float @dx.op.tertiary.f32(i32 46, float %464, float %31, float %465)  ; FMad(a,b,c)
  %467 = call float @dx.op.tertiary.f32(i32 46, float %450, float %27, float %466)  ; FMad(a,b,c)
  %468 = fadd fast float %467, %23
  %469 = call float @dx.op.unary.f32(i32 6, float %468)  ; FAbs(value)
  %470 = fcmp fast ogt float %469, 0x3EB0C6F7A0000000
  br i1 %470, label %471, label %592

; <label>:471                                     ; preds = %454
  %472 = fmul fast float %463, %34
  %473 = call float @dx.op.tertiary.f32(i32 46, float %464, float %30, float %472)  ; FMad(a,b,c)
  %474 = call float @dx.op.tertiary.f32(i32 46, float %450, float %26, float %473)  ; FMad(a,b,c)
  %475 = fadd fast float %474, %22
  %476 = fmul fast float %463, %33
  %477 = call float @dx.op.tertiary.f32(i32 46, float %464, float %29, float %476)  ; FMad(a,b,c)
  %478 = call float @dx.op.tertiary.f32(i32 46, float %450, float %25, float %477)  ; FMad(a,b,c)
  %479 = fadd fast float %478, %21
  %480 = fmul fast float %463, %32
  %481 = call float @dx.op.tertiary.f32(i32 46, float %464, float %28, float %480)  ; FMad(a,b,c)
  %482 = call float @dx.op.tertiary.f32(i32 46, float %450, float %24, float %481)  ; FMad(a,b,c)
  %483 = fadd fast float %482, %20
  %484 = fdiv fast float %483, %468
  %485 = fdiv fast float %479, %468
  %486 = fdiv fast float %475, %468
  %487 = fsub fast float %484, %17
  %488 = fsub fast float %485, %18
  %489 = fsub fast float %486, %19
  %490 = fmul fast float %487, %487
  %491 = fmul fast float %488, %488
  %492 = fadd fast float %491, %490
  %493 = fmul fast float %489, %489
  %494 = fadd fast float %492, %493
  %495 = call float @dx.op.unary.f32(i32 24, float %494)  ; Sqrt(value)
  %496 = fsub fast float %495, %9
  %497 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %496)  ; FMax(a,b)
  %498 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %498, label %499, label %522

; <label>:499                                     ; preds = %471
  %500 = call float @dx.op.unary.f32(i32 6, float %488)  ; FAbs(value)
  %501 = fmul fast float %500, %11
  %502 = fcmp fast olt float %501, 0x3F50624DE0000000
  br i1 %502, label %503, label %506

; <label>:503                                     ; preds = %499
  %504 = fmul fast float %501, 5.000000e-01
  %505 = fsub fast float 1.000000e+00, %504
  br label %511

; <label>:506                                     ; preds = %499
  %507 = fmul fast float %501, 0xBFF7154760000000
  %508 = call float @dx.op.unary.f32(i32 21, float %507)  ; Exp(value)
  %509 = fsub fast float 1.000000e+00, %508
  %510 = fdiv fast float %509, %501
  br label %511

; <label>:511                                     ; preds = %506, %503
  %512 = phi float [ %505, %503 ], [ %510, %506 ]
  %513 = call float @dx.op.binary.f32(i32 36, float %485, float %18)  ; FMin(a,b)
  %514 = fsub fast float %513, %10
  %515 = fmul fast float %11, %514
  %516 = fsub fast float -0.000000e+00, %515
  %517 = call float @dx.op.binary.f32(i32 35, float %516, float -4.000000e+01)  ; FMax(a,b)
  %518 = call float @dx.op.binary.f32(i32 36, float %517, float 5.000000e+00)  ; FMin(a,b)
  %519 = fmul fast float %518, 0x3FF7154760000000
  %520 = call float @dx.op.unary.f32(i32 21, float %519)  ; Exp(value)
  %521 = fmul fast float %520, %512
  br label %522

; <label>:522                                     ; preds = %511, %471
  %523 = phi float [ %521, %511 ], [ 1.000000e+00, %471 ]
  %524 = fmul fast float %497, %16
  %525 = fmul fast float %524, %523
  %526 = fcmp fast ole float %495, %9
  %527 = fcmp fast olt float %495, 0x3F1A36E2E0000000
  %528 = or i1 %526, %527
  br i1 %528, label %575, label %529

; <label>:529                                     ; preds = %522
  %530 = fdiv fast float %9, %495
  %531 = fmul fast float %530, %487
  %532 = fmul fast float %530, %488
  %533 = fmul fast float %530, %489
  %534 = fadd fast float %531, %17
  %535 = fadd fast float %532, %18
  %536 = fadd fast float %533, %19
  %537 = fadd fast float %534, -9.000000e+02
  %538 = fadd fast float %535, -1.500000e+01
  %539 = fadd fast float %536, -7.500000e+02
  %540 = fmul fast float %537, 0x3F62345680000000
  %541 = fmul fast float %538, 0x3F62345680000000
  %542 = fmul fast float %539, 0x3F62345680000000
  %543 = call float @dx.op.dot3.f32(i32 55, float %540, float %541, float %542, float %540, float %541, float %542)  ; Dot3(ax,ay,az,bx,by,bz)
  %544 = fsub fast float 1.000000e+00, %543
  %545 = call float @dx.op.unary.f32(i32 7, float %544)  ; Saturate(value)
  %546 = fmul fast float %545, %545
  %547 = fadd fast float %534, %484
  %548 = fadd fast float %535, %485
  %549 = fadd fast float %536, %486
  %550 = fmul fast float %547, 0x3F52345680000000
  %551 = fadd fast float %550, -2.000000e+00
  %552 = fmul fast float %548, 0x3F52345680000000
  %553 = fadd fast float %552, 0xBFA1111120000000
  %554 = fmul fast float %549, 0x3F52345680000000
  %555 = fadd fast float %554, 0xBFFAAAAAC0000000
  %556 = call float @dx.op.dot3.f32(i32 55, float %551, float %553, float %555, float %551, float %553, float %555)  ; Dot3(ax,ay,az,bx,by,bz)
  %557 = fsub fast float 1.000000e+00, %556
  %558 = call float @dx.op.unary.f32(i32 7, float %557)  ; Saturate(value)
  %559 = fmul fast float %558, %558
  %560 = fmul fast float %559, 4.000000e+00
  %561 = fadd fast float %560, %546
  %562 = fadd fast float %484, -9.000000e+02
  %563 = fadd fast float %485, -1.500000e+01
  %564 = fadd fast float %486, -7.500000e+02
  %565 = fmul fast float %562, 0x3F62345680000000
  %566 = fmul fast float %563, 0x3F62345680000000
  %567 = fmul fast float %564, 0x3F62345680000000
  %568 = call float @dx.op.dot3.f32(i32 55, float %565, float %566, float %567, float %565, float %566, float %567)  ; Dot3(ax,ay,az,bx,by,bz)
  %569 = fsub fast float 1.000000e+00, %568
  %570 = call float @dx.op.unary.f32(i32 7, float %569)  ; Saturate(value)
  %571 = fmul fast float %570, %570
  %572 = fadd fast float %561, %571
  %573 = fmul fast float %496, 0x3F25D867E0000000
  %574 = fmul fast float %573, %572
  br label %575

; <label>:575                                     ; preds = %529, %522
  %576 = phi float [ %574, %529 ], [ 0.000000e+00, %522 ]
  %577 = fadd fast float %576, %525
  %578 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %577)  ; FMin(a,b)
  %579 = fmul fast float %578, 0xBFF7154760000000
  %580 = call float @dx.op.unary.f32(i32 21, float %579)  ; Exp(value)
  %581 = fsub fast float 1.000000e+00, %580
  %582 = call float @dx.op.binary.f32(i32 36, float %12, float %581)  ; FMin(a,b)
  %583 = fsub fast float %13, %409
  %584 = fsub fast float %14, %410
  %585 = fsub fast float %15, %411
  %586 = fmul fast float %582, %583
  %587 = fmul fast float %582, %584
  %588 = fmul fast float %582, %585
  %589 = fadd fast float %586, %409
  %590 = fadd fast float %587, %410
  %591 = fadd fast float %588, %411
  br label %592

; <label>:592                                     ; preds = %575, %454, %448
  %593 = phi float [ %589, %575 ], [ %409, %454 ], [ %409, %448 ]
  %594 = phi float [ %590, %575 ], [ %410, %454 ], [ %410, %448 ]
  %595 = phi float [ %591, %575 ], [ %411, %454 ], [ %411, %448 ]
  %596 = fadd fast float %5, 1.000000e+00
  %597 = fadd fast float %6, 1.000000e+00
  %598 = fsub fast float 1.000000e+00, %5
  %599 = fmul fast float %36, %596
  %600 = fmul fast float %36, %597
  %601 = fmul fast float %36, %598
  %602 = fmul fast float %599, %593
  %603 = fmul fast float %600, %594
  %604 = fmul fast float %601, %595
  %605 = fcmp fast ult float %37, 5.000000e-01
  br i1 %605, label %631, label %606

; <label>:606                                     ; preds = %592
  %607 = fmul fast float %602, 0x4004147AE0000000
  %608 = fmul fast float %603, 0x4004147AE0000000
  %609 = fmul fast float %604, 0x4004147AE0000000
  %610 = fadd fast float %607, 0x3F9EB851E0000000
  %611 = fadd fast float %608, 0x3F9EB851E0000000
  %612 = fadd fast float %609, 0x3F9EB851E0000000
  %613 = fmul fast float %610, %602
  %614 = fmul fast float %611, %603
  %615 = fmul fast float %612, %604
  %616 = fmul fast float %602, 0x400370A3E0000000
  %617 = fmul fast float %603, 0x400370A3E0000000
  %618 = fmul fast float %604, 0x400370A3E0000000
  %619 = fadd fast float %616, 0x3FE2E147A0000000
  %620 = fadd fast float %617, 0x3FE2E147A0000000
  %621 = fadd fast float %618, 0x3FE2E147A0000000
  %622 = fmul fast float %619, %602
  %623 = fmul fast float %620, %603
  %624 = fmul fast float %621, %604
  %625 = fadd fast float %622, 0x3FC1EB8520000000
  %626 = fadd fast float %623, 0x3FC1EB8520000000
  %627 = fadd fast float %624, 0x3FC1EB8520000000
  %628 = fdiv fast float %613, %625
  %629 = fdiv fast float %614, %626
  %630 = fdiv fast float %615, %627
  br label %631

; <label>:631                                     ; preds = %606, %592
  %632 = phi float [ %628, %606 ], [ %602, %592 ]
  %633 = phi float [ %629, %606 ], [ %603, %592 ]
  %634 = phi float [ %630, %606 ], [ %604, %592 ]
  %635 = call float @dx.op.unary.f32(i32 7, float %632)  ; Saturate(value)
  %636 = call float @dx.op.unary.f32(i32 7, float %633)  ; Saturate(value)
  %637 = call float @dx.op.unary.f32(i32 7, float %634)  ; Saturate(value)
  %638 = call float @dx.op.dot3.f32(i32 55, float %635, float %636, float %637, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %639 = fsub fast float %635, %638
  %640 = fsub fast float %636, %638
  %641 = fsub fast float %637, %638
  %642 = fmul fast float %639, %8
  %643 = fmul fast float %640, %8
  %644 = fmul fast float %641, %8
  %645 = fadd fast float %642, %638
  %646 = fadd fast float %643, %638
  %647 = fadd fast float %644, %638
  %648 = call float @dx.op.unary.f32(i32 7, float %645)  ; Saturate(value)
  %649 = call float @dx.op.unary.f32(i32 7, float %646)  ; Saturate(value)
  %650 = call float @dx.op.unary.f32(i32 7, float %647)  ; Saturate(value)
  %651 = fadd fast float %648, 0xBFC70A3D80000000
  %652 = fadd fast float %649, 0xBFC70A3D80000000
  %653 = fadd fast float %650, 0xBFC70A3D80000000
  %654 = fmul fast float %651, %7
  %655 = fmul fast float %652, %7
  %656 = fmul fast float %653, %7
  %657 = fadd fast float %654, 0x3FC70A3D80000000
  %658 = fadd fast float %655, 0x3FC70A3D80000000
  %659 = fadd fast float %656, 0x3FC70A3D80000000
  %660 = call float @dx.op.unary.f32(i32 7, float %657)  ; Saturate(value)
  %661 = call float @dx.op.unary.f32(i32 7, float %658)  ; Saturate(value)
  %662 = call float @dx.op.unary.f32(i32 7, float %659)  ; Saturate(value)
  br label %663

; <label>:663                                     ; preds = %631, %414
  %664 = phi float [ %445, %414 ], [ %660, %631 ]
  %665 = phi float [ %446, %414 ], [ %661, %631 ]
  %666 = phi float [ %447, %414 ], [ %662, %631 ]
  %667 = fsub fast float %664, %384
  %668 = fsub fast float %665, %385
  %669 = fsub fast float %666, %386
  %670 = fmul fast float %667, %401
  %671 = fmul fast float %668, %401
  %672 = fmul fast float %669, %401
  %673 = fadd fast float %670, %384
  %674 = fadd fast float %671, %385
  %675 = fadd fast float %672, %386
  br label %676

; <label>:676                                     ; preds = %663, %355
  %677 = phi float [ %673, %663 ], [ %384, %355 ]
  %678 = phi float [ %674, %663 ], [ %385, %355 ]
  %679 = phi float [ %675, %663 ], [ %386, %355 ]
  %680 = add i32 %64, 1
  %681 = call i32 @dx.op.binary.i32(i32 37, i32 %680, i32 0)  ; IMax(a,b)
  %682 = call i32 @dx.op.binary.i32(i32 38, i32 %681, i32 %60)  ; IMin(a,b)
  %683 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %390, i32 %682, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %684 = extractvalue %dx.types.ResRet.f32 %683, 0
  %685 = fsub fast float %684, %82
  %686 = call float @dx.op.unary.f32(i32 6, float %685)  ; FAbs(value)
  %687 = fdiv fast float %686, %396
  %688 = fsub fast float 1.000000e+00, %687
  %689 = call float @dx.op.unary.f32(i32 7, float %688)  ; Saturate(value)
  %690 = fcmp fast ugt float %689, 0.000000e+00
  br i1 %690, label %691, label %964

; <label>:691                                     ; preds = %676
  %692 = call i32 @dx.op.binary.i32(i32 37, i32 %390, i32 0)  ; IMax(a,b)
  %693 = call i32 @dx.op.binary.i32(i32 37, i32 %682, i32 0)  ; IMax(a,b)
  %694 = call i32 @dx.op.binary.i32(i32 38, i32 %692, i32 %59)  ; IMin(a,b)
  %695 = call i32 @dx.op.binary.i32(i32 38, i32 %693, i32 %60)  ; IMin(a,b)
  %696 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %694, i32 %695, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %697 = extractvalue %dx.types.ResRet.f32 %696, 0
  %698 = extractvalue %dx.types.ResRet.f32 %696, 1
  %699 = extractvalue %dx.types.ResRet.f32 %696, 2
  %700 = extractvalue %dx.types.ResRet.f32 %696, 3
  %701 = fcmp fast olt float %700, 0.000000e+00
  br i1 %701, label %702, label %736

; <label>:702                                     ; preds = %691
  %703 = fcmp fast ogt float %697, 0x3FA4B5DCC0000000
  %704 = fcmp fast ogt float %698, 0x3FA4B5DCC0000000
  %705 = fcmp fast ogt float %699, 0x3FA4B5DCC0000000
  %706 = select i1 %703, float 0.000000e+00, float 1.000000e+00
  %707 = select i1 %704, float 0.000000e+00, float 1.000000e+00
  %708 = select i1 %705, float 0.000000e+00, float 1.000000e+00
  %709 = fmul fast float %697, 0x3FB3D07220000000
  %710 = fmul fast float %698, 0x3FB3D07220000000
  %711 = fmul fast float %699, 0x3FB3D07220000000
  %712 = fadd fast float %697, 0x3FAC28F5C0000000
  %713 = fadd fast float %698, 0x3FAC28F5C0000000
  %714 = fadd fast float %699, 0x3FAC28F5C0000000
  %715 = fmul fast float %712, 0x3FEE54EDE0000000
  %716 = fmul fast float %713, 0x3FEE54EDE0000000
  %717 = fmul fast float %714, 0x3FEE54EDE0000000
  %718 = call float @dx.op.unary.f32(i32 23, float %715)  ; Log(value)
  %719 = call float @dx.op.unary.f32(i32 23, float %716)  ; Log(value)
  %720 = call float @dx.op.unary.f32(i32 23, float %717)  ; Log(value)
  %721 = fmul fast float %718, 0x4003333340000000
  %722 = fmul fast float %719, 0x4003333340000000
  %723 = fmul fast float %720, 0x4003333340000000
  %724 = call float @dx.op.unary.f32(i32 21, float %721)  ; Exp(value)
  %725 = call float @dx.op.unary.f32(i32 21, float %722)  ; Exp(value)
  %726 = call float @dx.op.unary.f32(i32 21, float %723)  ; Exp(value)
  %727 = fsub fast float %709, %724
  %728 = fsub fast float %710, %725
  %729 = fsub fast float %711, %726
  %730 = fmul fast float %727, %706
  %731 = fmul fast float %728, %707
  %732 = fmul fast float %729, %708
  %733 = fadd fast float %730, %724
  %734 = fadd fast float %731, %725
  %735 = fadd fast float %732, %726
  br label %951

; <label>:736                                     ; preds = %691
  %737 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %694, i32 %695, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %738 = extractvalue %dx.types.ResRet.f32 %737, 0
  %739 = fcmp fast ogt float %38, 5.000000e-01
  %740 = fcmp fast olt float %738, 1.000000e+00
  %741 = and i1 %739, %740
  br i1 %741, label %742, label %880

; <label>:742                                     ; preds = %736
  %743 = sitofp i32 %694 to float
  %744 = sitofp i32 %695 to float
  %745 = fadd fast float %743, 5.000000e-01
  %746 = fadd fast float %744, 5.000000e-01
  %747 = fdiv fast float %745, %45
  %748 = fdiv fast float %746, %46
  %749 = fmul fast float %747, 2.000000e+00
  %750 = fmul fast float %748, 2.000000e+00
  %751 = fadd fast float %749, -1.000000e+00
  %752 = fsub fast float 1.000000e+00, %750
  %753 = fmul fast float %751, %35
  %754 = call float @dx.op.tertiary.f32(i32 46, float %752, float %31, float %753)  ; FMad(a,b,c)
  %755 = call float @dx.op.tertiary.f32(i32 46, float %738, float %27, float %754)  ; FMad(a,b,c)
  %756 = fadd fast float %755, %23
  %757 = call float @dx.op.unary.f32(i32 6, float %756)  ; FAbs(value)
  %758 = fcmp fast ogt float %757, 0x3EB0C6F7A0000000
  br i1 %758, label %759, label %880

; <label>:759                                     ; preds = %742
  %760 = fmul fast float %751, %34
  %761 = call float @dx.op.tertiary.f32(i32 46, float %752, float %30, float %760)  ; FMad(a,b,c)
  %762 = call float @dx.op.tertiary.f32(i32 46, float %738, float %26, float %761)  ; FMad(a,b,c)
  %763 = fadd fast float %762, %22
  %764 = fmul fast float %751, %33
  %765 = call float @dx.op.tertiary.f32(i32 46, float %752, float %29, float %764)  ; FMad(a,b,c)
  %766 = call float @dx.op.tertiary.f32(i32 46, float %738, float %25, float %765)  ; FMad(a,b,c)
  %767 = fadd fast float %766, %21
  %768 = fmul fast float %751, %32
  %769 = call float @dx.op.tertiary.f32(i32 46, float %752, float %28, float %768)  ; FMad(a,b,c)
  %770 = call float @dx.op.tertiary.f32(i32 46, float %738, float %24, float %769)  ; FMad(a,b,c)
  %771 = fadd fast float %770, %20
  %772 = fdiv fast float %771, %756
  %773 = fdiv fast float %767, %756
  %774 = fdiv fast float %763, %756
  %775 = fsub fast float %772, %17
  %776 = fsub fast float %773, %18
  %777 = fsub fast float %774, %19
  %778 = fmul fast float %775, %775
  %779 = fmul fast float %776, %776
  %780 = fadd fast float %779, %778
  %781 = fmul fast float %777, %777
  %782 = fadd fast float %780, %781
  %783 = call float @dx.op.unary.f32(i32 24, float %782)  ; Sqrt(value)
  %784 = fsub fast float %783, %9
  %785 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %784)  ; FMax(a,b)
  %786 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %786, label %787, label %810

; <label>:787                                     ; preds = %759
  %788 = call float @dx.op.unary.f32(i32 6, float %776)  ; FAbs(value)
  %789 = fmul fast float %788, %11
  %790 = fcmp fast olt float %789, 0x3F50624DE0000000
  br i1 %790, label %791, label %794

; <label>:791                                     ; preds = %787
  %792 = fmul fast float %789, 5.000000e-01
  %793 = fsub fast float 1.000000e+00, %792
  br label %799

; <label>:794                                     ; preds = %787
  %795 = fmul fast float %789, 0xBFF7154760000000
  %796 = call float @dx.op.unary.f32(i32 21, float %795)  ; Exp(value)
  %797 = fsub fast float 1.000000e+00, %796
  %798 = fdiv fast float %797, %789
  br label %799

; <label>:799                                     ; preds = %794, %791
  %800 = phi float [ %793, %791 ], [ %798, %794 ]
  %801 = call float @dx.op.binary.f32(i32 36, float %773, float %18)  ; FMin(a,b)
  %802 = fsub fast float %801, %10
  %803 = fmul fast float %11, %802
  %804 = fsub fast float -0.000000e+00, %803
  %805 = call float @dx.op.binary.f32(i32 35, float %804, float -4.000000e+01)  ; FMax(a,b)
  %806 = call float @dx.op.binary.f32(i32 36, float %805, float 5.000000e+00)  ; FMin(a,b)
  %807 = fmul fast float %806, 0x3FF7154760000000
  %808 = call float @dx.op.unary.f32(i32 21, float %807)  ; Exp(value)
  %809 = fmul fast float %808, %800
  br label %810

; <label>:810                                     ; preds = %799, %759
  %811 = phi float [ %809, %799 ], [ 1.000000e+00, %759 ]
  %812 = fmul fast float %785, %16
  %813 = fmul fast float %812, %811
  %814 = fcmp fast ole float %783, %9
  %815 = fcmp fast olt float %783, 0x3F1A36E2E0000000
  %816 = or i1 %814, %815
  br i1 %816, label %863, label %817

; <label>:817                                     ; preds = %810
  %818 = fdiv fast float %9, %783
  %819 = fmul fast float %818, %775
  %820 = fmul fast float %818, %776
  %821 = fmul fast float %818, %777
  %822 = fadd fast float %819, %17
  %823 = fadd fast float %820, %18
  %824 = fadd fast float %821, %19
  %825 = fadd fast float %822, -9.000000e+02
  %826 = fadd fast float %823, -1.500000e+01
  %827 = fadd fast float %824, -7.500000e+02
  %828 = fmul fast float %825, 0x3F62345680000000
  %829 = fmul fast float %826, 0x3F62345680000000
  %830 = fmul fast float %827, 0x3F62345680000000
  %831 = call float @dx.op.dot3.f32(i32 55, float %828, float %829, float %830, float %828, float %829, float %830)  ; Dot3(ax,ay,az,bx,by,bz)
  %832 = fsub fast float 1.000000e+00, %831
  %833 = call float @dx.op.unary.f32(i32 7, float %832)  ; Saturate(value)
  %834 = fmul fast float %833, %833
  %835 = fadd fast float %822, %772
  %836 = fadd fast float %823, %773
  %837 = fadd fast float %824, %774
  %838 = fmul fast float %835, 0x3F52345680000000
  %839 = fadd fast float %838, -2.000000e+00
  %840 = fmul fast float %836, 0x3F52345680000000
  %841 = fadd fast float %840, 0xBFA1111120000000
  %842 = fmul fast float %837, 0x3F52345680000000
  %843 = fadd fast float %842, 0xBFFAAAAAC0000000
  %844 = call float @dx.op.dot3.f32(i32 55, float %839, float %841, float %843, float %839, float %841, float %843)  ; Dot3(ax,ay,az,bx,by,bz)
  %845 = fsub fast float 1.000000e+00, %844
  %846 = call float @dx.op.unary.f32(i32 7, float %845)  ; Saturate(value)
  %847 = fmul fast float %846, %846
  %848 = fmul fast float %847, 4.000000e+00
  %849 = fadd fast float %848, %834
  %850 = fadd fast float %772, -9.000000e+02
  %851 = fadd fast float %773, -1.500000e+01
  %852 = fadd fast float %774, -7.500000e+02
  %853 = fmul fast float %850, 0x3F62345680000000
  %854 = fmul fast float %851, 0x3F62345680000000
  %855 = fmul fast float %852, 0x3F62345680000000
  %856 = call float @dx.op.dot3.f32(i32 55, float %853, float %854, float %855, float %853, float %854, float %855)  ; Dot3(ax,ay,az,bx,by,bz)
  %857 = fsub fast float 1.000000e+00, %856
  %858 = call float @dx.op.unary.f32(i32 7, float %857)  ; Saturate(value)
  %859 = fmul fast float %858, %858
  %860 = fadd fast float %849, %859
  %861 = fmul fast float %784, 0x3F25D867E0000000
  %862 = fmul fast float %861, %860
  br label %863

; <label>:863                                     ; preds = %817, %810
  %864 = phi float [ %862, %817 ], [ 0.000000e+00, %810 ]
  %865 = fadd fast float %864, %813
  %866 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %865)  ; FMin(a,b)
  %867 = fmul fast float %866, 0xBFF7154760000000
  %868 = call float @dx.op.unary.f32(i32 21, float %867)  ; Exp(value)
  %869 = fsub fast float 1.000000e+00, %868
  %870 = call float @dx.op.binary.f32(i32 36, float %12, float %869)  ; FMin(a,b)
  %871 = fsub fast float %13, %697
  %872 = fsub fast float %14, %698
  %873 = fsub fast float %15, %699
  %874 = fmul fast float %870, %871
  %875 = fmul fast float %870, %872
  %876 = fmul fast float %870, %873
  %877 = fadd fast float %874, %697
  %878 = fadd fast float %875, %698
  %879 = fadd fast float %876, %699
  br label %880

; <label>:880                                     ; preds = %863, %742, %736
  %881 = phi float [ %877, %863 ], [ %697, %742 ], [ %697, %736 ]
  %882 = phi float [ %878, %863 ], [ %698, %742 ], [ %698, %736 ]
  %883 = phi float [ %879, %863 ], [ %699, %742 ], [ %699, %736 ]
  %884 = fadd fast float %5, 1.000000e+00
  %885 = fadd fast float %6, 1.000000e+00
  %886 = fsub fast float 1.000000e+00, %5
  %887 = fmul fast float %36, %884
  %888 = fmul fast float %36, %885
  %889 = fmul fast float %36, %886
  %890 = fmul fast float %887, %881
  %891 = fmul fast float %888, %882
  %892 = fmul fast float %889, %883
  %893 = fcmp fast ult float %37, 5.000000e-01
  br i1 %893, label %919, label %894

; <label>:894                                     ; preds = %880
  %895 = fmul fast float %890, 0x4004147AE0000000
  %896 = fmul fast float %891, 0x4004147AE0000000
  %897 = fmul fast float %892, 0x4004147AE0000000
  %898 = fadd fast float %895, 0x3F9EB851E0000000
  %899 = fadd fast float %896, 0x3F9EB851E0000000
  %900 = fadd fast float %897, 0x3F9EB851E0000000
  %901 = fmul fast float %898, %890
  %902 = fmul fast float %899, %891
  %903 = fmul fast float %900, %892
  %904 = fmul fast float %890, 0x400370A3E0000000
  %905 = fmul fast float %891, 0x400370A3E0000000
  %906 = fmul fast float %892, 0x400370A3E0000000
  %907 = fadd fast float %904, 0x3FE2E147A0000000
  %908 = fadd fast float %905, 0x3FE2E147A0000000
  %909 = fadd fast float %906, 0x3FE2E147A0000000
  %910 = fmul fast float %907, %890
  %911 = fmul fast float %908, %891
  %912 = fmul fast float %909, %892
  %913 = fadd fast float %910, 0x3FC1EB8520000000
  %914 = fadd fast float %911, 0x3FC1EB8520000000
  %915 = fadd fast float %912, 0x3FC1EB8520000000
  %916 = fdiv fast float %901, %913
  %917 = fdiv fast float %902, %914
  %918 = fdiv fast float %903, %915
  br label %919

; <label>:919                                     ; preds = %894, %880
  %920 = phi float [ %916, %894 ], [ %890, %880 ]
  %921 = phi float [ %917, %894 ], [ %891, %880 ]
  %922 = phi float [ %918, %894 ], [ %892, %880 ]
  %923 = call float @dx.op.unary.f32(i32 7, float %920)  ; Saturate(value)
  %924 = call float @dx.op.unary.f32(i32 7, float %921)  ; Saturate(value)
  %925 = call float @dx.op.unary.f32(i32 7, float %922)  ; Saturate(value)
  %926 = call float @dx.op.dot3.f32(i32 55, float %923, float %924, float %925, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %927 = fsub fast float %923, %926
  %928 = fsub fast float %924, %926
  %929 = fsub fast float %925, %926
  %930 = fmul fast float %927, %8
  %931 = fmul fast float %928, %8
  %932 = fmul fast float %929, %8
  %933 = fadd fast float %930, %926
  %934 = fadd fast float %931, %926
  %935 = fadd fast float %932, %926
  %936 = call float @dx.op.unary.f32(i32 7, float %933)  ; Saturate(value)
  %937 = call float @dx.op.unary.f32(i32 7, float %934)  ; Saturate(value)
  %938 = call float @dx.op.unary.f32(i32 7, float %935)  ; Saturate(value)
  %939 = fadd fast float %936, 0xBFC70A3D80000000
  %940 = fadd fast float %937, 0xBFC70A3D80000000
  %941 = fadd fast float %938, 0xBFC70A3D80000000
  %942 = fmul fast float %939, %7
  %943 = fmul fast float %940, %7
  %944 = fmul fast float %941, %7
  %945 = fadd fast float %942, 0x3FC70A3D80000000
  %946 = fadd fast float %943, 0x3FC70A3D80000000
  %947 = fadd fast float %944, 0x3FC70A3D80000000
  %948 = call float @dx.op.unary.f32(i32 7, float %945)  ; Saturate(value)
  %949 = call float @dx.op.unary.f32(i32 7, float %946)  ; Saturate(value)
  %950 = call float @dx.op.unary.f32(i32 7, float %947)  ; Saturate(value)
  br label %951

; <label>:951                                     ; preds = %919, %702
  %952 = phi float [ %733, %702 ], [ %948, %919 ]
  %953 = phi float [ %734, %702 ], [ %949, %919 ]
  %954 = phi float [ %735, %702 ], [ %950, %919 ]
  %955 = fsub fast float %952, %384
  %956 = fsub fast float %953, %385
  %957 = fsub fast float %954, %386
  %958 = fmul fast float %955, %689
  %959 = fmul fast float %956, %689
  %960 = fmul fast float %957, %689
  %961 = fadd fast float %958, %384
  %962 = fadd fast float %959, %385
  %963 = fadd fast float %960, %386
  br label %964

; <label>:964                                     ; preds = %951, %676
  %965 = phi float [ %961, %951 ], [ %384, %676 ]
  %966 = phi float [ %962, %951 ], [ %385, %676 ]
  %967 = phi float [ %963, %951 ], [ %386, %676 ]
  %968 = add i32 %63, -1
  %969 = call i32 @dx.op.binary.i32(i32 37, i32 %968, i32 0)  ; IMax(a,b)
  %970 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %971 = call i32 @dx.op.binary.i32(i32 38, i32 %969, i32 %59)  ; IMin(a,b)
  %972 = call i32 @dx.op.binary.i32(i32 38, i32 %970, i32 %60)  ; IMin(a,b)
  %973 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %971, i32 %972, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %974 = extractvalue %dx.types.ResRet.f32 %973, 0
  %975 = fsub fast float %974, %82
  %976 = call float @dx.op.unary.f32(i32 6, float %975)  ; FAbs(value)
  %977 = fdiv fast float %976, %396
  %978 = fsub fast float 1.000000e+00, %977
  %979 = call float @dx.op.unary.f32(i32 7, float %978)  ; Saturate(value)
  %980 = fcmp fast ugt float %979, 0.000000e+00
  br i1 %980, label %981, label %1254

; <label>:981                                     ; preds = %964
  %982 = call i32 @dx.op.binary.i32(i32 37, i32 %971, i32 0)  ; IMax(a,b)
  %983 = call i32 @dx.op.binary.i32(i32 37, i32 %972, i32 0)  ; IMax(a,b)
  %984 = call i32 @dx.op.binary.i32(i32 38, i32 %982, i32 %59)  ; IMin(a,b)
  %985 = call i32 @dx.op.binary.i32(i32 38, i32 %983, i32 %60)  ; IMin(a,b)
  %986 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %984, i32 %985, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %987 = extractvalue %dx.types.ResRet.f32 %986, 0
  %988 = extractvalue %dx.types.ResRet.f32 %986, 1
  %989 = extractvalue %dx.types.ResRet.f32 %986, 2
  %990 = extractvalue %dx.types.ResRet.f32 %986, 3
  %991 = fcmp fast olt float %990, 0.000000e+00
  br i1 %991, label %992, label %1026

; <label>:992                                     ; preds = %981
  %993 = fcmp fast ogt float %987, 0x3FA4B5DCC0000000
  %994 = fcmp fast ogt float %988, 0x3FA4B5DCC0000000
  %995 = fcmp fast ogt float %989, 0x3FA4B5DCC0000000
  %996 = select i1 %993, float 0.000000e+00, float 1.000000e+00
  %997 = select i1 %994, float 0.000000e+00, float 1.000000e+00
  %998 = select i1 %995, float 0.000000e+00, float 1.000000e+00
  %999 = fmul fast float %987, 0x3FB3D07220000000
  %1000 = fmul fast float %988, 0x3FB3D07220000000
  %1001 = fmul fast float %989, 0x3FB3D07220000000
  %1002 = fadd fast float %987, 0x3FAC28F5C0000000
  %1003 = fadd fast float %988, 0x3FAC28F5C0000000
  %1004 = fadd fast float %989, 0x3FAC28F5C0000000
  %1005 = fmul fast float %1002, 0x3FEE54EDE0000000
  %1006 = fmul fast float %1003, 0x3FEE54EDE0000000
  %1007 = fmul fast float %1004, 0x3FEE54EDE0000000
  %1008 = call float @dx.op.unary.f32(i32 23, float %1005)  ; Log(value)
  %1009 = call float @dx.op.unary.f32(i32 23, float %1006)  ; Log(value)
  %1010 = call float @dx.op.unary.f32(i32 23, float %1007)  ; Log(value)
  %1011 = fmul fast float %1008, 0x4003333340000000
  %1012 = fmul fast float %1009, 0x4003333340000000
  %1013 = fmul fast float %1010, 0x4003333340000000
  %1014 = call float @dx.op.unary.f32(i32 21, float %1011)  ; Exp(value)
  %1015 = call float @dx.op.unary.f32(i32 21, float %1012)  ; Exp(value)
  %1016 = call float @dx.op.unary.f32(i32 21, float %1013)  ; Exp(value)
  %1017 = fsub fast float %999, %1014
  %1018 = fsub fast float %1000, %1015
  %1019 = fsub fast float %1001, %1016
  %1020 = fmul fast float %1017, %996
  %1021 = fmul fast float %1018, %997
  %1022 = fmul fast float %1019, %998
  %1023 = fadd fast float %1020, %1014
  %1024 = fadd fast float %1021, %1015
  %1025 = fadd fast float %1022, %1016
  br label %1241

; <label>:1026                                    ; preds = %981
  %1027 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %984, i32 %985, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1028 = extractvalue %dx.types.ResRet.f32 %1027, 0
  %1029 = fcmp fast ogt float %38, 5.000000e-01
  %1030 = fcmp fast olt float %1028, 1.000000e+00
  %1031 = and i1 %1029, %1030
  br i1 %1031, label %1032, label %1170

; <label>:1032                                    ; preds = %1026
  %1033 = sitofp i32 %984 to float
  %1034 = sitofp i32 %985 to float
  %1035 = fadd fast float %1033, 5.000000e-01
  %1036 = fadd fast float %1034, 5.000000e-01
  %1037 = fdiv fast float %1035, %45
  %1038 = fdiv fast float %1036, %46
  %1039 = fmul fast float %1037, 2.000000e+00
  %1040 = fmul fast float %1038, 2.000000e+00
  %1041 = fadd fast float %1039, -1.000000e+00
  %1042 = fsub fast float 1.000000e+00, %1040
  %1043 = fmul fast float %1041, %35
  %1044 = call float @dx.op.tertiary.f32(i32 46, float %1042, float %31, float %1043)  ; FMad(a,b,c)
  %1045 = call float @dx.op.tertiary.f32(i32 46, float %1028, float %27, float %1044)  ; FMad(a,b,c)
  %1046 = fadd fast float %1045, %23
  %1047 = call float @dx.op.unary.f32(i32 6, float %1046)  ; FAbs(value)
  %1048 = fcmp fast ogt float %1047, 0x3EB0C6F7A0000000
  br i1 %1048, label %1049, label %1170

; <label>:1049                                    ; preds = %1032
  %1050 = fmul fast float %1041, %34
  %1051 = call float @dx.op.tertiary.f32(i32 46, float %1042, float %30, float %1050)  ; FMad(a,b,c)
  %1052 = call float @dx.op.tertiary.f32(i32 46, float %1028, float %26, float %1051)  ; FMad(a,b,c)
  %1053 = fadd fast float %1052, %22
  %1054 = fmul fast float %1041, %33
  %1055 = call float @dx.op.tertiary.f32(i32 46, float %1042, float %29, float %1054)  ; FMad(a,b,c)
  %1056 = call float @dx.op.tertiary.f32(i32 46, float %1028, float %25, float %1055)  ; FMad(a,b,c)
  %1057 = fadd fast float %1056, %21
  %1058 = fmul fast float %1041, %32
  %1059 = call float @dx.op.tertiary.f32(i32 46, float %1042, float %28, float %1058)  ; FMad(a,b,c)
  %1060 = call float @dx.op.tertiary.f32(i32 46, float %1028, float %24, float %1059)  ; FMad(a,b,c)
  %1061 = fadd fast float %1060, %20
  %1062 = fdiv fast float %1061, %1046
  %1063 = fdiv fast float %1057, %1046
  %1064 = fdiv fast float %1053, %1046
  %1065 = fsub fast float %1062, %17
  %1066 = fsub fast float %1063, %18
  %1067 = fsub fast float %1064, %19
  %1068 = fmul fast float %1065, %1065
  %1069 = fmul fast float %1066, %1066
  %1070 = fadd fast float %1069, %1068
  %1071 = fmul fast float %1067, %1067
  %1072 = fadd fast float %1070, %1071
  %1073 = call float @dx.op.unary.f32(i32 24, float %1072)  ; Sqrt(value)
  %1074 = fsub fast float %1073, %9
  %1075 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1074)  ; FMax(a,b)
  %1076 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1076, label %1077, label %1100

; <label>:1077                                    ; preds = %1049
  %1078 = call float @dx.op.unary.f32(i32 6, float %1066)  ; FAbs(value)
  %1079 = fmul fast float %1078, %11
  %1080 = fcmp fast olt float %1079, 0x3F50624DE0000000
  br i1 %1080, label %1081, label %1084

; <label>:1081                                    ; preds = %1077
  %1082 = fmul fast float %1079, 5.000000e-01
  %1083 = fsub fast float 1.000000e+00, %1082
  br label %1089

; <label>:1084                                    ; preds = %1077
  %1085 = fmul fast float %1079, 0xBFF7154760000000
  %1086 = call float @dx.op.unary.f32(i32 21, float %1085)  ; Exp(value)
  %1087 = fsub fast float 1.000000e+00, %1086
  %1088 = fdiv fast float %1087, %1079
  br label %1089

; <label>:1089                                    ; preds = %1084, %1081
  %1090 = phi float [ %1083, %1081 ], [ %1088, %1084 ]
  %1091 = call float @dx.op.binary.f32(i32 36, float %1063, float %18)  ; FMin(a,b)
  %1092 = fsub fast float %1091, %10
  %1093 = fmul fast float %11, %1092
  %1094 = fsub fast float -0.000000e+00, %1093
  %1095 = call float @dx.op.binary.f32(i32 35, float %1094, float -4.000000e+01)  ; FMax(a,b)
  %1096 = call float @dx.op.binary.f32(i32 36, float %1095, float 5.000000e+00)  ; FMin(a,b)
  %1097 = fmul fast float %1096, 0x3FF7154760000000
  %1098 = call float @dx.op.unary.f32(i32 21, float %1097)  ; Exp(value)
  %1099 = fmul fast float %1098, %1090
  br label %1100

; <label>:1100                                    ; preds = %1089, %1049
  %1101 = phi float [ %1099, %1089 ], [ 1.000000e+00, %1049 ]
  %1102 = fmul fast float %1075, %16
  %1103 = fmul fast float %1102, %1101
  %1104 = fcmp fast ole float %1073, %9
  %1105 = fcmp fast olt float %1073, 0x3F1A36E2E0000000
  %1106 = or i1 %1104, %1105
  br i1 %1106, label %1153, label %1107

; <label>:1107                                    ; preds = %1100
  %1108 = fdiv fast float %9, %1073
  %1109 = fmul fast float %1108, %1065
  %1110 = fmul fast float %1108, %1066
  %1111 = fmul fast float %1108, %1067
  %1112 = fadd fast float %1109, %17
  %1113 = fadd fast float %1110, %18
  %1114 = fadd fast float %1111, %19
  %1115 = fadd fast float %1112, -9.000000e+02
  %1116 = fadd fast float %1113, -1.500000e+01
  %1117 = fadd fast float %1114, -7.500000e+02
  %1118 = fmul fast float %1115, 0x3F62345680000000
  %1119 = fmul fast float %1116, 0x3F62345680000000
  %1120 = fmul fast float %1117, 0x3F62345680000000
  %1121 = call float @dx.op.dot3.f32(i32 55, float %1118, float %1119, float %1120, float %1118, float %1119, float %1120)  ; Dot3(ax,ay,az,bx,by,bz)
  %1122 = fsub fast float 1.000000e+00, %1121
  %1123 = call float @dx.op.unary.f32(i32 7, float %1122)  ; Saturate(value)
  %1124 = fmul fast float %1123, %1123
  %1125 = fadd fast float %1112, %1062
  %1126 = fadd fast float %1113, %1063
  %1127 = fadd fast float %1114, %1064
  %1128 = fmul fast float %1125, 0x3F52345680000000
  %1129 = fadd fast float %1128, -2.000000e+00
  %1130 = fmul fast float %1126, 0x3F52345680000000
  %1131 = fadd fast float %1130, 0xBFA1111120000000
  %1132 = fmul fast float %1127, 0x3F52345680000000
  %1133 = fadd fast float %1132, 0xBFFAAAAAC0000000
  %1134 = call float @dx.op.dot3.f32(i32 55, float %1129, float %1131, float %1133, float %1129, float %1131, float %1133)  ; Dot3(ax,ay,az,bx,by,bz)
  %1135 = fsub fast float 1.000000e+00, %1134
  %1136 = call float @dx.op.unary.f32(i32 7, float %1135)  ; Saturate(value)
  %1137 = fmul fast float %1136, %1136
  %1138 = fmul fast float %1137, 4.000000e+00
  %1139 = fadd fast float %1138, %1124
  %1140 = fadd fast float %1062, -9.000000e+02
  %1141 = fadd fast float %1063, -1.500000e+01
  %1142 = fadd fast float %1064, -7.500000e+02
  %1143 = fmul fast float %1140, 0x3F62345680000000
  %1144 = fmul fast float %1141, 0x3F62345680000000
  %1145 = fmul fast float %1142, 0x3F62345680000000
  %1146 = call float @dx.op.dot3.f32(i32 55, float %1143, float %1144, float %1145, float %1143, float %1144, float %1145)  ; Dot3(ax,ay,az,bx,by,bz)
  %1147 = fsub fast float 1.000000e+00, %1146
  %1148 = call float @dx.op.unary.f32(i32 7, float %1147)  ; Saturate(value)
  %1149 = fmul fast float %1148, %1148
  %1150 = fadd fast float %1139, %1149
  %1151 = fmul fast float %1074, 0x3F25D867E0000000
  %1152 = fmul fast float %1151, %1150
  br label %1153

; <label>:1153                                    ; preds = %1107, %1100
  %1154 = phi float [ %1152, %1107 ], [ 0.000000e+00, %1100 ]
  %1155 = fadd fast float %1154, %1103
  %1156 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1155)  ; FMin(a,b)
  %1157 = fmul fast float %1156, 0xBFF7154760000000
  %1158 = call float @dx.op.unary.f32(i32 21, float %1157)  ; Exp(value)
  %1159 = fsub fast float 1.000000e+00, %1158
  %1160 = call float @dx.op.binary.f32(i32 36, float %12, float %1159)  ; FMin(a,b)
  %1161 = fsub fast float %13, %987
  %1162 = fsub fast float %14, %988
  %1163 = fsub fast float %15, %989
  %1164 = fmul fast float %1160, %1161
  %1165 = fmul fast float %1160, %1162
  %1166 = fmul fast float %1160, %1163
  %1167 = fadd fast float %1164, %987
  %1168 = fadd fast float %1165, %988
  %1169 = fadd fast float %1166, %989
  br label %1170

; <label>:1170                                    ; preds = %1153, %1032, %1026
  %1171 = phi float [ %1167, %1153 ], [ %987, %1032 ], [ %987, %1026 ]
  %1172 = phi float [ %1168, %1153 ], [ %988, %1032 ], [ %988, %1026 ]
  %1173 = phi float [ %1169, %1153 ], [ %989, %1032 ], [ %989, %1026 ]
  %1174 = fadd fast float %5, 1.000000e+00
  %1175 = fadd fast float %6, 1.000000e+00
  %1176 = fsub fast float 1.000000e+00, %5
  %1177 = fmul fast float %36, %1174
  %1178 = fmul fast float %36, %1175
  %1179 = fmul fast float %36, %1176
  %1180 = fmul fast float %1177, %1171
  %1181 = fmul fast float %1178, %1172
  %1182 = fmul fast float %1179, %1173
  %1183 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1183, label %1209, label %1184

; <label>:1184                                    ; preds = %1170
  %1185 = fmul fast float %1180, 0x4004147AE0000000
  %1186 = fmul fast float %1181, 0x4004147AE0000000
  %1187 = fmul fast float %1182, 0x4004147AE0000000
  %1188 = fadd fast float %1185, 0x3F9EB851E0000000
  %1189 = fadd fast float %1186, 0x3F9EB851E0000000
  %1190 = fadd fast float %1187, 0x3F9EB851E0000000
  %1191 = fmul fast float %1188, %1180
  %1192 = fmul fast float %1189, %1181
  %1193 = fmul fast float %1190, %1182
  %1194 = fmul fast float %1180, 0x400370A3E0000000
  %1195 = fmul fast float %1181, 0x400370A3E0000000
  %1196 = fmul fast float %1182, 0x400370A3E0000000
  %1197 = fadd fast float %1194, 0x3FE2E147A0000000
  %1198 = fadd fast float %1195, 0x3FE2E147A0000000
  %1199 = fadd fast float %1196, 0x3FE2E147A0000000
  %1200 = fmul fast float %1197, %1180
  %1201 = fmul fast float %1198, %1181
  %1202 = fmul fast float %1199, %1182
  %1203 = fadd fast float %1200, 0x3FC1EB8520000000
  %1204 = fadd fast float %1201, 0x3FC1EB8520000000
  %1205 = fadd fast float %1202, 0x3FC1EB8520000000
  %1206 = fdiv fast float %1191, %1203
  %1207 = fdiv fast float %1192, %1204
  %1208 = fdiv fast float %1193, %1205
  br label %1209

; <label>:1209                                    ; preds = %1184, %1170
  %1210 = phi float [ %1206, %1184 ], [ %1180, %1170 ]
  %1211 = phi float [ %1207, %1184 ], [ %1181, %1170 ]
  %1212 = phi float [ %1208, %1184 ], [ %1182, %1170 ]
  %1213 = call float @dx.op.unary.f32(i32 7, float %1210)  ; Saturate(value)
  %1214 = call float @dx.op.unary.f32(i32 7, float %1211)  ; Saturate(value)
  %1215 = call float @dx.op.unary.f32(i32 7, float %1212)  ; Saturate(value)
  %1216 = call float @dx.op.dot3.f32(i32 55, float %1213, float %1214, float %1215, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1217 = fsub fast float %1213, %1216
  %1218 = fsub fast float %1214, %1216
  %1219 = fsub fast float %1215, %1216
  %1220 = fmul fast float %1217, %8
  %1221 = fmul fast float %1218, %8
  %1222 = fmul fast float %1219, %8
  %1223 = fadd fast float %1220, %1216
  %1224 = fadd fast float %1221, %1216
  %1225 = fadd fast float %1222, %1216
  %1226 = call float @dx.op.unary.f32(i32 7, float %1223)  ; Saturate(value)
  %1227 = call float @dx.op.unary.f32(i32 7, float %1224)  ; Saturate(value)
  %1228 = call float @dx.op.unary.f32(i32 7, float %1225)  ; Saturate(value)
  %1229 = fadd fast float %1226, 0xBFC70A3D80000000
  %1230 = fadd fast float %1227, 0xBFC70A3D80000000
  %1231 = fadd fast float %1228, 0xBFC70A3D80000000
  %1232 = fmul fast float %1229, %7
  %1233 = fmul fast float %1230, %7
  %1234 = fmul fast float %1231, %7
  %1235 = fadd fast float %1232, 0x3FC70A3D80000000
  %1236 = fadd fast float %1233, 0x3FC70A3D80000000
  %1237 = fadd fast float %1234, 0x3FC70A3D80000000
  %1238 = call float @dx.op.unary.f32(i32 7, float %1235)  ; Saturate(value)
  %1239 = call float @dx.op.unary.f32(i32 7, float %1236)  ; Saturate(value)
  %1240 = call float @dx.op.unary.f32(i32 7, float %1237)  ; Saturate(value)
  br label %1241

; <label>:1241                                    ; preds = %1209, %992
  %1242 = phi float [ %1023, %992 ], [ %1238, %1209 ]
  %1243 = phi float [ %1024, %992 ], [ %1239, %1209 ]
  %1244 = phi float [ %1025, %992 ], [ %1240, %1209 ]
  %1245 = fsub fast float %1242, %384
  %1246 = fsub fast float %1243, %385
  %1247 = fsub fast float %1244, %386
  %1248 = fmul fast float %1245, %979
  %1249 = fmul fast float %1246, %979
  %1250 = fmul fast float %1247, %979
  %1251 = fadd fast float %1248, %384
  %1252 = fadd fast float %1249, %385
  %1253 = fadd fast float %1250, %386
  br label %1254

; <label>:1254                                    ; preds = %1241, %964
  %1255 = phi float [ %1251, %1241 ], [ %384, %964 ]
  %1256 = phi float [ %1252, %1241 ], [ %385, %964 ]
  %1257 = phi float [ %1253, %1241 ], [ %386, %964 ]
  %1258 = add i32 %63, 1
  %1259 = call i32 @dx.op.binary.i32(i32 37, i32 %1258, i32 0)  ; IMax(a,b)
  %1260 = call i32 @dx.op.binary.i32(i32 38, i32 %1259, i32 %59)  ; IMin(a,b)
  %1261 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1260, i32 %972, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1262 = extractvalue %dx.types.ResRet.f32 %1261, 0
  %1263 = fsub fast float %1262, %82
  %1264 = call float @dx.op.unary.f32(i32 6, float %1263)  ; FAbs(value)
  %1265 = fdiv fast float %1264, %396
  %1266 = fsub fast float 1.000000e+00, %1265
  %1267 = call float @dx.op.unary.f32(i32 7, float %1266)  ; Saturate(value)
  %1268 = fcmp fast ugt float %1267, 0.000000e+00
  br i1 %1268, label %1269, label %1542

; <label>:1269                                    ; preds = %1254
  %1270 = call i32 @dx.op.binary.i32(i32 37, i32 %1260, i32 0)  ; IMax(a,b)
  %1271 = call i32 @dx.op.binary.i32(i32 37, i32 %972, i32 0)  ; IMax(a,b)
  %1272 = call i32 @dx.op.binary.i32(i32 38, i32 %1270, i32 %59)  ; IMin(a,b)
  %1273 = call i32 @dx.op.binary.i32(i32 38, i32 %1271, i32 %60)  ; IMin(a,b)
  %1274 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1272, i32 %1273, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1275 = extractvalue %dx.types.ResRet.f32 %1274, 0
  %1276 = extractvalue %dx.types.ResRet.f32 %1274, 1
  %1277 = extractvalue %dx.types.ResRet.f32 %1274, 2
  %1278 = extractvalue %dx.types.ResRet.f32 %1274, 3
  %1279 = fcmp fast olt float %1278, 0.000000e+00
  br i1 %1279, label %1280, label %1314

; <label>:1280                                    ; preds = %1269
  %1281 = fcmp fast ogt float %1275, 0x3FA4B5DCC0000000
  %1282 = fcmp fast ogt float %1276, 0x3FA4B5DCC0000000
  %1283 = fcmp fast ogt float %1277, 0x3FA4B5DCC0000000
  %1284 = select i1 %1281, float 0.000000e+00, float 1.000000e+00
  %1285 = select i1 %1282, float 0.000000e+00, float 1.000000e+00
  %1286 = select i1 %1283, float 0.000000e+00, float 1.000000e+00
  %1287 = fmul fast float %1275, 0x3FB3D07220000000
  %1288 = fmul fast float %1276, 0x3FB3D07220000000
  %1289 = fmul fast float %1277, 0x3FB3D07220000000
  %1290 = fadd fast float %1275, 0x3FAC28F5C0000000
  %1291 = fadd fast float %1276, 0x3FAC28F5C0000000
  %1292 = fadd fast float %1277, 0x3FAC28F5C0000000
  %1293 = fmul fast float %1290, 0x3FEE54EDE0000000
  %1294 = fmul fast float %1291, 0x3FEE54EDE0000000
  %1295 = fmul fast float %1292, 0x3FEE54EDE0000000
  %1296 = call float @dx.op.unary.f32(i32 23, float %1293)  ; Log(value)
  %1297 = call float @dx.op.unary.f32(i32 23, float %1294)  ; Log(value)
  %1298 = call float @dx.op.unary.f32(i32 23, float %1295)  ; Log(value)
  %1299 = fmul fast float %1296, 0x4003333340000000
  %1300 = fmul fast float %1297, 0x4003333340000000
  %1301 = fmul fast float %1298, 0x4003333340000000
  %1302 = call float @dx.op.unary.f32(i32 21, float %1299)  ; Exp(value)
  %1303 = call float @dx.op.unary.f32(i32 21, float %1300)  ; Exp(value)
  %1304 = call float @dx.op.unary.f32(i32 21, float %1301)  ; Exp(value)
  %1305 = fsub fast float %1287, %1302
  %1306 = fsub fast float %1288, %1303
  %1307 = fsub fast float %1289, %1304
  %1308 = fmul fast float %1305, %1284
  %1309 = fmul fast float %1306, %1285
  %1310 = fmul fast float %1307, %1286
  %1311 = fadd fast float %1308, %1302
  %1312 = fadd fast float %1309, %1303
  %1313 = fadd fast float %1310, %1304
  br label %1529

; <label>:1314                                    ; preds = %1269
  %1315 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1272, i32 %1273, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1316 = extractvalue %dx.types.ResRet.f32 %1315, 0
  %1317 = fcmp fast ogt float %38, 5.000000e-01
  %1318 = fcmp fast olt float %1316, 1.000000e+00
  %1319 = and i1 %1317, %1318
  br i1 %1319, label %1320, label %1458

; <label>:1320                                    ; preds = %1314
  %1321 = sitofp i32 %1272 to float
  %1322 = sitofp i32 %1273 to float
  %1323 = fadd fast float %1321, 5.000000e-01
  %1324 = fadd fast float %1322, 5.000000e-01
  %1325 = fdiv fast float %1323, %45
  %1326 = fdiv fast float %1324, %46
  %1327 = fmul fast float %1325, 2.000000e+00
  %1328 = fmul fast float %1326, 2.000000e+00
  %1329 = fadd fast float %1327, -1.000000e+00
  %1330 = fsub fast float 1.000000e+00, %1328
  %1331 = fmul fast float %1329, %35
  %1332 = call float @dx.op.tertiary.f32(i32 46, float %1330, float %31, float %1331)  ; FMad(a,b,c)
  %1333 = call float @dx.op.tertiary.f32(i32 46, float %1316, float %27, float %1332)  ; FMad(a,b,c)
  %1334 = fadd fast float %1333, %23
  %1335 = call float @dx.op.unary.f32(i32 6, float %1334)  ; FAbs(value)
  %1336 = fcmp fast ogt float %1335, 0x3EB0C6F7A0000000
  br i1 %1336, label %1337, label %1458

; <label>:1337                                    ; preds = %1320
  %1338 = fmul fast float %1329, %34
  %1339 = call float @dx.op.tertiary.f32(i32 46, float %1330, float %30, float %1338)  ; FMad(a,b,c)
  %1340 = call float @dx.op.tertiary.f32(i32 46, float %1316, float %26, float %1339)  ; FMad(a,b,c)
  %1341 = fadd fast float %1340, %22
  %1342 = fmul fast float %1329, %33
  %1343 = call float @dx.op.tertiary.f32(i32 46, float %1330, float %29, float %1342)  ; FMad(a,b,c)
  %1344 = call float @dx.op.tertiary.f32(i32 46, float %1316, float %25, float %1343)  ; FMad(a,b,c)
  %1345 = fadd fast float %1344, %21
  %1346 = fmul fast float %1329, %32
  %1347 = call float @dx.op.tertiary.f32(i32 46, float %1330, float %28, float %1346)  ; FMad(a,b,c)
  %1348 = call float @dx.op.tertiary.f32(i32 46, float %1316, float %24, float %1347)  ; FMad(a,b,c)
  %1349 = fadd fast float %1348, %20
  %1350 = fdiv fast float %1349, %1334
  %1351 = fdiv fast float %1345, %1334
  %1352 = fdiv fast float %1341, %1334
  %1353 = fsub fast float %1350, %17
  %1354 = fsub fast float %1351, %18
  %1355 = fsub fast float %1352, %19
  %1356 = fmul fast float %1353, %1353
  %1357 = fmul fast float %1354, %1354
  %1358 = fadd fast float %1357, %1356
  %1359 = fmul fast float %1355, %1355
  %1360 = fadd fast float %1358, %1359
  %1361 = call float @dx.op.unary.f32(i32 24, float %1360)  ; Sqrt(value)
  %1362 = fsub fast float %1361, %9
  %1363 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1362)  ; FMax(a,b)
  %1364 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1364, label %1365, label %1388

; <label>:1365                                    ; preds = %1337
  %1366 = call float @dx.op.unary.f32(i32 6, float %1354)  ; FAbs(value)
  %1367 = fmul fast float %1366, %11
  %1368 = fcmp fast olt float %1367, 0x3F50624DE0000000
  br i1 %1368, label %1369, label %1372

; <label>:1369                                    ; preds = %1365
  %1370 = fmul fast float %1367, 5.000000e-01
  %1371 = fsub fast float 1.000000e+00, %1370
  br label %1377

; <label>:1372                                    ; preds = %1365
  %1373 = fmul fast float %1367, 0xBFF7154760000000
  %1374 = call float @dx.op.unary.f32(i32 21, float %1373)  ; Exp(value)
  %1375 = fsub fast float 1.000000e+00, %1374
  %1376 = fdiv fast float %1375, %1367
  br label %1377

; <label>:1377                                    ; preds = %1372, %1369
  %1378 = phi float [ %1371, %1369 ], [ %1376, %1372 ]
  %1379 = call float @dx.op.binary.f32(i32 36, float %1351, float %18)  ; FMin(a,b)
  %1380 = fsub fast float %1379, %10
  %1381 = fmul fast float %11, %1380
  %1382 = fsub fast float -0.000000e+00, %1381
  %1383 = call float @dx.op.binary.f32(i32 35, float %1382, float -4.000000e+01)  ; FMax(a,b)
  %1384 = call float @dx.op.binary.f32(i32 36, float %1383, float 5.000000e+00)  ; FMin(a,b)
  %1385 = fmul fast float %1384, 0x3FF7154760000000
  %1386 = call float @dx.op.unary.f32(i32 21, float %1385)  ; Exp(value)
  %1387 = fmul fast float %1386, %1378
  br label %1388

; <label>:1388                                    ; preds = %1377, %1337
  %1389 = phi float [ %1387, %1377 ], [ 1.000000e+00, %1337 ]
  %1390 = fmul fast float %1363, %16
  %1391 = fmul fast float %1390, %1389
  %1392 = fcmp fast ole float %1361, %9
  %1393 = fcmp fast olt float %1361, 0x3F1A36E2E0000000
  %1394 = or i1 %1392, %1393
  br i1 %1394, label %1441, label %1395

; <label>:1395                                    ; preds = %1388
  %1396 = fdiv fast float %9, %1361
  %1397 = fmul fast float %1396, %1353
  %1398 = fmul fast float %1396, %1354
  %1399 = fmul fast float %1396, %1355
  %1400 = fadd fast float %1397, %17
  %1401 = fadd fast float %1398, %18
  %1402 = fadd fast float %1399, %19
  %1403 = fadd fast float %1400, -9.000000e+02
  %1404 = fadd fast float %1401, -1.500000e+01
  %1405 = fadd fast float %1402, -7.500000e+02
  %1406 = fmul fast float %1403, 0x3F62345680000000
  %1407 = fmul fast float %1404, 0x3F62345680000000
  %1408 = fmul fast float %1405, 0x3F62345680000000
  %1409 = call float @dx.op.dot3.f32(i32 55, float %1406, float %1407, float %1408, float %1406, float %1407, float %1408)  ; Dot3(ax,ay,az,bx,by,bz)
  %1410 = fsub fast float 1.000000e+00, %1409
  %1411 = call float @dx.op.unary.f32(i32 7, float %1410)  ; Saturate(value)
  %1412 = fmul fast float %1411, %1411
  %1413 = fadd fast float %1400, %1350
  %1414 = fadd fast float %1401, %1351
  %1415 = fadd fast float %1402, %1352
  %1416 = fmul fast float %1413, 0x3F52345680000000
  %1417 = fadd fast float %1416, -2.000000e+00
  %1418 = fmul fast float %1414, 0x3F52345680000000
  %1419 = fadd fast float %1418, 0xBFA1111120000000
  %1420 = fmul fast float %1415, 0x3F52345680000000
  %1421 = fadd fast float %1420, 0xBFFAAAAAC0000000
  %1422 = call float @dx.op.dot3.f32(i32 55, float %1417, float %1419, float %1421, float %1417, float %1419, float %1421)  ; Dot3(ax,ay,az,bx,by,bz)
  %1423 = fsub fast float 1.000000e+00, %1422
  %1424 = call float @dx.op.unary.f32(i32 7, float %1423)  ; Saturate(value)
  %1425 = fmul fast float %1424, %1424
  %1426 = fmul fast float %1425, 4.000000e+00
  %1427 = fadd fast float %1426, %1412
  %1428 = fadd fast float %1350, -9.000000e+02
  %1429 = fadd fast float %1351, -1.500000e+01
  %1430 = fadd fast float %1352, -7.500000e+02
  %1431 = fmul fast float %1428, 0x3F62345680000000
  %1432 = fmul fast float %1429, 0x3F62345680000000
  %1433 = fmul fast float %1430, 0x3F62345680000000
  %1434 = call float @dx.op.dot3.f32(i32 55, float %1431, float %1432, float %1433, float %1431, float %1432, float %1433)  ; Dot3(ax,ay,az,bx,by,bz)
  %1435 = fsub fast float 1.000000e+00, %1434
  %1436 = call float @dx.op.unary.f32(i32 7, float %1435)  ; Saturate(value)
  %1437 = fmul fast float %1436, %1436
  %1438 = fadd fast float %1427, %1437
  %1439 = fmul fast float %1362, 0x3F25D867E0000000
  %1440 = fmul fast float %1439, %1438
  br label %1441

; <label>:1441                                    ; preds = %1395, %1388
  %1442 = phi float [ %1440, %1395 ], [ 0.000000e+00, %1388 ]
  %1443 = fadd fast float %1442, %1391
  %1444 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1443)  ; FMin(a,b)
  %1445 = fmul fast float %1444, 0xBFF7154760000000
  %1446 = call float @dx.op.unary.f32(i32 21, float %1445)  ; Exp(value)
  %1447 = fsub fast float 1.000000e+00, %1446
  %1448 = call float @dx.op.binary.f32(i32 36, float %12, float %1447)  ; FMin(a,b)
  %1449 = fsub fast float %13, %1275
  %1450 = fsub fast float %14, %1276
  %1451 = fsub fast float %15, %1277
  %1452 = fmul fast float %1448, %1449
  %1453 = fmul fast float %1448, %1450
  %1454 = fmul fast float %1448, %1451
  %1455 = fadd fast float %1452, %1275
  %1456 = fadd fast float %1453, %1276
  %1457 = fadd fast float %1454, %1277
  br label %1458

; <label>:1458                                    ; preds = %1441, %1320, %1314
  %1459 = phi float [ %1455, %1441 ], [ %1275, %1320 ], [ %1275, %1314 ]
  %1460 = phi float [ %1456, %1441 ], [ %1276, %1320 ], [ %1276, %1314 ]
  %1461 = phi float [ %1457, %1441 ], [ %1277, %1320 ], [ %1277, %1314 ]
  %1462 = fadd fast float %5, 1.000000e+00
  %1463 = fadd fast float %6, 1.000000e+00
  %1464 = fsub fast float 1.000000e+00, %5
  %1465 = fmul fast float %36, %1462
  %1466 = fmul fast float %36, %1463
  %1467 = fmul fast float %36, %1464
  %1468 = fmul fast float %1465, %1459
  %1469 = fmul fast float %1466, %1460
  %1470 = fmul fast float %1467, %1461
  %1471 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1471, label %1497, label %1472

; <label>:1472                                    ; preds = %1458
  %1473 = fmul fast float %1468, 0x4004147AE0000000
  %1474 = fmul fast float %1469, 0x4004147AE0000000
  %1475 = fmul fast float %1470, 0x4004147AE0000000
  %1476 = fadd fast float %1473, 0x3F9EB851E0000000
  %1477 = fadd fast float %1474, 0x3F9EB851E0000000
  %1478 = fadd fast float %1475, 0x3F9EB851E0000000
  %1479 = fmul fast float %1476, %1468
  %1480 = fmul fast float %1477, %1469
  %1481 = fmul fast float %1478, %1470
  %1482 = fmul fast float %1468, 0x400370A3E0000000
  %1483 = fmul fast float %1469, 0x400370A3E0000000
  %1484 = fmul fast float %1470, 0x400370A3E0000000
  %1485 = fadd fast float %1482, 0x3FE2E147A0000000
  %1486 = fadd fast float %1483, 0x3FE2E147A0000000
  %1487 = fadd fast float %1484, 0x3FE2E147A0000000
  %1488 = fmul fast float %1485, %1468
  %1489 = fmul fast float %1486, %1469
  %1490 = fmul fast float %1487, %1470
  %1491 = fadd fast float %1488, 0x3FC1EB8520000000
  %1492 = fadd fast float %1489, 0x3FC1EB8520000000
  %1493 = fadd fast float %1490, 0x3FC1EB8520000000
  %1494 = fdiv fast float %1479, %1491
  %1495 = fdiv fast float %1480, %1492
  %1496 = fdiv fast float %1481, %1493
  br label %1497

; <label>:1497                                    ; preds = %1472, %1458
  %1498 = phi float [ %1494, %1472 ], [ %1468, %1458 ]
  %1499 = phi float [ %1495, %1472 ], [ %1469, %1458 ]
  %1500 = phi float [ %1496, %1472 ], [ %1470, %1458 ]
  %1501 = call float @dx.op.unary.f32(i32 7, float %1498)  ; Saturate(value)
  %1502 = call float @dx.op.unary.f32(i32 7, float %1499)  ; Saturate(value)
  %1503 = call float @dx.op.unary.f32(i32 7, float %1500)  ; Saturate(value)
  %1504 = call float @dx.op.dot3.f32(i32 55, float %1501, float %1502, float %1503, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1505 = fsub fast float %1501, %1504
  %1506 = fsub fast float %1502, %1504
  %1507 = fsub fast float %1503, %1504
  %1508 = fmul fast float %1505, %8
  %1509 = fmul fast float %1506, %8
  %1510 = fmul fast float %1507, %8
  %1511 = fadd fast float %1508, %1504
  %1512 = fadd fast float %1509, %1504
  %1513 = fadd fast float %1510, %1504
  %1514 = call float @dx.op.unary.f32(i32 7, float %1511)  ; Saturate(value)
  %1515 = call float @dx.op.unary.f32(i32 7, float %1512)  ; Saturate(value)
  %1516 = call float @dx.op.unary.f32(i32 7, float %1513)  ; Saturate(value)
  %1517 = fadd fast float %1514, 0xBFC70A3D80000000
  %1518 = fadd fast float %1515, 0xBFC70A3D80000000
  %1519 = fadd fast float %1516, 0xBFC70A3D80000000
  %1520 = fmul fast float %1517, %7
  %1521 = fmul fast float %1518, %7
  %1522 = fmul fast float %1519, %7
  %1523 = fadd fast float %1520, 0x3FC70A3D80000000
  %1524 = fadd fast float %1521, 0x3FC70A3D80000000
  %1525 = fadd fast float %1522, 0x3FC70A3D80000000
  %1526 = call float @dx.op.unary.f32(i32 7, float %1523)  ; Saturate(value)
  %1527 = call float @dx.op.unary.f32(i32 7, float %1524)  ; Saturate(value)
  %1528 = call float @dx.op.unary.f32(i32 7, float %1525)  ; Saturate(value)
  br label %1529

; <label>:1529                                    ; preds = %1497, %1280
  %1530 = phi float [ %1311, %1280 ], [ %1526, %1497 ]
  %1531 = phi float [ %1312, %1280 ], [ %1527, %1497 ]
  %1532 = phi float [ %1313, %1280 ], [ %1528, %1497 ]
  %1533 = fsub fast float %1530, %384
  %1534 = fsub fast float %1531, %385
  %1535 = fsub fast float %1532, %386
  %1536 = fmul fast float %1533, %1267
  %1537 = fmul fast float %1534, %1267
  %1538 = fmul fast float %1535, %1267
  %1539 = fadd fast float %1536, %384
  %1540 = fadd fast float %1537, %385
  %1541 = fadd fast float %1538, %386
  br label %1542

; <label>:1542                                    ; preds = %1529, %1254
  %1543 = phi float [ %1539, %1529 ], [ %384, %1254 ]
  %1544 = phi float [ %1540, %1529 ], [ %385, %1254 ]
  %1545 = phi float [ %1541, %1529 ], [ %386, %1254 ]
  %1546 = call float @dx.op.binary.f32(i32 36, float %1255, float %1543)  ; FMin(a,b)
  %1547 = call float @dx.op.binary.f32(i32 36, float %1256, float %1544)  ; FMin(a,b)
  %1548 = call float @dx.op.binary.f32(i32 36, float %1257, float %1545)  ; FMin(a,b)
  %1549 = call float @dx.op.binary.f32(i32 36, float %677, float %965)  ; FMin(a,b)
  %1550 = call float @dx.op.binary.f32(i32 36, float %678, float %966)  ; FMin(a,b)
  %1551 = call float @dx.op.binary.f32(i32 36, float %679, float %967)  ; FMin(a,b)
  %1552 = call float @dx.op.binary.f32(i32 36, float %1549, float %1546)  ; FMin(a,b)
  %1553 = call float @dx.op.binary.f32(i32 36, float %1550, float %1547)  ; FMin(a,b)
  %1554 = call float @dx.op.binary.f32(i32 36, float %1551, float %1548)  ; FMin(a,b)
  %1555 = call float @dx.op.binary.f32(i32 36, float %384, float %1552)  ; FMin(a,b)
  %1556 = call float @dx.op.binary.f32(i32 36, float %385, float %1553)  ; FMin(a,b)
  %1557 = call float @dx.op.binary.f32(i32 36, float %386, float %1554)  ; FMin(a,b)
  %1558 = call float @dx.op.binary.f32(i32 35, float %1255, float %1543)  ; FMax(a,b)
  %1559 = call float @dx.op.binary.f32(i32 35, float %1256, float %1544)  ; FMax(a,b)
  %1560 = call float @dx.op.binary.f32(i32 35, float %1257, float %1545)  ; FMax(a,b)
  %1561 = call float @dx.op.binary.f32(i32 35, float %677, float %965)  ; FMax(a,b)
  %1562 = call float @dx.op.binary.f32(i32 35, float %678, float %966)  ; FMax(a,b)
  %1563 = call float @dx.op.binary.f32(i32 35, float %679, float %967)  ; FMax(a,b)
  %1564 = call float @dx.op.binary.f32(i32 35, float %1561, float %1558)  ; FMax(a,b)
  %1565 = call float @dx.op.binary.f32(i32 35, float %1562, float %1559)  ; FMax(a,b)
  %1566 = call float @dx.op.binary.f32(i32 35, float %1563, float %1560)  ; FMax(a,b)
  %1567 = call float @dx.op.binary.f32(i32 35, float %384, float %1564)  ; FMax(a,b)
  %1568 = call float @dx.op.binary.f32(i32 35, float %385, float %1565)  ; FMax(a,b)
  %1569 = call float @dx.op.binary.f32(i32 35, float %386, float %1566)  ; FMax(a,b)
  %1570 = fsub fast float %1567, %1555
  %1571 = fsub fast float %1568, %1556
  %1572 = fsub fast float %1569, %1557
  %1573 = call float @dx.op.unary.f32(i32 6, float %1570)  ; FAbs(value)
  %1574 = call float @dx.op.unary.f32(i32 6, float %1571)  ; FAbs(value)
  %1575 = call float @dx.op.unary.f32(i32 6, float %1572)  ; FAbs(value)
  %1576 = call float @dx.op.binary.f32(i32 35, float %1574, float %1575)  ; FMax(a,b)
  %1577 = call float @dx.op.binary.f32(i32 35, float %1573, float %1576)  ; FMax(a,b)
  %1578 = call float @dx.op.binary.f32(i32 35, float %1568, float %1569)  ; FMax(a,b)
  %1579 = call float @dx.op.binary.f32(i32 35, float %1567, float %1578)  ; FMax(a,b)
  %1580 = fmul fast float %1579, 1.250000e-01
  %1581 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1580)  ; FMax(a,b)
  %1582 = fcmp fast ogt float %1577, %1581
  br i1 %1582, label %1583, label %1644

; <label>:1583                                    ; preds = %1542
  %1584 = fsub fast float %677, %965
  %1585 = fsub fast float %678, %966
  %1586 = fsub fast float %679, %967
  %1587 = call float @dx.op.unary.f32(i32 6, float %1584)  ; FAbs(value)
  %1588 = call float @dx.op.unary.f32(i32 6, float %1585)  ; FAbs(value)
  %1589 = call float @dx.op.unary.f32(i32 6, float %1586)  ; FAbs(value)
  %1590 = call float @dx.op.binary.f32(i32 35, float %1588, float %1589)  ; FMax(a,b)
  %1591 = call float @dx.op.binary.f32(i32 35, float %1587, float %1590)  ; FMax(a,b)
  %1592 = fsub fast float %1255, %1543
  %1593 = fsub fast float %1256, %1544
  %1594 = fsub fast float %1257, %1545
  %1595 = call float @dx.op.unary.f32(i32 6, float %1592)  ; FAbs(value)
  %1596 = call float @dx.op.unary.f32(i32 6, float %1593)  ; FAbs(value)
  %1597 = call float @dx.op.unary.f32(i32 6, float %1594)  ; FAbs(value)
  %1598 = call float @dx.op.binary.f32(i32 35, float %1596, float %1597)  ; FMax(a,b)
  %1599 = call float @dx.op.binary.f32(i32 35, float %1595, float %1598)  ; FMax(a,b)
  %1600 = fcmp fast olt float %1591, %1599
  %1601 = select i1 %1600, float %677, float %1255
  %1602 = select i1 %1600, float %678, float %1256
  %1603 = select i1 %1600, float %679, float %1257
  %1604 = select i1 %1600, float %965, float %1543
  %1605 = select i1 %1600, float %966, float %1544
  %1606 = select i1 %1600, float %967, float %1545
  %1607 = fsub fast float %384, %1604
  %1608 = fsub fast float %385, %1605
  %1609 = fsub fast float %386, %1606
  %1610 = fsub fast float %384, %1601
  %1611 = fsub fast float %385, %1602
  %1612 = fsub fast float %386, %1603
  %1613 = call float @dx.op.dot3.f32(i32 55, float %1610, float %1611, float %1612, float %1607, float %1608, float %1609)  ; Dot3(ax,ay,az,bx,by,bz)
  %1614 = fcmp fast ogt float %1613, 0.000000e+00
  br i1 %1614, label %1615, label %1626

; <label>:1615                                    ; preds = %1583
  %1616 = fsub fast float %1601, %1604
  %1617 = fsub fast float %1602, %1605
  %1618 = fsub fast float %1603, %1606
  %1619 = call float @dx.op.unary.f32(i32 6, float %1616)  ; FAbs(value)
  %1620 = call float @dx.op.unary.f32(i32 6, float %1617)  ; FAbs(value)
  %1621 = call float @dx.op.unary.f32(i32 6, float %1618)  ; FAbs(value)
  %1622 = call float @dx.op.binary.f32(i32 35, float %1620, float %1621)  ; FMax(a,b)
  %1623 = call float @dx.op.binary.f32(i32 35, float %1619, float %1622)  ; FMax(a,b)
  %1624 = fmul fast float %1577, 2.500000e-01
  %1625 = fcmp fast olt float %1623, %1624
  br label %1626

; <label>:1626                                    ; preds = %1615, %1583
  %1627 = phi i1 [ false, %1583 ], [ %1625, %1615 ]
  %1628 = select i1 %1627, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  %1629 = fadd fast float %1601, %1604
  %1630 = fadd fast float %1602, %1605
  %1631 = fadd fast float %1603, %1606
  %1632 = fmul fast float %1629, 5.000000e-01
  %1633 = fmul fast float %1630, 5.000000e-01
  %1634 = fmul fast float %1631, 5.000000e-01
  %1635 = fsub fast float %1632, %384
  %1636 = fsub fast float %1633, %385
  %1637 = fsub fast float %1634, %386
  %1638 = fmul fast float %1628, %1635
  %1639 = fmul fast float %1628, %1636
  %1640 = fmul fast float %1628, %1637
  %1641 = fadd fast float %1638, %384
  %1642 = fadd fast float %1639, %385
  %1643 = fadd fast float %1640, %386
  br label %1644

; <label>:1644                                    ; preds = %1626, %1542
  %1645 = phi float [ %1641, %1626 ], [ %384, %1542 ]
  %1646 = phi float [ %1642, %1626 ], [ %385, %1542 ]
  %1647 = phi float [ %1643, %1626 ], [ %386, %1542 ]
  %1648 = fcmp fast ogt float %1645, 0x3F69A5C380000000
  %1649 = fcmp fast ogt float %1646, 0x3F69A5C380000000
  %1650 = fcmp fast ogt float %1647, 0x3F69A5C380000000
  %1651 = select i1 %1648, float 0.000000e+00, float 1.000000e+00
  %1652 = select i1 %1649, float 0.000000e+00, float 1.000000e+00
  %1653 = select i1 %1650, float 0.000000e+00, float 1.000000e+00
  %1654 = fmul fast float %1645, 0x4029D70A40000000
  %1655 = fmul fast float %1646, 0x4029D70A40000000
  %1656 = fmul fast float %1647, 0x4029D70A40000000
  %1657 = call float @dx.op.binary.f32(i32 35, float %1645, float 0.000000e+00)  ; FMax(a,b)
  %1658 = call float @dx.op.binary.f32(i32 35, float %1646, float 0.000000e+00)  ; FMax(a,b)
  %1659 = call float @dx.op.binary.f32(i32 35, float %1647, float 0.000000e+00)  ; FMax(a,b)
  %1660 = call float @dx.op.unary.f32(i32 23, float %1657)  ; Log(value)
  %1661 = call float @dx.op.unary.f32(i32 23, float %1658)  ; Log(value)
  %1662 = call float @dx.op.unary.f32(i32 23, float %1659)  ; Log(value)
  %1663 = fmul fast float %1660, 0x3FDAAAAAA0000000
  %1664 = fmul fast float %1661, 0x3FDAAAAAA0000000
  %1665 = fmul fast float %1662, 0x3FDAAAAAA0000000
  %1666 = call float @dx.op.unary.f32(i32 21, float %1663)  ; Exp(value)
  %1667 = call float @dx.op.unary.f32(i32 21, float %1664)  ; Exp(value)
  %1668 = call float @dx.op.unary.f32(i32 21, float %1665)  ; Exp(value)
  %1669 = fmul fast float %1666, 0x3FF0E147A0000000
  %1670 = fmul fast float %1667, 0x3FF0E147A0000000
  %1671 = fmul fast float %1668, 0x3FF0E147A0000000
  %1672 = fadd fast float %1669, 0xBFAC28F5C0000000
  %1673 = fadd fast float %1670, 0xBFAC28F5C0000000
  %1674 = fadd fast float %1671, 0xBFAC28F5C0000000
  %1675 = fsub fast float %1654, %1672
  %1676 = fsub fast float %1655, %1673
  %1677 = fsub fast float %1656, %1674
  %1678 = fmul fast float %1675, %1651
  %1679 = fmul fast float %1676, %1652
  %1680 = fmul fast float %1677, %1653
  %1681 = fadd fast float %1678, %1672
  %1682 = fadd fast float %1679, %1673
  %1683 = fadd fast float %1680, %1674
  br label %1684

; <label>:1684                                    ; preds = %1644, %172
  %1685 = phi float [ %167, %172 ], [ %1681, %1644 ]
  %1686 = phi float [ %168, %172 ], [ %1682, %1644 ]
  %1687 = phi float [ %169, %172 ], [ %1683, %1644 ]
  %1688 = phi float [ %173, %172 ], [ %170, %1644 ]
  %1689 = fcmp fast ogt float %1685, 0x3FA4B5DCC0000000
  %1690 = fcmp fast ogt float %1686, 0x3FA4B5DCC0000000
  %1691 = fcmp fast ogt float %1687, 0x3FA4B5DCC0000000
  %1692 = select i1 %1689, float 0.000000e+00, float 1.000000e+00
  %1693 = select i1 %1690, float 0.000000e+00, float 1.000000e+00
  %1694 = select i1 %1691, float 0.000000e+00, float 1.000000e+00
  %1695 = fmul fast float %1685, 0x3FB3D07220000000
  %1696 = fmul fast float %1686, 0x3FB3D07220000000
  %1697 = fmul fast float %1687, 0x3FB3D07220000000
  %1698 = fadd fast float %1685, 0x3FAC28F5C0000000
  %1699 = fadd fast float %1686, 0x3FAC28F5C0000000
  %1700 = fadd fast float %1687, 0x3FAC28F5C0000000
  %1701 = fmul fast float %1698, 0x3FEE54EDE0000000
  %1702 = fmul fast float %1699, 0x3FEE54EDE0000000
  %1703 = fmul fast float %1700, 0x3FEE54EDE0000000
  %1704 = call float @dx.op.unary.f32(i32 23, float %1701)  ; Log(value)
  %1705 = call float @dx.op.unary.f32(i32 23, float %1702)  ; Log(value)
  %1706 = call float @dx.op.unary.f32(i32 23, float %1703)  ; Log(value)
  %1707 = fmul fast float %1704, 0x4003333340000000
  %1708 = fmul fast float %1705, 0x4003333340000000
  %1709 = fmul fast float %1706, 0x4003333340000000
  %1710 = call float @dx.op.unary.f32(i32 21, float %1707)  ; Exp(value)
  %1711 = call float @dx.op.unary.f32(i32 21, float %1708)  ; Exp(value)
  %1712 = call float @dx.op.unary.f32(i32 21, float %1709)  ; Exp(value)
  %1713 = fsub fast float %1695, %1710
  %1714 = fsub fast float %1696, %1711
  %1715 = fsub fast float %1697, %1712
  %1716 = fmul fast float %1713, %1692
  %1717 = fmul fast float %1714, %1693
  %1718 = fmul fast float %1715, %1694
  %1719 = fadd fast float %1716, %1710
  %1720 = fadd fast float %1717, %1711
  %1721 = fadd fast float %1718, %1712
  %1722 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %67, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1723 = extractvalue %dx.types.ResRet.f32 %1722, 0
  %1724 = extractvalue %dx.types.ResRet.f32 %1722, 1
  %1725 = extractvalue %dx.types.ResRet.f32 %1722, 2
  %1726 = extractvalue %dx.types.ResRet.f32 %1722, 3
  %1727 = fcmp fast olt float %1726, 0.000000e+00
  br i1 %1727, label %1728, label %1730

; <label>:1728                                    ; preds = %1684
  %1729 = fsub fast float -1.000000e+00, %1726
  br label %3240

; <label>:1730                                    ; preds = %1684
  %1731 = fcmp fast ogt float %38, 5.000000e-01
  %1732 = fcmp fast olt float %84, 1.000000e+00
  %1733 = and i1 %1731, %1732
  br i1 %1733, label %1734, label %1872

; <label>:1734                                    ; preds = %1730
  %1735 = sitofp i32 %67 to float
  %1736 = sitofp i32 %64 to float
  %1737 = fadd fast float %1735, 5.000000e-01
  %1738 = fadd fast float %1736, 5.000000e-01
  %1739 = fdiv fast float %1737, %45
  %1740 = fdiv fast float %1738, %46
  %1741 = fmul fast float %1739, 2.000000e+00
  %1742 = fmul fast float %1740, 2.000000e+00
  %1743 = fadd fast float %1741, -1.000000e+00
  %1744 = fsub fast float 1.000000e+00, %1742
  %1745 = fmul fast float %1743, %35
  %1746 = call float @dx.op.tertiary.f32(i32 46, float %1744, float %31, float %1745)  ; FMad(a,b,c)
  %1747 = call float @dx.op.tertiary.f32(i32 46, float %84, float %27, float %1746)  ; FMad(a,b,c)
  %1748 = fadd fast float %1747, %23
  %1749 = call float @dx.op.unary.f32(i32 6, float %1748)  ; FAbs(value)
  %1750 = fcmp fast ogt float %1749, 0x3EB0C6F7A0000000
  br i1 %1750, label %1751, label %1872

; <label>:1751                                    ; preds = %1734
  %1752 = fmul fast float %1743, %34
  %1753 = call float @dx.op.tertiary.f32(i32 46, float %1744, float %30, float %1752)  ; FMad(a,b,c)
  %1754 = call float @dx.op.tertiary.f32(i32 46, float %84, float %26, float %1753)  ; FMad(a,b,c)
  %1755 = fadd fast float %1754, %22
  %1756 = fmul fast float %1743, %33
  %1757 = call float @dx.op.tertiary.f32(i32 46, float %1744, float %29, float %1756)  ; FMad(a,b,c)
  %1758 = call float @dx.op.tertiary.f32(i32 46, float %84, float %25, float %1757)  ; FMad(a,b,c)
  %1759 = fadd fast float %1758, %21
  %1760 = fmul fast float %1743, %32
  %1761 = call float @dx.op.tertiary.f32(i32 46, float %1744, float %28, float %1760)  ; FMad(a,b,c)
  %1762 = call float @dx.op.tertiary.f32(i32 46, float %84, float %24, float %1761)  ; FMad(a,b,c)
  %1763 = fadd fast float %1762, %20
  %1764 = fdiv fast float %1763, %1748
  %1765 = fdiv fast float %1759, %1748
  %1766 = fdiv fast float %1755, %1748
  %1767 = fsub fast float %1764, %17
  %1768 = fsub fast float %1765, %18
  %1769 = fsub fast float %1766, %19
  %1770 = fmul fast float %1767, %1767
  %1771 = fmul fast float %1768, %1768
  %1772 = fadd fast float %1771, %1770
  %1773 = fmul fast float %1769, %1769
  %1774 = fadd fast float %1772, %1773
  %1775 = call float @dx.op.unary.f32(i32 24, float %1774)  ; Sqrt(value)
  %1776 = fsub fast float %1775, %9
  %1777 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1776)  ; FMax(a,b)
  %1778 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1778, label %1779, label %1802

; <label>:1779                                    ; preds = %1751
  %1780 = call float @dx.op.unary.f32(i32 6, float %1768)  ; FAbs(value)
  %1781 = fmul fast float %1780, %11
  %1782 = fcmp fast olt float %1781, 0x3F50624DE0000000
  br i1 %1782, label %1783, label %1786

; <label>:1783                                    ; preds = %1779
  %1784 = fmul fast float %1781, 5.000000e-01
  %1785 = fsub fast float 1.000000e+00, %1784
  br label %1791

; <label>:1786                                    ; preds = %1779
  %1787 = fmul fast float %1781, 0xBFF7154760000000
  %1788 = call float @dx.op.unary.f32(i32 21, float %1787)  ; Exp(value)
  %1789 = fsub fast float 1.000000e+00, %1788
  %1790 = fdiv fast float %1789, %1781
  br label %1791

; <label>:1791                                    ; preds = %1786, %1783
  %1792 = phi float [ %1785, %1783 ], [ %1790, %1786 ]
  %1793 = call float @dx.op.binary.f32(i32 36, float %1765, float %18)  ; FMin(a,b)
  %1794 = fsub fast float %1793, %10
  %1795 = fmul fast float %11, %1794
  %1796 = fsub fast float -0.000000e+00, %1795
  %1797 = call float @dx.op.binary.f32(i32 35, float %1796, float -4.000000e+01)  ; FMax(a,b)
  %1798 = call float @dx.op.binary.f32(i32 36, float %1797, float 5.000000e+00)  ; FMin(a,b)
  %1799 = fmul fast float %1798, 0x3FF7154760000000
  %1800 = call float @dx.op.unary.f32(i32 21, float %1799)  ; Exp(value)
  %1801 = fmul fast float %1800, %1792
  br label %1802

; <label>:1802                                    ; preds = %1791, %1751
  %1803 = phi float [ %1801, %1791 ], [ 1.000000e+00, %1751 ]
  %1804 = fmul fast float %1777, %16
  %1805 = fmul fast float %1804, %1803
  %1806 = fcmp fast ole float %1775, %9
  %1807 = fcmp fast olt float %1775, 0x3F1A36E2E0000000
  %1808 = or i1 %1806, %1807
  br i1 %1808, label %1855, label %1809

; <label>:1809                                    ; preds = %1802
  %1810 = fdiv fast float %9, %1775
  %1811 = fmul fast float %1810, %1767
  %1812 = fmul fast float %1810, %1768
  %1813 = fmul fast float %1810, %1769
  %1814 = fadd fast float %1811, %17
  %1815 = fadd fast float %1812, %18
  %1816 = fadd fast float %1813, %19
  %1817 = fadd fast float %1814, -9.000000e+02
  %1818 = fadd fast float %1815, -1.500000e+01
  %1819 = fadd fast float %1816, -7.500000e+02
  %1820 = fmul fast float %1817, 0x3F62345680000000
  %1821 = fmul fast float %1818, 0x3F62345680000000
  %1822 = fmul fast float %1819, 0x3F62345680000000
  %1823 = call float @dx.op.dot3.f32(i32 55, float %1820, float %1821, float %1822, float %1820, float %1821, float %1822)  ; Dot3(ax,ay,az,bx,by,bz)
  %1824 = fsub fast float 1.000000e+00, %1823
  %1825 = call float @dx.op.unary.f32(i32 7, float %1824)  ; Saturate(value)
  %1826 = fmul fast float %1825, %1825
  %1827 = fadd fast float %1814, %1764
  %1828 = fadd fast float %1815, %1765
  %1829 = fadd fast float %1816, %1766
  %1830 = fmul fast float %1827, 0x3F52345680000000
  %1831 = fadd fast float %1830, -2.000000e+00
  %1832 = fmul fast float %1828, 0x3F52345680000000
  %1833 = fadd fast float %1832, 0xBFA1111120000000
  %1834 = fmul fast float %1829, 0x3F52345680000000
  %1835 = fadd fast float %1834, 0xBFFAAAAAC0000000
  %1836 = call float @dx.op.dot3.f32(i32 55, float %1831, float %1833, float %1835, float %1831, float %1833, float %1835)  ; Dot3(ax,ay,az,bx,by,bz)
  %1837 = fsub fast float 1.000000e+00, %1836
  %1838 = call float @dx.op.unary.f32(i32 7, float %1837)  ; Saturate(value)
  %1839 = fmul fast float %1838, %1838
  %1840 = fmul fast float %1839, 4.000000e+00
  %1841 = fadd fast float %1840, %1826
  %1842 = fadd fast float %1764, -9.000000e+02
  %1843 = fadd fast float %1765, -1.500000e+01
  %1844 = fadd fast float %1766, -7.500000e+02
  %1845 = fmul fast float %1842, 0x3F62345680000000
  %1846 = fmul fast float %1843, 0x3F62345680000000
  %1847 = fmul fast float %1844, 0x3F62345680000000
  %1848 = call float @dx.op.dot3.f32(i32 55, float %1845, float %1846, float %1847, float %1845, float %1846, float %1847)  ; Dot3(ax,ay,az,bx,by,bz)
  %1849 = fsub fast float 1.000000e+00, %1848
  %1850 = call float @dx.op.unary.f32(i32 7, float %1849)  ; Saturate(value)
  %1851 = fmul fast float %1850, %1850
  %1852 = fadd fast float %1841, %1851
  %1853 = fmul fast float %1776, 0x3F25D867E0000000
  %1854 = fmul fast float %1853, %1852
  br label %1855

; <label>:1855                                    ; preds = %1809, %1802
  %1856 = phi float [ %1854, %1809 ], [ 0.000000e+00, %1802 ]
  %1857 = fadd fast float %1856, %1805
  %1858 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1857)  ; FMin(a,b)
  %1859 = fmul fast float %1858, 0xBFF7154760000000
  %1860 = call float @dx.op.unary.f32(i32 21, float %1859)  ; Exp(value)
  %1861 = fsub fast float 1.000000e+00, %1860
  %1862 = call float @dx.op.binary.f32(i32 36, float %12, float %1861)  ; FMin(a,b)
  %1863 = fsub fast float %13, %1723
  %1864 = fsub fast float %14, %1724
  %1865 = fsub fast float %15, %1725
  %1866 = fmul fast float %1862, %1863
  %1867 = fmul fast float %1862, %1864
  %1868 = fmul fast float %1862, %1865
  %1869 = fadd fast float %1866, %1723
  %1870 = fadd fast float %1867, %1724
  %1871 = fadd fast float %1868, %1725
  br label %1872

; <label>:1872                                    ; preds = %1855, %1734, %1730
  %1873 = phi float [ %1869, %1855 ], [ %1723, %1734 ], [ %1723, %1730 ]
  %1874 = phi float [ %1870, %1855 ], [ %1724, %1734 ], [ %1724, %1730 ]
  %1875 = phi float [ %1871, %1855 ], [ %1725, %1734 ], [ %1725, %1730 ]
  %1876 = fadd fast float %5, 1.000000e+00
  %1877 = fadd fast float %6, 1.000000e+00
  %1878 = fsub fast float 1.000000e+00, %5
  %1879 = fmul fast float %36, %1876
  %1880 = fmul fast float %36, %1877
  %1881 = fmul fast float %36, %1878
  %1882 = fmul fast float %1879, %1873
  %1883 = fmul fast float %1880, %1874
  %1884 = fmul fast float %1881, %1875
  %1885 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1885, label %1911, label %1886

; <label>:1886                                    ; preds = %1872
  %1887 = fmul fast float %1882, 0x4004147AE0000000
  %1888 = fmul fast float %1883, 0x4004147AE0000000
  %1889 = fmul fast float %1884, 0x4004147AE0000000
  %1890 = fadd fast float %1887, 0x3F9EB851E0000000
  %1891 = fadd fast float %1888, 0x3F9EB851E0000000
  %1892 = fadd fast float %1889, 0x3F9EB851E0000000
  %1893 = fmul fast float %1890, %1882
  %1894 = fmul fast float %1891, %1883
  %1895 = fmul fast float %1892, %1884
  %1896 = fmul fast float %1882, 0x400370A3E0000000
  %1897 = fmul fast float %1883, 0x400370A3E0000000
  %1898 = fmul fast float %1884, 0x400370A3E0000000
  %1899 = fadd fast float %1896, 0x3FE2E147A0000000
  %1900 = fadd fast float %1897, 0x3FE2E147A0000000
  %1901 = fadd fast float %1898, 0x3FE2E147A0000000
  %1902 = fmul fast float %1899, %1882
  %1903 = fmul fast float %1900, %1883
  %1904 = fmul fast float %1901, %1884
  %1905 = fadd fast float %1902, 0x3FC1EB8520000000
  %1906 = fadd fast float %1903, 0x3FC1EB8520000000
  %1907 = fadd fast float %1904, 0x3FC1EB8520000000
  %1908 = fdiv fast float %1893, %1905
  %1909 = fdiv fast float %1894, %1906
  %1910 = fdiv fast float %1895, %1907
  br label %1911

; <label>:1911                                    ; preds = %1886, %1872
  %1912 = phi float [ %1908, %1886 ], [ %1882, %1872 ]
  %1913 = phi float [ %1909, %1886 ], [ %1883, %1872 ]
  %1914 = phi float [ %1910, %1886 ], [ %1884, %1872 ]
  %1915 = call float @dx.op.unary.f32(i32 7, float %1912)  ; Saturate(value)
  %1916 = call float @dx.op.unary.f32(i32 7, float %1913)  ; Saturate(value)
  %1917 = call float @dx.op.unary.f32(i32 7, float %1914)  ; Saturate(value)
  %1918 = call float @dx.op.dot3.f32(i32 55, float %1915, float %1916, float %1917, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1919 = fsub fast float %1915, %1918
  %1920 = fsub fast float %1916, %1918
  %1921 = fsub fast float %1917, %1918
  %1922 = fmul fast float %1919, %8
  %1923 = fmul fast float %1920, %8
  %1924 = fmul fast float %1921, %8
  %1925 = fadd fast float %1922, %1918
  %1926 = fadd fast float %1923, %1918
  %1927 = fadd fast float %1924, %1918
  %1928 = call float @dx.op.unary.f32(i32 7, float %1925)  ; Saturate(value)
  %1929 = call float @dx.op.unary.f32(i32 7, float %1926)  ; Saturate(value)
  %1930 = call float @dx.op.unary.f32(i32 7, float %1927)  ; Saturate(value)
  %1931 = fadd fast float %1928, 0xBFC70A3D80000000
  %1932 = fadd fast float %1929, 0xBFC70A3D80000000
  %1933 = fadd fast float %1930, 0xBFC70A3D80000000
  %1934 = fmul fast float %1931, %7
  %1935 = fmul fast float %1932, %7
  %1936 = fmul fast float %1933, %7
  %1937 = fadd fast float %1934, 0x3FC70A3D80000000
  %1938 = fadd fast float %1935, 0x3FC70A3D80000000
  %1939 = fadd fast float %1936, 0x3FC70A3D80000000
  %1940 = call float @dx.op.unary.f32(i32 7, float %1937)  ; Saturate(value)
  %1941 = call float @dx.op.unary.f32(i32 7, float %1938)  ; Saturate(value)
  %1942 = call float @dx.op.unary.f32(i32 7, float %1939)  ; Saturate(value)
  %1943 = add i32 %64, -1
  %1944 = call i32 @dx.op.binary.i32(i32 37, i32 %67, i32 0)  ; IMax(a,b)
  %1945 = call i32 @dx.op.binary.i32(i32 37, i32 %1943, i32 0)  ; IMax(a,b)
  %1946 = call i32 @dx.op.binary.i32(i32 38, i32 %1944, i32 %59)  ; IMin(a,b)
  %1947 = call i32 @dx.op.binary.i32(i32 38, i32 %1945, i32 %60)  ; IMin(a,b)
  %1948 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1946, i32 %1947, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1949 = extractvalue %dx.types.ResRet.f32 %1948, 0
  %1950 = fsub fast float 1.000000e+00, %84
  %1951 = fmul fast float %1950, 0x3FA99999A0000000
  %1952 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %1951)  ; FMax(a,b)
  %1953 = fsub fast float %1949, %84
  %1954 = call float @dx.op.unary.f32(i32 6, float %1953)  ; FAbs(value)
  %1955 = fdiv fast float %1954, %1952
  %1956 = fsub fast float 1.000000e+00, %1955
  %1957 = call float @dx.op.unary.f32(i32 7, float %1956)  ; Saturate(value)
  %1958 = fcmp fast ugt float %1957, 0.000000e+00
  br i1 %1958, label %1959, label %2232

; <label>:1959                                    ; preds = %1911
  %1960 = call i32 @dx.op.binary.i32(i32 37, i32 %1946, i32 0)  ; IMax(a,b)
  %1961 = call i32 @dx.op.binary.i32(i32 37, i32 %1947, i32 0)  ; IMax(a,b)
  %1962 = call i32 @dx.op.binary.i32(i32 38, i32 %1960, i32 %59)  ; IMin(a,b)
  %1963 = call i32 @dx.op.binary.i32(i32 38, i32 %1961, i32 %60)  ; IMin(a,b)
  %1964 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1962, i32 %1963, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1965 = extractvalue %dx.types.ResRet.f32 %1964, 0
  %1966 = extractvalue %dx.types.ResRet.f32 %1964, 1
  %1967 = extractvalue %dx.types.ResRet.f32 %1964, 2
  %1968 = extractvalue %dx.types.ResRet.f32 %1964, 3
  %1969 = fcmp fast olt float %1968, 0.000000e+00
  br i1 %1969, label %1970, label %2004

; <label>:1970                                    ; preds = %1959
  %1971 = fcmp fast ogt float %1965, 0x3FA4B5DCC0000000
  %1972 = fcmp fast ogt float %1966, 0x3FA4B5DCC0000000
  %1973 = fcmp fast ogt float %1967, 0x3FA4B5DCC0000000
  %1974 = select i1 %1971, float 0.000000e+00, float 1.000000e+00
  %1975 = select i1 %1972, float 0.000000e+00, float 1.000000e+00
  %1976 = select i1 %1973, float 0.000000e+00, float 1.000000e+00
  %1977 = fmul fast float %1965, 0x3FB3D07220000000
  %1978 = fmul fast float %1966, 0x3FB3D07220000000
  %1979 = fmul fast float %1967, 0x3FB3D07220000000
  %1980 = fadd fast float %1965, 0x3FAC28F5C0000000
  %1981 = fadd fast float %1966, 0x3FAC28F5C0000000
  %1982 = fadd fast float %1967, 0x3FAC28F5C0000000
  %1983 = fmul fast float %1980, 0x3FEE54EDE0000000
  %1984 = fmul fast float %1981, 0x3FEE54EDE0000000
  %1985 = fmul fast float %1982, 0x3FEE54EDE0000000
  %1986 = call float @dx.op.unary.f32(i32 23, float %1983)  ; Log(value)
  %1987 = call float @dx.op.unary.f32(i32 23, float %1984)  ; Log(value)
  %1988 = call float @dx.op.unary.f32(i32 23, float %1985)  ; Log(value)
  %1989 = fmul fast float %1986, 0x4003333340000000
  %1990 = fmul fast float %1987, 0x4003333340000000
  %1991 = fmul fast float %1988, 0x4003333340000000
  %1992 = call float @dx.op.unary.f32(i32 21, float %1989)  ; Exp(value)
  %1993 = call float @dx.op.unary.f32(i32 21, float %1990)  ; Exp(value)
  %1994 = call float @dx.op.unary.f32(i32 21, float %1991)  ; Exp(value)
  %1995 = fsub fast float %1977, %1992
  %1996 = fsub fast float %1978, %1993
  %1997 = fsub fast float %1979, %1994
  %1998 = fmul fast float %1995, %1974
  %1999 = fmul fast float %1996, %1975
  %2000 = fmul fast float %1997, %1976
  %2001 = fadd fast float %1998, %1992
  %2002 = fadd fast float %1999, %1993
  %2003 = fadd fast float %2000, %1994
  br label %2219

; <label>:2004                                    ; preds = %1959
  %2005 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1962, i32 %1963, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2006 = extractvalue %dx.types.ResRet.f32 %2005, 0
  %2007 = fcmp fast ogt float %38, 5.000000e-01
  %2008 = fcmp fast olt float %2006, 1.000000e+00
  %2009 = and i1 %2007, %2008
  br i1 %2009, label %2010, label %2148

; <label>:2010                                    ; preds = %2004
  %2011 = sitofp i32 %1962 to float
  %2012 = sitofp i32 %1963 to float
  %2013 = fadd fast float %2011, 5.000000e-01
  %2014 = fadd fast float %2012, 5.000000e-01
  %2015 = fdiv fast float %2013, %45
  %2016 = fdiv fast float %2014, %46
  %2017 = fmul fast float %2015, 2.000000e+00
  %2018 = fmul fast float %2016, 2.000000e+00
  %2019 = fadd fast float %2017, -1.000000e+00
  %2020 = fsub fast float 1.000000e+00, %2018
  %2021 = fmul fast float %2019, %35
  %2022 = call float @dx.op.tertiary.f32(i32 46, float %2020, float %31, float %2021)  ; FMad(a,b,c)
  %2023 = call float @dx.op.tertiary.f32(i32 46, float %2006, float %27, float %2022)  ; FMad(a,b,c)
  %2024 = fadd fast float %2023, %23
  %2025 = call float @dx.op.unary.f32(i32 6, float %2024)  ; FAbs(value)
  %2026 = fcmp fast ogt float %2025, 0x3EB0C6F7A0000000
  br i1 %2026, label %2027, label %2148

; <label>:2027                                    ; preds = %2010
  %2028 = fmul fast float %2019, %34
  %2029 = call float @dx.op.tertiary.f32(i32 46, float %2020, float %30, float %2028)  ; FMad(a,b,c)
  %2030 = call float @dx.op.tertiary.f32(i32 46, float %2006, float %26, float %2029)  ; FMad(a,b,c)
  %2031 = fadd fast float %2030, %22
  %2032 = fmul fast float %2019, %33
  %2033 = call float @dx.op.tertiary.f32(i32 46, float %2020, float %29, float %2032)  ; FMad(a,b,c)
  %2034 = call float @dx.op.tertiary.f32(i32 46, float %2006, float %25, float %2033)  ; FMad(a,b,c)
  %2035 = fadd fast float %2034, %21
  %2036 = fmul fast float %2019, %32
  %2037 = call float @dx.op.tertiary.f32(i32 46, float %2020, float %28, float %2036)  ; FMad(a,b,c)
  %2038 = call float @dx.op.tertiary.f32(i32 46, float %2006, float %24, float %2037)  ; FMad(a,b,c)
  %2039 = fadd fast float %2038, %20
  %2040 = fdiv fast float %2039, %2024
  %2041 = fdiv fast float %2035, %2024
  %2042 = fdiv fast float %2031, %2024
  %2043 = fsub fast float %2040, %17
  %2044 = fsub fast float %2041, %18
  %2045 = fsub fast float %2042, %19
  %2046 = fmul fast float %2043, %2043
  %2047 = fmul fast float %2044, %2044
  %2048 = fadd fast float %2047, %2046
  %2049 = fmul fast float %2045, %2045
  %2050 = fadd fast float %2048, %2049
  %2051 = call float @dx.op.unary.f32(i32 24, float %2050)  ; Sqrt(value)
  %2052 = fsub fast float %2051, %9
  %2053 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2052)  ; FMax(a,b)
  %2054 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %2054, label %2055, label %2078

; <label>:2055                                    ; preds = %2027
  %2056 = call float @dx.op.unary.f32(i32 6, float %2044)  ; FAbs(value)
  %2057 = fmul fast float %2056, %11
  %2058 = fcmp fast olt float %2057, 0x3F50624DE0000000
  br i1 %2058, label %2059, label %2062

; <label>:2059                                    ; preds = %2055
  %2060 = fmul fast float %2057, 5.000000e-01
  %2061 = fsub fast float 1.000000e+00, %2060
  br label %2067

; <label>:2062                                    ; preds = %2055
  %2063 = fmul fast float %2057, 0xBFF7154760000000
  %2064 = call float @dx.op.unary.f32(i32 21, float %2063)  ; Exp(value)
  %2065 = fsub fast float 1.000000e+00, %2064
  %2066 = fdiv fast float %2065, %2057
  br label %2067

; <label>:2067                                    ; preds = %2062, %2059
  %2068 = phi float [ %2061, %2059 ], [ %2066, %2062 ]
  %2069 = call float @dx.op.binary.f32(i32 36, float %2041, float %18)  ; FMin(a,b)
  %2070 = fsub fast float %2069, %10
  %2071 = fmul fast float %11, %2070
  %2072 = fsub fast float -0.000000e+00, %2071
  %2073 = call float @dx.op.binary.f32(i32 35, float %2072, float -4.000000e+01)  ; FMax(a,b)
  %2074 = call float @dx.op.binary.f32(i32 36, float %2073, float 5.000000e+00)  ; FMin(a,b)
  %2075 = fmul fast float %2074, 0x3FF7154760000000
  %2076 = call float @dx.op.unary.f32(i32 21, float %2075)  ; Exp(value)
  %2077 = fmul fast float %2076, %2068
  br label %2078

; <label>:2078                                    ; preds = %2067, %2027
  %2079 = phi float [ %2077, %2067 ], [ 1.000000e+00, %2027 ]
  %2080 = fmul fast float %2053, %16
  %2081 = fmul fast float %2080, %2079
  %2082 = fcmp fast ole float %2051, %9
  %2083 = fcmp fast olt float %2051, 0x3F1A36E2E0000000
  %2084 = or i1 %2082, %2083
  br i1 %2084, label %2131, label %2085

; <label>:2085                                    ; preds = %2078
  %2086 = fdiv fast float %9, %2051
  %2087 = fmul fast float %2086, %2043
  %2088 = fmul fast float %2086, %2044
  %2089 = fmul fast float %2086, %2045
  %2090 = fadd fast float %2087, %17
  %2091 = fadd fast float %2088, %18
  %2092 = fadd fast float %2089, %19
  %2093 = fadd fast float %2090, -9.000000e+02
  %2094 = fadd fast float %2091, -1.500000e+01
  %2095 = fadd fast float %2092, -7.500000e+02
  %2096 = fmul fast float %2093, 0x3F62345680000000
  %2097 = fmul fast float %2094, 0x3F62345680000000
  %2098 = fmul fast float %2095, 0x3F62345680000000
  %2099 = call float @dx.op.dot3.f32(i32 55, float %2096, float %2097, float %2098, float %2096, float %2097, float %2098)  ; Dot3(ax,ay,az,bx,by,bz)
  %2100 = fsub fast float 1.000000e+00, %2099
  %2101 = call float @dx.op.unary.f32(i32 7, float %2100)  ; Saturate(value)
  %2102 = fmul fast float %2101, %2101
  %2103 = fadd fast float %2090, %2040
  %2104 = fadd fast float %2091, %2041
  %2105 = fadd fast float %2092, %2042
  %2106 = fmul fast float %2103, 0x3F52345680000000
  %2107 = fadd fast float %2106, -2.000000e+00
  %2108 = fmul fast float %2104, 0x3F52345680000000
  %2109 = fadd fast float %2108, 0xBFA1111120000000
  %2110 = fmul fast float %2105, 0x3F52345680000000
  %2111 = fadd fast float %2110, 0xBFFAAAAAC0000000
  %2112 = call float @dx.op.dot3.f32(i32 55, float %2107, float %2109, float %2111, float %2107, float %2109, float %2111)  ; Dot3(ax,ay,az,bx,by,bz)
  %2113 = fsub fast float 1.000000e+00, %2112
  %2114 = call float @dx.op.unary.f32(i32 7, float %2113)  ; Saturate(value)
  %2115 = fmul fast float %2114, %2114
  %2116 = fmul fast float %2115, 4.000000e+00
  %2117 = fadd fast float %2116, %2102
  %2118 = fadd fast float %2040, -9.000000e+02
  %2119 = fadd fast float %2041, -1.500000e+01
  %2120 = fadd fast float %2042, -7.500000e+02
  %2121 = fmul fast float %2118, 0x3F62345680000000
  %2122 = fmul fast float %2119, 0x3F62345680000000
  %2123 = fmul fast float %2120, 0x3F62345680000000
  %2124 = call float @dx.op.dot3.f32(i32 55, float %2121, float %2122, float %2123, float %2121, float %2122, float %2123)  ; Dot3(ax,ay,az,bx,by,bz)
  %2125 = fsub fast float 1.000000e+00, %2124
  %2126 = call float @dx.op.unary.f32(i32 7, float %2125)  ; Saturate(value)
  %2127 = fmul fast float %2126, %2126
  %2128 = fadd fast float %2117, %2127
  %2129 = fmul fast float %2052, 0x3F25D867E0000000
  %2130 = fmul fast float %2129, %2128
  br label %2131

; <label>:2131                                    ; preds = %2085, %2078
  %2132 = phi float [ %2130, %2085 ], [ 0.000000e+00, %2078 ]
  %2133 = fadd fast float %2132, %2081
  %2134 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2133)  ; FMin(a,b)
  %2135 = fmul fast float %2134, 0xBFF7154760000000
  %2136 = call float @dx.op.unary.f32(i32 21, float %2135)  ; Exp(value)
  %2137 = fsub fast float 1.000000e+00, %2136
  %2138 = call float @dx.op.binary.f32(i32 36, float %12, float %2137)  ; FMin(a,b)
  %2139 = fsub fast float %13, %1965
  %2140 = fsub fast float %14, %1966
  %2141 = fsub fast float %15, %1967
  %2142 = fmul fast float %2138, %2139
  %2143 = fmul fast float %2138, %2140
  %2144 = fmul fast float %2138, %2141
  %2145 = fadd fast float %2142, %1965
  %2146 = fadd fast float %2143, %1966
  %2147 = fadd fast float %2144, %1967
  br label %2148

; <label>:2148                                    ; preds = %2131, %2010, %2004
  %2149 = phi float [ %2145, %2131 ], [ %1965, %2010 ], [ %1965, %2004 ]
  %2150 = phi float [ %2146, %2131 ], [ %1966, %2010 ], [ %1966, %2004 ]
  %2151 = phi float [ %2147, %2131 ], [ %1967, %2010 ], [ %1967, %2004 ]
  %2152 = fadd fast float %5, 1.000000e+00
  %2153 = fadd fast float %6, 1.000000e+00
  %2154 = fsub fast float 1.000000e+00, %5
  %2155 = fmul fast float %36, %2152
  %2156 = fmul fast float %36, %2153
  %2157 = fmul fast float %36, %2154
  %2158 = fmul fast float %2155, %2149
  %2159 = fmul fast float %2156, %2150
  %2160 = fmul fast float %2157, %2151
  %2161 = fcmp fast ult float %37, 5.000000e-01
  br i1 %2161, label %2187, label %2162

; <label>:2162                                    ; preds = %2148
  %2163 = fmul fast float %2158, 0x4004147AE0000000
  %2164 = fmul fast float %2159, 0x4004147AE0000000
  %2165 = fmul fast float %2160, 0x4004147AE0000000
  %2166 = fadd fast float %2163, 0x3F9EB851E0000000
  %2167 = fadd fast float %2164, 0x3F9EB851E0000000
  %2168 = fadd fast float %2165, 0x3F9EB851E0000000
  %2169 = fmul fast float %2166, %2158
  %2170 = fmul fast float %2167, %2159
  %2171 = fmul fast float %2168, %2160
  %2172 = fmul fast float %2158, 0x400370A3E0000000
  %2173 = fmul fast float %2159, 0x400370A3E0000000
  %2174 = fmul fast float %2160, 0x400370A3E0000000
  %2175 = fadd fast float %2172, 0x3FE2E147A0000000
  %2176 = fadd fast float %2173, 0x3FE2E147A0000000
  %2177 = fadd fast float %2174, 0x3FE2E147A0000000
  %2178 = fmul fast float %2175, %2158
  %2179 = fmul fast float %2176, %2159
  %2180 = fmul fast float %2177, %2160
  %2181 = fadd fast float %2178, 0x3FC1EB8520000000
  %2182 = fadd fast float %2179, 0x3FC1EB8520000000
  %2183 = fadd fast float %2180, 0x3FC1EB8520000000
  %2184 = fdiv fast float %2169, %2181
  %2185 = fdiv fast float %2170, %2182
  %2186 = fdiv fast float %2171, %2183
  br label %2187

; <label>:2187                                    ; preds = %2162, %2148
  %2188 = phi float [ %2184, %2162 ], [ %2158, %2148 ]
  %2189 = phi float [ %2185, %2162 ], [ %2159, %2148 ]
  %2190 = phi float [ %2186, %2162 ], [ %2160, %2148 ]
  %2191 = call float @dx.op.unary.f32(i32 7, float %2188)  ; Saturate(value)
  %2192 = call float @dx.op.unary.f32(i32 7, float %2189)  ; Saturate(value)
  %2193 = call float @dx.op.unary.f32(i32 7, float %2190)  ; Saturate(value)
  %2194 = call float @dx.op.dot3.f32(i32 55, float %2191, float %2192, float %2193, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2195 = fsub fast float %2191, %2194
  %2196 = fsub fast float %2192, %2194
  %2197 = fsub fast float %2193, %2194
  %2198 = fmul fast float %2195, %8
  %2199 = fmul fast float %2196, %8
  %2200 = fmul fast float %2197, %8
  %2201 = fadd fast float %2198, %2194
  %2202 = fadd fast float %2199, %2194
  %2203 = fadd fast float %2200, %2194
  %2204 = call float @dx.op.unary.f32(i32 7, float %2201)  ; Saturate(value)
  %2205 = call float @dx.op.unary.f32(i32 7, float %2202)  ; Saturate(value)
  %2206 = call float @dx.op.unary.f32(i32 7, float %2203)  ; Saturate(value)
  %2207 = fadd fast float %2204, 0xBFC70A3D80000000
  %2208 = fadd fast float %2205, 0xBFC70A3D80000000
  %2209 = fadd fast float %2206, 0xBFC70A3D80000000
  %2210 = fmul fast float %2207, %7
  %2211 = fmul fast float %2208, %7
  %2212 = fmul fast float %2209, %7
  %2213 = fadd fast float %2210, 0x3FC70A3D80000000
  %2214 = fadd fast float %2211, 0x3FC70A3D80000000
  %2215 = fadd fast float %2212, 0x3FC70A3D80000000
  %2216 = call float @dx.op.unary.f32(i32 7, float %2213)  ; Saturate(value)
  %2217 = call float @dx.op.unary.f32(i32 7, float %2214)  ; Saturate(value)
  %2218 = call float @dx.op.unary.f32(i32 7, float %2215)  ; Saturate(value)
  br label %2219

; <label>:2219                                    ; preds = %2187, %1970
  %2220 = phi float [ %2001, %1970 ], [ %2216, %2187 ]
  %2221 = phi float [ %2002, %1970 ], [ %2217, %2187 ]
  %2222 = phi float [ %2003, %1970 ], [ %2218, %2187 ]
  %2223 = fsub fast float %2220, %1940
  %2224 = fsub fast float %2221, %1941
  %2225 = fsub fast float %2222, %1942
  %2226 = fmul fast float %2223, %1957
  %2227 = fmul fast float %2224, %1957
  %2228 = fmul fast float %2225, %1957
  %2229 = fadd fast float %2226, %1940
  %2230 = fadd fast float %2227, %1941
  %2231 = fadd fast float %2228, %1942
  br label %2232

; <label>:2232                                    ; preds = %2219, %1911
  %2233 = phi float [ %2229, %2219 ], [ %1940, %1911 ]
  %2234 = phi float [ %2230, %2219 ], [ %1941, %1911 ]
  %2235 = phi float [ %2231, %2219 ], [ %1942, %1911 ]
  %2236 = add i32 %64, 1
  %2237 = call i32 @dx.op.binary.i32(i32 37, i32 %2236, i32 0)  ; IMax(a,b)
  %2238 = call i32 @dx.op.binary.i32(i32 38, i32 %2237, i32 %60)  ; IMin(a,b)
  %2239 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1946, i32 %2238, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2240 = extractvalue %dx.types.ResRet.f32 %2239, 0
  %2241 = fsub fast float %2240, %84
  %2242 = call float @dx.op.unary.f32(i32 6, float %2241)  ; FAbs(value)
  %2243 = fdiv fast float %2242, %1952
  %2244 = fsub fast float 1.000000e+00, %2243
  %2245 = call float @dx.op.unary.f32(i32 7, float %2244)  ; Saturate(value)
  %2246 = fcmp fast ugt float %2245, 0.000000e+00
  br i1 %2246, label %2247, label %2520

; <label>:2247                                    ; preds = %2232
  %2248 = call i32 @dx.op.binary.i32(i32 37, i32 %1946, i32 0)  ; IMax(a,b)
  %2249 = call i32 @dx.op.binary.i32(i32 37, i32 %2238, i32 0)  ; IMax(a,b)
  %2250 = call i32 @dx.op.binary.i32(i32 38, i32 %2248, i32 %59)  ; IMin(a,b)
  %2251 = call i32 @dx.op.binary.i32(i32 38, i32 %2249, i32 %60)  ; IMin(a,b)
  %2252 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2250, i32 %2251, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2253 = extractvalue %dx.types.ResRet.f32 %2252, 0
  %2254 = extractvalue %dx.types.ResRet.f32 %2252, 1
  %2255 = extractvalue %dx.types.ResRet.f32 %2252, 2
  %2256 = extractvalue %dx.types.ResRet.f32 %2252, 3
  %2257 = fcmp fast olt float %2256, 0.000000e+00
  br i1 %2257, label %2258, label %2292

; <label>:2258                                    ; preds = %2247
  %2259 = fcmp fast ogt float %2253, 0x3FA4B5DCC0000000
  %2260 = fcmp fast ogt float %2254, 0x3FA4B5DCC0000000
  %2261 = fcmp fast ogt float %2255, 0x3FA4B5DCC0000000
  %2262 = select i1 %2259, float 0.000000e+00, float 1.000000e+00
  %2263 = select i1 %2260, float 0.000000e+00, float 1.000000e+00
  %2264 = select i1 %2261, float 0.000000e+00, float 1.000000e+00
  %2265 = fmul fast float %2253, 0x3FB3D07220000000
  %2266 = fmul fast float %2254, 0x3FB3D07220000000
  %2267 = fmul fast float %2255, 0x3FB3D07220000000
  %2268 = fadd fast float %2253, 0x3FAC28F5C0000000
  %2269 = fadd fast float %2254, 0x3FAC28F5C0000000
  %2270 = fadd fast float %2255, 0x3FAC28F5C0000000
  %2271 = fmul fast float %2268, 0x3FEE54EDE0000000
  %2272 = fmul fast float %2269, 0x3FEE54EDE0000000
  %2273 = fmul fast float %2270, 0x3FEE54EDE0000000
  %2274 = call float @dx.op.unary.f32(i32 23, float %2271)  ; Log(value)
  %2275 = call float @dx.op.unary.f32(i32 23, float %2272)  ; Log(value)
  %2276 = call float @dx.op.unary.f32(i32 23, float %2273)  ; Log(value)
  %2277 = fmul fast float %2274, 0x4003333340000000
  %2278 = fmul fast float %2275, 0x4003333340000000
  %2279 = fmul fast float %2276, 0x4003333340000000
  %2280 = call float @dx.op.unary.f32(i32 21, float %2277)  ; Exp(value)
  %2281 = call float @dx.op.unary.f32(i32 21, float %2278)  ; Exp(value)
  %2282 = call float @dx.op.unary.f32(i32 21, float %2279)  ; Exp(value)
  %2283 = fsub fast float %2265, %2280
  %2284 = fsub fast float %2266, %2281
  %2285 = fsub fast float %2267, %2282
  %2286 = fmul fast float %2283, %2262
  %2287 = fmul fast float %2284, %2263
  %2288 = fmul fast float %2285, %2264
  %2289 = fadd fast float %2286, %2280
  %2290 = fadd fast float %2287, %2281
  %2291 = fadd fast float %2288, %2282
  br label %2507

; <label>:2292                                    ; preds = %2247
  %2293 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2250, i32 %2251, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2294 = extractvalue %dx.types.ResRet.f32 %2293, 0
  %2295 = fcmp fast ogt float %38, 5.000000e-01
  %2296 = fcmp fast olt float %2294, 1.000000e+00
  %2297 = and i1 %2295, %2296
  br i1 %2297, label %2298, label %2436

; <label>:2298                                    ; preds = %2292
  %2299 = sitofp i32 %2250 to float
  %2300 = sitofp i32 %2251 to float
  %2301 = fadd fast float %2299, 5.000000e-01
  %2302 = fadd fast float %2300, 5.000000e-01
  %2303 = fdiv fast float %2301, %45
  %2304 = fdiv fast float %2302, %46
  %2305 = fmul fast float %2303, 2.000000e+00
  %2306 = fmul fast float %2304, 2.000000e+00
  %2307 = fadd fast float %2305, -1.000000e+00
  %2308 = fsub fast float 1.000000e+00, %2306
  %2309 = fmul fast float %2307, %35
  %2310 = call float @dx.op.tertiary.f32(i32 46, float %2308, float %31, float %2309)  ; FMad(a,b,c)
  %2311 = call float @dx.op.tertiary.f32(i32 46, float %2294, float %27, float %2310)  ; FMad(a,b,c)
  %2312 = fadd fast float %2311, %23
  %2313 = call float @dx.op.unary.f32(i32 6, float %2312)  ; FAbs(value)
  %2314 = fcmp fast ogt float %2313, 0x3EB0C6F7A0000000
  br i1 %2314, label %2315, label %2436

; <label>:2315                                    ; preds = %2298
  %2316 = fmul fast float %2307, %34
  %2317 = call float @dx.op.tertiary.f32(i32 46, float %2308, float %30, float %2316)  ; FMad(a,b,c)
  %2318 = call float @dx.op.tertiary.f32(i32 46, float %2294, float %26, float %2317)  ; FMad(a,b,c)
  %2319 = fadd fast float %2318, %22
  %2320 = fmul fast float %2307, %33
  %2321 = call float @dx.op.tertiary.f32(i32 46, float %2308, float %29, float %2320)  ; FMad(a,b,c)
  %2322 = call float @dx.op.tertiary.f32(i32 46, float %2294, float %25, float %2321)  ; FMad(a,b,c)
  %2323 = fadd fast float %2322, %21
  %2324 = fmul fast float %2307, %32
  %2325 = call float @dx.op.tertiary.f32(i32 46, float %2308, float %28, float %2324)  ; FMad(a,b,c)
  %2326 = call float @dx.op.tertiary.f32(i32 46, float %2294, float %24, float %2325)  ; FMad(a,b,c)
  %2327 = fadd fast float %2326, %20
  %2328 = fdiv fast float %2327, %2312
  %2329 = fdiv fast float %2323, %2312
  %2330 = fdiv fast float %2319, %2312
  %2331 = fsub fast float %2328, %17
  %2332 = fsub fast float %2329, %18
  %2333 = fsub fast float %2330, %19
  %2334 = fmul fast float %2331, %2331
  %2335 = fmul fast float %2332, %2332
  %2336 = fadd fast float %2335, %2334
  %2337 = fmul fast float %2333, %2333
  %2338 = fadd fast float %2336, %2337
  %2339 = call float @dx.op.unary.f32(i32 24, float %2338)  ; Sqrt(value)
  %2340 = fsub fast float %2339, %9
  %2341 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2340)  ; FMax(a,b)
  %2342 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %2342, label %2343, label %2366

; <label>:2343                                    ; preds = %2315
  %2344 = call float @dx.op.unary.f32(i32 6, float %2332)  ; FAbs(value)
  %2345 = fmul fast float %2344, %11
  %2346 = fcmp fast olt float %2345, 0x3F50624DE0000000
  br i1 %2346, label %2347, label %2350

; <label>:2347                                    ; preds = %2343
  %2348 = fmul fast float %2345, 5.000000e-01
  %2349 = fsub fast float 1.000000e+00, %2348
  br label %2355

; <label>:2350                                    ; preds = %2343
  %2351 = fmul fast float %2345, 0xBFF7154760000000
  %2352 = call float @dx.op.unary.f32(i32 21, float %2351)  ; Exp(value)
  %2353 = fsub fast float 1.000000e+00, %2352
  %2354 = fdiv fast float %2353, %2345
  br label %2355

; <label>:2355                                    ; preds = %2350, %2347
  %2356 = phi float [ %2349, %2347 ], [ %2354, %2350 ]
  %2357 = call float @dx.op.binary.f32(i32 36, float %2329, float %18)  ; FMin(a,b)
  %2358 = fsub fast float %2357, %10
  %2359 = fmul fast float %11, %2358
  %2360 = fsub fast float -0.000000e+00, %2359
  %2361 = call float @dx.op.binary.f32(i32 35, float %2360, float -4.000000e+01)  ; FMax(a,b)
  %2362 = call float @dx.op.binary.f32(i32 36, float %2361, float 5.000000e+00)  ; FMin(a,b)
  %2363 = fmul fast float %2362, 0x3FF7154760000000
  %2364 = call float @dx.op.unary.f32(i32 21, float %2363)  ; Exp(value)
  %2365 = fmul fast float %2364, %2356
  br label %2366

; <label>:2366                                    ; preds = %2355, %2315
  %2367 = phi float [ %2365, %2355 ], [ 1.000000e+00, %2315 ]
  %2368 = fmul fast float %2341, %16
  %2369 = fmul fast float %2368, %2367
  %2370 = fcmp fast ole float %2339, %9
  %2371 = fcmp fast olt float %2339, 0x3F1A36E2E0000000
  %2372 = or i1 %2370, %2371
  br i1 %2372, label %2419, label %2373

; <label>:2373                                    ; preds = %2366
  %2374 = fdiv fast float %9, %2339
  %2375 = fmul fast float %2374, %2331
  %2376 = fmul fast float %2374, %2332
  %2377 = fmul fast float %2374, %2333
  %2378 = fadd fast float %2375, %17
  %2379 = fadd fast float %2376, %18
  %2380 = fadd fast float %2377, %19
  %2381 = fadd fast float %2378, -9.000000e+02
  %2382 = fadd fast float %2379, -1.500000e+01
  %2383 = fadd fast float %2380, -7.500000e+02
  %2384 = fmul fast float %2381, 0x3F62345680000000
  %2385 = fmul fast float %2382, 0x3F62345680000000
  %2386 = fmul fast float %2383, 0x3F62345680000000
  %2387 = call float @dx.op.dot3.f32(i32 55, float %2384, float %2385, float %2386, float %2384, float %2385, float %2386)  ; Dot3(ax,ay,az,bx,by,bz)
  %2388 = fsub fast float 1.000000e+00, %2387
  %2389 = call float @dx.op.unary.f32(i32 7, float %2388)  ; Saturate(value)
  %2390 = fmul fast float %2389, %2389
  %2391 = fadd fast float %2378, %2328
  %2392 = fadd fast float %2379, %2329
  %2393 = fadd fast float %2380, %2330
  %2394 = fmul fast float %2391, 0x3F52345680000000
  %2395 = fadd fast float %2394, -2.000000e+00
  %2396 = fmul fast float %2392, 0x3F52345680000000
  %2397 = fadd fast float %2396, 0xBFA1111120000000
  %2398 = fmul fast float %2393, 0x3F52345680000000
  %2399 = fadd fast float %2398, 0xBFFAAAAAC0000000
  %2400 = call float @dx.op.dot3.f32(i32 55, float %2395, float %2397, float %2399, float %2395, float %2397, float %2399)  ; Dot3(ax,ay,az,bx,by,bz)
  %2401 = fsub fast float 1.000000e+00, %2400
  %2402 = call float @dx.op.unary.f32(i32 7, float %2401)  ; Saturate(value)
  %2403 = fmul fast float %2402, %2402
  %2404 = fmul fast float %2403, 4.000000e+00
  %2405 = fadd fast float %2404, %2390
  %2406 = fadd fast float %2328, -9.000000e+02
  %2407 = fadd fast float %2329, -1.500000e+01
  %2408 = fadd fast float %2330, -7.500000e+02
  %2409 = fmul fast float %2406, 0x3F62345680000000
  %2410 = fmul fast float %2407, 0x3F62345680000000
  %2411 = fmul fast float %2408, 0x3F62345680000000
  %2412 = call float @dx.op.dot3.f32(i32 55, float %2409, float %2410, float %2411, float %2409, float %2410, float %2411)  ; Dot3(ax,ay,az,bx,by,bz)
  %2413 = fsub fast float 1.000000e+00, %2412
  %2414 = call float @dx.op.unary.f32(i32 7, float %2413)  ; Saturate(value)
  %2415 = fmul fast float %2414, %2414
  %2416 = fadd fast float %2405, %2415
  %2417 = fmul fast float %2340, 0x3F25D867E0000000
  %2418 = fmul fast float %2417, %2416
  br label %2419

; <label>:2419                                    ; preds = %2373, %2366
  %2420 = phi float [ %2418, %2373 ], [ 0.000000e+00, %2366 ]
  %2421 = fadd fast float %2420, %2369
  %2422 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2421)  ; FMin(a,b)
  %2423 = fmul fast float %2422, 0xBFF7154760000000
  %2424 = call float @dx.op.unary.f32(i32 21, float %2423)  ; Exp(value)
  %2425 = fsub fast float 1.000000e+00, %2424
  %2426 = call float @dx.op.binary.f32(i32 36, float %12, float %2425)  ; FMin(a,b)
  %2427 = fsub fast float %13, %2253
  %2428 = fsub fast float %14, %2254
  %2429 = fsub fast float %15, %2255
  %2430 = fmul fast float %2426, %2427
  %2431 = fmul fast float %2426, %2428
  %2432 = fmul fast float %2426, %2429
  %2433 = fadd fast float %2430, %2253
  %2434 = fadd fast float %2431, %2254
  %2435 = fadd fast float %2432, %2255
  br label %2436

; <label>:2436                                    ; preds = %2419, %2298, %2292
  %2437 = phi float [ %2433, %2419 ], [ %2253, %2298 ], [ %2253, %2292 ]
  %2438 = phi float [ %2434, %2419 ], [ %2254, %2298 ], [ %2254, %2292 ]
  %2439 = phi float [ %2435, %2419 ], [ %2255, %2298 ], [ %2255, %2292 ]
  %2440 = fadd fast float %5, 1.000000e+00
  %2441 = fadd fast float %6, 1.000000e+00
  %2442 = fsub fast float 1.000000e+00, %5
  %2443 = fmul fast float %36, %2440
  %2444 = fmul fast float %36, %2441
  %2445 = fmul fast float %36, %2442
  %2446 = fmul fast float %2443, %2437
  %2447 = fmul fast float %2444, %2438
  %2448 = fmul fast float %2445, %2439
  %2449 = fcmp fast ult float %37, 5.000000e-01
  br i1 %2449, label %2475, label %2450

; <label>:2450                                    ; preds = %2436
  %2451 = fmul fast float %2446, 0x4004147AE0000000
  %2452 = fmul fast float %2447, 0x4004147AE0000000
  %2453 = fmul fast float %2448, 0x4004147AE0000000
  %2454 = fadd fast float %2451, 0x3F9EB851E0000000
  %2455 = fadd fast float %2452, 0x3F9EB851E0000000
  %2456 = fadd fast float %2453, 0x3F9EB851E0000000
  %2457 = fmul fast float %2454, %2446
  %2458 = fmul fast float %2455, %2447
  %2459 = fmul fast float %2456, %2448
  %2460 = fmul fast float %2446, 0x400370A3E0000000
  %2461 = fmul fast float %2447, 0x400370A3E0000000
  %2462 = fmul fast float %2448, 0x400370A3E0000000
  %2463 = fadd fast float %2460, 0x3FE2E147A0000000
  %2464 = fadd fast float %2461, 0x3FE2E147A0000000
  %2465 = fadd fast float %2462, 0x3FE2E147A0000000
  %2466 = fmul fast float %2463, %2446
  %2467 = fmul fast float %2464, %2447
  %2468 = fmul fast float %2465, %2448
  %2469 = fadd fast float %2466, 0x3FC1EB8520000000
  %2470 = fadd fast float %2467, 0x3FC1EB8520000000
  %2471 = fadd fast float %2468, 0x3FC1EB8520000000
  %2472 = fdiv fast float %2457, %2469
  %2473 = fdiv fast float %2458, %2470
  %2474 = fdiv fast float %2459, %2471
  br label %2475

; <label>:2475                                    ; preds = %2450, %2436
  %2476 = phi float [ %2472, %2450 ], [ %2446, %2436 ]
  %2477 = phi float [ %2473, %2450 ], [ %2447, %2436 ]
  %2478 = phi float [ %2474, %2450 ], [ %2448, %2436 ]
  %2479 = call float @dx.op.unary.f32(i32 7, float %2476)  ; Saturate(value)
  %2480 = call float @dx.op.unary.f32(i32 7, float %2477)  ; Saturate(value)
  %2481 = call float @dx.op.unary.f32(i32 7, float %2478)  ; Saturate(value)
  %2482 = call float @dx.op.dot3.f32(i32 55, float %2479, float %2480, float %2481, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2483 = fsub fast float %2479, %2482
  %2484 = fsub fast float %2480, %2482
  %2485 = fsub fast float %2481, %2482
  %2486 = fmul fast float %2483, %8
  %2487 = fmul fast float %2484, %8
  %2488 = fmul fast float %2485, %8
  %2489 = fadd fast float %2486, %2482
  %2490 = fadd fast float %2487, %2482
  %2491 = fadd fast float %2488, %2482
  %2492 = call float @dx.op.unary.f32(i32 7, float %2489)  ; Saturate(value)
  %2493 = call float @dx.op.unary.f32(i32 7, float %2490)  ; Saturate(value)
  %2494 = call float @dx.op.unary.f32(i32 7, float %2491)  ; Saturate(value)
  %2495 = fadd fast float %2492, 0xBFC70A3D80000000
  %2496 = fadd fast float %2493, 0xBFC70A3D80000000
  %2497 = fadd fast float %2494, 0xBFC70A3D80000000
  %2498 = fmul fast float %2495, %7
  %2499 = fmul fast float %2496, %7
  %2500 = fmul fast float %2497, %7
  %2501 = fadd fast float %2498, 0x3FC70A3D80000000
  %2502 = fadd fast float %2499, 0x3FC70A3D80000000
  %2503 = fadd fast float %2500, 0x3FC70A3D80000000
  %2504 = call float @dx.op.unary.f32(i32 7, float %2501)  ; Saturate(value)
  %2505 = call float @dx.op.unary.f32(i32 7, float %2502)  ; Saturate(value)
  %2506 = call float @dx.op.unary.f32(i32 7, float %2503)  ; Saturate(value)
  br label %2507

; <label>:2507                                    ; preds = %2475, %2258
  %2508 = phi float [ %2289, %2258 ], [ %2504, %2475 ]
  %2509 = phi float [ %2290, %2258 ], [ %2505, %2475 ]
  %2510 = phi float [ %2291, %2258 ], [ %2506, %2475 ]
  %2511 = fsub fast float %2508, %1940
  %2512 = fsub fast float %2509, %1941
  %2513 = fsub fast float %2510, %1942
  %2514 = fmul fast float %2511, %2245
  %2515 = fmul fast float %2512, %2245
  %2516 = fmul fast float %2513, %2245
  %2517 = fadd fast float %2514, %1940
  %2518 = fadd fast float %2515, %1941
  %2519 = fadd fast float %2516, %1942
  br label %2520

; <label>:2520                                    ; preds = %2507, %2232
  %2521 = phi float [ %2517, %2507 ], [ %1940, %2232 ]
  %2522 = phi float [ %2518, %2507 ], [ %1941, %2232 ]
  %2523 = phi float [ %2519, %2507 ], [ %1942, %2232 ]
  %2524 = add i32 %67, -1
  %2525 = call i32 @dx.op.binary.i32(i32 37, i32 %2524, i32 0)  ; IMax(a,b)
  %2526 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %2527 = call i32 @dx.op.binary.i32(i32 38, i32 %2525, i32 %59)  ; IMin(a,b)
  %2528 = call i32 @dx.op.binary.i32(i32 38, i32 %2526, i32 %60)  ; IMin(a,b)
  %2529 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2527, i32 %2528, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2530 = extractvalue %dx.types.ResRet.f32 %2529, 0
  %2531 = fsub fast float %2530, %84
  %2532 = call float @dx.op.unary.f32(i32 6, float %2531)  ; FAbs(value)
  %2533 = fdiv fast float %2532, %1952
  %2534 = fsub fast float 1.000000e+00, %2533
  %2535 = call float @dx.op.unary.f32(i32 7, float %2534)  ; Saturate(value)
  %2536 = fcmp fast ugt float %2535, 0.000000e+00
  br i1 %2536, label %2537, label %2810

; <label>:2537                                    ; preds = %2520
  %2538 = call i32 @dx.op.binary.i32(i32 37, i32 %2527, i32 0)  ; IMax(a,b)
  %2539 = call i32 @dx.op.binary.i32(i32 37, i32 %2528, i32 0)  ; IMax(a,b)
  %2540 = call i32 @dx.op.binary.i32(i32 38, i32 %2538, i32 %59)  ; IMin(a,b)
  %2541 = call i32 @dx.op.binary.i32(i32 38, i32 %2539, i32 %60)  ; IMin(a,b)
  %2542 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2540, i32 %2541, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2543 = extractvalue %dx.types.ResRet.f32 %2542, 0
  %2544 = extractvalue %dx.types.ResRet.f32 %2542, 1
  %2545 = extractvalue %dx.types.ResRet.f32 %2542, 2
  %2546 = extractvalue %dx.types.ResRet.f32 %2542, 3
  %2547 = fcmp fast olt float %2546, 0.000000e+00
  br i1 %2547, label %2548, label %2582

; <label>:2548                                    ; preds = %2537
  %2549 = fcmp fast ogt float %2543, 0x3FA4B5DCC0000000
  %2550 = fcmp fast ogt float %2544, 0x3FA4B5DCC0000000
  %2551 = fcmp fast ogt float %2545, 0x3FA4B5DCC0000000
  %2552 = select i1 %2549, float 0.000000e+00, float 1.000000e+00
  %2553 = select i1 %2550, float 0.000000e+00, float 1.000000e+00
  %2554 = select i1 %2551, float 0.000000e+00, float 1.000000e+00
  %2555 = fmul fast float %2543, 0x3FB3D07220000000
  %2556 = fmul fast float %2544, 0x3FB3D07220000000
  %2557 = fmul fast float %2545, 0x3FB3D07220000000
  %2558 = fadd fast float %2543, 0x3FAC28F5C0000000
  %2559 = fadd fast float %2544, 0x3FAC28F5C0000000
  %2560 = fadd fast float %2545, 0x3FAC28F5C0000000
  %2561 = fmul fast float %2558, 0x3FEE54EDE0000000
  %2562 = fmul fast float %2559, 0x3FEE54EDE0000000
  %2563 = fmul fast float %2560, 0x3FEE54EDE0000000
  %2564 = call float @dx.op.unary.f32(i32 23, float %2561)  ; Log(value)
  %2565 = call float @dx.op.unary.f32(i32 23, float %2562)  ; Log(value)
  %2566 = call float @dx.op.unary.f32(i32 23, float %2563)  ; Log(value)
  %2567 = fmul fast float %2564, 0x4003333340000000
  %2568 = fmul fast float %2565, 0x4003333340000000
  %2569 = fmul fast float %2566, 0x4003333340000000
  %2570 = call float @dx.op.unary.f32(i32 21, float %2567)  ; Exp(value)
  %2571 = call float @dx.op.unary.f32(i32 21, float %2568)  ; Exp(value)
  %2572 = call float @dx.op.unary.f32(i32 21, float %2569)  ; Exp(value)
  %2573 = fsub fast float %2555, %2570
  %2574 = fsub fast float %2556, %2571
  %2575 = fsub fast float %2557, %2572
  %2576 = fmul fast float %2573, %2552
  %2577 = fmul fast float %2574, %2553
  %2578 = fmul fast float %2575, %2554
  %2579 = fadd fast float %2576, %2570
  %2580 = fadd fast float %2577, %2571
  %2581 = fadd fast float %2578, %2572
  br label %2797

; <label>:2582                                    ; preds = %2537
  %2583 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2540, i32 %2541, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2584 = extractvalue %dx.types.ResRet.f32 %2583, 0
  %2585 = fcmp fast ogt float %38, 5.000000e-01
  %2586 = fcmp fast olt float %2584, 1.000000e+00
  %2587 = and i1 %2585, %2586
  br i1 %2587, label %2588, label %2726

; <label>:2588                                    ; preds = %2582
  %2589 = sitofp i32 %2540 to float
  %2590 = sitofp i32 %2541 to float
  %2591 = fadd fast float %2589, 5.000000e-01
  %2592 = fadd fast float %2590, 5.000000e-01
  %2593 = fdiv fast float %2591, %45
  %2594 = fdiv fast float %2592, %46
  %2595 = fmul fast float %2593, 2.000000e+00
  %2596 = fmul fast float %2594, 2.000000e+00
  %2597 = fadd fast float %2595, -1.000000e+00
  %2598 = fsub fast float 1.000000e+00, %2596
  %2599 = fmul fast float %2597, %35
  %2600 = call float @dx.op.tertiary.f32(i32 46, float %2598, float %31, float %2599)  ; FMad(a,b,c)
  %2601 = call float @dx.op.tertiary.f32(i32 46, float %2584, float %27, float %2600)  ; FMad(a,b,c)
  %2602 = fadd fast float %2601, %23
  %2603 = call float @dx.op.unary.f32(i32 6, float %2602)  ; FAbs(value)
  %2604 = fcmp fast ogt float %2603, 0x3EB0C6F7A0000000
  br i1 %2604, label %2605, label %2726

; <label>:2605                                    ; preds = %2588
  %2606 = fmul fast float %2597, %34
  %2607 = call float @dx.op.tertiary.f32(i32 46, float %2598, float %30, float %2606)  ; FMad(a,b,c)
  %2608 = call float @dx.op.tertiary.f32(i32 46, float %2584, float %26, float %2607)  ; FMad(a,b,c)
  %2609 = fadd fast float %2608, %22
  %2610 = fmul fast float %2597, %33
  %2611 = call float @dx.op.tertiary.f32(i32 46, float %2598, float %29, float %2610)  ; FMad(a,b,c)
  %2612 = call float @dx.op.tertiary.f32(i32 46, float %2584, float %25, float %2611)  ; FMad(a,b,c)
  %2613 = fadd fast float %2612, %21
  %2614 = fmul fast float %2597, %32
  %2615 = call float @dx.op.tertiary.f32(i32 46, float %2598, float %28, float %2614)  ; FMad(a,b,c)
  %2616 = call float @dx.op.tertiary.f32(i32 46, float %2584, float %24, float %2615)  ; FMad(a,b,c)
  %2617 = fadd fast float %2616, %20
  %2618 = fdiv fast float %2617, %2602
  %2619 = fdiv fast float %2613, %2602
  %2620 = fdiv fast float %2609, %2602
  %2621 = fsub fast float %2618, %17
  %2622 = fsub fast float %2619, %18
  %2623 = fsub fast float %2620, %19
  %2624 = fmul fast float %2621, %2621
  %2625 = fmul fast float %2622, %2622
  %2626 = fadd fast float %2625, %2624
  %2627 = fmul fast float %2623, %2623
  %2628 = fadd fast float %2626, %2627
  %2629 = call float @dx.op.unary.f32(i32 24, float %2628)  ; Sqrt(value)
  %2630 = fsub fast float %2629, %9
  %2631 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2630)  ; FMax(a,b)
  %2632 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %2632, label %2633, label %2656

; <label>:2633                                    ; preds = %2605
  %2634 = call float @dx.op.unary.f32(i32 6, float %2622)  ; FAbs(value)
  %2635 = fmul fast float %2634, %11
  %2636 = fcmp fast olt float %2635, 0x3F50624DE0000000
  br i1 %2636, label %2637, label %2640

; <label>:2637                                    ; preds = %2633
  %2638 = fmul fast float %2635, 5.000000e-01
  %2639 = fsub fast float 1.000000e+00, %2638
  br label %2645

; <label>:2640                                    ; preds = %2633
  %2641 = fmul fast float %2635, 0xBFF7154760000000
  %2642 = call float @dx.op.unary.f32(i32 21, float %2641)  ; Exp(value)
  %2643 = fsub fast float 1.000000e+00, %2642
  %2644 = fdiv fast float %2643, %2635
  br label %2645

; <label>:2645                                    ; preds = %2640, %2637
  %2646 = phi float [ %2639, %2637 ], [ %2644, %2640 ]
  %2647 = call float @dx.op.binary.f32(i32 36, float %2619, float %18)  ; FMin(a,b)
  %2648 = fsub fast float %2647, %10
  %2649 = fmul fast float %11, %2648
  %2650 = fsub fast float -0.000000e+00, %2649
  %2651 = call float @dx.op.binary.f32(i32 35, float %2650, float -4.000000e+01)  ; FMax(a,b)
  %2652 = call float @dx.op.binary.f32(i32 36, float %2651, float 5.000000e+00)  ; FMin(a,b)
  %2653 = fmul fast float %2652, 0x3FF7154760000000
  %2654 = call float @dx.op.unary.f32(i32 21, float %2653)  ; Exp(value)
  %2655 = fmul fast float %2654, %2646
  br label %2656

; <label>:2656                                    ; preds = %2645, %2605
  %2657 = phi float [ %2655, %2645 ], [ 1.000000e+00, %2605 ]
  %2658 = fmul fast float %2631, %16
  %2659 = fmul fast float %2658, %2657
  %2660 = fcmp fast ole float %2629, %9
  %2661 = fcmp fast olt float %2629, 0x3F1A36E2E0000000
  %2662 = or i1 %2660, %2661
  br i1 %2662, label %2709, label %2663

; <label>:2663                                    ; preds = %2656
  %2664 = fdiv fast float %9, %2629
  %2665 = fmul fast float %2664, %2621
  %2666 = fmul fast float %2664, %2622
  %2667 = fmul fast float %2664, %2623
  %2668 = fadd fast float %2665, %17
  %2669 = fadd fast float %2666, %18
  %2670 = fadd fast float %2667, %19
  %2671 = fadd fast float %2668, -9.000000e+02
  %2672 = fadd fast float %2669, -1.500000e+01
  %2673 = fadd fast float %2670, -7.500000e+02
  %2674 = fmul fast float %2671, 0x3F62345680000000
  %2675 = fmul fast float %2672, 0x3F62345680000000
  %2676 = fmul fast float %2673, 0x3F62345680000000
  %2677 = call float @dx.op.dot3.f32(i32 55, float %2674, float %2675, float %2676, float %2674, float %2675, float %2676)  ; Dot3(ax,ay,az,bx,by,bz)
  %2678 = fsub fast float 1.000000e+00, %2677
  %2679 = call float @dx.op.unary.f32(i32 7, float %2678)  ; Saturate(value)
  %2680 = fmul fast float %2679, %2679
  %2681 = fadd fast float %2668, %2618
  %2682 = fadd fast float %2669, %2619
  %2683 = fadd fast float %2670, %2620
  %2684 = fmul fast float %2681, 0x3F52345680000000
  %2685 = fadd fast float %2684, -2.000000e+00
  %2686 = fmul fast float %2682, 0x3F52345680000000
  %2687 = fadd fast float %2686, 0xBFA1111120000000
  %2688 = fmul fast float %2683, 0x3F52345680000000
  %2689 = fadd fast float %2688, 0xBFFAAAAAC0000000
  %2690 = call float @dx.op.dot3.f32(i32 55, float %2685, float %2687, float %2689, float %2685, float %2687, float %2689)  ; Dot3(ax,ay,az,bx,by,bz)
  %2691 = fsub fast float 1.000000e+00, %2690
  %2692 = call float @dx.op.unary.f32(i32 7, float %2691)  ; Saturate(value)
  %2693 = fmul fast float %2692, %2692
  %2694 = fmul fast float %2693, 4.000000e+00
  %2695 = fadd fast float %2694, %2680
  %2696 = fadd fast float %2618, -9.000000e+02
  %2697 = fadd fast float %2619, -1.500000e+01
  %2698 = fadd fast float %2620, -7.500000e+02
  %2699 = fmul fast float %2696, 0x3F62345680000000
  %2700 = fmul fast float %2697, 0x3F62345680000000
  %2701 = fmul fast float %2698, 0x3F62345680000000
  %2702 = call float @dx.op.dot3.f32(i32 55, float %2699, float %2700, float %2701, float %2699, float %2700, float %2701)  ; Dot3(ax,ay,az,bx,by,bz)
  %2703 = fsub fast float 1.000000e+00, %2702
  %2704 = call float @dx.op.unary.f32(i32 7, float %2703)  ; Saturate(value)
  %2705 = fmul fast float %2704, %2704
  %2706 = fadd fast float %2695, %2705
  %2707 = fmul fast float %2630, 0x3F25D867E0000000
  %2708 = fmul fast float %2707, %2706
  br label %2709

; <label>:2709                                    ; preds = %2663, %2656
  %2710 = phi float [ %2708, %2663 ], [ 0.000000e+00, %2656 ]
  %2711 = fadd fast float %2710, %2659
  %2712 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2711)  ; FMin(a,b)
  %2713 = fmul fast float %2712, 0xBFF7154760000000
  %2714 = call float @dx.op.unary.f32(i32 21, float %2713)  ; Exp(value)
  %2715 = fsub fast float 1.000000e+00, %2714
  %2716 = call float @dx.op.binary.f32(i32 36, float %12, float %2715)  ; FMin(a,b)
  %2717 = fsub fast float %13, %2543
  %2718 = fsub fast float %14, %2544
  %2719 = fsub fast float %15, %2545
  %2720 = fmul fast float %2716, %2717
  %2721 = fmul fast float %2716, %2718
  %2722 = fmul fast float %2716, %2719
  %2723 = fadd fast float %2720, %2543
  %2724 = fadd fast float %2721, %2544
  %2725 = fadd fast float %2722, %2545
  br label %2726

; <label>:2726                                    ; preds = %2709, %2588, %2582
  %2727 = phi float [ %2723, %2709 ], [ %2543, %2588 ], [ %2543, %2582 ]
  %2728 = phi float [ %2724, %2709 ], [ %2544, %2588 ], [ %2544, %2582 ]
  %2729 = phi float [ %2725, %2709 ], [ %2545, %2588 ], [ %2545, %2582 ]
  %2730 = fadd fast float %5, 1.000000e+00
  %2731 = fadd fast float %6, 1.000000e+00
  %2732 = fsub fast float 1.000000e+00, %5
  %2733 = fmul fast float %36, %2730
  %2734 = fmul fast float %36, %2731
  %2735 = fmul fast float %36, %2732
  %2736 = fmul fast float %2733, %2727
  %2737 = fmul fast float %2734, %2728
  %2738 = fmul fast float %2735, %2729
  %2739 = fcmp fast ult float %37, 5.000000e-01
  br i1 %2739, label %2765, label %2740

; <label>:2740                                    ; preds = %2726
  %2741 = fmul fast float %2736, 0x4004147AE0000000
  %2742 = fmul fast float %2737, 0x4004147AE0000000
  %2743 = fmul fast float %2738, 0x4004147AE0000000
  %2744 = fadd fast float %2741, 0x3F9EB851E0000000
  %2745 = fadd fast float %2742, 0x3F9EB851E0000000
  %2746 = fadd fast float %2743, 0x3F9EB851E0000000
  %2747 = fmul fast float %2744, %2736
  %2748 = fmul fast float %2745, %2737
  %2749 = fmul fast float %2746, %2738
  %2750 = fmul fast float %2736, 0x400370A3E0000000
  %2751 = fmul fast float %2737, 0x400370A3E0000000
  %2752 = fmul fast float %2738, 0x400370A3E0000000
  %2753 = fadd fast float %2750, 0x3FE2E147A0000000
  %2754 = fadd fast float %2751, 0x3FE2E147A0000000
  %2755 = fadd fast float %2752, 0x3FE2E147A0000000
  %2756 = fmul fast float %2753, %2736
  %2757 = fmul fast float %2754, %2737
  %2758 = fmul fast float %2755, %2738
  %2759 = fadd fast float %2756, 0x3FC1EB8520000000
  %2760 = fadd fast float %2757, 0x3FC1EB8520000000
  %2761 = fadd fast float %2758, 0x3FC1EB8520000000
  %2762 = fdiv fast float %2747, %2759
  %2763 = fdiv fast float %2748, %2760
  %2764 = fdiv fast float %2749, %2761
  br label %2765

; <label>:2765                                    ; preds = %2740, %2726
  %2766 = phi float [ %2762, %2740 ], [ %2736, %2726 ]
  %2767 = phi float [ %2763, %2740 ], [ %2737, %2726 ]
  %2768 = phi float [ %2764, %2740 ], [ %2738, %2726 ]
  %2769 = call float @dx.op.unary.f32(i32 7, float %2766)  ; Saturate(value)
  %2770 = call float @dx.op.unary.f32(i32 7, float %2767)  ; Saturate(value)
  %2771 = call float @dx.op.unary.f32(i32 7, float %2768)  ; Saturate(value)
  %2772 = call float @dx.op.dot3.f32(i32 55, float %2769, float %2770, float %2771, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2773 = fsub fast float %2769, %2772
  %2774 = fsub fast float %2770, %2772
  %2775 = fsub fast float %2771, %2772
  %2776 = fmul fast float %2773, %8
  %2777 = fmul fast float %2774, %8
  %2778 = fmul fast float %2775, %8
  %2779 = fadd fast float %2776, %2772
  %2780 = fadd fast float %2777, %2772
  %2781 = fadd fast float %2778, %2772
  %2782 = call float @dx.op.unary.f32(i32 7, float %2779)  ; Saturate(value)
  %2783 = call float @dx.op.unary.f32(i32 7, float %2780)  ; Saturate(value)
  %2784 = call float @dx.op.unary.f32(i32 7, float %2781)  ; Saturate(value)
  %2785 = fadd fast float %2782, 0xBFC70A3D80000000
  %2786 = fadd fast float %2783, 0xBFC70A3D80000000
  %2787 = fadd fast float %2784, 0xBFC70A3D80000000
  %2788 = fmul fast float %2785, %7
  %2789 = fmul fast float %2786, %7
  %2790 = fmul fast float %2787, %7
  %2791 = fadd fast float %2788, 0x3FC70A3D80000000
  %2792 = fadd fast float %2789, 0x3FC70A3D80000000
  %2793 = fadd fast float %2790, 0x3FC70A3D80000000
  %2794 = call float @dx.op.unary.f32(i32 7, float %2791)  ; Saturate(value)
  %2795 = call float @dx.op.unary.f32(i32 7, float %2792)  ; Saturate(value)
  %2796 = call float @dx.op.unary.f32(i32 7, float %2793)  ; Saturate(value)
  br label %2797

; <label>:2797                                    ; preds = %2765, %2548
  %2798 = phi float [ %2579, %2548 ], [ %2794, %2765 ]
  %2799 = phi float [ %2580, %2548 ], [ %2795, %2765 ]
  %2800 = phi float [ %2581, %2548 ], [ %2796, %2765 ]
  %2801 = fsub fast float %2798, %1940
  %2802 = fsub fast float %2799, %1941
  %2803 = fsub fast float %2800, %1942
  %2804 = fmul fast float %2801, %2535
  %2805 = fmul fast float %2802, %2535
  %2806 = fmul fast float %2803, %2535
  %2807 = fadd fast float %2804, %1940
  %2808 = fadd fast float %2805, %1941
  %2809 = fadd fast float %2806, %1942
  br label %2810

; <label>:2810                                    ; preds = %2797, %2520
  %2811 = phi float [ %2807, %2797 ], [ %1940, %2520 ]
  %2812 = phi float [ %2808, %2797 ], [ %1941, %2520 ]
  %2813 = phi float [ %2809, %2797 ], [ %1942, %2520 ]
  %2814 = add i32 %67, 1
  %2815 = call i32 @dx.op.binary.i32(i32 37, i32 %2814, i32 0)  ; IMax(a,b)
  %2816 = call i32 @dx.op.binary.i32(i32 38, i32 %2815, i32 %59)  ; IMin(a,b)
  %2817 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2816, i32 %2528, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2818 = extractvalue %dx.types.ResRet.f32 %2817, 0
  %2819 = fsub fast float %2818, %84
  %2820 = call float @dx.op.unary.f32(i32 6, float %2819)  ; FAbs(value)
  %2821 = fdiv fast float %2820, %1952
  %2822 = fsub fast float 1.000000e+00, %2821
  %2823 = call float @dx.op.unary.f32(i32 7, float %2822)  ; Saturate(value)
  %2824 = fcmp fast ugt float %2823, 0.000000e+00
  br i1 %2824, label %2825, label %3098

; <label>:2825                                    ; preds = %2810
  %2826 = call i32 @dx.op.binary.i32(i32 37, i32 %2816, i32 0)  ; IMax(a,b)
  %2827 = call i32 @dx.op.binary.i32(i32 37, i32 %2528, i32 0)  ; IMax(a,b)
  %2828 = call i32 @dx.op.binary.i32(i32 38, i32 %2826, i32 %59)  ; IMin(a,b)
  %2829 = call i32 @dx.op.binary.i32(i32 38, i32 %2827, i32 %60)  ; IMin(a,b)
  %2830 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2828, i32 %2829, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2831 = extractvalue %dx.types.ResRet.f32 %2830, 0
  %2832 = extractvalue %dx.types.ResRet.f32 %2830, 1
  %2833 = extractvalue %dx.types.ResRet.f32 %2830, 2
  %2834 = extractvalue %dx.types.ResRet.f32 %2830, 3
  %2835 = fcmp fast olt float %2834, 0.000000e+00
  br i1 %2835, label %2836, label %2870

; <label>:2836                                    ; preds = %2825
  %2837 = fcmp fast ogt float %2831, 0x3FA4B5DCC0000000
  %2838 = fcmp fast ogt float %2832, 0x3FA4B5DCC0000000
  %2839 = fcmp fast ogt float %2833, 0x3FA4B5DCC0000000
  %2840 = select i1 %2837, float 0.000000e+00, float 1.000000e+00
  %2841 = select i1 %2838, float 0.000000e+00, float 1.000000e+00
  %2842 = select i1 %2839, float 0.000000e+00, float 1.000000e+00
  %2843 = fmul fast float %2831, 0x3FB3D07220000000
  %2844 = fmul fast float %2832, 0x3FB3D07220000000
  %2845 = fmul fast float %2833, 0x3FB3D07220000000
  %2846 = fadd fast float %2831, 0x3FAC28F5C0000000
  %2847 = fadd fast float %2832, 0x3FAC28F5C0000000
  %2848 = fadd fast float %2833, 0x3FAC28F5C0000000
  %2849 = fmul fast float %2846, 0x3FEE54EDE0000000
  %2850 = fmul fast float %2847, 0x3FEE54EDE0000000
  %2851 = fmul fast float %2848, 0x3FEE54EDE0000000
  %2852 = call float @dx.op.unary.f32(i32 23, float %2849)  ; Log(value)
  %2853 = call float @dx.op.unary.f32(i32 23, float %2850)  ; Log(value)
  %2854 = call float @dx.op.unary.f32(i32 23, float %2851)  ; Log(value)
  %2855 = fmul fast float %2852, 0x4003333340000000
  %2856 = fmul fast float %2853, 0x4003333340000000
  %2857 = fmul fast float %2854, 0x4003333340000000
  %2858 = call float @dx.op.unary.f32(i32 21, float %2855)  ; Exp(value)
  %2859 = call float @dx.op.unary.f32(i32 21, float %2856)  ; Exp(value)
  %2860 = call float @dx.op.unary.f32(i32 21, float %2857)  ; Exp(value)
  %2861 = fsub fast float %2843, %2858
  %2862 = fsub fast float %2844, %2859
  %2863 = fsub fast float %2845, %2860
  %2864 = fmul fast float %2861, %2840
  %2865 = fmul fast float %2862, %2841
  %2866 = fmul fast float %2863, %2842
  %2867 = fadd fast float %2864, %2858
  %2868 = fadd fast float %2865, %2859
  %2869 = fadd fast float %2866, %2860
  br label %3085

; <label>:2870                                    ; preds = %2825
  %2871 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2828, i32 %2829, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2872 = extractvalue %dx.types.ResRet.f32 %2871, 0
  %2873 = fcmp fast ogt float %38, 5.000000e-01
  %2874 = fcmp fast olt float %2872, 1.000000e+00
  %2875 = and i1 %2873, %2874
  br i1 %2875, label %2876, label %3014

; <label>:2876                                    ; preds = %2870
  %2877 = sitofp i32 %2828 to float
  %2878 = sitofp i32 %2829 to float
  %2879 = fadd fast float %2877, 5.000000e-01
  %2880 = fadd fast float %2878, 5.000000e-01
  %2881 = fdiv fast float %2879, %45
  %2882 = fdiv fast float %2880, %46
  %2883 = fmul fast float %2881, 2.000000e+00
  %2884 = fmul fast float %2882, 2.000000e+00
  %2885 = fadd fast float %2883, -1.000000e+00
  %2886 = fsub fast float 1.000000e+00, %2884
  %2887 = fmul fast float %2885, %35
  %2888 = call float @dx.op.tertiary.f32(i32 46, float %2886, float %31, float %2887)  ; FMad(a,b,c)
  %2889 = call float @dx.op.tertiary.f32(i32 46, float %2872, float %27, float %2888)  ; FMad(a,b,c)
  %2890 = fadd fast float %2889, %23
  %2891 = call float @dx.op.unary.f32(i32 6, float %2890)  ; FAbs(value)
  %2892 = fcmp fast ogt float %2891, 0x3EB0C6F7A0000000
  br i1 %2892, label %2893, label %3014

; <label>:2893                                    ; preds = %2876
  %2894 = fmul fast float %2885, %34
  %2895 = call float @dx.op.tertiary.f32(i32 46, float %2886, float %30, float %2894)  ; FMad(a,b,c)
  %2896 = call float @dx.op.tertiary.f32(i32 46, float %2872, float %26, float %2895)  ; FMad(a,b,c)
  %2897 = fadd fast float %2896, %22
  %2898 = fmul fast float %2885, %33
  %2899 = call float @dx.op.tertiary.f32(i32 46, float %2886, float %29, float %2898)  ; FMad(a,b,c)
  %2900 = call float @dx.op.tertiary.f32(i32 46, float %2872, float %25, float %2899)  ; FMad(a,b,c)
  %2901 = fadd fast float %2900, %21
  %2902 = fmul fast float %2885, %32
  %2903 = call float @dx.op.tertiary.f32(i32 46, float %2886, float %28, float %2902)  ; FMad(a,b,c)
  %2904 = call float @dx.op.tertiary.f32(i32 46, float %2872, float %24, float %2903)  ; FMad(a,b,c)
  %2905 = fadd fast float %2904, %20
  %2906 = fdiv fast float %2905, %2890
  %2907 = fdiv fast float %2901, %2890
  %2908 = fdiv fast float %2897, %2890
  %2909 = fsub fast float %2906, %17
  %2910 = fsub fast float %2907, %18
  %2911 = fsub fast float %2908, %19
  %2912 = fmul fast float %2909, %2909
  %2913 = fmul fast float %2910, %2910
  %2914 = fadd fast float %2913, %2912
  %2915 = fmul fast float %2911, %2911
  %2916 = fadd fast float %2914, %2915
  %2917 = call float @dx.op.unary.f32(i32 24, float %2916)  ; Sqrt(value)
  %2918 = fsub fast float %2917, %9
  %2919 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2918)  ; FMax(a,b)
  %2920 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %2920, label %2921, label %2944

; <label>:2921                                    ; preds = %2893
  %2922 = call float @dx.op.unary.f32(i32 6, float %2910)  ; FAbs(value)
  %2923 = fmul fast float %2922, %11
  %2924 = fcmp fast olt float %2923, 0x3F50624DE0000000
  br i1 %2924, label %2925, label %2928

; <label>:2925                                    ; preds = %2921
  %2926 = fmul fast float %2923, 5.000000e-01
  %2927 = fsub fast float 1.000000e+00, %2926
  br label %2933

; <label>:2928                                    ; preds = %2921
  %2929 = fmul fast float %2923, 0xBFF7154760000000
  %2930 = call float @dx.op.unary.f32(i32 21, float %2929)  ; Exp(value)
  %2931 = fsub fast float 1.000000e+00, %2930
  %2932 = fdiv fast float %2931, %2923
  br label %2933

; <label>:2933                                    ; preds = %2928, %2925
  %2934 = phi float [ %2927, %2925 ], [ %2932, %2928 ]
  %2935 = call float @dx.op.binary.f32(i32 36, float %2907, float %18)  ; FMin(a,b)
  %2936 = fsub fast float %2935, %10
  %2937 = fmul fast float %11, %2936
  %2938 = fsub fast float -0.000000e+00, %2937
  %2939 = call float @dx.op.binary.f32(i32 35, float %2938, float -4.000000e+01)  ; FMax(a,b)
  %2940 = call float @dx.op.binary.f32(i32 36, float %2939, float 5.000000e+00)  ; FMin(a,b)
  %2941 = fmul fast float %2940, 0x3FF7154760000000
  %2942 = call float @dx.op.unary.f32(i32 21, float %2941)  ; Exp(value)
  %2943 = fmul fast float %2942, %2934
  br label %2944

; <label>:2944                                    ; preds = %2933, %2893
  %2945 = phi float [ %2943, %2933 ], [ 1.000000e+00, %2893 ]
  %2946 = fmul fast float %2919, %16
  %2947 = fmul fast float %2946, %2945
  %2948 = fcmp fast ole float %2917, %9
  %2949 = fcmp fast olt float %2917, 0x3F1A36E2E0000000
  %2950 = or i1 %2948, %2949
  br i1 %2950, label %2997, label %2951

; <label>:2951                                    ; preds = %2944
  %2952 = fdiv fast float %9, %2917
  %2953 = fmul fast float %2952, %2909
  %2954 = fmul fast float %2952, %2910
  %2955 = fmul fast float %2952, %2911
  %2956 = fadd fast float %2953, %17
  %2957 = fadd fast float %2954, %18
  %2958 = fadd fast float %2955, %19
  %2959 = fadd fast float %2956, -9.000000e+02
  %2960 = fadd fast float %2957, -1.500000e+01
  %2961 = fadd fast float %2958, -7.500000e+02
  %2962 = fmul fast float %2959, 0x3F62345680000000
  %2963 = fmul fast float %2960, 0x3F62345680000000
  %2964 = fmul fast float %2961, 0x3F62345680000000
  %2965 = call float @dx.op.dot3.f32(i32 55, float %2962, float %2963, float %2964, float %2962, float %2963, float %2964)  ; Dot3(ax,ay,az,bx,by,bz)
  %2966 = fsub fast float 1.000000e+00, %2965
  %2967 = call float @dx.op.unary.f32(i32 7, float %2966)  ; Saturate(value)
  %2968 = fmul fast float %2967, %2967
  %2969 = fadd fast float %2956, %2906
  %2970 = fadd fast float %2957, %2907
  %2971 = fadd fast float %2958, %2908
  %2972 = fmul fast float %2969, 0x3F52345680000000
  %2973 = fadd fast float %2972, -2.000000e+00
  %2974 = fmul fast float %2970, 0x3F52345680000000
  %2975 = fadd fast float %2974, 0xBFA1111120000000
  %2976 = fmul fast float %2971, 0x3F52345680000000
  %2977 = fadd fast float %2976, 0xBFFAAAAAC0000000
  %2978 = call float @dx.op.dot3.f32(i32 55, float %2973, float %2975, float %2977, float %2973, float %2975, float %2977)  ; Dot3(ax,ay,az,bx,by,bz)
  %2979 = fsub fast float 1.000000e+00, %2978
  %2980 = call float @dx.op.unary.f32(i32 7, float %2979)  ; Saturate(value)
  %2981 = fmul fast float %2980, %2980
  %2982 = fmul fast float %2981, 4.000000e+00
  %2983 = fadd fast float %2982, %2968
  %2984 = fadd fast float %2906, -9.000000e+02
  %2985 = fadd fast float %2907, -1.500000e+01
  %2986 = fadd fast float %2908, -7.500000e+02
  %2987 = fmul fast float %2984, 0x3F62345680000000
  %2988 = fmul fast float %2985, 0x3F62345680000000
  %2989 = fmul fast float %2986, 0x3F62345680000000
  %2990 = call float @dx.op.dot3.f32(i32 55, float %2987, float %2988, float %2989, float %2987, float %2988, float %2989)  ; Dot3(ax,ay,az,bx,by,bz)
  %2991 = fsub fast float 1.000000e+00, %2990
  %2992 = call float @dx.op.unary.f32(i32 7, float %2991)  ; Saturate(value)
  %2993 = fmul fast float %2992, %2992
  %2994 = fadd fast float %2983, %2993
  %2995 = fmul fast float %2918, 0x3F25D867E0000000
  %2996 = fmul fast float %2995, %2994
  br label %2997

; <label>:2997                                    ; preds = %2951, %2944
  %2998 = phi float [ %2996, %2951 ], [ 0.000000e+00, %2944 ]
  %2999 = fadd fast float %2998, %2947
  %3000 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2999)  ; FMin(a,b)
  %3001 = fmul fast float %3000, 0xBFF7154760000000
  %3002 = call float @dx.op.unary.f32(i32 21, float %3001)  ; Exp(value)
  %3003 = fsub fast float 1.000000e+00, %3002
  %3004 = call float @dx.op.binary.f32(i32 36, float %12, float %3003)  ; FMin(a,b)
  %3005 = fsub fast float %13, %2831
  %3006 = fsub fast float %14, %2832
  %3007 = fsub fast float %15, %2833
  %3008 = fmul fast float %3004, %3005
  %3009 = fmul fast float %3004, %3006
  %3010 = fmul fast float %3004, %3007
  %3011 = fadd fast float %3008, %2831
  %3012 = fadd fast float %3009, %2832
  %3013 = fadd fast float %3010, %2833
  br label %3014

; <label>:3014                                    ; preds = %2997, %2876, %2870
  %3015 = phi float [ %3011, %2997 ], [ %2831, %2876 ], [ %2831, %2870 ]
  %3016 = phi float [ %3012, %2997 ], [ %2832, %2876 ], [ %2832, %2870 ]
  %3017 = phi float [ %3013, %2997 ], [ %2833, %2876 ], [ %2833, %2870 ]
  %3018 = fadd fast float %5, 1.000000e+00
  %3019 = fadd fast float %6, 1.000000e+00
  %3020 = fsub fast float 1.000000e+00, %5
  %3021 = fmul fast float %36, %3018
  %3022 = fmul fast float %36, %3019
  %3023 = fmul fast float %36, %3020
  %3024 = fmul fast float %3021, %3015
  %3025 = fmul fast float %3022, %3016
  %3026 = fmul fast float %3023, %3017
  %3027 = fcmp fast ult float %37, 5.000000e-01
  br i1 %3027, label %3053, label %3028

; <label>:3028                                    ; preds = %3014
  %3029 = fmul fast float %3024, 0x4004147AE0000000
  %3030 = fmul fast float %3025, 0x4004147AE0000000
  %3031 = fmul fast float %3026, 0x4004147AE0000000
  %3032 = fadd fast float %3029, 0x3F9EB851E0000000
  %3033 = fadd fast float %3030, 0x3F9EB851E0000000
  %3034 = fadd fast float %3031, 0x3F9EB851E0000000
  %3035 = fmul fast float %3032, %3024
  %3036 = fmul fast float %3033, %3025
  %3037 = fmul fast float %3034, %3026
  %3038 = fmul fast float %3024, 0x400370A3E0000000
  %3039 = fmul fast float %3025, 0x400370A3E0000000
  %3040 = fmul fast float %3026, 0x400370A3E0000000
  %3041 = fadd fast float %3038, 0x3FE2E147A0000000
  %3042 = fadd fast float %3039, 0x3FE2E147A0000000
  %3043 = fadd fast float %3040, 0x3FE2E147A0000000
  %3044 = fmul fast float %3041, %3024
  %3045 = fmul fast float %3042, %3025
  %3046 = fmul fast float %3043, %3026
  %3047 = fadd fast float %3044, 0x3FC1EB8520000000
  %3048 = fadd fast float %3045, 0x3FC1EB8520000000
  %3049 = fadd fast float %3046, 0x3FC1EB8520000000
  %3050 = fdiv fast float %3035, %3047
  %3051 = fdiv fast float %3036, %3048
  %3052 = fdiv fast float %3037, %3049
  br label %3053

; <label>:3053                                    ; preds = %3028, %3014
  %3054 = phi float [ %3050, %3028 ], [ %3024, %3014 ]
  %3055 = phi float [ %3051, %3028 ], [ %3025, %3014 ]
  %3056 = phi float [ %3052, %3028 ], [ %3026, %3014 ]
  %3057 = call float @dx.op.unary.f32(i32 7, float %3054)  ; Saturate(value)
  %3058 = call float @dx.op.unary.f32(i32 7, float %3055)  ; Saturate(value)
  %3059 = call float @dx.op.unary.f32(i32 7, float %3056)  ; Saturate(value)
  %3060 = call float @dx.op.dot3.f32(i32 55, float %3057, float %3058, float %3059, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3061 = fsub fast float %3057, %3060
  %3062 = fsub fast float %3058, %3060
  %3063 = fsub fast float %3059, %3060
  %3064 = fmul fast float %3061, %8
  %3065 = fmul fast float %3062, %8
  %3066 = fmul fast float %3063, %8
  %3067 = fadd fast float %3064, %3060
  %3068 = fadd fast float %3065, %3060
  %3069 = fadd fast float %3066, %3060
  %3070 = call float @dx.op.unary.f32(i32 7, float %3067)  ; Saturate(value)
  %3071 = call float @dx.op.unary.f32(i32 7, float %3068)  ; Saturate(value)
  %3072 = call float @dx.op.unary.f32(i32 7, float %3069)  ; Saturate(value)
  %3073 = fadd fast float %3070, 0xBFC70A3D80000000
  %3074 = fadd fast float %3071, 0xBFC70A3D80000000
  %3075 = fadd fast float %3072, 0xBFC70A3D80000000
  %3076 = fmul fast float %3073, %7
  %3077 = fmul fast float %3074, %7
  %3078 = fmul fast float %3075, %7
  %3079 = fadd fast float %3076, 0x3FC70A3D80000000
  %3080 = fadd fast float %3077, 0x3FC70A3D80000000
  %3081 = fadd fast float %3078, 0x3FC70A3D80000000
  %3082 = call float @dx.op.unary.f32(i32 7, float %3079)  ; Saturate(value)
  %3083 = call float @dx.op.unary.f32(i32 7, float %3080)  ; Saturate(value)
  %3084 = call float @dx.op.unary.f32(i32 7, float %3081)  ; Saturate(value)
  br label %3085

; <label>:3085                                    ; preds = %3053, %2836
  %3086 = phi float [ %2867, %2836 ], [ %3082, %3053 ]
  %3087 = phi float [ %2868, %2836 ], [ %3083, %3053 ]
  %3088 = phi float [ %2869, %2836 ], [ %3084, %3053 ]
  %3089 = fsub fast float %3086, %1940
  %3090 = fsub fast float %3087, %1941
  %3091 = fsub fast float %3088, %1942
  %3092 = fmul fast float %3089, %2823
  %3093 = fmul fast float %3090, %2823
  %3094 = fmul fast float %3091, %2823
  %3095 = fadd fast float %3092, %1940
  %3096 = fadd fast float %3093, %1941
  %3097 = fadd fast float %3094, %1942
  br label %3098

; <label>:3098                                    ; preds = %3085, %2810
  %3099 = phi float [ %3095, %3085 ], [ %1940, %2810 ]
  %3100 = phi float [ %3096, %3085 ], [ %1941, %2810 ]
  %3101 = phi float [ %3097, %3085 ], [ %1942, %2810 ]
  %3102 = call float @dx.op.binary.f32(i32 36, float %2811, float %3099)  ; FMin(a,b)
  %3103 = call float @dx.op.binary.f32(i32 36, float %2812, float %3100)  ; FMin(a,b)
  %3104 = call float @dx.op.binary.f32(i32 36, float %2813, float %3101)  ; FMin(a,b)
  %3105 = call float @dx.op.binary.f32(i32 36, float %2233, float %2521)  ; FMin(a,b)
  %3106 = call float @dx.op.binary.f32(i32 36, float %2234, float %2522)  ; FMin(a,b)
  %3107 = call float @dx.op.binary.f32(i32 36, float %2235, float %2523)  ; FMin(a,b)
  %3108 = call float @dx.op.binary.f32(i32 36, float %3105, float %3102)  ; FMin(a,b)
  %3109 = call float @dx.op.binary.f32(i32 36, float %3106, float %3103)  ; FMin(a,b)
  %3110 = call float @dx.op.binary.f32(i32 36, float %3107, float %3104)  ; FMin(a,b)
  %3111 = call float @dx.op.binary.f32(i32 36, float %1940, float %3108)  ; FMin(a,b)
  %3112 = call float @dx.op.binary.f32(i32 36, float %1941, float %3109)  ; FMin(a,b)
  %3113 = call float @dx.op.binary.f32(i32 36, float %1942, float %3110)  ; FMin(a,b)
  %3114 = call float @dx.op.binary.f32(i32 35, float %2811, float %3099)  ; FMax(a,b)
  %3115 = call float @dx.op.binary.f32(i32 35, float %2812, float %3100)  ; FMax(a,b)
  %3116 = call float @dx.op.binary.f32(i32 35, float %2813, float %3101)  ; FMax(a,b)
  %3117 = call float @dx.op.binary.f32(i32 35, float %2233, float %2521)  ; FMax(a,b)
  %3118 = call float @dx.op.binary.f32(i32 35, float %2234, float %2522)  ; FMax(a,b)
  %3119 = call float @dx.op.binary.f32(i32 35, float %2235, float %2523)  ; FMax(a,b)
  %3120 = call float @dx.op.binary.f32(i32 35, float %3117, float %3114)  ; FMax(a,b)
  %3121 = call float @dx.op.binary.f32(i32 35, float %3118, float %3115)  ; FMax(a,b)
  %3122 = call float @dx.op.binary.f32(i32 35, float %3119, float %3116)  ; FMax(a,b)
  %3123 = call float @dx.op.binary.f32(i32 35, float %1940, float %3120)  ; FMax(a,b)
  %3124 = call float @dx.op.binary.f32(i32 35, float %1941, float %3121)  ; FMax(a,b)
  %3125 = call float @dx.op.binary.f32(i32 35, float %1942, float %3122)  ; FMax(a,b)
  %3126 = fsub fast float %3123, %3111
  %3127 = fsub fast float %3124, %3112
  %3128 = fsub fast float %3125, %3113
  %3129 = call float @dx.op.unary.f32(i32 6, float %3126)  ; FAbs(value)
  %3130 = call float @dx.op.unary.f32(i32 6, float %3127)  ; FAbs(value)
  %3131 = call float @dx.op.unary.f32(i32 6, float %3128)  ; FAbs(value)
  %3132 = call float @dx.op.binary.f32(i32 35, float %3130, float %3131)  ; FMax(a,b)
  %3133 = call float @dx.op.binary.f32(i32 35, float %3129, float %3132)  ; FMax(a,b)
  %3134 = call float @dx.op.binary.f32(i32 35, float %3124, float %3125)  ; FMax(a,b)
  %3135 = call float @dx.op.binary.f32(i32 35, float %3123, float %3134)  ; FMax(a,b)
  %3136 = fmul fast float %3135, 1.250000e-01
  %3137 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %3136)  ; FMax(a,b)
  %3138 = fcmp fast ogt float %3133, %3137
  br i1 %3138, label %3139, label %3200

; <label>:3139                                    ; preds = %3098
  %3140 = fsub fast float %2233, %2521
  %3141 = fsub fast float %2234, %2522
  %3142 = fsub fast float %2235, %2523
  %3143 = call float @dx.op.unary.f32(i32 6, float %3140)  ; FAbs(value)
  %3144 = call float @dx.op.unary.f32(i32 6, float %3141)  ; FAbs(value)
  %3145 = call float @dx.op.unary.f32(i32 6, float %3142)  ; FAbs(value)
  %3146 = call float @dx.op.binary.f32(i32 35, float %3144, float %3145)  ; FMax(a,b)
  %3147 = call float @dx.op.binary.f32(i32 35, float %3143, float %3146)  ; FMax(a,b)
  %3148 = fsub fast float %2811, %3099
  %3149 = fsub fast float %2812, %3100
  %3150 = fsub fast float %2813, %3101
  %3151 = call float @dx.op.unary.f32(i32 6, float %3148)  ; FAbs(value)
  %3152 = call float @dx.op.unary.f32(i32 6, float %3149)  ; FAbs(value)
  %3153 = call float @dx.op.unary.f32(i32 6, float %3150)  ; FAbs(value)
  %3154 = call float @dx.op.binary.f32(i32 35, float %3152, float %3153)  ; FMax(a,b)
  %3155 = call float @dx.op.binary.f32(i32 35, float %3151, float %3154)  ; FMax(a,b)
  %3156 = fcmp fast olt float %3147, %3155
  %3157 = select i1 %3156, float %2233, float %2811
  %3158 = select i1 %3156, float %2234, float %2812
  %3159 = select i1 %3156, float %2235, float %2813
  %3160 = select i1 %3156, float %2521, float %3099
  %3161 = select i1 %3156, float %2522, float %3100
  %3162 = select i1 %3156, float %2523, float %3101
  %3163 = fsub fast float %1940, %3160
  %3164 = fsub fast float %1941, %3161
  %3165 = fsub fast float %1942, %3162
  %3166 = fsub fast float %1940, %3157
  %3167 = fsub fast float %1941, %3158
  %3168 = fsub fast float %1942, %3159
  %3169 = call float @dx.op.dot3.f32(i32 55, float %3166, float %3167, float %3168, float %3163, float %3164, float %3165)  ; Dot3(ax,ay,az,bx,by,bz)
  %3170 = fcmp fast ogt float %3169, 0.000000e+00
  br i1 %3170, label %3171, label %3182

; <label>:3171                                    ; preds = %3139
  %3172 = fsub fast float %3157, %3160
  %3173 = fsub fast float %3158, %3161
  %3174 = fsub fast float %3159, %3162
  %3175 = call float @dx.op.unary.f32(i32 6, float %3172)  ; FAbs(value)
  %3176 = call float @dx.op.unary.f32(i32 6, float %3173)  ; FAbs(value)
  %3177 = call float @dx.op.unary.f32(i32 6, float %3174)  ; FAbs(value)
  %3178 = call float @dx.op.binary.f32(i32 35, float %3176, float %3177)  ; FMax(a,b)
  %3179 = call float @dx.op.binary.f32(i32 35, float %3175, float %3178)  ; FMax(a,b)
  %3180 = fmul fast float %3133, 2.500000e-01
  %3181 = fcmp fast olt float %3179, %3180
  br label %3182

; <label>:3182                                    ; preds = %3171, %3139
  %3183 = phi i1 [ false, %3139 ], [ %3181, %3171 ]
  %3184 = select i1 %3183, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  %3185 = fadd fast float %3157, %3160
  %3186 = fadd fast float %3158, %3161
  %3187 = fadd fast float %3159, %3162
  %3188 = fmul fast float %3185, 5.000000e-01
  %3189 = fmul fast float %3186, 5.000000e-01
  %3190 = fmul fast float %3187, 5.000000e-01
  %3191 = fsub fast float %3188, %1940
  %3192 = fsub fast float %3189, %1941
  %3193 = fsub fast float %3190, %1942
  %3194 = fmul fast float %3184, %3191
  %3195 = fmul fast float %3184, %3192
  %3196 = fmul fast float %3184, %3193
  %3197 = fadd fast float %3194, %1940
  %3198 = fadd fast float %3195, %1941
  %3199 = fadd fast float %3196, %1942
  br label %3200

; <label>:3200                                    ; preds = %3182, %3098
  %3201 = phi float [ %3197, %3182 ], [ %1940, %3098 ]
  %3202 = phi float [ %3198, %3182 ], [ %1941, %3098 ]
  %3203 = phi float [ %3199, %3182 ], [ %1942, %3098 ]
  %3204 = fcmp fast ogt float %3201, 0x3F69A5C380000000
  %3205 = fcmp fast ogt float %3202, 0x3F69A5C380000000
  %3206 = fcmp fast ogt float %3203, 0x3F69A5C380000000
  %3207 = select i1 %3204, float 0.000000e+00, float 1.000000e+00
  %3208 = select i1 %3205, float 0.000000e+00, float 1.000000e+00
  %3209 = select i1 %3206, float 0.000000e+00, float 1.000000e+00
  %3210 = fmul fast float %3201, 0x4029D70A40000000
  %3211 = fmul fast float %3202, 0x4029D70A40000000
  %3212 = fmul fast float %3203, 0x4029D70A40000000
  %3213 = call float @dx.op.binary.f32(i32 35, float %3201, float 0.000000e+00)  ; FMax(a,b)
  %3214 = call float @dx.op.binary.f32(i32 35, float %3202, float 0.000000e+00)  ; FMax(a,b)
  %3215 = call float @dx.op.binary.f32(i32 35, float %3203, float 0.000000e+00)  ; FMax(a,b)
  %3216 = call float @dx.op.unary.f32(i32 23, float %3213)  ; Log(value)
  %3217 = call float @dx.op.unary.f32(i32 23, float %3214)  ; Log(value)
  %3218 = call float @dx.op.unary.f32(i32 23, float %3215)  ; Log(value)
  %3219 = fmul fast float %3216, 0x3FDAAAAAA0000000
  %3220 = fmul fast float %3217, 0x3FDAAAAAA0000000
  %3221 = fmul fast float %3218, 0x3FDAAAAAA0000000
  %3222 = call float @dx.op.unary.f32(i32 21, float %3219)  ; Exp(value)
  %3223 = call float @dx.op.unary.f32(i32 21, float %3220)  ; Exp(value)
  %3224 = call float @dx.op.unary.f32(i32 21, float %3221)  ; Exp(value)
  %3225 = fmul fast float %3222, 0x3FF0E147A0000000
  %3226 = fmul fast float %3223, 0x3FF0E147A0000000
  %3227 = fmul fast float %3224, 0x3FF0E147A0000000
  %3228 = fadd fast float %3225, 0xBFAC28F5C0000000
  %3229 = fadd fast float %3226, 0xBFAC28F5C0000000
  %3230 = fadd fast float %3227, 0xBFAC28F5C0000000
  %3231 = fsub fast float %3210, %3228
  %3232 = fsub fast float %3211, %3229
  %3233 = fsub fast float %3212, %3230
  %3234 = fmul fast float %3231, %3207
  %3235 = fmul fast float %3232, %3208
  %3236 = fmul fast float %3233, %3209
  %3237 = fadd fast float %3234, %3228
  %3238 = fadd fast float %3235, %3229
  %3239 = fadd fast float %3236, %3230
  br label %3240

; <label>:3240                                    ; preds = %3200, %1728
  %3241 = phi float [ %1723, %1728 ], [ %3237, %3200 ]
  %3242 = phi float [ %1724, %1728 ], [ %3238, %3200 ]
  %3243 = phi float [ %1725, %1728 ], [ %3239, %3200 ]
  %3244 = phi float [ %1729, %1728 ], [ %1726, %3200 ]
  %3245 = fcmp fast ogt float %3241, 0x3FA4B5DCC0000000
  %3246 = fcmp fast ogt float %3242, 0x3FA4B5DCC0000000
  %3247 = fcmp fast ogt float %3243, 0x3FA4B5DCC0000000
  %3248 = select i1 %3245, float 0.000000e+00, float 1.000000e+00
  %3249 = select i1 %3246, float 0.000000e+00, float 1.000000e+00
  %3250 = select i1 %3247, float 0.000000e+00, float 1.000000e+00
  %3251 = fmul fast float %3241, 0x3FB3D07220000000
  %3252 = fmul fast float %3242, 0x3FB3D07220000000
  %3253 = fmul fast float %3243, 0x3FB3D07220000000
  %3254 = fadd fast float %3241, 0x3FAC28F5C0000000
  %3255 = fadd fast float %3242, 0x3FAC28F5C0000000
  %3256 = fadd fast float %3243, 0x3FAC28F5C0000000
  %3257 = fmul fast float %3254, 0x3FEE54EDE0000000
  %3258 = fmul fast float %3255, 0x3FEE54EDE0000000
  %3259 = fmul fast float %3256, 0x3FEE54EDE0000000
  %3260 = call float @dx.op.unary.f32(i32 23, float %3257)  ; Log(value)
  %3261 = call float @dx.op.unary.f32(i32 23, float %3258)  ; Log(value)
  %3262 = call float @dx.op.unary.f32(i32 23, float %3259)  ; Log(value)
  %3263 = fmul fast float %3260, 0x4003333340000000
  %3264 = fmul fast float %3261, 0x4003333340000000
  %3265 = fmul fast float %3262, 0x4003333340000000
  %3266 = call float @dx.op.unary.f32(i32 21, float %3263)  ; Exp(value)
  %3267 = call float @dx.op.unary.f32(i32 21, float %3264)  ; Exp(value)
  %3268 = call float @dx.op.unary.f32(i32 21, float %3265)  ; Exp(value)
  %3269 = fsub fast float %3251, %3266
  %3270 = fsub fast float %3252, %3267
  %3271 = fsub fast float %3253, %3268
  %3272 = fmul fast float %3269, %3248
  %3273 = fmul fast float %3270, %3249
  %3274 = fmul fast float %3271, %3250
  %3275 = fadd fast float %3272, %3266
  %3276 = fadd fast float %3273, %3267
  %3277 = fadd fast float %3274, %3268
  %3278 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %63, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3279 = extractvalue %dx.types.ResRet.f32 %3278, 0
  %3280 = extractvalue %dx.types.ResRet.f32 %3278, 1
  %3281 = extractvalue %dx.types.ResRet.f32 %3278, 2
  %3282 = extractvalue %dx.types.ResRet.f32 %3278, 3
  %3283 = fcmp fast olt float %3282, 0.000000e+00
  br i1 %3283, label %3284, label %3286

; <label>:3284                                    ; preds = %3240
  %3285 = fsub fast float -1.000000e+00, %3282
  br label %4796

; <label>:3286                                    ; preds = %3240
  %3287 = fcmp fast ogt float %38, 5.000000e-01
  %3288 = fcmp fast olt float %86, 1.000000e+00
  %3289 = and i1 %3287, %3288
  br i1 %3289, label %3290, label %3428

; <label>:3290                                    ; preds = %3286
  %3291 = sitofp i32 %63 to float
  %3292 = sitofp i32 %70 to float
  %3293 = fadd fast float %3291, 5.000000e-01
  %3294 = fadd fast float %3292, 5.000000e-01
  %3295 = fdiv fast float %3293, %45
  %3296 = fdiv fast float %3294, %46
  %3297 = fmul fast float %3295, 2.000000e+00
  %3298 = fmul fast float %3296, 2.000000e+00
  %3299 = fadd fast float %3297, -1.000000e+00
  %3300 = fsub fast float 1.000000e+00, %3298
  %3301 = fmul fast float %3299, %35
  %3302 = call float @dx.op.tertiary.f32(i32 46, float %3300, float %31, float %3301)  ; FMad(a,b,c)
  %3303 = call float @dx.op.tertiary.f32(i32 46, float %86, float %27, float %3302)  ; FMad(a,b,c)
  %3304 = fadd fast float %3303, %23
  %3305 = call float @dx.op.unary.f32(i32 6, float %3304)  ; FAbs(value)
  %3306 = fcmp fast ogt float %3305, 0x3EB0C6F7A0000000
  br i1 %3306, label %3307, label %3428

; <label>:3307                                    ; preds = %3290
  %3308 = fmul fast float %3299, %34
  %3309 = call float @dx.op.tertiary.f32(i32 46, float %3300, float %30, float %3308)  ; FMad(a,b,c)
  %3310 = call float @dx.op.tertiary.f32(i32 46, float %86, float %26, float %3309)  ; FMad(a,b,c)
  %3311 = fadd fast float %3310, %22
  %3312 = fmul fast float %3299, %33
  %3313 = call float @dx.op.tertiary.f32(i32 46, float %3300, float %29, float %3312)  ; FMad(a,b,c)
  %3314 = call float @dx.op.tertiary.f32(i32 46, float %86, float %25, float %3313)  ; FMad(a,b,c)
  %3315 = fadd fast float %3314, %21
  %3316 = fmul fast float %3299, %32
  %3317 = call float @dx.op.tertiary.f32(i32 46, float %3300, float %28, float %3316)  ; FMad(a,b,c)
  %3318 = call float @dx.op.tertiary.f32(i32 46, float %86, float %24, float %3317)  ; FMad(a,b,c)
  %3319 = fadd fast float %3318, %20
  %3320 = fdiv fast float %3319, %3304
  %3321 = fdiv fast float %3315, %3304
  %3322 = fdiv fast float %3311, %3304
  %3323 = fsub fast float %3320, %17
  %3324 = fsub fast float %3321, %18
  %3325 = fsub fast float %3322, %19
  %3326 = fmul fast float %3323, %3323
  %3327 = fmul fast float %3324, %3324
  %3328 = fadd fast float %3327, %3326
  %3329 = fmul fast float %3325, %3325
  %3330 = fadd fast float %3328, %3329
  %3331 = call float @dx.op.unary.f32(i32 24, float %3330)  ; Sqrt(value)
  %3332 = fsub fast float %3331, %9
  %3333 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3332)  ; FMax(a,b)
  %3334 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %3334, label %3335, label %3358

; <label>:3335                                    ; preds = %3307
  %3336 = call float @dx.op.unary.f32(i32 6, float %3324)  ; FAbs(value)
  %3337 = fmul fast float %3336, %11
  %3338 = fcmp fast olt float %3337, 0x3F50624DE0000000
  br i1 %3338, label %3339, label %3342

; <label>:3339                                    ; preds = %3335
  %3340 = fmul fast float %3337, 5.000000e-01
  %3341 = fsub fast float 1.000000e+00, %3340
  br label %3347

; <label>:3342                                    ; preds = %3335
  %3343 = fmul fast float %3337, 0xBFF7154760000000
  %3344 = call float @dx.op.unary.f32(i32 21, float %3343)  ; Exp(value)
  %3345 = fsub fast float 1.000000e+00, %3344
  %3346 = fdiv fast float %3345, %3337
  br label %3347

; <label>:3347                                    ; preds = %3342, %3339
  %3348 = phi float [ %3341, %3339 ], [ %3346, %3342 ]
  %3349 = call float @dx.op.binary.f32(i32 36, float %3321, float %18)  ; FMin(a,b)
  %3350 = fsub fast float %3349, %10
  %3351 = fmul fast float %11, %3350
  %3352 = fsub fast float -0.000000e+00, %3351
  %3353 = call float @dx.op.binary.f32(i32 35, float %3352, float -4.000000e+01)  ; FMax(a,b)
  %3354 = call float @dx.op.binary.f32(i32 36, float %3353, float 5.000000e+00)  ; FMin(a,b)
  %3355 = fmul fast float %3354, 0x3FF7154760000000
  %3356 = call float @dx.op.unary.f32(i32 21, float %3355)  ; Exp(value)
  %3357 = fmul fast float %3356, %3348
  br label %3358

; <label>:3358                                    ; preds = %3347, %3307
  %3359 = phi float [ %3357, %3347 ], [ 1.000000e+00, %3307 ]
  %3360 = fmul fast float %3333, %16
  %3361 = fmul fast float %3360, %3359
  %3362 = fcmp fast ole float %3331, %9
  %3363 = fcmp fast olt float %3331, 0x3F1A36E2E0000000
  %3364 = or i1 %3362, %3363
  br i1 %3364, label %3411, label %3365

; <label>:3365                                    ; preds = %3358
  %3366 = fdiv fast float %9, %3331
  %3367 = fmul fast float %3366, %3323
  %3368 = fmul fast float %3366, %3324
  %3369 = fmul fast float %3366, %3325
  %3370 = fadd fast float %3367, %17
  %3371 = fadd fast float %3368, %18
  %3372 = fadd fast float %3369, %19
  %3373 = fadd fast float %3370, -9.000000e+02
  %3374 = fadd fast float %3371, -1.500000e+01
  %3375 = fadd fast float %3372, -7.500000e+02
  %3376 = fmul fast float %3373, 0x3F62345680000000
  %3377 = fmul fast float %3374, 0x3F62345680000000
  %3378 = fmul fast float %3375, 0x3F62345680000000
  %3379 = call float @dx.op.dot3.f32(i32 55, float %3376, float %3377, float %3378, float %3376, float %3377, float %3378)  ; Dot3(ax,ay,az,bx,by,bz)
  %3380 = fsub fast float 1.000000e+00, %3379
  %3381 = call float @dx.op.unary.f32(i32 7, float %3380)  ; Saturate(value)
  %3382 = fmul fast float %3381, %3381
  %3383 = fadd fast float %3370, %3320
  %3384 = fadd fast float %3371, %3321
  %3385 = fadd fast float %3372, %3322
  %3386 = fmul fast float %3383, 0x3F52345680000000
  %3387 = fadd fast float %3386, -2.000000e+00
  %3388 = fmul fast float %3384, 0x3F52345680000000
  %3389 = fadd fast float %3388, 0xBFA1111120000000
  %3390 = fmul fast float %3385, 0x3F52345680000000
  %3391 = fadd fast float %3390, 0xBFFAAAAAC0000000
  %3392 = call float @dx.op.dot3.f32(i32 55, float %3387, float %3389, float %3391, float %3387, float %3389, float %3391)  ; Dot3(ax,ay,az,bx,by,bz)
  %3393 = fsub fast float 1.000000e+00, %3392
  %3394 = call float @dx.op.unary.f32(i32 7, float %3393)  ; Saturate(value)
  %3395 = fmul fast float %3394, %3394
  %3396 = fmul fast float %3395, 4.000000e+00
  %3397 = fadd fast float %3396, %3382
  %3398 = fadd fast float %3320, -9.000000e+02
  %3399 = fadd fast float %3321, -1.500000e+01
  %3400 = fadd fast float %3322, -7.500000e+02
  %3401 = fmul fast float %3398, 0x3F62345680000000
  %3402 = fmul fast float %3399, 0x3F62345680000000
  %3403 = fmul fast float %3400, 0x3F62345680000000
  %3404 = call float @dx.op.dot3.f32(i32 55, float %3401, float %3402, float %3403, float %3401, float %3402, float %3403)  ; Dot3(ax,ay,az,bx,by,bz)
  %3405 = fsub fast float 1.000000e+00, %3404
  %3406 = call float @dx.op.unary.f32(i32 7, float %3405)  ; Saturate(value)
  %3407 = fmul fast float %3406, %3406
  %3408 = fadd fast float %3397, %3407
  %3409 = fmul fast float %3332, 0x3F25D867E0000000
  %3410 = fmul fast float %3409, %3408
  br label %3411

; <label>:3411                                    ; preds = %3365, %3358
  %3412 = phi float [ %3410, %3365 ], [ 0.000000e+00, %3358 ]
  %3413 = fadd fast float %3412, %3361
  %3414 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3413)  ; FMin(a,b)
  %3415 = fmul fast float %3414, 0xBFF7154760000000
  %3416 = call float @dx.op.unary.f32(i32 21, float %3415)  ; Exp(value)
  %3417 = fsub fast float 1.000000e+00, %3416
  %3418 = call float @dx.op.binary.f32(i32 36, float %12, float %3417)  ; FMin(a,b)
  %3419 = fsub fast float %13, %3279
  %3420 = fsub fast float %14, %3280
  %3421 = fsub fast float %15, %3281
  %3422 = fmul fast float %3418, %3419
  %3423 = fmul fast float %3418, %3420
  %3424 = fmul fast float %3418, %3421
  %3425 = fadd fast float %3422, %3279
  %3426 = fadd fast float %3423, %3280
  %3427 = fadd fast float %3424, %3281
  br label %3428

; <label>:3428                                    ; preds = %3411, %3290, %3286
  %3429 = phi float [ %3425, %3411 ], [ %3279, %3290 ], [ %3279, %3286 ]
  %3430 = phi float [ %3426, %3411 ], [ %3280, %3290 ], [ %3280, %3286 ]
  %3431 = phi float [ %3427, %3411 ], [ %3281, %3290 ], [ %3281, %3286 ]
  %3432 = fadd fast float %5, 1.000000e+00
  %3433 = fadd fast float %6, 1.000000e+00
  %3434 = fsub fast float 1.000000e+00, %5
  %3435 = fmul fast float %36, %3432
  %3436 = fmul fast float %36, %3433
  %3437 = fmul fast float %36, %3434
  %3438 = fmul fast float %3435, %3429
  %3439 = fmul fast float %3436, %3430
  %3440 = fmul fast float %3437, %3431
  %3441 = fcmp fast ult float %37, 5.000000e-01
  br i1 %3441, label %3467, label %3442

; <label>:3442                                    ; preds = %3428
  %3443 = fmul fast float %3438, 0x4004147AE0000000
  %3444 = fmul fast float %3439, 0x4004147AE0000000
  %3445 = fmul fast float %3440, 0x4004147AE0000000
  %3446 = fadd fast float %3443, 0x3F9EB851E0000000
  %3447 = fadd fast float %3444, 0x3F9EB851E0000000
  %3448 = fadd fast float %3445, 0x3F9EB851E0000000
  %3449 = fmul fast float %3446, %3438
  %3450 = fmul fast float %3447, %3439
  %3451 = fmul fast float %3448, %3440
  %3452 = fmul fast float %3438, 0x400370A3E0000000
  %3453 = fmul fast float %3439, 0x400370A3E0000000
  %3454 = fmul fast float %3440, 0x400370A3E0000000
  %3455 = fadd fast float %3452, 0x3FE2E147A0000000
  %3456 = fadd fast float %3453, 0x3FE2E147A0000000
  %3457 = fadd fast float %3454, 0x3FE2E147A0000000
  %3458 = fmul fast float %3455, %3438
  %3459 = fmul fast float %3456, %3439
  %3460 = fmul fast float %3457, %3440
  %3461 = fadd fast float %3458, 0x3FC1EB8520000000
  %3462 = fadd fast float %3459, 0x3FC1EB8520000000
  %3463 = fadd fast float %3460, 0x3FC1EB8520000000
  %3464 = fdiv fast float %3449, %3461
  %3465 = fdiv fast float %3450, %3462
  %3466 = fdiv fast float %3451, %3463
  br label %3467

; <label>:3467                                    ; preds = %3442, %3428
  %3468 = phi float [ %3464, %3442 ], [ %3438, %3428 ]
  %3469 = phi float [ %3465, %3442 ], [ %3439, %3428 ]
  %3470 = phi float [ %3466, %3442 ], [ %3440, %3428 ]
  %3471 = call float @dx.op.unary.f32(i32 7, float %3468)  ; Saturate(value)
  %3472 = call float @dx.op.unary.f32(i32 7, float %3469)  ; Saturate(value)
  %3473 = call float @dx.op.unary.f32(i32 7, float %3470)  ; Saturate(value)
  %3474 = call float @dx.op.dot3.f32(i32 55, float %3471, float %3472, float %3473, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3475 = fsub fast float %3471, %3474
  %3476 = fsub fast float %3472, %3474
  %3477 = fsub fast float %3473, %3474
  %3478 = fmul fast float %3475, %8
  %3479 = fmul fast float %3476, %8
  %3480 = fmul fast float %3477, %8
  %3481 = fadd fast float %3478, %3474
  %3482 = fadd fast float %3479, %3474
  %3483 = fadd fast float %3480, %3474
  %3484 = call float @dx.op.unary.f32(i32 7, float %3481)  ; Saturate(value)
  %3485 = call float @dx.op.unary.f32(i32 7, float %3482)  ; Saturate(value)
  %3486 = call float @dx.op.unary.f32(i32 7, float %3483)  ; Saturate(value)
  %3487 = fadd fast float %3484, 0xBFC70A3D80000000
  %3488 = fadd fast float %3485, 0xBFC70A3D80000000
  %3489 = fadd fast float %3486, 0xBFC70A3D80000000
  %3490 = fmul fast float %3487, %7
  %3491 = fmul fast float %3488, %7
  %3492 = fmul fast float %3489, %7
  %3493 = fadd fast float %3490, 0x3FC70A3D80000000
  %3494 = fadd fast float %3491, 0x3FC70A3D80000000
  %3495 = fadd fast float %3492, 0x3FC70A3D80000000
  %3496 = call float @dx.op.unary.f32(i32 7, float %3493)  ; Saturate(value)
  %3497 = call float @dx.op.unary.f32(i32 7, float %3494)  ; Saturate(value)
  %3498 = call float @dx.op.unary.f32(i32 7, float %3495)  ; Saturate(value)
  %3499 = add i32 %70, -1
  %3500 = call i32 @dx.op.binary.i32(i32 37, i32 %63, i32 0)  ; IMax(a,b)
  %3501 = call i32 @dx.op.binary.i32(i32 37, i32 %3499, i32 0)  ; IMax(a,b)
  %3502 = call i32 @dx.op.binary.i32(i32 38, i32 %3500, i32 %59)  ; IMin(a,b)
  %3503 = call i32 @dx.op.binary.i32(i32 38, i32 %3501, i32 %60)  ; IMin(a,b)
  %3504 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3502, i32 %3503, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3505 = extractvalue %dx.types.ResRet.f32 %3504, 0
  %3506 = fsub fast float 1.000000e+00, %86
  %3507 = fmul fast float %3506, 0x3FA99999A0000000
  %3508 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %3507)  ; FMax(a,b)
  %3509 = fsub fast float %3505, %86
  %3510 = call float @dx.op.unary.f32(i32 6, float %3509)  ; FAbs(value)
  %3511 = fdiv fast float %3510, %3508
  %3512 = fsub fast float 1.000000e+00, %3511
  %3513 = call float @dx.op.unary.f32(i32 7, float %3512)  ; Saturate(value)
  %3514 = fcmp fast ugt float %3513, 0.000000e+00
  br i1 %3514, label %3515, label %3788

; <label>:3515                                    ; preds = %3467
  %3516 = call i32 @dx.op.binary.i32(i32 37, i32 %3502, i32 0)  ; IMax(a,b)
  %3517 = call i32 @dx.op.binary.i32(i32 37, i32 %3503, i32 0)  ; IMax(a,b)
  %3518 = call i32 @dx.op.binary.i32(i32 38, i32 %3516, i32 %59)  ; IMin(a,b)
  %3519 = call i32 @dx.op.binary.i32(i32 38, i32 %3517, i32 %60)  ; IMin(a,b)
  %3520 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3518, i32 %3519, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3521 = extractvalue %dx.types.ResRet.f32 %3520, 0
  %3522 = extractvalue %dx.types.ResRet.f32 %3520, 1
  %3523 = extractvalue %dx.types.ResRet.f32 %3520, 2
  %3524 = extractvalue %dx.types.ResRet.f32 %3520, 3
  %3525 = fcmp fast olt float %3524, 0.000000e+00
  br i1 %3525, label %3526, label %3560

; <label>:3526                                    ; preds = %3515
  %3527 = fcmp fast ogt float %3521, 0x3FA4B5DCC0000000
  %3528 = fcmp fast ogt float %3522, 0x3FA4B5DCC0000000
  %3529 = fcmp fast ogt float %3523, 0x3FA4B5DCC0000000
  %3530 = select i1 %3527, float 0.000000e+00, float 1.000000e+00
  %3531 = select i1 %3528, float 0.000000e+00, float 1.000000e+00
  %3532 = select i1 %3529, float 0.000000e+00, float 1.000000e+00
  %3533 = fmul fast float %3521, 0x3FB3D07220000000
  %3534 = fmul fast float %3522, 0x3FB3D07220000000
  %3535 = fmul fast float %3523, 0x3FB3D07220000000
  %3536 = fadd fast float %3521, 0x3FAC28F5C0000000
  %3537 = fadd fast float %3522, 0x3FAC28F5C0000000
  %3538 = fadd fast float %3523, 0x3FAC28F5C0000000
  %3539 = fmul fast float %3536, 0x3FEE54EDE0000000
  %3540 = fmul fast float %3537, 0x3FEE54EDE0000000
  %3541 = fmul fast float %3538, 0x3FEE54EDE0000000
  %3542 = call float @dx.op.unary.f32(i32 23, float %3539)  ; Log(value)
  %3543 = call float @dx.op.unary.f32(i32 23, float %3540)  ; Log(value)
  %3544 = call float @dx.op.unary.f32(i32 23, float %3541)  ; Log(value)
  %3545 = fmul fast float %3542, 0x4003333340000000
  %3546 = fmul fast float %3543, 0x4003333340000000
  %3547 = fmul fast float %3544, 0x4003333340000000
  %3548 = call float @dx.op.unary.f32(i32 21, float %3545)  ; Exp(value)
  %3549 = call float @dx.op.unary.f32(i32 21, float %3546)  ; Exp(value)
  %3550 = call float @dx.op.unary.f32(i32 21, float %3547)  ; Exp(value)
  %3551 = fsub fast float %3533, %3548
  %3552 = fsub fast float %3534, %3549
  %3553 = fsub fast float %3535, %3550
  %3554 = fmul fast float %3551, %3530
  %3555 = fmul fast float %3552, %3531
  %3556 = fmul fast float %3553, %3532
  %3557 = fadd fast float %3554, %3548
  %3558 = fadd fast float %3555, %3549
  %3559 = fadd fast float %3556, %3550
  br label %3775

; <label>:3560                                    ; preds = %3515
  %3561 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3518, i32 %3519, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3562 = extractvalue %dx.types.ResRet.f32 %3561, 0
  %3563 = fcmp fast ogt float %38, 5.000000e-01
  %3564 = fcmp fast olt float %3562, 1.000000e+00
  %3565 = and i1 %3563, %3564
  br i1 %3565, label %3566, label %3704

; <label>:3566                                    ; preds = %3560
  %3567 = sitofp i32 %3518 to float
  %3568 = sitofp i32 %3519 to float
  %3569 = fadd fast float %3567, 5.000000e-01
  %3570 = fadd fast float %3568, 5.000000e-01
  %3571 = fdiv fast float %3569, %45
  %3572 = fdiv fast float %3570, %46
  %3573 = fmul fast float %3571, 2.000000e+00
  %3574 = fmul fast float %3572, 2.000000e+00
  %3575 = fadd fast float %3573, -1.000000e+00
  %3576 = fsub fast float 1.000000e+00, %3574
  %3577 = fmul fast float %3575, %35
  %3578 = call float @dx.op.tertiary.f32(i32 46, float %3576, float %31, float %3577)  ; FMad(a,b,c)
  %3579 = call float @dx.op.tertiary.f32(i32 46, float %3562, float %27, float %3578)  ; FMad(a,b,c)
  %3580 = fadd fast float %3579, %23
  %3581 = call float @dx.op.unary.f32(i32 6, float %3580)  ; FAbs(value)
  %3582 = fcmp fast ogt float %3581, 0x3EB0C6F7A0000000
  br i1 %3582, label %3583, label %3704

; <label>:3583                                    ; preds = %3566
  %3584 = fmul fast float %3575, %34
  %3585 = call float @dx.op.tertiary.f32(i32 46, float %3576, float %30, float %3584)  ; FMad(a,b,c)
  %3586 = call float @dx.op.tertiary.f32(i32 46, float %3562, float %26, float %3585)  ; FMad(a,b,c)
  %3587 = fadd fast float %3586, %22
  %3588 = fmul fast float %3575, %33
  %3589 = call float @dx.op.tertiary.f32(i32 46, float %3576, float %29, float %3588)  ; FMad(a,b,c)
  %3590 = call float @dx.op.tertiary.f32(i32 46, float %3562, float %25, float %3589)  ; FMad(a,b,c)
  %3591 = fadd fast float %3590, %21
  %3592 = fmul fast float %3575, %32
  %3593 = call float @dx.op.tertiary.f32(i32 46, float %3576, float %28, float %3592)  ; FMad(a,b,c)
  %3594 = call float @dx.op.tertiary.f32(i32 46, float %3562, float %24, float %3593)  ; FMad(a,b,c)
  %3595 = fadd fast float %3594, %20
  %3596 = fdiv fast float %3595, %3580
  %3597 = fdiv fast float %3591, %3580
  %3598 = fdiv fast float %3587, %3580
  %3599 = fsub fast float %3596, %17
  %3600 = fsub fast float %3597, %18
  %3601 = fsub fast float %3598, %19
  %3602 = fmul fast float %3599, %3599
  %3603 = fmul fast float %3600, %3600
  %3604 = fadd fast float %3603, %3602
  %3605 = fmul fast float %3601, %3601
  %3606 = fadd fast float %3604, %3605
  %3607 = call float @dx.op.unary.f32(i32 24, float %3606)  ; Sqrt(value)
  %3608 = fsub fast float %3607, %9
  %3609 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3608)  ; FMax(a,b)
  %3610 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %3610, label %3611, label %3634

; <label>:3611                                    ; preds = %3583
  %3612 = call float @dx.op.unary.f32(i32 6, float %3600)  ; FAbs(value)
  %3613 = fmul fast float %3612, %11
  %3614 = fcmp fast olt float %3613, 0x3F50624DE0000000
  br i1 %3614, label %3615, label %3618

; <label>:3615                                    ; preds = %3611
  %3616 = fmul fast float %3613, 5.000000e-01
  %3617 = fsub fast float 1.000000e+00, %3616
  br label %3623

; <label>:3618                                    ; preds = %3611
  %3619 = fmul fast float %3613, 0xBFF7154760000000
  %3620 = call float @dx.op.unary.f32(i32 21, float %3619)  ; Exp(value)
  %3621 = fsub fast float 1.000000e+00, %3620
  %3622 = fdiv fast float %3621, %3613
  br label %3623

; <label>:3623                                    ; preds = %3618, %3615
  %3624 = phi float [ %3617, %3615 ], [ %3622, %3618 ]
  %3625 = call float @dx.op.binary.f32(i32 36, float %3597, float %18)  ; FMin(a,b)
  %3626 = fsub fast float %3625, %10
  %3627 = fmul fast float %11, %3626
  %3628 = fsub fast float -0.000000e+00, %3627
  %3629 = call float @dx.op.binary.f32(i32 35, float %3628, float -4.000000e+01)  ; FMax(a,b)
  %3630 = call float @dx.op.binary.f32(i32 36, float %3629, float 5.000000e+00)  ; FMin(a,b)
  %3631 = fmul fast float %3630, 0x3FF7154760000000
  %3632 = call float @dx.op.unary.f32(i32 21, float %3631)  ; Exp(value)
  %3633 = fmul fast float %3632, %3624
  br label %3634

; <label>:3634                                    ; preds = %3623, %3583
  %3635 = phi float [ %3633, %3623 ], [ 1.000000e+00, %3583 ]
  %3636 = fmul fast float %3609, %16
  %3637 = fmul fast float %3636, %3635
  %3638 = fcmp fast ole float %3607, %9
  %3639 = fcmp fast olt float %3607, 0x3F1A36E2E0000000
  %3640 = or i1 %3638, %3639
  br i1 %3640, label %3687, label %3641

; <label>:3641                                    ; preds = %3634
  %3642 = fdiv fast float %9, %3607
  %3643 = fmul fast float %3642, %3599
  %3644 = fmul fast float %3642, %3600
  %3645 = fmul fast float %3642, %3601
  %3646 = fadd fast float %3643, %17
  %3647 = fadd fast float %3644, %18
  %3648 = fadd fast float %3645, %19
  %3649 = fadd fast float %3646, -9.000000e+02
  %3650 = fadd fast float %3647, -1.500000e+01
  %3651 = fadd fast float %3648, -7.500000e+02
  %3652 = fmul fast float %3649, 0x3F62345680000000
  %3653 = fmul fast float %3650, 0x3F62345680000000
  %3654 = fmul fast float %3651, 0x3F62345680000000
  %3655 = call float @dx.op.dot3.f32(i32 55, float %3652, float %3653, float %3654, float %3652, float %3653, float %3654)  ; Dot3(ax,ay,az,bx,by,bz)
  %3656 = fsub fast float 1.000000e+00, %3655
  %3657 = call float @dx.op.unary.f32(i32 7, float %3656)  ; Saturate(value)
  %3658 = fmul fast float %3657, %3657
  %3659 = fadd fast float %3646, %3596
  %3660 = fadd fast float %3647, %3597
  %3661 = fadd fast float %3648, %3598
  %3662 = fmul fast float %3659, 0x3F52345680000000
  %3663 = fadd fast float %3662, -2.000000e+00
  %3664 = fmul fast float %3660, 0x3F52345680000000
  %3665 = fadd fast float %3664, 0xBFA1111120000000
  %3666 = fmul fast float %3661, 0x3F52345680000000
  %3667 = fadd fast float %3666, 0xBFFAAAAAC0000000
  %3668 = call float @dx.op.dot3.f32(i32 55, float %3663, float %3665, float %3667, float %3663, float %3665, float %3667)  ; Dot3(ax,ay,az,bx,by,bz)
  %3669 = fsub fast float 1.000000e+00, %3668
  %3670 = call float @dx.op.unary.f32(i32 7, float %3669)  ; Saturate(value)
  %3671 = fmul fast float %3670, %3670
  %3672 = fmul fast float %3671, 4.000000e+00
  %3673 = fadd fast float %3672, %3658
  %3674 = fadd fast float %3596, -9.000000e+02
  %3675 = fadd fast float %3597, -1.500000e+01
  %3676 = fadd fast float %3598, -7.500000e+02
  %3677 = fmul fast float %3674, 0x3F62345680000000
  %3678 = fmul fast float %3675, 0x3F62345680000000
  %3679 = fmul fast float %3676, 0x3F62345680000000
  %3680 = call float @dx.op.dot3.f32(i32 55, float %3677, float %3678, float %3679, float %3677, float %3678, float %3679)  ; Dot3(ax,ay,az,bx,by,bz)
  %3681 = fsub fast float 1.000000e+00, %3680
  %3682 = call float @dx.op.unary.f32(i32 7, float %3681)  ; Saturate(value)
  %3683 = fmul fast float %3682, %3682
  %3684 = fadd fast float %3673, %3683
  %3685 = fmul fast float %3608, 0x3F25D867E0000000
  %3686 = fmul fast float %3685, %3684
  br label %3687

; <label>:3687                                    ; preds = %3641, %3634
  %3688 = phi float [ %3686, %3641 ], [ 0.000000e+00, %3634 ]
  %3689 = fadd fast float %3688, %3637
  %3690 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3689)  ; FMin(a,b)
  %3691 = fmul fast float %3690, 0xBFF7154760000000
  %3692 = call float @dx.op.unary.f32(i32 21, float %3691)  ; Exp(value)
  %3693 = fsub fast float 1.000000e+00, %3692
  %3694 = call float @dx.op.binary.f32(i32 36, float %12, float %3693)  ; FMin(a,b)
  %3695 = fsub fast float %13, %3521
  %3696 = fsub fast float %14, %3522
  %3697 = fsub fast float %15, %3523
  %3698 = fmul fast float %3694, %3695
  %3699 = fmul fast float %3694, %3696
  %3700 = fmul fast float %3694, %3697
  %3701 = fadd fast float %3698, %3521
  %3702 = fadd fast float %3699, %3522
  %3703 = fadd fast float %3700, %3523
  br label %3704

; <label>:3704                                    ; preds = %3687, %3566, %3560
  %3705 = phi float [ %3701, %3687 ], [ %3521, %3566 ], [ %3521, %3560 ]
  %3706 = phi float [ %3702, %3687 ], [ %3522, %3566 ], [ %3522, %3560 ]
  %3707 = phi float [ %3703, %3687 ], [ %3523, %3566 ], [ %3523, %3560 ]
  %3708 = fadd fast float %5, 1.000000e+00
  %3709 = fadd fast float %6, 1.000000e+00
  %3710 = fsub fast float 1.000000e+00, %5
  %3711 = fmul fast float %36, %3708
  %3712 = fmul fast float %36, %3709
  %3713 = fmul fast float %36, %3710
  %3714 = fmul fast float %3711, %3705
  %3715 = fmul fast float %3712, %3706
  %3716 = fmul fast float %3713, %3707
  %3717 = fcmp fast ult float %37, 5.000000e-01
  br i1 %3717, label %3743, label %3718

; <label>:3718                                    ; preds = %3704
  %3719 = fmul fast float %3714, 0x4004147AE0000000
  %3720 = fmul fast float %3715, 0x4004147AE0000000
  %3721 = fmul fast float %3716, 0x4004147AE0000000
  %3722 = fadd fast float %3719, 0x3F9EB851E0000000
  %3723 = fadd fast float %3720, 0x3F9EB851E0000000
  %3724 = fadd fast float %3721, 0x3F9EB851E0000000
  %3725 = fmul fast float %3722, %3714
  %3726 = fmul fast float %3723, %3715
  %3727 = fmul fast float %3724, %3716
  %3728 = fmul fast float %3714, 0x400370A3E0000000
  %3729 = fmul fast float %3715, 0x400370A3E0000000
  %3730 = fmul fast float %3716, 0x400370A3E0000000
  %3731 = fadd fast float %3728, 0x3FE2E147A0000000
  %3732 = fadd fast float %3729, 0x3FE2E147A0000000
  %3733 = fadd fast float %3730, 0x3FE2E147A0000000
  %3734 = fmul fast float %3731, %3714
  %3735 = fmul fast float %3732, %3715
  %3736 = fmul fast float %3733, %3716
  %3737 = fadd fast float %3734, 0x3FC1EB8520000000
  %3738 = fadd fast float %3735, 0x3FC1EB8520000000
  %3739 = fadd fast float %3736, 0x3FC1EB8520000000
  %3740 = fdiv fast float %3725, %3737
  %3741 = fdiv fast float %3726, %3738
  %3742 = fdiv fast float %3727, %3739
  br label %3743

; <label>:3743                                    ; preds = %3718, %3704
  %3744 = phi float [ %3740, %3718 ], [ %3714, %3704 ]
  %3745 = phi float [ %3741, %3718 ], [ %3715, %3704 ]
  %3746 = phi float [ %3742, %3718 ], [ %3716, %3704 ]
  %3747 = call float @dx.op.unary.f32(i32 7, float %3744)  ; Saturate(value)
  %3748 = call float @dx.op.unary.f32(i32 7, float %3745)  ; Saturate(value)
  %3749 = call float @dx.op.unary.f32(i32 7, float %3746)  ; Saturate(value)
  %3750 = call float @dx.op.dot3.f32(i32 55, float %3747, float %3748, float %3749, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3751 = fsub fast float %3747, %3750
  %3752 = fsub fast float %3748, %3750
  %3753 = fsub fast float %3749, %3750
  %3754 = fmul fast float %3751, %8
  %3755 = fmul fast float %3752, %8
  %3756 = fmul fast float %3753, %8
  %3757 = fadd fast float %3754, %3750
  %3758 = fadd fast float %3755, %3750
  %3759 = fadd fast float %3756, %3750
  %3760 = call float @dx.op.unary.f32(i32 7, float %3757)  ; Saturate(value)
  %3761 = call float @dx.op.unary.f32(i32 7, float %3758)  ; Saturate(value)
  %3762 = call float @dx.op.unary.f32(i32 7, float %3759)  ; Saturate(value)
  %3763 = fadd fast float %3760, 0xBFC70A3D80000000
  %3764 = fadd fast float %3761, 0xBFC70A3D80000000
  %3765 = fadd fast float %3762, 0xBFC70A3D80000000
  %3766 = fmul fast float %3763, %7
  %3767 = fmul fast float %3764, %7
  %3768 = fmul fast float %3765, %7
  %3769 = fadd fast float %3766, 0x3FC70A3D80000000
  %3770 = fadd fast float %3767, 0x3FC70A3D80000000
  %3771 = fadd fast float %3768, 0x3FC70A3D80000000
  %3772 = call float @dx.op.unary.f32(i32 7, float %3769)  ; Saturate(value)
  %3773 = call float @dx.op.unary.f32(i32 7, float %3770)  ; Saturate(value)
  %3774 = call float @dx.op.unary.f32(i32 7, float %3771)  ; Saturate(value)
  br label %3775

; <label>:3775                                    ; preds = %3743, %3526
  %3776 = phi float [ %3557, %3526 ], [ %3772, %3743 ]
  %3777 = phi float [ %3558, %3526 ], [ %3773, %3743 ]
  %3778 = phi float [ %3559, %3526 ], [ %3774, %3743 ]
  %3779 = fsub fast float %3776, %3496
  %3780 = fsub fast float %3777, %3497
  %3781 = fsub fast float %3778, %3498
  %3782 = fmul fast float %3779, %3513
  %3783 = fmul fast float %3780, %3513
  %3784 = fmul fast float %3781, %3513
  %3785 = fadd fast float %3782, %3496
  %3786 = fadd fast float %3783, %3497
  %3787 = fadd fast float %3784, %3498
  br label %3788

; <label>:3788                                    ; preds = %3775, %3467
  %3789 = phi float [ %3785, %3775 ], [ %3496, %3467 ]
  %3790 = phi float [ %3786, %3775 ], [ %3497, %3467 ]
  %3791 = phi float [ %3787, %3775 ], [ %3498, %3467 ]
  %3792 = add i32 %70, 1
  %3793 = call i32 @dx.op.binary.i32(i32 37, i32 %3792, i32 0)  ; IMax(a,b)
  %3794 = call i32 @dx.op.binary.i32(i32 38, i32 %3793, i32 %60)  ; IMin(a,b)
  %3795 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3502, i32 %3794, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3796 = extractvalue %dx.types.ResRet.f32 %3795, 0
  %3797 = fsub fast float %3796, %86
  %3798 = call float @dx.op.unary.f32(i32 6, float %3797)  ; FAbs(value)
  %3799 = fdiv fast float %3798, %3508
  %3800 = fsub fast float 1.000000e+00, %3799
  %3801 = call float @dx.op.unary.f32(i32 7, float %3800)  ; Saturate(value)
  %3802 = fcmp fast ugt float %3801, 0.000000e+00
  br i1 %3802, label %3803, label %4076

; <label>:3803                                    ; preds = %3788
  %3804 = call i32 @dx.op.binary.i32(i32 37, i32 %3502, i32 0)  ; IMax(a,b)
  %3805 = call i32 @dx.op.binary.i32(i32 37, i32 %3794, i32 0)  ; IMax(a,b)
  %3806 = call i32 @dx.op.binary.i32(i32 38, i32 %3804, i32 %59)  ; IMin(a,b)
  %3807 = call i32 @dx.op.binary.i32(i32 38, i32 %3805, i32 %60)  ; IMin(a,b)
  %3808 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3806, i32 %3807, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3809 = extractvalue %dx.types.ResRet.f32 %3808, 0
  %3810 = extractvalue %dx.types.ResRet.f32 %3808, 1
  %3811 = extractvalue %dx.types.ResRet.f32 %3808, 2
  %3812 = extractvalue %dx.types.ResRet.f32 %3808, 3
  %3813 = fcmp fast olt float %3812, 0.000000e+00
  br i1 %3813, label %3814, label %3848

; <label>:3814                                    ; preds = %3803
  %3815 = fcmp fast ogt float %3809, 0x3FA4B5DCC0000000
  %3816 = fcmp fast ogt float %3810, 0x3FA4B5DCC0000000
  %3817 = fcmp fast ogt float %3811, 0x3FA4B5DCC0000000
  %3818 = select i1 %3815, float 0.000000e+00, float 1.000000e+00
  %3819 = select i1 %3816, float 0.000000e+00, float 1.000000e+00
  %3820 = select i1 %3817, float 0.000000e+00, float 1.000000e+00
  %3821 = fmul fast float %3809, 0x3FB3D07220000000
  %3822 = fmul fast float %3810, 0x3FB3D07220000000
  %3823 = fmul fast float %3811, 0x3FB3D07220000000
  %3824 = fadd fast float %3809, 0x3FAC28F5C0000000
  %3825 = fadd fast float %3810, 0x3FAC28F5C0000000
  %3826 = fadd fast float %3811, 0x3FAC28F5C0000000
  %3827 = fmul fast float %3824, 0x3FEE54EDE0000000
  %3828 = fmul fast float %3825, 0x3FEE54EDE0000000
  %3829 = fmul fast float %3826, 0x3FEE54EDE0000000
  %3830 = call float @dx.op.unary.f32(i32 23, float %3827)  ; Log(value)
  %3831 = call float @dx.op.unary.f32(i32 23, float %3828)  ; Log(value)
  %3832 = call float @dx.op.unary.f32(i32 23, float %3829)  ; Log(value)
  %3833 = fmul fast float %3830, 0x4003333340000000
  %3834 = fmul fast float %3831, 0x4003333340000000
  %3835 = fmul fast float %3832, 0x4003333340000000
  %3836 = call float @dx.op.unary.f32(i32 21, float %3833)  ; Exp(value)
  %3837 = call float @dx.op.unary.f32(i32 21, float %3834)  ; Exp(value)
  %3838 = call float @dx.op.unary.f32(i32 21, float %3835)  ; Exp(value)
  %3839 = fsub fast float %3821, %3836
  %3840 = fsub fast float %3822, %3837
  %3841 = fsub fast float %3823, %3838
  %3842 = fmul fast float %3839, %3818
  %3843 = fmul fast float %3840, %3819
  %3844 = fmul fast float %3841, %3820
  %3845 = fadd fast float %3842, %3836
  %3846 = fadd fast float %3843, %3837
  %3847 = fadd fast float %3844, %3838
  br label %4063

; <label>:3848                                    ; preds = %3803
  %3849 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3806, i32 %3807, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3850 = extractvalue %dx.types.ResRet.f32 %3849, 0
  %3851 = fcmp fast ogt float %38, 5.000000e-01
  %3852 = fcmp fast olt float %3850, 1.000000e+00
  %3853 = and i1 %3851, %3852
  br i1 %3853, label %3854, label %3992

; <label>:3854                                    ; preds = %3848
  %3855 = sitofp i32 %3806 to float
  %3856 = sitofp i32 %3807 to float
  %3857 = fadd fast float %3855, 5.000000e-01
  %3858 = fadd fast float %3856, 5.000000e-01
  %3859 = fdiv fast float %3857, %45
  %3860 = fdiv fast float %3858, %46
  %3861 = fmul fast float %3859, 2.000000e+00
  %3862 = fmul fast float %3860, 2.000000e+00
  %3863 = fadd fast float %3861, -1.000000e+00
  %3864 = fsub fast float 1.000000e+00, %3862
  %3865 = fmul fast float %3863, %35
  %3866 = call float @dx.op.tertiary.f32(i32 46, float %3864, float %31, float %3865)  ; FMad(a,b,c)
  %3867 = call float @dx.op.tertiary.f32(i32 46, float %3850, float %27, float %3866)  ; FMad(a,b,c)
  %3868 = fadd fast float %3867, %23
  %3869 = call float @dx.op.unary.f32(i32 6, float %3868)  ; FAbs(value)
  %3870 = fcmp fast ogt float %3869, 0x3EB0C6F7A0000000
  br i1 %3870, label %3871, label %3992

; <label>:3871                                    ; preds = %3854
  %3872 = fmul fast float %3863, %34
  %3873 = call float @dx.op.tertiary.f32(i32 46, float %3864, float %30, float %3872)  ; FMad(a,b,c)
  %3874 = call float @dx.op.tertiary.f32(i32 46, float %3850, float %26, float %3873)  ; FMad(a,b,c)
  %3875 = fadd fast float %3874, %22
  %3876 = fmul fast float %3863, %33
  %3877 = call float @dx.op.tertiary.f32(i32 46, float %3864, float %29, float %3876)  ; FMad(a,b,c)
  %3878 = call float @dx.op.tertiary.f32(i32 46, float %3850, float %25, float %3877)  ; FMad(a,b,c)
  %3879 = fadd fast float %3878, %21
  %3880 = fmul fast float %3863, %32
  %3881 = call float @dx.op.tertiary.f32(i32 46, float %3864, float %28, float %3880)  ; FMad(a,b,c)
  %3882 = call float @dx.op.tertiary.f32(i32 46, float %3850, float %24, float %3881)  ; FMad(a,b,c)
  %3883 = fadd fast float %3882, %20
  %3884 = fdiv fast float %3883, %3868
  %3885 = fdiv fast float %3879, %3868
  %3886 = fdiv fast float %3875, %3868
  %3887 = fsub fast float %3884, %17
  %3888 = fsub fast float %3885, %18
  %3889 = fsub fast float %3886, %19
  %3890 = fmul fast float %3887, %3887
  %3891 = fmul fast float %3888, %3888
  %3892 = fadd fast float %3891, %3890
  %3893 = fmul fast float %3889, %3889
  %3894 = fadd fast float %3892, %3893
  %3895 = call float @dx.op.unary.f32(i32 24, float %3894)  ; Sqrt(value)
  %3896 = fsub fast float %3895, %9
  %3897 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3896)  ; FMax(a,b)
  %3898 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %3898, label %3899, label %3922

; <label>:3899                                    ; preds = %3871
  %3900 = call float @dx.op.unary.f32(i32 6, float %3888)  ; FAbs(value)
  %3901 = fmul fast float %3900, %11
  %3902 = fcmp fast olt float %3901, 0x3F50624DE0000000
  br i1 %3902, label %3903, label %3906

; <label>:3903                                    ; preds = %3899
  %3904 = fmul fast float %3901, 5.000000e-01
  %3905 = fsub fast float 1.000000e+00, %3904
  br label %3911

; <label>:3906                                    ; preds = %3899
  %3907 = fmul fast float %3901, 0xBFF7154760000000
  %3908 = call float @dx.op.unary.f32(i32 21, float %3907)  ; Exp(value)
  %3909 = fsub fast float 1.000000e+00, %3908
  %3910 = fdiv fast float %3909, %3901
  br label %3911

; <label>:3911                                    ; preds = %3906, %3903
  %3912 = phi float [ %3905, %3903 ], [ %3910, %3906 ]
  %3913 = call float @dx.op.binary.f32(i32 36, float %3885, float %18)  ; FMin(a,b)
  %3914 = fsub fast float %3913, %10
  %3915 = fmul fast float %11, %3914
  %3916 = fsub fast float -0.000000e+00, %3915
  %3917 = call float @dx.op.binary.f32(i32 35, float %3916, float -4.000000e+01)  ; FMax(a,b)
  %3918 = call float @dx.op.binary.f32(i32 36, float %3917, float 5.000000e+00)  ; FMin(a,b)
  %3919 = fmul fast float %3918, 0x3FF7154760000000
  %3920 = call float @dx.op.unary.f32(i32 21, float %3919)  ; Exp(value)
  %3921 = fmul fast float %3920, %3912
  br label %3922

; <label>:3922                                    ; preds = %3911, %3871
  %3923 = phi float [ %3921, %3911 ], [ 1.000000e+00, %3871 ]
  %3924 = fmul fast float %3897, %16
  %3925 = fmul fast float %3924, %3923
  %3926 = fcmp fast ole float %3895, %9
  %3927 = fcmp fast olt float %3895, 0x3F1A36E2E0000000
  %3928 = or i1 %3926, %3927
  br i1 %3928, label %3975, label %3929

; <label>:3929                                    ; preds = %3922
  %3930 = fdiv fast float %9, %3895
  %3931 = fmul fast float %3930, %3887
  %3932 = fmul fast float %3930, %3888
  %3933 = fmul fast float %3930, %3889
  %3934 = fadd fast float %3931, %17
  %3935 = fadd fast float %3932, %18
  %3936 = fadd fast float %3933, %19
  %3937 = fadd fast float %3934, -9.000000e+02
  %3938 = fadd fast float %3935, -1.500000e+01
  %3939 = fadd fast float %3936, -7.500000e+02
  %3940 = fmul fast float %3937, 0x3F62345680000000
  %3941 = fmul fast float %3938, 0x3F62345680000000
  %3942 = fmul fast float %3939, 0x3F62345680000000
  %3943 = call float @dx.op.dot3.f32(i32 55, float %3940, float %3941, float %3942, float %3940, float %3941, float %3942)  ; Dot3(ax,ay,az,bx,by,bz)
  %3944 = fsub fast float 1.000000e+00, %3943
  %3945 = call float @dx.op.unary.f32(i32 7, float %3944)  ; Saturate(value)
  %3946 = fmul fast float %3945, %3945
  %3947 = fadd fast float %3934, %3884
  %3948 = fadd fast float %3935, %3885
  %3949 = fadd fast float %3936, %3886
  %3950 = fmul fast float %3947, 0x3F52345680000000
  %3951 = fadd fast float %3950, -2.000000e+00
  %3952 = fmul fast float %3948, 0x3F52345680000000
  %3953 = fadd fast float %3952, 0xBFA1111120000000
  %3954 = fmul fast float %3949, 0x3F52345680000000
  %3955 = fadd fast float %3954, 0xBFFAAAAAC0000000
  %3956 = call float @dx.op.dot3.f32(i32 55, float %3951, float %3953, float %3955, float %3951, float %3953, float %3955)  ; Dot3(ax,ay,az,bx,by,bz)
  %3957 = fsub fast float 1.000000e+00, %3956
  %3958 = call float @dx.op.unary.f32(i32 7, float %3957)  ; Saturate(value)
  %3959 = fmul fast float %3958, %3958
  %3960 = fmul fast float %3959, 4.000000e+00
  %3961 = fadd fast float %3960, %3946
  %3962 = fadd fast float %3884, -9.000000e+02
  %3963 = fadd fast float %3885, -1.500000e+01
  %3964 = fadd fast float %3886, -7.500000e+02
  %3965 = fmul fast float %3962, 0x3F62345680000000
  %3966 = fmul fast float %3963, 0x3F62345680000000
  %3967 = fmul fast float %3964, 0x3F62345680000000
  %3968 = call float @dx.op.dot3.f32(i32 55, float %3965, float %3966, float %3967, float %3965, float %3966, float %3967)  ; Dot3(ax,ay,az,bx,by,bz)
  %3969 = fsub fast float 1.000000e+00, %3968
  %3970 = call float @dx.op.unary.f32(i32 7, float %3969)  ; Saturate(value)
  %3971 = fmul fast float %3970, %3970
  %3972 = fadd fast float %3961, %3971
  %3973 = fmul fast float %3896, 0x3F25D867E0000000
  %3974 = fmul fast float %3973, %3972
  br label %3975

; <label>:3975                                    ; preds = %3929, %3922
  %3976 = phi float [ %3974, %3929 ], [ 0.000000e+00, %3922 ]
  %3977 = fadd fast float %3976, %3925
  %3978 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3977)  ; FMin(a,b)
  %3979 = fmul fast float %3978, 0xBFF7154760000000
  %3980 = call float @dx.op.unary.f32(i32 21, float %3979)  ; Exp(value)
  %3981 = fsub fast float 1.000000e+00, %3980
  %3982 = call float @dx.op.binary.f32(i32 36, float %12, float %3981)  ; FMin(a,b)
  %3983 = fsub fast float %13, %3809
  %3984 = fsub fast float %14, %3810
  %3985 = fsub fast float %15, %3811
  %3986 = fmul fast float %3982, %3983
  %3987 = fmul fast float %3982, %3984
  %3988 = fmul fast float %3982, %3985
  %3989 = fadd fast float %3986, %3809
  %3990 = fadd fast float %3987, %3810
  %3991 = fadd fast float %3988, %3811
  br label %3992

; <label>:3992                                    ; preds = %3975, %3854, %3848
  %3993 = phi float [ %3989, %3975 ], [ %3809, %3854 ], [ %3809, %3848 ]
  %3994 = phi float [ %3990, %3975 ], [ %3810, %3854 ], [ %3810, %3848 ]
  %3995 = phi float [ %3991, %3975 ], [ %3811, %3854 ], [ %3811, %3848 ]
  %3996 = fadd fast float %5, 1.000000e+00
  %3997 = fadd fast float %6, 1.000000e+00
  %3998 = fsub fast float 1.000000e+00, %5
  %3999 = fmul fast float %36, %3996
  %4000 = fmul fast float %36, %3997
  %4001 = fmul fast float %36, %3998
  %4002 = fmul fast float %3999, %3993
  %4003 = fmul fast float %4000, %3994
  %4004 = fmul fast float %4001, %3995
  %4005 = fcmp fast ult float %37, 5.000000e-01
  br i1 %4005, label %4031, label %4006

; <label>:4006                                    ; preds = %3992
  %4007 = fmul fast float %4002, 0x4004147AE0000000
  %4008 = fmul fast float %4003, 0x4004147AE0000000
  %4009 = fmul fast float %4004, 0x4004147AE0000000
  %4010 = fadd fast float %4007, 0x3F9EB851E0000000
  %4011 = fadd fast float %4008, 0x3F9EB851E0000000
  %4012 = fadd fast float %4009, 0x3F9EB851E0000000
  %4013 = fmul fast float %4010, %4002
  %4014 = fmul fast float %4011, %4003
  %4015 = fmul fast float %4012, %4004
  %4016 = fmul fast float %4002, 0x400370A3E0000000
  %4017 = fmul fast float %4003, 0x400370A3E0000000
  %4018 = fmul fast float %4004, 0x400370A3E0000000
  %4019 = fadd fast float %4016, 0x3FE2E147A0000000
  %4020 = fadd fast float %4017, 0x3FE2E147A0000000
  %4021 = fadd fast float %4018, 0x3FE2E147A0000000
  %4022 = fmul fast float %4019, %4002
  %4023 = fmul fast float %4020, %4003
  %4024 = fmul fast float %4021, %4004
  %4025 = fadd fast float %4022, 0x3FC1EB8520000000
  %4026 = fadd fast float %4023, 0x3FC1EB8520000000
  %4027 = fadd fast float %4024, 0x3FC1EB8520000000
  %4028 = fdiv fast float %4013, %4025
  %4029 = fdiv fast float %4014, %4026
  %4030 = fdiv fast float %4015, %4027
  br label %4031

; <label>:4031                                    ; preds = %4006, %3992
  %4032 = phi float [ %4028, %4006 ], [ %4002, %3992 ]
  %4033 = phi float [ %4029, %4006 ], [ %4003, %3992 ]
  %4034 = phi float [ %4030, %4006 ], [ %4004, %3992 ]
  %4035 = call float @dx.op.unary.f32(i32 7, float %4032)  ; Saturate(value)
  %4036 = call float @dx.op.unary.f32(i32 7, float %4033)  ; Saturate(value)
  %4037 = call float @dx.op.unary.f32(i32 7, float %4034)  ; Saturate(value)
  %4038 = call float @dx.op.dot3.f32(i32 55, float %4035, float %4036, float %4037, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4039 = fsub fast float %4035, %4038
  %4040 = fsub fast float %4036, %4038
  %4041 = fsub fast float %4037, %4038
  %4042 = fmul fast float %4039, %8
  %4043 = fmul fast float %4040, %8
  %4044 = fmul fast float %4041, %8
  %4045 = fadd fast float %4042, %4038
  %4046 = fadd fast float %4043, %4038
  %4047 = fadd fast float %4044, %4038
  %4048 = call float @dx.op.unary.f32(i32 7, float %4045)  ; Saturate(value)
  %4049 = call float @dx.op.unary.f32(i32 7, float %4046)  ; Saturate(value)
  %4050 = call float @dx.op.unary.f32(i32 7, float %4047)  ; Saturate(value)
  %4051 = fadd fast float %4048, 0xBFC70A3D80000000
  %4052 = fadd fast float %4049, 0xBFC70A3D80000000
  %4053 = fadd fast float %4050, 0xBFC70A3D80000000
  %4054 = fmul fast float %4051, %7
  %4055 = fmul fast float %4052, %7
  %4056 = fmul fast float %4053, %7
  %4057 = fadd fast float %4054, 0x3FC70A3D80000000
  %4058 = fadd fast float %4055, 0x3FC70A3D80000000
  %4059 = fadd fast float %4056, 0x3FC70A3D80000000
  %4060 = call float @dx.op.unary.f32(i32 7, float %4057)  ; Saturate(value)
  %4061 = call float @dx.op.unary.f32(i32 7, float %4058)  ; Saturate(value)
  %4062 = call float @dx.op.unary.f32(i32 7, float %4059)  ; Saturate(value)
  br label %4063

; <label>:4063                                    ; preds = %4031, %3814
  %4064 = phi float [ %3845, %3814 ], [ %4060, %4031 ]
  %4065 = phi float [ %3846, %3814 ], [ %4061, %4031 ]
  %4066 = phi float [ %3847, %3814 ], [ %4062, %4031 ]
  %4067 = fsub fast float %4064, %3496
  %4068 = fsub fast float %4065, %3497
  %4069 = fsub fast float %4066, %3498
  %4070 = fmul fast float %4067, %3801
  %4071 = fmul fast float %4068, %3801
  %4072 = fmul fast float %4069, %3801
  %4073 = fadd fast float %4070, %3496
  %4074 = fadd fast float %4071, %3497
  %4075 = fadd fast float %4072, %3498
  br label %4076

; <label>:4076                                    ; preds = %4063, %3788
  %4077 = phi float [ %4073, %4063 ], [ %3496, %3788 ]
  %4078 = phi float [ %4074, %4063 ], [ %3497, %3788 ]
  %4079 = phi float [ %4075, %4063 ], [ %3498, %3788 ]
  %4080 = add i32 %63, -1
  %4081 = call i32 @dx.op.binary.i32(i32 37, i32 %4080, i32 0)  ; IMax(a,b)
  %4082 = call i32 @dx.op.binary.i32(i32 37, i32 %70, i32 0)  ; IMax(a,b)
  %4083 = call i32 @dx.op.binary.i32(i32 38, i32 %4081, i32 %59)  ; IMin(a,b)
  %4084 = call i32 @dx.op.binary.i32(i32 38, i32 %4082, i32 %60)  ; IMin(a,b)
  %4085 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4083, i32 %4084, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4086 = extractvalue %dx.types.ResRet.f32 %4085, 0
  %4087 = fsub fast float %4086, %86
  %4088 = call float @dx.op.unary.f32(i32 6, float %4087)  ; FAbs(value)
  %4089 = fdiv fast float %4088, %3508
  %4090 = fsub fast float 1.000000e+00, %4089
  %4091 = call float @dx.op.unary.f32(i32 7, float %4090)  ; Saturate(value)
  %4092 = fcmp fast ugt float %4091, 0.000000e+00
  br i1 %4092, label %4093, label %4366

; <label>:4093                                    ; preds = %4076
  %4094 = call i32 @dx.op.binary.i32(i32 37, i32 %4083, i32 0)  ; IMax(a,b)
  %4095 = call i32 @dx.op.binary.i32(i32 37, i32 %4084, i32 0)  ; IMax(a,b)
  %4096 = call i32 @dx.op.binary.i32(i32 38, i32 %4094, i32 %59)  ; IMin(a,b)
  %4097 = call i32 @dx.op.binary.i32(i32 38, i32 %4095, i32 %60)  ; IMin(a,b)
  %4098 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4096, i32 %4097, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4099 = extractvalue %dx.types.ResRet.f32 %4098, 0
  %4100 = extractvalue %dx.types.ResRet.f32 %4098, 1
  %4101 = extractvalue %dx.types.ResRet.f32 %4098, 2
  %4102 = extractvalue %dx.types.ResRet.f32 %4098, 3
  %4103 = fcmp fast olt float %4102, 0.000000e+00
  br i1 %4103, label %4104, label %4138

; <label>:4104                                    ; preds = %4093
  %4105 = fcmp fast ogt float %4099, 0x3FA4B5DCC0000000
  %4106 = fcmp fast ogt float %4100, 0x3FA4B5DCC0000000
  %4107 = fcmp fast ogt float %4101, 0x3FA4B5DCC0000000
  %4108 = select i1 %4105, float 0.000000e+00, float 1.000000e+00
  %4109 = select i1 %4106, float 0.000000e+00, float 1.000000e+00
  %4110 = select i1 %4107, float 0.000000e+00, float 1.000000e+00
  %4111 = fmul fast float %4099, 0x3FB3D07220000000
  %4112 = fmul fast float %4100, 0x3FB3D07220000000
  %4113 = fmul fast float %4101, 0x3FB3D07220000000
  %4114 = fadd fast float %4099, 0x3FAC28F5C0000000
  %4115 = fadd fast float %4100, 0x3FAC28F5C0000000
  %4116 = fadd fast float %4101, 0x3FAC28F5C0000000
  %4117 = fmul fast float %4114, 0x3FEE54EDE0000000
  %4118 = fmul fast float %4115, 0x3FEE54EDE0000000
  %4119 = fmul fast float %4116, 0x3FEE54EDE0000000
  %4120 = call float @dx.op.unary.f32(i32 23, float %4117)  ; Log(value)
  %4121 = call float @dx.op.unary.f32(i32 23, float %4118)  ; Log(value)
  %4122 = call float @dx.op.unary.f32(i32 23, float %4119)  ; Log(value)
  %4123 = fmul fast float %4120, 0x4003333340000000
  %4124 = fmul fast float %4121, 0x4003333340000000
  %4125 = fmul fast float %4122, 0x4003333340000000
  %4126 = call float @dx.op.unary.f32(i32 21, float %4123)  ; Exp(value)
  %4127 = call float @dx.op.unary.f32(i32 21, float %4124)  ; Exp(value)
  %4128 = call float @dx.op.unary.f32(i32 21, float %4125)  ; Exp(value)
  %4129 = fsub fast float %4111, %4126
  %4130 = fsub fast float %4112, %4127
  %4131 = fsub fast float %4113, %4128
  %4132 = fmul fast float %4129, %4108
  %4133 = fmul fast float %4130, %4109
  %4134 = fmul fast float %4131, %4110
  %4135 = fadd fast float %4132, %4126
  %4136 = fadd fast float %4133, %4127
  %4137 = fadd fast float %4134, %4128
  br label %4353

; <label>:4138                                    ; preds = %4093
  %4139 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4096, i32 %4097, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4140 = extractvalue %dx.types.ResRet.f32 %4139, 0
  %4141 = fcmp fast ogt float %38, 5.000000e-01
  %4142 = fcmp fast olt float %4140, 1.000000e+00
  %4143 = and i1 %4141, %4142
  br i1 %4143, label %4144, label %4282

; <label>:4144                                    ; preds = %4138
  %4145 = sitofp i32 %4096 to float
  %4146 = sitofp i32 %4097 to float
  %4147 = fadd fast float %4145, 5.000000e-01
  %4148 = fadd fast float %4146, 5.000000e-01
  %4149 = fdiv fast float %4147, %45
  %4150 = fdiv fast float %4148, %46
  %4151 = fmul fast float %4149, 2.000000e+00
  %4152 = fmul fast float %4150, 2.000000e+00
  %4153 = fadd fast float %4151, -1.000000e+00
  %4154 = fsub fast float 1.000000e+00, %4152
  %4155 = fmul fast float %4153, %35
  %4156 = call float @dx.op.tertiary.f32(i32 46, float %4154, float %31, float %4155)  ; FMad(a,b,c)
  %4157 = call float @dx.op.tertiary.f32(i32 46, float %4140, float %27, float %4156)  ; FMad(a,b,c)
  %4158 = fadd fast float %4157, %23
  %4159 = call float @dx.op.unary.f32(i32 6, float %4158)  ; FAbs(value)
  %4160 = fcmp fast ogt float %4159, 0x3EB0C6F7A0000000
  br i1 %4160, label %4161, label %4282

; <label>:4161                                    ; preds = %4144
  %4162 = fmul fast float %4153, %34
  %4163 = call float @dx.op.tertiary.f32(i32 46, float %4154, float %30, float %4162)  ; FMad(a,b,c)
  %4164 = call float @dx.op.tertiary.f32(i32 46, float %4140, float %26, float %4163)  ; FMad(a,b,c)
  %4165 = fadd fast float %4164, %22
  %4166 = fmul fast float %4153, %33
  %4167 = call float @dx.op.tertiary.f32(i32 46, float %4154, float %29, float %4166)  ; FMad(a,b,c)
  %4168 = call float @dx.op.tertiary.f32(i32 46, float %4140, float %25, float %4167)  ; FMad(a,b,c)
  %4169 = fadd fast float %4168, %21
  %4170 = fmul fast float %4153, %32
  %4171 = call float @dx.op.tertiary.f32(i32 46, float %4154, float %28, float %4170)  ; FMad(a,b,c)
  %4172 = call float @dx.op.tertiary.f32(i32 46, float %4140, float %24, float %4171)  ; FMad(a,b,c)
  %4173 = fadd fast float %4172, %20
  %4174 = fdiv fast float %4173, %4158
  %4175 = fdiv fast float %4169, %4158
  %4176 = fdiv fast float %4165, %4158
  %4177 = fsub fast float %4174, %17
  %4178 = fsub fast float %4175, %18
  %4179 = fsub fast float %4176, %19
  %4180 = fmul fast float %4177, %4177
  %4181 = fmul fast float %4178, %4178
  %4182 = fadd fast float %4181, %4180
  %4183 = fmul fast float %4179, %4179
  %4184 = fadd fast float %4182, %4183
  %4185 = call float @dx.op.unary.f32(i32 24, float %4184)  ; Sqrt(value)
  %4186 = fsub fast float %4185, %9
  %4187 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4186)  ; FMax(a,b)
  %4188 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %4188, label %4189, label %4212

; <label>:4189                                    ; preds = %4161
  %4190 = call float @dx.op.unary.f32(i32 6, float %4178)  ; FAbs(value)
  %4191 = fmul fast float %4190, %11
  %4192 = fcmp fast olt float %4191, 0x3F50624DE0000000
  br i1 %4192, label %4193, label %4196

; <label>:4193                                    ; preds = %4189
  %4194 = fmul fast float %4191, 5.000000e-01
  %4195 = fsub fast float 1.000000e+00, %4194
  br label %4201

; <label>:4196                                    ; preds = %4189
  %4197 = fmul fast float %4191, 0xBFF7154760000000
  %4198 = call float @dx.op.unary.f32(i32 21, float %4197)  ; Exp(value)
  %4199 = fsub fast float 1.000000e+00, %4198
  %4200 = fdiv fast float %4199, %4191
  br label %4201

; <label>:4201                                    ; preds = %4196, %4193
  %4202 = phi float [ %4195, %4193 ], [ %4200, %4196 ]
  %4203 = call float @dx.op.binary.f32(i32 36, float %4175, float %18)  ; FMin(a,b)
  %4204 = fsub fast float %4203, %10
  %4205 = fmul fast float %11, %4204
  %4206 = fsub fast float -0.000000e+00, %4205
  %4207 = call float @dx.op.binary.f32(i32 35, float %4206, float -4.000000e+01)  ; FMax(a,b)
  %4208 = call float @dx.op.binary.f32(i32 36, float %4207, float 5.000000e+00)  ; FMin(a,b)
  %4209 = fmul fast float %4208, 0x3FF7154760000000
  %4210 = call float @dx.op.unary.f32(i32 21, float %4209)  ; Exp(value)
  %4211 = fmul fast float %4210, %4202
  br label %4212

; <label>:4212                                    ; preds = %4201, %4161
  %4213 = phi float [ %4211, %4201 ], [ 1.000000e+00, %4161 ]
  %4214 = fmul fast float %4187, %16
  %4215 = fmul fast float %4214, %4213
  %4216 = fcmp fast ole float %4185, %9
  %4217 = fcmp fast olt float %4185, 0x3F1A36E2E0000000
  %4218 = or i1 %4216, %4217
  br i1 %4218, label %4265, label %4219

; <label>:4219                                    ; preds = %4212
  %4220 = fdiv fast float %9, %4185
  %4221 = fmul fast float %4220, %4177
  %4222 = fmul fast float %4220, %4178
  %4223 = fmul fast float %4220, %4179
  %4224 = fadd fast float %4221, %17
  %4225 = fadd fast float %4222, %18
  %4226 = fadd fast float %4223, %19
  %4227 = fadd fast float %4224, -9.000000e+02
  %4228 = fadd fast float %4225, -1.500000e+01
  %4229 = fadd fast float %4226, -7.500000e+02
  %4230 = fmul fast float %4227, 0x3F62345680000000
  %4231 = fmul fast float %4228, 0x3F62345680000000
  %4232 = fmul fast float %4229, 0x3F62345680000000
  %4233 = call float @dx.op.dot3.f32(i32 55, float %4230, float %4231, float %4232, float %4230, float %4231, float %4232)  ; Dot3(ax,ay,az,bx,by,bz)
  %4234 = fsub fast float 1.000000e+00, %4233
  %4235 = call float @dx.op.unary.f32(i32 7, float %4234)  ; Saturate(value)
  %4236 = fmul fast float %4235, %4235
  %4237 = fadd fast float %4224, %4174
  %4238 = fadd fast float %4225, %4175
  %4239 = fadd fast float %4226, %4176
  %4240 = fmul fast float %4237, 0x3F52345680000000
  %4241 = fadd fast float %4240, -2.000000e+00
  %4242 = fmul fast float %4238, 0x3F52345680000000
  %4243 = fadd fast float %4242, 0xBFA1111120000000
  %4244 = fmul fast float %4239, 0x3F52345680000000
  %4245 = fadd fast float %4244, 0xBFFAAAAAC0000000
  %4246 = call float @dx.op.dot3.f32(i32 55, float %4241, float %4243, float %4245, float %4241, float %4243, float %4245)  ; Dot3(ax,ay,az,bx,by,bz)
  %4247 = fsub fast float 1.000000e+00, %4246
  %4248 = call float @dx.op.unary.f32(i32 7, float %4247)  ; Saturate(value)
  %4249 = fmul fast float %4248, %4248
  %4250 = fmul fast float %4249, 4.000000e+00
  %4251 = fadd fast float %4250, %4236
  %4252 = fadd fast float %4174, -9.000000e+02
  %4253 = fadd fast float %4175, -1.500000e+01
  %4254 = fadd fast float %4176, -7.500000e+02
  %4255 = fmul fast float %4252, 0x3F62345680000000
  %4256 = fmul fast float %4253, 0x3F62345680000000
  %4257 = fmul fast float %4254, 0x3F62345680000000
  %4258 = call float @dx.op.dot3.f32(i32 55, float %4255, float %4256, float %4257, float %4255, float %4256, float %4257)  ; Dot3(ax,ay,az,bx,by,bz)
  %4259 = fsub fast float 1.000000e+00, %4258
  %4260 = call float @dx.op.unary.f32(i32 7, float %4259)  ; Saturate(value)
  %4261 = fmul fast float %4260, %4260
  %4262 = fadd fast float %4251, %4261
  %4263 = fmul fast float %4186, 0x3F25D867E0000000
  %4264 = fmul fast float %4263, %4262
  br label %4265

; <label>:4265                                    ; preds = %4219, %4212
  %4266 = phi float [ %4264, %4219 ], [ 0.000000e+00, %4212 ]
  %4267 = fadd fast float %4266, %4215
  %4268 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4267)  ; FMin(a,b)
  %4269 = fmul fast float %4268, 0xBFF7154760000000
  %4270 = call float @dx.op.unary.f32(i32 21, float %4269)  ; Exp(value)
  %4271 = fsub fast float 1.000000e+00, %4270
  %4272 = call float @dx.op.binary.f32(i32 36, float %12, float %4271)  ; FMin(a,b)
  %4273 = fsub fast float %13, %4099
  %4274 = fsub fast float %14, %4100
  %4275 = fsub fast float %15, %4101
  %4276 = fmul fast float %4272, %4273
  %4277 = fmul fast float %4272, %4274
  %4278 = fmul fast float %4272, %4275
  %4279 = fadd fast float %4276, %4099
  %4280 = fadd fast float %4277, %4100
  %4281 = fadd fast float %4278, %4101
  br label %4282

; <label>:4282                                    ; preds = %4265, %4144, %4138
  %4283 = phi float [ %4279, %4265 ], [ %4099, %4144 ], [ %4099, %4138 ]
  %4284 = phi float [ %4280, %4265 ], [ %4100, %4144 ], [ %4100, %4138 ]
  %4285 = phi float [ %4281, %4265 ], [ %4101, %4144 ], [ %4101, %4138 ]
  %4286 = fadd fast float %5, 1.000000e+00
  %4287 = fadd fast float %6, 1.000000e+00
  %4288 = fsub fast float 1.000000e+00, %5
  %4289 = fmul fast float %36, %4286
  %4290 = fmul fast float %36, %4287
  %4291 = fmul fast float %36, %4288
  %4292 = fmul fast float %4289, %4283
  %4293 = fmul fast float %4290, %4284
  %4294 = fmul fast float %4291, %4285
  %4295 = fcmp fast ult float %37, 5.000000e-01
  br i1 %4295, label %4321, label %4296

; <label>:4296                                    ; preds = %4282
  %4297 = fmul fast float %4292, 0x4004147AE0000000
  %4298 = fmul fast float %4293, 0x4004147AE0000000
  %4299 = fmul fast float %4294, 0x4004147AE0000000
  %4300 = fadd fast float %4297, 0x3F9EB851E0000000
  %4301 = fadd fast float %4298, 0x3F9EB851E0000000
  %4302 = fadd fast float %4299, 0x3F9EB851E0000000
  %4303 = fmul fast float %4300, %4292
  %4304 = fmul fast float %4301, %4293
  %4305 = fmul fast float %4302, %4294
  %4306 = fmul fast float %4292, 0x400370A3E0000000
  %4307 = fmul fast float %4293, 0x400370A3E0000000
  %4308 = fmul fast float %4294, 0x400370A3E0000000
  %4309 = fadd fast float %4306, 0x3FE2E147A0000000
  %4310 = fadd fast float %4307, 0x3FE2E147A0000000
  %4311 = fadd fast float %4308, 0x3FE2E147A0000000
  %4312 = fmul fast float %4309, %4292
  %4313 = fmul fast float %4310, %4293
  %4314 = fmul fast float %4311, %4294
  %4315 = fadd fast float %4312, 0x3FC1EB8520000000
  %4316 = fadd fast float %4313, 0x3FC1EB8520000000
  %4317 = fadd fast float %4314, 0x3FC1EB8520000000
  %4318 = fdiv fast float %4303, %4315
  %4319 = fdiv fast float %4304, %4316
  %4320 = fdiv fast float %4305, %4317
  br label %4321

; <label>:4321                                    ; preds = %4296, %4282
  %4322 = phi float [ %4318, %4296 ], [ %4292, %4282 ]
  %4323 = phi float [ %4319, %4296 ], [ %4293, %4282 ]
  %4324 = phi float [ %4320, %4296 ], [ %4294, %4282 ]
  %4325 = call float @dx.op.unary.f32(i32 7, float %4322)  ; Saturate(value)
  %4326 = call float @dx.op.unary.f32(i32 7, float %4323)  ; Saturate(value)
  %4327 = call float @dx.op.unary.f32(i32 7, float %4324)  ; Saturate(value)
  %4328 = call float @dx.op.dot3.f32(i32 55, float %4325, float %4326, float %4327, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4329 = fsub fast float %4325, %4328
  %4330 = fsub fast float %4326, %4328
  %4331 = fsub fast float %4327, %4328
  %4332 = fmul fast float %4329, %8
  %4333 = fmul fast float %4330, %8
  %4334 = fmul fast float %4331, %8
  %4335 = fadd fast float %4332, %4328
  %4336 = fadd fast float %4333, %4328
  %4337 = fadd fast float %4334, %4328
  %4338 = call float @dx.op.unary.f32(i32 7, float %4335)  ; Saturate(value)
  %4339 = call float @dx.op.unary.f32(i32 7, float %4336)  ; Saturate(value)
  %4340 = call float @dx.op.unary.f32(i32 7, float %4337)  ; Saturate(value)
  %4341 = fadd fast float %4338, 0xBFC70A3D80000000
  %4342 = fadd fast float %4339, 0xBFC70A3D80000000
  %4343 = fadd fast float %4340, 0xBFC70A3D80000000
  %4344 = fmul fast float %4341, %7
  %4345 = fmul fast float %4342, %7
  %4346 = fmul fast float %4343, %7
  %4347 = fadd fast float %4344, 0x3FC70A3D80000000
  %4348 = fadd fast float %4345, 0x3FC70A3D80000000
  %4349 = fadd fast float %4346, 0x3FC70A3D80000000
  %4350 = call float @dx.op.unary.f32(i32 7, float %4347)  ; Saturate(value)
  %4351 = call float @dx.op.unary.f32(i32 7, float %4348)  ; Saturate(value)
  %4352 = call float @dx.op.unary.f32(i32 7, float %4349)  ; Saturate(value)
  br label %4353

; <label>:4353                                    ; preds = %4321, %4104
  %4354 = phi float [ %4135, %4104 ], [ %4350, %4321 ]
  %4355 = phi float [ %4136, %4104 ], [ %4351, %4321 ]
  %4356 = phi float [ %4137, %4104 ], [ %4352, %4321 ]
  %4357 = fsub fast float %4354, %3496
  %4358 = fsub fast float %4355, %3497
  %4359 = fsub fast float %4356, %3498
  %4360 = fmul fast float %4357, %4091
  %4361 = fmul fast float %4358, %4091
  %4362 = fmul fast float %4359, %4091
  %4363 = fadd fast float %4360, %3496
  %4364 = fadd fast float %4361, %3497
  %4365 = fadd fast float %4362, %3498
  br label %4366

; <label>:4366                                    ; preds = %4353, %4076
  %4367 = phi float [ %4363, %4353 ], [ %3496, %4076 ]
  %4368 = phi float [ %4364, %4353 ], [ %3497, %4076 ]
  %4369 = phi float [ %4365, %4353 ], [ %3498, %4076 ]
  %4370 = add i32 %63, 1
  %4371 = call i32 @dx.op.binary.i32(i32 37, i32 %4370, i32 0)  ; IMax(a,b)
  %4372 = call i32 @dx.op.binary.i32(i32 38, i32 %4371, i32 %59)  ; IMin(a,b)
  %4373 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4372, i32 %4084, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4374 = extractvalue %dx.types.ResRet.f32 %4373, 0
  %4375 = fsub fast float %4374, %86
  %4376 = call float @dx.op.unary.f32(i32 6, float %4375)  ; FAbs(value)
  %4377 = fdiv fast float %4376, %3508
  %4378 = fsub fast float 1.000000e+00, %4377
  %4379 = call float @dx.op.unary.f32(i32 7, float %4378)  ; Saturate(value)
  %4380 = fcmp fast ugt float %4379, 0.000000e+00
  br i1 %4380, label %4381, label %4654

; <label>:4381                                    ; preds = %4366
  %4382 = call i32 @dx.op.binary.i32(i32 37, i32 %4372, i32 0)  ; IMax(a,b)
  %4383 = call i32 @dx.op.binary.i32(i32 37, i32 %4084, i32 0)  ; IMax(a,b)
  %4384 = call i32 @dx.op.binary.i32(i32 38, i32 %4382, i32 %59)  ; IMin(a,b)
  %4385 = call i32 @dx.op.binary.i32(i32 38, i32 %4383, i32 %60)  ; IMin(a,b)
  %4386 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4384, i32 %4385, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4387 = extractvalue %dx.types.ResRet.f32 %4386, 0
  %4388 = extractvalue %dx.types.ResRet.f32 %4386, 1
  %4389 = extractvalue %dx.types.ResRet.f32 %4386, 2
  %4390 = extractvalue %dx.types.ResRet.f32 %4386, 3
  %4391 = fcmp fast olt float %4390, 0.000000e+00
  br i1 %4391, label %4392, label %4426

; <label>:4392                                    ; preds = %4381
  %4393 = fcmp fast ogt float %4387, 0x3FA4B5DCC0000000
  %4394 = fcmp fast ogt float %4388, 0x3FA4B5DCC0000000
  %4395 = fcmp fast ogt float %4389, 0x3FA4B5DCC0000000
  %4396 = select i1 %4393, float 0.000000e+00, float 1.000000e+00
  %4397 = select i1 %4394, float 0.000000e+00, float 1.000000e+00
  %4398 = select i1 %4395, float 0.000000e+00, float 1.000000e+00
  %4399 = fmul fast float %4387, 0x3FB3D07220000000
  %4400 = fmul fast float %4388, 0x3FB3D07220000000
  %4401 = fmul fast float %4389, 0x3FB3D07220000000
  %4402 = fadd fast float %4387, 0x3FAC28F5C0000000
  %4403 = fadd fast float %4388, 0x3FAC28F5C0000000
  %4404 = fadd fast float %4389, 0x3FAC28F5C0000000
  %4405 = fmul fast float %4402, 0x3FEE54EDE0000000
  %4406 = fmul fast float %4403, 0x3FEE54EDE0000000
  %4407 = fmul fast float %4404, 0x3FEE54EDE0000000
  %4408 = call float @dx.op.unary.f32(i32 23, float %4405)  ; Log(value)
  %4409 = call float @dx.op.unary.f32(i32 23, float %4406)  ; Log(value)
  %4410 = call float @dx.op.unary.f32(i32 23, float %4407)  ; Log(value)
  %4411 = fmul fast float %4408, 0x4003333340000000
  %4412 = fmul fast float %4409, 0x4003333340000000
  %4413 = fmul fast float %4410, 0x4003333340000000
  %4414 = call float @dx.op.unary.f32(i32 21, float %4411)  ; Exp(value)
  %4415 = call float @dx.op.unary.f32(i32 21, float %4412)  ; Exp(value)
  %4416 = call float @dx.op.unary.f32(i32 21, float %4413)  ; Exp(value)
  %4417 = fsub fast float %4399, %4414
  %4418 = fsub fast float %4400, %4415
  %4419 = fsub fast float %4401, %4416
  %4420 = fmul fast float %4417, %4396
  %4421 = fmul fast float %4418, %4397
  %4422 = fmul fast float %4419, %4398
  %4423 = fadd fast float %4420, %4414
  %4424 = fadd fast float %4421, %4415
  %4425 = fadd fast float %4422, %4416
  br label %4641

; <label>:4426                                    ; preds = %4381
  %4427 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4384, i32 %4385, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4428 = extractvalue %dx.types.ResRet.f32 %4427, 0
  %4429 = fcmp fast ogt float %38, 5.000000e-01
  %4430 = fcmp fast olt float %4428, 1.000000e+00
  %4431 = and i1 %4429, %4430
  br i1 %4431, label %4432, label %4570

; <label>:4432                                    ; preds = %4426
  %4433 = sitofp i32 %4384 to float
  %4434 = sitofp i32 %4385 to float
  %4435 = fadd fast float %4433, 5.000000e-01
  %4436 = fadd fast float %4434, 5.000000e-01
  %4437 = fdiv fast float %4435, %45
  %4438 = fdiv fast float %4436, %46
  %4439 = fmul fast float %4437, 2.000000e+00
  %4440 = fmul fast float %4438, 2.000000e+00
  %4441 = fadd fast float %4439, -1.000000e+00
  %4442 = fsub fast float 1.000000e+00, %4440
  %4443 = fmul fast float %4441, %35
  %4444 = call float @dx.op.tertiary.f32(i32 46, float %4442, float %31, float %4443)  ; FMad(a,b,c)
  %4445 = call float @dx.op.tertiary.f32(i32 46, float %4428, float %27, float %4444)  ; FMad(a,b,c)
  %4446 = fadd fast float %4445, %23
  %4447 = call float @dx.op.unary.f32(i32 6, float %4446)  ; FAbs(value)
  %4448 = fcmp fast ogt float %4447, 0x3EB0C6F7A0000000
  br i1 %4448, label %4449, label %4570

; <label>:4449                                    ; preds = %4432
  %4450 = fmul fast float %4441, %34
  %4451 = call float @dx.op.tertiary.f32(i32 46, float %4442, float %30, float %4450)  ; FMad(a,b,c)
  %4452 = call float @dx.op.tertiary.f32(i32 46, float %4428, float %26, float %4451)  ; FMad(a,b,c)
  %4453 = fadd fast float %4452, %22
  %4454 = fmul fast float %4441, %33
  %4455 = call float @dx.op.tertiary.f32(i32 46, float %4442, float %29, float %4454)  ; FMad(a,b,c)
  %4456 = call float @dx.op.tertiary.f32(i32 46, float %4428, float %25, float %4455)  ; FMad(a,b,c)
  %4457 = fadd fast float %4456, %21
  %4458 = fmul fast float %4441, %32
  %4459 = call float @dx.op.tertiary.f32(i32 46, float %4442, float %28, float %4458)  ; FMad(a,b,c)
  %4460 = call float @dx.op.tertiary.f32(i32 46, float %4428, float %24, float %4459)  ; FMad(a,b,c)
  %4461 = fadd fast float %4460, %20
  %4462 = fdiv fast float %4461, %4446
  %4463 = fdiv fast float %4457, %4446
  %4464 = fdiv fast float %4453, %4446
  %4465 = fsub fast float %4462, %17
  %4466 = fsub fast float %4463, %18
  %4467 = fsub fast float %4464, %19
  %4468 = fmul fast float %4465, %4465
  %4469 = fmul fast float %4466, %4466
  %4470 = fadd fast float %4469, %4468
  %4471 = fmul fast float %4467, %4467
  %4472 = fadd fast float %4470, %4471
  %4473 = call float @dx.op.unary.f32(i32 24, float %4472)  ; Sqrt(value)
  %4474 = fsub fast float %4473, %9
  %4475 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4474)  ; FMax(a,b)
  %4476 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %4476, label %4477, label %4500

; <label>:4477                                    ; preds = %4449
  %4478 = call float @dx.op.unary.f32(i32 6, float %4466)  ; FAbs(value)
  %4479 = fmul fast float %4478, %11
  %4480 = fcmp fast olt float %4479, 0x3F50624DE0000000
  br i1 %4480, label %4481, label %4484

; <label>:4481                                    ; preds = %4477
  %4482 = fmul fast float %4479, 5.000000e-01
  %4483 = fsub fast float 1.000000e+00, %4482
  br label %4489

; <label>:4484                                    ; preds = %4477
  %4485 = fmul fast float %4479, 0xBFF7154760000000
  %4486 = call float @dx.op.unary.f32(i32 21, float %4485)  ; Exp(value)
  %4487 = fsub fast float 1.000000e+00, %4486
  %4488 = fdiv fast float %4487, %4479
  br label %4489

; <label>:4489                                    ; preds = %4484, %4481
  %4490 = phi float [ %4483, %4481 ], [ %4488, %4484 ]
  %4491 = call float @dx.op.binary.f32(i32 36, float %4463, float %18)  ; FMin(a,b)
  %4492 = fsub fast float %4491, %10
  %4493 = fmul fast float %11, %4492
  %4494 = fsub fast float -0.000000e+00, %4493
  %4495 = call float @dx.op.binary.f32(i32 35, float %4494, float -4.000000e+01)  ; FMax(a,b)
  %4496 = call float @dx.op.binary.f32(i32 36, float %4495, float 5.000000e+00)  ; FMin(a,b)
  %4497 = fmul fast float %4496, 0x3FF7154760000000
  %4498 = call float @dx.op.unary.f32(i32 21, float %4497)  ; Exp(value)
  %4499 = fmul fast float %4498, %4490
  br label %4500

; <label>:4500                                    ; preds = %4489, %4449
  %4501 = phi float [ %4499, %4489 ], [ 1.000000e+00, %4449 ]
  %4502 = fmul fast float %4475, %16
  %4503 = fmul fast float %4502, %4501
  %4504 = fcmp fast ole float %4473, %9
  %4505 = fcmp fast olt float %4473, 0x3F1A36E2E0000000
  %4506 = or i1 %4504, %4505
  br i1 %4506, label %4553, label %4507

; <label>:4507                                    ; preds = %4500
  %4508 = fdiv fast float %9, %4473
  %4509 = fmul fast float %4508, %4465
  %4510 = fmul fast float %4508, %4466
  %4511 = fmul fast float %4508, %4467
  %4512 = fadd fast float %4509, %17
  %4513 = fadd fast float %4510, %18
  %4514 = fadd fast float %4511, %19
  %4515 = fadd fast float %4512, -9.000000e+02
  %4516 = fadd fast float %4513, -1.500000e+01
  %4517 = fadd fast float %4514, -7.500000e+02
  %4518 = fmul fast float %4515, 0x3F62345680000000
  %4519 = fmul fast float %4516, 0x3F62345680000000
  %4520 = fmul fast float %4517, 0x3F62345680000000
  %4521 = call float @dx.op.dot3.f32(i32 55, float %4518, float %4519, float %4520, float %4518, float %4519, float %4520)  ; Dot3(ax,ay,az,bx,by,bz)
  %4522 = fsub fast float 1.000000e+00, %4521
  %4523 = call float @dx.op.unary.f32(i32 7, float %4522)  ; Saturate(value)
  %4524 = fmul fast float %4523, %4523
  %4525 = fadd fast float %4512, %4462
  %4526 = fadd fast float %4513, %4463
  %4527 = fadd fast float %4514, %4464
  %4528 = fmul fast float %4525, 0x3F52345680000000
  %4529 = fadd fast float %4528, -2.000000e+00
  %4530 = fmul fast float %4526, 0x3F52345680000000
  %4531 = fadd fast float %4530, 0xBFA1111120000000
  %4532 = fmul fast float %4527, 0x3F52345680000000
  %4533 = fadd fast float %4532, 0xBFFAAAAAC0000000
  %4534 = call float @dx.op.dot3.f32(i32 55, float %4529, float %4531, float %4533, float %4529, float %4531, float %4533)  ; Dot3(ax,ay,az,bx,by,bz)
  %4535 = fsub fast float 1.000000e+00, %4534
  %4536 = call float @dx.op.unary.f32(i32 7, float %4535)  ; Saturate(value)
  %4537 = fmul fast float %4536, %4536
  %4538 = fmul fast float %4537, 4.000000e+00
  %4539 = fadd fast float %4538, %4524
  %4540 = fadd fast float %4462, -9.000000e+02
  %4541 = fadd fast float %4463, -1.500000e+01
  %4542 = fadd fast float %4464, -7.500000e+02
  %4543 = fmul fast float %4540, 0x3F62345680000000
  %4544 = fmul fast float %4541, 0x3F62345680000000
  %4545 = fmul fast float %4542, 0x3F62345680000000
  %4546 = call float @dx.op.dot3.f32(i32 55, float %4543, float %4544, float %4545, float %4543, float %4544, float %4545)  ; Dot3(ax,ay,az,bx,by,bz)
  %4547 = fsub fast float 1.000000e+00, %4546
  %4548 = call float @dx.op.unary.f32(i32 7, float %4547)  ; Saturate(value)
  %4549 = fmul fast float %4548, %4548
  %4550 = fadd fast float %4539, %4549
  %4551 = fmul fast float %4474, 0x3F25D867E0000000
  %4552 = fmul fast float %4551, %4550
  br label %4553

; <label>:4553                                    ; preds = %4507, %4500
  %4554 = phi float [ %4552, %4507 ], [ 0.000000e+00, %4500 ]
  %4555 = fadd fast float %4554, %4503
  %4556 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4555)  ; FMin(a,b)
  %4557 = fmul fast float %4556, 0xBFF7154760000000
  %4558 = call float @dx.op.unary.f32(i32 21, float %4557)  ; Exp(value)
  %4559 = fsub fast float 1.000000e+00, %4558
  %4560 = call float @dx.op.binary.f32(i32 36, float %12, float %4559)  ; FMin(a,b)
  %4561 = fsub fast float %13, %4387
  %4562 = fsub fast float %14, %4388
  %4563 = fsub fast float %15, %4389
  %4564 = fmul fast float %4560, %4561
  %4565 = fmul fast float %4560, %4562
  %4566 = fmul fast float %4560, %4563
  %4567 = fadd fast float %4564, %4387
  %4568 = fadd fast float %4565, %4388
  %4569 = fadd fast float %4566, %4389
  br label %4570

; <label>:4570                                    ; preds = %4553, %4432, %4426
  %4571 = phi float [ %4567, %4553 ], [ %4387, %4432 ], [ %4387, %4426 ]
  %4572 = phi float [ %4568, %4553 ], [ %4388, %4432 ], [ %4388, %4426 ]
  %4573 = phi float [ %4569, %4553 ], [ %4389, %4432 ], [ %4389, %4426 ]
  %4574 = fadd fast float %5, 1.000000e+00
  %4575 = fadd fast float %6, 1.000000e+00
  %4576 = fsub fast float 1.000000e+00, %5
  %4577 = fmul fast float %36, %4574
  %4578 = fmul fast float %36, %4575
  %4579 = fmul fast float %36, %4576
  %4580 = fmul fast float %4577, %4571
  %4581 = fmul fast float %4578, %4572
  %4582 = fmul fast float %4579, %4573
  %4583 = fcmp fast ult float %37, 5.000000e-01
  br i1 %4583, label %4609, label %4584

; <label>:4584                                    ; preds = %4570
  %4585 = fmul fast float %4580, 0x4004147AE0000000
  %4586 = fmul fast float %4581, 0x4004147AE0000000
  %4587 = fmul fast float %4582, 0x4004147AE0000000
  %4588 = fadd fast float %4585, 0x3F9EB851E0000000
  %4589 = fadd fast float %4586, 0x3F9EB851E0000000
  %4590 = fadd fast float %4587, 0x3F9EB851E0000000
  %4591 = fmul fast float %4588, %4580
  %4592 = fmul fast float %4589, %4581
  %4593 = fmul fast float %4590, %4582
  %4594 = fmul fast float %4580, 0x400370A3E0000000
  %4595 = fmul fast float %4581, 0x400370A3E0000000
  %4596 = fmul fast float %4582, 0x400370A3E0000000
  %4597 = fadd fast float %4594, 0x3FE2E147A0000000
  %4598 = fadd fast float %4595, 0x3FE2E147A0000000
  %4599 = fadd fast float %4596, 0x3FE2E147A0000000
  %4600 = fmul fast float %4597, %4580
  %4601 = fmul fast float %4598, %4581
  %4602 = fmul fast float %4599, %4582
  %4603 = fadd fast float %4600, 0x3FC1EB8520000000
  %4604 = fadd fast float %4601, 0x3FC1EB8520000000
  %4605 = fadd fast float %4602, 0x3FC1EB8520000000
  %4606 = fdiv fast float %4591, %4603
  %4607 = fdiv fast float %4592, %4604
  %4608 = fdiv fast float %4593, %4605
  br label %4609

; <label>:4609                                    ; preds = %4584, %4570
  %4610 = phi float [ %4606, %4584 ], [ %4580, %4570 ]
  %4611 = phi float [ %4607, %4584 ], [ %4581, %4570 ]
  %4612 = phi float [ %4608, %4584 ], [ %4582, %4570 ]
  %4613 = call float @dx.op.unary.f32(i32 7, float %4610)  ; Saturate(value)
  %4614 = call float @dx.op.unary.f32(i32 7, float %4611)  ; Saturate(value)
  %4615 = call float @dx.op.unary.f32(i32 7, float %4612)  ; Saturate(value)
  %4616 = call float @dx.op.dot3.f32(i32 55, float %4613, float %4614, float %4615, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4617 = fsub fast float %4613, %4616
  %4618 = fsub fast float %4614, %4616
  %4619 = fsub fast float %4615, %4616
  %4620 = fmul fast float %4617, %8
  %4621 = fmul fast float %4618, %8
  %4622 = fmul fast float %4619, %8
  %4623 = fadd fast float %4620, %4616
  %4624 = fadd fast float %4621, %4616
  %4625 = fadd fast float %4622, %4616
  %4626 = call float @dx.op.unary.f32(i32 7, float %4623)  ; Saturate(value)
  %4627 = call float @dx.op.unary.f32(i32 7, float %4624)  ; Saturate(value)
  %4628 = call float @dx.op.unary.f32(i32 7, float %4625)  ; Saturate(value)
  %4629 = fadd fast float %4626, 0xBFC70A3D80000000
  %4630 = fadd fast float %4627, 0xBFC70A3D80000000
  %4631 = fadd fast float %4628, 0xBFC70A3D80000000
  %4632 = fmul fast float %4629, %7
  %4633 = fmul fast float %4630, %7
  %4634 = fmul fast float %4631, %7
  %4635 = fadd fast float %4632, 0x3FC70A3D80000000
  %4636 = fadd fast float %4633, 0x3FC70A3D80000000
  %4637 = fadd fast float %4634, 0x3FC70A3D80000000
  %4638 = call float @dx.op.unary.f32(i32 7, float %4635)  ; Saturate(value)
  %4639 = call float @dx.op.unary.f32(i32 7, float %4636)  ; Saturate(value)
  %4640 = call float @dx.op.unary.f32(i32 7, float %4637)  ; Saturate(value)
  br label %4641

; <label>:4641                                    ; preds = %4609, %4392
  %4642 = phi float [ %4423, %4392 ], [ %4638, %4609 ]
  %4643 = phi float [ %4424, %4392 ], [ %4639, %4609 ]
  %4644 = phi float [ %4425, %4392 ], [ %4640, %4609 ]
  %4645 = fsub fast float %4642, %3496
  %4646 = fsub fast float %4643, %3497
  %4647 = fsub fast float %4644, %3498
  %4648 = fmul fast float %4645, %4379
  %4649 = fmul fast float %4646, %4379
  %4650 = fmul fast float %4647, %4379
  %4651 = fadd fast float %4648, %3496
  %4652 = fadd fast float %4649, %3497
  %4653 = fadd fast float %4650, %3498
  br label %4654

; <label>:4654                                    ; preds = %4641, %4366
  %4655 = phi float [ %4651, %4641 ], [ %3496, %4366 ]
  %4656 = phi float [ %4652, %4641 ], [ %3497, %4366 ]
  %4657 = phi float [ %4653, %4641 ], [ %3498, %4366 ]
  %4658 = call float @dx.op.binary.f32(i32 36, float %4367, float %4655)  ; FMin(a,b)
  %4659 = call float @dx.op.binary.f32(i32 36, float %4368, float %4656)  ; FMin(a,b)
  %4660 = call float @dx.op.binary.f32(i32 36, float %4369, float %4657)  ; FMin(a,b)
  %4661 = call float @dx.op.binary.f32(i32 36, float %3789, float %4077)  ; FMin(a,b)
  %4662 = call float @dx.op.binary.f32(i32 36, float %3790, float %4078)  ; FMin(a,b)
  %4663 = call float @dx.op.binary.f32(i32 36, float %3791, float %4079)  ; FMin(a,b)
  %4664 = call float @dx.op.binary.f32(i32 36, float %4661, float %4658)  ; FMin(a,b)
  %4665 = call float @dx.op.binary.f32(i32 36, float %4662, float %4659)  ; FMin(a,b)
  %4666 = call float @dx.op.binary.f32(i32 36, float %4663, float %4660)  ; FMin(a,b)
  %4667 = call float @dx.op.binary.f32(i32 36, float %3496, float %4664)  ; FMin(a,b)
  %4668 = call float @dx.op.binary.f32(i32 36, float %3497, float %4665)  ; FMin(a,b)
  %4669 = call float @dx.op.binary.f32(i32 36, float %3498, float %4666)  ; FMin(a,b)
  %4670 = call float @dx.op.binary.f32(i32 35, float %4367, float %4655)  ; FMax(a,b)
  %4671 = call float @dx.op.binary.f32(i32 35, float %4368, float %4656)  ; FMax(a,b)
  %4672 = call float @dx.op.binary.f32(i32 35, float %4369, float %4657)  ; FMax(a,b)
  %4673 = call float @dx.op.binary.f32(i32 35, float %3789, float %4077)  ; FMax(a,b)
  %4674 = call float @dx.op.binary.f32(i32 35, float %3790, float %4078)  ; FMax(a,b)
  %4675 = call float @dx.op.binary.f32(i32 35, float %3791, float %4079)  ; FMax(a,b)
  %4676 = call float @dx.op.binary.f32(i32 35, float %4673, float %4670)  ; FMax(a,b)
  %4677 = call float @dx.op.binary.f32(i32 35, float %4674, float %4671)  ; FMax(a,b)
  %4678 = call float @dx.op.binary.f32(i32 35, float %4675, float %4672)  ; FMax(a,b)
  %4679 = call float @dx.op.binary.f32(i32 35, float %3496, float %4676)  ; FMax(a,b)
  %4680 = call float @dx.op.binary.f32(i32 35, float %3497, float %4677)  ; FMax(a,b)
  %4681 = call float @dx.op.binary.f32(i32 35, float %3498, float %4678)  ; FMax(a,b)
  %4682 = fsub fast float %4679, %4667
  %4683 = fsub fast float %4680, %4668
  %4684 = fsub fast float %4681, %4669
  %4685 = call float @dx.op.unary.f32(i32 6, float %4682)  ; FAbs(value)
  %4686 = call float @dx.op.unary.f32(i32 6, float %4683)  ; FAbs(value)
  %4687 = call float @dx.op.unary.f32(i32 6, float %4684)  ; FAbs(value)
  %4688 = call float @dx.op.binary.f32(i32 35, float %4686, float %4687)  ; FMax(a,b)
  %4689 = call float @dx.op.binary.f32(i32 35, float %4685, float %4688)  ; FMax(a,b)
  %4690 = call float @dx.op.binary.f32(i32 35, float %4680, float %4681)  ; FMax(a,b)
  %4691 = call float @dx.op.binary.f32(i32 35, float %4679, float %4690)  ; FMax(a,b)
  %4692 = fmul fast float %4691, 1.250000e-01
  %4693 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %4692)  ; FMax(a,b)
  %4694 = fcmp fast ogt float %4689, %4693
  br i1 %4694, label %4695, label %4756

; <label>:4695                                    ; preds = %4654
  %4696 = fsub fast float %3789, %4077
  %4697 = fsub fast float %3790, %4078
  %4698 = fsub fast float %3791, %4079
  %4699 = call float @dx.op.unary.f32(i32 6, float %4696)  ; FAbs(value)
  %4700 = call float @dx.op.unary.f32(i32 6, float %4697)  ; FAbs(value)
  %4701 = call float @dx.op.unary.f32(i32 6, float %4698)  ; FAbs(value)
  %4702 = call float @dx.op.binary.f32(i32 35, float %4700, float %4701)  ; FMax(a,b)
  %4703 = call float @dx.op.binary.f32(i32 35, float %4699, float %4702)  ; FMax(a,b)
  %4704 = fsub fast float %4367, %4655
  %4705 = fsub fast float %4368, %4656
  %4706 = fsub fast float %4369, %4657
  %4707 = call float @dx.op.unary.f32(i32 6, float %4704)  ; FAbs(value)
  %4708 = call float @dx.op.unary.f32(i32 6, float %4705)  ; FAbs(value)
  %4709 = call float @dx.op.unary.f32(i32 6, float %4706)  ; FAbs(value)
  %4710 = call float @dx.op.binary.f32(i32 35, float %4708, float %4709)  ; FMax(a,b)
  %4711 = call float @dx.op.binary.f32(i32 35, float %4707, float %4710)  ; FMax(a,b)
  %4712 = fcmp fast olt float %4703, %4711
  %4713 = select i1 %4712, float %3789, float %4367
  %4714 = select i1 %4712, float %3790, float %4368
  %4715 = select i1 %4712, float %3791, float %4369
  %4716 = select i1 %4712, float %4077, float %4655
  %4717 = select i1 %4712, float %4078, float %4656
  %4718 = select i1 %4712, float %4079, float %4657
  %4719 = fsub fast float %3496, %4716
  %4720 = fsub fast float %3497, %4717
  %4721 = fsub fast float %3498, %4718
  %4722 = fsub fast float %3496, %4713
  %4723 = fsub fast float %3497, %4714
  %4724 = fsub fast float %3498, %4715
  %4725 = call float @dx.op.dot3.f32(i32 55, float %4722, float %4723, float %4724, float %4719, float %4720, float %4721)  ; Dot3(ax,ay,az,bx,by,bz)
  %4726 = fcmp fast ogt float %4725, 0.000000e+00
  br i1 %4726, label %4727, label %4738

; <label>:4727                                    ; preds = %4695
  %4728 = fsub fast float %4713, %4716
  %4729 = fsub fast float %4714, %4717
  %4730 = fsub fast float %4715, %4718
  %4731 = call float @dx.op.unary.f32(i32 6, float %4728)  ; FAbs(value)
  %4732 = call float @dx.op.unary.f32(i32 6, float %4729)  ; FAbs(value)
  %4733 = call float @dx.op.unary.f32(i32 6, float %4730)  ; FAbs(value)
  %4734 = call float @dx.op.binary.f32(i32 35, float %4732, float %4733)  ; FMax(a,b)
  %4735 = call float @dx.op.binary.f32(i32 35, float %4731, float %4734)  ; FMax(a,b)
  %4736 = fmul fast float %4689, 2.500000e-01
  %4737 = fcmp fast olt float %4735, %4736
  br label %4738

; <label>:4738                                    ; preds = %4727, %4695
  %4739 = phi i1 [ false, %4695 ], [ %4737, %4727 ]
  %4740 = select i1 %4739, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  %4741 = fadd fast float %4713, %4716
  %4742 = fadd fast float %4714, %4717
  %4743 = fadd fast float %4715, %4718
  %4744 = fmul fast float %4741, 5.000000e-01
  %4745 = fmul fast float %4742, 5.000000e-01
  %4746 = fmul fast float %4743, 5.000000e-01
  %4747 = fsub fast float %4744, %3496
  %4748 = fsub fast float %4745, %3497
  %4749 = fsub fast float %4746, %3498
  %4750 = fmul fast float %4740, %4747
  %4751 = fmul fast float %4740, %4748
  %4752 = fmul fast float %4740, %4749
  %4753 = fadd fast float %4750, %3496
  %4754 = fadd fast float %4751, %3497
  %4755 = fadd fast float %4752, %3498
  br label %4756

; <label>:4756                                    ; preds = %4738, %4654
  %4757 = phi float [ %4753, %4738 ], [ %3496, %4654 ]
  %4758 = phi float [ %4754, %4738 ], [ %3497, %4654 ]
  %4759 = phi float [ %4755, %4738 ], [ %3498, %4654 ]
  %4760 = fcmp fast ogt float %4757, 0x3F69A5C380000000
  %4761 = fcmp fast ogt float %4758, 0x3F69A5C380000000
  %4762 = fcmp fast ogt float %4759, 0x3F69A5C380000000
  %4763 = select i1 %4760, float 0.000000e+00, float 1.000000e+00
  %4764 = select i1 %4761, float 0.000000e+00, float 1.000000e+00
  %4765 = select i1 %4762, float 0.000000e+00, float 1.000000e+00
  %4766 = fmul fast float %4757, 0x4029D70A40000000
  %4767 = fmul fast float %4758, 0x4029D70A40000000
  %4768 = fmul fast float %4759, 0x4029D70A40000000
  %4769 = call float @dx.op.binary.f32(i32 35, float %4757, float 0.000000e+00)  ; FMax(a,b)
  %4770 = call float @dx.op.binary.f32(i32 35, float %4758, float 0.000000e+00)  ; FMax(a,b)
  %4771 = call float @dx.op.binary.f32(i32 35, float %4759, float 0.000000e+00)  ; FMax(a,b)
  %4772 = call float @dx.op.unary.f32(i32 23, float %4769)  ; Log(value)
  %4773 = call float @dx.op.unary.f32(i32 23, float %4770)  ; Log(value)
  %4774 = call float @dx.op.unary.f32(i32 23, float %4771)  ; Log(value)
  %4775 = fmul fast float %4772, 0x3FDAAAAAA0000000
  %4776 = fmul fast float %4773, 0x3FDAAAAAA0000000
  %4777 = fmul fast float %4774, 0x3FDAAAAAA0000000
  %4778 = call float @dx.op.unary.f32(i32 21, float %4775)  ; Exp(value)
  %4779 = call float @dx.op.unary.f32(i32 21, float %4776)  ; Exp(value)
  %4780 = call float @dx.op.unary.f32(i32 21, float %4777)  ; Exp(value)
  %4781 = fmul fast float %4778, 0x3FF0E147A0000000
  %4782 = fmul fast float %4779, 0x3FF0E147A0000000
  %4783 = fmul fast float %4780, 0x3FF0E147A0000000
  %4784 = fadd fast float %4781, 0xBFAC28F5C0000000
  %4785 = fadd fast float %4782, 0xBFAC28F5C0000000
  %4786 = fadd fast float %4783, 0xBFAC28F5C0000000
  %4787 = fsub fast float %4766, %4784
  %4788 = fsub fast float %4767, %4785
  %4789 = fsub fast float %4768, %4786
  %4790 = fmul fast float %4787, %4763
  %4791 = fmul fast float %4788, %4764
  %4792 = fmul fast float %4789, %4765
  %4793 = fadd fast float %4790, %4784
  %4794 = fadd fast float %4791, %4785
  %4795 = fadd fast float %4792, %4786
  br label %4796

; <label>:4796                                    ; preds = %4756, %3284
  %4797 = phi float [ %3279, %3284 ], [ %4793, %4756 ]
  %4798 = phi float [ %3280, %3284 ], [ %4794, %4756 ]
  %4799 = phi float [ %3281, %3284 ], [ %4795, %4756 ]
  %4800 = phi float [ %3285, %3284 ], [ %3282, %4756 ]
  %4801 = fcmp fast ogt float %4797, 0x3FA4B5DCC0000000
  %4802 = fcmp fast ogt float %4798, 0x3FA4B5DCC0000000
  %4803 = fcmp fast ogt float %4799, 0x3FA4B5DCC0000000
  %4804 = select i1 %4801, float 0.000000e+00, float 1.000000e+00
  %4805 = select i1 %4802, float 0.000000e+00, float 1.000000e+00
  %4806 = select i1 %4803, float 0.000000e+00, float 1.000000e+00
  %4807 = fmul fast float %4797, 0x3FB3D07220000000
  %4808 = fmul fast float %4798, 0x3FB3D07220000000
  %4809 = fmul fast float %4799, 0x3FB3D07220000000
  %4810 = fadd fast float %4797, 0x3FAC28F5C0000000
  %4811 = fadd fast float %4798, 0x3FAC28F5C0000000
  %4812 = fadd fast float %4799, 0x3FAC28F5C0000000
  %4813 = fmul fast float %4810, 0x3FEE54EDE0000000
  %4814 = fmul fast float %4811, 0x3FEE54EDE0000000
  %4815 = fmul fast float %4812, 0x3FEE54EDE0000000
  %4816 = call float @dx.op.unary.f32(i32 23, float %4813)  ; Log(value)
  %4817 = call float @dx.op.unary.f32(i32 23, float %4814)  ; Log(value)
  %4818 = call float @dx.op.unary.f32(i32 23, float %4815)  ; Log(value)
  %4819 = fmul fast float %4816, 0x4003333340000000
  %4820 = fmul fast float %4817, 0x4003333340000000
  %4821 = fmul fast float %4818, 0x4003333340000000
  %4822 = call float @dx.op.unary.f32(i32 21, float %4819)  ; Exp(value)
  %4823 = call float @dx.op.unary.f32(i32 21, float %4820)  ; Exp(value)
  %4824 = call float @dx.op.unary.f32(i32 21, float %4821)  ; Exp(value)
  %4825 = fsub fast float %4807, %4822
  %4826 = fsub fast float %4808, %4823
  %4827 = fsub fast float %4809, %4824
  %4828 = fmul fast float %4825, %4804
  %4829 = fmul fast float %4826, %4805
  %4830 = fmul fast float %4827, %4806
  %4831 = fadd fast float %4828, %4822
  %4832 = fadd fast float %4829, %4823
  %4833 = fadd fast float %4830, %4824
  %4834 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %67, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4835 = extractvalue %dx.types.ResRet.f32 %4834, 0
  %4836 = extractvalue %dx.types.ResRet.f32 %4834, 1
  %4837 = extractvalue %dx.types.ResRet.f32 %4834, 2
  %4838 = extractvalue %dx.types.ResRet.f32 %4834, 3
  %4839 = fcmp fast olt float %4838, 0.000000e+00
  br i1 %4839, label %4840, label %4842

; <label>:4840                                    ; preds = %4796
  %4841 = fsub fast float -1.000000e+00, %4838
  br label %6352

; <label>:4842                                    ; preds = %4796
  %4843 = fcmp fast ogt float %38, 5.000000e-01
  %4844 = fcmp fast olt float %88, 1.000000e+00
  %4845 = and i1 %4843, %4844
  br i1 %4845, label %4846, label %4984

; <label>:4846                                    ; preds = %4842
  %4847 = sitofp i32 %67 to float
  %4848 = sitofp i32 %70 to float
  %4849 = fadd fast float %4847, 5.000000e-01
  %4850 = fadd fast float %4848, 5.000000e-01
  %4851 = fdiv fast float %4849, %45
  %4852 = fdiv fast float %4850, %46
  %4853 = fmul fast float %4851, 2.000000e+00
  %4854 = fmul fast float %4852, 2.000000e+00
  %4855 = fadd fast float %4853, -1.000000e+00
  %4856 = fsub fast float 1.000000e+00, %4854
  %4857 = fmul fast float %4855, %35
  %4858 = call float @dx.op.tertiary.f32(i32 46, float %4856, float %31, float %4857)  ; FMad(a,b,c)
  %4859 = call float @dx.op.tertiary.f32(i32 46, float %88, float %27, float %4858)  ; FMad(a,b,c)
  %4860 = fadd fast float %4859, %23
  %4861 = call float @dx.op.unary.f32(i32 6, float %4860)  ; FAbs(value)
  %4862 = fcmp fast ogt float %4861, 0x3EB0C6F7A0000000
  br i1 %4862, label %4863, label %4984

; <label>:4863                                    ; preds = %4846
  %4864 = fmul fast float %4855, %34
  %4865 = call float @dx.op.tertiary.f32(i32 46, float %4856, float %30, float %4864)  ; FMad(a,b,c)
  %4866 = call float @dx.op.tertiary.f32(i32 46, float %88, float %26, float %4865)  ; FMad(a,b,c)
  %4867 = fadd fast float %4866, %22
  %4868 = fmul fast float %4855, %33
  %4869 = call float @dx.op.tertiary.f32(i32 46, float %4856, float %29, float %4868)  ; FMad(a,b,c)
  %4870 = call float @dx.op.tertiary.f32(i32 46, float %88, float %25, float %4869)  ; FMad(a,b,c)
  %4871 = fadd fast float %4870, %21
  %4872 = fmul fast float %4855, %32
  %4873 = call float @dx.op.tertiary.f32(i32 46, float %4856, float %28, float %4872)  ; FMad(a,b,c)
  %4874 = call float @dx.op.tertiary.f32(i32 46, float %88, float %24, float %4873)  ; FMad(a,b,c)
  %4875 = fadd fast float %4874, %20
  %4876 = fdiv fast float %4875, %4860
  %4877 = fdiv fast float %4871, %4860
  %4878 = fdiv fast float %4867, %4860
  %4879 = fsub fast float %4876, %17
  %4880 = fsub fast float %4877, %18
  %4881 = fsub fast float %4878, %19
  %4882 = fmul fast float %4879, %4879
  %4883 = fmul fast float %4880, %4880
  %4884 = fadd fast float %4883, %4882
  %4885 = fmul fast float %4881, %4881
  %4886 = fadd fast float %4884, %4885
  %4887 = call float @dx.op.unary.f32(i32 24, float %4886)  ; Sqrt(value)
  %4888 = fsub fast float %4887, %9
  %4889 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4888)  ; FMax(a,b)
  %4890 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %4890, label %4891, label %4914

; <label>:4891                                    ; preds = %4863
  %4892 = call float @dx.op.unary.f32(i32 6, float %4880)  ; FAbs(value)
  %4893 = fmul fast float %4892, %11
  %4894 = fcmp fast olt float %4893, 0x3F50624DE0000000
  br i1 %4894, label %4895, label %4898

; <label>:4895                                    ; preds = %4891
  %4896 = fmul fast float %4893, 5.000000e-01
  %4897 = fsub fast float 1.000000e+00, %4896
  br label %4903

; <label>:4898                                    ; preds = %4891
  %4899 = fmul fast float %4893, 0xBFF7154760000000
  %4900 = call float @dx.op.unary.f32(i32 21, float %4899)  ; Exp(value)
  %4901 = fsub fast float 1.000000e+00, %4900
  %4902 = fdiv fast float %4901, %4893
  br label %4903

; <label>:4903                                    ; preds = %4898, %4895
  %4904 = phi float [ %4897, %4895 ], [ %4902, %4898 ]
  %4905 = call float @dx.op.binary.f32(i32 36, float %4877, float %18)  ; FMin(a,b)
  %4906 = fsub fast float %4905, %10
  %4907 = fmul fast float %11, %4906
  %4908 = fsub fast float -0.000000e+00, %4907
  %4909 = call float @dx.op.binary.f32(i32 35, float %4908, float -4.000000e+01)  ; FMax(a,b)
  %4910 = call float @dx.op.binary.f32(i32 36, float %4909, float 5.000000e+00)  ; FMin(a,b)
  %4911 = fmul fast float %4910, 0x3FF7154760000000
  %4912 = call float @dx.op.unary.f32(i32 21, float %4911)  ; Exp(value)
  %4913 = fmul fast float %4912, %4904
  br label %4914

; <label>:4914                                    ; preds = %4903, %4863
  %4915 = phi float [ %4913, %4903 ], [ 1.000000e+00, %4863 ]
  %4916 = fmul fast float %4889, %16
  %4917 = fmul fast float %4916, %4915
  %4918 = fcmp fast ole float %4887, %9
  %4919 = fcmp fast olt float %4887, 0x3F1A36E2E0000000
  %4920 = or i1 %4918, %4919
  br i1 %4920, label %4967, label %4921

; <label>:4921                                    ; preds = %4914
  %4922 = fdiv fast float %9, %4887
  %4923 = fmul fast float %4922, %4879
  %4924 = fmul fast float %4922, %4880
  %4925 = fmul fast float %4922, %4881
  %4926 = fadd fast float %4923, %17
  %4927 = fadd fast float %4924, %18
  %4928 = fadd fast float %4925, %19
  %4929 = fadd fast float %4926, -9.000000e+02
  %4930 = fadd fast float %4927, -1.500000e+01
  %4931 = fadd fast float %4928, -7.500000e+02
  %4932 = fmul fast float %4929, 0x3F62345680000000
  %4933 = fmul fast float %4930, 0x3F62345680000000
  %4934 = fmul fast float %4931, 0x3F62345680000000
  %4935 = call float @dx.op.dot3.f32(i32 55, float %4932, float %4933, float %4934, float %4932, float %4933, float %4934)  ; Dot3(ax,ay,az,bx,by,bz)
  %4936 = fsub fast float 1.000000e+00, %4935
  %4937 = call float @dx.op.unary.f32(i32 7, float %4936)  ; Saturate(value)
  %4938 = fmul fast float %4937, %4937
  %4939 = fadd fast float %4926, %4876
  %4940 = fadd fast float %4927, %4877
  %4941 = fadd fast float %4928, %4878
  %4942 = fmul fast float %4939, 0x3F52345680000000
  %4943 = fadd fast float %4942, -2.000000e+00
  %4944 = fmul fast float %4940, 0x3F52345680000000
  %4945 = fadd fast float %4944, 0xBFA1111120000000
  %4946 = fmul fast float %4941, 0x3F52345680000000
  %4947 = fadd fast float %4946, 0xBFFAAAAAC0000000
  %4948 = call float @dx.op.dot3.f32(i32 55, float %4943, float %4945, float %4947, float %4943, float %4945, float %4947)  ; Dot3(ax,ay,az,bx,by,bz)
  %4949 = fsub fast float 1.000000e+00, %4948
  %4950 = call float @dx.op.unary.f32(i32 7, float %4949)  ; Saturate(value)
  %4951 = fmul fast float %4950, %4950
  %4952 = fmul fast float %4951, 4.000000e+00
  %4953 = fadd fast float %4952, %4938
  %4954 = fadd fast float %4876, -9.000000e+02
  %4955 = fadd fast float %4877, -1.500000e+01
  %4956 = fadd fast float %4878, -7.500000e+02
  %4957 = fmul fast float %4954, 0x3F62345680000000
  %4958 = fmul fast float %4955, 0x3F62345680000000
  %4959 = fmul fast float %4956, 0x3F62345680000000
  %4960 = call float @dx.op.dot3.f32(i32 55, float %4957, float %4958, float %4959, float %4957, float %4958, float %4959)  ; Dot3(ax,ay,az,bx,by,bz)
  %4961 = fsub fast float 1.000000e+00, %4960
  %4962 = call float @dx.op.unary.f32(i32 7, float %4961)  ; Saturate(value)
  %4963 = fmul fast float %4962, %4962
  %4964 = fadd fast float %4953, %4963
  %4965 = fmul fast float %4888, 0x3F25D867E0000000
  %4966 = fmul fast float %4965, %4964
  br label %4967

; <label>:4967                                    ; preds = %4921, %4914
  %4968 = phi float [ %4966, %4921 ], [ 0.000000e+00, %4914 ]
  %4969 = fadd fast float %4968, %4917
  %4970 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4969)  ; FMin(a,b)
  %4971 = fmul fast float %4970, 0xBFF7154760000000
  %4972 = call float @dx.op.unary.f32(i32 21, float %4971)  ; Exp(value)
  %4973 = fsub fast float 1.000000e+00, %4972
  %4974 = call float @dx.op.binary.f32(i32 36, float %12, float %4973)  ; FMin(a,b)
  %4975 = fsub fast float %13, %4835
  %4976 = fsub fast float %14, %4836
  %4977 = fsub fast float %15, %4837
  %4978 = fmul fast float %4974, %4975
  %4979 = fmul fast float %4974, %4976
  %4980 = fmul fast float %4974, %4977
  %4981 = fadd fast float %4978, %4835
  %4982 = fadd fast float %4979, %4836
  %4983 = fadd fast float %4980, %4837
  br label %4984

; <label>:4984                                    ; preds = %4967, %4846, %4842
  %4985 = phi float [ %4981, %4967 ], [ %4835, %4846 ], [ %4835, %4842 ]
  %4986 = phi float [ %4982, %4967 ], [ %4836, %4846 ], [ %4836, %4842 ]
  %4987 = phi float [ %4983, %4967 ], [ %4837, %4846 ], [ %4837, %4842 ]
  %4988 = fadd fast float %5, 1.000000e+00
  %4989 = fadd fast float %6, 1.000000e+00
  %4990 = fsub fast float 1.000000e+00, %5
  %4991 = fmul fast float %36, %4988
  %4992 = fmul fast float %36, %4989
  %4993 = fmul fast float %36, %4990
  %4994 = fmul fast float %4991, %4985
  %4995 = fmul fast float %4992, %4986
  %4996 = fmul fast float %4993, %4987
  %4997 = fcmp fast ult float %37, 5.000000e-01
  br i1 %4997, label %5023, label %4998

; <label>:4998                                    ; preds = %4984
  %4999 = fmul fast float %4994, 0x4004147AE0000000
  %5000 = fmul fast float %4995, 0x4004147AE0000000
  %5001 = fmul fast float %4996, 0x4004147AE0000000
  %5002 = fadd fast float %4999, 0x3F9EB851E0000000
  %5003 = fadd fast float %5000, 0x3F9EB851E0000000
  %5004 = fadd fast float %5001, 0x3F9EB851E0000000
  %5005 = fmul fast float %5002, %4994
  %5006 = fmul fast float %5003, %4995
  %5007 = fmul fast float %5004, %4996
  %5008 = fmul fast float %4994, 0x400370A3E0000000
  %5009 = fmul fast float %4995, 0x400370A3E0000000
  %5010 = fmul fast float %4996, 0x400370A3E0000000
  %5011 = fadd fast float %5008, 0x3FE2E147A0000000
  %5012 = fadd fast float %5009, 0x3FE2E147A0000000
  %5013 = fadd fast float %5010, 0x3FE2E147A0000000
  %5014 = fmul fast float %5011, %4994
  %5015 = fmul fast float %5012, %4995
  %5016 = fmul fast float %5013, %4996
  %5017 = fadd fast float %5014, 0x3FC1EB8520000000
  %5018 = fadd fast float %5015, 0x3FC1EB8520000000
  %5019 = fadd fast float %5016, 0x3FC1EB8520000000
  %5020 = fdiv fast float %5005, %5017
  %5021 = fdiv fast float %5006, %5018
  %5022 = fdiv fast float %5007, %5019
  br label %5023

; <label>:5023                                    ; preds = %4998, %4984
  %5024 = phi float [ %5020, %4998 ], [ %4994, %4984 ]
  %5025 = phi float [ %5021, %4998 ], [ %4995, %4984 ]
  %5026 = phi float [ %5022, %4998 ], [ %4996, %4984 ]
  %5027 = call float @dx.op.unary.f32(i32 7, float %5024)  ; Saturate(value)
  %5028 = call float @dx.op.unary.f32(i32 7, float %5025)  ; Saturate(value)
  %5029 = call float @dx.op.unary.f32(i32 7, float %5026)  ; Saturate(value)
  %5030 = call float @dx.op.dot3.f32(i32 55, float %5027, float %5028, float %5029, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5031 = fsub fast float %5027, %5030
  %5032 = fsub fast float %5028, %5030
  %5033 = fsub fast float %5029, %5030
  %5034 = fmul fast float %5031, %8
  %5035 = fmul fast float %5032, %8
  %5036 = fmul fast float %5033, %8
  %5037 = fadd fast float %5034, %5030
  %5038 = fadd fast float %5035, %5030
  %5039 = fadd fast float %5036, %5030
  %5040 = call float @dx.op.unary.f32(i32 7, float %5037)  ; Saturate(value)
  %5041 = call float @dx.op.unary.f32(i32 7, float %5038)  ; Saturate(value)
  %5042 = call float @dx.op.unary.f32(i32 7, float %5039)  ; Saturate(value)
  %5043 = fadd fast float %5040, 0xBFC70A3D80000000
  %5044 = fadd fast float %5041, 0xBFC70A3D80000000
  %5045 = fadd fast float %5042, 0xBFC70A3D80000000
  %5046 = fmul fast float %5043, %7
  %5047 = fmul fast float %5044, %7
  %5048 = fmul fast float %5045, %7
  %5049 = fadd fast float %5046, 0x3FC70A3D80000000
  %5050 = fadd fast float %5047, 0x3FC70A3D80000000
  %5051 = fadd fast float %5048, 0x3FC70A3D80000000
  %5052 = call float @dx.op.unary.f32(i32 7, float %5049)  ; Saturate(value)
  %5053 = call float @dx.op.unary.f32(i32 7, float %5050)  ; Saturate(value)
  %5054 = call float @dx.op.unary.f32(i32 7, float %5051)  ; Saturate(value)
  %5055 = add i32 %70, -1
  %5056 = call i32 @dx.op.binary.i32(i32 37, i32 %67, i32 0)  ; IMax(a,b)
  %5057 = call i32 @dx.op.binary.i32(i32 37, i32 %5055, i32 0)  ; IMax(a,b)
  %5058 = call i32 @dx.op.binary.i32(i32 38, i32 %5056, i32 %59)  ; IMin(a,b)
  %5059 = call i32 @dx.op.binary.i32(i32 38, i32 %5057, i32 %60)  ; IMin(a,b)
  %5060 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5058, i32 %5059, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5061 = extractvalue %dx.types.ResRet.f32 %5060, 0
  %5062 = fsub fast float 1.000000e+00, %88
  %5063 = fmul fast float %5062, 0x3FA99999A0000000
  %5064 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %5063)  ; FMax(a,b)
  %5065 = fsub fast float %5061, %88
  %5066 = call float @dx.op.unary.f32(i32 6, float %5065)  ; FAbs(value)
  %5067 = fdiv fast float %5066, %5064
  %5068 = fsub fast float 1.000000e+00, %5067
  %5069 = call float @dx.op.unary.f32(i32 7, float %5068)  ; Saturate(value)
  %5070 = fcmp fast ugt float %5069, 0.000000e+00
  br i1 %5070, label %5071, label %5344

; <label>:5071                                    ; preds = %5023
  %5072 = call i32 @dx.op.binary.i32(i32 37, i32 %5058, i32 0)  ; IMax(a,b)
  %5073 = call i32 @dx.op.binary.i32(i32 37, i32 %5059, i32 0)  ; IMax(a,b)
  %5074 = call i32 @dx.op.binary.i32(i32 38, i32 %5072, i32 %59)  ; IMin(a,b)
  %5075 = call i32 @dx.op.binary.i32(i32 38, i32 %5073, i32 %60)  ; IMin(a,b)
  %5076 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %5074, i32 %5075, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5077 = extractvalue %dx.types.ResRet.f32 %5076, 0
  %5078 = extractvalue %dx.types.ResRet.f32 %5076, 1
  %5079 = extractvalue %dx.types.ResRet.f32 %5076, 2
  %5080 = extractvalue %dx.types.ResRet.f32 %5076, 3
  %5081 = fcmp fast olt float %5080, 0.000000e+00
  br i1 %5081, label %5082, label %5116

; <label>:5082                                    ; preds = %5071
  %5083 = fcmp fast ogt float %5077, 0x3FA4B5DCC0000000
  %5084 = fcmp fast ogt float %5078, 0x3FA4B5DCC0000000
  %5085 = fcmp fast ogt float %5079, 0x3FA4B5DCC0000000
  %5086 = select i1 %5083, float 0.000000e+00, float 1.000000e+00
  %5087 = select i1 %5084, float 0.000000e+00, float 1.000000e+00
  %5088 = select i1 %5085, float 0.000000e+00, float 1.000000e+00
  %5089 = fmul fast float %5077, 0x3FB3D07220000000
  %5090 = fmul fast float %5078, 0x3FB3D07220000000
  %5091 = fmul fast float %5079, 0x3FB3D07220000000
  %5092 = fadd fast float %5077, 0x3FAC28F5C0000000
  %5093 = fadd fast float %5078, 0x3FAC28F5C0000000
  %5094 = fadd fast float %5079, 0x3FAC28F5C0000000
  %5095 = fmul fast float %5092, 0x3FEE54EDE0000000
  %5096 = fmul fast float %5093, 0x3FEE54EDE0000000
  %5097 = fmul fast float %5094, 0x3FEE54EDE0000000
  %5098 = call float @dx.op.unary.f32(i32 23, float %5095)  ; Log(value)
  %5099 = call float @dx.op.unary.f32(i32 23, float %5096)  ; Log(value)
  %5100 = call float @dx.op.unary.f32(i32 23, float %5097)  ; Log(value)
  %5101 = fmul fast float %5098, 0x4003333340000000
  %5102 = fmul fast float %5099, 0x4003333340000000
  %5103 = fmul fast float %5100, 0x4003333340000000
  %5104 = call float @dx.op.unary.f32(i32 21, float %5101)  ; Exp(value)
  %5105 = call float @dx.op.unary.f32(i32 21, float %5102)  ; Exp(value)
  %5106 = call float @dx.op.unary.f32(i32 21, float %5103)  ; Exp(value)
  %5107 = fsub fast float %5089, %5104
  %5108 = fsub fast float %5090, %5105
  %5109 = fsub fast float %5091, %5106
  %5110 = fmul fast float %5107, %5086
  %5111 = fmul fast float %5108, %5087
  %5112 = fmul fast float %5109, %5088
  %5113 = fadd fast float %5110, %5104
  %5114 = fadd fast float %5111, %5105
  %5115 = fadd fast float %5112, %5106
  br label %5331

; <label>:5116                                    ; preds = %5071
  %5117 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5074, i32 %5075, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5118 = extractvalue %dx.types.ResRet.f32 %5117, 0
  %5119 = fcmp fast ogt float %38, 5.000000e-01
  %5120 = fcmp fast olt float %5118, 1.000000e+00
  %5121 = and i1 %5119, %5120
  br i1 %5121, label %5122, label %5260

; <label>:5122                                    ; preds = %5116
  %5123 = sitofp i32 %5074 to float
  %5124 = sitofp i32 %5075 to float
  %5125 = fadd fast float %5123, 5.000000e-01
  %5126 = fadd fast float %5124, 5.000000e-01
  %5127 = fdiv fast float %5125, %45
  %5128 = fdiv fast float %5126, %46
  %5129 = fmul fast float %5127, 2.000000e+00
  %5130 = fmul fast float %5128, 2.000000e+00
  %5131 = fadd fast float %5129, -1.000000e+00
  %5132 = fsub fast float 1.000000e+00, %5130
  %5133 = fmul fast float %5131, %35
  %5134 = call float @dx.op.tertiary.f32(i32 46, float %5132, float %31, float %5133)  ; FMad(a,b,c)
  %5135 = call float @dx.op.tertiary.f32(i32 46, float %5118, float %27, float %5134)  ; FMad(a,b,c)
  %5136 = fadd fast float %5135, %23
  %5137 = call float @dx.op.unary.f32(i32 6, float %5136)  ; FAbs(value)
  %5138 = fcmp fast ogt float %5137, 0x3EB0C6F7A0000000
  br i1 %5138, label %5139, label %5260

; <label>:5139                                    ; preds = %5122
  %5140 = fmul fast float %5131, %34
  %5141 = call float @dx.op.tertiary.f32(i32 46, float %5132, float %30, float %5140)  ; FMad(a,b,c)
  %5142 = call float @dx.op.tertiary.f32(i32 46, float %5118, float %26, float %5141)  ; FMad(a,b,c)
  %5143 = fadd fast float %5142, %22
  %5144 = fmul fast float %5131, %33
  %5145 = call float @dx.op.tertiary.f32(i32 46, float %5132, float %29, float %5144)  ; FMad(a,b,c)
  %5146 = call float @dx.op.tertiary.f32(i32 46, float %5118, float %25, float %5145)  ; FMad(a,b,c)
  %5147 = fadd fast float %5146, %21
  %5148 = fmul fast float %5131, %32
  %5149 = call float @dx.op.tertiary.f32(i32 46, float %5132, float %28, float %5148)  ; FMad(a,b,c)
  %5150 = call float @dx.op.tertiary.f32(i32 46, float %5118, float %24, float %5149)  ; FMad(a,b,c)
  %5151 = fadd fast float %5150, %20
  %5152 = fdiv fast float %5151, %5136
  %5153 = fdiv fast float %5147, %5136
  %5154 = fdiv fast float %5143, %5136
  %5155 = fsub fast float %5152, %17
  %5156 = fsub fast float %5153, %18
  %5157 = fsub fast float %5154, %19
  %5158 = fmul fast float %5155, %5155
  %5159 = fmul fast float %5156, %5156
  %5160 = fadd fast float %5159, %5158
  %5161 = fmul fast float %5157, %5157
  %5162 = fadd fast float %5160, %5161
  %5163 = call float @dx.op.unary.f32(i32 24, float %5162)  ; Sqrt(value)
  %5164 = fsub fast float %5163, %9
  %5165 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5164)  ; FMax(a,b)
  %5166 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %5166, label %5167, label %5190

; <label>:5167                                    ; preds = %5139
  %5168 = call float @dx.op.unary.f32(i32 6, float %5156)  ; FAbs(value)
  %5169 = fmul fast float %5168, %11
  %5170 = fcmp fast olt float %5169, 0x3F50624DE0000000
  br i1 %5170, label %5171, label %5174

; <label>:5171                                    ; preds = %5167
  %5172 = fmul fast float %5169, 5.000000e-01
  %5173 = fsub fast float 1.000000e+00, %5172
  br label %5179

; <label>:5174                                    ; preds = %5167
  %5175 = fmul fast float %5169, 0xBFF7154760000000
  %5176 = call float @dx.op.unary.f32(i32 21, float %5175)  ; Exp(value)
  %5177 = fsub fast float 1.000000e+00, %5176
  %5178 = fdiv fast float %5177, %5169
  br label %5179

; <label>:5179                                    ; preds = %5174, %5171
  %5180 = phi float [ %5173, %5171 ], [ %5178, %5174 ]
  %5181 = call float @dx.op.binary.f32(i32 36, float %5153, float %18)  ; FMin(a,b)
  %5182 = fsub fast float %5181, %10
  %5183 = fmul fast float %11, %5182
  %5184 = fsub fast float -0.000000e+00, %5183
  %5185 = call float @dx.op.binary.f32(i32 35, float %5184, float -4.000000e+01)  ; FMax(a,b)
  %5186 = call float @dx.op.binary.f32(i32 36, float %5185, float 5.000000e+00)  ; FMin(a,b)
  %5187 = fmul fast float %5186, 0x3FF7154760000000
  %5188 = call float @dx.op.unary.f32(i32 21, float %5187)  ; Exp(value)
  %5189 = fmul fast float %5188, %5180
  br label %5190

; <label>:5190                                    ; preds = %5179, %5139
  %5191 = phi float [ %5189, %5179 ], [ 1.000000e+00, %5139 ]
  %5192 = fmul fast float %5165, %16
  %5193 = fmul fast float %5192, %5191
  %5194 = fcmp fast ole float %5163, %9
  %5195 = fcmp fast olt float %5163, 0x3F1A36E2E0000000
  %5196 = or i1 %5194, %5195
  br i1 %5196, label %5243, label %5197

; <label>:5197                                    ; preds = %5190
  %5198 = fdiv fast float %9, %5163
  %5199 = fmul fast float %5198, %5155
  %5200 = fmul fast float %5198, %5156
  %5201 = fmul fast float %5198, %5157
  %5202 = fadd fast float %5199, %17
  %5203 = fadd fast float %5200, %18
  %5204 = fadd fast float %5201, %19
  %5205 = fadd fast float %5202, -9.000000e+02
  %5206 = fadd fast float %5203, -1.500000e+01
  %5207 = fadd fast float %5204, -7.500000e+02
  %5208 = fmul fast float %5205, 0x3F62345680000000
  %5209 = fmul fast float %5206, 0x3F62345680000000
  %5210 = fmul fast float %5207, 0x3F62345680000000
  %5211 = call float @dx.op.dot3.f32(i32 55, float %5208, float %5209, float %5210, float %5208, float %5209, float %5210)  ; Dot3(ax,ay,az,bx,by,bz)
  %5212 = fsub fast float 1.000000e+00, %5211
  %5213 = call float @dx.op.unary.f32(i32 7, float %5212)  ; Saturate(value)
  %5214 = fmul fast float %5213, %5213
  %5215 = fadd fast float %5202, %5152
  %5216 = fadd fast float %5203, %5153
  %5217 = fadd fast float %5204, %5154
  %5218 = fmul fast float %5215, 0x3F52345680000000
  %5219 = fadd fast float %5218, -2.000000e+00
  %5220 = fmul fast float %5216, 0x3F52345680000000
  %5221 = fadd fast float %5220, 0xBFA1111120000000
  %5222 = fmul fast float %5217, 0x3F52345680000000
  %5223 = fadd fast float %5222, 0xBFFAAAAAC0000000
  %5224 = call float @dx.op.dot3.f32(i32 55, float %5219, float %5221, float %5223, float %5219, float %5221, float %5223)  ; Dot3(ax,ay,az,bx,by,bz)
  %5225 = fsub fast float 1.000000e+00, %5224
  %5226 = call float @dx.op.unary.f32(i32 7, float %5225)  ; Saturate(value)
  %5227 = fmul fast float %5226, %5226
  %5228 = fmul fast float %5227, 4.000000e+00
  %5229 = fadd fast float %5228, %5214
  %5230 = fadd fast float %5152, -9.000000e+02
  %5231 = fadd fast float %5153, -1.500000e+01
  %5232 = fadd fast float %5154, -7.500000e+02
  %5233 = fmul fast float %5230, 0x3F62345680000000
  %5234 = fmul fast float %5231, 0x3F62345680000000
  %5235 = fmul fast float %5232, 0x3F62345680000000
  %5236 = call float @dx.op.dot3.f32(i32 55, float %5233, float %5234, float %5235, float %5233, float %5234, float %5235)  ; Dot3(ax,ay,az,bx,by,bz)
  %5237 = fsub fast float 1.000000e+00, %5236
  %5238 = call float @dx.op.unary.f32(i32 7, float %5237)  ; Saturate(value)
  %5239 = fmul fast float %5238, %5238
  %5240 = fadd fast float %5229, %5239
  %5241 = fmul fast float %5164, 0x3F25D867E0000000
  %5242 = fmul fast float %5241, %5240
  br label %5243

; <label>:5243                                    ; preds = %5197, %5190
  %5244 = phi float [ %5242, %5197 ], [ 0.000000e+00, %5190 ]
  %5245 = fadd fast float %5244, %5193
  %5246 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %5245)  ; FMin(a,b)
  %5247 = fmul fast float %5246, 0xBFF7154760000000
  %5248 = call float @dx.op.unary.f32(i32 21, float %5247)  ; Exp(value)
  %5249 = fsub fast float 1.000000e+00, %5248
  %5250 = call float @dx.op.binary.f32(i32 36, float %12, float %5249)  ; FMin(a,b)
  %5251 = fsub fast float %13, %5077
  %5252 = fsub fast float %14, %5078
  %5253 = fsub fast float %15, %5079
  %5254 = fmul fast float %5250, %5251
  %5255 = fmul fast float %5250, %5252
  %5256 = fmul fast float %5250, %5253
  %5257 = fadd fast float %5254, %5077
  %5258 = fadd fast float %5255, %5078
  %5259 = fadd fast float %5256, %5079
  br label %5260

; <label>:5260                                    ; preds = %5243, %5122, %5116
  %5261 = phi float [ %5257, %5243 ], [ %5077, %5122 ], [ %5077, %5116 ]
  %5262 = phi float [ %5258, %5243 ], [ %5078, %5122 ], [ %5078, %5116 ]
  %5263 = phi float [ %5259, %5243 ], [ %5079, %5122 ], [ %5079, %5116 ]
  %5264 = fadd fast float %5, 1.000000e+00
  %5265 = fadd fast float %6, 1.000000e+00
  %5266 = fsub fast float 1.000000e+00, %5
  %5267 = fmul fast float %36, %5264
  %5268 = fmul fast float %36, %5265
  %5269 = fmul fast float %36, %5266
  %5270 = fmul fast float %5267, %5261
  %5271 = fmul fast float %5268, %5262
  %5272 = fmul fast float %5269, %5263
  %5273 = fcmp fast ult float %37, 5.000000e-01
  br i1 %5273, label %5299, label %5274

; <label>:5274                                    ; preds = %5260
  %5275 = fmul fast float %5270, 0x4004147AE0000000
  %5276 = fmul fast float %5271, 0x4004147AE0000000
  %5277 = fmul fast float %5272, 0x4004147AE0000000
  %5278 = fadd fast float %5275, 0x3F9EB851E0000000
  %5279 = fadd fast float %5276, 0x3F9EB851E0000000
  %5280 = fadd fast float %5277, 0x3F9EB851E0000000
  %5281 = fmul fast float %5278, %5270
  %5282 = fmul fast float %5279, %5271
  %5283 = fmul fast float %5280, %5272
  %5284 = fmul fast float %5270, 0x400370A3E0000000
  %5285 = fmul fast float %5271, 0x400370A3E0000000
  %5286 = fmul fast float %5272, 0x400370A3E0000000
  %5287 = fadd fast float %5284, 0x3FE2E147A0000000
  %5288 = fadd fast float %5285, 0x3FE2E147A0000000
  %5289 = fadd fast float %5286, 0x3FE2E147A0000000
  %5290 = fmul fast float %5287, %5270
  %5291 = fmul fast float %5288, %5271
  %5292 = fmul fast float %5289, %5272
  %5293 = fadd fast float %5290, 0x3FC1EB8520000000
  %5294 = fadd fast float %5291, 0x3FC1EB8520000000
  %5295 = fadd fast float %5292, 0x3FC1EB8520000000
  %5296 = fdiv fast float %5281, %5293
  %5297 = fdiv fast float %5282, %5294
  %5298 = fdiv fast float %5283, %5295
  br label %5299

; <label>:5299                                    ; preds = %5274, %5260
  %5300 = phi float [ %5296, %5274 ], [ %5270, %5260 ]
  %5301 = phi float [ %5297, %5274 ], [ %5271, %5260 ]
  %5302 = phi float [ %5298, %5274 ], [ %5272, %5260 ]
  %5303 = call float @dx.op.unary.f32(i32 7, float %5300)  ; Saturate(value)
  %5304 = call float @dx.op.unary.f32(i32 7, float %5301)  ; Saturate(value)
  %5305 = call float @dx.op.unary.f32(i32 7, float %5302)  ; Saturate(value)
  %5306 = call float @dx.op.dot3.f32(i32 55, float %5303, float %5304, float %5305, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5307 = fsub fast float %5303, %5306
  %5308 = fsub fast float %5304, %5306
  %5309 = fsub fast float %5305, %5306
  %5310 = fmul fast float %5307, %8
  %5311 = fmul fast float %5308, %8
  %5312 = fmul fast float %5309, %8
  %5313 = fadd fast float %5310, %5306
  %5314 = fadd fast float %5311, %5306
  %5315 = fadd fast float %5312, %5306
  %5316 = call float @dx.op.unary.f32(i32 7, float %5313)  ; Saturate(value)
  %5317 = call float @dx.op.unary.f32(i32 7, float %5314)  ; Saturate(value)
  %5318 = call float @dx.op.unary.f32(i32 7, float %5315)  ; Saturate(value)
  %5319 = fadd fast float %5316, 0xBFC70A3D80000000
  %5320 = fadd fast float %5317, 0xBFC70A3D80000000
  %5321 = fadd fast float %5318, 0xBFC70A3D80000000
  %5322 = fmul fast float %5319, %7
  %5323 = fmul fast float %5320, %7
  %5324 = fmul fast float %5321, %7
  %5325 = fadd fast float %5322, 0x3FC70A3D80000000
  %5326 = fadd fast float %5323, 0x3FC70A3D80000000
  %5327 = fadd fast float %5324, 0x3FC70A3D80000000
  %5328 = call float @dx.op.unary.f32(i32 7, float %5325)  ; Saturate(value)
  %5329 = call float @dx.op.unary.f32(i32 7, float %5326)  ; Saturate(value)
  %5330 = call float @dx.op.unary.f32(i32 7, float %5327)  ; Saturate(value)
  br label %5331

; <label>:5331                                    ; preds = %5299, %5082
  %5332 = phi float [ %5113, %5082 ], [ %5328, %5299 ]
  %5333 = phi float [ %5114, %5082 ], [ %5329, %5299 ]
  %5334 = phi float [ %5115, %5082 ], [ %5330, %5299 ]
  %5335 = fsub fast float %5332, %5052
  %5336 = fsub fast float %5333, %5053
  %5337 = fsub fast float %5334, %5054
  %5338 = fmul fast float %5335, %5069
  %5339 = fmul fast float %5336, %5069
  %5340 = fmul fast float %5337, %5069
  %5341 = fadd fast float %5338, %5052
  %5342 = fadd fast float %5339, %5053
  %5343 = fadd fast float %5340, %5054
  br label %5344

; <label>:5344                                    ; preds = %5331, %5023
  %5345 = phi float [ %5341, %5331 ], [ %5052, %5023 ]
  %5346 = phi float [ %5342, %5331 ], [ %5053, %5023 ]
  %5347 = phi float [ %5343, %5331 ], [ %5054, %5023 ]
  %5348 = add i32 %70, 1
  %5349 = call i32 @dx.op.binary.i32(i32 37, i32 %5348, i32 0)  ; IMax(a,b)
  %5350 = call i32 @dx.op.binary.i32(i32 38, i32 %5349, i32 %60)  ; IMin(a,b)
  %5351 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5058, i32 %5350, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5352 = extractvalue %dx.types.ResRet.f32 %5351, 0
  %5353 = fsub fast float %5352, %88
  %5354 = call float @dx.op.unary.f32(i32 6, float %5353)  ; FAbs(value)
  %5355 = fdiv fast float %5354, %5064
  %5356 = fsub fast float 1.000000e+00, %5355
  %5357 = call float @dx.op.unary.f32(i32 7, float %5356)  ; Saturate(value)
  %5358 = fcmp fast ugt float %5357, 0.000000e+00
  br i1 %5358, label %5359, label %5632

; <label>:5359                                    ; preds = %5344
  %5360 = call i32 @dx.op.binary.i32(i32 37, i32 %5058, i32 0)  ; IMax(a,b)
  %5361 = call i32 @dx.op.binary.i32(i32 37, i32 %5350, i32 0)  ; IMax(a,b)
  %5362 = call i32 @dx.op.binary.i32(i32 38, i32 %5360, i32 %59)  ; IMin(a,b)
  %5363 = call i32 @dx.op.binary.i32(i32 38, i32 %5361, i32 %60)  ; IMin(a,b)
  %5364 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %5362, i32 %5363, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5365 = extractvalue %dx.types.ResRet.f32 %5364, 0
  %5366 = extractvalue %dx.types.ResRet.f32 %5364, 1
  %5367 = extractvalue %dx.types.ResRet.f32 %5364, 2
  %5368 = extractvalue %dx.types.ResRet.f32 %5364, 3
  %5369 = fcmp fast olt float %5368, 0.000000e+00
  br i1 %5369, label %5370, label %5404

; <label>:5370                                    ; preds = %5359
  %5371 = fcmp fast ogt float %5365, 0x3FA4B5DCC0000000
  %5372 = fcmp fast ogt float %5366, 0x3FA4B5DCC0000000
  %5373 = fcmp fast ogt float %5367, 0x3FA4B5DCC0000000
  %5374 = select i1 %5371, float 0.000000e+00, float 1.000000e+00
  %5375 = select i1 %5372, float 0.000000e+00, float 1.000000e+00
  %5376 = select i1 %5373, float 0.000000e+00, float 1.000000e+00
  %5377 = fmul fast float %5365, 0x3FB3D07220000000
  %5378 = fmul fast float %5366, 0x3FB3D07220000000
  %5379 = fmul fast float %5367, 0x3FB3D07220000000
  %5380 = fadd fast float %5365, 0x3FAC28F5C0000000
  %5381 = fadd fast float %5366, 0x3FAC28F5C0000000
  %5382 = fadd fast float %5367, 0x3FAC28F5C0000000
  %5383 = fmul fast float %5380, 0x3FEE54EDE0000000
  %5384 = fmul fast float %5381, 0x3FEE54EDE0000000
  %5385 = fmul fast float %5382, 0x3FEE54EDE0000000
  %5386 = call float @dx.op.unary.f32(i32 23, float %5383)  ; Log(value)
  %5387 = call float @dx.op.unary.f32(i32 23, float %5384)  ; Log(value)
  %5388 = call float @dx.op.unary.f32(i32 23, float %5385)  ; Log(value)
  %5389 = fmul fast float %5386, 0x4003333340000000
  %5390 = fmul fast float %5387, 0x4003333340000000
  %5391 = fmul fast float %5388, 0x4003333340000000
  %5392 = call float @dx.op.unary.f32(i32 21, float %5389)  ; Exp(value)
  %5393 = call float @dx.op.unary.f32(i32 21, float %5390)  ; Exp(value)
  %5394 = call float @dx.op.unary.f32(i32 21, float %5391)  ; Exp(value)
  %5395 = fsub fast float %5377, %5392
  %5396 = fsub fast float %5378, %5393
  %5397 = fsub fast float %5379, %5394
  %5398 = fmul fast float %5395, %5374
  %5399 = fmul fast float %5396, %5375
  %5400 = fmul fast float %5397, %5376
  %5401 = fadd fast float %5398, %5392
  %5402 = fadd fast float %5399, %5393
  %5403 = fadd fast float %5400, %5394
  br label %5619

; <label>:5404                                    ; preds = %5359
  %5405 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5362, i32 %5363, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5406 = extractvalue %dx.types.ResRet.f32 %5405, 0
  %5407 = fcmp fast ogt float %38, 5.000000e-01
  %5408 = fcmp fast olt float %5406, 1.000000e+00
  %5409 = and i1 %5407, %5408
  br i1 %5409, label %5410, label %5548

; <label>:5410                                    ; preds = %5404
  %5411 = sitofp i32 %5362 to float
  %5412 = sitofp i32 %5363 to float
  %5413 = fadd fast float %5411, 5.000000e-01
  %5414 = fadd fast float %5412, 5.000000e-01
  %5415 = fdiv fast float %5413, %45
  %5416 = fdiv fast float %5414, %46
  %5417 = fmul fast float %5415, 2.000000e+00
  %5418 = fmul fast float %5416, 2.000000e+00
  %5419 = fadd fast float %5417, -1.000000e+00
  %5420 = fsub fast float 1.000000e+00, %5418
  %5421 = fmul fast float %5419, %35
  %5422 = call float @dx.op.tertiary.f32(i32 46, float %5420, float %31, float %5421)  ; FMad(a,b,c)
  %5423 = call float @dx.op.tertiary.f32(i32 46, float %5406, float %27, float %5422)  ; FMad(a,b,c)
  %5424 = fadd fast float %5423, %23
  %5425 = call float @dx.op.unary.f32(i32 6, float %5424)  ; FAbs(value)
  %5426 = fcmp fast ogt float %5425, 0x3EB0C6F7A0000000
  br i1 %5426, label %5427, label %5548

; <label>:5427                                    ; preds = %5410
  %5428 = fmul fast float %5419, %34
  %5429 = call float @dx.op.tertiary.f32(i32 46, float %5420, float %30, float %5428)  ; FMad(a,b,c)
  %5430 = call float @dx.op.tertiary.f32(i32 46, float %5406, float %26, float %5429)  ; FMad(a,b,c)
  %5431 = fadd fast float %5430, %22
  %5432 = fmul fast float %5419, %33
  %5433 = call float @dx.op.tertiary.f32(i32 46, float %5420, float %29, float %5432)  ; FMad(a,b,c)
  %5434 = call float @dx.op.tertiary.f32(i32 46, float %5406, float %25, float %5433)  ; FMad(a,b,c)
  %5435 = fadd fast float %5434, %21
  %5436 = fmul fast float %5419, %32
  %5437 = call float @dx.op.tertiary.f32(i32 46, float %5420, float %28, float %5436)  ; FMad(a,b,c)
  %5438 = call float @dx.op.tertiary.f32(i32 46, float %5406, float %24, float %5437)  ; FMad(a,b,c)
  %5439 = fadd fast float %5438, %20
  %5440 = fdiv fast float %5439, %5424
  %5441 = fdiv fast float %5435, %5424
  %5442 = fdiv fast float %5431, %5424
  %5443 = fsub fast float %5440, %17
  %5444 = fsub fast float %5441, %18
  %5445 = fsub fast float %5442, %19
  %5446 = fmul fast float %5443, %5443
  %5447 = fmul fast float %5444, %5444
  %5448 = fadd fast float %5447, %5446
  %5449 = fmul fast float %5445, %5445
  %5450 = fadd fast float %5448, %5449
  %5451 = call float @dx.op.unary.f32(i32 24, float %5450)  ; Sqrt(value)
  %5452 = fsub fast float %5451, %9
  %5453 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5452)  ; FMax(a,b)
  %5454 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %5454, label %5455, label %5478

; <label>:5455                                    ; preds = %5427
  %5456 = call float @dx.op.unary.f32(i32 6, float %5444)  ; FAbs(value)
  %5457 = fmul fast float %5456, %11
  %5458 = fcmp fast olt float %5457, 0x3F50624DE0000000
  br i1 %5458, label %5459, label %5462

; <label>:5459                                    ; preds = %5455
  %5460 = fmul fast float %5457, 5.000000e-01
  %5461 = fsub fast float 1.000000e+00, %5460
  br label %5467

; <label>:5462                                    ; preds = %5455
  %5463 = fmul fast float %5457, 0xBFF7154760000000
  %5464 = call float @dx.op.unary.f32(i32 21, float %5463)  ; Exp(value)
  %5465 = fsub fast float 1.000000e+00, %5464
  %5466 = fdiv fast float %5465, %5457
  br label %5467

; <label>:5467                                    ; preds = %5462, %5459
  %5468 = phi float [ %5461, %5459 ], [ %5466, %5462 ]
  %5469 = call float @dx.op.binary.f32(i32 36, float %5441, float %18)  ; FMin(a,b)
  %5470 = fsub fast float %5469, %10
  %5471 = fmul fast float %11, %5470
  %5472 = fsub fast float -0.000000e+00, %5471
  %5473 = call float @dx.op.binary.f32(i32 35, float %5472, float -4.000000e+01)  ; FMax(a,b)
  %5474 = call float @dx.op.binary.f32(i32 36, float %5473, float 5.000000e+00)  ; FMin(a,b)
  %5475 = fmul fast float %5474, 0x3FF7154760000000
  %5476 = call float @dx.op.unary.f32(i32 21, float %5475)  ; Exp(value)
  %5477 = fmul fast float %5476, %5468
  br label %5478

; <label>:5478                                    ; preds = %5467, %5427
  %5479 = phi float [ %5477, %5467 ], [ 1.000000e+00, %5427 ]
  %5480 = fmul fast float %5453, %16
  %5481 = fmul fast float %5480, %5479
  %5482 = fcmp fast ole float %5451, %9
  %5483 = fcmp fast olt float %5451, 0x3F1A36E2E0000000
  %5484 = or i1 %5482, %5483
  br i1 %5484, label %5531, label %5485

; <label>:5485                                    ; preds = %5478
  %5486 = fdiv fast float %9, %5451
  %5487 = fmul fast float %5486, %5443
  %5488 = fmul fast float %5486, %5444
  %5489 = fmul fast float %5486, %5445
  %5490 = fadd fast float %5487, %17
  %5491 = fadd fast float %5488, %18
  %5492 = fadd fast float %5489, %19
  %5493 = fadd fast float %5490, -9.000000e+02
  %5494 = fadd fast float %5491, -1.500000e+01
  %5495 = fadd fast float %5492, -7.500000e+02
  %5496 = fmul fast float %5493, 0x3F62345680000000
  %5497 = fmul fast float %5494, 0x3F62345680000000
  %5498 = fmul fast float %5495, 0x3F62345680000000
  %5499 = call float @dx.op.dot3.f32(i32 55, float %5496, float %5497, float %5498, float %5496, float %5497, float %5498)  ; Dot3(ax,ay,az,bx,by,bz)
  %5500 = fsub fast float 1.000000e+00, %5499
  %5501 = call float @dx.op.unary.f32(i32 7, float %5500)  ; Saturate(value)
  %5502 = fmul fast float %5501, %5501
  %5503 = fadd fast float %5490, %5440
  %5504 = fadd fast float %5491, %5441
  %5505 = fadd fast float %5492, %5442
  %5506 = fmul fast float %5503, 0x3F52345680000000
  %5507 = fadd fast float %5506, -2.000000e+00
  %5508 = fmul fast float %5504, 0x3F52345680000000
  %5509 = fadd fast float %5508, 0xBFA1111120000000
  %5510 = fmul fast float %5505, 0x3F52345680000000
  %5511 = fadd fast float %5510, 0xBFFAAAAAC0000000
  %5512 = call float @dx.op.dot3.f32(i32 55, float %5507, float %5509, float %5511, float %5507, float %5509, float %5511)  ; Dot3(ax,ay,az,bx,by,bz)
  %5513 = fsub fast float 1.000000e+00, %5512
  %5514 = call float @dx.op.unary.f32(i32 7, float %5513)  ; Saturate(value)
  %5515 = fmul fast float %5514, %5514
  %5516 = fmul fast float %5515, 4.000000e+00
  %5517 = fadd fast float %5516, %5502
  %5518 = fadd fast float %5440, -9.000000e+02
  %5519 = fadd fast float %5441, -1.500000e+01
  %5520 = fadd fast float %5442, -7.500000e+02
  %5521 = fmul fast float %5518, 0x3F62345680000000
  %5522 = fmul fast float %5519, 0x3F62345680000000
  %5523 = fmul fast float %5520, 0x3F62345680000000
  %5524 = call float @dx.op.dot3.f32(i32 55, float %5521, float %5522, float %5523, float %5521, float %5522, float %5523)  ; Dot3(ax,ay,az,bx,by,bz)
  %5525 = fsub fast float 1.000000e+00, %5524
  %5526 = call float @dx.op.unary.f32(i32 7, float %5525)  ; Saturate(value)
  %5527 = fmul fast float %5526, %5526
  %5528 = fadd fast float %5517, %5527
  %5529 = fmul fast float %5452, 0x3F25D867E0000000
  %5530 = fmul fast float %5529, %5528
  br label %5531

; <label>:5531                                    ; preds = %5485, %5478
  %5532 = phi float [ %5530, %5485 ], [ 0.000000e+00, %5478 ]
  %5533 = fadd fast float %5532, %5481
  %5534 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %5533)  ; FMin(a,b)
  %5535 = fmul fast float %5534, 0xBFF7154760000000
  %5536 = call float @dx.op.unary.f32(i32 21, float %5535)  ; Exp(value)
  %5537 = fsub fast float 1.000000e+00, %5536
  %5538 = call float @dx.op.binary.f32(i32 36, float %12, float %5537)  ; FMin(a,b)
  %5539 = fsub fast float %13, %5365
  %5540 = fsub fast float %14, %5366
  %5541 = fsub fast float %15, %5367
  %5542 = fmul fast float %5538, %5539
  %5543 = fmul fast float %5538, %5540
  %5544 = fmul fast float %5538, %5541
  %5545 = fadd fast float %5542, %5365
  %5546 = fadd fast float %5543, %5366
  %5547 = fadd fast float %5544, %5367
  br label %5548

; <label>:5548                                    ; preds = %5531, %5410, %5404
  %5549 = phi float [ %5545, %5531 ], [ %5365, %5410 ], [ %5365, %5404 ]
  %5550 = phi float [ %5546, %5531 ], [ %5366, %5410 ], [ %5366, %5404 ]
  %5551 = phi float [ %5547, %5531 ], [ %5367, %5410 ], [ %5367, %5404 ]
  %5552 = fadd fast float %5, 1.000000e+00
  %5553 = fadd fast float %6, 1.000000e+00
  %5554 = fsub fast float 1.000000e+00, %5
  %5555 = fmul fast float %36, %5552
  %5556 = fmul fast float %36, %5553
  %5557 = fmul fast float %36, %5554
  %5558 = fmul fast float %5555, %5549
  %5559 = fmul fast float %5556, %5550
  %5560 = fmul fast float %5557, %5551
  %5561 = fcmp fast ult float %37, 5.000000e-01
  br i1 %5561, label %5587, label %5562

; <label>:5562                                    ; preds = %5548
  %5563 = fmul fast float %5558, 0x4004147AE0000000
  %5564 = fmul fast float %5559, 0x4004147AE0000000
  %5565 = fmul fast float %5560, 0x4004147AE0000000
  %5566 = fadd fast float %5563, 0x3F9EB851E0000000
  %5567 = fadd fast float %5564, 0x3F9EB851E0000000
  %5568 = fadd fast float %5565, 0x3F9EB851E0000000
  %5569 = fmul fast float %5566, %5558
  %5570 = fmul fast float %5567, %5559
  %5571 = fmul fast float %5568, %5560
  %5572 = fmul fast float %5558, 0x400370A3E0000000
  %5573 = fmul fast float %5559, 0x400370A3E0000000
  %5574 = fmul fast float %5560, 0x400370A3E0000000
  %5575 = fadd fast float %5572, 0x3FE2E147A0000000
  %5576 = fadd fast float %5573, 0x3FE2E147A0000000
  %5577 = fadd fast float %5574, 0x3FE2E147A0000000
  %5578 = fmul fast float %5575, %5558
  %5579 = fmul fast float %5576, %5559
  %5580 = fmul fast float %5577, %5560
  %5581 = fadd fast float %5578, 0x3FC1EB8520000000
  %5582 = fadd fast float %5579, 0x3FC1EB8520000000
  %5583 = fadd fast float %5580, 0x3FC1EB8520000000
  %5584 = fdiv fast float %5569, %5581
  %5585 = fdiv fast float %5570, %5582
  %5586 = fdiv fast float %5571, %5583
  br label %5587

; <label>:5587                                    ; preds = %5562, %5548
  %5588 = phi float [ %5584, %5562 ], [ %5558, %5548 ]
  %5589 = phi float [ %5585, %5562 ], [ %5559, %5548 ]
  %5590 = phi float [ %5586, %5562 ], [ %5560, %5548 ]
  %5591 = call float @dx.op.unary.f32(i32 7, float %5588)  ; Saturate(value)
  %5592 = call float @dx.op.unary.f32(i32 7, float %5589)  ; Saturate(value)
  %5593 = call float @dx.op.unary.f32(i32 7, float %5590)  ; Saturate(value)
  %5594 = call float @dx.op.dot3.f32(i32 55, float %5591, float %5592, float %5593, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5595 = fsub fast float %5591, %5594
  %5596 = fsub fast float %5592, %5594
  %5597 = fsub fast float %5593, %5594
  %5598 = fmul fast float %5595, %8
  %5599 = fmul fast float %5596, %8
  %5600 = fmul fast float %5597, %8
  %5601 = fadd fast float %5598, %5594
  %5602 = fadd fast float %5599, %5594
  %5603 = fadd fast float %5600, %5594
  %5604 = call float @dx.op.unary.f32(i32 7, float %5601)  ; Saturate(value)
  %5605 = call float @dx.op.unary.f32(i32 7, float %5602)  ; Saturate(value)
  %5606 = call float @dx.op.unary.f32(i32 7, float %5603)  ; Saturate(value)
  %5607 = fadd fast float %5604, 0xBFC70A3D80000000
  %5608 = fadd fast float %5605, 0xBFC70A3D80000000
  %5609 = fadd fast float %5606, 0xBFC70A3D80000000
  %5610 = fmul fast float %5607, %7
  %5611 = fmul fast float %5608, %7
  %5612 = fmul fast float %5609, %7
  %5613 = fadd fast float %5610, 0x3FC70A3D80000000
  %5614 = fadd fast float %5611, 0x3FC70A3D80000000
  %5615 = fadd fast float %5612, 0x3FC70A3D80000000
  %5616 = call float @dx.op.unary.f32(i32 7, float %5613)  ; Saturate(value)
  %5617 = call float @dx.op.unary.f32(i32 7, float %5614)  ; Saturate(value)
  %5618 = call float @dx.op.unary.f32(i32 7, float %5615)  ; Saturate(value)
  br label %5619

; <label>:5619                                    ; preds = %5587, %5370
  %5620 = phi float [ %5401, %5370 ], [ %5616, %5587 ]
  %5621 = phi float [ %5402, %5370 ], [ %5617, %5587 ]
  %5622 = phi float [ %5403, %5370 ], [ %5618, %5587 ]
  %5623 = fsub fast float %5620, %5052
  %5624 = fsub fast float %5621, %5053
  %5625 = fsub fast float %5622, %5054
  %5626 = fmul fast float %5623, %5357
  %5627 = fmul fast float %5624, %5357
  %5628 = fmul fast float %5625, %5357
  %5629 = fadd fast float %5626, %5052
  %5630 = fadd fast float %5627, %5053
  %5631 = fadd fast float %5628, %5054
  br label %5632

; <label>:5632                                    ; preds = %5619, %5344
  %5633 = phi float [ %5629, %5619 ], [ %5052, %5344 ]
  %5634 = phi float [ %5630, %5619 ], [ %5053, %5344 ]
  %5635 = phi float [ %5631, %5619 ], [ %5054, %5344 ]
  %5636 = add i32 %67, -1
  %5637 = call i32 @dx.op.binary.i32(i32 37, i32 %5636, i32 0)  ; IMax(a,b)
  %5638 = call i32 @dx.op.binary.i32(i32 37, i32 %70, i32 0)  ; IMax(a,b)
  %5639 = call i32 @dx.op.binary.i32(i32 38, i32 %5637, i32 %59)  ; IMin(a,b)
  %5640 = call i32 @dx.op.binary.i32(i32 38, i32 %5638, i32 %60)  ; IMin(a,b)
  %5641 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5639, i32 %5640, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5642 = extractvalue %dx.types.ResRet.f32 %5641, 0
  %5643 = fsub fast float %5642, %88
  %5644 = call float @dx.op.unary.f32(i32 6, float %5643)  ; FAbs(value)
  %5645 = fdiv fast float %5644, %5064
  %5646 = fsub fast float 1.000000e+00, %5645
  %5647 = call float @dx.op.unary.f32(i32 7, float %5646)  ; Saturate(value)
  %5648 = fcmp fast ugt float %5647, 0.000000e+00
  br i1 %5648, label %5649, label %5922

; <label>:5649                                    ; preds = %5632
  %5650 = call i32 @dx.op.binary.i32(i32 37, i32 %5639, i32 0)  ; IMax(a,b)
  %5651 = call i32 @dx.op.binary.i32(i32 37, i32 %5640, i32 0)  ; IMax(a,b)
  %5652 = call i32 @dx.op.binary.i32(i32 38, i32 %5650, i32 %59)  ; IMin(a,b)
  %5653 = call i32 @dx.op.binary.i32(i32 38, i32 %5651, i32 %60)  ; IMin(a,b)
  %5654 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %5652, i32 %5653, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5655 = extractvalue %dx.types.ResRet.f32 %5654, 0
  %5656 = extractvalue %dx.types.ResRet.f32 %5654, 1
  %5657 = extractvalue %dx.types.ResRet.f32 %5654, 2
  %5658 = extractvalue %dx.types.ResRet.f32 %5654, 3
  %5659 = fcmp fast olt float %5658, 0.000000e+00
  br i1 %5659, label %5660, label %5694

; <label>:5660                                    ; preds = %5649
  %5661 = fcmp fast ogt float %5655, 0x3FA4B5DCC0000000
  %5662 = fcmp fast ogt float %5656, 0x3FA4B5DCC0000000
  %5663 = fcmp fast ogt float %5657, 0x3FA4B5DCC0000000
  %5664 = select i1 %5661, float 0.000000e+00, float 1.000000e+00
  %5665 = select i1 %5662, float 0.000000e+00, float 1.000000e+00
  %5666 = select i1 %5663, float 0.000000e+00, float 1.000000e+00
  %5667 = fmul fast float %5655, 0x3FB3D07220000000
  %5668 = fmul fast float %5656, 0x3FB3D07220000000
  %5669 = fmul fast float %5657, 0x3FB3D07220000000
  %5670 = fadd fast float %5655, 0x3FAC28F5C0000000
  %5671 = fadd fast float %5656, 0x3FAC28F5C0000000
  %5672 = fadd fast float %5657, 0x3FAC28F5C0000000
  %5673 = fmul fast float %5670, 0x3FEE54EDE0000000
  %5674 = fmul fast float %5671, 0x3FEE54EDE0000000
  %5675 = fmul fast float %5672, 0x3FEE54EDE0000000
  %5676 = call float @dx.op.unary.f32(i32 23, float %5673)  ; Log(value)
  %5677 = call float @dx.op.unary.f32(i32 23, float %5674)  ; Log(value)
  %5678 = call float @dx.op.unary.f32(i32 23, float %5675)  ; Log(value)
  %5679 = fmul fast float %5676, 0x4003333340000000
  %5680 = fmul fast float %5677, 0x4003333340000000
  %5681 = fmul fast float %5678, 0x4003333340000000
  %5682 = call float @dx.op.unary.f32(i32 21, float %5679)  ; Exp(value)
  %5683 = call float @dx.op.unary.f32(i32 21, float %5680)  ; Exp(value)
  %5684 = call float @dx.op.unary.f32(i32 21, float %5681)  ; Exp(value)
  %5685 = fsub fast float %5667, %5682
  %5686 = fsub fast float %5668, %5683
  %5687 = fsub fast float %5669, %5684
  %5688 = fmul fast float %5685, %5664
  %5689 = fmul fast float %5686, %5665
  %5690 = fmul fast float %5687, %5666
  %5691 = fadd fast float %5688, %5682
  %5692 = fadd fast float %5689, %5683
  %5693 = fadd fast float %5690, %5684
  br label %5909

; <label>:5694                                    ; preds = %5649
  %5695 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5652, i32 %5653, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5696 = extractvalue %dx.types.ResRet.f32 %5695, 0
  %5697 = fcmp fast ogt float %38, 5.000000e-01
  %5698 = fcmp fast olt float %5696, 1.000000e+00
  %5699 = and i1 %5697, %5698
  br i1 %5699, label %5700, label %5838

; <label>:5700                                    ; preds = %5694
  %5701 = sitofp i32 %5652 to float
  %5702 = sitofp i32 %5653 to float
  %5703 = fadd fast float %5701, 5.000000e-01
  %5704 = fadd fast float %5702, 5.000000e-01
  %5705 = fdiv fast float %5703, %45
  %5706 = fdiv fast float %5704, %46
  %5707 = fmul fast float %5705, 2.000000e+00
  %5708 = fmul fast float %5706, 2.000000e+00
  %5709 = fadd fast float %5707, -1.000000e+00
  %5710 = fsub fast float 1.000000e+00, %5708
  %5711 = fmul fast float %5709, %35
  %5712 = call float @dx.op.tertiary.f32(i32 46, float %5710, float %31, float %5711)  ; FMad(a,b,c)
  %5713 = call float @dx.op.tertiary.f32(i32 46, float %5696, float %27, float %5712)  ; FMad(a,b,c)
  %5714 = fadd fast float %5713, %23
  %5715 = call float @dx.op.unary.f32(i32 6, float %5714)  ; FAbs(value)
  %5716 = fcmp fast ogt float %5715, 0x3EB0C6F7A0000000
  br i1 %5716, label %5717, label %5838

; <label>:5717                                    ; preds = %5700
  %5718 = fmul fast float %5709, %34
  %5719 = call float @dx.op.tertiary.f32(i32 46, float %5710, float %30, float %5718)  ; FMad(a,b,c)
  %5720 = call float @dx.op.tertiary.f32(i32 46, float %5696, float %26, float %5719)  ; FMad(a,b,c)
  %5721 = fadd fast float %5720, %22
  %5722 = fmul fast float %5709, %33
  %5723 = call float @dx.op.tertiary.f32(i32 46, float %5710, float %29, float %5722)  ; FMad(a,b,c)
  %5724 = call float @dx.op.tertiary.f32(i32 46, float %5696, float %25, float %5723)  ; FMad(a,b,c)
  %5725 = fadd fast float %5724, %21
  %5726 = fmul fast float %5709, %32
  %5727 = call float @dx.op.tertiary.f32(i32 46, float %5710, float %28, float %5726)  ; FMad(a,b,c)
  %5728 = call float @dx.op.tertiary.f32(i32 46, float %5696, float %24, float %5727)  ; FMad(a,b,c)
  %5729 = fadd fast float %5728, %20
  %5730 = fdiv fast float %5729, %5714
  %5731 = fdiv fast float %5725, %5714
  %5732 = fdiv fast float %5721, %5714
  %5733 = fsub fast float %5730, %17
  %5734 = fsub fast float %5731, %18
  %5735 = fsub fast float %5732, %19
  %5736 = fmul fast float %5733, %5733
  %5737 = fmul fast float %5734, %5734
  %5738 = fadd fast float %5737, %5736
  %5739 = fmul fast float %5735, %5735
  %5740 = fadd fast float %5738, %5739
  %5741 = call float @dx.op.unary.f32(i32 24, float %5740)  ; Sqrt(value)
  %5742 = fsub fast float %5741, %9
  %5743 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5742)  ; FMax(a,b)
  %5744 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %5744, label %5745, label %5768

; <label>:5745                                    ; preds = %5717
  %5746 = call float @dx.op.unary.f32(i32 6, float %5734)  ; FAbs(value)
  %5747 = fmul fast float %5746, %11
  %5748 = fcmp fast olt float %5747, 0x3F50624DE0000000
  br i1 %5748, label %5749, label %5752

; <label>:5749                                    ; preds = %5745
  %5750 = fmul fast float %5747, 5.000000e-01
  %5751 = fsub fast float 1.000000e+00, %5750
  br label %5757

; <label>:5752                                    ; preds = %5745
  %5753 = fmul fast float %5747, 0xBFF7154760000000
  %5754 = call float @dx.op.unary.f32(i32 21, float %5753)  ; Exp(value)
  %5755 = fsub fast float 1.000000e+00, %5754
  %5756 = fdiv fast float %5755, %5747
  br label %5757

; <label>:5757                                    ; preds = %5752, %5749
  %5758 = phi float [ %5751, %5749 ], [ %5756, %5752 ]
  %5759 = call float @dx.op.binary.f32(i32 36, float %5731, float %18)  ; FMin(a,b)
  %5760 = fsub fast float %5759, %10
  %5761 = fmul fast float %11, %5760
  %5762 = fsub fast float -0.000000e+00, %5761
  %5763 = call float @dx.op.binary.f32(i32 35, float %5762, float -4.000000e+01)  ; FMax(a,b)
  %5764 = call float @dx.op.binary.f32(i32 36, float %5763, float 5.000000e+00)  ; FMin(a,b)
  %5765 = fmul fast float %5764, 0x3FF7154760000000
  %5766 = call float @dx.op.unary.f32(i32 21, float %5765)  ; Exp(value)
  %5767 = fmul fast float %5766, %5758
  br label %5768

; <label>:5768                                    ; preds = %5757, %5717
  %5769 = phi float [ %5767, %5757 ], [ 1.000000e+00, %5717 ]
  %5770 = fmul fast float %5743, %16
  %5771 = fmul fast float %5770, %5769
  %5772 = fcmp fast ole float %5741, %9
  %5773 = fcmp fast olt float %5741, 0x3F1A36E2E0000000
  %5774 = or i1 %5772, %5773
  br i1 %5774, label %5821, label %5775

; <label>:5775                                    ; preds = %5768
  %5776 = fdiv fast float %9, %5741
  %5777 = fmul fast float %5776, %5733
  %5778 = fmul fast float %5776, %5734
  %5779 = fmul fast float %5776, %5735
  %5780 = fadd fast float %5777, %17
  %5781 = fadd fast float %5778, %18
  %5782 = fadd fast float %5779, %19
  %5783 = fadd fast float %5780, -9.000000e+02
  %5784 = fadd fast float %5781, -1.500000e+01
  %5785 = fadd fast float %5782, -7.500000e+02
  %5786 = fmul fast float %5783, 0x3F62345680000000
  %5787 = fmul fast float %5784, 0x3F62345680000000
  %5788 = fmul fast float %5785, 0x3F62345680000000
  %5789 = call float @dx.op.dot3.f32(i32 55, float %5786, float %5787, float %5788, float %5786, float %5787, float %5788)  ; Dot3(ax,ay,az,bx,by,bz)
  %5790 = fsub fast float 1.000000e+00, %5789
  %5791 = call float @dx.op.unary.f32(i32 7, float %5790)  ; Saturate(value)
  %5792 = fmul fast float %5791, %5791
  %5793 = fadd fast float %5780, %5730
  %5794 = fadd fast float %5781, %5731
  %5795 = fadd fast float %5782, %5732
  %5796 = fmul fast float %5793, 0x3F52345680000000
  %5797 = fadd fast float %5796, -2.000000e+00
  %5798 = fmul fast float %5794, 0x3F52345680000000
  %5799 = fadd fast float %5798, 0xBFA1111120000000
  %5800 = fmul fast float %5795, 0x3F52345680000000
  %5801 = fadd fast float %5800, 0xBFFAAAAAC0000000
  %5802 = call float @dx.op.dot3.f32(i32 55, float %5797, float %5799, float %5801, float %5797, float %5799, float %5801)  ; Dot3(ax,ay,az,bx,by,bz)
  %5803 = fsub fast float 1.000000e+00, %5802
  %5804 = call float @dx.op.unary.f32(i32 7, float %5803)  ; Saturate(value)
  %5805 = fmul fast float %5804, %5804
  %5806 = fmul fast float %5805, 4.000000e+00
  %5807 = fadd fast float %5806, %5792
  %5808 = fadd fast float %5730, -9.000000e+02
  %5809 = fadd fast float %5731, -1.500000e+01
  %5810 = fadd fast float %5732, -7.500000e+02
  %5811 = fmul fast float %5808, 0x3F62345680000000
  %5812 = fmul fast float %5809, 0x3F62345680000000
  %5813 = fmul fast float %5810, 0x3F62345680000000
  %5814 = call float @dx.op.dot3.f32(i32 55, float %5811, float %5812, float %5813, float %5811, float %5812, float %5813)  ; Dot3(ax,ay,az,bx,by,bz)
  %5815 = fsub fast float 1.000000e+00, %5814
  %5816 = call float @dx.op.unary.f32(i32 7, float %5815)  ; Saturate(value)
  %5817 = fmul fast float %5816, %5816
  %5818 = fadd fast float %5807, %5817
  %5819 = fmul fast float %5742, 0x3F25D867E0000000
  %5820 = fmul fast float %5819, %5818
  br label %5821

; <label>:5821                                    ; preds = %5775, %5768
  %5822 = phi float [ %5820, %5775 ], [ 0.000000e+00, %5768 ]
  %5823 = fadd fast float %5822, %5771
  %5824 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %5823)  ; FMin(a,b)
  %5825 = fmul fast float %5824, 0xBFF7154760000000
  %5826 = call float @dx.op.unary.f32(i32 21, float %5825)  ; Exp(value)
  %5827 = fsub fast float 1.000000e+00, %5826
  %5828 = call float @dx.op.binary.f32(i32 36, float %12, float %5827)  ; FMin(a,b)
  %5829 = fsub fast float %13, %5655
  %5830 = fsub fast float %14, %5656
  %5831 = fsub fast float %15, %5657
  %5832 = fmul fast float %5828, %5829
  %5833 = fmul fast float %5828, %5830
  %5834 = fmul fast float %5828, %5831
  %5835 = fadd fast float %5832, %5655
  %5836 = fadd fast float %5833, %5656
  %5837 = fadd fast float %5834, %5657
  br label %5838

; <label>:5838                                    ; preds = %5821, %5700, %5694
  %5839 = phi float [ %5835, %5821 ], [ %5655, %5700 ], [ %5655, %5694 ]
  %5840 = phi float [ %5836, %5821 ], [ %5656, %5700 ], [ %5656, %5694 ]
  %5841 = phi float [ %5837, %5821 ], [ %5657, %5700 ], [ %5657, %5694 ]
  %5842 = fadd fast float %5, 1.000000e+00
  %5843 = fadd fast float %6, 1.000000e+00
  %5844 = fsub fast float 1.000000e+00, %5
  %5845 = fmul fast float %36, %5842
  %5846 = fmul fast float %36, %5843
  %5847 = fmul fast float %36, %5844
  %5848 = fmul fast float %5845, %5839
  %5849 = fmul fast float %5846, %5840
  %5850 = fmul fast float %5847, %5841
  %5851 = fcmp fast ult float %37, 5.000000e-01
  br i1 %5851, label %5877, label %5852

; <label>:5852                                    ; preds = %5838
  %5853 = fmul fast float %5848, 0x4004147AE0000000
  %5854 = fmul fast float %5849, 0x4004147AE0000000
  %5855 = fmul fast float %5850, 0x4004147AE0000000
  %5856 = fadd fast float %5853, 0x3F9EB851E0000000
  %5857 = fadd fast float %5854, 0x3F9EB851E0000000
  %5858 = fadd fast float %5855, 0x3F9EB851E0000000
  %5859 = fmul fast float %5856, %5848
  %5860 = fmul fast float %5857, %5849
  %5861 = fmul fast float %5858, %5850
  %5862 = fmul fast float %5848, 0x400370A3E0000000
  %5863 = fmul fast float %5849, 0x400370A3E0000000
  %5864 = fmul fast float %5850, 0x400370A3E0000000
  %5865 = fadd fast float %5862, 0x3FE2E147A0000000
  %5866 = fadd fast float %5863, 0x3FE2E147A0000000
  %5867 = fadd fast float %5864, 0x3FE2E147A0000000
  %5868 = fmul fast float %5865, %5848
  %5869 = fmul fast float %5866, %5849
  %5870 = fmul fast float %5867, %5850
  %5871 = fadd fast float %5868, 0x3FC1EB8520000000
  %5872 = fadd fast float %5869, 0x3FC1EB8520000000
  %5873 = fadd fast float %5870, 0x3FC1EB8520000000
  %5874 = fdiv fast float %5859, %5871
  %5875 = fdiv fast float %5860, %5872
  %5876 = fdiv fast float %5861, %5873
  br label %5877

; <label>:5877                                    ; preds = %5852, %5838
  %5878 = phi float [ %5874, %5852 ], [ %5848, %5838 ]
  %5879 = phi float [ %5875, %5852 ], [ %5849, %5838 ]
  %5880 = phi float [ %5876, %5852 ], [ %5850, %5838 ]
  %5881 = call float @dx.op.unary.f32(i32 7, float %5878)  ; Saturate(value)
  %5882 = call float @dx.op.unary.f32(i32 7, float %5879)  ; Saturate(value)
  %5883 = call float @dx.op.unary.f32(i32 7, float %5880)  ; Saturate(value)
  %5884 = call float @dx.op.dot3.f32(i32 55, float %5881, float %5882, float %5883, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5885 = fsub fast float %5881, %5884
  %5886 = fsub fast float %5882, %5884
  %5887 = fsub fast float %5883, %5884
  %5888 = fmul fast float %5885, %8
  %5889 = fmul fast float %5886, %8
  %5890 = fmul fast float %5887, %8
  %5891 = fadd fast float %5888, %5884
  %5892 = fadd fast float %5889, %5884
  %5893 = fadd fast float %5890, %5884
  %5894 = call float @dx.op.unary.f32(i32 7, float %5891)  ; Saturate(value)
  %5895 = call float @dx.op.unary.f32(i32 7, float %5892)  ; Saturate(value)
  %5896 = call float @dx.op.unary.f32(i32 7, float %5893)  ; Saturate(value)
  %5897 = fadd fast float %5894, 0xBFC70A3D80000000
  %5898 = fadd fast float %5895, 0xBFC70A3D80000000
  %5899 = fadd fast float %5896, 0xBFC70A3D80000000
  %5900 = fmul fast float %5897, %7
  %5901 = fmul fast float %5898, %7
  %5902 = fmul fast float %5899, %7
  %5903 = fadd fast float %5900, 0x3FC70A3D80000000
  %5904 = fadd fast float %5901, 0x3FC70A3D80000000
  %5905 = fadd fast float %5902, 0x3FC70A3D80000000
  %5906 = call float @dx.op.unary.f32(i32 7, float %5903)  ; Saturate(value)
  %5907 = call float @dx.op.unary.f32(i32 7, float %5904)  ; Saturate(value)
  %5908 = call float @dx.op.unary.f32(i32 7, float %5905)  ; Saturate(value)
  br label %5909

; <label>:5909                                    ; preds = %5877, %5660
  %5910 = phi float [ %5691, %5660 ], [ %5906, %5877 ]
  %5911 = phi float [ %5692, %5660 ], [ %5907, %5877 ]
  %5912 = phi float [ %5693, %5660 ], [ %5908, %5877 ]
  %5913 = fsub fast float %5910, %5052
  %5914 = fsub fast float %5911, %5053
  %5915 = fsub fast float %5912, %5054
  %5916 = fmul fast float %5913, %5647
  %5917 = fmul fast float %5914, %5647
  %5918 = fmul fast float %5915, %5647
  %5919 = fadd fast float %5916, %5052
  %5920 = fadd fast float %5917, %5053
  %5921 = fadd fast float %5918, %5054
  br label %5922

; <label>:5922                                    ; preds = %5909, %5632
  %5923 = phi float [ %5919, %5909 ], [ %5052, %5632 ]
  %5924 = phi float [ %5920, %5909 ], [ %5053, %5632 ]
  %5925 = phi float [ %5921, %5909 ], [ %5054, %5632 ]
  %5926 = add i32 %67, 1
  %5927 = call i32 @dx.op.binary.i32(i32 37, i32 %5926, i32 0)  ; IMax(a,b)
  %5928 = call i32 @dx.op.binary.i32(i32 38, i32 %5927, i32 %59)  ; IMin(a,b)
  %5929 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5928, i32 %5640, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5930 = extractvalue %dx.types.ResRet.f32 %5929, 0
  %5931 = fsub fast float %5930, %88
  %5932 = call float @dx.op.unary.f32(i32 6, float %5931)  ; FAbs(value)
  %5933 = fdiv fast float %5932, %5064
  %5934 = fsub fast float 1.000000e+00, %5933
  %5935 = call float @dx.op.unary.f32(i32 7, float %5934)  ; Saturate(value)
  %5936 = fcmp fast ugt float %5935, 0.000000e+00
  br i1 %5936, label %5937, label %6210

; <label>:5937                                    ; preds = %5922
  %5938 = call i32 @dx.op.binary.i32(i32 37, i32 %5928, i32 0)  ; IMax(a,b)
  %5939 = call i32 @dx.op.binary.i32(i32 37, i32 %5640, i32 0)  ; IMax(a,b)
  %5940 = call i32 @dx.op.binary.i32(i32 38, i32 %5938, i32 %59)  ; IMin(a,b)
  %5941 = call i32 @dx.op.binary.i32(i32 38, i32 %5939, i32 %60)  ; IMin(a,b)
  %5942 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %5940, i32 %5941, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5943 = extractvalue %dx.types.ResRet.f32 %5942, 0
  %5944 = extractvalue %dx.types.ResRet.f32 %5942, 1
  %5945 = extractvalue %dx.types.ResRet.f32 %5942, 2
  %5946 = extractvalue %dx.types.ResRet.f32 %5942, 3
  %5947 = fcmp fast olt float %5946, 0.000000e+00
  br i1 %5947, label %5948, label %5982

; <label>:5948                                    ; preds = %5937
  %5949 = fcmp fast ogt float %5943, 0x3FA4B5DCC0000000
  %5950 = fcmp fast ogt float %5944, 0x3FA4B5DCC0000000
  %5951 = fcmp fast ogt float %5945, 0x3FA4B5DCC0000000
  %5952 = select i1 %5949, float 0.000000e+00, float 1.000000e+00
  %5953 = select i1 %5950, float 0.000000e+00, float 1.000000e+00
  %5954 = select i1 %5951, float 0.000000e+00, float 1.000000e+00
  %5955 = fmul fast float %5943, 0x3FB3D07220000000
  %5956 = fmul fast float %5944, 0x3FB3D07220000000
  %5957 = fmul fast float %5945, 0x3FB3D07220000000
  %5958 = fadd fast float %5943, 0x3FAC28F5C0000000
  %5959 = fadd fast float %5944, 0x3FAC28F5C0000000
  %5960 = fadd fast float %5945, 0x3FAC28F5C0000000
  %5961 = fmul fast float %5958, 0x3FEE54EDE0000000
  %5962 = fmul fast float %5959, 0x3FEE54EDE0000000
  %5963 = fmul fast float %5960, 0x3FEE54EDE0000000
  %5964 = call float @dx.op.unary.f32(i32 23, float %5961)  ; Log(value)
  %5965 = call float @dx.op.unary.f32(i32 23, float %5962)  ; Log(value)
  %5966 = call float @dx.op.unary.f32(i32 23, float %5963)  ; Log(value)
  %5967 = fmul fast float %5964, 0x4003333340000000
  %5968 = fmul fast float %5965, 0x4003333340000000
  %5969 = fmul fast float %5966, 0x4003333340000000
  %5970 = call float @dx.op.unary.f32(i32 21, float %5967)  ; Exp(value)
  %5971 = call float @dx.op.unary.f32(i32 21, float %5968)  ; Exp(value)
  %5972 = call float @dx.op.unary.f32(i32 21, float %5969)  ; Exp(value)
  %5973 = fsub fast float %5955, %5970
  %5974 = fsub fast float %5956, %5971
  %5975 = fsub fast float %5957, %5972
  %5976 = fmul fast float %5973, %5952
  %5977 = fmul fast float %5974, %5953
  %5978 = fmul fast float %5975, %5954
  %5979 = fadd fast float %5976, %5970
  %5980 = fadd fast float %5977, %5971
  %5981 = fadd fast float %5978, %5972
  br label %6197

; <label>:5982                                    ; preds = %5937
  %5983 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5940, i32 %5941, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5984 = extractvalue %dx.types.ResRet.f32 %5983, 0
  %5985 = fcmp fast ogt float %38, 5.000000e-01
  %5986 = fcmp fast olt float %5984, 1.000000e+00
  %5987 = and i1 %5985, %5986
  br i1 %5987, label %5988, label %6126

; <label>:5988                                    ; preds = %5982
  %5989 = sitofp i32 %5940 to float
  %5990 = sitofp i32 %5941 to float
  %5991 = fadd fast float %5989, 5.000000e-01
  %5992 = fadd fast float %5990, 5.000000e-01
  %5993 = fdiv fast float %5991, %45
  %5994 = fdiv fast float %5992, %46
  %5995 = fmul fast float %5993, 2.000000e+00
  %5996 = fmul fast float %5994, 2.000000e+00
  %5997 = fadd fast float %5995, -1.000000e+00
  %5998 = fsub fast float 1.000000e+00, %5996
  %5999 = fmul fast float %5997, %35
  %6000 = call float @dx.op.tertiary.f32(i32 46, float %5998, float %31, float %5999)  ; FMad(a,b,c)
  %6001 = call float @dx.op.tertiary.f32(i32 46, float %5984, float %27, float %6000)  ; FMad(a,b,c)
  %6002 = fadd fast float %6001, %23
  %6003 = call float @dx.op.unary.f32(i32 6, float %6002)  ; FAbs(value)
  %6004 = fcmp fast ogt float %6003, 0x3EB0C6F7A0000000
  br i1 %6004, label %6005, label %6126

; <label>:6005                                    ; preds = %5988
  %6006 = fmul fast float %5997, %34
  %6007 = call float @dx.op.tertiary.f32(i32 46, float %5998, float %30, float %6006)  ; FMad(a,b,c)
  %6008 = call float @dx.op.tertiary.f32(i32 46, float %5984, float %26, float %6007)  ; FMad(a,b,c)
  %6009 = fadd fast float %6008, %22
  %6010 = fmul fast float %5997, %33
  %6011 = call float @dx.op.tertiary.f32(i32 46, float %5998, float %29, float %6010)  ; FMad(a,b,c)
  %6012 = call float @dx.op.tertiary.f32(i32 46, float %5984, float %25, float %6011)  ; FMad(a,b,c)
  %6013 = fadd fast float %6012, %21
  %6014 = fmul fast float %5997, %32
  %6015 = call float @dx.op.tertiary.f32(i32 46, float %5998, float %28, float %6014)  ; FMad(a,b,c)
  %6016 = call float @dx.op.tertiary.f32(i32 46, float %5984, float %24, float %6015)  ; FMad(a,b,c)
  %6017 = fadd fast float %6016, %20
  %6018 = fdiv fast float %6017, %6002
  %6019 = fdiv fast float %6013, %6002
  %6020 = fdiv fast float %6009, %6002
  %6021 = fsub fast float %6018, %17
  %6022 = fsub fast float %6019, %18
  %6023 = fsub fast float %6020, %19
  %6024 = fmul fast float %6021, %6021
  %6025 = fmul fast float %6022, %6022
  %6026 = fadd fast float %6025, %6024
  %6027 = fmul fast float %6023, %6023
  %6028 = fadd fast float %6026, %6027
  %6029 = call float @dx.op.unary.f32(i32 24, float %6028)  ; Sqrt(value)
  %6030 = fsub fast float %6029, %9
  %6031 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %6030)  ; FMax(a,b)
  %6032 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %6032, label %6033, label %6056

; <label>:6033                                    ; preds = %6005
  %6034 = call float @dx.op.unary.f32(i32 6, float %6022)  ; FAbs(value)
  %6035 = fmul fast float %6034, %11
  %6036 = fcmp fast olt float %6035, 0x3F50624DE0000000
  br i1 %6036, label %6037, label %6040

; <label>:6037                                    ; preds = %6033
  %6038 = fmul fast float %6035, 5.000000e-01
  %6039 = fsub fast float 1.000000e+00, %6038
  br label %6045

; <label>:6040                                    ; preds = %6033
  %6041 = fmul fast float %6035, 0xBFF7154760000000
  %6042 = call float @dx.op.unary.f32(i32 21, float %6041)  ; Exp(value)
  %6043 = fsub fast float 1.000000e+00, %6042
  %6044 = fdiv fast float %6043, %6035
  br label %6045

; <label>:6045                                    ; preds = %6040, %6037
  %6046 = phi float [ %6039, %6037 ], [ %6044, %6040 ]
  %6047 = call float @dx.op.binary.f32(i32 36, float %6019, float %18)  ; FMin(a,b)
  %6048 = fsub fast float %6047, %10
  %6049 = fmul fast float %11, %6048
  %6050 = fsub fast float -0.000000e+00, %6049
  %6051 = call float @dx.op.binary.f32(i32 35, float %6050, float -4.000000e+01)  ; FMax(a,b)
  %6052 = call float @dx.op.binary.f32(i32 36, float %6051, float 5.000000e+00)  ; FMin(a,b)
  %6053 = fmul fast float %6052, 0x3FF7154760000000
  %6054 = call float @dx.op.unary.f32(i32 21, float %6053)  ; Exp(value)
  %6055 = fmul fast float %6054, %6046
  br label %6056

; <label>:6056                                    ; preds = %6045, %6005
  %6057 = phi float [ %6055, %6045 ], [ 1.000000e+00, %6005 ]
  %6058 = fmul fast float %6031, %16
  %6059 = fmul fast float %6058, %6057
  %6060 = fcmp fast ole float %6029, %9
  %6061 = fcmp fast olt float %6029, 0x3F1A36E2E0000000
  %6062 = or i1 %6060, %6061
  br i1 %6062, label %6109, label %6063

; <label>:6063                                    ; preds = %6056
  %6064 = fdiv fast float %9, %6029
  %6065 = fmul fast float %6064, %6021
  %6066 = fmul fast float %6064, %6022
  %6067 = fmul fast float %6064, %6023
  %6068 = fadd fast float %6065, %17
  %6069 = fadd fast float %6066, %18
  %6070 = fadd fast float %6067, %19
  %6071 = fadd fast float %6068, -9.000000e+02
  %6072 = fadd fast float %6069, -1.500000e+01
  %6073 = fadd fast float %6070, -7.500000e+02
  %6074 = fmul fast float %6071, 0x3F62345680000000
  %6075 = fmul fast float %6072, 0x3F62345680000000
  %6076 = fmul fast float %6073, 0x3F62345680000000
  %6077 = call float @dx.op.dot3.f32(i32 55, float %6074, float %6075, float %6076, float %6074, float %6075, float %6076)  ; Dot3(ax,ay,az,bx,by,bz)
  %6078 = fsub fast float 1.000000e+00, %6077
  %6079 = call float @dx.op.unary.f32(i32 7, float %6078)  ; Saturate(value)
  %6080 = fmul fast float %6079, %6079
  %6081 = fadd fast float %6068, %6018
  %6082 = fadd fast float %6069, %6019
  %6083 = fadd fast float %6070, %6020
  %6084 = fmul fast float %6081, 0x3F52345680000000
  %6085 = fadd fast float %6084, -2.000000e+00
  %6086 = fmul fast float %6082, 0x3F52345680000000
  %6087 = fadd fast float %6086, 0xBFA1111120000000
  %6088 = fmul fast float %6083, 0x3F52345680000000
  %6089 = fadd fast float %6088, 0xBFFAAAAAC0000000
  %6090 = call float @dx.op.dot3.f32(i32 55, float %6085, float %6087, float %6089, float %6085, float %6087, float %6089)  ; Dot3(ax,ay,az,bx,by,bz)
  %6091 = fsub fast float 1.000000e+00, %6090
  %6092 = call float @dx.op.unary.f32(i32 7, float %6091)  ; Saturate(value)
  %6093 = fmul fast float %6092, %6092
  %6094 = fmul fast float %6093, 4.000000e+00
  %6095 = fadd fast float %6094, %6080
  %6096 = fadd fast float %6018, -9.000000e+02
  %6097 = fadd fast float %6019, -1.500000e+01
  %6098 = fadd fast float %6020, -7.500000e+02
  %6099 = fmul fast float %6096, 0x3F62345680000000
  %6100 = fmul fast float %6097, 0x3F62345680000000
  %6101 = fmul fast float %6098, 0x3F62345680000000
  %6102 = call float @dx.op.dot3.f32(i32 55, float %6099, float %6100, float %6101, float %6099, float %6100, float %6101)  ; Dot3(ax,ay,az,bx,by,bz)
  %6103 = fsub fast float 1.000000e+00, %6102
  %6104 = call float @dx.op.unary.f32(i32 7, float %6103)  ; Saturate(value)
  %6105 = fmul fast float %6104, %6104
  %6106 = fadd fast float %6095, %6105
  %6107 = fmul fast float %6030, 0x3F25D867E0000000
  %6108 = fmul fast float %6107, %6106
  br label %6109

; <label>:6109                                    ; preds = %6063, %6056
  %6110 = phi float [ %6108, %6063 ], [ 0.000000e+00, %6056 ]
  %6111 = fadd fast float %6110, %6059
  %6112 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %6111)  ; FMin(a,b)
  %6113 = fmul fast float %6112, 0xBFF7154760000000
  %6114 = call float @dx.op.unary.f32(i32 21, float %6113)  ; Exp(value)
  %6115 = fsub fast float 1.000000e+00, %6114
  %6116 = call float @dx.op.binary.f32(i32 36, float %12, float %6115)  ; FMin(a,b)
  %6117 = fsub fast float %13, %5943
  %6118 = fsub fast float %14, %5944
  %6119 = fsub fast float %15, %5945
  %6120 = fmul fast float %6116, %6117
  %6121 = fmul fast float %6116, %6118
  %6122 = fmul fast float %6116, %6119
  %6123 = fadd fast float %6120, %5943
  %6124 = fadd fast float %6121, %5944
  %6125 = fadd fast float %6122, %5945
  br label %6126

; <label>:6126                                    ; preds = %6109, %5988, %5982
  %6127 = phi float [ %6123, %6109 ], [ %5943, %5988 ], [ %5943, %5982 ]
  %6128 = phi float [ %6124, %6109 ], [ %5944, %5988 ], [ %5944, %5982 ]
  %6129 = phi float [ %6125, %6109 ], [ %5945, %5988 ], [ %5945, %5982 ]
  %6130 = fadd fast float %5, 1.000000e+00
  %6131 = fadd fast float %6, 1.000000e+00
  %6132 = fsub fast float 1.000000e+00, %5
  %6133 = fmul fast float %36, %6130
  %6134 = fmul fast float %36, %6131
  %6135 = fmul fast float %36, %6132
  %6136 = fmul fast float %6133, %6127
  %6137 = fmul fast float %6134, %6128
  %6138 = fmul fast float %6135, %6129
  %6139 = fcmp fast ult float %37, 5.000000e-01
  br i1 %6139, label %6165, label %6140

; <label>:6140                                    ; preds = %6126
  %6141 = fmul fast float %6136, 0x4004147AE0000000
  %6142 = fmul fast float %6137, 0x4004147AE0000000
  %6143 = fmul fast float %6138, 0x4004147AE0000000
  %6144 = fadd fast float %6141, 0x3F9EB851E0000000
  %6145 = fadd fast float %6142, 0x3F9EB851E0000000
  %6146 = fadd fast float %6143, 0x3F9EB851E0000000
  %6147 = fmul fast float %6144, %6136
  %6148 = fmul fast float %6145, %6137
  %6149 = fmul fast float %6146, %6138
  %6150 = fmul fast float %6136, 0x400370A3E0000000
  %6151 = fmul fast float %6137, 0x400370A3E0000000
  %6152 = fmul fast float %6138, 0x400370A3E0000000
  %6153 = fadd fast float %6150, 0x3FE2E147A0000000
  %6154 = fadd fast float %6151, 0x3FE2E147A0000000
  %6155 = fadd fast float %6152, 0x3FE2E147A0000000
  %6156 = fmul fast float %6153, %6136
  %6157 = fmul fast float %6154, %6137
  %6158 = fmul fast float %6155, %6138
  %6159 = fadd fast float %6156, 0x3FC1EB8520000000
  %6160 = fadd fast float %6157, 0x3FC1EB8520000000
  %6161 = fadd fast float %6158, 0x3FC1EB8520000000
  %6162 = fdiv fast float %6147, %6159
  %6163 = fdiv fast float %6148, %6160
  %6164 = fdiv fast float %6149, %6161
  br label %6165

; <label>:6165                                    ; preds = %6140, %6126
  %6166 = phi float [ %6162, %6140 ], [ %6136, %6126 ]
  %6167 = phi float [ %6163, %6140 ], [ %6137, %6126 ]
  %6168 = phi float [ %6164, %6140 ], [ %6138, %6126 ]
  %6169 = call float @dx.op.unary.f32(i32 7, float %6166)  ; Saturate(value)
  %6170 = call float @dx.op.unary.f32(i32 7, float %6167)  ; Saturate(value)
  %6171 = call float @dx.op.unary.f32(i32 7, float %6168)  ; Saturate(value)
  %6172 = call float @dx.op.dot3.f32(i32 55, float %6169, float %6170, float %6171, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %6173 = fsub fast float %6169, %6172
  %6174 = fsub fast float %6170, %6172
  %6175 = fsub fast float %6171, %6172
  %6176 = fmul fast float %6173, %8
  %6177 = fmul fast float %6174, %8
  %6178 = fmul fast float %6175, %8
  %6179 = fadd fast float %6176, %6172
  %6180 = fadd fast float %6177, %6172
  %6181 = fadd fast float %6178, %6172
  %6182 = call float @dx.op.unary.f32(i32 7, float %6179)  ; Saturate(value)
  %6183 = call float @dx.op.unary.f32(i32 7, float %6180)  ; Saturate(value)
  %6184 = call float @dx.op.unary.f32(i32 7, float %6181)  ; Saturate(value)
  %6185 = fadd fast float %6182, 0xBFC70A3D80000000
  %6186 = fadd fast float %6183, 0xBFC70A3D80000000
  %6187 = fadd fast float %6184, 0xBFC70A3D80000000
  %6188 = fmul fast float %6185, %7
  %6189 = fmul fast float %6186, %7
  %6190 = fmul fast float %6187, %7
  %6191 = fadd fast float %6188, 0x3FC70A3D80000000
  %6192 = fadd fast float %6189, 0x3FC70A3D80000000
  %6193 = fadd fast float %6190, 0x3FC70A3D80000000
  %6194 = call float @dx.op.unary.f32(i32 7, float %6191)  ; Saturate(value)
  %6195 = call float @dx.op.unary.f32(i32 7, float %6192)  ; Saturate(value)
  %6196 = call float @dx.op.unary.f32(i32 7, float %6193)  ; Saturate(value)
  br label %6197

; <label>:6197                                    ; preds = %6165, %5948
  %6198 = phi float [ %5979, %5948 ], [ %6194, %6165 ]
  %6199 = phi float [ %5980, %5948 ], [ %6195, %6165 ]
  %6200 = phi float [ %5981, %5948 ], [ %6196, %6165 ]
  %6201 = fsub fast float %6198, %5052
  %6202 = fsub fast float %6199, %5053
  %6203 = fsub fast float %6200, %5054
  %6204 = fmul fast float %6201, %5935
  %6205 = fmul fast float %6202, %5935
  %6206 = fmul fast float %6203, %5935
  %6207 = fadd fast float %6204, %5052
  %6208 = fadd fast float %6205, %5053
  %6209 = fadd fast float %6206, %5054
  br label %6210

; <label>:6210                                    ; preds = %6197, %5922
  %6211 = phi float [ %6207, %6197 ], [ %5052, %5922 ]
  %6212 = phi float [ %6208, %6197 ], [ %5053, %5922 ]
  %6213 = phi float [ %6209, %6197 ], [ %5054, %5922 ]
  %6214 = call float @dx.op.binary.f32(i32 36, float %5923, float %6211)  ; FMin(a,b)
  %6215 = call float @dx.op.binary.f32(i32 36, float %5924, float %6212)  ; FMin(a,b)
  %6216 = call float @dx.op.binary.f32(i32 36, float %5925, float %6213)  ; FMin(a,b)
  %6217 = call float @dx.op.binary.f32(i32 36, float %5345, float %5633)  ; FMin(a,b)
  %6218 = call float @dx.op.binary.f32(i32 36, float %5346, float %5634)  ; FMin(a,b)
  %6219 = call float @dx.op.binary.f32(i32 36, float %5347, float %5635)  ; FMin(a,b)
  %6220 = call float @dx.op.binary.f32(i32 36, float %6217, float %6214)  ; FMin(a,b)
  %6221 = call float @dx.op.binary.f32(i32 36, float %6218, float %6215)  ; FMin(a,b)
  %6222 = call float @dx.op.binary.f32(i32 36, float %6219, float %6216)  ; FMin(a,b)
  %6223 = call float @dx.op.binary.f32(i32 36, float %5052, float %6220)  ; FMin(a,b)
  %6224 = call float @dx.op.binary.f32(i32 36, float %5053, float %6221)  ; FMin(a,b)
  %6225 = call float @dx.op.binary.f32(i32 36, float %5054, float %6222)  ; FMin(a,b)
  %6226 = call float @dx.op.binary.f32(i32 35, float %5923, float %6211)  ; FMax(a,b)
  %6227 = call float @dx.op.binary.f32(i32 35, float %5924, float %6212)  ; FMax(a,b)
  %6228 = call float @dx.op.binary.f32(i32 35, float %5925, float %6213)  ; FMax(a,b)
  %6229 = call float @dx.op.binary.f32(i32 35, float %5345, float %5633)  ; FMax(a,b)
  %6230 = call float @dx.op.binary.f32(i32 35, float %5346, float %5634)  ; FMax(a,b)
  %6231 = call float @dx.op.binary.f32(i32 35, float %5347, float %5635)  ; FMax(a,b)
  %6232 = call float @dx.op.binary.f32(i32 35, float %6229, float %6226)  ; FMax(a,b)
  %6233 = call float @dx.op.binary.f32(i32 35, float %6230, float %6227)  ; FMax(a,b)
  %6234 = call float @dx.op.binary.f32(i32 35, float %6231, float %6228)  ; FMax(a,b)
  %6235 = call float @dx.op.binary.f32(i32 35, float %5052, float %6232)  ; FMax(a,b)
  %6236 = call float @dx.op.binary.f32(i32 35, float %5053, float %6233)  ; FMax(a,b)
  %6237 = call float @dx.op.binary.f32(i32 35, float %5054, float %6234)  ; FMax(a,b)
  %6238 = fsub fast float %6235, %6223
  %6239 = fsub fast float %6236, %6224
  %6240 = fsub fast float %6237, %6225
  %6241 = call float @dx.op.unary.f32(i32 6, float %6238)  ; FAbs(value)
  %6242 = call float @dx.op.unary.f32(i32 6, float %6239)  ; FAbs(value)
  %6243 = call float @dx.op.unary.f32(i32 6, float %6240)  ; FAbs(value)
  %6244 = call float @dx.op.binary.f32(i32 35, float %6242, float %6243)  ; FMax(a,b)
  %6245 = call float @dx.op.binary.f32(i32 35, float %6241, float %6244)  ; FMax(a,b)
  %6246 = call float @dx.op.binary.f32(i32 35, float %6236, float %6237)  ; FMax(a,b)
  %6247 = call float @dx.op.binary.f32(i32 35, float %6235, float %6246)  ; FMax(a,b)
  %6248 = fmul fast float %6247, 1.250000e-01
  %6249 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %6248)  ; FMax(a,b)
  %6250 = fcmp fast ogt float %6245, %6249
  br i1 %6250, label %6251, label %6312

; <label>:6251                                    ; preds = %6210
  %6252 = fsub fast float %5345, %5633
  %6253 = fsub fast float %5346, %5634
  %6254 = fsub fast float %5347, %5635
  %6255 = call float @dx.op.unary.f32(i32 6, float %6252)  ; FAbs(value)
  %6256 = call float @dx.op.unary.f32(i32 6, float %6253)  ; FAbs(value)
  %6257 = call float @dx.op.unary.f32(i32 6, float %6254)  ; FAbs(value)
  %6258 = call float @dx.op.binary.f32(i32 35, float %6256, float %6257)  ; FMax(a,b)
  %6259 = call float @dx.op.binary.f32(i32 35, float %6255, float %6258)  ; FMax(a,b)
  %6260 = fsub fast float %5923, %6211
  %6261 = fsub fast float %5924, %6212
  %6262 = fsub fast float %5925, %6213
  %6263 = call float @dx.op.unary.f32(i32 6, float %6260)  ; FAbs(value)
  %6264 = call float @dx.op.unary.f32(i32 6, float %6261)  ; FAbs(value)
  %6265 = call float @dx.op.unary.f32(i32 6, float %6262)  ; FAbs(value)
  %6266 = call float @dx.op.binary.f32(i32 35, float %6264, float %6265)  ; FMax(a,b)
  %6267 = call float @dx.op.binary.f32(i32 35, float %6263, float %6266)  ; FMax(a,b)
  %6268 = fcmp fast olt float %6259, %6267
  %6269 = select i1 %6268, float %5345, float %5923
  %6270 = select i1 %6268, float %5346, float %5924
  %6271 = select i1 %6268, float %5347, float %5925
  %6272 = select i1 %6268, float %5633, float %6211
  %6273 = select i1 %6268, float %5634, float %6212
  %6274 = select i1 %6268, float %5635, float %6213
  %6275 = fsub fast float %5052, %6272
  %6276 = fsub fast float %5053, %6273
  %6277 = fsub fast float %5054, %6274
  %6278 = fsub fast float %5052, %6269
  %6279 = fsub fast float %5053, %6270
  %6280 = fsub fast float %5054, %6271
  %6281 = call float @dx.op.dot3.f32(i32 55, float %6278, float %6279, float %6280, float %6275, float %6276, float %6277)  ; Dot3(ax,ay,az,bx,by,bz)
  %6282 = fcmp fast ogt float %6281, 0.000000e+00
  br i1 %6282, label %6283, label %6295

; <label>:6283                                    ; preds = %6251
  %6284 = fsub fast float %6269, %6272
  %6285 = fsub fast float %6270, %6273
  %6286 = fsub fast float %6271, %6274
  %6287 = call float @dx.op.unary.f32(i32 6, float %6284)  ; FAbs(value)
  %6288 = call float @dx.op.unary.f32(i32 6, float %6285)  ; FAbs(value)
  %6289 = call float @dx.op.unary.f32(i32 6, float %6286)  ; FAbs(value)
  %6290 = call float @dx.op.binary.f32(i32 35, float %6288, float %6289)  ; FMax(a,b)
  %6291 = call float @dx.op.binary.f32(i32 35, float %6287, float %6290)  ; FMax(a,b)
  %6292 = fmul fast float %6245, 2.500000e-01
  %6293 = fcmp fast olt float %6291, %6292
  %6294 = select i1 %6293, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  br label %6295

; <label>:6295                                    ; preds = %6283, %6251
  %6296 = phi float [ 0x3FC99999A0000000, %6251 ], [ %6294, %6283 ]
  %6297 = fadd fast float %6269, %6272
  %6298 = fadd fast float %6270, %6273
  %6299 = fadd fast float %6271, %6274
  %6300 = fmul fast float %6297, 5.000000e-01
  %6301 = fmul fast float %6298, 5.000000e-01
  %6302 = fmul fast float %6299, 5.000000e-01
  %6303 = fsub fast float %6300, %5052
  %6304 = fsub fast float %6301, %5053
  %6305 = fsub fast float %6302, %5054
  %6306 = fmul fast float %6296, %6303
  %6307 = fmul fast float %6296, %6304
  %6308 = fmul fast float %6296, %6305
  %6309 = fadd fast float %6306, %5052
  %6310 = fadd fast float %6307, %5053
  %6311 = fadd fast float %6308, %5054
  br label %6312

; <label>:6312                                    ; preds = %6295, %6210
  %6313 = phi float [ %6309, %6295 ], [ %5052, %6210 ]
  %6314 = phi float [ %6310, %6295 ], [ %5053, %6210 ]
  %6315 = phi float [ %6311, %6295 ], [ %5054, %6210 ]
  %6316 = fcmp fast ogt float %6313, 0x3F69A5C380000000
  %6317 = fcmp fast ogt float %6314, 0x3F69A5C380000000
  %6318 = fcmp fast ogt float %6315, 0x3F69A5C380000000
  %6319 = select i1 %6316, float 0.000000e+00, float 1.000000e+00
  %6320 = select i1 %6317, float 0.000000e+00, float 1.000000e+00
  %6321 = select i1 %6318, float 0.000000e+00, float 1.000000e+00
  %6322 = fmul fast float %6313, 0x4029D70A40000000
  %6323 = fmul fast float %6314, 0x4029D70A40000000
  %6324 = fmul fast float %6315, 0x4029D70A40000000
  %6325 = call float @dx.op.binary.f32(i32 35, float %6313, float 0.000000e+00)  ; FMax(a,b)
  %6326 = call float @dx.op.binary.f32(i32 35, float %6314, float 0.000000e+00)  ; FMax(a,b)
  %6327 = call float @dx.op.binary.f32(i32 35, float %6315, float 0.000000e+00)  ; FMax(a,b)
  %6328 = call float @dx.op.unary.f32(i32 23, float %6325)  ; Log(value)
  %6329 = call float @dx.op.unary.f32(i32 23, float %6326)  ; Log(value)
  %6330 = call float @dx.op.unary.f32(i32 23, float %6327)  ; Log(value)
  %6331 = fmul fast float %6328, 0x3FDAAAAAA0000000
  %6332 = fmul fast float %6329, 0x3FDAAAAAA0000000
  %6333 = fmul fast float %6330, 0x3FDAAAAAA0000000
  %6334 = call float @dx.op.unary.f32(i32 21, float %6331)  ; Exp(value)
  %6335 = call float @dx.op.unary.f32(i32 21, float %6332)  ; Exp(value)
  %6336 = call float @dx.op.unary.f32(i32 21, float %6333)  ; Exp(value)
  %6337 = fmul fast float %6334, 0x3FF0E147A0000000
  %6338 = fmul fast float %6335, 0x3FF0E147A0000000
  %6339 = fmul fast float %6336, 0x3FF0E147A0000000
  %6340 = fadd fast float %6337, 0xBFAC28F5C0000000
  %6341 = fadd fast float %6338, 0xBFAC28F5C0000000
  %6342 = fadd fast float %6339, 0xBFAC28F5C0000000
  %6343 = fsub fast float %6322, %6340
  %6344 = fsub fast float %6323, %6341
  %6345 = fsub fast float %6324, %6342
  %6346 = fmul fast float %6343, %6319
  %6347 = fmul fast float %6344, %6320
  %6348 = fmul fast float %6345, %6321
  %6349 = fadd fast float %6346, %6340
  %6350 = fadd fast float %6347, %6341
  %6351 = fadd fast float %6348, %6342
  br label %6352

; <label>:6352                                    ; preds = %6312, %4840
  %6353 = phi float [ %4835, %4840 ], [ %6349, %6312 ]
  %6354 = phi float [ %4836, %4840 ], [ %6350, %6312 ]
  %6355 = phi float [ %4837, %4840 ], [ %6351, %6312 ]
  %6356 = phi float [ %4841, %4840 ], [ %4838, %6312 ]
  %6357 = fcmp fast ogt float %6353, 0x3FA4B5DCC0000000
  %6358 = fcmp fast ogt float %6354, 0x3FA4B5DCC0000000
  %6359 = fcmp fast ogt float %6355, 0x3FA4B5DCC0000000
  %6360 = select i1 %6357, float 0.000000e+00, float 1.000000e+00
  %6361 = select i1 %6358, float 0.000000e+00, float 1.000000e+00
  %6362 = select i1 %6359, float 0.000000e+00, float 1.000000e+00
  %6363 = fmul fast float %6353, 0x3FB3D07220000000
  %6364 = fmul fast float %6354, 0x3FB3D07220000000
  %6365 = fmul fast float %6355, 0x3FB3D07220000000
  %6366 = fadd fast float %6353, 0x3FAC28F5C0000000
  %6367 = fadd fast float %6354, 0x3FAC28F5C0000000
  %6368 = fadd fast float %6355, 0x3FAC28F5C0000000
  %6369 = fmul fast float %6366, 0x3FEE54EDE0000000
  %6370 = fmul fast float %6367, 0x3FEE54EDE0000000
  %6371 = fmul fast float %6368, 0x3FEE54EDE0000000
  %6372 = call float @dx.op.unary.f32(i32 23, float %6369)  ; Log(value)
  %6373 = call float @dx.op.unary.f32(i32 23, float %6370)  ; Log(value)
  %6374 = call float @dx.op.unary.f32(i32 23, float %6371)  ; Log(value)
  %6375 = fmul fast float %6372, 0x4003333340000000
  %6376 = fmul fast float %6373, 0x4003333340000000
  %6377 = fmul fast float %6374, 0x4003333340000000
  %6378 = call float @dx.op.unary.f32(i32 21, float %6375)  ; Exp(value)
  %6379 = call float @dx.op.unary.f32(i32 21, float %6376)  ; Exp(value)
  %6380 = call float @dx.op.unary.f32(i32 21, float %6377)  ; Exp(value)
  %6381 = fsub fast float %6363, %6378
  %6382 = fsub fast float %6364, %6379
  %6383 = fsub fast float %6365, %6380
  %6384 = fmul fast float %6381, %6360
  %6385 = fmul fast float %6382, %6361
  %6386 = fmul fast float %6383, %6362
  %6387 = fadd fast float %6384, %6378
  %6388 = fadd fast float %6385, %6379
  %6389 = fadd fast float %6386, %6380
  %6390 = fmul fast float %1719, %162
  %6391 = fmul fast float %1720, %162
  %6392 = fmul fast float %1721, %162
  %6393 = fmul fast float %3275, %163
  %6394 = fmul fast float %3276, %163
  %6395 = fmul fast float %3277, %163
  %6396 = fadd fast float %6393, %6390
  %6397 = fadd fast float %6394, %6391
  %6398 = fadd fast float %6395, %6392
  %6399 = fmul fast float %4831, %164
  %6400 = fmul fast float %4832, %164
  %6401 = fmul fast float %4833, %164
  %6402 = fadd fast float %6396, %6399
  %6403 = fadd fast float %6397, %6400
  %6404 = fadd fast float %6398, %6401
  %6405 = fmul fast float %6387, %165
  %6406 = fmul fast float %6388, %165
  %6407 = fmul fast float %6389, %165
  %6408 = fadd fast float %6402, %6405
  %6409 = fadd fast float %6403, %6406
  %6410 = fadd fast float %6404, %6407
  %6411 = fcmp fast ogt float %6408, 0x3F69A5C380000000
  %6412 = fcmp fast ogt float %6409, 0x3F69A5C380000000
  %6413 = fcmp fast ogt float %6410, 0x3F69A5C380000000
  %6414 = select i1 %6411, float 0.000000e+00, float 1.000000e+00
  %6415 = select i1 %6412, float 0.000000e+00, float 1.000000e+00
  %6416 = select i1 %6413, float 0.000000e+00, float 1.000000e+00
  %6417 = fmul fast float %6408, 0x4029D70A40000000
  %6418 = fmul fast float %6409, 0x4029D70A40000000
  %6419 = fmul fast float %6410, 0x4029D70A40000000
  %6420 = call float @dx.op.binary.f32(i32 35, float %6408, float 0.000000e+00)  ; FMax(a,b)
  %6421 = call float @dx.op.binary.f32(i32 35, float %6409, float 0.000000e+00)  ; FMax(a,b)
  %6422 = call float @dx.op.binary.f32(i32 35, float %6410, float 0.000000e+00)  ; FMax(a,b)
  %6423 = call float @dx.op.unary.f32(i32 23, float %6420)  ; Log(value)
  %6424 = call float @dx.op.unary.f32(i32 23, float %6421)  ; Log(value)
  %6425 = call float @dx.op.unary.f32(i32 23, float %6422)  ; Log(value)
  %6426 = fmul fast float %6423, 0x3FDAAAAAA0000000
  %6427 = fmul fast float %6424, 0x3FDAAAAAA0000000
  %6428 = fmul fast float %6425, 0x3FDAAAAAA0000000
  %6429 = call float @dx.op.unary.f32(i32 21, float %6426)  ; Exp(value)
  %6430 = call float @dx.op.unary.f32(i32 21, float %6427)  ; Exp(value)
  %6431 = call float @dx.op.unary.f32(i32 21, float %6428)  ; Exp(value)
  %6432 = fmul fast float %6429, 0x3FF0E147A0000000
  %6433 = fmul fast float %6430, 0x3FF0E147A0000000
  %6434 = fmul fast float %6431, 0x3FF0E147A0000000
  %6435 = fadd fast float %6432, 0xBFAC28F5C0000000
  %6436 = fadd fast float %6433, 0xBFAC28F5C0000000
  %6437 = fadd fast float %6434, 0xBFAC28F5C0000000
  %6438 = fsub fast float %6417, %6435
  %6439 = fsub fast float %6418, %6436
  %6440 = fsub fast float %6419, %6437
  %6441 = fmul fast float %6438, %6414
  %6442 = fmul fast float %6439, %6415
  %6443 = fmul fast float %6440, %6416
  %6444 = fadd fast float %6441, %6435
  %6445 = fadd fast float %6442, %6436
  %6446 = fadd fast float %6443, %6437
  %6447 = call float @dx.op.dot4.f32(i32 56, float %1688, float %3244, float %4800, float %6356, float %162, float %163, float %164, float %165)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %6444)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %6445)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %6446)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %6447)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %80)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare i1 @dx.op.isSpecialFloat.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !38, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, !37}
!36 = !{i32 9}
!37 = !{i32 3, i32 6}
!38 = !{!39, !40}
!39 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
!40 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !41}
!41 = !{i32 3, i32 1}
