;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float    yz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: f772c6b613413939d09b0a739948f3cc
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %40 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %41 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %42 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %43 = extractvalue %dx.types.Dimensions %42, 0
  %44 = extractvalue %dx.types.Dimensions %42, 1
  %45 = uitofp i32 %43 to float
  %46 = uitofp i32 %44 to float
  %47 = fmul fast float %45, %40
  %48 = fmul fast float %46, %41
  %49 = fdiv fast float %47, %3
  %50 = fdiv fast float %48, %4
  %51 = fadd fast float %49, -5.000000e-01
  %52 = fadd fast float %50, -5.000000e-01
  %53 = call float @dx.op.unary.f32(i32 27, float %51)  ; Round_ni(value)
  %54 = call float @dx.op.unary.f32(i32 27, float %52)  ; Round_ni(value)
  %55 = fptosi float %53 to i32
  %56 = fptosi float %54 to i32
  %57 = call float @dx.op.unary.f32(i32 22, float %51)  ; Frc(value)
  %58 = call float @dx.op.unary.f32(i32 22, float %52)  ; Frc(value)
  %59 = add i32 %43, -1
  %60 = add i32 %44, -1
  %61 = call i32 @dx.op.binary.i32(i32 37, i32 %55, i32 0)  ; IMax(a,b)
  %62 = call i32 @dx.op.binary.i32(i32 37, i32 %56, i32 0)  ; IMax(a,b)
  %63 = call i32 @dx.op.binary.i32(i32 38, i32 %61, i32 %59)  ; IMin(a,b)
  %64 = call i32 @dx.op.binary.i32(i32 38, i32 %62, i32 %60)  ; IMin(a,b)
  %65 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %66 = extractvalue %dx.types.ResRet.f32 %65, 0
  %67 = extractvalue %dx.types.ResRet.f32 %65, 1
  %68 = extractvalue %dx.types.ResRet.f32 %65, 2
  %69 = extractvalue %dx.types.ResRet.f32 %65, 3
  %70 = fcmp fast olt float %69, 0.000000e+00
  br i1 %70, label %71, label %73

; <label>:71                                      ; preds = %0
  %72 = fsub fast float -1.000000e+00, %69
  br label %1218

; <label>:73                                      ; preds = %0
  %74 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %75 = extractvalue %dx.types.ResRet.f32 %74, 0
  %76 = fcmp fast ogt float %38, 5.000000e-01
  %77 = fcmp fast olt float %75, 1.000000e+00
  %78 = and i1 %76, %77
  br i1 %78, label %79, label %165

; <label>:79                                      ; preds = %73
  %80 = sitofp i32 %63 to float
  %81 = sitofp i32 %64 to float
  %82 = fadd fast float %80, 5.000000e-01
  %83 = fadd fast float %81, 5.000000e-01
  %84 = fdiv fast float %82, %45
  %85 = fdiv fast float %83, %46
  %86 = fmul fast float %84, 2.000000e+00
  %87 = fmul fast float %85, 2.000000e+00
  %88 = fadd fast float %86, -1.000000e+00
  %89 = fsub fast float 1.000000e+00, %87
  %90 = fmul fast float %88, %35
  %91 = call float @dx.op.tertiary.f32(i32 46, float %89, float %31, float %90)  ; FMad(a,b,c)
  %92 = call float @dx.op.tertiary.f32(i32 46, float %75, float %27, float %91)  ; FMad(a,b,c)
  %93 = fadd fast float %92, %23
  %94 = call float @dx.op.unary.f32(i32 6, float %93)  ; FAbs(value)
  %95 = fcmp fast ogt float %94, 0x3EB0C6F7A0000000
  br i1 %95, label %96, label %165

; <label>:96                                      ; preds = %79
  %97 = fmul fast float %88, %34
  %98 = call float @dx.op.tertiary.f32(i32 46, float %89, float %30, float %97)  ; FMad(a,b,c)
  %99 = call float @dx.op.tertiary.f32(i32 46, float %75, float %26, float %98)  ; FMad(a,b,c)
  %100 = fadd fast float %99, %22
  %101 = fmul fast float %88, %33
  %102 = call float @dx.op.tertiary.f32(i32 46, float %89, float %29, float %101)  ; FMad(a,b,c)
  %103 = call float @dx.op.tertiary.f32(i32 46, float %75, float %25, float %102)  ; FMad(a,b,c)
  %104 = fadd fast float %103, %21
  %105 = fmul fast float %88, %32
  %106 = call float @dx.op.tertiary.f32(i32 46, float %89, float %28, float %105)  ; FMad(a,b,c)
  %107 = call float @dx.op.tertiary.f32(i32 46, float %75, float %24, float %106)  ; FMad(a,b,c)
  %108 = fadd fast float %107, %20
  %109 = fdiv fast float %108, %93
  %110 = fdiv fast float %104, %93
  %111 = fdiv fast float %100, %93
  %112 = fsub fast float %109, %17
  %113 = fsub fast float %110, %18
  %114 = fsub fast float %111, %19
  %115 = fmul fast float %112, %112
  %116 = fmul fast float %113, %113
  %117 = fadd fast float %116, %115
  %118 = fmul fast float %114, %114
  %119 = fadd fast float %117, %118
  %120 = call float @dx.op.unary.f32(i32 24, float %119)  ; Sqrt(value)
  %121 = fsub fast float %120, %9
  %122 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %121)  ; FMax(a,b)
  %123 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %123, label %124, label %147

; <label>:124                                     ; preds = %96
  %125 = call float @dx.op.unary.f32(i32 6, float %113)  ; FAbs(value)
  %126 = fmul fast float %125, %11
  %127 = fcmp fast olt float %126, 0x3F50624DE0000000
  br i1 %127, label %128, label %131

; <label>:128                                     ; preds = %124
  %129 = fmul fast float %126, 5.000000e-01
  %130 = fsub fast float 1.000000e+00, %129
  br label %136

; <label>:131                                     ; preds = %124
  %132 = fmul fast float %126, 0xBFF7154760000000
  %133 = call float @dx.op.unary.f32(i32 21, float %132)  ; Exp(value)
  %134 = fsub fast float 1.000000e+00, %133
  %135 = fdiv fast float %134, %126
  br label %136

; <label>:136                                     ; preds = %131, %128
  %137 = phi float [ %130, %128 ], [ %135, %131 ]
  %138 = call float @dx.op.binary.f32(i32 36, float %110, float %18)  ; FMin(a,b)
  %139 = fsub fast float %138, %10
  %140 = fmul fast float %11, %139
  %141 = fsub fast float -0.000000e+00, %140
  %142 = call float @dx.op.binary.f32(i32 35, float %141, float -4.000000e+01)  ; FMax(a,b)
  %143 = call float @dx.op.binary.f32(i32 36, float %142, float 5.000000e+00)  ; FMin(a,b)
  %144 = fmul fast float %143, 0x3FF7154760000000
  %145 = call float @dx.op.unary.f32(i32 21, float %144)  ; Exp(value)
  %146 = fmul fast float %145, %137
  br label %147

; <label>:147                                     ; preds = %136, %96
  %148 = phi float [ %146, %136 ], [ 1.000000e+00, %96 ]
  %149 = fmul fast float %122, %16
  %150 = fmul fast float %149, %148
  %151 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %150)  ; FMin(a,b)
  %152 = fmul fast float %151, 0xBFF7154760000000
  %153 = call float @dx.op.unary.f32(i32 21, float %152)  ; Exp(value)
  %154 = fsub fast float 1.000000e+00, %153
  %155 = call float @dx.op.binary.f32(i32 36, float %12, float %154)  ; FMin(a,b)
  %156 = fsub fast float %13, %66
  %157 = fsub fast float %14, %67
  %158 = fsub fast float %15, %68
  %159 = fmul fast float %155, %156
  %160 = fmul fast float %155, %157
  %161 = fmul fast float %155, %158
  %162 = fadd fast float %159, %66
  %163 = fadd fast float %160, %67
  %164 = fadd fast float %161, %68
  br label %165

; <label>:165                                     ; preds = %147, %79, %73
  %166 = phi float [ %162, %147 ], [ %66, %79 ], [ %66, %73 ]
  %167 = phi float [ %163, %147 ], [ %67, %79 ], [ %67, %73 ]
  %168 = phi float [ %164, %147 ], [ %68, %79 ], [ %68, %73 ]
  %169 = fadd fast float %5, 1.000000e+00
  %170 = fadd fast float %6, 1.000000e+00
  %171 = fsub fast float 1.000000e+00, %5
  %172 = fmul fast float %36, %169
  %173 = fmul fast float %36, %170
  %174 = fmul fast float %36, %171
  %175 = fmul fast float %172, %166
  %176 = fmul fast float %173, %167
  %177 = fmul fast float %174, %168
  %178 = fcmp fast ult float %37, 5.000000e-01
  br i1 %178, label %204, label %179

; <label>:179                                     ; preds = %165
  %180 = fmul fast float %175, 0x4004147AE0000000
  %181 = fmul fast float %176, 0x4004147AE0000000
  %182 = fmul fast float %177, 0x4004147AE0000000
  %183 = fadd fast float %180, 0x3F9EB851E0000000
  %184 = fadd fast float %181, 0x3F9EB851E0000000
  %185 = fadd fast float %182, 0x3F9EB851E0000000
  %186 = fmul fast float %183, %175
  %187 = fmul fast float %184, %176
  %188 = fmul fast float %185, %177
  %189 = fmul fast float %175, 0x400370A3E0000000
  %190 = fmul fast float %176, 0x400370A3E0000000
  %191 = fmul fast float %177, 0x400370A3E0000000
  %192 = fadd fast float %189, 0x3FE2E147A0000000
  %193 = fadd fast float %190, 0x3FE2E147A0000000
  %194 = fadd fast float %191, 0x3FE2E147A0000000
  %195 = fmul fast float %192, %175
  %196 = fmul fast float %193, %176
  %197 = fmul fast float %194, %177
  %198 = fadd fast float %195, 0x3FC1EB8520000000
  %199 = fadd fast float %196, 0x3FC1EB8520000000
  %200 = fadd fast float %197, 0x3FC1EB8520000000
  %201 = fdiv fast float %186, %198
  %202 = fdiv fast float %187, %199
  %203 = fdiv fast float %188, %200
  br label %204

; <label>:204                                     ; preds = %179, %165
  %205 = phi float [ %201, %179 ], [ %175, %165 ]
  %206 = phi float [ %202, %179 ], [ %176, %165 ]
  %207 = phi float [ %203, %179 ], [ %177, %165 ]
  %208 = call float @dx.op.unary.f32(i32 7, float %205)  ; Saturate(value)
  %209 = call float @dx.op.unary.f32(i32 7, float %206)  ; Saturate(value)
  %210 = call float @dx.op.unary.f32(i32 7, float %207)  ; Saturate(value)
  %211 = call float @dx.op.dot3.f32(i32 55, float %208, float %209, float %210, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %212 = fsub fast float %208, %211
  %213 = fsub fast float %209, %211
  %214 = fsub fast float %210, %211
  %215 = fmul fast float %212, %8
  %216 = fmul fast float %213, %8
  %217 = fmul fast float %214, %8
  %218 = fadd fast float %215, %211
  %219 = fadd fast float %216, %211
  %220 = fadd fast float %217, %211
  %221 = call float @dx.op.unary.f32(i32 7, float %218)  ; Saturate(value)
  %222 = call float @dx.op.unary.f32(i32 7, float %219)  ; Saturate(value)
  %223 = call float @dx.op.unary.f32(i32 7, float %220)  ; Saturate(value)
  %224 = fadd fast float %221, 0xBFC70A3D80000000
  %225 = fadd fast float %222, 0xBFC70A3D80000000
  %226 = fadd fast float %223, 0xBFC70A3D80000000
  %227 = fmul fast float %224, %7
  %228 = fmul fast float %225, %7
  %229 = fmul fast float %226, %7
  %230 = fadd fast float %227, 0x3FC70A3D80000000
  %231 = fadd fast float %228, 0x3FC70A3D80000000
  %232 = fadd fast float %229, 0x3FC70A3D80000000
  %233 = call float @dx.op.unary.f32(i32 7, float %230)  ; Saturate(value)
  %234 = call float @dx.op.unary.f32(i32 7, float %231)  ; Saturate(value)
  %235 = call float @dx.op.unary.f32(i32 7, float %232)  ; Saturate(value)
  %236 = add i32 %64, -1
  %237 = call i32 @dx.op.binary.i32(i32 37, i32 %63, i32 0)  ; IMax(a,b)
  %238 = call i32 @dx.op.binary.i32(i32 37, i32 %236, i32 0)  ; IMax(a,b)
  %239 = call i32 @dx.op.binary.i32(i32 38, i32 %237, i32 %59)  ; IMin(a,b)
  %240 = call i32 @dx.op.binary.i32(i32 38, i32 %238, i32 %60)  ; IMin(a,b)
  %241 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %239, i32 %240, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %242 = extractvalue %dx.types.ResRet.f32 %241, 0
  %243 = extractvalue %dx.types.ResRet.f32 %241, 1
  %244 = extractvalue %dx.types.ResRet.f32 %241, 2
  %245 = extractvalue %dx.types.ResRet.f32 %241, 3
  %246 = fcmp fast olt float %245, 0.000000e+00
  br i1 %246, label %247, label %281

; <label>:247                                     ; preds = %204
  %248 = fcmp fast ogt float %242, 0x3FA4B5DCC0000000
  %249 = fcmp fast ogt float %243, 0x3FA4B5DCC0000000
  %250 = fcmp fast ogt float %244, 0x3FA4B5DCC0000000
  %251 = select i1 %248, float 0.000000e+00, float 1.000000e+00
  %252 = select i1 %249, float 0.000000e+00, float 1.000000e+00
  %253 = select i1 %250, float 0.000000e+00, float 1.000000e+00
  %254 = fmul fast float %242, 0x3FB3D07220000000
  %255 = fmul fast float %243, 0x3FB3D07220000000
  %256 = fmul fast float %244, 0x3FB3D07220000000
  %257 = fadd fast float %242, 0x3FAC28F5C0000000
  %258 = fadd fast float %243, 0x3FAC28F5C0000000
  %259 = fadd fast float %244, 0x3FAC28F5C0000000
  %260 = fmul fast float %257, 0x3FEE54EDE0000000
  %261 = fmul fast float %258, 0x3FEE54EDE0000000
  %262 = fmul fast float %259, 0x3FEE54EDE0000000
  %263 = call float @dx.op.unary.f32(i32 23, float %260)  ; Log(value)
  %264 = call float @dx.op.unary.f32(i32 23, float %261)  ; Log(value)
  %265 = call float @dx.op.unary.f32(i32 23, float %262)  ; Log(value)
  %266 = fmul fast float %263, 0x4003333340000000
  %267 = fmul fast float %264, 0x4003333340000000
  %268 = fmul fast float %265, 0x4003333340000000
  %269 = call float @dx.op.unary.f32(i32 21, float %266)  ; Exp(value)
  %270 = call float @dx.op.unary.f32(i32 21, float %267)  ; Exp(value)
  %271 = call float @dx.op.unary.f32(i32 21, float %268)  ; Exp(value)
  %272 = fsub fast float %254, %269
  %273 = fsub fast float %255, %270
  %274 = fsub fast float %256, %271
  %275 = fmul fast float %272, %251
  %276 = fmul fast float %273, %252
  %277 = fmul fast float %274, %253
  %278 = fadd fast float %275, %269
  %279 = fadd fast float %276, %270
  %280 = fadd fast float %277, %271
  br label %444

; <label>:281                                     ; preds = %204
  %282 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %239, i32 %240, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %283 = extractvalue %dx.types.ResRet.f32 %282, 0
  %284 = fcmp fast ogt float %38, 5.000000e-01
  %285 = fcmp fast olt float %283, 1.000000e+00
  %286 = and i1 %284, %285
  br i1 %286, label %287, label %373

; <label>:287                                     ; preds = %281
  %288 = sitofp i32 %239 to float
  %289 = sitofp i32 %240 to float
  %290 = fadd fast float %288, 5.000000e-01
  %291 = fadd fast float %289, 5.000000e-01
  %292 = fdiv fast float %290, %45
  %293 = fdiv fast float %291, %46
  %294 = fmul fast float %292, 2.000000e+00
  %295 = fmul fast float %293, 2.000000e+00
  %296 = fadd fast float %294, -1.000000e+00
  %297 = fsub fast float 1.000000e+00, %295
  %298 = fmul fast float %296, %35
  %299 = call float @dx.op.tertiary.f32(i32 46, float %297, float %31, float %298)  ; FMad(a,b,c)
  %300 = call float @dx.op.tertiary.f32(i32 46, float %283, float %27, float %299)  ; FMad(a,b,c)
  %301 = fadd fast float %300, %23
  %302 = call float @dx.op.unary.f32(i32 6, float %301)  ; FAbs(value)
  %303 = fcmp fast ogt float %302, 0x3EB0C6F7A0000000
  br i1 %303, label %304, label %373

; <label>:304                                     ; preds = %287
  %305 = fmul fast float %296, %34
  %306 = call float @dx.op.tertiary.f32(i32 46, float %297, float %30, float %305)  ; FMad(a,b,c)
  %307 = call float @dx.op.tertiary.f32(i32 46, float %283, float %26, float %306)  ; FMad(a,b,c)
  %308 = fadd fast float %307, %22
  %309 = fmul fast float %296, %33
  %310 = call float @dx.op.tertiary.f32(i32 46, float %297, float %29, float %309)  ; FMad(a,b,c)
  %311 = call float @dx.op.tertiary.f32(i32 46, float %283, float %25, float %310)  ; FMad(a,b,c)
  %312 = fadd fast float %311, %21
  %313 = fmul fast float %296, %32
  %314 = call float @dx.op.tertiary.f32(i32 46, float %297, float %28, float %313)  ; FMad(a,b,c)
  %315 = call float @dx.op.tertiary.f32(i32 46, float %283, float %24, float %314)  ; FMad(a,b,c)
  %316 = fadd fast float %315, %20
  %317 = fdiv fast float %316, %301
  %318 = fdiv fast float %312, %301
  %319 = fdiv fast float %308, %301
  %320 = fsub fast float %317, %17
  %321 = fsub fast float %318, %18
  %322 = fsub fast float %319, %19
  %323 = fmul fast float %320, %320
  %324 = fmul fast float %321, %321
  %325 = fadd fast float %324, %323
  %326 = fmul fast float %322, %322
  %327 = fadd fast float %325, %326
  %328 = call float @dx.op.unary.f32(i32 24, float %327)  ; Sqrt(value)
  %329 = fsub fast float %328, %9
  %330 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %329)  ; FMax(a,b)
  %331 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %331, label %332, label %355

; <label>:332                                     ; preds = %304
  %333 = call float @dx.op.unary.f32(i32 6, float %321)  ; FAbs(value)
  %334 = fmul fast float %333, %11
  %335 = fcmp fast olt float %334, 0x3F50624DE0000000
  br i1 %335, label %336, label %339

; <label>:336                                     ; preds = %332
  %337 = fmul fast float %334, 5.000000e-01
  %338 = fsub fast float 1.000000e+00, %337
  br label %344

; <label>:339                                     ; preds = %332
  %340 = fmul fast float %334, 0xBFF7154760000000
  %341 = call float @dx.op.unary.f32(i32 21, float %340)  ; Exp(value)
  %342 = fsub fast float 1.000000e+00, %341
  %343 = fdiv fast float %342, %334
  br label %344

; <label>:344                                     ; preds = %339, %336
  %345 = phi float [ %338, %336 ], [ %343, %339 ]
  %346 = call float @dx.op.binary.f32(i32 36, float %318, float %18)  ; FMin(a,b)
  %347 = fsub fast float %346, %10
  %348 = fmul fast float %11, %347
  %349 = fsub fast float -0.000000e+00, %348
  %350 = call float @dx.op.binary.f32(i32 35, float %349, float -4.000000e+01)  ; FMax(a,b)
  %351 = call float @dx.op.binary.f32(i32 36, float %350, float 5.000000e+00)  ; FMin(a,b)
  %352 = fmul fast float %351, 0x3FF7154760000000
  %353 = call float @dx.op.unary.f32(i32 21, float %352)  ; Exp(value)
  %354 = fmul fast float %353, %345
  br label %355

; <label>:355                                     ; preds = %344, %304
  %356 = phi float [ %354, %344 ], [ 1.000000e+00, %304 ]
  %357 = fmul fast float %330, %16
  %358 = fmul fast float %357, %356
  %359 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %358)  ; FMin(a,b)
  %360 = fmul fast float %359, 0xBFF7154760000000
  %361 = call float @dx.op.unary.f32(i32 21, float %360)  ; Exp(value)
  %362 = fsub fast float 1.000000e+00, %361
  %363 = call float @dx.op.binary.f32(i32 36, float %12, float %362)  ; FMin(a,b)
  %364 = fsub fast float %13, %242
  %365 = fsub fast float %14, %243
  %366 = fsub fast float %15, %244
  %367 = fmul fast float %363, %364
  %368 = fmul fast float %363, %365
  %369 = fmul fast float %363, %366
  %370 = fadd fast float %367, %242
  %371 = fadd fast float %368, %243
  %372 = fadd fast float %369, %244
  br label %373

; <label>:373                                     ; preds = %355, %287, %281
  %374 = phi float [ %370, %355 ], [ %242, %287 ], [ %242, %281 ]
  %375 = phi float [ %371, %355 ], [ %243, %287 ], [ %243, %281 ]
  %376 = phi float [ %372, %355 ], [ %244, %287 ], [ %244, %281 ]
  %377 = fadd fast float %5, 1.000000e+00
  %378 = fadd fast float %6, 1.000000e+00
  %379 = fsub fast float 1.000000e+00, %5
  %380 = fmul fast float %36, %377
  %381 = fmul fast float %36, %378
  %382 = fmul fast float %36, %379
  %383 = fmul fast float %380, %374
  %384 = fmul fast float %381, %375
  %385 = fmul fast float %382, %376
  %386 = fcmp fast ult float %37, 5.000000e-01
  br i1 %386, label %412, label %387

; <label>:387                                     ; preds = %373
  %388 = fmul fast float %383, 0x4004147AE0000000
  %389 = fmul fast float %384, 0x4004147AE0000000
  %390 = fmul fast float %385, 0x4004147AE0000000
  %391 = fadd fast float %388, 0x3F9EB851E0000000
  %392 = fadd fast float %389, 0x3F9EB851E0000000
  %393 = fadd fast float %390, 0x3F9EB851E0000000
  %394 = fmul fast float %391, %383
  %395 = fmul fast float %392, %384
  %396 = fmul fast float %393, %385
  %397 = fmul fast float %383, 0x400370A3E0000000
  %398 = fmul fast float %384, 0x400370A3E0000000
  %399 = fmul fast float %385, 0x400370A3E0000000
  %400 = fadd fast float %397, 0x3FE2E147A0000000
  %401 = fadd fast float %398, 0x3FE2E147A0000000
  %402 = fadd fast float %399, 0x3FE2E147A0000000
  %403 = fmul fast float %400, %383
  %404 = fmul fast float %401, %384
  %405 = fmul fast float %402, %385
  %406 = fadd fast float %403, 0x3FC1EB8520000000
  %407 = fadd fast float %404, 0x3FC1EB8520000000
  %408 = fadd fast float %405, 0x3FC1EB8520000000
  %409 = fdiv fast float %394, %406
  %410 = fdiv fast float %395, %407
  %411 = fdiv fast float %396, %408
  br label %412

; <label>:412                                     ; preds = %387, %373
  %413 = phi float [ %409, %387 ], [ %383, %373 ]
  %414 = phi float [ %410, %387 ], [ %384, %373 ]
  %415 = phi float [ %411, %387 ], [ %385, %373 ]
  %416 = call float @dx.op.unary.f32(i32 7, float %413)  ; Saturate(value)
  %417 = call float @dx.op.unary.f32(i32 7, float %414)  ; Saturate(value)
  %418 = call float @dx.op.unary.f32(i32 7, float %415)  ; Saturate(value)
  %419 = call float @dx.op.dot3.f32(i32 55, float %416, float %417, float %418, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %420 = fsub fast float %416, %419
  %421 = fsub fast float %417, %419
  %422 = fsub fast float %418, %419
  %423 = fmul fast float %420, %8
  %424 = fmul fast float %421, %8
  %425 = fmul fast float %422, %8
  %426 = fadd fast float %423, %419
  %427 = fadd fast float %424, %419
  %428 = fadd fast float %425, %419
  %429 = call float @dx.op.unary.f32(i32 7, float %426)  ; Saturate(value)
  %430 = call float @dx.op.unary.f32(i32 7, float %427)  ; Saturate(value)
  %431 = call float @dx.op.unary.f32(i32 7, float %428)  ; Saturate(value)
  %432 = fadd fast float %429, 0xBFC70A3D80000000
  %433 = fadd fast float %430, 0xBFC70A3D80000000
  %434 = fadd fast float %431, 0xBFC70A3D80000000
  %435 = fmul fast float %432, %7
  %436 = fmul fast float %433, %7
  %437 = fmul fast float %434, %7
  %438 = fadd fast float %435, 0x3FC70A3D80000000
  %439 = fadd fast float %436, 0x3FC70A3D80000000
  %440 = fadd fast float %437, 0x3FC70A3D80000000
  %441 = call float @dx.op.unary.f32(i32 7, float %438)  ; Saturate(value)
  %442 = call float @dx.op.unary.f32(i32 7, float %439)  ; Saturate(value)
  %443 = call float @dx.op.unary.f32(i32 7, float %440)  ; Saturate(value)
  br label %444

; <label>:444                                     ; preds = %412, %247
  %445 = phi float [ %278, %247 ], [ %441, %412 ]
  %446 = phi float [ %279, %247 ], [ %442, %412 ]
  %447 = phi float [ %280, %247 ], [ %443, %412 ]
  %448 = add i32 %64, 1
  %449 = call i32 @dx.op.binary.i32(i32 37, i32 %448, i32 0)  ; IMax(a,b)
  %450 = call i32 @dx.op.binary.i32(i32 38, i32 %449, i32 %60)  ; IMin(a,b)
  %451 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %239, i32 %450, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %452 = extractvalue %dx.types.ResRet.f32 %451, 0
  %453 = extractvalue %dx.types.ResRet.f32 %451, 1
  %454 = extractvalue %dx.types.ResRet.f32 %451, 2
  %455 = extractvalue %dx.types.ResRet.f32 %451, 3
  %456 = fcmp fast olt float %455, 0.000000e+00
  br i1 %456, label %457, label %491

; <label>:457                                     ; preds = %444
  %458 = fcmp fast ogt float %452, 0x3FA4B5DCC0000000
  %459 = fcmp fast ogt float %453, 0x3FA4B5DCC0000000
  %460 = fcmp fast ogt float %454, 0x3FA4B5DCC0000000
  %461 = select i1 %458, float 0.000000e+00, float 1.000000e+00
  %462 = select i1 %459, float 0.000000e+00, float 1.000000e+00
  %463 = select i1 %460, float 0.000000e+00, float 1.000000e+00
  %464 = fmul fast float %452, 0x3FB3D07220000000
  %465 = fmul fast float %453, 0x3FB3D07220000000
  %466 = fmul fast float %454, 0x3FB3D07220000000
  %467 = fadd fast float %452, 0x3FAC28F5C0000000
  %468 = fadd fast float %453, 0x3FAC28F5C0000000
  %469 = fadd fast float %454, 0x3FAC28F5C0000000
  %470 = fmul fast float %467, 0x3FEE54EDE0000000
  %471 = fmul fast float %468, 0x3FEE54EDE0000000
  %472 = fmul fast float %469, 0x3FEE54EDE0000000
  %473 = call float @dx.op.unary.f32(i32 23, float %470)  ; Log(value)
  %474 = call float @dx.op.unary.f32(i32 23, float %471)  ; Log(value)
  %475 = call float @dx.op.unary.f32(i32 23, float %472)  ; Log(value)
  %476 = fmul fast float %473, 0x4003333340000000
  %477 = fmul fast float %474, 0x4003333340000000
  %478 = fmul fast float %475, 0x4003333340000000
  %479 = call float @dx.op.unary.f32(i32 21, float %476)  ; Exp(value)
  %480 = call float @dx.op.unary.f32(i32 21, float %477)  ; Exp(value)
  %481 = call float @dx.op.unary.f32(i32 21, float %478)  ; Exp(value)
  %482 = fsub fast float %464, %479
  %483 = fsub fast float %465, %480
  %484 = fsub fast float %466, %481
  %485 = fmul fast float %482, %461
  %486 = fmul fast float %483, %462
  %487 = fmul fast float %484, %463
  %488 = fadd fast float %485, %479
  %489 = fadd fast float %486, %480
  %490 = fadd fast float %487, %481
  br label %654

; <label>:491                                     ; preds = %444
  %492 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %239, i32 %450, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %493 = extractvalue %dx.types.ResRet.f32 %492, 0
  %494 = fcmp fast ogt float %38, 5.000000e-01
  %495 = fcmp fast olt float %493, 1.000000e+00
  %496 = and i1 %494, %495
  br i1 %496, label %497, label %583

; <label>:497                                     ; preds = %491
  %498 = sitofp i32 %239 to float
  %499 = sitofp i32 %450 to float
  %500 = fadd fast float %498, 5.000000e-01
  %501 = fadd fast float %499, 5.000000e-01
  %502 = fdiv fast float %500, %45
  %503 = fdiv fast float %501, %46
  %504 = fmul fast float %502, 2.000000e+00
  %505 = fmul fast float %503, 2.000000e+00
  %506 = fadd fast float %504, -1.000000e+00
  %507 = fsub fast float 1.000000e+00, %505
  %508 = fmul fast float %506, %35
  %509 = call float @dx.op.tertiary.f32(i32 46, float %507, float %31, float %508)  ; FMad(a,b,c)
  %510 = call float @dx.op.tertiary.f32(i32 46, float %493, float %27, float %509)  ; FMad(a,b,c)
  %511 = fadd fast float %510, %23
  %512 = call float @dx.op.unary.f32(i32 6, float %511)  ; FAbs(value)
  %513 = fcmp fast ogt float %512, 0x3EB0C6F7A0000000
  br i1 %513, label %514, label %583

; <label>:514                                     ; preds = %497
  %515 = fmul fast float %506, %34
  %516 = call float @dx.op.tertiary.f32(i32 46, float %507, float %30, float %515)  ; FMad(a,b,c)
  %517 = call float @dx.op.tertiary.f32(i32 46, float %493, float %26, float %516)  ; FMad(a,b,c)
  %518 = fadd fast float %517, %22
  %519 = fmul fast float %506, %33
  %520 = call float @dx.op.tertiary.f32(i32 46, float %507, float %29, float %519)  ; FMad(a,b,c)
  %521 = call float @dx.op.tertiary.f32(i32 46, float %493, float %25, float %520)  ; FMad(a,b,c)
  %522 = fadd fast float %521, %21
  %523 = fmul fast float %506, %32
  %524 = call float @dx.op.tertiary.f32(i32 46, float %507, float %28, float %523)  ; FMad(a,b,c)
  %525 = call float @dx.op.tertiary.f32(i32 46, float %493, float %24, float %524)  ; FMad(a,b,c)
  %526 = fadd fast float %525, %20
  %527 = fdiv fast float %526, %511
  %528 = fdiv fast float %522, %511
  %529 = fdiv fast float %518, %511
  %530 = fsub fast float %527, %17
  %531 = fsub fast float %528, %18
  %532 = fsub fast float %529, %19
  %533 = fmul fast float %530, %530
  %534 = fmul fast float %531, %531
  %535 = fadd fast float %534, %533
  %536 = fmul fast float %532, %532
  %537 = fadd fast float %535, %536
  %538 = call float @dx.op.unary.f32(i32 24, float %537)  ; Sqrt(value)
  %539 = fsub fast float %538, %9
  %540 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %539)  ; FMax(a,b)
  %541 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %541, label %542, label %565

; <label>:542                                     ; preds = %514
  %543 = call float @dx.op.unary.f32(i32 6, float %531)  ; FAbs(value)
  %544 = fmul fast float %543, %11
  %545 = fcmp fast olt float %544, 0x3F50624DE0000000
  br i1 %545, label %546, label %549

; <label>:546                                     ; preds = %542
  %547 = fmul fast float %544, 5.000000e-01
  %548 = fsub fast float 1.000000e+00, %547
  br label %554

; <label>:549                                     ; preds = %542
  %550 = fmul fast float %544, 0xBFF7154760000000
  %551 = call float @dx.op.unary.f32(i32 21, float %550)  ; Exp(value)
  %552 = fsub fast float 1.000000e+00, %551
  %553 = fdiv fast float %552, %544
  br label %554

; <label>:554                                     ; preds = %549, %546
  %555 = phi float [ %548, %546 ], [ %553, %549 ]
  %556 = call float @dx.op.binary.f32(i32 36, float %528, float %18)  ; FMin(a,b)
  %557 = fsub fast float %556, %10
  %558 = fmul fast float %11, %557
  %559 = fsub fast float -0.000000e+00, %558
  %560 = call float @dx.op.binary.f32(i32 35, float %559, float -4.000000e+01)  ; FMax(a,b)
  %561 = call float @dx.op.binary.f32(i32 36, float %560, float 5.000000e+00)  ; FMin(a,b)
  %562 = fmul fast float %561, 0x3FF7154760000000
  %563 = call float @dx.op.unary.f32(i32 21, float %562)  ; Exp(value)
  %564 = fmul fast float %563, %555
  br label %565

; <label>:565                                     ; preds = %554, %514
  %566 = phi float [ %564, %554 ], [ 1.000000e+00, %514 ]
  %567 = fmul fast float %540, %16
  %568 = fmul fast float %567, %566
  %569 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %568)  ; FMin(a,b)
  %570 = fmul fast float %569, 0xBFF7154760000000
  %571 = call float @dx.op.unary.f32(i32 21, float %570)  ; Exp(value)
  %572 = fsub fast float 1.000000e+00, %571
  %573 = call float @dx.op.binary.f32(i32 36, float %12, float %572)  ; FMin(a,b)
  %574 = fsub fast float %13, %452
  %575 = fsub fast float %14, %453
  %576 = fsub fast float %15, %454
  %577 = fmul fast float %573, %574
  %578 = fmul fast float %573, %575
  %579 = fmul fast float %573, %576
  %580 = fadd fast float %577, %452
  %581 = fadd fast float %578, %453
  %582 = fadd fast float %579, %454
  br label %583

; <label>:583                                     ; preds = %565, %497, %491
  %584 = phi float [ %580, %565 ], [ %452, %497 ], [ %452, %491 ]
  %585 = phi float [ %581, %565 ], [ %453, %497 ], [ %453, %491 ]
  %586 = phi float [ %582, %565 ], [ %454, %497 ], [ %454, %491 ]
  %587 = fadd fast float %5, 1.000000e+00
  %588 = fadd fast float %6, 1.000000e+00
  %589 = fsub fast float 1.000000e+00, %5
  %590 = fmul fast float %36, %587
  %591 = fmul fast float %36, %588
  %592 = fmul fast float %36, %589
  %593 = fmul fast float %590, %584
  %594 = fmul fast float %591, %585
  %595 = fmul fast float %592, %586
  %596 = fcmp fast ult float %37, 5.000000e-01
  br i1 %596, label %622, label %597

; <label>:597                                     ; preds = %583
  %598 = fmul fast float %593, 0x4004147AE0000000
  %599 = fmul fast float %594, 0x4004147AE0000000
  %600 = fmul fast float %595, 0x4004147AE0000000
  %601 = fadd fast float %598, 0x3F9EB851E0000000
  %602 = fadd fast float %599, 0x3F9EB851E0000000
  %603 = fadd fast float %600, 0x3F9EB851E0000000
  %604 = fmul fast float %601, %593
  %605 = fmul fast float %602, %594
  %606 = fmul fast float %603, %595
  %607 = fmul fast float %593, 0x400370A3E0000000
  %608 = fmul fast float %594, 0x400370A3E0000000
  %609 = fmul fast float %595, 0x400370A3E0000000
  %610 = fadd fast float %607, 0x3FE2E147A0000000
  %611 = fadd fast float %608, 0x3FE2E147A0000000
  %612 = fadd fast float %609, 0x3FE2E147A0000000
  %613 = fmul fast float %610, %593
  %614 = fmul fast float %611, %594
  %615 = fmul fast float %612, %595
  %616 = fadd fast float %613, 0x3FC1EB8520000000
  %617 = fadd fast float %614, 0x3FC1EB8520000000
  %618 = fadd fast float %615, 0x3FC1EB8520000000
  %619 = fdiv fast float %604, %616
  %620 = fdiv fast float %605, %617
  %621 = fdiv fast float %606, %618
  br label %622

; <label>:622                                     ; preds = %597, %583
  %623 = phi float [ %619, %597 ], [ %593, %583 ]
  %624 = phi float [ %620, %597 ], [ %594, %583 ]
  %625 = phi float [ %621, %597 ], [ %595, %583 ]
  %626 = call float @dx.op.unary.f32(i32 7, float %623)  ; Saturate(value)
  %627 = call float @dx.op.unary.f32(i32 7, float %624)  ; Saturate(value)
  %628 = call float @dx.op.unary.f32(i32 7, float %625)  ; Saturate(value)
  %629 = call float @dx.op.dot3.f32(i32 55, float %626, float %627, float %628, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %630 = fsub fast float %626, %629
  %631 = fsub fast float %627, %629
  %632 = fsub fast float %628, %629
  %633 = fmul fast float %630, %8
  %634 = fmul fast float %631, %8
  %635 = fmul fast float %632, %8
  %636 = fadd fast float %633, %629
  %637 = fadd fast float %634, %629
  %638 = fadd fast float %635, %629
  %639 = call float @dx.op.unary.f32(i32 7, float %636)  ; Saturate(value)
  %640 = call float @dx.op.unary.f32(i32 7, float %637)  ; Saturate(value)
  %641 = call float @dx.op.unary.f32(i32 7, float %638)  ; Saturate(value)
  %642 = fadd fast float %639, 0xBFC70A3D80000000
  %643 = fadd fast float %640, 0xBFC70A3D80000000
  %644 = fadd fast float %641, 0xBFC70A3D80000000
  %645 = fmul fast float %642, %7
  %646 = fmul fast float %643, %7
  %647 = fmul fast float %644, %7
  %648 = fadd fast float %645, 0x3FC70A3D80000000
  %649 = fadd fast float %646, 0x3FC70A3D80000000
  %650 = fadd fast float %647, 0x3FC70A3D80000000
  %651 = call float @dx.op.unary.f32(i32 7, float %648)  ; Saturate(value)
  %652 = call float @dx.op.unary.f32(i32 7, float %649)  ; Saturate(value)
  %653 = call float @dx.op.unary.f32(i32 7, float %650)  ; Saturate(value)
  br label %654

; <label>:654                                     ; preds = %622, %457
  %655 = phi float [ %488, %457 ], [ %651, %622 ]
  %656 = phi float [ %489, %457 ], [ %652, %622 ]
  %657 = phi float [ %490, %457 ], [ %653, %622 ]
  %658 = add i32 %63, -1
  %659 = call i32 @dx.op.binary.i32(i32 37, i32 %658, i32 0)  ; IMax(a,b)
  %660 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %661 = call i32 @dx.op.binary.i32(i32 38, i32 %659, i32 %59)  ; IMin(a,b)
  %662 = call i32 @dx.op.binary.i32(i32 38, i32 %660, i32 %60)  ; IMin(a,b)
  %663 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %661, i32 %662, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %664 = extractvalue %dx.types.ResRet.f32 %663, 0
  %665 = extractvalue %dx.types.ResRet.f32 %663, 1
  %666 = extractvalue %dx.types.ResRet.f32 %663, 2
  %667 = extractvalue %dx.types.ResRet.f32 %663, 3
  %668 = fcmp fast olt float %667, 0.000000e+00
  br i1 %668, label %669, label %703

; <label>:669                                     ; preds = %654
  %670 = fcmp fast ogt float %664, 0x3FA4B5DCC0000000
  %671 = fcmp fast ogt float %665, 0x3FA4B5DCC0000000
  %672 = fcmp fast ogt float %666, 0x3FA4B5DCC0000000
  %673 = select i1 %670, float 0.000000e+00, float 1.000000e+00
  %674 = select i1 %671, float 0.000000e+00, float 1.000000e+00
  %675 = select i1 %672, float 0.000000e+00, float 1.000000e+00
  %676 = fmul fast float %664, 0x3FB3D07220000000
  %677 = fmul fast float %665, 0x3FB3D07220000000
  %678 = fmul fast float %666, 0x3FB3D07220000000
  %679 = fadd fast float %664, 0x3FAC28F5C0000000
  %680 = fadd fast float %665, 0x3FAC28F5C0000000
  %681 = fadd fast float %666, 0x3FAC28F5C0000000
  %682 = fmul fast float %679, 0x3FEE54EDE0000000
  %683 = fmul fast float %680, 0x3FEE54EDE0000000
  %684 = fmul fast float %681, 0x3FEE54EDE0000000
  %685 = call float @dx.op.unary.f32(i32 23, float %682)  ; Log(value)
  %686 = call float @dx.op.unary.f32(i32 23, float %683)  ; Log(value)
  %687 = call float @dx.op.unary.f32(i32 23, float %684)  ; Log(value)
  %688 = fmul fast float %685, 0x4003333340000000
  %689 = fmul fast float %686, 0x4003333340000000
  %690 = fmul fast float %687, 0x4003333340000000
  %691 = call float @dx.op.unary.f32(i32 21, float %688)  ; Exp(value)
  %692 = call float @dx.op.unary.f32(i32 21, float %689)  ; Exp(value)
  %693 = call float @dx.op.unary.f32(i32 21, float %690)  ; Exp(value)
  %694 = fsub fast float %676, %691
  %695 = fsub fast float %677, %692
  %696 = fsub fast float %678, %693
  %697 = fmul fast float %694, %673
  %698 = fmul fast float %695, %674
  %699 = fmul fast float %696, %675
  %700 = fadd fast float %697, %691
  %701 = fadd fast float %698, %692
  %702 = fadd fast float %699, %693
  br label %866

; <label>:703                                     ; preds = %654
  %704 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %661, i32 %662, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %705 = extractvalue %dx.types.ResRet.f32 %704, 0
  %706 = fcmp fast ogt float %38, 5.000000e-01
  %707 = fcmp fast olt float %705, 1.000000e+00
  %708 = and i1 %706, %707
  br i1 %708, label %709, label %795

; <label>:709                                     ; preds = %703
  %710 = sitofp i32 %661 to float
  %711 = sitofp i32 %662 to float
  %712 = fadd fast float %710, 5.000000e-01
  %713 = fadd fast float %711, 5.000000e-01
  %714 = fdiv fast float %712, %45
  %715 = fdiv fast float %713, %46
  %716 = fmul fast float %714, 2.000000e+00
  %717 = fmul fast float %715, 2.000000e+00
  %718 = fadd fast float %716, -1.000000e+00
  %719 = fsub fast float 1.000000e+00, %717
  %720 = fmul fast float %718, %35
  %721 = call float @dx.op.tertiary.f32(i32 46, float %719, float %31, float %720)  ; FMad(a,b,c)
  %722 = call float @dx.op.tertiary.f32(i32 46, float %705, float %27, float %721)  ; FMad(a,b,c)
  %723 = fadd fast float %722, %23
  %724 = call float @dx.op.unary.f32(i32 6, float %723)  ; FAbs(value)
  %725 = fcmp fast ogt float %724, 0x3EB0C6F7A0000000
  br i1 %725, label %726, label %795

; <label>:726                                     ; preds = %709
  %727 = fmul fast float %718, %34
  %728 = call float @dx.op.tertiary.f32(i32 46, float %719, float %30, float %727)  ; FMad(a,b,c)
  %729 = call float @dx.op.tertiary.f32(i32 46, float %705, float %26, float %728)  ; FMad(a,b,c)
  %730 = fadd fast float %729, %22
  %731 = fmul fast float %718, %33
  %732 = call float @dx.op.tertiary.f32(i32 46, float %719, float %29, float %731)  ; FMad(a,b,c)
  %733 = call float @dx.op.tertiary.f32(i32 46, float %705, float %25, float %732)  ; FMad(a,b,c)
  %734 = fadd fast float %733, %21
  %735 = fmul fast float %718, %32
  %736 = call float @dx.op.tertiary.f32(i32 46, float %719, float %28, float %735)  ; FMad(a,b,c)
  %737 = call float @dx.op.tertiary.f32(i32 46, float %705, float %24, float %736)  ; FMad(a,b,c)
  %738 = fadd fast float %737, %20
  %739 = fdiv fast float %738, %723
  %740 = fdiv fast float %734, %723
  %741 = fdiv fast float %730, %723
  %742 = fsub fast float %739, %17
  %743 = fsub fast float %740, %18
  %744 = fsub fast float %741, %19
  %745 = fmul fast float %742, %742
  %746 = fmul fast float %743, %743
  %747 = fadd fast float %746, %745
  %748 = fmul fast float %744, %744
  %749 = fadd fast float %747, %748
  %750 = call float @dx.op.unary.f32(i32 24, float %749)  ; Sqrt(value)
  %751 = fsub fast float %750, %9
  %752 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %751)  ; FMax(a,b)
  %753 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %753, label %754, label %777

; <label>:754                                     ; preds = %726
  %755 = call float @dx.op.unary.f32(i32 6, float %743)  ; FAbs(value)
  %756 = fmul fast float %755, %11
  %757 = fcmp fast olt float %756, 0x3F50624DE0000000
  br i1 %757, label %758, label %761

; <label>:758                                     ; preds = %754
  %759 = fmul fast float %756, 5.000000e-01
  %760 = fsub fast float 1.000000e+00, %759
  br label %766

; <label>:761                                     ; preds = %754
  %762 = fmul fast float %756, 0xBFF7154760000000
  %763 = call float @dx.op.unary.f32(i32 21, float %762)  ; Exp(value)
  %764 = fsub fast float 1.000000e+00, %763
  %765 = fdiv fast float %764, %756
  br label %766

; <label>:766                                     ; preds = %761, %758
  %767 = phi float [ %760, %758 ], [ %765, %761 ]
  %768 = call float @dx.op.binary.f32(i32 36, float %740, float %18)  ; FMin(a,b)
  %769 = fsub fast float %768, %10
  %770 = fmul fast float %11, %769
  %771 = fsub fast float -0.000000e+00, %770
  %772 = call float @dx.op.binary.f32(i32 35, float %771, float -4.000000e+01)  ; FMax(a,b)
  %773 = call float @dx.op.binary.f32(i32 36, float %772, float 5.000000e+00)  ; FMin(a,b)
  %774 = fmul fast float %773, 0x3FF7154760000000
  %775 = call float @dx.op.unary.f32(i32 21, float %774)  ; Exp(value)
  %776 = fmul fast float %775, %767
  br label %777

; <label>:777                                     ; preds = %766, %726
  %778 = phi float [ %776, %766 ], [ 1.000000e+00, %726 ]
  %779 = fmul fast float %752, %16
  %780 = fmul fast float %779, %778
  %781 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %780)  ; FMin(a,b)
  %782 = fmul fast float %781, 0xBFF7154760000000
  %783 = call float @dx.op.unary.f32(i32 21, float %782)  ; Exp(value)
  %784 = fsub fast float 1.000000e+00, %783
  %785 = call float @dx.op.binary.f32(i32 36, float %12, float %784)  ; FMin(a,b)
  %786 = fsub fast float %13, %664
  %787 = fsub fast float %14, %665
  %788 = fsub fast float %15, %666
  %789 = fmul fast float %785, %786
  %790 = fmul fast float %785, %787
  %791 = fmul fast float %785, %788
  %792 = fadd fast float %789, %664
  %793 = fadd fast float %790, %665
  %794 = fadd fast float %791, %666
  br label %795

; <label>:795                                     ; preds = %777, %709, %703
  %796 = phi float [ %792, %777 ], [ %664, %709 ], [ %664, %703 ]
  %797 = phi float [ %793, %777 ], [ %665, %709 ], [ %665, %703 ]
  %798 = phi float [ %794, %777 ], [ %666, %709 ], [ %666, %703 ]
  %799 = fadd fast float %5, 1.000000e+00
  %800 = fadd fast float %6, 1.000000e+00
  %801 = fsub fast float 1.000000e+00, %5
  %802 = fmul fast float %36, %799
  %803 = fmul fast float %36, %800
  %804 = fmul fast float %36, %801
  %805 = fmul fast float %802, %796
  %806 = fmul fast float %803, %797
  %807 = fmul fast float %804, %798
  %808 = fcmp fast ult float %37, 5.000000e-01
  br i1 %808, label %834, label %809

; <label>:809                                     ; preds = %795
  %810 = fmul fast float %805, 0x4004147AE0000000
  %811 = fmul fast float %806, 0x4004147AE0000000
  %812 = fmul fast float %807, 0x4004147AE0000000
  %813 = fadd fast float %810, 0x3F9EB851E0000000
  %814 = fadd fast float %811, 0x3F9EB851E0000000
  %815 = fadd fast float %812, 0x3F9EB851E0000000
  %816 = fmul fast float %813, %805
  %817 = fmul fast float %814, %806
  %818 = fmul fast float %815, %807
  %819 = fmul fast float %805, 0x400370A3E0000000
  %820 = fmul fast float %806, 0x400370A3E0000000
  %821 = fmul fast float %807, 0x400370A3E0000000
  %822 = fadd fast float %819, 0x3FE2E147A0000000
  %823 = fadd fast float %820, 0x3FE2E147A0000000
  %824 = fadd fast float %821, 0x3FE2E147A0000000
  %825 = fmul fast float %822, %805
  %826 = fmul fast float %823, %806
  %827 = fmul fast float %824, %807
  %828 = fadd fast float %825, 0x3FC1EB8520000000
  %829 = fadd fast float %826, 0x3FC1EB8520000000
  %830 = fadd fast float %827, 0x3FC1EB8520000000
  %831 = fdiv fast float %816, %828
  %832 = fdiv fast float %817, %829
  %833 = fdiv fast float %818, %830
  br label %834

; <label>:834                                     ; preds = %809, %795
  %835 = phi float [ %831, %809 ], [ %805, %795 ]
  %836 = phi float [ %832, %809 ], [ %806, %795 ]
  %837 = phi float [ %833, %809 ], [ %807, %795 ]
  %838 = call float @dx.op.unary.f32(i32 7, float %835)  ; Saturate(value)
  %839 = call float @dx.op.unary.f32(i32 7, float %836)  ; Saturate(value)
  %840 = call float @dx.op.unary.f32(i32 7, float %837)  ; Saturate(value)
  %841 = call float @dx.op.dot3.f32(i32 55, float %838, float %839, float %840, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %842 = fsub fast float %838, %841
  %843 = fsub fast float %839, %841
  %844 = fsub fast float %840, %841
  %845 = fmul fast float %842, %8
  %846 = fmul fast float %843, %8
  %847 = fmul fast float %844, %8
  %848 = fadd fast float %845, %841
  %849 = fadd fast float %846, %841
  %850 = fadd fast float %847, %841
  %851 = call float @dx.op.unary.f32(i32 7, float %848)  ; Saturate(value)
  %852 = call float @dx.op.unary.f32(i32 7, float %849)  ; Saturate(value)
  %853 = call float @dx.op.unary.f32(i32 7, float %850)  ; Saturate(value)
  %854 = fadd fast float %851, 0xBFC70A3D80000000
  %855 = fadd fast float %852, 0xBFC70A3D80000000
  %856 = fadd fast float %853, 0xBFC70A3D80000000
  %857 = fmul fast float %854, %7
  %858 = fmul fast float %855, %7
  %859 = fmul fast float %856, %7
  %860 = fadd fast float %857, 0x3FC70A3D80000000
  %861 = fadd fast float %858, 0x3FC70A3D80000000
  %862 = fadd fast float %859, 0x3FC70A3D80000000
  %863 = call float @dx.op.unary.f32(i32 7, float %860)  ; Saturate(value)
  %864 = call float @dx.op.unary.f32(i32 7, float %861)  ; Saturate(value)
  %865 = call float @dx.op.unary.f32(i32 7, float %862)  ; Saturate(value)
  br label %866

; <label>:866                                     ; preds = %834, %669
  %867 = phi float [ %700, %669 ], [ %863, %834 ]
  %868 = phi float [ %701, %669 ], [ %864, %834 ]
  %869 = phi float [ %702, %669 ], [ %865, %834 ]
  %870 = add i32 %63, 1
  %871 = call i32 @dx.op.binary.i32(i32 37, i32 %870, i32 0)  ; IMax(a,b)
  %872 = call i32 @dx.op.binary.i32(i32 38, i32 %871, i32 %59)  ; IMin(a,b)
  %873 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %872, i32 %662, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %874 = extractvalue %dx.types.ResRet.f32 %873, 0
  %875 = extractvalue %dx.types.ResRet.f32 %873, 1
  %876 = extractvalue %dx.types.ResRet.f32 %873, 2
  %877 = extractvalue %dx.types.ResRet.f32 %873, 3
  %878 = fcmp fast olt float %877, 0.000000e+00
  br i1 %878, label %879, label %913

; <label>:879                                     ; preds = %866
  %880 = fcmp fast ogt float %874, 0x3FA4B5DCC0000000
  %881 = fcmp fast ogt float %875, 0x3FA4B5DCC0000000
  %882 = fcmp fast ogt float %876, 0x3FA4B5DCC0000000
  %883 = select i1 %880, float 0.000000e+00, float 1.000000e+00
  %884 = select i1 %881, float 0.000000e+00, float 1.000000e+00
  %885 = select i1 %882, float 0.000000e+00, float 1.000000e+00
  %886 = fmul fast float %874, 0x3FB3D07220000000
  %887 = fmul fast float %875, 0x3FB3D07220000000
  %888 = fmul fast float %876, 0x3FB3D07220000000
  %889 = fadd fast float %874, 0x3FAC28F5C0000000
  %890 = fadd fast float %875, 0x3FAC28F5C0000000
  %891 = fadd fast float %876, 0x3FAC28F5C0000000
  %892 = fmul fast float %889, 0x3FEE54EDE0000000
  %893 = fmul fast float %890, 0x3FEE54EDE0000000
  %894 = fmul fast float %891, 0x3FEE54EDE0000000
  %895 = call float @dx.op.unary.f32(i32 23, float %892)  ; Log(value)
  %896 = call float @dx.op.unary.f32(i32 23, float %893)  ; Log(value)
  %897 = call float @dx.op.unary.f32(i32 23, float %894)  ; Log(value)
  %898 = fmul fast float %895, 0x4003333340000000
  %899 = fmul fast float %896, 0x4003333340000000
  %900 = fmul fast float %897, 0x4003333340000000
  %901 = call float @dx.op.unary.f32(i32 21, float %898)  ; Exp(value)
  %902 = call float @dx.op.unary.f32(i32 21, float %899)  ; Exp(value)
  %903 = call float @dx.op.unary.f32(i32 21, float %900)  ; Exp(value)
  %904 = fsub fast float %886, %901
  %905 = fsub fast float %887, %902
  %906 = fsub fast float %888, %903
  %907 = fmul fast float %904, %883
  %908 = fmul fast float %905, %884
  %909 = fmul fast float %906, %885
  %910 = fadd fast float %907, %901
  %911 = fadd fast float %908, %902
  %912 = fadd fast float %909, %903
  br label %1076

; <label>:913                                     ; preds = %866
  %914 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %872, i32 %662, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %915 = extractvalue %dx.types.ResRet.f32 %914, 0
  %916 = fcmp fast ogt float %38, 5.000000e-01
  %917 = fcmp fast olt float %915, 1.000000e+00
  %918 = and i1 %916, %917
  br i1 %918, label %919, label %1005

; <label>:919                                     ; preds = %913
  %920 = sitofp i32 %872 to float
  %921 = sitofp i32 %662 to float
  %922 = fadd fast float %920, 5.000000e-01
  %923 = fadd fast float %921, 5.000000e-01
  %924 = fdiv fast float %922, %45
  %925 = fdiv fast float %923, %46
  %926 = fmul fast float %924, 2.000000e+00
  %927 = fmul fast float %925, 2.000000e+00
  %928 = fadd fast float %926, -1.000000e+00
  %929 = fsub fast float 1.000000e+00, %927
  %930 = fmul fast float %928, %35
  %931 = call float @dx.op.tertiary.f32(i32 46, float %929, float %31, float %930)  ; FMad(a,b,c)
  %932 = call float @dx.op.tertiary.f32(i32 46, float %915, float %27, float %931)  ; FMad(a,b,c)
  %933 = fadd fast float %932, %23
  %934 = call float @dx.op.unary.f32(i32 6, float %933)  ; FAbs(value)
  %935 = fcmp fast ogt float %934, 0x3EB0C6F7A0000000
  br i1 %935, label %936, label %1005

; <label>:936                                     ; preds = %919
  %937 = fmul fast float %928, %34
  %938 = call float @dx.op.tertiary.f32(i32 46, float %929, float %30, float %937)  ; FMad(a,b,c)
  %939 = call float @dx.op.tertiary.f32(i32 46, float %915, float %26, float %938)  ; FMad(a,b,c)
  %940 = fadd fast float %939, %22
  %941 = fmul fast float %928, %33
  %942 = call float @dx.op.tertiary.f32(i32 46, float %929, float %29, float %941)  ; FMad(a,b,c)
  %943 = call float @dx.op.tertiary.f32(i32 46, float %915, float %25, float %942)  ; FMad(a,b,c)
  %944 = fadd fast float %943, %21
  %945 = fmul fast float %928, %32
  %946 = call float @dx.op.tertiary.f32(i32 46, float %929, float %28, float %945)  ; FMad(a,b,c)
  %947 = call float @dx.op.tertiary.f32(i32 46, float %915, float %24, float %946)  ; FMad(a,b,c)
  %948 = fadd fast float %947, %20
  %949 = fdiv fast float %948, %933
  %950 = fdiv fast float %944, %933
  %951 = fdiv fast float %940, %933
  %952 = fsub fast float %949, %17
  %953 = fsub fast float %950, %18
  %954 = fsub fast float %951, %19
  %955 = fmul fast float %952, %952
  %956 = fmul fast float %953, %953
  %957 = fadd fast float %956, %955
  %958 = fmul fast float %954, %954
  %959 = fadd fast float %957, %958
  %960 = call float @dx.op.unary.f32(i32 24, float %959)  ; Sqrt(value)
  %961 = fsub fast float %960, %9
  %962 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %961)  ; FMax(a,b)
  %963 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %963, label %964, label %987

; <label>:964                                     ; preds = %936
  %965 = call float @dx.op.unary.f32(i32 6, float %953)  ; FAbs(value)
  %966 = fmul fast float %965, %11
  %967 = fcmp fast olt float %966, 0x3F50624DE0000000
  br i1 %967, label %968, label %971

; <label>:968                                     ; preds = %964
  %969 = fmul fast float %966, 5.000000e-01
  %970 = fsub fast float 1.000000e+00, %969
  br label %976

; <label>:971                                     ; preds = %964
  %972 = fmul fast float %966, 0xBFF7154760000000
  %973 = call float @dx.op.unary.f32(i32 21, float %972)  ; Exp(value)
  %974 = fsub fast float 1.000000e+00, %973
  %975 = fdiv fast float %974, %966
  br label %976

; <label>:976                                     ; preds = %971, %968
  %977 = phi float [ %970, %968 ], [ %975, %971 ]
  %978 = call float @dx.op.binary.f32(i32 36, float %950, float %18)  ; FMin(a,b)
  %979 = fsub fast float %978, %10
  %980 = fmul fast float %11, %979
  %981 = fsub fast float -0.000000e+00, %980
  %982 = call float @dx.op.binary.f32(i32 35, float %981, float -4.000000e+01)  ; FMax(a,b)
  %983 = call float @dx.op.binary.f32(i32 36, float %982, float 5.000000e+00)  ; FMin(a,b)
  %984 = fmul fast float %983, 0x3FF7154760000000
  %985 = call float @dx.op.unary.f32(i32 21, float %984)  ; Exp(value)
  %986 = fmul fast float %985, %977
  br label %987

; <label>:987                                     ; preds = %976, %936
  %988 = phi float [ %986, %976 ], [ 1.000000e+00, %936 ]
  %989 = fmul fast float %962, %16
  %990 = fmul fast float %989, %988
  %991 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %990)  ; FMin(a,b)
  %992 = fmul fast float %991, 0xBFF7154760000000
  %993 = call float @dx.op.unary.f32(i32 21, float %992)  ; Exp(value)
  %994 = fsub fast float 1.000000e+00, %993
  %995 = call float @dx.op.binary.f32(i32 36, float %12, float %994)  ; FMin(a,b)
  %996 = fsub fast float %13, %874
  %997 = fsub fast float %14, %875
  %998 = fsub fast float %15, %876
  %999 = fmul fast float %995, %996
  %1000 = fmul fast float %995, %997
  %1001 = fmul fast float %995, %998
  %1002 = fadd fast float %999, %874
  %1003 = fadd fast float %1000, %875
  %1004 = fadd fast float %1001, %876
  br label %1005

; <label>:1005                                    ; preds = %987, %919, %913
  %1006 = phi float [ %1002, %987 ], [ %874, %919 ], [ %874, %913 ]
  %1007 = phi float [ %1003, %987 ], [ %875, %919 ], [ %875, %913 ]
  %1008 = phi float [ %1004, %987 ], [ %876, %919 ], [ %876, %913 ]
  %1009 = fadd fast float %5, 1.000000e+00
  %1010 = fadd fast float %6, 1.000000e+00
  %1011 = fsub fast float 1.000000e+00, %5
  %1012 = fmul fast float %36, %1009
  %1013 = fmul fast float %36, %1010
  %1014 = fmul fast float %36, %1011
  %1015 = fmul fast float %1012, %1006
  %1016 = fmul fast float %1013, %1007
  %1017 = fmul fast float %1014, %1008
  %1018 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1018, label %1044, label %1019

; <label>:1019                                    ; preds = %1005
  %1020 = fmul fast float %1015, 0x4004147AE0000000
  %1021 = fmul fast float %1016, 0x4004147AE0000000
  %1022 = fmul fast float %1017, 0x4004147AE0000000
  %1023 = fadd fast float %1020, 0x3F9EB851E0000000
  %1024 = fadd fast float %1021, 0x3F9EB851E0000000
  %1025 = fadd fast float %1022, 0x3F9EB851E0000000
  %1026 = fmul fast float %1023, %1015
  %1027 = fmul fast float %1024, %1016
  %1028 = fmul fast float %1025, %1017
  %1029 = fmul fast float %1015, 0x400370A3E0000000
  %1030 = fmul fast float %1016, 0x400370A3E0000000
  %1031 = fmul fast float %1017, 0x400370A3E0000000
  %1032 = fadd fast float %1029, 0x3FE2E147A0000000
  %1033 = fadd fast float %1030, 0x3FE2E147A0000000
  %1034 = fadd fast float %1031, 0x3FE2E147A0000000
  %1035 = fmul fast float %1032, %1015
  %1036 = fmul fast float %1033, %1016
  %1037 = fmul fast float %1034, %1017
  %1038 = fadd fast float %1035, 0x3FC1EB8520000000
  %1039 = fadd fast float %1036, 0x3FC1EB8520000000
  %1040 = fadd fast float %1037, 0x3FC1EB8520000000
  %1041 = fdiv fast float %1026, %1038
  %1042 = fdiv fast float %1027, %1039
  %1043 = fdiv fast float %1028, %1040
  br label %1044

; <label>:1044                                    ; preds = %1019, %1005
  %1045 = phi float [ %1041, %1019 ], [ %1015, %1005 ]
  %1046 = phi float [ %1042, %1019 ], [ %1016, %1005 ]
  %1047 = phi float [ %1043, %1019 ], [ %1017, %1005 ]
  %1048 = call float @dx.op.unary.f32(i32 7, float %1045)  ; Saturate(value)
  %1049 = call float @dx.op.unary.f32(i32 7, float %1046)  ; Saturate(value)
  %1050 = call float @dx.op.unary.f32(i32 7, float %1047)  ; Saturate(value)
  %1051 = call float @dx.op.dot3.f32(i32 55, float %1048, float %1049, float %1050, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1052 = fsub fast float %1048, %1051
  %1053 = fsub fast float %1049, %1051
  %1054 = fsub fast float %1050, %1051
  %1055 = fmul fast float %1052, %8
  %1056 = fmul fast float %1053, %8
  %1057 = fmul fast float %1054, %8
  %1058 = fadd fast float %1055, %1051
  %1059 = fadd fast float %1056, %1051
  %1060 = fadd fast float %1057, %1051
  %1061 = call float @dx.op.unary.f32(i32 7, float %1058)  ; Saturate(value)
  %1062 = call float @dx.op.unary.f32(i32 7, float %1059)  ; Saturate(value)
  %1063 = call float @dx.op.unary.f32(i32 7, float %1060)  ; Saturate(value)
  %1064 = fadd fast float %1061, 0xBFC70A3D80000000
  %1065 = fadd fast float %1062, 0xBFC70A3D80000000
  %1066 = fadd fast float %1063, 0xBFC70A3D80000000
  %1067 = fmul fast float %1064, %7
  %1068 = fmul fast float %1065, %7
  %1069 = fmul fast float %1066, %7
  %1070 = fadd fast float %1067, 0x3FC70A3D80000000
  %1071 = fadd fast float %1068, 0x3FC70A3D80000000
  %1072 = fadd fast float %1069, 0x3FC70A3D80000000
  %1073 = call float @dx.op.unary.f32(i32 7, float %1070)  ; Saturate(value)
  %1074 = call float @dx.op.unary.f32(i32 7, float %1071)  ; Saturate(value)
  %1075 = call float @dx.op.unary.f32(i32 7, float %1072)  ; Saturate(value)
  br label %1076

; <label>:1076                                    ; preds = %1044, %879
  %1077 = phi float [ %910, %879 ], [ %1073, %1044 ]
  %1078 = phi float [ %911, %879 ], [ %1074, %1044 ]
  %1079 = phi float [ %912, %879 ], [ %1075, %1044 ]
  %1080 = call float @dx.op.binary.f32(i32 36, float %867, float %1077)  ; FMin(a,b)
  %1081 = call float @dx.op.binary.f32(i32 36, float %868, float %1078)  ; FMin(a,b)
  %1082 = call float @dx.op.binary.f32(i32 36, float %869, float %1079)  ; FMin(a,b)
  %1083 = call float @dx.op.binary.f32(i32 36, float %445, float %655)  ; FMin(a,b)
  %1084 = call float @dx.op.binary.f32(i32 36, float %446, float %656)  ; FMin(a,b)
  %1085 = call float @dx.op.binary.f32(i32 36, float %447, float %657)  ; FMin(a,b)
  %1086 = call float @dx.op.binary.f32(i32 36, float %1083, float %1080)  ; FMin(a,b)
  %1087 = call float @dx.op.binary.f32(i32 36, float %1084, float %1081)  ; FMin(a,b)
  %1088 = call float @dx.op.binary.f32(i32 36, float %1085, float %1082)  ; FMin(a,b)
  %1089 = call float @dx.op.binary.f32(i32 36, float %233, float %1086)  ; FMin(a,b)
  %1090 = call float @dx.op.binary.f32(i32 36, float %234, float %1087)  ; FMin(a,b)
  %1091 = call float @dx.op.binary.f32(i32 36, float %235, float %1088)  ; FMin(a,b)
  %1092 = call float @dx.op.binary.f32(i32 35, float %867, float %1077)  ; FMax(a,b)
  %1093 = call float @dx.op.binary.f32(i32 35, float %868, float %1078)  ; FMax(a,b)
  %1094 = call float @dx.op.binary.f32(i32 35, float %869, float %1079)  ; FMax(a,b)
  %1095 = call float @dx.op.binary.f32(i32 35, float %445, float %655)  ; FMax(a,b)
  %1096 = call float @dx.op.binary.f32(i32 35, float %446, float %656)  ; FMax(a,b)
  %1097 = call float @dx.op.binary.f32(i32 35, float %447, float %657)  ; FMax(a,b)
  %1098 = call float @dx.op.binary.f32(i32 35, float %1095, float %1092)  ; FMax(a,b)
  %1099 = call float @dx.op.binary.f32(i32 35, float %1096, float %1093)  ; FMax(a,b)
  %1100 = call float @dx.op.binary.f32(i32 35, float %1097, float %1094)  ; FMax(a,b)
  %1101 = call float @dx.op.binary.f32(i32 35, float %233, float %1098)  ; FMax(a,b)
  %1102 = call float @dx.op.binary.f32(i32 35, float %234, float %1099)  ; FMax(a,b)
  %1103 = call float @dx.op.binary.f32(i32 35, float %235, float %1100)  ; FMax(a,b)
  %1104 = fsub fast float %1101, %1089
  %1105 = fsub fast float %1102, %1090
  %1106 = fsub fast float %1103, %1091
  %1107 = call float @dx.op.unary.f32(i32 6, float %1104)  ; FAbs(value)
  %1108 = call float @dx.op.unary.f32(i32 6, float %1105)  ; FAbs(value)
  %1109 = call float @dx.op.unary.f32(i32 6, float %1106)  ; FAbs(value)
  %1110 = call float @dx.op.binary.f32(i32 35, float %1108, float %1109)  ; FMax(a,b)
  %1111 = call float @dx.op.binary.f32(i32 35, float %1107, float %1110)  ; FMax(a,b)
  %1112 = call float @dx.op.binary.f32(i32 35, float %1102, float %1103)  ; FMax(a,b)
  %1113 = call float @dx.op.binary.f32(i32 35, float %1101, float %1112)  ; FMax(a,b)
  %1114 = fmul fast float %1113, 1.250000e-01
  %1115 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1114)  ; FMax(a,b)
  %1116 = fcmp fast ogt float %1111, %1115
  br i1 %1116, label %1117, label %1178

; <label>:1117                                    ; preds = %1076
  %1118 = fsub fast float %445, %655
  %1119 = fsub fast float %446, %656
  %1120 = fsub fast float %447, %657
  %1121 = call float @dx.op.unary.f32(i32 6, float %1118)  ; FAbs(value)
  %1122 = call float @dx.op.unary.f32(i32 6, float %1119)  ; FAbs(value)
  %1123 = call float @dx.op.unary.f32(i32 6, float %1120)  ; FAbs(value)
  %1124 = call float @dx.op.binary.f32(i32 35, float %1122, float %1123)  ; FMax(a,b)
  %1125 = call float @dx.op.binary.f32(i32 35, float %1121, float %1124)  ; FMax(a,b)
  %1126 = fsub fast float %867, %1077
  %1127 = fsub fast float %868, %1078
  %1128 = fsub fast float %869, %1079
  %1129 = call float @dx.op.unary.f32(i32 6, float %1126)  ; FAbs(value)
  %1130 = call float @dx.op.unary.f32(i32 6, float %1127)  ; FAbs(value)
  %1131 = call float @dx.op.unary.f32(i32 6, float %1128)  ; FAbs(value)
  %1132 = call float @dx.op.binary.f32(i32 35, float %1130, float %1131)  ; FMax(a,b)
  %1133 = call float @dx.op.binary.f32(i32 35, float %1129, float %1132)  ; FMax(a,b)
  %1134 = fcmp fast olt float %1125, %1133
  %1135 = select i1 %1134, float %445, float %867
  %1136 = select i1 %1134, float %446, float %868
  %1137 = select i1 %1134, float %447, float %869
  %1138 = select i1 %1134, float %655, float %1077
  %1139 = select i1 %1134, float %656, float %1078
  %1140 = select i1 %1134, float %657, float %1079
  %1141 = fsub fast float %233, %1138
  %1142 = fsub fast float %234, %1139
  %1143 = fsub fast float %235, %1140
  %1144 = fsub fast float %233, %1135
  %1145 = fsub fast float %234, %1136
  %1146 = fsub fast float %235, %1137
  %1147 = call float @dx.op.dot3.f32(i32 55, float %1144, float %1145, float %1146, float %1141, float %1142, float %1143)  ; Dot3(ax,ay,az,bx,by,bz)
  %1148 = fcmp fast ogt float %1147, 0.000000e+00
  br i1 %1148, label %1149, label %1160

; <label>:1149                                    ; preds = %1117
  %1150 = fsub fast float %1135, %1138
  %1151 = fsub fast float %1136, %1139
  %1152 = fsub fast float %1137, %1140
  %1153 = call float @dx.op.unary.f32(i32 6, float %1150)  ; FAbs(value)
  %1154 = call float @dx.op.unary.f32(i32 6, float %1151)  ; FAbs(value)
  %1155 = call float @dx.op.unary.f32(i32 6, float %1152)  ; FAbs(value)
  %1156 = call float @dx.op.binary.f32(i32 35, float %1154, float %1155)  ; FMax(a,b)
  %1157 = call float @dx.op.binary.f32(i32 35, float %1153, float %1156)  ; FMax(a,b)
  %1158 = fmul fast float %1111, 2.500000e-01
  %1159 = fcmp fast olt float %1157, %1158
  br label %1160

; <label>:1160                                    ; preds = %1149, %1117
  %1161 = phi i1 [ false, %1117 ], [ %1159, %1149 ]
  %1162 = select i1 %1161, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  %1163 = fadd fast float %1135, %1138
  %1164 = fadd fast float %1136, %1139
  %1165 = fadd fast float %1137, %1140
  %1166 = fmul fast float %1163, 5.000000e-01
  %1167 = fmul fast float %1164, 5.000000e-01
  %1168 = fmul fast float %1165, 5.000000e-01
  %1169 = fsub fast float %1166, %233
  %1170 = fsub fast float %1167, %234
  %1171 = fsub fast float %1168, %235
  %1172 = fmul fast float %1162, %1169
  %1173 = fmul fast float %1162, %1170
  %1174 = fmul fast float %1162, %1171
  %1175 = fadd fast float %1172, %233
  %1176 = fadd fast float %1173, %234
  %1177 = fadd fast float %1174, %235
  br label %1178

; <label>:1178                                    ; preds = %1160, %1076
  %1179 = phi float [ %1175, %1160 ], [ %233, %1076 ]
  %1180 = phi float [ %1176, %1160 ], [ %234, %1076 ]
  %1181 = phi float [ %1177, %1160 ], [ %235, %1076 ]
  %1182 = fcmp fast ogt float %1179, 0x3F69A5C380000000
  %1183 = fcmp fast ogt float %1180, 0x3F69A5C380000000
  %1184 = fcmp fast ogt float %1181, 0x3F69A5C380000000
  %1185 = select i1 %1182, float 0.000000e+00, float 1.000000e+00
  %1186 = select i1 %1183, float 0.000000e+00, float 1.000000e+00
  %1187 = select i1 %1184, float 0.000000e+00, float 1.000000e+00
  %1188 = fmul fast float %1179, 0x4029D70A40000000
  %1189 = fmul fast float %1180, 0x4029D70A40000000
  %1190 = fmul fast float %1181, 0x4029D70A40000000
  %1191 = call float @dx.op.binary.f32(i32 35, float %1179, float 0.000000e+00)  ; FMax(a,b)
  %1192 = call float @dx.op.binary.f32(i32 35, float %1180, float 0.000000e+00)  ; FMax(a,b)
  %1193 = call float @dx.op.binary.f32(i32 35, float %1181, float 0.000000e+00)  ; FMax(a,b)
  %1194 = call float @dx.op.unary.f32(i32 23, float %1191)  ; Log(value)
  %1195 = call float @dx.op.unary.f32(i32 23, float %1192)  ; Log(value)
  %1196 = call float @dx.op.unary.f32(i32 23, float %1193)  ; Log(value)
  %1197 = fmul fast float %1194, 0x3FDAAAAAA0000000
  %1198 = fmul fast float %1195, 0x3FDAAAAAA0000000
  %1199 = fmul fast float %1196, 0x3FDAAAAAA0000000
  %1200 = call float @dx.op.unary.f32(i32 21, float %1197)  ; Exp(value)
  %1201 = call float @dx.op.unary.f32(i32 21, float %1198)  ; Exp(value)
  %1202 = call float @dx.op.unary.f32(i32 21, float %1199)  ; Exp(value)
  %1203 = fmul fast float %1200, 0x3FF0E147A0000000
  %1204 = fmul fast float %1201, 0x3FF0E147A0000000
  %1205 = fmul fast float %1202, 0x3FF0E147A0000000
  %1206 = fadd fast float %1203, 0xBFAC28F5C0000000
  %1207 = fadd fast float %1204, 0xBFAC28F5C0000000
  %1208 = fadd fast float %1205, 0xBFAC28F5C0000000
  %1209 = fsub fast float %1188, %1206
  %1210 = fsub fast float %1189, %1207
  %1211 = fsub fast float %1190, %1208
  %1212 = fmul fast float %1209, %1185
  %1213 = fmul fast float %1210, %1186
  %1214 = fmul fast float %1211, %1187
  %1215 = fadd fast float %1212, %1206
  %1216 = fadd fast float %1213, %1207
  %1217 = fadd fast float %1214, %1208
  br label %1218

; <label>:1218                                    ; preds = %1178, %71
  %1219 = phi float [ %66, %71 ], [ %1215, %1178 ]
  %1220 = phi float [ %67, %71 ], [ %1216, %1178 ]
  %1221 = phi float [ %68, %71 ], [ %1217, %1178 ]
  %1222 = phi float [ %72, %71 ], [ %69, %1178 ]
  %1223 = add i32 %55, 1
  %1224 = call i32 @dx.op.binary.i32(i32 37, i32 %1223, i32 0)  ; IMax(a,b)
  %1225 = call i32 @dx.op.binary.i32(i32 38, i32 %1224, i32 %59)  ; IMin(a,b)
  %1226 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1225, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1227 = extractvalue %dx.types.ResRet.f32 %1226, 0
  %1228 = extractvalue %dx.types.ResRet.f32 %1226, 1
  %1229 = extractvalue %dx.types.ResRet.f32 %1226, 2
  %1230 = extractvalue %dx.types.ResRet.f32 %1226, 3
  %1231 = fcmp fast olt float %1230, 0.000000e+00
  br i1 %1231, label %1232, label %1234

; <label>:1232                                    ; preds = %1218
  %1233 = fsub fast float -1.000000e+00, %1230
  br label %2379

; <label>:1234                                    ; preds = %1218
  %1235 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1225, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1236 = extractvalue %dx.types.ResRet.f32 %1235, 0
  %1237 = fcmp fast ogt float %38, 5.000000e-01
  %1238 = fcmp fast olt float %1236, 1.000000e+00
  %1239 = and i1 %1237, %1238
  br i1 %1239, label %1240, label %1326

; <label>:1240                                    ; preds = %1234
  %1241 = sitofp i32 %1225 to float
  %1242 = sitofp i32 %64 to float
  %1243 = fadd fast float %1241, 5.000000e-01
  %1244 = fadd fast float %1242, 5.000000e-01
  %1245 = fdiv fast float %1243, %45
  %1246 = fdiv fast float %1244, %46
  %1247 = fmul fast float %1245, 2.000000e+00
  %1248 = fmul fast float %1246, 2.000000e+00
  %1249 = fadd fast float %1247, -1.000000e+00
  %1250 = fsub fast float 1.000000e+00, %1248
  %1251 = fmul fast float %1249, %35
  %1252 = call float @dx.op.tertiary.f32(i32 46, float %1250, float %31, float %1251)  ; FMad(a,b,c)
  %1253 = call float @dx.op.tertiary.f32(i32 46, float %1236, float %27, float %1252)  ; FMad(a,b,c)
  %1254 = fadd fast float %1253, %23
  %1255 = call float @dx.op.unary.f32(i32 6, float %1254)  ; FAbs(value)
  %1256 = fcmp fast ogt float %1255, 0x3EB0C6F7A0000000
  br i1 %1256, label %1257, label %1326

; <label>:1257                                    ; preds = %1240
  %1258 = fmul fast float %1249, %34
  %1259 = call float @dx.op.tertiary.f32(i32 46, float %1250, float %30, float %1258)  ; FMad(a,b,c)
  %1260 = call float @dx.op.tertiary.f32(i32 46, float %1236, float %26, float %1259)  ; FMad(a,b,c)
  %1261 = fadd fast float %1260, %22
  %1262 = fmul fast float %1249, %33
  %1263 = call float @dx.op.tertiary.f32(i32 46, float %1250, float %29, float %1262)  ; FMad(a,b,c)
  %1264 = call float @dx.op.tertiary.f32(i32 46, float %1236, float %25, float %1263)  ; FMad(a,b,c)
  %1265 = fadd fast float %1264, %21
  %1266 = fmul fast float %1249, %32
  %1267 = call float @dx.op.tertiary.f32(i32 46, float %1250, float %28, float %1266)  ; FMad(a,b,c)
  %1268 = call float @dx.op.tertiary.f32(i32 46, float %1236, float %24, float %1267)  ; FMad(a,b,c)
  %1269 = fadd fast float %1268, %20
  %1270 = fdiv fast float %1269, %1254
  %1271 = fdiv fast float %1265, %1254
  %1272 = fdiv fast float %1261, %1254
  %1273 = fsub fast float %1270, %17
  %1274 = fsub fast float %1271, %18
  %1275 = fsub fast float %1272, %19
  %1276 = fmul fast float %1273, %1273
  %1277 = fmul fast float %1274, %1274
  %1278 = fadd fast float %1277, %1276
  %1279 = fmul fast float %1275, %1275
  %1280 = fadd fast float %1278, %1279
  %1281 = call float @dx.op.unary.f32(i32 24, float %1280)  ; Sqrt(value)
  %1282 = fsub fast float %1281, %9
  %1283 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1282)  ; FMax(a,b)
  %1284 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1284, label %1285, label %1308

; <label>:1285                                    ; preds = %1257
  %1286 = call float @dx.op.unary.f32(i32 6, float %1274)  ; FAbs(value)
  %1287 = fmul fast float %1286, %11
  %1288 = fcmp fast olt float %1287, 0x3F50624DE0000000
  br i1 %1288, label %1289, label %1292

; <label>:1289                                    ; preds = %1285
  %1290 = fmul fast float %1287, 5.000000e-01
  %1291 = fsub fast float 1.000000e+00, %1290
  br label %1297

; <label>:1292                                    ; preds = %1285
  %1293 = fmul fast float %1287, 0xBFF7154760000000
  %1294 = call float @dx.op.unary.f32(i32 21, float %1293)  ; Exp(value)
  %1295 = fsub fast float 1.000000e+00, %1294
  %1296 = fdiv fast float %1295, %1287
  br label %1297

; <label>:1297                                    ; preds = %1292, %1289
  %1298 = phi float [ %1291, %1289 ], [ %1296, %1292 ]
  %1299 = call float @dx.op.binary.f32(i32 36, float %1271, float %18)  ; FMin(a,b)
  %1300 = fsub fast float %1299, %10
  %1301 = fmul fast float %11, %1300
  %1302 = fsub fast float -0.000000e+00, %1301
  %1303 = call float @dx.op.binary.f32(i32 35, float %1302, float -4.000000e+01)  ; FMax(a,b)
  %1304 = call float @dx.op.binary.f32(i32 36, float %1303, float 5.000000e+00)  ; FMin(a,b)
  %1305 = fmul fast float %1304, 0x3FF7154760000000
  %1306 = call float @dx.op.unary.f32(i32 21, float %1305)  ; Exp(value)
  %1307 = fmul fast float %1306, %1298
  br label %1308

; <label>:1308                                    ; preds = %1297, %1257
  %1309 = phi float [ %1307, %1297 ], [ 1.000000e+00, %1257 ]
  %1310 = fmul fast float %1283, %16
  %1311 = fmul fast float %1310, %1309
  %1312 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1311)  ; FMin(a,b)
  %1313 = fmul fast float %1312, 0xBFF7154760000000
  %1314 = call float @dx.op.unary.f32(i32 21, float %1313)  ; Exp(value)
  %1315 = fsub fast float 1.000000e+00, %1314
  %1316 = call float @dx.op.binary.f32(i32 36, float %12, float %1315)  ; FMin(a,b)
  %1317 = fsub fast float %13, %1227
  %1318 = fsub fast float %14, %1228
  %1319 = fsub fast float %15, %1229
  %1320 = fmul fast float %1316, %1317
  %1321 = fmul fast float %1316, %1318
  %1322 = fmul fast float %1316, %1319
  %1323 = fadd fast float %1320, %1227
  %1324 = fadd fast float %1321, %1228
  %1325 = fadd fast float %1322, %1229
  br label %1326

; <label>:1326                                    ; preds = %1308, %1240, %1234
  %1327 = phi float [ %1323, %1308 ], [ %1227, %1240 ], [ %1227, %1234 ]
  %1328 = phi float [ %1324, %1308 ], [ %1228, %1240 ], [ %1228, %1234 ]
  %1329 = phi float [ %1325, %1308 ], [ %1229, %1240 ], [ %1229, %1234 ]
  %1330 = fadd fast float %5, 1.000000e+00
  %1331 = fadd fast float %6, 1.000000e+00
  %1332 = fsub fast float 1.000000e+00, %5
  %1333 = fmul fast float %36, %1330
  %1334 = fmul fast float %36, %1331
  %1335 = fmul fast float %36, %1332
  %1336 = fmul fast float %1333, %1327
  %1337 = fmul fast float %1334, %1328
  %1338 = fmul fast float %1335, %1329
  %1339 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1339, label %1365, label %1340

; <label>:1340                                    ; preds = %1326
  %1341 = fmul fast float %1336, 0x4004147AE0000000
  %1342 = fmul fast float %1337, 0x4004147AE0000000
  %1343 = fmul fast float %1338, 0x4004147AE0000000
  %1344 = fadd fast float %1341, 0x3F9EB851E0000000
  %1345 = fadd fast float %1342, 0x3F9EB851E0000000
  %1346 = fadd fast float %1343, 0x3F9EB851E0000000
  %1347 = fmul fast float %1344, %1336
  %1348 = fmul fast float %1345, %1337
  %1349 = fmul fast float %1346, %1338
  %1350 = fmul fast float %1336, 0x400370A3E0000000
  %1351 = fmul fast float %1337, 0x400370A3E0000000
  %1352 = fmul fast float %1338, 0x400370A3E0000000
  %1353 = fadd fast float %1350, 0x3FE2E147A0000000
  %1354 = fadd fast float %1351, 0x3FE2E147A0000000
  %1355 = fadd fast float %1352, 0x3FE2E147A0000000
  %1356 = fmul fast float %1353, %1336
  %1357 = fmul fast float %1354, %1337
  %1358 = fmul fast float %1355, %1338
  %1359 = fadd fast float %1356, 0x3FC1EB8520000000
  %1360 = fadd fast float %1357, 0x3FC1EB8520000000
  %1361 = fadd fast float %1358, 0x3FC1EB8520000000
  %1362 = fdiv fast float %1347, %1359
  %1363 = fdiv fast float %1348, %1360
  %1364 = fdiv fast float %1349, %1361
  br label %1365

; <label>:1365                                    ; preds = %1340, %1326
  %1366 = phi float [ %1362, %1340 ], [ %1336, %1326 ]
  %1367 = phi float [ %1363, %1340 ], [ %1337, %1326 ]
  %1368 = phi float [ %1364, %1340 ], [ %1338, %1326 ]
  %1369 = call float @dx.op.unary.f32(i32 7, float %1366)  ; Saturate(value)
  %1370 = call float @dx.op.unary.f32(i32 7, float %1367)  ; Saturate(value)
  %1371 = call float @dx.op.unary.f32(i32 7, float %1368)  ; Saturate(value)
  %1372 = call float @dx.op.dot3.f32(i32 55, float %1369, float %1370, float %1371, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1373 = fsub fast float %1369, %1372
  %1374 = fsub fast float %1370, %1372
  %1375 = fsub fast float %1371, %1372
  %1376 = fmul fast float %1373, %8
  %1377 = fmul fast float %1374, %8
  %1378 = fmul fast float %1375, %8
  %1379 = fadd fast float %1376, %1372
  %1380 = fadd fast float %1377, %1372
  %1381 = fadd fast float %1378, %1372
  %1382 = call float @dx.op.unary.f32(i32 7, float %1379)  ; Saturate(value)
  %1383 = call float @dx.op.unary.f32(i32 7, float %1380)  ; Saturate(value)
  %1384 = call float @dx.op.unary.f32(i32 7, float %1381)  ; Saturate(value)
  %1385 = fadd fast float %1382, 0xBFC70A3D80000000
  %1386 = fadd fast float %1383, 0xBFC70A3D80000000
  %1387 = fadd fast float %1384, 0xBFC70A3D80000000
  %1388 = fmul fast float %1385, %7
  %1389 = fmul fast float %1386, %7
  %1390 = fmul fast float %1387, %7
  %1391 = fadd fast float %1388, 0x3FC70A3D80000000
  %1392 = fadd fast float %1389, 0x3FC70A3D80000000
  %1393 = fadd fast float %1390, 0x3FC70A3D80000000
  %1394 = call float @dx.op.unary.f32(i32 7, float %1391)  ; Saturate(value)
  %1395 = call float @dx.op.unary.f32(i32 7, float %1392)  ; Saturate(value)
  %1396 = call float @dx.op.unary.f32(i32 7, float %1393)  ; Saturate(value)
  %1397 = add i32 %64, -1
  %1398 = call i32 @dx.op.binary.i32(i32 37, i32 %1225, i32 0)  ; IMax(a,b)
  %1399 = call i32 @dx.op.binary.i32(i32 37, i32 %1397, i32 0)  ; IMax(a,b)
  %1400 = call i32 @dx.op.binary.i32(i32 38, i32 %1398, i32 %59)  ; IMin(a,b)
  %1401 = call i32 @dx.op.binary.i32(i32 38, i32 %1399, i32 %60)  ; IMin(a,b)
  %1402 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1400, i32 %1401, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1403 = extractvalue %dx.types.ResRet.f32 %1402, 0
  %1404 = extractvalue %dx.types.ResRet.f32 %1402, 1
  %1405 = extractvalue %dx.types.ResRet.f32 %1402, 2
  %1406 = extractvalue %dx.types.ResRet.f32 %1402, 3
  %1407 = fcmp fast olt float %1406, 0.000000e+00
  br i1 %1407, label %1408, label %1442

; <label>:1408                                    ; preds = %1365
  %1409 = fcmp fast ogt float %1403, 0x3FA4B5DCC0000000
  %1410 = fcmp fast ogt float %1404, 0x3FA4B5DCC0000000
  %1411 = fcmp fast ogt float %1405, 0x3FA4B5DCC0000000
  %1412 = select i1 %1409, float 0.000000e+00, float 1.000000e+00
  %1413 = select i1 %1410, float 0.000000e+00, float 1.000000e+00
  %1414 = select i1 %1411, float 0.000000e+00, float 1.000000e+00
  %1415 = fmul fast float %1403, 0x3FB3D07220000000
  %1416 = fmul fast float %1404, 0x3FB3D07220000000
  %1417 = fmul fast float %1405, 0x3FB3D07220000000
  %1418 = fadd fast float %1403, 0x3FAC28F5C0000000
  %1419 = fadd fast float %1404, 0x3FAC28F5C0000000
  %1420 = fadd fast float %1405, 0x3FAC28F5C0000000
  %1421 = fmul fast float %1418, 0x3FEE54EDE0000000
  %1422 = fmul fast float %1419, 0x3FEE54EDE0000000
  %1423 = fmul fast float %1420, 0x3FEE54EDE0000000
  %1424 = call float @dx.op.unary.f32(i32 23, float %1421)  ; Log(value)
  %1425 = call float @dx.op.unary.f32(i32 23, float %1422)  ; Log(value)
  %1426 = call float @dx.op.unary.f32(i32 23, float %1423)  ; Log(value)
  %1427 = fmul fast float %1424, 0x4003333340000000
  %1428 = fmul fast float %1425, 0x4003333340000000
  %1429 = fmul fast float %1426, 0x4003333340000000
  %1430 = call float @dx.op.unary.f32(i32 21, float %1427)  ; Exp(value)
  %1431 = call float @dx.op.unary.f32(i32 21, float %1428)  ; Exp(value)
  %1432 = call float @dx.op.unary.f32(i32 21, float %1429)  ; Exp(value)
  %1433 = fsub fast float %1415, %1430
  %1434 = fsub fast float %1416, %1431
  %1435 = fsub fast float %1417, %1432
  %1436 = fmul fast float %1433, %1412
  %1437 = fmul fast float %1434, %1413
  %1438 = fmul fast float %1435, %1414
  %1439 = fadd fast float %1436, %1430
  %1440 = fadd fast float %1437, %1431
  %1441 = fadd fast float %1438, %1432
  br label %1605

; <label>:1442                                    ; preds = %1365
  %1443 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1400, i32 %1401, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1444 = extractvalue %dx.types.ResRet.f32 %1443, 0
  %1445 = fcmp fast ogt float %38, 5.000000e-01
  %1446 = fcmp fast olt float %1444, 1.000000e+00
  %1447 = and i1 %1445, %1446
  br i1 %1447, label %1448, label %1534

; <label>:1448                                    ; preds = %1442
  %1449 = sitofp i32 %1400 to float
  %1450 = sitofp i32 %1401 to float
  %1451 = fadd fast float %1449, 5.000000e-01
  %1452 = fadd fast float %1450, 5.000000e-01
  %1453 = fdiv fast float %1451, %45
  %1454 = fdiv fast float %1452, %46
  %1455 = fmul fast float %1453, 2.000000e+00
  %1456 = fmul fast float %1454, 2.000000e+00
  %1457 = fadd fast float %1455, -1.000000e+00
  %1458 = fsub fast float 1.000000e+00, %1456
  %1459 = fmul fast float %1457, %35
  %1460 = call float @dx.op.tertiary.f32(i32 46, float %1458, float %31, float %1459)  ; FMad(a,b,c)
  %1461 = call float @dx.op.tertiary.f32(i32 46, float %1444, float %27, float %1460)  ; FMad(a,b,c)
  %1462 = fadd fast float %1461, %23
  %1463 = call float @dx.op.unary.f32(i32 6, float %1462)  ; FAbs(value)
  %1464 = fcmp fast ogt float %1463, 0x3EB0C6F7A0000000
  br i1 %1464, label %1465, label %1534

; <label>:1465                                    ; preds = %1448
  %1466 = fmul fast float %1457, %34
  %1467 = call float @dx.op.tertiary.f32(i32 46, float %1458, float %30, float %1466)  ; FMad(a,b,c)
  %1468 = call float @dx.op.tertiary.f32(i32 46, float %1444, float %26, float %1467)  ; FMad(a,b,c)
  %1469 = fadd fast float %1468, %22
  %1470 = fmul fast float %1457, %33
  %1471 = call float @dx.op.tertiary.f32(i32 46, float %1458, float %29, float %1470)  ; FMad(a,b,c)
  %1472 = call float @dx.op.tertiary.f32(i32 46, float %1444, float %25, float %1471)  ; FMad(a,b,c)
  %1473 = fadd fast float %1472, %21
  %1474 = fmul fast float %1457, %32
  %1475 = call float @dx.op.tertiary.f32(i32 46, float %1458, float %28, float %1474)  ; FMad(a,b,c)
  %1476 = call float @dx.op.tertiary.f32(i32 46, float %1444, float %24, float %1475)  ; FMad(a,b,c)
  %1477 = fadd fast float %1476, %20
  %1478 = fdiv fast float %1477, %1462
  %1479 = fdiv fast float %1473, %1462
  %1480 = fdiv fast float %1469, %1462
  %1481 = fsub fast float %1478, %17
  %1482 = fsub fast float %1479, %18
  %1483 = fsub fast float %1480, %19
  %1484 = fmul fast float %1481, %1481
  %1485 = fmul fast float %1482, %1482
  %1486 = fadd fast float %1485, %1484
  %1487 = fmul fast float %1483, %1483
  %1488 = fadd fast float %1486, %1487
  %1489 = call float @dx.op.unary.f32(i32 24, float %1488)  ; Sqrt(value)
  %1490 = fsub fast float %1489, %9
  %1491 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1490)  ; FMax(a,b)
  %1492 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1492, label %1493, label %1516

; <label>:1493                                    ; preds = %1465
  %1494 = call float @dx.op.unary.f32(i32 6, float %1482)  ; FAbs(value)
  %1495 = fmul fast float %1494, %11
  %1496 = fcmp fast olt float %1495, 0x3F50624DE0000000
  br i1 %1496, label %1497, label %1500

; <label>:1497                                    ; preds = %1493
  %1498 = fmul fast float %1495, 5.000000e-01
  %1499 = fsub fast float 1.000000e+00, %1498
  br label %1505

; <label>:1500                                    ; preds = %1493
  %1501 = fmul fast float %1495, 0xBFF7154760000000
  %1502 = call float @dx.op.unary.f32(i32 21, float %1501)  ; Exp(value)
  %1503 = fsub fast float 1.000000e+00, %1502
  %1504 = fdiv fast float %1503, %1495
  br label %1505

; <label>:1505                                    ; preds = %1500, %1497
  %1506 = phi float [ %1499, %1497 ], [ %1504, %1500 ]
  %1507 = call float @dx.op.binary.f32(i32 36, float %1479, float %18)  ; FMin(a,b)
  %1508 = fsub fast float %1507, %10
  %1509 = fmul fast float %11, %1508
  %1510 = fsub fast float -0.000000e+00, %1509
  %1511 = call float @dx.op.binary.f32(i32 35, float %1510, float -4.000000e+01)  ; FMax(a,b)
  %1512 = call float @dx.op.binary.f32(i32 36, float %1511, float 5.000000e+00)  ; FMin(a,b)
  %1513 = fmul fast float %1512, 0x3FF7154760000000
  %1514 = call float @dx.op.unary.f32(i32 21, float %1513)  ; Exp(value)
  %1515 = fmul fast float %1514, %1506
  br label %1516

; <label>:1516                                    ; preds = %1505, %1465
  %1517 = phi float [ %1515, %1505 ], [ 1.000000e+00, %1465 ]
  %1518 = fmul fast float %1491, %16
  %1519 = fmul fast float %1518, %1517
  %1520 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1519)  ; FMin(a,b)
  %1521 = fmul fast float %1520, 0xBFF7154760000000
  %1522 = call float @dx.op.unary.f32(i32 21, float %1521)  ; Exp(value)
  %1523 = fsub fast float 1.000000e+00, %1522
  %1524 = call float @dx.op.binary.f32(i32 36, float %12, float %1523)  ; FMin(a,b)
  %1525 = fsub fast float %13, %1403
  %1526 = fsub fast float %14, %1404
  %1527 = fsub fast float %15, %1405
  %1528 = fmul fast float %1524, %1525
  %1529 = fmul fast float %1524, %1526
  %1530 = fmul fast float %1524, %1527
  %1531 = fadd fast float %1528, %1403
  %1532 = fadd fast float %1529, %1404
  %1533 = fadd fast float %1530, %1405
  br label %1534

; <label>:1534                                    ; preds = %1516, %1448, %1442
  %1535 = phi float [ %1531, %1516 ], [ %1403, %1448 ], [ %1403, %1442 ]
  %1536 = phi float [ %1532, %1516 ], [ %1404, %1448 ], [ %1404, %1442 ]
  %1537 = phi float [ %1533, %1516 ], [ %1405, %1448 ], [ %1405, %1442 ]
  %1538 = fadd fast float %5, 1.000000e+00
  %1539 = fadd fast float %6, 1.000000e+00
  %1540 = fsub fast float 1.000000e+00, %5
  %1541 = fmul fast float %36, %1538
  %1542 = fmul fast float %36, %1539
  %1543 = fmul fast float %36, %1540
  %1544 = fmul fast float %1541, %1535
  %1545 = fmul fast float %1542, %1536
  %1546 = fmul fast float %1543, %1537
  %1547 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1547, label %1573, label %1548

; <label>:1548                                    ; preds = %1534
  %1549 = fmul fast float %1544, 0x4004147AE0000000
  %1550 = fmul fast float %1545, 0x4004147AE0000000
  %1551 = fmul fast float %1546, 0x4004147AE0000000
  %1552 = fadd fast float %1549, 0x3F9EB851E0000000
  %1553 = fadd fast float %1550, 0x3F9EB851E0000000
  %1554 = fadd fast float %1551, 0x3F9EB851E0000000
  %1555 = fmul fast float %1552, %1544
  %1556 = fmul fast float %1553, %1545
  %1557 = fmul fast float %1554, %1546
  %1558 = fmul fast float %1544, 0x400370A3E0000000
  %1559 = fmul fast float %1545, 0x400370A3E0000000
  %1560 = fmul fast float %1546, 0x400370A3E0000000
  %1561 = fadd fast float %1558, 0x3FE2E147A0000000
  %1562 = fadd fast float %1559, 0x3FE2E147A0000000
  %1563 = fadd fast float %1560, 0x3FE2E147A0000000
  %1564 = fmul fast float %1561, %1544
  %1565 = fmul fast float %1562, %1545
  %1566 = fmul fast float %1563, %1546
  %1567 = fadd fast float %1564, 0x3FC1EB8520000000
  %1568 = fadd fast float %1565, 0x3FC1EB8520000000
  %1569 = fadd fast float %1566, 0x3FC1EB8520000000
  %1570 = fdiv fast float %1555, %1567
  %1571 = fdiv fast float %1556, %1568
  %1572 = fdiv fast float %1557, %1569
  br label %1573

; <label>:1573                                    ; preds = %1548, %1534
  %1574 = phi float [ %1570, %1548 ], [ %1544, %1534 ]
  %1575 = phi float [ %1571, %1548 ], [ %1545, %1534 ]
  %1576 = phi float [ %1572, %1548 ], [ %1546, %1534 ]
  %1577 = call float @dx.op.unary.f32(i32 7, float %1574)  ; Saturate(value)
  %1578 = call float @dx.op.unary.f32(i32 7, float %1575)  ; Saturate(value)
  %1579 = call float @dx.op.unary.f32(i32 7, float %1576)  ; Saturate(value)
  %1580 = call float @dx.op.dot3.f32(i32 55, float %1577, float %1578, float %1579, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1581 = fsub fast float %1577, %1580
  %1582 = fsub fast float %1578, %1580
  %1583 = fsub fast float %1579, %1580
  %1584 = fmul fast float %1581, %8
  %1585 = fmul fast float %1582, %8
  %1586 = fmul fast float %1583, %8
  %1587 = fadd fast float %1584, %1580
  %1588 = fadd fast float %1585, %1580
  %1589 = fadd fast float %1586, %1580
  %1590 = call float @dx.op.unary.f32(i32 7, float %1587)  ; Saturate(value)
  %1591 = call float @dx.op.unary.f32(i32 7, float %1588)  ; Saturate(value)
  %1592 = call float @dx.op.unary.f32(i32 7, float %1589)  ; Saturate(value)
  %1593 = fadd fast float %1590, 0xBFC70A3D80000000
  %1594 = fadd fast float %1591, 0xBFC70A3D80000000
  %1595 = fadd fast float %1592, 0xBFC70A3D80000000
  %1596 = fmul fast float %1593, %7
  %1597 = fmul fast float %1594, %7
  %1598 = fmul fast float %1595, %7
  %1599 = fadd fast float %1596, 0x3FC70A3D80000000
  %1600 = fadd fast float %1597, 0x3FC70A3D80000000
  %1601 = fadd fast float %1598, 0x3FC70A3D80000000
  %1602 = call float @dx.op.unary.f32(i32 7, float %1599)  ; Saturate(value)
  %1603 = call float @dx.op.unary.f32(i32 7, float %1600)  ; Saturate(value)
  %1604 = call float @dx.op.unary.f32(i32 7, float %1601)  ; Saturate(value)
  br label %1605

; <label>:1605                                    ; preds = %1573, %1408
  %1606 = phi float [ %1439, %1408 ], [ %1602, %1573 ]
  %1607 = phi float [ %1440, %1408 ], [ %1603, %1573 ]
  %1608 = phi float [ %1441, %1408 ], [ %1604, %1573 ]
  %1609 = add i32 %64, 1
  %1610 = call i32 @dx.op.binary.i32(i32 37, i32 %1609, i32 0)  ; IMax(a,b)
  %1611 = call i32 @dx.op.binary.i32(i32 38, i32 %1610, i32 %60)  ; IMin(a,b)
  %1612 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1400, i32 %1611, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1613 = extractvalue %dx.types.ResRet.f32 %1612, 0
  %1614 = extractvalue %dx.types.ResRet.f32 %1612, 1
  %1615 = extractvalue %dx.types.ResRet.f32 %1612, 2
  %1616 = extractvalue %dx.types.ResRet.f32 %1612, 3
  %1617 = fcmp fast olt float %1616, 0.000000e+00
  br i1 %1617, label %1618, label %1652

; <label>:1618                                    ; preds = %1605
  %1619 = fcmp fast ogt float %1613, 0x3FA4B5DCC0000000
  %1620 = fcmp fast ogt float %1614, 0x3FA4B5DCC0000000
  %1621 = fcmp fast ogt float %1615, 0x3FA4B5DCC0000000
  %1622 = select i1 %1619, float 0.000000e+00, float 1.000000e+00
  %1623 = select i1 %1620, float 0.000000e+00, float 1.000000e+00
  %1624 = select i1 %1621, float 0.000000e+00, float 1.000000e+00
  %1625 = fmul fast float %1613, 0x3FB3D07220000000
  %1626 = fmul fast float %1614, 0x3FB3D07220000000
  %1627 = fmul fast float %1615, 0x3FB3D07220000000
  %1628 = fadd fast float %1613, 0x3FAC28F5C0000000
  %1629 = fadd fast float %1614, 0x3FAC28F5C0000000
  %1630 = fadd fast float %1615, 0x3FAC28F5C0000000
  %1631 = fmul fast float %1628, 0x3FEE54EDE0000000
  %1632 = fmul fast float %1629, 0x3FEE54EDE0000000
  %1633 = fmul fast float %1630, 0x3FEE54EDE0000000
  %1634 = call float @dx.op.unary.f32(i32 23, float %1631)  ; Log(value)
  %1635 = call float @dx.op.unary.f32(i32 23, float %1632)  ; Log(value)
  %1636 = call float @dx.op.unary.f32(i32 23, float %1633)  ; Log(value)
  %1637 = fmul fast float %1634, 0x4003333340000000
  %1638 = fmul fast float %1635, 0x4003333340000000
  %1639 = fmul fast float %1636, 0x4003333340000000
  %1640 = call float @dx.op.unary.f32(i32 21, float %1637)  ; Exp(value)
  %1641 = call float @dx.op.unary.f32(i32 21, float %1638)  ; Exp(value)
  %1642 = call float @dx.op.unary.f32(i32 21, float %1639)  ; Exp(value)
  %1643 = fsub fast float %1625, %1640
  %1644 = fsub fast float %1626, %1641
  %1645 = fsub fast float %1627, %1642
  %1646 = fmul fast float %1643, %1622
  %1647 = fmul fast float %1644, %1623
  %1648 = fmul fast float %1645, %1624
  %1649 = fadd fast float %1646, %1640
  %1650 = fadd fast float %1647, %1641
  %1651 = fadd fast float %1648, %1642
  br label %1815

; <label>:1652                                    ; preds = %1605
  %1653 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1400, i32 %1611, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1654 = extractvalue %dx.types.ResRet.f32 %1653, 0
  %1655 = fcmp fast ogt float %38, 5.000000e-01
  %1656 = fcmp fast olt float %1654, 1.000000e+00
  %1657 = and i1 %1655, %1656
  br i1 %1657, label %1658, label %1744

; <label>:1658                                    ; preds = %1652
  %1659 = sitofp i32 %1400 to float
  %1660 = sitofp i32 %1611 to float
  %1661 = fadd fast float %1659, 5.000000e-01
  %1662 = fadd fast float %1660, 5.000000e-01
  %1663 = fdiv fast float %1661, %45
  %1664 = fdiv fast float %1662, %46
  %1665 = fmul fast float %1663, 2.000000e+00
  %1666 = fmul fast float %1664, 2.000000e+00
  %1667 = fadd fast float %1665, -1.000000e+00
  %1668 = fsub fast float 1.000000e+00, %1666
  %1669 = fmul fast float %1667, %35
  %1670 = call float @dx.op.tertiary.f32(i32 46, float %1668, float %31, float %1669)  ; FMad(a,b,c)
  %1671 = call float @dx.op.tertiary.f32(i32 46, float %1654, float %27, float %1670)  ; FMad(a,b,c)
  %1672 = fadd fast float %1671, %23
  %1673 = call float @dx.op.unary.f32(i32 6, float %1672)  ; FAbs(value)
  %1674 = fcmp fast ogt float %1673, 0x3EB0C6F7A0000000
  br i1 %1674, label %1675, label %1744

; <label>:1675                                    ; preds = %1658
  %1676 = fmul fast float %1667, %34
  %1677 = call float @dx.op.tertiary.f32(i32 46, float %1668, float %30, float %1676)  ; FMad(a,b,c)
  %1678 = call float @dx.op.tertiary.f32(i32 46, float %1654, float %26, float %1677)  ; FMad(a,b,c)
  %1679 = fadd fast float %1678, %22
  %1680 = fmul fast float %1667, %33
  %1681 = call float @dx.op.tertiary.f32(i32 46, float %1668, float %29, float %1680)  ; FMad(a,b,c)
  %1682 = call float @dx.op.tertiary.f32(i32 46, float %1654, float %25, float %1681)  ; FMad(a,b,c)
  %1683 = fadd fast float %1682, %21
  %1684 = fmul fast float %1667, %32
  %1685 = call float @dx.op.tertiary.f32(i32 46, float %1668, float %28, float %1684)  ; FMad(a,b,c)
  %1686 = call float @dx.op.tertiary.f32(i32 46, float %1654, float %24, float %1685)  ; FMad(a,b,c)
  %1687 = fadd fast float %1686, %20
  %1688 = fdiv fast float %1687, %1672
  %1689 = fdiv fast float %1683, %1672
  %1690 = fdiv fast float %1679, %1672
  %1691 = fsub fast float %1688, %17
  %1692 = fsub fast float %1689, %18
  %1693 = fsub fast float %1690, %19
  %1694 = fmul fast float %1691, %1691
  %1695 = fmul fast float %1692, %1692
  %1696 = fadd fast float %1695, %1694
  %1697 = fmul fast float %1693, %1693
  %1698 = fadd fast float %1696, %1697
  %1699 = call float @dx.op.unary.f32(i32 24, float %1698)  ; Sqrt(value)
  %1700 = fsub fast float %1699, %9
  %1701 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1700)  ; FMax(a,b)
  %1702 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1702, label %1703, label %1726

; <label>:1703                                    ; preds = %1675
  %1704 = call float @dx.op.unary.f32(i32 6, float %1692)  ; FAbs(value)
  %1705 = fmul fast float %1704, %11
  %1706 = fcmp fast olt float %1705, 0x3F50624DE0000000
  br i1 %1706, label %1707, label %1710

; <label>:1707                                    ; preds = %1703
  %1708 = fmul fast float %1705, 5.000000e-01
  %1709 = fsub fast float 1.000000e+00, %1708
  br label %1715

; <label>:1710                                    ; preds = %1703
  %1711 = fmul fast float %1705, 0xBFF7154760000000
  %1712 = call float @dx.op.unary.f32(i32 21, float %1711)  ; Exp(value)
  %1713 = fsub fast float 1.000000e+00, %1712
  %1714 = fdiv fast float %1713, %1705
  br label %1715

; <label>:1715                                    ; preds = %1710, %1707
  %1716 = phi float [ %1709, %1707 ], [ %1714, %1710 ]
  %1717 = call float @dx.op.binary.f32(i32 36, float %1689, float %18)  ; FMin(a,b)
  %1718 = fsub fast float %1717, %10
  %1719 = fmul fast float %11, %1718
  %1720 = fsub fast float -0.000000e+00, %1719
  %1721 = call float @dx.op.binary.f32(i32 35, float %1720, float -4.000000e+01)  ; FMax(a,b)
  %1722 = call float @dx.op.binary.f32(i32 36, float %1721, float 5.000000e+00)  ; FMin(a,b)
  %1723 = fmul fast float %1722, 0x3FF7154760000000
  %1724 = call float @dx.op.unary.f32(i32 21, float %1723)  ; Exp(value)
  %1725 = fmul fast float %1724, %1716
  br label %1726

; <label>:1726                                    ; preds = %1715, %1675
  %1727 = phi float [ %1725, %1715 ], [ 1.000000e+00, %1675 ]
  %1728 = fmul fast float %1701, %16
  %1729 = fmul fast float %1728, %1727
  %1730 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1729)  ; FMin(a,b)
  %1731 = fmul fast float %1730, 0xBFF7154760000000
  %1732 = call float @dx.op.unary.f32(i32 21, float %1731)  ; Exp(value)
  %1733 = fsub fast float 1.000000e+00, %1732
  %1734 = call float @dx.op.binary.f32(i32 36, float %12, float %1733)  ; FMin(a,b)
  %1735 = fsub fast float %13, %1613
  %1736 = fsub fast float %14, %1614
  %1737 = fsub fast float %15, %1615
  %1738 = fmul fast float %1734, %1735
  %1739 = fmul fast float %1734, %1736
  %1740 = fmul fast float %1734, %1737
  %1741 = fadd fast float %1738, %1613
  %1742 = fadd fast float %1739, %1614
  %1743 = fadd fast float %1740, %1615
  br label %1744

; <label>:1744                                    ; preds = %1726, %1658, %1652
  %1745 = phi float [ %1741, %1726 ], [ %1613, %1658 ], [ %1613, %1652 ]
  %1746 = phi float [ %1742, %1726 ], [ %1614, %1658 ], [ %1614, %1652 ]
  %1747 = phi float [ %1743, %1726 ], [ %1615, %1658 ], [ %1615, %1652 ]
  %1748 = fadd fast float %5, 1.000000e+00
  %1749 = fadd fast float %6, 1.000000e+00
  %1750 = fsub fast float 1.000000e+00, %5
  %1751 = fmul fast float %36, %1748
  %1752 = fmul fast float %36, %1749
  %1753 = fmul fast float %36, %1750
  %1754 = fmul fast float %1751, %1745
  %1755 = fmul fast float %1752, %1746
  %1756 = fmul fast float %1753, %1747
  %1757 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1757, label %1783, label %1758

; <label>:1758                                    ; preds = %1744
  %1759 = fmul fast float %1754, 0x4004147AE0000000
  %1760 = fmul fast float %1755, 0x4004147AE0000000
  %1761 = fmul fast float %1756, 0x4004147AE0000000
  %1762 = fadd fast float %1759, 0x3F9EB851E0000000
  %1763 = fadd fast float %1760, 0x3F9EB851E0000000
  %1764 = fadd fast float %1761, 0x3F9EB851E0000000
  %1765 = fmul fast float %1762, %1754
  %1766 = fmul fast float %1763, %1755
  %1767 = fmul fast float %1764, %1756
  %1768 = fmul fast float %1754, 0x400370A3E0000000
  %1769 = fmul fast float %1755, 0x400370A3E0000000
  %1770 = fmul fast float %1756, 0x400370A3E0000000
  %1771 = fadd fast float %1768, 0x3FE2E147A0000000
  %1772 = fadd fast float %1769, 0x3FE2E147A0000000
  %1773 = fadd fast float %1770, 0x3FE2E147A0000000
  %1774 = fmul fast float %1771, %1754
  %1775 = fmul fast float %1772, %1755
  %1776 = fmul fast float %1773, %1756
  %1777 = fadd fast float %1774, 0x3FC1EB8520000000
  %1778 = fadd fast float %1775, 0x3FC1EB8520000000
  %1779 = fadd fast float %1776, 0x3FC1EB8520000000
  %1780 = fdiv fast float %1765, %1777
  %1781 = fdiv fast float %1766, %1778
  %1782 = fdiv fast float %1767, %1779
  br label %1783

; <label>:1783                                    ; preds = %1758, %1744
  %1784 = phi float [ %1780, %1758 ], [ %1754, %1744 ]
  %1785 = phi float [ %1781, %1758 ], [ %1755, %1744 ]
  %1786 = phi float [ %1782, %1758 ], [ %1756, %1744 ]
  %1787 = call float @dx.op.unary.f32(i32 7, float %1784)  ; Saturate(value)
  %1788 = call float @dx.op.unary.f32(i32 7, float %1785)  ; Saturate(value)
  %1789 = call float @dx.op.unary.f32(i32 7, float %1786)  ; Saturate(value)
  %1790 = call float @dx.op.dot3.f32(i32 55, float %1787, float %1788, float %1789, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1791 = fsub fast float %1787, %1790
  %1792 = fsub fast float %1788, %1790
  %1793 = fsub fast float %1789, %1790
  %1794 = fmul fast float %1791, %8
  %1795 = fmul fast float %1792, %8
  %1796 = fmul fast float %1793, %8
  %1797 = fadd fast float %1794, %1790
  %1798 = fadd fast float %1795, %1790
  %1799 = fadd fast float %1796, %1790
  %1800 = call float @dx.op.unary.f32(i32 7, float %1797)  ; Saturate(value)
  %1801 = call float @dx.op.unary.f32(i32 7, float %1798)  ; Saturate(value)
  %1802 = call float @dx.op.unary.f32(i32 7, float %1799)  ; Saturate(value)
  %1803 = fadd fast float %1800, 0xBFC70A3D80000000
  %1804 = fadd fast float %1801, 0xBFC70A3D80000000
  %1805 = fadd fast float %1802, 0xBFC70A3D80000000
  %1806 = fmul fast float %1803, %7
  %1807 = fmul fast float %1804, %7
  %1808 = fmul fast float %1805, %7
  %1809 = fadd fast float %1806, 0x3FC70A3D80000000
  %1810 = fadd fast float %1807, 0x3FC70A3D80000000
  %1811 = fadd fast float %1808, 0x3FC70A3D80000000
  %1812 = call float @dx.op.unary.f32(i32 7, float %1809)  ; Saturate(value)
  %1813 = call float @dx.op.unary.f32(i32 7, float %1810)  ; Saturate(value)
  %1814 = call float @dx.op.unary.f32(i32 7, float %1811)  ; Saturate(value)
  br label %1815

; <label>:1815                                    ; preds = %1783, %1618
  %1816 = phi float [ %1649, %1618 ], [ %1812, %1783 ]
  %1817 = phi float [ %1650, %1618 ], [ %1813, %1783 ]
  %1818 = phi float [ %1651, %1618 ], [ %1814, %1783 ]
  %1819 = add i32 %1225, -1
  %1820 = call i32 @dx.op.binary.i32(i32 37, i32 %1819, i32 0)  ; IMax(a,b)
  %1821 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %1822 = call i32 @dx.op.binary.i32(i32 38, i32 %1820, i32 %59)  ; IMin(a,b)
  %1823 = call i32 @dx.op.binary.i32(i32 38, i32 %1821, i32 %60)  ; IMin(a,b)
  %1824 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1822, i32 %1823, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1825 = extractvalue %dx.types.ResRet.f32 %1824, 0
  %1826 = extractvalue %dx.types.ResRet.f32 %1824, 1
  %1827 = extractvalue %dx.types.ResRet.f32 %1824, 2
  %1828 = extractvalue %dx.types.ResRet.f32 %1824, 3
  %1829 = fcmp fast olt float %1828, 0.000000e+00
  br i1 %1829, label %1830, label %1864

; <label>:1830                                    ; preds = %1815
  %1831 = fcmp fast ogt float %1825, 0x3FA4B5DCC0000000
  %1832 = fcmp fast ogt float %1826, 0x3FA4B5DCC0000000
  %1833 = fcmp fast ogt float %1827, 0x3FA4B5DCC0000000
  %1834 = select i1 %1831, float 0.000000e+00, float 1.000000e+00
  %1835 = select i1 %1832, float 0.000000e+00, float 1.000000e+00
  %1836 = select i1 %1833, float 0.000000e+00, float 1.000000e+00
  %1837 = fmul fast float %1825, 0x3FB3D07220000000
  %1838 = fmul fast float %1826, 0x3FB3D07220000000
  %1839 = fmul fast float %1827, 0x3FB3D07220000000
  %1840 = fadd fast float %1825, 0x3FAC28F5C0000000
  %1841 = fadd fast float %1826, 0x3FAC28F5C0000000
  %1842 = fadd fast float %1827, 0x3FAC28F5C0000000
  %1843 = fmul fast float %1840, 0x3FEE54EDE0000000
  %1844 = fmul fast float %1841, 0x3FEE54EDE0000000
  %1845 = fmul fast float %1842, 0x3FEE54EDE0000000
  %1846 = call float @dx.op.unary.f32(i32 23, float %1843)  ; Log(value)
  %1847 = call float @dx.op.unary.f32(i32 23, float %1844)  ; Log(value)
  %1848 = call float @dx.op.unary.f32(i32 23, float %1845)  ; Log(value)
  %1849 = fmul fast float %1846, 0x4003333340000000
  %1850 = fmul fast float %1847, 0x4003333340000000
  %1851 = fmul fast float %1848, 0x4003333340000000
  %1852 = call float @dx.op.unary.f32(i32 21, float %1849)  ; Exp(value)
  %1853 = call float @dx.op.unary.f32(i32 21, float %1850)  ; Exp(value)
  %1854 = call float @dx.op.unary.f32(i32 21, float %1851)  ; Exp(value)
  %1855 = fsub fast float %1837, %1852
  %1856 = fsub fast float %1838, %1853
  %1857 = fsub fast float %1839, %1854
  %1858 = fmul fast float %1855, %1834
  %1859 = fmul fast float %1856, %1835
  %1860 = fmul fast float %1857, %1836
  %1861 = fadd fast float %1858, %1852
  %1862 = fadd fast float %1859, %1853
  %1863 = fadd fast float %1860, %1854
  br label %2027

; <label>:1864                                    ; preds = %1815
  %1865 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1822, i32 %1823, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1866 = extractvalue %dx.types.ResRet.f32 %1865, 0
  %1867 = fcmp fast ogt float %38, 5.000000e-01
  %1868 = fcmp fast olt float %1866, 1.000000e+00
  %1869 = and i1 %1867, %1868
  br i1 %1869, label %1870, label %1956

; <label>:1870                                    ; preds = %1864
  %1871 = sitofp i32 %1822 to float
  %1872 = sitofp i32 %1823 to float
  %1873 = fadd fast float %1871, 5.000000e-01
  %1874 = fadd fast float %1872, 5.000000e-01
  %1875 = fdiv fast float %1873, %45
  %1876 = fdiv fast float %1874, %46
  %1877 = fmul fast float %1875, 2.000000e+00
  %1878 = fmul fast float %1876, 2.000000e+00
  %1879 = fadd fast float %1877, -1.000000e+00
  %1880 = fsub fast float 1.000000e+00, %1878
  %1881 = fmul fast float %1879, %35
  %1882 = call float @dx.op.tertiary.f32(i32 46, float %1880, float %31, float %1881)  ; FMad(a,b,c)
  %1883 = call float @dx.op.tertiary.f32(i32 46, float %1866, float %27, float %1882)  ; FMad(a,b,c)
  %1884 = fadd fast float %1883, %23
  %1885 = call float @dx.op.unary.f32(i32 6, float %1884)  ; FAbs(value)
  %1886 = fcmp fast ogt float %1885, 0x3EB0C6F7A0000000
  br i1 %1886, label %1887, label %1956

; <label>:1887                                    ; preds = %1870
  %1888 = fmul fast float %1879, %34
  %1889 = call float @dx.op.tertiary.f32(i32 46, float %1880, float %30, float %1888)  ; FMad(a,b,c)
  %1890 = call float @dx.op.tertiary.f32(i32 46, float %1866, float %26, float %1889)  ; FMad(a,b,c)
  %1891 = fadd fast float %1890, %22
  %1892 = fmul fast float %1879, %33
  %1893 = call float @dx.op.tertiary.f32(i32 46, float %1880, float %29, float %1892)  ; FMad(a,b,c)
  %1894 = call float @dx.op.tertiary.f32(i32 46, float %1866, float %25, float %1893)  ; FMad(a,b,c)
  %1895 = fadd fast float %1894, %21
  %1896 = fmul fast float %1879, %32
  %1897 = call float @dx.op.tertiary.f32(i32 46, float %1880, float %28, float %1896)  ; FMad(a,b,c)
  %1898 = call float @dx.op.tertiary.f32(i32 46, float %1866, float %24, float %1897)  ; FMad(a,b,c)
  %1899 = fadd fast float %1898, %20
  %1900 = fdiv fast float %1899, %1884
  %1901 = fdiv fast float %1895, %1884
  %1902 = fdiv fast float %1891, %1884
  %1903 = fsub fast float %1900, %17
  %1904 = fsub fast float %1901, %18
  %1905 = fsub fast float %1902, %19
  %1906 = fmul fast float %1903, %1903
  %1907 = fmul fast float %1904, %1904
  %1908 = fadd fast float %1907, %1906
  %1909 = fmul fast float %1905, %1905
  %1910 = fadd fast float %1908, %1909
  %1911 = call float @dx.op.unary.f32(i32 24, float %1910)  ; Sqrt(value)
  %1912 = fsub fast float %1911, %9
  %1913 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1912)  ; FMax(a,b)
  %1914 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1914, label %1915, label %1938

; <label>:1915                                    ; preds = %1887
  %1916 = call float @dx.op.unary.f32(i32 6, float %1904)  ; FAbs(value)
  %1917 = fmul fast float %1916, %11
  %1918 = fcmp fast olt float %1917, 0x3F50624DE0000000
  br i1 %1918, label %1919, label %1922

; <label>:1919                                    ; preds = %1915
  %1920 = fmul fast float %1917, 5.000000e-01
  %1921 = fsub fast float 1.000000e+00, %1920
  br label %1927

; <label>:1922                                    ; preds = %1915
  %1923 = fmul fast float %1917, 0xBFF7154760000000
  %1924 = call float @dx.op.unary.f32(i32 21, float %1923)  ; Exp(value)
  %1925 = fsub fast float 1.000000e+00, %1924
  %1926 = fdiv fast float %1925, %1917
  br label %1927

; <label>:1927                                    ; preds = %1922, %1919
  %1928 = phi float [ %1921, %1919 ], [ %1926, %1922 ]
  %1929 = call float @dx.op.binary.f32(i32 36, float %1901, float %18)  ; FMin(a,b)
  %1930 = fsub fast float %1929, %10
  %1931 = fmul fast float %11, %1930
  %1932 = fsub fast float -0.000000e+00, %1931
  %1933 = call float @dx.op.binary.f32(i32 35, float %1932, float -4.000000e+01)  ; FMax(a,b)
  %1934 = call float @dx.op.binary.f32(i32 36, float %1933, float 5.000000e+00)  ; FMin(a,b)
  %1935 = fmul fast float %1934, 0x3FF7154760000000
  %1936 = call float @dx.op.unary.f32(i32 21, float %1935)  ; Exp(value)
  %1937 = fmul fast float %1936, %1928
  br label %1938

; <label>:1938                                    ; preds = %1927, %1887
  %1939 = phi float [ %1937, %1927 ], [ 1.000000e+00, %1887 ]
  %1940 = fmul fast float %1913, %16
  %1941 = fmul fast float %1940, %1939
  %1942 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1941)  ; FMin(a,b)
  %1943 = fmul fast float %1942, 0xBFF7154760000000
  %1944 = call float @dx.op.unary.f32(i32 21, float %1943)  ; Exp(value)
  %1945 = fsub fast float 1.000000e+00, %1944
  %1946 = call float @dx.op.binary.f32(i32 36, float %12, float %1945)  ; FMin(a,b)
  %1947 = fsub fast float %13, %1825
  %1948 = fsub fast float %14, %1826
  %1949 = fsub fast float %15, %1827
  %1950 = fmul fast float %1946, %1947
  %1951 = fmul fast float %1946, %1948
  %1952 = fmul fast float %1946, %1949
  %1953 = fadd fast float %1950, %1825
  %1954 = fadd fast float %1951, %1826
  %1955 = fadd fast float %1952, %1827
  br label %1956

; <label>:1956                                    ; preds = %1938, %1870, %1864
  %1957 = phi float [ %1953, %1938 ], [ %1825, %1870 ], [ %1825, %1864 ]
  %1958 = phi float [ %1954, %1938 ], [ %1826, %1870 ], [ %1826, %1864 ]
  %1959 = phi float [ %1955, %1938 ], [ %1827, %1870 ], [ %1827, %1864 ]
  %1960 = fadd fast float %5, 1.000000e+00
  %1961 = fadd fast float %6, 1.000000e+00
  %1962 = fsub fast float 1.000000e+00, %5
  %1963 = fmul fast float %36, %1960
  %1964 = fmul fast float %36, %1961
  %1965 = fmul fast float %36, %1962
  %1966 = fmul fast float %1963, %1957
  %1967 = fmul fast float %1964, %1958
  %1968 = fmul fast float %1965, %1959
  %1969 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1969, label %1995, label %1970

; <label>:1970                                    ; preds = %1956
  %1971 = fmul fast float %1966, 0x4004147AE0000000
  %1972 = fmul fast float %1967, 0x4004147AE0000000
  %1973 = fmul fast float %1968, 0x4004147AE0000000
  %1974 = fadd fast float %1971, 0x3F9EB851E0000000
  %1975 = fadd fast float %1972, 0x3F9EB851E0000000
  %1976 = fadd fast float %1973, 0x3F9EB851E0000000
  %1977 = fmul fast float %1974, %1966
  %1978 = fmul fast float %1975, %1967
  %1979 = fmul fast float %1976, %1968
  %1980 = fmul fast float %1966, 0x400370A3E0000000
  %1981 = fmul fast float %1967, 0x400370A3E0000000
  %1982 = fmul fast float %1968, 0x400370A3E0000000
  %1983 = fadd fast float %1980, 0x3FE2E147A0000000
  %1984 = fadd fast float %1981, 0x3FE2E147A0000000
  %1985 = fadd fast float %1982, 0x3FE2E147A0000000
  %1986 = fmul fast float %1983, %1966
  %1987 = fmul fast float %1984, %1967
  %1988 = fmul fast float %1985, %1968
  %1989 = fadd fast float %1986, 0x3FC1EB8520000000
  %1990 = fadd fast float %1987, 0x3FC1EB8520000000
  %1991 = fadd fast float %1988, 0x3FC1EB8520000000
  %1992 = fdiv fast float %1977, %1989
  %1993 = fdiv fast float %1978, %1990
  %1994 = fdiv fast float %1979, %1991
  br label %1995

; <label>:1995                                    ; preds = %1970, %1956
  %1996 = phi float [ %1992, %1970 ], [ %1966, %1956 ]
  %1997 = phi float [ %1993, %1970 ], [ %1967, %1956 ]
  %1998 = phi float [ %1994, %1970 ], [ %1968, %1956 ]
  %1999 = call float @dx.op.unary.f32(i32 7, float %1996)  ; Saturate(value)
  %2000 = call float @dx.op.unary.f32(i32 7, float %1997)  ; Saturate(value)
  %2001 = call float @dx.op.unary.f32(i32 7, float %1998)  ; Saturate(value)
  %2002 = call float @dx.op.dot3.f32(i32 55, float %1999, float %2000, float %2001, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2003 = fsub fast float %1999, %2002
  %2004 = fsub fast float %2000, %2002
  %2005 = fsub fast float %2001, %2002
  %2006 = fmul fast float %2003, %8
  %2007 = fmul fast float %2004, %8
  %2008 = fmul fast float %2005, %8
  %2009 = fadd fast float %2006, %2002
  %2010 = fadd fast float %2007, %2002
  %2011 = fadd fast float %2008, %2002
  %2012 = call float @dx.op.unary.f32(i32 7, float %2009)  ; Saturate(value)
  %2013 = call float @dx.op.unary.f32(i32 7, float %2010)  ; Saturate(value)
  %2014 = call float @dx.op.unary.f32(i32 7, float %2011)  ; Saturate(value)
  %2015 = fadd fast float %2012, 0xBFC70A3D80000000
  %2016 = fadd fast float %2013, 0xBFC70A3D80000000
  %2017 = fadd fast float %2014, 0xBFC70A3D80000000
  %2018 = fmul fast float %2015, %7
  %2019 = fmul fast float %2016, %7
  %2020 = fmul fast float %2017, %7
  %2021 = fadd fast float %2018, 0x3FC70A3D80000000
  %2022 = fadd fast float %2019, 0x3FC70A3D80000000
  %2023 = fadd fast float %2020, 0x3FC70A3D80000000
  %2024 = call float @dx.op.unary.f32(i32 7, float %2021)  ; Saturate(value)
  %2025 = call float @dx.op.unary.f32(i32 7, float %2022)  ; Saturate(value)
  %2026 = call float @dx.op.unary.f32(i32 7, float %2023)  ; Saturate(value)
  br label %2027

; <label>:2027                                    ; preds = %1995, %1830
  %2028 = phi float [ %1861, %1830 ], [ %2024, %1995 ]
  %2029 = phi float [ %1862, %1830 ], [ %2025, %1995 ]
  %2030 = phi float [ %1863, %1830 ], [ %2026, %1995 ]
  %2031 = add i32 %1225, 1
  %2032 = call i32 @dx.op.binary.i32(i32 37, i32 %2031, i32 0)  ; IMax(a,b)
  %2033 = call i32 @dx.op.binary.i32(i32 38, i32 %2032, i32 %59)  ; IMin(a,b)
  %2034 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2033, i32 %1823, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2035 = extractvalue %dx.types.ResRet.f32 %2034, 0
  %2036 = extractvalue %dx.types.ResRet.f32 %2034, 1
  %2037 = extractvalue %dx.types.ResRet.f32 %2034, 2
  %2038 = extractvalue %dx.types.ResRet.f32 %2034, 3
  %2039 = fcmp fast olt float %2038, 0.000000e+00
  br i1 %2039, label %2040, label %2074

; <label>:2040                                    ; preds = %2027
  %2041 = fcmp fast ogt float %2035, 0x3FA4B5DCC0000000
  %2042 = fcmp fast ogt float %2036, 0x3FA4B5DCC0000000
  %2043 = fcmp fast ogt float %2037, 0x3FA4B5DCC0000000
  %2044 = select i1 %2041, float 0.000000e+00, float 1.000000e+00
  %2045 = select i1 %2042, float 0.000000e+00, float 1.000000e+00
  %2046 = select i1 %2043, float 0.000000e+00, float 1.000000e+00
  %2047 = fmul fast float %2035, 0x3FB3D07220000000
  %2048 = fmul fast float %2036, 0x3FB3D07220000000
  %2049 = fmul fast float %2037, 0x3FB3D07220000000
  %2050 = fadd fast float %2035, 0x3FAC28F5C0000000
  %2051 = fadd fast float %2036, 0x3FAC28F5C0000000
  %2052 = fadd fast float %2037, 0x3FAC28F5C0000000
  %2053 = fmul fast float %2050, 0x3FEE54EDE0000000
  %2054 = fmul fast float %2051, 0x3FEE54EDE0000000
  %2055 = fmul fast float %2052, 0x3FEE54EDE0000000
  %2056 = call float @dx.op.unary.f32(i32 23, float %2053)  ; Log(value)
  %2057 = call float @dx.op.unary.f32(i32 23, float %2054)  ; Log(value)
  %2058 = call float @dx.op.unary.f32(i32 23, float %2055)  ; Log(value)
  %2059 = fmul fast float %2056, 0x4003333340000000
  %2060 = fmul fast float %2057, 0x4003333340000000
  %2061 = fmul fast float %2058, 0x4003333340000000
  %2062 = call float @dx.op.unary.f32(i32 21, float %2059)  ; Exp(value)
  %2063 = call float @dx.op.unary.f32(i32 21, float %2060)  ; Exp(value)
  %2064 = call float @dx.op.unary.f32(i32 21, float %2061)  ; Exp(value)
  %2065 = fsub fast float %2047, %2062
  %2066 = fsub fast float %2048, %2063
  %2067 = fsub fast float %2049, %2064
  %2068 = fmul fast float %2065, %2044
  %2069 = fmul fast float %2066, %2045
  %2070 = fmul fast float %2067, %2046
  %2071 = fadd fast float %2068, %2062
  %2072 = fadd fast float %2069, %2063
  %2073 = fadd fast float %2070, %2064
  br label %2237

; <label>:2074                                    ; preds = %2027
  %2075 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2033, i32 %1823, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2076 = extractvalue %dx.types.ResRet.f32 %2075, 0
  %2077 = fcmp fast ogt float %38, 5.000000e-01
  %2078 = fcmp fast olt float %2076, 1.000000e+00
  %2079 = and i1 %2077, %2078
  br i1 %2079, label %2080, label %2166

; <label>:2080                                    ; preds = %2074
  %2081 = sitofp i32 %2033 to float
  %2082 = sitofp i32 %1823 to float
  %2083 = fadd fast float %2081, 5.000000e-01
  %2084 = fadd fast float %2082, 5.000000e-01
  %2085 = fdiv fast float %2083, %45
  %2086 = fdiv fast float %2084, %46
  %2087 = fmul fast float %2085, 2.000000e+00
  %2088 = fmul fast float %2086, 2.000000e+00
  %2089 = fadd fast float %2087, -1.000000e+00
  %2090 = fsub fast float 1.000000e+00, %2088
  %2091 = fmul fast float %2089, %35
  %2092 = call float @dx.op.tertiary.f32(i32 46, float %2090, float %31, float %2091)  ; FMad(a,b,c)
  %2093 = call float @dx.op.tertiary.f32(i32 46, float %2076, float %27, float %2092)  ; FMad(a,b,c)
  %2094 = fadd fast float %2093, %23
  %2095 = call float @dx.op.unary.f32(i32 6, float %2094)  ; FAbs(value)
  %2096 = fcmp fast ogt float %2095, 0x3EB0C6F7A0000000
  br i1 %2096, label %2097, label %2166

; <label>:2097                                    ; preds = %2080
  %2098 = fmul fast float %2089, %34
  %2099 = call float @dx.op.tertiary.f32(i32 46, float %2090, float %30, float %2098)  ; FMad(a,b,c)
  %2100 = call float @dx.op.tertiary.f32(i32 46, float %2076, float %26, float %2099)  ; FMad(a,b,c)
  %2101 = fadd fast float %2100, %22
  %2102 = fmul fast float %2089, %33
  %2103 = call float @dx.op.tertiary.f32(i32 46, float %2090, float %29, float %2102)  ; FMad(a,b,c)
  %2104 = call float @dx.op.tertiary.f32(i32 46, float %2076, float %25, float %2103)  ; FMad(a,b,c)
  %2105 = fadd fast float %2104, %21
  %2106 = fmul fast float %2089, %32
  %2107 = call float @dx.op.tertiary.f32(i32 46, float %2090, float %28, float %2106)  ; FMad(a,b,c)
  %2108 = call float @dx.op.tertiary.f32(i32 46, float %2076, float %24, float %2107)  ; FMad(a,b,c)
  %2109 = fadd fast float %2108, %20
  %2110 = fdiv fast float %2109, %2094
  %2111 = fdiv fast float %2105, %2094
  %2112 = fdiv fast float %2101, %2094
  %2113 = fsub fast float %2110, %17
  %2114 = fsub fast float %2111, %18
  %2115 = fsub fast float %2112, %19
  %2116 = fmul fast float %2113, %2113
  %2117 = fmul fast float %2114, %2114
  %2118 = fadd fast float %2117, %2116
  %2119 = fmul fast float %2115, %2115
  %2120 = fadd fast float %2118, %2119
  %2121 = call float @dx.op.unary.f32(i32 24, float %2120)  ; Sqrt(value)
  %2122 = fsub fast float %2121, %9
  %2123 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2122)  ; FMax(a,b)
  %2124 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %2124, label %2125, label %2148

; <label>:2125                                    ; preds = %2097
  %2126 = call float @dx.op.unary.f32(i32 6, float %2114)  ; FAbs(value)
  %2127 = fmul fast float %2126, %11
  %2128 = fcmp fast olt float %2127, 0x3F50624DE0000000
  br i1 %2128, label %2129, label %2132

; <label>:2129                                    ; preds = %2125
  %2130 = fmul fast float %2127, 5.000000e-01
  %2131 = fsub fast float 1.000000e+00, %2130
  br label %2137

; <label>:2132                                    ; preds = %2125
  %2133 = fmul fast float %2127, 0xBFF7154760000000
  %2134 = call float @dx.op.unary.f32(i32 21, float %2133)  ; Exp(value)
  %2135 = fsub fast float 1.000000e+00, %2134
  %2136 = fdiv fast float %2135, %2127
  br label %2137

; <label>:2137                                    ; preds = %2132, %2129
  %2138 = phi float [ %2131, %2129 ], [ %2136, %2132 ]
  %2139 = call float @dx.op.binary.f32(i32 36, float %2111, float %18)  ; FMin(a,b)
  %2140 = fsub fast float %2139, %10
  %2141 = fmul fast float %11, %2140
  %2142 = fsub fast float -0.000000e+00, %2141
  %2143 = call float @dx.op.binary.f32(i32 35, float %2142, float -4.000000e+01)  ; FMax(a,b)
  %2144 = call float @dx.op.binary.f32(i32 36, float %2143, float 5.000000e+00)  ; FMin(a,b)
  %2145 = fmul fast float %2144, 0x3FF7154760000000
  %2146 = call float @dx.op.unary.f32(i32 21, float %2145)  ; Exp(value)
  %2147 = fmul fast float %2146, %2138
  br label %2148

; <label>:2148                                    ; preds = %2137, %2097
  %2149 = phi float [ %2147, %2137 ], [ 1.000000e+00, %2097 ]
  %2150 = fmul fast float %2123, %16
  %2151 = fmul fast float %2150, %2149
  %2152 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2151)  ; FMin(a,b)
  %2153 = fmul fast float %2152, 0xBFF7154760000000
  %2154 = call float @dx.op.unary.f32(i32 21, float %2153)  ; Exp(value)
  %2155 = fsub fast float 1.000000e+00, %2154
  %2156 = call float @dx.op.binary.f32(i32 36, float %12, float %2155)  ; FMin(a,b)
  %2157 = fsub fast float %13, %2035
  %2158 = fsub fast float %14, %2036
  %2159 = fsub fast float %15, %2037
  %2160 = fmul fast float %2156, %2157
  %2161 = fmul fast float %2156, %2158
  %2162 = fmul fast float %2156, %2159
  %2163 = fadd fast float %2160, %2035
  %2164 = fadd fast float %2161, %2036
  %2165 = fadd fast float %2162, %2037
  br label %2166

; <label>:2166                                    ; preds = %2148, %2080, %2074
  %2167 = phi float [ %2163, %2148 ], [ %2035, %2080 ], [ %2035, %2074 ]
  %2168 = phi float [ %2164, %2148 ], [ %2036, %2080 ], [ %2036, %2074 ]
  %2169 = phi float [ %2165, %2148 ], [ %2037, %2080 ], [ %2037, %2074 ]
  %2170 = fadd fast float %5, 1.000000e+00
  %2171 = fadd fast float %6, 1.000000e+00
  %2172 = fsub fast float 1.000000e+00, %5
  %2173 = fmul fast float %36, %2170
  %2174 = fmul fast float %36, %2171
  %2175 = fmul fast float %36, %2172
  %2176 = fmul fast float %2173, %2167
  %2177 = fmul fast float %2174, %2168
  %2178 = fmul fast float %2175, %2169
  %2179 = fcmp fast ult float %37, 5.000000e-01
  br i1 %2179, label %2205, label %2180

; <label>:2180                                    ; preds = %2166
  %2181 = fmul fast float %2176, 0x4004147AE0000000
  %2182 = fmul fast float %2177, 0x4004147AE0000000
  %2183 = fmul fast float %2178, 0x4004147AE0000000
  %2184 = fadd fast float %2181, 0x3F9EB851E0000000
  %2185 = fadd fast float %2182, 0x3F9EB851E0000000
  %2186 = fadd fast float %2183, 0x3F9EB851E0000000
  %2187 = fmul fast float %2184, %2176
  %2188 = fmul fast float %2185, %2177
  %2189 = fmul fast float %2186, %2178
  %2190 = fmul fast float %2176, 0x400370A3E0000000
  %2191 = fmul fast float %2177, 0x400370A3E0000000
  %2192 = fmul fast float %2178, 0x400370A3E0000000
  %2193 = fadd fast float %2190, 0x3FE2E147A0000000
  %2194 = fadd fast float %2191, 0x3FE2E147A0000000
  %2195 = fadd fast float %2192, 0x3FE2E147A0000000
  %2196 = fmul fast float %2193, %2176
  %2197 = fmul fast float %2194, %2177
  %2198 = fmul fast float %2195, %2178
  %2199 = fadd fast float %2196, 0x3FC1EB8520000000
  %2200 = fadd fast float %2197, 0x3FC1EB8520000000
  %2201 = fadd fast float %2198, 0x3FC1EB8520000000
  %2202 = fdiv fast float %2187, %2199
  %2203 = fdiv fast float %2188, %2200
  %2204 = fdiv fast float %2189, %2201
  br label %2205

; <label>:2205                                    ; preds = %2180, %2166
  %2206 = phi float [ %2202, %2180 ], [ %2176, %2166 ]
  %2207 = phi float [ %2203, %2180 ], [ %2177, %2166 ]
  %2208 = phi float [ %2204, %2180 ], [ %2178, %2166 ]
  %2209 = call float @dx.op.unary.f32(i32 7, float %2206)  ; Saturate(value)
  %2210 = call float @dx.op.unary.f32(i32 7, float %2207)  ; Saturate(value)
  %2211 = call float @dx.op.unary.f32(i32 7, float %2208)  ; Saturate(value)
  %2212 = call float @dx.op.dot3.f32(i32 55, float %2209, float %2210, float %2211, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2213 = fsub fast float %2209, %2212
  %2214 = fsub fast float %2210, %2212
  %2215 = fsub fast float %2211, %2212
  %2216 = fmul fast float %2213, %8
  %2217 = fmul fast float %2214, %8
  %2218 = fmul fast float %2215, %8
  %2219 = fadd fast float %2216, %2212
  %2220 = fadd fast float %2217, %2212
  %2221 = fadd fast float %2218, %2212
  %2222 = call float @dx.op.unary.f32(i32 7, float %2219)  ; Saturate(value)
  %2223 = call float @dx.op.unary.f32(i32 7, float %2220)  ; Saturate(value)
  %2224 = call float @dx.op.unary.f32(i32 7, float %2221)  ; Saturate(value)
  %2225 = fadd fast float %2222, 0xBFC70A3D80000000
  %2226 = fadd fast float %2223, 0xBFC70A3D80000000
  %2227 = fadd fast float %2224, 0xBFC70A3D80000000
  %2228 = fmul fast float %2225, %7
  %2229 = fmul fast float %2226, %7
  %2230 = fmul fast float %2227, %7
  %2231 = fadd fast float %2228, 0x3FC70A3D80000000
  %2232 = fadd fast float %2229, 0x3FC70A3D80000000
  %2233 = fadd fast float %2230, 0x3FC70A3D80000000
  %2234 = call float @dx.op.unary.f32(i32 7, float %2231)  ; Saturate(value)
  %2235 = call float @dx.op.unary.f32(i32 7, float %2232)  ; Saturate(value)
  %2236 = call float @dx.op.unary.f32(i32 7, float %2233)  ; Saturate(value)
  br label %2237

; <label>:2237                                    ; preds = %2205, %2040
  %2238 = phi float [ %2071, %2040 ], [ %2234, %2205 ]
  %2239 = phi float [ %2072, %2040 ], [ %2235, %2205 ]
  %2240 = phi float [ %2073, %2040 ], [ %2236, %2205 ]
  %2241 = call float @dx.op.binary.f32(i32 36, float %2028, float %2238)  ; FMin(a,b)
  %2242 = call float @dx.op.binary.f32(i32 36, float %2029, float %2239)  ; FMin(a,b)
  %2243 = call float @dx.op.binary.f32(i32 36, float %2030, float %2240)  ; FMin(a,b)
  %2244 = call float @dx.op.binary.f32(i32 36, float %1606, float %1816)  ; FMin(a,b)
  %2245 = call float @dx.op.binary.f32(i32 36, float %1607, float %1817)  ; FMin(a,b)
  %2246 = call float @dx.op.binary.f32(i32 36, float %1608, float %1818)  ; FMin(a,b)
  %2247 = call float @dx.op.binary.f32(i32 36, float %2244, float %2241)  ; FMin(a,b)
  %2248 = call float @dx.op.binary.f32(i32 36, float %2245, float %2242)  ; FMin(a,b)
  %2249 = call float @dx.op.binary.f32(i32 36, float %2246, float %2243)  ; FMin(a,b)
  %2250 = call float @dx.op.binary.f32(i32 36, float %1394, float %2247)  ; FMin(a,b)
  %2251 = call float @dx.op.binary.f32(i32 36, float %1395, float %2248)  ; FMin(a,b)
  %2252 = call float @dx.op.binary.f32(i32 36, float %1396, float %2249)  ; FMin(a,b)
  %2253 = call float @dx.op.binary.f32(i32 35, float %2028, float %2238)  ; FMax(a,b)
  %2254 = call float @dx.op.binary.f32(i32 35, float %2029, float %2239)  ; FMax(a,b)
  %2255 = call float @dx.op.binary.f32(i32 35, float %2030, float %2240)  ; FMax(a,b)
  %2256 = call float @dx.op.binary.f32(i32 35, float %1606, float %1816)  ; FMax(a,b)
  %2257 = call float @dx.op.binary.f32(i32 35, float %1607, float %1817)  ; FMax(a,b)
  %2258 = call float @dx.op.binary.f32(i32 35, float %1608, float %1818)  ; FMax(a,b)
  %2259 = call float @dx.op.binary.f32(i32 35, float %2256, float %2253)  ; FMax(a,b)
  %2260 = call float @dx.op.binary.f32(i32 35, float %2257, float %2254)  ; FMax(a,b)
  %2261 = call float @dx.op.binary.f32(i32 35, float %2258, float %2255)  ; FMax(a,b)
  %2262 = call float @dx.op.binary.f32(i32 35, float %1394, float %2259)  ; FMax(a,b)
  %2263 = call float @dx.op.binary.f32(i32 35, float %1395, float %2260)  ; FMax(a,b)
  %2264 = call float @dx.op.binary.f32(i32 35, float %1396, float %2261)  ; FMax(a,b)
  %2265 = fsub fast float %2262, %2250
  %2266 = fsub fast float %2263, %2251
  %2267 = fsub fast float %2264, %2252
  %2268 = call float @dx.op.unary.f32(i32 6, float %2265)  ; FAbs(value)
  %2269 = call float @dx.op.unary.f32(i32 6, float %2266)  ; FAbs(value)
  %2270 = call float @dx.op.unary.f32(i32 6, float %2267)  ; FAbs(value)
  %2271 = call float @dx.op.binary.f32(i32 35, float %2269, float %2270)  ; FMax(a,b)
  %2272 = call float @dx.op.binary.f32(i32 35, float %2268, float %2271)  ; FMax(a,b)
  %2273 = call float @dx.op.binary.f32(i32 35, float %2263, float %2264)  ; FMax(a,b)
  %2274 = call float @dx.op.binary.f32(i32 35, float %2262, float %2273)  ; FMax(a,b)
  %2275 = fmul fast float %2274, 1.250000e-01
  %2276 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %2275)  ; FMax(a,b)
  %2277 = fcmp fast ogt float %2272, %2276
  br i1 %2277, label %2278, label %2339

; <label>:2278                                    ; preds = %2237
  %2279 = fsub fast float %1606, %1816
  %2280 = fsub fast float %1607, %1817
  %2281 = fsub fast float %1608, %1818
  %2282 = call float @dx.op.unary.f32(i32 6, float %2279)  ; FAbs(value)
  %2283 = call float @dx.op.unary.f32(i32 6, float %2280)  ; FAbs(value)
  %2284 = call float @dx.op.unary.f32(i32 6, float %2281)  ; FAbs(value)
  %2285 = call float @dx.op.binary.f32(i32 35, float %2283, float %2284)  ; FMax(a,b)
  %2286 = call float @dx.op.binary.f32(i32 35, float %2282, float %2285)  ; FMax(a,b)
  %2287 = fsub fast float %2028, %2238
  %2288 = fsub fast float %2029, %2239
  %2289 = fsub fast float %2030, %2240
  %2290 = call float @dx.op.unary.f32(i32 6, float %2287)  ; FAbs(value)
  %2291 = call float @dx.op.unary.f32(i32 6, float %2288)  ; FAbs(value)
  %2292 = call float @dx.op.unary.f32(i32 6, float %2289)  ; FAbs(value)
  %2293 = call float @dx.op.binary.f32(i32 35, float %2291, float %2292)  ; FMax(a,b)
  %2294 = call float @dx.op.binary.f32(i32 35, float %2290, float %2293)  ; FMax(a,b)
  %2295 = fcmp fast olt float %2286, %2294
  %2296 = select i1 %2295, float %1606, float %2028
  %2297 = select i1 %2295, float %1607, float %2029
  %2298 = select i1 %2295, float %1608, float %2030
  %2299 = select i1 %2295, float %1816, float %2238
  %2300 = select i1 %2295, float %1817, float %2239
  %2301 = select i1 %2295, float %1818, float %2240
  %2302 = fsub fast float %1394, %2299
  %2303 = fsub fast float %1395, %2300
  %2304 = fsub fast float %1396, %2301
  %2305 = fsub fast float %1394, %2296
  %2306 = fsub fast float %1395, %2297
  %2307 = fsub fast float %1396, %2298
  %2308 = call float @dx.op.dot3.f32(i32 55, float %2305, float %2306, float %2307, float %2302, float %2303, float %2304)  ; Dot3(ax,ay,az,bx,by,bz)
  %2309 = fcmp fast ogt float %2308, 0.000000e+00
  br i1 %2309, label %2310, label %2321

; <label>:2310                                    ; preds = %2278
  %2311 = fsub fast float %2296, %2299
  %2312 = fsub fast float %2297, %2300
  %2313 = fsub fast float %2298, %2301
  %2314 = call float @dx.op.unary.f32(i32 6, float %2311)  ; FAbs(value)
  %2315 = call float @dx.op.unary.f32(i32 6, float %2312)  ; FAbs(value)
  %2316 = call float @dx.op.unary.f32(i32 6, float %2313)  ; FAbs(value)
  %2317 = call float @dx.op.binary.f32(i32 35, float %2315, float %2316)  ; FMax(a,b)
  %2318 = call float @dx.op.binary.f32(i32 35, float %2314, float %2317)  ; FMax(a,b)
  %2319 = fmul fast float %2272, 2.500000e-01
  %2320 = fcmp fast olt float %2318, %2319
  br label %2321

; <label>:2321                                    ; preds = %2310, %2278
  %2322 = phi i1 [ false, %2278 ], [ %2320, %2310 ]
  %2323 = select i1 %2322, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  %2324 = fadd fast float %2296, %2299
  %2325 = fadd fast float %2297, %2300
  %2326 = fadd fast float %2298, %2301
  %2327 = fmul fast float %2324, 5.000000e-01
  %2328 = fmul fast float %2325, 5.000000e-01
  %2329 = fmul fast float %2326, 5.000000e-01
  %2330 = fsub fast float %2327, %1394
  %2331 = fsub fast float %2328, %1395
  %2332 = fsub fast float %2329, %1396
  %2333 = fmul fast float %2323, %2330
  %2334 = fmul fast float %2323, %2331
  %2335 = fmul fast float %2323, %2332
  %2336 = fadd fast float %2333, %1394
  %2337 = fadd fast float %2334, %1395
  %2338 = fadd fast float %2335, %1396
  br label %2339

; <label>:2339                                    ; preds = %2321, %2237
  %2340 = phi float [ %2336, %2321 ], [ %1394, %2237 ]
  %2341 = phi float [ %2337, %2321 ], [ %1395, %2237 ]
  %2342 = phi float [ %2338, %2321 ], [ %1396, %2237 ]
  %2343 = fcmp fast ogt float %2340, 0x3F69A5C380000000
  %2344 = fcmp fast ogt float %2341, 0x3F69A5C380000000
  %2345 = fcmp fast ogt float %2342, 0x3F69A5C380000000
  %2346 = select i1 %2343, float 0.000000e+00, float 1.000000e+00
  %2347 = select i1 %2344, float 0.000000e+00, float 1.000000e+00
  %2348 = select i1 %2345, float 0.000000e+00, float 1.000000e+00
  %2349 = fmul fast float %2340, 0x4029D70A40000000
  %2350 = fmul fast float %2341, 0x4029D70A40000000
  %2351 = fmul fast float %2342, 0x4029D70A40000000
  %2352 = call float @dx.op.binary.f32(i32 35, float %2340, float 0.000000e+00)  ; FMax(a,b)
  %2353 = call float @dx.op.binary.f32(i32 35, float %2341, float 0.000000e+00)  ; FMax(a,b)
  %2354 = call float @dx.op.binary.f32(i32 35, float %2342, float 0.000000e+00)  ; FMax(a,b)
  %2355 = call float @dx.op.unary.f32(i32 23, float %2352)  ; Log(value)
  %2356 = call float @dx.op.unary.f32(i32 23, float %2353)  ; Log(value)
  %2357 = call float @dx.op.unary.f32(i32 23, float %2354)  ; Log(value)
  %2358 = fmul fast float %2355, 0x3FDAAAAAA0000000
  %2359 = fmul fast float %2356, 0x3FDAAAAAA0000000
  %2360 = fmul fast float %2357, 0x3FDAAAAAA0000000
  %2361 = call float @dx.op.unary.f32(i32 21, float %2358)  ; Exp(value)
  %2362 = call float @dx.op.unary.f32(i32 21, float %2359)  ; Exp(value)
  %2363 = call float @dx.op.unary.f32(i32 21, float %2360)  ; Exp(value)
  %2364 = fmul fast float %2361, 0x3FF0E147A0000000
  %2365 = fmul fast float %2362, 0x3FF0E147A0000000
  %2366 = fmul fast float %2363, 0x3FF0E147A0000000
  %2367 = fadd fast float %2364, 0xBFAC28F5C0000000
  %2368 = fadd fast float %2365, 0xBFAC28F5C0000000
  %2369 = fadd fast float %2366, 0xBFAC28F5C0000000
  %2370 = fsub fast float %2349, %2367
  %2371 = fsub fast float %2350, %2368
  %2372 = fsub fast float %2351, %2369
  %2373 = fmul fast float %2370, %2346
  %2374 = fmul fast float %2371, %2347
  %2375 = fmul fast float %2372, %2348
  %2376 = fadd fast float %2373, %2367
  %2377 = fadd fast float %2374, %2368
  %2378 = fadd fast float %2375, %2369
  br label %2379

; <label>:2379                                    ; preds = %2339, %1232
  %2380 = phi float [ %1227, %1232 ], [ %2376, %2339 ]
  %2381 = phi float [ %1228, %1232 ], [ %2377, %2339 ]
  %2382 = phi float [ %1229, %1232 ], [ %2378, %2339 ]
  %2383 = phi float [ %1233, %1232 ], [ %1230, %2339 ]
  %2384 = add i32 %56, 1
  %2385 = call i32 @dx.op.binary.i32(i32 37, i32 %2384, i32 0)  ; IMax(a,b)
  %2386 = call i32 @dx.op.binary.i32(i32 38, i32 %2385, i32 %60)  ; IMin(a,b)
  %2387 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %63, i32 %2386, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2388 = extractvalue %dx.types.ResRet.f32 %2387, 0
  %2389 = extractvalue %dx.types.ResRet.f32 %2387, 1
  %2390 = extractvalue %dx.types.ResRet.f32 %2387, 2
  %2391 = extractvalue %dx.types.ResRet.f32 %2387, 3
  %2392 = fcmp fast olt float %2391, 0.000000e+00
  br i1 %2392, label %2393, label %2395

; <label>:2393                                    ; preds = %2379
  %2394 = fsub fast float -1.000000e+00, %2391
  br label %3540

; <label>:2395                                    ; preds = %2379
  %2396 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %2386, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2397 = extractvalue %dx.types.ResRet.f32 %2396, 0
  %2398 = fcmp fast ogt float %38, 5.000000e-01
  %2399 = fcmp fast olt float %2397, 1.000000e+00
  %2400 = and i1 %2398, %2399
  br i1 %2400, label %2401, label %2487

; <label>:2401                                    ; preds = %2395
  %2402 = sitofp i32 %63 to float
  %2403 = sitofp i32 %2386 to float
  %2404 = fadd fast float %2402, 5.000000e-01
  %2405 = fadd fast float %2403, 5.000000e-01
  %2406 = fdiv fast float %2404, %45
  %2407 = fdiv fast float %2405, %46
  %2408 = fmul fast float %2406, 2.000000e+00
  %2409 = fmul fast float %2407, 2.000000e+00
  %2410 = fadd fast float %2408, -1.000000e+00
  %2411 = fsub fast float 1.000000e+00, %2409
  %2412 = fmul fast float %2410, %35
  %2413 = call float @dx.op.tertiary.f32(i32 46, float %2411, float %31, float %2412)  ; FMad(a,b,c)
  %2414 = call float @dx.op.tertiary.f32(i32 46, float %2397, float %27, float %2413)  ; FMad(a,b,c)
  %2415 = fadd fast float %2414, %23
  %2416 = call float @dx.op.unary.f32(i32 6, float %2415)  ; FAbs(value)
  %2417 = fcmp fast ogt float %2416, 0x3EB0C6F7A0000000
  br i1 %2417, label %2418, label %2487

; <label>:2418                                    ; preds = %2401
  %2419 = fmul fast float %2410, %34
  %2420 = call float @dx.op.tertiary.f32(i32 46, float %2411, float %30, float %2419)  ; FMad(a,b,c)
  %2421 = call float @dx.op.tertiary.f32(i32 46, float %2397, float %26, float %2420)  ; FMad(a,b,c)
  %2422 = fadd fast float %2421, %22
  %2423 = fmul fast float %2410, %33
  %2424 = call float @dx.op.tertiary.f32(i32 46, float %2411, float %29, float %2423)  ; FMad(a,b,c)
  %2425 = call float @dx.op.tertiary.f32(i32 46, float %2397, float %25, float %2424)  ; FMad(a,b,c)
  %2426 = fadd fast float %2425, %21
  %2427 = fmul fast float %2410, %32
  %2428 = call float @dx.op.tertiary.f32(i32 46, float %2411, float %28, float %2427)  ; FMad(a,b,c)
  %2429 = call float @dx.op.tertiary.f32(i32 46, float %2397, float %24, float %2428)  ; FMad(a,b,c)
  %2430 = fadd fast float %2429, %20
  %2431 = fdiv fast float %2430, %2415
  %2432 = fdiv fast float %2426, %2415
  %2433 = fdiv fast float %2422, %2415
  %2434 = fsub fast float %2431, %17
  %2435 = fsub fast float %2432, %18
  %2436 = fsub fast float %2433, %19
  %2437 = fmul fast float %2434, %2434
  %2438 = fmul fast float %2435, %2435
  %2439 = fadd fast float %2438, %2437
  %2440 = fmul fast float %2436, %2436
  %2441 = fadd fast float %2439, %2440
  %2442 = call float @dx.op.unary.f32(i32 24, float %2441)  ; Sqrt(value)
  %2443 = fsub fast float %2442, %9
  %2444 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2443)  ; FMax(a,b)
  %2445 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %2445, label %2446, label %2469

; <label>:2446                                    ; preds = %2418
  %2447 = call float @dx.op.unary.f32(i32 6, float %2435)  ; FAbs(value)
  %2448 = fmul fast float %2447, %11
  %2449 = fcmp fast olt float %2448, 0x3F50624DE0000000
  br i1 %2449, label %2450, label %2453

; <label>:2450                                    ; preds = %2446
  %2451 = fmul fast float %2448, 5.000000e-01
  %2452 = fsub fast float 1.000000e+00, %2451
  br label %2458

; <label>:2453                                    ; preds = %2446
  %2454 = fmul fast float %2448, 0xBFF7154760000000
  %2455 = call float @dx.op.unary.f32(i32 21, float %2454)  ; Exp(value)
  %2456 = fsub fast float 1.000000e+00, %2455
  %2457 = fdiv fast float %2456, %2448
  br label %2458

; <label>:2458                                    ; preds = %2453, %2450
  %2459 = phi float [ %2452, %2450 ], [ %2457, %2453 ]
  %2460 = call float @dx.op.binary.f32(i32 36, float %2432, float %18)  ; FMin(a,b)
  %2461 = fsub fast float %2460, %10
  %2462 = fmul fast float %11, %2461
  %2463 = fsub fast float -0.000000e+00, %2462
  %2464 = call float @dx.op.binary.f32(i32 35, float %2463, float -4.000000e+01)  ; FMax(a,b)
  %2465 = call float @dx.op.binary.f32(i32 36, float %2464, float 5.000000e+00)  ; FMin(a,b)
  %2466 = fmul fast float %2465, 0x3FF7154760000000
  %2467 = call float @dx.op.unary.f32(i32 21, float %2466)  ; Exp(value)
  %2468 = fmul fast float %2467, %2459
  br label %2469

; <label>:2469                                    ; preds = %2458, %2418
  %2470 = phi float [ %2468, %2458 ], [ 1.000000e+00, %2418 ]
  %2471 = fmul fast float %2444, %16
  %2472 = fmul fast float %2471, %2470
  %2473 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2472)  ; FMin(a,b)
  %2474 = fmul fast float %2473, 0xBFF7154760000000
  %2475 = call float @dx.op.unary.f32(i32 21, float %2474)  ; Exp(value)
  %2476 = fsub fast float 1.000000e+00, %2475
  %2477 = call float @dx.op.binary.f32(i32 36, float %12, float %2476)  ; FMin(a,b)
  %2478 = fsub fast float %13, %2388
  %2479 = fsub fast float %14, %2389
  %2480 = fsub fast float %15, %2390
  %2481 = fmul fast float %2477, %2478
  %2482 = fmul fast float %2477, %2479
  %2483 = fmul fast float %2477, %2480
  %2484 = fadd fast float %2481, %2388
  %2485 = fadd fast float %2482, %2389
  %2486 = fadd fast float %2483, %2390
  br label %2487

; <label>:2487                                    ; preds = %2469, %2401, %2395
  %2488 = phi float [ %2484, %2469 ], [ %2388, %2401 ], [ %2388, %2395 ]
  %2489 = phi float [ %2485, %2469 ], [ %2389, %2401 ], [ %2389, %2395 ]
  %2490 = phi float [ %2486, %2469 ], [ %2390, %2401 ], [ %2390, %2395 ]
  %2491 = fadd fast float %5, 1.000000e+00
  %2492 = fadd fast float %6, 1.000000e+00
  %2493 = fsub fast float 1.000000e+00, %5
  %2494 = fmul fast float %36, %2491
  %2495 = fmul fast float %36, %2492
  %2496 = fmul fast float %36, %2493
  %2497 = fmul fast float %2494, %2488
  %2498 = fmul fast float %2495, %2489
  %2499 = fmul fast float %2496, %2490
  %2500 = fcmp fast ult float %37, 5.000000e-01
  br i1 %2500, label %2526, label %2501

; <label>:2501                                    ; preds = %2487
  %2502 = fmul fast float %2497, 0x4004147AE0000000
  %2503 = fmul fast float %2498, 0x4004147AE0000000
  %2504 = fmul fast float %2499, 0x4004147AE0000000
  %2505 = fadd fast float %2502, 0x3F9EB851E0000000
  %2506 = fadd fast float %2503, 0x3F9EB851E0000000
  %2507 = fadd fast float %2504, 0x3F9EB851E0000000
  %2508 = fmul fast float %2505, %2497
  %2509 = fmul fast float %2506, %2498
  %2510 = fmul fast float %2507, %2499
  %2511 = fmul fast float %2497, 0x400370A3E0000000
  %2512 = fmul fast float %2498, 0x400370A3E0000000
  %2513 = fmul fast float %2499, 0x400370A3E0000000
  %2514 = fadd fast float %2511, 0x3FE2E147A0000000
  %2515 = fadd fast float %2512, 0x3FE2E147A0000000
  %2516 = fadd fast float %2513, 0x3FE2E147A0000000
  %2517 = fmul fast float %2514, %2497
  %2518 = fmul fast float %2515, %2498
  %2519 = fmul fast float %2516, %2499
  %2520 = fadd fast float %2517, 0x3FC1EB8520000000
  %2521 = fadd fast float %2518, 0x3FC1EB8520000000
  %2522 = fadd fast float %2519, 0x3FC1EB8520000000
  %2523 = fdiv fast float %2508, %2520
  %2524 = fdiv fast float %2509, %2521
  %2525 = fdiv fast float %2510, %2522
  br label %2526

; <label>:2526                                    ; preds = %2501, %2487
  %2527 = phi float [ %2523, %2501 ], [ %2497, %2487 ]
  %2528 = phi float [ %2524, %2501 ], [ %2498, %2487 ]
  %2529 = phi float [ %2525, %2501 ], [ %2499, %2487 ]
  %2530 = call float @dx.op.unary.f32(i32 7, float %2527)  ; Saturate(value)
  %2531 = call float @dx.op.unary.f32(i32 7, float %2528)  ; Saturate(value)
  %2532 = call float @dx.op.unary.f32(i32 7, float %2529)  ; Saturate(value)
  %2533 = call float @dx.op.dot3.f32(i32 55, float %2530, float %2531, float %2532, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2534 = fsub fast float %2530, %2533
  %2535 = fsub fast float %2531, %2533
  %2536 = fsub fast float %2532, %2533
  %2537 = fmul fast float %2534, %8
  %2538 = fmul fast float %2535, %8
  %2539 = fmul fast float %2536, %8
  %2540 = fadd fast float %2537, %2533
  %2541 = fadd fast float %2538, %2533
  %2542 = fadd fast float %2539, %2533
  %2543 = call float @dx.op.unary.f32(i32 7, float %2540)  ; Saturate(value)
  %2544 = call float @dx.op.unary.f32(i32 7, float %2541)  ; Saturate(value)
  %2545 = call float @dx.op.unary.f32(i32 7, float %2542)  ; Saturate(value)
  %2546 = fadd fast float %2543, 0xBFC70A3D80000000
  %2547 = fadd fast float %2544, 0xBFC70A3D80000000
  %2548 = fadd fast float %2545, 0xBFC70A3D80000000
  %2549 = fmul fast float %2546, %7
  %2550 = fmul fast float %2547, %7
  %2551 = fmul fast float %2548, %7
  %2552 = fadd fast float %2549, 0x3FC70A3D80000000
  %2553 = fadd fast float %2550, 0x3FC70A3D80000000
  %2554 = fadd fast float %2551, 0x3FC70A3D80000000
  %2555 = call float @dx.op.unary.f32(i32 7, float %2552)  ; Saturate(value)
  %2556 = call float @dx.op.unary.f32(i32 7, float %2553)  ; Saturate(value)
  %2557 = call float @dx.op.unary.f32(i32 7, float %2554)  ; Saturate(value)
  %2558 = add i32 %2386, -1
  %2559 = call i32 @dx.op.binary.i32(i32 37, i32 %63, i32 0)  ; IMax(a,b)
  %2560 = call i32 @dx.op.binary.i32(i32 37, i32 %2558, i32 0)  ; IMax(a,b)
  %2561 = call i32 @dx.op.binary.i32(i32 38, i32 %2559, i32 %59)  ; IMin(a,b)
  %2562 = call i32 @dx.op.binary.i32(i32 38, i32 %2560, i32 %60)  ; IMin(a,b)
  %2563 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2561, i32 %2562, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2564 = extractvalue %dx.types.ResRet.f32 %2563, 0
  %2565 = extractvalue %dx.types.ResRet.f32 %2563, 1
  %2566 = extractvalue %dx.types.ResRet.f32 %2563, 2
  %2567 = extractvalue %dx.types.ResRet.f32 %2563, 3
  %2568 = fcmp fast olt float %2567, 0.000000e+00
  br i1 %2568, label %2569, label %2603

; <label>:2569                                    ; preds = %2526
  %2570 = fcmp fast ogt float %2564, 0x3FA4B5DCC0000000
  %2571 = fcmp fast ogt float %2565, 0x3FA4B5DCC0000000
  %2572 = fcmp fast ogt float %2566, 0x3FA4B5DCC0000000
  %2573 = select i1 %2570, float 0.000000e+00, float 1.000000e+00
  %2574 = select i1 %2571, float 0.000000e+00, float 1.000000e+00
  %2575 = select i1 %2572, float 0.000000e+00, float 1.000000e+00
  %2576 = fmul fast float %2564, 0x3FB3D07220000000
  %2577 = fmul fast float %2565, 0x3FB3D07220000000
  %2578 = fmul fast float %2566, 0x3FB3D07220000000
  %2579 = fadd fast float %2564, 0x3FAC28F5C0000000
  %2580 = fadd fast float %2565, 0x3FAC28F5C0000000
  %2581 = fadd fast float %2566, 0x3FAC28F5C0000000
  %2582 = fmul fast float %2579, 0x3FEE54EDE0000000
  %2583 = fmul fast float %2580, 0x3FEE54EDE0000000
  %2584 = fmul fast float %2581, 0x3FEE54EDE0000000
  %2585 = call float @dx.op.unary.f32(i32 23, float %2582)  ; Log(value)
  %2586 = call float @dx.op.unary.f32(i32 23, float %2583)  ; Log(value)
  %2587 = call float @dx.op.unary.f32(i32 23, float %2584)  ; Log(value)
  %2588 = fmul fast float %2585, 0x4003333340000000
  %2589 = fmul fast float %2586, 0x4003333340000000
  %2590 = fmul fast float %2587, 0x4003333340000000
  %2591 = call float @dx.op.unary.f32(i32 21, float %2588)  ; Exp(value)
  %2592 = call float @dx.op.unary.f32(i32 21, float %2589)  ; Exp(value)
  %2593 = call float @dx.op.unary.f32(i32 21, float %2590)  ; Exp(value)
  %2594 = fsub fast float %2576, %2591
  %2595 = fsub fast float %2577, %2592
  %2596 = fsub fast float %2578, %2593
  %2597 = fmul fast float %2594, %2573
  %2598 = fmul fast float %2595, %2574
  %2599 = fmul fast float %2596, %2575
  %2600 = fadd fast float %2597, %2591
  %2601 = fadd fast float %2598, %2592
  %2602 = fadd fast float %2599, %2593
  br label %2766

; <label>:2603                                    ; preds = %2526
  %2604 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2561, i32 %2562, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2605 = extractvalue %dx.types.ResRet.f32 %2604, 0
  %2606 = fcmp fast ogt float %38, 5.000000e-01
  %2607 = fcmp fast olt float %2605, 1.000000e+00
  %2608 = and i1 %2606, %2607
  br i1 %2608, label %2609, label %2695

; <label>:2609                                    ; preds = %2603
  %2610 = sitofp i32 %2561 to float
  %2611 = sitofp i32 %2562 to float
  %2612 = fadd fast float %2610, 5.000000e-01
  %2613 = fadd fast float %2611, 5.000000e-01
  %2614 = fdiv fast float %2612, %45
  %2615 = fdiv fast float %2613, %46
  %2616 = fmul fast float %2614, 2.000000e+00
  %2617 = fmul fast float %2615, 2.000000e+00
  %2618 = fadd fast float %2616, -1.000000e+00
  %2619 = fsub fast float 1.000000e+00, %2617
  %2620 = fmul fast float %2618, %35
  %2621 = call float @dx.op.tertiary.f32(i32 46, float %2619, float %31, float %2620)  ; FMad(a,b,c)
  %2622 = call float @dx.op.tertiary.f32(i32 46, float %2605, float %27, float %2621)  ; FMad(a,b,c)
  %2623 = fadd fast float %2622, %23
  %2624 = call float @dx.op.unary.f32(i32 6, float %2623)  ; FAbs(value)
  %2625 = fcmp fast ogt float %2624, 0x3EB0C6F7A0000000
  br i1 %2625, label %2626, label %2695

; <label>:2626                                    ; preds = %2609
  %2627 = fmul fast float %2618, %34
  %2628 = call float @dx.op.tertiary.f32(i32 46, float %2619, float %30, float %2627)  ; FMad(a,b,c)
  %2629 = call float @dx.op.tertiary.f32(i32 46, float %2605, float %26, float %2628)  ; FMad(a,b,c)
  %2630 = fadd fast float %2629, %22
  %2631 = fmul fast float %2618, %33
  %2632 = call float @dx.op.tertiary.f32(i32 46, float %2619, float %29, float %2631)  ; FMad(a,b,c)
  %2633 = call float @dx.op.tertiary.f32(i32 46, float %2605, float %25, float %2632)  ; FMad(a,b,c)
  %2634 = fadd fast float %2633, %21
  %2635 = fmul fast float %2618, %32
  %2636 = call float @dx.op.tertiary.f32(i32 46, float %2619, float %28, float %2635)  ; FMad(a,b,c)
  %2637 = call float @dx.op.tertiary.f32(i32 46, float %2605, float %24, float %2636)  ; FMad(a,b,c)
  %2638 = fadd fast float %2637, %20
  %2639 = fdiv fast float %2638, %2623
  %2640 = fdiv fast float %2634, %2623
  %2641 = fdiv fast float %2630, %2623
  %2642 = fsub fast float %2639, %17
  %2643 = fsub fast float %2640, %18
  %2644 = fsub fast float %2641, %19
  %2645 = fmul fast float %2642, %2642
  %2646 = fmul fast float %2643, %2643
  %2647 = fadd fast float %2646, %2645
  %2648 = fmul fast float %2644, %2644
  %2649 = fadd fast float %2647, %2648
  %2650 = call float @dx.op.unary.f32(i32 24, float %2649)  ; Sqrt(value)
  %2651 = fsub fast float %2650, %9
  %2652 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2651)  ; FMax(a,b)
  %2653 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %2653, label %2654, label %2677

; <label>:2654                                    ; preds = %2626
  %2655 = call float @dx.op.unary.f32(i32 6, float %2643)  ; FAbs(value)
  %2656 = fmul fast float %2655, %11
  %2657 = fcmp fast olt float %2656, 0x3F50624DE0000000
  br i1 %2657, label %2658, label %2661

; <label>:2658                                    ; preds = %2654
  %2659 = fmul fast float %2656, 5.000000e-01
  %2660 = fsub fast float 1.000000e+00, %2659
  br label %2666

; <label>:2661                                    ; preds = %2654
  %2662 = fmul fast float %2656, 0xBFF7154760000000
  %2663 = call float @dx.op.unary.f32(i32 21, float %2662)  ; Exp(value)
  %2664 = fsub fast float 1.000000e+00, %2663
  %2665 = fdiv fast float %2664, %2656
  br label %2666

; <label>:2666                                    ; preds = %2661, %2658
  %2667 = phi float [ %2660, %2658 ], [ %2665, %2661 ]
  %2668 = call float @dx.op.binary.f32(i32 36, float %2640, float %18)  ; FMin(a,b)
  %2669 = fsub fast float %2668, %10
  %2670 = fmul fast float %11, %2669
  %2671 = fsub fast float -0.000000e+00, %2670
  %2672 = call float @dx.op.binary.f32(i32 35, float %2671, float -4.000000e+01)  ; FMax(a,b)
  %2673 = call float @dx.op.binary.f32(i32 36, float %2672, float 5.000000e+00)  ; FMin(a,b)
  %2674 = fmul fast float %2673, 0x3FF7154760000000
  %2675 = call float @dx.op.unary.f32(i32 21, float %2674)  ; Exp(value)
  %2676 = fmul fast float %2675, %2667
  br label %2677

; <label>:2677                                    ; preds = %2666, %2626
  %2678 = phi float [ %2676, %2666 ], [ 1.000000e+00, %2626 ]
  %2679 = fmul fast float %2652, %16
  %2680 = fmul fast float %2679, %2678
  %2681 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2680)  ; FMin(a,b)
  %2682 = fmul fast float %2681, 0xBFF7154760000000
  %2683 = call float @dx.op.unary.f32(i32 21, float %2682)  ; Exp(value)
  %2684 = fsub fast float 1.000000e+00, %2683
  %2685 = call float @dx.op.binary.f32(i32 36, float %12, float %2684)  ; FMin(a,b)
  %2686 = fsub fast float %13, %2564
  %2687 = fsub fast float %14, %2565
  %2688 = fsub fast float %15, %2566
  %2689 = fmul fast float %2685, %2686
  %2690 = fmul fast float %2685, %2687
  %2691 = fmul fast float %2685, %2688
  %2692 = fadd fast float %2689, %2564
  %2693 = fadd fast float %2690, %2565
  %2694 = fadd fast float %2691, %2566
  br label %2695

; <label>:2695                                    ; preds = %2677, %2609, %2603
  %2696 = phi float [ %2692, %2677 ], [ %2564, %2609 ], [ %2564, %2603 ]
  %2697 = phi float [ %2693, %2677 ], [ %2565, %2609 ], [ %2565, %2603 ]
  %2698 = phi float [ %2694, %2677 ], [ %2566, %2609 ], [ %2566, %2603 ]
  %2699 = fadd fast float %5, 1.000000e+00
  %2700 = fadd fast float %6, 1.000000e+00
  %2701 = fsub fast float 1.000000e+00, %5
  %2702 = fmul fast float %36, %2699
  %2703 = fmul fast float %36, %2700
  %2704 = fmul fast float %36, %2701
  %2705 = fmul fast float %2702, %2696
  %2706 = fmul fast float %2703, %2697
  %2707 = fmul fast float %2704, %2698
  %2708 = fcmp fast ult float %37, 5.000000e-01
  br i1 %2708, label %2734, label %2709

; <label>:2709                                    ; preds = %2695
  %2710 = fmul fast float %2705, 0x4004147AE0000000
  %2711 = fmul fast float %2706, 0x4004147AE0000000
  %2712 = fmul fast float %2707, 0x4004147AE0000000
  %2713 = fadd fast float %2710, 0x3F9EB851E0000000
  %2714 = fadd fast float %2711, 0x3F9EB851E0000000
  %2715 = fadd fast float %2712, 0x3F9EB851E0000000
  %2716 = fmul fast float %2713, %2705
  %2717 = fmul fast float %2714, %2706
  %2718 = fmul fast float %2715, %2707
  %2719 = fmul fast float %2705, 0x400370A3E0000000
  %2720 = fmul fast float %2706, 0x400370A3E0000000
  %2721 = fmul fast float %2707, 0x400370A3E0000000
  %2722 = fadd fast float %2719, 0x3FE2E147A0000000
  %2723 = fadd fast float %2720, 0x3FE2E147A0000000
  %2724 = fadd fast float %2721, 0x3FE2E147A0000000
  %2725 = fmul fast float %2722, %2705
  %2726 = fmul fast float %2723, %2706
  %2727 = fmul fast float %2724, %2707
  %2728 = fadd fast float %2725, 0x3FC1EB8520000000
  %2729 = fadd fast float %2726, 0x3FC1EB8520000000
  %2730 = fadd fast float %2727, 0x3FC1EB8520000000
  %2731 = fdiv fast float %2716, %2728
  %2732 = fdiv fast float %2717, %2729
  %2733 = fdiv fast float %2718, %2730
  br label %2734

; <label>:2734                                    ; preds = %2709, %2695
  %2735 = phi float [ %2731, %2709 ], [ %2705, %2695 ]
  %2736 = phi float [ %2732, %2709 ], [ %2706, %2695 ]
  %2737 = phi float [ %2733, %2709 ], [ %2707, %2695 ]
  %2738 = call float @dx.op.unary.f32(i32 7, float %2735)  ; Saturate(value)
  %2739 = call float @dx.op.unary.f32(i32 7, float %2736)  ; Saturate(value)
  %2740 = call float @dx.op.unary.f32(i32 7, float %2737)  ; Saturate(value)
  %2741 = call float @dx.op.dot3.f32(i32 55, float %2738, float %2739, float %2740, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2742 = fsub fast float %2738, %2741
  %2743 = fsub fast float %2739, %2741
  %2744 = fsub fast float %2740, %2741
  %2745 = fmul fast float %2742, %8
  %2746 = fmul fast float %2743, %8
  %2747 = fmul fast float %2744, %8
  %2748 = fadd fast float %2745, %2741
  %2749 = fadd fast float %2746, %2741
  %2750 = fadd fast float %2747, %2741
  %2751 = call float @dx.op.unary.f32(i32 7, float %2748)  ; Saturate(value)
  %2752 = call float @dx.op.unary.f32(i32 7, float %2749)  ; Saturate(value)
  %2753 = call float @dx.op.unary.f32(i32 7, float %2750)  ; Saturate(value)
  %2754 = fadd fast float %2751, 0xBFC70A3D80000000
  %2755 = fadd fast float %2752, 0xBFC70A3D80000000
  %2756 = fadd fast float %2753, 0xBFC70A3D80000000
  %2757 = fmul fast float %2754, %7
  %2758 = fmul fast float %2755, %7
  %2759 = fmul fast float %2756, %7
  %2760 = fadd fast float %2757, 0x3FC70A3D80000000
  %2761 = fadd fast float %2758, 0x3FC70A3D80000000
  %2762 = fadd fast float %2759, 0x3FC70A3D80000000
  %2763 = call float @dx.op.unary.f32(i32 7, float %2760)  ; Saturate(value)
  %2764 = call float @dx.op.unary.f32(i32 7, float %2761)  ; Saturate(value)
  %2765 = call float @dx.op.unary.f32(i32 7, float %2762)  ; Saturate(value)
  br label %2766

; <label>:2766                                    ; preds = %2734, %2569
  %2767 = phi float [ %2600, %2569 ], [ %2763, %2734 ]
  %2768 = phi float [ %2601, %2569 ], [ %2764, %2734 ]
  %2769 = phi float [ %2602, %2569 ], [ %2765, %2734 ]
  %2770 = add i32 %2386, 1
  %2771 = call i32 @dx.op.binary.i32(i32 37, i32 %2770, i32 0)  ; IMax(a,b)
  %2772 = call i32 @dx.op.binary.i32(i32 38, i32 %2771, i32 %60)  ; IMin(a,b)
  %2773 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2561, i32 %2772, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2774 = extractvalue %dx.types.ResRet.f32 %2773, 0
  %2775 = extractvalue %dx.types.ResRet.f32 %2773, 1
  %2776 = extractvalue %dx.types.ResRet.f32 %2773, 2
  %2777 = extractvalue %dx.types.ResRet.f32 %2773, 3
  %2778 = fcmp fast olt float %2777, 0.000000e+00
  br i1 %2778, label %2779, label %2813

; <label>:2779                                    ; preds = %2766
  %2780 = fcmp fast ogt float %2774, 0x3FA4B5DCC0000000
  %2781 = fcmp fast ogt float %2775, 0x3FA4B5DCC0000000
  %2782 = fcmp fast ogt float %2776, 0x3FA4B5DCC0000000
  %2783 = select i1 %2780, float 0.000000e+00, float 1.000000e+00
  %2784 = select i1 %2781, float 0.000000e+00, float 1.000000e+00
  %2785 = select i1 %2782, float 0.000000e+00, float 1.000000e+00
  %2786 = fmul fast float %2774, 0x3FB3D07220000000
  %2787 = fmul fast float %2775, 0x3FB3D07220000000
  %2788 = fmul fast float %2776, 0x3FB3D07220000000
  %2789 = fadd fast float %2774, 0x3FAC28F5C0000000
  %2790 = fadd fast float %2775, 0x3FAC28F5C0000000
  %2791 = fadd fast float %2776, 0x3FAC28F5C0000000
  %2792 = fmul fast float %2789, 0x3FEE54EDE0000000
  %2793 = fmul fast float %2790, 0x3FEE54EDE0000000
  %2794 = fmul fast float %2791, 0x3FEE54EDE0000000
  %2795 = call float @dx.op.unary.f32(i32 23, float %2792)  ; Log(value)
  %2796 = call float @dx.op.unary.f32(i32 23, float %2793)  ; Log(value)
  %2797 = call float @dx.op.unary.f32(i32 23, float %2794)  ; Log(value)
  %2798 = fmul fast float %2795, 0x4003333340000000
  %2799 = fmul fast float %2796, 0x4003333340000000
  %2800 = fmul fast float %2797, 0x4003333340000000
  %2801 = call float @dx.op.unary.f32(i32 21, float %2798)  ; Exp(value)
  %2802 = call float @dx.op.unary.f32(i32 21, float %2799)  ; Exp(value)
  %2803 = call float @dx.op.unary.f32(i32 21, float %2800)  ; Exp(value)
  %2804 = fsub fast float %2786, %2801
  %2805 = fsub fast float %2787, %2802
  %2806 = fsub fast float %2788, %2803
  %2807 = fmul fast float %2804, %2783
  %2808 = fmul fast float %2805, %2784
  %2809 = fmul fast float %2806, %2785
  %2810 = fadd fast float %2807, %2801
  %2811 = fadd fast float %2808, %2802
  %2812 = fadd fast float %2809, %2803
  br label %2976

; <label>:2813                                    ; preds = %2766
  %2814 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2561, i32 %2772, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2815 = extractvalue %dx.types.ResRet.f32 %2814, 0
  %2816 = fcmp fast ogt float %38, 5.000000e-01
  %2817 = fcmp fast olt float %2815, 1.000000e+00
  %2818 = and i1 %2816, %2817
  br i1 %2818, label %2819, label %2905

; <label>:2819                                    ; preds = %2813
  %2820 = sitofp i32 %2561 to float
  %2821 = sitofp i32 %2772 to float
  %2822 = fadd fast float %2820, 5.000000e-01
  %2823 = fadd fast float %2821, 5.000000e-01
  %2824 = fdiv fast float %2822, %45
  %2825 = fdiv fast float %2823, %46
  %2826 = fmul fast float %2824, 2.000000e+00
  %2827 = fmul fast float %2825, 2.000000e+00
  %2828 = fadd fast float %2826, -1.000000e+00
  %2829 = fsub fast float 1.000000e+00, %2827
  %2830 = fmul fast float %2828, %35
  %2831 = call float @dx.op.tertiary.f32(i32 46, float %2829, float %31, float %2830)  ; FMad(a,b,c)
  %2832 = call float @dx.op.tertiary.f32(i32 46, float %2815, float %27, float %2831)  ; FMad(a,b,c)
  %2833 = fadd fast float %2832, %23
  %2834 = call float @dx.op.unary.f32(i32 6, float %2833)  ; FAbs(value)
  %2835 = fcmp fast ogt float %2834, 0x3EB0C6F7A0000000
  br i1 %2835, label %2836, label %2905

; <label>:2836                                    ; preds = %2819
  %2837 = fmul fast float %2828, %34
  %2838 = call float @dx.op.tertiary.f32(i32 46, float %2829, float %30, float %2837)  ; FMad(a,b,c)
  %2839 = call float @dx.op.tertiary.f32(i32 46, float %2815, float %26, float %2838)  ; FMad(a,b,c)
  %2840 = fadd fast float %2839, %22
  %2841 = fmul fast float %2828, %33
  %2842 = call float @dx.op.tertiary.f32(i32 46, float %2829, float %29, float %2841)  ; FMad(a,b,c)
  %2843 = call float @dx.op.tertiary.f32(i32 46, float %2815, float %25, float %2842)  ; FMad(a,b,c)
  %2844 = fadd fast float %2843, %21
  %2845 = fmul fast float %2828, %32
  %2846 = call float @dx.op.tertiary.f32(i32 46, float %2829, float %28, float %2845)  ; FMad(a,b,c)
  %2847 = call float @dx.op.tertiary.f32(i32 46, float %2815, float %24, float %2846)  ; FMad(a,b,c)
  %2848 = fadd fast float %2847, %20
  %2849 = fdiv fast float %2848, %2833
  %2850 = fdiv fast float %2844, %2833
  %2851 = fdiv fast float %2840, %2833
  %2852 = fsub fast float %2849, %17
  %2853 = fsub fast float %2850, %18
  %2854 = fsub fast float %2851, %19
  %2855 = fmul fast float %2852, %2852
  %2856 = fmul fast float %2853, %2853
  %2857 = fadd fast float %2856, %2855
  %2858 = fmul fast float %2854, %2854
  %2859 = fadd fast float %2857, %2858
  %2860 = call float @dx.op.unary.f32(i32 24, float %2859)  ; Sqrt(value)
  %2861 = fsub fast float %2860, %9
  %2862 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2861)  ; FMax(a,b)
  %2863 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %2863, label %2864, label %2887

; <label>:2864                                    ; preds = %2836
  %2865 = call float @dx.op.unary.f32(i32 6, float %2853)  ; FAbs(value)
  %2866 = fmul fast float %2865, %11
  %2867 = fcmp fast olt float %2866, 0x3F50624DE0000000
  br i1 %2867, label %2868, label %2871

; <label>:2868                                    ; preds = %2864
  %2869 = fmul fast float %2866, 5.000000e-01
  %2870 = fsub fast float 1.000000e+00, %2869
  br label %2876

; <label>:2871                                    ; preds = %2864
  %2872 = fmul fast float %2866, 0xBFF7154760000000
  %2873 = call float @dx.op.unary.f32(i32 21, float %2872)  ; Exp(value)
  %2874 = fsub fast float 1.000000e+00, %2873
  %2875 = fdiv fast float %2874, %2866
  br label %2876

; <label>:2876                                    ; preds = %2871, %2868
  %2877 = phi float [ %2870, %2868 ], [ %2875, %2871 ]
  %2878 = call float @dx.op.binary.f32(i32 36, float %2850, float %18)  ; FMin(a,b)
  %2879 = fsub fast float %2878, %10
  %2880 = fmul fast float %11, %2879
  %2881 = fsub fast float -0.000000e+00, %2880
  %2882 = call float @dx.op.binary.f32(i32 35, float %2881, float -4.000000e+01)  ; FMax(a,b)
  %2883 = call float @dx.op.binary.f32(i32 36, float %2882, float 5.000000e+00)  ; FMin(a,b)
  %2884 = fmul fast float %2883, 0x3FF7154760000000
  %2885 = call float @dx.op.unary.f32(i32 21, float %2884)  ; Exp(value)
  %2886 = fmul fast float %2885, %2877
  br label %2887

; <label>:2887                                    ; preds = %2876, %2836
  %2888 = phi float [ %2886, %2876 ], [ 1.000000e+00, %2836 ]
  %2889 = fmul fast float %2862, %16
  %2890 = fmul fast float %2889, %2888
  %2891 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2890)  ; FMin(a,b)
  %2892 = fmul fast float %2891, 0xBFF7154760000000
  %2893 = call float @dx.op.unary.f32(i32 21, float %2892)  ; Exp(value)
  %2894 = fsub fast float 1.000000e+00, %2893
  %2895 = call float @dx.op.binary.f32(i32 36, float %12, float %2894)  ; FMin(a,b)
  %2896 = fsub fast float %13, %2774
  %2897 = fsub fast float %14, %2775
  %2898 = fsub fast float %15, %2776
  %2899 = fmul fast float %2895, %2896
  %2900 = fmul fast float %2895, %2897
  %2901 = fmul fast float %2895, %2898
  %2902 = fadd fast float %2899, %2774
  %2903 = fadd fast float %2900, %2775
  %2904 = fadd fast float %2901, %2776
  br label %2905

; <label>:2905                                    ; preds = %2887, %2819, %2813
  %2906 = phi float [ %2902, %2887 ], [ %2774, %2819 ], [ %2774, %2813 ]
  %2907 = phi float [ %2903, %2887 ], [ %2775, %2819 ], [ %2775, %2813 ]
  %2908 = phi float [ %2904, %2887 ], [ %2776, %2819 ], [ %2776, %2813 ]
  %2909 = fadd fast float %5, 1.000000e+00
  %2910 = fadd fast float %6, 1.000000e+00
  %2911 = fsub fast float 1.000000e+00, %5
  %2912 = fmul fast float %36, %2909
  %2913 = fmul fast float %36, %2910
  %2914 = fmul fast float %36, %2911
  %2915 = fmul fast float %2912, %2906
  %2916 = fmul fast float %2913, %2907
  %2917 = fmul fast float %2914, %2908
  %2918 = fcmp fast ult float %37, 5.000000e-01
  br i1 %2918, label %2944, label %2919

; <label>:2919                                    ; preds = %2905
  %2920 = fmul fast float %2915, 0x4004147AE0000000
  %2921 = fmul fast float %2916, 0x4004147AE0000000
  %2922 = fmul fast float %2917, 0x4004147AE0000000
  %2923 = fadd fast float %2920, 0x3F9EB851E0000000
  %2924 = fadd fast float %2921, 0x3F9EB851E0000000
  %2925 = fadd fast float %2922, 0x3F9EB851E0000000
  %2926 = fmul fast float %2923, %2915
  %2927 = fmul fast float %2924, %2916
  %2928 = fmul fast float %2925, %2917
  %2929 = fmul fast float %2915, 0x400370A3E0000000
  %2930 = fmul fast float %2916, 0x400370A3E0000000
  %2931 = fmul fast float %2917, 0x400370A3E0000000
  %2932 = fadd fast float %2929, 0x3FE2E147A0000000
  %2933 = fadd fast float %2930, 0x3FE2E147A0000000
  %2934 = fadd fast float %2931, 0x3FE2E147A0000000
  %2935 = fmul fast float %2932, %2915
  %2936 = fmul fast float %2933, %2916
  %2937 = fmul fast float %2934, %2917
  %2938 = fadd fast float %2935, 0x3FC1EB8520000000
  %2939 = fadd fast float %2936, 0x3FC1EB8520000000
  %2940 = fadd fast float %2937, 0x3FC1EB8520000000
  %2941 = fdiv fast float %2926, %2938
  %2942 = fdiv fast float %2927, %2939
  %2943 = fdiv fast float %2928, %2940
  br label %2944

; <label>:2944                                    ; preds = %2919, %2905
  %2945 = phi float [ %2941, %2919 ], [ %2915, %2905 ]
  %2946 = phi float [ %2942, %2919 ], [ %2916, %2905 ]
  %2947 = phi float [ %2943, %2919 ], [ %2917, %2905 ]
  %2948 = call float @dx.op.unary.f32(i32 7, float %2945)  ; Saturate(value)
  %2949 = call float @dx.op.unary.f32(i32 7, float %2946)  ; Saturate(value)
  %2950 = call float @dx.op.unary.f32(i32 7, float %2947)  ; Saturate(value)
  %2951 = call float @dx.op.dot3.f32(i32 55, float %2948, float %2949, float %2950, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2952 = fsub fast float %2948, %2951
  %2953 = fsub fast float %2949, %2951
  %2954 = fsub fast float %2950, %2951
  %2955 = fmul fast float %2952, %8
  %2956 = fmul fast float %2953, %8
  %2957 = fmul fast float %2954, %8
  %2958 = fadd fast float %2955, %2951
  %2959 = fadd fast float %2956, %2951
  %2960 = fadd fast float %2957, %2951
  %2961 = call float @dx.op.unary.f32(i32 7, float %2958)  ; Saturate(value)
  %2962 = call float @dx.op.unary.f32(i32 7, float %2959)  ; Saturate(value)
  %2963 = call float @dx.op.unary.f32(i32 7, float %2960)  ; Saturate(value)
  %2964 = fadd fast float %2961, 0xBFC70A3D80000000
  %2965 = fadd fast float %2962, 0xBFC70A3D80000000
  %2966 = fadd fast float %2963, 0xBFC70A3D80000000
  %2967 = fmul fast float %2964, %7
  %2968 = fmul fast float %2965, %7
  %2969 = fmul fast float %2966, %7
  %2970 = fadd fast float %2967, 0x3FC70A3D80000000
  %2971 = fadd fast float %2968, 0x3FC70A3D80000000
  %2972 = fadd fast float %2969, 0x3FC70A3D80000000
  %2973 = call float @dx.op.unary.f32(i32 7, float %2970)  ; Saturate(value)
  %2974 = call float @dx.op.unary.f32(i32 7, float %2971)  ; Saturate(value)
  %2975 = call float @dx.op.unary.f32(i32 7, float %2972)  ; Saturate(value)
  br label %2976

; <label>:2976                                    ; preds = %2944, %2779
  %2977 = phi float [ %2810, %2779 ], [ %2973, %2944 ]
  %2978 = phi float [ %2811, %2779 ], [ %2974, %2944 ]
  %2979 = phi float [ %2812, %2779 ], [ %2975, %2944 ]
  %2980 = add i32 %63, -1
  %2981 = call i32 @dx.op.binary.i32(i32 37, i32 %2980, i32 0)  ; IMax(a,b)
  %2982 = call i32 @dx.op.binary.i32(i32 37, i32 %2386, i32 0)  ; IMax(a,b)
  %2983 = call i32 @dx.op.binary.i32(i32 38, i32 %2981, i32 %59)  ; IMin(a,b)
  %2984 = call i32 @dx.op.binary.i32(i32 38, i32 %2982, i32 %60)  ; IMin(a,b)
  %2985 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2983, i32 %2984, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2986 = extractvalue %dx.types.ResRet.f32 %2985, 0
  %2987 = extractvalue %dx.types.ResRet.f32 %2985, 1
  %2988 = extractvalue %dx.types.ResRet.f32 %2985, 2
  %2989 = extractvalue %dx.types.ResRet.f32 %2985, 3
  %2990 = fcmp fast olt float %2989, 0.000000e+00
  br i1 %2990, label %2991, label %3025

; <label>:2991                                    ; preds = %2976
  %2992 = fcmp fast ogt float %2986, 0x3FA4B5DCC0000000
  %2993 = fcmp fast ogt float %2987, 0x3FA4B5DCC0000000
  %2994 = fcmp fast ogt float %2988, 0x3FA4B5DCC0000000
  %2995 = select i1 %2992, float 0.000000e+00, float 1.000000e+00
  %2996 = select i1 %2993, float 0.000000e+00, float 1.000000e+00
  %2997 = select i1 %2994, float 0.000000e+00, float 1.000000e+00
  %2998 = fmul fast float %2986, 0x3FB3D07220000000
  %2999 = fmul fast float %2987, 0x3FB3D07220000000
  %3000 = fmul fast float %2988, 0x3FB3D07220000000
  %3001 = fadd fast float %2986, 0x3FAC28F5C0000000
  %3002 = fadd fast float %2987, 0x3FAC28F5C0000000
  %3003 = fadd fast float %2988, 0x3FAC28F5C0000000
  %3004 = fmul fast float %3001, 0x3FEE54EDE0000000
  %3005 = fmul fast float %3002, 0x3FEE54EDE0000000
  %3006 = fmul fast float %3003, 0x3FEE54EDE0000000
  %3007 = call float @dx.op.unary.f32(i32 23, float %3004)  ; Log(value)
  %3008 = call float @dx.op.unary.f32(i32 23, float %3005)  ; Log(value)
  %3009 = call float @dx.op.unary.f32(i32 23, float %3006)  ; Log(value)
  %3010 = fmul fast float %3007, 0x4003333340000000
  %3011 = fmul fast float %3008, 0x4003333340000000
  %3012 = fmul fast float %3009, 0x4003333340000000
  %3013 = call float @dx.op.unary.f32(i32 21, float %3010)  ; Exp(value)
  %3014 = call float @dx.op.unary.f32(i32 21, float %3011)  ; Exp(value)
  %3015 = call float @dx.op.unary.f32(i32 21, float %3012)  ; Exp(value)
  %3016 = fsub fast float %2998, %3013
  %3017 = fsub fast float %2999, %3014
  %3018 = fsub fast float %3000, %3015
  %3019 = fmul fast float %3016, %2995
  %3020 = fmul fast float %3017, %2996
  %3021 = fmul fast float %3018, %2997
  %3022 = fadd fast float %3019, %3013
  %3023 = fadd fast float %3020, %3014
  %3024 = fadd fast float %3021, %3015
  br label %3188

; <label>:3025                                    ; preds = %2976
  %3026 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2983, i32 %2984, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3027 = extractvalue %dx.types.ResRet.f32 %3026, 0
  %3028 = fcmp fast ogt float %38, 5.000000e-01
  %3029 = fcmp fast olt float %3027, 1.000000e+00
  %3030 = and i1 %3028, %3029
  br i1 %3030, label %3031, label %3117

; <label>:3031                                    ; preds = %3025
  %3032 = sitofp i32 %2983 to float
  %3033 = sitofp i32 %2984 to float
  %3034 = fadd fast float %3032, 5.000000e-01
  %3035 = fadd fast float %3033, 5.000000e-01
  %3036 = fdiv fast float %3034, %45
  %3037 = fdiv fast float %3035, %46
  %3038 = fmul fast float %3036, 2.000000e+00
  %3039 = fmul fast float %3037, 2.000000e+00
  %3040 = fadd fast float %3038, -1.000000e+00
  %3041 = fsub fast float 1.000000e+00, %3039
  %3042 = fmul fast float %3040, %35
  %3043 = call float @dx.op.tertiary.f32(i32 46, float %3041, float %31, float %3042)  ; FMad(a,b,c)
  %3044 = call float @dx.op.tertiary.f32(i32 46, float %3027, float %27, float %3043)  ; FMad(a,b,c)
  %3045 = fadd fast float %3044, %23
  %3046 = call float @dx.op.unary.f32(i32 6, float %3045)  ; FAbs(value)
  %3047 = fcmp fast ogt float %3046, 0x3EB0C6F7A0000000
  br i1 %3047, label %3048, label %3117

; <label>:3048                                    ; preds = %3031
  %3049 = fmul fast float %3040, %34
  %3050 = call float @dx.op.tertiary.f32(i32 46, float %3041, float %30, float %3049)  ; FMad(a,b,c)
  %3051 = call float @dx.op.tertiary.f32(i32 46, float %3027, float %26, float %3050)  ; FMad(a,b,c)
  %3052 = fadd fast float %3051, %22
  %3053 = fmul fast float %3040, %33
  %3054 = call float @dx.op.tertiary.f32(i32 46, float %3041, float %29, float %3053)  ; FMad(a,b,c)
  %3055 = call float @dx.op.tertiary.f32(i32 46, float %3027, float %25, float %3054)  ; FMad(a,b,c)
  %3056 = fadd fast float %3055, %21
  %3057 = fmul fast float %3040, %32
  %3058 = call float @dx.op.tertiary.f32(i32 46, float %3041, float %28, float %3057)  ; FMad(a,b,c)
  %3059 = call float @dx.op.tertiary.f32(i32 46, float %3027, float %24, float %3058)  ; FMad(a,b,c)
  %3060 = fadd fast float %3059, %20
  %3061 = fdiv fast float %3060, %3045
  %3062 = fdiv fast float %3056, %3045
  %3063 = fdiv fast float %3052, %3045
  %3064 = fsub fast float %3061, %17
  %3065 = fsub fast float %3062, %18
  %3066 = fsub fast float %3063, %19
  %3067 = fmul fast float %3064, %3064
  %3068 = fmul fast float %3065, %3065
  %3069 = fadd fast float %3068, %3067
  %3070 = fmul fast float %3066, %3066
  %3071 = fadd fast float %3069, %3070
  %3072 = call float @dx.op.unary.f32(i32 24, float %3071)  ; Sqrt(value)
  %3073 = fsub fast float %3072, %9
  %3074 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3073)  ; FMax(a,b)
  %3075 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %3075, label %3076, label %3099

; <label>:3076                                    ; preds = %3048
  %3077 = call float @dx.op.unary.f32(i32 6, float %3065)  ; FAbs(value)
  %3078 = fmul fast float %3077, %11
  %3079 = fcmp fast olt float %3078, 0x3F50624DE0000000
  br i1 %3079, label %3080, label %3083

; <label>:3080                                    ; preds = %3076
  %3081 = fmul fast float %3078, 5.000000e-01
  %3082 = fsub fast float 1.000000e+00, %3081
  br label %3088

; <label>:3083                                    ; preds = %3076
  %3084 = fmul fast float %3078, 0xBFF7154760000000
  %3085 = call float @dx.op.unary.f32(i32 21, float %3084)  ; Exp(value)
  %3086 = fsub fast float 1.000000e+00, %3085
  %3087 = fdiv fast float %3086, %3078
  br label %3088

; <label>:3088                                    ; preds = %3083, %3080
  %3089 = phi float [ %3082, %3080 ], [ %3087, %3083 ]
  %3090 = call float @dx.op.binary.f32(i32 36, float %3062, float %18)  ; FMin(a,b)
  %3091 = fsub fast float %3090, %10
  %3092 = fmul fast float %11, %3091
  %3093 = fsub fast float -0.000000e+00, %3092
  %3094 = call float @dx.op.binary.f32(i32 35, float %3093, float -4.000000e+01)  ; FMax(a,b)
  %3095 = call float @dx.op.binary.f32(i32 36, float %3094, float 5.000000e+00)  ; FMin(a,b)
  %3096 = fmul fast float %3095, 0x3FF7154760000000
  %3097 = call float @dx.op.unary.f32(i32 21, float %3096)  ; Exp(value)
  %3098 = fmul fast float %3097, %3089
  br label %3099

; <label>:3099                                    ; preds = %3088, %3048
  %3100 = phi float [ %3098, %3088 ], [ 1.000000e+00, %3048 ]
  %3101 = fmul fast float %3074, %16
  %3102 = fmul fast float %3101, %3100
  %3103 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3102)  ; FMin(a,b)
  %3104 = fmul fast float %3103, 0xBFF7154760000000
  %3105 = call float @dx.op.unary.f32(i32 21, float %3104)  ; Exp(value)
  %3106 = fsub fast float 1.000000e+00, %3105
  %3107 = call float @dx.op.binary.f32(i32 36, float %12, float %3106)  ; FMin(a,b)
  %3108 = fsub fast float %13, %2986
  %3109 = fsub fast float %14, %2987
  %3110 = fsub fast float %15, %2988
  %3111 = fmul fast float %3107, %3108
  %3112 = fmul fast float %3107, %3109
  %3113 = fmul fast float %3107, %3110
  %3114 = fadd fast float %3111, %2986
  %3115 = fadd fast float %3112, %2987
  %3116 = fadd fast float %3113, %2988
  br label %3117

; <label>:3117                                    ; preds = %3099, %3031, %3025
  %3118 = phi float [ %3114, %3099 ], [ %2986, %3031 ], [ %2986, %3025 ]
  %3119 = phi float [ %3115, %3099 ], [ %2987, %3031 ], [ %2987, %3025 ]
  %3120 = phi float [ %3116, %3099 ], [ %2988, %3031 ], [ %2988, %3025 ]
  %3121 = fadd fast float %5, 1.000000e+00
  %3122 = fadd fast float %6, 1.000000e+00
  %3123 = fsub fast float 1.000000e+00, %5
  %3124 = fmul fast float %36, %3121
  %3125 = fmul fast float %36, %3122
  %3126 = fmul fast float %36, %3123
  %3127 = fmul fast float %3124, %3118
  %3128 = fmul fast float %3125, %3119
  %3129 = fmul fast float %3126, %3120
  %3130 = fcmp fast ult float %37, 5.000000e-01
  br i1 %3130, label %3156, label %3131

; <label>:3131                                    ; preds = %3117
  %3132 = fmul fast float %3127, 0x4004147AE0000000
  %3133 = fmul fast float %3128, 0x4004147AE0000000
  %3134 = fmul fast float %3129, 0x4004147AE0000000
  %3135 = fadd fast float %3132, 0x3F9EB851E0000000
  %3136 = fadd fast float %3133, 0x3F9EB851E0000000
  %3137 = fadd fast float %3134, 0x3F9EB851E0000000
  %3138 = fmul fast float %3135, %3127
  %3139 = fmul fast float %3136, %3128
  %3140 = fmul fast float %3137, %3129
  %3141 = fmul fast float %3127, 0x400370A3E0000000
  %3142 = fmul fast float %3128, 0x400370A3E0000000
  %3143 = fmul fast float %3129, 0x400370A3E0000000
  %3144 = fadd fast float %3141, 0x3FE2E147A0000000
  %3145 = fadd fast float %3142, 0x3FE2E147A0000000
  %3146 = fadd fast float %3143, 0x3FE2E147A0000000
  %3147 = fmul fast float %3144, %3127
  %3148 = fmul fast float %3145, %3128
  %3149 = fmul fast float %3146, %3129
  %3150 = fadd fast float %3147, 0x3FC1EB8520000000
  %3151 = fadd fast float %3148, 0x3FC1EB8520000000
  %3152 = fadd fast float %3149, 0x3FC1EB8520000000
  %3153 = fdiv fast float %3138, %3150
  %3154 = fdiv fast float %3139, %3151
  %3155 = fdiv fast float %3140, %3152
  br label %3156

; <label>:3156                                    ; preds = %3131, %3117
  %3157 = phi float [ %3153, %3131 ], [ %3127, %3117 ]
  %3158 = phi float [ %3154, %3131 ], [ %3128, %3117 ]
  %3159 = phi float [ %3155, %3131 ], [ %3129, %3117 ]
  %3160 = call float @dx.op.unary.f32(i32 7, float %3157)  ; Saturate(value)
  %3161 = call float @dx.op.unary.f32(i32 7, float %3158)  ; Saturate(value)
  %3162 = call float @dx.op.unary.f32(i32 7, float %3159)  ; Saturate(value)
  %3163 = call float @dx.op.dot3.f32(i32 55, float %3160, float %3161, float %3162, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3164 = fsub fast float %3160, %3163
  %3165 = fsub fast float %3161, %3163
  %3166 = fsub fast float %3162, %3163
  %3167 = fmul fast float %3164, %8
  %3168 = fmul fast float %3165, %8
  %3169 = fmul fast float %3166, %8
  %3170 = fadd fast float %3167, %3163
  %3171 = fadd fast float %3168, %3163
  %3172 = fadd fast float %3169, %3163
  %3173 = call float @dx.op.unary.f32(i32 7, float %3170)  ; Saturate(value)
  %3174 = call float @dx.op.unary.f32(i32 7, float %3171)  ; Saturate(value)
  %3175 = call float @dx.op.unary.f32(i32 7, float %3172)  ; Saturate(value)
  %3176 = fadd fast float %3173, 0xBFC70A3D80000000
  %3177 = fadd fast float %3174, 0xBFC70A3D80000000
  %3178 = fadd fast float %3175, 0xBFC70A3D80000000
  %3179 = fmul fast float %3176, %7
  %3180 = fmul fast float %3177, %7
  %3181 = fmul fast float %3178, %7
  %3182 = fadd fast float %3179, 0x3FC70A3D80000000
  %3183 = fadd fast float %3180, 0x3FC70A3D80000000
  %3184 = fadd fast float %3181, 0x3FC70A3D80000000
  %3185 = call float @dx.op.unary.f32(i32 7, float %3182)  ; Saturate(value)
  %3186 = call float @dx.op.unary.f32(i32 7, float %3183)  ; Saturate(value)
  %3187 = call float @dx.op.unary.f32(i32 7, float %3184)  ; Saturate(value)
  br label %3188

; <label>:3188                                    ; preds = %3156, %2991
  %3189 = phi float [ %3022, %2991 ], [ %3185, %3156 ]
  %3190 = phi float [ %3023, %2991 ], [ %3186, %3156 ]
  %3191 = phi float [ %3024, %2991 ], [ %3187, %3156 ]
  %3192 = add i32 %63, 1
  %3193 = call i32 @dx.op.binary.i32(i32 37, i32 %3192, i32 0)  ; IMax(a,b)
  %3194 = call i32 @dx.op.binary.i32(i32 38, i32 %3193, i32 %59)  ; IMin(a,b)
  %3195 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3194, i32 %2984, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3196 = extractvalue %dx.types.ResRet.f32 %3195, 0
  %3197 = extractvalue %dx.types.ResRet.f32 %3195, 1
  %3198 = extractvalue %dx.types.ResRet.f32 %3195, 2
  %3199 = extractvalue %dx.types.ResRet.f32 %3195, 3
  %3200 = fcmp fast olt float %3199, 0.000000e+00
  br i1 %3200, label %3201, label %3235

; <label>:3201                                    ; preds = %3188
  %3202 = fcmp fast ogt float %3196, 0x3FA4B5DCC0000000
  %3203 = fcmp fast ogt float %3197, 0x3FA4B5DCC0000000
  %3204 = fcmp fast ogt float %3198, 0x3FA4B5DCC0000000
  %3205 = select i1 %3202, float 0.000000e+00, float 1.000000e+00
  %3206 = select i1 %3203, float 0.000000e+00, float 1.000000e+00
  %3207 = select i1 %3204, float 0.000000e+00, float 1.000000e+00
  %3208 = fmul fast float %3196, 0x3FB3D07220000000
  %3209 = fmul fast float %3197, 0x3FB3D07220000000
  %3210 = fmul fast float %3198, 0x3FB3D07220000000
  %3211 = fadd fast float %3196, 0x3FAC28F5C0000000
  %3212 = fadd fast float %3197, 0x3FAC28F5C0000000
  %3213 = fadd fast float %3198, 0x3FAC28F5C0000000
  %3214 = fmul fast float %3211, 0x3FEE54EDE0000000
  %3215 = fmul fast float %3212, 0x3FEE54EDE0000000
  %3216 = fmul fast float %3213, 0x3FEE54EDE0000000
  %3217 = call float @dx.op.unary.f32(i32 23, float %3214)  ; Log(value)
  %3218 = call float @dx.op.unary.f32(i32 23, float %3215)  ; Log(value)
  %3219 = call float @dx.op.unary.f32(i32 23, float %3216)  ; Log(value)
  %3220 = fmul fast float %3217, 0x4003333340000000
  %3221 = fmul fast float %3218, 0x4003333340000000
  %3222 = fmul fast float %3219, 0x4003333340000000
  %3223 = call float @dx.op.unary.f32(i32 21, float %3220)  ; Exp(value)
  %3224 = call float @dx.op.unary.f32(i32 21, float %3221)  ; Exp(value)
  %3225 = call float @dx.op.unary.f32(i32 21, float %3222)  ; Exp(value)
  %3226 = fsub fast float %3208, %3223
  %3227 = fsub fast float %3209, %3224
  %3228 = fsub fast float %3210, %3225
  %3229 = fmul fast float %3226, %3205
  %3230 = fmul fast float %3227, %3206
  %3231 = fmul fast float %3228, %3207
  %3232 = fadd fast float %3229, %3223
  %3233 = fadd fast float %3230, %3224
  %3234 = fadd fast float %3231, %3225
  br label %3398

; <label>:3235                                    ; preds = %3188
  %3236 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3194, i32 %2984, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3237 = extractvalue %dx.types.ResRet.f32 %3236, 0
  %3238 = fcmp fast ogt float %38, 5.000000e-01
  %3239 = fcmp fast olt float %3237, 1.000000e+00
  %3240 = and i1 %3238, %3239
  br i1 %3240, label %3241, label %3327

; <label>:3241                                    ; preds = %3235
  %3242 = sitofp i32 %3194 to float
  %3243 = sitofp i32 %2984 to float
  %3244 = fadd fast float %3242, 5.000000e-01
  %3245 = fadd fast float %3243, 5.000000e-01
  %3246 = fdiv fast float %3244, %45
  %3247 = fdiv fast float %3245, %46
  %3248 = fmul fast float %3246, 2.000000e+00
  %3249 = fmul fast float %3247, 2.000000e+00
  %3250 = fadd fast float %3248, -1.000000e+00
  %3251 = fsub fast float 1.000000e+00, %3249
  %3252 = fmul fast float %3250, %35
  %3253 = call float @dx.op.tertiary.f32(i32 46, float %3251, float %31, float %3252)  ; FMad(a,b,c)
  %3254 = call float @dx.op.tertiary.f32(i32 46, float %3237, float %27, float %3253)  ; FMad(a,b,c)
  %3255 = fadd fast float %3254, %23
  %3256 = call float @dx.op.unary.f32(i32 6, float %3255)  ; FAbs(value)
  %3257 = fcmp fast ogt float %3256, 0x3EB0C6F7A0000000
  br i1 %3257, label %3258, label %3327

; <label>:3258                                    ; preds = %3241
  %3259 = fmul fast float %3250, %34
  %3260 = call float @dx.op.tertiary.f32(i32 46, float %3251, float %30, float %3259)  ; FMad(a,b,c)
  %3261 = call float @dx.op.tertiary.f32(i32 46, float %3237, float %26, float %3260)  ; FMad(a,b,c)
  %3262 = fadd fast float %3261, %22
  %3263 = fmul fast float %3250, %33
  %3264 = call float @dx.op.tertiary.f32(i32 46, float %3251, float %29, float %3263)  ; FMad(a,b,c)
  %3265 = call float @dx.op.tertiary.f32(i32 46, float %3237, float %25, float %3264)  ; FMad(a,b,c)
  %3266 = fadd fast float %3265, %21
  %3267 = fmul fast float %3250, %32
  %3268 = call float @dx.op.tertiary.f32(i32 46, float %3251, float %28, float %3267)  ; FMad(a,b,c)
  %3269 = call float @dx.op.tertiary.f32(i32 46, float %3237, float %24, float %3268)  ; FMad(a,b,c)
  %3270 = fadd fast float %3269, %20
  %3271 = fdiv fast float %3270, %3255
  %3272 = fdiv fast float %3266, %3255
  %3273 = fdiv fast float %3262, %3255
  %3274 = fsub fast float %3271, %17
  %3275 = fsub fast float %3272, %18
  %3276 = fsub fast float %3273, %19
  %3277 = fmul fast float %3274, %3274
  %3278 = fmul fast float %3275, %3275
  %3279 = fadd fast float %3278, %3277
  %3280 = fmul fast float %3276, %3276
  %3281 = fadd fast float %3279, %3280
  %3282 = call float @dx.op.unary.f32(i32 24, float %3281)  ; Sqrt(value)
  %3283 = fsub fast float %3282, %9
  %3284 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3283)  ; FMax(a,b)
  %3285 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %3285, label %3286, label %3309

; <label>:3286                                    ; preds = %3258
  %3287 = call float @dx.op.unary.f32(i32 6, float %3275)  ; FAbs(value)
  %3288 = fmul fast float %3287, %11
  %3289 = fcmp fast olt float %3288, 0x3F50624DE0000000
  br i1 %3289, label %3290, label %3293

; <label>:3290                                    ; preds = %3286
  %3291 = fmul fast float %3288, 5.000000e-01
  %3292 = fsub fast float 1.000000e+00, %3291
  br label %3298

; <label>:3293                                    ; preds = %3286
  %3294 = fmul fast float %3288, 0xBFF7154760000000
  %3295 = call float @dx.op.unary.f32(i32 21, float %3294)  ; Exp(value)
  %3296 = fsub fast float 1.000000e+00, %3295
  %3297 = fdiv fast float %3296, %3288
  br label %3298

; <label>:3298                                    ; preds = %3293, %3290
  %3299 = phi float [ %3292, %3290 ], [ %3297, %3293 ]
  %3300 = call float @dx.op.binary.f32(i32 36, float %3272, float %18)  ; FMin(a,b)
  %3301 = fsub fast float %3300, %10
  %3302 = fmul fast float %11, %3301
  %3303 = fsub fast float -0.000000e+00, %3302
  %3304 = call float @dx.op.binary.f32(i32 35, float %3303, float -4.000000e+01)  ; FMax(a,b)
  %3305 = call float @dx.op.binary.f32(i32 36, float %3304, float 5.000000e+00)  ; FMin(a,b)
  %3306 = fmul fast float %3305, 0x3FF7154760000000
  %3307 = call float @dx.op.unary.f32(i32 21, float %3306)  ; Exp(value)
  %3308 = fmul fast float %3307, %3299
  br label %3309

; <label>:3309                                    ; preds = %3298, %3258
  %3310 = phi float [ %3308, %3298 ], [ 1.000000e+00, %3258 ]
  %3311 = fmul fast float %3284, %16
  %3312 = fmul fast float %3311, %3310
  %3313 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3312)  ; FMin(a,b)
  %3314 = fmul fast float %3313, 0xBFF7154760000000
  %3315 = call float @dx.op.unary.f32(i32 21, float %3314)  ; Exp(value)
  %3316 = fsub fast float 1.000000e+00, %3315
  %3317 = call float @dx.op.binary.f32(i32 36, float %12, float %3316)  ; FMin(a,b)
  %3318 = fsub fast float %13, %3196
  %3319 = fsub fast float %14, %3197
  %3320 = fsub fast float %15, %3198
  %3321 = fmul fast float %3317, %3318
  %3322 = fmul fast float %3317, %3319
  %3323 = fmul fast float %3317, %3320
  %3324 = fadd fast float %3321, %3196
  %3325 = fadd fast float %3322, %3197
  %3326 = fadd fast float %3323, %3198
  br label %3327

; <label>:3327                                    ; preds = %3309, %3241, %3235
  %3328 = phi float [ %3324, %3309 ], [ %3196, %3241 ], [ %3196, %3235 ]
  %3329 = phi float [ %3325, %3309 ], [ %3197, %3241 ], [ %3197, %3235 ]
  %3330 = phi float [ %3326, %3309 ], [ %3198, %3241 ], [ %3198, %3235 ]
  %3331 = fadd fast float %5, 1.000000e+00
  %3332 = fadd fast float %6, 1.000000e+00
  %3333 = fsub fast float 1.000000e+00, %5
  %3334 = fmul fast float %36, %3331
  %3335 = fmul fast float %36, %3332
  %3336 = fmul fast float %36, %3333
  %3337 = fmul fast float %3334, %3328
  %3338 = fmul fast float %3335, %3329
  %3339 = fmul fast float %3336, %3330
  %3340 = fcmp fast ult float %37, 5.000000e-01
  br i1 %3340, label %3366, label %3341

; <label>:3341                                    ; preds = %3327
  %3342 = fmul fast float %3337, 0x4004147AE0000000
  %3343 = fmul fast float %3338, 0x4004147AE0000000
  %3344 = fmul fast float %3339, 0x4004147AE0000000
  %3345 = fadd fast float %3342, 0x3F9EB851E0000000
  %3346 = fadd fast float %3343, 0x3F9EB851E0000000
  %3347 = fadd fast float %3344, 0x3F9EB851E0000000
  %3348 = fmul fast float %3345, %3337
  %3349 = fmul fast float %3346, %3338
  %3350 = fmul fast float %3347, %3339
  %3351 = fmul fast float %3337, 0x400370A3E0000000
  %3352 = fmul fast float %3338, 0x400370A3E0000000
  %3353 = fmul fast float %3339, 0x400370A3E0000000
  %3354 = fadd fast float %3351, 0x3FE2E147A0000000
  %3355 = fadd fast float %3352, 0x3FE2E147A0000000
  %3356 = fadd fast float %3353, 0x3FE2E147A0000000
  %3357 = fmul fast float %3354, %3337
  %3358 = fmul fast float %3355, %3338
  %3359 = fmul fast float %3356, %3339
  %3360 = fadd fast float %3357, 0x3FC1EB8520000000
  %3361 = fadd fast float %3358, 0x3FC1EB8520000000
  %3362 = fadd fast float %3359, 0x3FC1EB8520000000
  %3363 = fdiv fast float %3348, %3360
  %3364 = fdiv fast float %3349, %3361
  %3365 = fdiv fast float %3350, %3362
  br label %3366

; <label>:3366                                    ; preds = %3341, %3327
  %3367 = phi float [ %3363, %3341 ], [ %3337, %3327 ]
  %3368 = phi float [ %3364, %3341 ], [ %3338, %3327 ]
  %3369 = phi float [ %3365, %3341 ], [ %3339, %3327 ]
  %3370 = call float @dx.op.unary.f32(i32 7, float %3367)  ; Saturate(value)
  %3371 = call float @dx.op.unary.f32(i32 7, float %3368)  ; Saturate(value)
  %3372 = call float @dx.op.unary.f32(i32 7, float %3369)  ; Saturate(value)
  %3373 = call float @dx.op.dot3.f32(i32 55, float %3370, float %3371, float %3372, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3374 = fsub fast float %3370, %3373
  %3375 = fsub fast float %3371, %3373
  %3376 = fsub fast float %3372, %3373
  %3377 = fmul fast float %3374, %8
  %3378 = fmul fast float %3375, %8
  %3379 = fmul fast float %3376, %8
  %3380 = fadd fast float %3377, %3373
  %3381 = fadd fast float %3378, %3373
  %3382 = fadd fast float %3379, %3373
  %3383 = call float @dx.op.unary.f32(i32 7, float %3380)  ; Saturate(value)
  %3384 = call float @dx.op.unary.f32(i32 7, float %3381)  ; Saturate(value)
  %3385 = call float @dx.op.unary.f32(i32 7, float %3382)  ; Saturate(value)
  %3386 = fadd fast float %3383, 0xBFC70A3D80000000
  %3387 = fadd fast float %3384, 0xBFC70A3D80000000
  %3388 = fadd fast float %3385, 0xBFC70A3D80000000
  %3389 = fmul fast float %3386, %7
  %3390 = fmul fast float %3387, %7
  %3391 = fmul fast float %3388, %7
  %3392 = fadd fast float %3389, 0x3FC70A3D80000000
  %3393 = fadd fast float %3390, 0x3FC70A3D80000000
  %3394 = fadd fast float %3391, 0x3FC70A3D80000000
  %3395 = call float @dx.op.unary.f32(i32 7, float %3392)  ; Saturate(value)
  %3396 = call float @dx.op.unary.f32(i32 7, float %3393)  ; Saturate(value)
  %3397 = call float @dx.op.unary.f32(i32 7, float %3394)  ; Saturate(value)
  br label %3398

; <label>:3398                                    ; preds = %3366, %3201
  %3399 = phi float [ %3232, %3201 ], [ %3395, %3366 ]
  %3400 = phi float [ %3233, %3201 ], [ %3396, %3366 ]
  %3401 = phi float [ %3234, %3201 ], [ %3397, %3366 ]
  %3402 = call float @dx.op.binary.f32(i32 36, float %3189, float %3399)  ; FMin(a,b)
  %3403 = call float @dx.op.binary.f32(i32 36, float %3190, float %3400)  ; FMin(a,b)
  %3404 = call float @dx.op.binary.f32(i32 36, float %3191, float %3401)  ; FMin(a,b)
  %3405 = call float @dx.op.binary.f32(i32 36, float %2767, float %2977)  ; FMin(a,b)
  %3406 = call float @dx.op.binary.f32(i32 36, float %2768, float %2978)  ; FMin(a,b)
  %3407 = call float @dx.op.binary.f32(i32 36, float %2769, float %2979)  ; FMin(a,b)
  %3408 = call float @dx.op.binary.f32(i32 36, float %3405, float %3402)  ; FMin(a,b)
  %3409 = call float @dx.op.binary.f32(i32 36, float %3406, float %3403)  ; FMin(a,b)
  %3410 = call float @dx.op.binary.f32(i32 36, float %3407, float %3404)  ; FMin(a,b)
  %3411 = call float @dx.op.binary.f32(i32 36, float %2555, float %3408)  ; FMin(a,b)
  %3412 = call float @dx.op.binary.f32(i32 36, float %2556, float %3409)  ; FMin(a,b)
  %3413 = call float @dx.op.binary.f32(i32 36, float %2557, float %3410)  ; FMin(a,b)
  %3414 = call float @dx.op.binary.f32(i32 35, float %3189, float %3399)  ; FMax(a,b)
  %3415 = call float @dx.op.binary.f32(i32 35, float %3190, float %3400)  ; FMax(a,b)
  %3416 = call float @dx.op.binary.f32(i32 35, float %3191, float %3401)  ; FMax(a,b)
  %3417 = call float @dx.op.binary.f32(i32 35, float %2767, float %2977)  ; FMax(a,b)
  %3418 = call float @dx.op.binary.f32(i32 35, float %2768, float %2978)  ; FMax(a,b)
  %3419 = call float @dx.op.binary.f32(i32 35, float %2769, float %2979)  ; FMax(a,b)
  %3420 = call float @dx.op.binary.f32(i32 35, float %3417, float %3414)  ; FMax(a,b)
  %3421 = call float @dx.op.binary.f32(i32 35, float %3418, float %3415)  ; FMax(a,b)
  %3422 = call float @dx.op.binary.f32(i32 35, float %3419, float %3416)  ; FMax(a,b)
  %3423 = call float @dx.op.binary.f32(i32 35, float %2555, float %3420)  ; FMax(a,b)
  %3424 = call float @dx.op.binary.f32(i32 35, float %2556, float %3421)  ; FMax(a,b)
  %3425 = call float @dx.op.binary.f32(i32 35, float %2557, float %3422)  ; FMax(a,b)
  %3426 = fsub fast float %3423, %3411
  %3427 = fsub fast float %3424, %3412
  %3428 = fsub fast float %3425, %3413
  %3429 = call float @dx.op.unary.f32(i32 6, float %3426)  ; FAbs(value)
  %3430 = call float @dx.op.unary.f32(i32 6, float %3427)  ; FAbs(value)
  %3431 = call float @dx.op.unary.f32(i32 6, float %3428)  ; FAbs(value)
  %3432 = call float @dx.op.binary.f32(i32 35, float %3430, float %3431)  ; FMax(a,b)
  %3433 = call float @dx.op.binary.f32(i32 35, float %3429, float %3432)  ; FMax(a,b)
  %3434 = call float @dx.op.binary.f32(i32 35, float %3424, float %3425)  ; FMax(a,b)
  %3435 = call float @dx.op.binary.f32(i32 35, float %3423, float %3434)  ; FMax(a,b)
  %3436 = fmul fast float %3435, 1.250000e-01
  %3437 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %3436)  ; FMax(a,b)
  %3438 = fcmp fast ogt float %3433, %3437
  br i1 %3438, label %3439, label %3500

; <label>:3439                                    ; preds = %3398
  %3440 = fsub fast float %2767, %2977
  %3441 = fsub fast float %2768, %2978
  %3442 = fsub fast float %2769, %2979
  %3443 = call float @dx.op.unary.f32(i32 6, float %3440)  ; FAbs(value)
  %3444 = call float @dx.op.unary.f32(i32 6, float %3441)  ; FAbs(value)
  %3445 = call float @dx.op.unary.f32(i32 6, float %3442)  ; FAbs(value)
  %3446 = call float @dx.op.binary.f32(i32 35, float %3444, float %3445)  ; FMax(a,b)
  %3447 = call float @dx.op.binary.f32(i32 35, float %3443, float %3446)  ; FMax(a,b)
  %3448 = fsub fast float %3189, %3399
  %3449 = fsub fast float %3190, %3400
  %3450 = fsub fast float %3191, %3401
  %3451 = call float @dx.op.unary.f32(i32 6, float %3448)  ; FAbs(value)
  %3452 = call float @dx.op.unary.f32(i32 6, float %3449)  ; FAbs(value)
  %3453 = call float @dx.op.unary.f32(i32 6, float %3450)  ; FAbs(value)
  %3454 = call float @dx.op.binary.f32(i32 35, float %3452, float %3453)  ; FMax(a,b)
  %3455 = call float @dx.op.binary.f32(i32 35, float %3451, float %3454)  ; FMax(a,b)
  %3456 = fcmp fast olt float %3447, %3455
  %3457 = select i1 %3456, float %2767, float %3189
  %3458 = select i1 %3456, float %2768, float %3190
  %3459 = select i1 %3456, float %2769, float %3191
  %3460 = select i1 %3456, float %2977, float %3399
  %3461 = select i1 %3456, float %2978, float %3400
  %3462 = select i1 %3456, float %2979, float %3401
  %3463 = fsub fast float %2555, %3460
  %3464 = fsub fast float %2556, %3461
  %3465 = fsub fast float %2557, %3462
  %3466 = fsub fast float %2555, %3457
  %3467 = fsub fast float %2556, %3458
  %3468 = fsub fast float %2557, %3459
  %3469 = call float @dx.op.dot3.f32(i32 55, float %3466, float %3467, float %3468, float %3463, float %3464, float %3465)  ; Dot3(ax,ay,az,bx,by,bz)
  %3470 = fcmp fast ogt float %3469, 0.000000e+00
  br i1 %3470, label %3471, label %3482

; <label>:3471                                    ; preds = %3439
  %3472 = fsub fast float %3457, %3460
  %3473 = fsub fast float %3458, %3461
  %3474 = fsub fast float %3459, %3462
  %3475 = call float @dx.op.unary.f32(i32 6, float %3472)  ; FAbs(value)
  %3476 = call float @dx.op.unary.f32(i32 6, float %3473)  ; FAbs(value)
  %3477 = call float @dx.op.unary.f32(i32 6, float %3474)  ; FAbs(value)
  %3478 = call float @dx.op.binary.f32(i32 35, float %3476, float %3477)  ; FMax(a,b)
  %3479 = call float @dx.op.binary.f32(i32 35, float %3475, float %3478)  ; FMax(a,b)
  %3480 = fmul fast float %3433, 2.500000e-01
  %3481 = fcmp fast olt float %3479, %3480
  br label %3482

; <label>:3482                                    ; preds = %3471, %3439
  %3483 = phi i1 [ false, %3439 ], [ %3481, %3471 ]
  %3484 = select i1 %3483, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  %3485 = fadd fast float %3457, %3460
  %3486 = fadd fast float %3458, %3461
  %3487 = fadd fast float %3459, %3462
  %3488 = fmul fast float %3485, 5.000000e-01
  %3489 = fmul fast float %3486, 5.000000e-01
  %3490 = fmul fast float %3487, 5.000000e-01
  %3491 = fsub fast float %3488, %2555
  %3492 = fsub fast float %3489, %2556
  %3493 = fsub fast float %3490, %2557
  %3494 = fmul fast float %3484, %3491
  %3495 = fmul fast float %3484, %3492
  %3496 = fmul fast float %3484, %3493
  %3497 = fadd fast float %3494, %2555
  %3498 = fadd fast float %3495, %2556
  %3499 = fadd fast float %3496, %2557
  br label %3500

; <label>:3500                                    ; preds = %3482, %3398
  %3501 = phi float [ %3497, %3482 ], [ %2555, %3398 ]
  %3502 = phi float [ %3498, %3482 ], [ %2556, %3398 ]
  %3503 = phi float [ %3499, %3482 ], [ %2557, %3398 ]
  %3504 = fcmp fast ogt float %3501, 0x3F69A5C380000000
  %3505 = fcmp fast ogt float %3502, 0x3F69A5C380000000
  %3506 = fcmp fast ogt float %3503, 0x3F69A5C380000000
  %3507 = select i1 %3504, float 0.000000e+00, float 1.000000e+00
  %3508 = select i1 %3505, float 0.000000e+00, float 1.000000e+00
  %3509 = select i1 %3506, float 0.000000e+00, float 1.000000e+00
  %3510 = fmul fast float %3501, 0x4029D70A40000000
  %3511 = fmul fast float %3502, 0x4029D70A40000000
  %3512 = fmul fast float %3503, 0x4029D70A40000000
  %3513 = call float @dx.op.binary.f32(i32 35, float %3501, float 0.000000e+00)  ; FMax(a,b)
  %3514 = call float @dx.op.binary.f32(i32 35, float %3502, float 0.000000e+00)  ; FMax(a,b)
  %3515 = call float @dx.op.binary.f32(i32 35, float %3503, float 0.000000e+00)  ; FMax(a,b)
  %3516 = call float @dx.op.unary.f32(i32 23, float %3513)  ; Log(value)
  %3517 = call float @dx.op.unary.f32(i32 23, float %3514)  ; Log(value)
  %3518 = call float @dx.op.unary.f32(i32 23, float %3515)  ; Log(value)
  %3519 = fmul fast float %3516, 0x3FDAAAAAA0000000
  %3520 = fmul fast float %3517, 0x3FDAAAAAA0000000
  %3521 = fmul fast float %3518, 0x3FDAAAAAA0000000
  %3522 = call float @dx.op.unary.f32(i32 21, float %3519)  ; Exp(value)
  %3523 = call float @dx.op.unary.f32(i32 21, float %3520)  ; Exp(value)
  %3524 = call float @dx.op.unary.f32(i32 21, float %3521)  ; Exp(value)
  %3525 = fmul fast float %3522, 0x3FF0E147A0000000
  %3526 = fmul fast float %3523, 0x3FF0E147A0000000
  %3527 = fmul fast float %3524, 0x3FF0E147A0000000
  %3528 = fadd fast float %3525, 0xBFAC28F5C0000000
  %3529 = fadd fast float %3526, 0xBFAC28F5C0000000
  %3530 = fadd fast float %3527, 0xBFAC28F5C0000000
  %3531 = fsub fast float %3510, %3528
  %3532 = fsub fast float %3511, %3529
  %3533 = fsub fast float %3512, %3530
  %3534 = fmul fast float %3531, %3507
  %3535 = fmul fast float %3532, %3508
  %3536 = fmul fast float %3533, %3509
  %3537 = fadd fast float %3534, %3528
  %3538 = fadd fast float %3535, %3529
  %3539 = fadd fast float %3536, %3530
  br label %3540

; <label>:3540                                    ; preds = %3500, %2393
  %3541 = phi float [ %2388, %2393 ], [ %3537, %3500 ]
  %3542 = phi float [ %2389, %2393 ], [ %3538, %3500 ]
  %3543 = phi float [ %2390, %2393 ], [ %3539, %3500 ]
  %3544 = phi float [ %2394, %2393 ], [ %2391, %3500 ]
  %3545 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1225, i32 %2386, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3546 = extractvalue %dx.types.ResRet.f32 %3545, 0
  %3547 = extractvalue %dx.types.ResRet.f32 %3545, 1
  %3548 = extractvalue %dx.types.ResRet.f32 %3545, 2
  %3549 = extractvalue %dx.types.ResRet.f32 %3545, 3
  %3550 = fcmp fast olt float %3549, 0.000000e+00
  br i1 %3550, label %3551, label %3553

; <label>:3551                                    ; preds = %3540
  %3552 = fsub fast float -1.000000e+00, %3549
  br label %4698

; <label>:3553                                    ; preds = %3540
  %3554 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1225, i32 %2386, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3555 = extractvalue %dx.types.ResRet.f32 %3554, 0
  %3556 = fcmp fast ogt float %38, 5.000000e-01
  %3557 = fcmp fast olt float %3555, 1.000000e+00
  %3558 = and i1 %3556, %3557
  br i1 %3558, label %3559, label %3645

; <label>:3559                                    ; preds = %3553
  %3560 = sitofp i32 %1225 to float
  %3561 = sitofp i32 %2386 to float
  %3562 = fadd fast float %3560, 5.000000e-01
  %3563 = fadd fast float %3561, 5.000000e-01
  %3564 = fdiv fast float %3562, %45
  %3565 = fdiv fast float %3563, %46
  %3566 = fmul fast float %3564, 2.000000e+00
  %3567 = fmul fast float %3565, 2.000000e+00
  %3568 = fadd fast float %3566, -1.000000e+00
  %3569 = fsub fast float 1.000000e+00, %3567
  %3570 = fmul fast float %3568, %35
  %3571 = call float @dx.op.tertiary.f32(i32 46, float %3569, float %31, float %3570)  ; FMad(a,b,c)
  %3572 = call float @dx.op.tertiary.f32(i32 46, float %3555, float %27, float %3571)  ; FMad(a,b,c)
  %3573 = fadd fast float %3572, %23
  %3574 = call float @dx.op.unary.f32(i32 6, float %3573)  ; FAbs(value)
  %3575 = fcmp fast ogt float %3574, 0x3EB0C6F7A0000000
  br i1 %3575, label %3576, label %3645

; <label>:3576                                    ; preds = %3559
  %3577 = fmul fast float %3568, %34
  %3578 = call float @dx.op.tertiary.f32(i32 46, float %3569, float %30, float %3577)  ; FMad(a,b,c)
  %3579 = call float @dx.op.tertiary.f32(i32 46, float %3555, float %26, float %3578)  ; FMad(a,b,c)
  %3580 = fadd fast float %3579, %22
  %3581 = fmul fast float %3568, %33
  %3582 = call float @dx.op.tertiary.f32(i32 46, float %3569, float %29, float %3581)  ; FMad(a,b,c)
  %3583 = call float @dx.op.tertiary.f32(i32 46, float %3555, float %25, float %3582)  ; FMad(a,b,c)
  %3584 = fadd fast float %3583, %21
  %3585 = fmul fast float %3568, %32
  %3586 = call float @dx.op.tertiary.f32(i32 46, float %3569, float %28, float %3585)  ; FMad(a,b,c)
  %3587 = call float @dx.op.tertiary.f32(i32 46, float %3555, float %24, float %3586)  ; FMad(a,b,c)
  %3588 = fadd fast float %3587, %20
  %3589 = fdiv fast float %3588, %3573
  %3590 = fdiv fast float %3584, %3573
  %3591 = fdiv fast float %3580, %3573
  %3592 = fsub fast float %3589, %17
  %3593 = fsub fast float %3590, %18
  %3594 = fsub fast float %3591, %19
  %3595 = fmul fast float %3592, %3592
  %3596 = fmul fast float %3593, %3593
  %3597 = fadd fast float %3596, %3595
  %3598 = fmul fast float %3594, %3594
  %3599 = fadd fast float %3597, %3598
  %3600 = call float @dx.op.unary.f32(i32 24, float %3599)  ; Sqrt(value)
  %3601 = fsub fast float %3600, %9
  %3602 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3601)  ; FMax(a,b)
  %3603 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %3603, label %3604, label %3627

; <label>:3604                                    ; preds = %3576
  %3605 = call float @dx.op.unary.f32(i32 6, float %3593)  ; FAbs(value)
  %3606 = fmul fast float %3605, %11
  %3607 = fcmp fast olt float %3606, 0x3F50624DE0000000
  br i1 %3607, label %3608, label %3611

; <label>:3608                                    ; preds = %3604
  %3609 = fmul fast float %3606, 5.000000e-01
  %3610 = fsub fast float 1.000000e+00, %3609
  br label %3616

; <label>:3611                                    ; preds = %3604
  %3612 = fmul fast float %3606, 0xBFF7154760000000
  %3613 = call float @dx.op.unary.f32(i32 21, float %3612)  ; Exp(value)
  %3614 = fsub fast float 1.000000e+00, %3613
  %3615 = fdiv fast float %3614, %3606
  br label %3616

; <label>:3616                                    ; preds = %3611, %3608
  %3617 = phi float [ %3610, %3608 ], [ %3615, %3611 ]
  %3618 = call float @dx.op.binary.f32(i32 36, float %3590, float %18)  ; FMin(a,b)
  %3619 = fsub fast float %3618, %10
  %3620 = fmul fast float %11, %3619
  %3621 = fsub fast float -0.000000e+00, %3620
  %3622 = call float @dx.op.binary.f32(i32 35, float %3621, float -4.000000e+01)  ; FMax(a,b)
  %3623 = call float @dx.op.binary.f32(i32 36, float %3622, float 5.000000e+00)  ; FMin(a,b)
  %3624 = fmul fast float %3623, 0x3FF7154760000000
  %3625 = call float @dx.op.unary.f32(i32 21, float %3624)  ; Exp(value)
  %3626 = fmul fast float %3625, %3617
  br label %3627

; <label>:3627                                    ; preds = %3616, %3576
  %3628 = phi float [ %3626, %3616 ], [ 1.000000e+00, %3576 ]
  %3629 = fmul fast float %3602, %16
  %3630 = fmul fast float %3629, %3628
  %3631 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3630)  ; FMin(a,b)
  %3632 = fmul fast float %3631, 0xBFF7154760000000
  %3633 = call float @dx.op.unary.f32(i32 21, float %3632)  ; Exp(value)
  %3634 = fsub fast float 1.000000e+00, %3633
  %3635 = call float @dx.op.binary.f32(i32 36, float %12, float %3634)  ; FMin(a,b)
  %3636 = fsub fast float %13, %3546
  %3637 = fsub fast float %14, %3547
  %3638 = fsub fast float %15, %3548
  %3639 = fmul fast float %3635, %3636
  %3640 = fmul fast float %3635, %3637
  %3641 = fmul fast float %3635, %3638
  %3642 = fadd fast float %3639, %3546
  %3643 = fadd fast float %3640, %3547
  %3644 = fadd fast float %3641, %3548
  br label %3645

; <label>:3645                                    ; preds = %3627, %3559, %3553
  %3646 = phi float [ %3642, %3627 ], [ %3546, %3559 ], [ %3546, %3553 ]
  %3647 = phi float [ %3643, %3627 ], [ %3547, %3559 ], [ %3547, %3553 ]
  %3648 = phi float [ %3644, %3627 ], [ %3548, %3559 ], [ %3548, %3553 ]
  %3649 = fadd fast float %5, 1.000000e+00
  %3650 = fadd fast float %6, 1.000000e+00
  %3651 = fsub fast float 1.000000e+00, %5
  %3652 = fmul fast float %36, %3649
  %3653 = fmul fast float %36, %3650
  %3654 = fmul fast float %36, %3651
  %3655 = fmul fast float %3652, %3646
  %3656 = fmul fast float %3653, %3647
  %3657 = fmul fast float %3654, %3648
  %3658 = fcmp fast ult float %37, 5.000000e-01
  br i1 %3658, label %3684, label %3659

; <label>:3659                                    ; preds = %3645
  %3660 = fmul fast float %3655, 0x4004147AE0000000
  %3661 = fmul fast float %3656, 0x4004147AE0000000
  %3662 = fmul fast float %3657, 0x4004147AE0000000
  %3663 = fadd fast float %3660, 0x3F9EB851E0000000
  %3664 = fadd fast float %3661, 0x3F9EB851E0000000
  %3665 = fadd fast float %3662, 0x3F9EB851E0000000
  %3666 = fmul fast float %3663, %3655
  %3667 = fmul fast float %3664, %3656
  %3668 = fmul fast float %3665, %3657
  %3669 = fmul fast float %3655, 0x400370A3E0000000
  %3670 = fmul fast float %3656, 0x400370A3E0000000
  %3671 = fmul fast float %3657, 0x400370A3E0000000
  %3672 = fadd fast float %3669, 0x3FE2E147A0000000
  %3673 = fadd fast float %3670, 0x3FE2E147A0000000
  %3674 = fadd fast float %3671, 0x3FE2E147A0000000
  %3675 = fmul fast float %3672, %3655
  %3676 = fmul fast float %3673, %3656
  %3677 = fmul fast float %3674, %3657
  %3678 = fadd fast float %3675, 0x3FC1EB8520000000
  %3679 = fadd fast float %3676, 0x3FC1EB8520000000
  %3680 = fadd fast float %3677, 0x3FC1EB8520000000
  %3681 = fdiv fast float %3666, %3678
  %3682 = fdiv fast float %3667, %3679
  %3683 = fdiv fast float %3668, %3680
  br label %3684

; <label>:3684                                    ; preds = %3659, %3645
  %3685 = phi float [ %3681, %3659 ], [ %3655, %3645 ]
  %3686 = phi float [ %3682, %3659 ], [ %3656, %3645 ]
  %3687 = phi float [ %3683, %3659 ], [ %3657, %3645 ]
  %3688 = call float @dx.op.unary.f32(i32 7, float %3685)  ; Saturate(value)
  %3689 = call float @dx.op.unary.f32(i32 7, float %3686)  ; Saturate(value)
  %3690 = call float @dx.op.unary.f32(i32 7, float %3687)  ; Saturate(value)
  %3691 = call float @dx.op.dot3.f32(i32 55, float %3688, float %3689, float %3690, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3692 = fsub fast float %3688, %3691
  %3693 = fsub fast float %3689, %3691
  %3694 = fsub fast float %3690, %3691
  %3695 = fmul fast float %3692, %8
  %3696 = fmul fast float %3693, %8
  %3697 = fmul fast float %3694, %8
  %3698 = fadd fast float %3695, %3691
  %3699 = fadd fast float %3696, %3691
  %3700 = fadd fast float %3697, %3691
  %3701 = call float @dx.op.unary.f32(i32 7, float %3698)  ; Saturate(value)
  %3702 = call float @dx.op.unary.f32(i32 7, float %3699)  ; Saturate(value)
  %3703 = call float @dx.op.unary.f32(i32 7, float %3700)  ; Saturate(value)
  %3704 = fadd fast float %3701, 0xBFC70A3D80000000
  %3705 = fadd fast float %3702, 0xBFC70A3D80000000
  %3706 = fadd fast float %3703, 0xBFC70A3D80000000
  %3707 = fmul fast float %3704, %7
  %3708 = fmul fast float %3705, %7
  %3709 = fmul fast float %3706, %7
  %3710 = fadd fast float %3707, 0x3FC70A3D80000000
  %3711 = fadd fast float %3708, 0x3FC70A3D80000000
  %3712 = fadd fast float %3709, 0x3FC70A3D80000000
  %3713 = call float @dx.op.unary.f32(i32 7, float %3710)  ; Saturate(value)
  %3714 = call float @dx.op.unary.f32(i32 7, float %3711)  ; Saturate(value)
  %3715 = call float @dx.op.unary.f32(i32 7, float %3712)  ; Saturate(value)
  %3716 = add i32 %2386, -1
  %3717 = call i32 @dx.op.binary.i32(i32 37, i32 %1225, i32 0)  ; IMax(a,b)
  %3718 = call i32 @dx.op.binary.i32(i32 37, i32 %3716, i32 0)  ; IMax(a,b)
  %3719 = call i32 @dx.op.binary.i32(i32 38, i32 %3717, i32 %59)  ; IMin(a,b)
  %3720 = call i32 @dx.op.binary.i32(i32 38, i32 %3718, i32 %60)  ; IMin(a,b)
  %3721 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3719, i32 %3720, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3722 = extractvalue %dx.types.ResRet.f32 %3721, 0
  %3723 = extractvalue %dx.types.ResRet.f32 %3721, 1
  %3724 = extractvalue %dx.types.ResRet.f32 %3721, 2
  %3725 = extractvalue %dx.types.ResRet.f32 %3721, 3
  %3726 = fcmp fast olt float %3725, 0.000000e+00
  br i1 %3726, label %3727, label %3761

; <label>:3727                                    ; preds = %3684
  %3728 = fcmp fast ogt float %3722, 0x3FA4B5DCC0000000
  %3729 = fcmp fast ogt float %3723, 0x3FA4B5DCC0000000
  %3730 = fcmp fast ogt float %3724, 0x3FA4B5DCC0000000
  %3731 = select i1 %3728, float 0.000000e+00, float 1.000000e+00
  %3732 = select i1 %3729, float 0.000000e+00, float 1.000000e+00
  %3733 = select i1 %3730, float 0.000000e+00, float 1.000000e+00
  %3734 = fmul fast float %3722, 0x3FB3D07220000000
  %3735 = fmul fast float %3723, 0x3FB3D07220000000
  %3736 = fmul fast float %3724, 0x3FB3D07220000000
  %3737 = fadd fast float %3722, 0x3FAC28F5C0000000
  %3738 = fadd fast float %3723, 0x3FAC28F5C0000000
  %3739 = fadd fast float %3724, 0x3FAC28F5C0000000
  %3740 = fmul fast float %3737, 0x3FEE54EDE0000000
  %3741 = fmul fast float %3738, 0x3FEE54EDE0000000
  %3742 = fmul fast float %3739, 0x3FEE54EDE0000000
  %3743 = call float @dx.op.unary.f32(i32 23, float %3740)  ; Log(value)
  %3744 = call float @dx.op.unary.f32(i32 23, float %3741)  ; Log(value)
  %3745 = call float @dx.op.unary.f32(i32 23, float %3742)  ; Log(value)
  %3746 = fmul fast float %3743, 0x4003333340000000
  %3747 = fmul fast float %3744, 0x4003333340000000
  %3748 = fmul fast float %3745, 0x4003333340000000
  %3749 = call float @dx.op.unary.f32(i32 21, float %3746)  ; Exp(value)
  %3750 = call float @dx.op.unary.f32(i32 21, float %3747)  ; Exp(value)
  %3751 = call float @dx.op.unary.f32(i32 21, float %3748)  ; Exp(value)
  %3752 = fsub fast float %3734, %3749
  %3753 = fsub fast float %3735, %3750
  %3754 = fsub fast float %3736, %3751
  %3755 = fmul fast float %3752, %3731
  %3756 = fmul fast float %3753, %3732
  %3757 = fmul fast float %3754, %3733
  %3758 = fadd fast float %3755, %3749
  %3759 = fadd fast float %3756, %3750
  %3760 = fadd fast float %3757, %3751
  br label %3924

; <label>:3761                                    ; preds = %3684
  %3762 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3719, i32 %3720, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3763 = extractvalue %dx.types.ResRet.f32 %3762, 0
  %3764 = fcmp fast ogt float %38, 5.000000e-01
  %3765 = fcmp fast olt float %3763, 1.000000e+00
  %3766 = and i1 %3764, %3765
  br i1 %3766, label %3767, label %3853

; <label>:3767                                    ; preds = %3761
  %3768 = sitofp i32 %3719 to float
  %3769 = sitofp i32 %3720 to float
  %3770 = fadd fast float %3768, 5.000000e-01
  %3771 = fadd fast float %3769, 5.000000e-01
  %3772 = fdiv fast float %3770, %45
  %3773 = fdiv fast float %3771, %46
  %3774 = fmul fast float %3772, 2.000000e+00
  %3775 = fmul fast float %3773, 2.000000e+00
  %3776 = fadd fast float %3774, -1.000000e+00
  %3777 = fsub fast float 1.000000e+00, %3775
  %3778 = fmul fast float %3776, %35
  %3779 = call float @dx.op.tertiary.f32(i32 46, float %3777, float %31, float %3778)  ; FMad(a,b,c)
  %3780 = call float @dx.op.tertiary.f32(i32 46, float %3763, float %27, float %3779)  ; FMad(a,b,c)
  %3781 = fadd fast float %3780, %23
  %3782 = call float @dx.op.unary.f32(i32 6, float %3781)  ; FAbs(value)
  %3783 = fcmp fast ogt float %3782, 0x3EB0C6F7A0000000
  br i1 %3783, label %3784, label %3853

; <label>:3784                                    ; preds = %3767
  %3785 = fmul fast float %3776, %34
  %3786 = call float @dx.op.tertiary.f32(i32 46, float %3777, float %30, float %3785)  ; FMad(a,b,c)
  %3787 = call float @dx.op.tertiary.f32(i32 46, float %3763, float %26, float %3786)  ; FMad(a,b,c)
  %3788 = fadd fast float %3787, %22
  %3789 = fmul fast float %3776, %33
  %3790 = call float @dx.op.tertiary.f32(i32 46, float %3777, float %29, float %3789)  ; FMad(a,b,c)
  %3791 = call float @dx.op.tertiary.f32(i32 46, float %3763, float %25, float %3790)  ; FMad(a,b,c)
  %3792 = fadd fast float %3791, %21
  %3793 = fmul fast float %3776, %32
  %3794 = call float @dx.op.tertiary.f32(i32 46, float %3777, float %28, float %3793)  ; FMad(a,b,c)
  %3795 = call float @dx.op.tertiary.f32(i32 46, float %3763, float %24, float %3794)  ; FMad(a,b,c)
  %3796 = fadd fast float %3795, %20
  %3797 = fdiv fast float %3796, %3781
  %3798 = fdiv fast float %3792, %3781
  %3799 = fdiv fast float %3788, %3781
  %3800 = fsub fast float %3797, %17
  %3801 = fsub fast float %3798, %18
  %3802 = fsub fast float %3799, %19
  %3803 = fmul fast float %3800, %3800
  %3804 = fmul fast float %3801, %3801
  %3805 = fadd fast float %3804, %3803
  %3806 = fmul fast float %3802, %3802
  %3807 = fadd fast float %3805, %3806
  %3808 = call float @dx.op.unary.f32(i32 24, float %3807)  ; Sqrt(value)
  %3809 = fsub fast float %3808, %9
  %3810 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3809)  ; FMax(a,b)
  %3811 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %3811, label %3812, label %3835

; <label>:3812                                    ; preds = %3784
  %3813 = call float @dx.op.unary.f32(i32 6, float %3801)  ; FAbs(value)
  %3814 = fmul fast float %3813, %11
  %3815 = fcmp fast olt float %3814, 0x3F50624DE0000000
  br i1 %3815, label %3816, label %3819

; <label>:3816                                    ; preds = %3812
  %3817 = fmul fast float %3814, 5.000000e-01
  %3818 = fsub fast float 1.000000e+00, %3817
  br label %3824

; <label>:3819                                    ; preds = %3812
  %3820 = fmul fast float %3814, 0xBFF7154760000000
  %3821 = call float @dx.op.unary.f32(i32 21, float %3820)  ; Exp(value)
  %3822 = fsub fast float 1.000000e+00, %3821
  %3823 = fdiv fast float %3822, %3814
  br label %3824

; <label>:3824                                    ; preds = %3819, %3816
  %3825 = phi float [ %3818, %3816 ], [ %3823, %3819 ]
  %3826 = call float @dx.op.binary.f32(i32 36, float %3798, float %18)  ; FMin(a,b)
  %3827 = fsub fast float %3826, %10
  %3828 = fmul fast float %11, %3827
  %3829 = fsub fast float -0.000000e+00, %3828
  %3830 = call float @dx.op.binary.f32(i32 35, float %3829, float -4.000000e+01)  ; FMax(a,b)
  %3831 = call float @dx.op.binary.f32(i32 36, float %3830, float 5.000000e+00)  ; FMin(a,b)
  %3832 = fmul fast float %3831, 0x3FF7154760000000
  %3833 = call float @dx.op.unary.f32(i32 21, float %3832)  ; Exp(value)
  %3834 = fmul fast float %3833, %3825
  br label %3835

; <label>:3835                                    ; preds = %3824, %3784
  %3836 = phi float [ %3834, %3824 ], [ 1.000000e+00, %3784 ]
  %3837 = fmul fast float %3810, %16
  %3838 = fmul fast float %3837, %3836
  %3839 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3838)  ; FMin(a,b)
  %3840 = fmul fast float %3839, 0xBFF7154760000000
  %3841 = call float @dx.op.unary.f32(i32 21, float %3840)  ; Exp(value)
  %3842 = fsub fast float 1.000000e+00, %3841
  %3843 = call float @dx.op.binary.f32(i32 36, float %12, float %3842)  ; FMin(a,b)
  %3844 = fsub fast float %13, %3722
  %3845 = fsub fast float %14, %3723
  %3846 = fsub fast float %15, %3724
  %3847 = fmul fast float %3843, %3844
  %3848 = fmul fast float %3843, %3845
  %3849 = fmul fast float %3843, %3846
  %3850 = fadd fast float %3847, %3722
  %3851 = fadd fast float %3848, %3723
  %3852 = fadd fast float %3849, %3724
  br label %3853

; <label>:3853                                    ; preds = %3835, %3767, %3761
  %3854 = phi float [ %3850, %3835 ], [ %3722, %3767 ], [ %3722, %3761 ]
  %3855 = phi float [ %3851, %3835 ], [ %3723, %3767 ], [ %3723, %3761 ]
  %3856 = phi float [ %3852, %3835 ], [ %3724, %3767 ], [ %3724, %3761 ]
  %3857 = fadd fast float %5, 1.000000e+00
  %3858 = fadd fast float %6, 1.000000e+00
  %3859 = fsub fast float 1.000000e+00, %5
  %3860 = fmul fast float %36, %3857
  %3861 = fmul fast float %36, %3858
  %3862 = fmul fast float %36, %3859
  %3863 = fmul fast float %3860, %3854
  %3864 = fmul fast float %3861, %3855
  %3865 = fmul fast float %3862, %3856
  %3866 = fcmp fast ult float %37, 5.000000e-01
  br i1 %3866, label %3892, label %3867

; <label>:3867                                    ; preds = %3853
  %3868 = fmul fast float %3863, 0x4004147AE0000000
  %3869 = fmul fast float %3864, 0x4004147AE0000000
  %3870 = fmul fast float %3865, 0x4004147AE0000000
  %3871 = fadd fast float %3868, 0x3F9EB851E0000000
  %3872 = fadd fast float %3869, 0x3F9EB851E0000000
  %3873 = fadd fast float %3870, 0x3F9EB851E0000000
  %3874 = fmul fast float %3871, %3863
  %3875 = fmul fast float %3872, %3864
  %3876 = fmul fast float %3873, %3865
  %3877 = fmul fast float %3863, 0x400370A3E0000000
  %3878 = fmul fast float %3864, 0x400370A3E0000000
  %3879 = fmul fast float %3865, 0x400370A3E0000000
  %3880 = fadd fast float %3877, 0x3FE2E147A0000000
  %3881 = fadd fast float %3878, 0x3FE2E147A0000000
  %3882 = fadd fast float %3879, 0x3FE2E147A0000000
  %3883 = fmul fast float %3880, %3863
  %3884 = fmul fast float %3881, %3864
  %3885 = fmul fast float %3882, %3865
  %3886 = fadd fast float %3883, 0x3FC1EB8520000000
  %3887 = fadd fast float %3884, 0x3FC1EB8520000000
  %3888 = fadd fast float %3885, 0x3FC1EB8520000000
  %3889 = fdiv fast float %3874, %3886
  %3890 = fdiv fast float %3875, %3887
  %3891 = fdiv fast float %3876, %3888
  br label %3892

; <label>:3892                                    ; preds = %3867, %3853
  %3893 = phi float [ %3889, %3867 ], [ %3863, %3853 ]
  %3894 = phi float [ %3890, %3867 ], [ %3864, %3853 ]
  %3895 = phi float [ %3891, %3867 ], [ %3865, %3853 ]
  %3896 = call float @dx.op.unary.f32(i32 7, float %3893)  ; Saturate(value)
  %3897 = call float @dx.op.unary.f32(i32 7, float %3894)  ; Saturate(value)
  %3898 = call float @dx.op.unary.f32(i32 7, float %3895)  ; Saturate(value)
  %3899 = call float @dx.op.dot3.f32(i32 55, float %3896, float %3897, float %3898, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3900 = fsub fast float %3896, %3899
  %3901 = fsub fast float %3897, %3899
  %3902 = fsub fast float %3898, %3899
  %3903 = fmul fast float %3900, %8
  %3904 = fmul fast float %3901, %8
  %3905 = fmul fast float %3902, %8
  %3906 = fadd fast float %3903, %3899
  %3907 = fadd fast float %3904, %3899
  %3908 = fadd fast float %3905, %3899
  %3909 = call float @dx.op.unary.f32(i32 7, float %3906)  ; Saturate(value)
  %3910 = call float @dx.op.unary.f32(i32 7, float %3907)  ; Saturate(value)
  %3911 = call float @dx.op.unary.f32(i32 7, float %3908)  ; Saturate(value)
  %3912 = fadd fast float %3909, 0xBFC70A3D80000000
  %3913 = fadd fast float %3910, 0xBFC70A3D80000000
  %3914 = fadd fast float %3911, 0xBFC70A3D80000000
  %3915 = fmul fast float %3912, %7
  %3916 = fmul fast float %3913, %7
  %3917 = fmul fast float %3914, %7
  %3918 = fadd fast float %3915, 0x3FC70A3D80000000
  %3919 = fadd fast float %3916, 0x3FC70A3D80000000
  %3920 = fadd fast float %3917, 0x3FC70A3D80000000
  %3921 = call float @dx.op.unary.f32(i32 7, float %3918)  ; Saturate(value)
  %3922 = call float @dx.op.unary.f32(i32 7, float %3919)  ; Saturate(value)
  %3923 = call float @dx.op.unary.f32(i32 7, float %3920)  ; Saturate(value)
  br label %3924

; <label>:3924                                    ; preds = %3892, %3727
  %3925 = phi float [ %3758, %3727 ], [ %3921, %3892 ]
  %3926 = phi float [ %3759, %3727 ], [ %3922, %3892 ]
  %3927 = phi float [ %3760, %3727 ], [ %3923, %3892 ]
  %3928 = add i32 %2386, 1
  %3929 = call i32 @dx.op.binary.i32(i32 37, i32 %3928, i32 0)  ; IMax(a,b)
  %3930 = call i32 @dx.op.binary.i32(i32 38, i32 %3929, i32 %60)  ; IMin(a,b)
  %3931 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3719, i32 %3930, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3932 = extractvalue %dx.types.ResRet.f32 %3931, 0
  %3933 = extractvalue %dx.types.ResRet.f32 %3931, 1
  %3934 = extractvalue %dx.types.ResRet.f32 %3931, 2
  %3935 = extractvalue %dx.types.ResRet.f32 %3931, 3
  %3936 = fcmp fast olt float %3935, 0.000000e+00
  br i1 %3936, label %3937, label %3971

; <label>:3937                                    ; preds = %3924
  %3938 = fcmp fast ogt float %3932, 0x3FA4B5DCC0000000
  %3939 = fcmp fast ogt float %3933, 0x3FA4B5DCC0000000
  %3940 = fcmp fast ogt float %3934, 0x3FA4B5DCC0000000
  %3941 = select i1 %3938, float 0.000000e+00, float 1.000000e+00
  %3942 = select i1 %3939, float 0.000000e+00, float 1.000000e+00
  %3943 = select i1 %3940, float 0.000000e+00, float 1.000000e+00
  %3944 = fmul fast float %3932, 0x3FB3D07220000000
  %3945 = fmul fast float %3933, 0x3FB3D07220000000
  %3946 = fmul fast float %3934, 0x3FB3D07220000000
  %3947 = fadd fast float %3932, 0x3FAC28F5C0000000
  %3948 = fadd fast float %3933, 0x3FAC28F5C0000000
  %3949 = fadd fast float %3934, 0x3FAC28F5C0000000
  %3950 = fmul fast float %3947, 0x3FEE54EDE0000000
  %3951 = fmul fast float %3948, 0x3FEE54EDE0000000
  %3952 = fmul fast float %3949, 0x3FEE54EDE0000000
  %3953 = call float @dx.op.unary.f32(i32 23, float %3950)  ; Log(value)
  %3954 = call float @dx.op.unary.f32(i32 23, float %3951)  ; Log(value)
  %3955 = call float @dx.op.unary.f32(i32 23, float %3952)  ; Log(value)
  %3956 = fmul fast float %3953, 0x4003333340000000
  %3957 = fmul fast float %3954, 0x4003333340000000
  %3958 = fmul fast float %3955, 0x4003333340000000
  %3959 = call float @dx.op.unary.f32(i32 21, float %3956)  ; Exp(value)
  %3960 = call float @dx.op.unary.f32(i32 21, float %3957)  ; Exp(value)
  %3961 = call float @dx.op.unary.f32(i32 21, float %3958)  ; Exp(value)
  %3962 = fsub fast float %3944, %3959
  %3963 = fsub fast float %3945, %3960
  %3964 = fsub fast float %3946, %3961
  %3965 = fmul fast float %3962, %3941
  %3966 = fmul fast float %3963, %3942
  %3967 = fmul fast float %3964, %3943
  %3968 = fadd fast float %3965, %3959
  %3969 = fadd fast float %3966, %3960
  %3970 = fadd fast float %3967, %3961
  br label %4134

; <label>:3971                                    ; preds = %3924
  %3972 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3719, i32 %3930, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3973 = extractvalue %dx.types.ResRet.f32 %3972, 0
  %3974 = fcmp fast ogt float %38, 5.000000e-01
  %3975 = fcmp fast olt float %3973, 1.000000e+00
  %3976 = and i1 %3974, %3975
  br i1 %3976, label %3977, label %4063

; <label>:3977                                    ; preds = %3971
  %3978 = sitofp i32 %3719 to float
  %3979 = sitofp i32 %3930 to float
  %3980 = fadd fast float %3978, 5.000000e-01
  %3981 = fadd fast float %3979, 5.000000e-01
  %3982 = fdiv fast float %3980, %45
  %3983 = fdiv fast float %3981, %46
  %3984 = fmul fast float %3982, 2.000000e+00
  %3985 = fmul fast float %3983, 2.000000e+00
  %3986 = fadd fast float %3984, -1.000000e+00
  %3987 = fsub fast float 1.000000e+00, %3985
  %3988 = fmul fast float %3986, %35
  %3989 = call float @dx.op.tertiary.f32(i32 46, float %3987, float %31, float %3988)  ; FMad(a,b,c)
  %3990 = call float @dx.op.tertiary.f32(i32 46, float %3973, float %27, float %3989)  ; FMad(a,b,c)
  %3991 = fadd fast float %3990, %23
  %3992 = call float @dx.op.unary.f32(i32 6, float %3991)  ; FAbs(value)
  %3993 = fcmp fast ogt float %3992, 0x3EB0C6F7A0000000
  br i1 %3993, label %3994, label %4063

; <label>:3994                                    ; preds = %3977
  %3995 = fmul fast float %3986, %34
  %3996 = call float @dx.op.tertiary.f32(i32 46, float %3987, float %30, float %3995)  ; FMad(a,b,c)
  %3997 = call float @dx.op.tertiary.f32(i32 46, float %3973, float %26, float %3996)  ; FMad(a,b,c)
  %3998 = fadd fast float %3997, %22
  %3999 = fmul fast float %3986, %33
  %4000 = call float @dx.op.tertiary.f32(i32 46, float %3987, float %29, float %3999)  ; FMad(a,b,c)
  %4001 = call float @dx.op.tertiary.f32(i32 46, float %3973, float %25, float %4000)  ; FMad(a,b,c)
  %4002 = fadd fast float %4001, %21
  %4003 = fmul fast float %3986, %32
  %4004 = call float @dx.op.tertiary.f32(i32 46, float %3987, float %28, float %4003)  ; FMad(a,b,c)
  %4005 = call float @dx.op.tertiary.f32(i32 46, float %3973, float %24, float %4004)  ; FMad(a,b,c)
  %4006 = fadd fast float %4005, %20
  %4007 = fdiv fast float %4006, %3991
  %4008 = fdiv fast float %4002, %3991
  %4009 = fdiv fast float %3998, %3991
  %4010 = fsub fast float %4007, %17
  %4011 = fsub fast float %4008, %18
  %4012 = fsub fast float %4009, %19
  %4013 = fmul fast float %4010, %4010
  %4014 = fmul fast float %4011, %4011
  %4015 = fadd fast float %4014, %4013
  %4016 = fmul fast float %4012, %4012
  %4017 = fadd fast float %4015, %4016
  %4018 = call float @dx.op.unary.f32(i32 24, float %4017)  ; Sqrt(value)
  %4019 = fsub fast float %4018, %9
  %4020 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4019)  ; FMax(a,b)
  %4021 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %4021, label %4022, label %4045

; <label>:4022                                    ; preds = %3994
  %4023 = call float @dx.op.unary.f32(i32 6, float %4011)  ; FAbs(value)
  %4024 = fmul fast float %4023, %11
  %4025 = fcmp fast olt float %4024, 0x3F50624DE0000000
  br i1 %4025, label %4026, label %4029

; <label>:4026                                    ; preds = %4022
  %4027 = fmul fast float %4024, 5.000000e-01
  %4028 = fsub fast float 1.000000e+00, %4027
  br label %4034

; <label>:4029                                    ; preds = %4022
  %4030 = fmul fast float %4024, 0xBFF7154760000000
  %4031 = call float @dx.op.unary.f32(i32 21, float %4030)  ; Exp(value)
  %4032 = fsub fast float 1.000000e+00, %4031
  %4033 = fdiv fast float %4032, %4024
  br label %4034

; <label>:4034                                    ; preds = %4029, %4026
  %4035 = phi float [ %4028, %4026 ], [ %4033, %4029 ]
  %4036 = call float @dx.op.binary.f32(i32 36, float %4008, float %18)  ; FMin(a,b)
  %4037 = fsub fast float %4036, %10
  %4038 = fmul fast float %11, %4037
  %4039 = fsub fast float -0.000000e+00, %4038
  %4040 = call float @dx.op.binary.f32(i32 35, float %4039, float -4.000000e+01)  ; FMax(a,b)
  %4041 = call float @dx.op.binary.f32(i32 36, float %4040, float 5.000000e+00)  ; FMin(a,b)
  %4042 = fmul fast float %4041, 0x3FF7154760000000
  %4043 = call float @dx.op.unary.f32(i32 21, float %4042)  ; Exp(value)
  %4044 = fmul fast float %4043, %4035
  br label %4045

; <label>:4045                                    ; preds = %4034, %3994
  %4046 = phi float [ %4044, %4034 ], [ 1.000000e+00, %3994 ]
  %4047 = fmul fast float %4020, %16
  %4048 = fmul fast float %4047, %4046
  %4049 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4048)  ; FMin(a,b)
  %4050 = fmul fast float %4049, 0xBFF7154760000000
  %4051 = call float @dx.op.unary.f32(i32 21, float %4050)  ; Exp(value)
  %4052 = fsub fast float 1.000000e+00, %4051
  %4053 = call float @dx.op.binary.f32(i32 36, float %12, float %4052)  ; FMin(a,b)
  %4054 = fsub fast float %13, %3932
  %4055 = fsub fast float %14, %3933
  %4056 = fsub fast float %15, %3934
  %4057 = fmul fast float %4053, %4054
  %4058 = fmul fast float %4053, %4055
  %4059 = fmul fast float %4053, %4056
  %4060 = fadd fast float %4057, %3932
  %4061 = fadd fast float %4058, %3933
  %4062 = fadd fast float %4059, %3934
  br label %4063

; <label>:4063                                    ; preds = %4045, %3977, %3971
  %4064 = phi float [ %4060, %4045 ], [ %3932, %3977 ], [ %3932, %3971 ]
  %4065 = phi float [ %4061, %4045 ], [ %3933, %3977 ], [ %3933, %3971 ]
  %4066 = phi float [ %4062, %4045 ], [ %3934, %3977 ], [ %3934, %3971 ]
  %4067 = fadd fast float %5, 1.000000e+00
  %4068 = fadd fast float %6, 1.000000e+00
  %4069 = fsub fast float 1.000000e+00, %5
  %4070 = fmul fast float %36, %4067
  %4071 = fmul fast float %36, %4068
  %4072 = fmul fast float %36, %4069
  %4073 = fmul fast float %4070, %4064
  %4074 = fmul fast float %4071, %4065
  %4075 = fmul fast float %4072, %4066
  %4076 = fcmp fast ult float %37, 5.000000e-01
  br i1 %4076, label %4102, label %4077

; <label>:4077                                    ; preds = %4063
  %4078 = fmul fast float %4073, 0x4004147AE0000000
  %4079 = fmul fast float %4074, 0x4004147AE0000000
  %4080 = fmul fast float %4075, 0x4004147AE0000000
  %4081 = fadd fast float %4078, 0x3F9EB851E0000000
  %4082 = fadd fast float %4079, 0x3F9EB851E0000000
  %4083 = fadd fast float %4080, 0x3F9EB851E0000000
  %4084 = fmul fast float %4081, %4073
  %4085 = fmul fast float %4082, %4074
  %4086 = fmul fast float %4083, %4075
  %4087 = fmul fast float %4073, 0x400370A3E0000000
  %4088 = fmul fast float %4074, 0x400370A3E0000000
  %4089 = fmul fast float %4075, 0x400370A3E0000000
  %4090 = fadd fast float %4087, 0x3FE2E147A0000000
  %4091 = fadd fast float %4088, 0x3FE2E147A0000000
  %4092 = fadd fast float %4089, 0x3FE2E147A0000000
  %4093 = fmul fast float %4090, %4073
  %4094 = fmul fast float %4091, %4074
  %4095 = fmul fast float %4092, %4075
  %4096 = fadd fast float %4093, 0x3FC1EB8520000000
  %4097 = fadd fast float %4094, 0x3FC1EB8520000000
  %4098 = fadd fast float %4095, 0x3FC1EB8520000000
  %4099 = fdiv fast float %4084, %4096
  %4100 = fdiv fast float %4085, %4097
  %4101 = fdiv fast float %4086, %4098
  br label %4102

; <label>:4102                                    ; preds = %4077, %4063
  %4103 = phi float [ %4099, %4077 ], [ %4073, %4063 ]
  %4104 = phi float [ %4100, %4077 ], [ %4074, %4063 ]
  %4105 = phi float [ %4101, %4077 ], [ %4075, %4063 ]
  %4106 = call float @dx.op.unary.f32(i32 7, float %4103)  ; Saturate(value)
  %4107 = call float @dx.op.unary.f32(i32 7, float %4104)  ; Saturate(value)
  %4108 = call float @dx.op.unary.f32(i32 7, float %4105)  ; Saturate(value)
  %4109 = call float @dx.op.dot3.f32(i32 55, float %4106, float %4107, float %4108, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4110 = fsub fast float %4106, %4109
  %4111 = fsub fast float %4107, %4109
  %4112 = fsub fast float %4108, %4109
  %4113 = fmul fast float %4110, %8
  %4114 = fmul fast float %4111, %8
  %4115 = fmul fast float %4112, %8
  %4116 = fadd fast float %4113, %4109
  %4117 = fadd fast float %4114, %4109
  %4118 = fadd fast float %4115, %4109
  %4119 = call float @dx.op.unary.f32(i32 7, float %4116)  ; Saturate(value)
  %4120 = call float @dx.op.unary.f32(i32 7, float %4117)  ; Saturate(value)
  %4121 = call float @dx.op.unary.f32(i32 7, float %4118)  ; Saturate(value)
  %4122 = fadd fast float %4119, 0xBFC70A3D80000000
  %4123 = fadd fast float %4120, 0xBFC70A3D80000000
  %4124 = fadd fast float %4121, 0xBFC70A3D80000000
  %4125 = fmul fast float %4122, %7
  %4126 = fmul fast float %4123, %7
  %4127 = fmul fast float %4124, %7
  %4128 = fadd fast float %4125, 0x3FC70A3D80000000
  %4129 = fadd fast float %4126, 0x3FC70A3D80000000
  %4130 = fadd fast float %4127, 0x3FC70A3D80000000
  %4131 = call float @dx.op.unary.f32(i32 7, float %4128)  ; Saturate(value)
  %4132 = call float @dx.op.unary.f32(i32 7, float %4129)  ; Saturate(value)
  %4133 = call float @dx.op.unary.f32(i32 7, float %4130)  ; Saturate(value)
  br label %4134

; <label>:4134                                    ; preds = %4102, %3937
  %4135 = phi float [ %3968, %3937 ], [ %4131, %4102 ]
  %4136 = phi float [ %3969, %3937 ], [ %4132, %4102 ]
  %4137 = phi float [ %3970, %3937 ], [ %4133, %4102 ]
  %4138 = add i32 %1225, -1
  %4139 = call i32 @dx.op.binary.i32(i32 37, i32 %4138, i32 0)  ; IMax(a,b)
  %4140 = call i32 @dx.op.binary.i32(i32 37, i32 %2386, i32 0)  ; IMax(a,b)
  %4141 = call i32 @dx.op.binary.i32(i32 38, i32 %4139, i32 %59)  ; IMin(a,b)
  %4142 = call i32 @dx.op.binary.i32(i32 38, i32 %4140, i32 %60)  ; IMin(a,b)
  %4143 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4141, i32 %4142, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4144 = extractvalue %dx.types.ResRet.f32 %4143, 0
  %4145 = extractvalue %dx.types.ResRet.f32 %4143, 1
  %4146 = extractvalue %dx.types.ResRet.f32 %4143, 2
  %4147 = extractvalue %dx.types.ResRet.f32 %4143, 3
  %4148 = fcmp fast olt float %4147, 0.000000e+00
  br i1 %4148, label %4149, label %4183

; <label>:4149                                    ; preds = %4134
  %4150 = fcmp fast ogt float %4144, 0x3FA4B5DCC0000000
  %4151 = fcmp fast ogt float %4145, 0x3FA4B5DCC0000000
  %4152 = fcmp fast ogt float %4146, 0x3FA4B5DCC0000000
  %4153 = select i1 %4150, float 0.000000e+00, float 1.000000e+00
  %4154 = select i1 %4151, float 0.000000e+00, float 1.000000e+00
  %4155 = select i1 %4152, float 0.000000e+00, float 1.000000e+00
  %4156 = fmul fast float %4144, 0x3FB3D07220000000
  %4157 = fmul fast float %4145, 0x3FB3D07220000000
  %4158 = fmul fast float %4146, 0x3FB3D07220000000
  %4159 = fadd fast float %4144, 0x3FAC28F5C0000000
  %4160 = fadd fast float %4145, 0x3FAC28F5C0000000
  %4161 = fadd fast float %4146, 0x3FAC28F5C0000000
  %4162 = fmul fast float %4159, 0x3FEE54EDE0000000
  %4163 = fmul fast float %4160, 0x3FEE54EDE0000000
  %4164 = fmul fast float %4161, 0x3FEE54EDE0000000
  %4165 = call float @dx.op.unary.f32(i32 23, float %4162)  ; Log(value)
  %4166 = call float @dx.op.unary.f32(i32 23, float %4163)  ; Log(value)
  %4167 = call float @dx.op.unary.f32(i32 23, float %4164)  ; Log(value)
  %4168 = fmul fast float %4165, 0x4003333340000000
  %4169 = fmul fast float %4166, 0x4003333340000000
  %4170 = fmul fast float %4167, 0x4003333340000000
  %4171 = call float @dx.op.unary.f32(i32 21, float %4168)  ; Exp(value)
  %4172 = call float @dx.op.unary.f32(i32 21, float %4169)  ; Exp(value)
  %4173 = call float @dx.op.unary.f32(i32 21, float %4170)  ; Exp(value)
  %4174 = fsub fast float %4156, %4171
  %4175 = fsub fast float %4157, %4172
  %4176 = fsub fast float %4158, %4173
  %4177 = fmul fast float %4174, %4153
  %4178 = fmul fast float %4175, %4154
  %4179 = fmul fast float %4176, %4155
  %4180 = fadd fast float %4177, %4171
  %4181 = fadd fast float %4178, %4172
  %4182 = fadd fast float %4179, %4173
  br label %4346

; <label>:4183                                    ; preds = %4134
  %4184 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4141, i32 %4142, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4185 = extractvalue %dx.types.ResRet.f32 %4184, 0
  %4186 = fcmp fast ogt float %38, 5.000000e-01
  %4187 = fcmp fast olt float %4185, 1.000000e+00
  %4188 = and i1 %4186, %4187
  br i1 %4188, label %4189, label %4275

; <label>:4189                                    ; preds = %4183
  %4190 = sitofp i32 %4141 to float
  %4191 = sitofp i32 %4142 to float
  %4192 = fadd fast float %4190, 5.000000e-01
  %4193 = fadd fast float %4191, 5.000000e-01
  %4194 = fdiv fast float %4192, %45
  %4195 = fdiv fast float %4193, %46
  %4196 = fmul fast float %4194, 2.000000e+00
  %4197 = fmul fast float %4195, 2.000000e+00
  %4198 = fadd fast float %4196, -1.000000e+00
  %4199 = fsub fast float 1.000000e+00, %4197
  %4200 = fmul fast float %4198, %35
  %4201 = call float @dx.op.tertiary.f32(i32 46, float %4199, float %31, float %4200)  ; FMad(a,b,c)
  %4202 = call float @dx.op.tertiary.f32(i32 46, float %4185, float %27, float %4201)  ; FMad(a,b,c)
  %4203 = fadd fast float %4202, %23
  %4204 = call float @dx.op.unary.f32(i32 6, float %4203)  ; FAbs(value)
  %4205 = fcmp fast ogt float %4204, 0x3EB0C6F7A0000000
  br i1 %4205, label %4206, label %4275

; <label>:4206                                    ; preds = %4189
  %4207 = fmul fast float %4198, %34
  %4208 = call float @dx.op.tertiary.f32(i32 46, float %4199, float %30, float %4207)  ; FMad(a,b,c)
  %4209 = call float @dx.op.tertiary.f32(i32 46, float %4185, float %26, float %4208)  ; FMad(a,b,c)
  %4210 = fadd fast float %4209, %22
  %4211 = fmul fast float %4198, %33
  %4212 = call float @dx.op.tertiary.f32(i32 46, float %4199, float %29, float %4211)  ; FMad(a,b,c)
  %4213 = call float @dx.op.tertiary.f32(i32 46, float %4185, float %25, float %4212)  ; FMad(a,b,c)
  %4214 = fadd fast float %4213, %21
  %4215 = fmul fast float %4198, %32
  %4216 = call float @dx.op.tertiary.f32(i32 46, float %4199, float %28, float %4215)  ; FMad(a,b,c)
  %4217 = call float @dx.op.tertiary.f32(i32 46, float %4185, float %24, float %4216)  ; FMad(a,b,c)
  %4218 = fadd fast float %4217, %20
  %4219 = fdiv fast float %4218, %4203
  %4220 = fdiv fast float %4214, %4203
  %4221 = fdiv fast float %4210, %4203
  %4222 = fsub fast float %4219, %17
  %4223 = fsub fast float %4220, %18
  %4224 = fsub fast float %4221, %19
  %4225 = fmul fast float %4222, %4222
  %4226 = fmul fast float %4223, %4223
  %4227 = fadd fast float %4226, %4225
  %4228 = fmul fast float %4224, %4224
  %4229 = fadd fast float %4227, %4228
  %4230 = call float @dx.op.unary.f32(i32 24, float %4229)  ; Sqrt(value)
  %4231 = fsub fast float %4230, %9
  %4232 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4231)  ; FMax(a,b)
  %4233 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %4233, label %4234, label %4257

; <label>:4234                                    ; preds = %4206
  %4235 = call float @dx.op.unary.f32(i32 6, float %4223)  ; FAbs(value)
  %4236 = fmul fast float %4235, %11
  %4237 = fcmp fast olt float %4236, 0x3F50624DE0000000
  br i1 %4237, label %4238, label %4241

; <label>:4238                                    ; preds = %4234
  %4239 = fmul fast float %4236, 5.000000e-01
  %4240 = fsub fast float 1.000000e+00, %4239
  br label %4246

; <label>:4241                                    ; preds = %4234
  %4242 = fmul fast float %4236, 0xBFF7154760000000
  %4243 = call float @dx.op.unary.f32(i32 21, float %4242)  ; Exp(value)
  %4244 = fsub fast float 1.000000e+00, %4243
  %4245 = fdiv fast float %4244, %4236
  br label %4246

; <label>:4246                                    ; preds = %4241, %4238
  %4247 = phi float [ %4240, %4238 ], [ %4245, %4241 ]
  %4248 = call float @dx.op.binary.f32(i32 36, float %4220, float %18)  ; FMin(a,b)
  %4249 = fsub fast float %4248, %10
  %4250 = fmul fast float %11, %4249
  %4251 = fsub fast float -0.000000e+00, %4250
  %4252 = call float @dx.op.binary.f32(i32 35, float %4251, float -4.000000e+01)  ; FMax(a,b)
  %4253 = call float @dx.op.binary.f32(i32 36, float %4252, float 5.000000e+00)  ; FMin(a,b)
  %4254 = fmul fast float %4253, 0x3FF7154760000000
  %4255 = call float @dx.op.unary.f32(i32 21, float %4254)  ; Exp(value)
  %4256 = fmul fast float %4255, %4247
  br label %4257

; <label>:4257                                    ; preds = %4246, %4206
  %4258 = phi float [ %4256, %4246 ], [ 1.000000e+00, %4206 ]
  %4259 = fmul fast float %4232, %16
  %4260 = fmul fast float %4259, %4258
  %4261 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4260)  ; FMin(a,b)
  %4262 = fmul fast float %4261, 0xBFF7154760000000
  %4263 = call float @dx.op.unary.f32(i32 21, float %4262)  ; Exp(value)
  %4264 = fsub fast float 1.000000e+00, %4263
  %4265 = call float @dx.op.binary.f32(i32 36, float %12, float %4264)  ; FMin(a,b)
  %4266 = fsub fast float %13, %4144
  %4267 = fsub fast float %14, %4145
  %4268 = fsub fast float %15, %4146
  %4269 = fmul fast float %4265, %4266
  %4270 = fmul fast float %4265, %4267
  %4271 = fmul fast float %4265, %4268
  %4272 = fadd fast float %4269, %4144
  %4273 = fadd fast float %4270, %4145
  %4274 = fadd fast float %4271, %4146
  br label %4275

; <label>:4275                                    ; preds = %4257, %4189, %4183
  %4276 = phi float [ %4272, %4257 ], [ %4144, %4189 ], [ %4144, %4183 ]
  %4277 = phi float [ %4273, %4257 ], [ %4145, %4189 ], [ %4145, %4183 ]
  %4278 = phi float [ %4274, %4257 ], [ %4146, %4189 ], [ %4146, %4183 ]
  %4279 = fadd fast float %5, 1.000000e+00
  %4280 = fadd fast float %6, 1.000000e+00
  %4281 = fsub fast float 1.000000e+00, %5
  %4282 = fmul fast float %36, %4279
  %4283 = fmul fast float %36, %4280
  %4284 = fmul fast float %36, %4281
  %4285 = fmul fast float %4282, %4276
  %4286 = fmul fast float %4283, %4277
  %4287 = fmul fast float %4284, %4278
  %4288 = fcmp fast ult float %37, 5.000000e-01
  br i1 %4288, label %4314, label %4289

; <label>:4289                                    ; preds = %4275
  %4290 = fmul fast float %4285, 0x4004147AE0000000
  %4291 = fmul fast float %4286, 0x4004147AE0000000
  %4292 = fmul fast float %4287, 0x4004147AE0000000
  %4293 = fadd fast float %4290, 0x3F9EB851E0000000
  %4294 = fadd fast float %4291, 0x3F9EB851E0000000
  %4295 = fadd fast float %4292, 0x3F9EB851E0000000
  %4296 = fmul fast float %4293, %4285
  %4297 = fmul fast float %4294, %4286
  %4298 = fmul fast float %4295, %4287
  %4299 = fmul fast float %4285, 0x400370A3E0000000
  %4300 = fmul fast float %4286, 0x400370A3E0000000
  %4301 = fmul fast float %4287, 0x400370A3E0000000
  %4302 = fadd fast float %4299, 0x3FE2E147A0000000
  %4303 = fadd fast float %4300, 0x3FE2E147A0000000
  %4304 = fadd fast float %4301, 0x3FE2E147A0000000
  %4305 = fmul fast float %4302, %4285
  %4306 = fmul fast float %4303, %4286
  %4307 = fmul fast float %4304, %4287
  %4308 = fadd fast float %4305, 0x3FC1EB8520000000
  %4309 = fadd fast float %4306, 0x3FC1EB8520000000
  %4310 = fadd fast float %4307, 0x3FC1EB8520000000
  %4311 = fdiv fast float %4296, %4308
  %4312 = fdiv fast float %4297, %4309
  %4313 = fdiv fast float %4298, %4310
  br label %4314

; <label>:4314                                    ; preds = %4289, %4275
  %4315 = phi float [ %4311, %4289 ], [ %4285, %4275 ]
  %4316 = phi float [ %4312, %4289 ], [ %4286, %4275 ]
  %4317 = phi float [ %4313, %4289 ], [ %4287, %4275 ]
  %4318 = call float @dx.op.unary.f32(i32 7, float %4315)  ; Saturate(value)
  %4319 = call float @dx.op.unary.f32(i32 7, float %4316)  ; Saturate(value)
  %4320 = call float @dx.op.unary.f32(i32 7, float %4317)  ; Saturate(value)
  %4321 = call float @dx.op.dot3.f32(i32 55, float %4318, float %4319, float %4320, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4322 = fsub fast float %4318, %4321
  %4323 = fsub fast float %4319, %4321
  %4324 = fsub fast float %4320, %4321
  %4325 = fmul fast float %4322, %8
  %4326 = fmul fast float %4323, %8
  %4327 = fmul fast float %4324, %8
  %4328 = fadd fast float %4325, %4321
  %4329 = fadd fast float %4326, %4321
  %4330 = fadd fast float %4327, %4321
  %4331 = call float @dx.op.unary.f32(i32 7, float %4328)  ; Saturate(value)
  %4332 = call float @dx.op.unary.f32(i32 7, float %4329)  ; Saturate(value)
  %4333 = call float @dx.op.unary.f32(i32 7, float %4330)  ; Saturate(value)
  %4334 = fadd fast float %4331, 0xBFC70A3D80000000
  %4335 = fadd fast float %4332, 0xBFC70A3D80000000
  %4336 = fadd fast float %4333, 0xBFC70A3D80000000
  %4337 = fmul fast float %4334, %7
  %4338 = fmul fast float %4335, %7
  %4339 = fmul fast float %4336, %7
  %4340 = fadd fast float %4337, 0x3FC70A3D80000000
  %4341 = fadd fast float %4338, 0x3FC70A3D80000000
  %4342 = fadd fast float %4339, 0x3FC70A3D80000000
  %4343 = call float @dx.op.unary.f32(i32 7, float %4340)  ; Saturate(value)
  %4344 = call float @dx.op.unary.f32(i32 7, float %4341)  ; Saturate(value)
  %4345 = call float @dx.op.unary.f32(i32 7, float %4342)  ; Saturate(value)
  br label %4346

; <label>:4346                                    ; preds = %4314, %4149
  %4347 = phi float [ %4180, %4149 ], [ %4343, %4314 ]
  %4348 = phi float [ %4181, %4149 ], [ %4344, %4314 ]
  %4349 = phi float [ %4182, %4149 ], [ %4345, %4314 ]
  %4350 = add i32 %1225, 1
  %4351 = call i32 @dx.op.binary.i32(i32 37, i32 %4350, i32 0)  ; IMax(a,b)
  %4352 = call i32 @dx.op.binary.i32(i32 38, i32 %4351, i32 %59)  ; IMin(a,b)
  %4353 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4352, i32 %4142, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4354 = extractvalue %dx.types.ResRet.f32 %4353, 0
  %4355 = extractvalue %dx.types.ResRet.f32 %4353, 1
  %4356 = extractvalue %dx.types.ResRet.f32 %4353, 2
  %4357 = extractvalue %dx.types.ResRet.f32 %4353, 3
  %4358 = fcmp fast olt float %4357, 0.000000e+00
  br i1 %4358, label %4359, label %4393

; <label>:4359                                    ; preds = %4346
  %4360 = fcmp fast ogt float %4354, 0x3FA4B5DCC0000000
  %4361 = fcmp fast ogt float %4355, 0x3FA4B5DCC0000000
  %4362 = fcmp fast ogt float %4356, 0x3FA4B5DCC0000000
  %4363 = select i1 %4360, float 0.000000e+00, float 1.000000e+00
  %4364 = select i1 %4361, float 0.000000e+00, float 1.000000e+00
  %4365 = select i1 %4362, float 0.000000e+00, float 1.000000e+00
  %4366 = fmul fast float %4354, 0x3FB3D07220000000
  %4367 = fmul fast float %4355, 0x3FB3D07220000000
  %4368 = fmul fast float %4356, 0x3FB3D07220000000
  %4369 = fadd fast float %4354, 0x3FAC28F5C0000000
  %4370 = fadd fast float %4355, 0x3FAC28F5C0000000
  %4371 = fadd fast float %4356, 0x3FAC28F5C0000000
  %4372 = fmul fast float %4369, 0x3FEE54EDE0000000
  %4373 = fmul fast float %4370, 0x3FEE54EDE0000000
  %4374 = fmul fast float %4371, 0x3FEE54EDE0000000
  %4375 = call float @dx.op.unary.f32(i32 23, float %4372)  ; Log(value)
  %4376 = call float @dx.op.unary.f32(i32 23, float %4373)  ; Log(value)
  %4377 = call float @dx.op.unary.f32(i32 23, float %4374)  ; Log(value)
  %4378 = fmul fast float %4375, 0x4003333340000000
  %4379 = fmul fast float %4376, 0x4003333340000000
  %4380 = fmul fast float %4377, 0x4003333340000000
  %4381 = call float @dx.op.unary.f32(i32 21, float %4378)  ; Exp(value)
  %4382 = call float @dx.op.unary.f32(i32 21, float %4379)  ; Exp(value)
  %4383 = call float @dx.op.unary.f32(i32 21, float %4380)  ; Exp(value)
  %4384 = fsub fast float %4366, %4381
  %4385 = fsub fast float %4367, %4382
  %4386 = fsub fast float %4368, %4383
  %4387 = fmul fast float %4384, %4363
  %4388 = fmul fast float %4385, %4364
  %4389 = fmul fast float %4386, %4365
  %4390 = fadd fast float %4387, %4381
  %4391 = fadd fast float %4388, %4382
  %4392 = fadd fast float %4389, %4383
  br label %4556

; <label>:4393                                    ; preds = %4346
  %4394 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4352, i32 %4142, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4395 = extractvalue %dx.types.ResRet.f32 %4394, 0
  %4396 = fcmp fast ogt float %38, 5.000000e-01
  %4397 = fcmp fast olt float %4395, 1.000000e+00
  %4398 = and i1 %4396, %4397
  br i1 %4398, label %4399, label %4485

; <label>:4399                                    ; preds = %4393
  %4400 = sitofp i32 %4352 to float
  %4401 = sitofp i32 %4142 to float
  %4402 = fadd fast float %4400, 5.000000e-01
  %4403 = fadd fast float %4401, 5.000000e-01
  %4404 = fdiv fast float %4402, %45
  %4405 = fdiv fast float %4403, %46
  %4406 = fmul fast float %4404, 2.000000e+00
  %4407 = fmul fast float %4405, 2.000000e+00
  %4408 = fadd fast float %4406, -1.000000e+00
  %4409 = fsub fast float 1.000000e+00, %4407
  %4410 = fmul fast float %4408, %35
  %4411 = call float @dx.op.tertiary.f32(i32 46, float %4409, float %31, float %4410)  ; FMad(a,b,c)
  %4412 = call float @dx.op.tertiary.f32(i32 46, float %4395, float %27, float %4411)  ; FMad(a,b,c)
  %4413 = fadd fast float %4412, %23
  %4414 = call float @dx.op.unary.f32(i32 6, float %4413)  ; FAbs(value)
  %4415 = fcmp fast ogt float %4414, 0x3EB0C6F7A0000000
  br i1 %4415, label %4416, label %4485

; <label>:4416                                    ; preds = %4399
  %4417 = fmul fast float %4408, %34
  %4418 = call float @dx.op.tertiary.f32(i32 46, float %4409, float %30, float %4417)  ; FMad(a,b,c)
  %4419 = call float @dx.op.tertiary.f32(i32 46, float %4395, float %26, float %4418)  ; FMad(a,b,c)
  %4420 = fadd fast float %4419, %22
  %4421 = fmul fast float %4408, %33
  %4422 = call float @dx.op.tertiary.f32(i32 46, float %4409, float %29, float %4421)  ; FMad(a,b,c)
  %4423 = call float @dx.op.tertiary.f32(i32 46, float %4395, float %25, float %4422)  ; FMad(a,b,c)
  %4424 = fadd fast float %4423, %21
  %4425 = fmul fast float %4408, %32
  %4426 = call float @dx.op.tertiary.f32(i32 46, float %4409, float %28, float %4425)  ; FMad(a,b,c)
  %4427 = call float @dx.op.tertiary.f32(i32 46, float %4395, float %24, float %4426)  ; FMad(a,b,c)
  %4428 = fadd fast float %4427, %20
  %4429 = fdiv fast float %4428, %4413
  %4430 = fdiv fast float %4424, %4413
  %4431 = fdiv fast float %4420, %4413
  %4432 = fsub fast float %4429, %17
  %4433 = fsub fast float %4430, %18
  %4434 = fsub fast float %4431, %19
  %4435 = fmul fast float %4432, %4432
  %4436 = fmul fast float %4433, %4433
  %4437 = fadd fast float %4436, %4435
  %4438 = fmul fast float %4434, %4434
  %4439 = fadd fast float %4437, %4438
  %4440 = call float @dx.op.unary.f32(i32 24, float %4439)  ; Sqrt(value)
  %4441 = fsub fast float %4440, %9
  %4442 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4441)  ; FMax(a,b)
  %4443 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %4443, label %4444, label %4467

; <label>:4444                                    ; preds = %4416
  %4445 = call float @dx.op.unary.f32(i32 6, float %4433)  ; FAbs(value)
  %4446 = fmul fast float %4445, %11
  %4447 = fcmp fast olt float %4446, 0x3F50624DE0000000
  br i1 %4447, label %4448, label %4451

; <label>:4448                                    ; preds = %4444
  %4449 = fmul fast float %4446, 5.000000e-01
  %4450 = fsub fast float 1.000000e+00, %4449
  br label %4456

; <label>:4451                                    ; preds = %4444
  %4452 = fmul fast float %4446, 0xBFF7154760000000
  %4453 = call float @dx.op.unary.f32(i32 21, float %4452)  ; Exp(value)
  %4454 = fsub fast float 1.000000e+00, %4453
  %4455 = fdiv fast float %4454, %4446
  br label %4456

; <label>:4456                                    ; preds = %4451, %4448
  %4457 = phi float [ %4450, %4448 ], [ %4455, %4451 ]
  %4458 = call float @dx.op.binary.f32(i32 36, float %4430, float %18)  ; FMin(a,b)
  %4459 = fsub fast float %4458, %10
  %4460 = fmul fast float %11, %4459
  %4461 = fsub fast float -0.000000e+00, %4460
  %4462 = call float @dx.op.binary.f32(i32 35, float %4461, float -4.000000e+01)  ; FMax(a,b)
  %4463 = call float @dx.op.binary.f32(i32 36, float %4462, float 5.000000e+00)  ; FMin(a,b)
  %4464 = fmul fast float %4463, 0x3FF7154760000000
  %4465 = call float @dx.op.unary.f32(i32 21, float %4464)  ; Exp(value)
  %4466 = fmul fast float %4465, %4457
  br label %4467

; <label>:4467                                    ; preds = %4456, %4416
  %4468 = phi float [ %4466, %4456 ], [ 1.000000e+00, %4416 ]
  %4469 = fmul fast float %4442, %16
  %4470 = fmul fast float %4469, %4468
  %4471 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4470)  ; FMin(a,b)
  %4472 = fmul fast float %4471, 0xBFF7154760000000
  %4473 = call float @dx.op.unary.f32(i32 21, float %4472)  ; Exp(value)
  %4474 = fsub fast float 1.000000e+00, %4473
  %4475 = call float @dx.op.binary.f32(i32 36, float %12, float %4474)  ; FMin(a,b)
  %4476 = fsub fast float %13, %4354
  %4477 = fsub fast float %14, %4355
  %4478 = fsub fast float %15, %4356
  %4479 = fmul fast float %4475, %4476
  %4480 = fmul fast float %4475, %4477
  %4481 = fmul fast float %4475, %4478
  %4482 = fadd fast float %4479, %4354
  %4483 = fadd fast float %4480, %4355
  %4484 = fadd fast float %4481, %4356
  br label %4485

; <label>:4485                                    ; preds = %4467, %4399, %4393
  %4486 = phi float [ %4482, %4467 ], [ %4354, %4399 ], [ %4354, %4393 ]
  %4487 = phi float [ %4483, %4467 ], [ %4355, %4399 ], [ %4355, %4393 ]
  %4488 = phi float [ %4484, %4467 ], [ %4356, %4399 ], [ %4356, %4393 ]
  %4489 = fadd fast float %5, 1.000000e+00
  %4490 = fadd fast float %6, 1.000000e+00
  %4491 = fsub fast float 1.000000e+00, %5
  %4492 = fmul fast float %36, %4489
  %4493 = fmul fast float %36, %4490
  %4494 = fmul fast float %36, %4491
  %4495 = fmul fast float %4492, %4486
  %4496 = fmul fast float %4493, %4487
  %4497 = fmul fast float %4494, %4488
  %4498 = fcmp fast ult float %37, 5.000000e-01
  br i1 %4498, label %4524, label %4499

; <label>:4499                                    ; preds = %4485
  %4500 = fmul fast float %4495, 0x4004147AE0000000
  %4501 = fmul fast float %4496, 0x4004147AE0000000
  %4502 = fmul fast float %4497, 0x4004147AE0000000
  %4503 = fadd fast float %4500, 0x3F9EB851E0000000
  %4504 = fadd fast float %4501, 0x3F9EB851E0000000
  %4505 = fadd fast float %4502, 0x3F9EB851E0000000
  %4506 = fmul fast float %4503, %4495
  %4507 = fmul fast float %4504, %4496
  %4508 = fmul fast float %4505, %4497
  %4509 = fmul fast float %4495, 0x400370A3E0000000
  %4510 = fmul fast float %4496, 0x400370A3E0000000
  %4511 = fmul fast float %4497, 0x400370A3E0000000
  %4512 = fadd fast float %4509, 0x3FE2E147A0000000
  %4513 = fadd fast float %4510, 0x3FE2E147A0000000
  %4514 = fadd fast float %4511, 0x3FE2E147A0000000
  %4515 = fmul fast float %4512, %4495
  %4516 = fmul fast float %4513, %4496
  %4517 = fmul fast float %4514, %4497
  %4518 = fadd fast float %4515, 0x3FC1EB8520000000
  %4519 = fadd fast float %4516, 0x3FC1EB8520000000
  %4520 = fadd fast float %4517, 0x3FC1EB8520000000
  %4521 = fdiv fast float %4506, %4518
  %4522 = fdiv fast float %4507, %4519
  %4523 = fdiv fast float %4508, %4520
  br label %4524

; <label>:4524                                    ; preds = %4499, %4485
  %4525 = phi float [ %4521, %4499 ], [ %4495, %4485 ]
  %4526 = phi float [ %4522, %4499 ], [ %4496, %4485 ]
  %4527 = phi float [ %4523, %4499 ], [ %4497, %4485 ]
  %4528 = call float @dx.op.unary.f32(i32 7, float %4525)  ; Saturate(value)
  %4529 = call float @dx.op.unary.f32(i32 7, float %4526)  ; Saturate(value)
  %4530 = call float @dx.op.unary.f32(i32 7, float %4527)  ; Saturate(value)
  %4531 = call float @dx.op.dot3.f32(i32 55, float %4528, float %4529, float %4530, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4532 = fsub fast float %4528, %4531
  %4533 = fsub fast float %4529, %4531
  %4534 = fsub fast float %4530, %4531
  %4535 = fmul fast float %4532, %8
  %4536 = fmul fast float %4533, %8
  %4537 = fmul fast float %4534, %8
  %4538 = fadd fast float %4535, %4531
  %4539 = fadd fast float %4536, %4531
  %4540 = fadd fast float %4537, %4531
  %4541 = call float @dx.op.unary.f32(i32 7, float %4538)  ; Saturate(value)
  %4542 = call float @dx.op.unary.f32(i32 7, float %4539)  ; Saturate(value)
  %4543 = call float @dx.op.unary.f32(i32 7, float %4540)  ; Saturate(value)
  %4544 = fadd fast float %4541, 0xBFC70A3D80000000
  %4545 = fadd fast float %4542, 0xBFC70A3D80000000
  %4546 = fadd fast float %4543, 0xBFC70A3D80000000
  %4547 = fmul fast float %4544, %7
  %4548 = fmul fast float %4545, %7
  %4549 = fmul fast float %4546, %7
  %4550 = fadd fast float %4547, 0x3FC70A3D80000000
  %4551 = fadd fast float %4548, 0x3FC70A3D80000000
  %4552 = fadd fast float %4549, 0x3FC70A3D80000000
  %4553 = call float @dx.op.unary.f32(i32 7, float %4550)  ; Saturate(value)
  %4554 = call float @dx.op.unary.f32(i32 7, float %4551)  ; Saturate(value)
  %4555 = call float @dx.op.unary.f32(i32 7, float %4552)  ; Saturate(value)
  br label %4556

; <label>:4556                                    ; preds = %4524, %4359
  %4557 = phi float [ %4390, %4359 ], [ %4553, %4524 ]
  %4558 = phi float [ %4391, %4359 ], [ %4554, %4524 ]
  %4559 = phi float [ %4392, %4359 ], [ %4555, %4524 ]
  %4560 = call float @dx.op.binary.f32(i32 36, float %4347, float %4557)  ; FMin(a,b)
  %4561 = call float @dx.op.binary.f32(i32 36, float %4348, float %4558)  ; FMin(a,b)
  %4562 = call float @dx.op.binary.f32(i32 36, float %4349, float %4559)  ; FMin(a,b)
  %4563 = call float @dx.op.binary.f32(i32 36, float %3925, float %4135)  ; FMin(a,b)
  %4564 = call float @dx.op.binary.f32(i32 36, float %3926, float %4136)  ; FMin(a,b)
  %4565 = call float @dx.op.binary.f32(i32 36, float %3927, float %4137)  ; FMin(a,b)
  %4566 = call float @dx.op.binary.f32(i32 36, float %4563, float %4560)  ; FMin(a,b)
  %4567 = call float @dx.op.binary.f32(i32 36, float %4564, float %4561)  ; FMin(a,b)
  %4568 = call float @dx.op.binary.f32(i32 36, float %4565, float %4562)  ; FMin(a,b)
  %4569 = call float @dx.op.binary.f32(i32 36, float %3713, float %4566)  ; FMin(a,b)
  %4570 = call float @dx.op.binary.f32(i32 36, float %3714, float %4567)  ; FMin(a,b)
  %4571 = call float @dx.op.binary.f32(i32 36, float %3715, float %4568)  ; FMin(a,b)
  %4572 = call float @dx.op.binary.f32(i32 35, float %4347, float %4557)  ; FMax(a,b)
  %4573 = call float @dx.op.binary.f32(i32 35, float %4348, float %4558)  ; FMax(a,b)
  %4574 = call float @dx.op.binary.f32(i32 35, float %4349, float %4559)  ; FMax(a,b)
  %4575 = call float @dx.op.binary.f32(i32 35, float %3925, float %4135)  ; FMax(a,b)
  %4576 = call float @dx.op.binary.f32(i32 35, float %3926, float %4136)  ; FMax(a,b)
  %4577 = call float @dx.op.binary.f32(i32 35, float %3927, float %4137)  ; FMax(a,b)
  %4578 = call float @dx.op.binary.f32(i32 35, float %4575, float %4572)  ; FMax(a,b)
  %4579 = call float @dx.op.binary.f32(i32 35, float %4576, float %4573)  ; FMax(a,b)
  %4580 = call float @dx.op.binary.f32(i32 35, float %4577, float %4574)  ; FMax(a,b)
  %4581 = call float @dx.op.binary.f32(i32 35, float %3713, float %4578)  ; FMax(a,b)
  %4582 = call float @dx.op.binary.f32(i32 35, float %3714, float %4579)  ; FMax(a,b)
  %4583 = call float @dx.op.binary.f32(i32 35, float %3715, float %4580)  ; FMax(a,b)
  %4584 = fsub fast float %4581, %4569
  %4585 = fsub fast float %4582, %4570
  %4586 = fsub fast float %4583, %4571
  %4587 = call float @dx.op.unary.f32(i32 6, float %4584)  ; FAbs(value)
  %4588 = call float @dx.op.unary.f32(i32 6, float %4585)  ; FAbs(value)
  %4589 = call float @dx.op.unary.f32(i32 6, float %4586)  ; FAbs(value)
  %4590 = call float @dx.op.binary.f32(i32 35, float %4588, float %4589)  ; FMax(a,b)
  %4591 = call float @dx.op.binary.f32(i32 35, float %4587, float %4590)  ; FMax(a,b)
  %4592 = call float @dx.op.binary.f32(i32 35, float %4582, float %4583)  ; FMax(a,b)
  %4593 = call float @dx.op.binary.f32(i32 35, float %4581, float %4592)  ; FMax(a,b)
  %4594 = fmul fast float %4593, 1.250000e-01
  %4595 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %4594)  ; FMax(a,b)
  %4596 = fcmp fast ogt float %4591, %4595
  br i1 %4596, label %4597, label %4658

; <label>:4597                                    ; preds = %4556
  %4598 = fsub fast float %3925, %4135
  %4599 = fsub fast float %3926, %4136
  %4600 = fsub fast float %3927, %4137
  %4601 = call float @dx.op.unary.f32(i32 6, float %4598)  ; FAbs(value)
  %4602 = call float @dx.op.unary.f32(i32 6, float %4599)  ; FAbs(value)
  %4603 = call float @dx.op.unary.f32(i32 6, float %4600)  ; FAbs(value)
  %4604 = call float @dx.op.binary.f32(i32 35, float %4602, float %4603)  ; FMax(a,b)
  %4605 = call float @dx.op.binary.f32(i32 35, float %4601, float %4604)  ; FMax(a,b)
  %4606 = fsub fast float %4347, %4557
  %4607 = fsub fast float %4348, %4558
  %4608 = fsub fast float %4349, %4559
  %4609 = call float @dx.op.unary.f32(i32 6, float %4606)  ; FAbs(value)
  %4610 = call float @dx.op.unary.f32(i32 6, float %4607)  ; FAbs(value)
  %4611 = call float @dx.op.unary.f32(i32 6, float %4608)  ; FAbs(value)
  %4612 = call float @dx.op.binary.f32(i32 35, float %4610, float %4611)  ; FMax(a,b)
  %4613 = call float @dx.op.binary.f32(i32 35, float %4609, float %4612)  ; FMax(a,b)
  %4614 = fcmp fast olt float %4605, %4613
  %4615 = select i1 %4614, float %3925, float %4347
  %4616 = select i1 %4614, float %3926, float %4348
  %4617 = select i1 %4614, float %3927, float %4349
  %4618 = select i1 %4614, float %4135, float %4557
  %4619 = select i1 %4614, float %4136, float %4558
  %4620 = select i1 %4614, float %4137, float %4559
  %4621 = fsub fast float %3713, %4618
  %4622 = fsub fast float %3714, %4619
  %4623 = fsub fast float %3715, %4620
  %4624 = fsub fast float %3713, %4615
  %4625 = fsub fast float %3714, %4616
  %4626 = fsub fast float %3715, %4617
  %4627 = call float @dx.op.dot3.f32(i32 55, float %4624, float %4625, float %4626, float %4621, float %4622, float %4623)  ; Dot3(ax,ay,az,bx,by,bz)
  %4628 = fcmp fast ogt float %4627, 0.000000e+00
  br i1 %4628, label %4629, label %4641

; <label>:4629                                    ; preds = %4597
  %4630 = fsub fast float %4615, %4618
  %4631 = fsub fast float %4616, %4619
  %4632 = fsub fast float %4617, %4620
  %4633 = call float @dx.op.unary.f32(i32 6, float %4630)  ; FAbs(value)
  %4634 = call float @dx.op.unary.f32(i32 6, float %4631)  ; FAbs(value)
  %4635 = call float @dx.op.unary.f32(i32 6, float %4632)  ; FAbs(value)
  %4636 = call float @dx.op.binary.f32(i32 35, float %4634, float %4635)  ; FMax(a,b)
  %4637 = call float @dx.op.binary.f32(i32 35, float %4633, float %4636)  ; FMax(a,b)
  %4638 = fmul fast float %4591, 2.500000e-01
  %4639 = fcmp fast olt float %4637, %4638
  %4640 = select i1 %4639, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  br label %4641

; <label>:4641                                    ; preds = %4629, %4597
  %4642 = phi float [ 0x3FC99999A0000000, %4597 ], [ %4640, %4629 ]
  %4643 = fadd fast float %4615, %4618
  %4644 = fadd fast float %4616, %4619
  %4645 = fadd fast float %4617, %4620
  %4646 = fmul fast float %4643, 5.000000e-01
  %4647 = fmul fast float %4644, 5.000000e-01
  %4648 = fmul fast float %4645, 5.000000e-01
  %4649 = fsub fast float %4646, %3713
  %4650 = fsub fast float %4647, %3714
  %4651 = fsub fast float %4648, %3715
  %4652 = fmul fast float %4642, %4649
  %4653 = fmul fast float %4642, %4650
  %4654 = fmul fast float %4642, %4651
  %4655 = fadd fast float %4652, %3713
  %4656 = fadd fast float %4653, %3714
  %4657 = fadd fast float %4654, %3715
  br label %4658

; <label>:4658                                    ; preds = %4641, %4556
  %4659 = phi float [ %4655, %4641 ], [ %3713, %4556 ]
  %4660 = phi float [ %4656, %4641 ], [ %3714, %4556 ]
  %4661 = phi float [ %4657, %4641 ], [ %3715, %4556 ]
  %4662 = fcmp fast ogt float %4659, 0x3F69A5C380000000
  %4663 = fcmp fast ogt float %4660, 0x3F69A5C380000000
  %4664 = fcmp fast ogt float %4661, 0x3F69A5C380000000
  %4665 = select i1 %4662, float 0.000000e+00, float 1.000000e+00
  %4666 = select i1 %4663, float 0.000000e+00, float 1.000000e+00
  %4667 = select i1 %4664, float 0.000000e+00, float 1.000000e+00
  %4668 = fmul fast float %4659, 0x4029D70A40000000
  %4669 = fmul fast float %4660, 0x4029D70A40000000
  %4670 = fmul fast float %4661, 0x4029D70A40000000
  %4671 = call float @dx.op.binary.f32(i32 35, float %4659, float 0.000000e+00)  ; FMax(a,b)
  %4672 = call float @dx.op.binary.f32(i32 35, float %4660, float 0.000000e+00)  ; FMax(a,b)
  %4673 = call float @dx.op.binary.f32(i32 35, float %4661, float 0.000000e+00)  ; FMax(a,b)
  %4674 = call float @dx.op.unary.f32(i32 23, float %4671)  ; Log(value)
  %4675 = call float @dx.op.unary.f32(i32 23, float %4672)  ; Log(value)
  %4676 = call float @dx.op.unary.f32(i32 23, float %4673)  ; Log(value)
  %4677 = fmul fast float %4674, 0x3FDAAAAAA0000000
  %4678 = fmul fast float %4675, 0x3FDAAAAAA0000000
  %4679 = fmul fast float %4676, 0x3FDAAAAAA0000000
  %4680 = call float @dx.op.unary.f32(i32 21, float %4677)  ; Exp(value)
  %4681 = call float @dx.op.unary.f32(i32 21, float %4678)  ; Exp(value)
  %4682 = call float @dx.op.unary.f32(i32 21, float %4679)  ; Exp(value)
  %4683 = fmul fast float %4680, 0x3FF0E147A0000000
  %4684 = fmul fast float %4681, 0x3FF0E147A0000000
  %4685 = fmul fast float %4682, 0x3FF0E147A0000000
  %4686 = fadd fast float %4683, 0xBFAC28F5C0000000
  %4687 = fadd fast float %4684, 0xBFAC28F5C0000000
  %4688 = fadd fast float %4685, 0xBFAC28F5C0000000
  %4689 = fsub fast float %4668, %4686
  %4690 = fsub fast float %4669, %4687
  %4691 = fsub fast float %4670, %4688
  %4692 = fmul fast float %4689, %4665
  %4693 = fmul fast float %4690, %4666
  %4694 = fmul fast float %4691, %4667
  %4695 = fadd fast float %4692, %4686
  %4696 = fadd fast float %4693, %4687
  %4697 = fadd fast float %4694, %4688
  br label %4698

; <label>:4698                                    ; preds = %4658, %3551
  %4699 = phi float [ %3546, %3551 ], [ %4695, %4658 ]
  %4700 = phi float [ %3547, %3551 ], [ %4696, %4658 ]
  %4701 = phi float [ %3548, %3551 ], [ %4697, %4658 ]
  %4702 = phi float [ %3552, %3551 ], [ %3549, %4658 ]
  %4703 = call float @dx.op.unary.f32(i32 27, float %49)  ; Round_ni(value)
  %4704 = call float @dx.op.unary.f32(i32 27, float %50)  ; Round_ni(value)
  %4705 = fptosi float %4703 to i32
  %4706 = fptosi float %4704 to i32
  %4707 = call i32 @dx.op.binary.i32(i32 37, i32 %4705, i32 0)  ; IMax(a,b)
  %4708 = call i32 @dx.op.binary.i32(i32 37, i32 %4706, i32 0)  ; IMax(a,b)
  %4709 = call i32 @dx.op.binary.i32(i32 38, i32 %4707, i32 %59)  ; IMin(a,b)
  %4710 = call i32 @dx.op.binary.i32(i32 38, i32 %4708, i32 %60)  ; IMin(a,b)
  %4711 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4709, i32 %4710, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4712 = extractvalue %dx.types.ResRet.f32 %4711, 0
  %4713 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4714 = extractvalue %dx.types.ResRet.f32 %4713, 0
  %4715 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1225, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4716 = extractvalue %dx.types.ResRet.f32 %4715, 0
  %4717 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %2386, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4718 = extractvalue %dx.types.ResRet.f32 %4717, 0
  %4719 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1225, i32 %2386, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4720 = extractvalue %dx.types.ResRet.f32 %4719, 0
  %4721 = fsub fast float 1.000000e+00, %57
  %4722 = fsub fast float 1.000000e+00, %58
  %4723 = fmul fast float %4722, %4721
  %4724 = fmul fast float %4722, %57
  %4725 = fmul fast float %4721, %58
  %4726 = fmul fast float %58, %57
  %4727 = fsub fast float 1.000000e+00, %4712
  %4728 = fmul fast float %4727, 0x3FA99999A0000000
  %4729 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %4728)  ; FMax(a,b)
  %4730 = fsub fast float %4714, %4712
  %4731 = fsub fast float %4716, %4712
  %4732 = fsub fast float %4718, %4712
  %4733 = fsub fast float %4720, %4712
  %4734 = call float @dx.op.unary.f32(i32 6, float %4730)  ; FAbs(value)
  %4735 = call float @dx.op.unary.f32(i32 6, float %4731)  ; FAbs(value)
  %4736 = call float @dx.op.unary.f32(i32 6, float %4732)  ; FAbs(value)
  %4737 = call float @dx.op.unary.f32(i32 6, float %4733)  ; FAbs(value)
  %4738 = fdiv fast float %4734, %4729
  %4739 = fdiv fast float %4735, %4729
  %4740 = fdiv fast float %4736, %4729
  %4741 = fdiv fast float %4737, %4729
  %4742 = fsub fast float 1.000000e+00, %4738
  %4743 = fsub fast float 1.000000e+00, %4739
  %4744 = fsub fast float 1.000000e+00, %4740
  %4745 = fsub fast float 1.000000e+00, %4741
  %4746 = call float @dx.op.unary.f32(i32 7, float %4742)  ; Saturate(value)
  %4747 = call float @dx.op.unary.f32(i32 7, float %4743)  ; Saturate(value)
  %4748 = call float @dx.op.unary.f32(i32 7, float %4744)  ; Saturate(value)
  %4749 = call float @dx.op.unary.f32(i32 7, float %4745)  ; Saturate(value)
  %4750 = fmul fast float %4723, %4746
  %4751 = fmul fast float %4724, %4747
  %4752 = fmul fast float %4725, %4748
  %4753 = fmul fast float %4726, %4749
  %4754 = call float @dx.op.dot4.f32(i32 56, float %4750, float %4751, float %4752, float %4753, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %4755 = call float @dx.op.binary.f32(i32 35, float %4754, float 0x3EE4F8B580000000)  ; FMax(a,b)
  %4756 = fdiv fast float %4750, %4755
  %4757 = fdiv fast float %4751, %4755
  %4758 = fdiv fast float %4752, %4755
  %4759 = fdiv fast float %4753, %4755
  %4760 = fcmp fast ogt float %1219, 0x3FA4B5DCC0000000
  %4761 = fcmp fast ogt float %1220, 0x3FA4B5DCC0000000
  %4762 = fcmp fast ogt float %1221, 0x3FA4B5DCC0000000
  %4763 = select i1 %4760, float 0.000000e+00, float 1.000000e+00
  %4764 = select i1 %4761, float 0.000000e+00, float 1.000000e+00
  %4765 = select i1 %4762, float 0.000000e+00, float 1.000000e+00
  %4766 = fmul fast float %1219, 0x3FB3D07220000000
  %4767 = fmul fast float %1220, 0x3FB3D07220000000
  %4768 = fmul fast float %1221, 0x3FB3D07220000000
  %4769 = fadd fast float %1219, 0x3FAC28F5C0000000
  %4770 = fadd fast float %1220, 0x3FAC28F5C0000000
  %4771 = fadd fast float %1221, 0x3FAC28F5C0000000
  %4772 = fmul fast float %4769, 0x3FEE54EDE0000000
  %4773 = fmul fast float %4770, 0x3FEE54EDE0000000
  %4774 = fmul fast float %4771, 0x3FEE54EDE0000000
  %4775 = call float @dx.op.unary.f32(i32 23, float %4772)  ; Log(value)
  %4776 = call float @dx.op.unary.f32(i32 23, float %4773)  ; Log(value)
  %4777 = call float @dx.op.unary.f32(i32 23, float %4774)  ; Log(value)
  %4778 = fmul fast float %4775, 0x4003333340000000
  %4779 = fmul fast float %4776, 0x4003333340000000
  %4780 = fmul fast float %4777, 0x4003333340000000
  %4781 = call float @dx.op.unary.f32(i32 21, float %4778)  ; Exp(value)
  %4782 = call float @dx.op.unary.f32(i32 21, float %4779)  ; Exp(value)
  %4783 = call float @dx.op.unary.f32(i32 21, float %4780)  ; Exp(value)
  %4784 = fsub fast float %4766, %4781
  %4785 = fsub fast float %4767, %4782
  %4786 = fsub fast float %4768, %4783
  %4787 = fmul fast float %4784, %4763
  %4788 = fmul fast float %4785, %4764
  %4789 = fmul fast float %4786, %4765
  %4790 = fadd fast float %4787, %4781
  %4791 = fadd fast float %4788, %4782
  %4792 = fadd fast float %4789, %4783
  %4793 = fmul fast float %4790, %4756
  %4794 = fmul fast float %4791, %4756
  %4795 = fmul fast float %4792, %4756
  %4796 = fcmp fast ogt float %2380, 0x3FA4B5DCC0000000
  %4797 = fcmp fast ogt float %2381, 0x3FA4B5DCC0000000
  %4798 = fcmp fast ogt float %2382, 0x3FA4B5DCC0000000
  %4799 = select i1 %4796, float 0.000000e+00, float 1.000000e+00
  %4800 = select i1 %4797, float 0.000000e+00, float 1.000000e+00
  %4801 = select i1 %4798, float 0.000000e+00, float 1.000000e+00
  %4802 = fmul fast float %2380, 0x3FB3D07220000000
  %4803 = fmul fast float %2381, 0x3FB3D07220000000
  %4804 = fmul fast float %2382, 0x3FB3D07220000000
  %4805 = fadd fast float %2380, 0x3FAC28F5C0000000
  %4806 = fadd fast float %2381, 0x3FAC28F5C0000000
  %4807 = fadd fast float %2382, 0x3FAC28F5C0000000
  %4808 = fmul fast float %4805, 0x3FEE54EDE0000000
  %4809 = fmul fast float %4806, 0x3FEE54EDE0000000
  %4810 = fmul fast float %4807, 0x3FEE54EDE0000000
  %4811 = call float @dx.op.unary.f32(i32 23, float %4808)  ; Log(value)
  %4812 = call float @dx.op.unary.f32(i32 23, float %4809)  ; Log(value)
  %4813 = call float @dx.op.unary.f32(i32 23, float %4810)  ; Log(value)
  %4814 = fmul fast float %4811, 0x4003333340000000
  %4815 = fmul fast float %4812, 0x4003333340000000
  %4816 = fmul fast float %4813, 0x4003333340000000
  %4817 = call float @dx.op.unary.f32(i32 21, float %4814)  ; Exp(value)
  %4818 = call float @dx.op.unary.f32(i32 21, float %4815)  ; Exp(value)
  %4819 = call float @dx.op.unary.f32(i32 21, float %4816)  ; Exp(value)
  %4820 = fsub fast float %4802, %4817
  %4821 = fsub fast float %4803, %4818
  %4822 = fsub fast float %4804, %4819
  %4823 = fmul fast float %4820, %4799
  %4824 = fmul fast float %4821, %4800
  %4825 = fmul fast float %4822, %4801
  %4826 = fadd fast float %4823, %4817
  %4827 = fadd fast float %4824, %4818
  %4828 = fadd fast float %4825, %4819
  %4829 = fmul fast float %4826, %4757
  %4830 = fmul fast float %4827, %4757
  %4831 = fmul fast float %4828, %4757
  %4832 = fadd fast float %4829, %4793
  %4833 = fadd fast float %4830, %4794
  %4834 = fadd fast float %4831, %4795
  %4835 = fcmp fast ogt float %3541, 0x3FA4B5DCC0000000
  %4836 = fcmp fast ogt float %3542, 0x3FA4B5DCC0000000
  %4837 = fcmp fast ogt float %3543, 0x3FA4B5DCC0000000
  %4838 = select i1 %4835, float 0.000000e+00, float 1.000000e+00
  %4839 = select i1 %4836, float 0.000000e+00, float 1.000000e+00
  %4840 = select i1 %4837, float 0.000000e+00, float 1.000000e+00
  %4841 = fmul fast float %3541, 0x3FB3D07220000000
  %4842 = fmul fast float %3542, 0x3FB3D07220000000
  %4843 = fmul fast float %3543, 0x3FB3D07220000000
  %4844 = fadd fast float %3541, 0x3FAC28F5C0000000
  %4845 = fadd fast float %3542, 0x3FAC28F5C0000000
  %4846 = fadd fast float %3543, 0x3FAC28F5C0000000
  %4847 = fmul fast float %4844, 0x3FEE54EDE0000000
  %4848 = fmul fast float %4845, 0x3FEE54EDE0000000
  %4849 = fmul fast float %4846, 0x3FEE54EDE0000000
  %4850 = call float @dx.op.unary.f32(i32 23, float %4847)  ; Log(value)
  %4851 = call float @dx.op.unary.f32(i32 23, float %4848)  ; Log(value)
  %4852 = call float @dx.op.unary.f32(i32 23, float %4849)  ; Log(value)
  %4853 = fmul fast float %4850, 0x4003333340000000
  %4854 = fmul fast float %4851, 0x4003333340000000
  %4855 = fmul fast float %4852, 0x4003333340000000
  %4856 = call float @dx.op.unary.f32(i32 21, float %4853)  ; Exp(value)
  %4857 = call float @dx.op.unary.f32(i32 21, float %4854)  ; Exp(value)
  %4858 = call float @dx.op.unary.f32(i32 21, float %4855)  ; Exp(value)
  %4859 = fsub fast float %4841, %4856
  %4860 = fsub fast float %4842, %4857
  %4861 = fsub fast float %4843, %4858
  %4862 = fmul fast float %4859, %4838
  %4863 = fmul fast float %4860, %4839
  %4864 = fmul fast float %4861, %4840
  %4865 = fadd fast float %4862, %4856
  %4866 = fadd fast float %4863, %4857
  %4867 = fadd fast float %4864, %4858
  %4868 = fmul fast float %4865, %4758
  %4869 = fmul fast float %4866, %4758
  %4870 = fmul fast float %4867, %4758
  %4871 = fadd fast float %4832, %4868
  %4872 = fadd fast float %4833, %4869
  %4873 = fadd fast float %4834, %4870
  %4874 = fcmp fast ogt float %4699, 0x3FA4B5DCC0000000
  %4875 = fcmp fast ogt float %4700, 0x3FA4B5DCC0000000
  %4876 = fcmp fast ogt float %4701, 0x3FA4B5DCC0000000
  %4877 = select i1 %4874, float 0.000000e+00, float 1.000000e+00
  %4878 = select i1 %4875, float 0.000000e+00, float 1.000000e+00
  %4879 = select i1 %4876, float 0.000000e+00, float 1.000000e+00
  %4880 = fmul fast float %4699, 0x3FB3D07220000000
  %4881 = fmul fast float %4700, 0x3FB3D07220000000
  %4882 = fmul fast float %4701, 0x3FB3D07220000000
  %4883 = fadd fast float %4699, 0x3FAC28F5C0000000
  %4884 = fadd fast float %4700, 0x3FAC28F5C0000000
  %4885 = fadd fast float %4701, 0x3FAC28F5C0000000
  %4886 = fmul fast float %4883, 0x3FEE54EDE0000000
  %4887 = fmul fast float %4884, 0x3FEE54EDE0000000
  %4888 = fmul fast float %4885, 0x3FEE54EDE0000000
  %4889 = call float @dx.op.unary.f32(i32 23, float %4886)  ; Log(value)
  %4890 = call float @dx.op.unary.f32(i32 23, float %4887)  ; Log(value)
  %4891 = call float @dx.op.unary.f32(i32 23, float %4888)  ; Log(value)
  %4892 = fmul fast float %4889, 0x4003333340000000
  %4893 = fmul fast float %4890, 0x4003333340000000
  %4894 = fmul fast float %4891, 0x4003333340000000
  %4895 = call float @dx.op.unary.f32(i32 21, float %4892)  ; Exp(value)
  %4896 = call float @dx.op.unary.f32(i32 21, float %4893)  ; Exp(value)
  %4897 = call float @dx.op.unary.f32(i32 21, float %4894)  ; Exp(value)
  %4898 = fsub fast float %4880, %4895
  %4899 = fsub fast float %4881, %4896
  %4900 = fsub fast float %4882, %4897
  %4901 = fmul fast float %4898, %4877
  %4902 = fmul fast float %4899, %4878
  %4903 = fmul fast float %4900, %4879
  %4904 = fadd fast float %4901, %4895
  %4905 = fadd fast float %4902, %4896
  %4906 = fadd fast float %4903, %4897
  %4907 = fmul fast float %4904, %4759
  %4908 = fmul fast float %4905, %4759
  %4909 = fmul fast float %4906, %4759
  %4910 = fadd fast float %4871, %4907
  %4911 = fadd fast float %4872, %4908
  %4912 = fadd fast float %4873, %4909
  %4913 = fcmp fast ogt float %4910, 0x3F69A5C380000000
  %4914 = fcmp fast ogt float %4911, 0x3F69A5C380000000
  %4915 = fcmp fast ogt float %4912, 0x3F69A5C380000000
  %4916 = select i1 %4913, float 0.000000e+00, float 1.000000e+00
  %4917 = select i1 %4914, float 0.000000e+00, float 1.000000e+00
  %4918 = select i1 %4915, float 0.000000e+00, float 1.000000e+00
  %4919 = fmul fast float %4910, 0x4029D70A40000000
  %4920 = fmul fast float %4911, 0x4029D70A40000000
  %4921 = fmul fast float %4912, 0x4029D70A40000000
  %4922 = call float @dx.op.binary.f32(i32 35, float %4910, float 0.000000e+00)  ; FMax(a,b)
  %4923 = call float @dx.op.binary.f32(i32 35, float %4911, float 0.000000e+00)  ; FMax(a,b)
  %4924 = call float @dx.op.binary.f32(i32 35, float %4912, float 0.000000e+00)  ; FMax(a,b)
  %4925 = call float @dx.op.unary.f32(i32 23, float %4922)  ; Log(value)
  %4926 = call float @dx.op.unary.f32(i32 23, float %4923)  ; Log(value)
  %4927 = call float @dx.op.unary.f32(i32 23, float %4924)  ; Log(value)
  %4928 = fmul fast float %4925, 0x3FDAAAAAA0000000
  %4929 = fmul fast float %4926, 0x3FDAAAAAA0000000
  %4930 = fmul fast float %4927, 0x3FDAAAAAA0000000
  %4931 = call float @dx.op.unary.f32(i32 21, float %4928)  ; Exp(value)
  %4932 = call float @dx.op.unary.f32(i32 21, float %4929)  ; Exp(value)
  %4933 = call float @dx.op.unary.f32(i32 21, float %4930)  ; Exp(value)
  %4934 = fmul fast float %4931, 0x3FF0E147A0000000
  %4935 = fmul fast float %4932, 0x3FF0E147A0000000
  %4936 = fmul fast float %4933, 0x3FF0E147A0000000
  %4937 = fadd fast float %4934, 0xBFAC28F5C0000000
  %4938 = fadd fast float %4935, 0xBFAC28F5C0000000
  %4939 = fadd fast float %4936, 0xBFAC28F5C0000000
  %4940 = fsub fast float %4919, %4937
  %4941 = fsub fast float %4920, %4938
  %4942 = fsub fast float %4921, %4939
  %4943 = fmul fast float %4940, %4916
  %4944 = fmul fast float %4941, %4917
  %4945 = fmul fast float %4942, %4918
  %4946 = fadd fast float %4943, %4937
  %4947 = fadd fast float %4944, %4938
  %4948 = fadd fast float %4945, %4939
  %4949 = call float @dx.op.dot4.f32(i32 56, float %1222, float %2383, float %3544, float %4702, float %4756, float %4757, float %4758, float %4759)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %4946)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %4947)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %4948)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %4949)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %4712)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !38, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, !37}
!36 = !{i32 9}
!37 = !{i32 3, i32 6}
!38 = !{!39, !40}
!39 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
!40 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !41}
!41 = !{i32 3, i32 1}
