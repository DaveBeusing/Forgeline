;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float    yz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: c6ba9747e81c70fbd46efbed2c10c076
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %40 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %41 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %42 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %43 = extractvalue %dx.types.Dimensions %42, 0
  %44 = extractvalue %dx.types.Dimensions %42, 1
  %45 = uitofp i32 %43 to float
  %46 = uitofp i32 %44 to float
  %47 = fmul fast float %45, %40
  %48 = fmul fast float %46, %41
  %49 = fdiv fast float %47, %3
  %50 = fdiv fast float %48, %4
  %51 = fadd fast float %49, -5.000000e-01
  %52 = fadd fast float %50, -5.000000e-01
  %53 = call float @dx.op.unary.f32(i32 27, float %51)  ; Round_ni(value)
  %54 = call float @dx.op.unary.f32(i32 27, float %52)  ; Round_ni(value)
  %55 = fptosi float %53 to i32
  %56 = fptosi float %54 to i32
  %57 = call float @dx.op.unary.f32(i32 22, float %51)  ; Frc(value)
  %58 = call float @dx.op.unary.f32(i32 22, float %52)  ; Frc(value)
  %59 = add i32 %43, -1
  %60 = add i32 %44, -1
  %61 = call i32 @dx.op.binary.i32(i32 37, i32 %55, i32 0)  ; IMax(a,b)
  %62 = call i32 @dx.op.binary.i32(i32 37, i32 %56, i32 0)  ; IMax(a,b)
  %63 = call i32 @dx.op.binary.i32(i32 38, i32 %61, i32 %59)  ; IMin(a,b)
  %64 = call i32 @dx.op.binary.i32(i32 38, i32 %62, i32 %60)  ; IMin(a,b)
  %65 = add i32 %55, 1
  %66 = call i32 @dx.op.binary.i32(i32 37, i32 %65, i32 0)  ; IMax(a,b)
  %67 = call i32 @dx.op.binary.i32(i32 38, i32 %66, i32 %59)  ; IMin(a,b)
  %68 = add i32 %56, 1
  %69 = call i32 @dx.op.binary.i32(i32 37, i32 %68, i32 0)  ; IMax(a,b)
  %70 = call i32 @dx.op.binary.i32(i32 38, i32 %69, i32 %60)  ; IMin(a,b)
  %71 = call float @dx.op.unary.f32(i32 27, float %49)  ; Round_ni(value)
  %72 = call float @dx.op.unary.f32(i32 27, float %50)  ; Round_ni(value)
  %73 = fptosi float %71 to i32
  %74 = fptosi float %72 to i32
  %75 = call i32 @dx.op.binary.i32(i32 37, i32 %73, i32 0)  ; IMax(a,b)
  %76 = call i32 @dx.op.binary.i32(i32 37, i32 %74, i32 0)  ; IMax(a,b)
  %77 = call i32 @dx.op.binary.i32(i32 38, i32 %75, i32 %59)  ; IMin(a,b)
  %78 = call i32 @dx.op.binary.i32(i32 38, i32 %76, i32 %60)  ; IMin(a,b)
  %79 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %77, i32 %78, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %80 = extractvalue %dx.types.ResRet.f32 %79, 0
  %81 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %82 = extractvalue %dx.types.ResRet.f32 %81, 0
  %83 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %67, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %84 = extractvalue %dx.types.ResRet.f32 %83, 0
  %85 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %86 = extractvalue %dx.types.ResRet.f32 %85, 0
  %87 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %67, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %88 = extractvalue %dx.types.ResRet.f32 %87, 0
  %89 = fsub fast float 1.000000e+00, %57
  %90 = fsub fast float 1.000000e+00, %58
  %91 = fmul fast float %90, %89
  %92 = fmul fast float %90, %57
  %93 = fmul fast float %89, %58
  %94 = fmul fast float %58, %57
  %95 = fsub fast float 1.000000e+00, %80
  %96 = fmul fast float %95, 0x3FA99999A0000000
  %97 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %96)  ; FMax(a,b)
  %98 = fsub fast float %82, %80
  %99 = call float @dx.op.unary.f32(i32 6, float %98)  ; FAbs(value)
  %100 = fdiv fast float %99, %97
  %101 = fsub fast float 1.000000e+00, %100
  %102 = call float @dx.op.unary.f32(i32 7, float %101)  ; Saturate(value)
  %103 = fsub fast float %84, %80
  %104 = call float @dx.op.unary.f32(i32 6, float %103)  ; FAbs(value)
  %105 = fdiv fast float %104, %97
  %106 = fsub fast float 1.000000e+00, %105
  %107 = call float @dx.op.unary.f32(i32 7, float %106)  ; Saturate(value)
  %108 = fsub fast float %86, %80
  %109 = call float @dx.op.unary.f32(i32 6, float %108)  ; FAbs(value)
  %110 = fdiv fast float %109, %97
  %111 = fsub fast float 1.000000e+00, %110
  %112 = call float @dx.op.unary.f32(i32 7, float %111)  ; Saturate(value)
  %113 = fsub fast float %88, %80
  %114 = call float @dx.op.unary.f32(i32 6, float %113)  ; FAbs(value)
  %115 = fdiv fast float %114, %97
  %116 = fsub fast float 1.000000e+00, %115
  %117 = call float @dx.op.unary.f32(i32 7, float %116)  ; Saturate(value)
  %118 = fmul fast float %91, %102
  %119 = fmul fast float %92, %107
  %120 = fmul fast float %93, %112
  %121 = fmul fast float %94, %117
  %122 = fcmp fast oge float %57, 5.000000e-01
  %123 = zext i1 %122 to i32
  %124 = fcmp fast oge float %58, 5.000000e-01
  %125 = select i1 %124, i32 2, i32 0
  %126 = or i32 %125, %123
  %127 = call float @dx.op.dot4.f32(i32 56, float %118, float %119, float %120, float %121, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %128 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %118)  ; IsFinite(value)
  %129 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %119)  ; IsFinite(value)
  %130 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %120)  ; IsFinite(value)
  %131 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %121)  ; IsFinite(value)
  %132 = and i1 %128, %129
  %133 = and i1 %132, %130
  %134 = and i1 %133, %131
  br i1 %134, label %135, label %152

; <label>:135                                     ; preds = %0
  %136 = fcmp fast oge float %118, 0.000000e+00
  %137 = fcmp fast oge float %119, 0.000000e+00
  %138 = fcmp fast oge float %120, 0.000000e+00
  %139 = fcmp fast oge float %121, 0.000000e+00
  %140 = and i1 %136, %137
  %141 = and i1 %140, %138
  %142 = and i1 %141, %139
  br i1 %142, label %143, label %152

; <label>:143                                     ; preds = %135
  %144 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %127)  ; IsFinite(value)
  %145 = fcmp fast oge float %127, 0x3810000000000000
  %146 = and i1 %145, %144
  br i1 %146, label %147, label %152

; <label>:147                                     ; preds = %143
  %148 = fdiv fast float %118, %127
  %149 = fdiv fast float %119, %127
  %150 = fdiv fast float %120, %127
  %151 = fdiv fast float %121, %127
  br label %161

; <label>:152                                     ; preds = %143, %135, %0
  %153 = icmp eq i32 %126, 0
  %154 = uitofp i1 %153 to float
  %155 = icmp eq i32 %126, 1
  %156 = uitofp i1 %155 to float
  %157 = icmp eq i32 %126, 2
  %158 = uitofp i1 %157 to float
  %159 = icmp eq i32 %126, 3
  %160 = uitofp i1 %159 to float
  br label %161

; <label>:161                                     ; preds = %152, %147
  %162 = phi float [ %148, %147 ], [ %154, %152 ]
  %163 = phi float [ %149, %147 ], [ %156, %152 ]
  %164 = phi float [ %150, %147 ], [ %158, %152 ]
  %165 = phi float [ %151, %147 ], [ %160, %152 ]
  %166 = or i32 %56, %55
  %167 = icmp sgt i32 %166, -1
  br i1 %167, label %168, label %172

; <label>:168                                     ; preds = %161
  %169 = icmp slt i32 %65, %43
  %170 = icmp slt i32 %68, %44
  %171 = and i1 %169, %170
  br label %172

; <label>:172                                     ; preds = %168, %161
  %173 = phi i1 [ false, %161 ], [ %171, %168 ]
  br i1 %173, label %174, label %1219

; <label>:174                                     ; preds = %172
  %175 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %55, i32 %56, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %176 = extractvalue %dx.types.ResRet.f32 %175, 0
  %177 = extractvalue %dx.types.ResRet.f32 %175, 1
  %178 = extractvalue %dx.types.ResRet.f32 %175, 2
  %179 = extractvalue %dx.types.ResRet.f32 %175, 3
  %180 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %65, i32 %56, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %181 = extractvalue %dx.types.ResRet.f32 %180, 0
  %182 = extractvalue %dx.types.ResRet.f32 %180, 1
  %183 = extractvalue %dx.types.ResRet.f32 %180, 2
  %184 = extractvalue %dx.types.ResRet.f32 %180, 3
  %185 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %55, i32 %68, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %186 = extractvalue %dx.types.ResRet.f32 %185, 0
  %187 = extractvalue %dx.types.ResRet.f32 %185, 1
  %188 = extractvalue %dx.types.ResRet.f32 %185, 2
  %189 = extractvalue %dx.types.ResRet.f32 %185, 3
  %190 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %65, i32 %68, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %191 = extractvalue %dx.types.ResRet.f32 %190, 0
  %192 = extractvalue %dx.types.ResRet.f32 %190, 1
  %193 = extractvalue %dx.types.ResRet.f32 %190, 2
  %194 = extractvalue %dx.types.ResRet.f32 %190, 3
  %195 = fcmp fast olt float %179, 0.000000e+00
  br i1 %195, label %196, label %230

; <label>:196                                     ; preds = %174
  %197 = fcmp fast ogt float %176, 0x3FA4B5DCC0000000
  %198 = fcmp fast ogt float %177, 0x3FA4B5DCC0000000
  %199 = fcmp fast ogt float %178, 0x3FA4B5DCC0000000
  %200 = select i1 %197, float 0.000000e+00, float 1.000000e+00
  %201 = select i1 %198, float 0.000000e+00, float 1.000000e+00
  %202 = select i1 %199, float 0.000000e+00, float 1.000000e+00
  %203 = fmul fast float %176, 0x3FB3D07220000000
  %204 = fmul fast float %177, 0x3FB3D07220000000
  %205 = fmul fast float %178, 0x3FB3D07220000000
  %206 = fadd fast float %176, 0x3FAC28F5C0000000
  %207 = fadd fast float %177, 0x3FAC28F5C0000000
  %208 = fadd fast float %178, 0x3FAC28F5C0000000
  %209 = fmul fast float %206, 0x3FEE54EDE0000000
  %210 = fmul fast float %207, 0x3FEE54EDE0000000
  %211 = fmul fast float %208, 0x3FEE54EDE0000000
  %212 = call float @dx.op.unary.f32(i32 23, float %209)  ; Log(value)
  %213 = call float @dx.op.unary.f32(i32 23, float %210)  ; Log(value)
  %214 = call float @dx.op.unary.f32(i32 23, float %211)  ; Log(value)
  %215 = fmul fast float %212, 0x4003333340000000
  %216 = fmul fast float %213, 0x4003333340000000
  %217 = fmul fast float %214, 0x4003333340000000
  %218 = call float @dx.op.unary.f32(i32 21, float %215)  ; Exp(value)
  %219 = call float @dx.op.unary.f32(i32 21, float %216)  ; Exp(value)
  %220 = call float @dx.op.unary.f32(i32 21, float %217)  ; Exp(value)
  %221 = fsub fast float %203, %218
  %222 = fsub fast float %204, %219
  %223 = fsub fast float %205, %220
  %224 = fmul fast float %221, %200
  %225 = fmul fast float %222, %201
  %226 = fmul fast float %223, %202
  %227 = fadd fast float %224, %218
  %228 = fadd fast float %225, %219
  %229 = fadd fast float %226, %220
  br label %445

; <label>:230                                     ; preds = %174
  %231 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %55, i32 %56, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %232 = extractvalue %dx.types.ResRet.f32 %231, 0
  %233 = fcmp fast ogt float %38, 5.000000e-01
  %234 = fcmp fast olt float %232, 1.000000e+00
  %235 = and i1 %233, %234
  br i1 %235, label %236, label %374

; <label>:236                                     ; preds = %230
  %237 = sitofp i32 %55 to float
  %238 = sitofp i32 %56 to float
  %239 = fadd fast float %237, 5.000000e-01
  %240 = fadd fast float %238, 5.000000e-01
  %241 = fdiv fast float %239, %45
  %242 = fdiv fast float %240, %46
  %243 = fmul fast float %241, 2.000000e+00
  %244 = fmul fast float %242, 2.000000e+00
  %245 = fadd fast float %243, -1.000000e+00
  %246 = fsub fast float 1.000000e+00, %244
  %247 = fmul fast float %245, %35
  %248 = call float @dx.op.tertiary.f32(i32 46, float %246, float %31, float %247)  ; FMad(a,b,c)
  %249 = call float @dx.op.tertiary.f32(i32 46, float %232, float %27, float %248)  ; FMad(a,b,c)
  %250 = fadd fast float %249, %23
  %251 = call float @dx.op.unary.f32(i32 6, float %250)  ; FAbs(value)
  %252 = fcmp fast ogt float %251, 0x3EB0C6F7A0000000
  br i1 %252, label %253, label %374

; <label>:253                                     ; preds = %236
  %254 = fmul fast float %245, %34
  %255 = call float @dx.op.tertiary.f32(i32 46, float %246, float %30, float %254)  ; FMad(a,b,c)
  %256 = call float @dx.op.tertiary.f32(i32 46, float %232, float %26, float %255)  ; FMad(a,b,c)
  %257 = fadd fast float %256, %22
  %258 = fmul fast float %245, %33
  %259 = call float @dx.op.tertiary.f32(i32 46, float %246, float %29, float %258)  ; FMad(a,b,c)
  %260 = call float @dx.op.tertiary.f32(i32 46, float %232, float %25, float %259)  ; FMad(a,b,c)
  %261 = fadd fast float %260, %21
  %262 = fmul fast float %245, %32
  %263 = call float @dx.op.tertiary.f32(i32 46, float %246, float %28, float %262)  ; FMad(a,b,c)
  %264 = call float @dx.op.tertiary.f32(i32 46, float %232, float %24, float %263)  ; FMad(a,b,c)
  %265 = fadd fast float %264, %20
  %266 = fdiv fast float %265, %250
  %267 = fdiv fast float %261, %250
  %268 = fdiv fast float %257, %250
  %269 = fsub fast float %266, %17
  %270 = fsub fast float %267, %18
  %271 = fsub fast float %268, %19
  %272 = fmul fast float %269, %269
  %273 = fmul fast float %270, %270
  %274 = fadd fast float %273, %272
  %275 = fmul fast float %271, %271
  %276 = fadd fast float %274, %275
  %277 = call float @dx.op.unary.f32(i32 24, float %276)  ; Sqrt(value)
  %278 = fsub fast float %277, %9
  %279 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %278)  ; FMax(a,b)
  %280 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %280, label %281, label %304

; <label>:281                                     ; preds = %253
  %282 = call float @dx.op.unary.f32(i32 6, float %270)  ; FAbs(value)
  %283 = fmul fast float %282, %11
  %284 = fcmp fast olt float %283, 0x3F50624DE0000000
  br i1 %284, label %285, label %288

; <label>:285                                     ; preds = %281
  %286 = fmul fast float %283, 5.000000e-01
  %287 = fsub fast float 1.000000e+00, %286
  br label %293

; <label>:288                                     ; preds = %281
  %289 = fmul fast float %283, 0xBFF7154760000000
  %290 = call float @dx.op.unary.f32(i32 21, float %289)  ; Exp(value)
  %291 = fsub fast float 1.000000e+00, %290
  %292 = fdiv fast float %291, %283
  br label %293

; <label>:293                                     ; preds = %288, %285
  %294 = phi float [ %287, %285 ], [ %292, %288 ]
  %295 = call float @dx.op.binary.f32(i32 36, float %267, float %18)  ; FMin(a,b)
  %296 = fsub fast float %295, %10
  %297 = fmul fast float %11, %296
  %298 = fsub fast float -0.000000e+00, %297
  %299 = call float @dx.op.binary.f32(i32 35, float %298, float -4.000000e+01)  ; FMax(a,b)
  %300 = call float @dx.op.binary.f32(i32 36, float %299, float 5.000000e+00)  ; FMin(a,b)
  %301 = fmul fast float %300, 0x3FF7154760000000
  %302 = call float @dx.op.unary.f32(i32 21, float %301)  ; Exp(value)
  %303 = fmul fast float %302, %294
  br label %304

; <label>:304                                     ; preds = %293, %253
  %305 = phi float [ %303, %293 ], [ 1.000000e+00, %253 ]
  %306 = fmul fast float %279, %16
  %307 = fmul fast float %306, %305
  %308 = fcmp fast ole float %277, %9
  %309 = fcmp fast olt float %277, 0x3F1A36E2E0000000
  %310 = or i1 %308, %309
  br i1 %310, label %357, label %311

; <label>:311                                     ; preds = %304
  %312 = fdiv fast float %9, %277
  %313 = fmul fast float %312, %269
  %314 = fmul fast float %312, %270
  %315 = fmul fast float %312, %271
  %316 = fadd fast float %313, %17
  %317 = fadd fast float %314, %18
  %318 = fadd fast float %315, %19
  %319 = fadd fast float %316, -9.000000e+02
  %320 = fadd fast float %317, -1.500000e+01
  %321 = fadd fast float %318, -7.500000e+02
  %322 = fmul fast float %319, 0x3F62345680000000
  %323 = fmul fast float %320, 0x3F62345680000000
  %324 = fmul fast float %321, 0x3F62345680000000
  %325 = call float @dx.op.dot3.f32(i32 55, float %322, float %323, float %324, float %322, float %323, float %324)  ; Dot3(ax,ay,az,bx,by,bz)
  %326 = fsub fast float 1.000000e+00, %325
  %327 = call float @dx.op.unary.f32(i32 7, float %326)  ; Saturate(value)
  %328 = fmul fast float %327, %327
  %329 = fadd fast float %316, %266
  %330 = fadd fast float %317, %267
  %331 = fadd fast float %318, %268
  %332 = fmul fast float %329, 0x3F52345680000000
  %333 = fadd fast float %332, -2.000000e+00
  %334 = fmul fast float %330, 0x3F52345680000000
  %335 = fadd fast float %334, 0xBFA1111120000000
  %336 = fmul fast float %331, 0x3F52345680000000
  %337 = fadd fast float %336, 0xBFFAAAAAC0000000
  %338 = call float @dx.op.dot3.f32(i32 55, float %333, float %335, float %337, float %333, float %335, float %337)  ; Dot3(ax,ay,az,bx,by,bz)
  %339 = fsub fast float 1.000000e+00, %338
  %340 = call float @dx.op.unary.f32(i32 7, float %339)  ; Saturate(value)
  %341 = fmul fast float %340, %340
  %342 = fmul fast float %341, 4.000000e+00
  %343 = fadd fast float %342, %328
  %344 = fadd fast float %266, -9.000000e+02
  %345 = fadd fast float %267, -1.500000e+01
  %346 = fadd fast float %268, -7.500000e+02
  %347 = fmul fast float %344, 0x3F62345680000000
  %348 = fmul fast float %345, 0x3F62345680000000
  %349 = fmul fast float %346, 0x3F62345680000000
  %350 = call float @dx.op.dot3.f32(i32 55, float %347, float %348, float %349, float %347, float %348, float %349)  ; Dot3(ax,ay,az,bx,by,bz)
  %351 = fsub fast float 1.000000e+00, %350
  %352 = call float @dx.op.unary.f32(i32 7, float %351)  ; Saturate(value)
  %353 = fmul fast float %352, %352
  %354 = fadd fast float %343, %353
  %355 = fmul fast float %278, 0x3F25D867E0000000
  %356 = fmul fast float %355, %354
  br label %357

; <label>:357                                     ; preds = %311, %304
  %358 = phi float [ %356, %311 ], [ 0.000000e+00, %304 ]
  %359 = fadd fast float %358, %307
  %360 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %359)  ; FMin(a,b)
  %361 = fmul fast float %360, 0xBFF7154760000000
  %362 = call float @dx.op.unary.f32(i32 21, float %361)  ; Exp(value)
  %363 = fsub fast float 1.000000e+00, %362
  %364 = call float @dx.op.binary.f32(i32 36, float %12, float %363)  ; FMin(a,b)
  %365 = fsub fast float %13, %176
  %366 = fsub fast float %14, %177
  %367 = fsub fast float %15, %178
  %368 = fmul fast float %364, %365
  %369 = fmul fast float %364, %366
  %370 = fmul fast float %364, %367
  %371 = fadd fast float %368, %176
  %372 = fadd fast float %369, %177
  %373 = fadd fast float %370, %178
  br label %374

; <label>:374                                     ; preds = %357, %236, %230
  %375 = phi float [ %371, %357 ], [ %176, %236 ], [ %176, %230 ]
  %376 = phi float [ %372, %357 ], [ %177, %236 ], [ %177, %230 ]
  %377 = phi float [ %373, %357 ], [ %178, %236 ], [ %178, %230 ]
  %378 = fadd fast float %5, 1.000000e+00
  %379 = fadd fast float %6, 1.000000e+00
  %380 = fsub fast float 1.000000e+00, %5
  %381 = fmul fast float %36, %378
  %382 = fmul fast float %36, %379
  %383 = fmul fast float %36, %380
  %384 = fmul fast float %381, %375
  %385 = fmul fast float %382, %376
  %386 = fmul fast float %383, %377
  %387 = fcmp fast ult float %37, 5.000000e-01
  br i1 %387, label %413, label %388

; <label>:388                                     ; preds = %374
  %389 = fmul fast float %384, 0x4004147AE0000000
  %390 = fmul fast float %385, 0x4004147AE0000000
  %391 = fmul fast float %386, 0x4004147AE0000000
  %392 = fadd fast float %389, 0x3F9EB851E0000000
  %393 = fadd fast float %390, 0x3F9EB851E0000000
  %394 = fadd fast float %391, 0x3F9EB851E0000000
  %395 = fmul fast float %392, %384
  %396 = fmul fast float %393, %385
  %397 = fmul fast float %394, %386
  %398 = fmul fast float %384, 0x400370A3E0000000
  %399 = fmul fast float %385, 0x400370A3E0000000
  %400 = fmul fast float %386, 0x400370A3E0000000
  %401 = fadd fast float %398, 0x3FE2E147A0000000
  %402 = fadd fast float %399, 0x3FE2E147A0000000
  %403 = fadd fast float %400, 0x3FE2E147A0000000
  %404 = fmul fast float %401, %384
  %405 = fmul fast float %402, %385
  %406 = fmul fast float %403, %386
  %407 = fadd fast float %404, 0x3FC1EB8520000000
  %408 = fadd fast float %405, 0x3FC1EB8520000000
  %409 = fadd fast float %406, 0x3FC1EB8520000000
  %410 = fdiv fast float %395, %407
  %411 = fdiv fast float %396, %408
  %412 = fdiv fast float %397, %409
  br label %413

; <label>:413                                     ; preds = %388, %374
  %414 = phi float [ %410, %388 ], [ %384, %374 ]
  %415 = phi float [ %411, %388 ], [ %385, %374 ]
  %416 = phi float [ %412, %388 ], [ %386, %374 ]
  %417 = call float @dx.op.unary.f32(i32 7, float %414)  ; Saturate(value)
  %418 = call float @dx.op.unary.f32(i32 7, float %415)  ; Saturate(value)
  %419 = call float @dx.op.unary.f32(i32 7, float %416)  ; Saturate(value)
  %420 = call float @dx.op.dot3.f32(i32 55, float %417, float %418, float %419, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %421 = fsub fast float %417, %420
  %422 = fsub fast float %418, %420
  %423 = fsub fast float %419, %420
  %424 = fmul fast float %421, %8
  %425 = fmul fast float %422, %8
  %426 = fmul fast float %423, %8
  %427 = fadd fast float %424, %420
  %428 = fadd fast float %425, %420
  %429 = fadd fast float %426, %420
  %430 = call float @dx.op.unary.f32(i32 7, float %427)  ; Saturate(value)
  %431 = call float @dx.op.unary.f32(i32 7, float %428)  ; Saturate(value)
  %432 = call float @dx.op.unary.f32(i32 7, float %429)  ; Saturate(value)
  %433 = fadd fast float %430, 0xBFC70A3D80000000
  %434 = fadd fast float %431, 0xBFC70A3D80000000
  %435 = fadd fast float %432, 0xBFC70A3D80000000
  %436 = fmul fast float %433, %7
  %437 = fmul fast float %434, %7
  %438 = fmul fast float %435, %7
  %439 = fadd fast float %436, 0x3FC70A3D80000000
  %440 = fadd fast float %437, 0x3FC70A3D80000000
  %441 = fadd fast float %438, 0x3FC70A3D80000000
  %442 = call float @dx.op.unary.f32(i32 7, float %439)  ; Saturate(value)
  %443 = call float @dx.op.unary.f32(i32 7, float %440)  ; Saturate(value)
  %444 = call float @dx.op.unary.f32(i32 7, float %441)  ; Saturate(value)
  br label %445

; <label>:445                                     ; preds = %413, %196
  %446 = phi float [ %227, %196 ], [ %442, %413 ]
  %447 = phi float [ %228, %196 ], [ %443, %413 ]
  %448 = phi float [ %229, %196 ], [ %444, %413 ]
  %449 = fcmp fast olt float %184, 0.000000e+00
  br i1 %449, label %450, label %484

; <label>:450                                     ; preds = %445
  %451 = fcmp fast ogt float %181, 0x3FA4B5DCC0000000
  %452 = fcmp fast ogt float %182, 0x3FA4B5DCC0000000
  %453 = fcmp fast ogt float %183, 0x3FA4B5DCC0000000
  %454 = select i1 %451, float 0.000000e+00, float 1.000000e+00
  %455 = select i1 %452, float 0.000000e+00, float 1.000000e+00
  %456 = select i1 %453, float 0.000000e+00, float 1.000000e+00
  %457 = fmul fast float %181, 0x3FB3D07220000000
  %458 = fmul fast float %182, 0x3FB3D07220000000
  %459 = fmul fast float %183, 0x3FB3D07220000000
  %460 = fadd fast float %181, 0x3FAC28F5C0000000
  %461 = fadd fast float %182, 0x3FAC28F5C0000000
  %462 = fadd fast float %183, 0x3FAC28F5C0000000
  %463 = fmul fast float %460, 0x3FEE54EDE0000000
  %464 = fmul fast float %461, 0x3FEE54EDE0000000
  %465 = fmul fast float %462, 0x3FEE54EDE0000000
  %466 = call float @dx.op.unary.f32(i32 23, float %463)  ; Log(value)
  %467 = call float @dx.op.unary.f32(i32 23, float %464)  ; Log(value)
  %468 = call float @dx.op.unary.f32(i32 23, float %465)  ; Log(value)
  %469 = fmul fast float %466, 0x4003333340000000
  %470 = fmul fast float %467, 0x4003333340000000
  %471 = fmul fast float %468, 0x4003333340000000
  %472 = call float @dx.op.unary.f32(i32 21, float %469)  ; Exp(value)
  %473 = call float @dx.op.unary.f32(i32 21, float %470)  ; Exp(value)
  %474 = call float @dx.op.unary.f32(i32 21, float %471)  ; Exp(value)
  %475 = fsub fast float %457, %472
  %476 = fsub fast float %458, %473
  %477 = fsub fast float %459, %474
  %478 = fmul fast float %475, %454
  %479 = fmul fast float %476, %455
  %480 = fmul fast float %477, %456
  %481 = fadd fast float %478, %472
  %482 = fadd fast float %479, %473
  %483 = fadd fast float %480, %474
  br label %699

; <label>:484                                     ; preds = %445
  %485 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %65, i32 %56, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %486 = extractvalue %dx.types.ResRet.f32 %485, 0
  %487 = fcmp fast ogt float %38, 5.000000e-01
  %488 = fcmp fast olt float %486, 1.000000e+00
  %489 = and i1 %487, %488
  br i1 %489, label %490, label %628

; <label>:490                                     ; preds = %484
  %491 = sitofp i32 %65 to float
  %492 = sitofp i32 %56 to float
  %493 = fadd fast float %491, 5.000000e-01
  %494 = fadd fast float %492, 5.000000e-01
  %495 = fdiv fast float %493, %45
  %496 = fdiv fast float %494, %46
  %497 = fmul fast float %495, 2.000000e+00
  %498 = fmul fast float %496, 2.000000e+00
  %499 = fadd fast float %497, -1.000000e+00
  %500 = fsub fast float 1.000000e+00, %498
  %501 = fmul fast float %499, %35
  %502 = call float @dx.op.tertiary.f32(i32 46, float %500, float %31, float %501)  ; FMad(a,b,c)
  %503 = call float @dx.op.tertiary.f32(i32 46, float %486, float %27, float %502)  ; FMad(a,b,c)
  %504 = fadd fast float %503, %23
  %505 = call float @dx.op.unary.f32(i32 6, float %504)  ; FAbs(value)
  %506 = fcmp fast ogt float %505, 0x3EB0C6F7A0000000
  br i1 %506, label %507, label %628

; <label>:507                                     ; preds = %490
  %508 = fmul fast float %499, %34
  %509 = call float @dx.op.tertiary.f32(i32 46, float %500, float %30, float %508)  ; FMad(a,b,c)
  %510 = call float @dx.op.tertiary.f32(i32 46, float %486, float %26, float %509)  ; FMad(a,b,c)
  %511 = fadd fast float %510, %22
  %512 = fmul fast float %499, %33
  %513 = call float @dx.op.tertiary.f32(i32 46, float %500, float %29, float %512)  ; FMad(a,b,c)
  %514 = call float @dx.op.tertiary.f32(i32 46, float %486, float %25, float %513)  ; FMad(a,b,c)
  %515 = fadd fast float %514, %21
  %516 = fmul fast float %499, %32
  %517 = call float @dx.op.tertiary.f32(i32 46, float %500, float %28, float %516)  ; FMad(a,b,c)
  %518 = call float @dx.op.tertiary.f32(i32 46, float %486, float %24, float %517)  ; FMad(a,b,c)
  %519 = fadd fast float %518, %20
  %520 = fdiv fast float %519, %504
  %521 = fdiv fast float %515, %504
  %522 = fdiv fast float %511, %504
  %523 = fsub fast float %520, %17
  %524 = fsub fast float %521, %18
  %525 = fsub fast float %522, %19
  %526 = fmul fast float %523, %523
  %527 = fmul fast float %524, %524
  %528 = fadd fast float %527, %526
  %529 = fmul fast float %525, %525
  %530 = fadd fast float %528, %529
  %531 = call float @dx.op.unary.f32(i32 24, float %530)  ; Sqrt(value)
  %532 = fsub fast float %531, %9
  %533 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %532)  ; FMax(a,b)
  %534 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %534, label %535, label %558

; <label>:535                                     ; preds = %507
  %536 = call float @dx.op.unary.f32(i32 6, float %524)  ; FAbs(value)
  %537 = fmul fast float %536, %11
  %538 = fcmp fast olt float %537, 0x3F50624DE0000000
  br i1 %538, label %539, label %542

; <label>:539                                     ; preds = %535
  %540 = fmul fast float %537, 5.000000e-01
  %541 = fsub fast float 1.000000e+00, %540
  br label %547

; <label>:542                                     ; preds = %535
  %543 = fmul fast float %537, 0xBFF7154760000000
  %544 = call float @dx.op.unary.f32(i32 21, float %543)  ; Exp(value)
  %545 = fsub fast float 1.000000e+00, %544
  %546 = fdiv fast float %545, %537
  br label %547

; <label>:547                                     ; preds = %542, %539
  %548 = phi float [ %541, %539 ], [ %546, %542 ]
  %549 = call float @dx.op.binary.f32(i32 36, float %521, float %18)  ; FMin(a,b)
  %550 = fsub fast float %549, %10
  %551 = fmul fast float %11, %550
  %552 = fsub fast float -0.000000e+00, %551
  %553 = call float @dx.op.binary.f32(i32 35, float %552, float -4.000000e+01)  ; FMax(a,b)
  %554 = call float @dx.op.binary.f32(i32 36, float %553, float 5.000000e+00)  ; FMin(a,b)
  %555 = fmul fast float %554, 0x3FF7154760000000
  %556 = call float @dx.op.unary.f32(i32 21, float %555)  ; Exp(value)
  %557 = fmul fast float %556, %548
  br label %558

; <label>:558                                     ; preds = %547, %507
  %559 = phi float [ %557, %547 ], [ 1.000000e+00, %507 ]
  %560 = fmul fast float %533, %16
  %561 = fmul fast float %560, %559
  %562 = fcmp fast ole float %531, %9
  %563 = fcmp fast olt float %531, 0x3F1A36E2E0000000
  %564 = or i1 %562, %563
  br i1 %564, label %611, label %565

; <label>:565                                     ; preds = %558
  %566 = fdiv fast float %9, %531
  %567 = fmul fast float %566, %523
  %568 = fmul fast float %566, %524
  %569 = fmul fast float %566, %525
  %570 = fadd fast float %567, %17
  %571 = fadd fast float %568, %18
  %572 = fadd fast float %569, %19
  %573 = fadd fast float %570, -9.000000e+02
  %574 = fadd fast float %571, -1.500000e+01
  %575 = fadd fast float %572, -7.500000e+02
  %576 = fmul fast float %573, 0x3F62345680000000
  %577 = fmul fast float %574, 0x3F62345680000000
  %578 = fmul fast float %575, 0x3F62345680000000
  %579 = call float @dx.op.dot3.f32(i32 55, float %576, float %577, float %578, float %576, float %577, float %578)  ; Dot3(ax,ay,az,bx,by,bz)
  %580 = fsub fast float 1.000000e+00, %579
  %581 = call float @dx.op.unary.f32(i32 7, float %580)  ; Saturate(value)
  %582 = fmul fast float %581, %581
  %583 = fadd fast float %570, %520
  %584 = fadd fast float %571, %521
  %585 = fadd fast float %572, %522
  %586 = fmul fast float %583, 0x3F52345680000000
  %587 = fadd fast float %586, -2.000000e+00
  %588 = fmul fast float %584, 0x3F52345680000000
  %589 = fadd fast float %588, 0xBFA1111120000000
  %590 = fmul fast float %585, 0x3F52345680000000
  %591 = fadd fast float %590, 0xBFFAAAAAC0000000
  %592 = call float @dx.op.dot3.f32(i32 55, float %587, float %589, float %591, float %587, float %589, float %591)  ; Dot3(ax,ay,az,bx,by,bz)
  %593 = fsub fast float 1.000000e+00, %592
  %594 = call float @dx.op.unary.f32(i32 7, float %593)  ; Saturate(value)
  %595 = fmul fast float %594, %594
  %596 = fmul fast float %595, 4.000000e+00
  %597 = fadd fast float %596, %582
  %598 = fadd fast float %520, -9.000000e+02
  %599 = fadd fast float %521, -1.500000e+01
  %600 = fadd fast float %522, -7.500000e+02
  %601 = fmul fast float %598, 0x3F62345680000000
  %602 = fmul fast float %599, 0x3F62345680000000
  %603 = fmul fast float %600, 0x3F62345680000000
  %604 = call float @dx.op.dot3.f32(i32 55, float %601, float %602, float %603, float %601, float %602, float %603)  ; Dot3(ax,ay,az,bx,by,bz)
  %605 = fsub fast float 1.000000e+00, %604
  %606 = call float @dx.op.unary.f32(i32 7, float %605)  ; Saturate(value)
  %607 = fmul fast float %606, %606
  %608 = fadd fast float %597, %607
  %609 = fmul fast float %532, 0x3F25D867E0000000
  %610 = fmul fast float %609, %608
  br label %611

; <label>:611                                     ; preds = %565, %558
  %612 = phi float [ %610, %565 ], [ 0.000000e+00, %558 ]
  %613 = fadd fast float %612, %561
  %614 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %613)  ; FMin(a,b)
  %615 = fmul fast float %614, 0xBFF7154760000000
  %616 = call float @dx.op.unary.f32(i32 21, float %615)  ; Exp(value)
  %617 = fsub fast float 1.000000e+00, %616
  %618 = call float @dx.op.binary.f32(i32 36, float %12, float %617)  ; FMin(a,b)
  %619 = fsub fast float %13, %181
  %620 = fsub fast float %14, %182
  %621 = fsub fast float %15, %183
  %622 = fmul fast float %618, %619
  %623 = fmul fast float %618, %620
  %624 = fmul fast float %618, %621
  %625 = fadd fast float %622, %181
  %626 = fadd fast float %623, %182
  %627 = fadd fast float %624, %183
  br label %628

; <label>:628                                     ; preds = %611, %490, %484
  %629 = phi float [ %625, %611 ], [ %181, %490 ], [ %181, %484 ]
  %630 = phi float [ %626, %611 ], [ %182, %490 ], [ %182, %484 ]
  %631 = phi float [ %627, %611 ], [ %183, %490 ], [ %183, %484 ]
  %632 = fadd fast float %5, 1.000000e+00
  %633 = fadd fast float %6, 1.000000e+00
  %634 = fsub fast float 1.000000e+00, %5
  %635 = fmul fast float %36, %632
  %636 = fmul fast float %36, %633
  %637 = fmul fast float %36, %634
  %638 = fmul fast float %635, %629
  %639 = fmul fast float %636, %630
  %640 = fmul fast float %637, %631
  %641 = fcmp fast ult float %37, 5.000000e-01
  br i1 %641, label %667, label %642

; <label>:642                                     ; preds = %628
  %643 = fmul fast float %638, 0x4004147AE0000000
  %644 = fmul fast float %639, 0x4004147AE0000000
  %645 = fmul fast float %640, 0x4004147AE0000000
  %646 = fadd fast float %643, 0x3F9EB851E0000000
  %647 = fadd fast float %644, 0x3F9EB851E0000000
  %648 = fadd fast float %645, 0x3F9EB851E0000000
  %649 = fmul fast float %646, %638
  %650 = fmul fast float %647, %639
  %651 = fmul fast float %648, %640
  %652 = fmul fast float %638, 0x400370A3E0000000
  %653 = fmul fast float %639, 0x400370A3E0000000
  %654 = fmul fast float %640, 0x400370A3E0000000
  %655 = fadd fast float %652, 0x3FE2E147A0000000
  %656 = fadd fast float %653, 0x3FE2E147A0000000
  %657 = fadd fast float %654, 0x3FE2E147A0000000
  %658 = fmul fast float %655, %638
  %659 = fmul fast float %656, %639
  %660 = fmul fast float %657, %640
  %661 = fadd fast float %658, 0x3FC1EB8520000000
  %662 = fadd fast float %659, 0x3FC1EB8520000000
  %663 = fadd fast float %660, 0x3FC1EB8520000000
  %664 = fdiv fast float %649, %661
  %665 = fdiv fast float %650, %662
  %666 = fdiv fast float %651, %663
  br label %667

; <label>:667                                     ; preds = %642, %628
  %668 = phi float [ %664, %642 ], [ %638, %628 ]
  %669 = phi float [ %665, %642 ], [ %639, %628 ]
  %670 = phi float [ %666, %642 ], [ %640, %628 ]
  %671 = call float @dx.op.unary.f32(i32 7, float %668)  ; Saturate(value)
  %672 = call float @dx.op.unary.f32(i32 7, float %669)  ; Saturate(value)
  %673 = call float @dx.op.unary.f32(i32 7, float %670)  ; Saturate(value)
  %674 = call float @dx.op.dot3.f32(i32 55, float %671, float %672, float %673, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %675 = fsub fast float %671, %674
  %676 = fsub fast float %672, %674
  %677 = fsub fast float %673, %674
  %678 = fmul fast float %675, %8
  %679 = fmul fast float %676, %8
  %680 = fmul fast float %677, %8
  %681 = fadd fast float %678, %674
  %682 = fadd fast float %679, %674
  %683 = fadd fast float %680, %674
  %684 = call float @dx.op.unary.f32(i32 7, float %681)  ; Saturate(value)
  %685 = call float @dx.op.unary.f32(i32 7, float %682)  ; Saturate(value)
  %686 = call float @dx.op.unary.f32(i32 7, float %683)  ; Saturate(value)
  %687 = fadd fast float %684, 0xBFC70A3D80000000
  %688 = fadd fast float %685, 0xBFC70A3D80000000
  %689 = fadd fast float %686, 0xBFC70A3D80000000
  %690 = fmul fast float %687, %7
  %691 = fmul fast float %688, %7
  %692 = fmul fast float %689, %7
  %693 = fadd fast float %690, 0x3FC70A3D80000000
  %694 = fadd fast float %691, 0x3FC70A3D80000000
  %695 = fadd fast float %692, 0x3FC70A3D80000000
  %696 = call float @dx.op.unary.f32(i32 7, float %693)  ; Saturate(value)
  %697 = call float @dx.op.unary.f32(i32 7, float %694)  ; Saturate(value)
  %698 = call float @dx.op.unary.f32(i32 7, float %695)  ; Saturate(value)
  br label %699

; <label>:699                                     ; preds = %667, %450
  %700 = phi float [ %481, %450 ], [ %696, %667 ]
  %701 = phi float [ %482, %450 ], [ %697, %667 ]
  %702 = phi float [ %483, %450 ], [ %698, %667 ]
  %703 = fcmp fast olt float %189, 0.000000e+00
  br i1 %703, label %704, label %738

; <label>:704                                     ; preds = %699
  %705 = fcmp fast ogt float %186, 0x3FA4B5DCC0000000
  %706 = fcmp fast ogt float %187, 0x3FA4B5DCC0000000
  %707 = fcmp fast ogt float %188, 0x3FA4B5DCC0000000
  %708 = select i1 %705, float 0.000000e+00, float 1.000000e+00
  %709 = select i1 %706, float 0.000000e+00, float 1.000000e+00
  %710 = select i1 %707, float 0.000000e+00, float 1.000000e+00
  %711 = fmul fast float %186, 0x3FB3D07220000000
  %712 = fmul fast float %187, 0x3FB3D07220000000
  %713 = fmul fast float %188, 0x3FB3D07220000000
  %714 = fadd fast float %186, 0x3FAC28F5C0000000
  %715 = fadd fast float %187, 0x3FAC28F5C0000000
  %716 = fadd fast float %188, 0x3FAC28F5C0000000
  %717 = fmul fast float %714, 0x3FEE54EDE0000000
  %718 = fmul fast float %715, 0x3FEE54EDE0000000
  %719 = fmul fast float %716, 0x3FEE54EDE0000000
  %720 = call float @dx.op.unary.f32(i32 23, float %717)  ; Log(value)
  %721 = call float @dx.op.unary.f32(i32 23, float %718)  ; Log(value)
  %722 = call float @dx.op.unary.f32(i32 23, float %719)  ; Log(value)
  %723 = fmul fast float %720, 0x4003333340000000
  %724 = fmul fast float %721, 0x4003333340000000
  %725 = fmul fast float %722, 0x4003333340000000
  %726 = call float @dx.op.unary.f32(i32 21, float %723)  ; Exp(value)
  %727 = call float @dx.op.unary.f32(i32 21, float %724)  ; Exp(value)
  %728 = call float @dx.op.unary.f32(i32 21, float %725)  ; Exp(value)
  %729 = fsub fast float %711, %726
  %730 = fsub fast float %712, %727
  %731 = fsub fast float %713, %728
  %732 = fmul fast float %729, %708
  %733 = fmul fast float %730, %709
  %734 = fmul fast float %731, %710
  %735 = fadd fast float %732, %726
  %736 = fadd fast float %733, %727
  %737 = fadd fast float %734, %728
  br label %953

; <label>:738                                     ; preds = %699
  %739 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %55, i32 %68, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %740 = extractvalue %dx.types.ResRet.f32 %739, 0
  %741 = fcmp fast ogt float %38, 5.000000e-01
  %742 = fcmp fast olt float %740, 1.000000e+00
  %743 = and i1 %741, %742
  br i1 %743, label %744, label %882

; <label>:744                                     ; preds = %738
  %745 = sitofp i32 %55 to float
  %746 = sitofp i32 %68 to float
  %747 = fadd fast float %745, 5.000000e-01
  %748 = fadd fast float %746, 5.000000e-01
  %749 = fdiv fast float %747, %45
  %750 = fdiv fast float %748, %46
  %751 = fmul fast float %749, 2.000000e+00
  %752 = fmul fast float %750, 2.000000e+00
  %753 = fadd fast float %751, -1.000000e+00
  %754 = fsub fast float 1.000000e+00, %752
  %755 = fmul fast float %753, %35
  %756 = call float @dx.op.tertiary.f32(i32 46, float %754, float %31, float %755)  ; FMad(a,b,c)
  %757 = call float @dx.op.tertiary.f32(i32 46, float %740, float %27, float %756)  ; FMad(a,b,c)
  %758 = fadd fast float %757, %23
  %759 = call float @dx.op.unary.f32(i32 6, float %758)  ; FAbs(value)
  %760 = fcmp fast ogt float %759, 0x3EB0C6F7A0000000
  br i1 %760, label %761, label %882

; <label>:761                                     ; preds = %744
  %762 = fmul fast float %753, %34
  %763 = call float @dx.op.tertiary.f32(i32 46, float %754, float %30, float %762)  ; FMad(a,b,c)
  %764 = call float @dx.op.tertiary.f32(i32 46, float %740, float %26, float %763)  ; FMad(a,b,c)
  %765 = fadd fast float %764, %22
  %766 = fmul fast float %753, %33
  %767 = call float @dx.op.tertiary.f32(i32 46, float %754, float %29, float %766)  ; FMad(a,b,c)
  %768 = call float @dx.op.tertiary.f32(i32 46, float %740, float %25, float %767)  ; FMad(a,b,c)
  %769 = fadd fast float %768, %21
  %770 = fmul fast float %753, %32
  %771 = call float @dx.op.tertiary.f32(i32 46, float %754, float %28, float %770)  ; FMad(a,b,c)
  %772 = call float @dx.op.tertiary.f32(i32 46, float %740, float %24, float %771)  ; FMad(a,b,c)
  %773 = fadd fast float %772, %20
  %774 = fdiv fast float %773, %758
  %775 = fdiv fast float %769, %758
  %776 = fdiv fast float %765, %758
  %777 = fsub fast float %774, %17
  %778 = fsub fast float %775, %18
  %779 = fsub fast float %776, %19
  %780 = fmul fast float %777, %777
  %781 = fmul fast float %778, %778
  %782 = fadd fast float %781, %780
  %783 = fmul fast float %779, %779
  %784 = fadd fast float %782, %783
  %785 = call float @dx.op.unary.f32(i32 24, float %784)  ; Sqrt(value)
  %786 = fsub fast float %785, %9
  %787 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %786)  ; FMax(a,b)
  %788 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %788, label %789, label %812

; <label>:789                                     ; preds = %761
  %790 = call float @dx.op.unary.f32(i32 6, float %778)  ; FAbs(value)
  %791 = fmul fast float %790, %11
  %792 = fcmp fast olt float %791, 0x3F50624DE0000000
  br i1 %792, label %793, label %796

; <label>:793                                     ; preds = %789
  %794 = fmul fast float %791, 5.000000e-01
  %795 = fsub fast float 1.000000e+00, %794
  br label %801

; <label>:796                                     ; preds = %789
  %797 = fmul fast float %791, 0xBFF7154760000000
  %798 = call float @dx.op.unary.f32(i32 21, float %797)  ; Exp(value)
  %799 = fsub fast float 1.000000e+00, %798
  %800 = fdiv fast float %799, %791
  br label %801

; <label>:801                                     ; preds = %796, %793
  %802 = phi float [ %795, %793 ], [ %800, %796 ]
  %803 = call float @dx.op.binary.f32(i32 36, float %775, float %18)  ; FMin(a,b)
  %804 = fsub fast float %803, %10
  %805 = fmul fast float %11, %804
  %806 = fsub fast float -0.000000e+00, %805
  %807 = call float @dx.op.binary.f32(i32 35, float %806, float -4.000000e+01)  ; FMax(a,b)
  %808 = call float @dx.op.binary.f32(i32 36, float %807, float 5.000000e+00)  ; FMin(a,b)
  %809 = fmul fast float %808, 0x3FF7154760000000
  %810 = call float @dx.op.unary.f32(i32 21, float %809)  ; Exp(value)
  %811 = fmul fast float %810, %802
  br label %812

; <label>:812                                     ; preds = %801, %761
  %813 = phi float [ %811, %801 ], [ 1.000000e+00, %761 ]
  %814 = fmul fast float %787, %16
  %815 = fmul fast float %814, %813
  %816 = fcmp fast ole float %785, %9
  %817 = fcmp fast olt float %785, 0x3F1A36E2E0000000
  %818 = or i1 %816, %817
  br i1 %818, label %865, label %819

; <label>:819                                     ; preds = %812
  %820 = fdiv fast float %9, %785
  %821 = fmul fast float %820, %777
  %822 = fmul fast float %820, %778
  %823 = fmul fast float %820, %779
  %824 = fadd fast float %821, %17
  %825 = fadd fast float %822, %18
  %826 = fadd fast float %823, %19
  %827 = fadd fast float %824, -9.000000e+02
  %828 = fadd fast float %825, -1.500000e+01
  %829 = fadd fast float %826, -7.500000e+02
  %830 = fmul fast float %827, 0x3F62345680000000
  %831 = fmul fast float %828, 0x3F62345680000000
  %832 = fmul fast float %829, 0x3F62345680000000
  %833 = call float @dx.op.dot3.f32(i32 55, float %830, float %831, float %832, float %830, float %831, float %832)  ; Dot3(ax,ay,az,bx,by,bz)
  %834 = fsub fast float 1.000000e+00, %833
  %835 = call float @dx.op.unary.f32(i32 7, float %834)  ; Saturate(value)
  %836 = fmul fast float %835, %835
  %837 = fadd fast float %824, %774
  %838 = fadd fast float %825, %775
  %839 = fadd fast float %826, %776
  %840 = fmul fast float %837, 0x3F52345680000000
  %841 = fadd fast float %840, -2.000000e+00
  %842 = fmul fast float %838, 0x3F52345680000000
  %843 = fadd fast float %842, 0xBFA1111120000000
  %844 = fmul fast float %839, 0x3F52345680000000
  %845 = fadd fast float %844, 0xBFFAAAAAC0000000
  %846 = call float @dx.op.dot3.f32(i32 55, float %841, float %843, float %845, float %841, float %843, float %845)  ; Dot3(ax,ay,az,bx,by,bz)
  %847 = fsub fast float 1.000000e+00, %846
  %848 = call float @dx.op.unary.f32(i32 7, float %847)  ; Saturate(value)
  %849 = fmul fast float %848, %848
  %850 = fmul fast float %849, 4.000000e+00
  %851 = fadd fast float %850, %836
  %852 = fadd fast float %774, -9.000000e+02
  %853 = fadd fast float %775, -1.500000e+01
  %854 = fadd fast float %776, -7.500000e+02
  %855 = fmul fast float %852, 0x3F62345680000000
  %856 = fmul fast float %853, 0x3F62345680000000
  %857 = fmul fast float %854, 0x3F62345680000000
  %858 = call float @dx.op.dot3.f32(i32 55, float %855, float %856, float %857, float %855, float %856, float %857)  ; Dot3(ax,ay,az,bx,by,bz)
  %859 = fsub fast float 1.000000e+00, %858
  %860 = call float @dx.op.unary.f32(i32 7, float %859)  ; Saturate(value)
  %861 = fmul fast float %860, %860
  %862 = fadd fast float %851, %861
  %863 = fmul fast float %786, 0x3F25D867E0000000
  %864 = fmul fast float %863, %862
  br label %865

; <label>:865                                     ; preds = %819, %812
  %866 = phi float [ %864, %819 ], [ 0.000000e+00, %812 ]
  %867 = fadd fast float %866, %815
  %868 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %867)  ; FMin(a,b)
  %869 = fmul fast float %868, 0xBFF7154760000000
  %870 = call float @dx.op.unary.f32(i32 21, float %869)  ; Exp(value)
  %871 = fsub fast float 1.000000e+00, %870
  %872 = call float @dx.op.binary.f32(i32 36, float %12, float %871)  ; FMin(a,b)
  %873 = fsub fast float %13, %186
  %874 = fsub fast float %14, %187
  %875 = fsub fast float %15, %188
  %876 = fmul fast float %872, %873
  %877 = fmul fast float %872, %874
  %878 = fmul fast float %872, %875
  %879 = fadd fast float %876, %186
  %880 = fadd fast float %877, %187
  %881 = fadd fast float %878, %188
  br label %882

; <label>:882                                     ; preds = %865, %744, %738
  %883 = phi float [ %879, %865 ], [ %186, %744 ], [ %186, %738 ]
  %884 = phi float [ %880, %865 ], [ %187, %744 ], [ %187, %738 ]
  %885 = phi float [ %881, %865 ], [ %188, %744 ], [ %188, %738 ]
  %886 = fadd fast float %5, 1.000000e+00
  %887 = fadd fast float %6, 1.000000e+00
  %888 = fsub fast float 1.000000e+00, %5
  %889 = fmul fast float %36, %886
  %890 = fmul fast float %36, %887
  %891 = fmul fast float %36, %888
  %892 = fmul fast float %889, %883
  %893 = fmul fast float %890, %884
  %894 = fmul fast float %891, %885
  %895 = fcmp fast ult float %37, 5.000000e-01
  br i1 %895, label %921, label %896

; <label>:896                                     ; preds = %882
  %897 = fmul fast float %892, 0x4004147AE0000000
  %898 = fmul fast float %893, 0x4004147AE0000000
  %899 = fmul fast float %894, 0x4004147AE0000000
  %900 = fadd fast float %897, 0x3F9EB851E0000000
  %901 = fadd fast float %898, 0x3F9EB851E0000000
  %902 = fadd fast float %899, 0x3F9EB851E0000000
  %903 = fmul fast float %900, %892
  %904 = fmul fast float %901, %893
  %905 = fmul fast float %902, %894
  %906 = fmul fast float %892, 0x400370A3E0000000
  %907 = fmul fast float %893, 0x400370A3E0000000
  %908 = fmul fast float %894, 0x400370A3E0000000
  %909 = fadd fast float %906, 0x3FE2E147A0000000
  %910 = fadd fast float %907, 0x3FE2E147A0000000
  %911 = fadd fast float %908, 0x3FE2E147A0000000
  %912 = fmul fast float %909, %892
  %913 = fmul fast float %910, %893
  %914 = fmul fast float %911, %894
  %915 = fadd fast float %912, 0x3FC1EB8520000000
  %916 = fadd fast float %913, 0x3FC1EB8520000000
  %917 = fadd fast float %914, 0x3FC1EB8520000000
  %918 = fdiv fast float %903, %915
  %919 = fdiv fast float %904, %916
  %920 = fdiv fast float %905, %917
  br label %921

; <label>:921                                     ; preds = %896, %882
  %922 = phi float [ %918, %896 ], [ %892, %882 ]
  %923 = phi float [ %919, %896 ], [ %893, %882 ]
  %924 = phi float [ %920, %896 ], [ %894, %882 ]
  %925 = call float @dx.op.unary.f32(i32 7, float %922)  ; Saturate(value)
  %926 = call float @dx.op.unary.f32(i32 7, float %923)  ; Saturate(value)
  %927 = call float @dx.op.unary.f32(i32 7, float %924)  ; Saturate(value)
  %928 = call float @dx.op.dot3.f32(i32 55, float %925, float %926, float %927, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %929 = fsub fast float %925, %928
  %930 = fsub fast float %926, %928
  %931 = fsub fast float %927, %928
  %932 = fmul fast float %929, %8
  %933 = fmul fast float %930, %8
  %934 = fmul fast float %931, %8
  %935 = fadd fast float %932, %928
  %936 = fadd fast float %933, %928
  %937 = fadd fast float %934, %928
  %938 = call float @dx.op.unary.f32(i32 7, float %935)  ; Saturate(value)
  %939 = call float @dx.op.unary.f32(i32 7, float %936)  ; Saturate(value)
  %940 = call float @dx.op.unary.f32(i32 7, float %937)  ; Saturate(value)
  %941 = fadd fast float %938, 0xBFC70A3D80000000
  %942 = fadd fast float %939, 0xBFC70A3D80000000
  %943 = fadd fast float %940, 0xBFC70A3D80000000
  %944 = fmul fast float %941, %7
  %945 = fmul fast float %942, %7
  %946 = fmul fast float %943, %7
  %947 = fadd fast float %944, 0x3FC70A3D80000000
  %948 = fadd fast float %945, 0x3FC70A3D80000000
  %949 = fadd fast float %946, 0x3FC70A3D80000000
  %950 = call float @dx.op.unary.f32(i32 7, float %947)  ; Saturate(value)
  %951 = call float @dx.op.unary.f32(i32 7, float %948)  ; Saturate(value)
  %952 = call float @dx.op.unary.f32(i32 7, float %949)  ; Saturate(value)
  br label %953

; <label>:953                                     ; preds = %921, %704
  %954 = phi float [ %735, %704 ], [ %950, %921 ]
  %955 = phi float [ %736, %704 ], [ %951, %921 ]
  %956 = phi float [ %737, %704 ], [ %952, %921 ]
  %957 = fcmp fast olt float %194, 0.000000e+00
  br i1 %957, label %958, label %992

; <label>:958                                     ; preds = %953
  %959 = fcmp fast ogt float %191, 0x3FA4B5DCC0000000
  %960 = fcmp fast ogt float %192, 0x3FA4B5DCC0000000
  %961 = fcmp fast ogt float %193, 0x3FA4B5DCC0000000
  %962 = select i1 %959, float 0.000000e+00, float 1.000000e+00
  %963 = select i1 %960, float 0.000000e+00, float 1.000000e+00
  %964 = select i1 %961, float 0.000000e+00, float 1.000000e+00
  %965 = fmul fast float %191, 0x3FB3D07220000000
  %966 = fmul fast float %192, 0x3FB3D07220000000
  %967 = fmul fast float %193, 0x3FB3D07220000000
  %968 = fadd fast float %191, 0x3FAC28F5C0000000
  %969 = fadd fast float %192, 0x3FAC28F5C0000000
  %970 = fadd fast float %193, 0x3FAC28F5C0000000
  %971 = fmul fast float %968, 0x3FEE54EDE0000000
  %972 = fmul fast float %969, 0x3FEE54EDE0000000
  %973 = fmul fast float %970, 0x3FEE54EDE0000000
  %974 = call float @dx.op.unary.f32(i32 23, float %971)  ; Log(value)
  %975 = call float @dx.op.unary.f32(i32 23, float %972)  ; Log(value)
  %976 = call float @dx.op.unary.f32(i32 23, float %973)  ; Log(value)
  %977 = fmul fast float %974, 0x4003333340000000
  %978 = fmul fast float %975, 0x4003333340000000
  %979 = fmul fast float %976, 0x4003333340000000
  %980 = call float @dx.op.unary.f32(i32 21, float %977)  ; Exp(value)
  %981 = call float @dx.op.unary.f32(i32 21, float %978)  ; Exp(value)
  %982 = call float @dx.op.unary.f32(i32 21, float %979)  ; Exp(value)
  %983 = fsub fast float %965, %980
  %984 = fsub fast float %966, %981
  %985 = fsub fast float %967, %982
  %986 = fmul fast float %983, %962
  %987 = fmul fast float %984, %963
  %988 = fmul fast float %985, %964
  %989 = fadd fast float %986, %980
  %990 = fadd fast float %987, %981
  %991 = fadd fast float %988, %982
  br label %1207

; <label>:992                                     ; preds = %953
  %993 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %65, i32 %68, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %994 = extractvalue %dx.types.ResRet.f32 %993, 0
  %995 = fcmp fast ogt float %38, 5.000000e-01
  %996 = fcmp fast olt float %994, 1.000000e+00
  %997 = and i1 %995, %996
  br i1 %997, label %998, label %1136

; <label>:998                                     ; preds = %992
  %999 = sitofp i32 %65 to float
  %1000 = sitofp i32 %68 to float
  %1001 = fadd fast float %999, 5.000000e-01
  %1002 = fadd fast float %1000, 5.000000e-01
  %1003 = fdiv fast float %1001, %45
  %1004 = fdiv fast float %1002, %46
  %1005 = fmul fast float %1003, 2.000000e+00
  %1006 = fmul fast float %1004, 2.000000e+00
  %1007 = fadd fast float %1005, -1.000000e+00
  %1008 = fsub fast float 1.000000e+00, %1006
  %1009 = fmul fast float %1007, %35
  %1010 = call float @dx.op.tertiary.f32(i32 46, float %1008, float %31, float %1009)  ; FMad(a,b,c)
  %1011 = call float @dx.op.tertiary.f32(i32 46, float %994, float %27, float %1010)  ; FMad(a,b,c)
  %1012 = fadd fast float %1011, %23
  %1013 = call float @dx.op.unary.f32(i32 6, float %1012)  ; FAbs(value)
  %1014 = fcmp fast ogt float %1013, 0x3EB0C6F7A0000000
  br i1 %1014, label %1015, label %1136

; <label>:1015                                    ; preds = %998
  %1016 = fmul fast float %1007, %34
  %1017 = call float @dx.op.tertiary.f32(i32 46, float %1008, float %30, float %1016)  ; FMad(a,b,c)
  %1018 = call float @dx.op.tertiary.f32(i32 46, float %994, float %26, float %1017)  ; FMad(a,b,c)
  %1019 = fadd fast float %1018, %22
  %1020 = fmul fast float %1007, %33
  %1021 = call float @dx.op.tertiary.f32(i32 46, float %1008, float %29, float %1020)  ; FMad(a,b,c)
  %1022 = call float @dx.op.tertiary.f32(i32 46, float %994, float %25, float %1021)  ; FMad(a,b,c)
  %1023 = fadd fast float %1022, %21
  %1024 = fmul fast float %1007, %32
  %1025 = call float @dx.op.tertiary.f32(i32 46, float %1008, float %28, float %1024)  ; FMad(a,b,c)
  %1026 = call float @dx.op.tertiary.f32(i32 46, float %994, float %24, float %1025)  ; FMad(a,b,c)
  %1027 = fadd fast float %1026, %20
  %1028 = fdiv fast float %1027, %1012
  %1029 = fdiv fast float %1023, %1012
  %1030 = fdiv fast float %1019, %1012
  %1031 = fsub fast float %1028, %17
  %1032 = fsub fast float %1029, %18
  %1033 = fsub fast float %1030, %19
  %1034 = fmul fast float %1031, %1031
  %1035 = fmul fast float %1032, %1032
  %1036 = fadd fast float %1035, %1034
  %1037 = fmul fast float %1033, %1033
  %1038 = fadd fast float %1036, %1037
  %1039 = call float @dx.op.unary.f32(i32 24, float %1038)  ; Sqrt(value)
  %1040 = fsub fast float %1039, %9
  %1041 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1040)  ; FMax(a,b)
  %1042 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1042, label %1043, label %1066

; <label>:1043                                    ; preds = %1015
  %1044 = call float @dx.op.unary.f32(i32 6, float %1032)  ; FAbs(value)
  %1045 = fmul fast float %1044, %11
  %1046 = fcmp fast olt float %1045, 0x3F50624DE0000000
  br i1 %1046, label %1047, label %1050

; <label>:1047                                    ; preds = %1043
  %1048 = fmul fast float %1045, 5.000000e-01
  %1049 = fsub fast float 1.000000e+00, %1048
  br label %1055

; <label>:1050                                    ; preds = %1043
  %1051 = fmul fast float %1045, 0xBFF7154760000000
  %1052 = call float @dx.op.unary.f32(i32 21, float %1051)  ; Exp(value)
  %1053 = fsub fast float 1.000000e+00, %1052
  %1054 = fdiv fast float %1053, %1045
  br label %1055

; <label>:1055                                    ; preds = %1050, %1047
  %1056 = phi float [ %1049, %1047 ], [ %1054, %1050 ]
  %1057 = call float @dx.op.binary.f32(i32 36, float %1029, float %18)  ; FMin(a,b)
  %1058 = fsub fast float %1057, %10
  %1059 = fmul fast float %11, %1058
  %1060 = fsub fast float -0.000000e+00, %1059
  %1061 = call float @dx.op.binary.f32(i32 35, float %1060, float -4.000000e+01)  ; FMax(a,b)
  %1062 = call float @dx.op.binary.f32(i32 36, float %1061, float 5.000000e+00)  ; FMin(a,b)
  %1063 = fmul fast float %1062, 0x3FF7154760000000
  %1064 = call float @dx.op.unary.f32(i32 21, float %1063)  ; Exp(value)
  %1065 = fmul fast float %1064, %1056
  br label %1066

; <label>:1066                                    ; preds = %1055, %1015
  %1067 = phi float [ %1065, %1055 ], [ 1.000000e+00, %1015 ]
  %1068 = fmul fast float %1041, %16
  %1069 = fmul fast float %1068, %1067
  %1070 = fcmp fast ole float %1039, %9
  %1071 = fcmp fast olt float %1039, 0x3F1A36E2E0000000
  %1072 = or i1 %1070, %1071
  br i1 %1072, label %1119, label %1073

; <label>:1073                                    ; preds = %1066
  %1074 = fdiv fast float %9, %1039
  %1075 = fmul fast float %1074, %1031
  %1076 = fmul fast float %1074, %1032
  %1077 = fmul fast float %1074, %1033
  %1078 = fadd fast float %1075, %17
  %1079 = fadd fast float %1076, %18
  %1080 = fadd fast float %1077, %19
  %1081 = fadd fast float %1078, -9.000000e+02
  %1082 = fadd fast float %1079, -1.500000e+01
  %1083 = fadd fast float %1080, -7.500000e+02
  %1084 = fmul fast float %1081, 0x3F62345680000000
  %1085 = fmul fast float %1082, 0x3F62345680000000
  %1086 = fmul fast float %1083, 0x3F62345680000000
  %1087 = call float @dx.op.dot3.f32(i32 55, float %1084, float %1085, float %1086, float %1084, float %1085, float %1086)  ; Dot3(ax,ay,az,bx,by,bz)
  %1088 = fsub fast float 1.000000e+00, %1087
  %1089 = call float @dx.op.unary.f32(i32 7, float %1088)  ; Saturate(value)
  %1090 = fmul fast float %1089, %1089
  %1091 = fadd fast float %1078, %1028
  %1092 = fadd fast float %1079, %1029
  %1093 = fadd fast float %1080, %1030
  %1094 = fmul fast float %1091, 0x3F52345680000000
  %1095 = fadd fast float %1094, -2.000000e+00
  %1096 = fmul fast float %1092, 0x3F52345680000000
  %1097 = fadd fast float %1096, 0xBFA1111120000000
  %1098 = fmul fast float %1093, 0x3F52345680000000
  %1099 = fadd fast float %1098, 0xBFFAAAAAC0000000
  %1100 = call float @dx.op.dot3.f32(i32 55, float %1095, float %1097, float %1099, float %1095, float %1097, float %1099)  ; Dot3(ax,ay,az,bx,by,bz)
  %1101 = fsub fast float 1.000000e+00, %1100
  %1102 = call float @dx.op.unary.f32(i32 7, float %1101)  ; Saturate(value)
  %1103 = fmul fast float %1102, %1102
  %1104 = fmul fast float %1103, 4.000000e+00
  %1105 = fadd fast float %1104, %1090
  %1106 = fadd fast float %1028, -9.000000e+02
  %1107 = fadd fast float %1029, -1.500000e+01
  %1108 = fadd fast float %1030, -7.500000e+02
  %1109 = fmul fast float %1106, 0x3F62345680000000
  %1110 = fmul fast float %1107, 0x3F62345680000000
  %1111 = fmul fast float %1108, 0x3F62345680000000
  %1112 = call float @dx.op.dot3.f32(i32 55, float %1109, float %1110, float %1111, float %1109, float %1110, float %1111)  ; Dot3(ax,ay,az,bx,by,bz)
  %1113 = fsub fast float 1.000000e+00, %1112
  %1114 = call float @dx.op.unary.f32(i32 7, float %1113)  ; Saturate(value)
  %1115 = fmul fast float %1114, %1114
  %1116 = fadd fast float %1105, %1115
  %1117 = fmul fast float %1040, 0x3F25D867E0000000
  %1118 = fmul fast float %1117, %1116
  br label %1119

; <label>:1119                                    ; preds = %1073, %1066
  %1120 = phi float [ %1118, %1073 ], [ 0.000000e+00, %1066 ]
  %1121 = fadd fast float %1120, %1069
  %1122 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1121)  ; FMin(a,b)
  %1123 = fmul fast float %1122, 0xBFF7154760000000
  %1124 = call float @dx.op.unary.f32(i32 21, float %1123)  ; Exp(value)
  %1125 = fsub fast float 1.000000e+00, %1124
  %1126 = call float @dx.op.binary.f32(i32 36, float %12, float %1125)  ; FMin(a,b)
  %1127 = fsub fast float %13, %191
  %1128 = fsub fast float %14, %192
  %1129 = fsub fast float %15, %193
  %1130 = fmul fast float %1126, %1127
  %1131 = fmul fast float %1126, %1128
  %1132 = fmul fast float %1126, %1129
  %1133 = fadd fast float %1130, %191
  %1134 = fadd fast float %1131, %192
  %1135 = fadd fast float %1132, %193
  br label %1136

; <label>:1136                                    ; preds = %1119, %998, %992
  %1137 = phi float [ %1133, %1119 ], [ %191, %998 ], [ %191, %992 ]
  %1138 = phi float [ %1134, %1119 ], [ %192, %998 ], [ %192, %992 ]
  %1139 = phi float [ %1135, %1119 ], [ %193, %998 ], [ %193, %992 ]
  %1140 = fadd fast float %5, 1.000000e+00
  %1141 = fadd fast float %6, 1.000000e+00
  %1142 = fsub fast float 1.000000e+00, %5
  %1143 = fmul fast float %36, %1140
  %1144 = fmul fast float %36, %1141
  %1145 = fmul fast float %36, %1142
  %1146 = fmul fast float %1143, %1137
  %1147 = fmul fast float %1144, %1138
  %1148 = fmul fast float %1145, %1139
  %1149 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1149, label %1175, label %1150

; <label>:1150                                    ; preds = %1136
  %1151 = fmul fast float %1146, 0x4004147AE0000000
  %1152 = fmul fast float %1147, 0x4004147AE0000000
  %1153 = fmul fast float %1148, 0x4004147AE0000000
  %1154 = fadd fast float %1151, 0x3F9EB851E0000000
  %1155 = fadd fast float %1152, 0x3F9EB851E0000000
  %1156 = fadd fast float %1153, 0x3F9EB851E0000000
  %1157 = fmul fast float %1154, %1146
  %1158 = fmul fast float %1155, %1147
  %1159 = fmul fast float %1156, %1148
  %1160 = fmul fast float %1146, 0x400370A3E0000000
  %1161 = fmul fast float %1147, 0x400370A3E0000000
  %1162 = fmul fast float %1148, 0x400370A3E0000000
  %1163 = fadd fast float %1160, 0x3FE2E147A0000000
  %1164 = fadd fast float %1161, 0x3FE2E147A0000000
  %1165 = fadd fast float %1162, 0x3FE2E147A0000000
  %1166 = fmul fast float %1163, %1146
  %1167 = fmul fast float %1164, %1147
  %1168 = fmul fast float %1165, %1148
  %1169 = fadd fast float %1166, 0x3FC1EB8520000000
  %1170 = fadd fast float %1167, 0x3FC1EB8520000000
  %1171 = fadd fast float %1168, 0x3FC1EB8520000000
  %1172 = fdiv fast float %1157, %1169
  %1173 = fdiv fast float %1158, %1170
  %1174 = fdiv fast float %1159, %1171
  br label %1175

; <label>:1175                                    ; preds = %1150, %1136
  %1176 = phi float [ %1172, %1150 ], [ %1146, %1136 ]
  %1177 = phi float [ %1173, %1150 ], [ %1147, %1136 ]
  %1178 = phi float [ %1174, %1150 ], [ %1148, %1136 ]
  %1179 = call float @dx.op.unary.f32(i32 7, float %1176)  ; Saturate(value)
  %1180 = call float @dx.op.unary.f32(i32 7, float %1177)  ; Saturate(value)
  %1181 = call float @dx.op.unary.f32(i32 7, float %1178)  ; Saturate(value)
  %1182 = call float @dx.op.dot3.f32(i32 55, float %1179, float %1180, float %1181, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1183 = fsub fast float %1179, %1182
  %1184 = fsub fast float %1180, %1182
  %1185 = fsub fast float %1181, %1182
  %1186 = fmul fast float %1183, %8
  %1187 = fmul fast float %1184, %8
  %1188 = fmul fast float %1185, %8
  %1189 = fadd fast float %1186, %1182
  %1190 = fadd fast float %1187, %1182
  %1191 = fadd fast float %1188, %1182
  %1192 = call float @dx.op.unary.f32(i32 7, float %1189)  ; Saturate(value)
  %1193 = call float @dx.op.unary.f32(i32 7, float %1190)  ; Saturate(value)
  %1194 = call float @dx.op.unary.f32(i32 7, float %1191)  ; Saturate(value)
  %1195 = fadd fast float %1192, 0xBFC70A3D80000000
  %1196 = fadd fast float %1193, 0xBFC70A3D80000000
  %1197 = fadd fast float %1194, 0xBFC70A3D80000000
  %1198 = fmul fast float %1195, %7
  %1199 = fmul fast float %1196, %7
  %1200 = fmul fast float %1197, %7
  %1201 = fadd fast float %1198, 0x3FC70A3D80000000
  %1202 = fadd fast float %1199, 0x3FC70A3D80000000
  %1203 = fadd fast float %1200, 0x3FC70A3D80000000
  %1204 = call float @dx.op.unary.f32(i32 7, float %1201)  ; Saturate(value)
  %1205 = call float @dx.op.unary.f32(i32 7, float %1202)  ; Saturate(value)
  %1206 = call float @dx.op.unary.f32(i32 7, float %1203)  ; Saturate(value)
  br label %1207

; <label>:1207                                    ; preds = %1175, %958
  %1208 = phi float [ %989, %958 ], [ %1204, %1175 ]
  %1209 = phi float [ %990, %958 ], [ %1205, %1175 ]
  %1210 = phi float [ %991, %958 ], [ %1206, %1175 ]
  %1211 = fsub fast float -1.000000e+00, %179
  %1212 = select i1 %195, float %1211, float %179
  %1213 = fsub fast float -1.000000e+00, %184
  %1214 = select i1 %449, float %1213, float %184
  %1215 = fsub fast float -1.000000e+00, %189
  %1216 = select i1 %703, float %1215, float %189
  %1217 = fsub fast float -1.000000e+00, %194
  %1218 = select i1 %957, float %1217, float %194
  br label %2251

; <label>:1219                                    ; preds = %172
  %1220 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1221 = extractvalue %dx.types.ResRet.f32 %1220, 0
  %1222 = extractvalue %dx.types.ResRet.f32 %1220, 1
  %1223 = extractvalue %dx.types.ResRet.f32 %1220, 2
  %1224 = extractvalue %dx.types.ResRet.f32 %1220, 3
  %1225 = fcmp fast olt float %1224, 0.000000e+00
  br i1 %1225, label %1226, label %1261

; <label>:1226                                    ; preds = %1219
  %1227 = fcmp fast ogt float %1221, 0x3FA4B5DCC0000000
  %1228 = fcmp fast ogt float %1222, 0x3FA4B5DCC0000000
  %1229 = fcmp fast ogt float %1223, 0x3FA4B5DCC0000000
  %1230 = select i1 %1227, float 0.000000e+00, float 1.000000e+00
  %1231 = select i1 %1228, float 0.000000e+00, float 1.000000e+00
  %1232 = select i1 %1229, float 0.000000e+00, float 1.000000e+00
  %1233 = fmul fast float %1221, 0x3FB3D07220000000
  %1234 = fmul fast float %1222, 0x3FB3D07220000000
  %1235 = fmul fast float %1223, 0x3FB3D07220000000
  %1236 = fadd fast float %1221, 0x3FAC28F5C0000000
  %1237 = fadd fast float %1222, 0x3FAC28F5C0000000
  %1238 = fadd fast float %1223, 0x3FAC28F5C0000000
  %1239 = fmul fast float %1236, 0x3FEE54EDE0000000
  %1240 = fmul fast float %1237, 0x3FEE54EDE0000000
  %1241 = fmul fast float %1238, 0x3FEE54EDE0000000
  %1242 = call float @dx.op.unary.f32(i32 23, float %1239)  ; Log(value)
  %1243 = call float @dx.op.unary.f32(i32 23, float %1240)  ; Log(value)
  %1244 = call float @dx.op.unary.f32(i32 23, float %1241)  ; Log(value)
  %1245 = fmul fast float %1242, 0x4003333340000000
  %1246 = fmul fast float %1243, 0x4003333340000000
  %1247 = fmul fast float %1244, 0x4003333340000000
  %1248 = call float @dx.op.unary.f32(i32 21, float %1245)  ; Exp(value)
  %1249 = call float @dx.op.unary.f32(i32 21, float %1246)  ; Exp(value)
  %1250 = call float @dx.op.unary.f32(i32 21, float %1247)  ; Exp(value)
  %1251 = fsub fast float %1233, %1248
  %1252 = fsub fast float %1234, %1249
  %1253 = fsub fast float %1235, %1250
  %1254 = fmul fast float %1251, %1230
  %1255 = fmul fast float %1252, %1231
  %1256 = fmul fast float %1253, %1232
  %1257 = fadd fast float %1254, %1248
  %1258 = fadd fast float %1255, %1249
  %1259 = fadd fast float %1256, %1250
  %1260 = fsub fast float -1.000000e+00, %1224
  br label %1474

; <label>:1261                                    ; preds = %1219
  %1262 = fcmp fast ogt float %38, 5.000000e-01
  %1263 = fcmp fast olt float %82, 1.000000e+00
  %1264 = and i1 %1262, %1263
  br i1 %1264, label %1265, label %1403

; <label>:1265                                    ; preds = %1261
  %1266 = sitofp i32 %63 to float
  %1267 = sitofp i32 %64 to float
  %1268 = fadd fast float %1266, 5.000000e-01
  %1269 = fadd fast float %1267, 5.000000e-01
  %1270 = fdiv fast float %1268, %45
  %1271 = fdiv fast float %1269, %46
  %1272 = fmul fast float %1270, 2.000000e+00
  %1273 = fmul fast float %1271, 2.000000e+00
  %1274 = fadd fast float %1272, -1.000000e+00
  %1275 = fsub fast float 1.000000e+00, %1273
  %1276 = fmul fast float %1274, %35
  %1277 = call float @dx.op.tertiary.f32(i32 46, float %1275, float %31, float %1276)  ; FMad(a,b,c)
  %1278 = call float @dx.op.tertiary.f32(i32 46, float %82, float %27, float %1277)  ; FMad(a,b,c)
  %1279 = fadd fast float %1278, %23
  %1280 = call float @dx.op.unary.f32(i32 6, float %1279)  ; FAbs(value)
  %1281 = fcmp fast ogt float %1280, 0x3EB0C6F7A0000000
  br i1 %1281, label %1282, label %1403

; <label>:1282                                    ; preds = %1265
  %1283 = fmul fast float %1274, %34
  %1284 = call float @dx.op.tertiary.f32(i32 46, float %1275, float %30, float %1283)  ; FMad(a,b,c)
  %1285 = call float @dx.op.tertiary.f32(i32 46, float %82, float %26, float %1284)  ; FMad(a,b,c)
  %1286 = fadd fast float %1285, %22
  %1287 = fmul fast float %1274, %33
  %1288 = call float @dx.op.tertiary.f32(i32 46, float %1275, float %29, float %1287)  ; FMad(a,b,c)
  %1289 = call float @dx.op.tertiary.f32(i32 46, float %82, float %25, float %1288)  ; FMad(a,b,c)
  %1290 = fadd fast float %1289, %21
  %1291 = fmul fast float %1274, %32
  %1292 = call float @dx.op.tertiary.f32(i32 46, float %1275, float %28, float %1291)  ; FMad(a,b,c)
  %1293 = call float @dx.op.tertiary.f32(i32 46, float %82, float %24, float %1292)  ; FMad(a,b,c)
  %1294 = fadd fast float %1293, %20
  %1295 = fdiv fast float %1294, %1279
  %1296 = fdiv fast float %1290, %1279
  %1297 = fdiv fast float %1286, %1279
  %1298 = fsub fast float %1295, %17
  %1299 = fsub fast float %1296, %18
  %1300 = fsub fast float %1297, %19
  %1301 = fmul fast float %1298, %1298
  %1302 = fmul fast float %1299, %1299
  %1303 = fadd fast float %1302, %1301
  %1304 = fmul fast float %1300, %1300
  %1305 = fadd fast float %1303, %1304
  %1306 = call float @dx.op.unary.f32(i32 24, float %1305)  ; Sqrt(value)
  %1307 = fsub fast float %1306, %9
  %1308 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1307)  ; FMax(a,b)
  %1309 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1309, label %1310, label %1333

; <label>:1310                                    ; preds = %1282
  %1311 = call float @dx.op.unary.f32(i32 6, float %1299)  ; FAbs(value)
  %1312 = fmul fast float %1311, %11
  %1313 = fcmp fast olt float %1312, 0x3F50624DE0000000
  br i1 %1313, label %1314, label %1317

; <label>:1314                                    ; preds = %1310
  %1315 = fmul fast float %1312, 5.000000e-01
  %1316 = fsub fast float 1.000000e+00, %1315
  br label %1322

; <label>:1317                                    ; preds = %1310
  %1318 = fmul fast float %1312, 0xBFF7154760000000
  %1319 = call float @dx.op.unary.f32(i32 21, float %1318)  ; Exp(value)
  %1320 = fsub fast float 1.000000e+00, %1319
  %1321 = fdiv fast float %1320, %1312
  br label %1322

; <label>:1322                                    ; preds = %1317, %1314
  %1323 = phi float [ %1316, %1314 ], [ %1321, %1317 ]
  %1324 = call float @dx.op.binary.f32(i32 36, float %1296, float %18)  ; FMin(a,b)
  %1325 = fsub fast float %1324, %10
  %1326 = fmul fast float %11, %1325
  %1327 = fsub fast float -0.000000e+00, %1326
  %1328 = call float @dx.op.binary.f32(i32 35, float %1327, float -4.000000e+01)  ; FMax(a,b)
  %1329 = call float @dx.op.binary.f32(i32 36, float %1328, float 5.000000e+00)  ; FMin(a,b)
  %1330 = fmul fast float %1329, 0x3FF7154760000000
  %1331 = call float @dx.op.unary.f32(i32 21, float %1330)  ; Exp(value)
  %1332 = fmul fast float %1331, %1323
  br label %1333

; <label>:1333                                    ; preds = %1322, %1282
  %1334 = phi float [ %1332, %1322 ], [ 1.000000e+00, %1282 ]
  %1335 = fmul fast float %1308, %16
  %1336 = fmul fast float %1335, %1334
  %1337 = fcmp fast ole float %1306, %9
  %1338 = fcmp fast olt float %1306, 0x3F1A36E2E0000000
  %1339 = or i1 %1337, %1338
  br i1 %1339, label %1386, label %1340

; <label>:1340                                    ; preds = %1333
  %1341 = fdiv fast float %9, %1306
  %1342 = fmul fast float %1341, %1298
  %1343 = fmul fast float %1341, %1299
  %1344 = fmul fast float %1341, %1300
  %1345 = fadd fast float %1342, %17
  %1346 = fadd fast float %1343, %18
  %1347 = fadd fast float %1344, %19
  %1348 = fadd fast float %1345, -9.000000e+02
  %1349 = fadd fast float %1346, -1.500000e+01
  %1350 = fadd fast float %1347, -7.500000e+02
  %1351 = fmul fast float %1348, 0x3F62345680000000
  %1352 = fmul fast float %1349, 0x3F62345680000000
  %1353 = fmul fast float %1350, 0x3F62345680000000
  %1354 = call float @dx.op.dot3.f32(i32 55, float %1351, float %1352, float %1353, float %1351, float %1352, float %1353)  ; Dot3(ax,ay,az,bx,by,bz)
  %1355 = fsub fast float 1.000000e+00, %1354
  %1356 = call float @dx.op.unary.f32(i32 7, float %1355)  ; Saturate(value)
  %1357 = fmul fast float %1356, %1356
  %1358 = fadd fast float %1345, %1295
  %1359 = fadd fast float %1346, %1296
  %1360 = fadd fast float %1347, %1297
  %1361 = fmul fast float %1358, 0x3F52345680000000
  %1362 = fadd fast float %1361, -2.000000e+00
  %1363 = fmul fast float %1359, 0x3F52345680000000
  %1364 = fadd fast float %1363, 0xBFA1111120000000
  %1365 = fmul fast float %1360, 0x3F52345680000000
  %1366 = fadd fast float %1365, 0xBFFAAAAAC0000000
  %1367 = call float @dx.op.dot3.f32(i32 55, float %1362, float %1364, float %1366, float %1362, float %1364, float %1366)  ; Dot3(ax,ay,az,bx,by,bz)
  %1368 = fsub fast float 1.000000e+00, %1367
  %1369 = call float @dx.op.unary.f32(i32 7, float %1368)  ; Saturate(value)
  %1370 = fmul fast float %1369, %1369
  %1371 = fmul fast float %1370, 4.000000e+00
  %1372 = fadd fast float %1371, %1357
  %1373 = fadd fast float %1295, -9.000000e+02
  %1374 = fadd fast float %1296, -1.500000e+01
  %1375 = fadd fast float %1297, -7.500000e+02
  %1376 = fmul fast float %1373, 0x3F62345680000000
  %1377 = fmul fast float %1374, 0x3F62345680000000
  %1378 = fmul fast float %1375, 0x3F62345680000000
  %1379 = call float @dx.op.dot3.f32(i32 55, float %1376, float %1377, float %1378, float %1376, float %1377, float %1378)  ; Dot3(ax,ay,az,bx,by,bz)
  %1380 = fsub fast float 1.000000e+00, %1379
  %1381 = call float @dx.op.unary.f32(i32 7, float %1380)  ; Saturate(value)
  %1382 = fmul fast float %1381, %1381
  %1383 = fadd fast float %1372, %1382
  %1384 = fmul fast float %1307, 0x3F25D867E0000000
  %1385 = fmul fast float %1384, %1383
  br label %1386

; <label>:1386                                    ; preds = %1340, %1333
  %1387 = phi float [ %1385, %1340 ], [ 0.000000e+00, %1333 ]
  %1388 = fadd fast float %1387, %1336
  %1389 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1388)  ; FMin(a,b)
  %1390 = fmul fast float %1389, 0xBFF7154760000000
  %1391 = call float @dx.op.unary.f32(i32 21, float %1390)  ; Exp(value)
  %1392 = fsub fast float 1.000000e+00, %1391
  %1393 = call float @dx.op.binary.f32(i32 36, float %12, float %1392)  ; FMin(a,b)
  %1394 = fsub fast float %13, %1221
  %1395 = fsub fast float %14, %1222
  %1396 = fsub fast float %15, %1223
  %1397 = fmul fast float %1393, %1394
  %1398 = fmul fast float %1393, %1395
  %1399 = fmul fast float %1393, %1396
  %1400 = fadd fast float %1397, %1221
  %1401 = fadd fast float %1398, %1222
  %1402 = fadd fast float %1399, %1223
  br label %1403

; <label>:1403                                    ; preds = %1386, %1265, %1261
  %1404 = phi float [ %1400, %1386 ], [ %1221, %1265 ], [ %1221, %1261 ]
  %1405 = phi float [ %1401, %1386 ], [ %1222, %1265 ], [ %1222, %1261 ]
  %1406 = phi float [ %1402, %1386 ], [ %1223, %1265 ], [ %1223, %1261 ]
  %1407 = fadd fast float %5, 1.000000e+00
  %1408 = fadd fast float %6, 1.000000e+00
  %1409 = fsub fast float 1.000000e+00, %5
  %1410 = fmul fast float %36, %1407
  %1411 = fmul fast float %36, %1408
  %1412 = fmul fast float %36, %1409
  %1413 = fmul fast float %1410, %1404
  %1414 = fmul fast float %1411, %1405
  %1415 = fmul fast float %1412, %1406
  %1416 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1416, label %1442, label %1417

; <label>:1417                                    ; preds = %1403
  %1418 = fmul fast float %1413, 0x4004147AE0000000
  %1419 = fmul fast float %1414, 0x4004147AE0000000
  %1420 = fmul fast float %1415, 0x4004147AE0000000
  %1421 = fadd fast float %1418, 0x3F9EB851E0000000
  %1422 = fadd fast float %1419, 0x3F9EB851E0000000
  %1423 = fadd fast float %1420, 0x3F9EB851E0000000
  %1424 = fmul fast float %1421, %1413
  %1425 = fmul fast float %1422, %1414
  %1426 = fmul fast float %1423, %1415
  %1427 = fmul fast float %1413, 0x400370A3E0000000
  %1428 = fmul fast float %1414, 0x400370A3E0000000
  %1429 = fmul fast float %1415, 0x400370A3E0000000
  %1430 = fadd fast float %1427, 0x3FE2E147A0000000
  %1431 = fadd fast float %1428, 0x3FE2E147A0000000
  %1432 = fadd fast float %1429, 0x3FE2E147A0000000
  %1433 = fmul fast float %1430, %1413
  %1434 = fmul fast float %1431, %1414
  %1435 = fmul fast float %1432, %1415
  %1436 = fadd fast float %1433, 0x3FC1EB8520000000
  %1437 = fadd fast float %1434, 0x3FC1EB8520000000
  %1438 = fadd fast float %1435, 0x3FC1EB8520000000
  %1439 = fdiv fast float %1424, %1436
  %1440 = fdiv fast float %1425, %1437
  %1441 = fdiv fast float %1426, %1438
  br label %1442

; <label>:1442                                    ; preds = %1417, %1403
  %1443 = phi float [ %1439, %1417 ], [ %1413, %1403 ]
  %1444 = phi float [ %1440, %1417 ], [ %1414, %1403 ]
  %1445 = phi float [ %1441, %1417 ], [ %1415, %1403 ]
  %1446 = call float @dx.op.unary.f32(i32 7, float %1443)  ; Saturate(value)
  %1447 = call float @dx.op.unary.f32(i32 7, float %1444)  ; Saturate(value)
  %1448 = call float @dx.op.unary.f32(i32 7, float %1445)  ; Saturate(value)
  %1449 = call float @dx.op.dot3.f32(i32 55, float %1446, float %1447, float %1448, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1450 = fsub fast float %1446, %1449
  %1451 = fsub fast float %1447, %1449
  %1452 = fsub fast float %1448, %1449
  %1453 = fmul fast float %1450, %8
  %1454 = fmul fast float %1451, %8
  %1455 = fmul fast float %1452, %8
  %1456 = fadd fast float %1453, %1449
  %1457 = fadd fast float %1454, %1449
  %1458 = fadd fast float %1455, %1449
  %1459 = call float @dx.op.unary.f32(i32 7, float %1456)  ; Saturate(value)
  %1460 = call float @dx.op.unary.f32(i32 7, float %1457)  ; Saturate(value)
  %1461 = call float @dx.op.unary.f32(i32 7, float %1458)  ; Saturate(value)
  %1462 = fadd fast float %1459, 0xBFC70A3D80000000
  %1463 = fadd fast float %1460, 0xBFC70A3D80000000
  %1464 = fadd fast float %1461, 0xBFC70A3D80000000
  %1465 = fmul fast float %1462, %7
  %1466 = fmul fast float %1463, %7
  %1467 = fmul fast float %1464, %7
  %1468 = fadd fast float %1465, 0x3FC70A3D80000000
  %1469 = fadd fast float %1466, 0x3FC70A3D80000000
  %1470 = fadd fast float %1467, 0x3FC70A3D80000000
  %1471 = call float @dx.op.unary.f32(i32 7, float %1468)  ; Saturate(value)
  %1472 = call float @dx.op.unary.f32(i32 7, float %1469)  ; Saturate(value)
  %1473 = call float @dx.op.unary.f32(i32 7, float %1470)  ; Saturate(value)
  br label %1474

; <label>:1474                                    ; preds = %1442, %1226
  %1475 = phi float [ %1257, %1226 ], [ %1471, %1442 ]
  %1476 = phi float [ %1258, %1226 ], [ %1472, %1442 ]
  %1477 = phi float [ %1259, %1226 ], [ %1473, %1442 ]
  %1478 = phi float [ %1260, %1226 ], [ %1224, %1442 ]
  %1479 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %67, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1480 = extractvalue %dx.types.ResRet.f32 %1479, 0
  %1481 = extractvalue %dx.types.ResRet.f32 %1479, 1
  %1482 = extractvalue %dx.types.ResRet.f32 %1479, 2
  %1483 = extractvalue %dx.types.ResRet.f32 %1479, 3
  %1484 = fcmp fast olt float %1483, 0.000000e+00
  br i1 %1484, label %1485, label %1520

; <label>:1485                                    ; preds = %1474
  %1486 = fcmp fast ogt float %1480, 0x3FA4B5DCC0000000
  %1487 = fcmp fast ogt float %1481, 0x3FA4B5DCC0000000
  %1488 = fcmp fast ogt float %1482, 0x3FA4B5DCC0000000
  %1489 = select i1 %1486, float 0.000000e+00, float 1.000000e+00
  %1490 = select i1 %1487, float 0.000000e+00, float 1.000000e+00
  %1491 = select i1 %1488, float 0.000000e+00, float 1.000000e+00
  %1492 = fmul fast float %1480, 0x3FB3D07220000000
  %1493 = fmul fast float %1481, 0x3FB3D07220000000
  %1494 = fmul fast float %1482, 0x3FB3D07220000000
  %1495 = fadd fast float %1480, 0x3FAC28F5C0000000
  %1496 = fadd fast float %1481, 0x3FAC28F5C0000000
  %1497 = fadd fast float %1482, 0x3FAC28F5C0000000
  %1498 = fmul fast float %1495, 0x3FEE54EDE0000000
  %1499 = fmul fast float %1496, 0x3FEE54EDE0000000
  %1500 = fmul fast float %1497, 0x3FEE54EDE0000000
  %1501 = call float @dx.op.unary.f32(i32 23, float %1498)  ; Log(value)
  %1502 = call float @dx.op.unary.f32(i32 23, float %1499)  ; Log(value)
  %1503 = call float @dx.op.unary.f32(i32 23, float %1500)  ; Log(value)
  %1504 = fmul fast float %1501, 0x4003333340000000
  %1505 = fmul fast float %1502, 0x4003333340000000
  %1506 = fmul fast float %1503, 0x4003333340000000
  %1507 = call float @dx.op.unary.f32(i32 21, float %1504)  ; Exp(value)
  %1508 = call float @dx.op.unary.f32(i32 21, float %1505)  ; Exp(value)
  %1509 = call float @dx.op.unary.f32(i32 21, float %1506)  ; Exp(value)
  %1510 = fsub fast float %1492, %1507
  %1511 = fsub fast float %1493, %1508
  %1512 = fsub fast float %1494, %1509
  %1513 = fmul fast float %1510, %1489
  %1514 = fmul fast float %1511, %1490
  %1515 = fmul fast float %1512, %1491
  %1516 = fadd fast float %1513, %1507
  %1517 = fadd fast float %1514, %1508
  %1518 = fadd fast float %1515, %1509
  %1519 = fsub fast float -1.000000e+00, %1483
  br label %1733

; <label>:1520                                    ; preds = %1474
  %1521 = fcmp fast ogt float %38, 5.000000e-01
  %1522 = fcmp fast olt float %84, 1.000000e+00
  %1523 = and i1 %1521, %1522
  br i1 %1523, label %1524, label %1662

; <label>:1524                                    ; preds = %1520
  %1525 = sitofp i32 %67 to float
  %1526 = sitofp i32 %64 to float
  %1527 = fadd fast float %1525, 5.000000e-01
  %1528 = fadd fast float %1526, 5.000000e-01
  %1529 = fdiv fast float %1527, %45
  %1530 = fdiv fast float %1528, %46
  %1531 = fmul fast float %1529, 2.000000e+00
  %1532 = fmul fast float %1530, 2.000000e+00
  %1533 = fadd fast float %1531, -1.000000e+00
  %1534 = fsub fast float 1.000000e+00, %1532
  %1535 = fmul fast float %1533, %35
  %1536 = call float @dx.op.tertiary.f32(i32 46, float %1534, float %31, float %1535)  ; FMad(a,b,c)
  %1537 = call float @dx.op.tertiary.f32(i32 46, float %84, float %27, float %1536)  ; FMad(a,b,c)
  %1538 = fadd fast float %1537, %23
  %1539 = call float @dx.op.unary.f32(i32 6, float %1538)  ; FAbs(value)
  %1540 = fcmp fast ogt float %1539, 0x3EB0C6F7A0000000
  br i1 %1540, label %1541, label %1662

; <label>:1541                                    ; preds = %1524
  %1542 = fmul fast float %1533, %34
  %1543 = call float @dx.op.tertiary.f32(i32 46, float %1534, float %30, float %1542)  ; FMad(a,b,c)
  %1544 = call float @dx.op.tertiary.f32(i32 46, float %84, float %26, float %1543)  ; FMad(a,b,c)
  %1545 = fadd fast float %1544, %22
  %1546 = fmul fast float %1533, %33
  %1547 = call float @dx.op.tertiary.f32(i32 46, float %1534, float %29, float %1546)  ; FMad(a,b,c)
  %1548 = call float @dx.op.tertiary.f32(i32 46, float %84, float %25, float %1547)  ; FMad(a,b,c)
  %1549 = fadd fast float %1548, %21
  %1550 = fmul fast float %1533, %32
  %1551 = call float @dx.op.tertiary.f32(i32 46, float %1534, float %28, float %1550)  ; FMad(a,b,c)
  %1552 = call float @dx.op.tertiary.f32(i32 46, float %84, float %24, float %1551)  ; FMad(a,b,c)
  %1553 = fadd fast float %1552, %20
  %1554 = fdiv fast float %1553, %1538
  %1555 = fdiv fast float %1549, %1538
  %1556 = fdiv fast float %1545, %1538
  %1557 = fsub fast float %1554, %17
  %1558 = fsub fast float %1555, %18
  %1559 = fsub fast float %1556, %19
  %1560 = fmul fast float %1557, %1557
  %1561 = fmul fast float %1558, %1558
  %1562 = fadd fast float %1561, %1560
  %1563 = fmul fast float %1559, %1559
  %1564 = fadd fast float %1562, %1563
  %1565 = call float @dx.op.unary.f32(i32 24, float %1564)  ; Sqrt(value)
  %1566 = fsub fast float %1565, %9
  %1567 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1566)  ; FMax(a,b)
  %1568 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1568, label %1569, label %1592

; <label>:1569                                    ; preds = %1541
  %1570 = call float @dx.op.unary.f32(i32 6, float %1558)  ; FAbs(value)
  %1571 = fmul fast float %1570, %11
  %1572 = fcmp fast olt float %1571, 0x3F50624DE0000000
  br i1 %1572, label %1573, label %1576

; <label>:1573                                    ; preds = %1569
  %1574 = fmul fast float %1571, 5.000000e-01
  %1575 = fsub fast float 1.000000e+00, %1574
  br label %1581

; <label>:1576                                    ; preds = %1569
  %1577 = fmul fast float %1571, 0xBFF7154760000000
  %1578 = call float @dx.op.unary.f32(i32 21, float %1577)  ; Exp(value)
  %1579 = fsub fast float 1.000000e+00, %1578
  %1580 = fdiv fast float %1579, %1571
  br label %1581

; <label>:1581                                    ; preds = %1576, %1573
  %1582 = phi float [ %1575, %1573 ], [ %1580, %1576 ]
  %1583 = call float @dx.op.binary.f32(i32 36, float %1555, float %18)  ; FMin(a,b)
  %1584 = fsub fast float %1583, %10
  %1585 = fmul fast float %11, %1584
  %1586 = fsub fast float -0.000000e+00, %1585
  %1587 = call float @dx.op.binary.f32(i32 35, float %1586, float -4.000000e+01)  ; FMax(a,b)
  %1588 = call float @dx.op.binary.f32(i32 36, float %1587, float 5.000000e+00)  ; FMin(a,b)
  %1589 = fmul fast float %1588, 0x3FF7154760000000
  %1590 = call float @dx.op.unary.f32(i32 21, float %1589)  ; Exp(value)
  %1591 = fmul fast float %1590, %1582
  br label %1592

; <label>:1592                                    ; preds = %1581, %1541
  %1593 = phi float [ %1591, %1581 ], [ 1.000000e+00, %1541 ]
  %1594 = fmul fast float %1567, %16
  %1595 = fmul fast float %1594, %1593
  %1596 = fcmp fast ole float %1565, %9
  %1597 = fcmp fast olt float %1565, 0x3F1A36E2E0000000
  %1598 = or i1 %1596, %1597
  br i1 %1598, label %1645, label %1599

; <label>:1599                                    ; preds = %1592
  %1600 = fdiv fast float %9, %1565
  %1601 = fmul fast float %1600, %1557
  %1602 = fmul fast float %1600, %1558
  %1603 = fmul fast float %1600, %1559
  %1604 = fadd fast float %1601, %17
  %1605 = fadd fast float %1602, %18
  %1606 = fadd fast float %1603, %19
  %1607 = fadd fast float %1604, -9.000000e+02
  %1608 = fadd fast float %1605, -1.500000e+01
  %1609 = fadd fast float %1606, -7.500000e+02
  %1610 = fmul fast float %1607, 0x3F62345680000000
  %1611 = fmul fast float %1608, 0x3F62345680000000
  %1612 = fmul fast float %1609, 0x3F62345680000000
  %1613 = call float @dx.op.dot3.f32(i32 55, float %1610, float %1611, float %1612, float %1610, float %1611, float %1612)  ; Dot3(ax,ay,az,bx,by,bz)
  %1614 = fsub fast float 1.000000e+00, %1613
  %1615 = call float @dx.op.unary.f32(i32 7, float %1614)  ; Saturate(value)
  %1616 = fmul fast float %1615, %1615
  %1617 = fadd fast float %1604, %1554
  %1618 = fadd fast float %1605, %1555
  %1619 = fadd fast float %1606, %1556
  %1620 = fmul fast float %1617, 0x3F52345680000000
  %1621 = fadd fast float %1620, -2.000000e+00
  %1622 = fmul fast float %1618, 0x3F52345680000000
  %1623 = fadd fast float %1622, 0xBFA1111120000000
  %1624 = fmul fast float %1619, 0x3F52345680000000
  %1625 = fadd fast float %1624, 0xBFFAAAAAC0000000
  %1626 = call float @dx.op.dot3.f32(i32 55, float %1621, float %1623, float %1625, float %1621, float %1623, float %1625)  ; Dot3(ax,ay,az,bx,by,bz)
  %1627 = fsub fast float 1.000000e+00, %1626
  %1628 = call float @dx.op.unary.f32(i32 7, float %1627)  ; Saturate(value)
  %1629 = fmul fast float %1628, %1628
  %1630 = fmul fast float %1629, 4.000000e+00
  %1631 = fadd fast float %1630, %1616
  %1632 = fadd fast float %1554, -9.000000e+02
  %1633 = fadd fast float %1555, -1.500000e+01
  %1634 = fadd fast float %1556, -7.500000e+02
  %1635 = fmul fast float %1632, 0x3F62345680000000
  %1636 = fmul fast float %1633, 0x3F62345680000000
  %1637 = fmul fast float %1634, 0x3F62345680000000
  %1638 = call float @dx.op.dot3.f32(i32 55, float %1635, float %1636, float %1637, float %1635, float %1636, float %1637)  ; Dot3(ax,ay,az,bx,by,bz)
  %1639 = fsub fast float 1.000000e+00, %1638
  %1640 = call float @dx.op.unary.f32(i32 7, float %1639)  ; Saturate(value)
  %1641 = fmul fast float %1640, %1640
  %1642 = fadd fast float %1631, %1641
  %1643 = fmul fast float %1566, 0x3F25D867E0000000
  %1644 = fmul fast float %1643, %1642
  br label %1645

; <label>:1645                                    ; preds = %1599, %1592
  %1646 = phi float [ %1644, %1599 ], [ 0.000000e+00, %1592 ]
  %1647 = fadd fast float %1646, %1595
  %1648 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1647)  ; FMin(a,b)
  %1649 = fmul fast float %1648, 0xBFF7154760000000
  %1650 = call float @dx.op.unary.f32(i32 21, float %1649)  ; Exp(value)
  %1651 = fsub fast float 1.000000e+00, %1650
  %1652 = call float @dx.op.binary.f32(i32 36, float %12, float %1651)  ; FMin(a,b)
  %1653 = fsub fast float %13, %1480
  %1654 = fsub fast float %14, %1481
  %1655 = fsub fast float %15, %1482
  %1656 = fmul fast float %1652, %1653
  %1657 = fmul fast float %1652, %1654
  %1658 = fmul fast float %1652, %1655
  %1659 = fadd fast float %1656, %1480
  %1660 = fadd fast float %1657, %1481
  %1661 = fadd fast float %1658, %1482
  br label %1662

; <label>:1662                                    ; preds = %1645, %1524, %1520
  %1663 = phi float [ %1659, %1645 ], [ %1480, %1524 ], [ %1480, %1520 ]
  %1664 = phi float [ %1660, %1645 ], [ %1481, %1524 ], [ %1481, %1520 ]
  %1665 = phi float [ %1661, %1645 ], [ %1482, %1524 ], [ %1482, %1520 ]
  %1666 = fadd fast float %5, 1.000000e+00
  %1667 = fadd fast float %6, 1.000000e+00
  %1668 = fsub fast float 1.000000e+00, %5
  %1669 = fmul fast float %36, %1666
  %1670 = fmul fast float %36, %1667
  %1671 = fmul fast float %36, %1668
  %1672 = fmul fast float %1669, %1663
  %1673 = fmul fast float %1670, %1664
  %1674 = fmul fast float %1671, %1665
  %1675 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1675, label %1701, label %1676

; <label>:1676                                    ; preds = %1662
  %1677 = fmul fast float %1672, 0x4004147AE0000000
  %1678 = fmul fast float %1673, 0x4004147AE0000000
  %1679 = fmul fast float %1674, 0x4004147AE0000000
  %1680 = fadd fast float %1677, 0x3F9EB851E0000000
  %1681 = fadd fast float %1678, 0x3F9EB851E0000000
  %1682 = fadd fast float %1679, 0x3F9EB851E0000000
  %1683 = fmul fast float %1680, %1672
  %1684 = fmul fast float %1681, %1673
  %1685 = fmul fast float %1682, %1674
  %1686 = fmul fast float %1672, 0x400370A3E0000000
  %1687 = fmul fast float %1673, 0x400370A3E0000000
  %1688 = fmul fast float %1674, 0x400370A3E0000000
  %1689 = fadd fast float %1686, 0x3FE2E147A0000000
  %1690 = fadd fast float %1687, 0x3FE2E147A0000000
  %1691 = fadd fast float %1688, 0x3FE2E147A0000000
  %1692 = fmul fast float %1689, %1672
  %1693 = fmul fast float %1690, %1673
  %1694 = fmul fast float %1691, %1674
  %1695 = fadd fast float %1692, 0x3FC1EB8520000000
  %1696 = fadd fast float %1693, 0x3FC1EB8520000000
  %1697 = fadd fast float %1694, 0x3FC1EB8520000000
  %1698 = fdiv fast float %1683, %1695
  %1699 = fdiv fast float %1684, %1696
  %1700 = fdiv fast float %1685, %1697
  br label %1701

; <label>:1701                                    ; preds = %1676, %1662
  %1702 = phi float [ %1698, %1676 ], [ %1672, %1662 ]
  %1703 = phi float [ %1699, %1676 ], [ %1673, %1662 ]
  %1704 = phi float [ %1700, %1676 ], [ %1674, %1662 ]
  %1705 = call float @dx.op.unary.f32(i32 7, float %1702)  ; Saturate(value)
  %1706 = call float @dx.op.unary.f32(i32 7, float %1703)  ; Saturate(value)
  %1707 = call float @dx.op.unary.f32(i32 7, float %1704)  ; Saturate(value)
  %1708 = call float @dx.op.dot3.f32(i32 55, float %1705, float %1706, float %1707, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1709 = fsub fast float %1705, %1708
  %1710 = fsub fast float %1706, %1708
  %1711 = fsub fast float %1707, %1708
  %1712 = fmul fast float %1709, %8
  %1713 = fmul fast float %1710, %8
  %1714 = fmul fast float %1711, %8
  %1715 = fadd fast float %1712, %1708
  %1716 = fadd fast float %1713, %1708
  %1717 = fadd fast float %1714, %1708
  %1718 = call float @dx.op.unary.f32(i32 7, float %1715)  ; Saturate(value)
  %1719 = call float @dx.op.unary.f32(i32 7, float %1716)  ; Saturate(value)
  %1720 = call float @dx.op.unary.f32(i32 7, float %1717)  ; Saturate(value)
  %1721 = fadd fast float %1718, 0xBFC70A3D80000000
  %1722 = fadd fast float %1719, 0xBFC70A3D80000000
  %1723 = fadd fast float %1720, 0xBFC70A3D80000000
  %1724 = fmul fast float %1721, %7
  %1725 = fmul fast float %1722, %7
  %1726 = fmul fast float %1723, %7
  %1727 = fadd fast float %1724, 0x3FC70A3D80000000
  %1728 = fadd fast float %1725, 0x3FC70A3D80000000
  %1729 = fadd fast float %1726, 0x3FC70A3D80000000
  %1730 = call float @dx.op.unary.f32(i32 7, float %1727)  ; Saturate(value)
  %1731 = call float @dx.op.unary.f32(i32 7, float %1728)  ; Saturate(value)
  %1732 = call float @dx.op.unary.f32(i32 7, float %1729)  ; Saturate(value)
  br label %1733

; <label>:1733                                    ; preds = %1701, %1485
  %1734 = phi float [ %1516, %1485 ], [ %1730, %1701 ]
  %1735 = phi float [ %1517, %1485 ], [ %1731, %1701 ]
  %1736 = phi float [ %1518, %1485 ], [ %1732, %1701 ]
  %1737 = phi float [ %1519, %1485 ], [ %1483, %1701 ]
  %1738 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %63, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1739 = extractvalue %dx.types.ResRet.f32 %1738, 0
  %1740 = extractvalue %dx.types.ResRet.f32 %1738, 1
  %1741 = extractvalue %dx.types.ResRet.f32 %1738, 2
  %1742 = extractvalue %dx.types.ResRet.f32 %1738, 3
  %1743 = fcmp fast olt float %1742, 0.000000e+00
  br i1 %1743, label %1744, label %1779

; <label>:1744                                    ; preds = %1733
  %1745 = fcmp fast ogt float %1739, 0x3FA4B5DCC0000000
  %1746 = fcmp fast ogt float %1740, 0x3FA4B5DCC0000000
  %1747 = fcmp fast ogt float %1741, 0x3FA4B5DCC0000000
  %1748 = select i1 %1745, float 0.000000e+00, float 1.000000e+00
  %1749 = select i1 %1746, float 0.000000e+00, float 1.000000e+00
  %1750 = select i1 %1747, float 0.000000e+00, float 1.000000e+00
  %1751 = fmul fast float %1739, 0x3FB3D07220000000
  %1752 = fmul fast float %1740, 0x3FB3D07220000000
  %1753 = fmul fast float %1741, 0x3FB3D07220000000
  %1754 = fadd fast float %1739, 0x3FAC28F5C0000000
  %1755 = fadd fast float %1740, 0x3FAC28F5C0000000
  %1756 = fadd fast float %1741, 0x3FAC28F5C0000000
  %1757 = fmul fast float %1754, 0x3FEE54EDE0000000
  %1758 = fmul fast float %1755, 0x3FEE54EDE0000000
  %1759 = fmul fast float %1756, 0x3FEE54EDE0000000
  %1760 = call float @dx.op.unary.f32(i32 23, float %1757)  ; Log(value)
  %1761 = call float @dx.op.unary.f32(i32 23, float %1758)  ; Log(value)
  %1762 = call float @dx.op.unary.f32(i32 23, float %1759)  ; Log(value)
  %1763 = fmul fast float %1760, 0x4003333340000000
  %1764 = fmul fast float %1761, 0x4003333340000000
  %1765 = fmul fast float %1762, 0x4003333340000000
  %1766 = call float @dx.op.unary.f32(i32 21, float %1763)  ; Exp(value)
  %1767 = call float @dx.op.unary.f32(i32 21, float %1764)  ; Exp(value)
  %1768 = call float @dx.op.unary.f32(i32 21, float %1765)  ; Exp(value)
  %1769 = fsub fast float %1751, %1766
  %1770 = fsub fast float %1752, %1767
  %1771 = fsub fast float %1753, %1768
  %1772 = fmul fast float %1769, %1748
  %1773 = fmul fast float %1770, %1749
  %1774 = fmul fast float %1771, %1750
  %1775 = fadd fast float %1772, %1766
  %1776 = fadd fast float %1773, %1767
  %1777 = fadd fast float %1774, %1768
  %1778 = fsub fast float -1.000000e+00, %1742
  br label %1992

; <label>:1779                                    ; preds = %1733
  %1780 = fcmp fast ogt float %38, 5.000000e-01
  %1781 = fcmp fast olt float %86, 1.000000e+00
  %1782 = and i1 %1780, %1781
  br i1 %1782, label %1783, label %1921

; <label>:1783                                    ; preds = %1779
  %1784 = sitofp i32 %63 to float
  %1785 = sitofp i32 %70 to float
  %1786 = fadd fast float %1784, 5.000000e-01
  %1787 = fadd fast float %1785, 5.000000e-01
  %1788 = fdiv fast float %1786, %45
  %1789 = fdiv fast float %1787, %46
  %1790 = fmul fast float %1788, 2.000000e+00
  %1791 = fmul fast float %1789, 2.000000e+00
  %1792 = fadd fast float %1790, -1.000000e+00
  %1793 = fsub fast float 1.000000e+00, %1791
  %1794 = fmul fast float %1792, %35
  %1795 = call float @dx.op.tertiary.f32(i32 46, float %1793, float %31, float %1794)  ; FMad(a,b,c)
  %1796 = call float @dx.op.tertiary.f32(i32 46, float %86, float %27, float %1795)  ; FMad(a,b,c)
  %1797 = fadd fast float %1796, %23
  %1798 = call float @dx.op.unary.f32(i32 6, float %1797)  ; FAbs(value)
  %1799 = fcmp fast ogt float %1798, 0x3EB0C6F7A0000000
  br i1 %1799, label %1800, label %1921

; <label>:1800                                    ; preds = %1783
  %1801 = fmul fast float %1792, %34
  %1802 = call float @dx.op.tertiary.f32(i32 46, float %1793, float %30, float %1801)  ; FMad(a,b,c)
  %1803 = call float @dx.op.tertiary.f32(i32 46, float %86, float %26, float %1802)  ; FMad(a,b,c)
  %1804 = fadd fast float %1803, %22
  %1805 = fmul fast float %1792, %33
  %1806 = call float @dx.op.tertiary.f32(i32 46, float %1793, float %29, float %1805)  ; FMad(a,b,c)
  %1807 = call float @dx.op.tertiary.f32(i32 46, float %86, float %25, float %1806)  ; FMad(a,b,c)
  %1808 = fadd fast float %1807, %21
  %1809 = fmul fast float %1792, %32
  %1810 = call float @dx.op.tertiary.f32(i32 46, float %1793, float %28, float %1809)  ; FMad(a,b,c)
  %1811 = call float @dx.op.tertiary.f32(i32 46, float %86, float %24, float %1810)  ; FMad(a,b,c)
  %1812 = fadd fast float %1811, %20
  %1813 = fdiv fast float %1812, %1797
  %1814 = fdiv fast float %1808, %1797
  %1815 = fdiv fast float %1804, %1797
  %1816 = fsub fast float %1813, %17
  %1817 = fsub fast float %1814, %18
  %1818 = fsub fast float %1815, %19
  %1819 = fmul fast float %1816, %1816
  %1820 = fmul fast float %1817, %1817
  %1821 = fadd fast float %1820, %1819
  %1822 = fmul fast float %1818, %1818
  %1823 = fadd fast float %1821, %1822
  %1824 = call float @dx.op.unary.f32(i32 24, float %1823)  ; Sqrt(value)
  %1825 = fsub fast float %1824, %9
  %1826 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1825)  ; FMax(a,b)
  %1827 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1827, label %1828, label %1851

; <label>:1828                                    ; preds = %1800
  %1829 = call float @dx.op.unary.f32(i32 6, float %1817)  ; FAbs(value)
  %1830 = fmul fast float %1829, %11
  %1831 = fcmp fast olt float %1830, 0x3F50624DE0000000
  br i1 %1831, label %1832, label %1835

; <label>:1832                                    ; preds = %1828
  %1833 = fmul fast float %1830, 5.000000e-01
  %1834 = fsub fast float 1.000000e+00, %1833
  br label %1840

; <label>:1835                                    ; preds = %1828
  %1836 = fmul fast float %1830, 0xBFF7154760000000
  %1837 = call float @dx.op.unary.f32(i32 21, float %1836)  ; Exp(value)
  %1838 = fsub fast float 1.000000e+00, %1837
  %1839 = fdiv fast float %1838, %1830
  br label %1840

; <label>:1840                                    ; preds = %1835, %1832
  %1841 = phi float [ %1834, %1832 ], [ %1839, %1835 ]
  %1842 = call float @dx.op.binary.f32(i32 36, float %1814, float %18)  ; FMin(a,b)
  %1843 = fsub fast float %1842, %10
  %1844 = fmul fast float %11, %1843
  %1845 = fsub fast float -0.000000e+00, %1844
  %1846 = call float @dx.op.binary.f32(i32 35, float %1845, float -4.000000e+01)  ; FMax(a,b)
  %1847 = call float @dx.op.binary.f32(i32 36, float %1846, float 5.000000e+00)  ; FMin(a,b)
  %1848 = fmul fast float %1847, 0x3FF7154760000000
  %1849 = call float @dx.op.unary.f32(i32 21, float %1848)  ; Exp(value)
  %1850 = fmul fast float %1849, %1841
  br label %1851

; <label>:1851                                    ; preds = %1840, %1800
  %1852 = phi float [ %1850, %1840 ], [ 1.000000e+00, %1800 ]
  %1853 = fmul fast float %1826, %16
  %1854 = fmul fast float %1853, %1852
  %1855 = fcmp fast ole float %1824, %9
  %1856 = fcmp fast olt float %1824, 0x3F1A36E2E0000000
  %1857 = or i1 %1855, %1856
  br i1 %1857, label %1904, label %1858

; <label>:1858                                    ; preds = %1851
  %1859 = fdiv fast float %9, %1824
  %1860 = fmul fast float %1859, %1816
  %1861 = fmul fast float %1859, %1817
  %1862 = fmul fast float %1859, %1818
  %1863 = fadd fast float %1860, %17
  %1864 = fadd fast float %1861, %18
  %1865 = fadd fast float %1862, %19
  %1866 = fadd fast float %1863, -9.000000e+02
  %1867 = fadd fast float %1864, -1.500000e+01
  %1868 = fadd fast float %1865, -7.500000e+02
  %1869 = fmul fast float %1866, 0x3F62345680000000
  %1870 = fmul fast float %1867, 0x3F62345680000000
  %1871 = fmul fast float %1868, 0x3F62345680000000
  %1872 = call float @dx.op.dot3.f32(i32 55, float %1869, float %1870, float %1871, float %1869, float %1870, float %1871)  ; Dot3(ax,ay,az,bx,by,bz)
  %1873 = fsub fast float 1.000000e+00, %1872
  %1874 = call float @dx.op.unary.f32(i32 7, float %1873)  ; Saturate(value)
  %1875 = fmul fast float %1874, %1874
  %1876 = fadd fast float %1863, %1813
  %1877 = fadd fast float %1864, %1814
  %1878 = fadd fast float %1865, %1815
  %1879 = fmul fast float %1876, 0x3F52345680000000
  %1880 = fadd fast float %1879, -2.000000e+00
  %1881 = fmul fast float %1877, 0x3F52345680000000
  %1882 = fadd fast float %1881, 0xBFA1111120000000
  %1883 = fmul fast float %1878, 0x3F52345680000000
  %1884 = fadd fast float %1883, 0xBFFAAAAAC0000000
  %1885 = call float @dx.op.dot3.f32(i32 55, float %1880, float %1882, float %1884, float %1880, float %1882, float %1884)  ; Dot3(ax,ay,az,bx,by,bz)
  %1886 = fsub fast float 1.000000e+00, %1885
  %1887 = call float @dx.op.unary.f32(i32 7, float %1886)  ; Saturate(value)
  %1888 = fmul fast float %1887, %1887
  %1889 = fmul fast float %1888, 4.000000e+00
  %1890 = fadd fast float %1889, %1875
  %1891 = fadd fast float %1813, -9.000000e+02
  %1892 = fadd fast float %1814, -1.500000e+01
  %1893 = fadd fast float %1815, -7.500000e+02
  %1894 = fmul fast float %1891, 0x3F62345680000000
  %1895 = fmul fast float %1892, 0x3F62345680000000
  %1896 = fmul fast float %1893, 0x3F62345680000000
  %1897 = call float @dx.op.dot3.f32(i32 55, float %1894, float %1895, float %1896, float %1894, float %1895, float %1896)  ; Dot3(ax,ay,az,bx,by,bz)
  %1898 = fsub fast float 1.000000e+00, %1897
  %1899 = call float @dx.op.unary.f32(i32 7, float %1898)  ; Saturate(value)
  %1900 = fmul fast float %1899, %1899
  %1901 = fadd fast float %1890, %1900
  %1902 = fmul fast float %1825, 0x3F25D867E0000000
  %1903 = fmul fast float %1902, %1901
  br label %1904

; <label>:1904                                    ; preds = %1858, %1851
  %1905 = phi float [ %1903, %1858 ], [ 0.000000e+00, %1851 ]
  %1906 = fadd fast float %1905, %1854
  %1907 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1906)  ; FMin(a,b)
  %1908 = fmul fast float %1907, 0xBFF7154760000000
  %1909 = call float @dx.op.unary.f32(i32 21, float %1908)  ; Exp(value)
  %1910 = fsub fast float 1.000000e+00, %1909
  %1911 = call float @dx.op.binary.f32(i32 36, float %12, float %1910)  ; FMin(a,b)
  %1912 = fsub fast float %13, %1739
  %1913 = fsub fast float %14, %1740
  %1914 = fsub fast float %15, %1741
  %1915 = fmul fast float %1911, %1912
  %1916 = fmul fast float %1911, %1913
  %1917 = fmul fast float %1911, %1914
  %1918 = fadd fast float %1915, %1739
  %1919 = fadd fast float %1916, %1740
  %1920 = fadd fast float %1917, %1741
  br label %1921

; <label>:1921                                    ; preds = %1904, %1783, %1779
  %1922 = phi float [ %1918, %1904 ], [ %1739, %1783 ], [ %1739, %1779 ]
  %1923 = phi float [ %1919, %1904 ], [ %1740, %1783 ], [ %1740, %1779 ]
  %1924 = phi float [ %1920, %1904 ], [ %1741, %1783 ], [ %1741, %1779 ]
  %1925 = fadd fast float %5, 1.000000e+00
  %1926 = fadd fast float %6, 1.000000e+00
  %1927 = fsub fast float 1.000000e+00, %5
  %1928 = fmul fast float %36, %1925
  %1929 = fmul fast float %36, %1926
  %1930 = fmul fast float %36, %1927
  %1931 = fmul fast float %1928, %1922
  %1932 = fmul fast float %1929, %1923
  %1933 = fmul fast float %1930, %1924
  %1934 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1934, label %1960, label %1935

; <label>:1935                                    ; preds = %1921
  %1936 = fmul fast float %1931, 0x4004147AE0000000
  %1937 = fmul fast float %1932, 0x4004147AE0000000
  %1938 = fmul fast float %1933, 0x4004147AE0000000
  %1939 = fadd fast float %1936, 0x3F9EB851E0000000
  %1940 = fadd fast float %1937, 0x3F9EB851E0000000
  %1941 = fadd fast float %1938, 0x3F9EB851E0000000
  %1942 = fmul fast float %1939, %1931
  %1943 = fmul fast float %1940, %1932
  %1944 = fmul fast float %1941, %1933
  %1945 = fmul fast float %1931, 0x400370A3E0000000
  %1946 = fmul fast float %1932, 0x400370A3E0000000
  %1947 = fmul fast float %1933, 0x400370A3E0000000
  %1948 = fadd fast float %1945, 0x3FE2E147A0000000
  %1949 = fadd fast float %1946, 0x3FE2E147A0000000
  %1950 = fadd fast float %1947, 0x3FE2E147A0000000
  %1951 = fmul fast float %1948, %1931
  %1952 = fmul fast float %1949, %1932
  %1953 = fmul fast float %1950, %1933
  %1954 = fadd fast float %1951, 0x3FC1EB8520000000
  %1955 = fadd fast float %1952, 0x3FC1EB8520000000
  %1956 = fadd fast float %1953, 0x3FC1EB8520000000
  %1957 = fdiv fast float %1942, %1954
  %1958 = fdiv fast float %1943, %1955
  %1959 = fdiv fast float %1944, %1956
  br label %1960

; <label>:1960                                    ; preds = %1935, %1921
  %1961 = phi float [ %1957, %1935 ], [ %1931, %1921 ]
  %1962 = phi float [ %1958, %1935 ], [ %1932, %1921 ]
  %1963 = phi float [ %1959, %1935 ], [ %1933, %1921 ]
  %1964 = call float @dx.op.unary.f32(i32 7, float %1961)  ; Saturate(value)
  %1965 = call float @dx.op.unary.f32(i32 7, float %1962)  ; Saturate(value)
  %1966 = call float @dx.op.unary.f32(i32 7, float %1963)  ; Saturate(value)
  %1967 = call float @dx.op.dot3.f32(i32 55, float %1964, float %1965, float %1966, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1968 = fsub fast float %1964, %1967
  %1969 = fsub fast float %1965, %1967
  %1970 = fsub fast float %1966, %1967
  %1971 = fmul fast float %1968, %8
  %1972 = fmul fast float %1969, %8
  %1973 = fmul fast float %1970, %8
  %1974 = fadd fast float %1971, %1967
  %1975 = fadd fast float %1972, %1967
  %1976 = fadd fast float %1973, %1967
  %1977 = call float @dx.op.unary.f32(i32 7, float %1974)  ; Saturate(value)
  %1978 = call float @dx.op.unary.f32(i32 7, float %1975)  ; Saturate(value)
  %1979 = call float @dx.op.unary.f32(i32 7, float %1976)  ; Saturate(value)
  %1980 = fadd fast float %1977, 0xBFC70A3D80000000
  %1981 = fadd fast float %1978, 0xBFC70A3D80000000
  %1982 = fadd fast float %1979, 0xBFC70A3D80000000
  %1983 = fmul fast float %1980, %7
  %1984 = fmul fast float %1981, %7
  %1985 = fmul fast float %1982, %7
  %1986 = fadd fast float %1983, 0x3FC70A3D80000000
  %1987 = fadd fast float %1984, 0x3FC70A3D80000000
  %1988 = fadd fast float %1985, 0x3FC70A3D80000000
  %1989 = call float @dx.op.unary.f32(i32 7, float %1986)  ; Saturate(value)
  %1990 = call float @dx.op.unary.f32(i32 7, float %1987)  ; Saturate(value)
  %1991 = call float @dx.op.unary.f32(i32 7, float %1988)  ; Saturate(value)
  br label %1992

; <label>:1992                                    ; preds = %1960, %1744
  %1993 = phi float [ %1775, %1744 ], [ %1989, %1960 ]
  %1994 = phi float [ %1776, %1744 ], [ %1990, %1960 ]
  %1995 = phi float [ %1777, %1744 ], [ %1991, %1960 ]
  %1996 = phi float [ %1778, %1744 ], [ %1742, %1960 ]
  %1997 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %67, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1998 = extractvalue %dx.types.ResRet.f32 %1997, 0
  %1999 = extractvalue %dx.types.ResRet.f32 %1997, 1
  %2000 = extractvalue %dx.types.ResRet.f32 %1997, 2
  %2001 = extractvalue %dx.types.ResRet.f32 %1997, 3
  %2002 = fcmp fast olt float %2001, 0.000000e+00
  br i1 %2002, label %2003, label %2038

; <label>:2003                                    ; preds = %1992
  %2004 = fcmp fast ogt float %1998, 0x3FA4B5DCC0000000
  %2005 = fcmp fast ogt float %1999, 0x3FA4B5DCC0000000
  %2006 = fcmp fast ogt float %2000, 0x3FA4B5DCC0000000
  %2007 = select i1 %2004, float 0.000000e+00, float 1.000000e+00
  %2008 = select i1 %2005, float 0.000000e+00, float 1.000000e+00
  %2009 = select i1 %2006, float 0.000000e+00, float 1.000000e+00
  %2010 = fmul fast float %1998, 0x3FB3D07220000000
  %2011 = fmul fast float %1999, 0x3FB3D07220000000
  %2012 = fmul fast float %2000, 0x3FB3D07220000000
  %2013 = fadd fast float %1998, 0x3FAC28F5C0000000
  %2014 = fadd fast float %1999, 0x3FAC28F5C0000000
  %2015 = fadd fast float %2000, 0x3FAC28F5C0000000
  %2016 = fmul fast float %2013, 0x3FEE54EDE0000000
  %2017 = fmul fast float %2014, 0x3FEE54EDE0000000
  %2018 = fmul fast float %2015, 0x3FEE54EDE0000000
  %2019 = call float @dx.op.unary.f32(i32 23, float %2016)  ; Log(value)
  %2020 = call float @dx.op.unary.f32(i32 23, float %2017)  ; Log(value)
  %2021 = call float @dx.op.unary.f32(i32 23, float %2018)  ; Log(value)
  %2022 = fmul fast float %2019, 0x4003333340000000
  %2023 = fmul fast float %2020, 0x4003333340000000
  %2024 = fmul fast float %2021, 0x4003333340000000
  %2025 = call float @dx.op.unary.f32(i32 21, float %2022)  ; Exp(value)
  %2026 = call float @dx.op.unary.f32(i32 21, float %2023)  ; Exp(value)
  %2027 = call float @dx.op.unary.f32(i32 21, float %2024)  ; Exp(value)
  %2028 = fsub fast float %2010, %2025
  %2029 = fsub fast float %2011, %2026
  %2030 = fsub fast float %2012, %2027
  %2031 = fmul fast float %2028, %2007
  %2032 = fmul fast float %2029, %2008
  %2033 = fmul fast float %2030, %2009
  %2034 = fadd fast float %2031, %2025
  %2035 = fadd fast float %2032, %2026
  %2036 = fadd fast float %2033, %2027
  %2037 = fsub fast float -1.000000e+00, %2001
  br label %2251

; <label>:2038                                    ; preds = %1992
  %2039 = fcmp fast ogt float %38, 5.000000e-01
  %2040 = fcmp fast olt float %88, 1.000000e+00
  %2041 = and i1 %2039, %2040
  br i1 %2041, label %2042, label %2180

; <label>:2042                                    ; preds = %2038
  %2043 = sitofp i32 %67 to float
  %2044 = sitofp i32 %70 to float
  %2045 = fadd fast float %2043, 5.000000e-01
  %2046 = fadd fast float %2044, 5.000000e-01
  %2047 = fdiv fast float %2045, %45
  %2048 = fdiv fast float %2046, %46
  %2049 = fmul fast float %2047, 2.000000e+00
  %2050 = fmul fast float %2048, 2.000000e+00
  %2051 = fadd fast float %2049, -1.000000e+00
  %2052 = fsub fast float 1.000000e+00, %2050
  %2053 = fmul fast float %2051, %35
  %2054 = call float @dx.op.tertiary.f32(i32 46, float %2052, float %31, float %2053)  ; FMad(a,b,c)
  %2055 = call float @dx.op.tertiary.f32(i32 46, float %88, float %27, float %2054)  ; FMad(a,b,c)
  %2056 = fadd fast float %2055, %23
  %2057 = call float @dx.op.unary.f32(i32 6, float %2056)  ; FAbs(value)
  %2058 = fcmp fast ogt float %2057, 0x3EB0C6F7A0000000
  br i1 %2058, label %2059, label %2180

; <label>:2059                                    ; preds = %2042
  %2060 = fmul fast float %2051, %34
  %2061 = call float @dx.op.tertiary.f32(i32 46, float %2052, float %30, float %2060)  ; FMad(a,b,c)
  %2062 = call float @dx.op.tertiary.f32(i32 46, float %88, float %26, float %2061)  ; FMad(a,b,c)
  %2063 = fadd fast float %2062, %22
  %2064 = fmul fast float %2051, %33
  %2065 = call float @dx.op.tertiary.f32(i32 46, float %2052, float %29, float %2064)  ; FMad(a,b,c)
  %2066 = call float @dx.op.tertiary.f32(i32 46, float %88, float %25, float %2065)  ; FMad(a,b,c)
  %2067 = fadd fast float %2066, %21
  %2068 = fmul fast float %2051, %32
  %2069 = call float @dx.op.tertiary.f32(i32 46, float %2052, float %28, float %2068)  ; FMad(a,b,c)
  %2070 = call float @dx.op.tertiary.f32(i32 46, float %88, float %24, float %2069)  ; FMad(a,b,c)
  %2071 = fadd fast float %2070, %20
  %2072 = fdiv fast float %2071, %2056
  %2073 = fdiv fast float %2067, %2056
  %2074 = fdiv fast float %2063, %2056
  %2075 = fsub fast float %2072, %17
  %2076 = fsub fast float %2073, %18
  %2077 = fsub fast float %2074, %19
  %2078 = fmul fast float %2075, %2075
  %2079 = fmul fast float %2076, %2076
  %2080 = fadd fast float %2079, %2078
  %2081 = fmul fast float %2077, %2077
  %2082 = fadd fast float %2080, %2081
  %2083 = call float @dx.op.unary.f32(i32 24, float %2082)  ; Sqrt(value)
  %2084 = fsub fast float %2083, %9
  %2085 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2084)  ; FMax(a,b)
  %2086 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %2086, label %2087, label %2110

; <label>:2087                                    ; preds = %2059
  %2088 = call float @dx.op.unary.f32(i32 6, float %2076)  ; FAbs(value)
  %2089 = fmul fast float %2088, %11
  %2090 = fcmp fast olt float %2089, 0x3F50624DE0000000
  br i1 %2090, label %2091, label %2094

; <label>:2091                                    ; preds = %2087
  %2092 = fmul fast float %2089, 5.000000e-01
  %2093 = fsub fast float 1.000000e+00, %2092
  br label %2099

; <label>:2094                                    ; preds = %2087
  %2095 = fmul fast float %2089, 0xBFF7154760000000
  %2096 = call float @dx.op.unary.f32(i32 21, float %2095)  ; Exp(value)
  %2097 = fsub fast float 1.000000e+00, %2096
  %2098 = fdiv fast float %2097, %2089
  br label %2099

; <label>:2099                                    ; preds = %2094, %2091
  %2100 = phi float [ %2093, %2091 ], [ %2098, %2094 ]
  %2101 = call float @dx.op.binary.f32(i32 36, float %2073, float %18)  ; FMin(a,b)
  %2102 = fsub fast float %2101, %10
  %2103 = fmul fast float %11, %2102
  %2104 = fsub fast float -0.000000e+00, %2103
  %2105 = call float @dx.op.binary.f32(i32 35, float %2104, float -4.000000e+01)  ; FMax(a,b)
  %2106 = call float @dx.op.binary.f32(i32 36, float %2105, float 5.000000e+00)  ; FMin(a,b)
  %2107 = fmul fast float %2106, 0x3FF7154760000000
  %2108 = call float @dx.op.unary.f32(i32 21, float %2107)  ; Exp(value)
  %2109 = fmul fast float %2108, %2100
  br label %2110

; <label>:2110                                    ; preds = %2099, %2059
  %2111 = phi float [ %2109, %2099 ], [ 1.000000e+00, %2059 ]
  %2112 = fmul fast float %2085, %16
  %2113 = fmul fast float %2112, %2111
  %2114 = fcmp fast ole float %2083, %9
  %2115 = fcmp fast olt float %2083, 0x3F1A36E2E0000000
  %2116 = or i1 %2114, %2115
  br i1 %2116, label %2163, label %2117

; <label>:2117                                    ; preds = %2110
  %2118 = fdiv fast float %9, %2083
  %2119 = fmul fast float %2118, %2075
  %2120 = fmul fast float %2118, %2076
  %2121 = fmul fast float %2118, %2077
  %2122 = fadd fast float %2119, %17
  %2123 = fadd fast float %2120, %18
  %2124 = fadd fast float %2121, %19
  %2125 = fadd fast float %2122, -9.000000e+02
  %2126 = fadd fast float %2123, -1.500000e+01
  %2127 = fadd fast float %2124, -7.500000e+02
  %2128 = fmul fast float %2125, 0x3F62345680000000
  %2129 = fmul fast float %2126, 0x3F62345680000000
  %2130 = fmul fast float %2127, 0x3F62345680000000
  %2131 = call float @dx.op.dot3.f32(i32 55, float %2128, float %2129, float %2130, float %2128, float %2129, float %2130)  ; Dot3(ax,ay,az,bx,by,bz)
  %2132 = fsub fast float 1.000000e+00, %2131
  %2133 = call float @dx.op.unary.f32(i32 7, float %2132)  ; Saturate(value)
  %2134 = fmul fast float %2133, %2133
  %2135 = fadd fast float %2122, %2072
  %2136 = fadd fast float %2123, %2073
  %2137 = fadd fast float %2124, %2074
  %2138 = fmul fast float %2135, 0x3F52345680000000
  %2139 = fadd fast float %2138, -2.000000e+00
  %2140 = fmul fast float %2136, 0x3F52345680000000
  %2141 = fadd fast float %2140, 0xBFA1111120000000
  %2142 = fmul fast float %2137, 0x3F52345680000000
  %2143 = fadd fast float %2142, 0xBFFAAAAAC0000000
  %2144 = call float @dx.op.dot3.f32(i32 55, float %2139, float %2141, float %2143, float %2139, float %2141, float %2143)  ; Dot3(ax,ay,az,bx,by,bz)
  %2145 = fsub fast float 1.000000e+00, %2144
  %2146 = call float @dx.op.unary.f32(i32 7, float %2145)  ; Saturate(value)
  %2147 = fmul fast float %2146, %2146
  %2148 = fmul fast float %2147, 4.000000e+00
  %2149 = fadd fast float %2148, %2134
  %2150 = fadd fast float %2072, -9.000000e+02
  %2151 = fadd fast float %2073, -1.500000e+01
  %2152 = fadd fast float %2074, -7.500000e+02
  %2153 = fmul fast float %2150, 0x3F62345680000000
  %2154 = fmul fast float %2151, 0x3F62345680000000
  %2155 = fmul fast float %2152, 0x3F62345680000000
  %2156 = call float @dx.op.dot3.f32(i32 55, float %2153, float %2154, float %2155, float %2153, float %2154, float %2155)  ; Dot3(ax,ay,az,bx,by,bz)
  %2157 = fsub fast float 1.000000e+00, %2156
  %2158 = call float @dx.op.unary.f32(i32 7, float %2157)  ; Saturate(value)
  %2159 = fmul fast float %2158, %2158
  %2160 = fadd fast float %2149, %2159
  %2161 = fmul fast float %2084, 0x3F25D867E0000000
  %2162 = fmul fast float %2161, %2160
  br label %2163

; <label>:2163                                    ; preds = %2117, %2110
  %2164 = phi float [ %2162, %2117 ], [ 0.000000e+00, %2110 ]
  %2165 = fadd fast float %2164, %2113
  %2166 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2165)  ; FMin(a,b)
  %2167 = fmul fast float %2166, 0xBFF7154760000000
  %2168 = call float @dx.op.unary.f32(i32 21, float %2167)  ; Exp(value)
  %2169 = fsub fast float 1.000000e+00, %2168
  %2170 = call float @dx.op.binary.f32(i32 36, float %12, float %2169)  ; FMin(a,b)
  %2171 = fsub fast float %13, %1998
  %2172 = fsub fast float %14, %1999
  %2173 = fsub fast float %15, %2000
  %2174 = fmul fast float %2170, %2171
  %2175 = fmul fast float %2170, %2172
  %2176 = fmul fast float %2170, %2173
  %2177 = fadd fast float %2174, %1998
  %2178 = fadd fast float %2175, %1999
  %2179 = fadd fast float %2176, %2000
  br label %2180

; <label>:2180                                    ; preds = %2163, %2042, %2038
  %2181 = phi float [ %2177, %2163 ], [ %1998, %2042 ], [ %1998, %2038 ]
  %2182 = phi float [ %2178, %2163 ], [ %1999, %2042 ], [ %1999, %2038 ]
  %2183 = phi float [ %2179, %2163 ], [ %2000, %2042 ], [ %2000, %2038 ]
  %2184 = fadd fast float %5, 1.000000e+00
  %2185 = fadd fast float %6, 1.000000e+00
  %2186 = fsub fast float 1.000000e+00, %5
  %2187 = fmul fast float %36, %2184
  %2188 = fmul fast float %36, %2185
  %2189 = fmul fast float %36, %2186
  %2190 = fmul fast float %2187, %2181
  %2191 = fmul fast float %2188, %2182
  %2192 = fmul fast float %2189, %2183
  %2193 = fcmp fast ult float %37, 5.000000e-01
  br i1 %2193, label %2219, label %2194

; <label>:2194                                    ; preds = %2180
  %2195 = fmul fast float %2190, 0x4004147AE0000000
  %2196 = fmul fast float %2191, 0x4004147AE0000000
  %2197 = fmul fast float %2192, 0x4004147AE0000000
  %2198 = fadd fast float %2195, 0x3F9EB851E0000000
  %2199 = fadd fast float %2196, 0x3F9EB851E0000000
  %2200 = fadd fast float %2197, 0x3F9EB851E0000000
  %2201 = fmul fast float %2198, %2190
  %2202 = fmul fast float %2199, %2191
  %2203 = fmul fast float %2200, %2192
  %2204 = fmul fast float %2190, 0x400370A3E0000000
  %2205 = fmul fast float %2191, 0x400370A3E0000000
  %2206 = fmul fast float %2192, 0x400370A3E0000000
  %2207 = fadd fast float %2204, 0x3FE2E147A0000000
  %2208 = fadd fast float %2205, 0x3FE2E147A0000000
  %2209 = fadd fast float %2206, 0x3FE2E147A0000000
  %2210 = fmul fast float %2207, %2190
  %2211 = fmul fast float %2208, %2191
  %2212 = fmul fast float %2209, %2192
  %2213 = fadd fast float %2210, 0x3FC1EB8520000000
  %2214 = fadd fast float %2211, 0x3FC1EB8520000000
  %2215 = fadd fast float %2212, 0x3FC1EB8520000000
  %2216 = fdiv fast float %2201, %2213
  %2217 = fdiv fast float %2202, %2214
  %2218 = fdiv fast float %2203, %2215
  br label %2219

; <label>:2219                                    ; preds = %2194, %2180
  %2220 = phi float [ %2216, %2194 ], [ %2190, %2180 ]
  %2221 = phi float [ %2217, %2194 ], [ %2191, %2180 ]
  %2222 = phi float [ %2218, %2194 ], [ %2192, %2180 ]
  %2223 = call float @dx.op.unary.f32(i32 7, float %2220)  ; Saturate(value)
  %2224 = call float @dx.op.unary.f32(i32 7, float %2221)  ; Saturate(value)
  %2225 = call float @dx.op.unary.f32(i32 7, float %2222)  ; Saturate(value)
  %2226 = call float @dx.op.dot3.f32(i32 55, float %2223, float %2224, float %2225, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2227 = fsub fast float %2223, %2226
  %2228 = fsub fast float %2224, %2226
  %2229 = fsub fast float %2225, %2226
  %2230 = fmul fast float %2227, %8
  %2231 = fmul fast float %2228, %8
  %2232 = fmul fast float %2229, %8
  %2233 = fadd fast float %2230, %2226
  %2234 = fadd fast float %2231, %2226
  %2235 = fadd fast float %2232, %2226
  %2236 = call float @dx.op.unary.f32(i32 7, float %2233)  ; Saturate(value)
  %2237 = call float @dx.op.unary.f32(i32 7, float %2234)  ; Saturate(value)
  %2238 = call float @dx.op.unary.f32(i32 7, float %2235)  ; Saturate(value)
  %2239 = fadd fast float %2236, 0xBFC70A3D80000000
  %2240 = fadd fast float %2237, 0xBFC70A3D80000000
  %2241 = fadd fast float %2238, 0xBFC70A3D80000000
  %2242 = fmul fast float %2239, %7
  %2243 = fmul fast float %2240, %7
  %2244 = fmul fast float %2241, %7
  %2245 = fadd fast float %2242, 0x3FC70A3D80000000
  %2246 = fadd fast float %2243, 0x3FC70A3D80000000
  %2247 = fadd fast float %2244, 0x3FC70A3D80000000
  %2248 = call float @dx.op.unary.f32(i32 7, float %2245)  ; Saturate(value)
  %2249 = call float @dx.op.unary.f32(i32 7, float %2246)  ; Saturate(value)
  %2250 = call float @dx.op.unary.f32(i32 7, float %2247)  ; Saturate(value)
  br label %2251

; <label>:2251                                    ; preds = %2219, %2003, %1207
  %2252 = phi float [ %1475, %2003 ], [ %446, %1207 ], [ %1475, %2219 ]
  %2253 = phi float [ %1476, %2003 ], [ %447, %1207 ], [ %1476, %2219 ]
  %2254 = phi float [ %1477, %2003 ], [ %448, %1207 ], [ %1477, %2219 ]
  %2255 = phi float [ %1478, %2003 ], [ %1212, %1207 ], [ %1478, %2219 ]
  %2256 = phi float [ %1734, %2003 ], [ %700, %1207 ], [ %1734, %2219 ]
  %2257 = phi float [ %1735, %2003 ], [ %701, %1207 ], [ %1735, %2219 ]
  %2258 = phi float [ %1736, %2003 ], [ %702, %1207 ], [ %1736, %2219 ]
  %2259 = phi float [ %1737, %2003 ], [ %1214, %1207 ], [ %1737, %2219 ]
  %2260 = phi float [ %1993, %2003 ], [ %954, %1207 ], [ %1993, %2219 ]
  %2261 = phi float [ %1994, %2003 ], [ %955, %1207 ], [ %1994, %2219 ]
  %2262 = phi float [ %1995, %2003 ], [ %956, %1207 ], [ %1995, %2219 ]
  %2263 = phi float [ %1996, %2003 ], [ %1216, %1207 ], [ %1996, %2219 ]
  %2264 = phi float [ %2034, %2003 ], [ %1208, %1207 ], [ %2248, %2219 ]
  %2265 = phi float [ %2035, %2003 ], [ %1209, %1207 ], [ %2249, %2219 ]
  %2266 = phi float [ %2036, %2003 ], [ %1210, %1207 ], [ %2250, %2219 ]
  %2267 = phi float [ %2037, %2003 ], [ %1218, %1207 ], [ %2001, %2219 ]
  %2268 = fmul fast float %2252, %162
  %2269 = fmul fast float %2253, %162
  %2270 = fmul fast float %2254, %162
  %2271 = fmul fast float %2256, %163
  %2272 = fmul fast float %2257, %163
  %2273 = fmul fast float %2258, %163
  %2274 = fadd fast float %2271, %2268
  %2275 = fadd fast float %2272, %2269
  %2276 = fadd fast float %2273, %2270
  %2277 = fmul fast float %2260, %164
  %2278 = fmul fast float %2261, %164
  %2279 = fmul fast float %2262, %164
  %2280 = fadd fast float %2274, %2277
  %2281 = fadd fast float %2275, %2278
  %2282 = fadd fast float %2276, %2279
  %2283 = fmul fast float %2264, %165
  %2284 = fmul fast float %2265, %165
  %2285 = fmul fast float %2266, %165
  %2286 = fadd fast float %2280, %2283
  %2287 = fadd fast float %2281, %2284
  %2288 = fadd fast float %2282, %2285
  %2289 = fcmp fast ogt float %2286, 0x3F69A5C380000000
  %2290 = fcmp fast ogt float %2287, 0x3F69A5C380000000
  %2291 = fcmp fast ogt float %2288, 0x3F69A5C380000000
  %2292 = select i1 %2289, float 0.000000e+00, float 1.000000e+00
  %2293 = select i1 %2290, float 0.000000e+00, float 1.000000e+00
  %2294 = select i1 %2291, float 0.000000e+00, float 1.000000e+00
  %2295 = fmul fast float %2286, 0x4029D70A40000000
  %2296 = fmul fast float %2287, 0x4029D70A40000000
  %2297 = fmul fast float %2288, 0x4029D70A40000000
  %2298 = call float @dx.op.binary.f32(i32 35, float %2286, float 0.000000e+00)  ; FMax(a,b)
  %2299 = call float @dx.op.binary.f32(i32 35, float %2287, float 0.000000e+00)  ; FMax(a,b)
  %2300 = call float @dx.op.binary.f32(i32 35, float %2288, float 0.000000e+00)  ; FMax(a,b)
  %2301 = call float @dx.op.unary.f32(i32 23, float %2298)  ; Log(value)
  %2302 = call float @dx.op.unary.f32(i32 23, float %2299)  ; Log(value)
  %2303 = call float @dx.op.unary.f32(i32 23, float %2300)  ; Log(value)
  %2304 = fmul fast float %2301, 0x3FDAAAAAA0000000
  %2305 = fmul fast float %2302, 0x3FDAAAAAA0000000
  %2306 = fmul fast float %2303, 0x3FDAAAAAA0000000
  %2307 = call float @dx.op.unary.f32(i32 21, float %2304)  ; Exp(value)
  %2308 = call float @dx.op.unary.f32(i32 21, float %2305)  ; Exp(value)
  %2309 = call float @dx.op.unary.f32(i32 21, float %2306)  ; Exp(value)
  %2310 = fmul fast float %2307, 0x3FF0E147A0000000
  %2311 = fmul fast float %2308, 0x3FF0E147A0000000
  %2312 = fmul fast float %2309, 0x3FF0E147A0000000
  %2313 = fadd fast float %2310, 0xBFAC28F5C0000000
  %2314 = fadd fast float %2311, 0xBFAC28F5C0000000
  %2315 = fadd fast float %2312, 0xBFAC28F5C0000000
  %2316 = fsub fast float %2295, %2313
  %2317 = fsub fast float %2296, %2314
  %2318 = fsub fast float %2297, %2315
  %2319 = fmul fast float %2316, %2292
  %2320 = fmul fast float %2317, %2293
  %2321 = fmul fast float %2318, %2294
  %2322 = fadd fast float %2319, %2313
  %2323 = fadd fast float %2320, %2314
  %2324 = fadd fast float %2321, %2315
  %2325 = call float @dx.op.dot4.f32(i32 56, float %2255, float %2259, float %2263, float %2267, float %162, float %163, float %164, float %165)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %2322)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %2323)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %2324)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %2325)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %80)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare i1 @dx.op.isSpecialFloat.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !38, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, !37}
!36 = !{i32 9}
!37 = !{i32 3, i32 6}
!38 = !{!39, !40}
!39 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
!40 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !41}
!41 = !{i32 3, i32 1}
