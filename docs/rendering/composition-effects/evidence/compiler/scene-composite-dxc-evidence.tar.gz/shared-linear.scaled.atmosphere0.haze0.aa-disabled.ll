;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xy  
; TEXCOORD                 1   xyzw        2     NONE   float       
; TEXCOORD                 2   xyzw        3     NONE   float       
; TEXCOORD                 3   xyzw        4     NONE   float       
; TEXCOORD                 4   xyzw        5     NONE   float       
; TEXCOORD                 5   xyzw        6     NONE   float       
; TEXCOORD                 6   xyzw        7     NONE   float       
; TEXCOORD                 7   xyzw        8     NONE   float       
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float    yz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: e1f0e273b2770c08561a46e5762f5bb3
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %14 = extractvalue %dx.types.Dimensions %13, 0
  %15 = extractvalue %dx.types.Dimensions %13, 1
  %16 = uitofp i32 %14 to float
  %17 = uitofp i32 %15 to float
  %18 = fmul fast float %16, %11
  %19 = fmul fast float %17, %12
  %20 = fdiv fast float %18, %3
  %21 = fdiv fast float %19, %4
  %22 = fadd fast float %20, -5.000000e-01
  %23 = fadd fast float %21, -5.000000e-01
  %24 = call float @dx.op.unary.f32(i32 27, float %22)  ; Round_ni(value)
  %25 = call float @dx.op.unary.f32(i32 27, float %23)  ; Round_ni(value)
  %26 = fptosi float %24 to i32
  %27 = fptosi float %25 to i32
  %28 = call float @dx.op.unary.f32(i32 22, float %22)  ; Frc(value)
  %29 = call float @dx.op.unary.f32(i32 22, float %23)  ; Frc(value)
  %30 = add i32 %14, -1
  %31 = add i32 %15, -1
  %32 = call i32 @dx.op.binary.i32(i32 37, i32 %26, i32 0)  ; IMax(a,b)
  %33 = call i32 @dx.op.binary.i32(i32 37, i32 %27, i32 0)  ; IMax(a,b)
  %34 = call i32 @dx.op.binary.i32(i32 38, i32 %32, i32 %30)  ; IMin(a,b)
  %35 = call i32 @dx.op.binary.i32(i32 38, i32 %33, i32 %31)  ; IMin(a,b)
  %36 = add i32 %26, 1
  %37 = call i32 @dx.op.binary.i32(i32 37, i32 %36, i32 0)  ; IMax(a,b)
  %38 = call i32 @dx.op.binary.i32(i32 38, i32 %37, i32 %30)  ; IMin(a,b)
  %39 = add i32 %27, 1
  %40 = call i32 @dx.op.binary.i32(i32 37, i32 %39, i32 0)  ; IMax(a,b)
  %41 = call i32 @dx.op.binary.i32(i32 38, i32 %40, i32 %31)  ; IMin(a,b)
  %42 = call float @dx.op.unary.f32(i32 27, float %20)  ; Round_ni(value)
  %43 = call float @dx.op.unary.f32(i32 27, float %21)  ; Round_ni(value)
  %44 = fptosi float %42 to i32
  %45 = fptosi float %43 to i32
  %46 = call i32 @dx.op.binary.i32(i32 37, i32 %44, i32 0)  ; IMax(a,b)
  %47 = call i32 @dx.op.binary.i32(i32 37, i32 %45, i32 0)  ; IMax(a,b)
  %48 = call i32 @dx.op.binary.i32(i32 38, i32 %46, i32 %30)  ; IMin(a,b)
  %49 = call i32 @dx.op.binary.i32(i32 38, i32 %47, i32 %31)  ; IMin(a,b)
  %50 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %48, i32 %49, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %51 = extractvalue %dx.types.ResRet.f32 %50, 0
  %52 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %34, i32 %35, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %53 = extractvalue %dx.types.ResRet.f32 %52, 0
  %54 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %38, i32 %35, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %55 = extractvalue %dx.types.ResRet.f32 %54, 0
  %56 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %34, i32 %41, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %57 = extractvalue %dx.types.ResRet.f32 %56, 0
  %58 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %38, i32 %41, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %59 = extractvalue %dx.types.ResRet.f32 %58, 0
  %60 = fsub fast float 1.000000e+00, %28
  %61 = fsub fast float 1.000000e+00, %29
  %62 = fmul fast float %61, %60
  %63 = fmul fast float %61, %28
  %64 = fmul fast float %60, %29
  %65 = fmul fast float %29, %28
  %66 = fsub fast float 1.000000e+00, %51
  %67 = fmul fast float %66, 0x3FA99999A0000000
  %68 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %67)  ; FMax(a,b)
  %69 = fsub fast float %53, %51
  %70 = call float @dx.op.unary.f32(i32 6, float %69)  ; FAbs(value)
  %71 = fdiv fast float %70, %68
  %72 = fsub fast float 1.000000e+00, %71
  %73 = call float @dx.op.unary.f32(i32 7, float %72)  ; Saturate(value)
  %74 = fsub fast float %55, %51
  %75 = call float @dx.op.unary.f32(i32 6, float %74)  ; FAbs(value)
  %76 = fdiv fast float %75, %68
  %77 = fsub fast float 1.000000e+00, %76
  %78 = call float @dx.op.unary.f32(i32 7, float %77)  ; Saturate(value)
  %79 = fsub fast float %57, %51
  %80 = call float @dx.op.unary.f32(i32 6, float %79)  ; FAbs(value)
  %81 = fdiv fast float %80, %68
  %82 = fsub fast float 1.000000e+00, %81
  %83 = call float @dx.op.unary.f32(i32 7, float %82)  ; Saturate(value)
  %84 = fsub fast float %59, %51
  %85 = call float @dx.op.unary.f32(i32 6, float %84)  ; FAbs(value)
  %86 = fdiv fast float %85, %68
  %87 = fsub fast float 1.000000e+00, %86
  %88 = call float @dx.op.unary.f32(i32 7, float %87)  ; Saturate(value)
  %89 = fmul fast float %62, %73
  %90 = fmul fast float %63, %78
  %91 = fmul fast float %64, %83
  %92 = fmul fast float %65, %88
  %93 = fcmp fast oge float %28, 5.000000e-01
  %94 = zext i1 %93 to i32
  %95 = fcmp fast oge float %29, 5.000000e-01
  %96 = select i1 %95, i32 2, i32 0
  %97 = or i32 %96, %94
  %98 = call float @dx.op.dot4.f32(i32 56, float %89, float %90, float %91, float %92, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %99 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %89)  ; IsFinite(value)
  %100 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %90)  ; IsFinite(value)
  %101 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %91)  ; IsFinite(value)
  %102 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %92)  ; IsFinite(value)
  %103 = and i1 %99, %100
  %104 = and i1 %103, %101
  %105 = and i1 %104, %102
  br i1 %105, label %106, label %123

; <label>:106                                     ; preds = %0
  %107 = fcmp fast oge float %89, 0.000000e+00
  %108 = fcmp fast oge float %90, 0.000000e+00
  %109 = fcmp fast oge float %91, 0.000000e+00
  %110 = fcmp fast oge float %92, 0.000000e+00
  %111 = and i1 %107, %108
  %112 = and i1 %111, %109
  %113 = and i1 %112, %110
  br i1 %113, label %114, label %123

; <label>:114                                     ; preds = %106
  %115 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %98)  ; IsFinite(value)
  %116 = fcmp fast oge float %98, 0x3810000000000000
  %117 = and i1 %116, %115
  br i1 %117, label %118, label %123

; <label>:118                                     ; preds = %114
  %119 = fdiv fast float %89, %98
  %120 = fdiv fast float %90, %98
  %121 = fdiv fast float %91, %98
  %122 = fdiv fast float %92, %98
  br label %132

; <label>:123                                     ; preds = %114, %106, %0
  %124 = icmp eq i32 %97, 0
  %125 = uitofp i1 %124 to float
  %126 = icmp eq i32 %97, 1
  %127 = uitofp i1 %126 to float
  %128 = icmp eq i32 %97, 2
  %129 = uitofp i1 %128 to float
  %130 = icmp eq i32 %97, 3
  %131 = uitofp i1 %130 to float
  br label %132

; <label>:132                                     ; preds = %123, %118
  %133 = phi float [ %119, %118 ], [ %125, %123 ]
  %134 = phi float [ %120, %118 ], [ %127, %123 ]
  %135 = phi float [ %121, %118 ], [ %129, %123 ]
  %136 = phi float [ %122, %118 ], [ %131, %123 ]
  %137 = or i32 %27, %26
  %138 = icmp sgt i32 %137, -1
  br i1 %138, label %139, label %143

; <label>:139                                     ; preds = %132
  %140 = icmp slt i32 %36, %14
  %141 = icmp slt i32 %39, %15
  %142 = and i1 %140, %141
  br label %143

; <label>:143                                     ; preds = %139, %132
  %144 = phi i1 [ false, %132 ], [ %142, %139 ]
  br i1 %144, label %145, label %602

; <label>:145                                     ; preds = %143
  %146 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %26, i32 %27, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %147 = extractvalue %dx.types.ResRet.f32 %146, 0
  %148 = extractvalue %dx.types.ResRet.f32 %146, 1
  %149 = extractvalue %dx.types.ResRet.f32 %146, 2
  %150 = extractvalue %dx.types.ResRet.f32 %146, 3
  %151 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %36, i32 %27, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %152 = extractvalue %dx.types.ResRet.f32 %151, 0
  %153 = extractvalue %dx.types.ResRet.f32 %151, 1
  %154 = extractvalue %dx.types.ResRet.f32 %151, 2
  %155 = extractvalue %dx.types.ResRet.f32 %151, 3
  %156 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %26, i32 %39, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %157 = extractvalue %dx.types.ResRet.f32 %156, 0
  %158 = extractvalue %dx.types.ResRet.f32 %156, 1
  %159 = extractvalue %dx.types.ResRet.f32 %156, 2
  %160 = extractvalue %dx.types.ResRet.f32 %156, 3
  %161 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %36, i32 %39, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %162 = extractvalue %dx.types.ResRet.f32 %161, 0
  %163 = extractvalue %dx.types.ResRet.f32 %161, 1
  %164 = extractvalue %dx.types.ResRet.f32 %161, 2
  %165 = extractvalue %dx.types.ResRet.f32 %161, 3
  %166 = fcmp fast olt float %150, 0.000000e+00
  br i1 %166, label %167, label %201

; <label>:167                                     ; preds = %145
  %168 = fcmp fast ogt float %147, 0x3FA4B5DCC0000000
  %169 = fcmp fast ogt float %148, 0x3FA4B5DCC0000000
  %170 = fcmp fast ogt float %149, 0x3FA4B5DCC0000000
  %171 = select i1 %168, float 0.000000e+00, float 1.000000e+00
  %172 = select i1 %169, float 0.000000e+00, float 1.000000e+00
  %173 = select i1 %170, float 0.000000e+00, float 1.000000e+00
  %174 = fmul fast float %147, 0x3FB3D07220000000
  %175 = fmul fast float %148, 0x3FB3D07220000000
  %176 = fmul fast float %149, 0x3FB3D07220000000
  %177 = fadd fast float %147, 0x3FAC28F5C0000000
  %178 = fadd fast float %148, 0x3FAC28F5C0000000
  %179 = fadd fast float %149, 0x3FAC28F5C0000000
  %180 = fmul fast float %177, 0x3FEE54EDE0000000
  %181 = fmul fast float %178, 0x3FEE54EDE0000000
  %182 = fmul fast float %179, 0x3FEE54EDE0000000
  %183 = call float @dx.op.unary.f32(i32 23, float %180)  ; Log(value)
  %184 = call float @dx.op.unary.f32(i32 23, float %181)  ; Log(value)
  %185 = call float @dx.op.unary.f32(i32 23, float %182)  ; Log(value)
  %186 = fmul fast float %183, 0x4003333340000000
  %187 = fmul fast float %184, 0x4003333340000000
  %188 = fmul fast float %185, 0x4003333340000000
  %189 = call float @dx.op.unary.f32(i32 21, float %186)  ; Exp(value)
  %190 = call float @dx.op.unary.f32(i32 21, float %187)  ; Exp(value)
  %191 = call float @dx.op.unary.f32(i32 21, float %188)  ; Exp(value)
  %192 = fsub fast float %174, %189
  %193 = fsub fast float %175, %190
  %194 = fsub fast float %176, %191
  %195 = fmul fast float %192, %171
  %196 = fmul fast float %193, %172
  %197 = fmul fast float %194, %173
  %198 = fadd fast float %195, %189
  %199 = fadd fast float %196, %190
  %200 = fadd fast float %197, %191
  br label %269

; <label>:201                                     ; preds = %145
  %202 = fadd fast float %5, 1.000000e+00
  %203 = fadd fast float %6, 1.000000e+00
  %204 = fsub fast float 1.000000e+00, %5
  %205 = fmul fast float %9, %202
  %206 = fmul fast float %9, %203
  %207 = fmul fast float %9, %204
  %208 = fmul fast float %205, %147
  %209 = fmul fast float %206, %148
  %210 = fmul fast float %207, %149
  %211 = fcmp fast ult float %10, 5.000000e-01
  br i1 %211, label %237, label %212

; <label>:212                                     ; preds = %201
  %213 = fmul fast float %208, 0x4004147AE0000000
  %214 = fmul fast float %209, 0x4004147AE0000000
  %215 = fmul fast float %210, 0x4004147AE0000000
  %216 = fadd fast float %213, 0x3F9EB851E0000000
  %217 = fadd fast float %214, 0x3F9EB851E0000000
  %218 = fadd fast float %215, 0x3F9EB851E0000000
  %219 = fmul fast float %216, %208
  %220 = fmul fast float %217, %209
  %221 = fmul fast float %218, %210
  %222 = fmul fast float %208, 0x400370A3E0000000
  %223 = fmul fast float %209, 0x400370A3E0000000
  %224 = fmul fast float %210, 0x400370A3E0000000
  %225 = fadd fast float %222, 0x3FE2E147A0000000
  %226 = fadd fast float %223, 0x3FE2E147A0000000
  %227 = fadd fast float %224, 0x3FE2E147A0000000
  %228 = fmul fast float %225, %208
  %229 = fmul fast float %226, %209
  %230 = fmul fast float %227, %210
  %231 = fadd fast float %228, 0x3FC1EB8520000000
  %232 = fadd fast float %229, 0x3FC1EB8520000000
  %233 = fadd fast float %230, 0x3FC1EB8520000000
  %234 = fdiv fast float %219, %231
  %235 = fdiv fast float %220, %232
  %236 = fdiv fast float %221, %233
  br label %237

; <label>:237                                     ; preds = %212, %201
  %238 = phi float [ %234, %212 ], [ %208, %201 ]
  %239 = phi float [ %235, %212 ], [ %209, %201 ]
  %240 = phi float [ %236, %212 ], [ %210, %201 ]
  %241 = call float @dx.op.unary.f32(i32 7, float %238)  ; Saturate(value)
  %242 = call float @dx.op.unary.f32(i32 7, float %239)  ; Saturate(value)
  %243 = call float @dx.op.unary.f32(i32 7, float %240)  ; Saturate(value)
  %244 = call float @dx.op.dot3.f32(i32 55, float %241, float %242, float %243, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %245 = fsub fast float %241, %244
  %246 = fsub fast float %242, %244
  %247 = fsub fast float %243, %244
  %248 = fmul fast float %245, %8
  %249 = fmul fast float %246, %8
  %250 = fmul fast float %247, %8
  %251 = fadd fast float %248, %244
  %252 = fadd fast float %249, %244
  %253 = fadd fast float %250, %244
  %254 = call float @dx.op.unary.f32(i32 7, float %251)  ; Saturate(value)
  %255 = call float @dx.op.unary.f32(i32 7, float %252)  ; Saturate(value)
  %256 = call float @dx.op.unary.f32(i32 7, float %253)  ; Saturate(value)
  %257 = fadd fast float %254, 0xBFC70A3D80000000
  %258 = fadd fast float %255, 0xBFC70A3D80000000
  %259 = fadd fast float %256, 0xBFC70A3D80000000
  %260 = fmul fast float %257, %7
  %261 = fmul fast float %258, %7
  %262 = fmul fast float %259, %7
  %263 = fadd fast float %260, 0x3FC70A3D80000000
  %264 = fadd fast float %261, 0x3FC70A3D80000000
  %265 = fadd fast float %262, 0x3FC70A3D80000000
  %266 = call float @dx.op.unary.f32(i32 7, float %263)  ; Saturate(value)
  %267 = call float @dx.op.unary.f32(i32 7, float %264)  ; Saturate(value)
  %268 = call float @dx.op.unary.f32(i32 7, float %265)  ; Saturate(value)
  br label %269

; <label>:269                                     ; preds = %237, %167
  %270 = phi float [ %198, %167 ], [ %266, %237 ]
  %271 = phi float [ %199, %167 ], [ %267, %237 ]
  %272 = phi float [ %200, %167 ], [ %268, %237 ]
  %273 = fcmp fast olt float %155, 0.000000e+00
  br i1 %273, label %274, label %308

; <label>:274                                     ; preds = %269
  %275 = fcmp fast ogt float %152, 0x3FA4B5DCC0000000
  %276 = fcmp fast ogt float %153, 0x3FA4B5DCC0000000
  %277 = fcmp fast ogt float %154, 0x3FA4B5DCC0000000
  %278 = select i1 %275, float 0.000000e+00, float 1.000000e+00
  %279 = select i1 %276, float 0.000000e+00, float 1.000000e+00
  %280 = select i1 %277, float 0.000000e+00, float 1.000000e+00
  %281 = fmul fast float %152, 0x3FB3D07220000000
  %282 = fmul fast float %153, 0x3FB3D07220000000
  %283 = fmul fast float %154, 0x3FB3D07220000000
  %284 = fadd fast float %152, 0x3FAC28F5C0000000
  %285 = fadd fast float %153, 0x3FAC28F5C0000000
  %286 = fadd fast float %154, 0x3FAC28F5C0000000
  %287 = fmul fast float %284, 0x3FEE54EDE0000000
  %288 = fmul fast float %285, 0x3FEE54EDE0000000
  %289 = fmul fast float %286, 0x3FEE54EDE0000000
  %290 = call float @dx.op.unary.f32(i32 23, float %287)  ; Log(value)
  %291 = call float @dx.op.unary.f32(i32 23, float %288)  ; Log(value)
  %292 = call float @dx.op.unary.f32(i32 23, float %289)  ; Log(value)
  %293 = fmul fast float %290, 0x4003333340000000
  %294 = fmul fast float %291, 0x4003333340000000
  %295 = fmul fast float %292, 0x4003333340000000
  %296 = call float @dx.op.unary.f32(i32 21, float %293)  ; Exp(value)
  %297 = call float @dx.op.unary.f32(i32 21, float %294)  ; Exp(value)
  %298 = call float @dx.op.unary.f32(i32 21, float %295)  ; Exp(value)
  %299 = fsub fast float %281, %296
  %300 = fsub fast float %282, %297
  %301 = fsub fast float %283, %298
  %302 = fmul fast float %299, %278
  %303 = fmul fast float %300, %279
  %304 = fmul fast float %301, %280
  %305 = fadd fast float %302, %296
  %306 = fadd fast float %303, %297
  %307 = fadd fast float %304, %298
  br label %376

; <label>:308                                     ; preds = %269
  %309 = fadd fast float %5, 1.000000e+00
  %310 = fadd fast float %6, 1.000000e+00
  %311 = fsub fast float 1.000000e+00, %5
  %312 = fmul fast float %9, %309
  %313 = fmul fast float %9, %310
  %314 = fmul fast float %9, %311
  %315 = fmul fast float %312, %152
  %316 = fmul fast float %313, %153
  %317 = fmul fast float %314, %154
  %318 = fcmp fast ult float %10, 5.000000e-01
  br i1 %318, label %344, label %319

; <label>:319                                     ; preds = %308
  %320 = fmul fast float %315, 0x4004147AE0000000
  %321 = fmul fast float %316, 0x4004147AE0000000
  %322 = fmul fast float %317, 0x4004147AE0000000
  %323 = fadd fast float %320, 0x3F9EB851E0000000
  %324 = fadd fast float %321, 0x3F9EB851E0000000
  %325 = fadd fast float %322, 0x3F9EB851E0000000
  %326 = fmul fast float %323, %315
  %327 = fmul fast float %324, %316
  %328 = fmul fast float %325, %317
  %329 = fmul fast float %315, 0x400370A3E0000000
  %330 = fmul fast float %316, 0x400370A3E0000000
  %331 = fmul fast float %317, 0x400370A3E0000000
  %332 = fadd fast float %329, 0x3FE2E147A0000000
  %333 = fadd fast float %330, 0x3FE2E147A0000000
  %334 = fadd fast float %331, 0x3FE2E147A0000000
  %335 = fmul fast float %332, %315
  %336 = fmul fast float %333, %316
  %337 = fmul fast float %334, %317
  %338 = fadd fast float %335, 0x3FC1EB8520000000
  %339 = fadd fast float %336, 0x3FC1EB8520000000
  %340 = fadd fast float %337, 0x3FC1EB8520000000
  %341 = fdiv fast float %326, %338
  %342 = fdiv fast float %327, %339
  %343 = fdiv fast float %328, %340
  br label %344

; <label>:344                                     ; preds = %319, %308
  %345 = phi float [ %341, %319 ], [ %315, %308 ]
  %346 = phi float [ %342, %319 ], [ %316, %308 ]
  %347 = phi float [ %343, %319 ], [ %317, %308 ]
  %348 = call float @dx.op.unary.f32(i32 7, float %345)  ; Saturate(value)
  %349 = call float @dx.op.unary.f32(i32 7, float %346)  ; Saturate(value)
  %350 = call float @dx.op.unary.f32(i32 7, float %347)  ; Saturate(value)
  %351 = call float @dx.op.dot3.f32(i32 55, float %348, float %349, float %350, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %352 = fsub fast float %348, %351
  %353 = fsub fast float %349, %351
  %354 = fsub fast float %350, %351
  %355 = fmul fast float %352, %8
  %356 = fmul fast float %353, %8
  %357 = fmul fast float %354, %8
  %358 = fadd fast float %355, %351
  %359 = fadd fast float %356, %351
  %360 = fadd fast float %357, %351
  %361 = call float @dx.op.unary.f32(i32 7, float %358)  ; Saturate(value)
  %362 = call float @dx.op.unary.f32(i32 7, float %359)  ; Saturate(value)
  %363 = call float @dx.op.unary.f32(i32 7, float %360)  ; Saturate(value)
  %364 = fadd fast float %361, 0xBFC70A3D80000000
  %365 = fadd fast float %362, 0xBFC70A3D80000000
  %366 = fadd fast float %363, 0xBFC70A3D80000000
  %367 = fmul fast float %364, %7
  %368 = fmul fast float %365, %7
  %369 = fmul fast float %366, %7
  %370 = fadd fast float %367, 0x3FC70A3D80000000
  %371 = fadd fast float %368, 0x3FC70A3D80000000
  %372 = fadd fast float %369, 0x3FC70A3D80000000
  %373 = call float @dx.op.unary.f32(i32 7, float %370)  ; Saturate(value)
  %374 = call float @dx.op.unary.f32(i32 7, float %371)  ; Saturate(value)
  %375 = call float @dx.op.unary.f32(i32 7, float %372)  ; Saturate(value)
  br label %376

; <label>:376                                     ; preds = %344, %274
  %377 = phi float [ %305, %274 ], [ %373, %344 ]
  %378 = phi float [ %306, %274 ], [ %374, %344 ]
  %379 = phi float [ %307, %274 ], [ %375, %344 ]
  %380 = fcmp fast olt float %160, 0.000000e+00
  br i1 %380, label %381, label %415

; <label>:381                                     ; preds = %376
  %382 = fcmp fast ogt float %157, 0x3FA4B5DCC0000000
  %383 = fcmp fast ogt float %158, 0x3FA4B5DCC0000000
  %384 = fcmp fast ogt float %159, 0x3FA4B5DCC0000000
  %385 = select i1 %382, float 0.000000e+00, float 1.000000e+00
  %386 = select i1 %383, float 0.000000e+00, float 1.000000e+00
  %387 = select i1 %384, float 0.000000e+00, float 1.000000e+00
  %388 = fmul fast float %157, 0x3FB3D07220000000
  %389 = fmul fast float %158, 0x3FB3D07220000000
  %390 = fmul fast float %159, 0x3FB3D07220000000
  %391 = fadd fast float %157, 0x3FAC28F5C0000000
  %392 = fadd fast float %158, 0x3FAC28F5C0000000
  %393 = fadd fast float %159, 0x3FAC28F5C0000000
  %394 = fmul fast float %391, 0x3FEE54EDE0000000
  %395 = fmul fast float %392, 0x3FEE54EDE0000000
  %396 = fmul fast float %393, 0x3FEE54EDE0000000
  %397 = call float @dx.op.unary.f32(i32 23, float %394)  ; Log(value)
  %398 = call float @dx.op.unary.f32(i32 23, float %395)  ; Log(value)
  %399 = call float @dx.op.unary.f32(i32 23, float %396)  ; Log(value)
  %400 = fmul fast float %397, 0x4003333340000000
  %401 = fmul fast float %398, 0x4003333340000000
  %402 = fmul fast float %399, 0x4003333340000000
  %403 = call float @dx.op.unary.f32(i32 21, float %400)  ; Exp(value)
  %404 = call float @dx.op.unary.f32(i32 21, float %401)  ; Exp(value)
  %405 = call float @dx.op.unary.f32(i32 21, float %402)  ; Exp(value)
  %406 = fsub fast float %388, %403
  %407 = fsub fast float %389, %404
  %408 = fsub fast float %390, %405
  %409 = fmul fast float %406, %385
  %410 = fmul fast float %407, %386
  %411 = fmul fast float %408, %387
  %412 = fadd fast float %409, %403
  %413 = fadd fast float %410, %404
  %414 = fadd fast float %411, %405
  br label %483

; <label>:415                                     ; preds = %376
  %416 = fadd fast float %5, 1.000000e+00
  %417 = fadd fast float %6, 1.000000e+00
  %418 = fsub fast float 1.000000e+00, %5
  %419 = fmul fast float %9, %416
  %420 = fmul fast float %9, %417
  %421 = fmul fast float %9, %418
  %422 = fmul fast float %419, %157
  %423 = fmul fast float %420, %158
  %424 = fmul fast float %421, %159
  %425 = fcmp fast ult float %10, 5.000000e-01
  br i1 %425, label %451, label %426

; <label>:426                                     ; preds = %415
  %427 = fmul fast float %422, 0x4004147AE0000000
  %428 = fmul fast float %423, 0x4004147AE0000000
  %429 = fmul fast float %424, 0x4004147AE0000000
  %430 = fadd fast float %427, 0x3F9EB851E0000000
  %431 = fadd fast float %428, 0x3F9EB851E0000000
  %432 = fadd fast float %429, 0x3F9EB851E0000000
  %433 = fmul fast float %430, %422
  %434 = fmul fast float %431, %423
  %435 = fmul fast float %432, %424
  %436 = fmul fast float %422, 0x400370A3E0000000
  %437 = fmul fast float %423, 0x400370A3E0000000
  %438 = fmul fast float %424, 0x400370A3E0000000
  %439 = fadd fast float %436, 0x3FE2E147A0000000
  %440 = fadd fast float %437, 0x3FE2E147A0000000
  %441 = fadd fast float %438, 0x3FE2E147A0000000
  %442 = fmul fast float %439, %422
  %443 = fmul fast float %440, %423
  %444 = fmul fast float %441, %424
  %445 = fadd fast float %442, 0x3FC1EB8520000000
  %446 = fadd fast float %443, 0x3FC1EB8520000000
  %447 = fadd fast float %444, 0x3FC1EB8520000000
  %448 = fdiv fast float %433, %445
  %449 = fdiv fast float %434, %446
  %450 = fdiv fast float %435, %447
  br label %451

; <label>:451                                     ; preds = %426, %415
  %452 = phi float [ %448, %426 ], [ %422, %415 ]
  %453 = phi float [ %449, %426 ], [ %423, %415 ]
  %454 = phi float [ %450, %426 ], [ %424, %415 ]
  %455 = call float @dx.op.unary.f32(i32 7, float %452)  ; Saturate(value)
  %456 = call float @dx.op.unary.f32(i32 7, float %453)  ; Saturate(value)
  %457 = call float @dx.op.unary.f32(i32 7, float %454)  ; Saturate(value)
  %458 = call float @dx.op.dot3.f32(i32 55, float %455, float %456, float %457, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %459 = fsub fast float %455, %458
  %460 = fsub fast float %456, %458
  %461 = fsub fast float %457, %458
  %462 = fmul fast float %459, %8
  %463 = fmul fast float %460, %8
  %464 = fmul fast float %461, %8
  %465 = fadd fast float %462, %458
  %466 = fadd fast float %463, %458
  %467 = fadd fast float %464, %458
  %468 = call float @dx.op.unary.f32(i32 7, float %465)  ; Saturate(value)
  %469 = call float @dx.op.unary.f32(i32 7, float %466)  ; Saturate(value)
  %470 = call float @dx.op.unary.f32(i32 7, float %467)  ; Saturate(value)
  %471 = fadd fast float %468, 0xBFC70A3D80000000
  %472 = fadd fast float %469, 0xBFC70A3D80000000
  %473 = fadd fast float %470, 0xBFC70A3D80000000
  %474 = fmul fast float %471, %7
  %475 = fmul fast float %472, %7
  %476 = fmul fast float %473, %7
  %477 = fadd fast float %474, 0x3FC70A3D80000000
  %478 = fadd fast float %475, 0x3FC70A3D80000000
  %479 = fadd fast float %476, 0x3FC70A3D80000000
  %480 = call float @dx.op.unary.f32(i32 7, float %477)  ; Saturate(value)
  %481 = call float @dx.op.unary.f32(i32 7, float %478)  ; Saturate(value)
  %482 = call float @dx.op.unary.f32(i32 7, float %479)  ; Saturate(value)
  br label %483

; <label>:483                                     ; preds = %451, %381
  %484 = phi float [ %412, %381 ], [ %480, %451 ]
  %485 = phi float [ %413, %381 ], [ %481, %451 ]
  %486 = phi float [ %414, %381 ], [ %482, %451 ]
  %487 = fcmp fast olt float %165, 0.000000e+00
  br i1 %487, label %488, label %522

; <label>:488                                     ; preds = %483
  %489 = fcmp fast ogt float %162, 0x3FA4B5DCC0000000
  %490 = fcmp fast ogt float %163, 0x3FA4B5DCC0000000
  %491 = fcmp fast ogt float %164, 0x3FA4B5DCC0000000
  %492 = select i1 %489, float 0.000000e+00, float 1.000000e+00
  %493 = select i1 %490, float 0.000000e+00, float 1.000000e+00
  %494 = select i1 %491, float 0.000000e+00, float 1.000000e+00
  %495 = fmul fast float %162, 0x3FB3D07220000000
  %496 = fmul fast float %163, 0x3FB3D07220000000
  %497 = fmul fast float %164, 0x3FB3D07220000000
  %498 = fadd fast float %162, 0x3FAC28F5C0000000
  %499 = fadd fast float %163, 0x3FAC28F5C0000000
  %500 = fadd fast float %164, 0x3FAC28F5C0000000
  %501 = fmul fast float %498, 0x3FEE54EDE0000000
  %502 = fmul fast float %499, 0x3FEE54EDE0000000
  %503 = fmul fast float %500, 0x3FEE54EDE0000000
  %504 = call float @dx.op.unary.f32(i32 23, float %501)  ; Log(value)
  %505 = call float @dx.op.unary.f32(i32 23, float %502)  ; Log(value)
  %506 = call float @dx.op.unary.f32(i32 23, float %503)  ; Log(value)
  %507 = fmul fast float %504, 0x4003333340000000
  %508 = fmul fast float %505, 0x4003333340000000
  %509 = fmul fast float %506, 0x4003333340000000
  %510 = call float @dx.op.unary.f32(i32 21, float %507)  ; Exp(value)
  %511 = call float @dx.op.unary.f32(i32 21, float %508)  ; Exp(value)
  %512 = call float @dx.op.unary.f32(i32 21, float %509)  ; Exp(value)
  %513 = fsub fast float %495, %510
  %514 = fsub fast float %496, %511
  %515 = fsub fast float %497, %512
  %516 = fmul fast float %513, %492
  %517 = fmul fast float %514, %493
  %518 = fmul fast float %515, %494
  %519 = fadd fast float %516, %510
  %520 = fadd fast float %517, %511
  %521 = fadd fast float %518, %512
  br label %590

; <label>:522                                     ; preds = %483
  %523 = fadd fast float %5, 1.000000e+00
  %524 = fadd fast float %6, 1.000000e+00
  %525 = fsub fast float 1.000000e+00, %5
  %526 = fmul fast float %9, %523
  %527 = fmul fast float %9, %524
  %528 = fmul fast float %9, %525
  %529 = fmul fast float %526, %162
  %530 = fmul fast float %527, %163
  %531 = fmul fast float %528, %164
  %532 = fcmp fast ult float %10, 5.000000e-01
  br i1 %532, label %558, label %533

; <label>:533                                     ; preds = %522
  %534 = fmul fast float %529, 0x4004147AE0000000
  %535 = fmul fast float %530, 0x4004147AE0000000
  %536 = fmul fast float %531, 0x4004147AE0000000
  %537 = fadd fast float %534, 0x3F9EB851E0000000
  %538 = fadd fast float %535, 0x3F9EB851E0000000
  %539 = fadd fast float %536, 0x3F9EB851E0000000
  %540 = fmul fast float %537, %529
  %541 = fmul fast float %538, %530
  %542 = fmul fast float %539, %531
  %543 = fmul fast float %529, 0x400370A3E0000000
  %544 = fmul fast float %530, 0x400370A3E0000000
  %545 = fmul fast float %531, 0x400370A3E0000000
  %546 = fadd fast float %543, 0x3FE2E147A0000000
  %547 = fadd fast float %544, 0x3FE2E147A0000000
  %548 = fadd fast float %545, 0x3FE2E147A0000000
  %549 = fmul fast float %546, %529
  %550 = fmul fast float %547, %530
  %551 = fmul fast float %548, %531
  %552 = fadd fast float %549, 0x3FC1EB8520000000
  %553 = fadd fast float %550, 0x3FC1EB8520000000
  %554 = fadd fast float %551, 0x3FC1EB8520000000
  %555 = fdiv fast float %540, %552
  %556 = fdiv fast float %541, %553
  %557 = fdiv fast float %542, %554
  br label %558

; <label>:558                                     ; preds = %533, %522
  %559 = phi float [ %555, %533 ], [ %529, %522 ]
  %560 = phi float [ %556, %533 ], [ %530, %522 ]
  %561 = phi float [ %557, %533 ], [ %531, %522 ]
  %562 = call float @dx.op.unary.f32(i32 7, float %559)  ; Saturate(value)
  %563 = call float @dx.op.unary.f32(i32 7, float %560)  ; Saturate(value)
  %564 = call float @dx.op.unary.f32(i32 7, float %561)  ; Saturate(value)
  %565 = call float @dx.op.dot3.f32(i32 55, float %562, float %563, float %564, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %566 = fsub fast float %562, %565
  %567 = fsub fast float %563, %565
  %568 = fsub fast float %564, %565
  %569 = fmul fast float %566, %8
  %570 = fmul fast float %567, %8
  %571 = fmul fast float %568, %8
  %572 = fadd fast float %569, %565
  %573 = fadd fast float %570, %565
  %574 = fadd fast float %571, %565
  %575 = call float @dx.op.unary.f32(i32 7, float %572)  ; Saturate(value)
  %576 = call float @dx.op.unary.f32(i32 7, float %573)  ; Saturate(value)
  %577 = call float @dx.op.unary.f32(i32 7, float %574)  ; Saturate(value)
  %578 = fadd fast float %575, 0xBFC70A3D80000000
  %579 = fadd fast float %576, 0xBFC70A3D80000000
  %580 = fadd fast float %577, 0xBFC70A3D80000000
  %581 = fmul fast float %578, %7
  %582 = fmul fast float %579, %7
  %583 = fmul fast float %580, %7
  %584 = fadd fast float %581, 0x3FC70A3D80000000
  %585 = fadd fast float %582, 0x3FC70A3D80000000
  %586 = fadd fast float %583, 0x3FC70A3D80000000
  %587 = call float @dx.op.unary.f32(i32 7, float %584)  ; Saturate(value)
  %588 = call float @dx.op.unary.f32(i32 7, float %585)  ; Saturate(value)
  %589 = call float @dx.op.unary.f32(i32 7, float %586)  ; Saturate(value)
  br label %590

; <label>:590                                     ; preds = %558, %488
  %591 = phi float [ %519, %488 ], [ %587, %558 ]
  %592 = phi float [ %520, %488 ], [ %588, %558 ]
  %593 = phi float [ %521, %488 ], [ %589, %558 ]
  %594 = fsub fast float -1.000000e+00, %150
  %595 = select i1 %166, float %594, float %150
  %596 = fsub fast float -1.000000e+00, %155
  %597 = select i1 %273, float %596, float %155
  %598 = fsub fast float -1.000000e+00, %160
  %599 = select i1 %380, float %598, float %160
  %600 = fsub fast float -1.000000e+00, %165
  %601 = select i1 %487, float %600, float %165
  br label %1054

; <label>:602                                     ; preds = %143
  %603 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %34, i32 %35, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %604 = extractvalue %dx.types.ResRet.f32 %603, 0
  %605 = extractvalue %dx.types.ResRet.f32 %603, 1
  %606 = extractvalue %dx.types.ResRet.f32 %603, 2
  %607 = extractvalue %dx.types.ResRet.f32 %603, 3
  %608 = fcmp fast olt float %607, 0.000000e+00
  br i1 %608, label %609, label %644

; <label>:609                                     ; preds = %602
  %610 = fcmp fast ogt float %604, 0x3FA4B5DCC0000000
  %611 = fcmp fast ogt float %605, 0x3FA4B5DCC0000000
  %612 = fcmp fast ogt float %606, 0x3FA4B5DCC0000000
  %613 = select i1 %610, float 0.000000e+00, float 1.000000e+00
  %614 = select i1 %611, float 0.000000e+00, float 1.000000e+00
  %615 = select i1 %612, float 0.000000e+00, float 1.000000e+00
  %616 = fmul fast float %604, 0x3FB3D07220000000
  %617 = fmul fast float %605, 0x3FB3D07220000000
  %618 = fmul fast float %606, 0x3FB3D07220000000
  %619 = fadd fast float %604, 0x3FAC28F5C0000000
  %620 = fadd fast float %605, 0x3FAC28F5C0000000
  %621 = fadd fast float %606, 0x3FAC28F5C0000000
  %622 = fmul fast float %619, 0x3FEE54EDE0000000
  %623 = fmul fast float %620, 0x3FEE54EDE0000000
  %624 = fmul fast float %621, 0x3FEE54EDE0000000
  %625 = call float @dx.op.unary.f32(i32 23, float %622)  ; Log(value)
  %626 = call float @dx.op.unary.f32(i32 23, float %623)  ; Log(value)
  %627 = call float @dx.op.unary.f32(i32 23, float %624)  ; Log(value)
  %628 = fmul fast float %625, 0x4003333340000000
  %629 = fmul fast float %626, 0x4003333340000000
  %630 = fmul fast float %627, 0x4003333340000000
  %631 = call float @dx.op.unary.f32(i32 21, float %628)  ; Exp(value)
  %632 = call float @dx.op.unary.f32(i32 21, float %629)  ; Exp(value)
  %633 = call float @dx.op.unary.f32(i32 21, float %630)  ; Exp(value)
  %634 = fsub fast float %616, %631
  %635 = fsub fast float %617, %632
  %636 = fsub fast float %618, %633
  %637 = fmul fast float %634, %613
  %638 = fmul fast float %635, %614
  %639 = fmul fast float %636, %615
  %640 = fadd fast float %637, %631
  %641 = fadd fast float %638, %632
  %642 = fadd fast float %639, %633
  %643 = fsub fast float -1.000000e+00, %607
  br label %712

; <label>:644                                     ; preds = %602
  %645 = fadd fast float %5, 1.000000e+00
  %646 = fadd fast float %6, 1.000000e+00
  %647 = fsub fast float 1.000000e+00, %5
  %648 = fmul fast float %9, %645
  %649 = fmul fast float %9, %646
  %650 = fmul fast float %9, %647
  %651 = fmul fast float %648, %604
  %652 = fmul fast float %649, %605
  %653 = fmul fast float %650, %606
  %654 = fcmp fast ult float %10, 5.000000e-01
  br i1 %654, label %680, label %655

; <label>:655                                     ; preds = %644
  %656 = fmul fast float %651, 0x4004147AE0000000
  %657 = fmul fast float %652, 0x4004147AE0000000
  %658 = fmul fast float %653, 0x4004147AE0000000
  %659 = fadd fast float %656, 0x3F9EB851E0000000
  %660 = fadd fast float %657, 0x3F9EB851E0000000
  %661 = fadd fast float %658, 0x3F9EB851E0000000
  %662 = fmul fast float %659, %651
  %663 = fmul fast float %660, %652
  %664 = fmul fast float %661, %653
  %665 = fmul fast float %651, 0x400370A3E0000000
  %666 = fmul fast float %652, 0x400370A3E0000000
  %667 = fmul fast float %653, 0x400370A3E0000000
  %668 = fadd fast float %665, 0x3FE2E147A0000000
  %669 = fadd fast float %666, 0x3FE2E147A0000000
  %670 = fadd fast float %667, 0x3FE2E147A0000000
  %671 = fmul fast float %668, %651
  %672 = fmul fast float %669, %652
  %673 = fmul fast float %670, %653
  %674 = fadd fast float %671, 0x3FC1EB8520000000
  %675 = fadd fast float %672, 0x3FC1EB8520000000
  %676 = fadd fast float %673, 0x3FC1EB8520000000
  %677 = fdiv fast float %662, %674
  %678 = fdiv fast float %663, %675
  %679 = fdiv fast float %664, %676
  br label %680

; <label>:680                                     ; preds = %655, %644
  %681 = phi float [ %677, %655 ], [ %651, %644 ]
  %682 = phi float [ %678, %655 ], [ %652, %644 ]
  %683 = phi float [ %679, %655 ], [ %653, %644 ]
  %684 = call float @dx.op.unary.f32(i32 7, float %681)  ; Saturate(value)
  %685 = call float @dx.op.unary.f32(i32 7, float %682)  ; Saturate(value)
  %686 = call float @dx.op.unary.f32(i32 7, float %683)  ; Saturate(value)
  %687 = call float @dx.op.dot3.f32(i32 55, float %684, float %685, float %686, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %688 = fsub fast float %684, %687
  %689 = fsub fast float %685, %687
  %690 = fsub fast float %686, %687
  %691 = fmul fast float %688, %8
  %692 = fmul fast float %689, %8
  %693 = fmul fast float %690, %8
  %694 = fadd fast float %691, %687
  %695 = fadd fast float %692, %687
  %696 = fadd fast float %693, %687
  %697 = call float @dx.op.unary.f32(i32 7, float %694)  ; Saturate(value)
  %698 = call float @dx.op.unary.f32(i32 7, float %695)  ; Saturate(value)
  %699 = call float @dx.op.unary.f32(i32 7, float %696)  ; Saturate(value)
  %700 = fadd fast float %697, 0xBFC70A3D80000000
  %701 = fadd fast float %698, 0xBFC70A3D80000000
  %702 = fadd fast float %699, 0xBFC70A3D80000000
  %703 = fmul fast float %700, %7
  %704 = fmul fast float %701, %7
  %705 = fmul fast float %702, %7
  %706 = fadd fast float %703, 0x3FC70A3D80000000
  %707 = fadd fast float %704, 0x3FC70A3D80000000
  %708 = fadd fast float %705, 0x3FC70A3D80000000
  %709 = call float @dx.op.unary.f32(i32 7, float %706)  ; Saturate(value)
  %710 = call float @dx.op.unary.f32(i32 7, float %707)  ; Saturate(value)
  %711 = call float @dx.op.unary.f32(i32 7, float %708)  ; Saturate(value)
  br label %712

; <label>:712                                     ; preds = %680, %609
  %713 = phi float [ %640, %609 ], [ %709, %680 ]
  %714 = phi float [ %641, %609 ], [ %710, %680 ]
  %715 = phi float [ %642, %609 ], [ %711, %680 ]
  %716 = phi float [ %643, %609 ], [ %607, %680 ]
  %717 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %38, i32 %35, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %718 = extractvalue %dx.types.ResRet.f32 %717, 0
  %719 = extractvalue %dx.types.ResRet.f32 %717, 1
  %720 = extractvalue %dx.types.ResRet.f32 %717, 2
  %721 = extractvalue %dx.types.ResRet.f32 %717, 3
  %722 = fcmp fast olt float %721, 0.000000e+00
  br i1 %722, label %723, label %758

; <label>:723                                     ; preds = %712
  %724 = fcmp fast ogt float %718, 0x3FA4B5DCC0000000
  %725 = fcmp fast ogt float %719, 0x3FA4B5DCC0000000
  %726 = fcmp fast ogt float %720, 0x3FA4B5DCC0000000
  %727 = select i1 %724, float 0.000000e+00, float 1.000000e+00
  %728 = select i1 %725, float 0.000000e+00, float 1.000000e+00
  %729 = select i1 %726, float 0.000000e+00, float 1.000000e+00
  %730 = fmul fast float %718, 0x3FB3D07220000000
  %731 = fmul fast float %719, 0x3FB3D07220000000
  %732 = fmul fast float %720, 0x3FB3D07220000000
  %733 = fadd fast float %718, 0x3FAC28F5C0000000
  %734 = fadd fast float %719, 0x3FAC28F5C0000000
  %735 = fadd fast float %720, 0x3FAC28F5C0000000
  %736 = fmul fast float %733, 0x3FEE54EDE0000000
  %737 = fmul fast float %734, 0x3FEE54EDE0000000
  %738 = fmul fast float %735, 0x3FEE54EDE0000000
  %739 = call float @dx.op.unary.f32(i32 23, float %736)  ; Log(value)
  %740 = call float @dx.op.unary.f32(i32 23, float %737)  ; Log(value)
  %741 = call float @dx.op.unary.f32(i32 23, float %738)  ; Log(value)
  %742 = fmul fast float %739, 0x4003333340000000
  %743 = fmul fast float %740, 0x4003333340000000
  %744 = fmul fast float %741, 0x4003333340000000
  %745 = call float @dx.op.unary.f32(i32 21, float %742)  ; Exp(value)
  %746 = call float @dx.op.unary.f32(i32 21, float %743)  ; Exp(value)
  %747 = call float @dx.op.unary.f32(i32 21, float %744)  ; Exp(value)
  %748 = fsub fast float %730, %745
  %749 = fsub fast float %731, %746
  %750 = fsub fast float %732, %747
  %751 = fmul fast float %748, %727
  %752 = fmul fast float %749, %728
  %753 = fmul fast float %750, %729
  %754 = fadd fast float %751, %745
  %755 = fadd fast float %752, %746
  %756 = fadd fast float %753, %747
  %757 = fsub fast float -1.000000e+00, %721
  br label %826

; <label>:758                                     ; preds = %712
  %759 = fadd fast float %5, 1.000000e+00
  %760 = fadd fast float %6, 1.000000e+00
  %761 = fsub fast float 1.000000e+00, %5
  %762 = fmul fast float %9, %759
  %763 = fmul fast float %9, %760
  %764 = fmul fast float %9, %761
  %765 = fmul fast float %762, %718
  %766 = fmul fast float %763, %719
  %767 = fmul fast float %764, %720
  %768 = fcmp fast ult float %10, 5.000000e-01
  br i1 %768, label %794, label %769

; <label>:769                                     ; preds = %758
  %770 = fmul fast float %765, 0x4004147AE0000000
  %771 = fmul fast float %766, 0x4004147AE0000000
  %772 = fmul fast float %767, 0x4004147AE0000000
  %773 = fadd fast float %770, 0x3F9EB851E0000000
  %774 = fadd fast float %771, 0x3F9EB851E0000000
  %775 = fadd fast float %772, 0x3F9EB851E0000000
  %776 = fmul fast float %773, %765
  %777 = fmul fast float %774, %766
  %778 = fmul fast float %775, %767
  %779 = fmul fast float %765, 0x400370A3E0000000
  %780 = fmul fast float %766, 0x400370A3E0000000
  %781 = fmul fast float %767, 0x400370A3E0000000
  %782 = fadd fast float %779, 0x3FE2E147A0000000
  %783 = fadd fast float %780, 0x3FE2E147A0000000
  %784 = fadd fast float %781, 0x3FE2E147A0000000
  %785 = fmul fast float %782, %765
  %786 = fmul fast float %783, %766
  %787 = fmul fast float %784, %767
  %788 = fadd fast float %785, 0x3FC1EB8520000000
  %789 = fadd fast float %786, 0x3FC1EB8520000000
  %790 = fadd fast float %787, 0x3FC1EB8520000000
  %791 = fdiv fast float %776, %788
  %792 = fdiv fast float %777, %789
  %793 = fdiv fast float %778, %790
  br label %794

; <label>:794                                     ; preds = %769, %758
  %795 = phi float [ %791, %769 ], [ %765, %758 ]
  %796 = phi float [ %792, %769 ], [ %766, %758 ]
  %797 = phi float [ %793, %769 ], [ %767, %758 ]
  %798 = call float @dx.op.unary.f32(i32 7, float %795)  ; Saturate(value)
  %799 = call float @dx.op.unary.f32(i32 7, float %796)  ; Saturate(value)
  %800 = call float @dx.op.unary.f32(i32 7, float %797)  ; Saturate(value)
  %801 = call float @dx.op.dot3.f32(i32 55, float %798, float %799, float %800, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %802 = fsub fast float %798, %801
  %803 = fsub fast float %799, %801
  %804 = fsub fast float %800, %801
  %805 = fmul fast float %802, %8
  %806 = fmul fast float %803, %8
  %807 = fmul fast float %804, %8
  %808 = fadd fast float %805, %801
  %809 = fadd fast float %806, %801
  %810 = fadd fast float %807, %801
  %811 = call float @dx.op.unary.f32(i32 7, float %808)  ; Saturate(value)
  %812 = call float @dx.op.unary.f32(i32 7, float %809)  ; Saturate(value)
  %813 = call float @dx.op.unary.f32(i32 7, float %810)  ; Saturate(value)
  %814 = fadd fast float %811, 0xBFC70A3D80000000
  %815 = fadd fast float %812, 0xBFC70A3D80000000
  %816 = fadd fast float %813, 0xBFC70A3D80000000
  %817 = fmul fast float %814, %7
  %818 = fmul fast float %815, %7
  %819 = fmul fast float %816, %7
  %820 = fadd fast float %817, 0x3FC70A3D80000000
  %821 = fadd fast float %818, 0x3FC70A3D80000000
  %822 = fadd fast float %819, 0x3FC70A3D80000000
  %823 = call float @dx.op.unary.f32(i32 7, float %820)  ; Saturate(value)
  %824 = call float @dx.op.unary.f32(i32 7, float %821)  ; Saturate(value)
  %825 = call float @dx.op.unary.f32(i32 7, float %822)  ; Saturate(value)
  br label %826

; <label>:826                                     ; preds = %794, %723
  %827 = phi float [ %754, %723 ], [ %823, %794 ]
  %828 = phi float [ %755, %723 ], [ %824, %794 ]
  %829 = phi float [ %756, %723 ], [ %825, %794 ]
  %830 = phi float [ %757, %723 ], [ %721, %794 ]
  %831 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %34, i32 %41, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %832 = extractvalue %dx.types.ResRet.f32 %831, 0
  %833 = extractvalue %dx.types.ResRet.f32 %831, 1
  %834 = extractvalue %dx.types.ResRet.f32 %831, 2
  %835 = extractvalue %dx.types.ResRet.f32 %831, 3
  %836 = fcmp fast olt float %835, 0.000000e+00
  br i1 %836, label %837, label %872

; <label>:837                                     ; preds = %826
  %838 = fcmp fast ogt float %832, 0x3FA4B5DCC0000000
  %839 = fcmp fast ogt float %833, 0x3FA4B5DCC0000000
  %840 = fcmp fast ogt float %834, 0x3FA4B5DCC0000000
  %841 = select i1 %838, float 0.000000e+00, float 1.000000e+00
  %842 = select i1 %839, float 0.000000e+00, float 1.000000e+00
  %843 = select i1 %840, float 0.000000e+00, float 1.000000e+00
  %844 = fmul fast float %832, 0x3FB3D07220000000
  %845 = fmul fast float %833, 0x3FB3D07220000000
  %846 = fmul fast float %834, 0x3FB3D07220000000
  %847 = fadd fast float %832, 0x3FAC28F5C0000000
  %848 = fadd fast float %833, 0x3FAC28F5C0000000
  %849 = fadd fast float %834, 0x3FAC28F5C0000000
  %850 = fmul fast float %847, 0x3FEE54EDE0000000
  %851 = fmul fast float %848, 0x3FEE54EDE0000000
  %852 = fmul fast float %849, 0x3FEE54EDE0000000
  %853 = call float @dx.op.unary.f32(i32 23, float %850)  ; Log(value)
  %854 = call float @dx.op.unary.f32(i32 23, float %851)  ; Log(value)
  %855 = call float @dx.op.unary.f32(i32 23, float %852)  ; Log(value)
  %856 = fmul fast float %853, 0x4003333340000000
  %857 = fmul fast float %854, 0x4003333340000000
  %858 = fmul fast float %855, 0x4003333340000000
  %859 = call float @dx.op.unary.f32(i32 21, float %856)  ; Exp(value)
  %860 = call float @dx.op.unary.f32(i32 21, float %857)  ; Exp(value)
  %861 = call float @dx.op.unary.f32(i32 21, float %858)  ; Exp(value)
  %862 = fsub fast float %844, %859
  %863 = fsub fast float %845, %860
  %864 = fsub fast float %846, %861
  %865 = fmul fast float %862, %841
  %866 = fmul fast float %863, %842
  %867 = fmul fast float %864, %843
  %868 = fadd fast float %865, %859
  %869 = fadd fast float %866, %860
  %870 = fadd fast float %867, %861
  %871 = fsub fast float -1.000000e+00, %835
  br label %940

; <label>:872                                     ; preds = %826
  %873 = fadd fast float %5, 1.000000e+00
  %874 = fadd fast float %6, 1.000000e+00
  %875 = fsub fast float 1.000000e+00, %5
  %876 = fmul fast float %9, %873
  %877 = fmul fast float %9, %874
  %878 = fmul fast float %9, %875
  %879 = fmul fast float %876, %832
  %880 = fmul fast float %877, %833
  %881 = fmul fast float %878, %834
  %882 = fcmp fast ult float %10, 5.000000e-01
  br i1 %882, label %908, label %883

; <label>:883                                     ; preds = %872
  %884 = fmul fast float %879, 0x4004147AE0000000
  %885 = fmul fast float %880, 0x4004147AE0000000
  %886 = fmul fast float %881, 0x4004147AE0000000
  %887 = fadd fast float %884, 0x3F9EB851E0000000
  %888 = fadd fast float %885, 0x3F9EB851E0000000
  %889 = fadd fast float %886, 0x3F9EB851E0000000
  %890 = fmul fast float %887, %879
  %891 = fmul fast float %888, %880
  %892 = fmul fast float %889, %881
  %893 = fmul fast float %879, 0x400370A3E0000000
  %894 = fmul fast float %880, 0x400370A3E0000000
  %895 = fmul fast float %881, 0x400370A3E0000000
  %896 = fadd fast float %893, 0x3FE2E147A0000000
  %897 = fadd fast float %894, 0x3FE2E147A0000000
  %898 = fadd fast float %895, 0x3FE2E147A0000000
  %899 = fmul fast float %896, %879
  %900 = fmul fast float %897, %880
  %901 = fmul fast float %898, %881
  %902 = fadd fast float %899, 0x3FC1EB8520000000
  %903 = fadd fast float %900, 0x3FC1EB8520000000
  %904 = fadd fast float %901, 0x3FC1EB8520000000
  %905 = fdiv fast float %890, %902
  %906 = fdiv fast float %891, %903
  %907 = fdiv fast float %892, %904
  br label %908

; <label>:908                                     ; preds = %883, %872
  %909 = phi float [ %905, %883 ], [ %879, %872 ]
  %910 = phi float [ %906, %883 ], [ %880, %872 ]
  %911 = phi float [ %907, %883 ], [ %881, %872 ]
  %912 = call float @dx.op.unary.f32(i32 7, float %909)  ; Saturate(value)
  %913 = call float @dx.op.unary.f32(i32 7, float %910)  ; Saturate(value)
  %914 = call float @dx.op.unary.f32(i32 7, float %911)  ; Saturate(value)
  %915 = call float @dx.op.dot3.f32(i32 55, float %912, float %913, float %914, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %916 = fsub fast float %912, %915
  %917 = fsub fast float %913, %915
  %918 = fsub fast float %914, %915
  %919 = fmul fast float %916, %8
  %920 = fmul fast float %917, %8
  %921 = fmul fast float %918, %8
  %922 = fadd fast float %919, %915
  %923 = fadd fast float %920, %915
  %924 = fadd fast float %921, %915
  %925 = call float @dx.op.unary.f32(i32 7, float %922)  ; Saturate(value)
  %926 = call float @dx.op.unary.f32(i32 7, float %923)  ; Saturate(value)
  %927 = call float @dx.op.unary.f32(i32 7, float %924)  ; Saturate(value)
  %928 = fadd fast float %925, 0xBFC70A3D80000000
  %929 = fadd fast float %926, 0xBFC70A3D80000000
  %930 = fadd fast float %927, 0xBFC70A3D80000000
  %931 = fmul fast float %928, %7
  %932 = fmul fast float %929, %7
  %933 = fmul fast float %930, %7
  %934 = fadd fast float %931, 0x3FC70A3D80000000
  %935 = fadd fast float %932, 0x3FC70A3D80000000
  %936 = fadd fast float %933, 0x3FC70A3D80000000
  %937 = call float @dx.op.unary.f32(i32 7, float %934)  ; Saturate(value)
  %938 = call float @dx.op.unary.f32(i32 7, float %935)  ; Saturate(value)
  %939 = call float @dx.op.unary.f32(i32 7, float %936)  ; Saturate(value)
  br label %940

; <label>:940                                     ; preds = %908, %837
  %941 = phi float [ %868, %837 ], [ %937, %908 ]
  %942 = phi float [ %869, %837 ], [ %938, %908 ]
  %943 = phi float [ %870, %837 ], [ %939, %908 ]
  %944 = phi float [ %871, %837 ], [ %835, %908 ]
  %945 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %38, i32 %41, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %946 = extractvalue %dx.types.ResRet.f32 %945, 0
  %947 = extractvalue %dx.types.ResRet.f32 %945, 1
  %948 = extractvalue %dx.types.ResRet.f32 %945, 2
  %949 = extractvalue %dx.types.ResRet.f32 %945, 3
  %950 = fcmp fast olt float %949, 0.000000e+00
  br i1 %950, label %951, label %986

; <label>:951                                     ; preds = %940
  %952 = fcmp fast ogt float %946, 0x3FA4B5DCC0000000
  %953 = fcmp fast ogt float %947, 0x3FA4B5DCC0000000
  %954 = fcmp fast ogt float %948, 0x3FA4B5DCC0000000
  %955 = select i1 %952, float 0.000000e+00, float 1.000000e+00
  %956 = select i1 %953, float 0.000000e+00, float 1.000000e+00
  %957 = select i1 %954, float 0.000000e+00, float 1.000000e+00
  %958 = fmul fast float %946, 0x3FB3D07220000000
  %959 = fmul fast float %947, 0x3FB3D07220000000
  %960 = fmul fast float %948, 0x3FB3D07220000000
  %961 = fadd fast float %946, 0x3FAC28F5C0000000
  %962 = fadd fast float %947, 0x3FAC28F5C0000000
  %963 = fadd fast float %948, 0x3FAC28F5C0000000
  %964 = fmul fast float %961, 0x3FEE54EDE0000000
  %965 = fmul fast float %962, 0x3FEE54EDE0000000
  %966 = fmul fast float %963, 0x3FEE54EDE0000000
  %967 = call float @dx.op.unary.f32(i32 23, float %964)  ; Log(value)
  %968 = call float @dx.op.unary.f32(i32 23, float %965)  ; Log(value)
  %969 = call float @dx.op.unary.f32(i32 23, float %966)  ; Log(value)
  %970 = fmul fast float %967, 0x4003333340000000
  %971 = fmul fast float %968, 0x4003333340000000
  %972 = fmul fast float %969, 0x4003333340000000
  %973 = call float @dx.op.unary.f32(i32 21, float %970)  ; Exp(value)
  %974 = call float @dx.op.unary.f32(i32 21, float %971)  ; Exp(value)
  %975 = call float @dx.op.unary.f32(i32 21, float %972)  ; Exp(value)
  %976 = fsub fast float %958, %973
  %977 = fsub fast float %959, %974
  %978 = fsub fast float %960, %975
  %979 = fmul fast float %976, %955
  %980 = fmul fast float %977, %956
  %981 = fmul fast float %978, %957
  %982 = fadd fast float %979, %973
  %983 = fadd fast float %980, %974
  %984 = fadd fast float %981, %975
  %985 = fsub fast float -1.000000e+00, %949
  br label %1054

; <label>:986                                     ; preds = %940
  %987 = fadd fast float %5, 1.000000e+00
  %988 = fadd fast float %6, 1.000000e+00
  %989 = fsub fast float 1.000000e+00, %5
  %990 = fmul fast float %9, %987
  %991 = fmul fast float %9, %988
  %992 = fmul fast float %9, %989
  %993 = fmul fast float %990, %946
  %994 = fmul fast float %991, %947
  %995 = fmul fast float %992, %948
  %996 = fcmp fast ult float %10, 5.000000e-01
  br i1 %996, label %1022, label %997

; <label>:997                                     ; preds = %986
  %998 = fmul fast float %993, 0x4004147AE0000000
  %999 = fmul fast float %994, 0x4004147AE0000000
  %1000 = fmul fast float %995, 0x4004147AE0000000
  %1001 = fadd fast float %998, 0x3F9EB851E0000000
  %1002 = fadd fast float %999, 0x3F9EB851E0000000
  %1003 = fadd fast float %1000, 0x3F9EB851E0000000
  %1004 = fmul fast float %1001, %993
  %1005 = fmul fast float %1002, %994
  %1006 = fmul fast float %1003, %995
  %1007 = fmul fast float %993, 0x400370A3E0000000
  %1008 = fmul fast float %994, 0x400370A3E0000000
  %1009 = fmul fast float %995, 0x400370A3E0000000
  %1010 = fadd fast float %1007, 0x3FE2E147A0000000
  %1011 = fadd fast float %1008, 0x3FE2E147A0000000
  %1012 = fadd fast float %1009, 0x3FE2E147A0000000
  %1013 = fmul fast float %1010, %993
  %1014 = fmul fast float %1011, %994
  %1015 = fmul fast float %1012, %995
  %1016 = fadd fast float %1013, 0x3FC1EB8520000000
  %1017 = fadd fast float %1014, 0x3FC1EB8520000000
  %1018 = fadd fast float %1015, 0x3FC1EB8520000000
  %1019 = fdiv fast float %1004, %1016
  %1020 = fdiv fast float %1005, %1017
  %1021 = fdiv fast float %1006, %1018
  br label %1022

; <label>:1022                                    ; preds = %997, %986
  %1023 = phi float [ %1019, %997 ], [ %993, %986 ]
  %1024 = phi float [ %1020, %997 ], [ %994, %986 ]
  %1025 = phi float [ %1021, %997 ], [ %995, %986 ]
  %1026 = call float @dx.op.unary.f32(i32 7, float %1023)  ; Saturate(value)
  %1027 = call float @dx.op.unary.f32(i32 7, float %1024)  ; Saturate(value)
  %1028 = call float @dx.op.unary.f32(i32 7, float %1025)  ; Saturate(value)
  %1029 = call float @dx.op.dot3.f32(i32 55, float %1026, float %1027, float %1028, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1030 = fsub fast float %1026, %1029
  %1031 = fsub fast float %1027, %1029
  %1032 = fsub fast float %1028, %1029
  %1033 = fmul fast float %1030, %8
  %1034 = fmul fast float %1031, %8
  %1035 = fmul fast float %1032, %8
  %1036 = fadd fast float %1033, %1029
  %1037 = fadd fast float %1034, %1029
  %1038 = fadd fast float %1035, %1029
  %1039 = call float @dx.op.unary.f32(i32 7, float %1036)  ; Saturate(value)
  %1040 = call float @dx.op.unary.f32(i32 7, float %1037)  ; Saturate(value)
  %1041 = call float @dx.op.unary.f32(i32 7, float %1038)  ; Saturate(value)
  %1042 = fadd fast float %1039, 0xBFC70A3D80000000
  %1043 = fadd fast float %1040, 0xBFC70A3D80000000
  %1044 = fadd fast float %1041, 0xBFC70A3D80000000
  %1045 = fmul fast float %1042, %7
  %1046 = fmul fast float %1043, %7
  %1047 = fmul fast float %1044, %7
  %1048 = fadd fast float %1045, 0x3FC70A3D80000000
  %1049 = fadd fast float %1046, 0x3FC70A3D80000000
  %1050 = fadd fast float %1047, 0x3FC70A3D80000000
  %1051 = call float @dx.op.unary.f32(i32 7, float %1048)  ; Saturate(value)
  %1052 = call float @dx.op.unary.f32(i32 7, float %1049)  ; Saturate(value)
  %1053 = call float @dx.op.unary.f32(i32 7, float %1050)  ; Saturate(value)
  br label %1054

; <label>:1054                                    ; preds = %1022, %951, %590
  %1055 = phi float [ %713, %951 ], [ %270, %590 ], [ %713, %1022 ]
  %1056 = phi float [ %714, %951 ], [ %271, %590 ], [ %714, %1022 ]
  %1057 = phi float [ %715, %951 ], [ %272, %590 ], [ %715, %1022 ]
  %1058 = phi float [ %716, %951 ], [ %595, %590 ], [ %716, %1022 ]
  %1059 = phi float [ %827, %951 ], [ %377, %590 ], [ %827, %1022 ]
  %1060 = phi float [ %828, %951 ], [ %378, %590 ], [ %828, %1022 ]
  %1061 = phi float [ %829, %951 ], [ %379, %590 ], [ %829, %1022 ]
  %1062 = phi float [ %830, %951 ], [ %597, %590 ], [ %830, %1022 ]
  %1063 = phi float [ %941, %951 ], [ %484, %590 ], [ %941, %1022 ]
  %1064 = phi float [ %942, %951 ], [ %485, %590 ], [ %942, %1022 ]
  %1065 = phi float [ %943, %951 ], [ %486, %590 ], [ %943, %1022 ]
  %1066 = phi float [ %944, %951 ], [ %599, %590 ], [ %944, %1022 ]
  %1067 = phi float [ %982, %951 ], [ %591, %590 ], [ %1051, %1022 ]
  %1068 = phi float [ %983, %951 ], [ %592, %590 ], [ %1052, %1022 ]
  %1069 = phi float [ %984, %951 ], [ %593, %590 ], [ %1053, %1022 ]
  %1070 = phi float [ %985, %951 ], [ %601, %590 ], [ %949, %1022 ]
  %1071 = fmul fast float %1055, %133
  %1072 = fmul fast float %1056, %133
  %1073 = fmul fast float %1057, %133
  %1074 = fmul fast float %1059, %134
  %1075 = fmul fast float %1060, %134
  %1076 = fmul fast float %1061, %134
  %1077 = fadd fast float %1074, %1071
  %1078 = fadd fast float %1075, %1072
  %1079 = fadd fast float %1076, %1073
  %1080 = fmul fast float %1063, %135
  %1081 = fmul fast float %1064, %135
  %1082 = fmul fast float %1065, %135
  %1083 = fadd fast float %1077, %1080
  %1084 = fadd fast float %1078, %1081
  %1085 = fadd fast float %1079, %1082
  %1086 = fmul fast float %1067, %136
  %1087 = fmul fast float %1068, %136
  %1088 = fmul fast float %1069, %136
  %1089 = fadd fast float %1083, %1086
  %1090 = fadd fast float %1084, %1087
  %1091 = fadd fast float %1085, %1088
  %1092 = fcmp fast ogt float %1089, 0x3F69A5C380000000
  %1093 = fcmp fast ogt float %1090, 0x3F69A5C380000000
  %1094 = fcmp fast ogt float %1091, 0x3F69A5C380000000
  %1095 = select i1 %1092, float 0.000000e+00, float 1.000000e+00
  %1096 = select i1 %1093, float 0.000000e+00, float 1.000000e+00
  %1097 = select i1 %1094, float 0.000000e+00, float 1.000000e+00
  %1098 = fmul fast float %1089, 0x4029D70A40000000
  %1099 = fmul fast float %1090, 0x4029D70A40000000
  %1100 = fmul fast float %1091, 0x4029D70A40000000
  %1101 = call float @dx.op.binary.f32(i32 35, float %1089, float 0.000000e+00)  ; FMax(a,b)
  %1102 = call float @dx.op.binary.f32(i32 35, float %1090, float 0.000000e+00)  ; FMax(a,b)
  %1103 = call float @dx.op.binary.f32(i32 35, float %1091, float 0.000000e+00)  ; FMax(a,b)
  %1104 = call float @dx.op.unary.f32(i32 23, float %1101)  ; Log(value)
  %1105 = call float @dx.op.unary.f32(i32 23, float %1102)  ; Log(value)
  %1106 = call float @dx.op.unary.f32(i32 23, float %1103)  ; Log(value)
  %1107 = fmul fast float %1104, 0x3FDAAAAAA0000000
  %1108 = fmul fast float %1105, 0x3FDAAAAAA0000000
  %1109 = fmul fast float %1106, 0x3FDAAAAAA0000000
  %1110 = call float @dx.op.unary.f32(i32 21, float %1107)  ; Exp(value)
  %1111 = call float @dx.op.unary.f32(i32 21, float %1108)  ; Exp(value)
  %1112 = call float @dx.op.unary.f32(i32 21, float %1109)  ; Exp(value)
  %1113 = fmul fast float %1110, 0x3FF0E147A0000000
  %1114 = fmul fast float %1111, 0x3FF0E147A0000000
  %1115 = fmul fast float %1112, 0x3FF0E147A0000000
  %1116 = fadd fast float %1113, 0xBFAC28F5C0000000
  %1117 = fadd fast float %1114, 0xBFAC28F5C0000000
  %1118 = fadd fast float %1115, 0xBFAC28F5C0000000
  %1119 = fsub fast float %1098, %1116
  %1120 = fsub fast float %1099, %1117
  %1121 = fsub fast float %1100, %1118
  %1122 = fmul fast float %1119, %1095
  %1123 = fmul fast float %1120, %1096
  %1124 = fmul fast float %1121, %1097
  %1125 = fadd fast float %1122, %1116
  %1126 = fadd fast float %1123, %1117
  %1127 = fadd fast float %1124, %1118
  %1128 = call float @dx.op.dot4.f32(i32 56, float %1058, float %1062, float %1066, float %1070, float %133, float %134, float %135, float %136)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %1125)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %1126)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %1127)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %1128)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %51)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare i1 @dx.op.isSpecialFloat.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 0, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !37, null}
!12 = !{!13, !16, !17, !19, !21, !23, !25, !27, !29, !31, !34}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !15}
!17 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !18, i8 1, i32 1, i8 4, i32 2, i8 0, null}
!18 = !{i32 1}
!19 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !20, i8 1, i32 1, i8 4, i32 3, i8 0, null}
!20 = !{i32 2}
!21 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !22, i8 1, i32 1, i8 4, i32 4, i8 0, null}
!22 = !{i32 3}
!23 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !24, i8 1, i32 1, i8 4, i32 5, i8 0, null}
!24 = !{i32 4}
!25 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !26, i8 1, i32 1, i8 4, i32 6, i8 0, null}
!26 = !{i32 5}
!27 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !28, i8 1, i32 1, i8 4, i32 7, i8 0, null}
!28 = !{i32 6}
!29 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 8, i8 0, null}
!30 = !{i32 7}
!31 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 9, i8 0, !33}
!32 = !{i32 8}
!33 = !{i32 3, i32 15}
!34 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !35, i8 1, i32 1, i8 4, i32 10, i8 0, !36}
!35 = !{i32 9}
!36 = !{i32 3, i32 6}
!37 = !{!38, !39}
!38 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !33}
!39 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !40}
!40 = !{i32 3, i32 1}
