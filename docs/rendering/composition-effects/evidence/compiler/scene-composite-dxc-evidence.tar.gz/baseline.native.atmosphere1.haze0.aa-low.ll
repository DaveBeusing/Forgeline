;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float       
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
;
; shader hash: dce887ae8fec6e33e7782422e25a337e
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=0
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 1
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39 }
;   output 3 depends on inputs: { 0, 1 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %40 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %41 = extractvalue %dx.types.Dimensions %40, 0
  %42 = extractvalue %dx.types.Dimensions %40, 1
  %43 = fptosi float %38 to i32
  %44 = fptosi float %39 to i32
  %45 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %43, i32 %44, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %46 = extractvalue %dx.types.ResRet.f32 %45, 0
  %47 = extractvalue %dx.types.ResRet.f32 %45, 1
  %48 = extractvalue %dx.types.ResRet.f32 %45, 2
  %49 = extractvalue %dx.types.ResRet.f32 %45, 3
  %50 = fcmp fast olt float %49, 0.000000e+00
  br i1 %50, label %51, label %53

; <label>:51                                      ; preds = %0
  %52 = fsub fast float -1.000000e+00, %49
  br label %1210

; <label>:53                                      ; preds = %0
  %54 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %43, i32 %44, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %55 = extractvalue %dx.types.ResRet.f32 %54, 0
  %56 = fcmp fast ogt float %36, 5.000000e-01
  %57 = fcmp fast olt float %55, 1.000000e+00
  %58 = and i1 %56, %57
  br i1 %58, label %59, label %147

; <label>:59                                      ; preds = %53
  %60 = sitofp i32 %43 to float
  %61 = sitofp i32 %44 to float
  %62 = fadd fast float %60, 5.000000e-01
  %63 = fadd fast float %61, 5.000000e-01
  %64 = uitofp i32 %41 to float
  %65 = uitofp i32 %42 to float
  %66 = fdiv fast float %62, %64
  %67 = fdiv fast float %63, %65
  %68 = fmul fast float %66, 2.000000e+00
  %69 = fmul fast float %67, 2.000000e+00
  %70 = fadd fast float %68, -1.000000e+00
  %71 = fsub fast float 1.000000e+00, %69
  %72 = fmul fast float %70, %33
  %73 = call float @dx.op.tertiary.f32(i32 46, float %71, float %29, float %72)  ; FMad(a,b,c)
  %74 = call float @dx.op.tertiary.f32(i32 46, float %55, float %25, float %73)  ; FMad(a,b,c)
  %75 = fadd fast float %74, %21
  %76 = call float @dx.op.unary.f32(i32 6, float %75)  ; FAbs(value)
  %77 = fcmp fast ogt float %76, 0x3EB0C6F7A0000000
  br i1 %77, label %78, label %147

; <label>:78                                      ; preds = %59
  %79 = fmul fast float %70, %32
  %80 = call float @dx.op.tertiary.f32(i32 46, float %71, float %28, float %79)  ; FMad(a,b,c)
  %81 = call float @dx.op.tertiary.f32(i32 46, float %55, float %24, float %80)  ; FMad(a,b,c)
  %82 = fadd fast float %81, %20
  %83 = fmul fast float %70, %31
  %84 = call float @dx.op.tertiary.f32(i32 46, float %71, float %27, float %83)  ; FMad(a,b,c)
  %85 = call float @dx.op.tertiary.f32(i32 46, float %55, float %23, float %84)  ; FMad(a,b,c)
  %86 = fadd fast float %85, %19
  %87 = fmul fast float %70, %30
  %88 = call float @dx.op.tertiary.f32(i32 46, float %71, float %26, float %87)  ; FMad(a,b,c)
  %89 = call float @dx.op.tertiary.f32(i32 46, float %55, float %22, float %88)  ; FMad(a,b,c)
  %90 = fadd fast float %89, %18
  %91 = fdiv fast float %90, %75
  %92 = fdiv fast float %86, %75
  %93 = fdiv fast float %82, %75
  %94 = fsub fast float %91, %15
  %95 = fsub fast float %92, %16
  %96 = fsub fast float %93, %17
  %97 = fmul fast float %94, %94
  %98 = fmul fast float %95, %95
  %99 = fadd fast float %98, %97
  %100 = fmul fast float %96, %96
  %101 = fadd fast float %99, %100
  %102 = call float @dx.op.unary.f32(i32 24, float %101)  ; Sqrt(value)
  %103 = fsub fast float %102, %7
  %104 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %103)  ; FMax(a,b)
  %105 = fcmp fast ogt float %37, 1.500000e+00
  br i1 %105, label %106, label %129

; <label>:106                                     ; preds = %78
  %107 = call float @dx.op.unary.f32(i32 6, float %95)  ; FAbs(value)
  %108 = fmul fast float %107, %9
  %109 = fcmp fast olt float %108, 0x3F50624DE0000000
  br i1 %109, label %110, label %113

; <label>:110                                     ; preds = %106
  %111 = fmul fast float %108, 5.000000e-01
  %112 = fsub fast float 1.000000e+00, %111
  br label %118

; <label>:113                                     ; preds = %106
  %114 = fmul fast float %108, 0xBFF7154760000000
  %115 = call float @dx.op.unary.f32(i32 21, float %114)  ; Exp(value)
  %116 = fsub fast float 1.000000e+00, %115
  %117 = fdiv fast float %116, %108
  br label %118

; <label>:118                                     ; preds = %113, %110
  %119 = phi float [ %112, %110 ], [ %117, %113 ]
  %120 = call float @dx.op.binary.f32(i32 36, float %92, float %16)  ; FMin(a,b)
  %121 = fsub fast float %120, %8
  %122 = fmul fast float %9, %121
  %123 = fsub fast float -0.000000e+00, %122
  %124 = call float @dx.op.binary.f32(i32 35, float %123, float -4.000000e+01)  ; FMax(a,b)
  %125 = call float @dx.op.binary.f32(i32 36, float %124, float 5.000000e+00)  ; FMin(a,b)
  %126 = fmul fast float %125, 0x3FF7154760000000
  %127 = call float @dx.op.unary.f32(i32 21, float %126)  ; Exp(value)
  %128 = fmul fast float %127, %119
  br label %129

; <label>:129                                     ; preds = %118, %78
  %130 = phi float [ %128, %118 ], [ 1.000000e+00, %78 ]
  %131 = fmul fast float %104, %14
  %132 = fmul fast float %131, %130
  %133 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %132)  ; FMin(a,b)
  %134 = fmul fast float %133, 0xBFF7154760000000
  %135 = call float @dx.op.unary.f32(i32 21, float %134)  ; Exp(value)
  %136 = fsub fast float 1.000000e+00, %135
  %137 = call float @dx.op.binary.f32(i32 36, float %10, float %136)  ; FMin(a,b)
  %138 = fsub fast float %11, %46
  %139 = fsub fast float %12, %47
  %140 = fsub fast float %13, %48
  %141 = fmul fast float %137, %138
  %142 = fmul fast float %137, %139
  %143 = fmul fast float %137, %140
  %144 = fadd fast float %141, %46
  %145 = fadd fast float %142, %47
  %146 = fadd fast float %143, %48
  br label %147

; <label>:147                                     ; preds = %129, %59, %53
  %148 = phi float [ %144, %129 ], [ %46, %59 ], [ %46, %53 ]
  %149 = phi float [ %145, %129 ], [ %47, %59 ], [ %47, %53 ]
  %150 = phi float [ %146, %129 ], [ %48, %59 ], [ %48, %53 ]
  %151 = fadd fast float %3, 1.000000e+00
  %152 = fadd fast float %4, 1.000000e+00
  %153 = fsub fast float 1.000000e+00, %3
  %154 = fmul fast float %34, %151
  %155 = fmul fast float %34, %152
  %156 = fmul fast float %34, %153
  %157 = fmul fast float %154, %148
  %158 = fmul fast float %155, %149
  %159 = fmul fast float %156, %150
  %160 = fcmp fast ult float %35, 5.000000e-01
  br i1 %160, label %186, label %161

; <label>:161                                     ; preds = %147
  %162 = fmul fast float %157, 0x4004147AE0000000
  %163 = fmul fast float %158, 0x4004147AE0000000
  %164 = fmul fast float %159, 0x4004147AE0000000
  %165 = fadd fast float %162, 0x3F9EB851E0000000
  %166 = fadd fast float %163, 0x3F9EB851E0000000
  %167 = fadd fast float %164, 0x3F9EB851E0000000
  %168 = fmul fast float %165, %157
  %169 = fmul fast float %166, %158
  %170 = fmul fast float %167, %159
  %171 = fmul fast float %157, 0x400370A3E0000000
  %172 = fmul fast float %158, 0x400370A3E0000000
  %173 = fmul fast float %159, 0x400370A3E0000000
  %174 = fadd fast float %171, 0x3FE2E147A0000000
  %175 = fadd fast float %172, 0x3FE2E147A0000000
  %176 = fadd fast float %173, 0x3FE2E147A0000000
  %177 = fmul fast float %174, %157
  %178 = fmul fast float %175, %158
  %179 = fmul fast float %176, %159
  %180 = fadd fast float %177, 0x3FC1EB8520000000
  %181 = fadd fast float %178, 0x3FC1EB8520000000
  %182 = fadd fast float %179, 0x3FC1EB8520000000
  %183 = fdiv fast float %168, %180
  %184 = fdiv fast float %169, %181
  %185 = fdiv fast float %170, %182
  br label %186

; <label>:186                                     ; preds = %161, %147
  %187 = phi float [ %183, %161 ], [ %157, %147 ]
  %188 = phi float [ %184, %161 ], [ %158, %147 ]
  %189 = phi float [ %185, %161 ], [ %159, %147 ]
  %190 = call float @dx.op.unary.f32(i32 7, float %187)  ; Saturate(value)
  %191 = call float @dx.op.unary.f32(i32 7, float %188)  ; Saturate(value)
  %192 = call float @dx.op.unary.f32(i32 7, float %189)  ; Saturate(value)
  %193 = call float @dx.op.dot3.f32(i32 55, float %190, float %191, float %192, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %194 = fsub fast float %190, %193
  %195 = fsub fast float %191, %193
  %196 = fsub fast float %192, %193
  %197 = fmul fast float %194, %6
  %198 = fmul fast float %195, %6
  %199 = fmul fast float %196, %6
  %200 = fadd fast float %197, %193
  %201 = fadd fast float %198, %193
  %202 = fadd fast float %199, %193
  %203 = call float @dx.op.unary.f32(i32 7, float %200)  ; Saturate(value)
  %204 = call float @dx.op.unary.f32(i32 7, float %201)  ; Saturate(value)
  %205 = call float @dx.op.unary.f32(i32 7, float %202)  ; Saturate(value)
  %206 = fadd fast float %203, 0xBFC70A3D80000000
  %207 = fadd fast float %204, 0xBFC70A3D80000000
  %208 = fadd fast float %205, 0xBFC70A3D80000000
  %209 = fmul fast float %206, %5
  %210 = fmul fast float %207, %5
  %211 = fmul fast float %208, %5
  %212 = fadd fast float %209, 0x3FC70A3D80000000
  %213 = fadd fast float %210, 0x3FC70A3D80000000
  %214 = fadd fast float %211, 0x3FC70A3D80000000
  %215 = call float @dx.op.unary.f32(i32 7, float %212)  ; Saturate(value)
  %216 = call float @dx.op.unary.f32(i32 7, float %213)  ; Saturate(value)
  %217 = call float @dx.op.unary.f32(i32 7, float %214)  ; Saturate(value)
  %218 = add i32 %44, -1
  %219 = add i32 %41, -1
  %220 = add i32 %42, -1
  %221 = call i32 @dx.op.binary.i32(i32 37, i32 %43, i32 0)  ; IMax(a,b)
  %222 = call i32 @dx.op.binary.i32(i32 37, i32 %218, i32 0)  ; IMax(a,b)
  %223 = call i32 @dx.op.binary.i32(i32 38, i32 %221, i32 %219)  ; IMin(a,b)
  %224 = call i32 @dx.op.binary.i32(i32 38, i32 %222, i32 %220)  ; IMin(a,b)
  %225 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %223, i32 %224, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %226 = extractvalue %dx.types.ResRet.f32 %225, 0
  %227 = extractvalue %dx.types.ResRet.f32 %225, 1
  %228 = extractvalue %dx.types.ResRet.f32 %225, 2
  %229 = extractvalue %dx.types.ResRet.f32 %225, 3
  %230 = fcmp fast olt float %229, 0.000000e+00
  br i1 %230, label %231, label %265

; <label>:231                                     ; preds = %186
  %232 = fcmp fast ogt float %226, 0x3FA4B5DCC0000000
  %233 = fcmp fast ogt float %227, 0x3FA4B5DCC0000000
  %234 = fcmp fast ogt float %228, 0x3FA4B5DCC0000000
  %235 = select i1 %232, float 0.000000e+00, float 1.000000e+00
  %236 = select i1 %233, float 0.000000e+00, float 1.000000e+00
  %237 = select i1 %234, float 0.000000e+00, float 1.000000e+00
  %238 = fmul fast float %226, 0x3FB3D07220000000
  %239 = fmul fast float %227, 0x3FB3D07220000000
  %240 = fmul fast float %228, 0x3FB3D07220000000
  %241 = fadd fast float %226, 0x3FAC28F5C0000000
  %242 = fadd fast float %227, 0x3FAC28F5C0000000
  %243 = fadd fast float %228, 0x3FAC28F5C0000000
  %244 = fmul fast float %241, 0x3FEE54EDE0000000
  %245 = fmul fast float %242, 0x3FEE54EDE0000000
  %246 = fmul fast float %243, 0x3FEE54EDE0000000
  %247 = call float @dx.op.unary.f32(i32 23, float %244)  ; Log(value)
  %248 = call float @dx.op.unary.f32(i32 23, float %245)  ; Log(value)
  %249 = call float @dx.op.unary.f32(i32 23, float %246)  ; Log(value)
  %250 = fmul fast float %247, 0x4003333340000000
  %251 = fmul fast float %248, 0x4003333340000000
  %252 = fmul fast float %249, 0x4003333340000000
  %253 = call float @dx.op.unary.f32(i32 21, float %250)  ; Exp(value)
  %254 = call float @dx.op.unary.f32(i32 21, float %251)  ; Exp(value)
  %255 = call float @dx.op.unary.f32(i32 21, float %252)  ; Exp(value)
  %256 = fsub fast float %238, %253
  %257 = fsub fast float %239, %254
  %258 = fsub fast float %240, %255
  %259 = fmul fast float %256, %235
  %260 = fmul fast float %257, %236
  %261 = fmul fast float %258, %237
  %262 = fadd fast float %259, %253
  %263 = fadd fast float %260, %254
  %264 = fadd fast float %261, %255
  br label %430

; <label>:265                                     ; preds = %186
  %266 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %223, i32 %224, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %267 = extractvalue %dx.types.ResRet.f32 %266, 0
  %268 = fcmp fast ogt float %36, 5.000000e-01
  %269 = fcmp fast olt float %267, 1.000000e+00
  %270 = and i1 %268, %269
  br i1 %270, label %271, label %359

; <label>:271                                     ; preds = %265
  %272 = sitofp i32 %223 to float
  %273 = sitofp i32 %224 to float
  %274 = fadd fast float %272, 5.000000e-01
  %275 = fadd fast float %273, 5.000000e-01
  %276 = uitofp i32 %41 to float
  %277 = uitofp i32 %42 to float
  %278 = fdiv fast float %274, %276
  %279 = fdiv fast float %275, %277
  %280 = fmul fast float %278, 2.000000e+00
  %281 = fmul fast float %279, 2.000000e+00
  %282 = fadd fast float %280, -1.000000e+00
  %283 = fsub fast float 1.000000e+00, %281
  %284 = fmul fast float %282, %33
  %285 = call float @dx.op.tertiary.f32(i32 46, float %283, float %29, float %284)  ; FMad(a,b,c)
  %286 = call float @dx.op.tertiary.f32(i32 46, float %267, float %25, float %285)  ; FMad(a,b,c)
  %287 = fadd fast float %286, %21
  %288 = call float @dx.op.unary.f32(i32 6, float %287)  ; FAbs(value)
  %289 = fcmp fast ogt float %288, 0x3EB0C6F7A0000000
  br i1 %289, label %290, label %359

; <label>:290                                     ; preds = %271
  %291 = fmul fast float %282, %32
  %292 = call float @dx.op.tertiary.f32(i32 46, float %283, float %28, float %291)  ; FMad(a,b,c)
  %293 = call float @dx.op.tertiary.f32(i32 46, float %267, float %24, float %292)  ; FMad(a,b,c)
  %294 = fadd fast float %293, %20
  %295 = fmul fast float %282, %31
  %296 = call float @dx.op.tertiary.f32(i32 46, float %283, float %27, float %295)  ; FMad(a,b,c)
  %297 = call float @dx.op.tertiary.f32(i32 46, float %267, float %23, float %296)  ; FMad(a,b,c)
  %298 = fadd fast float %297, %19
  %299 = fmul fast float %282, %30
  %300 = call float @dx.op.tertiary.f32(i32 46, float %283, float %26, float %299)  ; FMad(a,b,c)
  %301 = call float @dx.op.tertiary.f32(i32 46, float %267, float %22, float %300)  ; FMad(a,b,c)
  %302 = fadd fast float %301, %18
  %303 = fdiv fast float %302, %287
  %304 = fdiv fast float %298, %287
  %305 = fdiv fast float %294, %287
  %306 = fsub fast float %303, %15
  %307 = fsub fast float %304, %16
  %308 = fsub fast float %305, %17
  %309 = fmul fast float %306, %306
  %310 = fmul fast float %307, %307
  %311 = fadd fast float %310, %309
  %312 = fmul fast float %308, %308
  %313 = fadd fast float %311, %312
  %314 = call float @dx.op.unary.f32(i32 24, float %313)  ; Sqrt(value)
  %315 = fsub fast float %314, %7
  %316 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %315)  ; FMax(a,b)
  %317 = fcmp fast ogt float %37, 1.500000e+00
  br i1 %317, label %318, label %341

; <label>:318                                     ; preds = %290
  %319 = call float @dx.op.unary.f32(i32 6, float %307)  ; FAbs(value)
  %320 = fmul fast float %319, %9
  %321 = fcmp fast olt float %320, 0x3F50624DE0000000
  br i1 %321, label %322, label %325

; <label>:322                                     ; preds = %318
  %323 = fmul fast float %320, 5.000000e-01
  %324 = fsub fast float 1.000000e+00, %323
  br label %330

; <label>:325                                     ; preds = %318
  %326 = fmul fast float %320, 0xBFF7154760000000
  %327 = call float @dx.op.unary.f32(i32 21, float %326)  ; Exp(value)
  %328 = fsub fast float 1.000000e+00, %327
  %329 = fdiv fast float %328, %320
  br label %330

; <label>:330                                     ; preds = %325, %322
  %331 = phi float [ %324, %322 ], [ %329, %325 ]
  %332 = call float @dx.op.binary.f32(i32 36, float %304, float %16)  ; FMin(a,b)
  %333 = fsub fast float %332, %8
  %334 = fmul fast float %9, %333
  %335 = fsub fast float -0.000000e+00, %334
  %336 = call float @dx.op.binary.f32(i32 35, float %335, float -4.000000e+01)  ; FMax(a,b)
  %337 = call float @dx.op.binary.f32(i32 36, float %336, float 5.000000e+00)  ; FMin(a,b)
  %338 = fmul fast float %337, 0x3FF7154760000000
  %339 = call float @dx.op.unary.f32(i32 21, float %338)  ; Exp(value)
  %340 = fmul fast float %339, %331
  br label %341

; <label>:341                                     ; preds = %330, %290
  %342 = phi float [ %340, %330 ], [ 1.000000e+00, %290 ]
  %343 = fmul fast float %316, %14
  %344 = fmul fast float %343, %342
  %345 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %344)  ; FMin(a,b)
  %346 = fmul fast float %345, 0xBFF7154760000000
  %347 = call float @dx.op.unary.f32(i32 21, float %346)  ; Exp(value)
  %348 = fsub fast float 1.000000e+00, %347
  %349 = call float @dx.op.binary.f32(i32 36, float %10, float %348)  ; FMin(a,b)
  %350 = fsub fast float %11, %226
  %351 = fsub fast float %12, %227
  %352 = fsub fast float %13, %228
  %353 = fmul fast float %349, %350
  %354 = fmul fast float %349, %351
  %355 = fmul fast float %349, %352
  %356 = fadd fast float %353, %226
  %357 = fadd fast float %354, %227
  %358 = fadd fast float %355, %228
  br label %359

; <label>:359                                     ; preds = %341, %271, %265
  %360 = phi float [ %356, %341 ], [ %226, %271 ], [ %226, %265 ]
  %361 = phi float [ %357, %341 ], [ %227, %271 ], [ %227, %265 ]
  %362 = phi float [ %358, %341 ], [ %228, %271 ], [ %228, %265 ]
  %363 = fadd fast float %3, 1.000000e+00
  %364 = fadd fast float %4, 1.000000e+00
  %365 = fsub fast float 1.000000e+00, %3
  %366 = fmul fast float %34, %363
  %367 = fmul fast float %34, %364
  %368 = fmul fast float %34, %365
  %369 = fmul fast float %366, %360
  %370 = fmul fast float %367, %361
  %371 = fmul fast float %368, %362
  %372 = fcmp fast ult float %35, 5.000000e-01
  br i1 %372, label %398, label %373

; <label>:373                                     ; preds = %359
  %374 = fmul fast float %369, 0x4004147AE0000000
  %375 = fmul fast float %370, 0x4004147AE0000000
  %376 = fmul fast float %371, 0x4004147AE0000000
  %377 = fadd fast float %374, 0x3F9EB851E0000000
  %378 = fadd fast float %375, 0x3F9EB851E0000000
  %379 = fadd fast float %376, 0x3F9EB851E0000000
  %380 = fmul fast float %377, %369
  %381 = fmul fast float %378, %370
  %382 = fmul fast float %379, %371
  %383 = fmul fast float %369, 0x400370A3E0000000
  %384 = fmul fast float %370, 0x400370A3E0000000
  %385 = fmul fast float %371, 0x400370A3E0000000
  %386 = fadd fast float %383, 0x3FE2E147A0000000
  %387 = fadd fast float %384, 0x3FE2E147A0000000
  %388 = fadd fast float %385, 0x3FE2E147A0000000
  %389 = fmul fast float %386, %369
  %390 = fmul fast float %387, %370
  %391 = fmul fast float %388, %371
  %392 = fadd fast float %389, 0x3FC1EB8520000000
  %393 = fadd fast float %390, 0x3FC1EB8520000000
  %394 = fadd fast float %391, 0x3FC1EB8520000000
  %395 = fdiv fast float %380, %392
  %396 = fdiv fast float %381, %393
  %397 = fdiv fast float %382, %394
  br label %398

; <label>:398                                     ; preds = %373, %359
  %399 = phi float [ %395, %373 ], [ %369, %359 ]
  %400 = phi float [ %396, %373 ], [ %370, %359 ]
  %401 = phi float [ %397, %373 ], [ %371, %359 ]
  %402 = call float @dx.op.unary.f32(i32 7, float %399)  ; Saturate(value)
  %403 = call float @dx.op.unary.f32(i32 7, float %400)  ; Saturate(value)
  %404 = call float @dx.op.unary.f32(i32 7, float %401)  ; Saturate(value)
  %405 = call float @dx.op.dot3.f32(i32 55, float %402, float %403, float %404, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %406 = fsub fast float %402, %405
  %407 = fsub fast float %403, %405
  %408 = fsub fast float %404, %405
  %409 = fmul fast float %406, %6
  %410 = fmul fast float %407, %6
  %411 = fmul fast float %408, %6
  %412 = fadd fast float %409, %405
  %413 = fadd fast float %410, %405
  %414 = fadd fast float %411, %405
  %415 = call float @dx.op.unary.f32(i32 7, float %412)  ; Saturate(value)
  %416 = call float @dx.op.unary.f32(i32 7, float %413)  ; Saturate(value)
  %417 = call float @dx.op.unary.f32(i32 7, float %414)  ; Saturate(value)
  %418 = fadd fast float %415, 0xBFC70A3D80000000
  %419 = fadd fast float %416, 0xBFC70A3D80000000
  %420 = fadd fast float %417, 0xBFC70A3D80000000
  %421 = fmul fast float %418, %5
  %422 = fmul fast float %419, %5
  %423 = fmul fast float %420, %5
  %424 = fadd fast float %421, 0x3FC70A3D80000000
  %425 = fadd fast float %422, 0x3FC70A3D80000000
  %426 = fadd fast float %423, 0x3FC70A3D80000000
  %427 = call float @dx.op.unary.f32(i32 7, float %424)  ; Saturate(value)
  %428 = call float @dx.op.unary.f32(i32 7, float %425)  ; Saturate(value)
  %429 = call float @dx.op.unary.f32(i32 7, float %426)  ; Saturate(value)
  br label %430

; <label>:430                                     ; preds = %398, %231
  %431 = phi float [ %262, %231 ], [ %427, %398 ]
  %432 = phi float [ %263, %231 ], [ %428, %398 ]
  %433 = phi float [ %264, %231 ], [ %429, %398 ]
  %434 = add i32 %44, 1
  %435 = call i32 @dx.op.binary.i32(i32 37, i32 %434, i32 0)  ; IMax(a,b)
  %436 = call i32 @dx.op.binary.i32(i32 38, i32 %435, i32 %220)  ; IMin(a,b)
  %437 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %223, i32 %436, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %438 = extractvalue %dx.types.ResRet.f32 %437, 0
  %439 = extractvalue %dx.types.ResRet.f32 %437, 1
  %440 = extractvalue %dx.types.ResRet.f32 %437, 2
  %441 = extractvalue %dx.types.ResRet.f32 %437, 3
  %442 = fcmp fast olt float %441, 0.000000e+00
  br i1 %442, label %443, label %477

; <label>:443                                     ; preds = %430
  %444 = fcmp fast ogt float %438, 0x3FA4B5DCC0000000
  %445 = fcmp fast ogt float %439, 0x3FA4B5DCC0000000
  %446 = fcmp fast ogt float %440, 0x3FA4B5DCC0000000
  %447 = select i1 %444, float 0.000000e+00, float 1.000000e+00
  %448 = select i1 %445, float 0.000000e+00, float 1.000000e+00
  %449 = select i1 %446, float 0.000000e+00, float 1.000000e+00
  %450 = fmul fast float %438, 0x3FB3D07220000000
  %451 = fmul fast float %439, 0x3FB3D07220000000
  %452 = fmul fast float %440, 0x3FB3D07220000000
  %453 = fadd fast float %438, 0x3FAC28F5C0000000
  %454 = fadd fast float %439, 0x3FAC28F5C0000000
  %455 = fadd fast float %440, 0x3FAC28F5C0000000
  %456 = fmul fast float %453, 0x3FEE54EDE0000000
  %457 = fmul fast float %454, 0x3FEE54EDE0000000
  %458 = fmul fast float %455, 0x3FEE54EDE0000000
  %459 = call float @dx.op.unary.f32(i32 23, float %456)  ; Log(value)
  %460 = call float @dx.op.unary.f32(i32 23, float %457)  ; Log(value)
  %461 = call float @dx.op.unary.f32(i32 23, float %458)  ; Log(value)
  %462 = fmul fast float %459, 0x4003333340000000
  %463 = fmul fast float %460, 0x4003333340000000
  %464 = fmul fast float %461, 0x4003333340000000
  %465 = call float @dx.op.unary.f32(i32 21, float %462)  ; Exp(value)
  %466 = call float @dx.op.unary.f32(i32 21, float %463)  ; Exp(value)
  %467 = call float @dx.op.unary.f32(i32 21, float %464)  ; Exp(value)
  %468 = fsub fast float %450, %465
  %469 = fsub fast float %451, %466
  %470 = fsub fast float %452, %467
  %471 = fmul fast float %468, %447
  %472 = fmul fast float %469, %448
  %473 = fmul fast float %470, %449
  %474 = fadd fast float %471, %465
  %475 = fadd fast float %472, %466
  %476 = fadd fast float %473, %467
  br label %642

; <label>:477                                     ; preds = %430
  %478 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %223, i32 %436, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %479 = extractvalue %dx.types.ResRet.f32 %478, 0
  %480 = fcmp fast ogt float %36, 5.000000e-01
  %481 = fcmp fast olt float %479, 1.000000e+00
  %482 = and i1 %480, %481
  br i1 %482, label %483, label %571

; <label>:483                                     ; preds = %477
  %484 = sitofp i32 %223 to float
  %485 = sitofp i32 %436 to float
  %486 = fadd fast float %484, 5.000000e-01
  %487 = fadd fast float %485, 5.000000e-01
  %488 = uitofp i32 %41 to float
  %489 = uitofp i32 %42 to float
  %490 = fdiv fast float %486, %488
  %491 = fdiv fast float %487, %489
  %492 = fmul fast float %490, 2.000000e+00
  %493 = fmul fast float %491, 2.000000e+00
  %494 = fadd fast float %492, -1.000000e+00
  %495 = fsub fast float 1.000000e+00, %493
  %496 = fmul fast float %494, %33
  %497 = call float @dx.op.tertiary.f32(i32 46, float %495, float %29, float %496)  ; FMad(a,b,c)
  %498 = call float @dx.op.tertiary.f32(i32 46, float %479, float %25, float %497)  ; FMad(a,b,c)
  %499 = fadd fast float %498, %21
  %500 = call float @dx.op.unary.f32(i32 6, float %499)  ; FAbs(value)
  %501 = fcmp fast ogt float %500, 0x3EB0C6F7A0000000
  br i1 %501, label %502, label %571

; <label>:502                                     ; preds = %483
  %503 = fmul fast float %494, %32
  %504 = call float @dx.op.tertiary.f32(i32 46, float %495, float %28, float %503)  ; FMad(a,b,c)
  %505 = call float @dx.op.tertiary.f32(i32 46, float %479, float %24, float %504)  ; FMad(a,b,c)
  %506 = fadd fast float %505, %20
  %507 = fmul fast float %494, %31
  %508 = call float @dx.op.tertiary.f32(i32 46, float %495, float %27, float %507)  ; FMad(a,b,c)
  %509 = call float @dx.op.tertiary.f32(i32 46, float %479, float %23, float %508)  ; FMad(a,b,c)
  %510 = fadd fast float %509, %19
  %511 = fmul fast float %494, %30
  %512 = call float @dx.op.tertiary.f32(i32 46, float %495, float %26, float %511)  ; FMad(a,b,c)
  %513 = call float @dx.op.tertiary.f32(i32 46, float %479, float %22, float %512)  ; FMad(a,b,c)
  %514 = fadd fast float %513, %18
  %515 = fdiv fast float %514, %499
  %516 = fdiv fast float %510, %499
  %517 = fdiv fast float %506, %499
  %518 = fsub fast float %515, %15
  %519 = fsub fast float %516, %16
  %520 = fsub fast float %517, %17
  %521 = fmul fast float %518, %518
  %522 = fmul fast float %519, %519
  %523 = fadd fast float %522, %521
  %524 = fmul fast float %520, %520
  %525 = fadd fast float %523, %524
  %526 = call float @dx.op.unary.f32(i32 24, float %525)  ; Sqrt(value)
  %527 = fsub fast float %526, %7
  %528 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %527)  ; FMax(a,b)
  %529 = fcmp fast ogt float %37, 1.500000e+00
  br i1 %529, label %530, label %553

; <label>:530                                     ; preds = %502
  %531 = call float @dx.op.unary.f32(i32 6, float %519)  ; FAbs(value)
  %532 = fmul fast float %531, %9
  %533 = fcmp fast olt float %532, 0x3F50624DE0000000
  br i1 %533, label %534, label %537

; <label>:534                                     ; preds = %530
  %535 = fmul fast float %532, 5.000000e-01
  %536 = fsub fast float 1.000000e+00, %535
  br label %542

; <label>:537                                     ; preds = %530
  %538 = fmul fast float %532, 0xBFF7154760000000
  %539 = call float @dx.op.unary.f32(i32 21, float %538)  ; Exp(value)
  %540 = fsub fast float 1.000000e+00, %539
  %541 = fdiv fast float %540, %532
  br label %542

; <label>:542                                     ; preds = %537, %534
  %543 = phi float [ %536, %534 ], [ %541, %537 ]
  %544 = call float @dx.op.binary.f32(i32 36, float %516, float %16)  ; FMin(a,b)
  %545 = fsub fast float %544, %8
  %546 = fmul fast float %9, %545
  %547 = fsub fast float -0.000000e+00, %546
  %548 = call float @dx.op.binary.f32(i32 35, float %547, float -4.000000e+01)  ; FMax(a,b)
  %549 = call float @dx.op.binary.f32(i32 36, float %548, float 5.000000e+00)  ; FMin(a,b)
  %550 = fmul fast float %549, 0x3FF7154760000000
  %551 = call float @dx.op.unary.f32(i32 21, float %550)  ; Exp(value)
  %552 = fmul fast float %551, %543
  br label %553

; <label>:553                                     ; preds = %542, %502
  %554 = phi float [ %552, %542 ], [ 1.000000e+00, %502 ]
  %555 = fmul fast float %528, %14
  %556 = fmul fast float %555, %554
  %557 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %556)  ; FMin(a,b)
  %558 = fmul fast float %557, 0xBFF7154760000000
  %559 = call float @dx.op.unary.f32(i32 21, float %558)  ; Exp(value)
  %560 = fsub fast float 1.000000e+00, %559
  %561 = call float @dx.op.binary.f32(i32 36, float %10, float %560)  ; FMin(a,b)
  %562 = fsub fast float %11, %438
  %563 = fsub fast float %12, %439
  %564 = fsub fast float %13, %440
  %565 = fmul fast float %561, %562
  %566 = fmul fast float %561, %563
  %567 = fmul fast float %561, %564
  %568 = fadd fast float %565, %438
  %569 = fadd fast float %566, %439
  %570 = fadd fast float %567, %440
  br label %571

; <label>:571                                     ; preds = %553, %483, %477
  %572 = phi float [ %568, %553 ], [ %438, %483 ], [ %438, %477 ]
  %573 = phi float [ %569, %553 ], [ %439, %483 ], [ %439, %477 ]
  %574 = phi float [ %570, %553 ], [ %440, %483 ], [ %440, %477 ]
  %575 = fadd fast float %3, 1.000000e+00
  %576 = fadd fast float %4, 1.000000e+00
  %577 = fsub fast float 1.000000e+00, %3
  %578 = fmul fast float %34, %575
  %579 = fmul fast float %34, %576
  %580 = fmul fast float %34, %577
  %581 = fmul fast float %578, %572
  %582 = fmul fast float %579, %573
  %583 = fmul fast float %580, %574
  %584 = fcmp fast ult float %35, 5.000000e-01
  br i1 %584, label %610, label %585

; <label>:585                                     ; preds = %571
  %586 = fmul fast float %581, 0x4004147AE0000000
  %587 = fmul fast float %582, 0x4004147AE0000000
  %588 = fmul fast float %583, 0x4004147AE0000000
  %589 = fadd fast float %586, 0x3F9EB851E0000000
  %590 = fadd fast float %587, 0x3F9EB851E0000000
  %591 = fadd fast float %588, 0x3F9EB851E0000000
  %592 = fmul fast float %589, %581
  %593 = fmul fast float %590, %582
  %594 = fmul fast float %591, %583
  %595 = fmul fast float %581, 0x400370A3E0000000
  %596 = fmul fast float %582, 0x400370A3E0000000
  %597 = fmul fast float %583, 0x400370A3E0000000
  %598 = fadd fast float %595, 0x3FE2E147A0000000
  %599 = fadd fast float %596, 0x3FE2E147A0000000
  %600 = fadd fast float %597, 0x3FE2E147A0000000
  %601 = fmul fast float %598, %581
  %602 = fmul fast float %599, %582
  %603 = fmul fast float %600, %583
  %604 = fadd fast float %601, 0x3FC1EB8520000000
  %605 = fadd fast float %602, 0x3FC1EB8520000000
  %606 = fadd fast float %603, 0x3FC1EB8520000000
  %607 = fdiv fast float %592, %604
  %608 = fdiv fast float %593, %605
  %609 = fdiv fast float %594, %606
  br label %610

; <label>:610                                     ; preds = %585, %571
  %611 = phi float [ %607, %585 ], [ %581, %571 ]
  %612 = phi float [ %608, %585 ], [ %582, %571 ]
  %613 = phi float [ %609, %585 ], [ %583, %571 ]
  %614 = call float @dx.op.unary.f32(i32 7, float %611)  ; Saturate(value)
  %615 = call float @dx.op.unary.f32(i32 7, float %612)  ; Saturate(value)
  %616 = call float @dx.op.unary.f32(i32 7, float %613)  ; Saturate(value)
  %617 = call float @dx.op.dot3.f32(i32 55, float %614, float %615, float %616, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %618 = fsub fast float %614, %617
  %619 = fsub fast float %615, %617
  %620 = fsub fast float %616, %617
  %621 = fmul fast float %618, %6
  %622 = fmul fast float %619, %6
  %623 = fmul fast float %620, %6
  %624 = fadd fast float %621, %617
  %625 = fadd fast float %622, %617
  %626 = fadd fast float %623, %617
  %627 = call float @dx.op.unary.f32(i32 7, float %624)  ; Saturate(value)
  %628 = call float @dx.op.unary.f32(i32 7, float %625)  ; Saturate(value)
  %629 = call float @dx.op.unary.f32(i32 7, float %626)  ; Saturate(value)
  %630 = fadd fast float %627, 0xBFC70A3D80000000
  %631 = fadd fast float %628, 0xBFC70A3D80000000
  %632 = fadd fast float %629, 0xBFC70A3D80000000
  %633 = fmul fast float %630, %5
  %634 = fmul fast float %631, %5
  %635 = fmul fast float %632, %5
  %636 = fadd fast float %633, 0x3FC70A3D80000000
  %637 = fadd fast float %634, 0x3FC70A3D80000000
  %638 = fadd fast float %635, 0x3FC70A3D80000000
  %639 = call float @dx.op.unary.f32(i32 7, float %636)  ; Saturate(value)
  %640 = call float @dx.op.unary.f32(i32 7, float %637)  ; Saturate(value)
  %641 = call float @dx.op.unary.f32(i32 7, float %638)  ; Saturate(value)
  br label %642

; <label>:642                                     ; preds = %610, %443
  %643 = phi float [ %474, %443 ], [ %639, %610 ]
  %644 = phi float [ %475, %443 ], [ %640, %610 ]
  %645 = phi float [ %476, %443 ], [ %641, %610 ]
  %646 = add i32 %43, -1
  %647 = call i32 @dx.op.binary.i32(i32 37, i32 %646, i32 0)  ; IMax(a,b)
  %648 = call i32 @dx.op.binary.i32(i32 37, i32 %44, i32 0)  ; IMax(a,b)
  %649 = call i32 @dx.op.binary.i32(i32 38, i32 %647, i32 %219)  ; IMin(a,b)
  %650 = call i32 @dx.op.binary.i32(i32 38, i32 %648, i32 %220)  ; IMin(a,b)
  %651 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %649, i32 %650, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %652 = extractvalue %dx.types.ResRet.f32 %651, 0
  %653 = extractvalue %dx.types.ResRet.f32 %651, 1
  %654 = extractvalue %dx.types.ResRet.f32 %651, 2
  %655 = extractvalue %dx.types.ResRet.f32 %651, 3
  %656 = fcmp fast olt float %655, 0.000000e+00
  br i1 %656, label %657, label %691

; <label>:657                                     ; preds = %642
  %658 = fcmp fast ogt float %652, 0x3FA4B5DCC0000000
  %659 = fcmp fast ogt float %653, 0x3FA4B5DCC0000000
  %660 = fcmp fast ogt float %654, 0x3FA4B5DCC0000000
  %661 = select i1 %658, float 0.000000e+00, float 1.000000e+00
  %662 = select i1 %659, float 0.000000e+00, float 1.000000e+00
  %663 = select i1 %660, float 0.000000e+00, float 1.000000e+00
  %664 = fmul fast float %652, 0x3FB3D07220000000
  %665 = fmul fast float %653, 0x3FB3D07220000000
  %666 = fmul fast float %654, 0x3FB3D07220000000
  %667 = fadd fast float %652, 0x3FAC28F5C0000000
  %668 = fadd fast float %653, 0x3FAC28F5C0000000
  %669 = fadd fast float %654, 0x3FAC28F5C0000000
  %670 = fmul fast float %667, 0x3FEE54EDE0000000
  %671 = fmul fast float %668, 0x3FEE54EDE0000000
  %672 = fmul fast float %669, 0x3FEE54EDE0000000
  %673 = call float @dx.op.unary.f32(i32 23, float %670)  ; Log(value)
  %674 = call float @dx.op.unary.f32(i32 23, float %671)  ; Log(value)
  %675 = call float @dx.op.unary.f32(i32 23, float %672)  ; Log(value)
  %676 = fmul fast float %673, 0x4003333340000000
  %677 = fmul fast float %674, 0x4003333340000000
  %678 = fmul fast float %675, 0x4003333340000000
  %679 = call float @dx.op.unary.f32(i32 21, float %676)  ; Exp(value)
  %680 = call float @dx.op.unary.f32(i32 21, float %677)  ; Exp(value)
  %681 = call float @dx.op.unary.f32(i32 21, float %678)  ; Exp(value)
  %682 = fsub fast float %664, %679
  %683 = fsub fast float %665, %680
  %684 = fsub fast float %666, %681
  %685 = fmul fast float %682, %661
  %686 = fmul fast float %683, %662
  %687 = fmul fast float %684, %663
  %688 = fadd fast float %685, %679
  %689 = fadd fast float %686, %680
  %690 = fadd fast float %687, %681
  br label %856

; <label>:691                                     ; preds = %642
  %692 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %649, i32 %650, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %693 = extractvalue %dx.types.ResRet.f32 %692, 0
  %694 = fcmp fast ogt float %36, 5.000000e-01
  %695 = fcmp fast olt float %693, 1.000000e+00
  %696 = and i1 %694, %695
  br i1 %696, label %697, label %785

; <label>:697                                     ; preds = %691
  %698 = sitofp i32 %649 to float
  %699 = sitofp i32 %650 to float
  %700 = fadd fast float %698, 5.000000e-01
  %701 = fadd fast float %699, 5.000000e-01
  %702 = uitofp i32 %41 to float
  %703 = uitofp i32 %42 to float
  %704 = fdiv fast float %700, %702
  %705 = fdiv fast float %701, %703
  %706 = fmul fast float %704, 2.000000e+00
  %707 = fmul fast float %705, 2.000000e+00
  %708 = fadd fast float %706, -1.000000e+00
  %709 = fsub fast float 1.000000e+00, %707
  %710 = fmul fast float %708, %33
  %711 = call float @dx.op.tertiary.f32(i32 46, float %709, float %29, float %710)  ; FMad(a,b,c)
  %712 = call float @dx.op.tertiary.f32(i32 46, float %693, float %25, float %711)  ; FMad(a,b,c)
  %713 = fadd fast float %712, %21
  %714 = call float @dx.op.unary.f32(i32 6, float %713)  ; FAbs(value)
  %715 = fcmp fast ogt float %714, 0x3EB0C6F7A0000000
  br i1 %715, label %716, label %785

; <label>:716                                     ; preds = %697
  %717 = fmul fast float %708, %32
  %718 = call float @dx.op.tertiary.f32(i32 46, float %709, float %28, float %717)  ; FMad(a,b,c)
  %719 = call float @dx.op.tertiary.f32(i32 46, float %693, float %24, float %718)  ; FMad(a,b,c)
  %720 = fadd fast float %719, %20
  %721 = fmul fast float %708, %31
  %722 = call float @dx.op.tertiary.f32(i32 46, float %709, float %27, float %721)  ; FMad(a,b,c)
  %723 = call float @dx.op.tertiary.f32(i32 46, float %693, float %23, float %722)  ; FMad(a,b,c)
  %724 = fadd fast float %723, %19
  %725 = fmul fast float %708, %30
  %726 = call float @dx.op.tertiary.f32(i32 46, float %709, float %26, float %725)  ; FMad(a,b,c)
  %727 = call float @dx.op.tertiary.f32(i32 46, float %693, float %22, float %726)  ; FMad(a,b,c)
  %728 = fadd fast float %727, %18
  %729 = fdiv fast float %728, %713
  %730 = fdiv fast float %724, %713
  %731 = fdiv fast float %720, %713
  %732 = fsub fast float %729, %15
  %733 = fsub fast float %730, %16
  %734 = fsub fast float %731, %17
  %735 = fmul fast float %732, %732
  %736 = fmul fast float %733, %733
  %737 = fadd fast float %736, %735
  %738 = fmul fast float %734, %734
  %739 = fadd fast float %737, %738
  %740 = call float @dx.op.unary.f32(i32 24, float %739)  ; Sqrt(value)
  %741 = fsub fast float %740, %7
  %742 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %741)  ; FMax(a,b)
  %743 = fcmp fast ogt float %37, 1.500000e+00
  br i1 %743, label %744, label %767

; <label>:744                                     ; preds = %716
  %745 = call float @dx.op.unary.f32(i32 6, float %733)  ; FAbs(value)
  %746 = fmul fast float %745, %9
  %747 = fcmp fast olt float %746, 0x3F50624DE0000000
  br i1 %747, label %748, label %751

; <label>:748                                     ; preds = %744
  %749 = fmul fast float %746, 5.000000e-01
  %750 = fsub fast float 1.000000e+00, %749
  br label %756

; <label>:751                                     ; preds = %744
  %752 = fmul fast float %746, 0xBFF7154760000000
  %753 = call float @dx.op.unary.f32(i32 21, float %752)  ; Exp(value)
  %754 = fsub fast float 1.000000e+00, %753
  %755 = fdiv fast float %754, %746
  br label %756

; <label>:756                                     ; preds = %751, %748
  %757 = phi float [ %750, %748 ], [ %755, %751 ]
  %758 = call float @dx.op.binary.f32(i32 36, float %730, float %16)  ; FMin(a,b)
  %759 = fsub fast float %758, %8
  %760 = fmul fast float %9, %759
  %761 = fsub fast float -0.000000e+00, %760
  %762 = call float @dx.op.binary.f32(i32 35, float %761, float -4.000000e+01)  ; FMax(a,b)
  %763 = call float @dx.op.binary.f32(i32 36, float %762, float 5.000000e+00)  ; FMin(a,b)
  %764 = fmul fast float %763, 0x3FF7154760000000
  %765 = call float @dx.op.unary.f32(i32 21, float %764)  ; Exp(value)
  %766 = fmul fast float %765, %757
  br label %767

; <label>:767                                     ; preds = %756, %716
  %768 = phi float [ %766, %756 ], [ 1.000000e+00, %716 ]
  %769 = fmul fast float %742, %14
  %770 = fmul fast float %769, %768
  %771 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %770)  ; FMin(a,b)
  %772 = fmul fast float %771, 0xBFF7154760000000
  %773 = call float @dx.op.unary.f32(i32 21, float %772)  ; Exp(value)
  %774 = fsub fast float 1.000000e+00, %773
  %775 = call float @dx.op.binary.f32(i32 36, float %10, float %774)  ; FMin(a,b)
  %776 = fsub fast float %11, %652
  %777 = fsub fast float %12, %653
  %778 = fsub fast float %13, %654
  %779 = fmul fast float %775, %776
  %780 = fmul fast float %775, %777
  %781 = fmul fast float %775, %778
  %782 = fadd fast float %779, %652
  %783 = fadd fast float %780, %653
  %784 = fadd fast float %781, %654
  br label %785

; <label>:785                                     ; preds = %767, %697, %691
  %786 = phi float [ %782, %767 ], [ %652, %697 ], [ %652, %691 ]
  %787 = phi float [ %783, %767 ], [ %653, %697 ], [ %653, %691 ]
  %788 = phi float [ %784, %767 ], [ %654, %697 ], [ %654, %691 ]
  %789 = fadd fast float %3, 1.000000e+00
  %790 = fadd fast float %4, 1.000000e+00
  %791 = fsub fast float 1.000000e+00, %3
  %792 = fmul fast float %34, %789
  %793 = fmul fast float %34, %790
  %794 = fmul fast float %34, %791
  %795 = fmul fast float %792, %786
  %796 = fmul fast float %793, %787
  %797 = fmul fast float %794, %788
  %798 = fcmp fast ult float %35, 5.000000e-01
  br i1 %798, label %824, label %799

; <label>:799                                     ; preds = %785
  %800 = fmul fast float %795, 0x4004147AE0000000
  %801 = fmul fast float %796, 0x4004147AE0000000
  %802 = fmul fast float %797, 0x4004147AE0000000
  %803 = fadd fast float %800, 0x3F9EB851E0000000
  %804 = fadd fast float %801, 0x3F9EB851E0000000
  %805 = fadd fast float %802, 0x3F9EB851E0000000
  %806 = fmul fast float %803, %795
  %807 = fmul fast float %804, %796
  %808 = fmul fast float %805, %797
  %809 = fmul fast float %795, 0x400370A3E0000000
  %810 = fmul fast float %796, 0x400370A3E0000000
  %811 = fmul fast float %797, 0x400370A3E0000000
  %812 = fadd fast float %809, 0x3FE2E147A0000000
  %813 = fadd fast float %810, 0x3FE2E147A0000000
  %814 = fadd fast float %811, 0x3FE2E147A0000000
  %815 = fmul fast float %812, %795
  %816 = fmul fast float %813, %796
  %817 = fmul fast float %814, %797
  %818 = fadd fast float %815, 0x3FC1EB8520000000
  %819 = fadd fast float %816, 0x3FC1EB8520000000
  %820 = fadd fast float %817, 0x3FC1EB8520000000
  %821 = fdiv fast float %806, %818
  %822 = fdiv fast float %807, %819
  %823 = fdiv fast float %808, %820
  br label %824

; <label>:824                                     ; preds = %799, %785
  %825 = phi float [ %821, %799 ], [ %795, %785 ]
  %826 = phi float [ %822, %799 ], [ %796, %785 ]
  %827 = phi float [ %823, %799 ], [ %797, %785 ]
  %828 = call float @dx.op.unary.f32(i32 7, float %825)  ; Saturate(value)
  %829 = call float @dx.op.unary.f32(i32 7, float %826)  ; Saturate(value)
  %830 = call float @dx.op.unary.f32(i32 7, float %827)  ; Saturate(value)
  %831 = call float @dx.op.dot3.f32(i32 55, float %828, float %829, float %830, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %832 = fsub fast float %828, %831
  %833 = fsub fast float %829, %831
  %834 = fsub fast float %830, %831
  %835 = fmul fast float %832, %6
  %836 = fmul fast float %833, %6
  %837 = fmul fast float %834, %6
  %838 = fadd fast float %835, %831
  %839 = fadd fast float %836, %831
  %840 = fadd fast float %837, %831
  %841 = call float @dx.op.unary.f32(i32 7, float %838)  ; Saturate(value)
  %842 = call float @dx.op.unary.f32(i32 7, float %839)  ; Saturate(value)
  %843 = call float @dx.op.unary.f32(i32 7, float %840)  ; Saturate(value)
  %844 = fadd fast float %841, 0xBFC70A3D80000000
  %845 = fadd fast float %842, 0xBFC70A3D80000000
  %846 = fadd fast float %843, 0xBFC70A3D80000000
  %847 = fmul fast float %844, %5
  %848 = fmul fast float %845, %5
  %849 = fmul fast float %846, %5
  %850 = fadd fast float %847, 0x3FC70A3D80000000
  %851 = fadd fast float %848, 0x3FC70A3D80000000
  %852 = fadd fast float %849, 0x3FC70A3D80000000
  %853 = call float @dx.op.unary.f32(i32 7, float %850)  ; Saturate(value)
  %854 = call float @dx.op.unary.f32(i32 7, float %851)  ; Saturate(value)
  %855 = call float @dx.op.unary.f32(i32 7, float %852)  ; Saturate(value)
  br label %856

; <label>:856                                     ; preds = %824, %657
  %857 = phi float [ %688, %657 ], [ %853, %824 ]
  %858 = phi float [ %689, %657 ], [ %854, %824 ]
  %859 = phi float [ %690, %657 ], [ %855, %824 ]
  %860 = add i32 %43, 1
  %861 = call i32 @dx.op.binary.i32(i32 37, i32 %860, i32 0)  ; IMax(a,b)
  %862 = call i32 @dx.op.binary.i32(i32 38, i32 %861, i32 %219)  ; IMin(a,b)
  %863 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %862, i32 %650, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %864 = extractvalue %dx.types.ResRet.f32 %863, 0
  %865 = extractvalue %dx.types.ResRet.f32 %863, 1
  %866 = extractvalue %dx.types.ResRet.f32 %863, 2
  %867 = extractvalue %dx.types.ResRet.f32 %863, 3
  %868 = fcmp fast olt float %867, 0.000000e+00
  br i1 %868, label %869, label %903

; <label>:869                                     ; preds = %856
  %870 = fcmp fast ogt float %864, 0x3FA4B5DCC0000000
  %871 = fcmp fast ogt float %865, 0x3FA4B5DCC0000000
  %872 = fcmp fast ogt float %866, 0x3FA4B5DCC0000000
  %873 = select i1 %870, float 0.000000e+00, float 1.000000e+00
  %874 = select i1 %871, float 0.000000e+00, float 1.000000e+00
  %875 = select i1 %872, float 0.000000e+00, float 1.000000e+00
  %876 = fmul fast float %864, 0x3FB3D07220000000
  %877 = fmul fast float %865, 0x3FB3D07220000000
  %878 = fmul fast float %866, 0x3FB3D07220000000
  %879 = fadd fast float %864, 0x3FAC28F5C0000000
  %880 = fadd fast float %865, 0x3FAC28F5C0000000
  %881 = fadd fast float %866, 0x3FAC28F5C0000000
  %882 = fmul fast float %879, 0x3FEE54EDE0000000
  %883 = fmul fast float %880, 0x3FEE54EDE0000000
  %884 = fmul fast float %881, 0x3FEE54EDE0000000
  %885 = call float @dx.op.unary.f32(i32 23, float %882)  ; Log(value)
  %886 = call float @dx.op.unary.f32(i32 23, float %883)  ; Log(value)
  %887 = call float @dx.op.unary.f32(i32 23, float %884)  ; Log(value)
  %888 = fmul fast float %885, 0x4003333340000000
  %889 = fmul fast float %886, 0x4003333340000000
  %890 = fmul fast float %887, 0x4003333340000000
  %891 = call float @dx.op.unary.f32(i32 21, float %888)  ; Exp(value)
  %892 = call float @dx.op.unary.f32(i32 21, float %889)  ; Exp(value)
  %893 = call float @dx.op.unary.f32(i32 21, float %890)  ; Exp(value)
  %894 = fsub fast float %876, %891
  %895 = fsub fast float %877, %892
  %896 = fsub fast float %878, %893
  %897 = fmul fast float %894, %873
  %898 = fmul fast float %895, %874
  %899 = fmul fast float %896, %875
  %900 = fadd fast float %897, %891
  %901 = fadd fast float %898, %892
  %902 = fadd fast float %899, %893
  br label %1068

; <label>:903                                     ; preds = %856
  %904 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %862, i32 %650, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %905 = extractvalue %dx.types.ResRet.f32 %904, 0
  %906 = fcmp fast ogt float %36, 5.000000e-01
  %907 = fcmp fast olt float %905, 1.000000e+00
  %908 = and i1 %906, %907
  br i1 %908, label %909, label %997

; <label>:909                                     ; preds = %903
  %910 = sitofp i32 %862 to float
  %911 = sitofp i32 %650 to float
  %912 = fadd fast float %910, 5.000000e-01
  %913 = fadd fast float %911, 5.000000e-01
  %914 = uitofp i32 %41 to float
  %915 = uitofp i32 %42 to float
  %916 = fdiv fast float %912, %914
  %917 = fdiv fast float %913, %915
  %918 = fmul fast float %916, 2.000000e+00
  %919 = fmul fast float %917, 2.000000e+00
  %920 = fadd fast float %918, -1.000000e+00
  %921 = fsub fast float 1.000000e+00, %919
  %922 = fmul fast float %920, %33
  %923 = call float @dx.op.tertiary.f32(i32 46, float %921, float %29, float %922)  ; FMad(a,b,c)
  %924 = call float @dx.op.tertiary.f32(i32 46, float %905, float %25, float %923)  ; FMad(a,b,c)
  %925 = fadd fast float %924, %21
  %926 = call float @dx.op.unary.f32(i32 6, float %925)  ; FAbs(value)
  %927 = fcmp fast ogt float %926, 0x3EB0C6F7A0000000
  br i1 %927, label %928, label %997

; <label>:928                                     ; preds = %909
  %929 = fmul fast float %920, %32
  %930 = call float @dx.op.tertiary.f32(i32 46, float %921, float %28, float %929)  ; FMad(a,b,c)
  %931 = call float @dx.op.tertiary.f32(i32 46, float %905, float %24, float %930)  ; FMad(a,b,c)
  %932 = fadd fast float %931, %20
  %933 = fmul fast float %920, %31
  %934 = call float @dx.op.tertiary.f32(i32 46, float %921, float %27, float %933)  ; FMad(a,b,c)
  %935 = call float @dx.op.tertiary.f32(i32 46, float %905, float %23, float %934)  ; FMad(a,b,c)
  %936 = fadd fast float %935, %19
  %937 = fmul fast float %920, %30
  %938 = call float @dx.op.tertiary.f32(i32 46, float %921, float %26, float %937)  ; FMad(a,b,c)
  %939 = call float @dx.op.tertiary.f32(i32 46, float %905, float %22, float %938)  ; FMad(a,b,c)
  %940 = fadd fast float %939, %18
  %941 = fdiv fast float %940, %925
  %942 = fdiv fast float %936, %925
  %943 = fdiv fast float %932, %925
  %944 = fsub fast float %941, %15
  %945 = fsub fast float %942, %16
  %946 = fsub fast float %943, %17
  %947 = fmul fast float %944, %944
  %948 = fmul fast float %945, %945
  %949 = fadd fast float %948, %947
  %950 = fmul fast float %946, %946
  %951 = fadd fast float %949, %950
  %952 = call float @dx.op.unary.f32(i32 24, float %951)  ; Sqrt(value)
  %953 = fsub fast float %952, %7
  %954 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %953)  ; FMax(a,b)
  %955 = fcmp fast ogt float %37, 1.500000e+00
  br i1 %955, label %956, label %979

; <label>:956                                     ; preds = %928
  %957 = call float @dx.op.unary.f32(i32 6, float %945)  ; FAbs(value)
  %958 = fmul fast float %957, %9
  %959 = fcmp fast olt float %958, 0x3F50624DE0000000
  br i1 %959, label %960, label %963

; <label>:960                                     ; preds = %956
  %961 = fmul fast float %958, 5.000000e-01
  %962 = fsub fast float 1.000000e+00, %961
  br label %968

; <label>:963                                     ; preds = %956
  %964 = fmul fast float %958, 0xBFF7154760000000
  %965 = call float @dx.op.unary.f32(i32 21, float %964)  ; Exp(value)
  %966 = fsub fast float 1.000000e+00, %965
  %967 = fdiv fast float %966, %958
  br label %968

; <label>:968                                     ; preds = %963, %960
  %969 = phi float [ %962, %960 ], [ %967, %963 ]
  %970 = call float @dx.op.binary.f32(i32 36, float %942, float %16)  ; FMin(a,b)
  %971 = fsub fast float %970, %8
  %972 = fmul fast float %9, %971
  %973 = fsub fast float -0.000000e+00, %972
  %974 = call float @dx.op.binary.f32(i32 35, float %973, float -4.000000e+01)  ; FMax(a,b)
  %975 = call float @dx.op.binary.f32(i32 36, float %974, float 5.000000e+00)  ; FMin(a,b)
  %976 = fmul fast float %975, 0x3FF7154760000000
  %977 = call float @dx.op.unary.f32(i32 21, float %976)  ; Exp(value)
  %978 = fmul fast float %977, %969
  br label %979

; <label>:979                                     ; preds = %968, %928
  %980 = phi float [ %978, %968 ], [ 1.000000e+00, %928 ]
  %981 = fmul fast float %954, %14
  %982 = fmul fast float %981, %980
  %983 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %982)  ; FMin(a,b)
  %984 = fmul fast float %983, 0xBFF7154760000000
  %985 = call float @dx.op.unary.f32(i32 21, float %984)  ; Exp(value)
  %986 = fsub fast float 1.000000e+00, %985
  %987 = call float @dx.op.binary.f32(i32 36, float %10, float %986)  ; FMin(a,b)
  %988 = fsub fast float %11, %864
  %989 = fsub fast float %12, %865
  %990 = fsub fast float %13, %866
  %991 = fmul fast float %987, %988
  %992 = fmul fast float %987, %989
  %993 = fmul fast float %987, %990
  %994 = fadd fast float %991, %864
  %995 = fadd fast float %992, %865
  %996 = fadd fast float %993, %866
  br label %997

; <label>:997                                     ; preds = %979, %909, %903
  %998 = phi float [ %994, %979 ], [ %864, %909 ], [ %864, %903 ]
  %999 = phi float [ %995, %979 ], [ %865, %909 ], [ %865, %903 ]
  %1000 = phi float [ %996, %979 ], [ %866, %909 ], [ %866, %903 ]
  %1001 = fadd fast float %3, 1.000000e+00
  %1002 = fadd fast float %4, 1.000000e+00
  %1003 = fsub fast float 1.000000e+00, %3
  %1004 = fmul fast float %34, %1001
  %1005 = fmul fast float %34, %1002
  %1006 = fmul fast float %34, %1003
  %1007 = fmul fast float %1004, %998
  %1008 = fmul fast float %1005, %999
  %1009 = fmul fast float %1006, %1000
  %1010 = fcmp fast ult float %35, 5.000000e-01
  br i1 %1010, label %1036, label %1011

; <label>:1011                                    ; preds = %997
  %1012 = fmul fast float %1007, 0x4004147AE0000000
  %1013 = fmul fast float %1008, 0x4004147AE0000000
  %1014 = fmul fast float %1009, 0x4004147AE0000000
  %1015 = fadd fast float %1012, 0x3F9EB851E0000000
  %1016 = fadd fast float %1013, 0x3F9EB851E0000000
  %1017 = fadd fast float %1014, 0x3F9EB851E0000000
  %1018 = fmul fast float %1015, %1007
  %1019 = fmul fast float %1016, %1008
  %1020 = fmul fast float %1017, %1009
  %1021 = fmul fast float %1007, 0x400370A3E0000000
  %1022 = fmul fast float %1008, 0x400370A3E0000000
  %1023 = fmul fast float %1009, 0x400370A3E0000000
  %1024 = fadd fast float %1021, 0x3FE2E147A0000000
  %1025 = fadd fast float %1022, 0x3FE2E147A0000000
  %1026 = fadd fast float %1023, 0x3FE2E147A0000000
  %1027 = fmul fast float %1024, %1007
  %1028 = fmul fast float %1025, %1008
  %1029 = fmul fast float %1026, %1009
  %1030 = fadd fast float %1027, 0x3FC1EB8520000000
  %1031 = fadd fast float %1028, 0x3FC1EB8520000000
  %1032 = fadd fast float %1029, 0x3FC1EB8520000000
  %1033 = fdiv fast float %1018, %1030
  %1034 = fdiv fast float %1019, %1031
  %1035 = fdiv fast float %1020, %1032
  br label %1036

; <label>:1036                                    ; preds = %1011, %997
  %1037 = phi float [ %1033, %1011 ], [ %1007, %997 ]
  %1038 = phi float [ %1034, %1011 ], [ %1008, %997 ]
  %1039 = phi float [ %1035, %1011 ], [ %1009, %997 ]
  %1040 = call float @dx.op.unary.f32(i32 7, float %1037)  ; Saturate(value)
  %1041 = call float @dx.op.unary.f32(i32 7, float %1038)  ; Saturate(value)
  %1042 = call float @dx.op.unary.f32(i32 7, float %1039)  ; Saturate(value)
  %1043 = call float @dx.op.dot3.f32(i32 55, float %1040, float %1041, float %1042, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1044 = fsub fast float %1040, %1043
  %1045 = fsub fast float %1041, %1043
  %1046 = fsub fast float %1042, %1043
  %1047 = fmul fast float %1044, %6
  %1048 = fmul fast float %1045, %6
  %1049 = fmul fast float %1046, %6
  %1050 = fadd fast float %1047, %1043
  %1051 = fadd fast float %1048, %1043
  %1052 = fadd fast float %1049, %1043
  %1053 = call float @dx.op.unary.f32(i32 7, float %1050)  ; Saturate(value)
  %1054 = call float @dx.op.unary.f32(i32 7, float %1051)  ; Saturate(value)
  %1055 = call float @dx.op.unary.f32(i32 7, float %1052)  ; Saturate(value)
  %1056 = fadd fast float %1053, 0xBFC70A3D80000000
  %1057 = fadd fast float %1054, 0xBFC70A3D80000000
  %1058 = fadd fast float %1055, 0xBFC70A3D80000000
  %1059 = fmul fast float %1056, %5
  %1060 = fmul fast float %1057, %5
  %1061 = fmul fast float %1058, %5
  %1062 = fadd fast float %1059, 0x3FC70A3D80000000
  %1063 = fadd fast float %1060, 0x3FC70A3D80000000
  %1064 = fadd fast float %1061, 0x3FC70A3D80000000
  %1065 = call float @dx.op.unary.f32(i32 7, float %1062)  ; Saturate(value)
  %1066 = call float @dx.op.unary.f32(i32 7, float %1063)  ; Saturate(value)
  %1067 = call float @dx.op.unary.f32(i32 7, float %1064)  ; Saturate(value)
  br label %1068

; <label>:1068                                    ; preds = %1036, %869
  %1069 = phi float [ %900, %869 ], [ %1065, %1036 ]
  %1070 = phi float [ %901, %869 ], [ %1066, %1036 ]
  %1071 = phi float [ %902, %869 ], [ %1067, %1036 ]
  %1072 = call float @dx.op.binary.f32(i32 36, float %857, float %1069)  ; FMin(a,b)
  %1073 = call float @dx.op.binary.f32(i32 36, float %858, float %1070)  ; FMin(a,b)
  %1074 = call float @dx.op.binary.f32(i32 36, float %859, float %1071)  ; FMin(a,b)
  %1075 = call float @dx.op.binary.f32(i32 36, float %431, float %643)  ; FMin(a,b)
  %1076 = call float @dx.op.binary.f32(i32 36, float %432, float %644)  ; FMin(a,b)
  %1077 = call float @dx.op.binary.f32(i32 36, float %433, float %645)  ; FMin(a,b)
  %1078 = call float @dx.op.binary.f32(i32 36, float %1075, float %1072)  ; FMin(a,b)
  %1079 = call float @dx.op.binary.f32(i32 36, float %1076, float %1073)  ; FMin(a,b)
  %1080 = call float @dx.op.binary.f32(i32 36, float %1077, float %1074)  ; FMin(a,b)
  %1081 = call float @dx.op.binary.f32(i32 36, float %215, float %1078)  ; FMin(a,b)
  %1082 = call float @dx.op.binary.f32(i32 36, float %216, float %1079)  ; FMin(a,b)
  %1083 = call float @dx.op.binary.f32(i32 36, float %217, float %1080)  ; FMin(a,b)
  %1084 = call float @dx.op.binary.f32(i32 35, float %857, float %1069)  ; FMax(a,b)
  %1085 = call float @dx.op.binary.f32(i32 35, float %858, float %1070)  ; FMax(a,b)
  %1086 = call float @dx.op.binary.f32(i32 35, float %859, float %1071)  ; FMax(a,b)
  %1087 = call float @dx.op.binary.f32(i32 35, float %431, float %643)  ; FMax(a,b)
  %1088 = call float @dx.op.binary.f32(i32 35, float %432, float %644)  ; FMax(a,b)
  %1089 = call float @dx.op.binary.f32(i32 35, float %433, float %645)  ; FMax(a,b)
  %1090 = call float @dx.op.binary.f32(i32 35, float %1087, float %1084)  ; FMax(a,b)
  %1091 = call float @dx.op.binary.f32(i32 35, float %1088, float %1085)  ; FMax(a,b)
  %1092 = call float @dx.op.binary.f32(i32 35, float %1089, float %1086)  ; FMax(a,b)
  %1093 = call float @dx.op.binary.f32(i32 35, float %215, float %1090)  ; FMax(a,b)
  %1094 = call float @dx.op.binary.f32(i32 35, float %216, float %1091)  ; FMax(a,b)
  %1095 = call float @dx.op.binary.f32(i32 35, float %217, float %1092)  ; FMax(a,b)
  %1096 = fsub fast float %1093, %1081
  %1097 = fsub fast float %1094, %1082
  %1098 = fsub fast float %1095, %1083
  %1099 = call float @dx.op.unary.f32(i32 6, float %1096)  ; FAbs(value)
  %1100 = call float @dx.op.unary.f32(i32 6, float %1097)  ; FAbs(value)
  %1101 = call float @dx.op.unary.f32(i32 6, float %1098)  ; FAbs(value)
  %1102 = call float @dx.op.binary.f32(i32 35, float %1100, float %1101)  ; FMax(a,b)
  %1103 = call float @dx.op.binary.f32(i32 35, float %1099, float %1102)  ; FMax(a,b)
  %1104 = call float @dx.op.binary.f32(i32 35, float %1094, float %1095)  ; FMax(a,b)
  %1105 = call float @dx.op.binary.f32(i32 35, float %1093, float %1104)  ; FMax(a,b)
  %1106 = fmul fast float %1105, 1.250000e-01
  %1107 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1106)  ; FMax(a,b)
  %1108 = fcmp fast ogt float %1103, %1107
  br i1 %1108, label %1109, label %1170

; <label>:1109                                    ; preds = %1068
  %1110 = fsub fast float %431, %643
  %1111 = fsub fast float %432, %644
  %1112 = fsub fast float %433, %645
  %1113 = call float @dx.op.unary.f32(i32 6, float %1110)  ; FAbs(value)
  %1114 = call float @dx.op.unary.f32(i32 6, float %1111)  ; FAbs(value)
  %1115 = call float @dx.op.unary.f32(i32 6, float %1112)  ; FAbs(value)
  %1116 = call float @dx.op.binary.f32(i32 35, float %1114, float %1115)  ; FMax(a,b)
  %1117 = call float @dx.op.binary.f32(i32 35, float %1113, float %1116)  ; FMax(a,b)
  %1118 = fsub fast float %857, %1069
  %1119 = fsub fast float %858, %1070
  %1120 = fsub fast float %859, %1071
  %1121 = call float @dx.op.unary.f32(i32 6, float %1118)  ; FAbs(value)
  %1122 = call float @dx.op.unary.f32(i32 6, float %1119)  ; FAbs(value)
  %1123 = call float @dx.op.unary.f32(i32 6, float %1120)  ; FAbs(value)
  %1124 = call float @dx.op.binary.f32(i32 35, float %1122, float %1123)  ; FMax(a,b)
  %1125 = call float @dx.op.binary.f32(i32 35, float %1121, float %1124)  ; FMax(a,b)
  %1126 = fcmp fast olt float %1117, %1125
  %1127 = select i1 %1126, float %431, float %857
  %1128 = select i1 %1126, float %432, float %858
  %1129 = select i1 %1126, float %433, float %859
  %1130 = select i1 %1126, float %643, float %1069
  %1131 = select i1 %1126, float %644, float %1070
  %1132 = select i1 %1126, float %645, float %1071
  %1133 = fsub fast float %215, %1130
  %1134 = fsub fast float %216, %1131
  %1135 = fsub fast float %217, %1132
  %1136 = fsub fast float %215, %1127
  %1137 = fsub fast float %216, %1128
  %1138 = fsub fast float %217, %1129
  %1139 = call float @dx.op.dot3.f32(i32 55, float %1136, float %1137, float %1138, float %1133, float %1134, float %1135)  ; Dot3(ax,ay,az,bx,by,bz)
  %1140 = fcmp fast ogt float %1139, 0.000000e+00
  br i1 %1140, label %1141, label %1153

; <label>:1141                                    ; preds = %1109
  %1142 = fsub fast float %1127, %1130
  %1143 = fsub fast float %1128, %1131
  %1144 = fsub fast float %1129, %1132
  %1145 = call float @dx.op.unary.f32(i32 6, float %1142)  ; FAbs(value)
  %1146 = call float @dx.op.unary.f32(i32 6, float %1143)  ; FAbs(value)
  %1147 = call float @dx.op.unary.f32(i32 6, float %1144)  ; FAbs(value)
  %1148 = call float @dx.op.binary.f32(i32 35, float %1146, float %1147)  ; FMax(a,b)
  %1149 = call float @dx.op.binary.f32(i32 35, float %1145, float %1148)  ; FMax(a,b)
  %1150 = fmul fast float %1103, 2.500000e-01
  %1151 = fcmp fast olt float %1149, %1150
  %1152 = select i1 %1151, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  br label %1153

; <label>:1153                                    ; preds = %1141, %1109
  %1154 = phi float [ 0x3FC99999A0000000, %1109 ], [ %1152, %1141 ]
  %1155 = fadd fast float %1127, %1130
  %1156 = fadd fast float %1128, %1131
  %1157 = fadd fast float %1129, %1132
  %1158 = fmul fast float %1155, 5.000000e-01
  %1159 = fmul fast float %1156, 5.000000e-01
  %1160 = fmul fast float %1157, 5.000000e-01
  %1161 = fsub fast float %1158, %215
  %1162 = fsub fast float %1159, %216
  %1163 = fsub fast float %1160, %217
  %1164 = fmul fast float %1154, %1161
  %1165 = fmul fast float %1154, %1162
  %1166 = fmul fast float %1154, %1163
  %1167 = fadd fast float %1164, %215
  %1168 = fadd fast float %1165, %216
  %1169 = fadd fast float %1166, %217
  br label %1170

; <label>:1170                                    ; preds = %1153, %1068
  %1171 = phi float [ %1167, %1153 ], [ %215, %1068 ]
  %1172 = phi float [ %1168, %1153 ], [ %216, %1068 ]
  %1173 = phi float [ %1169, %1153 ], [ %217, %1068 ]
  %1174 = fcmp fast ogt float %1171, 0x3F69A5C380000000
  %1175 = fcmp fast ogt float %1172, 0x3F69A5C380000000
  %1176 = fcmp fast ogt float %1173, 0x3F69A5C380000000
  %1177 = select i1 %1174, float 0.000000e+00, float 1.000000e+00
  %1178 = select i1 %1175, float 0.000000e+00, float 1.000000e+00
  %1179 = select i1 %1176, float 0.000000e+00, float 1.000000e+00
  %1180 = fmul fast float %1171, 0x4029D70A40000000
  %1181 = fmul fast float %1172, 0x4029D70A40000000
  %1182 = fmul fast float %1173, 0x4029D70A40000000
  %1183 = call float @dx.op.binary.f32(i32 35, float %1171, float 0.000000e+00)  ; FMax(a,b)
  %1184 = call float @dx.op.binary.f32(i32 35, float %1172, float 0.000000e+00)  ; FMax(a,b)
  %1185 = call float @dx.op.binary.f32(i32 35, float %1173, float 0.000000e+00)  ; FMax(a,b)
  %1186 = call float @dx.op.unary.f32(i32 23, float %1183)  ; Log(value)
  %1187 = call float @dx.op.unary.f32(i32 23, float %1184)  ; Log(value)
  %1188 = call float @dx.op.unary.f32(i32 23, float %1185)  ; Log(value)
  %1189 = fmul fast float %1186, 0x3FDAAAAAA0000000
  %1190 = fmul fast float %1187, 0x3FDAAAAAA0000000
  %1191 = fmul fast float %1188, 0x3FDAAAAAA0000000
  %1192 = call float @dx.op.unary.f32(i32 21, float %1189)  ; Exp(value)
  %1193 = call float @dx.op.unary.f32(i32 21, float %1190)  ; Exp(value)
  %1194 = call float @dx.op.unary.f32(i32 21, float %1191)  ; Exp(value)
  %1195 = fmul fast float %1192, 0x3FF0E147A0000000
  %1196 = fmul fast float %1193, 0x3FF0E147A0000000
  %1197 = fmul fast float %1194, 0x3FF0E147A0000000
  %1198 = fadd fast float %1195, 0xBFAC28F5C0000000
  %1199 = fadd fast float %1196, 0xBFAC28F5C0000000
  %1200 = fadd fast float %1197, 0xBFAC28F5C0000000
  %1201 = fsub fast float %1180, %1198
  %1202 = fsub fast float %1181, %1199
  %1203 = fsub fast float %1182, %1200
  %1204 = fmul fast float %1201, %1177
  %1205 = fmul fast float %1202, %1178
  %1206 = fmul fast float %1203, %1179
  %1207 = fadd fast float %1204, %1198
  %1208 = fadd fast float %1205, %1199
  %1209 = fadd fast float %1206, %1200
  br label %1210

; <label>:1210                                    ; preds = %1170, %51
  %1211 = phi float [ %46, %51 ], [ %1207, %1170 ]
  %1212 = phi float [ %47, %51 ], [ %1208, %1170 ]
  %1213 = phi float [ %48, %51 ], [ %1209, %1170 ]
  %1214 = phi float [ %52, %51 ], [ %49, %1170 ]
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %1211)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %1212)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %1213)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %1214)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 0, i32 0, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !37, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, null}
!36 = !{i32 9}
!37 = !{!38}
!38 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
