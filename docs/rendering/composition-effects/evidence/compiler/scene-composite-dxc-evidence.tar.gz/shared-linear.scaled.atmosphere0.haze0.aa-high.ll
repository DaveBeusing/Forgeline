;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xy  
; TEXCOORD                 1   xyzw        2     NONE   float       
; TEXCOORD                 2   xyzw        3     NONE   float       
; TEXCOORD                 3   xyzw        4     NONE   float       
; TEXCOORD                 4   xyzw        5     NONE   float       
; TEXCOORD                 5   xyzw        6     NONE   float       
; TEXCOORD                 6   xyzw        7     NONE   float       
; TEXCOORD                 7   xyzw        8     NONE   float       
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float    yz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: 204a72e632f37f04664ee97ce5d6307d
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %14 = extractvalue %dx.types.Dimensions %13, 0
  %15 = extractvalue %dx.types.Dimensions %13, 1
  %16 = uitofp i32 %14 to float
  %17 = uitofp i32 %15 to float
  %18 = fmul fast float %16, %11
  %19 = fmul fast float %17, %12
  %20 = fdiv fast float %18, %3
  %21 = fdiv fast float %19, %4
  %22 = fadd fast float %20, -5.000000e-01
  %23 = fadd fast float %21, -5.000000e-01
  %24 = call float @dx.op.unary.f32(i32 27, float %22)  ; Round_ni(value)
  %25 = call float @dx.op.unary.f32(i32 27, float %23)  ; Round_ni(value)
  %26 = fptosi float %24 to i32
  %27 = fptosi float %25 to i32
  %28 = call float @dx.op.unary.f32(i32 22, float %22)  ; Frc(value)
  %29 = call float @dx.op.unary.f32(i32 22, float %23)  ; Frc(value)
  %30 = add i32 %14, -1
  %31 = add i32 %15, -1
  %32 = call i32 @dx.op.binary.i32(i32 37, i32 %26, i32 0)  ; IMax(a,b)
  %33 = call i32 @dx.op.binary.i32(i32 37, i32 %27, i32 0)  ; IMax(a,b)
  %34 = call i32 @dx.op.binary.i32(i32 38, i32 %32, i32 %30)  ; IMin(a,b)
  %35 = call i32 @dx.op.binary.i32(i32 38, i32 %33, i32 %31)  ; IMin(a,b)
  %36 = add i32 %26, 1
  %37 = call i32 @dx.op.binary.i32(i32 37, i32 %36, i32 0)  ; IMax(a,b)
  %38 = call i32 @dx.op.binary.i32(i32 38, i32 %37, i32 %30)  ; IMin(a,b)
  %39 = add i32 %27, 1
  %40 = call i32 @dx.op.binary.i32(i32 37, i32 %39, i32 0)  ; IMax(a,b)
  %41 = call i32 @dx.op.binary.i32(i32 38, i32 %40, i32 %31)  ; IMin(a,b)
  %42 = call float @dx.op.unary.f32(i32 27, float %20)  ; Round_ni(value)
  %43 = call float @dx.op.unary.f32(i32 27, float %21)  ; Round_ni(value)
  %44 = fptosi float %42 to i32
  %45 = fptosi float %43 to i32
  %46 = call i32 @dx.op.binary.i32(i32 37, i32 %44, i32 0)  ; IMax(a,b)
  %47 = call i32 @dx.op.binary.i32(i32 37, i32 %45, i32 0)  ; IMax(a,b)
  %48 = call i32 @dx.op.binary.i32(i32 38, i32 %46, i32 %30)  ; IMin(a,b)
  %49 = call i32 @dx.op.binary.i32(i32 38, i32 %47, i32 %31)  ; IMin(a,b)
  %50 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %48, i32 %49, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %51 = extractvalue %dx.types.ResRet.f32 %50, 0
  %52 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %34, i32 %35, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %53 = extractvalue %dx.types.ResRet.f32 %52, 0
  %54 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %38, i32 %35, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %55 = extractvalue %dx.types.ResRet.f32 %54, 0
  %56 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %34, i32 %41, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %57 = extractvalue %dx.types.ResRet.f32 %56, 0
  %58 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %38, i32 %41, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %59 = extractvalue %dx.types.ResRet.f32 %58, 0
  %60 = fsub fast float 1.000000e+00, %28
  %61 = fsub fast float 1.000000e+00, %29
  %62 = fmul fast float %61, %60
  %63 = fmul fast float %61, %28
  %64 = fmul fast float %60, %29
  %65 = fmul fast float %29, %28
  %66 = fsub fast float 1.000000e+00, %51
  %67 = fmul fast float %66, 0x3FA99999A0000000
  %68 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %67)  ; FMax(a,b)
  %69 = fsub fast float %53, %51
  %70 = call float @dx.op.unary.f32(i32 6, float %69)  ; FAbs(value)
  %71 = fdiv fast float %70, %68
  %72 = fsub fast float 1.000000e+00, %71
  %73 = call float @dx.op.unary.f32(i32 7, float %72)  ; Saturate(value)
  %74 = fsub fast float %55, %51
  %75 = call float @dx.op.unary.f32(i32 6, float %74)  ; FAbs(value)
  %76 = fdiv fast float %75, %68
  %77 = fsub fast float 1.000000e+00, %76
  %78 = call float @dx.op.unary.f32(i32 7, float %77)  ; Saturate(value)
  %79 = fsub fast float %57, %51
  %80 = call float @dx.op.unary.f32(i32 6, float %79)  ; FAbs(value)
  %81 = fdiv fast float %80, %68
  %82 = fsub fast float 1.000000e+00, %81
  %83 = call float @dx.op.unary.f32(i32 7, float %82)  ; Saturate(value)
  %84 = fsub fast float %59, %51
  %85 = call float @dx.op.unary.f32(i32 6, float %84)  ; FAbs(value)
  %86 = fdiv fast float %85, %68
  %87 = fsub fast float 1.000000e+00, %86
  %88 = call float @dx.op.unary.f32(i32 7, float %87)  ; Saturate(value)
  %89 = fmul fast float %62, %73
  %90 = fmul fast float %63, %78
  %91 = fmul fast float %64, %83
  %92 = fmul fast float %65, %88
  %93 = fcmp fast oge float %28, 5.000000e-01
  %94 = zext i1 %93 to i32
  %95 = fcmp fast oge float %29, 5.000000e-01
  %96 = select i1 %95, i32 2, i32 0
  %97 = or i32 %96, %94
  %98 = call float @dx.op.dot4.f32(i32 56, float %89, float %90, float %91, float %92, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %99 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %89)  ; IsFinite(value)
  %100 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %90)  ; IsFinite(value)
  %101 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %91)  ; IsFinite(value)
  %102 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %92)  ; IsFinite(value)
  %103 = and i1 %99, %100
  %104 = and i1 %103, %101
  %105 = and i1 %104, %102
  br i1 %105, label %106, label %123

; <label>:106                                     ; preds = %0
  %107 = fcmp fast oge float %89, 0.000000e+00
  %108 = fcmp fast oge float %90, 0.000000e+00
  %109 = fcmp fast oge float %91, 0.000000e+00
  %110 = fcmp fast oge float %92, 0.000000e+00
  %111 = and i1 %107, %108
  %112 = and i1 %111, %109
  %113 = and i1 %112, %110
  br i1 %113, label %114, label %123

; <label>:114                                     ; preds = %106
  %115 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %98)  ; IsFinite(value)
  %116 = fcmp fast oge float %98, 0x3810000000000000
  %117 = and i1 %116, %115
  br i1 %117, label %118, label %123

; <label>:118                                     ; preds = %114
  %119 = fdiv fast float %89, %98
  %120 = fdiv fast float %90, %98
  %121 = fdiv fast float %91, %98
  %122 = fdiv fast float %92, %98
  br label %132

; <label>:123                                     ; preds = %114, %106, %0
  %124 = icmp eq i32 %97, 0
  %125 = uitofp i1 %124 to float
  %126 = icmp eq i32 %97, 1
  %127 = uitofp i1 %126 to float
  %128 = icmp eq i32 %97, 2
  %129 = uitofp i1 %128 to float
  %130 = icmp eq i32 %97, 3
  %131 = uitofp i1 %130 to float
  br label %132

; <label>:132                                     ; preds = %123, %118
  %133 = phi float [ %119, %118 ], [ %125, %123 ]
  %134 = phi float [ %120, %118 ], [ %127, %123 ]
  %135 = phi float [ %121, %118 ], [ %129, %123 ]
  %136 = phi float [ %122, %118 ], [ %131, %123 ]
  %137 = or i32 %27, %26
  %138 = icmp sgt i32 %137, -1
  br i1 %138, label %139, label %143

; <label>:139                                     ; preds = %132
  %140 = icmp slt i32 %36, %14
  %141 = icmp slt i32 %39, %15
  %142 = and i1 %140, %141
  br label %143

; <label>:143                                     ; preds = %139, %132
  %144 = phi i1 [ false, %132 ], [ %142, %139 ]
  br i1 %144, label %145, label %2314

; <label>:145                                     ; preds = %143
  %146 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %26, i32 %27, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %147 = extractvalue %dx.types.ResRet.f32 %146, 0
  %148 = extractvalue %dx.types.ResRet.f32 %146, 1
  %149 = extractvalue %dx.types.ResRet.f32 %146, 2
  %150 = extractvalue %dx.types.ResRet.f32 %146, 3
  %151 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %36, i32 %27, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %152 = extractvalue %dx.types.ResRet.f32 %151, 0
  %153 = extractvalue %dx.types.ResRet.f32 %151, 1
  %154 = extractvalue %dx.types.ResRet.f32 %151, 2
  %155 = extractvalue %dx.types.ResRet.f32 %151, 3
  %156 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %26, i32 %39, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %157 = extractvalue %dx.types.ResRet.f32 %156, 0
  %158 = extractvalue %dx.types.ResRet.f32 %156, 1
  %159 = extractvalue %dx.types.ResRet.f32 %156, 2
  %160 = extractvalue %dx.types.ResRet.f32 %156, 3
  %161 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %36, i32 %39, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %162 = extractvalue %dx.types.ResRet.f32 %161, 0
  %163 = extractvalue %dx.types.ResRet.f32 %161, 1
  %164 = extractvalue %dx.types.ResRet.f32 %161, 2
  %165 = extractvalue %dx.types.ResRet.f32 %161, 3
  %166 = fcmp fast olt float %150, 0.000000e+00
  br i1 %166, label %167, label %201

; <label>:167                                     ; preds = %145
  %168 = fcmp fast ogt float %147, 0x3FA4B5DCC0000000
  %169 = fcmp fast ogt float %148, 0x3FA4B5DCC0000000
  %170 = fcmp fast ogt float %149, 0x3FA4B5DCC0000000
  %171 = select i1 %168, float 0.000000e+00, float 1.000000e+00
  %172 = select i1 %169, float 0.000000e+00, float 1.000000e+00
  %173 = select i1 %170, float 0.000000e+00, float 1.000000e+00
  %174 = fmul fast float %147, 0x3FB3D07220000000
  %175 = fmul fast float %148, 0x3FB3D07220000000
  %176 = fmul fast float %149, 0x3FB3D07220000000
  %177 = fadd fast float %147, 0x3FAC28F5C0000000
  %178 = fadd fast float %148, 0x3FAC28F5C0000000
  %179 = fadd fast float %149, 0x3FAC28F5C0000000
  %180 = fmul fast float %177, 0x3FEE54EDE0000000
  %181 = fmul fast float %178, 0x3FEE54EDE0000000
  %182 = fmul fast float %179, 0x3FEE54EDE0000000
  %183 = call float @dx.op.unary.f32(i32 23, float %180)  ; Log(value)
  %184 = call float @dx.op.unary.f32(i32 23, float %181)  ; Log(value)
  %185 = call float @dx.op.unary.f32(i32 23, float %182)  ; Log(value)
  %186 = fmul fast float %183, 0x4003333340000000
  %187 = fmul fast float %184, 0x4003333340000000
  %188 = fmul fast float %185, 0x4003333340000000
  %189 = call float @dx.op.unary.f32(i32 21, float %186)  ; Exp(value)
  %190 = call float @dx.op.unary.f32(i32 21, float %187)  ; Exp(value)
  %191 = call float @dx.op.unary.f32(i32 21, float %188)  ; Exp(value)
  %192 = fsub fast float %174, %189
  %193 = fsub fast float %175, %190
  %194 = fsub fast float %176, %191
  %195 = fmul fast float %192, %171
  %196 = fmul fast float %193, %172
  %197 = fmul fast float %194, %173
  %198 = fadd fast float %195, %189
  %199 = fadd fast float %196, %190
  %200 = fadd fast float %197, %191
  br label %269

; <label>:201                                     ; preds = %145
  %202 = fadd fast float %5, 1.000000e+00
  %203 = fadd fast float %6, 1.000000e+00
  %204 = fsub fast float 1.000000e+00, %5
  %205 = fmul fast float %9, %202
  %206 = fmul fast float %9, %203
  %207 = fmul fast float %9, %204
  %208 = fmul fast float %205, %147
  %209 = fmul fast float %206, %148
  %210 = fmul fast float %207, %149
  %211 = fcmp fast ult float %10, 5.000000e-01
  br i1 %211, label %237, label %212

; <label>:212                                     ; preds = %201
  %213 = fmul fast float %208, 0x4004147AE0000000
  %214 = fmul fast float %209, 0x4004147AE0000000
  %215 = fmul fast float %210, 0x4004147AE0000000
  %216 = fadd fast float %213, 0x3F9EB851E0000000
  %217 = fadd fast float %214, 0x3F9EB851E0000000
  %218 = fadd fast float %215, 0x3F9EB851E0000000
  %219 = fmul fast float %216, %208
  %220 = fmul fast float %217, %209
  %221 = fmul fast float %218, %210
  %222 = fmul fast float %208, 0x400370A3E0000000
  %223 = fmul fast float %209, 0x400370A3E0000000
  %224 = fmul fast float %210, 0x400370A3E0000000
  %225 = fadd fast float %222, 0x3FE2E147A0000000
  %226 = fadd fast float %223, 0x3FE2E147A0000000
  %227 = fadd fast float %224, 0x3FE2E147A0000000
  %228 = fmul fast float %225, %208
  %229 = fmul fast float %226, %209
  %230 = fmul fast float %227, %210
  %231 = fadd fast float %228, 0x3FC1EB8520000000
  %232 = fadd fast float %229, 0x3FC1EB8520000000
  %233 = fadd fast float %230, 0x3FC1EB8520000000
  %234 = fdiv fast float %219, %231
  %235 = fdiv fast float %220, %232
  %236 = fdiv fast float %221, %233
  br label %237

; <label>:237                                     ; preds = %212, %201
  %238 = phi float [ %234, %212 ], [ %208, %201 ]
  %239 = phi float [ %235, %212 ], [ %209, %201 ]
  %240 = phi float [ %236, %212 ], [ %210, %201 ]
  %241 = call float @dx.op.unary.f32(i32 7, float %238)  ; Saturate(value)
  %242 = call float @dx.op.unary.f32(i32 7, float %239)  ; Saturate(value)
  %243 = call float @dx.op.unary.f32(i32 7, float %240)  ; Saturate(value)
  %244 = call float @dx.op.dot3.f32(i32 55, float %241, float %242, float %243, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %245 = fsub fast float %241, %244
  %246 = fsub fast float %242, %244
  %247 = fsub fast float %243, %244
  %248 = fmul fast float %245, %8
  %249 = fmul fast float %246, %8
  %250 = fmul fast float %247, %8
  %251 = fadd fast float %248, %244
  %252 = fadd fast float %249, %244
  %253 = fadd fast float %250, %244
  %254 = call float @dx.op.unary.f32(i32 7, float %251)  ; Saturate(value)
  %255 = call float @dx.op.unary.f32(i32 7, float %252)  ; Saturate(value)
  %256 = call float @dx.op.unary.f32(i32 7, float %253)  ; Saturate(value)
  %257 = fadd fast float %254, 0xBFC70A3D80000000
  %258 = fadd fast float %255, 0xBFC70A3D80000000
  %259 = fadd fast float %256, 0xBFC70A3D80000000
  %260 = fmul fast float %257, %7
  %261 = fmul fast float %258, %7
  %262 = fmul fast float %259, %7
  %263 = fadd fast float %260, 0x3FC70A3D80000000
  %264 = fadd fast float %261, 0x3FC70A3D80000000
  %265 = fadd fast float %262, 0x3FC70A3D80000000
  %266 = call float @dx.op.unary.f32(i32 7, float %263)  ; Saturate(value)
  %267 = call float @dx.op.unary.f32(i32 7, float %264)  ; Saturate(value)
  %268 = call float @dx.op.unary.f32(i32 7, float %265)  ; Saturate(value)
  br label %269

; <label>:269                                     ; preds = %237, %167
  %270 = phi float [ %198, %167 ], [ %266, %237 ]
  %271 = phi float [ %199, %167 ], [ %267, %237 ]
  %272 = phi float [ %200, %167 ], [ %268, %237 ]
  %273 = fcmp fast olt float %155, 0.000000e+00
  br i1 %273, label %274, label %308

; <label>:274                                     ; preds = %269
  %275 = fcmp fast ogt float %152, 0x3FA4B5DCC0000000
  %276 = fcmp fast ogt float %153, 0x3FA4B5DCC0000000
  %277 = fcmp fast ogt float %154, 0x3FA4B5DCC0000000
  %278 = select i1 %275, float 0.000000e+00, float 1.000000e+00
  %279 = select i1 %276, float 0.000000e+00, float 1.000000e+00
  %280 = select i1 %277, float 0.000000e+00, float 1.000000e+00
  %281 = fmul fast float %152, 0x3FB3D07220000000
  %282 = fmul fast float %153, 0x3FB3D07220000000
  %283 = fmul fast float %154, 0x3FB3D07220000000
  %284 = fadd fast float %152, 0x3FAC28F5C0000000
  %285 = fadd fast float %153, 0x3FAC28F5C0000000
  %286 = fadd fast float %154, 0x3FAC28F5C0000000
  %287 = fmul fast float %284, 0x3FEE54EDE0000000
  %288 = fmul fast float %285, 0x3FEE54EDE0000000
  %289 = fmul fast float %286, 0x3FEE54EDE0000000
  %290 = call float @dx.op.unary.f32(i32 23, float %287)  ; Log(value)
  %291 = call float @dx.op.unary.f32(i32 23, float %288)  ; Log(value)
  %292 = call float @dx.op.unary.f32(i32 23, float %289)  ; Log(value)
  %293 = fmul fast float %290, 0x4003333340000000
  %294 = fmul fast float %291, 0x4003333340000000
  %295 = fmul fast float %292, 0x4003333340000000
  %296 = call float @dx.op.unary.f32(i32 21, float %293)  ; Exp(value)
  %297 = call float @dx.op.unary.f32(i32 21, float %294)  ; Exp(value)
  %298 = call float @dx.op.unary.f32(i32 21, float %295)  ; Exp(value)
  %299 = fsub fast float %281, %296
  %300 = fsub fast float %282, %297
  %301 = fsub fast float %283, %298
  %302 = fmul fast float %299, %278
  %303 = fmul fast float %300, %279
  %304 = fmul fast float %301, %280
  %305 = fadd fast float %302, %296
  %306 = fadd fast float %303, %297
  %307 = fadd fast float %304, %298
  br label %376

; <label>:308                                     ; preds = %269
  %309 = fadd fast float %5, 1.000000e+00
  %310 = fadd fast float %6, 1.000000e+00
  %311 = fsub fast float 1.000000e+00, %5
  %312 = fmul fast float %9, %309
  %313 = fmul fast float %9, %310
  %314 = fmul fast float %9, %311
  %315 = fmul fast float %312, %152
  %316 = fmul fast float %313, %153
  %317 = fmul fast float %314, %154
  %318 = fcmp fast ult float %10, 5.000000e-01
  br i1 %318, label %344, label %319

; <label>:319                                     ; preds = %308
  %320 = fmul fast float %315, 0x4004147AE0000000
  %321 = fmul fast float %316, 0x4004147AE0000000
  %322 = fmul fast float %317, 0x4004147AE0000000
  %323 = fadd fast float %320, 0x3F9EB851E0000000
  %324 = fadd fast float %321, 0x3F9EB851E0000000
  %325 = fadd fast float %322, 0x3F9EB851E0000000
  %326 = fmul fast float %323, %315
  %327 = fmul fast float %324, %316
  %328 = fmul fast float %325, %317
  %329 = fmul fast float %315, 0x400370A3E0000000
  %330 = fmul fast float %316, 0x400370A3E0000000
  %331 = fmul fast float %317, 0x400370A3E0000000
  %332 = fadd fast float %329, 0x3FE2E147A0000000
  %333 = fadd fast float %330, 0x3FE2E147A0000000
  %334 = fadd fast float %331, 0x3FE2E147A0000000
  %335 = fmul fast float %332, %315
  %336 = fmul fast float %333, %316
  %337 = fmul fast float %334, %317
  %338 = fadd fast float %335, 0x3FC1EB8520000000
  %339 = fadd fast float %336, 0x3FC1EB8520000000
  %340 = fadd fast float %337, 0x3FC1EB8520000000
  %341 = fdiv fast float %326, %338
  %342 = fdiv fast float %327, %339
  %343 = fdiv fast float %328, %340
  br label %344

; <label>:344                                     ; preds = %319, %308
  %345 = phi float [ %341, %319 ], [ %315, %308 ]
  %346 = phi float [ %342, %319 ], [ %316, %308 ]
  %347 = phi float [ %343, %319 ], [ %317, %308 ]
  %348 = call float @dx.op.unary.f32(i32 7, float %345)  ; Saturate(value)
  %349 = call float @dx.op.unary.f32(i32 7, float %346)  ; Saturate(value)
  %350 = call float @dx.op.unary.f32(i32 7, float %347)  ; Saturate(value)
  %351 = call float @dx.op.dot3.f32(i32 55, float %348, float %349, float %350, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %352 = fsub fast float %348, %351
  %353 = fsub fast float %349, %351
  %354 = fsub fast float %350, %351
  %355 = fmul fast float %352, %8
  %356 = fmul fast float %353, %8
  %357 = fmul fast float %354, %8
  %358 = fadd fast float %355, %351
  %359 = fadd fast float %356, %351
  %360 = fadd fast float %357, %351
  %361 = call float @dx.op.unary.f32(i32 7, float %358)  ; Saturate(value)
  %362 = call float @dx.op.unary.f32(i32 7, float %359)  ; Saturate(value)
  %363 = call float @dx.op.unary.f32(i32 7, float %360)  ; Saturate(value)
  %364 = fadd fast float %361, 0xBFC70A3D80000000
  %365 = fadd fast float %362, 0xBFC70A3D80000000
  %366 = fadd fast float %363, 0xBFC70A3D80000000
  %367 = fmul fast float %364, %7
  %368 = fmul fast float %365, %7
  %369 = fmul fast float %366, %7
  %370 = fadd fast float %367, 0x3FC70A3D80000000
  %371 = fadd fast float %368, 0x3FC70A3D80000000
  %372 = fadd fast float %369, 0x3FC70A3D80000000
  %373 = call float @dx.op.unary.f32(i32 7, float %370)  ; Saturate(value)
  %374 = call float @dx.op.unary.f32(i32 7, float %371)  ; Saturate(value)
  %375 = call float @dx.op.unary.f32(i32 7, float %372)  ; Saturate(value)
  br label %376

; <label>:376                                     ; preds = %344, %274
  %377 = phi float [ %305, %274 ], [ %373, %344 ]
  %378 = phi float [ %306, %274 ], [ %374, %344 ]
  %379 = phi float [ %307, %274 ], [ %375, %344 ]
  %380 = fcmp fast olt float %160, 0.000000e+00
  br i1 %380, label %381, label %415

; <label>:381                                     ; preds = %376
  %382 = fcmp fast ogt float %157, 0x3FA4B5DCC0000000
  %383 = fcmp fast ogt float %158, 0x3FA4B5DCC0000000
  %384 = fcmp fast ogt float %159, 0x3FA4B5DCC0000000
  %385 = select i1 %382, float 0.000000e+00, float 1.000000e+00
  %386 = select i1 %383, float 0.000000e+00, float 1.000000e+00
  %387 = select i1 %384, float 0.000000e+00, float 1.000000e+00
  %388 = fmul fast float %157, 0x3FB3D07220000000
  %389 = fmul fast float %158, 0x3FB3D07220000000
  %390 = fmul fast float %159, 0x3FB3D07220000000
  %391 = fadd fast float %157, 0x3FAC28F5C0000000
  %392 = fadd fast float %158, 0x3FAC28F5C0000000
  %393 = fadd fast float %159, 0x3FAC28F5C0000000
  %394 = fmul fast float %391, 0x3FEE54EDE0000000
  %395 = fmul fast float %392, 0x3FEE54EDE0000000
  %396 = fmul fast float %393, 0x3FEE54EDE0000000
  %397 = call float @dx.op.unary.f32(i32 23, float %394)  ; Log(value)
  %398 = call float @dx.op.unary.f32(i32 23, float %395)  ; Log(value)
  %399 = call float @dx.op.unary.f32(i32 23, float %396)  ; Log(value)
  %400 = fmul fast float %397, 0x4003333340000000
  %401 = fmul fast float %398, 0x4003333340000000
  %402 = fmul fast float %399, 0x4003333340000000
  %403 = call float @dx.op.unary.f32(i32 21, float %400)  ; Exp(value)
  %404 = call float @dx.op.unary.f32(i32 21, float %401)  ; Exp(value)
  %405 = call float @dx.op.unary.f32(i32 21, float %402)  ; Exp(value)
  %406 = fsub fast float %388, %403
  %407 = fsub fast float %389, %404
  %408 = fsub fast float %390, %405
  %409 = fmul fast float %406, %385
  %410 = fmul fast float %407, %386
  %411 = fmul fast float %408, %387
  %412 = fadd fast float %409, %403
  %413 = fadd fast float %410, %404
  %414 = fadd fast float %411, %405
  br label %483

; <label>:415                                     ; preds = %376
  %416 = fadd fast float %5, 1.000000e+00
  %417 = fadd fast float %6, 1.000000e+00
  %418 = fsub fast float 1.000000e+00, %5
  %419 = fmul fast float %9, %416
  %420 = fmul fast float %9, %417
  %421 = fmul fast float %9, %418
  %422 = fmul fast float %419, %157
  %423 = fmul fast float %420, %158
  %424 = fmul fast float %421, %159
  %425 = fcmp fast ult float %10, 5.000000e-01
  br i1 %425, label %451, label %426

; <label>:426                                     ; preds = %415
  %427 = fmul fast float %422, 0x4004147AE0000000
  %428 = fmul fast float %423, 0x4004147AE0000000
  %429 = fmul fast float %424, 0x4004147AE0000000
  %430 = fadd fast float %427, 0x3F9EB851E0000000
  %431 = fadd fast float %428, 0x3F9EB851E0000000
  %432 = fadd fast float %429, 0x3F9EB851E0000000
  %433 = fmul fast float %430, %422
  %434 = fmul fast float %431, %423
  %435 = fmul fast float %432, %424
  %436 = fmul fast float %422, 0x400370A3E0000000
  %437 = fmul fast float %423, 0x400370A3E0000000
  %438 = fmul fast float %424, 0x400370A3E0000000
  %439 = fadd fast float %436, 0x3FE2E147A0000000
  %440 = fadd fast float %437, 0x3FE2E147A0000000
  %441 = fadd fast float %438, 0x3FE2E147A0000000
  %442 = fmul fast float %439, %422
  %443 = fmul fast float %440, %423
  %444 = fmul fast float %441, %424
  %445 = fadd fast float %442, 0x3FC1EB8520000000
  %446 = fadd fast float %443, 0x3FC1EB8520000000
  %447 = fadd fast float %444, 0x3FC1EB8520000000
  %448 = fdiv fast float %433, %445
  %449 = fdiv fast float %434, %446
  %450 = fdiv fast float %435, %447
  br label %451

; <label>:451                                     ; preds = %426, %415
  %452 = phi float [ %448, %426 ], [ %422, %415 ]
  %453 = phi float [ %449, %426 ], [ %423, %415 ]
  %454 = phi float [ %450, %426 ], [ %424, %415 ]
  %455 = call float @dx.op.unary.f32(i32 7, float %452)  ; Saturate(value)
  %456 = call float @dx.op.unary.f32(i32 7, float %453)  ; Saturate(value)
  %457 = call float @dx.op.unary.f32(i32 7, float %454)  ; Saturate(value)
  %458 = call float @dx.op.dot3.f32(i32 55, float %455, float %456, float %457, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %459 = fsub fast float %455, %458
  %460 = fsub fast float %456, %458
  %461 = fsub fast float %457, %458
  %462 = fmul fast float %459, %8
  %463 = fmul fast float %460, %8
  %464 = fmul fast float %461, %8
  %465 = fadd fast float %462, %458
  %466 = fadd fast float %463, %458
  %467 = fadd fast float %464, %458
  %468 = call float @dx.op.unary.f32(i32 7, float %465)  ; Saturate(value)
  %469 = call float @dx.op.unary.f32(i32 7, float %466)  ; Saturate(value)
  %470 = call float @dx.op.unary.f32(i32 7, float %467)  ; Saturate(value)
  %471 = fadd fast float %468, 0xBFC70A3D80000000
  %472 = fadd fast float %469, 0xBFC70A3D80000000
  %473 = fadd fast float %470, 0xBFC70A3D80000000
  %474 = fmul fast float %471, %7
  %475 = fmul fast float %472, %7
  %476 = fmul fast float %473, %7
  %477 = fadd fast float %474, 0x3FC70A3D80000000
  %478 = fadd fast float %475, 0x3FC70A3D80000000
  %479 = fadd fast float %476, 0x3FC70A3D80000000
  %480 = call float @dx.op.unary.f32(i32 7, float %477)  ; Saturate(value)
  %481 = call float @dx.op.unary.f32(i32 7, float %478)  ; Saturate(value)
  %482 = call float @dx.op.unary.f32(i32 7, float %479)  ; Saturate(value)
  br label %483

; <label>:483                                     ; preds = %451, %381
  %484 = phi float [ %412, %381 ], [ %480, %451 ]
  %485 = phi float [ %413, %381 ], [ %481, %451 ]
  %486 = phi float [ %414, %381 ], [ %482, %451 ]
  %487 = fcmp fast olt float %165, 0.000000e+00
  br i1 %487, label %488, label %522

; <label>:488                                     ; preds = %483
  %489 = fcmp fast ogt float %162, 0x3FA4B5DCC0000000
  %490 = fcmp fast ogt float %163, 0x3FA4B5DCC0000000
  %491 = fcmp fast ogt float %164, 0x3FA4B5DCC0000000
  %492 = select i1 %489, float 0.000000e+00, float 1.000000e+00
  %493 = select i1 %490, float 0.000000e+00, float 1.000000e+00
  %494 = select i1 %491, float 0.000000e+00, float 1.000000e+00
  %495 = fmul fast float %162, 0x3FB3D07220000000
  %496 = fmul fast float %163, 0x3FB3D07220000000
  %497 = fmul fast float %164, 0x3FB3D07220000000
  %498 = fadd fast float %162, 0x3FAC28F5C0000000
  %499 = fadd fast float %163, 0x3FAC28F5C0000000
  %500 = fadd fast float %164, 0x3FAC28F5C0000000
  %501 = fmul fast float %498, 0x3FEE54EDE0000000
  %502 = fmul fast float %499, 0x3FEE54EDE0000000
  %503 = fmul fast float %500, 0x3FEE54EDE0000000
  %504 = call float @dx.op.unary.f32(i32 23, float %501)  ; Log(value)
  %505 = call float @dx.op.unary.f32(i32 23, float %502)  ; Log(value)
  %506 = call float @dx.op.unary.f32(i32 23, float %503)  ; Log(value)
  %507 = fmul fast float %504, 0x4003333340000000
  %508 = fmul fast float %505, 0x4003333340000000
  %509 = fmul fast float %506, 0x4003333340000000
  %510 = call float @dx.op.unary.f32(i32 21, float %507)  ; Exp(value)
  %511 = call float @dx.op.unary.f32(i32 21, float %508)  ; Exp(value)
  %512 = call float @dx.op.unary.f32(i32 21, float %509)  ; Exp(value)
  %513 = fsub fast float %495, %510
  %514 = fsub fast float %496, %511
  %515 = fsub fast float %497, %512
  %516 = fmul fast float %513, %492
  %517 = fmul fast float %514, %493
  %518 = fmul fast float %515, %494
  %519 = fadd fast float %516, %510
  %520 = fadd fast float %517, %511
  %521 = fadd fast float %518, %512
  br label %590

; <label>:522                                     ; preds = %483
  %523 = fadd fast float %5, 1.000000e+00
  %524 = fadd fast float %6, 1.000000e+00
  %525 = fsub fast float 1.000000e+00, %5
  %526 = fmul fast float %9, %523
  %527 = fmul fast float %9, %524
  %528 = fmul fast float %9, %525
  %529 = fmul fast float %526, %162
  %530 = fmul fast float %527, %163
  %531 = fmul fast float %528, %164
  %532 = fcmp fast ult float %10, 5.000000e-01
  br i1 %532, label %558, label %533

; <label>:533                                     ; preds = %522
  %534 = fmul fast float %529, 0x4004147AE0000000
  %535 = fmul fast float %530, 0x4004147AE0000000
  %536 = fmul fast float %531, 0x4004147AE0000000
  %537 = fadd fast float %534, 0x3F9EB851E0000000
  %538 = fadd fast float %535, 0x3F9EB851E0000000
  %539 = fadd fast float %536, 0x3F9EB851E0000000
  %540 = fmul fast float %537, %529
  %541 = fmul fast float %538, %530
  %542 = fmul fast float %539, %531
  %543 = fmul fast float %529, 0x400370A3E0000000
  %544 = fmul fast float %530, 0x400370A3E0000000
  %545 = fmul fast float %531, 0x400370A3E0000000
  %546 = fadd fast float %543, 0x3FE2E147A0000000
  %547 = fadd fast float %544, 0x3FE2E147A0000000
  %548 = fadd fast float %545, 0x3FE2E147A0000000
  %549 = fmul fast float %546, %529
  %550 = fmul fast float %547, %530
  %551 = fmul fast float %548, %531
  %552 = fadd fast float %549, 0x3FC1EB8520000000
  %553 = fadd fast float %550, 0x3FC1EB8520000000
  %554 = fadd fast float %551, 0x3FC1EB8520000000
  %555 = fdiv fast float %540, %552
  %556 = fdiv fast float %541, %553
  %557 = fdiv fast float %542, %554
  br label %558

; <label>:558                                     ; preds = %533, %522
  %559 = phi float [ %555, %533 ], [ %529, %522 ]
  %560 = phi float [ %556, %533 ], [ %530, %522 ]
  %561 = phi float [ %557, %533 ], [ %531, %522 ]
  %562 = call float @dx.op.unary.f32(i32 7, float %559)  ; Saturate(value)
  %563 = call float @dx.op.unary.f32(i32 7, float %560)  ; Saturate(value)
  %564 = call float @dx.op.unary.f32(i32 7, float %561)  ; Saturate(value)
  %565 = call float @dx.op.dot3.f32(i32 55, float %562, float %563, float %564, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %566 = fsub fast float %562, %565
  %567 = fsub fast float %563, %565
  %568 = fsub fast float %564, %565
  %569 = fmul fast float %566, %8
  %570 = fmul fast float %567, %8
  %571 = fmul fast float %568, %8
  %572 = fadd fast float %569, %565
  %573 = fadd fast float %570, %565
  %574 = fadd fast float %571, %565
  %575 = call float @dx.op.unary.f32(i32 7, float %572)  ; Saturate(value)
  %576 = call float @dx.op.unary.f32(i32 7, float %573)  ; Saturate(value)
  %577 = call float @dx.op.unary.f32(i32 7, float %574)  ; Saturate(value)
  %578 = fadd fast float %575, 0xBFC70A3D80000000
  %579 = fadd fast float %576, 0xBFC70A3D80000000
  %580 = fadd fast float %577, 0xBFC70A3D80000000
  %581 = fmul fast float %578, %7
  %582 = fmul fast float %579, %7
  %583 = fmul fast float %580, %7
  %584 = fadd fast float %581, 0x3FC70A3D80000000
  %585 = fadd fast float %582, 0x3FC70A3D80000000
  %586 = fadd fast float %583, 0x3FC70A3D80000000
  %587 = call float @dx.op.unary.f32(i32 7, float %584)  ; Saturate(value)
  %588 = call float @dx.op.unary.f32(i32 7, float %585)  ; Saturate(value)
  %589 = call float @dx.op.unary.f32(i32 7, float %586)  ; Saturate(value)
  br label %590

; <label>:590                                     ; preds = %558, %488
  %591 = phi float [ %519, %488 ], [ %587, %558 ]
  %592 = phi float [ %520, %488 ], [ %588, %558 ]
  %593 = phi float [ %521, %488 ], [ %589, %558 ]
  %594 = fsub fast float -1.000000e+00, %150
  %595 = select i1 %166, float %594, float %150
  %596 = fsub fast float -1.000000e+00, %155
  %597 = select i1 %273, float %596, float %155
  %598 = fsub fast float -1.000000e+00, %160
  %599 = select i1 %380, float %598, float %160
  %600 = fsub fast float -1.000000e+00, %165
  %601 = select i1 %487, float %600, float %165
  %602 = fcmp fast ult float %150, 0.000000e+00
  br i1 %602, label %1027, label %603

; <label>:603                                     ; preds = %590
  %604 = fsub fast float 1.000000e+00, %53
  %605 = fmul fast float %604, 0x3FA99999A0000000
  %606 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %605)  ; FMax(a,b)
  %607 = fsub fast float %55, %53
  %608 = call float @dx.op.unary.f32(i32 6, float %607)  ; FAbs(value)
  %609 = fdiv fast float %608, %606
  %610 = fsub fast float 1.000000e+00, %609
  %611 = call float @dx.op.unary.f32(i32 7, float %610)  ; Saturate(value)
  %612 = fcmp fast ugt float %611, 0.000000e+00
  br i1 %612, label %613, label %623

; <label>:613                                     ; preds = %603
  %614 = fsub fast float %377, %270
  %615 = fsub fast float %378, %271
  %616 = fsub fast float %379, %272
  %617 = fmul fast float %611, %614
  %618 = fmul fast float %611, %615
  %619 = fmul fast float %611, %616
  %620 = fadd fast float %617, %270
  %621 = fadd fast float %618, %271
  %622 = fadd fast float %619, %272
  br label %623

; <label>:623                                     ; preds = %613, %603
  %624 = phi float [ %620, %613 ], [ %270, %603 ]
  %625 = phi float [ %621, %613 ], [ %271, %603 ]
  %626 = phi float [ %622, %613 ], [ %272, %603 ]
  %627 = add i32 %26, -1
  %628 = call i32 @dx.op.binary.i32(i32 37, i32 %627, i32 0)  ; IMax(a,b)
  %629 = call i32 @dx.op.binary.i32(i32 38, i32 %628, i32 %30)  ; IMin(a,b)
  %630 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %629, i32 %35, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %631 = extractvalue %dx.types.ResRet.f32 %630, 0
  %632 = fsub fast float %631, %53
  %633 = call float @dx.op.unary.f32(i32 6, float %632)  ; FAbs(value)
  %634 = fdiv fast float %633, %606
  %635 = fsub fast float 1.000000e+00, %634
  %636 = call float @dx.op.unary.f32(i32 7, float %635)  ; Saturate(value)
  %637 = fcmp fast ugt float %636, 0.000000e+00
  br i1 %637, label %638, label %764

; <label>:638                                     ; preds = %623
  %639 = call i32 @dx.op.binary.i32(i32 37, i32 %629, i32 0)  ; IMax(a,b)
  %640 = call i32 @dx.op.binary.i32(i32 37, i32 %35, i32 0)  ; IMax(a,b)
  %641 = call i32 @dx.op.binary.i32(i32 38, i32 %639, i32 %30)  ; IMin(a,b)
  %642 = call i32 @dx.op.binary.i32(i32 38, i32 %640, i32 %31)  ; IMin(a,b)
  %643 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %641, i32 %642, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %644 = extractvalue %dx.types.ResRet.f32 %643, 0
  %645 = extractvalue %dx.types.ResRet.f32 %643, 1
  %646 = extractvalue %dx.types.ResRet.f32 %643, 2
  %647 = extractvalue %dx.types.ResRet.f32 %643, 3
  %648 = fcmp fast olt float %647, 0.000000e+00
  br i1 %648, label %649, label %683

; <label>:649                                     ; preds = %638
  %650 = fcmp fast ogt float %644, 0x3FA4B5DCC0000000
  %651 = fcmp fast ogt float %645, 0x3FA4B5DCC0000000
  %652 = fcmp fast ogt float %646, 0x3FA4B5DCC0000000
  %653 = select i1 %650, float 0.000000e+00, float 1.000000e+00
  %654 = select i1 %651, float 0.000000e+00, float 1.000000e+00
  %655 = select i1 %652, float 0.000000e+00, float 1.000000e+00
  %656 = fmul fast float %644, 0x3FB3D07220000000
  %657 = fmul fast float %645, 0x3FB3D07220000000
  %658 = fmul fast float %646, 0x3FB3D07220000000
  %659 = fadd fast float %644, 0x3FAC28F5C0000000
  %660 = fadd fast float %645, 0x3FAC28F5C0000000
  %661 = fadd fast float %646, 0x3FAC28F5C0000000
  %662 = fmul fast float %659, 0x3FEE54EDE0000000
  %663 = fmul fast float %660, 0x3FEE54EDE0000000
  %664 = fmul fast float %661, 0x3FEE54EDE0000000
  %665 = call float @dx.op.unary.f32(i32 23, float %662)  ; Log(value)
  %666 = call float @dx.op.unary.f32(i32 23, float %663)  ; Log(value)
  %667 = call float @dx.op.unary.f32(i32 23, float %664)  ; Log(value)
  %668 = fmul fast float %665, 0x4003333340000000
  %669 = fmul fast float %666, 0x4003333340000000
  %670 = fmul fast float %667, 0x4003333340000000
  %671 = call float @dx.op.unary.f32(i32 21, float %668)  ; Exp(value)
  %672 = call float @dx.op.unary.f32(i32 21, float %669)  ; Exp(value)
  %673 = call float @dx.op.unary.f32(i32 21, float %670)  ; Exp(value)
  %674 = fsub fast float %656, %671
  %675 = fsub fast float %657, %672
  %676 = fsub fast float %658, %673
  %677 = fmul fast float %674, %653
  %678 = fmul fast float %675, %654
  %679 = fmul fast float %676, %655
  %680 = fadd fast float %677, %671
  %681 = fadd fast float %678, %672
  %682 = fadd fast float %679, %673
  br label %751

; <label>:683                                     ; preds = %638
  %684 = fadd fast float %5, 1.000000e+00
  %685 = fadd fast float %6, 1.000000e+00
  %686 = fsub fast float 1.000000e+00, %5
  %687 = fmul fast float %9, %684
  %688 = fmul fast float %9, %685
  %689 = fmul fast float %9, %686
  %690 = fmul fast float %687, %644
  %691 = fmul fast float %688, %645
  %692 = fmul fast float %689, %646
  %693 = fcmp fast ult float %10, 5.000000e-01
  br i1 %693, label %719, label %694

; <label>:694                                     ; preds = %683
  %695 = fmul fast float %690, 0x4004147AE0000000
  %696 = fmul fast float %691, 0x4004147AE0000000
  %697 = fmul fast float %692, 0x4004147AE0000000
  %698 = fadd fast float %695, 0x3F9EB851E0000000
  %699 = fadd fast float %696, 0x3F9EB851E0000000
  %700 = fadd fast float %697, 0x3F9EB851E0000000
  %701 = fmul fast float %698, %690
  %702 = fmul fast float %699, %691
  %703 = fmul fast float %700, %692
  %704 = fmul fast float %690, 0x400370A3E0000000
  %705 = fmul fast float %691, 0x400370A3E0000000
  %706 = fmul fast float %692, 0x400370A3E0000000
  %707 = fadd fast float %704, 0x3FE2E147A0000000
  %708 = fadd fast float %705, 0x3FE2E147A0000000
  %709 = fadd fast float %706, 0x3FE2E147A0000000
  %710 = fmul fast float %707, %690
  %711 = fmul fast float %708, %691
  %712 = fmul fast float %709, %692
  %713 = fadd fast float %710, 0x3FC1EB8520000000
  %714 = fadd fast float %711, 0x3FC1EB8520000000
  %715 = fadd fast float %712, 0x3FC1EB8520000000
  %716 = fdiv fast float %701, %713
  %717 = fdiv fast float %702, %714
  %718 = fdiv fast float %703, %715
  br label %719

; <label>:719                                     ; preds = %694, %683
  %720 = phi float [ %716, %694 ], [ %690, %683 ]
  %721 = phi float [ %717, %694 ], [ %691, %683 ]
  %722 = phi float [ %718, %694 ], [ %692, %683 ]
  %723 = call float @dx.op.unary.f32(i32 7, float %720)  ; Saturate(value)
  %724 = call float @dx.op.unary.f32(i32 7, float %721)  ; Saturate(value)
  %725 = call float @dx.op.unary.f32(i32 7, float %722)  ; Saturate(value)
  %726 = call float @dx.op.dot3.f32(i32 55, float %723, float %724, float %725, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %727 = fsub fast float %723, %726
  %728 = fsub fast float %724, %726
  %729 = fsub fast float %725, %726
  %730 = fmul fast float %727, %8
  %731 = fmul fast float %728, %8
  %732 = fmul fast float %729, %8
  %733 = fadd fast float %730, %726
  %734 = fadd fast float %731, %726
  %735 = fadd fast float %732, %726
  %736 = call float @dx.op.unary.f32(i32 7, float %733)  ; Saturate(value)
  %737 = call float @dx.op.unary.f32(i32 7, float %734)  ; Saturate(value)
  %738 = call float @dx.op.unary.f32(i32 7, float %735)  ; Saturate(value)
  %739 = fadd fast float %736, 0xBFC70A3D80000000
  %740 = fadd fast float %737, 0xBFC70A3D80000000
  %741 = fadd fast float %738, 0xBFC70A3D80000000
  %742 = fmul fast float %739, %7
  %743 = fmul fast float %740, %7
  %744 = fmul fast float %741, %7
  %745 = fadd fast float %742, 0x3FC70A3D80000000
  %746 = fadd fast float %743, 0x3FC70A3D80000000
  %747 = fadd fast float %744, 0x3FC70A3D80000000
  %748 = call float @dx.op.unary.f32(i32 7, float %745)  ; Saturate(value)
  %749 = call float @dx.op.unary.f32(i32 7, float %746)  ; Saturate(value)
  %750 = call float @dx.op.unary.f32(i32 7, float %747)  ; Saturate(value)
  br label %751

; <label>:751                                     ; preds = %719, %649
  %752 = phi float [ %680, %649 ], [ %748, %719 ]
  %753 = phi float [ %681, %649 ], [ %749, %719 ]
  %754 = phi float [ %682, %649 ], [ %750, %719 ]
  %755 = fsub fast float %752, %270
  %756 = fsub fast float %753, %271
  %757 = fsub fast float %754, %272
  %758 = fmul fast float %755, %636
  %759 = fmul fast float %756, %636
  %760 = fmul fast float %757, %636
  %761 = fadd fast float %758, %270
  %762 = fadd fast float %759, %271
  %763 = fadd fast float %760, %272
  br label %764

; <label>:764                                     ; preds = %751, %623
  %765 = phi float [ %761, %751 ], [ %270, %623 ]
  %766 = phi float [ %762, %751 ], [ %271, %623 ]
  %767 = phi float [ %763, %751 ], [ %272, %623 ]
  %768 = fsub fast float %57, %53
  %769 = call float @dx.op.unary.f32(i32 6, float %768)  ; FAbs(value)
  %770 = fdiv fast float %769, %606
  %771 = fsub fast float 1.000000e+00, %770
  %772 = call float @dx.op.unary.f32(i32 7, float %771)  ; Saturate(value)
  %773 = fcmp fast ugt float %772, 0.000000e+00
  br i1 %773, label %774, label %784

; <label>:774                                     ; preds = %764
  %775 = fsub fast float %484, %270
  %776 = fsub fast float %485, %271
  %777 = fsub fast float %486, %272
  %778 = fmul fast float %772, %775
  %779 = fmul fast float %772, %776
  %780 = fmul fast float %772, %777
  %781 = fadd fast float %778, %270
  %782 = fadd fast float %779, %271
  %783 = fadd fast float %780, %272
  br label %784

; <label>:784                                     ; preds = %774, %764
  %785 = phi float [ %781, %774 ], [ %270, %764 ]
  %786 = phi float [ %782, %774 ], [ %271, %764 ]
  %787 = phi float [ %783, %774 ], [ %272, %764 ]
  %788 = add i32 %27, -1
  %789 = call i32 @dx.op.binary.i32(i32 37, i32 %788, i32 0)  ; IMax(a,b)
  %790 = call i32 @dx.op.binary.i32(i32 38, i32 %789, i32 %31)  ; IMin(a,b)
  %791 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %34, i32 %790, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %792 = extractvalue %dx.types.ResRet.f32 %791, 0
  %793 = fsub fast float %792, %53
  %794 = call float @dx.op.unary.f32(i32 6, float %793)  ; FAbs(value)
  %795 = fdiv fast float %794, %606
  %796 = fsub fast float 1.000000e+00, %795
  %797 = call float @dx.op.unary.f32(i32 7, float %796)  ; Saturate(value)
  %798 = fcmp fast ugt float %797, 0.000000e+00
  br i1 %798, label %799, label %925

; <label>:799                                     ; preds = %784
  %800 = call i32 @dx.op.binary.i32(i32 37, i32 %34, i32 0)  ; IMax(a,b)
  %801 = call i32 @dx.op.binary.i32(i32 37, i32 %790, i32 0)  ; IMax(a,b)
  %802 = call i32 @dx.op.binary.i32(i32 38, i32 %800, i32 %30)  ; IMin(a,b)
  %803 = call i32 @dx.op.binary.i32(i32 38, i32 %801, i32 %31)  ; IMin(a,b)
  %804 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %802, i32 %803, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %805 = extractvalue %dx.types.ResRet.f32 %804, 0
  %806 = extractvalue %dx.types.ResRet.f32 %804, 1
  %807 = extractvalue %dx.types.ResRet.f32 %804, 2
  %808 = extractvalue %dx.types.ResRet.f32 %804, 3
  %809 = fcmp fast olt float %808, 0.000000e+00
  br i1 %809, label %810, label %844

; <label>:810                                     ; preds = %799
  %811 = fcmp fast ogt float %805, 0x3FA4B5DCC0000000
  %812 = fcmp fast ogt float %806, 0x3FA4B5DCC0000000
  %813 = fcmp fast ogt float %807, 0x3FA4B5DCC0000000
  %814 = select i1 %811, float 0.000000e+00, float 1.000000e+00
  %815 = select i1 %812, float 0.000000e+00, float 1.000000e+00
  %816 = select i1 %813, float 0.000000e+00, float 1.000000e+00
  %817 = fmul fast float %805, 0x3FB3D07220000000
  %818 = fmul fast float %806, 0x3FB3D07220000000
  %819 = fmul fast float %807, 0x3FB3D07220000000
  %820 = fadd fast float %805, 0x3FAC28F5C0000000
  %821 = fadd fast float %806, 0x3FAC28F5C0000000
  %822 = fadd fast float %807, 0x3FAC28F5C0000000
  %823 = fmul fast float %820, 0x3FEE54EDE0000000
  %824 = fmul fast float %821, 0x3FEE54EDE0000000
  %825 = fmul fast float %822, 0x3FEE54EDE0000000
  %826 = call float @dx.op.unary.f32(i32 23, float %823)  ; Log(value)
  %827 = call float @dx.op.unary.f32(i32 23, float %824)  ; Log(value)
  %828 = call float @dx.op.unary.f32(i32 23, float %825)  ; Log(value)
  %829 = fmul fast float %826, 0x4003333340000000
  %830 = fmul fast float %827, 0x4003333340000000
  %831 = fmul fast float %828, 0x4003333340000000
  %832 = call float @dx.op.unary.f32(i32 21, float %829)  ; Exp(value)
  %833 = call float @dx.op.unary.f32(i32 21, float %830)  ; Exp(value)
  %834 = call float @dx.op.unary.f32(i32 21, float %831)  ; Exp(value)
  %835 = fsub fast float %817, %832
  %836 = fsub fast float %818, %833
  %837 = fsub fast float %819, %834
  %838 = fmul fast float %835, %814
  %839 = fmul fast float %836, %815
  %840 = fmul fast float %837, %816
  %841 = fadd fast float %838, %832
  %842 = fadd fast float %839, %833
  %843 = fadd fast float %840, %834
  br label %912

; <label>:844                                     ; preds = %799
  %845 = fadd fast float %5, 1.000000e+00
  %846 = fadd fast float %6, 1.000000e+00
  %847 = fsub fast float 1.000000e+00, %5
  %848 = fmul fast float %9, %845
  %849 = fmul fast float %9, %846
  %850 = fmul fast float %9, %847
  %851 = fmul fast float %848, %805
  %852 = fmul fast float %849, %806
  %853 = fmul fast float %850, %807
  %854 = fcmp fast ult float %10, 5.000000e-01
  br i1 %854, label %880, label %855

; <label>:855                                     ; preds = %844
  %856 = fmul fast float %851, 0x4004147AE0000000
  %857 = fmul fast float %852, 0x4004147AE0000000
  %858 = fmul fast float %853, 0x4004147AE0000000
  %859 = fadd fast float %856, 0x3F9EB851E0000000
  %860 = fadd fast float %857, 0x3F9EB851E0000000
  %861 = fadd fast float %858, 0x3F9EB851E0000000
  %862 = fmul fast float %859, %851
  %863 = fmul fast float %860, %852
  %864 = fmul fast float %861, %853
  %865 = fmul fast float %851, 0x400370A3E0000000
  %866 = fmul fast float %852, 0x400370A3E0000000
  %867 = fmul fast float %853, 0x400370A3E0000000
  %868 = fadd fast float %865, 0x3FE2E147A0000000
  %869 = fadd fast float %866, 0x3FE2E147A0000000
  %870 = fadd fast float %867, 0x3FE2E147A0000000
  %871 = fmul fast float %868, %851
  %872 = fmul fast float %869, %852
  %873 = fmul fast float %870, %853
  %874 = fadd fast float %871, 0x3FC1EB8520000000
  %875 = fadd fast float %872, 0x3FC1EB8520000000
  %876 = fadd fast float %873, 0x3FC1EB8520000000
  %877 = fdiv fast float %862, %874
  %878 = fdiv fast float %863, %875
  %879 = fdiv fast float %864, %876
  br label %880

; <label>:880                                     ; preds = %855, %844
  %881 = phi float [ %877, %855 ], [ %851, %844 ]
  %882 = phi float [ %878, %855 ], [ %852, %844 ]
  %883 = phi float [ %879, %855 ], [ %853, %844 ]
  %884 = call float @dx.op.unary.f32(i32 7, float %881)  ; Saturate(value)
  %885 = call float @dx.op.unary.f32(i32 7, float %882)  ; Saturate(value)
  %886 = call float @dx.op.unary.f32(i32 7, float %883)  ; Saturate(value)
  %887 = call float @dx.op.dot3.f32(i32 55, float %884, float %885, float %886, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %888 = fsub fast float %884, %887
  %889 = fsub fast float %885, %887
  %890 = fsub fast float %886, %887
  %891 = fmul fast float %888, %8
  %892 = fmul fast float %889, %8
  %893 = fmul fast float %890, %8
  %894 = fadd fast float %891, %887
  %895 = fadd fast float %892, %887
  %896 = fadd fast float %893, %887
  %897 = call float @dx.op.unary.f32(i32 7, float %894)  ; Saturate(value)
  %898 = call float @dx.op.unary.f32(i32 7, float %895)  ; Saturate(value)
  %899 = call float @dx.op.unary.f32(i32 7, float %896)  ; Saturate(value)
  %900 = fadd fast float %897, 0xBFC70A3D80000000
  %901 = fadd fast float %898, 0xBFC70A3D80000000
  %902 = fadd fast float %899, 0xBFC70A3D80000000
  %903 = fmul fast float %900, %7
  %904 = fmul fast float %901, %7
  %905 = fmul fast float %902, %7
  %906 = fadd fast float %903, 0x3FC70A3D80000000
  %907 = fadd fast float %904, 0x3FC70A3D80000000
  %908 = fadd fast float %905, 0x3FC70A3D80000000
  %909 = call float @dx.op.unary.f32(i32 7, float %906)  ; Saturate(value)
  %910 = call float @dx.op.unary.f32(i32 7, float %907)  ; Saturate(value)
  %911 = call float @dx.op.unary.f32(i32 7, float %908)  ; Saturate(value)
  br label %912

; <label>:912                                     ; preds = %880, %810
  %913 = phi float [ %841, %810 ], [ %909, %880 ]
  %914 = phi float [ %842, %810 ], [ %910, %880 ]
  %915 = phi float [ %843, %810 ], [ %911, %880 ]
  %916 = fsub fast float %913, %270
  %917 = fsub fast float %914, %271
  %918 = fsub fast float %915, %272
  %919 = fmul fast float %916, %797
  %920 = fmul fast float %917, %797
  %921 = fmul fast float %918, %797
  %922 = fadd fast float %919, %270
  %923 = fadd fast float %920, %271
  %924 = fadd fast float %921, %272
  br label %925

; <label>:925                                     ; preds = %912, %784
  %926 = phi float [ %922, %912 ], [ %270, %784 ]
  %927 = phi float [ %923, %912 ], [ %271, %784 ]
  %928 = phi float [ %924, %912 ], [ %272, %784 ]
  %929 = call float @dx.op.binary.f32(i32 36, float %765, float %624)  ; FMin(a,b)
  %930 = call float @dx.op.binary.f32(i32 36, float %766, float %625)  ; FMin(a,b)
  %931 = call float @dx.op.binary.f32(i32 36, float %767, float %626)  ; FMin(a,b)
  %932 = call float @dx.op.binary.f32(i32 36, float %926, float %785)  ; FMin(a,b)
  %933 = call float @dx.op.binary.f32(i32 36, float %927, float %786)  ; FMin(a,b)
  %934 = call float @dx.op.binary.f32(i32 36, float %928, float %787)  ; FMin(a,b)
  %935 = call float @dx.op.binary.f32(i32 36, float %932, float %929)  ; FMin(a,b)
  %936 = call float @dx.op.binary.f32(i32 36, float %933, float %930)  ; FMin(a,b)
  %937 = call float @dx.op.binary.f32(i32 36, float %934, float %931)  ; FMin(a,b)
  %938 = call float @dx.op.binary.f32(i32 36, float %270, float %935)  ; FMin(a,b)
  %939 = call float @dx.op.binary.f32(i32 36, float %271, float %936)  ; FMin(a,b)
  %940 = call float @dx.op.binary.f32(i32 36, float %272, float %937)  ; FMin(a,b)
  %941 = call float @dx.op.binary.f32(i32 35, float %765, float %624)  ; FMax(a,b)
  %942 = call float @dx.op.binary.f32(i32 35, float %766, float %625)  ; FMax(a,b)
  %943 = call float @dx.op.binary.f32(i32 35, float %767, float %626)  ; FMax(a,b)
  %944 = call float @dx.op.binary.f32(i32 35, float %926, float %785)  ; FMax(a,b)
  %945 = call float @dx.op.binary.f32(i32 35, float %927, float %786)  ; FMax(a,b)
  %946 = call float @dx.op.binary.f32(i32 35, float %928, float %787)  ; FMax(a,b)
  %947 = call float @dx.op.binary.f32(i32 35, float %944, float %941)  ; FMax(a,b)
  %948 = call float @dx.op.binary.f32(i32 35, float %945, float %942)  ; FMax(a,b)
  %949 = call float @dx.op.binary.f32(i32 35, float %946, float %943)  ; FMax(a,b)
  %950 = call float @dx.op.binary.f32(i32 35, float %270, float %947)  ; FMax(a,b)
  %951 = call float @dx.op.binary.f32(i32 35, float %271, float %948)  ; FMax(a,b)
  %952 = call float @dx.op.binary.f32(i32 35, float %272, float %949)  ; FMax(a,b)
  %953 = fsub fast float %950, %938
  %954 = fsub fast float %951, %939
  %955 = fsub fast float %952, %940
  %956 = call float @dx.op.unary.f32(i32 6, float %953)  ; FAbs(value)
  %957 = call float @dx.op.unary.f32(i32 6, float %954)  ; FAbs(value)
  %958 = call float @dx.op.unary.f32(i32 6, float %955)  ; FAbs(value)
  %959 = call float @dx.op.binary.f32(i32 35, float %957, float %958)  ; FMax(a,b)
  %960 = call float @dx.op.binary.f32(i32 35, float %956, float %959)  ; FMax(a,b)
  %961 = call float @dx.op.binary.f32(i32 35, float %951, float %952)  ; FMax(a,b)
  %962 = call float @dx.op.binary.f32(i32 35, float %950, float %961)  ; FMax(a,b)
  %963 = fmul fast float %962, 1.250000e-01
  %964 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %963)  ; FMax(a,b)
  %965 = fcmp fast ogt float %960, %964
  br i1 %965, label %966, label %1027

; <label>:966                                     ; preds = %925
  %967 = fsub fast float %926, %785
  %968 = fsub fast float %927, %786
  %969 = fsub fast float %928, %787
  %970 = call float @dx.op.unary.f32(i32 6, float %967)  ; FAbs(value)
  %971 = call float @dx.op.unary.f32(i32 6, float %968)  ; FAbs(value)
  %972 = call float @dx.op.unary.f32(i32 6, float %969)  ; FAbs(value)
  %973 = call float @dx.op.binary.f32(i32 35, float %971, float %972)  ; FMax(a,b)
  %974 = call float @dx.op.binary.f32(i32 35, float %970, float %973)  ; FMax(a,b)
  %975 = fsub fast float %765, %624
  %976 = fsub fast float %766, %625
  %977 = fsub fast float %767, %626
  %978 = call float @dx.op.unary.f32(i32 6, float %975)  ; FAbs(value)
  %979 = call float @dx.op.unary.f32(i32 6, float %976)  ; FAbs(value)
  %980 = call float @dx.op.unary.f32(i32 6, float %977)  ; FAbs(value)
  %981 = call float @dx.op.binary.f32(i32 35, float %979, float %980)  ; FMax(a,b)
  %982 = call float @dx.op.binary.f32(i32 35, float %978, float %981)  ; FMax(a,b)
  %983 = fcmp fast olt float %974, %982
  %984 = select i1 %983, float %926, float %765
  %985 = select i1 %983, float %927, float %766
  %986 = select i1 %983, float %928, float %767
  %987 = select i1 %983, float %785, float %624
  %988 = select i1 %983, float %786, float %625
  %989 = select i1 %983, float %787, float %626
  %990 = fsub fast float %270, %987
  %991 = fsub fast float %271, %988
  %992 = fsub fast float %272, %989
  %993 = fsub fast float %270, %984
  %994 = fsub fast float %271, %985
  %995 = fsub fast float %272, %986
  %996 = call float @dx.op.dot3.f32(i32 55, float %993, float %994, float %995, float %990, float %991, float %992)  ; Dot3(ax,ay,az,bx,by,bz)
  %997 = fcmp fast ogt float %996, 0.000000e+00
  br i1 %997, label %998, label %1009

; <label>:998                                     ; preds = %966
  %999 = fsub fast float %984, %987
  %1000 = fsub fast float %985, %988
  %1001 = fsub fast float %986, %989
  %1002 = call float @dx.op.unary.f32(i32 6, float %999)  ; FAbs(value)
  %1003 = call float @dx.op.unary.f32(i32 6, float %1000)  ; FAbs(value)
  %1004 = call float @dx.op.unary.f32(i32 6, float %1001)  ; FAbs(value)
  %1005 = call float @dx.op.binary.f32(i32 35, float %1003, float %1004)  ; FMax(a,b)
  %1006 = call float @dx.op.binary.f32(i32 35, float %1002, float %1005)  ; FMax(a,b)
  %1007 = fmul fast float %960, 2.500000e-01
  %1008 = fcmp fast olt float %1006, %1007
  br label %1009

; <label>:1009                                    ; preds = %998, %966
  %1010 = phi i1 [ false, %966 ], [ %1008, %998 ]
  %1011 = select i1 %1010, float 0x3FC3333340000000, float 0x3FD3333340000000
  %1012 = fadd fast float %984, %987
  %1013 = fadd fast float %985, %988
  %1014 = fadd fast float %986, %989
  %1015 = fmul fast float %1012, 5.000000e-01
  %1016 = fmul fast float %1013, 5.000000e-01
  %1017 = fmul fast float %1014, 5.000000e-01
  %1018 = fsub fast float %1015, %270
  %1019 = fsub fast float %1016, %271
  %1020 = fsub fast float %1017, %272
  %1021 = fmul fast float %1011, %1018
  %1022 = fmul fast float %1011, %1019
  %1023 = fmul fast float %1011, %1020
  %1024 = fadd fast float %1021, %270
  %1025 = fadd fast float %1022, %271
  %1026 = fadd fast float %1023, %272
  br label %1027

; <label>:1027                                    ; preds = %1009, %925, %590
  %1028 = phi float [ %270, %590 ], [ %1024, %1009 ], [ %270, %925 ]
  %1029 = phi float [ %271, %590 ], [ %1025, %1009 ], [ %271, %925 ]
  %1030 = phi float [ %272, %590 ], [ %1026, %1009 ], [ %272, %925 ]
  %1031 = fcmp fast ult float %155, 0.000000e+00
  br i1 %1031, label %1456, label %1032

; <label>:1032                                    ; preds = %1027
  %1033 = add i32 %26, 2
  %1034 = call i32 @dx.op.binary.i32(i32 37, i32 %1033, i32 0)  ; IMax(a,b)
  %1035 = call i32 @dx.op.binary.i32(i32 38, i32 %1034, i32 %30)  ; IMin(a,b)
  %1036 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1035, i32 %35, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1037 = extractvalue %dx.types.ResRet.f32 %1036, 0
  %1038 = fsub fast float 1.000000e+00, %55
  %1039 = fmul fast float %1038, 0x3FA99999A0000000
  %1040 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %1039)  ; FMax(a,b)
  %1041 = fsub fast float %1037, %55
  %1042 = call float @dx.op.unary.f32(i32 6, float %1041)  ; FAbs(value)
  %1043 = fdiv fast float %1042, %1040
  %1044 = fsub fast float 1.000000e+00, %1043
  %1045 = call float @dx.op.unary.f32(i32 7, float %1044)  ; Saturate(value)
  %1046 = fcmp fast ugt float %1045, 0.000000e+00
  br i1 %1046, label %1047, label %1173

; <label>:1047                                    ; preds = %1032
  %1048 = call i32 @dx.op.binary.i32(i32 37, i32 %1035, i32 0)  ; IMax(a,b)
  %1049 = call i32 @dx.op.binary.i32(i32 37, i32 %35, i32 0)  ; IMax(a,b)
  %1050 = call i32 @dx.op.binary.i32(i32 38, i32 %1048, i32 %30)  ; IMin(a,b)
  %1051 = call i32 @dx.op.binary.i32(i32 38, i32 %1049, i32 %31)  ; IMin(a,b)
  %1052 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1050, i32 %1051, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1053 = extractvalue %dx.types.ResRet.f32 %1052, 0
  %1054 = extractvalue %dx.types.ResRet.f32 %1052, 1
  %1055 = extractvalue %dx.types.ResRet.f32 %1052, 2
  %1056 = extractvalue %dx.types.ResRet.f32 %1052, 3
  %1057 = fcmp fast olt float %1056, 0.000000e+00
  br i1 %1057, label %1058, label %1092

; <label>:1058                                    ; preds = %1047
  %1059 = fcmp fast ogt float %1053, 0x3FA4B5DCC0000000
  %1060 = fcmp fast ogt float %1054, 0x3FA4B5DCC0000000
  %1061 = fcmp fast ogt float %1055, 0x3FA4B5DCC0000000
  %1062 = select i1 %1059, float 0.000000e+00, float 1.000000e+00
  %1063 = select i1 %1060, float 0.000000e+00, float 1.000000e+00
  %1064 = select i1 %1061, float 0.000000e+00, float 1.000000e+00
  %1065 = fmul fast float %1053, 0x3FB3D07220000000
  %1066 = fmul fast float %1054, 0x3FB3D07220000000
  %1067 = fmul fast float %1055, 0x3FB3D07220000000
  %1068 = fadd fast float %1053, 0x3FAC28F5C0000000
  %1069 = fadd fast float %1054, 0x3FAC28F5C0000000
  %1070 = fadd fast float %1055, 0x3FAC28F5C0000000
  %1071 = fmul fast float %1068, 0x3FEE54EDE0000000
  %1072 = fmul fast float %1069, 0x3FEE54EDE0000000
  %1073 = fmul fast float %1070, 0x3FEE54EDE0000000
  %1074 = call float @dx.op.unary.f32(i32 23, float %1071)  ; Log(value)
  %1075 = call float @dx.op.unary.f32(i32 23, float %1072)  ; Log(value)
  %1076 = call float @dx.op.unary.f32(i32 23, float %1073)  ; Log(value)
  %1077 = fmul fast float %1074, 0x4003333340000000
  %1078 = fmul fast float %1075, 0x4003333340000000
  %1079 = fmul fast float %1076, 0x4003333340000000
  %1080 = call float @dx.op.unary.f32(i32 21, float %1077)  ; Exp(value)
  %1081 = call float @dx.op.unary.f32(i32 21, float %1078)  ; Exp(value)
  %1082 = call float @dx.op.unary.f32(i32 21, float %1079)  ; Exp(value)
  %1083 = fsub fast float %1065, %1080
  %1084 = fsub fast float %1066, %1081
  %1085 = fsub fast float %1067, %1082
  %1086 = fmul fast float %1083, %1062
  %1087 = fmul fast float %1084, %1063
  %1088 = fmul fast float %1085, %1064
  %1089 = fadd fast float %1086, %1080
  %1090 = fadd fast float %1087, %1081
  %1091 = fadd fast float %1088, %1082
  br label %1160

; <label>:1092                                    ; preds = %1047
  %1093 = fadd fast float %5, 1.000000e+00
  %1094 = fadd fast float %6, 1.000000e+00
  %1095 = fsub fast float 1.000000e+00, %5
  %1096 = fmul fast float %9, %1093
  %1097 = fmul fast float %9, %1094
  %1098 = fmul fast float %9, %1095
  %1099 = fmul fast float %1096, %1053
  %1100 = fmul fast float %1097, %1054
  %1101 = fmul fast float %1098, %1055
  %1102 = fcmp fast ult float %10, 5.000000e-01
  br i1 %1102, label %1128, label %1103

; <label>:1103                                    ; preds = %1092
  %1104 = fmul fast float %1099, 0x4004147AE0000000
  %1105 = fmul fast float %1100, 0x4004147AE0000000
  %1106 = fmul fast float %1101, 0x4004147AE0000000
  %1107 = fadd fast float %1104, 0x3F9EB851E0000000
  %1108 = fadd fast float %1105, 0x3F9EB851E0000000
  %1109 = fadd fast float %1106, 0x3F9EB851E0000000
  %1110 = fmul fast float %1107, %1099
  %1111 = fmul fast float %1108, %1100
  %1112 = fmul fast float %1109, %1101
  %1113 = fmul fast float %1099, 0x400370A3E0000000
  %1114 = fmul fast float %1100, 0x400370A3E0000000
  %1115 = fmul fast float %1101, 0x400370A3E0000000
  %1116 = fadd fast float %1113, 0x3FE2E147A0000000
  %1117 = fadd fast float %1114, 0x3FE2E147A0000000
  %1118 = fadd fast float %1115, 0x3FE2E147A0000000
  %1119 = fmul fast float %1116, %1099
  %1120 = fmul fast float %1117, %1100
  %1121 = fmul fast float %1118, %1101
  %1122 = fadd fast float %1119, 0x3FC1EB8520000000
  %1123 = fadd fast float %1120, 0x3FC1EB8520000000
  %1124 = fadd fast float %1121, 0x3FC1EB8520000000
  %1125 = fdiv fast float %1110, %1122
  %1126 = fdiv fast float %1111, %1123
  %1127 = fdiv fast float %1112, %1124
  br label %1128

; <label>:1128                                    ; preds = %1103, %1092
  %1129 = phi float [ %1125, %1103 ], [ %1099, %1092 ]
  %1130 = phi float [ %1126, %1103 ], [ %1100, %1092 ]
  %1131 = phi float [ %1127, %1103 ], [ %1101, %1092 ]
  %1132 = call float @dx.op.unary.f32(i32 7, float %1129)  ; Saturate(value)
  %1133 = call float @dx.op.unary.f32(i32 7, float %1130)  ; Saturate(value)
  %1134 = call float @dx.op.unary.f32(i32 7, float %1131)  ; Saturate(value)
  %1135 = call float @dx.op.dot3.f32(i32 55, float %1132, float %1133, float %1134, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1136 = fsub fast float %1132, %1135
  %1137 = fsub fast float %1133, %1135
  %1138 = fsub fast float %1134, %1135
  %1139 = fmul fast float %1136, %8
  %1140 = fmul fast float %1137, %8
  %1141 = fmul fast float %1138, %8
  %1142 = fadd fast float %1139, %1135
  %1143 = fadd fast float %1140, %1135
  %1144 = fadd fast float %1141, %1135
  %1145 = call float @dx.op.unary.f32(i32 7, float %1142)  ; Saturate(value)
  %1146 = call float @dx.op.unary.f32(i32 7, float %1143)  ; Saturate(value)
  %1147 = call float @dx.op.unary.f32(i32 7, float %1144)  ; Saturate(value)
  %1148 = fadd fast float %1145, 0xBFC70A3D80000000
  %1149 = fadd fast float %1146, 0xBFC70A3D80000000
  %1150 = fadd fast float %1147, 0xBFC70A3D80000000
  %1151 = fmul fast float %1148, %7
  %1152 = fmul fast float %1149, %7
  %1153 = fmul fast float %1150, %7
  %1154 = fadd fast float %1151, 0x3FC70A3D80000000
  %1155 = fadd fast float %1152, 0x3FC70A3D80000000
  %1156 = fadd fast float %1153, 0x3FC70A3D80000000
  %1157 = call float @dx.op.unary.f32(i32 7, float %1154)  ; Saturate(value)
  %1158 = call float @dx.op.unary.f32(i32 7, float %1155)  ; Saturate(value)
  %1159 = call float @dx.op.unary.f32(i32 7, float %1156)  ; Saturate(value)
  br label %1160

; <label>:1160                                    ; preds = %1128, %1058
  %1161 = phi float [ %1089, %1058 ], [ %1157, %1128 ]
  %1162 = phi float [ %1090, %1058 ], [ %1158, %1128 ]
  %1163 = phi float [ %1091, %1058 ], [ %1159, %1128 ]
  %1164 = fsub fast float %1161, %377
  %1165 = fsub fast float %1162, %378
  %1166 = fsub fast float %1163, %379
  %1167 = fmul fast float %1164, %1045
  %1168 = fmul fast float %1165, %1045
  %1169 = fmul fast float %1166, %1045
  %1170 = fadd fast float %1167, %377
  %1171 = fadd fast float %1168, %378
  %1172 = fadd fast float %1169, %379
  br label %1173

; <label>:1173                                    ; preds = %1160, %1032
  %1174 = phi float [ %1170, %1160 ], [ %377, %1032 ]
  %1175 = phi float [ %1171, %1160 ], [ %378, %1032 ]
  %1176 = phi float [ %1172, %1160 ], [ %379, %1032 ]
  %1177 = fsub fast float %53, %55
  %1178 = call float @dx.op.unary.f32(i32 6, float %1177)  ; FAbs(value)
  %1179 = fdiv fast float %1178, %1040
  %1180 = fsub fast float 1.000000e+00, %1179
  %1181 = call float @dx.op.unary.f32(i32 7, float %1180)  ; Saturate(value)
  %1182 = fcmp fast ugt float %1181, 0.000000e+00
  br i1 %1182, label %1183, label %1193

; <label>:1183                                    ; preds = %1173
  %1184 = fsub fast float %270, %377
  %1185 = fsub fast float %271, %378
  %1186 = fsub fast float %272, %379
  %1187 = fmul fast float %1181, %1184
  %1188 = fmul fast float %1181, %1185
  %1189 = fmul fast float %1181, %1186
  %1190 = fadd fast float %1187, %377
  %1191 = fadd fast float %1188, %378
  %1192 = fadd fast float %1189, %379
  br label %1193

; <label>:1193                                    ; preds = %1183, %1173
  %1194 = phi float [ %1190, %1183 ], [ %377, %1173 ]
  %1195 = phi float [ %1191, %1183 ], [ %378, %1173 ]
  %1196 = phi float [ %1192, %1183 ], [ %379, %1173 ]
  %1197 = fsub fast float %59, %55
  %1198 = call float @dx.op.unary.f32(i32 6, float %1197)  ; FAbs(value)
  %1199 = fdiv fast float %1198, %1040
  %1200 = fsub fast float 1.000000e+00, %1199
  %1201 = call float @dx.op.unary.f32(i32 7, float %1200)  ; Saturate(value)
  %1202 = fcmp fast ugt float %1201, 0.000000e+00
  br i1 %1202, label %1203, label %1213

; <label>:1203                                    ; preds = %1193
  %1204 = fsub fast float %591, %377
  %1205 = fsub fast float %592, %378
  %1206 = fsub fast float %593, %379
  %1207 = fmul fast float %1201, %1204
  %1208 = fmul fast float %1201, %1205
  %1209 = fmul fast float %1201, %1206
  %1210 = fadd fast float %1207, %377
  %1211 = fadd fast float %1208, %378
  %1212 = fadd fast float %1209, %379
  br label %1213

; <label>:1213                                    ; preds = %1203, %1193
  %1214 = phi float [ %1210, %1203 ], [ %377, %1193 ]
  %1215 = phi float [ %1211, %1203 ], [ %378, %1193 ]
  %1216 = phi float [ %1212, %1203 ], [ %379, %1193 ]
  %1217 = add i32 %27, -1
  %1218 = call i32 @dx.op.binary.i32(i32 37, i32 %1217, i32 0)  ; IMax(a,b)
  %1219 = call i32 @dx.op.binary.i32(i32 38, i32 %1218, i32 %31)  ; IMin(a,b)
  %1220 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %38, i32 %1219, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1221 = extractvalue %dx.types.ResRet.f32 %1220, 0
  %1222 = fsub fast float %1221, %55
  %1223 = call float @dx.op.unary.f32(i32 6, float %1222)  ; FAbs(value)
  %1224 = fdiv fast float %1223, %1040
  %1225 = fsub fast float 1.000000e+00, %1224
  %1226 = call float @dx.op.unary.f32(i32 7, float %1225)  ; Saturate(value)
  %1227 = fcmp fast ugt float %1226, 0.000000e+00
  br i1 %1227, label %1228, label %1354

; <label>:1228                                    ; preds = %1213
  %1229 = call i32 @dx.op.binary.i32(i32 37, i32 %38, i32 0)  ; IMax(a,b)
  %1230 = call i32 @dx.op.binary.i32(i32 37, i32 %1219, i32 0)  ; IMax(a,b)
  %1231 = call i32 @dx.op.binary.i32(i32 38, i32 %1229, i32 %30)  ; IMin(a,b)
  %1232 = call i32 @dx.op.binary.i32(i32 38, i32 %1230, i32 %31)  ; IMin(a,b)
  %1233 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1231, i32 %1232, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1234 = extractvalue %dx.types.ResRet.f32 %1233, 0
  %1235 = extractvalue %dx.types.ResRet.f32 %1233, 1
  %1236 = extractvalue %dx.types.ResRet.f32 %1233, 2
  %1237 = extractvalue %dx.types.ResRet.f32 %1233, 3
  %1238 = fcmp fast olt float %1237, 0.000000e+00
  br i1 %1238, label %1239, label %1273

; <label>:1239                                    ; preds = %1228
  %1240 = fcmp fast ogt float %1234, 0x3FA4B5DCC0000000
  %1241 = fcmp fast ogt float %1235, 0x3FA4B5DCC0000000
  %1242 = fcmp fast ogt float %1236, 0x3FA4B5DCC0000000
  %1243 = select i1 %1240, float 0.000000e+00, float 1.000000e+00
  %1244 = select i1 %1241, float 0.000000e+00, float 1.000000e+00
  %1245 = select i1 %1242, float 0.000000e+00, float 1.000000e+00
  %1246 = fmul fast float %1234, 0x3FB3D07220000000
  %1247 = fmul fast float %1235, 0x3FB3D07220000000
  %1248 = fmul fast float %1236, 0x3FB3D07220000000
  %1249 = fadd fast float %1234, 0x3FAC28F5C0000000
  %1250 = fadd fast float %1235, 0x3FAC28F5C0000000
  %1251 = fadd fast float %1236, 0x3FAC28F5C0000000
  %1252 = fmul fast float %1249, 0x3FEE54EDE0000000
  %1253 = fmul fast float %1250, 0x3FEE54EDE0000000
  %1254 = fmul fast float %1251, 0x3FEE54EDE0000000
  %1255 = call float @dx.op.unary.f32(i32 23, float %1252)  ; Log(value)
  %1256 = call float @dx.op.unary.f32(i32 23, float %1253)  ; Log(value)
  %1257 = call float @dx.op.unary.f32(i32 23, float %1254)  ; Log(value)
  %1258 = fmul fast float %1255, 0x4003333340000000
  %1259 = fmul fast float %1256, 0x4003333340000000
  %1260 = fmul fast float %1257, 0x4003333340000000
  %1261 = call float @dx.op.unary.f32(i32 21, float %1258)  ; Exp(value)
  %1262 = call float @dx.op.unary.f32(i32 21, float %1259)  ; Exp(value)
  %1263 = call float @dx.op.unary.f32(i32 21, float %1260)  ; Exp(value)
  %1264 = fsub fast float %1246, %1261
  %1265 = fsub fast float %1247, %1262
  %1266 = fsub fast float %1248, %1263
  %1267 = fmul fast float %1264, %1243
  %1268 = fmul fast float %1265, %1244
  %1269 = fmul fast float %1266, %1245
  %1270 = fadd fast float %1267, %1261
  %1271 = fadd fast float %1268, %1262
  %1272 = fadd fast float %1269, %1263
  br label %1341

; <label>:1273                                    ; preds = %1228
  %1274 = fadd fast float %5, 1.000000e+00
  %1275 = fadd fast float %6, 1.000000e+00
  %1276 = fsub fast float 1.000000e+00, %5
  %1277 = fmul fast float %9, %1274
  %1278 = fmul fast float %9, %1275
  %1279 = fmul fast float %9, %1276
  %1280 = fmul fast float %1277, %1234
  %1281 = fmul fast float %1278, %1235
  %1282 = fmul fast float %1279, %1236
  %1283 = fcmp fast ult float %10, 5.000000e-01
  br i1 %1283, label %1309, label %1284

; <label>:1284                                    ; preds = %1273
  %1285 = fmul fast float %1280, 0x4004147AE0000000
  %1286 = fmul fast float %1281, 0x4004147AE0000000
  %1287 = fmul fast float %1282, 0x4004147AE0000000
  %1288 = fadd fast float %1285, 0x3F9EB851E0000000
  %1289 = fadd fast float %1286, 0x3F9EB851E0000000
  %1290 = fadd fast float %1287, 0x3F9EB851E0000000
  %1291 = fmul fast float %1288, %1280
  %1292 = fmul fast float %1289, %1281
  %1293 = fmul fast float %1290, %1282
  %1294 = fmul fast float %1280, 0x400370A3E0000000
  %1295 = fmul fast float %1281, 0x400370A3E0000000
  %1296 = fmul fast float %1282, 0x400370A3E0000000
  %1297 = fadd fast float %1294, 0x3FE2E147A0000000
  %1298 = fadd fast float %1295, 0x3FE2E147A0000000
  %1299 = fadd fast float %1296, 0x3FE2E147A0000000
  %1300 = fmul fast float %1297, %1280
  %1301 = fmul fast float %1298, %1281
  %1302 = fmul fast float %1299, %1282
  %1303 = fadd fast float %1300, 0x3FC1EB8520000000
  %1304 = fadd fast float %1301, 0x3FC1EB8520000000
  %1305 = fadd fast float %1302, 0x3FC1EB8520000000
  %1306 = fdiv fast float %1291, %1303
  %1307 = fdiv fast float %1292, %1304
  %1308 = fdiv fast float %1293, %1305
  br label %1309

; <label>:1309                                    ; preds = %1284, %1273
  %1310 = phi float [ %1306, %1284 ], [ %1280, %1273 ]
  %1311 = phi float [ %1307, %1284 ], [ %1281, %1273 ]
  %1312 = phi float [ %1308, %1284 ], [ %1282, %1273 ]
  %1313 = call float @dx.op.unary.f32(i32 7, float %1310)  ; Saturate(value)
  %1314 = call float @dx.op.unary.f32(i32 7, float %1311)  ; Saturate(value)
  %1315 = call float @dx.op.unary.f32(i32 7, float %1312)  ; Saturate(value)
  %1316 = call float @dx.op.dot3.f32(i32 55, float %1313, float %1314, float %1315, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1317 = fsub fast float %1313, %1316
  %1318 = fsub fast float %1314, %1316
  %1319 = fsub fast float %1315, %1316
  %1320 = fmul fast float %1317, %8
  %1321 = fmul fast float %1318, %8
  %1322 = fmul fast float %1319, %8
  %1323 = fadd fast float %1320, %1316
  %1324 = fadd fast float %1321, %1316
  %1325 = fadd fast float %1322, %1316
  %1326 = call float @dx.op.unary.f32(i32 7, float %1323)  ; Saturate(value)
  %1327 = call float @dx.op.unary.f32(i32 7, float %1324)  ; Saturate(value)
  %1328 = call float @dx.op.unary.f32(i32 7, float %1325)  ; Saturate(value)
  %1329 = fadd fast float %1326, 0xBFC70A3D80000000
  %1330 = fadd fast float %1327, 0xBFC70A3D80000000
  %1331 = fadd fast float %1328, 0xBFC70A3D80000000
  %1332 = fmul fast float %1329, %7
  %1333 = fmul fast float %1330, %7
  %1334 = fmul fast float %1331, %7
  %1335 = fadd fast float %1332, 0x3FC70A3D80000000
  %1336 = fadd fast float %1333, 0x3FC70A3D80000000
  %1337 = fadd fast float %1334, 0x3FC70A3D80000000
  %1338 = call float @dx.op.unary.f32(i32 7, float %1335)  ; Saturate(value)
  %1339 = call float @dx.op.unary.f32(i32 7, float %1336)  ; Saturate(value)
  %1340 = call float @dx.op.unary.f32(i32 7, float %1337)  ; Saturate(value)
  br label %1341

; <label>:1341                                    ; preds = %1309, %1239
  %1342 = phi float [ %1270, %1239 ], [ %1338, %1309 ]
  %1343 = phi float [ %1271, %1239 ], [ %1339, %1309 ]
  %1344 = phi float [ %1272, %1239 ], [ %1340, %1309 ]
  %1345 = fsub fast float %1342, %377
  %1346 = fsub fast float %1343, %378
  %1347 = fsub fast float %1344, %379
  %1348 = fmul fast float %1345, %1226
  %1349 = fmul fast float %1346, %1226
  %1350 = fmul fast float %1347, %1226
  %1351 = fadd fast float %1348, %377
  %1352 = fadd fast float %1349, %378
  %1353 = fadd fast float %1350, %379
  br label %1354

; <label>:1354                                    ; preds = %1341, %1213
  %1355 = phi float [ %1351, %1341 ], [ %377, %1213 ]
  %1356 = phi float [ %1352, %1341 ], [ %378, %1213 ]
  %1357 = phi float [ %1353, %1341 ], [ %379, %1213 ]
  %1358 = call float @dx.op.binary.f32(i32 36, float %1194, float %1174)  ; FMin(a,b)
  %1359 = call float @dx.op.binary.f32(i32 36, float %1195, float %1175)  ; FMin(a,b)
  %1360 = call float @dx.op.binary.f32(i32 36, float %1196, float %1176)  ; FMin(a,b)
  %1361 = call float @dx.op.binary.f32(i32 36, float %1355, float %1214)  ; FMin(a,b)
  %1362 = call float @dx.op.binary.f32(i32 36, float %1356, float %1215)  ; FMin(a,b)
  %1363 = call float @dx.op.binary.f32(i32 36, float %1357, float %1216)  ; FMin(a,b)
  %1364 = call float @dx.op.binary.f32(i32 36, float %1361, float %1358)  ; FMin(a,b)
  %1365 = call float @dx.op.binary.f32(i32 36, float %1362, float %1359)  ; FMin(a,b)
  %1366 = call float @dx.op.binary.f32(i32 36, float %1363, float %1360)  ; FMin(a,b)
  %1367 = call float @dx.op.binary.f32(i32 36, float %377, float %1364)  ; FMin(a,b)
  %1368 = call float @dx.op.binary.f32(i32 36, float %378, float %1365)  ; FMin(a,b)
  %1369 = call float @dx.op.binary.f32(i32 36, float %379, float %1366)  ; FMin(a,b)
  %1370 = call float @dx.op.binary.f32(i32 35, float %1194, float %1174)  ; FMax(a,b)
  %1371 = call float @dx.op.binary.f32(i32 35, float %1195, float %1175)  ; FMax(a,b)
  %1372 = call float @dx.op.binary.f32(i32 35, float %1196, float %1176)  ; FMax(a,b)
  %1373 = call float @dx.op.binary.f32(i32 35, float %1355, float %1214)  ; FMax(a,b)
  %1374 = call float @dx.op.binary.f32(i32 35, float %1356, float %1215)  ; FMax(a,b)
  %1375 = call float @dx.op.binary.f32(i32 35, float %1357, float %1216)  ; FMax(a,b)
  %1376 = call float @dx.op.binary.f32(i32 35, float %1373, float %1370)  ; FMax(a,b)
  %1377 = call float @dx.op.binary.f32(i32 35, float %1374, float %1371)  ; FMax(a,b)
  %1378 = call float @dx.op.binary.f32(i32 35, float %1375, float %1372)  ; FMax(a,b)
  %1379 = call float @dx.op.binary.f32(i32 35, float %377, float %1376)  ; FMax(a,b)
  %1380 = call float @dx.op.binary.f32(i32 35, float %378, float %1377)  ; FMax(a,b)
  %1381 = call float @dx.op.binary.f32(i32 35, float %379, float %1378)  ; FMax(a,b)
  %1382 = fsub fast float %1379, %1367
  %1383 = fsub fast float %1380, %1368
  %1384 = fsub fast float %1381, %1369
  %1385 = call float @dx.op.unary.f32(i32 6, float %1382)  ; FAbs(value)
  %1386 = call float @dx.op.unary.f32(i32 6, float %1383)  ; FAbs(value)
  %1387 = call float @dx.op.unary.f32(i32 6, float %1384)  ; FAbs(value)
  %1388 = call float @dx.op.binary.f32(i32 35, float %1386, float %1387)  ; FMax(a,b)
  %1389 = call float @dx.op.binary.f32(i32 35, float %1385, float %1388)  ; FMax(a,b)
  %1390 = call float @dx.op.binary.f32(i32 35, float %1380, float %1381)  ; FMax(a,b)
  %1391 = call float @dx.op.binary.f32(i32 35, float %1379, float %1390)  ; FMax(a,b)
  %1392 = fmul fast float %1391, 1.250000e-01
  %1393 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1392)  ; FMax(a,b)
  %1394 = fcmp fast ogt float %1389, %1393
  br i1 %1394, label %1395, label %1456

; <label>:1395                                    ; preds = %1354
  %1396 = fsub fast float %1355, %1214
  %1397 = fsub fast float %1356, %1215
  %1398 = fsub fast float %1357, %1216
  %1399 = call float @dx.op.unary.f32(i32 6, float %1396)  ; FAbs(value)
  %1400 = call float @dx.op.unary.f32(i32 6, float %1397)  ; FAbs(value)
  %1401 = call float @dx.op.unary.f32(i32 6, float %1398)  ; FAbs(value)
  %1402 = call float @dx.op.binary.f32(i32 35, float %1400, float %1401)  ; FMax(a,b)
  %1403 = call float @dx.op.binary.f32(i32 35, float %1399, float %1402)  ; FMax(a,b)
  %1404 = fsub fast float %1194, %1174
  %1405 = fsub fast float %1195, %1175
  %1406 = fsub fast float %1196, %1176
  %1407 = call float @dx.op.unary.f32(i32 6, float %1404)  ; FAbs(value)
  %1408 = call float @dx.op.unary.f32(i32 6, float %1405)  ; FAbs(value)
  %1409 = call float @dx.op.unary.f32(i32 6, float %1406)  ; FAbs(value)
  %1410 = call float @dx.op.binary.f32(i32 35, float %1408, float %1409)  ; FMax(a,b)
  %1411 = call float @dx.op.binary.f32(i32 35, float %1407, float %1410)  ; FMax(a,b)
  %1412 = fcmp fast olt float %1403, %1411
  %1413 = select i1 %1412, float %1355, float %1194
  %1414 = select i1 %1412, float %1356, float %1195
  %1415 = select i1 %1412, float %1357, float %1196
  %1416 = select i1 %1412, float %1214, float %1174
  %1417 = select i1 %1412, float %1215, float %1175
  %1418 = select i1 %1412, float %1216, float %1176
  %1419 = fsub fast float %377, %1416
  %1420 = fsub fast float %378, %1417
  %1421 = fsub fast float %379, %1418
  %1422 = fsub fast float %377, %1413
  %1423 = fsub fast float %378, %1414
  %1424 = fsub fast float %379, %1415
  %1425 = call float @dx.op.dot3.f32(i32 55, float %1422, float %1423, float %1424, float %1419, float %1420, float %1421)  ; Dot3(ax,ay,az,bx,by,bz)
  %1426 = fcmp fast ogt float %1425, 0.000000e+00
  br i1 %1426, label %1427, label %1438

; <label>:1427                                    ; preds = %1395
  %1428 = fsub fast float %1413, %1416
  %1429 = fsub fast float %1414, %1417
  %1430 = fsub fast float %1415, %1418
  %1431 = call float @dx.op.unary.f32(i32 6, float %1428)  ; FAbs(value)
  %1432 = call float @dx.op.unary.f32(i32 6, float %1429)  ; FAbs(value)
  %1433 = call float @dx.op.unary.f32(i32 6, float %1430)  ; FAbs(value)
  %1434 = call float @dx.op.binary.f32(i32 35, float %1432, float %1433)  ; FMax(a,b)
  %1435 = call float @dx.op.binary.f32(i32 35, float %1431, float %1434)  ; FMax(a,b)
  %1436 = fmul fast float %1389, 2.500000e-01
  %1437 = fcmp fast olt float %1435, %1436
  br label %1438

; <label>:1438                                    ; preds = %1427, %1395
  %1439 = phi i1 [ false, %1395 ], [ %1437, %1427 ]
  %1440 = select i1 %1439, float 0x3FC3333340000000, float 0x3FD3333340000000
  %1441 = fadd fast float %1413, %1416
  %1442 = fadd fast float %1414, %1417
  %1443 = fadd fast float %1415, %1418
  %1444 = fmul fast float %1441, 5.000000e-01
  %1445 = fmul fast float %1442, 5.000000e-01
  %1446 = fmul fast float %1443, 5.000000e-01
  %1447 = fsub fast float %1444, %377
  %1448 = fsub fast float %1445, %378
  %1449 = fsub fast float %1446, %379
  %1450 = fmul fast float %1440, %1447
  %1451 = fmul fast float %1440, %1448
  %1452 = fmul fast float %1440, %1449
  %1453 = fadd fast float %1450, %377
  %1454 = fadd fast float %1451, %378
  %1455 = fadd fast float %1452, %379
  br label %1456

; <label>:1456                                    ; preds = %1438, %1354, %1027
  %1457 = phi float [ %377, %1027 ], [ %1453, %1438 ], [ %377, %1354 ]
  %1458 = phi float [ %378, %1027 ], [ %1454, %1438 ], [ %378, %1354 ]
  %1459 = phi float [ %379, %1027 ], [ %1455, %1438 ], [ %379, %1354 ]
  %1460 = fcmp fast ult float %160, 0.000000e+00
  br i1 %1460, label %1885, label %1461

; <label>:1461                                    ; preds = %1456
  %1462 = fsub fast float 1.000000e+00, %57
  %1463 = fmul fast float %1462, 0x3FA99999A0000000
  %1464 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %1463)  ; FMax(a,b)
  %1465 = fsub fast float %59, %57
  %1466 = call float @dx.op.unary.f32(i32 6, float %1465)  ; FAbs(value)
  %1467 = fdiv fast float %1466, %1464
  %1468 = fsub fast float 1.000000e+00, %1467
  %1469 = call float @dx.op.unary.f32(i32 7, float %1468)  ; Saturate(value)
  %1470 = fcmp fast ugt float %1469, 0.000000e+00
  br i1 %1470, label %1471, label %1481

; <label>:1471                                    ; preds = %1461
  %1472 = fsub fast float %591, %484
  %1473 = fsub fast float %592, %485
  %1474 = fsub fast float %593, %486
  %1475 = fmul fast float %1469, %1472
  %1476 = fmul fast float %1469, %1473
  %1477 = fmul fast float %1469, %1474
  %1478 = fadd fast float %1475, %484
  %1479 = fadd fast float %1476, %485
  %1480 = fadd fast float %1477, %486
  br label %1481

; <label>:1481                                    ; preds = %1471, %1461
  %1482 = phi float [ %1478, %1471 ], [ %484, %1461 ]
  %1483 = phi float [ %1479, %1471 ], [ %485, %1461 ]
  %1484 = phi float [ %1480, %1471 ], [ %486, %1461 ]
  %1485 = add i32 %26, -1
  %1486 = call i32 @dx.op.binary.i32(i32 37, i32 %1485, i32 0)  ; IMax(a,b)
  %1487 = call i32 @dx.op.binary.i32(i32 38, i32 %1486, i32 %30)  ; IMin(a,b)
  %1488 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1487, i32 %41, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1489 = extractvalue %dx.types.ResRet.f32 %1488, 0
  %1490 = fsub fast float %1489, %57
  %1491 = call float @dx.op.unary.f32(i32 6, float %1490)  ; FAbs(value)
  %1492 = fdiv fast float %1491, %1464
  %1493 = fsub fast float 1.000000e+00, %1492
  %1494 = call float @dx.op.unary.f32(i32 7, float %1493)  ; Saturate(value)
  %1495 = fcmp fast ugt float %1494, 0.000000e+00
  br i1 %1495, label %1496, label %1622

; <label>:1496                                    ; preds = %1481
  %1497 = call i32 @dx.op.binary.i32(i32 37, i32 %1487, i32 0)  ; IMax(a,b)
  %1498 = call i32 @dx.op.binary.i32(i32 37, i32 %41, i32 0)  ; IMax(a,b)
  %1499 = call i32 @dx.op.binary.i32(i32 38, i32 %1497, i32 %30)  ; IMin(a,b)
  %1500 = call i32 @dx.op.binary.i32(i32 38, i32 %1498, i32 %31)  ; IMin(a,b)
  %1501 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1499, i32 %1500, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1502 = extractvalue %dx.types.ResRet.f32 %1501, 0
  %1503 = extractvalue %dx.types.ResRet.f32 %1501, 1
  %1504 = extractvalue %dx.types.ResRet.f32 %1501, 2
  %1505 = extractvalue %dx.types.ResRet.f32 %1501, 3
  %1506 = fcmp fast olt float %1505, 0.000000e+00
  br i1 %1506, label %1507, label %1541

; <label>:1507                                    ; preds = %1496
  %1508 = fcmp fast ogt float %1502, 0x3FA4B5DCC0000000
  %1509 = fcmp fast ogt float %1503, 0x3FA4B5DCC0000000
  %1510 = fcmp fast ogt float %1504, 0x3FA4B5DCC0000000
  %1511 = select i1 %1508, float 0.000000e+00, float 1.000000e+00
  %1512 = select i1 %1509, float 0.000000e+00, float 1.000000e+00
  %1513 = select i1 %1510, float 0.000000e+00, float 1.000000e+00
  %1514 = fmul fast float %1502, 0x3FB3D07220000000
  %1515 = fmul fast float %1503, 0x3FB3D07220000000
  %1516 = fmul fast float %1504, 0x3FB3D07220000000
  %1517 = fadd fast float %1502, 0x3FAC28F5C0000000
  %1518 = fadd fast float %1503, 0x3FAC28F5C0000000
  %1519 = fadd fast float %1504, 0x3FAC28F5C0000000
  %1520 = fmul fast float %1517, 0x3FEE54EDE0000000
  %1521 = fmul fast float %1518, 0x3FEE54EDE0000000
  %1522 = fmul fast float %1519, 0x3FEE54EDE0000000
  %1523 = call float @dx.op.unary.f32(i32 23, float %1520)  ; Log(value)
  %1524 = call float @dx.op.unary.f32(i32 23, float %1521)  ; Log(value)
  %1525 = call float @dx.op.unary.f32(i32 23, float %1522)  ; Log(value)
  %1526 = fmul fast float %1523, 0x4003333340000000
  %1527 = fmul fast float %1524, 0x4003333340000000
  %1528 = fmul fast float %1525, 0x4003333340000000
  %1529 = call float @dx.op.unary.f32(i32 21, float %1526)  ; Exp(value)
  %1530 = call float @dx.op.unary.f32(i32 21, float %1527)  ; Exp(value)
  %1531 = call float @dx.op.unary.f32(i32 21, float %1528)  ; Exp(value)
  %1532 = fsub fast float %1514, %1529
  %1533 = fsub fast float %1515, %1530
  %1534 = fsub fast float %1516, %1531
  %1535 = fmul fast float %1532, %1511
  %1536 = fmul fast float %1533, %1512
  %1537 = fmul fast float %1534, %1513
  %1538 = fadd fast float %1535, %1529
  %1539 = fadd fast float %1536, %1530
  %1540 = fadd fast float %1537, %1531
  br label %1609

; <label>:1541                                    ; preds = %1496
  %1542 = fadd fast float %5, 1.000000e+00
  %1543 = fadd fast float %6, 1.000000e+00
  %1544 = fsub fast float 1.000000e+00, %5
  %1545 = fmul fast float %9, %1542
  %1546 = fmul fast float %9, %1543
  %1547 = fmul fast float %9, %1544
  %1548 = fmul fast float %1545, %1502
  %1549 = fmul fast float %1546, %1503
  %1550 = fmul fast float %1547, %1504
  %1551 = fcmp fast ult float %10, 5.000000e-01
  br i1 %1551, label %1577, label %1552

; <label>:1552                                    ; preds = %1541
  %1553 = fmul fast float %1548, 0x4004147AE0000000
  %1554 = fmul fast float %1549, 0x4004147AE0000000
  %1555 = fmul fast float %1550, 0x4004147AE0000000
  %1556 = fadd fast float %1553, 0x3F9EB851E0000000
  %1557 = fadd fast float %1554, 0x3F9EB851E0000000
  %1558 = fadd fast float %1555, 0x3F9EB851E0000000
  %1559 = fmul fast float %1556, %1548
  %1560 = fmul fast float %1557, %1549
  %1561 = fmul fast float %1558, %1550
  %1562 = fmul fast float %1548, 0x400370A3E0000000
  %1563 = fmul fast float %1549, 0x400370A3E0000000
  %1564 = fmul fast float %1550, 0x400370A3E0000000
  %1565 = fadd fast float %1562, 0x3FE2E147A0000000
  %1566 = fadd fast float %1563, 0x3FE2E147A0000000
  %1567 = fadd fast float %1564, 0x3FE2E147A0000000
  %1568 = fmul fast float %1565, %1548
  %1569 = fmul fast float %1566, %1549
  %1570 = fmul fast float %1567, %1550
  %1571 = fadd fast float %1568, 0x3FC1EB8520000000
  %1572 = fadd fast float %1569, 0x3FC1EB8520000000
  %1573 = fadd fast float %1570, 0x3FC1EB8520000000
  %1574 = fdiv fast float %1559, %1571
  %1575 = fdiv fast float %1560, %1572
  %1576 = fdiv fast float %1561, %1573
  br label %1577

; <label>:1577                                    ; preds = %1552, %1541
  %1578 = phi float [ %1574, %1552 ], [ %1548, %1541 ]
  %1579 = phi float [ %1575, %1552 ], [ %1549, %1541 ]
  %1580 = phi float [ %1576, %1552 ], [ %1550, %1541 ]
  %1581 = call float @dx.op.unary.f32(i32 7, float %1578)  ; Saturate(value)
  %1582 = call float @dx.op.unary.f32(i32 7, float %1579)  ; Saturate(value)
  %1583 = call float @dx.op.unary.f32(i32 7, float %1580)  ; Saturate(value)
  %1584 = call float @dx.op.dot3.f32(i32 55, float %1581, float %1582, float %1583, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1585 = fsub fast float %1581, %1584
  %1586 = fsub fast float %1582, %1584
  %1587 = fsub fast float %1583, %1584
  %1588 = fmul fast float %1585, %8
  %1589 = fmul fast float %1586, %8
  %1590 = fmul fast float %1587, %8
  %1591 = fadd fast float %1588, %1584
  %1592 = fadd fast float %1589, %1584
  %1593 = fadd fast float %1590, %1584
  %1594 = call float @dx.op.unary.f32(i32 7, float %1591)  ; Saturate(value)
  %1595 = call float @dx.op.unary.f32(i32 7, float %1592)  ; Saturate(value)
  %1596 = call float @dx.op.unary.f32(i32 7, float %1593)  ; Saturate(value)
  %1597 = fadd fast float %1594, 0xBFC70A3D80000000
  %1598 = fadd fast float %1595, 0xBFC70A3D80000000
  %1599 = fadd fast float %1596, 0xBFC70A3D80000000
  %1600 = fmul fast float %1597, %7
  %1601 = fmul fast float %1598, %7
  %1602 = fmul fast float %1599, %7
  %1603 = fadd fast float %1600, 0x3FC70A3D80000000
  %1604 = fadd fast float %1601, 0x3FC70A3D80000000
  %1605 = fadd fast float %1602, 0x3FC70A3D80000000
  %1606 = call float @dx.op.unary.f32(i32 7, float %1603)  ; Saturate(value)
  %1607 = call float @dx.op.unary.f32(i32 7, float %1604)  ; Saturate(value)
  %1608 = call float @dx.op.unary.f32(i32 7, float %1605)  ; Saturate(value)
  br label %1609

; <label>:1609                                    ; preds = %1577, %1507
  %1610 = phi float [ %1538, %1507 ], [ %1606, %1577 ]
  %1611 = phi float [ %1539, %1507 ], [ %1607, %1577 ]
  %1612 = phi float [ %1540, %1507 ], [ %1608, %1577 ]
  %1613 = fsub fast float %1610, %484
  %1614 = fsub fast float %1611, %485
  %1615 = fsub fast float %1612, %486
  %1616 = fmul fast float %1613, %1494
  %1617 = fmul fast float %1614, %1494
  %1618 = fmul fast float %1615, %1494
  %1619 = fadd fast float %1616, %484
  %1620 = fadd fast float %1617, %485
  %1621 = fadd fast float %1618, %486
  br label %1622

; <label>:1622                                    ; preds = %1609, %1481
  %1623 = phi float [ %1619, %1609 ], [ %484, %1481 ]
  %1624 = phi float [ %1620, %1609 ], [ %485, %1481 ]
  %1625 = phi float [ %1621, %1609 ], [ %486, %1481 ]
  %1626 = add i32 %27, 2
  %1627 = call i32 @dx.op.binary.i32(i32 37, i32 %1626, i32 0)  ; IMax(a,b)
  %1628 = call i32 @dx.op.binary.i32(i32 38, i32 %1627, i32 %31)  ; IMin(a,b)
  %1629 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %34, i32 %1628, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1630 = extractvalue %dx.types.ResRet.f32 %1629, 0
  %1631 = fsub fast float %1630, %57
  %1632 = call float @dx.op.unary.f32(i32 6, float %1631)  ; FAbs(value)
  %1633 = fdiv fast float %1632, %1464
  %1634 = fsub fast float 1.000000e+00, %1633
  %1635 = call float @dx.op.unary.f32(i32 7, float %1634)  ; Saturate(value)
  %1636 = fcmp fast ugt float %1635, 0.000000e+00
  br i1 %1636, label %1637, label %1763

; <label>:1637                                    ; preds = %1622
  %1638 = call i32 @dx.op.binary.i32(i32 37, i32 %34, i32 0)  ; IMax(a,b)
  %1639 = call i32 @dx.op.binary.i32(i32 37, i32 %1628, i32 0)  ; IMax(a,b)
  %1640 = call i32 @dx.op.binary.i32(i32 38, i32 %1638, i32 %30)  ; IMin(a,b)
  %1641 = call i32 @dx.op.binary.i32(i32 38, i32 %1639, i32 %31)  ; IMin(a,b)
  %1642 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1640, i32 %1641, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1643 = extractvalue %dx.types.ResRet.f32 %1642, 0
  %1644 = extractvalue %dx.types.ResRet.f32 %1642, 1
  %1645 = extractvalue %dx.types.ResRet.f32 %1642, 2
  %1646 = extractvalue %dx.types.ResRet.f32 %1642, 3
  %1647 = fcmp fast olt float %1646, 0.000000e+00
  br i1 %1647, label %1648, label %1682

; <label>:1648                                    ; preds = %1637
  %1649 = fcmp fast ogt float %1643, 0x3FA4B5DCC0000000
  %1650 = fcmp fast ogt float %1644, 0x3FA4B5DCC0000000
  %1651 = fcmp fast ogt float %1645, 0x3FA4B5DCC0000000
  %1652 = select i1 %1649, float 0.000000e+00, float 1.000000e+00
  %1653 = select i1 %1650, float 0.000000e+00, float 1.000000e+00
  %1654 = select i1 %1651, float 0.000000e+00, float 1.000000e+00
  %1655 = fmul fast float %1643, 0x3FB3D07220000000
  %1656 = fmul fast float %1644, 0x3FB3D07220000000
  %1657 = fmul fast float %1645, 0x3FB3D07220000000
  %1658 = fadd fast float %1643, 0x3FAC28F5C0000000
  %1659 = fadd fast float %1644, 0x3FAC28F5C0000000
  %1660 = fadd fast float %1645, 0x3FAC28F5C0000000
  %1661 = fmul fast float %1658, 0x3FEE54EDE0000000
  %1662 = fmul fast float %1659, 0x3FEE54EDE0000000
  %1663 = fmul fast float %1660, 0x3FEE54EDE0000000
  %1664 = call float @dx.op.unary.f32(i32 23, float %1661)  ; Log(value)
  %1665 = call float @dx.op.unary.f32(i32 23, float %1662)  ; Log(value)
  %1666 = call float @dx.op.unary.f32(i32 23, float %1663)  ; Log(value)
  %1667 = fmul fast float %1664, 0x4003333340000000
  %1668 = fmul fast float %1665, 0x4003333340000000
  %1669 = fmul fast float %1666, 0x4003333340000000
  %1670 = call float @dx.op.unary.f32(i32 21, float %1667)  ; Exp(value)
  %1671 = call float @dx.op.unary.f32(i32 21, float %1668)  ; Exp(value)
  %1672 = call float @dx.op.unary.f32(i32 21, float %1669)  ; Exp(value)
  %1673 = fsub fast float %1655, %1670
  %1674 = fsub fast float %1656, %1671
  %1675 = fsub fast float %1657, %1672
  %1676 = fmul fast float %1673, %1652
  %1677 = fmul fast float %1674, %1653
  %1678 = fmul fast float %1675, %1654
  %1679 = fadd fast float %1676, %1670
  %1680 = fadd fast float %1677, %1671
  %1681 = fadd fast float %1678, %1672
  br label %1750

; <label>:1682                                    ; preds = %1637
  %1683 = fadd fast float %5, 1.000000e+00
  %1684 = fadd fast float %6, 1.000000e+00
  %1685 = fsub fast float 1.000000e+00, %5
  %1686 = fmul fast float %9, %1683
  %1687 = fmul fast float %9, %1684
  %1688 = fmul fast float %9, %1685
  %1689 = fmul fast float %1686, %1643
  %1690 = fmul fast float %1687, %1644
  %1691 = fmul fast float %1688, %1645
  %1692 = fcmp fast ult float %10, 5.000000e-01
  br i1 %1692, label %1718, label %1693

; <label>:1693                                    ; preds = %1682
  %1694 = fmul fast float %1689, 0x4004147AE0000000
  %1695 = fmul fast float %1690, 0x4004147AE0000000
  %1696 = fmul fast float %1691, 0x4004147AE0000000
  %1697 = fadd fast float %1694, 0x3F9EB851E0000000
  %1698 = fadd fast float %1695, 0x3F9EB851E0000000
  %1699 = fadd fast float %1696, 0x3F9EB851E0000000
  %1700 = fmul fast float %1697, %1689
  %1701 = fmul fast float %1698, %1690
  %1702 = fmul fast float %1699, %1691
  %1703 = fmul fast float %1689, 0x400370A3E0000000
  %1704 = fmul fast float %1690, 0x400370A3E0000000
  %1705 = fmul fast float %1691, 0x400370A3E0000000
  %1706 = fadd fast float %1703, 0x3FE2E147A0000000
  %1707 = fadd fast float %1704, 0x3FE2E147A0000000
  %1708 = fadd fast float %1705, 0x3FE2E147A0000000
  %1709 = fmul fast float %1706, %1689
  %1710 = fmul fast float %1707, %1690
  %1711 = fmul fast float %1708, %1691
  %1712 = fadd fast float %1709, 0x3FC1EB8520000000
  %1713 = fadd fast float %1710, 0x3FC1EB8520000000
  %1714 = fadd fast float %1711, 0x3FC1EB8520000000
  %1715 = fdiv fast float %1700, %1712
  %1716 = fdiv fast float %1701, %1713
  %1717 = fdiv fast float %1702, %1714
  br label %1718

; <label>:1718                                    ; preds = %1693, %1682
  %1719 = phi float [ %1715, %1693 ], [ %1689, %1682 ]
  %1720 = phi float [ %1716, %1693 ], [ %1690, %1682 ]
  %1721 = phi float [ %1717, %1693 ], [ %1691, %1682 ]
  %1722 = call float @dx.op.unary.f32(i32 7, float %1719)  ; Saturate(value)
  %1723 = call float @dx.op.unary.f32(i32 7, float %1720)  ; Saturate(value)
  %1724 = call float @dx.op.unary.f32(i32 7, float %1721)  ; Saturate(value)
  %1725 = call float @dx.op.dot3.f32(i32 55, float %1722, float %1723, float %1724, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1726 = fsub fast float %1722, %1725
  %1727 = fsub fast float %1723, %1725
  %1728 = fsub fast float %1724, %1725
  %1729 = fmul fast float %1726, %8
  %1730 = fmul fast float %1727, %8
  %1731 = fmul fast float %1728, %8
  %1732 = fadd fast float %1729, %1725
  %1733 = fadd fast float %1730, %1725
  %1734 = fadd fast float %1731, %1725
  %1735 = call float @dx.op.unary.f32(i32 7, float %1732)  ; Saturate(value)
  %1736 = call float @dx.op.unary.f32(i32 7, float %1733)  ; Saturate(value)
  %1737 = call float @dx.op.unary.f32(i32 7, float %1734)  ; Saturate(value)
  %1738 = fadd fast float %1735, 0xBFC70A3D80000000
  %1739 = fadd fast float %1736, 0xBFC70A3D80000000
  %1740 = fadd fast float %1737, 0xBFC70A3D80000000
  %1741 = fmul fast float %1738, %7
  %1742 = fmul fast float %1739, %7
  %1743 = fmul fast float %1740, %7
  %1744 = fadd fast float %1741, 0x3FC70A3D80000000
  %1745 = fadd fast float %1742, 0x3FC70A3D80000000
  %1746 = fadd fast float %1743, 0x3FC70A3D80000000
  %1747 = call float @dx.op.unary.f32(i32 7, float %1744)  ; Saturate(value)
  %1748 = call float @dx.op.unary.f32(i32 7, float %1745)  ; Saturate(value)
  %1749 = call float @dx.op.unary.f32(i32 7, float %1746)  ; Saturate(value)
  br label %1750

; <label>:1750                                    ; preds = %1718, %1648
  %1751 = phi float [ %1679, %1648 ], [ %1747, %1718 ]
  %1752 = phi float [ %1680, %1648 ], [ %1748, %1718 ]
  %1753 = phi float [ %1681, %1648 ], [ %1749, %1718 ]
  %1754 = fsub fast float %1751, %484
  %1755 = fsub fast float %1752, %485
  %1756 = fsub fast float %1753, %486
  %1757 = fmul fast float %1754, %1635
  %1758 = fmul fast float %1755, %1635
  %1759 = fmul fast float %1756, %1635
  %1760 = fadd fast float %1757, %484
  %1761 = fadd fast float %1758, %485
  %1762 = fadd fast float %1759, %486
  br label %1763

; <label>:1763                                    ; preds = %1750, %1622
  %1764 = phi float [ %1760, %1750 ], [ %484, %1622 ]
  %1765 = phi float [ %1761, %1750 ], [ %485, %1622 ]
  %1766 = phi float [ %1762, %1750 ], [ %486, %1622 ]
  %1767 = fsub fast float %53, %57
  %1768 = call float @dx.op.unary.f32(i32 6, float %1767)  ; FAbs(value)
  %1769 = fdiv fast float %1768, %1464
  %1770 = fsub fast float 1.000000e+00, %1769
  %1771 = call float @dx.op.unary.f32(i32 7, float %1770)  ; Saturate(value)
  %1772 = fcmp fast ugt float %1771, 0.000000e+00
  br i1 %1772, label %1773, label %1783

; <label>:1773                                    ; preds = %1763
  %1774 = fsub fast float %270, %484
  %1775 = fsub fast float %271, %485
  %1776 = fsub fast float %272, %486
  %1777 = fmul fast float %1771, %1774
  %1778 = fmul fast float %1771, %1775
  %1779 = fmul fast float %1771, %1776
  %1780 = fadd fast float %1777, %484
  %1781 = fadd fast float %1778, %485
  %1782 = fadd fast float %1779, %486
  br label %1783

; <label>:1783                                    ; preds = %1773, %1763
  %1784 = phi float [ %1780, %1773 ], [ %484, %1763 ]
  %1785 = phi float [ %1781, %1773 ], [ %485, %1763 ]
  %1786 = phi float [ %1782, %1773 ], [ %486, %1763 ]
  %1787 = call float @dx.op.binary.f32(i32 36, float %1623, float %1482)  ; FMin(a,b)
  %1788 = call float @dx.op.binary.f32(i32 36, float %1624, float %1483)  ; FMin(a,b)
  %1789 = call float @dx.op.binary.f32(i32 36, float %1625, float %1484)  ; FMin(a,b)
  %1790 = call float @dx.op.binary.f32(i32 36, float %1784, float %1764)  ; FMin(a,b)
  %1791 = call float @dx.op.binary.f32(i32 36, float %1785, float %1765)  ; FMin(a,b)
  %1792 = call float @dx.op.binary.f32(i32 36, float %1786, float %1766)  ; FMin(a,b)
  %1793 = call float @dx.op.binary.f32(i32 36, float %1790, float %1787)  ; FMin(a,b)
  %1794 = call float @dx.op.binary.f32(i32 36, float %1791, float %1788)  ; FMin(a,b)
  %1795 = call float @dx.op.binary.f32(i32 36, float %1792, float %1789)  ; FMin(a,b)
  %1796 = call float @dx.op.binary.f32(i32 36, float %484, float %1793)  ; FMin(a,b)
  %1797 = call float @dx.op.binary.f32(i32 36, float %485, float %1794)  ; FMin(a,b)
  %1798 = call float @dx.op.binary.f32(i32 36, float %486, float %1795)  ; FMin(a,b)
  %1799 = call float @dx.op.binary.f32(i32 35, float %1623, float %1482)  ; FMax(a,b)
  %1800 = call float @dx.op.binary.f32(i32 35, float %1624, float %1483)  ; FMax(a,b)
  %1801 = call float @dx.op.binary.f32(i32 35, float %1625, float %1484)  ; FMax(a,b)
  %1802 = call float @dx.op.binary.f32(i32 35, float %1784, float %1764)  ; FMax(a,b)
  %1803 = call float @dx.op.binary.f32(i32 35, float %1785, float %1765)  ; FMax(a,b)
  %1804 = call float @dx.op.binary.f32(i32 35, float %1786, float %1766)  ; FMax(a,b)
  %1805 = call float @dx.op.binary.f32(i32 35, float %1802, float %1799)  ; FMax(a,b)
  %1806 = call float @dx.op.binary.f32(i32 35, float %1803, float %1800)  ; FMax(a,b)
  %1807 = call float @dx.op.binary.f32(i32 35, float %1804, float %1801)  ; FMax(a,b)
  %1808 = call float @dx.op.binary.f32(i32 35, float %484, float %1805)  ; FMax(a,b)
  %1809 = call float @dx.op.binary.f32(i32 35, float %485, float %1806)  ; FMax(a,b)
  %1810 = call float @dx.op.binary.f32(i32 35, float %486, float %1807)  ; FMax(a,b)
  %1811 = fsub fast float %1808, %1796
  %1812 = fsub fast float %1809, %1797
  %1813 = fsub fast float %1810, %1798
  %1814 = call float @dx.op.unary.f32(i32 6, float %1811)  ; FAbs(value)
  %1815 = call float @dx.op.unary.f32(i32 6, float %1812)  ; FAbs(value)
  %1816 = call float @dx.op.unary.f32(i32 6, float %1813)  ; FAbs(value)
  %1817 = call float @dx.op.binary.f32(i32 35, float %1815, float %1816)  ; FMax(a,b)
  %1818 = call float @dx.op.binary.f32(i32 35, float %1814, float %1817)  ; FMax(a,b)
  %1819 = call float @dx.op.binary.f32(i32 35, float %1809, float %1810)  ; FMax(a,b)
  %1820 = call float @dx.op.binary.f32(i32 35, float %1808, float %1819)  ; FMax(a,b)
  %1821 = fmul fast float %1820, 1.250000e-01
  %1822 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1821)  ; FMax(a,b)
  %1823 = fcmp fast ogt float %1818, %1822
  br i1 %1823, label %1824, label %1885

; <label>:1824                                    ; preds = %1783
  %1825 = fsub fast float %1784, %1764
  %1826 = fsub fast float %1785, %1765
  %1827 = fsub fast float %1786, %1766
  %1828 = call float @dx.op.unary.f32(i32 6, float %1825)  ; FAbs(value)
  %1829 = call float @dx.op.unary.f32(i32 6, float %1826)  ; FAbs(value)
  %1830 = call float @dx.op.unary.f32(i32 6, float %1827)  ; FAbs(value)
  %1831 = call float @dx.op.binary.f32(i32 35, float %1829, float %1830)  ; FMax(a,b)
  %1832 = call float @dx.op.binary.f32(i32 35, float %1828, float %1831)  ; FMax(a,b)
  %1833 = fsub fast float %1623, %1482
  %1834 = fsub fast float %1624, %1483
  %1835 = fsub fast float %1625, %1484
  %1836 = call float @dx.op.unary.f32(i32 6, float %1833)  ; FAbs(value)
  %1837 = call float @dx.op.unary.f32(i32 6, float %1834)  ; FAbs(value)
  %1838 = call float @dx.op.unary.f32(i32 6, float %1835)  ; FAbs(value)
  %1839 = call float @dx.op.binary.f32(i32 35, float %1837, float %1838)  ; FMax(a,b)
  %1840 = call float @dx.op.binary.f32(i32 35, float %1836, float %1839)  ; FMax(a,b)
  %1841 = fcmp fast olt float %1832, %1840
  %1842 = select i1 %1841, float %1784, float %1623
  %1843 = select i1 %1841, float %1785, float %1624
  %1844 = select i1 %1841, float %1786, float %1625
  %1845 = select i1 %1841, float %1764, float %1482
  %1846 = select i1 %1841, float %1765, float %1483
  %1847 = select i1 %1841, float %1766, float %1484
  %1848 = fsub fast float %484, %1845
  %1849 = fsub fast float %485, %1846
  %1850 = fsub fast float %486, %1847
  %1851 = fsub fast float %484, %1842
  %1852 = fsub fast float %485, %1843
  %1853 = fsub fast float %486, %1844
  %1854 = call float @dx.op.dot3.f32(i32 55, float %1851, float %1852, float %1853, float %1848, float %1849, float %1850)  ; Dot3(ax,ay,az,bx,by,bz)
  %1855 = fcmp fast ogt float %1854, 0.000000e+00
  br i1 %1855, label %1856, label %1868

; <label>:1856                                    ; preds = %1824
  %1857 = fsub fast float %1842, %1845
  %1858 = fsub fast float %1843, %1846
  %1859 = fsub fast float %1844, %1847
  %1860 = call float @dx.op.unary.f32(i32 6, float %1857)  ; FAbs(value)
  %1861 = call float @dx.op.unary.f32(i32 6, float %1858)  ; FAbs(value)
  %1862 = call float @dx.op.unary.f32(i32 6, float %1859)  ; FAbs(value)
  %1863 = call float @dx.op.binary.f32(i32 35, float %1861, float %1862)  ; FMax(a,b)
  %1864 = call float @dx.op.binary.f32(i32 35, float %1860, float %1863)  ; FMax(a,b)
  %1865 = fmul fast float %1818, 2.500000e-01
  %1866 = fcmp fast olt float %1864, %1865
  %1867 = select i1 %1866, float 0x3FC3333340000000, float 0x3FD3333340000000
  br label %1868

; <label>:1868                                    ; preds = %1856, %1824
  %1869 = phi float [ 0x3FD3333340000000, %1824 ], [ %1867, %1856 ]
  %1870 = fadd fast float %1842, %1845
  %1871 = fadd fast float %1843, %1846
  %1872 = fadd fast float %1844, %1847
  %1873 = fmul fast float %1870, 5.000000e-01
  %1874 = fmul fast float %1871, 5.000000e-01
  %1875 = fmul fast float %1872, 5.000000e-01
  %1876 = fsub fast float %1873, %484
  %1877 = fsub fast float %1874, %485
  %1878 = fsub fast float %1875, %486
  %1879 = fmul fast float %1869, %1876
  %1880 = fmul fast float %1869, %1877
  %1881 = fmul fast float %1869, %1878
  %1882 = fadd fast float %1879, %484
  %1883 = fadd fast float %1880, %485
  %1884 = fadd fast float %1881, %486
  br label %1885

; <label>:1885                                    ; preds = %1868, %1783, %1456
  %1886 = phi float [ %484, %1456 ], [ %1882, %1868 ], [ %484, %1783 ]
  %1887 = phi float [ %485, %1456 ], [ %1883, %1868 ], [ %485, %1783 ]
  %1888 = phi float [ %486, %1456 ], [ %1884, %1868 ], [ %486, %1783 ]
  %1889 = fcmp fast ult float %165, 0.000000e+00
  br i1 %1889, label %5442, label %1890

; <label>:1890                                    ; preds = %1885
  %1891 = add i32 %26, 2
  %1892 = call i32 @dx.op.binary.i32(i32 37, i32 %1891, i32 0)  ; IMax(a,b)
  %1893 = call i32 @dx.op.binary.i32(i32 38, i32 %1892, i32 %30)  ; IMin(a,b)
  %1894 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1893, i32 %41, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1895 = extractvalue %dx.types.ResRet.f32 %1894, 0
  %1896 = fsub fast float 1.000000e+00, %59
  %1897 = fmul fast float %1896, 0x3FA99999A0000000
  %1898 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %1897)  ; FMax(a,b)
  %1899 = fsub fast float %1895, %59
  %1900 = call float @dx.op.unary.f32(i32 6, float %1899)  ; FAbs(value)
  %1901 = fdiv fast float %1900, %1898
  %1902 = fsub fast float 1.000000e+00, %1901
  %1903 = call float @dx.op.unary.f32(i32 7, float %1902)  ; Saturate(value)
  %1904 = fcmp fast ugt float %1903, 0.000000e+00
  br i1 %1904, label %1905, label %2031

; <label>:1905                                    ; preds = %1890
  %1906 = call i32 @dx.op.binary.i32(i32 37, i32 %1893, i32 0)  ; IMax(a,b)
  %1907 = call i32 @dx.op.binary.i32(i32 37, i32 %41, i32 0)  ; IMax(a,b)
  %1908 = call i32 @dx.op.binary.i32(i32 38, i32 %1906, i32 %30)  ; IMin(a,b)
  %1909 = call i32 @dx.op.binary.i32(i32 38, i32 %1907, i32 %31)  ; IMin(a,b)
  %1910 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1908, i32 %1909, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1911 = extractvalue %dx.types.ResRet.f32 %1910, 0
  %1912 = extractvalue %dx.types.ResRet.f32 %1910, 1
  %1913 = extractvalue %dx.types.ResRet.f32 %1910, 2
  %1914 = extractvalue %dx.types.ResRet.f32 %1910, 3
  %1915 = fcmp fast olt float %1914, 0.000000e+00
  br i1 %1915, label %1916, label %1950

; <label>:1916                                    ; preds = %1905
  %1917 = fcmp fast ogt float %1911, 0x3FA4B5DCC0000000
  %1918 = fcmp fast ogt float %1912, 0x3FA4B5DCC0000000
  %1919 = fcmp fast ogt float %1913, 0x3FA4B5DCC0000000
  %1920 = select i1 %1917, float 0.000000e+00, float 1.000000e+00
  %1921 = select i1 %1918, float 0.000000e+00, float 1.000000e+00
  %1922 = select i1 %1919, float 0.000000e+00, float 1.000000e+00
  %1923 = fmul fast float %1911, 0x3FB3D07220000000
  %1924 = fmul fast float %1912, 0x3FB3D07220000000
  %1925 = fmul fast float %1913, 0x3FB3D07220000000
  %1926 = fadd fast float %1911, 0x3FAC28F5C0000000
  %1927 = fadd fast float %1912, 0x3FAC28F5C0000000
  %1928 = fadd fast float %1913, 0x3FAC28F5C0000000
  %1929 = fmul fast float %1926, 0x3FEE54EDE0000000
  %1930 = fmul fast float %1927, 0x3FEE54EDE0000000
  %1931 = fmul fast float %1928, 0x3FEE54EDE0000000
  %1932 = call float @dx.op.unary.f32(i32 23, float %1929)  ; Log(value)
  %1933 = call float @dx.op.unary.f32(i32 23, float %1930)  ; Log(value)
  %1934 = call float @dx.op.unary.f32(i32 23, float %1931)  ; Log(value)
  %1935 = fmul fast float %1932, 0x4003333340000000
  %1936 = fmul fast float %1933, 0x4003333340000000
  %1937 = fmul fast float %1934, 0x4003333340000000
  %1938 = call float @dx.op.unary.f32(i32 21, float %1935)  ; Exp(value)
  %1939 = call float @dx.op.unary.f32(i32 21, float %1936)  ; Exp(value)
  %1940 = call float @dx.op.unary.f32(i32 21, float %1937)  ; Exp(value)
  %1941 = fsub fast float %1923, %1938
  %1942 = fsub fast float %1924, %1939
  %1943 = fsub fast float %1925, %1940
  %1944 = fmul fast float %1941, %1920
  %1945 = fmul fast float %1942, %1921
  %1946 = fmul fast float %1943, %1922
  %1947 = fadd fast float %1944, %1938
  %1948 = fadd fast float %1945, %1939
  %1949 = fadd fast float %1946, %1940
  br label %2018

; <label>:1950                                    ; preds = %1905
  %1951 = fadd fast float %5, 1.000000e+00
  %1952 = fadd fast float %6, 1.000000e+00
  %1953 = fsub fast float 1.000000e+00, %5
  %1954 = fmul fast float %9, %1951
  %1955 = fmul fast float %9, %1952
  %1956 = fmul fast float %9, %1953
  %1957 = fmul fast float %1954, %1911
  %1958 = fmul fast float %1955, %1912
  %1959 = fmul fast float %1956, %1913
  %1960 = fcmp fast ult float %10, 5.000000e-01
  br i1 %1960, label %1986, label %1961

; <label>:1961                                    ; preds = %1950
  %1962 = fmul fast float %1957, 0x4004147AE0000000
  %1963 = fmul fast float %1958, 0x4004147AE0000000
  %1964 = fmul fast float %1959, 0x4004147AE0000000
  %1965 = fadd fast float %1962, 0x3F9EB851E0000000
  %1966 = fadd fast float %1963, 0x3F9EB851E0000000
  %1967 = fadd fast float %1964, 0x3F9EB851E0000000
  %1968 = fmul fast float %1965, %1957
  %1969 = fmul fast float %1966, %1958
  %1970 = fmul fast float %1967, %1959
  %1971 = fmul fast float %1957, 0x400370A3E0000000
  %1972 = fmul fast float %1958, 0x400370A3E0000000
  %1973 = fmul fast float %1959, 0x400370A3E0000000
  %1974 = fadd fast float %1971, 0x3FE2E147A0000000
  %1975 = fadd fast float %1972, 0x3FE2E147A0000000
  %1976 = fadd fast float %1973, 0x3FE2E147A0000000
  %1977 = fmul fast float %1974, %1957
  %1978 = fmul fast float %1975, %1958
  %1979 = fmul fast float %1976, %1959
  %1980 = fadd fast float %1977, 0x3FC1EB8520000000
  %1981 = fadd fast float %1978, 0x3FC1EB8520000000
  %1982 = fadd fast float %1979, 0x3FC1EB8520000000
  %1983 = fdiv fast float %1968, %1980
  %1984 = fdiv fast float %1969, %1981
  %1985 = fdiv fast float %1970, %1982
  br label %1986

; <label>:1986                                    ; preds = %1961, %1950
  %1987 = phi float [ %1983, %1961 ], [ %1957, %1950 ]
  %1988 = phi float [ %1984, %1961 ], [ %1958, %1950 ]
  %1989 = phi float [ %1985, %1961 ], [ %1959, %1950 ]
  %1990 = call float @dx.op.unary.f32(i32 7, float %1987)  ; Saturate(value)
  %1991 = call float @dx.op.unary.f32(i32 7, float %1988)  ; Saturate(value)
  %1992 = call float @dx.op.unary.f32(i32 7, float %1989)  ; Saturate(value)
  %1993 = call float @dx.op.dot3.f32(i32 55, float %1990, float %1991, float %1992, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1994 = fsub fast float %1990, %1993
  %1995 = fsub fast float %1991, %1993
  %1996 = fsub fast float %1992, %1993
  %1997 = fmul fast float %1994, %8
  %1998 = fmul fast float %1995, %8
  %1999 = fmul fast float %1996, %8
  %2000 = fadd fast float %1997, %1993
  %2001 = fadd fast float %1998, %1993
  %2002 = fadd fast float %1999, %1993
  %2003 = call float @dx.op.unary.f32(i32 7, float %2000)  ; Saturate(value)
  %2004 = call float @dx.op.unary.f32(i32 7, float %2001)  ; Saturate(value)
  %2005 = call float @dx.op.unary.f32(i32 7, float %2002)  ; Saturate(value)
  %2006 = fadd fast float %2003, 0xBFC70A3D80000000
  %2007 = fadd fast float %2004, 0xBFC70A3D80000000
  %2008 = fadd fast float %2005, 0xBFC70A3D80000000
  %2009 = fmul fast float %2006, %7
  %2010 = fmul fast float %2007, %7
  %2011 = fmul fast float %2008, %7
  %2012 = fadd fast float %2009, 0x3FC70A3D80000000
  %2013 = fadd fast float %2010, 0x3FC70A3D80000000
  %2014 = fadd fast float %2011, 0x3FC70A3D80000000
  %2015 = call float @dx.op.unary.f32(i32 7, float %2012)  ; Saturate(value)
  %2016 = call float @dx.op.unary.f32(i32 7, float %2013)  ; Saturate(value)
  %2017 = call float @dx.op.unary.f32(i32 7, float %2014)  ; Saturate(value)
  br label %2018

; <label>:2018                                    ; preds = %1986, %1916
  %2019 = phi float [ %1947, %1916 ], [ %2015, %1986 ]
  %2020 = phi float [ %1948, %1916 ], [ %2016, %1986 ]
  %2021 = phi float [ %1949, %1916 ], [ %2017, %1986 ]
  %2022 = fsub fast float %2019, %591
  %2023 = fsub fast float %2020, %592
  %2024 = fsub fast float %2021, %593
  %2025 = fmul fast float %2022, %1903
  %2026 = fmul fast float %2023, %1903
  %2027 = fmul fast float %2024, %1903
  %2028 = fadd fast float %2025, %591
  %2029 = fadd fast float %2026, %592
  %2030 = fadd fast float %2027, %593
  br label %2031

; <label>:2031                                    ; preds = %2018, %1890
  %2032 = phi float [ %2028, %2018 ], [ %591, %1890 ]
  %2033 = phi float [ %2029, %2018 ], [ %592, %1890 ]
  %2034 = phi float [ %2030, %2018 ], [ %593, %1890 ]
  %2035 = fsub fast float %57, %59
  %2036 = call float @dx.op.unary.f32(i32 6, float %2035)  ; FAbs(value)
  %2037 = fdiv fast float %2036, %1898
  %2038 = fsub fast float 1.000000e+00, %2037
  %2039 = call float @dx.op.unary.f32(i32 7, float %2038)  ; Saturate(value)
  %2040 = fcmp fast ugt float %2039, 0.000000e+00
  br i1 %2040, label %2041, label %2051

; <label>:2041                                    ; preds = %2031
  %2042 = fsub fast float %484, %591
  %2043 = fsub fast float %485, %592
  %2044 = fsub fast float %486, %593
  %2045 = fmul fast float %2039, %2042
  %2046 = fmul fast float %2039, %2043
  %2047 = fmul fast float %2039, %2044
  %2048 = fadd fast float %2045, %591
  %2049 = fadd fast float %2046, %592
  %2050 = fadd fast float %2047, %593
  br label %2051

; <label>:2051                                    ; preds = %2041, %2031
  %2052 = phi float [ %2048, %2041 ], [ %591, %2031 ]
  %2053 = phi float [ %2049, %2041 ], [ %592, %2031 ]
  %2054 = phi float [ %2050, %2041 ], [ %593, %2031 ]
  %2055 = add i32 %27, 2
  %2056 = call i32 @dx.op.binary.i32(i32 37, i32 %2055, i32 0)  ; IMax(a,b)
  %2057 = call i32 @dx.op.binary.i32(i32 38, i32 %2056, i32 %31)  ; IMin(a,b)
  %2058 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %38, i32 %2057, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2059 = extractvalue %dx.types.ResRet.f32 %2058, 0
  %2060 = fsub fast float %2059, %59
  %2061 = call float @dx.op.unary.f32(i32 6, float %2060)  ; FAbs(value)
  %2062 = fdiv fast float %2061, %1898
  %2063 = fsub fast float 1.000000e+00, %2062
  %2064 = call float @dx.op.unary.f32(i32 7, float %2063)  ; Saturate(value)
  %2065 = fcmp fast ugt float %2064, 0.000000e+00
  br i1 %2065, label %2066, label %2192

; <label>:2066                                    ; preds = %2051
  %2067 = call i32 @dx.op.binary.i32(i32 37, i32 %38, i32 0)  ; IMax(a,b)
  %2068 = call i32 @dx.op.binary.i32(i32 37, i32 %2057, i32 0)  ; IMax(a,b)
  %2069 = call i32 @dx.op.binary.i32(i32 38, i32 %2067, i32 %30)  ; IMin(a,b)
  %2070 = call i32 @dx.op.binary.i32(i32 38, i32 %2068, i32 %31)  ; IMin(a,b)
  %2071 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2069, i32 %2070, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2072 = extractvalue %dx.types.ResRet.f32 %2071, 0
  %2073 = extractvalue %dx.types.ResRet.f32 %2071, 1
  %2074 = extractvalue %dx.types.ResRet.f32 %2071, 2
  %2075 = extractvalue %dx.types.ResRet.f32 %2071, 3
  %2076 = fcmp fast olt float %2075, 0.000000e+00
  br i1 %2076, label %2077, label %2111

; <label>:2077                                    ; preds = %2066
  %2078 = fcmp fast ogt float %2072, 0x3FA4B5DCC0000000
  %2079 = fcmp fast ogt float %2073, 0x3FA4B5DCC0000000
  %2080 = fcmp fast ogt float %2074, 0x3FA4B5DCC0000000
  %2081 = select i1 %2078, float 0.000000e+00, float 1.000000e+00
  %2082 = select i1 %2079, float 0.000000e+00, float 1.000000e+00
  %2083 = select i1 %2080, float 0.000000e+00, float 1.000000e+00
  %2084 = fmul fast float %2072, 0x3FB3D07220000000
  %2085 = fmul fast float %2073, 0x3FB3D07220000000
  %2086 = fmul fast float %2074, 0x3FB3D07220000000
  %2087 = fadd fast float %2072, 0x3FAC28F5C0000000
  %2088 = fadd fast float %2073, 0x3FAC28F5C0000000
  %2089 = fadd fast float %2074, 0x3FAC28F5C0000000
  %2090 = fmul fast float %2087, 0x3FEE54EDE0000000
  %2091 = fmul fast float %2088, 0x3FEE54EDE0000000
  %2092 = fmul fast float %2089, 0x3FEE54EDE0000000
  %2093 = call float @dx.op.unary.f32(i32 23, float %2090)  ; Log(value)
  %2094 = call float @dx.op.unary.f32(i32 23, float %2091)  ; Log(value)
  %2095 = call float @dx.op.unary.f32(i32 23, float %2092)  ; Log(value)
  %2096 = fmul fast float %2093, 0x4003333340000000
  %2097 = fmul fast float %2094, 0x4003333340000000
  %2098 = fmul fast float %2095, 0x4003333340000000
  %2099 = call float @dx.op.unary.f32(i32 21, float %2096)  ; Exp(value)
  %2100 = call float @dx.op.unary.f32(i32 21, float %2097)  ; Exp(value)
  %2101 = call float @dx.op.unary.f32(i32 21, float %2098)  ; Exp(value)
  %2102 = fsub fast float %2084, %2099
  %2103 = fsub fast float %2085, %2100
  %2104 = fsub fast float %2086, %2101
  %2105 = fmul fast float %2102, %2081
  %2106 = fmul fast float %2103, %2082
  %2107 = fmul fast float %2104, %2083
  %2108 = fadd fast float %2105, %2099
  %2109 = fadd fast float %2106, %2100
  %2110 = fadd fast float %2107, %2101
  br label %2179

; <label>:2111                                    ; preds = %2066
  %2112 = fadd fast float %5, 1.000000e+00
  %2113 = fadd fast float %6, 1.000000e+00
  %2114 = fsub fast float 1.000000e+00, %5
  %2115 = fmul fast float %9, %2112
  %2116 = fmul fast float %9, %2113
  %2117 = fmul fast float %9, %2114
  %2118 = fmul fast float %2115, %2072
  %2119 = fmul fast float %2116, %2073
  %2120 = fmul fast float %2117, %2074
  %2121 = fcmp fast ult float %10, 5.000000e-01
  br i1 %2121, label %2147, label %2122

; <label>:2122                                    ; preds = %2111
  %2123 = fmul fast float %2118, 0x4004147AE0000000
  %2124 = fmul fast float %2119, 0x4004147AE0000000
  %2125 = fmul fast float %2120, 0x4004147AE0000000
  %2126 = fadd fast float %2123, 0x3F9EB851E0000000
  %2127 = fadd fast float %2124, 0x3F9EB851E0000000
  %2128 = fadd fast float %2125, 0x3F9EB851E0000000
  %2129 = fmul fast float %2126, %2118
  %2130 = fmul fast float %2127, %2119
  %2131 = fmul fast float %2128, %2120
  %2132 = fmul fast float %2118, 0x400370A3E0000000
  %2133 = fmul fast float %2119, 0x400370A3E0000000
  %2134 = fmul fast float %2120, 0x400370A3E0000000
  %2135 = fadd fast float %2132, 0x3FE2E147A0000000
  %2136 = fadd fast float %2133, 0x3FE2E147A0000000
  %2137 = fadd fast float %2134, 0x3FE2E147A0000000
  %2138 = fmul fast float %2135, %2118
  %2139 = fmul fast float %2136, %2119
  %2140 = fmul fast float %2137, %2120
  %2141 = fadd fast float %2138, 0x3FC1EB8520000000
  %2142 = fadd fast float %2139, 0x3FC1EB8520000000
  %2143 = fadd fast float %2140, 0x3FC1EB8520000000
  %2144 = fdiv fast float %2129, %2141
  %2145 = fdiv fast float %2130, %2142
  %2146 = fdiv fast float %2131, %2143
  br label %2147

; <label>:2147                                    ; preds = %2122, %2111
  %2148 = phi float [ %2144, %2122 ], [ %2118, %2111 ]
  %2149 = phi float [ %2145, %2122 ], [ %2119, %2111 ]
  %2150 = phi float [ %2146, %2122 ], [ %2120, %2111 ]
  %2151 = call float @dx.op.unary.f32(i32 7, float %2148)  ; Saturate(value)
  %2152 = call float @dx.op.unary.f32(i32 7, float %2149)  ; Saturate(value)
  %2153 = call float @dx.op.unary.f32(i32 7, float %2150)  ; Saturate(value)
  %2154 = call float @dx.op.dot3.f32(i32 55, float %2151, float %2152, float %2153, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2155 = fsub fast float %2151, %2154
  %2156 = fsub fast float %2152, %2154
  %2157 = fsub fast float %2153, %2154
  %2158 = fmul fast float %2155, %8
  %2159 = fmul fast float %2156, %8
  %2160 = fmul fast float %2157, %8
  %2161 = fadd fast float %2158, %2154
  %2162 = fadd fast float %2159, %2154
  %2163 = fadd fast float %2160, %2154
  %2164 = call float @dx.op.unary.f32(i32 7, float %2161)  ; Saturate(value)
  %2165 = call float @dx.op.unary.f32(i32 7, float %2162)  ; Saturate(value)
  %2166 = call float @dx.op.unary.f32(i32 7, float %2163)  ; Saturate(value)
  %2167 = fadd fast float %2164, 0xBFC70A3D80000000
  %2168 = fadd fast float %2165, 0xBFC70A3D80000000
  %2169 = fadd fast float %2166, 0xBFC70A3D80000000
  %2170 = fmul fast float %2167, %7
  %2171 = fmul fast float %2168, %7
  %2172 = fmul fast float %2169, %7
  %2173 = fadd fast float %2170, 0x3FC70A3D80000000
  %2174 = fadd fast float %2171, 0x3FC70A3D80000000
  %2175 = fadd fast float %2172, 0x3FC70A3D80000000
  %2176 = call float @dx.op.unary.f32(i32 7, float %2173)  ; Saturate(value)
  %2177 = call float @dx.op.unary.f32(i32 7, float %2174)  ; Saturate(value)
  %2178 = call float @dx.op.unary.f32(i32 7, float %2175)  ; Saturate(value)
  br label %2179

; <label>:2179                                    ; preds = %2147, %2077
  %2180 = phi float [ %2108, %2077 ], [ %2176, %2147 ]
  %2181 = phi float [ %2109, %2077 ], [ %2177, %2147 ]
  %2182 = phi float [ %2110, %2077 ], [ %2178, %2147 ]
  %2183 = fsub fast float %2180, %591
  %2184 = fsub fast float %2181, %592
  %2185 = fsub fast float %2182, %593
  %2186 = fmul fast float %2183, %2064
  %2187 = fmul fast float %2184, %2064
  %2188 = fmul fast float %2185, %2064
  %2189 = fadd fast float %2186, %591
  %2190 = fadd fast float %2187, %592
  %2191 = fadd fast float %2188, %593
  br label %2192

; <label>:2192                                    ; preds = %2179, %2051
  %2193 = phi float [ %2189, %2179 ], [ %591, %2051 ]
  %2194 = phi float [ %2190, %2179 ], [ %592, %2051 ]
  %2195 = phi float [ %2191, %2179 ], [ %593, %2051 ]
  %2196 = fsub fast float %55, %59
  %2197 = call float @dx.op.unary.f32(i32 6, float %2196)  ; FAbs(value)
  %2198 = fdiv fast float %2197, %1898
  %2199 = fsub fast float 1.000000e+00, %2198
  %2200 = call float @dx.op.unary.f32(i32 7, float %2199)  ; Saturate(value)
  %2201 = fcmp fast ugt float %2200, 0.000000e+00
  br i1 %2201, label %2202, label %2212

; <label>:2202                                    ; preds = %2192
  %2203 = fsub fast float %377, %591
  %2204 = fsub fast float %378, %592
  %2205 = fsub fast float %379, %593
  %2206 = fmul fast float %2200, %2203
  %2207 = fmul fast float %2200, %2204
  %2208 = fmul fast float %2200, %2205
  %2209 = fadd fast float %2206, %591
  %2210 = fadd fast float %2207, %592
  %2211 = fadd fast float %2208, %593
  br label %2212

; <label>:2212                                    ; preds = %2202, %2192
  %2213 = phi float [ %2209, %2202 ], [ %591, %2192 ]
  %2214 = phi float [ %2210, %2202 ], [ %592, %2192 ]
  %2215 = phi float [ %2211, %2202 ], [ %593, %2192 ]
  %2216 = call float @dx.op.binary.f32(i32 36, float %2052, float %2032)  ; FMin(a,b)
  %2217 = call float @dx.op.binary.f32(i32 36, float %2053, float %2033)  ; FMin(a,b)
  %2218 = call float @dx.op.binary.f32(i32 36, float %2054, float %2034)  ; FMin(a,b)
  %2219 = call float @dx.op.binary.f32(i32 36, float %2213, float %2193)  ; FMin(a,b)
  %2220 = call float @dx.op.binary.f32(i32 36, float %2214, float %2194)  ; FMin(a,b)
  %2221 = call float @dx.op.binary.f32(i32 36, float %2215, float %2195)  ; FMin(a,b)
  %2222 = call float @dx.op.binary.f32(i32 36, float %2219, float %2216)  ; FMin(a,b)
  %2223 = call float @dx.op.binary.f32(i32 36, float %2220, float %2217)  ; FMin(a,b)
  %2224 = call float @dx.op.binary.f32(i32 36, float %2221, float %2218)  ; FMin(a,b)
  %2225 = call float @dx.op.binary.f32(i32 36, float %591, float %2222)  ; FMin(a,b)
  %2226 = call float @dx.op.binary.f32(i32 36, float %592, float %2223)  ; FMin(a,b)
  %2227 = call float @dx.op.binary.f32(i32 36, float %593, float %2224)  ; FMin(a,b)
  %2228 = call float @dx.op.binary.f32(i32 35, float %2052, float %2032)  ; FMax(a,b)
  %2229 = call float @dx.op.binary.f32(i32 35, float %2053, float %2033)  ; FMax(a,b)
  %2230 = call float @dx.op.binary.f32(i32 35, float %2054, float %2034)  ; FMax(a,b)
  %2231 = call float @dx.op.binary.f32(i32 35, float %2213, float %2193)  ; FMax(a,b)
  %2232 = call float @dx.op.binary.f32(i32 35, float %2214, float %2194)  ; FMax(a,b)
  %2233 = call float @dx.op.binary.f32(i32 35, float %2215, float %2195)  ; FMax(a,b)
  %2234 = call float @dx.op.binary.f32(i32 35, float %2231, float %2228)  ; FMax(a,b)
  %2235 = call float @dx.op.binary.f32(i32 35, float %2232, float %2229)  ; FMax(a,b)
  %2236 = call float @dx.op.binary.f32(i32 35, float %2233, float %2230)  ; FMax(a,b)
  %2237 = call float @dx.op.binary.f32(i32 35, float %591, float %2234)  ; FMax(a,b)
  %2238 = call float @dx.op.binary.f32(i32 35, float %592, float %2235)  ; FMax(a,b)
  %2239 = call float @dx.op.binary.f32(i32 35, float %593, float %2236)  ; FMax(a,b)
  %2240 = fsub fast float %2237, %2225
  %2241 = fsub fast float %2238, %2226
  %2242 = fsub fast float %2239, %2227
  %2243 = call float @dx.op.unary.f32(i32 6, float %2240)  ; FAbs(value)
  %2244 = call float @dx.op.unary.f32(i32 6, float %2241)  ; FAbs(value)
  %2245 = call float @dx.op.unary.f32(i32 6, float %2242)  ; FAbs(value)
  %2246 = call float @dx.op.binary.f32(i32 35, float %2244, float %2245)  ; FMax(a,b)
  %2247 = call float @dx.op.binary.f32(i32 35, float %2243, float %2246)  ; FMax(a,b)
  %2248 = call float @dx.op.binary.f32(i32 35, float %2238, float %2239)  ; FMax(a,b)
  %2249 = call float @dx.op.binary.f32(i32 35, float %2237, float %2248)  ; FMax(a,b)
  %2250 = fmul fast float %2249, 1.250000e-01
  %2251 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %2250)  ; FMax(a,b)
  %2252 = fcmp fast ogt float %2247, %2251
  br i1 %2252, label %2253, label %5442

; <label>:2253                                    ; preds = %2212
  %2254 = fsub fast float %2213, %2193
  %2255 = fsub fast float %2214, %2194
  %2256 = fsub fast float %2215, %2195
  %2257 = call float @dx.op.unary.f32(i32 6, float %2254)  ; FAbs(value)
  %2258 = call float @dx.op.unary.f32(i32 6, float %2255)  ; FAbs(value)
  %2259 = call float @dx.op.unary.f32(i32 6, float %2256)  ; FAbs(value)
  %2260 = call float @dx.op.binary.f32(i32 35, float %2258, float %2259)  ; FMax(a,b)
  %2261 = call float @dx.op.binary.f32(i32 35, float %2257, float %2260)  ; FMax(a,b)
  %2262 = fsub fast float %2052, %2032
  %2263 = fsub fast float %2053, %2033
  %2264 = fsub fast float %2054, %2034
  %2265 = call float @dx.op.unary.f32(i32 6, float %2262)  ; FAbs(value)
  %2266 = call float @dx.op.unary.f32(i32 6, float %2263)  ; FAbs(value)
  %2267 = call float @dx.op.unary.f32(i32 6, float %2264)  ; FAbs(value)
  %2268 = call float @dx.op.binary.f32(i32 35, float %2266, float %2267)  ; FMax(a,b)
  %2269 = call float @dx.op.binary.f32(i32 35, float %2265, float %2268)  ; FMax(a,b)
  %2270 = fcmp fast olt float %2261, %2269
  %2271 = select i1 %2270, float %2213, float %2052
  %2272 = select i1 %2270, float %2214, float %2053
  %2273 = select i1 %2270, float %2215, float %2054
  %2274 = select i1 %2270, float %2193, float %2032
  %2275 = select i1 %2270, float %2194, float %2033
  %2276 = select i1 %2270, float %2195, float %2034
  %2277 = fsub fast float %591, %2274
  %2278 = fsub fast float %592, %2275
  %2279 = fsub fast float %593, %2276
  %2280 = fsub fast float %591, %2271
  %2281 = fsub fast float %592, %2272
  %2282 = fsub fast float %593, %2273
  %2283 = call float @dx.op.dot3.f32(i32 55, float %2280, float %2281, float %2282, float %2277, float %2278, float %2279)  ; Dot3(ax,ay,az,bx,by,bz)
  %2284 = fcmp fast ogt float %2283, 0.000000e+00
  br i1 %2284, label %2285, label %2297

; <label>:2285                                    ; preds = %2253
  %2286 = fsub fast float %2271, %2274
  %2287 = fsub fast float %2272, %2275
  %2288 = fsub fast float %2273, %2276
  %2289 = call float @dx.op.unary.f32(i32 6, float %2286)  ; FAbs(value)
  %2290 = call float @dx.op.unary.f32(i32 6, float %2287)  ; FAbs(value)
  %2291 = call float @dx.op.unary.f32(i32 6, float %2288)  ; FAbs(value)
  %2292 = call float @dx.op.binary.f32(i32 35, float %2290, float %2291)  ; FMax(a,b)
  %2293 = call float @dx.op.binary.f32(i32 35, float %2289, float %2292)  ; FMax(a,b)
  %2294 = fmul fast float %2247, 2.500000e-01
  %2295 = fcmp fast olt float %2293, %2294
  %2296 = select i1 %2295, float 0x3FC3333340000000, float 0x3FD3333340000000
  br label %2297

; <label>:2297                                    ; preds = %2285, %2253
  %2298 = phi float [ 0x3FD3333340000000, %2253 ], [ %2296, %2285 ]
  %2299 = fadd fast float %2271, %2274
  %2300 = fadd fast float %2272, %2275
  %2301 = fadd fast float %2273, %2276
  %2302 = fmul fast float %2299, 5.000000e-01
  %2303 = fmul fast float %2300, 5.000000e-01
  %2304 = fmul fast float %2301, 5.000000e-01
  %2305 = fsub fast float %2302, %591
  %2306 = fsub fast float %2303, %592
  %2307 = fsub fast float %2304, %593
  %2308 = fmul fast float %2298, %2305
  %2309 = fmul fast float %2298, %2306
  %2310 = fmul fast float %2298, %2307
  %2311 = fadd fast float %2308, %591
  %2312 = fadd fast float %2309, %592
  %2313 = fadd fast float %2310, %593
  br label %5442

; <label>:2314                                    ; preds = %143
  %2315 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %34, i32 %35, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2316 = extractvalue %dx.types.ResRet.f32 %2315, 0
  %2317 = extractvalue %dx.types.ResRet.f32 %2315, 1
  %2318 = extractvalue %dx.types.ResRet.f32 %2315, 2
  %2319 = extractvalue %dx.types.ResRet.f32 %2315, 3
  %2320 = fcmp fast olt float %2319, 0.000000e+00
  br i1 %2320, label %2321, label %2356

; <label>:2321                                    ; preds = %2314
  %2322 = fcmp fast ogt float %2316, 0x3FA4B5DCC0000000
  %2323 = fcmp fast ogt float %2317, 0x3FA4B5DCC0000000
  %2324 = fcmp fast ogt float %2318, 0x3FA4B5DCC0000000
  %2325 = select i1 %2322, float 0.000000e+00, float 1.000000e+00
  %2326 = select i1 %2323, float 0.000000e+00, float 1.000000e+00
  %2327 = select i1 %2324, float 0.000000e+00, float 1.000000e+00
  %2328 = fmul fast float %2316, 0x3FB3D07220000000
  %2329 = fmul fast float %2317, 0x3FB3D07220000000
  %2330 = fmul fast float %2318, 0x3FB3D07220000000
  %2331 = fadd fast float %2316, 0x3FAC28F5C0000000
  %2332 = fadd fast float %2317, 0x3FAC28F5C0000000
  %2333 = fadd fast float %2318, 0x3FAC28F5C0000000
  %2334 = fmul fast float %2331, 0x3FEE54EDE0000000
  %2335 = fmul fast float %2332, 0x3FEE54EDE0000000
  %2336 = fmul fast float %2333, 0x3FEE54EDE0000000
  %2337 = call float @dx.op.unary.f32(i32 23, float %2334)  ; Log(value)
  %2338 = call float @dx.op.unary.f32(i32 23, float %2335)  ; Log(value)
  %2339 = call float @dx.op.unary.f32(i32 23, float %2336)  ; Log(value)
  %2340 = fmul fast float %2337, 0x4003333340000000
  %2341 = fmul fast float %2338, 0x4003333340000000
  %2342 = fmul fast float %2339, 0x4003333340000000
  %2343 = call float @dx.op.unary.f32(i32 21, float %2340)  ; Exp(value)
  %2344 = call float @dx.op.unary.f32(i32 21, float %2341)  ; Exp(value)
  %2345 = call float @dx.op.unary.f32(i32 21, float %2342)  ; Exp(value)
  %2346 = fsub fast float %2328, %2343
  %2347 = fsub fast float %2329, %2344
  %2348 = fsub fast float %2330, %2345
  %2349 = fmul fast float %2346, %2325
  %2350 = fmul fast float %2347, %2326
  %2351 = fmul fast float %2348, %2327
  %2352 = fadd fast float %2349, %2343
  %2353 = fadd fast float %2350, %2344
  %2354 = fadd fast float %2351, %2345
  %2355 = fsub fast float -1.000000e+00, %2319
  br label %3093

; <label>:2356                                    ; preds = %2314
  %2357 = fadd fast float %5, 1.000000e+00
  %2358 = fadd fast float %6, 1.000000e+00
  %2359 = fsub fast float 1.000000e+00, %5
  %2360 = fmul fast float %9, %2357
  %2361 = fmul fast float %9, %2358
  %2362 = fmul fast float %9, %2359
  %2363 = fmul fast float %2360, %2316
  %2364 = fmul fast float %2361, %2317
  %2365 = fmul fast float %2362, %2318
  %2366 = fcmp fast ult float %10, 5.000000e-01
  br i1 %2366, label %2392, label %2367

; <label>:2367                                    ; preds = %2356
  %2368 = fmul fast float %2363, 0x4004147AE0000000
  %2369 = fmul fast float %2364, 0x4004147AE0000000
  %2370 = fmul fast float %2365, 0x4004147AE0000000
  %2371 = fadd fast float %2368, 0x3F9EB851E0000000
  %2372 = fadd fast float %2369, 0x3F9EB851E0000000
  %2373 = fadd fast float %2370, 0x3F9EB851E0000000
  %2374 = fmul fast float %2371, %2363
  %2375 = fmul fast float %2372, %2364
  %2376 = fmul fast float %2373, %2365
  %2377 = fmul fast float %2363, 0x400370A3E0000000
  %2378 = fmul fast float %2364, 0x400370A3E0000000
  %2379 = fmul fast float %2365, 0x400370A3E0000000
  %2380 = fadd fast float %2377, 0x3FE2E147A0000000
  %2381 = fadd fast float %2378, 0x3FE2E147A0000000
  %2382 = fadd fast float %2379, 0x3FE2E147A0000000
  %2383 = fmul fast float %2380, %2363
  %2384 = fmul fast float %2381, %2364
  %2385 = fmul fast float %2382, %2365
  %2386 = fadd fast float %2383, 0x3FC1EB8520000000
  %2387 = fadd fast float %2384, 0x3FC1EB8520000000
  %2388 = fadd fast float %2385, 0x3FC1EB8520000000
  %2389 = fdiv fast float %2374, %2386
  %2390 = fdiv fast float %2375, %2387
  %2391 = fdiv fast float %2376, %2388
  br label %2392

; <label>:2392                                    ; preds = %2367, %2356
  %2393 = phi float [ %2389, %2367 ], [ %2363, %2356 ]
  %2394 = phi float [ %2390, %2367 ], [ %2364, %2356 ]
  %2395 = phi float [ %2391, %2367 ], [ %2365, %2356 ]
  %2396 = call float @dx.op.unary.f32(i32 7, float %2393)  ; Saturate(value)
  %2397 = call float @dx.op.unary.f32(i32 7, float %2394)  ; Saturate(value)
  %2398 = call float @dx.op.unary.f32(i32 7, float %2395)  ; Saturate(value)
  %2399 = call float @dx.op.dot3.f32(i32 55, float %2396, float %2397, float %2398, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2400 = fsub fast float %2396, %2399
  %2401 = fsub fast float %2397, %2399
  %2402 = fsub fast float %2398, %2399
  %2403 = fmul fast float %2400, %8
  %2404 = fmul fast float %2401, %8
  %2405 = fmul fast float %2402, %8
  %2406 = fadd fast float %2403, %2399
  %2407 = fadd fast float %2404, %2399
  %2408 = fadd fast float %2405, %2399
  %2409 = call float @dx.op.unary.f32(i32 7, float %2406)  ; Saturate(value)
  %2410 = call float @dx.op.unary.f32(i32 7, float %2407)  ; Saturate(value)
  %2411 = call float @dx.op.unary.f32(i32 7, float %2408)  ; Saturate(value)
  %2412 = fadd fast float %2409, 0xBFC70A3D80000000
  %2413 = fadd fast float %2410, 0xBFC70A3D80000000
  %2414 = fadd fast float %2411, 0xBFC70A3D80000000
  %2415 = fmul fast float %2412, %7
  %2416 = fmul fast float %2413, %7
  %2417 = fmul fast float %2414, %7
  %2418 = fadd fast float %2415, 0x3FC70A3D80000000
  %2419 = fadd fast float %2416, 0x3FC70A3D80000000
  %2420 = fadd fast float %2417, 0x3FC70A3D80000000
  %2421 = call float @dx.op.unary.f32(i32 7, float %2418)  ; Saturate(value)
  %2422 = call float @dx.op.unary.f32(i32 7, float %2419)  ; Saturate(value)
  %2423 = call float @dx.op.unary.f32(i32 7, float %2420)  ; Saturate(value)
  %2424 = add i32 %35, -1
  %2425 = call i32 @dx.op.binary.i32(i32 37, i32 %34, i32 0)  ; IMax(a,b)
  %2426 = call i32 @dx.op.binary.i32(i32 37, i32 %2424, i32 0)  ; IMax(a,b)
  %2427 = call i32 @dx.op.binary.i32(i32 38, i32 %2425, i32 %30)  ; IMin(a,b)
  %2428 = call i32 @dx.op.binary.i32(i32 38, i32 %2426, i32 %31)  ; IMin(a,b)
  %2429 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2427, i32 %2428, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2430 = extractvalue %dx.types.ResRet.f32 %2429, 0
  %2431 = fsub fast float 1.000000e+00, %53
  %2432 = fmul fast float %2431, 0x3FA99999A0000000
  %2433 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %2432)  ; FMax(a,b)
  %2434 = fsub fast float %2430, %53
  %2435 = call float @dx.op.unary.f32(i32 6, float %2434)  ; FAbs(value)
  %2436 = fdiv fast float %2435, %2433
  %2437 = fsub fast float 1.000000e+00, %2436
  %2438 = call float @dx.op.unary.f32(i32 7, float %2437)  ; Saturate(value)
  %2439 = fcmp fast ugt float %2438, 0.000000e+00
  br i1 %2439, label %2440, label %2566

; <label>:2440                                    ; preds = %2392
  %2441 = call i32 @dx.op.binary.i32(i32 37, i32 %2427, i32 0)  ; IMax(a,b)
  %2442 = call i32 @dx.op.binary.i32(i32 37, i32 %2428, i32 0)  ; IMax(a,b)
  %2443 = call i32 @dx.op.binary.i32(i32 38, i32 %2441, i32 %30)  ; IMin(a,b)
  %2444 = call i32 @dx.op.binary.i32(i32 38, i32 %2442, i32 %31)  ; IMin(a,b)
  %2445 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2443, i32 %2444, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2446 = extractvalue %dx.types.ResRet.f32 %2445, 0
  %2447 = extractvalue %dx.types.ResRet.f32 %2445, 1
  %2448 = extractvalue %dx.types.ResRet.f32 %2445, 2
  %2449 = extractvalue %dx.types.ResRet.f32 %2445, 3
  %2450 = fcmp fast olt float %2449, 0.000000e+00
  br i1 %2450, label %2451, label %2485

; <label>:2451                                    ; preds = %2440
  %2452 = fcmp fast ogt float %2446, 0x3FA4B5DCC0000000
  %2453 = fcmp fast ogt float %2447, 0x3FA4B5DCC0000000
  %2454 = fcmp fast ogt float %2448, 0x3FA4B5DCC0000000
  %2455 = select i1 %2452, float 0.000000e+00, float 1.000000e+00
  %2456 = select i1 %2453, float 0.000000e+00, float 1.000000e+00
  %2457 = select i1 %2454, float 0.000000e+00, float 1.000000e+00
  %2458 = fmul fast float %2446, 0x3FB3D07220000000
  %2459 = fmul fast float %2447, 0x3FB3D07220000000
  %2460 = fmul fast float %2448, 0x3FB3D07220000000
  %2461 = fadd fast float %2446, 0x3FAC28F5C0000000
  %2462 = fadd fast float %2447, 0x3FAC28F5C0000000
  %2463 = fadd fast float %2448, 0x3FAC28F5C0000000
  %2464 = fmul fast float %2461, 0x3FEE54EDE0000000
  %2465 = fmul fast float %2462, 0x3FEE54EDE0000000
  %2466 = fmul fast float %2463, 0x3FEE54EDE0000000
  %2467 = call float @dx.op.unary.f32(i32 23, float %2464)  ; Log(value)
  %2468 = call float @dx.op.unary.f32(i32 23, float %2465)  ; Log(value)
  %2469 = call float @dx.op.unary.f32(i32 23, float %2466)  ; Log(value)
  %2470 = fmul fast float %2467, 0x4003333340000000
  %2471 = fmul fast float %2468, 0x4003333340000000
  %2472 = fmul fast float %2469, 0x4003333340000000
  %2473 = call float @dx.op.unary.f32(i32 21, float %2470)  ; Exp(value)
  %2474 = call float @dx.op.unary.f32(i32 21, float %2471)  ; Exp(value)
  %2475 = call float @dx.op.unary.f32(i32 21, float %2472)  ; Exp(value)
  %2476 = fsub fast float %2458, %2473
  %2477 = fsub fast float %2459, %2474
  %2478 = fsub fast float %2460, %2475
  %2479 = fmul fast float %2476, %2455
  %2480 = fmul fast float %2477, %2456
  %2481 = fmul fast float %2478, %2457
  %2482 = fadd fast float %2479, %2473
  %2483 = fadd fast float %2480, %2474
  %2484 = fadd fast float %2481, %2475
  br label %2553

; <label>:2485                                    ; preds = %2440
  %2486 = fadd fast float %5, 1.000000e+00
  %2487 = fadd fast float %6, 1.000000e+00
  %2488 = fsub fast float 1.000000e+00, %5
  %2489 = fmul fast float %9, %2486
  %2490 = fmul fast float %9, %2487
  %2491 = fmul fast float %9, %2488
  %2492 = fmul fast float %2489, %2446
  %2493 = fmul fast float %2490, %2447
  %2494 = fmul fast float %2491, %2448
  %2495 = fcmp fast ult float %10, 5.000000e-01
  br i1 %2495, label %2521, label %2496

; <label>:2496                                    ; preds = %2485
  %2497 = fmul fast float %2492, 0x4004147AE0000000
  %2498 = fmul fast float %2493, 0x4004147AE0000000
  %2499 = fmul fast float %2494, 0x4004147AE0000000
  %2500 = fadd fast float %2497, 0x3F9EB851E0000000
  %2501 = fadd fast float %2498, 0x3F9EB851E0000000
  %2502 = fadd fast float %2499, 0x3F9EB851E0000000
  %2503 = fmul fast float %2500, %2492
  %2504 = fmul fast float %2501, %2493
  %2505 = fmul fast float %2502, %2494
  %2506 = fmul fast float %2492, 0x400370A3E0000000
  %2507 = fmul fast float %2493, 0x400370A3E0000000
  %2508 = fmul fast float %2494, 0x400370A3E0000000
  %2509 = fadd fast float %2506, 0x3FE2E147A0000000
  %2510 = fadd fast float %2507, 0x3FE2E147A0000000
  %2511 = fadd fast float %2508, 0x3FE2E147A0000000
  %2512 = fmul fast float %2509, %2492
  %2513 = fmul fast float %2510, %2493
  %2514 = fmul fast float %2511, %2494
  %2515 = fadd fast float %2512, 0x3FC1EB8520000000
  %2516 = fadd fast float %2513, 0x3FC1EB8520000000
  %2517 = fadd fast float %2514, 0x3FC1EB8520000000
  %2518 = fdiv fast float %2503, %2515
  %2519 = fdiv fast float %2504, %2516
  %2520 = fdiv fast float %2505, %2517
  br label %2521

; <label>:2521                                    ; preds = %2496, %2485
  %2522 = phi float [ %2518, %2496 ], [ %2492, %2485 ]
  %2523 = phi float [ %2519, %2496 ], [ %2493, %2485 ]
  %2524 = phi float [ %2520, %2496 ], [ %2494, %2485 ]
  %2525 = call float @dx.op.unary.f32(i32 7, float %2522)  ; Saturate(value)
  %2526 = call float @dx.op.unary.f32(i32 7, float %2523)  ; Saturate(value)
  %2527 = call float @dx.op.unary.f32(i32 7, float %2524)  ; Saturate(value)
  %2528 = call float @dx.op.dot3.f32(i32 55, float %2525, float %2526, float %2527, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2529 = fsub fast float %2525, %2528
  %2530 = fsub fast float %2526, %2528
  %2531 = fsub fast float %2527, %2528
  %2532 = fmul fast float %2529, %8
  %2533 = fmul fast float %2530, %8
  %2534 = fmul fast float %2531, %8
  %2535 = fadd fast float %2532, %2528
  %2536 = fadd fast float %2533, %2528
  %2537 = fadd fast float %2534, %2528
  %2538 = call float @dx.op.unary.f32(i32 7, float %2535)  ; Saturate(value)
  %2539 = call float @dx.op.unary.f32(i32 7, float %2536)  ; Saturate(value)
  %2540 = call float @dx.op.unary.f32(i32 7, float %2537)  ; Saturate(value)
  %2541 = fadd fast float %2538, 0xBFC70A3D80000000
  %2542 = fadd fast float %2539, 0xBFC70A3D80000000
  %2543 = fadd fast float %2540, 0xBFC70A3D80000000
  %2544 = fmul fast float %2541, %7
  %2545 = fmul fast float %2542, %7
  %2546 = fmul fast float %2543, %7
  %2547 = fadd fast float %2544, 0x3FC70A3D80000000
  %2548 = fadd fast float %2545, 0x3FC70A3D80000000
  %2549 = fadd fast float %2546, 0x3FC70A3D80000000
  %2550 = call float @dx.op.unary.f32(i32 7, float %2547)  ; Saturate(value)
  %2551 = call float @dx.op.unary.f32(i32 7, float %2548)  ; Saturate(value)
  %2552 = call float @dx.op.unary.f32(i32 7, float %2549)  ; Saturate(value)
  br label %2553

; <label>:2553                                    ; preds = %2521, %2451
  %2554 = phi float [ %2482, %2451 ], [ %2550, %2521 ]
  %2555 = phi float [ %2483, %2451 ], [ %2551, %2521 ]
  %2556 = phi float [ %2484, %2451 ], [ %2552, %2521 ]
  %2557 = fsub fast float %2554, %2421
  %2558 = fsub fast float %2555, %2422
  %2559 = fsub fast float %2556, %2423
  %2560 = fmul fast float %2557, %2438
  %2561 = fmul fast float %2558, %2438
  %2562 = fmul fast float %2559, %2438
  %2563 = fadd fast float %2560, %2421
  %2564 = fadd fast float %2561, %2422
  %2565 = fadd fast float %2562, %2423
  br label %2566

; <label>:2566                                    ; preds = %2553, %2392
  %2567 = phi float [ %2563, %2553 ], [ %2421, %2392 ]
  %2568 = phi float [ %2564, %2553 ], [ %2422, %2392 ]
  %2569 = phi float [ %2565, %2553 ], [ %2423, %2392 ]
  %2570 = add i32 %35, 1
  %2571 = call i32 @dx.op.binary.i32(i32 37, i32 %2570, i32 0)  ; IMax(a,b)
  %2572 = call i32 @dx.op.binary.i32(i32 38, i32 %2571, i32 %31)  ; IMin(a,b)
  %2573 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2427, i32 %2572, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2574 = extractvalue %dx.types.ResRet.f32 %2573, 0
  %2575 = fsub fast float %2574, %53
  %2576 = call float @dx.op.unary.f32(i32 6, float %2575)  ; FAbs(value)
  %2577 = fdiv fast float %2576, %2433
  %2578 = fsub fast float 1.000000e+00, %2577
  %2579 = call float @dx.op.unary.f32(i32 7, float %2578)  ; Saturate(value)
  %2580 = fcmp fast ugt float %2579, 0.000000e+00
  br i1 %2580, label %2581, label %2707

; <label>:2581                                    ; preds = %2566
  %2582 = call i32 @dx.op.binary.i32(i32 37, i32 %2427, i32 0)  ; IMax(a,b)
  %2583 = call i32 @dx.op.binary.i32(i32 37, i32 %2572, i32 0)  ; IMax(a,b)
  %2584 = call i32 @dx.op.binary.i32(i32 38, i32 %2582, i32 %30)  ; IMin(a,b)
  %2585 = call i32 @dx.op.binary.i32(i32 38, i32 %2583, i32 %31)  ; IMin(a,b)
  %2586 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2584, i32 %2585, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2587 = extractvalue %dx.types.ResRet.f32 %2586, 0
  %2588 = extractvalue %dx.types.ResRet.f32 %2586, 1
  %2589 = extractvalue %dx.types.ResRet.f32 %2586, 2
  %2590 = extractvalue %dx.types.ResRet.f32 %2586, 3
  %2591 = fcmp fast olt float %2590, 0.000000e+00
  br i1 %2591, label %2592, label %2626

; <label>:2592                                    ; preds = %2581
  %2593 = fcmp fast ogt float %2587, 0x3FA4B5DCC0000000
  %2594 = fcmp fast ogt float %2588, 0x3FA4B5DCC0000000
  %2595 = fcmp fast ogt float %2589, 0x3FA4B5DCC0000000
  %2596 = select i1 %2593, float 0.000000e+00, float 1.000000e+00
  %2597 = select i1 %2594, float 0.000000e+00, float 1.000000e+00
  %2598 = select i1 %2595, float 0.000000e+00, float 1.000000e+00
  %2599 = fmul fast float %2587, 0x3FB3D07220000000
  %2600 = fmul fast float %2588, 0x3FB3D07220000000
  %2601 = fmul fast float %2589, 0x3FB3D07220000000
  %2602 = fadd fast float %2587, 0x3FAC28F5C0000000
  %2603 = fadd fast float %2588, 0x3FAC28F5C0000000
  %2604 = fadd fast float %2589, 0x3FAC28F5C0000000
  %2605 = fmul fast float %2602, 0x3FEE54EDE0000000
  %2606 = fmul fast float %2603, 0x3FEE54EDE0000000
  %2607 = fmul fast float %2604, 0x3FEE54EDE0000000
  %2608 = call float @dx.op.unary.f32(i32 23, float %2605)  ; Log(value)
  %2609 = call float @dx.op.unary.f32(i32 23, float %2606)  ; Log(value)
  %2610 = call float @dx.op.unary.f32(i32 23, float %2607)  ; Log(value)
  %2611 = fmul fast float %2608, 0x4003333340000000
  %2612 = fmul fast float %2609, 0x4003333340000000
  %2613 = fmul fast float %2610, 0x4003333340000000
  %2614 = call float @dx.op.unary.f32(i32 21, float %2611)  ; Exp(value)
  %2615 = call float @dx.op.unary.f32(i32 21, float %2612)  ; Exp(value)
  %2616 = call float @dx.op.unary.f32(i32 21, float %2613)  ; Exp(value)
  %2617 = fsub fast float %2599, %2614
  %2618 = fsub fast float %2600, %2615
  %2619 = fsub fast float %2601, %2616
  %2620 = fmul fast float %2617, %2596
  %2621 = fmul fast float %2618, %2597
  %2622 = fmul fast float %2619, %2598
  %2623 = fadd fast float %2620, %2614
  %2624 = fadd fast float %2621, %2615
  %2625 = fadd fast float %2622, %2616
  br label %2694

; <label>:2626                                    ; preds = %2581
  %2627 = fadd fast float %5, 1.000000e+00
  %2628 = fadd fast float %6, 1.000000e+00
  %2629 = fsub fast float 1.000000e+00, %5
  %2630 = fmul fast float %9, %2627
  %2631 = fmul fast float %9, %2628
  %2632 = fmul fast float %9, %2629
  %2633 = fmul fast float %2630, %2587
  %2634 = fmul fast float %2631, %2588
  %2635 = fmul fast float %2632, %2589
  %2636 = fcmp fast ult float %10, 5.000000e-01
  br i1 %2636, label %2662, label %2637

; <label>:2637                                    ; preds = %2626
  %2638 = fmul fast float %2633, 0x4004147AE0000000
  %2639 = fmul fast float %2634, 0x4004147AE0000000
  %2640 = fmul fast float %2635, 0x4004147AE0000000
  %2641 = fadd fast float %2638, 0x3F9EB851E0000000
  %2642 = fadd fast float %2639, 0x3F9EB851E0000000
  %2643 = fadd fast float %2640, 0x3F9EB851E0000000
  %2644 = fmul fast float %2641, %2633
  %2645 = fmul fast float %2642, %2634
  %2646 = fmul fast float %2643, %2635
  %2647 = fmul fast float %2633, 0x400370A3E0000000
  %2648 = fmul fast float %2634, 0x400370A3E0000000
  %2649 = fmul fast float %2635, 0x400370A3E0000000
  %2650 = fadd fast float %2647, 0x3FE2E147A0000000
  %2651 = fadd fast float %2648, 0x3FE2E147A0000000
  %2652 = fadd fast float %2649, 0x3FE2E147A0000000
  %2653 = fmul fast float %2650, %2633
  %2654 = fmul fast float %2651, %2634
  %2655 = fmul fast float %2652, %2635
  %2656 = fadd fast float %2653, 0x3FC1EB8520000000
  %2657 = fadd fast float %2654, 0x3FC1EB8520000000
  %2658 = fadd fast float %2655, 0x3FC1EB8520000000
  %2659 = fdiv fast float %2644, %2656
  %2660 = fdiv fast float %2645, %2657
  %2661 = fdiv fast float %2646, %2658
  br label %2662

; <label>:2662                                    ; preds = %2637, %2626
  %2663 = phi float [ %2659, %2637 ], [ %2633, %2626 ]
  %2664 = phi float [ %2660, %2637 ], [ %2634, %2626 ]
  %2665 = phi float [ %2661, %2637 ], [ %2635, %2626 ]
  %2666 = call float @dx.op.unary.f32(i32 7, float %2663)  ; Saturate(value)
  %2667 = call float @dx.op.unary.f32(i32 7, float %2664)  ; Saturate(value)
  %2668 = call float @dx.op.unary.f32(i32 7, float %2665)  ; Saturate(value)
  %2669 = call float @dx.op.dot3.f32(i32 55, float %2666, float %2667, float %2668, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2670 = fsub fast float %2666, %2669
  %2671 = fsub fast float %2667, %2669
  %2672 = fsub fast float %2668, %2669
  %2673 = fmul fast float %2670, %8
  %2674 = fmul fast float %2671, %8
  %2675 = fmul fast float %2672, %8
  %2676 = fadd fast float %2673, %2669
  %2677 = fadd fast float %2674, %2669
  %2678 = fadd fast float %2675, %2669
  %2679 = call float @dx.op.unary.f32(i32 7, float %2676)  ; Saturate(value)
  %2680 = call float @dx.op.unary.f32(i32 7, float %2677)  ; Saturate(value)
  %2681 = call float @dx.op.unary.f32(i32 7, float %2678)  ; Saturate(value)
  %2682 = fadd fast float %2679, 0xBFC70A3D80000000
  %2683 = fadd fast float %2680, 0xBFC70A3D80000000
  %2684 = fadd fast float %2681, 0xBFC70A3D80000000
  %2685 = fmul fast float %2682, %7
  %2686 = fmul fast float %2683, %7
  %2687 = fmul fast float %2684, %7
  %2688 = fadd fast float %2685, 0x3FC70A3D80000000
  %2689 = fadd fast float %2686, 0x3FC70A3D80000000
  %2690 = fadd fast float %2687, 0x3FC70A3D80000000
  %2691 = call float @dx.op.unary.f32(i32 7, float %2688)  ; Saturate(value)
  %2692 = call float @dx.op.unary.f32(i32 7, float %2689)  ; Saturate(value)
  %2693 = call float @dx.op.unary.f32(i32 7, float %2690)  ; Saturate(value)
  br label %2694

; <label>:2694                                    ; preds = %2662, %2592
  %2695 = phi float [ %2623, %2592 ], [ %2691, %2662 ]
  %2696 = phi float [ %2624, %2592 ], [ %2692, %2662 ]
  %2697 = phi float [ %2625, %2592 ], [ %2693, %2662 ]
  %2698 = fsub fast float %2695, %2421
  %2699 = fsub fast float %2696, %2422
  %2700 = fsub fast float %2697, %2423
  %2701 = fmul fast float %2698, %2579
  %2702 = fmul fast float %2699, %2579
  %2703 = fmul fast float %2700, %2579
  %2704 = fadd fast float %2701, %2421
  %2705 = fadd fast float %2702, %2422
  %2706 = fadd fast float %2703, %2423
  br label %2707

; <label>:2707                                    ; preds = %2694, %2566
  %2708 = phi float [ %2704, %2694 ], [ %2421, %2566 ]
  %2709 = phi float [ %2705, %2694 ], [ %2422, %2566 ]
  %2710 = phi float [ %2706, %2694 ], [ %2423, %2566 ]
  %2711 = add i32 %34, -1
  %2712 = call i32 @dx.op.binary.i32(i32 37, i32 %2711, i32 0)  ; IMax(a,b)
  %2713 = call i32 @dx.op.binary.i32(i32 37, i32 %35, i32 0)  ; IMax(a,b)
  %2714 = call i32 @dx.op.binary.i32(i32 38, i32 %2712, i32 %30)  ; IMin(a,b)
  %2715 = call i32 @dx.op.binary.i32(i32 38, i32 %2713, i32 %31)  ; IMin(a,b)
  %2716 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2714, i32 %2715, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2717 = extractvalue %dx.types.ResRet.f32 %2716, 0
  %2718 = fsub fast float %2717, %53
  %2719 = call float @dx.op.unary.f32(i32 6, float %2718)  ; FAbs(value)
  %2720 = fdiv fast float %2719, %2433
  %2721 = fsub fast float 1.000000e+00, %2720
  %2722 = call float @dx.op.unary.f32(i32 7, float %2721)  ; Saturate(value)
  %2723 = fcmp fast ugt float %2722, 0.000000e+00
  br i1 %2723, label %2724, label %2850

; <label>:2724                                    ; preds = %2707
  %2725 = call i32 @dx.op.binary.i32(i32 37, i32 %2714, i32 0)  ; IMax(a,b)
  %2726 = call i32 @dx.op.binary.i32(i32 37, i32 %2715, i32 0)  ; IMax(a,b)
  %2727 = call i32 @dx.op.binary.i32(i32 38, i32 %2725, i32 %30)  ; IMin(a,b)
  %2728 = call i32 @dx.op.binary.i32(i32 38, i32 %2726, i32 %31)  ; IMin(a,b)
  %2729 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2727, i32 %2728, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2730 = extractvalue %dx.types.ResRet.f32 %2729, 0
  %2731 = extractvalue %dx.types.ResRet.f32 %2729, 1
  %2732 = extractvalue %dx.types.ResRet.f32 %2729, 2
  %2733 = extractvalue %dx.types.ResRet.f32 %2729, 3
  %2734 = fcmp fast olt float %2733, 0.000000e+00
  br i1 %2734, label %2735, label %2769

; <label>:2735                                    ; preds = %2724
  %2736 = fcmp fast ogt float %2730, 0x3FA4B5DCC0000000
  %2737 = fcmp fast ogt float %2731, 0x3FA4B5DCC0000000
  %2738 = fcmp fast ogt float %2732, 0x3FA4B5DCC0000000
  %2739 = select i1 %2736, float 0.000000e+00, float 1.000000e+00
  %2740 = select i1 %2737, float 0.000000e+00, float 1.000000e+00
  %2741 = select i1 %2738, float 0.000000e+00, float 1.000000e+00
  %2742 = fmul fast float %2730, 0x3FB3D07220000000
  %2743 = fmul fast float %2731, 0x3FB3D07220000000
  %2744 = fmul fast float %2732, 0x3FB3D07220000000
  %2745 = fadd fast float %2730, 0x3FAC28F5C0000000
  %2746 = fadd fast float %2731, 0x3FAC28F5C0000000
  %2747 = fadd fast float %2732, 0x3FAC28F5C0000000
  %2748 = fmul fast float %2745, 0x3FEE54EDE0000000
  %2749 = fmul fast float %2746, 0x3FEE54EDE0000000
  %2750 = fmul fast float %2747, 0x3FEE54EDE0000000
  %2751 = call float @dx.op.unary.f32(i32 23, float %2748)  ; Log(value)
  %2752 = call float @dx.op.unary.f32(i32 23, float %2749)  ; Log(value)
  %2753 = call float @dx.op.unary.f32(i32 23, float %2750)  ; Log(value)
  %2754 = fmul fast float %2751, 0x4003333340000000
  %2755 = fmul fast float %2752, 0x4003333340000000
  %2756 = fmul fast float %2753, 0x4003333340000000
  %2757 = call float @dx.op.unary.f32(i32 21, float %2754)  ; Exp(value)
  %2758 = call float @dx.op.unary.f32(i32 21, float %2755)  ; Exp(value)
  %2759 = call float @dx.op.unary.f32(i32 21, float %2756)  ; Exp(value)
  %2760 = fsub fast float %2742, %2757
  %2761 = fsub fast float %2743, %2758
  %2762 = fsub fast float %2744, %2759
  %2763 = fmul fast float %2760, %2739
  %2764 = fmul fast float %2761, %2740
  %2765 = fmul fast float %2762, %2741
  %2766 = fadd fast float %2763, %2757
  %2767 = fadd fast float %2764, %2758
  %2768 = fadd fast float %2765, %2759
  br label %2837

; <label>:2769                                    ; preds = %2724
  %2770 = fadd fast float %5, 1.000000e+00
  %2771 = fadd fast float %6, 1.000000e+00
  %2772 = fsub fast float 1.000000e+00, %5
  %2773 = fmul fast float %9, %2770
  %2774 = fmul fast float %9, %2771
  %2775 = fmul fast float %9, %2772
  %2776 = fmul fast float %2773, %2730
  %2777 = fmul fast float %2774, %2731
  %2778 = fmul fast float %2775, %2732
  %2779 = fcmp fast ult float %10, 5.000000e-01
  br i1 %2779, label %2805, label %2780

; <label>:2780                                    ; preds = %2769
  %2781 = fmul fast float %2776, 0x4004147AE0000000
  %2782 = fmul fast float %2777, 0x4004147AE0000000
  %2783 = fmul fast float %2778, 0x4004147AE0000000
  %2784 = fadd fast float %2781, 0x3F9EB851E0000000
  %2785 = fadd fast float %2782, 0x3F9EB851E0000000
  %2786 = fadd fast float %2783, 0x3F9EB851E0000000
  %2787 = fmul fast float %2784, %2776
  %2788 = fmul fast float %2785, %2777
  %2789 = fmul fast float %2786, %2778
  %2790 = fmul fast float %2776, 0x400370A3E0000000
  %2791 = fmul fast float %2777, 0x400370A3E0000000
  %2792 = fmul fast float %2778, 0x400370A3E0000000
  %2793 = fadd fast float %2790, 0x3FE2E147A0000000
  %2794 = fadd fast float %2791, 0x3FE2E147A0000000
  %2795 = fadd fast float %2792, 0x3FE2E147A0000000
  %2796 = fmul fast float %2793, %2776
  %2797 = fmul fast float %2794, %2777
  %2798 = fmul fast float %2795, %2778
  %2799 = fadd fast float %2796, 0x3FC1EB8520000000
  %2800 = fadd fast float %2797, 0x3FC1EB8520000000
  %2801 = fadd fast float %2798, 0x3FC1EB8520000000
  %2802 = fdiv fast float %2787, %2799
  %2803 = fdiv fast float %2788, %2800
  %2804 = fdiv fast float %2789, %2801
  br label %2805

; <label>:2805                                    ; preds = %2780, %2769
  %2806 = phi float [ %2802, %2780 ], [ %2776, %2769 ]
  %2807 = phi float [ %2803, %2780 ], [ %2777, %2769 ]
  %2808 = phi float [ %2804, %2780 ], [ %2778, %2769 ]
  %2809 = call float @dx.op.unary.f32(i32 7, float %2806)  ; Saturate(value)
  %2810 = call float @dx.op.unary.f32(i32 7, float %2807)  ; Saturate(value)
  %2811 = call float @dx.op.unary.f32(i32 7, float %2808)  ; Saturate(value)
  %2812 = call float @dx.op.dot3.f32(i32 55, float %2809, float %2810, float %2811, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2813 = fsub fast float %2809, %2812
  %2814 = fsub fast float %2810, %2812
  %2815 = fsub fast float %2811, %2812
  %2816 = fmul fast float %2813, %8
  %2817 = fmul fast float %2814, %8
  %2818 = fmul fast float %2815, %8
  %2819 = fadd fast float %2816, %2812
  %2820 = fadd fast float %2817, %2812
  %2821 = fadd fast float %2818, %2812
  %2822 = call float @dx.op.unary.f32(i32 7, float %2819)  ; Saturate(value)
  %2823 = call float @dx.op.unary.f32(i32 7, float %2820)  ; Saturate(value)
  %2824 = call float @dx.op.unary.f32(i32 7, float %2821)  ; Saturate(value)
  %2825 = fadd fast float %2822, 0xBFC70A3D80000000
  %2826 = fadd fast float %2823, 0xBFC70A3D80000000
  %2827 = fadd fast float %2824, 0xBFC70A3D80000000
  %2828 = fmul fast float %2825, %7
  %2829 = fmul fast float %2826, %7
  %2830 = fmul fast float %2827, %7
  %2831 = fadd fast float %2828, 0x3FC70A3D80000000
  %2832 = fadd fast float %2829, 0x3FC70A3D80000000
  %2833 = fadd fast float %2830, 0x3FC70A3D80000000
  %2834 = call float @dx.op.unary.f32(i32 7, float %2831)  ; Saturate(value)
  %2835 = call float @dx.op.unary.f32(i32 7, float %2832)  ; Saturate(value)
  %2836 = call float @dx.op.unary.f32(i32 7, float %2833)  ; Saturate(value)
  br label %2837

; <label>:2837                                    ; preds = %2805, %2735
  %2838 = phi float [ %2766, %2735 ], [ %2834, %2805 ]
  %2839 = phi float [ %2767, %2735 ], [ %2835, %2805 ]
  %2840 = phi float [ %2768, %2735 ], [ %2836, %2805 ]
  %2841 = fsub fast float %2838, %2421
  %2842 = fsub fast float %2839, %2422
  %2843 = fsub fast float %2840, %2423
  %2844 = fmul fast float %2841, %2722
  %2845 = fmul fast float %2842, %2722
  %2846 = fmul fast float %2843, %2722
  %2847 = fadd fast float %2844, %2421
  %2848 = fadd fast float %2845, %2422
  %2849 = fadd fast float %2846, %2423
  br label %2850

; <label>:2850                                    ; preds = %2837, %2707
  %2851 = phi float [ %2847, %2837 ], [ %2421, %2707 ]
  %2852 = phi float [ %2848, %2837 ], [ %2422, %2707 ]
  %2853 = phi float [ %2849, %2837 ], [ %2423, %2707 ]
  %2854 = add i32 %34, 1
  %2855 = call i32 @dx.op.binary.i32(i32 37, i32 %2854, i32 0)  ; IMax(a,b)
  %2856 = call i32 @dx.op.binary.i32(i32 38, i32 %2855, i32 %30)  ; IMin(a,b)
  %2857 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2856, i32 %2715, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2858 = extractvalue %dx.types.ResRet.f32 %2857, 0
  %2859 = fsub fast float %2858, %53
  %2860 = call float @dx.op.unary.f32(i32 6, float %2859)  ; FAbs(value)
  %2861 = fdiv fast float %2860, %2433
  %2862 = fsub fast float 1.000000e+00, %2861
  %2863 = call float @dx.op.unary.f32(i32 7, float %2862)  ; Saturate(value)
  %2864 = fcmp fast ugt float %2863, 0.000000e+00
  br i1 %2864, label %2865, label %2991

; <label>:2865                                    ; preds = %2850
  %2866 = call i32 @dx.op.binary.i32(i32 37, i32 %2856, i32 0)  ; IMax(a,b)
  %2867 = call i32 @dx.op.binary.i32(i32 37, i32 %2715, i32 0)  ; IMax(a,b)
  %2868 = call i32 @dx.op.binary.i32(i32 38, i32 %2866, i32 %30)  ; IMin(a,b)
  %2869 = call i32 @dx.op.binary.i32(i32 38, i32 %2867, i32 %31)  ; IMin(a,b)
  %2870 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2868, i32 %2869, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2871 = extractvalue %dx.types.ResRet.f32 %2870, 0
  %2872 = extractvalue %dx.types.ResRet.f32 %2870, 1
  %2873 = extractvalue %dx.types.ResRet.f32 %2870, 2
  %2874 = extractvalue %dx.types.ResRet.f32 %2870, 3
  %2875 = fcmp fast olt float %2874, 0.000000e+00
  br i1 %2875, label %2876, label %2910

; <label>:2876                                    ; preds = %2865
  %2877 = fcmp fast ogt float %2871, 0x3FA4B5DCC0000000
  %2878 = fcmp fast ogt float %2872, 0x3FA4B5DCC0000000
  %2879 = fcmp fast ogt float %2873, 0x3FA4B5DCC0000000
  %2880 = select i1 %2877, float 0.000000e+00, float 1.000000e+00
  %2881 = select i1 %2878, float 0.000000e+00, float 1.000000e+00
  %2882 = select i1 %2879, float 0.000000e+00, float 1.000000e+00
  %2883 = fmul fast float %2871, 0x3FB3D07220000000
  %2884 = fmul fast float %2872, 0x3FB3D07220000000
  %2885 = fmul fast float %2873, 0x3FB3D07220000000
  %2886 = fadd fast float %2871, 0x3FAC28F5C0000000
  %2887 = fadd fast float %2872, 0x3FAC28F5C0000000
  %2888 = fadd fast float %2873, 0x3FAC28F5C0000000
  %2889 = fmul fast float %2886, 0x3FEE54EDE0000000
  %2890 = fmul fast float %2887, 0x3FEE54EDE0000000
  %2891 = fmul fast float %2888, 0x3FEE54EDE0000000
  %2892 = call float @dx.op.unary.f32(i32 23, float %2889)  ; Log(value)
  %2893 = call float @dx.op.unary.f32(i32 23, float %2890)  ; Log(value)
  %2894 = call float @dx.op.unary.f32(i32 23, float %2891)  ; Log(value)
  %2895 = fmul fast float %2892, 0x4003333340000000
  %2896 = fmul fast float %2893, 0x4003333340000000
  %2897 = fmul fast float %2894, 0x4003333340000000
  %2898 = call float @dx.op.unary.f32(i32 21, float %2895)  ; Exp(value)
  %2899 = call float @dx.op.unary.f32(i32 21, float %2896)  ; Exp(value)
  %2900 = call float @dx.op.unary.f32(i32 21, float %2897)  ; Exp(value)
  %2901 = fsub fast float %2883, %2898
  %2902 = fsub fast float %2884, %2899
  %2903 = fsub fast float %2885, %2900
  %2904 = fmul fast float %2901, %2880
  %2905 = fmul fast float %2902, %2881
  %2906 = fmul fast float %2903, %2882
  %2907 = fadd fast float %2904, %2898
  %2908 = fadd fast float %2905, %2899
  %2909 = fadd fast float %2906, %2900
  br label %2978

; <label>:2910                                    ; preds = %2865
  %2911 = fadd fast float %5, 1.000000e+00
  %2912 = fadd fast float %6, 1.000000e+00
  %2913 = fsub fast float 1.000000e+00, %5
  %2914 = fmul fast float %9, %2911
  %2915 = fmul fast float %9, %2912
  %2916 = fmul fast float %9, %2913
  %2917 = fmul fast float %2914, %2871
  %2918 = fmul fast float %2915, %2872
  %2919 = fmul fast float %2916, %2873
  %2920 = fcmp fast ult float %10, 5.000000e-01
  br i1 %2920, label %2946, label %2921

; <label>:2921                                    ; preds = %2910
  %2922 = fmul fast float %2917, 0x4004147AE0000000
  %2923 = fmul fast float %2918, 0x4004147AE0000000
  %2924 = fmul fast float %2919, 0x4004147AE0000000
  %2925 = fadd fast float %2922, 0x3F9EB851E0000000
  %2926 = fadd fast float %2923, 0x3F9EB851E0000000
  %2927 = fadd fast float %2924, 0x3F9EB851E0000000
  %2928 = fmul fast float %2925, %2917
  %2929 = fmul fast float %2926, %2918
  %2930 = fmul fast float %2927, %2919
  %2931 = fmul fast float %2917, 0x400370A3E0000000
  %2932 = fmul fast float %2918, 0x400370A3E0000000
  %2933 = fmul fast float %2919, 0x400370A3E0000000
  %2934 = fadd fast float %2931, 0x3FE2E147A0000000
  %2935 = fadd fast float %2932, 0x3FE2E147A0000000
  %2936 = fadd fast float %2933, 0x3FE2E147A0000000
  %2937 = fmul fast float %2934, %2917
  %2938 = fmul fast float %2935, %2918
  %2939 = fmul fast float %2936, %2919
  %2940 = fadd fast float %2937, 0x3FC1EB8520000000
  %2941 = fadd fast float %2938, 0x3FC1EB8520000000
  %2942 = fadd fast float %2939, 0x3FC1EB8520000000
  %2943 = fdiv fast float %2928, %2940
  %2944 = fdiv fast float %2929, %2941
  %2945 = fdiv fast float %2930, %2942
  br label %2946

; <label>:2946                                    ; preds = %2921, %2910
  %2947 = phi float [ %2943, %2921 ], [ %2917, %2910 ]
  %2948 = phi float [ %2944, %2921 ], [ %2918, %2910 ]
  %2949 = phi float [ %2945, %2921 ], [ %2919, %2910 ]
  %2950 = call float @dx.op.unary.f32(i32 7, float %2947)  ; Saturate(value)
  %2951 = call float @dx.op.unary.f32(i32 7, float %2948)  ; Saturate(value)
  %2952 = call float @dx.op.unary.f32(i32 7, float %2949)  ; Saturate(value)
  %2953 = call float @dx.op.dot3.f32(i32 55, float %2950, float %2951, float %2952, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2954 = fsub fast float %2950, %2953
  %2955 = fsub fast float %2951, %2953
  %2956 = fsub fast float %2952, %2953
  %2957 = fmul fast float %2954, %8
  %2958 = fmul fast float %2955, %8
  %2959 = fmul fast float %2956, %8
  %2960 = fadd fast float %2957, %2953
  %2961 = fadd fast float %2958, %2953
  %2962 = fadd fast float %2959, %2953
  %2963 = call float @dx.op.unary.f32(i32 7, float %2960)  ; Saturate(value)
  %2964 = call float @dx.op.unary.f32(i32 7, float %2961)  ; Saturate(value)
  %2965 = call float @dx.op.unary.f32(i32 7, float %2962)  ; Saturate(value)
  %2966 = fadd fast float %2963, 0xBFC70A3D80000000
  %2967 = fadd fast float %2964, 0xBFC70A3D80000000
  %2968 = fadd fast float %2965, 0xBFC70A3D80000000
  %2969 = fmul fast float %2966, %7
  %2970 = fmul fast float %2967, %7
  %2971 = fmul fast float %2968, %7
  %2972 = fadd fast float %2969, 0x3FC70A3D80000000
  %2973 = fadd fast float %2970, 0x3FC70A3D80000000
  %2974 = fadd fast float %2971, 0x3FC70A3D80000000
  %2975 = call float @dx.op.unary.f32(i32 7, float %2972)  ; Saturate(value)
  %2976 = call float @dx.op.unary.f32(i32 7, float %2973)  ; Saturate(value)
  %2977 = call float @dx.op.unary.f32(i32 7, float %2974)  ; Saturate(value)
  br label %2978

; <label>:2978                                    ; preds = %2946, %2876
  %2979 = phi float [ %2907, %2876 ], [ %2975, %2946 ]
  %2980 = phi float [ %2908, %2876 ], [ %2976, %2946 ]
  %2981 = phi float [ %2909, %2876 ], [ %2977, %2946 ]
  %2982 = fsub fast float %2979, %2421
  %2983 = fsub fast float %2980, %2422
  %2984 = fsub fast float %2981, %2423
  %2985 = fmul fast float %2982, %2863
  %2986 = fmul fast float %2983, %2863
  %2987 = fmul fast float %2984, %2863
  %2988 = fadd fast float %2985, %2421
  %2989 = fadd fast float %2986, %2422
  %2990 = fadd fast float %2987, %2423
  br label %2991

; <label>:2991                                    ; preds = %2978, %2850
  %2992 = phi float [ %2988, %2978 ], [ %2421, %2850 ]
  %2993 = phi float [ %2989, %2978 ], [ %2422, %2850 ]
  %2994 = phi float [ %2990, %2978 ], [ %2423, %2850 ]
  %2995 = call float @dx.op.binary.f32(i32 36, float %2851, float %2992)  ; FMin(a,b)
  %2996 = call float @dx.op.binary.f32(i32 36, float %2852, float %2993)  ; FMin(a,b)
  %2997 = call float @dx.op.binary.f32(i32 36, float %2853, float %2994)  ; FMin(a,b)
  %2998 = call float @dx.op.binary.f32(i32 36, float %2567, float %2708)  ; FMin(a,b)
  %2999 = call float @dx.op.binary.f32(i32 36, float %2568, float %2709)  ; FMin(a,b)
  %3000 = call float @dx.op.binary.f32(i32 36, float %2569, float %2710)  ; FMin(a,b)
  %3001 = call float @dx.op.binary.f32(i32 36, float %2998, float %2995)  ; FMin(a,b)
  %3002 = call float @dx.op.binary.f32(i32 36, float %2999, float %2996)  ; FMin(a,b)
  %3003 = call float @dx.op.binary.f32(i32 36, float %3000, float %2997)  ; FMin(a,b)
  %3004 = call float @dx.op.binary.f32(i32 36, float %2421, float %3001)  ; FMin(a,b)
  %3005 = call float @dx.op.binary.f32(i32 36, float %2422, float %3002)  ; FMin(a,b)
  %3006 = call float @dx.op.binary.f32(i32 36, float %2423, float %3003)  ; FMin(a,b)
  %3007 = call float @dx.op.binary.f32(i32 35, float %2851, float %2992)  ; FMax(a,b)
  %3008 = call float @dx.op.binary.f32(i32 35, float %2852, float %2993)  ; FMax(a,b)
  %3009 = call float @dx.op.binary.f32(i32 35, float %2853, float %2994)  ; FMax(a,b)
  %3010 = call float @dx.op.binary.f32(i32 35, float %2567, float %2708)  ; FMax(a,b)
  %3011 = call float @dx.op.binary.f32(i32 35, float %2568, float %2709)  ; FMax(a,b)
  %3012 = call float @dx.op.binary.f32(i32 35, float %2569, float %2710)  ; FMax(a,b)
  %3013 = call float @dx.op.binary.f32(i32 35, float %3010, float %3007)  ; FMax(a,b)
  %3014 = call float @dx.op.binary.f32(i32 35, float %3011, float %3008)  ; FMax(a,b)
  %3015 = call float @dx.op.binary.f32(i32 35, float %3012, float %3009)  ; FMax(a,b)
  %3016 = call float @dx.op.binary.f32(i32 35, float %2421, float %3013)  ; FMax(a,b)
  %3017 = call float @dx.op.binary.f32(i32 35, float %2422, float %3014)  ; FMax(a,b)
  %3018 = call float @dx.op.binary.f32(i32 35, float %2423, float %3015)  ; FMax(a,b)
  %3019 = fsub fast float %3016, %3004
  %3020 = fsub fast float %3017, %3005
  %3021 = fsub fast float %3018, %3006
  %3022 = call float @dx.op.unary.f32(i32 6, float %3019)  ; FAbs(value)
  %3023 = call float @dx.op.unary.f32(i32 6, float %3020)  ; FAbs(value)
  %3024 = call float @dx.op.unary.f32(i32 6, float %3021)  ; FAbs(value)
  %3025 = call float @dx.op.binary.f32(i32 35, float %3023, float %3024)  ; FMax(a,b)
  %3026 = call float @dx.op.binary.f32(i32 35, float %3022, float %3025)  ; FMax(a,b)
  %3027 = call float @dx.op.binary.f32(i32 35, float %3017, float %3018)  ; FMax(a,b)
  %3028 = call float @dx.op.binary.f32(i32 35, float %3016, float %3027)  ; FMax(a,b)
  %3029 = fmul fast float %3028, 1.250000e-01
  %3030 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %3029)  ; FMax(a,b)
  %3031 = fcmp fast ogt float %3026, %3030
  br i1 %3031, label %3032, label %3093

; <label>:3032                                    ; preds = %2991
  %3033 = fsub fast float %2567, %2708
  %3034 = fsub fast float %2568, %2709
  %3035 = fsub fast float %2569, %2710
  %3036 = call float @dx.op.unary.f32(i32 6, float %3033)  ; FAbs(value)
  %3037 = call float @dx.op.unary.f32(i32 6, float %3034)  ; FAbs(value)
  %3038 = call float @dx.op.unary.f32(i32 6, float %3035)  ; FAbs(value)
  %3039 = call float @dx.op.binary.f32(i32 35, float %3037, float %3038)  ; FMax(a,b)
  %3040 = call float @dx.op.binary.f32(i32 35, float %3036, float %3039)  ; FMax(a,b)
  %3041 = fsub fast float %2851, %2992
  %3042 = fsub fast float %2852, %2993
  %3043 = fsub fast float %2853, %2994
  %3044 = call float @dx.op.unary.f32(i32 6, float %3041)  ; FAbs(value)
  %3045 = call float @dx.op.unary.f32(i32 6, float %3042)  ; FAbs(value)
  %3046 = call float @dx.op.unary.f32(i32 6, float %3043)  ; FAbs(value)
  %3047 = call float @dx.op.binary.f32(i32 35, float %3045, float %3046)  ; FMax(a,b)
  %3048 = call float @dx.op.binary.f32(i32 35, float %3044, float %3047)  ; FMax(a,b)
  %3049 = fcmp fast olt float %3040, %3048
  %3050 = select i1 %3049, float %2567, float %2851
  %3051 = select i1 %3049, float %2568, float %2852
  %3052 = select i1 %3049, float %2569, float %2853
  %3053 = select i1 %3049, float %2708, float %2992
  %3054 = select i1 %3049, float %2709, float %2993
  %3055 = select i1 %3049, float %2710, float %2994
  %3056 = fsub fast float %2421, %3053
  %3057 = fsub fast float %2422, %3054
  %3058 = fsub fast float %2423, %3055
  %3059 = fsub fast float %2421, %3050
  %3060 = fsub fast float %2422, %3051
  %3061 = fsub fast float %2423, %3052
  %3062 = call float @dx.op.dot3.f32(i32 55, float %3059, float %3060, float %3061, float %3056, float %3057, float %3058)  ; Dot3(ax,ay,az,bx,by,bz)
  %3063 = fcmp fast ogt float %3062, 0.000000e+00
  br i1 %3063, label %3064, label %3075

; <label>:3064                                    ; preds = %3032
  %3065 = fsub fast float %3050, %3053
  %3066 = fsub fast float %3051, %3054
  %3067 = fsub fast float %3052, %3055
  %3068 = call float @dx.op.unary.f32(i32 6, float %3065)  ; FAbs(value)
  %3069 = call float @dx.op.unary.f32(i32 6, float %3066)  ; FAbs(value)
  %3070 = call float @dx.op.unary.f32(i32 6, float %3067)  ; FAbs(value)
  %3071 = call float @dx.op.binary.f32(i32 35, float %3069, float %3070)  ; FMax(a,b)
  %3072 = call float @dx.op.binary.f32(i32 35, float %3068, float %3071)  ; FMax(a,b)
  %3073 = fmul fast float %3026, 2.500000e-01
  %3074 = fcmp fast olt float %3072, %3073
  br label %3075

; <label>:3075                                    ; preds = %3064, %3032
  %3076 = phi i1 [ false, %3032 ], [ %3074, %3064 ]
  %3077 = select i1 %3076, float 0x3FC3333340000000, float 0x3FD3333340000000
  %3078 = fadd fast float %3050, %3053
  %3079 = fadd fast float %3051, %3054
  %3080 = fadd fast float %3052, %3055
  %3081 = fmul fast float %3078, 5.000000e-01
  %3082 = fmul fast float %3079, 5.000000e-01
  %3083 = fmul fast float %3080, 5.000000e-01
  %3084 = fsub fast float %3081, %2421
  %3085 = fsub fast float %3082, %2422
  %3086 = fsub fast float %3083, %2423
  %3087 = fmul fast float %3077, %3084
  %3088 = fmul fast float %3077, %3085
  %3089 = fmul fast float %3077, %3086
  %3090 = fadd fast float %3087, %2421
  %3091 = fadd fast float %3088, %2422
  %3092 = fadd fast float %3089, %2423
  br label %3093

; <label>:3093                                    ; preds = %3075, %2991, %2321
  %3094 = phi float [ %2352, %2321 ], [ %3090, %3075 ], [ %2421, %2991 ]
  %3095 = phi float [ %2353, %2321 ], [ %3091, %3075 ], [ %2422, %2991 ]
  %3096 = phi float [ %2354, %2321 ], [ %3092, %3075 ], [ %2423, %2991 ]
  %3097 = phi float [ %2355, %2321 ], [ %2319, %3075 ], [ %2319, %2991 ]
  %3098 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %38, i32 %35, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3099 = extractvalue %dx.types.ResRet.f32 %3098, 0
  %3100 = extractvalue %dx.types.ResRet.f32 %3098, 1
  %3101 = extractvalue %dx.types.ResRet.f32 %3098, 2
  %3102 = extractvalue %dx.types.ResRet.f32 %3098, 3
  %3103 = fcmp fast olt float %3102, 0.000000e+00
  br i1 %3103, label %3104, label %3139

; <label>:3104                                    ; preds = %3093
  %3105 = fcmp fast ogt float %3099, 0x3FA4B5DCC0000000
  %3106 = fcmp fast ogt float %3100, 0x3FA4B5DCC0000000
  %3107 = fcmp fast ogt float %3101, 0x3FA4B5DCC0000000
  %3108 = select i1 %3105, float 0.000000e+00, float 1.000000e+00
  %3109 = select i1 %3106, float 0.000000e+00, float 1.000000e+00
  %3110 = select i1 %3107, float 0.000000e+00, float 1.000000e+00
  %3111 = fmul fast float %3099, 0x3FB3D07220000000
  %3112 = fmul fast float %3100, 0x3FB3D07220000000
  %3113 = fmul fast float %3101, 0x3FB3D07220000000
  %3114 = fadd fast float %3099, 0x3FAC28F5C0000000
  %3115 = fadd fast float %3100, 0x3FAC28F5C0000000
  %3116 = fadd fast float %3101, 0x3FAC28F5C0000000
  %3117 = fmul fast float %3114, 0x3FEE54EDE0000000
  %3118 = fmul fast float %3115, 0x3FEE54EDE0000000
  %3119 = fmul fast float %3116, 0x3FEE54EDE0000000
  %3120 = call float @dx.op.unary.f32(i32 23, float %3117)  ; Log(value)
  %3121 = call float @dx.op.unary.f32(i32 23, float %3118)  ; Log(value)
  %3122 = call float @dx.op.unary.f32(i32 23, float %3119)  ; Log(value)
  %3123 = fmul fast float %3120, 0x4003333340000000
  %3124 = fmul fast float %3121, 0x4003333340000000
  %3125 = fmul fast float %3122, 0x4003333340000000
  %3126 = call float @dx.op.unary.f32(i32 21, float %3123)  ; Exp(value)
  %3127 = call float @dx.op.unary.f32(i32 21, float %3124)  ; Exp(value)
  %3128 = call float @dx.op.unary.f32(i32 21, float %3125)  ; Exp(value)
  %3129 = fsub fast float %3111, %3126
  %3130 = fsub fast float %3112, %3127
  %3131 = fsub fast float %3113, %3128
  %3132 = fmul fast float %3129, %3108
  %3133 = fmul fast float %3130, %3109
  %3134 = fmul fast float %3131, %3110
  %3135 = fadd fast float %3132, %3126
  %3136 = fadd fast float %3133, %3127
  %3137 = fadd fast float %3134, %3128
  %3138 = fsub fast float -1.000000e+00, %3102
  br label %3876

; <label>:3139                                    ; preds = %3093
  %3140 = fadd fast float %5, 1.000000e+00
  %3141 = fadd fast float %6, 1.000000e+00
  %3142 = fsub fast float 1.000000e+00, %5
  %3143 = fmul fast float %9, %3140
  %3144 = fmul fast float %9, %3141
  %3145 = fmul fast float %9, %3142
  %3146 = fmul fast float %3143, %3099
  %3147 = fmul fast float %3144, %3100
  %3148 = fmul fast float %3145, %3101
  %3149 = fcmp fast ult float %10, 5.000000e-01
  br i1 %3149, label %3175, label %3150

; <label>:3150                                    ; preds = %3139
  %3151 = fmul fast float %3146, 0x4004147AE0000000
  %3152 = fmul fast float %3147, 0x4004147AE0000000
  %3153 = fmul fast float %3148, 0x4004147AE0000000
  %3154 = fadd fast float %3151, 0x3F9EB851E0000000
  %3155 = fadd fast float %3152, 0x3F9EB851E0000000
  %3156 = fadd fast float %3153, 0x3F9EB851E0000000
  %3157 = fmul fast float %3154, %3146
  %3158 = fmul fast float %3155, %3147
  %3159 = fmul fast float %3156, %3148
  %3160 = fmul fast float %3146, 0x400370A3E0000000
  %3161 = fmul fast float %3147, 0x400370A3E0000000
  %3162 = fmul fast float %3148, 0x400370A3E0000000
  %3163 = fadd fast float %3160, 0x3FE2E147A0000000
  %3164 = fadd fast float %3161, 0x3FE2E147A0000000
  %3165 = fadd fast float %3162, 0x3FE2E147A0000000
  %3166 = fmul fast float %3163, %3146
  %3167 = fmul fast float %3164, %3147
  %3168 = fmul fast float %3165, %3148
  %3169 = fadd fast float %3166, 0x3FC1EB8520000000
  %3170 = fadd fast float %3167, 0x3FC1EB8520000000
  %3171 = fadd fast float %3168, 0x3FC1EB8520000000
  %3172 = fdiv fast float %3157, %3169
  %3173 = fdiv fast float %3158, %3170
  %3174 = fdiv fast float %3159, %3171
  br label %3175

; <label>:3175                                    ; preds = %3150, %3139
  %3176 = phi float [ %3172, %3150 ], [ %3146, %3139 ]
  %3177 = phi float [ %3173, %3150 ], [ %3147, %3139 ]
  %3178 = phi float [ %3174, %3150 ], [ %3148, %3139 ]
  %3179 = call float @dx.op.unary.f32(i32 7, float %3176)  ; Saturate(value)
  %3180 = call float @dx.op.unary.f32(i32 7, float %3177)  ; Saturate(value)
  %3181 = call float @dx.op.unary.f32(i32 7, float %3178)  ; Saturate(value)
  %3182 = call float @dx.op.dot3.f32(i32 55, float %3179, float %3180, float %3181, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3183 = fsub fast float %3179, %3182
  %3184 = fsub fast float %3180, %3182
  %3185 = fsub fast float %3181, %3182
  %3186 = fmul fast float %3183, %8
  %3187 = fmul fast float %3184, %8
  %3188 = fmul fast float %3185, %8
  %3189 = fadd fast float %3186, %3182
  %3190 = fadd fast float %3187, %3182
  %3191 = fadd fast float %3188, %3182
  %3192 = call float @dx.op.unary.f32(i32 7, float %3189)  ; Saturate(value)
  %3193 = call float @dx.op.unary.f32(i32 7, float %3190)  ; Saturate(value)
  %3194 = call float @dx.op.unary.f32(i32 7, float %3191)  ; Saturate(value)
  %3195 = fadd fast float %3192, 0xBFC70A3D80000000
  %3196 = fadd fast float %3193, 0xBFC70A3D80000000
  %3197 = fadd fast float %3194, 0xBFC70A3D80000000
  %3198 = fmul fast float %3195, %7
  %3199 = fmul fast float %3196, %7
  %3200 = fmul fast float %3197, %7
  %3201 = fadd fast float %3198, 0x3FC70A3D80000000
  %3202 = fadd fast float %3199, 0x3FC70A3D80000000
  %3203 = fadd fast float %3200, 0x3FC70A3D80000000
  %3204 = call float @dx.op.unary.f32(i32 7, float %3201)  ; Saturate(value)
  %3205 = call float @dx.op.unary.f32(i32 7, float %3202)  ; Saturate(value)
  %3206 = call float @dx.op.unary.f32(i32 7, float %3203)  ; Saturate(value)
  %3207 = add i32 %35, -1
  %3208 = call i32 @dx.op.binary.i32(i32 37, i32 %38, i32 0)  ; IMax(a,b)
  %3209 = call i32 @dx.op.binary.i32(i32 37, i32 %3207, i32 0)  ; IMax(a,b)
  %3210 = call i32 @dx.op.binary.i32(i32 38, i32 %3208, i32 %30)  ; IMin(a,b)
  %3211 = call i32 @dx.op.binary.i32(i32 38, i32 %3209, i32 %31)  ; IMin(a,b)
  %3212 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3210, i32 %3211, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3213 = extractvalue %dx.types.ResRet.f32 %3212, 0
  %3214 = fsub fast float 1.000000e+00, %55
  %3215 = fmul fast float %3214, 0x3FA99999A0000000
  %3216 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %3215)  ; FMax(a,b)
  %3217 = fsub fast float %3213, %55
  %3218 = call float @dx.op.unary.f32(i32 6, float %3217)  ; FAbs(value)
  %3219 = fdiv fast float %3218, %3216
  %3220 = fsub fast float 1.000000e+00, %3219
  %3221 = call float @dx.op.unary.f32(i32 7, float %3220)  ; Saturate(value)
  %3222 = fcmp fast ugt float %3221, 0.000000e+00
  br i1 %3222, label %3223, label %3349

; <label>:3223                                    ; preds = %3175
  %3224 = call i32 @dx.op.binary.i32(i32 37, i32 %3210, i32 0)  ; IMax(a,b)
  %3225 = call i32 @dx.op.binary.i32(i32 37, i32 %3211, i32 0)  ; IMax(a,b)
  %3226 = call i32 @dx.op.binary.i32(i32 38, i32 %3224, i32 %30)  ; IMin(a,b)
  %3227 = call i32 @dx.op.binary.i32(i32 38, i32 %3225, i32 %31)  ; IMin(a,b)
  %3228 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3226, i32 %3227, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3229 = extractvalue %dx.types.ResRet.f32 %3228, 0
  %3230 = extractvalue %dx.types.ResRet.f32 %3228, 1
  %3231 = extractvalue %dx.types.ResRet.f32 %3228, 2
  %3232 = extractvalue %dx.types.ResRet.f32 %3228, 3
  %3233 = fcmp fast olt float %3232, 0.000000e+00
  br i1 %3233, label %3234, label %3268

; <label>:3234                                    ; preds = %3223
  %3235 = fcmp fast ogt float %3229, 0x3FA4B5DCC0000000
  %3236 = fcmp fast ogt float %3230, 0x3FA4B5DCC0000000
  %3237 = fcmp fast ogt float %3231, 0x3FA4B5DCC0000000
  %3238 = select i1 %3235, float 0.000000e+00, float 1.000000e+00
  %3239 = select i1 %3236, float 0.000000e+00, float 1.000000e+00
  %3240 = select i1 %3237, float 0.000000e+00, float 1.000000e+00
  %3241 = fmul fast float %3229, 0x3FB3D07220000000
  %3242 = fmul fast float %3230, 0x3FB3D07220000000
  %3243 = fmul fast float %3231, 0x3FB3D07220000000
  %3244 = fadd fast float %3229, 0x3FAC28F5C0000000
  %3245 = fadd fast float %3230, 0x3FAC28F5C0000000
  %3246 = fadd fast float %3231, 0x3FAC28F5C0000000
  %3247 = fmul fast float %3244, 0x3FEE54EDE0000000
  %3248 = fmul fast float %3245, 0x3FEE54EDE0000000
  %3249 = fmul fast float %3246, 0x3FEE54EDE0000000
  %3250 = call float @dx.op.unary.f32(i32 23, float %3247)  ; Log(value)
  %3251 = call float @dx.op.unary.f32(i32 23, float %3248)  ; Log(value)
  %3252 = call float @dx.op.unary.f32(i32 23, float %3249)  ; Log(value)
  %3253 = fmul fast float %3250, 0x4003333340000000
  %3254 = fmul fast float %3251, 0x4003333340000000
  %3255 = fmul fast float %3252, 0x4003333340000000
  %3256 = call float @dx.op.unary.f32(i32 21, float %3253)  ; Exp(value)
  %3257 = call float @dx.op.unary.f32(i32 21, float %3254)  ; Exp(value)
  %3258 = call float @dx.op.unary.f32(i32 21, float %3255)  ; Exp(value)
  %3259 = fsub fast float %3241, %3256
  %3260 = fsub fast float %3242, %3257
  %3261 = fsub fast float %3243, %3258
  %3262 = fmul fast float %3259, %3238
  %3263 = fmul fast float %3260, %3239
  %3264 = fmul fast float %3261, %3240
  %3265 = fadd fast float %3262, %3256
  %3266 = fadd fast float %3263, %3257
  %3267 = fadd fast float %3264, %3258
  br label %3336

; <label>:3268                                    ; preds = %3223
  %3269 = fadd fast float %5, 1.000000e+00
  %3270 = fadd fast float %6, 1.000000e+00
  %3271 = fsub fast float 1.000000e+00, %5
  %3272 = fmul fast float %9, %3269
  %3273 = fmul fast float %9, %3270
  %3274 = fmul fast float %9, %3271
  %3275 = fmul fast float %3272, %3229
  %3276 = fmul fast float %3273, %3230
  %3277 = fmul fast float %3274, %3231
  %3278 = fcmp fast ult float %10, 5.000000e-01
  br i1 %3278, label %3304, label %3279

; <label>:3279                                    ; preds = %3268
  %3280 = fmul fast float %3275, 0x4004147AE0000000
  %3281 = fmul fast float %3276, 0x4004147AE0000000
  %3282 = fmul fast float %3277, 0x4004147AE0000000
  %3283 = fadd fast float %3280, 0x3F9EB851E0000000
  %3284 = fadd fast float %3281, 0x3F9EB851E0000000
  %3285 = fadd fast float %3282, 0x3F9EB851E0000000
  %3286 = fmul fast float %3283, %3275
  %3287 = fmul fast float %3284, %3276
  %3288 = fmul fast float %3285, %3277
  %3289 = fmul fast float %3275, 0x400370A3E0000000
  %3290 = fmul fast float %3276, 0x400370A3E0000000
  %3291 = fmul fast float %3277, 0x400370A3E0000000
  %3292 = fadd fast float %3289, 0x3FE2E147A0000000
  %3293 = fadd fast float %3290, 0x3FE2E147A0000000
  %3294 = fadd fast float %3291, 0x3FE2E147A0000000
  %3295 = fmul fast float %3292, %3275
  %3296 = fmul fast float %3293, %3276
  %3297 = fmul fast float %3294, %3277
  %3298 = fadd fast float %3295, 0x3FC1EB8520000000
  %3299 = fadd fast float %3296, 0x3FC1EB8520000000
  %3300 = fadd fast float %3297, 0x3FC1EB8520000000
  %3301 = fdiv fast float %3286, %3298
  %3302 = fdiv fast float %3287, %3299
  %3303 = fdiv fast float %3288, %3300
  br label %3304

; <label>:3304                                    ; preds = %3279, %3268
  %3305 = phi float [ %3301, %3279 ], [ %3275, %3268 ]
  %3306 = phi float [ %3302, %3279 ], [ %3276, %3268 ]
  %3307 = phi float [ %3303, %3279 ], [ %3277, %3268 ]
  %3308 = call float @dx.op.unary.f32(i32 7, float %3305)  ; Saturate(value)
  %3309 = call float @dx.op.unary.f32(i32 7, float %3306)  ; Saturate(value)
  %3310 = call float @dx.op.unary.f32(i32 7, float %3307)  ; Saturate(value)
  %3311 = call float @dx.op.dot3.f32(i32 55, float %3308, float %3309, float %3310, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3312 = fsub fast float %3308, %3311
  %3313 = fsub fast float %3309, %3311
  %3314 = fsub fast float %3310, %3311
  %3315 = fmul fast float %3312, %8
  %3316 = fmul fast float %3313, %8
  %3317 = fmul fast float %3314, %8
  %3318 = fadd fast float %3315, %3311
  %3319 = fadd fast float %3316, %3311
  %3320 = fadd fast float %3317, %3311
  %3321 = call float @dx.op.unary.f32(i32 7, float %3318)  ; Saturate(value)
  %3322 = call float @dx.op.unary.f32(i32 7, float %3319)  ; Saturate(value)
  %3323 = call float @dx.op.unary.f32(i32 7, float %3320)  ; Saturate(value)
  %3324 = fadd fast float %3321, 0xBFC70A3D80000000
  %3325 = fadd fast float %3322, 0xBFC70A3D80000000
  %3326 = fadd fast float %3323, 0xBFC70A3D80000000
  %3327 = fmul fast float %3324, %7
  %3328 = fmul fast float %3325, %7
  %3329 = fmul fast float %3326, %7
  %3330 = fadd fast float %3327, 0x3FC70A3D80000000
  %3331 = fadd fast float %3328, 0x3FC70A3D80000000
  %3332 = fadd fast float %3329, 0x3FC70A3D80000000
  %3333 = call float @dx.op.unary.f32(i32 7, float %3330)  ; Saturate(value)
  %3334 = call float @dx.op.unary.f32(i32 7, float %3331)  ; Saturate(value)
  %3335 = call float @dx.op.unary.f32(i32 7, float %3332)  ; Saturate(value)
  br label %3336

; <label>:3336                                    ; preds = %3304, %3234
  %3337 = phi float [ %3265, %3234 ], [ %3333, %3304 ]
  %3338 = phi float [ %3266, %3234 ], [ %3334, %3304 ]
  %3339 = phi float [ %3267, %3234 ], [ %3335, %3304 ]
  %3340 = fsub fast float %3337, %3204
  %3341 = fsub fast float %3338, %3205
  %3342 = fsub fast float %3339, %3206
  %3343 = fmul fast float %3340, %3221
  %3344 = fmul fast float %3341, %3221
  %3345 = fmul fast float %3342, %3221
  %3346 = fadd fast float %3343, %3204
  %3347 = fadd fast float %3344, %3205
  %3348 = fadd fast float %3345, %3206
  br label %3349

; <label>:3349                                    ; preds = %3336, %3175
  %3350 = phi float [ %3346, %3336 ], [ %3204, %3175 ]
  %3351 = phi float [ %3347, %3336 ], [ %3205, %3175 ]
  %3352 = phi float [ %3348, %3336 ], [ %3206, %3175 ]
  %3353 = add i32 %35, 1
  %3354 = call i32 @dx.op.binary.i32(i32 37, i32 %3353, i32 0)  ; IMax(a,b)
  %3355 = call i32 @dx.op.binary.i32(i32 38, i32 %3354, i32 %31)  ; IMin(a,b)
  %3356 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3210, i32 %3355, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3357 = extractvalue %dx.types.ResRet.f32 %3356, 0
  %3358 = fsub fast float %3357, %55
  %3359 = call float @dx.op.unary.f32(i32 6, float %3358)  ; FAbs(value)
  %3360 = fdiv fast float %3359, %3216
  %3361 = fsub fast float 1.000000e+00, %3360
  %3362 = call float @dx.op.unary.f32(i32 7, float %3361)  ; Saturate(value)
  %3363 = fcmp fast ugt float %3362, 0.000000e+00
  br i1 %3363, label %3364, label %3490

; <label>:3364                                    ; preds = %3349
  %3365 = call i32 @dx.op.binary.i32(i32 37, i32 %3210, i32 0)  ; IMax(a,b)
  %3366 = call i32 @dx.op.binary.i32(i32 37, i32 %3355, i32 0)  ; IMax(a,b)
  %3367 = call i32 @dx.op.binary.i32(i32 38, i32 %3365, i32 %30)  ; IMin(a,b)
  %3368 = call i32 @dx.op.binary.i32(i32 38, i32 %3366, i32 %31)  ; IMin(a,b)
  %3369 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3367, i32 %3368, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3370 = extractvalue %dx.types.ResRet.f32 %3369, 0
  %3371 = extractvalue %dx.types.ResRet.f32 %3369, 1
  %3372 = extractvalue %dx.types.ResRet.f32 %3369, 2
  %3373 = extractvalue %dx.types.ResRet.f32 %3369, 3
  %3374 = fcmp fast olt float %3373, 0.000000e+00
  br i1 %3374, label %3375, label %3409

; <label>:3375                                    ; preds = %3364
  %3376 = fcmp fast ogt float %3370, 0x3FA4B5DCC0000000
  %3377 = fcmp fast ogt float %3371, 0x3FA4B5DCC0000000
  %3378 = fcmp fast ogt float %3372, 0x3FA4B5DCC0000000
  %3379 = select i1 %3376, float 0.000000e+00, float 1.000000e+00
  %3380 = select i1 %3377, float 0.000000e+00, float 1.000000e+00
  %3381 = select i1 %3378, float 0.000000e+00, float 1.000000e+00
  %3382 = fmul fast float %3370, 0x3FB3D07220000000
  %3383 = fmul fast float %3371, 0x3FB3D07220000000
  %3384 = fmul fast float %3372, 0x3FB3D07220000000
  %3385 = fadd fast float %3370, 0x3FAC28F5C0000000
  %3386 = fadd fast float %3371, 0x3FAC28F5C0000000
  %3387 = fadd fast float %3372, 0x3FAC28F5C0000000
  %3388 = fmul fast float %3385, 0x3FEE54EDE0000000
  %3389 = fmul fast float %3386, 0x3FEE54EDE0000000
  %3390 = fmul fast float %3387, 0x3FEE54EDE0000000
  %3391 = call float @dx.op.unary.f32(i32 23, float %3388)  ; Log(value)
  %3392 = call float @dx.op.unary.f32(i32 23, float %3389)  ; Log(value)
  %3393 = call float @dx.op.unary.f32(i32 23, float %3390)  ; Log(value)
  %3394 = fmul fast float %3391, 0x4003333340000000
  %3395 = fmul fast float %3392, 0x4003333340000000
  %3396 = fmul fast float %3393, 0x4003333340000000
  %3397 = call float @dx.op.unary.f32(i32 21, float %3394)  ; Exp(value)
  %3398 = call float @dx.op.unary.f32(i32 21, float %3395)  ; Exp(value)
  %3399 = call float @dx.op.unary.f32(i32 21, float %3396)  ; Exp(value)
  %3400 = fsub fast float %3382, %3397
  %3401 = fsub fast float %3383, %3398
  %3402 = fsub fast float %3384, %3399
  %3403 = fmul fast float %3400, %3379
  %3404 = fmul fast float %3401, %3380
  %3405 = fmul fast float %3402, %3381
  %3406 = fadd fast float %3403, %3397
  %3407 = fadd fast float %3404, %3398
  %3408 = fadd fast float %3405, %3399
  br label %3477

; <label>:3409                                    ; preds = %3364
  %3410 = fadd fast float %5, 1.000000e+00
  %3411 = fadd fast float %6, 1.000000e+00
  %3412 = fsub fast float 1.000000e+00, %5
  %3413 = fmul fast float %9, %3410
  %3414 = fmul fast float %9, %3411
  %3415 = fmul fast float %9, %3412
  %3416 = fmul fast float %3413, %3370
  %3417 = fmul fast float %3414, %3371
  %3418 = fmul fast float %3415, %3372
  %3419 = fcmp fast ult float %10, 5.000000e-01
  br i1 %3419, label %3445, label %3420

; <label>:3420                                    ; preds = %3409
  %3421 = fmul fast float %3416, 0x4004147AE0000000
  %3422 = fmul fast float %3417, 0x4004147AE0000000
  %3423 = fmul fast float %3418, 0x4004147AE0000000
  %3424 = fadd fast float %3421, 0x3F9EB851E0000000
  %3425 = fadd fast float %3422, 0x3F9EB851E0000000
  %3426 = fadd fast float %3423, 0x3F9EB851E0000000
  %3427 = fmul fast float %3424, %3416
  %3428 = fmul fast float %3425, %3417
  %3429 = fmul fast float %3426, %3418
  %3430 = fmul fast float %3416, 0x400370A3E0000000
  %3431 = fmul fast float %3417, 0x400370A3E0000000
  %3432 = fmul fast float %3418, 0x400370A3E0000000
  %3433 = fadd fast float %3430, 0x3FE2E147A0000000
  %3434 = fadd fast float %3431, 0x3FE2E147A0000000
  %3435 = fadd fast float %3432, 0x3FE2E147A0000000
  %3436 = fmul fast float %3433, %3416
  %3437 = fmul fast float %3434, %3417
  %3438 = fmul fast float %3435, %3418
  %3439 = fadd fast float %3436, 0x3FC1EB8520000000
  %3440 = fadd fast float %3437, 0x3FC1EB8520000000
  %3441 = fadd fast float %3438, 0x3FC1EB8520000000
  %3442 = fdiv fast float %3427, %3439
  %3443 = fdiv fast float %3428, %3440
  %3444 = fdiv fast float %3429, %3441
  br label %3445

; <label>:3445                                    ; preds = %3420, %3409
  %3446 = phi float [ %3442, %3420 ], [ %3416, %3409 ]
  %3447 = phi float [ %3443, %3420 ], [ %3417, %3409 ]
  %3448 = phi float [ %3444, %3420 ], [ %3418, %3409 ]
  %3449 = call float @dx.op.unary.f32(i32 7, float %3446)  ; Saturate(value)
  %3450 = call float @dx.op.unary.f32(i32 7, float %3447)  ; Saturate(value)
  %3451 = call float @dx.op.unary.f32(i32 7, float %3448)  ; Saturate(value)
  %3452 = call float @dx.op.dot3.f32(i32 55, float %3449, float %3450, float %3451, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3453 = fsub fast float %3449, %3452
  %3454 = fsub fast float %3450, %3452
  %3455 = fsub fast float %3451, %3452
  %3456 = fmul fast float %3453, %8
  %3457 = fmul fast float %3454, %8
  %3458 = fmul fast float %3455, %8
  %3459 = fadd fast float %3456, %3452
  %3460 = fadd fast float %3457, %3452
  %3461 = fadd fast float %3458, %3452
  %3462 = call float @dx.op.unary.f32(i32 7, float %3459)  ; Saturate(value)
  %3463 = call float @dx.op.unary.f32(i32 7, float %3460)  ; Saturate(value)
  %3464 = call float @dx.op.unary.f32(i32 7, float %3461)  ; Saturate(value)
  %3465 = fadd fast float %3462, 0xBFC70A3D80000000
  %3466 = fadd fast float %3463, 0xBFC70A3D80000000
  %3467 = fadd fast float %3464, 0xBFC70A3D80000000
  %3468 = fmul fast float %3465, %7
  %3469 = fmul fast float %3466, %7
  %3470 = fmul fast float %3467, %7
  %3471 = fadd fast float %3468, 0x3FC70A3D80000000
  %3472 = fadd fast float %3469, 0x3FC70A3D80000000
  %3473 = fadd fast float %3470, 0x3FC70A3D80000000
  %3474 = call float @dx.op.unary.f32(i32 7, float %3471)  ; Saturate(value)
  %3475 = call float @dx.op.unary.f32(i32 7, float %3472)  ; Saturate(value)
  %3476 = call float @dx.op.unary.f32(i32 7, float %3473)  ; Saturate(value)
  br label %3477

; <label>:3477                                    ; preds = %3445, %3375
  %3478 = phi float [ %3406, %3375 ], [ %3474, %3445 ]
  %3479 = phi float [ %3407, %3375 ], [ %3475, %3445 ]
  %3480 = phi float [ %3408, %3375 ], [ %3476, %3445 ]
  %3481 = fsub fast float %3478, %3204
  %3482 = fsub fast float %3479, %3205
  %3483 = fsub fast float %3480, %3206
  %3484 = fmul fast float %3481, %3362
  %3485 = fmul fast float %3482, %3362
  %3486 = fmul fast float %3483, %3362
  %3487 = fadd fast float %3484, %3204
  %3488 = fadd fast float %3485, %3205
  %3489 = fadd fast float %3486, %3206
  br label %3490

; <label>:3490                                    ; preds = %3477, %3349
  %3491 = phi float [ %3487, %3477 ], [ %3204, %3349 ]
  %3492 = phi float [ %3488, %3477 ], [ %3205, %3349 ]
  %3493 = phi float [ %3489, %3477 ], [ %3206, %3349 ]
  %3494 = add i32 %38, -1
  %3495 = call i32 @dx.op.binary.i32(i32 37, i32 %3494, i32 0)  ; IMax(a,b)
  %3496 = call i32 @dx.op.binary.i32(i32 37, i32 %35, i32 0)  ; IMax(a,b)
  %3497 = call i32 @dx.op.binary.i32(i32 38, i32 %3495, i32 %30)  ; IMin(a,b)
  %3498 = call i32 @dx.op.binary.i32(i32 38, i32 %3496, i32 %31)  ; IMin(a,b)
  %3499 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3497, i32 %3498, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3500 = extractvalue %dx.types.ResRet.f32 %3499, 0
  %3501 = fsub fast float %3500, %55
  %3502 = call float @dx.op.unary.f32(i32 6, float %3501)  ; FAbs(value)
  %3503 = fdiv fast float %3502, %3216
  %3504 = fsub fast float 1.000000e+00, %3503
  %3505 = call float @dx.op.unary.f32(i32 7, float %3504)  ; Saturate(value)
  %3506 = fcmp fast ugt float %3505, 0.000000e+00
  br i1 %3506, label %3507, label %3633

; <label>:3507                                    ; preds = %3490
  %3508 = call i32 @dx.op.binary.i32(i32 37, i32 %3497, i32 0)  ; IMax(a,b)
  %3509 = call i32 @dx.op.binary.i32(i32 37, i32 %3498, i32 0)  ; IMax(a,b)
  %3510 = call i32 @dx.op.binary.i32(i32 38, i32 %3508, i32 %30)  ; IMin(a,b)
  %3511 = call i32 @dx.op.binary.i32(i32 38, i32 %3509, i32 %31)  ; IMin(a,b)
  %3512 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3510, i32 %3511, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3513 = extractvalue %dx.types.ResRet.f32 %3512, 0
  %3514 = extractvalue %dx.types.ResRet.f32 %3512, 1
  %3515 = extractvalue %dx.types.ResRet.f32 %3512, 2
  %3516 = extractvalue %dx.types.ResRet.f32 %3512, 3
  %3517 = fcmp fast olt float %3516, 0.000000e+00
  br i1 %3517, label %3518, label %3552

; <label>:3518                                    ; preds = %3507
  %3519 = fcmp fast ogt float %3513, 0x3FA4B5DCC0000000
  %3520 = fcmp fast ogt float %3514, 0x3FA4B5DCC0000000
  %3521 = fcmp fast ogt float %3515, 0x3FA4B5DCC0000000
  %3522 = select i1 %3519, float 0.000000e+00, float 1.000000e+00
  %3523 = select i1 %3520, float 0.000000e+00, float 1.000000e+00
  %3524 = select i1 %3521, float 0.000000e+00, float 1.000000e+00
  %3525 = fmul fast float %3513, 0x3FB3D07220000000
  %3526 = fmul fast float %3514, 0x3FB3D07220000000
  %3527 = fmul fast float %3515, 0x3FB3D07220000000
  %3528 = fadd fast float %3513, 0x3FAC28F5C0000000
  %3529 = fadd fast float %3514, 0x3FAC28F5C0000000
  %3530 = fadd fast float %3515, 0x3FAC28F5C0000000
  %3531 = fmul fast float %3528, 0x3FEE54EDE0000000
  %3532 = fmul fast float %3529, 0x3FEE54EDE0000000
  %3533 = fmul fast float %3530, 0x3FEE54EDE0000000
  %3534 = call float @dx.op.unary.f32(i32 23, float %3531)  ; Log(value)
  %3535 = call float @dx.op.unary.f32(i32 23, float %3532)  ; Log(value)
  %3536 = call float @dx.op.unary.f32(i32 23, float %3533)  ; Log(value)
  %3537 = fmul fast float %3534, 0x4003333340000000
  %3538 = fmul fast float %3535, 0x4003333340000000
  %3539 = fmul fast float %3536, 0x4003333340000000
  %3540 = call float @dx.op.unary.f32(i32 21, float %3537)  ; Exp(value)
  %3541 = call float @dx.op.unary.f32(i32 21, float %3538)  ; Exp(value)
  %3542 = call float @dx.op.unary.f32(i32 21, float %3539)  ; Exp(value)
  %3543 = fsub fast float %3525, %3540
  %3544 = fsub fast float %3526, %3541
  %3545 = fsub fast float %3527, %3542
  %3546 = fmul fast float %3543, %3522
  %3547 = fmul fast float %3544, %3523
  %3548 = fmul fast float %3545, %3524
  %3549 = fadd fast float %3546, %3540
  %3550 = fadd fast float %3547, %3541
  %3551 = fadd fast float %3548, %3542
  br label %3620

; <label>:3552                                    ; preds = %3507
  %3553 = fadd fast float %5, 1.000000e+00
  %3554 = fadd fast float %6, 1.000000e+00
  %3555 = fsub fast float 1.000000e+00, %5
  %3556 = fmul fast float %9, %3553
  %3557 = fmul fast float %9, %3554
  %3558 = fmul fast float %9, %3555
  %3559 = fmul fast float %3556, %3513
  %3560 = fmul fast float %3557, %3514
  %3561 = fmul fast float %3558, %3515
  %3562 = fcmp fast ult float %10, 5.000000e-01
  br i1 %3562, label %3588, label %3563

; <label>:3563                                    ; preds = %3552
  %3564 = fmul fast float %3559, 0x4004147AE0000000
  %3565 = fmul fast float %3560, 0x4004147AE0000000
  %3566 = fmul fast float %3561, 0x4004147AE0000000
  %3567 = fadd fast float %3564, 0x3F9EB851E0000000
  %3568 = fadd fast float %3565, 0x3F9EB851E0000000
  %3569 = fadd fast float %3566, 0x3F9EB851E0000000
  %3570 = fmul fast float %3567, %3559
  %3571 = fmul fast float %3568, %3560
  %3572 = fmul fast float %3569, %3561
  %3573 = fmul fast float %3559, 0x400370A3E0000000
  %3574 = fmul fast float %3560, 0x400370A3E0000000
  %3575 = fmul fast float %3561, 0x400370A3E0000000
  %3576 = fadd fast float %3573, 0x3FE2E147A0000000
  %3577 = fadd fast float %3574, 0x3FE2E147A0000000
  %3578 = fadd fast float %3575, 0x3FE2E147A0000000
  %3579 = fmul fast float %3576, %3559
  %3580 = fmul fast float %3577, %3560
  %3581 = fmul fast float %3578, %3561
  %3582 = fadd fast float %3579, 0x3FC1EB8520000000
  %3583 = fadd fast float %3580, 0x3FC1EB8520000000
  %3584 = fadd fast float %3581, 0x3FC1EB8520000000
  %3585 = fdiv fast float %3570, %3582
  %3586 = fdiv fast float %3571, %3583
  %3587 = fdiv fast float %3572, %3584
  br label %3588

; <label>:3588                                    ; preds = %3563, %3552
  %3589 = phi float [ %3585, %3563 ], [ %3559, %3552 ]
  %3590 = phi float [ %3586, %3563 ], [ %3560, %3552 ]
  %3591 = phi float [ %3587, %3563 ], [ %3561, %3552 ]
  %3592 = call float @dx.op.unary.f32(i32 7, float %3589)  ; Saturate(value)
  %3593 = call float @dx.op.unary.f32(i32 7, float %3590)  ; Saturate(value)
  %3594 = call float @dx.op.unary.f32(i32 7, float %3591)  ; Saturate(value)
  %3595 = call float @dx.op.dot3.f32(i32 55, float %3592, float %3593, float %3594, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3596 = fsub fast float %3592, %3595
  %3597 = fsub fast float %3593, %3595
  %3598 = fsub fast float %3594, %3595
  %3599 = fmul fast float %3596, %8
  %3600 = fmul fast float %3597, %8
  %3601 = fmul fast float %3598, %8
  %3602 = fadd fast float %3599, %3595
  %3603 = fadd fast float %3600, %3595
  %3604 = fadd fast float %3601, %3595
  %3605 = call float @dx.op.unary.f32(i32 7, float %3602)  ; Saturate(value)
  %3606 = call float @dx.op.unary.f32(i32 7, float %3603)  ; Saturate(value)
  %3607 = call float @dx.op.unary.f32(i32 7, float %3604)  ; Saturate(value)
  %3608 = fadd fast float %3605, 0xBFC70A3D80000000
  %3609 = fadd fast float %3606, 0xBFC70A3D80000000
  %3610 = fadd fast float %3607, 0xBFC70A3D80000000
  %3611 = fmul fast float %3608, %7
  %3612 = fmul fast float %3609, %7
  %3613 = fmul fast float %3610, %7
  %3614 = fadd fast float %3611, 0x3FC70A3D80000000
  %3615 = fadd fast float %3612, 0x3FC70A3D80000000
  %3616 = fadd fast float %3613, 0x3FC70A3D80000000
  %3617 = call float @dx.op.unary.f32(i32 7, float %3614)  ; Saturate(value)
  %3618 = call float @dx.op.unary.f32(i32 7, float %3615)  ; Saturate(value)
  %3619 = call float @dx.op.unary.f32(i32 7, float %3616)  ; Saturate(value)
  br label %3620

; <label>:3620                                    ; preds = %3588, %3518
  %3621 = phi float [ %3549, %3518 ], [ %3617, %3588 ]
  %3622 = phi float [ %3550, %3518 ], [ %3618, %3588 ]
  %3623 = phi float [ %3551, %3518 ], [ %3619, %3588 ]
  %3624 = fsub fast float %3621, %3204
  %3625 = fsub fast float %3622, %3205
  %3626 = fsub fast float %3623, %3206
  %3627 = fmul fast float %3624, %3505
  %3628 = fmul fast float %3625, %3505
  %3629 = fmul fast float %3626, %3505
  %3630 = fadd fast float %3627, %3204
  %3631 = fadd fast float %3628, %3205
  %3632 = fadd fast float %3629, %3206
  br label %3633

; <label>:3633                                    ; preds = %3620, %3490
  %3634 = phi float [ %3630, %3620 ], [ %3204, %3490 ]
  %3635 = phi float [ %3631, %3620 ], [ %3205, %3490 ]
  %3636 = phi float [ %3632, %3620 ], [ %3206, %3490 ]
  %3637 = add i32 %38, 1
  %3638 = call i32 @dx.op.binary.i32(i32 37, i32 %3637, i32 0)  ; IMax(a,b)
  %3639 = call i32 @dx.op.binary.i32(i32 38, i32 %3638, i32 %30)  ; IMin(a,b)
  %3640 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3639, i32 %3498, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3641 = extractvalue %dx.types.ResRet.f32 %3640, 0
  %3642 = fsub fast float %3641, %55
  %3643 = call float @dx.op.unary.f32(i32 6, float %3642)  ; FAbs(value)
  %3644 = fdiv fast float %3643, %3216
  %3645 = fsub fast float 1.000000e+00, %3644
  %3646 = call float @dx.op.unary.f32(i32 7, float %3645)  ; Saturate(value)
  %3647 = fcmp fast ugt float %3646, 0.000000e+00
  br i1 %3647, label %3648, label %3774

; <label>:3648                                    ; preds = %3633
  %3649 = call i32 @dx.op.binary.i32(i32 37, i32 %3639, i32 0)  ; IMax(a,b)
  %3650 = call i32 @dx.op.binary.i32(i32 37, i32 %3498, i32 0)  ; IMax(a,b)
  %3651 = call i32 @dx.op.binary.i32(i32 38, i32 %3649, i32 %30)  ; IMin(a,b)
  %3652 = call i32 @dx.op.binary.i32(i32 38, i32 %3650, i32 %31)  ; IMin(a,b)
  %3653 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3651, i32 %3652, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3654 = extractvalue %dx.types.ResRet.f32 %3653, 0
  %3655 = extractvalue %dx.types.ResRet.f32 %3653, 1
  %3656 = extractvalue %dx.types.ResRet.f32 %3653, 2
  %3657 = extractvalue %dx.types.ResRet.f32 %3653, 3
  %3658 = fcmp fast olt float %3657, 0.000000e+00
  br i1 %3658, label %3659, label %3693

; <label>:3659                                    ; preds = %3648
  %3660 = fcmp fast ogt float %3654, 0x3FA4B5DCC0000000
  %3661 = fcmp fast ogt float %3655, 0x3FA4B5DCC0000000
  %3662 = fcmp fast ogt float %3656, 0x3FA4B5DCC0000000
  %3663 = select i1 %3660, float 0.000000e+00, float 1.000000e+00
  %3664 = select i1 %3661, float 0.000000e+00, float 1.000000e+00
  %3665 = select i1 %3662, float 0.000000e+00, float 1.000000e+00
  %3666 = fmul fast float %3654, 0x3FB3D07220000000
  %3667 = fmul fast float %3655, 0x3FB3D07220000000
  %3668 = fmul fast float %3656, 0x3FB3D07220000000
  %3669 = fadd fast float %3654, 0x3FAC28F5C0000000
  %3670 = fadd fast float %3655, 0x3FAC28F5C0000000
  %3671 = fadd fast float %3656, 0x3FAC28F5C0000000
  %3672 = fmul fast float %3669, 0x3FEE54EDE0000000
  %3673 = fmul fast float %3670, 0x3FEE54EDE0000000
  %3674 = fmul fast float %3671, 0x3FEE54EDE0000000
  %3675 = call float @dx.op.unary.f32(i32 23, float %3672)  ; Log(value)
  %3676 = call float @dx.op.unary.f32(i32 23, float %3673)  ; Log(value)
  %3677 = call float @dx.op.unary.f32(i32 23, float %3674)  ; Log(value)
  %3678 = fmul fast float %3675, 0x4003333340000000
  %3679 = fmul fast float %3676, 0x4003333340000000
  %3680 = fmul fast float %3677, 0x4003333340000000
  %3681 = call float @dx.op.unary.f32(i32 21, float %3678)  ; Exp(value)
  %3682 = call float @dx.op.unary.f32(i32 21, float %3679)  ; Exp(value)
  %3683 = call float @dx.op.unary.f32(i32 21, float %3680)  ; Exp(value)
  %3684 = fsub fast float %3666, %3681
  %3685 = fsub fast float %3667, %3682
  %3686 = fsub fast float %3668, %3683
  %3687 = fmul fast float %3684, %3663
  %3688 = fmul fast float %3685, %3664
  %3689 = fmul fast float %3686, %3665
  %3690 = fadd fast float %3687, %3681
  %3691 = fadd fast float %3688, %3682
  %3692 = fadd fast float %3689, %3683
  br label %3761

; <label>:3693                                    ; preds = %3648
  %3694 = fadd fast float %5, 1.000000e+00
  %3695 = fadd fast float %6, 1.000000e+00
  %3696 = fsub fast float 1.000000e+00, %5
  %3697 = fmul fast float %9, %3694
  %3698 = fmul fast float %9, %3695
  %3699 = fmul fast float %9, %3696
  %3700 = fmul fast float %3697, %3654
  %3701 = fmul fast float %3698, %3655
  %3702 = fmul fast float %3699, %3656
  %3703 = fcmp fast ult float %10, 5.000000e-01
  br i1 %3703, label %3729, label %3704

; <label>:3704                                    ; preds = %3693
  %3705 = fmul fast float %3700, 0x4004147AE0000000
  %3706 = fmul fast float %3701, 0x4004147AE0000000
  %3707 = fmul fast float %3702, 0x4004147AE0000000
  %3708 = fadd fast float %3705, 0x3F9EB851E0000000
  %3709 = fadd fast float %3706, 0x3F9EB851E0000000
  %3710 = fadd fast float %3707, 0x3F9EB851E0000000
  %3711 = fmul fast float %3708, %3700
  %3712 = fmul fast float %3709, %3701
  %3713 = fmul fast float %3710, %3702
  %3714 = fmul fast float %3700, 0x400370A3E0000000
  %3715 = fmul fast float %3701, 0x400370A3E0000000
  %3716 = fmul fast float %3702, 0x400370A3E0000000
  %3717 = fadd fast float %3714, 0x3FE2E147A0000000
  %3718 = fadd fast float %3715, 0x3FE2E147A0000000
  %3719 = fadd fast float %3716, 0x3FE2E147A0000000
  %3720 = fmul fast float %3717, %3700
  %3721 = fmul fast float %3718, %3701
  %3722 = fmul fast float %3719, %3702
  %3723 = fadd fast float %3720, 0x3FC1EB8520000000
  %3724 = fadd fast float %3721, 0x3FC1EB8520000000
  %3725 = fadd fast float %3722, 0x3FC1EB8520000000
  %3726 = fdiv fast float %3711, %3723
  %3727 = fdiv fast float %3712, %3724
  %3728 = fdiv fast float %3713, %3725
  br label %3729

; <label>:3729                                    ; preds = %3704, %3693
  %3730 = phi float [ %3726, %3704 ], [ %3700, %3693 ]
  %3731 = phi float [ %3727, %3704 ], [ %3701, %3693 ]
  %3732 = phi float [ %3728, %3704 ], [ %3702, %3693 ]
  %3733 = call float @dx.op.unary.f32(i32 7, float %3730)  ; Saturate(value)
  %3734 = call float @dx.op.unary.f32(i32 7, float %3731)  ; Saturate(value)
  %3735 = call float @dx.op.unary.f32(i32 7, float %3732)  ; Saturate(value)
  %3736 = call float @dx.op.dot3.f32(i32 55, float %3733, float %3734, float %3735, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3737 = fsub fast float %3733, %3736
  %3738 = fsub fast float %3734, %3736
  %3739 = fsub fast float %3735, %3736
  %3740 = fmul fast float %3737, %8
  %3741 = fmul fast float %3738, %8
  %3742 = fmul fast float %3739, %8
  %3743 = fadd fast float %3740, %3736
  %3744 = fadd fast float %3741, %3736
  %3745 = fadd fast float %3742, %3736
  %3746 = call float @dx.op.unary.f32(i32 7, float %3743)  ; Saturate(value)
  %3747 = call float @dx.op.unary.f32(i32 7, float %3744)  ; Saturate(value)
  %3748 = call float @dx.op.unary.f32(i32 7, float %3745)  ; Saturate(value)
  %3749 = fadd fast float %3746, 0xBFC70A3D80000000
  %3750 = fadd fast float %3747, 0xBFC70A3D80000000
  %3751 = fadd fast float %3748, 0xBFC70A3D80000000
  %3752 = fmul fast float %3749, %7
  %3753 = fmul fast float %3750, %7
  %3754 = fmul fast float %3751, %7
  %3755 = fadd fast float %3752, 0x3FC70A3D80000000
  %3756 = fadd fast float %3753, 0x3FC70A3D80000000
  %3757 = fadd fast float %3754, 0x3FC70A3D80000000
  %3758 = call float @dx.op.unary.f32(i32 7, float %3755)  ; Saturate(value)
  %3759 = call float @dx.op.unary.f32(i32 7, float %3756)  ; Saturate(value)
  %3760 = call float @dx.op.unary.f32(i32 7, float %3757)  ; Saturate(value)
  br label %3761

; <label>:3761                                    ; preds = %3729, %3659
  %3762 = phi float [ %3690, %3659 ], [ %3758, %3729 ]
  %3763 = phi float [ %3691, %3659 ], [ %3759, %3729 ]
  %3764 = phi float [ %3692, %3659 ], [ %3760, %3729 ]
  %3765 = fsub fast float %3762, %3204
  %3766 = fsub fast float %3763, %3205
  %3767 = fsub fast float %3764, %3206
  %3768 = fmul fast float %3765, %3646
  %3769 = fmul fast float %3766, %3646
  %3770 = fmul fast float %3767, %3646
  %3771 = fadd fast float %3768, %3204
  %3772 = fadd fast float %3769, %3205
  %3773 = fadd fast float %3770, %3206
  br label %3774

; <label>:3774                                    ; preds = %3761, %3633
  %3775 = phi float [ %3771, %3761 ], [ %3204, %3633 ]
  %3776 = phi float [ %3772, %3761 ], [ %3205, %3633 ]
  %3777 = phi float [ %3773, %3761 ], [ %3206, %3633 ]
  %3778 = call float @dx.op.binary.f32(i32 36, float %3634, float %3775)  ; FMin(a,b)
  %3779 = call float @dx.op.binary.f32(i32 36, float %3635, float %3776)  ; FMin(a,b)
  %3780 = call float @dx.op.binary.f32(i32 36, float %3636, float %3777)  ; FMin(a,b)
  %3781 = call float @dx.op.binary.f32(i32 36, float %3350, float %3491)  ; FMin(a,b)
  %3782 = call float @dx.op.binary.f32(i32 36, float %3351, float %3492)  ; FMin(a,b)
  %3783 = call float @dx.op.binary.f32(i32 36, float %3352, float %3493)  ; FMin(a,b)
  %3784 = call float @dx.op.binary.f32(i32 36, float %3781, float %3778)  ; FMin(a,b)
  %3785 = call float @dx.op.binary.f32(i32 36, float %3782, float %3779)  ; FMin(a,b)
  %3786 = call float @dx.op.binary.f32(i32 36, float %3783, float %3780)  ; FMin(a,b)
  %3787 = call float @dx.op.binary.f32(i32 36, float %3204, float %3784)  ; FMin(a,b)
  %3788 = call float @dx.op.binary.f32(i32 36, float %3205, float %3785)  ; FMin(a,b)
  %3789 = call float @dx.op.binary.f32(i32 36, float %3206, float %3786)  ; FMin(a,b)
  %3790 = call float @dx.op.binary.f32(i32 35, float %3634, float %3775)  ; FMax(a,b)
  %3791 = call float @dx.op.binary.f32(i32 35, float %3635, float %3776)  ; FMax(a,b)
  %3792 = call float @dx.op.binary.f32(i32 35, float %3636, float %3777)  ; FMax(a,b)
  %3793 = call float @dx.op.binary.f32(i32 35, float %3350, float %3491)  ; FMax(a,b)
  %3794 = call float @dx.op.binary.f32(i32 35, float %3351, float %3492)  ; FMax(a,b)
  %3795 = call float @dx.op.binary.f32(i32 35, float %3352, float %3493)  ; FMax(a,b)
  %3796 = call float @dx.op.binary.f32(i32 35, float %3793, float %3790)  ; FMax(a,b)
  %3797 = call float @dx.op.binary.f32(i32 35, float %3794, float %3791)  ; FMax(a,b)
  %3798 = call float @dx.op.binary.f32(i32 35, float %3795, float %3792)  ; FMax(a,b)
  %3799 = call float @dx.op.binary.f32(i32 35, float %3204, float %3796)  ; FMax(a,b)
  %3800 = call float @dx.op.binary.f32(i32 35, float %3205, float %3797)  ; FMax(a,b)
  %3801 = call float @dx.op.binary.f32(i32 35, float %3206, float %3798)  ; FMax(a,b)
  %3802 = fsub fast float %3799, %3787
  %3803 = fsub fast float %3800, %3788
  %3804 = fsub fast float %3801, %3789
  %3805 = call float @dx.op.unary.f32(i32 6, float %3802)  ; FAbs(value)
  %3806 = call float @dx.op.unary.f32(i32 6, float %3803)  ; FAbs(value)
  %3807 = call float @dx.op.unary.f32(i32 6, float %3804)  ; FAbs(value)
  %3808 = call float @dx.op.binary.f32(i32 35, float %3806, float %3807)  ; FMax(a,b)
  %3809 = call float @dx.op.binary.f32(i32 35, float %3805, float %3808)  ; FMax(a,b)
  %3810 = call float @dx.op.binary.f32(i32 35, float %3800, float %3801)  ; FMax(a,b)
  %3811 = call float @dx.op.binary.f32(i32 35, float %3799, float %3810)  ; FMax(a,b)
  %3812 = fmul fast float %3811, 1.250000e-01
  %3813 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %3812)  ; FMax(a,b)
  %3814 = fcmp fast ogt float %3809, %3813
  br i1 %3814, label %3815, label %3876

; <label>:3815                                    ; preds = %3774
  %3816 = fsub fast float %3350, %3491
  %3817 = fsub fast float %3351, %3492
  %3818 = fsub fast float %3352, %3493
  %3819 = call float @dx.op.unary.f32(i32 6, float %3816)  ; FAbs(value)
  %3820 = call float @dx.op.unary.f32(i32 6, float %3817)  ; FAbs(value)
  %3821 = call float @dx.op.unary.f32(i32 6, float %3818)  ; FAbs(value)
  %3822 = call float @dx.op.binary.f32(i32 35, float %3820, float %3821)  ; FMax(a,b)
  %3823 = call float @dx.op.binary.f32(i32 35, float %3819, float %3822)  ; FMax(a,b)
  %3824 = fsub fast float %3634, %3775
  %3825 = fsub fast float %3635, %3776
  %3826 = fsub fast float %3636, %3777
  %3827 = call float @dx.op.unary.f32(i32 6, float %3824)  ; FAbs(value)
  %3828 = call float @dx.op.unary.f32(i32 6, float %3825)  ; FAbs(value)
  %3829 = call float @dx.op.unary.f32(i32 6, float %3826)  ; FAbs(value)
  %3830 = call float @dx.op.binary.f32(i32 35, float %3828, float %3829)  ; FMax(a,b)
  %3831 = call float @dx.op.binary.f32(i32 35, float %3827, float %3830)  ; FMax(a,b)
  %3832 = fcmp fast olt float %3823, %3831
  %3833 = select i1 %3832, float %3350, float %3634
  %3834 = select i1 %3832, float %3351, float %3635
  %3835 = select i1 %3832, float %3352, float %3636
  %3836 = select i1 %3832, float %3491, float %3775
  %3837 = select i1 %3832, float %3492, float %3776
  %3838 = select i1 %3832, float %3493, float %3777
  %3839 = fsub fast float %3204, %3836
  %3840 = fsub fast float %3205, %3837
  %3841 = fsub fast float %3206, %3838
  %3842 = fsub fast float %3204, %3833
  %3843 = fsub fast float %3205, %3834
  %3844 = fsub fast float %3206, %3835
  %3845 = call float @dx.op.dot3.f32(i32 55, float %3842, float %3843, float %3844, float %3839, float %3840, float %3841)  ; Dot3(ax,ay,az,bx,by,bz)
  %3846 = fcmp fast ogt float %3845, 0.000000e+00
  br i1 %3846, label %3847, label %3858

; <label>:3847                                    ; preds = %3815
  %3848 = fsub fast float %3833, %3836
  %3849 = fsub fast float %3834, %3837
  %3850 = fsub fast float %3835, %3838
  %3851 = call float @dx.op.unary.f32(i32 6, float %3848)  ; FAbs(value)
  %3852 = call float @dx.op.unary.f32(i32 6, float %3849)  ; FAbs(value)
  %3853 = call float @dx.op.unary.f32(i32 6, float %3850)  ; FAbs(value)
  %3854 = call float @dx.op.binary.f32(i32 35, float %3852, float %3853)  ; FMax(a,b)
  %3855 = call float @dx.op.binary.f32(i32 35, float %3851, float %3854)  ; FMax(a,b)
  %3856 = fmul fast float %3809, 2.500000e-01
  %3857 = fcmp fast olt float %3855, %3856
  br label %3858

; <label>:3858                                    ; preds = %3847, %3815
  %3859 = phi i1 [ false, %3815 ], [ %3857, %3847 ]
  %3860 = select i1 %3859, float 0x3FC3333340000000, float 0x3FD3333340000000
  %3861 = fadd fast float %3833, %3836
  %3862 = fadd fast float %3834, %3837
  %3863 = fadd fast float %3835, %3838
  %3864 = fmul fast float %3861, 5.000000e-01
  %3865 = fmul fast float %3862, 5.000000e-01
  %3866 = fmul fast float %3863, 5.000000e-01
  %3867 = fsub fast float %3864, %3204
  %3868 = fsub fast float %3865, %3205
  %3869 = fsub fast float %3866, %3206
  %3870 = fmul fast float %3860, %3867
  %3871 = fmul fast float %3860, %3868
  %3872 = fmul fast float %3860, %3869
  %3873 = fadd fast float %3870, %3204
  %3874 = fadd fast float %3871, %3205
  %3875 = fadd fast float %3872, %3206
  br label %3876

; <label>:3876                                    ; preds = %3858, %3774, %3104
  %3877 = phi float [ %3135, %3104 ], [ %3873, %3858 ], [ %3204, %3774 ]
  %3878 = phi float [ %3136, %3104 ], [ %3874, %3858 ], [ %3205, %3774 ]
  %3879 = phi float [ %3137, %3104 ], [ %3875, %3858 ], [ %3206, %3774 ]
  %3880 = phi float [ %3138, %3104 ], [ %3102, %3858 ], [ %3102, %3774 ]
  %3881 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %34, i32 %41, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3882 = extractvalue %dx.types.ResRet.f32 %3881, 0
  %3883 = extractvalue %dx.types.ResRet.f32 %3881, 1
  %3884 = extractvalue %dx.types.ResRet.f32 %3881, 2
  %3885 = extractvalue %dx.types.ResRet.f32 %3881, 3
  %3886 = fcmp fast olt float %3885, 0.000000e+00
  br i1 %3886, label %3887, label %3922

; <label>:3887                                    ; preds = %3876
  %3888 = fcmp fast ogt float %3882, 0x3FA4B5DCC0000000
  %3889 = fcmp fast ogt float %3883, 0x3FA4B5DCC0000000
  %3890 = fcmp fast ogt float %3884, 0x3FA4B5DCC0000000
  %3891 = select i1 %3888, float 0.000000e+00, float 1.000000e+00
  %3892 = select i1 %3889, float 0.000000e+00, float 1.000000e+00
  %3893 = select i1 %3890, float 0.000000e+00, float 1.000000e+00
  %3894 = fmul fast float %3882, 0x3FB3D07220000000
  %3895 = fmul fast float %3883, 0x3FB3D07220000000
  %3896 = fmul fast float %3884, 0x3FB3D07220000000
  %3897 = fadd fast float %3882, 0x3FAC28F5C0000000
  %3898 = fadd fast float %3883, 0x3FAC28F5C0000000
  %3899 = fadd fast float %3884, 0x3FAC28F5C0000000
  %3900 = fmul fast float %3897, 0x3FEE54EDE0000000
  %3901 = fmul fast float %3898, 0x3FEE54EDE0000000
  %3902 = fmul fast float %3899, 0x3FEE54EDE0000000
  %3903 = call float @dx.op.unary.f32(i32 23, float %3900)  ; Log(value)
  %3904 = call float @dx.op.unary.f32(i32 23, float %3901)  ; Log(value)
  %3905 = call float @dx.op.unary.f32(i32 23, float %3902)  ; Log(value)
  %3906 = fmul fast float %3903, 0x4003333340000000
  %3907 = fmul fast float %3904, 0x4003333340000000
  %3908 = fmul fast float %3905, 0x4003333340000000
  %3909 = call float @dx.op.unary.f32(i32 21, float %3906)  ; Exp(value)
  %3910 = call float @dx.op.unary.f32(i32 21, float %3907)  ; Exp(value)
  %3911 = call float @dx.op.unary.f32(i32 21, float %3908)  ; Exp(value)
  %3912 = fsub fast float %3894, %3909
  %3913 = fsub fast float %3895, %3910
  %3914 = fsub fast float %3896, %3911
  %3915 = fmul fast float %3912, %3891
  %3916 = fmul fast float %3913, %3892
  %3917 = fmul fast float %3914, %3893
  %3918 = fadd fast float %3915, %3909
  %3919 = fadd fast float %3916, %3910
  %3920 = fadd fast float %3917, %3911
  %3921 = fsub fast float -1.000000e+00, %3885
  br label %4659

; <label>:3922                                    ; preds = %3876
  %3923 = fadd fast float %5, 1.000000e+00
  %3924 = fadd fast float %6, 1.000000e+00
  %3925 = fsub fast float 1.000000e+00, %5
  %3926 = fmul fast float %9, %3923
  %3927 = fmul fast float %9, %3924
  %3928 = fmul fast float %9, %3925
  %3929 = fmul fast float %3926, %3882
  %3930 = fmul fast float %3927, %3883
  %3931 = fmul fast float %3928, %3884
  %3932 = fcmp fast ult float %10, 5.000000e-01
  br i1 %3932, label %3958, label %3933

; <label>:3933                                    ; preds = %3922
  %3934 = fmul fast float %3929, 0x4004147AE0000000
  %3935 = fmul fast float %3930, 0x4004147AE0000000
  %3936 = fmul fast float %3931, 0x4004147AE0000000
  %3937 = fadd fast float %3934, 0x3F9EB851E0000000
  %3938 = fadd fast float %3935, 0x3F9EB851E0000000
  %3939 = fadd fast float %3936, 0x3F9EB851E0000000
  %3940 = fmul fast float %3937, %3929
  %3941 = fmul fast float %3938, %3930
  %3942 = fmul fast float %3939, %3931
  %3943 = fmul fast float %3929, 0x400370A3E0000000
  %3944 = fmul fast float %3930, 0x400370A3E0000000
  %3945 = fmul fast float %3931, 0x400370A3E0000000
  %3946 = fadd fast float %3943, 0x3FE2E147A0000000
  %3947 = fadd fast float %3944, 0x3FE2E147A0000000
  %3948 = fadd fast float %3945, 0x3FE2E147A0000000
  %3949 = fmul fast float %3946, %3929
  %3950 = fmul fast float %3947, %3930
  %3951 = fmul fast float %3948, %3931
  %3952 = fadd fast float %3949, 0x3FC1EB8520000000
  %3953 = fadd fast float %3950, 0x3FC1EB8520000000
  %3954 = fadd fast float %3951, 0x3FC1EB8520000000
  %3955 = fdiv fast float %3940, %3952
  %3956 = fdiv fast float %3941, %3953
  %3957 = fdiv fast float %3942, %3954
  br label %3958

; <label>:3958                                    ; preds = %3933, %3922
  %3959 = phi float [ %3955, %3933 ], [ %3929, %3922 ]
  %3960 = phi float [ %3956, %3933 ], [ %3930, %3922 ]
  %3961 = phi float [ %3957, %3933 ], [ %3931, %3922 ]
  %3962 = call float @dx.op.unary.f32(i32 7, float %3959)  ; Saturate(value)
  %3963 = call float @dx.op.unary.f32(i32 7, float %3960)  ; Saturate(value)
  %3964 = call float @dx.op.unary.f32(i32 7, float %3961)  ; Saturate(value)
  %3965 = call float @dx.op.dot3.f32(i32 55, float %3962, float %3963, float %3964, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3966 = fsub fast float %3962, %3965
  %3967 = fsub fast float %3963, %3965
  %3968 = fsub fast float %3964, %3965
  %3969 = fmul fast float %3966, %8
  %3970 = fmul fast float %3967, %8
  %3971 = fmul fast float %3968, %8
  %3972 = fadd fast float %3969, %3965
  %3973 = fadd fast float %3970, %3965
  %3974 = fadd fast float %3971, %3965
  %3975 = call float @dx.op.unary.f32(i32 7, float %3972)  ; Saturate(value)
  %3976 = call float @dx.op.unary.f32(i32 7, float %3973)  ; Saturate(value)
  %3977 = call float @dx.op.unary.f32(i32 7, float %3974)  ; Saturate(value)
  %3978 = fadd fast float %3975, 0xBFC70A3D80000000
  %3979 = fadd fast float %3976, 0xBFC70A3D80000000
  %3980 = fadd fast float %3977, 0xBFC70A3D80000000
  %3981 = fmul fast float %3978, %7
  %3982 = fmul fast float %3979, %7
  %3983 = fmul fast float %3980, %7
  %3984 = fadd fast float %3981, 0x3FC70A3D80000000
  %3985 = fadd fast float %3982, 0x3FC70A3D80000000
  %3986 = fadd fast float %3983, 0x3FC70A3D80000000
  %3987 = call float @dx.op.unary.f32(i32 7, float %3984)  ; Saturate(value)
  %3988 = call float @dx.op.unary.f32(i32 7, float %3985)  ; Saturate(value)
  %3989 = call float @dx.op.unary.f32(i32 7, float %3986)  ; Saturate(value)
  %3990 = add i32 %41, -1
  %3991 = call i32 @dx.op.binary.i32(i32 37, i32 %34, i32 0)  ; IMax(a,b)
  %3992 = call i32 @dx.op.binary.i32(i32 37, i32 %3990, i32 0)  ; IMax(a,b)
  %3993 = call i32 @dx.op.binary.i32(i32 38, i32 %3991, i32 %30)  ; IMin(a,b)
  %3994 = call i32 @dx.op.binary.i32(i32 38, i32 %3992, i32 %31)  ; IMin(a,b)
  %3995 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3993, i32 %3994, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3996 = extractvalue %dx.types.ResRet.f32 %3995, 0
  %3997 = fsub fast float 1.000000e+00, %57
  %3998 = fmul fast float %3997, 0x3FA99999A0000000
  %3999 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %3998)  ; FMax(a,b)
  %4000 = fsub fast float %3996, %57
  %4001 = call float @dx.op.unary.f32(i32 6, float %4000)  ; FAbs(value)
  %4002 = fdiv fast float %4001, %3999
  %4003 = fsub fast float 1.000000e+00, %4002
  %4004 = call float @dx.op.unary.f32(i32 7, float %4003)  ; Saturate(value)
  %4005 = fcmp fast ugt float %4004, 0.000000e+00
  br i1 %4005, label %4006, label %4132

; <label>:4006                                    ; preds = %3958
  %4007 = call i32 @dx.op.binary.i32(i32 37, i32 %3993, i32 0)  ; IMax(a,b)
  %4008 = call i32 @dx.op.binary.i32(i32 37, i32 %3994, i32 0)  ; IMax(a,b)
  %4009 = call i32 @dx.op.binary.i32(i32 38, i32 %4007, i32 %30)  ; IMin(a,b)
  %4010 = call i32 @dx.op.binary.i32(i32 38, i32 %4008, i32 %31)  ; IMin(a,b)
  %4011 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4009, i32 %4010, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4012 = extractvalue %dx.types.ResRet.f32 %4011, 0
  %4013 = extractvalue %dx.types.ResRet.f32 %4011, 1
  %4014 = extractvalue %dx.types.ResRet.f32 %4011, 2
  %4015 = extractvalue %dx.types.ResRet.f32 %4011, 3
  %4016 = fcmp fast olt float %4015, 0.000000e+00
  br i1 %4016, label %4017, label %4051

; <label>:4017                                    ; preds = %4006
  %4018 = fcmp fast ogt float %4012, 0x3FA4B5DCC0000000
  %4019 = fcmp fast ogt float %4013, 0x3FA4B5DCC0000000
  %4020 = fcmp fast ogt float %4014, 0x3FA4B5DCC0000000
  %4021 = select i1 %4018, float 0.000000e+00, float 1.000000e+00
  %4022 = select i1 %4019, float 0.000000e+00, float 1.000000e+00
  %4023 = select i1 %4020, float 0.000000e+00, float 1.000000e+00
  %4024 = fmul fast float %4012, 0x3FB3D07220000000
  %4025 = fmul fast float %4013, 0x3FB3D07220000000
  %4026 = fmul fast float %4014, 0x3FB3D07220000000
  %4027 = fadd fast float %4012, 0x3FAC28F5C0000000
  %4028 = fadd fast float %4013, 0x3FAC28F5C0000000
  %4029 = fadd fast float %4014, 0x3FAC28F5C0000000
  %4030 = fmul fast float %4027, 0x3FEE54EDE0000000
  %4031 = fmul fast float %4028, 0x3FEE54EDE0000000
  %4032 = fmul fast float %4029, 0x3FEE54EDE0000000
  %4033 = call float @dx.op.unary.f32(i32 23, float %4030)  ; Log(value)
  %4034 = call float @dx.op.unary.f32(i32 23, float %4031)  ; Log(value)
  %4035 = call float @dx.op.unary.f32(i32 23, float %4032)  ; Log(value)
  %4036 = fmul fast float %4033, 0x4003333340000000
  %4037 = fmul fast float %4034, 0x4003333340000000
  %4038 = fmul fast float %4035, 0x4003333340000000
  %4039 = call float @dx.op.unary.f32(i32 21, float %4036)  ; Exp(value)
  %4040 = call float @dx.op.unary.f32(i32 21, float %4037)  ; Exp(value)
  %4041 = call float @dx.op.unary.f32(i32 21, float %4038)  ; Exp(value)
  %4042 = fsub fast float %4024, %4039
  %4043 = fsub fast float %4025, %4040
  %4044 = fsub fast float %4026, %4041
  %4045 = fmul fast float %4042, %4021
  %4046 = fmul fast float %4043, %4022
  %4047 = fmul fast float %4044, %4023
  %4048 = fadd fast float %4045, %4039
  %4049 = fadd fast float %4046, %4040
  %4050 = fadd fast float %4047, %4041
  br label %4119

; <label>:4051                                    ; preds = %4006
  %4052 = fadd fast float %5, 1.000000e+00
  %4053 = fadd fast float %6, 1.000000e+00
  %4054 = fsub fast float 1.000000e+00, %5
  %4055 = fmul fast float %9, %4052
  %4056 = fmul fast float %9, %4053
  %4057 = fmul fast float %9, %4054
  %4058 = fmul fast float %4055, %4012
  %4059 = fmul fast float %4056, %4013
  %4060 = fmul fast float %4057, %4014
  %4061 = fcmp fast ult float %10, 5.000000e-01
  br i1 %4061, label %4087, label %4062

; <label>:4062                                    ; preds = %4051
  %4063 = fmul fast float %4058, 0x4004147AE0000000
  %4064 = fmul fast float %4059, 0x4004147AE0000000
  %4065 = fmul fast float %4060, 0x4004147AE0000000
  %4066 = fadd fast float %4063, 0x3F9EB851E0000000
  %4067 = fadd fast float %4064, 0x3F9EB851E0000000
  %4068 = fadd fast float %4065, 0x3F9EB851E0000000
  %4069 = fmul fast float %4066, %4058
  %4070 = fmul fast float %4067, %4059
  %4071 = fmul fast float %4068, %4060
  %4072 = fmul fast float %4058, 0x400370A3E0000000
  %4073 = fmul fast float %4059, 0x400370A3E0000000
  %4074 = fmul fast float %4060, 0x400370A3E0000000
  %4075 = fadd fast float %4072, 0x3FE2E147A0000000
  %4076 = fadd fast float %4073, 0x3FE2E147A0000000
  %4077 = fadd fast float %4074, 0x3FE2E147A0000000
  %4078 = fmul fast float %4075, %4058
  %4079 = fmul fast float %4076, %4059
  %4080 = fmul fast float %4077, %4060
  %4081 = fadd fast float %4078, 0x3FC1EB8520000000
  %4082 = fadd fast float %4079, 0x3FC1EB8520000000
  %4083 = fadd fast float %4080, 0x3FC1EB8520000000
  %4084 = fdiv fast float %4069, %4081
  %4085 = fdiv fast float %4070, %4082
  %4086 = fdiv fast float %4071, %4083
  br label %4087

; <label>:4087                                    ; preds = %4062, %4051
  %4088 = phi float [ %4084, %4062 ], [ %4058, %4051 ]
  %4089 = phi float [ %4085, %4062 ], [ %4059, %4051 ]
  %4090 = phi float [ %4086, %4062 ], [ %4060, %4051 ]
  %4091 = call float @dx.op.unary.f32(i32 7, float %4088)  ; Saturate(value)
  %4092 = call float @dx.op.unary.f32(i32 7, float %4089)  ; Saturate(value)
  %4093 = call float @dx.op.unary.f32(i32 7, float %4090)  ; Saturate(value)
  %4094 = call float @dx.op.dot3.f32(i32 55, float %4091, float %4092, float %4093, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4095 = fsub fast float %4091, %4094
  %4096 = fsub fast float %4092, %4094
  %4097 = fsub fast float %4093, %4094
  %4098 = fmul fast float %4095, %8
  %4099 = fmul fast float %4096, %8
  %4100 = fmul fast float %4097, %8
  %4101 = fadd fast float %4098, %4094
  %4102 = fadd fast float %4099, %4094
  %4103 = fadd fast float %4100, %4094
  %4104 = call float @dx.op.unary.f32(i32 7, float %4101)  ; Saturate(value)
  %4105 = call float @dx.op.unary.f32(i32 7, float %4102)  ; Saturate(value)
  %4106 = call float @dx.op.unary.f32(i32 7, float %4103)  ; Saturate(value)
  %4107 = fadd fast float %4104, 0xBFC70A3D80000000
  %4108 = fadd fast float %4105, 0xBFC70A3D80000000
  %4109 = fadd fast float %4106, 0xBFC70A3D80000000
  %4110 = fmul fast float %4107, %7
  %4111 = fmul fast float %4108, %7
  %4112 = fmul fast float %4109, %7
  %4113 = fadd fast float %4110, 0x3FC70A3D80000000
  %4114 = fadd fast float %4111, 0x3FC70A3D80000000
  %4115 = fadd fast float %4112, 0x3FC70A3D80000000
  %4116 = call float @dx.op.unary.f32(i32 7, float %4113)  ; Saturate(value)
  %4117 = call float @dx.op.unary.f32(i32 7, float %4114)  ; Saturate(value)
  %4118 = call float @dx.op.unary.f32(i32 7, float %4115)  ; Saturate(value)
  br label %4119

; <label>:4119                                    ; preds = %4087, %4017
  %4120 = phi float [ %4048, %4017 ], [ %4116, %4087 ]
  %4121 = phi float [ %4049, %4017 ], [ %4117, %4087 ]
  %4122 = phi float [ %4050, %4017 ], [ %4118, %4087 ]
  %4123 = fsub fast float %4120, %3987
  %4124 = fsub fast float %4121, %3988
  %4125 = fsub fast float %4122, %3989
  %4126 = fmul fast float %4123, %4004
  %4127 = fmul fast float %4124, %4004
  %4128 = fmul fast float %4125, %4004
  %4129 = fadd fast float %4126, %3987
  %4130 = fadd fast float %4127, %3988
  %4131 = fadd fast float %4128, %3989
  br label %4132

; <label>:4132                                    ; preds = %4119, %3958
  %4133 = phi float [ %4129, %4119 ], [ %3987, %3958 ]
  %4134 = phi float [ %4130, %4119 ], [ %3988, %3958 ]
  %4135 = phi float [ %4131, %4119 ], [ %3989, %3958 ]
  %4136 = add i32 %41, 1
  %4137 = call i32 @dx.op.binary.i32(i32 37, i32 %4136, i32 0)  ; IMax(a,b)
  %4138 = call i32 @dx.op.binary.i32(i32 38, i32 %4137, i32 %31)  ; IMin(a,b)
  %4139 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3993, i32 %4138, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4140 = extractvalue %dx.types.ResRet.f32 %4139, 0
  %4141 = fsub fast float %4140, %57
  %4142 = call float @dx.op.unary.f32(i32 6, float %4141)  ; FAbs(value)
  %4143 = fdiv fast float %4142, %3999
  %4144 = fsub fast float 1.000000e+00, %4143
  %4145 = call float @dx.op.unary.f32(i32 7, float %4144)  ; Saturate(value)
  %4146 = fcmp fast ugt float %4145, 0.000000e+00
  br i1 %4146, label %4147, label %4273

; <label>:4147                                    ; preds = %4132
  %4148 = call i32 @dx.op.binary.i32(i32 37, i32 %3993, i32 0)  ; IMax(a,b)
  %4149 = call i32 @dx.op.binary.i32(i32 37, i32 %4138, i32 0)  ; IMax(a,b)
  %4150 = call i32 @dx.op.binary.i32(i32 38, i32 %4148, i32 %30)  ; IMin(a,b)
  %4151 = call i32 @dx.op.binary.i32(i32 38, i32 %4149, i32 %31)  ; IMin(a,b)
  %4152 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4150, i32 %4151, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4153 = extractvalue %dx.types.ResRet.f32 %4152, 0
  %4154 = extractvalue %dx.types.ResRet.f32 %4152, 1
  %4155 = extractvalue %dx.types.ResRet.f32 %4152, 2
  %4156 = extractvalue %dx.types.ResRet.f32 %4152, 3
  %4157 = fcmp fast olt float %4156, 0.000000e+00
  br i1 %4157, label %4158, label %4192

; <label>:4158                                    ; preds = %4147
  %4159 = fcmp fast ogt float %4153, 0x3FA4B5DCC0000000
  %4160 = fcmp fast ogt float %4154, 0x3FA4B5DCC0000000
  %4161 = fcmp fast ogt float %4155, 0x3FA4B5DCC0000000
  %4162 = select i1 %4159, float 0.000000e+00, float 1.000000e+00
  %4163 = select i1 %4160, float 0.000000e+00, float 1.000000e+00
  %4164 = select i1 %4161, float 0.000000e+00, float 1.000000e+00
  %4165 = fmul fast float %4153, 0x3FB3D07220000000
  %4166 = fmul fast float %4154, 0x3FB3D07220000000
  %4167 = fmul fast float %4155, 0x3FB3D07220000000
  %4168 = fadd fast float %4153, 0x3FAC28F5C0000000
  %4169 = fadd fast float %4154, 0x3FAC28F5C0000000
  %4170 = fadd fast float %4155, 0x3FAC28F5C0000000
  %4171 = fmul fast float %4168, 0x3FEE54EDE0000000
  %4172 = fmul fast float %4169, 0x3FEE54EDE0000000
  %4173 = fmul fast float %4170, 0x3FEE54EDE0000000
  %4174 = call float @dx.op.unary.f32(i32 23, float %4171)  ; Log(value)
  %4175 = call float @dx.op.unary.f32(i32 23, float %4172)  ; Log(value)
  %4176 = call float @dx.op.unary.f32(i32 23, float %4173)  ; Log(value)
  %4177 = fmul fast float %4174, 0x4003333340000000
  %4178 = fmul fast float %4175, 0x4003333340000000
  %4179 = fmul fast float %4176, 0x4003333340000000
  %4180 = call float @dx.op.unary.f32(i32 21, float %4177)  ; Exp(value)
  %4181 = call float @dx.op.unary.f32(i32 21, float %4178)  ; Exp(value)
  %4182 = call float @dx.op.unary.f32(i32 21, float %4179)  ; Exp(value)
  %4183 = fsub fast float %4165, %4180
  %4184 = fsub fast float %4166, %4181
  %4185 = fsub fast float %4167, %4182
  %4186 = fmul fast float %4183, %4162
  %4187 = fmul fast float %4184, %4163
  %4188 = fmul fast float %4185, %4164
  %4189 = fadd fast float %4186, %4180
  %4190 = fadd fast float %4187, %4181
  %4191 = fadd fast float %4188, %4182
  br label %4260

; <label>:4192                                    ; preds = %4147
  %4193 = fadd fast float %5, 1.000000e+00
  %4194 = fadd fast float %6, 1.000000e+00
  %4195 = fsub fast float 1.000000e+00, %5
  %4196 = fmul fast float %9, %4193
  %4197 = fmul fast float %9, %4194
  %4198 = fmul fast float %9, %4195
  %4199 = fmul fast float %4196, %4153
  %4200 = fmul fast float %4197, %4154
  %4201 = fmul fast float %4198, %4155
  %4202 = fcmp fast ult float %10, 5.000000e-01
  br i1 %4202, label %4228, label %4203

; <label>:4203                                    ; preds = %4192
  %4204 = fmul fast float %4199, 0x4004147AE0000000
  %4205 = fmul fast float %4200, 0x4004147AE0000000
  %4206 = fmul fast float %4201, 0x4004147AE0000000
  %4207 = fadd fast float %4204, 0x3F9EB851E0000000
  %4208 = fadd fast float %4205, 0x3F9EB851E0000000
  %4209 = fadd fast float %4206, 0x3F9EB851E0000000
  %4210 = fmul fast float %4207, %4199
  %4211 = fmul fast float %4208, %4200
  %4212 = fmul fast float %4209, %4201
  %4213 = fmul fast float %4199, 0x400370A3E0000000
  %4214 = fmul fast float %4200, 0x400370A3E0000000
  %4215 = fmul fast float %4201, 0x400370A3E0000000
  %4216 = fadd fast float %4213, 0x3FE2E147A0000000
  %4217 = fadd fast float %4214, 0x3FE2E147A0000000
  %4218 = fadd fast float %4215, 0x3FE2E147A0000000
  %4219 = fmul fast float %4216, %4199
  %4220 = fmul fast float %4217, %4200
  %4221 = fmul fast float %4218, %4201
  %4222 = fadd fast float %4219, 0x3FC1EB8520000000
  %4223 = fadd fast float %4220, 0x3FC1EB8520000000
  %4224 = fadd fast float %4221, 0x3FC1EB8520000000
  %4225 = fdiv fast float %4210, %4222
  %4226 = fdiv fast float %4211, %4223
  %4227 = fdiv fast float %4212, %4224
  br label %4228

; <label>:4228                                    ; preds = %4203, %4192
  %4229 = phi float [ %4225, %4203 ], [ %4199, %4192 ]
  %4230 = phi float [ %4226, %4203 ], [ %4200, %4192 ]
  %4231 = phi float [ %4227, %4203 ], [ %4201, %4192 ]
  %4232 = call float @dx.op.unary.f32(i32 7, float %4229)  ; Saturate(value)
  %4233 = call float @dx.op.unary.f32(i32 7, float %4230)  ; Saturate(value)
  %4234 = call float @dx.op.unary.f32(i32 7, float %4231)  ; Saturate(value)
  %4235 = call float @dx.op.dot3.f32(i32 55, float %4232, float %4233, float %4234, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4236 = fsub fast float %4232, %4235
  %4237 = fsub fast float %4233, %4235
  %4238 = fsub fast float %4234, %4235
  %4239 = fmul fast float %4236, %8
  %4240 = fmul fast float %4237, %8
  %4241 = fmul fast float %4238, %8
  %4242 = fadd fast float %4239, %4235
  %4243 = fadd fast float %4240, %4235
  %4244 = fadd fast float %4241, %4235
  %4245 = call float @dx.op.unary.f32(i32 7, float %4242)  ; Saturate(value)
  %4246 = call float @dx.op.unary.f32(i32 7, float %4243)  ; Saturate(value)
  %4247 = call float @dx.op.unary.f32(i32 7, float %4244)  ; Saturate(value)
  %4248 = fadd fast float %4245, 0xBFC70A3D80000000
  %4249 = fadd fast float %4246, 0xBFC70A3D80000000
  %4250 = fadd fast float %4247, 0xBFC70A3D80000000
  %4251 = fmul fast float %4248, %7
  %4252 = fmul fast float %4249, %7
  %4253 = fmul fast float %4250, %7
  %4254 = fadd fast float %4251, 0x3FC70A3D80000000
  %4255 = fadd fast float %4252, 0x3FC70A3D80000000
  %4256 = fadd fast float %4253, 0x3FC70A3D80000000
  %4257 = call float @dx.op.unary.f32(i32 7, float %4254)  ; Saturate(value)
  %4258 = call float @dx.op.unary.f32(i32 7, float %4255)  ; Saturate(value)
  %4259 = call float @dx.op.unary.f32(i32 7, float %4256)  ; Saturate(value)
  br label %4260

; <label>:4260                                    ; preds = %4228, %4158
  %4261 = phi float [ %4189, %4158 ], [ %4257, %4228 ]
  %4262 = phi float [ %4190, %4158 ], [ %4258, %4228 ]
  %4263 = phi float [ %4191, %4158 ], [ %4259, %4228 ]
  %4264 = fsub fast float %4261, %3987
  %4265 = fsub fast float %4262, %3988
  %4266 = fsub fast float %4263, %3989
  %4267 = fmul fast float %4264, %4145
  %4268 = fmul fast float %4265, %4145
  %4269 = fmul fast float %4266, %4145
  %4270 = fadd fast float %4267, %3987
  %4271 = fadd fast float %4268, %3988
  %4272 = fadd fast float %4269, %3989
  br label %4273

; <label>:4273                                    ; preds = %4260, %4132
  %4274 = phi float [ %4270, %4260 ], [ %3987, %4132 ]
  %4275 = phi float [ %4271, %4260 ], [ %3988, %4132 ]
  %4276 = phi float [ %4272, %4260 ], [ %3989, %4132 ]
  %4277 = add i32 %34, -1
  %4278 = call i32 @dx.op.binary.i32(i32 37, i32 %4277, i32 0)  ; IMax(a,b)
  %4279 = call i32 @dx.op.binary.i32(i32 37, i32 %41, i32 0)  ; IMax(a,b)
  %4280 = call i32 @dx.op.binary.i32(i32 38, i32 %4278, i32 %30)  ; IMin(a,b)
  %4281 = call i32 @dx.op.binary.i32(i32 38, i32 %4279, i32 %31)  ; IMin(a,b)
  %4282 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4280, i32 %4281, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4283 = extractvalue %dx.types.ResRet.f32 %4282, 0
  %4284 = fsub fast float %4283, %57
  %4285 = call float @dx.op.unary.f32(i32 6, float %4284)  ; FAbs(value)
  %4286 = fdiv fast float %4285, %3999
  %4287 = fsub fast float 1.000000e+00, %4286
  %4288 = call float @dx.op.unary.f32(i32 7, float %4287)  ; Saturate(value)
  %4289 = fcmp fast ugt float %4288, 0.000000e+00
  br i1 %4289, label %4290, label %4416

; <label>:4290                                    ; preds = %4273
  %4291 = call i32 @dx.op.binary.i32(i32 37, i32 %4280, i32 0)  ; IMax(a,b)
  %4292 = call i32 @dx.op.binary.i32(i32 37, i32 %4281, i32 0)  ; IMax(a,b)
  %4293 = call i32 @dx.op.binary.i32(i32 38, i32 %4291, i32 %30)  ; IMin(a,b)
  %4294 = call i32 @dx.op.binary.i32(i32 38, i32 %4292, i32 %31)  ; IMin(a,b)
  %4295 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4293, i32 %4294, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4296 = extractvalue %dx.types.ResRet.f32 %4295, 0
  %4297 = extractvalue %dx.types.ResRet.f32 %4295, 1
  %4298 = extractvalue %dx.types.ResRet.f32 %4295, 2
  %4299 = extractvalue %dx.types.ResRet.f32 %4295, 3
  %4300 = fcmp fast olt float %4299, 0.000000e+00
  br i1 %4300, label %4301, label %4335

; <label>:4301                                    ; preds = %4290
  %4302 = fcmp fast ogt float %4296, 0x3FA4B5DCC0000000
  %4303 = fcmp fast ogt float %4297, 0x3FA4B5DCC0000000
  %4304 = fcmp fast ogt float %4298, 0x3FA4B5DCC0000000
  %4305 = select i1 %4302, float 0.000000e+00, float 1.000000e+00
  %4306 = select i1 %4303, float 0.000000e+00, float 1.000000e+00
  %4307 = select i1 %4304, float 0.000000e+00, float 1.000000e+00
  %4308 = fmul fast float %4296, 0x3FB3D07220000000
  %4309 = fmul fast float %4297, 0x3FB3D07220000000
  %4310 = fmul fast float %4298, 0x3FB3D07220000000
  %4311 = fadd fast float %4296, 0x3FAC28F5C0000000
  %4312 = fadd fast float %4297, 0x3FAC28F5C0000000
  %4313 = fadd fast float %4298, 0x3FAC28F5C0000000
  %4314 = fmul fast float %4311, 0x3FEE54EDE0000000
  %4315 = fmul fast float %4312, 0x3FEE54EDE0000000
  %4316 = fmul fast float %4313, 0x3FEE54EDE0000000
  %4317 = call float @dx.op.unary.f32(i32 23, float %4314)  ; Log(value)
  %4318 = call float @dx.op.unary.f32(i32 23, float %4315)  ; Log(value)
  %4319 = call float @dx.op.unary.f32(i32 23, float %4316)  ; Log(value)
  %4320 = fmul fast float %4317, 0x4003333340000000
  %4321 = fmul fast float %4318, 0x4003333340000000
  %4322 = fmul fast float %4319, 0x4003333340000000
  %4323 = call float @dx.op.unary.f32(i32 21, float %4320)  ; Exp(value)
  %4324 = call float @dx.op.unary.f32(i32 21, float %4321)  ; Exp(value)
  %4325 = call float @dx.op.unary.f32(i32 21, float %4322)  ; Exp(value)
  %4326 = fsub fast float %4308, %4323
  %4327 = fsub fast float %4309, %4324
  %4328 = fsub fast float %4310, %4325
  %4329 = fmul fast float %4326, %4305
  %4330 = fmul fast float %4327, %4306
  %4331 = fmul fast float %4328, %4307
  %4332 = fadd fast float %4329, %4323
  %4333 = fadd fast float %4330, %4324
  %4334 = fadd fast float %4331, %4325
  br label %4403

; <label>:4335                                    ; preds = %4290
  %4336 = fadd fast float %5, 1.000000e+00
  %4337 = fadd fast float %6, 1.000000e+00
  %4338 = fsub fast float 1.000000e+00, %5
  %4339 = fmul fast float %9, %4336
  %4340 = fmul fast float %9, %4337
  %4341 = fmul fast float %9, %4338
  %4342 = fmul fast float %4339, %4296
  %4343 = fmul fast float %4340, %4297
  %4344 = fmul fast float %4341, %4298
  %4345 = fcmp fast ult float %10, 5.000000e-01
  br i1 %4345, label %4371, label %4346

; <label>:4346                                    ; preds = %4335
  %4347 = fmul fast float %4342, 0x4004147AE0000000
  %4348 = fmul fast float %4343, 0x4004147AE0000000
  %4349 = fmul fast float %4344, 0x4004147AE0000000
  %4350 = fadd fast float %4347, 0x3F9EB851E0000000
  %4351 = fadd fast float %4348, 0x3F9EB851E0000000
  %4352 = fadd fast float %4349, 0x3F9EB851E0000000
  %4353 = fmul fast float %4350, %4342
  %4354 = fmul fast float %4351, %4343
  %4355 = fmul fast float %4352, %4344
  %4356 = fmul fast float %4342, 0x400370A3E0000000
  %4357 = fmul fast float %4343, 0x400370A3E0000000
  %4358 = fmul fast float %4344, 0x400370A3E0000000
  %4359 = fadd fast float %4356, 0x3FE2E147A0000000
  %4360 = fadd fast float %4357, 0x3FE2E147A0000000
  %4361 = fadd fast float %4358, 0x3FE2E147A0000000
  %4362 = fmul fast float %4359, %4342
  %4363 = fmul fast float %4360, %4343
  %4364 = fmul fast float %4361, %4344
  %4365 = fadd fast float %4362, 0x3FC1EB8520000000
  %4366 = fadd fast float %4363, 0x3FC1EB8520000000
  %4367 = fadd fast float %4364, 0x3FC1EB8520000000
  %4368 = fdiv fast float %4353, %4365
  %4369 = fdiv fast float %4354, %4366
  %4370 = fdiv fast float %4355, %4367
  br label %4371

; <label>:4371                                    ; preds = %4346, %4335
  %4372 = phi float [ %4368, %4346 ], [ %4342, %4335 ]
  %4373 = phi float [ %4369, %4346 ], [ %4343, %4335 ]
  %4374 = phi float [ %4370, %4346 ], [ %4344, %4335 ]
  %4375 = call float @dx.op.unary.f32(i32 7, float %4372)  ; Saturate(value)
  %4376 = call float @dx.op.unary.f32(i32 7, float %4373)  ; Saturate(value)
  %4377 = call float @dx.op.unary.f32(i32 7, float %4374)  ; Saturate(value)
  %4378 = call float @dx.op.dot3.f32(i32 55, float %4375, float %4376, float %4377, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4379 = fsub fast float %4375, %4378
  %4380 = fsub fast float %4376, %4378
  %4381 = fsub fast float %4377, %4378
  %4382 = fmul fast float %4379, %8
  %4383 = fmul fast float %4380, %8
  %4384 = fmul fast float %4381, %8
  %4385 = fadd fast float %4382, %4378
  %4386 = fadd fast float %4383, %4378
  %4387 = fadd fast float %4384, %4378
  %4388 = call float @dx.op.unary.f32(i32 7, float %4385)  ; Saturate(value)
  %4389 = call float @dx.op.unary.f32(i32 7, float %4386)  ; Saturate(value)
  %4390 = call float @dx.op.unary.f32(i32 7, float %4387)  ; Saturate(value)
  %4391 = fadd fast float %4388, 0xBFC70A3D80000000
  %4392 = fadd fast float %4389, 0xBFC70A3D80000000
  %4393 = fadd fast float %4390, 0xBFC70A3D80000000
  %4394 = fmul fast float %4391, %7
  %4395 = fmul fast float %4392, %7
  %4396 = fmul fast float %4393, %7
  %4397 = fadd fast float %4394, 0x3FC70A3D80000000
  %4398 = fadd fast float %4395, 0x3FC70A3D80000000
  %4399 = fadd fast float %4396, 0x3FC70A3D80000000
  %4400 = call float @dx.op.unary.f32(i32 7, float %4397)  ; Saturate(value)
  %4401 = call float @dx.op.unary.f32(i32 7, float %4398)  ; Saturate(value)
  %4402 = call float @dx.op.unary.f32(i32 7, float %4399)  ; Saturate(value)
  br label %4403

; <label>:4403                                    ; preds = %4371, %4301
  %4404 = phi float [ %4332, %4301 ], [ %4400, %4371 ]
  %4405 = phi float [ %4333, %4301 ], [ %4401, %4371 ]
  %4406 = phi float [ %4334, %4301 ], [ %4402, %4371 ]
  %4407 = fsub fast float %4404, %3987
  %4408 = fsub fast float %4405, %3988
  %4409 = fsub fast float %4406, %3989
  %4410 = fmul fast float %4407, %4288
  %4411 = fmul fast float %4408, %4288
  %4412 = fmul fast float %4409, %4288
  %4413 = fadd fast float %4410, %3987
  %4414 = fadd fast float %4411, %3988
  %4415 = fadd fast float %4412, %3989
  br label %4416

; <label>:4416                                    ; preds = %4403, %4273
  %4417 = phi float [ %4413, %4403 ], [ %3987, %4273 ]
  %4418 = phi float [ %4414, %4403 ], [ %3988, %4273 ]
  %4419 = phi float [ %4415, %4403 ], [ %3989, %4273 ]
  %4420 = add i32 %34, 1
  %4421 = call i32 @dx.op.binary.i32(i32 37, i32 %4420, i32 0)  ; IMax(a,b)
  %4422 = call i32 @dx.op.binary.i32(i32 38, i32 %4421, i32 %30)  ; IMin(a,b)
  %4423 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4422, i32 %4281, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4424 = extractvalue %dx.types.ResRet.f32 %4423, 0
  %4425 = fsub fast float %4424, %57
  %4426 = call float @dx.op.unary.f32(i32 6, float %4425)  ; FAbs(value)
  %4427 = fdiv fast float %4426, %3999
  %4428 = fsub fast float 1.000000e+00, %4427
  %4429 = call float @dx.op.unary.f32(i32 7, float %4428)  ; Saturate(value)
  %4430 = fcmp fast ugt float %4429, 0.000000e+00
  br i1 %4430, label %4431, label %4557

; <label>:4431                                    ; preds = %4416
  %4432 = call i32 @dx.op.binary.i32(i32 37, i32 %4422, i32 0)  ; IMax(a,b)
  %4433 = call i32 @dx.op.binary.i32(i32 37, i32 %4281, i32 0)  ; IMax(a,b)
  %4434 = call i32 @dx.op.binary.i32(i32 38, i32 %4432, i32 %30)  ; IMin(a,b)
  %4435 = call i32 @dx.op.binary.i32(i32 38, i32 %4433, i32 %31)  ; IMin(a,b)
  %4436 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4434, i32 %4435, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4437 = extractvalue %dx.types.ResRet.f32 %4436, 0
  %4438 = extractvalue %dx.types.ResRet.f32 %4436, 1
  %4439 = extractvalue %dx.types.ResRet.f32 %4436, 2
  %4440 = extractvalue %dx.types.ResRet.f32 %4436, 3
  %4441 = fcmp fast olt float %4440, 0.000000e+00
  br i1 %4441, label %4442, label %4476

; <label>:4442                                    ; preds = %4431
  %4443 = fcmp fast ogt float %4437, 0x3FA4B5DCC0000000
  %4444 = fcmp fast ogt float %4438, 0x3FA4B5DCC0000000
  %4445 = fcmp fast ogt float %4439, 0x3FA4B5DCC0000000
  %4446 = select i1 %4443, float 0.000000e+00, float 1.000000e+00
  %4447 = select i1 %4444, float 0.000000e+00, float 1.000000e+00
  %4448 = select i1 %4445, float 0.000000e+00, float 1.000000e+00
  %4449 = fmul fast float %4437, 0x3FB3D07220000000
  %4450 = fmul fast float %4438, 0x3FB3D07220000000
  %4451 = fmul fast float %4439, 0x3FB3D07220000000
  %4452 = fadd fast float %4437, 0x3FAC28F5C0000000
  %4453 = fadd fast float %4438, 0x3FAC28F5C0000000
  %4454 = fadd fast float %4439, 0x3FAC28F5C0000000
  %4455 = fmul fast float %4452, 0x3FEE54EDE0000000
  %4456 = fmul fast float %4453, 0x3FEE54EDE0000000
  %4457 = fmul fast float %4454, 0x3FEE54EDE0000000
  %4458 = call float @dx.op.unary.f32(i32 23, float %4455)  ; Log(value)
  %4459 = call float @dx.op.unary.f32(i32 23, float %4456)  ; Log(value)
  %4460 = call float @dx.op.unary.f32(i32 23, float %4457)  ; Log(value)
  %4461 = fmul fast float %4458, 0x4003333340000000
  %4462 = fmul fast float %4459, 0x4003333340000000
  %4463 = fmul fast float %4460, 0x4003333340000000
  %4464 = call float @dx.op.unary.f32(i32 21, float %4461)  ; Exp(value)
  %4465 = call float @dx.op.unary.f32(i32 21, float %4462)  ; Exp(value)
  %4466 = call float @dx.op.unary.f32(i32 21, float %4463)  ; Exp(value)
  %4467 = fsub fast float %4449, %4464
  %4468 = fsub fast float %4450, %4465
  %4469 = fsub fast float %4451, %4466
  %4470 = fmul fast float %4467, %4446
  %4471 = fmul fast float %4468, %4447
  %4472 = fmul fast float %4469, %4448
  %4473 = fadd fast float %4470, %4464
  %4474 = fadd fast float %4471, %4465
  %4475 = fadd fast float %4472, %4466
  br label %4544

; <label>:4476                                    ; preds = %4431
  %4477 = fadd fast float %5, 1.000000e+00
  %4478 = fadd fast float %6, 1.000000e+00
  %4479 = fsub fast float 1.000000e+00, %5
  %4480 = fmul fast float %9, %4477
  %4481 = fmul fast float %9, %4478
  %4482 = fmul fast float %9, %4479
  %4483 = fmul fast float %4480, %4437
  %4484 = fmul fast float %4481, %4438
  %4485 = fmul fast float %4482, %4439
  %4486 = fcmp fast ult float %10, 5.000000e-01
  br i1 %4486, label %4512, label %4487

; <label>:4487                                    ; preds = %4476
  %4488 = fmul fast float %4483, 0x4004147AE0000000
  %4489 = fmul fast float %4484, 0x4004147AE0000000
  %4490 = fmul fast float %4485, 0x4004147AE0000000
  %4491 = fadd fast float %4488, 0x3F9EB851E0000000
  %4492 = fadd fast float %4489, 0x3F9EB851E0000000
  %4493 = fadd fast float %4490, 0x3F9EB851E0000000
  %4494 = fmul fast float %4491, %4483
  %4495 = fmul fast float %4492, %4484
  %4496 = fmul fast float %4493, %4485
  %4497 = fmul fast float %4483, 0x400370A3E0000000
  %4498 = fmul fast float %4484, 0x400370A3E0000000
  %4499 = fmul fast float %4485, 0x400370A3E0000000
  %4500 = fadd fast float %4497, 0x3FE2E147A0000000
  %4501 = fadd fast float %4498, 0x3FE2E147A0000000
  %4502 = fadd fast float %4499, 0x3FE2E147A0000000
  %4503 = fmul fast float %4500, %4483
  %4504 = fmul fast float %4501, %4484
  %4505 = fmul fast float %4502, %4485
  %4506 = fadd fast float %4503, 0x3FC1EB8520000000
  %4507 = fadd fast float %4504, 0x3FC1EB8520000000
  %4508 = fadd fast float %4505, 0x3FC1EB8520000000
  %4509 = fdiv fast float %4494, %4506
  %4510 = fdiv fast float %4495, %4507
  %4511 = fdiv fast float %4496, %4508
  br label %4512

; <label>:4512                                    ; preds = %4487, %4476
  %4513 = phi float [ %4509, %4487 ], [ %4483, %4476 ]
  %4514 = phi float [ %4510, %4487 ], [ %4484, %4476 ]
  %4515 = phi float [ %4511, %4487 ], [ %4485, %4476 ]
  %4516 = call float @dx.op.unary.f32(i32 7, float %4513)  ; Saturate(value)
  %4517 = call float @dx.op.unary.f32(i32 7, float %4514)  ; Saturate(value)
  %4518 = call float @dx.op.unary.f32(i32 7, float %4515)  ; Saturate(value)
  %4519 = call float @dx.op.dot3.f32(i32 55, float %4516, float %4517, float %4518, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4520 = fsub fast float %4516, %4519
  %4521 = fsub fast float %4517, %4519
  %4522 = fsub fast float %4518, %4519
  %4523 = fmul fast float %4520, %8
  %4524 = fmul fast float %4521, %8
  %4525 = fmul fast float %4522, %8
  %4526 = fadd fast float %4523, %4519
  %4527 = fadd fast float %4524, %4519
  %4528 = fadd fast float %4525, %4519
  %4529 = call float @dx.op.unary.f32(i32 7, float %4526)  ; Saturate(value)
  %4530 = call float @dx.op.unary.f32(i32 7, float %4527)  ; Saturate(value)
  %4531 = call float @dx.op.unary.f32(i32 7, float %4528)  ; Saturate(value)
  %4532 = fadd fast float %4529, 0xBFC70A3D80000000
  %4533 = fadd fast float %4530, 0xBFC70A3D80000000
  %4534 = fadd fast float %4531, 0xBFC70A3D80000000
  %4535 = fmul fast float %4532, %7
  %4536 = fmul fast float %4533, %7
  %4537 = fmul fast float %4534, %7
  %4538 = fadd fast float %4535, 0x3FC70A3D80000000
  %4539 = fadd fast float %4536, 0x3FC70A3D80000000
  %4540 = fadd fast float %4537, 0x3FC70A3D80000000
  %4541 = call float @dx.op.unary.f32(i32 7, float %4538)  ; Saturate(value)
  %4542 = call float @dx.op.unary.f32(i32 7, float %4539)  ; Saturate(value)
  %4543 = call float @dx.op.unary.f32(i32 7, float %4540)  ; Saturate(value)
  br label %4544

; <label>:4544                                    ; preds = %4512, %4442
  %4545 = phi float [ %4473, %4442 ], [ %4541, %4512 ]
  %4546 = phi float [ %4474, %4442 ], [ %4542, %4512 ]
  %4547 = phi float [ %4475, %4442 ], [ %4543, %4512 ]
  %4548 = fsub fast float %4545, %3987
  %4549 = fsub fast float %4546, %3988
  %4550 = fsub fast float %4547, %3989
  %4551 = fmul fast float %4548, %4429
  %4552 = fmul fast float %4549, %4429
  %4553 = fmul fast float %4550, %4429
  %4554 = fadd fast float %4551, %3987
  %4555 = fadd fast float %4552, %3988
  %4556 = fadd fast float %4553, %3989
  br label %4557

; <label>:4557                                    ; preds = %4544, %4416
  %4558 = phi float [ %4554, %4544 ], [ %3987, %4416 ]
  %4559 = phi float [ %4555, %4544 ], [ %3988, %4416 ]
  %4560 = phi float [ %4556, %4544 ], [ %3989, %4416 ]
  %4561 = call float @dx.op.binary.f32(i32 36, float %4417, float %4558)  ; FMin(a,b)
  %4562 = call float @dx.op.binary.f32(i32 36, float %4418, float %4559)  ; FMin(a,b)
  %4563 = call float @dx.op.binary.f32(i32 36, float %4419, float %4560)  ; FMin(a,b)
  %4564 = call float @dx.op.binary.f32(i32 36, float %4133, float %4274)  ; FMin(a,b)
  %4565 = call float @dx.op.binary.f32(i32 36, float %4134, float %4275)  ; FMin(a,b)
  %4566 = call float @dx.op.binary.f32(i32 36, float %4135, float %4276)  ; FMin(a,b)
  %4567 = call float @dx.op.binary.f32(i32 36, float %4564, float %4561)  ; FMin(a,b)
  %4568 = call float @dx.op.binary.f32(i32 36, float %4565, float %4562)  ; FMin(a,b)
  %4569 = call float @dx.op.binary.f32(i32 36, float %4566, float %4563)  ; FMin(a,b)
  %4570 = call float @dx.op.binary.f32(i32 36, float %3987, float %4567)  ; FMin(a,b)
  %4571 = call float @dx.op.binary.f32(i32 36, float %3988, float %4568)  ; FMin(a,b)
  %4572 = call float @dx.op.binary.f32(i32 36, float %3989, float %4569)  ; FMin(a,b)
  %4573 = call float @dx.op.binary.f32(i32 35, float %4417, float %4558)  ; FMax(a,b)
  %4574 = call float @dx.op.binary.f32(i32 35, float %4418, float %4559)  ; FMax(a,b)
  %4575 = call float @dx.op.binary.f32(i32 35, float %4419, float %4560)  ; FMax(a,b)
  %4576 = call float @dx.op.binary.f32(i32 35, float %4133, float %4274)  ; FMax(a,b)
  %4577 = call float @dx.op.binary.f32(i32 35, float %4134, float %4275)  ; FMax(a,b)
  %4578 = call float @dx.op.binary.f32(i32 35, float %4135, float %4276)  ; FMax(a,b)
  %4579 = call float @dx.op.binary.f32(i32 35, float %4576, float %4573)  ; FMax(a,b)
  %4580 = call float @dx.op.binary.f32(i32 35, float %4577, float %4574)  ; FMax(a,b)
  %4581 = call float @dx.op.binary.f32(i32 35, float %4578, float %4575)  ; FMax(a,b)
  %4582 = call float @dx.op.binary.f32(i32 35, float %3987, float %4579)  ; FMax(a,b)
  %4583 = call float @dx.op.binary.f32(i32 35, float %3988, float %4580)  ; FMax(a,b)
  %4584 = call float @dx.op.binary.f32(i32 35, float %3989, float %4581)  ; FMax(a,b)
  %4585 = fsub fast float %4582, %4570
  %4586 = fsub fast float %4583, %4571
  %4587 = fsub fast float %4584, %4572
  %4588 = call float @dx.op.unary.f32(i32 6, float %4585)  ; FAbs(value)
  %4589 = call float @dx.op.unary.f32(i32 6, float %4586)  ; FAbs(value)
  %4590 = call float @dx.op.unary.f32(i32 6, float %4587)  ; FAbs(value)
  %4591 = call float @dx.op.binary.f32(i32 35, float %4589, float %4590)  ; FMax(a,b)
  %4592 = call float @dx.op.binary.f32(i32 35, float %4588, float %4591)  ; FMax(a,b)
  %4593 = call float @dx.op.binary.f32(i32 35, float %4583, float %4584)  ; FMax(a,b)
  %4594 = call float @dx.op.binary.f32(i32 35, float %4582, float %4593)  ; FMax(a,b)
  %4595 = fmul fast float %4594, 1.250000e-01
  %4596 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %4595)  ; FMax(a,b)
  %4597 = fcmp fast ogt float %4592, %4596
  br i1 %4597, label %4598, label %4659

; <label>:4598                                    ; preds = %4557
  %4599 = fsub fast float %4133, %4274
  %4600 = fsub fast float %4134, %4275
  %4601 = fsub fast float %4135, %4276
  %4602 = call float @dx.op.unary.f32(i32 6, float %4599)  ; FAbs(value)
  %4603 = call float @dx.op.unary.f32(i32 6, float %4600)  ; FAbs(value)
  %4604 = call float @dx.op.unary.f32(i32 6, float %4601)  ; FAbs(value)
  %4605 = call float @dx.op.binary.f32(i32 35, float %4603, float %4604)  ; FMax(a,b)
  %4606 = call float @dx.op.binary.f32(i32 35, float %4602, float %4605)  ; FMax(a,b)
  %4607 = fsub fast float %4417, %4558
  %4608 = fsub fast float %4418, %4559
  %4609 = fsub fast float %4419, %4560
  %4610 = call float @dx.op.unary.f32(i32 6, float %4607)  ; FAbs(value)
  %4611 = call float @dx.op.unary.f32(i32 6, float %4608)  ; FAbs(value)
  %4612 = call float @dx.op.unary.f32(i32 6, float %4609)  ; FAbs(value)
  %4613 = call float @dx.op.binary.f32(i32 35, float %4611, float %4612)  ; FMax(a,b)
  %4614 = call float @dx.op.binary.f32(i32 35, float %4610, float %4613)  ; FMax(a,b)
  %4615 = fcmp fast olt float %4606, %4614
  %4616 = select i1 %4615, float %4133, float %4417
  %4617 = select i1 %4615, float %4134, float %4418
  %4618 = select i1 %4615, float %4135, float %4419
  %4619 = select i1 %4615, float %4274, float %4558
  %4620 = select i1 %4615, float %4275, float %4559
  %4621 = select i1 %4615, float %4276, float %4560
  %4622 = fsub fast float %3987, %4619
  %4623 = fsub fast float %3988, %4620
  %4624 = fsub fast float %3989, %4621
  %4625 = fsub fast float %3987, %4616
  %4626 = fsub fast float %3988, %4617
  %4627 = fsub fast float %3989, %4618
  %4628 = call float @dx.op.dot3.f32(i32 55, float %4625, float %4626, float %4627, float %4622, float %4623, float %4624)  ; Dot3(ax,ay,az,bx,by,bz)
  %4629 = fcmp fast ogt float %4628, 0.000000e+00
  br i1 %4629, label %4630, label %4641

; <label>:4630                                    ; preds = %4598
  %4631 = fsub fast float %4616, %4619
  %4632 = fsub fast float %4617, %4620
  %4633 = fsub fast float %4618, %4621
  %4634 = call float @dx.op.unary.f32(i32 6, float %4631)  ; FAbs(value)
  %4635 = call float @dx.op.unary.f32(i32 6, float %4632)  ; FAbs(value)
  %4636 = call float @dx.op.unary.f32(i32 6, float %4633)  ; FAbs(value)
  %4637 = call float @dx.op.binary.f32(i32 35, float %4635, float %4636)  ; FMax(a,b)
  %4638 = call float @dx.op.binary.f32(i32 35, float %4634, float %4637)  ; FMax(a,b)
  %4639 = fmul fast float %4592, 2.500000e-01
  %4640 = fcmp fast olt float %4638, %4639
  br label %4641

; <label>:4641                                    ; preds = %4630, %4598
  %4642 = phi i1 [ false, %4598 ], [ %4640, %4630 ]
  %4643 = select i1 %4642, float 0x3FC3333340000000, float 0x3FD3333340000000
  %4644 = fadd fast float %4616, %4619
  %4645 = fadd fast float %4617, %4620
  %4646 = fadd fast float %4618, %4621
  %4647 = fmul fast float %4644, 5.000000e-01
  %4648 = fmul fast float %4645, 5.000000e-01
  %4649 = fmul fast float %4646, 5.000000e-01
  %4650 = fsub fast float %4647, %3987
  %4651 = fsub fast float %4648, %3988
  %4652 = fsub fast float %4649, %3989
  %4653 = fmul fast float %4643, %4650
  %4654 = fmul fast float %4643, %4651
  %4655 = fmul fast float %4643, %4652
  %4656 = fadd fast float %4653, %3987
  %4657 = fadd fast float %4654, %3988
  %4658 = fadd fast float %4655, %3989
  br label %4659

; <label>:4659                                    ; preds = %4641, %4557, %3887
  %4660 = phi float [ %3918, %3887 ], [ %4656, %4641 ], [ %3987, %4557 ]
  %4661 = phi float [ %3919, %3887 ], [ %4657, %4641 ], [ %3988, %4557 ]
  %4662 = phi float [ %3920, %3887 ], [ %4658, %4641 ], [ %3989, %4557 ]
  %4663 = phi float [ %3921, %3887 ], [ %3885, %4641 ], [ %3885, %4557 ]
  %4664 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %38, i32 %41, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4665 = extractvalue %dx.types.ResRet.f32 %4664, 0
  %4666 = extractvalue %dx.types.ResRet.f32 %4664, 1
  %4667 = extractvalue %dx.types.ResRet.f32 %4664, 2
  %4668 = extractvalue %dx.types.ResRet.f32 %4664, 3
  %4669 = fcmp fast olt float %4668, 0.000000e+00
  br i1 %4669, label %4670, label %4705

; <label>:4670                                    ; preds = %4659
  %4671 = fcmp fast ogt float %4665, 0x3FA4B5DCC0000000
  %4672 = fcmp fast ogt float %4666, 0x3FA4B5DCC0000000
  %4673 = fcmp fast ogt float %4667, 0x3FA4B5DCC0000000
  %4674 = select i1 %4671, float 0.000000e+00, float 1.000000e+00
  %4675 = select i1 %4672, float 0.000000e+00, float 1.000000e+00
  %4676 = select i1 %4673, float 0.000000e+00, float 1.000000e+00
  %4677 = fmul fast float %4665, 0x3FB3D07220000000
  %4678 = fmul fast float %4666, 0x3FB3D07220000000
  %4679 = fmul fast float %4667, 0x3FB3D07220000000
  %4680 = fadd fast float %4665, 0x3FAC28F5C0000000
  %4681 = fadd fast float %4666, 0x3FAC28F5C0000000
  %4682 = fadd fast float %4667, 0x3FAC28F5C0000000
  %4683 = fmul fast float %4680, 0x3FEE54EDE0000000
  %4684 = fmul fast float %4681, 0x3FEE54EDE0000000
  %4685 = fmul fast float %4682, 0x3FEE54EDE0000000
  %4686 = call float @dx.op.unary.f32(i32 23, float %4683)  ; Log(value)
  %4687 = call float @dx.op.unary.f32(i32 23, float %4684)  ; Log(value)
  %4688 = call float @dx.op.unary.f32(i32 23, float %4685)  ; Log(value)
  %4689 = fmul fast float %4686, 0x4003333340000000
  %4690 = fmul fast float %4687, 0x4003333340000000
  %4691 = fmul fast float %4688, 0x4003333340000000
  %4692 = call float @dx.op.unary.f32(i32 21, float %4689)  ; Exp(value)
  %4693 = call float @dx.op.unary.f32(i32 21, float %4690)  ; Exp(value)
  %4694 = call float @dx.op.unary.f32(i32 21, float %4691)  ; Exp(value)
  %4695 = fsub fast float %4677, %4692
  %4696 = fsub fast float %4678, %4693
  %4697 = fsub fast float %4679, %4694
  %4698 = fmul fast float %4695, %4674
  %4699 = fmul fast float %4696, %4675
  %4700 = fmul fast float %4697, %4676
  %4701 = fadd fast float %4698, %4692
  %4702 = fadd fast float %4699, %4693
  %4703 = fadd fast float %4700, %4694
  %4704 = fsub fast float -1.000000e+00, %4668
  br label %5442

; <label>:4705                                    ; preds = %4659
  %4706 = fadd fast float %5, 1.000000e+00
  %4707 = fadd fast float %6, 1.000000e+00
  %4708 = fsub fast float 1.000000e+00, %5
  %4709 = fmul fast float %9, %4706
  %4710 = fmul fast float %9, %4707
  %4711 = fmul fast float %9, %4708
  %4712 = fmul fast float %4709, %4665
  %4713 = fmul fast float %4710, %4666
  %4714 = fmul fast float %4711, %4667
  %4715 = fcmp fast ult float %10, 5.000000e-01
  br i1 %4715, label %4741, label %4716

; <label>:4716                                    ; preds = %4705
  %4717 = fmul fast float %4712, 0x4004147AE0000000
  %4718 = fmul fast float %4713, 0x4004147AE0000000
  %4719 = fmul fast float %4714, 0x4004147AE0000000
  %4720 = fadd fast float %4717, 0x3F9EB851E0000000
  %4721 = fadd fast float %4718, 0x3F9EB851E0000000
  %4722 = fadd fast float %4719, 0x3F9EB851E0000000
  %4723 = fmul fast float %4720, %4712
  %4724 = fmul fast float %4721, %4713
  %4725 = fmul fast float %4722, %4714
  %4726 = fmul fast float %4712, 0x400370A3E0000000
  %4727 = fmul fast float %4713, 0x400370A3E0000000
  %4728 = fmul fast float %4714, 0x400370A3E0000000
  %4729 = fadd fast float %4726, 0x3FE2E147A0000000
  %4730 = fadd fast float %4727, 0x3FE2E147A0000000
  %4731 = fadd fast float %4728, 0x3FE2E147A0000000
  %4732 = fmul fast float %4729, %4712
  %4733 = fmul fast float %4730, %4713
  %4734 = fmul fast float %4731, %4714
  %4735 = fadd fast float %4732, 0x3FC1EB8520000000
  %4736 = fadd fast float %4733, 0x3FC1EB8520000000
  %4737 = fadd fast float %4734, 0x3FC1EB8520000000
  %4738 = fdiv fast float %4723, %4735
  %4739 = fdiv fast float %4724, %4736
  %4740 = fdiv fast float %4725, %4737
  br label %4741

; <label>:4741                                    ; preds = %4716, %4705
  %4742 = phi float [ %4738, %4716 ], [ %4712, %4705 ]
  %4743 = phi float [ %4739, %4716 ], [ %4713, %4705 ]
  %4744 = phi float [ %4740, %4716 ], [ %4714, %4705 ]
  %4745 = call float @dx.op.unary.f32(i32 7, float %4742)  ; Saturate(value)
  %4746 = call float @dx.op.unary.f32(i32 7, float %4743)  ; Saturate(value)
  %4747 = call float @dx.op.unary.f32(i32 7, float %4744)  ; Saturate(value)
  %4748 = call float @dx.op.dot3.f32(i32 55, float %4745, float %4746, float %4747, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4749 = fsub fast float %4745, %4748
  %4750 = fsub fast float %4746, %4748
  %4751 = fsub fast float %4747, %4748
  %4752 = fmul fast float %4749, %8
  %4753 = fmul fast float %4750, %8
  %4754 = fmul fast float %4751, %8
  %4755 = fadd fast float %4752, %4748
  %4756 = fadd fast float %4753, %4748
  %4757 = fadd fast float %4754, %4748
  %4758 = call float @dx.op.unary.f32(i32 7, float %4755)  ; Saturate(value)
  %4759 = call float @dx.op.unary.f32(i32 7, float %4756)  ; Saturate(value)
  %4760 = call float @dx.op.unary.f32(i32 7, float %4757)  ; Saturate(value)
  %4761 = fadd fast float %4758, 0xBFC70A3D80000000
  %4762 = fadd fast float %4759, 0xBFC70A3D80000000
  %4763 = fadd fast float %4760, 0xBFC70A3D80000000
  %4764 = fmul fast float %4761, %7
  %4765 = fmul fast float %4762, %7
  %4766 = fmul fast float %4763, %7
  %4767 = fadd fast float %4764, 0x3FC70A3D80000000
  %4768 = fadd fast float %4765, 0x3FC70A3D80000000
  %4769 = fadd fast float %4766, 0x3FC70A3D80000000
  %4770 = call float @dx.op.unary.f32(i32 7, float %4767)  ; Saturate(value)
  %4771 = call float @dx.op.unary.f32(i32 7, float %4768)  ; Saturate(value)
  %4772 = call float @dx.op.unary.f32(i32 7, float %4769)  ; Saturate(value)
  %4773 = add i32 %41, -1
  %4774 = call i32 @dx.op.binary.i32(i32 37, i32 %38, i32 0)  ; IMax(a,b)
  %4775 = call i32 @dx.op.binary.i32(i32 37, i32 %4773, i32 0)  ; IMax(a,b)
  %4776 = call i32 @dx.op.binary.i32(i32 38, i32 %4774, i32 %30)  ; IMin(a,b)
  %4777 = call i32 @dx.op.binary.i32(i32 38, i32 %4775, i32 %31)  ; IMin(a,b)
  %4778 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4776, i32 %4777, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4779 = extractvalue %dx.types.ResRet.f32 %4778, 0
  %4780 = fsub fast float 1.000000e+00, %59
  %4781 = fmul fast float %4780, 0x3FA99999A0000000
  %4782 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %4781)  ; FMax(a,b)
  %4783 = fsub fast float %4779, %59
  %4784 = call float @dx.op.unary.f32(i32 6, float %4783)  ; FAbs(value)
  %4785 = fdiv fast float %4784, %4782
  %4786 = fsub fast float 1.000000e+00, %4785
  %4787 = call float @dx.op.unary.f32(i32 7, float %4786)  ; Saturate(value)
  %4788 = fcmp fast ugt float %4787, 0.000000e+00
  br i1 %4788, label %4789, label %4915

; <label>:4789                                    ; preds = %4741
  %4790 = call i32 @dx.op.binary.i32(i32 37, i32 %4776, i32 0)  ; IMax(a,b)
  %4791 = call i32 @dx.op.binary.i32(i32 37, i32 %4777, i32 0)  ; IMax(a,b)
  %4792 = call i32 @dx.op.binary.i32(i32 38, i32 %4790, i32 %30)  ; IMin(a,b)
  %4793 = call i32 @dx.op.binary.i32(i32 38, i32 %4791, i32 %31)  ; IMin(a,b)
  %4794 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4792, i32 %4793, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4795 = extractvalue %dx.types.ResRet.f32 %4794, 0
  %4796 = extractvalue %dx.types.ResRet.f32 %4794, 1
  %4797 = extractvalue %dx.types.ResRet.f32 %4794, 2
  %4798 = extractvalue %dx.types.ResRet.f32 %4794, 3
  %4799 = fcmp fast olt float %4798, 0.000000e+00
  br i1 %4799, label %4800, label %4834

; <label>:4800                                    ; preds = %4789
  %4801 = fcmp fast ogt float %4795, 0x3FA4B5DCC0000000
  %4802 = fcmp fast ogt float %4796, 0x3FA4B5DCC0000000
  %4803 = fcmp fast ogt float %4797, 0x3FA4B5DCC0000000
  %4804 = select i1 %4801, float 0.000000e+00, float 1.000000e+00
  %4805 = select i1 %4802, float 0.000000e+00, float 1.000000e+00
  %4806 = select i1 %4803, float 0.000000e+00, float 1.000000e+00
  %4807 = fmul fast float %4795, 0x3FB3D07220000000
  %4808 = fmul fast float %4796, 0x3FB3D07220000000
  %4809 = fmul fast float %4797, 0x3FB3D07220000000
  %4810 = fadd fast float %4795, 0x3FAC28F5C0000000
  %4811 = fadd fast float %4796, 0x3FAC28F5C0000000
  %4812 = fadd fast float %4797, 0x3FAC28F5C0000000
  %4813 = fmul fast float %4810, 0x3FEE54EDE0000000
  %4814 = fmul fast float %4811, 0x3FEE54EDE0000000
  %4815 = fmul fast float %4812, 0x3FEE54EDE0000000
  %4816 = call float @dx.op.unary.f32(i32 23, float %4813)  ; Log(value)
  %4817 = call float @dx.op.unary.f32(i32 23, float %4814)  ; Log(value)
  %4818 = call float @dx.op.unary.f32(i32 23, float %4815)  ; Log(value)
  %4819 = fmul fast float %4816, 0x4003333340000000
  %4820 = fmul fast float %4817, 0x4003333340000000
  %4821 = fmul fast float %4818, 0x4003333340000000
  %4822 = call float @dx.op.unary.f32(i32 21, float %4819)  ; Exp(value)
  %4823 = call float @dx.op.unary.f32(i32 21, float %4820)  ; Exp(value)
  %4824 = call float @dx.op.unary.f32(i32 21, float %4821)  ; Exp(value)
  %4825 = fsub fast float %4807, %4822
  %4826 = fsub fast float %4808, %4823
  %4827 = fsub fast float %4809, %4824
  %4828 = fmul fast float %4825, %4804
  %4829 = fmul fast float %4826, %4805
  %4830 = fmul fast float %4827, %4806
  %4831 = fadd fast float %4828, %4822
  %4832 = fadd fast float %4829, %4823
  %4833 = fadd fast float %4830, %4824
  br label %4902

; <label>:4834                                    ; preds = %4789
  %4835 = fadd fast float %5, 1.000000e+00
  %4836 = fadd fast float %6, 1.000000e+00
  %4837 = fsub fast float 1.000000e+00, %5
  %4838 = fmul fast float %9, %4835
  %4839 = fmul fast float %9, %4836
  %4840 = fmul fast float %9, %4837
  %4841 = fmul fast float %4838, %4795
  %4842 = fmul fast float %4839, %4796
  %4843 = fmul fast float %4840, %4797
  %4844 = fcmp fast ult float %10, 5.000000e-01
  br i1 %4844, label %4870, label %4845

; <label>:4845                                    ; preds = %4834
  %4846 = fmul fast float %4841, 0x4004147AE0000000
  %4847 = fmul fast float %4842, 0x4004147AE0000000
  %4848 = fmul fast float %4843, 0x4004147AE0000000
  %4849 = fadd fast float %4846, 0x3F9EB851E0000000
  %4850 = fadd fast float %4847, 0x3F9EB851E0000000
  %4851 = fadd fast float %4848, 0x3F9EB851E0000000
  %4852 = fmul fast float %4849, %4841
  %4853 = fmul fast float %4850, %4842
  %4854 = fmul fast float %4851, %4843
  %4855 = fmul fast float %4841, 0x400370A3E0000000
  %4856 = fmul fast float %4842, 0x400370A3E0000000
  %4857 = fmul fast float %4843, 0x400370A3E0000000
  %4858 = fadd fast float %4855, 0x3FE2E147A0000000
  %4859 = fadd fast float %4856, 0x3FE2E147A0000000
  %4860 = fadd fast float %4857, 0x3FE2E147A0000000
  %4861 = fmul fast float %4858, %4841
  %4862 = fmul fast float %4859, %4842
  %4863 = fmul fast float %4860, %4843
  %4864 = fadd fast float %4861, 0x3FC1EB8520000000
  %4865 = fadd fast float %4862, 0x3FC1EB8520000000
  %4866 = fadd fast float %4863, 0x3FC1EB8520000000
  %4867 = fdiv fast float %4852, %4864
  %4868 = fdiv fast float %4853, %4865
  %4869 = fdiv fast float %4854, %4866
  br label %4870

; <label>:4870                                    ; preds = %4845, %4834
  %4871 = phi float [ %4867, %4845 ], [ %4841, %4834 ]
  %4872 = phi float [ %4868, %4845 ], [ %4842, %4834 ]
  %4873 = phi float [ %4869, %4845 ], [ %4843, %4834 ]
  %4874 = call float @dx.op.unary.f32(i32 7, float %4871)  ; Saturate(value)
  %4875 = call float @dx.op.unary.f32(i32 7, float %4872)  ; Saturate(value)
  %4876 = call float @dx.op.unary.f32(i32 7, float %4873)  ; Saturate(value)
  %4877 = call float @dx.op.dot3.f32(i32 55, float %4874, float %4875, float %4876, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4878 = fsub fast float %4874, %4877
  %4879 = fsub fast float %4875, %4877
  %4880 = fsub fast float %4876, %4877
  %4881 = fmul fast float %4878, %8
  %4882 = fmul fast float %4879, %8
  %4883 = fmul fast float %4880, %8
  %4884 = fadd fast float %4881, %4877
  %4885 = fadd fast float %4882, %4877
  %4886 = fadd fast float %4883, %4877
  %4887 = call float @dx.op.unary.f32(i32 7, float %4884)  ; Saturate(value)
  %4888 = call float @dx.op.unary.f32(i32 7, float %4885)  ; Saturate(value)
  %4889 = call float @dx.op.unary.f32(i32 7, float %4886)  ; Saturate(value)
  %4890 = fadd fast float %4887, 0xBFC70A3D80000000
  %4891 = fadd fast float %4888, 0xBFC70A3D80000000
  %4892 = fadd fast float %4889, 0xBFC70A3D80000000
  %4893 = fmul fast float %4890, %7
  %4894 = fmul fast float %4891, %7
  %4895 = fmul fast float %4892, %7
  %4896 = fadd fast float %4893, 0x3FC70A3D80000000
  %4897 = fadd fast float %4894, 0x3FC70A3D80000000
  %4898 = fadd fast float %4895, 0x3FC70A3D80000000
  %4899 = call float @dx.op.unary.f32(i32 7, float %4896)  ; Saturate(value)
  %4900 = call float @dx.op.unary.f32(i32 7, float %4897)  ; Saturate(value)
  %4901 = call float @dx.op.unary.f32(i32 7, float %4898)  ; Saturate(value)
  br label %4902

; <label>:4902                                    ; preds = %4870, %4800
  %4903 = phi float [ %4831, %4800 ], [ %4899, %4870 ]
  %4904 = phi float [ %4832, %4800 ], [ %4900, %4870 ]
  %4905 = phi float [ %4833, %4800 ], [ %4901, %4870 ]
  %4906 = fsub fast float %4903, %4770
  %4907 = fsub fast float %4904, %4771
  %4908 = fsub fast float %4905, %4772
  %4909 = fmul fast float %4906, %4787
  %4910 = fmul fast float %4907, %4787
  %4911 = fmul fast float %4908, %4787
  %4912 = fadd fast float %4909, %4770
  %4913 = fadd fast float %4910, %4771
  %4914 = fadd fast float %4911, %4772
  br label %4915

; <label>:4915                                    ; preds = %4902, %4741
  %4916 = phi float [ %4912, %4902 ], [ %4770, %4741 ]
  %4917 = phi float [ %4913, %4902 ], [ %4771, %4741 ]
  %4918 = phi float [ %4914, %4902 ], [ %4772, %4741 ]
  %4919 = add i32 %41, 1
  %4920 = call i32 @dx.op.binary.i32(i32 37, i32 %4919, i32 0)  ; IMax(a,b)
  %4921 = call i32 @dx.op.binary.i32(i32 38, i32 %4920, i32 %31)  ; IMin(a,b)
  %4922 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4776, i32 %4921, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4923 = extractvalue %dx.types.ResRet.f32 %4922, 0
  %4924 = fsub fast float %4923, %59
  %4925 = call float @dx.op.unary.f32(i32 6, float %4924)  ; FAbs(value)
  %4926 = fdiv fast float %4925, %4782
  %4927 = fsub fast float 1.000000e+00, %4926
  %4928 = call float @dx.op.unary.f32(i32 7, float %4927)  ; Saturate(value)
  %4929 = fcmp fast ugt float %4928, 0.000000e+00
  br i1 %4929, label %4930, label %5056

; <label>:4930                                    ; preds = %4915
  %4931 = call i32 @dx.op.binary.i32(i32 37, i32 %4776, i32 0)  ; IMax(a,b)
  %4932 = call i32 @dx.op.binary.i32(i32 37, i32 %4921, i32 0)  ; IMax(a,b)
  %4933 = call i32 @dx.op.binary.i32(i32 38, i32 %4931, i32 %30)  ; IMin(a,b)
  %4934 = call i32 @dx.op.binary.i32(i32 38, i32 %4932, i32 %31)  ; IMin(a,b)
  %4935 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4933, i32 %4934, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4936 = extractvalue %dx.types.ResRet.f32 %4935, 0
  %4937 = extractvalue %dx.types.ResRet.f32 %4935, 1
  %4938 = extractvalue %dx.types.ResRet.f32 %4935, 2
  %4939 = extractvalue %dx.types.ResRet.f32 %4935, 3
  %4940 = fcmp fast olt float %4939, 0.000000e+00
  br i1 %4940, label %4941, label %4975

; <label>:4941                                    ; preds = %4930
  %4942 = fcmp fast ogt float %4936, 0x3FA4B5DCC0000000
  %4943 = fcmp fast ogt float %4937, 0x3FA4B5DCC0000000
  %4944 = fcmp fast ogt float %4938, 0x3FA4B5DCC0000000
  %4945 = select i1 %4942, float 0.000000e+00, float 1.000000e+00
  %4946 = select i1 %4943, float 0.000000e+00, float 1.000000e+00
  %4947 = select i1 %4944, float 0.000000e+00, float 1.000000e+00
  %4948 = fmul fast float %4936, 0x3FB3D07220000000
  %4949 = fmul fast float %4937, 0x3FB3D07220000000
  %4950 = fmul fast float %4938, 0x3FB3D07220000000
  %4951 = fadd fast float %4936, 0x3FAC28F5C0000000
  %4952 = fadd fast float %4937, 0x3FAC28F5C0000000
  %4953 = fadd fast float %4938, 0x3FAC28F5C0000000
  %4954 = fmul fast float %4951, 0x3FEE54EDE0000000
  %4955 = fmul fast float %4952, 0x3FEE54EDE0000000
  %4956 = fmul fast float %4953, 0x3FEE54EDE0000000
  %4957 = call float @dx.op.unary.f32(i32 23, float %4954)  ; Log(value)
  %4958 = call float @dx.op.unary.f32(i32 23, float %4955)  ; Log(value)
  %4959 = call float @dx.op.unary.f32(i32 23, float %4956)  ; Log(value)
  %4960 = fmul fast float %4957, 0x4003333340000000
  %4961 = fmul fast float %4958, 0x4003333340000000
  %4962 = fmul fast float %4959, 0x4003333340000000
  %4963 = call float @dx.op.unary.f32(i32 21, float %4960)  ; Exp(value)
  %4964 = call float @dx.op.unary.f32(i32 21, float %4961)  ; Exp(value)
  %4965 = call float @dx.op.unary.f32(i32 21, float %4962)  ; Exp(value)
  %4966 = fsub fast float %4948, %4963
  %4967 = fsub fast float %4949, %4964
  %4968 = fsub fast float %4950, %4965
  %4969 = fmul fast float %4966, %4945
  %4970 = fmul fast float %4967, %4946
  %4971 = fmul fast float %4968, %4947
  %4972 = fadd fast float %4969, %4963
  %4973 = fadd fast float %4970, %4964
  %4974 = fadd fast float %4971, %4965
  br label %5043

; <label>:4975                                    ; preds = %4930
  %4976 = fadd fast float %5, 1.000000e+00
  %4977 = fadd fast float %6, 1.000000e+00
  %4978 = fsub fast float 1.000000e+00, %5
  %4979 = fmul fast float %9, %4976
  %4980 = fmul fast float %9, %4977
  %4981 = fmul fast float %9, %4978
  %4982 = fmul fast float %4979, %4936
  %4983 = fmul fast float %4980, %4937
  %4984 = fmul fast float %4981, %4938
  %4985 = fcmp fast ult float %10, 5.000000e-01
  br i1 %4985, label %5011, label %4986

; <label>:4986                                    ; preds = %4975
  %4987 = fmul fast float %4982, 0x4004147AE0000000
  %4988 = fmul fast float %4983, 0x4004147AE0000000
  %4989 = fmul fast float %4984, 0x4004147AE0000000
  %4990 = fadd fast float %4987, 0x3F9EB851E0000000
  %4991 = fadd fast float %4988, 0x3F9EB851E0000000
  %4992 = fadd fast float %4989, 0x3F9EB851E0000000
  %4993 = fmul fast float %4990, %4982
  %4994 = fmul fast float %4991, %4983
  %4995 = fmul fast float %4992, %4984
  %4996 = fmul fast float %4982, 0x400370A3E0000000
  %4997 = fmul fast float %4983, 0x400370A3E0000000
  %4998 = fmul fast float %4984, 0x400370A3E0000000
  %4999 = fadd fast float %4996, 0x3FE2E147A0000000
  %5000 = fadd fast float %4997, 0x3FE2E147A0000000
  %5001 = fadd fast float %4998, 0x3FE2E147A0000000
  %5002 = fmul fast float %4999, %4982
  %5003 = fmul fast float %5000, %4983
  %5004 = fmul fast float %5001, %4984
  %5005 = fadd fast float %5002, 0x3FC1EB8520000000
  %5006 = fadd fast float %5003, 0x3FC1EB8520000000
  %5007 = fadd fast float %5004, 0x3FC1EB8520000000
  %5008 = fdiv fast float %4993, %5005
  %5009 = fdiv fast float %4994, %5006
  %5010 = fdiv fast float %4995, %5007
  br label %5011

; <label>:5011                                    ; preds = %4986, %4975
  %5012 = phi float [ %5008, %4986 ], [ %4982, %4975 ]
  %5013 = phi float [ %5009, %4986 ], [ %4983, %4975 ]
  %5014 = phi float [ %5010, %4986 ], [ %4984, %4975 ]
  %5015 = call float @dx.op.unary.f32(i32 7, float %5012)  ; Saturate(value)
  %5016 = call float @dx.op.unary.f32(i32 7, float %5013)  ; Saturate(value)
  %5017 = call float @dx.op.unary.f32(i32 7, float %5014)  ; Saturate(value)
  %5018 = call float @dx.op.dot3.f32(i32 55, float %5015, float %5016, float %5017, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5019 = fsub fast float %5015, %5018
  %5020 = fsub fast float %5016, %5018
  %5021 = fsub fast float %5017, %5018
  %5022 = fmul fast float %5019, %8
  %5023 = fmul fast float %5020, %8
  %5024 = fmul fast float %5021, %8
  %5025 = fadd fast float %5022, %5018
  %5026 = fadd fast float %5023, %5018
  %5027 = fadd fast float %5024, %5018
  %5028 = call float @dx.op.unary.f32(i32 7, float %5025)  ; Saturate(value)
  %5029 = call float @dx.op.unary.f32(i32 7, float %5026)  ; Saturate(value)
  %5030 = call float @dx.op.unary.f32(i32 7, float %5027)  ; Saturate(value)
  %5031 = fadd fast float %5028, 0xBFC70A3D80000000
  %5032 = fadd fast float %5029, 0xBFC70A3D80000000
  %5033 = fadd fast float %5030, 0xBFC70A3D80000000
  %5034 = fmul fast float %5031, %7
  %5035 = fmul fast float %5032, %7
  %5036 = fmul fast float %5033, %7
  %5037 = fadd fast float %5034, 0x3FC70A3D80000000
  %5038 = fadd fast float %5035, 0x3FC70A3D80000000
  %5039 = fadd fast float %5036, 0x3FC70A3D80000000
  %5040 = call float @dx.op.unary.f32(i32 7, float %5037)  ; Saturate(value)
  %5041 = call float @dx.op.unary.f32(i32 7, float %5038)  ; Saturate(value)
  %5042 = call float @dx.op.unary.f32(i32 7, float %5039)  ; Saturate(value)
  br label %5043

; <label>:5043                                    ; preds = %5011, %4941
  %5044 = phi float [ %4972, %4941 ], [ %5040, %5011 ]
  %5045 = phi float [ %4973, %4941 ], [ %5041, %5011 ]
  %5046 = phi float [ %4974, %4941 ], [ %5042, %5011 ]
  %5047 = fsub fast float %5044, %4770
  %5048 = fsub fast float %5045, %4771
  %5049 = fsub fast float %5046, %4772
  %5050 = fmul fast float %5047, %4928
  %5051 = fmul fast float %5048, %4928
  %5052 = fmul fast float %5049, %4928
  %5053 = fadd fast float %5050, %4770
  %5054 = fadd fast float %5051, %4771
  %5055 = fadd fast float %5052, %4772
  br label %5056

; <label>:5056                                    ; preds = %5043, %4915
  %5057 = phi float [ %5053, %5043 ], [ %4770, %4915 ]
  %5058 = phi float [ %5054, %5043 ], [ %4771, %4915 ]
  %5059 = phi float [ %5055, %5043 ], [ %4772, %4915 ]
  %5060 = add i32 %38, -1
  %5061 = call i32 @dx.op.binary.i32(i32 37, i32 %5060, i32 0)  ; IMax(a,b)
  %5062 = call i32 @dx.op.binary.i32(i32 37, i32 %41, i32 0)  ; IMax(a,b)
  %5063 = call i32 @dx.op.binary.i32(i32 38, i32 %5061, i32 %30)  ; IMin(a,b)
  %5064 = call i32 @dx.op.binary.i32(i32 38, i32 %5062, i32 %31)  ; IMin(a,b)
  %5065 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5063, i32 %5064, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5066 = extractvalue %dx.types.ResRet.f32 %5065, 0
  %5067 = fsub fast float %5066, %59
  %5068 = call float @dx.op.unary.f32(i32 6, float %5067)  ; FAbs(value)
  %5069 = fdiv fast float %5068, %4782
  %5070 = fsub fast float 1.000000e+00, %5069
  %5071 = call float @dx.op.unary.f32(i32 7, float %5070)  ; Saturate(value)
  %5072 = fcmp fast ugt float %5071, 0.000000e+00
  br i1 %5072, label %5073, label %5199

; <label>:5073                                    ; preds = %5056
  %5074 = call i32 @dx.op.binary.i32(i32 37, i32 %5063, i32 0)  ; IMax(a,b)
  %5075 = call i32 @dx.op.binary.i32(i32 37, i32 %5064, i32 0)  ; IMax(a,b)
  %5076 = call i32 @dx.op.binary.i32(i32 38, i32 %5074, i32 %30)  ; IMin(a,b)
  %5077 = call i32 @dx.op.binary.i32(i32 38, i32 %5075, i32 %31)  ; IMin(a,b)
  %5078 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %5076, i32 %5077, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5079 = extractvalue %dx.types.ResRet.f32 %5078, 0
  %5080 = extractvalue %dx.types.ResRet.f32 %5078, 1
  %5081 = extractvalue %dx.types.ResRet.f32 %5078, 2
  %5082 = extractvalue %dx.types.ResRet.f32 %5078, 3
  %5083 = fcmp fast olt float %5082, 0.000000e+00
  br i1 %5083, label %5084, label %5118

; <label>:5084                                    ; preds = %5073
  %5085 = fcmp fast ogt float %5079, 0x3FA4B5DCC0000000
  %5086 = fcmp fast ogt float %5080, 0x3FA4B5DCC0000000
  %5087 = fcmp fast ogt float %5081, 0x3FA4B5DCC0000000
  %5088 = select i1 %5085, float 0.000000e+00, float 1.000000e+00
  %5089 = select i1 %5086, float 0.000000e+00, float 1.000000e+00
  %5090 = select i1 %5087, float 0.000000e+00, float 1.000000e+00
  %5091 = fmul fast float %5079, 0x3FB3D07220000000
  %5092 = fmul fast float %5080, 0x3FB3D07220000000
  %5093 = fmul fast float %5081, 0x3FB3D07220000000
  %5094 = fadd fast float %5079, 0x3FAC28F5C0000000
  %5095 = fadd fast float %5080, 0x3FAC28F5C0000000
  %5096 = fadd fast float %5081, 0x3FAC28F5C0000000
  %5097 = fmul fast float %5094, 0x3FEE54EDE0000000
  %5098 = fmul fast float %5095, 0x3FEE54EDE0000000
  %5099 = fmul fast float %5096, 0x3FEE54EDE0000000
  %5100 = call float @dx.op.unary.f32(i32 23, float %5097)  ; Log(value)
  %5101 = call float @dx.op.unary.f32(i32 23, float %5098)  ; Log(value)
  %5102 = call float @dx.op.unary.f32(i32 23, float %5099)  ; Log(value)
  %5103 = fmul fast float %5100, 0x4003333340000000
  %5104 = fmul fast float %5101, 0x4003333340000000
  %5105 = fmul fast float %5102, 0x4003333340000000
  %5106 = call float @dx.op.unary.f32(i32 21, float %5103)  ; Exp(value)
  %5107 = call float @dx.op.unary.f32(i32 21, float %5104)  ; Exp(value)
  %5108 = call float @dx.op.unary.f32(i32 21, float %5105)  ; Exp(value)
  %5109 = fsub fast float %5091, %5106
  %5110 = fsub fast float %5092, %5107
  %5111 = fsub fast float %5093, %5108
  %5112 = fmul fast float %5109, %5088
  %5113 = fmul fast float %5110, %5089
  %5114 = fmul fast float %5111, %5090
  %5115 = fadd fast float %5112, %5106
  %5116 = fadd fast float %5113, %5107
  %5117 = fadd fast float %5114, %5108
  br label %5186

; <label>:5118                                    ; preds = %5073
  %5119 = fadd fast float %5, 1.000000e+00
  %5120 = fadd fast float %6, 1.000000e+00
  %5121 = fsub fast float 1.000000e+00, %5
  %5122 = fmul fast float %9, %5119
  %5123 = fmul fast float %9, %5120
  %5124 = fmul fast float %9, %5121
  %5125 = fmul fast float %5122, %5079
  %5126 = fmul fast float %5123, %5080
  %5127 = fmul fast float %5124, %5081
  %5128 = fcmp fast ult float %10, 5.000000e-01
  br i1 %5128, label %5154, label %5129

; <label>:5129                                    ; preds = %5118
  %5130 = fmul fast float %5125, 0x4004147AE0000000
  %5131 = fmul fast float %5126, 0x4004147AE0000000
  %5132 = fmul fast float %5127, 0x4004147AE0000000
  %5133 = fadd fast float %5130, 0x3F9EB851E0000000
  %5134 = fadd fast float %5131, 0x3F9EB851E0000000
  %5135 = fadd fast float %5132, 0x3F9EB851E0000000
  %5136 = fmul fast float %5133, %5125
  %5137 = fmul fast float %5134, %5126
  %5138 = fmul fast float %5135, %5127
  %5139 = fmul fast float %5125, 0x400370A3E0000000
  %5140 = fmul fast float %5126, 0x400370A3E0000000
  %5141 = fmul fast float %5127, 0x400370A3E0000000
  %5142 = fadd fast float %5139, 0x3FE2E147A0000000
  %5143 = fadd fast float %5140, 0x3FE2E147A0000000
  %5144 = fadd fast float %5141, 0x3FE2E147A0000000
  %5145 = fmul fast float %5142, %5125
  %5146 = fmul fast float %5143, %5126
  %5147 = fmul fast float %5144, %5127
  %5148 = fadd fast float %5145, 0x3FC1EB8520000000
  %5149 = fadd fast float %5146, 0x3FC1EB8520000000
  %5150 = fadd fast float %5147, 0x3FC1EB8520000000
  %5151 = fdiv fast float %5136, %5148
  %5152 = fdiv fast float %5137, %5149
  %5153 = fdiv fast float %5138, %5150
  br label %5154

; <label>:5154                                    ; preds = %5129, %5118
  %5155 = phi float [ %5151, %5129 ], [ %5125, %5118 ]
  %5156 = phi float [ %5152, %5129 ], [ %5126, %5118 ]
  %5157 = phi float [ %5153, %5129 ], [ %5127, %5118 ]
  %5158 = call float @dx.op.unary.f32(i32 7, float %5155)  ; Saturate(value)
  %5159 = call float @dx.op.unary.f32(i32 7, float %5156)  ; Saturate(value)
  %5160 = call float @dx.op.unary.f32(i32 7, float %5157)  ; Saturate(value)
  %5161 = call float @dx.op.dot3.f32(i32 55, float %5158, float %5159, float %5160, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5162 = fsub fast float %5158, %5161
  %5163 = fsub fast float %5159, %5161
  %5164 = fsub fast float %5160, %5161
  %5165 = fmul fast float %5162, %8
  %5166 = fmul fast float %5163, %8
  %5167 = fmul fast float %5164, %8
  %5168 = fadd fast float %5165, %5161
  %5169 = fadd fast float %5166, %5161
  %5170 = fadd fast float %5167, %5161
  %5171 = call float @dx.op.unary.f32(i32 7, float %5168)  ; Saturate(value)
  %5172 = call float @dx.op.unary.f32(i32 7, float %5169)  ; Saturate(value)
  %5173 = call float @dx.op.unary.f32(i32 7, float %5170)  ; Saturate(value)
  %5174 = fadd fast float %5171, 0xBFC70A3D80000000
  %5175 = fadd fast float %5172, 0xBFC70A3D80000000
  %5176 = fadd fast float %5173, 0xBFC70A3D80000000
  %5177 = fmul fast float %5174, %7
  %5178 = fmul fast float %5175, %7
  %5179 = fmul fast float %5176, %7
  %5180 = fadd fast float %5177, 0x3FC70A3D80000000
  %5181 = fadd fast float %5178, 0x3FC70A3D80000000
  %5182 = fadd fast float %5179, 0x3FC70A3D80000000
  %5183 = call float @dx.op.unary.f32(i32 7, float %5180)  ; Saturate(value)
  %5184 = call float @dx.op.unary.f32(i32 7, float %5181)  ; Saturate(value)
  %5185 = call float @dx.op.unary.f32(i32 7, float %5182)  ; Saturate(value)
  br label %5186

; <label>:5186                                    ; preds = %5154, %5084
  %5187 = phi float [ %5115, %5084 ], [ %5183, %5154 ]
  %5188 = phi float [ %5116, %5084 ], [ %5184, %5154 ]
  %5189 = phi float [ %5117, %5084 ], [ %5185, %5154 ]
  %5190 = fsub fast float %5187, %4770
  %5191 = fsub fast float %5188, %4771
  %5192 = fsub fast float %5189, %4772
  %5193 = fmul fast float %5190, %5071
  %5194 = fmul fast float %5191, %5071
  %5195 = fmul fast float %5192, %5071
  %5196 = fadd fast float %5193, %4770
  %5197 = fadd fast float %5194, %4771
  %5198 = fadd fast float %5195, %4772
  br label %5199

; <label>:5199                                    ; preds = %5186, %5056
  %5200 = phi float [ %5196, %5186 ], [ %4770, %5056 ]
  %5201 = phi float [ %5197, %5186 ], [ %4771, %5056 ]
  %5202 = phi float [ %5198, %5186 ], [ %4772, %5056 ]
  %5203 = add i32 %38, 1
  %5204 = call i32 @dx.op.binary.i32(i32 37, i32 %5203, i32 0)  ; IMax(a,b)
  %5205 = call i32 @dx.op.binary.i32(i32 38, i32 %5204, i32 %30)  ; IMin(a,b)
  %5206 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5205, i32 %5064, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5207 = extractvalue %dx.types.ResRet.f32 %5206, 0
  %5208 = fsub fast float %5207, %59
  %5209 = call float @dx.op.unary.f32(i32 6, float %5208)  ; FAbs(value)
  %5210 = fdiv fast float %5209, %4782
  %5211 = fsub fast float 1.000000e+00, %5210
  %5212 = call float @dx.op.unary.f32(i32 7, float %5211)  ; Saturate(value)
  %5213 = fcmp fast ugt float %5212, 0.000000e+00
  br i1 %5213, label %5214, label %5340

; <label>:5214                                    ; preds = %5199
  %5215 = call i32 @dx.op.binary.i32(i32 37, i32 %5205, i32 0)  ; IMax(a,b)
  %5216 = call i32 @dx.op.binary.i32(i32 37, i32 %5064, i32 0)  ; IMax(a,b)
  %5217 = call i32 @dx.op.binary.i32(i32 38, i32 %5215, i32 %30)  ; IMin(a,b)
  %5218 = call i32 @dx.op.binary.i32(i32 38, i32 %5216, i32 %31)  ; IMin(a,b)
  %5219 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %5217, i32 %5218, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5220 = extractvalue %dx.types.ResRet.f32 %5219, 0
  %5221 = extractvalue %dx.types.ResRet.f32 %5219, 1
  %5222 = extractvalue %dx.types.ResRet.f32 %5219, 2
  %5223 = extractvalue %dx.types.ResRet.f32 %5219, 3
  %5224 = fcmp fast olt float %5223, 0.000000e+00
  br i1 %5224, label %5225, label %5259

; <label>:5225                                    ; preds = %5214
  %5226 = fcmp fast ogt float %5220, 0x3FA4B5DCC0000000
  %5227 = fcmp fast ogt float %5221, 0x3FA4B5DCC0000000
  %5228 = fcmp fast ogt float %5222, 0x3FA4B5DCC0000000
  %5229 = select i1 %5226, float 0.000000e+00, float 1.000000e+00
  %5230 = select i1 %5227, float 0.000000e+00, float 1.000000e+00
  %5231 = select i1 %5228, float 0.000000e+00, float 1.000000e+00
  %5232 = fmul fast float %5220, 0x3FB3D07220000000
  %5233 = fmul fast float %5221, 0x3FB3D07220000000
  %5234 = fmul fast float %5222, 0x3FB3D07220000000
  %5235 = fadd fast float %5220, 0x3FAC28F5C0000000
  %5236 = fadd fast float %5221, 0x3FAC28F5C0000000
  %5237 = fadd fast float %5222, 0x3FAC28F5C0000000
  %5238 = fmul fast float %5235, 0x3FEE54EDE0000000
  %5239 = fmul fast float %5236, 0x3FEE54EDE0000000
  %5240 = fmul fast float %5237, 0x3FEE54EDE0000000
  %5241 = call float @dx.op.unary.f32(i32 23, float %5238)  ; Log(value)
  %5242 = call float @dx.op.unary.f32(i32 23, float %5239)  ; Log(value)
  %5243 = call float @dx.op.unary.f32(i32 23, float %5240)  ; Log(value)
  %5244 = fmul fast float %5241, 0x4003333340000000
  %5245 = fmul fast float %5242, 0x4003333340000000
  %5246 = fmul fast float %5243, 0x4003333340000000
  %5247 = call float @dx.op.unary.f32(i32 21, float %5244)  ; Exp(value)
  %5248 = call float @dx.op.unary.f32(i32 21, float %5245)  ; Exp(value)
  %5249 = call float @dx.op.unary.f32(i32 21, float %5246)  ; Exp(value)
  %5250 = fsub fast float %5232, %5247
  %5251 = fsub fast float %5233, %5248
  %5252 = fsub fast float %5234, %5249
  %5253 = fmul fast float %5250, %5229
  %5254 = fmul fast float %5251, %5230
  %5255 = fmul fast float %5252, %5231
  %5256 = fadd fast float %5253, %5247
  %5257 = fadd fast float %5254, %5248
  %5258 = fadd fast float %5255, %5249
  br label %5327

; <label>:5259                                    ; preds = %5214
  %5260 = fadd fast float %5, 1.000000e+00
  %5261 = fadd fast float %6, 1.000000e+00
  %5262 = fsub fast float 1.000000e+00, %5
  %5263 = fmul fast float %9, %5260
  %5264 = fmul fast float %9, %5261
  %5265 = fmul fast float %9, %5262
  %5266 = fmul fast float %5263, %5220
  %5267 = fmul fast float %5264, %5221
  %5268 = fmul fast float %5265, %5222
  %5269 = fcmp fast ult float %10, 5.000000e-01
  br i1 %5269, label %5295, label %5270

; <label>:5270                                    ; preds = %5259
  %5271 = fmul fast float %5266, 0x4004147AE0000000
  %5272 = fmul fast float %5267, 0x4004147AE0000000
  %5273 = fmul fast float %5268, 0x4004147AE0000000
  %5274 = fadd fast float %5271, 0x3F9EB851E0000000
  %5275 = fadd fast float %5272, 0x3F9EB851E0000000
  %5276 = fadd fast float %5273, 0x3F9EB851E0000000
  %5277 = fmul fast float %5274, %5266
  %5278 = fmul fast float %5275, %5267
  %5279 = fmul fast float %5276, %5268
  %5280 = fmul fast float %5266, 0x400370A3E0000000
  %5281 = fmul fast float %5267, 0x400370A3E0000000
  %5282 = fmul fast float %5268, 0x400370A3E0000000
  %5283 = fadd fast float %5280, 0x3FE2E147A0000000
  %5284 = fadd fast float %5281, 0x3FE2E147A0000000
  %5285 = fadd fast float %5282, 0x3FE2E147A0000000
  %5286 = fmul fast float %5283, %5266
  %5287 = fmul fast float %5284, %5267
  %5288 = fmul fast float %5285, %5268
  %5289 = fadd fast float %5286, 0x3FC1EB8520000000
  %5290 = fadd fast float %5287, 0x3FC1EB8520000000
  %5291 = fadd fast float %5288, 0x3FC1EB8520000000
  %5292 = fdiv fast float %5277, %5289
  %5293 = fdiv fast float %5278, %5290
  %5294 = fdiv fast float %5279, %5291
  br label %5295

; <label>:5295                                    ; preds = %5270, %5259
  %5296 = phi float [ %5292, %5270 ], [ %5266, %5259 ]
  %5297 = phi float [ %5293, %5270 ], [ %5267, %5259 ]
  %5298 = phi float [ %5294, %5270 ], [ %5268, %5259 ]
  %5299 = call float @dx.op.unary.f32(i32 7, float %5296)  ; Saturate(value)
  %5300 = call float @dx.op.unary.f32(i32 7, float %5297)  ; Saturate(value)
  %5301 = call float @dx.op.unary.f32(i32 7, float %5298)  ; Saturate(value)
  %5302 = call float @dx.op.dot3.f32(i32 55, float %5299, float %5300, float %5301, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5303 = fsub fast float %5299, %5302
  %5304 = fsub fast float %5300, %5302
  %5305 = fsub fast float %5301, %5302
  %5306 = fmul fast float %5303, %8
  %5307 = fmul fast float %5304, %8
  %5308 = fmul fast float %5305, %8
  %5309 = fadd fast float %5306, %5302
  %5310 = fadd fast float %5307, %5302
  %5311 = fadd fast float %5308, %5302
  %5312 = call float @dx.op.unary.f32(i32 7, float %5309)  ; Saturate(value)
  %5313 = call float @dx.op.unary.f32(i32 7, float %5310)  ; Saturate(value)
  %5314 = call float @dx.op.unary.f32(i32 7, float %5311)  ; Saturate(value)
  %5315 = fadd fast float %5312, 0xBFC70A3D80000000
  %5316 = fadd fast float %5313, 0xBFC70A3D80000000
  %5317 = fadd fast float %5314, 0xBFC70A3D80000000
  %5318 = fmul fast float %5315, %7
  %5319 = fmul fast float %5316, %7
  %5320 = fmul fast float %5317, %7
  %5321 = fadd fast float %5318, 0x3FC70A3D80000000
  %5322 = fadd fast float %5319, 0x3FC70A3D80000000
  %5323 = fadd fast float %5320, 0x3FC70A3D80000000
  %5324 = call float @dx.op.unary.f32(i32 7, float %5321)  ; Saturate(value)
  %5325 = call float @dx.op.unary.f32(i32 7, float %5322)  ; Saturate(value)
  %5326 = call float @dx.op.unary.f32(i32 7, float %5323)  ; Saturate(value)
  br label %5327

; <label>:5327                                    ; preds = %5295, %5225
  %5328 = phi float [ %5256, %5225 ], [ %5324, %5295 ]
  %5329 = phi float [ %5257, %5225 ], [ %5325, %5295 ]
  %5330 = phi float [ %5258, %5225 ], [ %5326, %5295 ]
  %5331 = fsub fast float %5328, %4770
  %5332 = fsub fast float %5329, %4771
  %5333 = fsub fast float %5330, %4772
  %5334 = fmul fast float %5331, %5212
  %5335 = fmul fast float %5332, %5212
  %5336 = fmul fast float %5333, %5212
  %5337 = fadd fast float %5334, %4770
  %5338 = fadd fast float %5335, %4771
  %5339 = fadd fast float %5336, %4772
  br label %5340

; <label>:5340                                    ; preds = %5327, %5199
  %5341 = phi float [ %5337, %5327 ], [ %4770, %5199 ]
  %5342 = phi float [ %5338, %5327 ], [ %4771, %5199 ]
  %5343 = phi float [ %5339, %5327 ], [ %4772, %5199 ]
  %5344 = call float @dx.op.binary.f32(i32 36, float %5200, float %5341)  ; FMin(a,b)
  %5345 = call float @dx.op.binary.f32(i32 36, float %5201, float %5342)  ; FMin(a,b)
  %5346 = call float @dx.op.binary.f32(i32 36, float %5202, float %5343)  ; FMin(a,b)
  %5347 = call float @dx.op.binary.f32(i32 36, float %4916, float %5057)  ; FMin(a,b)
  %5348 = call float @dx.op.binary.f32(i32 36, float %4917, float %5058)  ; FMin(a,b)
  %5349 = call float @dx.op.binary.f32(i32 36, float %4918, float %5059)  ; FMin(a,b)
  %5350 = call float @dx.op.binary.f32(i32 36, float %5347, float %5344)  ; FMin(a,b)
  %5351 = call float @dx.op.binary.f32(i32 36, float %5348, float %5345)  ; FMin(a,b)
  %5352 = call float @dx.op.binary.f32(i32 36, float %5349, float %5346)  ; FMin(a,b)
  %5353 = call float @dx.op.binary.f32(i32 36, float %4770, float %5350)  ; FMin(a,b)
  %5354 = call float @dx.op.binary.f32(i32 36, float %4771, float %5351)  ; FMin(a,b)
  %5355 = call float @dx.op.binary.f32(i32 36, float %4772, float %5352)  ; FMin(a,b)
  %5356 = call float @dx.op.binary.f32(i32 35, float %5200, float %5341)  ; FMax(a,b)
  %5357 = call float @dx.op.binary.f32(i32 35, float %5201, float %5342)  ; FMax(a,b)
  %5358 = call float @dx.op.binary.f32(i32 35, float %5202, float %5343)  ; FMax(a,b)
  %5359 = call float @dx.op.binary.f32(i32 35, float %4916, float %5057)  ; FMax(a,b)
  %5360 = call float @dx.op.binary.f32(i32 35, float %4917, float %5058)  ; FMax(a,b)
  %5361 = call float @dx.op.binary.f32(i32 35, float %4918, float %5059)  ; FMax(a,b)
  %5362 = call float @dx.op.binary.f32(i32 35, float %5359, float %5356)  ; FMax(a,b)
  %5363 = call float @dx.op.binary.f32(i32 35, float %5360, float %5357)  ; FMax(a,b)
  %5364 = call float @dx.op.binary.f32(i32 35, float %5361, float %5358)  ; FMax(a,b)
  %5365 = call float @dx.op.binary.f32(i32 35, float %4770, float %5362)  ; FMax(a,b)
  %5366 = call float @dx.op.binary.f32(i32 35, float %4771, float %5363)  ; FMax(a,b)
  %5367 = call float @dx.op.binary.f32(i32 35, float %4772, float %5364)  ; FMax(a,b)
  %5368 = fsub fast float %5365, %5353
  %5369 = fsub fast float %5366, %5354
  %5370 = fsub fast float %5367, %5355
  %5371 = call float @dx.op.unary.f32(i32 6, float %5368)  ; FAbs(value)
  %5372 = call float @dx.op.unary.f32(i32 6, float %5369)  ; FAbs(value)
  %5373 = call float @dx.op.unary.f32(i32 6, float %5370)  ; FAbs(value)
  %5374 = call float @dx.op.binary.f32(i32 35, float %5372, float %5373)  ; FMax(a,b)
  %5375 = call float @dx.op.binary.f32(i32 35, float %5371, float %5374)  ; FMax(a,b)
  %5376 = call float @dx.op.binary.f32(i32 35, float %5366, float %5367)  ; FMax(a,b)
  %5377 = call float @dx.op.binary.f32(i32 35, float %5365, float %5376)  ; FMax(a,b)
  %5378 = fmul fast float %5377, 1.250000e-01
  %5379 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %5378)  ; FMax(a,b)
  %5380 = fcmp fast ogt float %5375, %5379
  br i1 %5380, label %5381, label %5442

; <label>:5381                                    ; preds = %5340
  %5382 = fsub fast float %4916, %5057
  %5383 = fsub fast float %4917, %5058
  %5384 = fsub fast float %4918, %5059
  %5385 = call float @dx.op.unary.f32(i32 6, float %5382)  ; FAbs(value)
  %5386 = call float @dx.op.unary.f32(i32 6, float %5383)  ; FAbs(value)
  %5387 = call float @dx.op.unary.f32(i32 6, float %5384)  ; FAbs(value)
  %5388 = call float @dx.op.binary.f32(i32 35, float %5386, float %5387)  ; FMax(a,b)
  %5389 = call float @dx.op.binary.f32(i32 35, float %5385, float %5388)  ; FMax(a,b)
  %5390 = fsub fast float %5200, %5341
  %5391 = fsub fast float %5201, %5342
  %5392 = fsub fast float %5202, %5343
  %5393 = call float @dx.op.unary.f32(i32 6, float %5390)  ; FAbs(value)
  %5394 = call float @dx.op.unary.f32(i32 6, float %5391)  ; FAbs(value)
  %5395 = call float @dx.op.unary.f32(i32 6, float %5392)  ; FAbs(value)
  %5396 = call float @dx.op.binary.f32(i32 35, float %5394, float %5395)  ; FMax(a,b)
  %5397 = call float @dx.op.binary.f32(i32 35, float %5393, float %5396)  ; FMax(a,b)
  %5398 = fcmp fast olt float %5389, %5397
  %5399 = select i1 %5398, float %4916, float %5200
  %5400 = select i1 %5398, float %4917, float %5201
  %5401 = select i1 %5398, float %4918, float %5202
  %5402 = select i1 %5398, float %5057, float %5341
  %5403 = select i1 %5398, float %5058, float %5342
  %5404 = select i1 %5398, float %5059, float %5343
  %5405 = fsub fast float %4770, %5402
  %5406 = fsub fast float %4771, %5403
  %5407 = fsub fast float %4772, %5404
  %5408 = fsub fast float %4770, %5399
  %5409 = fsub fast float %4771, %5400
  %5410 = fsub fast float %4772, %5401
  %5411 = call float @dx.op.dot3.f32(i32 55, float %5408, float %5409, float %5410, float %5405, float %5406, float %5407)  ; Dot3(ax,ay,az,bx,by,bz)
  %5412 = fcmp fast ogt float %5411, 0.000000e+00
  br i1 %5412, label %5413, label %5425

; <label>:5413                                    ; preds = %5381
  %5414 = fsub fast float %5399, %5402
  %5415 = fsub fast float %5400, %5403
  %5416 = fsub fast float %5401, %5404
  %5417 = call float @dx.op.unary.f32(i32 6, float %5414)  ; FAbs(value)
  %5418 = call float @dx.op.unary.f32(i32 6, float %5415)  ; FAbs(value)
  %5419 = call float @dx.op.unary.f32(i32 6, float %5416)  ; FAbs(value)
  %5420 = call float @dx.op.binary.f32(i32 35, float %5418, float %5419)  ; FMax(a,b)
  %5421 = call float @dx.op.binary.f32(i32 35, float %5417, float %5420)  ; FMax(a,b)
  %5422 = fmul fast float %5375, 2.500000e-01
  %5423 = fcmp fast olt float %5421, %5422
  %5424 = select i1 %5423, float 0x3FC3333340000000, float 0x3FD3333340000000
  br label %5425

; <label>:5425                                    ; preds = %5413, %5381
  %5426 = phi float [ 0x3FD3333340000000, %5381 ], [ %5424, %5413 ]
  %5427 = fadd fast float %5399, %5402
  %5428 = fadd fast float %5400, %5403
  %5429 = fadd fast float %5401, %5404
  %5430 = fmul fast float %5427, 5.000000e-01
  %5431 = fmul fast float %5428, 5.000000e-01
  %5432 = fmul fast float %5429, 5.000000e-01
  %5433 = fsub fast float %5430, %4770
  %5434 = fsub fast float %5431, %4771
  %5435 = fsub fast float %5432, %4772
  %5436 = fmul fast float %5426, %5433
  %5437 = fmul fast float %5426, %5434
  %5438 = fmul fast float %5426, %5435
  %5439 = fadd fast float %5436, %4770
  %5440 = fadd fast float %5437, %4771
  %5441 = fadd fast float %5438, %4772
  br label %5442

; <label>:5442                                    ; preds = %5425, %5340, %4670, %2297, %2212, %1885
  %5443 = phi float [ %1028, %1885 ], [ %3094, %4670 ], [ %1028, %2297 ], [ %1028, %2212 ], [ %3094, %5425 ], [ %3094, %5340 ]
  %5444 = phi float [ %1029, %1885 ], [ %3095, %4670 ], [ %1029, %2297 ], [ %1029, %2212 ], [ %3095, %5425 ], [ %3095, %5340 ]
  %5445 = phi float [ %1030, %1885 ], [ %3096, %4670 ], [ %1030, %2297 ], [ %1030, %2212 ], [ %3096, %5425 ], [ %3096, %5340 ]
  %5446 = phi float [ %595, %1885 ], [ %3097, %4670 ], [ %595, %2297 ], [ %595, %2212 ], [ %3097, %5425 ], [ %3097, %5340 ]
  %5447 = phi float [ %1457, %1885 ], [ %3877, %4670 ], [ %1457, %2297 ], [ %1457, %2212 ], [ %3877, %5425 ], [ %3877, %5340 ]
  %5448 = phi float [ %1458, %1885 ], [ %3878, %4670 ], [ %1458, %2297 ], [ %1458, %2212 ], [ %3878, %5425 ], [ %3878, %5340 ]
  %5449 = phi float [ %1459, %1885 ], [ %3879, %4670 ], [ %1459, %2297 ], [ %1459, %2212 ], [ %3879, %5425 ], [ %3879, %5340 ]
  %5450 = phi float [ %597, %1885 ], [ %3880, %4670 ], [ %597, %2297 ], [ %597, %2212 ], [ %3880, %5425 ], [ %3880, %5340 ]
  %5451 = phi float [ %1886, %1885 ], [ %4660, %4670 ], [ %1886, %2297 ], [ %1886, %2212 ], [ %4660, %5425 ], [ %4660, %5340 ]
  %5452 = phi float [ %1887, %1885 ], [ %4661, %4670 ], [ %1887, %2297 ], [ %1887, %2212 ], [ %4661, %5425 ], [ %4661, %5340 ]
  %5453 = phi float [ %1888, %1885 ], [ %4662, %4670 ], [ %1888, %2297 ], [ %1888, %2212 ], [ %4662, %5425 ], [ %4662, %5340 ]
  %5454 = phi float [ %599, %1885 ], [ %4663, %4670 ], [ %599, %2297 ], [ %599, %2212 ], [ %4663, %5425 ], [ %4663, %5340 ]
  %5455 = phi float [ %591, %1885 ], [ %4701, %4670 ], [ %2311, %2297 ], [ %591, %2212 ], [ %5439, %5425 ], [ %4770, %5340 ]
  %5456 = phi float [ %592, %1885 ], [ %4702, %4670 ], [ %2312, %2297 ], [ %592, %2212 ], [ %5440, %5425 ], [ %4771, %5340 ]
  %5457 = phi float [ %593, %1885 ], [ %4703, %4670 ], [ %2313, %2297 ], [ %593, %2212 ], [ %5441, %5425 ], [ %4772, %5340 ]
  %5458 = phi float [ %601, %1885 ], [ %4704, %4670 ], [ %601, %2297 ], [ %601, %2212 ], [ %4668, %5425 ], [ %4668, %5340 ]
  %5459 = fmul fast float %5443, %133
  %5460 = fmul fast float %5444, %133
  %5461 = fmul fast float %5445, %133
  %5462 = fmul fast float %5447, %134
  %5463 = fmul fast float %5448, %134
  %5464 = fmul fast float %5449, %134
  %5465 = fadd fast float %5462, %5459
  %5466 = fadd fast float %5463, %5460
  %5467 = fadd fast float %5464, %5461
  %5468 = fmul fast float %5451, %135
  %5469 = fmul fast float %5452, %135
  %5470 = fmul fast float %5453, %135
  %5471 = fadd fast float %5465, %5468
  %5472 = fadd fast float %5466, %5469
  %5473 = fadd fast float %5467, %5470
  %5474 = fmul fast float %5455, %136
  %5475 = fmul fast float %5456, %136
  %5476 = fmul fast float %5457, %136
  %5477 = fadd fast float %5471, %5474
  %5478 = fadd fast float %5472, %5475
  %5479 = fadd fast float %5473, %5476
  %5480 = fcmp fast ogt float %5477, 0x3F69A5C380000000
  %5481 = fcmp fast ogt float %5478, 0x3F69A5C380000000
  %5482 = fcmp fast ogt float %5479, 0x3F69A5C380000000
  %5483 = select i1 %5480, float 0.000000e+00, float 1.000000e+00
  %5484 = select i1 %5481, float 0.000000e+00, float 1.000000e+00
  %5485 = select i1 %5482, float 0.000000e+00, float 1.000000e+00
  %5486 = fmul fast float %5477, 0x4029D70A40000000
  %5487 = fmul fast float %5478, 0x4029D70A40000000
  %5488 = fmul fast float %5479, 0x4029D70A40000000
  %5489 = call float @dx.op.binary.f32(i32 35, float %5477, float 0.000000e+00)  ; FMax(a,b)
  %5490 = call float @dx.op.binary.f32(i32 35, float %5478, float 0.000000e+00)  ; FMax(a,b)
  %5491 = call float @dx.op.binary.f32(i32 35, float %5479, float 0.000000e+00)  ; FMax(a,b)
  %5492 = call float @dx.op.unary.f32(i32 23, float %5489)  ; Log(value)
  %5493 = call float @dx.op.unary.f32(i32 23, float %5490)  ; Log(value)
  %5494 = call float @dx.op.unary.f32(i32 23, float %5491)  ; Log(value)
  %5495 = fmul fast float %5492, 0x3FDAAAAAA0000000
  %5496 = fmul fast float %5493, 0x3FDAAAAAA0000000
  %5497 = fmul fast float %5494, 0x3FDAAAAAA0000000
  %5498 = call float @dx.op.unary.f32(i32 21, float %5495)  ; Exp(value)
  %5499 = call float @dx.op.unary.f32(i32 21, float %5496)  ; Exp(value)
  %5500 = call float @dx.op.unary.f32(i32 21, float %5497)  ; Exp(value)
  %5501 = fmul fast float %5498, 0x3FF0E147A0000000
  %5502 = fmul fast float %5499, 0x3FF0E147A0000000
  %5503 = fmul fast float %5500, 0x3FF0E147A0000000
  %5504 = fadd fast float %5501, 0xBFAC28F5C0000000
  %5505 = fadd fast float %5502, 0xBFAC28F5C0000000
  %5506 = fadd fast float %5503, 0xBFAC28F5C0000000
  %5507 = fsub fast float %5486, %5504
  %5508 = fsub fast float %5487, %5505
  %5509 = fsub fast float %5488, %5506
  %5510 = fmul fast float %5507, %5483
  %5511 = fmul fast float %5508, %5484
  %5512 = fmul fast float %5509, %5485
  %5513 = fadd fast float %5510, %5504
  %5514 = fadd fast float %5511, %5505
  %5515 = fadd fast float %5512, %5506
  %5516 = call float @dx.op.dot4.f32(i32 56, float %5446, float %5450, float %5454, float %5458, float %133, float %134, float %135, float %136)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %5513)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %5514)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %5515)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %5516)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %51)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare i1 @dx.op.isSpecialFloat.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 0, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !37, null}
!12 = !{!13, !16, !17, !19, !21, !23, !25, !27, !29, !31, !34}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !15}
!17 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !18, i8 1, i32 1, i8 4, i32 2, i8 0, null}
!18 = !{i32 1}
!19 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !20, i8 1, i32 1, i8 4, i32 3, i8 0, null}
!20 = !{i32 2}
!21 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !22, i8 1, i32 1, i8 4, i32 4, i8 0, null}
!22 = !{i32 3}
!23 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !24, i8 1, i32 1, i8 4, i32 5, i8 0, null}
!24 = !{i32 4}
!25 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !26, i8 1, i32 1, i8 4, i32 6, i8 0, null}
!26 = !{i32 5}
!27 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !28, i8 1, i32 1, i8 4, i32 7, i8 0, null}
!28 = !{i32 6}
!29 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 8, i8 0, null}
!30 = !{i32 7}
!31 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 9, i8 0, !33}
!32 = !{i32 8}
!33 = !{i32 3, i32 15}
!34 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !35, i8 1, i32 1, i8 4, i32 10, i8 0, !36}
!35 = !{i32 9}
!36 = !{i32 3, i32 6}
!37 = !{!38, !39}
!38 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !33}
!39 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !40}
!40 = !{i32 3, i32 1}
