;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xy  
; TEXCOORD                 1   xyzw        2     NONE   float       
; TEXCOORD                 2   xyzw        3     NONE   float       
; TEXCOORD                 3   xyzw        4     NONE   float       
; TEXCOORD                 4   xyzw        5     NONE   float       
; TEXCOORD                 5   xyzw        6     NONE   float       
; TEXCOORD                 6   xyzw        7     NONE   float       
; TEXCOORD                 7   xyzw        8     NONE   float       
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float       
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
;
; shader hash: 52ddd55f5cb651dbf3e8a8cc3611824f
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=0
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 1
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39 }
;   output 3 depends on inputs: { 0, 1 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %1, i32 0)  ; GetDimensions(handle,mipLevel)
  %11 = extractvalue %dx.types.Dimensions %10, 0
  %12 = extractvalue %dx.types.Dimensions %10, 1
  %13 = fptosi float %8 to i32
  %14 = fptosi float %9 to i32
  %15 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %13, i32 %14, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %16 = extractvalue %dx.types.ResRet.f32 %15, 0
  %17 = extractvalue %dx.types.ResRet.f32 %15, 1
  %18 = extractvalue %dx.types.ResRet.f32 %15, 2
  %19 = extractvalue %dx.types.ResRet.f32 %15, 3
  %20 = fcmp fast olt float %19, 0.000000e+00
  br i1 %20, label %21, label %23

; <label>:21                                      ; preds = %0
  %22 = fsub fast float -1.000000e+00, %19
  br label %695

; <label>:23                                      ; preds = %0
  %24 = fadd fast float %2, 1.000000e+00
  %25 = fadd fast float %3, 1.000000e+00
  %26 = fsub fast float 1.000000e+00, %2
  %27 = fmul fast float %6, %24
  %28 = fmul fast float %6, %25
  %29 = fmul fast float %6, %26
  %30 = fmul fast float %27, %16
  %31 = fmul fast float %28, %17
  %32 = fmul fast float %29, %18
  %33 = fcmp fast ult float %7, 5.000000e-01
  br i1 %33, label %59, label %34

; <label>:34                                      ; preds = %23
  %35 = fmul fast float %30, 0x4004147AE0000000
  %36 = fmul fast float %31, 0x4004147AE0000000
  %37 = fmul fast float %32, 0x4004147AE0000000
  %38 = fadd fast float %35, 0x3F9EB851E0000000
  %39 = fadd fast float %36, 0x3F9EB851E0000000
  %40 = fadd fast float %37, 0x3F9EB851E0000000
  %41 = fmul fast float %38, %30
  %42 = fmul fast float %39, %31
  %43 = fmul fast float %40, %32
  %44 = fmul fast float %30, 0x400370A3E0000000
  %45 = fmul fast float %31, 0x400370A3E0000000
  %46 = fmul fast float %32, 0x400370A3E0000000
  %47 = fadd fast float %44, 0x3FE2E147A0000000
  %48 = fadd fast float %45, 0x3FE2E147A0000000
  %49 = fadd fast float %46, 0x3FE2E147A0000000
  %50 = fmul fast float %47, %30
  %51 = fmul fast float %48, %31
  %52 = fmul fast float %49, %32
  %53 = fadd fast float %50, 0x3FC1EB8520000000
  %54 = fadd fast float %51, 0x3FC1EB8520000000
  %55 = fadd fast float %52, 0x3FC1EB8520000000
  %56 = fdiv fast float %41, %53
  %57 = fdiv fast float %42, %54
  %58 = fdiv fast float %43, %55
  br label %59

; <label>:59                                      ; preds = %34, %23
  %60 = phi float [ %56, %34 ], [ %30, %23 ]
  %61 = phi float [ %57, %34 ], [ %31, %23 ]
  %62 = phi float [ %58, %34 ], [ %32, %23 ]
  %63 = call float @dx.op.unary.f32(i32 7, float %60)  ; Saturate(value)
  %64 = call float @dx.op.unary.f32(i32 7, float %61)  ; Saturate(value)
  %65 = call float @dx.op.unary.f32(i32 7, float %62)  ; Saturate(value)
  %66 = call float @dx.op.dot3.f32(i32 55, float %63, float %64, float %65, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %67 = fsub fast float %63, %66
  %68 = fsub fast float %64, %66
  %69 = fsub fast float %65, %66
  %70 = fmul fast float %67, %5
  %71 = fmul fast float %68, %5
  %72 = fmul fast float %69, %5
  %73 = fadd fast float %70, %66
  %74 = fadd fast float %71, %66
  %75 = fadd fast float %72, %66
  %76 = call float @dx.op.unary.f32(i32 7, float %73)  ; Saturate(value)
  %77 = call float @dx.op.unary.f32(i32 7, float %74)  ; Saturate(value)
  %78 = call float @dx.op.unary.f32(i32 7, float %75)  ; Saturate(value)
  %79 = fadd fast float %76, 0xBFC70A3D80000000
  %80 = fadd fast float %77, 0xBFC70A3D80000000
  %81 = fadd fast float %78, 0xBFC70A3D80000000
  %82 = fmul fast float %79, %4
  %83 = fmul fast float %80, %4
  %84 = fmul fast float %81, %4
  %85 = fadd fast float %82, 0x3FC70A3D80000000
  %86 = fadd fast float %83, 0x3FC70A3D80000000
  %87 = fadd fast float %84, 0x3FC70A3D80000000
  %88 = call float @dx.op.unary.f32(i32 7, float %85)  ; Saturate(value)
  %89 = call float @dx.op.unary.f32(i32 7, float %86)  ; Saturate(value)
  %90 = call float @dx.op.unary.f32(i32 7, float %87)  ; Saturate(value)
  %91 = add i32 %14, -1
  %92 = add i32 %11, -1
  %93 = add i32 %12, -1
  %94 = call i32 @dx.op.binary.i32(i32 37, i32 %13, i32 0)  ; IMax(a,b)
  %95 = call i32 @dx.op.binary.i32(i32 37, i32 %91, i32 0)  ; IMax(a,b)
  %96 = call i32 @dx.op.binary.i32(i32 38, i32 %94, i32 %92)  ; IMin(a,b)
  %97 = call i32 @dx.op.binary.i32(i32 38, i32 %95, i32 %93)  ; IMin(a,b)
  %98 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %96, i32 %97, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %99 = extractvalue %dx.types.ResRet.f32 %98, 0
  %100 = extractvalue %dx.types.ResRet.f32 %98, 1
  %101 = extractvalue %dx.types.ResRet.f32 %98, 2
  %102 = extractvalue %dx.types.ResRet.f32 %98, 3
  %103 = fcmp fast olt float %102, 0.000000e+00
  br i1 %103, label %104, label %138

; <label>:104                                     ; preds = %59
  %105 = fcmp fast ogt float %99, 0x3FA4B5DCC0000000
  %106 = fcmp fast ogt float %100, 0x3FA4B5DCC0000000
  %107 = fcmp fast ogt float %101, 0x3FA4B5DCC0000000
  %108 = select i1 %105, float 0.000000e+00, float 1.000000e+00
  %109 = select i1 %106, float 0.000000e+00, float 1.000000e+00
  %110 = select i1 %107, float 0.000000e+00, float 1.000000e+00
  %111 = fmul fast float %99, 0x3FB3D07220000000
  %112 = fmul fast float %100, 0x3FB3D07220000000
  %113 = fmul fast float %101, 0x3FB3D07220000000
  %114 = fadd fast float %99, 0x3FAC28F5C0000000
  %115 = fadd fast float %100, 0x3FAC28F5C0000000
  %116 = fadd fast float %101, 0x3FAC28F5C0000000
  %117 = fmul fast float %114, 0x3FEE54EDE0000000
  %118 = fmul fast float %115, 0x3FEE54EDE0000000
  %119 = fmul fast float %116, 0x3FEE54EDE0000000
  %120 = call float @dx.op.unary.f32(i32 23, float %117)  ; Log(value)
  %121 = call float @dx.op.unary.f32(i32 23, float %118)  ; Log(value)
  %122 = call float @dx.op.unary.f32(i32 23, float %119)  ; Log(value)
  %123 = fmul fast float %120, 0x4003333340000000
  %124 = fmul fast float %121, 0x4003333340000000
  %125 = fmul fast float %122, 0x4003333340000000
  %126 = call float @dx.op.unary.f32(i32 21, float %123)  ; Exp(value)
  %127 = call float @dx.op.unary.f32(i32 21, float %124)  ; Exp(value)
  %128 = call float @dx.op.unary.f32(i32 21, float %125)  ; Exp(value)
  %129 = fsub fast float %111, %126
  %130 = fsub fast float %112, %127
  %131 = fsub fast float %113, %128
  %132 = fmul fast float %129, %108
  %133 = fmul fast float %130, %109
  %134 = fmul fast float %131, %110
  %135 = fadd fast float %132, %126
  %136 = fadd fast float %133, %127
  %137 = fadd fast float %134, %128
  br label %206

; <label>:138                                     ; preds = %59
  %139 = fadd fast float %2, 1.000000e+00
  %140 = fadd fast float %3, 1.000000e+00
  %141 = fsub fast float 1.000000e+00, %2
  %142 = fmul fast float %6, %139
  %143 = fmul fast float %6, %140
  %144 = fmul fast float %6, %141
  %145 = fmul fast float %142, %99
  %146 = fmul fast float %143, %100
  %147 = fmul fast float %144, %101
  %148 = fcmp fast ult float %7, 5.000000e-01
  br i1 %148, label %174, label %149

; <label>:149                                     ; preds = %138
  %150 = fmul fast float %145, 0x4004147AE0000000
  %151 = fmul fast float %146, 0x4004147AE0000000
  %152 = fmul fast float %147, 0x4004147AE0000000
  %153 = fadd fast float %150, 0x3F9EB851E0000000
  %154 = fadd fast float %151, 0x3F9EB851E0000000
  %155 = fadd fast float %152, 0x3F9EB851E0000000
  %156 = fmul fast float %153, %145
  %157 = fmul fast float %154, %146
  %158 = fmul fast float %155, %147
  %159 = fmul fast float %145, 0x400370A3E0000000
  %160 = fmul fast float %146, 0x400370A3E0000000
  %161 = fmul fast float %147, 0x400370A3E0000000
  %162 = fadd fast float %159, 0x3FE2E147A0000000
  %163 = fadd fast float %160, 0x3FE2E147A0000000
  %164 = fadd fast float %161, 0x3FE2E147A0000000
  %165 = fmul fast float %162, %145
  %166 = fmul fast float %163, %146
  %167 = fmul fast float %164, %147
  %168 = fadd fast float %165, 0x3FC1EB8520000000
  %169 = fadd fast float %166, 0x3FC1EB8520000000
  %170 = fadd fast float %167, 0x3FC1EB8520000000
  %171 = fdiv fast float %156, %168
  %172 = fdiv fast float %157, %169
  %173 = fdiv fast float %158, %170
  br label %174

; <label>:174                                     ; preds = %149, %138
  %175 = phi float [ %171, %149 ], [ %145, %138 ]
  %176 = phi float [ %172, %149 ], [ %146, %138 ]
  %177 = phi float [ %173, %149 ], [ %147, %138 ]
  %178 = call float @dx.op.unary.f32(i32 7, float %175)  ; Saturate(value)
  %179 = call float @dx.op.unary.f32(i32 7, float %176)  ; Saturate(value)
  %180 = call float @dx.op.unary.f32(i32 7, float %177)  ; Saturate(value)
  %181 = call float @dx.op.dot3.f32(i32 55, float %178, float %179, float %180, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %182 = fsub fast float %178, %181
  %183 = fsub fast float %179, %181
  %184 = fsub fast float %180, %181
  %185 = fmul fast float %182, %5
  %186 = fmul fast float %183, %5
  %187 = fmul fast float %184, %5
  %188 = fadd fast float %185, %181
  %189 = fadd fast float %186, %181
  %190 = fadd fast float %187, %181
  %191 = call float @dx.op.unary.f32(i32 7, float %188)  ; Saturate(value)
  %192 = call float @dx.op.unary.f32(i32 7, float %189)  ; Saturate(value)
  %193 = call float @dx.op.unary.f32(i32 7, float %190)  ; Saturate(value)
  %194 = fadd fast float %191, 0xBFC70A3D80000000
  %195 = fadd fast float %192, 0xBFC70A3D80000000
  %196 = fadd fast float %193, 0xBFC70A3D80000000
  %197 = fmul fast float %194, %4
  %198 = fmul fast float %195, %4
  %199 = fmul fast float %196, %4
  %200 = fadd fast float %197, 0x3FC70A3D80000000
  %201 = fadd fast float %198, 0x3FC70A3D80000000
  %202 = fadd fast float %199, 0x3FC70A3D80000000
  %203 = call float @dx.op.unary.f32(i32 7, float %200)  ; Saturate(value)
  %204 = call float @dx.op.unary.f32(i32 7, float %201)  ; Saturate(value)
  %205 = call float @dx.op.unary.f32(i32 7, float %202)  ; Saturate(value)
  br label %206

; <label>:206                                     ; preds = %174, %104
  %207 = phi float [ %135, %104 ], [ %203, %174 ]
  %208 = phi float [ %136, %104 ], [ %204, %174 ]
  %209 = phi float [ %137, %104 ], [ %205, %174 ]
  %210 = add i32 %14, 1
  %211 = call i32 @dx.op.binary.i32(i32 37, i32 %210, i32 0)  ; IMax(a,b)
  %212 = call i32 @dx.op.binary.i32(i32 38, i32 %211, i32 %93)  ; IMin(a,b)
  %213 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %96, i32 %212, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %214 = extractvalue %dx.types.ResRet.f32 %213, 0
  %215 = extractvalue %dx.types.ResRet.f32 %213, 1
  %216 = extractvalue %dx.types.ResRet.f32 %213, 2
  %217 = extractvalue %dx.types.ResRet.f32 %213, 3
  %218 = fcmp fast olt float %217, 0.000000e+00
  br i1 %218, label %219, label %253

; <label>:219                                     ; preds = %206
  %220 = fcmp fast ogt float %214, 0x3FA4B5DCC0000000
  %221 = fcmp fast ogt float %215, 0x3FA4B5DCC0000000
  %222 = fcmp fast ogt float %216, 0x3FA4B5DCC0000000
  %223 = select i1 %220, float 0.000000e+00, float 1.000000e+00
  %224 = select i1 %221, float 0.000000e+00, float 1.000000e+00
  %225 = select i1 %222, float 0.000000e+00, float 1.000000e+00
  %226 = fmul fast float %214, 0x3FB3D07220000000
  %227 = fmul fast float %215, 0x3FB3D07220000000
  %228 = fmul fast float %216, 0x3FB3D07220000000
  %229 = fadd fast float %214, 0x3FAC28F5C0000000
  %230 = fadd fast float %215, 0x3FAC28F5C0000000
  %231 = fadd fast float %216, 0x3FAC28F5C0000000
  %232 = fmul fast float %229, 0x3FEE54EDE0000000
  %233 = fmul fast float %230, 0x3FEE54EDE0000000
  %234 = fmul fast float %231, 0x3FEE54EDE0000000
  %235 = call float @dx.op.unary.f32(i32 23, float %232)  ; Log(value)
  %236 = call float @dx.op.unary.f32(i32 23, float %233)  ; Log(value)
  %237 = call float @dx.op.unary.f32(i32 23, float %234)  ; Log(value)
  %238 = fmul fast float %235, 0x4003333340000000
  %239 = fmul fast float %236, 0x4003333340000000
  %240 = fmul fast float %237, 0x4003333340000000
  %241 = call float @dx.op.unary.f32(i32 21, float %238)  ; Exp(value)
  %242 = call float @dx.op.unary.f32(i32 21, float %239)  ; Exp(value)
  %243 = call float @dx.op.unary.f32(i32 21, float %240)  ; Exp(value)
  %244 = fsub fast float %226, %241
  %245 = fsub fast float %227, %242
  %246 = fsub fast float %228, %243
  %247 = fmul fast float %244, %223
  %248 = fmul fast float %245, %224
  %249 = fmul fast float %246, %225
  %250 = fadd fast float %247, %241
  %251 = fadd fast float %248, %242
  %252 = fadd fast float %249, %243
  br label %321

; <label>:253                                     ; preds = %206
  %254 = fadd fast float %2, 1.000000e+00
  %255 = fadd fast float %3, 1.000000e+00
  %256 = fsub fast float 1.000000e+00, %2
  %257 = fmul fast float %6, %254
  %258 = fmul fast float %6, %255
  %259 = fmul fast float %6, %256
  %260 = fmul fast float %257, %214
  %261 = fmul fast float %258, %215
  %262 = fmul fast float %259, %216
  %263 = fcmp fast ult float %7, 5.000000e-01
  br i1 %263, label %289, label %264

; <label>:264                                     ; preds = %253
  %265 = fmul fast float %260, 0x4004147AE0000000
  %266 = fmul fast float %261, 0x4004147AE0000000
  %267 = fmul fast float %262, 0x4004147AE0000000
  %268 = fadd fast float %265, 0x3F9EB851E0000000
  %269 = fadd fast float %266, 0x3F9EB851E0000000
  %270 = fadd fast float %267, 0x3F9EB851E0000000
  %271 = fmul fast float %268, %260
  %272 = fmul fast float %269, %261
  %273 = fmul fast float %270, %262
  %274 = fmul fast float %260, 0x400370A3E0000000
  %275 = fmul fast float %261, 0x400370A3E0000000
  %276 = fmul fast float %262, 0x400370A3E0000000
  %277 = fadd fast float %274, 0x3FE2E147A0000000
  %278 = fadd fast float %275, 0x3FE2E147A0000000
  %279 = fadd fast float %276, 0x3FE2E147A0000000
  %280 = fmul fast float %277, %260
  %281 = fmul fast float %278, %261
  %282 = fmul fast float %279, %262
  %283 = fadd fast float %280, 0x3FC1EB8520000000
  %284 = fadd fast float %281, 0x3FC1EB8520000000
  %285 = fadd fast float %282, 0x3FC1EB8520000000
  %286 = fdiv fast float %271, %283
  %287 = fdiv fast float %272, %284
  %288 = fdiv fast float %273, %285
  br label %289

; <label>:289                                     ; preds = %264, %253
  %290 = phi float [ %286, %264 ], [ %260, %253 ]
  %291 = phi float [ %287, %264 ], [ %261, %253 ]
  %292 = phi float [ %288, %264 ], [ %262, %253 ]
  %293 = call float @dx.op.unary.f32(i32 7, float %290)  ; Saturate(value)
  %294 = call float @dx.op.unary.f32(i32 7, float %291)  ; Saturate(value)
  %295 = call float @dx.op.unary.f32(i32 7, float %292)  ; Saturate(value)
  %296 = call float @dx.op.dot3.f32(i32 55, float %293, float %294, float %295, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %297 = fsub fast float %293, %296
  %298 = fsub fast float %294, %296
  %299 = fsub fast float %295, %296
  %300 = fmul fast float %297, %5
  %301 = fmul fast float %298, %5
  %302 = fmul fast float %299, %5
  %303 = fadd fast float %300, %296
  %304 = fadd fast float %301, %296
  %305 = fadd fast float %302, %296
  %306 = call float @dx.op.unary.f32(i32 7, float %303)  ; Saturate(value)
  %307 = call float @dx.op.unary.f32(i32 7, float %304)  ; Saturate(value)
  %308 = call float @dx.op.unary.f32(i32 7, float %305)  ; Saturate(value)
  %309 = fadd fast float %306, 0xBFC70A3D80000000
  %310 = fadd fast float %307, 0xBFC70A3D80000000
  %311 = fadd fast float %308, 0xBFC70A3D80000000
  %312 = fmul fast float %309, %4
  %313 = fmul fast float %310, %4
  %314 = fmul fast float %311, %4
  %315 = fadd fast float %312, 0x3FC70A3D80000000
  %316 = fadd fast float %313, 0x3FC70A3D80000000
  %317 = fadd fast float %314, 0x3FC70A3D80000000
  %318 = call float @dx.op.unary.f32(i32 7, float %315)  ; Saturate(value)
  %319 = call float @dx.op.unary.f32(i32 7, float %316)  ; Saturate(value)
  %320 = call float @dx.op.unary.f32(i32 7, float %317)  ; Saturate(value)
  br label %321

; <label>:321                                     ; preds = %289, %219
  %322 = phi float [ %250, %219 ], [ %318, %289 ]
  %323 = phi float [ %251, %219 ], [ %319, %289 ]
  %324 = phi float [ %252, %219 ], [ %320, %289 ]
  %325 = add i32 %13, -1
  %326 = call i32 @dx.op.binary.i32(i32 37, i32 %325, i32 0)  ; IMax(a,b)
  %327 = call i32 @dx.op.binary.i32(i32 37, i32 %14, i32 0)  ; IMax(a,b)
  %328 = call i32 @dx.op.binary.i32(i32 38, i32 %326, i32 %92)  ; IMin(a,b)
  %329 = call i32 @dx.op.binary.i32(i32 38, i32 %327, i32 %93)  ; IMin(a,b)
  %330 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %328, i32 %329, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %331 = extractvalue %dx.types.ResRet.f32 %330, 0
  %332 = extractvalue %dx.types.ResRet.f32 %330, 1
  %333 = extractvalue %dx.types.ResRet.f32 %330, 2
  %334 = extractvalue %dx.types.ResRet.f32 %330, 3
  %335 = fcmp fast olt float %334, 0.000000e+00
  br i1 %335, label %336, label %370

; <label>:336                                     ; preds = %321
  %337 = fcmp fast ogt float %331, 0x3FA4B5DCC0000000
  %338 = fcmp fast ogt float %332, 0x3FA4B5DCC0000000
  %339 = fcmp fast ogt float %333, 0x3FA4B5DCC0000000
  %340 = select i1 %337, float 0.000000e+00, float 1.000000e+00
  %341 = select i1 %338, float 0.000000e+00, float 1.000000e+00
  %342 = select i1 %339, float 0.000000e+00, float 1.000000e+00
  %343 = fmul fast float %331, 0x3FB3D07220000000
  %344 = fmul fast float %332, 0x3FB3D07220000000
  %345 = fmul fast float %333, 0x3FB3D07220000000
  %346 = fadd fast float %331, 0x3FAC28F5C0000000
  %347 = fadd fast float %332, 0x3FAC28F5C0000000
  %348 = fadd fast float %333, 0x3FAC28F5C0000000
  %349 = fmul fast float %346, 0x3FEE54EDE0000000
  %350 = fmul fast float %347, 0x3FEE54EDE0000000
  %351 = fmul fast float %348, 0x3FEE54EDE0000000
  %352 = call float @dx.op.unary.f32(i32 23, float %349)  ; Log(value)
  %353 = call float @dx.op.unary.f32(i32 23, float %350)  ; Log(value)
  %354 = call float @dx.op.unary.f32(i32 23, float %351)  ; Log(value)
  %355 = fmul fast float %352, 0x4003333340000000
  %356 = fmul fast float %353, 0x4003333340000000
  %357 = fmul fast float %354, 0x4003333340000000
  %358 = call float @dx.op.unary.f32(i32 21, float %355)  ; Exp(value)
  %359 = call float @dx.op.unary.f32(i32 21, float %356)  ; Exp(value)
  %360 = call float @dx.op.unary.f32(i32 21, float %357)  ; Exp(value)
  %361 = fsub fast float %343, %358
  %362 = fsub fast float %344, %359
  %363 = fsub fast float %345, %360
  %364 = fmul fast float %361, %340
  %365 = fmul fast float %362, %341
  %366 = fmul fast float %363, %342
  %367 = fadd fast float %364, %358
  %368 = fadd fast float %365, %359
  %369 = fadd fast float %366, %360
  br label %438

; <label>:370                                     ; preds = %321
  %371 = fadd fast float %2, 1.000000e+00
  %372 = fadd fast float %3, 1.000000e+00
  %373 = fsub fast float 1.000000e+00, %2
  %374 = fmul fast float %6, %371
  %375 = fmul fast float %6, %372
  %376 = fmul fast float %6, %373
  %377 = fmul fast float %374, %331
  %378 = fmul fast float %375, %332
  %379 = fmul fast float %376, %333
  %380 = fcmp fast ult float %7, 5.000000e-01
  br i1 %380, label %406, label %381

; <label>:381                                     ; preds = %370
  %382 = fmul fast float %377, 0x4004147AE0000000
  %383 = fmul fast float %378, 0x4004147AE0000000
  %384 = fmul fast float %379, 0x4004147AE0000000
  %385 = fadd fast float %382, 0x3F9EB851E0000000
  %386 = fadd fast float %383, 0x3F9EB851E0000000
  %387 = fadd fast float %384, 0x3F9EB851E0000000
  %388 = fmul fast float %385, %377
  %389 = fmul fast float %386, %378
  %390 = fmul fast float %387, %379
  %391 = fmul fast float %377, 0x400370A3E0000000
  %392 = fmul fast float %378, 0x400370A3E0000000
  %393 = fmul fast float %379, 0x400370A3E0000000
  %394 = fadd fast float %391, 0x3FE2E147A0000000
  %395 = fadd fast float %392, 0x3FE2E147A0000000
  %396 = fadd fast float %393, 0x3FE2E147A0000000
  %397 = fmul fast float %394, %377
  %398 = fmul fast float %395, %378
  %399 = fmul fast float %396, %379
  %400 = fadd fast float %397, 0x3FC1EB8520000000
  %401 = fadd fast float %398, 0x3FC1EB8520000000
  %402 = fadd fast float %399, 0x3FC1EB8520000000
  %403 = fdiv fast float %388, %400
  %404 = fdiv fast float %389, %401
  %405 = fdiv fast float %390, %402
  br label %406

; <label>:406                                     ; preds = %381, %370
  %407 = phi float [ %403, %381 ], [ %377, %370 ]
  %408 = phi float [ %404, %381 ], [ %378, %370 ]
  %409 = phi float [ %405, %381 ], [ %379, %370 ]
  %410 = call float @dx.op.unary.f32(i32 7, float %407)  ; Saturate(value)
  %411 = call float @dx.op.unary.f32(i32 7, float %408)  ; Saturate(value)
  %412 = call float @dx.op.unary.f32(i32 7, float %409)  ; Saturate(value)
  %413 = call float @dx.op.dot3.f32(i32 55, float %410, float %411, float %412, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %414 = fsub fast float %410, %413
  %415 = fsub fast float %411, %413
  %416 = fsub fast float %412, %413
  %417 = fmul fast float %414, %5
  %418 = fmul fast float %415, %5
  %419 = fmul fast float %416, %5
  %420 = fadd fast float %417, %413
  %421 = fadd fast float %418, %413
  %422 = fadd fast float %419, %413
  %423 = call float @dx.op.unary.f32(i32 7, float %420)  ; Saturate(value)
  %424 = call float @dx.op.unary.f32(i32 7, float %421)  ; Saturate(value)
  %425 = call float @dx.op.unary.f32(i32 7, float %422)  ; Saturate(value)
  %426 = fadd fast float %423, 0xBFC70A3D80000000
  %427 = fadd fast float %424, 0xBFC70A3D80000000
  %428 = fadd fast float %425, 0xBFC70A3D80000000
  %429 = fmul fast float %426, %4
  %430 = fmul fast float %427, %4
  %431 = fmul fast float %428, %4
  %432 = fadd fast float %429, 0x3FC70A3D80000000
  %433 = fadd fast float %430, 0x3FC70A3D80000000
  %434 = fadd fast float %431, 0x3FC70A3D80000000
  %435 = call float @dx.op.unary.f32(i32 7, float %432)  ; Saturate(value)
  %436 = call float @dx.op.unary.f32(i32 7, float %433)  ; Saturate(value)
  %437 = call float @dx.op.unary.f32(i32 7, float %434)  ; Saturate(value)
  br label %438

; <label>:438                                     ; preds = %406, %336
  %439 = phi float [ %367, %336 ], [ %435, %406 ]
  %440 = phi float [ %368, %336 ], [ %436, %406 ]
  %441 = phi float [ %369, %336 ], [ %437, %406 ]
  %442 = add i32 %13, 1
  %443 = call i32 @dx.op.binary.i32(i32 37, i32 %442, i32 0)  ; IMax(a,b)
  %444 = call i32 @dx.op.binary.i32(i32 38, i32 %443, i32 %92)  ; IMin(a,b)
  %445 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %444, i32 %329, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %446 = extractvalue %dx.types.ResRet.f32 %445, 0
  %447 = extractvalue %dx.types.ResRet.f32 %445, 1
  %448 = extractvalue %dx.types.ResRet.f32 %445, 2
  %449 = extractvalue %dx.types.ResRet.f32 %445, 3
  %450 = fcmp fast olt float %449, 0.000000e+00
  br i1 %450, label %451, label %485

; <label>:451                                     ; preds = %438
  %452 = fcmp fast ogt float %446, 0x3FA4B5DCC0000000
  %453 = fcmp fast ogt float %447, 0x3FA4B5DCC0000000
  %454 = fcmp fast ogt float %448, 0x3FA4B5DCC0000000
  %455 = select i1 %452, float 0.000000e+00, float 1.000000e+00
  %456 = select i1 %453, float 0.000000e+00, float 1.000000e+00
  %457 = select i1 %454, float 0.000000e+00, float 1.000000e+00
  %458 = fmul fast float %446, 0x3FB3D07220000000
  %459 = fmul fast float %447, 0x3FB3D07220000000
  %460 = fmul fast float %448, 0x3FB3D07220000000
  %461 = fadd fast float %446, 0x3FAC28F5C0000000
  %462 = fadd fast float %447, 0x3FAC28F5C0000000
  %463 = fadd fast float %448, 0x3FAC28F5C0000000
  %464 = fmul fast float %461, 0x3FEE54EDE0000000
  %465 = fmul fast float %462, 0x3FEE54EDE0000000
  %466 = fmul fast float %463, 0x3FEE54EDE0000000
  %467 = call float @dx.op.unary.f32(i32 23, float %464)  ; Log(value)
  %468 = call float @dx.op.unary.f32(i32 23, float %465)  ; Log(value)
  %469 = call float @dx.op.unary.f32(i32 23, float %466)  ; Log(value)
  %470 = fmul fast float %467, 0x4003333340000000
  %471 = fmul fast float %468, 0x4003333340000000
  %472 = fmul fast float %469, 0x4003333340000000
  %473 = call float @dx.op.unary.f32(i32 21, float %470)  ; Exp(value)
  %474 = call float @dx.op.unary.f32(i32 21, float %471)  ; Exp(value)
  %475 = call float @dx.op.unary.f32(i32 21, float %472)  ; Exp(value)
  %476 = fsub fast float %458, %473
  %477 = fsub fast float %459, %474
  %478 = fsub fast float %460, %475
  %479 = fmul fast float %476, %455
  %480 = fmul fast float %477, %456
  %481 = fmul fast float %478, %457
  %482 = fadd fast float %479, %473
  %483 = fadd fast float %480, %474
  %484 = fadd fast float %481, %475
  br label %553

; <label>:485                                     ; preds = %438
  %486 = fadd fast float %2, 1.000000e+00
  %487 = fadd fast float %3, 1.000000e+00
  %488 = fsub fast float 1.000000e+00, %2
  %489 = fmul fast float %6, %486
  %490 = fmul fast float %6, %487
  %491 = fmul fast float %6, %488
  %492 = fmul fast float %489, %446
  %493 = fmul fast float %490, %447
  %494 = fmul fast float %491, %448
  %495 = fcmp fast ult float %7, 5.000000e-01
  br i1 %495, label %521, label %496

; <label>:496                                     ; preds = %485
  %497 = fmul fast float %492, 0x4004147AE0000000
  %498 = fmul fast float %493, 0x4004147AE0000000
  %499 = fmul fast float %494, 0x4004147AE0000000
  %500 = fadd fast float %497, 0x3F9EB851E0000000
  %501 = fadd fast float %498, 0x3F9EB851E0000000
  %502 = fadd fast float %499, 0x3F9EB851E0000000
  %503 = fmul fast float %500, %492
  %504 = fmul fast float %501, %493
  %505 = fmul fast float %502, %494
  %506 = fmul fast float %492, 0x400370A3E0000000
  %507 = fmul fast float %493, 0x400370A3E0000000
  %508 = fmul fast float %494, 0x400370A3E0000000
  %509 = fadd fast float %506, 0x3FE2E147A0000000
  %510 = fadd fast float %507, 0x3FE2E147A0000000
  %511 = fadd fast float %508, 0x3FE2E147A0000000
  %512 = fmul fast float %509, %492
  %513 = fmul fast float %510, %493
  %514 = fmul fast float %511, %494
  %515 = fadd fast float %512, 0x3FC1EB8520000000
  %516 = fadd fast float %513, 0x3FC1EB8520000000
  %517 = fadd fast float %514, 0x3FC1EB8520000000
  %518 = fdiv fast float %503, %515
  %519 = fdiv fast float %504, %516
  %520 = fdiv fast float %505, %517
  br label %521

; <label>:521                                     ; preds = %496, %485
  %522 = phi float [ %518, %496 ], [ %492, %485 ]
  %523 = phi float [ %519, %496 ], [ %493, %485 ]
  %524 = phi float [ %520, %496 ], [ %494, %485 ]
  %525 = call float @dx.op.unary.f32(i32 7, float %522)  ; Saturate(value)
  %526 = call float @dx.op.unary.f32(i32 7, float %523)  ; Saturate(value)
  %527 = call float @dx.op.unary.f32(i32 7, float %524)  ; Saturate(value)
  %528 = call float @dx.op.dot3.f32(i32 55, float %525, float %526, float %527, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %529 = fsub fast float %525, %528
  %530 = fsub fast float %526, %528
  %531 = fsub fast float %527, %528
  %532 = fmul fast float %529, %5
  %533 = fmul fast float %530, %5
  %534 = fmul fast float %531, %5
  %535 = fadd fast float %532, %528
  %536 = fadd fast float %533, %528
  %537 = fadd fast float %534, %528
  %538 = call float @dx.op.unary.f32(i32 7, float %535)  ; Saturate(value)
  %539 = call float @dx.op.unary.f32(i32 7, float %536)  ; Saturate(value)
  %540 = call float @dx.op.unary.f32(i32 7, float %537)  ; Saturate(value)
  %541 = fadd fast float %538, 0xBFC70A3D80000000
  %542 = fadd fast float %539, 0xBFC70A3D80000000
  %543 = fadd fast float %540, 0xBFC70A3D80000000
  %544 = fmul fast float %541, %4
  %545 = fmul fast float %542, %4
  %546 = fmul fast float %543, %4
  %547 = fadd fast float %544, 0x3FC70A3D80000000
  %548 = fadd fast float %545, 0x3FC70A3D80000000
  %549 = fadd fast float %546, 0x3FC70A3D80000000
  %550 = call float @dx.op.unary.f32(i32 7, float %547)  ; Saturate(value)
  %551 = call float @dx.op.unary.f32(i32 7, float %548)  ; Saturate(value)
  %552 = call float @dx.op.unary.f32(i32 7, float %549)  ; Saturate(value)
  br label %553

; <label>:553                                     ; preds = %521, %451
  %554 = phi float [ %482, %451 ], [ %550, %521 ]
  %555 = phi float [ %483, %451 ], [ %551, %521 ]
  %556 = phi float [ %484, %451 ], [ %552, %521 ]
  %557 = call float @dx.op.binary.f32(i32 36, float %439, float %554)  ; FMin(a,b)
  %558 = call float @dx.op.binary.f32(i32 36, float %440, float %555)  ; FMin(a,b)
  %559 = call float @dx.op.binary.f32(i32 36, float %441, float %556)  ; FMin(a,b)
  %560 = call float @dx.op.binary.f32(i32 36, float %207, float %322)  ; FMin(a,b)
  %561 = call float @dx.op.binary.f32(i32 36, float %208, float %323)  ; FMin(a,b)
  %562 = call float @dx.op.binary.f32(i32 36, float %209, float %324)  ; FMin(a,b)
  %563 = call float @dx.op.binary.f32(i32 36, float %560, float %557)  ; FMin(a,b)
  %564 = call float @dx.op.binary.f32(i32 36, float %561, float %558)  ; FMin(a,b)
  %565 = call float @dx.op.binary.f32(i32 36, float %562, float %559)  ; FMin(a,b)
  %566 = call float @dx.op.binary.f32(i32 36, float %88, float %563)  ; FMin(a,b)
  %567 = call float @dx.op.binary.f32(i32 36, float %89, float %564)  ; FMin(a,b)
  %568 = call float @dx.op.binary.f32(i32 36, float %90, float %565)  ; FMin(a,b)
  %569 = call float @dx.op.binary.f32(i32 35, float %439, float %554)  ; FMax(a,b)
  %570 = call float @dx.op.binary.f32(i32 35, float %440, float %555)  ; FMax(a,b)
  %571 = call float @dx.op.binary.f32(i32 35, float %441, float %556)  ; FMax(a,b)
  %572 = call float @dx.op.binary.f32(i32 35, float %207, float %322)  ; FMax(a,b)
  %573 = call float @dx.op.binary.f32(i32 35, float %208, float %323)  ; FMax(a,b)
  %574 = call float @dx.op.binary.f32(i32 35, float %209, float %324)  ; FMax(a,b)
  %575 = call float @dx.op.binary.f32(i32 35, float %572, float %569)  ; FMax(a,b)
  %576 = call float @dx.op.binary.f32(i32 35, float %573, float %570)  ; FMax(a,b)
  %577 = call float @dx.op.binary.f32(i32 35, float %574, float %571)  ; FMax(a,b)
  %578 = call float @dx.op.binary.f32(i32 35, float %88, float %575)  ; FMax(a,b)
  %579 = call float @dx.op.binary.f32(i32 35, float %89, float %576)  ; FMax(a,b)
  %580 = call float @dx.op.binary.f32(i32 35, float %90, float %577)  ; FMax(a,b)
  %581 = fsub fast float %578, %566
  %582 = fsub fast float %579, %567
  %583 = fsub fast float %580, %568
  %584 = call float @dx.op.unary.f32(i32 6, float %581)  ; FAbs(value)
  %585 = call float @dx.op.unary.f32(i32 6, float %582)  ; FAbs(value)
  %586 = call float @dx.op.unary.f32(i32 6, float %583)  ; FAbs(value)
  %587 = call float @dx.op.binary.f32(i32 35, float %585, float %586)  ; FMax(a,b)
  %588 = call float @dx.op.binary.f32(i32 35, float %584, float %587)  ; FMax(a,b)
  %589 = call float @dx.op.binary.f32(i32 35, float %579, float %580)  ; FMax(a,b)
  %590 = call float @dx.op.binary.f32(i32 35, float %578, float %589)  ; FMax(a,b)
  %591 = fmul fast float %590, 1.250000e-01
  %592 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %591)  ; FMax(a,b)
  %593 = fcmp fast ogt float %588, %592
  br i1 %593, label %594, label %655

; <label>:594                                     ; preds = %553
  %595 = fsub fast float %207, %322
  %596 = fsub fast float %208, %323
  %597 = fsub fast float %209, %324
  %598 = call float @dx.op.unary.f32(i32 6, float %595)  ; FAbs(value)
  %599 = call float @dx.op.unary.f32(i32 6, float %596)  ; FAbs(value)
  %600 = call float @dx.op.unary.f32(i32 6, float %597)  ; FAbs(value)
  %601 = call float @dx.op.binary.f32(i32 35, float %599, float %600)  ; FMax(a,b)
  %602 = call float @dx.op.binary.f32(i32 35, float %598, float %601)  ; FMax(a,b)
  %603 = fsub fast float %439, %554
  %604 = fsub fast float %440, %555
  %605 = fsub fast float %441, %556
  %606 = call float @dx.op.unary.f32(i32 6, float %603)  ; FAbs(value)
  %607 = call float @dx.op.unary.f32(i32 6, float %604)  ; FAbs(value)
  %608 = call float @dx.op.unary.f32(i32 6, float %605)  ; FAbs(value)
  %609 = call float @dx.op.binary.f32(i32 35, float %607, float %608)  ; FMax(a,b)
  %610 = call float @dx.op.binary.f32(i32 35, float %606, float %609)  ; FMax(a,b)
  %611 = fcmp fast olt float %602, %610
  %612 = select i1 %611, float %207, float %439
  %613 = select i1 %611, float %208, float %440
  %614 = select i1 %611, float %209, float %441
  %615 = select i1 %611, float %322, float %554
  %616 = select i1 %611, float %323, float %555
  %617 = select i1 %611, float %324, float %556
  %618 = fsub fast float %88, %615
  %619 = fsub fast float %89, %616
  %620 = fsub fast float %90, %617
  %621 = fsub fast float %88, %612
  %622 = fsub fast float %89, %613
  %623 = fsub fast float %90, %614
  %624 = call float @dx.op.dot3.f32(i32 55, float %621, float %622, float %623, float %618, float %619, float %620)  ; Dot3(ax,ay,az,bx,by,bz)
  %625 = fcmp fast ogt float %624, 0.000000e+00
  br i1 %625, label %626, label %638

; <label>:626                                     ; preds = %594
  %627 = fsub fast float %612, %615
  %628 = fsub fast float %613, %616
  %629 = fsub fast float %614, %617
  %630 = call float @dx.op.unary.f32(i32 6, float %627)  ; FAbs(value)
  %631 = call float @dx.op.unary.f32(i32 6, float %628)  ; FAbs(value)
  %632 = call float @dx.op.unary.f32(i32 6, float %629)  ; FAbs(value)
  %633 = call float @dx.op.binary.f32(i32 35, float %631, float %632)  ; FMax(a,b)
  %634 = call float @dx.op.binary.f32(i32 35, float %630, float %633)  ; FMax(a,b)
  %635 = fmul fast float %588, 2.500000e-01
  %636 = fcmp fast olt float %634, %635
  %637 = select i1 %636, float 0x3FC3333340000000, float 0x3FD3333340000000
  br label %638

; <label>:638                                     ; preds = %626, %594
  %639 = phi float [ 0x3FD3333340000000, %594 ], [ %637, %626 ]
  %640 = fadd fast float %612, %615
  %641 = fadd fast float %613, %616
  %642 = fadd fast float %614, %617
  %643 = fmul fast float %640, 5.000000e-01
  %644 = fmul fast float %641, 5.000000e-01
  %645 = fmul fast float %642, 5.000000e-01
  %646 = fsub fast float %643, %88
  %647 = fsub fast float %644, %89
  %648 = fsub fast float %645, %90
  %649 = fmul fast float %639, %646
  %650 = fmul fast float %639, %647
  %651 = fmul fast float %639, %648
  %652 = fadd fast float %649, %88
  %653 = fadd fast float %650, %89
  %654 = fadd fast float %651, %90
  br label %655

; <label>:655                                     ; preds = %638, %553
  %656 = phi float [ %652, %638 ], [ %88, %553 ]
  %657 = phi float [ %653, %638 ], [ %89, %553 ]
  %658 = phi float [ %654, %638 ], [ %90, %553 ]
  %659 = fcmp fast ogt float %656, 0x3F69A5C380000000
  %660 = fcmp fast ogt float %657, 0x3F69A5C380000000
  %661 = fcmp fast ogt float %658, 0x3F69A5C380000000
  %662 = select i1 %659, float 0.000000e+00, float 1.000000e+00
  %663 = select i1 %660, float 0.000000e+00, float 1.000000e+00
  %664 = select i1 %661, float 0.000000e+00, float 1.000000e+00
  %665 = fmul fast float %656, 0x4029D70A40000000
  %666 = fmul fast float %657, 0x4029D70A40000000
  %667 = fmul fast float %658, 0x4029D70A40000000
  %668 = call float @dx.op.binary.f32(i32 35, float %656, float 0.000000e+00)  ; FMax(a,b)
  %669 = call float @dx.op.binary.f32(i32 35, float %657, float 0.000000e+00)  ; FMax(a,b)
  %670 = call float @dx.op.binary.f32(i32 35, float %658, float 0.000000e+00)  ; FMax(a,b)
  %671 = call float @dx.op.unary.f32(i32 23, float %668)  ; Log(value)
  %672 = call float @dx.op.unary.f32(i32 23, float %669)  ; Log(value)
  %673 = call float @dx.op.unary.f32(i32 23, float %670)  ; Log(value)
  %674 = fmul fast float %671, 0x3FDAAAAAA0000000
  %675 = fmul fast float %672, 0x3FDAAAAAA0000000
  %676 = fmul fast float %673, 0x3FDAAAAAA0000000
  %677 = call float @dx.op.unary.f32(i32 21, float %674)  ; Exp(value)
  %678 = call float @dx.op.unary.f32(i32 21, float %675)  ; Exp(value)
  %679 = call float @dx.op.unary.f32(i32 21, float %676)  ; Exp(value)
  %680 = fmul fast float %677, 0x3FF0E147A0000000
  %681 = fmul fast float %678, 0x3FF0E147A0000000
  %682 = fmul fast float %679, 0x3FF0E147A0000000
  %683 = fadd fast float %680, 0xBFAC28F5C0000000
  %684 = fadd fast float %681, 0xBFAC28F5C0000000
  %685 = fadd fast float %682, 0xBFAC28F5C0000000
  %686 = fsub fast float %665, %683
  %687 = fsub fast float %666, %684
  %688 = fsub fast float %667, %685
  %689 = fmul fast float %686, %662
  %690 = fmul fast float %687, %663
  %691 = fmul fast float %688, %664
  %692 = fadd fast float %689, %683
  %693 = fadd fast float %690, %684
  %694 = fadd fast float %691, %685
  br label %695

; <label>:695                                     ; preds = %655, %21
  %696 = phi float [ %16, %21 ], [ %692, %655 ]
  %697 = phi float [ %17, %21 ], [ %693, %655 ]
  %698 = phi float [ %18, %21 ], [ %694, %655 ]
  %699 = phi float [ %22, %21 ], [ %19, %655 ]
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %696)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %697)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %698)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %699)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!8}
!dx.entryPoints = !{!9}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 0, i32 0, i32 0, i32 0]}
!9 = !{void ()* @PSMain, !"PSMain", !10, !4, null}
!10 = !{!11, !35, null}
!11 = !{!12, !15, !16, !18, !20, !22, !24, !26, !28, !30, !33}
!12 = !{i32 0, !"SV_Position", i8 9, i8 3, !13, i8 4, i32 1, i8 4, i32 0, i8 0, !14}
!13 = !{i32 0}
!14 = !{i32 3, i32 3}
!15 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !13, i8 1, i32 1, i8 4, i32 1, i8 0, !14}
!16 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !17, i8 1, i32 1, i8 4, i32 2, i8 0, null}
!17 = !{i32 1}
!18 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 3, i8 0, null}
!19 = !{i32 2}
!20 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 4, i8 0, null}
!21 = !{i32 3}
!22 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 5, i8 0, null}
!23 = !{i32 4}
!24 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 6, i8 0, null}
!25 = !{i32 5}
!26 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 7, i8 0, null}
!27 = !{i32 6}
!28 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !29, i8 1, i32 1, i8 4, i32 8, i8 0, null}
!29 = !{i32 7}
!30 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !31, i8 1, i32 1, i8 4, i32 9, i8 0, !32}
!31 = !{i32 8}
!32 = !{i32 3, i32 15}
!33 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 10, i8 0, null}
!34 = !{i32 9}
!35 = !{!36}
!36 = !{i32 0, !"SV_Target", i8 9, i8 16, !13, i8 0, i32 1, i8 4, i32 0, i8 0, !32}
