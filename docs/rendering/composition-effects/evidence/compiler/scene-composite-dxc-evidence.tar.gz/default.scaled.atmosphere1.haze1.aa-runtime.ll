;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float   xyz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: 199a4bd773a03cba3be0e65c9b1e0acf
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %40 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %41 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %42 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %43 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %44 = extractvalue %dx.types.Dimensions %43, 0
  %45 = extractvalue %dx.types.Dimensions %43, 1
  %46 = uitofp i32 %44 to float
  %47 = uitofp i32 %45 to float
  %48 = fmul fast float %46, %41
  %49 = fmul fast float %47, %42
  %50 = fdiv fast float %48, %4
  %51 = fdiv fast float %49, %5
  %52 = fadd fast float %50, -5.000000e-01
  %53 = fadd fast float %51, -5.000000e-01
  %54 = call float @dx.op.unary.f32(i32 27, float %52)  ; Round_ni(value)
  %55 = call float @dx.op.unary.f32(i32 27, float %53)  ; Round_ni(value)
  %56 = fptosi float %54 to i32
  %57 = fptosi float %55 to i32
  %58 = call float @dx.op.unary.f32(i32 22, float %52)  ; Frc(value)
  %59 = call float @dx.op.unary.f32(i32 22, float %53)  ; Frc(value)
  %60 = add i32 %44, -1
  %61 = add i32 %45, -1
  %62 = call i32 @dx.op.binary.i32(i32 37, i32 %56, i32 0)  ; IMax(a,b)
  %63 = call i32 @dx.op.binary.i32(i32 37, i32 %57, i32 0)  ; IMax(a,b)
  %64 = call i32 @dx.op.binary.i32(i32 38, i32 %62, i32 %60)  ; IMin(a,b)
  %65 = call i32 @dx.op.binary.i32(i32 38, i32 %63, i32 %61)  ; IMin(a,b)
  %66 = add i32 %56, 1
  %67 = call i32 @dx.op.binary.i32(i32 37, i32 %66, i32 0)  ; IMax(a,b)
  %68 = call i32 @dx.op.binary.i32(i32 38, i32 %67, i32 %60)  ; IMin(a,b)
  %69 = add i32 %57, 1
  %70 = call i32 @dx.op.binary.i32(i32 37, i32 %69, i32 0)  ; IMax(a,b)
  %71 = call i32 @dx.op.binary.i32(i32 38, i32 %70, i32 %61)  ; IMin(a,b)
  %72 = call float @dx.op.unary.f32(i32 27, float %50)  ; Round_ni(value)
  %73 = call float @dx.op.unary.f32(i32 27, float %51)  ; Round_ni(value)
  %74 = fptosi float %72 to i32
  %75 = fptosi float %73 to i32
  %76 = call i32 @dx.op.binary.i32(i32 37, i32 %74, i32 0)  ; IMax(a,b)
  %77 = call i32 @dx.op.binary.i32(i32 37, i32 %75, i32 0)  ; IMax(a,b)
  %78 = call i32 @dx.op.binary.i32(i32 38, i32 %76, i32 %60)  ; IMin(a,b)
  %79 = call i32 @dx.op.binary.i32(i32 38, i32 %77, i32 %61)  ; IMin(a,b)
  %80 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %78, i32 %79, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %81 = extractvalue %dx.types.ResRet.f32 %80, 0
  %82 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %64, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %83 = extractvalue %dx.types.ResRet.f32 %82, 0
  %84 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %68, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %85 = extractvalue %dx.types.ResRet.f32 %84, 0
  %86 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %64, i32 %71, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %87 = extractvalue %dx.types.ResRet.f32 %86, 0
  %88 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %68, i32 %71, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %89 = extractvalue %dx.types.ResRet.f32 %88, 0
  %90 = fsub fast float 1.000000e+00, %58
  %91 = fsub fast float 1.000000e+00, %59
  %92 = fmul fast float %91, %90
  %93 = fmul fast float %91, %58
  %94 = fmul fast float %90, %59
  %95 = fmul fast float %59, %58
  %96 = fsub fast float 1.000000e+00, %81
  %97 = fmul fast float %96, 0x3FA99999A0000000
  %98 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %97)  ; FMax(a,b)
  %99 = fsub fast float %83, %81
  %100 = call float @dx.op.unary.f32(i32 6, float %99)  ; FAbs(value)
  %101 = fdiv fast float %100, %98
  %102 = fsub fast float 1.000000e+00, %101
  %103 = call float @dx.op.unary.f32(i32 7, float %102)  ; Saturate(value)
  %104 = fsub fast float %85, %81
  %105 = call float @dx.op.unary.f32(i32 6, float %104)  ; FAbs(value)
  %106 = fdiv fast float %105, %98
  %107 = fsub fast float 1.000000e+00, %106
  %108 = call float @dx.op.unary.f32(i32 7, float %107)  ; Saturate(value)
  %109 = fsub fast float %87, %81
  %110 = call float @dx.op.unary.f32(i32 6, float %109)  ; FAbs(value)
  %111 = fdiv fast float %110, %98
  %112 = fsub fast float 1.000000e+00, %111
  %113 = call float @dx.op.unary.f32(i32 7, float %112)  ; Saturate(value)
  %114 = fsub fast float %89, %81
  %115 = call float @dx.op.unary.f32(i32 6, float %114)  ; FAbs(value)
  %116 = fdiv fast float %115, %98
  %117 = fsub fast float 1.000000e+00, %116
  %118 = call float @dx.op.unary.f32(i32 7, float %117)  ; Saturate(value)
  %119 = fmul fast float %92, %103
  %120 = fmul fast float %93, %108
  %121 = fmul fast float %94, %113
  %122 = fmul fast float %95, %118
  %123 = fcmp fast oge float %58, 5.000000e-01
  %124 = zext i1 %123 to i32
  %125 = fcmp fast oge float %59, 5.000000e-01
  %126 = select i1 %125, i32 2, i32 0
  %127 = or i32 %126, %124
  %128 = call float @dx.op.dot4.f32(i32 56, float %119, float %120, float %121, float %122, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %129 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %119)  ; IsFinite(value)
  %130 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %120)  ; IsFinite(value)
  %131 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %121)  ; IsFinite(value)
  %132 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %122)  ; IsFinite(value)
  %133 = and i1 %129, %130
  %134 = and i1 %133, %131
  %135 = and i1 %134, %132
  br i1 %135, label %136, label %153

; <label>:136                                     ; preds = %0
  %137 = fcmp fast oge float %119, 0.000000e+00
  %138 = fcmp fast oge float %120, 0.000000e+00
  %139 = fcmp fast oge float %121, 0.000000e+00
  %140 = fcmp fast oge float %122, 0.000000e+00
  %141 = and i1 %137, %138
  %142 = and i1 %141, %139
  %143 = and i1 %142, %140
  br i1 %143, label %144, label %153

; <label>:144                                     ; preds = %136
  %145 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %128)  ; IsFinite(value)
  %146 = fcmp fast oge float %128, 0x3810000000000000
  %147 = and i1 %146, %145
  br i1 %147, label %148, label %153

; <label>:148                                     ; preds = %144
  %149 = fdiv fast float %119, %128
  %150 = fdiv fast float %120, %128
  %151 = fdiv fast float %121, %128
  %152 = fdiv fast float %122, %128
  br label %162

; <label>:153                                     ; preds = %144, %136, %0
  %154 = icmp eq i32 %127, 0
  %155 = uitofp i1 %154 to float
  %156 = icmp eq i32 %127, 1
  %157 = uitofp i1 %156 to float
  %158 = icmp eq i32 %127, 2
  %159 = uitofp i1 %158 to float
  %160 = icmp eq i32 %127, 3
  %161 = uitofp i1 %160 to float
  br label %162

; <label>:162                                     ; preds = %153, %148
  %163 = phi float [ %149, %148 ], [ %155, %153 ]
  %164 = phi float [ %150, %148 ], [ %157, %153 ]
  %165 = phi float [ %151, %148 ], [ %159, %153 ]
  %166 = phi float [ %152, %148 ], [ %161, %153 ]
  %167 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %64, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %168 = extractvalue %dx.types.ResRet.f32 %167, 0
  %169 = extractvalue %dx.types.ResRet.f32 %167, 1
  %170 = extractvalue %dx.types.ResRet.f32 %167, 2
  %171 = extractvalue %dx.types.ResRet.f32 %167, 3
  %172 = fcmp fast olt float %171, 0.000000e+00
  br i1 %172, label %173, label %175

; <label>:173                                     ; preds = %162
  %174 = fsub fast float -1.000000e+00, %171
  br label %1688

; <label>:175                                     ; preds = %162
  %176 = fcmp fast ogt float %39, 5.000000e-01
  %177 = fcmp fast olt float %83, 1.000000e+00
  %178 = and i1 %176, %177
  br i1 %178, label %179, label %317

; <label>:179                                     ; preds = %175
  %180 = sitofp i32 %64 to float
  %181 = sitofp i32 %65 to float
  %182 = fadd fast float %180, 5.000000e-01
  %183 = fadd fast float %181, 5.000000e-01
  %184 = fdiv fast float %182, %46
  %185 = fdiv fast float %183, %47
  %186 = fmul fast float %184, 2.000000e+00
  %187 = fmul fast float %185, 2.000000e+00
  %188 = fadd fast float %186, -1.000000e+00
  %189 = fsub fast float 1.000000e+00, %187
  %190 = fmul fast float %188, %36
  %191 = call float @dx.op.tertiary.f32(i32 46, float %189, float %32, float %190)  ; FMad(a,b,c)
  %192 = call float @dx.op.tertiary.f32(i32 46, float %83, float %28, float %191)  ; FMad(a,b,c)
  %193 = fadd fast float %192, %24
  %194 = call float @dx.op.unary.f32(i32 6, float %193)  ; FAbs(value)
  %195 = fcmp fast ogt float %194, 0x3EB0C6F7A0000000
  br i1 %195, label %196, label %317

; <label>:196                                     ; preds = %179
  %197 = fmul fast float %188, %35
  %198 = call float @dx.op.tertiary.f32(i32 46, float %189, float %31, float %197)  ; FMad(a,b,c)
  %199 = call float @dx.op.tertiary.f32(i32 46, float %83, float %27, float %198)  ; FMad(a,b,c)
  %200 = fadd fast float %199, %23
  %201 = fmul fast float %188, %34
  %202 = call float @dx.op.tertiary.f32(i32 46, float %189, float %30, float %201)  ; FMad(a,b,c)
  %203 = call float @dx.op.tertiary.f32(i32 46, float %83, float %26, float %202)  ; FMad(a,b,c)
  %204 = fadd fast float %203, %22
  %205 = fmul fast float %188, %33
  %206 = call float @dx.op.tertiary.f32(i32 46, float %189, float %29, float %205)  ; FMad(a,b,c)
  %207 = call float @dx.op.tertiary.f32(i32 46, float %83, float %25, float %206)  ; FMad(a,b,c)
  %208 = fadd fast float %207, %21
  %209 = fdiv fast float %208, %193
  %210 = fdiv fast float %204, %193
  %211 = fdiv fast float %200, %193
  %212 = fsub fast float %209, %18
  %213 = fsub fast float %210, %19
  %214 = fsub fast float %211, %20
  %215 = fmul fast float %212, %212
  %216 = fmul fast float %213, %213
  %217 = fadd fast float %216, %215
  %218 = fmul fast float %214, %214
  %219 = fadd fast float %217, %218
  %220 = call float @dx.op.unary.f32(i32 24, float %219)  ; Sqrt(value)
  %221 = fsub fast float %220, %10
  %222 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %221)  ; FMax(a,b)
  %223 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %223, label %224, label %247

; <label>:224                                     ; preds = %196
  %225 = call float @dx.op.unary.f32(i32 6, float %213)  ; FAbs(value)
  %226 = fmul fast float %225, %12
  %227 = fcmp fast olt float %226, 0x3F50624DE0000000
  br i1 %227, label %228, label %231

; <label>:228                                     ; preds = %224
  %229 = fmul fast float %226, 5.000000e-01
  %230 = fsub fast float 1.000000e+00, %229
  br label %236

; <label>:231                                     ; preds = %224
  %232 = fmul fast float %226, 0xBFF7154760000000
  %233 = call float @dx.op.unary.f32(i32 21, float %232)  ; Exp(value)
  %234 = fsub fast float 1.000000e+00, %233
  %235 = fdiv fast float %234, %226
  br label %236

; <label>:236                                     ; preds = %231, %228
  %237 = phi float [ %230, %228 ], [ %235, %231 ]
  %238 = call float @dx.op.binary.f32(i32 36, float %210, float %19)  ; FMin(a,b)
  %239 = fsub fast float %238, %11
  %240 = fmul fast float %12, %239
  %241 = fsub fast float -0.000000e+00, %240
  %242 = call float @dx.op.binary.f32(i32 35, float %241, float -4.000000e+01)  ; FMax(a,b)
  %243 = call float @dx.op.binary.f32(i32 36, float %242, float 5.000000e+00)  ; FMin(a,b)
  %244 = fmul fast float %243, 0x3FF7154760000000
  %245 = call float @dx.op.unary.f32(i32 21, float %244)  ; Exp(value)
  %246 = fmul fast float %245, %237
  br label %247

; <label>:247                                     ; preds = %236, %196
  %248 = phi float [ %246, %236 ], [ 1.000000e+00, %196 ]
  %249 = fmul fast float %222, %17
  %250 = fmul fast float %249, %248
  %251 = fcmp fast ole float %220, %10
  %252 = fcmp fast olt float %220, 0x3F1A36E2E0000000
  %253 = or i1 %251, %252
  br i1 %253, label %300, label %254

; <label>:254                                     ; preds = %247
  %255 = fdiv fast float %10, %220
  %256 = fmul fast float %255, %212
  %257 = fmul fast float %255, %213
  %258 = fmul fast float %255, %214
  %259 = fadd fast float %256, %18
  %260 = fadd fast float %257, %19
  %261 = fadd fast float %258, %20
  %262 = fadd fast float %259, -9.000000e+02
  %263 = fadd fast float %260, -1.500000e+01
  %264 = fadd fast float %261, -7.500000e+02
  %265 = fmul fast float %262, 0x3F62345680000000
  %266 = fmul fast float %263, 0x3F62345680000000
  %267 = fmul fast float %264, 0x3F62345680000000
  %268 = call float @dx.op.dot3.f32(i32 55, float %265, float %266, float %267, float %265, float %266, float %267)  ; Dot3(ax,ay,az,bx,by,bz)
  %269 = fsub fast float 1.000000e+00, %268
  %270 = call float @dx.op.unary.f32(i32 7, float %269)  ; Saturate(value)
  %271 = fmul fast float %270, %270
  %272 = fadd fast float %259, %209
  %273 = fadd fast float %260, %210
  %274 = fadd fast float %261, %211
  %275 = fmul fast float %272, 0x3F52345680000000
  %276 = fadd fast float %275, -2.000000e+00
  %277 = fmul fast float %273, 0x3F52345680000000
  %278 = fadd fast float %277, 0xBFA1111120000000
  %279 = fmul fast float %274, 0x3F52345680000000
  %280 = fadd fast float %279, 0xBFFAAAAAC0000000
  %281 = call float @dx.op.dot3.f32(i32 55, float %276, float %278, float %280, float %276, float %278, float %280)  ; Dot3(ax,ay,az,bx,by,bz)
  %282 = fsub fast float 1.000000e+00, %281
  %283 = call float @dx.op.unary.f32(i32 7, float %282)  ; Saturate(value)
  %284 = fmul fast float %283, %283
  %285 = fmul fast float %284, 4.000000e+00
  %286 = fadd fast float %285, %271
  %287 = fadd fast float %209, -9.000000e+02
  %288 = fadd fast float %210, -1.500000e+01
  %289 = fadd fast float %211, -7.500000e+02
  %290 = fmul fast float %287, 0x3F62345680000000
  %291 = fmul fast float %288, 0x3F62345680000000
  %292 = fmul fast float %289, 0x3F62345680000000
  %293 = call float @dx.op.dot3.f32(i32 55, float %290, float %291, float %292, float %290, float %291, float %292)  ; Dot3(ax,ay,az,bx,by,bz)
  %294 = fsub fast float 1.000000e+00, %293
  %295 = call float @dx.op.unary.f32(i32 7, float %294)  ; Saturate(value)
  %296 = fmul fast float %295, %295
  %297 = fadd fast float %286, %296
  %298 = fmul fast float %221, 0x3F25D867E0000000
  %299 = fmul fast float %298, %297
  br label %300

; <label>:300                                     ; preds = %254, %247
  %301 = phi float [ %299, %254 ], [ 0.000000e+00, %247 ]
  %302 = fadd fast float %301, %250
  %303 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %302)  ; FMin(a,b)
  %304 = fmul fast float %303, 0xBFF7154760000000
  %305 = call float @dx.op.unary.f32(i32 21, float %304)  ; Exp(value)
  %306 = fsub fast float 1.000000e+00, %305
  %307 = call float @dx.op.binary.f32(i32 36, float %13, float %306)  ; FMin(a,b)
  %308 = fsub fast float %14, %168
  %309 = fsub fast float %15, %169
  %310 = fsub fast float %16, %170
  %311 = fmul fast float %307, %308
  %312 = fmul fast float %307, %309
  %313 = fmul fast float %307, %310
  %314 = fadd fast float %311, %168
  %315 = fadd fast float %312, %169
  %316 = fadd fast float %313, %170
  br label %317

; <label>:317                                     ; preds = %300, %179, %175
  %318 = phi float [ %314, %300 ], [ %168, %179 ], [ %168, %175 ]
  %319 = phi float [ %315, %300 ], [ %169, %179 ], [ %169, %175 ]
  %320 = phi float [ %316, %300 ], [ %170, %179 ], [ %170, %175 ]
  %321 = fadd fast float %6, 1.000000e+00
  %322 = fadd fast float %7, 1.000000e+00
  %323 = fsub fast float 1.000000e+00, %6
  %324 = fmul fast float %37, %321
  %325 = fmul fast float %37, %322
  %326 = fmul fast float %37, %323
  %327 = fmul fast float %324, %318
  %328 = fmul fast float %325, %319
  %329 = fmul fast float %326, %320
  %330 = fcmp fast ult float %38, 5.000000e-01
  br i1 %330, label %356, label %331

; <label>:331                                     ; preds = %317
  %332 = fmul fast float %327, 0x4004147AE0000000
  %333 = fmul fast float %328, 0x4004147AE0000000
  %334 = fmul fast float %329, 0x4004147AE0000000
  %335 = fadd fast float %332, 0x3F9EB851E0000000
  %336 = fadd fast float %333, 0x3F9EB851E0000000
  %337 = fadd fast float %334, 0x3F9EB851E0000000
  %338 = fmul fast float %335, %327
  %339 = fmul fast float %336, %328
  %340 = fmul fast float %337, %329
  %341 = fmul fast float %327, 0x400370A3E0000000
  %342 = fmul fast float %328, 0x400370A3E0000000
  %343 = fmul fast float %329, 0x400370A3E0000000
  %344 = fadd fast float %341, 0x3FE2E147A0000000
  %345 = fadd fast float %342, 0x3FE2E147A0000000
  %346 = fadd fast float %343, 0x3FE2E147A0000000
  %347 = fmul fast float %344, %327
  %348 = fmul fast float %345, %328
  %349 = fmul fast float %346, %329
  %350 = fadd fast float %347, 0x3FC1EB8520000000
  %351 = fadd fast float %348, 0x3FC1EB8520000000
  %352 = fadd fast float %349, 0x3FC1EB8520000000
  %353 = fdiv fast float %338, %350
  %354 = fdiv fast float %339, %351
  %355 = fdiv fast float %340, %352
  br label %356

; <label>:356                                     ; preds = %331, %317
  %357 = phi float [ %353, %331 ], [ %327, %317 ]
  %358 = phi float [ %354, %331 ], [ %328, %317 ]
  %359 = phi float [ %355, %331 ], [ %329, %317 ]
  %360 = call float @dx.op.unary.f32(i32 7, float %357)  ; Saturate(value)
  %361 = call float @dx.op.unary.f32(i32 7, float %358)  ; Saturate(value)
  %362 = call float @dx.op.unary.f32(i32 7, float %359)  ; Saturate(value)
  %363 = call float @dx.op.dot3.f32(i32 55, float %360, float %361, float %362, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %364 = fsub fast float %360, %363
  %365 = fsub fast float %361, %363
  %366 = fsub fast float %362, %363
  %367 = fmul fast float %364, %9
  %368 = fmul fast float %365, %9
  %369 = fmul fast float %366, %9
  %370 = fadd fast float %367, %363
  %371 = fadd fast float %368, %363
  %372 = fadd fast float %369, %363
  %373 = call float @dx.op.unary.f32(i32 7, float %370)  ; Saturate(value)
  %374 = call float @dx.op.unary.f32(i32 7, float %371)  ; Saturate(value)
  %375 = call float @dx.op.unary.f32(i32 7, float %372)  ; Saturate(value)
  %376 = fadd fast float %373, 0xBFC70A3D80000000
  %377 = fadd fast float %374, 0xBFC70A3D80000000
  %378 = fadd fast float %375, 0xBFC70A3D80000000
  %379 = fmul fast float %376, %8
  %380 = fmul fast float %377, %8
  %381 = fmul fast float %378, %8
  %382 = fadd fast float %379, 0x3FC70A3D80000000
  %383 = fadd fast float %380, 0x3FC70A3D80000000
  %384 = fadd fast float %381, 0x3FC70A3D80000000
  %385 = call float @dx.op.unary.f32(i32 7, float %382)  ; Saturate(value)
  %386 = call float @dx.op.unary.f32(i32 7, float %383)  ; Saturate(value)
  %387 = call float @dx.op.unary.f32(i32 7, float %384)  ; Saturate(value)
  %388 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %388, label %389, label %1648

; <label>:389                                     ; preds = %356
  %390 = add i32 %65, -1
  %391 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %392 = call i32 @dx.op.binary.i32(i32 37, i32 %390, i32 0)  ; IMax(a,b)
  %393 = call i32 @dx.op.binary.i32(i32 38, i32 %391, i32 %60)  ; IMin(a,b)
  %394 = call i32 @dx.op.binary.i32(i32 38, i32 %392, i32 %61)  ; IMin(a,b)
  %395 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %393, i32 %394, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %396 = extractvalue %dx.types.ResRet.f32 %395, 0
  %397 = fsub fast float 1.000000e+00, %83
  %398 = fmul fast float %397, 0x3FA99999A0000000
  %399 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %398)  ; FMax(a,b)
  %400 = fsub fast float %396, %83
  %401 = call float @dx.op.unary.f32(i32 6, float %400)  ; FAbs(value)
  %402 = fdiv fast float %401, %399
  %403 = fsub fast float 1.000000e+00, %402
  %404 = call float @dx.op.unary.f32(i32 7, float %403)  ; Saturate(value)
  %405 = fcmp fast ugt float %404, 0.000000e+00
  br i1 %405, label %406, label %679

; <label>:406                                     ; preds = %389
  %407 = call i32 @dx.op.binary.i32(i32 37, i32 %393, i32 0)  ; IMax(a,b)
  %408 = call i32 @dx.op.binary.i32(i32 37, i32 %394, i32 0)  ; IMax(a,b)
  %409 = call i32 @dx.op.binary.i32(i32 38, i32 %407, i32 %60)  ; IMin(a,b)
  %410 = call i32 @dx.op.binary.i32(i32 38, i32 %408, i32 %61)  ; IMin(a,b)
  %411 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %409, i32 %410, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %412 = extractvalue %dx.types.ResRet.f32 %411, 0
  %413 = extractvalue %dx.types.ResRet.f32 %411, 1
  %414 = extractvalue %dx.types.ResRet.f32 %411, 2
  %415 = extractvalue %dx.types.ResRet.f32 %411, 3
  %416 = fcmp fast olt float %415, 0.000000e+00
  br i1 %416, label %417, label %451

; <label>:417                                     ; preds = %406
  %418 = fcmp fast ogt float %412, 0x3FA4B5DCC0000000
  %419 = fcmp fast ogt float %413, 0x3FA4B5DCC0000000
  %420 = fcmp fast ogt float %414, 0x3FA4B5DCC0000000
  %421 = select i1 %418, float 0.000000e+00, float 1.000000e+00
  %422 = select i1 %419, float 0.000000e+00, float 1.000000e+00
  %423 = select i1 %420, float 0.000000e+00, float 1.000000e+00
  %424 = fmul fast float %412, 0x3FB3D07220000000
  %425 = fmul fast float %413, 0x3FB3D07220000000
  %426 = fmul fast float %414, 0x3FB3D07220000000
  %427 = fadd fast float %412, 0x3FAC28F5C0000000
  %428 = fadd fast float %413, 0x3FAC28F5C0000000
  %429 = fadd fast float %414, 0x3FAC28F5C0000000
  %430 = fmul fast float %427, 0x3FEE54EDE0000000
  %431 = fmul fast float %428, 0x3FEE54EDE0000000
  %432 = fmul fast float %429, 0x3FEE54EDE0000000
  %433 = call float @dx.op.unary.f32(i32 23, float %430)  ; Log(value)
  %434 = call float @dx.op.unary.f32(i32 23, float %431)  ; Log(value)
  %435 = call float @dx.op.unary.f32(i32 23, float %432)  ; Log(value)
  %436 = fmul fast float %433, 0x4003333340000000
  %437 = fmul fast float %434, 0x4003333340000000
  %438 = fmul fast float %435, 0x4003333340000000
  %439 = call float @dx.op.unary.f32(i32 21, float %436)  ; Exp(value)
  %440 = call float @dx.op.unary.f32(i32 21, float %437)  ; Exp(value)
  %441 = call float @dx.op.unary.f32(i32 21, float %438)  ; Exp(value)
  %442 = fsub fast float %424, %439
  %443 = fsub fast float %425, %440
  %444 = fsub fast float %426, %441
  %445 = fmul fast float %442, %421
  %446 = fmul fast float %443, %422
  %447 = fmul fast float %444, %423
  %448 = fadd fast float %445, %439
  %449 = fadd fast float %446, %440
  %450 = fadd fast float %447, %441
  br label %666

; <label>:451                                     ; preds = %406
  %452 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %409, i32 %410, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %453 = extractvalue %dx.types.ResRet.f32 %452, 0
  %454 = fcmp fast ogt float %39, 5.000000e-01
  %455 = fcmp fast olt float %453, 1.000000e+00
  %456 = and i1 %454, %455
  br i1 %456, label %457, label %595

; <label>:457                                     ; preds = %451
  %458 = sitofp i32 %409 to float
  %459 = sitofp i32 %410 to float
  %460 = fadd fast float %458, 5.000000e-01
  %461 = fadd fast float %459, 5.000000e-01
  %462 = fdiv fast float %460, %46
  %463 = fdiv fast float %461, %47
  %464 = fmul fast float %462, 2.000000e+00
  %465 = fmul fast float %463, 2.000000e+00
  %466 = fadd fast float %464, -1.000000e+00
  %467 = fsub fast float 1.000000e+00, %465
  %468 = fmul fast float %466, %36
  %469 = call float @dx.op.tertiary.f32(i32 46, float %467, float %32, float %468)  ; FMad(a,b,c)
  %470 = call float @dx.op.tertiary.f32(i32 46, float %453, float %28, float %469)  ; FMad(a,b,c)
  %471 = fadd fast float %470, %24
  %472 = call float @dx.op.unary.f32(i32 6, float %471)  ; FAbs(value)
  %473 = fcmp fast ogt float %472, 0x3EB0C6F7A0000000
  br i1 %473, label %474, label %595

; <label>:474                                     ; preds = %457
  %475 = fmul fast float %466, %35
  %476 = call float @dx.op.tertiary.f32(i32 46, float %467, float %31, float %475)  ; FMad(a,b,c)
  %477 = call float @dx.op.tertiary.f32(i32 46, float %453, float %27, float %476)  ; FMad(a,b,c)
  %478 = fadd fast float %477, %23
  %479 = fmul fast float %466, %34
  %480 = call float @dx.op.tertiary.f32(i32 46, float %467, float %30, float %479)  ; FMad(a,b,c)
  %481 = call float @dx.op.tertiary.f32(i32 46, float %453, float %26, float %480)  ; FMad(a,b,c)
  %482 = fadd fast float %481, %22
  %483 = fmul fast float %466, %33
  %484 = call float @dx.op.tertiary.f32(i32 46, float %467, float %29, float %483)  ; FMad(a,b,c)
  %485 = call float @dx.op.tertiary.f32(i32 46, float %453, float %25, float %484)  ; FMad(a,b,c)
  %486 = fadd fast float %485, %21
  %487 = fdiv fast float %486, %471
  %488 = fdiv fast float %482, %471
  %489 = fdiv fast float %478, %471
  %490 = fsub fast float %487, %18
  %491 = fsub fast float %488, %19
  %492 = fsub fast float %489, %20
  %493 = fmul fast float %490, %490
  %494 = fmul fast float %491, %491
  %495 = fadd fast float %494, %493
  %496 = fmul fast float %492, %492
  %497 = fadd fast float %495, %496
  %498 = call float @dx.op.unary.f32(i32 24, float %497)  ; Sqrt(value)
  %499 = fsub fast float %498, %10
  %500 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %499)  ; FMax(a,b)
  %501 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %501, label %502, label %525

; <label>:502                                     ; preds = %474
  %503 = call float @dx.op.unary.f32(i32 6, float %491)  ; FAbs(value)
  %504 = fmul fast float %503, %12
  %505 = fcmp fast olt float %504, 0x3F50624DE0000000
  br i1 %505, label %506, label %509

; <label>:506                                     ; preds = %502
  %507 = fmul fast float %504, 5.000000e-01
  %508 = fsub fast float 1.000000e+00, %507
  br label %514

; <label>:509                                     ; preds = %502
  %510 = fmul fast float %504, 0xBFF7154760000000
  %511 = call float @dx.op.unary.f32(i32 21, float %510)  ; Exp(value)
  %512 = fsub fast float 1.000000e+00, %511
  %513 = fdiv fast float %512, %504
  br label %514

; <label>:514                                     ; preds = %509, %506
  %515 = phi float [ %508, %506 ], [ %513, %509 ]
  %516 = call float @dx.op.binary.f32(i32 36, float %488, float %19)  ; FMin(a,b)
  %517 = fsub fast float %516, %11
  %518 = fmul fast float %12, %517
  %519 = fsub fast float -0.000000e+00, %518
  %520 = call float @dx.op.binary.f32(i32 35, float %519, float -4.000000e+01)  ; FMax(a,b)
  %521 = call float @dx.op.binary.f32(i32 36, float %520, float 5.000000e+00)  ; FMin(a,b)
  %522 = fmul fast float %521, 0x3FF7154760000000
  %523 = call float @dx.op.unary.f32(i32 21, float %522)  ; Exp(value)
  %524 = fmul fast float %523, %515
  br label %525

; <label>:525                                     ; preds = %514, %474
  %526 = phi float [ %524, %514 ], [ 1.000000e+00, %474 ]
  %527 = fmul fast float %500, %17
  %528 = fmul fast float %527, %526
  %529 = fcmp fast ole float %498, %10
  %530 = fcmp fast olt float %498, 0x3F1A36E2E0000000
  %531 = or i1 %529, %530
  br i1 %531, label %578, label %532

; <label>:532                                     ; preds = %525
  %533 = fdiv fast float %10, %498
  %534 = fmul fast float %533, %490
  %535 = fmul fast float %533, %491
  %536 = fmul fast float %533, %492
  %537 = fadd fast float %534, %18
  %538 = fadd fast float %535, %19
  %539 = fadd fast float %536, %20
  %540 = fadd fast float %537, -9.000000e+02
  %541 = fadd fast float %538, -1.500000e+01
  %542 = fadd fast float %539, -7.500000e+02
  %543 = fmul fast float %540, 0x3F62345680000000
  %544 = fmul fast float %541, 0x3F62345680000000
  %545 = fmul fast float %542, 0x3F62345680000000
  %546 = call float @dx.op.dot3.f32(i32 55, float %543, float %544, float %545, float %543, float %544, float %545)  ; Dot3(ax,ay,az,bx,by,bz)
  %547 = fsub fast float 1.000000e+00, %546
  %548 = call float @dx.op.unary.f32(i32 7, float %547)  ; Saturate(value)
  %549 = fmul fast float %548, %548
  %550 = fadd fast float %537, %487
  %551 = fadd fast float %538, %488
  %552 = fadd fast float %539, %489
  %553 = fmul fast float %550, 0x3F52345680000000
  %554 = fadd fast float %553, -2.000000e+00
  %555 = fmul fast float %551, 0x3F52345680000000
  %556 = fadd fast float %555, 0xBFA1111120000000
  %557 = fmul fast float %552, 0x3F52345680000000
  %558 = fadd fast float %557, 0xBFFAAAAAC0000000
  %559 = call float @dx.op.dot3.f32(i32 55, float %554, float %556, float %558, float %554, float %556, float %558)  ; Dot3(ax,ay,az,bx,by,bz)
  %560 = fsub fast float 1.000000e+00, %559
  %561 = call float @dx.op.unary.f32(i32 7, float %560)  ; Saturate(value)
  %562 = fmul fast float %561, %561
  %563 = fmul fast float %562, 4.000000e+00
  %564 = fadd fast float %563, %549
  %565 = fadd fast float %487, -9.000000e+02
  %566 = fadd fast float %488, -1.500000e+01
  %567 = fadd fast float %489, -7.500000e+02
  %568 = fmul fast float %565, 0x3F62345680000000
  %569 = fmul fast float %566, 0x3F62345680000000
  %570 = fmul fast float %567, 0x3F62345680000000
  %571 = call float @dx.op.dot3.f32(i32 55, float %568, float %569, float %570, float %568, float %569, float %570)  ; Dot3(ax,ay,az,bx,by,bz)
  %572 = fsub fast float 1.000000e+00, %571
  %573 = call float @dx.op.unary.f32(i32 7, float %572)  ; Saturate(value)
  %574 = fmul fast float %573, %573
  %575 = fadd fast float %564, %574
  %576 = fmul fast float %499, 0x3F25D867E0000000
  %577 = fmul fast float %576, %575
  br label %578

; <label>:578                                     ; preds = %532, %525
  %579 = phi float [ %577, %532 ], [ 0.000000e+00, %525 ]
  %580 = fadd fast float %579, %528
  %581 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %580)  ; FMin(a,b)
  %582 = fmul fast float %581, 0xBFF7154760000000
  %583 = call float @dx.op.unary.f32(i32 21, float %582)  ; Exp(value)
  %584 = fsub fast float 1.000000e+00, %583
  %585 = call float @dx.op.binary.f32(i32 36, float %13, float %584)  ; FMin(a,b)
  %586 = fsub fast float %14, %412
  %587 = fsub fast float %15, %413
  %588 = fsub fast float %16, %414
  %589 = fmul fast float %585, %586
  %590 = fmul fast float %585, %587
  %591 = fmul fast float %585, %588
  %592 = fadd fast float %589, %412
  %593 = fadd fast float %590, %413
  %594 = fadd fast float %591, %414
  br label %595

; <label>:595                                     ; preds = %578, %457, %451
  %596 = phi float [ %592, %578 ], [ %412, %457 ], [ %412, %451 ]
  %597 = phi float [ %593, %578 ], [ %413, %457 ], [ %413, %451 ]
  %598 = phi float [ %594, %578 ], [ %414, %457 ], [ %414, %451 ]
  %599 = fadd fast float %6, 1.000000e+00
  %600 = fadd fast float %7, 1.000000e+00
  %601 = fsub fast float 1.000000e+00, %6
  %602 = fmul fast float %37, %599
  %603 = fmul fast float %37, %600
  %604 = fmul fast float %37, %601
  %605 = fmul fast float %602, %596
  %606 = fmul fast float %603, %597
  %607 = fmul fast float %604, %598
  %608 = fcmp fast ult float %38, 5.000000e-01
  br i1 %608, label %634, label %609

; <label>:609                                     ; preds = %595
  %610 = fmul fast float %605, 0x4004147AE0000000
  %611 = fmul fast float %606, 0x4004147AE0000000
  %612 = fmul fast float %607, 0x4004147AE0000000
  %613 = fadd fast float %610, 0x3F9EB851E0000000
  %614 = fadd fast float %611, 0x3F9EB851E0000000
  %615 = fadd fast float %612, 0x3F9EB851E0000000
  %616 = fmul fast float %613, %605
  %617 = fmul fast float %614, %606
  %618 = fmul fast float %615, %607
  %619 = fmul fast float %605, 0x400370A3E0000000
  %620 = fmul fast float %606, 0x400370A3E0000000
  %621 = fmul fast float %607, 0x400370A3E0000000
  %622 = fadd fast float %619, 0x3FE2E147A0000000
  %623 = fadd fast float %620, 0x3FE2E147A0000000
  %624 = fadd fast float %621, 0x3FE2E147A0000000
  %625 = fmul fast float %622, %605
  %626 = fmul fast float %623, %606
  %627 = fmul fast float %624, %607
  %628 = fadd fast float %625, 0x3FC1EB8520000000
  %629 = fadd fast float %626, 0x3FC1EB8520000000
  %630 = fadd fast float %627, 0x3FC1EB8520000000
  %631 = fdiv fast float %616, %628
  %632 = fdiv fast float %617, %629
  %633 = fdiv fast float %618, %630
  br label %634

; <label>:634                                     ; preds = %609, %595
  %635 = phi float [ %631, %609 ], [ %605, %595 ]
  %636 = phi float [ %632, %609 ], [ %606, %595 ]
  %637 = phi float [ %633, %609 ], [ %607, %595 ]
  %638 = call float @dx.op.unary.f32(i32 7, float %635)  ; Saturate(value)
  %639 = call float @dx.op.unary.f32(i32 7, float %636)  ; Saturate(value)
  %640 = call float @dx.op.unary.f32(i32 7, float %637)  ; Saturate(value)
  %641 = call float @dx.op.dot3.f32(i32 55, float %638, float %639, float %640, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %642 = fsub fast float %638, %641
  %643 = fsub fast float %639, %641
  %644 = fsub fast float %640, %641
  %645 = fmul fast float %642, %9
  %646 = fmul fast float %643, %9
  %647 = fmul fast float %644, %9
  %648 = fadd fast float %645, %641
  %649 = fadd fast float %646, %641
  %650 = fadd fast float %647, %641
  %651 = call float @dx.op.unary.f32(i32 7, float %648)  ; Saturate(value)
  %652 = call float @dx.op.unary.f32(i32 7, float %649)  ; Saturate(value)
  %653 = call float @dx.op.unary.f32(i32 7, float %650)  ; Saturate(value)
  %654 = fadd fast float %651, 0xBFC70A3D80000000
  %655 = fadd fast float %652, 0xBFC70A3D80000000
  %656 = fadd fast float %653, 0xBFC70A3D80000000
  %657 = fmul fast float %654, %8
  %658 = fmul fast float %655, %8
  %659 = fmul fast float %656, %8
  %660 = fadd fast float %657, 0x3FC70A3D80000000
  %661 = fadd fast float %658, 0x3FC70A3D80000000
  %662 = fadd fast float %659, 0x3FC70A3D80000000
  %663 = call float @dx.op.unary.f32(i32 7, float %660)  ; Saturate(value)
  %664 = call float @dx.op.unary.f32(i32 7, float %661)  ; Saturate(value)
  %665 = call float @dx.op.unary.f32(i32 7, float %662)  ; Saturate(value)
  br label %666

; <label>:666                                     ; preds = %634, %417
  %667 = phi float [ %448, %417 ], [ %663, %634 ]
  %668 = phi float [ %449, %417 ], [ %664, %634 ]
  %669 = phi float [ %450, %417 ], [ %665, %634 ]
  %670 = fsub fast float %667, %385
  %671 = fsub fast float %668, %386
  %672 = fsub fast float %669, %387
  %673 = fmul fast float %670, %404
  %674 = fmul fast float %671, %404
  %675 = fmul fast float %672, %404
  %676 = fadd fast float %673, %385
  %677 = fadd fast float %674, %386
  %678 = fadd fast float %675, %387
  br label %679

; <label>:679                                     ; preds = %666, %389
  %680 = phi float [ %676, %666 ], [ %385, %389 ]
  %681 = phi float [ %677, %666 ], [ %386, %389 ]
  %682 = phi float [ %678, %666 ], [ %387, %389 ]
  %683 = add i32 %65, 1
  %684 = call i32 @dx.op.binary.i32(i32 37, i32 %683, i32 0)  ; IMax(a,b)
  %685 = call i32 @dx.op.binary.i32(i32 38, i32 %684, i32 %61)  ; IMin(a,b)
  %686 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %393, i32 %685, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %687 = extractvalue %dx.types.ResRet.f32 %686, 0
  %688 = fsub fast float %687, %83
  %689 = call float @dx.op.unary.f32(i32 6, float %688)  ; FAbs(value)
  %690 = fdiv fast float %689, %399
  %691 = fsub fast float 1.000000e+00, %690
  %692 = call float @dx.op.unary.f32(i32 7, float %691)  ; Saturate(value)
  %693 = fcmp fast ugt float %692, 0.000000e+00
  br i1 %693, label %694, label %967

; <label>:694                                     ; preds = %679
  %695 = call i32 @dx.op.binary.i32(i32 37, i32 %393, i32 0)  ; IMax(a,b)
  %696 = call i32 @dx.op.binary.i32(i32 37, i32 %685, i32 0)  ; IMax(a,b)
  %697 = call i32 @dx.op.binary.i32(i32 38, i32 %695, i32 %60)  ; IMin(a,b)
  %698 = call i32 @dx.op.binary.i32(i32 38, i32 %696, i32 %61)  ; IMin(a,b)
  %699 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %697, i32 %698, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %700 = extractvalue %dx.types.ResRet.f32 %699, 0
  %701 = extractvalue %dx.types.ResRet.f32 %699, 1
  %702 = extractvalue %dx.types.ResRet.f32 %699, 2
  %703 = extractvalue %dx.types.ResRet.f32 %699, 3
  %704 = fcmp fast olt float %703, 0.000000e+00
  br i1 %704, label %705, label %739

; <label>:705                                     ; preds = %694
  %706 = fcmp fast ogt float %700, 0x3FA4B5DCC0000000
  %707 = fcmp fast ogt float %701, 0x3FA4B5DCC0000000
  %708 = fcmp fast ogt float %702, 0x3FA4B5DCC0000000
  %709 = select i1 %706, float 0.000000e+00, float 1.000000e+00
  %710 = select i1 %707, float 0.000000e+00, float 1.000000e+00
  %711 = select i1 %708, float 0.000000e+00, float 1.000000e+00
  %712 = fmul fast float %700, 0x3FB3D07220000000
  %713 = fmul fast float %701, 0x3FB3D07220000000
  %714 = fmul fast float %702, 0x3FB3D07220000000
  %715 = fadd fast float %700, 0x3FAC28F5C0000000
  %716 = fadd fast float %701, 0x3FAC28F5C0000000
  %717 = fadd fast float %702, 0x3FAC28F5C0000000
  %718 = fmul fast float %715, 0x3FEE54EDE0000000
  %719 = fmul fast float %716, 0x3FEE54EDE0000000
  %720 = fmul fast float %717, 0x3FEE54EDE0000000
  %721 = call float @dx.op.unary.f32(i32 23, float %718)  ; Log(value)
  %722 = call float @dx.op.unary.f32(i32 23, float %719)  ; Log(value)
  %723 = call float @dx.op.unary.f32(i32 23, float %720)  ; Log(value)
  %724 = fmul fast float %721, 0x4003333340000000
  %725 = fmul fast float %722, 0x4003333340000000
  %726 = fmul fast float %723, 0x4003333340000000
  %727 = call float @dx.op.unary.f32(i32 21, float %724)  ; Exp(value)
  %728 = call float @dx.op.unary.f32(i32 21, float %725)  ; Exp(value)
  %729 = call float @dx.op.unary.f32(i32 21, float %726)  ; Exp(value)
  %730 = fsub fast float %712, %727
  %731 = fsub fast float %713, %728
  %732 = fsub fast float %714, %729
  %733 = fmul fast float %730, %709
  %734 = fmul fast float %731, %710
  %735 = fmul fast float %732, %711
  %736 = fadd fast float %733, %727
  %737 = fadd fast float %734, %728
  %738 = fadd fast float %735, %729
  br label %954

; <label>:739                                     ; preds = %694
  %740 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %697, i32 %698, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %741 = extractvalue %dx.types.ResRet.f32 %740, 0
  %742 = fcmp fast ogt float %39, 5.000000e-01
  %743 = fcmp fast olt float %741, 1.000000e+00
  %744 = and i1 %742, %743
  br i1 %744, label %745, label %883

; <label>:745                                     ; preds = %739
  %746 = sitofp i32 %697 to float
  %747 = sitofp i32 %698 to float
  %748 = fadd fast float %746, 5.000000e-01
  %749 = fadd fast float %747, 5.000000e-01
  %750 = fdiv fast float %748, %46
  %751 = fdiv fast float %749, %47
  %752 = fmul fast float %750, 2.000000e+00
  %753 = fmul fast float %751, 2.000000e+00
  %754 = fadd fast float %752, -1.000000e+00
  %755 = fsub fast float 1.000000e+00, %753
  %756 = fmul fast float %754, %36
  %757 = call float @dx.op.tertiary.f32(i32 46, float %755, float %32, float %756)  ; FMad(a,b,c)
  %758 = call float @dx.op.tertiary.f32(i32 46, float %741, float %28, float %757)  ; FMad(a,b,c)
  %759 = fadd fast float %758, %24
  %760 = call float @dx.op.unary.f32(i32 6, float %759)  ; FAbs(value)
  %761 = fcmp fast ogt float %760, 0x3EB0C6F7A0000000
  br i1 %761, label %762, label %883

; <label>:762                                     ; preds = %745
  %763 = fmul fast float %754, %35
  %764 = call float @dx.op.tertiary.f32(i32 46, float %755, float %31, float %763)  ; FMad(a,b,c)
  %765 = call float @dx.op.tertiary.f32(i32 46, float %741, float %27, float %764)  ; FMad(a,b,c)
  %766 = fadd fast float %765, %23
  %767 = fmul fast float %754, %34
  %768 = call float @dx.op.tertiary.f32(i32 46, float %755, float %30, float %767)  ; FMad(a,b,c)
  %769 = call float @dx.op.tertiary.f32(i32 46, float %741, float %26, float %768)  ; FMad(a,b,c)
  %770 = fadd fast float %769, %22
  %771 = fmul fast float %754, %33
  %772 = call float @dx.op.tertiary.f32(i32 46, float %755, float %29, float %771)  ; FMad(a,b,c)
  %773 = call float @dx.op.tertiary.f32(i32 46, float %741, float %25, float %772)  ; FMad(a,b,c)
  %774 = fadd fast float %773, %21
  %775 = fdiv fast float %774, %759
  %776 = fdiv fast float %770, %759
  %777 = fdiv fast float %766, %759
  %778 = fsub fast float %775, %18
  %779 = fsub fast float %776, %19
  %780 = fsub fast float %777, %20
  %781 = fmul fast float %778, %778
  %782 = fmul fast float %779, %779
  %783 = fadd fast float %782, %781
  %784 = fmul fast float %780, %780
  %785 = fadd fast float %783, %784
  %786 = call float @dx.op.unary.f32(i32 24, float %785)  ; Sqrt(value)
  %787 = fsub fast float %786, %10
  %788 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %787)  ; FMax(a,b)
  %789 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %789, label %790, label %813

; <label>:790                                     ; preds = %762
  %791 = call float @dx.op.unary.f32(i32 6, float %779)  ; FAbs(value)
  %792 = fmul fast float %791, %12
  %793 = fcmp fast olt float %792, 0x3F50624DE0000000
  br i1 %793, label %794, label %797

; <label>:794                                     ; preds = %790
  %795 = fmul fast float %792, 5.000000e-01
  %796 = fsub fast float 1.000000e+00, %795
  br label %802

; <label>:797                                     ; preds = %790
  %798 = fmul fast float %792, 0xBFF7154760000000
  %799 = call float @dx.op.unary.f32(i32 21, float %798)  ; Exp(value)
  %800 = fsub fast float 1.000000e+00, %799
  %801 = fdiv fast float %800, %792
  br label %802

; <label>:802                                     ; preds = %797, %794
  %803 = phi float [ %796, %794 ], [ %801, %797 ]
  %804 = call float @dx.op.binary.f32(i32 36, float %776, float %19)  ; FMin(a,b)
  %805 = fsub fast float %804, %11
  %806 = fmul fast float %12, %805
  %807 = fsub fast float -0.000000e+00, %806
  %808 = call float @dx.op.binary.f32(i32 35, float %807, float -4.000000e+01)  ; FMax(a,b)
  %809 = call float @dx.op.binary.f32(i32 36, float %808, float 5.000000e+00)  ; FMin(a,b)
  %810 = fmul fast float %809, 0x3FF7154760000000
  %811 = call float @dx.op.unary.f32(i32 21, float %810)  ; Exp(value)
  %812 = fmul fast float %811, %803
  br label %813

; <label>:813                                     ; preds = %802, %762
  %814 = phi float [ %812, %802 ], [ 1.000000e+00, %762 ]
  %815 = fmul fast float %788, %17
  %816 = fmul fast float %815, %814
  %817 = fcmp fast ole float %786, %10
  %818 = fcmp fast olt float %786, 0x3F1A36E2E0000000
  %819 = or i1 %817, %818
  br i1 %819, label %866, label %820

; <label>:820                                     ; preds = %813
  %821 = fdiv fast float %10, %786
  %822 = fmul fast float %821, %778
  %823 = fmul fast float %821, %779
  %824 = fmul fast float %821, %780
  %825 = fadd fast float %822, %18
  %826 = fadd fast float %823, %19
  %827 = fadd fast float %824, %20
  %828 = fadd fast float %825, -9.000000e+02
  %829 = fadd fast float %826, -1.500000e+01
  %830 = fadd fast float %827, -7.500000e+02
  %831 = fmul fast float %828, 0x3F62345680000000
  %832 = fmul fast float %829, 0x3F62345680000000
  %833 = fmul fast float %830, 0x3F62345680000000
  %834 = call float @dx.op.dot3.f32(i32 55, float %831, float %832, float %833, float %831, float %832, float %833)  ; Dot3(ax,ay,az,bx,by,bz)
  %835 = fsub fast float 1.000000e+00, %834
  %836 = call float @dx.op.unary.f32(i32 7, float %835)  ; Saturate(value)
  %837 = fmul fast float %836, %836
  %838 = fadd fast float %825, %775
  %839 = fadd fast float %826, %776
  %840 = fadd fast float %827, %777
  %841 = fmul fast float %838, 0x3F52345680000000
  %842 = fadd fast float %841, -2.000000e+00
  %843 = fmul fast float %839, 0x3F52345680000000
  %844 = fadd fast float %843, 0xBFA1111120000000
  %845 = fmul fast float %840, 0x3F52345680000000
  %846 = fadd fast float %845, 0xBFFAAAAAC0000000
  %847 = call float @dx.op.dot3.f32(i32 55, float %842, float %844, float %846, float %842, float %844, float %846)  ; Dot3(ax,ay,az,bx,by,bz)
  %848 = fsub fast float 1.000000e+00, %847
  %849 = call float @dx.op.unary.f32(i32 7, float %848)  ; Saturate(value)
  %850 = fmul fast float %849, %849
  %851 = fmul fast float %850, 4.000000e+00
  %852 = fadd fast float %851, %837
  %853 = fadd fast float %775, -9.000000e+02
  %854 = fadd fast float %776, -1.500000e+01
  %855 = fadd fast float %777, -7.500000e+02
  %856 = fmul fast float %853, 0x3F62345680000000
  %857 = fmul fast float %854, 0x3F62345680000000
  %858 = fmul fast float %855, 0x3F62345680000000
  %859 = call float @dx.op.dot3.f32(i32 55, float %856, float %857, float %858, float %856, float %857, float %858)  ; Dot3(ax,ay,az,bx,by,bz)
  %860 = fsub fast float 1.000000e+00, %859
  %861 = call float @dx.op.unary.f32(i32 7, float %860)  ; Saturate(value)
  %862 = fmul fast float %861, %861
  %863 = fadd fast float %852, %862
  %864 = fmul fast float %787, 0x3F25D867E0000000
  %865 = fmul fast float %864, %863
  br label %866

; <label>:866                                     ; preds = %820, %813
  %867 = phi float [ %865, %820 ], [ 0.000000e+00, %813 ]
  %868 = fadd fast float %867, %816
  %869 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %868)  ; FMin(a,b)
  %870 = fmul fast float %869, 0xBFF7154760000000
  %871 = call float @dx.op.unary.f32(i32 21, float %870)  ; Exp(value)
  %872 = fsub fast float 1.000000e+00, %871
  %873 = call float @dx.op.binary.f32(i32 36, float %13, float %872)  ; FMin(a,b)
  %874 = fsub fast float %14, %700
  %875 = fsub fast float %15, %701
  %876 = fsub fast float %16, %702
  %877 = fmul fast float %873, %874
  %878 = fmul fast float %873, %875
  %879 = fmul fast float %873, %876
  %880 = fadd fast float %877, %700
  %881 = fadd fast float %878, %701
  %882 = fadd fast float %879, %702
  br label %883

; <label>:883                                     ; preds = %866, %745, %739
  %884 = phi float [ %880, %866 ], [ %700, %745 ], [ %700, %739 ]
  %885 = phi float [ %881, %866 ], [ %701, %745 ], [ %701, %739 ]
  %886 = phi float [ %882, %866 ], [ %702, %745 ], [ %702, %739 ]
  %887 = fadd fast float %6, 1.000000e+00
  %888 = fadd fast float %7, 1.000000e+00
  %889 = fsub fast float 1.000000e+00, %6
  %890 = fmul fast float %37, %887
  %891 = fmul fast float %37, %888
  %892 = fmul fast float %37, %889
  %893 = fmul fast float %890, %884
  %894 = fmul fast float %891, %885
  %895 = fmul fast float %892, %886
  %896 = fcmp fast ult float %38, 5.000000e-01
  br i1 %896, label %922, label %897

; <label>:897                                     ; preds = %883
  %898 = fmul fast float %893, 0x4004147AE0000000
  %899 = fmul fast float %894, 0x4004147AE0000000
  %900 = fmul fast float %895, 0x4004147AE0000000
  %901 = fadd fast float %898, 0x3F9EB851E0000000
  %902 = fadd fast float %899, 0x3F9EB851E0000000
  %903 = fadd fast float %900, 0x3F9EB851E0000000
  %904 = fmul fast float %901, %893
  %905 = fmul fast float %902, %894
  %906 = fmul fast float %903, %895
  %907 = fmul fast float %893, 0x400370A3E0000000
  %908 = fmul fast float %894, 0x400370A3E0000000
  %909 = fmul fast float %895, 0x400370A3E0000000
  %910 = fadd fast float %907, 0x3FE2E147A0000000
  %911 = fadd fast float %908, 0x3FE2E147A0000000
  %912 = fadd fast float %909, 0x3FE2E147A0000000
  %913 = fmul fast float %910, %893
  %914 = fmul fast float %911, %894
  %915 = fmul fast float %912, %895
  %916 = fadd fast float %913, 0x3FC1EB8520000000
  %917 = fadd fast float %914, 0x3FC1EB8520000000
  %918 = fadd fast float %915, 0x3FC1EB8520000000
  %919 = fdiv fast float %904, %916
  %920 = fdiv fast float %905, %917
  %921 = fdiv fast float %906, %918
  br label %922

; <label>:922                                     ; preds = %897, %883
  %923 = phi float [ %919, %897 ], [ %893, %883 ]
  %924 = phi float [ %920, %897 ], [ %894, %883 ]
  %925 = phi float [ %921, %897 ], [ %895, %883 ]
  %926 = call float @dx.op.unary.f32(i32 7, float %923)  ; Saturate(value)
  %927 = call float @dx.op.unary.f32(i32 7, float %924)  ; Saturate(value)
  %928 = call float @dx.op.unary.f32(i32 7, float %925)  ; Saturate(value)
  %929 = call float @dx.op.dot3.f32(i32 55, float %926, float %927, float %928, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %930 = fsub fast float %926, %929
  %931 = fsub fast float %927, %929
  %932 = fsub fast float %928, %929
  %933 = fmul fast float %930, %9
  %934 = fmul fast float %931, %9
  %935 = fmul fast float %932, %9
  %936 = fadd fast float %933, %929
  %937 = fadd fast float %934, %929
  %938 = fadd fast float %935, %929
  %939 = call float @dx.op.unary.f32(i32 7, float %936)  ; Saturate(value)
  %940 = call float @dx.op.unary.f32(i32 7, float %937)  ; Saturate(value)
  %941 = call float @dx.op.unary.f32(i32 7, float %938)  ; Saturate(value)
  %942 = fadd fast float %939, 0xBFC70A3D80000000
  %943 = fadd fast float %940, 0xBFC70A3D80000000
  %944 = fadd fast float %941, 0xBFC70A3D80000000
  %945 = fmul fast float %942, %8
  %946 = fmul fast float %943, %8
  %947 = fmul fast float %944, %8
  %948 = fadd fast float %945, 0x3FC70A3D80000000
  %949 = fadd fast float %946, 0x3FC70A3D80000000
  %950 = fadd fast float %947, 0x3FC70A3D80000000
  %951 = call float @dx.op.unary.f32(i32 7, float %948)  ; Saturate(value)
  %952 = call float @dx.op.unary.f32(i32 7, float %949)  ; Saturate(value)
  %953 = call float @dx.op.unary.f32(i32 7, float %950)  ; Saturate(value)
  br label %954

; <label>:954                                     ; preds = %922, %705
  %955 = phi float [ %736, %705 ], [ %951, %922 ]
  %956 = phi float [ %737, %705 ], [ %952, %922 ]
  %957 = phi float [ %738, %705 ], [ %953, %922 ]
  %958 = fsub fast float %955, %385
  %959 = fsub fast float %956, %386
  %960 = fsub fast float %957, %387
  %961 = fmul fast float %958, %692
  %962 = fmul fast float %959, %692
  %963 = fmul fast float %960, %692
  %964 = fadd fast float %961, %385
  %965 = fadd fast float %962, %386
  %966 = fadd fast float %963, %387
  br label %967

; <label>:967                                     ; preds = %954, %679
  %968 = phi float [ %964, %954 ], [ %385, %679 ]
  %969 = phi float [ %965, %954 ], [ %386, %679 ]
  %970 = phi float [ %966, %954 ], [ %387, %679 ]
  %971 = add i32 %64, -1
  %972 = call i32 @dx.op.binary.i32(i32 37, i32 %971, i32 0)  ; IMax(a,b)
  %973 = call i32 @dx.op.binary.i32(i32 37, i32 %65, i32 0)  ; IMax(a,b)
  %974 = call i32 @dx.op.binary.i32(i32 38, i32 %972, i32 %60)  ; IMin(a,b)
  %975 = call i32 @dx.op.binary.i32(i32 38, i32 %973, i32 %61)  ; IMin(a,b)
  %976 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %974, i32 %975, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %977 = extractvalue %dx.types.ResRet.f32 %976, 0
  %978 = fsub fast float %977, %83
  %979 = call float @dx.op.unary.f32(i32 6, float %978)  ; FAbs(value)
  %980 = fdiv fast float %979, %399
  %981 = fsub fast float 1.000000e+00, %980
  %982 = call float @dx.op.unary.f32(i32 7, float %981)  ; Saturate(value)
  %983 = fcmp fast ugt float %982, 0.000000e+00
  br i1 %983, label %984, label %1257

; <label>:984                                     ; preds = %967
  %985 = call i32 @dx.op.binary.i32(i32 37, i32 %974, i32 0)  ; IMax(a,b)
  %986 = call i32 @dx.op.binary.i32(i32 37, i32 %975, i32 0)  ; IMax(a,b)
  %987 = call i32 @dx.op.binary.i32(i32 38, i32 %985, i32 %60)  ; IMin(a,b)
  %988 = call i32 @dx.op.binary.i32(i32 38, i32 %986, i32 %61)  ; IMin(a,b)
  %989 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %987, i32 %988, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %990 = extractvalue %dx.types.ResRet.f32 %989, 0
  %991 = extractvalue %dx.types.ResRet.f32 %989, 1
  %992 = extractvalue %dx.types.ResRet.f32 %989, 2
  %993 = extractvalue %dx.types.ResRet.f32 %989, 3
  %994 = fcmp fast olt float %993, 0.000000e+00
  br i1 %994, label %995, label %1029

; <label>:995                                     ; preds = %984
  %996 = fcmp fast ogt float %990, 0x3FA4B5DCC0000000
  %997 = fcmp fast ogt float %991, 0x3FA4B5DCC0000000
  %998 = fcmp fast ogt float %992, 0x3FA4B5DCC0000000
  %999 = select i1 %996, float 0.000000e+00, float 1.000000e+00
  %1000 = select i1 %997, float 0.000000e+00, float 1.000000e+00
  %1001 = select i1 %998, float 0.000000e+00, float 1.000000e+00
  %1002 = fmul fast float %990, 0x3FB3D07220000000
  %1003 = fmul fast float %991, 0x3FB3D07220000000
  %1004 = fmul fast float %992, 0x3FB3D07220000000
  %1005 = fadd fast float %990, 0x3FAC28F5C0000000
  %1006 = fadd fast float %991, 0x3FAC28F5C0000000
  %1007 = fadd fast float %992, 0x3FAC28F5C0000000
  %1008 = fmul fast float %1005, 0x3FEE54EDE0000000
  %1009 = fmul fast float %1006, 0x3FEE54EDE0000000
  %1010 = fmul fast float %1007, 0x3FEE54EDE0000000
  %1011 = call float @dx.op.unary.f32(i32 23, float %1008)  ; Log(value)
  %1012 = call float @dx.op.unary.f32(i32 23, float %1009)  ; Log(value)
  %1013 = call float @dx.op.unary.f32(i32 23, float %1010)  ; Log(value)
  %1014 = fmul fast float %1011, 0x4003333340000000
  %1015 = fmul fast float %1012, 0x4003333340000000
  %1016 = fmul fast float %1013, 0x4003333340000000
  %1017 = call float @dx.op.unary.f32(i32 21, float %1014)  ; Exp(value)
  %1018 = call float @dx.op.unary.f32(i32 21, float %1015)  ; Exp(value)
  %1019 = call float @dx.op.unary.f32(i32 21, float %1016)  ; Exp(value)
  %1020 = fsub fast float %1002, %1017
  %1021 = fsub fast float %1003, %1018
  %1022 = fsub fast float %1004, %1019
  %1023 = fmul fast float %1020, %999
  %1024 = fmul fast float %1021, %1000
  %1025 = fmul fast float %1022, %1001
  %1026 = fadd fast float %1023, %1017
  %1027 = fadd fast float %1024, %1018
  %1028 = fadd fast float %1025, %1019
  br label %1244

; <label>:1029                                    ; preds = %984
  %1030 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %987, i32 %988, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1031 = extractvalue %dx.types.ResRet.f32 %1030, 0
  %1032 = fcmp fast ogt float %39, 5.000000e-01
  %1033 = fcmp fast olt float %1031, 1.000000e+00
  %1034 = and i1 %1032, %1033
  br i1 %1034, label %1035, label %1173

; <label>:1035                                    ; preds = %1029
  %1036 = sitofp i32 %987 to float
  %1037 = sitofp i32 %988 to float
  %1038 = fadd fast float %1036, 5.000000e-01
  %1039 = fadd fast float %1037, 5.000000e-01
  %1040 = fdiv fast float %1038, %46
  %1041 = fdiv fast float %1039, %47
  %1042 = fmul fast float %1040, 2.000000e+00
  %1043 = fmul fast float %1041, 2.000000e+00
  %1044 = fadd fast float %1042, -1.000000e+00
  %1045 = fsub fast float 1.000000e+00, %1043
  %1046 = fmul fast float %1044, %36
  %1047 = call float @dx.op.tertiary.f32(i32 46, float %1045, float %32, float %1046)  ; FMad(a,b,c)
  %1048 = call float @dx.op.tertiary.f32(i32 46, float %1031, float %28, float %1047)  ; FMad(a,b,c)
  %1049 = fadd fast float %1048, %24
  %1050 = call float @dx.op.unary.f32(i32 6, float %1049)  ; FAbs(value)
  %1051 = fcmp fast ogt float %1050, 0x3EB0C6F7A0000000
  br i1 %1051, label %1052, label %1173

; <label>:1052                                    ; preds = %1035
  %1053 = fmul fast float %1044, %35
  %1054 = call float @dx.op.tertiary.f32(i32 46, float %1045, float %31, float %1053)  ; FMad(a,b,c)
  %1055 = call float @dx.op.tertiary.f32(i32 46, float %1031, float %27, float %1054)  ; FMad(a,b,c)
  %1056 = fadd fast float %1055, %23
  %1057 = fmul fast float %1044, %34
  %1058 = call float @dx.op.tertiary.f32(i32 46, float %1045, float %30, float %1057)  ; FMad(a,b,c)
  %1059 = call float @dx.op.tertiary.f32(i32 46, float %1031, float %26, float %1058)  ; FMad(a,b,c)
  %1060 = fadd fast float %1059, %22
  %1061 = fmul fast float %1044, %33
  %1062 = call float @dx.op.tertiary.f32(i32 46, float %1045, float %29, float %1061)  ; FMad(a,b,c)
  %1063 = call float @dx.op.tertiary.f32(i32 46, float %1031, float %25, float %1062)  ; FMad(a,b,c)
  %1064 = fadd fast float %1063, %21
  %1065 = fdiv fast float %1064, %1049
  %1066 = fdiv fast float %1060, %1049
  %1067 = fdiv fast float %1056, %1049
  %1068 = fsub fast float %1065, %18
  %1069 = fsub fast float %1066, %19
  %1070 = fsub fast float %1067, %20
  %1071 = fmul fast float %1068, %1068
  %1072 = fmul fast float %1069, %1069
  %1073 = fadd fast float %1072, %1071
  %1074 = fmul fast float %1070, %1070
  %1075 = fadd fast float %1073, %1074
  %1076 = call float @dx.op.unary.f32(i32 24, float %1075)  ; Sqrt(value)
  %1077 = fsub fast float %1076, %10
  %1078 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1077)  ; FMax(a,b)
  %1079 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %1079, label %1080, label %1103

; <label>:1080                                    ; preds = %1052
  %1081 = call float @dx.op.unary.f32(i32 6, float %1069)  ; FAbs(value)
  %1082 = fmul fast float %1081, %12
  %1083 = fcmp fast olt float %1082, 0x3F50624DE0000000
  br i1 %1083, label %1084, label %1087

; <label>:1084                                    ; preds = %1080
  %1085 = fmul fast float %1082, 5.000000e-01
  %1086 = fsub fast float 1.000000e+00, %1085
  br label %1092

; <label>:1087                                    ; preds = %1080
  %1088 = fmul fast float %1082, 0xBFF7154760000000
  %1089 = call float @dx.op.unary.f32(i32 21, float %1088)  ; Exp(value)
  %1090 = fsub fast float 1.000000e+00, %1089
  %1091 = fdiv fast float %1090, %1082
  br label %1092

; <label>:1092                                    ; preds = %1087, %1084
  %1093 = phi float [ %1086, %1084 ], [ %1091, %1087 ]
  %1094 = call float @dx.op.binary.f32(i32 36, float %1066, float %19)  ; FMin(a,b)
  %1095 = fsub fast float %1094, %11
  %1096 = fmul fast float %12, %1095
  %1097 = fsub fast float -0.000000e+00, %1096
  %1098 = call float @dx.op.binary.f32(i32 35, float %1097, float -4.000000e+01)  ; FMax(a,b)
  %1099 = call float @dx.op.binary.f32(i32 36, float %1098, float 5.000000e+00)  ; FMin(a,b)
  %1100 = fmul fast float %1099, 0x3FF7154760000000
  %1101 = call float @dx.op.unary.f32(i32 21, float %1100)  ; Exp(value)
  %1102 = fmul fast float %1101, %1093
  br label %1103

; <label>:1103                                    ; preds = %1092, %1052
  %1104 = phi float [ %1102, %1092 ], [ 1.000000e+00, %1052 ]
  %1105 = fmul fast float %1078, %17
  %1106 = fmul fast float %1105, %1104
  %1107 = fcmp fast ole float %1076, %10
  %1108 = fcmp fast olt float %1076, 0x3F1A36E2E0000000
  %1109 = or i1 %1107, %1108
  br i1 %1109, label %1156, label %1110

; <label>:1110                                    ; preds = %1103
  %1111 = fdiv fast float %10, %1076
  %1112 = fmul fast float %1111, %1068
  %1113 = fmul fast float %1111, %1069
  %1114 = fmul fast float %1111, %1070
  %1115 = fadd fast float %1112, %18
  %1116 = fadd fast float %1113, %19
  %1117 = fadd fast float %1114, %20
  %1118 = fadd fast float %1115, -9.000000e+02
  %1119 = fadd fast float %1116, -1.500000e+01
  %1120 = fadd fast float %1117, -7.500000e+02
  %1121 = fmul fast float %1118, 0x3F62345680000000
  %1122 = fmul fast float %1119, 0x3F62345680000000
  %1123 = fmul fast float %1120, 0x3F62345680000000
  %1124 = call float @dx.op.dot3.f32(i32 55, float %1121, float %1122, float %1123, float %1121, float %1122, float %1123)  ; Dot3(ax,ay,az,bx,by,bz)
  %1125 = fsub fast float 1.000000e+00, %1124
  %1126 = call float @dx.op.unary.f32(i32 7, float %1125)  ; Saturate(value)
  %1127 = fmul fast float %1126, %1126
  %1128 = fadd fast float %1115, %1065
  %1129 = fadd fast float %1116, %1066
  %1130 = fadd fast float %1117, %1067
  %1131 = fmul fast float %1128, 0x3F52345680000000
  %1132 = fadd fast float %1131, -2.000000e+00
  %1133 = fmul fast float %1129, 0x3F52345680000000
  %1134 = fadd fast float %1133, 0xBFA1111120000000
  %1135 = fmul fast float %1130, 0x3F52345680000000
  %1136 = fadd fast float %1135, 0xBFFAAAAAC0000000
  %1137 = call float @dx.op.dot3.f32(i32 55, float %1132, float %1134, float %1136, float %1132, float %1134, float %1136)  ; Dot3(ax,ay,az,bx,by,bz)
  %1138 = fsub fast float 1.000000e+00, %1137
  %1139 = call float @dx.op.unary.f32(i32 7, float %1138)  ; Saturate(value)
  %1140 = fmul fast float %1139, %1139
  %1141 = fmul fast float %1140, 4.000000e+00
  %1142 = fadd fast float %1141, %1127
  %1143 = fadd fast float %1065, -9.000000e+02
  %1144 = fadd fast float %1066, -1.500000e+01
  %1145 = fadd fast float %1067, -7.500000e+02
  %1146 = fmul fast float %1143, 0x3F62345680000000
  %1147 = fmul fast float %1144, 0x3F62345680000000
  %1148 = fmul fast float %1145, 0x3F62345680000000
  %1149 = call float @dx.op.dot3.f32(i32 55, float %1146, float %1147, float %1148, float %1146, float %1147, float %1148)  ; Dot3(ax,ay,az,bx,by,bz)
  %1150 = fsub fast float 1.000000e+00, %1149
  %1151 = call float @dx.op.unary.f32(i32 7, float %1150)  ; Saturate(value)
  %1152 = fmul fast float %1151, %1151
  %1153 = fadd fast float %1142, %1152
  %1154 = fmul fast float %1077, 0x3F25D867E0000000
  %1155 = fmul fast float %1154, %1153
  br label %1156

; <label>:1156                                    ; preds = %1110, %1103
  %1157 = phi float [ %1155, %1110 ], [ 0.000000e+00, %1103 ]
  %1158 = fadd fast float %1157, %1106
  %1159 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1158)  ; FMin(a,b)
  %1160 = fmul fast float %1159, 0xBFF7154760000000
  %1161 = call float @dx.op.unary.f32(i32 21, float %1160)  ; Exp(value)
  %1162 = fsub fast float 1.000000e+00, %1161
  %1163 = call float @dx.op.binary.f32(i32 36, float %13, float %1162)  ; FMin(a,b)
  %1164 = fsub fast float %14, %990
  %1165 = fsub fast float %15, %991
  %1166 = fsub fast float %16, %992
  %1167 = fmul fast float %1163, %1164
  %1168 = fmul fast float %1163, %1165
  %1169 = fmul fast float %1163, %1166
  %1170 = fadd fast float %1167, %990
  %1171 = fadd fast float %1168, %991
  %1172 = fadd fast float %1169, %992
  br label %1173

; <label>:1173                                    ; preds = %1156, %1035, %1029
  %1174 = phi float [ %1170, %1156 ], [ %990, %1035 ], [ %990, %1029 ]
  %1175 = phi float [ %1171, %1156 ], [ %991, %1035 ], [ %991, %1029 ]
  %1176 = phi float [ %1172, %1156 ], [ %992, %1035 ], [ %992, %1029 ]
  %1177 = fadd fast float %6, 1.000000e+00
  %1178 = fadd fast float %7, 1.000000e+00
  %1179 = fsub fast float 1.000000e+00, %6
  %1180 = fmul fast float %37, %1177
  %1181 = fmul fast float %37, %1178
  %1182 = fmul fast float %37, %1179
  %1183 = fmul fast float %1180, %1174
  %1184 = fmul fast float %1181, %1175
  %1185 = fmul fast float %1182, %1176
  %1186 = fcmp fast ult float %38, 5.000000e-01
  br i1 %1186, label %1212, label %1187

; <label>:1187                                    ; preds = %1173
  %1188 = fmul fast float %1183, 0x4004147AE0000000
  %1189 = fmul fast float %1184, 0x4004147AE0000000
  %1190 = fmul fast float %1185, 0x4004147AE0000000
  %1191 = fadd fast float %1188, 0x3F9EB851E0000000
  %1192 = fadd fast float %1189, 0x3F9EB851E0000000
  %1193 = fadd fast float %1190, 0x3F9EB851E0000000
  %1194 = fmul fast float %1191, %1183
  %1195 = fmul fast float %1192, %1184
  %1196 = fmul fast float %1193, %1185
  %1197 = fmul fast float %1183, 0x400370A3E0000000
  %1198 = fmul fast float %1184, 0x400370A3E0000000
  %1199 = fmul fast float %1185, 0x400370A3E0000000
  %1200 = fadd fast float %1197, 0x3FE2E147A0000000
  %1201 = fadd fast float %1198, 0x3FE2E147A0000000
  %1202 = fadd fast float %1199, 0x3FE2E147A0000000
  %1203 = fmul fast float %1200, %1183
  %1204 = fmul fast float %1201, %1184
  %1205 = fmul fast float %1202, %1185
  %1206 = fadd fast float %1203, 0x3FC1EB8520000000
  %1207 = fadd fast float %1204, 0x3FC1EB8520000000
  %1208 = fadd fast float %1205, 0x3FC1EB8520000000
  %1209 = fdiv fast float %1194, %1206
  %1210 = fdiv fast float %1195, %1207
  %1211 = fdiv fast float %1196, %1208
  br label %1212

; <label>:1212                                    ; preds = %1187, %1173
  %1213 = phi float [ %1209, %1187 ], [ %1183, %1173 ]
  %1214 = phi float [ %1210, %1187 ], [ %1184, %1173 ]
  %1215 = phi float [ %1211, %1187 ], [ %1185, %1173 ]
  %1216 = call float @dx.op.unary.f32(i32 7, float %1213)  ; Saturate(value)
  %1217 = call float @dx.op.unary.f32(i32 7, float %1214)  ; Saturate(value)
  %1218 = call float @dx.op.unary.f32(i32 7, float %1215)  ; Saturate(value)
  %1219 = call float @dx.op.dot3.f32(i32 55, float %1216, float %1217, float %1218, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1220 = fsub fast float %1216, %1219
  %1221 = fsub fast float %1217, %1219
  %1222 = fsub fast float %1218, %1219
  %1223 = fmul fast float %1220, %9
  %1224 = fmul fast float %1221, %9
  %1225 = fmul fast float %1222, %9
  %1226 = fadd fast float %1223, %1219
  %1227 = fadd fast float %1224, %1219
  %1228 = fadd fast float %1225, %1219
  %1229 = call float @dx.op.unary.f32(i32 7, float %1226)  ; Saturate(value)
  %1230 = call float @dx.op.unary.f32(i32 7, float %1227)  ; Saturate(value)
  %1231 = call float @dx.op.unary.f32(i32 7, float %1228)  ; Saturate(value)
  %1232 = fadd fast float %1229, 0xBFC70A3D80000000
  %1233 = fadd fast float %1230, 0xBFC70A3D80000000
  %1234 = fadd fast float %1231, 0xBFC70A3D80000000
  %1235 = fmul fast float %1232, %8
  %1236 = fmul fast float %1233, %8
  %1237 = fmul fast float %1234, %8
  %1238 = fadd fast float %1235, 0x3FC70A3D80000000
  %1239 = fadd fast float %1236, 0x3FC70A3D80000000
  %1240 = fadd fast float %1237, 0x3FC70A3D80000000
  %1241 = call float @dx.op.unary.f32(i32 7, float %1238)  ; Saturate(value)
  %1242 = call float @dx.op.unary.f32(i32 7, float %1239)  ; Saturate(value)
  %1243 = call float @dx.op.unary.f32(i32 7, float %1240)  ; Saturate(value)
  br label %1244

; <label>:1244                                    ; preds = %1212, %995
  %1245 = phi float [ %1026, %995 ], [ %1241, %1212 ]
  %1246 = phi float [ %1027, %995 ], [ %1242, %1212 ]
  %1247 = phi float [ %1028, %995 ], [ %1243, %1212 ]
  %1248 = fsub fast float %1245, %385
  %1249 = fsub fast float %1246, %386
  %1250 = fsub fast float %1247, %387
  %1251 = fmul fast float %1248, %982
  %1252 = fmul fast float %1249, %982
  %1253 = fmul fast float %1250, %982
  %1254 = fadd fast float %1251, %385
  %1255 = fadd fast float %1252, %386
  %1256 = fadd fast float %1253, %387
  br label %1257

; <label>:1257                                    ; preds = %1244, %967
  %1258 = phi float [ %1254, %1244 ], [ %385, %967 ]
  %1259 = phi float [ %1255, %1244 ], [ %386, %967 ]
  %1260 = phi float [ %1256, %1244 ], [ %387, %967 ]
  %1261 = add i32 %64, 1
  %1262 = call i32 @dx.op.binary.i32(i32 37, i32 %1261, i32 0)  ; IMax(a,b)
  %1263 = call i32 @dx.op.binary.i32(i32 38, i32 %1262, i32 %60)  ; IMin(a,b)
  %1264 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1263, i32 %975, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1265 = extractvalue %dx.types.ResRet.f32 %1264, 0
  %1266 = fsub fast float %1265, %83
  %1267 = call float @dx.op.unary.f32(i32 6, float %1266)  ; FAbs(value)
  %1268 = fdiv fast float %1267, %399
  %1269 = fsub fast float 1.000000e+00, %1268
  %1270 = call float @dx.op.unary.f32(i32 7, float %1269)  ; Saturate(value)
  %1271 = fcmp fast ugt float %1270, 0.000000e+00
  br i1 %1271, label %1272, label %1545

; <label>:1272                                    ; preds = %1257
  %1273 = call i32 @dx.op.binary.i32(i32 37, i32 %1263, i32 0)  ; IMax(a,b)
  %1274 = call i32 @dx.op.binary.i32(i32 37, i32 %975, i32 0)  ; IMax(a,b)
  %1275 = call i32 @dx.op.binary.i32(i32 38, i32 %1273, i32 %60)  ; IMin(a,b)
  %1276 = call i32 @dx.op.binary.i32(i32 38, i32 %1274, i32 %61)  ; IMin(a,b)
  %1277 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1275, i32 %1276, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1278 = extractvalue %dx.types.ResRet.f32 %1277, 0
  %1279 = extractvalue %dx.types.ResRet.f32 %1277, 1
  %1280 = extractvalue %dx.types.ResRet.f32 %1277, 2
  %1281 = extractvalue %dx.types.ResRet.f32 %1277, 3
  %1282 = fcmp fast olt float %1281, 0.000000e+00
  br i1 %1282, label %1283, label %1317

; <label>:1283                                    ; preds = %1272
  %1284 = fcmp fast ogt float %1278, 0x3FA4B5DCC0000000
  %1285 = fcmp fast ogt float %1279, 0x3FA4B5DCC0000000
  %1286 = fcmp fast ogt float %1280, 0x3FA4B5DCC0000000
  %1287 = select i1 %1284, float 0.000000e+00, float 1.000000e+00
  %1288 = select i1 %1285, float 0.000000e+00, float 1.000000e+00
  %1289 = select i1 %1286, float 0.000000e+00, float 1.000000e+00
  %1290 = fmul fast float %1278, 0x3FB3D07220000000
  %1291 = fmul fast float %1279, 0x3FB3D07220000000
  %1292 = fmul fast float %1280, 0x3FB3D07220000000
  %1293 = fadd fast float %1278, 0x3FAC28F5C0000000
  %1294 = fadd fast float %1279, 0x3FAC28F5C0000000
  %1295 = fadd fast float %1280, 0x3FAC28F5C0000000
  %1296 = fmul fast float %1293, 0x3FEE54EDE0000000
  %1297 = fmul fast float %1294, 0x3FEE54EDE0000000
  %1298 = fmul fast float %1295, 0x3FEE54EDE0000000
  %1299 = call float @dx.op.unary.f32(i32 23, float %1296)  ; Log(value)
  %1300 = call float @dx.op.unary.f32(i32 23, float %1297)  ; Log(value)
  %1301 = call float @dx.op.unary.f32(i32 23, float %1298)  ; Log(value)
  %1302 = fmul fast float %1299, 0x4003333340000000
  %1303 = fmul fast float %1300, 0x4003333340000000
  %1304 = fmul fast float %1301, 0x4003333340000000
  %1305 = call float @dx.op.unary.f32(i32 21, float %1302)  ; Exp(value)
  %1306 = call float @dx.op.unary.f32(i32 21, float %1303)  ; Exp(value)
  %1307 = call float @dx.op.unary.f32(i32 21, float %1304)  ; Exp(value)
  %1308 = fsub fast float %1290, %1305
  %1309 = fsub fast float %1291, %1306
  %1310 = fsub fast float %1292, %1307
  %1311 = fmul fast float %1308, %1287
  %1312 = fmul fast float %1309, %1288
  %1313 = fmul fast float %1310, %1289
  %1314 = fadd fast float %1311, %1305
  %1315 = fadd fast float %1312, %1306
  %1316 = fadd fast float %1313, %1307
  br label %1532

; <label>:1317                                    ; preds = %1272
  %1318 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1275, i32 %1276, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1319 = extractvalue %dx.types.ResRet.f32 %1318, 0
  %1320 = fcmp fast ogt float %39, 5.000000e-01
  %1321 = fcmp fast olt float %1319, 1.000000e+00
  %1322 = and i1 %1320, %1321
  br i1 %1322, label %1323, label %1461

; <label>:1323                                    ; preds = %1317
  %1324 = sitofp i32 %1275 to float
  %1325 = sitofp i32 %1276 to float
  %1326 = fadd fast float %1324, 5.000000e-01
  %1327 = fadd fast float %1325, 5.000000e-01
  %1328 = fdiv fast float %1326, %46
  %1329 = fdiv fast float %1327, %47
  %1330 = fmul fast float %1328, 2.000000e+00
  %1331 = fmul fast float %1329, 2.000000e+00
  %1332 = fadd fast float %1330, -1.000000e+00
  %1333 = fsub fast float 1.000000e+00, %1331
  %1334 = fmul fast float %1332, %36
  %1335 = call float @dx.op.tertiary.f32(i32 46, float %1333, float %32, float %1334)  ; FMad(a,b,c)
  %1336 = call float @dx.op.tertiary.f32(i32 46, float %1319, float %28, float %1335)  ; FMad(a,b,c)
  %1337 = fadd fast float %1336, %24
  %1338 = call float @dx.op.unary.f32(i32 6, float %1337)  ; FAbs(value)
  %1339 = fcmp fast ogt float %1338, 0x3EB0C6F7A0000000
  br i1 %1339, label %1340, label %1461

; <label>:1340                                    ; preds = %1323
  %1341 = fmul fast float %1332, %35
  %1342 = call float @dx.op.tertiary.f32(i32 46, float %1333, float %31, float %1341)  ; FMad(a,b,c)
  %1343 = call float @dx.op.tertiary.f32(i32 46, float %1319, float %27, float %1342)  ; FMad(a,b,c)
  %1344 = fadd fast float %1343, %23
  %1345 = fmul fast float %1332, %34
  %1346 = call float @dx.op.tertiary.f32(i32 46, float %1333, float %30, float %1345)  ; FMad(a,b,c)
  %1347 = call float @dx.op.tertiary.f32(i32 46, float %1319, float %26, float %1346)  ; FMad(a,b,c)
  %1348 = fadd fast float %1347, %22
  %1349 = fmul fast float %1332, %33
  %1350 = call float @dx.op.tertiary.f32(i32 46, float %1333, float %29, float %1349)  ; FMad(a,b,c)
  %1351 = call float @dx.op.tertiary.f32(i32 46, float %1319, float %25, float %1350)  ; FMad(a,b,c)
  %1352 = fadd fast float %1351, %21
  %1353 = fdiv fast float %1352, %1337
  %1354 = fdiv fast float %1348, %1337
  %1355 = fdiv fast float %1344, %1337
  %1356 = fsub fast float %1353, %18
  %1357 = fsub fast float %1354, %19
  %1358 = fsub fast float %1355, %20
  %1359 = fmul fast float %1356, %1356
  %1360 = fmul fast float %1357, %1357
  %1361 = fadd fast float %1360, %1359
  %1362 = fmul fast float %1358, %1358
  %1363 = fadd fast float %1361, %1362
  %1364 = call float @dx.op.unary.f32(i32 24, float %1363)  ; Sqrt(value)
  %1365 = fsub fast float %1364, %10
  %1366 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1365)  ; FMax(a,b)
  %1367 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %1367, label %1368, label %1391

; <label>:1368                                    ; preds = %1340
  %1369 = call float @dx.op.unary.f32(i32 6, float %1357)  ; FAbs(value)
  %1370 = fmul fast float %1369, %12
  %1371 = fcmp fast olt float %1370, 0x3F50624DE0000000
  br i1 %1371, label %1372, label %1375

; <label>:1372                                    ; preds = %1368
  %1373 = fmul fast float %1370, 5.000000e-01
  %1374 = fsub fast float 1.000000e+00, %1373
  br label %1380

; <label>:1375                                    ; preds = %1368
  %1376 = fmul fast float %1370, 0xBFF7154760000000
  %1377 = call float @dx.op.unary.f32(i32 21, float %1376)  ; Exp(value)
  %1378 = fsub fast float 1.000000e+00, %1377
  %1379 = fdiv fast float %1378, %1370
  br label %1380

; <label>:1380                                    ; preds = %1375, %1372
  %1381 = phi float [ %1374, %1372 ], [ %1379, %1375 ]
  %1382 = call float @dx.op.binary.f32(i32 36, float %1354, float %19)  ; FMin(a,b)
  %1383 = fsub fast float %1382, %11
  %1384 = fmul fast float %12, %1383
  %1385 = fsub fast float -0.000000e+00, %1384
  %1386 = call float @dx.op.binary.f32(i32 35, float %1385, float -4.000000e+01)  ; FMax(a,b)
  %1387 = call float @dx.op.binary.f32(i32 36, float %1386, float 5.000000e+00)  ; FMin(a,b)
  %1388 = fmul fast float %1387, 0x3FF7154760000000
  %1389 = call float @dx.op.unary.f32(i32 21, float %1388)  ; Exp(value)
  %1390 = fmul fast float %1389, %1381
  br label %1391

; <label>:1391                                    ; preds = %1380, %1340
  %1392 = phi float [ %1390, %1380 ], [ 1.000000e+00, %1340 ]
  %1393 = fmul fast float %1366, %17
  %1394 = fmul fast float %1393, %1392
  %1395 = fcmp fast ole float %1364, %10
  %1396 = fcmp fast olt float %1364, 0x3F1A36E2E0000000
  %1397 = or i1 %1395, %1396
  br i1 %1397, label %1444, label %1398

; <label>:1398                                    ; preds = %1391
  %1399 = fdiv fast float %10, %1364
  %1400 = fmul fast float %1399, %1356
  %1401 = fmul fast float %1399, %1357
  %1402 = fmul fast float %1399, %1358
  %1403 = fadd fast float %1400, %18
  %1404 = fadd fast float %1401, %19
  %1405 = fadd fast float %1402, %20
  %1406 = fadd fast float %1403, -9.000000e+02
  %1407 = fadd fast float %1404, -1.500000e+01
  %1408 = fadd fast float %1405, -7.500000e+02
  %1409 = fmul fast float %1406, 0x3F62345680000000
  %1410 = fmul fast float %1407, 0x3F62345680000000
  %1411 = fmul fast float %1408, 0x3F62345680000000
  %1412 = call float @dx.op.dot3.f32(i32 55, float %1409, float %1410, float %1411, float %1409, float %1410, float %1411)  ; Dot3(ax,ay,az,bx,by,bz)
  %1413 = fsub fast float 1.000000e+00, %1412
  %1414 = call float @dx.op.unary.f32(i32 7, float %1413)  ; Saturate(value)
  %1415 = fmul fast float %1414, %1414
  %1416 = fadd fast float %1403, %1353
  %1417 = fadd fast float %1404, %1354
  %1418 = fadd fast float %1405, %1355
  %1419 = fmul fast float %1416, 0x3F52345680000000
  %1420 = fadd fast float %1419, -2.000000e+00
  %1421 = fmul fast float %1417, 0x3F52345680000000
  %1422 = fadd fast float %1421, 0xBFA1111120000000
  %1423 = fmul fast float %1418, 0x3F52345680000000
  %1424 = fadd fast float %1423, 0xBFFAAAAAC0000000
  %1425 = call float @dx.op.dot3.f32(i32 55, float %1420, float %1422, float %1424, float %1420, float %1422, float %1424)  ; Dot3(ax,ay,az,bx,by,bz)
  %1426 = fsub fast float 1.000000e+00, %1425
  %1427 = call float @dx.op.unary.f32(i32 7, float %1426)  ; Saturate(value)
  %1428 = fmul fast float %1427, %1427
  %1429 = fmul fast float %1428, 4.000000e+00
  %1430 = fadd fast float %1429, %1415
  %1431 = fadd fast float %1353, -9.000000e+02
  %1432 = fadd fast float %1354, -1.500000e+01
  %1433 = fadd fast float %1355, -7.500000e+02
  %1434 = fmul fast float %1431, 0x3F62345680000000
  %1435 = fmul fast float %1432, 0x3F62345680000000
  %1436 = fmul fast float %1433, 0x3F62345680000000
  %1437 = call float @dx.op.dot3.f32(i32 55, float %1434, float %1435, float %1436, float %1434, float %1435, float %1436)  ; Dot3(ax,ay,az,bx,by,bz)
  %1438 = fsub fast float 1.000000e+00, %1437
  %1439 = call float @dx.op.unary.f32(i32 7, float %1438)  ; Saturate(value)
  %1440 = fmul fast float %1439, %1439
  %1441 = fadd fast float %1430, %1440
  %1442 = fmul fast float %1365, 0x3F25D867E0000000
  %1443 = fmul fast float %1442, %1441
  br label %1444

; <label>:1444                                    ; preds = %1398, %1391
  %1445 = phi float [ %1443, %1398 ], [ 0.000000e+00, %1391 ]
  %1446 = fadd fast float %1445, %1394
  %1447 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1446)  ; FMin(a,b)
  %1448 = fmul fast float %1447, 0xBFF7154760000000
  %1449 = call float @dx.op.unary.f32(i32 21, float %1448)  ; Exp(value)
  %1450 = fsub fast float 1.000000e+00, %1449
  %1451 = call float @dx.op.binary.f32(i32 36, float %13, float %1450)  ; FMin(a,b)
  %1452 = fsub fast float %14, %1278
  %1453 = fsub fast float %15, %1279
  %1454 = fsub fast float %16, %1280
  %1455 = fmul fast float %1451, %1452
  %1456 = fmul fast float %1451, %1453
  %1457 = fmul fast float %1451, %1454
  %1458 = fadd fast float %1455, %1278
  %1459 = fadd fast float %1456, %1279
  %1460 = fadd fast float %1457, %1280
  br label %1461

; <label>:1461                                    ; preds = %1444, %1323, %1317
  %1462 = phi float [ %1458, %1444 ], [ %1278, %1323 ], [ %1278, %1317 ]
  %1463 = phi float [ %1459, %1444 ], [ %1279, %1323 ], [ %1279, %1317 ]
  %1464 = phi float [ %1460, %1444 ], [ %1280, %1323 ], [ %1280, %1317 ]
  %1465 = fadd fast float %6, 1.000000e+00
  %1466 = fadd fast float %7, 1.000000e+00
  %1467 = fsub fast float 1.000000e+00, %6
  %1468 = fmul fast float %37, %1465
  %1469 = fmul fast float %37, %1466
  %1470 = fmul fast float %37, %1467
  %1471 = fmul fast float %1468, %1462
  %1472 = fmul fast float %1469, %1463
  %1473 = fmul fast float %1470, %1464
  %1474 = fcmp fast ult float %38, 5.000000e-01
  br i1 %1474, label %1500, label %1475

; <label>:1475                                    ; preds = %1461
  %1476 = fmul fast float %1471, 0x4004147AE0000000
  %1477 = fmul fast float %1472, 0x4004147AE0000000
  %1478 = fmul fast float %1473, 0x4004147AE0000000
  %1479 = fadd fast float %1476, 0x3F9EB851E0000000
  %1480 = fadd fast float %1477, 0x3F9EB851E0000000
  %1481 = fadd fast float %1478, 0x3F9EB851E0000000
  %1482 = fmul fast float %1479, %1471
  %1483 = fmul fast float %1480, %1472
  %1484 = fmul fast float %1481, %1473
  %1485 = fmul fast float %1471, 0x400370A3E0000000
  %1486 = fmul fast float %1472, 0x400370A3E0000000
  %1487 = fmul fast float %1473, 0x400370A3E0000000
  %1488 = fadd fast float %1485, 0x3FE2E147A0000000
  %1489 = fadd fast float %1486, 0x3FE2E147A0000000
  %1490 = fadd fast float %1487, 0x3FE2E147A0000000
  %1491 = fmul fast float %1488, %1471
  %1492 = fmul fast float %1489, %1472
  %1493 = fmul fast float %1490, %1473
  %1494 = fadd fast float %1491, 0x3FC1EB8520000000
  %1495 = fadd fast float %1492, 0x3FC1EB8520000000
  %1496 = fadd fast float %1493, 0x3FC1EB8520000000
  %1497 = fdiv fast float %1482, %1494
  %1498 = fdiv fast float %1483, %1495
  %1499 = fdiv fast float %1484, %1496
  br label %1500

; <label>:1500                                    ; preds = %1475, %1461
  %1501 = phi float [ %1497, %1475 ], [ %1471, %1461 ]
  %1502 = phi float [ %1498, %1475 ], [ %1472, %1461 ]
  %1503 = phi float [ %1499, %1475 ], [ %1473, %1461 ]
  %1504 = call float @dx.op.unary.f32(i32 7, float %1501)  ; Saturate(value)
  %1505 = call float @dx.op.unary.f32(i32 7, float %1502)  ; Saturate(value)
  %1506 = call float @dx.op.unary.f32(i32 7, float %1503)  ; Saturate(value)
  %1507 = call float @dx.op.dot3.f32(i32 55, float %1504, float %1505, float %1506, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1508 = fsub fast float %1504, %1507
  %1509 = fsub fast float %1505, %1507
  %1510 = fsub fast float %1506, %1507
  %1511 = fmul fast float %1508, %9
  %1512 = fmul fast float %1509, %9
  %1513 = fmul fast float %1510, %9
  %1514 = fadd fast float %1511, %1507
  %1515 = fadd fast float %1512, %1507
  %1516 = fadd fast float %1513, %1507
  %1517 = call float @dx.op.unary.f32(i32 7, float %1514)  ; Saturate(value)
  %1518 = call float @dx.op.unary.f32(i32 7, float %1515)  ; Saturate(value)
  %1519 = call float @dx.op.unary.f32(i32 7, float %1516)  ; Saturate(value)
  %1520 = fadd fast float %1517, 0xBFC70A3D80000000
  %1521 = fadd fast float %1518, 0xBFC70A3D80000000
  %1522 = fadd fast float %1519, 0xBFC70A3D80000000
  %1523 = fmul fast float %1520, %8
  %1524 = fmul fast float %1521, %8
  %1525 = fmul fast float %1522, %8
  %1526 = fadd fast float %1523, 0x3FC70A3D80000000
  %1527 = fadd fast float %1524, 0x3FC70A3D80000000
  %1528 = fadd fast float %1525, 0x3FC70A3D80000000
  %1529 = call float @dx.op.unary.f32(i32 7, float %1526)  ; Saturate(value)
  %1530 = call float @dx.op.unary.f32(i32 7, float %1527)  ; Saturate(value)
  %1531 = call float @dx.op.unary.f32(i32 7, float %1528)  ; Saturate(value)
  br label %1532

; <label>:1532                                    ; preds = %1500, %1283
  %1533 = phi float [ %1314, %1283 ], [ %1529, %1500 ]
  %1534 = phi float [ %1315, %1283 ], [ %1530, %1500 ]
  %1535 = phi float [ %1316, %1283 ], [ %1531, %1500 ]
  %1536 = fsub fast float %1533, %385
  %1537 = fsub fast float %1534, %386
  %1538 = fsub fast float %1535, %387
  %1539 = fmul fast float %1536, %1270
  %1540 = fmul fast float %1537, %1270
  %1541 = fmul fast float %1538, %1270
  %1542 = fadd fast float %1539, %385
  %1543 = fadd fast float %1540, %386
  %1544 = fadd fast float %1541, %387
  br label %1545

; <label>:1545                                    ; preds = %1532, %1257
  %1546 = phi float [ %1542, %1532 ], [ %385, %1257 ]
  %1547 = phi float [ %1543, %1532 ], [ %386, %1257 ]
  %1548 = phi float [ %1544, %1532 ], [ %387, %1257 ]
  %1549 = call float @dx.op.binary.f32(i32 36, float %1258, float %1546)  ; FMin(a,b)
  %1550 = call float @dx.op.binary.f32(i32 36, float %1259, float %1547)  ; FMin(a,b)
  %1551 = call float @dx.op.binary.f32(i32 36, float %1260, float %1548)  ; FMin(a,b)
  %1552 = call float @dx.op.binary.f32(i32 36, float %680, float %968)  ; FMin(a,b)
  %1553 = call float @dx.op.binary.f32(i32 36, float %681, float %969)  ; FMin(a,b)
  %1554 = call float @dx.op.binary.f32(i32 36, float %682, float %970)  ; FMin(a,b)
  %1555 = call float @dx.op.binary.f32(i32 36, float %1552, float %1549)  ; FMin(a,b)
  %1556 = call float @dx.op.binary.f32(i32 36, float %1553, float %1550)  ; FMin(a,b)
  %1557 = call float @dx.op.binary.f32(i32 36, float %1554, float %1551)  ; FMin(a,b)
  %1558 = call float @dx.op.binary.f32(i32 36, float %385, float %1555)  ; FMin(a,b)
  %1559 = call float @dx.op.binary.f32(i32 36, float %386, float %1556)  ; FMin(a,b)
  %1560 = call float @dx.op.binary.f32(i32 36, float %387, float %1557)  ; FMin(a,b)
  %1561 = call float @dx.op.binary.f32(i32 35, float %1258, float %1546)  ; FMax(a,b)
  %1562 = call float @dx.op.binary.f32(i32 35, float %1259, float %1547)  ; FMax(a,b)
  %1563 = call float @dx.op.binary.f32(i32 35, float %1260, float %1548)  ; FMax(a,b)
  %1564 = call float @dx.op.binary.f32(i32 35, float %680, float %968)  ; FMax(a,b)
  %1565 = call float @dx.op.binary.f32(i32 35, float %681, float %969)  ; FMax(a,b)
  %1566 = call float @dx.op.binary.f32(i32 35, float %682, float %970)  ; FMax(a,b)
  %1567 = call float @dx.op.binary.f32(i32 35, float %1564, float %1561)  ; FMax(a,b)
  %1568 = call float @dx.op.binary.f32(i32 35, float %1565, float %1562)  ; FMax(a,b)
  %1569 = call float @dx.op.binary.f32(i32 35, float %1566, float %1563)  ; FMax(a,b)
  %1570 = call float @dx.op.binary.f32(i32 35, float %385, float %1567)  ; FMax(a,b)
  %1571 = call float @dx.op.binary.f32(i32 35, float %386, float %1568)  ; FMax(a,b)
  %1572 = call float @dx.op.binary.f32(i32 35, float %387, float %1569)  ; FMax(a,b)
  %1573 = fsub fast float %1570, %1558
  %1574 = fsub fast float %1571, %1559
  %1575 = fsub fast float %1572, %1560
  %1576 = call float @dx.op.unary.f32(i32 6, float %1573)  ; FAbs(value)
  %1577 = call float @dx.op.unary.f32(i32 6, float %1574)  ; FAbs(value)
  %1578 = call float @dx.op.unary.f32(i32 6, float %1575)  ; FAbs(value)
  %1579 = call float @dx.op.binary.f32(i32 35, float %1577, float %1578)  ; FMax(a,b)
  %1580 = call float @dx.op.binary.f32(i32 35, float %1576, float %1579)  ; FMax(a,b)
  %1581 = call float @dx.op.binary.f32(i32 35, float %1571, float %1572)  ; FMax(a,b)
  %1582 = call float @dx.op.binary.f32(i32 35, float %1570, float %1581)  ; FMax(a,b)
  %1583 = fmul fast float %1582, 1.250000e-01
  %1584 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1583)  ; FMax(a,b)
  %1585 = fcmp fast ogt float %1580, %1584
  br i1 %1585, label %1586, label %1648

; <label>:1586                                    ; preds = %1545
  %1587 = fsub fast float %680, %968
  %1588 = fsub fast float %681, %969
  %1589 = fsub fast float %682, %970
  %1590 = call float @dx.op.unary.f32(i32 6, float %1587)  ; FAbs(value)
  %1591 = call float @dx.op.unary.f32(i32 6, float %1588)  ; FAbs(value)
  %1592 = call float @dx.op.unary.f32(i32 6, float %1589)  ; FAbs(value)
  %1593 = call float @dx.op.binary.f32(i32 35, float %1591, float %1592)  ; FMax(a,b)
  %1594 = call float @dx.op.binary.f32(i32 35, float %1590, float %1593)  ; FMax(a,b)
  %1595 = fsub fast float %1258, %1546
  %1596 = fsub fast float %1259, %1547
  %1597 = fsub fast float %1260, %1548
  %1598 = call float @dx.op.unary.f32(i32 6, float %1595)  ; FAbs(value)
  %1599 = call float @dx.op.unary.f32(i32 6, float %1596)  ; FAbs(value)
  %1600 = call float @dx.op.unary.f32(i32 6, float %1597)  ; FAbs(value)
  %1601 = call float @dx.op.binary.f32(i32 35, float %1599, float %1600)  ; FMax(a,b)
  %1602 = call float @dx.op.binary.f32(i32 35, float %1598, float %1601)  ; FMax(a,b)
  %1603 = fcmp fast olt float %1594, %1602
  %1604 = select i1 %1603, float %680, float %1258
  %1605 = select i1 %1603, float %681, float %1259
  %1606 = select i1 %1603, float %682, float %1260
  %1607 = select i1 %1603, float %968, float %1546
  %1608 = select i1 %1603, float %969, float %1547
  %1609 = select i1 %1603, float %970, float %1548
  %1610 = fsub fast float %385, %1607
  %1611 = fsub fast float %386, %1608
  %1612 = fsub fast float %387, %1609
  %1613 = fsub fast float %385, %1604
  %1614 = fsub fast float %386, %1605
  %1615 = fsub fast float %387, %1606
  %1616 = call float @dx.op.dot3.f32(i32 55, float %1613, float %1614, float %1615, float %1610, float %1611, float %1612)  ; Dot3(ax,ay,az,bx,by,bz)
  %1617 = fcmp fast ogt float %1616, 0.000000e+00
  br i1 %1617, label %1618, label %1629

; <label>:1618                                    ; preds = %1586
  %1619 = fsub fast float %1604, %1607
  %1620 = fsub fast float %1605, %1608
  %1621 = fsub fast float %1606, %1609
  %1622 = call float @dx.op.unary.f32(i32 6, float %1619)  ; FAbs(value)
  %1623 = call float @dx.op.unary.f32(i32 6, float %1620)  ; FAbs(value)
  %1624 = call float @dx.op.unary.f32(i32 6, float %1621)  ; FAbs(value)
  %1625 = call float @dx.op.binary.f32(i32 35, float %1623, float %1624)  ; FMax(a,b)
  %1626 = call float @dx.op.binary.f32(i32 35, float %1622, float %1625)  ; FMax(a,b)
  %1627 = fmul fast float %1580, 2.500000e-01
  %1628 = fcmp fast olt float %1626, %1627
  br label %1629

; <label>:1629                                    ; preds = %1618, %1586
  %1630 = phi i1 [ false, %1586 ], [ %1628, %1618 ]
  %1631 = select i1 %1630, float 5.000000e-01, float 1.000000e+00
  %1632 = fmul fast float %1631, %3
  %1633 = fadd fast float %1604, %1607
  %1634 = fadd fast float %1605, %1608
  %1635 = fadd fast float %1606, %1609
  %1636 = fmul fast float %1633, 5.000000e-01
  %1637 = fmul fast float %1634, 5.000000e-01
  %1638 = fmul fast float %1635, 5.000000e-01
  %1639 = fsub fast float %1636, %385
  %1640 = fsub fast float %1637, %386
  %1641 = fsub fast float %1638, %387
  %1642 = fmul fast float %1632, %1639
  %1643 = fmul fast float %1632, %1640
  %1644 = fmul fast float %1632, %1641
  %1645 = fadd fast float %1642, %385
  %1646 = fadd fast float %1643, %386
  %1647 = fadd fast float %1644, %387
  br label %1648

; <label>:1648                                    ; preds = %1629, %1545, %356
  %1649 = phi float [ %385, %356 ], [ %1645, %1629 ], [ %385, %1545 ]
  %1650 = phi float [ %386, %356 ], [ %1646, %1629 ], [ %386, %1545 ]
  %1651 = phi float [ %387, %356 ], [ %1647, %1629 ], [ %387, %1545 ]
  %1652 = fcmp fast ogt float %1649, 0x3F69A5C380000000
  %1653 = fcmp fast ogt float %1650, 0x3F69A5C380000000
  %1654 = fcmp fast ogt float %1651, 0x3F69A5C380000000
  %1655 = select i1 %1652, float 0.000000e+00, float 1.000000e+00
  %1656 = select i1 %1653, float 0.000000e+00, float 1.000000e+00
  %1657 = select i1 %1654, float 0.000000e+00, float 1.000000e+00
  %1658 = fmul fast float %1649, 0x4029D70A40000000
  %1659 = fmul fast float %1650, 0x4029D70A40000000
  %1660 = fmul fast float %1651, 0x4029D70A40000000
  %1661 = call float @dx.op.binary.f32(i32 35, float %1649, float 0.000000e+00)  ; FMax(a,b)
  %1662 = call float @dx.op.binary.f32(i32 35, float %1650, float 0.000000e+00)  ; FMax(a,b)
  %1663 = call float @dx.op.binary.f32(i32 35, float %1651, float 0.000000e+00)  ; FMax(a,b)
  %1664 = call float @dx.op.unary.f32(i32 23, float %1661)  ; Log(value)
  %1665 = call float @dx.op.unary.f32(i32 23, float %1662)  ; Log(value)
  %1666 = call float @dx.op.unary.f32(i32 23, float %1663)  ; Log(value)
  %1667 = fmul fast float %1664, 0x3FDAAAAAA0000000
  %1668 = fmul fast float %1665, 0x3FDAAAAAA0000000
  %1669 = fmul fast float %1666, 0x3FDAAAAAA0000000
  %1670 = call float @dx.op.unary.f32(i32 21, float %1667)  ; Exp(value)
  %1671 = call float @dx.op.unary.f32(i32 21, float %1668)  ; Exp(value)
  %1672 = call float @dx.op.unary.f32(i32 21, float %1669)  ; Exp(value)
  %1673 = fmul fast float %1670, 0x3FF0E147A0000000
  %1674 = fmul fast float %1671, 0x3FF0E147A0000000
  %1675 = fmul fast float %1672, 0x3FF0E147A0000000
  %1676 = fadd fast float %1673, 0xBFAC28F5C0000000
  %1677 = fadd fast float %1674, 0xBFAC28F5C0000000
  %1678 = fadd fast float %1675, 0xBFAC28F5C0000000
  %1679 = fsub fast float %1658, %1676
  %1680 = fsub fast float %1659, %1677
  %1681 = fsub fast float %1660, %1678
  %1682 = fmul fast float %1679, %1655
  %1683 = fmul fast float %1680, %1656
  %1684 = fmul fast float %1681, %1657
  %1685 = fadd fast float %1682, %1676
  %1686 = fadd fast float %1683, %1677
  %1687 = fadd fast float %1684, %1678
  br label %1688

; <label>:1688                                    ; preds = %1648, %173
  %1689 = phi float [ %168, %173 ], [ %1685, %1648 ]
  %1690 = phi float [ %169, %173 ], [ %1686, %1648 ]
  %1691 = phi float [ %170, %173 ], [ %1687, %1648 ]
  %1692 = phi float [ %174, %173 ], [ %171, %1648 ]
  %1693 = fcmp fast ogt float %1689, 0x3FA4B5DCC0000000
  %1694 = fcmp fast ogt float %1690, 0x3FA4B5DCC0000000
  %1695 = fcmp fast ogt float %1691, 0x3FA4B5DCC0000000
  %1696 = select i1 %1693, float 0.000000e+00, float 1.000000e+00
  %1697 = select i1 %1694, float 0.000000e+00, float 1.000000e+00
  %1698 = select i1 %1695, float 0.000000e+00, float 1.000000e+00
  %1699 = fmul fast float %1689, 0x3FB3D07220000000
  %1700 = fmul fast float %1690, 0x3FB3D07220000000
  %1701 = fmul fast float %1691, 0x3FB3D07220000000
  %1702 = fadd fast float %1689, 0x3FAC28F5C0000000
  %1703 = fadd fast float %1690, 0x3FAC28F5C0000000
  %1704 = fadd fast float %1691, 0x3FAC28F5C0000000
  %1705 = fmul fast float %1702, 0x3FEE54EDE0000000
  %1706 = fmul fast float %1703, 0x3FEE54EDE0000000
  %1707 = fmul fast float %1704, 0x3FEE54EDE0000000
  %1708 = call float @dx.op.unary.f32(i32 23, float %1705)  ; Log(value)
  %1709 = call float @dx.op.unary.f32(i32 23, float %1706)  ; Log(value)
  %1710 = call float @dx.op.unary.f32(i32 23, float %1707)  ; Log(value)
  %1711 = fmul fast float %1708, 0x4003333340000000
  %1712 = fmul fast float %1709, 0x4003333340000000
  %1713 = fmul fast float %1710, 0x4003333340000000
  %1714 = call float @dx.op.unary.f32(i32 21, float %1711)  ; Exp(value)
  %1715 = call float @dx.op.unary.f32(i32 21, float %1712)  ; Exp(value)
  %1716 = call float @dx.op.unary.f32(i32 21, float %1713)  ; Exp(value)
  %1717 = fsub fast float %1699, %1714
  %1718 = fsub fast float %1700, %1715
  %1719 = fsub fast float %1701, %1716
  %1720 = fmul fast float %1717, %1696
  %1721 = fmul fast float %1718, %1697
  %1722 = fmul fast float %1719, %1698
  %1723 = fadd fast float %1720, %1714
  %1724 = fadd fast float %1721, %1715
  %1725 = fadd fast float %1722, %1716
  %1726 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %68, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1727 = extractvalue %dx.types.ResRet.f32 %1726, 0
  %1728 = extractvalue %dx.types.ResRet.f32 %1726, 1
  %1729 = extractvalue %dx.types.ResRet.f32 %1726, 2
  %1730 = extractvalue %dx.types.ResRet.f32 %1726, 3
  %1731 = fcmp fast olt float %1730, 0.000000e+00
  br i1 %1731, label %1732, label %1734

; <label>:1732                                    ; preds = %1688
  %1733 = fsub fast float -1.000000e+00, %1730
  br label %3247

; <label>:1734                                    ; preds = %1688
  %1735 = fcmp fast ogt float %39, 5.000000e-01
  %1736 = fcmp fast olt float %85, 1.000000e+00
  %1737 = and i1 %1735, %1736
  br i1 %1737, label %1738, label %1876

; <label>:1738                                    ; preds = %1734
  %1739 = sitofp i32 %68 to float
  %1740 = sitofp i32 %65 to float
  %1741 = fadd fast float %1739, 5.000000e-01
  %1742 = fadd fast float %1740, 5.000000e-01
  %1743 = fdiv fast float %1741, %46
  %1744 = fdiv fast float %1742, %47
  %1745 = fmul fast float %1743, 2.000000e+00
  %1746 = fmul fast float %1744, 2.000000e+00
  %1747 = fadd fast float %1745, -1.000000e+00
  %1748 = fsub fast float 1.000000e+00, %1746
  %1749 = fmul fast float %1747, %36
  %1750 = call float @dx.op.tertiary.f32(i32 46, float %1748, float %32, float %1749)  ; FMad(a,b,c)
  %1751 = call float @dx.op.tertiary.f32(i32 46, float %85, float %28, float %1750)  ; FMad(a,b,c)
  %1752 = fadd fast float %1751, %24
  %1753 = call float @dx.op.unary.f32(i32 6, float %1752)  ; FAbs(value)
  %1754 = fcmp fast ogt float %1753, 0x3EB0C6F7A0000000
  br i1 %1754, label %1755, label %1876

; <label>:1755                                    ; preds = %1738
  %1756 = fmul fast float %1747, %35
  %1757 = call float @dx.op.tertiary.f32(i32 46, float %1748, float %31, float %1756)  ; FMad(a,b,c)
  %1758 = call float @dx.op.tertiary.f32(i32 46, float %85, float %27, float %1757)  ; FMad(a,b,c)
  %1759 = fadd fast float %1758, %23
  %1760 = fmul fast float %1747, %34
  %1761 = call float @dx.op.tertiary.f32(i32 46, float %1748, float %30, float %1760)  ; FMad(a,b,c)
  %1762 = call float @dx.op.tertiary.f32(i32 46, float %85, float %26, float %1761)  ; FMad(a,b,c)
  %1763 = fadd fast float %1762, %22
  %1764 = fmul fast float %1747, %33
  %1765 = call float @dx.op.tertiary.f32(i32 46, float %1748, float %29, float %1764)  ; FMad(a,b,c)
  %1766 = call float @dx.op.tertiary.f32(i32 46, float %85, float %25, float %1765)  ; FMad(a,b,c)
  %1767 = fadd fast float %1766, %21
  %1768 = fdiv fast float %1767, %1752
  %1769 = fdiv fast float %1763, %1752
  %1770 = fdiv fast float %1759, %1752
  %1771 = fsub fast float %1768, %18
  %1772 = fsub fast float %1769, %19
  %1773 = fsub fast float %1770, %20
  %1774 = fmul fast float %1771, %1771
  %1775 = fmul fast float %1772, %1772
  %1776 = fadd fast float %1775, %1774
  %1777 = fmul fast float %1773, %1773
  %1778 = fadd fast float %1776, %1777
  %1779 = call float @dx.op.unary.f32(i32 24, float %1778)  ; Sqrt(value)
  %1780 = fsub fast float %1779, %10
  %1781 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1780)  ; FMax(a,b)
  %1782 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %1782, label %1783, label %1806

; <label>:1783                                    ; preds = %1755
  %1784 = call float @dx.op.unary.f32(i32 6, float %1772)  ; FAbs(value)
  %1785 = fmul fast float %1784, %12
  %1786 = fcmp fast olt float %1785, 0x3F50624DE0000000
  br i1 %1786, label %1787, label %1790

; <label>:1787                                    ; preds = %1783
  %1788 = fmul fast float %1785, 5.000000e-01
  %1789 = fsub fast float 1.000000e+00, %1788
  br label %1795

; <label>:1790                                    ; preds = %1783
  %1791 = fmul fast float %1785, 0xBFF7154760000000
  %1792 = call float @dx.op.unary.f32(i32 21, float %1791)  ; Exp(value)
  %1793 = fsub fast float 1.000000e+00, %1792
  %1794 = fdiv fast float %1793, %1785
  br label %1795

; <label>:1795                                    ; preds = %1790, %1787
  %1796 = phi float [ %1789, %1787 ], [ %1794, %1790 ]
  %1797 = call float @dx.op.binary.f32(i32 36, float %1769, float %19)  ; FMin(a,b)
  %1798 = fsub fast float %1797, %11
  %1799 = fmul fast float %12, %1798
  %1800 = fsub fast float -0.000000e+00, %1799
  %1801 = call float @dx.op.binary.f32(i32 35, float %1800, float -4.000000e+01)  ; FMax(a,b)
  %1802 = call float @dx.op.binary.f32(i32 36, float %1801, float 5.000000e+00)  ; FMin(a,b)
  %1803 = fmul fast float %1802, 0x3FF7154760000000
  %1804 = call float @dx.op.unary.f32(i32 21, float %1803)  ; Exp(value)
  %1805 = fmul fast float %1804, %1796
  br label %1806

; <label>:1806                                    ; preds = %1795, %1755
  %1807 = phi float [ %1805, %1795 ], [ 1.000000e+00, %1755 ]
  %1808 = fmul fast float %1781, %17
  %1809 = fmul fast float %1808, %1807
  %1810 = fcmp fast ole float %1779, %10
  %1811 = fcmp fast olt float %1779, 0x3F1A36E2E0000000
  %1812 = or i1 %1810, %1811
  br i1 %1812, label %1859, label %1813

; <label>:1813                                    ; preds = %1806
  %1814 = fdiv fast float %10, %1779
  %1815 = fmul fast float %1814, %1771
  %1816 = fmul fast float %1814, %1772
  %1817 = fmul fast float %1814, %1773
  %1818 = fadd fast float %1815, %18
  %1819 = fadd fast float %1816, %19
  %1820 = fadd fast float %1817, %20
  %1821 = fadd fast float %1818, -9.000000e+02
  %1822 = fadd fast float %1819, -1.500000e+01
  %1823 = fadd fast float %1820, -7.500000e+02
  %1824 = fmul fast float %1821, 0x3F62345680000000
  %1825 = fmul fast float %1822, 0x3F62345680000000
  %1826 = fmul fast float %1823, 0x3F62345680000000
  %1827 = call float @dx.op.dot3.f32(i32 55, float %1824, float %1825, float %1826, float %1824, float %1825, float %1826)  ; Dot3(ax,ay,az,bx,by,bz)
  %1828 = fsub fast float 1.000000e+00, %1827
  %1829 = call float @dx.op.unary.f32(i32 7, float %1828)  ; Saturate(value)
  %1830 = fmul fast float %1829, %1829
  %1831 = fadd fast float %1818, %1768
  %1832 = fadd fast float %1819, %1769
  %1833 = fadd fast float %1820, %1770
  %1834 = fmul fast float %1831, 0x3F52345680000000
  %1835 = fadd fast float %1834, -2.000000e+00
  %1836 = fmul fast float %1832, 0x3F52345680000000
  %1837 = fadd fast float %1836, 0xBFA1111120000000
  %1838 = fmul fast float %1833, 0x3F52345680000000
  %1839 = fadd fast float %1838, 0xBFFAAAAAC0000000
  %1840 = call float @dx.op.dot3.f32(i32 55, float %1835, float %1837, float %1839, float %1835, float %1837, float %1839)  ; Dot3(ax,ay,az,bx,by,bz)
  %1841 = fsub fast float 1.000000e+00, %1840
  %1842 = call float @dx.op.unary.f32(i32 7, float %1841)  ; Saturate(value)
  %1843 = fmul fast float %1842, %1842
  %1844 = fmul fast float %1843, 4.000000e+00
  %1845 = fadd fast float %1844, %1830
  %1846 = fadd fast float %1768, -9.000000e+02
  %1847 = fadd fast float %1769, -1.500000e+01
  %1848 = fadd fast float %1770, -7.500000e+02
  %1849 = fmul fast float %1846, 0x3F62345680000000
  %1850 = fmul fast float %1847, 0x3F62345680000000
  %1851 = fmul fast float %1848, 0x3F62345680000000
  %1852 = call float @dx.op.dot3.f32(i32 55, float %1849, float %1850, float %1851, float %1849, float %1850, float %1851)  ; Dot3(ax,ay,az,bx,by,bz)
  %1853 = fsub fast float 1.000000e+00, %1852
  %1854 = call float @dx.op.unary.f32(i32 7, float %1853)  ; Saturate(value)
  %1855 = fmul fast float %1854, %1854
  %1856 = fadd fast float %1845, %1855
  %1857 = fmul fast float %1780, 0x3F25D867E0000000
  %1858 = fmul fast float %1857, %1856
  br label %1859

; <label>:1859                                    ; preds = %1813, %1806
  %1860 = phi float [ %1858, %1813 ], [ 0.000000e+00, %1806 ]
  %1861 = fadd fast float %1860, %1809
  %1862 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1861)  ; FMin(a,b)
  %1863 = fmul fast float %1862, 0xBFF7154760000000
  %1864 = call float @dx.op.unary.f32(i32 21, float %1863)  ; Exp(value)
  %1865 = fsub fast float 1.000000e+00, %1864
  %1866 = call float @dx.op.binary.f32(i32 36, float %13, float %1865)  ; FMin(a,b)
  %1867 = fsub fast float %14, %1727
  %1868 = fsub fast float %15, %1728
  %1869 = fsub fast float %16, %1729
  %1870 = fmul fast float %1866, %1867
  %1871 = fmul fast float %1866, %1868
  %1872 = fmul fast float %1866, %1869
  %1873 = fadd fast float %1870, %1727
  %1874 = fadd fast float %1871, %1728
  %1875 = fadd fast float %1872, %1729
  br label %1876

; <label>:1876                                    ; preds = %1859, %1738, %1734
  %1877 = phi float [ %1873, %1859 ], [ %1727, %1738 ], [ %1727, %1734 ]
  %1878 = phi float [ %1874, %1859 ], [ %1728, %1738 ], [ %1728, %1734 ]
  %1879 = phi float [ %1875, %1859 ], [ %1729, %1738 ], [ %1729, %1734 ]
  %1880 = fadd fast float %6, 1.000000e+00
  %1881 = fadd fast float %7, 1.000000e+00
  %1882 = fsub fast float 1.000000e+00, %6
  %1883 = fmul fast float %37, %1880
  %1884 = fmul fast float %37, %1881
  %1885 = fmul fast float %37, %1882
  %1886 = fmul fast float %1883, %1877
  %1887 = fmul fast float %1884, %1878
  %1888 = fmul fast float %1885, %1879
  %1889 = fcmp fast ult float %38, 5.000000e-01
  br i1 %1889, label %1915, label %1890

; <label>:1890                                    ; preds = %1876
  %1891 = fmul fast float %1886, 0x4004147AE0000000
  %1892 = fmul fast float %1887, 0x4004147AE0000000
  %1893 = fmul fast float %1888, 0x4004147AE0000000
  %1894 = fadd fast float %1891, 0x3F9EB851E0000000
  %1895 = fadd fast float %1892, 0x3F9EB851E0000000
  %1896 = fadd fast float %1893, 0x3F9EB851E0000000
  %1897 = fmul fast float %1894, %1886
  %1898 = fmul fast float %1895, %1887
  %1899 = fmul fast float %1896, %1888
  %1900 = fmul fast float %1886, 0x400370A3E0000000
  %1901 = fmul fast float %1887, 0x400370A3E0000000
  %1902 = fmul fast float %1888, 0x400370A3E0000000
  %1903 = fadd fast float %1900, 0x3FE2E147A0000000
  %1904 = fadd fast float %1901, 0x3FE2E147A0000000
  %1905 = fadd fast float %1902, 0x3FE2E147A0000000
  %1906 = fmul fast float %1903, %1886
  %1907 = fmul fast float %1904, %1887
  %1908 = fmul fast float %1905, %1888
  %1909 = fadd fast float %1906, 0x3FC1EB8520000000
  %1910 = fadd fast float %1907, 0x3FC1EB8520000000
  %1911 = fadd fast float %1908, 0x3FC1EB8520000000
  %1912 = fdiv fast float %1897, %1909
  %1913 = fdiv fast float %1898, %1910
  %1914 = fdiv fast float %1899, %1911
  br label %1915

; <label>:1915                                    ; preds = %1890, %1876
  %1916 = phi float [ %1912, %1890 ], [ %1886, %1876 ]
  %1917 = phi float [ %1913, %1890 ], [ %1887, %1876 ]
  %1918 = phi float [ %1914, %1890 ], [ %1888, %1876 ]
  %1919 = call float @dx.op.unary.f32(i32 7, float %1916)  ; Saturate(value)
  %1920 = call float @dx.op.unary.f32(i32 7, float %1917)  ; Saturate(value)
  %1921 = call float @dx.op.unary.f32(i32 7, float %1918)  ; Saturate(value)
  %1922 = call float @dx.op.dot3.f32(i32 55, float %1919, float %1920, float %1921, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1923 = fsub fast float %1919, %1922
  %1924 = fsub fast float %1920, %1922
  %1925 = fsub fast float %1921, %1922
  %1926 = fmul fast float %1923, %9
  %1927 = fmul fast float %1924, %9
  %1928 = fmul fast float %1925, %9
  %1929 = fadd fast float %1926, %1922
  %1930 = fadd fast float %1927, %1922
  %1931 = fadd fast float %1928, %1922
  %1932 = call float @dx.op.unary.f32(i32 7, float %1929)  ; Saturate(value)
  %1933 = call float @dx.op.unary.f32(i32 7, float %1930)  ; Saturate(value)
  %1934 = call float @dx.op.unary.f32(i32 7, float %1931)  ; Saturate(value)
  %1935 = fadd fast float %1932, 0xBFC70A3D80000000
  %1936 = fadd fast float %1933, 0xBFC70A3D80000000
  %1937 = fadd fast float %1934, 0xBFC70A3D80000000
  %1938 = fmul fast float %1935, %8
  %1939 = fmul fast float %1936, %8
  %1940 = fmul fast float %1937, %8
  %1941 = fadd fast float %1938, 0x3FC70A3D80000000
  %1942 = fadd fast float %1939, 0x3FC70A3D80000000
  %1943 = fadd fast float %1940, 0x3FC70A3D80000000
  %1944 = call float @dx.op.unary.f32(i32 7, float %1941)  ; Saturate(value)
  %1945 = call float @dx.op.unary.f32(i32 7, float %1942)  ; Saturate(value)
  %1946 = call float @dx.op.unary.f32(i32 7, float %1943)  ; Saturate(value)
  %1947 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %1947, label %1948, label %3207

; <label>:1948                                    ; preds = %1915
  %1949 = add i32 %65, -1
  %1950 = call i32 @dx.op.binary.i32(i32 37, i32 %68, i32 0)  ; IMax(a,b)
  %1951 = call i32 @dx.op.binary.i32(i32 37, i32 %1949, i32 0)  ; IMax(a,b)
  %1952 = call i32 @dx.op.binary.i32(i32 38, i32 %1950, i32 %60)  ; IMin(a,b)
  %1953 = call i32 @dx.op.binary.i32(i32 38, i32 %1951, i32 %61)  ; IMin(a,b)
  %1954 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1952, i32 %1953, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1955 = extractvalue %dx.types.ResRet.f32 %1954, 0
  %1956 = fsub fast float 1.000000e+00, %85
  %1957 = fmul fast float %1956, 0x3FA99999A0000000
  %1958 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %1957)  ; FMax(a,b)
  %1959 = fsub fast float %1955, %85
  %1960 = call float @dx.op.unary.f32(i32 6, float %1959)  ; FAbs(value)
  %1961 = fdiv fast float %1960, %1958
  %1962 = fsub fast float 1.000000e+00, %1961
  %1963 = call float @dx.op.unary.f32(i32 7, float %1962)  ; Saturate(value)
  %1964 = fcmp fast ugt float %1963, 0.000000e+00
  br i1 %1964, label %1965, label %2238

; <label>:1965                                    ; preds = %1948
  %1966 = call i32 @dx.op.binary.i32(i32 37, i32 %1952, i32 0)  ; IMax(a,b)
  %1967 = call i32 @dx.op.binary.i32(i32 37, i32 %1953, i32 0)  ; IMax(a,b)
  %1968 = call i32 @dx.op.binary.i32(i32 38, i32 %1966, i32 %60)  ; IMin(a,b)
  %1969 = call i32 @dx.op.binary.i32(i32 38, i32 %1967, i32 %61)  ; IMin(a,b)
  %1970 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1968, i32 %1969, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1971 = extractvalue %dx.types.ResRet.f32 %1970, 0
  %1972 = extractvalue %dx.types.ResRet.f32 %1970, 1
  %1973 = extractvalue %dx.types.ResRet.f32 %1970, 2
  %1974 = extractvalue %dx.types.ResRet.f32 %1970, 3
  %1975 = fcmp fast olt float %1974, 0.000000e+00
  br i1 %1975, label %1976, label %2010

; <label>:1976                                    ; preds = %1965
  %1977 = fcmp fast ogt float %1971, 0x3FA4B5DCC0000000
  %1978 = fcmp fast ogt float %1972, 0x3FA4B5DCC0000000
  %1979 = fcmp fast ogt float %1973, 0x3FA4B5DCC0000000
  %1980 = select i1 %1977, float 0.000000e+00, float 1.000000e+00
  %1981 = select i1 %1978, float 0.000000e+00, float 1.000000e+00
  %1982 = select i1 %1979, float 0.000000e+00, float 1.000000e+00
  %1983 = fmul fast float %1971, 0x3FB3D07220000000
  %1984 = fmul fast float %1972, 0x3FB3D07220000000
  %1985 = fmul fast float %1973, 0x3FB3D07220000000
  %1986 = fadd fast float %1971, 0x3FAC28F5C0000000
  %1987 = fadd fast float %1972, 0x3FAC28F5C0000000
  %1988 = fadd fast float %1973, 0x3FAC28F5C0000000
  %1989 = fmul fast float %1986, 0x3FEE54EDE0000000
  %1990 = fmul fast float %1987, 0x3FEE54EDE0000000
  %1991 = fmul fast float %1988, 0x3FEE54EDE0000000
  %1992 = call float @dx.op.unary.f32(i32 23, float %1989)  ; Log(value)
  %1993 = call float @dx.op.unary.f32(i32 23, float %1990)  ; Log(value)
  %1994 = call float @dx.op.unary.f32(i32 23, float %1991)  ; Log(value)
  %1995 = fmul fast float %1992, 0x4003333340000000
  %1996 = fmul fast float %1993, 0x4003333340000000
  %1997 = fmul fast float %1994, 0x4003333340000000
  %1998 = call float @dx.op.unary.f32(i32 21, float %1995)  ; Exp(value)
  %1999 = call float @dx.op.unary.f32(i32 21, float %1996)  ; Exp(value)
  %2000 = call float @dx.op.unary.f32(i32 21, float %1997)  ; Exp(value)
  %2001 = fsub fast float %1983, %1998
  %2002 = fsub fast float %1984, %1999
  %2003 = fsub fast float %1985, %2000
  %2004 = fmul fast float %2001, %1980
  %2005 = fmul fast float %2002, %1981
  %2006 = fmul fast float %2003, %1982
  %2007 = fadd fast float %2004, %1998
  %2008 = fadd fast float %2005, %1999
  %2009 = fadd fast float %2006, %2000
  br label %2225

; <label>:2010                                    ; preds = %1965
  %2011 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1968, i32 %1969, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2012 = extractvalue %dx.types.ResRet.f32 %2011, 0
  %2013 = fcmp fast ogt float %39, 5.000000e-01
  %2014 = fcmp fast olt float %2012, 1.000000e+00
  %2015 = and i1 %2013, %2014
  br i1 %2015, label %2016, label %2154

; <label>:2016                                    ; preds = %2010
  %2017 = sitofp i32 %1968 to float
  %2018 = sitofp i32 %1969 to float
  %2019 = fadd fast float %2017, 5.000000e-01
  %2020 = fadd fast float %2018, 5.000000e-01
  %2021 = fdiv fast float %2019, %46
  %2022 = fdiv fast float %2020, %47
  %2023 = fmul fast float %2021, 2.000000e+00
  %2024 = fmul fast float %2022, 2.000000e+00
  %2025 = fadd fast float %2023, -1.000000e+00
  %2026 = fsub fast float 1.000000e+00, %2024
  %2027 = fmul fast float %2025, %36
  %2028 = call float @dx.op.tertiary.f32(i32 46, float %2026, float %32, float %2027)  ; FMad(a,b,c)
  %2029 = call float @dx.op.tertiary.f32(i32 46, float %2012, float %28, float %2028)  ; FMad(a,b,c)
  %2030 = fadd fast float %2029, %24
  %2031 = call float @dx.op.unary.f32(i32 6, float %2030)  ; FAbs(value)
  %2032 = fcmp fast ogt float %2031, 0x3EB0C6F7A0000000
  br i1 %2032, label %2033, label %2154

; <label>:2033                                    ; preds = %2016
  %2034 = fmul fast float %2025, %35
  %2035 = call float @dx.op.tertiary.f32(i32 46, float %2026, float %31, float %2034)  ; FMad(a,b,c)
  %2036 = call float @dx.op.tertiary.f32(i32 46, float %2012, float %27, float %2035)  ; FMad(a,b,c)
  %2037 = fadd fast float %2036, %23
  %2038 = fmul fast float %2025, %34
  %2039 = call float @dx.op.tertiary.f32(i32 46, float %2026, float %30, float %2038)  ; FMad(a,b,c)
  %2040 = call float @dx.op.tertiary.f32(i32 46, float %2012, float %26, float %2039)  ; FMad(a,b,c)
  %2041 = fadd fast float %2040, %22
  %2042 = fmul fast float %2025, %33
  %2043 = call float @dx.op.tertiary.f32(i32 46, float %2026, float %29, float %2042)  ; FMad(a,b,c)
  %2044 = call float @dx.op.tertiary.f32(i32 46, float %2012, float %25, float %2043)  ; FMad(a,b,c)
  %2045 = fadd fast float %2044, %21
  %2046 = fdiv fast float %2045, %2030
  %2047 = fdiv fast float %2041, %2030
  %2048 = fdiv fast float %2037, %2030
  %2049 = fsub fast float %2046, %18
  %2050 = fsub fast float %2047, %19
  %2051 = fsub fast float %2048, %20
  %2052 = fmul fast float %2049, %2049
  %2053 = fmul fast float %2050, %2050
  %2054 = fadd fast float %2053, %2052
  %2055 = fmul fast float %2051, %2051
  %2056 = fadd fast float %2054, %2055
  %2057 = call float @dx.op.unary.f32(i32 24, float %2056)  ; Sqrt(value)
  %2058 = fsub fast float %2057, %10
  %2059 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2058)  ; FMax(a,b)
  %2060 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %2060, label %2061, label %2084

; <label>:2061                                    ; preds = %2033
  %2062 = call float @dx.op.unary.f32(i32 6, float %2050)  ; FAbs(value)
  %2063 = fmul fast float %2062, %12
  %2064 = fcmp fast olt float %2063, 0x3F50624DE0000000
  br i1 %2064, label %2065, label %2068

; <label>:2065                                    ; preds = %2061
  %2066 = fmul fast float %2063, 5.000000e-01
  %2067 = fsub fast float 1.000000e+00, %2066
  br label %2073

; <label>:2068                                    ; preds = %2061
  %2069 = fmul fast float %2063, 0xBFF7154760000000
  %2070 = call float @dx.op.unary.f32(i32 21, float %2069)  ; Exp(value)
  %2071 = fsub fast float 1.000000e+00, %2070
  %2072 = fdiv fast float %2071, %2063
  br label %2073

; <label>:2073                                    ; preds = %2068, %2065
  %2074 = phi float [ %2067, %2065 ], [ %2072, %2068 ]
  %2075 = call float @dx.op.binary.f32(i32 36, float %2047, float %19)  ; FMin(a,b)
  %2076 = fsub fast float %2075, %11
  %2077 = fmul fast float %12, %2076
  %2078 = fsub fast float -0.000000e+00, %2077
  %2079 = call float @dx.op.binary.f32(i32 35, float %2078, float -4.000000e+01)  ; FMax(a,b)
  %2080 = call float @dx.op.binary.f32(i32 36, float %2079, float 5.000000e+00)  ; FMin(a,b)
  %2081 = fmul fast float %2080, 0x3FF7154760000000
  %2082 = call float @dx.op.unary.f32(i32 21, float %2081)  ; Exp(value)
  %2083 = fmul fast float %2082, %2074
  br label %2084

; <label>:2084                                    ; preds = %2073, %2033
  %2085 = phi float [ %2083, %2073 ], [ 1.000000e+00, %2033 ]
  %2086 = fmul fast float %2059, %17
  %2087 = fmul fast float %2086, %2085
  %2088 = fcmp fast ole float %2057, %10
  %2089 = fcmp fast olt float %2057, 0x3F1A36E2E0000000
  %2090 = or i1 %2088, %2089
  br i1 %2090, label %2137, label %2091

; <label>:2091                                    ; preds = %2084
  %2092 = fdiv fast float %10, %2057
  %2093 = fmul fast float %2092, %2049
  %2094 = fmul fast float %2092, %2050
  %2095 = fmul fast float %2092, %2051
  %2096 = fadd fast float %2093, %18
  %2097 = fadd fast float %2094, %19
  %2098 = fadd fast float %2095, %20
  %2099 = fadd fast float %2096, -9.000000e+02
  %2100 = fadd fast float %2097, -1.500000e+01
  %2101 = fadd fast float %2098, -7.500000e+02
  %2102 = fmul fast float %2099, 0x3F62345680000000
  %2103 = fmul fast float %2100, 0x3F62345680000000
  %2104 = fmul fast float %2101, 0x3F62345680000000
  %2105 = call float @dx.op.dot3.f32(i32 55, float %2102, float %2103, float %2104, float %2102, float %2103, float %2104)  ; Dot3(ax,ay,az,bx,by,bz)
  %2106 = fsub fast float 1.000000e+00, %2105
  %2107 = call float @dx.op.unary.f32(i32 7, float %2106)  ; Saturate(value)
  %2108 = fmul fast float %2107, %2107
  %2109 = fadd fast float %2096, %2046
  %2110 = fadd fast float %2097, %2047
  %2111 = fadd fast float %2098, %2048
  %2112 = fmul fast float %2109, 0x3F52345680000000
  %2113 = fadd fast float %2112, -2.000000e+00
  %2114 = fmul fast float %2110, 0x3F52345680000000
  %2115 = fadd fast float %2114, 0xBFA1111120000000
  %2116 = fmul fast float %2111, 0x3F52345680000000
  %2117 = fadd fast float %2116, 0xBFFAAAAAC0000000
  %2118 = call float @dx.op.dot3.f32(i32 55, float %2113, float %2115, float %2117, float %2113, float %2115, float %2117)  ; Dot3(ax,ay,az,bx,by,bz)
  %2119 = fsub fast float 1.000000e+00, %2118
  %2120 = call float @dx.op.unary.f32(i32 7, float %2119)  ; Saturate(value)
  %2121 = fmul fast float %2120, %2120
  %2122 = fmul fast float %2121, 4.000000e+00
  %2123 = fadd fast float %2122, %2108
  %2124 = fadd fast float %2046, -9.000000e+02
  %2125 = fadd fast float %2047, -1.500000e+01
  %2126 = fadd fast float %2048, -7.500000e+02
  %2127 = fmul fast float %2124, 0x3F62345680000000
  %2128 = fmul fast float %2125, 0x3F62345680000000
  %2129 = fmul fast float %2126, 0x3F62345680000000
  %2130 = call float @dx.op.dot3.f32(i32 55, float %2127, float %2128, float %2129, float %2127, float %2128, float %2129)  ; Dot3(ax,ay,az,bx,by,bz)
  %2131 = fsub fast float 1.000000e+00, %2130
  %2132 = call float @dx.op.unary.f32(i32 7, float %2131)  ; Saturate(value)
  %2133 = fmul fast float %2132, %2132
  %2134 = fadd fast float %2123, %2133
  %2135 = fmul fast float %2058, 0x3F25D867E0000000
  %2136 = fmul fast float %2135, %2134
  br label %2137

; <label>:2137                                    ; preds = %2091, %2084
  %2138 = phi float [ %2136, %2091 ], [ 0.000000e+00, %2084 ]
  %2139 = fadd fast float %2138, %2087
  %2140 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2139)  ; FMin(a,b)
  %2141 = fmul fast float %2140, 0xBFF7154760000000
  %2142 = call float @dx.op.unary.f32(i32 21, float %2141)  ; Exp(value)
  %2143 = fsub fast float 1.000000e+00, %2142
  %2144 = call float @dx.op.binary.f32(i32 36, float %13, float %2143)  ; FMin(a,b)
  %2145 = fsub fast float %14, %1971
  %2146 = fsub fast float %15, %1972
  %2147 = fsub fast float %16, %1973
  %2148 = fmul fast float %2144, %2145
  %2149 = fmul fast float %2144, %2146
  %2150 = fmul fast float %2144, %2147
  %2151 = fadd fast float %2148, %1971
  %2152 = fadd fast float %2149, %1972
  %2153 = fadd fast float %2150, %1973
  br label %2154

; <label>:2154                                    ; preds = %2137, %2016, %2010
  %2155 = phi float [ %2151, %2137 ], [ %1971, %2016 ], [ %1971, %2010 ]
  %2156 = phi float [ %2152, %2137 ], [ %1972, %2016 ], [ %1972, %2010 ]
  %2157 = phi float [ %2153, %2137 ], [ %1973, %2016 ], [ %1973, %2010 ]
  %2158 = fadd fast float %6, 1.000000e+00
  %2159 = fadd fast float %7, 1.000000e+00
  %2160 = fsub fast float 1.000000e+00, %6
  %2161 = fmul fast float %37, %2158
  %2162 = fmul fast float %37, %2159
  %2163 = fmul fast float %37, %2160
  %2164 = fmul fast float %2161, %2155
  %2165 = fmul fast float %2162, %2156
  %2166 = fmul fast float %2163, %2157
  %2167 = fcmp fast ult float %38, 5.000000e-01
  br i1 %2167, label %2193, label %2168

; <label>:2168                                    ; preds = %2154
  %2169 = fmul fast float %2164, 0x4004147AE0000000
  %2170 = fmul fast float %2165, 0x4004147AE0000000
  %2171 = fmul fast float %2166, 0x4004147AE0000000
  %2172 = fadd fast float %2169, 0x3F9EB851E0000000
  %2173 = fadd fast float %2170, 0x3F9EB851E0000000
  %2174 = fadd fast float %2171, 0x3F9EB851E0000000
  %2175 = fmul fast float %2172, %2164
  %2176 = fmul fast float %2173, %2165
  %2177 = fmul fast float %2174, %2166
  %2178 = fmul fast float %2164, 0x400370A3E0000000
  %2179 = fmul fast float %2165, 0x400370A3E0000000
  %2180 = fmul fast float %2166, 0x400370A3E0000000
  %2181 = fadd fast float %2178, 0x3FE2E147A0000000
  %2182 = fadd fast float %2179, 0x3FE2E147A0000000
  %2183 = fadd fast float %2180, 0x3FE2E147A0000000
  %2184 = fmul fast float %2181, %2164
  %2185 = fmul fast float %2182, %2165
  %2186 = fmul fast float %2183, %2166
  %2187 = fadd fast float %2184, 0x3FC1EB8520000000
  %2188 = fadd fast float %2185, 0x3FC1EB8520000000
  %2189 = fadd fast float %2186, 0x3FC1EB8520000000
  %2190 = fdiv fast float %2175, %2187
  %2191 = fdiv fast float %2176, %2188
  %2192 = fdiv fast float %2177, %2189
  br label %2193

; <label>:2193                                    ; preds = %2168, %2154
  %2194 = phi float [ %2190, %2168 ], [ %2164, %2154 ]
  %2195 = phi float [ %2191, %2168 ], [ %2165, %2154 ]
  %2196 = phi float [ %2192, %2168 ], [ %2166, %2154 ]
  %2197 = call float @dx.op.unary.f32(i32 7, float %2194)  ; Saturate(value)
  %2198 = call float @dx.op.unary.f32(i32 7, float %2195)  ; Saturate(value)
  %2199 = call float @dx.op.unary.f32(i32 7, float %2196)  ; Saturate(value)
  %2200 = call float @dx.op.dot3.f32(i32 55, float %2197, float %2198, float %2199, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2201 = fsub fast float %2197, %2200
  %2202 = fsub fast float %2198, %2200
  %2203 = fsub fast float %2199, %2200
  %2204 = fmul fast float %2201, %9
  %2205 = fmul fast float %2202, %9
  %2206 = fmul fast float %2203, %9
  %2207 = fadd fast float %2204, %2200
  %2208 = fadd fast float %2205, %2200
  %2209 = fadd fast float %2206, %2200
  %2210 = call float @dx.op.unary.f32(i32 7, float %2207)  ; Saturate(value)
  %2211 = call float @dx.op.unary.f32(i32 7, float %2208)  ; Saturate(value)
  %2212 = call float @dx.op.unary.f32(i32 7, float %2209)  ; Saturate(value)
  %2213 = fadd fast float %2210, 0xBFC70A3D80000000
  %2214 = fadd fast float %2211, 0xBFC70A3D80000000
  %2215 = fadd fast float %2212, 0xBFC70A3D80000000
  %2216 = fmul fast float %2213, %8
  %2217 = fmul fast float %2214, %8
  %2218 = fmul fast float %2215, %8
  %2219 = fadd fast float %2216, 0x3FC70A3D80000000
  %2220 = fadd fast float %2217, 0x3FC70A3D80000000
  %2221 = fadd fast float %2218, 0x3FC70A3D80000000
  %2222 = call float @dx.op.unary.f32(i32 7, float %2219)  ; Saturate(value)
  %2223 = call float @dx.op.unary.f32(i32 7, float %2220)  ; Saturate(value)
  %2224 = call float @dx.op.unary.f32(i32 7, float %2221)  ; Saturate(value)
  br label %2225

; <label>:2225                                    ; preds = %2193, %1976
  %2226 = phi float [ %2007, %1976 ], [ %2222, %2193 ]
  %2227 = phi float [ %2008, %1976 ], [ %2223, %2193 ]
  %2228 = phi float [ %2009, %1976 ], [ %2224, %2193 ]
  %2229 = fsub fast float %2226, %1944
  %2230 = fsub fast float %2227, %1945
  %2231 = fsub fast float %2228, %1946
  %2232 = fmul fast float %2229, %1963
  %2233 = fmul fast float %2230, %1963
  %2234 = fmul fast float %2231, %1963
  %2235 = fadd fast float %2232, %1944
  %2236 = fadd fast float %2233, %1945
  %2237 = fadd fast float %2234, %1946
  br label %2238

; <label>:2238                                    ; preds = %2225, %1948
  %2239 = phi float [ %2235, %2225 ], [ %1944, %1948 ]
  %2240 = phi float [ %2236, %2225 ], [ %1945, %1948 ]
  %2241 = phi float [ %2237, %2225 ], [ %1946, %1948 ]
  %2242 = add i32 %65, 1
  %2243 = call i32 @dx.op.binary.i32(i32 37, i32 %2242, i32 0)  ; IMax(a,b)
  %2244 = call i32 @dx.op.binary.i32(i32 38, i32 %2243, i32 %61)  ; IMin(a,b)
  %2245 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1952, i32 %2244, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2246 = extractvalue %dx.types.ResRet.f32 %2245, 0
  %2247 = fsub fast float %2246, %85
  %2248 = call float @dx.op.unary.f32(i32 6, float %2247)  ; FAbs(value)
  %2249 = fdiv fast float %2248, %1958
  %2250 = fsub fast float 1.000000e+00, %2249
  %2251 = call float @dx.op.unary.f32(i32 7, float %2250)  ; Saturate(value)
  %2252 = fcmp fast ugt float %2251, 0.000000e+00
  br i1 %2252, label %2253, label %2526

; <label>:2253                                    ; preds = %2238
  %2254 = call i32 @dx.op.binary.i32(i32 37, i32 %1952, i32 0)  ; IMax(a,b)
  %2255 = call i32 @dx.op.binary.i32(i32 37, i32 %2244, i32 0)  ; IMax(a,b)
  %2256 = call i32 @dx.op.binary.i32(i32 38, i32 %2254, i32 %60)  ; IMin(a,b)
  %2257 = call i32 @dx.op.binary.i32(i32 38, i32 %2255, i32 %61)  ; IMin(a,b)
  %2258 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2256, i32 %2257, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2259 = extractvalue %dx.types.ResRet.f32 %2258, 0
  %2260 = extractvalue %dx.types.ResRet.f32 %2258, 1
  %2261 = extractvalue %dx.types.ResRet.f32 %2258, 2
  %2262 = extractvalue %dx.types.ResRet.f32 %2258, 3
  %2263 = fcmp fast olt float %2262, 0.000000e+00
  br i1 %2263, label %2264, label %2298

; <label>:2264                                    ; preds = %2253
  %2265 = fcmp fast ogt float %2259, 0x3FA4B5DCC0000000
  %2266 = fcmp fast ogt float %2260, 0x3FA4B5DCC0000000
  %2267 = fcmp fast ogt float %2261, 0x3FA4B5DCC0000000
  %2268 = select i1 %2265, float 0.000000e+00, float 1.000000e+00
  %2269 = select i1 %2266, float 0.000000e+00, float 1.000000e+00
  %2270 = select i1 %2267, float 0.000000e+00, float 1.000000e+00
  %2271 = fmul fast float %2259, 0x3FB3D07220000000
  %2272 = fmul fast float %2260, 0x3FB3D07220000000
  %2273 = fmul fast float %2261, 0x3FB3D07220000000
  %2274 = fadd fast float %2259, 0x3FAC28F5C0000000
  %2275 = fadd fast float %2260, 0x3FAC28F5C0000000
  %2276 = fadd fast float %2261, 0x3FAC28F5C0000000
  %2277 = fmul fast float %2274, 0x3FEE54EDE0000000
  %2278 = fmul fast float %2275, 0x3FEE54EDE0000000
  %2279 = fmul fast float %2276, 0x3FEE54EDE0000000
  %2280 = call float @dx.op.unary.f32(i32 23, float %2277)  ; Log(value)
  %2281 = call float @dx.op.unary.f32(i32 23, float %2278)  ; Log(value)
  %2282 = call float @dx.op.unary.f32(i32 23, float %2279)  ; Log(value)
  %2283 = fmul fast float %2280, 0x4003333340000000
  %2284 = fmul fast float %2281, 0x4003333340000000
  %2285 = fmul fast float %2282, 0x4003333340000000
  %2286 = call float @dx.op.unary.f32(i32 21, float %2283)  ; Exp(value)
  %2287 = call float @dx.op.unary.f32(i32 21, float %2284)  ; Exp(value)
  %2288 = call float @dx.op.unary.f32(i32 21, float %2285)  ; Exp(value)
  %2289 = fsub fast float %2271, %2286
  %2290 = fsub fast float %2272, %2287
  %2291 = fsub fast float %2273, %2288
  %2292 = fmul fast float %2289, %2268
  %2293 = fmul fast float %2290, %2269
  %2294 = fmul fast float %2291, %2270
  %2295 = fadd fast float %2292, %2286
  %2296 = fadd fast float %2293, %2287
  %2297 = fadd fast float %2294, %2288
  br label %2513

; <label>:2298                                    ; preds = %2253
  %2299 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2256, i32 %2257, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2300 = extractvalue %dx.types.ResRet.f32 %2299, 0
  %2301 = fcmp fast ogt float %39, 5.000000e-01
  %2302 = fcmp fast olt float %2300, 1.000000e+00
  %2303 = and i1 %2301, %2302
  br i1 %2303, label %2304, label %2442

; <label>:2304                                    ; preds = %2298
  %2305 = sitofp i32 %2256 to float
  %2306 = sitofp i32 %2257 to float
  %2307 = fadd fast float %2305, 5.000000e-01
  %2308 = fadd fast float %2306, 5.000000e-01
  %2309 = fdiv fast float %2307, %46
  %2310 = fdiv fast float %2308, %47
  %2311 = fmul fast float %2309, 2.000000e+00
  %2312 = fmul fast float %2310, 2.000000e+00
  %2313 = fadd fast float %2311, -1.000000e+00
  %2314 = fsub fast float 1.000000e+00, %2312
  %2315 = fmul fast float %2313, %36
  %2316 = call float @dx.op.tertiary.f32(i32 46, float %2314, float %32, float %2315)  ; FMad(a,b,c)
  %2317 = call float @dx.op.tertiary.f32(i32 46, float %2300, float %28, float %2316)  ; FMad(a,b,c)
  %2318 = fadd fast float %2317, %24
  %2319 = call float @dx.op.unary.f32(i32 6, float %2318)  ; FAbs(value)
  %2320 = fcmp fast ogt float %2319, 0x3EB0C6F7A0000000
  br i1 %2320, label %2321, label %2442

; <label>:2321                                    ; preds = %2304
  %2322 = fmul fast float %2313, %35
  %2323 = call float @dx.op.tertiary.f32(i32 46, float %2314, float %31, float %2322)  ; FMad(a,b,c)
  %2324 = call float @dx.op.tertiary.f32(i32 46, float %2300, float %27, float %2323)  ; FMad(a,b,c)
  %2325 = fadd fast float %2324, %23
  %2326 = fmul fast float %2313, %34
  %2327 = call float @dx.op.tertiary.f32(i32 46, float %2314, float %30, float %2326)  ; FMad(a,b,c)
  %2328 = call float @dx.op.tertiary.f32(i32 46, float %2300, float %26, float %2327)  ; FMad(a,b,c)
  %2329 = fadd fast float %2328, %22
  %2330 = fmul fast float %2313, %33
  %2331 = call float @dx.op.tertiary.f32(i32 46, float %2314, float %29, float %2330)  ; FMad(a,b,c)
  %2332 = call float @dx.op.tertiary.f32(i32 46, float %2300, float %25, float %2331)  ; FMad(a,b,c)
  %2333 = fadd fast float %2332, %21
  %2334 = fdiv fast float %2333, %2318
  %2335 = fdiv fast float %2329, %2318
  %2336 = fdiv fast float %2325, %2318
  %2337 = fsub fast float %2334, %18
  %2338 = fsub fast float %2335, %19
  %2339 = fsub fast float %2336, %20
  %2340 = fmul fast float %2337, %2337
  %2341 = fmul fast float %2338, %2338
  %2342 = fadd fast float %2341, %2340
  %2343 = fmul fast float %2339, %2339
  %2344 = fadd fast float %2342, %2343
  %2345 = call float @dx.op.unary.f32(i32 24, float %2344)  ; Sqrt(value)
  %2346 = fsub fast float %2345, %10
  %2347 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2346)  ; FMax(a,b)
  %2348 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %2348, label %2349, label %2372

; <label>:2349                                    ; preds = %2321
  %2350 = call float @dx.op.unary.f32(i32 6, float %2338)  ; FAbs(value)
  %2351 = fmul fast float %2350, %12
  %2352 = fcmp fast olt float %2351, 0x3F50624DE0000000
  br i1 %2352, label %2353, label %2356

; <label>:2353                                    ; preds = %2349
  %2354 = fmul fast float %2351, 5.000000e-01
  %2355 = fsub fast float 1.000000e+00, %2354
  br label %2361

; <label>:2356                                    ; preds = %2349
  %2357 = fmul fast float %2351, 0xBFF7154760000000
  %2358 = call float @dx.op.unary.f32(i32 21, float %2357)  ; Exp(value)
  %2359 = fsub fast float 1.000000e+00, %2358
  %2360 = fdiv fast float %2359, %2351
  br label %2361

; <label>:2361                                    ; preds = %2356, %2353
  %2362 = phi float [ %2355, %2353 ], [ %2360, %2356 ]
  %2363 = call float @dx.op.binary.f32(i32 36, float %2335, float %19)  ; FMin(a,b)
  %2364 = fsub fast float %2363, %11
  %2365 = fmul fast float %12, %2364
  %2366 = fsub fast float -0.000000e+00, %2365
  %2367 = call float @dx.op.binary.f32(i32 35, float %2366, float -4.000000e+01)  ; FMax(a,b)
  %2368 = call float @dx.op.binary.f32(i32 36, float %2367, float 5.000000e+00)  ; FMin(a,b)
  %2369 = fmul fast float %2368, 0x3FF7154760000000
  %2370 = call float @dx.op.unary.f32(i32 21, float %2369)  ; Exp(value)
  %2371 = fmul fast float %2370, %2362
  br label %2372

; <label>:2372                                    ; preds = %2361, %2321
  %2373 = phi float [ %2371, %2361 ], [ 1.000000e+00, %2321 ]
  %2374 = fmul fast float %2347, %17
  %2375 = fmul fast float %2374, %2373
  %2376 = fcmp fast ole float %2345, %10
  %2377 = fcmp fast olt float %2345, 0x3F1A36E2E0000000
  %2378 = or i1 %2376, %2377
  br i1 %2378, label %2425, label %2379

; <label>:2379                                    ; preds = %2372
  %2380 = fdiv fast float %10, %2345
  %2381 = fmul fast float %2380, %2337
  %2382 = fmul fast float %2380, %2338
  %2383 = fmul fast float %2380, %2339
  %2384 = fadd fast float %2381, %18
  %2385 = fadd fast float %2382, %19
  %2386 = fadd fast float %2383, %20
  %2387 = fadd fast float %2384, -9.000000e+02
  %2388 = fadd fast float %2385, -1.500000e+01
  %2389 = fadd fast float %2386, -7.500000e+02
  %2390 = fmul fast float %2387, 0x3F62345680000000
  %2391 = fmul fast float %2388, 0x3F62345680000000
  %2392 = fmul fast float %2389, 0x3F62345680000000
  %2393 = call float @dx.op.dot3.f32(i32 55, float %2390, float %2391, float %2392, float %2390, float %2391, float %2392)  ; Dot3(ax,ay,az,bx,by,bz)
  %2394 = fsub fast float 1.000000e+00, %2393
  %2395 = call float @dx.op.unary.f32(i32 7, float %2394)  ; Saturate(value)
  %2396 = fmul fast float %2395, %2395
  %2397 = fadd fast float %2384, %2334
  %2398 = fadd fast float %2385, %2335
  %2399 = fadd fast float %2386, %2336
  %2400 = fmul fast float %2397, 0x3F52345680000000
  %2401 = fadd fast float %2400, -2.000000e+00
  %2402 = fmul fast float %2398, 0x3F52345680000000
  %2403 = fadd fast float %2402, 0xBFA1111120000000
  %2404 = fmul fast float %2399, 0x3F52345680000000
  %2405 = fadd fast float %2404, 0xBFFAAAAAC0000000
  %2406 = call float @dx.op.dot3.f32(i32 55, float %2401, float %2403, float %2405, float %2401, float %2403, float %2405)  ; Dot3(ax,ay,az,bx,by,bz)
  %2407 = fsub fast float 1.000000e+00, %2406
  %2408 = call float @dx.op.unary.f32(i32 7, float %2407)  ; Saturate(value)
  %2409 = fmul fast float %2408, %2408
  %2410 = fmul fast float %2409, 4.000000e+00
  %2411 = fadd fast float %2410, %2396
  %2412 = fadd fast float %2334, -9.000000e+02
  %2413 = fadd fast float %2335, -1.500000e+01
  %2414 = fadd fast float %2336, -7.500000e+02
  %2415 = fmul fast float %2412, 0x3F62345680000000
  %2416 = fmul fast float %2413, 0x3F62345680000000
  %2417 = fmul fast float %2414, 0x3F62345680000000
  %2418 = call float @dx.op.dot3.f32(i32 55, float %2415, float %2416, float %2417, float %2415, float %2416, float %2417)  ; Dot3(ax,ay,az,bx,by,bz)
  %2419 = fsub fast float 1.000000e+00, %2418
  %2420 = call float @dx.op.unary.f32(i32 7, float %2419)  ; Saturate(value)
  %2421 = fmul fast float %2420, %2420
  %2422 = fadd fast float %2411, %2421
  %2423 = fmul fast float %2346, 0x3F25D867E0000000
  %2424 = fmul fast float %2423, %2422
  br label %2425

; <label>:2425                                    ; preds = %2379, %2372
  %2426 = phi float [ %2424, %2379 ], [ 0.000000e+00, %2372 ]
  %2427 = fadd fast float %2426, %2375
  %2428 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2427)  ; FMin(a,b)
  %2429 = fmul fast float %2428, 0xBFF7154760000000
  %2430 = call float @dx.op.unary.f32(i32 21, float %2429)  ; Exp(value)
  %2431 = fsub fast float 1.000000e+00, %2430
  %2432 = call float @dx.op.binary.f32(i32 36, float %13, float %2431)  ; FMin(a,b)
  %2433 = fsub fast float %14, %2259
  %2434 = fsub fast float %15, %2260
  %2435 = fsub fast float %16, %2261
  %2436 = fmul fast float %2432, %2433
  %2437 = fmul fast float %2432, %2434
  %2438 = fmul fast float %2432, %2435
  %2439 = fadd fast float %2436, %2259
  %2440 = fadd fast float %2437, %2260
  %2441 = fadd fast float %2438, %2261
  br label %2442

; <label>:2442                                    ; preds = %2425, %2304, %2298
  %2443 = phi float [ %2439, %2425 ], [ %2259, %2304 ], [ %2259, %2298 ]
  %2444 = phi float [ %2440, %2425 ], [ %2260, %2304 ], [ %2260, %2298 ]
  %2445 = phi float [ %2441, %2425 ], [ %2261, %2304 ], [ %2261, %2298 ]
  %2446 = fadd fast float %6, 1.000000e+00
  %2447 = fadd fast float %7, 1.000000e+00
  %2448 = fsub fast float 1.000000e+00, %6
  %2449 = fmul fast float %37, %2446
  %2450 = fmul fast float %37, %2447
  %2451 = fmul fast float %37, %2448
  %2452 = fmul fast float %2449, %2443
  %2453 = fmul fast float %2450, %2444
  %2454 = fmul fast float %2451, %2445
  %2455 = fcmp fast ult float %38, 5.000000e-01
  br i1 %2455, label %2481, label %2456

; <label>:2456                                    ; preds = %2442
  %2457 = fmul fast float %2452, 0x4004147AE0000000
  %2458 = fmul fast float %2453, 0x4004147AE0000000
  %2459 = fmul fast float %2454, 0x4004147AE0000000
  %2460 = fadd fast float %2457, 0x3F9EB851E0000000
  %2461 = fadd fast float %2458, 0x3F9EB851E0000000
  %2462 = fadd fast float %2459, 0x3F9EB851E0000000
  %2463 = fmul fast float %2460, %2452
  %2464 = fmul fast float %2461, %2453
  %2465 = fmul fast float %2462, %2454
  %2466 = fmul fast float %2452, 0x400370A3E0000000
  %2467 = fmul fast float %2453, 0x400370A3E0000000
  %2468 = fmul fast float %2454, 0x400370A3E0000000
  %2469 = fadd fast float %2466, 0x3FE2E147A0000000
  %2470 = fadd fast float %2467, 0x3FE2E147A0000000
  %2471 = fadd fast float %2468, 0x3FE2E147A0000000
  %2472 = fmul fast float %2469, %2452
  %2473 = fmul fast float %2470, %2453
  %2474 = fmul fast float %2471, %2454
  %2475 = fadd fast float %2472, 0x3FC1EB8520000000
  %2476 = fadd fast float %2473, 0x3FC1EB8520000000
  %2477 = fadd fast float %2474, 0x3FC1EB8520000000
  %2478 = fdiv fast float %2463, %2475
  %2479 = fdiv fast float %2464, %2476
  %2480 = fdiv fast float %2465, %2477
  br label %2481

; <label>:2481                                    ; preds = %2456, %2442
  %2482 = phi float [ %2478, %2456 ], [ %2452, %2442 ]
  %2483 = phi float [ %2479, %2456 ], [ %2453, %2442 ]
  %2484 = phi float [ %2480, %2456 ], [ %2454, %2442 ]
  %2485 = call float @dx.op.unary.f32(i32 7, float %2482)  ; Saturate(value)
  %2486 = call float @dx.op.unary.f32(i32 7, float %2483)  ; Saturate(value)
  %2487 = call float @dx.op.unary.f32(i32 7, float %2484)  ; Saturate(value)
  %2488 = call float @dx.op.dot3.f32(i32 55, float %2485, float %2486, float %2487, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2489 = fsub fast float %2485, %2488
  %2490 = fsub fast float %2486, %2488
  %2491 = fsub fast float %2487, %2488
  %2492 = fmul fast float %2489, %9
  %2493 = fmul fast float %2490, %9
  %2494 = fmul fast float %2491, %9
  %2495 = fadd fast float %2492, %2488
  %2496 = fadd fast float %2493, %2488
  %2497 = fadd fast float %2494, %2488
  %2498 = call float @dx.op.unary.f32(i32 7, float %2495)  ; Saturate(value)
  %2499 = call float @dx.op.unary.f32(i32 7, float %2496)  ; Saturate(value)
  %2500 = call float @dx.op.unary.f32(i32 7, float %2497)  ; Saturate(value)
  %2501 = fadd fast float %2498, 0xBFC70A3D80000000
  %2502 = fadd fast float %2499, 0xBFC70A3D80000000
  %2503 = fadd fast float %2500, 0xBFC70A3D80000000
  %2504 = fmul fast float %2501, %8
  %2505 = fmul fast float %2502, %8
  %2506 = fmul fast float %2503, %8
  %2507 = fadd fast float %2504, 0x3FC70A3D80000000
  %2508 = fadd fast float %2505, 0x3FC70A3D80000000
  %2509 = fadd fast float %2506, 0x3FC70A3D80000000
  %2510 = call float @dx.op.unary.f32(i32 7, float %2507)  ; Saturate(value)
  %2511 = call float @dx.op.unary.f32(i32 7, float %2508)  ; Saturate(value)
  %2512 = call float @dx.op.unary.f32(i32 7, float %2509)  ; Saturate(value)
  br label %2513

; <label>:2513                                    ; preds = %2481, %2264
  %2514 = phi float [ %2295, %2264 ], [ %2510, %2481 ]
  %2515 = phi float [ %2296, %2264 ], [ %2511, %2481 ]
  %2516 = phi float [ %2297, %2264 ], [ %2512, %2481 ]
  %2517 = fsub fast float %2514, %1944
  %2518 = fsub fast float %2515, %1945
  %2519 = fsub fast float %2516, %1946
  %2520 = fmul fast float %2517, %2251
  %2521 = fmul fast float %2518, %2251
  %2522 = fmul fast float %2519, %2251
  %2523 = fadd fast float %2520, %1944
  %2524 = fadd fast float %2521, %1945
  %2525 = fadd fast float %2522, %1946
  br label %2526

; <label>:2526                                    ; preds = %2513, %2238
  %2527 = phi float [ %2523, %2513 ], [ %1944, %2238 ]
  %2528 = phi float [ %2524, %2513 ], [ %1945, %2238 ]
  %2529 = phi float [ %2525, %2513 ], [ %1946, %2238 ]
  %2530 = add i32 %68, -1
  %2531 = call i32 @dx.op.binary.i32(i32 37, i32 %2530, i32 0)  ; IMax(a,b)
  %2532 = call i32 @dx.op.binary.i32(i32 37, i32 %65, i32 0)  ; IMax(a,b)
  %2533 = call i32 @dx.op.binary.i32(i32 38, i32 %2531, i32 %60)  ; IMin(a,b)
  %2534 = call i32 @dx.op.binary.i32(i32 38, i32 %2532, i32 %61)  ; IMin(a,b)
  %2535 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2533, i32 %2534, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2536 = extractvalue %dx.types.ResRet.f32 %2535, 0
  %2537 = fsub fast float %2536, %85
  %2538 = call float @dx.op.unary.f32(i32 6, float %2537)  ; FAbs(value)
  %2539 = fdiv fast float %2538, %1958
  %2540 = fsub fast float 1.000000e+00, %2539
  %2541 = call float @dx.op.unary.f32(i32 7, float %2540)  ; Saturate(value)
  %2542 = fcmp fast ugt float %2541, 0.000000e+00
  br i1 %2542, label %2543, label %2816

; <label>:2543                                    ; preds = %2526
  %2544 = call i32 @dx.op.binary.i32(i32 37, i32 %2533, i32 0)  ; IMax(a,b)
  %2545 = call i32 @dx.op.binary.i32(i32 37, i32 %2534, i32 0)  ; IMax(a,b)
  %2546 = call i32 @dx.op.binary.i32(i32 38, i32 %2544, i32 %60)  ; IMin(a,b)
  %2547 = call i32 @dx.op.binary.i32(i32 38, i32 %2545, i32 %61)  ; IMin(a,b)
  %2548 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2546, i32 %2547, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2549 = extractvalue %dx.types.ResRet.f32 %2548, 0
  %2550 = extractvalue %dx.types.ResRet.f32 %2548, 1
  %2551 = extractvalue %dx.types.ResRet.f32 %2548, 2
  %2552 = extractvalue %dx.types.ResRet.f32 %2548, 3
  %2553 = fcmp fast olt float %2552, 0.000000e+00
  br i1 %2553, label %2554, label %2588

; <label>:2554                                    ; preds = %2543
  %2555 = fcmp fast ogt float %2549, 0x3FA4B5DCC0000000
  %2556 = fcmp fast ogt float %2550, 0x3FA4B5DCC0000000
  %2557 = fcmp fast ogt float %2551, 0x3FA4B5DCC0000000
  %2558 = select i1 %2555, float 0.000000e+00, float 1.000000e+00
  %2559 = select i1 %2556, float 0.000000e+00, float 1.000000e+00
  %2560 = select i1 %2557, float 0.000000e+00, float 1.000000e+00
  %2561 = fmul fast float %2549, 0x3FB3D07220000000
  %2562 = fmul fast float %2550, 0x3FB3D07220000000
  %2563 = fmul fast float %2551, 0x3FB3D07220000000
  %2564 = fadd fast float %2549, 0x3FAC28F5C0000000
  %2565 = fadd fast float %2550, 0x3FAC28F5C0000000
  %2566 = fadd fast float %2551, 0x3FAC28F5C0000000
  %2567 = fmul fast float %2564, 0x3FEE54EDE0000000
  %2568 = fmul fast float %2565, 0x3FEE54EDE0000000
  %2569 = fmul fast float %2566, 0x3FEE54EDE0000000
  %2570 = call float @dx.op.unary.f32(i32 23, float %2567)  ; Log(value)
  %2571 = call float @dx.op.unary.f32(i32 23, float %2568)  ; Log(value)
  %2572 = call float @dx.op.unary.f32(i32 23, float %2569)  ; Log(value)
  %2573 = fmul fast float %2570, 0x4003333340000000
  %2574 = fmul fast float %2571, 0x4003333340000000
  %2575 = fmul fast float %2572, 0x4003333340000000
  %2576 = call float @dx.op.unary.f32(i32 21, float %2573)  ; Exp(value)
  %2577 = call float @dx.op.unary.f32(i32 21, float %2574)  ; Exp(value)
  %2578 = call float @dx.op.unary.f32(i32 21, float %2575)  ; Exp(value)
  %2579 = fsub fast float %2561, %2576
  %2580 = fsub fast float %2562, %2577
  %2581 = fsub fast float %2563, %2578
  %2582 = fmul fast float %2579, %2558
  %2583 = fmul fast float %2580, %2559
  %2584 = fmul fast float %2581, %2560
  %2585 = fadd fast float %2582, %2576
  %2586 = fadd fast float %2583, %2577
  %2587 = fadd fast float %2584, %2578
  br label %2803

; <label>:2588                                    ; preds = %2543
  %2589 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2546, i32 %2547, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2590 = extractvalue %dx.types.ResRet.f32 %2589, 0
  %2591 = fcmp fast ogt float %39, 5.000000e-01
  %2592 = fcmp fast olt float %2590, 1.000000e+00
  %2593 = and i1 %2591, %2592
  br i1 %2593, label %2594, label %2732

; <label>:2594                                    ; preds = %2588
  %2595 = sitofp i32 %2546 to float
  %2596 = sitofp i32 %2547 to float
  %2597 = fadd fast float %2595, 5.000000e-01
  %2598 = fadd fast float %2596, 5.000000e-01
  %2599 = fdiv fast float %2597, %46
  %2600 = fdiv fast float %2598, %47
  %2601 = fmul fast float %2599, 2.000000e+00
  %2602 = fmul fast float %2600, 2.000000e+00
  %2603 = fadd fast float %2601, -1.000000e+00
  %2604 = fsub fast float 1.000000e+00, %2602
  %2605 = fmul fast float %2603, %36
  %2606 = call float @dx.op.tertiary.f32(i32 46, float %2604, float %32, float %2605)  ; FMad(a,b,c)
  %2607 = call float @dx.op.tertiary.f32(i32 46, float %2590, float %28, float %2606)  ; FMad(a,b,c)
  %2608 = fadd fast float %2607, %24
  %2609 = call float @dx.op.unary.f32(i32 6, float %2608)  ; FAbs(value)
  %2610 = fcmp fast ogt float %2609, 0x3EB0C6F7A0000000
  br i1 %2610, label %2611, label %2732

; <label>:2611                                    ; preds = %2594
  %2612 = fmul fast float %2603, %35
  %2613 = call float @dx.op.tertiary.f32(i32 46, float %2604, float %31, float %2612)  ; FMad(a,b,c)
  %2614 = call float @dx.op.tertiary.f32(i32 46, float %2590, float %27, float %2613)  ; FMad(a,b,c)
  %2615 = fadd fast float %2614, %23
  %2616 = fmul fast float %2603, %34
  %2617 = call float @dx.op.tertiary.f32(i32 46, float %2604, float %30, float %2616)  ; FMad(a,b,c)
  %2618 = call float @dx.op.tertiary.f32(i32 46, float %2590, float %26, float %2617)  ; FMad(a,b,c)
  %2619 = fadd fast float %2618, %22
  %2620 = fmul fast float %2603, %33
  %2621 = call float @dx.op.tertiary.f32(i32 46, float %2604, float %29, float %2620)  ; FMad(a,b,c)
  %2622 = call float @dx.op.tertiary.f32(i32 46, float %2590, float %25, float %2621)  ; FMad(a,b,c)
  %2623 = fadd fast float %2622, %21
  %2624 = fdiv fast float %2623, %2608
  %2625 = fdiv fast float %2619, %2608
  %2626 = fdiv fast float %2615, %2608
  %2627 = fsub fast float %2624, %18
  %2628 = fsub fast float %2625, %19
  %2629 = fsub fast float %2626, %20
  %2630 = fmul fast float %2627, %2627
  %2631 = fmul fast float %2628, %2628
  %2632 = fadd fast float %2631, %2630
  %2633 = fmul fast float %2629, %2629
  %2634 = fadd fast float %2632, %2633
  %2635 = call float @dx.op.unary.f32(i32 24, float %2634)  ; Sqrt(value)
  %2636 = fsub fast float %2635, %10
  %2637 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2636)  ; FMax(a,b)
  %2638 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %2638, label %2639, label %2662

; <label>:2639                                    ; preds = %2611
  %2640 = call float @dx.op.unary.f32(i32 6, float %2628)  ; FAbs(value)
  %2641 = fmul fast float %2640, %12
  %2642 = fcmp fast olt float %2641, 0x3F50624DE0000000
  br i1 %2642, label %2643, label %2646

; <label>:2643                                    ; preds = %2639
  %2644 = fmul fast float %2641, 5.000000e-01
  %2645 = fsub fast float 1.000000e+00, %2644
  br label %2651

; <label>:2646                                    ; preds = %2639
  %2647 = fmul fast float %2641, 0xBFF7154760000000
  %2648 = call float @dx.op.unary.f32(i32 21, float %2647)  ; Exp(value)
  %2649 = fsub fast float 1.000000e+00, %2648
  %2650 = fdiv fast float %2649, %2641
  br label %2651

; <label>:2651                                    ; preds = %2646, %2643
  %2652 = phi float [ %2645, %2643 ], [ %2650, %2646 ]
  %2653 = call float @dx.op.binary.f32(i32 36, float %2625, float %19)  ; FMin(a,b)
  %2654 = fsub fast float %2653, %11
  %2655 = fmul fast float %12, %2654
  %2656 = fsub fast float -0.000000e+00, %2655
  %2657 = call float @dx.op.binary.f32(i32 35, float %2656, float -4.000000e+01)  ; FMax(a,b)
  %2658 = call float @dx.op.binary.f32(i32 36, float %2657, float 5.000000e+00)  ; FMin(a,b)
  %2659 = fmul fast float %2658, 0x3FF7154760000000
  %2660 = call float @dx.op.unary.f32(i32 21, float %2659)  ; Exp(value)
  %2661 = fmul fast float %2660, %2652
  br label %2662

; <label>:2662                                    ; preds = %2651, %2611
  %2663 = phi float [ %2661, %2651 ], [ 1.000000e+00, %2611 ]
  %2664 = fmul fast float %2637, %17
  %2665 = fmul fast float %2664, %2663
  %2666 = fcmp fast ole float %2635, %10
  %2667 = fcmp fast olt float %2635, 0x3F1A36E2E0000000
  %2668 = or i1 %2666, %2667
  br i1 %2668, label %2715, label %2669

; <label>:2669                                    ; preds = %2662
  %2670 = fdiv fast float %10, %2635
  %2671 = fmul fast float %2670, %2627
  %2672 = fmul fast float %2670, %2628
  %2673 = fmul fast float %2670, %2629
  %2674 = fadd fast float %2671, %18
  %2675 = fadd fast float %2672, %19
  %2676 = fadd fast float %2673, %20
  %2677 = fadd fast float %2674, -9.000000e+02
  %2678 = fadd fast float %2675, -1.500000e+01
  %2679 = fadd fast float %2676, -7.500000e+02
  %2680 = fmul fast float %2677, 0x3F62345680000000
  %2681 = fmul fast float %2678, 0x3F62345680000000
  %2682 = fmul fast float %2679, 0x3F62345680000000
  %2683 = call float @dx.op.dot3.f32(i32 55, float %2680, float %2681, float %2682, float %2680, float %2681, float %2682)  ; Dot3(ax,ay,az,bx,by,bz)
  %2684 = fsub fast float 1.000000e+00, %2683
  %2685 = call float @dx.op.unary.f32(i32 7, float %2684)  ; Saturate(value)
  %2686 = fmul fast float %2685, %2685
  %2687 = fadd fast float %2674, %2624
  %2688 = fadd fast float %2675, %2625
  %2689 = fadd fast float %2676, %2626
  %2690 = fmul fast float %2687, 0x3F52345680000000
  %2691 = fadd fast float %2690, -2.000000e+00
  %2692 = fmul fast float %2688, 0x3F52345680000000
  %2693 = fadd fast float %2692, 0xBFA1111120000000
  %2694 = fmul fast float %2689, 0x3F52345680000000
  %2695 = fadd fast float %2694, 0xBFFAAAAAC0000000
  %2696 = call float @dx.op.dot3.f32(i32 55, float %2691, float %2693, float %2695, float %2691, float %2693, float %2695)  ; Dot3(ax,ay,az,bx,by,bz)
  %2697 = fsub fast float 1.000000e+00, %2696
  %2698 = call float @dx.op.unary.f32(i32 7, float %2697)  ; Saturate(value)
  %2699 = fmul fast float %2698, %2698
  %2700 = fmul fast float %2699, 4.000000e+00
  %2701 = fadd fast float %2700, %2686
  %2702 = fadd fast float %2624, -9.000000e+02
  %2703 = fadd fast float %2625, -1.500000e+01
  %2704 = fadd fast float %2626, -7.500000e+02
  %2705 = fmul fast float %2702, 0x3F62345680000000
  %2706 = fmul fast float %2703, 0x3F62345680000000
  %2707 = fmul fast float %2704, 0x3F62345680000000
  %2708 = call float @dx.op.dot3.f32(i32 55, float %2705, float %2706, float %2707, float %2705, float %2706, float %2707)  ; Dot3(ax,ay,az,bx,by,bz)
  %2709 = fsub fast float 1.000000e+00, %2708
  %2710 = call float @dx.op.unary.f32(i32 7, float %2709)  ; Saturate(value)
  %2711 = fmul fast float %2710, %2710
  %2712 = fadd fast float %2701, %2711
  %2713 = fmul fast float %2636, 0x3F25D867E0000000
  %2714 = fmul fast float %2713, %2712
  br label %2715

; <label>:2715                                    ; preds = %2669, %2662
  %2716 = phi float [ %2714, %2669 ], [ 0.000000e+00, %2662 ]
  %2717 = fadd fast float %2716, %2665
  %2718 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2717)  ; FMin(a,b)
  %2719 = fmul fast float %2718, 0xBFF7154760000000
  %2720 = call float @dx.op.unary.f32(i32 21, float %2719)  ; Exp(value)
  %2721 = fsub fast float 1.000000e+00, %2720
  %2722 = call float @dx.op.binary.f32(i32 36, float %13, float %2721)  ; FMin(a,b)
  %2723 = fsub fast float %14, %2549
  %2724 = fsub fast float %15, %2550
  %2725 = fsub fast float %16, %2551
  %2726 = fmul fast float %2722, %2723
  %2727 = fmul fast float %2722, %2724
  %2728 = fmul fast float %2722, %2725
  %2729 = fadd fast float %2726, %2549
  %2730 = fadd fast float %2727, %2550
  %2731 = fadd fast float %2728, %2551
  br label %2732

; <label>:2732                                    ; preds = %2715, %2594, %2588
  %2733 = phi float [ %2729, %2715 ], [ %2549, %2594 ], [ %2549, %2588 ]
  %2734 = phi float [ %2730, %2715 ], [ %2550, %2594 ], [ %2550, %2588 ]
  %2735 = phi float [ %2731, %2715 ], [ %2551, %2594 ], [ %2551, %2588 ]
  %2736 = fadd fast float %6, 1.000000e+00
  %2737 = fadd fast float %7, 1.000000e+00
  %2738 = fsub fast float 1.000000e+00, %6
  %2739 = fmul fast float %37, %2736
  %2740 = fmul fast float %37, %2737
  %2741 = fmul fast float %37, %2738
  %2742 = fmul fast float %2739, %2733
  %2743 = fmul fast float %2740, %2734
  %2744 = fmul fast float %2741, %2735
  %2745 = fcmp fast ult float %38, 5.000000e-01
  br i1 %2745, label %2771, label %2746

; <label>:2746                                    ; preds = %2732
  %2747 = fmul fast float %2742, 0x4004147AE0000000
  %2748 = fmul fast float %2743, 0x4004147AE0000000
  %2749 = fmul fast float %2744, 0x4004147AE0000000
  %2750 = fadd fast float %2747, 0x3F9EB851E0000000
  %2751 = fadd fast float %2748, 0x3F9EB851E0000000
  %2752 = fadd fast float %2749, 0x3F9EB851E0000000
  %2753 = fmul fast float %2750, %2742
  %2754 = fmul fast float %2751, %2743
  %2755 = fmul fast float %2752, %2744
  %2756 = fmul fast float %2742, 0x400370A3E0000000
  %2757 = fmul fast float %2743, 0x400370A3E0000000
  %2758 = fmul fast float %2744, 0x400370A3E0000000
  %2759 = fadd fast float %2756, 0x3FE2E147A0000000
  %2760 = fadd fast float %2757, 0x3FE2E147A0000000
  %2761 = fadd fast float %2758, 0x3FE2E147A0000000
  %2762 = fmul fast float %2759, %2742
  %2763 = fmul fast float %2760, %2743
  %2764 = fmul fast float %2761, %2744
  %2765 = fadd fast float %2762, 0x3FC1EB8520000000
  %2766 = fadd fast float %2763, 0x3FC1EB8520000000
  %2767 = fadd fast float %2764, 0x3FC1EB8520000000
  %2768 = fdiv fast float %2753, %2765
  %2769 = fdiv fast float %2754, %2766
  %2770 = fdiv fast float %2755, %2767
  br label %2771

; <label>:2771                                    ; preds = %2746, %2732
  %2772 = phi float [ %2768, %2746 ], [ %2742, %2732 ]
  %2773 = phi float [ %2769, %2746 ], [ %2743, %2732 ]
  %2774 = phi float [ %2770, %2746 ], [ %2744, %2732 ]
  %2775 = call float @dx.op.unary.f32(i32 7, float %2772)  ; Saturate(value)
  %2776 = call float @dx.op.unary.f32(i32 7, float %2773)  ; Saturate(value)
  %2777 = call float @dx.op.unary.f32(i32 7, float %2774)  ; Saturate(value)
  %2778 = call float @dx.op.dot3.f32(i32 55, float %2775, float %2776, float %2777, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2779 = fsub fast float %2775, %2778
  %2780 = fsub fast float %2776, %2778
  %2781 = fsub fast float %2777, %2778
  %2782 = fmul fast float %2779, %9
  %2783 = fmul fast float %2780, %9
  %2784 = fmul fast float %2781, %9
  %2785 = fadd fast float %2782, %2778
  %2786 = fadd fast float %2783, %2778
  %2787 = fadd fast float %2784, %2778
  %2788 = call float @dx.op.unary.f32(i32 7, float %2785)  ; Saturate(value)
  %2789 = call float @dx.op.unary.f32(i32 7, float %2786)  ; Saturate(value)
  %2790 = call float @dx.op.unary.f32(i32 7, float %2787)  ; Saturate(value)
  %2791 = fadd fast float %2788, 0xBFC70A3D80000000
  %2792 = fadd fast float %2789, 0xBFC70A3D80000000
  %2793 = fadd fast float %2790, 0xBFC70A3D80000000
  %2794 = fmul fast float %2791, %8
  %2795 = fmul fast float %2792, %8
  %2796 = fmul fast float %2793, %8
  %2797 = fadd fast float %2794, 0x3FC70A3D80000000
  %2798 = fadd fast float %2795, 0x3FC70A3D80000000
  %2799 = fadd fast float %2796, 0x3FC70A3D80000000
  %2800 = call float @dx.op.unary.f32(i32 7, float %2797)  ; Saturate(value)
  %2801 = call float @dx.op.unary.f32(i32 7, float %2798)  ; Saturate(value)
  %2802 = call float @dx.op.unary.f32(i32 7, float %2799)  ; Saturate(value)
  br label %2803

; <label>:2803                                    ; preds = %2771, %2554
  %2804 = phi float [ %2585, %2554 ], [ %2800, %2771 ]
  %2805 = phi float [ %2586, %2554 ], [ %2801, %2771 ]
  %2806 = phi float [ %2587, %2554 ], [ %2802, %2771 ]
  %2807 = fsub fast float %2804, %1944
  %2808 = fsub fast float %2805, %1945
  %2809 = fsub fast float %2806, %1946
  %2810 = fmul fast float %2807, %2541
  %2811 = fmul fast float %2808, %2541
  %2812 = fmul fast float %2809, %2541
  %2813 = fadd fast float %2810, %1944
  %2814 = fadd fast float %2811, %1945
  %2815 = fadd fast float %2812, %1946
  br label %2816

; <label>:2816                                    ; preds = %2803, %2526
  %2817 = phi float [ %2813, %2803 ], [ %1944, %2526 ]
  %2818 = phi float [ %2814, %2803 ], [ %1945, %2526 ]
  %2819 = phi float [ %2815, %2803 ], [ %1946, %2526 ]
  %2820 = add i32 %68, 1
  %2821 = call i32 @dx.op.binary.i32(i32 37, i32 %2820, i32 0)  ; IMax(a,b)
  %2822 = call i32 @dx.op.binary.i32(i32 38, i32 %2821, i32 %60)  ; IMin(a,b)
  %2823 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2822, i32 %2534, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2824 = extractvalue %dx.types.ResRet.f32 %2823, 0
  %2825 = fsub fast float %2824, %85
  %2826 = call float @dx.op.unary.f32(i32 6, float %2825)  ; FAbs(value)
  %2827 = fdiv fast float %2826, %1958
  %2828 = fsub fast float 1.000000e+00, %2827
  %2829 = call float @dx.op.unary.f32(i32 7, float %2828)  ; Saturate(value)
  %2830 = fcmp fast ugt float %2829, 0.000000e+00
  br i1 %2830, label %2831, label %3104

; <label>:2831                                    ; preds = %2816
  %2832 = call i32 @dx.op.binary.i32(i32 37, i32 %2822, i32 0)  ; IMax(a,b)
  %2833 = call i32 @dx.op.binary.i32(i32 37, i32 %2534, i32 0)  ; IMax(a,b)
  %2834 = call i32 @dx.op.binary.i32(i32 38, i32 %2832, i32 %60)  ; IMin(a,b)
  %2835 = call i32 @dx.op.binary.i32(i32 38, i32 %2833, i32 %61)  ; IMin(a,b)
  %2836 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2834, i32 %2835, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2837 = extractvalue %dx.types.ResRet.f32 %2836, 0
  %2838 = extractvalue %dx.types.ResRet.f32 %2836, 1
  %2839 = extractvalue %dx.types.ResRet.f32 %2836, 2
  %2840 = extractvalue %dx.types.ResRet.f32 %2836, 3
  %2841 = fcmp fast olt float %2840, 0.000000e+00
  br i1 %2841, label %2842, label %2876

; <label>:2842                                    ; preds = %2831
  %2843 = fcmp fast ogt float %2837, 0x3FA4B5DCC0000000
  %2844 = fcmp fast ogt float %2838, 0x3FA4B5DCC0000000
  %2845 = fcmp fast ogt float %2839, 0x3FA4B5DCC0000000
  %2846 = select i1 %2843, float 0.000000e+00, float 1.000000e+00
  %2847 = select i1 %2844, float 0.000000e+00, float 1.000000e+00
  %2848 = select i1 %2845, float 0.000000e+00, float 1.000000e+00
  %2849 = fmul fast float %2837, 0x3FB3D07220000000
  %2850 = fmul fast float %2838, 0x3FB3D07220000000
  %2851 = fmul fast float %2839, 0x3FB3D07220000000
  %2852 = fadd fast float %2837, 0x3FAC28F5C0000000
  %2853 = fadd fast float %2838, 0x3FAC28F5C0000000
  %2854 = fadd fast float %2839, 0x3FAC28F5C0000000
  %2855 = fmul fast float %2852, 0x3FEE54EDE0000000
  %2856 = fmul fast float %2853, 0x3FEE54EDE0000000
  %2857 = fmul fast float %2854, 0x3FEE54EDE0000000
  %2858 = call float @dx.op.unary.f32(i32 23, float %2855)  ; Log(value)
  %2859 = call float @dx.op.unary.f32(i32 23, float %2856)  ; Log(value)
  %2860 = call float @dx.op.unary.f32(i32 23, float %2857)  ; Log(value)
  %2861 = fmul fast float %2858, 0x4003333340000000
  %2862 = fmul fast float %2859, 0x4003333340000000
  %2863 = fmul fast float %2860, 0x4003333340000000
  %2864 = call float @dx.op.unary.f32(i32 21, float %2861)  ; Exp(value)
  %2865 = call float @dx.op.unary.f32(i32 21, float %2862)  ; Exp(value)
  %2866 = call float @dx.op.unary.f32(i32 21, float %2863)  ; Exp(value)
  %2867 = fsub fast float %2849, %2864
  %2868 = fsub fast float %2850, %2865
  %2869 = fsub fast float %2851, %2866
  %2870 = fmul fast float %2867, %2846
  %2871 = fmul fast float %2868, %2847
  %2872 = fmul fast float %2869, %2848
  %2873 = fadd fast float %2870, %2864
  %2874 = fadd fast float %2871, %2865
  %2875 = fadd fast float %2872, %2866
  br label %3091

; <label>:2876                                    ; preds = %2831
  %2877 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2834, i32 %2835, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2878 = extractvalue %dx.types.ResRet.f32 %2877, 0
  %2879 = fcmp fast ogt float %39, 5.000000e-01
  %2880 = fcmp fast olt float %2878, 1.000000e+00
  %2881 = and i1 %2879, %2880
  br i1 %2881, label %2882, label %3020

; <label>:2882                                    ; preds = %2876
  %2883 = sitofp i32 %2834 to float
  %2884 = sitofp i32 %2835 to float
  %2885 = fadd fast float %2883, 5.000000e-01
  %2886 = fadd fast float %2884, 5.000000e-01
  %2887 = fdiv fast float %2885, %46
  %2888 = fdiv fast float %2886, %47
  %2889 = fmul fast float %2887, 2.000000e+00
  %2890 = fmul fast float %2888, 2.000000e+00
  %2891 = fadd fast float %2889, -1.000000e+00
  %2892 = fsub fast float 1.000000e+00, %2890
  %2893 = fmul fast float %2891, %36
  %2894 = call float @dx.op.tertiary.f32(i32 46, float %2892, float %32, float %2893)  ; FMad(a,b,c)
  %2895 = call float @dx.op.tertiary.f32(i32 46, float %2878, float %28, float %2894)  ; FMad(a,b,c)
  %2896 = fadd fast float %2895, %24
  %2897 = call float @dx.op.unary.f32(i32 6, float %2896)  ; FAbs(value)
  %2898 = fcmp fast ogt float %2897, 0x3EB0C6F7A0000000
  br i1 %2898, label %2899, label %3020

; <label>:2899                                    ; preds = %2882
  %2900 = fmul fast float %2891, %35
  %2901 = call float @dx.op.tertiary.f32(i32 46, float %2892, float %31, float %2900)  ; FMad(a,b,c)
  %2902 = call float @dx.op.tertiary.f32(i32 46, float %2878, float %27, float %2901)  ; FMad(a,b,c)
  %2903 = fadd fast float %2902, %23
  %2904 = fmul fast float %2891, %34
  %2905 = call float @dx.op.tertiary.f32(i32 46, float %2892, float %30, float %2904)  ; FMad(a,b,c)
  %2906 = call float @dx.op.tertiary.f32(i32 46, float %2878, float %26, float %2905)  ; FMad(a,b,c)
  %2907 = fadd fast float %2906, %22
  %2908 = fmul fast float %2891, %33
  %2909 = call float @dx.op.tertiary.f32(i32 46, float %2892, float %29, float %2908)  ; FMad(a,b,c)
  %2910 = call float @dx.op.tertiary.f32(i32 46, float %2878, float %25, float %2909)  ; FMad(a,b,c)
  %2911 = fadd fast float %2910, %21
  %2912 = fdiv fast float %2911, %2896
  %2913 = fdiv fast float %2907, %2896
  %2914 = fdiv fast float %2903, %2896
  %2915 = fsub fast float %2912, %18
  %2916 = fsub fast float %2913, %19
  %2917 = fsub fast float %2914, %20
  %2918 = fmul fast float %2915, %2915
  %2919 = fmul fast float %2916, %2916
  %2920 = fadd fast float %2919, %2918
  %2921 = fmul fast float %2917, %2917
  %2922 = fadd fast float %2920, %2921
  %2923 = call float @dx.op.unary.f32(i32 24, float %2922)  ; Sqrt(value)
  %2924 = fsub fast float %2923, %10
  %2925 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2924)  ; FMax(a,b)
  %2926 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %2926, label %2927, label %2950

; <label>:2927                                    ; preds = %2899
  %2928 = call float @dx.op.unary.f32(i32 6, float %2916)  ; FAbs(value)
  %2929 = fmul fast float %2928, %12
  %2930 = fcmp fast olt float %2929, 0x3F50624DE0000000
  br i1 %2930, label %2931, label %2934

; <label>:2931                                    ; preds = %2927
  %2932 = fmul fast float %2929, 5.000000e-01
  %2933 = fsub fast float 1.000000e+00, %2932
  br label %2939

; <label>:2934                                    ; preds = %2927
  %2935 = fmul fast float %2929, 0xBFF7154760000000
  %2936 = call float @dx.op.unary.f32(i32 21, float %2935)  ; Exp(value)
  %2937 = fsub fast float 1.000000e+00, %2936
  %2938 = fdiv fast float %2937, %2929
  br label %2939

; <label>:2939                                    ; preds = %2934, %2931
  %2940 = phi float [ %2933, %2931 ], [ %2938, %2934 ]
  %2941 = call float @dx.op.binary.f32(i32 36, float %2913, float %19)  ; FMin(a,b)
  %2942 = fsub fast float %2941, %11
  %2943 = fmul fast float %12, %2942
  %2944 = fsub fast float -0.000000e+00, %2943
  %2945 = call float @dx.op.binary.f32(i32 35, float %2944, float -4.000000e+01)  ; FMax(a,b)
  %2946 = call float @dx.op.binary.f32(i32 36, float %2945, float 5.000000e+00)  ; FMin(a,b)
  %2947 = fmul fast float %2946, 0x3FF7154760000000
  %2948 = call float @dx.op.unary.f32(i32 21, float %2947)  ; Exp(value)
  %2949 = fmul fast float %2948, %2940
  br label %2950

; <label>:2950                                    ; preds = %2939, %2899
  %2951 = phi float [ %2949, %2939 ], [ 1.000000e+00, %2899 ]
  %2952 = fmul fast float %2925, %17
  %2953 = fmul fast float %2952, %2951
  %2954 = fcmp fast ole float %2923, %10
  %2955 = fcmp fast olt float %2923, 0x3F1A36E2E0000000
  %2956 = or i1 %2954, %2955
  br i1 %2956, label %3003, label %2957

; <label>:2957                                    ; preds = %2950
  %2958 = fdiv fast float %10, %2923
  %2959 = fmul fast float %2958, %2915
  %2960 = fmul fast float %2958, %2916
  %2961 = fmul fast float %2958, %2917
  %2962 = fadd fast float %2959, %18
  %2963 = fadd fast float %2960, %19
  %2964 = fadd fast float %2961, %20
  %2965 = fadd fast float %2962, -9.000000e+02
  %2966 = fadd fast float %2963, -1.500000e+01
  %2967 = fadd fast float %2964, -7.500000e+02
  %2968 = fmul fast float %2965, 0x3F62345680000000
  %2969 = fmul fast float %2966, 0x3F62345680000000
  %2970 = fmul fast float %2967, 0x3F62345680000000
  %2971 = call float @dx.op.dot3.f32(i32 55, float %2968, float %2969, float %2970, float %2968, float %2969, float %2970)  ; Dot3(ax,ay,az,bx,by,bz)
  %2972 = fsub fast float 1.000000e+00, %2971
  %2973 = call float @dx.op.unary.f32(i32 7, float %2972)  ; Saturate(value)
  %2974 = fmul fast float %2973, %2973
  %2975 = fadd fast float %2962, %2912
  %2976 = fadd fast float %2963, %2913
  %2977 = fadd fast float %2964, %2914
  %2978 = fmul fast float %2975, 0x3F52345680000000
  %2979 = fadd fast float %2978, -2.000000e+00
  %2980 = fmul fast float %2976, 0x3F52345680000000
  %2981 = fadd fast float %2980, 0xBFA1111120000000
  %2982 = fmul fast float %2977, 0x3F52345680000000
  %2983 = fadd fast float %2982, 0xBFFAAAAAC0000000
  %2984 = call float @dx.op.dot3.f32(i32 55, float %2979, float %2981, float %2983, float %2979, float %2981, float %2983)  ; Dot3(ax,ay,az,bx,by,bz)
  %2985 = fsub fast float 1.000000e+00, %2984
  %2986 = call float @dx.op.unary.f32(i32 7, float %2985)  ; Saturate(value)
  %2987 = fmul fast float %2986, %2986
  %2988 = fmul fast float %2987, 4.000000e+00
  %2989 = fadd fast float %2988, %2974
  %2990 = fadd fast float %2912, -9.000000e+02
  %2991 = fadd fast float %2913, -1.500000e+01
  %2992 = fadd fast float %2914, -7.500000e+02
  %2993 = fmul fast float %2990, 0x3F62345680000000
  %2994 = fmul fast float %2991, 0x3F62345680000000
  %2995 = fmul fast float %2992, 0x3F62345680000000
  %2996 = call float @dx.op.dot3.f32(i32 55, float %2993, float %2994, float %2995, float %2993, float %2994, float %2995)  ; Dot3(ax,ay,az,bx,by,bz)
  %2997 = fsub fast float 1.000000e+00, %2996
  %2998 = call float @dx.op.unary.f32(i32 7, float %2997)  ; Saturate(value)
  %2999 = fmul fast float %2998, %2998
  %3000 = fadd fast float %2989, %2999
  %3001 = fmul fast float %2924, 0x3F25D867E0000000
  %3002 = fmul fast float %3001, %3000
  br label %3003

; <label>:3003                                    ; preds = %2957, %2950
  %3004 = phi float [ %3002, %2957 ], [ 0.000000e+00, %2950 ]
  %3005 = fadd fast float %3004, %2953
  %3006 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3005)  ; FMin(a,b)
  %3007 = fmul fast float %3006, 0xBFF7154760000000
  %3008 = call float @dx.op.unary.f32(i32 21, float %3007)  ; Exp(value)
  %3009 = fsub fast float 1.000000e+00, %3008
  %3010 = call float @dx.op.binary.f32(i32 36, float %13, float %3009)  ; FMin(a,b)
  %3011 = fsub fast float %14, %2837
  %3012 = fsub fast float %15, %2838
  %3013 = fsub fast float %16, %2839
  %3014 = fmul fast float %3010, %3011
  %3015 = fmul fast float %3010, %3012
  %3016 = fmul fast float %3010, %3013
  %3017 = fadd fast float %3014, %2837
  %3018 = fadd fast float %3015, %2838
  %3019 = fadd fast float %3016, %2839
  br label %3020

; <label>:3020                                    ; preds = %3003, %2882, %2876
  %3021 = phi float [ %3017, %3003 ], [ %2837, %2882 ], [ %2837, %2876 ]
  %3022 = phi float [ %3018, %3003 ], [ %2838, %2882 ], [ %2838, %2876 ]
  %3023 = phi float [ %3019, %3003 ], [ %2839, %2882 ], [ %2839, %2876 ]
  %3024 = fadd fast float %6, 1.000000e+00
  %3025 = fadd fast float %7, 1.000000e+00
  %3026 = fsub fast float 1.000000e+00, %6
  %3027 = fmul fast float %37, %3024
  %3028 = fmul fast float %37, %3025
  %3029 = fmul fast float %37, %3026
  %3030 = fmul fast float %3027, %3021
  %3031 = fmul fast float %3028, %3022
  %3032 = fmul fast float %3029, %3023
  %3033 = fcmp fast ult float %38, 5.000000e-01
  br i1 %3033, label %3059, label %3034

; <label>:3034                                    ; preds = %3020
  %3035 = fmul fast float %3030, 0x4004147AE0000000
  %3036 = fmul fast float %3031, 0x4004147AE0000000
  %3037 = fmul fast float %3032, 0x4004147AE0000000
  %3038 = fadd fast float %3035, 0x3F9EB851E0000000
  %3039 = fadd fast float %3036, 0x3F9EB851E0000000
  %3040 = fadd fast float %3037, 0x3F9EB851E0000000
  %3041 = fmul fast float %3038, %3030
  %3042 = fmul fast float %3039, %3031
  %3043 = fmul fast float %3040, %3032
  %3044 = fmul fast float %3030, 0x400370A3E0000000
  %3045 = fmul fast float %3031, 0x400370A3E0000000
  %3046 = fmul fast float %3032, 0x400370A3E0000000
  %3047 = fadd fast float %3044, 0x3FE2E147A0000000
  %3048 = fadd fast float %3045, 0x3FE2E147A0000000
  %3049 = fadd fast float %3046, 0x3FE2E147A0000000
  %3050 = fmul fast float %3047, %3030
  %3051 = fmul fast float %3048, %3031
  %3052 = fmul fast float %3049, %3032
  %3053 = fadd fast float %3050, 0x3FC1EB8520000000
  %3054 = fadd fast float %3051, 0x3FC1EB8520000000
  %3055 = fadd fast float %3052, 0x3FC1EB8520000000
  %3056 = fdiv fast float %3041, %3053
  %3057 = fdiv fast float %3042, %3054
  %3058 = fdiv fast float %3043, %3055
  br label %3059

; <label>:3059                                    ; preds = %3034, %3020
  %3060 = phi float [ %3056, %3034 ], [ %3030, %3020 ]
  %3061 = phi float [ %3057, %3034 ], [ %3031, %3020 ]
  %3062 = phi float [ %3058, %3034 ], [ %3032, %3020 ]
  %3063 = call float @dx.op.unary.f32(i32 7, float %3060)  ; Saturate(value)
  %3064 = call float @dx.op.unary.f32(i32 7, float %3061)  ; Saturate(value)
  %3065 = call float @dx.op.unary.f32(i32 7, float %3062)  ; Saturate(value)
  %3066 = call float @dx.op.dot3.f32(i32 55, float %3063, float %3064, float %3065, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3067 = fsub fast float %3063, %3066
  %3068 = fsub fast float %3064, %3066
  %3069 = fsub fast float %3065, %3066
  %3070 = fmul fast float %3067, %9
  %3071 = fmul fast float %3068, %9
  %3072 = fmul fast float %3069, %9
  %3073 = fadd fast float %3070, %3066
  %3074 = fadd fast float %3071, %3066
  %3075 = fadd fast float %3072, %3066
  %3076 = call float @dx.op.unary.f32(i32 7, float %3073)  ; Saturate(value)
  %3077 = call float @dx.op.unary.f32(i32 7, float %3074)  ; Saturate(value)
  %3078 = call float @dx.op.unary.f32(i32 7, float %3075)  ; Saturate(value)
  %3079 = fadd fast float %3076, 0xBFC70A3D80000000
  %3080 = fadd fast float %3077, 0xBFC70A3D80000000
  %3081 = fadd fast float %3078, 0xBFC70A3D80000000
  %3082 = fmul fast float %3079, %8
  %3083 = fmul fast float %3080, %8
  %3084 = fmul fast float %3081, %8
  %3085 = fadd fast float %3082, 0x3FC70A3D80000000
  %3086 = fadd fast float %3083, 0x3FC70A3D80000000
  %3087 = fadd fast float %3084, 0x3FC70A3D80000000
  %3088 = call float @dx.op.unary.f32(i32 7, float %3085)  ; Saturate(value)
  %3089 = call float @dx.op.unary.f32(i32 7, float %3086)  ; Saturate(value)
  %3090 = call float @dx.op.unary.f32(i32 7, float %3087)  ; Saturate(value)
  br label %3091

; <label>:3091                                    ; preds = %3059, %2842
  %3092 = phi float [ %2873, %2842 ], [ %3088, %3059 ]
  %3093 = phi float [ %2874, %2842 ], [ %3089, %3059 ]
  %3094 = phi float [ %2875, %2842 ], [ %3090, %3059 ]
  %3095 = fsub fast float %3092, %1944
  %3096 = fsub fast float %3093, %1945
  %3097 = fsub fast float %3094, %1946
  %3098 = fmul fast float %3095, %2829
  %3099 = fmul fast float %3096, %2829
  %3100 = fmul fast float %3097, %2829
  %3101 = fadd fast float %3098, %1944
  %3102 = fadd fast float %3099, %1945
  %3103 = fadd fast float %3100, %1946
  br label %3104

; <label>:3104                                    ; preds = %3091, %2816
  %3105 = phi float [ %3101, %3091 ], [ %1944, %2816 ]
  %3106 = phi float [ %3102, %3091 ], [ %1945, %2816 ]
  %3107 = phi float [ %3103, %3091 ], [ %1946, %2816 ]
  %3108 = call float @dx.op.binary.f32(i32 36, float %2817, float %3105)  ; FMin(a,b)
  %3109 = call float @dx.op.binary.f32(i32 36, float %2818, float %3106)  ; FMin(a,b)
  %3110 = call float @dx.op.binary.f32(i32 36, float %2819, float %3107)  ; FMin(a,b)
  %3111 = call float @dx.op.binary.f32(i32 36, float %2239, float %2527)  ; FMin(a,b)
  %3112 = call float @dx.op.binary.f32(i32 36, float %2240, float %2528)  ; FMin(a,b)
  %3113 = call float @dx.op.binary.f32(i32 36, float %2241, float %2529)  ; FMin(a,b)
  %3114 = call float @dx.op.binary.f32(i32 36, float %3111, float %3108)  ; FMin(a,b)
  %3115 = call float @dx.op.binary.f32(i32 36, float %3112, float %3109)  ; FMin(a,b)
  %3116 = call float @dx.op.binary.f32(i32 36, float %3113, float %3110)  ; FMin(a,b)
  %3117 = call float @dx.op.binary.f32(i32 36, float %1944, float %3114)  ; FMin(a,b)
  %3118 = call float @dx.op.binary.f32(i32 36, float %1945, float %3115)  ; FMin(a,b)
  %3119 = call float @dx.op.binary.f32(i32 36, float %1946, float %3116)  ; FMin(a,b)
  %3120 = call float @dx.op.binary.f32(i32 35, float %2817, float %3105)  ; FMax(a,b)
  %3121 = call float @dx.op.binary.f32(i32 35, float %2818, float %3106)  ; FMax(a,b)
  %3122 = call float @dx.op.binary.f32(i32 35, float %2819, float %3107)  ; FMax(a,b)
  %3123 = call float @dx.op.binary.f32(i32 35, float %2239, float %2527)  ; FMax(a,b)
  %3124 = call float @dx.op.binary.f32(i32 35, float %2240, float %2528)  ; FMax(a,b)
  %3125 = call float @dx.op.binary.f32(i32 35, float %2241, float %2529)  ; FMax(a,b)
  %3126 = call float @dx.op.binary.f32(i32 35, float %3123, float %3120)  ; FMax(a,b)
  %3127 = call float @dx.op.binary.f32(i32 35, float %3124, float %3121)  ; FMax(a,b)
  %3128 = call float @dx.op.binary.f32(i32 35, float %3125, float %3122)  ; FMax(a,b)
  %3129 = call float @dx.op.binary.f32(i32 35, float %1944, float %3126)  ; FMax(a,b)
  %3130 = call float @dx.op.binary.f32(i32 35, float %1945, float %3127)  ; FMax(a,b)
  %3131 = call float @dx.op.binary.f32(i32 35, float %1946, float %3128)  ; FMax(a,b)
  %3132 = fsub fast float %3129, %3117
  %3133 = fsub fast float %3130, %3118
  %3134 = fsub fast float %3131, %3119
  %3135 = call float @dx.op.unary.f32(i32 6, float %3132)  ; FAbs(value)
  %3136 = call float @dx.op.unary.f32(i32 6, float %3133)  ; FAbs(value)
  %3137 = call float @dx.op.unary.f32(i32 6, float %3134)  ; FAbs(value)
  %3138 = call float @dx.op.binary.f32(i32 35, float %3136, float %3137)  ; FMax(a,b)
  %3139 = call float @dx.op.binary.f32(i32 35, float %3135, float %3138)  ; FMax(a,b)
  %3140 = call float @dx.op.binary.f32(i32 35, float %3130, float %3131)  ; FMax(a,b)
  %3141 = call float @dx.op.binary.f32(i32 35, float %3129, float %3140)  ; FMax(a,b)
  %3142 = fmul fast float %3141, 1.250000e-01
  %3143 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %3142)  ; FMax(a,b)
  %3144 = fcmp fast ogt float %3139, %3143
  br i1 %3144, label %3145, label %3207

; <label>:3145                                    ; preds = %3104
  %3146 = fsub fast float %2239, %2527
  %3147 = fsub fast float %2240, %2528
  %3148 = fsub fast float %2241, %2529
  %3149 = call float @dx.op.unary.f32(i32 6, float %3146)  ; FAbs(value)
  %3150 = call float @dx.op.unary.f32(i32 6, float %3147)  ; FAbs(value)
  %3151 = call float @dx.op.unary.f32(i32 6, float %3148)  ; FAbs(value)
  %3152 = call float @dx.op.binary.f32(i32 35, float %3150, float %3151)  ; FMax(a,b)
  %3153 = call float @dx.op.binary.f32(i32 35, float %3149, float %3152)  ; FMax(a,b)
  %3154 = fsub fast float %2817, %3105
  %3155 = fsub fast float %2818, %3106
  %3156 = fsub fast float %2819, %3107
  %3157 = call float @dx.op.unary.f32(i32 6, float %3154)  ; FAbs(value)
  %3158 = call float @dx.op.unary.f32(i32 6, float %3155)  ; FAbs(value)
  %3159 = call float @dx.op.unary.f32(i32 6, float %3156)  ; FAbs(value)
  %3160 = call float @dx.op.binary.f32(i32 35, float %3158, float %3159)  ; FMax(a,b)
  %3161 = call float @dx.op.binary.f32(i32 35, float %3157, float %3160)  ; FMax(a,b)
  %3162 = fcmp fast olt float %3153, %3161
  %3163 = select i1 %3162, float %2239, float %2817
  %3164 = select i1 %3162, float %2240, float %2818
  %3165 = select i1 %3162, float %2241, float %2819
  %3166 = select i1 %3162, float %2527, float %3105
  %3167 = select i1 %3162, float %2528, float %3106
  %3168 = select i1 %3162, float %2529, float %3107
  %3169 = fsub fast float %1944, %3166
  %3170 = fsub fast float %1945, %3167
  %3171 = fsub fast float %1946, %3168
  %3172 = fsub fast float %1944, %3163
  %3173 = fsub fast float %1945, %3164
  %3174 = fsub fast float %1946, %3165
  %3175 = call float @dx.op.dot3.f32(i32 55, float %3172, float %3173, float %3174, float %3169, float %3170, float %3171)  ; Dot3(ax,ay,az,bx,by,bz)
  %3176 = fcmp fast ogt float %3175, 0.000000e+00
  br i1 %3176, label %3177, label %3188

; <label>:3177                                    ; preds = %3145
  %3178 = fsub fast float %3163, %3166
  %3179 = fsub fast float %3164, %3167
  %3180 = fsub fast float %3165, %3168
  %3181 = call float @dx.op.unary.f32(i32 6, float %3178)  ; FAbs(value)
  %3182 = call float @dx.op.unary.f32(i32 6, float %3179)  ; FAbs(value)
  %3183 = call float @dx.op.unary.f32(i32 6, float %3180)  ; FAbs(value)
  %3184 = call float @dx.op.binary.f32(i32 35, float %3182, float %3183)  ; FMax(a,b)
  %3185 = call float @dx.op.binary.f32(i32 35, float %3181, float %3184)  ; FMax(a,b)
  %3186 = fmul fast float %3139, 2.500000e-01
  %3187 = fcmp fast olt float %3185, %3186
  br label %3188

; <label>:3188                                    ; preds = %3177, %3145
  %3189 = phi i1 [ false, %3145 ], [ %3187, %3177 ]
  %3190 = select i1 %3189, float 5.000000e-01, float 1.000000e+00
  %3191 = fmul fast float %3190, %3
  %3192 = fadd fast float %3163, %3166
  %3193 = fadd fast float %3164, %3167
  %3194 = fadd fast float %3165, %3168
  %3195 = fmul fast float %3192, 5.000000e-01
  %3196 = fmul fast float %3193, 5.000000e-01
  %3197 = fmul fast float %3194, 5.000000e-01
  %3198 = fsub fast float %3195, %1944
  %3199 = fsub fast float %3196, %1945
  %3200 = fsub fast float %3197, %1946
  %3201 = fmul fast float %3191, %3198
  %3202 = fmul fast float %3191, %3199
  %3203 = fmul fast float %3191, %3200
  %3204 = fadd fast float %3201, %1944
  %3205 = fadd fast float %3202, %1945
  %3206 = fadd fast float %3203, %1946
  br label %3207

; <label>:3207                                    ; preds = %3188, %3104, %1915
  %3208 = phi float [ %1944, %1915 ], [ %3204, %3188 ], [ %1944, %3104 ]
  %3209 = phi float [ %1945, %1915 ], [ %3205, %3188 ], [ %1945, %3104 ]
  %3210 = phi float [ %1946, %1915 ], [ %3206, %3188 ], [ %1946, %3104 ]
  %3211 = fcmp fast ogt float %3208, 0x3F69A5C380000000
  %3212 = fcmp fast ogt float %3209, 0x3F69A5C380000000
  %3213 = fcmp fast ogt float %3210, 0x3F69A5C380000000
  %3214 = select i1 %3211, float 0.000000e+00, float 1.000000e+00
  %3215 = select i1 %3212, float 0.000000e+00, float 1.000000e+00
  %3216 = select i1 %3213, float 0.000000e+00, float 1.000000e+00
  %3217 = fmul fast float %3208, 0x4029D70A40000000
  %3218 = fmul fast float %3209, 0x4029D70A40000000
  %3219 = fmul fast float %3210, 0x4029D70A40000000
  %3220 = call float @dx.op.binary.f32(i32 35, float %3208, float 0.000000e+00)  ; FMax(a,b)
  %3221 = call float @dx.op.binary.f32(i32 35, float %3209, float 0.000000e+00)  ; FMax(a,b)
  %3222 = call float @dx.op.binary.f32(i32 35, float %3210, float 0.000000e+00)  ; FMax(a,b)
  %3223 = call float @dx.op.unary.f32(i32 23, float %3220)  ; Log(value)
  %3224 = call float @dx.op.unary.f32(i32 23, float %3221)  ; Log(value)
  %3225 = call float @dx.op.unary.f32(i32 23, float %3222)  ; Log(value)
  %3226 = fmul fast float %3223, 0x3FDAAAAAA0000000
  %3227 = fmul fast float %3224, 0x3FDAAAAAA0000000
  %3228 = fmul fast float %3225, 0x3FDAAAAAA0000000
  %3229 = call float @dx.op.unary.f32(i32 21, float %3226)  ; Exp(value)
  %3230 = call float @dx.op.unary.f32(i32 21, float %3227)  ; Exp(value)
  %3231 = call float @dx.op.unary.f32(i32 21, float %3228)  ; Exp(value)
  %3232 = fmul fast float %3229, 0x3FF0E147A0000000
  %3233 = fmul fast float %3230, 0x3FF0E147A0000000
  %3234 = fmul fast float %3231, 0x3FF0E147A0000000
  %3235 = fadd fast float %3232, 0xBFAC28F5C0000000
  %3236 = fadd fast float %3233, 0xBFAC28F5C0000000
  %3237 = fadd fast float %3234, 0xBFAC28F5C0000000
  %3238 = fsub fast float %3217, %3235
  %3239 = fsub fast float %3218, %3236
  %3240 = fsub fast float %3219, %3237
  %3241 = fmul fast float %3238, %3214
  %3242 = fmul fast float %3239, %3215
  %3243 = fmul fast float %3240, %3216
  %3244 = fadd fast float %3241, %3235
  %3245 = fadd fast float %3242, %3236
  %3246 = fadd fast float %3243, %3237
  br label %3247

; <label>:3247                                    ; preds = %3207, %1732
  %3248 = phi float [ %1727, %1732 ], [ %3244, %3207 ]
  %3249 = phi float [ %1728, %1732 ], [ %3245, %3207 ]
  %3250 = phi float [ %1729, %1732 ], [ %3246, %3207 ]
  %3251 = phi float [ %1733, %1732 ], [ %1730, %3207 ]
  %3252 = fcmp fast ogt float %3248, 0x3FA4B5DCC0000000
  %3253 = fcmp fast ogt float %3249, 0x3FA4B5DCC0000000
  %3254 = fcmp fast ogt float %3250, 0x3FA4B5DCC0000000
  %3255 = select i1 %3252, float 0.000000e+00, float 1.000000e+00
  %3256 = select i1 %3253, float 0.000000e+00, float 1.000000e+00
  %3257 = select i1 %3254, float 0.000000e+00, float 1.000000e+00
  %3258 = fmul fast float %3248, 0x3FB3D07220000000
  %3259 = fmul fast float %3249, 0x3FB3D07220000000
  %3260 = fmul fast float %3250, 0x3FB3D07220000000
  %3261 = fadd fast float %3248, 0x3FAC28F5C0000000
  %3262 = fadd fast float %3249, 0x3FAC28F5C0000000
  %3263 = fadd fast float %3250, 0x3FAC28F5C0000000
  %3264 = fmul fast float %3261, 0x3FEE54EDE0000000
  %3265 = fmul fast float %3262, 0x3FEE54EDE0000000
  %3266 = fmul fast float %3263, 0x3FEE54EDE0000000
  %3267 = call float @dx.op.unary.f32(i32 23, float %3264)  ; Log(value)
  %3268 = call float @dx.op.unary.f32(i32 23, float %3265)  ; Log(value)
  %3269 = call float @dx.op.unary.f32(i32 23, float %3266)  ; Log(value)
  %3270 = fmul fast float %3267, 0x4003333340000000
  %3271 = fmul fast float %3268, 0x4003333340000000
  %3272 = fmul fast float %3269, 0x4003333340000000
  %3273 = call float @dx.op.unary.f32(i32 21, float %3270)  ; Exp(value)
  %3274 = call float @dx.op.unary.f32(i32 21, float %3271)  ; Exp(value)
  %3275 = call float @dx.op.unary.f32(i32 21, float %3272)  ; Exp(value)
  %3276 = fsub fast float %3258, %3273
  %3277 = fsub fast float %3259, %3274
  %3278 = fsub fast float %3260, %3275
  %3279 = fmul fast float %3276, %3255
  %3280 = fmul fast float %3277, %3256
  %3281 = fmul fast float %3278, %3257
  %3282 = fadd fast float %3279, %3273
  %3283 = fadd fast float %3280, %3274
  %3284 = fadd fast float %3281, %3275
  %3285 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %64, i32 %71, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3286 = extractvalue %dx.types.ResRet.f32 %3285, 0
  %3287 = extractvalue %dx.types.ResRet.f32 %3285, 1
  %3288 = extractvalue %dx.types.ResRet.f32 %3285, 2
  %3289 = extractvalue %dx.types.ResRet.f32 %3285, 3
  %3290 = fcmp fast olt float %3289, 0.000000e+00
  br i1 %3290, label %3291, label %3293

; <label>:3291                                    ; preds = %3247
  %3292 = fsub fast float -1.000000e+00, %3289
  br label %4806

; <label>:3293                                    ; preds = %3247
  %3294 = fcmp fast ogt float %39, 5.000000e-01
  %3295 = fcmp fast olt float %87, 1.000000e+00
  %3296 = and i1 %3294, %3295
  br i1 %3296, label %3297, label %3435

; <label>:3297                                    ; preds = %3293
  %3298 = sitofp i32 %64 to float
  %3299 = sitofp i32 %71 to float
  %3300 = fadd fast float %3298, 5.000000e-01
  %3301 = fadd fast float %3299, 5.000000e-01
  %3302 = fdiv fast float %3300, %46
  %3303 = fdiv fast float %3301, %47
  %3304 = fmul fast float %3302, 2.000000e+00
  %3305 = fmul fast float %3303, 2.000000e+00
  %3306 = fadd fast float %3304, -1.000000e+00
  %3307 = fsub fast float 1.000000e+00, %3305
  %3308 = fmul fast float %3306, %36
  %3309 = call float @dx.op.tertiary.f32(i32 46, float %3307, float %32, float %3308)  ; FMad(a,b,c)
  %3310 = call float @dx.op.tertiary.f32(i32 46, float %87, float %28, float %3309)  ; FMad(a,b,c)
  %3311 = fadd fast float %3310, %24
  %3312 = call float @dx.op.unary.f32(i32 6, float %3311)  ; FAbs(value)
  %3313 = fcmp fast ogt float %3312, 0x3EB0C6F7A0000000
  br i1 %3313, label %3314, label %3435

; <label>:3314                                    ; preds = %3297
  %3315 = fmul fast float %3306, %35
  %3316 = call float @dx.op.tertiary.f32(i32 46, float %3307, float %31, float %3315)  ; FMad(a,b,c)
  %3317 = call float @dx.op.tertiary.f32(i32 46, float %87, float %27, float %3316)  ; FMad(a,b,c)
  %3318 = fadd fast float %3317, %23
  %3319 = fmul fast float %3306, %34
  %3320 = call float @dx.op.tertiary.f32(i32 46, float %3307, float %30, float %3319)  ; FMad(a,b,c)
  %3321 = call float @dx.op.tertiary.f32(i32 46, float %87, float %26, float %3320)  ; FMad(a,b,c)
  %3322 = fadd fast float %3321, %22
  %3323 = fmul fast float %3306, %33
  %3324 = call float @dx.op.tertiary.f32(i32 46, float %3307, float %29, float %3323)  ; FMad(a,b,c)
  %3325 = call float @dx.op.tertiary.f32(i32 46, float %87, float %25, float %3324)  ; FMad(a,b,c)
  %3326 = fadd fast float %3325, %21
  %3327 = fdiv fast float %3326, %3311
  %3328 = fdiv fast float %3322, %3311
  %3329 = fdiv fast float %3318, %3311
  %3330 = fsub fast float %3327, %18
  %3331 = fsub fast float %3328, %19
  %3332 = fsub fast float %3329, %20
  %3333 = fmul fast float %3330, %3330
  %3334 = fmul fast float %3331, %3331
  %3335 = fadd fast float %3334, %3333
  %3336 = fmul fast float %3332, %3332
  %3337 = fadd fast float %3335, %3336
  %3338 = call float @dx.op.unary.f32(i32 24, float %3337)  ; Sqrt(value)
  %3339 = fsub fast float %3338, %10
  %3340 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3339)  ; FMax(a,b)
  %3341 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %3341, label %3342, label %3365

; <label>:3342                                    ; preds = %3314
  %3343 = call float @dx.op.unary.f32(i32 6, float %3331)  ; FAbs(value)
  %3344 = fmul fast float %3343, %12
  %3345 = fcmp fast olt float %3344, 0x3F50624DE0000000
  br i1 %3345, label %3346, label %3349

; <label>:3346                                    ; preds = %3342
  %3347 = fmul fast float %3344, 5.000000e-01
  %3348 = fsub fast float 1.000000e+00, %3347
  br label %3354

; <label>:3349                                    ; preds = %3342
  %3350 = fmul fast float %3344, 0xBFF7154760000000
  %3351 = call float @dx.op.unary.f32(i32 21, float %3350)  ; Exp(value)
  %3352 = fsub fast float 1.000000e+00, %3351
  %3353 = fdiv fast float %3352, %3344
  br label %3354

; <label>:3354                                    ; preds = %3349, %3346
  %3355 = phi float [ %3348, %3346 ], [ %3353, %3349 ]
  %3356 = call float @dx.op.binary.f32(i32 36, float %3328, float %19)  ; FMin(a,b)
  %3357 = fsub fast float %3356, %11
  %3358 = fmul fast float %12, %3357
  %3359 = fsub fast float -0.000000e+00, %3358
  %3360 = call float @dx.op.binary.f32(i32 35, float %3359, float -4.000000e+01)  ; FMax(a,b)
  %3361 = call float @dx.op.binary.f32(i32 36, float %3360, float 5.000000e+00)  ; FMin(a,b)
  %3362 = fmul fast float %3361, 0x3FF7154760000000
  %3363 = call float @dx.op.unary.f32(i32 21, float %3362)  ; Exp(value)
  %3364 = fmul fast float %3363, %3355
  br label %3365

; <label>:3365                                    ; preds = %3354, %3314
  %3366 = phi float [ %3364, %3354 ], [ 1.000000e+00, %3314 ]
  %3367 = fmul fast float %3340, %17
  %3368 = fmul fast float %3367, %3366
  %3369 = fcmp fast ole float %3338, %10
  %3370 = fcmp fast olt float %3338, 0x3F1A36E2E0000000
  %3371 = or i1 %3369, %3370
  br i1 %3371, label %3418, label %3372

; <label>:3372                                    ; preds = %3365
  %3373 = fdiv fast float %10, %3338
  %3374 = fmul fast float %3373, %3330
  %3375 = fmul fast float %3373, %3331
  %3376 = fmul fast float %3373, %3332
  %3377 = fadd fast float %3374, %18
  %3378 = fadd fast float %3375, %19
  %3379 = fadd fast float %3376, %20
  %3380 = fadd fast float %3377, -9.000000e+02
  %3381 = fadd fast float %3378, -1.500000e+01
  %3382 = fadd fast float %3379, -7.500000e+02
  %3383 = fmul fast float %3380, 0x3F62345680000000
  %3384 = fmul fast float %3381, 0x3F62345680000000
  %3385 = fmul fast float %3382, 0x3F62345680000000
  %3386 = call float @dx.op.dot3.f32(i32 55, float %3383, float %3384, float %3385, float %3383, float %3384, float %3385)  ; Dot3(ax,ay,az,bx,by,bz)
  %3387 = fsub fast float 1.000000e+00, %3386
  %3388 = call float @dx.op.unary.f32(i32 7, float %3387)  ; Saturate(value)
  %3389 = fmul fast float %3388, %3388
  %3390 = fadd fast float %3377, %3327
  %3391 = fadd fast float %3378, %3328
  %3392 = fadd fast float %3379, %3329
  %3393 = fmul fast float %3390, 0x3F52345680000000
  %3394 = fadd fast float %3393, -2.000000e+00
  %3395 = fmul fast float %3391, 0x3F52345680000000
  %3396 = fadd fast float %3395, 0xBFA1111120000000
  %3397 = fmul fast float %3392, 0x3F52345680000000
  %3398 = fadd fast float %3397, 0xBFFAAAAAC0000000
  %3399 = call float @dx.op.dot3.f32(i32 55, float %3394, float %3396, float %3398, float %3394, float %3396, float %3398)  ; Dot3(ax,ay,az,bx,by,bz)
  %3400 = fsub fast float 1.000000e+00, %3399
  %3401 = call float @dx.op.unary.f32(i32 7, float %3400)  ; Saturate(value)
  %3402 = fmul fast float %3401, %3401
  %3403 = fmul fast float %3402, 4.000000e+00
  %3404 = fadd fast float %3403, %3389
  %3405 = fadd fast float %3327, -9.000000e+02
  %3406 = fadd fast float %3328, -1.500000e+01
  %3407 = fadd fast float %3329, -7.500000e+02
  %3408 = fmul fast float %3405, 0x3F62345680000000
  %3409 = fmul fast float %3406, 0x3F62345680000000
  %3410 = fmul fast float %3407, 0x3F62345680000000
  %3411 = call float @dx.op.dot3.f32(i32 55, float %3408, float %3409, float %3410, float %3408, float %3409, float %3410)  ; Dot3(ax,ay,az,bx,by,bz)
  %3412 = fsub fast float 1.000000e+00, %3411
  %3413 = call float @dx.op.unary.f32(i32 7, float %3412)  ; Saturate(value)
  %3414 = fmul fast float %3413, %3413
  %3415 = fadd fast float %3404, %3414
  %3416 = fmul fast float %3339, 0x3F25D867E0000000
  %3417 = fmul fast float %3416, %3415
  br label %3418

; <label>:3418                                    ; preds = %3372, %3365
  %3419 = phi float [ %3417, %3372 ], [ 0.000000e+00, %3365 ]
  %3420 = fadd fast float %3419, %3368
  %3421 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3420)  ; FMin(a,b)
  %3422 = fmul fast float %3421, 0xBFF7154760000000
  %3423 = call float @dx.op.unary.f32(i32 21, float %3422)  ; Exp(value)
  %3424 = fsub fast float 1.000000e+00, %3423
  %3425 = call float @dx.op.binary.f32(i32 36, float %13, float %3424)  ; FMin(a,b)
  %3426 = fsub fast float %14, %3286
  %3427 = fsub fast float %15, %3287
  %3428 = fsub fast float %16, %3288
  %3429 = fmul fast float %3425, %3426
  %3430 = fmul fast float %3425, %3427
  %3431 = fmul fast float %3425, %3428
  %3432 = fadd fast float %3429, %3286
  %3433 = fadd fast float %3430, %3287
  %3434 = fadd fast float %3431, %3288
  br label %3435

; <label>:3435                                    ; preds = %3418, %3297, %3293
  %3436 = phi float [ %3432, %3418 ], [ %3286, %3297 ], [ %3286, %3293 ]
  %3437 = phi float [ %3433, %3418 ], [ %3287, %3297 ], [ %3287, %3293 ]
  %3438 = phi float [ %3434, %3418 ], [ %3288, %3297 ], [ %3288, %3293 ]
  %3439 = fadd fast float %6, 1.000000e+00
  %3440 = fadd fast float %7, 1.000000e+00
  %3441 = fsub fast float 1.000000e+00, %6
  %3442 = fmul fast float %37, %3439
  %3443 = fmul fast float %37, %3440
  %3444 = fmul fast float %37, %3441
  %3445 = fmul fast float %3442, %3436
  %3446 = fmul fast float %3443, %3437
  %3447 = fmul fast float %3444, %3438
  %3448 = fcmp fast ult float %38, 5.000000e-01
  br i1 %3448, label %3474, label %3449

; <label>:3449                                    ; preds = %3435
  %3450 = fmul fast float %3445, 0x4004147AE0000000
  %3451 = fmul fast float %3446, 0x4004147AE0000000
  %3452 = fmul fast float %3447, 0x4004147AE0000000
  %3453 = fadd fast float %3450, 0x3F9EB851E0000000
  %3454 = fadd fast float %3451, 0x3F9EB851E0000000
  %3455 = fadd fast float %3452, 0x3F9EB851E0000000
  %3456 = fmul fast float %3453, %3445
  %3457 = fmul fast float %3454, %3446
  %3458 = fmul fast float %3455, %3447
  %3459 = fmul fast float %3445, 0x400370A3E0000000
  %3460 = fmul fast float %3446, 0x400370A3E0000000
  %3461 = fmul fast float %3447, 0x400370A3E0000000
  %3462 = fadd fast float %3459, 0x3FE2E147A0000000
  %3463 = fadd fast float %3460, 0x3FE2E147A0000000
  %3464 = fadd fast float %3461, 0x3FE2E147A0000000
  %3465 = fmul fast float %3462, %3445
  %3466 = fmul fast float %3463, %3446
  %3467 = fmul fast float %3464, %3447
  %3468 = fadd fast float %3465, 0x3FC1EB8520000000
  %3469 = fadd fast float %3466, 0x3FC1EB8520000000
  %3470 = fadd fast float %3467, 0x3FC1EB8520000000
  %3471 = fdiv fast float %3456, %3468
  %3472 = fdiv fast float %3457, %3469
  %3473 = fdiv fast float %3458, %3470
  br label %3474

; <label>:3474                                    ; preds = %3449, %3435
  %3475 = phi float [ %3471, %3449 ], [ %3445, %3435 ]
  %3476 = phi float [ %3472, %3449 ], [ %3446, %3435 ]
  %3477 = phi float [ %3473, %3449 ], [ %3447, %3435 ]
  %3478 = call float @dx.op.unary.f32(i32 7, float %3475)  ; Saturate(value)
  %3479 = call float @dx.op.unary.f32(i32 7, float %3476)  ; Saturate(value)
  %3480 = call float @dx.op.unary.f32(i32 7, float %3477)  ; Saturate(value)
  %3481 = call float @dx.op.dot3.f32(i32 55, float %3478, float %3479, float %3480, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3482 = fsub fast float %3478, %3481
  %3483 = fsub fast float %3479, %3481
  %3484 = fsub fast float %3480, %3481
  %3485 = fmul fast float %3482, %9
  %3486 = fmul fast float %3483, %9
  %3487 = fmul fast float %3484, %9
  %3488 = fadd fast float %3485, %3481
  %3489 = fadd fast float %3486, %3481
  %3490 = fadd fast float %3487, %3481
  %3491 = call float @dx.op.unary.f32(i32 7, float %3488)  ; Saturate(value)
  %3492 = call float @dx.op.unary.f32(i32 7, float %3489)  ; Saturate(value)
  %3493 = call float @dx.op.unary.f32(i32 7, float %3490)  ; Saturate(value)
  %3494 = fadd fast float %3491, 0xBFC70A3D80000000
  %3495 = fadd fast float %3492, 0xBFC70A3D80000000
  %3496 = fadd fast float %3493, 0xBFC70A3D80000000
  %3497 = fmul fast float %3494, %8
  %3498 = fmul fast float %3495, %8
  %3499 = fmul fast float %3496, %8
  %3500 = fadd fast float %3497, 0x3FC70A3D80000000
  %3501 = fadd fast float %3498, 0x3FC70A3D80000000
  %3502 = fadd fast float %3499, 0x3FC70A3D80000000
  %3503 = call float @dx.op.unary.f32(i32 7, float %3500)  ; Saturate(value)
  %3504 = call float @dx.op.unary.f32(i32 7, float %3501)  ; Saturate(value)
  %3505 = call float @dx.op.unary.f32(i32 7, float %3502)  ; Saturate(value)
  %3506 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %3506, label %3507, label %4766

; <label>:3507                                    ; preds = %3474
  %3508 = add i32 %71, -1
  %3509 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %3510 = call i32 @dx.op.binary.i32(i32 37, i32 %3508, i32 0)  ; IMax(a,b)
  %3511 = call i32 @dx.op.binary.i32(i32 38, i32 %3509, i32 %60)  ; IMin(a,b)
  %3512 = call i32 @dx.op.binary.i32(i32 38, i32 %3510, i32 %61)  ; IMin(a,b)
  %3513 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3511, i32 %3512, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3514 = extractvalue %dx.types.ResRet.f32 %3513, 0
  %3515 = fsub fast float 1.000000e+00, %87
  %3516 = fmul fast float %3515, 0x3FA99999A0000000
  %3517 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %3516)  ; FMax(a,b)
  %3518 = fsub fast float %3514, %87
  %3519 = call float @dx.op.unary.f32(i32 6, float %3518)  ; FAbs(value)
  %3520 = fdiv fast float %3519, %3517
  %3521 = fsub fast float 1.000000e+00, %3520
  %3522 = call float @dx.op.unary.f32(i32 7, float %3521)  ; Saturate(value)
  %3523 = fcmp fast ugt float %3522, 0.000000e+00
  br i1 %3523, label %3524, label %3797

; <label>:3524                                    ; preds = %3507
  %3525 = call i32 @dx.op.binary.i32(i32 37, i32 %3511, i32 0)  ; IMax(a,b)
  %3526 = call i32 @dx.op.binary.i32(i32 37, i32 %3512, i32 0)  ; IMax(a,b)
  %3527 = call i32 @dx.op.binary.i32(i32 38, i32 %3525, i32 %60)  ; IMin(a,b)
  %3528 = call i32 @dx.op.binary.i32(i32 38, i32 %3526, i32 %61)  ; IMin(a,b)
  %3529 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3527, i32 %3528, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3530 = extractvalue %dx.types.ResRet.f32 %3529, 0
  %3531 = extractvalue %dx.types.ResRet.f32 %3529, 1
  %3532 = extractvalue %dx.types.ResRet.f32 %3529, 2
  %3533 = extractvalue %dx.types.ResRet.f32 %3529, 3
  %3534 = fcmp fast olt float %3533, 0.000000e+00
  br i1 %3534, label %3535, label %3569

; <label>:3535                                    ; preds = %3524
  %3536 = fcmp fast ogt float %3530, 0x3FA4B5DCC0000000
  %3537 = fcmp fast ogt float %3531, 0x3FA4B5DCC0000000
  %3538 = fcmp fast ogt float %3532, 0x3FA4B5DCC0000000
  %3539 = select i1 %3536, float 0.000000e+00, float 1.000000e+00
  %3540 = select i1 %3537, float 0.000000e+00, float 1.000000e+00
  %3541 = select i1 %3538, float 0.000000e+00, float 1.000000e+00
  %3542 = fmul fast float %3530, 0x3FB3D07220000000
  %3543 = fmul fast float %3531, 0x3FB3D07220000000
  %3544 = fmul fast float %3532, 0x3FB3D07220000000
  %3545 = fadd fast float %3530, 0x3FAC28F5C0000000
  %3546 = fadd fast float %3531, 0x3FAC28F5C0000000
  %3547 = fadd fast float %3532, 0x3FAC28F5C0000000
  %3548 = fmul fast float %3545, 0x3FEE54EDE0000000
  %3549 = fmul fast float %3546, 0x3FEE54EDE0000000
  %3550 = fmul fast float %3547, 0x3FEE54EDE0000000
  %3551 = call float @dx.op.unary.f32(i32 23, float %3548)  ; Log(value)
  %3552 = call float @dx.op.unary.f32(i32 23, float %3549)  ; Log(value)
  %3553 = call float @dx.op.unary.f32(i32 23, float %3550)  ; Log(value)
  %3554 = fmul fast float %3551, 0x4003333340000000
  %3555 = fmul fast float %3552, 0x4003333340000000
  %3556 = fmul fast float %3553, 0x4003333340000000
  %3557 = call float @dx.op.unary.f32(i32 21, float %3554)  ; Exp(value)
  %3558 = call float @dx.op.unary.f32(i32 21, float %3555)  ; Exp(value)
  %3559 = call float @dx.op.unary.f32(i32 21, float %3556)  ; Exp(value)
  %3560 = fsub fast float %3542, %3557
  %3561 = fsub fast float %3543, %3558
  %3562 = fsub fast float %3544, %3559
  %3563 = fmul fast float %3560, %3539
  %3564 = fmul fast float %3561, %3540
  %3565 = fmul fast float %3562, %3541
  %3566 = fadd fast float %3563, %3557
  %3567 = fadd fast float %3564, %3558
  %3568 = fadd fast float %3565, %3559
  br label %3784

; <label>:3569                                    ; preds = %3524
  %3570 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3527, i32 %3528, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3571 = extractvalue %dx.types.ResRet.f32 %3570, 0
  %3572 = fcmp fast ogt float %39, 5.000000e-01
  %3573 = fcmp fast olt float %3571, 1.000000e+00
  %3574 = and i1 %3572, %3573
  br i1 %3574, label %3575, label %3713

; <label>:3575                                    ; preds = %3569
  %3576 = sitofp i32 %3527 to float
  %3577 = sitofp i32 %3528 to float
  %3578 = fadd fast float %3576, 5.000000e-01
  %3579 = fadd fast float %3577, 5.000000e-01
  %3580 = fdiv fast float %3578, %46
  %3581 = fdiv fast float %3579, %47
  %3582 = fmul fast float %3580, 2.000000e+00
  %3583 = fmul fast float %3581, 2.000000e+00
  %3584 = fadd fast float %3582, -1.000000e+00
  %3585 = fsub fast float 1.000000e+00, %3583
  %3586 = fmul fast float %3584, %36
  %3587 = call float @dx.op.tertiary.f32(i32 46, float %3585, float %32, float %3586)  ; FMad(a,b,c)
  %3588 = call float @dx.op.tertiary.f32(i32 46, float %3571, float %28, float %3587)  ; FMad(a,b,c)
  %3589 = fadd fast float %3588, %24
  %3590 = call float @dx.op.unary.f32(i32 6, float %3589)  ; FAbs(value)
  %3591 = fcmp fast ogt float %3590, 0x3EB0C6F7A0000000
  br i1 %3591, label %3592, label %3713

; <label>:3592                                    ; preds = %3575
  %3593 = fmul fast float %3584, %35
  %3594 = call float @dx.op.tertiary.f32(i32 46, float %3585, float %31, float %3593)  ; FMad(a,b,c)
  %3595 = call float @dx.op.tertiary.f32(i32 46, float %3571, float %27, float %3594)  ; FMad(a,b,c)
  %3596 = fadd fast float %3595, %23
  %3597 = fmul fast float %3584, %34
  %3598 = call float @dx.op.tertiary.f32(i32 46, float %3585, float %30, float %3597)  ; FMad(a,b,c)
  %3599 = call float @dx.op.tertiary.f32(i32 46, float %3571, float %26, float %3598)  ; FMad(a,b,c)
  %3600 = fadd fast float %3599, %22
  %3601 = fmul fast float %3584, %33
  %3602 = call float @dx.op.tertiary.f32(i32 46, float %3585, float %29, float %3601)  ; FMad(a,b,c)
  %3603 = call float @dx.op.tertiary.f32(i32 46, float %3571, float %25, float %3602)  ; FMad(a,b,c)
  %3604 = fadd fast float %3603, %21
  %3605 = fdiv fast float %3604, %3589
  %3606 = fdiv fast float %3600, %3589
  %3607 = fdiv fast float %3596, %3589
  %3608 = fsub fast float %3605, %18
  %3609 = fsub fast float %3606, %19
  %3610 = fsub fast float %3607, %20
  %3611 = fmul fast float %3608, %3608
  %3612 = fmul fast float %3609, %3609
  %3613 = fadd fast float %3612, %3611
  %3614 = fmul fast float %3610, %3610
  %3615 = fadd fast float %3613, %3614
  %3616 = call float @dx.op.unary.f32(i32 24, float %3615)  ; Sqrt(value)
  %3617 = fsub fast float %3616, %10
  %3618 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3617)  ; FMax(a,b)
  %3619 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %3619, label %3620, label %3643

; <label>:3620                                    ; preds = %3592
  %3621 = call float @dx.op.unary.f32(i32 6, float %3609)  ; FAbs(value)
  %3622 = fmul fast float %3621, %12
  %3623 = fcmp fast olt float %3622, 0x3F50624DE0000000
  br i1 %3623, label %3624, label %3627

; <label>:3624                                    ; preds = %3620
  %3625 = fmul fast float %3622, 5.000000e-01
  %3626 = fsub fast float 1.000000e+00, %3625
  br label %3632

; <label>:3627                                    ; preds = %3620
  %3628 = fmul fast float %3622, 0xBFF7154760000000
  %3629 = call float @dx.op.unary.f32(i32 21, float %3628)  ; Exp(value)
  %3630 = fsub fast float 1.000000e+00, %3629
  %3631 = fdiv fast float %3630, %3622
  br label %3632

; <label>:3632                                    ; preds = %3627, %3624
  %3633 = phi float [ %3626, %3624 ], [ %3631, %3627 ]
  %3634 = call float @dx.op.binary.f32(i32 36, float %3606, float %19)  ; FMin(a,b)
  %3635 = fsub fast float %3634, %11
  %3636 = fmul fast float %12, %3635
  %3637 = fsub fast float -0.000000e+00, %3636
  %3638 = call float @dx.op.binary.f32(i32 35, float %3637, float -4.000000e+01)  ; FMax(a,b)
  %3639 = call float @dx.op.binary.f32(i32 36, float %3638, float 5.000000e+00)  ; FMin(a,b)
  %3640 = fmul fast float %3639, 0x3FF7154760000000
  %3641 = call float @dx.op.unary.f32(i32 21, float %3640)  ; Exp(value)
  %3642 = fmul fast float %3641, %3633
  br label %3643

; <label>:3643                                    ; preds = %3632, %3592
  %3644 = phi float [ %3642, %3632 ], [ 1.000000e+00, %3592 ]
  %3645 = fmul fast float %3618, %17
  %3646 = fmul fast float %3645, %3644
  %3647 = fcmp fast ole float %3616, %10
  %3648 = fcmp fast olt float %3616, 0x3F1A36E2E0000000
  %3649 = or i1 %3647, %3648
  br i1 %3649, label %3696, label %3650

; <label>:3650                                    ; preds = %3643
  %3651 = fdiv fast float %10, %3616
  %3652 = fmul fast float %3651, %3608
  %3653 = fmul fast float %3651, %3609
  %3654 = fmul fast float %3651, %3610
  %3655 = fadd fast float %3652, %18
  %3656 = fadd fast float %3653, %19
  %3657 = fadd fast float %3654, %20
  %3658 = fadd fast float %3655, -9.000000e+02
  %3659 = fadd fast float %3656, -1.500000e+01
  %3660 = fadd fast float %3657, -7.500000e+02
  %3661 = fmul fast float %3658, 0x3F62345680000000
  %3662 = fmul fast float %3659, 0x3F62345680000000
  %3663 = fmul fast float %3660, 0x3F62345680000000
  %3664 = call float @dx.op.dot3.f32(i32 55, float %3661, float %3662, float %3663, float %3661, float %3662, float %3663)  ; Dot3(ax,ay,az,bx,by,bz)
  %3665 = fsub fast float 1.000000e+00, %3664
  %3666 = call float @dx.op.unary.f32(i32 7, float %3665)  ; Saturate(value)
  %3667 = fmul fast float %3666, %3666
  %3668 = fadd fast float %3655, %3605
  %3669 = fadd fast float %3656, %3606
  %3670 = fadd fast float %3657, %3607
  %3671 = fmul fast float %3668, 0x3F52345680000000
  %3672 = fadd fast float %3671, -2.000000e+00
  %3673 = fmul fast float %3669, 0x3F52345680000000
  %3674 = fadd fast float %3673, 0xBFA1111120000000
  %3675 = fmul fast float %3670, 0x3F52345680000000
  %3676 = fadd fast float %3675, 0xBFFAAAAAC0000000
  %3677 = call float @dx.op.dot3.f32(i32 55, float %3672, float %3674, float %3676, float %3672, float %3674, float %3676)  ; Dot3(ax,ay,az,bx,by,bz)
  %3678 = fsub fast float 1.000000e+00, %3677
  %3679 = call float @dx.op.unary.f32(i32 7, float %3678)  ; Saturate(value)
  %3680 = fmul fast float %3679, %3679
  %3681 = fmul fast float %3680, 4.000000e+00
  %3682 = fadd fast float %3681, %3667
  %3683 = fadd fast float %3605, -9.000000e+02
  %3684 = fadd fast float %3606, -1.500000e+01
  %3685 = fadd fast float %3607, -7.500000e+02
  %3686 = fmul fast float %3683, 0x3F62345680000000
  %3687 = fmul fast float %3684, 0x3F62345680000000
  %3688 = fmul fast float %3685, 0x3F62345680000000
  %3689 = call float @dx.op.dot3.f32(i32 55, float %3686, float %3687, float %3688, float %3686, float %3687, float %3688)  ; Dot3(ax,ay,az,bx,by,bz)
  %3690 = fsub fast float 1.000000e+00, %3689
  %3691 = call float @dx.op.unary.f32(i32 7, float %3690)  ; Saturate(value)
  %3692 = fmul fast float %3691, %3691
  %3693 = fadd fast float %3682, %3692
  %3694 = fmul fast float %3617, 0x3F25D867E0000000
  %3695 = fmul fast float %3694, %3693
  br label %3696

; <label>:3696                                    ; preds = %3650, %3643
  %3697 = phi float [ %3695, %3650 ], [ 0.000000e+00, %3643 ]
  %3698 = fadd fast float %3697, %3646
  %3699 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3698)  ; FMin(a,b)
  %3700 = fmul fast float %3699, 0xBFF7154760000000
  %3701 = call float @dx.op.unary.f32(i32 21, float %3700)  ; Exp(value)
  %3702 = fsub fast float 1.000000e+00, %3701
  %3703 = call float @dx.op.binary.f32(i32 36, float %13, float %3702)  ; FMin(a,b)
  %3704 = fsub fast float %14, %3530
  %3705 = fsub fast float %15, %3531
  %3706 = fsub fast float %16, %3532
  %3707 = fmul fast float %3703, %3704
  %3708 = fmul fast float %3703, %3705
  %3709 = fmul fast float %3703, %3706
  %3710 = fadd fast float %3707, %3530
  %3711 = fadd fast float %3708, %3531
  %3712 = fadd fast float %3709, %3532
  br label %3713

; <label>:3713                                    ; preds = %3696, %3575, %3569
  %3714 = phi float [ %3710, %3696 ], [ %3530, %3575 ], [ %3530, %3569 ]
  %3715 = phi float [ %3711, %3696 ], [ %3531, %3575 ], [ %3531, %3569 ]
  %3716 = phi float [ %3712, %3696 ], [ %3532, %3575 ], [ %3532, %3569 ]
  %3717 = fadd fast float %6, 1.000000e+00
  %3718 = fadd fast float %7, 1.000000e+00
  %3719 = fsub fast float 1.000000e+00, %6
  %3720 = fmul fast float %37, %3717
  %3721 = fmul fast float %37, %3718
  %3722 = fmul fast float %37, %3719
  %3723 = fmul fast float %3720, %3714
  %3724 = fmul fast float %3721, %3715
  %3725 = fmul fast float %3722, %3716
  %3726 = fcmp fast ult float %38, 5.000000e-01
  br i1 %3726, label %3752, label %3727

; <label>:3727                                    ; preds = %3713
  %3728 = fmul fast float %3723, 0x4004147AE0000000
  %3729 = fmul fast float %3724, 0x4004147AE0000000
  %3730 = fmul fast float %3725, 0x4004147AE0000000
  %3731 = fadd fast float %3728, 0x3F9EB851E0000000
  %3732 = fadd fast float %3729, 0x3F9EB851E0000000
  %3733 = fadd fast float %3730, 0x3F9EB851E0000000
  %3734 = fmul fast float %3731, %3723
  %3735 = fmul fast float %3732, %3724
  %3736 = fmul fast float %3733, %3725
  %3737 = fmul fast float %3723, 0x400370A3E0000000
  %3738 = fmul fast float %3724, 0x400370A3E0000000
  %3739 = fmul fast float %3725, 0x400370A3E0000000
  %3740 = fadd fast float %3737, 0x3FE2E147A0000000
  %3741 = fadd fast float %3738, 0x3FE2E147A0000000
  %3742 = fadd fast float %3739, 0x3FE2E147A0000000
  %3743 = fmul fast float %3740, %3723
  %3744 = fmul fast float %3741, %3724
  %3745 = fmul fast float %3742, %3725
  %3746 = fadd fast float %3743, 0x3FC1EB8520000000
  %3747 = fadd fast float %3744, 0x3FC1EB8520000000
  %3748 = fadd fast float %3745, 0x3FC1EB8520000000
  %3749 = fdiv fast float %3734, %3746
  %3750 = fdiv fast float %3735, %3747
  %3751 = fdiv fast float %3736, %3748
  br label %3752

; <label>:3752                                    ; preds = %3727, %3713
  %3753 = phi float [ %3749, %3727 ], [ %3723, %3713 ]
  %3754 = phi float [ %3750, %3727 ], [ %3724, %3713 ]
  %3755 = phi float [ %3751, %3727 ], [ %3725, %3713 ]
  %3756 = call float @dx.op.unary.f32(i32 7, float %3753)  ; Saturate(value)
  %3757 = call float @dx.op.unary.f32(i32 7, float %3754)  ; Saturate(value)
  %3758 = call float @dx.op.unary.f32(i32 7, float %3755)  ; Saturate(value)
  %3759 = call float @dx.op.dot3.f32(i32 55, float %3756, float %3757, float %3758, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3760 = fsub fast float %3756, %3759
  %3761 = fsub fast float %3757, %3759
  %3762 = fsub fast float %3758, %3759
  %3763 = fmul fast float %3760, %9
  %3764 = fmul fast float %3761, %9
  %3765 = fmul fast float %3762, %9
  %3766 = fadd fast float %3763, %3759
  %3767 = fadd fast float %3764, %3759
  %3768 = fadd fast float %3765, %3759
  %3769 = call float @dx.op.unary.f32(i32 7, float %3766)  ; Saturate(value)
  %3770 = call float @dx.op.unary.f32(i32 7, float %3767)  ; Saturate(value)
  %3771 = call float @dx.op.unary.f32(i32 7, float %3768)  ; Saturate(value)
  %3772 = fadd fast float %3769, 0xBFC70A3D80000000
  %3773 = fadd fast float %3770, 0xBFC70A3D80000000
  %3774 = fadd fast float %3771, 0xBFC70A3D80000000
  %3775 = fmul fast float %3772, %8
  %3776 = fmul fast float %3773, %8
  %3777 = fmul fast float %3774, %8
  %3778 = fadd fast float %3775, 0x3FC70A3D80000000
  %3779 = fadd fast float %3776, 0x3FC70A3D80000000
  %3780 = fadd fast float %3777, 0x3FC70A3D80000000
  %3781 = call float @dx.op.unary.f32(i32 7, float %3778)  ; Saturate(value)
  %3782 = call float @dx.op.unary.f32(i32 7, float %3779)  ; Saturate(value)
  %3783 = call float @dx.op.unary.f32(i32 7, float %3780)  ; Saturate(value)
  br label %3784

; <label>:3784                                    ; preds = %3752, %3535
  %3785 = phi float [ %3566, %3535 ], [ %3781, %3752 ]
  %3786 = phi float [ %3567, %3535 ], [ %3782, %3752 ]
  %3787 = phi float [ %3568, %3535 ], [ %3783, %3752 ]
  %3788 = fsub fast float %3785, %3503
  %3789 = fsub fast float %3786, %3504
  %3790 = fsub fast float %3787, %3505
  %3791 = fmul fast float %3788, %3522
  %3792 = fmul fast float %3789, %3522
  %3793 = fmul fast float %3790, %3522
  %3794 = fadd fast float %3791, %3503
  %3795 = fadd fast float %3792, %3504
  %3796 = fadd fast float %3793, %3505
  br label %3797

; <label>:3797                                    ; preds = %3784, %3507
  %3798 = phi float [ %3794, %3784 ], [ %3503, %3507 ]
  %3799 = phi float [ %3795, %3784 ], [ %3504, %3507 ]
  %3800 = phi float [ %3796, %3784 ], [ %3505, %3507 ]
  %3801 = add i32 %71, 1
  %3802 = call i32 @dx.op.binary.i32(i32 37, i32 %3801, i32 0)  ; IMax(a,b)
  %3803 = call i32 @dx.op.binary.i32(i32 38, i32 %3802, i32 %61)  ; IMin(a,b)
  %3804 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3511, i32 %3803, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3805 = extractvalue %dx.types.ResRet.f32 %3804, 0
  %3806 = fsub fast float %3805, %87
  %3807 = call float @dx.op.unary.f32(i32 6, float %3806)  ; FAbs(value)
  %3808 = fdiv fast float %3807, %3517
  %3809 = fsub fast float 1.000000e+00, %3808
  %3810 = call float @dx.op.unary.f32(i32 7, float %3809)  ; Saturate(value)
  %3811 = fcmp fast ugt float %3810, 0.000000e+00
  br i1 %3811, label %3812, label %4085

; <label>:3812                                    ; preds = %3797
  %3813 = call i32 @dx.op.binary.i32(i32 37, i32 %3511, i32 0)  ; IMax(a,b)
  %3814 = call i32 @dx.op.binary.i32(i32 37, i32 %3803, i32 0)  ; IMax(a,b)
  %3815 = call i32 @dx.op.binary.i32(i32 38, i32 %3813, i32 %60)  ; IMin(a,b)
  %3816 = call i32 @dx.op.binary.i32(i32 38, i32 %3814, i32 %61)  ; IMin(a,b)
  %3817 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3815, i32 %3816, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3818 = extractvalue %dx.types.ResRet.f32 %3817, 0
  %3819 = extractvalue %dx.types.ResRet.f32 %3817, 1
  %3820 = extractvalue %dx.types.ResRet.f32 %3817, 2
  %3821 = extractvalue %dx.types.ResRet.f32 %3817, 3
  %3822 = fcmp fast olt float %3821, 0.000000e+00
  br i1 %3822, label %3823, label %3857

; <label>:3823                                    ; preds = %3812
  %3824 = fcmp fast ogt float %3818, 0x3FA4B5DCC0000000
  %3825 = fcmp fast ogt float %3819, 0x3FA4B5DCC0000000
  %3826 = fcmp fast ogt float %3820, 0x3FA4B5DCC0000000
  %3827 = select i1 %3824, float 0.000000e+00, float 1.000000e+00
  %3828 = select i1 %3825, float 0.000000e+00, float 1.000000e+00
  %3829 = select i1 %3826, float 0.000000e+00, float 1.000000e+00
  %3830 = fmul fast float %3818, 0x3FB3D07220000000
  %3831 = fmul fast float %3819, 0x3FB3D07220000000
  %3832 = fmul fast float %3820, 0x3FB3D07220000000
  %3833 = fadd fast float %3818, 0x3FAC28F5C0000000
  %3834 = fadd fast float %3819, 0x3FAC28F5C0000000
  %3835 = fadd fast float %3820, 0x3FAC28F5C0000000
  %3836 = fmul fast float %3833, 0x3FEE54EDE0000000
  %3837 = fmul fast float %3834, 0x3FEE54EDE0000000
  %3838 = fmul fast float %3835, 0x3FEE54EDE0000000
  %3839 = call float @dx.op.unary.f32(i32 23, float %3836)  ; Log(value)
  %3840 = call float @dx.op.unary.f32(i32 23, float %3837)  ; Log(value)
  %3841 = call float @dx.op.unary.f32(i32 23, float %3838)  ; Log(value)
  %3842 = fmul fast float %3839, 0x4003333340000000
  %3843 = fmul fast float %3840, 0x4003333340000000
  %3844 = fmul fast float %3841, 0x4003333340000000
  %3845 = call float @dx.op.unary.f32(i32 21, float %3842)  ; Exp(value)
  %3846 = call float @dx.op.unary.f32(i32 21, float %3843)  ; Exp(value)
  %3847 = call float @dx.op.unary.f32(i32 21, float %3844)  ; Exp(value)
  %3848 = fsub fast float %3830, %3845
  %3849 = fsub fast float %3831, %3846
  %3850 = fsub fast float %3832, %3847
  %3851 = fmul fast float %3848, %3827
  %3852 = fmul fast float %3849, %3828
  %3853 = fmul fast float %3850, %3829
  %3854 = fadd fast float %3851, %3845
  %3855 = fadd fast float %3852, %3846
  %3856 = fadd fast float %3853, %3847
  br label %4072

; <label>:3857                                    ; preds = %3812
  %3858 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3815, i32 %3816, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3859 = extractvalue %dx.types.ResRet.f32 %3858, 0
  %3860 = fcmp fast ogt float %39, 5.000000e-01
  %3861 = fcmp fast olt float %3859, 1.000000e+00
  %3862 = and i1 %3860, %3861
  br i1 %3862, label %3863, label %4001

; <label>:3863                                    ; preds = %3857
  %3864 = sitofp i32 %3815 to float
  %3865 = sitofp i32 %3816 to float
  %3866 = fadd fast float %3864, 5.000000e-01
  %3867 = fadd fast float %3865, 5.000000e-01
  %3868 = fdiv fast float %3866, %46
  %3869 = fdiv fast float %3867, %47
  %3870 = fmul fast float %3868, 2.000000e+00
  %3871 = fmul fast float %3869, 2.000000e+00
  %3872 = fadd fast float %3870, -1.000000e+00
  %3873 = fsub fast float 1.000000e+00, %3871
  %3874 = fmul fast float %3872, %36
  %3875 = call float @dx.op.tertiary.f32(i32 46, float %3873, float %32, float %3874)  ; FMad(a,b,c)
  %3876 = call float @dx.op.tertiary.f32(i32 46, float %3859, float %28, float %3875)  ; FMad(a,b,c)
  %3877 = fadd fast float %3876, %24
  %3878 = call float @dx.op.unary.f32(i32 6, float %3877)  ; FAbs(value)
  %3879 = fcmp fast ogt float %3878, 0x3EB0C6F7A0000000
  br i1 %3879, label %3880, label %4001

; <label>:3880                                    ; preds = %3863
  %3881 = fmul fast float %3872, %35
  %3882 = call float @dx.op.tertiary.f32(i32 46, float %3873, float %31, float %3881)  ; FMad(a,b,c)
  %3883 = call float @dx.op.tertiary.f32(i32 46, float %3859, float %27, float %3882)  ; FMad(a,b,c)
  %3884 = fadd fast float %3883, %23
  %3885 = fmul fast float %3872, %34
  %3886 = call float @dx.op.tertiary.f32(i32 46, float %3873, float %30, float %3885)  ; FMad(a,b,c)
  %3887 = call float @dx.op.tertiary.f32(i32 46, float %3859, float %26, float %3886)  ; FMad(a,b,c)
  %3888 = fadd fast float %3887, %22
  %3889 = fmul fast float %3872, %33
  %3890 = call float @dx.op.tertiary.f32(i32 46, float %3873, float %29, float %3889)  ; FMad(a,b,c)
  %3891 = call float @dx.op.tertiary.f32(i32 46, float %3859, float %25, float %3890)  ; FMad(a,b,c)
  %3892 = fadd fast float %3891, %21
  %3893 = fdiv fast float %3892, %3877
  %3894 = fdiv fast float %3888, %3877
  %3895 = fdiv fast float %3884, %3877
  %3896 = fsub fast float %3893, %18
  %3897 = fsub fast float %3894, %19
  %3898 = fsub fast float %3895, %20
  %3899 = fmul fast float %3896, %3896
  %3900 = fmul fast float %3897, %3897
  %3901 = fadd fast float %3900, %3899
  %3902 = fmul fast float %3898, %3898
  %3903 = fadd fast float %3901, %3902
  %3904 = call float @dx.op.unary.f32(i32 24, float %3903)  ; Sqrt(value)
  %3905 = fsub fast float %3904, %10
  %3906 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3905)  ; FMax(a,b)
  %3907 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %3907, label %3908, label %3931

; <label>:3908                                    ; preds = %3880
  %3909 = call float @dx.op.unary.f32(i32 6, float %3897)  ; FAbs(value)
  %3910 = fmul fast float %3909, %12
  %3911 = fcmp fast olt float %3910, 0x3F50624DE0000000
  br i1 %3911, label %3912, label %3915

; <label>:3912                                    ; preds = %3908
  %3913 = fmul fast float %3910, 5.000000e-01
  %3914 = fsub fast float 1.000000e+00, %3913
  br label %3920

; <label>:3915                                    ; preds = %3908
  %3916 = fmul fast float %3910, 0xBFF7154760000000
  %3917 = call float @dx.op.unary.f32(i32 21, float %3916)  ; Exp(value)
  %3918 = fsub fast float 1.000000e+00, %3917
  %3919 = fdiv fast float %3918, %3910
  br label %3920

; <label>:3920                                    ; preds = %3915, %3912
  %3921 = phi float [ %3914, %3912 ], [ %3919, %3915 ]
  %3922 = call float @dx.op.binary.f32(i32 36, float %3894, float %19)  ; FMin(a,b)
  %3923 = fsub fast float %3922, %11
  %3924 = fmul fast float %12, %3923
  %3925 = fsub fast float -0.000000e+00, %3924
  %3926 = call float @dx.op.binary.f32(i32 35, float %3925, float -4.000000e+01)  ; FMax(a,b)
  %3927 = call float @dx.op.binary.f32(i32 36, float %3926, float 5.000000e+00)  ; FMin(a,b)
  %3928 = fmul fast float %3927, 0x3FF7154760000000
  %3929 = call float @dx.op.unary.f32(i32 21, float %3928)  ; Exp(value)
  %3930 = fmul fast float %3929, %3921
  br label %3931

; <label>:3931                                    ; preds = %3920, %3880
  %3932 = phi float [ %3930, %3920 ], [ 1.000000e+00, %3880 ]
  %3933 = fmul fast float %3906, %17
  %3934 = fmul fast float %3933, %3932
  %3935 = fcmp fast ole float %3904, %10
  %3936 = fcmp fast olt float %3904, 0x3F1A36E2E0000000
  %3937 = or i1 %3935, %3936
  br i1 %3937, label %3984, label %3938

; <label>:3938                                    ; preds = %3931
  %3939 = fdiv fast float %10, %3904
  %3940 = fmul fast float %3939, %3896
  %3941 = fmul fast float %3939, %3897
  %3942 = fmul fast float %3939, %3898
  %3943 = fadd fast float %3940, %18
  %3944 = fadd fast float %3941, %19
  %3945 = fadd fast float %3942, %20
  %3946 = fadd fast float %3943, -9.000000e+02
  %3947 = fadd fast float %3944, -1.500000e+01
  %3948 = fadd fast float %3945, -7.500000e+02
  %3949 = fmul fast float %3946, 0x3F62345680000000
  %3950 = fmul fast float %3947, 0x3F62345680000000
  %3951 = fmul fast float %3948, 0x3F62345680000000
  %3952 = call float @dx.op.dot3.f32(i32 55, float %3949, float %3950, float %3951, float %3949, float %3950, float %3951)  ; Dot3(ax,ay,az,bx,by,bz)
  %3953 = fsub fast float 1.000000e+00, %3952
  %3954 = call float @dx.op.unary.f32(i32 7, float %3953)  ; Saturate(value)
  %3955 = fmul fast float %3954, %3954
  %3956 = fadd fast float %3943, %3893
  %3957 = fadd fast float %3944, %3894
  %3958 = fadd fast float %3945, %3895
  %3959 = fmul fast float %3956, 0x3F52345680000000
  %3960 = fadd fast float %3959, -2.000000e+00
  %3961 = fmul fast float %3957, 0x3F52345680000000
  %3962 = fadd fast float %3961, 0xBFA1111120000000
  %3963 = fmul fast float %3958, 0x3F52345680000000
  %3964 = fadd fast float %3963, 0xBFFAAAAAC0000000
  %3965 = call float @dx.op.dot3.f32(i32 55, float %3960, float %3962, float %3964, float %3960, float %3962, float %3964)  ; Dot3(ax,ay,az,bx,by,bz)
  %3966 = fsub fast float 1.000000e+00, %3965
  %3967 = call float @dx.op.unary.f32(i32 7, float %3966)  ; Saturate(value)
  %3968 = fmul fast float %3967, %3967
  %3969 = fmul fast float %3968, 4.000000e+00
  %3970 = fadd fast float %3969, %3955
  %3971 = fadd fast float %3893, -9.000000e+02
  %3972 = fadd fast float %3894, -1.500000e+01
  %3973 = fadd fast float %3895, -7.500000e+02
  %3974 = fmul fast float %3971, 0x3F62345680000000
  %3975 = fmul fast float %3972, 0x3F62345680000000
  %3976 = fmul fast float %3973, 0x3F62345680000000
  %3977 = call float @dx.op.dot3.f32(i32 55, float %3974, float %3975, float %3976, float %3974, float %3975, float %3976)  ; Dot3(ax,ay,az,bx,by,bz)
  %3978 = fsub fast float 1.000000e+00, %3977
  %3979 = call float @dx.op.unary.f32(i32 7, float %3978)  ; Saturate(value)
  %3980 = fmul fast float %3979, %3979
  %3981 = fadd fast float %3970, %3980
  %3982 = fmul fast float %3905, 0x3F25D867E0000000
  %3983 = fmul fast float %3982, %3981
  br label %3984

; <label>:3984                                    ; preds = %3938, %3931
  %3985 = phi float [ %3983, %3938 ], [ 0.000000e+00, %3931 ]
  %3986 = fadd fast float %3985, %3934
  %3987 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3986)  ; FMin(a,b)
  %3988 = fmul fast float %3987, 0xBFF7154760000000
  %3989 = call float @dx.op.unary.f32(i32 21, float %3988)  ; Exp(value)
  %3990 = fsub fast float 1.000000e+00, %3989
  %3991 = call float @dx.op.binary.f32(i32 36, float %13, float %3990)  ; FMin(a,b)
  %3992 = fsub fast float %14, %3818
  %3993 = fsub fast float %15, %3819
  %3994 = fsub fast float %16, %3820
  %3995 = fmul fast float %3991, %3992
  %3996 = fmul fast float %3991, %3993
  %3997 = fmul fast float %3991, %3994
  %3998 = fadd fast float %3995, %3818
  %3999 = fadd fast float %3996, %3819
  %4000 = fadd fast float %3997, %3820
  br label %4001

; <label>:4001                                    ; preds = %3984, %3863, %3857
  %4002 = phi float [ %3998, %3984 ], [ %3818, %3863 ], [ %3818, %3857 ]
  %4003 = phi float [ %3999, %3984 ], [ %3819, %3863 ], [ %3819, %3857 ]
  %4004 = phi float [ %4000, %3984 ], [ %3820, %3863 ], [ %3820, %3857 ]
  %4005 = fadd fast float %6, 1.000000e+00
  %4006 = fadd fast float %7, 1.000000e+00
  %4007 = fsub fast float 1.000000e+00, %6
  %4008 = fmul fast float %37, %4005
  %4009 = fmul fast float %37, %4006
  %4010 = fmul fast float %37, %4007
  %4011 = fmul fast float %4008, %4002
  %4012 = fmul fast float %4009, %4003
  %4013 = fmul fast float %4010, %4004
  %4014 = fcmp fast ult float %38, 5.000000e-01
  br i1 %4014, label %4040, label %4015

; <label>:4015                                    ; preds = %4001
  %4016 = fmul fast float %4011, 0x4004147AE0000000
  %4017 = fmul fast float %4012, 0x4004147AE0000000
  %4018 = fmul fast float %4013, 0x4004147AE0000000
  %4019 = fadd fast float %4016, 0x3F9EB851E0000000
  %4020 = fadd fast float %4017, 0x3F9EB851E0000000
  %4021 = fadd fast float %4018, 0x3F9EB851E0000000
  %4022 = fmul fast float %4019, %4011
  %4023 = fmul fast float %4020, %4012
  %4024 = fmul fast float %4021, %4013
  %4025 = fmul fast float %4011, 0x400370A3E0000000
  %4026 = fmul fast float %4012, 0x400370A3E0000000
  %4027 = fmul fast float %4013, 0x400370A3E0000000
  %4028 = fadd fast float %4025, 0x3FE2E147A0000000
  %4029 = fadd fast float %4026, 0x3FE2E147A0000000
  %4030 = fadd fast float %4027, 0x3FE2E147A0000000
  %4031 = fmul fast float %4028, %4011
  %4032 = fmul fast float %4029, %4012
  %4033 = fmul fast float %4030, %4013
  %4034 = fadd fast float %4031, 0x3FC1EB8520000000
  %4035 = fadd fast float %4032, 0x3FC1EB8520000000
  %4036 = fadd fast float %4033, 0x3FC1EB8520000000
  %4037 = fdiv fast float %4022, %4034
  %4038 = fdiv fast float %4023, %4035
  %4039 = fdiv fast float %4024, %4036
  br label %4040

; <label>:4040                                    ; preds = %4015, %4001
  %4041 = phi float [ %4037, %4015 ], [ %4011, %4001 ]
  %4042 = phi float [ %4038, %4015 ], [ %4012, %4001 ]
  %4043 = phi float [ %4039, %4015 ], [ %4013, %4001 ]
  %4044 = call float @dx.op.unary.f32(i32 7, float %4041)  ; Saturate(value)
  %4045 = call float @dx.op.unary.f32(i32 7, float %4042)  ; Saturate(value)
  %4046 = call float @dx.op.unary.f32(i32 7, float %4043)  ; Saturate(value)
  %4047 = call float @dx.op.dot3.f32(i32 55, float %4044, float %4045, float %4046, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4048 = fsub fast float %4044, %4047
  %4049 = fsub fast float %4045, %4047
  %4050 = fsub fast float %4046, %4047
  %4051 = fmul fast float %4048, %9
  %4052 = fmul fast float %4049, %9
  %4053 = fmul fast float %4050, %9
  %4054 = fadd fast float %4051, %4047
  %4055 = fadd fast float %4052, %4047
  %4056 = fadd fast float %4053, %4047
  %4057 = call float @dx.op.unary.f32(i32 7, float %4054)  ; Saturate(value)
  %4058 = call float @dx.op.unary.f32(i32 7, float %4055)  ; Saturate(value)
  %4059 = call float @dx.op.unary.f32(i32 7, float %4056)  ; Saturate(value)
  %4060 = fadd fast float %4057, 0xBFC70A3D80000000
  %4061 = fadd fast float %4058, 0xBFC70A3D80000000
  %4062 = fadd fast float %4059, 0xBFC70A3D80000000
  %4063 = fmul fast float %4060, %8
  %4064 = fmul fast float %4061, %8
  %4065 = fmul fast float %4062, %8
  %4066 = fadd fast float %4063, 0x3FC70A3D80000000
  %4067 = fadd fast float %4064, 0x3FC70A3D80000000
  %4068 = fadd fast float %4065, 0x3FC70A3D80000000
  %4069 = call float @dx.op.unary.f32(i32 7, float %4066)  ; Saturate(value)
  %4070 = call float @dx.op.unary.f32(i32 7, float %4067)  ; Saturate(value)
  %4071 = call float @dx.op.unary.f32(i32 7, float %4068)  ; Saturate(value)
  br label %4072

; <label>:4072                                    ; preds = %4040, %3823
  %4073 = phi float [ %3854, %3823 ], [ %4069, %4040 ]
  %4074 = phi float [ %3855, %3823 ], [ %4070, %4040 ]
  %4075 = phi float [ %3856, %3823 ], [ %4071, %4040 ]
  %4076 = fsub fast float %4073, %3503
  %4077 = fsub fast float %4074, %3504
  %4078 = fsub fast float %4075, %3505
  %4079 = fmul fast float %4076, %3810
  %4080 = fmul fast float %4077, %3810
  %4081 = fmul fast float %4078, %3810
  %4082 = fadd fast float %4079, %3503
  %4083 = fadd fast float %4080, %3504
  %4084 = fadd fast float %4081, %3505
  br label %4085

; <label>:4085                                    ; preds = %4072, %3797
  %4086 = phi float [ %4082, %4072 ], [ %3503, %3797 ]
  %4087 = phi float [ %4083, %4072 ], [ %3504, %3797 ]
  %4088 = phi float [ %4084, %4072 ], [ %3505, %3797 ]
  %4089 = add i32 %64, -1
  %4090 = call i32 @dx.op.binary.i32(i32 37, i32 %4089, i32 0)  ; IMax(a,b)
  %4091 = call i32 @dx.op.binary.i32(i32 37, i32 %71, i32 0)  ; IMax(a,b)
  %4092 = call i32 @dx.op.binary.i32(i32 38, i32 %4090, i32 %60)  ; IMin(a,b)
  %4093 = call i32 @dx.op.binary.i32(i32 38, i32 %4091, i32 %61)  ; IMin(a,b)
  %4094 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4092, i32 %4093, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4095 = extractvalue %dx.types.ResRet.f32 %4094, 0
  %4096 = fsub fast float %4095, %87
  %4097 = call float @dx.op.unary.f32(i32 6, float %4096)  ; FAbs(value)
  %4098 = fdiv fast float %4097, %3517
  %4099 = fsub fast float 1.000000e+00, %4098
  %4100 = call float @dx.op.unary.f32(i32 7, float %4099)  ; Saturate(value)
  %4101 = fcmp fast ugt float %4100, 0.000000e+00
  br i1 %4101, label %4102, label %4375

; <label>:4102                                    ; preds = %4085
  %4103 = call i32 @dx.op.binary.i32(i32 37, i32 %4092, i32 0)  ; IMax(a,b)
  %4104 = call i32 @dx.op.binary.i32(i32 37, i32 %4093, i32 0)  ; IMax(a,b)
  %4105 = call i32 @dx.op.binary.i32(i32 38, i32 %4103, i32 %60)  ; IMin(a,b)
  %4106 = call i32 @dx.op.binary.i32(i32 38, i32 %4104, i32 %61)  ; IMin(a,b)
  %4107 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4105, i32 %4106, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4108 = extractvalue %dx.types.ResRet.f32 %4107, 0
  %4109 = extractvalue %dx.types.ResRet.f32 %4107, 1
  %4110 = extractvalue %dx.types.ResRet.f32 %4107, 2
  %4111 = extractvalue %dx.types.ResRet.f32 %4107, 3
  %4112 = fcmp fast olt float %4111, 0.000000e+00
  br i1 %4112, label %4113, label %4147

; <label>:4113                                    ; preds = %4102
  %4114 = fcmp fast ogt float %4108, 0x3FA4B5DCC0000000
  %4115 = fcmp fast ogt float %4109, 0x3FA4B5DCC0000000
  %4116 = fcmp fast ogt float %4110, 0x3FA4B5DCC0000000
  %4117 = select i1 %4114, float 0.000000e+00, float 1.000000e+00
  %4118 = select i1 %4115, float 0.000000e+00, float 1.000000e+00
  %4119 = select i1 %4116, float 0.000000e+00, float 1.000000e+00
  %4120 = fmul fast float %4108, 0x3FB3D07220000000
  %4121 = fmul fast float %4109, 0x3FB3D07220000000
  %4122 = fmul fast float %4110, 0x3FB3D07220000000
  %4123 = fadd fast float %4108, 0x3FAC28F5C0000000
  %4124 = fadd fast float %4109, 0x3FAC28F5C0000000
  %4125 = fadd fast float %4110, 0x3FAC28F5C0000000
  %4126 = fmul fast float %4123, 0x3FEE54EDE0000000
  %4127 = fmul fast float %4124, 0x3FEE54EDE0000000
  %4128 = fmul fast float %4125, 0x3FEE54EDE0000000
  %4129 = call float @dx.op.unary.f32(i32 23, float %4126)  ; Log(value)
  %4130 = call float @dx.op.unary.f32(i32 23, float %4127)  ; Log(value)
  %4131 = call float @dx.op.unary.f32(i32 23, float %4128)  ; Log(value)
  %4132 = fmul fast float %4129, 0x4003333340000000
  %4133 = fmul fast float %4130, 0x4003333340000000
  %4134 = fmul fast float %4131, 0x4003333340000000
  %4135 = call float @dx.op.unary.f32(i32 21, float %4132)  ; Exp(value)
  %4136 = call float @dx.op.unary.f32(i32 21, float %4133)  ; Exp(value)
  %4137 = call float @dx.op.unary.f32(i32 21, float %4134)  ; Exp(value)
  %4138 = fsub fast float %4120, %4135
  %4139 = fsub fast float %4121, %4136
  %4140 = fsub fast float %4122, %4137
  %4141 = fmul fast float %4138, %4117
  %4142 = fmul fast float %4139, %4118
  %4143 = fmul fast float %4140, %4119
  %4144 = fadd fast float %4141, %4135
  %4145 = fadd fast float %4142, %4136
  %4146 = fadd fast float %4143, %4137
  br label %4362

; <label>:4147                                    ; preds = %4102
  %4148 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4105, i32 %4106, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4149 = extractvalue %dx.types.ResRet.f32 %4148, 0
  %4150 = fcmp fast ogt float %39, 5.000000e-01
  %4151 = fcmp fast olt float %4149, 1.000000e+00
  %4152 = and i1 %4150, %4151
  br i1 %4152, label %4153, label %4291

; <label>:4153                                    ; preds = %4147
  %4154 = sitofp i32 %4105 to float
  %4155 = sitofp i32 %4106 to float
  %4156 = fadd fast float %4154, 5.000000e-01
  %4157 = fadd fast float %4155, 5.000000e-01
  %4158 = fdiv fast float %4156, %46
  %4159 = fdiv fast float %4157, %47
  %4160 = fmul fast float %4158, 2.000000e+00
  %4161 = fmul fast float %4159, 2.000000e+00
  %4162 = fadd fast float %4160, -1.000000e+00
  %4163 = fsub fast float 1.000000e+00, %4161
  %4164 = fmul fast float %4162, %36
  %4165 = call float @dx.op.tertiary.f32(i32 46, float %4163, float %32, float %4164)  ; FMad(a,b,c)
  %4166 = call float @dx.op.tertiary.f32(i32 46, float %4149, float %28, float %4165)  ; FMad(a,b,c)
  %4167 = fadd fast float %4166, %24
  %4168 = call float @dx.op.unary.f32(i32 6, float %4167)  ; FAbs(value)
  %4169 = fcmp fast ogt float %4168, 0x3EB0C6F7A0000000
  br i1 %4169, label %4170, label %4291

; <label>:4170                                    ; preds = %4153
  %4171 = fmul fast float %4162, %35
  %4172 = call float @dx.op.tertiary.f32(i32 46, float %4163, float %31, float %4171)  ; FMad(a,b,c)
  %4173 = call float @dx.op.tertiary.f32(i32 46, float %4149, float %27, float %4172)  ; FMad(a,b,c)
  %4174 = fadd fast float %4173, %23
  %4175 = fmul fast float %4162, %34
  %4176 = call float @dx.op.tertiary.f32(i32 46, float %4163, float %30, float %4175)  ; FMad(a,b,c)
  %4177 = call float @dx.op.tertiary.f32(i32 46, float %4149, float %26, float %4176)  ; FMad(a,b,c)
  %4178 = fadd fast float %4177, %22
  %4179 = fmul fast float %4162, %33
  %4180 = call float @dx.op.tertiary.f32(i32 46, float %4163, float %29, float %4179)  ; FMad(a,b,c)
  %4181 = call float @dx.op.tertiary.f32(i32 46, float %4149, float %25, float %4180)  ; FMad(a,b,c)
  %4182 = fadd fast float %4181, %21
  %4183 = fdiv fast float %4182, %4167
  %4184 = fdiv fast float %4178, %4167
  %4185 = fdiv fast float %4174, %4167
  %4186 = fsub fast float %4183, %18
  %4187 = fsub fast float %4184, %19
  %4188 = fsub fast float %4185, %20
  %4189 = fmul fast float %4186, %4186
  %4190 = fmul fast float %4187, %4187
  %4191 = fadd fast float %4190, %4189
  %4192 = fmul fast float %4188, %4188
  %4193 = fadd fast float %4191, %4192
  %4194 = call float @dx.op.unary.f32(i32 24, float %4193)  ; Sqrt(value)
  %4195 = fsub fast float %4194, %10
  %4196 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4195)  ; FMax(a,b)
  %4197 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %4197, label %4198, label %4221

; <label>:4198                                    ; preds = %4170
  %4199 = call float @dx.op.unary.f32(i32 6, float %4187)  ; FAbs(value)
  %4200 = fmul fast float %4199, %12
  %4201 = fcmp fast olt float %4200, 0x3F50624DE0000000
  br i1 %4201, label %4202, label %4205

; <label>:4202                                    ; preds = %4198
  %4203 = fmul fast float %4200, 5.000000e-01
  %4204 = fsub fast float 1.000000e+00, %4203
  br label %4210

; <label>:4205                                    ; preds = %4198
  %4206 = fmul fast float %4200, 0xBFF7154760000000
  %4207 = call float @dx.op.unary.f32(i32 21, float %4206)  ; Exp(value)
  %4208 = fsub fast float 1.000000e+00, %4207
  %4209 = fdiv fast float %4208, %4200
  br label %4210

; <label>:4210                                    ; preds = %4205, %4202
  %4211 = phi float [ %4204, %4202 ], [ %4209, %4205 ]
  %4212 = call float @dx.op.binary.f32(i32 36, float %4184, float %19)  ; FMin(a,b)
  %4213 = fsub fast float %4212, %11
  %4214 = fmul fast float %12, %4213
  %4215 = fsub fast float -0.000000e+00, %4214
  %4216 = call float @dx.op.binary.f32(i32 35, float %4215, float -4.000000e+01)  ; FMax(a,b)
  %4217 = call float @dx.op.binary.f32(i32 36, float %4216, float 5.000000e+00)  ; FMin(a,b)
  %4218 = fmul fast float %4217, 0x3FF7154760000000
  %4219 = call float @dx.op.unary.f32(i32 21, float %4218)  ; Exp(value)
  %4220 = fmul fast float %4219, %4211
  br label %4221

; <label>:4221                                    ; preds = %4210, %4170
  %4222 = phi float [ %4220, %4210 ], [ 1.000000e+00, %4170 ]
  %4223 = fmul fast float %4196, %17
  %4224 = fmul fast float %4223, %4222
  %4225 = fcmp fast ole float %4194, %10
  %4226 = fcmp fast olt float %4194, 0x3F1A36E2E0000000
  %4227 = or i1 %4225, %4226
  br i1 %4227, label %4274, label %4228

; <label>:4228                                    ; preds = %4221
  %4229 = fdiv fast float %10, %4194
  %4230 = fmul fast float %4229, %4186
  %4231 = fmul fast float %4229, %4187
  %4232 = fmul fast float %4229, %4188
  %4233 = fadd fast float %4230, %18
  %4234 = fadd fast float %4231, %19
  %4235 = fadd fast float %4232, %20
  %4236 = fadd fast float %4233, -9.000000e+02
  %4237 = fadd fast float %4234, -1.500000e+01
  %4238 = fadd fast float %4235, -7.500000e+02
  %4239 = fmul fast float %4236, 0x3F62345680000000
  %4240 = fmul fast float %4237, 0x3F62345680000000
  %4241 = fmul fast float %4238, 0x3F62345680000000
  %4242 = call float @dx.op.dot3.f32(i32 55, float %4239, float %4240, float %4241, float %4239, float %4240, float %4241)  ; Dot3(ax,ay,az,bx,by,bz)
  %4243 = fsub fast float 1.000000e+00, %4242
  %4244 = call float @dx.op.unary.f32(i32 7, float %4243)  ; Saturate(value)
  %4245 = fmul fast float %4244, %4244
  %4246 = fadd fast float %4233, %4183
  %4247 = fadd fast float %4234, %4184
  %4248 = fadd fast float %4235, %4185
  %4249 = fmul fast float %4246, 0x3F52345680000000
  %4250 = fadd fast float %4249, -2.000000e+00
  %4251 = fmul fast float %4247, 0x3F52345680000000
  %4252 = fadd fast float %4251, 0xBFA1111120000000
  %4253 = fmul fast float %4248, 0x3F52345680000000
  %4254 = fadd fast float %4253, 0xBFFAAAAAC0000000
  %4255 = call float @dx.op.dot3.f32(i32 55, float %4250, float %4252, float %4254, float %4250, float %4252, float %4254)  ; Dot3(ax,ay,az,bx,by,bz)
  %4256 = fsub fast float 1.000000e+00, %4255
  %4257 = call float @dx.op.unary.f32(i32 7, float %4256)  ; Saturate(value)
  %4258 = fmul fast float %4257, %4257
  %4259 = fmul fast float %4258, 4.000000e+00
  %4260 = fadd fast float %4259, %4245
  %4261 = fadd fast float %4183, -9.000000e+02
  %4262 = fadd fast float %4184, -1.500000e+01
  %4263 = fadd fast float %4185, -7.500000e+02
  %4264 = fmul fast float %4261, 0x3F62345680000000
  %4265 = fmul fast float %4262, 0x3F62345680000000
  %4266 = fmul fast float %4263, 0x3F62345680000000
  %4267 = call float @dx.op.dot3.f32(i32 55, float %4264, float %4265, float %4266, float %4264, float %4265, float %4266)  ; Dot3(ax,ay,az,bx,by,bz)
  %4268 = fsub fast float 1.000000e+00, %4267
  %4269 = call float @dx.op.unary.f32(i32 7, float %4268)  ; Saturate(value)
  %4270 = fmul fast float %4269, %4269
  %4271 = fadd fast float %4260, %4270
  %4272 = fmul fast float %4195, 0x3F25D867E0000000
  %4273 = fmul fast float %4272, %4271
  br label %4274

; <label>:4274                                    ; preds = %4228, %4221
  %4275 = phi float [ %4273, %4228 ], [ 0.000000e+00, %4221 ]
  %4276 = fadd fast float %4275, %4224
  %4277 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4276)  ; FMin(a,b)
  %4278 = fmul fast float %4277, 0xBFF7154760000000
  %4279 = call float @dx.op.unary.f32(i32 21, float %4278)  ; Exp(value)
  %4280 = fsub fast float 1.000000e+00, %4279
  %4281 = call float @dx.op.binary.f32(i32 36, float %13, float %4280)  ; FMin(a,b)
  %4282 = fsub fast float %14, %4108
  %4283 = fsub fast float %15, %4109
  %4284 = fsub fast float %16, %4110
  %4285 = fmul fast float %4281, %4282
  %4286 = fmul fast float %4281, %4283
  %4287 = fmul fast float %4281, %4284
  %4288 = fadd fast float %4285, %4108
  %4289 = fadd fast float %4286, %4109
  %4290 = fadd fast float %4287, %4110
  br label %4291

; <label>:4291                                    ; preds = %4274, %4153, %4147
  %4292 = phi float [ %4288, %4274 ], [ %4108, %4153 ], [ %4108, %4147 ]
  %4293 = phi float [ %4289, %4274 ], [ %4109, %4153 ], [ %4109, %4147 ]
  %4294 = phi float [ %4290, %4274 ], [ %4110, %4153 ], [ %4110, %4147 ]
  %4295 = fadd fast float %6, 1.000000e+00
  %4296 = fadd fast float %7, 1.000000e+00
  %4297 = fsub fast float 1.000000e+00, %6
  %4298 = fmul fast float %37, %4295
  %4299 = fmul fast float %37, %4296
  %4300 = fmul fast float %37, %4297
  %4301 = fmul fast float %4298, %4292
  %4302 = fmul fast float %4299, %4293
  %4303 = fmul fast float %4300, %4294
  %4304 = fcmp fast ult float %38, 5.000000e-01
  br i1 %4304, label %4330, label %4305

; <label>:4305                                    ; preds = %4291
  %4306 = fmul fast float %4301, 0x4004147AE0000000
  %4307 = fmul fast float %4302, 0x4004147AE0000000
  %4308 = fmul fast float %4303, 0x4004147AE0000000
  %4309 = fadd fast float %4306, 0x3F9EB851E0000000
  %4310 = fadd fast float %4307, 0x3F9EB851E0000000
  %4311 = fadd fast float %4308, 0x3F9EB851E0000000
  %4312 = fmul fast float %4309, %4301
  %4313 = fmul fast float %4310, %4302
  %4314 = fmul fast float %4311, %4303
  %4315 = fmul fast float %4301, 0x400370A3E0000000
  %4316 = fmul fast float %4302, 0x400370A3E0000000
  %4317 = fmul fast float %4303, 0x400370A3E0000000
  %4318 = fadd fast float %4315, 0x3FE2E147A0000000
  %4319 = fadd fast float %4316, 0x3FE2E147A0000000
  %4320 = fadd fast float %4317, 0x3FE2E147A0000000
  %4321 = fmul fast float %4318, %4301
  %4322 = fmul fast float %4319, %4302
  %4323 = fmul fast float %4320, %4303
  %4324 = fadd fast float %4321, 0x3FC1EB8520000000
  %4325 = fadd fast float %4322, 0x3FC1EB8520000000
  %4326 = fadd fast float %4323, 0x3FC1EB8520000000
  %4327 = fdiv fast float %4312, %4324
  %4328 = fdiv fast float %4313, %4325
  %4329 = fdiv fast float %4314, %4326
  br label %4330

; <label>:4330                                    ; preds = %4305, %4291
  %4331 = phi float [ %4327, %4305 ], [ %4301, %4291 ]
  %4332 = phi float [ %4328, %4305 ], [ %4302, %4291 ]
  %4333 = phi float [ %4329, %4305 ], [ %4303, %4291 ]
  %4334 = call float @dx.op.unary.f32(i32 7, float %4331)  ; Saturate(value)
  %4335 = call float @dx.op.unary.f32(i32 7, float %4332)  ; Saturate(value)
  %4336 = call float @dx.op.unary.f32(i32 7, float %4333)  ; Saturate(value)
  %4337 = call float @dx.op.dot3.f32(i32 55, float %4334, float %4335, float %4336, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4338 = fsub fast float %4334, %4337
  %4339 = fsub fast float %4335, %4337
  %4340 = fsub fast float %4336, %4337
  %4341 = fmul fast float %4338, %9
  %4342 = fmul fast float %4339, %9
  %4343 = fmul fast float %4340, %9
  %4344 = fadd fast float %4341, %4337
  %4345 = fadd fast float %4342, %4337
  %4346 = fadd fast float %4343, %4337
  %4347 = call float @dx.op.unary.f32(i32 7, float %4344)  ; Saturate(value)
  %4348 = call float @dx.op.unary.f32(i32 7, float %4345)  ; Saturate(value)
  %4349 = call float @dx.op.unary.f32(i32 7, float %4346)  ; Saturate(value)
  %4350 = fadd fast float %4347, 0xBFC70A3D80000000
  %4351 = fadd fast float %4348, 0xBFC70A3D80000000
  %4352 = fadd fast float %4349, 0xBFC70A3D80000000
  %4353 = fmul fast float %4350, %8
  %4354 = fmul fast float %4351, %8
  %4355 = fmul fast float %4352, %8
  %4356 = fadd fast float %4353, 0x3FC70A3D80000000
  %4357 = fadd fast float %4354, 0x3FC70A3D80000000
  %4358 = fadd fast float %4355, 0x3FC70A3D80000000
  %4359 = call float @dx.op.unary.f32(i32 7, float %4356)  ; Saturate(value)
  %4360 = call float @dx.op.unary.f32(i32 7, float %4357)  ; Saturate(value)
  %4361 = call float @dx.op.unary.f32(i32 7, float %4358)  ; Saturate(value)
  br label %4362

; <label>:4362                                    ; preds = %4330, %4113
  %4363 = phi float [ %4144, %4113 ], [ %4359, %4330 ]
  %4364 = phi float [ %4145, %4113 ], [ %4360, %4330 ]
  %4365 = phi float [ %4146, %4113 ], [ %4361, %4330 ]
  %4366 = fsub fast float %4363, %3503
  %4367 = fsub fast float %4364, %3504
  %4368 = fsub fast float %4365, %3505
  %4369 = fmul fast float %4366, %4100
  %4370 = fmul fast float %4367, %4100
  %4371 = fmul fast float %4368, %4100
  %4372 = fadd fast float %4369, %3503
  %4373 = fadd fast float %4370, %3504
  %4374 = fadd fast float %4371, %3505
  br label %4375

; <label>:4375                                    ; preds = %4362, %4085
  %4376 = phi float [ %4372, %4362 ], [ %3503, %4085 ]
  %4377 = phi float [ %4373, %4362 ], [ %3504, %4085 ]
  %4378 = phi float [ %4374, %4362 ], [ %3505, %4085 ]
  %4379 = add i32 %64, 1
  %4380 = call i32 @dx.op.binary.i32(i32 37, i32 %4379, i32 0)  ; IMax(a,b)
  %4381 = call i32 @dx.op.binary.i32(i32 38, i32 %4380, i32 %60)  ; IMin(a,b)
  %4382 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4381, i32 %4093, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4383 = extractvalue %dx.types.ResRet.f32 %4382, 0
  %4384 = fsub fast float %4383, %87
  %4385 = call float @dx.op.unary.f32(i32 6, float %4384)  ; FAbs(value)
  %4386 = fdiv fast float %4385, %3517
  %4387 = fsub fast float 1.000000e+00, %4386
  %4388 = call float @dx.op.unary.f32(i32 7, float %4387)  ; Saturate(value)
  %4389 = fcmp fast ugt float %4388, 0.000000e+00
  br i1 %4389, label %4390, label %4663

; <label>:4390                                    ; preds = %4375
  %4391 = call i32 @dx.op.binary.i32(i32 37, i32 %4381, i32 0)  ; IMax(a,b)
  %4392 = call i32 @dx.op.binary.i32(i32 37, i32 %4093, i32 0)  ; IMax(a,b)
  %4393 = call i32 @dx.op.binary.i32(i32 38, i32 %4391, i32 %60)  ; IMin(a,b)
  %4394 = call i32 @dx.op.binary.i32(i32 38, i32 %4392, i32 %61)  ; IMin(a,b)
  %4395 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4393, i32 %4394, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4396 = extractvalue %dx.types.ResRet.f32 %4395, 0
  %4397 = extractvalue %dx.types.ResRet.f32 %4395, 1
  %4398 = extractvalue %dx.types.ResRet.f32 %4395, 2
  %4399 = extractvalue %dx.types.ResRet.f32 %4395, 3
  %4400 = fcmp fast olt float %4399, 0.000000e+00
  br i1 %4400, label %4401, label %4435

; <label>:4401                                    ; preds = %4390
  %4402 = fcmp fast ogt float %4396, 0x3FA4B5DCC0000000
  %4403 = fcmp fast ogt float %4397, 0x3FA4B5DCC0000000
  %4404 = fcmp fast ogt float %4398, 0x3FA4B5DCC0000000
  %4405 = select i1 %4402, float 0.000000e+00, float 1.000000e+00
  %4406 = select i1 %4403, float 0.000000e+00, float 1.000000e+00
  %4407 = select i1 %4404, float 0.000000e+00, float 1.000000e+00
  %4408 = fmul fast float %4396, 0x3FB3D07220000000
  %4409 = fmul fast float %4397, 0x3FB3D07220000000
  %4410 = fmul fast float %4398, 0x3FB3D07220000000
  %4411 = fadd fast float %4396, 0x3FAC28F5C0000000
  %4412 = fadd fast float %4397, 0x3FAC28F5C0000000
  %4413 = fadd fast float %4398, 0x3FAC28F5C0000000
  %4414 = fmul fast float %4411, 0x3FEE54EDE0000000
  %4415 = fmul fast float %4412, 0x3FEE54EDE0000000
  %4416 = fmul fast float %4413, 0x3FEE54EDE0000000
  %4417 = call float @dx.op.unary.f32(i32 23, float %4414)  ; Log(value)
  %4418 = call float @dx.op.unary.f32(i32 23, float %4415)  ; Log(value)
  %4419 = call float @dx.op.unary.f32(i32 23, float %4416)  ; Log(value)
  %4420 = fmul fast float %4417, 0x4003333340000000
  %4421 = fmul fast float %4418, 0x4003333340000000
  %4422 = fmul fast float %4419, 0x4003333340000000
  %4423 = call float @dx.op.unary.f32(i32 21, float %4420)  ; Exp(value)
  %4424 = call float @dx.op.unary.f32(i32 21, float %4421)  ; Exp(value)
  %4425 = call float @dx.op.unary.f32(i32 21, float %4422)  ; Exp(value)
  %4426 = fsub fast float %4408, %4423
  %4427 = fsub fast float %4409, %4424
  %4428 = fsub fast float %4410, %4425
  %4429 = fmul fast float %4426, %4405
  %4430 = fmul fast float %4427, %4406
  %4431 = fmul fast float %4428, %4407
  %4432 = fadd fast float %4429, %4423
  %4433 = fadd fast float %4430, %4424
  %4434 = fadd fast float %4431, %4425
  br label %4650

; <label>:4435                                    ; preds = %4390
  %4436 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4393, i32 %4394, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4437 = extractvalue %dx.types.ResRet.f32 %4436, 0
  %4438 = fcmp fast ogt float %39, 5.000000e-01
  %4439 = fcmp fast olt float %4437, 1.000000e+00
  %4440 = and i1 %4438, %4439
  br i1 %4440, label %4441, label %4579

; <label>:4441                                    ; preds = %4435
  %4442 = sitofp i32 %4393 to float
  %4443 = sitofp i32 %4394 to float
  %4444 = fadd fast float %4442, 5.000000e-01
  %4445 = fadd fast float %4443, 5.000000e-01
  %4446 = fdiv fast float %4444, %46
  %4447 = fdiv fast float %4445, %47
  %4448 = fmul fast float %4446, 2.000000e+00
  %4449 = fmul fast float %4447, 2.000000e+00
  %4450 = fadd fast float %4448, -1.000000e+00
  %4451 = fsub fast float 1.000000e+00, %4449
  %4452 = fmul fast float %4450, %36
  %4453 = call float @dx.op.tertiary.f32(i32 46, float %4451, float %32, float %4452)  ; FMad(a,b,c)
  %4454 = call float @dx.op.tertiary.f32(i32 46, float %4437, float %28, float %4453)  ; FMad(a,b,c)
  %4455 = fadd fast float %4454, %24
  %4456 = call float @dx.op.unary.f32(i32 6, float %4455)  ; FAbs(value)
  %4457 = fcmp fast ogt float %4456, 0x3EB0C6F7A0000000
  br i1 %4457, label %4458, label %4579

; <label>:4458                                    ; preds = %4441
  %4459 = fmul fast float %4450, %35
  %4460 = call float @dx.op.tertiary.f32(i32 46, float %4451, float %31, float %4459)  ; FMad(a,b,c)
  %4461 = call float @dx.op.tertiary.f32(i32 46, float %4437, float %27, float %4460)  ; FMad(a,b,c)
  %4462 = fadd fast float %4461, %23
  %4463 = fmul fast float %4450, %34
  %4464 = call float @dx.op.tertiary.f32(i32 46, float %4451, float %30, float %4463)  ; FMad(a,b,c)
  %4465 = call float @dx.op.tertiary.f32(i32 46, float %4437, float %26, float %4464)  ; FMad(a,b,c)
  %4466 = fadd fast float %4465, %22
  %4467 = fmul fast float %4450, %33
  %4468 = call float @dx.op.tertiary.f32(i32 46, float %4451, float %29, float %4467)  ; FMad(a,b,c)
  %4469 = call float @dx.op.tertiary.f32(i32 46, float %4437, float %25, float %4468)  ; FMad(a,b,c)
  %4470 = fadd fast float %4469, %21
  %4471 = fdiv fast float %4470, %4455
  %4472 = fdiv fast float %4466, %4455
  %4473 = fdiv fast float %4462, %4455
  %4474 = fsub fast float %4471, %18
  %4475 = fsub fast float %4472, %19
  %4476 = fsub fast float %4473, %20
  %4477 = fmul fast float %4474, %4474
  %4478 = fmul fast float %4475, %4475
  %4479 = fadd fast float %4478, %4477
  %4480 = fmul fast float %4476, %4476
  %4481 = fadd fast float %4479, %4480
  %4482 = call float @dx.op.unary.f32(i32 24, float %4481)  ; Sqrt(value)
  %4483 = fsub fast float %4482, %10
  %4484 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4483)  ; FMax(a,b)
  %4485 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %4485, label %4486, label %4509

; <label>:4486                                    ; preds = %4458
  %4487 = call float @dx.op.unary.f32(i32 6, float %4475)  ; FAbs(value)
  %4488 = fmul fast float %4487, %12
  %4489 = fcmp fast olt float %4488, 0x3F50624DE0000000
  br i1 %4489, label %4490, label %4493

; <label>:4490                                    ; preds = %4486
  %4491 = fmul fast float %4488, 5.000000e-01
  %4492 = fsub fast float 1.000000e+00, %4491
  br label %4498

; <label>:4493                                    ; preds = %4486
  %4494 = fmul fast float %4488, 0xBFF7154760000000
  %4495 = call float @dx.op.unary.f32(i32 21, float %4494)  ; Exp(value)
  %4496 = fsub fast float 1.000000e+00, %4495
  %4497 = fdiv fast float %4496, %4488
  br label %4498

; <label>:4498                                    ; preds = %4493, %4490
  %4499 = phi float [ %4492, %4490 ], [ %4497, %4493 ]
  %4500 = call float @dx.op.binary.f32(i32 36, float %4472, float %19)  ; FMin(a,b)
  %4501 = fsub fast float %4500, %11
  %4502 = fmul fast float %12, %4501
  %4503 = fsub fast float -0.000000e+00, %4502
  %4504 = call float @dx.op.binary.f32(i32 35, float %4503, float -4.000000e+01)  ; FMax(a,b)
  %4505 = call float @dx.op.binary.f32(i32 36, float %4504, float 5.000000e+00)  ; FMin(a,b)
  %4506 = fmul fast float %4505, 0x3FF7154760000000
  %4507 = call float @dx.op.unary.f32(i32 21, float %4506)  ; Exp(value)
  %4508 = fmul fast float %4507, %4499
  br label %4509

; <label>:4509                                    ; preds = %4498, %4458
  %4510 = phi float [ %4508, %4498 ], [ 1.000000e+00, %4458 ]
  %4511 = fmul fast float %4484, %17
  %4512 = fmul fast float %4511, %4510
  %4513 = fcmp fast ole float %4482, %10
  %4514 = fcmp fast olt float %4482, 0x3F1A36E2E0000000
  %4515 = or i1 %4513, %4514
  br i1 %4515, label %4562, label %4516

; <label>:4516                                    ; preds = %4509
  %4517 = fdiv fast float %10, %4482
  %4518 = fmul fast float %4517, %4474
  %4519 = fmul fast float %4517, %4475
  %4520 = fmul fast float %4517, %4476
  %4521 = fadd fast float %4518, %18
  %4522 = fadd fast float %4519, %19
  %4523 = fadd fast float %4520, %20
  %4524 = fadd fast float %4521, -9.000000e+02
  %4525 = fadd fast float %4522, -1.500000e+01
  %4526 = fadd fast float %4523, -7.500000e+02
  %4527 = fmul fast float %4524, 0x3F62345680000000
  %4528 = fmul fast float %4525, 0x3F62345680000000
  %4529 = fmul fast float %4526, 0x3F62345680000000
  %4530 = call float @dx.op.dot3.f32(i32 55, float %4527, float %4528, float %4529, float %4527, float %4528, float %4529)  ; Dot3(ax,ay,az,bx,by,bz)
  %4531 = fsub fast float 1.000000e+00, %4530
  %4532 = call float @dx.op.unary.f32(i32 7, float %4531)  ; Saturate(value)
  %4533 = fmul fast float %4532, %4532
  %4534 = fadd fast float %4521, %4471
  %4535 = fadd fast float %4522, %4472
  %4536 = fadd fast float %4523, %4473
  %4537 = fmul fast float %4534, 0x3F52345680000000
  %4538 = fadd fast float %4537, -2.000000e+00
  %4539 = fmul fast float %4535, 0x3F52345680000000
  %4540 = fadd fast float %4539, 0xBFA1111120000000
  %4541 = fmul fast float %4536, 0x3F52345680000000
  %4542 = fadd fast float %4541, 0xBFFAAAAAC0000000
  %4543 = call float @dx.op.dot3.f32(i32 55, float %4538, float %4540, float %4542, float %4538, float %4540, float %4542)  ; Dot3(ax,ay,az,bx,by,bz)
  %4544 = fsub fast float 1.000000e+00, %4543
  %4545 = call float @dx.op.unary.f32(i32 7, float %4544)  ; Saturate(value)
  %4546 = fmul fast float %4545, %4545
  %4547 = fmul fast float %4546, 4.000000e+00
  %4548 = fadd fast float %4547, %4533
  %4549 = fadd fast float %4471, -9.000000e+02
  %4550 = fadd fast float %4472, -1.500000e+01
  %4551 = fadd fast float %4473, -7.500000e+02
  %4552 = fmul fast float %4549, 0x3F62345680000000
  %4553 = fmul fast float %4550, 0x3F62345680000000
  %4554 = fmul fast float %4551, 0x3F62345680000000
  %4555 = call float @dx.op.dot3.f32(i32 55, float %4552, float %4553, float %4554, float %4552, float %4553, float %4554)  ; Dot3(ax,ay,az,bx,by,bz)
  %4556 = fsub fast float 1.000000e+00, %4555
  %4557 = call float @dx.op.unary.f32(i32 7, float %4556)  ; Saturate(value)
  %4558 = fmul fast float %4557, %4557
  %4559 = fadd fast float %4548, %4558
  %4560 = fmul fast float %4483, 0x3F25D867E0000000
  %4561 = fmul fast float %4560, %4559
  br label %4562

; <label>:4562                                    ; preds = %4516, %4509
  %4563 = phi float [ %4561, %4516 ], [ 0.000000e+00, %4509 ]
  %4564 = fadd fast float %4563, %4512
  %4565 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4564)  ; FMin(a,b)
  %4566 = fmul fast float %4565, 0xBFF7154760000000
  %4567 = call float @dx.op.unary.f32(i32 21, float %4566)  ; Exp(value)
  %4568 = fsub fast float 1.000000e+00, %4567
  %4569 = call float @dx.op.binary.f32(i32 36, float %13, float %4568)  ; FMin(a,b)
  %4570 = fsub fast float %14, %4396
  %4571 = fsub fast float %15, %4397
  %4572 = fsub fast float %16, %4398
  %4573 = fmul fast float %4569, %4570
  %4574 = fmul fast float %4569, %4571
  %4575 = fmul fast float %4569, %4572
  %4576 = fadd fast float %4573, %4396
  %4577 = fadd fast float %4574, %4397
  %4578 = fadd fast float %4575, %4398
  br label %4579

; <label>:4579                                    ; preds = %4562, %4441, %4435
  %4580 = phi float [ %4576, %4562 ], [ %4396, %4441 ], [ %4396, %4435 ]
  %4581 = phi float [ %4577, %4562 ], [ %4397, %4441 ], [ %4397, %4435 ]
  %4582 = phi float [ %4578, %4562 ], [ %4398, %4441 ], [ %4398, %4435 ]
  %4583 = fadd fast float %6, 1.000000e+00
  %4584 = fadd fast float %7, 1.000000e+00
  %4585 = fsub fast float 1.000000e+00, %6
  %4586 = fmul fast float %37, %4583
  %4587 = fmul fast float %37, %4584
  %4588 = fmul fast float %37, %4585
  %4589 = fmul fast float %4586, %4580
  %4590 = fmul fast float %4587, %4581
  %4591 = fmul fast float %4588, %4582
  %4592 = fcmp fast ult float %38, 5.000000e-01
  br i1 %4592, label %4618, label %4593

; <label>:4593                                    ; preds = %4579
  %4594 = fmul fast float %4589, 0x4004147AE0000000
  %4595 = fmul fast float %4590, 0x4004147AE0000000
  %4596 = fmul fast float %4591, 0x4004147AE0000000
  %4597 = fadd fast float %4594, 0x3F9EB851E0000000
  %4598 = fadd fast float %4595, 0x3F9EB851E0000000
  %4599 = fadd fast float %4596, 0x3F9EB851E0000000
  %4600 = fmul fast float %4597, %4589
  %4601 = fmul fast float %4598, %4590
  %4602 = fmul fast float %4599, %4591
  %4603 = fmul fast float %4589, 0x400370A3E0000000
  %4604 = fmul fast float %4590, 0x400370A3E0000000
  %4605 = fmul fast float %4591, 0x400370A3E0000000
  %4606 = fadd fast float %4603, 0x3FE2E147A0000000
  %4607 = fadd fast float %4604, 0x3FE2E147A0000000
  %4608 = fadd fast float %4605, 0x3FE2E147A0000000
  %4609 = fmul fast float %4606, %4589
  %4610 = fmul fast float %4607, %4590
  %4611 = fmul fast float %4608, %4591
  %4612 = fadd fast float %4609, 0x3FC1EB8520000000
  %4613 = fadd fast float %4610, 0x3FC1EB8520000000
  %4614 = fadd fast float %4611, 0x3FC1EB8520000000
  %4615 = fdiv fast float %4600, %4612
  %4616 = fdiv fast float %4601, %4613
  %4617 = fdiv fast float %4602, %4614
  br label %4618

; <label>:4618                                    ; preds = %4593, %4579
  %4619 = phi float [ %4615, %4593 ], [ %4589, %4579 ]
  %4620 = phi float [ %4616, %4593 ], [ %4590, %4579 ]
  %4621 = phi float [ %4617, %4593 ], [ %4591, %4579 ]
  %4622 = call float @dx.op.unary.f32(i32 7, float %4619)  ; Saturate(value)
  %4623 = call float @dx.op.unary.f32(i32 7, float %4620)  ; Saturate(value)
  %4624 = call float @dx.op.unary.f32(i32 7, float %4621)  ; Saturate(value)
  %4625 = call float @dx.op.dot3.f32(i32 55, float %4622, float %4623, float %4624, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4626 = fsub fast float %4622, %4625
  %4627 = fsub fast float %4623, %4625
  %4628 = fsub fast float %4624, %4625
  %4629 = fmul fast float %4626, %9
  %4630 = fmul fast float %4627, %9
  %4631 = fmul fast float %4628, %9
  %4632 = fadd fast float %4629, %4625
  %4633 = fadd fast float %4630, %4625
  %4634 = fadd fast float %4631, %4625
  %4635 = call float @dx.op.unary.f32(i32 7, float %4632)  ; Saturate(value)
  %4636 = call float @dx.op.unary.f32(i32 7, float %4633)  ; Saturate(value)
  %4637 = call float @dx.op.unary.f32(i32 7, float %4634)  ; Saturate(value)
  %4638 = fadd fast float %4635, 0xBFC70A3D80000000
  %4639 = fadd fast float %4636, 0xBFC70A3D80000000
  %4640 = fadd fast float %4637, 0xBFC70A3D80000000
  %4641 = fmul fast float %4638, %8
  %4642 = fmul fast float %4639, %8
  %4643 = fmul fast float %4640, %8
  %4644 = fadd fast float %4641, 0x3FC70A3D80000000
  %4645 = fadd fast float %4642, 0x3FC70A3D80000000
  %4646 = fadd fast float %4643, 0x3FC70A3D80000000
  %4647 = call float @dx.op.unary.f32(i32 7, float %4644)  ; Saturate(value)
  %4648 = call float @dx.op.unary.f32(i32 7, float %4645)  ; Saturate(value)
  %4649 = call float @dx.op.unary.f32(i32 7, float %4646)  ; Saturate(value)
  br label %4650

; <label>:4650                                    ; preds = %4618, %4401
  %4651 = phi float [ %4432, %4401 ], [ %4647, %4618 ]
  %4652 = phi float [ %4433, %4401 ], [ %4648, %4618 ]
  %4653 = phi float [ %4434, %4401 ], [ %4649, %4618 ]
  %4654 = fsub fast float %4651, %3503
  %4655 = fsub fast float %4652, %3504
  %4656 = fsub fast float %4653, %3505
  %4657 = fmul fast float %4654, %4388
  %4658 = fmul fast float %4655, %4388
  %4659 = fmul fast float %4656, %4388
  %4660 = fadd fast float %4657, %3503
  %4661 = fadd fast float %4658, %3504
  %4662 = fadd fast float %4659, %3505
  br label %4663

; <label>:4663                                    ; preds = %4650, %4375
  %4664 = phi float [ %4660, %4650 ], [ %3503, %4375 ]
  %4665 = phi float [ %4661, %4650 ], [ %3504, %4375 ]
  %4666 = phi float [ %4662, %4650 ], [ %3505, %4375 ]
  %4667 = call float @dx.op.binary.f32(i32 36, float %4376, float %4664)  ; FMin(a,b)
  %4668 = call float @dx.op.binary.f32(i32 36, float %4377, float %4665)  ; FMin(a,b)
  %4669 = call float @dx.op.binary.f32(i32 36, float %4378, float %4666)  ; FMin(a,b)
  %4670 = call float @dx.op.binary.f32(i32 36, float %3798, float %4086)  ; FMin(a,b)
  %4671 = call float @dx.op.binary.f32(i32 36, float %3799, float %4087)  ; FMin(a,b)
  %4672 = call float @dx.op.binary.f32(i32 36, float %3800, float %4088)  ; FMin(a,b)
  %4673 = call float @dx.op.binary.f32(i32 36, float %4670, float %4667)  ; FMin(a,b)
  %4674 = call float @dx.op.binary.f32(i32 36, float %4671, float %4668)  ; FMin(a,b)
  %4675 = call float @dx.op.binary.f32(i32 36, float %4672, float %4669)  ; FMin(a,b)
  %4676 = call float @dx.op.binary.f32(i32 36, float %3503, float %4673)  ; FMin(a,b)
  %4677 = call float @dx.op.binary.f32(i32 36, float %3504, float %4674)  ; FMin(a,b)
  %4678 = call float @dx.op.binary.f32(i32 36, float %3505, float %4675)  ; FMin(a,b)
  %4679 = call float @dx.op.binary.f32(i32 35, float %4376, float %4664)  ; FMax(a,b)
  %4680 = call float @dx.op.binary.f32(i32 35, float %4377, float %4665)  ; FMax(a,b)
  %4681 = call float @dx.op.binary.f32(i32 35, float %4378, float %4666)  ; FMax(a,b)
  %4682 = call float @dx.op.binary.f32(i32 35, float %3798, float %4086)  ; FMax(a,b)
  %4683 = call float @dx.op.binary.f32(i32 35, float %3799, float %4087)  ; FMax(a,b)
  %4684 = call float @dx.op.binary.f32(i32 35, float %3800, float %4088)  ; FMax(a,b)
  %4685 = call float @dx.op.binary.f32(i32 35, float %4682, float %4679)  ; FMax(a,b)
  %4686 = call float @dx.op.binary.f32(i32 35, float %4683, float %4680)  ; FMax(a,b)
  %4687 = call float @dx.op.binary.f32(i32 35, float %4684, float %4681)  ; FMax(a,b)
  %4688 = call float @dx.op.binary.f32(i32 35, float %3503, float %4685)  ; FMax(a,b)
  %4689 = call float @dx.op.binary.f32(i32 35, float %3504, float %4686)  ; FMax(a,b)
  %4690 = call float @dx.op.binary.f32(i32 35, float %3505, float %4687)  ; FMax(a,b)
  %4691 = fsub fast float %4688, %4676
  %4692 = fsub fast float %4689, %4677
  %4693 = fsub fast float %4690, %4678
  %4694 = call float @dx.op.unary.f32(i32 6, float %4691)  ; FAbs(value)
  %4695 = call float @dx.op.unary.f32(i32 6, float %4692)  ; FAbs(value)
  %4696 = call float @dx.op.unary.f32(i32 6, float %4693)  ; FAbs(value)
  %4697 = call float @dx.op.binary.f32(i32 35, float %4695, float %4696)  ; FMax(a,b)
  %4698 = call float @dx.op.binary.f32(i32 35, float %4694, float %4697)  ; FMax(a,b)
  %4699 = call float @dx.op.binary.f32(i32 35, float %4689, float %4690)  ; FMax(a,b)
  %4700 = call float @dx.op.binary.f32(i32 35, float %4688, float %4699)  ; FMax(a,b)
  %4701 = fmul fast float %4700, 1.250000e-01
  %4702 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %4701)  ; FMax(a,b)
  %4703 = fcmp fast ogt float %4698, %4702
  br i1 %4703, label %4704, label %4766

; <label>:4704                                    ; preds = %4663
  %4705 = fsub fast float %3798, %4086
  %4706 = fsub fast float %3799, %4087
  %4707 = fsub fast float %3800, %4088
  %4708 = call float @dx.op.unary.f32(i32 6, float %4705)  ; FAbs(value)
  %4709 = call float @dx.op.unary.f32(i32 6, float %4706)  ; FAbs(value)
  %4710 = call float @dx.op.unary.f32(i32 6, float %4707)  ; FAbs(value)
  %4711 = call float @dx.op.binary.f32(i32 35, float %4709, float %4710)  ; FMax(a,b)
  %4712 = call float @dx.op.binary.f32(i32 35, float %4708, float %4711)  ; FMax(a,b)
  %4713 = fsub fast float %4376, %4664
  %4714 = fsub fast float %4377, %4665
  %4715 = fsub fast float %4378, %4666
  %4716 = call float @dx.op.unary.f32(i32 6, float %4713)  ; FAbs(value)
  %4717 = call float @dx.op.unary.f32(i32 6, float %4714)  ; FAbs(value)
  %4718 = call float @dx.op.unary.f32(i32 6, float %4715)  ; FAbs(value)
  %4719 = call float @dx.op.binary.f32(i32 35, float %4717, float %4718)  ; FMax(a,b)
  %4720 = call float @dx.op.binary.f32(i32 35, float %4716, float %4719)  ; FMax(a,b)
  %4721 = fcmp fast olt float %4712, %4720
  %4722 = select i1 %4721, float %3798, float %4376
  %4723 = select i1 %4721, float %3799, float %4377
  %4724 = select i1 %4721, float %3800, float %4378
  %4725 = select i1 %4721, float %4086, float %4664
  %4726 = select i1 %4721, float %4087, float %4665
  %4727 = select i1 %4721, float %4088, float %4666
  %4728 = fsub fast float %3503, %4725
  %4729 = fsub fast float %3504, %4726
  %4730 = fsub fast float %3505, %4727
  %4731 = fsub fast float %3503, %4722
  %4732 = fsub fast float %3504, %4723
  %4733 = fsub fast float %3505, %4724
  %4734 = call float @dx.op.dot3.f32(i32 55, float %4731, float %4732, float %4733, float %4728, float %4729, float %4730)  ; Dot3(ax,ay,az,bx,by,bz)
  %4735 = fcmp fast ogt float %4734, 0.000000e+00
  br i1 %4735, label %4736, label %4747

; <label>:4736                                    ; preds = %4704
  %4737 = fsub fast float %4722, %4725
  %4738 = fsub fast float %4723, %4726
  %4739 = fsub fast float %4724, %4727
  %4740 = call float @dx.op.unary.f32(i32 6, float %4737)  ; FAbs(value)
  %4741 = call float @dx.op.unary.f32(i32 6, float %4738)  ; FAbs(value)
  %4742 = call float @dx.op.unary.f32(i32 6, float %4739)  ; FAbs(value)
  %4743 = call float @dx.op.binary.f32(i32 35, float %4741, float %4742)  ; FMax(a,b)
  %4744 = call float @dx.op.binary.f32(i32 35, float %4740, float %4743)  ; FMax(a,b)
  %4745 = fmul fast float %4698, 2.500000e-01
  %4746 = fcmp fast olt float %4744, %4745
  br label %4747

; <label>:4747                                    ; preds = %4736, %4704
  %4748 = phi i1 [ false, %4704 ], [ %4746, %4736 ]
  %4749 = select i1 %4748, float 5.000000e-01, float 1.000000e+00
  %4750 = fmul fast float %4749, %3
  %4751 = fadd fast float %4722, %4725
  %4752 = fadd fast float %4723, %4726
  %4753 = fadd fast float %4724, %4727
  %4754 = fmul fast float %4751, 5.000000e-01
  %4755 = fmul fast float %4752, 5.000000e-01
  %4756 = fmul fast float %4753, 5.000000e-01
  %4757 = fsub fast float %4754, %3503
  %4758 = fsub fast float %4755, %3504
  %4759 = fsub fast float %4756, %3505
  %4760 = fmul fast float %4750, %4757
  %4761 = fmul fast float %4750, %4758
  %4762 = fmul fast float %4750, %4759
  %4763 = fadd fast float %4760, %3503
  %4764 = fadd fast float %4761, %3504
  %4765 = fadd fast float %4762, %3505
  br label %4766

; <label>:4766                                    ; preds = %4747, %4663, %3474
  %4767 = phi float [ %3503, %3474 ], [ %4763, %4747 ], [ %3503, %4663 ]
  %4768 = phi float [ %3504, %3474 ], [ %4764, %4747 ], [ %3504, %4663 ]
  %4769 = phi float [ %3505, %3474 ], [ %4765, %4747 ], [ %3505, %4663 ]
  %4770 = fcmp fast ogt float %4767, 0x3F69A5C380000000
  %4771 = fcmp fast ogt float %4768, 0x3F69A5C380000000
  %4772 = fcmp fast ogt float %4769, 0x3F69A5C380000000
  %4773 = select i1 %4770, float 0.000000e+00, float 1.000000e+00
  %4774 = select i1 %4771, float 0.000000e+00, float 1.000000e+00
  %4775 = select i1 %4772, float 0.000000e+00, float 1.000000e+00
  %4776 = fmul fast float %4767, 0x4029D70A40000000
  %4777 = fmul fast float %4768, 0x4029D70A40000000
  %4778 = fmul fast float %4769, 0x4029D70A40000000
  %4779 = call float @dx.op.binary.f32(i32 35, float %4767, float 0.000000e+00)  ; FMax(a,b)
  %4780 = call float @dx.op.binary.f32(i32 35, float %4768, float 0.000000e+00)  ; FMax(a,b)
  %4781 = call float @dx.op.binary.f32(i32 35, float %4769, float 0.000000e+00)  ; FMax(a,b)
  %4782 = call float @dx.op.unary.f32(i32 23, float %4779)  ; Log(value)
  %4783 = call float @dx.op.unary.f32(i32 23, float %4780)  ; Log(value)
  %4784 = call float @dx.op.unary.f32(i32 23, float %4781)  ; Log(value)
  %4785 = fmul fast float %4782, 0x3FDAAAAAA0000000
  %4786 = fmul fast float %4783, 0x3FDAAAAAA0000000
  %4787 = fmul fast float %4784, 0x3FDAAAAAA0000000
  %4788 = call float @dx.op.unary.f32(i32 21, float %4785)  ; Exp(value)
  %4789 = call float @dx.op.unary.f32(i32 21, float %4786)  ; Exp(value)
  %4790 = call float @dx.op.unary.f32(i32 21, float %4787)  ; Exp(value)
  %4791 = fmul fast float %4788, 0x3FF0E147A0000000
  %4792 = fmul fast float %4789, 0x3FF0E147A0000000
  %4793 = fmul fast float %4790, 0x3FF0E147A0000000
  %4794 = fadd fast float %4791, 0xBFAC28F5C0000000
  %4795 = fadd fast float %4792, 0xBFAC28F5C0000000
  %4796 = fadd fast float %4793, 0xBFAC28F5C0000000
  %4797 = fsub fast float %4776, %4794
  %4798 = fsub fast float %4777, %4795
  %4799 = fsub fast float %4778, %4796
  %4800 = fmul fast float %4797, %4773
  %4801 = fmul fast float %4798, %4774
  %4802 = fmul fast float %4799, %4775
  %4803 = fadd fast float %4800, %4794
  %4804 = fadd fast float %4801, %4795
  %4805 = fadd fast float %4802, %4796
  br label %4806

; <label>:4806                                    ; preds = %4766, %3291
  %4807 = phi float [ %3286, %3291 ], [ %4803, %4766 ]
  %4808 = phi float [ %3287, %3291 ], [ %4804, %4766 ]
  %4809 = phi float [ %3288, %3291 ], [ %4805, %4766 ]
  %4810 = phi float [ %3292, %3291 ], [ %3289, %4766 ]
  %4811 = fcmp fast ogt float %4807, 0x3FA4B5DCC0000000
  %4812 = fcmp fast ogt float %4808, 0x3FA4B5DCC0000000
  %4813 = fcmp fast ogt float %4809, 0x3FA4B5DCC0000000
  %4814 = select i1 %4811, float 0.000000e+00, float 1.000000e+00
  %4815 = select i1 %4812, float 0.000000e+00, float 1.000000e+00
  %4816 = select i1 %4813, float 0.000000e+00, float 1.000000e+00
  %4817 = fmul fast float %4807, 0x3FB3D07220000000
  %4818 = fmul fast float %4808, 0x3FB3D07220000000
  %4819 = fmul fast float %4809, 0x3FB3D07220000000
  %4820 = fadd fast float %4807, 0x3FAC28F5C0000000
  %4821 = fadd fast float %4808, 0x3FAC28F5C0000000
  %4822 = fadd fast float %4809, 0x3FAC28F5C0000000
  %4823 = fmul fast float %4820, 0x3FEE54EDE0000000
  %4824 = fmul fast float %4821, 0x3FEE54EDE0000000
  %4825 = fmul fast float %4822, 0x3FEE54EDE0000000
  %4826 = call float @dx.op.unary.f32(i32 23, float %4823)  ; Log(value)
  %4827 = call float @dx.op.unary.f32(i32 23, float %4824)  ; Log(value)
  %4828 = call float @dx.op.unary.f32(i32 23, float %4825)  ; Log(value)
  %4829 = fmul fast float %4826, 0x4003333340000000
  %4830 = fmul fast float %4827, 0x4003333340000000
  %4831 = fmul fast float %4828, 0x4003333340000000
  %4832 = call float @dx.op.unary.f32(i32 21, float %4829)  ; Exp(value)
  %4833 = call float @dx.op.unary.f32(i32 21, float %4830)  ; Exp(value)
  %4834 = call float @dx.op.unary.f32(i32 21, float %4831)  ; Exp(value)
  %4835 = fsub fast float %4817, %4832
  %4836 = fsub fast float %4818, %4833
  %4837 = fsub fast float %4819, %4834
  %4838 = fmul fast float %4835, %4814
  %4839 = fmul fast float %4836, %4815
  %4840 = fmul fast float %4837, %4816
  %4841 = fadd fast float %4838, %4832
  %4842 = fadd fast float %4839, %4833
  %4843 = fadd fast float %4840, %4834
  %4844 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %68, i32 %71, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4845 = extractvalue %dx.types.ResRet.f32 %4844, 0
  %4846 = extractvalue %dx.types.ResRet.f32 %4844, 1
  %4847 = extractvalue %dx.types.ResRet.f32 %4844, 2
  %4848 = extractvalue %dx.types.ResRet.f32 %4844, 3
  %4849 = fcmp fast olt float %4848, 0.000000e+00
  br i1 %4849, label %4850, label %4852

; <label>:4850                                    ; preds = %4806
  %4851 = fsub fast float -1.000000e+00, %4848
  br label %6365

; <label>:4852                                    ; preds = %4806
  %4853 = fcmp fast ogt float %39, 5.000000e-01
  %4854 = fcmp fast olt float %89, 1.000000e+00
  %4855 = and i1 %4853, %4854
  br i1 %4855, label %4856, label %4994

; <label>:4856                                    ; preds = %4852
  %4857 = sitofp i32 %68 to float
  %4858 = sitofp i32 %71 to float
  %4859 = fadd fast float %4857, 5.000000e-01
  %4860 = fadd fast float %4858, 5.000000e-01
  %4861 = fdiv fast float %4859, %46
  %4862 = fdiv fast float %4860, %47
  %4863 = fmul fast float %4861, 2.000000e+00
  %4864 = fmul fast float %4862, 2.000000e+00
  %4865 = fadd fast float %4863, -1.000000e+00
  %4866 = fsub fast float 1.000000e+00, %4864
  %4867 = fmul fast float %4865, %36
  %4868 = call float @dx.op.tertiary.f32(i32 46, float %4866, float %32, float %4867)  ; FMad(a,b,c)
  %4869 = call float @dx.op.tertiary.f32(i32 46, float %89, float %28, float %4868)  ; FMad(a,b,c)
  %4870 = fadd fast float %4869, %24
  %4871 = call float @dx.op.unary.f32(i32 6, float %4870)  ; FAbs(value)
  %4872 = fcmp fast ogt float %4871, 0x3EB0C6F7A0000000
  br i1 %4872, label %4873, label %4994

; <label>:4873                                    ; preds = %4856
  %4874 = fmul fast float %4865, %35
  %4875 = call float @dx.op.tertiary.f32(i32 46, float %4866, float %31, float %4874)  ; FMad(a,b,c)
  %4876 = call float @dx.op.tertiary.f32(i32 46, float %89, float %27, float %4875)  ; FMad(a,b,c)
  %4877 = fadd fast float %4876, %23
  %4878 = fmul fast float %4865, %34
  %4879 = call float @dx.op.tertiary.f32(i32 46, float %4866, float %30, float %4878)  ; FMad(a,b,c)
  %4880 = call float @dx.op.tertiary.f32(i32 46, float %89, float %26, float %4879)  ; FMad(a,b,c)
  %4881 = fadd fast float %4880, %22
  %4882 = fmul fast float %4865, %33
  %4883 = call float @dx.op.tertiary.f32(i32 46, float %4866, float %29, float %4882)  ; FMad(a,b,c)
  %4884 = call float @dx.op.tertiary.f32(i32 46, float %89, float %25, float %4883)  ; FMad(a,b,c)
  %4885 = fadd fast float %4884, %21
  %4886 = fdiv fast float %4885, %4870
  %4887 = fdiv fast float %4881, %4870
  %4888 = fdiv fast float %4877, %4870
  %4889 = fsub fast float %4886, %18
  %4890 = fsub fast float %4887, %19
  %4891 = fsub fast float %4888, %20
  %4892 = fmul fast float %4889, %4889
  %4893 = fmul fast float %4890, %4890
  %4894 = fadd fast float %4893, %4892
  %4895 = fmul fast float %4891, %4891
  %4896 = fadd fast float %4894, %4895
  %4897 = call float @dx.op.unary.f32(i32 24, float %4896)  ; Sqrt(value)
  %4898 = fsub fast float %4897, %10
  %4899 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4898)  ; FMax(a,b)
  %4900 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %4900, label %4901, label %4924

; <label>:4901                                    ; preds = %4873
  %4902 = call float @dx.op.unary.f32(i32 6, float %4890)  ; FAbs(value)
  %4903 = fmul fast float %4902, %12
  %4904 = fcmp fast olt float %4903, 0x3F50624DE0000000
  br i1 %4904, label %4905, label %4908

; <label>:4905                                    ; preds = %4901
  %4906 = fmul fast float %4903, 5.000000e-01
  %4907 = fsub fast float 1.000000e+00, %4906
  br label %4913

; <label>:4908                                    ; preds = %4901
  %4909 = fmul fast float %4903, 0xBFF7154760000000
  %4910 = call float @dx.op.unary.f32(i32 21, float %4909)  ; Exp(value)
  %4911 = fsub fast float 1.000000e+00, %4910
  %4912 = fdiv fast float %4911, %4903
  br label %4913

; <label>:4913                                    ; preds = %4908, %4905
  %4914 = phi float [ %4907, %4905 ], [ %4912, %4908 ]
  %4915 = call float @dx.op.binary.f32(i32 36, float %4887, float %19)  ; FMin(a,b)
  %4916 = fsub fast float %4915, %11
  %4917 = fmul fast float %12, %4916
  %4918 = fsub fast float -0.000000e+00, %4917
  %4919 = call float @dx.op.binary.f32(i32 35, float %4918, float -4.000000e+01)  ; FMax(a,b)
  %4920 = call float @dx.op.binary.f32(i32 36, float %4919, float 5.000000e+00)  ; FMin(a,b)
  %4921 = fmul fast float %4920, 0x3FF7154760000000
  %4922 = call float @dx.op.unary.f32(i32 21, float %4921)  ; Exp(value)
  %4923 = fmul fast float %4922, %4914
  br label %4924

; <label>:4924                                    ; preds = %4913, %4873
  %4925 = phi float [ %4923, %4913 ], [ 1.000000e+00, %4873 ]
  %4926 = fmul fast float %4899, %17
  %4927 = fmul fast float %4926, %4925
  %4928 = fcmp fast ole float %4897, %10
  %4929 = fcmp fast olt float %4897, 0x3F1A36E2E0000000
  %4930 = or i1 %4928, %4929
  br i1 %4930, label %4977, label %4931

; <label>:4931                                    ; preds = %4924
  %4932 = fdiv fast float %10, %4897
  %4933 = fmul fast float %4932, %4889
  %4934 = fmul fast float %4932, %4890
  %4935 = fmul fast float %4932, %4891
  %4936 = fadd fast float %4933, %18
  %4937 = fadd fast float %4934, %19
  %4938 = fadd fast float %4935, %20
  %4939 = fadd fast float %4936, -9.000000e+02
  %4940 = fadd fast float %4937, -1.500000e+01
  %4941 = fadd fast float %4938, -7.500000e+02
  %4942 = fmul fast float %4939, 0x3F62345680000000
  %4943 = fmul fast float %4940, 0x3F62345680000000
  %4944 = fmul fast float %4941, 0x3F62345680000000
  %4945 = call float @dx.op.dot3.f32(i32 55, float %4942, float %4943, float %4944, float %4942, float %4943, float %4944)  ; Dot3(ax,ay,az,bx,by,bz)
  %4946 = fsub fast float 1.000000e+00, %4945
  %4947 = call float @dx.op.unary.f32(i32 7, float %4946)  ; Saturate(value)
  %4948 = fmul fast float %4947, %4947
  %4949 = fadd fast float %4936, %4886
  %4950 = fadd fast float %4937, %4887
  %4951 = fadd fast float %4938, %4888
  %4952 = fmul fast float %4949, 0x3F52345680000000
  %4953 = fadd fast float %4952, -2.000000e+00
  %4954 = fmul fast float %4950, 0x3F52345680000000
  %4955 = fadd fast float %4954, 0xBFA1111120000000
  %4956 = fmul fast float %4951, 0x3F52345680000000
  %4957 = fadd fast float %4956, 0xBFFAAAAAC0000000
  %4958 = call float @dx.op.dot3.f32(i32 55, float %4953, float %4955, float %4957, float %4953, float %4955, float %4957)  ; Dot3(ax,ay,az,bx,by,bz)
  %4959 = fsub fast float 1.000000e+00, %4958
  %4960 = call float @dx.op.unary.f32(i32 7, float %4959)  ; Saturate(value)
  %4961 = fmul fast float %4960, %4960
  %4962 = fmul fast float %4961, 4.000000e+00
  %4963 = fadd fast float %4962, %4948
  %4964 = fadd fast float %4886, -9.000000e+02
  %4965 = fadd fast float %4887, -1.500000e+01
  %4966 = fadd fast float %4888, -7.500000e+02
  %4967 = fmul fast float %4964, 0x3F62345680000000
  %4968 = fmul fast float %4965, 0x3F62345680000000
  %4969 = fmul fast float %4966, 0x3F62345680000000
  %4970 = call float @dx.op.dot3.f32(i32 55, float %4967, float %4968, float %4969, float %4967, float %4968, float %4969)  ; Dot3(ax,ay,az,bx,by,bz)
  %4971 = fsub fast float 1.000000e+00, %4970
  %4972 = call float @dx.op.unary.f32(i32 7, float %4971)  ; Saturate(value)
  %4973 = fmul fast float %4972, %4972
  %4974 = fadd fast float %4963, %4973
  %4975 = fmul fast float %4898, 0x3F25D867E0000000
  %4976 = fmul fast float %4975, %4974
  br label %4977

; <label>:4977                                    ; preds = %4931, %4924
  %4978 = phi float [ %4976, %4931 ], [ 0.000000e+00, %4924 ]
  %4979 = fadd fast float %4978, %4927
  %4980 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4979)  ; FMin(a,b)
  %4981 = fmul fast float %4980, 0xBFF7154760000000
  %4982 = call float @dx.op.unary.f32(i32 21, float %4981)  ; Exp(value)
  %4983 = fsub fast float 1.000000e+00, %4982
  %4984 = call float @dx.op.binary.f32(i32 36, float %13, float %4983)  ; FMin(a,b)
  %4985 = fsub fast float %14, %4845
  %4986 = fsub fast float %15, %4846
  %4987 = fsub fast float %16, %4847
  %4988 = fmul fast float %4984, %4985
  %4989 = fmul fast float %4984, %4986
  %4990 = fmul fast float %4984, %4987
  %4991 = fadd fast float %4988, %4845
  %4992 = fadd fast float %4989, %4846
  %4993 = fadd fast float %4990, %4847
  br label %4994

; <label>:4994                                    ; preds = %4977, %4856, %4852
  %4995 = phi float [ %4991, %4977 ], [ %4845, %4856 ], [ %4845, %4852 ]
  %4996 = phi float [ %4992, %4977 ], [ %4846, %4856 ], [ %4846, %4852 ]
  %4997 = phi float [ %4993, %4977 ], [ %4847, %4856 ], [ %4847, %4852 ]
  %4998 = fadd fast float %6, 1.000000e+00
  %4999 = fadd fast float %7, 1.000000e+00
  %5000 = fsub fast float 1.000000e+00, %6
  %5001 = fmul fast float %37, %4998
  %5002 = fmul fast float %37, %4999
  %5003 = fmul fast float %37, %5000
  %5004 = fmul fast float %5001, %4995
  %5005 = fmul fast float %5002, %4996
  %5006 = fmul fast float %5003, %4997
  %5007 = fcmp fast ult float %38, 5.000000e-01
  br i1 %5007, label %5033, label %5008

; <label>:5008                                    ; preds = %4994
  %5009 = fmul fast float %5004, 0x4004147AE0000000
  %5010 = fmul fast float %5005, 0x4004147AE0000000
  %5011 = fmul fast float %5006, 0x4004147AE0000000
  %5012 = fadd fast float %5009, 0x3F9EB851E0000000
  %5013 = fadd fast float %5010, 0x3F9EB851E0000000
  %5014 = fadd fast float %5011, 0x3F9EB851E0000000
  %5015 = fmul fast float %5012, %5004
  %5016 = fmul fast float %5013, %5005
  %5017 = fmul fast float %5014, %5006
  %5018 = fmul fast float %5004, 0x400370A3E0000000
  %5019 = fmul fast float %5005, 0x400370A3E0000000
  %5020 = fmul fast float %5006, 0x400370A3E0000000
  %5021 = fadd fast float %5018, 0x3FE2E147A0000000
  %5022 = fadd fast float %5019, 0x3FE2E147A0000000
  %5023 = fadd fast float %5020, 0x3FE2E147A0000000
  %5024 = fmul fast float %5021, %5004
  %5025 = fmul fast float %5022, %5005
  %5026 = fmul fast float %5023, %5006
  %5027 = fadd fast float %5024, 0x3FC1EB8520000000
  %5028 = fadd fast float %5025, 0x3FC1EB8520000000
  %5029 = fadd fast float %5026, 0x3FC1EB8520000000
  %5030 = fdiv fast float %5015, %5027
  %5031 = fdiv fast float %5016, %5028
  %5032 = fdiv fast float %5017, %5029
  br label %5033

; <label>:5033                                    ; preds = %5008, %4994
  %5034 = phi float [ %5030, %5008 ], [ %5004, %4994 ]
  %5035 = phi float [ %5031, %5008 ], [ %5005, %4994 ]
  %5036 = phi float [ %5032, %5008 ], [ %5006, %4994 ]
  %5037 = call float @dx.op.unary.f32(i32 7, float %5034)  ; Saturate(value)
  %5038 = call float @dx.op.unary.f32(i32 7, float %5035)  ; Saturate(value)
  %5039 = call float @dx.op.unary.f32(i32 7, float %5036)  ; Saturate(value)
  %5040 = call float @dx.op.dot3.f32(i32 55, float %5037, float %5038, float %5039, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5041 = fsub fast float %5037, %5040
  %5042 = fsub fast float %5038, %5040
  %5043 = fsub fast float %5039, %5040
  %5044 = fmul fast float %5041, %9
  %5045 = fmul fast float %5042, %9
  %5046 = fmul fast float %5043, %9
  %5047 = fadd fast float %5044, %5040
  %5048 = fadd fast float %5045, %5040
  %5049 = fadd fast float %5046, %5040
  %5050 = call float @dx.op.unary.f32(i32 7, float %5047)  ; Saturate(value)
  %5051 = call float @dx.op.unary.f32(i32 7, float %5048)  ; Saturate(value)
  %5052 = call float @dx.op.unary.f32(i32 7, float %5049)  ; Saturate(value)
  %5053 = fadd fast float %5050, 0xBFC70A3D80000000
  %5054 = fadd fast float %5051, 0xBFC70A3D80000000
  %5055 = fadd fast float %5052, 0xBFC70A3D80000000
  %5056 = fmul fast float %5053, %8
  %5057 = fmul fast float %5054, %8
  %5058 = fmul fast float %5055, %8
  %5059 = fadd fast float %5056, 0x3FC70A3D80000000
  %5060 = fadd fast float %5057, 0x3FC70A3D80000000
  %5061 = fadd fast float %5058, 0x3FC70A3D80000000
  %5062 = call float @dx.op.unary.f32(i32 7, float %5059)  ; Saturate(value)
  %5063 = call float @dx.op.unary.f32(i32 7, float %5060)  ; Saturate(value)
  %5064 = call float @dx.op.unary.f32(i32 7, float %5061)  ; Saturate(value)
  %5065 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %5065, label %5066, label %6325

; <label>:5066                                    ; preds = %5033
  %5067 = add i32 %71, -1
  %5068 = call i32 @dx.op.binary.i32(i32 37, i32 %68, i32 0)  ; IMax(a,b)
  %5069 = call i32 @dx.op.binary.i32(i32 37, i32 %5067, i32 0)  ; IMax(a,b)
  %5070 = call i32 @dx.op.binary.i32(i32 38, i32 %5068, i32 %60)  ; IMin(a,b)
  %5071 = call i32 @dx.op.binary.i32(i32 38, i32 %5069, i32 %61)  ; IMin(a,b)
  %5072 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5070, i32 %5071, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5073 = extractvalue %dx.types.ResRet.f32 %5072, 0
  %5074 = fsub fast float 1.000000e+00, %89
  %5075 = fmul fast float %5074, 0x3FA99999A0000000
  %5076 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %5075)  ; FMax(a,b)
  %5077 = fsub fast float %5073, %89
  %5078 = call float @dx.op.unary.f32(i32 6, float %5077)  ; FAbs(value)
  %5079 = fdiv fast float %5078, %5076
  %5080 = fsub fast float 1.000000e+00, %5079
  %5081 = call float @dx.op.unary.f32(i32 7, float %5080)  ; Saturate(value)
  %5082 = fcmp fast ugt float %5081, 0.000000e+00
  br i1 %5082, label %5083, label %5356

; <label>:5083                                    ; preds = %5066
  %5084 = call i32 @dx.op.binary.i32(i32 37, i32 %5070, i32 0)  ; IMax(a,b)
  %5085 = call i32 @dx.op.binary.i32(i32 37, i32 %5071, i32 0)  ; IMax(a,b)
  %5086 = call i32 @dx.op.binary.i32(i32 38, i32 %5084, i32 %60)  ; IMin(a,b)
  %5087 = call i32 @dx.op.binary.i32(i32 38, i32 %5085, i32 %61)  ; IMin(a,b)
  %5088 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %5086, i32 %5087, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5089 = extractvalue %dx.types.ResRet.f32 %5088, 0
  %5090 = extractvalue %dx.types.ResRet.f32 %5088, 1
  %5091 = extractvalue %dx.types.ResRet.f32 %5088, 2
  %5092 = extractvalue %dx.types.ResRet.f32 %5088, 3
  %5093 = fcmp fast olt float %5092, 0.000000e+00
  br i1 %5093, label %5094, label %5128

; <label>:5094                                    ; preds = %5083
  %5095 = fcmp fast ogt float %5089, 0x3FA4B5DCC0000000
  %5096 = fcmp fast ogt float %5090, 0x3FA4B5DCC0000000
  %5097 = fcmp fast ogt float %5091, 0x3FA4B5DCC0000000
  %5098 = select i1 %5095, float 0.000000e+00, float 1.000000e+00
  %5099 = select i1 %5096, float 0.000000e+00, float 1.000000e+00
  %5100 = select i1 %5097, float 0.000000e+00, float 1.000000e+00
  %5101 = fmul fast float %5089, 0x3FB3D07220000000
  %5102 = fmul fast float %5090, 0x3FB3D07220000000
  %5103 = fmul fast float %5091, 0x3FB3D07220000000
  %5104 = fadd fast float %5089, 0x3FAC28F5C0000000
  %5105 = fadd fast float %5090, 0x3FAC28F5C0000000
  %5106 = fadd fast float %5091, 0x3FAC28F5C0000000
  %5107 = fmul fast float %5104, 0x3FEE54EDE0000000
  %5108 = fmul fast float %5105, 0x3FEE54EDE0000000
  %5109 = fmul fast float %5106, 0x3FEE54EDE0000000
  %5110 = call float @dx.op.unary.f32(i32 23, float %5107)  ; Log(value)
  %5111 = call float @dx.op.unary.f32(i32 23, float %5108)  ; Log(value)
  %5112 = call float @dx.op.unary.f32(i32 23, float %5109)  ; Log(value)
  %5113 = fmul fast float %5110, 0x4003333340000000
  %5114 = fmul fast float %5111, 0x4003333340000000
  %5115 = fmul fast float %5112, 0x4003333340000000
  %5116 = call float @dx.op.unary.f32(i32 21, float %5113)  ; Exp(value)
  %5117 = call float @dx.op.unary.f32(i32 21, float %5114)  ; Exp(value)
  %5118 = call float @dx.op.unary.f32(i32 21, float %5115)  ; Exp(value)
  %5119 = fsub fast float %5101, %5116
  %5120 = fsub fast float %5102, %5117
  %5121 = fsub fast float %5103, %5118
  %5122 = fmul fast float %5119, %5098
  %5123 = fmul fast float %5120, %5099
  %5124 = fmul fast float %5121, %5100
  %5125 = fadd fast float %5122, %5116
  %5126 = fadd fast float %5123, %5117
  %5127 = fadd fast float %5124, %5118
  br label %5343

; <label>:5128                                    ; preds = %5083
  %5129 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5086, i32 %5087, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5130 = extractvalue %dx.types.ResRet.f32 %5129, 0
  %5131 = fcmp fast ogt float %39, 5.000000e-01
  %5132 = fcmp fast olt float %5130, 1.000000e+00
  %5133 = and i1 %5131, %5132
  br i1 %5133, label %5134, label %5272

; <label>:5134                                    ; preds = %5128
  %5135 = sitofp i32 %5086 to float
  %5136 = sitofp i32 %5087 to float
  %5137 = fadd fast float %5135, 5.000000e-01
  %5138 = fadd fast float %5136, 5.000000e-01
  %5139 = fdiv fast float %5137, %46
  %5140 = fdiv fast float %5138, %47
  %5141 = fmul fast float %5139, 2.000000e+00
  %5142 = fmul fast float %5140, 2.000000e+00
  %5143 = fadd fast float %5141, -1.000000e+00
  %5144 = fsub fast float 1.000000e+00, %5142
  %5145 = fmul fast float %5143, %36
  %5146 = call float @dx.op.tertiary.f32(i32 46, float %5144, float %32, float %5145)  ; FMad(a,b,c)
  %5147 = call float @dx.op.tertiary.f32(i32 46, float %5130, float %28, float %5146)  ; FMad(a,b,c)
  %5148 = fadd fast float %5147, %24
  %5149 = call float @dx.op.unary.f32(i32 6, float %5148)  ; FAbs(value)
  %5150 = fcmp fast ogt float %5149, 0x3EB0C6F7A0000000
  br i1 %5150, label %5151, label %5272

; <label>:5151                                    ; preds = %5134
  %5152 = fmul fast float %5143, %35
  %5153 = call float @dx.op.tertiary.f32(i32 46, float %5144, float %31, float %5152)  ; FMad(a,b,c)
  %5154 = call float @dx.op.tertiary.f32(i32 46, float %5130, float %27, float %5153)  ; FMad(a,b,c)
  %5155 = fadd fast float %5154, %23
  %5156 = fmul fast float %5143, %34
  %5157 = call float @dx.op.tertiary.f32(i32 46, float %5144, float %30, float %5156)  ; FMad(a,b,c)
  %5158 = call float @dx.op.tertiary.f32(i32 46, float %5130, float %26, float %5157)  ; FMad(a,b,c)
  %5159 = fadd fast float %5158, %22
  %5160 = fmul fast float %5143, %33
  %5161 = call float @dx.op.tertiary.f32(i32 46, float %5144, float %29, float %5160)  ; FMad(a,b,c)
  %5162 = call float @dx.op.tertiary.f32(i32 46, float %5130, float %25, float %5161)  ; FMad(a,b,c)
  %5163 = fadd fast float %5162, %21
  %5164 = fdiv fast float %5163, %5148
  %5165 = fdiv fast float %5159, %5148
  %5166 = fdiv fast float %5155, %5148
  %5167 = fsub fast float %5164, %18
  %5168 = fsub fast float %5165, %19
  %5169 = fsub fast float %5166, %20
  %5170 = fmul fast float %5167, %5167
  %5171 = fmul fast float %5168, %5168
  %5172 = fadd fast float %5171, %5170
  %5173 = fmul fast float %5169, %5169
  %5174 = fadd fast float %5172, %5173
  %5175 = call float @dx.op.unary.f32(i32 24, float %5174)  ; Sqrt(value)
  %5176 = fsub fast float %5175, %10
  %5177 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5176)  ; FMax(a,b)
  %5178 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %5178, label %5179, label %5202

; <label>:5179                                    ; preds = %5151
  %5180 = call float @dx.op.unary.f32(i32 6, float %5168)  ; FAbs(value)
  %5181 = fmul fast float %5180, %12
  %5182 = fcmp fast olt float %5181, 0x3F50624DE0000000
  br i1 %5182, label %5183, label %5186

; <label>:5183                                    ; preds = %5179
  %5184 = fmul fast float %5181, 5.000000e-01
  %5185 = fsub fast float 1.000000e+00, %5184
  br label %5191

; <label>:5186                                    ; preds = %5179
  %5187 = fmul fast float %5181, 0xBFF7154760000000
  %5188 = call float @dx.op.unary.f32(i32 21, float %5187)  ; Exp(value)
  %5189 = fsub fast float 1.000000e+00, %5188
  %5190 = fdiv fast float %5189, %5181
  br label %5191

; <label>:5191                                    ; preds = %5186, %5183
  %5192 = phi float [ %5185, %5183 ], [ %5190, %5186 ]
  %5193 = call float @dx.op.binary.f32(i32 36, float %5165, float %19)  ; FMin(a,b)
  %5194 = fsub fast float %5193, %11
  %5195 = fmul fast float %12, %5194
  %5196 = fsub fast float -0.000000e+00, %5195
  %5197 = call float @dx.op.binary.f32(i32 35, float %5196, float -4.000000e+01)  ; FMax(a,b)
  %5198 = call float @dx.op.binary.f32(i32 36, float %5197, float 5.000000e+00)  ; FMin(a,b)
  %5199 = fmul fast float %5198, 0x3FF7154760000000
  %5200 = call float @dx.op.unary.f32(i32 21, float %5199)  ; Exp(value)
  %5201 = fmul fast float %5200, %5192
  br label %5202

; <label>:5202                                    ; preds = %5191, %5151
  %5203 = phi float [ %5201, %5191 ], [ 1.000000e+00, %5151 ]
  %5204 = fmul fast float %5177, %17
  %5205 = fmul fast float %5204, %5203
  %5206 = fcmp fast ole float %5175, %10
  %5207 = fcmp fast olt float %5175, 0x3F1A36E2E0000000
  %5208 = or i1 %5206, %5207
  br i1 %5208, label %5255, label %5209

; <label>:5209                                    ; preds = %5202
  %5210 = fdiv fast float %10, %5175
  %5211 = fmul fast float %5210, %5167
  %5212 = fmul fast float %5210, %5168
  %5213 = fmul fast float %5210, %5169
  %5214 = fadd fast float %5211, %18
  %5215 = fadd fast float %5212, %19
  %5216 = fadd fast float %5213, %20
  %5217 = fadd fast float %5214, -9.000000e+02
  %5218 = fadd fast float %5215, -1.500000e+01
  %5219 = fadd fast float %5216, -7.500000e+02
  %5220 = fmul fast float %5217, 0x3F62345680000000
  %5221 = fmul fast float %5218, 0x3F62345680000000
  %5222 = fmul fast float %5219, 0x3F62345680000000
  %5223 = call float @dx.op.dot3.f32(i32 55, float %5220, float %5221, float %5222, float %5220, float %5221, float %5222)  ; Dot3(ax,ay,az,bx,by,bz)
  %5224 = fsub fast float 1.000000e+00, %5223
  %5225 = call float @dx.op.unary.f32(i32 7, float %5224)  ; Saturate(value)
  %5226 = fmul fast float %5225, %5225
  %5227 = fadd fast float %5214, %5164
  %5228 = fadd fast float %5215, %5165
  %5229 = fadd fast float %5216, %5166
  %5230 = fmul fast float %5227, 0x3F52345680000000
  %5231 = fadd fast float %5230, -2.000000e+00
  %5232 = fmul fast float %5228, 0x3F52345680000000
  %5233 = fadd fast float %5232, 0xBFA1111120000000
  %5234 = fmul fast float %5229, 0x3F52345680000000
  %5235 = fadd fast float %5234, 0xBFFAAAAAC0000000
  %5236 = call float @dx.op.dot3.f32(i32 55, float %5231, float %5233, float %5235, float %5231, float %5233, float %5235)  ; Dot3(ax,ay,az,bx,by,bz)
  %5237 = fsub fast float 1.000000e+00, %5236
  %5238 = call float @dx.op.unary.f32(i32 7, float %5237)  ; Saturate(value)
  %5239 = fmul fast float %5238, %5238
  %5240 = fmul fast float %5239, 4.000000e+00
  %5241 = fadd fast float %5240, %5226
  %5242 = fadd fast float %5164, -9.000000e+02
  %5243 = fadd fast float %5165, -1.500000e+01
  %5244 = fadd fast float %5166, -7.500000e+02
  %5245 = fmul fast float %5242, 0x3F62345680000000
  %5246 = fmul fast float %5243, 0x3F62345680000000
  %5247 = fmul fast float %5244, 0x3F62345680000000
  %5248 = call float @dx.op.dot3.f32(i32 55, float %5245, float %5246, float %5247, float %5245, float %5246, float %5247)  ; Dot3(ax,ay,az,bx,by,bz)
  %5249 = fsub fast float 1.000000e+00, %5248
  %5250 = call float @dx.op.unary.f32(i32 7, float %5249)  ; Saturate(value)
  %5251 = fmul fast float %5250, %5250
  %5252 = fadd fast float %5241, %5251
  %5253 = fmul fast float %5176, 0x3F25D867E0000000
  %5254 = fmul fast float %5253, %5252
  br label %5255

; <label>:5255                                    ; preds = %5209, %5202
  %5256 = phi float [ %5254, %5209 ], [ 0.000000e+00, %5202 ]
  %5257 = fadd fast float %5256, %5205
  %5258 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %5257)  ; FMin(a,b)
  %5259 = fmul fast float %5258, 0xBFF7154760000000
  %5260 = call float @dx.op.unary.f32(i32 21, float %5259)  ; Exp(value)
  %5261 = fsub fast float 1.000000e+00, %5260
  %5262 = call float @dx.op.binary.f32(i32 36, float %13, float %5261)  ; FMin(a,b)
  %5263 = fsub fast float %14, %5089
  %5264 = fsub fast float %15, %5090
  %5265 = fsub fast float %16, %5091
  %5266 = fmul fast float %5262, %5263
  %5267 = fmul fast float %5262, %5264
  %5268 = fmul fast float %5262, %5265
  %5269 = fadd fast float %5266, %5089
  %5270 = fadd fast float %5267, %5090
  %5271 = fadd fast float %5268, %5091
  br label %5272

; <label>:5272                                    ; preds = %5255, %5134, %5128
  %5273 = phi float [ %5269, %5255 ], [ %5089, %5134 ], [ %5089, %5128 ]
  %5274 = phi float [ %5270, %5255 ], [ %5090, %5134 ], [ %5090, %5128 ]
  %5275 = phi float [ %5271, %5255 ], [ %5091, %5134 ], [ %5091, %5128 ]
  %5276 = fadd fast float %6, 1.000000e+00
  %5277 = fadd fast float %7, 1.000000e+00
  %5278 = fsub fast float 1.000000e+00, %6
  %5279 = fmul fast float %37, %5276
  %5280 = fmul fast float %37, %5277
  %5281 = fmul fast float %37, %5278
  %5282 = fmul fast float %5279, %5273
  %5283 = fmul fast float %5280, %5274
  %5284 = fmul fast float %5281, %5275
  %5285 = fcmp fast ult float %38, 5.000000e-01
  br i1 %5285, label %5311, label %5286

; <label>:5286                                    ; preds = %5272
  %5287 = fmul fast float %5282, 0x4004147AE0000000
  %5288 = fmul fast float %5283, 0x4004147AE0000000
  %5289 = fmul fast float %5284, 0x4004147AE0000000
  %5290 = fadd fast float %5287, 0x3F9EB851E0000000
  %5291 = fadd fast float %5288, 0x3F9EB851E0000000
  %5292 = fadd fast float %5289, 0x3F9EB851E0000000
  %5293 = fmul fast float %5290, %5282
  %5294 = fmul fast float %5291, %5283
  %5295 = fmul fast float %5292, %5284
  %5296 = fmul fast float %5282, 0x400370A3E0000000
  %5297 = fmul fast float %5283, 0x400370A3E0000000
  %5298 = fmul fast float %5284, 0x400370A3E0000000
  %5299 = fadd fast float %5296, 0x3FE2E147A0000000
  %5300 = fadd fast float %5297, 0x3FE2E147A0000000
  %5301 = fadd fast float %5298, 0x3FE2E147A0000000
  %5302 = fmul fast float %5299, %5282
  %5303 = fmul fast float %5300, %5283
  %5304 = fmul fast float %5301, %5284
  %5305 = fadd fast float %5302, 0x3FC1EB8520000000
  %5306 = fadd fast float %5303, 0x3FC1EB8520000000
  %5307 = fadd fast float %5304, 0x3FC1EB8520000000
  %5308 = fdiv fast float %5293, %5305
  %5309 = fdiv fast float %5294, %5306
  %5310 = fdiv fast float %5295, %5307
  br label %5311

; <label>:5311                                    ; preds = %5286, %5272
  %5312 = phi float [ %5308, %5286 ], [ %5282, %5272 ]
  %5313 = phi float [ %5309, %5286 ], [ %5283, %5272 ]
  %5314 = phi float [ %5310, %5286 ], [ %5284, %5272 ]
  %5315 = call float @dx.op.unary.f32(i32 7, float %5312)  ; Saturate(value)
  %5316 = call float @dx.op.unary.f32(i32 7, float %5313)  ; Saturate(value)
  %5317 = call float @dx.op.unary.f32(i32 7, float %5314)  ; Saturate(value)
  %5318 = call float @dx.op.dot3.f32(i32 55, float %5315, float %5316, float %5317, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5319 = fsub fast float %5315, %5318
  %5320 = fsub fast float %5316, %5318
  %5321 = fsub fast float %5317, %5318
  %5322 = fmul fast float %5319, %9
  %5323 = fmul fast float %5320, %9
  %5324 = fmul fast float %5321, %9
  %5325 = fadd fast float %5322, %5318
  %5326 = fadd fast float %5323, %5318
  %5327 = fadd fast float %5324, %5318
  %5328 = call float @dx.op.unary.f32(i32 7, float %5325)  ; Saturate(value)
  %5329 = call float @dx.op.unary.f32(i32 7, float %5326)  ; Saturate(value)
  %5330 = call float @dx.op.unary.f32(i32 7, float %5327)  ; Saturate(value)
  %5331 = fadd fast float %5328, 0xBFC70A3D80000000
  %5332 = fadd fast float %5329, 0xBFC70A3D80000000
  %5333 = fadd fast float %5330, 0xBFC70A3D80000000
  %5334 = fmul fast float %5331, %8
  %5335 = fmul fast float %5332, %8
  %5336 = fmul fast float %5333, %8
  %5337 = fadd fast float %5334, 0x3FC70A3D80000000
  %5338 = fadd fast float %5335, 0x3FC70A3D80000000
  %5339 = fadd fast float %5336, 0x3FC70A3D80000000
  %5340 = call float @dx.op.unary.f32(i32 7, float %5337)  ; Saturate(value)
  %5341 = call float @dx.op.unary.f32(i32 7, float %5338)  ; Saturate(value)
  %5342 = call float @dx.op.unary.f32(i32 7, float %5339)  ; Saturate(value)
  br label %5343

; <label>:5343                                    ; preds = %5311, %5094
  %5344 = phi float [ %5125, %5094 ], [ %5340, %5311 ]
  %5345 = phi float [ %5126, %5094 ], [ %5341, %5311 ]
  %5346 = phi float [ %5127, %5094 ], [ %5342, %5311 ]
  %5347 = fsub fast float %5344, %5062
  %5348 = fsub fast float %5345, %5063
  %5349 = fsub fast float %5346, %5064
  %5350 = fmul fast float %5347, %5081
  %5351 = fmul fast float %5348, %5081
  %5352 = fmul fast float %5349, %5081
  %5353 = fadd fast float %5350, %5062
  %5354 = fadd fast float %5351, %5063
  %5355 = fadd fast float %5352, %5064
  br label %5356

; <label>:5356                                    ; preds = %5343, %5066
  %5357 = phi float [ %5353, %5343 ], [ %5062, %5066 ]
  %5358 = phi float [ %5354, %5343 ], [ %5063, %5066 ]
  %5359 = phi float [ %5355, %5343 ], [ %5064, %5066 ]
  %5360 = add i32 %71, 1
  %5361 = call i32 @dx.op.binary.i32(i32 37, i32 %5360, i32 0)  ; IMax(a,b)
  %5362 = call i32 @dx.op.binary.i32(i32 38, i32 %5361, i32 %61)  ; IMin(a,b)
  %5363 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5070, i32 %5362, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5364 = extractvalue %dx.types.ResRet.f32 %5363, 0
  %5365 = fsub fast float %5364, %89
  %5366 = call float @dx.op.unary.f32(i32 6, float %5365)  ; FAbs(value)
  %5367 = fdiv fast float %5366, %5076
  %5368 = fsub fast float 1.000000e+00, %5367
  %5369 = call float @dx.op.unary.f32(i32 7, float %5368)  ; Saturate(value)
  %5370 = fcmp fast ugt float %5369, 0.000000e+00
  br i1 %5370, label %5371, label %5644

; <label>:5371                                    ; preds = %5356
  %5372 = call i32 @dx.op.binary.i32(i32 37, i32 %5070, i32 0)  ; IMax(a,b)
  %5373 = call i32 @dx.op.binary.i32(i32 37, i32 %5362, i32 0)  ; IMax(a,b)
  %5374 = call i32 @dx.op.binary.i32(i32 38, i32 %5372, i32 %60)  ; IMin(a,b)
  %5375 = call i32 @dx.op.binary.i32(i32 38, i32 %5373, i32 %61)  ; IMin(a,b)
  %5376 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %5374, i32 %5375, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5377 = extractvalue %dx.types.ResRet.f32 %5376, 0
  %5378 = extractvalue %dx.types.ResRet.f32 %5376, 1
  %5379 = extractvalue %dx.types.ResRet.f32 %5376, 2
  %5380 = extractvalue %dx.types.ResRet.f32 %5376, 3
  %5381 = fcmp fast olt float %5380, 0.000000e+00
  br i1 %5381, label %5382, label %5416

; <label>:5382                                    ; preds = %5371
  %5383 = fcmp fast ogt float %5377, 0x3FA4B5DCC0000000
  %5384 = fcmp fast ogt float %5378, 0x3FA4B5DCC0000000
  %5385 = fcmp fast ogt float %5379, 0x3FA4B5DCC0000000
  %5386 = select i1 %5383, float 0.000000e+00, float 1.000000e+00
  %5387 = select i1 %5384, float 0.000000e+00, float 1.000000e+00
  %5388 = select i1 %5385, float 0.000000e+00, float 1.000000e+00
  %5389 = fmul fast float %5377, 0x3FB3D07220000000
  %5390 = fmul fast float %5378, 0x3FB3D07220000000
  %5391 = fmul fast float %5379, 0x3FB3D07220000000
  %5392 = fadd fast float %5377, 0x3FAC28F5C0000000
  %5393 = fadd fast float %5378, 0x3FAC28F5C0000000
  %5394 = fadd fast float %5379, 0x3FAC28F5C0000000
  %5395 = fmul fast float %5392, 0x3FEE54EDE0000000
  %5396 = fmul fast float %5393, 0x3FEE54EDE0000000
  %5397 = fmul fast float %5394, 0x3FEE54EDE0000000
  %5398 = call float @dx.op.unary.f32(i32 23, float %5395)  ; Log(value)
  %5399 = call float @dx.op.unary.f32(i32 23, float %5396)  ; Log(value)
  %5400 = call float @dx.op.unary.f32(i32 23, float %5397)  ; Log(value)
  %5401 = fmul fast float %5398, 0x4003333340000000
  %5402 = fmul fast float %5399, 0x4003333340000000
  %5403 = fmul fast float %5400, 0x4003333340000000
  %5404 = call float @dx.op.unary.f32(i32 21, float %5401)  ; Exp(value)
  %5405 = call float @dx.op.unary.f32(i32 21, float %5402)  ; Exp(value)
  %5406 = call float @dx.op.unary.f32(i32 21, float %5403)  ; Exp(value)
  %5407 = fsub fast float %5389, %5404
  %5408 = fsub fast float %5390, %5405
  %5409 = fsub fast float %5391, %5406
  %5410 = fmul fast float %5407, %5386
  %5411 = fmul fast float %5408, %5387
  %5412 = fmul fast float %5409, %5388
  %5413 = fadd fast float %5410, %5404
  %5414 = fadd fast float %5411, %5405
  %5415 = fadd fast float %5412, %5406
  br label %5631

; <label>:5416                                    ; preds = %5371
  %5417 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5374, i32 %5375, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5418 = extractvalue %dx.types.ResRet.f32 %5417, 0
  %5419 = fcmp fast ogt float %39, 5.000000e-01
  %5420 = fcmp fast olt float %5418, 1.000000e+00
  %5421 = and i1 %5419, %5420
  br i1 %5421, label %5422, label %5560

; <label>:5422                                    ; preds = %5416
  %5423 = sitofp i32 %5374 to float
  %5424 = sitofp i32 %5375 to float
  %5425 = fadd fast float %5423, 5.000000e-01
  %5426 = fadd fast float %5424, 5.000000e-01
  %5427 = fdiv fast float %5425, %46
  %5428 = fdiv fast float %5426, %47
  %5429 = fmul fast float %5427, 2.000000e+00
  %5430 = fmul fast float %5428, 2.000000e+00
  %5431 = fadd fast float %5429, -1.000000e+00
  %5432 = fsub fast float 1.000000e+00, %5430
  %5433 = fmul fast float %5431, %36
  %5434 = call float @dx.op.tertiary.f32(i32 46, float %5432, float %32, float %5433)  ; FMad(a,b,c)
  %5435 = call float @dx.op.tertiary.f32(i32 46, float %5418, float %28, float %5434)  ; FMad(a,b,c)
  %5436 = fadd fast float %5435, %24
  %5437 = call float @dx.op.unary.f32(i32 6, float %5436)  ; FAbs(value)
  %5438 = fcmp fast ogt float %5437, 0x3EB0C6F7A0000000
  br i1 %5438, label %5439, label %5560

; <label>:5439                                    ; preds = %5422
  %5440 = fmul fast float %5431, %35
  %5441 = call float @dx.op.tertiary.f32(i32 46, float %5432, float %31, float %5440)  ; FMad(a,b,c)
  %5442 = call float @dx.op.tertiary.f32(i32 46, float %5418, float %27, float %5441)  ; FMad(a,b,c)
  %5443 = fadd fast float %5442, %23
  %5444 = fmul fast float %5431, %34
  %5445 = call float @dx.op.tertiary.f32(i32 46, float %5432, float %30, float %5444)  ; FMad(a,b,c)
  %5446 = call float @dx.op.tertiary.f32(i32 46, float %5418, float %26, float %5445)  ; FMad(a,b,c)
  %5447 = fadd fast float %5446, %22
  %5448 = fmul fast float %5431, %33
  %5449 = call float @dx.op.tertiary.f32(i32 46, float %5432, float %29, float %5448)  ; FMad(a,b,c)
  %5450 = call float @dx.op.tertiary.f32(i32 46, float %5418, float %25, float %5449)  ; FMad(a,b,c)
  %5451 = fadd fast float %5450, %21
  %5452 = fdiv fast float %5451, %5436
  %5453 = fdiv fast float %5447, %5436
  %5454 = fdiv fast float %5443, %5436
  %5455 = fsub fast float %5452, %18
  %5456 = fsub fast float %5453, %19
  %5457 = fsub fast float %5454, %20
  %5458 = fmul fast float %5455, %5455
  %5459 = fmul fast float %5456, %5456
  %5460 = fadd fast float %5459, %5458
  %5461 = fmul fast float %5457, %5457
  %5462 = fadd fast float %5460, %5461
  %5463 = call float @dx.op.unary.f32(i32 24, float %5462)  ; Sqrt(value)
  %5464 = fsub fast float %5463, %10
  %5465 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5464)  ; FMax(a,b)
  %5466 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %5466, label %5467, label %5490

; <label>:5467                                    ; preds = %5439
  %5468 = call float @dx.op.unary.f32(i32 6, float %5456)  ; FAbs(value)
  %5469 = fmul fast float %5468, %12
  %5470 = fcmp fast olt float %5469, 0x3F50624DE0000000
  br i1 %5470, label %5471, label %5474

; <label>:5471                                    ; preds = %5467
  %5472 = fmul fast float %5469, 5.000000e-01
  %5473 = fsub fast float 1.000000e+00, %5472
  br label %5479

; <label>:5474                                    ; preds = %5467
  %5475 = fmul fast float %5469, 0xBFF7154760000000
  %5476 = call float @dx.op.unary.f32(i32 21, float %5475)  ; Exp(value)
  %5477 = fsub fast float 1.000000e+00, %5476
  %5478 = fdiv fast float %5477, %5469
  br label %5479

; <label>:5479                                    ; preds = %5474, %5471
  %5480 = phi float [ %5473, %5471 ], [ %5478, %5474 ]
  %5481 = call float @dx.op.binary.f32(i32 36, float %5453, float %19)  ; FMin(a,b)
  %5482 = fsub fast float %5481, %11
  %5483 = fmul fast float %12, %5482
  %5484 = fsub fast float -0.000000e+00, %5483
  %5485 = call float @dx.op.binary.f32(i32 35, float %5484, float -4.000000e+01)  ; FMax(a,b)
  %5486 = call float @dx.op.binary.f32(i32 36, float %5485, float 5.000000e+00)  ; FMin(a,b)
  %5487 = fmul fast float %5486, 0x3FF7154760000000
  %5488 = call float @dx.op.unary.f32(i32 21, float %5487)  ; Exp(value)
  %5489 = fmul fast float %5488, %5480
  br label %5490

; <label>:5490                                    ; preds = %5479, %5439
  %5491 = phi float [ %5489, %5479 ], [ 1.000000e+00, %5439 ]
  %5492 = fmul fast float %5465, %17
  %5493 = fmul fast float %5492, %5491
  %5494 = fcmp fast ole float %5463, %10
  %5495 = fcmp fast olt float %5463, 0x3F1A36E2E0000000
  %5496 = or i1 %5494, %5495
  br i1 %5496, label %5543, label %5497

; <label>:5497                                    ; preds = %5490
  %5498 = fdiv fast float %10, %5463
  %5499 = fmul fast float %5498, %5455
  %5500 = fmul fast float %5498, %5456
  %5501 = fmul fast float %5498, %5457
  %5502 = fadd fast float %5499, %18
  %5503 = fadd fast float %5500, %19
  %5504 = fadd fast float %5501, %20
  %5505 = fadd fast float %5502, -9.000000e+02
  %5506 = fadd fast float %5503, -1.500000e+01
  %5507 = fadd fast float %5504, -7.500000e+02
  %5508 = fmul fast float %5505, 0x3F62345680000000
  %5509 = fmul fast float %5506, 0x3F62345680000000
  %5510 = fmul fast float %5507, 0x3F62345680000000
  %5511 = call float @dx.op.dot3.f32(i32 55, float %5508, float %5509, float %5510, float %5508, float %5509, float %5510)  ; Dot3(ax,ay,az,bx,by,bz)
  %5512 = fsub fast float 1.000000e+00, %5511
  %5513 = call float @dx.op.unary.f32(i32 7, float %5512)  ; Saturate(value)
  %5514 = fmul fast float %5513, %5513
  %5515 = fadd fast float %5502, %5452
  %5516 = fadd fast float %5503, %5453
  %5517 = fadd fast float %5504, %5454
  %5518 = fmul fast float %5515, 0x3F52345680000000
  %5519 = fadd fast float %5518, -2.000000e+00
  %5520 = fmul fast float %5516, 0x3F52345680000000
  %5521 = fadd fast float %5520, 0xBFA1111120000000
  %5522 = fmul fast float %5517, 0x3F52345680000000
  %5523 = fadd fast float %5522, 0xBFFAAAAAC0000000
  %5524 = call float @dx.op.dot3.f32(i32 55, float %5519, float %5521, float %5523, float %5519, float %5521, float %5523)  ; Dot3(ax,ay,az,bx,by,bz)
  %5525 = fsub fast float 1.000000e+00, %5524
  %5526 = call float @dx.op.unary.f32(i32 7, float %5525)  ; Saturate(value)
  %5527 = fmul fast float %5526, %5526
  %5528 = fmul fast float %5527, 4.000000e+00
  %5529 = fadd fast float %5528, %5514
  %5530 = fadd fast float %5452, -9.000000e+02
  %5531 = fadd fast float %5453, -1.500000e+01
  %5532 = fadd fast float %5454, -7.500000e+02
  %5533 = fmul fast float %5530, 0x3F62345680000000
  %5534 = fmul fast float %5531, 0x3F62345680000000
  %5535 = fmul fast float %5532, 0x3F62345680000000
  %5536 = call float @dx.op.dot3.f32(i32 55, float %5533, float %5534, float %5535, float %5533, float %5534, float %5535)  ; Dot3(ax,ay,az,bx,by,bz)
  %5537 = fsub fast float 1.000000e+00, %5536
  %5538 = call float @dx.op.unary.f32(i32 7, float %5537)  ; Saturate(value)
  %5539 = fmul fast float %5538, %5538
  %5540 = fadd fast float %5529, %5539
  %5541 = fmul fast float %5464, 0x3F25D867E0000000
  %5542 = fmul fast float %5541, %5540
  br label %5543

; <label>:5543                                    ; preds = %5497, %5490
  %5544 = phi float [ %5542, %5497 ], [ 0.000000e+00, %5490 ]
  %5545 = fadd fast float %5544, %5493
  %5546 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %5545)  ; FMin(a,b)
  %5547 = fmul fast float %5546, 0xBFF7154760000000
  %5548 = call float @dx.op.unary.f32(i32 21, float %5547)  ; Exp(value)
  %5549 = fsub fast float 1.000000e+00, %5548
  %5550 = call float @dx.op.binary.f32(i32 36, float %13, float %5549)  ; FMin(a,b)
  %5551 = fsub fast float %14, %5377
  %5552 = fsub fast float %15, %5378
  %5553 = fsub fast float %16, %5379
  %5554 = fmul fast float %5550, %5551
  %5555 = fmul fast float %5550, %5552
  %5556 = fmul fast float %5550, %5553
  %5557 = fadd fast float %5554, %5377
  %5558 = fadd fast float %5555, %5378
  %5559 = fadd fast float %5556, %5379
  br label %5560

; <label>:5560                                    ; preds = %5543, %5422, %5416
  %5561 = phi float [ %5557, %5543 ], [ %5377, %5422 ], [ %5377, %5416 ]
  %5562 = phi float [ %5558, %5543 ], [ %5378, %5422 ], [ %5378, %5416 ]
  %5563 = phi float [ %5559, %5543 ], [ %5379, %5422 ], [ %5379, %5416 ]
  %5564 = fadd fast float %6, 1.000000e+00
  %5565 = fadd fast float %7, 1.000000e+00
  %5566 = fsub fast float 1.000000e+00, %6
  %5567 = fmul fast float %37, %5564
  %5568 = fmul fast float %37, %5565
  %5569 = fmul fast float %37, %5566
  %5570 = fmul fast float %5567, %5561
  %5571 = fmul fast float %5568, %5562
  %5572 = fmul fast float %5569, %5563
  %5573 = fcmp fast ult float %38, 5.000000e-01
  br i1 %5573, label %5599, label %5574

; <label>:5574                                    ; preds = %5560
  %5575 = fmul fast float %5570, 0x4004147AE0000000
  %5576 = fmul fast float %5571, 0x4004147AE0000000
  %5577 = fmul fast float %5572, 0x4004147AE0000000
  %5578 = fadd fast float %5575, 0x3F9EB851E0000000
  %5579 = fadd fast float %5576, 0x3F9EB851E0000000
  %5580 = fadd fast float %5577, 0x3F9EB851E0000000
  %5581 = fmul fast float %5578, %5570
  %5582 = fmul fast float %5579, %5571
  %5583 = fmul fast float %5580, %5572
  %5584 = fmul fast float %5570, 0x400370A3E0000000
  %5585 = fmul fast float %5571, 0x400370A3E0000000
  %5586 = fmul fast float %5572, 0x400370A3E0000000
  %5587 = fadd fast float %5584, 0x3FE2E147A0000000
  %5588 = fadd fast float %5585, 0x3FE2E147A0000000
  %5589 = fadd fast float %5586, 0x3FE2E147A0000000
  %5590 = fmul fast float %5587, %5570
  %5591 = fmul fast float %5588, %5571
  %5592 = fmul fast float %5589, %5572
  %5593 = fadd fast float %5590, 0x3FC1EB8520000000
  %5594 = fadd fast float %5591, 0x3FC1EB8520000000
  %5595 = fadd fast float %5592, 0x3FC1EB8520000000
  %5596 = fdiv fast float %5581, %5593
  %5597 = fdiv fast float %5582, %5594
  %5598 = fdiv fast float %5583, %5595
  br label %5599

; <label>:5599                                    ; preds = %5574, %5560
  %5600 = phi float [ %5596, %5574 ], [ %5570, %5560 ]
  %5601 = phi float [ %5597, %5574 ], [ %5571, %5560 ]
  %5602 = phi float [ %5598, %5574 ], [ %5572, %5560 ]
  %5603 = call float @dx.op.unary.f32(i32 7, float %5600)  ; Saturate(value)
  %5604 = call float @dx.op.unary.f32(i32 7, float %5601)  ; Saturate(value)
  %5605 = call float @dx.op.unary.f32(i32 7, float %5602)  ; Saturate(value)
  %5606 = call float @dx.op.dot3.f32(i32 55, float %5603, float %5604, float %5605, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5607 = fsub fast float %5603, %5606
  %5608 = fsub fast float %5604, %5606
  %5609 = fsub fast float %5605, %5606
  %5610 = fmul fast float %5607, %9
  %5611 = fmul fast float %5608, %9
  %5612 = fmul fast float %5609, %9
  %5613 = fadd fast float %5610, %5606
  %5614 = fadd fast float %5611, %5606
  %5615 = fadd fast float %5612, %5606
  %5616 = call float @dx.op.unary.f32(i32 7, float %5613)  ; Saturate(value)
  %5617 = call float @dx.op.unary.f32(i32 7, float %5614)  ; Saturate(value)
  %5618 = call float @dx.op.unary.f32(i32 7, float %5615)  ; Saturate(value)
  %5619 = fadd fast float %5616, 0xBFC70A3D80000000
  %5620 = fadd fast float %5617, 0xBFC70A3D80000000
  %5621 = fadd fast float %5618, 0xBFC70A3D80000000
  %5622 = fmul fast float %5619, %8
  %5623 = fmul fast float %5620, %8
  %5624 = fmul fast float %5621, %8
  %5625 = fadd fast float %5622, 0x3FC70A3D80000000
  %5626 = fadd fast float %5623, 0x3FC70A3D80000000
  %5627 = fadd fast float %5624, 0x3FC70A3D80000000
  %5628 = call float @dx.op.unary.f32(i32 7, float %5625)  ; Saturate(value)
  %5629 = call float @dx.op.unary.f32(i32 7, float %5626)  ; Saturate(value)
  %5630 = call float @dx.op.unary.f32(i32 7, float %5627)  ; Saturate(value)
  br label %5631

; <label>:5631                                    ; preds = %5599, %5382
  %5632 = phi float [ %5413, %5382 ], [ %5628, %5599 ]
  %5633 = phi float [ %5414, %5382 ], [ %5629, %5599 ]
  %5634 = phi float [ %5415, %5382 ], [ %5630, %5599 ]
  %5635 = fsub fast float %5632, %5062
  %5636 = fsub fast float %5633, %5063
  %5637 = fsub fast float %5634, %5064
  %5638 = fmul fast float %5635, %5369
  %5639 = fmul fast float %5636, %5369
  %5640 = fmul fast float %5637, %5369
  %5641 = fadd fast float %5638, %5062
  %5642 = fadd fast float %5639, %5063
  %5643 = fadd fast float %5640, %5064
  br label %5644

; <label>:5644                                    ; preds = %5631, %5356
  %5645 = phi float [ %5641, %5631 ], [ %5062, %5356 ]
  %5646 = phi float [ %5642, %5631 ], [ %5063, %5356 ]
  %5647 = phi float [ %5643, %5631 ], [ %5064, %5356 ]
  %5648 = add i32 %68, -1
  %5649 = call i32 @dx.op.binary.i32(i32 37, i32 %5648, i32 0)  ; IMax(a,b)
  %5650 = call i32 @dx.op.binary.i32(i32 37, i32 %71, i32 0)  ; IMax(a,b)
  %5651 = call i32 @dx.op.binary.i32(i32 38, i32 %5649, i32 %60)  ; IMin(a,b)
  %5652 = call i32 @dx.op.binary.i32(i32 38, i32 %5650, i32 %61)  ; IMin(a,b)
  %5653 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5651, i32 %5652, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5654 = extractvalue %dx.types.ResRet.f32 %5653, 0
  %5655 = fsub fast float %5654, %89
  %5656 = call float @dx.op.unary.f32(i32 6, float %5655)  ; FAbs(value)
  %5657 = fdiv fast float %5656, %5076
  %5658 = fsub fast float 1.000000e+00, %5657
  %5659 = call float @dx.op.unary.f32(i32 7, float %5658)  ; Saturate(value)
  %5660 = fcmp fast ugt float %5659, 0.000000e+00
  br i1 %5660, label %5661, label %5934

; <label>:5661                                    ; preds = %5644
  %5662 = call i32 @dx.op.binary.i32(i32 37, i32 %5651, i32 0)  ; IMax(a,b)
  %5663 = call i32 @dx.op.binary.i32(i32 37, i32 %5652, i32 0)  ; IMax(a,b)
  %5664 = call i32 @dx.op.binary.i32(i32 38, i32 %5662, i32 %60)  ; IMin(a,b)
  %5665 = call i32 @dx.op.binary.i32(i32 38, i32 %5663, i32 %61)  ; IMin(a,b)
  %5666 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %5664, i32 %5665, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5667 = extractvalue %dx.types.ResRet.f32 %5666, 0
  %5668 = extractvalue %dx.types.ResRet.f32 %5666, 1
  %5669 = extractvalue %dx.types.ResRet.f32 %5666, 2
  %5670 = extractvalue %dx.types.ResRet.f32 %5666, 3
  %5671 = fcmp fast olt float %5670, 0.000000e+00
  br i1 %5671, label %5672, label %5706

; <label>:5672                                    ; preds = %5661
  %5673 = fcmp fast ogt float %5667, 0x3FA4B5DCC0000000
  %5674 = fcmp fast ogt float %5668, 0x3FA4B5DCC0000000
  %5675 = fcmp fast ogt float %5669, 0x3FA4B5DCC0000000
  %5676 = select i1 %5673, float 0.000000e+00, float 1.000000e+00
  %5677 = select i1 %5674, float 0.000000e+00, float 1.000000e+00
  %5678 = select i1 %5675, float 0.000000e+00, float 1.000000e+00
  %5679 = fmul fast float %5667, 0x3FB3D07220000000
  %5680 = fmul fast float %5668, 0x3FB3D07220000000
  %5681 = fmul fast float %5669, 0x3FB3D07220000000
  %5682 = fadd fast float %5667, 0x3FAC28F5C0000000
  %5683 = fadd fast float %5668, 0x3FAC28F5C0000000
  %5684 = fadd fast float %5669, 0x3FAC28F5C0000000
  %5685 = fmul fast float %5682, 0x3FEE54EDE0000000
  %5686 = fmul fast float %5683, 0x3FEE54EDE0000000
  %5687 = fmul fast float %5684, 0x3FEE54EDE0000000
  %5688 = call float @dx.op.unary.f32(i32 23, float %5685)  ; Log(value)
  %5689 = call float @dx.op.unary.f32(i32 23, float %5686)  ; Log(value)
  %5690 = call float @dx.op.unary.f32(i32 23, float %5687)  ; Log(value)
  %5691 = fmul fast float %5688, 0x4003333340000000
  %5692 = fmul fast float %5689, 0x4003333340000000
  %5693 = fmul fast float %5690, 0x4003333340000000
  %5694 = call float @dx.op.unary.f32(i32 21, float %5691)  ; Exp(value)
  %5695 = call float @dx.op.unary.f32(i32 21, float %5692)  ; Exp(value)
  %5696 = call float @dx.op.unary.f32(i32 21, float %5693)  ; Exp(value)
  %5697 = fsub fast float %5679, %5694
  %5698 = fsub fast float %5680, %5695
  %5699 = fsub fast float %5681, %5696
  %5700 = fmul fast float %5697, %5676
  %5701 = fmul fast float %5698, %5677
  %5702 = fmul fast float %5699, %5678
  %5703 = fadd fast float %5700, %5694
  %5704 = fadd fast float %5701, %5695
  %5705 = fadd fast float %5702, %5696
  br label %5921

; <label>:5706                                    ; preds = %5661
  %5707 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5664, i32 %5665, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5708 = extractvalue %dx.types.ResRet.f32 %5707, 0
  %5709 = fcmp fast ogt float %39, 5.000000e-01
  %5710 = fcmp fast olt float %5708, 1.000000e+00
  %5711 = and i1 %5709, %5710
  br i1 %5711, label %5712, label %5850

; <label>:5712                                    ; preds = %5706
  %5713 = sitofp i32 %5664 to float
  %5714 = sitofp i32 %5665 to float
  %5715 = fadd fast float %5713, 5.000000e-01
  %5716 = fadd fast float %5714, 5.000000e-01
  %5717 = fdiv fast float %5715, %46
  %5718 = fdiv fast float %5716, %47
  %5719 = fmul fast float %5717, 2.000000e+00
  %5720 = fmul fast float %5718, 2.000000e+00
  %5721 = fadd fast float %5719, -1.000000e+00
  %5722 = fsub fast float 1.000000e+00, %5720
  %5723 = fmul fast float %5721, %36
  %5724 = call float @dx.op.tertiary.f32(i32 46, float %5722, float %32, float %5723)  ; FMad(a,b,c)
  %5725 = call float @dx.op.tertiary.f32(i32 46, float %5708, float %28, float %5724)  ; FMad(a,b,c)
  %5726 = fadd fast float %5725, %24
  %5727 = call float @dx.op.unary.f32(i32 6, float %5726)  ; FAbs(value)
  %5728 = fcmp fast ogt float %5727, 0x3EB0C6F7A0000000
  br i1 %5728, label %5729, label %5850

; <label>:5729                                    ; preds = %5712
  %5730 = fmul fast float %5721, %35
  %5731 = call float @dx.op.tertiary.f32(i32 46, float %5722, float %31, float %5730)  ; FMad(a,b,c)
  %5732 = call float @dx.op.tertiary.f32(i32 46, float %5708, float %27, float %5731)  ; FMad(a,b,c)
  %5733 = fadd fast float %5732, %23
  %5734 = fmul fast float %5721, %34
  %5735 = call float @dx.op.tertiary.f32(i32 46, float %5722, float %30, float %5734)  ; FMad(a,b,c)
  %5736 = call float @dx.op.tertiary.f32(i32 46, float %5708, float %26, float %5735)  ; FMad(a,b,c)
  %5737 = fadd fast float %5736, %22
  %5738 = fmul fast float %5721, %33
  %5739 = call float @dx.op.tertiary.f32(i32 46, float %5722, float %29, float %5738)  ; FMad(a,b,c)
  %5740 = call float @dx.op.tertiary.f32(i32 46, float %5708, float %25, float %5739)  ; FMad(a,b,c)
  %5741 = fadd fast float %5740, %21
  %5742 = fdiv fast float %5741, %5726
  %5743 = fdiv fast float %5737, %5726
  %5744 = fdiv fast float %5733, %5726
  %5745 = fsub fast float %5742, %18
  %5746 = fsub fast float %5743, %19
  %5747 = fsub fast float %5744, %20
  %5748 = fmul fast float %5745, %5745
  %5749 = fmul fast float %5746, %5746
  %5750 = fadd fast float %5749, %5748
  %5751 = fmul fast float %5747, %5747
  %5752 = fadd fast float %5750, %5751
  %5753 = call float @dx.op.unary.f32(i32 24, float %5752)  ; Sqrt(value)
  %5754 = fsub fast float %5753, %10
  %5755 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5754)  ; FMax(a,b)
  %5756 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %5756, label %5757, label %5780

; <label>:5757                                    ; preds = %5729
  %5758 = call float @dx.op.unary.f32(i32 6, float %5746)  ; FAbs(value)
  %5759 = fmul fast float %5758, %12
  %5760 = fcmp fast olt float %5759, 0x3F50624DE0000000
  br i1 %5760, label %5761, label %5764

; <label>:5761                                    ; preds = %5757
  %5762 = fmul fast float %5759, 5.000000e-01
  %5763 = fsub fast float 1.000000e+00, %5762
  br label %5769

; <label>:5764                                    ; preds = %5757
  %5765 = fmul fast float %5759, 0xBFF7154760000000
  %5766 = call float @dx.op.unary.f32(i32 21, float %5765)  ; Exp(value)
  %5767 = fsub fast float 1.000000e+00, %5766
  %5768 = fdiv fast float %5767, %5759
  br label %5769

; <label>:5769                                    ; preds = %5764, %5761
  %5770 = phi float [ %5763, %5761 ], [ %5768, %5764 ]
  %5771 = call float @dx.op.binary.f32(i32 36, float %5743, float %19)  ; FMin(a,b)
  %5772 = fsub fast float %5771, %11
  %5773 = fmul fast float %12, %5772
  %5774 = fsub fast float -0.000000e+00, %5773
  %5775 = call float @dx.op.binary.f32(i32 35, float %5774, float -4.000000e+01)  ; FMax(a,b)
  %5776 = call float @dx.op.binary.f32(i32 36, float %5775, float 5.000000e+00)  ; FMin(a,b)
  %5777 = fmul fast float %5776, 0x3FF7154760000000
  %5778 = call float @dx.op.unary.f32(i32 21, float %5777)  ; Exp(value)
  %5779 = fmul fast float %5778, %5770
  br label %5780

; <label>:5780                                    ; preds = %5769, %5729
  %5781 = phi float [ %5779, %5769 ], [ 1.000000e+00, %5729 ]
  %5782 = fmul fast float %5755, %17
  %5783 = fmul fast float %5782, %5781
  %5784 = fcmp fast ole float %5753, %10
  %5785 = fcmp fast olt float %5753, 0x3F1A36E2E0000000
  %5786 = or i1 %5784, %5785
  br i1 %5786, label %5833, label %5787

; <label>:5787                                    ; preds = %5780
  %5788 = fdiv fast float %10, %5753
  %5789 = fmul fast float %5788, %5745
  %5790 = fmul fast float %5788, %5746
  %5791 = fmul fast float %5788, %5747
  %5792 = fadd fast float %5789, %18
  %5793 = fadd fast float %5790, %19
  %5794 = fadd fast float %5791, %20
  %5795 = fadd fast float %5792, -9.000000e+02
  %5796 = fadd fast float %5793, -1.500000e+01
  %5797 = fadd fast float %5794, -7.500000e+02
  %5798 = fmul fast float %5795, 0x3F62345680000000
  %5799 = fmul fast float %5796, 0x3F62345680000000
  %5800 = fmul fast float %5797, 0x3F62345680000000
  %5801 = call float @dx.op.dot3.f32(i32 55, float %5798, float %5799, float %5800, float %5798, float %5799, float %5800)  ; Dot3(ax,ay,az,bx,by,bz)
  %5802 = fsub fast float 1.000000e+00, %5801
  %5803 = call float @dx.op.unary.f32(i32 7, float %5802)  ; Saturate(value)
  %5804 = fmul fast float %5803, %5803
  %5805 = fadd fast float %5792, %5742
  %5806 = fadd fast float %5793, %5743
  %5807 = fadd fast float %5794, %5744
  %5808 = fmul fast float %5805, 0x3F52345680000000
  %5809 = fadd fast float %5808, -2.000000e+00
  %5810 = fmul fast float %5806, 0x3F52345680000000
  %5811 = fadd fast float %5810, 0xBFA1111120000000
  %5812 = fmul fast float %5807, 0x3F52345680000000
  %5813 = fadd fast float %5812, 0xBFFAAAAAC0000000
  %5814 = call float @dx.op.dot3.f32(i32 55, float %5809, float %5811, float %5813, float %5809, float %5811, float %5813)  ; Dot3(ax,ay,az,bx,by,bz)
  %5815 = fsub fast float 1.000000e+00, %5814
  %5816 = call float @dx.op.unary.f32(i32 7, float %5815)  ; Saturate(value)
  %5817 = fmul fast float %5816, %5816
  %5818 = fmul fast float %5817, 4.000000e+00
  %5819 = fadd fast float %5818, %5804
  %5820 = fadd fast float %5742, -9.000000e+02
  %5821 = fadd fast float %5743, -1.500000e+01
  %5822 = fadd fast float %5744, -7.500000e+02
  %5823 = fmul fast float %5820, 0x3F62345680000000
  %5824 = fmul fast float %5821, 0x3F62345680000000
  %5825 = fmul fast float %5822, 0x3F62345680000000
  %5826 = call float @dx.op.dot3.f32(i32 55, float %5823, float %5824, float %5825, float %5823, float %5824, float %5825)  ; Dot3(ax,ay,az,bx,by,bz)
  %5827 = fsub fast float 1.000000e+00, %5826
  %5828 = call float @dx.op.unary.f32(i32 7, float %5827)  ; Saturate(value)
  %5829 = fmul fast float %5828, %5828
  %5830 = fadd fast float %5819, %5829
  %5831 = fmul fast float %5754, 0x3F25D867E0000000
  %5832 = fmul fast float %5831, %5830
  br label %5833

; <label>:5833                                    ; preds = %5787, %5780
  %5834 = phi float [ %5832, %5787 ], [ 0.000000e+00, %5780 ]
  %5835 = fadd fast float %5834, %5783
  %5836 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %5835)  ; FMin(a,b)
  %5837 = fmul fast float %5836, 0xBFF7154760000000
  %5838 = call float @dx.op.unary.f32(i32 21, float %5837)  ; Exp(value)
  %5839 = fsub fast float 1.000000e+00, %5838
  %5840 = call float @dx.op.binary.f32(i32 36, float %13, float %5839)  ; FMin(a,b)
  %5841 = fsub fast float %14, %5667
  %5842 = fsub fast float %15, %5668
  %5843 = fsub fast float %16, %5669
  %5844 = fmul fast float %5840, %5841
  %5845 = fmul fast float %5840, %5842
  %5846 = fmul fast float %5840, %5843
  %5847 = fadd fast float %5844, %5667
  %5848 = fadd fast float %5845, %5668
  %5849 = fadd fast float %5846, %5669
  br label %5850

; <label>:5850                                    ; preds = %5833, %5712, %5706
  %5851 = phi float [ %5847, %5833 ], [ %5667, %5712 ], [ %5667, %5706 ]
  %5852 = phi float [ %5848, %5833 ], [ %5668, %5712 ], [ %5668, %5706 ]
  %5853 = phi float [ %5849, %5833 ], [ %5669, %5712 ], [ %5669, %5706 ]
  %5854 = fadd fast float %6, 1.000000e+00
  %5855 = fadd fast float %7, 1.000000e+00
  %5856 = fsub fast float 1.000000e+00, %6
  %5857 = fmul fast float %37, %5854
  %5858 = fmul fast float %37, %5855
  %5859 = fmul fast float %37, %5856
  %5860 = fmul fast float %5857, %5851
  %5861 = fmul fast float %5858, %5852
  %5862 = fmul fast float %5859, %5853
  %5863 = fcmp fast ult float %38, 5.000000e-01
  br i1 %5863, label %5889, label %5864

; <label>:5864                                    ; preds = %5850
  %5865 = fmul fast float %5860, 0x4004147AE0000000
  %5866 = fmul fast float %5861, 0x4004147AE0000000
  %5867 = fmul fast float %5862, 0x4004147AE0000000
  %5868 = fadd fast float %5865, 0x3F9EB851E0000000
  %5869 = fadd fast float %5866, 0x3F9EB851E0000000
  %5870 = fadd fast float %5867, 0x3F9EB851E0000000
  %5871 = fmul fast float %5868, %5860
  %5872 = fmul fast float %5869, %5861
  %5873 = fmul fast float %5870, %5862
  %5874 = fmul fast float %5860, 0x400370A3E0000000
  %5875 = fmul fast float %5861, 0x400370A3E0000000
  %5876 = fmul fast float %5862, 0x400370A3E0000000
  %5877 = fadd fast float %5874, 0x3FE2E147A0000000
  %5878 = fadd fast float %5875, 0x3FE2E147A0000000
  %5879 = fadd fast float %5876, 0x3FE2E147A0000000
  %5880 = fmul fast float %5877, %5860
  %5881 = fmul fast float %5878, %5861
  %5882 = fmul fast float %5879, %5862
  %5883 = fadd fast float %5880, 0x3FC1EB8520000000
  %5884 = fadd fast float %5881, 0x3FC1EB8520000000
  %5885 = fadd fast float %5882, 0x3FC1EB8520000000
  %5886 = fdiv fast float %5871, %5883
  %5887 = fdiv fast float %5872, %5884
  %5888 = fdiv fast float %5873, %5885
  br label %5889

; <label>:5889                                    ; preds = %5864, %5850
  %5890 = phi float [ %5886, %5864 ], [ %5860, %5850 ]
  %5891 = phi float [ %5887, %5864 ], [ %5861, %5850 ]
  %5892 = phi float [ %5888, %5864 ], [ %5862, %5850 ]
  %5893 = call float @dx.op.unary.f32(i32 7, float %5890)  ; Saturate(value)
  %5894 = call float @dx.op.unary.f32(i32 7, float %5891)  ; Saturate(value)
  %5895 = call float @dx.op.unary.f32(i32 7, float %5892)  ; Saturate(value)
  %5896 = call float @dx.op.dot3.f32(i32 55, float %5893, float %5894, float %5895, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5897 = fsub fast float %5893, %5896
  %5898 = fsub fast float %5894, %5896
  %5899 = fsub fast float %5895, %5896
  %5900 = fmul fast float %5897, %9
  %5901 = fmul fast float %5898, %9
  %5902 = fmul fast float %5899, %9
  %5903 = fadd fast float %5900, %5896
  %5904 = fadd fast float %5901, %5896
  %5905 = fadd fast float %5902, %5896
  %5906 = call float @dx.op.unary.f32(i32 7, float %5903)  ; Saturate(value)
  %5907 = call float @dx.op.unary.f32(i32 7, float %5904)  ; Saturate(value)
  %5908 = call float @dx.op.unary.f32(i32 7, float %5905)  ; Saturate(value)
  %5909 = fadd fast float %5906, 0xBFC70A3D80000000
  %5910 = fadd fast float %5907, 0xBFC70A3D80000000
  %5911 = fadd fast float %5908, 0xBFC70A3D80000000
  %5912 = fmul fast float %5909, %8
  %5913 = fmul fast float %5910, %8
  %5914 = fmul fast float %5911, %8
  %5915 = fadd fast float %5912, 0x3FC70A3D80000000
  %5916 = fadd fast float %5913, 0x3FC70A3D80000000
  %5917 = fadd fast float %5914, 0x3FC70A3D80000000
  %5918 = call float @dx.op.unary.f32(i32 7, float %5915)  ; Saturate(value)
  %5919 = call float @dx.op.unary.f32(i32 7, float %5916)  ; Saturate(value)
  %5920 = call float @dx.op.unary.f32(i32 7, float %5917)  ; Saturate(value)
  br label %5921

; <label>:5921                                    ; preds = %5889, %5672
  %5922 = phi float [ %5703, %5672 ], [ %5918, %5889 ]
  %5923 = phi float [ %5704, %5672 ], [ %5919, %5889 ]
  %5924 = phi float [ %5705, %5672 ], [ %5920, %5889 ]
  %5925 = fsub fast float %5922, %5062
  %5926 = fsub fast float %5923, %5063
  %5927 = fsub fast float %5924, %5064
  %5928 = fmul fast float %5925, %5659
  %5929 = fmul fast float %5926, %5659
  %5930 = fmul fast float %5927, %5659
  %5931 = fadd fast float %5928, %5062
  %5932 = fadd fast float %5929, %5063
  %5933 = fadd fast float %5930, %5064
  br label %5934

; <label>:5934                                    ; preds = %5921, %5644
  %5935 = phi float [ %5931, %5921 ], [ %5062, %5644 ]
  %5936 = phi float [ %5932, %5921 ], [ %5063, %5644 ]
  %5937 = phi float [ %5933, %5921 ], [ %5064, %5644 ]
  %5938 = add i32 %68, 1
  %5939 = call i32 @dx.op.binary.i32(i32 37, i32 %5938, i32 0)  ; IMax(a,b)
  %5940 = call i32 @dx.op.binary.i32(i32 38, i32 %5939, i32 %60)  ; IMin(a,b)
  %5941 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5940, i32 %5652, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5942 = extractvalue %dx.types.ResRet.f32 %5941, 0
  %5943 = fsub fast float %5942, %89
  %5944 = call float @dx.op.unary.f32(i32 6, float %5943)  ; FAbs(value)
  %5945 = fdiv fast float %5944, %5076
  %5946 = fsub fast float 1.000000e+00, %5945
  %5947 = call float @dx.op.unary.f32(i32 7, float %5946)  ; Saturate(value)
  %5948 = fcmp fast ugt float %5947, 0.000000e+00
  br i1 %5948, label %5949, label %6222

; <label>:5949                                    ; preds = %5934
  %5950 = call i32 @dx.op.binary.i32(i32 37, i32 %5940, i32 0)  ; IMax(a,b)
  %5951 = call i32 @dx.op.binary.i32(i32 37, i32 %5652, i32 0)  ; IMax(a,b)
  %5952 = call i32 @dx.op.binary.i32(i32 38, i32 %5950, i32 %60)  ; IMin(a,b)
  %5953 = call i32 @dx.op.binary.i32(i32 38, i32 %5951, i32 %61)  ; IMin(a,b)
  %5954 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %5952, i32 %5953, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5955 = extractvalue %dx.types.ResRet.f32 %5954, 0
  %5956 = extractvalue %dx.types.ResRet.f32 %5954, 1
  %5957 = extractvalue %dx.types.ResRet.f32 %5954, 2
  %5958 = extractvalue %dx.types.ResRet.f32 %5954, 3
  %5959 = fcmp fast olt float %5958, 0.000000e+00
  br i1 %5959, label %5960, label %5994

; <label>:5960                                    ; preds = %5949
  %5961 = fcmp fast ogt float %5955, 0x3FA4B5DCC0000000
  %5962 = fcmp fast ogt float %5956, 0x3FA4B5DCC0000000
  %5963 = fcmp fast ogt float %5957, 0x3FA4B5DCC0000000
  %5964 = select i1 %5961, float 0.000000e+00, float 1.000000e+00
  %5965 = select i1 %5962, float 0.000000e+00, float 1.000000e+00
  %5966 = select i1 %5963, float 0.000000e+00, float 1.000000e+00
  %5967 = fmul fast float %5955, 0x3FB3D07220000000
  %5968 = fmul fast float %5956, 0x3FB3D07220000000
  %5969 = fmul fast float %5957, 0x3FB3D07220000000
  %5970 = fadd fast float %5955, 0x3FAC28F5C0000000
  %5971 = fadd fast float %5956, 0x3FAC28F5C0000000
  %5972 = fadd fast float %5957, 0x3FAC28F5C0000000
  %5973 = fmul fast float %5970, 0x3FEE54EDE0000000
  %5974 = fmul fast float %5971, 0x3FEE54EDE0000000
  %5975 = fmul fast float %5972, 0x3FEE54EDE0000000
  %5976 = call float @dx.op.unary.f32(i32 23, float %5973)  ; Log(value)
  %5977 = call float @dx.op.unary.f32(i32 23, float %5974)  ; Log(value)
  %5978 = call float @dx.op.unary.f32(i32 23, float %5975)  ; Log(value)
  %5979 = fmul fast float %5976, 0x4003333340000000
  %5980 = fmul fast float %5977, 0x4003333340000000
  %5981 = fmul fast float %5978, 0x4003333340000000
  %5982 = call float @dx.op.unary.f32(i32 21, float %5979)  ; Exp(value)
  %5983 = call float @dx.op.unary.f32(i32 21, float %5980)  ; Exp(value)
  %5984 = call float @dx.op.unary.f32(i32 21, float %5981)  ; Exp(value)
  %5985 = fsub fast float %5967, %5982
  %5986 = fsub fast float %5968, %5983
  %5987 = fsub fast float %5969, %5984
  %5988 = fmul fast float %5985, %5964
  %5989 = fmul fast float %5986, %5965
  %5990 = fmul fast float %5987, %5966
  %5991 = fadd fast float %5988, %5982
  %5992 = fadd fast float %5989, %5983
  %5993 = fadd fast float %5990, %5984
  br label %6209

; <label>:5994                                    ; preds = %5949
  %5995 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5952, i32 %5953, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5996 = extractvalue %dx.types.ResRet.f32 %5995, 0
  %5997 = fcmp fast ogt float %39, 5.000000e-01
  %5998 = fcmp fast olt float %5996, 1.000000e+00
  %5999 = and i1 %5997, %5998
  br i1 %5999, label %6000, label %6138

; <label>:6000                                    ; preds = %5994
  %6001 = sitofp i32 %5952 to float
  %6002 = sitofp i32 %5953 to float
  %6003 = fadd fast float %6001, 5.000000e-01
  %6004 = fadd fast float %6002, 5.000000e-01
  %6005 = fdiv fast float %6003, %46
  %6006 = fdiv fast float %6004, %47
  %6007 = fmul fast float %6005, 2.000000e+00
  %6008 = fmul fast float %6006, 2.000000e+00
  %6009 = fadd fast float %6007, -1.000000e+00
  %6010 = fsub fast float 1.000000e+00, %6008
  %6011 = fmul fast float %6009, %36
  %6012 = call float @dx.op.tertiary.f32(i32 46, float %6010, float %32, float %6011)  ; FMad(a,b,c)
  %6013 = call float @dx.op.tertiary.f32(i32 46, float %5996, float %28, float %6012)  ; FMad(a,b,c)
  %6014 = fadd fast float %6013, %24
  %6015 = call float @dx.op.unary.f32(i32 6, float %6014)  ; FAbs(value)
  %6016 = fcmp fast ogt float %6015, 0x3EB0C6F7A0000000
  br i1 %6016, label %6017, label %6138

; <label>:6017                                    ; preds = %6000
  %6018 = fmul fast float %6009, %35
  %6019 = call float @dx.op.tertiary.f32(i32 46, float %6010, float %31, float %6018)  ; FMad(a,b,c)
  %6020 = call float @dx.op.tertiary.f32(i32 46, float %5996, float %27, float %6019)  ; FMad(a,b,c)
  %6021 = fadd fast float %6020, %23
  %6022 = fmul fast float %6009, %34
  %6023 = call float @dx.op.tertiary.f32(i32 46, float %6010, float %30, float %6022)  ; FMad(a,b,c)
  %6024 = call float @dx.op.tertiary.f32(i32 46, float %5996, float %26, float %6023)  ; FMad(a,b,c)
  %6025 = fadd fast float %6024, %22
  %6026 = fmul fast float %6009, %33
  %6027 = call float @dx.op.tertiary.f32(i32 46, float %6010, float %29, float %6026)  ; FMad(a,b,c)
  %6028 = call float @dx.op.tertiary.f32(i32 46, float %5996, float %25, float %6027)  ; FMad(a,b,c)
  %6029 = fadd fast float %6028, %21
  %6030 = fdiv fast float %6029, %6014
  %6031 = fdiv fast float %6025, %6014
  %6032 = fdiv fast float %6021, %6014
  %6033 = fsub fast float %6030, %18
  %6034 = fsub fast float %6031, %19
  %6035 = fsub fast float %6032, %20
  %6036 = fmul fast float %6033, %6033
  %6037 = fmul fast float %6034, %6034
  %6038 = fadd fast float %6037, %6036
  %6039 = fmul fast float %6035, %6035
  %6040 = fadd fast float %6038, %6039
  %6041 = call float @dx.op.unary.f32(i32 24, float %6040)  ; Sqrt(value)
  %6042 = fsub fast float %6041, %10
  %6043 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %6042)  ; FMax(a,b)
  %6044 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %6044, label %6045, label %6068

; <label>:6045                                    ; preds = %6017
  %6046 = call float @dx.op.unary.f32(i32 6, float %6034)  ; FAbs(value)
  %6047 = fmul fast float %6046, %12
  %6048 = fcmp fast olt float %6047, 0x3F50624DE0000000
  br i1 %6048, label %6049, label %6052

; <label>:6049                                    ; preds = %6045
  %6050 = fmul fast float %6047, 5.000000e-01
  %6051 = fsub fast float 1.000000e+00, %6050
  br label %6057

; <label>:6052                                    ; preds = %6045
  %6053 = fmul fast float %6047, 0xBFF7154760000000
  %6054 = call float @dx.op.unary.f32(i32 21, float %6053)  ; Exp(value)
  %6055 = fsub fast float 1.000000e+00, %6054
  %6056 = fdiv fast float %6055, %6047
  br label %6057

; <label>:6057                                    ; preds = %6052, %6049
  %6058 = phi float [ %6051, %6049 ], [ %6056, %6052 ]
  %6059 = call float @dx.op.binary.f32(i32 36, float %6031, float %19)  ; FMin(a,b)
  %6060 = fsub fast float %6059, %11
  %6061 = fmul fast float %12, %6060
  %6062 = fsub fast float -0.000000e+00, %6061
  %6063 = call float @dx.op.binary.f32(i32 35, float %6062, float -4.000000e+01)  ; FMax(a,b)
  %6064 = call float @dx.op.binary.f32(i32 36, float %6063, float 5.000000e+00)  ; FMin(a,b)
  %6065 = fmul fast float %6064, 0x3FF7154760000000
  %6066 = call float @dx.op.unary.f32(i32 21, float %6065)  ; Exp(value)
  %6067 = fmul fast float %6066, %6058
  br label %6068

; <label>:6068                                    ; preds = %6057, %6017
  %6069 = phi float [ %6067, %6057 ], [ 1.000000e+00, %6017 ]
  %6070 = fmul fast float %6043, %17
  %6071 = fmul fast float %6070, %6069
  %6072 = fcmp fast ole float %6041, %10
  %6073 = fcmp fast olt float %6041, 0x3F1A36E2E0000000
  %6074 = or i1 %6072, %6073
  br i1 %6074, label %6121, label %6075

; <label>:6075                                    ; preds = %6068
  %6076 = fdiv fast float %10, %6041
  %6077 = fmul fast float %6076, %6033
  %6078 = fmul fast float %6076, %6034
  %6079 = fmul fast float %6076, %6035
  %6080 = fadd fast float %6077, %18
  %6081 = fadd fast float %6078, %19
  %6082 = fadd fast float %6079, %20
  %6083 = fadd fast float %6080, -9.000000e+02
  %6084 = fadd fast float %6081, -1.500000e+01
  %6085 = fadd fast float %6082, -7.500000e+02
  %6086 = fmul fast float %6083, 0x3F62345680000000
  %6087 = fmul fast float %6084, 0x3F62345680000000
  %6088 = fmul fast float %6085, 0x3F62345680000000
  %6089 = call float @dx.op.dot3.f32(i32 55, float %6086, float %6087, float %6088, float %6086, float %6087, float %6088)  ; Dot3(ax,ay,az,bx,by,bz)
  %6090 = fsub fast float 1.000000e+00, %6089
  %6091 = call float @dx.op.unary.f32(i32 7, float %6090)  ; Saturate(value)
  %6092 = fmul fast float %6091, %6091
  %6093 = fadd fast float %6080, %6030
  %6094 = fadd fast float %6081, %6031
  %6095 = fadd fast float %6082, %6032
  %6096 = fmul fast float %6093, 0x3F52345680000000
  %6097 = fadd fast float %6096, -2.000000e+00
  %6098 = fmul fast float %6094, 0x3F52345680000000
  %6099 = fadd fast float %6098, 0xBFA1111120000000
  %6100 = fmul fast float %6095, 0x3F52345680000000
  %6101 = fadd fast float %6100, 0xBFFAAAAAC0000000
  %6102 = call float @dx.op.dot3.f32(i32 55, float %6097, float %6099, float %6101, float %6097, float %6099, float %6101)  ; Dot3(ax,ay,az,bx,by,bz)
  %6103 = fsub fast float 1.000000e+00, %6102
  %6104 = call float @dx.op.unary.f32(i32 7, float %6103)  ; Saturate(value)
  %6105 = fmul fast float %6104, %6104
  %6106 = fmul fast float %6105, 4.000000e+00
  %6107 = fadd fast float %6106, %6092
  %6108 = fadd fast float %6030, -9.000000e+02
  %6109 = fadd fast float %6031, -1.500000e+01
  %6110 = fadd fast float %6032, -7.500000e+02
  %6111 = fmul fast float %6108, 0x3F62345680000000
  %6112 = fmul fast float %6109, 0x3F62345680000000
  %6113 = fmul fast float %6110, 0x3F62345680000000
  %6114 = call float @dx.op.dot3.f32(i32 55, float %6111, float %6112, float %6113, float %6111, float %6112, float %6113)  ; Dot3(ax,ay,az,bx,by,bz)
  %6115 = fsub fast float 1.000000e+00, %6114
  %6116 = call float @dx.op.unary.f32(i32 7, float %6115)  ; Saturate(value)
  %6117 = fmul fast float %6116, %6116
  %6118 = fadd fast float %6107, %6117
  %6119 = fmul fast float %6042, 0x3F25D867E0000000
  %6120 = fmul fast float %6119, %6118
  br label %6121

; <label>:6121                                    ; preds = %6075, %6068
  %6122 = phi float [ %6120, %6075 ], [ 0.000000e+00, %6068 ]
  %6123 = fadd fast float %6122, %6071
  %6124 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %6123)  ; FMin(a,b)
  %6125 = fmul fast float %6124, 0xBFF7154760000000
  %6126 = call float @dx.op.unary.f32(i32 21, float %6125)  ; Exp(value)
  %6127 = fsub fast float 1.000000e+00, %6126
  %6128 = call float @dx.op.binary.f32(i32 36, float %13, float %6127)  ; FMin(a,b)
  %6129 = fsub fast float %14, %5955
  %6130 = fsub fast float %15, %5956
  %6131 = fsub fast float %16, %5957
  %6132 = fmul fast float %6128, %6129
  %6133 = fmul fast float %6128, %6130
  %6134 = fmul fast float %6128, %6131
  %6135 = fadd fast float %6132, %5955
  %6136 = fadd fast float %6133, %5956
  %6137 = fadd fast float %6134, %5957
  br label %6138

; <label>:6138                                    ; preds = %6121, %6000, %5994
  %6139 = phi float [ %6135, %6121 ], [ %5955, %6000 ], [ %5955, %5994 ]
  %6140 = phi float [ %6136, %6121 ], [ %5956, %6000 ], [ %5956, %5994 ]
  %6141 = phi float [ %6137, %6121 ], [ %5957, %6000 ], [ %5957, %5994 ]
  %6142 = fadd fast float %6, 1.000000e+00
  %6143 = fadd fast float %7, 1.000000e+00
  %6144 = fsub fast float 1.000000e+00, %6
  %6145 = fmul fast float %37, %6142
  %6146 = fmul fast float %37, %6143
  %6147 = fmul fast float %37, %6144
  %6148 = fmul fast float %6145, %6139
  %6149 = fmul fast float %6146, %6140
  %6150 = fmul fast float %6147, %6141
  %6151 = fcmp fast ult float %38, 5.000000e-01
  br i1 %6151, label %6177, label %6152

; <label>:6152                                    ; preds = %6138
  %6153 = fmul fast float %6148, 0x4004147AE0000000
  %6154 = fmul fast float %6149, 0x4004147AE0000000
  %6155 = fmul fast float %6150, 0x4004147AE0000000
  %6156 = fadd fast float %6153, 0x3F9EB851E0000000
  %6157 = fadd fast float %6154, 0x3F9EB851E0000000
  %6158 = fadd fast float %6155, 0x3F9EB851E0000000
  %6159 = fmul fast float %6156, %6148
  %6160 = fmul fast float %6157, %6149
  %6161 = fmul fast float %6158, %6150
  %6162 = fmul fast float %6148, 0x400370A3E0000000
  %6163 = fmul fast float %6149, 0x400370A3E0000000
  %6164 = fmul fast float %6150, 0x400370A3E0000000
  %6165 = fadd fast float %6162, 0x3FE2E147A0000000
  %6166 = fadd fast float %6163, 0x3FE2E147A0000000
  %6167 = fadd fast float %6164, 0x3FE2E147A0000000
  %6168 = fmul fast float %6165, %6148
  %6169 = fmul fast float %6166, %6149
  %6170 = fmul fast float %6167, %6150
  %6171 = fadd fast float %6168, 0x3FC1EB8520000000
  %6172 = fadd fast float %6169, 0x3FC1EB8520000000
  %6173 = fadd fast float %6170, 0x3FC1EB8520000000
  %6174 = fdiv fast float %6159, %6171
  %6175 = fdiv fast float %6160, %6172
  %6176 = fdiv fast float %6161, %6173
  br label %6177

; <label>:6177                                    ; preds = %6152, %6138
  %6178 = phi float [ %6174, %6152 ], [ %6148, %6138 ]
  %6179 = phi float [ %6175, %6152 ], [ %6149, %6138 ]
  %6180 = phi float [ %6176, %6152 ], [ %6150, %6138 ]
  %6181 = call float @dx.op.unary.f32(i32 7, float %6178)  ; Saturate(value)
  %6182 = call float @dx.op.unary.f32(i32 7, float %6179)  ; Saturate(value)
  %6183 = call float @dx.op.unary.f32(i32 7, float %6180)  ; Saturate(value)
  %6184 = call float @dx.op.dot3.f32(i32 55, float %6181, float %6182, float %6183, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %6185 = fsub fast float %6181, %6184
  %6186 = fsub fast float %6182, %6184
  %6187 = fsub fast float %6183, %6184
  %6188 = fmul fast float %6185, %9
  %6189 = fmul fast float %6186, %9
  %6190 = fmul fast float %6187, %9
  %6191 = fadd fast float %6188, %6184
  %6192 = fadd fast float %6189, %6184
  %6193 = fadd fast float %6190, %6184
  %6194 = call float @dx.op.unary.f32(i32 7, float %6191)  ; Saturate(value)
  %6195 = call float @dx.op.unary.f32(i32 7, float %6192)  ; Saturate(value)
  %6196 = call float @dx.op.unary.f32(i32 7, float %6193)  ; Saturate(value)
  %6197 = fadd fast float %6194, 0xBFC70A3D80000000
  %6198 = fadd fast float %6195, 0xBFC70A3D80000000
  %6199 = fadd fast float %6196, 0xBFC70A3D80000000
  %6200 = fmul fast float %6197, %8
  %6201 = fmul fast float %6198, %8
  %6202 = fmul fast float %6199, %8
  %6203 = fadd fast float %6200, 0x3FC70A3D80000000
  %6204 = fadd fast float %6201, 0x3FC70A3D80000000
  %6205 = fadd fast float %6202, 0x3FC70A3D80000000
  %6206 = call float @dx.op.unary.f32(i32 7, float %6203)  ; Saturate(value)
  %6207 = call float @dx.op.unary.f32(i32 7, float %6204)  ; Saturate(value)
  %6208 = call float @dx.op.unary.f32(i32 7, float %6205)  ; Saturate(value)
  br label %6209

; <label>:6209                                    ; preds = %6177, %5960
  %6210 = phi float [ %5991, %5960 ], [ %6206, %6177 ]
  %6211 = phi float [ %5992, %5960 ], [ %6207, %6177 ]
  %6212 = phi float [ %5993, %5960 ], [ %6208, %6177 ]
  %6213 = fsub fast float %6210, %5062
  %6214 = fsub fast float %6211, %5063
  %6215 = fsub fast float %6212, %5064
  %6216 = fmul fast float %6213, %5947
  %6217 = fmul fast float %6214, %5947
  %6218 = fmul fast float %6215, %5947
  %6219 = fadd fast float %6216, %5062
  %6220 = fadd fast float %6217, %5063
  %6221 = fadd fast float %6218, %5064
  br label %6222

; <label>:6222                                    ; preds = %6209, %5934
  %6223 = phi float [ %6219, %6209 ], [ %5062, %5934 ]
  %6224 = phi float [ %6220, %6209 ], [ %5063, %5934 ]
  %6225 = phi float [ %6221, %6209 ], [ %5064, %5934 ]
  %6226 = call float @dx.op.binary.f32(i32 36, float %5935, float %6223)  ; FMin(a,b)
  %6227 = call float @dx.op.binary.f32(i32 36, float %5936, float %6224)  ; FMin(a,b)
  %6228 = call float @dx.op.binary.f32(i32 36, float %5937, float %6225)  ; FMin(a,b)
  %6229 = call float @dx.op.binary.f32(i32 36, float %5357, float %5645)  ; FMin(a,b)
  %6230 = call float @dx.op.binary.f32(i32 36, float %5358, float %5646)  ; FMin(a,b)
  %6231 = call float @dx.op.binary.f32(i32 36, float %5359, float %5647)  ; FMin(a,b)
  %6232 = call float @dx.op.binary.f32(i32 36, float %6229, float %6226)  ; FMin(a,b)
  %6233 = call float @dx.op.binary.f32(i32 36, float %6230, float %6227)  ; FMin(a,b)
  %6234 = call float @dx.op.binary.f32(i32 36, float %6231, float %6228)  ; FMin(a,b)
  %6235 = call float @dx.op.binary.f32(i32 36, float %5062, float %6232)  ; FMin(a,b)
  %6236 = call float @dx.op.binary.f32(i32 36, float %5063, float %6233)  ; FMin(a,b)
  %6237 = call float @dx.op.binary.f32(i32 36, float %5064, float %6234)  ; FMin(a,b)
  %6238 = call float @dx.op.binary.f32(i32 35, float %5935, float %6223)  ; FMax(a,b)
  %6239 = call float @dx.op.binary.f32(i32 35, float %5936, float %6224)  ; FMax(a,b)
  %6240 = call float @dx.op.binary.f32(i32 35, float %5937, float %6225)  ; FMax(a,b)
  %6241 = call float @dx.op.binary.f32(i32 35, float %5357, float %5645)  ; FMax(a,b)
  %6242 = call float @dx.op.binary.f32(i32 35, float %5358, float %5646)  ; FMax(a,b)
  %6243 = call float @dx.op.binary.f32(i32 35, float %5359, float %5647)  ; FMax(a,b)
  %6244 = call float @dx.op.binary.f32(i32 35, float %6241, float %6238)  ; FMax(a,b)
  %6245 = call float @dx.op.binary.f32(i32 35, float %6242, float %6239)  ; FMax(a,b)
  %6246 = call float @dx.op.binary.f32(i32 35, float %6243, float %6240)  ; FMax(a,b)
  %6247 = call float @dx.op.binary.f32(i32 35, float %5062, float %6244)  ; FMax(a,b)
  %6248 = call float @dx.op.binary.f32(i32 35, float %5063, float %6245)  ; FMax(a,b)
  %6249 = call float @dx.op.binary.f32(i32 35, float %5064, float %6246)  ; FMax(a,b)
  %6250 = fsub fast float %6247, %6235
  %6251 = fsub fast float %6248, %6236
  %6252 = fsub fast float %6249, %6237
  %6253 = call float @dx.op.unary.f32(i32 6, float %6250)  ; FAbs(value)
  %6254 = call float @dx.op.unary.f32(i32 6, float %6251)  ; FAbs(value)
  %6255 = call float @dx.op.unary.f32(i32 6, float %6252)  ; FAbs(value)
  %6256 = call float @dx.op.binary.f32(i32 35, float %6254, float %6255)  ; FMax(a,b)
  %6257 = call float @dx.op.binary.f32(i32 35, float %6253, float %6256)  ; FMax(a,b)
  %6258 = call float @dx.op.binary.f32(i32 35, float %6248, float %6249)  ; FMax(a,b)
  %6259 = call float @dx.op.binary.f32(i32 35, float %6247, float %6258)  ; FMax(a,b)
  %6260 = fmul fast float %6259, 1.250000e-01
  %6261 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %6260)  ; FMax(a,b)
  %6262 = fcmp fast ogt float %6257, %6261
  br i1 %6262, label %6263, label %6325

; <label>:6263                                    ; preds = %6222
  %6264 = fsub fast float %5357, %5645
  %6265 = fsub fast float %5358, %5646
  %6266 = fsub fast float %5359, %5647
  %6267 = call float @dx.op.unary.f32(i32 6, float %6264)  ; FAbs(value)
  %6268 = call float @dx.op.unary.f32(i32 6, float %6265)  ; FAbs(value)
  %6269 = call float @dx.op.unary.f32(i32 6, float %6266)  ; FAbs(value)
  %6270 = call float @dx.op.binary.f32(i32 35, float %6268, float %6269)  ; FMax(a,b)
  %6271 = call float @dx.op.binary.f32(i32 35, float %6267, float %6270)  ; FMax(a,b)
  %6272 = fsub fast float %5935, %6223
  %6273 = fsub fast float %5936, %6224
  %6274 = fsub fast float %5937, %6225
  %6275 = call float @dx.op.unary.f32(i32 6, float %6272)  ; FAbs(value)
  %6276 = call float @dx.op.unary.f32(i32 6, float %6273)  ; FAbs(value)
  %6277 = call float @dx.op.unary.f32(i32 6, float %6274)  ; FAbs(value)
  %6278 = call float @dx.op.binary.f32(i32 35, float %6276, float %6277)  ; FMax(a,b)
  %6279 = call float @dx.op.binary.f32(i32 35, float %6275, float %6278)  ; FMax(a,b)
  %6280 = fcmp fast olt float %6271, %6279
  %6281 = select i1 %6280, float %5357, float %5935
  %6282 = select i1 %6280, float %5358, float %5936
  %6283 = select i1 %6280, float %5359, float %5937
  %6284 = select i1 %6280, float %5645, float %6223
  %6285 = select i1 %6280, float %5646, float %6224
  %6286 = select i1 %6280, float %5647, float %6225
  %6287 = fsub fast float %5062, %6284
  %6288 = fsub fast float %5063, %6285
  %6289 = fsub fast float %5064, %6286
  %6290 = fsub fast float %5062, %6281
  %6291 = fsub fast float %5063, %6282
  %6292 = fsub fast float %5064, %6283
  %6293 = call float @dx.op.dot3.f32(i32 55, float %6290, float %6291, float %6292, float %6287, float %6288, float %6289)  ; Dot3(ax,ay,az,bx,by,bz)
  %6294 = fcmp fast ogt float %6293, 0.000000e+00
  br i1 %6294, label %6295, label %6307

; <label>:6295                                    ; preds = %6263
  %6296 = fsub fast float %6281, %6284
  %6297 = fsub fast float %6282, %6285
  %6298 = fsub fast float %6283, %6286
  %6299 = call float @dx.op.unary.f32(i32 6, float %6296)  ; FAbs(value)
  %6300 = call float @dx.op.unary.f32(i32 6, float %6297)  ; FAbs(value)
  %6301 = call float @dx.op.unary.f32(i32 6, float %6298)  ; FAbs(value)
  %6302 = call float @dx.op.binary.f32(i32 35, float %6300, float %6301)  ; FMax(a,b)
  %6303 = call float @dx.op.binary.f32(i32 35, float %6299, float %6302)  ; FMax(a,b)
  %6304 = fmul fast float %6257, 2.500000e-01
  %6305 = fcmp fast olt float %6303, %6304
  %6306 = select i1 %6305, float 5.000000e-01, float 1.000000e+00
  br label %6307

; <label>:6307                                    ; preds = %6295, %6263
  %6308 = phi float [ 1.000000e+00, %6263 ], [ %6306, %6295 ]
  %6309 = fmul fast float %6308, %3
  %6310 = fadd fast float %6281, %6284
  %6311 = fadd fast float %6282, %6285
  %6312 = fadd fast float %6283, %6286
  %6313 = fmul fast float %6310, 5.000000e-01
  %6314 = fmul fast float %6311, 5.000000e-01
  %6315 = fmul fast float %6312, 5.000000e-01
  %6316 = fsub fast float %6313, %5062
  %6317 = fsub fast float %6314, %5063
  %6318 = fsub fast float %6315, %5064
  %6319 = fmul fast float %6309, %6316
  %6320 = fmul fast float %6309, %6317
  %6321 = fmul fast float %6309, %6318
  %6322 = fadd fast float %6319, %5062
  %6323 = fadd fast float %6320, %5063
  %6324 = fadd fast float %6321, %5064
  br label %6325

; <label>:6325                                    ; preds = %6307, %6222, %5033
  %6326 = phi float [ %5062, %5033 ], [ %6322, %6307 ], [ %5062, %6222 ]
  %6327 = phi float [ %5063, %5033 ], [ %6323, %6307 ], [ %5063, %6222 ]
  %6328 = phi float [ %5064, %5033 ], [ %6324, %6307 ], [ %5064, %6222 ]
  %6329 = fcmp fast ogt float %6326, 0x3F69A5C380000000
  %6330 = fcmp fast ogt float %6327, 0x3F69A5C380000000
  %6331 = fcmp fast ogt float %6328, 0x3F69A5C380000000
  %6332 = select i1 %6329, float 0.000000e+00, float 1.000000e+00
  %6333 = select i1 %6330, float 0.000000e+00, float 1.000000e+00
  %6334 = select i1 %6331, float 0.000000e+00, float 1.000000e+00
  %6335 = fmul fast float %6326, 0x4029D70A40000000
  %6336 = fmul fast float %6327, 0x4029D70A40000000
  %6337 = fmul fast float %6328, 0x4029D70A40000000
  %6338 = call float @dx.op.binary.f32(i32 35, float %6326, float 0.000000e+00)  ; FMax(a,b)
  %6339 = call float @dx.op.binary.f32(i32 35, float %6327, float 0.000000e+00)  ; FMax(a,b)
  %6340 = call float @dx.op.binary.f32(i32 35, float %6328, float 0.000000e+00)  ; FMax(a,b)
  %6341 = call float @dx.op.unary.f32(i32 23, float %6338)  ; Log(value)
  %6342 = call float @dx.op.unary.f32(i32 23, float %6339)  ; Log(value)
  %6343 = call float @dx.op.unary.f32(i32 23, float %6340)  ; Log(value)
  %6344 = fmul fast float %6341, 0x3FDAAAAAA0000000
  %6345 = fmul fast float %6342, 0x3FDAAAAAA0000000
  %6346 = fmul fast float %6343, 0x3FDAAAAAA0000000
  %6347 = call float @dx.op.unary.f32(i32 21, float %6344)  ; Exp(value)
  %6348 = call float @dx.op.unary.f32(i32 21, float %6345)  ; Exp(value)
  %6349 = call float @dx.op.unary.f32(i32 21, float %6346)  ; Exp(value)
  %6350 = fmul fast float %6347, 0x3FF0E147A0000000
  %6351 = fmul fast float %6348, 0x3FF0E147A0000000
  %6352 = fmul fast float %6349, 0x3FF0E147A0000000
  %6353 = fadd fast float %6350, 0xBFAC28F5C0000000
  %6354 = fadd fast float %6351, 0xBFAC28F5C0000000
  %6355 = fadd fast float %6352, 0xBFAC28F5C0000000
  %6356 = fsub fast float %6335, %6353
  %6357 = fsub fast float %6336, %6354
  %6358 = fsub fast float %6337, %6355
  %6359 = fmul fast float %6356, %6332
  %6360 = fmul fast float %6357, %6333
  %6361 = fmul fast float %6358, %6334
  %6362 = fadd fast float %6359, %6353
  %6363 = fadd fast float %6360, %6354
  %6364 = fadd fast float %6361, %6355
  br label %6365

; <label>:6365                                    ; preds = %6325, %4850
  %6366 = phi float [ %4845, %4850 ], [ %6362, %6325 ]
  %6367 = phi float [ %4846, %4850 ], [ %6363, %6325 ]
  %6368 = phi float [ %4847, %4850 ], [ %6364, %6325 ]
  %6369 = phi float [ %4851, %4850 ], [ %4848, %6325 ]
  %6370 = fcmp fast ogt float %6366, 0x3FA4B5DCC0000000
  %6371 = fcmp fast ogt float %6367, 0x3FA4B5DCC0000000
  %6372 = fcmp fast ogt float %6368, 0x3FA4B5DCC0000000
  %6373 = select i1 %6370, float 0.000000e+00, float 1.000000e+00
  %6374 = select i1 %6371, float 0.000000e+00, float 1.000000e+00
  %6375 = select i1 %6372, float 0.000000e+00, float 1.000000e+00
  %6376 = fmul fast float %6366, 0x3FB3D07220000000
  %6377 = fmul fast float %6367, 0x3FB3D07220000000
  %6378 = fmul fast float %6368, 0x3FB3D07220000000
  %6379 = fadd fast float %6366, 0x3FAC28F5C0000000
  %6380 = fadd fast float %6367, 0x3FAC28F5C0000000
  %6381 = fadd fast float %6368, 0x3FAC28F5C0000000
  %6382 = fmul fast float %6379, 0x3FEE54EDE0000000
  %6383 = fmul fast float %6380, 0x3FEE54EDE0000000
  %6384 = fmul fast float %6381, 0x3FEE54EDE0000000
  %6385 = call float @dx.op.unary.f32(i32 23, float %6382)  ; Log(value)
  %6386 = call float @dx.op.unary.f32(i32 23, float %6383)  ; Log(value)
  %6387 = call float @dx.op.unary.f32(i32 23, float %6384)  ; Log(value)
  %6388 = fmul fast float %6385, 0x4003333340000000
  %6389 = fmul fast float %6386, 0x4003333340000000
  %6390 = fmul fast float %6387, 0x4003333340000000
  %6391 = call float @dx.op.unary.f32(i32 21, float %6388)  ; Exp(value)
  %6392 = call float @dx.op.unary.f32(i32 21, float %6389)  ; Exp(value)
  %6393 = call float @dx.op.unary.f32(i32 21, float %6390)  ; Exp(value)
  %6394 = fsub fast float %6376, %6391
  %6395 = fsub fast float %6377, %6392
  %6396 = fsub fast float %6378, %6393
  %6397 = fmul fast float %6394, %6373
  %6398 = fmul fast float %6395, %6374
  %6399 = fmul fast float %6396, %6375
  %6400 = fadd fast float %6397, %6391
  %6401 = fadd fast float %6398, %6392
  %6402 = fadd fast float %6399, %6393
  %6403 = fmul fast float %1723, %163
  %6404 = fmul fast float %1724, %163
  %6405 = fmul fast float %1725, %163
  %6406 = fmul fast float %3282, %164
  %6407 = fmul fast float %3283, %164
  %6408 = fmul fast float %3284, %164
  %6409 = fadd fast float %6406, %6403
  %6410 = fadd fast float %6407, %6404
  %6411 = fadd fast float %6408, %6405
  %6412 = fmul fast float %4841, %165
  %6413 = fmul fast float %4842, %165
  %6414 = fmul fast float %4843, %165
  %6415 = fadd fast float %6409, %6412
  %6416 = fadd fast float %6410, %6413
  %6417 = fadd fast float %6411, %6414
  %6418 = fmul fast float %6400, %166
  %6419 = fmul fast float %6401, %166
  %6420 = fmul fast float %6402, %166
  %6421 = fadd fast float %6415, %6418
  %6422 = fadd fast float %6416, %6419
  %6423 = fadd fast float %6417, %6420
  %6424 = fcmp fast ogt float %6421, 0x3F69A5C380000000
  %6425 = fcmp fast ogt float %6422, 0x3F69A5C380000000
  %6426 = fcmp fast ogt float %6423, 0x3F69A5C380000000
  %6427 = select i1 %6424, float 0.000000e+00, float 1.000000e+00
  %6428 = select i1 %6425, float 0.000000e+00, float 1.000000e+00
  %6429 = select i1 %6426, float 0.000000e+00, float 1.000000e+00
  %6430 = fmul fast float %6421, 0x4029D70A40000000
  %6431 = fmul fast float %6422, 0x4029D70A40000000
  %6432 = fmul fast float %6423, 0x4029D70A40000000
  %6433 = call float @dx.op.binary.f32(i32 35, float %6421, float 0.000000e+00)  ; FMax(a,b)
  %6434 = call float @dx.op.binary.f32(i32 35, float %6422, float 0.000000e+00)  ; FMax(a,b)
  %6435 = call float @dx.op.binary.f32(i32 35, float %6423, float 0.000000e+00)  ; FMax(a,b)
  %6436 = call float @dx.op.unary.f32(i32 23, float %6433)  ; Log(value)
  %6437 = call float @dx.op.unary.f32(i32 23, float %6434)  ; Log(value)
  %6438 = call float @dx.op.unary.f32(i32 23, float %6435)  ; Log(value)
  %6439 = fmul fast float %6436, 0x3FDAAAAAA0000000
  %6440 = fmul fast float %6437, 0x3FDAAAAAA0000000
  %6441 = fmul fast float %6438, 0x3FDAAAAAA0000000
  %6442 = call float @dx.op.unary.f32(i32 21, float %6439)  ; Exp(value)
  %6443 = call float @dx.op.unary.f32(i32 21, float %6440)  ; Exp(value)
  %6444 = call float @dx.op.unary.f32(i32 21, float %6441)  ; Exp(value)
  %6445 = fmul fast float %6442, 0x3FF0E147A0000000
  %6446 = fmul fast float %6443, 0x3FF0E147A0000000
  %6447 = fmul fast float %6444, 0x3FF0E147A0000000
  %6448 = fadd fast float %6445, 0xBFAC28F5C0000000
  %6449 = fadd fast float %6446, 0xBFAC28F5C0000000
  %6450 = fadd fast float %6447, 0xBFAC28F5C0000000
  %6451 = fsub fast float %6430, %6448
  %6452 = fsub fast float %6431, %6449
  %6453 = fsub fast float %6432, %6450
  %6454 = fmul fast float %6451, %6427
  %6455 = fmul fast float %6452, %6428
  %6456 = fmul fast float %6453, %6429
  %6457 = fadd fast float %6454, %6448
  %6458 = fadd fast float %6455, %6449
  %6459 = fadd fast float %6456, %6450
  %6460 = call float @dx.op.dot4.f32(i32 56, float %1692, float %3251, float %4810, float %6369, float %163, float %164, float %165, float %166)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %6457)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %6458)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %6459)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %6460)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %81)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare i1 @dx.op.isSpecialFloat.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !37, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, !28}
!36 = !{i32 9}
!37 = !{!38, !39}
!38 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
!39 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !40}
!40 = !{i32 3, i32 1}
