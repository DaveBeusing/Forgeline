;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float    yz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: 2617eb91ff74f304570c4230d2a30b8a
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %40 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %41 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %42 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %43 = extractvalue %dx.types.Dimensions %42, 0
  %44 = extractvalue %dx.types.Dimensions %42, 1
  %45 = uitofp i32 %43 to float
  %46 = uitofp i32 %44 to float
  %47 = fmul fast float %45, %40
  %48 = fmul fast float %46, %41
  %49 = fdiv fast float %47, %3
  %50 = fdiv fast float %48, %4
  %51 = fadd fast float %49, -5.000000e-01
  %52 = fadd fast float %50, -5.000000e-01
  %53 = call float @dx.op.unary.f32(i32 27, float %51)  ; Round_ni(value)
  %54 = call float @dx.op.unary.f32(i32 27, float %52)  ; Round_ni(value)
  %55 = fptosi float %53 to i32
  %56 = fptosi float %54 to i32
  %57 = call float @dx.op.unary.f32(i32 22, float %51)  ; Frc(value)
  %58 = call float @dx.op.unary.f32(i32 22, float %52)  ; Frc(value)
  %59 = add i32 %43, -1
  %60 = add i32 %44, -1
  %61 = call i32 @dx.op.binary.i32(i32 37, i32 %55, i32 0)  ; IMax(a,b)
  %62 = call i32 @dx.op.binary.i32(i32 37, i32 %56, i32 0)  ; IMax(a,b)
  %63 = call i32 @dx.op.binary.i32(i32 38, i32 %61, i32 %59)  ; IMin(a,b)
  %64 = call i32 @dx.op.binary.i32(i32 38, i32 %62, i32 %60)  ; IMin(a,b)
  %65 = add i32 %55, 1
  %66 = call i32 @dx.op.binary.i32(i32 37, i32 %65, i32 0)  ; IMax(a,b)
  %67 = call i32 @dx.op.binary.i32(i32 38, i32 %66, i32 %59)  ; IMin(a,b)
  %68 = add i32 %56, 1
  %69 = call i32 @dx.op.binary.i32(i32 37, i32 %68, i32 0)  ; IMax(a,b)
  %70 = call i32 @dx.op.binary.i32(i32 38, i32 %69, i32 %60)  ; IMin(a,b)
  %71 = call float @dx.op.unary.f32(i32 27, float %49)  ; Round_ni(value)
  %72 = call float @dx.op.unary.f32(i32 27, float %50)  ; Round_ni(value)
  %73 = fptosi float %71 to i32
  %74 = fptosi float %72 to i32
  %75 = call i32 @dx.op.binary.i32(i32 37, i32 %73, i32 0)  ; IMax(a,b)
  %76 = call i32 @dx.op.binary.i32(i32 37, i32 %74, i32 0)  ; IMax(a,b)
  %77 = call i32 @dx.op.binary.i32(i32 38, i32 %75, i32 %59)  ; IMin(a,b)
  %78 = call i32 @dx.op.binary.i32(i32 38, i32 %76, i32 %60)  ; IMin(a,b)
  %79 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %77, i32 %78, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %80 = extractvalue %dx.types.ResRet.f32 %79, 0
  %81 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %82 = extractvalue %dx.types.ResRet.f32 %81, 0
  %83 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %67, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %84 = extractvalue %dx.types.ResRet.f32 %83, 0
  %85 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %86 = extractvalue %dx.types.ResRet.f32 %85, 0
  %87 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %67, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %88 = extractvalue %dx.types.ResRet.f32 %87, 0
  %89 = fsub fast float 1.000000e+00, %57
  %90 = fsub fast float 1.000000e+00, %58
  %91 = fmul fast float %90, %89
  %92 = fmul fast float %90, %57
  %93 = fmul fast float %89, %58
  %94 = fmul fast float %58, %57
  %95 = fsub fast float 1.000000e+00, %80
  %96 = fmul fast float %95, 0x3FA99999A0000000
  %97 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %96)  ; FMax(a,b)
  %98 = fsub fast float %82, %80
  %99 = call float @dx.op.unary.f32(i32 6, float %98)  ; FAbs(value)
  %100 = fdiv fast float %99, %97
  %101 = fsub fast float 1.000000e+00, %100
  %102 = call float @dx.op.unary.f32(i32 7, float %101)  ; Saturate(value)
  %103 = fsub fast float %84, %80
  %104 = call float @dx.op.unary.f32(i32 6, float %103)  ; FAbs(value)
  %105 = fdiv fast float %104, %97
  %106 = fsub fast float 1.000000e+00, %105
  %107 = call float @dx.op.unary.f32(i32 7, float %106)  ; Saturate(value)
  %108 = fsub fast float %86, %80
  %109 = call float @dx.op.unary.f32(i32 6, float %108)  ; FAbs(value)
  %110 = fdiv fast float %109, %97
  %111 = fsub fast float 1.000000e+00, %110
  %112 = call float @dx.op.unary.f32(i32 7, float %111)  ; Saturate(value)
  %113 = fsub fast float %88, %80
  %114 = call float @dx.op.unary.f32(i32 6, float %113)  ; FAbs(value)
  %115 = fdiv fast float %114, %97
  %116 = fsub fast float 1.000000e+00, %115
  %117 = call float @dx.op.unary.f32(i32 7, float %116)  ; Saturate(value)
  %118 = fmul fast float %91, %102
  %119 = fmul fast float %92, %107
  %120 = fmul fast float %93, %112
  %121 = fmul fast float %94, %117
  %122 = fcmp fast oge float %57, 5.000000e-01
  %123 = zext i1 %122 to i32
  %124 = fcmp fast oge float %58, 5.000000e-01
  %125 = select i1 %124, i32 2, i32 0
  %126 = or i32 %125, %123
  %127 = call float @dx.op.dot4.f32(i32 56, float %118, float %119, float %120, float %121, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %128 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %118)  ; IsFinite(value)
  %129 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %119)  ; IsFinite(value)
  %130 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %120)  ; IsFinite(value)
  %131 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %121)  ; IsFinite(value)
  %132 = and i1 %128, %129
  %133 = and i1 %132, %130
  %134 = and i1 %133, %131
  br i1 %134, label %135, label %152

; <label>:135                                     ; preds = %0
  %136 = fcmp fast oge float %118, 0.000000e+00
  %137 = fcmp fast oge float %119, 0.000000e+00
  %138 = fcmp fast oge float %120, 0.000000e+00
  %139 = fcmp fast oge float %121, 0.000000e+00
  %140 = and i1 %136, %137
  %141 = and i1 %140, %138
  %142 = and i1 %141, %139
  br i1 %142, label %143, label %152

; <label>:143                                     ; preds = %135
  %144 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %127)  ; IsFinite(value)
  %145 = fcmp fast oge float %127, 0x3810000000000000
  %146 = and i1 %145, %144
  br i1 %146, label %147, label %152

; <label>:147                                     ; preds = %143
  %148 = fdiv fast float %118, %127
  %149 = fdiv fast float %119, %127
  %150 = fdiv fast float %120, %127
  %151 = fdiv fast float %121, %127
  br label %161

; <label>:152                                     ; preds = %143, %135, %0
  %153 = icmp eq i32 %126, 0
  %154 = uitofp i1 %153 to float
  %155 = icmp eq i32 %126, 1
  %156 = uitofp i1 %155 to float
  %157 = icmp eq i32 %126, 2
  %158 = uitofp i1 %157 to float
  %159 = icmp eq i32 %126, 3
  %160 = uitofp i1 %159 to float
  br label %161

; <label>:161                                     ; preds = %152, %147
  %162 = phi float [ %148, %147 ], [ %154, %152 ]
  %163 = phi float [ %149, %147 ], [ %156, %152 ]
  %164 = phi float [ %150, %147 ], [ %158, %152 ]
  %165 = phi float [ %151, %147 ], [ %160, %152 ]
  %166 = or i32 %56, %55
  %167 = icmp sgt i32 %166, -1
  br i1 %167, label %168, label %172

; <label>:168                                     ; preds = %161
  %169 = icmp slt i32 %65, %43
  %170 = icmp slt i32 %68, %44
  %171 = and i1 %169, %170
  br label %172

; <label>:172                                     ; preds = %168, %161
  %173 = phi i1 [ false, %161 ], [ %171, %168 ]
  br i1 %173, label %174, label %3483

; <label>:174                                     ; preds = %172
  %175 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %55, i32 %56, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %176 = extractvalue %dx.types.ResRet.f32 %175, 0
  %177 = extractvalue %dx.types.ResRet.f32 %175, 1
  %178 = extractvalue %dx.types.ResRet.f32 %175, 2
  %179 = extractvalue %dx.types.ResRet.f32 %175, 3
  %180 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %65, i32 %56, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %181 = extractvalue %dx.types.ResRet.f32 %180, 0
  %182 = extractvalue %dx.types.ResRet.f32 %180, 1
  %183 = extractvalue %dx.types.ResRet.f32 %180, 2
  %184 = extractvalue %dx.types.ResRet.f32 %180, 3
  %185 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %55, i32 %68, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %186 = extractvalue %dx.types.ResRet.f32 %185, 0
  %187 = extractvalue %dx.types.ResRet.f32 %185, 1
  %188 = extractvalue %dx.types.ResRet.f32 %185, 2
  %189 = extractvalue %dx.types.ResRet.f32 %185, 3
  %190 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %65, i32 %68, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %191 = extractvalue %dx.types.ResRet.f32 %190, 0
  %192 = extractvalue %dx.types.ResRet.f32 %190, 1
  %193 = extractvalue %dx.types.ResRet.f32 %190, 2
  %194 = extractvalue %dx.types.ResRet.f32 %190, 3
  %195 = fcmp fast olt float %179, 0.000000e+00
  br i1 %195, label %196, label %230

; <label>:196                                     ; preds = %174
  %197 = fcmp fast ogt float %176, 0x3FA4B5DCC0000000
  %198 = fcmp fast ogt float %177, 0x3FA4B5DCC0000000
  %199 = fcmp fast ogt float %178, 0x3FA4B5DCC0000000
  %200 = select i1 %197, float 0.000000e+00, float 1.000000e+00
  %201 = select i1 %198, float 0.000000e+00, float 1.000000e+00
  %202 = select i1 %199, float 0.000000e+00, float 1.000000e+00
  %203 = fmul fast float %176, 0x3FB3D07220000000
  %204 = fmul fast float %177, 0x3FB3D07220000000
  %205 = fmul fast float %178, 0x3FB3D07220000000
  %206 = fadd fast float %176, 0x3FAC28F5C0000000
  %207 = fadd fast float %177, 0x3FAC28F5C0000000
  %208 = fadd fast float %178, 0x3FAC28F5C0000000
  %209 = fmul fast float %206, 0x3FEE54EDE0000000
  %210 = fmul fast float %207, 0x3FEE54EDE0000000
  %211 = fmul fast float %208, 0x3FEE54EDE0000000
  %212 = call float @dx.op.unary.f32(i32 23, float %209)  ; Log(value)
  %213 = call float @dx.op.unary.f32(i32 23, float %210)  ; Log(value)
  %214 = call float @dx.op.unary.f32(i32 23, float %211)  ; Log(value)
  %215 = fmul fast float %212, 0x4003333340000000
  %216 = fmul fast float %213, 0x4003333340000000
  %217 = fmul fast float %214, 0x4003333340000000
  %218 = call float @dx.op.unary.f32(i32 21, float %215)  ; Exp(value)
  %219 = call float @dx.op.unary.f32(i32 21, float %216)  ; Exp(value)
  %220 = call float @dx.op.unary.f32(i32 21, float %217)  ; Exp(value)
  %221 = fsub fast float %203, %218
  %222 = fsub fast float %204, %219
  %223 = fsub fast float %205, %220
  %224 = fmul fast float %221, %200
  %225 = fmul fast float %222, %201
  %226 = fmul fast float %223, %202
  %227 = fadd fast float %224, %218
  %228 = fadd fast float %225, %219
  %229 = fadd fast float %226, %220
  br label %393

; <label>:230                                     ; preds = %174
  %231 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %55, i32 %56, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %232 = extractvalue %dx.types.ResRet.f32 %231, 0
  %233 = fcmp fast ogt float %38, 5.000000e-01
  %234 = fcmp fast olt float %232, 1.000000e+00
  %235 = and i1 %233, %234
  br i1 %235, label %236, label %322

; <label>:236                                     ; preds = %230
  %237 = sitofp i32 %55 to float
  %238 = sitofp i32 %56 to float
  %239 = fadd fast float %237, 5.000000e-01
  %240 = fadd fast float %238, 5.000000e-01
  %241 = fdiv fast float %239, %45
  %242 = fdiv fast float %240, %46
  %243 = fmul fast float %241, 2.000000e+00
  %244 = fmul fast float %242, 2.000000e+00
  %245 = fadd fast float %243, -1.000000e+00
  %246 = fsub fast float 1.000000e+00, %244
  %247 = fmul fast float %245, %35
  %248 = call float @dx.op.tertiary.f32(i32 46, float %246, float %31, float %247)  ; FMad(a,b,c)
  %249 = call float @dx.op.tertiary.f32(i32 46, float %232, float %27, float %248)  ; FMad(a,b,c)
  %250 = fadd fast float %249, %23
  %251 = call float @dx.op.unary.f32(i32 6, float %250)  ; FAbs(value)
  %252 = fcmp fast ogt float %251, 0x3EB0C6F7A0000000
  br i1 %252, label %253, label %322

; <label>:253                                     ; preds = %236
  %254 = fmul fast float %245, %34
  %255 = call float @dx.op.tertiary.f32(i32 46, float %246, float %30, float %254)  ; FMad(a,b,c)
  %256 = call float @dx.op.tertiary.f32(i32 46, float %232, float %26, float %255)  ; FMad(a,b,c)
  %257 = fadd fast float %256, %22
  %258 = fmul fast float %245, %33
  %259 = call float @dx.op.tertiary.f32(i32 46, float %246, float %29, float %258)  ; FMad(a,b,c)
  %260 = call float @dx.op.tertiary.f32(i32 46, float %232, float %25, float %259)  ; FMad(a,b,c)
  %261 = fadd fast float %260, %21
  %262 = fmul fast float %245, %32
  %263 = call float @dx.op.tertiary.f32(i32 46, float %246, float %28, float %262)  ; FMad(a,b,c)
  %264 = call float @dx.op.tertiary.f32(i32 46, float %232, float %24, float %263)  ; FMad(a,b,c)
  %265 = fadd fast float %264, %20
  %266 = fdiv fast float %265, %250
  %267 = fdiv fast float %261, %250
  %268 = fdiv fast float %257, %250
  %269 = fsub fast float %266, %17
  %270 = fsub fast float %267, %18
  %271 = fsub fast float %268, %19
  %272 = fmul fast float %269, %269
  %273 = fmul fast float %270, %270
  %274 = fadd fast float %273, %272
  %275 = fmul fast float %271, %271
  %276 = fadd fast float %274, %275
  %277 = call float @dx.op.unary.f32(i32 24, float %276)  ; Sqrt(value)
  %278 = fsub fast float %277, %9
  %279 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %278)  ; FMax(a,b)
  %280 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %280, label %281, label %304

; <label>:281                                     ; preds = %253
  %282 = call float @dx.op.unary.f32(i32 6, float %270)  ; FAbs(value)
  %283 = fmul fast float %282, %11
  %284 = fcmp fast olt float %283, 0x3F50624DE0000000
  br i1 %284, label %285, label %288

; <label>:285                                     ; preds = %281
  %286 = fmul fast float %283, 5.000000e-01
  %287 = fsub fast float 1.000000e+00, %286
  br label %293

; <label>:288                                     ; preds = %281
  %289 = fmul fast float %283, 0xBFF7154760000000
  %290 = call float @dx.op.unary.f32(i32 21, float %289)  ; Exp(value)
  %291 = fsub fast float 1.000000e+00, %290
  %292 = fdiv fast float %291, %283
  br label %293

; <label>:293                                     ; preds = %288, %285
  %294 = phi float [ %287, %285 ], [ %292, %288 ]
  %295 = call float @dx.op.binary.f32(i32 36, float %267, float %18)  ; FMin(a,b)
  %296 = fsub fast float %295, %10
  %297 = fmul fast float %11, %296
  %298 = fsub fast float -0.000000e+00, %297
  %299 = call float @dx.op.binary.f32(i32 35, float %298, float -4.000000e+01)  ; FMax(a,b)
  %300 = call float @dx.op.binary.f32(i32 36, float %299, float 5.000000e+00)  ; FMin(a,b)
  %301 = fmul fast float %300, 0x3FF7154760000000
  %302 = call float @dx.op.unary.f32(i32 21, float %301)  ; Exp(value)
  %303 = fmul fast float %302, %294
  br label %304

; <label>:304                                     ; preds = %293, %253
  %305 = phi float [ %303, %293 ], [ 1.000000e+00, %253 ]
  %306 = fmul fast float %279, %16
  %307 = fmul fast float %306, %305
  %308 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %307)  ; FMin(a,b)
  %309 = fmul fast float %308, 0xBFF7154760000000
  %310 = call float @dx.op.unary.f32(i32 21, float %309)  ; Exp(value)
  %311 = fsub fast float 1.000000e+00, %310
  %312 = call float @dx.op.binary.f32(i32 36, float %12, float %311)  ; FMin(a,b)
  %313 = fsub fast float %13, %176
  %314 = fsub fast float %14, %177
  %315 = fsub fast float %15, %178
  %316 = fmul fast float %312, %313
  %317 = fmul fast float %312, %314
  %318 = fmul fast float %312, %315
  %319 = fadd fast float %316, %176
  %320 = fadd fast float %317, %177
  %321 = fadd fast float %318, %178
  br label %322

; <label>:322                                     ; preds = %304, %236, %230
  %323 = phi float [ %319, %304 ], [ %176, %236 ], [ %176, %230 ]
  %324 = phi float [ %320, %304 ], [ %177, %236 ], [ %177, %230 ]
  %325 = phi float [ %321, %304 ], [ %178, %236 ], [ %178, %230 ]
  %326 = fadd fast float %5, 1.000000e+00
  %327 = fadd fast float %6, 1.000000e+00
  %328 = fsub fast float 1.000000e+00, %5
  %329 = fmul fast float %36, %326
  %330 = fmul fast float %36, %327
  %331 = fmul fast float %36, %328
  %332 = fmul fast float %329, %323
  %333 = fmul fast float %330, %324
  %334 = fmul fast float %331, %325
  %335 = fcmp fast ult float %37, 5.000000e-01
  br i1 %335, label %361, label %336

; <label>:336                                     ; preds = %322
  %337 = fmul fast float %332, 0x4004147AE0000000
  %338 = fmul fast float %333, 0x4004147AE0000000
  %339 = fmul fast float %334, 0x4004147AE0000000
  %340 = fadd fast float %337, 0x3F9EB851E0000000
  %341 = fadd fast float %338, 0x3F9EB851E0000000
  %342 = fadd fast float %339, 0x3F9EB851E0000000
  %343 = fmul fast float %340, %332
  %344 = fmul fast float %341, %333
  %345 = fmul fast float %342, %334
  %346 = fmul fast float %332, 0x400370A3E0000000
  %347 = fmul fast float %333, 0x400370A3E0000000
  %348 = fmul fast float %334, 0x400370A3E0000000
  %349 = fadd fast float %346, 0x3FE2E147A0000000
  %350 = fadd fast float %347, 0x3FE2E147A0000000
  %351 = fadd fast float %348, 0x3FE2E147A0000000
  %352 = fmul fast float %349, %332
  %353 = fmul fast float %350, %333
  %354 = fmul fast float %351, %334
  %355 = fadd fast float %352, 0x3FC1EB8520000000
  %356 = fadd fast float %353, 0x3FC1EB8520000000
  %357 = fadd fast float %354, 0x3FC1EB8520000000
  %358 = fdiv fast float %343, %355
  %359 = fdiv fast float %344, %356
  %360 = fdiv fast float %345, %357
  br label %361

; <label>:361                                     ; preds = %336, %322
  %362 = phi float [ %358, %336 ], [ %332, %322 ]
  %363 = phi float [ %359, %336 ], [ %333, %322 ]
  %364 = phi float [ %360, %336 ], [ %334, %322 ]
  %365 = call float @dx.op.unary.f32(i32 7, float %362)  ; Saturate(value)
  %366 = call float @dx.op.unary.f32(i32 7, float %363)  ; Saturate(value)
  %367 = call float @dx.op.unary.f32(i32 7, float %364)  ; Saturate(value)
  %368 = call float @dx.op.dot3.f32(i32 55, float %365, float %366, float %367, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %369 = fsub fast float %365, %368
  %370 = fsub fast float %366, %368
  %371 = fsub fast float %367, %368
  %372 = fmul fast float %369, %8
  %373 = fmul fast float %370, %8
  %374 = fmul fast float %371, %8
  %375 = fadd fast float %372, %368
  %376 = fadd fast float %373, %368
  %377 = fadd fast float %374, %368
  %378 = call float @dx.op.unary.f32(i32 7, float %375)  ; Saturate(value)
  %379 = call float @dx.op.unary.f32(i32 7, float %376)  ; Saturate(value)
  %380 = call float @dx.op.unary.f32(i32 7, float %377)  ; Saturate(value)
  %381 = fadd fast float %378, 0xBFC70A3D80000000
  %382 = fadd fast float %379, 0xBFC70A3D80000000
  %383 = fadd fast float %380, 0xBFC70A3D80000000
  %384 = fmul fast float %381, %7
  %385 = fmul fast float %382, %7
  %386 = fmul fast float %383, %7
  %387 = fadd fast float %384, 0x3FC70A3D80000000
  %388 = fadd fast float %385, 0x3FC70A3D80000000
  %389 = fadd fast float %386, 0x3FC70A3D80000000
  %390 = call float @dx.op.unary.f32(i32 7, float %387)  ; Saturate(value)
  %391 = call float @dx.op.unary.f32(i32 7, float %388)  ; Saturate(value)
  %392 = call float @dx.op.unary.f32(i32 7, float %389)  ; Saturate(value)
  br label %393

; <label>:393                                     ; preds = %361, %196
  %394 = phi float [ %227, %196 ], [ %390, %361 ]
  %395 = phi float [ %228, %196 ], [ %391, %361 ]
  %396 = phi float [ %229, %196 ], [ %392, %361 ]
  %397 = fcmp fast olt float %184, 0.000000e+00
  br i1 %397, label %398, label %432

; <label>:398                                     ; preds = %393
  %399 = fcmp fast ogt float %181, 0x3FA4B5DCC0000000
  %400 = fcmp fast ogt float %182, 0x3FA4B5DCC0000000
  %401 = fcmp fast ogt float %183, 0x3FA4B5DCC0000000
  %402 = select i1 %399, float 0.000000e+00, float 1.000000e+00
  %403 = select i1 %400, float 0.000000e+00, float 1.000000e+00
  %404 = select i1 %401, float 0.000000e+00, float 1.000000e+00
  %405 = fmul fast float %181, 0x3FB3D07220000000
  %406 = fmul fast float %182, 0x3FB3D07220000000
  %407 = fmul fast float %183, 0x3FB3D07220000000
  %408 = fadd fast float %181, 0x3FAC28F5C0000000
  %409 = fadd fast float %182, 0x3FAC28F5C0000000
  %410 = fadd fast float %183, 0x3FAC28F5C0000000
  %411 = fmul fast float %408, 0x3FEE54EDE0000000
  %412 = fmul fast float %409, 0x3FEE54EDE0000000
  %413 = fmul fast float %410, 0x3FEE54EDE0000000
  %414 = call float @dx.op.unary.f32(i32 23, float %411)  ; Log(value)
  %415 = call float @dx.op.unary.f32(i32 23, float %412)  ; Log(value)
  %416 = call float @dx.op.unary.f32(i32 23, float %413)  ; Log(value)
  %417 = fmul fast float %414, 0x4003333340000000
  %418 = fmul fast float %415, 0x4003333340000000
  %419 = fmul fast float %416, 0x4003333340000000
  %420 = call float @dx.op.unary.f32(i32 21, float %417)  ; Exp(value)
  %421 = call float @dx.op.unary.f32(i32 21, float %418)  ; Exp(value)
  %422 = call float @dx.op.unary.f32(i32 21, float %419)  ; Exp(value)
  %423 = fsub fast float %405, %420
  %424 = fsub fast float %406, %421
  %425 = fsub fast float %407, %422
  %426 = fmul fast float %423, %402
  %427 = fmul fast float %424, %403
  %428 = fmul fast float %425, %404
  %429 = fadd fast float %426, %420
  %430 = fadd fast float %427, %421
  %431 = fadd fast float %428, %422
  br label %595

; <label>:432                                     ; preds = %393
  %433 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %65, i32 %56, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %434 = extractvalue %dx.types.ResRet.f32 %433, 0
  %435 = fcmp fast ogt float %38, 5.000000e-01
  %436 = fcmp fast olt float %434, 1.000000e+00
  %437 = and i1 %435, %436
  br i1 %437, label %438, label %524

; <label>:438                                     ; preds = %432
  %439 = sitofp i32 %65 to float
  %440 = sitofp i32 %56 to float
  %441 = fadd fast float %439, 5.000000e-01
  %442 = fadd fast float %440, 5.000000e-01
  %443 = fdiv fast float %441, %45
  %444 = fdiv fast float %442, %46
  %445 = fmul fast float %443, 2.000000e+00
  %446 = fmul fast float %444, 2.000000e+00
  %447 = fadd fast float %445, -1.000000e+00
  %448 = fsub fast float 1.000000e+00, %446
  %449 = fmul fast float %447, %35
  %450 = call float @dx.op.tertiary.f32(i32 46, float %448, float %31, float %449)  ; FMad(a,b,c)
  %451 = call float @dx.op.tertiary.f32(i32 46, float %434, float %27, float %450)  ; FMad(a,b,c)
  %452 = fadd fast float %451, %23
  %453 = call float @dx.op.unary.f32(i32 6, float %452)  ; FAbs(value)
  %454 = fcmp fast ogt float %453, 0x3EB0C6F7A0000000
  br i1 %454, label %455, label %524

; <label>:455                                     ; preds = %438
  %456 = fmul fast float %447, %34
  %457 = call float @dx.op.tertiary.f32(i32 46, float %448, float %30, float %456)  ; FMad(a,b,c)
  %458 = call float @dx.op.tertiary.f32(i32 46, float %434, float %26, float %457)  ; FMad(a,b,c)
  %459 = fadd fast float %458, %22
  %460 = fmul fast float %447, %33
  %461 = call float @dx.op.tertiary.f32(i32 46, float %448, float %29, float %460)  ; FMad(a,b,c)
  %462 = call float @dx.op.tertiary.f32(i32 46, float %434, float %25, float %461)  ; FMad(a,b,c)
  %463 = fadd fast float %462, %21
  %464 = fmul fast float %447, %32
  %465 = call float @dx.op.tertiary.f32(i32 46, float %448, float %28, float %464)  ; FMad(a,b,c)
  %466 = call float @dx.op.tertiary.f32(i32 46, float %434, float %24, float %465)  ; FMad(a,b,c)
  %467 = fadd fast float %466, %20
  %468 = fdiv fast float %467, %452
  %469 = fdiv fast float %463, %452
  %470 = fdiv fast float %459, %452
  %471 = fsub fast float %468, %17
  %472 = fsub fast float %469, %18
  %473 = fsub fast float %470, %19
  %474 = fmul fast float %471, %471
  %475 = fmul fast float %472, %472
  %476 = fadd fast float %475, %474
  %477 = fmul fast float %473, %473
  %478 = fadd fast float %476, %477
  %479 = call float @dx.op.unary.f32(i32 24, float %478)  ; Sqrt(value)
  %480 = fsub fast float %479, %9
  %481 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %480)  ; FMax(a,b)
  %482 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %482, label %483, label %506

; <label>:483                                     ; preds = %455
  %484 = call float @dx.op.unary.f32(i32 6, float %472)  ; FAbs(value)
  %485 = fmul fast float %484, %11
  %486 = fcmp fast olt float %485, 0x3F50624DE0000000
  br i1 %486, label %487, label %490

; <label>:487                                     ; preds = %483
  %488 = fmul fast float %485, 5.000000e-01
  %489 = fsub fast float 1.000000e+00, %488
  br label %495

; <label>:490                                     ; preds = %483
  %491 = fmul fast float %485, 0xBFF7154760000000
  %492 = call float @dx.op.unary.f32(i32 21, float %491)  ; Exp(value)
  %493 = fsub fast float 1.000000e+00, %492
  %494 = fdiv fast float %493, %485
  br label %495

; <label>:495                                     ; preds = %490, %487
  %496 = phi float [ %489, %487 ], [ %494, %490 ]
  %497 = call float @dx.op.binary.f32(i32 36, float %469, float %18)  ; FMin(a,b)
  %498 = fsub fast float %497, %10
  %499 = fmul fast float %11, %498
  %500 = fsub fast float -0.000000e+00, %499
  %501 = call float @dx.op.binary.f32(i32 35, float %500, float -4.000000e+01)  ; FMax(a,b)
  %502 = call float @dx.op.binary.f32(i32 36, float %501, float 5.000000e+00)  ; FMin(a,b)
  %503 = fmul fast float %502, 0x3FF7154760000000
  %504 = call float @dx.op.unary.f32(i32 21, float %503)  ; Exp(value)
  %505 = fmul fast float %504, %496
  br label %506

; <label>:506                                     ; preds = %495, %455
  %507 = phi float [ %505, %495 ], [ 1.000000e+00, %455 ]
  %508 = fmul fast float %481, %16
  %509 = fmul fast float %508, %507
  %510 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %509)  ; FMin(a,b)
  %511 = fmul fast float %510, 0xBFF7154760000000
  %512 = call float @dx.op.unary.f32(i32 21, float %511)  ; Exp(value)
  %513 = fsub fast float 1.000000e+00, %512
  %514 = call float @dx.op.binary.f32(i32 36, float %12, float %513)  ; FMin(a,b)
  %515 = fsub fast float %13, %181
  %516 = fsub fast float %14, %182
  %517 = fsub fast float %15, %183
  %518 = fmul fast float %514, %515
  %519 = fmul fast float %514, %516
  %520 = fmul fast float %514, %517
  %521 = fadd fast float %518, %181
  %522 = fadd fast float %519, %182
  %523 = fadd fast float %520, %183
  br label %524

; <label>:524                                     ; preds = %506, %438, %432
  %525 = phi float [ %521, %506 ], [ %181, %438 ], [ %181, %432 ]
  %526 = phi float [ %522, %506 ], [ %182, %438 ], [ %182, %432 ]
  %527 = phi float [ %523, %506 ], [ %183, %438 ], [ %183, %432 ]
  %528 = fadd fast float %5, 1.000000e+00
  %529 = fadd fast float %6, 1.000000e+00
  %530 = fsub fast float 1.000000e+00, %5
  %531 = fmul fast float %36, %528
  %532 = fmul fast float %36, %529
  %533 = fmul fast float %36, %530
  %534 = fmul fast float %531, %525
  %535 = fmul fast float %532, %526
  %536 = fmul fast float %533, %527
  %537 = fcmp fast ult float %37, 5.000000e-01
  br i1 %537, label %563, label %538

; <label>:538                                     ; preds = %524
  %539 = fmul fast float %534, 0x4004147AE0000000
  %540 = fmul fast float %535, 0x4004147AE0000000
  %541 = fmul fast float %536, 0x4004147AE0000000
  %542 = fadd fast float %539, 0x3F9EB851E0000000
  %543 = fadd fast float %540, 0x3F9EB851E0000000
  %544 = fadd fast float %541, 0x3F9EB851E0000000
  %545 = fmul fast float %542, %534
  %546 = fmul fast float %543, %535
  %547 = fmul fast float %544, %536
  %548 = fmul fast float %534, 0x400370A3E0000000
  %549 = fmul fast float %535, 0x400370A3E0000000
  %550 = fmul fast float %536, 0x400370A3E0000000
  %551 = fadd fast float %548, 0x3FE2E147A0000000
  %552 = fadd fast float %549, 0x3FE2E147A0000000
  %553 = fadd fast float %550, 0x3FE2E147A0000000
  %554 = fmul fast float %551, %534
  %555 = fmul fast float %552, %535
  %556 = fmul fast float %553, %536
  %557 = fadd fast float %554, 0x3FC1EB8520000000
  %558 = fadd fast float %555, 0x3FC1EB8520000000
  %559 = fadd fast float %556, 0x3FC1EB8520000000
  %560 = fdiv fast float %545, %557
  %561 = fdiv fast float %546, %558
  %562 = fdiv fast float %547, %559
  br label %563

; <label>:563                                     ; preds = %538, %524
  %564 = phi float [ %560, %538 ], [ %534, %524 ]
  %565 = phi float [ %561, %538 ], [ %535, %524 ]
  %566 = phi float [ %562, %538 ], [ %536, %524 ]
  %567 = call float @dx.op.unary.f32(i32 7, float %564)  ; Saturate(value)
  %568 = call float @dx.op.unary.f32(i32 7, float %565)  ; Saturate(value)
  %569 = call float @dx.op.unary.f32(i32 7, float %566)  ; Saturate(value)
  %570 = call float @dx.op.dot3.f32(i32 55, float %567, float %568, float %569, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %571 = fsub fast float %567, %570
  %572 = fsub fast float %568, %570
  %573 = fsub fast float %569, %570
  %574 = fmul fast float %571, %8
  %575 = fmul fast float %572, %8
  %576 = fmul fast float %573, %8
  %577 = fadd fast float %574, %570
  %578 = fadd fast float %575, %570
  %579 = fadd fast float %576, %570
  %580 = call float @dx.op.unary.f32(i32 7, float %577)  ; Saturate(value)
  %581 = call float @dx.op.unary.f32(i32 7, float %578)  ; Saturate(value)
  %582 = call float @dx.op.unary.f32(i32 7, float %579)  ; Saturate(value)
  %583 = fadd fast float %580, 0xBFC70A3D80000000
  %584 = fadd fast float %581, 0xBFC70A3D80000000
  %585 = fadd fast float %582, 0xBFC70A3D80000000
  %586 = fmul fast float %583, %7
  %587 = fmul fast float %584, %7
  %588 = fmul fast float %585, %7
  %589 = fadd fast float %586, 0x3FC70A3D80000000
  %590 = fadd fast float %587, 0x3FC70A3D80000000
  %591 = fadd fast float %588, 0x3FC70A3D80000000
  %592 = call float @dx.op.unary.f32(i32 7, float %589)  ; Saturate(value)
  %593 = call float @dx.op.unary.f32(i32 7, float %590)  ; Saturate(value)
  %594 = call float @dx.op.unary.f32(i32 7, float %591)  ; Saturate(value)
  br label %595

; <label>:595                                     ; preds = %563, %398
  %596 = phi float [ %429, %398 ], [ %592, %563 ]
  %597 = phi float [ %430, %398 ], [ %593, %563 ]
  %598 = phi float [ %431, %398 ], [ %594, %563 ]
  %599 = fcmp fast olt float %189, 0.000000e+00
  br i1 %599, label %600, label %634

; <label>:600                                     ; preds = %595
  %601 = fcmp fast ogt float %186, 0x3FA4B5DCC0000000
  %602 = fcmp fast ogt float %187, 0x3FA4B5DCC0000000
  %603 = fcmp fast ogt float %188, 0x3FA4B5DCC0000000
  %604 = select i1 %601, float 0.000000e+00, float 1.000000e+00
  %605 = select i1 %602, float 0.000000e+00, float 1.000000e+00
  %606 = select i1 %603, float 0.000000e+00, float 1.000000e+00
  %607 = fmul fast float %186, 0x3FB3D07220000000
  %608 = fmul fast float %187, 0x3FB3D07220000000
  %609 = fmul fast float %188, 0x3FB3D07220000000
  %610 = fadd fast float %186, 0x3FAC28F5C0000000
  %611 = fadd fast float %187, 0x3FAC28F5C0000000
  %612 = fadd fast float %188, 0x3FAC28F5C0000000
  %613 = fmul fast float %610, 0x3FEE54EDE0000000
  %614 = fmul fast float %611, 0x3FEE54EDE0000000
  %615 = fmul fast float %612, 0x3FEE54EDE0000000
  %616 = call float @dx.op.unary.f32(i32 23, float %613)  ; Log(value)
  %617 = call float @dx.op.unary.f32(i32 23, float %614)  ; Log(value)
  %618 = call float @dx.op.unary.f32(i32 23, float %615)  ; Log(value)
  %619 = fmul fast float %616, 0x4003333340000000
  %620 = fmul fast float %617, 0x4003333340000000
  %621 = fmul fast float %618, 0x4003333340000000
  %622 = call float @dx.op.unary.f32(i32 21, float %619)  ; Exp(value)
  %623 = call float @dx.op.unary.f32(i32 21, float %620)  ; Exp(value)
  %624 = call float @dx.op.unary.f32(i32 21, float %621)  ; Exp(value)
  %625 = fsub fast float %607, %622
  %626 = fsub fast float %608, %623
  %627 = fsub fast float %609, %624
  %628 = fmul fast float %625, %604
  %629 = fmul fast float %626, %605
  %630 = fmul fast float %627, %606
  %631 = fadd fast float %628, %622
  %632 = fadd fast float %629, %623
  %633 = fadd fast float %630, %624
  br label %797

; <label>:634                                     ; preds = %595
  %635 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %55, i32 %68, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %636 = extractvalue %dx.types.ResRet.f32 %635, 0
  %637 = fcmp fast ogt float %38, 5.000000e-01
  %638 = fcmp fast olt float %636, 1.000000e+00
  %639 = and i1 %637, %638
  br i1 %639, label %640, label %726

; <label>:640                                     ; preds = %634
  %641 = sitofp i32 %55 to float
  %642 = sitofp i32 %68 to float
  %643 = fadd fast float %641, 5.000000e-01
  %644 = fadd fast float %642, 5.000000e-01
  %645 = fdiv fast float %643, %45
  %646 = fdiv fast float %644, %46
  %647 = fmul fast float %645, 2.000000e+00
  %648 = fmul fast float %646, 2.000000e+00
  %649 = fadd fast float %647, -1.000000e+00
  %650 = fsub fast float 1.000000e+00, %648
  %651 = fmul fast float %649, %35
  %652 = call float @dx.op.tertiary.f32(i32 46, float %650, float %31, float %651)  ; FMad(a,b,c)
  %653 = call float @dx.op.tertiary.f32(i32 46, float %636, float %27, float %652)  ; FMad(a,b,c)
  %654 = fadd fast float %653, %23
  %655 = call float @dx.op.unary.f32(i32 6, float %654)  ; FAbs(value)
  %656 = fcmp fast ogt float %655, 0x3EB0C6F7A0000000
  br i1 %656, label %657, label %726

; <label>:657                                     ; preds = %640
  %658 = fmul fast float %649, %34
  %659 = call float @dx.op.tertiary.f32(i32 46, float %650, float %30, float %658)  ; FMad(a,b,c)
  %660 = call float @dx.op.tertiary.f32(i32 46, float %636, float %26, float %659)  ; FMad(a,b,c)
  %661 = fadd fast float %660, %22
  %662 = fmul fast float %649, %33
  %663 = call float @dx.op.tertiary.f32(i32 46, float %650, float %29, float %662)  ; FMad(a,b,c)
  %664 = call float @dx.op.tertiary.f32(i32 46, float %636, float %25, float %663)  ; FMad(a,b,c)
  %665 = fadd fast float %664, %21
  %666 = fmul fast float %649, %32
  %667 = call float @dx.op.tertiary.f32(i32 46, float %650, float %28, float %666)  ; FMad(a,b,c)
  %668 = call float @dx.op.tertiary.f32(i32 46, float %636, float %24, float %667)  ; FMad(a,b,c)
  %669 = fadd fast float %668, %20
  %670 = fdiv fast float %669, %654
  %671 = fdiv fast float %665, %654
  %672 = fdiv fast float %661, %654
  %673 = fsub fast float %670, %17
  %674 = fsub fast float %671, %18
  %675 = fsub fast float %672, %19
  %676 = fmul fast float %673, %673
  %677 = fmul fast float %674, %674
  %678 = fadd fast float %677, %676
  %679 = fmul fast float %675, %675
  %680 = fadd fast float %678, %679
  %681 = call float @dx.op.unary.f32(i32 24, float %680)  ; Sqrt(value)
  %682 = fsub fast float %681, %9
  %683 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %682)  ; FMax(a,b)
  %684 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %684, label %685, label %708

; <label>:685                                     ; preds = %657
  %686 = call float @dx.op.unary.f32(i32 6, float %674)  ; FAbs(value)
  %687 = fmul fast float %686, %11
  %688 = fcmp fast olt float %687, 0x3F50624DE0000000
  br i1 %688, label %689, label %692

; <label>:689                                     ; preds = %685
  %690 = fmul fast float %687, 5.000000e-01
  %691 = fsub fast float 1.000000e+00, %690
  br label %697

; <label>:692                                     ; preds = %685
  %693 = fmul fast float %687, 0xBFF7154760000000
  %694 = call float @dx.op.unary.f32(i32 21, float %693)  ; Exp(value)
  %695 = fsub fast float 1.000000e+00, %694
  %696 = fdiv fast float %695, %687
  br label %697

; <label>:697                                     ; preds = %692, %689
  %698 = phi float [ %691, %689 ], [ %696, %692 ]
  %699 = call float @dx.op.binary.f32(i32 36, float %671, float %18)  ; FMin(a,b)
  %700 = fsub fast float %699, %10
  %701 = fmul fast float %11, %700
  %702 = fsub fast float -0.000000e+00, %701
  %703 = call float @dx.op.binary.f32(i32 35, float %702, float -4.000000e+01)  ; FMax(a,b)
  %704 = call float @dx.op.binary.f32(i32 36, float %703, float 5.000000e+00)  ; FMin(a,b)
  %705 = fmul fast float %704, 0x3FF7154760000000
  %706 = call float @dx.op.unary.f32(i32 21, float %705)  ; Exp(value)
  %707 = fmul fast float %706, %698
  br label %708

; <label>:708                                     ; preds = %697, %657
  %709 = phi float [ %707, %697 ], [ 1.000000e+00, %657 ]
  %710 = fmul fast float %683, %16
  %711 = fmul fast float %710, %709
  %712 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %711)  ; FMin(a,b)
  %713 = fmul fast float %712, 0xBFF7154760000000
  %714 = call float @dx.op.unary.f32(i32 21, float %713)  ; Exp(value)
  %715 = fsub fast float 1.000000e+00, %714
  %716 = call float @dx.op.binary.f32(i32 36, float %12, float %715)  ; FMin(a,b)
  %717 = fsub fast float %13, %186
  %718 = fsub fast float %14, %187
  %719 = fsub fast float %15, %188
  %720 = fmul fast float %716, %717
  %721 = fmul fast float %716, %718
  %722 = fmul fast float %716, %719
  %723 = fadd fast float %720, %186
  %724 = fadd fast float %721, %187
  %725 = fadd fast float %722, %188
  br label %726

; <label>:726                                     ; preds = %708, %640, %634
  %727 = phi float [ %723, %708 ], [ %186, %640 ], [ %186, %634 ]
  %728 = phi float [ %724, %708 ], [ %187, %640 ], [ %187, %634 ]
  %729 = phi float [ %725, %708 ], [ %188, %640 ], [ %188, %634 ]
  %730 = fadd fast float %5, 1.000000e+00
  %731 = fadd fast float %6, 1.000000e+00
  %732 = fsub fast float 1.000000e+00, %5
  %733 = fmul fast float %36, %730
  %734 = fmul fast float %36, %731
  %735 = fmul fast float %36, %732
  %736 = fmul fast float %733, %727
  %737 = fmul fast float %734, %728
  %738 = fmul fast float %735, %729
  %739 = fcmp fast ult float %37, 5.000000e-01
  br i1 %739, label %765, label %740

; <label>:740                                     ; preds = %726
  %741 = fmul fast float %736, 0x4004147AE0000000
  %742 = fmul fast float %737, 0x4004147AE0000000
  %743 = fmul fast float %738, 0x4004147AE0000000
  %744 = fadd fast float %741, 0x3F9EB851E0000000
  %745 = fadd fast float %742, 0x3F9EB851E0000000
  %746 = fadd fast float %743, 0x3F9EB851E0000000
  %747 = fmul fast float %744, %736
  %748 = fmul fast float %745, %737
  %749 = fmul fast float %746, %738
  %750 = fmul fast float %736, 0x400370A3E0000000
  %751 = fmul fast float %737, 0x400370A3E0000000
  %752 = fmul fast float %738, 0x400370A3E0000000
  %753 = fadd fast float %750, 0x3FE2E147A0000000
  %754 = fadd fast float %751, 0x3FE2E147A0000000
  %755 = fadd fast float %752, 0x3FE2E147A0000000
  %756 = fmul fast float %753, %736
  %757 = fmul fast float %754, %737
  %758 = fmul fast float %755, %738
  %759 = fadd fast float %756, 0x3FC1EB8520000000
  %760 = fadd fast float %757, 0x3FC1EB8520000000
  %761 = fadd fast float %758, 0x3FC1EB8520000000
  %762 = fdiv fast float %747, %759
  %763 = fdiv fast float %748, %760
  %764 = fdiv fast float %749, %761
  br label %765

; <label>:765                                     ; preds = %740, %726
  %766 = phi float [ %762, %740 ], [ %736, %726 ]
  %767 = phi float [ %763, %740 ], [ %737, %726 ]
  %768 = phi float [ %764, %740 ], [ %738, %726 ]
  %769 = call float @dx.op.unary.f32(i32 7, float %766)  ; Saturate(value)
  %770 = call float @dx.op.unary.f32(i32 7, float %767)  ; Saturate(value)
  %771 = call float @dx.op.unary.f32(i32 7, float %768)  ; Saturate(value)
  %772 = call float @dx.op.dot3.f32(i32 55, float %769, float %770, float %771, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %773 = fsub fast float %769, %772
  %774 = fsub fast float %770, %772
  %775 = fsub fast float %771, %772
  %776 = fmul fast float %773, %8
  %777 = fmul fast float %774, %8
  %778 = fmul fast float %775, %8
  %779 = fadd fast float %776, %772
  %780 = fadd fast float %777, %772
  %781 = fadd fast float %778, %772
  %782 = call float @dx.op.unary.f32(i32 7, float %779)  ; Saturate(value)
  %783 = call float @dx.op.unary.f32(i32 7, float %780)  ; Saturate(value)
  %784 = call float @dx.op.unary.f32(i32 7, float %781)  ; Saturate(value)
  %785 = fadd fast float %782, 0xBFC70A3D80000000
  %786 = fadd fast float %783, 0xBFC70A3D80000000
  %787 = fadd fast float %784, 0xBFC70A3D80000000
  %788 = fmul fast float %785, %7
  %789 = fmul fast float %786, %7
  %790 = fmul fast float %787, %7
  %791 = fadd fast float %788, 0x3FC70A3D80000000
  %792 = fadd fast float %789, 0x3FC70A3D80000000
  %793 = fadd fast float %790, 0x3FC70A3D80000000
  %794 = call float @dx.op.unary.f32(i32 7, float %791)  ; Saturate(value)
  %795 = call float @dx.op.unary.f32(i32 7, float %792)  ; Saturate(value)
  %796 = call float @dx.op.unary.f32(i32 7, float %793)  ; Saturate(value)
  br label %797

; <label>:797                                     ; preds = %765, %600
  %798 = phi float [ %631, %600 ], [ %794, %765 ]
  %799 = phi float [ %632, %600 ], [ %795, %765 ]
  %800 = phi float [ %633, %600 ], [ %796, %765 ]
  %801 = fcmp fast olt float %194, 0.000000e+00
  br i1 %801, label %802, label %836

; <label>:802                                     ; preds = %797
  %803 = fcmp fast ogt float %191, 0x3FA4B5DCC0000000
  %804 = fcmp fast ogt float %192, 0x3FA4B5DCC0000000
  %805 = fcmp fast ogt float %193, 0x3FA4B5DCC0000000
  %806 = select i1 %803, float 0.000000e+00, float 1.000000e+00
  %807 = select i1 %804, float 0.000000e+00, float 1.000000e+00
  %808 = select i1 %805, float 0.000000e+00, float 1.000000e+00
  %809 = fmul fast float %191, 0x3FB3D07220000000
  %810 = fmul fast float %192, 0x3FB3D07220000000
  %811 = fmul fast float %193, 0x3FB3D07220000000
  %812 = fadd fast float %191, 0x3FAC28F5C0000000
  %813 = fadd fast float %192, 0x3FAC28F5C0000000
  %814 = fadd fast float %193, 0x3FAC28F5C0000000
  %815 = fmul fast float %812, 0x3FEE54EDE0000000
  %816 = fmul fast float %813, 0x3FEE54EDE0000000
  %817 = fmul fast float %814, 0x3FEE54EDE0000000
  %818 = call float @dx.op.unary.f32(i32 23, float %815)  ; Log(value)
  %819 = call float @dx.op.unary.f32(i32 23, float %816)  ; Log(value)
  %820 = call float @dx.op.unary.f32(i32 23, float %817)  ; Log(value)
  %821 = fmul fast float %818, 0x4003333340000000
  %822 = fmul fast float %819, 0x4003333340000000
  %823 = fmul fast float %820, 0x4003333340000000
  %824 = call float @dx.op.unary.f32(i32 21, float %821)  ; Exp(value)
  %825 = call float @dx.op.unary.f32(i32 21, float %822)  ; Exp(value)
  %826 = call float @dx.op.unary.f32(i32 21, float %823)  ; Exp(value)
  %827 = fsub fast float %809, %824
  %828 = fsub fast float %810, %825
  %829 = fsub fast float %811, %826
  %830 = fmul fast float %827, %806
  %831 = fmul fast float %828, %807
  %832 = fmul fast float %829, %808
  %833 = fadd fast float %830, %824
  %834 = fadd fast float %831, %825
  %835 = fadd fast float %832, %826
  br label %999

; <label>:836                                     ; preds = %797
  %837 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %65, i32 %68, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %838 = extractvalue %dx.types.ResRet.f32 %837, 0
  %839 = fcmp fast ogt float %38, 5.000000e-01
  %840 = fcmp fast olt float %838, 1.000000e+00
  %841 = and i1 %839, %840
  br i1 %841, label %842, label %928

; <label>:842                                     ; preds = %836
  %843 = sitofp i32 %65 to float
  %844 = sitofp i32 %68 to float
  %845 = fadd fast float %843, 5.000000e-01
  %846 = fadd fast float %844, 5.000000e-01
  %847 = fdiv fast float %845, %45
  %848 = fdiv fast float %846, %46
  %849 = fmul fast float %847, 2.000000e+00
  %850 = fmul fast float %848, 2.000000e+00
  %851 = fadd fast float %849, -1.000000e+00
  %852 = fsub fast float 1.000000e+00, %850
  %853 = fmul fast float %851, %35
  %854 = call float @dx.op.tertiary.f32(i32 46, float %852, float %31, float %853)  ; FMad(a,b,c)
  %855 = call float @dx.op.tertiary.f32(i32 46, float %838, float %27, float %854)  ; FMad(a,b,c)
  %856 = fadd fast float %855, %23
  %857 = call float @dx.op.unary.f32(i32 6, float %856)  ; FAbs(value)
  %858 = fcmp fast ogt float %857, 0x3EB0C6F7A0000000
  br i1 %858, label %859, label %928

; <label>:859                                     ; preds = %842
  %860 = fmul fast float %851, %34
  %861 = call float @dx.op.tertiary.f32(i32 46, float %852, float %30, float %860)  ; FMad(a,b,c)
  %862 = call float @dx.op.tertiary.f32(i32 46, float %838, float %26, float %861)  ; FMad(a,b,c)
  %863 = fadd fast float %862, %22
  %864 = fmul fast float %851, %33
  %865 = call float @dx.op.tertiary.f32(i32 46, float %852, float %29, float %864)  ; FMad(a,b,c)
  %866 = call float @dx.op.tertiary.f32(i32 46, float %838, float %25, float %865)  ; FMad(a,b,c)
  %867 = fadd fast float %866, %21
  %868 = fmul fast float %851, %32
  %869 = call float @dx.op.tertiary.f32(i32 46, float %852, float %28, float %868)  ; FMad(a,b,c)
  %870 = call float @dx.op.tertiary.f32(i32 46, float %838, float %24, float %869)  ; FMad(a,b,c)
  %871 = fadd fast float %870, %20
  %872 = fdiv fast float %871, %856
  %873 = fdiv fast float %867, %856
  %874 = fdiv fast float %863, %856
  %875 = fsub fast float %872, %17
  %876 = fsub fast float %873, %18
  %877 = fsub fast float %874, %19
  %878 = fmul fast float %875, %875
  %879 = fmul fast float %876, %876
  %880 = fadd fast float %879, %878
  %881 = fmul fast float %877, %877
  %882 = fadd fast float %880, %881
  %883 = call float @dx.op.unary.f32(i32 24, float %882)  ; Sqrt(value)
  %884 = fsub fast float %883, %9
  %885 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %884)  ; FMax(a,b)
  %886 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %886, label %887, label %910

; <label>:887                                     ; preds = %859
  %888 = call float @dx.op.unary.f32(i32 6, float %876)  ; FAbs(value)
  %889 = fmul fast float %888, %11
  %890 = fcmp fast olt float %889, 0x3F50624DE0000000
  br i1 %890, label %891, label %894

; <label>:891                                     ; preds = %887
  %892 = fmul fast float %889, 5.000000e-01
  %893 = fsub fast float 1.000000e+00, %892
  br label %899

; <label>:894                                     ; preds = %887
  %895 = fmul fast float %889, 0xBFF7154760000000
  %896 = call float @dx.op.unary.f32(i32 21, float %895)  ; Exp(value)
  %897 = fsub fast float 1.000000e+00, %896
  %898 = fdiv fast float %897, %889
  br label %899

; <label>:899                                     ; preds = %894, %891
  %900 = phi float [ %893, %891 ], [ %898, %894 ]
  %901 = call float @dx.op.binary.f32(i32 36, float %873, float %18)  ; FMin(a,b)
  %902 = fsub fast float %901, %10
  %903 = fmul fast float %11, %902
  %904 = fsub fast float -0.000000e+00, %903
  %905 = call float @dx.op.binary.f32(i32 35, float %904, float -4.000000e+01)  ; FMax(a,b)
  %906 = call float @dx.op.binary.f32(i32 36, float %905, float 5.000000e+00)  ; FMin(a,b)
  %907 = fmul fast float %906, 0x3FF7154760000000
  %908 = call float @dx.op.unary.f32(i32 21, float %907)  ; Exp(value)
  %909 = fmul fast float %908, %900
  br label %910

; <label>:910                                     ; preds = %899, %859
  %911 = phi float [ %909, %899 ], [ 1.000000e+00, %859 ]
  %912 = fmul fast float %885, %16
  %913 = fmul fast float %912, %911
  %914 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %913)  ; FMin(a,b)
  %915 = fmul fast float %914, 0xBFF7154760000000
  %916 = call float @dx.op.unary.f32(i32 21, float %915)  ; Exp(value)
  %917 = fsub fast float 1.000000e+00, %916
  %918 = call float @dx.op.binary.f32(i32 36, float %12, float %917)  ; FMin(a,b)
  %919 = fsub fast float %13, %191
  %920 = fsub fast float %14, %192
  %921 = fsub fast float %15, %193
  %922 = fmul fast float %918, %919
  %923 = fmul fast float %918, %920
  %924 = fmul fast float %918, %921
  %925 = fadd fast float %922, %191
  %926 = fadd fast float %923, %192
  %927 = fadd fast float %924, %193
  br label %928

; <label>:928                                     ; preds = %910, %842, %836
  %929 = phi float [ %925, %910 ], [ %191, %842 ], [ %191, %836 ]
  %930 = phi float [ %926, %910 ], [ %192, %842 ], [ %192, %836 ]
  %931 = phi float [ %927, %910 ], [ %193, %842 ], [ %193, %836 ]
  %932 = fadd fast float %5, 1.000000e+00
  %933 = fadd fast float %6, 1.000000e+00
  %934 = fsub fast float 1.000000e+00, %5
  %935 = fmul fast float %36, %932
  %936 = fmul fast float %36, %933
  %937 = fmul fast float %36, %934
  %938 = fmul fast float %935, %929
  %939 = fmul fast float %936, %930
  %940 = fmul fast float %937, %931
  %941 = fcmp fast ult float %37, 5.000000e-01
  br i1 %941, label %967, label %942

; <label>:942                                     ; preds = %928
  %943 = fmul fast float %938, 0x4004147AE0000000
  %944 = fmul fast float %939, 0x4004147AE0000000
  %945 = fmul fast float %940, 0x4004147AE0000000
  %946 = fadd fast float %943, 0x3F9EB851E0000000
  %947 = fadd fast float %944, 0x3F9EB851E0000000
  %948 = fadd fast float %945, 0x3F9EB851E0000000
  %949 = fmul fast float %946, %938
  %950 = fmul fast float %947, %939
  %951 = fmul fast float %948, %940
  %952 = fmul fast float %938, 0x400370A3E0000000
  %953 = fmul fast float %939, 0x400370A3E0000000
  %954 = fmul fast float %940, 0x400370A3E0000000
  %955 = fadd fast float %952, 0x3FE2E147A0000000
  %956 = fadd fast float %953, 0x3FE2E147A0000000
  %957 = fadd fast float %954, 0x3FE2E147A0000000
  %958 = fmul fast float %955, %938
  %959 = fmul fast float %956, %939
  %960 = fmul fast float %957, %940
  %961 = fadd fast float %958, 0x3FC1EB8520000000
  %962 = fadd fast float %959, 0x3FC1EB8520000000
  %963 = fadd fast float %960, 0x3FC1EB8520000000
  %964 = fdiv fast float %949, %961
  %965 = fdiv fast float %950, %962
  %966 = fdiv fast float %951, %963
  br label %967

; <label>:967                                     ; preds = %942, %928
  %968 = phi float [ %964, %942 ], [ %938, %928 ]
  %969 = phi float [ %965, %942 ], [ %939, %928 ]
  %970 = phi float [ %966, %942 ], [ %940, %928 ]
  %971 = call float @dx.op.unary.f32(i32 7, float %968)  ; Saturate(value)
  %972 = call float @dx.op.unary.f32(i32 7, float %969)  ; Saturate(value)
  %973 = call float @dx.op.unary.f32(i32 7, float %970)  ; Saturate(value)
  %974 = call float @dx.op.dot3.f32(i32 55, float %971, float %972, float %973, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %975 = fsub fast float %971, %974
  %976 = fsub fast float %972, %974
  %977 = fsub fast float %973, %974
  %978 = fmul fast float %975, %8
  %979 = fmul fast float %976, %8
  %980 = fmul fast float %977, %8
  %981 = fadd fast float %978, %974
  %982 = fadd fast float %979, %974
  %983 = fadd fast float %980, %974
  %984 = call float @dx.op.unary.f32(i32 7, float %981)  ; Saturate(value)
  %985 = call float @dx.op.unary.f32(i32 7, float %982)  ; Saturate(value)
  %986 = call float @dx.op.unary.f32(i32 7, float %983)  ; Saturate(value)
  %987 = fadd fast float %984, 0xBFC70A3D80000000
  %988 = fadd fast float %985, 0xBFC70A3D80000000
  %989 = fadd fast float %986, 0xBFC70A3D80000000
  %990 = fmul fast float %987, %7
  %991 = fmul fast float %988, %7
  %992 = fmul fast float %989, %7
  %993 = fadd fast float %990, 0x3FC70A3D80000000
  %994 = fadd fast float %991, 0x3FC70A3D80000000
  %995 = fadd fast float %992, 0x3FC70A3D80000000
  %996 = call float @dx.op.unary.f32(i32 7, float %993)  ; Saturate(value)
  %997 = call float @dx.op.unary.f32(i32 7, float %994)  ; Saturate(value)
  %998 = call float @dx.op.unary.f32(i32 7, float %995)  ; Saturate(value)
  br label %999

; <label>:999                                     ; preds = %967, %802
  %1000 = phi float [ %833, %802 ], [ %996, %967 ]
  %1001 = phi float [ %834, %802 ], [ %997, %967 ]
  %1002 = phi float [ %835, %802 ], [ %998, %967 ]
  %1003 = fsub fast float -1.000000e+00, %179
  %1004 = select i1 %195, float %1003, float %179
  %1005 = fsub fast float -1.000000e+00, %184
  %1006 = select i1 %397, float %1005, float %184
  %1007 = fsub fast float -1.000000e+00, %189
  %1008 = select i1 %599, float %1007, float %189
  %1009 = fsub fast float -1.000000e+00, %194
  %1010 = select i1 %801, float %1009, float %194
  %1011 = fcmp fast ult float %179, 0.000000e+00
  br i1 %1011, label %1626, label %1012

; <label>:1012                                    ; preds = %999
  %1013 = fsub fast float 1.000000e+00, %82
  %1014 = fmul fast float %1013, 0x3FA99999A0000000
  %1015 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %1014)  ; FMax(a,b)
  %1016 = fsub fast float %84, %82
  %1017 = call float @dx.op.unary.f32(i32 6, float %1016)  ; FAbs(value)
  %1018 = fdiv fast float %1017, %1015
  %1019 = fsub fast float 1.000000e+00, %1018
  %1020 = call float @dx.op.unary.f32(i32 7, float %1019)  ; Saturate(value)
  %1021 = fcmp fast ugt float %1020, 0.000000e+00
  br i1 %1021, label %1022, label %1032

; <label>:1022                                    ; preds = %1012
  %1023 = fsub fast float %596, %394
  %1024 = fsub fast float %597, %395
  %1025 = fsub fast float %598, %396
  %1026 = fmul fast float %1020, %1023
  %1027 = fmul fast float %1020, %1024
  %1028 = fmul fast float %1020, %1025
  %1029 = fadd fast float %1026, %394
  %1030 = fadd fast float %1027, %395
  %1031 = fadd fast float %1028, %396
  br label %1032

; <label>:1032                                    ; preds = %1022, %1012
  %1033 = phi float [ %1029, %1022 ], [ %394, %1012 ]
  %1034 = phi float [ %1030, %1022 ], [ %395, %1012 ]
  %1035 = phi float [ %1031, %1022 ], [ %396, %1012 ]
  %1036 = add i32 %55, -1
  %1037 = call i32 @dx.op.binary.i32(i32 37, i32 %1036, i32 0)  ; IMax(a,b)
  %1038 = call i32 @dx.op.binary.i32(i32 38, i32 %1037, i32 %59)  ; IMin(a,b)
  %1039 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1038, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1040 = extractvalue %dx.types.ResRet.f32 %1039, 0
  %1041 = fsub fast float %1040, %82
  %1042 = call float @dx.op.unary.f32(i32 6, float %1041)  ; FAbs(value)
  %1043 = fdiv fast float %1042, %1015
  %1044 = fsub fast float 1.000000e+00, %1043
  %1045 = call float @dx.op.unary.f32(i32 7, float %1044)  ; Saturate(value)
  %1046 = fcmp fast ugt float %1045, 0.000000e+00
  br i1 %1046, label %1047, label %1268

; <label>:1047                                    ; preds = %1032
  %1048 = call i32 @dx.op.binary.i32(i32 37, i32 %1038, i32 0)  ; IMax(a,b)
  %1049 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %1050 = call i32 @dx.op.binary.i32(i32 38, i32 %1048, i32 %59)  ; IMin(a,b)
  %1051 = call i32 @dx.op.binary.i32(i32 38, i32 %1049, i32 %60)  ; IMin(a,b)
  %1052 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1050, i32 %1051, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1053 = extractvalue %dx.types.ResRet.f32 %1052, 0
  %1054 = extractvalue %dx.types.ResRet.f32 %1052, 1
  %1055 = extractvalue %dx.types.ResRet.f32 %1052, 2
  %1056 = extractvalue %dx.types.ResRet.f32 %1052, 3
  %1057 = fcmp fast olt float %1056, 0.000000e+00
  br i1 %1057, label %1058, label %1092

; <label>:1058                                    ; preds = %1047
  %1059 = fcmp fast ogt float %1053, 0x3FA4B5DCC0000000
  %1060 = fcmp fast ogt float %1054, 0x3FA4B5DCC0000000
  %1061 = fcmp fast ogt float %1055, 0x3FA4B5DCC0000000
  %1062 = select i1 %1059, float 0.000000e+00, float 1.000000e+00
  %1063 = select i1 %1060, float 0.000000e+00, float 1.000000e+00
  %1064 = select i1 %1061, float 0.000000e+00, float 1.000000e+00
  %1065 = fmul fast float %1053, 0x3FB3D07220000000
  %1066 = fmul fast float %1054, 0x3FB3D07220000000
  %1067 = fmul fast float %1055, 0x3FB3D07220000000
  %1068 = fadd fast float %1053, 0x3FAC28F5C0000000
  %1069 = fadd fast float %1054, 0x3FAC28F5C0000000
  %1070 = fadd fast float %1055, 0x3FAC28F5C0000000
  %1071 = fmul fast float %1068, 0x3FEE54EDE0000000
  %1072 = fmul fast float %1069, 0x3FEE54EDE0000000
  %1073 = fmul fast float %1070, 0x3FEE54EDE0000000
  %1074 = call float @dx.op.unary.f32(i32 23, float %1071)  ; Log(value)
  %1075 = call float @dx.op.unary.f32(i32 23, float %1072)  ; Log(value)
  %1076 = call float @dx.op.unary.f32(i32 23, float %1073)  ; Log(value)
  %1077 = fmul fast float %1074, 0x4003333340000000
  %1078 = fmul fast float %1075, 0x4003333340000000
  %1079 = fmul fast float %1076, 0x4003333340000000
  %1080 = call float @dx.op.unary.f32(i32 21, float %1077)  ; Exp(value)
  %1081 = call float @dx.op.unary.f32(i32 21, float %1078)  ; Exp(value)
  %1082 = call float @dx.op.unary.f32(i32 21, float %1079)  ; Exp(value)
  %1083 = fsub fast float %1065, %1080
  %1084 = fsub fast float %1066, %1081
  %1085 = fsub fast float %1067, %1082
  %1086 = fmul fast float %1083, %1062
  %1087 = fmul fast float %1084, %1063
  %1088 = fmul fast float %1085, %1064
  %1089 = fadd fast float %1086, %1080
  %1090 = fadd fast float %1087, %1081
  %1091 = fadd fast float %1088, %1082
  br label %1255

; <label>:1092                                    ; preds = %1047
  %1093 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1050, i32 %1051, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1094 = extractvalue %dx.types.ResRet.f32 %1093, 0
  %1095 = fcmp fast ogt float %38, 5.000000e-01
  %1096 = fcmp fast olt float %1094, 1.000000e+00
  %1097 = and i1 %1095, %1096
  br i1 %1097, label %1098, label %1184

; <label>:1098                                    ; preds = %1092
  %1099 = sitofp i32 %1050 to float
  %1100 = sitofp i32 %1051 to float
  %1101 = fadd fast float %1099, 5.000000e-01
  %1102 = fadd fast float %1100, 5.000000e-01
  %1103 = fdiv fast float %1101, %45
  %1104 = fdiv fast float %1102, %46
  %1105 = fmul fast float %1103, 2.000000e+00
  %1106 = fmul fast float %1104, 2.000000e+00
  %1107 = fadd fast float %1105, -1.000000e+00
  %1108 = fsub fast float 1.000000e+00, %1106
  %1109 = fmul fast float %1107, %35
  %1110 = call float @dx.op.tertiary.f32(i32 46, float %1108, float %31, float %1109)  ; FMad(a,b,c)
  %1111 = call float @dx.op.tertiary.f32(i32 46, float %1094, float %27, float %1110)  ; FMad(a,b,c)
  %1112 = fadd fast float %1111, %23
  %1113 = call float @dx.op.unary.f32(i32 6, float %1112)  ; FAbs(value)
  %1114 = fcmp fast ogt float %1113, 0x3EB0C6F7A0000000
  br i1 %1114, label %1115, label %1184

; <label>:1115                                    ; preds = %1098
  %1116 = fmul fast float %1107, %34
  %1117 = call float @dx.op.tertiary.f32(i32 46, float %1108, float %30, float %1116)  ; FMad(a,b,c)
  %1118 = call float @dx.op.tertiary.f32(i32 46, float %1094, float %26, float %1117)  ; FMad(a,b,c)
  %1119 = fadd fast float %1118, %22
  %1120 = fmul fast float %1107, %33
  %1121 = call float @dx.op.tertiary.f32(i32 46, float %1108, float %29, float %1120)  ; FMad(a,b,c)
  %1122 = call float @dx.op.tertiary.f32(i32 46, float %1094, float %25, float %1121)  ; FMad(a,b,c)
  %1123 = fadd fast float %1122, %21
  %1124 = fmul fast float %1107, %32
  %1125 = call float @dx.op.tertiary.f32(i32 46, float %1108, float %28, float %1124)  ; FMad(a,b,c)
  %1126 = call float @dx.op.tertiary.f32(i32 46, float %1094, float %24, float %1125)  ; FMad(a,b,c)
  %1127 = fadd fast float %1126, %20
  %1128 = fdiv fast float %1127, %1112
  %1129 = fdiv fast float %1123, %1112
  %1130 = fdiv fast float %1119, %1112
  %1131 = fsub fast float %1128, %17
  %1132 = fsub fast float %1129, %18
  %1133 = fsub fast float %1130, %19
  %1134 = fmul fast float %1131, %1131
  %1135 = fmul fast float %1132, %1132
  %1136 = fadd fast float %1135, %1134
  %1137 = fmul fast float %1133, %1133
  %1138 = fadd fast float %1136, %1137
  %1139 = call float @dx.op.unary.f32(i32 24, float %1138)  ; Sqrt(value)
  %1140 = fsub fast float %1139, %9
  %1141 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1140)  ; FMax(a,b)
  %1142 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1142, label %1143, label %1166

; <label>:1143                                    ; preds = %1115
  %1144 = call float @dx.op.unary.f32(i32 6, float %1132)  ; FAbs(value)
  %1145 = fmul fast float %1144, %11
  %1146 = fcmp fast olt float %1145, 0x3F50624DE0000000
  br i1 %1146, label %1147, label %1150

; <label>:1147                                    ; preds = %1143
  %1148 = fmul fast float %1145, 5.000000e-01
  %1149 = fsub fast float 1.000000e+00, %1148
  br label %1155

; <label>:1150                                    ; preds = %1143
  %1151 = fmul fast float %1145, 0xBFF7154760000000
  %1152 = call float @dx.op.unary.f32(i32 21, float %1151)  ; Exp(value)
  %1153 = fsub fast float 1.000000e+00, %1152
  %1154 = fdiv fast float %1153, %1145
  br label %1155

; <label>:1155                                    ; preds = %1150, %1147
  %1156 = phi float [ %1149, %1147 ], [ %1154, %1150 ]
  %1157 = call float @dx.op.binary.f32(i32 36, float %1129, float %18)  ; FMin(a,b)
  %1158 = fsub fast float %1157, %10
  %1159 = fmul fast float %11, %1158
  %1160 = fsub fast float -0.000000e+00, %1159
  %1161 = call float @dx.op.binary.f32(i32 35, float %1160, float -4.000000e+01)  ; FMax(a,b)
  %1162 = call float @dx.op.binary.f32(i32 36, float %1161, float 5.000000e+00)  ; FMin(a,b)
  %1163 = fmul fast float %1162, 0x3FF7154760000000
  %1164 = call float @dx.op.unary.f32(i32 21, float %1163)  ; Exp(value)
  %1165 = fmul fast float %1164, %1156
  br label %1166

; <label>:1166                                    ; preds = %1155, %1115
  %1167 = phi float [ %1165, %1155 ], [ 1.000000e+00, %1115 ]
  %1168 = fmul fast float %1141, %16
  %1169 = fmul fast float %1168, %1167
  %1170 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1169)  ; FMin(a,b)
  %1171 = fmul fast float %1170, 0xBFF7154760000000
  %1172 = call float @dx.op.unary.f32(i32 21, float %1171)  ; Exp(value)
  %1173 = fsub fast float 1.000000e+00, %1172
  %1174 = call float @dx.op.binary.f32(i32 36, float %12, float %1173)  ; FMin(a,b)
  %1175 = fsub fast float %13, %1053
  %1176 = fsub fast float %14, %1054
  %1177 = fsub fast float %15, %1055
  %1178 = fmul fast float %1174, %1175
  %1179 = fmul fast float %1174, %1176
  %1180 = fmul fast float %1174, %1177
  %1181 = fadd fast float %1178, %1053
  %1182 = fadd fast float %1179, %1054
  %1183 = fadd fast float %1180, %1055
  br label %1184

; <label>:1184                                    ; preds = %1166, %1098, %1092
  %1185 = phi float [ %1181, %1166 ], [ %1053, %1098 ], [ %1053, %1092 ]
  %1186 = phi float [ %1182, %1166 ], [ %1054, %1098 ], [ %1054, %1092 ]
  %1187 = phi float [ %1183, %1166 ], [ %1055, %1098 ], [ %1055, %1092 ]
  %1188 = fadd fast float %5, 1.000000e+00
  %1189 = fadd fast float %6, 1.000000e+00
  %1190 = fsub fast float 1.000000e+00, %5
  %1191 = fmul fast float %36, %1188
  %1192 = fmul fast float %36, %1189
  %1193 = fmul fast float %36, %1190
  %1194 = fmul fast float %1191, %1185
  %1195 = fmul fast float %1192, %1186
  %1196 = fmul fast float %1193, %1187
  %1197 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1197, label %1223, label %1198

; <label>:1198                                    ; preds = %1184
  %1199 = fmul fast float %1194, 0x4004147AE0000000
  %1200 = fmul fast float %1195, 0x4004147AE0000000
  %1201 = fmul fast float %1196, 0x4004147AE0000000
  %1202 = fadd fast float %1199, 0x3F9EB851E0000000
  %1203 = fadd fast float %1200, 0x3F9EB851E0000000
  %1204 = fadd fast float %1201, 0x3F9EB851E0000000
  %1205 = fmul fast float %1202, %1194
  %1206 = fmul fast float %1203, %1195
  %1207 = fmul fast float %1204, %1196
  %1208 = fmul fast float %1194, 0x400370A3E0000000
  %1209 = fmul fast float %1195, 0x400370A3E0000000
  %1210 = fmul fast float %1196, 0x400370A3E0000000
  %1211 = fadd fast float %1208, 0x3FE2E147A0000000
  %1212 = fadd fast float %1209, 0x3FE2E147A0000000
  %1213 = fadd fast float %1210, 0x3FE2E147A0000000
  %1214 = fmul fast float %1211, %1194
  %1215 = fmul fast float %1212, %1195
  %1216 = fmul fast float %1213, %1196
  %1217 = fadd fast float %1214, 0x3FC1EB8520000000
  %1218 = fadd fast float %1215, 0x3FC1EB8520000000
  %1219 = fadd fast float %1216, 0x3FC1EB8520000000
  %1220 = fdiv fast float %1205, %1217
  %1221 = fdiv fast float %1206, %1218
  %1222 = fdiv fast float %1207, %1219
  br label %1223

; <label>:1223                                    ; preds = %1198, %1184
  %1224 = phi float [ %1220, %1198 ], [ %1194, %1184 ]
  %1225 = phi float [ %1221, %1198 ], [ %1195, %1184 ]
  %1226 = phi float [ %1222, %1198 ], [ %1196, %1184 ]
  %1227 = call float @dx.op.unary.f32(i32 7, float %1224)  ; Saturate(value)
  %1228 = call float @dx.op.unary.f32(i32 7, float %1225)  ; Saturate(value)
  %1229 = call float @dx.op.unary.f32(i32 7, float %1226)  ; Saturate(value)
  %1230 = call float @dx.op.dot3.f32(i32 55, float %1227, float %1228, float %1229, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1231 = fsub fast float %1227, %1230
  %1232 = fsub fast float %1228, %1230
  %1233 = fsub fast float %1229, %1230
  %1234 = fmul fast float %1231, %8
  %1235 = fmul fast float %1232, %8
  %1236 = fmul fast float %1233, %8
  %1237 = fadd fast float %1234, %1230
  %1238 = fadd fast float %1235, %1230
  %1239 = fadd fast float %1236, %1230
  %1240 = call float @dx.op.unary.f32(i32 7, float %1237)  ; Saturate(value)
  %1241 = call float @dx.op.unary.f32(i32 7, float %1238)  ; Saturate(value)
  %1242 = call float @dx.op.unary.f32(i32 7, float %1239)  ; Saturate(value)
  %1243 = fadd fast float %1240, 0xBFC70A3D80000000
  %1244 = fadd fast float %1241, 0xBFC70A3D80000000
  %1245 = fadd fast float %1242, 0xBFC70A3D80000000
  %1246 = fmul fast float %1243, %7
  %1247 = fmul fast float %1244, %7
  %1248 = fmul fast float %1245, %7
  %1249 = fadd fast float %1246, 0x3FC70A3D80000000
  %1250 = fadd fast float %1247, 0x3FC70A3D80000000
  %1251 = fadd fast float %1248, 0x3FC70A3D80000000
  %1252 = call float @dx.op.unary.f32(i32 7, float %1249)  ; Saturate(value)
  %1253 = call float @dx.op.unary.f32(i32 7, float %1250)  ; Saturate(value)
  %1254 = call float @dx.op.unary.f32(i32 7, float %1251)  ; Saturate(value)
  br label %1255

; <label>:1255                                    ; preds = %1223, %1058
  %1256 = phi float [ %1089, %1058 ], [ %1252, %1223 ]
  %1257 = phi float [ %1090, %1058 ], [ %1253, %1223 ]
  %1258 = phi float [ %1091, %1058 ], [ %1254, %1223 ]
  %1259 = fsub fast float %1256, %394
  %1260 = fsub fast float %1257, %395
  %1261 = fsub fast float %1258, %396
  %1262 = fmul fast float %1259, %1045
  %1263 = fmul fast float %1260, %1045
  %1264 = fmul fast float %1261, %1045
  %1265 = fadd fast float %1262, %394
  %1266 = fadd fast float %1263, %395
  %1267 = fadd fast float %1264, %396
  br label %1268

; <label>:1268                                    ; preds = %1255, %1032
  %1269 = phi float [ %1265, %1255 ], [ %394, %1032 ]
  %1270 = phi float [ %1266, %1255 ], [ %395, %1032 ]
  %1271 = phi float [ %1267, %1255 ], [ %396, %1032 ]
  %1272 = fsub fast float %86, %82
  %1273 = call float @dx.op.unary.f32(i32 6, float %1272)  ; FAbs(value)
  %1274 = fdiv fast float %1273, %1015
  %1275 = fsub fast float 1.000000e+00, %1274
  %1276 = call float @dx.op.unary.f32(i32 7, float %1275)  ; Saturate(value)
  %1277 = fcmp fast ugt float %1276, 0.000000e+00
  br i1 %1277, label %1278, label %1288

; <label>:1278                                    ; preds = %1268
  %1279 = fsub fast float %798, %394
  %1280 = fsub fast float %799, %395
  %1281 = fsub fast float %800, %396
  %1282 = fmul fast float %1276, %1279
  %1283 = fmul fast float %1276, %1280
  %1284 = fmul fast float %1276, %1281
  %1285 = fadd fast float %1282, %394
  %1286 = fadd fast float %1283, %395
  %1287 = fadd fast float %1284, %396
  br label %1288

; <label>:1288                                    ; preds = %1278, %1268
  %1289 = phi float [ %1285, %1278 ], [ %394, %1268 ]
  %1290 = phi float [ %1286, %1278 ], [ %395, %1268 ]
  %1291 = phi float [ %1287, %1278 ], [ %396, %1268 ]
  %1292 = add i32 %56, -1
  %1293 = call i32 @dx.op.binary.i32(i32 37, i32 %1292, i32 0)  ; IMax(a,b)
  %1294 = call i32 @dx.op.binary.i32(i32 38, i32 %1293, i32 %60)  ; IMin(a,b)
  %1295 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %1294, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1296 = extractvalue %dx.types.ResRet.f32 %1295, 0
  %1297 = fsub fast float %1296, %82
  %1298 = call float @dx.op.unary.f32(i32 6, float %1297)  ; FAbs(value)
  %1299 = fdiv fast float %1298, %1015
  %1300 = fsub fast float 1.000000e+00, %1299
  %1301 = call float @dx.op.unary.f32(i32 7, float %1300)  ; Saturate(value)
  %1302 = fcmp fast ugt float %1301, 0.000000e+00
  br i1 %1302, label %1303, label %1524

; <label>:1303                                    ; preds = %1288
  %1304 = call i32 @dx.op.binary.i32(i32 37, i32 %63, i32 0)  ; IMax(a,b)
  %1305 = call i32 @dx.op.binary.i32(i32 37, i32 %1294, i32 0)  ; IMax(a,b)
  %1306 = call i32 @dx.op.binary.i32(i32 38, i32 %1304, i32 %59)  ; IMin(a,b)
  %1307 = call i32 @dx.op.binary.i32(i32 38, i32 %1305, i32 %60)  ; IMin(a,b)
  %1308 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1306, i32 %1307, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1309 = extractvalue %dx.types.ResRet.f32 %1308, 0
  %1310 = extractvalue %dx.types.ResRet.f32 %1308, 1
  %1311 = extractvalue %dx.types.ResRet.f32 %1308, 2
  %1312 = extractvalue %dx.types.ResRet.f32 %1308, 3
  %1313 = fcmp fast olt float %1312, 0.000000e+00
  br i1 %1313, label %1314, label %1348

; <label>:1314                                    ; preds = %1303
  %1315 = fcmp fast ogt float %1309, 0x3FA4B5DCC0000000
  %1316 = fcmp fast ogt float %1310, 0x3FA4B5DCC0000000
  %1317 = fcmp fast ogt float %1311, 0x3FA4B5DCC0000000
  %1318 = select i1 %1315, float 0.000000e+00, float 1.000000e+00
  %1319 = select i1 %1316, float 0.000000e+00, float 1.000000e+00
  %1320 = select i1 %1317, float 0.000000e+00, float 1.000000e+00
  %1321 = fmul fast float %1309, 0x3FB3D07220000000
  %1322 = fmul fast float %1310, 0x3FB3D07220000000
  %1323 = fmul fast float %1311, 0x3FB3D07220000000
  %1324 = fadd fast float %1309, 0x3FAC28F5C0000000
  %1325 = fadd fast float %1310, 0x3FAC28F5C0000000
  %1326 = fadd fast float %1311, 0x3FAC28F5C0000000
  %1327 = fmul fast float %1324, 0x3FEE54EDE0000000
  %1328 = fmul fast float %1325, 0x3FEE54EDE0000000
  %1329 = fmul fast float %1326, 0x3FEE54EDE0000000
  %1330 = call float @dx.op.unary.f32(i32 23, float %1327)  ; Log(value)
  %1331 = call float @dx.op.unary.f32(i32 23, float %1328)  ; Log(value)
  %1332 = call float @dx.op.unary.f32(i32 23, float %1329)  ; Log(value)
  %1333 = fmul fast float %1330, 0x4003333340000000
  %1334 = fmul fast float %1331, 0x4003333340000000
  %1335 = fmul fast float %1332, 0x4003333340000000
  %1336 = call float @dx.op.unary.f32(i32 21, float %1333)  ; Exp(value)
  %1337 = call float @dx.op.unary.f32(i32 21, float %1334)  ; Exp(value)
  %1338 = call float @dx.op.unary.f32(i32 21, float %1335)  ; Exp(value)
  %1339 = fsub fast float %1321, %1336
  %1340 = fsub fast float %1322, %1337
  %1341 = fsub fast float %1323, %1338
  %1342 = fmul fast float %1339, %1318
  %1343 = fmul fast float %1340, %1319
  %1344 = fmul fast float %1341, %1320
  %1345 = fadd fast float %1342, %1336
  %1346 = fadd fast float %1343, %1337
  %1347 = fadd fast float %1344, %1338
  br label %1511

; <label>:1348                                    ; preds = %1303
  %1349 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1306, i32 %1307, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1350 = extractvalue %dx.types.ResRet.f32 %1349, 0
  %1351 = fcmp fast ogt float %38, 5.000000e-01
  %1352 = fcmp fast olt float %1350, 1.000000e+00
  %1353 = and i1 %1351, %1352
  br i1 %1353, label %1354, label %1440

; <label>:1354                                    ; preds = %1348
  %1355 = sitofp i32 %1306 to float
  %1356 = sitofp i32 %1307 to float
  %1357 = fadd fast float %1355, 5.000000e-01
  %1358 = fadd fast float %1356, 5.000000e-01
  %1359 = fdiv fast float %1357, %45
  %1360 = fdiv fast float %1358, %46
  %1361 = fmul fast float %1359, 2.000000e+00
  %1362 = fmul fast float %1360, 2.000000e+00
  %1363 = fadd fast float %1361, -1.000000e+00
  %1364 = fsub fast float 1.000000e+00, %1362
  %1365 = fmul fast float %1363, %35
  %1366 = call float @dx.op.tertiary.f32(i32 46, float %1364, float %31, float %1365)  ; FMad(a,b,c)
  %1367 = call float @dx.op.tertiary.f32(i32 46, float %1350, float %27, float %1366)  ; FMad(a,b,c)
  %1368 = fadd fast float %1367, %23
  %1369 = call float @dx.op.unary.f32(i32 6, float %1368)  ; FAbs(value)
  %1370 = fcmp fast ogt float %1369, 0x3EB0C6F7A0000000
  br i1 %1370, label %1371, label %1440

; <label>:1371                                    ; preds = %1354
  %1372 = fmul fast float %1363, %34
  %1373 = call float @dx.op.tertiary.f32(i32 46, float %1364, float %30, float %1372)  ; FMad(a,b,c)
  %1374 = call float @dx.op.tertiary.f32(i32 46, float %1350, float %26, float %1373)  ; FMad(a,b,c)
  %1375 = fadd fast float %1374, %22
  %1376 = fmul fast float %1363, %33
  %1377 = call float @dx.op.tertiary.f32(i32 46, float %1364, float %29, float %1376)  ; FMad(a,b,c)
  %1378 = call float @dx.op.tertiary.f32(i32 46, float %1350, float %25, float %1377)  ; FMad(a,b,c)
  %1379 = fadd fast float %1378, %21
  %1380 = fmul fast float %1363, %32
  %1381 = call float @dx.op.tertiary.f32(i32 46, float %1364, float %28, float %1380)  ; FMad(a,b,c)
  %1382 = call float @dx.op.tertiary.f32(i32 46, float %1350, float %24, float %1381)  ; FMad(a,b,c)
  %1383 = fadd fast float %1382, %20
  %1384 = fdiv fast float %1383, %1368
  %1385 = fdiv fast float %1379, %1368
  %1386 = fdiv fast float %1375, %1368
  %1387 = fsub fast float %1384, %17
  %1388 = fsub fast float %1385, %18
  %1389 = fsub fast float %1386, %19
  %1390 = fmul fast float %1387, %1387
  %1391 = fmul fast float %1388, %1388
  %1392 = fadd fast float %1391, %1390
  %1393 = fmul fast float %1389, %1389
  %1394 = fadd fast float %1392, %1393
  %1395 = call float @dx.op.unary.f32(i32 24, float %1394)  ; Sqrt(value)
  %1396 = fsub fast float %1395, %9
  %1397 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1396)  ; FMax(a,b)
  %1398 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1398, label %1399, label %1422

; <label>:1399                                    ; preds = %1371
  %1400 = call float @dx.op.unary.f32(i32 6, float %1388)  ; FAbs(value)
  %1401 = fmul fast float %1400, %11
  %1402 = fcmp fast olt float %1401, 0x3F50624DE0000000
  br i1 %1402, label %1403, label %1406

; <label>:1403                                    ; preds = %1399
  %1404 = fmul fast float %1401, 5.000000e-01
  %1405 = fsub fast float 1.000000e+00, %1404
  br label %1411

; <label>:1406                                    ; preds = %1399
  %1407 = fmul fast float %1401, 0xBFF7154760000000
  %1408 = call float @dx.op.unary.f32(i32 21, float %1407)  ; Exp(value)
  %1409 = fsub fast float 1.000000e+00, %1408
  %1410 = fdiv fast float %1409, %1401
  br label %1411

; <label>:1411                                    ; preds = %1406, %1403
  %1412 = phi float [ %1405, %1403 ], [ %1410, %1406 ]
  %1413 = call float @dx.op.binary.f32(i32 36, float %1385, float %18)  ; FMin(a,b)
  %1414 = fsub fast float %1413, %10
  %1415 = fmul fast float %11, %1414
  %1416 = fsub fast float -0.000000e+00, %1415
  %1417 = call float @dx.op.binary.f32(i32 35, float %1416, float -4.000000e+01)  ; FMax(a,b)
  %1418 = call float @dx.op.binary.f32(i32 36, float %1417, float 5.000000e+00)  ; FMin(a,b)
  %1419 = fmul fast float %1418, 0x3FF7154760000000
  %1420 = call float @dx.op.unary.f32(i32 21, float %1419)  ; Exp(value)
  %1421 = fmul fast float %1420, %1412
  br label %1422

; <label>:1422                                    ; preds = %1411, %1371
  %1423 = phi float [ %1421, %1411 ], [ 1.000000e+00, %1371 ]
  %1424 = fmul fast float %1397, %16
  %1425 = fmul fast float %1424, %1423
  %1426 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1425)  ; FMin(a,b)
  %1427 = fmul fast float %1426, 0xBFF7154760000000
  %1428 = call float @dx.op.unary.f32(i32 21, float %1427)  ; Exp(value)
  %1429 = fsub fast float 1.000000e+00, %1428
  %1430 = call float @dx.op.binary.f32(i32 36, float %12, float %1429)  ; FMin(a,b)
  %1431 = fsub fast float %13, %1309
  %1432 = fsub fast float %14, %1310
  %1433 = fsub fast float %15, %1311
  %1434 = fmul fast float %1430, %1431
  %1435 = fmul fast float %1430, %1432
  %1436 = fmul fast float %1430, %1433
  %1437 = fadd fast float %1434, %1309
  %1438 = fadd fast float %1435, %1310
  %1439 = fadd fast float %1436, %1311
  br label %1440

; <label>:1440                                    ; preds = %1422, %1354, %1348
  %1441 = phi float [ %1437, %1422 ], [ %1309, %1354 ], [ %1309, %1348 ]
  %1442 = phi float [ %1438, %1422 ], [ %1310, %1354 ], [ %1310, %1348 ]
  %1443 = phi float [ %1439, %1422 ], [ %1311, %1354 ], [ %1311, %1348 ]
  %1444 = fadd fast float %5, 1.000000e+00
  %1445 = fadd fast float %6, 1.000000e+00
  %1446 = fsub fast float 1.000000e+00, %5
  %1447 = fmul fast float %36, %1444
  %1448 = fmul fast float %36, %1445
  %1449 = fmul fast float %36, %1446
  %1450 = fmul fast float %1447, %1441
  %1451 = fmul fast float %1448, %1442
  %1452 = fmul fast float %1449, %1443
  %1453 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1453, label %1479, label %1454

; <label>:1454                                    ; preds = %1440
  %1455 = fmul fast float %1450, 0x4004147AE0000000
  %1456 = fmul fast float %1451, 0x4004147AE0000000
  %1457 = fmul fast float %1452, 0x4004147AE0000000
  %1458 = fadd fast float %1455, 0x3F9EB851E0000000
  %1459 = fadd fast float %1456, 0x3F9EB851E0000000
  %1460 = fadd fast float %1457, 0x3F9EB851E0000000
  %1461 = fmul fast float %1458, %1450
  %1462 = fmul fast float %1459, %1451
  %1463 = fmul fast float %1460, %1452
  %1464 = fmul fast float %1450, 0x400370A3E0000000
  %1465 = fmul fast float %1451, 0x400370A3E0000000
  %1466 = fmul fast float %1452, 0x400370A3E0000000
  %1467 = fadd fast float %1464, 0x3FE2E147A0000000
  %1468 = fadd fast float %1465, 0x3FE2E147A0000000
  %1469 = fadd fast float %1466, 0x3FE2E147A0000000
  %1470 = fmul fast float %1467, %1450
  %1471 = fmul fast float %1468, %1451
  %1472 = fmul fast float %1469, %1452
  %1473 = fadd fast float %1470, 0x3FC1EB8520000000
  %1474 = fadd fast float %1471, 0x3FC1EB8520000000
  %1475 = fadd fast float %1472, 0x3FC1EB8520000000
  %1476 = fdiv fast float %1461, %1473
  %1477 = fdiv fast float %1462, %1474
  %1478 = fdiv fast float %1463, %1475
  br label %1479

; <label>:1479                                    ; preds = %1454, %1440
  %1480 = phi float [ %1476, %1454 ], [ %1450, %1440 ]
  %1481 = phi float [ %1477, %1454 ], [ %1451, %1440 ]
  %1482 = phi float [ %1478, %1454 ], [ %1452, %1440 ]
  %1483 = call float @dx.op.unary.f32(i32 7, float %1480)  ; Saturate(value)
  %1484 = call float @dx.op.unary.f32(i32 7, float %1481)  ; Saturate(value)
  %1485 = call float @dx.op.unary.f32(i32 7, float %1482)  ; Saturate(value)
  %1486 = call float @dx.op.dot3.f32(i32 55, float %1483, float %1484, float %1485, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1487 = fsub fast float %1483, %1486
  %1488 = fsub fast float %1484, %1486
  %1489 = fsub fast float %1485, %1486
  %1490 = fmul fast float %1487, %8
  %1491 = fmul fast float %1488, %8
  %1492 = fmul fast float %1489, %8
  %1493 = fadd fast float %1490, %1486
  %1494 = fadd fast float %1491, %1486
  %1495 = fadd fast float %1492, %1486
  %1496 = call float @dx.op.unary.f32(i32 7, float %1493)  ; Saturate(value)
  %1497 = call float @dx.op.unary.f32(i32 7, float %1494)  ; Saturate(value)
  %1498 = call float @dx.op.unary.f32(i32 7, float %1495)  ; Saturate(value)
  %1499 = fadd fast float %1496, 0xBFC70A3D80000000
  %1500 = fadd fast float %1497, 0xBFC70A3D80000000
  %1501 = fadd fast float %1498, 0xBFC70A3D80000000
  %1502 = fmul fast float %1499, %7
  %1503 = fmul fast float %1500, %7
  %1504 = fmul fast float %1501, %7
  %1505 = fadd fast float %1502, 0x3FC70A3D80000000
  %1506 = fadd fast float %1503, 0x3FC70A3D80000000
  %1507 = fadd fast float %1504, 0x3FC70A3D80000000
  %1508 = call float @dx.op.unary.f32(i32 7, float %1505)  ; Saturate(value)
  %1509 = call float @dx.op.unary.f32(i32 7, float %1506)  ; Saturate(value)
  %1510 = call float @dx.op.unary.f32(i32 7, float %1507)  ; Saturate(value)
  br label %1511

; <label>:1511                                    ; preds = %1479, %1314
  %1512 = phi float [ %1345, %1314 ], [ %1508, %1479 ]
  %1513 = phi float [ %1346, %1314 ], [ %1509, %1479 ]
  %1514 = phi float [ %1347, %1314 ], [ %1510, %1479 ]
  %1515 = fsub fast float %1512, %394
  %1516 = fsub fast float %1513, %395
  %1517 = fsub fast float %1514, %396
  %1518 = fmul fast float %1515, %1301
  %1519 = fmul fast float %1516, %1301
  %1520 = fmul fast float %1517, %1301
  %1521 = fadd fast float %1518, %394
  %1522 = fadd fast float %1519, %395
  %1523 = fadd fast float %1520, %396
  br label %1524

; <label>:1524                                    ; preds = %1511, %1288
  %1525 = phi float [ %1521, %1511 ], [ %394, %1288 ]
  %1526 = phi float [ %1522, %1511 ], [ %395, %1288 ]
  %1527 = phi float [ %1523, %1511 ], [ %396, %1288 ]
  %1528 = call float @dx.op.binary.f32(i32 36, float %1269, float %1033)  ; FMin(a,b)
  %1529 = call float @dx.op.binary.f32(i32 36, float %1270, float %1034)  ; FMin(a,b)
  %1530 = call float @dx.op.binary.f32(i32 36, float %1271, float %1035)  ; FMin(a,b)
  %1531 = call float @dx.op.binary.f32(i32 36, float %1525, float %1289)  ; FMin(a,b)
  %1532 = call float @dx.op.binary.f32(i32 36, float %1526, float %1290)  ; FMin(a,b)
  %1533 = call float @dx.op.binary.f32(i32 36, float %1527, float %1291)  ; FMin(a,b)
  %1534 = call float @dx.op.binary.f32(i32 36, float %1531, float %1528)  ; FMin(a,b)
  %1535 = call float @dx.op.binary.f32(i32 36, float %1532, float %1529)  ; FMin(a,b)
  %1536 = call float @dx.op.binary.f32(i32 36, float %1533, float %1530)  ; FMin(a,b)
  %1537 = call float @dx.op.binary.f32(i32 36, float %394, float %1534)  ; FMin(a,b)
  %1538 = call float @dx.op.binary.f32(i32 36, float %395, float %1535)  ; FMin(a,b)
  %1539 = call float @dx.op.binary.f32(i32 36, float %396, float %1536)  ; FMin(a,b)
  %1540 = call float @dx.op.binary.f32(i32 35, float %1269, float %1033)  ; FMax(a,b)
  %1541 = call float @dx.op.binary.f32(i32 35, float %1270, float %1034)  ; FMax(a,b)
  %1542 = call float @dx.op.binary.f32(i32 35, float %1271, float %1035)  ; FMax(a,b)
  %1543 = call float @dx.op.binary.f32(i32 35, float %1525, float %1289)  ; FMax(a,b)
  %1544 = call float @dx.op.binary.f32(i32 35, float %1526, float %1290)  ; FMax(a,b)
  %1545 = call float @dx.op.binary.f32(i32 35, float %1527, float %1291)  ; FMax(a,b)
  %1546 = call float @dx.op.binary.f32(i32 35, float %1543, float %1540)  ; FMax(a,b)
  %1547 = call float @dx.op.binary.f32(i32 35, float %1544, float %1541)  ; FMax(a,b)
  %1548 = call float @dx.op.binary.f32(i32 35, float %1545, float %1542)  ; FMax(a,b)
  %1549 = call float @dx.op.binary.f32(i32 35, float %394, float %1546)  ; FMax(a,b)
  %1550 = call float @dx.op.binary.f32(i32 35, float %395, float %1547)  ; FMax(a,b)
  %1551 = call float @dx.op.binary.f32(i32 35, float %396, float %1548)  ; FMax(a,b)
  %1552 = fsub fast float %1549, %1537
  %1553 = fsub fast float %1550, %1538
  %1554 = fsub fast float %1551, %1539
  %1555 = call float @dx.op.unary.f32(i32 6, float %1552)  ; FAbs(value)
  %1556 = call float @dx.op.unary.f32(i32 6, float %1553)  ; FAbs(value)
  %1557 = call float @dx.op.unary.f32(i32 6, float %1554)  ; FAbs(value)
  %1558 = call float @dx.op.binary.f32(i32 35, float %1556, float %1557)  ; FMax(a,b)
  %1559 = call float @dx.op.binary.f32(i32 35, float %1555, float %1558)  ; FMax(a,b)
  %1560 = call float @dx.op.binary.f32(i32 35, float %1550, float %1551)  ; FMax(a,b)
  %1561 = call float @dx.op.binary.f32(i32 35, float %1549, float %1560)  ; FMax(a,b)
  %1562 = fmul fast float %1561, 1.250000e-01
  %1563 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1562)  ; FMax(a,b)
  %1564 = fcmp fast ogt float %1559, %1563
  br i1 %1564, label %1565, label %1626

; <label>:1565                                    ; preds = %1524
  %1566 = fsub fast float %1525, %1289
  %1567 = fsub fast float %1526, %1290
  %1568 = fsub fast float %1527, %1291
  %1569 = call float @dx.op.unary.f32(i32 6, float %1566)  ; FAbs(value)
  %1570 = call float @dx.op.unary.f32(i32 6, float %1567)  ; FAbs(value)
  %1571 = call float @dx.op.unary.f32(i32 6, float %1568)  ; FAbs(value)
  %1572 = call float @dx.op.binary.f32(i32 35, float %1570, float %1571)  ; FMax(a,b)
  %1573 = call float @dx.op.binary.f32(i32 35, float %1569, float %1572)  ; FMax(a,b)
  %1574 = fsub fast float %1269, %1033
  %1575 = fsub fast float %1270, %1034
  %1576 = fsub fast float %1271, %1035
  %1577 = call float @dx.op.unary.f32(i32 6, float %1574)  ; FAbs(value)
  %1578 = call float @dx.op.unary.f32(i32 6, float %1575)  ; FAbs(value)
  %1579 = call float @dx.op.unary.f32(i32 6, float %1576)  ; FAbs(value)
  %1580 = call float @dx.op.binary.f32(i32 35, float %1578, float %1579)  ; FMax(a,b)
  %1581 = call float @dx.op.binary.f32(i32 35, float %1577, float %1580)  ; FMax(a,b)
  %1582 = fcmp fast olt float %1573, %1581
  %1583 = select i1 %1582, float %1525, float %1269
  %1584 = select i1 %1582, float %1526, float %1270
  %1585 = select i1 %1582, float %1527, float %1271
  %1586 = select i1 %1582, float %1289, float %1033
  %1587 = select i1 %1582, float %1290, float %1034
  %1588 = select i1 %1582, float %1291, float %1035
  %1589 = fsub fast float %394, %1586
  %1590 = fsub fast float %395, %1587
  %1591 = fsub fast float %396, %1588
  %1592 = fsub fast float %394, %1583
  %1593 = fsub fast float %395, %1584
  %1594 = fsub fast float %396, %1585
  %1595 = call float @dx.op.dot3.f32(i32 55, float %1592, float %1593, float %1594, float %1589, float %1590, float %1591)  ; Dot3(ax,ay,az,bx,by,bz)
  %1596 = fcmp fast ogt float %1595, 0.000000e+00
  br i1 %1596, label %1597, label %1608

; <label>:1597                                    ; preds = %1565
  %1598 = fsub fast float %1583, %1586
  %1599 = fsub fast float %1584, %1587
  %1600 = fsub fast float %1585, %1588
  %1601 = call float @dx.op.unary.f32(i32 6, float %1598)  ; FAbs(value)
  %1602 = call float @dx.op.unary.f32(i32 6, float %1599)  ; FAbs(value)
  %1603 = call float @dx.op.unary.f32(i32 6, float %1600)  ; FAbs(value)
  %1604 = call float @dx.op.binary.f32(i32 35, float %1602, float %1603)  ; FMax(a,b)
  %1605 = call float @dx.op.binary.f32(i32 35, float %1601, float %1604)  ; FMax(a,b)
  %1606 = fmul fast float %1559, 2.500000e-01
  %1607 = fcmp fast olt float %1605, %1606
  br label %1608

; <label>:1608                                    ; preds = %1597, %1565
  %1609 = phi i1 [ false, %1565 ], [ %1607, %1597 ]
  %1610 = select i1 %1609, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  %1611 = fadd fast float %1583, %1586
  %1612 = fadd fast float %1584, %1587
  %1613 = fadd fast float %1585, %1588
  %1614 = fmul fast float %1611, 5.000000e-01
  %1615 = fmul fast float %1612, 5.000000e-01
  %1616 = fmul fast float %1613, 5.000000e-01
  %1617 = fsub fast float %1614, %394
  %1618 = fsub fast float %1615, %395
  %1619 = fsub fast float %1616, %396
  %1620 = fmul fast float %1610, %1617
  %1621 = fmul fast float %1610, %1618
  %1622 = fmul fast float %1610, %1619
  %1623 = fadd fast float %1620, %394
  %1624 = fadd fast float %1621, %395
  %1625 = fadd fast float %1622, %396
  br label %1626

; <label>:1626                                    ; preds = %1608, %1524, %999
  %1627 = phi float [ %394, %999 ], [ %1623, %1608 ], [ %394, %1524 ]
  %1628 = phi float [ %395, %999 ], [ %1624, %1608 ], [ %395, %1524 ]
  %1629 = phi float [ %396, %999 ], [ %1625, %1608 ], [ %396, %1524 ]
  %1630 = fcmp fast ult float %184, 0.000000e+00
  br i1 %1630, label %2245, label %1631

; <label>:1631                                    ; preds = %1626
  %1632 = add i32 %55, 2
  %1633 = call i32 @dx.op.binary.i32(i32 37, i32 %1632, i32 0)  ; IMax(a,b)
  %1634 = call i32 @dx.op.binary.i32(i32 38, i32 %1633, i32 %59)  ; IMin(a,b)
  %1635 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1634, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1636 = extractvalue %dx.types.ResRet.f32 %1635, 0
  %1637 = fsub fast float 1.000000e+00, %84
  %1638 = fmul fast float %1637, 0x3FA99999A0000000
  %1639 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %1638)  ; FMax(a,b)
  %1640 = fsub fast float %1636, %84
  %1641 = call float @dx.op.unary.f32(i32 6, float %1640)  ; FAbs(value)
  %1642 = fdiv fast float %1641, %1639
  %1643 = fsub fast float 1.000000e+00, %1642
  %1644 = call float @dx.op.unary.f32(i32 7, float %1643)  ; Saturate(value)
  %1645 = fcmp fast ugt float %1644, 0.000000e+00
  br i1 %1645, label %1646, label %1867

; <label>:1646                                    ; preds = %1631
  %1647 = call i32 @dx.op.binary.i32(i32 37, i32 %1634, i32 0)  ; IMax(a,b)
  %1648 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %1649 = call i32 @dx.op.binary.i32(i32 38, i32 %1647, i32 %59)  ; IMin(a,b)
  %1650 = call i32 @dx.op.binary.i32(i32 38, i32 %1648, i32 %60)  ; IMin(a,b)
  %1651 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1649, i32 %1650, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1652 = extractvalue %dx.types.ResRet.f32 %1651, 0
  %1653 = extractvalue %dx.types.ResRet.f32 %1651, 1
  %1654 = extractvalue %dx.types.ResRet.f32 %1651, 2
  %1655 = extractvalue %dx.types.ResRet.f32 %1651, 3
  %1656 = fcmp fast olt float %1655, 0.000000e+00
  br i1 %1656, label %1657, label %1691

; <label>:1657                                    ; preds = %1646
  %1658 = fcmp fast ogt float %1652, 0x3FA4B5DCC0000000
  %1659 = fcmp fast ogt float %1653, 0x3FA4B5DCC0000000
  %1660 = fcmp fast ogt float %1654, 0x3FA4B5DCC0000000
  %1661 = select i1 %1658, float 0.000000e+00, float 1.000000e+00
  %1662 = select i1 %1659, float 0.000000e+00, float 1.000000e+00
  %1663 = select i1 %1660, float 0.000000e+00, float 1.000000e+00
  %1664 = fmul fast float %1652, 0x3FB3D07220000000
  %1665 = fmul fast float %1653, 0x3FB3D07220000000
  %1666 = fmul fast float %1654, 0x3FB3D07220000000
  %1667 = fadd fast float %1652, 0x3FAC28F5C0000000
  %1668 = fadd fast float %1653, 0x3FAC28F5C0000000
  %1669 = fadd fast float %1654, 0x3FAC28F5C0000000
  %1670 = fmul fast float %1667, 0x3FEE54EDE0000000
  %1671 = fmul fast float %1668, 0x3FEE54EDE0000000
  %1672 = fmul fast float %1669, 0x3FEE54EDE0000000
  %1673 = call float @dx.op.unary.f32(i32 23, float %1670)  ; Log(value)
  %1674 = call float @dx.op.unary.f32(i32 23, float %1671)  ; Log(value)
  %1675 = call float @dx.op.unary.f32(i32 23, float %1672)  ; Log(value)
  %1676 = fmul fast float %1673, 0x4003333340000000
  %1677 = fmul fast float %1674, 0x4003333340000000
  %1678 = fmul fast float %1675, 0x4003333340000000
  %1679 = call float @dx.op.unary.f32(i32 21, float %1676)  ; Exp(value)
  %1680 = call float @dx.op.unary.f32(i32 21, float %1677)  ; Exp(value)
  %1681 = call float @dx.op.unary.f32(i32 21, float %1678)  ; Exp(value)
  %1682 = fsub fast float %1664, %1679
  %1683 = fsub fast float %1665, %1680
  %1684 = fsub fast float %1666, %1681
  %1685 = fmul fast float %1682, %1661
  %1686 = fmul fast float %1683, %1662
  %1687 = fmul fast float %1684, %1663
  %1688 = fadd fast float %1685, %1679
  %1689 = fadd fast float %1686, %1680
  %1690 = fadd fast float %1687, %1681
  br label %1854

; <label>:1691                                    ; preds = %1646
  %1692 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1649, i32 %1650, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1693 = extractvalue %dx.types.ResRet.f32 %1692, 0
  %1694 = fcmp fast ogt float %38, 5.000000e-01
  %1695 = fcmp fast olt float %1693, 1.000000e+00
  %1696 = and i1 %1694, %1695
  br i1 %1696, label %1697, label %1783

; <label>:1697                                    ; preds = %1691
  %1698 = sitofp i32 %1649 to float
  %1699 = sitofp i32 %1650 to float
  %1700 = fadd fast float %1698, 5.000000e-01
  %1701 = fadd fast float %1699, 5.000000e-01
  %1702 = fdiv fast float %1700, %45
  %1703 = fdiv fast float %1701, %46
  %1704 = fmul fast float %1702, 2.000000e+00
  %1705 = fmul fast float %1703, 2.000000e+00
  %1706 = fadd fast float %1704, -1.000000e+00
  %1707 = fsub fast float 1.000000e+00, %1705
  %1708 = fmul fast float %1706, %35
  %1709 = call float @dx.op.tertiary.f32(i32 46, float %1707, float %31, float %1708)  ; FMad(a,b,c)
  %1710 = call float @dx.op.tertiary.f32(i32 46, float %1693, float %27, float %1709)  ; FMad(a,b,c)
  %1711 = fadd fast float %1710, %23
  %1712 = call float @dx.op.unary.f32(i32 6, float %1711)  ; FAbs(value)
  %1713 = fcmp fast ogt float %1712, 0x3EB0C6F7A0000000
  br i1 %1713, label %1714, label %1783

; <label>:1714                                    ; preds = %1697
  %1715 = fmul fast float %1706, %34
  %1716 = call float @dx.op.tertiary.f32(i32 46, float %1707, float %30, float %1715)  ; FMad(a,b,c)
  %1717 = call float @dx.op.tertiary.f32(i32 46, float %1693, float %26, float %1716)  ; FMad(a,b,c)
  %1718 = fadd fast float %1717, %22
  %1719 = fmul fast float %1706, %33
  %1720 = call float @dx.op.tertiary.f32(i32 46, float %1707, float %29, float %1719)  ; FMad(a,b,c)
  %1721 = call float @dx.op.tertiary.f32(i32 46, float %1693, float %25, float %1720)  ; FMad(a,b,c)
  %1722 = fadd fast float %1721, %21
  %1723 = fmul fast float %1706, %32
  %1724 = call float @dx.op.tertiary.f32(i32 46, float %1707, float %28, float %1723)  ; FMad(a,b,c)
  %1725 = call float @dx.op.tertiary.f32(i32 46, float %1693, float %24, float %1724)  ; FMad(a,b,c)
  %1726 = fadd fast float %1725, %20
  %1727 = fdiv fast float %1726, %1711
  %1728 = fdiv fast float %1722, %1711
  %1729 = fdiv fast float %1718, %1711
  %1730 = fsub fast float %1727, %17
  %1731 = fsub fast float %1728, %18
  %1732 = fsub fast float %1729, %19
  %1733 = fmul fast float %1730, %1730
  %1734 = fmul fast float %1731, %1731
  %1735 = fadd fast float %1734, %1733
  %1736 = fmul fast float %1732, %1732
  %1737 = fadd fast float %1735, %1736
  %1738 = call float @dx.op.unary.f32(i32 24, float %1737)  ; Sqrt(value)
  %1739 = fsub fast float %1738, %9
  %1740 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1739)  ; FMax(a,b)
  %1741 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1741, label %1742, label %1765

; <label>:1742                                    ; preds = %1714
  %1743 = call float @dx.op.unary.f32(i32 6, float %1731)  ; FAbs(value)
  %1744 = fmul fast float %1743, %11
  %1745 = fcmp fast olt float %1744, 0x3F50624DE0000000
  br i1 %1745, label %1746, label %1749

; <label>:1746                                    ; preds = %1742
  %1747 = fmul fast float %1744, 5.000000e-01
  %1748 = fsub fast float 1.000000e+00, %1747
  br label %1754

; <label>:1749                                    ; preds = %1742
  %1750 = fmul fast float %1744, 0xBFF7154760000000
  %1751 = call float @dx.op.unary.f32(i32 21, float %1750)  ; Exp(value)
  %1752 = fsub fast float 1.000000e+00, %1751
  %1753 = fdiv fast float %1752, %1744
  br label %1754

; <label>:1754                                    ; preds = %1749, %1746
  %1755 = phi float [ %1748, %1746 ], [ %1753, %1749 ]
  %1756 = call float @dx.op.binary.f32(i32 36, float %1728, float %18)  ; FMin(a,b)
  %1757 = fsub fast float %1756, %10
  %1758 = fmul fast float %11, %1757
  %1759 = fsub fast float -0.000000e+00, %1758
  %1760 = call float @dx.op.binary.f32(i32 35, float %1759, float -4.000000e+01)  ; FMax(a,b)
  %1761 = call float @dx.op.binary.f32(i32 36, float %1760, float 5.000000e+00)  ; FMin(a,b)
  %1762 = fmul fast float %1761, 0x3FF7154760000000
  %1763 = call float @dx.op.unary.f32(i32 21, float %1762)  ; Exp(value)
  %1764 = fmul fast float %1763, %1755
  br label %1765

; <label>:1765                                    ; preds = %1754, %1714
  %1766 = phi float [ %1764, %1754 ], [ 1.000000e+00, %1714 ]
  %1767 = fmul fast float %1740, %16
  %1768 = fmul fast float %1767, %1766
  %1769 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1768)  ; FMin(a,b)
  %1770 = fmul fast float %1769, 0xBFF7154760000000
  %1771 = call float @dx.op.unary.f32(i32 21, float %1770)  ; Exp(value)
  %1772 = fsub fast float 1.000000e+00, %1771
  %1773 = call float @dx.op.binary.f32(i32 36, float %12, float %1772)  ; FMin(a,b)
  %1774 = fsub fast float %13, %1652
  %1775 = fsub fast float %14, %1653
  %1776 = fsub fast float %15, %1654
  %1777 = fmul fast float %1773, %1774
  %1778 = fmul fast float %1773, %1775
  %1779 = fmul fast float %1773, %1776
  %1780 = fadd fast float %1777, %1652
  %1781 = fadd fast float %1778, %1653
  %1782 = fadd fast float %1779, %1654
  br label %1783

; <label>:1783                                    ; preds = %1765, %1697, %1691
  %1784 = phi float [ %1780, %1765 ], [ %1652, %1697 ], [ %1652, %1691 ]
  %1785 = phi float [ %1781, %1765 ], [ %1653, %1697 ], [ %1653, %1691 ]
  %1786 = phi float [ %1782, %1765 ], [ %1654, %1697 ], [ %1654, %1691 ]
  %1787 = fadd fast float %5, 1.000000e+00
  %1788 = fadd fast float %6, 1.000000e+00
  %1789 = fsub fast float 1.000000e+00, %5
  %1790 = fmul fast float %36, %1787
  %1791 = fmul fast float %36, %1788
  %1792 = fmul fast float %36, %1789
  %1793 = fmul fast float %1790, %1784
  %1794 = fmul fast float %1791, %1785
  %1795 = fmul fast float %1792, %1786
  %1796 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1796, label %1822, label %1797

; <label>:1797                                    ; preds = %1783
  %1798 = fmul fast float %1793, 0x4004147AE0000000
  %1799 = fmul fast float %1794, 0x4004147AE0000000
  %1800 = fmul fast float %1795, 0x4004147AE0000000
  %1801 = fadd fast float %1798, 0x3F9EB851E0000000
  %1802 = fadd fast float %1799, 0x3F9EB851E0000000
  %1803 = fadd fast float %1800, 0x3F9EB851E0000000
  %1804 = fmul fast float %1801, %1793
  %1805 = fmul fast float %1802, %1794
  %1806 = fmul fast float %1803, %1795
  %1807 = fmul fast float %1793, 0x400370A3E0000000
  %1808 = fmul fast float %1794, 0x400370A3E0000000
  %1809 = fmul fast float %1795, 0x400370A3E0000000
  %1810 = fadd fast float %1807, 0x3FE2E147A0000000
  %1811 = fadd fast float %1808, 0x3FE2E147A0000000
  %1812 = fadd fast float %1809, 0x3FE2E147A0000000
  %1813 = fmul fast float %1810, %1793
  %1814 = fmul fast float %1811, %1794
  %1815 = fmul fast float %1812, %1795
  %1816 = fadd fast float %1813, 0x3FC1EB8520000000
  %1817 = fadd fast float %1814, 0x3FC1EB8520000000
  %1818 = fadd fast float %1815, 0x3FC1EB8520000000
  %1819 = fdiv fast float %1804, %1816
  %1820 = fdiv fast float %1805, %1817
  %1821 = fdiv fast float %1806, %1818
  br label %1822

; <label>:1822                                    ; preds = %1797, %1783
  %1823 = phi float [ %1819, %1797 ], [ %1793, %1783 ]
  %1824 = phi float [ %1820, %1797 ], [ %1794, %1783 ]
  %1825 = phi float [ %1821, %1797 ], [ %1795, %1783 ]
  %1826 = call float @dx.op.unary.f32(i32 7, float %1823)  ; Saturate(value)
  %1827 = call float @dx.op.unary.f32(i32 7, float %1824)  ; Saturate(value)
  %1828 = call float @dx.op.unary.f32(i32 7, float %1825)  ; Saturate(value)
  %1829 = call float @dx.op.dot3.f32(i32 55, float %1826, float %1827, float %1828, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1830 = fsub fast float %1826, %1829
  %1831 = fsub fast float %1827, %1829
  %1832 = fsub fast float %1828, %1829
  %1833 = fmul fast float %1830, %8
  %1834 = fmul fast float %1831, %8
  %1835 = fmul fast float %1832, %8
  %1836 = fadd fast float %1833, %1829
  %1837 = fadd fast float %1834, %1829
  %1838 = fadd fast float %1835, %1829
  %1839 = call float @dx.op.unary.f32(i32 7, float %1836)  ; Saturate(value)
  %1840 = call float @dx.op.unary.f32(i32 7, float %1837)  ; Saturate(value)
  %1841 = call float @dx.op.unary.f32(i32 7, float %1838)  ; Saturate(value)
  %1842 = fadd fast float %1839, 0xBFC70A3D80000000
  %1843 = fadd fast float %1840, 0xBFC70A3D80000000
  %1844 = fadd fast float %1841, 0xBFC70A3D80000000
  %1845 = fmul fast float %1842, %7
  %1846 = fmul fast float %1843, %7
  %1847 = fmul fast float %1844, %7
  %1848 = fadd fast float %1845, 0x3FC70A3D80000000
  %1849 = fadd fast float %1846, 0x3FC70A3D80000000
  %1850 = fadd fast float %1847, 0x3FC70A3D80000000
  %1851 = call float @dx.op.unary.f32(i32 7, float %1848)  ; Saturate(value)
  %1852 = call float @dx.op.unary.f32(i32 7, float %1849)  ; Saturate(value)
  %1853 = call float @dx.op.unary.f32(i32 7, float %1850)  ; Saturate(value)
  br label %1854

; <label>:1854                                    ; preds = %1822, %1657
  %1855 = phi float [ %1688, %1657 ], [ %1851, %1822 ]
  %1856 = phi float [ %1689, %1657 ], [ %1852, %1822 ]
  %1857 = phi float [ %1690, %1657 ], [ %1853, %1822 ]
  %1858 = fsub fast float %1855, %596
  %1859 = fsub fast float %1856, %597
  %1860 = fsub fast float %1857, %598
  %1861 = fmul fast float %1858, %1644
  %1862 = fmul fast float %1859, %1644
  %1863 = fmul fast float %1860, %1644
  %1864 = fadd fast float %1861, %596
  %1865 = fadd fast float %1862, %597
  %1866 = fadd fast float %1863, %598
  br label %1867

; <label>:1867                                    ; preds = %1854, %1631
  %1868 = phi float [ %1864, %1854 ], [ %596, %1631 ]
  %1869 = phi float [ %1865, %1854 ], [ %597, %1631 ]
  %1870 = phi float [ %1866, %1854 ], [ %598, %1631 ]
  %1871 = fsub fast float %82, %84
  %1872 = call float @dx.op.unary.f32(i32 6, float %1871)  ; FAbs(value)
  %1873 = fdiv fast float %1872, %1639
  %1874 = fsub fast float 1.000000e+00, %1873
  %1875 = call float @dx.op.unary.f32(i32 7, float %1874)  ; Saturate(value)
  %1876 = fcmp fast ugt float %1875, 0.000000e+00
  br i1 %1876, label %1877, label %1887

; <label>:1877                                    ; preds = %1867
  %1878 = fsub fast float %394, %596
  %1879 = fsub fast float %395, %597
  %1880 = fsub fast float %396, %598
  %1881 = fmul fast float %1875, %1878
  %1882 = fmul fast float %1875, %1879
  %1883 = fmul fast float %1875, %1880
  %1884 = fadd fast float %1881, %596
  %1885 = fadd fast float %1882, %597
  %1886 = fadd fast float %1883, %598
  br label %1887

; <label>:1887                                    ; preds = %1877, %1867
  %1888 = phi float [ %1884, %1877 ], [ %596, %1867 ]
  %1889 = phi float [ %1885, %1877 ], [ %597, %1867 ]
  %1890 = phi float [ %1886, %1877 ], [ %598, %1867 ]
  %1891 = fsub fast float %88, %84
  %1892 = call float @dx.op.unary.f32(i32 6, float %1891)  ; FAbs(value)
  %1893 = fdiv fast float %1892, %1639
  %1894 = fsub fast float 1.000000e+00, %1893
  %1895 = call float @dx.op.unary.f32(i32 7, float %1894)  ; Saturate(value)
  %1896 = fcmp fast ugt float %1895, 0.000000e+00
  br i1 %1896, label %1897, label %1907

; <label>:1897                                    ; preds = %1887
  %1898 = fsub fast float %1000, %596
  %1899 = fsub fast float %1001, %597
  %1900 = fsub fast float %1002, %598
  %1901 = fmul fast float %1895, %1898
  %1902 = fmul fast float %1895, %1899
  %1903 = fmul fast float %1895, %1900
  %1904 = fadd fast float %1901, %596
  %1905 = fadd fast float %1902, %597
  %1906 = fadd fast float %1903, %598
  br label %1907

; <label>:1907                                    ; preds = %1897, %1887
  %1908 = phi float [ %1904, %1897 ], [ %596, %1887 ]
  %1909 = phi float [ %1905, %1897 ], [ %597, %1887 ]
  %1910 = phi float [ %1906, %1897 ], [ %598, %1887 ]
  %1911 = add i32 %56, -1
  %1912 = call i32 @dx.op.binary.i32(i32 37, i32 %1911, i32 0)  ; IMax(a,b)
  %1913 = call i32 @dx.op.binary.i32(i32 38, i32 %1912, i32 %60)  ; IMin(a,b)
  %1914 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %67, i32 %1913, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1915 = extractvalue %dx.types.ResRet.f32 %1914, 0
  %1916 = fsub fast float %1915, %84
  %1917 = call float @dx.op.unary.f32(i32 6, float %1916)  ; FAbs(value)
  %1918 = fdiv fast float %1917, %1639
  %1919 = fsub fast float 1.000000e+00, %1918
  %1920 = call float @dx.op.unary.f32(i32 7, float %1919)  ; Saturate(value)
  %1921 = fcmp fast ugt float %1920, 0.000000e+00
  br i1 %1921, label %1922, label %2143

; <label>:1922                                    ; preds = %1907
  %1923 = call i32 @dx.op.binary.i32(i32 37, i32 %67, i32 0)  ; IMax(a,b)
  %1924 = call i32 @dx.op.binary.i32(i32 37, i32 %1913, i32 0)  ; IMax(a,b)
  %1925 = call i32 @dx.op.binary.i32(i32 38, i32 %1923, i32 %59)  ; IMin(a,b)
  %1926 = call i32 @dx.op.binary.i32(i32 38, i32 %1924, i32 %60)  ; IMin(a,b)
  %1927 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1925, i32 %1926, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1928 = extractvalue %dx.types.ResRet.f32 %1927, 0
  %1929 = extractvalue %dx.types.ResRet.f32 %1927, 1
  %1930 = extractvalue %dx.types.ResRet.f32 %1927, 2
  %1931 = extractvalue %dx.types.ResRet.f32 %1927, 3
  %1932 = fcmp fast olt float %1931, 0.000000e+00
  br i1 %1932, label %1933, label %1967

; <label>:1933                                    ; preds = %1922
  %1934 = fcmp fast ogt float %1928, 0x3FA4B5DCC0000000
  %1935 = fcmp fast ogt float %1929, 0x3FA4B5DCC0000000
  %1936 = fcmp fast ogt float %1930, 0x3FA4B5DCC0000000
  %1937 = select i1 %1934, float 0.000000e+00, float 1.000000e+00
  %1938 = select i1 %1935, float 0.000000e+00, float 1.000000e+00
  %1939 = select i1 %1936, float 0.000000e+00, float 1.000000e+00
  %1940 = fmul fast float %1928, 0x3FB3D07220000000
  %1941 = fmul fast float %1929, 0x3FB3D07220000000
  %1942 = fmul fast float %1930, 0x3FB3D07220000000
  %1943 = fadd fast float %1928, 0x3FAC28F5C0000000
  %1944 = fadd fast float %1929, 0x3FAC28F5C0000000
  %1945 = fadd fast float %1930, 0x3FAC28F5C0000000
  %1946 = fmul fast float %1943, 0x3FEE54EDE0000000
  %1947 = fmul fast float %1944, 0x3FEE54EDE0000000
  %1948 = fmul fast float %1945, 0x3FEE54EDE0000000
  %1949 = call float @dx.op.unary.f32(i32 23, float %1946)  ; Log(value)
  %1950 = call float @dx.op.unary.f32(i32 23, float %1947)  ; Log(value)
  %1951 = call float @dx.op.unary.f32(i32 23, float %1948)  ; Log(value)
  %1952 = fmul fast float %1949, 0x4003333340000000
  %1953 = fmul fast float %1950, 0x4003333340000000
  %1954 = fmul fast float %1951, 0x4003333340000000
  %1955 = call float @dx.op.unary.f32(i32 21, float %1952)  ; Exp(value)
  %1956 = call float @dx.op.unary.f32(i32 21, float %1953)  ; Exp(value)
  %1957 = call float @dx.op.unary.f32(i32 21, float %1954)  ; Exp(value)
  %1958 = fsub fast float %1940, %1955
  %1959 = fsub fast float %1941, %1956
  %1960 = fsub fast float %1942, %1957
  %1961 = fmul fast float %1958, %1937
  %1962 = fmul fast float %1959, %1938
  %1963 = fmul fast float %1960, %1939
  %1964 = fadd fast float %1961, %1955
  %1965 = fadd fast float %1962, %1956
  %1966 = fadd fast float %1963, %1957
  br label %2130

; <label>:1967                                    ; preds = %1922
  %1968 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1925, i32 %1926, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1969 = extractvalue %dx.types.ResRet.f32 %1968, 0
  %1970 = fcmp fast ogt float %38, 5.000000e-01
  %1971 = fcmp fast olt float %1969, 1.000000e+00
  %1972 = and i1 %1970, %1971
  br i1 %1972, label %1973, label %2059

; <label>:1973                                    ; preds = %1967
  %1974 = sitofp i32 %1925 to float
  %1975 = sitofp i32 %1926 to float
  %1976 = fadd fast float %1974, 5.000000e-01
  %1977 = fadd fast float %1975, 5.000000e-01
  %1978 = fdiv fast float %1976, %45
  %1979 = fdiv fast float %1977, %46
  %1980 = fmul fast float %1978, 2.000000e+00
  %1981 = fmul fast float %1979, 2.000000e+00
  %1982 = fadd fast float %1980, -1.000000e+00
  %1983 = fsub fast float 1.000000e+00, %1981
  %1984 = fmul fast float %1982, %35
  %1985 = call float @dx.op.tertiary.f32(i32 46, float %1983, float %31, float %1984)  ; FMad(a,b,c)
  %1986 = call float @dx.op.tertiary.f32(i32 46, float %1969, float %27, float %1985)  ; FMad(a,b,c)
  %1987 = fadd fast float %1986, %23
  %1988 = call float @dx.op.unary.f32(i32 6, float %1987)  ; FAbs(value)
  %1989 = fcmp fast ogt float %1988, 0x3EB0C6F7A0000000
  br i1 %1989, label %1990, label %2059

; <label>:1990                                    ; preds = %1973
  %1991 = fmul fast float %1982, %34
  %1992 = call float @dx.op.tertiary.f32(i32 46, float %1983, float %30, float %1991)  ; FMad(a,b,c)
  %1993 = call float @dx.op.tertiary.f32(i32 46, float %1969, float %26, float %1992)  ; FMad(a,b,c)
  %1994 = fadd fast float %1993, %22
  %1995 = fmul fast float %1982, %33
  %1996 = call float @dx.op.tertiary.f32(i32 46, float %1983, float %29, float %1995)  ; FMad(a,b,c)
  %1997 = call float @dx.op.tertiary.f32(i32 46, float %1969, float %25, float %1996)  ; FMad(a,b,c)
  %1998 = fadd fast float %1997, %21
  %1999 = fmul fast float %1982, %32
  %2000 = call float @dx.op.tertiary.f32(i32 46, float %1983, float %28, float %1999)  ; FMad(a,b,c)
  %2001 = call float @dx.op.tertiary.f32(i32 46, float %1969, float %24, float %2000)  ; FMad(a,b,c)
  %2002 = fadd fast float %2001, %20
  %2003 = fdiv fast float %2002, %1987
  %2004 = fdiv fast float %1998, %1987
  %2005 = fdiv fast float %1994, %1987
  %2006 = fsub fast float %2003, %17
  %2007 = fsub fast float %2004, %18
  %2008 = fsub fast float %2005, %19
  %2009 = fmul fast float %2006, %2006
  %2010 = fmul fast float %2007, %2007
  %2011 = fadd fast float %2010, %2009
  %2012 = fmul fast float %2008, %2008
  %2013 = fadd fast float %2011, %2012
  %2014 = call float @dx.op.unary.f32(i32 24, float %2013)  ; Sqrt(value)
  %2015 = fsub fast float %2014, %9
  %2016 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2015)  ; FMax(a,b)
  %2017 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %2017, label %2018, label %2041

; <label>:2018                                    ; preds = %1990
  %2019 = call float @dx.op.unary.f32(i32 6, float %2007)  ; FAbs(value)
  %2020 = fmul fast float %2019, %11
  %2021 = fcmp fast olt float %2020, 0x3F50624DE0000000
  br i1 %2021, label %2022, label %2025

; <label>:2022                                    ; preds = %2018
  %2023 = fmul fast float %2020, 5.000000e-01
  %2024 = fsub fast float 1.000000e+00, %2023
  br label %2030

; <label>:2025                                    ; preds = %2018
  %2026 = fmul fast float %2020, 0xBFF7154760000000
  %2027 = call float @dx.op.unary.f32(i32 21, float %2026)  ; Exp(value)
  %2028 = fsub fast float 1.000000e+00, %2027
  %2029 = fdiv fast float %2028, %2020
  br label %2030

; <label>:2030                                    ; preds = %2025, %2022
  %2031 = phi float [ %2024, %2022 ], [ %2029, %2025 ]
  %2032 = call float @dx.op.binary.f32(i32 36, float %2004, float %18)  ; FMin(a,b)
  %2033 = fsub fast float %2032, %10
  %2034 = fmul fast float %11, %2033
  %2035 = fsub fast float -0.000000e+00, %2034
  %2036 = call float @dx.op.binary.f32(i32 35, float %2035, float -4.000000e+01)  ; FMax(a,b)
  %2037 = call float @dx.op.binary.f32(i32 36, float %2036, float 5.000000e+00)  ; FMin(a,b)
  %2038 = fmul fast float %2037, 0x3FF7154760000000
  %2039 = call float @dx.op.unary.f32(i32 21, float %2038)  ; Exp(value)
  %2040 = fmul fast float %2039, %2031
  br label %2041

; <label>:2041                                    ; preds = %2030, %1990
  %2042 = phi float [ %2040, %2030 ], [ 1.000000e+00, %1990 ]
  %2043 = fmul fast float %2016, %16
  %2044 = fmul fast float %2043, %2042
  %2045 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2044)  ; FMin(a,b)
  %2046 = fmul fast float %2045, 0xBFF7154760000000
  %2047 = call float @dx.op.unary.f32(i32 21, float %2046)  ; Exp(value)
  %2048 = fsub fast float 1.000000e+00, %2047
  %2049 = call float @dx.op.binary.f32(i32 36, float %12, float %2048)  ; FMin(a,b)
  %2050 = fsub fast float %13, %1928
  %2051 = fsub fast float %14, %1929
  %2052 = fsub fast float %15, %1930
  %2053 = fmul fast float %2049, %2050
  %2054 = fmul fast float %2049, %2051
  %2055 = fmul fast float %2049, %2052
  %2056 = fadd fast float %2053, %1928
  %2057 = fadd fast float %2054, %1929
  %2058 = fadd fast float %2055, %1930
  br label %2059

; <label>:2059                                    ; preds = %2041, %1973, %1967
  %2060 = phi float [ %2056, %2041 ], [ %1928, %1973 ], [ %1928, %1967 ]
  %2061 = phi float [ %2057, %2041 ], [ %1929, %1973 ], [ %1929, %1967 ]
  %2062 = phi float [ %2058, %2041 ], [ %1930, %1973 ], [ %1930, %1967 ]
  %2063 = fadd fast float %5, 1.000000e+00
  %2064 = fadd fast float %6, 1.000000e+00
  %2065 = fsub fast float 1.000000e+00, %5
  %2066 = fmul fast float %36, %2063
  %2067 = fmul fast float %36, %2064
  %2068 = fmul fast float %36, %2065
  %2069 = fmul fast float %2066, %2060
  %2070 = fmul fast float %2067, %2061
  %2071 = fmul fast float %2068, %2062
  %2072 = fcmp fast ult float %37, 5.000000e-01
  br i1 %2072, label %2098, label %2073

; <label>:2073                                    ; preds = %2059
  %2074 = fmul fast float %2069, 0x4004147AE0000000
  %2075 = fmul fast float %2070, 0x4004147AE0000000
  %2076 = fmul fast float %2071, 0x4004147AE0000000
  %2077 = fadd fast float %2074, 0x3F9EB851E0000000
  %2078 = fadd fast float %2075, 0x3F9EB851E0000000
  %2079 = fadd fast float %2076, 0x3F9EB851E0000000
  %2080 = fmul fast float %2077, %2069
  %2081 = fmul fast float %2078, %2070
  %2082 = fmul fast float %2079, %2071
  %2083 = fmul fast float %2069, 0x400370A3E0000000
  %2084 = fmul fast float %2070, 0x400370A3E0000000
  %2085 = fmul fast float %2071, 0x400370A3E0000000
  %2086 = fadd fast float %2083, 0x3FE2E147A0000000
  %2087 = fadd fast float %2084, 0x3FE2E147A0000000
  %2088 = fadd fast float %2085, 0x3FE2E147A0000000
  %2089 = fmul fast float %2086, %2069
  %2090 = fmul fast float %2087, %2070
  %2091 = fmul fast float %2088, %2071
  %2092 = fadd fast float %2089, 0x3FC1EB8520000000
  %2093 = fadd fast float %2090, 0x3FC1EB8520000000
  %2094 = fadd fast float %2091, 0x3FC1EB8520000000
  %2095 = fdiv fast float %2080, %2092
  %2096 = fdiv fast float %2081, %2093
  %2097 = fdiv fast float %2082, %2094
  br label %2098

; <label>:2098                                    ; preds = %2073, %2059
  %2099 = phi float [ %2095, %2073 ], [ %2069, %2059 ]
  %2100 = phi float [ %2096, %2073 ], [ %2070, %2059 ]
  %2101 = phi float [ %2097, %2073 ], [ %2071, %2059 ]
  %2102 = call float @dx.op.unary.f32(i32 7, float %2099)  ; Saturate(value)
  %2103 = call float @dx.op.unary.f32(i32 7, float %2100)  ; Saturate(value)
  %2104 = call float @dx.op.unary.f32(i32 7, float %2101)  ; Saturate(value)
  %2105 = call float @dx.op.dot3.f32(i32 55, float %2102, float %2103, float %2104, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2106 = fsub fast float %2102, %2105
  %2107 = fsub fast float %2103, %2105
  %2108 = fsub fast float %2104, %2105
  %2109 = fmul fast float %2106, %8
  %2110 = fmul fast float %2107, %8
  %2111 = fmul fast float %2108, %8
  %2112 = fadd fast float %2109, %2105
  %2113 = fadd fast float %2110, %2105
  %2114 = fadd fast float %2111, %2105
  %2115 = call float @dx.op.unary.f32(i32 7, float %2112)  ; Saturate(value)
  %2116 = call float @dx.op.unary.f32(i32 7, float %2113)  ; Saturate(value)
  %2117 = call float @dx.op.unary.f32(i32 7, float %2114)  ; Saturate(value)
  %2118 = fadd fast float %2115, 0xBFC70A3D80000000
  %2119 = fadd fast float %2116, 0xBFC70A3D80000000
  %2120 = fadd fast float %2117, 0xBFC70A3D80000000
  %2121 = fmul fast float %2118, %7
  %2122 = fmul fast float %2119, %7
  %2123 = fmul fast float %2120, %7
  %2124 = fadd fast float %2121, 0x3FC70A3D80000000
  %2125 = fadd fast float %2122, 0x3FC70A3D80000000
  %2126 = fadd fast float %2123, 0x3FC70A3D80000000
  %2127 = call float @dx.op.unary.f32(i32 7, float %2124)  ; Saturate(value)
  %2128 = call float @dx.op.unary.f32(i32 7, float %2125)  ; Saturate(value)
  %2129 = call float @dx.op.unary.f32(i32 7, float %2126)  ; Saturate(value)
  br label %2130

; <label>:2130                                    ; preds = %2098, %1933
  %2131 = phi float [ %1964, %1933 ], [ %2127, %2098 ]
  %2132 = phi float [ %1965, %1933 ], [ %2128, %2098 ]
  %2133 = phi float [ %1966, %1933 ], [ %2129, %2098 ]
  %2134 = fsub fast float %2131, %596
  %2135 = fsub fast float %2132, %597
  %2136 = fsub fast float %2133, %598
  %2137 = fmul fast float %2134, %1920
  %2138 = fmul fast float %2135, %1920
  %2139 = fmul fast float %2136, %1920
  %2140 = fadd fast float %2137, %596
  %2141 = fadd fast float %2138, %597
  %2142 = fadd fast float %2139, %598
  br label %2143

; <label>:2143                                    ; preds = %2130, %1907
  %2144 = phi float [ %2140, %2130 ], [ %596, %1907 ]
  %2145 = phi float [ %2141, %2130 ], [ %597, %1907 ]
  %2146 = phi float [ %2142, %2130 ], [ %598, %1907 ]
  %2147 = call float @dx.op.binary.f32(i32 36, float %1888, float %1868)  ; FMin(a,b)
  %2148 = call float @dx.op.binary.f32(i32 36, float %1889, float %1869)  ; FMin(a,b)
  %2149 = call float @dx.op.binary.f32(i32 36, float %1890, float %1870)  ; FMin(a,b)
  %2150 = call float @dx.op.binary.f32(i32 36, float %2144, float %1908)  ; FMin(a,b)
  %2151 = call float @dx.op.binary.f32(i32 36, float %2145, float %1909)  ; FMin(a,b)
  %2152 = call float @dx.op.binary.f32(i32 36, float %2146, float %1910)  ; FMin(a,b)
  %2153 = call float @dx.op.binary.f32(i32 36, float %2150, float %2147)  ; FMin(a,b)
  %2154 = call float @dx.op.binary.f32(i32 36, float %2151, float %2148)  ; FMin(a,b)
  %2155 = call float @dx.op.binary.f32(i32 36, float %2152, float %2149)  ; FMin(a,b)
  %2156 = call float @dx.op.binary.f32(i32 36, float %596, float %2153)  ; FMin(a,b)
  %2157 = call float @dx.op.binary.f32(i32 36, float %597, float %2154)  ; FMin(a,b)
  %2158 = call float @dx.op.binary.f32(i32 36, float %598, float %2155)  ; FMin(a,b)
  %2159 = call float @dx.op.binary.f32(i32 35, float %1888, float %1868)  ; FMax(a,b)
  %2160 = call float @dx.op.binary.f32(i32 35, float %1889, float %1869)  ; FMax(a,b)
  %2161 = call float @dx.op.binary.f32(i32 35, float %1890, float %1870)  ; FMax(a,b)
  %2162 = call float @dx.op.binary.f32(i32 35, float %2144, float %1908)  ; FMax(a,b)
  %2163 = call float @dx.op.binary.f32(i32 35, float %2145, float %1909)  ; FMax(a,b)
  %2164 = call float @dx.op.binary.f32(i32 35, float %2146, float %1910)  ; FMax(a,b)
  %2165 = call float @dx.op.binary.f32(i32 35, float %2162, float %2159)  ; FMax(a,b)
  %2166 = call float @dx.op.binary.f32(i32 35, float %2163, float %2160)  ; FMax(a,b)
  %2167 = call float @dx.op.binary.f32(i32 35, float %2164, float %2161)  ; FMax(a,b)
  %2168 = call float @dx.op.binary.f32(i32 35, float %596, float %2165)  ; FMax(a,b)
  %2169 = call float @dx.op.binary.f32(i32 35, float %597, float %2166)  ; FMax(a,b)
  %2170 = call float @dx.op.binary.f32(i32 35, float %598, float %2167)  ; FMax(a,b)
  %2171 = fsub fast float %2168, %2156
  %2172 = fsub fast float %2169, %2157
  %2173 = fsub fast float %2170, %2158
  %2174 = call float @dx.op.unary.f32(i32 6, float %2171)  ; FAbs(value)
  %2175 = call float @dx.op.unary.f32(i32 6, float %2172)  ; FAbs(value)
  %2176 = call float @dx.op.unary.f32(i32 6, float %2173)  ; FAbs(value)
  %2177 = call float @dx.op.binary.f32(i32 35, float %2175, float %2176)  ; FMax(a,b)
  %2178 = call float @dx.op.binary.f32(i32 35, float %2174, float %2177)  ; FMax(a,b)
  %2179 = call float @dx.op.binary.f32(i32 35, float %2169, float %2170)  ; FMax(a,b)
  %2180 = call float @dx.op.binary.f32(i32 35, float %2168, float %2179)  ; FMax(a,b)
  %2181 = fmul fast float %2180, 1.250000e-01
  %2182 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %2181)  ; FMax(a,b)
  %2183 = fcmp fast ogt float %2178, %2182
  br i1 %2183, label %2184, label %2245

; <label>:2184                                    ; preds = %2143
  %2185 = fsub fast float %2144, %1908
  %2186 = fsub fast float %2145, %1909
  %2187 = fsub fast float %2146, %1910
  %2188 = call float @dx.op.unary.f32(i32 6, float %2185)  ; FAbs(value)
  %2189 = call float @dx.op.unary.f32(i32 6, float %2186)  ; FAbs(value)
  %2190 = call float @dx.op.unary.f32(i32 6, float %2187)  ; FAbs(value)
  %2191 = call float @dx.op.binary.f32(i32 35, float %2189, float %2190)  ; FMax(a,b)
  %2192 = call float @dx.op.binary.f32(i32 35, float %2188, float %2191)  ; FMax(a,b)
  %2193 = fsub fast float %1888, %1868
  %2194 = fsub fast float %1889, %1869
  %2195 = fsub fast float %1890, %1870
  %2196 = call float @dx.op.unary.f32(i32 6, float %2193)  ; FAbs(value)
  %2197 = call float @dx.op.unary.f32(i32 6, float %2194)  ; FAbs(value)
  %2198 = call float @dx.op.unary.f32(i32 6, float %2195)  ; FAbs(value)
  %2199 = call float @dx.op.binary.f32(i32 35, float %2197, float %2198)  ; FMax(a,b)
  %2200 = call float @dx.op.binary.f32(i32 35, float %2196, float %2199)  ; FMax(a,b)
  %2201 = fcmp fast olt float %2192, %2200
  %2202 = select i1 %2201, float %2144, float %1888
  %2203 = select i1 %2201, float %2145, float %1889
  %2204 = select i1 %2201, float %2146, float %1890
  %2205 = select i1 %2201, float %1908, float %1868
  %2206 = select i1 %2201, float %1909, float %1869
  %2207 = select i1 %2201, float %1910, float %1870
  %2208 = fsub fast float %596, %2205
  %2209 = fsub fast float %597, %2206
  %2210 = fsub fast float %598, %2207
  %2211 = fsub fast float %596, %2202
  %2212 = fsub fast float %597, %2203
  %2213 = fsub fast float %598, %2204
  %2214 = call float @dx.op.dot3.f32(i32 55, float %2211, float %2212, float %2213, float %2208, float %2209, float %2210)  ; Dot3(ax,ay,az,bx,by,bz)
  %2215 = fcmp fast ogt float %2214, 0.000000e+00
  br i1 %2215, label %2216, label %2227

; <label>:2216                                    ; preds = %2184
  %2217 = fsub fast float %2202, %2205
  %2218 = fsub fast float %2203, %2206
  %2219 = fsub fast float %2204, %2207
  %2220 = call float @dx.op.unary.f32(i32 6, float %2217)  ; FAbs(value)
  %2221 = call float @dx.op.unary.f32(i32 6, float %2218)  ; FAbs(value)
  %2222 = call float @dx.op.unary.f32(i32 6, float %2219)  ; FAbs(value)
  %2223 = call float @dx.op.binary.f32(i32 35, float %2221, float %2222)  ; FMax(a,b)
  %2224 = call float @dx.op.binary.f32(i32 35, float %2220, float %2223)  ; FMax(a,b)
  %2225 = fmul fast float %2178, 2.500000e-01
  %2226 = fcmp fast olt float %2224, %2225
  br label %2227

; <label>:2227                                    ; preds = %2216, %2184
  %2228 = phi i1 [ false, %2184 ], [ %2226, %2216 ]
  %2229 = select i1 %2228, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  %2230 = fadd fast float %2202, %2205
  %2231 = fadd fast float %2203, %2206
  %2232 = fadd fast float %2204, %2207
  %2233 = fmul fast float %2230, 5.000000e-01
  %2234 = fmul fast float %2231, 5.000000e-01
  %2235 = fmul fast float %2232, 5.000000e-01
  %2236 = fsub fast float %2233, %596
  %2237 = fsub fast float %2234, %597
  %2238 = fsub fast float %2235, %598
  %2239 = fmul fast float %2229, %2236
  %2240 = fmul fast float %2229, %2237
  %2241 = fmul fast float %2229, %2238
  %2242 = fadd fast float %2239, %596
  %2243 = fadd fast float %2240, %597
  %2244 = fadd fast float %2241, %598
  br label %2245

; <label>:2245                                    ; preds = %2227, %2143, %1626
  %2246 = phi float [ %596, %1626 ], [ %2242, %2227 ], [ %596, %2143 ]
  %2247 = phi float [ %597, %1626 ], [ %2243, %2227 ], [ %597, %2143 ]
  %2248 = phi float [ %598, %1626 ], [ %2244, %2227 ], [ %598, %2143 ]
  %2249 = fcmp fast ult float %189, 0.000000e+00
  br i1 %2249, label %2864, label %2250

; <label>:2250                                    ; preds = %2245
  %2251 = fsub fast float 1.000000e+00, %86
  %2252 = fmul fast float %2251, 0x3FA99999A0000000
  %2253 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %2252)  ; FMax(a,b)
  %2254 = fsub fast float %88, %86
  %2255 = call float @dx.op.unary.f32(i32 6, float %2254)  ; FAbs(value)
  %2256 = fdiv fast float %2255, %2253
  %2257 = fsub fast float 1.000000e+00, %2256
  %2258 = call float @dx.op.unary.f32(i32 7, float %2257)  ; Saturate(value)
  %2259 = fcmp fast ugt float %2258, 0.000000e+00
  br i1 %2259, label %2260, label %2270

; <label>:2260                                    ; preds = %2250
  %2261 = fsub fast float %1000, %798
  %2262 = fsub fast float %1001, %799
  %2263 = fsub fast float %1002, %800
  %2264 = fmul fast float %2258, %2261
  %2265 = fmul fast float %2258, %2262
  %2266 = fmul fast float %2258, %2263
  %2267 = fadd fast float %2264, %798
  %2268 = fadd fast float %2265, %799
  %2269 = fadd fast float %2266, %800
  br label %2270

; <label>:2270                                    ; preds = %2260, %2250
  %2271 = phi float [ %2267, %2260 ], [ %798, %2250 ]
  %2272 = phi float [ %2268, %2260 ], [ %799, %2250 ]
  %2273 = phi float [ %2269, %2260 ], [ %800, %2250 ]
  %2274 = add i32 %55, -1
  %2275 = call i32 @dx.op.binary.i32(i32 37, i32 %2274, i32 0)  ; IMax(a,b)
  %2276 = call i32 @dx.op.binary.i32(i32 38, i32 %2275, i32 %59)  ; IMin(a,b)
  %2277 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2276, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2278 = extractvalue %dx.types.ResRet.f32 %2277, 0
  %2279 = fsub fast float %2278, %86
  %2280 = call float @dx.op.unary.f32(i32 6, float %2279)  ; FAbs(value)
  %2281 = fdiv fast float %2280, %2253
  %2282 = fsub fast float 1.000000e+00, %2281
  %2283 = call float @dx.op.unary.f32(i32 7, float %2282)  ; Saturate(value)
  %2284 = fcmp fast ugt float %2283, 0.000000e+00
  br i1 %2284, label %2285, label %2506

; <label>:2285                                    ; preds = %2270
  %2286 = call i32 @dx.op.binary.i32(i32 37, i32 %2276, i32 0)  ; IMax(a,b)
  %2287 = call i32 @dx.op.binary.i32(i32 37, i32 %70, i32 0)  ; IMax(a,b)
  %2288 = call i32 @dx.op.binary.i32(i32 38, i32 %2286, i32 %59)  ; IMin(a,b)
  %2289 = call i32 @dx.op.binary.i32(i32 38, i32 %2287, i32 %60)  ; IMin(a,b)
  %2290 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2288, i32 %2289, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2291 = extractvalue %dx.types.ResRet.f32 %2290, 0
  %2292 = extractvalue %dx.types.ResRet.f32 %2290, 1
  %2293 = extractvalue %dx.types.ResRet.f32 %2290, 2
  %2294 = extractvalue %dx.types.ResRet.f32 %2290, 3
  %2295 = fcmp fast olt float %2294, 0.000000e+00
  br i1 %2295, label %2296, label %2330

; <label>:2296                                    ; preds = %2285
  %2297 = fcmp fast ogt float %2291, 0x3FA4B5DCC0000000
  %2298 = fcmp fast ogt float %2292, 0x3FA4B5DCC0000000
  %2299 = fcmp fast ogt float %2293, 0x3FA4B5DCC0000000
  %2300 = select i1 %2297, float 0.000000e+00, float 1.000000e+00
  %2301 = select i1 %2298, float 0.000000e+00, float 1.000000e+00
  %2302 = select i1 %2299, float 0.000000e+00, float 1.000000e+00
  %2303 = fmul fast float %2291, 0x3FB3D07220000000
  %2304 = fmul fast float %2292, 0x3FB3D07220000000
  %2305 = fmul fast float %2293, 0x3FB3D07220000000
  %2306 = fadd fast float %2291, 0x3FAC28F5C0000000
  %2307 = fadd fast float %2292, 0x3FAC28F5C0000000
  %2308 = fadd fast float %2293, 0x3FAC28F5C0000000
  %2309 = fmul fast float %2306, 0x3FEE54EDE0000000
  %2310 = fmul fast float %2307, 0x3FEE54EDE0000000
  %2311 = fmul fast float %2308, 0x3FEE54EDE0000000
  %2312 = call float @dx.op.unary.f32(i32 23, float %2309)  ; Log(value)
  %2313 = call float @dx.op.unary.f32(i32 23, float %2310)  ; Log(value)
  %2314 = call float @dx.op.unary.f32(i32 23, float %2311)  ; Log(value)
  %2315 = fmul fast float %2312, 0x4003333340000000
  %2316 = fmul fast float %2313, 0x4003333340000000
  %2317 = fmul fast float %2314, 0x4003333340000000
  %2318 = call float @dx.op.unary.f32(i32 21, float %2315)  ; Exp(value)
  %2319 = call float @dx.op.unary.f32(i32 21, float %2316)  ; Exp(value)
  %2320 = call float @dx.op.unary.f32(i32 21, float %2317)  ; Exp(value)
  %2321 = fsub fast float %2303, %2318
  %2322 = fsub fast float %2304, %2319
  %2323 = fsub fast float %2305, %2320
  %2324 = fmul fast float %2321, %2300
  %2325 = fmul fast float %2322, %2301
  %2326 = fmul fast float %2323, %2302
  %2327 = fadd fast float %2324, %2318
  %2328 = fadd fast float %2325, %2319
  %2329 = fadd fast float %2326, %2320
  br label %2493

; <label>:2330                                    ; preds = %2285
  %2331 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2288, i32 %2289, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2332 = extractvalue %dx.types.ResRet.f32 %2331, 0
  %2333 = fcmp fast ogt float %38, 5.000000e-01
  %2334 = fcmp fast olt float %2332, 1.000000e+00
  %2335 = and i1 %2333, %2334
  br i1 %2335, label %2336, label %2422

; <label>:2336                                    ; preds = %2330
  %2337 = sitofp i32 %2288 to float
  %2338 = sitofp i32 %2289 to float
  %2339 = fadd fast float %2337, 5.000000e-01
  %2340 = fadd fast float %2338, 5.000000e-01
  %2341 = fdiv fast float %2339, %45
  %2342 = fdiv fast float %2340, %46
  %2343 = fmul fast float %2341, 2.000000e+00
  %2344 = fmul fast float %2342, 2.000000e+00
  %2345 = fadd fast float %2343, -1.000000e+00
  %2346 = fsub fast float 1.000000e+00, %2344
  %2347 = fmul fast float %2345, %35
  %2348 = call float @dx.op.tertiary.f32(i32 46, float %2346, float %31, float %2347)  ; FMad(a,b,c)
  %2349 = call float @dx.op.tertiary.f32(i32 46, float %2332, float %27, float %2348)  ; FMad(a,b,c)
  %2350 = fadd fast float %2349, %23
  %2351 = call float @dx.op.unary.f32(i32 6, float %2350)  ; FAbs(value)
  %2352 = fcmp fast ogt float %2351, 0x3EB0C6F7A0000000
  br i1 %2352, label %2353, label %2422

; <label>:2353                                    ; preds = %2336
  %2354 = fmul fast float %2345, %34
  %2355 = call float @dx.op.tertiary.f32(i32 46, float %2346, float %30, float %2354)  ; FMad(a,b,c)
  %2356 = call float @dx.op.tertiary.f32(i32 46, float %2332, float %26, float %2355)  ; FMad(a,b,c)
  %2357 = fadd fast float %2356, %22
  %2358 = fmul fast float %2345, %33
  %2359 = call float @dx.op.tertiary.f32(i32 46, float %2346, float %29, float %2358)  ; FMad(a,b,c)
  %2360 = call float @dx.op.tertiary.f32(i32 46, float %2332, float %25, float %2359)  ; FMad(a,b,c)
  %2361 = fadd fast float %2360, %21
  %2362 = fmul fast float %2345, %32
  %2363 = call float @dx.op.tertiary.f32(i32 46, float %2346, float %28, float %2362)  ; FMad(a,b,c)
  %2364 = call float @dx.op.tertiary.f32(i32 46, float %2332, float %24, float %2363)  ; FMad(a,b,c)
  %2365 = fadd fast float %2364, %20
  %2366 = fdiv fast float %2365, %2350
  %2367 = fdiv fast float %2361, %2350
  %2368 = fdiv fast float %2357, %2350
  %2369 = fsub fast float %2366, %17
  %2370 = fsub fast float %2367, %18
  %2371 = fsub fast float %2368, %19
  %2372 = fmul fast float %2369, %2369
  %2373 = fmul fast float %2370, %2370
  %2374 = fadd fast float %2373, %2372
  %2375 = fmul fast float %2371, %2371
  %2376 = fadd fast float %2374, %2375
  %2377 = call float @dx.op.unary.f32(i32 24, float %2376)  ; Sqrt(value)
  %2378 = fsub fast float %2377, %9
  %2379 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2378)  ; FMax(a,b)
  %2380 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %2380, label %2381, label %2404

; <label>:2381                                    ; preds = %2353
  %2382 = call float @dx.op.unary.f32(i32 6, float %2370)  ; FAbs(value)
  %2383 = fmul fast float %2382, %11
  %2384 = fcmp fast olt float %2383, 0x3F50624DE0000000
  br i1 %2384, label %2385, label %2388

; <label>:2385                                    ; preds = %2381
  %2386 = fmul fast float %2383, 5.000000e-01
  %2387 = fsub fast float 1.000000e+00, %2386
  br label %2393

; <label>:2388                                    ; preds = %2381
  %2389 = fmul fast float %2383, 0xBFF7154760000000
  %2390 = call float @dx.op.unary.f32(i32 21, float %2389)  ; Exp(value)
  %2391 = fsub fast float 1.000000e+00, %2390
  %2392 = fdiv fast float %2391, %2383
  br label %2393

; <label>:2393                                    ; preds = %2388, %2385
  %2394 = phi float [ %2387, %2385 ], [ %2392, %2388 ]
  %2395 = call float @dx.op.binary.f32(i32 36, float %2367, float %18)  ; FMin(a,b)
  %2396 = fsub fast float %2395, %10
  %2397 = fmul fast float %11, %2396
  %2398 = fsub fast float -0.000000e+00, %2397
  %2399 = call float @dx.op.binary.f32(i32 35, float %2398, float -4.000000e+01)  ; FMax(a,b)
  %2400 = call float @dx.op.binary.f32(i32 36, float %2399, float 5.000000e+00)  ; FMin(a,b)
  %2401 = fmul fast float %2400, 0x3FF7154760000000
  %2402 = call float @dx.op.unary.f32(i32 21, float %2401)  ; Exp(value)
  %2403 = fmul fast float %2402, %2394
  br label %2404

; <label>:2404                                    ; preds = %2393, %2353
  %2405 = phi float [ %2403, %2393 ], [ 1.000000e+00, %2353 ]
  %2406 = fmul fast float %2379, %16
  %2407 = fmul fast float %2406, %2405
  %2408 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2407)  ; FMin(a,b)
  %2409 = fmul fast float %2408, 0xBFF7154760000000
  %2410 = call float @dx.op.unary.f32(i32 21, float %2409)  ; Exp(value)
  %2411 = fsub fast float 1.000000e+00, %2410
  %2412 = call float @dx.op.binary.f32(i32 36, float %12, float %2411)  ; FMin(a,b)
  %2413 = fsub fast float %13, %2291
  %2414 = fsub fast float %14, %2292
  %2415 = fsub fast float %15, %2293
  %2416 = fmul fast float %2412, %2413
  %2417 = fmul fast float %2412, %2414
  %2418 = fmul fast float %2412, %2415
  %2419 = fadd fast float %2416, %2291
  %2420 = fadd fast float %2417, %2292
  %2421 = fadd fast float %2418, %2293
  br label %2422

; <label>:2422                                    ; preds = %2404, %2336, %2330
  %2423 = phi float [ %2419, %2404 ], [ %2291, %2336 ], [ %2291, %2330 ]
  %2424 = phi float [ %2420, %2404 ], [ %2292, %2336 ], [ %2292, %2330 ]
  %2425 = phi float [ %2421, %2404 ], [ %2293, %2336 ], [ %2293, %2330 ]
  %2426 = fadd fast float %5, 1.000000e+00
  %2427 = fadd fast float %6, 1.000000e+00
  %2428 = fsub fast float 1.000000e+00, %5
  %2429 = fmul fast float %36, %2426
  %2430 = fmul fast float %36, %2427
  %2431 = fmul fast float %36, %2428
  %2432 = fmul fast float %2429, %2423
  %2433 = fmul fast float %2430, %2424
  %2434 = fmul fast float %2431, %2425
  %2435 = fcmp fast ult float %37, 5.000000e-01
  br i1 %2435, label %2461, label %2436

; <label>:2436                                    ; preds = %2422
  %2437 = fmul fast float %2432, 0x4004147AE0000000
  %2438 = fmul fast float %2433, 0x4004147AE0000000
  %2439 = fmul fast float %2434, 0x4004147AE0000000
  %2440 = fadd fast float %2437, 0x3F9EB851E0000000
  %2441 = fadd fast float %2438, 0x3F9EB851E0000000
  %2442 = fadd fast float %2439, 0x3F9EB851E0000000
  %2443 = fmul fast float %2440, %2432
  %2444 = fmul fast float %2441, %2433
  %2445 = fmul fast float %2442, %2434
  %2446 = fmul fast float %2432, 0x400370A3E0000000
  %2447 = fmul fast float %2433, 0x400370A3E0000000
  %2448 = fmul fast float %2434, 0x400370A3E0000000
  %2449 = fadd fast float %2446, 0x3FE2E147A0000000
  %2450 = fadd fast float %2447, 0x3FE2E147A0000000
  %2451 = fadd fast float %2448, 0x3FE2E147A0000000
  %2452 = fmul fast float %2449, %2432
  %2453 = fmul fast float %2450, %2433
  %2454 = fmul fast float %2451, %2434
  %2455 = fadd fast float %2452, 0x3FC1EB8520000000
  %2456 = fadd fast float %2453, 0x3FC1EB8520000000
  %2457 = fadd fast float %2454, 0x3FC1EB8520000000
  %2458 = fdiv fast float %2443, %2455
  %2459 = fdiv fast float %2444, %2456
  %2460 = fdiv fast float %2445, %2457
  br label %2461

; <label>:2461                                    ; preds = %2436, %2422
  %2462 = phi float [ %2458, %2436 ], [ %2432, %2422 ]
  %2463 = phi float [ %2459, %2436 ], [ %2433, %2422 ]
  %2464 = phi float [ %2460, %2436 ], [ %2434, %2422 ]
  %2465 = call float @dx.op.unary.f32(i32 7, float %2462)  ; Saturate(value)
  %2466 = call float @dx.op.unary.f32(i32 7, float %2463)  ; Saturate(value)
  %2467 = call float @dx.op.unary.f32(i32 7, float %2464)  ; Saturate(value)
  %2468 = call float @dx.op.dot3.f32(i32 55, float %2465, float %2466, float %2467, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2469 = fsub fast float %2465, %2468
  %2470 = fsub fast float %2466, %2468
  %2471 = fsub fast float %2467, %2468
  %2472 = fmul fast float %2469, %8
  %2473 = fmul fast float %2470, %8
  %2474 = fmul fast float %2471, %8
  %2475 = fadd fast float %2472, %2468
  %2476 = fadd fast float %2473, %2468
  %2477 = fadd fast float %2474, %2468
  %2478 = call float @dx.op.unary.f32(i32 7, float %2475)  ; Saturate(value)
  %2479 = call float @dx.op.unary.f32(i32 7, float %2476)  ; Saturate(value)
  %2480 = call float @dx.op.unary.f32(i32 7, float %2477)  ; Saturate(value)
  %2481 = fadd fast float %2478, 0xBFC70A3D80000000
  %2482 = fadd fast float %2479, 0xBFC70A3D80000000
  %2483 = fadd fast float %2480, 0xBFC70A3D80000000
  %2484 = fmul fast float %2481, %7
  %2485 = fmul fast float %2482, %7
  %2486 = fmul fast float %2483, %7
  %2487 = fadd fast float %2484, 0x3FC70A3D80000000
  %2488 = fadd fast float %2485, 0x3FC70A3D80000000
  %2489 = fadd fast float %2486, 0x3FC70A3D80000000
  %2490 = call float @dx.op.unary.f32(i32 7, float %2487)  ; Saturate(value)
  %2491 = call float @dx.op.unary.f32(i32 7, float %2488)  ; Saturate(value)
  %2492 = call float @dx.op.unary.f32(i32 7, float %2489)  ; Saturate(value)
  br label %2493

; <label>:2493                                    ; preds = %2461, %2296
  %2494 = phi float [ %2327, %2296 ], [ %2490, %2461 ]
  %2495 = phi float [ %2328, %2296 ], [ %2491, %2461 ]
  %2496 = phi float [ %2329, %2296 ], [ %2492, %2461 ]
  %2497 = fsub fast float %2494, %798
  %2498 = fsub fast float %2495, %799
  %2499 = fsub fast float %2496, %800
  %2500 = fmul fast float %2497, %2283
  %2501 = fmul fast float %2498, %2283
  %2502 = fmul fast float %2499, %2283
  %2503 = fadd fast float %2500, %798
  %2504 = fadd fast float %2501, %799
  %2505 = fadd fast float %2502, %800
  br label %2506

; <label>:2506                                    ; preds = %2493, %2270
  %2507 = phi float [ %2503, %2493 ], [ %798, %2270 ]
  %2508 = phi float [ %2504, %2493 ], [ %799, %2270 ]
  %2509 = phi float [ %2505, %2493 ], [ %800, %2270 ]
  %2510 = add i32 %56, 2
  %2511 = call i32 @dx.op.binary.i32(i32 37, i32 %2510, i32 0)  ; IMax(a,b)
  %2512 = call i32 @dx.op.binary.i32(i32 38, i32 %2511, i32 %60)  ; IMin(a,b)
  %2513 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %2512, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2514 = extractvalue %dx.types.ResRet.f32 %2513, 0
  %2515 = fsub fast float %2514, %86
  %2516 = call float @dx.op.unary.f32(i32 6, float %2515)  ; FAbs(value)
  %2517 = fdiv fast float %2516, %2253
  %2518 = fsub fast float 1.000000e+00, %2517
  %2519 = call float @dx.op.unary.f32(i32 7, float %2518)  ; Saturate(value)
  %2520 = fcmp fast ugt float %2519, 0.000000e+00
  br i1 %2520, label %2521, label %2742

; <label>:2521                                    ; preds = %2506
  %2522 = call i32 @dx.op.binary.i32(i32 37, i32 %63, i32 0)  ; IMax(a,b)
  %2523 = call i32 @dx.op.binary.i32(i32 37, i32 %2512, i32 0)  ; IMax(a,b)
  %2524 = call i32 @dx.op.binary.i32(i32 38, i32 %2522, i32 %59)  ; IMin(a,b)
  %2525 = call i32 @dx.op.binary.i32(i32 38, i32 %2523, i32 %60)  ; IMin(a,b)
  %2526 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2524, i32 %2525, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2527 = extractvalue %dx.types.ResRet.f32 %2526, 0
  %2528 = extractvalue %dx.types.ResRet.f32 %2526, 1
  %2529 = extractvalue %dx.types.ResRet.f32 %2526, 2
  %2530 = extractvalue %dx.types.ResRet.f32 %2526, 3
  %2531 = fcmp fast olt float %2530, 0.000000e+00
  br i1 %2531, label %2532, label %2566

; <label>:2532                                    ; preds = %2521
  %2533 = fcmp fast ogt float %2527, 0x3FA4B5DCC0000000
  %2534 = fcmp fast ogt float %2528, 0x3FA4B5DCC0000000
  %2535 = fcmp fast ogt float %2529, 0x3FA4B5DCC0000000
  %2536 = select i1 %2533, float 0.000000e+00, float 1.000000e+00
  %2537 = select i1 %2534, float 0.000000e+00, float 1.000000e+00
  %2538 = select i1 %2535, float 0.000000e+00, float 1.000000e+00
  %2539 = fmul fast float %2527, 0x3FB3D07220000000
  %2540 = fmul fast float %2528, 0x3FB3D07220000000
  %2541 = fmul fast float %2529, 0x3FB3D07220000000
  %2542 = fadd fast float %2527, 0x3FAC28F5C0000000
  %2543 = fadd fast float %2528, 0x3FAC28F5C0000000
  %2544 = fadd fast float %2529, 0x3FAC28F5C0000000
  %2545 = fmul fast float %2542, 0x3FEE54EDE0000000
  %2546 = fmul fast float %2543, 0x3FEE54EDE0000000
  %2547 = fmul fast float %2544, 0x3FEE54EDE0000000
  %2548 = call float @dx.op.unary.f32(i32 23, float %2545)  ; Log(value)
  %2549 = call float @dx.op.unary.f32(i32 23, float %2546)  ; Log(value)
  %2550 = call float @dx.op.unary.f32(i32 23, float %2547)  ; Log(value)
  %2551 = fmul fast float %2548, 0x4003333340000000
  %2552 = fmul fast float %2549, 0x4003333340000000
  %2553 = fmul fast float %2550, 0x4003333340000000
  %2554 = call float @dx.op.unary.f32(i32 21, float %2551)  ; Exp(value)
  %2555 = call float @dx.op.unary.f32(i32 21, float %2552)  ; Exp(value)
  %2556 = call float @dx.op.unary.f32(i32 21, float %2553)  ; Exp(value)
  %2557 = fsub fast float %2539, %2554
  %2558 = fsub fast float %2540, %2555
  %2559 = fsub fast float %2541, %2556
  %2560 = fmul fast float %2557, %2536
  %2561 = fmul fast float %2558, %2537
  %2562 = fmul fast float %2559, %2538
  %2563 = fadd fast float %2560, %2554
  %2564 = fadd fast float %2561, %2555
  %2565 = fadd fast float %2562, %2556
  br label %2729

; <label>:2566                                    ; preds = %2521
  %2567 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2524, i32 %2525, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2568 = extractvalue %dx.types.ResRet.f32 %2567, 0
  %2569 = fcmp fast ogt float %38, 5.000000e-01
  %2570 = fcmp fast olt float %2568, 1.000000e+00
  %2571 = and i1 %2569, %2570
  br i1 %2571, label %2572, label %2658

; <label>:2572                                    ; preds = %2566
  %2573 = sitofp i32 %2524 to float
  %2574 = sitofp i32 %2525 to float
  %2575 = fadd fast float %2573, 5.000000e-01
  %2576 = fadd fast float %2574, 5.000000e-01
  %2577 = fdiv fast float %2575, %45
  %2578 = fdiv fast float %2576, %46
  %2579 = fmul fast float %2577, 2.000000e+00
  %2580 = fmul fast float %2578, 2.000000e+00
  %2581 = fadd fast float %2579, -1.000000e+00
  %2582 = fsub fast float 1.000000e+00, %2580
  %2583 = fmul fast float %2581, %35
  %2584 = call float @dx.op.tertiary.f32(i32 46, float %2582, float %31, float %2583)  ; FMad(a,b,c)
  %2585 = call float @dx.op.tertiary.f32(i32 46, float %2568, float %27, float %2584)  ; FMad(a,b,c)
  %2586 = fadd fast float %2585, %23
  %2587 = call float @dx.op.unary.f32(i32 6, float %2586)  ; FAbs(value)
  %2588 = fcmp fast ogt float %2587, 0x3EB0C6F7A0000000
  br i1 %2588, label %2589, label %2658

; <label>:2589                                    ; preds = %2572
  %2590 = fmul fast float %2581, %34
  %2591 = call float @dx.op.tertiary.f32(i32 46, float %2582, float %30, float %2590)  ; FMad(a,b,c)
  %2592 = call float @dx.op.tertiary.f32(i32 46, float %2568, float %26, float %2591)  ; FMad(a,b,c)
  %2593 = fadd fast float %2592, %22
  %2594 = fmul fast float %2581, %33
  %2595 = call float @dx.op.tertiary.f32(i32 46, float %2582, float %29, float %2594)  ; FMad(a,b,c)
  %2596 = call float @dx.op.tertiary.f32(i32 46, float %2568, float %25, float %2595)  ; FMad(a,b,c)
  %2597 = fadd fast float %2596, %21
  %2598 = fmul fast float %2581, %32
  %2599 = call float @dx.op.tertiary.f32(i32 46, float %2582, float %28, float %2598)  ; FMad(a,b,c)
  %2600 = call float @dx.op.tertiary.f32(i32 46, float %2568, float %24, float %2599)  ; FMad(a,b,c)
  %2601 = fadd fast float %2600, %20
  %2602 = fdiv fast float %2601, %2586
  %2603 = fdiv fast float %2597, %2586
  %2604 = fdiv fast float %2593, %2586
  %2605 = fsub fast float %2602, %17
  %2606 = fsub fast float %2603, %18
  %2607 = fsub fast float %2604, %19
  %2608 = fmul fast float %2605, %2605
  %2609 = fmul fast float %2606, %2606
  %2610 = fadd fast float %2609, %2608
  %2611 = fmul fast float %2607, %2607
  %2612 = fadd fast float %2610, %2611
  %2613 = call float @dx.op.unary.f32(i32 24, float %2612)  ; Sqrt(value)
  %2614 = fsub fast float %2613, %9
  %2615 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2614)  ; FMax(a,b)
  %2616 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %2616, label %2617, label %2640

; <label>:2617                                    ; preds = %2589
  %2618 = call float @dx.op.unary.f32(i32 6, float %2606)  ; FAbs(value)
  %2619 = fmul fast float %2618, %11
  %2620 = fcmp fast olt float %2619, 0x3F50624DE0000000
  br i1 %2620, label %2621, label %2624

; <label>:2621                                    ; preds = %2617
  %2622 = fmul fast float %2619, 5.000000e-01
  %2623 = fsub fast float 1.000000e+00, %2622
  br label %2629

; <label>:2624                                    ; preds = %2617
  %2625 = fmul fast float %2619, 0xBFF7154760000000
  %2626 = call float @dx.op.unary.f32(i32 21, float %2625)  ; Exp(value)
  %2627 = fsub fast float 1.000000e+00, %2626
  %2628 = fdiv fast float %2627, %2619
  br label %2629

; <label>:2629                                    ; preds = %2624, %2621
  %2630 = phi float [ %2623, %2621 ], [ %2628, %2624 ]
  %2631 = call float @dx.op.binary.f32(i32 36, float %2603, float %18)  ; FMin(a,b)
  %2632 = fsub fast float %2631, %10
  %2633 = fmul fast float %11, %2632
  %2634 = fsub fast float -0.000000e+00, %2633
  %2635 = call float @dx.op.binary.f32(i32 35, float %2634, float -4.000000e+01)  ; FMax(a,b)
  %2636 = call float @dx.op.binary.f32(i32 36, float %2635, float 5.000000e+00)  ; FMin(a,b)
  %2637 = fmul fast float %2636, 0x3FF7154760000000
  %2638 = call float @dx.op.unary.f32(i32 21, float %2637)  ; Exp(value)
  %2639 = fmul fast float %2638, %2630
  br label %2640

; <label>:2640                                    ; preds = %2629, %2589
  %2641 = phi float [ %2639, %2629 ], [ 1.000000e+00, %2589 ]
  %2642 = fmul fast float %2615, %16
  %2643 = fmul fast float %2642, %2641
  %2644 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2643)  ; FMin(a,b)
  %2645 = fmul fast float %2644, 0xBFF7154760000000
  %2646 = call float @dx.op.unary.f32(i32 21, float %2645)  ; Exp(value)
  %2647 = fsub fast float 1.000000e+00, %2646
  %2648 = call float @dx.op.binary.f32(i32 36, float %12, float %2647)  ; FMin(a,b)
  %2649 = fsub fast float %13, %2527
  %2650 = fsub fast float %14, %2528
  %2651 = fsub fast float %15, %2529
  %2652 = fmul fast float %2648, %2649
  %2653 = fmul fast float %2648, %2650
  %2654 = fmul fast float %2648, %2651
  %2655 = fadd fast float %2652, %2527
  %2656 = fadd fast float %2653, %2528
  %2657 = fadd fast float %2654, %2529
  br label %2658

; <label>:2658                                    ; preds = %2640, %2572, %2566
  %2659 = phi float [ %2655, %2640 ], [ %2527, %2572 ], [ %2527, %2566 ]
  %2660 = phi float [ %2656, %2640 ], [ %2528, %2572 ], [ %2528, %2566 ]
  %2661 = phi float [ %2657, %2640 ], [ %2529, %2572 ], [ %2529, %2566 ]
  %2662 = fadd fast float %5, 1.000000e+00
  %2663 = fadd fast float %6, 1.000000e+00
  %2664 = fsub fast float 1.000000e+00, %5
  %2665 = fmul fast float %36, %2662
  %2666 = fmul fast float %36, %2663
  %2667 = fmul fast float %36, %2664
  %2668 = fmul fast float %2665, %2659
  %2669 = fmul fast float %2666, %2660
  %2670 = fmul fast float %2667, %2661
  %2671 = fcmp fast ult float %37, 5.000000e-01
  br i1 %2671, label %2697, label %2672

; <label>:2672                                    ; preds = %2658
  %2673 = fmul fast float %2668, 0x4004147AE0000000
  %2674 = fmul fast float %2669, 0x4004147AE0000000
  %2675 = fmul fast float %2670, 0x4004147AE0000000
  %2676 = fadd fast float %2673, 0x3F9EB851E0000000
  %2677 = fadd fast float %2674, 0x3F9EB851E0000000
  %2678 = fadd fast float %2675, 0x3F9EB851E0000000
  %2679 = fmul fast float %2676, %2668
  %2680 = fmul fast float %2677, %2669
  %2681 = fmul fast float %2678, %2670
  %2682 = fmul fast float %2668, 0x400370A3E0000000
  %2683 = fmul fast float %2669, 0x400370A3E0000000
  %2684 = fmul fast float %2670, 0x400370A3E0000000
  %2685 = fadd fast float %2682, 0x3FE2E147A0000000
  %2686 = fadd fast float %2683, 0x3FE2E147A0000000
  %2687 = fadd fast float %2684, 0x3FE2E147A0000000
  %2688 = fmul fast float %2685, %2668
  %2689 = fmul fast float %2686, %2669
  %2690 = fmul fast float %2687, %2670
  %2691 = fadd fast float %2688, 0x3FC1EB8520000000
  %2692 = fadd fast float %2689, 0x3FC1EB8520000000
  %2693 = fadd fast float %2690, 0x3FC1EB8520000000
  %2694 = fdiv fast float %2679, %2691
  %2695 = fdiv fast float %2680, %2692
  %2696 = fdiv fast float %2681, %2693
  br label %2697

; <label>:2697                                    ; preds = %2672, %2658
  %2698 = phi float [ %2694, %2672 ], [ %2668, %2658 ]
  %2699 = phi float [ %2695, %2672 ], [ %2669, %2658 ]
  %2700 = phi float [ %2696, %2672 ], [ %2670, %2658 ]
  %2701 = call float @dx.op.unary.f32(i32 7, float %2698)  ; Saturate(value)
  %2702 = call float @dx.op.unary.f32(i32 7, float %2699)  ; Saturate(value)
  %2703 = call float @dx.op.unary.f32(i32 7, float %2700)  ; Saturate(value)
  %2704 = call float @dx.op.dot3.f32(i32 55, float %2701, float %2702, float %2703, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2705 = fsub fast float %2701, %2704
  %2706 = fsub fast float %2702, %2704
  %2707 = fsub fast float %2703, %2704
  %2708 = fmul fast float %2705, %8
  %2709 = fmul fast float %2706, %8
  %2710 = fmul fast float %2707, %8
  %2711 = fadd fast float %2708, %2704
  %2712 = fadd fast float %2709, %2704
  %2713 = fadd fast float %2710, %2704
  %2714 = call float @dx.op.unary.f32(i32 7, float %2711)  ; Saturate(value)
  %2715 = call float @dx.op.unary.f32(i32 7, float %2712)  ; Saturate(value)
  %2716 = call float @dx.op.unary.f32(i32 7, float %2713)  ; Saturate(value)
  %2717 = fadd fast float %2714, 0xBFC70A3D80000000
  %2718 = fadd fast float %2715, 0xBFC70A3D80000000
  %2719 = fadd fast float %2716, 0xBFC70A3D80000000
  %2720 = fmul fast float %2717, %7
  %2721 = fmul fast float %2718, %7
  %2722 = fmul fast float %2719, %7
  %2723 = fadd fast float %2720, 0x3FC70A3D80000000
  %2724 = fadd fast float %2721, 0x3FC70A3D80000000
  %2725 = fadd fast float %2722, 0x3FC70A3D80000000
  %2726 = call float @dx.op.unary.f32(i32 7, float %2723)  ; Saturate(value)
  %2727 = call float @dx.op.unary.f32(i32 7, float %2724)  ; Saturate(value)
  %2728 = call float @dx.op.unary.f32(i32 7, float %2725)  ; Saturate(value)
  br label %2729

; <label>:2729                                    ; preds = %2697, %2532
  %2730 = phi float [ %2563, %2532 ], [ %2726, %2697 ]
  %2731 = phi float [ %2564, %2532 ], [ %2727, %2697 ]
  %2732 = phi float [ %2565, %2532 ], [ %2728, %2697 ]
  %2733 = fsub fast float %2730, %798
  %2734 = fsub fast float %2731, %799
  %2735 = fsub fast float %2732, %800
  %2736 = fmul fast float %2733, %2519
  %2737 = fmul fast float %2734, %2519
  %2738 = fmul fast float %2735, %2519
  %2739 = fadd fast float %2736, %798
  %2740 = fadd fast float %2737, %799
  %2741 = fadd fast float %2738, %800
  br label %2742

; <label>:2742                                    ; preds = %2729, %2506
  %2743 = phi float [ %2739, %2729 ], [ %798, %2506 ]
  %2744 = phi float [ %2740, %2729 ], [ %799, %2506 ]
  %2745 = phi float [ %2741, %2729 ], [ %800, %2506 ]
  %2746 = fsub fast float %82, %86
  %2747 = call float @dx.op.unary.f32(i32 6, float %2746)  ; FAbs(value)
  %2748 = fdiv fast float %2747, %2253
  %2749 = fsub fast float 1.000000e+00, %2748
  %2750 = call float @dx.op.unary.f32(i32 7, float %2749)  ; Saturate(value)
  %2751 = fcmp fast ugt float %2750, 0.000000e+00
  br i1 %2751, label %2752, label %2762

; <label>:2752                                    ; preds = %2742
  %2753 = fsub fast float %394, %798
  %2754 = fsub fast float %395, %799
  %2755 = fsub fast float %396, %800
  %2756 = fmul fast float %2750, %2753
  %2757 = fmul fast float %2750, %2754
  %2758 = fmul fast float %2750, %2755
  %2759 = fadd fast float %2756, %798
  %2760 = fadd fast float %2757, %799
  %2761 = fadd fast float %2758, %800
  br label %2762

; <label>:2762                                    ; preds = %2752, %2742
  %2763 = phi float [ %2759, %2752 ], [ %798, %2742 ]
  %2764 = phi float [ %2760, %2752 ], [ %799, %2742 ]
  %2765 = phi float [ %2761, %2752 ], [ %800, %2742 ]
  %2766 = call float @dx.op.binary.f32(i32 36, float %2507, float %2271)  ; FMin(a,b)
  %2767 = call float @dx.op.binary.f32(i32 36, float %2508, float %2272)  ; FMin(a,b)
  %2768 = call float @dx.op.binary.f32(i32 36, float %2509, float %2273)  ; FMin(a,b)
  %2769 = call float @dx.op.binary.f32(i32 36, float %2763, float %2743)  ; FMin(a,b)
  %2770 = call float @dx.op.binary.f32(i32 36, float %2764, float %2744)  ; FMin(a,b)
  %2771 = call float @dx.op.binary.f32(i32 36, float %2765, float %2745)  ; FMin(a,b)
  %2772 = call float @dx.op.binary.f32(i32 36, float %2769, float %2766)  ; FMin(a,b)
  %2773 = call float @dx.op.binary.f32(i32 36, float %2770, float %2767)  ; FMin(a,b)
  %2774 = call float @dx.op.binary.f32(i32 36, float %2771, float %2768)  ; FMin(a,b)
  %2775 = call float @dx.op.binary.f32(i32 36, float %798, float %2772)  ; FMin(a,b)
  %2776 = call float @dx.op.binary.f32(i32 36, float %799, float %2773)  ; FMin(a,b)
  %2777 = call float @dx.op.binary.f32(i32 36, float %800, float %2774)  ; FMin(a,b)
  %2778 = call float @dx.op.binary.f32(i32 35, float %2507, float %2271)  ; FMax(a,b)
  %2779 = call float @dx.op.binary.f32(i32 35, float %2508, float %2272)  ; FMax(a,b)
  %2780 = call float @dx.op.binary.f32(i32 35, float %2509, float %2273)  ; FMax(a,b)
  %2781 = call float @dx.op.binary.f32(i32 35, float %2763, float %2743)  ; FMax(a,b)
  %2782 = call float @dx.op.binary.f32(i32 35, float %2764, float %2744)  ; FMax(a,b)
  %2783 = call float @dx.op.binary.f32(i32 35, float %2765, float %2745)  ; FMax(a,b)
  %2784 = call float @dx.op.binary.f32(i32 35, float %2781, float %2778)  ; FMax(a,b)
  %2785 = call float @dx.op.binary.f32(i32 35, float %2782, float %2779)  ; FMax(a,b)
  %2786 = call float @dx.op.binary.f32(i32 35, float %2783, float %2780)  ; FMax(a,b)
  %2787 = call float @dx.op.binary.f32(i32 35, float %798, float %2784)  ; FMax(a,b)
  %2788 = call float @dx.op.binary.f32(i32 35, float %799, float %2785)  ; FMax(a,b)
  %2789 = call float @dx.op.binary.f32(i32 35, float %800, float %2786)  ; FMax(a,b)
  %2790 = fsub fast float %2787, %2775
  %2791 = fsub fast float %2788, %2776
  %2792 = fsub fast float %2789, %2777
  %2793 = call float @dx.op.unary.f32(i32 6, float %2790)  ; FAbs(value)
  %2794 = call float @dx.op.unary.f32(i32 6, float %2791)  ; FAbs(value)
  %2795 = call float @dx.op.unary.f32(i32 6, float %2792)  ; FAbs(value)
  %2796 = call float @dx.op.binary.f32(i32 35, float %2794, float %2795)  ; FMax(a,b)
  %2797 = call float @dx.op.binary.f32(i32 35, float %2793, float %2796)  ; FMax(a,b)
  %2798 = call float @dx.op.binary.f32(i32 35, float %2788, float %2789)  ; FMax(a,b)
  %2799 = call float @dx.op.binary.f32(i32 35, float %2787, float %2798)  ; FMax(a,b)
  %2800 = fmul fast float %2799, 1.250000e-01
  %2801 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %2800)  ; FMax(a,b)
  %2802 = fcmp fast ogt float %2797, %2801
  br i1 %2802, label %2803, label %2864

; <label>:2803                                    ; preds = %2762
  %2804 = fsub fast float %2763, %2743
  %2805 = fsub fast float %2764, %2744
  %2806 = fsub fast float %2765, %2745
  %2807 = call float @dx.op.unary.f32(i32 6, float %2804)  ; FAbs(value)
  %2808 = call float @dx.op.unary.f32(i32 6, float %2805)  ; FAbs(value)
  %2809 = call float @dx.op.unary.f32(i32 6, float %2806)  ; FAbs(value)
  %2810 = call float @dx.op.binary.f32(i32 35, float %2808, float %2809)  ; FMax(a,b)
  %2811 = call float @dx.op.binary.f32(i32 35, float %2807, float %2810)  ; FMax(a,b)
  %2812 = fsub fast float %2507, %2271
  %2813 = fsub fast float %2508, %2272
  %2814 = fsub fast float %2509, %2273
  %2815 = call float @dx.op.unary.f32(i32 6, float %2812)  ; FAbs(value)
  %2816 = call float @dx.op.unary.f32(i32 6, float %2813)  ; FAbs(value)
  %2817 = call float @dx.op.unary.f32(i32 6, float %2814)  ; FAbs(value)
  %2818 = call float @dx.op.binary.f32(i32 35, float %2816, float %2817)  ; FMax(a,b)
  %2819 = call float @dx.op.binary.f32(i32 35, float %2815, float %2818)  ; FMax(a,b)
  %2820 = fcmp fast olt float %2811, %2819
  %2821 = select i1 %2820, float %2763, float %2507
  %2822 = select i1 %2820, float %2764, float %2508
  %2823 = select i1 %2820, float %2765, float %2509
  %2824 = select i1 %2820, float %2743, float %2271
  %2825 = select i1 %2820, float %2744, float %2272
  %2826 = select i1 %2820, float %2745, float %2273
  %2827 = fsub fast float %798, %2824
  %2828 = fsub fast float %799, %2825
  %2829 = fsub fast float %800, %2826
  %2830 = fsub fast float %798, %2821
  %2831 = fsub fast float %799, %2822
  %2832 = fsub fast float %800, %2823
  %2833 = call float @dx.op.dot3.f32(i32 55, float %2830, float %2831, float %2832, float %2827, float %2828, float %2829)  ; Dot3(ax,ay,az,bx,by,bz)
  %2834 = fcmp fast ogt float %2833, 0.000000e+00
  br i1 %2834, label %2835, label %2846

; <label>:2835                                    ; preds = %2803
  %2836 = fsub fast float %2821, %2824
  %2837 = fsub fast float %2822, %2825
  %2838 = fsub fast float %2823, %2826
  %2839 = call float @dx.op.unary.f32(i32 6, float %2836)  ; FAbs(value)
  %2840 = call float @dx.op.unary.f32(i32 6, float %2837)  ; FAbs(value)
  %2841 = call float @dx.op.unary.f32(i32 6, float %2838)  ; FAbs(value)
  %2842 = call float @dx.op.binary.f32(i32 35, float %2840, float %2841)  ; FMax(a,b)
  %2843 = call float @dx.op.binary.f32(i32 35, float %2839, float %2842)  ; FMax(a,b)
  %2844 = fmul fast float %2797, 2.500000e-01
  %2845 = fcmp fast olt float %2843, %2844
  br label %2846

; <label>:2846                                    ; preds = %2835, %2803
  %2847 = phi i1 [ false, %2803 ], [ %2845, %2835 ]
  %2848 = select i1 %2847, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  %2849 = fadd fast float %2821, %2824
  %2850 = fadd fast float %2822, %2825
  %2851 = fadd fast float %2823, %2826
  %2852 = fmul fast float %2849, 5.000000e-01
  %2853 = fmul fast float %2850, 5.000000e-01
  %2854 = fmul fast float %2851, 5.000000e-01
  %2855 = fsub fast float %2852, %798
  %2856 = fsub fast float %2853, %799
  %2857 = fsub fast float %2854, %800
  %2858 = fmul fast float %2848, %2855
  %2859 = fmul fast float %2848, %2856
  %2860 = fmul fast float %2848, %2857
  %2861 = fadd fast float %2858, %798
  %2862 = fadd fast float %2859, %799
  %2863 = fadd fast float %2860, %800
  br label %2864

; <label>:2864                                    ; preds = %2846, %2762, %2245
  %2865 = phi float [ %798, %2245 ], [ %2861, %2846 ], [ %798, %2762 ]
  %2866 = phi float [ %799, %2245 ], [ %2862, %2846 ], [ %799, %2762 ]
  %2867 = phi float [ %800, %2245 ], [ %2863, %2846 ], [ %800, %2762 ]
  %2868 = fcmp fast ult float %194, 0.000000e+00
  br i1 %2868, label %8503, label %2869

; <label>:2869                                    ; preds = %2864
  %2870 = add i32 %55, 2
  %2871 = call i32 @dx.op.binary.i32(i32 37, i32 %2870, i32 0)  ; IMax(a,b)
  %2872 = call i32 @dx.op.binary.i32(i32 38, i32 %2871, i32 %59)  ; IMin(a,b)
  %2873 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2872, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2874 = extractvalue %dx.types.ResRet.f32 %2873, 0
  %2875 = fsub fast float 1.000000e+00, %88
  %2876 = fmul fast float %2875, 0x3FA99999A0000000
  %2877 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %2876)  ; FMax(a,b)
  %2878 = fsub fast float %2874, %88
  %2879 = call float @dx.op.unary.f32(i32 6, float %2878)  ; FAbs(value)
  %2880 = fdiv fast float %2879, %2877
  %2881 = fsub fast float 1.000000e+00, %2880
  %2882 = call float @dx.op.unary.f32(i32 7, float %2881)  ; Saturate(value)
  %2883 = fcmp fast ugt float %2882, 0.000000e+00
  br i1 %2883, label %2884, label %3105

; <label>:2884                                    ; preds = %2869
  %2885 = call i32 @dx.op.binary.i32(i32 37, i32 %2872, i32 0)  ; IMax(a,b)
  %2886 = call i32 @dx.op.binary.i32(i32 37, i32 %70, i32 0)  ; IMax(a,b)
  %2887 = call i32 @dx.op.binary.i32(i32 38, i32 %2885, i32 %59)  ; IMin(a,b)
  %2888 = call i32 @dx.op.binary.i32(i32 38, i32 %2886, i32 %60)  ; IMin(a,b)
  %2889 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2887, i32 %2888, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2890 = extractvalue %dx.types.ResRet.f32 %2889, 0
  %2891 = extractvalue %dx.types.ResRet.f32 %2889, 1
  %2892 = extractvalue %dx.types.ResRet.f32 %2889, 2
  %2893 = extractvalue %dx.types.ResRet.f32 %2889, 3
  %2894 = fcmp fast olt float %2893, 0.000000e+00
  br i1 %2894, label %2895, label %2929

; <label>:2895                                    ; preds = %2884
  %2896 = fcmp fast ogt float %2890, 0x3FA4B5DCC0000000
  %2897 = fcmp fast ogt float %2891, 0x3FA4B5DCC0000000
  %2898 = fcmp fast ogt float %2892, 0x3FA4B5DCC0000000
  %2899 = select i1 %2896, float 0.000000e+00, float 1.000000e+00
  %2900 = select i1 %2897, float 0.000000e+00, float 1.000000e+00
  %2901 = select i1 %2898, float 0.000000e+00, float 1.000000e+00
  %2902 = fmul fast float %2890, 0x3FB3D07220000000
  %2903 = fmul fast float %2891, 0x3FB3D07220000000
  %2904 = fmul fast float %2892, 0x3FB3D07220000000
  %2905 = fadd fast float %2890, 0x3FAC28F5C0000000
  %2906 = fadd fast float %2891, 0x3FAC28F5C0000000
  %2907 = fadd fast float %2892, 0x3FAC28F5C0000000
  %2908 = fmul fast float %2905, 0x3FEE54EDE0000000
  %2909 = fmul fast float %2906, 0x3FEE54EDE0000000
  %2910 = fmul fast float %2907, 0x3FEE54EDE0000000
  %2911 = call float @dx.op.unary.f32(i32 23, float %2908)  ; Log(value)
  %2912 = call float @dx.op.unary.f32(i32 23, float %2909)  ; Log(value)
  %2913 = call float @dx.op.unary.f32(i32 23, float %2910)  ; Log(value)
  %2914 = fmul fast float %2911, 0x4003333340000000
  %2915 = fmul fast float %2912, 0x4003333340000000
  %2916 = fmul fast float %2913, 0x4003333340000000
  %2917 = call float @dx.op.unary.f32(i32 21, float %2914)  ; Exp(value)
  %2918 = call float @dx.op.unary.f32(i32 21, float %2915)  ; Exp(value)
  %2919 = call float @dx.op.unary.f32(i32 21, float %2916)  ; Exp(value)
  %2920 = fsub fast float %2902, %2917
  %2921 = fsub fast float %2903, %2918
  %2922 = fsub fast float %2904, %2919
  %2923 = fmul fast float %2920, %2899
  %2924 = fmul fast float %2921, %2900
  %2925 = fmul fast float %2922, %2901
  %2926 = fadd fast float %2923, %2917
  %2927 = fadd fast float %2924, %2918
  %2928 = fadd fast float %2925, %2919
  br label %3092

; <label>:2929                                    ; preds = %2884
  %2930 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2887, i32 %2888, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2931 = extractvalue %dx.types.ResRet.f32 %2930, 0
  %2932 = fcmp fast ogt float %38, 5.000000e-01
  %2933 = fcmp fast olt float %2931, 1.000000e+00
  %2934 = and i1 %2932, %2933
  br i1 %2934, label %2935, label %3021

; <label>:2935                                    ; preds = %2929
  %2936 = sitofp i32 %2887 to float
  %2937 = sitofp i32 %2888 to float
  %2938 = fadd fast float %2936, 5.000000e-01
  %2939 = fadd fast float %2937, 5.000000e-01
  %2940 = fdiv fast float %2938, %45
  %2941 = fdiv fast float %2939, %46
  %2942 = fmul fast float %2940, 2.000000e+00
  %2943 = fmul fast float %2941, 2.000000e+00
  %2944 = fadd fast float %2942, -1.000000e+00
  %2945 = fsub fast float 1.000000e+00, %2943
  %2946 = fmul fast float %2944, %35
  %2947 = call float @dx.op.tertiary.f32(i32 46, float %2945, float %31, float %2946)  ; FMad(a,b,c)
  %2948 = call float @dx.op.tertiary.f32(i32 46, float %2931, float %27, float %2947)  ; FMad(a,b,c)
  %2949 = fadd fast float %2948, %23
  %2950 = call float @dx.op.unary.f32(i32 6, float %2949)  ; FAbs(value)
  %2951 = fcmp fast ogt float %2950, 0x3EB0C6F7A0000000
  br i1 %2951, label %2952, label %3021

; <label>:2952                                    ; preds = %2935
  %2953 = fmul fast float %2944, %34
  %2954 = call float @dx.op.tertiary.f32(i32 46, float %2945, float %30, float %2953)  ; FMad(a,b,c)
  %2955 = call float @dx.op.tertiary.f32(i32 46, float %2931, float %26, float %2954)  ; FMad(a,b,c)
  %2956 = fadd fast float %2955, %22
  %2957 = fmul fast float %2944, %33
  %2958 = call float @dx.op.tertiary.f32(i32 46, float %2945, float %29, float %2957)  ; FMad(a,b,c)
  %2959 = call float @dx.op.tertiary.f32(i32 46, float %2931, float %25, float %2958)  ; FMad(a,b,c)
  %2960 = fadd fast float %2959, %21
  %2961 = fmul fast float %2944, %32
  %2962 = call float @dx.op.tertiary.f32(i32 46, float %2945, float %28, float %2961)  ; FMad(a,b,c)
  %2963 = call float @dx.op.tertiary.f32(i32 46, float %2931, float %24, float %2962)  ; FMad(a,b,c)
  %2964 = fadd fast float %2963, %20
  %2965 = fdiv fast float %2964, %2949
  %2966 = fdiv fast float %2960, %2949
  %2967 = fdiv fast float %2956, %2949
  %2968 = fsub fast float %2965, %17
  %2969 = fsub fast float %2966, %18
  %2970 = fsub fast float %2967, %19
  %2971 = fmul fast float %2968, %2968
  %2972 = fmul fast float %2969, %2969
  %2973 = fadd fast float %2972, %2971
  %2974 = fmul fast float %2970, %2970
  %2975 = fadd fast float %2973, %2974
  %2976 = call float @dx.op.unary.f32(i32 24, float %2975)  ; Sqrt(value)
  %2977 = fsub fast float %2976, %9
  %2978 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2977)  ; FMax(a,b)
  %2979 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %2979, label %2980, label %3003

; <label>:2980                                    ; preds = %2952
  %2981 = call float @dx.op.unary.f32(i32 6, float %2969)  ; FAbs(value)
  %2982 = fmul fast float %2981, %11
  %2983 = fcmp fast olt float %2982, 0x3F50624DE0000000
  br i1 %2983, label %2984, label %2987

; <label>:2984                                    ; preds = %2980
  %2985 = fmul fast float %2982, 5.000000e-01
  %2986 = fsub fast float 1.000000e+00, %2985
  br label %2992

; <label>:2987                                    ; preds = %2980
  %2988 = fmul fast float %2982, 0xBFF7154760000000
  %2989 = call float @dx.op.unary.f32(i32 21, float %2988)  ; Exp(value)
  %2990 = fsub fast float 1.000000e+00, %2989
  %2991 = fdiv fast float %2990, %2982
  br label %2992

; <label>:2992                                    ; preds = %2987, %2984
  %2993 = phi float [ %2986, %2984 ], [ %2991, %2987 ]
  %2994 = call float @dx.op.binary.f32(i32 36, float %2966, float %18)  ; FMin(a,b)
  %2995 = fsub fast float %2994, %10
  %2996 = fmul fast float %11, %2995
  %2997 = fsub fast float -0.000000e+00, %2996
  %2998 = call float @dx.op.binary.f32(i32 35, float %2997, float -4.000000e+01)  ; FMax(a,b)
  %2999 = call float @dx.op.binary.f32(i32 36, float %2998, float 5.000000e+00)  ; FMin(a,b)
  %3000 = fmul fast float %2999, 0x3FF7154760000000
  %3001 = call float @dx.op.unary.f32(i32 21, float %3000)  ; Exp(value)
  %3002 = fmul fast float %3001, %2993
  br label %3003

; <label>:3003                                    ; preds = %2992, %2952
  %3004 = phi float [ %3002, %2992 ], [ 1.000000e+00, %2952 ]
  %3005 = fmul fast float %2978, %16
  %3006 = fmul fast float %3005, %3004
  %3007 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3006)  ; FMin(a,b)
  %3008 = fmul fast float %3007, 0xBFF7154760000000
  %3009 = call float @dx.op.unary.f32(i32 21, float %3008)  ; Exp(value)
  %3010 = fsub fast float 1.000000e+00, %3009
  %3011 = call float @dx.op.binary.f32(i32 36, float %12, float %3010)  ; FMin(a,b)
  %3012 = fsub fast float %13, %2890
  %3013 = fsub fast float %14, %2891
  %3014 = fsub fast float %15, %2892
  %3015 = fmul fast float %3011, %3012
  %3016 = fmul fast float %3011, %3013
  %3017 = fmul fast float %3011, %3014
  %3018 = fadd fast float %3015, %2890
  %3019 = fadd fast float %3016, %2891
  %3020 = fadd fast float %3017, %2892
  br label %3021

; <label>:3021                                    ; preds = %3003, %2935, %2929
  %3022 = phi float [ %3018, %3003 ], [ %2890, %2935 ], [ %2890, %2929 ]
  %3023 = phi float [ %3019, %3003 ], [ %2891, %2935 ], [ %2891, %2929 ]
  %3024 = phi float [ %3020, %3003 ], [ %2892, %2935 ], [ %2892, %2929 ]
  %3025 = fadd fast float %5, 1.000000e+00
  %3026 = fadd fast float %6, 1.000000e+00
  %3027 = fsub fast float 1.000000e+00, %5
  %3028 = fmul fast float %36, %3025
  %3029 = fmul fast float %36, %3026
  %3030 = fmul fast float %36, %3027
  %3031 = fmul fast float %3028, %3022
  %3032 = fmul fast float %3029, %3023
  %3033 = fmul fast float %3030, %3024
  %3034 = fcmp fast ult float %37, 5.000000e-01
  br i1 %3034, label %3060, label %3035

; <label>:3035                                    ; preds = %3021
  %3036 = fmul fast float %3031, 0x4004147AE0000000
  %3037 = fmul fast float %3032, 0x4004147AE0000000
  %3038 = fmul fast float %3033, 0x4004147AE0000000
  %3039 = fadd fast float %3036, 0x3F9EB851E0000000
  %3040 = fadd fast float %3037, 0x3F9EB851E0000000
  %3041 = fadd fast float %3038, 0x3F9EB851E0000000
  %3042 = fmul fast float %3039, %3031
  %3043 = fmul fast float %3040, %3032
  %3044 = fmul fast float %3041, %3033
  %3045 = fmul fast float %3031, 0x400370A3E0000000
  %3046 = fmul fast float %3032, 0x400370A3E0000000
  %3047 = fmul fast float %3033, 0x400370A3E0000000
  %3048 = fadd fast float %3045, 0x3FE2E147A0000000
  %3049 = fadd fast float %3046, 0x3FE2E147A0000000
  %3050 = fadd fast float %3047, 0x3FE2E147A0000000
  %3051 = fmul fast float %3048, %3031
  %3052 = fmul fast float %3049, %3032
  %3053 = fmul fast float %3050, %3033
  %3054 = fadd fast float %3051, 0x3FC1EB8520000000
  %3055 = fadd fast float %3052, 0x3FC1EB8520000000
  %3056 = fadd fast float %3053, 0x3FC1EB8520000000
  %3057 = fdiv fast float %3042, %3054
  %3058 = fdiv fast float %3043, %3055
  %3059 = fdiv fast float %3044, %3056
  br label %3060

; <label>:3060                                    ; preds = %3035, %3021
  %3061 = phi float [ %3057, %3035 ], [ %3031, %3021 ]
  %3062 = phi float [ %3058, %3035 ], [ %3032, %3021 ]
  %3063 = phi float [ %3059, %3035 ], [ %3033, %3021 ]
  %3064 = call float @dx.op.unary.f32(i32 7, float %3061)  ; Saturate(value)
  %3065 = call float @dx.op.unary.f32(i32 7, float %3062)  ; Saturate(value)
  %3066 = call float @dx.op.unary.f32(i32 7, float %3063)  ; Saturate(value)
  %3067 = call float @dx.op.dot3.f32(i32 55, float %3064, float %3065, float %3066, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3068 = fsub fast float %3064, %3067
  %3069 = fsub fast float %3065, %3067
  %3070 = fsub fast float %3066, %3067
  %3071 = fmul fast float %3068, %8
  %3072 = fmul fast float %3069, %8
  %3073 = fmul fast float %3070, %8
  %3074 = fadd fast float %3071, %3067
  %3075 = fadd fast float %3072, %3067
  %3076 = fadd fast float %3073, %3067
  %3077 = call float @dx.op.unary.f32(i32 7, float %3074)  ; Saturate(value)
  %3078 = call float @dx.op.unary.f32(i32 7, float %3075)  ; Saturate(value)
  %3079 = call float @dx.op.unary.f32(i32 7, float %3076)  ; Saturate(value)
  %3080 = fadd fast float %3077, 0xBFC70A3D80000000
  %3081 = fadd fast float %3078, 0xBFC70A3D80000000
  %3082 = fadd fast float %3079, 0xBFC70A3D80000000
  %3083 = fmul fast float %3080, %7
  %3084 = fmul fast float %3081, %7
  %3085 = fmul fast float %3082, %7
  %3086 = fadd fast float %3083, 0x3FC70A3D80000000
  %3087 = fadd fast float %3084, 0x3FC70A3D80000000
  %3088 = fadd fast float %3085, 0x3FC70A3D80000000
  %3089 = call float @dx.op.unary.f32(i32 7, float %3086)  ; Saturate(value)
  %3090 = call float @dx.op.unary.f32(i32 7, float %3087)  ; Saturate(value)
  %3091 = call float @dx.op.unary.f32(i32 7, float %3088)  ; Saturate(value)
  br label %3092

; <label>:3092                                    ; preds = %3060, %2895
  %3093 = phi float [ %2926, %2895 ], [ %3089, %3060 ]
  %3094 = phi float [ %2927, %2895 ], [ %3090, %3060 ]
  %3095 = phi float [ %2928, %2895 ], [ %3091, %3060 ]
  %3096 = fsub fast float %3093, %1000
  %3097 = fsub fast float %3094, %1001
  %3098 = fsub fast float %3095, %1002
  %3099 = fmul fast float %3096, %2882
  %3100 = fmul fast float %3097, %2882
  %3101 = fmul fast float %3098, %2882
  %3102 = fadd fast float %3099, %1000
  %3103 = fadd fast float %3100, %1001
  %3104 = fadd fast float %3101, %1002
  br label %3105

; <label>:3105                                    ; preds = %3092, %2869
  %3106 = phi float [ %3102, %3092 ], [ %1000, %2869 ]
  %3107 = phi float [ %3103, %3092 ], [ %1001, %2869 ]
  %3108 = phi float [ %3104, %3092 ], [ %1002, %2869 ]
  %3109 = fsub fast float %86, %88
  %3110 = call float @dx.op.unary.f32(i32 6, float %3109)  ; FAbs(value)
  %3111 = fdiv fast float %3110, %2877
  %3112 = fsub fast float 1.000000e+00, %3111
  %3113 = call float @dx.op.unary.f32(i32 7, float %3112)  ; Saturate(value)
  %3114 = fcmp fast ugt float %3113, 0.000000e+00
  br i1 %3114, label %3115, label %3125

; <label>:3115                                    ; preds = %3105
  %3116 = fsub fast float %798, %1000
  %3117 = fsub fast float %799, %1001
  %3118 = fsub fast float %800, %1002
  %3119 = fmul fast float %3113, %3116
  %3120 = fmul fast float %3113, %3117
  %3121 = fmul fast float %3113, %3118
  %3122 = fadd fast float %3119, %1000
  %3123 = fadd fast float %3120, %1001
  %3124 = fadd fast float %3121, %1002
  br label %3125

; <label>:3125                                    ; preds = %3115, %3105
  %3126 = phi float [ %3122, %3115 ], [ %1000, %3105 ]
  %3127 = phi float [ %3123, %3115 ], [ %1001, %3105 ]
  %3128 = phi float [ %3124, %3115 ], [ %1002, %3105 ]
  %3129 = add i32 %56, 2
  %3130 = call i32 @dx.op.binary.i32(i32 37, i32 %3129, i32 0)  ; IMax(a,b)
  %3131 = call i32 @dx.op.binary.i32(i32 38, i32 %3130, i32 %60)  ; IMin(a,b)
  %3132 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %67, i32 %3131, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3133 = extractvalue %dx.types.ResRet.f32 %3132, 0
  %3134 = fsub fast float %3133, %88
  %3135 = call float @dx.op.unary.f32(i32 6, float %3134)  ; FAbs(value)
  %3136 = fdiv fast float %3135, %2877
  %3137 = fsub fast float 1.000000e+00, %3136
  %3138 = call float @dx.op.unary.f32(i32 7, float %3137)  ; Saturate(value)
  %3139 = fcmp fast ugt float %3138, 0.000000e+00
  br i1 %3139, label %3140, label %3361

; <label>:3140                                    ; preds = %3125
  %3141 = call i32 @dx.op.binary.i32(i32 37, i32 %67, i32 0)  ; IMax(a,b)
  %3142 = call i32 @dx.op.binary.i32(i32 37, i32 %3131, i32 0)  ; IMax(a,b)
  %3143 = call i32 @dx.op.binary.i32(i32 38, i32 %3141, i32 %59)  ; IMin(a,b)
  %3144 = call i32 @dx.op.binary.i32(i32 38, i32 %3142, i32 %60)  ; IMin(a,b)
  %3145 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3143, i32 %3144, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3146 = extractvalue %dx.types.ResRet.f32 %3145, 0
  %3147 = extractvalue %dx.types.ResRet.f32 %3145, 1
  %3148 = extractvalue %dx.types.ResRet.f32 %3145, 2
  %3149 = extractvalue %dx.types.ResRet.f32 %3145, 3
  %3150 = fcmp fast olt float %3149, 0.000000e+00
  br i1 %3150, label %3151, label %3185

; <label>:3151                                    ; preds = %3140
  %3152 = fcmp fast ogt float %3146, 0x3FA4B5DCC0000000
  %3153 = fcmp fast ogt float %3147, 0x3FA4B5DCC0000000
  %3154 = fcmp fast ogt float %3148, 0x3FA4B5DCC0000000
  %3155 = select i1 %3152, float 0.000000e+00, float 1.000000e+00
  %3156 = select i1 %3153, float 0.000000e+00, float 1.000000e+00
  %3157 = select i1 %3154, float 0.000000e+00, float 1.000000e+00
  %3158 = fmul fast float %3146, 0x3FB3D07220000000
  %3159 = fmul fast float %3147, 0x3FB3D07220000000
  %3160 = fmul fast float %3148, 0x3FB3D07220000000
  %3161 = fadd fast float %3146, 0x3FAC28F5C0000000
  %3162 = fadd fast float %3147, 0x3FAC28F5C0000000
  %3163 = fadd fast float %3148, 0x3FAC28F5C0000000
  %3164 = fmul fast float %3161, 0x3FEE54EDE0000000
  %3165 = fmul fast float %3162, 0x3FEE54EDE0000000
  %3166 = fmul fast float %3163, 0x3FEE54EDE0000000
  %3167 = call float @dx.op.unary.f32(i32 23, float %3164)  ; Log(value)
  %3168 = call float @dx.op.unary.f32(i32 23, float %3165)  ; Log(value)
  %3169 = call float @dx.op.unary.f32(i32 23, float %3166)  ; Log(value)
  %3170 = fmul fast float %3167, 0x4003333340000000
  %3171 = fmul fast float %3168, 0x4003333340000000
  %3172 = fmul fast float %3169, 0x4003333340000000
  %3173 = call float @dx.op.unary.f32(i32 21, float %3170)  ; Exp(value)
  %3174 = call float @dx.op.unary.f32(i32 21, float %3171)  ; Exp(value)
  %3175 = call float @dx.op.unary.f32(i32 21, float %3172)  ; Exp(value)
  %3176 = fsub fast float %3158, %3173
  %3177 = fsub fast float %3159, %3174
  %3178 = fsub fast float %3160, %3175
  %3179 = fmul fast float %3176, %3155
  %3180 = fmul fast float %3177, %3156
  %3181 = fmul fast float %3178, %3157
  %3182 = fadd fast float %3179, %3173
  %3183 = fadd fast float %3180, %3174
  %3184 = fadd fast float %3181, %3175
  br label %3348

; <label>:3185                                    ; preds = %3140
  %3186 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3143, i32 %3144, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3187 = extractvalue %dx.types.ResRet.f32 %3186, 0
  %3188 = fcmp fast ogt float %38, 5.000000e-01
  %3189 = fcmp fast olt float %3187, 1.000000e+00
  %3190 = and i1 %3188, %3189
  br i1 %3190, label %3191, label %3277

; <label>:3191                                    ; preds = %3185
  %3192 = sitofp i32 %3143 to float
  %3193 = sitofp i32 %3144 to float
  %3194 = fadd fast float %3192, 5.000000e-01
  %3195 = fadd fast float %3193, 5.000000e-01
  %3196 = fdiv fast float %3194, %45
  %3197 = fdiv fast float %3195, %46
  %3198 = fmul fast float %3196, 2.000000e+00
  %3199 = fmul fast float %3197, 2.000000e+00
  %3200 = fadd fast float %3198, -1.000000e+00
  %3201 = fsub fast float 1.000000e+00, %3199
  %3202 = fmul fast float %3200, %35
  %3203 = call float @dx.op.tertiary.f32(i32 46, float %3201, float %31, float %3202)  ; FMad(a,b,c)
  %3204 = call float @dx.op.tertiary.f32(i32 46, float %3187, float %27, float %3203)  ; FMad(a,b,c)
  %3205 = fadd fast float %3204, %23
  %3206 = call float @dx.op.unary.f32(i32 6, float %3205)  ; FAbs(value)
  %3207 = fcmp fast ogt float %3206, 0x3EB0C6F7A0000000
  br i1 %3207, label %3208, label %3277

; <label>:3208                                    ; preds = %3191
  %3209 = fmul fast float %3200, %34
  %3210 = call float @dx.op.tertiary.f32(i32 46, float %3201, float %30, float %3209)  ; FMad(a,b,c)
  %3211 = call float @dx.op.tertiary.f32(i32 46, float %3187, float %26, float %3210)  ; FMad(a,b,c)
  %3212 = fadd fast float %3211, %22
  %3213 = fmul fast float %3200, %33
  %3214 = call float @dx.op.tertiary.f32(i32 46, float %3201, float %29, float %3213)  ; FMad(a,b,c)
  %3215 = call float @dx.op.tertiary.f32(i32 46, float %3187, float %25, float %3214)  ; FMad(a,b,c)
  %3216 = fadd fast float %3215, %21
  %3217 = fmul fast float %3200, %32
  %3218 = call float @dx.op.tertiary.f32(i32 46, float %3201, float %28, float %3217)  ; FMad(a,b,c)
  %3219 = call float @dx.op.tertiary.f32(i32 46, float %3187, float %24, float %3218)  ; FMad(a,b,c)
  %3220 = fadd fast float %3219, %20
  %3221 = fdiv fast float %3220, %3205
  %3222 = fdiv fast float %3216, %3205
  %3223 = fdiv fast float %3212, %3205
  %3224 = fsub fast float %3221, %17
  %3225 = fsub fast float %3222, %18
  %3226 = fsub fast float %3223, %19
  %3227 = fmul fast float %3224, %3224
  %3228 = fmul fast float %3225, %3225
  %3229 = fadd fast float %3228, %3227
  %3230 = fmul fast float %3226, %3226
  %3231 = fadd fast float %3229, %3230
  %3232 = call float @dx.op.unary.f32(i32 24, float %3231)  ; Sqrt(value)
  %3233 = fsub fast float %3232, %9
  %3234 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3233)  ; FMax(a,b)
  %3235 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %3235, label %3236, label %3259

; <label>:3236                                    ; preds = %3208
  %3237 = call float @dx.op.unary.f32(i32 6, float %3225)  ; FAbs(value)
  %3238 = fmul fast float %3237, %11
  %3239 = fcmp fast olt float %3238, 0x3F50624DE0000000
  br i1 %3239, label %3240, label %3243

; <label>:3240                                    ; preds = %3236
  %3241 = fmul fast float %3238, 5.000000e-01
  %3242 = fsub fast float 1.000000e+00, %3241
  br label %3248

; <label>:3243                                    ; preds = %3236
  %3244 = fmul fast float %3238, 0xBFF7154760000000
  %3245 = call float @dx.op.unary.f32(i32 21, float %3244)  ; Exp(value)
  %3246 = fsub fast float 1.000000e+00, %3245
  %3247 = fdiv fast float %3246, %3238
  br label %3248

; <label>:3248                                    ; preds = %3243, %3240
  %3249 = phi float [ %3242, %3240 ], [ %3247, %3243 ]
  %3250 = call float @dx.op.binary.f32(i32 36, float %3222, float %18)  ; FMin(a,b)
  %3251 = fsub fast float %3250, %10
  %3252 = fmul fast float %11, %3251
  %3253 = fsub fast float -0.000000e+00, %3252
  %3254 = call float @dx.op.binary.f32(i32 35, float %3253, float -4.000000e+01)  ; FMax(a,b)
  %3255 = call float @dx.op.binary.f32(i32 36, float %3254, float 5.000000e+00)  ; FMin(a,b)
  %3256 = fmul fast float %3255, 0x3FF7154760000000
  %3257 = call float @dx.op.unary.f32(i32 21, float %3256)  ; Exp(value)
  %3258 = fmul fast float %3257, %3249
  br label %3259

; <label>:3259                                    ; preds = %3248, %3208
  %3260 = phi float [ %3258, %3248 ], [ 1.000000e+00, %3208 ]
  %3261 = fmul fast float %3234, %16
  %3262 = fmul fast float %3261, %3260
  %3263 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3262)  ; FMin(a,b)
  %3264 = fmul fast float %3263, 0xBFF7154760000000
  %3265 = call float @dx.op.unary.f32(i32 21, float %3264)  ; Exp(value)
  %3266 = fsub fast float 1.000000e+00, %3265
  %3267 = call float @dx.op.binary.f32(i32 36, float %12, float %3266)  ; FMin(a,b)
  %3268 = fsub fast float %13, %3146
  %3269 = fsub fast float %14, %3147
  %3270 = fsub fast float %15, %3148
  %3271 = fmul fast float %3267, %3268
  %3272 = fmul fast float %3267, %3269
  %3273 = fmul fast float %3267, %3270
  %3274 = fadd fast float %3271, %3146
  %3275 = fadd fast float %3272, %3147
  %3276 = fadd fast float %3273, %3148
  br label %3277

; <label>:3277                                    ; preds = %3259, %3191, %3185
  %3278 = phi float [ %3274, %3259 ], [ %3146, %3191 ], [ %3146, %3185 ]
  %3279 = phi float [ %3275, %3259 ], [ %3147, %3191 ], [ %3147, %3185 ]
  %3280 = phi float [ %3276, %3259 ], [ %3148, %3191 ], [ %3148, %3185 ]
  %3281 = fadd fast float %5, 1.000000e+00
  %3282 = fadd fast float %6, 1.000000e+00
  %3283 = fsub fast float 1.000000e+00, %5
  %3284 = fmul fast float %36, %3281
  %3285 = fmul fast float %36, %3282
  %3286 = fmul fast float %36, %3283
  %3287 = fmul fast float %3284, %3278
  %3288 = fmul fast float %3285, %3279
  %3289 = fmul fast float %3286, %3280
  %3290 = fcmp fast ult float %37, 5.000000e-01
  br i1 %3290, label %3316, label %3291

; <label>:3291                                    ; preds = %3277
  %3292 = fmul fast float %3287, 0x4004147AE0000000
  %3293 = fmul fast float %3288, 0x4004147AE0000000
  %3294 = fmul fast float %3289, 0x4004147AE0000000
  %3295 = fadd fast float %3292, 0x3F9EB851E0000000
  %3296 = fadd fast float %3293, 0x3F9EB851E0000000
  %3297 = fadd fast float %3294, 0x3F9EB851E0000000
  %3298 = fmul fast float %3295, %3287
  %3299 = fmul fast float %3296, %3288
  %3300 = fmul fast float %3297, %3289
  %3301 = fmul fast float %3287, 0x400370A3E0000000
  %3302 = fmul fast float %3288, 0x400370A3E0000000
  %3303 = fmul fast float %3289, 0x400370A3E0000000
  %3304 = fadd fast float %3301, 0x3FE2E147A0000000
  %3305 = fadd fast float %3302, 0x3FE2E147A0000000
  %3306 = fadd fast float %3303, 0x3FE2E147A0000000
  %3307 = fmul fast float %3304, %3287
  %3308 = fmul fast float %3305, %3288
  %3309 = fmul fast float %3306, %3289
  %3310 = fadd fast float %3307, 0x3FC1EB8520000000
  %3311 = fadd fast float %3308, 0x3FC1EB8520000000
  %3312 = fadd fast float %3309, 0x3FC1EB8520000000
  %3313 = fdiv fast float %3298, %3310
  %3314 = fdiv fast float %3299, %3311
  %3315 = fdiv fast float %3300, %3312
  br label %3316

; <label>:3316                                    ; preds = %3291, %3277
  %3317 = phi float [ %3313, %3291 ], [ %3287, %3277 ]
  %3318 = phi float [ %3314, %3291 ], [ %3288, %3277 ]
  %3319 = phi float [ %3315, %3291 ], [ %3289, %3277 ]
  %3320 = call float @dx.op.unary.f32(i32 7, float %3317)  ; Saturate(value)
  %3321 = call float @dx.op.unary.f32(i32 7, float %3318)  ; Saturate(value)
  %3322 = call float @dx.op.unary.f32(i32 7, float %3319)  ; Saturate(value)
  %3323 = call float @dx.op.dot3.f32(i32 55, float %3320, float %3321, float %3322, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3324 = fsub fast float %3320, %3323
  %3325 = fsub fast float %3321, %3323
  %3326 = fsub fast float %3322, %3323
  %3327 = fmul fast float %3324, %8
  %3328 = fmul fast float %3325, %8
  %3329 = fmul fast float %3326, %8
  %3330 = fadd fast float %3327, %3323
  %3331 = fadd fast float %3328, %3323
  %3332 = fadd fast float %3329, %3323
  %3333 = call float @dx.op.unary.f32(i32 7, float %3330)  ; Saturate(value)
  %3334 = call float @dx.op.unary.f32(i32 7, float %3331)  ; Saturate(value)
  %3335 = call float @dx.op.unary.f32(i32 7, float %3332)  ; Saturate(value)
  %3336 = fadd fast float %3333, 0xBFC70A3D80000000
  %3337 = fadd fast float %3334, 0xBFC70A3D80000000
  %3338 = fadd fast float %3335, 0xBFC70A3D80000000
  %3339 = fmul fast float %3336, %7
  %3340 = fmul fast float %3337, %7
  %3341 = fmul fast float %3338, %7
  %3342 = fadd fast float %3339, 0x3FC70A3D80000000
  %3343 = fadd fast float %3340, 0x3FC70A3D80000000
  %3344 = fadd fast float %3341, 0x3FC70A3D80000000
  %3345 = call float @dx.op.unary.f32(i32 7, float %3342)  ; Saturate(value)
  %3346 = call float @dx.op.unary.f32(i32 7, float %3343)  ; Saturate(value)
  %3347 = call float @dx.op.unary.f32(i32 7, float %3344)  ; Saturate(value)
  br label %3348

; <label>:3348                                    ; preds = %3316, %3151
  %3349 = phi float [ %3182, %3151 ], [ %3345, %3316 ]
  %3350 = phi float [ %3183, %3151 ], [ %3346, %3316 ]
  %3351 = phi float [ %3184, %3151 ], [ %3347, %3316 ]
  %3352 = fsub fast float %3349, %1000
  %3353 = fsub fast float %3350, %1001
  %3354 = fsub fast float %3351, %1002
  %3355 = fmul fast float %3352, %3138
  %3356 = fmul fast float %3353, %3138
  %3357 = fmul fast float %3354, %3138
  %3358 = fadd fast float %3355, %1000
  %3359 = fadd fast float %3356, %1001
  %3360 = fadd fast float %3357, %1002
  br label %3361

; <label>:3361                                    ; preds = %3348, %3125
  %3362 = phi float [ %3358, %3348 ], [ %1000, %3125 ]
  %3363 = phi float [ %3359, %3348 ], [ %1001, %3125 ]
  %3364 = phi float [ %3360, %3348 ], [ %1002, %3125 ]
  %3365 = fsub fast float %84, %88
  %3366 = call float @dx.op.unary.f32(i32 6, float %3365)  ; FAbs(value)
  %3367 = fdiv fast float %3366, %2877
  %3368 = fsub fast float 1.000000e+00, %3367
  %3369 = call float @dx.op.unary.f32(i32 7, float %3368)  ; Saturate(value)
  %3370 = fcmp fast ugt float %3369, 0.000000e+00
  br i1 %3370, label %3371, label %3381

; <label>:3371                                    ; preds = %3361
  %3372 = fsub fast float %596, %1000
  %3373 = fsub fast float %597, %1001
  %3374 = fsub fast float %598, %1002
  %3375 = fmul fast float %3369, %3372
  %3376 = fmul fast float %3369, %3373
  %3377 = fmul fast float %3369, %3374
  %3378 = fadd fast float %3375, %1000
  %3379 = fadd fast float %3376, %1001
  %3380 = fadd fast float %3377, %1002
  br label %3381

; <label>:3381                                    ; preds = %3371, %3361
  %3382 = phi float [ %3378, %3371 ], [ %1000, %3361 ]
  %3383 = phi float [ %3379, %3371 ], [ %1001, %3361 ]
  %3384 = phi float [ %3380, %3371 ], [ %1002, %3361 ]
  %3385 = call float @dx.op.binary.f32(i32 36, float %3126, float %3106)  ; FMin(a,b)
  %3386 = call float @dx.op.binary.f32(i32 36, float %3127, float %3107)  ; FMin(a,b)
  %3387 = call float @dx.op.binary.f32(i32 36, float %3128, float %3108)  ; FMin(a,b)
  %3388 = call float @dx.op.binary.f32(i32 36, float %3382, float %3362)  ; FMin(a,b)
  %3389 = call float @dx.op.binary.f32(i32 36, float %3383, float %3363)  ; FMin(a,b)
  %3390 = call float @dx.op.binary.f32(i32 36, float %3384, float %3364)  ; FMin(a,b)
  %3391 = call float @dx.op.binary.f32(i32 36, float %3388, float %3385)  ; FMin(a,b)
  %3392 = call float @dx.op.binary.f32(i32 36, float %3389, float %3386)  ; FMin(a,b)
  %3393 = call float @dx.op.binary.f32(i32 36, float %3390, float %3387)  ; FMin(a,b)
  %3394 = call float @dx.op.binary.f32(i32 36, float %1000, float %3391)  ; FMin(a,b)
  %3395 = call float @dx.op.binary.f32(i32 36, float %1001, float %3392)  ; FMin(a,b)
  %3396 = call float @dx.op.binary.f32(i32 36, float %1002, float %3393)  ; FMin(a,b)
  %3397 = call float @dx.op.binary.f32(i32 35, float %3126, float %3106)  ; FMax(a,b)
  %3398 = call float @dx.op.binary.f32(i32 35, float %3127, float %3107)  ; FMax(a,b)
  %3399 = call float @dx.op.binary.f32(i32 35, float %3128, float %3108)  ; FMax(a,b)
  %3400 = call float @dx.op.binary.f32(i32 35, float %3382, float %3362)  ; FMax(a,b)
  %3401 = call float @dx.op.binary.f32(i32 35, float %3383, float %3363)  ; FMax(a,b)
  %3402 = call float @dx.op.binary.f32(i32 35, float %3384, float %3364)  ; FMax(a,b)
  %3403 = call float @dx.op.binary.f32(i32 35, float %3400, float %3397)  ; FMax(a,b)
  %3404 = call float @dx.op.binary.f32(i32 35, float %3401, float %3398)  ; FMax(a,b)
  %3405 = call float @dx.op.binary.f32(i32 35, float %3402, float %3399)  ; FMax(a,b)
  %3406 = call float @dx.op.binary.f32(i32 35, float %1000, float %3403)  ; FMax(a,b)
  %3407 = call float @dx.op.binary.f32(i32 35, float %1001, float %3404)  ; FMax(a,b)
  %3408 = call float @dx.op.binary.f32(i32 35, float %1002, float %3405)  ; FMax(a,b)
  %3409 = fsub fast float %3406, %3394
  %3410 = fsub fast float %3407, %3395
  %3411 = fsub fast float %3408, %3396
  %3412 = call float @dx.op.unary.f32(i32 6, float %3409)  ; FAbs(value)
  %3413 = call float @dx.op.unary.f32(i32 6, float %3410)  ; FAbs(value)
  %3414 = call float @dx.op.unary.f32(i32 6, float %3411)  ; FAbs(value)
  %3415 = call float @dx.op.binary.f32(i32 35, float %3413, float %3414)  ; FMax(a,b)
  %3416 = call float @dx.op.binary.f32(i32 35, float %3412, float %3415)  ; FMax(a,b)
  %3417 = call float @dx.op.binary.f32(i32 35, float %3407, float %3408)  ; FMax(a,b)
  %3418 = call float @dx.op.binary.f32(i32 35, float %3406, float %3417)  ; FMax(a,b)
  %3419 = fmul fast float %3418, 1.250000e-01
  %3420 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %3419)  ; FMax(a,b)
  %3421 = fcmp fast ogt float %3416, %3420
  br i1 %3421, label %3422, label %8503

; <label>:3422                                    ; preds = %3381
  %3423 = fsub fast float %3382, %3362
  %3424 = fsub fast float %3383, %3363
  %3425 = fsub fast float %3384, %3364
  %3426 = call float @dx.op.unary.f32(i32 6, float %3423)  ; FAbs(value)
  %3427 = call float @dx.op.unary.f32(i32 6, float %3424)  ; FAbs(value)
  %3428 = call float @dx.op.unary.f32(i32 6, float %3425)  ; FAbs(value)
  %3429 = call float @dx.op.binary.f32(i32 35, float %3427, float %3428)  ; FMax(a,b)
  %3430 = call float @dx.op.binary.f32(i32 35, float %3426, float %3429)  ; FMax(a,b)
  %3431 = fsub fast float %3126, %3106
  %3432 = fsub fast float %3127, %3107
  %3433 = fsub fast float %3128, %3108
  %3434 = call float @dx.op.unary.f32(i32 6, float %3431)  ; FAbs(value)
  %3435 = call float @dx.op.unary.f32(i32 6, float %3432)  ; FAbs(value)
  %3436 = call float @dx.op.unary.f32(i32 6, float %3433)  ; FAbs(value)
  %3437 = call float @dx.op.binary.f32(i32 35, float %3435, float %3436)  ; FMax(a,b)
  %3438 = call float @dx.op.binary.f32(i32 35, float %3434, float %3437)  ; FMax(a,b)
  %3439 = fcmp fast olt float %3430, %3438
  %3440 = select i1 %3439, float %3382, float %3126
  %3441 = select i1 %3439, float %3383, float %3127
  %3442 = select i1 %3439, float %3384, float %3128
  %3443 = select i1 %3439, float %3362, float %3106
  %3444 = select i1 %3439, float %3363, float %3107
  %3445 = select i1 %3439, float %3364, float %3108
  %3446 = fsub fast float %1000, %3443
  %3447 = fsub fast float %1001, %3444
  %3448 = fsub fast float %1002, %3445
  %3449 = fsub fast float %1000, %3440
  %3450 = fsub fast float %1001, %3441
  %3451 = fsub fast float %1002, %3442
  %3452 = call float @dx.op.dot3.f32(i32 55, float %3449, float %3450, float %3451, float %3446, float %3447, float %3448)  ; Dot3(ax,ay,az,bx,by,bz)
  %3453 = fcmp fast ogt float %3452, 0.000000e+00
  br i1 %3453, label %3454, label %3466

; <label>:3454                                    ; preds = %3422
  %3455 = fsub fast float %3440, %3443
  %3456 = fsub fast float %3441, %3444
  %3457 = fsub fast float %3442, %3445
  %3458 = call float @dx.op.unary.f32(i32 6, float %3455)  ; FAbs(value)
  %3459 = call float @dx.op.unary.f32(i32 6, float %3456)  ; FAbs(value)
  %3460 = call float @dx.op.unary.f32(i32 6, float %3457)  ; FAbs(value)
  %3461 = call float @dx.op.binary.f32(i32 35, float %3459, float %3460)  ; FMax(a,b)
  %3462 = call float @dx.op.binary.f32(i32 35, float %3458, float %3461)  ; FMax(a,b)
  %3463 = fmul fast float %3416, 2.500000e-01
  %3464 = fcmp fast olt float %3462, %3463
  %3465 = select i1 %3464, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  br label %3466

; <label>:3466                                    ; preds = %3454, %3422
  %3467 = phi float [ 0x3FC99999A0000000, %3422 ], [ %3465, %3454 ]
  %3468 = fadd fast float %3440, %3443
  %3469 = fadd fast float %3441, %3444
  %3470 = fadd fast float %3442, %3445
  %3471 = fmul fast float %3468, 5.000000e-01
  %3472 = fmul fast float %3469, 5.000000e-01
  %3473 = fmul fast float %3470, 5.000000e-01
  %3474 = fsub fast float %3471, %1000
  %3475 = fsub fast float %3472, %1001
  %3476 = fsub fast float %3473, %1002
  %3477 = fmul fast float %3467, %3474
  %3478 = fmul fast float %3467, %3475
  %3479 = fmul fast float %3467, %3476
  %3480 = fadd fast float %3477, %1000
  %3481 = fadd fast float %3478, %1001
  %3482 = fadd fast float %3479, %1002
  br label %8503

; <label>:3483                                    ; preds = %172
  %3484 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3485 = extractvalue %dx.types.ResRet.f32 %3484, 0
  %3486 = extractvalue %dx.types.ResRet.f32 %3484, 1
  %3487 = extractvalue %dx.types.ResRet.f32 %3484, 2
  %3488 = extractvalue %dx.types.ResRet.f32 %3484, 3
  %3489 = fcmp fast olt float %3488, 0.000000e+00
  br i1 %3489, label %3490, label %3525

; <label>:3490                                    ; preds = %3483
  %3491 = fcmp fast ogt float %3485, 0x3FA4B5DCC0000000
  %3492 = fcmp fast ogt float %3486, 0x3FA4B5DCC0000000
  %3493 = fcmp fast ogt float %3487, 0x3FA4B5DCC0000000
  %3494 = select i1 %3491, float 0.000000e+00, float 1.000000e+00
  %3495 = select i1 %3492, float 0.000000e+00, float 1.000000e+00
  %3496 = select i1 %3493, float 0.000000e+00, float 1.000000e+00
  %3497 = fmul fast float %3485, 0x3FB3D07220000000
  %3498 = fmul fast float %3486, 0x3FB3D07220000000
  %3499 = fmul fast float %3487, 0x3FB3D07220000000
  %3500 = fadd fast float %3485, 0x3FAC28F5C0000000
  %3501 = fadd fast float %3486, 0x3FAC28F5C0000000
  %3502 = fadd fast float %3487, 0x3FAC28F5C0000000
  %3503 = fmul fast float %3500, 0x3FEE54EDE0000000
  %3504 = fmul fast float %3501, 0x3FEE54EDE0000000
  %3505 = fmul fast float %3502, 0x3FEE54EDE0000000
  %3506 = call float @dx.op.unary.f32(i32 23, float %3503)  ; Log(value)
  %3507 = call float @dx.op.unary.f32(i32 23, float %3504)  ; Log(value)
  %3508 = call float @dx.op.unary.f32(i32 23, float %3505)  ; Log(value)
  %3509 = fmul fast float %3506, 0x4003333340000000
  %3510 = fmul fast float %3507, 0x4003333340000000
  %3511 = fmul fast float %3508, 0x4003333340000000
  %3512 = call float @dx.op.unary.f32(i32 21, float %3509)  ; Exp(value)
  %3513 = call float @dx.op.unary.f32(i32 21, float %3510)  ; Exp(value)
  %3514 = call float @dx.op.unary.f32(i32 21, float %3511)  ; Exp(value)
  %3515 = fsub fast float %3497, %3512
  %3516 = fsub fast float %3498, %3513
  %3517 = fsub fast float %3499, %3514
  %3518 = fmul fast float %3515, %3494
  %3519 = fmul fast float %3516, %3495
  %3520 = fmul fast float %3517, %3496
  %3521 = fadd fast float %3518, %3512
  %3522 = fadd fast float %3519, %3513
  %3523 = fadd fast float %3520, %3514
  %3524 = fsub fast float -1.000000e+00, %3488
  br label %4735

; <label>:3525                                    ; preds = %3483
  %3526 = fcmp fast ogt float %38, 5.000000e-01
  %3527 = fcmp fast olt float %82, 1.000000e+00
  %3528 = and i1 %3526, %3527
  br i1 %3528, label %3529, label %3615

; <label>:3529                                    ; preds = %3525
  %3530 = sitofp i32 %63 to float
  %3531 = sitofp i32 %64 to float
  %3532 = fadd fast float %3530, 5.000000e-01
  %3533 = fadd fast float %3531, 5.000000e-01
  %3534 = fdiv fast float %3532, %45
  %3535 = fdiv fast float %3533, %46
  %3536 = fmul fast float %3534, 2.000000e+00
  %3537 = fmul fast float %3535, 2.000000e+00
  %3538 = fadd fast float %3536, -1.000000e+00
  %3539 = fsub fast float 1.000000e+00, %3537
  %3540 = fmul fast float %3538, %35
  %3541 = call float @dx.op.tertiary.f32(i32 46, float %3539, float %31, float %3540)  ; FMad(a,b,c)
  %3542 = call float @dx.op.tertiary.f32(i32 46, float %82, float %27, float %3541)  ; FMad(a,b,c)
  %3543 = fadd fast float %3542, %23
  %3544 = call float @dx.op.unary.f32(i32 6, float %3543)  ; FAbs(value)
  %3545 = fcmp fast ogt float %3544, 0x3EB0C6F7A0000000
  br i1 %3545, label %3546, label %3615

; <label>:3546                                    ; preds = %3529
  %3547 = fmul fast float %3538, %34
  %3548 = call float @dx.op.tertiary.f32(i32 46, float %3539, float %30, float %3547)  ; FMad(a,b,c)
  %3549 = call float @dx.op.tertiary.f32(i32 46, float %82, float %26, float %3548)  ; FMad(a,b,c)
  %3550 = fadd fast float %3549, %22
  %3551 = fmul fast float %3538, %33
  %3552 = call float @dx.op.tertiary.f32(i32 46, float %3539, float %29, float %3551)  ; FMad(a,b,c)
  %3553 = call float @dx.op.tertiary.f32(i32 46, float %82, float %25, float %3552)  ; FMad(a,b,c)
  %3554 = fadd fast float %3553, %21
  %3555 = fmul fast float %3538, %32
  %3556 = call float @dx.op.tertiary.f32(i32 46, float %3539, float %28, float %3555)  ; FMad(a,b,c)
  %3557 = call float @dx.op.tertiary.f32(i32 46, float %82, float %24, float %3556)  ; FMad(a,b,c)
  %3558 = fadd fast float %3557, %20
  %3559 = fdiv fast float %3558, %3543
  %3560 = fdiv fast float %3554, %3543
  %3561 = fdiv fast float %3550, %3543
  %3562 = fsub fast float %3559, %17
  %3563 = fsub fast float %3560, %18
  %3564 = fsub fast float %3561, %19
  %3565 = fmul fast float %3562, %3562
  %3566 = fmul fast float %3563, %3563
  %3567 = fadd fast float %3566, %3565
  %3568 = fmul fast float %3564, %3564
  %3569 = fadd fast float %3567, %3568
  %3570 = call float @dx.op.unary.f32(i32 24, float %3569)  ; Sqrt(value)
  %3571 = fsub fast float %3570, %9
  %3572 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3571)  ; FMax(a,b)
  %3573 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %3573, label %3574, label %3597

; <label>:3574                                    ; preds = %3546
  %3575 = call float @dx.op.unary.f32(i32 6, float %3563)  ; FAbs(value)
  %3576 = fmul fast float %3575, %11
  %3577 = fcmp fast olt float %3576, 0x3F50624DE0000000
  br i1 %3577, label %3578, label %3581

; <label>:3578                                    ; preds = %3574
  %3579 = fmul fast float %3576, 5.000000e-01
  %3580 = fsub fast float 1.000000e+00, %3579
  br label %3586

; <label>:3581                                    ; preds = %3574
  %3582 = fmul fast float %3576, 0xBFF7154760000000
  %3583 = call float @dx.op.unary.f32(i32 21, float %3582)  ; Exp(value)
  %3584 = fsub fast float 1.000000e+00, %3583
  %3585 = fdiv fast float %3584, %3576
  br label %3586

; <label>:3586                                    ; preds = %3581, %3578
  %3587 = phi float [ %3580, %3578 ], [ %3585, %3581 ]
  %3588 = call float @dx.op.binary.f32(i32 36, float %3560, float %18)  ; FMin(a,b)
  %3589 = fsub fast float %3588, %10
  %3590 = fmul fast float %11, %3589
  %3591 = fsub fast float -0.000000e+00, %3590
  %3592 = call float @dx.op.binary.f32(i32 35, float %3591, float -4.000000e+01)  ; FMax(a,b)
  %3593 = call float @dx.op.binary.f32(i32 36, float %3592, float 5.000000e+00)  ; FMin(a,b)
  %3594 = fmul fast float %3593, 0x3FF7154760000000
  %3595 = call float @dx.op.unary.f32(i32 21, float %3594)  ; Exp(value)
  %3596 = fmul fast float %3595, %3587
  br label %3597

; <label>:3597                                    ; preds = %3586, %3546
  %3598 = phi float [ %3596, %3586 ], [ 1.000000e+00, %3546 ]
  %3599 = fmul fast float %3572, %16
  %3600 = fmul fast float %3599, %3598
  %3601 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3600)  ; FMin(a,b)
  %3602 = fmul fast float %3601, 0xBFF7154760000000
  %3603 = call float @dx.op.unary.f32(i32 21, float %3602)  ; Exp(value)
  %3604 = fsub fast float 1.000000e+00, %3603
  %3605 = call float @dx.op.binary.f32(i32 36, float %12, float %3604)  ; FMin(a,b)
  %3606 = fsub fast float %13, %3485
  %3607 = fsub fast float %14, %3486
  %3608 = fsub fast float %15, %3487
  %3609 = fmul fast float %3605, %3606
  %3610 = fmul fast float %3605, %3607
  %3611 = fmul fast float %3605, %3608
  %3612 = fadd fast float %3609, %3485
  %3613 = fadd fast float %3610, %3486
  %3614 = fadd fast float %3611, %3487
  br label %3615

; <label>:3615                                    ; preds = %3597, %3529, %3525
  %3616 = phi float [ %3612, %3597 ], [ %3485, %3529 ], [ %3485, %3525 ]
  %3617 = phi float [ %3613, %3597 ], [ %3486, %3529 ], [ %3486, %3525 ]
  %3618 = phi float [ %3614, %3597 ], [ %3487, %3529 ], [ %3487, %3525 ]
  %3619 = fadd fast float %5, 1.000000e+00
  %3620 = fadd fast float %6, 1.000000e+00
  %3621 = fsub fast float 1.000000e+00, %5
  %3622 = fmul fast float %36, %3619
  %3623 = fmul fast float %36, %3620
  %3624 = fmul fast float %36, %3621
  %3625 = fmul fast float %3622, %3616
  %3626 = fmul fast float %3623, %3617
  %3627 = fmul fast float %3624, %3618
  %3628 = fcmp fast ult float %37, 5.000000e-01
  br i1 %3628, label %3654, label %3629

; <label>:3629                                    ; preds = %3615
  %3630 = fmul fast float %3625, 0x4004147AE0000000
  %3631 = fmul fast float %3626, 0x4004147AE0000000
  %3632 = fmul fast float %3627, 0x4004147AE0000000
  %3633 = fadd fast float %3630, 0x3F9EB851E0000000
  %3634 = fadd fast float %3631, 0x3F9EB851E0000000
  %3635 = fadd fast float %3632, 0x3F9EB851E0000000
  %3636 = fmul fast float %3633, %3625
  %3637 = fmul fast float %3634, %3626
  %3638 = fmul fast float %3635, %3627
  %3639 = fmul fast float %3625, 0x400370A3E0000000
  %3640 = fmul fast float %3626, 0x400370A3E0000000
  %3641 = fmul fast float %3627, 0x400370A3E0000000
  %3642 = fadd fast float %3639, 0x3FE2E147A0000000
  %3643 = fadd fast float %3640, 0x3FE2E147A0000000
  %3644 = fadd fast float %3641, 0x3FE2E147A0000000
  %3645 = fmul fast float %3642, %3625
  %3646 = fmul fast float %3643, %3626
  %3647 = fmul fast float %3644, %3627
  %3648 = fadd fast float %3645, 0x3FC1EB8520000000
  %3649 = fadd fast float %3646, 0x3FC1EB8520000000
  %3650 = fadd fast float %3647, 0x3FC1EB8520000000
  %3651 = fdiv fast float %3636, %3648
  %3652 = fdiv fast float %3637, %3649
  %3653 = fdiv fast float %3638, %3650
  br label %3654

; <label>:3654                                    ; preds = %3629, %3615
  %3655 = phi float [ %3651, %3629 ], [ %3625, %3615 ]
  %3656 = phi float [ %3652, %3629 ], [ %3626, %3615 ]
  %3657 = phi float [ %3653, %3629 ], [ %3627, %3615 ]
  %3658 = call float @dx.op.unary.f32(i32 7, float %3655)  ; Saturate(value)
  %3659 = call float @dx.op.unary.f32(i32 7, float %3656)  ; Saturate(value)
  %3660 = call float @dx.op.unary.f32(i32 7, float %3657)  ; Saturate(value)
  %3661 = call float @dx.op.dot3.f32(i32 55, float %3658, float %3659, float %3660, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3662 = fsub fast float %3658, %3661
  %3663 = fsub fast float %3659, %3661
  %3664 = fsub fast float %3660, %3661
  %3665 = fmul fast float %3662, %8
  %3666 = fmul fast float %3663, %8
  %3667 = fmul fast float %3664, %8
  %3668 = fadd fast float %3665, %3661
  %3669 = fadd fast float %3666, %3661
  %3670 = fadd fast float %3667, %3661
  %3671 = call float @dx.op.unary.f32(i32 7, float %3668)  ; Saturate(value)
  %3672 = call float @dx.op.unary.f32(i32 7, float %3669)  ; Saturate(value)
  %3673 = call float @dx.op.unary.f32(i32 7, float %3670)  ; Saturate(value)
  %3674 = fadd fast float %3671, 0xBFC70A3D80000000
  %3675 = fadd fast float %3672, 0xBFC70A3D80000000
  %3676 = fadd fast float %3673, 0xBFC70A3D80000000
  %3677 = fmul fast float %3674, %7
  %3678 = fmul fast float %3675, %7
  %3679 = fmul fast float %3676, %7
  %3680 = fadd fast float %3677, 0x3FC70A3D80000000
  %3681 = fadd fast float %3678, 0x3FC70A3D80000000
  %3682 = fadd fast float %3679, 0x3FC70A3D80000000
  %3683 = call float @dx.op.unary.f32(i32 7, float %3680)  ; Saturate(value)
  %3684 = call float @dx.op.unary.f32(i32 7, float %3681)  ; Saturate(value)
  %3685 = call float @dx.op.unary.f32(i32 7, float %3682)  ; Saturate(value)
  %3686 = add i32 %64, -1
  %3687 = call i32 @dx.op.binary.i32(i32 37, i32 %63, i32 0)  ; IMax(a,b)
  %3688 = call i32 @dx.op.binary.i32(i32 37, i32 %3686, i32 0)  ; IMax(a,b)
  %3689 = call i32 @dx.op.binary.i32(i32 38, i32 %3687, i32 %59)  ; IMin(a,b)
  %3690 = call i32 @dx.op.binary.i32(i32 38, i32 %3688, i32 %60)  ; IMin(a,b)
  %3691 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3689, i32 %3690, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3692 = extractvalue %dx.types.ResRet.f32 %3691, 0
  %3693 = fsub fast float 1.000000e+00, %82
  %3694 = fmul fast float %3693, 0x3FA99999A0000000
  %3695 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %3694)  ; FMax(a,b)
  %3696 = fsub fast float %3692, %82
  %3697 = call float @dx.op.unary.f32(i32 6, float %3696)  ; FAbs(value)
  %3698 = fdiv fast float %3697, %3695
  %3699 = fsub fast float 1.000000e+00, %3698
  %3700 = call float @dx.op.unary.f32(i32 7, float %3699)  ; Saturate(value)
  %3701 = fcmp fast ugt float %3700, 0.000000e+00
  br i1 %3701, label %3702, label %3923

; <label>:3702                                    ; preds = %3654
  %3703 = call i32 @dx.op.binary.i32(i32 37, i32 %3689, i32 0)  ; IMax(a,b)
  %3704 = call i32 @dx.op.binary.i32(i32 37, i32 %3690, i32 0)  ; IMax(a,b)
  %3705 = call i32 @dx.op.binary.i32(i32 38, i32 %3703, i32 %59)  ; IMin(a,b)
  %3706 = call i32 @dx.op.binary.i32(i32 38, i32 %3704, i32 %60)  ; IMin(a,b)
  %3707 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3705, i32 %3706, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3708 = extractvalue %dx.types.ResRet.f32 %3707, 0
  %3709 = extractvalue %dx.types.ResRet.f32 %3707, 1
  %3710 = extractvalue %dx.types.ResRet.f32 %3707, 2
  %3711 = extractvalue %dx.types.ResRet.f32 %3707, 3
  %3712 = fcmp fast olt float %3711, 0.000000e+00
  br i1 %3712, label %3713, label %3747

; <label>:3713                                    ; preds = %3702
  %3714 = fcmp fast ogt float %3708, 0x3FA4B5DCC0000000
  %3715 = fcmp fast ogt float %3709, 0x3FA4B5DCC0000000
  %3716 = fcmp fast ogt float %3710, 0x3FA4B5DCC0000000
  %3717 = select i1 %3714, float 0.000000e+00, float 1.000000e+00
  %3718 = select i1 %3715, float 0.000000e+00, float 1.000000e+00
  %3719 = select i1 %3716, float 0.000000e+00, float 1.000000e+00
  %3720 = fmul fast float %3708, 0x3FB3D07220000000
  %3721 = fmul fast float %3709, 0x3FB3D07220000000
  %3722 = fmul fast float %3710, 0x3FB3D07220000000
  %3723 = fadd fast float %3708, 0x3FAC28F5C0000000
  %3724 = fadd fast float %3709, 0x3FAC28F5C0000000
  %3725 = fadd fast float %3710, 0x3FAC28F5C0000000
  %3726 = fmul fast float %3723, 0x3FEE54EDE0000000
  %3727 = fmul fast float %3724, 0x3FEE54EDE0000000
  %3728 = fmul fast float %3725, 0x3FEE54EDE0000000
  %3729 = call float @dx.op.unary.f32(i32 23, float %3726)  ; Log(value)
  %3730 = call float @dx.op.unary.f32(i32 23, float %3727)  ; Log(value)
  %3731 = call float @dx.op.unary.f32(i32 23, float %3728)  ; Log(value)
  %3732 = fmul fast float %3729, 0x4003333340000000
  %3733 = fmul fast float %3730, 0x4003333340000000
  %3734 = fmul fast float %3731, 0x4003333340000000
  %3735 = call float @dx.op.unary.f32(i32 21, float %3732)  ; Exp(value)
  %3736 = call float @dx.op.unary.f32(i32 21, float %3733)  ; Exp(value)
  %3737 = call float @dx.op.unary.f32(i32 21, float %3734)  ; Exp(value)
  %3738 = fsub fast float %3720, %3735
  %3739 = fsub fast float %3721, %3736
  %3740 = fsub fast float %3722, %3737
  %3741 = fmul fast float %3738, %3717
  %3742 = fmul fast float %3739, %3718
  %3743 = fmul fast float %3740, %3719
  %3744 = fadd fast float %3741, %3735
  %3745 = fadd fast float %3742, %3736
  %3746 = fadd fast float %3743, %3737
  br label %3910

; <label>:3747                                    ; preds = %3702
  %3748 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3705, i32 %3706, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3749 = extractvalue %dx.types.ResRet.f32 %3748, 0
  %3750 = fcmp fast ogt float %38, 5.000000e-01
  %3751 = fcmp fast olt float %3749, 1.000000e+00
  %3752 = and i1 %3750, %3751
  br i1 %3752, label %3753, label %3839

; <label>:3753                                    ; preds = %3747
  %3754 = sitofp i32 %3705 to float
  %3755 = sitofp i32 %3706 to float
  %3756 = fadd fast float %3754, 5.000000e-01
  %3757 = fadd fast float %3755, 5.000000e-01
  %3758 = fdiv fast float %3756, %45
  %3759 = fdiv fast float %3757, %46
  %3760 = fmul fast float %3758, 2.000000e+00
  %3761 = fmul fast float %3759, 2.000000e+00
  %3762 = fadd fast float %3760, -1.000000e+00
  %3763 = fsub fast float 1.000000e+00, %3761
  %3764 = fmul fast float %3762, %35
  %3765 = call float @dx.op.tertiary.f32(i32 46, float %3763, float %31, float %3764)  ; FMad(a,b,c)
  %3766 = call float @dx.op.tertiary.f32(i32 46, float %3749, float %27, float %3765)  ; FMad(a,b,c)
  %3767 = fadd fast float %3766, %23
  %3768 = call float @dx.op.unary.f32(i32 6, float %3767)  ; FAbs(value)
  %3769 = fcmp fast ogt float %3768, 0x3EB0C6F7A0000000
  br i1 %3769, label %3770, label %3839

; <label>:3770                                    ; preds = %3753
  %3771 = fmul fast float %3762, %34
  %3772 = call float @dx.op.tertiary.f32(i32 46, float %3763, float %30, float %3771)  ; FMad(a,b,c)
  %3773 = call float @dx.op.tertiary.f32(i32 46, float %3749, float %26, float %3772)  ; FMad(a,b,c)
  %3774 = fadd fast float %3773, %22
  %3775 = fmul fast float %3762, %33
  %3776 = call float @dx.op.tertiary.f32(i32 46, float %3763, float %29, float %3775)  ; FMad(a,b,c)
  %3777 = call float @dx.op.tertiary.f32(i32 46, float %3749, float %25, float %3776)  ; FMad(a,b,c)
  %3778 = fadd fast float %3777, %21
  %3779 = fmul fast float %3762, %32
  %3780 = call float @dx.op.tertiary.f32(i32 46, float %3763, float %28, float %3779)  ; FMad(a,b,c)
  %3781 = call float @dx.op.tertiary.f32(i32 46, float %3749, float %24, float %3780)  ; FMad(a,b,c)
  %3782 = fadd fast float %3781, %20
  %3783 = fdiv fast float %3782, %3767
  %3784 = fdiv fast float %3778, %3767
  %3785 = fdiv fast float %3774, %3767
  %3786 = fsub fast float %3783, %17
  %3787 = fsub fast float %3784, %18
  %3788 = fsub fast float %3785, %19
  %3789 = fmul fast float %3786, %3786
  %3790 = fmul fast float %3787, %3787
  %3791 = fadd fast float %3790, %3789
  %3792 = fmul fast float %3788, %3788
  %3793 = fadd fast float %3791, %3792
  %3794 = call float @dx.op.unary.f32(i32 24, float %3793)  ; Sqrt(value)
  %3795 = fsub fast float %3794, %9
  %3796 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3795)  ; FMax(a,b)
  %3797 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %3797, label %3798, label %3821

; <label>:3798                                    ; preds = %3770
  %3799 = call float @dx.op.unary.f32(i32 6, float %3787)  ; FAbs(value)
  %3800 = fmul fast float %3799, %11
  %3801 = fcmp fast olt float %3800, 0x3F50624DE0000000
  br i1 %3801, label %3802, label %3805

; <label>:3802                                    ; preds = %3798
  %3803 = fmul fast float %3800, 5.000000e-01
  %3804 = fsub fast float 1.000000e+00, %3803
  br label %3810

; <label>:3805                                    ; preds = %3798
  %3806 = fmul fast float %3800, 0xBFF7154760000000
  %3807 = call float @dx.op.unary.f32(i32 21, float %3806)  ; Exp(value)
  %3808 = fsub fast float 1.000000e+00, %3807
  %3809 = fdiv fast float %3808, %3800
  br label %3810

; <label>:3810                                    ; preds = %3805, %3802
  %3811 = phi float [ %3804, %3802 ], [ %3809, %3805 ]
  %3812 = call float @dx.op.binary.f32(i32 36, float %3784, float %18)  ; FMin(a,b)
  %3813 = fsub fast float %3812, %10
  %3814 = fmul fast float %11, %3813
  %3815 = fsub fast float -0.000000e+00, %3814
  %3816 = call float @dx.op.binary.f32(i32 35, float %3815, float -4.000000e+01)  ; FMax(a,b)
  %3817 = call float @dx.op.binary.f32(i32 36, float %3816, float 5.000000e+00)  ; FMin(a,b)
  %3818 = fmul fast float %3817, 0x3FF7154760000000
  %3819 = call float @dx.op.unary.f32(i32 21, float %3818)  ; Exp(value)
  %3820 = fmul fast float %3819, %3811
  br label %3821

; <label>:3821                                    ; preds = %3810, %3770
  %3822 = phi float [ %3820, %3810 ], [ 1.000000e+00, %3770 ]
  %3823 = fmul fast float %3796, %16
  %3824 = fmul fast float %3823, %3822
  %3825 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3824)  ; FMin(a,b)
  %3826 = fmul fast float %3825, 0xBFF7154760000000
  %3827 = call float @dx.op.unary.f32(i32 21, float %3826)  ; Exp(value)
  %3828 = fsub fast float 1.000000e+00, %3827
  %3829 = call float @dx.op.binary.f32(i32 36, float %12, float %3828)  ; FMin(a,b)
  %3830 = fsub fast float %13, %3708
  %3831 = fsub fast float %14, %3709
  %3832 = fsub fast float %15, %3710
  %3833 = fmul fast float %3829, %3830
  %3834 = fmul fast float %3829, %3831
  %3835 = fmul fast float %3829, %3832
  %3836 = fadd fast float %3833, %3708
  %3837 = fadd fast float %3834, %3709
  %3838 = fadd fast float %3835, %3710
  br label %3839

; <label>:3839                                    ; preds = %3821, %3753, %3747
  %3840 = phi float [ %3836, %3821 ], [ %3708, %3753 ], [ %3708, %3747 ]
  %3841 = phi float [ %3837, %3821 ], [ %3709, %3753 ], [ %3709, %3747 ]
  %3842 = phi float [ %3838, %3821 ], [ %3710, %3753 ], [ %3710, %3747 ]
  %3843 = fadd fast float %5, 1.000000e+00
  %3844 = fadd fast float %6, 1.000000e+00
  %3845 = fsub fast float 1.000000e+00, %5
  %3846 = fmul fast float %36, %3843
  %3847 = fmul fast float %36, %3844
  %3848 = fmul fast float %36, %3845
  %3849 = fmul fast float %3846, %3840
  %3850 = fmul fast float %3847, %3841
  %3851 = fmul fast float %3848, %3842
  %3852 = fcmp fast ult float %37, 5.000000e-01
  br i1 %3852, label %3878, label %3853

; <label>:3853                                    ; preds = %3839
  %3854 = fmul fast float %3849, 0x4004147AE0000000
  %3855 = fmul fast float %3850, 0x4004147AE0000000
  %3856 = fmul fast float %3851, 0x4004147AE0000000
  %3857 = fadd fast float %3854, 0x3F9EB851E0000000
  %3858 = fadd fast float %3855, 0x3F9EB851E0000000
  %3859 = fadd fast float %3856, 0x3F9EB851E0000000
  %3860 = fmul fast float %3857, %3849
  %3861 = fmul fast float %3858, %3850
  %3862 = fmul fast float %3859, %3851
  %3863 = fmul fast float %3849, 0x400370A3E0000000
  %3864 = fmul fast float %3850, 0x400370A3E0000000
  %3865 = fmul fast float %3851, 0x400370A3E0000000
  %3866 = fadd fast float %3863, 0x3FE2E147A0000000
  %3867 = fadd fast float %3864, 0x3FE2E147A0000000
  %3868 = fadd fast float %3865, 0x3FE2E147A0000000
  %3869 = fmul fast float %3866, %3849
  %3870 = fmul fast float %3867, %3850
  %3871 = fmul fast float %3868, %3851
  %3872 = fadd fast float %3869, 0x3FC1EB8520000000
  %3873 = fadd fast float %3870, 0x3FC1EB8520000000
  %3874 = fadd fast float %3871, 0x3FC1EB8520000000
  %3875 = fdiv fast float %3860, %3872
  %3876 = fdiv fast float %3861, %3873
  %3877 = fdiv fast float %3862, %3874
  br label %3878

; <label>:3878                                    ; preds = %3853, %3839
  %3879 = phi float [ %3875, %3853 ], [ %3849, %3839 ]
  %3880 = phi float [ %3876, %3853 ], [ %3850, %3839 ]
  %3881 = phi float [ %3877, %3853 ], [ %3851, %3839 ]
  %3882 = call float @dx.op.unary.f32(i32 7, float %3879)  ; Saturate(value)
  %3883 = call float @dx.op.unary.f32(i32 7, float %3880)  ; Saturate(value)
  %3884 = call float @dx.op.unary.f32(i32 7, float %3881)  ; Saturate(value)
  %3885 = call float @dx.op.dot3.f32(i32 55, float %3882, float %3883, float %3884, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3886 = fsub fast float %3882, %3885
  %3887 = fsub fast float %3883, %3885
  %3888 = fsub fast float %3884, %3885
  %3889 = fmul fast float %3886, %8
  %3890 = fmul fast float %3887, %8
  %3891 = fmul fast float %3888, %8
  %3892 = fadd fast float %3889, %3885
  %3893 = fadd fast float %3890, %3885
  %3894 = fadd fast float %3891, %3885
  %3895 = call float @dx.op.unary.f32(i32 7, float %3892)  ; Saturate(value)
  %3896 = call float @dx.op.unary.f32(i32 7, float %3893)  ; Saturate(value)
  %3897 = call float @dx.op.unary.f32(i32 7, float %3894)  ; Saturate(value)
  %3898 = fadd fast float %3895, 0xBFC70A3D80000000
  %3899 = fadd fast float %3896, 0xBFC70A3D80000000
  %3900 = fadd fast float %3897, 0xBFC70A3D80000000
  %3901 = fmul fast float %3898, %7
  %3902 = fmul fast float %3899, %7
  %3903 = fmul fast float %3900, %7
  %3904 = fadd fast float %3901, 0x3FC70A3D80000000
  %3905 = fadd fast float %3902, 0x3FC70A3D80000000
  %3906 = fadd fast float %3903, 0x3FC70A3D80000000
  %3907 = call float @dx.op.unary.f32(i32 7, float %3904)  ; Saturate(value)
  %3908 = call float @dx.op.unary.f32(i32 7, float %3905)  ; Saturate(value)
  %3909 = call float @dx.op.unary.f32(i32 7, float %3906)  ; Saturate(value)
  br label %3910

; <label>:3910                                    ; preds = %3878, %3713
  %3911 = phi float [ %3744, %3713 ], [ %3907, %3878 ]
  %3912 = phi float [ %3745, %3713 ], [ %3908, %3878 ]
  %3913 = phi float [ %3746, %3713 ], [ %3909, %3878 ]
  %3914 = fsub fast float %3911, %3683
  %3915 = fsub fast float %3912, %3684
  %3916 = fsub fast float %3913, %3685
  %3917 = fmul fast float %3914, %3700
  %3918 = fmul fast float %3915, %3700
  %3919 = fmul fast float %3916, %3700
  %3920 = fadd fast float %3917, %3683
  %3921 = fadd fast float %3918, %3684
  %3922 = fadd fast float %3919, %3685
  br label %3923

; <label>:3923                                    ; preds = %3910, %3654
  %3924 = phi float [ %3920, %3910 ], [ %3683, %3654 ]
  %3925 = phi float [ %3921, %3910 ], [ %3684, %3654 ]
  %3926 = phi float [ %3922, %3910 ], [ %3685, %3654 ]
  %3927 = add i32 %64, 1
  %3928 = call i32 @dx.op.binary.i32(i32 37, i32 %3927, i32 0)  ; IMax(a,b)
  %3929 = call i32 @dx.op.binary.i32(i32 38, i32 %3928, i32 %60)  ; IMin(a,b)
  %3930 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3689, i32 %3929, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3931 = extractvalue %dx.types.ResRet.f32 %3930, 0
  %3932 = fsub fast float %3931, %82
  %3933 = call float @dx.op.unary.f32(i32 6, float %3932)  ; FAbs(value)
  %3934 = fdiv fast float %3933, %3695
  %3935 = fsub fast float 1.000000e+00, %3934
  %3936 = call float @dx.op.unary.f32(i32 7, float %3935)  ; Saturate(value)
  %3937 = fcmp fast ugt float %3936, 0.000000e+00
  br i1 %3937, label %3938, label %4159

; <label>:3938                                    ; preds = %3923
  %3939 = call i32 @dx.op.binary.i32(i32 37, i32 %3689, i32 0)  ; IMax(a,b)
  %3940 = call i32 @dx.op.binary.i32(i32 37, i32 %3929, i32 0)  ; IMax(a,b)
  %3941 = call i32 @dx.op.binary.i32(i32 38, i32 %3939, i32 %59)  ; IMin(a,b)
  %3942 = call i32 @dx.op.binary.i32(i32 38, i32 %3940, i32 %60)  ; IMin(a,b)
  %3943 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3941, i32 %3942, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3944 = extractvalue %dx.types.ResRet.f32 %3943, 0
  %3945 = extractvalue %dx.types.ResRet.f32 %3943, 1
  %3946 = extractvalue %dx.types.ResRet.f32 %3943, 2
  %3947 = extractvalue %dx.types.ResRet.f32 %3943, 3
  %3948 = fcmp fast olt float %3947, 0.000000e+00
  br i1 %3948, label %3949, label %3983

; <label>:3949                                    ; preds = %3938
  %3950 = fcmp fast ogt float %3944, 0x3FA4B5DCC0000000
  %3951 = fcmp fast ogt float %3945, 0x3FA4B5DCC0000000
  %3952 = fcmp fast ogt float %3946, 0x3FA4B5DCC0000000
  %3953 = select i1 %3950, float 0.000000e+00, float 1.000000e+00
  %3954 = select i1 %3951, float 0.000000e+00, float 1.000000e+00
  %3955 = select i1 %3952, float 0.000000e+00, float 1.000000e+00
  %3956 = fmul fast float %3944, 0x3FB3D07220000000
  %3957 = fmul fast float %3945, 0x3FB3D07220000000
  %3958 = fmul fast float %3946, 0x3FB3D07220000000
  %3959 = fadd fast float %3944, 0x3FAC28F5C0000000
  %3960 = fadd fast float %3945, 0x3FAC28F5C0000000
  %3961 = fadd fast float %3946, 0x3FAC28F5C0000000
  %3962 = fmul fast float %3959, 0x3FEE54EDE0000000
  %3963 = fmul fast float %3960, 0x3FEE54EDE0000000
  %3964 = fmul fast float %3961, 0x3FEE54EDE0000000
  %3965 = call float @dx.op.unary.f32(i32 23, float %3962)  ; Log(value)
  %3966 = call float @dx.op.unary.f32(i32 23, float %3963)  ; Log(value)
  %3967 = call float @dx.op.unary.f32(i32 23, float %3964)  ; Log(value)
  %3968 = fmul fast float %3965, 0x4003333340000000
  %3969 = fmul fast float %3966, 0x4003333340000000
  %3970 = fmul fast float %3967, 0x4003333340000000
  %3971 = call float @dx.op.unary.f32(i32 21, float %3968)  ; Exp(value)
  %3972 = call float @dx.op.unary.f32(i32 21, float %3969)  ; Exp(value)
  %3973 = call float @dx.op.unary.f32(i32 21, float %3970)  ; Exp(value)
  %3974 = fsub fast float %3956, %3971
  %3975 = fsub fast float %3957, %3972
  %3976 = fsub fast float %3958, %3973
  %3977 = fmul fast float %3974, %3953
  %3978 = fmul fast float %3975, %3954
  %3979 = fmul fast float %3976, %3955
  %3980 = fadd fast float %3977, %3971
  %3981 = fadd fast float %3978, %3972
  %3982 = fadd fast float %3979, %3973
  br label %4146

; <label>:3983                                    ; preds = %3938
  %3984 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3941, i32 %3942, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3985 = extractvalue %dx.types.ResRet.f32 %3984, 0
  %3986 = fcmp fast ogt float %38, 5.000000e-01
  %3987 = fcmp fast olt float %3985, 1.000000e+00
  %3988 = and i1 %3986, %3987
  br i1 %3988, label %3989, label %4075

; <label>:3989                                    ; preds = %3983
  %3990 = sitofp i32 %3941 to float
  %3991 = sitofp i32 %3942 to float
  %3992 = fadd fast float %3990, 5.000000e-01
  %3993 = fadd fast float %3991, 5.000000e-01
  %3994 = fdiv fast float %3992, %45
  %3995 = fdiv fast float %3993, %46
  %3996 = fmul fast float %3994, 2.000000e+00
  %3997 = fmul fast float %3995, 2.000000e+00
  %3998 = fadd fast float %3996, -1.000000e+00
  %3999 = fsub fast float 1.000000e+00, %3997
  %4000 = fmul fast float %3998, %35
  %4001 = call float @dx.op.tertiary.f32(i32 46, float %3999, float %31, float %4000)  ; FMad(a,b,c)
  %4002 = call float @dx.op.tertiary.f32(i32 46, float %3985, float %27, float %4001)  ; FMad(a,b,c)
  %4003 = fadd fast float %4002, %23
  %4004 = call float @dx.op.unary.f32(i32 6, float %4003)  ; FAbs(value)
  %4005 = fcmp fast ogt float %4004, 0x3EB0C6F7A0000000
  br i1 %4005, label %4006, label %4075

; <label>:4006                                    ; preds = %3989
  %4007 = fmul fast float %3998, %34
  %4008 = call float @dx.op.tertiary.f32(i32 46, float %3999, float %30, float %4007)  ; FMad(a,b,c)
  %4009 = call float @dx.op.tertiary.f32(i32 46, float %3985, float %26, float %4008)  ; FMad(a,b,c)
  %4010 = fadd fast float %4009, %22
  %4011 = fmul fast float %3998, %33
  %4012 = call float @dx.op.tertiary.f32(i32 46, float %3999, float %29, float %4011)  ; FMad(a,b,c)
  %4013 = call float @dx.op.tertiary.f32(i32 46, float %3985, float %25, float %4012)  ; FMad(a,b,c)
  %4014 = fadd fast float %4013, %21
  %4015 = fmul fast float %3998, %32
  %4016 = call float @dx.op.tertiary.f32(i32 46, float %3999, float %28, float %4015)  ; FMad(a,b,c)
  %4017 = call float @dx.op.tertiary.f32(i32 46, float %3985, float %24, float %4016)  ; FMad(a,b,c)
  %4018 = fadd fast float %4017, %20
  %4019 = fdiv fast float %4018, %4003
  %4020 = fdiv fast float %4014, %4003
  %4021 = fdiv fast float %4010, %4003
  %4022 = fsub fast float %4019, %17
  %4023 = fsub fast float %4020, %18
  %4024 = fsub fast float %4021, %19
  %4025 = fmul fast float %4022, %4022
  %4026 = fmul fast float %4023, %4023
  %4027 = fadd fast float %4026, %4025
  %4028 = fmul fast float %4024, %4024
  %4029 = fadd fast float %4027, %4028
  %4030 = call float @dx.op.unary.f32(i32 24, float %4029)  ; Sqrt(value)
  %4031 = fsub fast float %4030, %9
  %4032 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4031)  ; FMax(a,b)
  %4033 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %4033, label %4034, label %4057

; <label>:4034                                    ; preds = %4006
  %4035 = call float @dx.op.unary.f32(i32 6, float %4023)  ; FAbs(value)
  %4036 = fmul fast float %4035, %11
  %4037 = fcmp fast olt float %4036, 0x3F50624DE0000000
  br i1 %4037, label %4038, label %4041

; <label>:4038                                    ; preds = %4034
  %4039 = fmul fast float %4036, 5.000000e-01
  %4040 = fsub fast float 1.000000e+00, %4039
  br label %4046

; <label>:4041                                    ; preds = %4034
  %4042 = fmul fast float %4036, 0xBFF7154760000000
  %4043 = call float @dx.op.unary.f32(i32 21, float %4042)  ; Exp(value)
  %4044 = fsub fast float 1.000000e+00, %4043
  %4045 = fdiv fast float %4044, %4036
  br label %4046

; <label>:4046                                    ; preds = %4041, %4038
  %4047 = phi float [ %4040, %4038 ], [ %4045, %4041 ]
  %4048 = call float @dx.op.binary.f32(i32 36, float %4020, float %18)  ; FMin(a,b)
  %4049 = fsub fast float %4048, %10
  %4050 = fmul fast float %11, %4049
  %4051 = fsub fast float -0.000000e+00, %4050
  %4052 = call float @dx.op.binary.f32(i32 35, float %4051, float -4.000000e+01)  ; FMax(a,b)
  %4053 = call float @dx.op.binary.f32(i32 36, float %4052, float 5.000000e+00)  ; FMin(a,b)
  %4054 = fmul fast float %4053, 0x3FF7154760000000
  %4055 = call float @dx.op.unary.f32(i32 21, float %4054)  ; Exp(value)
  %4056 = fmul fast float %4055, %4047
  br label %4057

; <label>:4057                                    ; preds = %4046, %4006
  %4058 = phi float [ %4056, %4046 ], [ 1.000000e+00, %4006 ]
  %4059 = fmul fast float %4032, %16
  %4060 = fmul fast float %4059, %4058
  %4061 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4060)  ; FMin(a,b)
  %4062 = fmul fast float %4061, 0xBFF7154760000000
  %4063 = call float @dx.op.unary.f32(i32 21, float %4062)  ; Exp(value)
  %4064 = fsub fast float 1.000000e+00, %4063
  %4065 = call float @dx.op.binary.f32(i32 36, float %12, float %4064)  ; FMin(a,b)
  %4066 = fsub fast float %13, %3944
  %4067 = fsub fast float %14, %3945
  %4068 = fsub fast float %15, %3946
  %4069 = fmul fast float %4065, %4066
  %4070 = fmul fast float %4065, %4067
  %4071 = fmul fast float %4065, %4068
  %4072 = fadd fast float %4069, %3944
  %4073 = fadd fast float %4070, %3945
  %4074 = fadd fast float %4071, %3946
  br label %4075

; <label>:4075                                    ; preds = %4057, %3989, %3983
  %4076 = phi float [ %4072, %4057 ], [ %3944, %3989 ], [ %3944, %3983 ]
  %4077 = phi float [ %4073, %4057 ], [ %3945, %3989 ], [ %3945, %3983 ]
  %4078 = phi float [ %4074, %4057 ], [ %3946, %3989 ], [ %3946, %3983 ]
  %4079 = fadd fast float %5, 1.000000e+00
  %4080 = fadd fast float %6, 1.000000e+00
  %4081 = fsub fast float 1.000000e+00, %5
  %4082 = fmul fast float %36, %4079
  %4083 = fmul fast float %36, %4080
  %4084 = fmul fast float %36, %4081
  %4085 = fmul fast float %4082, %4076
  %4086 = fmul fast float %4083, %4077
  %4087 = fmul fast float %4084, %4078
  %4088 = fcmp fast ult float %37, 5.000000e-01
  br i1 %4088, label %4114, label %4089

; <label>:4089                                    ; preds = %4075
  %4090 = fmul fast float %4085, 0x4004147AE0000000
  %4091 = fmul fast float %4086, 0x4004147AE0000000
  %4092 = fmul fast float %4087, 0x4004147AE0000000
  %4093 = fadd fast float %4090, 0x3F9EB851E0000000
  %4094 = fadd fast float %4091, 0x3F9EB851E0000000
  %4095 = fadd fast float %4092, 0x3F9EB851E0000000
  %4096 = fmul fast float %4093, %4085
  %4097 = fmul fast float %4094, %4086
  %4098 = fmul fast float %4095, %4087
  %4099 = fmul fast float %4085, 0x400370A3E0000000
  %4100 = fmul fast float %4086, 0x400370A3E0000000
  %4101 = fmul fast float %4087, 0x400370A3E0000000
  %4102 = fadd fast float %4099, 0x3FE2E147A0000000
  %4103 = fadd fast float %4100, 0x3FE2E147A0000000
  %4104 = fadd fast float %4101, 0x3FE2E147A0000000
  %4105 = fmul fast float %4102, %4085
  %4106 = fmul fast float %4103, %4086
  %4107 = fmul fast float %4104, %4087
  %4108 = fadd fast float %4105, 0x3FC1EB8520000000
  %4109 = fadd fast float %4106, 0x3FC1EB8520000000
  %4110 = fadd fast float %4107, 0x3FC1EB8520000000
  %4111 = fdiv fast float %4096, %4108
  %4112 = fdiv fast float %4097, %4109
  %4113 = fdiv fast float %4098, %4110
  br label %4114

; <label>:4114                                    ; preds = %4089, %4075
  %4115 = phi float [ %4111, %4089 ], [ %4085, %4075 ]
  %4116 = phi float [ %4112, %4089 ], [ %4086, %4075 ]
  %4117 = phi float [ %4113, %4089 ], [ %4087, %4075 ]
  %4118 = call float @dx.op.unary.f32(i32 7, float %4115)  ; Saturate(value)
  %4119 = call float @dx.op.unary.f32(i32 7, float %4116)  ; Saturate(value)
  %4120 = call float @dx.op.unary.f32(i32 7, float %4117)  ; Saturate(value)
  %4121 = call float @dx.op.dot3.f32(i32 55, float %4118, float %4119, float %4120, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4122 = fsub fast float %4118, %4121
  %4123 = fsub fast float %4119, %4121
  %4124 = fsub fast float %4120, %4121
  %4125 = fmul fast float %4122, %8
  %4126 = fmul fast float %4123, %8
  %4127 = fmul fast float %4124, %8
  %4128 = fadd fast float %4125, %4121
  %4129 = fadd fast float %4126, %4121
  %4130 = fadd fast float %4127, %4121
  %4131 = call float @dx.op.unary.f32(i32 7, float %4128)  ; Saturate(value)
  %4132 = call float @dx.op.unary.f32(i32 7, float %4129)  ; Saturate(value)
  %4133 = call float @dx.op.unary.f32(i32 7, float %4130)  ; Saturate(value)
  %4134 = fadd fast float %4131, 0xBFC70A3D80000000
  %4135 = fadd fast float %4132, 0xBFC70A3D80000000
  %4136 = fadd fast float %4133, 0xBFC70A3D80000000
  %4137 = fmul fast float %4134, %7
  %4138 = fmul fast float %4135, %7
  %4139 = fmul fast float %4136, %7
  %4140 = fadd fast float %4137, 0x3FC70A3D80000000
  %4141 = fadd fast float %4138, 0x3FC70A3D80000000
  %4142 = fadd fast float %4139, 0x3FC70A3D80000000
  %4143 = call float @dx.op.unary.f32(i32 7, float %4140)  ; Saturate(value)
  %4144 = call float @dx.op.unary.f32(i32 7, float %4141)  ; Saturate(value)
  %4145 = call float @dx.op.unary.f32(i32 7, float %4142)  ; Saturate(value)
  br label %4146

; <label>:4146                                    ; preds = %4114, %3949
  %4147 = phi float [ %3980, %3949 ], [ %4143, %4114 ]
  %4148 = phi float [ %3981, %3949 ], [ %4144, %4114 ]
  %4149 = phi float [ %3982, %3949 ], [ %4145, %4114 ]
  %4150 = fsub fast float %4147, %3683
  %4151 = fsub fast float %4148, %3684
  %4152 = fsub fast float %4149, %3685
  %4153 = fmul fast float %4150, %3936
  %4154 = fmul fast float %4151, %3936
  %4155 = fmul fast float %4152, %3936
  %4156 = fadd fast float %4153, %3683
  %4157 = fadd fast float %4154, %3684
  %4158 = fadd fast float %4155, %3685
  br label %4159

; <label>:4159                                    ; preds = %4146, %3923
  %4160 = phi float [ %4156, %4146 ], [ %3683, %3923 ]
  %4161 = phi float [ %4157, %4146 ], [ %3684, %3923 ]
  %4162 = phi float [ %4158, %4146 ], [ %3685, %3923 ]
  %4163 = add i32 %63, -1
  %4164 = call i32 @dx.op.binary.i32(i32 37, i32 %4163, i32 0)  ; IMax(a,b)
  %4165 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %4166 = call i32 @dx.op.binary.i32(i32 38, i32 %4164, i32 %59)  ; IMin(a,b)
  %4167 = call i32 @dx.op.binary.i32(i32 38, i32 %4165, i32 %60)  ; IMin(a,b)
  %4168 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4166, i32 %4167, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4169 = extractvalue %dx.types.ResRet.f32 %4168, 0
  %4170 = fsub fast float %4169, %82
  %4171 = call float @dx.op.unary.f32(i32 6, float %4170)  ; FAbs(value)
  %4172 = fdiv fast float %4171, %3695
  %4173 = fsub fast float 1.000000e+00, %4172
  %4174 = call float @dx.op.unary.f32(i32 7, float %4173)  ; Saturate(value)
  %4175 = fcmp fast ugt float %4174, 0.000000e+00
  br i1 %4175, label %4176, label %4397

; <label>:4176                                    ; preds = %4159
  %4177 = call i32 @dx.op.binary.i32(i32 37, i32 %4166, i32 0)  ; IMax(a,b)
  %4178 = call i32 @dx.op.binary.i32(i32 37, i32 %4167, i32 0)  ; IMax(a,b)
  %4179 = call i32 @dx.op.binary.i32(i32 38, i32 %4177, i32 %59)  ; IMin(a,b)
  %4180 = call i32 @dx.op.binary.i32(i32 38, i32 %4178, i32 %60)  ; IMin(a,b)
  %4181 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4179, i32 %4180, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4182 = extractvalue %dx.types.ResRet.f32 %4181, 0
  %4183 = extractvalue %dx.types.ResRet.f32 %4181, 1
  %4184 = extractvalue %dx.types.ResRet.f32 %4181, 2
  %4185 = extractvalue %dx.types.ResRet.f32 %4181, 3
  %4186 = fcmp fast olt float %4185, 0.000000e+00
  br i1 %4186, label %4187, label %4221

; <label>:4187                                    ; preds = %4176
  %4188 = fcmp fast ogt float %4182, 0x3FA4B5DCC0000000
  %4189 = fcmp fast ogt float %4183, 0x3FA4B5DCC0000000
  %4190 = fcmp fast ogt float %4184, 0x3FA4B5DCC0000000
  %4191 = select i1 %4188, float 0.000000e+00, float 1.000000e+00
  %4192 = select i1 %4189, float 0.000000e+00, float 1.000000e+00
  %4193 = select i1 %4190, float 0.000000e+00, float 1.000000e+00
  %4194 = fmul fast float %4182, 0x3FB3D07220000000
  %4195 = fmul fast float %4183, 0x3FB3D07220000000
  %4196 = fmul fast float %4184, 0x3FB3D07220000000
  %4197 = fadd fast float %4182, 0x3FAC28F5C0000000
  %4198 = fadd fast float %4183, 0x3FAC28F5C0000000
  %4199 = fadd fast float %4184, 0x3FAC28F5C0000000
  %4200 = fmul fast float %4197, 0x3FEE54EDE0000000
  %4201 = fmul fast float %4198, 0x3FEE54EDE0000000
  %4202 = fmul fast float %4199, 0x3FEE54EDE0000000
  %4203 = call float @dx.op.unary.f32(i32 23, float %4200)  ; Log(value)
  %4204 = call float @dx.op.unary.f32(i32 23, float %4201)  ; Log(value)
  %4205 = call float @dx.op.unary.f32(i32 23, float %4202)  ; Log(value)
  %4206 = fmul fast float %4203, 0x4003333340000000
  %4207 = fmul fast float %4204, 0x4003333340000000
  %4208 = fmul fast float %4205, 0x4003333340000000
  %4209 = call float @dx.op.unary.f32(i32 21, float %4206)  ; Exp(value)
  %4210 = call float @dx.op.unary.f32(i32 21, float %4207)  ; Exp(value)
  %4211 = call float @dx.op.unary.f32(i32 21, float %4208)  ; Exp(value)
  %4212 = fsub fast float %4194, %4209
  %4213 = fsub fast float %4195, %4210
  %4214 = fsub fast float %4196, %4211
  %4215 = fmul fast float %4212, %4191
  %4216 = fmul fast float %4213, %4192
  %4217 = fmul fast float %4214, %4193
  %4218 = fadd fast float %4215, %4209
  %4219 = fadd fast float %4216, %4210
  %4220 = fadd fast float %4217, %4211
  br label %4384

; <label>:4221                                    ; preds = %4176
  %4222 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4179, i32 %4180, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4223 = extractvalue %dx.types.ResRet.f32 %4222, 0
  %4224 = fcmp fast ogt float %38, 5.000000e-01
  %4225 = fcmp fast olt float %4223, 1.000000e+00
  %4226 = and i1 %4224, %4225
  br i1 %4226, label %4227, label %4313

; <label>:4227                                    ; preds = %4221
  %4228 = sitofp i32 %4179 to float
  %4229 = sitofp i32 %4180 to float
  %4230 = fadd fast float %4228, 5.000000e-01
  %4231 = fadd fast float %4229, 5.000000e-01
  %4232 = fdiv fast float %4230, %45
  %4233 = fdiv fast float %4231, %46
  %4234 = fmul fast float %4232, 2.000000e+00
  %4235 = fmul fast float %4233, 2.000000e+00
  %4236 = fadd fast float %4234, -1.000000e+00
  %4237 = fsub fast float 1.000000e+00, %4235
  %4238 = fmul fast float %4236, %35
  %4239 = call float @dx.op.tertiary.f32(i32 46, float %4237, float %31, float %4238)  ; FMad(a,b,c)
  %4240 = call float @dx.op.tertiary.f32(i32 46, float %4223, float %27, float %4239)  ; FMad(a,b,c)
  %4241 = fadd fast float %4240, %23
  %4242 = call float @dx.op.unary.f32(i32 6, float %4241)  ; FAbs(value)
  %4243 = fcmp fast ogt float %4242, 0x3EB0C6F7A0000000
  br i1 %4243, label %4244, label %4313

; <label>:4244                                    ; preds = %4227
  %4245 = fmul fast float %4236, %34
  %4246 = call float @dx.op.tertiary.f32(i32 46, float %4237, float %30, float %4245)  ; FMad(a,b,c)
  %4247 = call float @dx.op.tertiary.f32(i32 46, float %4223, float %26, float %4246)  ; FMad(a,b,c)
  %4248 = fadd fast float %4247, %22
  %4249 = fmul fast float %4236, %33
  %4250 = call float @dx.op.tertiary.f32(i32 46, float %4237, float %29, float %4249)  ; FMad(a,b,c)
  %4251 = call float @dx.op.tertiary.f32(i32 46, float %4223, float %25, float %4250)  ; FMad(a,b,c)
  %4252 = fadd fast float %4251, %21
  %4253 = fmul fast float %4236, %32
  %4254 = call float @dx.op.tertiary.f32(i32 46, float %4237, float %28, float %4253)  ; FMad(a,b,c)
  %4255 = call float @dx.op.tertiary.f32(i32 46, float %4223, float %24, float %4254)  ; FMad(a,b,c)
  %4256 = fadd fast float %4255, %20
  %4257 = fdiv fast float %4256, %4241
  %4258 = fdiv fast float %4252, %4241
  %4259 = fdiv fast float %4248, %4241
  %4260 = fsub fast float %4257, %17
  %4261 = fsub fast float %4258, %18
  %4262 = fsub fast float %4259, %19
  %4263 = fmul fast float %4260, %4260
  %4264 = fmul fast float %4261, %4261
  %4265 = fadd fast float %4264, %4263
  %4266 = fmul fast float %4262, %4262
  %4267 = fadd fast float %4265, %4266
  %4268 = call float @dx.op.unary.f32(i32 24, float %4267)  ; Sqrt(value)
  %4269 = fsub fast float %4268, %9
  %4270 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4269)  ; FMax(a,b)
  %4271 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %4271, label %4272, label %4295

; <label>:4272                                    ; preds = %4244
  %4273 = call float @dx.op.unary.f32(i32 6, float %4261)  ; FAbs(value)
  %4274 = fmul fast float %4273, %11
  %4275 = fcmp fast olt float %4274, 0x3F50624DE0000000
  br i1 %4275, label %4276, label %4279

; <label>:4276                                    ; preds = %4272
  %4277 = fmul fast float %4274, 5.000000e-01
  %4278 = fsub fast float 1.000000e+00, %4277
  br label %4284

; <label>:4279                                    ; preds = %4272
  %4280 = fmul fast float %4274, 0xBFF7154760000000
  %4281 = call float @dx.op.unary.f32(i32 21, float %4280)  ; Exp(value)
  %4282 = fsub fast float 1.000000e+00, %4281
  %4283 = fdiv fast float %4282, %4274
  br label %4284

; <label>:4284                                    ; preds = %4279, %4276
  %4285 = phi float [ %4278, %4276 ], [ %4283, %4279 ]
  %4286 = call float @dx.op.binary.f32(i32 36, float %4258, float %18)  ; FMin(a,b)
  %4287 = fsub fast float %4286, %10
  %4288 = fmul fast float %11, %4287
  %4289 = fsub fast float -0.000000e+00, %4288
  %4290 = call float @dx.op.binary.f32(i32 35, float %4289, float -4.000000e+01)  ; FMax(a,b)
  %4291 = call float @dx.op.binary.f32(i32 36, float %4290, float 5.000000e+00)  ; FMin(a,b)
  %4292 = fmul fast float %4291, 0x3FF7154760000000
  %4293 = call float @dx.op.unary.f32(i32 21, float %4292)  ; Exp(value)
  %4294 = fmul fast float %4293, %4285
  br label %4295

; <label>:4295                                    ; preds = %4284, %4244
  %4296 = phi float [ %4294, %4284 ], [ 1.000000e+00, %4244 ]
  %4297 = fmul fast float %4270, %16
  %4298 = fmul fast float %4297, %4296
  %4299 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4298)  ; FMin(a,b)
  %4300 = fmul fast float %4299, 0xBFF7154760000000
  %4301 = call float @dx.op.unary.f32(i32 21, float %4300)  ; Exp(value)
  %4302 = fsub fast float 1.000000e+00, %4301
  %4303 = call float @dx.op.binary.f32(i32 36, float %12, float %4302)  ; FMin(a,b)
  %4304 = fsub fast float %13, %4182
  %4305 = fsub fast float %14, %4183
  %4306 = fsub fast float %15, %4184
  %4307 = fmul fast float %4303, %4304
  %4308 = fmul fast float %4303, %4305
  %4309 = fmul fast float %4303, %4306
  %4310 = fadd fast float %4307, %4182
  %4311 = fadd fast float %4308, %4183
  %4312 = fadd fast float %4309, %4184
  br label %4313

; <label>:4313                                    ; preds = %4295, %4227, %4221
  %4314 = phi float [ %4310, %4295 ], [ %4182, %4227 ], [ %4182, %4221 ]
  %4315 = phi float [ %4311, %4295 ], [ %4183, %4227 ], [ %4183, %4221 ]
  %4316 = phi float [ %4312, %4295 ], [ %4184, %4227 ], [ %4184, %4221 ]
  %4317 = fadd fast float %5, 1.000000e+00
  %4318 = fadd fast float %6, 1.000000e+00
  %4319 = fsub fast float 1.000000e+00, %5
  %4320 = fmul fast float %36, %4317
  %4321 = fmul fast float %36, %4318
  %4322 = fmul fast float %36, %4319
  %4323 = fmul fast float %4320, %4314
  %4324 = fmul fast float %4321, %4315
  %4325 = fmul fast float %4322, %4316
  %4326 = fcmp fast ult float %37, 5.000000e-01
  br i1 %4326, label %4352, label %4327

; <label>:4327                                    ; preds = %4313
  %4328 = fmul fast float %4323, 0x4004147AE0000000
  %4329 = fmul fast float %4324, 0x4004147AE0000000
  %4330 = fmul fast float %4325, 0x4004147AE0000000
  %4331 = fadd fast float %4328, 0x3F9EB851E0000000
  %4332 = fadd fast float %4329, 0x3F9EB851E0000000
  %4333 = fadd fast float %4330, 0x3F9EB851E0000000
  %4334 = fmul fast float %4331, %4323
  %4335 = fmul fast float %4332, %4324
  %4336 = fmul fast float %4333, %4325
  %4337 = fmul fast float %4323, 0x400370A3E0000000
  %4338 = fmul fast float %4324, 0x400370A3E0000000
  %4339 = fmul fast float %4325, 0x400370A3E0000000
  %4340 = fadd fast float %4337, 0x3FE2E147A0000000
  %4341 = fadd fast float %4338, 0x3FE2E147A0000000
  %4342 = fadd fast float %4339, 0x3FE2E147A0000000
  %4343 = fmul fast float %4340, %4323
  %4344 = fmul fast float %4341, %4324
  %4345 = fmul fast float %4342, %4325
  %4346 = fadd fast float %4343, 0x3FC1EB8520000000
  %4347 = fadd fast float %4344, 0x3FC1EB8520000000
  %4348 = fadd fast float %4345, 0x3FC1EB8520000000
  %4349 = fdiv fast float %4334, %4346
  %4350 = fdiv fast float %4335, %4347
  %4351 = fdiv fast float %4336, %4348
  br label %4352

; <label>:4352                                    ; preds = %4327, %4313
  %4353 = phi float [ %4349, %4327 ], [ %4323, %4313 ]
  %4354 = phi float [ %4350, %4327 ], [ %4324, %4313 ]
  %4355 = phi float [ %4351, %4327 ], [ %4325, %4313 ]
  %4356 = call float @dx.op.unary.f32(i32 7, float %4353)  ; Saturate(value)
  %4357 = call float @dx.op.unary.f32(i32 7, float %4354)  ; Saturate(value)
  %4358 = call float @dx.op.unary.f32(i32 7, float %4355)  ; Saturate(value)
  %4359 = call float @dx.op.dot3.f32(i32 55, float %4356, float %4357, float %4358, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4360 = fsub fast float %4356, %4359
  %4361 = fsub fast float %4357, %4359
  %4362 = fsub fast float %4358, %4359
  %4363 = fmul fast float %4360, %8
  %4364 = fmul fast float %4361, %8
  %4365 = fmul fast float %4362, %8
  %4366 = fadd fast float %4363, %4359
  %4367 = fadd fast float %4364, %4359
  %4368 = fadd fast float %4365, %4359
  %4369 = call float @dx.op.unary.f32(i32 7, float %4366)  ; Saturate(value)
  %4370 = call float @dx.op.unary.f32(i32 7, float %4367)  ; Saturate(value)
  %4371 = call float @dx.op.unary.f32(i32 7, float %4368)  ; Saturate(value)
  %4372 = fadd fast float %4369, 0xBFC70A3D80000000
  %4373 = fadd fast float %4370, 0xBFC70A3D80000000
  %4374 = fadd fast float %4371, 0xBFC70A3D80000000
  %4375 = fmul fast float %4372, %7
  %4376 = fmul fast float %4373, %7
  %4377 = fmul fast float %4374, %7
  %4378 = fadd fast float %4375, 0x3FC70A3D80000000
  %4379 = fadd fast float %4376, 0x3FC70A3D80000000
  %4380 = fadd fast float %4377, 0x3FC70A3D80000000
  %4381 = call float @dx.op.unary.f32(i32 7, float %4378)  ; Saturate(value)
  %4382 = call float @dx.op.unary.f32(i32 7, float %4379)  ; Saturate(value)
  %4383 = call float @dx.op.unary.f32(i32 7, float %4380)  ; Saturate(value)
  br label %4384

; <label>:4384                                    ; preds = %4352, %4187
  %4385 = phi float [ %4218, %4187 ], [ %4381, %4352 ]
  %4386 = phi float [ %4219, %4187 ], [ %4382, %4352 ]
  %4387 = phi float [ %4220, %4187 ], [ %4383, %4352 ]
  %4388 = fsub fast float %4385, %3683
  %4389 = fsub fast float %4386, %3684
  %4390 = fsub fast float %4387, %3685
  %4391 = fmul fast float %4388, %4174
  %4392 = fmul fast float %4389, %4174
  %4393 = fmul fast float %4390, %4174
  %4394 = fadd fast float %4391, %3683
  %4395 = fadd fast float %4392, %3684
  %4396 = fadd fast float %4393, %3685
  br label %4397

; <label>:4397                                    ; preds = %4384, %4159
  %4398 = phi float [ %4394, %4384 ], [ %3683, %4159 ]
  %4399 = phi float [ %4395, %4384 ], [ %3684, %4159 ]
  %4400 = phi float [ %4396, %4384 ], [ %3685, %4159 ]
  %4401 = add i32 %63, 1
  %4402 = call i32 @dx.op.binary.i32(i32 37, i32 %4401, i32 0)  ; IMax(a,b)
  %4403 = call i32 @dx.op.binary.i32(i32 38, i32 %4402, i32 %59)  ; IMin(a,b)
  %4404 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4403, i32 %4167, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4405 = extractvalue %dx.types.ResRet.f32 %4404, 0
  %4406 = fsub fast float %4405, %82
  %4407 = call float @dx.op.unary.f32(i32 6, float %4406)  ; FAbs(value)
  %4408 = fdiv fast float %4407, %3695
  %4409 = fsub fast float 1.000000e+00, %4408
  %4410 = call float @dx.op.unary.f32(i32 7, float %4409)  ; Saturate(value)
  %4411 = fcmp fast ugt float %4410, 0.000000e+00
  br i1 %4411, label %4412, label %4633

; <label>:4412                                    ; preds = %4397
  %4413 = call i32 @dx.op.binary.i32(i32 37, i32 %4403, i32 0)  ; IMax(a,b)
  %4414 = call i32 @dx.op.binary.i32(i32 37, i32 %4167, i32 0)  ; IMax(a,b)
  %4415 = call i32 @dx.op.binary.i32(i32 38, i32 %4413, i32 %59)  ; IMin(a,b)
  %4416 = call i32 @dx.op.binary.i32(i32 38, i32 %4414, i32 %60)  ; IMin(a,b)
  %4417 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4415, i32 %4416, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4418 = extractvalue %dx.types.ResRet.f32 %4417, 0
  %4419 = extractvalue %dx.types.ResRet.f32 %4417, 1
  %4420 = extractvalue %dx.types.ResRet.f32 %4417, 2
  %4421 = extractvalue %dx.types.ResRet.f32 %4417, 3
  %4422 = fcmp fast olt float %4421, 0.000000e+00
  br i1 %4422, label %4423, label %4457

; <label>:4423                                    ; preds = %4412
  %4424 = fcmp fast ogt float %4418, 0x3FA4B5DCC0000000
  %4425 = fcmp fast ogt float %4419, 0x3FA4B5DCC0000000
  %4426 = fcmp fast ogt float %4420, 0x3FA4B5DCC0000000
  %4427 = select i1 %4424, float 0.000000e+00, float 1.000000e+00
  %4428 = select i1 %4425, float 0.000000e+00, float 1.000000e+00
  %4429 = select i1 %4426, float 0.000000e+00, float 1.000000e+00
  %4430 = fmul fast float %4418, 0x3FB3D07220000000
  %4431 = fmul fast float %4419, 0x3FB3D07220000000
  %4432 = fmul fast float %4420, 0x3FB3D07220000000
  %4433 = fadd fast float %4418, 0x3FAC28F5C0000000
  %4434 = fadd fast float %4419, 0x3FAC28F5C0000000
  %4435 = fadd fast float %4420, 0x3FAC28F5C0000000
  %4436 = fmul fast float %4433, 0x3FEE54EDE0000000
  %4437 = fmul fast float %4434, 0x3FEE54EDE0000000
  %4438 = fmul fast float %4435, 0x3FEE54EDE0000000
  %4439 = call float @dx.op.unary.f32(i32 23, float %4436)  ; Log(value)
  %4440 = call float @dx.op.unary.f32(i32 23, float %4437)  ; Log(value)
  %4441 = call float @dx.op.unary.f32(i32 23, float %4438)  ; Log(value)
  %4442 = fmul fast float %4439, 0x4003333340000000
  %4443 = fmul fast float %4440, 0x4003333340000000
  %4444 = fmul fast float %4441, 0x4003333340000000
  %4445 = call float @dx.op.unary.f32(i32 21, float %4442)  ; Exp(value)
  %4446 = call float @dx.op.unary.f32(i32 21, float %4443)  ; Exp(value)
  %4447 = call float @dx.op.unary.f32(i32 21, float %4444)  ; Exp(value)
  %4448 = fsub fast float %4430, %4445
  %4449 = fsub fast float %4431, %4446
  %4450 = fsub fast float %4432, %4447
  %4451 = fmul fast float %4448, %4427
  %4452 = fmul fast float %4449, %4428
  %4453 = fmul fast float %4450, %4429
  %4454 = fadd fast float %4451, %4445
  %4455 = fadd fast float %4452, %4446
  %4456 = fadd fast float %4453, %4447
  br label %4620

; <label>:4457                                    ; preds = %4412
  %4458 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4415, i32 %4416, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4459 = extractvalue %dx.types.ResRet.f32 %4458, 0
  %4460 = fcmp fast ogt float %38, 5.000000e-01
  %4461 = fcmp fast olt float %4459, 1.000000e+00
  %4462 = and i1 %4460, %4461
  br i1 %4462, label %4463, label %4549

; <label>:4463                                    ; preds = %4457
  %4464 = sitofp i32 %4415 to float
  %4465 = sitofp i32 %4416 to float
  %4466 = fadd fast float %4464, 5.000000e-01
  %4467 = fadd fast float %4465, 5.000000e-01
  %4468 = fdiv fast float %4466, %45
  %4469 = fdiv fast float %4467, %46
  %4470 = fmul fast float %4468, 2.000000e+00
  %4471 = fmul fast float %4469, 2.000000e+00
  %4472 = fadd fast float %4470, -1.000000e+00
  %4473 = fsub fast float 1.000000e+00, %4471
  %4474 = fmul fast float %4472, %35
  %4475 = call float @dx.op.tertiary.f32(i32 46, float %4473, float %31, float %4474)  ; FMad(a,b,c)
  %4476 = call float @dx.op.tertiary.f32(i32 46, float %4459, float %27, float %4475)  ; FMad(a,b,c)
  %4477 = fadd fast float %4476, %23
  %4478 = call float @dx.op.unary.f32(i32 6, float %4477)  ; FAbs(value)
  %4479 = fcmp fast ogt float %4478, 0x3EB0C6F7A0000000
  br i1 %4479, label %4480, label %4549

; <label>:4480                                    ; preds = %4463
  %4481 = fmul fast float %4472, %34
  %4482 = call float @dx.op.tertiary.f32(i32 46, float %4473, float %30, float %4481)  ; FMad(a,b,c)
  %4483 = call float @dx.op.tertiary.f32(i32 46, float %4459, float %26, float %4482)  ; FMad(a,b,c)
  %4484 = fadd fast float %4483, %22
  %4485 = fmul fast float %4472, %33
  %4486 = call float @dx.op.tertiary.f32(i32 46, float %4473, float %29, float %4485)  ; FMad(a,b,c)
  %4487 = call float @dx.op.tertiary.f32(i32 46, float %4459, float %25, float %4486)  ; FMad(a,b,c)
  %4488 = fadd fast float %4487, %21
  %4489 = fmul fast float %4472, %32
  %4490 = call float @dx.op.tertiary.f32(i32 46, float %4473, float %28, float %4489)  ; FMad(a,b,c)
  %4491 = call float @dx.op.tertiary.f32(i32 46, float %4459, float %24, float %4490)  ; FMad(a,b,c)
  %4492 = fadd fast float %4491, %20
  %4493 = fdiv fast float %4492, %4477
  %4494 = fdiv fast float %4488, %4477
  %4495 = fdiv fast float %4484, %4477
  %4496 = fsub fast float %4493, %17
  %4497 = fsub fast float %4494, %18
  %4498 = fsub fast float %4495, %19
  %4499 = fmul fast float %4496, %4496
  %4500 = fmul fast float %4497, %4497
  %4501 = fadd fast float %4500, %4499
  %4502 = fmul fast float %4498, %4498
  %4503 = fadd fast float %4501, %4502
  %4504 = call float @dx.op.unary.f32(i32 24, float %4503)  ; Sqrt(value)
  %4505 = fsub fast float %4504, %9
  %4506 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4505)  ; FMax(a,b)
  %4507 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %4507, label %4508, label %4531

; <label>:4508                                    ; preds = %4480
  %4509 = call float @dx.op.unary.f32(i32 6, float %4497)  ; FAbs(value)
  %4510 = fmul fast float %4509, %11
  %4511 = fcmp fast olt float %4510, 0x3F50624DE0000000
  br i1 %4511, label %4512, label %4515

; <label>:4512                                    ; preds = %4508
  %4513 = fmul fast float %4510, 5.000000e-01
  %4514 = fsub fast float 1.000000e+00, %4513
  br label %4520

; <label>:4515                                    ; preds = %4508
  %4516 = fmul fast float %4510, 0xBFF7154760000000
  %4517 = call float @dx.op.unary.f32(i32 21, float %4516)  ; Exp(value)
  %4518 = fsub fast float 1.000000e+00, %4517
  %4519 = fdiv fast float %4518, %4510
  br label %4520

; <label>:4520                                    ; preds = %4515, %4512
  %4521 = phi float [ %4514, %4512 ], [ %4519, %4515 ]
  %4522 = call float @dx.op.binary.f32(i32 36, float %4494, float %18)  ; FMin(a,b)
  %4523 = fsub fast float %4522, %10
  %4524 = fmul fast float %11, %4523
  %4525 = fsub fast float -0.000000e+00, %4524
  %4526 = call float @dx.op.binary.f32(i32 35, float %4525, float -4.000000e+01)  ; FMax(a,b)
  %4527 = call float @dx.op.binary.f32(i32 36, float %4526, float 5.000000e+00)  ; FMin(a,b)
  %4528 = fmul fast float %4527, 0x3FF7154760000000
  %4529 = call float @dx.op.unary.f32(i32 21, float %4528)  ; Exp(value)
  %4530 = fmul fast float %4529, %4521
  br label %4531

; <label>:4531                                    ; preds = %4520, %4480
  %4532 = phi float [ %4530, %4520 ], [ 1.000000e+00, %4480 ]
  %4533 = fmul fast float %4506, %16
  %4534 = fmul fast float %4533, %4532
  %4535 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4534)  ; FMin(a,b)
  %4536 = fmul fast float %4535, 0xBFF7154760000000
  %4537 = call float @dx.op.unary.f32(i32 21, float %4536)  ; Exp(value)
  %4538 = fsub fast float 1.000000e+00, %4537
  %4539 = call float @dx.op.binary.f32(i32 36, float %12, float %4538)  ; FMin(a,b)
  %4540 = fsub fast float %13, %4418
  %4541 = fsub fast float %14, %4419
  %4542 = fsub fast float %15, %4420
  %4543 = fmul fast float %4539, %4540
  %4544 = fmul fast float %4539, %4541
  %4545 = fmul fast float %4539, %4542
  %4546 = fadd fast float %4543, %4418
  %4547 = fadd fast float %4544, %4419
  %4548 = fadd fast float %4545, %4420
  br label %4549

; <label>:4549                                    ; preds = %4531, %4463, %4457
  %4550 = phi float [ %4546, %4531 ], [ %4418, %4463 ], [ %4418, %4457 ]
  %4551 = phi float [ %4547, %4531 ], [ %4419, %4463 ], [ %4419, %4457 ]
  %4552 = phi float [ %4548, %4531 ], [ %4420, %4463 ], [ %4420, %4457 ]
  %4553 = fadd fast float %5, 1.000000e+00
  %4554 = fadd fast float %6, 1.000000e+00
  %4555 = fsub fast float 1.000000e+00, %5
  %4556 = fmul fast float %36, %4553
  %4557 = fmul fast float %36, %4554
  %4558 = fmul fast float %36, %4555
  %4559 = fmul fast float %4556, %4550
  %4560 = fmul fast float %4557, %4551
  %4561 = fmul fast float %4558, %4552
  %4562 = fcmp fast ult float %37, 5.000000e-01
  br i1 %4562, label %4588, label %4563

; <label>:4563                                    ; preds = %4549
  %4564 = fmul fast float %4559, 0x4004147AE0000000
  %4565 = fmul fast float %4560, 0x4004147AE0000000
  %4566 = fmul fast float %4561, 0x4004147AE0000000
  %4567 = fadd fast float %4564, 0x3F9EB851E0000000
  %4568 = fadd fast float %4565, 0x3F9EB851E0000000
  %4569 = fadd fast float %4566, 0x3F9EB851E0000000
  %4570 = fmul fast float %4567, %4559
  %4571 = fmul fast float %4568, %4560
  %4572 = fmul fast float %4569, %4561
  %4573 = fmul fast float %4559, 0x400370A3E0000000
  %4574 = fmul fast float %4560, 0x400370A3E0000000
  %4575 = fmul fast float %4561, 0x400370A3E0000000
  %4576 = fadd fast float %4573, 0x3FE2E147A0000000
  %4577 = fadd fast float %4574, 0x3FE2E147A0000000
  %4578 = fadd fast float %4575, 0x3FE2E147A0000000
  %4579 = fmul fast float %4576, %4559
  %4580 = fmul fast float %4577, %4560
  %4581 = fmul fast float %4578, %4561
  %4582 = fadd fast float %4579, 0x3FC1EB8520000000
  %4583 = fadd fast float %4580, 0x3FC1EB8520000000
  %4584 = fadd fast float %4581, 0x3FC1EB8520000000
  %4585 = fdiv fast float %4570, %4582
  %4586 = fdiv fast float %4571, %4583
  %4587 = fdiv fast float %4572, %4584
  br label %4588

; <label>:4588                                    ; preds = %4563, %4549
  %4589 = phi float [ %4585, %4563 ], [ %4559, %4549 ]
  %4590 = phi float [ %4586, %4563 ], [ %4560, %4549 ]
  %4591 = phi float [ %4587, %4563 ], [ %4561, %4549 ]
  %4592 = call float @dx.op.unary.f32(i32 7, float %4589)  ; Saturate(value)
  %4593 = call float @dx.op.unary.f32(i32 7, float %4590)  ; Saturate(value)
  %4594 = call float @dx.op.unary.f32(i32 7, float %4591)  ; Saturate(value)
  %4595 = call float @dx.op.dot3.f32(i32 55, float %4592, float %4593, float %4594, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4596 = fsub fast float %4592, %4595
  %4597 = fsub fast float %4593, %4595
  %4598 = fsub fast float %4594, %4595
  %4599 = fmul fast float %4596, %8
  %4600 = fmul fast float %4597, %8
  %4601 = fmul fast float %4598, %8
  %4602 = fadd fast float %4599, %4595
  %4603 = fadd fast float %4600, %4595
  %4604 = fadd fast float %4601, %4595
  %4605 = call float @dx.op.unary.f32(i32 7, float %4602)  ; Saturate(value)
  %4606 = call float @dx.op.unary.f32(i32 7, float %4603)  ; Saturate(value)
  %4607 = call float @dx.op.unary.f32(i32 7, float %4604)  ; Saturate(value)
  %4608 = fadd fast float %4605, 0xBFC70A3D80000000
  %4609 = fadd fast float %4606, 0xBFC70A3D80000000
  %4610 = fadd fast float %4607, 0xBFC70A3D80000000
  %4611 = fmul fast float %4608, %7
  %4612 = fmul fast float %4609, %7
  %4613 = fmul fast float %4610, %7
  %4614 = fadd fast float %4611, 0x3FC70A3D80000000
  %4615 = fadd fast float %4612, 0x3FC70A3D80000000
  %4616 = fadd fast float %4613, 0x3FC70A3D80000000
  %4617 = call float @dx.op.unary.f32(i32 7, float %4614)  ; Saturate(value)
  %4618 = call float @dx.op.unary.f32(i32 7, float %4615)  ; Saturate(value)
  %4619 = call float @dx.op.unary.f32(i32 7, float %4616)  ; Saturate(value)
  br label %4620

; <label>:4620                                    ; preds = %4588, %4423
  %4621 = phi float [ %4454, %4423 ], [ %4617, %4588 ]
  %4622 = phi float [ %4455, %4423 ], [ %4618, %4588 ]
  %4623 = phi float [ %4456, %4423 ], [ %4619, %4588 ]
  %4624 = fsub fast float %4621, %3683
  %4625 = fsub fast float %4622, %3684
  %4626 = fsub fast float %4623, %3685
  %4627 = fmul fast float %4624, %4410
  %4628 = fmul fast float %4625, %4410
  %4629 = fmul fast float %4626, %4410
  %4630 = fadd fast float %4627, %3683
  %4631 = fadd fast float %4628, %3684
  %4632 = fadd fast float %4629, %3685
  br label %4633

; <label>:4633                                    ; preds = %4620, %4397
  %4634 = phi float [ %4630, %4620 ], [ %3683, %4397 ]
  %4635 = phi float [ %4631, %4620 ], [ %3684, %4397 ]
  %4636 = phi float [ %4632, %4620 ], [ %3685, %4397 ]
  %4637 = call float @dx.op.binary.f32(i32 36, float %4398, float %4634)  ; FMin(a,b)
  %4638 = call float @dx.op.binary.f32(i32 36, float %4399, float %4635)  ; FMin(a,b)
  %4639 = call float @dx.op.binary.f32(i32 36, float %4400, float %4636)  ; FMin(a,b)
  %4640 = call float @dx.op.binary.f32(i32 36, float %3924, float %4160)  ; FMin(a,b)
  %4641 = call float @dx.op.binary.f32(i32 36, float %3925, float %4161)  ; FMin(a,b)
  %4642 = call float @dx.op.binary.f32(i32 36, float %3926, float %4162)  ; FMin(a,b)
  %4643 = call float @dx.op.binary.f32(i32 36, float %4640, float %4637)  ; FMin(a,b)
  %4644 = call float @dx.op.binary.f32(i32 36, float %4641, float %4638)  ; FMin(a,b)
  %4645 = call float @dx.op.binary.f32(i32 36, float %4642, float %4639)  ; FMin(a,b)
  %4646 = call float @dx.op.binary.f32(i32 36, float %3683, float %4643)  ; FMin(a,b)
  %4647 = call float @dx.op.binary.f32(i32 36, float %3684, float %4644)  ; FMin(a,b)
  %4648 = call float @dx.op.binary.f32(i32 36, float %3685, float %4645)  ; FMin(a,b)
  %4649 = call float @dx.op.binary.f32(i32 35, float %4398, float %4634)  ; FMax(a,b)
  %4650 = call float @dx.op.binary.f32(i32 35, float %4399, float %4635)  ; FMax(a,b)
  %4651 = call float @dx.op.binary.f32(i32 35, float %4400, float %4636)  ; FMax(a,b)
  %4652 = call float @dx.op.binary.f32(i32 35, float %3924, float %4160)  ; FMax(a,b)
  %4653 = call float @dx.op.binary.f32(i32 35, float %3925, float %4161)  ; FMax(a,b)
  %4654 = call float @dx.op.binary.f32(i32 35, float %3926, float %4162)  ; FMax(a,b)
  %4655 = call float @dx.op.binary.f32(i32 35, float %4652, float %4649)  ; FMax(a,b)
  %4656 = call float @dx.op.binary.f32(i32 35, float %4653, float %4650)  ; FMax(a,b)
  %4657 = call float @dx.op.binary.f32(i32 35, float %4654, float %4651)  ; FMax(a,b)
  %4658 = call float @dx.op.binary.f32(i32 35, float %3683, float %4655)  ; FMax(a,b)
  %4659 = call float @dx.op.binary.f32(i32 35, float %3684, float %4656)  ; FMax(a,b)
  %4660 = call float @dx.op.binary.f32(i32 35, float %3685, float %4657)  ; FMax(a,b)
  %4661 = fsub fast float %4658, %4646
  %4662 = fsub fast float %4659, %4647
  %4663 = fsub fast float %4660, %4648
  %4664 = call float @dx.op.unary.f32(i32 6, float %4661)  ; FAbs(value)
  %4665 = call float @dx.op.unary.f32(i32 6, float %4662)  ; FAbs(value)
  %4666 = call float @dx.op.unary.f32(i32 6, float %4663)  ; FAbs(value)
  %4667 = call float @dx.op.binary.f32(i32 35, float %4665, float %4666)  ; FMax(a,b)
  %4668 = call float @dx.op.binary.f32(i32 35, float %4664, float %4667)  ; FMax(a,b)
  %4669 = call float @dx.op.binary.f32(i32 35, float %4659, float %4660)  ; FMax(a,b)
  %4670 = call float @dx.op.binary.f32(i32 35, float %4658, float %4669)  ; FMax(a,b)
  %4671 = fmul fast float %4670, 1.250000e-01
  %4672 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %4671)  ; FMax(a,b)
  %4673 = fcmp fast ogt float %4668, %4672
  br i1 %4673, label %4674, label %4735

; <label>:4674                                    ; preds = %4633
  %4675 = fsub fast float %3924, %4160
  %4676 = fsub fast float %3925, %4161
  %4677 = fsub fast float %3926, %4162
  %4678 = call float @dx.op.unary.f32(i32 6, float %4675)  ; FAbs(value)
  %4679 = call float @dx.op.unary.f32(i32 6, float %4676)  ; FAbs(value)
  %4680 = call float @dx.op.unary.f32(i32 6, float %4677)  ; FAbs(value)
  %4681 = call float @dx.op.binary.f32(i32 35, float %4679, float %4680)  ; FMax(a,b)
  %4682 = call float @dx.op.binary.f32(i32 35, float %4678, float %4681)  ; FMax(a,b)
  %4683 = fsub fast float %4398, %4634
  %4684 = fsub fast float %4399, %4635
  %4685 = fsub fast float %4400, %4636
  %4686 = call float @dx.op.unary.f32(i32 6, float %4683)  ; FAbs(value)
  %4687 = call float @dx.op.unary.f32(i32 6, float %4684)  ; FAbs(value)
  %4688 = call float @dx.op.unary.f32(i32 6, float %4685)  ; FAbs(value)
  %4689 = call float @dx.op.binary.f32(i32 35, float %4687, float %4688)  ; FMax(a,b)
  %4690 = call float @dx.op.binary.f32(i32 35, float %4686, float %4689)  ; FMax(a,b)
  %4691 = fcmp fast olt float %4682, %4690
  %4692 = select i1 %4691, float %3924, float %4398
  %4693 = select i1 %4691, float %3925, float %4399
  %4694 = select i1 %4691, float %3926, float %4400
  %4695 = select i1 %4691, float %4160, float %4634
  %4696 = select i1 %4691, float %4161, float %4635
  %4697 = select i1 %4691, float %4162, float %4636
  %4698 = fsub fast float %3683, %4695
  %4699 = fsub fast float %3684, %4696
  %4700 = fsub fast float %3685, %4697
  %4701 = fsub fast float %3683, %4692
  %4702 = fsub fast float %3684, %4693
  %4703 = fsub fast float %3685, %4694
  %4704 = call float @dx.op.dot3.f32(i32 55, float %4701, float %4702, float %4703, float %4698, float %4699, float %4700)  ; Dot3(ax,ay,az,bx,by,bz)
  %4705 = fcmp fast ogt float %4704, 0.000000e+00
  br i1 %4705, label %4706, label %4717

; <label>:4706                                    ; preds = %4674
  %4707 = fsub fast float %4692, %4695
  %4708 = fsub fast float %4693, %4696
  %4709 = fsub fast float %4694, %4697
  %4710 = call float @dx.op.unary.f32(i32 6, float %4707)  ; FAbs(value)
  %4711 = call float @dx.op.unary.f32(i32 6, float %4708)  ; FAbs(value)
  %4712 = call float @dx.op.unary.f32(i32 6, float %4709)  ; FAbs(value)
  %4713 = call float @dx.op.binary.f32(i32 35, float %4711, float %4712)  ; FMax(a,b)
  %4714 = call float @dx.op.binary.f32(i32 35, float %4710, float %4713)  ; FMax(a,b)
  %4715 = fmul fast float %4668, 2.500000e-01
  %4716 = fcmp fast olt float %4714, %4715
  br label %4717

; <label>:4717                                    ; preds = %4706, %4674
  %4718 = phi i1 [ false, %4674 ], [ %4716, %4706 ]
  %4719 = select i1 %4718, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  %4720 = fadd fast float %4692, %4695
  %4721 = fadd fast float %4693, %4696
  %4722 = fadd fast float %4694, %4697
  %4723 = fmul fast float %4720, 5.000000e-01
  %4724 = fmul fast float %4721, 5.000000e-01
  %4725 = fmul fast float %4722, 5.000000e-01
  %4726 = fsub fast float %4723, %3683
  %4727 = fsub fast float %4724, %3684
  %4728 = fsub fast float %4725, %3685
  %4729 = fmul fast float %4719, %4726
  %4730 = fmul fast float %4719, %4727
  %4731 = fmul fast float %4719, %4728
  %4732 = fadd fast float %4729, %3683
  %4733 = fadd fast float %4730, %3684
  %4734 = fadd fast float %4731, %3685
  br label %4735

; <label>:4735                                    ; preds = %4717, %4633, %3490
  %4736 = phi float [ %3521, %3490 ], [ %4732, %4717 ], [ %3683, %4633 ]
  %4737 = phi float [ %3522, %3490 ], [ %4733, %4717 ], [ %3684, %4633 ]
  %4738 = phi float [ %3523, %3490 ], [ %4734, %4717 ], [ %3685, %4633 ]
  %4739 = phi float [ %3524, %3490 ], [ %3488, %4717 ], [ %3488, %4633 ]
  %4740 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %67, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4741 = extractvalue %dx.types.ResRet.f32 %4740, 0
  %4742 = extractvalue %dx.types.ResRet.f32 %4740, 1
  %4743 = extractvalue %dx.types.ResRet.f32 %4740, 2
  %4744 = extractvalue %dx.types.ResRet.f32 %4740, 3
  %4745 = fcmp fast olt float %4744, 0.000000e+00
  br i1 %4745, label %4746, label %4781

; <label>:4746                                    ; preds = %4735
  %4747 = fcmp fast ogt float %4741, 0x3FA4B5DCC0000000
  %4748 = fcmp fast ogt float %4742, 0x3FA4B5DCC0000000
  %4749 = fcmp fast ogt float %4743, 0x3FA4B5DCC0000000
  %4750 = select i1 %4747, float 0.000000e+00, float 1.000000e+00
  %4751 = select i1 %4748, float 0.000000e+00, float 1.000000e+00
  %4752 = select i1 %4749, float 0.000000e+00, float 1.000000e+00
  %4753 = fmul fast float %4741, 0x3FB3D07220000000
  %4754 = fmul fast float %4742, 0x3FB3D07220000000
  %4755 = fmul fast float %4743, 0x3FB3D07220000000
  %4756 = fadd fast float %4741, 0x3FAC28F5C0000000
  %4757 = fadd fast float %4742, 0x3FAC28F5C0000000
  %4758 = fadd fast float %4743, 0x3FAC28F5C0000000
  %4759 = fmul fast float %4756, 0x3FEE54EDE0000000
  %4760 = fmul fast float %4757, 0x3FEE54EDE0000000
  %4761 = fmul fast float %4758, 0x3FEE54EDE0000000
  %4762 = call float @dx.op.unary.f32(i32 23, float %4759)  ; Log(value)
  %4763 = call float @dx.op.unary.f32(i32 23, float %4760)  ; Log(value)
  %4764 = call float @dx.op.unary.f32(i32 23, float %4761)  ; Log(value)
  %4765 = fmul fast float %4762, 0x4003333340000000
  %4766 = fmul fast float %4763, 0x4003333340000000
  %4767 = fmul fast float %4764, 0x4003333340000000
  %4768 = call float @dx.op.unary.f32(i32 21, float %4765)  ; Exp(value)
  %4769 = call float @dx.op.unary.f32(i32 21, float %4766)  ; Exp(value)
  %4770 = call float @dx.op.unary.f32(i32 21, float %4767)  ; Exp(value)
  %4771 = fsub fast float %4753, %4768
  %4772 = fsub fast float %4754, %4769
  %4773 = fsub fast float %4755, %4770
  %4774 = fmul fast float %4771, %4750
  %4775 = fmul fast float %4772, %4751
  %4776 = fmul fast float %4773, %4752
  %4777 = fadd fast float %4774, %4768
  %4778 = fadd fast float %4775, %4769
  %4779 = fadd fast float %4776, %4770
  %4780 = fsub fast float -1.000000e+00, %4744
  br label %5991

; <label>:4781                                    ; preds = %4735
  %4782 = fcmp fast ogt float %38, 5.000000e-01
  %4783 = fcmp fast olt float %84, 1.000000e+00
  %4784 = and i1 %4782, %4783
  br i1 %4784, label %4785, label %4871

; <label>:4785                                    ; preds = %4781
  %4786 = sitofp i32 %67 to float
  %4787 = sitofp i32 %64 to float
  %4788 = fadd fast float %4786, 5.000000e-01
  %4789 = fadd fast float %4787, 5.000000e-01
  %4790 = fdiv fast float %4788, %45
  %4791 = fdiv fast float %4789, %46
  %4792 = fmul fast float %4790, 2.000000e+00
  %4793 = fmul fast float %4791, 2.000000e+00
  %4794 = fadd fast float %4792, -1.000000e+00
  %4795 = fsub fast float 1.000000e+00, %4793
  %4796 = fmul fast float %4794, %35
  %4797 = call float @dx.op.tertiary.f32(i32 46, float %4795, float %31, float %4796)  ; FMad(a,b,c)
  %4798 = call float @dx.op.tertiary.f32(i32 46, float %84, float %27, float %4797)  ; FMad(a,b,c)
  %4799 = fadd fast float %4798, %23
  %4800 = call float @dx.op.unary.f32(i32 6, float %4799)  ; FAbs(value)
  %4801 = fcmp fast ogt float %4800, 0x3EB0C6F7A0000000
  br i1 %4801, label %4802, label %4871

; <label>:4802                                    ; preds = %4785
  %4803 = fmul fast float %4794, %34
  %4804 = call float @dx.op.tertiary.f32(i32 46, float %4795, float %30, float %4803)  ; FMad(a,b,c)
  %4805 = call float @dx.op.tertiary.f32(i32 46, float %84, float %26, float %4804)  ; FMad(a,b,c)
  %4806 = fadd fast float %4805, %22
  %4807 = fmul fast float %4794, %33
  %4808 = call float @dx.op.tertiary.f32(i32 46, float %4795, float %29, float %4807)  ; FMad(a,b,c)
  %4809 = call float @dx.op.tertiary.f32(i32 46, float %84, float %25, float %4808)  ; FMad(a,b,c)
  %4810 = fadd fast float %4809, %21
  %4811 = fmul fast float %4794, %32
  %4812 = call float @dx.op.tertiary.f32(i32 46, float %4795, float %28, float %4811)  ; FMad(a,b,c)
  %4813 = call float @dx.op.tertiary.f32(i32 46, float %84, float %24, float %4812)  ; FMad(a,b,c)
  %4814 = fadd fast float %4813, %20
  %4815 = fdiv fast float %4814, %4799
  %4816 = fdiv fast float %4810, %4799
  %4817 = fdiv fast float %4806, %4799
  %4818 = fsub fast float %4815, %17
  %4819 = fsub fast float %4816, %18
  %4820 = fsub fast float %4817, %19
  %4821 = fmul fast float %4818, %4818
  %4822 = fmul fast float %4819, %4819
  %4823 = fadd fast float %4822, %4821
  %4824 = fmul fast float %4820, %4820
  %4825 = fadd fast float %4823, %4824
  %4826 = call float @dx.op.unary.f32(i32 24, float %4825)  ; Sqrt(value)
  %4827 = fsub fast float %4826, %9
  %4828 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4827)  ; FMax(a,b)
  %4829 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %4829, label %4830, label %4853

; <label>:4830                                    ; preds = %4802
  %4831 = call float @dx.op.unary.f32(i32 6, float %4819)  ; FAbs(value)
  %4832 = fmul fast float %4831, %11
  %4833 = fcmp fast olt float %4832, 0x3F50624DE0000000
  br i1 %4833, label %4834, label %4837

; <label>:4834                                    ; preds = %4830
  %4835 = fmul fast float %4832, 5.000000e-01
  %4836 = fsub fast float 1.000000e+00, %4835
  br label %4842

; <label>:4837                                    ; preds = %4830
  %4838 = fmul fast float %4832, 0xBFF7154760000000
  %4839 = call float @dx.op.unary.f32(i32 21, float %4838)  ; Exp(value)
  %4840 = fsub fast float 1.000000e+00, %4839
  %4841 = fdiv fast float %4840, %4832
  br label %4842

; <label>:4842                                    ; preds = %4837, %4834
  %4843 = phi float [ %4836, %4834 ], [ %4841, %4837 ]
  %4844 = call float @dx.op.binary.f32(i32 36, float %4816, float %18)  ; FMin(a,b)
  %4845 = fsub fast float %4844, %10
  %4846 = fmul fast float %11, %4845
  %4847 = fsub fast float -0.000000e+00, %4846
  %4848 = call float @dx.op.binary.f32(i32 35, float %4847, float -4.000000e+01)  ; FMax(a,b)
  %4849 = call float @dx.op.binary.f32(i32 36, float %4848, float 5.000000e+00)  ; FMin(a,b)
  %4850 = fmul fast float %4849, 0x3FF7154760000000
  %4851 = call float @dx.op.unary.f32(i32 21, float %4850)  ; Exp(value)
  %4852 = fmul fast float %4851, %4843
  br label %4853

; <label>:4853                                    ; preds = %4842, %4802
  %4854 = phi float [ %4852, %4842 ], [ 1.000000e+00, %4802 ]
  %4855 = fmul fast float %4828, %16
  %4856 = fmul fast float %4855, %4854
  %4857 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4856)  ; FMin(a,b)
  %4858 = fmul fast float %4857, 0xBFF7154760000000
  %4859 = call float @dx.op.unary.f32(i32 21, float %4858)  ; Exp(value)
  %4860 = fsub fast float 1.000000e+00, %4859
  %4861 = call float @dx.op.binary.f32(i32 36, float %12, float %4860)  ; FMin(a,b)
  %4862 = fsub fast float %13, %4741
  %4863 = fsub fast float %14, %4742
  %4864 = fsub fast float %15, %4743
  %4865 = fmul fast float %4861, %4862
  %4866 = fmul fast float %4861, %4863
  %4867 = fmul fast float %4861, %4864
  %4868 = fadd fast float %4865, %4741
  %4869 = fadd fast float %4866, %4742
  %4870 = fadd fast float %4867, %4743
  br label %4871

; <label>:4871                                    ; preds = %4853, %4785, %4781
  %4872 = phi float [ %4868, %4853 ], [ %4741, %4785 ], [ %4741, %4781 ]
  %4873 = phi float [ %4869, %4853 ], [ %4742, %4785 ], [ %4742, %4781 ]
  %4874 = phi float [ %4870, %4853 ], [ %4743, %4785 ], [ %4743, %4781 ]
  %4875 = fadd fast float %5, 1.000000e+00
  %4876 = fadd fast float %6, 1.000000e+00
  %4877 = fsub fast float 1.000000e+00, %5
  %4878 = fmul fast float %36, %4875
  %4879 = fmul fast float %36, %4876
  %4880 = fmul fast float %36, %4877
  %4881 = fmul fast float %4878, %4872
  %4882 = fmul fast float %4879, %4873
  %4883 = fmul fast float %4880, %4874
  %4884 = fcmp fast ult float %37, 5.000000e-01
  br i1 %4884, label %4910, label %4885

; <label>:4885                                    ; preds = %4871
  %4886 = fmul fast float %4881, 0x4004147AE0000000
  %4887 = fmul fast float %4882, 0x4004147AE0000000
  %4888 = fmul fast float %4883, 0x4004147AE0000000
  %4889 = fadd fast float %4886, 0x3F9EB851E0000000
  %4890 = fadd fast float %4887, 0x3F9EB851E0000000
  %4891 = fadd fast float %4888, 0x3F9EB851E0000000
  %4892 = fmul fast float %4889, %4881
  %4893 = fmul fast float %4890, %4882
  %4894 = fmul fast float %4891, %4883
  %4895 = fmul fast float %4881, 0x400370A3E0000000
  %4896 = fmul fast float %4882, 0x400370A3E0000000
  %4897 = fmul fast float %4883, 0x400370A3E0000000
  %4898 = fadd fast float %4895, 0x3FE2E147A0000000
  %4899 = fadd fast float %4896, 0x3FE2E147A0000000
  %4900 = fadd fast float %4897, 0x3FE2E147A0000000
  %4901 = fmul fast float %4898, %4881
  %4902 = fmul fast float %4899, %4882
  %4903 = fmul fast float %4900, %4883
  %4904 = fadd fast float %4901, 0x3FC1EB8520000000
  %4905 = fadd fast float %4902, 0x3FC1EB8520000000
  %4906 = fadd fast float %4903, 0x3FC1EB8520000000
  %4907 = fdiv fast float %4892, %4904
  %4908 = fdiv fast float %4893, %4905
  %4909 = fdiv fast float %4894, %4906
  br label %4910

; <label>:4910                                    ; preds = %4885, %4871
  %4911 = phi float [ %4907, %4885 ], [ %4881, %4871 ]
  %4912 = phi float [ %4908, %4885 ], [ %4882, %4871 ]
  %4913 = phi float [ %4909, %4885 ], [ %4883, %4871 ]
  %4914 = call float @dx.op.unary.f32(i32 7, float %4911)  ; Saturate(value)
  %4915 = call float @dx.op.unary.f32(i32 7, float %4912)  ; Saturate(value)
  %4916 = call float @dx.op.unary.f32(i32 7, float %4913)  ; Saturate(value)
  %4917 = call float @dx.op.dot3.f32(i32 55, float %4914, float %4915, float %4916, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4918 = fsub fast float %4914, %4917
  %4919 = fsub fast float %4915, %4917
  %4920 = fsub fast float %4916, %4917
  %4921 = fmul fast float %4918, %8
  %4922 = fmul fast float %4919, %8
  %4923 = fmul fast float %4920, %8
  %4924 = fadd fast float %4921, %4917
  %4925 = fadd fast float %4922, %4917
  %4926 = fadd fast float %4923, %4917
  %4927 = call float @dx.op.unary.f32(i32 7, float %4924)  ; Saturate(value)
  %4928 = call float @dx.op.unary.f32(i32 7, float %4925)  ; Saturate(value)
  %4929 = call float @dx.op.unary.f32(i32 7, float %4926)  ; Saturate(value)
  %4930 = fadd fast float %4927, 0xBFC70A3D80000000
  %4931 = fadd fast float %4928, 0xBFC70A3D80000000
  %4932 = fadd fast float %4929, 0xBFC70A3D80000000
  %4933 = fmul fast float %4930, %7
  %4934 = fmul fast float %4931, %7
  %4935 = fmul fast float %4932, %7
  %4936 = fadd fast float %4933, 0x3FC70A3D80000000
  %4937 = fadd fast float %4934, 0x3FC70A3D80000000
  %4938 = fadd fast float %4935, 0x3FC70A3D80000000
  %4939 = call float @dx.op.unary.f32(i32 7, float %4936)  ; Saturate(value)
  %4940 = call float @dx.op.unary.f32(i32 7, float %4937)  ; Saturate(value)
  %4941 = call float @dx.op.unary.f32(i32 7, float %4938)  ; Saturate(value)
  %4942 = add i32 %64, -1
  %4943 = call i32 @dx.op.binary.i32(i32 37, i32 %67, i32 0)  ; IMax(a,b)
  %4944 = call i32 @dx.op.binary.i32(i32 37, i32 %4942, i32 0)  ; IMax(a,b)
  %4945 = call i32 @dx.op.binary.i32(i32 38, i32 %4943, i32 %59)  ; IMin(a,b)
  %4946 = call i32 @dx.op.binary.i32(i32 38, i32 %4944, i32 %60)  ; IMin(a,b)
  %4947 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4945, i32 %4946, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4948 = extractvalue %dx.types.ResRet.f32 %4947, 0
  %4949 = fsub fast float 1.000000e+00, %84
  %4950 = fmul fast float %4949, 0x3FA99999A0000000
  %4951 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %4950)  ; FMax(a,b)
  %4952 = fsub fast float %4948, %84
  %4953 = call float @dx.op.unary.f32(i32 6, float %4952)  ; FAbs(value)
  %4954 = fdiv fast float %4953, %4951
  %4955 = fsub fast float 1.000000e+00, %4954
  %4956 = call float @dx.op.unary.f32(i32 7, float %4955)  ; Saturate(value)
  %4957 = fcmp fast ugt float %4956, 0.000000e+00
  br i1 %4957, label %4958, label %5179

; <label>:4958                                    ; preds = %4910
  %4959 = call i32 @dx.op.binary.i32(i32 37, i32 %4945, i32 0)  ; IMax(a,b)
  %4960 = call i32 @dx.op.binary.i32(i32 37, i32 %4946, i32 0)  ; IMax(a,b)
  %4961 = call i32 @dx.op.binary.i32(i32 38, i32 %4959, i32 %59)  ; IMin(a,b)
  %4962 = call i32 @dx.op.binary.i32(i32 38, i32 %4960, i32 %60)  ; IMin(a,b)
  %4963 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4961, i32 %4962, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4964 = extractvalue %dx.types.ResRet.f32 %4963, 0
  %4965 = extractvalue %dx.types.ResRet.f32 %4963, 1
  %4966 = extractvalue %dx.types.ResRet.f32 %4963, 2
  %4967 = extractvalue %dx.types.ResRet.f32 %4963, 3
  %4968 = fcmp fast olt float %4967, 0.000000e+00
  br i1 %4968, label %4969, label %5003

; <label>:4969                                    ; preds = %4958
  %4970 = fcmp fast ogt float %4964, 0x3FA4B5DCC0000000
  %4971 = fcmp fast ogt float %4965, 0x3FA4B5DCC0000000
  %4972 = fcmp fast ogt float %4966, 0x3FA4B5DCC0000000
  %4973 = select i1 %4970, float 0.000000e+00, float 1.000000e+00
  %4974 = select i1 %4971, float 0.000000e+00, float 1.000000e+00
  %4975 = select i1 %4972, float 0.000000e+00, float 1.000000e+00
  %4976 = fmul fast float %4964, 0x3FB3D07220000000
  %4977 = fmul fast float %4965, 0x3FB3D07220000000
  %4978 = fmul fast float %4966, 0x3FB3D07220000000
  %4979 = fadd fast float %4964, 0x3FAC28F5C0000000
  %4980 = fadd fast float %4965, 0x3FAC28F5C0000000
  %4981 = fadd fast float %4966, 0x3FAC28F5C0000000
  %4982 = fmul fast float %4979, 0x3FEE54EDE0000000
  %4983 = fmul fast float %4980, 0x3FEE54EDE0000000
  %4984 = fmul fast float %4981, 0x3FEE54EDE0000000
  %4985 = call float @dx.op.unary.f32(i32 23, float %4982)  ; Log(value)
  %4986 = call float @dx.op.unary.f32(i32 23, float %4983)  ; Log(value)
  %4987 = call float @dx.op.unary.f32(i32 23, float %4984)  ; Log(value)
  %4988 = fmul fast float %4985, 0x4003333340000000
  %4989 = fmul fast float %4986, 0x4003333340000000
  %4990 = fmul fast float %4987, 0x4003333340000000
  %4991 = call float @dx.op.unary.f32(i32 21, float %4988)  ; Exp(value)
  %4992 = call float @dx.op.unary.f32(i32 21, float %4989)  ; Exp(value)
  %4993 = call float @dx.op.unary.f32(i32 21, float %4990)  ; Exp(value)
  %4994 = fsub fast float %4976, %4991
  %4995 = fsub fast float %4977, %4992
  %4996 = fsub fast float %4978, %4993
  %4997 = fmul fast float %4994, %4973
  %4998 = fmul fast float %4995, %4974
  %4999 = fmul fast float %4996, %4975
  %5000 = fadd fast float %4997, %4991
  %5001 = fadd fast float %4998, %4992
  %5002 = fadd fast float %4999, %4993
  br label %5166

; <label>:5003                                    ; preds = %4958
  %5004 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4961, i32 %4962, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5005 = extractvalue %dx.types.ResRet.f32 %5004, 0
  %5006 = fcmp fast ogt float %38, 5.000000e-01
  %5007 = fcmp fast olt float %5005, 1.000000e+00
  %5008 = and i1 %5006, %5007
  br i1 %5008, label %5009, label %5095

; <label>:5009                                    ; preds = %5003
  %5010 = sitofp i32 %4961 to float
  %5011 = sitofp i32 %4962 to float
  %5012 = fadd fast float %5010, 5.000000e-01
  %5013 = fadd fast float %5011, 5.000000e-01
  %5014 = fdiv fast float %5012, %45
  %5015 = fdiv fast float %5013, %46
  %5016 = fmul fast float %5014, 2.000000e+00
  %5017 = fmul fast float %5015, 2.000000e+00
  %5018 = fadd fast float %5016, -1.000000e+00
  %5019 = fsub fast float 1.000000e+00, %5017
  %5020 = fmul fast float %5018, %35
  %5021 = call float @dx.op.tertiary.f32(i32 46, float %5019, float %31, float %5020)  ; FMad(a,b,c)
  %5022 = call float @dx.op.tertiary.f32(i32 46, float %5005, float %27, float %5021)  ; FMad(a,b,c)
  %5023 = fadd fast float %5022, %23
  %5024 = call float @dx.op.unary.f32(i32 6, float %5023)  ; FAbs(value)
  %5025 = fcmp fast ogt float %5024, 0x3EB0C6F7A0000000
  br i1 %5025, label %5026, label %5095

; <label>:5026                                    ; preds = %5009
  %5027 = fmul fast float %5018, %34
  %5028 = call float @dx.op.tertiary.f32(i32 46, float %5019, float %30, float %5027)  ; FMad(a,b,c)
  %5029 = call float @dx.op.tertiary.f32(i32 46, float %5005, float %26, float %5028)  ; FMad(a,b,c)
  %5030 = fadd fast float %5029, %22
  %5031 = fmul fast float %5018, %33
  %5032 = call float @dx.op.tertiary.f32(i32 46, float %5019, float %29, float %5031)  ; FMad(a,b,c)
  %5033 = call float @dx.op.tertiary.f32(i32 46, float %5005, float %25, float %5032)  ; FMad(a,b,c)
  %5034 = fadd fast float %5033, %21
  %5035 = fmul fast float %5018, %32
  %5036 = call float @dx.op.tertiary.f32(i32 46, float %5019, float %28, float %5035)  ; FMad(a,b,c)
  %5037 = call float @dx.op.tertiary.f32(i32 46, float %5005, float %24, float %5036)  ; FMad(a,b,c)
  %5038 = fadd fast float %5037, %20
  %5039 = fdiv fast float %5038, %5023
  %5040 = fdiv fast float %5034, %5023
  %5041 = fdiv fast float %5030, %5023
  %5042 = fsub fast float %5039, %17
  %5043 = fsub fast float %5040, %18
  %5044 = fsub fast float %5041, %19
  %5045 = fmul fast float %5042, %5042
  %5046 = fmul fast float %5043, %5043
  %5047 = fadd fast float %5046, %5045
  %5048 = fmul fast float %5044, %5044
  %5049 = fadd fast float %5047, %5048
  %5050 = call float @dx.op.unary.f32(i32 24, float %5049)  ; Sqrt(value)
  %5051 = fsub fast float %5050, %9
  %5052 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5051)  ; FMax(a,b)
  %5053 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %5053, label %5054, label %5077

; <label>:5054                                    ; preds = %5026
  %5055 = call float @dx.op.unary.f32(i32 6, float %5043)  ; FAbs(value)
  %5056 = fmul fast float %5055, %11
  %5057 = fcmp fast olt float %5056, 0x3F50624DE0000000
  br i1 %5057, label %5058, label %5061

; <label>:5058                                    ; preds = %5054
  %5059 = fmul fast float %5056, 5.000000e-01
  %5060 = fsub fast float 1.000000e+00, %5059
  br label %5066

; <label>:5061                                    ; preds = %5054
  %5062 = fmul fast float %5056, 0xBFF7154760000000
  %5063 = call float @dx.op.unary.f32(i32 21, float %5062)  ; Exp(value)
  %5064 = fsub fast float 1.000000e+00, %5063
  %5065 = fdiv fast float %5064, %5056
  br label %5066

; <label>:5066                                    ; preds = %5061, %5058
  %5067 = phi float [ %5060, %5058 ], [ %5065, %5061 ]
  %5068 = call float @dx.op.binary.f32(i32 36, float %5040, float %18)  ; FMin(a,b)
  %5069 = fsub fast float %5068, %10
  %5070 = fmul fast float %11, %5069
  %5071 = fsub fast float -0.000000e+00, %5070
  %5072 = call float @dx.op.binary.f32(i32 35, float %5071, float -4.000000e+01)  ; FMax(a,b)
  %5073 = call float @dx.op.binary.f32(i32 36, float %5072, float 5.000000e+00)  ; FMin(a,b)
  %5074 = fmul fast float %5073, 0x3FF7154760000000
  %5075 = call float @dx.op.unary.f32(i32 21, float %5074)  ; Exp(value)
  %5076 = fmul fast float %5075, %5067
  br label %5077

; <label>:5077                                    ; preds = %5066, %5026
  %5078 = phi float [ %5076, %5066 ], [ 1.000000e+00, %5026 ]
  %5079 = fmul fast float %5052, %16
  %5080 = fmul fast float %5079, %5078
  %5081 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %5080)  ; FMin(a,b)
  %5082 = fmul fast float %5081, 0xBFF7154760000000
  %5083 = call float @dx.op.unary.f32(i32 21, float %5082)  ; Exp(value)
  %5084 = fsub fast float 1.000000e+00, %5083
  %5085 = call float @dx.op.binary.f32(i32 36, float %12, float %5084)  ; FMin(a,b)
  %5086 = fsub fast float %13, %4964
  %5087 = fsub fast float %14, %4965
  %5088 = fsub fast float %15, %4966
  %5089 = fmul fast float %5085, %5086
  %5090 = fmul fast float %5085, %5087
  %5091 = fmul fast float %5085, %5088
  %5092 = fadd fast float %5089, %4964
  %5093 = fadd fast float %5090, %4965
  %5094 = fadd fast float %5091, %4966
  br label %5095

; <label>:5095                                    ; preds = %5077, %5009, %5003
  %5096 = phi float [ %5092, %5077 ], [ %4964, %5009 ], [ %4964, %5003 ]
  %5097 = phi float [ %5093, %5077 ], [ %4965, %5009 ], [ %4965, %5003 ]
  %5098 = phi float [ %5094, %5077 ], [ %4966, %5009 ], [ %4966, %5003 ]
  %5099 = fadd fast float %5, 1.000000e+00
  %5100 = fadd fast float %6, 1.000000e+00
  %5101 = fsub fast float 1.000000e+00, %5
  %5102 = fmul fast float %36, %5099
  %5103 = fmul fast float %36, %5100
  %5104 = fmul fast float %36, %5101
  %5105 = fmul fast float %5102, %5096
  %5106 = fmul fast float %5103, %5097
  %5107 = fmul fast float %5104, %5098
  %5108 = fcmp fast ult float %37, 5.000000e-01
  br i1 %5108, label %5134, label %5109

; <label>:5109                                    ; preds = %5095
  %5110 = fmul fast float %5105, 0x4004147AE0000000
  %5111 = fmul fast float %5106, 0x4004147AE0000000
  %5112 = fmul fast float %5107, 0x4004147AE0000000
  %5113 = fadd fast float %5110, 0x3F9EB851E0000000
  %5114 = fadd fast float %5111, 0x3F9EB851E0000000
  %5115 = fadd fast float %5112, 0x3F9EB851E0000000
  %5116 = fmul fast float %5113, %5105
  %5117 = fmul fast float %5114, %5106
  %5118 = fmul fast float %5115, %5107
  %5119 = fmul fast float %5105, 0x400370A3E0000000
  %5120 = fmul fast float %5106, 0x400370A3E0000000
  %5121 = fmul fast float %5107, 0x400370A3E0000000
  %5122 = fadd fast float %5119, 0x3FE2E147A0000000
  %5123 = fadd fast float %5120, 0x3FE2E147A0000000
  %5124 = fadd fast float %5121, 0x3FE2E147A0000000
  %5125 = fmul fast float %5122, %5105
  %5126 = fmul fast float %5123, %5106
  %5127 = fmul fast float %5124, %5107
  %5128 = fadd fast float %5125, 0x3FC1EB8520000000
  %5129 = fadd fast float %5126, 0x3FC1EB8520000000
  %5130 = fadd fast float %5127, 0x3FC1EB8520000000
  %5131 = fdiv fast float %5116, %5128
  %5132 = fdiv fast float %5117, %5129
  %5133 = fdiv fast float %5118, %5130
  br label %5134

; <label>:5134                                    ; preds = %5109, %5095
  %5135 = phi float [ %5131, %5109 ], [ %5105, %5095 ]
  %5136 = phi float [ %5132, %5109 ], [ %5106, %5095 ]
  %5137 = phi float [ %5133, %5109 ], [ %5107, %5095 ]
  %5138 = call float @dx.op.unary.f32(i32 7, float %5135)  ; Saturate(value)
  %5139 = call float @dx.op.unary.f32(i32 7, float %5136)  ; Saturate(value)
  %5140 = call float @dx.op.unary.f32(i32 7, float %5137)  ; Saturate(value)
  %5141 = call float @dx.op.dot3.f32(i32 55, float %5138, float %5139, float %5140, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5142 = fsub fast float %5138, %5141
  %5143 = fsub fast float %5139, %5141
  %5144 = fsub fast float %5140, %5141
  %5145 = fmul fast float %5142, %8
  %5146 = fmul fast float %5143, %8
  %5147 = fmul fast float %5144, %8
  %5148 = fadd fast float %5145, %5141
  %5149 = fadd fast float %5146, %5141
  %5150 = fadd fast float %5147, %5141
  %5151 = call float @dx.op.unary.f32(i32 7, float %5148)  ; Saturate(value)
  %5152 = call float @dx.op.unary.f32(i32 7, float %5149)  ; Saturate(value)
  %5153 = call float @dx.op.unary.f32(i32 7, float %5150)  ; Saturate(value)
  %5154 = fadd fast float %5151, 0xBFC70A3D80000000
  %5155 = fadd fast float %5152, 0xBFC70A3D80000000
  %5156 = fadd fast float %5153, 0xBFC70A3D80000000
  %5157 = fmul fast float %5154, %7
  %5158 = fmul fast float %5155, %7
  %5159 = fmul fast float %5156, %7
  %5160 = fadd fast float %5157, 0x3FC70A3D80000000
  %5161 = fadd fast float %5158, 0x3FC70A3D80000000
  %5162 = fadd fast float %5159, 0x3FC70A3D80000000
  %5163 = call float @dx.op.unary.f32(i32 7, float %5160)  ; Saturate(value)
  %5164 = call float @dx.op.unary.f32(i32 7, float %5161)  ; Saturate(value)
  %5165 = call float @dx.op.unary.f32(i32 7, float %5162)  ; Saturate(value)
  br label %5166

; <label>:5166                                    ; preds = %5134, %4969
  %5167 = phi float [ %5000, %4969 ], [ %5163, %5134 ]
  %5168 = phi float [ %5001, %4969 ], [ %5164, %5134 ]
  %5169 = phi float [ %5002, %4969 ], [ %5165, %5134 ]
  %5170 = fsub fast float %5167, %4939
  %5171 = fsub fast float %5168, %4940
  %5172 = fsub fast float %5169, %4941
  %5173 = fmul fast float %5170, %4956
  %5174 = fmul fast float %5171, %4956
  %5175 = fmul fast float %5172, %4956
  %5176 = fadd fast float %5173, %4939
  %5177 = fadd fast float %5174, %4940
  %5178 = fadd fast float %5175, %4941
  br label %5179

; <label>:5179                                    ; preds = %5166, %4910
  %5180 = phi float [ %5176, %5166 ], [ %4939, %4910 ]
  %5181 = phi float [ %5177, %5166 ], [ %4940, %4910 ]
  %5182 = phi float [ %5178, %5166 ], [ %4941, %4910 ]
  %5183 = add i32 %64, 1
  %5184 = call i32 @dx.op.binary.i32(i32 37, i32 %5183, i32 0)  ; IMax(a,b)
  %5185 = call i32 @dx.op.binary.i32(i32 38, i32 %5184, i32 %60)  ; IMin(a,b)
  %5186 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4945, i32 %5185, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5187 = extractvalue %dx.types.ResRet.f32 %5186, 0
  %5188 = fsub fast float %5187, %84
  %5189 = call float @dx.op.unary.f32(i32 6, float %5188)  ; FAbs(value)
  %5190 = fdiv fast float %5189, %4951
  %5191 = fsub fast float 1.000000e+00, %5190
  %5192 = call float @dx.op.unary.f32(i32 7, float %5191)  ; Saturate(value)
  %5193 = fcmp fast ugt float %5192, 0.000000e+00
  br i1 %5193, label %5194, label %5415

; <label>:5194                                    ; preds = %5179
  %5195 = call i32 @dx.op.binary.i32(i32 37, i32 %4945, i32 0)  ; IMax(a,b)
  %5196 = call i32 @dx.op.binary.i32(i32 37, i32 %5185, i32 0)  ; IMax(a,b)
  %5197 = call i32 @dx.op.binary.i32(i32 38, i32 %5195, i32 %59)  ; IMin(a,b)
  %5198 = call i32 @dx.op.binary.i32(i32 38, i32 %5196, i32 %60)  ; IMin(a,b)
  %5199 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %5197, i32 %5198, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5200 = extractvalue %dx.types.ResRet.f32 %5199, 0
  %5201 = extractvalue %dx.types.ResRet.f32 %5199, 1
  %5202 = extractvalue %dx.types.ResRet.f32 %5199, 2
  %5203 = extractvalue %dx.types.ResRet.f32 %5199, 3
  %5204 = fcmp fast olt float %5203, 0.000000e+00
  br i1 %5204, label %5205, label %5239

; <label>:5205                                    ; preds = %5194
  %5206 = fcmp fast ogt float %5200, 0x3FA4B5DCC0000000
  %5207 = fcmp fast ogt float %5201, 0x3FA4B5DCC0000000
  %5208 = fcmp fast ogt float %5202, 0x3FA4B5DCC0000000
  %5209 = select i1 %5206, float 0.000000e+00, float 1.000000e+00
  %5210 = select i1 %5207, float 0.000000e+00, float 1.000000e+00
  %5211 = select i1 %5208, float 0.000000e+00, float 1.000000e+00
  %5212 = fmul fast float %5200, 0x3FB3D07220000000
  %5213 = fmul fast float %5201, 0x3FB3D07220000000
  %5214 = fmul fast float %5202, 0x3FB3D07220000000
  %5215 = fadd fast float %5200, 0x3FAC28F5C0000000
  %5216 = fadd fast float %5201, 0x3FAC28F5C0000000
  %5217 = fadd fast float %5202, 0x3FAC28F5C0000000
  %5218 = fmul fast float %5215, 0x3FEE54EDE0000000
  %5219 = fmul fast float %5216, 0x3FEE54EDE0000000
  %5220 = fmul fast float %5217, 0x3FEE54EDE0000000
  %5221 = call float @dx.op.unary.f32(i32 23, float %5218)  ; Log(value)
  %5222 = call float @dx.op.unary.f32(i32 23, float %5219)  ; Log(value)
  %5223 = call float @dx.op.unary.f32(i32 23, float %5220)  ; Log(value)
  %5224 = fmul fast float %5221, 0x4003333340000000
  %5225 = fmul fast float %5222, 0x4003333340000000
  %5226 = fmul fast float %5223, 0x4003333340000000
  %5227 = call float @dx.op.unary.f32(i32 21, float %5224)  ; Exp(value)
  %5228 = call float @dx.op.unary.f32(i32 21, float %5225)  ; Exp(value)
  %5229 = call float @dx.op.unary.f32(i32 21, float %5226)  ; Exp(value)
  %5230 = fsub fast float %5212, %5227
  %5231 = fsub fast float %5213, %5228
  %5232 = fsub fast float %5214, %5229
  %5233 = fmul fast float %5230, %5209
  %5234 = fmul fast float %5231, %5210
  %5235 = fmul fast float %5232, %5211
  %5236 = fadd fast float %5233, %5227
  %5237 = fadd fast float %5234, %5228
  %5238 = fadd fast float %5235, %5229
  br label %5402

; <label>:5239                                    ; preds = %5194
  %5240 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5197, i32 %5198, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5241 = extractvalue %dx.types.ResRet.f32 %5240, 0
  %5242 = fcmp fast ogt float %38, 5.000000e-01
  %5243 = fcmp fast olt float %5241, 1.000000e+00
  %5244 = and i1 %5242, %5243
  br i1 %5244, label %5245, label %5331

; <label>:5245                                    ; preds = %5239
  %5246 = sitofp i32 %5197 to float
  %5247 = sitofp i32 %5198 to float
  %5248 = fadd fast float %5246, 5.000000e-01
  %5249 = fadd fast float %5247, 5.000000e-01
  %5250 = fdiv fast float %5248, %45
  %5251 = fdiv fast float %5249, %46
  %5252 = fmul fast float %5250, 2.000000e+00
  %5253 = fmul fast float %5251, 2.000000e+00
  %5254 = fadd fast float %5252, -1.000000e+00
  %5255 = fsub fast float 1.000000e+00, %5253
  %5256 = fmul fast float %5254, %35
  %5257 = call float @dx.op.tertiary.f32(i32 46, float %5255, float %31, float %5256)  ; FMad(a,b,c)
  %5258 = call float @dx.op.tertiary.f32(i32 46, float %5241, float %27, float %5257)  ; FMad(a,b,c)
  %5259 = fadd fast float %5258, %23
  %5260 = call float @dx.op.unary.f32(i32 6, float %5259)  ; FAbs(value)
  %5261 = fcmp fast ogt float %5260, 0x3EB0C6F7A0000000
  br i1 %5261, label %5262, label %5331

; <label>:5262                                    ; preds = %5245
  %5263 = fmul fast float %5254, %34
  %5264 = call float @dx.op.tertiary.f32(i32 46, float %5255, float %30, float %5263)  ; FMad(a,b,c)
  %5265 = call float @dx.op.tertiary.f32(i32 46, float %5241, float %26, float %5264)  ; FMad(a,b,c)
  %5266 = fadd fast float %5265, %22
  %5267 = fmul fast float %5254, %33
  %5268 = call float @dx.op.tertiary.f32(i32 46, float %5255, float %29, float %5267)  ; FMad(a,b,c)
  %5269 = call float @dx.op.tertiary.f32(i32 46, float %5241, float %25, float %5268)  ; FMad(a,b,c)
  %5270 = fadd fast float %5269, %21
  %5271 = fmul fast float %5254, %32
  %5272 = call float @dx.op.tertiary.f32(i32 46, float %5255, float %28, float %5271)  ; FMad(a,b,c)
  %5273 = call float @dx.op.tertiary.f32(i32 46, float %5241, float %24, float %5272)  ; FMad(a,b,c)
  %5274 = fadd fast float %5273, %20
  %5275 = fdiv fast float %5274, %5259
  %5276 = fdiv fast float %5270, %5259
  %5277 = fdiv fast float %5266, %5259
  %5278 = fsub fast float %5275, %17
  %5279 = fsub fast float %5276, %18
  %5280 = fsub fast float %5277, %19
  %5281 = fmul fast float %5278, %5278
  %5282 = fmul fast float %5279, %5279
  %5283 = fadd fast float %5282, %5281
  %5284 = fmul fast float %5280, %5280
  %5285 = fadd fast float %5283, %5284
  %5286 = call float @dx.op.unary.f32(i32 24, float %5285)  ; Sqrt(value)
  %5287 = fsub fast float %5286, %9
  %5288 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5287)  ; FMax(a,b)
  %5289 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %5289, label %5290, label %5313

; <label>:5290                                    ; preds = %5262
  %5291 = call float @dx.op.unary.f32(i32 6, float %5279)  ; FAbs(value)
  %5292 = fmul fast float %5291, %11
  %5293 = fcmp fast olt float %5292, 0x3F50624DE0000000
  br i1 %5293, label %5294, label %5297

; <label>:5294                                    ; preds = %5290
  %5295 = fmul fast float %5292, 5.000000e-01
  %5296 = fsub fast float 1.000000e+00, %5295
  br label %5302

; <label>:5297                                    ; preds = %5290
  %5298 = fmul fast float %5292, 0xBFF7154760000000
  %5299 = call float @dx.op.unary.f32(i32 21, float %5298)  ; Exp(value)
  %5300 = fsub fast float 1.000000e+00, %5299
  %5301 = fdiv fast float %5300, %5292
  br label %5302

; <label>:5302                                    ; preds = %5297, %5294
  %5303 = phi float [ %5296, %5294 ], [ %5301, %5297 ]
  %5304 = call float @dx.op.binary.f32(i32 36, float %5276, float %18)  ; FMin(a,b)
  %5305 = fsub fast float %5304, %10
  %5306 = fmul fast float %11, %5305
  %5307 = fsub fast float -0.000000e+00, %5306
  %5308 = call float @dx.op.binary.f32(i32 35, float %5307, float -4.000000e+01)  ; FMax(a,b)
  %5309 = call float @dx.op.binary.f32(i32 36, float %5308, float 5.000000e+00)  ; FMin(a,b)
  %5310 = fmul fast float %5309, 0x3FF7154760000000
  %5311 = call float @dx.op.unary.f32(i32 21, float %5310)  ; Exp(value)
  %5312 = fmul fast float %5311, %5303
  br label %5313

; <label>:5313                                    ; preds = %5302, %5262
  %5314 = phi float [ %5312, %5302 ], [ 1.000000e+00, %5262 ]
  %5315 = fmul fast float %5288, %16
  %5316 = fmul fast float %5315, %5314
  %5317 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %5316)  ; FMin(a,b)
  %5318 = fmul fast float %5317, 0xBFF7154760000000
  %5319 = call float @dx.op.unary.f32(i32 21, float %5318)  ; Exp(value)
  %5320 = fsub fast float 1.000000e+00, %5319
  %5321 = call float @dx.op.binary.f32(i32 36, float %12, float %5320)  ; FMin(a,b)
  %5322 = fsub fast float %13, %5200
  %5323 = fsub fast float %14, %5201
  %5324 = fsub fast float %15, %5202
  %5325 = fmul fast float %5321, %5322
  %5326 = fmul fast float %5321, %5323
  %5327 = fmul fast float %5321, %5324
  %5328 = fadd fast float %5325, %5200
  %5329 = fadd fast float %5326, %5201
  %5330 = fadd fast float %5327, %5202
  br label %5331

; <label>:5331                                    ; preds = %5313, %5245, %5239
  %5332 = phi float [ %5328, %5313 ], [ %5200, %5245 ], [ %5200, %5239 ]
  %5333 = phi float [ %5329, %5313 ], [ %5201, %5245 ], [ %5201, %5239 ]
  %5334 = phi float [ %5330, %5313 ], [ %5202, %5245 ], [ %5202, %5239 ]
  %5335 = fadd fast float %5, 1.000000e+00
  %5336 = fadd fast float %6, 1.000000e+00
  %5337 = fsub fast float 1.000000e+00, %5
  %5338 = fmul fast float %36, %5335
  %5339 = fmul fast float %36, %5336
  %5340 = fmul fast float %36, %5337
  %5341 = fmul fast float %5338, %5332
  %5342 = fmul fast float %5339, %5333
  %5343 = fmul fast float %5340, %5334
  %5344 = fcmp fast ult float %37, 5.000000e-01
  br i1 %5344, label %5370, label %5345

; <label>:5345                                    ; preds = %5331
  %5346 = fmul fast float %5341, 0x4004147AE0000000
  %5347 = fmul fast float %5342, 0x4004147AE0000000
  %5348 = fmul fast float %5343, 0x4004147AE0000000
  %5349 = fadd fast float %5346, 0x3F9EB851E0000000
  %5350 = fadd fast float %5347, 0x3F9EB851E0000000
  %5351 = fadd fast float %5348, 0x3F9EB851E0000000
  %5352 = fmul fast float %5349, %5341
  %5353 = fmul fast float %5350, %5342
  %5354 = fmul fast float %5351, %5343
  %5355 = fmul fast float %5341, 0x400370A3E0000000
  %5356 = fmul fast float %5342, 0x400370A3E0000000
  %5357 = fmul fast float %5343, 0x400370A3E0000000
  %5358 = fadd fast float %5355, 0x3FE2E147A0000000
  %5359 = fadd fast float %5356, 0x3FE2E147A0000000
  %5360 = fadd fast float %5357, 0x3FE2E147A0000000
  %5361 = fmul fast float %5358, %5341
  %5362 = fmul fast float %5359, %5342
  %5363 = fmul fast float %5360, %5343
  %5364 = fadd fast float %5361, 0x3FC1EB8520000000
  %5365 = fadd fast float %5362, 0x3FC1EB8520000000
  %5366 = fadd fast float %5363, 0x3FC1EB8520000000
  %5367 = fdiv fast float %5352, %5364
  %5368 = fdiv fast float %5353, %5365
  %5369 = fdiv fast float %5354, %5366
  br label %5370

; <label>:5370                                    ; preds = %5345, %5331
  %5371 = phi float [ %5367, %5345 ], [ %5341, %5331 ]
  %5372 = phi float [ %5368, %5345 ], [ %5342, %5331 ]
  %5373 = phi float [ %5369, %5345 ], [ %5343, %5331 ]
  %5374 = call float @dx.op.unary.f32(i32 7, float %5371)  ; Saturate(value)
  %5375 = call float @dx.op.unary.f32(i32 7, float %5372)  ; Saturate(value)
  %5376 = call float @dx.op.unary.f32(i32 7, float %5373)  ; Saturate(value)
  %5377 = call float @dx.op.dot3.f32(i32 55, float %5374, float %5375, float %5376, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5378 = fsub fast float %5374, %5377
  %5379 = fsub fast float %5375, %5377
  %5380 = fsub fast float %5376, %5377
  %5381 = fmul fast float %5378, %8
  %5382 = fmul fast float %5379, %8
  %5383 = fmul fast float %5380, %8
  %5384 = fadd fast float %5381, %5377
  %5385 = fadd fast float %5382, %5377
  %5386 = fadd fast float %5383, %5377
  %5387 = call float @dx.op.unary.f32(i32 7, float %5384)  ; Saturate(value)
  %5388 = call float @dx.op.unary.f32(i32 7, float %5385)  ; Saturate(value)
  %5389 = call float @dx.op.unary.f32(i32 7, float %5386)  ; Saturate(value)
  %5390 = fadd fast float %5387, 0xBFC70A3D80000000
  %5391 = fadd fast float %5388, 0xBFC70A3D80000000
  %5392 = fadd fast float %5389, 0xBFC70A3D80000000
  %5393 = fmul fast float %5390, %7
  %5394 = fmul fast float %5391, %7
  %5395 = fmul fast float %5392, %7
  %5396 = fadd fast float %5393, 0x3FC70A3D80000000
  %5397 = fadd fast float %5394, 0x3FC70A3D80000000
  %5398 = fadd fast float %5395, 0x3FC70A3D80000000
  %5399 = call float @dx.op.unary.f32(i32 7, float %5396)  ; Saturate(value)
  %5400 = call float @dx.op.unary.f32(i32 7, float %5397)  ; Saturate(value)
  %5401 = call float @dx.op.unary.f32(i32 7, float %5398)  ; Saturate(value)
  br label %5402

; <label>:5402                                    ; preds = %5370, %5205
  %5403 = phi float [ %5236, %5205 ], [ %5399, %5370 ]
  %5404 = phi float [ %5237, %5205 ], [ %5400, %5370 ]
  %5405 = phi float [ %5238, %5205 ], [ %5401, %5370 ]
  %5406 = fsub fast float %5403, %4939
  %5407 = fsub fast float %5404, %4940
  %5408 = fsub fast float %5405, %4941
  %5409 = fmul fast float %5406, %5192
  %5410 = fmul fast float %5407, %5192
  %5411 = fmul fast float %5408, %5192
  %5412 = fadd fast float %5409, %4939
  %5413 = fadd fast float %5410, %4940
  %5414 = fadd fast float %5411, %4941
  br label %5415

; <label>:5415                                    ; preds = %5402, %5179
  %5416 = phi float [ %5412, %5402 ], [ %4939, %5179 ]
  %5417 = phi float [ %5413, %5402 ], [ %4940, %5179 ]
  %5418 = phi float [ %5414, %5402 ], [ %4941, %5179 ]
  %5419 = add i32 %67, -1
  %5420 = call i32 @dx.op.binary.i32(i32 37, i32 %5419, i32 0)  ; IMax(a,b)
  %5421 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %5422 = call i32 @dx.op.binary.i32(i32 38, i32 %5420, i32 %59)  ; IMin(a,b)
  %5423 = call i32 @dx.op.binary.i32(i32 38, i32 %5421, i32 %60)  ; IMin(a,b)
  %5424 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5422, i32 %5423, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5425 = extractvalue %dx.types.ResRet.f32 %5424, 0
  %5426 = fsub fast float %5425, %84
  %5427 = call float @dx.op.unary.f32(i32 6, float %5426)  ; FAbs(value)
  %5428 = fdiv fast float %5427, %4951
  %5429 = fsub fast float 1.000000e+00, %5428
  %5430 = call float @dx.op.unary.f32(i32 7, float %5429)  ; Saturate(value)
  %5431 = fcmp fast ugt float %5430, 0.000000e+00
  br i1 %5431, label %5432, label %5653

; <label>:5432                                    ; preds = %5415
  %5433 = call i32 @dx.op.binary.i32(i32 37, i32 %5422, i32 0)  ; IMax(a,b)
  %5434 = call i32 @dx.op.binary.i32(i32 37, i32 %5423, i32 0)  ; IMax(a,b)
  %5435 = call i32 @dx.op.binary.i32(i32 38, i32 %5433, i32 %59)  ; IMin(a,b)
  %5436 = call i32 @dx.op.binary.i32(i32 38, i32 %5434, i32 %60)  ; IMin(a,b)
  %5437 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %5435, i32 %5436, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5438 = extractvalue %dx.types.ResRet.f32 %5437, 0
  %5439 = extractvalue %dx.types.ResRet.f32 %5437, 1
  %5440 = extractvalue %dx.types.ResRet.f32 %5437, 2
  %5441 = extractvalue %dx.types.ResRet.f32 %5437, 3
  %5442 = fcmp fast olt float %5441, 0.000000e+00
  br i1 %5442, label %5443, label %5477

; <label>:5443                                    ; preds = %5432
  %5444 = fcmp fast ogt float %5438, 0x3FA4B5DCC0000000
  %5445 = fcmp fast ogt float %5439, 0x3FA4B5DCC0000000
  %5446 = fcmp fast ogt float %5440, 0x3FA4B5DCC0000000
  %5447 = select i1 %5444, float 0.000000e+00, float 1.000000e+00
  %5448 = select i1 %5445, float 0.000000e+00, float 1.000000e+00
  %5449 = select i1 %5446, float 0.000000e+00, float 1.000000e+00
  %5450 = fmul fast float %5438, 0x3FB3D07220000000
  %5451 = fmul fast float %5439, 0x3FB3D07220000000
  %5452 = fmul fast float %5440, 0x3FB3D07220000000
  %5453 = fadd fast float %5438, 0x3FAC28F5C0000000
  %5454 = fadd fast float %5439, 0x3FAC28F5C0000000
  %5455 = fadd fast float %5440, 0x3FAC28F5C0000000
  %5456 = fmul fast float %5453, 0x3FEE54EDE0000000
  %5457 = fmul fast float %5454, 0x3FEE54EDE0000000
  %5458 = fmul fast float %5455, 0x3FEE54EDE0000000
  %5459 = call float @dx.op.unary.f32(i32 23, float %5456)  ; Log(value)
  %5460 = call float @dx.op.unary.f32(i32 23, float %5457)  ; Log(value)
  %5461 = call float @dx.op.unary.f32(i32 23, float %5458)  ; Log(value)
  %5462 = fmul fast float %5459, 0x4003333340000000
  %5463 = fmul fast float %5460, 0x4003333340000000
  %5464 = fmul fast float %5461, 0x4003333340000000
  %5465 = call float @dx.op.unary.f32(i32 21, float %5462)  ; Exp(value)
  %5466 = call float @dx.op.unary.f32(i32 21, float %5463)  ; Exp(value)
  %5467 = call float @dx.op.unary.f32(i32 21, float %5464)  ; Exp(value)
  %5468 = fsub fast float %5450, %5465
  %5469 = fsub fast float %5451, %5466
  %5470 = fsub fast float %5452, %5467
  %5471 = fmul fast float %5468, %5447
  %5472 = fmul fast float %5469, %5448
  %5473 = fmul fast float %5470, %5449
  %5474 = fadd fast float %5471, %5465
  %5475 = fadd fast float %5472, %5466
  %5476 = fadd fast float %5473, %5467
  br label %5640

; <label>:5477                                    ; preds = %5432
  %5478 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5435, i32 %5436, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5479 = extractvalue %dx.types.ResRet.f32 %5478, 0
  %5480 = fcmp fast ogt float %38, 5.000000e-01
  %5481 = fcmp fast olt float %5479, 1.000000e+00
  %5482 = and i1 %5480, %5481
  br i1 %5482, label %5483, label %5569

; <label>:5483                                    ; preds = %5477
  %5484 = sitofp i32 %5435 to float
  %5485 = sitofp i32 %5436 to float
  %5486 = fadd fast float %5484, 5.000000e-01
  %5487 = fadd fast float %5485, 5.000000e-01
  %5488 = fdiv fast float %5486, %45
  %5489 = fdiv fast float %5487, %46
  %5490 = fmul fast float %5488, 2.000000e+00
  %5491 = fmul fast float %5489, 2.000000e+00
  %5492 = fadd fast float %5490, -1.000000e+00
  %5493 = fsub fast float 1.000000e+00, %5491
  %5494 = fmul fast float %5492, %35
  %5495 = call float @dx.op.tertiary.f32(i32 46, float %5493, float %31, float %5494)  ; FMad(a,b,c)
  %5496 = call float @dx.op.tertiary.f32(i32 46, float %5479, float %27, float %5495)  ; FMad(a,b,c)
  %5497 = fadd fast float %5496, %23
  %5498 = call float @dx.op.unary.f32(i32 6, float %5497)  ; FAbs(value)
  %5499 = fcmp fast ogt float %5498, 0x3EB0C6F7A0000000
  br i1 %5499, label %5500, label %5569

; <label>:5500                                    ; preds = %5483
  %5501 = fmul fast float %5492, %34
  %5502 = call float @dx.op.tertiary.f32(i32 46, float %5493, float %30, float %5501)  ; FMad(a,b,c)
  %5503 = call float @dx.op.tertiary.f32(i32 46, float %5479, float %26, float %5502)  ; FMad(a,b,c)
  %5504 = fadd fast float %5503, %22
  %5505 = fmul fast float %5492, %33
  %5506 = call float @dx.op.tertiary.f32(i32 46, float %5493, float %29, float %5505)  ; FMad(a,b,c)
  %5507 = call float @dx.op.tertiary.f32(i32 46, float %5479, float %25, float %5506)  ; FMad(a,b,c)
  %5508 = fadd fast float %5507, %21
  %5509 = fmul fast float %5492, %32
  %5510 = call float @dx.op.tertiary.f32(i32 46, float %5493, float %28, float %5509)  ; FMad(a,b,c)
  %5511 = call float @dx.op.tertiary.f32(i32 46, float %5479, float %24, float %5510)  ; FMad(a,b,c)
  %5512 = fadd fast float %5511, %20
  %5513 = fdiv fast float %5512, %5497
  %5514 = fdiv fast float %5508, %5497
  %5515 = fdiv fast float %5504, %5497
  %5516 = fsub fast float %5513, %17
  %5517 = fsub fast float %5514, %18
  %5518 = fsub fast float %5515, %19
  %5519 = fmul fast float %5516, %5516
  %5520 = fmul fast float %5517, %5517
  %5521 = fadd fast float %5520, %5519
  %5522 = fmul fast float %5518, %5518
  %5523 = fadd fast float %5521, %5522
  %5524 = call float @dx.op.unary.f32(i32 24, float %5523)  ; Sqrt(value)
  %5525 = fsub fast float %5524, %9
  %5526 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5525)  ; FMax(a,b)
  %5527 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %5527, label %5528, label %5551

; <label>:5528                                    ; preds = %5500
  %5529 = call float @dx.op.unary.f32(i32 6, float %5517)  ; FAbs(value)
  %5530 = fmul fast float %5529, %11
  %5531 = fcmp fast olt float %5530, 0x3F50624DE0000000
  br i1 %5531, label %5532, label %5535

; <label>:5532                                    ; preds = %5528
  %5533 = fmul fast float %5530, 5.000000e-01
  %5534 = fsub fast float 1.000000e+00, %5533
  br label %5540

; <label>:5535                                    ; preds = %5528
  %5536 = fmul fast float %5530, 0xBFF7154760000000
  %5537 = call float @dx.op.unary.f32(i32 21, float %5536)  ; Exp(value)
  %5538 = fsub fast float 1.000000e+00, %5537
  %5539 = fdiv fast float %5538, %5530
  br label %5540

; <label>:5540                                    ; preds = %5535, %5532
  %5541 = phi float [ %5534, %5532 ], [ %5539, %5535 ]
  %5542 = call float @dx.op.binary.f32(i32 36, float %5514, float %18)  ; FMin(a,b)
  %5543 = fsub fast float %5542, %10
  %5544 = fmul fast float %11, %5543
  %5545 = fsub fast float -0.000000e+00, %5544
  %5546 = call float @dx.op.binary.f32(i32 35, float %5545, float -4.000000e+01)  ; FMax(a,b)
  %5547 = call float @dx.op.binary.f32(i32 36, float %5546, float 5.000000e+00)  ; FMin(a,b)
  %5548 = fmul fast float %5547, 0x3FF7154760000000
  %5549 = call float @dx.op.unary.f32(i32 21, float %5548)  ; Exp(value)
  %5550 = fmul fast float %5549, %5541
  br label %5551

; <label>:5551                                    ; preds = %5540, %5500
  %5552 = phi float [ %5550, %5540 ], [ 1.000000e+00, %5500 ]
  %5553 = fmul fast float %5526, %16
  %5554 = fmul fast float %5553, %5552
  %5555 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %5554)  ; FMin(a,b)
  %5556 = fmul fast float %5555, 0xBFF7154760000000
  %5557 = call float @dx.op.unary.f32(i32 21, float %5556)  ; Exp(value)
  %5558 = fsub fast float 1.000000e+00, %5557
  %5559 = call float @dx.op.binary.f32(i32 36, float %12, float %5558)  ; FMin(a,b)
  %5560 = fsub fast float %13, %5438
  %5561 = fsub fast float %14, %5439
  %5562 = fsub fast float %15, %5440
  %5563 = fmul fast float %5559, %5560
  %5564 = fmul fast float %5559, %5561
  %5565 = fmul fast float %5559, %5562
  %5566 = fadd fast float %5563, %5438
  %5567 = fadd fast float %5564, %5439
  %5568 = fadd fast float %5565, %5440
  br label %5569

; <label>:5569                                    ; preds = %5551, %5483, %5477
  %5570 = phi float [ %5566, %5551 ], [ %5438, %5483 ], [ %5438, %5477 ]
  %5571 = phi float [ %5567, %5551 ], [ %5439, %5483 ], [ %5439, %5477 ]
  %5572 = phi float [ %5568, %5551 ], [ %5440, %5483 ], [ %5440, %5477 ]
  %5573 = fadd fast float %5, 1.000000e+00
  %5574 = fadd fast float %6, 1.000000e+00
  %5575 = fsub fast float 1.000000e+00, %5
  %5576 = fmul fast float %36, %5573
  %5577 = fmul fast float %36, %5574
  %5578 = fmul fast float %36, %5575
  %5579 = fmul fast float %5576, %5570
  %5580 = fmul fast float %5577, %5571
  %5581 = fmul fast float %5578, %5572
  %5582 = fcmp fast ult float %37, 5.000000e-01
  br i1 %5582, label %5608, label %5583

; <label>:5583                                    ; preds = %5569
  %5584 = fmul fast float %5579, 0x4004147AE0000000
  %5585 = fmul fast float %5580, 0x4004147AE0000000
  %5586 = fmul fast float %5581, 0x4004147AE0000000
  %5587 = fadd fast float %5584, 0x3F9EB851E0000000
  %5588 = fadd fast float %5585, 0x3F9EB851E0000000
  %5589 = fadd fast float %5586, 0x3F9EB851E0000000
  %5590 = fmul fast float %5587, %5579
  %5591 = fmul fast float %5588, %5580
  %5592 = fmul fast float %5589, %5581
  %5593 = fmul fast float %5579, 0x400370A3E0000000
  %5594 = fmul fast float %5580, 0x400370A3E0000000
  %5595 = fmul fast float %5581, 0x400370A3E0000000
  %5596 = fadd fast float %5593, 0x3FE2E147A0000000
  %5597 = fadd fast float %5594, 0x3FE2E147A0000000
  %5598 = fadd fast float %5595, 0x3FE2E147A0000000
  %5599 = fmul fast float %5596, %5579
  %5600 = fmul fast float %5597, %5580
  %5601 = fmul fast float %5598, %5581
  %5602 = fadd fast float %5599, 0x3FC1EB8520000000
  %5603 = fadd fast float %5600, 0x3FC1EB8520000000
  %5604 = fadd fast float %5601, 0x3FC1EB8520000000
  %5605 = fdiv fast float %5590, %5602
  %5606 = fdiv fast float %5591, %5603
  %5607 = fdiv fast float %5592, %5604
  br label %5608

; <label>:5608                                    ; preds = %5583, %5569
  %5609 = phi float [ %5605, %5583 ], [ %5579, %5569 ]
  %5610 = phi float [ %5606, %5583 ], [ %5580, %5569 ]
  %5611 = phi float [ %5607, %5583 ], [ %5581, %5569 ]
  %5612 = call float @dx.op.unary.f32(i32 7, float %5609)  ; Saturate(value)
  %5613 = call float @dx.op.unary.f32(i32 7, float %5610)  ; Saturate(value)
  %5614 = call float @dx.op.unary.f32(i32 7, float %5611)  ; Saturate(value)
  %5615 = call float @dx.op.dot3.f32(i32 55, float %5612, float %5613, float %5614, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5616 = fsub fast float %5612, %5615
  %5617 = fsub fast float %5613, %5615
  %5618 = fsub fast float %5614, %5615
  %5619 = fmul fast float %5616, %8
  %5620 = fmul fast float %5617, %8
  %5621 = fmul fast float %5618, %8
  %5622 = fadd fast float %5619, %5615
  %5623 = fadd fast float %5620, %5615
  %5624 = fadd fast float %5621, %5615
  %5625 = call float @dx.op.unary.f32(i32 7, float %5622)  ; Saturate(value)
  %5626 = call float @dx.op.unary.f32(i32 7, float %5623)  ; Saturate(value)
  %5627 = call float @dx.op.unary.f32(i32 7, float %5624)  ; Saturate(value)
  %5628 = fadd fast float %5625, 0xBFC70A3D80000000
  %5629 = fadd fast float %5626, 0xBFC70A3D80000000
  %5630 = fadd fast float %5627, 0xBFC70A3D80000000
  %5631 = fmul fast float %5628, %7
  %5632 = fmul fast float %5629, %7
  %5633 = fmul fast float %5630, %7
  %5634 = fadd fast float %5631, 0x3FC70A3D80000000
  %5635 = fadd fast float %5632, 0x3FC70A3D80000000
  %5636 = fadd fast float %5633, 0x3FC70A3D80000000
  %5637 = call float @dx.op.unary.f32(i32 7, float %5634)  ; Saturate(value)
  %5638 = call float @dx.op.unary.f32(i32 7, float %5635)  ; Saturate(value)
  %5639 = call float @dx.op.unary.f32(i32 7, float %5636)  ; Saturate(value)
  br label %5640

; <label>:5640                                    ; preds = %5608, %5443
  %5641 = phi float [ %5474, %5443 ], [ %5637, %5608 ]
  %5642 = phi float [ %5475, %5443 ], [ %5638, %5608 ]
  %5643 = phi float [ %5476, %5443 ], [ %5639, %5608 ]
  %5644 = fsub fast float %5641, %4939
  %5645 = fsub fast float %5642, %4940
  %5646 = fsub fast float %5643, %4941
  %5647 = fmul fast float %5644, %5430
  %5648 = fmul fast float %5645, %5430
  %5649 = fmul fast float %5646, %5430
  %5650 = fadd fast float %5647, %4939
  %5651 = fadd fast float %5648, %4940
  %5652 = fadd fast float %5649, %4941
  br label %5653

; <label>:5653                                    ; preds = %5640, %5415
  %5654 = phi float [ %5650, %5640 ], [ %4939, %5415 ]
  %5655 = phi float [ %5651, %5640 ], [ %4940, %5415 ]
  %5656 = phi float [ %5652, %5640 ], [ %4941, %5415 ]
  %5657 = add i32 %67, 1
  %5658 = call i32 @dx.op.binary.i32(i32 37, i32 %5657, i32 0)  ; IMax(a,b)
  %5659 = call i32 @dx.op.binary.i32(i32 38, i32 %5658, i32 %59)  ; IMin(a,b)
  %5660 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5659, i32 %5423, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5661 = extractvalue %dx.types.ResRet.f32 %5660, 0
  %5662 = fsub fast float %5661, %84
  %5663 = call float @dx.op.unary.f32(i32 6, float %5662)  ; FAbs(value)
  %5664 = fdiv fast float %5663, %4951
  %5665 = fsub fast float 1.000000e+00, %5664
  %5666 = call float @dx.op.unary.f32(i32 7, float %5665)  ; Saturate(value)
  %5667 = fcmp fast ugt float %5666, 0.000000e+00
  br i1 %5667, label %5668, label %5889

; <label>:5668                                    ; preds = %5653
  %5669 = call i32 @dx.op.binary.i32(i32 37, i32 %5659, i32 0)  ; IMax(a,b)
  %5670 = call i32 @dx.op.binary.i32(i32 37, i32 %5423, i32 0)  ; IMax(a,b)
  %5671 = call i32 @dx.op.binary.i32(i32 38, i32 %5669, i32 %59)  ; IMin(a,b)
  %5672 = call i32 @dx.op.binary.i32(i32 38, i32 %5670, i32 %60)  ; IMin(a,b)
  %5673 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %5671, i32 %5672, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5674 = extractvalue %dx.types.ResRet.f32 %5673, 0
  %5675 = extractvalue %dx.types.ResRet.f32 %5673, 1
  %5676 = extractvalue %dx.types.ResRet.f32 %5673, 2
  %5677 = extractvalue %dx.types.ResRet.f32 %5673, 3
  %5678 = fcmp fast olt float %5677, 0.000000e+00
  br i1 %5678, label %5679, label %5713

; <label>:5679                                    ; preds = %5668
  %5680 = fcmp fast ogt float %5674, 0x3FA4B5DCC0000000
  %5681 = fcmp fast ogt float %5675, 0x3FA4B5DCC0000000
  %5682 = fcmp fast ogt float %5676, 0x3FA4B5DCC0000000
  %5683 = select i1 %5680, float 0.000000e+00, float 1.000000e+00
  %5684 = select i1 %5681, float 0.000000e+00, float 1.000000e+00
  %5685 = select i1 %5682, float 0.000000e+00, float 1.000000e+00
  %5686 = fmul fast float %5674, 0x3FB3D07220000000
  %5687 = fmul fast float %5675, 0x3FB3D07220000000
  %5688 = fmul fast float %5676, 0x3FB3D07220000000
  %5689 = fadd fast float %5674, 0x3FAC28F5C0000000
  %5690 = fadd fast float %5675, 0x3FAC28F5C0000000
  %5691 = fadd fast float %5676, 0x3FAC28F5C0000000
  %5692 = fmul fast float %5689, 0x3FEE54EDE0000000
  %5693 = fmul fast float %5690, 0x3FEE54EDE0000000
  %5694 = fmul fast float %5691, 0x3FEE54EDE0000000
  %5695 = call float @dx.op.unary.f32(i32 23, float %5692)  ; Log(value)
  %5696 = call float @dx.op.unary.f32(i32 23, float %5693)  ; Log(value)
  %5697 = call float @dx.op.unary.f32(i32 23, float %5694)  ; Log(value)
  %5698 = fmul fast float %5695, 0x4003333340000000
  %5699 = fmul fast float %5696, 0x4003333340000000
  %5700 = fmul fast float %5697, 0x4003333340000000
  %5701 = call float @dx.op.unary.f32(i32 21, float %5698)  ; Exp(value)
  %5702 = call float @dx.op.unary.f32(i32 21, float %5699)  ; Exp(value)
  %5703 = call float @dx.op.unary.f32(i32 21, float %5700)  ; Exp(value)
  %5704 = fsub fast float %5686, %5701
  %5705 = fsub fast float %5687, %5702
  %5706 = fsub fast float %5688, %5703
  %5707 = fmul fast float %5704, %5683
  %5708 = fmul fast float %5705, %5684
  %5709 = fmul fast float %5706, %5685
  %5710 = fadd fast float %5707, %5701
  %5711 = fadd fast float %5708, %5702
  %5712 = fadd fast float %5709, %5703
  br label %5876

; <label>:5713                                    ; preds = %5668
  %5714 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5671, i32 %5672, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5715 = extractvalue %dx.types.ResRet.f32 %5714, 0
  %5716 = fcmp fast ogt float %38, 5.000000e-01
  %5717 = fcmp fast olt float %5715, 1.000000e+00
  %5718 = and i1 %5716, %5717
  br i1 %5718, label %5719, label %5805

; <label>:5719                                    ; preds = %5713
  %5720 = sitofp i32 %5671 to float
  %5721 = sitofp i32 %5672 to float
  %5722 = fadd fast float %5720, 5.000000e-01
  %5723 = fadd fast float %5721, 5.000000e-01
  %5724 = fdiv fast float %5722, %45
  %5725 = fdiv fast float %5723, %46
  %5726 = fmul fast float %5724, 2.000000e+00
  %5727 = fmul fast float %5725, 2.000000e+00
  %5728 = fadd fast float %5726, -1.000000e+00
  %5729 = fsub fast float 1.000000e+00, %5727
  %5730 = fmul fast float %5728, %35
  %5731 = call float @dx.op.tertiary.f32(i32 46, float %5729, float %31, float %5730)  ; FMad(a,b,c)
  %5732 = call float @dx.op.tertiary.f32(i32 46, float %5715, float %27, float %5731)  ; FMad(a,b,c)
  %5733 = fadd fast float %5732, %23
  %5734 = call float @dx.op.unary.f32(i32 6, float %5733)  ; FAbs(value)
  %5735 = fcmp fast ogt float %5734, 0x3EB0C6F7A0000000
  br i1 %5735, label %5736, label %5805

; <label>:5736                                    ; preds = %5719
  %5737 = fmul fast float %5728, %34
  %5738 = call float @dx.op.tertiary.f32(i32 46, float %5729, float %30, float %5737)  ; FMad(a,b,c)
  %5739 = call float @dx.op.tertiary.f32(i32 46, float %5715, float %26, float %5738)  ; FMad(a,b,c)
  %5740 = fadd fast float %5739, %22
  %5741 = fmul fast float %5728, %33
  %5742 = call float @dx.op.tertiary.f32(i32 46, float %5729, float %29, float %5741)  ; FMad(a,b,c)
  %5743 = call float @dx.op.tertiary.f32(i32 46, float %5715, float %25, float %5742)  ; FMad(a,b,c)
  %5744 = fadd fast float %5743, %21
  %5745 = fmul fast float %5728, %32
  %5746 = call float @dx.op.tertiary.f32(i32 46, float %5729, float %28, float %5745)  ; FMad(a,b,c)
  %5747 = call float @dx.op.tertiary.f32(i32 46, float %5715, float %24, float %5746)  ; FMad(a,b,c)
  %5748 = fadd fast float %5747, %20
  %5749 = fdiv fast float %5748, %5733
  %5750 = fdiv fast float %5744, %5733
  %5751 = fdiv fast float %5740, %5733
  %5752 = fsub fast float %5749, %17
  %5753 = fsub fast float %5750, %18
  %5754 = fsub fast float %5751, %19
  %5755 = fmul fast float %5752, %5752
  %5756 = fmul fast float %5753, %5753
  %5757 = fadd fast float %5756, %5755
  %5758 = fmul fast float %5754, %5754
  %5759 = fadd fast float %5757, %5758
  %5760 = call float @dx.op.unary.f32(i32 24, float %5759)  ; Sqrt(value)
  %5761 = fsub fast float %5760, %9
  %5762 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5761)  ; FMax(a,b)
  %5763 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %5763, label %5764, label %5787

; <label>:5764                                    ; preds = %5736
  %5765 = call float @dx.op.unary.f32(i32 6, float %5753)  ; FAbs(value)
  %5766 = fmul fast float %5765, %11
  %5767 = fcmp fast olt float %5766, 0x3F50624DE0000000
  br i1 %5767, label %5768, label %5771

; <label>:5768                                    ; preds = %5764
  %5769 = fmul fast float %5766, 5.000000e-01
  %5770 = fsub fast float 1.000000e+00, %5769
  br label %5776

; <label>:5771                                    ; preds = %5764
  %5772 = fmul fast float %5766, 0xBFF7154760000000
  %5773 = call float @dx.op.unary.f32(i32 21, float %5772)  ; Exp(value)
  %5774 = fsub fast float 1.000000e+00, %5773
  %5775 = fdiv fast float %5774, %5766
  br label %5776

; <label>:5776                                    ; preds = %5771, %5768
  %5777 = phi float [ %5770, %5768 ], [ %5775, %5771 ]
  %5778 = call float @dx.op.binary.f32(i32 36, float %5750, float %18)  ; FMin(a,b)
  %5779 = fsub fast float %5778, %10
  %5780 = fmul fast float %11, %5779
  %5781 = fsub fast float -0.000000e+00, %5780
  %5782 = call float @dx.op.binary.f32(i32 35, float %5781, float -4.000000e+01)  ; FMax(a,b)
  %5783 = call float @dx.op.binary.f32(i32 36, float %5782, float 5.000000e+00)  ; FMin(a,b)
  %5784 = fmul fast float %5783, 0x3FF7154760000000
  %5785 = call float @dx.op.unary.f32(i32 21, float %5784)  ; Exp(value)
  %5786 = fmul fast float %5785, %5777
  br label %5787

; <label>:5787                                    ; preds = %5776, %5736
  %5788 = phi float [ %5786, %5776 ], [ 1.000000e+00, %5736 ]
  %5789 = fmul fast float %5762, %16
  %5790 = fmul fast float %5789, %5788
  %5791 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %5790)  ; FMin(a,b)
  %5792 = fmul fast float %5791, 0xBFF7154760000000
  %5793 = call float @dx.op.unary.f32(i32 21, float %5792)  ; Exp(value)
  %5794 = fsub fast float 1.000000e+00, %5793
  %5795 = call float @dx.op.binary.f32(i32 36, float %12, float %5794)  ; FMin(a,b)
  %5796 = fsub fast float %13, %5674
  %5797 = fsub fast float %14, %5675
  %5798 = fsub fast float %15, %5676
  %5799 = fmul fast float %5795, %5796
  %5800 = fmul fast float %5795, %5797
  %5801 = fmul fast float %5795, %5798
  %5802 = fadd fast float %5799, %5674
  %5803 = fadd fast float %5800, %5675
  %5804 = fadd fast float %5801, %5676
  br label %5805

; <label>:5805                                    ; preds = %5787, %5719, %5713
  %5806 = phi float [ %5802, %5787 ], [ %5674, %5719 ], [ %5674, %5713 ]
  %5807 = phi float [ %5803, %5787 ], [ %5675, %5719 ], [ %5675, %5713 ]
  %5808 = phi float [ %5804, %5787 ], [ %5676, %5719 ], [ %5676, %5713 ]
  %5809 = fadd fast float %5, 1.000000e+00
  %5810 = fadd fast float %6, 1.000000e+00
  %5811 = fsub fast float 1.000000e+00, %5
  %5812 = fmul fast float %36, %5809
  %5813 = fmul fast float %36, %5810
  %5814 = fmul fast float %36, %5811
  %5815 = fmul fast float %5812, %5806
  %5816 = fmul fast float %5813, %5807
  %5817 = fmul fast float %5814, %5808
  %5818 = fcmp fast ult float %37, 5.000000e-01
  br i1 %5818, label %5844, label %5819

; <label>:5819                                    ; preds = %5805
  %5820 = fmul fast float %5815, 0x4004147AE0000000
  %5821 = fmul fast float %5816, 0x4004147AE0000000
  %5822 = fmul fast float %5817, 0x4004147AE0000000
  %5823 = fadd fast float %5820, 0x3F9EB851E0000000
  %5824 = fadd fast float %5821, 0x3F9EB851E0000000
  %5825 = fadd fast float %5822, 0x3F9EB851E0000000
  %5826 = fmul fast float %5823, %5815
  %5827 = fmul fast float %5824, %5816
  %5828 = fmul fast float %5825, %5817
  %5829 = fmul fast float %5815, 0x400370A3E0000000
  %5830 = fmul fast float %5816, 0x400370A3E0000000
  %5831 = fmul fast float %5817, 0x400370A3E0000000
  %5832 = fadd fast float %5829, 0x3FE2E147A0000000
  %5833 = fadd fast float %5830, 0x3FE2E147A0000000
  %5834 = fadd fast float %5831, 0x3FE2E147A0000000
  %5835 = fmul fast float %5832, %5815
  %5836 = fmul fast float %5833, %5816
  %5837 = fmul fast float %5834, %5817
  %5838 = fadd fast float %5835, 0x3FC1EB8520000000
  %5839 = fadd fast float %5836, 0x3FC1EB8520000000
  %5840 = fadd fast float %5837, 0x3FC1EB8520000000
  %5841 = fdiv fast float %5826, %5838
  %5842 = fdiv fast float %5827, %5839
  %5843 = fdiv fast float %5828, %5840
  br label %5844

; <label>:5844                                    ; preds = %5819, %5805
  %5845 = phi float [ %5841, %5819 ], [ %5815, %5805 ]
  %5846 = phi float [ %5842, %5819 ], [ %5816, %5805 ]
  %5847 = phi float [ %5843, %5819 ], [ %5817, %5805 ]
  %5848 = call float @dx.op.unary.f32(i32 7, float %5845)  ; Saturate(value)
  %5849 = call float @dx.op.unary.f32(i32 7, float %5846)  ; Saturate(value)
  %5850 = call float @dx.op.unary.f32(i32 7, float %5847)  ; Saturate(value)
  %5851 = call float @dx.op.dot3.f32(i32 55, float %5848, float %5849, float %5850, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5852 = fsub fast float %5848, %5851
  %5853 = fsub fast float %5849, %5851
  %5854 = fsub fast float %5850, %5851
  %5855 = fmul fast float %5852, %8
  %5856 = fmul fast float %5853, %8
  %5857 = fmul fast float %5854, %8
  %5858 = fadd fast float %5855, %5851
  %5859 = fadd fast float %5856, %5851
  %5860 = fadd fast float %5857, %5851
  %5861 = call float @dx.op.unary.f32(i32 7, float %5858)  ; Saturate(value)
  %5862 = call float @dx.op.unary.f32(i32 7, float %5859)  ; Saturate(value)
  %5863 = call float @dx.op.unary.f32(i32 7, float %5860)  ; Saturate(value)
  %5864 = fadd fast float %5861, 0xBFC70A3D80000000
  %5865 = fadd fast float %5862, 0xBFC70A3D80000000
  %5866 = fadd fast float %5863, 0xBFC70A3D80000000
  %5867 = fmul fast float %5864, %7
  %5868 = fmul fast float %5865, %7
  %5869 = fmul fast float %5866, %7
  %5870 = fadd fast float %5867, 0x3FC70A3D80000000
  %5871 = fadd fast float %5868, 0x3FC70A3D80000000
  %5872 = fadd fast float %5869, 0x3FC70A3D80000000
  %5873 = call float @dx.op.unary.f32(i32 7, float %5870)  ; Saturate(value)
  %5874 = call float @dx.op.unary.f32(i32 7, float %5871)  ; Saturate(value)
  %5875 = call float @dx.op.unary.f32(i32 7, float %5872)  ; Saturate(value)
  br label %5876

; <label>:5876                                    ; preds = %5844, %5679
  %5877 = phi float [ %5710, %5679 ], [ %5873, %5844 ]
  %5878 = phi float [ %5711, %5679 ], [ %5874, %5844 ]
  %5879 = phi float [ %5712, %5679 ], [ %5875, %5844 ]
  %5880 = fsub fast float %5877, %4939
  %5881 = fsub fast float %5878, %4940
  %5882 = fsub fast float %5879, %4941
  %5883 = fmul fast float %5880, %5666
  %5884 = fmul fast float %5881, %5666
  %5885 = fmul fast float %5882, %5666
  %5886 = fadd fast float %5883, %4939
  %5887 = fadd fast float %5884, %4940
  %5888 = fadd fast float %5885, %4941
  br label %5889

; <label>:5889                                    ; preds = %5876, %5653
  %5890 = phi float [ %5886, %5876 ], [ %4939, %5653 ]
  %5891 = phi float [ %5887, %5876 ], [ %4940, %5653 ]
  %5892 = phi float [ %5888, %5876 ], [ %4941, %5653 ]
  %5893 = call float @dx.op.binary.f32(i32 36, float %5654, float %5890)  ; FMin(a,b)
  %5894 = call float @dx.op.binary.f32(i32 36, float %5655, float %5891)  ; FMin(a,b)
  %5895 = call float @dx.op.binary.f32(i32 36, float %5656, float %5892)  ; FMin(a,b)
  %5896 = call float @dx.op.binary.f32(i32 36, float %5180, float %5416)  ; FMin(a,b)
  %5897 = call float @dx.op.binary.f32(i32 36, float %5181, float %5417)  ; FMin(a,b)
  %5898 = call float @dx.op.binary.f32(i32 36, float %5182, float %5418)  ; FMin(a,b)
  %5899 = call float @dx.op.binary.f32(i32 36, float %5896, float %5893)  ; FMin(a,b)
  %5900 = call float @dx.op.binary.f32(i32 36, float %5897, float %5894)  ; FMin(a,b)
  %5901 = call float @dx.op.binary.f32(i32 36, float %5898, float %5895)  ; FMin(a,b)
  %5902 = call float @dx.op.binary.f32(i32 36, float %4939, float %5899)  ; FMin(a,b)
  %5903 = call float @dx.op.binary.f32(i32 36, float %4940, float %5900)  ; FMin(a,b)
  %5904 = call float @dx.op.binary.f32(i32 36, float %4941, float %5901)  ; FMin(a,b)
  %5905 = call float @dx.op.binary.f32(i32 35, float %5654, float %5890)  ; FMax(a,b)
  %5906 = call float @dx.op.binary.f32(i32 35, float %5655, float %5891)  ; FMax(a,b)
  %5907 = call float @dx.op.binary.f32(i32 35, float %5656, float %5892)  ; FMax(a,b)
  %5908 = call float @dx.op.binary.f32(i32 35, float %5180, float %5416)  ; FMax(a,b)
  %5909 = call float @dx.op.binary.f32(i32 35, float %5181, float %5417)  ; FMax(a,b)
  %5910 = call float @dx.op.binary.f32(i32 35, float %5182, float %5418)  ; FMax(a,b)
  %5911 = call float @dx.op.binary.f32(i32 35, float %5908, float %5905)  ; FMax(a,b)
  %5912 = call float @dx.op.binary.f32(i32 35, float %5909, float %5906)  ; FMax(a,b)
  %5913 = call float @dx.op.binary.f32(i32 35, float %5910, float %5907)  ; FMax(a,b)
  %5914 = call float @dx.op.binary.f32(i32 35, float %4939, float %5911)  ; FMax(a,b)
  %5915 = call float @dx.op.binary.f32(i32 35, float %4940, float %5912)  ; FMax(a,b)
  %5916 = call float @dx.op.binary.f32(i32 35, float %4941, float %5913)  ; FMax(a,b)
  %5917 = fsub fast float %5914, %5902
  %5918 = fsub fast float %5915, %5903
  %5919 = fsub fast float %5916, %5904
  %5920 = call float @dx.op.unary.f32(i32 6, float %5917)  ; FAbs(value)
  %5921 = call float @dx.op.unary.f32(i32 6, float %5918)  ; FAbs(value)
  %5922 = call float @dx.op.unary.f32(i32 6, float %5919)  ; FAbs(value)
  %5923 = call float @dx.op.binary.f32(i32 35, float %5921, float %5922)  ; FMax(a,b)
  %5924 = call float @dx.op.binary.f32(i32 35, float %5920, float %5923)  ; FMax(a,b)
  %5925 = call float @dx.op.binary.f32(i32 35, float %5915, float %5916)  ; FMax(a,b)
  %5926 = call float @dx.op.binary.f32(i32 35, float %5914, float %5925)  ; FMax(a,b)
  %5927 = fmul fast float %5926, 1.250000e-01
  %5928 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %5927)  ; FMax(a,b)
  %5929 = fcmp fast ogt float %5924, %5928
  br i1 %5929, label %5930, label %5991

; <label>:5930                                    ; preds = %5889
  %5931 = fsub fast float %5180, %5416
  %5932 = fsub fast float %5181, %5417
  %5933 = fsub fast float %5182, %5418
  %5934 = call float @dx.op.unary.f32(i32 6, float %5931)  ; FAbs(value)
  %5935 = call float @dx.op.unary.f32(i32 6, float %5932)  ; FAbs(value)
  %5936 = call float @dx.op.unary.f32(i32 6, float %5933)  ; FAbs(value)
  %5937 = call float @dx.op.binary.f32(i32 35, float %5935, float %5936)  ; FMax(a,b)
  %5938 = call float @dx.op.binary.f32(i32 35, float %5934, float %5937)  ; FMax(a,b)
  %5939 = fsub fast float %5654, %5890
  %5940 = fsub fast float %5655, %5891
  %5941 = fsub fast float %5656, %5892
  %5942 = call float @dx.op.unary.f32(i32 6, float %5939)  ; FAbs(value)
  %5943 = call float @dx.op.unary.f32(i32 6, float %5940)  ; FAbs(value)
  %5944 = call float @dx.op.unary.f32(i32 6, float %5941)  ; FAbs(value)
  %5945 = call float @dx.op.binary.f32(i32 35, float %5943, float %5944)  ; FMax(a,b)
  %5946 = call float @dx.op.binary.f32(i32 35, float %5942, float %5945)  ; FMax(a,b)
  %5947 = fcmp fast olt float %5938, %5946
  %5948 = select i1 %5947, float %5180, float %5654
  %5949 = select i1 %5947, float %5181, float %5655
  %5950 = select i1 %5947, float %5182, float %5656
  %5951 = select i1 %5947, float %5416, float %5890
  %5952 = select i1 %5947, float %5417, float %5891
  %5953 = select i1 %5947, float %5418, float %5892
  %5954 = fsub fast float %4939, %5951
  %5955 = fsub fast float %4940, %5952
  %5956 = fsub fast float %4941, %5953
  %5957 = fsub fast float %4939, %5948
  %5958 = fsub fast float %4940, %5949
  %5959 = fsub fast float %4941, %5950
  %5960 = call float @dx.op.dot3.f32(i32 55, float %5957, float %5958, float %5959, float %5954, float %5955, float %5956)  ; Dot3(ax,ay,az,bx,by,bz)
  %5961 = fcmp fast ogt float %5960, 0.000000e+00
  br i1 %5961, label %5962, label %5973

; <label>:5962                                    ; preds = %5930
  %5963 = fsub fast float %5948, %5951
  %5964 = fsub fast float %5949, %5952
  %5965 = fsub fast float %5950, %5953
  %5966 = call float @dx.op.unary.f32(i32 6, float %5963)  ; FAbs(value)
  %5967 = call float @dx.op.unary.f32(i32 6, float %5964)  ; FAbs(value)
  %5968 = call float @dx.op.unary.f32(i32 6, float %5965)  ; FAbs(value)
  %5969 = call float @dx.op.binary.f32(i32 35, float %5967, float %5968)  ; FMax(a,b)
  %5970 = call float @dx.op.binary.f32(i32 35, float %5966, float %5969)  ; FMax(a,b)
  %5971 = fmul fast float %5924, 2.500000e-01
  %5972 = fcmp fast olt float %5970, %5971
  br label %5973

; <label>:5973                                    ; preds = %5962, %5930
  %5974 = phi i1 [ false, %5930 ], [ %5972, %5962 ]
  %5975 = select i1 %5974, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  %5976 = fadd fast float %5948, %5951
  %5977 = fadd fast float %5949, %5952
  %5978 = fadd fast float %5950, %5953
  %5979 = fmul fast float %5976, 5.000000e-01
  %5980 = fmul fast float %5977, 5.000000e-01
  %5981 = fmul fast float %5978, 5.000000e-01
  %5982 = fsub fast float %5979, %4939
  %5983 = fsub fast float %5980, %4940
  %5984 = fsub fast float %5981, %4941
  %5985 = fmul fast float %5975, %5982
  %5986 = fmul fast float %5975, %5983
  %5987 = fmul fast float %5975, %5984
  %5988 = fadd fast float %5985, %4939
  %5989 = fadd fast float %5986, %4940
  %5990 = fadd fast float %5987, %4941
  br label %5991

; <label>:5991                                    ; preds = %5973, %5889, %4746
  %5992 = phi float [ %4777, %4746 ], [ %5988, %5973 ], [ %4939, %5889 ]
  %5993 = phi float [ %4778, %4746 ], [ %5989, %5973 ], [ %4940, %5889 ]
  %5994 = phi float [ %4779, %4746 ], [ %5990, %5973 ], [ %4941, %5889 ]
  %5995 = phi float [ %4780, %4746 ], [ %4744, %5973 ], [ %4744, %5889 ]
  %5996 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %63, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5997 = extractvalue %dx.types.ResRet.f32 %5996, 0
  %5998 = extractvalue %dx.types.ResRet.f32 %5996, 1
  %5999 = extractvalue %dx.types.ResRet.f32 %5996, 2
  %6000 = extractvalue %dx.types.ResRet.f32 %5996, 3
  %6001 = fcmp fast olt float %6000, 0.000000e+00
  br i1 %6001, label %6002, label %6037

; <label>:6002                                    ; preds = %5991
  %6003 = fcmp fast ogt float %5997, 0x3FA4B5DCC0000000
  %6004 = fcmp fast ogt float %5998, 0x3FA4B5DCC0000000
  %6005 = fcmp fast ogt float %5999, 0x3FA4B5DCC0000000
  %6006 = select i1 %6003, float 0.000000e+00, float 1.000000e+00
  %6007 = select i1 %6004, float 0.000000e+00, float 1.000000e+00
  %6008 = select i1 %6005, float 0.000000e+00, float 1.000000e+00
  %6009 = fmul fast float %5997, 0x3FB3D07220000000
  %6010 = fmul fast float %5998, 0x3FB3D07220000000
  %6011 = fmul fast float %5999, 0x3FB3D07220000000
  %6012 = fadd fast float %5997, 0x3FAC28F5C0000000
  %6013 = fadd fast float %5998, 0x3FAC28F5C0000000
  %6014 = fadd fast float %5999, 0x3FAC28F5C0000000
  %6015 = fmul fast float %6012, 0x3FEE54EDE0000000
  %6016 = fmul fast float %6013, 0x3FEE54EDE0000000
  %6017 = fmul fast float %6014, 0x3FEE54EDE0000000
  %6018 = call float @dx.op.unary.f32(i32 23, float %6015)  ; Log(value)
  %6019 = call float @dx.op.unary.f32(i32 23, float %6016)  ; Log(value)
  %6020 = call float @dx.op.unary.f32(i32 23, float %6017)  ; Log(value)
  %6021 = fmul fast float %6018, 0x4003333340000000
  %6022 = fmul fast float %6019, 0x4003333340000000
  %6023 = fmul fast float %6020, 0x4003333340000000
  %6024 = call float @dx.op.unary.f32(i32 21, float %6021)  ; Exp(value)
  %6025 = call float @dx.op.unary.f32(i32 21, float %6022)  ; Exp(value)
  %6026 = call float @dx.op.unary.f32(i32 21, float %6023)  ; Exp(value)
  %6027 = fsub fast float %6009, %6024
  %6028 = fsub fast float %6010, %6025
  %6029 = fsub fast float %6011, %6026
  %6030 = fmul fast float %6027, %6006
  %6031 = fmul fast float %6028, %6007
  %6032 = fmul fast float %6029, %6008
  %6033 = fadd fast float %6030, %6024
  %6034 = fadd fast float %6031, %6025
  %6035 = fadd fast float %6032, %6026
  %6036 = fsub fast float -1.000000e+00, %6000
  br label %7247

; <label>:6037                                    ; preds = %5991
  %6038 = fcmp fast ogt float %38, 5.000000e-01
  %6039 = fcmp fast olt float %86, 1.000000e+00
  %6040 = and i1 %6038, %6039
  br i1 %6040, label %6041, label %6127

; <label>:6041                                    ; preds = %6037
  %6042 = sitofp i32 %63 to float
  %6043 = sitofp i32 %70 to float
  %6044 = fadd fast float %6042, 5.000000e-01
  %6045 = fadd fast float %6043, 5.000000e-01
  %6046 = fdiv fast float %6044, %45
  %6047 = fdiv fast float %6045, %46
  %6048 = fmul fast float %6046, 2.000000e+00
  %6049 = fmul fast float %6047, 2.000000e+00
  %6050 = fadd fast float %6048, -1.000000e+00
  %6051 = fsub fast float 1.000000e+00, %6049
  %6052 = fmul fast float %6050, %35
  %6053 = call float @dx.op.tertiary.f32(i32 46, float %6051, float %31, float %6052)  ; FMad(a,b,c)
  %6054 = call float @dx.op.tertiary.f32(i32 46, float %86, float %27, float %6053)  ; FMad(a,b,c)
  %6055 = fadd fast float %6054, %23
  %6056 = call float @dx.op.unary.f32(i32 6, float %6055)  ; FAbs(value)
  %6057 = fcmp fast ogt float %6056, 0x3EB0C6F7A0000000
  br i1 %6057, label %6058, label %6127

; <label>:6058                                    ; preds = %6041
  %6059 = fmul fast float %6050, %34
  %6060 = call float @dx.op.tertiary.f32(i32 46, float %6051, float %30, float %6059)  ; FMad(a,b,c)
  %6061 = call float @dx.op.tertiary.f32(i32 46, float %86, float %26, float %6060)  ; FMad(a,b,c)
  %6062 = fadd fast float %6061, %22
  %6063 = fmul fast float %6050, %33
  %6064 = call float @dx.op.tertiary.f32(i32 46, float %6051, float %29, float %6063)  ; FMad(a,b,c)
  %6065 = call float @dx.op.tertiary.f32(i32 46, float %86, float %25, float %6064)  ; FMad(a,b,c)
  %6066 = fadd fast float %6065, %21
  %6067 = fmul fast float %6050, %32
  %6068 = call float @dx.op.tertiary.f32(i32 46, float %6051, float %28, float %6067)  ; FMad(a,b,c)
  %6069 = call float @dx.op.tertiary.f32(i32 46, float %86, float %24, float %6068)  ; FMad(a,b,c)
  %6070 = fadd fast float %6069, %20
  %6071 = fdiv fast float %6070, %6055
  %6072 = fdiv fast float %6066, %6055
  %6073 = fdiv fast float %6062, %6055
  %6074 = fsub fast float %6071, %17
  %6075 = fsub fast float %6072, %18
  %6076 = fsub fast float %6073, %19
  %6077 = fmul fast float %6074, %6074
  %6078 = fmul fast float %6075, %6075
  %6079 = fadd fast float %6078, %6077
  %6080 = fmul fast float %6076, %6076
  %6081 = fadd fast float %6079, %6080
  %6082 = call float @dx.op.unary.f32(i32 24, float %6081)  ; Sqrt(value)
  %6083 = fsub fast float %6082, %9
  %6084 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %6083)  ; FMax(a,b)
  %6085 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %6085, label %6086, label %6109

; <label>:6086                                    ; preds = %6058
  %6087 = call float @dx.op.unary.f32(i32 6, float %6075)  ; FAbs(value)
  %6088 = fmul fast float %6087, %11
  %6089 = fcmp fast olt float %6088, 0x3F50624DE0000000
  br i1 %6089, label %6090, label %6093

; <label>:6090                                    ; preds = %6086
  %6091 = fmul fast float %6088, 5.000000e-01
  %6092 = fsub fast float 1.000000e+00, %6091
  br label %6098

; <label>:6093                                    ; preds = %6086
  %6094 = fmul fast float %6088, 0xBFF7154760000000
  %6095 = call float @dx.op.unary.f32(i32 21, float %6094)  ; Exp(value)
  %6096 = fsub fast float 1.000000e+00, %6095
  %6097 = fdiv fast float %6096, %6088
  br label %6098

; <label>:6098                                    ; preds = %6093, %6090
  %6099 = phi float [ %6092, %6090 ], [ %6097, %6093 ]
  %6100 = call float @dx.op.binary.f32(i32 36, float %6072, float %18)  ; FMin(a,b)
  %6101 = fsub fast float %6100, %10
  %6102 = fmul fast float %11, %6101
  %6103 = fsub fast float -0.000000e+00, %6102
  %6104 = call float @dx.op.binary.f32(i32 35, float %6103, float -4.000000e+01)  ; FMax(a,b)
  %6105 = call float @dx.op.binary.f32(i32 36, float %6104, float 5.000000e+00)  ; FMin(a,b)
  %6106 = fmul fast float %6105, 0x3FF7154760000000
  %6107 = call float @dx.op.unary.f32(i32 21, float %6106)  ; Exp(value)
  %6108 = fmul fast float %6107, %6099
  br label %6109

; <label>:6109                                    ; preds = %6098, %6058
  %6110 = phi float [ %6108, %6098 ], [ 1.000000e+00, %6058 ]
  %6111 = fmul fast float %6084, %16
  %6112 = fmul fast float %6111, %6110
  %6113 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %6112)  ; FMin(a,b)
  %6114 = fmul fast float %6113, 0xBFF7154760000000
  %6115 = call float @dx.op.unary.f32(i32 21, float %6114)  ; Exp(value)
  %6116 = fsub fast float 1.000000e+00, %6115
  %6117 = call float @dx.op.binary.f32(i32 36, float %12, float %6116)  ; FMin(a,b)
  %6118 = fsub fast float %13, %5997
  %6119 = fsub fast float %14, %5998
  %6120 = fsub fast float %15, %5999
  %6121 = fmul fast float %6117, %6118
  %6122 = fmul fast float %6117, %6119
  %6123 = fmul fast float %6117, %6120
  %6124 = fadd fast float %6121, %5997
  %6125 = fadd fast float %6122, %5998
  %6126 = fadd fast float %6123, %5999
  br label %6127

; <label>:6127                                    ; preds = %6109, %6041, %6037
  %6128 = phi float [ %6124, %6109 ], [ %5997, %6041 ], [ %5997, %6037 ]
  %6129 = phi float [ %6125, %6109 ], [ %5998, %6041 ], [ %5998, %6037 ]
  %6130 = phi float [ %6126, %6109 ], [ %5999, %6041 ], [ %5999, %6037 ]
  %6131 = fadd fast float %5, 1.000000e+00
  %6132 = fadd fast float %6, 1.000000e+00
  %6133 = fsub fast float 1.000000e+00, %5
  %6134 = fmul fast float %36, %6131
  %6135 = fmul fast float %36, %6132
  %6136 = fmul fast float %36, %6133
  %6137 = fmul fast float %6134, %6128
  %6138 = fmul fast float %6135, %6129
  %6139 = fmul fast float %6136, %6130
  %6140 = fcmp fast ult float %37, 5.000000e-01
  br i1 %6140, label %6166, label %6141

; <label>:6141                                    ; preds = %6127
  %6142 = fmul fast float %6137, 0x4004147AE0000000
  %6143 = fmul fast float %6138, 0x4004147AE0000000
  %6144 = fmul fast float %6139, 0x4004147AE0000000
  %6145 = fadd fast float %6142, 0x3F9EB851E0000000
  %6146 = fadd fast float %6143, 0x3F9EB851E0000000
  %6147 = fadd fast float %6144, 0x3F9EB851E0000000
  %6148 = fmul fast float %6145, %6137
  %6149 = fmul fast float %6146, %6138
  %6150 = fmul fast float %6147, %6139
  %6151 = fmul fast float %6137, 0x400370A3E0000000
  %6152 = fmul fast float %6138, 0x400370A3E0000000
  %6153 = fmul fast float %6139, 0x400370A3E0000000
  %6154 = fadd fast float %6151, 0x3FE2E147A0000000
  %6155 = fadd fast float %6152, 0x3FE2E147A0000000
  %6156 = fadd fast float %6153, 0x3FE2E147A0000000
  %6157 = fmul fast float %6154, %6137
  %6158 = fmul fast float %6155, %6138
  %6159 = fmul fast float %6156, %6139
  %6160 = fadd fast float %6157, 0x3FC1EB8520000000
  %6161 = fadd fast float %6158, 0x3FC1EB8520000000
  %6162 = fadd fast float %6159, 0x3FC1EB8520000000
  %6163 = fdiv fast float %6148, %6160
  %6164 = fdiv fast float %6149, %6161
  %6165 = fdiv fast float %6150, %6162
  br label %6166

; <label>:6166                                    ; preds = %6141, %6127
  %6167 = phi float [ %6163, %6141 ], [ %6137, %6127 ]
  %6168 = phi float [ %6164, %6141 ], [ %6138, %6127 ]
  %6169 = phi float [ %6165, %6141 ], [ %6139, %6127 ]
  %6170 = call float @dx.op.unary.f32(i32 7, float %6167)  ; Saturate(value)
  %6171 = call float @dx.op.unary.f32(i32 7, float %6168)  ; Saturate(value)
  %6172 = call float @dx.op.unary.f32(i32 7, float %6169)  ; Saturate(value)
  %6173 = call float @dx.op.dot3.f32(i32 55, float %6170, float %6171, float %6172, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %6174 = fsub fast float %6170, %6173
  %6175 = fsub fast float %6171, %6173
  %6176 = fsub fast float %6172, %6173
  %6177 = fmul fast float %6174, %8
  %6178 = fmul fast float %6175, %8
  %6179 = fmul fast float %6176, %8
  %6180 = fadd fast float %6177, %6173
  %6181 = fadd fast float %6178, %6173
  %6182 = fadd fast float %6179, %6173
  %6183 = call float @dx.op.unary.f32(i32 7, float %6180)  ; Saturate(value)
  %6184 = call float @dx.op.unary.f32(i32 7, float %6181)  ; Saturate(value)
  %6185 = call float @dx.op.unary.f32(i32 7, float %6182)  ; Saturate(value)
  %6186 = fadd fast float %6183, 0xBFC70A3D80000000
  %6187 = fadd fast float %6184, 0xBFC70A3D80000000
  %6188 = fadd fast float %6185, 0xBFC70A3D80000000
  %6189 = fmul fast float %6186, %7
  %6190 = fmul fast float %6187, %7
  %6191 = fmul fast float %6188, %7
  %6192 = fadd fast float %6189, 0x3FC70A3D80000000
  %6193 = fadd fast float %6190, 0x3FC70A3D80000000
  %6194 = fadd fast float %6191, 0x3FC70A3D80000000
  %6195 = call float @dx.op.unary.f32(i32 7, float %6192)  ; Saturate(value)
  %6196 = call float @dx.op.unary.f32(i32 7, float %6193)  ; Saturate(value)
  %6197 = call float @dx.op.unary.f32(i32 7, float %6194)  ; Saturate(value)
  %6198 = add i32 %70, -1
  %6199 = call i32 @dx.op.binary.i32(i32 37, i32 %63, i32 0)  ; IMax(a,b)
  %6200 = call i32 @dx.op.binary.i32(i32 37, i32 %6198, i32 0)  ; IMax(a,b)
  %6201 = call i32 @dx.op.binary.i32(i32 38, i32 %6199, i32 %59)  ; IMin(a,b)
  %6202 = call i32 @dx.op.binary.i32(i32 38, i32 %6200, i32 %60)  ; IMin(a,b)
  %6203 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %6201, i32 %6202, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6204 = extractvalue %dx.types.ResRet.f32 %6203, 0
  %6205 = fsub fast float 1.000000e+00, %86
  %6206 = fmul fast float %6205, 0x3FA99999A0000000
  %6207 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %6206)  ; FMax(a,b)
  %6208 = fsub fast float %6204, %86
  %6209 = call float @dx.op.unary.f32(i32 6, float %6208)  ; FAbs(value)
  %6210 = fdiv fast float %6209, %6207
  %6211 = fsub fast float 1.000000e+00, %6210
  %6212 = call float @dx.op.unary.f32(i32 7, float %6211)  ; Saturate(value)
  %6213 = fcmp fast ugt float %6212, 0.000000e+00
  br i1 %6213, label %6214, label %6435

; <label>:6214                                    ; preds = %6166
  %6215 = call i32 @dx.op.binary.i32(i32 37, i32 %6201, i32 0)  ; IMax(a,b)
  %6216 = call i32 @dx.op.binary.i32(i32 37, i32 %6202, i32 0)  ; IMax(a,b)
  %6217 = call i32 @dx.op.binary.i32(i32 38, i32 %6215, i32 %59)  ; IMin(a,b)
  %6218 = call i32 @dx.op.binary.i32(i32 38, i32 %6216, i32 %60)  ; IMin(a,b)
  %6219 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %6217, i32 %6218, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6220 = extractvalue %dx.types.ResRet.f32 %6219, 0
  %6221 = extractvalue %dx.types.ResRet.f32 %6219, 1
  %6222 = extractvalue %dx.types.ResRet.f32 %6219, 2
  %6223 = extractvalue %dx.types.ResRet.f32 %6219, 3
  %6224 = fcmp fast olt float %6223, 0.000000e+00
  br i1 %6224, label %6225, label %6259

; <label>:6225                                    ; preds = %6214
  %6226 = fcmp fast ogt float %6220, 0x3FA4B5DCC0000000
  %6227 = fcmp fast ogt float %6221, 0x3FA4B5DCC0000000
  %6228 = fcmp fast ogt float %6222, 0x3FA4B5DCC0000000
  %6229 = select i1 %6226, float 0.000000e+00, float 1.000000e+00
  %6230 = select i1 %6227, float 0.000000e+00, float 1.000000e+00
  %6231 = select i1 %6228, float 0.000000e+00, float 1.000000e+00
  %6232 = fmul fast float %6220, 0x3FB3D07220000000
  %6233 = fmul fast float %6221, 0x3FB3D07220000000
  %6234 = fmul fast float %6222, 0x3FB3D07220000000
  %6235 = fadd fast float %6220, 0x3FAC28F5C0000000
  %6236 = fadd fast float %6221, 0x3FAC28F5C0000000
  %6237 = fadd fast float %6222, 0x3FAC28F5C0000000
  %6238 = fmul fast float %6235, 0x3FEE54EDE0000000
  %6239 = fmul fast float %6236, 0x3FEE54EDE0000000
  %6240 = fmul fast float %6237, 0x3FEE54EDE0000000
  %6241 = call float @dx.op.unary.f32(i32 23, float %6238)  ; Log(value)
  %6242 = call float @dx.op.unary.f32(i32 23, float %6239)  ; Log(value)
  %6243 = call float @dx.op.unary.f32(i32 23, float %6240)  ; Log(value)
  %6244 = fmul fast float %6241, 0x4003333340000000
  %6245 = fmul fast float %6242, 0x4003333340000000
  %6246 = fmul fast float %6243, 0x4003333340000000
  %6247 = call float @dx.op.unary.f32(i32 21, float %6244)  ; Exp(value)
  %6248 = call float @dx.op.unary.f32(i32 21, float %6245)  ; Exp(value)
  %6249 = call float @dx.op.unary.f32(i32 21, float %6246)  ; Exp(value)
  %6250 = fsub fast float %6232, %6247
  %6251 = fsub fast float %6233, %6248
  %6252 = fsub fast float %6234, %6249
  %6253 = fmul fast float %6250, %6229
  %6254 = fmul fast float %6251, %6230
  %6255 = fmul fast float %6252, %6231
  %6256 = fadd fast float %6253, %6247
  %6257 = fadd fast float %6254, %6248
  %6258 = fadd fast float %6255, %6249
  br label %6422

; <label>:6259                                    ; preds = %6214
  %6260 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %6217, i32 %6218, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6261 = extractvalue %dx.types.ResRet.f32 %6260, 0
  %6262 = fcmp fast ogt float %38, 5.000000e-01
  %6263 = fcmp fast olt float %6261, 1.000000e+00
  %6264 = and i1 %6262, %6263
  br i1 %6264, label %6265, label %6351

; <label>:6265                                    ; preds = %6259
  %6266 = sitofp i32 %6217 to float
  %6267 = sitofp i32 %6218 to float
  %6268 = fadd fast float %6266, 5.000000e-01
  %6269 = fadd fast float %6267, 5.000000e-01
  %6270 = fdiv fast float %6268, %45
  %6271 = fdiv fast float %6269, %46
  %6272 = fmul fast float %6270, 2.000000e+00
  %6273 = fmul fast float %6271, 2.000000e+00
  %6274 = fadd fast float %6272, -1.000000e+00
  %6275 = fsub fast float 1.000000e+00, %6273
  %6276 = fmul fast float %6274, %35
  %6277 = call float @dx.op.tertiary.f32(i32 46, float %6275, float %31, float %6276)  ; FMad(a,b,c)
  %6278 = call float @dx.op.tertiary.f32(i32 46, float %6261, float %27, float %6277)  ; FMad(a,b,c)
  %6279 = fadd fast float %6278, %23
  %6280 = call float @dx.op.unary.f32(i32 6, float %6279)  ; FAbs(value)
  %6281 = fcmp fast ogt float %6280, 0x3EB0C6F7A0000000
  br i1 %6281, label %6282, label %6351

; <label>:6282                                    ; preds = %6265
  %6283 = fmul fast float %6274, %34
  %6284 = call float @dx.op.tertiary.f32(i32 46, float %6275, float %30, float %6283)  ; FMad(a,b,c)
  %6285 = call float @dx.op.tertiary.f32(i32 46, float %6261, float %26, float %6284)  ; FMad(a,b,c)
  %6286 = fadd fast float %6285, %22
  %6287 = fmul fast float %6274, %33
  %6288 = call float @dx.op.tertiary.f32(i32 46, float %6275, float %29, float %6287)  ; FMad(a,b,c)
  %6289 = call float @dx.op.tertiary.f32(i32 46, float %6261, float %25, float %6288)  ; FMad(a,b,c)
  %6290 = fadd fast float %6289, %21
  %6291 = fmul fast float %6274, %32
  %6292 = call float @dx.op.tertiary.f32(i32 46, float %6275, float %28, float %6291)  ; FMad(a,b,c)
  %6293 = call float @dx.op.tertiary.f32(i32 46, float %6261, float %24, float %6292)  ; FMad(a,b,c)
  %6294 = fadd fast float %6293, %20
  %6295 = fdiv fast float %6294, %6279
  %6296 = fdiv fast float %6290, %6279
  %6297 = fdiv fast float %6286, %6279
  %6298 = fsub fast float %6295, %17
  %6299 = fsub fast float %6296, %18
  %6300 = fsub fast float %6297, %19
  %6301 = fmul fast float %6298, %6298
  %6302 = fmul fast float %6299, %6299
  %6303 = fadd fast float %6302, %6301
  %6304 = fmul fast float %6300, %6300
  %6305 = fadd fast float %6303, %6304
  %6306 = call float @dx.op.unary.f32(i32 24, float %6305)  ; Sqrt(value)
  %6307 = fsub fast float %6306, %9
  %6308 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %6307)  ; FMax(a,b)
  %6309 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %6309, label %6310, label %6333

; <label>:6310                                    ; preds = %6282
  %6311 = call float @dx.op.unary.f32(i32 6, float %6299)  ; FAbs(value)
  %6312 = fmul fast float %6311, %11
  %6313 = fcmp fast olt float %6312, 0x3F50624DE0000000
  br i1 %6313, label %6314, label %6317

; <label>:6314                                    ; preds = %6310
  %6315 = fmul fast float %6312, 5.000000e-01
  %6316 = fsub fast float 1.000000e+00, %6315
  br label %6322

; <label>:6317                                    ; preds = %6310
  %6318 = fmul fast float %6312, 0xBFF7154760000000
  %6319 = call float @dx.op.unary.f32(i32 21, float %6318)  ; Exp(value)
  %6320 = fsub fast float 1.000000e+00, %6319
  %6321 = fdiv fast float %6320, %6312
  br label %6322

; <label>:6322                                    ; preds = %6317, %6314
  %6323 = phi float [ %6316, %6314 ], [ %6321, %6317 ]
  %6324 = call float @dx.op.binary.f32(i32 36, float %6296, float %18)  ; FMin(a,b)
  %6325 = fsub fast float %6324, %10
  %6326 = fmul fast float %11, %6325
  %6327 = fsub fast float -0.000000e+00, %6326
  %6328 = call float @dx.op.binary.f32(i32 35, float %6327, float -4.000000e+01)  ; FMax(a,b)
  %6329 = call float @dx.op.binary.f32(i32 36, float %6328, float 5.000000e+00)  ; FMin(a,b)
  %6330 = fmul fast float %6329, 0x3FF7154760000000
  %6331 = call float @dx.op.unary.f32(i32 21, float %6330)  ; Exp(value)
  %6332 = fmul fast float %6331, %6323
  br label %6333

; <label>:6333                                    ; preds = %6322, %6282
  %6334 = phi float [ %6332, %6322 ], [ 1.000000e+00, %6282 ]
  %6335 = fmul fast float %6308, %16
  %6336 = fmul fast float %6335, %6334
  %6337 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %6336)  ; FMin(a,b)
  %6338 = fmul fast float %6337, 0xBFF7154760000000
  %6339 = call float @dx.op.unary.f32(i32 21, float %6338)  ; Exp(value)
  %6340 = fsub fast float 1.000000e+00, %6339
  %6341 = call float @dx.op.binary.f32(i32 36, float %12, float %6340)  ; FMin(a,b)
  %6342 = fsub fast float %13, %6220
  %6343 = fsub fast float %14, %6221
  %6344 = fsub fast float %15, %6222
  %6345 = fmul fast float %6341, %6342
  %6346 = fmul fast float %6341, %6343
  %6347 = fmul fast float %6341, %6344
  %6348 = fadd fast float %6345, %6220
  %6349 = fadd fast float %6346, %6221
  %6350 = fadd fast float %6347, %6222
  br label %6351

; <label>:6351                                    ; preds = %6333, %6265, %6259
  %6352 = phi float [ %6348, %6333 ], [ %6220, %6265 ], [ %6220, %6259 ]
  %6353 = phi float [ %6349, %6333 ], [ %6221, %6265 ], [ %6221, %6259 ]
  %6354 = phi float [ %6350, %6333 ], [ %6222, %6265 ], [ %6222, %6259 ]
  %6355 = fadd fast float %5, 1.000000e+00
  %6356 = fadd fast float %6, 1.000000e+00
  %6357 = fsub fast float 1.000000e+00, %5
  %6358 = fmul fast float %36, %6355
  %6359 = fmul fast float %36, %6356
  %6360 = fmul fast float %36, %6357
  %6361 = fmul fast float %6358, %6352
  %6362 = fmul fast float %6359, %6353
  %6363 = fmul fast float %6360, %6354
  %6364 = fcmp fast ult float %37, 5.000000e-01
  br i1 %6364, label %6390, label %6365

; <label>:6365                                    ; preds = %6351
  %6366 = fmul fast float %6361, 0x4004147AE0000000
  %6367 = fmul fast float %6362, 0x4004147AE0000000
  %6368 = fmul fast float %6363, 0x4004147AE0000000
  %6369 = fadd fast float %6366, 0x3F9EB851E0000000
  %6370 = fadd fast float %6367, 0x3F9EB851E0000000
  %6371 = fadd fast float %6368, 0x3F9EB851E0000000
  %6372 = fmul fast float %6369, %6361
  %6373 = fmul fast float %6370, %6362
  %6374 = fmul fast float %6371, %6363
  %6375 = fmul fast float %6361, 0x400370A3E0000000
  %6376 = fmul fast float %6362, 0x400370A3E0000000
  %6377 = fmul fast float %6363, 0x400370A3E0000000
  %6378 = fadd fast float %6375, 0x3FE2E147A0000000
  %6379 = fadd fast float %6376, 0x3FE2E147A0000000
  %6380 = fadd fast float %6377, 0x3FE2E147A0000000
  %6381 = fmul fast float %6378, %6361
  %6382 = fmul fast float %6379, %6362
  %6383 = fmul fast float %6380, %6363
  %6384 = fadd fast float %6381, 0x3FC1EB8520000000
  %6385 = fadd fast float %6382, 0x3FC1EB8520000000
  %6386 = fadd fast float %6383, 0x3FC1EB8520000000
  %6387 = fdiv fast float %6372, %6384
  %6388 = fdiv fast float %6373, %6385
  %6389 = fdiv fast float %6374, %6386
  br label %6390

; <label>:6390                                    ; preds = %6365, %6351
  %6391 = phi float [ %6387, %6365 ], [ %6361, %6351 ]
  %6392 = phi float [ %6388, %6365 ], [ %6362, %6351 ]
  %6393 = phi float [ %6389, %6365 ], [ %6363, %6351 ]
  %6394 = call float @dx.op.unary.f32(i32 7, float %6391)  ; Saturate(value)
  %6395 = call float @dx.op.unary.f32(i32 7, float %6392)  ; Saturate(value)
  %6396 = call float @dx.op.unary.f32(i32 7, float %6393)  ; Saturate(value)
  %6397 = call float @dx.op.dot3.f32(i32 55, float %6394, float %6395, float %6396, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %6398 = fsub fast float %6394, %6397
  %6399 = fsub fast float %6395, %6397
  %6400 = fsub fast float %6396, %6397
  %6401 = fmul fast float %6398, %8
  %6402 = fmul fast float %6399, %8
  %6403 = fmul fast float %6400, %8
  %6404 = fadd fast float %6401, %6397
  %6405 = fadd fast float %6402, %6397
  %6406 = fadd fast float %6403, %6397
  %6407 = call float @dx.op.unary.f32(i32 7, float %6404)  ; Saturate(value)
  %6408 = call float @dx.op.unary.f32(i32 7, float %6405)  ; Saturate(value)
  %6409 = call float @dx.op.unary.f32(i32 7, float %6406)  ; Saturate(value)
  %6410 = fadd fast float %6407, 0xBFC70A3D80000000
  %6411 = fadd fast float %6408, 0xBFC70A3D80000000
  %6412 = fadd fast float %6409, 0xBFC70A3D80000000
  %6413 = fmul fast float %6410, %7
  %6414 = fmul fast float %6411, %7
  %6415 = fmul fast float %6412, %7
  %6416 = fadd fast float %6413, 0x3FC70A3D80000000
  %6417 = fadd fast float %6414, 0x3FC70A3D80000000
  %6418 = fadd fast float %6415, 0x3FC70A3D80000000
  %6419 = call float @dx.op.unary.f32(i32 7, float %6416)  ; Saturate(value)
  %6420 = call float @dx.op.unary.f32(i32 7, float %6417)  ; Saturate(value)
  %6421 = call float @dx.op.unary.f32(i32 7, float %6418)  ; Saturate(value)
  br label %6422

; <label>:6422                                    ; preds = %6390, %6225
  %6423 = phi float [ %6256, %6225 ], [ %6419, %6390 ]
  %6424 = phi float [ %6257, %6225 ], [ %6420, %6390 ]
  %6425 = phi float [ %6258, %6225 ], [ %6421, %6390 ]
  %6426 = fsub fast float %6423, %6195
  %6427 = fsub fast float %6424, %6196
  %6428 = fsub fast float %6425, %6197
  %6429 = fmul fast float %6426, %6212
  %6430 = fmul fast float %6427, %6212
  %6431 = fmul fast float %6428, %6212
  %6432 = fadd fast float %6429, %6195
  %6433 = fadd fast float %6430, %6196
  %6434 = fadd fast float %6431, %6197
  br label %6435

; <label>:6435                                    ; preds = %6422, %6166
  %6436 = phi float [ %6432, %6422 ], [ %6195, %6166 ]
  %6437 = phi float [ %6433, %6422 ], [ %6196, %6166 ]
  %6438 = phi float [ %6434, %6422 ], [ %6197, %6166 ]
  %6439 = add i32 %70, 1
  %6440 = call i32 @dx.op.binary.i32(i32 37, i32 %6439, i32 0)  ; IMax(a,b)
  %6441 = call i32 @dx.op.binary.i32(i32 38, i32 %6440, i32 %60)  ; IMin(a,b)
  %6442 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %6201, i32 %6441, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6443 = extractvalue %dx.types.ResRet.f32 %6442, 0
  %6444 = fsub fast float %6443, %86
  %6445 = call float @dx.op.unary.f32(i32 6, float %6444)  ; FAbs(value)
  %6446 = fdiv fast float %6445, %6207
  %6447 = fsub fast float 1.000000e+00, %6446
  %6448 = call float @dx.op.unary.f32(i32 7, float %6447)  ; Saturate(value)
  %6449 = fcmp fast ugt float %6448, 0.000000e+00
  br i1 %6449, label %6450, label %6671

; <label>:6450                                    ; preds = %6435
  %6451 = call i32 @dx.op.binary.i32(i32 37, i32 %6201, i32 0)  ; IMax(a,b)
  %6452 = call i32 @dx.op.binary.i32(i32 37, i32 %6441, i32 0)  ; IMax(a,b)
  %6453 = call i32 @dx.op.binary.i32(i32 38, i32 %6451, i32 %59)  ; IMin(a,b)
  %6454 = call i32 @dx.op.binary.i32(i32 38, i32 %6452, i32 %60)  ; IMin(a,b)
  %6455 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %6453, i32 %6454, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6456 = extractvalue %dx.types.ResRet.f32 %6455, 0
  %6457 = extractvalue %dx.types.ResRet.f32 %6455, 1
  %6458 = extractvalue %dx.types.ResRet.f32 %6455, 2
  %6459 = extractvalue %dx.types.ResRet.f32 %6455, 3
  %6460 = fcmp fast olt float %6459, 0.000000e+00
  br i1 %6460, label %6461, label %6495

; <label>:6461                                    ; preds = %6450
  %6462 = fcmp fast ogt float %6456, 0x3FA4B5DCC0000000
  %6463 = fcmp fast ogt float %6457, 0x3FA4B5DCC0000000
  %6464 = fcmp fast ogt float %6458, 0x3FA4B5DCC0000000
  %6465 = select i1 %6462, float 0.000000e+00, float 1.000000e+00
  %6466 = select i1 %6463, float 0.000000e+00, float 1.000000e+00
  %6467 = select i1 %6464, float 0.000000e+00, float 1.000000e+00
  %6468 = fmul fast float %6456, 0x3FB3D07220000000
  %6469 = fmul fast float %6457, 0x3FB3D07220000000
  %6470 = fmul fast float %6458, 0x3FB3D07220000000
  %6471 = fadd fast float %6456, 0x3FAC28F5C0000000
  %6472 = fadd fast float %6457, 0x3FAC28F5C0000000
  %6473 = fadd fast float %6458, 0x3FAC28F5C0000000
  %6474 = fmul fast float %6471, 0x3FEE54EDE0000000
  %6475 = fmul fast float %6472, 0x3FEE54EDE0000000
  %6476 = fmul fast float %6473, 0x3FEE54EDE0000000
  %6477 = call float @dx.op.unary.f32(i32 23, float %6474)  ; Log(value)
  %6478 = call float @dx.op.unary.f32(i32 23, float %6475)  ; Log(value)
  %6479 = call float @dx.op.unary.f32(i32 23, float %6476)  ; Log(value)
  %6480 = fmul fast float %6477, 0x4003333340000000
  %6481 = fmul fast float %6478, 0x4003333340000000
  %6482 = fmul fast float %6479, 0x4003333340000000
  %6483 = call float @dx.op.unary.f32(i32 21, float %6480)  ; Exp(value)
  %6484 = call float @dx.op.unary.f32(i32 21, float %6481)  ; Exp(value)
  %6485 = call float @dx.op.unary.f32(i32 21, float %6482)  ; Exp(value)
  %6486 = fsub fast float %6468, %6483
  %6487 = fsub fast float %6469, %6484
  %6488 = fsub fast float %6470, %6485
  %6489 = fmul fast float %6486, %6465
  %6490 = fmul fast float %6487, %6466
  %6491 = fmul fast float %6488, %6467
  %6492 = fadd fast float %6489, %6483
  %6493 = fadd fast float %6490, %6484
  %6494 = fadd fast float %6491, %6485
  br label %6658

; <label>:6495                                    ; preds = %6450
  %6496 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %6453, i32 %6454, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6497 = extractvalue %dx.types.ResRet.f32 %6496, 0
  %6498 = fcmp fast ogt float %38, 5.000000e-01
  %6499 = fcmp fast olt float %6497, 1.000000e+00
  %6500 = and i1 %6498, %6499
  br i1 %6500, label %6501, label %6587

; <label>:6501                                    ; preds = %6495
  %6502 = sitofp i32 %6453 to float
  %6503 = sitofp i32 %6454 to float
  %6504 = fadd fast float %6502, 5.000000e-01
  %6505 = fadd fast float %6503, 5.000000e-01
  %6506 = fdiv fast float %6504, %45
  %6507 = fdiv fast float %6505, %46
  %6508 = fmul fast float %6506, 2.000000e+00
  %6509 = fmul fast float %6507, 2.000000e+00
  %6510 = fadd fast float %6508, -1.000000e+00
  %6511 = fsub fast float 1.000000e+00, %6509
  %6512 = fmul fast float %6510, %35
  %6513 = call float @dx.op.tertiary.f32(i32 46, float %6511, float %31, float %6512)  ; FMad(a,b,c)
  %6514 = call float @dx.op.tertiary.f32(i32 46, float %6497, float %27, float %6513)  ; FMad(a,b,c)
  %6515 = fadd fast float %6514, %23
  %6516 = call float @dx.op.unary.f32(i32 6, float %6515)  ; FAbs(value)
  %6517 = fcmp fast ogt float %6516, 0x3EB0C6F7A0000000
  br i1 %6517, label %6518, label %6587

; <label>:6518                                    ; preds = %6501
  %6519 = fmul fast float %6510, %34
  %6520 = call float @dx.op.tertiary.f32(i32 46, float %6511, float %30, float %6519)  ; FMad(a,b,c)
  %6521 = call float @dx.op.tertiary.f32(i32 46, float %6497, float %26, float %6520)  ; FMad(a,b,c)
  %6522 = fadd fast float %6521, %22
  %6523 = fmul fast float %6510, %33
  %6524 = call float @dx.op.tertiary.f32(i32 46, float %6511, float %29, float %6523)  ; FMad(a,b,c)
  %6525 = call float @dx.op.tertiary.f32(i32 46, float %6497, float %25, float %6524)  ; FMad(a,b,c)
  %6526 = fadd fast float %6525, %21
  %6527 = fmul fast float %6510, %32
  %6528 = call float @dx.op.tertiary.f32(i32 46, float %6511, float %28, float %6527)  ; FMad(a,b,c)
  %6529 = call float @dx.op.tertiary.f32(i32 46, float %6497, float %24, float %6528)  ; FMad(a,b,c)
  %6530 = fadd fast float %6529, %20
  %6531 = fdiv fast float %6530, %6515
  %6532 = fdiv fast float %6526, %6515
  %6533 = fdiv fast float %6522, %6515
  %6534 = fsub fast float %6531, %17
  %6535 = fsub fast float %6532, %18
  %6536 = fsub fast float %6533, %19
  %6537 = fmul fast float %6534, %6534
  %6538 = fmul fast float %6535, %6535
  %6539 = fadd fast float %6538, %6537
  %6540 = fmul fast float %6536, %6536
  %6541 = fadd fast float %6539, %6540
  %6542 = call float @dx.op.unary.f32(i32 24, float %6541)  ; Sqrt(value)
  %6543 = fsub fast float %6542, %9
  %6544 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %6543)  ; FMax(a,b)
  %6545 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %6545, label %6546, label %6569

; <label>:6546                                    ; preds = %6518
  %6547 = call float @dx.op.unary.f32(i32 6, float %6535)  ; FAbs(value)
  %6548 = fmul fast float %6547, %11
  %6549 = fcmp fast olt float %6548, 0x3F50624DE0000000
  br i1 %6549, label %6550, label %6553

; <label>:6550                                    ; preds = %6546
  %6551 = fmul fast float %6548, 5.000000e-01
  %6552 = fsub fast float 1.000000e+00, %6551
  br label %6558

; <label>:6553                                    ; preds = %6546
  %6554 = fmul fast float %6548, 0xBFF7154760000000
  %6555 = call float @dx.op.unary.f32(i32 21, float %6554)  ; Exp(value)
  %6556 = fsub fast float 1.000000e+00, %6555
  %6557 = fdiv fast float %6556, %6548
  br label %6558

; <label>:6558                                    ; preds = %6553, %6550
  %6559 = phi float [ %6552, %6550 ], [ %6557, %6553 ]
  %6560 = call float @dx.op.binary.f32(i32 36, float %6532, float %18)  ; FMin(a,b)
  %6561 = fsub fast float %6560, %10
  %6562 = fmul fast float %11, %6561
  %6563 = fsub fast float -0.000000e+00, %6562
  %6564 = call float @dx.op.binary.f32(i32 35, float %6563, float -4.000000e+01)  ; FMax(a,b)
  %6565 = call float @dx.op.binary.f32(i32 36, float %6564, float 5.000000e+00)  ; FMin(a,b)
  %6566 = fmul fast float %6565, 0x3FF7154760000000
  %6567 = call float @dx.op.unary.f32(i32 21, float %6566)  ; Exp(value)
  %6568 = fmul fast float %6567, %6559
  br label %6569

; <label>:6569                                    ; preds = %6558, %6518
  %6570 = phi float [ %6568, %6558 ], [ 1.000000e+00, %6518 ]
  %6571 = fmul fast float %6544, %16
  %6572 = fmul fast float %6571, %6570
  %6573 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %6572)  ; FMin(a,b)
  %6574 = fmul fast float %6573, 0xBFF7154760000000
  %6575 = call float @dx.op.unary.f32(i32 21, float %6574)  ; Exp(value)
  %6576 = fsub fast float 1.000000e+00, %6575
  %6577 = call float @dx.op.binary.f32(i32 36, float %12, float %6576)  ; FMin(a,b)
  %6578 = fsub fast float %13, %6456
  %6579 = fsub fast float %14, %6457
  %6580 = fsub fast float %15, %6458
  %6581 = fmul fast float %6577, %6578
  %6582 = fmul fast float %6577, %6579
  %6583 = fmul fast float %6577, %6580
  %6584 = fadd fast float %6581, %6456
  %6585 = fadd fast float %6582, %6457
  %6586 = fadd fast float %6583, %6458
  br label %6587

; <label>:6587                                    ; preds = %6569, %6501, %6495
  %6588 = phi float [ %6584, %6569 ], [ %6456, %6501 ], [ %6456, %6495 ]
  %6589 = phi float [ %6585, %6569 ], [ %6457, %6501 ], [ %6457, %6495 ]
  %6590 = phi float [ %6586, %6569 ], [ %6458, %6501 ], [ %6458, %6495 ]
  %6591 = fadd fast float %5, 1.000000e+00
  %6592 = fadd fast float %6, 1.000000e+00
  %6593 = fsub fast float 1.000000e+00, %5
  %6594 = fmul fast float %36, %6591
  %6595 = fmul fast float %36, %6592
  %6596 = fmul fast float %36, %6593
  %6597 = fmul fast float %6594, %6588
  %6598 = fmul fast float %6595, %6589
  %6599 = fmul fast float %6596, %6590
  %6600 = fcmp fast ult float %37, 5.000000e-01
  br i1 %6600, label %6626, label %6601

; <label>:6601                                    ; preds = %6587
  %6602 = fmul fast float %6597, 0x4004147AE0000000
  %6603 = fmul fast float %6598, 0x4004147AE0000000
  %6604 = fmul fast float %6599, 0x4004147AE0000000
  %6605 = fadd fast float %6602, 0x3F9EB851E0000000
  %6606 = fadd fast float %6603, 0x3F9EB851E0000000
  %6607 = fadd fast float %6604, 0x3F9EB851E0000000
  %6608 = fmul fast float %6605, %6597
  %6609 = fmul fast float %6606, %6598
  %6610 = fmul fast float %6607, %6599
  %6611 = fmul fast float %6597, 0x400370A3E0000000
  %6612 = fmul fast float %6598, 0x400370A3E0000000
  %6613 = fmul fast float %6599, 0x400370A3E0000000
  %6614 = fadd fast float %6611, 0x3FE2E147A0000000
  %6615 = fadd fast float %6612, 0x3FE2E147A0000000
  %6616 = fadd fast float %6613, 0x3FE2E147A0000000
  %6617 = fmul fast float %6614, %6597
  %6618 = fmul fast float %6615, %6598
  %6619 = fmul fast float %6616, %6599
  %6620 = fadd fast float %6617, 0x3FC1EB8520000000
  %6621 = fadd fast float %6618, 0x3FC1EB8520000000
  %6622 = fadd fast float %6619, 0x3FC1EB8520000000
  %6623 = fdiv fast float %6608, %6620
  %6624 = fdiv fast float %6609, %6621
  %6625 = fdiv fast float %6610, %6622
  br label %6626

; <label>:6626                                    ; preds = %6601, %6587
  %6627 = phi float [ %6623, %6601 ], [ %6597, %6587 ]
  %6628 = phi float [ %6624, %6601 ], [ %6598, %6587 ]
  %6629 = phi float [ %6625, %6601 ], [ %6599, %6587 ]
  %6630 = call float @dx.op.unary.f32(i32 7, float %6627)  ; Saturate(value)
  %6631 = call float @dx.op.unary.f32(i32 7, float %6628)  ; Saturate(value)
  %6632 = call float @dx.op.unary.f32(i32 7, float %6629)  ; Saturate(value)
  %6633 = call float @dx.op.dot3.f32(i32 55, float %6630, float %6631, float %6632, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %6634 = fsub fast float %6630, %6633
  %6635 = fsub fast float %6631, %6633
  %6636 = fsub fast float %6632, %6633
  %6637 = fmul fast float %6634, %8
  %6638 = fmul fast float %6635, %8
  %6639 = fmul fast float %6636, %8
  %6640 = fadd fast float %6637, %6633
  %6641 = fadd fast float %6638, %6633
  %6642 = fadd fast float %6639, %6633
  %6643 = call float @dx.op.unary.f32(i32 7, float %6640)  ; Saturate(value)
  %6644 = call float @dx.op.unary.f32(i32 7, float %6641)  ; Saturate(value)
  %6645 = call float @dx.op.unary.f32(i32 7, float %6642)  ; Saturate(value)
  %6646 = fadd fast float %6643, 0xBFC70A3D80000000
  %6647 = fadd fast float %6644, 0xBFC70A3D80000000
  %6648 = fadd fast float %6645, 0xBFC70A3D80000000
  %6649 = fmul fast float %6646, %7
  %6650 = fmul fast float %6647, %7
  %6651 = fmul fast float %6648, %7
  %6652 = fadd fast float %6649, 0x3FC70A3D80000000
  %6653 = fadd fast float %6650, 0x3FC70A3D80000000
  %6654 = fadd fast float %6651, 0x3FC70A3D80000000
  %6655 = call float @dx.op.unary.f32(i32 7, float %6652)  ; Saturate(value)
  %6656 = call float @dx.op.unary.f32(i32 7, float %6653)  ; Saturate(value)
  %6657 = call float @dx.op.unary.f32(i32 7, float %6654)  ; Saturate(value)
  br label %6658

; <label>:6658                                    ; preds = %6626, %6461
  %6659 = phi float [ %6492, %6461 ], [ %6655, %6626 ]
  %6660 = phi float [ %6493, %6461 ], [ %6656, %6626 ]
  %6661 = phi float [ %6494, %6461 ], [ %6657, %6626 ]
  %6662 = fsub fast float %6659, %6195
  %6663 = fsub fast float %6660, %6196
  %6664 = fsub fast float %6661, %6197
  %6665 = fmul fast float %6662, %6448
  %6666 = fmul fast float %6663, %6448
  %6667 = fmul fast float %6664, %6448
  %6668 = fadd fast float %6665, %6195
  %6669 = fadd fast float %6666, %6196
  %6670 = fadd fast float %6667, %6197
  br label %6671

; <label>:6671                                    ; preds = %6658, %6435
  %6672 = phi float [ %6668, %6658 ], [ %6195, %6435 ]
  %6673 = phi float [ %6669, %6658 ], [ %6196, %6435 ]
  %6674 = phi float [ %6670, %6658 ], [ %6197, %6435 ]
  %6675 = add i32 %63, -1
  %6676 = call i32 @dx.op.binary.i32(i32 37, i32 %6675, i32 0)  ; IMax(a,b)
  %6677 = call i32 @dx.op.binary.i32(i32 37, i32 %70, i32 0)  ; IMax(a,b)
  %6678 = call i32 @dx.op.binary.i32(i32 38, i32 %6676, i32 %59)  ; IMin(a,b)
  %6679 = call i32 @dx.op.binary.i32(i32 38, i32 %6677, i32 %60)  ; IMin(a,b)
  %6680 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %6678, i32 %6679, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6681 = extractvalue %dx.types.ResRet.f32 %6680, 0
  %6682 = fsub fast float %6681, %86
  %6683 = call float @dx.op.unary.f32(i32 6, float %6682)  ; FAbs(value)
  %6684 = fdiv fast float %6683, %6207
  %6685 = fsub fast float 1.000000e+00, %6684
  %6686 = call float @dx.op.unary.f32(i32 7, float %6685)  ; Saturate(value)
  %6687 = fcmp fast ugt float %6686, 0.000000e+00
  br i1 %6687, label %6688, label %6909

; <label>:6688                                    ; preds = %6671
  %6689 = call i32 @dx.op.binary.i32(i32 37, i32 %6678, i32 0)  ; IMax(a,b)
  %6690 = call i32 @dx.op.binary.i32(i32 37, i32 %6679, i32 0)  ; IMax(a,b)
  %6691 = call i32 @dx.op.binary.i32(i32 38, i32 %6689, i32 %59)  ; IMin(a,b)
  %6692 = call i32 @dx.op.binary.i32(i32 38, i32 %6690, i32 %60)  ; IMin(a,b)
  %6693 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %6691, i32 %6692, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6694 = extractvalue %dx.types.ResRet.f32 %6693, 0
  %6695 = extractvalue %dx.types.ResRet.f32 %6693, 1
  %6696 = extractvalue %dx.types.ResRet.f32 %6693, 2
  %6697 = extractvalue %dx.types.ResRet.f32 %6693, 3
  %6698 = fcmp fast olt float %6697, 0.000000e+00
  br i1 %6698, label %6699, label %6733

; <label>:6699                                    ; preds = %6688
  %6700 = fcmp fast ogt float %6694, 0x3FA4B5DCC0000000
  %6701 = fcmp fast ogt float %6695, 0x3FA4B5DCC0000000
  %6702 = fcmp fast ogt float %6696, 0x3FA4B5DCC0000000
  %6703 = select i1 %6700, float 0.000000e+00, float 1.000000e+00
  %6704 = select i1 %6701, float 0.000000e+00, float 1.000000e+00
  %6705 = select i1 %6702, float 0.000000e+00, float 1.000000e+00
  %6706 = fmul fast float %6694, 0x3FB3D07220000000
  %6707 = fmul fast float %6695, 0x3FB3D07220000000
  %6708 = fmul fast float %6696, 0x3FB3D07220000000
  %6709 = fadd fast float %6694, 0x3FAC28F5C0000000
  %6710 = fadd fast float %6695, 0x3FAC28F5C0000000
  %6711 = fadd fast float %6696, 0x3FAC28F5C0000000
  %6712 = fmul fast float %6709, 0x3FEE54EDE0000000
  %6713 = fmul fast float %6710, 0x3FEE54EDE0000000
  %6714 = fmul fast float %6711, 0x3FEE54EDE0000000
  %6715 = call float @dx.op.unary.f32(i32 23, float %6712)  ; Log(value)
  %6716 = call float @dx.op.unary.f32(i32 23, float %6713)  ; Log(value)
  %6717 = call float @dx.op.unary.f32(i32 23, float %6714)  ; Log(value)
  %6718 = fmul fast float %6715, 0x4003333340000000
  %6719 = fmul fast float %6716, 0x4003333340000000
  %6720 = fmul fast float %6717, 0x4003333340000000
  %6721 = call float @dx.op.unary.f32(i32 21, float %6718)  ; Exp(value)
  %6722 = call float @dx.op.unary.f32(i32 21, float %6719)  ; Exp(value)
  %6723 = call float @dx.op.unary.f32(i32 21, float %6720)  ; Exp(value)
  %6724 = fsub fast float %6706, %6721
  %6725 = fsub fast float %6707, %6722
  %6726 = fsub fast float %6708, %6723
  %6727 = fmul fast float %6724, %6703
  %6728 = fmul fast float %6725, %6704
  %6729 = fmul fast float %6726, %6705
  %6730 = fadd fast float %6727, %6721
  %6731 = fadd fast float %6728, %6722
  %6732 = fadd fast float %6729, %6723
  br label %6896

; <label>:6733                                    ; preds = %6688
  %6734 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %6691, i32 %6692, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6735 = extractvalue %dx.types.ResRet.f32 %6734, 0
  %6736 = fcmp fast ogt float %38, 5.000000e-01
  %6737 = fcmp fast olt float %6735, 1.000000e+00
  %6738 = and i1 %6736, %6737
  br i1 %6738, label %6739, label %6825

; <label>:6739                                    ; preds = %6733
  %6740 = sitofp i32 %6691 to float
  %6741 = sitofp i32 %6692 to float
  %6742 = fadd fast float %6740, 5.000000e-01
  %6743 = fadd fast float %6741, 5.000000e-01
  %6744 = fdiv fast float %6742, %45
  %6745 = fdiv fast float %6743, %46
  %6746 = fmul fast float %6744, 2.000000e+00
  %6747 = fmul fast float %6745, 2.000000e+00
  %6748 = fadd fast float %6746, -1.000000e+00
  %6749 = fsub fast float 1.000000e+00, %6747
  %6750 = fmul fast float %6748, %35
  %6751 = call float @dx.op.tertiary.f32(i32 46, float %6749, float %31, float %6750)  ; FMad(a,b,c)
  %6752 = call float @dx.op.tertiary.f32(i32 46, float %6735, float %27, float %6751)  ; FMad(a,b,c)
  %6753 = fadd fast float %6752, %23
  %6754 = call float @dx.op.unary.f32(i32 6, float %6753)  ; FAbs(value)
  %6755 = fcmp fast ogt float %6754, 0x3EB0C6F7A0000000
  br i1 %6755, label %6756, label %6825

; <label>:6756                                    ; preds = %6739
  %6757 = fmul fast float %6748, %34
  %6758 = call float @dx.op.tertiary.f32(i32 46, float %6749, float %30, float %6757)  ; FMad(a,b,c)
  %6759 = call float @dx.op.tertiary.f32(i32 46, float %6735, float %26, float %6758)  ; FMad(a,b,c)
  %6760 = fadd fast float %6759, %22
  %6761 = fmul fast float %6748, %33
  %6762 = call float @dx.op.tertiary.f32(i32 46, float %6749, float %29, float %6761)  ; FMad(a,b,c)
  %6763 = call float @dx.op.tertiary.f32(i32 46, float %6735, float %25, float %6762)  ; FMad(a,b,c)
  %6764 = fadd fast float %6763, %21
  %6765 = fmul fast float %6748, %32
  %6766 = call float @dx.op.tertiary.f32(i32 46, float %6749, float %28, float %6765)  ; FMad(a,b,c)
  %6767 = call float @dx.op.tertiary.f32(i32 46, float %6735, float %24, float %6766)  ; FMad(a,b,c)
  %6768 = fadd fast float %6767, %20
  %6769 = fdiv fast float %6768, %6753
  %6770 = fdiv fast float %6764, %6753
  %6771 = fdiv fast float %6760, %6753
  %6772 = fsub fast float %6769, %17
  %6773 = fsub fast float %6770, %18
  %6774 = fsub fast float %6771, %19
  %6775 = fmul fast float %6772, %6772
  %6776 = fmul fast float %6773, %6773
  %6777 = fadd fast float %6776, %6775
  %6778 = fmul fast float %6774, %6774
  %6779 = fadd fast float %6777, %6778
  %6780 = call float @dx.op.unary.f32(i32 24, float %6779)  ; Sqrt(value)
  %6781 = fsub fast float %6780, %9
  %6782 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %6781)  ; FMax(a,b)
  %6783 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %6783, label %6784, label %6807

; <label>:6784                                    ; preds = %6756
  %6785 = call float @dx.op.unary.f32(i32 6, float %6773)  ; FAbs(value)
  %6786 = fmul fast float %6785, %11
  %6787 = fcmp fast olt float %6786, 0x3F50624DE0000000
  br i1 %6787, label %6788, label %6791

; <label>:6788                                    ; preds = %6784
  %6789 = fmul fast float %6786, 5.000000e-01
  %6790 = fsub fast float 1.000000e+00, %6789
  br label %6796

; <label>:6791                                    ; preds = %6784
  %6792 = fmul fast float %6786, 0xBFF7154760000000
  %6793 = call float @dx.op.unary.f32(i32 21, float %6792)  ; Exp(value)
  %6794 = fsub fast float 1.000000e+00, %6793
  %6795 = fdiv fast float %6794, %6786
  br label %6796

; <label>:6796                                    ; preds = %6791, %6788
  %6797 = phi float [ %6790, %6788 ], [ %6795, %6791 ]
  %6798 = call float @dx.op.binary.f32(i32 36, float %6770, float %18)  ; FMin(a,b)
  %6799 = fsub fast float %6798, %10
  %6800 = fmul fast float %11, %6799
  %6801 = fsub fast float -0.000000e+00, %6800
  %6802 = call float @dx.op.binary.f32(i32 35, float %6801, float -4.000000e+01)  ; FMax(a,b)
  %6803 = call float @dx.op.binary.f32(i32 36, float %6802, float 5.000000e+00)  ; FMin(a,b)
  %6804 = fmul fast float %6803, 0x3FF7154760000000
  %6805 = call float @dx.op.unary.f32(i32 21, float %6804)  ; Exp(value)
  %6806 = fmul fast float %6805, %6797
  br label %6807

; <label>:6807                                    ; preds = %6796, %6756
  %6808 = phi float [ %6806, %6796 ], [ 1.000000e+00, %6756 ]
  %6809 = fmul fast float %6782, %16
  %6810 = fmul fast float %6809, %6808
  %6811 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %6810)  ; FMin(a,b)
  %6812 = fmul fast float %6811, 0xBFF7154760000000
  %6813 = call float @dx.op.unary.f32(i32 21, float %6812)  ; Exp(value)
  %6814 = fsub fast float 1.000000e+00, %6813
  %6815 = call float @dx.op.binary.f32(i32 36, float %12, float %6814)  ; FMin(a,b)
  %6816 = fsub fast float %13, %6694
  %6817 = fsub fast float %14, %6695
  %6818 = fsub fast float %15, %6696
  %6819 = fmul fast float %6815, %6816
  %6820 = fmul fast float %6815, %6817
  %6821 = fmul fast float %6815, %6818
  %6822 = fadd fast float %6819, %6694
  %6823 = fadd fast float %6820, %6695
  %6824 = fadd fast float %6821, %6696
  br label %6825

; <label>:6825                                    ; preds = %6807, %6739, %6733
  %6826 = phi float [ %6822, %6807 ], [ %6694, %6739 ], [ %6694, %6733 ]
  %6827 = phi float [ %6823, %6807 ], [ %6695, %6739 ], [ %6695, %6733 ]
  %6828 = phi float [ %6824, %6807 ], [ %6696, %6739 ], [ %6696, %6733 ]
  %6829 = fadd fast float %5, 1.000000e+00
  %6830 = fadd fast float %6, 1.000000e+00
  %6831 = fsub fast float 1.000000e+00, %5
  %6832 = fmul fast float %36, %6829
  %6833 = fmul fast float %36, %6830
  %6834 = fmul fast float %36, %6831
  %6835 = fmul fast float %6832, %6826
  %6836 = fmul fast float %6833, %6827
  %6837 = fmul fast float %6834, %6828
  %6838 = fcmp fast ult float %37, 5.000000e-01
  br i1 %6838, label %6864, label %6839

; <label>:6839                                    ; preds = %6825
  %6840 = fmul fast float %6835, 0x4004147AE0000000
  %6841 = fmul fast float %6836, 0x4004147AE0000000
  %6842 = fmul fast float %6837, 0x4004147AE0000000
  %6843 = fadd fast float %6840, 0x3F9EB851E0000000
  %6844 = fadd fast float %6841, 0x3F9EB851E0000000
  %6845 = fadd fast float %6842, 0x3F9EB851E0000000
  %6846 = fmul fast float %6843, %6835
  %6847 = fmul fast float %6844, %6836
  %6848 = fmul fast float %6845, %6837
  %6849 = fmul fast float %6835, 0x400370A3E0000000
  %6850 = fmul fast float %6836, 0x400370A3E0000000
  %6851 = fmul fast float %6837, 0x400370A3E0000000
  %6852 = fadd fast float %6849, 0x3FE2E147A0000000
  %6853 = fadd fast float %6850, 0x3FE2E147A0000000
  %6854 = fadd fast float %6851, 0x3FE2E147A0000000
  %6855 = fmul fast float %6852, %6835
  %6856 = fmul fast float %6853, %6836
  %6857 = fmul fast float %6854, %6837
  %6858 = fadd fast float %6855, 0x3FC1EB8520000000
  %6859 = fadd fast float %6856, 0x3FC1EB8520000000
  %6860 = fadd fast float %6857, 0x3FC1EB8520000000
  %6861 = fdiv fast float %6846, %6858
  %6862 = fdiv fast float %6847, %6859
  %6863 = fdiv fast float %6848, %6860
  br label %6864

; <label>:6864                                    ; preds = %6839, %6825
  %6865 = phi float [ %6861, %6839 ], [ %6835, %6825 ]
  %6866 = phi float [ %6862, %6839 ], [ %6836, %6825 ]
  %6867 = phi float [ %6863, %6839 ], [ %6837, %6825 ]
  %6868 = call float @dx.op.unary.f32(i32 7, float %6865)  ; Saturate(value)
  %6869 = call float @dx.op.unary.f32(i32 7, float %6866)  ; Saturate(value)
  %6870 = call float @dx.op.unary.f32(i32 7, float %6867)  ; Saturate(value)
  %6871 = call float @dx.op.dot3.f32(i32 55, float %6868, float %6869, float %6870, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %6872 = fsub fast float %6868, %6871
  %6873 = fsub fast float %6869, %6871
  %6874 = fsub fast float %6870, %6871
  %6875 = fmul fast float %6872, %8
  %6876 = fmul fast float %6873, %8
  %6877 = fmul fast float %6874, %8
  %6878 = fadd fast float %6875, %6871
  %6879 = fadd fast float %6876, %6871
  %6880 = fadd fast float %6877, %6871
  %6881 = call float @dx.op.unary.f32(i32 7, float %6878)  ; Saturate(value)
  %6882 = call float @dx.op.unary.f32(i32 7, float %6879)  ; Saturate(value)
  %6883 = call float @dx.op.unary.f32(i32 7, float %6880)  ; Saturate(value)
  %6884 = fadd fast float %6881, 0xBFC70A3D80000000
  %6885 = fadd fast float %6882, 0xBFC70A3D80000000
  %6886 = fadd fast float %6883, 0xBFC70A3D80000000
  %6887 = fmul fast float %6884, %7
  %6888 = fmul fast float %6885, %7
  %6889 = fmul fast float %6886, %7
  %6890 = fadd fast float %6887, 0x3FC70A3D80000000
  %6891 = fadd fast float %6888, 0x3FC70A3D80000000
  %6892 = fadd fast float %6889, 0x3FC70A3D80000000
  %6893 = call float @dx.op.unary.f32(i32 7, float %6890)  ; Saturate(value)
  %6894 = call float @dx.op.unary.f32(i32 7, float %6891)  ; Saturate(value)
  %6895 = call float @dx.op.unary.f32(i32 7, float %6892)  ; Saturate(value)
  br label %6896

; <label>:6896                                    ; preds = %6864, %6699
  %6897 = phi float [ %6730, %6699 ], [ %6893, %6864 ]
  %6898 = phi float [ %6731, %6699 ], [ %6894, %6864 ]
  %6899 = phi float [ %6732, %6699 ], [ %6895, %6864 ]
  %6900 = fsub fast float %6897, %6195
  %6901 = fsub fast float %6898, %6196
  %6902 = fsub fast float %6899, %6197
  %6903 = fmul fast float %6900, %6686
  %6904 = fmul fast float %6901, %6686
  %6905 = fmul fast float %6902, %6686
  %6906 = fadd fast float %6903, %6195
  %6907 = fadd fast float %6904, %6196
  %6908 = fadd fast float %6905, %6197
  br label %6909

; <label>:6909                                    ; preds = %6896, %6671
  %6910 = phi float [ %6906, %6896 ], [ %6195, %6671 ]
  %6911 = phi float [ %6907, %6896 ], [ %6196, %6671 ]
  %6912 = phi float [ %6908, %6896 ], [ %6197, %6671 ]
  %6913 = add i32 %63, 1
  %6914 = call i32 @dx.op.binary.i32(i32 37, i32 %6913, i32 0)  ; IMax(a,b)
  %6915 = call i32 @dx.op.binary.i32(i32 38, i32 %6914, i32 %59)  ; IMin(a,b)
  %6916 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %6915, i32 %6679, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6917 = extractvalue %dx.types.ResRet.f32 %6916, 0
  %6918 = fsub fast float %6917, %86
  %6919 = call float @dx.op.unary.f32(i32 6, float %6918)  ; FAbs(value)
  %6920 = fdiv fast float %6919, %6207
  %6921 = fsub fast float 1.000000e+00, %6920
  %6922 = call float @dx.op.unary.f32(i32 7, float %6921)  ; Saturate(value)
  %6923 = fcmp fast ugt float %6922, 0.000000e+00
  br i1 %6923, label %6924, label %7145

; <label>:6924                                    ; preds = %6909
  %6925 = call i32 @dx.op.binary.i32(i32 37, i32 %6915, i32 0)  ; IMax(a,b)
  %6926 = call i32 @dx.op.binary.i32(i32 37, i32 %6679, i32 0)  ; IMax(a,b)
  %6927 = call i32 @dx.op.binary.i32(i32 38, i32 %6925, i32 %59)  ; IMin(a,b)
  %6928 = call i32 @dx.op.binary.i32(i32 38, i32 %6926, i32 %60)  ; IMin(a,b)
  %6929 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %6927, i32 %6928, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6930 = extractvalue %dx.types.ResRet.f32 %6929, 0
  %6931 = extractvalue %dx.types.ResRet.f32 %6929, 1
  %6932 = extractvalue %dx.types.ResRet.f32 %6929, 2
  %6933 = extractvalue %dx.types.ResRet.f32 %6929, 3
  %6934 = fcmp fast olt float %6933, 0.000000e+00
  br i1 %6934, label %6935, label %6969

; <label>:6935                                    ; preds = %6924
  %6936 = fcmp fast ogt float %6930, 0x3FA4B5DCC0000000
  %6937 = fcmp fast ogt float %6931, 0x3FA4B5DCC0000000
  %6938 = fcmp fast ogt float %6932, 0x3FA4B5DCC0000000
  %6939 = select i1 %6936, float 0.000000e+00, float 1.000000e+00
  %6940 = select i1 %6937, float 0.000000e+00, float 1.000000e+00
  %6941 = select i1 %6938, float 0.000000e+00, float 1.000000e+00
  %6942 = fmul fast float %6930, 0x3FB3D07220000000
  %6943 = fmul fast float %6931, 0x3FB3D07220000000
  %6944 = fmul fast float %6932, 0x3FB3D07220000000
  %6945 = fadd fast float %6930, 0x3FAC28F5C0000000
  %6946 = fadd fast float %6931, 0x3FAC28F5C0000000
  %6947 = fadd fast float %6932, 0x3FAC28F5C0000000
  %6948 = fmul fast float %6945, 0x3FEE54EDE0000000
  %6949 = fmul fast float %6946, 0x3FEE54EDE0000000
  %6950 = fmul fast float %6947, 0x3FEE54EDE0000000
  %6951 = call float @dx.op.unary.f32(i32 23, float %6948)  ; Log(value)
  %6952 = call float @dx.op.unary.f32(i32 23, float %6949)  ; Log(value)
  %6953 = call float @dx.op.unary.f32(i32 23, float %6950)  ; Log(value)
  %6954 = fmul fast float %6951, 0x4003333340000000
  %6955 = fmul fast float %6952, 0x4003333340000000
  %6956 = fmul fast float %6953, 0x4003333340000000
  %6957 = call float @dx.op.unary.f32(i32 21, float %6954)  ; Exp(value)
  %6958 = call float @dx.op.unary.f32(i32 21, float %6955)  ; Exp(value)
  %6959 = call float @dx.op.unary.f32(i32 21, float %6956)  ; Exp(value)
  %6960 = fsub fast float %6942, %6957
  %6961 = fsub fast float %6943, %6958
  %6962 = fsub fast float %6944, %6959
  %6963 = fmul fast float %6960, %6939
  %6964 = fmul fast float %6961, %6940
  %6965 = fmul fast float %6962, %6941
  %6966 = fadd fast float %6963, %6957
  %6967 = fadd fast float %6964, %6958
  %6968 = fadd fast float %6965, %6959
  br label %7132

; <label>:6969                                    ; preds = %6924
  %6970 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %6927, i32 %6928, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6971 = extractvalue %dx.types.ResRet.f32 %6970, 0
  %6972 = fcmp fast ogt float %38, 5.000000e-01
  %6973 = fcmp fast olt float %6971, 1.000000e+00
  %6974 = and i1 %6972, %6973
  br i1 %6974, label %6975, label %7061

; <label>:6975                                    ; preds = %6969
  %6976 = sitofp i32 %6927 to float
  %6977 = sitofp i32 %6928 to float
  %6978 = fadd fast float %6976, 5.000000e-01
  %6979 = fadd fast float %6977, 5.000000e-01
  %6980 = fdiv fast float %6978, %45
  %6981 = fdiv fast float %6979, %46
  %6982 = fmul fast float %6980, 2.000000e+00
  %6983 = fmul fast float %6981, 2.000000e+00
  %6984 = fadd fast float %6982, -1.000000e+00
  %6985 = fsub fast float 1.000000e+00, %6983
  %6986 = fmul fast float %6984, %35
  %6987 = call float @dx.op.tertiary.f32(i32 46, float %6985, float %31, float %6986)  ; FMad(a,b,c)
  %6988 = call float @dx.op.tertiary.f32(i32 46, float %6971, float %27, float %6987)  ; FMad(a,b,c)
  %6989 = fadd fast float %6988, %23
  %6990 = call float @dx.op.unary.f32(i32 6, float %6989)  ; FAbs(value)
  %6991 = fcmp fast ogt float %6990, 0x3EB0C6F7A0000000
  br i1 %6991, label %6992, label %7061

; <label>:6992                                    ; preds = %6975
  %6993 = fmul fast float %6984, %34
  %6994 = call float @dx.op.tertiary.f32(i32 46, float %6985, float %30, float %6993)  ; FMad(a,b,c)
  %6995 = call float @dx.op.tertiary.f32(i32 46, float %6971, float %26, float %6994)  ; FMad(a,b,c)
  %6996 = fadd fast float %6995, %22
  %6997 = fmul fast float %6984, %33
  %6998 = call float @dx.op.tertiary.f32(i32 46, float %6985, float %29, float %6997)  ; FMad(a,b,c)
  %6999 = call float @dx.op.tertiary.f32(i32 46, float %6971, float %25, float %6998)  ; FMad(a,b,c)
  %7000 = fadd fast float %6999, %21
  %7001 = fmul fast float %6984, %32
  %7002 = call float @dx.op.tertiary.f32(i32 46, float %6985, float %28, float %7001)  ; FMad(a,b,c)
  %7003 = call float @dx.op.tertiary.f32(i32 46, float %6971, float %24, float %7002)  ; FMad(a,b,c)
  %7004 = fadd fast float %7003, %20
  %7005 = fdiv fast float %7004, %6989
  %7006 = fdiv fast float %7000, %6989
  %7007 = fdiv fast float %6996, %6989
  %7008 = fsub fast float %7005, %17
  %7009 = fsub fast float %7006, %18
  %7010 = fsub fast float %7007, %19
  %7011 = fmul fast float %7008, %7008
  %7012 = fmul fast float %7009, %7009
  %7013 = fadd fast float %7012, %7011
  %7014 = fmul fast float %7010, %7010
  %7015 = fadd fast float %7013, %7014
  %7016 = call float @dx.op.unary.f32(i32 24, float %7015)  ; Sqrt(value)
  %7017 = fsub fast float %7016, %9
  %7018 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %7017)  ; FMax(a,b)
  %7019 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %7019, label %7020, label %7043

; <label>:7020                                    ; preds = %6992
  %7021 = call float @dx.op.unary.f32(i32 6, float %7009)  ; FAbs(value)
  %7022 = fmul fast float %7021, %11
  %7023 = fcmp fast olt float %7022, 0x3F50624DE0000000
  br i1 %7023, label %7024, label %7027

; <label>:7024                                    ; preds = %7020
  %7025 = fmul fast float %7022, 5.000000e-01
  %7026 = fsub fast float 1.000000e+00, %7025
  br label %7032

; <label>:7027                                    ; preds = %7020
  %7028 = fmul fast float %7022, 0xBFF7154760000000
  %7029 = call float @dx.op.unary.f32(i32 21, float %7028)  ; Exp(value)
  %7030 = fsub fast float 1.000000e+00, %7029
  %7031 = fdiv fast float %7030, %7022
  br label %7032

; <label>:7032                                    ; preds = %7027, %7024
  %7033 = phi float [ %7026, %7024 ], [ %7031, %7027 ]
  %7034 = call float @dx.op.binary.f32(i32 36, float %7006, float %18)  ; FMin(a,b)
  %7035 = fsub fast float %7034, %10
  %7036 = fmul fast float %11, %7035
  %7037 = fsub fast float -0.000000e+00, %7036
  %7038 = call float @dx.op.binary.f32(i32 35, float %7037, float -4.000000e+01)  ; FMax(a,b)
  %7039 = call float @dx.op.binary.f32(i32 36, float %7038, float 5.000000e+00)  ; FMin(a,b)
  %7040 = fmul fast float %7039, 0x3FF7154760000000
  %7041 = call float @dx.op.unary.f32(i32 21, float %7040)  ; Exp(value)
  %7042 = fmul fast float %7041, %7033
  br label %7043

; <label>:7043                                    ; preds = %7032, %6992
  %7044 = phi float [ %7042, %7032 ], [ 1.000000e+00, %6992 ]
  %7045 = fmul fast float %7018, %16
  %7046 = fmul fast float %7045, %7044
  %7047 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %7046)  ; FMin(a,b)
  %7048 = fmul fast float %7047, 0xBFF7154760000000
  %7049 = call float @dx.op.unary.f32(i32 21, float %7048)  ; Exp(value)
  %7050 = fsub fast float 1.000000e+00, %7049
  %7051 = call float @dx.op.binary.f32(i32 36, float %12, float %7050)  ; FMin(a,b)
  %7052 = fsub fast float %13, %6930
  %7053 = fsub fast float %14, %6931
  %7054 = fsub fast float %15, %6932
  %7055 = fmul fast float %7051, %7052
  %7056 = fmul fast float %7051, %7053
  %7057 = fmul fast float %7051, %7054
  %7058 = fadd fast float %7055, %6930
  %7059 = fadd fast float %7056, %6931
  %7060 = fadd fast float %7057, %6932
  br label %7061

; <label>:7061                                    ; preds = %7043, %6975, %6969
  %7062 = phi float [ %7058, %7043 ], [ %6930, %6975 ], [ %6930, %6969 ]
  %7063 = phi float [ %7059, %7043 ], [ %6931, %6975 ], [ %6931, %6969 ]
  %7064 = phi float [ %7060, %7043 ], [ %6932, %6975 ], [ %6932, %6969 ]
  %7065 = fadd fast float %5, 1.000000e+00
  %7066 = fadd fast float %6, 1.000000e+00
  %7067 = fsub fast float 1.000000e+00, %5
  %7068 = fmul fast float %36, %7065
  %7069 = fmul fast float %36, %7066
  %7070 = fmul fast float %36, %7067
  %7071 = fmul fast float %7068, %7062
  %7072 = fmul fast float %7069, %7063
  %7073 = fmul fast float %7070, %7064
  %7074 = fcmp fast ult float %37, 5.000000e-01
  br i1 %7074, label %7100, label %7075

; <label>:7075                                    ; preds = %7061
  %7076 = fmul fast float %7071, 0x4004147AE0000000
  %7077 = fmul fast float %7072, 0x4004147AE0000000
  %7078 = fmul fast float %7073, 0x4004147AE0000000
  %7079 = fadd fast float %7076, 0x3F9EB851E0000000
  %7080 = fadd fast float %7077, 0x3F9EB851E0000000
  %7081 = fadd fast float %7078, 0x3F9EB851E0000000
  %7082 = fmul fast float %7079, %7071
  %7083 = fmul fast float %7080, %7072
  %7084 = fmul fast float %7081, %7073
  %7085 = fmul fast float %7071, 0x400370A3E0000000
  %7086 = fmul fast float %7072, 0x400370A3E0000000
  %7087 = fmul fast float %7073, 0x400370A3E0000000
  %7088 = fadd fast float %7085, 0x3FE2E147A0000000
  %7089 = fadd fast float %7086, 0x3FE2E147A0000000
  %7090 = fadd fast float %7087, 0x3FE2E147A0000000
  %7091 = fmul fast float %7088, %7071
  %7092 = fmul fast float %7089, %7072
  %7093 = fmul fast float %7090, %7073
  %7094 = fadd fast float %7091, 0x3FC1EB8520000000
  %7095 = fadd fast float %7092, 0x3FC1EB8520000000
  %7096 = fadd fast float %7093, 0x3FC1EB8520000000
  %7097 = fdiv fast float %7082, %7094
  %7098 = fdiv fast float %7083, %7095
  %7099 = fdiv fast float %7084, %7096
  br label %7100

; <label>:7100                                    ; preds = %7075, %7061
  %7101 = phi float [ %7097, %7075 ], [ %7071, %7061 ]
  %7102 = phi float [ %7098, %7075 ], [ %7072, %7061 ]
  %7103 = phi float [ %7099, %7075 ], [ %7073, %7061 ]
  %7104 = call float @dx.op.unary.f32(i32 7, float %7101)  ; Saturate(value)
  %7105 = call float @dx.op.unary.f32(i32 7, float %7102)  ; Saturate(value)
  %7106 = call float @dx.op.unary.f32(i32 7, float %7103)  ; Saturate(value)
  %7107 = call float @dx.op.dot3.f32(i32 55, float %7104, float %7105, float %7106, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %7108 = fsub fast float %7104, %7107
  %7109 = fsub fast float %7105, %7107
  %7110 = fsub fast float %7106, %7107
  %7111 = fmul fast float %7108, %8
  %7112 = fmul fast float %7109, %8
  %7113 = fmul fast float %7110, %8
  %7114 = fadd fast float %7111, %7107
  %7115 = fadd fast float %7112, %7107
  %7116 = fadd fast float %7113, %7107
  %7117 = call float @dx.op.unary.f32(i32 7, float %7114)  ; Saturate(value)
  %7118 = call float @dx.op.unary.f32(i32 7, float %7115)  ; Saturate(value)
  %7119 = call float @dx.op.unary.f32(i32 7, float %7116)  ; Saturate(value)
  %7120 = fadd fast float %7117, 0xBFC70A3D80000000
  %7121 = fadd fast float %7118, 0xBFC70A3D80000000
  %7122 = fadd fast float %7119, 0xBFC70A3D80000000
  %7123 = fmul fast float %7120, %7
  %7124 = fmul fast float %7121, %7
  %7125 = fmul fast float %7122, %7
  %7126 = fadd fast float %7123, 0x3FC70A3D80000000
  %7127 = fadd fast float %7124, 0x3FC70A3D80000000
  %7128 = fadd fast float %7125, 0x3FC70A3D80000000
  %7129 = call float @dx.op.unary.f32(i32 7, float %7126)  ; Saturate(value)
  %7130 = call float @dx.op.unary.f32(i32 7, float %7127)  ; Saturate(value)
  %7131 = call float @dx.op.unary.f32(i32 7, float %7128)  ; Saturate(value)
  br label %7132

; <label>:7132                                    ; preds = %7100, %6935
  %7133 = phi float [ %6966, %6935 ], [ %7129, %7100 ]
  %7134 = phi float [ %6967, %6935 ], [ %7130, %7100 ]
  %7135 = phi float [ %6968, %6935 ], [ %7131, %7100 ]
  %7136 = fsub fast float %7133, %6195
  %7137 = fsub fast float %7134, %6196
  %7138 = fsub fast float %7135, %6197
  %7139 = fmul fast float %7136, %6922
  %7140 = fmul fast float %7137, %6922
  %7141 = fmul fast float %7138, %6922
  %7142 = fadd fast float %7139, %6195
  %7143 = fadd fast float %7140, %6196
  %7144 = fadd fast float %7141, %6197
  br label %7145

; <label>:7145                                    ; preds = %7132, %6909
  %7146 = phi float [ %7142, %7132 ], [ %6195, %6909 ]
  %7147 = phi float [ %7143, %7132 ], [ %6196, %6909 ]
  %7148 = phi float [ %7144, %7132 ], [ %6197, %6909 ]
  %7149 = call float @dx.op.binary.f32(i32 36, float %6910, float %7146)  ; FMin(a,b)
  %7150 = call float @dx.op.binary.f32(i32 36, float %6911, float %7147)  ; FMin(a,b)
  %7151 = call float @dx.op.binary.f32(i32 36, float %6912, float %7148)  ; FMin(a,b)
  %7152 = call float @dx.op.binary.f32(i32 36, float %6436, float %6672)  ; FMin(a,b)
  %7153 = call float @dx.op.binary.f32(i32 36, float %6437, float %6673)  ; FMin(a,b)
  %7154 = call float @dx.op.binary.f32(i32 36, float %6438, float %6674)  ; FMin(a,b)
  %7155 = call float @dx.op.binary.f32(i32 36, float %7152, float %7149)  ; FMin(a,b)
  %7156 = call float @dx.op.binary.f32(i32 36, float %7153, float %7150)  ; FMin(a,b)
  %7157 = call float @dx.op.binary.f32(i32 36, float %7154, float %7151)  ; FMin(a,b)
  %7158 = call float @dx.op.binary.f32(i32 36, float %6195, float %7155)  ; FMin(a,b)
  %7159 = call float @dx.op.binary.f32(i32 36, float %6196, float %7156)  ; FMin(a,b)
  %7160 = call float @dx.op.binary.f32(i32 36, float %6197, float %7157)  ; FMin(a,b)
  %7161 = call float @dx.op.binary.f32(i32 35, float %6910, float %7146)  ; FMax(a,b)
  %7162 = call float @dx.op.binary.f32(i32 35, float %6911, float %7147)  ; FMax(a,b)
  %7163 = call float @dx.op.binary.f32(i32 35, float %6912, float %7148)  ; FMax(a,b)
  %7164 = call float @dx.op.binary.f32(i32 35, float %6436, float %6672)  ; FMax(a,b)
  %7165 = call float @dx.op.binary.f32(i32 35, float %6437, float %6673)  ; FMax(a,b)
  %7166 = call float @dx.op.binary.f32(i32 35, float %6438, float %6674)  ; FMax(a,b)
  %7167 = call float @dx.op.binary.f32(i32 35, float %7164, float %7161)  ; FMax(a,b)
  %7168 = call float @dx.op.binary.f32(i32 35, float %7165, float %7162)  ; FMax(a,b)
  %7169 = call float @dx.op.binary.f32(i32 35, float %7166, float %7163)  ; FMax(a,b)
  %7170 = call float @dx.op.binary.f32(i32 35, float %6195, float %7167)  ; FMax(a,b)
  %7171 = call float @dx.op.binary.f32(i32 35, float %6196, float %7168)  ; FMax(a,b)
  %7172 = call float @dx.op.binary.f32(i32 35, float %6197, float %7169)  ; FMax(a,b)
  %7173 = fsub fast float %7170, %7158
  %7174 = fsub fast float %7171, %7159
  %7175 = fsub fast float %7172, %7160
  %7176 = call float @dx.op.unary.f32(i32 6, float %7173)  ; FAbs(value)
  %7177 = call float @dx.op.unary.f32(i32 6, float %7174)  ; FAbs(value)
  %7178 = call float @dx.op.unary.f32(i32 6, float %7175)  ; FAbs(value)
  %7179 = call float @dx.op.binary.f32(i32 35, float %7177, float %7178)  ; FMax(a,b)
  %7180 = call float @dx.op.binary.f32(i32 35, float %7176, float %7179)  ; FMax(a,b)
  %7181 = call float @dx.op.binary.f32(i32 35, float %7171, float %7172)  ; FMax(a,b)
  %7182 = call float @dx.op.binary.f32(i32 35, float %7170, float %7181)  ; FMax(a,b)
  %7183 = fmul fast float %7182, 1.250000e-01
  %7184 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %7183)  ; FMax(a,b)
  %7185 = fcmp fast ogt float %7180, %7184
  br i1 %7185, label %7186, label %7247

; <label>:7186                                    ; preds = %7145
  %7187 = fsub fast float %6436, %6672
  %7188 = fsub fast float %6437, %6673
  %7189 = fsub fast float %6438, %6674
  %7190 = call float @dx.op.unary.f32(i32 6, float %7187)  ; FAbs(value)
  %7191 = call float @dx.op.unary.f32(i32 6, float %7188)  ; FAbs(value)
  %7192 = call float @dx.op.unary.f32(i32 6, float %7189)  ; FAbs(value)
  %7193 = call float @dx.op.binary.f32(i32 35, float %7191, float %7192)  ; FMax(a,b)
  %7194 = call float @dx.op.binary.f32(i32 35, float %7190, float %7193)  ; FMax(a,b)
  %7195 = fsub fast float %6910, %7146
  %7196 = fsub fast float %6911, %7147
  %7197 = fsub fast float %6912, %7148
  %7198 = call float @dx.op.unary.f32(i32 6, float %7195)  ; FAbs(value)
  %7199 = call float @dx.op.unary.f32(i32 6, float %7196)  ; FAbs(value)
  %7200 = call float @dx.op.unary.f32(i32 6, float %7197)  ; FAbs(value)
  %7201 = call float @dx.op.binary.f32(i32 35, float %7199, float %7200)  ; FMax(a,b)
  %7202 = call float @dx.op.binary.f32(i32 35, float %7198, float %7201)  ; FMax(a,b)
  %7203 = fcmp fast olt float %7194, %7202
  %7204 = select i1 %7203, float %6436, float %6910
  %7205 = select i1 %7203, float %6437, float %6911
  %7206 = select i1 %7203, float %6438, float %6912
  %7207 = select i1 %7203, float %6672, float %7146
  %7208 = select i1 %7203, float %6673, float %7147
  %7209 = select i1 %7203, float %6674, float %7148
  %7210 = fsub fast float %6195, %7207
  %7211 = fsub fast float %6196, %7208
  %7212 = fsub fast float %6197, %7209
  %7213 = fsub fast float %6195, %7204
  %7214 = fsub fast float %6196, %7205
  %7215 = fsub fast float %6197, %7206
  %7216 = call float @dx.op.dot3.f32(i32 55, float %7213, float %7214, float %7215, float %7210, float %7211, float %7212)  ; Dot3(ax,ay,az,bx,by,bz)
  %7217 = fcmp fast ogt float %7216, 0.000000e+00
  br i1 %7217, label %7218, label %7229

; <label>:7218                                    ; preds = %7186
  %7219 = fsub fast float %7204, %7207
  %7220 = fsub fast float %7205, %7208
  %7221 = fsub fast float %7206, %7209
  %7222 = call float @dx.op.unary.f32(i32 6, float %7219)  ; FAbs(value)
  %7223 = call float @dx.op.unary.f32(i32 6, float %7220)  ; FAbs(value)
  %7224 = call float @dx.op.unary.f32(i32 6, float %7221)  ; FAbs(value)
  %7225 = call float @dx.op.binary.f32(i32 35, float %7223, float %7224)  ; FMax(a,b)
  %7226 = call float @dx.op.binary.f32(i32 35, float %7222, float %7225)  ; FMax(a,b)
  %7227 = fmul fast float %7180, 2.500000e-01
  %7228 = fcmp fast olt float %7226, %7227
  br label %7229

; <label>:7229                                    ; preds = %7218, %7186
  %7230 = phi i1 [ false, %7186 ], [ %7228, %7218 ]
  %7231 = select i1 %7230, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  %7232 = fadd fast float %7204, %7207
  %7233 = fadd fast float %7205, %7208
  %7234 = fadd fast float %7206, %7209
  %7235 = fmul fast float %7232, 5.000000e-01
  %7236 = fmul fast float %7233, 5.000000e-01
  %7237 = fmul fast float %7234, 5.000000e-01
  %7238 = fsub fast float %7235, %6195
  %7239 = fsub fast float %7236, %6196
  %7240 = fsub fast float %7237, %6197
  %7241 = fmul fast float %7231, %7238
  %7242 = fmul fast float %7231, %7239
  %7243 = fmul fast float %7231, %7240
  %7244 = fadd fast float %7241, %6195
  %7245 = fadd fast float %7242, %6196
  %7246 = fadd fast float %7243, %6197
  br label %7247

; <label>:7247                                    ; preds = %7229, %7145, %6002
  %7248 = phi float [ %6033, %6002 ], [ %7244, %7229 ], [ %6195, %7145 ]
  %7249 = phi float [ %6034, %6002 ], [ %7245, %7229 ], [ %6196, %7145 ]
  %7250 = phi float [ %6035, %6002 ], [ %7246, %7229 ], [ %6197, %7145 ]
  %7251 = phi float [ %6036, %6002 ], [ %6000, %7229 ], [ %6000, %7145 ]
  %7252 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %67, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7253 = extractvalue %dx.types.ResRet.f32 %7252, 0
  %7254 = extractvalue %dx.types.ResRet.f32 %7252, 1
  %7255 = extractvalue %dx.types.ResRet.f32 %7252, 2
  %7256 = extractvalue %dx.types.ResRet.f32 %7252, 3
  %7257 = fcmp fast olt float %7256, 0.000000e+00
  br i1 %7257, label %7258, label %7293

; <label>:7258                                    ; preds = %7247
  %7259 = fcmp fast ogt float %7253, 0x3FA4B5DCC0000000
  %7260 = fcmp fast ogt float %7254, 0x3FA4B5DCC0000000
  %7261 = fcmp fast ogt float %7255, 0x3FA4B5DCC0000000
  %7262 = select i1 %7259, float 0.000000e+00, float 1.000000e+00
  %7263 = select i1 %7260, float 0.000000e+00, float 1.000000e+00
  %7264 = select i1 %7261, float 0.000000e+00, float 1.000000e+00
  %7265 = fmul fast float %7253, 0x3FB3D07220000000
  %7266 = fmul fast float %7254, 0x3FB3D07220000000
  %7267 = fmul fast float %7255, 0x3FB3D07220000000
  %7268 = fadd fast float %7253, 0x3FAC28F5C0000000
  %7269 = fadd fast float %7254, 0x3FAC28F5C0000000
  %7270 = fadd fast float %7255, 0x3FAC28F5C0000000
  %7271 = fmul fast float %7268, 0x3FEE54EDE0000000
  %7272 = fmul fast float %7269, 0x3FEE54EDE0000000
  %7273 = fmul fast float %7270, 0x3FEE54EDE0000000
  %7274 = call float @dx.op.unary.f32(i32 23, float %7271)  ; Log(value)
  %7275 = call float @dx.op.unary.f32(i32 23, float %7272)  ; Log(value)
  %7276 = call float @dx.op.unary.f32(i32 23, float %7273)  ; Log(value)
  %7277 = fmul fast float %7274, 0x4003333340000000
  %7278 = fmul fast float %7275, 0x4003333340000000
  %7279 = fmul fast float %7276, 0x4003333340000000
  %7280 = call float @dx.op.unary.f32(i32 21, float %7277)  ; Exp(value)
  %7281 = call float @dx.op.unary.f32(i32 21, float %7278)  ; Exp(value)
  %7282 = call float @dx.op.unary.f32(i32 21, float %7279)  ; Exp(value)
  %7283 = fsub fast float %7265, %7280
  %7284 = fsub fast float %7266, %7281
  %7285 = fsub fast float %7267, %7282
  %7286 = fmul fast float %7283, %7262
  %7287 = fmul fast float %7284, %7263
  %7288 = fmul fast float %7285, %7264
  %7289 = fadd fast float %7286, %7280
  %7290 = fadd fast float %7287, %7281
  %7291 = fadd fast float %7288, %7282
  %7292 = fsub fast float -1.000000e+00, %7256
  br label %8503

; <label>:7293                                    ; preds = %7247
  %7294 = fcmp fast ogt float %38, 5.000000e-01
  %7295 = fcmp fast olt float %88, 1.000000e+00
  %7296 = and i1 %7294, %7295
  br i1 %7296, label %7297, label %7383

; <label>:7297                                    ; preds = %7293
  %7298 = sitofp i32 %67 to float
  %7299 = sitofp i32 %70 to float
  %7300 = fadd fast float %7298, 5.000000e-01
  %7301 = fadd fast float %7299, 5.000000e-01
  %7302 = fdiv fast float %7300, %45
  %7303 = fdiv fast float %7301, %46
  %7304 = fmul fast float %7302, 2.000000e+00
  %7305 = fmul fast float %7303, 2.000000e+00
  %7306 = fadd fast float %7304, -1.000000e+00
  %7307 = fsub fast float 1.000000e+00, %7305
  %7308 = fmul fast float %7306, %35
  %7309 = call float @dx.op.tertiary.f32(i32 46, float %7307, float %31, float %7308)  ; FMad(a,b,c)
  %7310 = call float @dx.op.tertiary.f32(i32 46, float %88, float %27, float %7309)  ; FMad(a,b,c)
  %7311 = fadd fast float %7310, %23
  %7312 = call float @dx.op.unary.f32(i32 6, float %7311)  ; FAbs(value)
  %7313 = fcmp fast ogt float %7312, 0x3EB0C6F7A0000000
  br i1 %7313, label %7314, label %7383

; <label>:7314                                    ; preds = %7297
  %7315 = fmul fast float %7306, %34
  %7316 = call float @dx.op.tertiary.f32(i32 46, float %7307, float %30, float %7315)  ; FMad(a,b,c)
  %7317 = call float @dx.op.tertiary.f32(i32 46, float %88, float %26, float %7316)  ; FMad(a,b,c)
  %7318 = fadd fast float %7317, %22
  %7319 = fmul fast float %7306, %33
  %7320 = call float @dx.op.tertiary.f32(i32 46, float %7307, float %29, float %7319)  ; FMad(a,b,c)
  %7321 = call float @dx.op.tertiary.f32(i32 46, float %88, float %25, float %7320)  ; FMad(a,b,c)
  %7322 = fadd fast float %7321, %21
  %7323 = fmul fast float %7306, %32
  %7324 = call float @dx.op.tertiary.f32(i32 46, float %7307, float %28, float %7323)  ; FMad(a,b,c)
  %7325 = call float @dx.op.tertiary.f32(i32 46, float %88, float %24, float %7324)  ; FMad(a,b,c)
  %7326 = fadd fast float %7325, %20
  %7327 = fdiv fast float %7326, %7311
  %7328 = fdiv fast float %7322, %7311
  %7329 = fdiv fast float %7318, %7311
  %7330 = fsub fast float %7327, %17
  %7331 = fsub fast float %7328, %18
  %7332 = fsub fast float %7329, %19
  %7333 = fmul fast float %7330, %7330
  %7334 = fmul fast float %7331, %7331
  %7335 = fadd fast float %7334, %7333
  %7336 = fmul fast float %7332, %7332
  %7337 = fadd fast float %7335, %7336
  %7338 = call float @dx.op.unary.f32(i32 24, float %7337)  ; Sqrt(value)
  %7339 = fsub fast float %7338, %9
  %7340 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %7339)  ; FMax(a,b)
  %7341 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %7341, label %7342, label %7365

; <label>:7342                                    ; preds = %7314
  %7343 = call float @dx.op.unary.f32(i32 6, float %7331)  ; FAbs(value)
  %7344 = fmul fast float %7343, %11
  %7345 = fcmp fast olt float %7344, 0x3F50624DE0000000
  br i1 %7345, label %7346, label %7349

; <label>:7346                                    ; preds = %7342
  %7347 = fmul fast float %7344, 5.000000e-01
  %7348 = fsub fast float 1.000000e+00, %7347
  br label %7354

; <label>:7349                                    ; preds = %7342
  %7350 = fmul fast float %7344, 0xBFF7154760000000
  %7351 = call float @dx.op.unary.f32(i32 21, float %7350)  ; Exp(value)
  %7352 = fsub fast float 1.000000e+00, %7351
  %7353 = fdiv fast float %7352, %7344
  br label %7354

; <label>:7354                                    ; preds = %7349, %7346
  %7355 = phi float [ %7348, %7346 ], [ %7353, %7349 ]
  %7356 = call float @dx.op.binary.f32(i32 36, float %7328, float %18)  ; FMin(a,b)
  %7357 = fsub fast float %7356, %10
  %7358 = fmul fast float %11, %7357
  %7359 = fsub fast float -0.000000e+00, %7358
  %7360 = call float @dx.op.binary.f32(i32 35, float %7359, float -4.000000e+01)  ; FMax(a,b)
  %7361 = call float @dx.op.binary.f32(i32 36, float %7360, float 5.000000e+00)  ; FMin(a,b)
  %7362 = fmul fast float %7361, 0x3FF7154760000000
  %7363 = call float @dx.op.unary.f32(i32 21, float %7362)  ; Exp(value)
  %7364 = fmul fast float %7363, %7355
  br label %7365

; <label>:7365                                    ; preds = %7354, %7314
  %7366 = phi float [ %7364, %7354 ], [ 1.000000e+00, %7314 ]
  %7367 = fmul fast float %7340, %16
  %7368 = fmul fast float %7367, %7366
  %7369 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %7368)  ; FMin(a,b)
  %7370 = fmul fast float %7369, 0xBFF7154760000000
  %7371 = call float @dx.op.unary.f32(i32 21, float %7370)  ; Exp(value)
  %7372 = fsub fast float 1.000000e+00, %7371
  %7373 = call float @dx.op.binary.f32(i32 36, float %12, float %7372)  ; FMin(a,b)
  %7374 = fsub fast float %13, %7253
  %7375 = fsub fast float %14, %7254
  %7376 = fsub fast float %15, %7255
  %7377 = fmul fast float %7373, %7374
  %7378 = fmul fast float %7373, %7375
  %7379 = fmul fast float %7373, %7376
  %7380 = fadd fast float %7377, %7253
  %7381 = fadd fast float %7378, %7254
  %7382 = fadd fast float %7379, %7255
  br label %7383

; <label>:7383                                    ; preds = %7365, %7297, %7293
  %7384 = phi float [ %7380, %7365 ], [ %7253, %7297 ], [ %7253, %7293 ]
  %7385 = phi float [ %7381, %7365 ], [ %7254, %7297 ], [ %7254, %7293 ]
  %7386 = phi float [ %7382, %7365 ], [ %7255, %7297 ], [ %7255, %7293 ]
  %7387 = fadd fast float %5, 1.000000e+00
  %7388 = fadd fast float %6, 1.000000e+00
  %7389 = fsub fast float 1.000000e+00, %5
  %7390 = fmul fast float %36, %7387
  %7391 = fmul fast float %36, %7388
  %7392 = fmul fast float %36, %7389
  %7393 = fmul fast float %7390, %7384
  %7394 = fmul fast float %7391, %7385
  %7395 = fmul fast float %7392, %7386
  %7396 = fcmp fast ult float %37, 5.000000e-01
  br i1 %7396, label %7422, label %7397

; <label>:7397                                    ; preds = %7383
  %7398 = fmul fast float %7393, 0x4004147AE0000000
  %7399 = fmul fast float %7394, 0x4004147AE0000000
  %7400 = fmul fast float %7395, 0x4004147AE0000000
  %7401 = fadd fast float %7398, 0x3F9EB851E0000000
  %7402 = fadd fast float %7399, 0x3F9EB851E0000000
  %7403 = fadd fast float %7400, 0x3F9EB851E0000000
  %7404 = fmul fast float %7401, %7393
  %7405 = fmul fast float %7402, %7394
  %7406 = fmul fast float %7403, %7395
  %7407 = fmul fast float %7393, 0x400370A3E0000000
  %7408 = fmul fast float %7394, 0x400370A3E0000000
  %7409 = fmul fast float %7395, 0x400370A3E0000000
  %7410 = fadd fast float %7407, 0x3FE2E147A0000000
  %7411 = fadd fast float %7408, 0x3FE2E147A0000000
  %7412 = fadd fast float %7409, 0x3FE2E147A0000000
  %7413 = fmul fast float %7410, %7393
  %7414 = fmul fast float %7411, %7394
  %7415 = fmul fast float %7412, %7395
  %7416 = fadd fast float %7413, 0x3FC1EB8520000000
  %7417 = fadd fast float %7414, 0x3FC1EB8520000000
  %7418 = fadd fast float %7415, 0x3FC1EB8520000000
  %7419 = fdiv fast float %7404, %7416
  %7420 = fdiv fast float %7405, %7417
  %7421 = fdiv fast float %7406, %7418
  br label %7422

; <label>:7422                                    ; preds = %7397, %7383
  %7423 = phi float [ %7419, %7397 ], [ %7393, %7383 ]
  %7424 = phi float [ %7420, %7397 ], [ %7394, %7383 ]
  %7425 = phi float [ %7421, %7397 ], [ %7395, %7383 ]
  %7426 = call float @dx.op.unary.f32(i32 7, float %7423)  ; Saturate(value)
  %7427 = call float @dx.op.unary.f32(i32 7, float %7424)  ; Saturate(value)
  %7428 = call float @dx.op.unary.f32(i32 7, float %7425)  ; Saturate(value)
  %7429 = call float @dx.op.dot3.f32(i32 55, float %7426, float %7427, float %7428, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %7430 = fsub fast float %7426, %7429
  %7431 = fsub fast float %7427, %7429
  %7432 = fsub fast float %7428, %7429
  %7433 = fmul fast float %7430, %8
  %7434 = fmul fast float %7431, %8
  %7435 = fmul fast float %7432, %8
  %7436 = fadd fast float %7433, %7429
  %7437 = fadd fast float %7434, %7429
  %7438 = fadd fast float %7435, %7429
  %7439 = call float @dx.op.unary.f32(i32 7, float %7436)  ; Saturate(value)
  %7440 = call float @dx.op.unary.f32(i32 7, float %7437)  ; Saturate(value)
  %7441 = call float @dx.op.unary.f32(i32 7, float %7438)  ; Saturate(value)
  %7442 = fadd fast float %7439, 0xBFC70A3D80000000
  %7443 = fadd fast float %7440, 0xBFC70A3D80000000
  %7444 = fadd fast float %7441, 0xBFC70A3D80000000
  %7445 = fmul fast float %7442, %7
  %7446 = fmul fast float %7443, %7
  %7447 = fmul fast float %7444, %7
  %7448 = fadd fast float %7445, 0x3FC70A3D80000000
  %7449 = fadd fast float %7446, 0x3FC70A3D80000000
  %7450 = fadd fast float %7447, 0x3FC70A3D80000000
  %7451 = call float @dx.op.unary.f32(i32 7, float %7448)  ; Saturate(value)
  %7452 = call float @dx.op.unary.f32(i32 7, float %7449)  ; Saturate(value)
  %7453 = call float @dx.op.unary.f32(i32 7, float %7450)  ; Saturate(value)
  %7454 = add i32 %70, -1
  %7455 = call i32 @dx.op.binary.i32(i32 37, i32 %67, i32 0)  ; IMax(a,b)
  %7456 = call i32 @dx.op.binary.i32(i32 37, i32 %7454, i32 0)  ; IMax(a,b)
  %7457 = call i32 @dx.op.binary.i32(i32 38, i32 %7455, i32 %59)  ; IMin(a,b)
  %7458 = call i32 @dx.op.binary.i32(i32 38, i32 %7456, i32 %60)  ; IMin(a,b)
  %7459 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %7457, i32 %7458, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7460 = extractvalue %dx.types.ResRet.f32 %7459, 0
  %7461 = fsub fast float 1.000000e+00, %88
  %7462 = fmul fast float %7461, 0x3FA99999A0000000
  %7463 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %7462)  ; FMax(a,b)
  %7464 = fsub fast float %7460, %88
  %7465 = call float @dx.op.unary.f32(i32 6, float %7464)  ; FAbs(value)
  %7466 = fdiv fast float %7465, %7463
  %7467 = fsub fast float 1.000000e+00, %7466
  %7468 = call float @dx.op.unary.f32(i32 7, float %7467)  ; Saturate(value)
  %7469 = fcmp fast ugt float %7468, 0.000000e+00
  br i1 %7469, label %7470, label %7691

; <label>:7470                                    ; preds = %7422
  %7471 = call i32 @dx.op.binary.i32(i32 37, i32 %7457, i32 0)  ; IMax(a,b)
  %7472 = call i32 @dx.op.binary.i32(i32 37, i32 %7458, i32 0)  ; IMax(a,b)
  %7473 = call i32 @dx.op.binary.i32(i32 38, i32 %7471, i32 %59)  ; IMin(a,b)
  %7474 = call i32 @dx.op.binary.i32(i32 38, i32 %7472, i32 %60)  ; IMin(a,b)
  %7475 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %7473, i32 %7474, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7476 = extractvalue %dx.types.ResRet.f32 %7475, 0
  %7477 = extractvalue %dx.types.ResRet.f32 %7475, 1
  %7478 = extractvalue %dx.types.ResRet.f32 %7475, 2
  %7479 = extractvalue %dx.types.ResRet.f32 %7475, 3
  %7480 = fcmp fast olt float %7479, 0.000000e+00
  br i1 %7480, label %7481, label %7515

; <label>:7481                                    ; preds = %7470
  %7482 = fcmp fast ogt float %7476, 0x3FA4B5DCC0000000
  %7483 = fcmp fast ogt float %7477, 0x3FA4B5DCC0000000
  %7484 = fcmp fast ogt float %7478, 0x3FA4B5DCC0000000
  %7485 = select i1 %7482, float 0.000000e+00, float 1.000000e+00
  %7486 = select i1 %7483, float 0.000000e+00, float 1.000000e+00
  %7487 = select i1 %7484, float 0.000000e+00, float 1.000000e+00
  %7488 = fmul fast float %7476, 0x3FB3D07220000000
  %7489 = fmul fast float %7477, 0x3FB3D07220000000
  %7490 = fmul fast float %7478, 0x3FB3D07220000000
  %7491 = fadd fast float %7476, 0x3FAC28F5C0000000
  %7492 = fadd fast float %7477, 0x3FAC28F5C0000000
  %7493 = fadd fast float %7478, 0x3FAC28F5C0000000
  %7494 = fmul fast float %7491, 0x3FEE54EDE0000000
  %7495 = fmul fast float %7492, 0x3FEE54EDE0000000
  %7496 = fmul fast float %7493, 0x3FEE54EDE0000000
  %7497 = call float @dx.op.unary.f32(i32 23, float %7494)  ; Log(value)
  %7498 = call float @dx.op.unary.f32(i32 23, float %7495)  ; Log(value)
  %7499 = call float @dx.op.unary.f32(i32 23, float %7496)  ; Log(value)
  %7500 = fmul fast float %7497, 0x4003333340000000
  %7501 = fmul fast float %7498, 0x4003333340000000
  %7502 = fmul fast float %7499, 0x4003333340000000
  %7503 = call float @dx.op.unary.f32(i32 21, float %7500)  ; Exp(value)
  %7504 = call float @dx.op.unary.f32(i32 21, float %7501)  ; Exp(value)
  %7505 = call float @dx.op.unary.f32(i32 21, float %7502)  ; Exp(value)
  %7506 = fsub fast float %7488, %7503
  %7507 = fsub fast float %7489, %7504
  %7508 = fsub fast float %7490, %7505
  %7509 = fmul fast float %7506, %7485
  %7510 = fmul fast float %7507, %7486
  %7511 = fmul fast float %7508, %7487
  %7512 = fadd fast float %7509, %7503
  %7513 = fadd fast float %7510, %7504
  %7514 = fadd fast float %7511, %7505
  br label %7678

; <label>:7515                                    ; preds = %7470
  %7516 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %7473, i32 %7474, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7517 = extractvalue %dx.types.ResRet.f32 %7516, 0
  %7518 = fcmp fast ogt float %38, 5.000000e-01
  %7519 = fcmp fast olt float %7517, 1.000000e+00
  %7520 = and i1 %7518, %7519
  br i1 %7520, label %7521, label %7607

; <label>:7521                                    ; preds = %7515
  %7522 = sitofp i32 %7473 to float
  %7523 = sitofp i32 %7474 to float
  %7524 = fadd fast float %7522, 5.000000e-01
  %7525 = fadd fast float %7523, 5.000000e-01
  %7526 = fdiv fast float %7524, %45
  %7527 = fdiv fast float %7525, %46
  %7528 = fmul fast float %7526, 2.000000e+00
  %7529 = fmul fast float %7527, 2.000000e+00
  %7530 = fadd fast float %7528, -1.000000e+00
  %7531 = fsub fast float 1.000000e+00, %7529
  %7532 = fmul fast float %7530, %35
  %7533 = call float @dx.op.tertiary.f32(i32 46, float %7531, float %31, float %7532)  ; FMad(a,b,c)
  %7534 = call float @dx.op.tertiary.f32(i32 46, float %7517, float %27, float %7533)  ; FMad(a,b,c)
  %7535 = fadd fast float %7534, %23
  %7536 = call float @dx.op.unary.f32(i32 6, float %7535)  ; FAbs(value)
  %7537 = fcmp fast ogt float %7536, 0x3EB0C6F7A0000000
  br i1 %7537, label %7538, label %7607

; <label>:7538                                    ; preds = %7521
  %7539 = fmul fast float %7530, %34
  %7540 = call float @dx.op.tertiary.f32(i32 46, float %7531, float %30, float %7539)  ; FMad(a,b,c)
  %7541 = call float @dx.op.tertiary.f32(i32 46, float %7517, float %26, float %7540)  ; FMad(a,b,c)
  %7542 = fadd fast float %7541, %22
  %7543 = fmul fast float %7530, %33
  %7544 = call float @dx.op.tertiary.f32(i32 46, float %7531, float %29, float %7543)  ; FMad(a,b,c)
  %7545 = call float @dx.op.tertiary.f32(i32 46, float %7517, float %25, float %7544)  ; FMad(a,b,c)
  %7546 = fadd fast float %7545, %21
  %7547 = fmul fast float %7530, %32
  %7548 = call float @dx.op.tertiary.f32(i32 46, float %7531, float %28, float %7547)  ; FMad(a,b,c)
  %7549 = call float @dx.op.tertiary.f32(i32 46, float %7517, float %24, float %7548)  ; FMad(a,b,c)
  %7550 = fadd fast float %7549, %20
  %7551 = fdiv fast float %7550, %7535
  %7552 = fdiv fast float %7546, %7535
  %7553 = fdiv fast float %7542, %7535
  %7554 = fsub fast float %7551, %17
  %7555 = fsub fast float %7552, %18
  %7556 = fsub fast float %7553, %19
  %7557 = fmul fast float %7554, %7554
  %7558 = fmul fast float %7555, %7555
  %7559 = fadd fast float %7558, %7557
  %7560 = fmul fast float %7556, %7556
  %7561 = fadd fast float %7559, %7560
  %7562 = call float @dx.op.unary.f32(i32 24, float %7561)  ; Sqrt(value)
  %7563 = fsub fast float %7562, %9
  %7564 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %7563)  ; FMax(a,b)
  %7565 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %7565, label %7566, label %7589

; <label>:7566                                    ; preds = %7538
  %7567 = call float @dx.op.unary.f32(i32 6, float %7555)  ; FAbs(value)
  %7568 = fmul fast float %7567, %11
  %7569 = fcmp fast olt float %7568, 0x3F50624DE0000000
  br i1 %7569, label %7570, label %7573

; <label>:7570                                    ; preds = %7566
  %7571 = fmul fast float %7568, 5.000000e-01
  %7572 = fsub fast float 1.000000e+00, %7571
  br label %7578

; <label>:7573                                    ; preds = %7566
  %7574 = fmul fast float %7568, 0xBFF7154760000000
  %7575 = call float @dx.op.unary.f32(i32 21, float %7574)  ; Exp(value)
  %7576 = fsub fast float 1.000000e+00, %7575
  %7577 = fdiv fast float %7576, %7568
  br label %7578

; <label>:7578                                    ; preds = %7573, %7570
  %7579 = phi float [ %7572, %7570 ], [ %7577, %7573 ]
  %7580 = call float @dx.op.binary.f32(i32 36, float %7552, float %18)  ; FMin(a,b)
  %7581 = fsub fast float %7580, %10
  %7582 = fmul fast float %11, %7581
  %7583 = fsub fast float -0.000000e+00, %7582
  %7584 = call float @dx.op.binary.f32(i32 35, float %7583, float -4.000000e+01)  ; FMax(a,b)
  %7585 = call float @dx.op.binary.f32(i32 36, float %7584, float 5.000000e+00)  ; FMin(a,b)
  %7586 = fmul fast float %7585, 0x3FF7154760000000
  %7587 = call float @dx.op.unary.f32(i32 21, float %7586)  ; Exp(value)
  %7588 = fmul fast float %7587, %7579
  br label %7589

; <label>:7589                                    ; preds = %7578, %7538
  %7590 = phi float [ %7588, %7578 ], [ 1.000000e+00, %7538 ]
  %7591 = fmul fast float %7564, %16
  %7592 = fmul fast float %7591, %7590
  %7593 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %7592)  ; FMin(a,b)
  %7594 = fmul fast float %7593, 0xBFF7154760000000
  %7595 = call float @dx.op.unary.f32(i32 21, float %7594)  ; Exp(value)
  %7596 = fsub fast float 1.000000e+00, %7595
  %7597 = call float @dx.op.binary.f32(i32 36, float %12, float %7596)  ; FMin(a,b)
  %7598 = fsub fast float %13, %7476
  %7599 = fsub fast float %14, %7477
  %7600 = fsub fast float %15, %7478
  %7601 = fmul fast float %7597, %7598
  %7602 = fmul fast float %7597, %7599
  %7603 = fmul fast float %7597, %7600
  %7604 = fadd fast float %7601, %7476
  %7605 = fadd fast float %7602, %7477
  %7606 = fadd fast float %7603, %7478
  br label %7607

; <label>:7607                                    ; preds = %7589, %7521, %7515
  %7608 = phi float [ %7604, %7589 ], [ %7476, %7521 ], [ %7476, %7515 ]
  %7609 = phi float [ %7605, %7589 ], [ %7477, %7521 ], [ %7477, %7515 ]
  %7610 = phi float [ %7606, %7589 ], [ %7478, %7521 ], [ %7478, %7515 ]
  %7611 = fadd fast float %5, 1.000000e+00
  %7612 = fadd fast float %6, 1.000000e+00
  %7613 = fsub fast float 1.000000e+00, %5
  %7614 = fmul fast float %36, %7611
  %7615 = fmul fast float %36, %7612
  %7616 = fmul fast float %36, %7613
  %7617 = fmul fast float %7614, %7608
  %7618 = fmul fast float %7615, %7609
  %7619 = fmul fast float %7616, %7610
  %7620 = fcmp fast ult float %37, 5.000000e-01
  br i1 %7620, label %7646, label %7621

; <label>:7621                                    ; preds = %7607
  %7622 = fmul fast float %7617, 0x4004147AE0000000
  %7623 = fmul fast float %7618, 0x4004147AE0000000
  %7624 = fmul fast float %7619, 0x4004147AE0000000
  %7625 = fadd fast float %7622, 0x3F9EB851E0000000
  %7626 = fadd fast float %7623, 0x3F9EB851E0000000
  %7627 = fadd fast float %7624, 0x3F9EB851E0000000
  %7628 = fmul fast float %7625, %7617
  %7629 = fmul fast float %7626, %7618
  %7630 = fmul fast float %7627, %7619
  %7631 = fmul fast float %7617, 0x400370A3E0000000
  %7632 = fmul fast float %7618, 0x400370A3E0000000
  %7633 = fmul fast float %7619, 0x400370A3E0000000
  %7634 = fadd fast float %7631, 0x3FE2E147A0000000
  %7635 = fadd fast float %7632, 0x3FE2E147A0000000
  %7636 = fadd fast float %7633, 0x3FE2E147A0000000
  %7637 = fmul fast float %7634, %7617
  %7638 = fmul fast float %7635, %7618
  %7639 = fmul fast float %7636, %7619
  %7640 = fadd fast float %7637, 0x3FC1EB8520000000
  %7641 = fadd fast float %7638, 0x3FC1EB8520000000
  %7642 = fadd fast float %7639, 0x3FC1EB8520000000
  %7643 = fdiv fast float %7628, %7640
  %7644 = fdiv fast float %7629, %7641
  %7645 = fdiv fast float %7630, %7642
  br label %7646

; <label>:7646                                    ; preds = %7621, %7607
  %7647 = phi float [ %7643, %7621 ], [ %7617, %7607 ]
  %7648 = phi float [ %7644, %7621 ], [ %7618, %7607 ]
  %7649 = phi float [ %7645, %7621 ], [ %7619, %7607 ]
  %7650 = call float @dx.op.unary.f32(i32 7, float %7647)  ; Saturate(value)
  %7651 = call float @dx.op.unary.f32(i32 7, float %7648)  ; Saturate(value)
  %7652 = call float @dx.op.unary.f32(i32 7, float %7649)  ; Saturate(value)
  %7653 = call float @dx.op.dot3.f32(i32 55, float %7650, float %7651, float %7652, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %7654 = fsub fast float %7650, %7653
  %7655 = fsub fast float %7651, %7653
  %7656 = fsub fast float %7652, %7653
  %7657 = fmul fast float %7654, %8
  %7658 = fmul fast float %7655, %8
  %7659 = fmul fast float %7656, %8
  %7660 = fadd fast float %7657, %7653
  %7661 = fadd fast float %7658, %7653
  %7662 = fadd fast float %7659, %7653
  %7663 = call float @dx.op.unary.f32(i32 7, float %7660)  ; Saturate(value)
  %7664 = call float @dx.op.unary.f32(i32 7, float %7661)  ; Saturate(value)
  %7665 = call float @dx.op.unary.f32(i32 7, float %7662)  ; Saturate(value)
  %7666 = fadd fast float %7663, 0xBFC70A3D80000000
  %7667 = fadd fast float %7664, 0xBFC70A3D80000000
  %7668 = fadd fast float %7665, 0xBFC70A3D80000000
  %7669 = fmul fast float %7666, %7
  %7670 = fmul fast float %7667, %7
  %7671 = fmul fast float %7668, %7
  %7672 = fadd fast float %7669, 0x3FC70A3D80000000
  %7673 = fadd fast float %7670, 0x3FC70A3D80000000
  %7674 = fadd fast float %7671, 0x3FC70A3D80000000
  %7675 = call float @dx.op.unary.f32(i32 7, float %7672)  ; Saturate(value)
  %7676 = call float @dx.op.unary.f32(i32 7, float %7673)  ; Saturate(value)
  %7677 = call float @dx.op.unary.f32(i32 7, float %7674)  ; Saturate(value)
  br label %7678

; <label>:7678                                    ; preds = %7646, %7481
  %7679 = phi float [ %7512, %7481 ], [ %7675, %7646 ]
  %7680 = phi float [ %7513, %7481 ], [ %7676, %7646 ]
  %7681 = phi float [ %7514, %7481 ], [ %7677, %7646 ]
  %7682 = fsub fast float %7679, %7451
  %7683 = fsub fast float %7680, %7452
  %7684 = fsub fast float %7681, %7453
  %7685 = fmul fast float %7682, %7468
  %7686 = fmul fast float %7683, %7468
  %7687 = fmul fast float %7684, %7468
  %7688 = fadd fast float %7685, %7451
  %7689 = fadd fast float %7686, %7452
  %7690 = fadd fast float %7687, %7453
  br label %7691

; <label>:7691                                    ; preds = %7678, %7422
  %7692 = phi float [ %7688, %7678 ], [ %7451, %7422 ]
  %7693 = phi float [ %7689, %7678 ], [ %7452, %7422 ]
  %7694 = phi float [ %7690, %7678 ], [ %7453, %7422 ]
  %7695 = add i32 %70, 1
  %7696 = call i32 @dx.op.binary.i32(i32 37, i32 %7695, i32 0)  ; IMax(a,b)
  %7697 = call i32 @dx.op.binary.i32(i32 38, i32 %7696, i32 %60)  ; IMin(a,b)
  %7698 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %7457, i32 %7697, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7699 = extractvalue %dx.types.ResRet.f32 %7698, 0
  %7700 = fsub fast float %7699, %88
  %7701 = call float @dx.op.unary.f32(i32 6, float %7700)  ; FAbs(value)
  %7702 = fdiv fast float %7701, %7463
  %7703 = fsub fast float 1.000000e+00, %7702
  %7704 = call float @dx.op.unary.f32(i32 7, float %7703)  ; Saturate(value)
  %7705 = fcmp fast ugt float %7704, 0.000000e+00
  br i1 %7705, label %7706, label %7927

; <label>:7706                                    ; preds = %7691
  %7707 = call i32 @dx.op.binary.i32(i32 37, i32 %7457, i32 0)  ; IMax(a,b)
  %7708 = call i32 @dx.op.binary.i32(i32 37, i32 %7697, i32 0)  ; IMax(a,b)
  %7709 = call i32 @dx.op.binary.i32(i32 38, i32 %7707, i32 %59)  ; IMin(a,b)
  %7710 = call i32 @dx.op.binary.i32(i32 38, i32 %7708, i32 %60)  ; IMin(a,b)
  %7711 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %7709, i32 %7710, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7712 = extractvalue %dx.types.ResRet.f32 %7711, 0
  %7713 = extractvalue %dx.types.ResRet.f32 %7711, 1
  %7714 = extractvalue %dx.types.ResRet.f32 %7711, 2
  %7715 = extractvalue %dx.types.ResRet.f32 %7711, 3
  %7716 = fcmp fast olt float %7715, 0.000000e+00
  br i1 %7716, label %7717, label %7751

; <label>:7717                                    ; preds = %7706
  %7718 = fcmp fast ogt float %7712, 0x3FA4B5DCC0000000
  %7719 = fcmp fast ogt float %7713, 0x3FA4B5DCC0000000
  %7720 = fcmp fast ogt float %7714, 0x3FA4B5DCC0000000
  %7721 = select i1 %7718, float 0.000000e+00, float 1.000000e+00
  %7722 = select i1 %7719, float 0.000000e+00, float 1.000000e+00
  %7723 = select i1 %7720, float 0.000000e+00, float 1.000000e+00
  %7724 = fmul fast float %7712, 0x3FB3D07220000000
  %7725 = fmul fast float %7713, 0x3FB3D07220000000
  %7726 = fmul fast float %7714, 0x3FB3D07220000000
  %7727 = fadd fast float %7712, 0x3FAC28F5C0000000
  %7728 = fadd fast float %7713, 0x3FAC28F5C0000000
  %7729 = fadd fast float %7714, 0x3FAC28F5C0000000
  %7730 = fmul fast float %7727, 0x3FEE54EDE0000000
  %7731 = fmul fast float %7728, 0x3FEE54EDE0000000
  %7732 = fmul fast float %7729, 0x3FEE54EDE0000000
  %7733 = call float @dx.op.unary.f32(i32 23, float %7730)  ; Log(value)
  %7734 = call float @dx.op.unary.f32(i32 23, float %7731)  ; Log(value)
  %7735 = call float @dx.op.unary.f32(i32 23, float %7732)  ; Log(value)
  %7736 = fmul fast float %7733, 0x4003333340000000
  %7737 = fmul fast float %7734, 0x4003333340000000
  %7738 = fmul fast float %7735, 0x4003333340000000
  %7739 = call float @dx.op.unary.f32(i32 21, float %7736)  ; Exp(value)
  %7740 = call float @dx.op.unary.f32(i32 21, float %7737)  ; Exp(value)
  %7741 = call float @dx.op.unary.f32(i32 21, float %7738)  ; Exp(value)
  %7742 = fsub fast float %7724, %7739
  %7743 = fsub fast float %7725, %7740
  %7744 = fsub fast float %7726, %7741
  %7745 = fmul fast float %7742, %7721
  %7746 = fmul fast float %7743, %7722
  %7747 = fmul fast float %7744, %7723
  %7748 = fadd fast float %7745, %7739
  %7749 = fadd fast float %7746, %7740
  %7750 = fadd fast float %7747, %7741
  br label %7914

; <label>:7751                                    ; preds = %7706
  %7752 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %7709, i32 %7710, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7753 = extractvalue %dx.types.ResRet.f32 %7752, 0
  %7754 = fcmp fast ogt float %38, 5.000000e-01
  %7755 = fcmp fast olt float %7753, 1.000000e+00
  %7756 = and i1 %7754, %7755
  br i1 %7756, label %7757, label %7843

; <label>:7757                                    ; preds = %7751
  %7758 = sitofp i32 %7709 to float
  %7759 = sitofp i32 %7710 to float
  %7760 = fadd fast float %7758, 5.000000e-01
  %7761 = fadd fast float %7759, 5.000000e-01
  %7762 = fdiv fast float %7760, %45
  %7763 = fdiv fast float %7761, %46
  %7764 = fmul fast float %7762, 2.000000e+00
  %7765 = fmul fast float %7763, 2.000000e+00
  %7766 = fadd fast float %7764, -1.000000e+00
  %7767 = fsub fast float 1.000000e+00, %7765
  %7768 = fmul fast float %7766, %35
  %7769 = call float @dx.op.tertiary.f32(i32 46, float %7767, float %31, float %7768)  ; FMad(a,b,c)
  %7770 = call float @dx.op.tertiary.f32(i32 46, float %7753, float %27, float %7769)  ; FMad(a,b,c)
  %7771 = fadd fast float %7770, %23
  %7772 = call float @dx.op.unary.f32(i32 6, float %7771)  ; FAbs(value)
  %7773 = fcmp fast ogt float %7772, 0x3EB0C6F7A0000000
  br i1 %7773, label %7774, label %7843

; <label>:7774                                    ; preds = %7757
  %7775 = fmul fast float %7766, %34
  %7776 = call float @dx.op.tertiary.f32(i32 46, float %7767, float %30, float %7775)  ; FMad(a,b,c)
  %7777 = call float @dx.op.tertiary.f32(i32 46, float %7753, float %26, float %7776)  ; FMad(a,b,c)
  %7778 = fadd fast float %7777, %22
  %7779 = fmul fast float %7766, %33
  %7780 = call float @dx.op.tertiary.f32(i32 46, float %7767, float %29, float %7779)  ; FMad(a,b,c)
  %7781 = call float @dx.op.tertiary.f32(i32 46, float %7753, float %25, float %7780)  ; FMad(a,b,c)
  %7782 = fadd fast float %7781, %21
  %7783 = fmul fast float %7766, %32
  %7784 = call float @dx.op.tertiary.f32(i32 46, float %7767, float %28, float %7783)  ; FMad(a,b,c)
  %7785 = call float @dx.op.tertiary.f32(i32 46, float %7753, float %24, float %7784)  ; FMad(a,b,c)
  %7786 = fadd fast float %7785, %20
  %7787 = fdiv fast float %7786, %7771
  %7788 = fdiv fast float %7782, %7771
  %7789 = fdiv fast float %7778, %7771
  %7790 = fsub fast float %7787, %17
  %7791 = fsub fast float %7788, %18
  %7792 = fsub fast float %7789, %19
  %7793 = fmul fast float %7790, %7790
  %7794 = fmul fast float %7791, %7791
  %7795 = fadd fast float %7794, %7793
  %7796 = fmul fast float %7792, %7792
  %7797 = fadd fast float %7795, %7796
  %7798 = call float @dx.op.unary.f32(i32 24, float %7797)  ; Sqrt(value)
  %7799 = fsub fast float %7798, %9
  %7800 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %7799)  ; FMax(a,b)
  %7801 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %7801, label %7802, label %7825

; <label>:7802                                    ; preds = %7774
  %7803 = call float @dx.op.unary.f32(i32 6, float %7791)  ; FAbs(value)
  %7804 = fmul fast float %7803, %11
  %7805 = fcmp fast olt float %7804, 0x3F50624DE0000000
  br i1 %7805, label %7806, label %7809

; <label>:7806                                    ; preds = %7802
  %7807 = fmul fast float %7804, 5.000000e-01
  %7808 = fsub fast float 1.000000e+00, %7807
  br label %7814

; <label>:7809                                    ; preds = %7802
  %7810 = fmul fast float %7804, 0xBFF7154760000000
  %7811 = call float @dx.op.unary.f32(i32 21, float %7810)  ; Exp(value)
  %7812 = fsub fast float 1.000000e+00, %7811
  %7813 = fdiv fast float %7812, %7804
  br label %7814

; <label>:7814                                    ; preds = %7809, %7806
  %7815 = phi float [ %7808, %7806 ], [ %7813, %7809 ]
  %7816 = call float @dx.op.binary.f32(i32 36, float %7788, float %18)  ; FMin(a,b)
  %7817 = fsub fast float %7816, %10
  %7818 = fmul fast float %11, %7817
  %7819 = fsub fast float -0.000000e+00, %7818
  %7820 = call float @dx.op.binary.f32(i32 35, float %7819, float -4.000000e+01)  ; FMax(a,b)
  %7821 = call float @dx.op.binary.f32(i32 36, float %7820, float 5.000000e+00)  ; FMin(a,b)
  %7822 = fmul fast float %7821, 0x3FF7154760000000
  %7823 = call float @dx.op.unary.f32(i32 21, float %7822)  ; Exp(value)
  %7824 = fmul fast float %7823, %7815
  br label %7825

; <label>:7825                                    ; preds = %7814, %7774
  %7826 = phi float [ %7824, %7814 ], [ 1.000000e+00, %7774 ]
  %7827 = fmul fast float %7800, %16
  %7828 = fmul fast float %7827, %7826
  %7829 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %7828)  ; FMin(a,b)
  %7830 = fmul fast float %7829, 0xBFF7154760000000
  %7831 = call float @dx.op.unary.f32(i32 21, float %7830)  ; Exp(value)
  %7832 = fsub fast float 1.000000e+00, %7831
  %7833 = call float @dx.op.binary.f32(i32 36, float %12, float %7832)  ; FMin(a,b)
  %7834 = fsub fast float %13, %7712
  %7835 = fsub fast float %14, %7713
  %7836 = fsub fast float %15, %7714
  %7837 = fmul fast float %7833, %7834
  %7838 = fmul fast float %7833, %7835
  %7839 = fmul fast float %7833, %7836
  %7840 = fadd fast float %7837, %7712
  %7841 = fadd fast float %7838, %7713
  %7842 = fadd fast float %7839, %7714
  br label %7843

; <label>:7843                                    ; preds = %7825, %7757, %7751
  %7844 = phi float [ %7840, %7825 ], [ %7712, %7757 ], [ %7712, %7751 ]
  %7845 = phi float [ %7841, %7825 ], [ %7713, %7757 ], [ %7713, %7751 ]
  %7846 = phi float [ %7842, %7825 ], [ %7714, %7757 ], [ %7714, %7751 ]
  %7847 = fadd fast float %5, 1.000000e+00
  %7848 = fadd fast float %6, 1.000000e+00
  %7849 = fsub fast float 1.000000e+00, %5
  %7850 = fmul fast float %36, %7847
  %7851 = fmul fast float %36, %7848
  %7852 = fmul fast float %36, %7849
  %7853 = fmul fast float %7850, %7844
  %7854 = fmul fast float %7851, %7845
  %7855 = fmul fast float %7852, %7846
  %7856 = fcmp fast ult float %37, 5.000000e-01
  br i1 %7856, label %7882, label %7857

; <label>:7857                                    ; preds = %7843
  %7858 = fmul fast float %7853, 0x4004147AE0000000
  %7859 = fmul fast float %7854, 0x4004147AE0000000
  %7860 = fmul fast float %7855, 0x4004147AE0000000
  %7861 = fadd fast float %7858, 0x3F9EB851E0000000
  %7862 = fadd fast float %7859, 0x3F9EB851E0000000
  %7863 = fadd fast float %7860, 0x3F9EB851E0000000
  %7864 = fmul fast float %7861, %7853
  %7865 = fmul fast float %7862, %7854
  %7866 = fmul fast float %7863, %7855
  %7867 = fmul fast float %7853, 0x400370A3E0000000
  %7868 = fmul fast float %7854, 0x400370A3E0000000
  %7869 = fmul fast float %7855, 0x400370A3E0000000
  %7870 = fadd fast float %7867, 0x3FE2E147A0000000
  %7871 = fadd fast float %7868, 0x3FE2E147A0000000
  %7872 = fadd fast float %7869, 0x3FE2E147A0000000
  %7873 = fmul fast float %7870, %7853
  %7874 = fmul fast float %7871, %7854
  %7875 = fmul fast float %7872, %7855
  %7876 = fadd fast float %7873, 0x3FC1EB8520000000
  %7877 = fadd fast float %7874, 0x3FC1EB8520000000
  %7878 = fadd fast float %7875, 0x3FC1EB8520000000
  %7879 = fdiv fast float %7864, %7876
  %7880 = fdiv fast float %7865, %7877
  %7881 = fdiv fast float %7866, %7878
  br label %7882

; <label>:7882                                    ; preds = %7857, %7843
  %7883 = phi float [ %7879, %7857 ], [ %7853, %7843 ]
  %7884 = phi float [ %7880, %7857 ], [ %7854, %7843 ]
  %7885 = phi float [ %7881, %7857 ], [ %7855, %7843 ]
  %7886 = call float @dx.op.unary.f32(i32 7, float %7883)  ; Saturate(value)
  %7887 = call float @dx.op.unary.f32(i32 7, float %7884)  ; Saturate(value)
  %7888 = call float @dx.op.unary.f32(i32 7, float %7885)  ; Saturate(value)
  %7889 = call float @dx.op.dot3.f32(i32 55, float %7886, float %7887, float %7888, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %7890 = fsub fast float %7886, %7889
  %7891 = fsub fast float %7887, %7889
  %7892 = fsub fast float %7888, %7889
  %7893 = fmul fast float %7890, %8
  %7894 = fmul fast float %7891, %8
  %7895 = fmul fast float %7892, %8
  %7896 = fadd fast float %7893, %7889
  %7897 = fadd fast float %7894, %7889
  %7898 = fadd fast float %7895, %7889
  %7899 = call float @dx.op.unary.f32(i32 7, float %7896)  ; Saturate(value)
  %7900 = call float @dx.op.unary.f32(i32 7, float %7897)  ; Saturate(value)
  %7901 = call float @dx.op.unary.f32(i32 7, float %7898)  ; Saturate(value)
  %7902 = fadd fast float %7899, 0xBFC70A3D80000000
  %7903 = fadd fast float %7900, 0xBFC70A3D80000000
  %7904 = fadd fast float %7901, 0xBFC70A3D80000000
  %7905 = fmul fast float %7902, %7
  %7906 = fmul fast float %7903, %7
  %7907 = fmul fast float %7904, %7
  %7908 = fadd fast float %7905, 0x3FC70A3D80000000
  %7909 = fadd fast float %7906, 0x3FC70A3D80000000
  %7910 = fadd fast float %7907, 0x3FC70A3D80000000
  %7911 = call float @dx.op.unary.f32(i32 7, float %7908)  ; Saturate(value)
  %7912 = call float @dx.op.unary.f32(i32 7, float %7909)  ; Saturate(value)
  %7913 = call float @dx.op.unary.f32(i32 7, float %7910)  ; Saturate(value)
  br label %7914

; <label>:7914                                    ; preds = %7882, %7717
  %7915 = phi float [ %7748, %7717 ], [ %7911, %7882 ]
  %7916 = phi float [ %7749, %7717 ], [ %7912, %7882 ]
  %7917 = phi float [ %7750, %7717 ], [ %7913, %7882 ]
  %7918 = fsub fast float %7915, %7451
  %7919 = fsub fast float %7916, %7452
  %7920 = fsub fast float %7917, %7453
  %7921 = fmul fast float %7918, %7704
  %7922 = fmul fast float %7919, %7704
  %7923 = fmul fast float %7920, %7704
  %7924 = fadd fast float %7921, %7451
  %7925 = fadd fast float %7922, %7452
  %7926 = fadd fast float %7923, %7453
  br label %7927

; <label>:7927                                    ; preds = %7914, %7691
  %7928 = phi float [ %7924, %7914 ], [ %7451, %7691 ]
  %7929 = phi float [ %7925, %7914 ], [ %7452, %7691 ]
  %7930 = phi float [ %7926, %7914 ], [ %7453, %7691 ]
  %7931 = add i32 %67, -1
  %7932 = call i32 @dx.op.binary.i32(i32 37, i32 %7931, i32 0)  ; IMax(a,b)
  %7933 = call i32 @dx.op.binary.i32(i32 37, i32 %70, i32 0)  ; IMax(a,b)
  %7934 = call i32 @dx.op.binary.i32(i32 38, i32 %7932, i32 %59)  ; IMin(a,b)
  %7935 = call i32 @dx.op.binary.i32(i32 38, i32 %7933, i32 %60)  ; IMin(a,b)
  %7936 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %7934, i32 %7935, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7937 = extractvalue %dx.types.ResRet.f32 %7936, 0
  %7938 = fsub fast float %7937, %88
  %7939 = call float @dx.op.unary.f32(i32 6, float %7938)  ; FAbs(value)
  %7940 = fdiv fast float %7939, %7463
  %7941 = fsub fast float 1.000000e+00, %7940
  %7942 = call float @dx.op.unary.f32(i32 7, float %7941)  ; Saturate(value)
  %7943 = fcmp fast ugt float %7942, 0.000000e+00
  br i1 %7943, label %7944, label %8165

; <label>:7944                                    ; preds = %7927
  %7945 = call i32 @dx.op.binary.i32(i32 37, i32 %7934, i32 0)  ; IMax(a,b)
  %7946 = call i32 @dx.op.binary.i32(i32 37, i32 %7935, i32 0)  ; IMax(a,b)
  %7947 = call i32 @dx.op.binary.i32(i32 38, i32 %7945, i32 %59)  ; IMin(a,b)
  %7948 = call i32 @dx.op.binary.i32(i32 38, i32 %7946, i32 %60)  ; IMin(a,b)
  %7949 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %7947, i32 %7948, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7950 = extractvalue %dx.types.ResRet.f32 %7949, 0
  %7951 = extractvalue %dx.types.ResRet.f32 %7949, 1
  %7952 = extractvalue %dx.types.ResRet.f32 %7949, 2
  %7953 = extractvalue %dx.types.ResRet.f32 %7949, 3
  %7954 = fcmp fast olt float %7953, 0.000000e+00
  br i1 %7954, label %7955, label %7989

; <label>:7955                                    ; preds = %7944
  %7956 = fcmp fast ogt float %7950, 0x3FA4B5DCC0000000
  %7957 = fcmp fast ogt float %7951, 0x3FA4B5DCC0000000
  %7958 = fcmp fast ogt float %7952, 0x3FA4B5DCC0000000
  %7959 = select i1 %7956, float 0.000000e+00, float 1.000000e+00
  %7960 = select i1 %7957, float 0.000000e+00, float 1.000000e+00
  %7961 = select i1 %7958, float 0.000000e+00, float 1.000000e+00
  %7962 = fmul fast float %7950, 0x3FB3D07220000000
  %7963 = fmul fast float %7951, 0x3FB3D07220000000
  %7964 = fmul fast float %7952, 0x3FB3D07220000000
  %7965 = fadd fast float %7950, 0x3FAC28F5C0000000
  %7966 = fadd fast float %7951, 0x3FAC28F5C0000000
  %7967 = fadd fast float %7952, 0x3FAC28F5C0000000
  %7968 = fmul fast float %7965, 0x3FEE54EDE0000000
  %7969 = fmul fast float %7966, 0x3FEE54EDE0000000
  %7970 = fmul fast float %7967, 0x3FEE54EDE0000000
  %7971 = call float @dx.op.unary.f32(i32 23, float %7968)  ; Log(value)
  %7972 = call float @dx.op.unary.f32(i32 23, float %7969)  ; Log(value)
  %7973 = call float @dx.op.unary.f32(i32 23, float %7970)  ; Log(value)
  %7974 = fmul fast float %7971, 0x4003333340000000
  %7975 = fmul fast float %7972, 0x4003333340000000
  %7976 = fmul fast float %7973, 0x4003333340000000
  %7977 = call float @dx.op.unary.f32(i32 21, float %7974)  ; Exp(value)
  %7978 = call float @dx.op.unary.f32(i32 21, float %7975)  ; Exp(value)
  %7979 = call float @dx.op.unary.f32(i32 21, float %7976)  ; Exp(value)
  %7980 = fsub fast float %7962, %7977
  %7981 = fsub fast float %7963, %7978
  %7982 = fsub fast float %7964, %7979
  %7983 = fmul fast float %7980, %7959
  %7984 = fmul fast float %7981, %7960
  %7985 = fmul fast float %7982, %7961
  %7986 = fadd fast float %7983, %7977
  %7987 = fadd fast float %7984, %7978
  %7988 = fadd fast float %7985, %7979
  br label %8152

; <label>:7989                                    ; preds = %7944
  %7990 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %7947, i32 %7948, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7991 = extractvalue %dx.types.ResRet.f32 %7990, 0
  %7992 = fcmp fast ogt float %38, 5.000000e-01
  %7993 = fcmp fast olt float %7991, 1.000000e+00
  %7994 = and i1 %7992, %7993
  br i1 %7994, label %7995, label %8081

; <label>:7995                                    ; preds = %7989
  %7996 = sitofp i32 %7947 to float
  %7997 = sitofp i32 %7948 to float
  %7998 = fadd fast float %7996, 5.000000e-01
  %7999 = fadd fast float %7997, 5.000000e-01
  %8000 = fdiv fast float %7998, %45
  %8001 = fdiv fast float %7999, %46
  %8002 = fmul fast float %8000, 2.000000e+00
  %8003 = fmul fast float %8001, 2.000000e+00
  %8004 = fadd fast float %8002, -1.000000e+00
  %8005 = fsub fast float 1.000000e+00, %8003
  %8006 = fmul fast float %8004, %35
  %8007 = call float @dx.op.tertiary.f32(i32 46, float %8005, float %31, float %8006)  ; FMad(a,b,c)
  %8008 = call float @dx.op.tertiary.f32(i32 46, float %7991, float %27, float %8007)  ; FMad(a,b,c)
  %8009 = fadd fast float %8008, %23
  %8010 = call float @dx.op.unary.f32(i32 6, float %8009)  ; FAbs(value)
  %8011 = fcmp fast ogt float %8010, 0x3EB0C6F7A0000000
  br i1 %8011, label %8012, label %8081

; <label>:8012                                    ; preds = %7995
  %8013 = fmul fast float %8004, %34
  %8014 = call float @dx.op.tertiary.f32(i32 46, float %8005, float %30, float %8013)  ; FMad(a,b,c)
  %8015 = call float @dx.op.tertiary.f32(i32 46, float %7991, float %26, float %8014)  ; FMad(a,b,c)
  %8016 = fadd fast float %8015, %22
  %8017 = fmul fast float %8004, %33
  %8018 = call float @dx.op.tertiary.f32(i32 46, float %8005, float %29, float %8017)  ; FMad(a,b,c)
  %8019 = call float @dx.op.tertiary.f32(i32 46, float %7991, float %25, float %8018)  ; FMad(a,b,c)
  %8020 = fadd fast float %8019, %21
  %8021 = fmul fast float %8004, %32
  %8022 = call float @dx.op.tertiary.f32(i32 46, float %8005, float %28, float %8021)  ; FMad(a,b,c)
  %8023 = call float @dx.op.tertiary.f32(i32 46, float %7991, float %24, float %8022)  ; FMad(a,b,c)
  %8024 = fadd fast float %8023, %20
  %8025 = fdiv fast float %8024, %8009
  %8026 = fdiv fast float %8020, %8009
  %8027 = fdiv fast float %8016, %8009
  %8028 = fsub fast float %8025, %17
  %8029 = fsub fast float %8026, %18
  %8030 = fsub fast float %8027, %19
  %8031 = fmul fast float %8028, %8028
  %8032 = fmul fast float %8029, %8029
  %8033 = fadd fast float %8032, %8031
  %8034 = fmul fast float %8030, %8030
  %8035 = fadd fast float %8033, %8034
  %8036 = call float @dx.op.unary.f32(i32 24, float %8035)  ; Sqrt(value)
  %8037 = fsub fast float %8036, %9
  %8038 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %8037)  ; FMax(a,b)
  %8039 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %8039, label %8040, label %8063

; <label>:8040                                    ; preds = %8012
  %8041 = call float @dx.op.unary.f32(i32 6, float %8029)  ; FAbs(value)
  %8042 = fmul fast float %8041, %11
  %8043 = fcmp fast olt float %8042, 0x3F50624DE0000000
  br i1 %8043, label %8044, label %8047

; <label>:8044                                    ; preds = %8040
  %8045 = fmul fast float %8042, 5.000000e-01
  %8046 = fsub fast float 1.000000e+00, %8045
  br label %8052

; <label>:8047                                    ; preds = %8040
  %8048 = fmul fast float %8042, 0xBFF7154760000000
  %8049 = call float @dx.op.unary.f32(i32 21, float %8048)  ; Exp(value)
  %8050 = fsub fast float 1.000000e+00, %8049
  %8051 = fdiv fast float %8050, %8042
  br label %8052

; <label>:8052                                    ; preds = %8047, %8044
  %8053 = phi float [ %8046, %8044 ], [ %8051, %8047 ]
  %8054 = call float @dx.op.binary.f32(i32 36, float %8026, float %18)  ; FMin(a,b)
  %8055 = fsub fast float %8054, %10
  %8056 = fmul fast float %11, %8055
  %8057 = fsub fast float -0.000000e+00, %8056
  %8058 = call float @dx.op.binary.f32(i32 35, float %8057, float -4.000000e+01)  ; FMax(a,b)
  %8059 = call float @dx.op.binary.f32(i32 36, float %8058, float 5.000000e+00)  ; FMin(a,b)
  %8060 = fmul fast float %8059, 0x3FF7154760000000
  %8061 = call float @dx.op.unary.f32(i32 21, float %8060)  ; Exp(value)
  %8062 = fmul fast float %8061, %8053
  br label %8063

; <label>:8063                                    ; preds = %8052, %8012
  %8064 = phi float [ %8062, %8052 ], [ 1.000000e+00, %8012 ]
  %8065 = fmul fast float %8038, %16
  %8066 = fmul fast float %8065, %8064
  %8067 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %8066)  ; FMin(a,b)
  %8068 = fmul fast float %8067, 0xBFF7154760000000
  %8069 = call float @dx.op.unary.f32(i32 21, float %8068)  ; Exp(value)
  %8070 = fsub fast float 1.000000e+00, %8069
  %8071 = call float @dx.op.binary.f32(i32 36, float %12, float %8070)  ; FMin(a,b)
  %8072 = fsub fast float %13, %7950
  %8073 = fsub fast float %14, %7951
  %8074 = fsub fast float %15, %7952
  %8075 = fmul fast float %8071, %8072
  %8076 = fmul fast float %8071, %8073
  %8077 = fmul fast float %8071, %8074
  %8078 = fadd fast float %8075, %7950
  %8079 = fadd fast float %8076, %7951
  %8080 = fadd fast float %8077, %7952
  br label %8081

; <label>:8081                                    ; preds = %8063, %7995, %7989
  %8082 = phi float [ %8078, %8063 ], [ %7950, %7995 ], [ %7950, %7989 ]
  %8083 = phi float [ %8079, %8063 ], [ %7951, %7995 ], [ %7951, %7989 ]
  %8084 = phi float [ %8080, %8063 ], [ %7952, %7995 ], [ %7952, %7989 ]
  %8085 = fadd fast float %5, 1.000000e+00
  %8086 = fadd fast float %6, 1.000000e+00
  %8087 = fsub fast float 1.000000e+00, %5
  %8088 = fmul fast float %36, %8085
  %8089 = fmul fast float %36, %8086
  %8090 = fmul fast float %36, %8087
  %8091 = fmul fast float %8088, %8082
  %8092 = fmul fast float %8089, %8083
  %8093 = fmul fast float %8090, %8084
  %8094 = fcmp fast ult float %37, 5.000000e-01
  br i1 %8094, label %8120, label %8095

; <label>:8095                                    ; preds = %8081
  %8096 = fmul fast float %8091, 0x4004147AE0000000
  %8097 = fmul fast float %8092, 0x4004147AE0000000
  %8098 = fmul fast float %8093, 0x4004147AE0000000
  %8099 = fadd fast float %8096, 0x3F9EB851E0000000
  %8100 = fadd fast float %8097, 0x3F9EB851E0000000
  %8101 = fadd fast float %8098, 0x3F9EB851E0000000
  %8102 = fmul fast float %8099, %8091
  %8103 = fmul fast float %8100, %8092
  %8104 = fmul fast float %8101, %8093
  %8105 = fmul fast float %8091, 0x400370A3E0000000
  %8106 = fmul fast float %8092, 0x400370A3E0000000
  %8107 = fmul fast float %8093, 0x400370A3E0000000
  %8108 = fadd fast float %8105, 0x3FE2E147A0000000
  %8109 = fadd fast float %8106, 0x3FE2E147A0000000
  %8110 = fadd fast float %8107, 0x3FE2E147A0000000
  %8111 = fmul fast float %8108, %8091
  %8112 = fmul fast float %8109, %8092
  %8113 = fmul fast float %8110, %8093
  %8114 = fadd fast float %8111, 0x3FC1EB8520000000
  %8115 = fadd fast float %8112, 0x3FC1EB8520000000
  %8116 = fadd fast float %8113, 0x3FC1EB8520000000
  %8117 = fdiv fast float %8102, %8114
  %8118 = fdiv fast float %8103, %8115
  %8119 = fdiv fast float %8104, %8116
  br label %8120

; <label>:8120                                    ; preds = %8095, %8081
  %8121 = phi float [ %8117, %8095 ], [ %8091, %8081 ]
  %8122 = phi float [ %8118, %8095 ], [ %8092, %8081 ]
  %8123 = phi float [ %8119, %8095 ], [ %8093, %8081 ]
  %8124 = call float @dx.op.unary.f32(i32 7, float %8121)  ; Saturate(value)
  %8125 = call float @dx.op.unary.f32(i32 7, float %8122)  ; Saturate(value)
  %8126 = call float @dx.op.unary.f32(i32 7, float %8123)  ; Saturate(value)
  %8127 = call float @dx.op.dot3.f32(i32 55, float %8124, float %8125, float %8126, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %8128 = fsub fast float %8124, %8127
  %8129 = fsub fast float %8125, %8127
  %8130 = fsub fast float %8126, %8127
  %8131 = fmul fast float %8128, %8
  %8132 = fmul fast float %8129, %8
  %8133 = fmul fast float %8130, %8
  %8134 = fadd fast float %8131, %8127
  %8135 = fadd fast float %8132, %8127
  %8136 = fadd fast float %8133, %8127
  %8137 = call float @dx.op.unary.f32(i32 7, float %8134)  ; Saturate(value)
  %8138 = call float @dx.op.unary.f32(i32 7, float %8135)  ; Saturate(value)
  %8139 = call float @dx.op.unary.f32(i32 7, float %8136)  ; Saturate(value)
  %8140 = fadd fast float %8137, 0xBFC70A3D80000000
  %8141 = fadd fast float %8138, 0xBFC70A3D80000000
  %8142 = fadd fast float %8139, 0xBFC70A3D80000000
  %8143 = fmul fast float %8140, %7
  %8144 = fmul fast float %8141, %7
  %8145 = fmul fast float %8142, %7
  %8146 = fadd fast float %8143, 0x3FC70A3D80000000
  %8147 = fadd fast float %8144, 0x3FC70A3D80000000
  %8148 = fadd fast float %8145, 0x3FC70A3D80000000
  %8149 = call float @dx.op.unary.f32(i32 7, float %8146)  ; Saturate(value)
  %8150 = call float @dx.op.unary.f32(i32 7, float %8147)  ; Saturate(value)
  %8151 = call float @dx.op.unary.f32(i32 7, float %8148)  ; Saturate(value)
  br label %8152

; <label>:8152                                    ; preds = %8120, %7955
  %8153 = phi float [ %7986, %7955 ], [ %8149, %8120 ]
  %8154 = phi float [ %7987, %7955 ], [ %8150, %8120 ]
  %8155 = phi float [ %7988, %7955 ], [ %8151, %8120 ]
  %8156 = fsub fast float %8153, %7451
  %8157 = fsub fast float %8154, %7452
  %8158 = fsub fast float %8155, %7453
  %8159 = fmul fast float %8156, %7942
  %8160 = fmul fast float %8157, %7942
  %8161 = fmul fast float %8158, %7942
  %8162 = fadd fast float %8159, %7451
  %8163 = fadd fast float %8160, %7452
  %8164 = fadd fast float %8161, %7453
  br label %8165

; <label>:8165                                    ; preds = %8152, %7927
  %8166 = phi float [ %8162, %8152 ], [ %7451, %7927 ]
  %8167 = phi float [ %8163, %8152 ], [ %7452, %7927 ]
  %8168 = phi float [ %8164, %8152 ], [ %7453, %7927 ]
  %8169 = add i32 %67, 1
  %8170 = call i32 @dx.op.binary.i32(i32 37, i32 %8169, i32 0)  ; IMax(a,b)
  %8171 = call i32 @dx.op.binary.i32(i32 38, i32 %8170, i32 %59)  ; IMin(a,b)
  %8172 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %8171, i32 %7935, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %8173 = extractvalue %dx.types.ResRet.f32 %8172, 0
  %8174 = fsub fast float %8173, %88
  %8175 = call float @dx.op.unary.f32(i32 6, float %8174)  ; FAbs(value)
  %8176 = fdiv fast float %8175, %7463
  %8177 = fsub fast float 1.000000e+00, %8176
  %8178 = call float @dx.op.unary.f32(i32 7, float %8177)  ; Saturate(value)
  %8179 = fcmp fast ugt float %8178, 0.000000e+00
  br i1 %8179, label %8180, label %8401

; <label>:8180                                    ; preds = %8165
  %8181 = call i32 @dx.op.binary.i32(i32 37, i32 %8171, i32 0)  ; IMax(a,b)
  %8182 = call i32 @dx.op.binary.i32(i32 37, i32 %7935, i32 0)  ; IMax(a,b)
  %8183 = call i32 @dx.op.binary.i32(i32 38, i32 %8181, i32 %59)  ; IMin(a,b)
  %8184 = call i32 @dx.op.binary.i32(i32 38, i32 %8182, i32 %60)  ; IMin(a,b)
  %8185 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %8183, i32 %8184, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %8186 = extractvalue %dx.types.ResRet.f32 %8185, 0
  %8187 = extractvalue %dx.types.ResRet.f32 %8185, 1
  %8188 = extractvalue %dx.types.ResRet.f32 %8185, 2
  %8189 = extractvalue %dx.types.ResRet.f32 %8185, 3
  %8190 = fcmp fast olt float %8189, 0.000000e+00
  br i1 %8190, label %8191, label %8225

; <label>:8191                                    ; preds = %8180
  %8192 = fcmp fast ogt float %8186, 0x3FA4B5DCC0000000
  %8193 = fcmp fast ogt float %8187, 0x3FA4B5DCC0000000
  %8194 = fcmp fast ogt float %8188, 0x3FA4B5DCC0000000
  %8195 = select i1 %8192, float 0.000000e+00, float 1.000000e+00
  %8196 = select i1 %8193, float 0.000000e+00, float 1.000000e+00
  %8197 = select i1 %8194, float 0.000000e+00, float 1.000000e+00
  %8198 = fmul fast float %8186, 0x3FB3D07220000000
  %8199 = fmul fast float %8187, 0x3FB3D07220000000
  %8200 = fmul fast float %8188, 0x3FB3D07220000000
  %8201 = fadd fast float %8186, 0x3FAC28F5C0000000
  %8202 = fadd fast float %8187, 0x3FAC28F5C0000000
  %8203 = fadd fast float %8188, 0x3FAC28F5C0000000
  %8204 = fmul fast float %8201, 0x3FEE54EDE0000000
  %8205 = fmul fast float %8202, 0x3FEE54EDE0000000
  %8206 = fmul fast float %8203, 0x3FEE54EDE0000000
  %8207 = call float @dx.op.unary.f32(i32 23, float %8204)  ; Log(value)
  %8208 = call float @dx.op.unary.f32(i32 23, float %8205)  ; Log(value)
  %8209 = call float @dx.op.unary.f32(i32 23, float %8206)  ; Log(value)
  %8210 = fmul fast float %8207, 0x4003333340000000
  %8211 = fmul fast float %8208, 0x4003333340000000
  %8212 = fmul fast float %8209, 0x4003333340000000
  %8213 = call float @dx.op.unary.f32(i32 21, float %8210)  ; Exp(value)
  %8214 = call float @dx.op.unary.f32(i32 21, float %8211)  ; Exp(value)
  %8215 = call float @dx.op.unary.f32(i32 21, float %8212)  ; Exp(value)
  %8216 = fsub fast float %8198, %8213
  %8217 = fsub fast float %8199, %8214
  %8218 = fsub fast float %8200, %8215
  %8219 = fmul fast float %8216, %8195
  %8220 = fmul fast float %8217, %8196
  %8221 = fmul fast float %8218, %8197
  %8222 = fadd fast float %8219, %8213
  %8223 = fadd fast float %8220, %8214
  %8224 = fadd fast float %8221, %8215
  br label %8388

; <label>:8225                                    ; preds = %8180
  %8226 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %8183, i32 %8184, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %8227 = extractvalue %dx.types.ResRet.f32 %8226, 0
  %8228 = fcmp fast ogt float %38, 5.000000e-01
  %8229 = fcmp fast olt float %8227, 1.000000e+00
  %8230 = and i1 %8228, %8229
  br i1 %8230, label %8231, label %8317

; <label>:8231                                    ; preds = %8225
  %8232 = sitofp i32 %8183 to float
  %8233 = sitofp i32 %8184 to float
  %8234 = fadd fast float %8232, 5.000000e-01
  %8235 = fadd fast float %8233, 5.000000e-01
  %8236 = fdiv fast float %8234, %45
  %8237 = fdiv fast float %8235, %46
  %8238 = fmul fast float %8236, 2.000000e+00
  %8239 = fmul fast float %8237, 2.000000e+00
  %8240 = fadd fast float %8238, -1.000000e+00
  %8241 = fsub fast float 1.000000e+00, %8239
  %8242 = fmul fast float %8240, %35
  %8243 = call float @dx.op.tertiary.f32(i32 46, float %8241, float %31, float %8242)  ; FMad(a,b,c)
  %8244 = call float @dx.op.tertiary.f32(i32 46, float %8227, float %27, float %8243)  ; FMad(a,b,c)
  %8245 = fadd fast float %8244, %23
  %8246 = call float @dx.op.unary.f32(i32 6, float %8245)  ; FAbs(value)
  %8247 = fcmp fast ogt float %8246, 0x3EB0C6F7A0000000
  br i1 %8247, label %8248, label %8317

; <label>:8248                                    ; preds = %8231
  %8249 = fmul fast float %8240, %34
  %8250 = call float @dx.op.tertiary.f32(i32 46, float %8241, float %30, float %8249)  ; FMad(a,b,c)
  %8251 = call float @dx.op.tertiary.f32(i32 46, float %8227, float %26, float %8250)  ; FMad(a,b,c)
  %8252 = fadd fast float %8251, %22
  %8253 = fmul fast float %8240, %33
  %8254 = call float @dx.op.tertiary.f32(i32 46, float %8241, float %29, float %8253)  ; FMad(a,b,c)
  %8255 = call float @dx.op.tertiary.f32(i32 46, float %8227, float %25, float %8254)  ; FMad(a,b,c)
  %8256 = fadd fast float %8255, %21
  %8257 = fmul fast float %8240, %32
  %8258 = call float @dx.op.tertiary.f32(i32 46, float %8241, float %28, float %8257)  ; FMad(a,b,c)
  %8259 = call float @dx.op.tertiary.f32(i32 46, float %8227, float %24, float %8258)  ; FMad(a,b,c)
  %8260 = fadd fast float %8259, %20
  %8261 = fdiv fast float %8260, %8245
  %8262 = fdiv fast float %8256, %8245
  %8263 = fdiv fast float %8252, %8245
  %8264 = fsub fast float %8261, %17
  %8265 = fsub fast float %8262, %18
  %8266 = fsub fast float %8263, %19
  %8267 = fmul fast float %8264, %8264
  %8268 = fmul fast float %8265, %8265
  %8269 = fadd fast float %8268, %8267
  %8270 = fmul fast float %8266, %8266
  %8271 = fadd fast float %8269, %8270
  %8272 = call float @dx.op.unary.f32(i32 24, float %8271)  ; Sqrt(value)
  %8273 = fsub fast float %8272, %9
  %8274 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %8273)  ; FMax(a,b)
  %8275 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %8275, label %8276, label %8299

; <label>:8276                                    ; preds = %8248
  %8277 = call float @dx.op.unary.f32(i32 6, float %8265)  ; FAbs(value)
  %8278 = fmul fast float %8277, %11
  %8279 = fcmp fast olt float %8278, 0x3F50624DE0000000
  br i1 %8279, label %8280, label %8283

; <label>:8280                                    ; preds = %8276
  %8281 = fmul fast float %8278, 5.000000e-01
  %8282 = fsub fast float 1.000000e+00, %8281
  br label %8288

; <label>:8283                                    ; preds = %8276
  %8284 = fmul fast float %8278, 0xBFF7154760000000
  %8285 = call float @dx.op.unary.f32(i32 21, float %8284)  ; Exp(value)
  %8286 = fsub fast float 1.000000e+00, %8285
  %8287 = fdiv fast float %8286, %8278
  br label %8288

; <label>:8288                                    ; preds = %8283, %8280
  %8289 = phi float [ %8282, %8280 ], [ %8287, %8283 ]
  %8290 = call float @dx.op.binary.f32(i32 36, float %8262, float %18)  ; FMin(a,b)
  %8291 = fsub fast float %8290, %10
  %8292 = fmul fast float %11, %8291
  %8293 = fsub fast float -0.000000e+00, %8292
  %8294 = call float @dx.op.binary.f32(i32 35, float %8293, float -4.000000e+01)  ; FMax(a,b)
  %8295 = call float @dx.op.binary.f32(i32 36, float %8294, float 5.000000e+00)  ; FMin(a,b)
  %8296 = fmul fast float %8295, 0x3FF7154760000000
  %8297 = call float @dx.op.unary.f32(i32 21, float %8296)  ; Exp(value)
  %8298 = fmul fast float %8297, %8289
  br label %8299

; <label>:8299                                    ; preds = %8288, %8248
  %8300 = phi float [ %8298, %8288 ], [ 1.000000e+00, %8248 ]
  %8301 = fmul fast float %8274, %16
  %8302 = fmul fast float %8301, %8300
  %8303 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %8302)  ; FMin(a,b)
  %8304 = fmul fast float %8303, 0xBFF7154760000000
  %8305 = call float @dx.op.unary.f32(i32 21, float %8304)  ; Exp(value)
  %8306 = fsub fast float 1.000000e+00, %8305
  %8307 = call float @dx.op.binary.f32(i32 36, float %12, float %8306)  ; FMin(a,b)
  %8308 = fsub fast float %13, %8186
  %8309 = fsub fast float %14, %8187
  %8310 = fsub fast float %15, %8188
  %8311 = fmul fast float %8307, %8308
  %8312 = fmul fast float %8307, %8309
  %8313 = fmul fast float %8307, %8310
  %8314 = fadd fast float %8311, %8186
  %8315 = fadd fast float %8312, %8187
  %8316 = fadd fast float %8313, %8188
  br label %8317

; <label>:8317                                    ; preds = %8299, %8231, %8225
  %8318 = phi float [ %8314, %8299 ], [ %8186, %8231 ], [ %8186, %8225 ]
  %8319 = phi float [ %8315, %8299 ], [ %8187, %8231 ], [ %8187, %8225 ]
  %8320 = phi float [ %8316, %8299 ], [ %8188, %8231 ], [ %8188, %8225 ]
  %8321 = fadd fast float %5, 1.000000e+00
  %8322 = fadd fast float %6, 1.000000e+00
  %8323 = fsub fast float 1.000000e+00, %5
  %8324 = fmul fast float %36, %8321
  %8325 = fmul fast float %36, %8322
  %8326 = fmul fast float %36, %8323
  %8327 = fmul fast float %8324, %8318
  %8328 = fmul fast float %8325, %8319
  %8329 = fmul fast float %8326, %8320
  %8330 = fcmp fast ult float %37, 5.000000e-01
  br i1 %8330, label %8356, label %8331

; <label>:8331                                    ; preds = %8317
  %8332 = fmul fast float %8327, 0x4004147AE0000000
  %8333 = fmul fast float %8328, 0x4004147AE0000000
  %8334 = fmul fast float %8329, 0x4004147AE0000000
  %8335 = fadd fast float %8332, 0x3F9EB851E0000000
  %8336 = fadd fast float %8333, 0x3F9EB851E0000000
  %8337 = fadd fast float %8334, 0x3F9EB851E0000000
  %8338 = fmul fast float %8335, %8327
  %8339 = fmul fast float %8336, %8328
  %8340 = fmul fast float %8337, %8329
  %8341 = fmul fast float %8327, 0x400370A3E0000000
  %8342 = fmul fast float %8328, 0x400370A3E0000000
  %8343 = fmul fast float %8329, 0x400370A3E0000000
  %8344 = fadd fast float %8341, 0x3FE2E147A0000000
  %8345 = fadd fast float %8342, 0x3FE2E147A0000000
  %8346 = fadd fast float %8343, 0x3FE2E147A0000000
  %8347 = fmul fast float %8344, %8327
  %8348 = fmul fast float %8345, %8328
  %8349 = fmul fast float %8346, %8329
  %8350 = fadd fast float %8347, 0x3FC1EB8520000000
  %8351 = fadd fast float %8348, 0x3FC1EB8520000000
  %8352 = fadd fast float %8349, 0x3FC1EB8520000000
  %8353 = fdiv fast float %8338, %8350
  %8354 = fdiv fast float %8339, %8351
  %8355 = fdiv fast float %8340, %8352
  br label %8356

; <label>:8356                                    ; preds = %8331, %8317
  %8357 = phi float [ %8353, %8331 ], [ %8327, %8317 ]
  %8358 = phi float [ %8354, %8331 ], [ %8328, %8317 ]
  %8359 = phi float [ %8355, %8331 ], [ %8329, %8317 ]
  %8360 = call float @dx.op.unary.f32(i32 7, float %8357)  ; Saturate(value)
  %8361 = call float @dx.op.unary.f32(i32 7, float %8358)  ; Saturate(value)
  %8362 = call float @dx.op.unary.f32(i32 7, float %8359)  ; Saturate(value)
  %8363 = call float @dx.op.dot3.f32(i32 55, float %8360, float %8361, float %8362, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %8364 = fsub fast float %8360, %8363
  %8365 = fsub fast float %8361, %8363
  %8366 = fsub fast float %8362, %8363
  %8367 = fmul fast float %8364, %8
  %8368 = fmul fast float %8365, %8
  %8369 = fmul fast float %8366, %8
  %8370 = fadd fast float %8367, %8363
  %8371 = fadd fast float %8368, %8363
  %8372 = fadd fast float %8369, %8363
  %8373 = call float @dx.op.unary.f32(i32 7, float %8370)  ; Saturate(value)
  %8374 = call float @dx.op.unary.f32(i32 7, float %8371)  ; Saturate(value)
  %8375 = call float @dx.op.unary.f32(i32 7, float %8372)  ; Saturate(value)
  %8376 = fadd fast float %8373, 0xBFC70A3D80000000
  %8377 = fadd fast float %8374, 0xBFC70A3D80000000
  %8378 = fadd fast float %8375, 0xBFC70A3D80000000
  %8379 = fmul fast float %8376, %7
  %8380 = fmul fast float %8377, %7
  %8381 = fmul fast float %8378, %7
  %8382 = fadd fast float %8379, 0x3FC70A3D80000000
  %8383 = fadd fast float %8380, 0x3FC70A3D80000000
  %8384 = fadd fast float %8381, 0x3FC70A3D80000000
  %8385 = call float @dx.op.unary.f32(i32 7, float %8382)  ; Saturate(value)
  %8386 = call float @dx.op.unary.f32(i32 7, float %8383)  ; Saturate(value)
  %8387 = call float @dx.op.unary.f32(i32 7, float %8384)  ; Saturate(value)
  br label %8388

; <label>:8388                                    ; preds = %8356, %8191
  %8389 = phi float [ %8222, %8191 ], [ %8385, %8356 ]
  %8390 = phi float [ %8223, %8191 ], [ %8386, %8356 ]
  %8391 = phi float [ %8224, %8191 ], [ %8387, %8356 ]
  %8392 = fsub fast float %8389, %7451
  %8393 = fsub fast float %8390, %7452
  %8394 = fsub fast float %8391, %7453
  %8395 = fmul fast float %8392, %8178
  %8396 = fmul fast float %8393, %8178
  %8397 = fmul fast float %8394, %8178
  %8398 = fadd fast float %8395, %7451
  %8399 = fadd fast float %8396, %7452
  %8400 = fadd fast float %8397, %7453
  br label %8401

; <label>:8401                                    ; preds = %8388, %8165
  %8402 = phi float [ %8398, %8388 ], [ %7451, %8165 ]
  %8403 = phi float [ %8399, %8388 ], [ %7452, %8165 ]
  %8404 = phi float [ %8400, %8388 ], [ %7453, %8165 ]
  %8405 = call float @dx.op.binary.f32(i32 36, float %8166, float %8402)  ; FMin(a,b)
  %8406 = call float @dx.op.binary.f32(i32 36, float %8167, float %8403)  ; FMin(a,b)
  %8407 = call float @dx.op.binary.f32(i32 36, float %8168, float %8404)  ; FMin(a,b)
  %8408 = call float @dx.op.binary.f32(i32 36, float %7692, float %7928)  ; FMin(a,b)
  %8409 = call float @dx.op.binary.f32(i32 36, float %7693, float %7929)  ; FMin(a,b)
  %8410 = call float @dx.op.binary.f32(i32 36, float %7694, float %7930)  ; FMin(a,b)
  %8411 = call float @dx.op.binary.f32(i32 36, float %8408, float %8405)  ; FMin(a,b)
  %8412 = call float @dx.op.binary.f32(i32 36, float %8409, float %8406)  ; FMin(a,b)
  %8413 = call float @dx.op.binary.f32(i32 36, float %8410, float %8407)  ; FMin(a,b)
  %8414 = call float @dx.op.binary.f32(i32 36, float %7451, float %8411)  ; FMin(a,b)
  %8415 = call float @dx.op.binary.f32(i32 36, float %7452, float %8412)  ; FMin(a,b)
  %8416 = call float @dx.op.binary.f32(i32 36, float %7453, float %8413)  ; FMin(a,b)
  %8417 = call float @dx.op.binary.f32(i32 35, float %8166, float %8402)  ; FMax(a,b)
  %8418 = call float @dx.op.binary.f32(i32 35, float %8167, float %8403)  ; FMax(a,b)
  %8419 = call float @dx.op.binary.f32(i32 35, float %8168, float %8404)  ; FMax(a,b)
  %8420 = call float @dx.op.binary.f32(i32 35, float %7692, float %7928)  ; FMax(a,b)
  %8421 = call float @dx.op.binary.f32(i32 35, float %7693, float %7929)  ; FMax(a,b)
  %8422 = call float @dx.op.binary.f32(i32 35, float %7694, float %7930)  ; FMax(a,b)
  %8423 = call float @dx.op.binary.f32(i32 35, float %8420, float %8417)  ; FMax(a,b)
  %8424 = call float @dx.op.binary.f32(i32 35, float %8421, float %8418)  ; FMax(a,b)
  %8425 = call float @dx.op.binary.f32(i32 35, float %8422, float %8419)  ; FMax(a,b)
  %8426 = call float @dx.op.binary.f32(i32 35, float %7451, float %8423)  ; FMax(a,b)
  %8427 = call float @dx.op.binary.f32(i32 35, float %7452, float %8424)  ; FMax(a,b)
  %8428 = call float @dx.op.binary.f32(i32 35, float %7453, float %8425)  ; FMax(a,b)
  %8429 = fsub fast float %8426, %8414
  %8430 = fsub fast float %8427, %8415
  %8431 = fsub fast float %8428, %8416
  %8432 = call float @dx.op.unary.f32(i32 6, float %8429)  ; FAbs(value)
  %8433 = call float @dx.op.unary.f32(i32 6, float %8430)  ; FAbs(value)
  %8434 = call float @dx.op.unary.f32(i32 6, float %8431)  ; FAbs(value)
  %8435 = call float @dx.op.binary.f32(i32 35, float %8433, float %8434)  ; FMax(a,b)
  %8436 = call float @dx.op.binary.f32(i32 35, float %8432, float %8435)  ; FMax(a,b)
  %8437 = call float @dx.op.binary.f32(i32 35, float %8427, float %8428)  ; FMax(a,b)
  %8438 = call float @dx.op.binary.f32(i32 35, float %8426, float %8437)  ; FMax(a,b)
  %8439 = fmul fast float %8438, 1.250000e-01
  %8440 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %8439)  ; FMax(a,b)
  %8441 = fcmp fast ogt float %8436, %8440
  br i1 %8441, label %8442, label %8503

; <label>:8442                                    ; preds = %8401
  %8443 = fsub fast float %7692, %7928
  %8444 = fsub fast float %7693, %7929
  %8445 = fsub fast float %7694, %7930
  %8446 = call float @dx.op.unary.f32(i32 6, float %8443)  ; FAbs(value)
  %8447 = call float @dx.op.unary.f32(i32 6, float %8444)  ; FAbs(value)
  %8448 = call float @dx.op.unary.f32(i32 6, float %8445)  ; FAbs(value)
  %8449 = call float @dx.op.binary.f32(i32 35, float %8447, float %8448)  ; FMax(a,b)
  %8450 = call float @dx.op.binary.f32(i32 35, float %8446, float %8449)  ; FMax(a,b)
  %8451 = fsub fast float %8166, %8402
  %8452 = fsub fast float %8167, %8403
  %8453 = fsub fast float %8168, %8404
  %8454 = call float @dx.op.unary.f32(i32 6, float %8451)  ; FAbs(value)
  %8455 = call float @dx.op.unary.f32(i32 6, float %8452)  ; FAbs(value)
  %8456 = call float @dx.op.unary.f32(i32 6, float %8453)  ; FAbs(value)
  %8457 = call float @dx.op.binary.f32(i32 35, float %8455, float %8456)  ; FMax(a,b)
  %8458 = call float @dx.op.binary.f32(i32 35, float %8454, float %8457)  ; FMax(a,b)
  %8459 = fcmp fast olt float %8450, %8458
  %8460 = select i1 %8459, float %7692, float %8166
  %8461 = select i1 %8459, float %7693, float %8167
  %8462 = select i1 %8459, float %7694, float %8168
  %8463 = select i1 %8459, float %7928, float %8402
  %8464 = select i1 %8459, float %7929, float %8403
  %8465 = select i1 %8459, float %7930, float %8404
  %8466 = fsub fast float %7451, %8463
  %8467 = fsub fast float %7452, %8464
  %8468 = fsub fast float %7453, %8465
  %8469 = fsub fast float %7451, %8460
  %8470 = fsub fast float %7452, %8461
  %8471 = fsub fast float %7453, %8462
  %8472 = call float @dx.op.dot3.f32(i32 55, float %8469, float %8470, float %8471, float %8466, float %8467, float %8468)  ; Dot3(ax,ay,az,bx,by,bz)
  %8473 = fcmp fast ogt float %8472, 0.000000e+00
  br i1 %8473, label %8474, label %8486

; <label>:8474                                    ; preds = %8442
  %8475 = fsub fast float %8460, %8463
  %8476 = fsub fast float %8461, %8464
  %8477 = fsub fast float %8462, %8465
  %8478 = call float @dx.op.unary.f32(i32 6, float %8475)  ; FAbs(value)
  %8479 = call float @dx.op.unary.f32(i32 6, float %8476)  ; FAbs(value)
  %8480 = call float @dx.op.unary.f32(i32 6, float %8477)  ; FAbs(value)
  %8481 = call float @dx.op.binary.f32(i32 35, float %8479, float %8480)  ; FMax(a,b)
  %8482 = call float @dx.op.binary.f32(i32 35, float %8478, float %8481)  ; FMax(a,b)
  %8483 = fmul fast float %8436, 2.500000e-01
  %8484 = fcmp fast olt float %8482, %8483
  %8485 = select i1 %8484, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  br label %8486

; <label>:8486                                    ; preds = %8474, %8442
  %8487 = phi float [ 0x3FC99999A0000000, %8442 ], [ %8485, %8474 ]
  %8488 = fadd fast float %8460, %8463
  %8489 = fadd fast float %8461, %8464
  %8490 = fadd fast float %8462, %8465
  %8491 = fmul fast float %8488, 5.000000e-01
  %8492 = fmul fast float %8489, 5.000000e-01
  %8493 = fmul fast float %8490, 5.000000e-01
  %8494 = fsub fast float %8491, %7451
  %8495 = fsub fast float %8492, %7452
  %8496 = fsub fast float %8493, %7453
  %8497 = fmul fast float %8487, %8494
  %8498 = fmul fast float %8487, %8495
  %8499 = fmul fast float %8487, %8496
  %8500 = fadd fast float %8497, %7451
  %8501 = fadd fast float %8498, %7452
  %8502 = fadd fast float %8499, %7453
  br label %8503

; <label>:8503                                    ; preds = %8486, %8401, %7258, %3466, %3381, %2864
  %8504 = phi float [ %1627, %2864 ], [ %4736, %7258 ], [ %1627, %3466 ], [ %1627, %3381 ], [ %4736, %8486 ], [ %4736, %8401 ]
  %8505 = phi float [ %1628, %2864 ], [ %4737, %7258 ], [ %1628, %3466 ], [ %1628, %3381 ], [ %4737, %8486 ], [ %4737, %8401 ]
  %8506 = phi float [ %1629, %2864 ], [ %4738, %7258 ], [ %1629, %3466 ], [ %1629, %3381 ], [ %4738, %8486 ], [ %4738, %8401 ]
  %8507 = phi float [ %1004, %2864 ], [ %4739, %7258 ], [ %1004, %3466 ], [ %1004, %3381 ], [ %4739, %8486 ], [ %4739, %8401 ]
  %8508 = phi float [ %2246, %2864 ], [ %5992, %7258 ], [ %2246, %3466 ], [ %2246, %3381 ], [ %5992, %8486 ], [ %5992, %8401 ]
  %8509 = phi float [ %2247, %2864 ], [ %5993, %7258 ], [ %2247, %3466 ], [ %2247, %3381 ], [ %5993, %8486 ], [ %5993, %8401 ]
  %8510 = phi float [ %2248, %2864 ], [ %5994, %7258 ], [ %2248, %3466 ], [ %2248, %3381 ], [ %5994, %8486 ], [ %5994, %8401 ]
  %8511 = phi float [ %1006, %2864 ], [ %5995, %7258 ], [ %1006, %3466 ], [ %1006, %3381 ], [ %5995, %8486 ], [ %5995, %8401 ]
  %8512 = phi float [ %2865, %2864 ], [ %7248, %7258 ], [ %2865, %3466 ], [ %2865, %3381 ], [ %7248, %8486 ], [ %7248, %8401 ]
  %8513 = phi float [ %2866, %2864 ], [ %7249, %7258 ], [ %2866, %3466 ], [ %2866, %3381 ], [ %7249, %8486 ], [ %7249, %8401 ]
  %8514 = phi float [ %2867, %2864 ], [ %7250, %7258 ], [ %2867, %3466 ], [ %2867, %3381 ], [ %7250, %8486 ], [ %7250, %8401 ]
  %8515 = phi float [ %1008, %2864 ], [ %7251, %7258 ], [ %1008, %3466 ], [ %1008, %3381 ], [ %7251, %8486 ], [ %7251, %8401 ]
  %8516 = phi float [ %1000, %2864 ], [ %7289, %7258 ], [ %3480, %3466 ], [ %1000, %3381 ], [ %8500, %8486 ], [ %7451, %8401 ]
  %8517 = phi float [ %1001, %2864 ], [ %7290, %7258 ], [ %3481, %3466 ], [ %1001, %3381 ], [ %8501, %8486 ], [ %7452, %8401 ]
  %8518 = phi float [ %1002, %2864 ], [ %7291, %7258 ], [ %3482, %3466 ], [ %1002, %3381 ], [ %8502, %8486 ], [ %7453, %8401 ]
  %8519 = phi float [ %1010, %2864 ], [ %7292, %7258 ], [ %1010, %3466 ], [ %1010, %3381 ], [ %7256, %8486 ], [ %7256, %8401 ]
  %8520 = fmul fast float %8504, %162
  %8521 = fmul fast float %8505, %162
  %8522 = fmul fast float %8506, %162
  %8523 = fmul fast float %8508, %163
  %8524 = fmul fast float %8509, %163
  %8525 = fmul fast float %8510, %163
  %8526 = fadd fast float %8523, %8520
  %8527 = fadd fast float %8524, %8521
  %8528 = fadd fast float %8525, %8522
  %8529 = fmul fast float %8512, %164
  %8530 = fmul fast float %8513, %164
  %8531 = fmul fast float %8514, %164
  %8532 = fadd fast float %8526, %8529
  %8533 = fadd fast float %8527, %8530
  %8534 = fadd fast float %8528, %8531
  %8535 = fmul fast float %8516, %165
  %8536 = fmul fast float %8517, %165
  %8537 = fmul fast float %8518, %165
  %8538 = fadd fast float %8532, %8535
  %8539 = fadd fast float %8533, %8536
  %8540 = fadd fast float %8534, %8537
  %8541 = fcmp fast ogt float %8538, 0x3F69A5C380000000
  %8542 = fcmp fast ogt float %8539, 0x3F69A5C380000000
  %8543 = fcmp fast ogt float %8540, 0x3F69A5C380000000
  %8544 = select i1 %8541, float 0.000000e+00, float 1.000000e+00
  %8545 = select i1 %8542, float 0.000000e+00, float 1.000000e+00
  %8546 = select i1 %8543, float 0.000000e+00, float 1.000000e+00
  %8547 = fmul fast float %8538, 0x4029D70A40000000
  %8548 = fmul fast float %8539, 0x4029D70A40000000
  %8549 = fmul fast float %8540, 0x4029D70A40000000
  %8550 = call float @dx.op.binary.f32(i32 35, float %8538, float 0.000000e+00)  ; FMax(a,b)
  %8551 = call float @dx.op.binary.f32(i32 35, float %8539, float 0.000000e+00)  ; FMax(a,b)
  %8552 = call float @dx.op.binary.f32(i32 35, float %8540, float 0.000000e+00)  ; FMax(a,b)
  %8553 = call float @dx.op.unary.f32(i32 23, float %8550)  ; Log(value)
  %8554 = call float @dx.op.unary.f32(i32 23, float %8551)  ; Log(value)
  %8555 = call float @dx.op.unary.f32(i32 23, float %8552)  ; Log(value)
  %8556 = fmul fast float %8553, 0x3FDAAAAAA0000000
  %8557 = fmul fast float %8554, 0x3FDAAAAAA0000000
  %8558 = fmul fast float %8555, 0x3FDAAAAAA0000000
  %8559 = call float @dx.op.unary.f32(i32 21, float %8556)  ; Exp(value)
  %8560 = call float @dx.op.unary.f32(i32 21, float %8557)  ; Exp(value)
  %8561 = call float @dx.op.unary.f32(i32 21, float %8558)  ; Exp(value)
  %8562 = fmul fast float %8559, 0x3FF0E147A0000000
  %8563 = fmul fast float %8560, 0x3FF0E147A0000000
  %8564 = fmul fast float %8561, 0x3FF0E147A0000000
  %8565 = fadd fast float %8562, 0xBFAC28F5C0000000
  %8566 = fadd fast float %8563, 0xBFAC28F5C0000000
  %8567 = fadd fast float %8564, 0xBFAC28F5C0000000
  %8568 = fsub fast float %8547, %8565
  %8569 = fsub fast float %8548, %8566
  %8570 = fsub fast float %8549, %8567
  %8571 = fmul fast float %8568, %8544
  %8572 = fmul fast float %8569, %8545
  %8573 = fmul fast float %8570, %8546
  %8574 = fadd fast float %8571, %8565
  %8575 = fadd fast float %8572, %8566
  %8576 = fadd fast float %8573, %8567
  %8577 = call float @dx.op.dot4.f32(i32 56, float %8507, float %8511, float %8515, float %8519, float %162, float %163, float %164, float %165)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %8574)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %8575)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %8576)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %8577)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %80)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare i1 @dx.op.isSpecialFloat.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !38, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, !37}
!36 = !{i32 9}
!37 = !{i32 3, i32 6}
!38 = !{!39, !40}
!39 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
!40 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !41}
!41 = !{i32 3, i32 1}
