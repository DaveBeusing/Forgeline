;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float    yz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: 6a688d8399811a14f706de5c5f946991
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %40 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %41 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %42 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %43 = extractvalue %dx.types.Dimensions %42, 0
  %44 = extractvalue %dx.types.Dimensions %42, 1
  %45 = uitofp i32 %43 to float
  %46 = uitofp i32 %44 to float
  %47 = fmul fast float %45, %40
  %48 = fmul fast float %46, %41
  %49 = fdiv fast float %47, %3
  %50 = fdiv fast float %48, %4
  %51 = fadd fast float %49, -5.000000e-01
  %52 = fadd fast float %50, -5.000000e-01
  %53 = call float @dx.op.unary.f32(i32 27, float %51)  ; Round_ni(value)
  %54 = call float @dx.op.unary.f32(i32 27, float %52)  ; Round_ni(value)
  %55 = fptosi float %53 to i32
  %56 = fptosi float %54 to i32
  %57 = call float @dx.op.unary.f32(i32 22, float %51)  ; Frc(value)
  %58 = call float @dx.op.unary.f32(i32 22, float %52)  ; Frc(value)
  %59 = add i32 %43, -1
  %60 = add i32 %44, -1
  %61 = call i32 @dx.op.binary.i32(i32 37, i32 %55, i32 0)  ; IMax(a,b)
  %62 = call i32 @dx.op.binary.i32(i32 37, i32 %56, i32 0)  ; IMax(a,b)
  %63 = call i32 @dx.op.binary.i32(i32 38, i32 %61, i32 %59)  ; IMin(a,b)
  %64 = call i32 @dx.op.binary.i32(i32 38, i32 %62, i32 %60)  ; IMin(a,b)
  %65 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %66 = extractvalue %dx.types.ResRet.f32 %65, 0
  %67 = extractvalue %dx.types.ResRet.f32 %65, 1
  %68 = extractvalue %dx.types.ResRet.f32 %65, 2
  %69 = extractvalue %dx.types.ResRet.f32 %65, 3
  %70 = fcmp fast olt float %69, 0.000000e+00
  br i1 %70, label %71, label %73

; <label>:71                                      ; preds = %0
  %72 = fsub fast float -1.000000e+00, %69
  br label %324

; <label>:73                                      ; preds = %0
  %74 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %75 = extractvalue %dx.types.ResRet.f32 %74, 0
  %76 = fcmp fast ogt float %38, 5.000000e-01
  %77 = fcmp fast olt float %75, 1.000000e+00
  %78 = and i1 %76, %77
  br i1 %78, label %79, label %217

; <label>:79                                      ; preds = %73
  %80 = sitofp i32 %63 to float
  %81 = sitofp i32 %64 to float
  %82 = fadd fast float %80, 5.000000e-01
  %83 = fadd fast float %81, 5.000000e-01
  %84 = fdiv fast float %82, %45
  %85 = fdiv fast float %83, %46
  %86 = fmul fast float %84, 2.000000e+00
  %87 = fmul fast float %85, 2.000000e+00
  %88 = fadd fast float %86, -1.000000e+00
  %89 = fsub fast float 1.000000e+00, %87
  %90 = fmul fast float %88, %35
  %91 = call float @dx.op.tertiary.f32(i32 46, float %89, float %31, float %90)  ; FMad(a,b,c)
  %92 = call float @dx.op.tertiary.f32(i32 46, float %75, float %27, float %91)  ; FMad(a,b,c)
  %93 = fadd fast float %92, %23
  %94 = call float @dx.op.unary.f32(i32 6, float %93)  ; FAbs(value)
  %95 = fcmp fast ogt float %94, 0x3EB0C6F7A0000000
  br i1 %95, label %96, label %217

; <label>:96                                      ; preds = %79
  %97 = fmul fast float %88, %34
  %98 = call float @dx.op.tertiary.f32(i32 46, float %89, float %30, float %97)  ; FMad(a,b,c)
  %99 = call float @dx.op.tertiary.f32(i32 46, float %75, float %26, float %98)  ; FMad(a,b,c)
  %100 = fadd fast float %99, %22
  %101 = fmul fast float %88, %33
  %102 = call float @dx.op.tertiary.f32(i32 46, float %89, float %29, float %101)  ; FMad(a,b,c)
  %103 = call float @dx.op.tertiary.f32(i32 46, float %75, float %25, float %102)  ; FMad(a,b,c)
  %104 = fadd fast float %103, %21
  %105 = fmul fast float %88, %32
  %106 = call float @dx.op.tertiary.f32(i32 46, float %89, float %28, float %105)  ; FMad(a,b,c)
  %107 = call float @dx.op.tertiary.f32(i32 46, float %75, float %24, float %106)  ; FMad(a,b,c)
  %108 = fadd fast float %107, %20
  %109 = fdiv fast float %108, %93
  %110 = fdiv fast float %104, %93
  %111 = fdiv fast float %100, %93
  %112 = fsub fast float %109, %17
  %113 = fsub fast float %110, %18
  %114 = fsub fast float %111, %19
  %115 = fmul fast float %112, %112
  %116 = fmul fast float %113, %113
  %117 = fadd fast float %116, %115
  %118 = fmul fast float %114, %114
  %119 = fadd fast float %117, %118
  %120 = call float @dx.op.unary.f32(i32 24, float %119)  ; Sqrt(value)
  %121 = fsub fast float %120, %9
  %122 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %121)  ; FMax(a,b)
  %123 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %123, label %124, label %147

; <label>:124                                     ; preds = %96
  %125 = call float @dx.op.unary.f32(i32 6, float %113)  ; FAbs(value)
  %126 = fmul fast float %125, %11
  %127 = fcmp fast olt float %126, 0x3F50624DE0000000
  br i1 %127, label %128, label %131

; <label>:128                                     ; preds = %124
  %129 = fmul fast float %126, 5.000000e-01
  %130 = fsub fast float 1.000000e+00, %129
  br label %136

; <label>:131                                     ; preds = %124
  %132 = fmul fast float %126, 0xBFF7154760000000
  %133 = call float @dx.op.unary.f32(i32 21, float %132)  ; Exp(value)
  %134 = fsub fast float 1.000000e+00, %133
  %135 = fdiv fast float %134, %126
  br label %136

; <label>:136                                     ; preds = %131, %128
  %137 = phi float [ %130, %128 ], [ %135, %131 ]
  %138 = call float @dx.op.binary.f32(i32 36, float %110, float %18)  ; FMin(a,b)
  %139 = fsub fast float %138, %10
  %140 = fmul fast float %11, %139
  %141 = fsub fast float -0.000000e+00, %140
  %142 = call float @dx.op.binary.f32(i32 35, float %141, float -4.000000e+01)  ; FMax(a,b)
  %143 = call float @dx.op.binary.f32(i32 36, float %142, float 5.000000e+00)  ; FMin(a,b)
  %144 = fmul fast float %143, 0x3FF7154760000000
  %145 = call float @dx.op.unary.f32(i32 21, float %144)  ; Exp(value)
  %146 = fmul fast float %145, %137
  br label %147

; <label>:147                                     ; preds = %136, %96
  %148 = phi float [ %146, %136 ], [ 1.000000e+00, %96 ]
  %149 = fmul fast float %122, %16
  %150 = fmul fast float %149, %148
  %151 = fcmp fast ole float %120, %9
  %152 = fcmp fast olt float %120, 0x3F1A36E2E0000000
  %153 = or i1 %151, %152
  br i1 %153, label %200, label %154

; <label>:154                                     ; preds = %147
  %155 = fdiv fast float %9, %120
  %156 = fmul fast float %155, %112
  %157 = fmul fast float %155, %113
  %158 = fmul fast float %155, %114
  %159 = fadd fast float %156, %17
  %160 = fadd fast float %157, %18
  %161 = fadd fast float %158, %19
  %162 = fadd fast float %159, -9.000000e+02
  %163 = fadd fast float %160, -1.500000e+01
  %164 = fadd fast float %161, -7.500000e+02
  %165 = fmul fast float %162, 0x3F62345680000000
  %166 = fmul fast float %163, 0x3F62345680000000
  %167 = fmul fast float %164, 0x3F62345680000000
  %168 = call float @dx.op.dot3.f32(i32 55, float %165, float %166, float %167, float %165, float %166, float %167)  ; Dot3(ax,ay,az,bx,by,bz)
  %169 = fsub fast float 1.000000e+00, %168
  %170 = call float @dx.op.unary.f32(i32 7, float %169)  ; Saturate(value)
  %171 = fmul fast float %170, %170
  %172 = fadd fast float %159, %109
  %173 = fadd fast float %160, %110
  %174 = fadd fast float %161, %111
  %175 = fmul fast float %172, 0x3F52345680000000
  %176 = fadd fast float %175, -2.000000e+00
  %177 = fmul fast float %173, 0x3F52345680000000
  %178 = fadd fast float %177, 0xBFA1111120000000
  %179 = fmul fast float %174, 0x3F52345680000000
  %180 = fadd fast float %179, 0xBFFAAAAAC0000000
  %181 = call float @dx.op.dot3.f32(i32 55, float %176, float %178, float %180, float %176, float %178, float %180)  ; Dot3(ax,ay,az,bx,by,bz)
  %182 = fsub fast float 1.000000e+00, %181
  %183 = call float @dx.op.unary.f32(i32 7, float %182)  ; Saturate(value)
  %184 = fmul fast float %183, %183
  %185 = fmul fast float %184, 4.000000e+00
  %186 = fadd fast float %185, %171
  %187 = fadd fast float %109, -9.000000e+02
  %188 = fadd fast float %110, -1.500000e+01
  %189 = fadd fast float %111, -7.500000e+02
  %190 = fmul fast float %187, 0x3F62345680000000
  %191 = fmul fast float %188, 0x3F62345680000000
  %192 = fmul fast float %189, 0x3F62345680000000
  %193 = call float @dx.op.dot3.f32(i32 55, float %190, float %191, float %192, float %190, float %191, float %192)  ; Dot3(ax,ay,az,bx,by,bz)
  %194 = fsub fast float 1.000000e+00, %193
  %195 = call float @dx.op.unary.f32(i32 7, float %194)  ; Saturate(value)
  %196 = fmul fast float %195, %195
  %197 = fadd fast float %186, %196
  %198 = fmul fast float %121, 0x3F25D867E0000000
  %199 = fmul fast float %198, %197
  br label %200

; <label>:200                                     ; preds = %154, %147
  %201 = phi float [ %199, %154 ], [ 0.000000e+00, %147 ]
  %202 = fadd fast float %201, %150
  %203 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %202)  ; FMin(a,b)
  %204 = fmul fast float %203, 0xBFF7154760000000
  %205 = call float @dx.op.unary.f32(i32 21, float %204)  ; Exp(value)
  %206 = fsub fast float 1.000000e+00, %205
  %207 = call float @dx.op.binary.f32(i32 36, float %12, float %206)  ; FMin(a,b)
  %208 = fsub fast float %13, %66
  %209 = fsub fast float %14, %67
  %210 = fsub fast float %15, %68
  %211 = fmul fast float %207, %208
  %212 = fmul fast float %207, %209
  %213 = fmul fast float %207, %210
  %214 = fadd fast float %211, %66
  %215 = fadd fast float %212, %67
  %216 = fadd fast float %213, %68
  br label %217

; <label>:217                                     ; preds = %200, %79, %73
  %218 = phi float [ %214, %200 ], [ %66, %79 ], [ %66, %73 ]
  %219 = phi float [ %215, %200 ], [ %67, %79 ], [ %67, %73 ]
  %220 = phi float [ %216, %200 ], [ %68, %79 ], [ %68, %73 ]
  %221 = fadd fast float %5, 1.000000e+00
  %222 = fadd fast float %6, 1.000000e+00
  %223 = fsub fast float 1.000000e+00, %5
  %224 = fmul fast float %36, %221
  %225 = fmul fast float %36, %222
  %226 = fmul fast float %36, %223
  %227 = fmul fast float %224, %218
  %228 = fmul fast float %225, %219
  %229 = fmul fast float %226, %220
  %230 = fcmp fast ult float %37, 5.000000e-01
  br i1 %230, label %256, label %231

; <label>:231                                     ; preds = %217
  %232 = fmul fast float %227, 0x4004147AE0000000
  %233 = fmul fast float %228, 0x4004147AE0000000
  %234 = fmul fast float %229, 0x4004147AE0000000
  %235 = fadd fast float %232, 0x3F9EB851E0000000
  %236 = fadd fast float %233, 0x3F9EB851E0000000
  %237 = fadd fast float %234, 0x3F9EB851E0000000
  %238 = fmul fast float %235, %227
  %239 = fmul fast float %236, %228
  %240 = fmul fast float %237, %229
  %241 = fmul fast float %227, 0x400370A3E0000000
  %242 = fmul fast float %228, 0x400370A3E0000000
  %243 = fmul fast float %229, 0x400370A3E0000000
  %244 = fadd fast float %241, 0x3FE2E147A0000000
  %245 = fadd fast float %242, 0x3FE2E147A0000000
  %246 = fadd fast float %243, 0x3FE2E147A0000000
  %247 = fmul fast float %244, %227
  %248 = fmul fast float %245, %228
  %249 = fmul fast float %246, %229
  %250 = fadd fast float %247, 0x3FC1EB8520000000
  %251 = fadd fast float %248, 0x3FC1EB8520000000
  %252 = fadd fast float %249, 0x3FC1EB8520000000
  %253 = fdiv fast float %238, %250
  %254 = fdiv fast float %239, %251
  %255 = fdiv fast float %240, %252
  br label %256

; <label>:256                                     ; preds = %231, %217
  %257 = phi float [ %253, %231 ], [ %227, %217 ]
  %258 = phi float [ %254, %231 ], [ %228, %217 ]
  %259 = phi float [ %255, %231 ], [ %229, %217 ]
  %260 = call float @dx.op.unary.f32(i32 7, float %257)  ; Saturate(value)
  %261 = call float @dx.op.unary.f32(i32 7, float %258)  ; Saturate(value)
  %262 = call float @dx.op.unary.f32(i32 7, float %259)  ; Saturate(value)
  %263 = call float @dx.op.dot3.f32(i32 55, float %260, float %261, float %262, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %264 = fsub fast float %260, %263
  %265 = fsub fast float %261, %263
  %266 = fsub fast float %262, %263
  %267 = fmul fast float %264, %8
  %268 = fmul fast float %265, %8
  %269 = fmul fast float %266, %8
  %270 = fadd fast float %267, %263
  %271 = fadd fast float %268, %263
  %272 = fadd fast float %269, %263
  %273 = call float @dx.op.unary.f32(i32 7, float %270)  ; Saturate(value)
  %274 = call float @dx.op.unary.f32(i32 7, float %271)  ; Saturate(value)
  %275 = call float @dx.op.unary.f32(i32 7, float %272)  ; Saturate(value)
  %276 = fadd fast float %273, 0xBFC70A3D80000000
  %277 = fadd fast float %274, 0xBFC70A3D80000000
  %278 = fadd fast float %275, 0xBFC70A3D80000000
  %279 = fmul fast float %276, %7
  %280 = fmul fast float %277, %7
  %281 = fmul fast float %278, %7
  %282 = fadd fast float %279, 0x3FC70A3D80000000
  %283 = fadd fast float %280, 0x3FC70A3D80000000
  %284 = fadd fast float %281, 0x3FC70A3D80000000
  %285 = call float @dx.op.unary.f32(i32 7, float %282)  ; Saturate(value)
  %286 = call float @dx.op.unary.f32(i32 7, float %283)  ; Saturate(value)
  %287 = call float @dx.op.unary.f32(i32 7, float %284)  ; Saturate(value)
  %288 = fcmp fast ogt float %285, 0x3F69A5C380000000
  %289 = fcmp fast ogt float %286, 0x3F69A5C380000000
  %290 = fcmp fast ogt float %287, 0x3F69A5C380000000
  %291 = select i1 %288, float 0.000000e+00, float 1.000000e+00
  %292 = select i1 %289, float 0.000000e+00, float 1.000000e+00
  %293 = select i1 %290, float 0.000000e+00, float 1.000000e+00
  %294 = fmul fast float %285, 0x4029D70A40000000
  %295 = fmul fast float %286, 0x4029D70A40000000
  %296 = fmul fast float %287, 0x4029D70A40000000
  %297 = call float @dx.op.binary.f32(i32 35, float %285, float 0.000000e+00)  ; FMax(a,b)
  %298 = call float @dx.op.binary.f32(i32 35, float %286, float 0.000000e+00)  ; FMax(a,b)
  %299 = call float @dx.op.binary.f32(i32 35, float %287, float 0.000000e+00)  ; FMax(a,b)
  %300 = call float @dx.op.unary.f32(i32 23, float %297)  ; Log(value)
  %301 = call float @dx.op.unary.f32(i32 23, float %298)  ; Log(value)
  %302 = call float @dx.op.unary.f32(i32 23, float %299)  ; Log(value)
  %303 = fmul fast float %300, 0x3FDAAAAAA0000000
  %304 = fmul fast float %301, 0x3FDAAAAAA0000000
  %305 = fmul fast float %302, 0x3FDAAAAAA0000000
  %306 = call float @dx.op.unary.f32(i32 21, float %303)  ; Exp(value)
  %307 = call float @dx.op.unary.f32(i32 21, float %304)  ; Exp(value)
  %308 = call float @dx.op.unary.f32(i32 21, float %305)  ; Exp(value)
  %309 = fmul fast float %306, 0x3FF0E147A0000000
  %310 = fmul fast float %307, 0x3FF0E147A0000000
  %311 = fmul fast float %308, 0x3FF0E147A0000000
  %312 = fadd fast float %309, 0xBFAC28F5C0000000
  %313 = fadd fast float %310, 0xBFAC28F5C0000000
  %314 = fadd fast float %311, 0xBFAC28F5C0000000
  %315 = fsub fast float %294, %312
  %316 = fsub fast float %295, %313
  %317 = fsub fast float %296, %314
  %318 = fmul fast float %315, %291
  %319 = fmul fast float %316, %292
  %320 = fmul fast float %317, %293
  %321 = fadd fast float %318, %312
  %322 = fadd fast float %319, %313
  %323 = fadd fast float %320, %314
  br label %324

; <label>:324                                     ; preds = %256, %71
  %325 = phi float [ %66, %71 ], [ %321, %256 ]
  %326 = phi float [ %67, %71 ], [ %322, %256 ]
  %327 = phi float [ %68, %71 ], [ %323, %256 ]
  %328 = phi float [ %72, %71 ], [ %69, %256 ]
  %329 = add i32 %55, 1
  %330 = call i32 @dx.op.binary.i32(i32 37, i32 %329, i32 0)  ; IMax(a,b)
  %331 = call i32 @dx.op.binary.i32(i32 38, i32 %330, i32 %59)  ; IMin(a,b)
  %332 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %331, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %333 = extractvalue %dx.types.ResRet.f32 %332, 0
  %334 = extractvalue %dx.types.ResRet.f32 %332, 1
  %335 = extractvalue %dx.types.ResRet.f32 %332, 2
  %336 = extractvalue %dx.types.ResRet.f32 %332, 3
  %337 = fcmp fast olt float %336, 0.000000e+00
  br i1 %337, label %338, label %340

; <label>:338                                     ; preds = %324
  %339 = fsub fast float -1.000000e+00, %336
  br label %591

; <label>:340                                     ; preds = %324
  %341 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %331, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %342 = extractvalue %dx.types.ResRet.f32 %341, 0
  %343 = fcmp fast ogt float %38, 5.000000e-01
  %344 = fcmp fast olt float %342, 1.000000e+00
  %345 = and i1 %343, %344
  br i1 %345, label %346, label %484

; <label>:346                                     ; preds = %340
  %347 = sitofp i32 %331 to float
  %348 = sitofp i32 %64 to float
  %349 = fadd fast float %347, 5.000000e-01
  %350 = fadd fast float %348, 5.000000e-01
  %351 = fdiv fast float %349, %45
  %352 = fdiv fast float %350, %46
  %353 = fmul fast float %351, 2.000000e+00
  %354 = fmul fast float %352, 2.000000e+00
  %355 = fadd fast float %353, -1.000000e+00
  %356 = fsub fast float 1.000000e+00, %354
  %357 = fmul fast float %355, %35
  %358 = call float @dx.op.tertiary.f32(i32 46, float %356, float %31, float %357)  ; FMad(a,b,c)
  %359 = call float @dx.op.tertiary.f32(i32 46, float %342, float %27, float %358)  ; FMad(a,b,c)
  %360 = fadd fast float %359, %23
  %361 = call float @dx.op.unary.f32(i32 6, float %360)  ; FAbs(value)
  %362 = fcmp fast ogt float %361, 0x3EB0C6F7A0000000
  br i1 %362, label %363, label %484

; <label>:363                                     ; preds = %346
  %364 = fmul fast float %355, %34
  %365 = call float @dx.op.tertiary.f32(i32 46, float %356, float %30, float %364)  ; FMad(a,b,c)
  %366 = call float @dx.op.tertiary.f32(i32 46, float %342, float %26, float %365)  ; FMad(a,b,c)
  %367 = fadd fast float %366, %22
  %368 = fmul fast float %355, %33
  %369 = call float @dx.op.tertiary.f32(i32 46, float %356, float %29, float %368)  ; FMad(a,b,c)
  %370 = call float @dx.op.tertiary.f32(i32 46, float %342, float %25, float %369)  ; FMad(a,b,c)
  %371 = fadd fast float %370, %21
  %372 = fmul fast float %355, %32
  %373 = call float @dx.op.tertiary.f32(i32 46, float %356, float %28, float %372)  ; FMad(a,b,c)
  %374 = call float @dx.op.tertiary.f32(i32 46, float %342, float %24, float %373)  ; FMad(a,b,c)
  %375 = fadd fast float %374, %20
  %376 = fdiv fast float %375, %360
  %377 = fdiv fast float %371, %360
  %378 = fdiv fast float %367, %360
  %379 = fsub fast float %376, %17
  %380 = fsub fast float %377, %18
  %381 = fsub fast float %378, %19
  %382 = fmul fast float %379, %379
  %383 = fmul fast float %380, %380
  %384 = fadd fast float %383, %382
  %385 = fmul fast float %381, %381
  %386 = fadd fast float %384, %385
  %387 = call float @dx.op.unary.f32(i32 24, float %386)  ; Sqrt(value)
  %388 = fsub fast float %387, %9
  %389 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %388)  ; FMax(a,b)
  %390 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %390, label %391, label %414

; <label>:391                                     ; preds = %363
  %392 = call float @dx.op.unary.f32(i32 6, float %380)  ; FAbs(value)
  %393 = fmul fast float %392, %11
  %394 = fcmp fast olt float %393, 0x3F50624DE0000000
  br i1 %394, label %395, label %398

; <label>:395                                     ; preds = %391
  %396 = fmul fast float %393, 5.000000e-01
  %397 = fsub fast float 1.000000e+00, %396
  br label %403

; <label>:398                                     ; preds = %391
  %399 = fmul fast float %393, 0xBFF7154760000000
  %400 = call float @dx.op.unary.f32(i32 21, float %399)  ; Exp(value)
  %401 = fsub fast float 1.000000e+00, %400
  %402 = fdiv fast float %401, %393
  br label %403

; <label>:403                                     ; preds = %398, %395
  %404 = phi float [ %397, %395 ], [ %402, %398 ]
  %405 = call float @dx.op.binary.f32(i32 36, float %377, float %18)  ; FMin(a,b)
  %406 = fsub fast float %405, %10
  %407 = fmul fast float %11, %406
  %408 = fsub fast float -0.000000e+00, %407
  %409 = call float @dx.op.binary.f32(i32 35, float %408, float -4.000000e+01)  ; FMax(a,b)
  %410 = call float @dx.op.binary.f32(i32 36, float %409, float 5.000000e+00)  ; FMin(a,b)
  %411 = fmul fast float %410, 0x3FF7154760000000
  %412 = call float @dx.op.unary.f32(i32 21, float %411)  ; Exp(value)
  %413 = fmul fast float %412, %404
  br label %414

; <label>:414                                     ; preds = %403, %363
  %415 = phi float [ %413, %403 ], [ 1.000000e+00, %363 ]
  %416 = fmul fast float %389, %16
  %417 = fmul fast float %416, %415
  %418 = fcmp fast ole float %387, %9
  %419 = fcmp fast olt float %387, 0x3F1A36E2E0000000
  %420 = or i1 %418, %419
  br i1 %420, label %467, label %421

; <label>:421                                     ; preds = %414
  %422 = fdiv fast float %9, %387
  %423 = fmul fast float %422, %379
  %424 = fmul fast float %422, %380
  %425 = fmul fast float %422, %381
  %426 = fadd fast float %423, %17
  %427 = fadd fast float %424, %18
  %428 = fadd fast float %425, %19
  %429 = fadd fast float %426, -9.000000e+02
  %430 = fadd fast float %427, -1.500000e+01
  %431 = fadd fast float %428, -7.500000e+02
  %432 = fmul fast float %429, 0x3F62345680000000
  %433 = fmul fast float %430, 0x3F62345680000000
  %434 = fmul fast float %431, 0x3F62345680000000
  %435 = call float @dx.op.dot3.f32(i32 55, float %432, float %433, float %434, float %432, float %433, float %434)  ; Dot3(ax,ay,az,bx,by,bz)
  %436 = fsub fast float 1.000000e+00, %435
  %437 = call float @dx.op.unary.f32(i32 7, float %436)  ; Saturate(value)
  %438 = fmul fast float %437, %437
  %439 = fadd fast float %426, %376
  %440 = fadd fast float %427, %377
  %441 = fadd fast float %428, %378
  %442 = fmul fast float %439, 0x3F52345680000000
  %443 = fadd fast float %442, -2.000000e+00
  %444 = fmul fast float %440, 0x3F52345680000000
  %445 = fadd fast float %444, 0xBFA1111120000000
  %446 = fmul fast float %441, 0x3F52345680000000
  %447 = fadd fast float %446, 0xBFFAAAAAC0000000
  %448 = call float @dx.op.dot3.f32(i32 55, float %443, float %445, float %447, float %443, float %445, float %447)  ; Dot3(ax,ay,az,bx,by,bz)
  %449 = fsub fast float 1.000000e+00, %448
  %450 = call float @dx.op.unary.f32(i32 7, float %449)  ; Saturate(value)
  %451 = fmul fast float %450, %450
  %452 = fmul fast float %451, 4.000000e+00
  %453 = fadd fast float %452, %438
  %454 = fadd fast float %376, -9.000000e+02
  %455 = fadd fast float %377, -1.500000e+01
  %456 = fadd fast float %378, -7.500000e+02
  %457 = fmul fast float %454, 0x3F62345680000000
  %458 = fmul fast float %455, 0x3F62345680000000
  %459 = fmul fast float %456, 0x3F62345680000000
  %460 = call float @dx.op.dot3.f32(i32 55, float %457, float %458, float %459, float %457, float %458, float %459)  ; Dot3(ax,ay,az,bx,by,bz)
  %461 = fsub fast float 1.000000e+00, %460
  %462 = call float @dx.op.unary.f32(i32 7, float %461)  ; Saturate(value)
  %463 = fmul fast float %462, %462
  %464 = fadd fast float %453, %463
  %465 = fmul fast float %388, 0x3F25D867E0000000
  %466 = fmul fast float %465, %464
  br label %467

; <label>:467                                     ; preds = %421, %414
  %468 = phi float [ %466, %421 ], [ 0.000000e+00, %414 ]
  %469 = fadd fast float %468, %417
  %470 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %469)  ; FMin(a,b)
  %471 = fmul fast float %470, 0xBFF7154760000000
  %472 = call float @dx.op.unary.f32(i32 21, float %471)  ; Exp(value)
  %473 = fsub fast float 1.000000e+00, %472
  %474 = call float @dx.op.binary.f32(i32 36, float %12, float %473)  ; FMin(a,b)
  %475 = fsub fast float %13, %333
  %476 = fsub fast float %14, %334
  %477 = fsub fast float %15, %335
  %478 = fmul fast float %474, %475
  %479 = fmul fast float %474, %476
  %480 = fmul fast float %474, %477
  %481 = fadd fast float %478, %333
  %482 = fadd fast float %479, %334
  %483 = fadd fast float %480, %335
  br label %484

; <label>:484                                     ; preds = %467, %346, %340
  %485 = phi float [ %481, %467 ], [ %333, %346 ], [ %333, %340 ]
  %486 = phi float [ %482, %467 ], [ %334, %346 ], [ %334, %340 ]
  %487 = phi float [ %483, %467 ], [ %335, %346 ], [ %335, %340 ]
  %488 = fadd fast float %5, 1.000000e+00
  %489 = fadd fast float %6, 1.000000e+00
  %490 = fsub fast float 1.000000e+00, %5
  %491 = fmul fast float %36, %488
  %492 = fmul fast float %36, %489
  %493 = fmul fast float %36, %490
  %494 = fmul fast float %491, %485
  %495 = fmul fast float %492, %486
  %496 = fmul fast float %493, %487
  %497 = fcmp fast ult float %37, 5.000000e-01
  br i1 %497, label %523, label %498

; <label>:498                                     ; preds = %484
  %499 = fmul fast float %494, 0x4004147AE0000000
  %500 = fmul fast float %495, 0x4004147AE0000000
  %501 = fmul fast float %496, 0x4004147AE0000000
  %502 = fadd fast float %499, 0x3F9EB851E0000000
  %503 = fadd fast float %500, 0x3F9EB851E0000000
  %504 = fadd fast float %501, 0x3F9EB851E0000000
  %505 = fmul fast float %502, %494
  %506 = fmul fast float %503, %495
  %507 = fmul fast float %504, %496
  %508 = fmul fast float %494, 0x400370A3E0000000
  %509 = fmul fast float %495, 0x400370A3E0000000
  %510 = fmul fast float %496, 0x400370A3E0000000
  %511 = fadd fast float %508, 0x3FE2E147A0000000
  %512 = fadd fast float %509, 0x3FE2E147A0000000
  %513 = fadd fast float %510, 0x3FE2E147A0000000
  %514 = fmul fast float %511, %494
  %515 = fmul fast float %512, %495
  %516 = fmul fast float %513, %496
  %517 = fadd fast float %514, 0x3FC1EB8520000000
  %518 = fadd fast float %515, 0x3FC1EB8520000000
  %519 = fadd fast float %516, 0x3FC1EB8520000000
  %520 = fdiv fast float %505, %517
  %521 = fdiv fast float %506, %518
  %522 = fdiv fast float %507, %519
  br label %523

; <label>:523                                     ; preds = %498, %484
  %524 = phi float [ %520, %498 ], [ %494, %484 ]
  %525 = phi float [ %521, %498 ], [ %495, %484 ]
  %526 = phi float [ %522, %498 ], [ %496, %484 ]
  %527 = call float @dx.op.unary.f32(i32 7, float %524)  ; Saturate(value)
  %528 = call float @dx.op.unary.f32(i32 7, float %525)  ; Saturate(value)
  %529 = call float @dx.op.unary.f32(i32 7, float %526)  ; Saturate(value)
  %530 = call float @dx.op.dot3.f32(i32 55, float %527, float %528, float %529, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %531 = fsub fast float %527, %530
  %532 = fsub fast float %528, %530
  %533 = fsub fast float %529, %530
  %534 = fmul fast float %531, %8
  %535 = fmul fast float %532, %8
  %536 = fmul fast float %533, %8
  %537 = fadd fast float %534, %530
  %538 = fadd fast float %535, %530
  %539 = fadd fast float %536, %530
  %540 = call float @dx.op.unary.f32(i32 7, float %537)  ; Saturate(value)
  %541 = call float @dx.op.unary.f32(i32 7, float %538)  ; Saturate(value)
  %542 = call float @dx.op.unary.f32(i32 7, float %539)  ; Saturate(value)
  %543 = fadd fast float %540, 0xBFC70A3D80000000
  %544 = fadd fast float %541, 0xBFC70A3D80000000
  %545 = fadd fast float %542, 0xBFC70A3D80000000
  %546 = fmul fast float %543, %7
  %547 = fmul fast float %544, %7
  %548 = fmul fast float %545, %7
  %549 = fadd fast float %546, 0x3FC70A3D80000000
  %550 = fadd fast float %547, 0x3FC70A3D80000000
  %551 = fadd fast float %548, 0x3FC70A3D80000000
  %552 = call float @dx.op.unary.f32(i32 7, float %549)  ; Saturate(value)
  %553 = call float @dx.op.unary.f32(i32 7, float %550)  ; Saturate(value)
  %554 = call float @dx.op.unary.f32(i32 7, float %551)  ; Saturate(value)
  %555 = fcmp fast ogt float %552, 0x3F69A5C380000000
  %556 = fcmp fast ogt float %553, 0x3F69A5C380000000
  %557 = fcmp fast ogt float %554, 0x3F69A5C380000000
  %558 = select i1 %555, float 0.000000e+00, float 1.000000e+00
  %559 = select i1 %556, float 0.000000e+00, float 1.000000e+00
  %560 = select i1 %557, float 0.000000e+00, float 1.000000e+00
  %561 = fmul fast float %552, 0x4029D70A40000000
  %562 = fmul fast float %553, 0x4029D70A40000000
  %563 = fmul fast float %554, 0x4029D70A40000000
  %564 = call float @dx.op.binary.f32(i32 35, float %552, float 0.000000e+00)  ; FMax(a,b)
  %565 = call float @dx.op.binary.f32(i32 35, float %553, float 0.000000e+00)  ; FMax(a,b)
  %566 = call float @dx.op.binary.f32(i32 35, float %554, float 0.000000e+00)  ; FMax(a,b)
  %567 = call float @dx.op.unary.f32(i32 23, float %564)  ; Log(value)
  %568 = call float @dx.op.unary.f32(i32 23, float %565)  ; Log(value)
  %569 = call float @dx.op.unary.f32(i32 23, float %566)  ; Log(value)
  %570 = fmul fast float %567, 0x3FDAAAAAA0000000
  %571 = fmul fast float %568, 0x3FDAAAAAA0000000
  %572 = fmul fast float %569, 0x3FDAAAAAA0000000
  %573 = call float @dx.op.unary.f32(i32 21, float %570)  ; Exp(value)
  %574 = call float @dx.op.unary.f32(i32 21, float %571)  ; Exp(value)
  %575 = call float @dx.op.unary.f32(i32 21, float %572)  ; Exp(value)
  %576 = fmul fast float %573, 0x3FF0E147A0000000
  %577 = fmul fast float %574, 0x3FF0E147A0000000
  %578 = fmul fast float %575, 0x3FF0E147A0000000
  %579 = fadd fast float %576, 0xBFAC28F5C0000000
  %580 = fadd fast float %577, 0xBFAC28F5C0000000
  %581 = fadd fast float %578, 0xBFAC28F5C0000000
  %582 = fsub fast float %561, %579
  %583 = fsub fast float %562, %580
  %584 = fsub fast float %563, %581
  %585 = fmul fast float %582, %558
  %586 = fmul fast float %583, %559
  %587 = fmul fast float %584, %560
  %588 = fadd fast float %585, %579
  %589 = fadd fast float %586, %580
  %590 = fadd fast float %587, %581
  br label %591

; <label>:591                                     ; preds = %523, %338
  %592 = phi float [ %333, %338 ], [ %588, %523 ]
  %593 = phi float [ %334, %338 ], [ %589, %523 ]
  %594 = phi float [ %335, %338 ], [ %590, %523 ]
  %595 = phi float [ %339, %338 ], [ %336, %523 ]
  %596 = add i32 %56, 1
  %597 = call i32 @dx.op.binary.i32(i32 37, i32 %596, i32 0)  ; IMax(a,b)
  %598 = call i32 @dx.op.binary.i32(i32 38, i32 %597, i32 %60)  ; IMin(a,b)
  %599 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %63, i32 %598, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %600 = extractvalue %dx.types.ResRet.f32 %599, 0
  %601 = extractvalue %dx.types.ResRet.f32 %599, 1
  %602 = extractvalue %dx.types.ResRet.f32 %599, 2
  %603 = extractvalue %dx.types.ResRet.f32 %599, 3
  %604 = fcmp fast olt float %603, 0.000000e+00
  br i1 %604, label %605, label %607

; <label>:605                                     ; preds = %591
  %606 = fsub fast float -1.000000e+00, %603
  br label %858

; <label>:607                                     ; preds = %591
  %608 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %598, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %609 = extractvalue %dx.types.ResRet.f32 %608, 0
  %610 = fcmp fast ogt float %38, 5.000000e-01
  %611 = fcmp fast olt float %609, 1.000000e+00
  %612 = and i1 %610, %611
  br i1 %612, label %613, label %751

; <label>:613                                     ; preds = %607
  %614 = sitofp i32 %63 to float
  %615 = sitofp i32 %598 to float
  %616 = fadd fast float %614, 5.000000e-01
  %617 = fadd fast float %615, 5.000000e-01
  %618 = fdiv fast float %616, %45
  %619 = fdiv fast float %617, %46
  %620 = fmul fast float %618, 2.000000e+00
  %621 = fmul fast float %619, 2.000000e+00
  %622 = fadd fast float %620, -1.000000e+00
  %623 = fsub fast float 1.000000e+00, %621
  %624 = fmul fast float %622, %35
  %625 = call float @dx.op.tertiary.f32(i32 46, float %623, float %31, float %624)  ; FMad(a,b,c)
  %626 = call float @dx.op.tertiary.f32(i32 46, float %609, float %27, float %625)  ; FMad(a,b,c)
  %627 = fadd fast float %626, %23
  %628 = call float @dx.op.unary.f32(i32 6, float %627)  ; FAbs(value)
  %629 = fcmp fast ogt float %628, 0x3EB0C6F7A0000000
  br i1 %629, label %630, label %751

; <label>:630                                     ; preds = %613
  %631 = fmul fast float %622, %34
  %632 = call float @dx.op.tertiary.f32(i32 46, float %623, float %30, float %631)  ; FMad(a,b,c)
  %633 = call float @dx.op.tertiary.f32(i32 46, float %609, float %26, float %632)  ; FMad(a,b,c)
  %634 = fadd fast float %633, %22
  %635 = fmul fast float %622, %33
  %636 = call float @dx.op.tertiary.f32(i32 46, float %623, float %29, float %635)  ; FMad(a,b,c)
  %637 = call float @dx.op.tertiary.f32(i32 46, float %609, float %25, float %636)  ; FMad(a,b,c)
  %638 = fadd fast float %637, %21
  %639 = fmul fast float %622, %32
  %640 = call float @dx.op.tertiary.f32(i32 46, float %623, float %28, float %639)  ; FMad(a,b,c)
  %641 = call float @dx.op.tertiary.f32(i32 46, float %609, float %24, float %640)  ; FMad(a,b,c)
  %642 = fadd fast float %641, %20
  %643 = fdiv fast float %642, %627
  %644 = fdiv fast float %638, %627
  %645 = fdiv fast float %634, %627
  %646 = fsub fast float %643, %17
  %647 = fsub fast float %644, %18
  %648 = fsub fast float %645, %19
  %649 = fmul fast float %646, %646
  %650 = fmul fast float %647, %647
  %651 = fadd fast float %650, %649
  %652 = fmul fast float %648, %648
  %653 = fadd fast float %651, %652
  %654 = call float @dx.op.unary.f32(i32 24, float %653)  ; Sqrt(value)
  %655 = fsub fast float %654, %9
  %656 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %655)  ; FMax(a,b)
  %657 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %657, label %658, label %681

; <label>:658                                     ; preds = %630
  %659 = call float @dx.op.unary.f32(i32 6, float %647)  ; FAbs(value)
  %660 = fmul fast float %659, %11
  %661 = fcmp fast olt float %660, 0x3F50624DE0000000
  br i1 %661, label %662, label %665

; <label>:662                                     ; preds = %658
  %663 = fmul fast float %660, 5.000000e-01
  %664 = fsub fast float 1.000000e+00, %663
  br label %670

; <label>:665                                     ; preds = %658
  %666 = fmul fast float %660, 0xBFF7154760000000
  %667 = call float @dx.op.unary.f32(i32 21, float %666)  ; Exp(value)
  %668 = fsub fast float 1.000000e+00, %667
  %669 = fdiv fast float %668, %660
  br label %670

; <label>:670                                     ; preds = %665, %662
  %671 = phi float [ %664, %662 ], [ %669, %665 ]
  %672 = call float @dx.op.binary.f32(i32 36, float %644, float %18)  ; FMin(a,b)
  %673 = fsub fast float %672, %10
  %674 = fmul fast float %11, %673
  %675 = fsub fast float -0.000000e+00, %674
  %676 = call float @dx.op.binary.f32(i32 35, float %675, float -4.000000e+01)  ; FMax(a,b)
  %677 = call float @dx.op.binary.f32(i32 36, float %676, float 5.000000e+00)  ; FMin(a,b)
  %678 = fmul fast float %677, 0x3FF7154760000000
  %679 = call float @dx.op.unary.f32(i32 21, float %678)  ; Exp(value)
  %680 = fmul fast float %679, %671
  br label %681

; <label>:681                                     ; preds = %670, %630
  %682 = phi float [ %680, %670 ], [ 1.000000e+00, %630 ]
  %683 = fmul fast float %656, %16
  %684 = fmul fast float %683, %682
  %685 = fcmp fast ole float %654, %9
  %686 = fcmp fast olt float %654, 0x3F1A36E2E0000000
  %687 = or i1 %685, %686
  br i1 %687, label %734, label %688

; <label>:688                                     ; preds = %681
  %689 = fdiv fast float %9, %654
  %690 = fmul fast float %689, %646
  %691 = fmul fast float %689, %647
  %692 = fmul fast float %689, %648
  %693 = fadd fast float %690, %17
  %694 = fadd fast float %691, %18
  %695 = fadd fast float %692, %19
  %696 = fadd fast float %693, -9.000000e+02
  %697 = fadd fast float %694, -1.500000e+01
  %698 = fadd fast float %695, -7.500000e+02
  %699 = fmul fast float %696, 0x3F62345680000000
  %700 = fmul fast float %697, 0x3F62345680000000
  %701 = fmul fast float %698, 0x3F62345680000000
  %702 = call float @dx.op.dot3.f32(i32 55, float %699, float %700, float %701, float %699, float %700, float %701)  ; Dot3(ax,ay,az,bx,by,bz)
  %703 = fsub fast float 1.000000e+00, %702
  %704 = call float @dx.op.unary.f32(i32 7, float %703)  ; Saturate(value)
  %705 = fmul fast float %704, %704
  %706 = fadd fast float %693, %643
  %707 = fadd fast float %694, %644
  %708 = fadd fast float %695, %645
  %709 = fmul fast float %706, 0x3F52345680000000
  %710 = fadd fast float %709, -2.000000e+00
  %711 = fmul fast float %707, 0x3F52345680000000
  %712 = fadd fast float %711, 0xBFA1111120000000
  %713 = fmul fast float %708, 0x3F52345680000000
  %714 = fadd fast float %713, 0xBFFAAAAAC0000000
  %715 = call float @dx.op.dot3.f32(i32 55, float %710, float %712, float %714, float %710, float %712, float %714)  ; Dot3(ax,ay,az,bx,by,bz)
  %716 = fsub fast float 1.000000e+00, %715
  %717 = call float @dx.op.unary.f32(i32 7, float %716)  ; Saturate(value)
  %718 = fmul fast float %717, %717
  %719 = fmul fast float %718, 4.000000e+00
  %720 = fadd fast float %719, %705
  %721 = fadd fast float %643, -9.000000e+02
  %722 = fadd fast float %644, -1.500000e+01
  %723 = fadd fast float %645, -7.500000e+02
  %724 = fmul fast float %721, 0x3F62345680000000
  %725 = fmul fast float %722, 0x3F62345680000000
  %726 = fmul fast float %723, 0x3F62345680000000
  %727 = call float @dx.op.dot3.f32(i32 55, float %724, float %725, float %726, float %724, float %725, float %726)  ; Dot3(ax,ay,az,bx,by,bz)
  %728 = fsub fast float 1.000000e+00, %727
  %729 = call float @dx.op.unary.f32(i32 7, float %728)  ; Saturate(value)
  %730 = fmul fast float %729, %729
  %731 = fadd fast float %720, %730
  %732 = fmul fast float %655, 0x3F25D867E0000000
  %733 = fmul fast float %732, %731
  br label %734

; <label>:734                                     ; preds = %688, %681
  %735 = phi float [ %733, %688 ], [ 0.000000e+00, %681 ]
  %736 = fadd fast float %735, %684
  %737 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %736)  ; FMin(a,b)
  %738 = fmul fast float %737, 0xBFF7154760000000
  %739 = call float @dx.op.unary.f32(i32 21, float %738)  ; Exp(value)
  %740 = fsub fast float 1.000000e+00, %739
  %741 = call float @dx.op.binary.f32(i32 36, float %12, float %740)  ; FMin(a,b)
  %742 = fsub fast float %13, %600
  %743 = fsub fast float %14, %601
  %744 = fsub fast float %15, %602
  %745 = fmul fast float %741, %742
  %746 = fmul fast float %741, %743
  %747 = fmul fast float %741, %744
  %748 = fadd fast float %745, %600
  %749 = fadd fast float %746, %601
  %750 = fadd fast float %747, %602
  br label %751

; <label>:751                                     ; preds = %734, %613, %607
  %752 = phi float [ %748, %734 ], [ %600, %613 ], [ %600, %607 ]
  %753 = phi float [ %749, %734 ], [ %601, %613 ], [ %601, %607 ]
  %754 = phi float [ %750, %734 ], [ %602, %613 ], [ %602, %607 ]
  %755 = fadd fast float %5, 1.000000e+00
  %756 = fadd fast float %6, 1.000000e+00
  %757 = fsub fast float 1.000000e+00, %5
  %758 = fmul fast float %36, %755
  %759 = fmul fast float %36, %756
  %760 = fmul fast float %36, %757
  %761 = fmul fast float %758, %752
  %762 = fmul fast float %759, %753
  %763 = fmul fast float %760, %754
  %764 = fcmp fast ult float %37, 5.000000e-01
  br i1 %764, label %790, label %765

; <label>:765                                     ; preds = %751
  %766 = fmul fast float %761, 0x4004147AE0000000
  %767 = fmul fast float %762, 0x4004147AE0000000
  %768 = fmul fast float %763, 0x4004147AE0000000
  %769 = fadd fast float %766, 0x3F9EB851E0000000
  %770 = fadd fast float %767, 0x3F9EB851E0000000
  %771 = fadd fast float %768, 0x3F9EB851E0000000
  %772 = fmul fast float %769, %761
  %773 = fmul fast float %770, %762
  %774 = fmul fast float %771, %763
  %775 = fmul fast float %761, 0x400370A3E0000000
  %776 = fmul fast float %762, 0x400370A3E0000000
  %777 = fmul fast float %763, 0x400370A3E0000000
  %778 = fadd fast float %775, 0x3FE2E147A0000000
  %779 = fadd fast float %776, 0x3FE2E147A0000000
  %780 = fadd fast float %777, 0x3FE2E147A0000000
  %781 = fmul fast float %778, %761
  %782 = fmul fast float %779, %762
  %783 = fmul fast float %780, %763
  %784 = fadd fast float %781, 0x3FC1EB8520000000
  %785 = fadd fast float %782, 0x3FC1EB8520000000
  %786 = fadd fast float %783, 0x3FC1EB8520000000
  %787 = fdiv fast float %772, %784
  %788 = fdiv fast float %773, %785
  %789 = fdiv fast float %774, %786
  br label %790

; <label>:790                                     ; preds = %765, %751
  %791 = phi float [ %787, %765 ], [ %761, %751 ]
  %792 = phi float [ %788, %765 ], [ %762, %751 ]
  %793 = phi float [ %789, %765 ], [ %763, %751 ]
  %794 = call float @dx.op.unary.f32(i32 7, float %791)  ; Saturate(value)
  %795 = call float @dx.op.unary.f32(i32 7, float %792)  ; Saturate(value)
  %796 = call float @dx.op.unary.f32(i32 7, float %793)  ; Saturate(value)
  %797 = call float @dx.op.dot3.f32(i32 55, float %794, float %795, float %796, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %798 = fsub fast float %794, %797
  %799 = fsub fast float %795, %797
  %800 = fsub fast float %796, %797
  %801 = fmul fast float %798, %8
  %802 = fmul fast float %799, %8
  %803 = fmul fast float %800, %8
  %804 = fadd fast float %801, %797
  %805 = fadd fast float %802, %797
  %806 = fadd fast float %803, %797
  %807 = call float @dx.op.unary.f32(i32 7, float %804)  ; Saturate(value)
  %808 = call float @dx.op.unary.f32(i32 7, float %805)  ; Saturate(value)
  %809 = call float @dx.op.unary.f32(i32 7, float %806)  ; Saturate(value)
  %810 = fadd fast float %807, 0xBFC70A3D80000000
  %811 = fadd fast float %808, 0xBFC70A3D80000000
  %812 = fadd fast float %809, 0xBFC70A3D80000000
  %813 = fmul fast float %810, %7
  %814 = fmul fast float %811, %7
  %815 = fmul fast float %812, %7
  %816 = fadd fast float %813, 0x3FC70A3D80000000
  %817 = fadd fast float %814, 0x3FC70A3D80000000
  %818 = fadd fast float %815, 0x3FC70A3D80000000
  %819 = call float @dx.op.unary.f32(i32 7, float %816)  ; Saturate(value)
  %820 = call float @dx.op.unary.f32(i32 7, float %817)  ; Saturate(value)
  %821 = call float @dx.op.unary.f32(i32 7, float %818)  ; Saturate(value)
  %822 = fcmp fast ogt float %819, 0x3F69A5C380000000
  %823 = fcmp fast ogt float %820, 0x3F69A5C380000000
  %824 = fcmp fast ogt float %821, 0x3F69A5C380000000
  %825 = select i1 %822, float 0.000000e+00, float 1.000000e+00
  %826 = select i1 %823, float 0.000000e+00, float 1.000000e+00
  %827 = select i1 %824, float 0.000000e+00, float 1.000000e+00
  %828 = fmul fast float %819, 0x4029D70A40000000
  %829 = fmul fast float %820, 0x4029D70A40000000
  %830 = fmul fast float %821, 0x4029D70A40000000
  %831 = call float @dx.op.binary.f32(i32 35, float %819, float 0.000000e+00)  ; FMax(a,b)
  %832 = call float @dx.op.binary.f32(i32 35, float %820, float 0.000000e+00)  ; FMax(a,b)
  %833 = call float @dx.op.binary.f32(i32 35, float %821, float 0.000000e+00)  ; FMax(a,b)
  %834 = call float @dx.op.unary.f32(i32 23, float %831)  ; Log(value)
  %835 = call float @dx.op.unary.f32(i32 23, float %832)  ; Log(value)
  %836 = call float @dx.op.unary.f32(i32 23, float %833)  ; Log(value)
  %837 = fmul fast float %834, 0x3FDAAAAAA0000000
  %838 = fmul fast float %835, 0x3FDAAAAAA0000000
  %839 = fmul fast float %836, 0x3FDAAAAAA0000000
  %840 = call float @dx.op.unary.f32(i32 21, float %837)  ; Exp(value)
  %841 = call float @dx.op.unary.f32(i32 21, float %838)  ; Exp(value)
  %842 = call float @dx.op.unary.f32(i32 21, float %839)  ; Exp(value)
  %843 = fmul fast float %840, 0x3FF0E147A0000000
  %844 = fmul fast float %841, 0x3FF0E147A0000000
  %845 = fmul fast float %842, 0x3FF0E147A0000000
  %846 = fadd fast float %843, 0xBFAC28F5C0000000
  %847 = fadd fast float %844, 0xBFAC28F5C0000000
  %848 = fadd fast float %845, 0xBFAC28F5C0000000
  %849 = fsub fast float %828, %846
  %850 = fsub fast float %829, %847
  %851 = fsub fast float %830, %848
  %852 = fmul fast float %849, %825
  %853 = fmul fast float %850, %826
  %854 = fmul fast float %851, %827
  %855 = fadd fast float %852, %846
  %856 = fadd fast float %853, %847
  %857 = fadd fast float %854, %848
  br label %858

; <label>:858                                     ; preds = %790, %605
  %859 = phi float [ %600, %605 ], [ %855, %790 ]
  %860 = phi float [ %601, %605 ], [ %856, %790 ]
  %861 = phi float [ %602, %605 ], [ %857, %790 ]
  %862 = phi float [ %606, %605 ], [ %603, %790 ]
  %863 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %331, i32 %598, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %864 = extractvalue %dx.types.ResRet.f32 %863, 0
  %865 = extractvalue %dx.types.ResRet.f32 %863, 1
  %866 = extractvalue %dx.types.ResRet.f32 %863, 2
  %867 = extractvalue %dx.types.ResRet.f32 %863, 3
  %868 = fcmp fast olt float %867, 0.000000e+00
  br i1 %868, label %869, label %871

; <label>:869                                     ; preds = %858
  %870 = fsub fast float -1.000000e+00, %867
  br label %1122

; <label>:871                                     ; preds = %858
  %872 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %331, i32 %598, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %873 = extractvalue %dx.types.ResRet.f32 %872, 0
  %874 = fcmp fast ogt float %38, 5.000000e-01
  %875 = fcmp fast olt float %873, 1.000000e+00
  %876 = and i1 %874, %875
  br i1 %876, label %877, label %1015

; <label>:877                                     ; preds = %871
  %878 = sitofp i32 %331 to float
  %879 = sitofp i32 %598 to float
  %880 = fadd fast float %878, 5.000000e-01
  %881 = fadd fast float %879, 5.000000e-01
  %882 = fdiv fast float %880, %45
  %883 = fdiv fast float %881, %46
  %884 = fmul fast float %882, 2.000000e+00
  %885 = fmul fast float %883, 2.000000e+00
  %886 = fadd fast float %884, -1.000000e+00
  %887 = fsub fast float 1.000000e+00, %885
  %888 = fmul fast float %886, %35
  %889 = call float @dx.op.tertiary.f32(i32 46, float %887, float %31, float %888)  ; FMad(a,b,c)
  %890 = call float @dx.op.tertiary.f32(i32 46, float %873, float %27, float %889)  ; FMad(a,b,c)
  %891 = fadd fast float %890, %23
  %892 = call float @dx.op.unary.f32(i32 6, float %891)  ; FAbs(value)
  %893 = fcmp fast ogt float %892, 0x3EB0C6F7A0000000
  br i1 %893, label %894, label %1015

; <label>:894                                     ; preds = %877
  %895 = fmul fast float %886, %34
  %896 = call float @dx.op.tertiary.f32(i32 46, float %887, float %30, float %895)  ; FMad(a,b,c)
  %897 = call float @dx.op.tertiary.f32(i32 46, float %873, float %26, float %896)  ; FMad(a,b,c)
  %898 = fadd fast float %897, %22
  %899 = fmul fast float %886, %33
  %900 = call float @dx.op.tertiary.f32(i32 46, float %887, float %29, float %899)  ; FMad(a,b,c)
  %901 = call float @dx.op.tertiary.f32(i32 46, float %873, float %25, float %900)  ; FMad(a,b,c)
  %902 = fadd fast float %901, %21
  %903 = fmul fast float %886, %32
  %904 = call float @dx.op.tertiary.f32(i32 46, float %887, float %28, float %903)  ; FMad(a,b,c)
  %905 = call float @dx.op.tertiary.f32(i32 46, float %873, float %24, float %904)  ; FMad(a,b,c)
  %906 = fadd fast float %905, %20
  %907 = fdiv fast float %906, %891
  %908 = fdiv fast float %902, %891
  %909 = fdiv fast float %898, %891
  %910 = fsub fast float %907, %17
  %911 = fsub fast float %908, %18
  %912 = fsub fast float %909, %19
  %913 = fmul fast float %910, %910
  %914 = fmul fast float %911, %911
  %915 = fadd fast float %914, %913
  %916 = fmul fast float %912, %912
  %917 = fadd fast float %915, %916
  %918 = call float @dx.op.unary.f32(i32 24, float %917)  ; Sqrt(value)
  %919 = fsub fast float %918, %9
  %920 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %919)  ; FMax(a,b)
  %921 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %921, label %922, label %945

; <label>:922                                     ; preds = %894
  %923 = call float @dx.op.unary.f32(i32 6, float %911)  ; FAbs(value)
  %924 = fmul fast float %923, %11
  %925 = fcmp fast olt float %924, 0x3F50624DE0000000
  br i1 %925, label %926, label %929

; <label>:926                                     ; preds = %922
  %927 = fmul fast float %924, 5.000000e-01
  %928 = fsub fast float 1.000000e+00, %927
  br label %934

; <label>:929                                     ; preds = %922
  %930 = fmul fast float %924, 0xBFF7154760000000
  %931 = call float @dx.op.unary.f32(i32 21, float %930)  ; Exp(value)
  %932 = fsub fast float 1.000000e+00, %931
  %933 = fdiv fast float %932, %924
  br label %934

; <label>:934                                     ; preds = %929, %926
  %935 = phi float [ %928, %926 ], [ %933, %929 ]
  %936 = call float @dx.op.binary.f32(i32 36, float %908, float %18)  ; FMin(a,b)
  %937 = fsub fast float %936, %10
  %938 = fmul fast float %11, %937
  %939 = fsub fast float -0.000000e+00, %938
  %940 = call float @dx.op.binary.f32(i32 35, float %939, float -4.000000e+01)  ; FMax(a,b)
  %941 = call float @dx.op.binary.f32(i32 36, float %940, float 5.000000e+00)  ; FMin(a,b)
  %942 = fmul fast float %941, 0x3FF7154760000000
  %943 = call float @dx.op.unary.f32(i32 21, float %942)  ; Exp(value)
  %944 = fmul fast float %943, %935
  br label %945

; <label>:945                                     ; preds = %934, %894
  %946 = phi float [ %944, %934 ], [ 1.000000e+00, %894 ]
  %947 = fmul fast float %920, %16
  %948 = fmul fast float %947, %946
  %949 = fcmp fast ole float %918, %9
  %950 = fcmp fast olt float %918, 0x3F1A36E2E0000000
  %951 = or i1 %949, %950
  br i1 %951, label %998, label %952

; <label>:952                                     ; preds = %945
  %953 = fdiv fast float %9, %918
  %954 = fmul fast float %953, %910
  %955 = fmul fast float %953, %911
  %956 = fmul fast float %953, %912
  %957 = fadd fast float %954, %17
  %958 = fadd fast float %955, %18
  %959 = fadd fast float %956, %19
  %960 = fadd fast float %957, -9.000000e+02
  %961 = fadd fast float %958, -1.500000e+01
  %962 = fadd fast float %959, -7.500000e+02
  %963 = fmul fast float %960, 0x3F62345680000000
  %964 = fmul fast float %961, 0x3F62345680000000
  %965 = fmul fast float %962, 0x3F62345680000000
  %966 = call float @dx.op.dot3.f32(i32 55, float %963, float %964, float %965, float %963, float %964, float %965)  ; Dot3(ax,ay,az,bx,by,bz)
  %967 = fsub fast float 1.000000e+00, %966
  %968 = call float @dx.op.unary.f32(i32 7, float %967)  ; Saturate(value)
  %969 = fmul fast float %968, %968
  %970 = fadd fast float %957, %907
  %971 = fadd fast float %958, %908
  %972 = fadd fast float %959, %909
  %973 = fmul fast float %970, 0x3F52345680000000
  %974 = fadd fast float %973, -2.000000e+00
  %975 = fmul fast float %971, 0x3F52345680000000
  %976 = fadd fast float %975, 0xBFA1111120000000
  %977 = fmul fast float %972, 0x3F52345680000000
  %978 = fadd fast float %977, 0xBFFAAAAAC0000000
  %979 = call float @dx.op.dot3.f32(i32 55, float %974, float %976, float %978, float %974, float %976, float %978)  ; Dot3(ax,ay,az,bx,by,bz)
  %980 = fsub fast float 1.000000e+00, %979
  %981 = call float @dx.op.unary.f32(i32 7, float %980)  ; Saturate(value)
  %982 = fmul fast float %981, %981
  %983 = fmul fast float %982, 4.000000e+00
  %984 = fadd fast float %983, %969
  %985 = fadd fast float %907, -9.000000e+02
  %986 = fadd fast float %908, -1.500000e+01
  %987 = fadd fast float %909, -7.500000e+02
  %988 = fmul fast float %985, 0x3F62345680000000
  %989 = fmul fast float %986, 0x3F62345680000000
  %990 = fmul fast float %987, 0x3F62345680000000
  %991 = call float @dx.op.dot3.f32(i32 55, float %988, float %989, float %990, float %988, float %989, float %990)  ; Dot3(ax,ay,az,bx,by,bz)
  %992 = fsub fast float 1.000000e+00, %991
  %993 = call float @dx.op.unary.f32(i32 7, float %992)  ; Saturate(value)
  %994 = fmul fast float %993, %993
  %995 = fadd fast float %984, %994
  %996 = fmul fast float %919, 0x3F25D867E0000000
  %997 = fmul fast float %996, %995
  br label %998

; <label>:998                                     ; preds = %952, %945
  %999 = phi float [ %997, %952 ], [ 0.000000e+00, %945 ]
  %1000 = fadd fast float %999, %948
  %1001 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1000)  ; FMin(a,b)
  %1002 = fmul fast float %1001, 0xBFF7154760000000
  %1003 = call float @dx.op.unary.f32(i32 21, float %1002)  ; Exp(value)
  %1004 = fsub fast float 1.000000e+00, %1003
  %1005 = call float @dx.op.binary.f32(i32 36, float %12, float %1004)  ; FMin(a,b)
  %1006 = fsub fast float %13, %864
  %1007 = fsub fast float %14, %865
  %1008 = fsub fast float %15, %866
  %1009 = fmul fast float %1005, %1006
  %1010 = fmul fast float %1005, %1007
  %1011 = fmul fast float %1005, %1008
  %1012 = fadd fast float %1009, %864
  %1013 = fadd fast float %1010, %865
  %1014 = fadd fast float %1011, %866
  br label %1015

; <label>:1015                                    ; preds = %998, %877, %871
  %1016 = phi float [ %1012, %998 ], [ %864, %877 ], [ %864, %871 ]
  %1017 = phi float [ %1013, %998 ], [ %865, %877 ], [ %865, %871 ]
  %1018 = phi float [ %1014, %998 ], [ %866, %877 ], [ %866, %871 ]
  %1019 = fadd fast float %5, 1.000000e+00
  %1020 = fadd fast float %6, 1.000000e+00
  %1021 = fsub fast float 1.000000e+00, %5
  %1022 = fmul fast float %36, %1019
  %1023 = fmul fast float %36, %1020
  %1024 = fmul fast float %36, %1021
  %1025 = fmul fast float %1022, %1016
  %1026 = fmul fast float %1023, %1017
  %1027 = fmul fast float %1024, %1018
  %1028 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1028, label %1054, label %1029

; <label>:1029                                    ; preds = %1015
  %1030 = fmul fast float %1025, 0x4004147AE0000000
  %1031 = fmul fast float %1026, 0x4004147AE0000000
  %1032 = fmul fast float %1027, 0x4004147AE0000000
  %1033 = fadd fast float %1030, 0x3F9EB851E0000000
  %1034 = fadd fast float %1031, 0x3F9EB851E0000000
  %1035 = fadd fast float %1032, 0x3F9EB851E0000000
  %1036 = fmul fast float %1033, %1025
  %1037 = fmul fast float %1034, %1026
  %1038 = fmul fast float %1035, %1027
  %1039 = fmul fast float %1025, 0x400370A3E0000000
  %1040 = fmul fast float %1026, 0x400370A3E0000000
  %1041 = fmul fast float %1027, 0x400370A3E0000000
  %1042 = fadd fast float %1039, 0x3FE2E147A0000000
  %1043 = fadd fast float %1040, 0x3FE2E147A0000000
  %1044 = fadd fast float %1041, 0x3FE2E147A0000000
  %1045 = fmul fast float %1042, %1025
  %1046 = fmul fast float %1043, %1026
  %1047 = fmul fast float %1044, %1027
  %1048 = fadd fast float %1045, 0x3FC1EB8520000000
  %1049 = fadd fast float %1046, 0x3FC1EB8520000000
  %1050 = fadd fast float %1047, 0x3FC1EB8520000000
  %1051 = fdiv fast float %1036, %1048
  %1052 = fdiv fast float %1037, %1049
  %1053 = fdiv fast float %1038, %1050
  br label %1054

; <label>:1054                                    ; preds = %1029, %1015
  %1055 = phi float [ %1051, %1029 ], [ %1025, %1015 ]
  %1056 = phi float [ %1052, %1029 ], [ %1026, %1015 ]
  %1057 = phi float [ %1053, %1029 ], [ %1027, %1015 ]
  %1058 = call float @dx.op.unary.f32(i32 7, float %1055)  ; Saturate(value)
  %1059 = call float @dx.op.unary.f32(i32 7, float %1056)  ; Saturate(value)
  %1060 = call float @dx.op.unary.f32(i32 7, float %1057)  ; Saturate(value)
  %1061 = call float @dx.op.dot3.f32(i32 55, float %1058, float %1059, float %1060, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1062 = fsub fast float %1058, %1061
  %1063 = fsub fast float %1059, %1061
  %1064 = fsub fast float %1060, %1061
  %1065 = fmul fast float %1062, %8
  %1066 = fmul fast float %1063, %8
  %1067 = fmul fast float %1064, %8
  %1068 = fadd fast float %1065, %1061
  %1069 = fadd fast float %1066, %1061
  %1070 = fadd fast float %1067, %1061
  %1071 = call float @dx.op.unary.f32(i32 7, float %1068)  ; Saturate(value)
  %1072 = call float @dx.op.unary.f32(i32 7, float %1069)  ; Saturate(value)
  %1073 = call float @dx.op.unary.f32(i32 7, float %1070)  ; Saturate(value)
  %1074 = fadd fast float %1071, 0xBFC70A3D80000000
  %1075 = fadd fast float %1072, 0xBFC70A3D80000000
  %1076 = fadd fast float %1073, 0xBFC70A3D80000000
  %1077 = fmul fast float %1074, %7
  %1078 = fmul fast float %1075, %7
  %1079 = fmul fast float %1076, %7
  %1080 = fadd fast float %1077, 0x3FC70A3D80000000
  %1081 = fadd fast float %1078, 0x3FC70A3D80000000
  %1082 = fadd fast float %1079, 0x3FC70A3D80000000
  %1083 = call float @dx.op.unary.f32(i32 7, float %1080)  ; Saturate(value)
  %1084 = call float @dx.op.unary.f32(i32 7, float %1081)  ; Saturate(value)
  %1085 = call float @dx.op.unary.f32(i32 7, float %1082)  ; Saturate(value)
  %1086 = fcmp fast ogt float %1083, 0x3F69A5C380000000
  %1087 = fcmp fast ogt float %1084, 0x3F69A5C380000000
  %1088 = fcmp fast ogt float %1085, 0x3F69A5C380000000
  %1089 = select i1 %1086, float 0.000000e+00, float 1.000000e+00
  %1090 = select i1 %1087, float 0.000000e+00, float 1.000000e+00
  %1091 = select i1 %1088, float 0.000000e+00, float 1.000000e+00
  %1092 = fmul fast float %1083, 0x4029D70A40000000
  %1093 = fmul fast float %1084, 0x4029D70A40000000
  %1094 = fmul fast float %1085, 0x4029D70A40000000
  %1095 = call float @dx.op.binary.f32(i32 35, float %1083, float 0.000000e+00)  ; FMax(a,b)
  %1096 = call float @dx.op.binary.f32(i32 35, float %1084, float 0.000000e+00)  ; FMax(a,b)
  %1097 = call float @dx.op.binary.f32(i32 35, float %1085, float 0.000000e+00)  ; FMax(a,b)
  %1098 = call float @dx.op.unary.f32(i32 23, float %1095)  ; Log(value)
  %1099 = call float @dx.op.unary.f32(i32 23, float %1096)  ; Log(value)
  %1100 = call float @dx.op.unary.f32(i32 23, float %1097)  ; Log(value)
  %1101 = fmul fast float %1098, 0x3FDAAAAAA0000000
  %1102 = fmul fast float %1099, 0x3FDAAAAAA0000000
  %1103 = fmul fast float %1100, 0x3FDAAAAAA0000000
  %1104 = call float @dx.op.unary.f32(i32 21, float %1101)  ; Exp(value)
  %1105 = call float @dx.op.unary.f32(i32 21, float %1102)  ; Exp(value)
  %1106 = call float @dx.op.unary.f32(i32 21, float %1103)  ; Exp(value)
  %1107 = fmul fast float %1104, 0x3FF0E147A0000000
  %1108 = fmul fast float %1105, 0x3FF0E147A0000000
  %1109 = fmul fast float %1106, 0x3FF0E147A0000000
  %1110 = fadd fast float %1107, 0xBFAC28F5C0000000
  %1111 = fadd fast float %1108, 0xBFAC28F5C0000000
  %1112 = fadd fast float %1109, 0xBFAC28F5C0000000
  %1113 = fsub fast float %1092, %1110
  %1114 = fsub fast float %1093, %1111
  %1115 = fsub fast float %1094, %1112
  %1116 = fmul fast float %1113, %1089
  %1117 = fmul fast float %1114, %1090
  %1118 = fmul fast float %1115, %1091
  %1119 = fadd fast float %1116, %1110
  %1120 = fadd fast float %1117, %1111
  %1121 = fadd fast float %1118, %1112
  br label %1122

; <label>:1122                                    ; preds = %1054, %869
  %1123 = phi float [ %864, %869 ], [ %1119, %1054 ]
  %1124 = phi float [ %865, %869 ], [ %1120, %1054 ]
  %1125 = phi float [ %866, %869 ], [ %1121, %1054 ]
  %1126 = phi float [ %870, %869 ], [ %867, %1054 ]
  %1127 = call float @dx.op.unary.f32(i32 27, float %49)  ; Round_ni(value)
  %1128 = call float @dx.op.unary.f32(i32 27, float %50)  ; Round_ni(value)
  %1129 = fptosi float %1127 to i32
  %1130 = fptosi float %1128 to i32
  %1131 = call i32 @dx.op.binary.i32(i32 37, i32 %1129, i32 0)  ; IMax(a,b)
  %1132 = call i32 @dx.op.binary.i32(i32 37, i32 %1130, i32 0)  ; IMax(a,b)
  %1133 = call i32 @dx.op.binary.i32(i32 38, i32 %1131, i32 %59)  ; IMin(a,b)
  %1134 = call i32 @dx.op.binary.i32(i32 38, i32 %1132, i32 %60)  ; IMin(a,b)
  %1135 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1133, i32 %1134, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1136 = extractvalue %dx.types.ResRet.f32 %1135, 0
  %1137 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1138 = extractvalue %dx.types.ResRet.f32 %1137, 0
  %1139 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %331, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1140 = extractvalue %dx.types.ResRet.f32 %1139, 0
  %1141 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %598, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1142 = extractvalue %dx.types.ResRet.f32 %1141, 0
  %1143 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %331, i32 %598, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1144 = extractvalue %dx.types.ResRet.f32 %1143, 0
  %1145 = fsub fast float 1.000000e+00, %57
  %1146 = fsub fast float 1.000000e+00, %58
  %1147 = fmul fast float %1146, %1145
  %1148 = fmul fast float %1146, %57
  %1149 = fmul fast float %1145, %58
  %1150 = fmul fast float %58, %57
  %1151 = fsub fast float 1.000000e+00, %1136
  %1152 = fmul fast float %1151, 0x3FA99999A0000000
  %1153 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %1152)  ; FMax(a,b)
  %1154 = fsub fast float %1138, %1136
  %1155 = fsub fast float %1140, %1136
  %1156 = fsub fast float %1142, %1136
  %1157 = fsub fast float %1144, %1136
  %1158 = call float @dx.op.unary.f32(i32 6, float %1154)  ; FAbs(value)
  %1159 = call float @dx.op.unary.f32(i32 6, float %1155)  ; FAbs(value)
  %1160 = call float @dx.op.unary.f32(i32 6, float %1156)  ; FAbs(value)
  %1161 = call float @dx.op.unary.f32(i32 6, float %1157)  ; FAbs(value)
  %1162 = fdiv fast float %1158, %1153
  %1163 = fdiv fast float %1159, %1153
  %1164 = fdiv fast float %1160, %1153
  %1165 = fdiv fast float %1161, %1153
  %1166 = fsub fast float 1.000000e+00, %1162
  %1167 = fsub fast float 1.000000e+00, %1163
  %1168 = fsub fast float 1.000000e+00, %1164
  %1169 = fsub fast float 1.000000e+00, %1165
  %1170 = call float @dx.op.unary.f32(i32 7, float %1166)  ; Saturate(value)
  %1171 = call float @dx.op.unary.f32(i32 7, float %1167)  ; Saturate(value)
  %1172 = call float @dx.op.unary.f32(i32 7, float %1168)  ; Saturate(value)
  %1173 = call float @dx.op.unary.f32(i32 7, float %1169)  ; Saturate(value)
  %1174 = fmul fast float %1147, %1170
  %1175 = fmul fast float %1148, %1171
  %1176 = fmul fast float %1149, %1172
  %1177 = fmul fast float %1150, %1173
  %1178 = call float @dx.op.dot4.f32(i32 56, float %1174, float %1175, float %1176, float %1177, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %1179 = call float @dx.op.binary.f32(i32 35, float %1178, float 0x3EE4F8B580000000)  ; FMax(a,b)
  %1180 = fdiv fast float %1174, %1179
  %1181 = fdiv fast float %1175, %1179
  %1182 = fdiv fast float %1176, %1179
  %1183 = fdiv fast float %1177, %1179
  %1184 = fcmp fast ogt float %325, 0x3FA4B5DCC0000000
  %1185 = fcmp fast ogt float %326, 0x3FA4B5DCC0000000
  %1186 = fcmp fast ogt float %327, 0x3FA4B5DCC0000000
  %1187 = select i1 %1184, float 0.000000e+00, float 1.000000e+00
  %1188 = select i1 %1185, float 0.000000e+00, float 1.000000e+00
  %1189 = select i1 %1186, float 0.000000e+00, float 1.000000e+00
  %1190 = fmul fast float %325, 0x3FB3D07220000000
  %1191 = fmul fast float %326, 0x3FB3D07220000000
  %1192 = fmul fast float %327, 0x3FB3D07220000000
  %1193 = fadd fast float %325, 0x3FAC28F5C0000000
  %1194 = fadd fast float %326, 0x3FAC28F5C0000000
  %1195 = fadd fast float %327, 0x3FAC28F5C0000000
  %1196 = fmul fast float %1193, 0x3FEE54EDE0000000
  %1197 = fmul fast float %1194, 0x3FEE54EDE0000000
  %1198 = fmul fast float %1195, 0x3FEE54EDE0000000
  %1199 = call float @dx.op.unary.f32(i32 23, float %1196)  ; Log(value)
  %1200 = call float @dx.op.unary.f32(i32 23, float %1197)  ; Log(value)
  %1201 = call float @dx.op.unary.f32(i32 23, float %1198)  ; Log(value)
  %1202 = fmul fast float %1199, 0x4003333340000000
  %1203 = fmul fast float %1200, 0x4003333340000000
  %1204 = fmul fast float %1201, 0x4003333340000000
  %1205 = call float @dx.op.unary.f32(i32 21, float %1202)  ; Exp(value)
  %1206 = call float @dx.op.unary.f32(i32 21, float %1203)  ; Exp(value)
  %1207 = call float @dx.op.unary.f32(i32 21, float %1204)  ; Exp(value)
  %1208 = fsub fast float %1190, %1205
  %1209 = fsub fast float %1191, %1206
  %1210 = fsub fast float %1192, %1207
  %1211 = fmul fast float %1208, %1187
  %1212 = fmul fast float %1209, %1188
  %1213 = fmul fast float %1210, %1189
  %1214 = fadd fast float %1211, %1205
  %1215 = fadd fast float %1212, %1206
  %1216 = fadd fast float %1213, %1207
  %1217 = fmul fast float %1214, %1180
  %1218 = fmul fast float %1215, %1180
  %1219 = fmul fast float %1216, %1180
  %1220 = fcmp fast ogt float %592, 0x3FA4B5DCC0000000
  %1221 = fcmp fast ogt float %593, 0x3FA4B5DCC0000000
  %1222 = fcmp fast ogt float %594, 0x3FA4B5DCC0000000
  %1223 = select i1 %1220, float 0.000000e+00, float 1.000000e+00
  %1224 = select i1 %1221, float 0.000000e+00, float 1.000000e+00
  %1225 = select i1 %1222, float 0.000000e+00, float 1.000000e+00
  %1226 = fmul fast float %592, 0x3FB3D07220000000
  %1227 = fmul fast float %593, 0x3FB3D07220000000
  %1228 = fmul fast float %594, 0x3FB3D07220000000
  %1229 = fadd fast float %592, 0x3FAC28F5C0000000
  %1230 = fadd fast float %593, 0x3FAC28F5C0000000
  %1231 = fadd fast float %594, 0x3FAC28F5C0000000
  %1232 = fmul fast float %1229, 0x3FEE54EDE0000000
  %1233 = fmul fast float %1230, 0x3FEE54EDE0000000
  %1234 = fmul fast float %1231, 0x3FEE54EDE0000000
  %1235 = call float @dx.op.unary.f32(i32 23, float %1232)  ; Log(value)
  %1236 = call float @dx.op.unary.f32(i32 23, float %1233)  ; Log(value)
  %1237 = call float @dx.op.unary.f32(i32 23, float %1234)  ; Log(value)
  %1238 = fmul fast float %1235, 0x4003333340000000
  %1239 = fmul fast float %1236, 0x4003333340000000
  %1240 = fmul fast float %1237, 0x4003333340000000
  %1241 = call float @dx.op.unary.f32(i32 21, float %1238)  ; Exp(value)
  %1242 = call float @dx.op.unary.f32(i32 21, float %1239)  ; Exp(value)
  %1243 = call float @dx.op.unary.f32(i32 21, float %1240)  ; Exp(value)
  %1244 = fsub fast float %1226, %1241
  %1245 = fsub fast float %1227, %1242
  %1246 = fsub fast float %1228, %1243
  %1247 = fmul fast float %1244, %1223
  %1248 = fmul fast float %1245, %1224
  %1249 = fmul fast float %1246, %1225
  %1250 = fadd fast float %1247, %1241
  %1251 = fadd fast float %1248, %1242
  %1252 = fadd fast float %1249, %1243
  %1253 = fmul fast float %1250, %1181
  %1254 = fmul fast float %1251, %1181
  %1255 = fmul fast float %1252, %1181
  %1256 = fadd fast float %1253, %1217
  %1257 = fadd fast float %1254, %1218
  %1258 = fadd fast float %1255, %1219
  %1259 = fcmp fast ogt float %859, 0x3FA4B5DCC0000000
  %1260 = fcmp fast ogt float %860, 0x3FA4B5DCC0000000
  %1261 = fcmp fast ogt float %861, 0x3FA4B5DCC0000000
  %1262 = select i1 %1259, float 0.000000e+00, float 1.000000e+00
  %1263 = select i1 %1260, float 0.000000e+00, float 1.000000e+00
  %1264 = select i1 %1261, float 0.000000e+00, float 1.000000e+00
  %1265 = fmul fast float %859, 0x3FB3D07220000000
  %1266 = fmul fast float %860, 0x3FB3D07220000000
  %1267 = fmul fast float %861, 0x3FB3D07220000000
  %1268 = fadd fast float %859, 0x3FAC28F5C0000000
  %1269 = fadd fast float %860, 0x3FAC28F5C0000000
  %1270 = fadd fast float %861, 0x3FAC28F5C0000000
  %1271 = fmul fast float %1268, 0x3FEE54EDE0000000
  %1272 = fmul fast float %1269, 0x3FEE54EDE0000000
  %1273 = fmul fast float %1270, 0x3FEE54EDE0000000
  %1274 = call float @dx.op.unary.f32(i32 23, float %1271)  ; Log(value)
  %1275 = call float @dx.op.unary.f32(i32 23, float %1272)  ; Log(value)
  %1276 = call float @dx.op.unary.f32(i32 23, float %1273)  ; Log(value)
  %1277 = fmul fast float %1274, 0x4003333340000000
  %1278 = fmul fast float %1275, 0x4003333340000000
  %1279 = fmul fast float %1276, 0x4003333340000000
  %1280 = call float @dx.op.unary.f32(i32 21, float %1277)  ; Exp(value)
  %1281 = call float @dx.op.unary.f32(i32 21, float %1278)  ; Exp(value)
  %1282 = call float @dx.op.unary.f32(i32 21, float %1279)  ; Exp(value)
  %1283 = fsub fast float %1265, %1280
  %1284 = fsub fast float %1266, %1281
  %1285 = fsub fast float %1267, %1282
  %1286 = fmul fast float %1283, %1262
  %1287 = fmul fast float %1284, %1263
  %1288 = fmul fast float %1285, %1264
  %1289 = fadd fast float %1286, %1280
  %1290 = fadd fast float %1287, %1281
  %1291 = fadd fast float %1288, %1282
  %1292 = fmul fast float %1289, %1182
  %1293 = fmul fast float %1290, %1182
  %1294 = fmul fast float %1291, %1182
  %1295 = fadd fast float %1256, %1292
  %1296 = fadd fast float %1257, %1293
  %1297 = fadd fast float %1258, %1294
  %1298 = fcmp fast ogt float %1123, 0x3FA4B5DCC0000000
  %1299 = fcmp fast ogt float %1124, 0x3FA4B5DCC0000000
  %1300 = fcmp fast ogt float %1125, 0x3FA4B5DCC0000000
  %1301 = select i1 %1298, float 0.000000e+00, float 1.000000e+00
  %1302 = select i1 %1299, float 0.000000e+00, float 1.000000e+00
  %1303 = select i1 %1300, float 0.000000e+00, float 1.000000e+00
  %1304 = fmul fast float %1123, 0x3FB3D07220000000
  %1305 = fmul fast float %1124, 0x3FB3D07220000000
  %1306 = fmul fast float %1125, 0x3FB3D07220000000
  %1307 = fadd fast float %1123, 0x3FAC28F5C0000000
  %1308 = fadd fast float %1124, 0x3FAC28F5C0000000
  %1309 = fadd fast float %1125, 0x3FAC28F5C0000000
  %1310 = fmul fast float %1307, 0x3FEE54EDE0000000
  %1311 = fmul fast float %1308, 0x3FEE54EDE0000000
  %1312 = fmul fast float %1309, 0x3FEE54EDE0000000
  %1313 = call float @dx.op.unary.f32(i32 23, float %1310)  ; Log(value)
  %1314 = call float @dx.op.unary.f32(i32 23, float %1311)  ; Log(value)
  %1315 = call float @dx.op.unary.f32(i32 23, float %1312)  ; Log(value)
  %1316 = fmul fast float %1313, 0x4003333340000000
  %1317 = fmul fast float %1314, 0x4003333340000000
  %1318 = fmul fast float %1315, 0x4003333340000000
  %1319 = call float @dx.op.unary.f32(i32 21, float %1316)  ; Exp(value)
  %1320 = call float @dx.op.unary.f32(i32 21, float %1317)  ; Exp(value)
  %1321 = call float @dx.op.unary.f32(i32 21, float %1318)  ; Exp(value)
  %1322 = fsub fast float %1304, %1319
  %1323 = fsub fast float %1305, %1320
  %1324 = fsub fast float %1306, %1321
  %1325 = fmul fast float %1322, %1301
  %1326 = fmul fast float %1323, %1302
  %1327 = fmul fast float %1324, %1303
  %1328 = fadd fast float %1325, %1319
  %1329 = fadd fast float %1326, %1320
  %1330 = fadd fast float %1327, %1321
  %1331 = fmul fast float %1328, %1183
  %1332 = fmul fast float %1329, %1183
  %1333 = fmul fast float %1330, %1183
  %1334 = fadd fast float %1295, %1331
  %1335 = fadd fast float %1296, %1332
  %1336 = fadd fast float %1297, %1333
  %1337 = fcmp fast ogt float %1334, 0x3F69A5C380000000
  %1338 = fcmp fast ogt float %1335, 0x3F69A5C380000000
  %1339 = fcmp fast ogt float %1336, 0x3F69A5C380000000
  %1340 = select i1 %1337, float 0.000000e+00, float 1.000000e+00
  %1341 = select i1 %1338, float 0.000000e+00, float 1.000000e+00
  %1342 = select i1 %1339, float 0.000000e+00, float 1.000000e+00
  %1343 = fmul fast float %1334, 0x4029D70A40000000
  %1344 = fmul fast float %1335, 0x4029D70A40000000
  %1345 = fmul fast float %1336, 0x4029D70A40000000
  %1346 = call float @dx.op.binary.f32(i32 35, float %1334, float 0.000000e+00)  ; FMax(a,b)
  %1347 = call float @dx.op.binary.f32(i32 35, float %1335, float 0.000000e+00)  ; FMax(a,b)
  %1348 = call float @dx.op.binary.f32(i32 35, float %1336, float 0.000000e+00)  ; FMax(a,b)
  %1349 = call float @dx.op.unary.f32(i32 23, float %1346)  ; Log(value)
  %1350 = call float @dx.op.unary.f32(i32 23, float %1347)  ; Log(value)
  %1351 = call float @dx.op.unary.f32(i32 23, float %1348)  ; Log(value)
  %1352 = fmul fast float %1349, 0x3FDAAAAAA0000000
  %1353 = fmul fast float %1350, 0x3FDAAAAAA0000000
  %1354 = fmul fast float %1351, 0x3FDAAAAAA0000000
  %1355 = call float @dx.op.unary.f32(i32 21, float %1352)  ; Exp(value)
  %1356 = call float @dx.op.unary.f32(i32 21, float %1353)  ; Exp(value)
  %1357 = call float @dx.op.unary.f32(i32 21, float %1354)  ; Exp(value)
  %1358 = fmul fast float %1355, 0x3FF0E147A0000000
  %1359 = fmul fast float %1356, 0x3FF0E147A0000000
  %1360 = fmul fast float %1357, 0x3FF0E147A0000000
  %1361 = fadd fast float %1358, 0xBFAC28F5C0000000
  %1362 = fadd fast float %1359, 0xBFAC28F5C0000000
  %1363 = fadd fast float %1360, 0xBFAC28F5C0000000
  %1364 = fsub fast float %1343, %1361
  %1365 = fsub fast float %1344, %1362
  %1366 = fsub fast float %1345, %1363
  %1367 = fmul fast float %1364, %1340
  %1368 = fmul fast float %1365, %1341
  %1369 = fmul fast float %1366, %1342
  %1370 = fadd fast float %1367, %1361
  %1371 = fadd fast float %1368, %1362
  %1372 = fadd fast float %1369, %1363
  %1373 = call float @dx.op.dot4.f32(i32 56, float %328, float %595, float %862, float %1126, float %1180, float %1181, float %1182, float %1183)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %1370)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %1371)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %1372)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %1373)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %1136)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !38, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, !37}
!36 = !{i32 9}
!37 = !{i32 3, i32 6}
!38 = !{!39, !40}
!39 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
!40 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !41}
!41 = !{i32 3, i32 1}
