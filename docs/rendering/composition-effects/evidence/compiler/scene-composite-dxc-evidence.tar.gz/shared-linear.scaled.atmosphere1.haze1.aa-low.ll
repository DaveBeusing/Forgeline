;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float    yz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: 3b50472b444df7587ffb38455b411398
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %40 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %41 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %42 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %43 = extractvalue %dx.types.Dimensions %42, 0
  %44 = extractvalue %dx.types.Dimensions %42, 1
  %45 = uitofp i32 %43 to float
  %46 = uitofp i32 %44 to float
  %47 = fmul fast float %45, %40
  %48 = fmul fast float %46, %41
  %49 = fdiv fast float %47, %3
  %50 = fdiv fast float %48, %4
  %51 = fadd fast float %49, -5.000000e-01
  %52 = fadd fast float %50, -5.000000e-01
  %53 = call float @dx.op.unary.f32(i32 27, float %51)  ; Round_ni(value)
  %54 = call float @dx.op.unary.f32(i32 27, float %52)  ; Round_ni(value)
  %55 = fptosi float %53 to i32
  %56 = fptosi float %54 to i32
  %57 = call float @dx.op.unary.f32(i32 22, float %51)  ; Frc(value)
  %58 = call float @dx.op.unary.f32(i32 22, float %52)  ; Frc(value)
  %59 = add i32 %43, -1
  %60 = add i32 %44, -1
  %61 = call i32 @dx.op.binary.i32(i32 37, i32 %55, i32 0)  ; IMax(a,b)
  %62 = call i32 @dx.op.binary.i32(i32 37, i32 %56, i32 0)  ; IMax(a,b)
  %63 = call i32 @dx.op.binary.i32(i32 38, i32 %61, i32 %59)  ; IMin(a,b)
  %64 = call i32 @dx.op.binary.i32(i32 38, i32 %62, i32 %60)  ; IMin(a,b)
  %65 = add i32 %55, 1
  %66 = call i32 @dx.op.binary.i32(i32 37, i32 %65, i32 0)  ; IMax(a,b)
  %67 = call i32 @dx.op.binary.i32(i32 38, i32 %66, i32 %59)  ; IMin(a,b)
  %68 = add i32 %56, 1
  %69 = call i32 @dx.op.binary.i32(i32 37, i32 %68, i32 0)  ; IMax(a,b)
  %70 = call i32 @dx.op.binary.i32(i32 38, i32 %69, i32 %60)  ; IMin(a,b)
  %71 = call float @dx.op.unary.f32(i32 27, float %49)  ; Round_ni(value)
  %72 = call float @dx.op.unary.f32(i32 27, float %50)  ; Round_ni(value)
  %73 = fptosi float %71 to i32
  %74 = fptosi float %72 to i32
  %75 = call i32 @dx.op.binary.i32(i32 37, i32 %73, i32 0)  ; IMax(a,b)
  %76 = call i32 @dx.op.binary.i32(i32 37, i32 %74, i32 0)  ; IMax(a,b)
  %77 = call i32 @dx.op.binary.i32(i32 38, i32 %75, i32 %59)  ; IMin(a,b)
  %78 = call i32 @dx.op.binary.i32(i32 38, i32 %76, i32 %60)  ; IMin(a,b)
  %79 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %77, i32 %78, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %80 = extractvalue %dx.types.ResRet.f32 %79, 0
  %81 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %82 = extractvalue %dx.types.ResRet.f32 %81, 0
  %83 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %67, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %84 = extractvalue %dx.types.ResRet.f32 %83, 0
  %85 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %86 = extractvalue %dx.types.ResRet.f32 %85, 0
  %87 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %67, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %88 = extractvalue %dx.types.ResRet.f32 %87, 0
  %89 = fsub fast float 1.000000e+00, %57
  %90 = fsub fast float 1.000000e+00, %58
  %91 = fmul fast float %90, %89
  %92 = fmul fast float %90, %57
  %93 = fmul fast float %89, %58
  %94 = fmul fast float %58, %57
  %95 = fsub fast float 1.000000e+00, %80
  %96 = fmul fast float %95, 0x3FA99999A0000000
  %97 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %96)  ; FMax(a,b)
  %98 = fsub fast float %82, %80
  %99 = call float @dx.op.unary.f32(i32 6, float %98)  ; FAbs(value)
  %100 = fdiv fast float %99, %97
  %101 = fsub fast float 1.000000e+00, %100
  %102 = call float @dx.op.unary.f32(i32 7, float %101)  ; Saturate(value)
  %103 = fsub fast float %84, %80
  %104 = call float @dx.op.unary.f32(i32 6, float %103)  ; FAbs(value)
  %105 = fdiv fast float %104, %97
  %106 = fsub fast float 1.000000e+00, %105
  %107 = call float @dx.op.unary.f32(i32 7, float %106)  ; Saturate(value)
  %108 = fsub fast float %86, %80
  %109 = call float @dx.op.unary.f32(i32 6, float %108)  ; FAbs(value)
  %110 = fdiv fast float %109, %97
  %111 = fsub fast float 1.000000e+00, %110
  %112 = call float @dx.op.unary.f32(i32 7, float %111)  ; Saturate(value)
  %113 = fsub fast float %88, %80
  %114 = call float @dx.op.unary.f32(i32 6, float %113)  ; FAbs(value)
  %115 = fdiv fast float %114, %97
  %116 = fsub fast float 1.000000e+00, %115
  %117 = call float @dx.op.unary.f32(i32 7, float %116)  ; Saturate(value)
  %118 = fmul fast float %91, %102
  %119 = fmul fast float %92, %107
  %120 = fmul fast float %93, %112
  %121 = fmul fast float %94, %117
  %122 = fcmp fast oge float %57, 5.000000e-01
  %123 = zext i1 %122 to i32
  %124 = fcmp fast oge float %58, 5.000000e-01
  %125 = select i1 %124, i32 2, i32 0
  %126 = or i32 %125, %123
  %127 = call float @dx.op.dot4.f32(i32 56, float %118, float %119, float %120, float %121, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %128 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %118)  ; IsFinite(value)
  %129 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %119)  ; IsFinite(value)
  %130 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %120)  ; IsFinite(value)
  %131 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %121)  ; IsFinite(value)
  %132 = and i1 %128, %129
  %133 = and i1 %132, %130
  %134 = and i1 %133, %131
  br i1 %134, label %135, label %152

; <label>:135                                     ; preds = %0
  %136 = fcmp fast oge float %118, 0.000000e+00
  %137 = fcmp fast oge float %119, 0.000000e+00
  %138 = fcmp fast oge float %120, 0.000000e+00
  %139 = fcmp fast oge float %121, 0.000000e+00
  %140 = and i1 %136, %137
  %141 = and i1 %140, %138
  %142 = and i1 %141, %139
  br i1 %142, label %143, label %152

; <label>:143                                     ; preds = %135
  %144 = call i1 @dx.op.isSpecialFloat.f32(i32 10, float %127)  ; IsFinite(value)
  %145 = fcmp fast oge float %127, 0x3810000000000000
  %146 = and i1 %145, %144
  br i1 %146, label %147, label %152

; <label>:147                                     ; preds = %143
  %148 = fdiv fast float %118, %127
  %149 = fdiv fast float %119, %127
  %150 = fdiv fast float %120, %127
  %151 = fdiv fast float %121, %127
  br label %161

; <label>:152                                     ; preds = %143, %135, %0
  %153 = icmp eq i32 %126, 0
  %154 = uitofp i1 %153 to float
  %155 = icmp eq i32 %126, 1
  %156 = uitofp i1 %155 to float
  %157 = icmp eq i32 %126, 2
  %158 = uitofp i1 %157 to float
  %159 = icmp eq i32 %126, 3
  %160 = uitofp i1 %159 to float
  br label %161

; <label>:161                                     ; preds = %152, %147
  %162 = phi float [ %148, %147 ], [ %154, %152 ]
  %163 = phi float [ %149, %147 ], [ %156, %152 ]
  %164 = phi float [ %150, %147 ], [ %158, %152 ]
  %165 = phi float [ %151, %147 ], [ %160, %152 ]
  %166 = or i32 %56, %55
  %167 = icmp sgt i32 %166, -1
  br i1 %167, label %168, label %172

; <label>:168                                     ; preds = %161
  %169 = icmp slt i32 %65, %43
  %170 = icmp slt i32 %68, %44
  %171 = and i1 %169, %170
  br label %172

; <label>:172                                     ; preds = %168, %161
  %173 = phi i1 [ false, %161 ], [ %171, %168 ]
  br i1 %173, label %174, label %4107

; <label>:174                                     ; preds = %172
  %175 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %55, i32 %56, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %176 = extractvalue %dx.types.ResRet.f32 %175, 0
  %177 = extractvalue %dx.types.ResRet.f32 %175, 1
  %178 = extractvalue %dx.types.ResRet.f32 %175, 2
  %179 = extractvalue %dx.types.ResRet.f32 %175, 3
  %180 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %65, i32 %56, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %181 = extractvalue %dx.types.ResRet.f32 %180, 0
  %182 = extractvalue %dx.types.ResRet.f32 %180, 1
  %183 = extractvalue %dx.types.ResRet.f32 %180, 2
  %184 = extractvalue %dx.types.ResRet.f32 %180, 3
  %185 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %55, i32 %68, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %186 = extractvalue %dx.types.ResRet.f32 %185, 0
  %187 = extractvalue %dx.types.ResRet.f32 %185, 1
  %188 = extractvalue %dx.types.ResRet.f32 %185, 2
  %189 = extractvalue %dx.types.ResRet.f32 %185, 3
  %190 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %65, i32 %68, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %191 = extractvalue %dx.types.ResRet.f32 %190, 0
  %192 = extractvalue %dx.types.ResRet.f32 %190, 1
  %193 = extractvalue %dx.types.ResRet.f32 %190, 2
  %194 = extractvalue %dx.types.ResRet.f32 %190, 3
  %195 = fcmp fast olt float %179, 0.000000e+00
  br i1 %195, label %196, label %230

; <label>:196                                     ; preds = %174
  %197 = fcmp fast ogt float %176, 0x3FA4B5DCC0000000
  %198 = fcmp fast ogt float %177, 0x3FA4B5DCC0000000
  %199 = fcmp fast ogt float %178, 0x3FA4B5DCC0000000
  %200 = select i1 %197, float 0.000000e+00, float 1.000000e+00
  %201 = select i1 %198, float 0.000000e+00, float 1.000000e+00
  %202 = select i1 %199, float 0.000000e+00, float 1.000000e+00
  %203 = fmul fast float %176, 0x3FB3D07220000000
  %204 = fmul fast float %177, 0x3FB3D07220000000
  %205 = fmul fast float %178, 0x3FB3D07220000000
  %206 = fadd fast float %176, 0x3FAC28F5C0000000
  %207 = fadd fast float %177, 0x3FAC28F5C0000000
  %208 = fadd fast float %178, 0x3FAC28F5C0000000
  %209 = fmul fast float %206, 0x3FEE54EDE0000000
  %210 = fmul fast float %207, 0x3FEE54EDE0000000
  %211 = fmul fast float %208, 0x3FEE54EDE0000000
  %212 = call float @dx.op.unary.f32(i32 23, float %209)  ; Log(value)
  %213 = call float @dx.op.unary.f32(i32 23, float %210)  ; Log(value)
  %214 = call float @dx.op.unary.f32(i32 23, float %211)  ; Log(value)
  %215 = fmul fast float %212, 0x4003333340000000
  %216 = fmul fast float %213, 0x4003333340000000
  %217 = fmul fast float %214, 0x4003333340000000
  %218 = call float @dx.op.unary.f32(i32 21, float %215)  ; Exp(value)
  %219 = call float @dx.op.unary.f32(i32 21, float %216)  ; Exp(value)
  %220 = call float @dx.op.unary.f32(i32 21, float %217)  ; Exp(value)
  %221 = fsub fast float %203, %218
  %222 = fsub fast float %204, %219
  %223 = fsub fast float %205, %220
  %224 = fmul fast float %221, %200
  %225 = fmul fast float %222, %201
  %226 = fmul fast float %223, %202
  %227 = fadd fast float %224, %218
  %228 = fadd fast float %225, %219
  %229 = fadd fast float %226, %220
  br label %445

; <label>:230                                     ; preds = %174
  %231 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %55, i32 %56, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %232 = extractvalue %dx.types.ResRet.f32 %231, 0
  %233 = fcmp fast ogt float %38, 5.000000e-01
  %234 = fcmp fast olt float %232, 1.000000e+00
  %235 = and i1 %233, %234
  br i1 %235, label %236, label %374

; <label>:236                                     ; preds = %230
  %237 = sitofp i32 %55 to float
  %238 = sitofp i32 %56 to float
  %239 = fadd fast float %237, 5.000000e-01
  %240 = fadd fast float %238, 5.000000e-01
  %241 = fdiv fast float %239, %45
  %242 = fdiv fast float %240, %46
  %243 = fmul fast float %241, 2.000000e+00
  %244 = fmul fast float %242, 2.000000e+00
  %245 = fadd fast float %243, -1.000000e+00
  %246 = fsub fast float 1.000000e+00, %244
  %247 = fmul fast float %245, %35
  %248 = call float @dx.op.tertiary.f32(i32 46, float %246, float %31, float %247)  ; FMad(a,b,c)
  %249 = call float @dx.op.tertiary.f32(i32 46, float %232, float %27, float %248)  ; FMad(a,b,c)
  %250 = fadd fast float %249, %23
  %251 = call float @dx.op.unary.f32(i32 6, float %250)  ; FAbs(value)
  %252 = fcmp fast ogt float %251, 0x3EB0C6F7A0000000
  br i1 %252, label %253, label %374

; <label>:253                                     ; preds = %236
  %254 = fmul fast float %245, %34
  %255 = call float @dx.op.tertiary.f32(i32 46, float %246, float %30, float %254)  ; FMad(a,b,c)
  %256 = call float @dx.op.tertiary.f32(i32 46, float %232, float %26, float %255)  ; FMad(a,b,c)
  %257 = fadd fast float %256, %22
  %258 = fmul fast float %245, %33
  %259 = call float @dx.op.tertiary.f32(i32 46, float %246, float %29, float %258)  ; FMad(a,b,c)
  %260 = call float @dx.op.tertiary.f32(i32 46, float %232, float %25, float %259)  ; FMad(a,b,c)
  %261 = fadd fast float %260, %21
  %262 = fmul fast float %245, %32
  %263 = call float @dx.op.tertiary.f32(i32 46, float %246, float %28, float %262)  ; FMad(a,b,c)
  %264 = call float @dx.op.tertiary.f32(i32 46, float %232, float %24, float %263)  ; FMad(a,b,c)
  %265 = fadd fast float %264, %20
  %266 = fdiv fast float %265, %250
  %267 = fdiv fast float %261, %250
  %268 = fdiv fast float %257, %250
  %269 = fsub fast float %266, %17
  %270 = fsub fast float %267, %18
  %271 = fsub fast float %268, %19
  %272 = fmul fast float %269, %269
  %273 = fmul fast float %270, %270
  %274 = fadd fast float %273, %272
  %275 = fmul fast float %271, %271
  %276 = fadd fast float %274, %275
  %277 = call float @dx.op.unary.f32(i32 24, float %276)  ; Sqrt(value)
  %278 = fsub fast float %277, %9
  %279 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %278)  ; FMax(a,b)
  %280 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %280, label %281, label %304

; <label>:281                                     ; preds = %253
  %282 = call float @dx.op.unary.f32(i32 6, float %270)  ; FAbs(value)
  %283 = fmul fast float %282, %11
  %284 = fcmp fast olt float %283, 0x3F50624DE0000000
  br i1 %284, label %285, label %288

; <label>:285                                     ; preds = %281
  %286 = fmul fast float %283, 5.000000e-01
  %287 = fsub fast float 1.000000e+00, %286
  br label %293

; <label>:288                                     ; preds = %281
  %289 = fmul fast float %283, 0xBFF7154760000000
  %290 = call float @dx.op.unary.f32(i32 21, float %289)  ; Exp(value)
  %291 = fsub fast float 1.000000e+00, %290
  %292 = fdiv fast float %291, %283
  br label %293

; <label>:293                                     ; preds = %288, %285
  %294 = phi float [ %287, %285 ], [ %292, %288 ]
  %295 = call float @dx.op.binary.f32(i32 36, float %267, float %18)  ; FMin(a,b)
  %296 = fsub fast float %295, %10
  %297 = fmul fast float %11, %296
  %298 = fsub fast float -0.000000e+00, %297
  %299 = call float @dx.op.binary.f32(i32 35, float %298, float -4.000000e+01)  ; FMax(a,b)
  %300 = call float @dx.op.binary.f32(i32 36, float %299, float 5.000000e+00)  ; FMin(a,b)
  %301 = fmul fast float %300, 0x3FF7154760000000
  %302 = call float @dx.op.unary.f32(i32 21, float %301)  ; Exp(value)
  %303 = fmul fast float %302, %294
  br label %304

; <label>:304                                     ; preds = %293, %253
  %305 = phi float [ %303, %293 ], [ 1.000000e+00, %253 ]
  %306 = fmul fast float %279, %16
  %307 = fmul fast float %306, %305
  %308 = fcmp fast ole float %277, %9
  %309 = fcmp fast olt float %277, 0x3F1A36E2E0000000
  %310 = or i1 %308, %309
  br i1 %310, label %357, label %311

; <label>:311                                     ; preds = %304
  %312 = fdiv fast float %9, %277
  %313 = fmul fast float %312, %269
  %314 = fmul fast float %312, %270
  %315 = fmul fast float %312, %271
  %316 = fadd fast float %313, %17
  %317 = fadd fast float %314, %18
  %318 = fadd fast float %315, %19
  %319 = fadd fast float %316, -9.000000e+02
  %320 = fadd fast float %317, -1.500000e+01
  %321 = fadd fast float %318, -7.500000e+02
  %322 = fmul fast float %319, 0x3F62345680000000
  %323 = fmul fast float %320, 0x3F62345680000000
  %324 = fmul fast float %321, 0x3F62345680000000
  %325 = call float @dx.op.dot3.f32(i32 55, float %322, float %323, float %324, float %322, float %323, float %324)  ; Dot3(ax,ay,az,bx,by,bz)
  %326 = fsub fast float 1.000000e+00, %325
  %327 = call float @dx.op.unary.f32(i32 7, float %326)  ; Saturate(value)
  %328 = fmul fast float %327, %327
  %329 = fadd fast float %316, %266
  %330 = fadd fast float %317, %267
  %331 = fadd fast float %318, %268
  %332 = fmul fast float %329, 0x3F52345680000000
  %333 = fadd fast float %332, -2.000000e+00
  %334 = fmul fast float %330, 0x3F52345680000000
  %335 = fadd fast float %334, 0xBFA1111120000000
  %336 = fmul fast float %331, 0x3F52345680000000
  %337 = fadd fast float %336, 0xBFFAAAAAC0000000
  %338 = call float @dx.op.dot3.f32(i32 55, float %333, float %335, float %337, float %333, float %335, float %337)  ; Dot3(ax,ay,az,bx,by,bz)
  %339 = fsub fast float 1.000000e+00, %338
  %340 = call float @dx.op.unary.f32(i32 7, float %339)  ; Saturate(value)
  %341 = fmul fast float %340, %340
  %342 = fmul fast float %341, 4.000000e+00
  %343 = fadd fast float %342, %328
  %344 = fadd fast float %266, -9.000000e+02
  %345 = fadd fast float %267, -1.500000e+01
  %346 = fadd fast float %268, -7.500000e+02
  %347 = fmul fast float %344, 0x3F62345680000000
  %348 = fmul fast float %345, 0x3F62345680000000
  %349 = fmul fast float %346, 0x3F62345680000000
  %350 = call float @dx.op.dot3.f32(i32 55, float %347, float %348, float %349, float %347, float %348, float %349)  ; Dot3(ax,ay,az,bx,by,bz)
  %351 = fsub fast float 1.000000e+00, %350
  %352 = call float @dx.op.unary.f32(i32 7, float %351)  ; Saturate(value)
  %353 = fmul fast float %352, %352
  %354 = fadd fast float %343, %353
  %355 = fmul fast float %278, 0x3F25D867E0000000
  %356 = fmul fast float %355, %354
  br label %357

; <label>:357                                     ; preds = %311, %304
  %358 = phi float [ %356, %311 ], [ 0.000000e+00, %304 ]
  %359 = fadd fast float %358, %307
  %360 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %359)  ; FMin(a,b)
  %361 = fmul fast float %360, 0xBFF7154760000000
  %362 = call float @dx.op.unary.f32(i32 21, float %361)  ; Exp(value)
  %363 = fsub fast float 1.000000e+00, %362
  %364 = call float @dx.op.binary.f32(i32 36, float %12, float %363)  ; FMin(a,b)
  %365 = fsub fast float %13, %176
  %366 = fsub fast float %14, %177
  %367 = fsub fast float %15, %178
  %368 = fmul fast float %364, %365
  %369 = fmul fast float %364, %366
  %370 = fmul fast float %364, %367
  %371 = fadd fast float %368, %176
  %372 = fadd fast float %369, %177
  %373 = fadd fast float %370, %178
  br label %374

; <label>:374                                     ; preds = %357, %236, %230
  %375 = phi float [ %371, %357 ], [ %176, %236 ], [ %176, %230 ]
  %376 = phi float [ %372, %357 ], [ %177, %236 ], [ %177, %230 ]
  %377 = phi float [ %373, %357 ], [ %178, %236 ], [ %178, %230 ]
  %378 = fadd fast float %5, 1.000000e+00
  %379 = fadd fast float %6, 1.000000e+00
  %380 = fsub fast float 1.000000e+00, %5
  %381 = fmul fast float %36, %378
  %382 = fmul fast float %36, %379
  %383 = fmul fast float %36, %380
  %384 = fmul fast float %381, %375
  %385 = fmul fast float %382, %376
  %386 = fmul fast float %383, %377
  %387 = fcmp fast ult float %37, 5.000000e-01
  br i1 %387, label %413, label %388

; <label>:388                                     ; preds = %374
  %389 = fmul fast float %384, 0x4004147AE0000000
  %390 = fmul fast float %385, 0x4004147AE0000000
  %391 = fmul fast float %386, 0x4004147AE0000000
  %392 = fadd fast float %389, 0x3F9EB851E0000000
  %393 = fadd fast float %390, 0x3F9EB851E0000000
  %394 = fadd fast float %391, 0x3F9EB851E0000000
  %395 = fmul fast float %392, %384
  %396 = fmul fast float %393, %385
  %397 = fmul fast float %394, %386
  %398 = fmul fast float %384, 0x400370A3E0000000
  %399 = fmul fast float %385, 0x400370A3E0000000
  %400 = fmul fast float %386, 0x400370A3E0000000
  %401 = fadd fast float %398, 0x3FE2E147A0000000
  %402 = fadd fast float %399, 0x3FE2E147A0000000
  %403 = fadd fast float %400, 0x3FE2E147A0000000
  %404 = fmul fast float %401, %384
  %405 = fmul fast float %402, %385
  %406 = fmul fast float %403, %386
  %407 = fadd fast float %404, 0x3FC1EB8520000000
  %408 = fadd fast float %405, 0x3FC1EB8520000000
  %409 = fadd fast float %406, 0x3FC1EB8520000000
  %410 = fdiv fast float %395, %407
  %411 = fdiv fast float %396, %408
  %412 = fdiv fast float %397, %409
  br label %413

; <label>:413                                     ; preds = %388, %374
  %414 = phi float [ %410, %388 ], [ %384, %374 ]
  %415 = phi float [ %411, %388 ], [ %385, %374 ]
  %416 = phi float [ %412, %388 ], [ %386, %374 ]
  %417 = call float @dx.op.unary.f32(i32 7, float %414)  ; Saturate(value)
  %418 = call float @dx.op.unary.f32(i32 7, float %415)  ; Saturate(value)
  %419 = call float @dx.op.unary.f32(i32 7, float %416)  ; Saturate(value)
  %420 = call float @dx.op.dot3.f32(i32 55, float %417, float %418, float %419, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %421 = fsub fast float %417, %420
  %422 = fsub fast float %418, %420
  %423 = fsub fast float %419, %420
  %424 = fmul fast float %421, %8
  %425 = fmul fast float %422, %8
  %426 = fmul fast float %423, %8
  %427 = fadd fast float %424, %420
  %428 = fadd fast float %425, %420
  %429 = fadd fast float %426, %420
  %430 = call float @dx.op.unary.f32(i32 7, float %427)  ; Saturate(value)
  %431 = call float @dx.op.unary.f32(i32 7, float %428)  ; Saturate(value)
  %432 = call float @dx.op.unary.f32(i32 7, float %429)  ; Saturate(value)
  %433 = fadd fast float %430, 0xBFC70A3D80000000
  %434 = fadd fast float %431, 0xBFC70A3D80000000
  %435 = fadd fast float %432, 0xBFC70A3D80000000
  %436 = fmul fast float %433, %7
  %437 = fmul fast float %434, %7
  %438 = fmul fast float %435, %7
  %439 = fadd fast float %436, 0x3FC70A3D80000000
  %440 = fadd fast float %437, 0x3FC70A3D80000000
  %441 = fadd fast float %438, 0x3FC70A3D80000000
  %442 = call float @dx.op.unary.f32(i32 7, float %439)  ; Saturate(value)
  %443 = call float @dx.op.unary.f32(i32 7, float %440)  ; Saturate(value)
  %444 = call float @dx.op.unary.f32(i32 7, float %441)  ; Saturate(value)
  br label %445

; <label>:445                                     ; preds = %413, %196
  %446 = phi float [ %227, %196 ], [ %442, %413 ]
  %447 = phi float [ %228, %196 ], [ %443, %413 ]
  %448 = phi float [ %229, %196 ], [ %444, %413 ]
  %449 = fcmp fast olt float %184, 0.000000e+00
  br i1 %449, label %450, label %484

; <label>:450                                     ; preds = %445
  %451 = fcmp fast ogt float %181, 0x3FA4B5DCC0000000
  %452 = fcmp fast ogt float %182, 0x3FA4B5DCC0000000
  %453 = fcmp fast ogt float %183, 0x3FA4B5DCC0000000
  %454 = select i1 %451, float 0.000000e+00, float 1.000000e+00
  %455 = select i1 %452, float 0.000000e+00, float 1.000000e+00
  %456 = select i1 %453, float 0.000000e+00, float 1.000000e+00
  %457 = fmul fast float %181, 0x3FB3D07220000000
  %458 = fmul fast float %182, 0x3FB3D07220000000
  %459 = fmul fast float %183, 0x3FB3D07220000000
  %460 = fadd fast float %181, 0x3FAC28F5C0000000
  %461 = fadd fast float %182, 0x3FAC28F5C0000000
  %462 = fadd fast float %183, 0x3FAC28F5C0000000
  %463 = fmul fast float %460, 0x3FEE54EDE0000000
  %464 = fmul fast float %461, 0x3FEE54EDE0000000
  %465 = fmul fast float %462, 0x3FEE54EDE0000000
  %466 = call float @dx.op.unary.f32(i32 23, float %463)  ; Log(value)
  %467 = call float @dx.op.unary.f32(i32 23, float %464)  ; Log(value)
  %468 = call float @dx.op.unary.f32(i32 23, float %465)  ; Log(value)
  %469 = fmul fast float %466, 0x4003333340000000
  %470 = fmul fast float %467, 0x4003333340000000
  %471 = fmul fast float %468, 0x4003333340000000
  %472 = call float @dx.op.unary.f32(i32 21, float %469)  ; Exp(value)
  %473 = call float @dx.op.unary.f32(i32 21, float %470)  ; Exp(value)
  %474 = call float @dx.op.unary.f32(i32 21, float %471)  ; Exp(value)
  %475 = fsub fast float %457, %472
  %476 = fsub fast float %458, %473
  %477 = fsub fast float %459, %474
  %478 = fmul fast float %475, %454
  %479 = fmul fast float %476, %455
  %480 = fmul fast float %477, %456
  %481 = fadd fast float %478, %472
  %482 = fadd fast float %479, %473
  %483 = fadd fast float %480, %474
  br label %699

; <label>:484                                     ; preds = %445
  %485 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %65, i32 %56, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %486 = extractvalue %dx.types.ResRet.f32 %485, 0
  %487 = fcmp fast ogt float %38, 5.000000e-01
  %488 = fcmp fast olt float %486, 1.000000e+00
  %489 = and i1 %487, %488
  br i1 %489, label %490, label %628

; <label>:490                                     ; preds = %484
  %491 = sitofp i32 %65 to float
  %492 = sitofp i32 %56 to float
  %493 = fadd fast float %491, 5.000000e-01
  %494 = fadd fast float %492, 5.000000e-01
  %495 = fdiv fast float %493, %45
  %496 = fdiv fast float %494, %46
  %497 = fmul fast float %495, 2.000000e+00
  %498 = fmul fast float %496, 2.000000e+00
  %499 = fadd fast float %497, -1.000000e+00
  %500 = fsub fast float 1.000000e+00, %498
  %501 = fmul fast float %499, %35
  %502 = call float @dx.op.tertiary.f32(i32 46, float %500, float %31, float %501)  ; FMad(a,b,c)
  %503 = call float @dx.op.tertiary.f32(i32 46, float %486, float %27, float %502)  ; FMad(a,b,c)
  %504 = fadd fast float %503, %23
  %505 = call float @dx.op.unary.f32(i32 6, float %504)  ; FAbs(value)
  %506 = fcmp fast ogt float %505, 0x3EB0C6F7A0000000
  br i1 %506, label %507, label %628

; <label>:507                                     ; preds = %490
  %508 = fmul fast float %499, %34
  %509 = call float @dx.op.tertiary.f32(i32 46, float %500, float %30, float %508)  ; FMad(a,b,c)
  %510 = call float @dx.op.tertiary.f32(i32 46, float %486, float %26, float %509)  ; FMad(a,b,c)
  %511 = fadd fast float %510, %22
  %512 = fmul fast float %499, %33
  %513 = call float @dx.op.tertiary.f32(i32 46, float %500, float %29, float %512)  ; FMad(a,b,c)
  %514 = call float @dx.op.tertiary.f32(i32 46, float %486, float %25, float %513)  ; FMad(a,b,c)
  %515 = fadd fast float %514, %21
  %516 = fmul fast float %499, %32
  %517 = call float @dx.op.tertiary.f32(i32 46, float %500, float %28, float %516)  ; FMad(a,b,c)
  %518 = call float @dx.op.tertiary.f32(i32 46, float %486, float %24, float %517)  ; FMad(a,b,c)
  %519 = fadd fast float %518, %20
  %520 = fdiv fast float %519, %504
  %521 = fdiv fast float %515, %504
  %522 = fdiv fast float %511, %504
  %523 = fsub fast float %520, %17
  %524 = fsub fast float %521, %18
  %525 = fsub fast float %522, %19
  %526 = fmul fast float %523, %523
  %527 = fmul fast float %524, %524
  %528 = fadd fast float %527, %526
  %529 = fmul fast float %525, %525
  %530 = fadd fast float %528, %529
  %531 = call float @dx.op.unary.f32(i32 24, float %530)  ; Sqrt(value)
  %532 = fsub fast float %531, %9
  %533 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %532)  ; FMax(a,b)
  %534 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %534, label %535, label %558

; <label>:535                                     ; preds = %507
  %536 = call float @dx.op.unary.f32(i32 6, float %524)  ; FAbs(value)
  %537 = fmul fast float %536, %11
  %538 = fcmp fast olt float %537, 0x3F50624DE0000000
  br i1 %538, label %539, label %542

; <label>:539                                     ; preds = %535
  %540 = fmul fast float %537, 5.000000e-01
  %541 = fsub fast float 1.000000e+00, %540
  br label %547

; <label>:542                                     ; preds = %535
  %543 = fmul fast float %537, 0xBFF7154760000000
  %544 = call float @dx.op.unary.f32(i32 21, float %543)  ; Exp(value)
  %545 = fsub fast float 1.000000e+00, %544
  %546 = fdiv fast float %545, %537
  br label %547

; <label>:547                                     ; preds = %542, %539
  %548 = phi float [ %541, %539 ], [ %546, %542 ]
  %549 = call float @dx.op.binary.f32(i32 36, float %521, float %18)  ; FMin(a,b)
  %550 = fsub fast float %549, %10
  %551 = fmul fast float %11, %550
  %552 = fsub fast float -0.000000e+00, %551
  %553 = call float @dx.op.binary.f32(i32 35, float %552, float -4.000000e+01)  ; FMax(a,b)
  %554 = call float @dx.op.binary.f32(i32 36, float %553, float 5.000000e+00)  ; FMin(a,b)
  %555 = fmul fast float %554, 0x3FF7154760000000
  %556 = call float @dx.op.unary.f32(i32 21, float %555)  ; Exp(value)
  %557 = fmul fast float %556, %548
  br label %558

; <label>:558                                     ; preds = %547, %507
  %559 = phi float [ %557, %547 ], [ 1.000000e+00, %507 ]
  %560 = fmul fast float %533, %16
  %561 = fmul fast float %560, %559
  %562 = fcmp fast ole float %531, %9
  %563 = fcmp fast olt float %531, 0x3F1A36E2E0000000
  %564 = or i1 %562, %563
  br i1 %564, label %611, label %565

; <label>:565                                     ; preds = %558
  %566 = fdiv fast float %9, %531
  %567 = fmul fast float %566, %523
  %568 = fmul fast float %566, %524
  %569 = fmul fast float %566, %525
  %570 = fadd fast float %567, %17
  %571 = fadd fast float %568, %18
  %572 = fadd fast float %569, %19
  %573 = fadd fast float %570, -9.000000e+02
  %574 = fadd fast float %571, -1.500000e+01
  %575 = fadd fast float %572, -7.500000e+02
  %576 = fmul fast float %573, 0x3F62345680000000
  %577 = fmul fast float %574, 0x3F62345680000000
  %578 = fmul fast float %575, 0x3F62345680000000
  %579 = call float @dx.op.dot3.f32(i32 55, float %576, float %577, float %578, float %576, float %577, float %578)  ; Dot3(ax,ay,az,bx,by,bz)
  %580 = fsub fast float 1.000000e+00, %579
  %581 = call float @dx.op.unary.f32(i32 7, float %580)  ; Saturate(value)
  %582 = fmul fast float %581, %581
  %583 = fadd fast float %570, %520
  %584 = fadd fast float %571, %521
  %585 = fadd fast float %572, %522
  %586 = fmul fast float %583, 0x3F52345680000000
  %587 = fadd fast float %586, -2.000000e+00
  %588 = fmul fast float %584, 0x3F52345680000000
  %589 = fadd fast float %588, 0xBFA1111120000000
  %590 = fmul fast float %585, 0x3F52345680000000
  %591 = fadd fast float %590, 0xBFFAAAAAC0000000
  %592 = call float @dx.op.dot3.f32(i32 55, float %587, float %589, float %591, float %587, float %589, float %591)  ; Dot3(ax,ay,az,bx,by,bz)
  %593 = fsub fast float 1.000000e+00, %592
  %594 = call float @dx.op.unary.f32(i32 7, float %593)  ; Saturate(value)
  %595 = fmul fast float %594, %594
  %596 = fmul fast float %595, 4.000000e+00
  %597 = fadd fast float %596, %582
  %598 = fadd fast float %520, -9.000000e+02
  %599 = fadd fast float %521, -1.500000e+01
  %600 = fadd fast float %522, -7.500000e+02
  %601 = fmul fast float %598, 0x3F62345680000000
  %602 = fmul fast float %599, 0x3F62345680000000
  %603 = fmul fast float %600, 0x3F62345680000000
  %604 = call float @dx.op.dot3.f32(i32 55, float %601, float %602, float %603, float %601, float %602, float %603)  ; Dot3(ax,ay,az,bx,by,bz)
  %605 = fsub fast float 1.000000e+00, %604
  %606 = call float @dx.op.unary.f32(i32 7, float %605)  ; Saturate(value)
  %607 = fmul fast float %606, %606
  %608 = fadd fast float %597, %607
  %609 = fmul fast float %532, 0x3F25D867E0000000
  %610 = fmul fast float %609, %608
  br label %611

; <label>:611                                     ; preds = %565, %558
  %612 = phi float [ %610, %565 ], [ 0.000000e+00, %558 ]
  %613 = fadd fast float %612, %561
  %614 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %613)  ; FMin(a,b)
  %615 = fmul fast float %614, 0xBFF7154760000000
  %616 = call float @dx.op.unary.f32(i32 21, float %615)  ; Exp(value)
  %617 = fsub fast float 1.000000e+00, %616
  %618 = call float @dx.op.binary.f32(i32 36, float %12, float %617)  ; FMin(a,b)
  %619 = fsub fast float %13, %181
  %620 = fsub fast float %14, %182
  %621 = fsub fast float %15, %183
  %622 = fmul fast float %618, %619
  %623 = fmul fast float %618, %620
  %624 = fmul fast float %618, %621
  %625 = fadd fast float %622, %181
  %626 = fadd fast float %623, %182
  %627 = fadd fast float %624, %183
  br label %628

; <label>:628                                     ; preds = %611, %490, %484
  %629 = phi float [ %625, %611 ], [ %181, %490 ], [ %181, %484 ]
  %630 = phi float [ %626, %611 ], [ %182, %490 ], [ %182, %484 ]
  %631 = phi float [ %627, %611 ], [ %183, %490 ], [ %183, %484 ]
  %632 = fadd fast float %5, 1.000000e+00
  %633 = fadd fast float %6, 1.000000e+00
  %634 = fsub fast float 1.000000e+00, %5
  %635 = fmul fast float %36, %632
  %636 = fmul fast float %36, %633
  %637 = fmul fast float %36, %634
  %638 = fmul fast float %635, %629
  %639 = fmul fast float %636, %630
  %640 = fmul fast float %637, %631
  %641 = fcmp fast ult float %37, 5.000000e-01
  br i1 %641, label %667, label %642

; <label>:642                                     ; preds = %628
  %643 = fmul fast float %638, 0x4004147AE0000000
  %644 = fmul fast float %639, 0x4004147AE0000000
  %645 = fmul fast float %640, 0x4004147AE0000000
  %646 = fadd fast float %643, 0x3F9EB851E0000000
  %647 = fadd fast float %644, 0x3F9EB851E0000000
  %648 = fadd fast float %645, 0x3F9EB851E0000000
  %649 = fmul fast float %646, %638
  %650 = fmul fast float %647, %639
  %651 = fmul fast float %648, %640
  %652 = fmul fast float %638, 0x400370A3E0000000
  %653 = fmul fast float %639, 0x400370A3E0000000
  %654 = fmul fast float %640, 0x400370A3E0000000
  %655 = fadd fast float %652, 0x3FE2E147A0000000
  %656 = fadd fast float %653, 0x3FE2E147A0000000
  %657 = fadd fast float %654, 0x3FE2E147A0000000
  %658 = fmul fast float %655, %638
  %659 = fmul fast float %656, %639
  %660 = fmul fast float %657, %640
  %661 = fadd fast float %658, 0x3FC1EB8520000000
  %662 = fadd fast float %659, 0x3FC1EB8520000000
  %663 = fadd fast float %660, 0x3FC1EB8520000000
  %664 = fdiv fast float %649, %661
  %665 = fdiv fast float %650, %662
  %666 = fdiv fast float %651, %663
  br label %667

; <label>:667                                     ; preds = %642, %628
  %668 = phi float [ %664, %642 ], [ %638, %628 ]
  %669 = phi float [ %665, %642 ], [ %639, %628 ]
  %670 = phi float [ %666, %642 ], [ %640, %628 ]
  %671 = call float @dx.op.unary.f32(i32 7, float %668)  ; Saturate(value)
  %672 = call float @dx.op.unary.f32(i32 7, float %669)  ; Saturate(value)
  %673 = call float @dx.op.unary.f32(i32 7, float %670)  ; Saturate(value)
  %674 = call float @dx.op.dot3.f32(i32 55, float %671, float %672, float %673, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %675 = fsub fast float %671, %674
  %676 = fsub fast float %672, %674
  %677 = fsub fast float %673, %674
  %678 = fmul fast float %675, %8
  %679 = fmul fast float %676, %8
  %680 = fmul fast float %677, %8
  %681 = fadd fast float %678, %674
  %682 = fadd fast float %679, %674
  %683 = fadd fast float %680, %674
  %684 = call float @dx.op.unary.f32(i32 7, float %681)  ; Saturate(value)
  %685 = call float @dx.op.unary.f32(i32 7, float %682)  ; Saturate(value)
  %686 = call float @dx.op.unary.f32(i32 7, float %683)  ; Saturate(value)
  %687 = fadd fast float %684, 0xBFC70A3D80000000
  %688 = fadd fast float %685, 0xBFC70A3D80000000
  %689 = fadd fast float %686, 0xBFC70A3D80000000
  %690 = fmul fast float %687, %7
  %691 = fmul fast float %688, %7
  %692 = fmul fast float %689, %7
  %693 = fadd fast float %690, 0x3FC70A3D80000000
  %694 = fadd fast float %691, 0x3FC70A3D80000000
  %695 = fadd fast float %692, 0x3FC70A3D80000000
  %696 = call float @dx.op.unary.f32(i32 7, float %693)  ; Saturate(value)
  %697 = call float @dx.op.unary.f32(i32 7, float %694)  ; Saturate(value)
  %698 = call float @dx.op.unary.f32(i32 7, float %695)  ; Saturate(value)
  br label %699

; <label>:699                                     ; preds = %667, %450
  %700 = phi float [ %481, %450 ], [ %696, %667 ]
  %701 = phi float [ %482, %450 ], [ %697, %667 ]
  %702 = phi float [ %483, %450 ], [ %698, %667 ]
  %703 = fcmp fast olt float %189, 0.000000e+00
  br i1 %703, label %704, label %738

; <label>:704                                     ; preds = %699
  %705 = fcmp fast ogt float %186, 0x3FA4B5DCC0000000
  %706 = fcmp fast ogt float %187, 0x3FA4B5DCC0000000
  %707 = fcmp fast ogt float %188, 0x3FA4B5DCC0000000
  %708 = select i1 %705, float 0.000000e+00, float 1.000000e+00
  %709 = select i1 %706, float 0.000000e+00, float 1.000000e+00
  %710 = select i1 %707, float 0.000000e+00, float 1.000000e+00
  %711 = fmul fast float %186, 0x3FB3D07220000000
  %712 = fmul fast float %187, 0x3FB3D07220000000
  %713 = fmul fast float %188, 0x3FB3D07220000000
  %714 = fadd fast float %186, 0x3FAC28F5C0000000
  %715 = fadd fast float %187, 0x3FAC28F5C0000000
  %716 = fadd fast float %188, 0x3FAC28F5C0000000
  %717 = fmul fast float %714, 0x3FEE54EDE0000000
  %718 = fmul fast float %715, 0x3FEE54EDE0000000
  %719 = fmul fast float %716, 0x3FEE54EDE0000000
  %720 = call float @dx.op.unary.f32(i32 23, float %717)  ; Log(value)
  %721 = call float @dx.op.unary.f32(i32 23, float %718)  ; Log(value)
  %722 = call float @dx.op.unary.f32(i32 23, float %719)  ; Log(value)
  %723 = fmul fast float %720, 0x4003333340000000
  %724 = fmul fast float %721, 0x4003333340000000
  %725 = fmul fast float %722, 0x4003333340000000
  %726 = call float @dx.op.unary.f32(i32 21, float %723)  ; Exp(value)
  %727 = call float @dx.op.unary.f32(i32 21, float %724)  ; Exp(value)
  %728 = call float @dx.op.unary.f32(i32 21, float %725)  ; Exp(value)
  %729 = fsub fast float %711, %726
  %730 = fsub fast float %712, %727
  %731 = fsub fast float %713, %728
  %732 = fmul fast float %729, %708
  %733 = fmul fast float %730, %709
  %734 = fmul fast float %731, %710
  %735 = fadd fast float %732, %726
  %736 = fadd fast float %733, %727
  %737 = fadd fast float %734, %728
  br label %953

; <label>:738                                     ; preds = %699
  %739 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %55, i32 %68, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %740 = extractvalue %dx.types.ResRet.f32 %739, 0
  %741 = fcmp fast ogt float %38, 5.000000e-01
  %742 = fcmp fast olt float %740, 1.000000e+00
  %743 = and i1 %741, %742
  br i1 %743, label %744, label %882

; <label>:744                                     ; preds = %738
  %745 = sitofp i32 %55 to float
  %746 = sitofp i32 %68 to float
  %747 = fadd fast float %745, 5.000000e-01
  %748 = fadd fast float %746, 5.000000e-01
  %749 = fdiv fast float %747, %45
  %750 = fdiv fast float %748, %46
  %751 = fmul fast float %749, 2.000000e+00
  %752 = fmul fast float %750, 2.000000e+00
  %753 = fadd fast float %751, -1.000000e+00
  %754 = fsub fast float 1.000000e+00, %752
  %755 = fmul fast float %753, %35
  %756 = call float @dx.op.tertiary.f32(i32 46, float %754, float %31, float %755)  ; FMad(a,b,c)
  %757 = call float @dx.op.tertiary.f32(i32 46, float %740, float %27, float %756)  ; FMad(a,b,c)
  %758 = fadd fast float %757, %23
  %759 = call float @dx.op.unary.f32(i32 6, float %758)  ; FAbs(value)
  %760 = fcmp fast ogt float %759, 0x3EB0C6F7A0000000
  br i1 %760, label %761, label %882

; <label>:761                                     ; preds = %744
  %762 = fmul fast float %753, %34
  %763 = call float @dx.op.tertiary.f32(i32 46, float %754, float %30, float %762)  ; FMad(a,b,c)
  %764 = call float @dx.op.tertiary.f32(i32 46, float %740, float %26, float %763)  ; FMad(a,b,c)
  %765 = fadd fast float %764, %22
  %766 = fmul fast float %753, %33
  %767 = call float @dx.op.tertiary.f32(i32 46, float %754, float %29, float %766)  ; FMad(a,b,c)
  %768 = call float @dx.op.tertiary.f32(i32 46, float %740, float %25, float %767)  ; FMad(a,b,c)
  %769 = fadd fast float %768, %21
  %770 = fmul fast float %753, %32
  %771 = call float @dx.op.tertiary.f32(i32 46, float %754, float %28, float %770)  ; FMad(a,b,c)
  %772 = call float @dx.op.tertiary.f32(i32 46, float %740, float %24, float %771)  ; FMad(a,b,c)
  %773 = fadd fast float %772, %20
  %774 = fdiv fast float %773, %758
  %775 = fdiv fast float %769, %758
  %776 = fdiv fast float %765, %758
  %777 = fsub fast float %774, %17
  %778 = fsub fast float %775, %18
  %779 = fsub fast float %776, %19
  %780 = fmul fast float %777, %777
  %781 = fmul fast float %778, %778
  %782 = fadd fast float %781, %780
  %783 = fmul fast float %779, %779
  %784 = fadd fast float %782, %783
  %785 = call float @dx.op.unary.f32(i32 24, float %784)  ; Sqrt(value)
  %786 = fsub fast float %785, %9
  %787 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %786)  ; FMax(a,b)
  %788 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %788, label %789, label %812

; <label>:789                                     ; preds = %761
  %790 = call float @dx.op.unary.f32(i32 6, float %778)  ; FAbs(value)
  %791 = fmul fast float %790, %11
  %792 = fcmp fast olt float %791, 0x3F50624DE0000000
  br i1 %792, label %793, label %796

; <label>:793                                     ; preds = %789
  %794 = fmul fast float %791, 5.000000e-01
  %795 = fsub fast float 1.000000e+00, %794
  br label %801

; <label>:796                                     ; preds = %789
  %797 = fmul fast float %791, 0xBFF7154760000000
  %798 = call float @dx.op.unary.f32(i32 21, float %797)  ; Exp(value)
  %799 = fsub fast float 1.000000e+00, %798
  %800 = fdiv fast float %799, %791
  br label %801

; <label>:801                                     ; preds = %796, %793
  %802 = phi float [ %795, %793 ], [ %800, %796 ]
  %803 = call float @dx.op.binary.f32(i32 36, float %775, float %18)  ; FMin(a,b)
  %804 = fsub fast float %803, %10
  %805 = fmul fast float %11, %804
  %806 = fsub fast float -0.000000e+00, %805
  %807 = call float @dx.op.binary.f32(i32 35, float %806, float -4.000000e+01)  ; FMax(a,b)
  %808 = call float @dx.op.binary.f32(i32 36, float %807, float 5.000000e+00)  ; FMin(a,b)
  %809 = fmul fast float %808, 0x3FF7154760000000
  %810 = call float @dx.op.unary.f32(i32 21, float %809)  ; Exp(value)
  %811 = fmul fast float %810, %802
  br label %812

; <label>:812                                     ; preds = %801, %761
  %813 = phi float [ %811, %801 ], [ 1.000000e+00, %761 ]
  %814 = fmul fast float %787, %16
  %815 = fmul fast float %814, %813
  %816 = fcmp fast ole float %785, %9
  %817 = fcmp fast olt float %785, 0x3F1A36E2E0000000
  %818 = or i1 %816, %817
  br i1 %818, label %865, label %819

; <label>:819                                     ; preds = %812
  %820 = fdiv fast float %9, %785
  %821 = fmul fast float %820, %777
  %822 = fmul fast float %820, %778
  %823 = fmul fast float %820, %779
  %824 = fadd fast float %821, %17
  %825 = fadd fast float %822, %18
  %826 = fadd fast float %823, %19
  %827 = fadd fast float %824, -9.000000e+02
  %828 = fadd fast float %825, -1.500000e+01
  %829 = fadd fast float %826, -7.500000e+02
  %830 = fmul fast float %827, 0x3F62345680000000
  %831 = fmul fast float %828, 0x3F62345680000000
  %832 = fmul fast float %829, 0x3F62345680000000
  %833 = call float @dx.op.dot3.f32(i32 55, float %830, float %831, float %832, float %830, float %831, float %832)  ; Dot3(ax,ay,az,bx,by,bz)
  %834 = fsub fast float 1.000000e+00, %833
  %835 = call float @dx.op.unary.f32(i32 7, float %834)  ; Saturate(value)
  %836 = fmul fast float %835, %835
  %837 = fadd fast float %824, %774
  %838 = fadd fast float %825, %775
  %839 = fadd fast float %826, %776
  %840 = fmul fast float %837, 0x3F52345680000000
  %841 = fadd fast float %840, -2.000000e+00
  %842 = fmul fast float %838, 0x3F52345680000000
  %843 = fadd fast float %842, 0xBFA1111120000000
  %844 = fmul fast float %839, 0x3F52345680000000
  %845 = fadd fast float %844, 0xBFFAAAAAC0000000
  %846 = call float @dx.op.dot3.f32(i32 55, float %841, float %843, float %845, float %841, float %843, float %845)  ; Dot3(ax,ay,az,bx,by,bz)
  %847 = fsub fast float 1.000000e+00, %846
  %848 = call float @dx.op.unary.f32(i32 7, float %847)  ; Saturate(value)
  %849 = fmul fast float %848, %848
  %850 = fmul fast float %849, 4.000000e+00
  %851 = fadd fast float %850, %836
  %852 = fadd fast float %774, -9.000000e+02
  %853 = fadd fast float %775, -1.500000e+01
  %854 = fadd fast float %776, -7.500000e+02
  %855 = fmul fast float %852, 0x3F62345680000000
  %856 = fmul fast float %853, 0x3F62345680000000
  %857 = fmul fast float %854, 0x3F62345680000000
  %858 = call float @dx.op.dot3.f32(i32 55, float %855, float %856, float %857, float %855, float %856, float %857)  ; Dot3(ax,ay,az,bx,by,bz)
  %859 = fsub fast float 1.000000e+00, %858
  %860 = call float @dx.op.unary.f32(i32 7, float %859)  ; Saturate(value)
  %861 = fmul fast float %860, %860
  %862 = fadd fast float %851, %861
  %863 = fmul fast float %786, 0x3F25D867E0000000
  %864 = fmul fast float %863, %862
  br label %865

; <label>:865                                     ; preds = %819, %812
  %866 = phi float [ %864, %819 ], [ 0.000000e+00, %812 ]
  %867 = fadd fast float %866, %815
  %868 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %867)  ; FMin(a,b)
  %869 = fmul fast float %868, 0xBFF7154760000000
  %870 = call float @dx.op.unary.f32(i32 21, float %869)  ; Exp(value)
  %871 = fsub fast float 1.000000e+00, %870
  %872 = call float @dx.op.binary.f32(i32 36, float %12, float %871)  ; FMin(a,b)
  %873 = fsub fast float %13, %186
  %874 = fsub fast float %14, %187
  %875 = fsub fast float %15, %188
  %876 = fmul fast float %872, %873
  %877 = fmul fast float %872, %874
  %878 = fmul fast float %872, %875
  %879 = fadd fast float %876, %186
  %880 = fadd fast float %877, %187
  %881 = fadd fast float %878, %188
  br label %882

; <label>:882                                     ; preds = %865, %744, %738
  %883 = phi float [ %879, %865 ], [ %186, %744 ], [ %186, %738 ]
  %884 = phi float [ %880, %865 ], [ %187, %744 ], [ %187, %738 ]
  %885 = phi float [ %881, %865 ], [ %188, %744 ], [ %188, %738 ]
  %886 = fadd fast float %5, 1.000000e+00
  %887 = fadd fast float %6, 1.000000e+00
  %888 = fsub fast float 1.000000e+00, %5
  %889 = fmul fast float %36, %886
  %890 = fmul fast float %36, %887
  %891 = fmul fast float %36, %888
  %892 = fmul fast float %889, %883
  %893 = fmul fast float %890, %884
  %894 = fmul fast float %891, %885
  %895 = fcmp fast ult float %37, 5.000000e-01
  br i1 %895, label %921, label %896

; <label>:896                                     ; preds = %882
  %897 = fmul fast float %892, 0x4004147AE0000000
  %898 = fmul fast float %893, 0x4004147AE0000000
  %899 = fmul fast float %894, 0x4004147AE0000000
  %900 = fadd fast float %897, 0x3F9EB851E0000000
  %901 = fadd fast float %898, 0x3F9EB851E0000000
  %902 = fadd fast float %899, 0x3F9EB851E0000000
  %903 = fmul fast float %900, %892
  %904 = fmul fast float %901, %893
  %905 = fmul fast float %902, %894
  %906 = fmul fast float %892, 0x400370A3E0000000
  %907 = fmul fast float %893, 0x400370A3E0000000
  %908 = fmul fast float %894, 0x400370A3E0000000
  %909 = fadd fast float %906, 0x3FE2E147A0000000
  %910 = fadd fast float %907, 0x3FE2E147A0000000
  %911 = fadd fast float %908, 0x3FE2E147A0000000
  %912 = fmul fast float %909, %892
  %913 = fmul fast float %910, %893
  %914 = fmul fast float %911, %894
  %915 = fadd fast float %912, 0x3FC1EB8520000000
  %916 = fadd fast float %913, 0x3FC1EB8520000000
  %917 = fadd fast float %914, 0x3FC1EB8520000000
  %918 = fdiv fast float %903, %915
  %919 = fdiv fast float %904, %916
  %920 = fdiv fast float %905, %917
  br label %921

; <label>:921                                     ; preds = %896, %882
  %922 = phi float [ %918, %896 ], [ %892, %882 ]
  %923 = phi float [ %919, %896 ], [ %893, %882 ]
  %924 = phi float [ %920, %896 ], [ %894, %882 ]
  %925 = call float @dx.op.unary.f32(i32 7, float %922)  ; Saturate(value)
  %926 = call float @dx.op.unary.f32(i32 7, float %923)  ; Saturate(value)
  %927 = call float @dx.op.unary.f32(i32 7, float %924)  ; Saturate(value)
  %928 = call float @dx.op.dot3.f32(i32 55, float %925, float %926, float %927, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %929 = fsub fast float %925, %928
  %930 = fsub fast float %926, %928
  %931 = fsub fast float %927, %928
  %932 = fmul fast float %929, %8
  %933 = fmul fast float %930, %8
  %934 = fmul fast float %931, %8
  %935 = fadd fast float %932, %928
  %936 = fadd fast float %933, %928
  %937 = fadd fast float %934, %928
  %938 = call float @dx.op.unary.f32(i32 7, float %935)  ; Saturate(value)
  %939 = call float @dx.op.unary.f32(i32 7, float %936)  ; Saturate(value)
  %940 = call float @dx.op.unary.f32(i32 7, float %937)  ; Saturate(value)
  %941 = fadd fast float %938, 0xBFC70A3D80000000
  %942 = fadd fast float %939, 0xBFC70A3D80000000
  %943 = fadd fast float %940, 0xBFC70A3D80000000
  %944 = fmul fast float %941, %7
  %945 = fmul fast float %942, %7
  %946 = fmul fast float %943, %7
  %947 = fadd fast float %944, 0x3FC70A3D80000000
  %948 = fadd fast float %945, 0x3FC70A3D80000000
  %949 = fadd fast float %946, 0x3FC70A3D80000000
  %950 = call float @dx.op.unary.f32(i32 7, float %947)  ; Saturate(value)
  %951 = call float @dx.op.unary.f32(i32 7, float %948)  ; Saturate(value)
  %952 = call float @dx.op.unary.f32(i32 7, float %949)  ; Saturate(value)
  br label %953

; <label>:953                                     ; preds = %921, %704
  %954 = phi float [ %735, %704 ], [ %950, %921 ]
  %955 = phi float [ %736, %704 ], [ %951, %921 ]
  %956 = phi float [ %737, %704 ], [ %952, %921 ]
  %957 = fcmp fast olt float %194, 0.000000e+00
  br i1 %957, label %958, label %992

; <label>:958                                     ; preds = %953
  %959 = fcmp fast ogt float %191, 0x3FA4B5DCC0000000
  %960 = fcmp fast ogt float %192, 0x3FA4B5DCC0000000
  %961 = fcmp fast ogt float %193, 0x3FA4B5DCC0000000
  %962 = select i1 %959, float 0.000000e+00, float 1.000000e+00
  %963 = select i1 %960, float 0.000000e+00, float 1.000000e+00
  %964 = select i1 %961, float 0.000000e+00, float 1.000000e+00
  %965 = fmul fast float %191, 0x3FB3D07220000000
  %966 = fmul fast float %192, 0x3FB3D07220000000
  %967 = fmul fast float %193, 0x3FB3D07220000000
  %968 = fadd fast float %191, 0x3FAC28F5C0000000
  %969 = fadd fast float %192, 0x3FAC28F5C0000000
  %970 = fadd fast float %193, 0x3FAC28F5C0000000
  %971 = fmul fast float %968, 0x3FEE54EDE0000000
  %972 = fmul fast float %969, 0x3FEE54EDE0000000
  %973 = fmul fast float %970, 0x3FEE54EDE0000000
  %974 = call float @dx.op.unary.f32(i32 23, float %971)  ; Log(value)
  %975 = call float @dx.op.unary.f32(i32 23, float %972)  ; Log(value)
  %976 = call float @dx.op.unary.f32(i32 23, float %973)  ; Log(value)
  %977 = fmul fast float %974, 0x4003333340000000
  %978 = fmul fast float %975, 0x4003333340000000
  %979 = fmul fast float %976, 0x4003333340000000
  %980 = call float @dx.op.unary.f32(i32 21, float %977)  ; Exp(value)
  %981 = call float @dx.op.unary.f32(i32 21, float %978)  ; Exp(value)
  %982 = call float @dx.op.unary.f32(i32 21, float %979)  ; Exp(value)
  %983 = fsub fast float %965, %980
  %984 = fsub fast float %966, %981
  %985 = fsub fast float %967, %982
  %986 = fmul fast float %983, %962
  %987 = fmul fast float %984, %963
  %988 = fmul fast float %985, %964
  %989 = fadd fast float %986, %980
  %990 = fadd fast float %987, %981
  %991 = fadd fast float %988, %982
  br label %1207

; <label>:992                                     ; preds = %953
  %993 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %65, i32 %68, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %994 = extractvalue %dx.types.ResRet.f32 %993, 0
  %995 = fcmp fast ogt float %38, 5.000000e-01
  %996 = fcmp fast olt float %994, 1.000000e+00
  %997 = and i1 %995, %996
  br i1 %997, label %998, label %1136

; <label>:998                                     ; preds = %992
  %999 = sitofp i32 %65 to float
  %1000 = sitofp i32 %68 to float
  %1001 = fadd fast float %999, 5.000000e-01
  %1002 = fadd fast float %1000, 5.000000e-01
  %1003 = fdiv fast float %1001, %45
  %1004 = fdiv fast float %1002, %46
  %1005 = fmul fast float %1003, 2.000000e+00
  %1006 = fmul fast float %1004, 2.000000e+00
  %1007 = fadd fast float %1005, -1.000000e+00
  %1008 = fsub fast float 1.000000e+00, %1006
  %1009 = fmul fast float %1007, %35
  %1010 = call float @dx.op.tertiary.f32(i32 46, float %1008, float %31, float %1009)  ; FMad(a,b,c)
  %1011 = call float @dx.op.tertiary.f32(i32 46, float %994, float %27, float %1010)  ; FMad(a,b,c)
  %1012 = fadd fast float %1011, %23
  %1013 = call float @dx.op.unary.f32(i32 6, float %1012)  ; FAbs(value)
  %1014 = fcmp fast ogt float %1013, 0x3EB0C6F7A0000000
  br i1 %1014, label %1015, label %1136

; <label>:1015                                    ; preds = %998
  %1016 = fmul fast float %1007, %34
  %1017 = call float @dx.op.tertiary.f32(i32 46, float %1008, float %30, float %1016)  ; FMad(a,b,c)
  %1018 = call float @dx.op.tertiary.f32(i32 46, float %994, float %26, float %1017)  ; FMad(a,b,c)
  %1019 = fadd fast float %1018, %22
  %1020 = fmul fast float %1007, %33
  %1021 = call float @dx.op.tertiary.f32(i32 46, float %1008, float %29, float %1020)  ; FMad(a,b,c)
  %1022 = call float @dx.op.tertiary.f32(i32 46, float %994, float %25, float %1021)  ; FMad(a,b,c)
  %1023 = fadd fast float %1022, %21
  %1024 = fmul fast float %1007, %32
  %1025 = call float @dx.op.tertiary.f32(i32 46, float %1008, float %28, float %1024)  ; FMad(a,b,c)
  %1026 = call float @dx.op.tertiary.f32(i32 46, float %994, float %24, float %1025)  ; FMad(a,b,c)
  %1027 = fadd fast float %1026, %20
  %1028 = fdiv fast float %1027, %1012
  %1029 = fdiv fast float %1023, %1012
  %1030 = fdiv fast float %1019, %1012
  %1031 = fsub fast float %1028, %17
  %1032 = fsub fast float %1029, %18
  %1033 = fsub fast float %1030, %19
  %1034 = fmul fast float %1031, %1031
  %1035 = fmul fast float %1032, %1032
  %1036 = fadd fast float %1035, %1034
  %1037 = fmul fast float %1033, %1033
  %1038 = fadd fast float %1036, %1037
  %1039 = call float @dx.op.unary.f32(i32 24, float %1038)  ; Sqrt(value)
  %1040 = fsub fast float %1039, %9
  %1041 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1040)  ; FMax(a,b)
  %1042 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1042, label %1043, label %1066

; <label>:1043                                    ; preds = %1015
  %1044 = call float @dx.op.unary.f32(i32 6, float %1032)  ; FAbs(value)
  %1045 = fmul fast float %1044, %11
  %1046 = fcmp fast olt float %1045, 0x3F50624DE0000000
  br i1 %1046, label %1047, label %1050

; <label>:1047                                    ; preds = %1043
  %1048 = fmul fast float %1045, 5.000000e-01
  %1049 = fsub fast float 1.000000e+00, %1048
  br label %1055

; <label>:1050                                    ; preds = %1043
  %1051 = fmul fast float %1045, 0xBFF7154760000000
  %1052 = call float @dx.op.unary.f32(i32 21, float %1051)  ; Exp(value)
  %1053 = fsub fast float 1.000000e+00, %1052
  %1054 = fdiv fast float %1053, %1045
  br label %1055

; <label>:1055                                    ; preds = %1050, %1047
  %1056 = phi float [ %1049, %1047 ], [ %1054, %1050 ]
  %1057 = call float @dx.op.binary.f32(i32 36, float %1029, float %18)  ; FMin(a,b)
  %1058 = fsub fast float %1057, %10
  %1059 = fmul fast float %11, %1058
  %1060 = fsub fast float -0.000000e+00, %1059
  %1061 = call float @dx.op.binary.f32(i32 35, float %1060, float -4.000000e+01)  ; FMax(a,b)
  %1062 = call float @dx.op.binary.f32(i32 36, float %1061, float 5.000000e+00)  ; FMin(a,b)
  %1063 = fmul fast float %1062, 0x3FF7154760000000
  %1064 = call float @dx.op.unary.f32(i32 21, float %1063)  ; Exp(value)
  %1065 = fmul fast float %1064, %1056
  br label %1066

; <label>:1066                                    ; preds = %1055, %1015
  %1067 = phi float [ %1065, %1055 ], [ 1.000000e+00, %1015 ]
  %1068 = fmul fast float %1041, %16
  %1069 = fmul fast float %1068, %1067
  %1070 = fcmp fast ole float %1039, %9
  %1071 = fcmp fast olt float %1039, 0x3F1A36E2E0000000
  %1072 = or i1 %1070, %1071
  br i1 %1072, label %1119, label %1073

; <label>:1073                                    ; preds = %1066
  %1074 = fdiv fast float %9, %1039
  %1075 = fmul fast float %1074, %1031
  %1076 = fmul fast float %1074, %1032
  %1077 = fmul fast float %1074, %1033
  %1078 = fadd fast float %1075, %17
  %1079 = fadd fast float %1076, %18
  %1080 = fadd fast float %1077, %19
  %1081 = fadd fast float %1078, -9.000000e+02
  %1082 = fadd fast float %1079, -1.500000e+01
  %1083 = fadd fast float %1080, -7.500000e+02
  %1084 = fmul fast float %1081, 0x3F62345680000000
  %1085 = fmul fast float %1082, 0x3F62345680000000
  %1086 = fmul fast float %1083, 0x3F62345680000000
  %1087 = call float @dx.op.dot3.f32(i32 55, float %1084, float %1085, float %1086, float %1084, float %1085, float %1086)  ; Dot3(ax,ay,az,bx,by,bz)
  %1088 = fsub fast float 1.000000e+00, %1087
  %1089 = call float @dx.op.unary.f32(i32 7, float %1088)  ; Saturate(value)
  %1090 = fmul fast float %1089, %1089
  %1091 = fadd fast float %1078, %1028
  %1092 = fadd fast float %1079, %1029
  %1093 = fadd fast float %1080, %1030
  %1094 = fmul fast float %1091, 0x3F52345680000000
  %1095 = fadd fast float %1094, -2.000000e+00
  %1096 = fmul fast float %1092, 0x3F52345680000000
  %1097 = fadd fast float %1096, 0xBFA1111120000000
  %1098 = fmul fast float %1093, 0x3F52345680000000
  %1099 = fadd fast float %1098, 0xBFFAAAAAC0000000
  %1100 = call float @dx.op.dot3.f32(i32 55, float %1095, float %1097, float %1099, float %1095, float %1097, float %1099)  ; Dot3(ax,ay,az,bx,by,bz)
  %1101 = fsub fast float 1.000000e+00, %1100
  %1102 = call float @dx.op.unary.f32(i32 7, float %1101)  ; Saturate(value)
  %1103 = fmul fast float %1102, %1102
  %1104 = fmul fast float %1103, 4.000000e+00
  %1105 = fadd fast float %1104, %1090
  %1106 = fadd fast float %1028, -9.000000e+02
  %1107 = fadd fast float %1029, -1.500000e+01
  %1108 = fadd fast float %1030, -7.500000e+02
  %1109 = fmul fast float %1106, 0x3F62345680000000
  %1110 = fmul fast float %1107, 0x3F62345680000000
  %1111 = fmul fast float %1108, 0x3F62345680000000
  %1112 = call float @dx.op.dot3.f32(i32 55, float %1109, float %1110, float %1111, float %1109, float %1110, float %1111)  ; Dot3(ax,ay,az,bx,by,bz)
  %1113 = fsub fast float 1.000000e+00, %1112
  %1114 = call float @dx.op.unary.f32(i32 7, float %1113)  ; Saturate(value)
  %1115 = fmul fast float %1114, %1114
  %1116 = fadd fast float %1105, %1115
  %1117 = fmul fast float %1040, 0x3F25D867E0000000
  %1118 = fmul fast float %1117, %1116
  br label %1119

; <label>:1119                                    ; preds = %1073, %1066
  %1120 = phi float [ %1118, %1073 ], [ 0.000000e+00, %1066 ]
  %1121 = fadd fast float %1120, %1069
  %1122 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1121)  ; FMin(a,b)
  %1123 = fmul fast float %1122, 0xBFF7154760000000
  %1124 = call float @dx.op.unary.f32(i32 21, float %1123)  ; Exp(value)
  %1125 = fsub fast float 1.000000e+00, %1124
  %1126 = call float @dx.op.binary.f32(i32 36, float %12, float %1125)  ; FMin(a,b)
  %1127 = fsub fast float %13, %191
  %1128 = fsub fast float %14, %192
  %1129 = fsub fast float %15, %193
  %1130 = fmul fast float %1126, %1127
  %1131 = fmul fast float %1126, %1128
  %1132 = fmul fast float %1126, %1129
  %1133 = fadd fast float %1130, %191
  %1134 = fadd fast float %1131, %192
  %1135 = fadd fast float %1132, %193
  br label %1136

; <label>:1136                                    ; preds = %1119, %998, %992
  %1137 = phi float [ %1133, %1119 ], [ %191, %998 ], [ %191, %992 ]
  %1138 = phi float [ %1134, %1119 ], [ %192, %998 ], [ %192, %992 ]
  %1139 = phi float [ %1135, %1119 ], [ %193, %998 ], [ %193, %992 ]
  %1140 = fadd fast float %5, 1.000000e+00
  %1141 = fadd fast float %6, 1.000000e+00
  %1142 = fsub fast float 1.000000e+00, %5
  %1143 = fmul fast float %36, %1140
  %1144 = fmul fast float %36, %1141
  %1145 = fmul fast float %36, %1142
  %1146 = fmul fast float %1143, %1137
  %1147 = fmul fast float %1144, %1138
  %1148 = fmul fast float %1145, %1139
  %1149 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1149, label %1175, label %1150

; <label>:1150                                    ; preds = %1136
  %1151 = fmul fast float %1146, 0x4004147AE0000000
  %1152 = fmul fast float %1147, 0x4004147AE0000000
  %1153 = fmul fast float %1148, 0x4004147AE0000000
  %1154 = fadd fast float %1151, 0x3F9EB851E0000000
  %1155 = fadd fast float %1152, 0x3F9EB851E0000000
  %1156 = fadd fast float %1153, 0x3F9EB851E0000000
  %1157 = fmul fast float %1154, %1146
  %1158 = fmul fast float %1155, %1147
  %1159 = fmul fast float %1156, %1148
  %1160 = fmul fast float %1146, 0x400370A3E0000000
  %1161 = fmul fast float %1147, 0x400370A3E0000000
  %1162 = fmul fast float %1148, 0x400370A3E0000000
  %1163 = fadd fast float %1160, 0x3FE2E147A0000000
  %1164 = fadd fast float %1161, 0x3FE2E147A0000000
  %1165 = fadd fast float %1162, 0x3FE2E147A0000000
  %1166 = fmul fast float %1163, %1146
  %1167 = fmul fast float %1164, %1147
  %1168 = fmul fast float %1165, %1148
  %1169 = fadd fast float %1166, 0x3FC1EB8520000000
  %1170 = fadd fast float %1167, 0x3FC1EB8520000000
  %1171 = fadd fast float %1168, 0x3FC1EB8520000000
  %1172 = fdiv fast float %1157, %1169
  %1173 = fdiv fast float %1158, %1170
  %1174 = fdiv fast float %1159, %1171
  br label %1175

; <label>:1175                                    ; preds = %1150, %1136
  %1176 = phi float [ %1172, %1150 ], [ %1146, %1136 ]
  %1177 = phi float [ %1173, %1150 ], [ %1147, %1136 ]
  %1178 = phi float [ %1174, %1150 ], [ %1148, %1136 ]
  %1179 = call float @dx.op.unary.f32(i32 7, float %1176)  ; Saturate(value)
  %1180 = call float @dx.op.unary.f32(i32 7, float %1177)  ; Saturate(value)
  %1181 = call float @dx.op.unary.f32(i32 7, float %1178)  ; Saturate(value)
  %1182 = call float @dx.op.dot3.f32(i32 55, float %1179, float %1180, float %1181, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1183 = fsub fast float %1179, %1182
  %1184 = fsub fast float %1180, %1182
  %1185 = fsub fast float %1181, %1182
  %1186 = fmul fast float %1183, %8
  %1187 = fmul fast float %1184, %8
  %1188 = fmul fast float %1185, %8
  %1189 = fadd fast float %1186, %1182
  %1190 = fadd fast float %1187, %1182
  %1191 = fadd fast float %1188, %1182
  %1192 = call float @dx.op.unary.f32(i32 7, float %1189)  ; Saturate(value)
  %1193 = call float @dx.op.unary.f32(i32 7, float %1190)  ; Saturate(value)
  %1194 = call float @dx.op.unary.f32(i32 7, float %1191)  ; Saturate(value)
  %1195 = fadd fast float %1192, 0xBFC70A3D80000000
  %1196 = fadd fast float %1193, 0xBFC70A3D80000000
  %1197 = fadd fast float %1194, 0xBFC70A3D80000000
  %1198 = fmul fast float %1195, %7
  %1199 = fmul fast float %1196, %7
  %1200 = fmul fast float %1197, %7
  %1201 = fadd fast float %1198, 0x3FC70A3D80000000
  %1202 = fadd fast float %1199, 0x3FC70A3D80000000
  %1203 = fadd fast float %1200, 0x3FC70A3D80000000
  %1204 = call float @dx.op.unary.f32(i32 7, float %1201)  ; Saturate(value)
  %1205 = call float @dx.op.unary.f32(i32 7, float %1202)  ; Saturate(value)
  %1206 = call float @dx.op.unary.f32(i32 7, float %1203)  ; Saturate(value)
  br label %1207

; <label>:1207                                    ; preds = %1175, %958
  %1208 = phi float [ %989, %958 ], [ %1204, %1175 ]
  %1209 = phi float [ %990, %958 ], [ %1205, %1175 ]
  %1210 = phi float [ %991, %958 ], [ %1206, %1175 ]
  %1211 = fsub fast float -1.000000e+00, %179
  %1212 = select i1 %195, float %1211, float %179
  %1213 = fsub fast float -1.000000e+00, %184
  %1214 = select i1 %449, float %1213, float %184
  %1215 = fsub fast float -1.000000e+00, %189
  %1216 = select i1 %703, float %1215, float %189
  %1217 = fsub fast float -1.000000e+00, %194
  %1218 = select i1 %957, float %1217, float %194
  %1219 = fcmp fast ult float %179, 0.000000e+00
  br i1 %1219, label %1938, label %1220

; <label>:1220                                    ; preds = %1207
  %1221 = fsub fast float 1.000000e+00, %82
  %1222 = fmul fast float %1221, 0x3FA99999A0000000
  %1223 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %1222)  ; FMax(a,b)
  %1224 = fsub fast float %84, %82
  %1225 = call float @dx.op.unary.f32(i32 6, float %1224)  ; FAbs(value)
  %1226 = fdiv fast float %1225, %1223
  %1227 = fsub fast float 1.000000e+00, %1226
  %1228 = call float @dx.op.unary.f32(i32 7, float %1227)  ; Saturate(value)
  %1229 = fcmp fast ugt float %1228, 0.000000e+00
  br i1 %1229, label %1230, label %1240

; <label>:1230                                    ; preds = %1220
  %1231 = fsub fast float %700, %446
  %1232 = fsub fast float %701, %447
  %1233 = fsub fast float %702, %448
  %1234 = fmul fast float %1228, %1231
  %1235 = fmul fast float %1228, %1232
  %1236 = fmul fast float %1228, %1233
  %1237 = fadd fast float %1234, %446
  %1238 = fadd fast float %1235, %447
  %1239 = fadd fast float %1236, %448
  br label %1240

; <label>:1240                                    ; preds = %1230, %1220
  %1241 = phi float [ %1237, %1230 ], [ %446, %1220 ]
  %1242 = phi float [ %1238, %1230 ], [ %447, %1220 ]
  %1243 = phi float [ %1239, %1230 ], [ %448, %1220 ]
  %1244 = add i32 %55, -1
  %1245 = call i32 @dx.op.binary.i32(i32 37, i32 %1244, i32 0)  ; IMax(a,b)
  %1246 = call i32 @dx.op.binary.i32(i32 38, i32 %1245, i32 %59)  ; IMin(a,b)
  %1247 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1246, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1248 = extractvalue %dx.types.ResRet.f32 %1247, 0
  %1249 = fsub fast float %1248, %82
  %1250 = call float @dx.op.unary.f32(i32 6, float %1249)  ; FAbs(value)
  %1251 = fdiv fast float %1250, %1223
  %1252 = fsub fast float 1.000000e+00, %1251
  %1253 = call float @dx.op.unary.f32(i32 7, float %1252)  ; Saturate(value)
  %1254 = fcmp fast ugt float %1253, 0.000000e+00
  br i1 %1254, label %1255, label %1528

; <label>:1255                                    ; preds = %1240
  %1256 = call i32 @dx.op.binary.i32(i32 37, i32 %1246, i32 0)  ; IMax(a,b)
  %1257 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %1258 = call i32 @dx.op.binary.i32(i32 38, i32 %1256, i32 %59)  ; IMin(a,b)
  %1259 = call i32 @dx.op.binary.i32(i32 38, i32 %1257, i32 %60)  ; IMin(a,b)
  %1260 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1258, i32 %1259, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1261 = extractvalue %dx.types.ResRet.f32 %1260, 0
  %1262 = extractvalue %dx.types.ResRet.f32 %1260, 1
  %1263 = extractvalue %dx.types.ResRet.f32 %1260, 2
  %1264 = extractvalue %dx.types.ResRet.f32 %1260, 3
  %1265 = fcmp fast olt float %1264, 0.000000e+00
  br i1 %1265, label %1266, label %1300

; <label>:1266                                    ; preds = %1255
  %1267 = fcmp fast ogt float %1261, 0x3FA4B5DCC0000000
  %1268 = fcmp fast ogt float %1262, 0x3FA4B5DCC0000000
  %1269 = fcmp fast ogt float %1263, 0x3FA4B5DCC0000000
  %1270 = select i1 %1267, float 0.000000e+00, float 1.000000e+00
  %1271 = select i1 %1268, float 0.000000e+00, float 1.000000e+00
  %1272 = select i1 %1269, float 0.000000e+00, float 1.000000e+00
  %1273 = fmul fast float %1261, 0x3FB3D07220000000
  %1274 = fmul fast float %1262, 0x3FB3D07220000000
  %1275 = fmul fast float %1263, 0x3FB3D07220000000
  %1276 = fadd fast float %1261, 0x3FAC28F5C0000000
  %1277 = fadd fast float %1262, 0x3FAC28F5C0000000
  %1278 = fadd fast float %1263, 0x3FAC28F5C0000000
  %1279 = fmul fast float %1276, 0x3FEE54EDE0000000
  %1280 = fmul fast float %1277, 0x3FEE54EDE0000000
  %1281 = fmul fast float %1278, 0x3FEE54EDE0000000
  %1282 = call float @dx.op.unary.f32(i32 23, float %1279)  ; Log(value)
  %1283 = call float @dx.op.unary.f32(i32 23, float %1280)  ; Log(value)
  %1284 = call float @dx.op.unary.f32(i32 23, float %1281)  ; Log(value)
  %1285 = fmul fast float %1282, 0x4003333340000000
  %1286 = fmul fast float %1283, 0x4003333340000000
  %1287 = fmul fast float %1284, 0x4003333340000000
  %1288 = call float @dx.op.unary.f32(i32 21, float %1285)  ; Exp(value)
  %1289 = call float @dx.op.unary.f32(i32 21, float %1286)  ; Exp(value)
  %1290 = call float @dx.op.unary.f32(i32 21, float %1287)  ; Exp(value)
  %1291 = fsub fast float %1273, %1288
  %1292 = fsub fast float %1274, %1289
  %1293 = fsub fast float %1275, %1290
  %1294 = fmul fast float %1291, %1270
  %1295 = fmul fast float %1292, %1271
  %1296 = fmul fast float %1293, %1272
  %1297 = fadd fast float %1294, %1288
  %1298 = fadd fast float %1295, %1289
  %1299 = fadd fast float %1296, %1290
  br label %1515

; <label>:1300                                    ; preds = %1255
  %1301 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1258, i32 %1259, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1302 = extractvalue %dx.types.ResRet.f32 %1301, 0
  %1303 = fcmp fast ogt float %38, 5.000000e-01
  %1304 = fcmp fast olt float %1302, 1.000000e+00
  %1305 = and i1 %1303, %1304
  br i1 %1305, label %1306, label %1444

; <label>:1306                                    ; preds = %1300
  %1307 = sitofp i32 %1258 to float
  %1308 = sitofp i32 %1259 to float
  %1309 = fadd fast float %1307, 5.000000e-01
  %1310 = fadd fast float %1308, 5.000000e-01
  %1311 = fdiv fast float %1309, %45
  %1312 = fdiv fast float %1310, %46
  %1313 = fmul fast float %1311, 2.000000e+00
  %1314 = fmul fast float %1312, 2.000000e+00
  %1315 = fadd fast float %1313, -1.000000e+00
  %1316 = fsub fast float 1.000000e+00, %1314
  %1317 = fmul fast float %1315, %35
  %1318 = call float @dx.op.tertiary.f32(i32 46, float %1316, float %31, float %1317)  ; FMad(a,b,c)
  %1319 = call float @dx.op.tertiary.f32(i32 46, float %1302, float %27, float %1318)  ; FMad(a,b,c)
  %1320 = fadd fast float %1319, %23
  %1321 = call float @dx.op.unary.f32(i32 6, float %1320)  ; FAbs(value)
  %1322 = fcmp fast ogt float %1321, 0x3EB0C6F7A0000000
  br i1 %1322, label %1323, label %1444

; <label>:1323                                    ; preds = %1306
  %1324 = fmul fast float %1315, %34
  %1325 = call float @dx.op.tertiary.f32(i32 46, float %1316, float %30, float %1324)  ; FMad(a,b,c)
  %1326 = call float @dx.op.tertiary.f32(i32 46, float %1302, float %26, float %1325)  ; FMad(a,b,c)
  %1327 = fadd fast float %1326, %22
  %1328 = fmul fast float %1315, %33
  %1329 = call float @dx.op.tertiary.f32(i32 46, float %1316, float %29, float %1328)  ; FMad(a,b,c)
  %1330 = call float @dx.op.tertiary.f32(i32 46, float %1302, float %25, float %1329)  ; FMad(a,b,c)
  %1331 = fadd fast float %1330, %21
  %1332 = fmul fast float %1315, %32
  %1333 = call float @dx.op.tertiary.f32(i32 46, float %1316, float %28, float %1332)  ; FMad(a,b,c)
  %1334 = call float @dx.op.tertiary.f32(i32 46, float %1302, float %24, float %1333)  ; FMad(a,b,c)
  %1335 = fadd fast float %1334, %20
  %1336 = fdiv fast float %1335, %1320
  %1337 = fdiv fast float %1331, %1320
  %1338 = fdiv fast float %1327, %1320
  %1339 = fsub fast float %1336, %17
  %1340 = fsub fast float %1337, %18
  %1341 = fsub fast float %1338, %19
  %1342 = fmul fast float %1339, %1339
  %1343 = fmul fast float %1340, %1340
  %1344 = fadd fast float %1343, %1342
  %1345 = fmul fast float %1341, %1341
  %1346 = fadd fast float %1344, %1345
  %1347 = call float @dx.op.unary.f32(i32 24, float %1346)  ; Sqrt(value)
  %1348 = fsub fast float %1347, %9
  %1349 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1348)  ; FMax(a,b)
  %1350 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1350, label %1351, label %1374

; <label>:1351                                    ; preds = %1323
  %1352 = call float @dx.op.unary.f32(i32 6, float %1340)  ; FAbs(value)
  %1353 = fmul fast float %1352, %11
  %1354 = fcmp fast olt float %1353, 0x3F50624DE0000000
  br i1 %1354, label %1355, label %1358

; <label>:1355                                    ; preds = %1351
  %1356 = fmul fast float %1353, 5.000000e-01
  %1357 = fsub fast float 1.000000e+00, %1356
  br label %1363

; <label>:1358                                    ; preds = %1351
  %1359 = fmul fast float %1353, 0xBFF7154760000000
  %1360 = call float @dx.op.unary.f32(i32 21, float %1359)  ; Exp(value)
  %1361 = fsub fast float 1.000000e+00, %1360
  %1362 = fdiv fast float %1361, %1353
  br label %1363

; <label>:1363                                    ; preds = %1358, %1355
  %1364 = phi float [ %1357, %1355 ], [ %1362, %1358 ]
  %1365 = call float @dx.op.binary.f32(i32 36, float %1337, float %18)  ; FMin(a,b)
  %1366 = fsub fast float %1365, %10
  %1367 = fmul fast float %11, %1366
  %1368 = fsub fast float -0.000000e+00, %1367
  %1369 = call float @dx.op.binary.f32(i32 35, float %1368, float -4.000000e+01)  ; FMax(a,b)
  %1370 = call float @dx.op.binary.f32(i32 36, float %1369, float 5.000000e+00)  ; FMin(a,b)
  %1371 = fmul fast float %1370, 0x3FF7154760000000
  %1372 = call float @dx.op.unary.f32(i32 21, float %1371)  ; Exp(value)
  %1373 = fmul fast float %1372, %1364
  br label %1374

; <label>:1374                                    ; preds = %1363, %1323
  %1375 = phi float [ %1373, %1363 ], [ 1.000000e+00, %1323 ]
  %1376 = fmul fast float %1349, %16
  %1377 = fmul fast float %1376, %1375
  %1378 = fcmp fast ole float %1347, %9
  %1379 = fcmp fast olt float %1347, 0x3F1A36E2E0000000
  %1380 = or i1 %1378, %1379
  br i1 %1380, label %1427, label %1381

; <label>:1381                                    ; preds = %1374
  %1382 = fdiv fast float %9, %1347
  %1383 = fmul fast float %1382, %1339
  %1384 = fmul fast float %1382, %1340
  %1385 = fmul fast float %1382, %1341
  %1386 = fadd fast float %1383, %17
  %1387 = fadd fast float %1384, %18
  %1388 = fadd fast float %1385, %19
  %1389 = fadd fast float %1386, -9.000000e+02
  %1390 = fadd fast float %1387, -1.500000e+01
  %1391 = fadd fast float %1388, -7.500000e+02
  %1392 = fmul fast float %1389, 0x3F62345680000000
  %1393 = fmul fast float %1390, 0x3F62345680000000
  %1394 = fmul fast float %1391, 0x3F62345680000000
  %1395 = call float @dx.op.dot3.f32(i32 55, float %1392, float %1393, float %1394, float %1392, float %1393, float %1394)  ; Dot3(ax,ay,az,bx,by,bz)
  %1396 = fsub fast float 1.000000e+00, %1395
  %1397 = call float @dx.op.unary.f32(i32 7, float %1396)  ; Saturate(value)
  %1398 = fmul fast float %1397, %1397
  %1399 = fadd fast float %1386, %1336
  %1400 = fadd fast float %1387, %1337
  %1401 = fadd fast float %1388, %1338
  %1402 = fmul fast float %1399, 0x3F52345680000000
  %1403 = fadd fast float %1402, -2.000000e+00
  %1404 = fmul fast float %1400, 0x3F52345680000000
  %1405 = fadd fast float %1404, 0xBFA1111120000000
  %1406 = fmul fast float %1401, 0x3F52345680000000
  %1407 = fadd fast float %1406, 0xBFFAAAAAC0000000
  %1408 = call float @dx.op.dot3.f32(i32 55, float %1403, float %1405, float %1407, float %1403, float %1405, float %1407)  ; Dot3(ax,ay,az,bx,by,bz)
  %1409 = fsub fast float 1.000000e+00, %1408
  %1410 = call float @dx.op.unary.f32(i32 7, float %1409)  ; Saturate(value)
  %1411 = fmul fast float %1410, %1410
  %1412 = fmul fast float %1411, 4.000000e+00
  %1413 = fadd fast float %1412, %1398
  %1414 = fadd fast float %1336, -9.000000e+02
  %1415 = fadd fast float %1337, -1.500000e+01
  %1416 = fadd fast float %1338, -7.500000e+02
  %1417 = fmul fast float %1414, 0x3F62345680000000
  %1418 = fmul fast float %1415, 0x3F62345680000000
  %1419 = fmul fast float %1416, 0x3F62345680000000
  %1420 = call float @dx.op.dot3.f32(i32 55, float %1417, float %1418, float %1419, float %1417, float %1418, float %1419)  ; Dot3(ax,ay,az,bx,by,bz)
  %1421 = fsub fast float 1.000000e+00, %1420
  %1422 = call float @dx.op.unary.f32(i32 7, float %1421)  ; Saturate(value)
  %1423 = fmul fast float %1422, %1422
  %1424 = fadd fast float %1413, %1423
  %1425 = fmul fast float %1348, 0x3F25D867E0000000
  %1426 = fmul fast float %1425, %1424
  br label %1427

; <label>:1427                                    ; preds = %1381, %1374
  %1428 = phi float [ %1426, %1381 ], [ 0.000000e+00, %1374 ]
  %1429 = fadd fast float %1428, %1377
  %1430 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1429)  ; FMin(a,b)
  %1431 = fmul fast float %1430, 0xBFF7154760000000
  %1432 = call float @dx.op.unary.f32(i32 21, float %1431)  ; Exp(value)
  %1433 = fsub fast float 1.000000e+00, %1432
  %1434 = call float @dx.op.binary.f32(i32 36, float %12, float %1433)  ; FMin(a,b)
  %1435 = fsub fast float %13, %1261
  %1436 = fsub fast float %14, %1262
  %1437 = fsub fast float %15, %1263
  %1438 = fmul fast float %1434, %1435
  %1439 = fmul fast float %1434, %1436
  %1440 = fmul fast float %1434, %1437
  %1441 = fadd fast float %1438, %1261
  %1442 = fadd fast float %1439, %1262
  %1443 = fadd fast float %1440, %1263
  br label %1444

; <label>:1444                                    ; preds = %1427, %1306, %1300
  %1445 = phi float [ %1441, %1427 ], [ %1261, %1306 ], [ %1261, %1300 ]
  %1446 = phi float [ %1442, %1427 ], [ %1262, %1306 ], [ %1262, %1300 ]
  %1447 = phi float [ %1443, %1427 ], [ %1263, %1306 ], [ %1263, %1300 ]
  %1448 = fadd fast float %5, 1.000000e+00
  %1449 = fadd fast float %6, 1.000000e+00
  %1450 = fsub fast float 1.000000e+00, %5
  %1451 = fmul fast float %36, %1448
  %1452 = fmul fast float %36, %1449
  %1453 = fmul fast float %36, %1450
  %1454 = fmul fast float %1451, %1445
  %1455 = fmul fast float %1452, %1446
  %1456 = fmul fast float %1453, %1447
  %1457 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1457, label %1483, label %1458

; <label>:1458                                    ; preds = %1444
  %1459 = fmul fast float %1454, 0x4004147AE0000000
  %1460 = fmul fast float %1455, 0x4004147AE0000000
  %1461 = fmul fast float %1456, 0x4004147AE0000000
  %1462 = fadd fast float %1459, 0x3F9EB851E0000000
  %1463 = fadd fast float %1460, 0x3F9EB851E0000000
  %1464 = fadd fast float %1461, 0x3F9EB851E0000000
  %1465 = fmul fast float %1462, %1454
  %1466 = fmul fast float %1463, %1455
  %1467 = fmul fast float %1464, %1456
  %1468 = fmul fast float %1454, 0x400370A3E0000000
  %1469 = fmul fast float %1455, 0x400370A3E0000000
  %1470 = fmul fast float %1456, 0x400370A3E0000000
  %1471 = fadd fast float %1468, 0x3FE2E147A0000000
  %1472 = fadd fast float %1469, 0x3FE2E147A0000000
  %1473 = fadd fast float %1470, 0x3FE2E147A0000000
  %1474 = fmul fast float %1471, %1454
  %1475 = fmul fast float %1472, %1455
  %1476 = fmul fast float %1473, %1456
  %1477 = fadd fast float %1474, 0x3FC1EB8520000000
  %1478 = fadd fast float %1475, 0x3FC1EB8520000000
  %1479 = fadd fast float %1476, 0x3FC1EB8520000000
  %1480 = fdiv fast float %1465, %1477
  %1481 = fdiv fast float %1466, %1478
  %1482 = fdiv fast float %1467, %1479
  br label %1483

; <label>:1483                                    ; preds = %1458, %1444
  %1484 = phi float [ %1480, %1458 ], [ %1454, %1444 ]
  %1485 = phi float [ %1481, %1458 ], [ %1455, %1444 ]
  %1486 = phi float [ %1482, %1458 ], [ %1456, %1444 ]
  %1487 = call float @dx.op.unary.f32(i32 7, float %1484)  ; Saturate(value)
  %1488 = call float @dx.op.unary.f32(i32 7, float %1485)  ; Saturate(value)
  %1489 = call float @dx.op.unary.f32(i32 7, float %1486)  ; Saturate(value)
  %1490 = call float @dx.op.dot3.f32(i32 55, float %1487, float %1488, float %1489, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1491 = fsub fast float %1487, %1490
  %1492 = fsub fast float %1488, %1490
  %1493 = fsub fast float %1489, %1490
  %1494 = fmul fast float %1491, %8
  %1495 = fmul fast float %1492, %8
  %1496 = fmul fast float %1493, %8
  %1497 = fadd fast float %1494, %1490
  %1498 = fadd fast float %1495, %1490
  %1499 = fadd fast float %1496, %1490
  %1500 = call float @dx.op.unary.f32(i32 7, float %1497)  ; Saturate(value)
  %1501 = call float @dx.op.unary.f32(i32 7, float %1498)  ; Saturate(value)
  %1502 = call float @dx.op.unary.f32(i32 7, float %1499)  ; Saturate(value)
  %1503 = fadd fast float %1500, 0xBFC70A3D80000000
  %1504 = fadd fast float %1501, 0xBFC70A3D80000000
  %1505 = fadd fast float %1502, 0xBFC70A3D80000000
  %1506 = fmul fast float %1503, %7
  %1507 = fmul fast float %1504, %7
  %1508 = fmul fast float %1505, %7
  %1509 = fadd fast float %1506, 0x3FC70A3D80000000
  %1510 = fadd fast float %1507, 0x3FC70A3D80000000
  %1511 = fadd fast float %1508, 0x3FC70A3D80000000
  %1512 = call float @dx.op.unary.f32(i32 7, float %1509)  ; Saturate(value)
  %1513 = call float @dx.op.unary.f32(i32 7, float %1510)  ; Saturate(value)
  %1514 = call float @dx.op.unary.f32(i32 7, float %1511)  ; Saturate(value)
  br label %1515

; <label>:1515                                    ; preds = %1483, %1266
  %1516 = phi float [ %1297, %1266 ], [ %1512, %1483 ]
  %1517 = phi float [ %1298, %1266 ], [ %1513, %1483 ]
  %1518 = phi float [ %1299, %1266 ], [ %1514, %1483 ]
  %1519 = fsub fast float %1516, %446
  %1520 = fsub fast float %1517, %447
  %1521 = fsub fast float %1518, %448
  %1522 = fmul fast float %1519, %1253
  %1523 = fmul fast float %1520, %1253
  %1524 = fmul fast float %1521, %1253
  %1525 = fadd fast float %1522, %446
  %1526 = fadd fast float %1523, %447
  %1527 = fadd fast float %1524, %448
  br label %1528

; <label>:1528                                    ; preds = %1515, %1240
  %1529 = phi float [ %1525, %1515 ], [ %446, %1240 ]
  %1530 = phi float [ %1526, %1515 ], [ %447, %1240 ]
  %1531 = phi float [ %1527, %1515 ], [ %448, %1240 ]
  %1532 = fsub fast float %86, %82
  %1533 = call float @dx.op.unary.f32(i32 6, float %1532)  ; FAbs(value)
  %1534 = fdiv fast float %1533, %1223
  %1535 = fsub fast float 1.000000e+00, %1534
  %1536 = call float @dx.op.unary.f32(i32 7, float %1535)  ; Saturate(value)
  %1537 = fcmp fast ugt float %1536, 0.000000e+00
  br i1 %1537, label %1538, label %1548

; <label>:1538                                    ; preds = %1528
  %1539 = fsub fast float %954, %446
  %1540 = fsub fast float %955, %447
  %1541 = fsub fast float %956, %448
  %1542 = fmul fast float %1536, %1539
  %1543 = fmul fast float %1536, %1540
  %1544 = fmul fast float %1536, %1541
  %1545 = fadd fast float %1542, %446
  %1546 = fadd fast float %1543, %447
  %1547 = fadd fast float %1544, %448
  br label %1548

; <label>:1548                                    ; preds = %1538, %1528
  %1549 = phi float [ %1545, %1538 ], [ %446, %1528 ]
  %1550 = phi float [ %1546, %1538 ], [ %447, %1528 ]
  %1551 = phi float [ %1547, %1538 ], [ %448, %1528 ]
  %1552 = add i32 %56, -1
  %1553 = call i32 @dx.op.binary.i32(i32 37, i32 %1552, i32 0)  ; IMax(a,b)
  %1554 = call i32 @dx.op.binary.i32(i32 38, i32 %1553, i32 %60)  ; IMin(a,b)
  %1555 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %1554, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1556 = extractvalue %dx.types.ResRet.f32 %1555, 0
  %1557 = fsub fast float %1556, %82
  %1558 = call float @dx.op.unary.f32(i32 6, float %1557)  ; FAbs(value)
  %1559 = fdiv fast float %1558, %1223
  %1560 = fsub fast float 1.000000e+00, %1559
  %1561 = call float @dx.op.unary.f32(i32 7, float %1560)  ; Saturate(value)
  %1562 = fcmp fast ugt float %1561, 0.000000e+00
  br i1 %1562, label %1563, label %1836

; <label>:1563                                    ; preds = %1548
  %1564 = call i32 @dx.op.binary.i32(i32 37, i32 %63, i32 0)  ; IMax(a,b)
  %1565 = call i32 @dx.op.binary.i32(i32 37, i32 %1554, i32 0)  ; IMax(a,b)
  %1566 = call i32 @dx.op.binary.i32(i32 38, i32 %1564, i32 %59)  ; IMin(a,b)
  %1567 = call i32 @dx.op.binary.i32(i32 38, i32 %1565, i32 %60)  ; IMin(a,b)
  %1568 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1566, i32 %1567, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1569 = extractvalue %dx.types.ResRet.f32 %1568, 0
  %1570 = extractvalue %dx.types.ResRet.f32 %1568, 1
  %1571 = extractvalue %dx.types.ResRet.f32 %1568, 2
  %1572 = extractvalue %dx.types.ResRet.f32 %1568, 3
  %1573 = fcmp fast olt float %1572, 0.000000e+00
  br i1 %1573, label %1574, label %1608

; <label>:1574                                    ; preds = %1563
  %1575 = fcmp fast ogt float %1569, 0x3FA4B5DCC0000000
  %1576 = fcmp fast ogt float %1570, 0x3FA4B5DCC0000000
  %1577 = fcmp fast ogt float %1571, 0x3FA4B5DCC0000000
  %1578 = select i1 %1575, float 0.000000e+00, float 1.000000e+00
  %1579 = select i1 %1576, float 0.000000e+00, float 1.000000e+00
  %1580 = select i1 %1577, float 0.000000e+00, float 1.000000e+00
  %1581 = fmul fast float %1569, 0x3FB3D07220000000
  %1582 = fmul fast float %1570, 0x3FB3D07220000000
  %1583 = fmul fast float %1571, 0x3FB3D07220000000
  %1584 = fadd fast float %1569, 0x3FAC28F5C0000000
  %1585 = fadd fast float %1570, 0x3FAC28F5C0000000
  %1586 = fadd fast float %1571, 0x3FAC28F5C0000000
  %1587 = fmul fast float %1584, 0x3FEE54EDE0000000
  %1588 = fmul fast float %1585, 0x3FEE54EDE0000000
  %1589 = fmul fast float %1586, 0x3FEE54EDE0000000
  %1590 = call float @dx.op.unary.f32(i32 23, float %1587)  ; Log(value)
  %1591 = call float @dx.op.unary.f32(i32 23, float %1588)  ; Log(value)
  %1592 = call float @dx.op.unary.f32(i32 23, float %1589)  ; Log(value)
  %1593 = fmul fast float %1590, 0x4003333340000000
  %1594 = fmul fast float %1591, 0x4003333340000000
  %1595 = fmul fast float %1592, 0x4003333340000000
  %1596 = call float @dx.op.unary.f32(i32 21, float %1593)  ; Exp(value)
  %1597 = call float @dx.op.unary.f32(i32 21, float %1594)  ; Exp(value)
  %1598 = call float @dx.op.unary.f32(i32 21, float %1595)  ; Exp(value)
  %1599 = fsub fast float %1581, %1596
  %1600 = fsub fast float %1582, %1597
  %1601 = fsub fast float %1583, %1598
  %1602 = fmul fast float %1599, %1578
  %1603 = fmul fast float %1600, %1579
  %1604 = fmul fast float %1601, %1580
  %1605 = fadd fast float %1602, %1596
  %1606 = fadd fast float %1603, %1597
  %1607 = fadd fast float %1604, %1598
  br label %1823

; <label>:1608                                    ; preds = %1563
  %1609 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1566, i32 %1567, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1610 = extractvalue %dx.types.ResRet.f32 %1609, 0
  %1611 = fcmp fast ogt float %38, 5.000000e-01
  %1612 = fcmp fast olt float %1610, 1.000000e+00
  %1613 = and i1 %1611, %1612
  br i1 %1613, label %1614, label %1752

; <label>:1614                                    ; preds = %1608
  %1615 = sitofp i32 %1566 to float
  %1616 = sitofp i32 %1567 to float
  %1617 = fadd fast float %1615, 5.000000e-01
  %1618 = fadd fast float %1616, 5.000000e-01
  %1619 = fdiv fast float %1617, %45
  %1620 = fdiv fast float %1618, %46
  %1621 = fmul fast float %1619, 2.000000e+00
  %1622 = fmul fast float %1620, 2.000000e+00
  %1623 = fadd fast float %1621, -1.000000e+00
  %1624 = fsub fast float 1.000000e+00, %1622
  %1625 = fmul fast float %1623, %35
  %1626 = call float @dx.op.tertiary.f32(i32 46, float %1624, float %31, float %1625)  ; FMad(a,b,c)
  %1627 = call float @dx.op.tertiary.f32(i32 46, float %1610, float %27, float %1626)  ; FMad(a,b,c)
  %1628 = fadd fast float %1627, %23
  %1629 = call float @dx.op.unary.f32(i32 6, float %1628)  ; FAbs(value)
  %1630 = fcmp fast ogt float %1629, 0x3EB0C6F7A0000000
  br i1 %1630, label %1631, label %1752

; <label>:1631                                    ; preds = %1614
  %1632 = fmul fast float %1623, %34
  %1633 = call float @dx.op.tertiary.f32(i32 46, float %1624, float %30, float %1632)  ; FMad(a,b,c)
  %1634 = call float @dx.op.tertiary.f32(i32 46, float %1610, float %26, float %1633)  ; FMad(a,b,c)
  %1635 = fadd fast float %1634, %22
  %1636 = fmul fast float %1623, %33
  %1637 = call float @dx.op.tertiary.f32(i32 46, float %1624, float %29, float %1636)  ; FMad(a,b,c)
  %1638 = call float @dx.op.tertiary.f32(i32 46, float %1610, float %25, float %1637)  ; FMad(a,b,c)
  %1639 = fadd fast float %1638, %21
  %1640 = fmul fast float %1623, %32
  %1641 = call float @dx.op.tertiary.f32(i32 46, float %1624, float %28, float %1640)  ; FMad(a,b,c)
  %1642 = call float @dx.op.tertiary.f32(i32 46, float %1610, float %24, float %1641)  ; FMad(a,b,c)
  %1643 = fadd fast float %1642, %20
  %1644 = fdiv fast float %1643, %1628
  %1645 = fdiv fast float %1639, %1628
  %1646 = fdiv fast float %1635, %1628
  %1647 = fsub fast float %1644, %17
  %1648 = fsub fast float %1645, %18
  %1649 = fsub fast float %1646, %19
  %1650 = fmul fast float %1647, %1647
  %1651 = fmul fast float %1648, %1648
  %1652 = fadd fast float %1651, %1650
  %1653 = fmul fast float %1649, %1649
  %1654 = fadd fast float %1652, %1653
  %1655 = call float @dx.op.unary.f32(i32 24, float %1654)  ; Sqrt(value)
  %1656 = fsub fast float %1655, %9
  %1657 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1656)  ; FMax(a,b)
  %1658 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1658, label %1659, label %1682

; <label>:1659                                    ; preds = %1631
  %1660 = call float @dx.op.unary.f32(i32 6, float %1648)  ; FAbs(value)
  %1661 = fmul fast float %1660, %11
  %1662 = fcmp fast olt float %1661, 0x3F50624DE0000000
  br i1 %1662, label %1663, label %1666

; <label>:1663                                    ; preds = %1659
  %1664 = fmul fast float %1661, 5.000000e-01
  %1665 = fsub fast float 1.000000e+00, %1664
  br label %1671

; <label>:1666                                    ; preds = %1659
  %1667 = fmul fast float %1661, 0xBFF7154760000000
  %1668 = call float @dx.op.unary.f32(i32 21, float %1667)  ; Exp(value)
  %1669 = fsub fast float 1.000000e+00, %1668
  %1670 = fdiv fast float %1669, %1661
  br label %1671

; <label>:1671                                    ; preds = %1666, %1663
  %1672 = phi float [ %1665, %1663 ], [ %1670, %1666 ]
  %1673 = call float @dx.op.binary.f32(i32 36, float %1645, float %18)  ; FMin(a,b)
  %1674 = fsub fast float %1673, %10
  %1675 = fmul fast float %11, %1674
  %1676 = fsub fast float -0.000000e+00, %1675
  %1677 = call float @dx.op.binary.f32(i32 35, float %1676, float -4.000000e+01)  ; FMax(a,b)
  %1678 = call float @dx.op.binary.f32(i32 36, float %1677, float 5.000000e+00)  ; FMin(a,b)
  %1679 = fmul fast float %1678, 0x3FF7154760000000
  %1680 = call float @dx.op.unary.f32(i32 21, float %1679)  ; Exp(value)
  %1681 = fmul fast float %1680, %1672
  br label %1682

; <label>:1682                                    ; preds = %1671, %1631
  %1683 = phi float [ %1681, %1671 ], [ 1.000000e+00, %1631 ]
  %1684 = fmul fast float %1657, %16
  %1685 = fmul fast float %1684, %1683
  %1686 = fcmp fast ole float %1655, %9
  %1687 = fcmp fast olt float %1655, 0x3F1A36E2E0000000
  %1688 = or i1 %1686, %1687
  br i1 %1688, label %1735, label %1689

; <label>:1689                                    ; preds = %1682
  %1690 = fdiv fast float %9, %1655
  %1691 = fmul fast float %1690, %1647
  %1692 = fmul fast float %1690, %1648
  %1693 = fmul fast float %1690, %1649
  %1694 = fadd fast float %1691, %17
  %1695 = fadd fast float %1692, %18
  %1696 = fadd fast float %1693, %19
  %1697 = fadd fast float %1694, -9.000000e+02
  %1698 = fadd fast float %1695, -1.500000e+01
  %1699 = fadd fast float %1696, -7.500000e+02
  %1700 = fmul fast float %1697, 0x3F62345680000000
  %1701 = fmul fast float %1698, 0x3F62345680000000
  %1702 = fmul fast float %1699, 0x3F62345680000000
  %1703 = call float @dx.op.dot3.f32(i32 55, float %1700, float %1701, float %1702, float %1700, float %1701, float %1702)  ; Dot3(ax,ay,az,bx,by,bz)
  %1704 = fsub fast float 1.000000e+00, %1703
  %1705 = call float @dx.op.unary.f32(i32 7, float %1704)  ; Saturate(value)
  %1706 = fmul fast float %1705, %1705
  %1707 = fadd fast float %1694, %1644
  %1708 = fadd fast float %1695, %1645
  %1709 = fadd fast float %1696, %1646
  %1710 = fmul fast float %1707, 0x3F52345680000000
  %1711 = fadd fast float %1710, -2.000000e+00
  %1712 = fmul fast float %1708, 0x3F52345680000000
  %1713 = fadd fast float %1712, 0xBFA1111120000000
  %1714 = fmul fast float %1709, 0x3F52345680000000
  %1715 = fadd fast float %1714, 0xBFFAAAAAC0000000
  %1716 = call float @dx.op.dot3.f32(i32 55, float %1711, float %1713, float %1715, float %1711, float %1713, float %1715)  ; Dot3(ax,ay,az,bx,by,bz)
  %1717 = fsub fast float 1.000000e+00, %1716
  %1718 = call float @dx.op.unary.f32(i32 7, float %1717)  ; Saturate(value)
  %1719 = fmul fast float %1718, %1718
  %1720 = fmul fast float %1719, 4.000000e+00
  %1721 = fadd fast float %1720, %1706
  %1722 = fadd fast float %1644, -9.000000e+02
  %1723 = fadd fast float %1645, -1.500000e+01
  %1724 = fadd fast float %1646, -7.500000e+02
  %1725 = fmul fast float %1722, 0x3F62345680000000
  %1726 = fmul fast float %1723, 0x3F62345680000000
  %1727 = fmul fast float %1724, 0x3F62345680000000
  %1728 = call float @dx.op.dot3.f32(i32 55, float %1725, float %1726, float %1727, float %1725, float %1726, float %1727)  ; Dot3(ax,ay,az,bx,by,bz)
  %1729 = fsub fast float 1.000000e+00, %1728
  %1730 = call float @dx.op.unary.f32(i32 7, float %1729)  ; Saturate(value)
  %1731 = fmul fast float %1730, %1730
  %1732 = fadd fast float %1721, %1731
  %1733 = fmul fast float %1656, 0x3F25D867E0000000
  %1734 = fmul fast float %1733, %1732
  br label %1735

; <label>:1735                                    ; preds = %1689, %1682
  %1736 = phi float [ %1734, %1689 ], [ 0.000000e+00, %1682 ]
  %1737 = fadd fast float %1736, %1685
  %1738 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1737)  ; FMin(a,b)
  %1739 = fmul fast float %1738, 0xBFF7154760000000
  %1740 = call float @dx.op.unary.f32(i32 21, float %1739)  ; Exp(value)
  %1741 = fsub fast float 1.000000e+00, %1740
  %1742 = call float @dx.op.binary.f32(i32 36, float %12, float %1741)  ; FMin(a,b)
  %1743 = fsub fast float %13, %1569
  %1744 = fsub fast float %14, %1570
  %1745 = fsub fast float %15, %1571
  %1746 = fmul fast float %1742, %1743
  %1747 = fmul fast float %1742, %1744
  %1748 = fmul fast float %1742, %1745
  %1749 = fadd fast float %1746, %1569
  %1750 = fadd fast float %1747, %1570
  %1751 = fadd fast float %1748, %1571
  br label %1752

; <label>:1752                                    ; preds = %1735, %1614, %1608
  %1753 = phi float [ %1749, %1735 ], [ %1569, %1614 ], [ %1569, %1608 ]
  %1754 = phi float [ %1750, %1735 ], [ %1570, %1614 ], [ %1570, %1608 ]
  %1755 = phi float [ %1751, %1735 ], [ %1571, %1614 ], [ %1571, %1608 ]
  %1756 = fadd fast float %5, 1.000000e+00
  %1757 = fadd fast float %6, 1.000000e+00
  %1758 = fsub fast float 1.000000e+00, %5
  %1759 = fmul fast float %36, %1756
  %1760 = fmul fast float %36, %1757
  %1761 = fmul fast float %36, %1758
  %1762 = fmul fast float %1759, %1753
  %1763 = fmul fast float %1760, %1754
  %1764 = fmul fast float %1761, %1755
  %1765 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1765, label %1791, label %1766

; <label>:1766                                    ; preds = %1752
  %1767 = fmul fast float %1762, 0x4004147AE0000000
  %1768 = fmul fast float %1763, 0x4004147AE0000000
  %1769 = fmul fast float %1764, 0x4004147AE0000000
  %1770 = fadd fast float %1767, 0x3F9EB851E0000000
  %1771 = fadd fast float %1768, 0x3F9EB851E0000000
  %1772 = fadd fast float %1769, 0x3F9EB851E0000000
  %1773 = fmul fast float %1770, %1762
  %1774 = fmul fast float %1771, %1763
  %1775 = fmul fast float %1772, %1764
  %1776 = fmul fast float %1762, 0x400370A3E0000000
  %1777 = fmul fast float %1763, 0x400370A3E0000000
  %1778 = fmul fast float %1764, 0x400370A3E0000000
  %1779 = fadd fast float %1776, 0x3FE2E147A0000000
  %1780 = fadd fast float %1777, 0x3FE2E147A0000000
  %1781 = fadd fast float %1778, 0x3FE2E147A0000000
  %1782 = fmul fast float %1779, %1762
  %1783 = fmul fast float %1780, %1763
  %1784 = fmul fast float %1781, %1764
  %1785 = fadd fast float %1782, 0x3FC1EB8520000000
  %1786 = fadd fast float %1783, 0x3FC1EB8520000000
  %1787 = fadd fast float %1784, 0x3FC1EB8520000000
  %1788 = fdiv fast float %1773, %1785
  %1789 = fdiv fast float %1774, %1786
  %1790 = fdiv fast float %1775, %1787
  br label %1791

; <label>:1791                                    ; preds = %1766, %1752
  %1792 = phi float [ %1788, %1766 ], [ %1762, %1752 ]
  %1793 = phi float [ %1789, %1766 ], [ %1763, %1752 ]
  %1794 = phi float [ %1790, %1766 ], [ %1764, %1752 ]
  %1795 = call float @dx.op.unary.f32(i32 7, float %1792)  ; Saturate(value)
  %1796 = call float @dx.op.unary.f32(i32 7, float %1793)  ; Saturate(value)
  %1797 = call float @dx.op.unary.f32(i32 7, float %1794)  ; Saturate(value)
  %1798 = call float @dx.op.dot3.f32(i32 55, float %1795, float %1796, float %1797, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1799 = fsub fast float %1795, %1798
  %1800 = fsub fast float %1796, %1798
  %1801 = fsub fast float %1797, %1798
  %1802 = fmul fast float %1799, %8
  %1803 = fmul fast float %1800, %8
  %1804 = fmul fast float %1801, %8
  %1805 = fadd fast float %1802, %1798
  %1806 = fadd fast float %1803, %1798
  %1807 = fadd fast float %1804, %1798
  %1808 = call float @dx.op.unary.f32(i32 7, float %1805)  ; Saturate(value)
  %1809 = call float @dx.op.unary.f32(i32 7, float %1806)  ; Saturate(value)
  %1810 = call float @dx.op.unary.f32(i32 7, float %1807)  ; Saturate(value)
  %1811 = fadd fast float %1808, 0xBFC70A3D80000000
  %1812 = fadd fast float %1809, 0xBFC70A3D80000000
  %1813 = fadd fast float %1810, 0xBFC70A3D80000000
  %1814 = fmul fast float %1811, %7
  %1815 = fmul fast float %1812, %7
  %1816 = fmul fast float %1813, %7
  %1817 = fadd fast float %1814, 0x3FC70A3D80000000
  %1818 = fadd fast float %1815, 0x3FC70A3D80000000
  %1819 = fadd fast float %1816, 0x3FC70A3D80000000
  %1820 = call float @dx.op.unary.f32(i32 7, float %1817)  ; Saturate(value)
  %1821 = call float @dx.op.unary.f32(i32 7, float %1818)  ; Saturate(value)
  %1822 = call float @dx.op.unary.f32(i32 7, float %1819)  ; Saturate(value)
  br label %1823

; <label>:1823                                    ; preds = %1791, %1574
  %1824 = phi float [ %1605, %1574 ], [ %1820, %1791 ]
  %1825 = phi float [ %1606, %1574 ], [ %1821, %1791 ]
  %1826 = phi float [ %1607, %1574 ], [ %1822, %1791 ]
  %1827 = fsub fast float %1824, %446
  %1828 = fsub fast float %1825, %447
  %1829 = fsub fast float %1826, %448
  %1830 = fmul fast float %1827, %1561
  %1831 = fmul fast float %1828, %1561
  %1832 = fmul fast float %1829, %1561
  %1833 = fadd fast float %1830, %446
  %1834 = fadd fast float %1831, %447
  %1835 = fadd fast float %1832, %448
  br label %1836

; <label>:1836                                    ; preds = %1823, %1548
  %1837 = phi float [ %1833, %1823 ], [ %446, %1548 ]
  %1838 = phi float [ %1834, %1823 ], [ %447, %1548 ]
  %1839 = phi float [ %1835, %1823 ], [ %448, %1548 ]
  %1840 = call float @dx.op.binary.f32(i32 36, float %1529, float %1241)  ; FMin(a,b)
  %1841 = call float @dx.op.binary.f32(i32 36, float %1530, float %1242)  ; FMin(a,b)
  %1842 = call float @dx.op.binary.f32(i32 36, float %1531, float %1243)  ; FMin(a,b)
  %1843 = call float @dx.op.binary.f32(i32 36, float %1837, float %1549)  ; FMin(a,b)
  %1844 = call float @dx.op.binary.f32(i32 36, float %1838, float %1550)  ; FMin(a,b)
  %1845 = call float @dx.op.binary.f32(i32 36, float %1839, float %1551)  ; FMin(a,b)
  %1846 = call float @dx.op.binary.f32(i32 36, float %1843, float %1840)  ; FMin(a,b)
  %1847 = call float @dx.op.binary.f32(i32 36, float %1844, float %1841)  ; FMin(a,b)
  %1848 = call float @dx.op.binary.f32(i32 36, float %1845, float %1842)  ; FMin(a,b)
  %1849 = call float @dx.op.binary.f32(i32 36, float %446, float %1846)  ; FMin(a,b)
  %1850 = call float @dx.op.binary.f32(i32 36, float %447, float %1847)  ; FMin(a,b)
  %1851 = call float @dx.op.binary.f32(i32 36, float %448, float %1848)  ; FMin(a,b)
  %1852 = call float @dx.op.binary.f32(i32 35, float %1529, float %1241)  ; FMax(a,b)
  %1853 = call float @dx.op.binary.f32(i32 35, float %1530, float %1242)  ; FMax(a,b)
  %1854 = call float @dx.op.binary.f32(i32 35, float %1531, float %1243)  ; FMax(a,b)
  %1855 = call float @dx.op.binary.f32(i32 35, float %1837, float %1549)  ; FMax(a,b)
  %1856 = call float @dx.op.binary.f32(i32 35, float %1838, float %1550)  ; FMax(a,b)
  %1857 = call float @dx.op.binary.f32(i32 35, float %1839, float %1551)  ; FMax(a,b)
  %1858 = call float @dx.op.binary.f32(i32 35, float %1855, float %1852)  ; FMax(a,b)
  %1859 = call float @dx.op.binary.f32(i32 35, float %1856, float %1853)  ; FMax(a,b)
  %1860 = call float @dx.op.binary.f32(i32 35, float %1857, float %1854)  ; FMax(a,b)
  %1861 = call float @dx.op.binary.f32(i32 35, float %446, float %1858)  ; FMax(a,b)
  %1862 = call float @dx.op.binary.f32(i32 35, float %447, float %1859)  ; FMax(a,b)
  %1863 = call float @dx.op.binary.f32(i32 35, float %448, float %1860)  ; FMax(a,b)
  %1864 = fsub fast float %1861, %1849
  %1865 = fsub fast float %1862, %1850
  %1866 = fsub fast float %1863, %1851
  %1867 = call float @dx.op.unary.f32(i32 6, float %1864)  ; FAbs(value)
  %1868 = call float @dx.op.unary.f32(i32 6, float %1865)  ; FAbs(value)
  %1869 = call float @dx.op.unary.f32(i32 6, float %1866)  ; FAbs(value)
  %1870 = call float @dx.op.binary.f32(i32 35, float %1868, float %1869)  ; FMax(a,b)
  %1871 = call float @dx.op.binary.f32(i32 35, float %1867, float %1870)  ; FMax(a,b)
  %1872 = call float @dx.op.binary.f32(i32 35, float %1862, float %1863)  ; FMax(a,b)
  %1873 = call float @dx.op.binary.f32(i32 35, float %1861, float %1872)  ; FMax(a,b)
  %1874 = fmul fast float %1873, 1.250000e-01
  %1875 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1874)  ; FMax(a,b)
  %1876 = fcmp fast ogt float %1871, %1875
  br i1 %1876, label %1877, label %1938

; <label>:1877                                    ; preds = %1836
  %1878 = fsub fast float %1837, %1549
  %1879 = fsub fast float %1838, %1550
  %1880 = fsub fast float %1839, %1551
  %1881 = call float @dx.op.unary.f32(i32 6, float %1878)  ; FAbs(value)
  %1882 = call float @dx.op.unary.f32(i32 6, float %1879)  ; FAbs(value)
  %1883 = call float @dx.op.unary.f32(i32 6, float %1880)  ; FAbs(value)
  %1884 = call float @dx.op.binary.f32(i32 35, float %1882, float %1883)  ; FMax(a,b)
  %1885 = call float @dx.op.binary.f32(i32 35, float %1881, float %1884)  ; FMax(a,b)
  %1886 = fsub fast float %1529, %1241
  %1887 = fsub fast float %1530, %1242
  %1888 = fsub fast float %1531, %1243
  %1889 = call float @dx.op.unary.f32(i32 6, float %1886)  ; FAbs(value)
  %1890 = call float @dx.op.unary.f32(i32 6, float %1887)  ; FAbs(value)
  %1891 = call float @dx.op.unary.f32(i32 6, float %1888)  ; FAbs(value)
  %1892 = call float @dx.op.binary.f32(i32 35, float %1890, float %1891)  ; FMax(a,b)
  %1893 = call float @dx.op.binary.f32(i32 35, float %1889, float %1892)  ; FMax(a,b)
  %1894 = fcmp fast olt float %1885, %1893
  %1895 = select i1 %1894, float %1837, float %1529
  %1896 = select i1 %1894, float %1838, float %1530
  %1897 = select i1 %1894, float %1839, float %1531
  %1898 = select i1 %1894, float %1549, float %1241
  %1899 = select i1 %1894, float %1550, float %1242
  %1900 = select i1 %1894, float %1551, float %1243
  %1901 = fsub fast float %446, %1898
  %1902 = fsub fast float %447, %1899
  %1903 = fsub fast float %448, %1900
  %1904 = fsub fast float %446, %1895
  %1905 = fsub fast float %447, %1896
  %1906 = fsub fast float %448, %1897
  %1907 = call float @dx.op.dot3.f32(i32 55, float %1904, float %1905, float %1906, float %1901, float %1902, float %1903)  ; Dot3(ax,ay,az,bx,by,bz)
  %1908 = fcmp fast ogt float %1907, 0.000000e+00
  br i1 %1908, label %1909, label %1920

; <label>:1909                                    ; preds = %1877
  %1910 = fsub fast float %1895, %1898
  %1911 = fsub fast float %1896, %1899
  %1912 = fsub fast float %1897, %1900
  %1913 = call float @dx.op.unary.f32(i32 6, float %1910)  ; FAbs(value)
  %1914 = call float @dx.op.unary.f32(i32 6, float %1911)  ; FAbs(value)
  %1915 = call float @dx.op.unary.f32(i32 6, float %1912)  ; FAbs(value)
  %1916 = call float @dx.op.binary.f32(i32 35, float %1914, float %1915)  ; FMax(a,b)
  %1917 = call float @dx.op.binary.f32(i32 35, float %1913, float %1916)  ; FMax(a,b)
  %1918 = fmul fast float %1871, 2.500000e-01
  %1919 = fcmp fast olt float %1917, %1918
  br label %1920

; <label>:1920                                    ; preds = %1909, %1877
  %1921 = phi i1 [ false, %1877 ], [ %1919, %1909 ]
  %1922 = select i1 %1921, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  %1923 = fadd fast float %1895, %1898
  %1924 = fadd fast float %1896, %1899
  %1925 = fadd fast float %1897, %1900
  %1926 = fmul fast float %1923, 5.000000e-01
  %1927 = fmul fast float %1924, 5.000000e-01
  %1928 = fmul fast float %1925, 5.000000e-01
  %1929 = fsub fast float %1926, %446
  %1930 = fsub fast float %1927, %447
  %1931 = fsub fast float %1928, %448
  %1932 = fmul fast float %1922, %1929
  %1933 = fmul fast float %1922, %1930
  %1934 = fmul fast float %1922, %1931
  %1935 = fadd fast float %1932, %446
  %1936 = fadd fast float %1933, %447
  %1937 = fadd fast float %1934, %448
  br label %1938

; <label>:1938                                    ; preds = %1920, %1836, %1207
  %1939 = phi float [ %446, %1207 ], [ %1935, %1920 ], [ %446, %1836 ]
  %1940 = phi float [ %447, %1207 ], [ %1936, %1920 ], [ %447, %1836 ]
  %1941 = phi float [ %448, %1207 ], [ %1937, %1920 ], [ %448, %1836 ]
  %1942 = fcmp fast ult float %184, 0.000000e+00
  br i1 %1942, label %2661, label %1943

; <label>:1943                                    ; preds = %1938
  %1944 = add i32 %55, 2
  %1945 = call i32 @dx.op.binary.i32(i32 37, i32 %1944, i32 0)  ; IMax(a,b)
  %1946 = call i32 @dx.op.binary.i32(i32 38, i32 %1945, i32 %59)  ; IMin(a,b)
  %1947 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1946, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1948 = extractvalue %dx.types.ResRet.f32 %1947, 0
  %1949 = fsub fast float 1.000000e+00, %84
  %1950 = fmul fast float %1949, 0x3FA99999A0000000
  %1951 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %1950)  ; FMax(a,b)
  %1952 = fsub fast float %1948, %84
  %1953 = call float @dx.op.unary.f32(i32 6, float %1952)  ; FAbs(value)
  %1954 = fdiv fast float %1953, %1951
  %1955 = fsub fast float 1.000000e+00, %1954
  %1956 = call float @dx.op.unary.f32(i32 7, float %1955)  ; Saturate(value)
  %1957 = fcmp fast ugt float %1956, 0.000000e+00
  br i1 %1957, label %1958, label %2231

; <label>:1958                                    ; preds = %1943
  %1959 = call i32 @dx.op.binary.i32(i32 37, i32 %1946, i32 0)  ; IMax(a,b)
  %1960 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %1961 = call i32 @dx.op.binary.i32(i32 38, i32 %1959, i32 %59)  ; IMin(a,b)
  %1962 = call i32 @dx.op.binary.i32(i32 38, i32 %1960, i32 %60)  ; IMin(a,b)
  %1963 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1961, i32 %1962, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1964 = extractvalue %dx.types.ResRet.f32 %1963, 0
  %1965 = extractvalue %dx.types.ResRet.f32 %1963, 1
  %1966 = extractvalue %dx.types.ResRet.f32 %1963, 2
  %1967 = extractvalue %dx.types.ResRet.f32 %1963, 3
  %1968 = fcmp fast olt float %1967, 0.000000e+00
  br i1 %1968, label %1969, label %2003

; <label>:1969                                    ; preds = %1958
  %1970 = fcmp fast ogt float %1964, 0x3FA4B5DCC0000000
  %1971 = fcmp fast ogt float %1965, 0x3FA4B5DCC0000000
  %1972 = fcmp fast ogt float %1966, 0x3FA4B5DCC0000000
  %1973 = select i1 %1970, float 0.000000e+00, float 1.000000e+00
  %1974 = select i1 %1971, float 0.000000e+00, float 1.000000e+00
  %1975 = select i1 %1972, float 0.000000e+00, float 1.000000e+00
  %1976 = fmul fast float %1964, 0x3FB3D07220000000
  %1977 = fmul fast float %1965, 0x3FB3D07220000000
  %1978 = fmul fast float %1966, 0x3FB3D07220000000
  %1979 = fadd fast float %1964, 0x3FAC28F5C0000000
  %1980 = fadd fast float %1965, 0x3FAC28F5C0000000
  %1981 = fadd fast float %1966, 0x3FAC28F5C0000000
  %1982 = fmul fast float %1979, 0x3FEE54EDE0000000
  %1983 = fmul fast float %1980, 0x3FEE54EDE0000000
  %1984 = fmul fast float %1981, 0x3FEE54EDE0000000
  %1985 = call float @dx.op.unary.f32(i32 23, float %1982)  ; Log(value)
  %1986 = call float @dx.op.unary.f32(i32 23, float %1983)  ; Log(value)
  %1987 = call float @dx.op.unary.f32(i32 23, float %1984)  ; Log(value)
  %1988 = fmul fast float %1985, 0x4003333340000000
  %1989 = fmul fast float %1986, 0x4003333340000000
  %1990 = fmul fast float %1987, 0x4003333340000000
  %1991 = call float @dx.op.unary.f32(i32 21, float %1988)  ; Exp(value)
  %1992 = call float @dx.op.unary.f32(i32 21, float %1989)  ; Exp(value)
  %1993 = call float @dx.op.unary.f32(i32 21, float %1990)  ; Exp(value)
  %1994 = fsub fast float %1976, %1991
  %1995 = fsub fast float %1977, %1992
  %1996 = fsub fast float %1978, %1993
  %1997 = fmul fast float %1994, %1973
  %1998 = fmul fast float %1995, %1974
  %1999 = fmul fast float %1996, %1975
  %2000 = fadd fast float %1997, %1991
  %2001 = fadd fast float %1998, %1992
  %2002 = fadd fast float %1999, %1993
  br label %2218

; <label>:2003                                    ; preds = %1958
  %2004 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1961, i32 %1962, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2005 = extractvalue %dx.types.ResRet.f32 %2004, 0
  %2006 = fcmp fast ogt float %38, 5.000000e-01
  %2007 = fcmp fast olt float %2005, 1.000000e+00
  %2008 = and i1 %2006, %2007
  br i1 %2008, label %2009, label %2147

; <label>:2009                                    ; preds = %2003
  %2010 = sitofp i32 %1961 to float
  %2011 = sitofp i32 %1962 to float
  %2012 = fadd fast float %2010, 5.000000e-01
  %2013 = fadd fast float %2011, 5.000000e-01
  %2014 = fdiv fast float %2012, %45
  %2015 = fdiv fast float %2013, %46
  %2016 = fmul fast float %2014, 2.000000e+00
  %2017 = fmul fast float %2015, 2.000000e+00
  %2018 = fadd fast float %2016, -1.000000e+00
  %2019 = fsub fast float 1.000000e+00, %2017
  %2020 = fmul fast float %2018, %35
  %2021 = call float @dx.op.tertiary.f32(i32 46, float %2019, float %31, float %2020)  ; FMad(a,b,c)
  %2022 = call float @dx.op.tertiary.f32(i32 46, float %2005, float %27, float %2021)  ; FMad(a,b,c)
  %2023 = fadd fast float %2022, %23
  %2024 = call float @dx.op.unary.f32(i32 6, float %2023)  ; FAbs(value)
  %2025 = fcmp fast ogt float %2024, 0x3EB0C6F7A0000000
  br i1 %2025, label %2026, label %2147

; <label>:2026                                    ; preds = %2009
  %2027 = fmul fast float %2018, %34
  %2028 = call float @dx.op.tertiary.f32(i32 46, float %2019, float %30, float %2027)  ; FMad(a,b,c)
  %2029 = call float @dx.op.tertiary.f32(i32 46, float %2005, float %26, float %2028)  ; FMad(a,b,c)
  %2030 = fadd fast float %2029, %22
  %2031 = fmul fast float %2018, %33
  %2032 = call float @dx.op.tertiary.f32(i32 46, float %2019, float %29, float %2031)  ; FMad(a,b,c)
  %2033 = call float @dx.op.tertiary.f32(i32 46, float %2005, float %25, float %2032)  ; FMad(a,b,c)
  %2034 = fadd fast float %2033, %21
  %2035 = fmul fast float %2018, %32
  %2036 = call float @dx.op.tertiary.f32(i32 46, float %2019, float %28, float %2035)  ; FMad(a,b,c)
  %2037 = call float @dx.op.tertiary.f32(i32 46, float %2005, float %24, float %2036)  ; FMad(a,b,c)
  %2038 = fadd fast float %2037, %20
  %2039 = fdiv fast float %2038, %2023
  %2040 = fdiv fast float %2034, %2023
  %2041 = fdiv fast float %2030, %2023
  %2042 = fsub fast float %2039, %17
  %2043 = fsub fast float %2040, %18
  %2044 = fsub fast float %2041, %19
  %2045 = fmul fast float %2042, %2042
  %2046 = fmul fast float %2043, %2043
  %2047 = fadd fast float %2046, %2045
  %2048 = fmul fast float %2044, %2044
  %2049 = fadd fast float %2047, %2048
  %2050 = call float @dx.op.unary.f32(i32 24, float %2049)  ; Sqrt(value)
  %2051 = fsub fast float %2050, %9
  %2052 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2051)  ; FMax(a,b)
  %2053 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %2053, label %2054, label %2077

; <label>:2054                                    ; preds = %2026
  %2055 = call float @dx.op.unary.f32(i32 6, float %2043)  ; FAbs(value)
  %2056 = fmul fast float %2055, %11
  %2057 = fcmp fast olt float %2056, 0x3F50624DE0000000
  br i1 %2057, label %2058, label %2061

; <label>:2058                                    ; preds = %2054
  %2059 = fmul fast float %2056, 5.000000e-01
  %2060 = fsub fast float 1.000000e+00, %2059
  br label %2066

; <label>:2061                                    ; preds = %2054
  %2062 = fmul fast float %2056, 0xBFF7154760000000
  %2063 = call float @dx.op.unary.f32(i32 21, float %2062)  ; Exp(value)
  %2064 = fsub fast float 1.000000e+00, %2063
  %2065 = fdiv fast float %2064, %2056
  br label %2066

; <label>:2066                                    ; preds = %2061, %2058
  %2067 = phi float [ %2060, %2058 ], [ %2065, %2061 ]
  %2068 = call float @dx.op.binary.f32(i32 36, float %2040, float %18)  ; FMin(a,b)
  %2069 = fsub fast float %2068, %10
  %2070 = fmul fast float %11, %2069
  %2071 = fsub fast float -0.000000e+00, %2070
  %2072 = call float @dx.op.binary.f32(i32 35, float %2071, float -4.000000e+01)  ; FMax(a,b)
  %2073 = call float @dx.op.binary.f32(i32 36, float %2072, float 5.000000e+00)  ; FMin(a,b)
  %2074 = fmul fast float %2073, 0x3FF7154760000000
  %2075 = call float @dx.op.unary.f32(i32 21, float %2074)  ; Exp(value)
  %2076 = fmul fast float %2075, %2067
  br label %2077

; <label>:2077                                    ; preds = %2066, %2026
  %2078 = phi float [ %2076, %2066 ], [ 1.000000e+00, %2026 ]
  %2079 = fmul fast float %2052, %16
  %2080 = fmul fast float %2079, %2078
  %2081 = fcmp fast ole float %2050, %9
  %2082 = fcmp fast olt float %2050, 0x3F1A36E2E0000000
  %2083 = or i1 %2081, %2082
  br i1 %2083, label %2130, label %2084

; <label>:2084                                    ; preds = %2077
  %2085 = fdiv fast float %9, %2050
  %2086 = fmul fast float %2085, %2042
  %2087 = fmul fast float %2085, %2043
  %2088 = fmul fast float %2085, %2044
  %2089 = fadd fast float %2086, %17
  %2090 = fadd fast float %2087, %18
  %2091 = fadd fast float %2088, %19
  %2092 = fadd fast float %2089, -9.000000e+02
  %2093 = fadd fast float %2090, -1.500000e+01
  %2094 = fadd fast float %2091, -7.500000e+02
  %2095 = fmul fast float %2092, 0x3F62345680000000
  %2096 = fmul fast float %2093, 0x3F62345680000000
  %2097 = fmul fast float %2094, 0x3F62345680000000
  %2098 = call float @dx.op.dot3.f32(i32 55, float %2095, float %2096, float %2097, float %2095, float %2096, float %2097)  ; Dot3(ax,ay,az,bx,by,bz)
  %2099 = fsub fast float 1.000000e+00, %2098
  %2100 = call float @dx.op.unary.f32(i32 7, float %2099)  ; Saturate(value)
  %2101 = fmul fast float %2100, %2100
  %2102 = fadd fast float %2089, %2039
  %2103 = fadd fast float %2090, %2040
  %2104 = fadd fast float %2091, %2041
  %2105 = fmul fast float %2102, 0x3F52345680000000
  %2106 = fadd fast float %2105, -2.000000e+00
  %2107 = fmul fast float %2103, 0x3F52345680000000
  %2108 = fadd fast float %2107, 0xBFA1111120000000
  %2109 = fmul fast float %2104, 0x3F52345680000000
  %2110 = fadd fast float %2109, 0xBFFAAAAAC0000000
  %2111 = call float @dx.op.dot3.f32(i32 55, float %2106, float %2108, float %2110, float %2106, float %2108, float %2110)  ; Dot3(ax,ay,az,bx,by,bz)
  %2112 = fsub fast float 1.000000e+00, %2111
  %2113 = call float @dx.op.unary.f32(i32 7, float %2112)  ; Saturate(value)
  %2114 = fmul fast float %2113, %2113
  %2115 = fmul fast float %2114, 4.000000e+00
  %2116 = fadd fast float %2115, %2101
  %2117 = fadd fast float %2039, -9.000000e+02
  %2118 = fadd fast float %2040, -1.500000e+01
  %2119 = fadd fast float %2041, -7.500000e+02
  %2120 = fmul fast float %2117, 0x3F62345680000000
  %2121 = fmul fast float %2118, 0x3F62345680000000
  %2122 = fmul fast float %2119, 0x3F62345680000000
  %2123 = call float @dx.op.dot3.f32(i32 55, float %2120, float %2121, float %2122, float %2120, float %2121, float %2122)  ; Dot3(ax,ay,az,bx,by,bz)
  %2124 = fsub fast float 1.000000e+00, %2123
  %2125 = call float @dx.op.unary.f32(i32 7, float %2124)  ; Saturate(value)
  %2126 = fmul fast float %2125, %2125
  %2127 = fadd fast float %2116, %2126
  %2128 = fmul fast float %2051, 0x3F25D867E0000000
  %2129 = fmul fast float %2128, %2127
  br label %2130

; <label>:2130                                    ; preds = %2084, %2077
  %2131 = phi float [ %2129, %2084 ], [ 0.000000e+00, %2077 ]
  %2132 = fadd fast float %2131, %2080
  %2133 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2132)  ; FMin(a,b)
  %2134 = fmul fast float %2133, 0xBFF7154760000000
  %2135 = call float @dx.op.unary.f32(i32 21, float %2134)  ; Exp(value)
  %2136 = fsub fast float 1.000000e+00, %2135
  %2137 = call float @dx.op.binary.f32(i32 36, float %12, float %2136)  ; FMin(a,b)
  %2138 = fsub fast float %13, %1964
  %2139 = fsub fast float %14, %1965
  %2140 = fsub fast float %15, %1966
  %2141 = fmul fast float %2137, %2138
  %2142 = fmul fast float %2137, %2139
  %2143 = fmul fast float %2137, %2140
  %2144 = fadd fast float %2141, %1964
  %2145 = fadd fast float %2142, %1965
  %2146 = fadd fast float %2143, %1966
  br label %2147

; <label>:2147                                    ; preds = %2130, %2009, %2003
  %2148 = phi float [ %2144, %2130 ], [ %1964, %2009 ], [ %1964, %2003 ]
  %2149 = phi float [ %2145, %2130 ], [ %1965, %2009 ], [ %1965, %2003 ]
  %2150 = phi float [ %2146, %2130 ], [ %1966, %2009 ], [ %1966, %2003 ]
  %2151 = fadd fast float %5, 1.000000e+00
  %2152 = fadd fast float %6, 1.000000e+00
  %2153 = fsub fast float 1.000000e+00, %5
  %2154 = fmul fast float %36, %2151
  %2155 = fmul fast float %36, %2152
  %2156 = fmul fast float %36, %2153
  %2157 = fmul fast float %2154, %2148
  %2158 = fmul fast float %2155, %2149
  %2159 = fmul fast float %2156, %2150
  %2160 = fcmp fast ult float %37, 5.000000e-01
  br i1 %2160, label %2186, label %2161

; <label>:2161                                    ; preds = %2147
  %2162 = fmul fast float %2157, 0x4004147AE0000000
  %2163 = fmul fast float %2158, 0x4004147AE0000000
  %2164 = fmul fast float %2159, 0x4004147AE0000000
  %2165 = fadd fast float %2162, 0x3F9EB851E0000000
  %2166 = fadd fast float %2163, 0x3F9EB851E0000000
  %2167 = fadd fast float %2164, 0x3F9EB851E0000000
  %2168 = fmul fast float %2165, %2157
  %2169 = fmul fast float %2166, %2158
  %2170 = fmul fast float %2167, %2159
  %2171 = fmul fast float %2157, 0x400370A3E0000000
  %2172 = fmul fast float %2158, 0x400370A3E0000000
  %2173 = fmul fast float %2159, 0x400370A3E0000000
  %2174 = fadd fast float %2171, 0x3FE2E147A0000000
  %2175 = fadd fast float %2172, 0x3FE2E147A0000000
  %2176 = fadd fast float %2173, 0x3FE2E147A0000000
  %2177 = fmul fast float %2174, %2157
  %2178 = fmul fast float %2175, %2158
  %2179 = fmul fast float %2176, %2159
  %2180 = fadd fast float %2177, 0x3FC1EB8520000000
  %2181 = fadd fast float %2178, 0x3FC1EB8520000000
  %2182 = fadd fast float %2179, 0x3FC1EB8520000000
  %2183 = fdiv fast float %2168, %2180
  %2184 = fdiv fast float %2169, %2181
  %2185 = fdiv fast float %2170, %2182
  br label %2186

; <label>:2186                                    ; preds = %2161, %2147
  %2187 = phi float [ %2183, %2161 ], [ %2157, %2147 ]
  %2188 = phi float [ %2184, %2161 ], [ %2158, %2147 ]
  %2189 = phi float [ %2185, %2161 ], [ %2159, %2147 ]
  %2190 = call float @dx.op.unary.f32(i32 7, float %2187)  ; Saturate(value)
  %2191 = call float @dx.op.unary.f32(i32 7, float %2188)  ; Saturate(value)
  %2192 = call float @dx.op.unary.f32(i32 7, float %2189)  ; Saturate(value)
  %2193 = call float @dx.op.dot3.f32(i32 55, float %2190, float %2191, float %2192, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2194 = fsub fast float %2190, %2193
  %2195 = fsub fast float %2191, %2193
  %2196 = fsub fast float %2192, %2193
  %2197 = fmul fast float %2194, %8
  %2198 = fmul fast float %2195, %8
  %2199 = fmul fast float %2196, %8
  %2200 = fadd fast float %2197, %2193
  %2201 = fadd fast float %2198, %2193
  %2202 = fadd fast float %2199, %2193
  %2203 = call float @dx.op.unary.f32(i32 7, float %2200)  ; Saturate(value)
  %2204 = call float @dx.op.unary.f32(i32 7, float %2201)  ; Saturate(value)
  %2205 = call float @dx.op.unary.f32(i32 7, float %2202)  ; Saturate(value)
  %2206 = fadd fast float %2203, 0xBFC70A3D80000000
  %2207 = fadd fast float %2204, 0xBFC70A3D80000000
  %2208 = fadd fast float %2205, 0xBFC70A3D80000000
  %2209 = fmul fast float %2206, %7
  %2210 = fmul fast float %2207, %7
  %2211 = fmul fast float %2208, %7
  %2212 = fadd fast float %2209, 0x3FC70A3D80000000
  %2213 = fadd fast float %2210, 0x3FC70A3D80000000
  %2214 = fadd fast float %2211, 0x3FC70A3D80000000
  %2215 = call float @dx.op.unary.f32(i32 7, float %2212)  ; Saturate(value)
  %2216 = call float @dx.op.unary.f32(i32 7, float %2213)  ; Saturate(value)
  %2217 = call float @dx.op.unary.f32(i32 7, float %2214)  ; Saturate(value)
  br label %2218

; <label>:2218                                    ; preds = %2186, %1969
  %2219 = phi float [ %2000, %1969 ], [ %2215, %2186 ]
  %2220 = phi float [ %2001, %1969 ], [ %2216, %2186 ]
  %2221 = phi float [ %2002, %1969 ], [ %2217, %2186 ]
  %2222 = fsub fast float %2219, %700
  %2223 = fsub fast float %2220, %701
  %2224 = fsub fast float %2221, %702
  %2225 = fmul fast float %2222, %1956
  %2226 = fmul fast float %2223, %1956
  %2227 = fmul fast float %2224, %1956
  %2228 = fadd fast float %2225, %700
  %2229 = fadd fast float %2226, %701
  %2230 = fadd fast float %2227, %702
  br label %2231

; <label>:2231                                    ; preds = %2218, %1943
  %2232 = phi float [ %2228, %2218 ], [ %700, %1943 ]
  %2233 = phi float [ %2229, %2218 ], [ %701, %1943 ]
  %2234 = phi float [ %2230, %2218 ], [ %702, %1943 ]
  %2235 = fsub fast float %82, %84
  %2236 = call float @dx.op.unary.f32(i32 6, float %2235)  ; FAbs(value)
  %2237 = fdiv fast float %2236, %1951
  %2238 = fsub fast float 1.000000e+00, %2237
  %2239 = call float @dx.op.unary.f32(i32 7, float %2238)  ; Saturate(value)
  %2240 = fcmp fast ugt float %2239, 0.000000e+00
  br i1 %2240, label %2241, label %2251

; <label>:2241                                    ; preds = %2231
  %2242 = fsub fast float %446, %700
  %2243 = fsub fast float %447, %701
  %2244 = fsub fast float %448, %702
  %2245 = fmul fast float %2239, %2242
  %2246 = fmul fast float %2239, %2243
  %2247 = fmul fast float %2239, %2244
  %2248 = fadd fast float %2245, %700
  %2249 = fadd fast float %2246, %701
  %2250 = fadd fast float %2247, %702
  br label %2251

; <label>:2251                                    ; preds = %2241, %2231
  %2252 = phi float [ %2248, %2241 ], [ %700, %2231 ]
  %2253 = phi float [ %2249, %2241 ], [ %701, %2231 ]
  %2254 = phi float [ %2250, %2241 ], [ %702, %2231 ]
  %2255 = fsub fast float %88, %84
  %2256 = call float @dx.op.unary.f32(i32 6, float %2255)  ; FAbs(value)
  %2257 = fdiv fast float %2256, %1951
  %2258 = fsub fast float 1.000000e+00, %2257
  %2259 = call float @dx.op.unary.f32(i32 7, float %2258)  ; Saturate(value)
  %2260 = fcmp fast ugt float %2259, 0.000000e+00
  br i1 %2260, label %2261, label %2271

; <label>:2261                                    ; preds = %2251
  %2262 = fsub fast float %1208, %700
  %2263 = fsub fast float %1209, %701
  %2264 = fsub fast float %1210, %702
  %2265 = fmul fast float %2259, %2262
  %2266 = fmul fast float %2259, %2263
  %2267 = fmul fast float %2259, %2264
  %2268 = fadd fast float %2265, %700
  %2269 = fadd fast float %2266, %701
  %2270 = fadd fast float %2267, %702
  br label %2271

; <label>:2271                                    ; preds = %2261, %2251
  %2272 = phi float [ %2268, %2261 ], [ %700, %2251 ]
  %2273 = phi float [ %2269, %2261 ], [ %701, %2251 ]
  %2274 = phi float [ %2270, %2261 ], [ %702, %2251 ]
  %2275 = add i32 %56, -1
  %2276 = call i32 @dx.op.binary.i32(i32 37, i32 %2275, i32 0)  ; IMax(a,b)
  %2277 = call i32 @dx.op.binary.i32(i32 38, i32 %2276, i32 %60)  ; IMin(a,b)
  %2278 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %67, i32 %2277, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2279 = extractvalue %dx.types.ResRet.f32 %2278, 0
  %2280 = fsub fast float %2279, %84
  %2281 = call float @dx.op.unary.f32(i32 6, float %2280)  ; FAbs(value)
  %2282 = fdiv fast float %2281, %1951
  %2283 = fsub fast float 1.000000e+00, %2282
  %2284 = call float @dx.op.unary.f32(i32 7, float %2283)  ; Saturate(value)
  %2285 = fcmp fast ugt float %2284, 0.000000e+00
  br i1 %2285, label %2286, label %2559

; <label>:2286                                    ; preds = %2271
  %2287 = call i32 @dx.op.binary.i32(i32 37, i32 %67, i32 0)  ; IMax(a,b)
  %2288 = call i32 @dx.op.binary.i32(i32 37, i32 %2277, i32 0)  ; IMax(a,b)
  %2289 = call i32 @dx.op.binary.i32(i32 38, i32 %2287, i32 %59)  ; IMin(a,b)
  %2290 = call i32 @dx.op.binary.i32(i32 38, i32 %2288, i32 %60)  ; IMin(a,b)
  %2291 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2289, i32 %2290, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2292 = extractvalue %dx.types.ResRet.f32 %2291, 0
  %2293 = extractvalue %dx.types.ResRet.f32 %2291, 1
  %2294 = extractvalue %dx.types.ResRet.f32 %2291, 2
  %2295 = extractvalue %dx.types.ResRet.f32 %2291, 3
  %2296 = fcmp fast olt float %2295, 0.000000e+00
  br i1 %2296, label %2297, label %2331

; <label>:2297                                    ; preds = %2286
  %2298 = fcmp fast ogt float %2292, 0x3FA4B5DCC0000000
  %2299 = fcmp fast ogt float %2293, 0x3FA4B5DCC0000000
  %2300 = fcmp fast ogt float %2294, 0x3FA4B5DCC0000000
  %2301 = select i1 %2298, float 0.000000e+00, float 1.000000e+00
  %2302 = select i1 %2299, float 0.000000e+00, float 1.000000e+00
  %2303 = select i1 %2300, float 0.000000e+00, float 1.000000e+00
  %2304 = fmul fast float %2292, 0x3FB3D07220000000
  %2305 = fmul fast float %2293, 0x3FB3D07220000000
  %2306 = fmul fast float %2294, 0x3FB3D07220000000
  %2307 = fadd fast float %2292, 0x3FAC28F5C0000000
  %2308 = fadd fast float %2293, 0x3FAC28F5C0000000
  %2309 = fadd fast float %2294, 0x3FAC28F5C0000000
  %2310 = fmul fast float %2307, 0x3FEE54EDE0000000
  %2311 = fmul fast float %2308, 0x3FEE54EDE0000000
  %2312 = fmul fast float %2309, 0x3FEE54EDE0000000
  %2313 = call float @dx.op.unary.f32(i32 23, float %2310)  ; Log(value)
  %2314 = call float @dx.op.unary.f32(i32 23, float %2311)  ; Log(value)
  %2315 = call float @dx.op.unary.f32(i32 23, float %2312)  ; Log(value)
  %2316 = fmul fast float %2313, 0x4003333340000000
  %2317 = fmul fast float %2314, 0x4003333340000000
  %2318 = fmul fast float %2315, 0x4003333340000000
  %2319 = call float @dx.op.unary.f32(i32 21, float %2316)  ; Exp(value)
  %2320 = call float @dx.op.unary.f32(i32 21, float %2317)  ; Exp(value)
  %2321 = call float @dx.op.unary.f32(i32 21, float %2318)  ; Exp(value)
  %2322 = fsub fast float %2304, %2319
  %2323 = fsub fast float %2305, %2320
  %2324 = fsub fast float %2306, %2321
  %2325 = fmul fast float %2322, %2301
  %2326 = fmul fast float %2323, %2302
  %2327 = fmul fast float %2324, %2303
  %2328 = fadd fast float %2325, %2319
  %2329 = fadd fast float %2326, %2320
  %2330 = fadd fast float %2327, %2321
  br label %2546

; <label>:2331                                    ; preds = %2286
  %2332 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2289, i32 %2290, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2333 = extractvalue %dx.types.ResRet.f32 %2332, 0
  %2334 = fcmp fast ogt float %38, 5.000000e-01
  %2335 = fcmp fast olt float %2333, 1.000000e+00
  %2336 = and i1 %2334, %2335
  br i1 %2336, label %2337, label %2475

; <label>:2337                                    ; preds = %2331
  %2338 = sitofp i32 %2289 to float
  %2339 = sitofp i32 %2290 to float
  %2340 = fadd fast float %2338, 5.000000e-01
  %2341 = fadd fast float %2339, 5.000000e-01
  %2342 = fdiv fast float %2340, %45
  %2343 = fdiv fast float %2341, %46
  %2344 = fmul fast float %2342, 2.000000e+00
  %2345 = fmul fast float %2343, 2.000000e+00
  %2346 = fadd fast float %2344, -1.000000e+00
  %2347 = fsub fast float 1.000000e+00, %2345
  %2348 = fmul fast float %2346, %35
  %2349 = call float @dx.op.tertiary.f32(i32 46, float %2347, float %31, float %2348)  ; FMad(a,b,c)
  %2350 = call float @dx.op.tertiary.f32(i32 46, float %2333, float %27, float %2349)  ; FMad(a,b,c)
  %2351 = fadd fast float %2350, %23
  %2352 = call float @dx.op.unary.f32(i32 6, float %2351)  ; FAbs(value)
  %2353 = fcmp fast ogt float %2352, 0x3EB0C6F7A0000000
  br i1 %2353, label %2354, label %2475

; <label>:2354                                    ; preds = %2337
  %2355 = fmul fast float %2346, %34
  %2356 = call float @dx.op.tertiary.f32(i32 46, float %2347, float %30, float %2355)  ; FMad(a,b,c)
  %2357 = call float @dx.op.tertiary.f32(i32 46, float %2333, float %26, float %2356)  ; FMad(a,b,c)
  %2358 = fadd fast float %2357, %22
  %2359 = fmul fast float %2346, %33
  %2360 = call float @dx.op.tertiary.f32(i32 46, float %2347, float %29, float %2359)  ; FMad(a,b,c)
  %2361 = call float @dx.op.tertiary.f32(i32 46, float %2333, float %25, float %2360)  ; FMad(a,b,c)
  %2362 = fadd fast float %2361, %21
  %2363 = fmul fast float %2346, %32
  %2364 = call float @dx.op.tertiary.f32(i32 46, float %2347, float %28, float %2363)  ; FMad(a,b,c)
  %2365 = call float @dx.op.tertiary.f32(i32 46, float %2333, float %24, float %2364)  ; FMad(a,b,c)
  %2366 = fadd fast float %2365, %20
  %2367 = fdiv fast float %2366, %2351
  %2368 = fdiv fast float %2362, %2351
  %2369 = fdiv fast float %2358, %2351
  %2370 = fsub fast float %2367, %17
  %2371 = fsub fast float %2368, %18
  %2372 = fsub fast float %2369, %19
  %2373 = fmul fast float %2370, %2370
  %2374 = fmul fast float %2371, %2371
  %2375 = fadd fast float %2374, %2373
  %2376 = fmul fast float %2372, %2372
  %2377 = fadd fast float %2375, %2376
  %2378 = call float @dx.op.unary.f32(i32 24, float %2377)  ; Sqrt(value)
  %2379 = fsub fast float %2378, %9
  %2380 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2379)  ; FMax(a,b)
  %2381 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %2381, label %2382, label %2405

; <label>:2382                                    ; preds = %2354
  %2383 = call float @dx.op.unary.f32(i32 6, float %2371)  ; FAbs(value)
  %2384 = fmul fast float %2383, %11
  %2385 = fcmp fast olt float %2384, 0x3F50624DE0000000
  br i1 %2385, label %2386, label %2389

; <label>:2386                                    ; preds = %2382
  %2387 = fmul fast float %2384, 5.000000e-01
  %2388 = fsub fast float 1.000000e+00, %2387
  br label %2394

; <label>:2389                                    ; preds = %2382
  %2390 = fmul fast float %2384, 0xBFF7154760000000
  %2391 = call float @dx.op.unary.f32(i32 21, float %2390)  ; Exp(value)
  %2392 = fsub fast float 1.000000e+00, %2391
  %2393 = fdiv fast float %2392, %2384
  br label %2394

; <label>:2394                                    ; preds = %2389, %2386
  %2395 = phi float [ %2388, %2386 ], [ %2393, %2389 ]
  %2396 = call float @dx.op.binary.f32(i32 36, float %2368, float %18)  ; FMin(a,b)
  %2397 = fsub fast float %2396, %10
  %2398 = fmul fast float %11, %2397
  %2399 = fsub fast float -0.000000e+00, %2398
  %2400 = call float @dx.op.binary.f32(i32 35, float %2399, float -4.000000e+01)  ; FMax(a,b)
  %2401 = call float @dx.op.binary.f32(i32 36, float %2400, float 5.000000e+00)  ; FMin(a,b)
  %2402 = fmul fast float %2401, 0x3FF7154760000000
  %2403 = call float @dx.op.unary.f32(i32 21, float %2402)  ; Exp(value)
  %2404 = fmul fast float %2403, %2395
  br label %2405

; <label>:2405                                    ; preds = %2394, %2354
  %2406 = phi float [ %2404, %2394 ], [ 1.000000e+00, %2354 ]
  %2407 = fmul fast float %2380, %16
  %2408 = fmul fast float %2407, %2406
  %2409 = fcmp fast ole float %2378, %9
  %2410 = fcmp fast olt float %2378, 0x3F1A36E2E0000000
  %2411 = or i1 %2409, %2410
  br i1 %2411, label %2458, label %2412

; <label>:2412                                    ; preds = %2405
  %2413 = fdiv fast float %9, %2378
  %2414 = fmul fast float %2413, %2370
  %2415 = fmul fast float %2413, %2371
  %2416 = fmul fast float %2413, %2372
  %2417 = fadd fast float %2414, %17
  %2418 = fadd fast float %2415, %18
  %2419 = fadd fast float %2416, %19
  %2420 = fadd fast float %2417, -9.000000e+02
  %2421 = fadd fast float %2418, -1.500000e+01
  %2422 = fadd fast float %2419, -7.500000e+02
  %2423 = fmul fast float %2420, 0x3F62345680000000
  %2424 = fmul fast float %2421, 0x3F62345680000000
  %2425 = fmul fast float %2422, 0x3F62345680000000
  %2426 = call float @dx.op.dot3.f32(i32 55, float %2423, float %2424, float %2425, float %2423, float %2424, float %2425)  ; Dot3(ax,ay,az,bx,by,bz)
  %2427 = fsub fast float 1.000000e+00, %2426
  %2428 = call float @dx.op.unary.f32(i32 7, float %2427)  ; Saturate(value)
  %2429 = fmul fast float %2428, %2428
  %2430 = fadd fast float %2417, %2367
  %2431 = fadd fast float %2418, %2368
  %2432 = fadd fast float %2419, %2369
  %2433 = fmul fast float %2430, 0x3F52345680000000
  %2434 = fadd fast float %2433, -2.000000e+00
  %2435 = fmul fast float %2431, 0x3F52345680000000
  %2436 = fadd fast float %2435, 0xBFA1111120000000
  %2437 = fmul fast float %2432, 0x3F52345680000000
  %2438 = fadd fast float %2437, 0xBFFAAAAAC0000000
  %2439 = call float @dx.op.dot3.f32(i32 55, float %2434, float %2436, float %2438, float %2434, float %2436, float %2438)  ; Dot3(ax,ay,az,bx,by,bz)
  %2440 = fsub fast float 1.000000e+00, %2439
  %2441 = call float @dx.op.unary.f32(i32 7, float %2440)  ; Saturate(value)
  %2442 = fmul fast float %2441, %2441
  %2443 = fmul fast float %2442, 4.000000e+00
  %2444 = fadd fast float %2443, %2429
  %2445 = fadd fast float %2367, -9.000000e+02
  %2446 = fadd fast float %2368, -1.500000e+01
  %2447 = fadd fast float %2369, -7.500000e+02
  %2448 = fmul fast float %2445, 0x3F62345680000000
  %2449 = fmul fast float %2446, 0x3F62345680000000
  %2450 = fmul fast float %2447, 0x3F62345680000000
  %2451 = call float @dx.op.dot3.f32(i32 55, float %2448, float %2449, float %2450, float %2448, float %2449, float %2450)  ; Dot3(ax,ay,az,bx,by,bz)
  %2452 = fsub fast float 1.000000e+00, %2451
  %2453 = call float @dx.op.unary.f32(i32 7, float %2452)  ; Saturate(value)
  %2454 = fmul fast float %2453, %2453
  %2455 = fadd fast float %2444, %2454
  %2456 = fmul fast float %2379, 0x3F25D867E0000000
  %2457 = fmul fast float %2456, %2455
  br label %2458

; <label>:2458                                    ; preds = %2412, %2405
  %2459 = phi float [ %2457, %2412 ], [ 0.000000e+00, %2405 ]
  %2460 = fadd fast float %2459, %2408
  %2461 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2460)  ; FMin(a,b)
  %2462 = fmul fast float %2461, 0xBFF7154760000000
  %2463 = call float @dx.op.unary.f32(i32 21, float %2462)  ; Exp(value)
  %2464 = fsub fast float 1.000000e+00, %2463
  %2465 = call float @dx.op.binary.f32(i32 36, float %12, float %2464)  ; FMin(a,b)
  %2466 = fsub fast float %13, %2292
  %2467 = fsub fast float %14, %2293
  %2468 = fsub fast float %15, %2294
  %2469 = fmul fast float %2465, %2466
  %2470 = fmul fast float %2465, %2467
  %2471 = fmul fast float %2465, %2468
  %2472 = fadd fast float %2469, %2292
  %2473 = fadd fast float %2470, %2293
  %2474 = fadd fast float %2471, %2294
  br label %2475

; <label>:2475                                    ; preds = %2458, %2337, %2331
  %2476 = phi float [ %2472, %2458 ], [ %2292, %2337 ], [ %2292, %2331 ]
  %2477 = phi float [ %2473, %2458 ], [ %2293, %2337 ], [ %2293, %2331 ]
  %2478 = phi float [ %2474, %2458 ], [ %2294, %2337 ], [ %2294, %2331 ]
  %2479 = fadd fast float %5, 1.000000e+00
  %2480 = fadd fast float %6, 1.000000e+00
  %2481 = fsub fast float 1.000000e+00, %5
  %2482 = fmul fast float %36, %2479
  %2483 = fmul fast float %36, %2480
  %2484 = fmul fast float %36, %2481
  %2485 = fmul fast float %2482, %2476
  %2486 = fmul fast float %2483, %2477
  %2487 = fmul fast float %2484, %2478
  %2488 = fcmp fast ult float %37, 5.000000e-01
  br i1 %2488, label %2514, label %2489

; <label>:2489                                    ; preds = %2475
  %2490 = fmul fast float %2485, 0x4004147AE0000000
  %2491 = fmul fast float %2486, 0x4004147AE0000000
  %2492 = fmul fast float %2487, 0x4004147AE0000000
  %2493 = fadd fast float %2490, 0x3F9EB851E0000000
  %2494 = fadd fast float %2491, 0x3F9EB851E0000000
  %2495 = fadd fast float %2492, 0x3F9EB851E0000000
  %2496 = fmul fast float %2493, %2485
  %2497 = fmul fast float %2494, %2486
  %2498 = fmul fast float %2495, %2487
  %2499 = fmul fast float %2485, 0x400370A3E0000000
  %2500 = fmul fast float %2486, 0x400370A3E0000000
  %2501 = fmul fast float %2487, 0x400370A3E0000000
  %2502 = fadd fast float %2499, 0x3FE2E147A0000000
  %2503 = fadd fast float %2500, 0x3FE2E147A0000000
  %2504 = fadd fast float %2501, 0x3FE2E147A0000000
  %2505 = fmul fast float %2502, %2485
  %2506 = fmul fast float %2503, %2486
  %2507 = fmul fast float %2504, %2487
  %2508 = fadd fast float %2505, 0x3FC1EB8520000000
  %2509 = fadd fast float %2506, 0x3FC1EB8520000000
  %2510 = fadd fast float %2507, 0x3FC1EB8520000000
  %2511 = fdiv fast float %2496, %2508
  %2512 = fdiv fast float %2497, %2509
  %2513 = fdiv fast float %2498, %2510
  br label %2514

; <label>:2514                                    ; preds = %2489, %2475
  %2515 = phi float [ %2511, %2489 ], [ %2485, %2475 ]
  %2516 = phi float [ %2512, %2489 ], [ %2486, %2475 ]
  %2517 = phi float [ %2513, %2489 ], [ %2487, %2475 ]
  %2518 = call float @dx.op.unary.f32(i32 7, float %2515)  ; Saturate(value)
  %2519 = call float @dx.op.unary.f32(i32 7, float %2516)  ; Saturate(value)
  %2520 = call float @dx.op.unary.f32(i32 7, float %2517)  ; Saturate(value)
  %2521 = call float @dx.op.dot3.f32(i32 55, float %2518, float %2519, float %2520, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2522 = fsub fast float %2518, %2521
  %2523 = fsub fast float %2519, %2521
  %2524 = fsub fast float %2520, %2521
  %2525 = fmul fast float %2522, %8
  %2526 = fmul fast float %2523, %8
  %2527 = fmul fast float %2524, %8
  %2528 = fadd fast float %2525, %2521
  %2529 = fadd fast float %2526, %2521
  %2530 = fadd fast float %2527, %2521
  %2531 = call float @dx.op.unary.f32(i32 7, float %2528)  ; Saturate(value)
  %2532 = call float @dx.op.unary.f32(i32 7, float %2529)  ; Saturate(value)
  %2533 = call float @dx.op.unary.f32(i32 7, float %2530)  ; Saturate(value)
  %2534 = fadd fast float %2531, 0xBFC70A3D80000000
  %2535 = fadd fast float %2532, 0xBFC70A3D80000000
  %2536 = fadd fast float %2533, 0xBFC70A3D80000000
  %2537 = fmul fast float %2534, %7
  %2538 = fmul fast float %2535, %7
  %2539 = fmul fast float %2536, %7
  %2540 = fadd fast float %2537, 0x3FC70A3D80000000
  %2541 = fadd fast float %2538, 0x3FC70A3D80000000
  %2542 = fadd fast float %2539, 0x3FC70A3D80000000
  %2543 = call float @dx.op.unary.f32(i32 7, float %2540)  ; Saturate(value)
  %2544 = call float @dx.op.unary.f32(i32 7, float %2541)  ; Saturate(value)
  %2545 = call float @dx.op.unary.f32(i32 7, float %2542)  ; Saturate(value)
  br label %2546

; <label>:2546                                    ; preds = %2514, %2297
  %2547 = phi float [ %2328, %2297 ], [ %2543, %2514 ]
  %2548 = phi float [ %2329, %2297 ], [ %2544, %2514 ]
  %2549 = phi float [ %2330, %2297 ], [ %2545, %2514 ]
  %2550 = fsub fast float %2547, %700
  %2551 = fsub fast float %2548, %701
  %2552 = fsub fast float %2549, %702
  %2553 = fmul fast float %2550, %2284
  %2554 = fmul fast float %2551, %2284
  %2555 = fmul fast float %2552, %2284
  %2556 = fadd fast float %2553, %700
  %2557 = fadd fast float %2554, %701
  %2558 = fadd fast float %2555, %702
  br label %2559

; <label>:2559                                    ; preds = %2546, %2271
  %2560 = phi float [ %2556, %2546 ], [ %700, %2271 ]
  %2561 = phi float [ %2557, %2546 ], [ %701, %2271 ]
  %2562 = phi float [ %2558, %2546 ], [ %702, %2271 ]
  %2563 = call float @dx.op.binary.f32(i32 36, float %2252, float %2232)  ; FMin(a,b)
  %2564 = call float @dx.op.binary.f32(i32 36, float %2253, float %2233)  ; FMin(a,b)
  %2565 = call float @dx.op.binary.f32(i32 36, float %2254, float %2234)  ; FMin(a,b)
  %2566 = call float @dx.op.binary.f32(i32 36, float %2560, float %2272)  ; FMin(a,b)
  %2567 = call float @dx.op.binary.f32(i32 36, float %2561, float %2273)  ; FMin(a,b)
  %2568 = call float @dx.op.binary.f32(i32 36, float %2562, float %2274)  ; FMin(a,b)
  %2569 = call float @dx.op.binary.f32(i32 36, float %2566, float %2563)  ; FMin(a,b)
  %2570 = call float @dx.op.binary.f32(i32 36, float %2567, float %2564)  ; FMin(a,b)
  %2571 = call float @dx.op.binary.f32(i32 36, float %2568, float %2565)  ; FMin(a,b)
  %2572 = call float @dx.op.binary.f32(i32 36, float %700, float %2569)  ; FMin(a,b)
  %2573 = call float @dx.op.binary.f32(i32 36, float %701, float %2570)  ; FMin(a,b)
  %2574 = call float @dx.op.binary.f32(i32 36, float %702, float %2571)  ; FMin(a,b)
  %2575 = call float @dx.op.binary.f32(i32 35, float %2252, float %2232)  ; FMax(a,b)
  %2576 = call float @dx.op.binary.f32(i32 35, float %2253, float %2233)  ; FMax(a,b)
  %2577 = call float @dx.op.binary.f32(i32 35, float %2254, float %2234)  ; FMax(a,b)
  %2578 = call float @dx.op.binary.f32(i32 35, float %2560, float %2272)  ; FMax(a,b)
  %2579 = call float @dx.op.binary.f32(i32 35, float %2561, float %2273)  ; FMax(a,b)
  %2580 = call float @dx.op.binary.f32(i32 35, float %2562, float %2274)  ; FMax(a,b)
  %2581 = call float @dx.op.binary.f32(i32 35, float %2578, float %2575)  ; FMax(a,b)
  %2582 = call float @dx.op.binary.f32(i32 35, float %2579, float %2576)  ; FMax(a,b)
  %2583 = call float @dx.op.binary.f32(i32 35, float %2580, float %2577)  ; FMax(a,b)
  %2584 = call float @dx.op.binary.f32(i32 35, float %700, float %2581)  ; FMax(a,b)
  %2585 = call float @dx.op.binary.f32(i32 35, float %701, float %2582)  ; FMax(a,b)
  %2586 = call float @dx.op.binary.f32(i32 35, float %702, float %2583)  ; FMax(a,b)
  %2587 = fsub fast float %2584, %2572
  %2588 = fsub fast float %2585, %2573
  %2589 = fsub fast float %2586, %2574
  %2590 = call float @dx.op.unary.f32(i32 6, float %2587)  ; FAbs(value)
  %2591 = call float @dx.op.unary.f32(i32 6, float %2588)  ; FAbs(value)
  %2592 = call float @dx.op.unary.f32(i32 6, float %2589)  ; FAbs(value)
  %2593 = call float @dx.op.binary.f32(i32 35, float %2591, float %2592)  ; FMax(a,b)
  %2594 = call float @dx.op.binary.f32(i32 35, float %2590, float %2593)  ; FMax(a,b)
  %2595 = call float @dx.op.binary.f32(i32 35, float %2585, float %2586)  ; FMax(a,b)
  %2596 = call float @dx.op.binary.f32(i32 35, float %2584, float %2595)  ; FMax(a,b)
  %2597 = fmul fast float %2596, 1.250000e-01
  %2598 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %2597)  ; FMax(a,b)
  %2599 = fcmp fast ogt float %2594, %2598
  br i1 %2599, label %2600, label %2661

; <label>:2600                                    ; preds = %2559
  %2601 = fsub fast float %2560, %2272
  %2602 = fsub fast float %2561, %2273
  %2603 = fsub fast float %2562, %2274
  %2604 = call float @dx.op.unary.f32(i32 6, float %2601)  ; FAbs(value)
  %2605 = call float @dx.op.unary.f32(i32 6, float %2602)  ; FAbs(value)
  %2606 = call float @dx.op.unary.f32(i32 6, float %2603)  ; FAbs(value)
  %2607 = call float @dx.op.binary.f32(i32 35, float %2605, float %2606)  ; FMax(a,b)
  %2608 = call float @dx.op.binary.f32(i32 35, float %2604, float %2607)  ; FMax(a,b)
  %2609 = fsub fast float %2252, %2232
  %2610 = fsub fast float %2253, %2233
  %2611 = fsub fast float %2254, %2234
  %2612 = call float @dx.op.unary.f32(i32 6, float %2609)  ; FAbs(value)
  %2613 = call float @dx.op.unary.f32(i32 6, float %2610)  ; FAbs(value)
  %2614 = call float @dx.op.unary.f32(i32 6, float %2611)  ; FAbs(value)
  %2615 = call float @dx.op.binary.f32(i32 35, float %2613, float %2614)  ; FMax(a,b)
  %2616 = call float @dx.op.binary.f32(i32 35, float %2612, float %2615)  ; FMax(a,b)
  %2617 = fcmp fast olt float %2608, %2616
  %2618 = select i1 %2617, float %2560, float %2252
  %2619 = select i1 %2617, float %2561, float %2253
  %2620 = select i1 %2617, float %2562, float %2254
  %2621 = select i1 %2617, float %2272, float %2232
  %2622 = select i1 %2617, float %2273, float %2233
  %2623 = select i1 %2617, float %2274, float %2234
  %2624 = fsub fast float %700, %2621
  %2625 = fsub fast float %701, %2622
  %2626 = fsub fast float %702, %2623
  %2627 = fsub fast float %700, %2618
  %2628 = fsub fast float %701, %2619
  %2629 = fsub fast float %702, %2620
  %2630 = call float @dx.op.dot3.f32(i32 55, float %2627, float %2628, float %2629, float %2624, float %2625, float %2626)  ; Dot3(ax,ay,az,bx,by,bz)
  %2631 = fcmp fast ogt float %2630, 0.000000e+00
  br i1 %2631, label %2632, label %2643

; <label>:2632                                    ; preds = %2600
  %2633 = fsub fast float %2618, %2621
  %2634 = fsub fast float %2619, %2622
  %2635 = fsub fast float %2620, %2623
  %2636 = call float @dx.op.unary.f32(i32 6, float %2633)  ; FAbs(value)
  %2637 = call float @dx.op.unary.f32(i32 6, float %2634)  ; FAbs(value)
  %2638 = call float @dx.op.unary.f32(i32 6, float %2635)  ; FAbs(value)
  %2639 = call float @dx.op.binary.f32(i32 35, float %2637, float %2638)  ; FMax(a,b)
  %2640 = call float @dx.op.binary.f32(i32 35, float %2636, float %2639)  ; FMax(a,b)
  %2641 = fmul fast float %2594, 2.500000e-01
  %2642 = fcmp fast olt float %2640, %2641
  br label %2643

; <label>:2643                                    ; preds = %2632, %2600
  %2644 = phi i1 [ false, %2600 ], [ %2642, %2632 ]
  %2645 = select i1 %2644, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  %2646 = fadd fast float %2618, %2621
  %2647 = fadd fast float %2619, %2622
  %2648 = fadd fast float %2620, %2623
  %2649 = fmul fast float %2646, 5.000000e-01
  %2650 = fmul fast float %2647, 5.000000e-01
  %2651 = fmul fast float %2648, 5.000000e-01
  %2652 = fsub fast float %2649, %700
  %2653 = fsub fast float %2650, %701
  %2654 = fsub fast float %2651, %702
  %2655 = fmul fast float %2645, %2652
  %2656 = fmul fast float %2645, %2653
  %2657 = fmul fast float %2645, %2654
  %2658 = fadd fast float %2655, %700
  %2659 = fadd fast float %2656, %701
  %2660 = fadd fast float %2657, %702
  br label %2661

; <label>:2661                                    ; preds = %2643, %2559, %1938
  %2662 = phi float [ %700, %1938 ], [ %2658, %2643 ], [ %700, %2559 ]
  %2663 = phi float [ %701, %1938 ], [ %2659, %2643 ], [ %701, %2559 ]
  %2664 = phi float [ %702, %1938 ], [ %2660, %2643 ], [ %702, %2559 ]
  %2665 = fcmp fast ult float %189, 0.000000e+00
  br i1 %2665, label %3384, label %2666

; <label>:2666                                    ; preds = %2661
  %2667 = fsub fast float 1.000000e+00, %86
  %2668 = fmul fast float %2667, 0x3FA99999A0000000
  %2669 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %2668)  ; FMax(a,b)
  %2670 = fsub fast float %88, %86
  %2671 = call float @dx.op.unary.f32(i32 6, float %2670)  ; FAbs(value)
  %2672 = fdiv fast float %2671, %2669
  %2673 = fsub fast float 1.000000e+00, %2672
  %2674 = call float @dx.op.unary.f32(i32 7, float %2673)  ; Saturate(value)
  %2675 = fcmp fast ugt float %2674, 0.000000e+00
  br i1 %2675, label %2676, label %2686

; <label>:2676                                    ; preds = %2666
  %2677 = fsub fast float %1208, %954
  %2678 = fsub fast float %1209, %955
  %2679 = fsub fast float %1210, %956
  %2680 = fmul fast float %2674, %2677
  %2681 = fmul fast float %2674, %2678
  %2682 = fmul fast float %2674, %2679
  %2683 = fadd fast float %2680, %954
  %2684 = fadd fast float %2681, %955
  %2685 = fadd fast float %2682, %956
  br label %2686

; <label>:2686                                    ; preds = %2676, %2666
  %2687 = phi float [ %2683, %2676 ], [ %954, %2666 ]
  %2688 = phi float [ %2684, %2676 ], [ %955, %2666 ]
  %2689 = phi float [ %2685, %2676 ], [ %956, %2666 ]
  %2690 = add i32 %55, -1
  %2691 = call i32 @dx.op.binary.i32(i32 37, i32 %2690, i32 0)  ; IMax(a,b)
  %2692 = call i32 @dx.op.binary.i32(i32 38, i32 %2691, i32 %59)  ; IMin(a,b)
  %2693 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2692, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2694 = extractvalue %dx.types.ResRet.f32 %2693, 0
  %2695 = fsub fast float %2694, %86
  %2696 = call float @dx.op.unary.f32(i32 6, float %2695)  ; FAbs(value)
  %2697 = fdiv fast float %2696, %2669
  %2698 = fsub fast float 1.000000e+00, %2697
  %2699 = call float @dx.op.unary.f32(i32 7, float %2698)  ; Saturate(value)
  %2700 = fcmp fast ugt float %2699, 0.000000e+00
  br i1 %2700, label %2701, label %2974

; <label>:2701                                    ; preds = %2686
  %2702 = call i32 @dx.op.binary.i32(i32 37, i32 %2692, i32 0)  ; IMax(a,b)
  %2703 = call i32 @dx.op.binary.i32(i32 37, i32 %70, i32 0)  ; IMax(a,b)
  %2704 = call i32 @dx.op.binary.i32(i32 38, i32 %2702, i32 %59)  ; IMin(a,b)
  %2705 = call i32 @dx.op.binary.i32(i32 38, i32 %2703, i32 %60)  ; IMin(a,b)
  %2706 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2704, i32 %2705, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2707 = extractvalue %dx.types.ResRet.f32 %2706, 0
  %2708 = extractvalue %dx.types.ResRet.f32 %2706, 1
  %2709 = extractvalue %dx.types.ResRet.f32 %2706, 2
  %2710 = extractvalue %dx.types.ResRet.f32 %2706, 3
  %2711 = fcmp fast olt float %2710, 0.000000e+00
  br i1 %2711, label %2712, label %2746

; <label>:2712                                    ; preds = %2701
  %2713 = fcmp fast ogt float %2707, 0x3FA4B5DCC0000000
  %2714 = fcmp fast ogt float %2708, 0x3FA4B5DCC0000000
  %2715 = fcmp fast ogt float %2709, 0x3FA4B5DCC0000000
  %2716 = select i1 %2713, float 0.000000e+00, float 1.000000e+00
  %2717 = select i1 %2714, float 0.000000e+00, float 1.000000e+00
  %2718 = select i1 %2715, float 0.000000e+00, float 1.000000e+00
  %2719 = fmul fast float %2707, 0x3FB3D07220000000
  %2720 = fmul fast float %2708, 0x3FB3D07220000000
  %2721 = fmul fast float %2709, 0x3FB3D07220000000
  %2722 = fadd fast float %2707, 0x3FAC28F5C0000000
  %2723 = fadd fast float %2708, 0x3FAC28F5C0000000
  %2724 = fadd fast float %2709, 0x3FAC28F5C0000000
  %2725 = fmul fast float %2722, 0x3FEE54EDE0000000
  %2726 = fmul fast float %2723, 0x3FEE54EDE0000000
  %2727 = fmul fast float %2724, 0x3FEE54EDE0000000
  %2728 = call float @dx.op.unary.f32(i32 23, float %2725)  ; Log(value)
  %2729 = call float @dx.op.unary.f32(i32 23, float %2726)  ; Log(value)
  %2730 = call float @dx.op.unary.f32(i32 23, float %2727)  ; Log(value)
  %2731 = fmul fast float %2728, 0x4003333340000000
  %2732 = fmul fast float %2729, 0x4003333340000000
  %2733 = fmul fast float %2730, 0x4003333340000000
  %2734 = call float @dx.op.unary.f32(i32 21, float %2731)  ; Exp(value)
  %2735 = call float @dx.op.unary.f32(i32 21, float %2732)  ; Exp(value)
  %2736 = call float @dx.op.unary.f32(i32 21, float %2733)  ; Exp(value)
  %2737 = fsub fast float %2719, %2734
  %2738 = fsub fast float %2720, %2735
  %2739 = fsub fast float %2721, %2736
  %2740 = fmul fast float %2737, %2716
  %2741 = fmul fast float %2738, %2717
  %2742 = fmul fast float %2739, %2718
  %2743 = fadd fast float %2740, %2734
  %2744 = fadd fast float %2741, %2735
  %2745 = fadd fast float %2742, %2736
  br label %2961

; <label>:2746                                    ; preds = %2701
  %2747 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2704, i32 %2705, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2748 = extractvalue %dx.types.ResRet.f32 %2747, 0
  %2749 = fcmp fast ogt float %38, 5.000000e-01
  %2750 = fcmp fast olt float %2748, 1.000000e+00
  %2751 = and i1 %2749, %2750
  br i1 %2751, label %2752, label %2890

; <label>:2752                                    ; preds = %2746
  %2753 = sitofp i32 %2704 to float
  %2754 = sitofp i32 %2705 to float
  %2755 = fadd fast float %2753, 5.000000e-01
  %2756 = fadd fast float %2754, 5.000000e-01
  %2757 = fdiv fast float %2755, %45
  %2758 = fdiv fast float %2756, %46
  %2759 = fmul fast float %2757, 2.000000e+00
  %2760 = fmul fast float %2758, 2.000000e+00
  %2761 = fadd fast float %2759, -1.000000e+00
  %2762 = fsub fast float 1.000000e+00, %2760
  %2763 = fmul fast float %2761, %35
  %2764 = call float @dx.op.tertiary.f32(i32 46, float %2762, float %31, float %2763)  ; FMad(a,b,c)
  %2765 = call float @dx.op.tertiary.f32(i32 46, float %2748, float %27, float %2764)  ; FMad(a,b,c)
  %2766 = fadd fast float %2765, %23
  %2767 = call float @dx.op.unary.f32(i32 6, float %2766)  ; FAbs(value)
  %2768 = fcmp fast ogt float %2767, 0x3EB0C6F7A0000000
  br i1 %2768, label %2769, label %2890

; <label>:2769                                    ; preds = %2752
  %2770 = fmul fast float %2761, %34
  %2771 = call float @dx.op.tertiary.f32(i32 46, float %2762, float %30, float %2770)  ; FMad(a,b,c)
  %2772 = call float @dx.op.tertiary.f32(i32 46, float %2748, float %26, float %2771)  ; FMad(a,b,c)
  %2773 = fadd fast float %2772, %22
  %2774 = fmul fast float %2761, %33
  %2775 = call float @dx.op.tertiary.f32(i32 46, float %2762, float %29, float %2774)  ; FMad(a,b,c)
  %2776 = call float @dx.op.tertiary.f32(i32 46, float %2748, float %25, float %2775)  ; FMad(a,b,c)
  %2777 = fadd fast float %2776, %21
  %2778 = fmul fast float %2761, %32
  %2779 = call float @dx.op.tertiary.f32(i32 46, float %2762, float %28, float %2778)  ; FMad(a,b,c)
  %2780 = call float @dx.op.tertiary.f32(i32 46, float %2748, float %24, float %2779)  ; FMad(a,b,c)
  %2781 = fadd fast float %2780, %20
  %2782 = fdiv fast float %2781, %2766
  %2783 = fdiv fast float %2777, %2766
  %2784 = fdiv fast float %2773, %2766
  %2785 = fsub fast float %2782, %17
  %2786 = fsub fast float %2783, %18
  %2787 = fsub fast float %2784, %19
  %2788 = fmul fast float %2785, %2785
  %2789 = fmul fast float %2786, %2786
  %2790 = fadd fast float %2789, %2788
  %2791 = fmul fast float %2787, %2787
  %2792 = fadd fast float %2790, %2791
  %2793 = call float @dx.op.unary.f32(i32 24, float %2792)  ; Sqrt(value)
  %2794 = fsub fast float %2793, %9
  %2795 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2794)  ; FMax(a,b)
  %2796 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %2796, label %2797, label %2820

; <label>:2797                                    ; preds = %2769
  %2798 = call float @dx.op.unary.f32(i32 6, float %2786)  ; FAbs(value)
  %2799 = fmul fast float %2798, %11
  %2800 = fcmp fast olt float %2799, 0x3F50624DE0000000
  br i1 %2800, label %2801, label %2804

; <label>:2801                                    ; preds = %2797
  %2802 = fmul fast float %2799, 5.000000e-01
  %2803 = fsub fast float 1.000000e+00, %2802
  br label %2809

; <label>:2804                                    ; preds = %2797
  %2805 = fmul fast float %2799, 0xBFF7154760000000
  %2806 = call float @dx.op.unary.f32(i32 21, float %2805)  ; Exp(value)
  %2807 = fsub fast float 1.000000e+00, %2806
  %2808 = fdiv fast float %2807, %2799
  br label %2809

; <label>:2809                                    ; preds = %2804, %2801
  %2810 = phi float [ %2803, %2801 ], [ %2808, %2804 ]
  %2811 = call float @dx.op.binary.f32(i32 36, float %2783, float %18)  ; FMin(a,b)
  %2812 = fsub fast float %2811, %10
  %2813 = fmul fast float %11, %2812
  %2814 = fsub fast float -0.000000e+00, %2813
  %2815 = call float @dx.op.binary.f32(i32 35, float %2814, float -4.000000e+01)  ; FMax(a,b)
  %2816 = call float @dx.op.binary.f32(i32 36, float %2815, float 5.000000e+00)  ; FMin(a,b)
  %2817 = fmul fast float %2816, 0x3FF7154760000000
  %2818 = call float @dx.op.unary.f32(i32 21, float %2817)  ; Exp(value)
  %2819 = fmul fast float %2818, %2810
  br label %2820

; <label>:2820                                    ; preds = %2809, %2769
  %2821 = phi float [ %2819, %2809 ], [ 1.000000e+00, %2769 ]
  %2822 = fmul fast float %2795, %16
  %2823 = fmul fast float %2822, %2821
  %2824 = fcmp fast ole float %2793, %9
  %2825 = fcmp fast olt float %2793, 0x3F1A36E2E0000000
  %2826 = or i1 %2824, %2825
  br i1 %2826, label %2873, label %2827

; <label>:2827                                    ; preds = %2820
  %2828 = fdiv fast float %9, %2793
  %2829 = fmul fast float %2828, %2785
  %2830 = fmul fast float %2828, %2786
  %2831 = fmul fast float %2828, %2787
  %2832 = fadd fast float %2829, %17
  %2833 = fadd fast float %2830, %18
  %2834 = fadd fast float %2831, %19
  %2835 = fadd fast float %2832, -9.000000e+02
  %2836 = fadd fast float %2833, -1.500000e+01
  %2837 = fadd fast float %2834, -7.500000e+02
  %2838 = fmul fast float %2835, 0x3F62345680000000
  %2839 = fmul fast float %2836, 0x3F62345680000000
  %2840 = fmul fast float %2837, 0x3F62345680000000
  %2841 = call float @dx.op.dot3.f32(i32 55, float %2838, float %2839, float %2840, float %2838, float %2839, float %2840)  ; Dot3(ax,ay,az,bx,by,bz)
  %2842 = fsub fast float 1.000000e+00, %2841
  %2843 = call float @dx.op.unary.f32(i32 7, float %2842)  ; Saturate(value)
  %2844 = fmul fast float %2843, %2843
  %2845 = fadd fast float %2832, %2782
  %2846 = fadd fast float %2833, %2783
  %2847 = fadd fast float %2834, %2784
  %2848 = fmul fast float %2845, 0x3F52345680000000
  %2849 = fadd fast float %2848, -2.000000e+00
  %2850 = fmul fast float %2846, 0x3F52345680000000
  %2851 = fadd fast float %2850, 0xBFA1111120000000
  %2852 = fmul fast float %2847, 0x3F52345680000000
  %2853 = fadd fast float %2852, 0xBFFAAAAAC0000000
  %2854 = call float @dx.op.dot3.f32(i32 55, float %2849, float %2851, float %2853, float %2849, float %2851, float %2853)  ; Dot3(ax,ay,az,bx,by,bz)
  %2855 = fsub fast float 1.000000e+00, %2854
  %2856 = call float @dx.op.unary.f32(i32 7, float %2855)  ; Saturate(value)
  %2857 = fmul fast float %2856, %2856
  %2858 = fmul fast float %2857, 4.000000e+00
  %2859 = fadd fast float %2858, %2844
  %2860 = fadd fast float %2782, -9.000000e+02
  %2861 = fadd fast float %2783, -1.500000e+01
  %2862 = fadd fast float %2784, -7.500000e+02
  %2863 = fmul fast float %2860, 0x3F62345680000000
  %2864 = fmul fast float %2861, 0x3F62345680000000
  %2865 = fmul fast float %2862, 0x3F62345680000000
  %2866 = call float @dx.op.dot3.f32(i32 55, float %2863, float %2864, float %2865, float %2863, float %2864, float %2865)  ; Dot3(ax,ay,az,bx,by,bz)
  %2867 = fsub fast float 1.000000e+00, %2866
  %2868 = call float @dx.op.unary.f32(i32 7, float %2867)  ; Saturate(value)
  %2869 = fmul fast float %2868, %2868
  %2870 = fadd fast float %2859, %2869
  %2871 = fmul fast float %2794, 0x3F25D867E0000000
  %2872 = fmul fast float %2871, %2870
  br label %2873

; <label>:2873                                    ; preds = %2827, %2820
  %2874 = phi float [ %2872, %2827 ], [ 0.000000e+00, %2820 ]
  %2875 = fadd fast float %2874, %2823
  %2876 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2875)  ; FMin(a,b)
  %2877 = fmul fast float %2876, 0xBFF7154760000000
  %2878 = call float @dx.op.unary.f32(i32 21, float %2877)  ; Exp(value)
  %2879 = fsub fast float 1.000000e+00, %2878
  %2880 = call float @dx.op.binary.f32(i32 36, float %12, float %2879)  ; FMin(a,b)
  %2881 = fsub fast float %13, %2707
  %2882 = fsub fast float %14, %2708
  %2883 = fsub fast float %15, %2709
  %2884 = fmul fast float %2880, %2881
  %2885 = fmul fast float %2880, %2882
  %2886 = fmul fast float %2880, %2883
  %2887 = fadd fast float %2884, %2707
  %2888 = fadd fast float %2885, %2708
  %2889 = fadd fast float %2886, %2709
  br label %2890

; <label>:2890                                    ; preds = %2873, %2752, %2746
  %2891 = phi float [ %2887, %2873 ], [ %2707, %2752 ], [ %2707, %2746 ]
  %2892 = phi float [ %2888, %2873 ], [ %2708, %2752 ], [ %2708, %2746 ]
  %2893 = phi float [ %2889, %2873 ], [ %2709, %2752 ], [ %2709, %2746 ]
  %2894 = fadd fast float %5, 1.000000e+00
  %2895 = fadd fast float %6, 1.000000e+00
  %2896 = fsub fast float 1.000000e+00, %5
  %2897 = fmul fast float %36, %2894
  %2898 = fmul fast float %36, %2895
  %2899 = fmul fast float %36, %2896
  %2900 = fmul fast float %2897, %2891
  %2901 = fmul fast float %2898, %2892
  %2902 = fmul fast float %2899, %2893
  %2903 = fcmp fast ult float %37, 5.000000e-01
  br i1 %2903, label %2929, label %2904

; <label>:2904                                    ; preds = %2890
  %2905 = fmul fast float %2900, 0x4004147AE0000000
  %2906 = fmul fast float %2901, 0x4004147AE0000000
  %2907 = fmul fast float %2902, 0x4004147AE0000000
  %2908 = fadd fast float %2905, 0x3F9EB851E0000000
  %2909 = fadd fast float %2906, 0x3F9EB851E0000000
  %2910 = fadd fast float %2907, 0x3F9EB851E0000000
  %2911 = fmul fast float %2908, %2900
  %2912 = fmul fast float %2909, %2901
  %2913 = fmul fast float %2910, %2902
  %2914 = fmul fast float %2900, 0x400370A3E0000000
  %2915 = fmul fast float %2901, 0x400370A3E0000000
  %2916 = fmul fast float %2902, 0x400370A3E0000000
  %2917 = fadd fast float %2914, 0x3FE2E147A0000000
  %2918 = fadd fast float %2915, 0x3FE2E147A0000000
  %2919 = fadd fast float %2916, 0x3FE2E147A0000000
  %2920 = fmul fast float %2917, %2900
  %2921 = fmul fast float %2918, %2901
  %2922 = fmul fast float %2919, %2902
  %2923 = fadd fast float %2920, 0x3FC1EB8520000000
  %2924 = fadd fast float %2921, 0x3FC1EB8520000000
  %2925 = fadd fast float %2922, 0x3FC1EB8520000000
  %2926 = fdiv fast float %2911, %2923
  %2927 = fdiv fast float %2912, %2924
  %2928 = fdiv fast float %2913, %2925
  br label %2929

; <label>:2929                                    ; preds = %2904, %2890
  %2930 = phi float [ %2926, %2904 ], [ %2900, %2890 ]
  %2931 = phi float [ %2927, %2904 ], [ %2901, %2890 ]
  %2932 = phi float [ %2928, %2904 ], [ %2902, %2890 ]
  %2933 = call float @dx.op.unary.f32(i32 7, float %2930)  ; Saturate(value)
  %2934 = call float @dx.op.unary.f32(i32 7, float %2931)  ; Saturate(value)
  %2935 = call float @dx.op.unary.f32(i32 7, float %2932)  ; Saturate(value)
  %2936 = call float @dx.op.dot3.f32(i32 55, float %2933, float %2934, float %2935, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2937 = fsub fast float %2933, %2936
  %2938 = fsub fast float %2934, %2936
  %2939 = fsub fast float %2935, %2936
  %2940 = fmul fast float %2937, %8
  %2941 = fmul fast float %2938, %8
  %2942 = fmul fast float %2939, %8
  %2943 = fadd fast float %2940, %2936
  %2944 = fadd fast float %2941, %2936
  %2945 = fadd fast float %2942, %2936
  %2946 = call float @dx.op.unary.f32(i32 7, float %2943)  ; Saturate(value)
  %2947 = call float @dx.op.unary.f32(i32 7, float %2944)  ; Saturate(value)
  %2948 = call float @dx.op.unary.f32(i32 7, float %2945)  ; Saturate(value)
  %2949 = fadd fast float %2946, 0xBFC70A3D80000000
  %2950 = fadd fast float %2947, 0xBFC70A3D80000000
  %2951 = fadd fast float %2948, 0xBFC70A3D80000000
  %2952 = fmul fast float %2949, %7
  %2953 = fmul fast float %2950, %7
  %2954 = fmul fast float %2951, %7
  %2955 = fadd fast float %2952, 0x3FC70A3D80000000
  %2956 = fadd fast float %2953, 0x3FC70A3D80000000
  %2957 = fadd fast float %2954, 0x3FC70A3D80000000
  %2958 = call float @dx.op.unary.f32(i32 7, float %2955)  ; Saturate(value)
  %2959 = call float @dx.op.unary.f32(i32 7, float %2956)  ; Saturate(value)
  %2960 = call float @dx.op.unary.f32(i32 7, float %2957)  ; Saturate(value)
  br label %2961

; <label>:2961                                    ; preds = %2929, %2712
  %2962 = phi float [ %2743, %2712 ], [ %2958, %2929 ]
  %2963 = phi float [ %2744, %2712 ], [ %2959, %2929 ]
  %2964 = phi float [ %2745, %2712 ], [ %2960, %2929 ]
  %2965 = fsub fast float %2962, %954
  %2966 = fsub fast float %2963, %955
  %2967 = fsub fast float %2964, %956
  %2968 = fmul fast float %2965, %2699
  %2969 = fmul fast float %2966, %2699
  %2970 = fmul fast float %2967, %2699
  %2971 = fadd fast float %2968, %954
  %2972 = fadd fast float %2969, %955
  %2973 = fadd fast float %2970, %956
  br label %2974

; <label>:2974                                    ; preds = %2961, %2686
  %2975 = phi float [ %2971, %2961 ], [ %954, %2686 ]
  %2976 = phi float [ %2972, %2961 ], [ %955, %2686 ]
  %2977 = phi float [ %2973, %2961 ], [ %956, %2686 ]
  %2978 = add i32 %56, 2
  %2979 = call i32 @dx.op.binary.i32(i32 37, i32 %2978, i32 0)  ; IMax(a,b)
  %2980 = call i32 @dx.op.binary.i32(i32 38, i32 %2979, i32 %60)  ; IMin(a,b)
  %2981 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %2980, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2982 = extractvalue %dx.types.ResRet.f32 %2981, 0
  %2983 = fsub fast float %2982, %86
  %2984 = call float @dx.op.unary.f32(i32 6, float %2983)  ; FAbs(value)
  %2985 = fdiv fast float %2984, %2669
  %2986 = fsub fast float 1.000000e+00, %2985
  %2987 = call float @dx.op.unary.f32(i32 7, float %2986)  ; Saturate(value)
  %2988 = fcmp fast ugt float %2987, 0.000000e+00
  br i1 %2988, label %2989, label %3262

; <label>:2989                                    ; preds = %2974
  %2990 = call i32 @dx.op.binary.i32(i32 37, i32 %63, i32 0)  ; IMax(a,b)
  %2991 = call i32 @dx.op.binary.i32(i32 37, i32 %2980, i32 0)  ; IMax(a,b)
  %2992 = call i32 @dx.op.binary.i32(i32 38, i32 %2990, i32 %59)  ; IMin(a,b)
  %2993 = call i32 @dx.op.binary.i32(i32 38, i32 %2991, i32 %60)  ; IMin(a,b)
  %2994 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2992, i32 %2993, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2995 = extractvalue %dx.types.ResRet.f32 %2994, 0
  %2996 = extractvalue %dx.types.ResRet.f32 %2994, 1
  %2997 = extractvalue %dx.types.ResRet.f32 %2994, 2
  %2998 = extractvalue %dx.types.ResRet.f32 %2994, 3
  %2999 = fcmp fast olt float %2998, 0.000000e+00
  br i1 %2999, label %3000, label %3034

; <label>:3000                                    ; preds = %2989
  %3001 = fcmp fast ogt float %2995, 0x3FA4B5DCC0000000
  %3002 = fcmp fast ogt float %2996, 0x3FA4B5DCC0000000
  %3003 = fcmp fast ogt float %2997, 0x3FA4B5DCC0000000
  %3004 = select i1 %3001, float 0.000000e+00, float 1.000000e+00
  %3005 = select i1 %3002, float 0.000000e+00, float 1.000000e+00
  %3006 = select i1 %3003, float 0.000000e+00, float 1.000000e+00
  %3007 = fmul fast float %2995, 0x3FB3D07220000000
  %3008 = fmul fast float %2996, 0x3FB3D07220000000
  %3009 = fmul fast float %2997, 0x3FB3D07220000000
  %3010 = fadd fast float %2995, 0x3FAC28F5C0000000
  %3011 = fadd fast float %2996, 0x3FAC28F5C0000000
  %3012 = fadd fast float %2997, 0x3FAC28F5C0000000
  %3013 = fmul fast float %3010, 0x3FEE54EDE0000000
  %3014 = fmul fast float %3011, 0x3FEE54EDE0000000
  %3015 = fmul fast float %3012, 0x3FEE54EDE0000000
  %3016 = call float @dx.op.unary.f32(i32 23, float %3013)  ; Log(value)
  %3017 = call float @dx.op.unary.f32(i32 23, float %3014)  ; Log(value)
  %3018 = call float @dx.op.unary.f32(i32 23, float %3015)  ; Log(value)
  %3019 = fmul fast float %3016, 0x4003333340000000
  %3020 = fmul fast float %3017, 0x4003333340000000
  %3021 = fmul fast float %3018, 0x4003333340000000
  %3022 = call float @dx.op.unary.f32(i32 21, float %3019)  ; Exp(value)
  %3023 = call float @dx.op.unary.f32(i32 21, float %3020)  ; Exp(value)
  %3024 = call float @dx.op.unary.f32(i32 21, float %3021)  ; Exp(value)
  %3025 = fsub fast float %3007, %3022
  %3026 = fsub fast float %3008, %3023
  %3027 = fsub fast float %3009, %3024
  %3028 = fmul fast float %3025, %3004
  %3029 = fmul fast float %3026, %3005
  %3030 = fmul fast float %3027, %3006
  %3031 = fadd fast float %3028, %3022
  %3032 = fadd fast float %3029, %3023
  %3033 = fadd fast float %3030, %3024
  br label %3249

; <label>:3034                                    ; preds = %2989
  %3035 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2992, i32 %2993, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3036 = extractvalue %dx.types.ResRet.f32 %3035, 0
  %3037 = fcmp fast ogt float %38, 5.000000e-01
  %3038 = fcmp fast olt float %3036, 1.000000e+00
  %3039 = and i1 %3037, %3038
  br i1 %3039, label %3040, label %3178

; <label>:3040                                    ; preds = %3034
  %3041 = sitofp i32 %2992 to float
  %3042 = sitofp i32 %2993 to float
  %3043 = fadd fast float %3041, 5.000000e-01
  %3044 = fadd fast float %3042, 5.000000e-01
  %3045 = fdiv fast float %3043, %45
  %3046 = fdiv fast float %3044, %46
  %3047 = fmul fast float %3045, 2.000000e+00
  %3048 = fmul fast float %3046, 2.000000e+00
  %3049 = fadd fast float %3047, -1.000000e+00
  %3050 = fsub fast float 1.000000e+00, %3048
  %3051 = fmul fast float %3049, %35
  %3052 = call float @dx.op.tertiary.f32(i32 46, float %3050, float %31, float %3051)  ; FMad(a,b,c)
  %3053 = call float @dx.op.tertiary.f32(i32 46, float %3036, float %27, float %3052)  ; FMad(a,b,c)
  %3054 = fadd fast float %3053, %23
  %3055 = call float @dx.op.unary.f32(i32 6, float %3054)  ; FAbs(value)
  %3056 = fcmp fast ogt float %3055, 0x3EB0C6F7A0000000
  br i1 %3056, label %3057, label %3178

; <label>:3057                                    ; preds = %3040
  %3058 = fmul fast float %3049, %34
  %3059 = call float @dx.op.tertiary.f32(i32 46, float %3050, float %30, float %3058)  ; FMad(a,b,c)
  %3060 = call float @dx.op.tertiary.f32(i32 46, float %3036, float %26, float %3059)  ; FMad(a,b,c)
  %3061 = fadd fast float %3060, %22
  %3062 = fmul fast float %3049, %33
  %3063 = call float @dx.op.tertiary.f32(i32 46, float %3050, float %29, float %3062)  ; FMad(a,b,c)
  %3064 = call float @dx.op.tertiary.f32(i32 46, float %3036, float %25, float %3063)  ; FMad(a,b,c)
  %3065 = fadd fast float %3064, %21
  %3066 = fmul fast float %3049, %32
  %3067 = call float @dx.op.tertiary.f32(i32 46, float %3050, float %28, float %3066)  ; FMad(a,b,c)
  %3068 = call float @dx.op.tertiary.f32(i32 46, float %3036, float %24, float %3067)  ; FMad(a,b,c)
  %3069 = fadd fast float %3068, %20
  %3070 = fdiv fast float %3069, %3054
  %3071 = fdiv fast float %3065, %3054
  %3072 = fdiv fast float %3061, %3054
  %3073 = fsub fast float %3070, %17
  %3074 = fsub fast float %3071, %18
  %3075 = fsub fast float %3072, %19
  %3076 = fmul fast float %3073, %3073
  %3077 = fmul fast float %3074, %3074
  %3078 = fadd fast float %3077, %3076
  %3079 = fmul fast float %3075, %3075
  %3080 = fadd fast float %3078, %3079
  %3081 = call float @dx.op.unary.f32(i32 24, float %3080)  ; Sqrt(value)
  %3082 = fsub fast float %3081, %9
  %3083 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3082)  ; FMax(a,b)
  %3084 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %3084, label %3085, label %3108

; <label>:3085                                    ; preds = %3057
  %3086 = call float @dx.op.unary.f32(i32 6, float %3074)  ; FAbs(value)
  %3087 = fmul fast float %3086, %11
  %3088 = fcmp fast olt float %3087, 0x3F50624DE0000000
  br i1 %3088, label %3089, label %3092

; <label>:3089                                    ; preds = %3085
  %3090 = fmul fast float %3087, 5.000000e-01
  %3091 = fsub fast float 1.000000e+00, %3090
  br label %3097

; <label>:3092                                    ; preds = %3085
  %3093 = fmul fast float %3087, 0xBFF7154760000000
  %3094 = call float @dx.op.unary.f32(i32 21, float %3093)  ; Exp(value)
  %3095 = fsub fast float 1.000000e+00, %3094
  %3096 = fdiv fast float %3095, %3087
  br label %3097

; <label>:3097                                    ; preds = %3092, %3089
  %3098 = phi float [ %3091, %3089 ], [ %3096, %3092 ]
  %3099 = call float @dx.op.binary.f32(i32 36, float %3071, float %18)  ; FMin(a,b)
  %3100 = fsub fast float %3099, %10
  %3101 = fmul fast float %11, %3100
  %3102 = fsub fast float -0.000000e+00, %3101
  %3103 = call float @dx.op.binary.f32(i32 35, float %3102, float -4.000000e+01)  ; FMax(a,b)
  %3104 = call float @dx.op.binary.f32(i32 36, float %3103, float 5.000000e+00)  ; FMin(a,b)
  %3105 = fmul fast float %3104, 0x3FF7154760000000
  %3106 = call float @dx.op.unary.f32(i32 21, float %3105)  ; Exp(value)
  %3107 = fmul fast float %3106, %3098
  br label %3108

; <label>:3108                                    ; preds = %3097, %3057
  %3109 = phi float [ %3107, %3097 ], [ 1.000000e+00, %3057 ]
  %3110 = fmul fast float %3083, %16
  %3111 = fmul fast float %3110, %3109
  %3112 = fcmp fast ole float %3081, %9
  %3113 = fcmp fast olt float %3081, 0x3F1A36E2E0000000
  %3114 = or i1 %3112, %3113
  br i1 %3114, label %3161, label %3115

; <label>:3115                                    ; preds = %3108
  %3116 = fdiv fast float %9, %3081
  %3117 = fmul fast float %3116, %3073
  %3118 = fmul fast float %3116, %3074
  %3119 = fmul fast float %3116, %3075
  %3120 = fadd fast float %3117, %17
  %3121 = fadd fast float %3118, %18
  %3122 = fadd fast float %3119, %19
  %3123 = fadd fast float %3120, -9.000000e+02
  %3124 = fadd fast float %3121, -1.500000e+01
  %3125 = fadd fast float %3122, -7.500000e+02
  %3126 = fmul fast float %3123, 0x3F62345680000000
  %3127 = fmul fast float %3124, 0x3F62345680000000
  %3128 = fmul fast float %3125, 0x3F62345680000000
  %3129 = call float @dx.op.dot3.f32(i32 55, float %3126, float %3127, float %3128, float %3126, float %3127, float %3128)  ; Dot3(ax,ay,az,bx,by,bz)
  %3130 = fsub fast float 1.000000e+00, %3129
  %3131 = call float @dx.op.unary.f32(i32 7, float %3130)  ; Saturate(value)
  %3132 = fmul fast float %3131, %3131
  %3133 = fadd fast float %3120, %3070
  %3134 = fadd fast float %3121, %3071
  %3135 = fadd fast float %3122, %3072
  %3136 = fmul fast float %3133, 0x3F52345680000000
  %3137 = fadd fast float %3136, -2.000000e+00
  %3138 = fmul fast float %3134, 0x3F52345680000000
  %3139 = fadd fast float %3138, 0xBFA1111120000000
  %3140 = fmul fast float %3135, 0x3F52345680000000
  %3141 = fadd fast float %3140, 0xBFFAAAAAC0000000
  %3142 = call float @dx.op.dot3.f32(i32 55, float %3137, float %3139, float %3141, float %3137, float %3139, float %3141)  ; Dot3(ax,ay,az,bx,by,bz)
  %3143 = fsub fast float 1.000000e+00, %3142
  %3144 = call float @dx.op.unary.f32(i32 7, float %3143)  ; Saturate(value)
  %3145 = fmul fast float %3144, %3144
  %3146 = fmul fast float %3145, 4.000000e+00
  %3147 = fadd fast float %3146, %3132
  %3148 = fadd fast float %3070, -9.000000e+02
  %3149 = fadd fast float %3071, -1.500000e+01
  %3150 = fadd fast float %3072, -7.500000e+02
  %3151 = fmul fast float %3148, 0x3F62345680000000
  %3152 = fmul fast float %3149, 0x3F62345680000000
  %3153 = fmul fast float %3150, 0x3F62345680000000
  %3154 = call float @dx.op.dot3.f32(i32 55, float %3151, float %3152, float %3153, float %3151, float %3152, float %3153)  ; Dot3(ax,ay,az,bx,by,bz)
  %3155 = fsub fast float 1.000000e+00, %3154
  %3156 = call float @dx.op.unary.f32(i32 7, float %3155)  ; Saturate(value)
  %3157 = fmul fast float %3156, %3156
  %3158 = fadd fast float %3147, %3157
  %3159 = fmul fast float %3082, 0x3F25D867E0000000
  %3160 = fmul fast float %3159, %3158
  br label %3161

; <label>:3161                                    ; preds = %3115, %3108
  %3162 = phi float [ %3160, %3115 ], [ 0.000000e+00, %3108 ]
  %3163 = fadd fast float %3162, %3111
  %3164 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3163)  ; FMin(a,b)
  %3165 = fmul fast float %3164, 0xBFF7154760000000
  %3166 = call float @dx.op.unary.f32(i32 21, float %3165)  ; Exp(value)
  %3167 = fsub fast float 1.000000e+00, %3166
  %3168 = call float @dx.op.binary.f32(i32 36, float %12, float %3167)  ; FMin(a,b)
  %3169 = fsub fast float %13, %2995
  %3170 = fsub fast float %14, %2996
  %3171 = fsub fast float %15, %2997
  %3172 = fmul fast float %3168, %3169
  %3173 = fmul fast float %3168, %3170
  %3174 = fmul fast float %3168, %3171
  %3175 = fadd fast float %3172, %2995
  %3176 = fadd fast float %3173, %2996
  %3177 = fadd fast float %3174, %2997
  br label %3178

; <label>:3178                                    ; preds = %3161, %3040, %3034
  %3179 = phi float [ %3175, %3161 ], [ %2995, %3040 ], [ %2995, %3034 ]
  %3180 = phi float [ %3176, %3161 ], [ %2996, %3040 ], [ %2996, %3034 ]
  %3181 = phi float [ %3177, %3161 ], [ %2997, %3040 ], [ %2997, %3034 ]
  %3182 = fadd fast float %5, 1.000000e+00
  %3183 = fadd fast float %6, 1.000000e+00
  %3184 = fsub fast float 1.000000e+00, %5
  %3185 = fmul fast float %36, %3182
  %3186 = fmul fast float %36, %3183
  %3187 = fmul fast float %36, %3184
  %3188 = fmul fast float %3185, %3179
  %3189 = fmul fast float %3186, %3180
  %3190 = fmul fast float %3187, %3181
  %3191 = fcmp fast ult float %37, 5.000000e-01
  br i1 %3191, label %3217, label %3192

; <label>:3192                                    ; preds = %3178
  %3193 = fmul fast float %3188, 0x4004147AE0000000
  %3194 = fmul fast float %3189, 0x4004147AE0000000
  %3195 = fmul fast float %3190, 0x4004147AE0000000
  %3196 = fadd fast float %3193, 0x3F9EB851E0000000
  %3197 = fadd fast float %3194, 0x3F9EB851E0000000
  %3198 = fadd fast float %3195, 0x3F9EB851E0000000
  %3199 = fmul fast float %3196, %3188
  %3200 = fmul fast float %3197, %3189
  %3201 = fmul fast float %3198, %3190
  %3202 = fmul fast float %3188, 0x400370A3E0000000
  %3203 = fmul fast float %3189, 0x400370A3E0000000
  %3204 = fmul fast float %3190, 0x400370A3E0000000
  %3205 = fadd fast float %3202, 0x3FE2E147A0000000
  %3206 = fadd fast float %3203, 0x3FE2E147A0000000
  %3207 = fadd fast float %3204, 0x3FE2E147A0000000
  %3208 = fmul fast float %3205, %3188
  %3209 = fmul fast float %3206, %3189
  %3210 = fmul fast float %3207, %3190
  %3211 = fadd fast float %3208, 0x3FC1EB8520000000
  %3212 = fadd fast float %3209, 0x3FC1EB8520000000
  %3213 = fadd fast float %3210, 0x3FC1EB8520000000
  %3214 = fdiv fast float %3199, %3211
  %3215 = fdiv fast float %3200, %3212
  %3216 = fdiv fast float %3201, %3213
  br label %3217

; <label>:3217                                    ; preds = %3192, %3178
  %3218 = phi float [ %3214, %3192 ], [ %3188, %3178 ]
  %3219 = phi float [ %3215, %3192 ], [ %3189, %3178 ]
  %3220 = phi float [ %3216, %3192 ], [ %3190, %3178 ]
  %3221 = call float @dx.op.unary.f32(i32 7, float %3218)  ; Saturate(value)
  %3222 = call float @dx.op.unary.f32(i32 7, float %3219)  ; Saturate(value)
  %3223 = call float @dx.op.unary.f32(i32 7, float %3220)  ; Saturate(value)
  %3224 = call float @dx.op.dot3.f32(i32 55, float %3221, float %3222, float %3223, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3225 = fsub fast float %3221, %3224
  %3226 = fsub fast float %3222, %3224
  %3227 = fsub fast float %3223, %3224
  %3228 = fmul fast float %3225, %8
  %3229 = fmul fast float %3226, %8
  %3230 = fmul fast float %3227, %8
  %3231 = fadd fast float %3228, %3224
  %3232 = fadd fast float %3229, %3224
  %3233 = fadd fast float %3230, %3224
  %3234 = call float @dx.op.unary.f32(i32 7, float %3231)  ; Saturate(value)
  %3235 = call float @dx.op.unary.f32(i32 7, float %3232)  ; Saturate(value)
  %3236 = call float @dx.op.unary.f32(i32 7, float %3233)  ; Saturate(value)
  %3237 = fadd fast float %3234, 0xBFC70A3D80000000
  %3238 = fadd fast float %3235, 0xBFC70A3D80000000
  %3239 = fadd fast float %3236, 0xBFC70A3D80000000
  %3240 = fmul fast float %3237, %7
  %3241 = fmul fast float %3238, %7
  %3242 = fmul fast float %3239, %7
  %3243 = fadd fast float %3240, 0x3FC70A3D80000000
  %3244 = fadd fast float %3241, 0x3FC70A3D80000000
  %3245 = fadd fast float %3242, 0x3FC70A3D80000000
  %3246 = call float @dx.op.unary.f32(i32 7, float %3243)  ; Saturate(value)
  %3247 = call float @dx.op.unary.f32(i32 7, float %3244)  ; Saturate(value)
  %3248 = call float @dx.op.unary.f32(i32 7, float %3245)  ; Saturate(value)
  br label %3249

; <label>:3249                                    ; preds = %3217, %3000
  %3250 = phi float [ %3031, %3000 ], [ %3246, %3217 ]
  %3251 = phi float [ %3032, %3000 ], [ %3247, %3217 ]
  %3252 = phi float [ %3033, %3000 ], [ %3248, %3217 ]
  %3253 = fsub fast float %3250, %954
  %3254 = fsub fast float %3251, %955
  %3255 = fsub fast float %3252, %956
  %3256 = fmul fast float %3253, %2987
  %3257 = fmul fast float %3254, %2987
  %3258 = fmul fast float %3255, %2987
  %3259 = fadd fast float %3256, %954
  %3260 = fadd fast float %3257, %955
  %3261 = fadd fast float %3258, %956
  br label %3262

; <label>:3262                                    ; preds = %3249, %2974
  %3263 = phi float [ %3259, %3249 ], [ %954, %2974 ]
  %3264 = phi float [ %3260, %3249 ], [ %955, %2974 ]
  %3265 = phi float [ %3261, %3249 ], [ %956, %2974 ]
  %3266 = fsub fast float %82, %86
  %3267 = call float @dx.op.unary.f32(i32 6, float %3266)  ; FAbs(value)
  %3268 = fdiv fast float %3267, %2669
  %3269 = fsub fast float 1.000000e+00, %3268
  %3270 = call float @dx.op.unary.f32(i32 7, float %3269)  ; Saturate(value)
  %3271 = fcmp fast ugt float %3270, 0.000000e+00
  br i1 %3271, label %3272, label %3282

; <label>:3272                                    ; preds = %3262
  %3273 = fsub fast float %446, %954
  %3274 = fsub fast float %447, %955
  %3275 = fsub fast float %448, %956
  %3276 = fmul fast float %3270, %3273
  %3277 = fmul fast float %3270, %3274
  %3278 = fmul fast float %3270, %3275
  %3279 = fadd fast float %3276, %954
  %3280 = fadd fast float %3277, %955
  %3281 = fadd fast float %3278, %956
  br label %3282

; <label>:3282                                    ; preds = %3272, %3262
  %3283 = phi float [ %3279, %3272 ], [ %954, %3262 ]
  %3284 = phi float [ %3280, %3272 ], [ %955, %3262 ]
  %3285 = phi float [ %3281, %3272 ], [ %956, %3262 ]
  %3286 = call float @dx.op.binary.f32(i32 36, float %2975, float %2687)  ; FMin(a,b)
  %3287 = call float @dx.op.binary.f32(i32 36, float %2976, float %2688)  ; FMin(a,b)
  %3288 = call float @dx.op.binary.f32(i32 36, float %2977, float %2689)  ; FMin(a,b)
  %3289 = call float @dx.op.binary.f32(i32 36, float %3283, float %3263)  ; FMin(a,b)
  %3290 = call float @dx.op.binary.f32(i32 36, float %3284, float %3264)  ; FMin(a,b)
  %3291 = call float @dx.op.binary.f32(i32 36, float %3285, float %3265)  ; FMin(a,b)
  %3292 = call float @dx.op.binary.f32(i32 36, float %3289, float %3286)  ; FMin(a,b)
  %3293 = call float @dx.op.binary.f32(i32 36, float %3290, float %3287)  ; FMin(a,b)
  %3294 = call float @dx.op.binary.f32(i32 36, float %3291, float %3288)  ; FMin(a,b)
  %3295 = call float @dx.op.binary.f32(i32 36, float %954, float %3292)  ; FMin(a,b)
  %3296 = call float @dx.op.binary.f32(i32 36, float %955, float %3293)  ; FMin(a,b)
  %3297 = call float @dx.op.binary.f32(i32 36, float %956, float %3294)  ; FMin(a,b)
  %3298 = call float @dx.op.binary.f32(i32 35, float %2975, float %2687)  ; FMax(a,b)
  %3299 = call float @dx.op.binary.f32(i32 35, float %2976, float %2688)  ; FMax(a,b)
  %3300 = call float @dx.op.binary.f32(i32 35, float %2977, float %2689)  ; FMax(a,b)
  %3301 = call float @dx.op.binary.f32(i32 35, float %3283, float %3263)  ; FMax(a,b)
  %3302 = call float @dx.op.binary.f32(i32 35, float %3284, float %3264)  ; FMax(a,b)
  %3303 = call float @dx.op.binary.f32(i32 35, float %3285, float %3265)  ; FMax(a,b)
  %3304 = call float @dx.op.binary.f32(i32 35, float %3301, float %3298)  ; FMax(a,b)
  %3305 = call float @dx.op.binary.f32(i32 35, float %3302, float %3299)  ; FMax(a,b)
  %3306 = call float @dx.op.binary.f32(i32 35, float %3303, float %3300)  ; FMax(a,b)
  %3307 = call float @dx.op.binary.f32(i32 35, float %954, float %3304)  ; FMax(a,b)
  %3308 = call float @dx.op.binary.f32(i32 35, float %955, float %3305)  ; FMax(a,b)
  %3309 = call float @dx.op.binary.f32(i32 35, float %956, float %3306)  ; FMax(a,b)
  %3310 = fsub fast float %3307, %3295
  %3311 = fsub fast float %3308, %3296
  %3312 = fsub fast float %3309, %3297
  %3313 = call float @dx.op.unary.f32(i32 6, float %3310)  ; FAbs(value)
  %3314 = call float @dx.op.unary.f32(i32 6, float %3311)  ; FAbs(value)
  %3315 = call float @dx.op.unary.f32(i32 6, float %3312)  ; FAbs(value)
  %3316 = call float @dx.op.binary.f32(i32 35, float %3314, float %3315)  ; FMax(a,b)
  %3317 = call float @dx.op.binary.f32(i32 35, float %3313, float %3316)  ; FMax(a,b)
  %3318 = call float @dx.op.binary.f32(i32 35, float %3308, float %3309)  ; FMax(a,b)
  %3319 = call float @dx.op.binary.f32(i32 35, float %3307, float %3318)  ; FMax(a,b)
  %3320 = fmul fast float %3319, 1.250000e-01
  %3321 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %3320)  ; FMax(a,b)
  %3322 = fcmp fast ogt float %3317, %3321
  br i1 %3322, label %3323, label %3384

; <label>:3323                                    ; preds = %3282
  %3324 = fsub fast float %3283, %3263
  %3325 = fsub fast float %3284, %3264
  %3326 = fsub fast float %3285, %3265
  %3327 = call float @dx.op.unary.f32(i32 6, float %3324)  ; FAbs(value)
  %3328 = call float @dx.op.unary.f32(i32 6, float %3325)  ; FAbs(value)
  %3329 = call float @dx.op.unary.f32(i32 6, float %3326)  ; FAbs(value)
  %3330 = call float @dx.op.binary.f32(i32 35, float %3328, float %3329)  ; FMax(a,b)
  %3331 = call float @dx.op.binary.f32(i32 35, float %3327, float %3330)  ; FMax(a,b)
  %3332 = fsub fast float %2975, %2687
  %3333 = fsub fast float %2976, %2688
  %3334 = fsub fast float %2977, %2689
  %3335 = call float @dx.op.unary.f32(i32 6, float %3332)  ; FAbs(value)
  %3336 = call float @dx.op.unary.f32(i32 6, float %3333)  ; FAbs(value)
  %3337 = call float @dx.op.unary.f32(i32 6, float %3334)  ; FAbs(value)
  %3338 = call float @dx.op.binary.f32(i32 35, float %3336, float %3337)  ; FMax(a,b)
  %3339 = call float @dx.op.binary.f32(i32 35, float %3335, float %3338)  ; FMax(a,b)
  %3340 = fcmp fast olt float %3331, %3339
  %3341 = select i1 %3340, float %3283, float %2975
  %3342 = select i1 %3340, float %3284, float %2976
  %3343 = select i1 %3340, float %3285, float %2977
  %3344 = select i1 %3340, float %3263, float %2687
  %3345 = select i1 %3340, float %3264, float %2688
  %3346 = select i1 %3340, float %3265, float %2689
  %3347 = fsub fast float %954, %3344
  %3348 = fsub fast float %955, %3345
  %3349 = fsub fast float %956, %3346
  %3350 = fsub fast float %954, %3341
  %3351 = fsub fast float %955, %3342
  %3352 = fsub fast float %956, %3343
  %3353 = call float @dx.op.dot3.f32(i32 55, float %3350, float %3351, float %3352, float %3347, float %3348, float %3349)  ; Dot3(ax,ay,az,bx,by,bz)
  %3354 = fcmp fast ogt float %3353, 0.000000e+00
  br i1 %3354, label %3355, label %3366

; <label>:3355                                    ; preds = %3323
  %3356 = fsub fast float %3341, %3344
  %3357 = fsub fast float %3342, %3345
  %3358 = fsub fast float %3343, %3346
  %3359 = call float @dx.op.unary.f32(i32 6, float %3356)  ; FAbs(value)
  %3360 = call float @dx.op.unary.f32(i32 6, float %3357)  ; FAbs(value)
  %3361 = call float @dx.op.unary.f32(i32 6, float %3358)  ; FAbs(value)
  %3362 = call float @dx.op.binary.f32(i32 35, float %3360, float %3361)  ; FMax(a,b)
  %3363 = call float @dx.op.binary.f32(i32 35, float %3359, float %3362)  ; FMax(a,b)
  %3364 = fmul fast float %3317, 2.500000e-01
  %3365 = fcmp fast olt float %3363, %3364
  br label %3366

; <label>:3366                                    ; preds = %3355, %3323
  %3367 = phi i1 [ false, %3323 ], [ %3365, %3355 ]
  %3368 = select i1 %3367, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  %3369 = fadd fast float %3341, %3344
  %3370 = fadd fast float %3342, %3345
  %3371 = fadd fast float %3343, %3346
  %3372 = fmul fast float %3369, 5.000000e-01
  %3373 = fmul fast float %3370, 5.000000e-01
  %3374 = fmul fast float %3371, 5.000000e-01
  %3375 = fsub fast float %3372, %954
  %3376 = fsub fast float %3373, %955
  %3377 = fsub fast float %3374, %956
  %3378 = fmul fast float %3368, %3375
  %3379 = fmul fast float %3368, %3376
  %3380 = fmul fast float %3368, %3377
  %3381 = fadd fast float %3378, %954
  %3382 = fadd fast float %3379, %955
  %3383 = fadd fast float %3380, %956
  br label %3384

; <label>:3384                                    ; preds = %3366, %3282, %2661
  %3385 = phi float [ %954, %2661 ], [ %3381, %3366 ], [ %954, %3282 ]
  %3386 = phi float [ %955, %2661 ], [ %3382, %3366 ], [ %955, %3282 ]
  %3387 = phi float [ %956, %2661 ], [ %3383, %3366 ], [ %956, %3282 ]
  %3388 = fcmp fast ult float %194, 0.000000e+00
  br i1 %3388, label %10167, label %3389

; <label>:3389                                    ; preds = %3384
  %3390 = add i32 %55, 2
  %3391 = call i32 @dx.op.binary.i32(i32 37, i32 %3390, i32 0)  ; IMax(a,b)
  %3392 = call i32 @dx.op.binary.i32(i32 38, i32 %3391, i32 %59)  ; IMin(a,b)
  %3393 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3392, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3394 = extractvalue %dx.types.ResRet.f32 %3393, 0
  %3395 = fsub fast float 1.000000e+00, %88
  %3396 = fmul fast float %3395, 0x3FA99999A0000000
  %3397 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %3396)  ; FMax(a,b)
  %3398 = fsub fast float %3394, %88
  %3399 = call float @dx.op.unary.f32(i32 6, float %3398)  ; FAbs(value)
  %3400 = fdiv fast float %3399, %3397
  %3401 = fsub fast float 1.000000e+00, %3400
  %3402 = call float @dx.op.unary.f32(i32 7, float %3401)  ; Saturate(value)
  %3403 = fcmp fast ugt float %3402, 0.000000e+00
  br i1 %3403, label %3404, label %3677

; <label>:3404                                    ; preds = %3389
  %3405 = call i32 @dx.op.binary.i32(i32 37, i32 %3392, i32 0)  ; IMax(a,b)
  %3406 = call i32 @dx.op.binary.i32(i32 37, i32 %70, i32 0)  ; IMax(a,b)
  %3407 = call i32 @dx.op.binary.i32(i32 38, i32 %3405, i32 %59)  ; IMin(a,b)
  %3408 = call i32 @dx.op.binary.i32(i32 38, i32 %3406, i32 %60)  ; IMin(a,b)
  %3409 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3407, i32 %3408, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3410 = extractvalue %dx.types.ResRet.f32 %3409, 0
  %3411 = extractvalue %dx.types.ResRet.f32 %3409, 1
  %3412 = extractvalue %dx.types.ResRet.f32 %3409, 2
  %3413 = extractvalue %dx.types.ResRet.f32 %3409, 3
  %3414 = fcmp fast olt float %3413, 0.000000e+00
  br i1 %3414, label %3415, label %3449

; <label>:3415                                    ; preds = %3404
  %3416 = fcmp fast ogt float %3410, 0x3FA4B5DCC0000000
  %3417 = fcmp fast ogt float %3411, 0x3FA4B5DCC0000000
  %3418 = fcmp fast ogt float %3412, 0x3FA4B5DCC0000000
  %3419 = select i1 %3416, float 0.000000e+00, float 1.000000e+00
  %3420 = select i1 %3417, float 0.000000e+00, float 1.000000e+00
  %3421 = select i1 %3418, float 0.000000e+00, float 1.000000e+00
  %3422 = fmul fast float %3410, 0x3FB3D07220000000
  %3423 = fmul fast float %3411, 0x3FB3D07220000000
  %3424 = fmul fast float %3412, 0x3FB3D07220000000
  %3425 = fadd fast float %3410, 0x3FAC28F5C0000000
  %3426 = fadd fast float %3411, 0x3FAC28F5C0000000
  %3427 = fadd fast float %3412, 0x3FAC28F5C0000000
  %3428 = fmul fast float %3425, 0x3FEE54EDE0000000
  %3429 = fmul fast float %3426, 0x3FEE54EDE0000000
  %3430 = fmul fast float %3427, 0x3FEE54EDE0000000
  %3431 = call float @dx.op.unary.f32(i32 23, float %3428)  ; Log(value)
  %3432 = call float @dx.op.unary.f32(i32 23, float %3429)  ; Log(value)
  %3433 = call float @dx.op.unary.f32(i32 23, float %3430)  ; Log(value)
  %3434 = fmul fast float %3431, 0x4003333340000000
  %3435 = fmul fast float %3432, 0x4003333340000000
  %3436 = fmul fast float %3433, 0x4003333340000000
  %3437 = call float @dx.op.unary.f32(i32 21, float %3434)  ; Exp(value)
  %3438 = call float @dx.op.unary.f32(i32 21, float %3435)  ; Exp(value)
  %3439 = call float @dx.op.unary.f32(i32 21, float %3436)  ; Exp(value)
  %3440 = fsub fast float %3422, %3437
  %3441 = fsub fast float %3423, %3438
  %3442 = fsub fast float %3424, %3439
  %3443 = fmul fast float %3440, %3419
  %3444 = fmul fast float %3441, %3420
  %3445 = fmul fast float %3442, %3421
  %3446 = fadd fast float %3443, %3437
  %3447 = fadd fast float %3444, %3438
  %3448 = fadd fast float %3445, %3439
  br label %3664

; <label>:3449                                    ; preds = %3404
  %3450 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3407, i32 %3408, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3451 = extractvalue %dx.types.ResRet.f32 %3450, 0
  %3452 = fcmp fast ogt float %38, 5.000000e-01
  %3453 = fcmp fast olt float %3451, 1.000000e+00
  %3454 = and i1 %3452, %3453
  br i1 %3454, label %3455, label %3593

; <label>:3455                                    ; preds = %3449
  %3456 = sitofp i32 %3407 to float
  %3457 = sitofp i32 %3408 to float
  %3458 = fadd fast float %3456, 5.000000e-01
  %3459 = fadd fast float %3457, 5.000000e-01
  %3460 = fdiv fast float %3458, %45
  %3461 = fdiv fast float %3459, %46
  %3462 = fmul fast float %3460, 2.000000e+00
  %3463 = fmul fast float %3461, 2.000000e+00
  %3464 = fadd fast float %3462, -1.000000e+00
  %3465 = fsub fast float 1.000000e+00, %3463
  %3466 = fmul fast float %3464, %35
  %3467 = call float @dx.op.tertiary.f32(i32 46, float %3465, float %31, float %3466)  ; FMad(a,b,c)
  %3468 = call float @dx.op.tertiary.f32(i32 46, float %3451, float %27, float %3467)  ; FMad(a,b,c)
  %3469 = fadd fast float %3468, %23
  %3470 = call float @dx.op.unary.f32(i32 6, float %3469)  ; FAbs(value)
  %3471 = fcmp fast ogt float %3470, 0x3EB0C6F7A0000000
  br i1 %3471, label %3472, label %3593

; <label>:3472                                    ; preds = %3455
  %3473 = fmul fast float %3464, %34
  %3474 = call float @dx.op.tertiary.f32(i32 46, float %3465, float %30, float %3473)  ; FMad(a,b,c)
  %3475 = call float @dx.op.tertiary.f32(i32 46, float %3451, float %26, float %3474)  ; FMad(a,b,c)
  %3476 = fadd fast float %3475, %22
  %3477 = fmul fast float %3464, %33
  %3478 = call float @dx.op.tertiary.f32(i32 46, float %3465, float %29, float %3477)  ; FMad(a,b,c)
  %3479 = call float @dx.op.tertiary.f32(i32 46, float %3451, float %25, float %3478)  ; FMad(a,b,c)
  %3480 = fadd fast float %3479, %21
  %3481 = fmul fast float %3464, %32
  %3482 = call float @dx.op.tertiary.f32(i32 46, float %3465, float %28, float %3481)  ; FMad(a,b,c)
  %3483 = call float @dx.op.tertiary.f32(i32 46, float %3451, float %24, float %3482)  ; FMad(a,b,c)
  %3484 = fadd fast float %3483, %20
  %3485 = fdiv fast float %3484, %3469
  %3486 = fdiv fast float %3480, %3469
  %3487 = fdiv fast float %3476, %3469
  %3488 = fsub fast float %3485, %17
  %3489 = fsub fast float %3486, %18
  %3490 = fsub fast float %3487, %19
  %3491 = fmul fast float %3488, %3488
  %3492 = fmul fast float %3489, %3489
  %3493 = fadd fast float %3492, %3491
  %3494 = fmul fast float %3490, %3490
  %3495 = fadd fast float %3493, %3494
  %3496 = call float @dx.op.unary.f32(i32 24, float %3495)  ; Sqrt(value)
  %3497 = fsub fast float %3496, %9
  %3498 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3497)  ; FMax(a,b)
  %3499 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %3499, label %3500, label %3523

; <label>:3500                                    ; preds = %3472
  %3501 = call float @dx.op.unary.f32(i32 6, float %3489)  ; FAbs(value)
  %3502 = fmul fast float %3501, %11
  %3503 = fcmp fast olt float %3502, 0x3F50624DE0000000
  br i1 %3503, label %3504, label %3507

; <label>:3504                                    ; preds = %3500
  %3505 = fmul fast float %3502, 5.000000e-01
  %3506 = fsub fast float 1.000000e+00, %3505
  br label %3512

; <label>:3507                                    ; preds = %3500
  %3508 = fmul fast float %3502, 0xBFF7154760000000
  %3509 = call float @dx.op.unary.f32(i32 21, float %3508)  ; Exp(value)
  %3510 = fsub fast float 1.000000e+00, %3509
  %3511 = fdiv fast float %3510, %3502
  br label %3512

; <label>:3512                                    ; preds = %3507, %3504
  %3513 = phi float [ %3506, %3504 ], [ %3511, %3507 ]
  %3514 = call float @dx.op.binary.f32(i32 36, float %3486, float %18)  ; FMin(a,b)
  %3515 = fsub fast float %3514, %10
  %3516 = fmul fast float %11, %3515
  %3517 = fsub fast float -0.000000e+00, %3516
  %3518 = call float @dx.op.binary.f32(i32 35, float %3517, float -4.000000e+01)  ; FMax(a,b)
  %3519 = call float @dx.op.binary.f32(i32 36, float %3518, float 5.000000e+00)  ; FMin(a,b)
  %3520 = fmul fast float %3519, 0x3FF7154760000000
  %3521 = call float @dx.op.unary.f32(i32 21, float %3520)  ; Exp(value)
  %3522 = fmul fast float %3521, %3513
  br label %3523

; <label>:3523                                    ; preds = %3512, %3472
  %3524 = phi float [ %3522, %3512 ], [ 1.000000e+00, %3472 ]
  %3525 = fmul fast float %3498, %16
  %3526 = fmul fast float %3525, %3524
  %3527 = fcmp fast ole float %3496, %9
  %3528 = fcmp fast olt float %3496, 0x3F1A36E2E0000000
  %3529 = or i1 %3527, %3528
  br i1 %3529, label %3576, label %3530

; <label>:3530                                    ; preds = %3523
  %3531 = fdiv fast float %9, %3496
  %3532 = fmul fast float %3531, %3488
  %3533 = fmul fast float %3531, %3489
  %3534 = fmul fast float %3531, %3490
  %3535 = fadd fast float %3532, %17
  %3536 = fadd fast float %3533, %18
  %3537 = fadd fast float %3534, %19
  %3538 = fadd fast float %3535, -9.000000e+02
  %3539 = fadd fast float %3536, -1.500000e+01
  %3540 = fadd fast float %3537, -7.500000e+02
  %3541 = fmul fast float %3538, 0x3F62345680000000
  %3542 = fmul fast float %3539, 0x3F62345680000000
  %3543 = fmul fast float %3540, 0x3F62345680000000
  %3544 = call float @dx.op.dot3.f32(i32 55, float %3541, float %3542, float %3543, float %3541, float %3542, float %3543)  ; Dot3(ax,ay,az,bx,by,bz)
  %3545 = fsub fast float 1.000000e+00, %3544
  %3546 = call float @dx.op.unary.f32(i32 7, float %3545)  ; Saturate(value)
  %3547 = fmul fast float %3546, %3546
  %3548 = fadd fast float %3535, %3485
  %3549 = fadd fast float %3536, %3486
  %3550 = fadd fast float %3537, %3487
  %3551 = fmul fast float %3548, 0x3F52345680000000
  %3552 = fadd fast float %3551, -2.000000e+00
  %3553 = fmul fast float %3549, 0x3F52345680000000
  %3554 = fadd fast float %3553, 0xBFA1111120000000
  %3555 = fmul fast float %3550, 0x3F52345680000000
  %3556 = fadd fast float %3555, 0xBFFAAAAAC0000000
  %3557 = call float @dx.op.dot3.f32(i32 55, float %3552, float %3554, float %3556, float %3552, float %3554, float %3556)  ; Dot3(ax,ay,az,bx,by,bz)
  %3558 = fsub fast float 1.000000e+00, %3557
  %3559 = call float @dx.op.unary.f32(i32 7, float %3558)  ; Saturate(value)
  %3560 = fmul fast float %3559, %3559
  %3561 = fmul fast float %3560, 4.000000e+00
  %3562 = fadd fast float %3561, %3547
  %3563 = fadd fast float %3485, -9.000000e+02
  %3564 = fadd fast float %3486, -1.500000e+01
  %3565 = fadd fast float %3487, -7.500000e+02
  %3566 = fmul fast float %3563, 0x3F62345680000000
  %3567 = fmul fast float %3564, 0x3F62345680000000
  %3568 = fmul fast float %3565, 0x3F62345680000000
  %3569 = call float @dx.op.dot3.f32(i32 55, float %3566, float %3567, float %3568, float %3566, float %3567, float %3568)  ; Dot3(ax,ay,az,bx,by,bz)
  %3570 = fsub fast float 1.000000e+00, %3569
  %3571 = call float @dx.op.unary.f32(i32 7, float %3570)  ; Saturate(value)
  %3572 = fmul fast float %3571, %3571
  %3573 = fadd fast float %3562, %3572
  %3574 = fmul fast float %3497, 0x3F25D867E0000000
  %3575 = fmul fast float %3574, %3573
  br label %3576

; <label>:3576                                    ; preds = %3530, %3523
  %3577 = phi float [ %3575, %3530 ], [ 0.000000e+00, %3523 ]
  %3578 = fadd fast float %3577, %3526
  %3579 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3578)  ; FMin(a,b)
  %3580 = fmul fast float %3579, 0xBFF7154760000000
  %3581 = call float @dx.op.unary.f32(i32 21, float %3580)  ; Exp(value)
  %3582 = fsub fast float 1.000000e+00, %3581
  %3583 = call float @dx.op.binary.f32(i32 36, float %12, float %3582)  ; FMin(a,b)
  %3584 = fsub fast float %13, %3410
  %3585 = fsub fast float %14, %3411
  %3586 = fsub fast float %15, %3412
  %3587 = fmul fast float %3583, %3584
  %3588 = fmul fast float %3583, %3585
  %3589 = fmul fast float %3583, %3586
  %3590 = fadd fast float %3587, %3410
  %3591 = fadd fast float %3588, %3411
  %3592 = fadd fast float %3589, %3412
  br label %3593

; <label>:3593                                    ; preds = %3576, %3455, %3449
  %3594 = phi float [ %3590, %3576 ], [ %3410, %3455 ], [ %3410, %3449 ]
  %3595 = phi float [ %3591, %3576 ], [ %3411, %3455 ], [ %3411, %3449 ]
  %3596 = phi float [ %3592, %3576 ], [ %3412, %3455 ], [ %3412, %3449 ]
  %3597 = fadd fast float %5, 1.000000e+00
  %3598 = fadd fast float %6, 1.000000e+00
  %3599 = fsub fast float 1.000000e+00, %5
  %3600 = fmul fast float %36, %3597
  %3601 = fmul fast float %36, %3598
  %3602 = fmul fast float %36, %3599
  %3603 = fmul fast float %3600, %3594
  %3604 = fmul fast float %3601, %3595
  %3605 = fmul fast float %3602, %3596
  %3606 = fcmp fast ult float %37, 5.000000e-01
  br i1 %3606, label %3632, label %3607

; <label>:3607                                    ; preds = %3593
  %3608 = fmul fast float %3603, 0x4004147AE0000000
  %3609 = fmul fast float %3604, 0x4004147AE0000000
  %3610 = fmul fast float %3605, 0x4004147AE0000000
  %3611 = fadd fast float %3608, 0x3F9EB851E0000000
  %3612 = fadd fast float %3609, 0x3F9EB851E0000000
  %3613 = fadd fast float %3610, 0x3F9EB851E0000000
  %3614 = fmul fast float %3611, %3603
  %3615 = fmul fast float %3612, %3604
  %3616 = fmul fast float %3613, %3605
  %3617 = fmul fast float %3603, 0x400370A3E0000000
  %3618 = fmul fast float %3604, 0x400370A3E0000000
  %3619 = fmul fast float %3605, 0x400370A3E0000000
  %3620 = fadd fast float %3617, 0x3FE2E147A0000000
  %3621 = fadd fast float %3618, 0x3FE2E147A0000000
  %3622 = fadd fast float %3619, 0x3FE2E147A0000000
  %3623 = fmul fast float %3620, %3603
  %3624 = fmul fast float %3621, %3604
  %3625 = fmul fast float %3622, %3605
  %3626 = fadd fast float %3623, 0x3FC1EB8520000000
  %3627 = fadd fast float %3624, 0x3FC1EB8520000000
  %3628 = fadd fast float %3625, 0x3FC1EB8520000000
  %3629 = fdiv fast float %3614, %3626
  %3630 = fdiv fast float %3615, %3627
  %3631 = fdiv fast float %3616, %3628
  br label %3632

; <label>:3632                                    ; preds = %3607, %3593
  %3633 = phi float [ %3629, %3607 ], [ %3603, %3593 ]
  %3634 = phi float [ %3630, %3607 ], [ %3604, %3593 ]
  %3635 = phi float [ %3631, %3607 ], [ %3605, %3593 ]
  %3636 = call float @dx.op.unary.f32(i32 7, float %3633)  ; Saturate(value)
  %3637 = call float @dx.op.unary.f32(i32 7, float %3634)  ; Saturate(value)
  %3638 = call float @dx.op.unary.f32(i32 7, float %3635)  ; Saturate(value)
  %3639 = call float @dx.op.dot3.f32(i32 55, float %3636, float %3637, float %3638, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3640 = fsub fast float %3636, %3639
  %3641 = fsub fast float %3637, %3639
  %3642 = fsub fast float %3638, %3639
  %3643 = fmul fast float %3640, %8
  %3644 = fmul fast float %3641, %8
  %3645 = fmul fast float %3642, %8
  %3646 = fadd fast float %3643, %3639
  %3647 = fadd fast float %3644, %3639
  %3648 = fadd fast float %3645, %3639
  %3649 = call float @dx.op.unary.f32(i32 7, float %3646)  ; Saturate(value)
  %3650 = call float @dx.op.unary.f32(i32 7, float %3647)  ; Saturate(value)
  %3651 = call float @dx.op.unary.f32(i32 7, float %3648)  ; Saturate(value)
  %3652 = fadd fast float %3649, 0xBFC70A3D80000000
  %3653 = fadd fast float %3650, 0xBFC70A3D80000000
  %3654 = fadd fast float %3651, 0xBFC70A3D80000000
  %3655 = fmul fast float %3652, %7
  %3656 = fmul fast float %3653, %7
  %3657 = fmul fast float %3654, %7
  %3658 = fadd fast float %3655, 0x3FC70A3D80000000
  %3659 = fadd fast float %3656, 0x3FC70A3D80000000
  %3660 = fadd fast float %3657, 0x3FC70A3D80000000
  %3661 = call float @dx.op.unary.f32(i32 7, float %3658)  ; Saturate(value)
  %3662 = call float @dx.op.unary.f32(i32 7, float %3659)  ; Saturate(value)
  %3663 = call float @dx.op.unary.f32(i32 7, float %3660)  ; Saturate(value)
  br label %3664

; <label>:3664                                    ; preds = %3632, %3415
  %3665 = phi float [ %3446, %3415 ], [ %3661, %3632 ]
  %3666 = phi float [ %3447, %3415 ], [ %3662, %3632 ]
  %3667 = phi float [ %3448, %3415 ], [ %3663, %3632 ]
  %3668 = fsub fast float %3665, %1208
  %3669 = fsub fast float %3666, %1209
  %3670 = fsub fast float %3667, %1210
  %3671 = fmul fast float %3668, %3402
  %3672 = fmul fast float %3669, %3402
  %3673 = fmul fast float %3670, %3402
  %3674 = fadd fast float %3671, %1208
  %3675 = fadd fast float %3672, %1209
  %3676 = fadd fast float %3673, %1210
  br label %3677

; <label>:3677                                    ; preds = %3664, %3389
  %3678 = phi float [ %3674, %3664 ], [ %1208, %3389 ]
  %3679 = phi float [ %3675, %3664 ], [ %1209, %3389 ]
  %3680 = phi float [ %3676, %3664 ], [ %1210, %3389 ]
  %3681 = fsub fast float %86, %88
  %3682 = call float @dx.op.unary.f32(i32 6, float %3681)  ; FAbs(value)
  %3683 = fdiv fast float %3682, %3397
  %3684 = fsub fast float 1.000000e+00, %3683
  %3685 = call float @dx.op.unary.f32(i32 7, float %3684)  ; Saturate(value)
  %3686 = fcmp fast ugt float %3685, 0.000000e+00
  br i1 %3686, label %3687, label %3697

; <label>:3687                                    ; preds = %3677
  %3688 = fsub fast float %954, %1208
  %3689 = fsub fast float %955, %1209
  %3690 = fsub fast float %956, %1210
  %3691 = fmul fast float %3685, %3688
  %3692 = fmul fast float %3685, %3689
  %3693 = fmul fast float %3685, %3690
  %3694 = fadd fast float %3691, %1208
  %3695 = fadd fast float %3692, %1209
  %3696 = fadd fast float %3693, %1210
  br label %3697

; <label>:3697                                    ; preds = %3687, %3677
  %3698 = phi float [ %3694, %3687 ], [ %1208, %3677 ]
  %3699 = phi float [ %3695, %3687 ], [ %1209, %3677 ]
  %3700 = phi float [ %3696, %3687 ], [ %1210, %3677 ]
  %3701 = add i32 %56, 2
  %3702 = call i32 @dx.op.binary.i32(i32 37, i32 %3701, i32 0)  ; IMax(a,b)
  %3703 = call i32 @dx.op.binary.i32(i32 38, i32 %3702, i32 %60)  ; IMin(a,b)
  %3704 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %67, i32 %3703, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3705 = extractvalue %dx.types.ResRet.f32 %3704, 0
  %3706 = fsub fast float %3705, %88
  %3707 = call float @dx.op.unary.f32(i32 6, float %3706)  ; FAbs(value)
  %3708 = fdiv fast float %3707, %3397
  %3709 = fsub fast float 1.000000e+00, %3708
  %3710 = call float @dx.op.unary.f32(i32 7, float %3709)  ; Saturate(value)
  %3711 = fcmp fast ugt float %3710, 0.000000e+00
  br i1 %3711, label %3712, label %3985

; <label>:3712                                    ; preds = %3697
  %3713 = call i32 @dx.op.binary.i32(i32 37, i32 %67, i32 0)  ; IMax(a,b)
  %3714 = call i32 @dx.op.binary.i32(i32 37, i32 %3703, i32 0)  ; IMax(a,b)
  %3715 = call i32 @dx.op.binary.i32(i32 38, i32 %3713, i32 %59)  ; IMin(a,b)
  %3716 = call i32 @dx.op.binary.i32(i32 38, i32 %3714, i32 %60)  ; IMin(a,b)
  %3717 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3715, i32 %3716, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3718 = extractvalue %dx.types.ResRet.f32 %3717, 0
  %3719 = extractvalue %dx.types.ResRet.f32 %3717, 1
  %3720 = extractvalue %dx.types.ResRet.f32 %3717, 2
  %3721 = extractvalue %dx.types.ResRet.f32 %3717, 3
  %3722 = fcmp fast olt float %3721, 0.000000e+00
  br i1 %3722, label %3723, label %3757

; <label>:3723                                    ; preds = %3712
  %3724 = fcmp fast ogt float %3718, 0x3FA4B5DCC0000000
  %3725 = fcmp fast ogt float %3719, 0x3FA4B5DCC0000000
  %3726 = fcmp fast ogt float %3720, 0x3FA4B5DCC0000000
  %3727 = select i1 %3724, float 0.000000e+00, float 1.000000e+00
  %3728 = select i1 %3725, float 0.000000e+00, float 1.000000e+00
  %3729 = select i1 %3726, float 0.000000e+00, float 1.000000e+00
  %3730 = fmul fast float %3718, 0x3FB3D07220000000
  %3731 = fmul fast float %3719, 0x3FB3D07220000000
  %3732 = fmul fast float %3720, 0x3FB3D07220000000
  %3733 = fadd fast float %3718, 0x3FAC28F5C0000000
  %3734 = fadd fast float %3719, 0x3FAC28F5C0000000
  %3735 = fadd fast float %3720, 0x3FAC28F5C0000000
  %3736 = fmul fast float %3733, 0x3FEE54EDE0000000
  %3737 = fmul fast float %3734, 0x3FEE54EDE0000000
  %3738 = fmul fast float %3735, 0x3FEE54EDE0000000
  %3739 = call float @dx.op.unary.f32(i32 23, float %3736)  ; Log(value)
  %3740 = call float @dx.op.unary.f32(i32 23, float %3737)  ; Log(value)
  %3741 = call float @dx.op.unary.f32(i32 23, float %3738)  ; Log(value)
  %3742 = fmul fast float %3739, 0x4003333340000000
  %3743 = fmul fast float %3740, 0x4003333340000000
  %3744 = fmul fast float %3741, 0x4003333340000000
  %3745 = call float @dx.op.unary.f32(i32 21, float %3742)  ; Exp(value)
  %3746 = call float @dx.op.unary.f32(i32 21, float %3743)  ; Exp(value)
  %3747 = call float @dx.op.unary.f32(i32 21, float %3744)  ; Exp(value)
  %3748 = fsub fast float %3730, %3745
  %3749 = fsub fast float %3731, %3746
  %3750 = fsub fast float %3732, %3747
  %3751 = fmul fast float %3748, %3727
  %3752 = fmul fast float %3749, %3728
  %3753 = fmul fast float %3750, %3729
  %3754 = fadd fast float %3751, %3745
  %3755 = fadd fast float %3752, %3746
  %3756 = fadd fast float %3753, %3747
  br label %3972

; <label>:3757                                    ; preds = %3712
  %3758 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3715, i32 %3716, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3759 = extractvalue %dx.types.ResRet.f32 %3758, 0
  %3760 = fcmp fast ogt float %38, 5.000000e-01
  %3761 = fcmp fast olt float %3759, 1.000000e+00
  %3762 = and i1 %3760, %3761
  br i1 %3762, label %3763, label %3901

; <label>:3763                                    ; preds = %3757
  %3764 = sitofp i32 %3715 to float
  %3765 = sitofp i32 %3716 to float
  %3766 = fadd fast float %3764, 5.000000e-01
  %3767 = fadd fast float %3765, 5.000000e-01
  %3768 = fdiv fast float %3766, %45
  %3769 = fdiv fast float %3767, %46
  %3770 = fmul fast float %3768, 2.000000e+00
  %3771 = fmul fast float %3769, 2.000000e+00
  %3772 = fadd fast float %3770, -1.000000e+00
  %3773 = fsub fast float 1.000000e+00, %3771
  %3774 = fmul fast float %3772, %35
  %3775 = call float @dx.op.tertiary.f32(i32 46, float %3773, float %31, float %3774)  ; FMad(a,b,c)
  %3776 = call float @dx.op.tertiary.f32(i32 46, float %3759, float %27, float %3775)  ; FMad(a,b,c)
  %3777 = fadd fast float %3776, %23
  %3778 = call float @dx.op.unary.f32(i32 6, float %3777)  ; FAbs(value)
  %3779 = fcmp fast ogt float %3778, 0x3EB0C6F7A0000000
  br i1 %3779, label %3780, label %3901

; <label>:3780                                    ; preds = %3763
  %3781 = fmul fast float %3772, %34
  %3782 = call float @dx.op.tertiary.f32(i32 46, float %3773, float %30, float %3781)  ; FMad(a,b,c)
  %3783 = call float @dx.op.tertiary.f32(i32 46, float %3759, float %26, float %3782)  ; FMad(a,b,c)
  %3784 = fadd fast float %3783, %22
  %3785 = fmul fast float %3772, %33
  %3786 = call float @dx.op.tertiary.f32(i32 46, float %3773, float %29, float %3785)  ; FMad(a,b,c)
  %3787 = call float @dx.op.tertiary.f32(i32 46, float %3759, float %25, float %3786)  ; FMad(a,b,c)
  %3788 = fadd fast float %3787, %21
  %3789 = fmul fast float %3772, %32
  %3790 = call float @dx.op.tertiary.f32(i32 46, float %3773, float %28, float %3789)  ; FMad(a,b,c)
  %3791 = call float @dx.op.tertiary.f32(i32 46, float %3759, float %24, float %3790)  ; FMad(a,b,c)
  %3792 = fadd fast float %3791, %20
  %3793 = fdiv fast float %3792, %3777
  %3794 = fdiv fast float %3788, %3777
  %3795 = fdiv fast float %3784, %3777
  %3796 = fsub fast float %3793, %17
  %3797 = fsub fast float %3794, %18
  %3798 = fsub fast float %3795, %19
  %3799 = fmul fast float %3796, %3796
  %3800 = fmul fast float %3797, %3797
  %3801 = fadd fast float %3800, %3799
  %3802 = fmul fast float %3798, %3798
  %3803 = fadd fast float %3801, %3802
  %3804 = call float @dx.op.unary.f32(i32 24, float %3803)  ; Sqrt(value)
  %3805 = fsub fast float %3804, %9
  %3806 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3805)  ; FMax(a,b)
  %3807 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %3807, label %3808, label %3831

; <label>:3808                                    ; preds = %3780
  %3809 = call float @dx.op.unary.f32(i32 6, float %3797)  ; FAbs(value)
  %3810 = fmul fast float %3809, %11
  %3811 = fcmp fast olt float %3810, 0x3F50624DE0000000
  br i1 %3811, label %3812, label %3815

; <label>:3812                                    ; preds = %3808
  %3813 = fmul fast float %3810, 5.000000e-01
  %3814 = fsub fast float 1.000000e+00, %3813
  br label %3820

; <label>:3815                                    ; preds = %3808
  %3816 = fmul fast float %3810, 0xBFF7154760000000
  %3817 = call float @dx.op.unary.f32(i32 21, float %3816)  ; Exp(value)
  %3818 = fsub fast float 1.000000e+00, %3817
  %3819 = fdiv fast float %3818, %3810
  br label %3820

; <label>:3820                                    ; preds = %3815, %3812
  %3821 = phi float [ %3814, %3812 ], [ %3819, %3815 ]
  %3822 = call float @dx.op.binary.f32(i32 36, float %3794, float %18)  ; FMin(a,b)
  %3823 = fsub fast float %3822, %10
  %3824 = fmul fast float %11, %3823
  %3825 = fsub fast float -0.000000e+00, %3824
  %3826 = call float @dx.op.binary.f32(i32 35, float %3825, float -4.000000e+01)  ; FMax(a,b)
  %3827 = call float @dx.op.binary.f32(i32 36, float %3826, float 5.000000e+00)  ; FMin(a,b)
  %3828 = fmul fast float %3827, 0x3FF7154760000000
  %3829 = call float @dx.op.unary.f32(i32 21, float %3828)  ; Exp(value)
  %3830 = fmul fast float %3829, %3821
  br label %3831

; <label>:3831                                    ; preds = %3820, %3780
  %3832 = phi float [ %3830, %3820 ], [ 1.000000e+00, %3780 ]
  %3833 = fmul fast float %3806, %16
  %3834 = fmul fast float %3833, %3832
  %3835 = fcmp fast ole float %3804, %9
  %3836 = fcmp fast olt float %3804, 0x3F1A36E2E0000000
  %3837 = or i1 %3835, %3836
  br i1 %3837, label %3884, label %3838

; <label>:3838                                    ; preds = %3831
  %3839 = fdiv fast float %9, %3804
  %3840 = fmul fast float %3839, %3796
  %3841 = fmul fast float %3839, %3797
  %3842 = fmul fast float %3839, %3798
  %3843 = fadd fast float %3840, %17
  %3844 = fadd fast float %3841, %18
  %3845 = fadd fast float %3842, %19
  %3846 = fadd fast float %3843, -9.000000e+02
  %3847 = fadd fast float %3844, -1.500000e+01
  %3848 = fadd fast float %3845, -7.500000e+02
  %3849 = fmul fast float %3846, 0x3F62345680000000
  %3850 = fmul fast float %3847, 0x3F62345680000000
  %3851 = fmul fast float %3848, 0x3F62345680000000
  %3852 = call float @dx.op.dot3.f32(i32 55, float %3849, float %3850, float %3851, float %3849, float %3850, float %3851)  ; Dot3(ax,ay,az,bx,by,bz)
  %3853 = fsub fast float 1.000000e+00, %3852
  %3854 = call float @dx.op.unary.f32(i32 7, float %3853)  ; Saturate(value)
  %3855 = fmul fast float %3854, %3854
  %3856 = fadd fast float %3843, %3793
  %3857 = fadd fast float %3844, %3794
  %3858 = fadd fast float %3845, %3795
  %3859 = fmul fast float %3856, 0x3F52345680000000
  %3860 = fadd fast float %3859, -2.000000e+00
  %3861 = fmul fast float %3857, 0x3F52345680000000
  %3862 = fadd fast float %3861, 0xBFA1111120000000
  %3863 = fmul fast float %3858, 0x3F52345680000000
  %3864 = fadd fast float %3863, 0xBFFAAAAAC0000000
  %3865 = call float @dx.op.dot3.f32(i32 55, float %3860, float %3862, float %3864, float %3860, float %3862, float %3864)  ; Dot3(ax,ay,az,bx,by,bz)
  %3866 = fsub fast float 1.000000e+00, %3865
  %3867 = call float @dx.op.unary.f32(i32 7, float %3866)  ; Saturate(value)
  %3868 = fmul fast float %3867, %3867
  %3869 = fmul fast float %3868, 4.000000e+00
  %3870 = fadd fast float %3869, %3855
  %3871 = fadd fast float %3793, -9.000000e+02
  %3872 = fadd fast float %3794, -1.500000e+01
  %3873 = fadd fast float %3795, -7.500000e+02
  %3874 = fmul fast float %3871, 0x3F62345680000000
  %3875 = fmul fast float %3872, 0x3F62345680000000
  %3876 = fmul fast float %3873, 0x3F62345680000000
  %3877 = call float @dx.op.dot3.f32(i32 55, float %3874, float %3875, float %3876, float %3874, float %3875, float %3876)  ; Dot3(ax,ay,az,bx,by,bz)
  %3878 = fsub fast float 1.000000e+00, %3877
  %3879 = call float @dx.op.unary.f32(i32 7, float %3878)  ; Saturate(value)
  %3880 = fmul fast float %3879, %3879
  %3881 = fadd fast float %3870, %3880
  %3882 = fmul fast float %3805, 0x3F25D867E0000000
  %3883 = fmul fast float %3882, %3881
  br label %3884

; <label>:3884                                    ; preds = %3838, %3831
  %3885 = phi float [ %3883, %3838 ], [ 0.000000e+00, %3831 ]
  %3886 = fadd fast float %3885, %3834
  %3887 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3886)  ; FMin(a,b)
  %3888 = fmul fast float %3887, 0xBFF7154760000000
  %3889 = call float @dx.op.unary.f32(i32 21, float %3888)  ; Exp(value)
  %3890 = fsub fast float 1.000000e+00, %3889
  %3891 = call float @dx.op.binary.f32(i32 36, float %12, float %3890)  ; FMin(a,b)
  %3892 = fsub fast float %13, %3718
  %3893 = fsub fast float %14, %3719
  %3894 = fsub fast float %15, %3720
  %3895 = fmul fast float %3891, %3892
  %3896 = fmul fast float %3891, %3893
  %3897 = fmul fast float %3891, %3894
  %3898 = fadd fast float %3895, %3718
  %3899 = fadd fast float %3896, %3719
  %3900 = fadd fast float %3897, %3720
  br label %3901

; <label>:3901                                    ; preds = %3884, %3763, %3757
  %3902 = phi float [ %3898, %3884 ], [ %3718, %3763 ], [ %3718, %3757 ]
  %3903 = phi float [ %3899, %3884 ], [ %3719, %3763 ], [ %3719, %3757 ]
  %3904 = phi float [ %3900, %3884 ], [ %3720, %3763 ], [ %3720, %3757 ]
  %3905 = fadd fast float %5, 1.000000e+00
  %3906 = fadd fast float %6, 1.000000e+00
  %3907 = fsub fast float 1.000000e+00, %5
  %3908 = fmul fast float %36, %3905
  %3909 = fmul fast float %36, %3906
  %3910 = fmul fast float %36, %3907
  %3911 = fmul fast float %3908, %3902
  %3912 = fmul fast float %3909, %3903
  %3913 = fmul fast float %3910, %3904
  %3914 = fcmp fast ult float %37, 5.000000e-01
  br i1 %3914, label %3940, label %3915

; <label>:3915                                    ; preds = %3901
  %3916 = fmul fast float %3911, 0x4004147AE0000000
  %3917 = fmul fast float %3912, 0x4004147AE0000000
  %3918 = fmul fast float %3913, 0x4004147AE0000000
  %3919 = fadd fast float %3916, 0x3F9EB851E0000000
  %3920 = fadd fast float %3917, 0x3F9EB851E0000000
  %3921 = fadd fast float %3918, 0x3F9EB851E0000000
  %3922 = fmul fast float %3919, %3911
  %3923 = fmul fast float %3920, %3912
  %3924 = fmul fast float %3921, %3913
  %3925 = fmul fast float %3911, 0x400370A3E0000000
  %3926 = fmul fast float %3912, 0x400370A3E0000000
  %3927 = fmul fast float %3913, 0x400370A3E0000000
  %3928 = fadd fast float %3925, 0x3FE2E147A0000000
  %3929 = fadd fast float %3926, 0x3FE2E147A0000000
  %3930 = fadd fast float %3927, 0x3FE2E147A0000000
  %3931 = fmul fast float %3928, %3911
  %3932 = fmul fast float %3929, %3912
  %3933 = fmul fast float %3930, %3913
  %3934 = fadd fast float %3931, 0x3FC1EB8520000000
  %3935 = fadd fast float %3932, 0x3FC1EB8520000000
  %3936 = fadd fast float %3933, 0x3FC1EB8520000000
  %3937 = fdiv fast float %3922, %3934
  %3938 = fdiv fast float %3923, %3935
  %3939 = fdiv fast float %3924, %3936
  br label %3940

; <label>:3940                                    ; preds = %3915, %3901
  %3941 = phi float [ %3937, %3915 ], [ %3911, %3901 ]
  %3942 = phi float [ %3938, %3915 ], [ %3912, %3901 ]
  %3943 = phi float [ %3939, %3915 ], [ %3913, %3901 ]
  %3944 = call float @dx.op.unary.f32(i32 7, float %3941)  ; Saturate(value)
  %3945 = call float @dx.op.unary.f32(i32 7, float %3942)  ; Saturate(value)
  %3946 = call float @dx.op.unary.f32(i32 7, float %3943)  ; Saturate(value)
  %3947 = call float @dx.op.dot3.f32(i32 55, float %3944, float %3945, float %3946, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3948 = fsub fast float %3944, %3947
  %3949 = fsub fast float %3945, %3947
  %3950 = fsub fast float %3946, %3947
  %3951 = fmul fast float %3948, %8
  %3952 = fmul fast float %3949, %8
  %3953 = fmul fast float %3950, %8
  %3954 = fadd fast float %3951, %3947
  %3955 = fadd fast float %3952, %3947
  %3956 = fadd fast float %3953, %3947
  %3957 = call float @dx.op.unary.f32(i32 7, float %3954)  ; Saturate(value)
  %3958 = call float @dx.op.unary.f32(i32 7, float %3955)  ; Saturate(value)
  %3959 = call float @dx.op.unary.f32(i32 7, float %3956)  ; Saturate(value)
  %3960 = fadd fast float %3957, 0xBFC70A3D80000000
  %3961 = fadd fast float %3958, 0xBFC70A3D80000000
  %3962 = fadd fast float %3959, 0xBFC70A3D80000000
  %3963 = fmul fast float %3960, %7
  %3964 = fmul fast float %3961, %7
  %3965 = fmul fast float %3962, %7
  %3966 = fadd fast float %3963, 0x3FC70A3D80000000
  %3967 = fadd fast float %3964, 0x3FC70A3D80000000
  %3968 = fadd fast float %3965, 0x3FC70A3D80000000
  %3969 = call float @dx.op.unary.f32(i32 7, float %3966)  ; Saturate(value)
  %3970 = call float @dx.op.unary.f32(i32 7, float %3967)  ; Saturate(value)
  %3971 = call float @dx.op.unary.f32(i32 7, float %3968)  ; Saturate(value)
  br label %3972

; <label>:3972                                    ; preds = %3940, %3723
  %3973 = phi float [ %3754, %3723 ], [ %3969, %3940 ]
  %3974 = phi float [ %3755, %3723 ], [ %3970, %3940 ]
  %3975 = phi float [ %3756, %3723 ], [ %3971, %3940 ]
  %3976 = fsub fast float %3973, %1208
  %3977 = fsub fast float %3974, %1209
  %3978 = fsub fast float %3975, %1210
  %3979 = fmul fast float %3976, %3710
  %3980 = fmul fast float %3977, %3710
  %3981 = fmul fast float %3978, %3710
  %3982 = fadd fast float %3979, %1208
  %3983 = fadd fast float %3980, %1209
  %3984 = fadd fast float %3981, %1210
  br label %3985

; <label>:3985                                    ; preds = %3972, %3697
  %3986 = phi float [ %3982, %3972 ], [ %1208, %3697 ]
  %3987 = phi float [ %3983, %3972 ], [ %1209, %3697 ]
  %3988 = phi float [ %3984, %3972 ], [ %1210, %3697 ]
  %3989 = fsub fast float %84, %88
  %3990 = call float @dx.op.unary.f32(i32 6, float %3989)  ; FAbs(value)
  %3991 = fdiv fast float %3990, %3397
  %3992 = fsub fast float 1.000000e+00, %3991
  %3993 = call float @dx.op.unary.f32(i32 7, float %3992)  ; Saturate(value)
  %3994 = fcmp fast ugt float %3993, 0.000000e+00
  br i1 %3994, label %3995, label %4005

; <label>:3995                                    ; preds = %3985
  %3996 = fsub fast float %700, %1208
  %3997 = fsub fast float %701, %1209
  %3998 = fsub fast float %702, %1210
  %3999 = fmul fast float %3993, %3996
  %4000 = fmul fast float %3993, %3997
  %4001 = fmul fast float %3993, %3998
  %4002 = fadd fast float %3999, %1208
  %4003 = fadd fast float %4000, %1209
  %4004 = fadd fast float %4001, %1210
  br label %4005

; <label>:4005                                    ; preds = %3995, %3985
  %4006 = phi float [ %4002, %3995 ], [ %1208, %3985 ]
  %4007 = phi float [ %4003, %3995 ], [ %1209, %3985 ]
  %4008 = phi float [ %4004, %3995 ], [ %1210, %3985 ]
  %4009 = call float @dx.op.binary.f32(i32 36, float %3698, float %3678)  ; FMin(a,b)
  %4010 = call float @dx.op.binary.f32(i32 36, float %3699, float %3679)  ; FMin(a,b)
  %4011 = call float @dx.op.binary.f32(i32 36, float %3700, float %3680)  ; FMin(a,b)
  %4012 = call float @dx.op.binary.f32(i32 36, float %4006, float %3986)  ; FMin(a,b)
  %4013 = call float @dx.op.binary.f32(i32 36, float %4007, float %3987)  ; FMin(a,b)
  %4014 = call float @dx.op.binary.f32(i32 36, float %4008, float %3988)  ; FMin(a,b)
  %4015 = call float @dx.op.binary.f32(i32 36, float %4012, float %4009)  ; FMin(a,b)
  %4016 = call float @dx.op.binary.f32(i32 36, float %4013, float %4010)  ; FMin(a,b)
  %4017 = call float @dx.op.binary.f32(i32 36, float %4014, float %4011)  ; FMin(a,b)
  %4018 = call float @dx.op.binary.f32(i32 36, float %1208, float %4015)  ; FMin(a,b)
  %4019 = call float @dx.op.binary.f32(i32 36, float %1209, float %4016)  ; FMin(a,b)
  %4020 = call float @dx.op.binary.f32(i32 36, float %1210, float %4017)  ; FMin(a,b)
  %4021 = call float @dx.op.binary.f32(i32 35, float %3698, float %3678)  ; FMax(a,b)
  %4022 = call float @dx.op.binary.f32(i32 35, float %3699, float %3679)  ; FMax(a,b)
  %4023 = call float @dx.op.binary.f32(i32 35, float %3700, float %3680)  ; FMax(a,b)
  %4024 = call float @dx.op.binary.f32(i32 35, float %4006, float %3986)  ; FMax(a,b)
  %4025 = call float @dx.op.binary.f32(i32 35, float %4007, float %3987)  ; FMax(a,b)
  %4026 = call float @dx.op.binary.f32(i32 35, float %4008, float %3988)  ; FMax(a,b)
  %4027 = call float @dx.op.binary.f32(i32 35, float %4024, float %4021)  ; FMax(a,b)
  %4028 = call float @dx.op.binary.f32(i32 35, float %4025, float %4022)  ; FMax(a,b)
  %4029 = call float @dx.op.binary.f32(i32 35, float %4026, float %4023)  ; FMax(a,b)
  %4030 = call float @dx.op.binary.f32(i32 35, float %1208, float %4027)  ; FMax(a,b)
  %4031 = call float @dx.op.binary.f32(i32 35, float %1209, float %4028)  ; FMax(a,b)
  %4032 = call float @dx.op.binary.f32(i32 35, float %1210, float %4029)  ; FMax(a,b)
  %4033 = fsub fast float %4030, %4018
  %4034 = fsub fast float %4031, %4019
  %4035 = fsub fast float %4032, %4020
  %4036 = call float @dx.op.unary.f32(i32 6, float %4033)  ; FAbs(value)
  %4037 = call float @dx.op.unary.f32(i32 6, float %4034)  ; FAbs(value)
  %4038 = call float @dx.op.unary.f32(i32 6, float %4035)  ; FAbs(value)
  %4039 = call float @dx.op.binary.f32(i32 35, float %4037, float %4038)  ; FMax(a,b)
  %4040 = call float @dx.op.binary.f32(i32 35, float %4036, float %4039)  ; FMax(a,b)
  %4041 = call float @dx.op.binary.f32(i32 35, float %4031, float %4032)  ; FMax(a,b)
  %4042 = call float @dx.op.binary.f32(i32 35, float %4030, float %4041)  ; FMax(a,b)
  %4043 = fmul fast float %4042, 1.250000e-01
  %4044 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %4043)  ; FMax(a,b)
  %4045 = fcmp fast ogt float %4040, %4044
  br i1 %4045, label %4046, label %10167

; <label>:4046                                    ; preds = %4005
  %4047 = fsub fast float %4006, %3986
  %4048 = fsub fast float %4007, %3987
  %4049 = fsub fast float %4008, %3988
  %4050 = call float @dx.op.unary.f32(i32 6, float %4047)  ; FAbs(value)
  %4051 = call float @dx.op.unary.f32(i32 6, float %4048)  ; FAbs(value)
  %4052 = call float @dx.op.unary.f32(i32 6, float %4049)  ; FAbs(value)
  %4053 = call float @dx.op.binary.f32(i32 35, float %4051, float %4052)  ; FMax(a,b)
  %4054 = call float @dx.op.binary.f32(i32 35, float %4050, float %4053)  ; FMax(a,b)
  %4055 = fsub fast float %3698, %3678
  %4056 = fsub fast float %3699, %3679
  %4057 = fsub fast float %3700, %3680
  %4058 = call float @dx.op.unary.f32(i32 6, float %4055)  ; FAbs(value)
  %4059 = call float @dx.op.unary.f32(i32 6, float %4056)  ; FAbs(value)
  %4060 = call float @dx.op.unary.f32(i32 6, float %4057)  ; FAbs(value)
  %4061 = call float @dx.op.binary.f32(i32 35, float %4059, float %4060)  ; FMax(a,b)
  %4062 = call float @dx.op.binary.f32(i32 35, float %4058, float %4061)  ; FMax(a,b)
  %4063 = fcmp fast olt float %4054, %4062
  %4064 = select i1 %4063, float %4006, float %3698
  %4065 = select i1 %4063, float %4007, float %3699
  %4066 = select i1 %4063, float %4008, float %3700
  %4067 = select i1 %4063, float %3986, float %3678
  %4068 = select i1 %4063, float %3987, float %3679
  %4069 = select i1 %4063, float %3988, float %3680
  %4070 = fsub fast float %1208, %4067
  %4071 = fsub fast float %1209, %4068
  %4072 = fsub fast float %1210, %4069
  %4073 = fsub fast float %1208, %4064
  %4074 = fsub fast float %1209, %4065
  %4075 = fsub fast float %1210, %4066
  %4076 = call float @dx.op.dot3.f32(i32 55, float %4073, float %4074, float %4075, float %4070, float %4071, float %4072)  ; Dot3(ax,ay,az,bx,by,bz)
  %4077 = fcmp fast ogt float %4076, 0.000000e+00
  br i1 %4077, label %4078, label %4090

; <label>:4078                                    ; preds = %4046
  %4079 = fsub fast float %4064, %4067
  %4080 = fsub fast float %4065, %4068
  %4081 = fsub fast float %4066, %4069
  %4082 = call float @dx.op.unary.f32(i32 6, float %4079)  ; FAbs(value)
  %4083 = call float @dx.op.unary.f32(i32 6, float %4080)  ; FAbs(value)
  %4084 = call float @dx.op.unary.f32(i32 6, float %4081)  ; FAbs(value)
  %4085 = call float @dx.op.binary.f32(i32 35, float %4083, float %4084)  ; FMax(a,b)
  %4086 = call float @dx.op.binary.f32(i32 35, float %4082, float %4085)  ; FMax(a,b)
  %4087 = fmul fast float %4040, 2.500000e-01
  %4088 = fcmp fast olt float %4086, %4087
  %4089 = select i1 %4088, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  br label %4090

; <label>:4090                                    ; preds = %4078, %4046
  %4091 = phi float [ 0x3FC99999A0000000, %4046 ], [ %4089, %4078 ]
  %4092 = fadd fast float %4064, %4067
  %4093 = fadd fast float %4065, %4068
  %4094 = fadd fast float %4066, %4069
  %4095 = fmul fast float %4092, 5.000000e-01
  %4096 = fmul fast float %4093, 5.000000e-01
  %4097 = fmul fast float %4094, 5.000000e-01
  %4098 = fsub fast float %4095, %1208
  %4099 = fsub fast float %4096, %1209
  %4100 = fsub fast float %4097, %1210
  %4101 = fmul fast float %4091, %4098
  %4102 = fmul fast float %4091, %4099
  %4103 = fmul fast float %4091, %4100
  %4104 = fadd fast float %4101, %1208
  %4105 = fadd fast float %4102, %1209
  %4106 = fadd fast float %4103, %1210
  br label %10167

; <label>:4107                                    ; preds = %172
  %4108 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4109 = extractvalue %dx.types.ResRet.f32 %4108, 0
  %4110 = extractvalue %dx.types.ResRet.f32 %4108, 1
  %4111 = extractvalue %dx.types.ResRet.f32 %4108, 2
  %4112 = extractvalue %dx.types.ResRet.f32 %4108, 3
  %4113 = fcmp fast olt float %4112, 0.000000e+00
  br i1 %4113, label %4114, label %4149

; <label>:4114                                    ; preds = %4107
  %4115 = fcmp fast ogt float %4109, 0x3FA4B5DCC0000000
  %4116 = fcmp fast ogt float %4110, 0x3FA4B5DCC0000000
  %4117 = fcmp fast ogt float %4111, 0x3FA4B5DCC0000000
  %4118 = select i1 %4115, float 0.000000e+00, float 1.000000e+00
  %4119 = select i1 %4116, float 0.000000e+00, float 1.000000e+00
  %4120 = select i1 %4117, float 0.000000e+00, float 1.000000e+00
  %4121 = fmul fast float %4109, 0x3FB3D07220000000
  %4122 = fmul fast float %4110, 0x3FB3D07220000000
  %4123 = fmul fast float %4111, 0x3FB3D07220000000
  %4124 = fadd fast float %4109, 0x3FAC28F5C0000000
  %4125 = fadd fast float %4110, 0x3FAC28F5C0000000
  %4126 = fadd fast float %4111, 0x3FAC28F5C0000000
  %4127 = fmul fast float %4124, 0x3FEE54EDE0000000
  %4128 = fmul fast float %4125, 0x3FEE54EDE0000000
  %4129 = fmul fast float %4126, 0x3FEE54EDE0000000
  %4130 = call float @dx.op.unary.f32(i32 23, float %4127)  ; Log(value)
  %4131 = call float @dx.op.unary.f32(i32 23, float %4128)  ; Log(value)
  %4132 = call float @dx.op.unary.f32(i32 23, float %4129)  ; Log(value)
  %4133 = fmul fast float %4130, 0x4003333340000000
  %4134 = fmul fast float %4131, 0x4003333340000000
  %4135 = fmul fast float %4132, 0x4003333340000000
  %4136 = call float @dx.op.unary.f32(i32 21, float %4133)  ; Exp(value)
  %4137 = call float @dx.op.unary.f32(i32 21, float %4134)  ; Exp(value)
  %4138 = call float @dx.op.unary.f32(i32 21, float %4135)  ; Exp(value)
  %4139 = fsub fast float %4121, %4136
  %4140 = fsub fast float %4122, %4137
  %4141 = fsub fast float %4123, %4138
  %4142 = fmul fast float %4139, %4118
  %4143 = fmul fast float %4140, %4119
  %4144 = fmul fast float %4141, %4120
  %4145 = fadd fast float %4142, %4136
  %4146 = fadd fast float %4143, %4137
  %4147 = fadd fast float %4144, %4138
  %4148 = fsub fast float -1.000000e+00, %4112
  br label %5619

; <label>:4149                                    ; preds = %4107
  %4150 = fcmp fast ogt float %38, 5.000000e-01
  %4151 = fcmp fast olt float %82, 1.000000e+00
  %4152 = and i1 %4150, %4151
  br i1 %4152, label %4153, label %4291

; <label>:4153                                    ; preds = %4149
  %4154 = sitofp i32 %63 to float
  %4155 = sitofp i32 %64 to float
  %4156 = fadd fast float %4154, 5.000000e-01
  %4157 = fadd fast float %4155, 5.000000e-01
  %4158 = fdiv fast float %4156, %45
  %4159 = fdiv fast float %4157, %46
  %4160 = fmul fast float %4158, 2.000000e+00
  %4161 = fmul fast float %4159, 2.000000e+00
  %4162 = fadd fast float %4160, -1.000000e+00
  %4163 = fsub fast float 1.000000e+00, %4161
  %4164 = fmul fast float %4162, %35
  %4165 = call float @dx.op.tertiary.f32(i32 46, float %4163, float %31, float %4164)  ; FMad(a,b,c)
  %4166 = call float @dx.op.tertiary.f32(i32 46, float %82, float %27, float %4165)  ; FMad(a,b,c)
  %4167 = fadd fast float %4166, %23
  %4168 = call float @dx.op.unary.f32(i32 6, float %4167)  ; FAbs(value)
  %4169 = fcmp fast ogt float %4168, 0x3EB0C6F7A0000000
  br i1 %4169, label %4170, label %4291

; <label>:4170                                    ; preds = %4153
  %4171 = fmul fast float %4162, %34
  %4172 = call float @dx.op.tertiary.f32(i32 46, float %4163, float %30, float %4171)  ; FMad(a,b,c)
  %4173 = call float @dx.op.tertiary.f32(i32 46, float %82, float %26, float %4172)  ; FMad(a,b,c)
  %4174 = fadd fast float %4173, %22
  %4175 = fmul fast float %4162, %33
  %4176 = call float @dx.op.tertiary.f32(i32 46, float %4163, float %29, float %4175)  ; FMad(a,b,c)
  %4177 = call float @dx.op.tertiary.f32(i32 46, float %82, float %25, float %4176)  ; FMad(a,b,c)
  %4178 = fadd fast float %4177, %21
  %4179 = fmul fast float %4162, %32
  %4180 = call float @dx.op.tertiary.f32(i32 46, float %4163, float %28, float %4179)  ; FMad(a,b,c)
  %4181 = call float @dx.op.tertiary.f32(i32 46, float %82, float %24, float %4180)  ; FMad(a,b,c)
  %4182 = fadd fast float %4181, %20
  %4183 = fdiv fast float %4182, %4167
  %4184 = fdiv fast float %4178, %4167
  %4185 = fdiv fast float %4174, %4167
  %4186 = fsub fast float %4183, %17
  %4187 = fsub fast float %4184, %18
  %4188 = fsub fast float %4185, %19
  %4189 = fmul fast float %4186, %4186
  %4190 = fmul fast float %4187, %4187
  %4191 = fadd fast float %4190, %4189
  %4192 = fmul fast float %4188, %4188
  %4193 = fadd fast float %4191, %4192
  %4194 = call float @dx.op.unary.f32(i32 24, float %4193)  ; Sqrt(value)
  %4195 = fsub fast float %4194, %9
  %4196 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4195)  ; FMax(a,b)
  %4197 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %4197, label %4198, label %4221

; <label>:4198                                    ; preds = %4170
  %4199 = call float @dx.op.unary.f32(i32 6, float %4187)  ; FAbs(value)
  %4200 = fmul fast float %4199, %11
  %4201 = fcmp fast olt float %4200, 0x3F50624DE0000000
  br i1 %4201, label %4202, label %4205

; <label>:4202                                    ; preds = %4198
  %4203 = fmul fast float %4200, 5.000000e-01
  %4204 = fsub fast float 1.000000e+00, %4203
  br label %4210

; <label>:4205                                    ; preds = %4198
  %4206 = fmul fast float %4200, 0xBFF7154760000000
  %4207 = call float @dx.op.unary.f32(i32 21, float %4206)  ; Exp(value)
  %4208 = fsub fast float 1.000000e+00, %4207
  %4209 = fdiv fast float %4208, %4200
  br label %4210

; <label>:4210                                    ; preds = %4205, %4202
  %4211 = phi float [ %4204, %4202 ], [ %4209, %4205 ]
  %4212 = call float @dx.op.binary.f32(i32 36, float %4184, float %18)  ; FMin(a,b)
  %4213 = fsub fast float %4212, %10
  %4214 = fmul fast float %11, %4213
  %4215 = fsub fast float -0.000000e+00, %4214
  %4216 = call float @dx.op.binary.f32(i32 35, float %4215, float -4.000000e+01)  ; FMax(a,b)
  %4217 = call float @dx.op.binary.f32(i32 36, float %4216, float 5.000000e+00)  ; FMin(a,b)
  %4218 = fmul fast float %4217, 0x3FF7154760000000
  %4219 = call float @dx.op.unary.f32(i32 21, float %4218)  ; Exp(value)
  %4220 = fmul fast float %4219, %4211
  br label %4221

; <label>:4221                                    ; preds = %4210, %4170
  %4222 = phi float [ %4220, %4210 ], [ 1.000000e+00, %4170 ]
  %4223 = fmul fast float %4196, %16
  %4224 = fmul fast float %4223, %4222
  %4225 = fcmp fast ole float %4194, %9
  %4226 = fcmp fast olt float %4194, 0x3F1A36E2E0000000
  %4227 = or i1 %4225, %4226
  br i1 %4227, label %4274, label %4228

; <label>:4228                                    ; preds = %4221
  %4229 = fdiv fast float %9, %4194
  %4230 = fmul fast float %4229, %4186
  %4231 = fmul fast float %4229, %4187
  %4232 = fmul fast float %4229, %4188
  %4233 = fadd fast float %4230, %17
  %4234 = fadd fast float %4231, %18
  %4235 = fadd fast float %4232, %19
  %4236 = fadd fast float %4233, -9.000000e+02
  %4237 = fadd fast float %4234, -1.500000e+01
  %4238 = fadd fast float %4235, -7.500000e+02
  %4239 = fmul fast float %4236, 0x3F62345680000000
  %4240 = fmul fast float %4237, 0x3F62345680000000
  %4241 = fmul fast float %4238, 0x3F62345680000000
  %4242 = call float @dx.op.dot3.f32(i32 55, float %4239, float %4240, float %4241, float %4239, float %4240, float %4241)  ; Dot3(ax,ay,az,bx,by,bz)
  %4243 = fsub fast float 1.000000e+00, %4242
  %4244 = call float @dx.op.unary.f32(i32 7, float %4243)  ; Saturate(value)
  %4245 = fmul fast float %4244, %4244
  %4246 = fadd fast float %4233, %4183
  %4247 = fadd fast float %4234, %4184
  %4248 = fadd fast float %4235, %4185
  %4249 = fmul fast float %4246, 0x3F52345680000000
  %4250 = fadd fast float %4249, -2.000000e+00
  %4251 = fmul fast float %4247, 0x3F52345680000000
  %4252 = fadd fast float %4251, 0xBFA1111120000000
  %4253 = fmul fast float %4248, 0x3F52345680000000
  %4254 = fadd fast float %4253, 0xBFFAAAAAC0000000
  %4255 = call float @dx.op.dot3.f32(i32 55, float %4250, float %4252, float %4254, float %4250, float %4252, float %4254)  ; Dot3(ax,ay,az,bx,by,bz)
  %4256 = fsub fast float 1.000000e+00, %4255
  %4257 = call float @dx.op.unary.f32(i32 7, float %4256)  ; Saturate(value)
  %4258 = fmul fast float %4257, %4257
  %4259 = fmul fast float %4258, 4.000000e+00
  %4260 = fadd fast float %4259, %4245
  %4261 = fadd fast float %4183, -9.000000e+02
  %4262 = fadd fast float %4184, -1.500000e+01
  %4263 = fadd fast float %4185, -7.500000e+02
  %4264 = fmul fast float %4261, 0x3F62345680000000
  %4265 = fmul fast float %4262, 0x3F62345680000000
  %4266 = fmul fast float %4263, 0x3F62345680000000
  %4267 = call float @dx.op.dot3.f32(i32 55, float %4264, float %4265, float %4266, float %4264, float %4265, float %4266)  ; Dot3(ax,ay,az,bx,by,bz)
  %4268 = fsub fast float 1.000000e+00, %4267
  %4269 = call float @dx.op.unary.f32(i32 7, float %4268)  ; Saturate(value)
  %4270 = fmul fast float %4269, %4269
  %4271 = fadd fast float %4260, %4270
  %4272 = fmul fast float %4195, 0x3F25D867E0000000
  %4273 = fmul fast float %4272, %4271
  br label %4274

; <label>:4274                                    ; preds = %4228, %4221
  %4275 = phi float [ %4273, %4228 ], [ 0.000000e+00, %4221 ]
  %4276 = fadd fast float %4275, %4224
  %4277 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4276)  ; FMin(a,b)
  %4278 = fmul fast float %4277, 0xBFF7154760000000
  %4279 = call float @dx.op.unary.f32(i32 21, float %4278)  ; Exp(value)
  %4280 = fsub fast float 1.000000e+00, %4279
  %4281 = call float @dx.op.binary.f32(i32 36, float %12, float %4280)  ; FMin(a,b)
  %4282 = fsub fast float %13, %4109
  %4283 = fsub fast float %14, %4110
  %4284 = fsub fast float %15, %4111
  %4285 = fmul fast float %4281, %4282
  %4286 = fmul fast float %4281, %4283
  %4287 = fmul fast float %4281, %4284
  %4288 = fadd fast float %4285, %4109
  %4289 = fadd fast float %4286, %4110
  %4290 = fadd fast float %4287, %4111
  br label %4291

; <label>:4291                                    ; preds = %4274, %4153, %4149
  %4292 = phi float [ %4288, %4274 ], [ %4109, %4153 ], [ %4109, %4149 ]
  %4293 = phi float [ %4289, %4274 ], [ %4110, %4153 ], [ %4110, %4149 ]
  %4294 = phi float [ %4290, %4274 ], [ %4111, %4153 ], [ %4111, %4149 ]
  %4295 = fadd fast float %5, 1.000000e+00
  %4296 = fadd fast float %6, 1.000000e+00
  %4297 = fsub fast float 1.000000e+00, %5
  %4298 = fmul fast float %36, %4295
  %4299 = fmul fast float %36, %4296
  %4300 = fmul fast float %36, %4297
  %4301 = fmul fast float %4298, %4292
  %4302 = fmul fast float %4299, %4293
  %4303 = fmul fast float %4300, %4294
  %4304 = fcmp fast ult float %37, 5.000000e-01
  br i1 %4304, label %4330, label %4305

; <label>:4305                                    ; preds = %4291
  %4306 = fmul fast float %4301, 0x4004147AE0000000
  %4307 = fmul fast float %4302, 0x4004147AE0000000
  %4308 = fmul fast float %4303, 0x4004147AE0000000
  %4309 = fadd fast float %4306, 0x3F9EB851E0000000
  %4310 = fadd fast float %4307, 0x3F9EB851E0000000
  %4311 = fadd fast float %4308, 0x3F9EB851E0000000
  %4312 = fmul fast float %4309, %4301
  %4313 = fmul fast float %4310, %4302
  %4314 = fmul fast float %4311, %4303
  %4315 = fmul fast float %4301, 0x400370A3E0000000
  %4316 = fmul fast float %4302, 0x400370A3E0000000
  %4317 = fmul fast float %4303, 0x400370A3E0000000
  %4318 = fadd fast float %4315, 0x3FE2E147A0000000
  %4319 = fadd fast float %4316, 0x3FE2E147A0000000
  %4320 = fadd fast float %4317, 0x3FE2E147A0000000
  %4321 = fmul fast float %4318, %4301
  %4322 = fmul fast float %4319, %4302
  %4323 = fmul fast float %4320, %4303
  %4324 = fadd fast float %4321, 0x3FC1EB8520000000
  %4325 = fadd fast float %4322, 0x3FC1EB8520000000
  %4326 = fadd fast float %4323, 0x3FC1EB8520000000
  %4327 = fdiv fast float %4312, %4324
  %4328 = fdiv fast float %4313, %4325
  %4329 = fdiv fast float %4314, %4326
  br label %4330

; <label>:4330                                    ; preds = %4305, %4291
  %4331 = phi float [ %4327, %4305 ], [ %4301, %4291 ]
  %4332 = phi float [ %4328, %4305 ], [ %4302, %4291 ]
  %4333 = phi float [ %4329, %4305 ], [ %4303, %4291 ]
  %4334 = call float @dx.op.unary.f32(i32 7, float %4331)  ; Saturate(value)
  %4335 = call float @dx.op.unary.f32(i32 7, float %4332)  ; Saturate(value)
  %4336 = call float @dx.op.unary.f32(i32 7, float %4333)  ; Saturate(value)
  %4337 = call float @dx.op.dot3.f32(i32 55, float %4334, float %4335, float %4336, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4338 = fsub fast float %4334, %4337
  %4339 = fsub fast float %4335, %4337
  %4340 = fsub fast float %4336, %4337
  %4341 = fmul fast float %4338, %8
  %4342 = fmul fast float %4339, %8
  %4343 = fmul fast float %4340, %8
  %4344 = fadd fast float %4341, %4337
  %4345 = fadd fast float %4342, %4337
  %4346 = fadd fast float %4343, %4337
  %4347 = call float @dx.op.unary.f32(i32 7, float %4344)  ; Saturate(value)
  %4348 = call float @dx.op.unary.f32(i32 7, float %4345)  ; Saturate(value)
  %4349 = call float @dx.op.unary.f32(i32 7, float %4346)  ; Saturate(value)
  %4350 = fadd fast float %4347, 0xBFC70A3D80000000
  %4351 = fadd fast float %4348, 0xBFC70A3D80000000
  %4352 = fadd fast float %4349, 0xBFC70A3D80000000
  %4353 = fmul fast float %4350, %7
  %4354 = fmul fast float %4351, %7
  %4355 = fmul fast float %4352, %7
  %4356 = fadd fast float %4353, 0x3FC70A3D80000000
  %4357 = fadd fast float %4354, 0x3FC70A3D80000000
  %4358 = fadd fast float %4355, 0x3FC70A3D80000000
  %4359 = call float @dx.op.unary.f32(i32 7, float %4356)  ; Saturate(value)
  %4360 = call float @dx.op.unary.f32(i32 7, float %4357)  ; Saturate(value)
  %4361 = call float @dx.op.unary.f32(i32 7, float %4358)  ; Saturate(value)
  %4362 = add i32 %64, -1
  %4363 = call i32 @dx.op.binary.i32(i32 37, i32 %63, i32 0)  ; IMax(a,b)
  %4364 = call i32 @dx.op.binary.i32(i32 37, i32 %4362, i32 0)  ; IMax(a,b)
  %4365 = call i32 @dx.op.binary.i32(i32 38, i32 %4363, i32 %59)  ; IMin(a,b)
  %4366 = call i32 @dx.op.binary.i32(i32 38, i32 %4364, i32 %60)  ; IMin(a,b)
  %4367 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4365, i32 %4366, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4368 = extractvalue %dx.types.ResRet.f32 %4367, 0
  %4369 = fsub fast float 1.000000e+00, %82
  %4370 = fmul fast float %4369, 0x3FA99999A0000000
  %4371 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %4370)  ; FMax(a,b)
  %4372 = fsub fast float %4368, %82
  %4373 = call float @dx.op.unary.f32(i32 6, float %4372)  ; FAbs(value)
  %4374 = fdiv fast float %4373, %4371
  %4375 = fsub fast float 1.000000e+00, %4374
  %4376 = call float @dx.op.unary.f32(i32 7, float %4375)  ; Saturate(value)
  %4377 = fcmp fast ugt float %4376, 0.000000e+00
  br i1 %4377, label %4378, label %4651

; <label>:4378                                    ; preds = %4330
  %4379 = call i32 @dx.op.binary.i32(i32 37, i32 %4365, i32 0)  ; IMax(a,b)
  %4380 = call i32 @dx.op.binary.i32(i32 37, i32 %4366, i32 0)  ; IMax(a,b)
  %4381 = call i32 @dx.op.binary.i32(i32 38, i32 %4379, i32 %59)  ; IMin(a,b)
  %4382 = call i32 @dx.op.binary.i32(i32 38, i32 %4380, i32 %60)  ; IMin(a,b)
  %4383 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4381, i32 %4382, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4384 = extractvalue %dx.types.ResRet.f32 %4383, 0
  %4385 = extractvalue %dx.types.ResRet.f32 %4383, 1
  %4386 = extractvalue %dx.types.ResRet.f32 %4383, 2
  %4387 = extractvalue %dx.types.ResRet.f32 %4383, 3
  %4388 = fcmp fast olt float %4387, 0.000000e+00
  br i1 %4388, label %4389, label %4423

; <label>:4389                                    ; preds = %4378
  %4390 = fcmp fast ogt float %4384, 0x3FA4B5DCC0000000
  %4391 = fcmp fast ogt float %4385, 0x3FA4B5DCC0000000
  %4392 = fcmp fast ogt float %4386, 0x3FA4B5DCC0000000
  %4393 = select i1 %4390, float 0.000000e+00, float 1.000000e+00
  %4394 = select i1 %4391, float 0.000000e+00, float 1.000000e+00
  %4395 = select i1 %4392, float 0.000000e+00, float 1.000000e+00
  %4396 = fmul fast float %4384, 0x3FB3D07220000000
  %4397 = fmul fast float %4385, 0x3FB3D07220000000
  %4398 = fmul fast float %4386, 0x3FB3D07220000000
  %4399 = fadd fast float %4384, 0x3FAC28F5C0000000
  %4400 = fadd fast float %4385, 0x3FAC28F5C0000000
  %4401 = fadd fast float %4386, 0x3FAC28F5C0000000
  %4402 = fmul fast float %4399, 0x3FEE54EDE0000000
  %4403 = fmul fast float %4400, 0x3FEE54EDE0000000
  %4404 = fmul fast float %4401, 0x3FEE54EDE0000000
  %4405 = call float @dx.op.unary.f32(i32 23, float %4402)  ; Log(value)
  %4406 = call float @dx.op.unary.f32(i32 23, float %4403)  ; Log(value)
  %4407 = call float @dx.op.unary.f32(i32 23, float %4404)  ; Log(value)
  %4408 = fmul fast float %4405, 0x4003333340000000
  %4409 = fmul fast float %4406, 0x4003333340000000
  %4410 = fmul fast float %4407, 0x4003333340000000
  %4411 = call float @dx.op.unary.f32(i32 21, float %4408)  ; Exp(value)
  %4412 = call float @dx.op.unary.f32(i32 21, float %4409)  ; Exp(value)
  %4413 = call float @dx.op.unary.f32(i32 21, float %4410)  ; Exp(value)
  %4414 = fsub fast float %4396, %4411
  %4415 = fsub fast float %4397, %4412
  %4416 = fsub fast float %4398, %4413
  %4417 = fmul fast float %4414, %4393
  %4418 = fmul fast float %4415, %4394
  %4419 = fmul fast float %4416, %4395
  %4420 = fadd fast float %4417, %4411
  %4421 = fadd fast float %4418, %4412
  %4422 = fadd fast float %4419, %4413
  br label %4638

; <label>:4423                                    ; preds = %4378
  %4424 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4381, i32 %4382, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4425 = extractvalue %dx.types.ResRet.f32 %4424, 0
  %4426 = fcmp fast ogt float %38, 5.000000e-01
  %4427 = fcmp fast olt float %4425, 1.000000e+00
  %4428 = and i1 %4426, %4427
  br i1 %4428, label %4429, label %4567

; <label>:4429                                    ; preds = %4423
  %4430 = sitofp i32 %4381 to float
  %4431 = sitofp i32 %4382 to float
  %4432 = fadd fast float %4430, 5.000000e-01
  %4433 = fadd fast float %4431, 5.000000e-01
  %4434 = fdiv fast float %4432, %45
  %4435 = fdiv fast float %4433, %46
  %4436 = fmul fast float %4434, 2.000000e+00
  %4437 = fmul fast float %4435, 2.000000e+00
  %4438 = fadd fast float %4436, -1.000000e+00
  %4439 = fsub fast float 1.000000e+00, %4437
  %4440 = fmul fast float %4438, %35
  %4441 = call float @dx.op.tertiary.f32(i32 46, float %4439, float %31, float %4440)  ; FMad(a,b,c)
  %4442 = call float @dx.op.tertiary.f32(i32 46, float %4425, float %27, float %4441)  ; FMad(a,b,c)
  %4443 = fadd fast float %4442, %23
  %4444 = call float @dx.op.unary.f32(i32 6, float %4443)  ; FAbs(value)
  %4445 = fcmp fast ogt float %4444, 0x3EB0C6F7A0000000
  br i1 %4445, label %4446, label %4567

; <label>:4446                                    ; preds = %4429
  %4447 = fmul fast float %4438, %34
  %4448 = call float @dx.op.tertiary.f32(i32 46, float %4439, float %30, float %4447)  ; FMad(a,b,c)
  %4449 = call float @dx.op.tertiary.f32(i32 46, float %4425, float %26, float %4448)  ; FMad(a,b,c)
  %4450 = fadd fast float %4449, %22
  %4451 = fmul fast float %4438, %33
  %4452 = call float @dx.op.tertiary.f32(i32 46, float %4439, float %29, float %4451)  ; FMad(a,b,c)
  %4453 = call float @dx.op.tertiary.f32(i32 46, float %4425, float %25, float %4452)  ; FMad(a,b,c)
  %4454 = fadd fast float %4453, %21
  %4455 = fmul fast float %4438, %32
  %4456 = call float @dx.op.tertiary.f32(i32 46, float %4439, float %28, float %4455)  ; FMad(a,b,c)
  %4457 = call float @dx.op.tertiary.f32(i32 46, float %4425, float %24, float %4456)  ; FMad(a,b,c)
  %4458 = fadd fast float %4457, %20
  %4459 = fdiv fast float %4458, %4443
  %4460 = fdiv fast float %4454, %4443
  %4461 = fdiv fast float %4450, %4443
  %4462 = fsub fast float %4459, %17
  %4463 = fsub fast float %4460, %18
  %4464 = fsub fast float %4461, %19
  %4465 = fmul fast float %4462, %4462
  %4466 = fmul fast float %4463, %4463
  %4467 = fadd fast float %4466, %4465
  %4468 = fmul fast float %4464, %4464
  %4469 = fadd fast float %4467, %4468
  %4470 = call float @dx.op.unary.f32(i32 24, float %4469)  ; Sqrt(value)
  %4471 = fsub fast float %4470, %9
  %4472 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4471)  ; FMax(a,b)
  %4473 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %4473, label %4474, label %4497

; <label>:4474                                    ; preds = %4446
  %4475 = call float @dx.op.unary.f32(i32 6, float %4463)  ; FAbs(value)
  %4476 = fmul fast float %4475, %11
  %4477 = fcmp fast olt float %4476, 0x3F50624DE0000000
  br i1 %4477, label %4478, label %4481

; <label>:4478                                    ; preds = %4474
  %4479 = fmul fast float %4476, 5.000000e-01
  %4480 = fsub fast float 1.000000e+00, %4479
  br label %4486

; <label>:4481                                    ; preds = %4474
  %4482 = fmul fast float %4476, 0xBFF7154760000000
  %4483 = call float @dx.op.unary.f32(i32 21, float %4482)  ; Exp(value)
  %4484 = fsub fast float 1.000000e+00, %4483
  %4485 = fdiv fast float %4484, %4476
  br label %4486

; <label>:4486                                    ; preds = %4481, %4478
  %4487 = phi float [ %4480, %4478 ], [ %4485, %4481 ]
  %4488 = call float @dx.op.binary.f32(i32 36, float %4460, float %18)  ; FMin(a,b)
  %4489 = fsub fast float %4488, %10
  %4490 = fmul fast float %11, %4489
  %4491 = fsub fast float -0.000000e+00, %4490
  %4492 = call float @dx.op.binary.f32(i32 35, float %4491, float -4.000000e+01)  ; FMax(a,b)
  %4493 = call float @dx.op.binary.f32(i32 36, float %4492, float 5.000000e+00)  ; FMin(a,b)
  %4494 = fmul fast float %4493, 0x3FF7154760000000
  %4495 = call float @dx.op.unary.f32(i32 21, float %4494)  ; Exp(value)
  %4496 = fmul fast float %4495, %4487
  br label %4497

; <label>:4497                                    ; preds = %4486, %4446
  %4498 = phi float [ %4496, %4486 ], [ 1.000000e+00, %4446 ]
  %4499 = fmul fast float %4472, %16
  %4500 = fmul fast float %4499, %4498
  %4501 = fcmp fast ole float %4470, %9
  %4502 = fcmp fast olt float %4470, 0x3F1A36E2E0000000
  %4503 = or i1 %4501, %4502
  br i1 %4503, label %4550, label %4504

; <label>:4504                                    ; preds = %4497
  %4505 = fdiv fast float %9, %4470
  %4506 = fmul fast float %4505, %4462
  %4507 = fmul fast float %4505, %4463
  %4508 = fmul fast float %4505, %4464
  %4509 = fadd fast float %4506, %17
  %4510 = fadd fast float %4507, %18
  %4511 = fadd fast float %4508, %19
  %4512 = fadd fast float %4509, -9.000000e+02
  %4513 = fadd fast float %4510, -1.500000e+01
  %4514 = fadd fast float %4511, -7.500000e+02
  %4515 = fmul fast float %4512, 0x3F62345680000000
  %4516 = fmul fast float %4513, 0x3F62345680000000
  %4517 = fmul fast float %4514, 0x3F62345680000000
  %4518 = call float @dx.op.dot3.f32(i32 55, float %4515, float %4516, float %4517, float %4515, float %4516, float %4517)  ; Dot3(ax,ay,az,bx,by,bz)
  %4519 = fsub fast float 1.000000e+00, %4518
  %4520 = call float @dx.op.unary.f32(i32 7, float %4519)  ; Saturate(value)
  %4521 = fmul fast float %4520, %4520
  %4522 = fadd fast float %4509, %4459
  %4523 = fadd fast float %4510, %4460
  %4524 = fadd fast float %4511, %4461
  %4525 = fmul fast float %4522, 0x3F52345680000000
  %4526 = fadd fast float %4525, -2.000000e+00
  %4527 = fmul fast float %4523, 0x3F52345680000000
  %4528 = fadd fast float %4527, 0xBFA1111120000000
  %4529 = fmul fast float %4524, 0x3F52345680000000
  %4530 = fadd fast float %4529, 0xBFFAAAAAC0000000
  %4531 = call float @dx.op.dot3.f32(i32 55, float %4526, float %4528, float %4530, float %4526, float %4528, float %4530)  ; Dot3(ax,ay,az,bx,by,bz)
  %4532 = fsub fast float 1.000000e+00, %4531
  %4533 = call float @dx.op.unary.f32(i32 7, float %4532)  ; Saturate(value)
  %4534 = fmul fast float %4533, %4533
  %4535 = fmul fast float %4534, 4.000000e+00
  %4536 = fadd fast float %4535, %4521
  %4537 = fadd fast float %4459, -9.000000e+02
  %4538 = fadd fast float %4460, -1.500000e+01
  %4539 = fadd fast float %4461, -7.500000e+02
  %4540 = fmul fast float %4537, 0x3F62345680000000
  %4541 = fmul fast float %4538, 0x3F62345680000000
  %4542 = fmul fast float %4539, 0x3F62345680000000
  %4543 = call float @dx.op.dot3.f32(i32 55, float %4540, float %4541, float %4542, float %4540, float %4541, float %4542)  ; Dot3(ax,ay,az,bx,by,bz)
  %4544 = fsub fast float 1.000000e+00, %4543
  %4545 = call float @dx.op.unary.f32(i32 7, float %4544)  ; Saturate(value)
  %4546 = fmul fast float %4545, %4545
  %4547 = fadd fast float %4536, %4546
  %4548 = fmul fast float %4471, 0x3F25D867E0000000
  %4549 = fmul fast float %4548, %4547
  br label %4550

; <label>:4550                                    ; preds = %4504, %4497
  %4551 = phi float [ %4549, %4504 ], [ 0.000000e+00, %4497 ]
  %4552 = fadd fast float %4551, %4500
  %4553 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4552)  ; FMin(a,b)
  %4554 = fmul fast float %4553, 0xBFF7154760000000
  %4555 = call float @dx.op.unary.f32(i32 21, float %4554)  ; Exp(value)
  %4556 = fsub fast float 1.000000e+00, %4555
  %4557 = call float @dx.op.binary.f32(i32 36, float %12, float %4556)  ; FMin(a,b)
  %4558 = fsub fast float %13, %4384
  %4559 = fsub fast float %14, %4385
  %4560 = fsub fast float %15, %4386
  %4561 = fmul fast float %4557, %4558
  %4562 = fmul fast float %4557, %4559
  %4563 = fmul fast float %4557, %4560
  %4564 = fadd fast float %4561, %4384
  %4565 = fadd fast float %4562, %4385
  %4566 = fadd fast float %4563, %4386
  br label %4567

; <label>:4567                                    ; preds = %4550, %4429, %4423
  %4568 = phi float [ %4564, %4550 ], [ %4384, %4429 ], [ %4384, %4423 ]
  %4569 = phi float [ %4565, %4550 ], [ %4385, %4429 ], [ %4385, %4423 ]
  %4570 = phi float [ %4566, %4550 ], [ %4386, %4429 ], [ %4386, %4423 ]
  %4571 = fadd fast float %5, 1.000000e+00
  %4572 = fadd fast float %6, 1.000000e+00
  %4573 = fsub fast float 1.000000e+00, %5
  %4574 = fmul fast float %36, %4571
  %4575 = fmul fast float %36, %4572
  %4576 = fmul fast float %36, %4573
  %4577 = fmul fast float %4574, %4568
  %4578 = fmul fast float %4575, %4569
  %4579 = fmul fast float %4576, %4570
  %4580 = fcmp fast ult float %37, 5.000000e-01
  br i1 %4580, label %4606, label %4581

; <label>:4581                                    ; preds = %4567
  %4582 = fmul fast float %4577, 0x4004147AE0000000
  %4583 = fmul fast float %4578, 0x4004147AE0000000
  %4584 = fmul fast float %4579, 0x4004147AE0000000
  %4585 = fadd fast float %4582, 0x3F9EB851E0000000
  %4586 = fadd fast float %4583, 0x3F9EB851E0000000
  %4587 = fadd fast float %4584, 0x3F9EB851E0000000
  %4588 = fmul fast float %4585, %4577
  %4589 = fmul fast float %4586, %4578
  %4590 = fmul fast float %4587, %4579
  %4591 = fmul fast float %4577, 0x400370A3E0000000
  %4592 = fmul fast float %4578, 0x400370A3E0000000
  %4593 = fmul fast float %4579, 0x400370A3E0000000
  %4594 = fadd fast float %4591, 0x3FE2E147A0000000
  %4595 = fadd fast float %4592, 0x3FE2E147A0000000
  %4596 = fadd fast float %4593, 0x3FE2E147A0000000
  %4597 = fmul fast float %4594, %4577
  %4598 = fmul fast float %4595, %4578
  %4599 = fmul fast float %4596, %4579
  %4600 = fadd fast float %4597, 0x3FC1EB8520000000
  %4601 = fadd fast float %4598, 0x3FC1EB8520000000
  %4602 = fadd fast float %4599, 0x3FC1EB8520000000
  %4603 = fdiv fast float %4588, %4600
  %4604 = fdiv fast float %4589, %4601
  %4605 = fdiv fast float %4590, %4602
  br label %4606

; <label>:4606                                    ; preds = %4581, %4567
  %4607 = phi float [ %4603, %4581 ], [ %4577, %4567 ]
  %4608 = phi float [ %4604, %4581 ], [ %4578, %4567 ]
  %4609 = phi float [ %4605, %4581 ], [ %4579, %4567 ]
  %4610 = call float @dx.op.unary.f32(i32 7, float %4607)  ; Saturate(value)
  %4611 = call float @dx.op.unary.f32(i32 7, float %4608)  ; Saturate(value)
  %4612 = call float @dx.op.unary.f32(i32 7, float %4609)  ; Saturate(value)
  %4613 = call float @dx.op.dot3.f32(i32 55, float %4610, float %4611, float %4612, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4614 = fsub fast float %4610, %4613
  %4615 = fsub fast float %4611, %4613
  %4616 = fsub fast float %4612, %4613
  %4617 = fmul fast float %4614, %8
  %4618 = fmul fast float %4615, %8
  %4619 = fmul fast float %4616, %8
  %4620 = fadd fast float %4617, %4613
  %4621 = fadd fast float %4618, %4613
  %4622 = fadd fast float %4619, %4613
  %4623 = call float @dx.op.unary.f32(i32 7, float %4620)  ; Saturate(value)
  %4624 = call float @dx.op.unary.f32(i32 7, float %4621)  ; Saturate(value)
  %4625 = call float @dx.op.unary.f32(i32 7, float %4622)  ; Saturate(value)
  %4626 = fadd fast float %4623, 0xBFC70A3D80000000
  %4627 = fadd fast float %4624, 0xBFC70A3D80000000
  %4628 = fadd fast float %4625, 0xBFC70A3D80000000
  %4629 = fmul fast float %4626, %7
  %4630 = fmul fast float %4627, %7
  %4631 = fmul fast float %4628, %7
  %4632 = fadd fast float %4629, 0x3FC70A3D80000000
  %4633 = fadd fast float %4630, 0x3FC70A3D80000000
  %4634 = fadd fast float %4631, 0x3FC70A3D80000000
  %4635 = call float @dx.op.unary.f32(i32 7, float %4632)  ; Saturate(value)
  %4636 = call float @dx.op.unary.f32(i32 7, float %4633)  ; Saturate(value)
  %4637 = call float @dx.op.unary.f32(i32 7, float %4634)  ; Saturate(value)
  br label %4638

; <label>:4638                                    ; preds = %4606, %4389
  %4639 = phi float [ %4420, %4389 ], [ %4635, %4606 ]
  %4640 = phi float [ %4421, %4389 ], [ %4636, %4606 ]
  %4641 = phi float [ %4422, %4389 ], [ %4637, %4606 ]
  %4642 = fsub fast float %4639, %4359
  %4643 = fsub fast float %4640, %4360
  %4644 = fsub fast float %4641, %4361
  %4645 = fmul fast float %4642, %4376
  %4646 = fmul fast float %4643, %4376
  %4647 = fmul fast float %4644, %4376
  %4648 = fadd fast float %4645, %4359
  %4649 = fadd fast float %4646, %4360
  %4650 = fadd fast float %4647, %4361
  br label %4651

; <label>:4651                                    ; preds = %4638, %4330
  %4652 = phi float [ %4648, %4638 ], [ %4359, %4330 ]
  %4653 = phi float [ %4649, %4638 ], [ %4360, %4330 ]
  %4654 = phi float [ %4650, %4638 ], [ %4361, %4330 ]
  %4655 = add i32 %64, 1
  %4656 = call i32 @dx.op.binary.i32(i32 37, i32 %4655, i32 0)  ; IMax(a,b)
  %4657 = call i32 @dx.op.binary.i32(i32 38, i32 %4656, i32 %60)  ; IMin(a,b)
  %4658 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4365, i32 %4657, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4659 = extractvalue %dx.types.ResRet.f32 %4658, 0
  %4660 = fsub fast float %4659, %82
  %4661 = call float @dx.op.unary.f32(i32 6, float %4660)  ; FAbs(value)
  %4662 = fdiv fast float %4661, %4371
  %4663 = fsub fast float 1.000000e+00, %4662
  %4664 = call float @dx.op.unary.f32(i32 7, float %4663)  ; Saturate(value)
  %4665 = fcmp fast ugt float %4664, 0.000000e+00
  br i1 %4665, label %4666, label %4939

; <label>:4666                                    ; preds = %4651
  %4667 = call i32 @dx.op.binary.i32(i32 37, i32 %4365, i32 0)  ; IMax(a,b)
  %4668 = call i32 @dx.op.binary.i32(i32 37, i32 %4657, i32 0)  ; IMax(a,b)
  %4669 = call i32 @dx.op.binary.i32(i32 38, i32 %4667, i32 %59)  ; IMin(a,b)
  %4670 = call i32 @dx.op.binary.i32(i32 38, i32 %4668, i32 %60)  ; IMin(a,b)
  %4671 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4669, i32 %4670, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4672 = extractvalue %dx.types.ResRet.f32 %4671, 0
  %4673 = extractvalue %dx.types.ResRet.f32 %4671, 1
  %4674 = extractvalue %dx.types.ResRet.f32 %4671, 2
  %4675 = extractvalue %dx.types.ResRet.f32 %4671, 3
  %4676 = fcmp fast olt float %4675, 0.000000e+00
  br i1 %4676, label %4677, label %4711

; <label>:4677                                    ; preds = %4666
  %4678 = fcmp fast ogt float %4672, 0x3FA4B5DCC0000000
  %4679 = fcmp fast ogt float %4673, 0x3FA4B5DCC0000000
  %4680 = fcmp fast ogt float %4674, 0x3FA4B5DCC0000000
  %4681 = select i1 %4678, float 0.000000e+00, float 1.000000e+00
  %4682 = select i1 %4679, float 0.000000e+00, float 1.000000e+00
  %4683 = select i1 %4680, float 0.000000e+00, float 1.000000e+00
  %4684 = fmul fast float %4672, 0x3FB3D07220000000
  %4685 = fmul fast float %4673, 0x3FB3D07220000000
  %4686 = fmul fast float %4674, 0x3FB3D07220000000
  %4687 = fadd fast float %4672, 0x3FAC28F5C0000000
  %4688 = fadd fast float %4673, 0x3FAC28F5C0000000
  %4689 = fadd fast float %4674, 0x3FAC28F5C0000000
  %4690 = fmul fast float %4687, 0x3FEE54EDE0000000
  %4691 = fmul fast float %4688, 0x3FEE54EDE0000000
  %4692 = fmul fast float %4689, 0x3FEE54EDE0000000
  %4693 = call float @dx.op.unary.f32(i32 23, float %4690)  ; Log(value)
  %4694 = call float @dx.op.unary.f32(i32 23, float %4691)  ; Log(value)
  %4695 = call float @dx.op.unary.f32(i32 23, float %4692)  ; Log(value)
  %4696 = fmul fast float %4693, 0x4003333340000000
  %4697 = fmul fast float %4694, 0x4003333340000000
  %4698 = fmul fast float %4695, 0x4003333340000000
  %4699 = call float @dx.op.unary.f32(i32 21, float %4696)  ; Exp(value)
  %4700 = call float @dx.op.unary.f32(i32 21, float %4697)  ; Exp(value)
  %4701 = call float @dx.op.unary.f32(i32 21, float %4698)  ; Exp(value)
  %4702 = fsub fast float %4684, %4699
  %4703 = fsub fast float %4685, %4700
  %4704 = fsub fast float %4686, %4701
  %4705 = fmul fast float %4702, %4681
  %4706 = fmul fast float %4703, %4682
  %4707 = fmul fast float %4704, %4683
  %4708 = fadd fast float %4705, %4699
  %4709 = fadd fast float %4706, %4700
  %4710 = fadd fast float %4707, %4701
  br label %4926

; <label>:4711                                    ; preds = %4666
  %4712 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4669, i32 %4670, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4713 = extractvalue %dx.types.ResRet.f32 %4712, 0
  %4714 = fcmp fast ogt float %38, 5.000000e-01
  %4715 = fcmp fast olt float %4713, 1.000000e+00
  %4716 = and i1 %4714, %4715
  br i1 %4716, label %4717, label %4855

; <label>:4717                                    ; preds = %4711
  %4718 = sitofp i32 %4669 to float
  %4719 = sitofp i32 %4670 to float
  %4720 = fadd fast float %4718, 5.000000e-01
  %4721 = fadd fast float %4719, 5.000000e-01
  %4722 = fdiv fast float %4720, %45
  %4723 = fdiv fast float %4721, %46
  %4724 = fmul fast float %4722, 2.000000e+00
  %4725 = fmul fast float %4723, 2.000000e+00
  %4726 = fadd fast float %4724, -1.000000e+00
  %4727 = fsub fast float 1.000000e+00, %4725
  %4728 = fmul fast float %4726, %35
  %4729 = call float @dx.op.tertiary.f32(i32 46, float %4727, float %31, float %4728)  ; FMad(a,b,c)
  %4730 = call float @dx.op.tertiary.f32(i32 46, float %4713, float %27, float %4729)  ; FMad(a,b,c)
  %4731 = fadd fast float %4730, %23
  %4732 = call float @dx.op.unary.f32(i32 6, float %4731)  ; FAbs(value)
  %4733 = fcmp fast ogt float %4732, 0x3EB0C6F7A0000000
  br i1 %4733, label %4734, label %4855

; <label>:4734                                    ; preds = %4717
  %4735 = fmul fast float %4726, %34
  %4736 = call float @dx.op.tertiary.f32(i32 46, float %4727, float %30, float %4735)  ; FMad(a,b,c)
  %4737 = call float @dx.op.tertiary.f32(i32 46, float %4713, float %26, float %4736)  ; FMad(a,b,c)
  %4738 = fadd fast float %4737, %22
  %4739 = fmul fast float %4726, %33
  %4740 = call float @dx.op.tertiary.f32(i32 46, float %4727, float %29, float %4739)  ; FMad(a,b,c)
  %4741 = call float @dx.op.tertiary.f32(i32 46, float %4713, float %25, float %4740)  ; FMad(a,b,c)
  %4742 = fadd fast float %4741, %21
  %4743 = fmul fast float %4726, %32
  %4744 = call float @dx.op.tertiary.f32(i32 46, float %4727, float %28, float %4743)  ; FMad(a,b,c)
  %4745 = call float @dx.op.tertiary.f32(i32 46, float %4713, float %24, float %4744)  ; FMad(a,b,c)
  %4746 = fadd fast float %4745, %20
  %4747 = fdiv fast float %4746, %4731
  %4748 = fdiv fast float %4742, %4731
  %4749 = fdiv fast float %4738, %4731
  %4750 = fsub fast float %4747, %17
  %4751 = fsub fast float %4748, %18
  %4752 = fsub fast float %4749, %19
  %4753 = fmul fast float %4750, %4750
  %4754 = fmul fast float %4751, %4751
  %4755 = fadd fast float %4754, %4753
  %4756 = fmul fast float %4752, %4752
  %4757 = fadd fast float %4755, %4756
  %4758 = call float @dx.op.unary.f32(i32 24, float %4757)  ; Sqrt(value)
  %4759 = fsub fast float %4758, %9
  %4760 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4759)  ; FMax(a,b)
  %4761 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %4761, label %4762, label %4785

; <label>:4762                                    ; preds = %4734
  %4763 = call float @dx.op.unary.f32(i32 6, float %4751)  ; FAbs(value)
  %4764 = fmul fast float %4763, %11
  %4765 = fcmp fast olt float %4764, 0x3F50624DE0000000
  br i1 %4765, label %4766, label %4769

; <label>:4766                                    ; preds = %4762
  %4767 = fmul fast float %4764, 5.000000e-01
  %4768 = fsub fast float 1.000000e+00, %4767
  br label %4774

; <label>:4769                                    ; preds = %4762
  %4770 = fmul fast float %4764, 0xBFF7154760000000
  %4771 = call float @dx.op.unary.f32(i32 21, float %4770)  ; Exp(value)
  %4772 = fsub fast float 1.000000e+00, %4771
  %4773 = fdiv fast float %4772, %4764
  br label %4774

; <label>:4774                                    ; preds = %4769, %4766
  %4775 = phi float [ %4768, %4766 ], [ %4773, %4769 ]
  %4776 = call float @dx.op.binary.f32(i32 36, float %4748, float %18)  ; FMin(a,b)
  %4777 = fsub fast float %4776, %10
  %4778 = fmul fast float %11, %4777
  %4779 = fsub fast float -0.000000e+00, %4778
  %4780 = call float @dx.op.binary.f32(i32 35, float %4779, float -4.000000e+01)  ; FMax(a,b)
  %4781 = call float @dx.op.binary.f32(i32 36, float %4780, float 5.000000e+00)  ; FMin(a,b)
  %4782 = fmul fast float %4781, 0x3FF7154760000000
  %4783 = call float @dx.op.unary.f32(i32 21, float %4782)  ; Exp(value)
  %4784 = fmul fast float %4783, %4775
  br label %4785

; <label>:4785                                    ; preds = %4774, %4734
  %4786 = phi float [ %4784, %4774 ], [ 1.000000e+00, %4734 ]
  %4787 = fmul fast float %4760, %16
  %4788 = fmul fast float %4787, %4786
  %4789 = fcmp fast ole float %4758, %9
  %4790 = fcmp fast olt float %4758, 0x3F1A36E2E0000000
  %4791 = or i1 %4789, %4790
  br i1 %4791, label %4838, label %4792

; <label>:4792                                    ; preds = %4785
  %4793 = fdiv fast float %9, %4758
  %4794 = fmul fast float %4793, %4750
  %4795 = fmul fast float %4793, %4751
  %4796 = fmul fast float %4793, %4752
  %4797 = fadd fast float %4794, %17
  %4798 = fadd fast float %4795, %18
  %4799 = fadd fast float %4796, %19
  %4800 = fadd fast float %4797, -9.000000e+02
  %4801 = fadd fast float %4798, -1.500000e+01
  %4802 = fadd fast float %4799, -7.500000e+02
  %4803 = fmul fast float %4800, 0x3F62345680000000
  %4804 = fmul fast float %4801, 0x3F62345680000000
  %4805 = fmul fast float %4802, 0x3F62345680000000
  %4806 = call float @dx.op.dot3.f32(i32 55, float %4803, float %4804, float %4805, float %4803, float %4804, float %4805)  ; Dot3(ax,ay,az,bx,by,bz)
  %4807 = fsub fast float 1.000000e+00, %4806
  %4808 = call float @dx.op.unary.f32(i32 7, float %4807)  ; Saturate(value)
  %4809 = fmul fast float %4808, %4808
  %4810 = fadd fast float %4797, %4747
  %4811 = fadd fast float %4798, %4748
  %4812 = fadd fast float %4799, %4749
  %4813 = fmul fast float %4810, 0x3F52345680000000
  %4814 = fadd fast float %4813, -2.000000e+00
  %4815 = fmul fast float %4811, 0x3F52345680000000
  %4816 = fadd fast float %4815, 0xBFA1111120000000
  %4817 = fmul fast float %4812, 0x3F52345680000000
  %4818 = fadd fast float %4817, 0xBFFAAAAAC0000000
  %4819 = call float @dx.op.dot3.f32(i32 55, float %4814, float %4816, float %4818, float %4814, float %4816, float %4818)  ; Dot3(ax,ay,az,bx,by,bz)
  %4820 = fsub fast float 1.000000e+00, %4819
  %4821 = call float @dx.op.unary.f32(i32 7, float %4820)  ; Saturate(value)
  %4822 = fmul fast float %4821, %4821
  %4823 = fmul fast float %4822, 4.000000e+00
  %4824 = fadd fast float %4823, %4809
  %4825 = fadd fast float %4747, -9.000000e+02
  %4826 = fadd fast float %4748, -1.500000e+01
  %4827 = fadd fast float %4749, -7.500000e+02
  %4828 = fmul fast float %4825, 0x3F62345680000000
  %4829 = fmul fast float %4826, 0x3F62345680000000
  %4830 = fmul fast float %4827, 0x3F62345680000000
  %4831 = call float @dx.op.dot3.f32(i32 55, float %4828, float %4829, float %4830, float %4828, float %4829, float %4830)  ; Dot3(ax,ay,az,bx,by,bz)
  %4832 = fsub fast float 1.000000e+00, %4831
  %4833 = call float @dx.op.unary.f32(i32 7, float %4832)  ; Saturate(value)
  %4834 = fmul fast float %4833, %4833
  %4835 = fadd fast float %4824, %4834
  %4836 = fmul fast float %4759, 0x3F25D867E0000000
  %4837 = fmul fast float %4836, %4835
  br label %4838

; <label>:4838                                    ; preds = %4792, %4785
  %4839 = phi float [ %4837, %4792 ], [ 0.000000e+00, %4785 ]
  %4840 = fadd fast float %4839, %4788
  %4841 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4840)  ; FMin(a,b)
  %4842 = fmul fast float %4841, 0xBFF7154760000000
  %4843 = call float @dx.op.unary.f32(i32 21, float %4842)  ; Exp(value)
  %4844 = fsub fast float 1.000000e+00, %4843
  %4845 = call float @dx.op.binary.f32(i32 36, float %12, float %4844)  ; FMin(a,b)
  %4846 = fsub fast float %13, %4672
  %4847 = fsub fast float %14, %4673
  %4848 = fsub fast float %15, %4674
  %4849 = fmul fast float %4845, %4846
  %4850 = fmul fast float %4845, %4847
  %4851 = fmul fast float %4845, %4848
  %4852 = fadd fast float %4849, %4672
  %4853 = fadd fast float %4850, %4673
  %4854 = fadd fast float %4851, %4674
  br label %4855

; <label>:4855                                    ; preds = %4838, %4717, %4711
  %4856 = phi float [ %4852, %4838 ], [ %4672, %4717 ], [ %4672, %4711 ]
  %4857 = phi float [ %4853, %4838 ], [ %4673, %4717 ], [ %4673, %4711 ]
  %4858 = phi float [ %4854, %4838 ], [ %4674, %4717 ], [ %4674, %4711 ]
  %4859 = fadd fast float %5, 1.000000e+00
  %4860 = fadd fast float %6, 1.000000e+00
  %4861 = fsub fast float 1.000000e+00, %5
  %4862 = fmul fast float %36, %4859
  %4863 = fmul fast float %36, %4860
  %4864 = fmul fast float %36, %4861
  %4865 = fmul fast float %4862, %4856
  %4866 = fmul fast float %4863, %4857
  %4867 = fmul fast float %4864, %4858
  %4868 = fcmp fast ult float %37, 5.000000e-01
  br i1 %4868, label %4894, label %4869

; <label>:4869                                    ; preds = %4855
  %4870 = fmul fast float %4865, 0x4004147AE0000000
  %4871 = fmul fast float %4866, 0x4004147AE0000000
  %4872 = fmul fast float %4867, 0x4004147AE0000000
  %4873 = fadd fast float %4870, 0x3F9EB851E0000000
  %4874 = fadd fast float %4871, 0x3F9EB851E0000000
  %4875 = fadd fast float %4872, 0x3F9EB851E0000000
  %4876 = fmul fast float %4873, %4865
  %4877 = fmul fast float %4874, %4866
  %4878 = fmul fast float %4875, %4867
  %4879 = fmul fast float %4865, 0x400370A3E0000000
  %4880 = fmul fast float %4866, 0x400370A3E0000000
  %4881 = fmul fast float %4867, 0x400370A3E0000000
  %4882 = fadd fast float %4879, 0x3FE2E147A0000000
  %4883 = fadd fast float %4880, 0x3FE2E147A0000000
  %4884 = fadd fast float %4881, 0x3FE2E147A0000000
  %4885 = fmul fast float %4882, %4865
  %4886 = fmul fast float %4883, %4866
  %4887 = fmul fast float %4884, %4867
  %4888 = fadd fast float %4885, 0x3FC1EB8520000000
  %4889 = fadd fast float %4886, 0x3FC1EB8520000000
  %4890 = fadd fast float %4887, 0x3FC1EB8520000000
  %4891 = fdiv fast float %4876, %4888
  %4892 = fdiv fast float %4877, %4889
  %4893 = fdiv fast float %4878, %4890
  br label %4894

; <label>:4894                                    ; preds = %4869, %4855
  %4895 = phi float [ %4891, %4869 ], [ %4865, %4855 ]
  %4896 = phi float [ %4892, %4869 ], [ %4866, %4855 ]
  %4897 = phi float [ %4893, %4869 ], [ %4867, %4855 ]
  %4898 = call float @dx.op.unary.f32(i32 7, float %4895)  ; Saturate(value)
  %4899 = call float @dx.op.unary.f32(i32 7, float %4896)  ; Saturate(value)
  %4900 = call float @dx.op.unary.f32(i32 7, float %4897)  ; Saturate(value)
  %4901 = call float @dx.op.dot3.f32(i32 55, float %4898, float %4899, float %4900, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4902 = fsub fast float %4898, %4901
  %4903 = fsub fast float %4899, %4901
  %4904 = fsub fast float %4900, %4901
  %4905 = fmul fast float %4902, %8
  %4906 = fmul fast float %4903, %8
  %4907 = fmul fast float %4904, %8
  %4908 = fadd fast float %4905, %4901
  %4909 = fadd fast float %4906, %4901
  %4910 = fadd fast float %4907, %4901
  %4911 = call float @dx.op.unary.f32(i32 7, float %4908)  ; Saturate(value)
  %4912 = call float @dx.op.unary.f32(i32 7, float %4909)  ; Saturate(value)
  %4913 = call float @dx.op.unary.f32(i32 7, float %4910)  ; Saturate(value)
  %4914 = fadd fast float %4911, 0xBFC70A3D80000000
  %4915 = fadd fast float %4912, 0xBFC70A3D80000000
  %4916 = fadd fast float %4913, 0xBFC70A3D80000000
  %4917 = fmul fast float %4914, %7
  %4918 = fmul fast float %4915, %7
  %4919 = fmul fast float %4916, %7
  %4920 = fadd fast float %4917, 0x3FC70A3D80000000
  %4921 = fadd fast float %4918, 0x3FC70A3D80000000
  %4922 = fadd fast float %4919, 0x3FC70A3D80000000
  %4923 = call float @dx.op.unary.f32(i32 7, float %4920)  ; Saturate(value)
  %4924 = call float @dx.op.unary.f32(i32 7, float %4921)  ; Saturate(value)
  %4925 = call float @dx.op.unary.f32(i32 7, float %4922)  ; Saturate(value)
  br label %4926

; <label>:4926                                    ; preds = %4894, %4677
  %4927 = phi float [ %4708, %4677 ], [ %4923, %4894 ]
  %4928 = phi float [ %4709, %4677 ], [ %4924, %4894 ]
  %4929 = phi float [ %4710, %4677 ], [ %4925, %4894 ]
  %4930 = fsub fast float %4927, %4359
  %4931 = fsub fast float %4928, %4360
  %4932 = fsub fast float %4929, %4361
  %4933 = fmul fast float %4930, %4664
  %4934 = fmul fast float %4931, %4664
  %4935 = fmul fast float %4932, %4664
  %4936 = fadd fast float %4933, %4359
  %4937 = fadd fast float %4934, %4360
  %4938 = fadd fast float %4935, %4361
  br label %4939

; <label>:4939                                    ; preds = %4926, %4651
  %4940 = phi float [ %4936, %4926 ], [ %4359, %4651 ]
  %4941 = phi float [ %4937, %4926 ], [ %4360, %4651 ]
  %4942 = phi float [ %4938, %4926 ], [ %4361, %4651 ]
  %4943 = add i32 %63, -1
  %4944 = call i32 @dx.op.binary.i32(i32 37, i32 %4943, i32 0)  ; IMax(a,b)
  %4945 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %4946 = call i32 @dx.op.binary.i32(i32 38, i32 %4944, i32 %59)  ; IMin(a,b)
  %4947 = call i32 @dx.op.binary.i32(i32 38, i32 %4945, i32 %60)  ; IMin(a,b)
  %4948 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4946, i32 %4947, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4949 = extractvalue %dx.types.ResRet.f32 %4948, 0
  %4950 = fsub fast float %4949, %82
  %4951 = call float @dx.op.unary.f32(i32 6, float %4950)  ; FAbs(value)
  %4952 = fdiv fast float %4951, %4371
  %4953 = fsub fast float 1.000000e+00, %4952
  %4954 = call float @dx.op.unary.f32(i32 7, float %4953)  ; Saturate(value)
  %4955 = fcmp fast ugt float %4954, 0.000000e+00
  br i1 %4955, label %4956, label %5229

; <label>:4956                                    ; preds = %4939
  %4957 = call i32 @dx.op.binary.i32(i32 37, i32 %4946, i32 0)  ; IMax(a,b)
  %4958 = call i32 @dx.op.binary.i32(i32 37, i32 %4947, i32 0)  ; IMax(a,b)
  %4959 = call i32 @dx.op.binary.i32(i32 38, i32 %4957, i32 %59)  ; IMin(a,b)
  %4960 = call i32 @dx.op.binary.i32(i32 38, i32 %4958, i32 %60)  ; IMin(a,b)
  %4961 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4959, i32 %4960, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4962 = extractvalue %dx.types.ResRet.f32 %4961, 0
  %4963 = extractvalue %dx.types.ResRet.f32 %4961, 1
  %4964 = extractvalue %dx.types.ResRet.f32 %4961, 2
  %4965 = extractvalue %dx.types.ResRet.f32 %4961, 3
  %4966 = fcmp fast olt float %4965, 0.000000e+00
  br i1 %4966, label %4967, label %5001

; <label>:4967                                    ; preds = %4956
  %4968 = fcmp fast ogt float %4962, 0x3FA4B5DCC0000000
  %4969 = fcmp fast ogt float %4963, 0x3FA4B5DCC0000000
  %4970 = fcmp fast ogt float %4964, 0x3FA4B5DCC0000000
  %4971 = select i1 %4968, float 0.000000e+00, float 1.000000e+00
  %4972 = select i1 %4969, float 0.000000e+00, float 1.000000e+00
  %4973 = select i1 %4970, float 0.000000e+00, float 1.000000e+00
  %4974 = fmul fast float %4962, 0x3FB3D07220000000
  %4975 = fmul fast float %4963, 0x3FB3D07220000000
  %4976 = fmul fast float %4964, 0x3FB3D07220000000
  %4977 = fadd fast float %4962, 0x3FAC28F5C0000000
  %4978 = fadd fast float %4963, 0x3FAC28F5C0000000
  %4979 = fadd fast float %4964, 0x3FAC28F5C0000000
  %4980 = fmul fast float %4977, 0x3FEE54EDE0000000
  %4981 = fmul fast float %4978, 0x3FEE54EDE0000000
  %4982 = fmul fast float %4979, 0x3FEE54EDE0000000
  %4983 = call float @dx.op.unary.f32(i32 23, float %4980)  ; Log(value)
  %4984 = call float @dx.op.unary.f32(i32 23, float %4981)  ; Log(value)
  %4985 = call float @dx.op.unary.f32(i32 23, float %4982)  ; Log(value)
  %4986 = fmul fast float %4983, 0x4003333340000000
  %4987 = fmul fast float %4984, 0x4003333340000000
  %4988 = fmul fast float %4985, 0x4003333340000000
  %4989 = call float @dx.op.unary.f32(i32 21, float %4986)  ; Exp(value)
  %4990 = call float @dx.op.unary.f32(i32 21, float %4987)  ; Exp(value)
  %4991 = call float @dx.op.unary.f32(i32 21, float %4988)  ; Exp(value)
  %4992 = fsub fast float %4974, %4989
  %4993 = fsub fast float %4975, %4990
  %4994 = fsub fast float %4976, %4991
  %4995 = fmul fast float %4992, %4971
  %4996 = fmul fast float %4993, %4972
  %4997 = fmul fast float %4994, %4973
  %4998 = fadd fast float %4995, %4989
  %4999 = fadd fast float %4996, %4990
  %5000 = fadd fast float %4997, %4991
  br label %5216

; <label>:5001                                    ; preds = %4956
  %5002 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4959, i32 %4960, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5003 = extractvalue %dx.types.ResRet.f32 %5002, 0
  %5004 = fcmp fast ogt float %38, 5.000000e-01
  %5005 = fcmp fast olt float %5003, 1.000000e+00
  %5006 = and i1 %5004, %5005
  br i1 %5006, label %5007, label %5145

; <label>:5007                                    ; preds = %5001
  %5008 = sitofp i32 %4959 to float
  %5009 = sitofp i32 %4960 to float
  %5010 = fadd fast float %5008, 5.000000e-01
  %5011 = fadd fast float %5009, 5.000000e-01
  %5012 = fdiv fast float %5010, %45
  %5013 = fdiv fast float %5011, %46
  %5014 = fmul fast float %5012, 2.000000e+00
  %5015 = fmul fast float %5013, 2.000000e+00
  %5016 = fadd fast float %5014, -1.000000e+00
  %5017 = fsub fast float 1.000000e+00, %5015
  %5018 = fmul fast float %5016, %35
  %5019 = call float @dx.op.tertiary.f32(i32 46, float %5017, float %31, float %5018)  ; FMad(a,b,c)
  %5020 = call float @dx.op.tertiary.f32(i32 46, float %5003, float %27, float %5019)  ; FMad(a,b,c)
  %5021 = fadd fast float %5020, %23
  %5022 = call float @dx.op.unary.f32(i32 6, float %5021)  ; FAbs(value)
  %5023 = fcmp fast ogt float %5022, 0x3EB0C6F7A0000000
  br i1 %5023, label %5024, label %5145

; <label>:5024                                    ; preds = %5007
  %5025 = fmul fast float %5016, %34
  %5026 = call float @dx.op.tertiary.f32(i32 46, float %5017, float %30, float %5025)  ; FMad(a,b,c)
  %5027 = call float @dx.op.tertiary.f32(i32 46, float %5003, float %26, float %5026)  ; FMad(a,b,c)
  %5028 = fadd fast float %5027, %22
  %5029 = fmul fast float %5016, %33
  %5030 = call float @dx.op.tertiary.f32(i32 46, float %5017, float %29, float %5029)  ; FMad(a,b,c)
  %5031 = call float @dx.op.tertiary.f32(i32 46, float %5003, float %25, float %5030)  ; FMad(a,b,c)
  %5032 = fadd fast float %5031, %21
  %5033 = fmul fast float %5016, %32
  %5034 = call float @dx.op.tertiary.f32(i32 46, float %5017, float %28, float %5033)  ; FMad(a,b,c)
  %5035 = call float @dx.op.tertiary.f32(i32 46, float %5003, float %24, float %5034)  ; FMad(a,b,c)
  %5036 = fadd fast float %5035, %20
  %5037 = fdiv fast float %5036, %5021
  %5038 = fdiv fast float %5032, %5021
  %5039 = fdiv fast float %5028, %5021
  %5040 = fsub fast float %5037, %17
  %5041 = fsub fast float %5038, %18
  %5042 = fsub fast float %5039, %19
  %5043 = fmul fast float %5040, %5040
  %5044 = fmul fast float %5041, %5041
  %5045 = fadd fast float %5044, %5043
  %5046 = fmul fast float %5042, %5042
  %5047 = fadd fast float %5045, %5046
  %5048 = call float @dx.op.unary.f32(i32 24, float %5047)  ; Sqrt(value)
  %5049 = fsub fast float %5048, %9
  %5050 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5049)  ; FMax(a,b)
  %5051 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %5051, label %5052, label %5075

; <label>:5052                                    ; preds = %5024
  %5053 = call float @dx.op.unary.f32(i32 6, float %5041)  ; FAbs(value)
  %5054 = fmul fast float %5053, %11
  %5055 = fcmp fast olt float %5054, 0x3F50624DE0000000
  br i1 %5055, label %5056, label %5059

; <label>:5056                                    ; preds = %5052
  %5057 = fmul fast float %5054, 5.000000e-01
  %5058 = fsub fast float 1.000000e+00, %5057
  br label %5064

; <label>:5059                                    ; preds = %5052
  %5060 = fmul fast float %5054, 0xBFF7154760000000
  %5061 = call float @dx.op.unary.f32(i32 21, float %5060)  ; Exp(value)
  %5062 = fsub fast float 1.000000e+00, %5061
  %5063 = fdiv fast float %5062, %5054
  br label %5064

; <label>:5064                                    ; preds = %5059, %5056
  %5065 = phi float [ %5058, %5056 ], [ %5063, %5059 ]
  %5066 = call float @dx.op.binary.f32(i32 36, float %5038, float %18)  ; FMin(a,b)
  %5067 = fsub fast float %5066, %10
  %5068 = fmul fast float %11, %5067
  %5069 = fsub fast float -0.000000e+00, %5068
  %5070 = call float @dx.op.binary.f32(i32 35, float %5069, float -4.000000e+01)  ; FMax(a,b)
  %5071 = call float @dx.op.binary.f32(i32 36, float %5070, float 5.000000e+00)  ; FMin(a,b)
  %5072 = fmul fast float %5071, 0x3FF7154760000000
  %5073 = call float @dx.op.unary.f32(i32 21, float %5072)  ; Exp(value)
  %5074 = fmul fast float %5073, %5065
  br label %5075

; <label>:5075                                    ; preds = %5064, %5024
  %5076 = phi float [ %5074, %5064 ], [ 1.000000e+00, %5024 ]
  %5077 = fmul fast float %5050, %16
  %5078 = fmul fast float %5077, %5076
  %5079 = fcmp fast ole float %5048, %9
  %5080 = fcmp fast olt float %5048, 0x3F1A36E2E0000000
  %5081 = or i1 %5079, %5080
  br i1 %5081, label %5128, label %5082

; <label>:5082                                    ; preds = %5075
  %5083 = fdiv fast float %9, %5048
  %5084 = fmul fast float %5083, %5040
  %5085 = fmul fast float %5083, %5041
  %5086 = fmul fast float %5083, %5042
  %5087 = fadd fast float %5084, %17
  %5088 = fadd fast float %5085, %18
  %5089 = fadd fast float %5086, %19
  %5090 = fadd fast float %5087, -9.000000e+02
  %5091 = fadd fast float %5088, -1.500000e+01
  %5092 = fadd fast float %5089, -7.500000e+02
  %5093 = fmul fast float %5090, 0x3F62345680000000
  %5094 = fmul fast float %5091, 0x3F62345680000000
  %5095 = fmul fast float %5092, 0x3F62345680000000
  %5096 = call float @dx.op.dot3.f32(i32 55, float %5093, float %5094, float %5095, float %5093, float %5094, float %5095)  ; Dot3(ax,ay,az,bx,by,bz)
  %5097 = fsub fast float 1.000000e+00, %5096
  %5098 = call float @dx.op.unary.f32(i32 7, float %5097)  ; Saturate(value)
  %5099 = fmul fast float %5098, %5098
  %5100 = fadd fast float %5087, %5037
  %5101 = fadd fast float %5088, %5038
  %5102 = fadd fast float %5089, %5039
  %5103 = fmul fast float %5100, 0x3F52345680000000
  %5104 = fadd fast float %5103, -2.000000e+00
  %5105 = fmul fast float %5101, 0x3F52345680000000
  %5106 = fadd fast float %5105, 0xBFA1111120000000
  %5107 = fmul fast float %5102, 0x3F52345680000000
  %5108 = fadd fast float %5107, 0xBFFAAAAAC0000000
  %5109 = call float @dx.op.dot3.f32(i32 55, float %5104, float %5106, float %5108, float %5104, float %5106, float %5108)  ; Dot3(ax,ay,az,bx,by,bz)
  %5110 = fsub fast float 1.000000e+00, %5109
  %5111 = call float @dx.op.unary.f32(i32 7, float %5110)  ; Saturate(value)
  %5112 = fmul fast float %5111, %5111
  %5113 = fmul fast float %5112, 4.000000e+00
  %5114 = fadd fast float %5113, %5099
  %5115 = fadd fast float %5037, -9.000000e+02
  %5116 = fadd fast float %5038, -1.500000e+01
  %5117 = fadd fast float %5039, -7.500000e+02
  %5118 = fmul fast float %5115, 0x3F62345680000000
  %5119 = fmul fast float %5116, 0x3F62345680000000
  %5120 = fmul fast float %5117, 0x3F62345680000000
  %5121 = call float @dx.op.dot3.f32(i32 55, float %5118, float %5119, float %5120, float %5118, float %5119, float %5120)  ; Dot3(ax,ay,az,bx,by,bz)
  %5122 = fsub fast float 1.000000e+00, %5121
  %5123 = call float @dx.op.unary.f32(i32 7, float %5122)  ; Saturate(value)
  %5124 = fmul fast float %5123, %5123
  %5125 = fadd fast float %5114, %5124
  %5126 = fmul fast float %5049, 0x3F25D867E0000000
  %5127 = fmul fast float %5126, %5125
  br label %5128

; <label>:5128                                    ; preds = %5082, %5075
  %5129 = phi float [ %5127, %5082 ], [ 0.000000e+00, %5075 ]
  %5130 = fadd fast float %5129, %5078
  %5131 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %5130)  ; FMin(a,b)
  %5132 = fmul fast float %5131, 0xBFF7154760000000
  %5133 = call float @dx.op.unary.f32(i32 21, float %5132)  ; Exp(value)
  %5134 = fsub fast float 1.000000e+00, %5133
  %5135 = call float @dx.op.binary.f32(i32 36, float %12, float %5134)  ; FMin(a,b)
  %5136 = fsub fast float %13, %4962
  %5137 = fsub fast float %14, %4963
  %5138 = fsub fast float %15, %4964
  %5139 = fmul fast float %5135, %5136
  %5140 = fmul fast float %5135, %5137
  %5141 = fmul fast float %5135, %5138
  %5142 = fadd fast float %5139, %4962
  %5143 = fadd fast float %5140, %4963
  %5144 = fadd fast float %5141, %4964
  br label %5145

; <label>:5145                                    ; preds = %5128, %5007, %5001
  %5146 = phi float [ %5142, %5128 ], [ %4962, %5007 ], [ %4962, %5001 ]
  %5147 = phi float [ %5143, %5128 ], [ %4963, %5007 ], [ %4963, %5001 ]
  %5148 = phi float [ %5144, %5128 ], [ %4964, %5007 ], [ %4964, %5001 ]
  %5149 = fadd fast float %5, 1.000000e+00
  %5150 = fadd fast float %6, 1.000000e+00
  %5151 = fsub fast float 1.000000e+00, %5
  %5152 = fmul fast float %36, %5149
  %5153 = fmul fast float %36, %5150
  %5154 = fmul fast float %36, %5151
  %5155 = fmul fast float %5152, %5146
  %5156 = fmul fast float %5153, %5147
  %5157 = fmul fast float %5154, %5148
  %5158 = fcmp fast ult float %37, 5.000000e-01
  br i1 %5158, label %5184, label %5159

; <label>:5159                                    ; preds = %5145
  %5160 = fmul fast float %5155, 0x4004147AE0000000
  %5161 = fmul fast float %5156, 0x4004147AE0000000
  %5162 = fmul fast float %5157, 0x4004147AE0000000
  %5163 = fadd fast float %5160, 0x3F9EB851E0000000
  %5164 = fadd fast float %5161, 0x3F9EB851E0000000
  %5165 = fadd fast float %5162, 0x3F9EB851E0000000
  %5166 = fmul fast float %5163, %5155
  %5167 = fmul fast float %5164, %5156
  %5168 = fmul fast float %5165, %5157
  %5169 = fmul fast float %5155, 0x400370A3E0000000
  %5170 = fmul fast float %5156, 0x400370A3E0000000
  %5171 = fmul fast float %5157, 0x400370A3E0000000
  %5172 = fadd fast float %5169, 0x3FE2E147A0000000
  %5173 = fadd fast float %5170, 0x3FE2E147A0000000
  %5174 = fadd fast float %5171, 0x3FE2E147A0000000
  %5175 = fmul fast float %5172, %5155
  %5176 = fmul fast float %5173, %5156
  %5177 = fmul fast float %5174, %5157
  %5178 = fadd fast float %5175, 0x3FC1EB8520000000
  %5179 = fadd fast float %5176, 0x3FC1EB8520000000
  %5180 = fadd fast float %5177, 0x3FC1EB8520000000
  %5181 = fdiv fast float %5166, %5178
  %5182 = fdiv fast float %5167, %5179
  %5183 = fdiv fast float %5168, %5180
  br label %5184

; <label>:5184                                    ; preds = %5159, %5145
  %5185 = phi float [ %5181, %5159 ], [ %5155, %5145 ]
  %5186 = phi float [ %5182, %5159 ], [ %5156, %5145 ]
  %5187 = phi float [ %5183, %5159 ], [ %5157, %5145 ]
  %5188 = call float @dx.op.unary.f32(i32 7, float %5185)  ; Saturate(value)
  %5189 = call float @dx.op.unary.f32(i32 7, float %5186)  ; Saturate(value)
  %5190 = call float @dx.op.unary.f32(i32 7, float %5187)  ; Saturate(value)
  %5191 = call float @dx.op.dot3.f32(i32 55, float %5188, float %5189, float %5190, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5192 = fsub fast float %5188, %5191
  %5193 = fsub fast float %5189, %5191
  %5194 = fsub fast float %5190, %5191
  %5195 = fmul fast float %5192, %8
  %5196 = fmul fast float %5193, %8
  %5197 = fmul fast float %5194, %8
  %5198 = fadd fast float %5195, %5191
  %5199 = fadd fast float %5196, %5191
  %5200 = fadd fast float %5197, %5191
  %5201 = call float @dx.op.unary.f32(i32 7, float %5198)  ; Saturate(value)
  %5202 = call float @dx.op.unary.f32(i32 7, float %5199)  ; Saturate(value)
  %5203 = call float @dx.op.unary.f32(i32 7, float %5200)  ; Saturate(value)
  %5204 = fadd fast float %5201, 0xBFC70A3D80000000
  %5205 = fadd fast float %5202, 0xBFC70A3D80000000
  %5206 = fadd fast float %5203, 0xBFC70A3D80000000
  %5207 = fmul fast float %5204, %7
  %5208 = fmul fast float %5205, %7
  %5209 = fmul fast float %5206, %7
  %5210 = fadd fast float %5207, 0x3FC70A3D80000000
  %5211 = fadd fast float %5208, 0x3FC70A3D80000000
  %5212 = fadd fast float %5209, 0x3FC70A3D80000000
  %5213 = call float @dx.op.unary.f32(i32 7, float %5210)  ; Saturate(value)
  %5214 = call float @dx.op.unary.f32(i32 7, float %5211)  ; Saturate(value)
  %5215 = call float @dx.op.unary.f32(i32 7, float %5212)  ; Saturate(value)
  br label %5216

; <label>:5216                                    ; preds = %5184, %4967
  %5217 = phi float [ %4998, %4967 ], [ %5213, %5184 ]
  %5218 = phi float [ %4999, %4967 ], [ %5214, %5184 ]
  %5219 = phi float [ %5000, %4967 ], [ %5215, %5184 ]
  %5220 = fsub fast float %5217, %4359
  %5221 = fsub fast float %5218, %4360
  %5222 = fsub fast float %5219, %4361
  %5223 = fmul fast float %5220, %4954
  %5224 = fmul fast float %5221, %4954
  %5225 = fmul fast float %5222, %4954
  %5226 = fadd fast float %5223, %4359
  %5227 = fadd fast float %5224, %4360
  %5228 = fadd fast float %5225, %4361
  br label %5229

; <label>:5229                                    ; preds = %5216, %4939
  %5230 = phi float [ %5226, %5216 ], [ %4359, %4939 ]
  %5231 = phi float [ %5227, %5216 ], [ %4360, %4939 ]
  %5232 = phi float [ %5228, %5216 ], [ %4361, %4939 ]
  %5233 = add i32 %63, 1
  %5234 = call i32 @dx.op.binary.i32(i32 37, i32 %5233, i32 0)  ; IMax(a,b)
  %5235 = call i32 @dx.op.binary.i32(i32 38, i32 %5234, i32 %59)  ; IMin(a,b)
  %5236 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5235, i32 %4947, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5237 = extractvalue %dx.types.ResRet.f32 %5236, 0
  %5238 = fsub fast float %5237, %82
  %5239 = call float @dx.op.unary.f32(i32 6, float %5238)  ; FAbs(value)
  %5240 = fdiv fast float %5239, %4371
  %5241 = fsub fast float 1.000000e+00, %5240
  %5242 = call float @dx.op.unary.f32(i32 7, float %5241)  ; Saturate(value)
  %5243 = fcmp fast ugt float %5242, 0.000000e+00
  br i1 %5243, label %5244, label %5517

; <label>:5244                                    ; preds = %5229
  %5245 = call i32 @dx.op.binary.i32(i32 37, i32 %5235, i32 0)  ; IMax(a,b)
  %5246 = call i32 @dx.op.binary.i32(i32 37, i32 %4947, i32 0)  ; IMax(a,b)
  %5247 = call i32 @dx.op.binary.i32(i32 38, i32 %5245, i32 %59)  ; IMin(a,b)
  %5248 = call i32 @dx.op.binary.i32(i32 38, i32 %5246, i32 %60)  ; IMin(a,b)
  %5249 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %5247, i32 %5248, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5250 = extractvalue %dx.types.ResRet.f32 %5249, 0
  %5251 = extractvalue %dx.types.ResRet.f32 %5249, 1
  %5252 = extractvalue %dx.types.ResRet.f32 %5249, 2
  %5253 = extractvalue %dx.types.ResRet.f32 %5249, 3
  %5254 = fcmp fast olt float %5253, 0.000000e+00
  br i1 %5254, label %5255, label %5289

; <label>:5255                                    ; preds = %5244
  %5256 = fcmp fast ogt float %5250, 0x3FA4B5DCC0000000
  %5257 = fcmp fast ogt float %5251, 0x3FA4B5DCC0000000
  %5258 = fcmp fast ogt float %5252, 0x3FA4B5DCC0000000
  %5259 = select i1 %5256, float 0.000000e+00, float 1.000000e+00
  %5260 = select i1 %5257, float 0.000000e+00, float 1.000000e+00
  %5261 = select i1 %5258, float 0.000000e+00, float 1.000000e+00
  %5262 = fmul fast float %5250, 0x3FB3D07220000000
  %5263 = fmul fast float %5251, 0x3FB3D07220000000
  %5264 = fmul fast float %5252, 0x3FB3D07220000000
  %5265 = fadd fast float %5250, 0x3FAC28F5C0000000
  %5266 = fadd fast float %5251, 0x3FAC28F5C0000000
  %5267 = fadd fast float %5252, 0x3FAC28F5C0000000
  %5268 = fmul fast float %5265, 0x3FEE54EDE0000000
  %5269 = fmul fast float %5266, 0x3FEE54EDE0000000
  %5270 = fmul fast float %5267, 0x3FEE54EDE0000000
  %5271 = call float @dx.op.unary.f32(i32 23, float %5268)  ; Log(value)
  %5272 = call float @dx.op.unary.f32(i32 23, float %5269)  ; Log(value)
  %5273 = call float @dx.op.unary.f32(i32 23, float %5270)  ; Log(value)
  %5274 = fmul fast float %5271, 0x4003333340000000
  %5275 = fmul fast float %5272, 0x4003333340000000
  %5276 = fmul fast float %5273, 0x4003333340000000
  %5277 = call float @dx.op.unary.f32(i32 21, float %5274)  ; Exp(value)
  %5278 = call float @dx.op.unary.f32(i32 21, float %5275)  ; Exp(value)
  %5279 = call float @dx.op.unary.f32(i32 21, float %5276)  ; Exp(value)
  %5280 = fsub fast float %5262, %5277
  %5281 = fsub fast float %5263, %5278
  %5282 = fsub fast float %5264, %5279
  %5283 = fmul fast float %5280, %5259
  %5284 = fmul fast float %5281, %5260
  %5285 = fmul fast float %5282, %5261
  %5286 = fadd fast float %5283, %5277
  %5287 = fadd fast float %5284, %5278
  %5288 = fadd fast float %5285, %5279
  br label %5504

; <label>:5289                                    ; preds = %5244
  %5290 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5247, i32 %5248, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5291 = extractvalue %dx.types.ResRet.f32 %5290, 0
  %5292 = fcmp fast ogt float %38, 5.000000e-01
  %5293 = fcmp fast olt float %5291, 1.000000e+00
  %5294 = and i1 %5292, %5293
  br i1 %5294, label %5295, label %5433

; <label>:5295                                    ; preds = %5289
  %5296 = sitofp i32 %5247 to float
  %5297 = sitofp i32 %5248 to float
  %5298 = fadd fast float %5296, 5.000000e-01
  %5299 = fadd fast float %5297, 5.000000e-01
  %5300 = fdiv fast float %5298, %45
  %5301 = fdiv fast float %5299, %46
  %5302 = fmul fast float %5300, 2.000000e+00
  %5303 = fmul fast float %5301, 2.000000e+00
  %5304 = fadd fast float %5302, -1.000000e+00
  %5305 = fsub fast float 1.000000e+00, %5303
  %5306 = fmul fast float %5304, %35
  %5307 = call float @dx.op.tertiary.f32(i32 46, float %5305, float %31, float %5306)  ; FMad(a,b,c)
  %5308 = call float @dx.op.tertiary.f32(i32 46, float %5291, float %27, float %5307)  ; FMad(a,b,c)
  %5309 = fadd fast float %5308, %23
  %5310 = call float @dx.op.unary.f32(i32 6, float %5309)  ; FAbs(value)
  %5311 = fcmp fast ogt float %5310, 0x3EB0C6F7A0000000
  br i1 %5311, label %5312, label %5433

; <label>:5312                                    ; preds = %5295
  %5313 = fmul fast float %5304, %34
  %5314 = call float @dx.op.tertiary.f32(i32 46, float %5305, float %30, float %5313)  ; FMad(a,b,c)
  %5315 = call float @dx.op.tertiary.f32(i32 46, float %5291, float %26, float %5314)  ; FMad(a,b,c)
  %5316 = fadd fast float %5315, %22
  %5317 = fmul fast float %5304, %33
  %5318 = call float @dx.op.tertiary.f32(i32 46, float %5305, float %29, float %5317)  ; FMad(a,b,c)
  %5319 = call float @dx.op.tertiary.f32(i32 46, float %5291, float %25, float %5318)  ; FMad(a,b,c)
  %5320 = fadd fast float %5319, %21
  %5321 = fmul fast float %5304, %32
  %5322 = call float @dx.op.tertiary.f32(i32 46, float %5305, float %28, float %5321)  ; FMad(a,b,c)
  %5323 = call float @dx.op.tertiary.f32(i32 46, float %5291, float %24, float %5322)  ; FMad(a,b,c)
  %5324 = fadd fast float %5323, %20
  %5325 = fdiv fast float %5324, %5309
  %5326 = fdiv fast float %5320, %5309
  %5327 = fdiv fast float %5316, %5309
  %5328 = fsub fast float %5325, %17
  %5329 = fsub fast float %5326, %18
  %5330 = fsub fast float %5327, %19
  %5331 = fmul fast float %5328, %5328
  %5332 = fmul fast float %5329, %5329
  %5333 = fadd fast float %5332, %5331
  %5334 = fmul fast float %5330, %5330
  %5335 = fadd fast float %5333, %5334
  %5336 = call float @dx.op.unary.f32(i32 24, float %5335)  ; Sqrt(value)
  %5337 = fsub fast float %5336, %9
  %5338 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5337)  ; FMax(a,b)
  %5339 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %5339, label %5340, label %5363

; <label>:5340                                    ; preds = %5312
  %5341 = call float @dx.op.unary.f32(i32 6, float %5329)  ; FAbs(value)
  %5342 = fmul fast float %5341, %11
  %5343 = fcmp fast olt float %5342, 0x3F50624DE0000000
  br i1 %5343, label %5344, label %5347

; <label>:5344                                    ; preds = %5340
  %5345 = fmul fast float %5342, 5.000000e-01
  %5346 = fsub fast float 1.000000e+00, %5345
  br label %5352

; <label>:5347                                    ; preds = %5340
  %5348 = fmul fast float %5342, 0xBFF7154760000000
  %5349 = call float @dx.op.unary.f32(i32 21, float %5348)  ; Exp(value)
  %5350 = fsub fast float 1.000000e+00, %5349
  %5351 = fdiv fast float %5350, %5342
  br label %5352

; <label>:5352                                    ; preds = %5347, %5344
  %5353 = phi float [ %5346, %5344 ], [ %5351, %5347 ]
  %5354 = call float @dx.op.binary.f32(i32 36, float %5326, float %18)  ; FMin(a,b)
  %5355 = fsub fast float %5354, %10
  %5356 = fmul fast float %11, %5355
  %5357 = fsub fast float -0.000000e+00, %5356
  %5358 = call float @dx.op.binary.f32(i32 35, float %5357, float -4.000000e+01)  ; FMax(a,b)
  %5359 = call float @dx.op.binary.f32(i32 36, float %5358, float 5.000000e+00)  ; FMin(a,b)
  %5360 = fmul fast float %5359, 0x3FF7154760000000
  %5361 = call float @dx.op.unary.f32(i32 21, float %5360)  ; Exp(value)
  %5362 = fmul fast float %5361, %5353
  br label %5363

; <label>:5363                                    ; preds = %5352, %5312
  %5364 = phi float [ %5362, %5352 ], [ 1.000000e+00, %5312 ]
  %5365 = fmul fast float %5338, %16
  %5366 = fmul fast float %5365, %5364
  %5367 = fcmp fast ole float %5336, %9
  %5368 = fcmp fast olt float %5336, 0x3F1A36E2E0000000
  %5369 = or i1 %5367, %5368
  br i1 %5369, label %5416, label %5370

; <label>:5370                                    ; preds = %5363
  %5371 = fdiv fast float %9, %5336
  %5372 = fmul fast float %5371, %5328
  %5373 = fmul fast float %5371, %5329
  %5374 = fmul fast float %5371, %5330
  %5375 = fadd fast float %5372, %17
  %5376 = fadd fast float %5373, %18
  %5377 = fadd fast float %5374, %19
  %5378 = fadd fast float %5375, -9.000000e+02
  %5379 = fadd fast float %5376, -1.500000e+01
  %5380 = fadd fast float %5377, -7.500000e+02
  %5381 = fmul fast float %5378, 0x3F62345680000000
  %5382 = fmul fast float %5379, 0x3F62345680000000
  %5383 = fmul fast float %5380, 0x3F62345680000000
  %5384 = call float @dx.op.dot3.f32(i32 55, float %5381, float %5382, float %5383, float %5381, float %5382, float %5383)  ; Dot3(ax,ay,az,bx,by,bz)
  %5385 = fsub fast float 1.000000e+00, %5384
  %5386 = call float @dx.op.unary.f32(i32 7, float %5385)  ; Saturate(value)
  %5387 = fmul fast float %5386, %5386
  %5388 = fadd fast float %5375, %5325
  %5389 = fadd fast float %5376, %5326
  %5390 = fadd fast float %5377, %5327
  %5391 = fmul fast float %5388, 0x3F52345680000000
  %5392 = fadd fast float %5391, -2.000000e+00
  %5393 = fmul fast float %5389, 0x3F52345680000000
  %5394 = fadd fast float %5393, 0xBFA1111120000000
  %5395 = fmul fast float %5390, 0x3F52345680000000
  %5396 = fadd fast float %5395, 0xBFFAAAAAC0000000
  %5397 = call float @dx.op.dot3.f32(i32 55, float %5392, float %5394, float %5396, float %5392, float %5394, float %5396)  ; Dot3(ax,ay,az,bx,by,bz)
  %5398 = fsub fast float 1.000000e+00, %5397
  %5399 = call float @dx.op.unary.f32(i32 7, float %5398)  ; Saturate(value)
  %5400 = fmul fast float %5399, %5399
  %5401 = fmul fast float %5400, 4.000000e+00
  %5402 = fadd fast float %5401, %5387
  %5403 = fadd fast float %5325, -9.000000e+02
  %5404 = fadd fast float %5326, -1.500000e+01
  %5405 = fadd fast float %5327, -7.500000e+02
  %5406 = fmul fast float %5403, 0x3F62345680000000
  %5407 = fmul fast float %5404, 0x3F62345680000000
  %5408 = fmul fast float %5405, 0x3F62345680000000
  %5409 = call float @dx.op.dot3.f32(i32 55, float %5406, float %5407, float %5408, float %5406, float %5407, float %5408)  ; Dot3(ax,ay,az,bx,by,bz)
  %5410 = fsub fast float 1.000000e+00, %5409
  %5411 = call float @dx.op.unary.f32(i32 7, float %5410)  ; Saturate(value)
  %5412 = fmul fast float %5411, %5411
  %5413 = fadd fast float %5402, %5412
  %5414 = fmul fast float %5337, 0x3F25D867E0000000
  %5415 = fmul fast float %5414, %5413
  br label %5416

; <label>:5416                                    ; preds = %5370, %5363
  %5417 = phi float [ %5415, %5370 ], [ 0.000000e+00, %5363 ]
  %5418 = fadd fast float %5417, %5366
  %5419 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %5418)  ; FMin(a,b)
  %5420 = fmul fast float %5419, 0xBFF7154760000000
  %5421 = call float @dx.op.unary.f32(i32 21, float %5420)  ; Exp(value)
  %5422 = fsub fast float 1.000000e+00, %5421
  %5423 = call float @dx.op.binary.f32(i32 36, float %12, float %5422)  ; FMin(a,b)
  %5424 = fsub fast float %13, %5250
  %5425 = fsub fast float %14, %5251
  %5426 = fsub fast float %15, %5252
  %5427 = fmul fast float %5423, %5424
  %5428 = fmul fast float %5423, %5425
  %5429 = fmul fast float %5423, %5426
  %5430 = fadd fast float %5427, %5250
  %5431 = fadd fast float %5428, %5251
  %5432 = fadd fast float %5429, %5252
  br label %5433

; <label>:5433                                    ; preds = %5416, %5295, %5289
  %5434 = phi float [ %5430, %5416 ], [ %5250, %5295 ], [ %5250, %5289 ]
  %5435 = phi float [ %5431, %5416 ], [ %5251, %5295 ], [ %5251, %5289 ]
  %5436 = phi float [ %5432, %5416 ], [ %5252, %5295 ], [ %5252, %5289 ]
  %5437 = fadd fast float %5, 1.000000e+00
  %5438 = fadd fast float %6, 1.000000e+00
  %5439 = fsub fast float 1.000000e+00, %5
  %5440 = fmul fast float %36, %5437
  %5441 = fmul fast float %36, %5438
  %5442 = fmul fast float %36, %5439
  %5443 = fmul fast float %5440, %5434
  %5444 = fmul fast float %5441, %5435
  %5445 = fmul fast float %5442, %5436
  %5446 = fcmp fast ult float %37, 5.000000e-01
  br i1 %5446, label %5472, label %5447

; <label>:5447                                    ; preds = %5433
  %5448 = fmul fast float %5443, 0x4004147AE0000000
  %5449 = fmul fast float %5444, 0x4004147AE0000000
  %5450 = fmul fast float %5445, 0x4004147AE0000000
  %5451 = fadd fast float %5448, 0x3F9EB851E0000000
  %5452 = fadd fast float %5449, 0x3F9EB851E0000000
  %5453 = fadd fast float %5450, 0x3F9EB851E0000000
  %5454 = fmul fast float %5451, %5443
  %5455 = fmul fast float %5452, %5444
  %5456 = fmul fast float %5453, %5445
  %5457 = fmul fast float %5443, 0x400370A3E0000000
  %5458 = fmul fast float %5444, 0x400370A3E0000000
  %5459 = fmul fast float %5445, 0x400370A3E0000000
  %5460 = fadd fast float %5457, 0x3FE2E147A0000000
  %5461 = fadd fast float %5458, 0x3FE2E147A0000000
  %5462 = fadd fast float %5459, 0x3FE2E147A0000000
  %5463 = fmul fast float %5460, %5443
  %5464 = fmul fast float %5461, %5444
  %5465 = fmul fast float %5462, %5445
  %5466 = fadd fast float %5463, 0x3FC1EB8520000000
  %5467 = fadd fast float %5464, 0x3FC1EB8520000000
  %5468 = fadd fast float %5465, 0x3FC1EB8520000000
  %5469 = fdiv fast float %5454, %5466
  %5470 = fdiv fast float %5455, %5467
  %5471 = fdiv fast float %5456, %5468
  br label %5472

; <label>:5472                                    ; preds = %5447, %5433
  %5473 = phi float [ %5469, %5447 ], [ %5443, %5433 ]
  %5474 = phi float [ %5470, %5447 ], [ %5444, %5433 ]
  %5475 = phi float [ %5471, %5447 ], [ %5445, %5433 ]
  %5476 = call float @dx.op.unary.f32(i32 7, float %5473)  ; Saturate(value)
  %5477 = call float @dx.op.unary.f32(i32 7, float %5474)  ; Saturate(value)
  %5478 = call float @dx.op.unary.f32(i32 7, float %5475)  ; Saturate(value)
  %5479 = call float @dx.op.dot3.f32(i32 55, float %5476, float %5477, float %5478, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5480 = fsub fast float %5476, %5479
  %5481 = fsub fast float %5477, %5479
  %5482 = fsub fast float %5478, %5479
  %5483 = fmul fast float %5480, %8
  %5484 = fmul fast float %5481, %8
  %5485 = fmul fast float %5482, %8
  %5486 = fadd fast float %5483, %5479
  %5487 = fadd fast float %5484, %5479
  %5488 = fadd fast float %5485, %5479
  %5489 = call float @dx.op.unary.f32(i32 7, float %5486)  ; Saturate(value)
  %5490 = call float @dx.op.unary.f32(i32 7, float %5487)  ; Saturate(value)
  %5491 = call float @dx.op.unary.f32(i32 7, float %5488)  ; Saturate(value)
  %5492 = fadd fast float %5489, 0xBFC70A3D80000000
  %5493 = fadd fast float %5490, 0xBFC70A3D80000000
  %5494 = fadd fast float %5491, 0xBFC70A3D80000000
  %5495 = fmul fast float %5492, %7
  %5496 = fmul fast float %5493, %7
  %5497 = fmul fast float %5494, %7
  %5498 = fadd fast float %5495, 0x3FC70A3D80000000
  %5499 = fadd fast float %5496, 0x3FC70A3D80000000
  %5500 = fadd fast float %5497, 0x3FC70A3D80000000
  %5501 = call float @dx.op.unary.f32(i32 7, float %5498)  ; Saturate(value)
  %5502 = call float @dx.op.unary.f32(i32 7, float %5499)  ; Saturate(value)
  %5503 = call float @dx.op.unary.f32(i32 7, float %5500)  ; Saturate(value)
  br label %5504

; <label>:5504                                    ; preds = %5472, %5255
  %5505 = phi float [ %5286, %5255 ], [ %5501, %5472 ]
  %5506 = phi float [ %5287, %5255 ], [ %5502, %5472 ]
  %5507 = phi float [ %5288, %5255 ], [ %5503, %5472 ]
  %5508 = fsub fast float %5505, %4359
  %5509 = fsub fast float %5506, %4360
  %5510 = fsub fast float %5507, %4361
  %5511 = fmul fast float %5508, %5242
  %5512 = fmul fast float %5509, %5242
  %5513 = fmul fast float %5510, %5242
  %5514 = fadd fast float %5511, %4359
  %5515 = fadd fast float %5512, %4360
  %5516 = fadd fast float %5513, %4361
  br label %5517

; <label>:5517                                    ; preds = %5504, %5229
  %5518 = phi float [ %5514, %5504 ], [ %4359, %5229 ]
  %5519 = phi float [ %5515, %5504 ], [ %4360, %5229 ]
  %5520 = phi float [ %5516, %5504 ], [ %4361, %5229 ]
  %5521 = call float @dx.op.binary.f32(i32 36, float %5230, float %5518)  ; FMin(a,b)
  %5522 = call float @dx.op.binary.f32(i32 36, float %5231, float %5519)  ; FMin(a,b)
  %5523 = call float @dx.op.binary.f32(i32 36, float %5232, float %5520)  ; FMin(a,b)
  %5524 = call float @dx.op.binary.f32(i32 36, float %4652, float %4940)  ; FMin(a,b)
  %5525 = call float @dx.op.binary.f32(i32 36, float %4653, float %4941)  ; FMin(a,b)
  %5526 = call float @dx.op.binary.f32(i32 36, float %4654, float %4942)  ; FMin(a,b)
  %5527 = call float @dx.op.binary.f32(i32 36, float %5524, float %5521)  ; FMin(a,b)
  %5528 = call float @dx.op.binary.f32(i32 36, float %5525, float %5522)  ; FMin(a,b)
  %5529 = call float @dx.op.binary.f32(i32 36, float %5526, float %5523)  ; FMin(a,b)
  %5530 = call float @dx.op.binary.f32(i32 36, float %4359, float %5527)  ; FMin(a,b)
  %5531 = call float @dx.op.binary.f32(i32 36, float %4360, float %5528)  ; FMin(a,b)
  %5532 = call float @dx.op.binary.f32(i32 36, float %4361, float %5529)  ; FMin(a,b)
  %5533 = call float @dx.op.binary.f32(i32 35, float %5230, float %5518)  ; FMax(a,b)
  %5534 = call float @dx.op.binary.f32(i32 35, float %5231, float %5519)  ; FMax(a,b)
  %5535 = call float @dx.op.binary.f32(i32 35, float %5232, float %5520)  ; FMax(a,b)
  %5536 = call float @dx.op.binary.f32(i32 35, float %4652, float %4940)  ; FMax(a,b)
  %5537 = call float @dx.op.binary.f32(i32 35, float %4653, float %4941)  ; FMax(a,b)
  %5538 = call float @dx.op.binary.f32(i32 35, float %4654, float %4942)  ; FMax(a,b)
  %5539 = call float @dx.op.binary.f32(i32 35, float %5536, float %5533)  ; FMax(a,b)
  %5540 = call float @dx.op.binary.f32(i32 35, float %5537, float %5534)  ; FMax(a,b)
  %5541 = call float @dx.op.binary.f32(i32 35, float %5538, float %5535)  ; FMax(a,b)
  %5542 = call float @dx.op.binary.f32(i32 35, float %4359, float %5539)  ; FMax(a,b)
  %5543 = call float @dx.op.binary.f32(i32 35, float %4360, float %5540)  ; FMax(a,b)
  %5544 = call float @dx.op.binary.f32(i32 35, float %4361, float %5541)  ; FMax(a,b)
  %5545 = fsub fast float %5542, %5530
  %5546 = fsub fast float %5543, %5531
  %5547 = fsub fast float %5544, %5532
  %5548 = call float @dx.op.unary.f32(i32 6, float %5545)  ; FAbs(value)
  %5549 = call float @dx.op.unary.f32(i32 6, float %5546)  ; FAbs(value)
  %5550 = call float @dx.op.unary.f32(i32 6, float %5547)  ; FAbs(value)
  %5551 = call float @dx.op.binary.f32(i32 35, float %5549, float %5550)  ; FMax(a,b)
  %5552 = call float @dx.op.binary.f32(i32 35, float %5548, float %5551)  ; FMax(a,b)
  %5553 = call float @dx.op.binary.f32(i32 35, float %5543, float %5544)  ; FMax(a,b)
  %5554 = call float @dx.op.binary.f32(i32 35, float %5542, float %5553)  ; FMax(a,b)
  %5555 = fmul fast float %5554, 1.250000e-01
  %5556 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %5555)  ; FMax(a,b)
  %5557 = fcmp fast ogt float %5552, %5556
  br i1 %5557, label %5558, label %5619

; <label>:5558                                    ; preds = %5517
  %5559 = fsub fast float %4652, %4940
  %5560 = fsub fast float %4653, %4941
  %5561 = fsub fast float %4654, %4942
  %5562 = call float @dx.op.unary.f32(i32 6, float %5559)  ; FAbs(value)
  %5563 = call float @dx.op.unary.f32(i32 6, float %5560)  ; FAbs(value)
  %5564 = call float @dx.op.unary.f32(i32 6, float %5561)  ; FAbs(value)
  %5565 = call float @dx.op.binary.f32(i32 35, float %5563, float %5564)  ; FMax(a,b)
  %5566 = call float @dx.op.binary.f32(i32 35, float %5562, float %5565)  ; FMax(a,b)
  %5567 = fsub fast float %5230, %5518
  %5568 = fsub fast float %5231, %5519
  %5569 = fsub fast float %5232, %5520
  %5570 = call float @dx.op.unary.f32(i32 6, float %5567)  ; FAbs(value)
  %5571 = call float @dx.op.unary.f32(i32 6, float %5568)  ; FAbs(value)
  %5572 = call float @dx.op.unary.f32(i32 6, float %5569)  ; FAbs(value)
  %5573 = call float @dx.op.binary.f32(i32 35, float %5571, float %5572)  ; FMax(a,b)
  %5574 = call float @dx.op.binary.f32(i32 35, float %5570, float %5573)  ; FMax(a,b)
  %5575 = fcmp fast olt float %5566, %5574
  %5576 = select i1 %5575, float %4652, float %5230
  %5577 = select i1 %5575, float %4653, float %5231
  %5578 = select i1 %5575, float %4654, float %5232
  %5579 = select i1 %5575, float %4940, float %5518
  %5580 = select i1 %5575, float %4941, float %5519
  %5581 = select i1 %5575, float %4942, float %5520
  %5582 = fsub fast float %4359, %5579
  %5583 = fsub fast float %4360, %5580
  %5584 = fsub fast float %4361, %5581
  %5585 = fsub fast float %4359, %5576
  %5586 = fsub fast float %4360, %5577
  %5587 = fsub fast float %4361, %5578
  %5588 = call float @dx.op.dot3.f32(i32 55, float %5585, float %5586, float %5587, float %5582, float %5583, float %5584)  ; Dot3(ax,ay,az,bx,by,bz)
  %5589 = fcmp fast ogt float %5588, 0.000000e+00
  br i1 %5589, label %5590, label %5601

; <label>:5590                                    ; preds = %5558
  %5591 = fsub fast float %5576, %5579
  %5592 = fsub fast float %5577, %5580
  %5593 = fsub fast float %5578, %5581
  %5594 = call float @dx.op.unary.f32(i32 6, float %5591)  ; FAbs(value)
  %5595 = call float @dx.op.unary.f32(i32 6, float %5592)  ; FAbs(value)
  %5596 = call float @dx.op.unary.f32(i32 6, float %5593)  ; FAbs(value)
  %5597 = call float @dx.op.binary.f32(i32 35, float %5595, float %5596)  ; FMax(a,b)
  %5598 = call float @dx.op.binary.f32(i32 35, float %5594, float %5597)  ; FMax(a,b)
  %5599 = fmul fast float %5552, 2.500000e-01
  %5600 = fcmp fast olt float %5598, %5599
  br label %5601

; <label>:5601                                    ; preds = %5590, %5558
  %5602 = phi i1 [ false, %5558 ], [ %5600, %5590 ]
  %5603 = select i1 %5602, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  %5604 = fadd fast float %5576, %5579
  %5605 = fadd fast float %5577, %5580
  %5606 = fadd fast float %5578, %5581
  %5607 = fmul fast float %5604, 5.000000e-01
  %5608 = fmul fast float %5605, 5.000000e-01
  %5609 = fmul fast float %5606, 5.000000e-01
  %5610 = fsub fast float %5607, %4359
  %5611 = fsub fast float %5608, %4360
  %5612 = fsub fast float %5609, %4361
  %5613 = fmul fast float %5603, %5610
  %5614 = fmul fast float %5603, %5611
  %5615 = fmul fast float %5603, %5612
  %5616 = fadd fast float %5613, %4359
  %5617 = fadd fast float %5614, %4360
  %5618 = fadd fast float %5615, %4361
  br label %5619

; <label>:5619                                    ; preds = %5601, %5517, %4114
  %5620 = phi float [ %4145, %4114 ], [ %5616, %5601 ], [ %4359, %5517 ]
  %5621 = phi float [ %4146, %4114 ], [ %5617, %5601 ], [ %4360, %5517 ]
  %5622 = phi float [ %4147, %4114 ], [ %5618, %5601 ], [ %4361, %5517 ]
  %5623 = phi float [ %4148, %4114 ], [ %4112, %5601 ], [ %4112, %5517 ]
  %5624 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %67, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5625 = extractvalue %dx.types.ResRet.f32 %5624, 0
  %5626 = extractvalue %dx.types.ResRet.f32 %5624, 1
  %5627 = extractvalue %dx.types.ResRet.f32 %5624, 2
  %5628 = extractvalue %dx.types.ResRet.f32 %5624, 3
  %5629 = fcmp fast olt float %5628, 0.000000e+00
  br i1 %5629, label %5630, label %5665

; <label>:5630                                    ; preds = %5619
  %5631 = fcmp fast ogt float %5625, 0x3FA4B5DCC0000000
  %5632 = fcmp fast ogt float %5626, 0x3FA4B5DCC0000000
  %5633 = fcmp fast ogt float %5627, 0x3FA4B5DCC0000000
  %5634 = select i1 %5631, float 0.000000e+00, float 1.000000e+00
  %5635 = select i1 %5632, float 0.000000e+00, float 1.000000e+00
  %5636 = select i1 %5633, float 0.000000e+00, float 1.000000e+00
  %5637 = fmul fast float %5625, 0x3FB3D07220000000
  %5638 = fmul fast float %5626, 0x3FB3D07220000000
  %5639 = fmul fast float %5627, 0x3FB3D07220000000
  %5640 = fadd fast float %5625, 0x3FAC28F5C0000000
  %5641 = fadd fast float %5626, 0x3FAC28F5C0000000
  %5642 = fadd fast float %5627, 0x3FAC28F5C0000000
  %5643 = fmul fast float %5640, 0x3FEE54EDE0000000
  %5644 = fmul fast float %5641, 0x3FEE54EDE0000000
  %5645 = fmul fast float %5642, 0x3FEE54EDE0000000
  %5646 = call float @dx.op.unary.f32(i32 23, float %5643)  ; Log(value)
  %5647 = call float @dx.op.unary.f32(i32 23, float %5644)  ; Log(value)
  %5648 = call float @dx.op.unary.f32(i32 23, float %5645)  ; Log(value)
  %5649 = fmul fast float %5646, 0x4003333340000000
  %5650 = fmul fast float %5647, 0x4003333340000000
  %5651 = fmul fast float %5648, 0x4003333340000000
  %5652 = call float @dx.op.unary.f32(i32 21, float %5649)  ; Exp(value)
  %5653 = call float @dx.op.unary.f32(i32 21, float %5650)  ; Exp(value)
  %5654 = call float @dx.op.unary.f32(i32 21, float %5651)  ; Exp(value)
  %5655 = fsub fast float %5637, %5652
  %5656 = fsub fast float %5638, %5653
  %5657 = fsub fast float %5639, %5654
  %5658 = fmul fast float %5655, %5634
  %5659 = fmul fast float %5656, %5635
  %5660 = fmul fast float %5657, %5636
  %5661 = fadd fast float %5658, %5652
  %5662 = fadd fast float %5659, %5653
  %5663 = fadd fast float %5660, %5654
  %5664 = fsub fast float -1.000000e+00, %5628
  br label %7135

; <label>:5665                                    ; preds = %5619
  %5666 = fcmp fast ogt float %38, 5.000000e-01
  %5667 = fcmp fast olt float %84, 1.000000e+00
  %5668 = and i1 %5666, %5667
  br i1 %5668, label %5669, label %5807

; <label>:5669                                    ; preds = %5665
  %5670 = sitofp i32 %67 to float
  %5671 = sitofp i32 %64 to float
  %5672 = fadd fast float %5670, 5.000000e-01
  %5673 = fadd fast float %5671, 5.000000e-01
  %5674 = fdiv fast float %5672, %45
  %5675 = fdiv fast float %5673, %46
  %5676 = fmul fast float %5674, 2.000000e+00
  %5677 = fmul fast float %5675, 2.000000e+00
  %5678 = fadd fast float %5676, -1.000000e+00
  %5679 = fsub fast float 1.000000e+00, %5677
  %5680 = fmul fast float %5678, %35
  %5681 = call float @dx.op.tertiary.f32(i32 46, float %5679, float %31, float %5680)  ; FMad(a,b,c)
  %5682 = call float @dx.op.tertiary.f32(i32 46, float %84, float %27, float %5681)  ; FMad(a,b,c)
  %5683 = fadd fast float %5682, %23
  %5684 = call float @dx.op.unary.f32(i32 6, float %5683)  ; FAbs(value)
  %5685 = fcmp fast ogt float %5684, 0x3EB0C6F7A0000000
  br i1 %5685, label %5686, label %5807

; <label>:5686                                    ; preds = %5669
  %5687 = fmul fast float %5678, %34
  %5688 = call float @dx.op.tertiary.f32(i32 46, float %5679, float %30, float %5687)  ; FMad(a,b,c)
  %5689 = call float @dx.op.tertiary.f32(i32 46, float %84, float %26, float %5688)  ; FMad(a,b,c)
  %5690 = fadd fast float %5689, %22
  %5691 = fmul fast float %5678, %33
  %5692 = call float @dx.op.tertiary.f32(i32 46, float %5679, float %29, float %5691)  ; FMad(a,b,c)
  %5693 = call float @dx.op.tertiary.f32(i32 46, float %84, float %25, float %5692)  ; FMad(a,b,c)
  %5694 = fadd fast float %5693, %21
  %5695 = fmul fast float %5678, %32
  %5696 = call float @dx.op.tertiary.f32(i32 46, float %5679, float %28, float %5695)  ; FMad(a,b,c)
  %5697 = call float @dx.op.tertiary.f32(i32 46, float %84, float %24, float %5696)  ; FMad(a,b,c)
  %5698 = fadd fast float %5697, %20
  %5699 = fdiv fast float %5698, %5683
  %5700 = fdiv fast float %5694, %5683
  %5701 = fdiv fast float %5690, %5683
  %5702 = fsub fast float %5699, %17
  %5703 = fsub fast float %5700, %18
  %5704 = fsub fast float %5701, %19
  %5705 = fmul fast float %5702, %5702
  %5706 = fmul fast float %5703, %5703
  %5707 = fadd fast float %5706, %5705
  %5708 = fmul fast float %5704, %5704
  %5709 = fadd fast float %5707, %5708
  %5710 = call float @dx.op.unary.f32(i32 24, float %5709)  ; Sqrt(value)
  %5711 = fsub fast float %5710, %9
  %5712 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5711)  ; FMax(a,b)
  %5713 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %5713, label %5714, label %5737

; <label>:5714                                    ; preds = %5686
  %5715 = call float @dx.op.unary.f32(i32 6, float %5703)  ; FAbs(value)
  %5716 = fmul fast float %5715, %11
  %5717 = fcmp fast olt float %5716, 0x3F50624DE0000000
  br i1 %5717, label %5718, label %5721

; <label>:5718                                    ; preds = %5714
  %5719 = fmul fast float %5716, 5.000000e-01
  %5720 = fsub fast float 1.000000e+00, %5719
  br label %5726

; <label>:5721                                    ; preds = %5714
  %5722 = fmul fast float %5716, 0xBFF7154760000000
  %5723 = call float @dx.op.unary.f32(i32 21, float %5722)  ; Exp(value)
  %5724 = fsub fast float 1.000000e+00, %5723
  %5725 = fdiv fast float %5724, %5716
  br label %5726

; <label>:5726                                    ; preds = %5721, %5718
  %5727 = phi float [ %5720, %5718 ], [ %5725, %5721 ]
  %5728 = call float @dx.op.binary.f32(i32 36, float %5700, float %18)  ; FMin(a,b)
  %5729 = fsub fast float %5728, %10
  %5730 = fmul fast float %11, %5729
  %5731 = fsub fast float -0.000000e+00, %5730
  %5732 = call float @dx.op.binary.f32(i32 35, float %5731, float -4.000000e+01)  ; FMax(a,b)
  %5733 = call float @dx.op.binary.f32(i32 36, float %5732, float 5.000000e+00)  ; FMin(a,b)
  %5734 = fmul fast float %5733, 0x3FF7154760000000
  %5735 = call float @dx.op.unary.f32(i32 21, float %5734)  ; Exp(value)
  %5736 = fmul fast float %5735, %5727
  br label %5737

; <label>:5737                                    ; preds = %5726, %5686
  %5738 = phi float [ %5736, %5726 ], [ 1.000000e+00, %5686 ]
  %5739 = fmul fast float %5712, %16
  %5740 = fmul fast float %5739, %5738
  %5741 = fcmp fast ole float %5710, %9
  %5742 = fcmp fast olt float %5710, 0x3F1A36E2E0000000
  %5743 = or i1 %5741, %5742
  br i1 %5743, label %5790, label %5744

; <label>:5744                                    ; preds = %5737
  %5745 = fdiv fast float %9, %5710
  %5746 = fmul fast float %5745, %5702
  %5747 = fmul fast float %5745, %5703
  %5748 = fmul fast float %5745, %5704
  %5749 = fadd fast float %5746, %17
  %5750 = fadd fast float %5747, %18
  %5751 = fadd fast float %5748, %19
  %5752 = fadd fast float %5749, -9.000000e+02
  %5753 = fadd fast float %5750, -1.500000e+01
  %5754 = fadd fast float %5751, -7.500000e+02
  %5755 = fmul fast float %5752, 0x3F62345680000000
  %5756 = fmul fast float %5753, 0x3F62345680000000
  %5757 = fmul fast float %5754, 0x3F62345680000000
  %5758 = call float @dx.op.dot3.f32(i32 55, float %5755, float %5756, float %5757, float %5755, float %5756, float %5757)  ; Dot3(ax,ay,az,bx,by,bz)
  %5759 = fsub fast float 1.000000e+00, %5758
  %5760 = call float @dx.op.unary.f32(i32 7, float %5759)  ; Saturate(value)
  %5761 = fmul fast float %5760, %5760
  %5762 = fadd fast float %5749, %5699
  %5763 = fadd fast float %5750, %5700
  %5764 = fadd fast float %5751, %5701
  %5765 = fmul fast float %5762, 0x3F52345680000000
  %5766 = fadd fast float %5765, -2.000000e+00
  %5767 = fmul fast float %5763, 0x3F52345680000000
  %5768 = fadd fast float %5767, 0xBFA1111120000000
  %5769 = fmul fast float %5764, 0x3F52345680000000
  %5770 = fadd fast float %5769, 0xBFFAAAAAC0000000
  %5771 = call float @dx.op.dot3.f32(i32 55, float %5766, float %5768, float %5770, float %5766, float %5768, float %5770)  ; Dot3(ax,ay,az,bx,by,bz)
  %5772 = fsub fast float 1.000000e+00, %5771
  %5773 = call float @dx.op.unary.f32(i32 7, float %5772)  ; Saturate(value)
  %5774 = fmul fast float %5773, %5773
  %5775 = fmul fast float %5774, 4.000000e+00
  %5776 = fadd fast float %5775, %5761
  %5777 = fadd fast float %5699, -9.000000e+02
  %5778 = fadd fast float %5700, -1.500000e+01
  %5779 = fadd fast float %5701, -7.500000e+02
  %5780 = fmul fast float %5777, 0x3F62345680000000
  %5781 = fmul fast float %5778, 0x3F62345680000000
  %5782 = fmul fast float %5779, 0x3F62345680000000
  %5783 = call float @dx.op.dot3.f32(i32 55, float %5780, float %5781, float %5782, float %5780, float %5781, float %5782)  ; Dot3(ax,ay,az,bx,by,bz)
  %5784 = fsub fast float 1.000000e+00, %5783
  %5785 = call float @dx.op.unary.f32(i32 7, float %5784)  ; Saturate(value)
  %5786 = fmul fast float %5785, %5785
  %5787 = fadd fast float %5776, %5786
  %5788 = fmul fast float %5711, 0x3F25D867E0000000
  %5789 = fmul fast float %5788, %5787
  br label %5790

; <label>:5790                                    ; preds = %5744, %5737
  %5791 = phi float [ %5789, %5744 ], [ 0.000000e+00, %5737 ]
  %5792 = fadd fast float %5791, %5740
  %5793 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %5792)  ; FMin(a,b)
  %5794 = fmul fast float %5793, 0xBFF7154760000000
  %5795 = call float @dx.op.unary.f32(i32 21, float %5794)  ; Exp(value)
  %5796 = fsub fast float 1.000000e+00, %5795
  %5797 = call float @dx.op.binary.f32(i32 36, float %12, float %5796)  ; FMin(a,b)
  %5798 = fsub fast float %13, %5625
  %5799 = fsub fast float %14, %5626
  %5800 = fsub fast float %15, %5627
  %5801 = fmul fast float %5797, %5798
  %5802 = fmul fast float %5797, %5799
  %5803 = fmul fast float %5797, %5800
  %5804 = fadd fast float %5801, %5625
  %5805 = fadd fast float %5802, %5626
  %5806 = fadd fast float %5803, %5627
  br label %5807

; <label>:5807                                    ; preds = %5790, %5669, %5665
  %5808 = phi float [ %5804, %5790 ], [ %5625, %5669 ], [ %5625, %5665 ]
  %5809 = phi float [ %5805, %5790 ], [ %5626, %5669 ], [ %5626, %5665 ]
  %5810 = phi float [ %5806, %5790 ], [ %5627, %5669 ], [ %5627, %5665 ]
  %5811 = fadd fast float %5, 1.000000e+00
  %5812 = fadd fast float %6, 1.000000e+00
  %5813 = fsub fast float 1.000000e+00, %5
  %5814 = fmul fast float %36, %5811
  %5815 = fmul fast float %36, %5812
  %5816 = fmul fast float %36, %5813
  %5817 = fmul fast float %5814, %5808
  %5818 = fmul fast float %5815, %5809
  %5819 = fmul fast float %5816, %5810
  %5820 = fcmp fast ult float %37, 5.000000e-01
  br i1 %5820, label %5846, label %5821

; <label>:5821                                    ; preds = %5807
  %5822 = fmul fast float %5817, 0x4004147AE0000000
  %5823 = fmul fast float %5818, 0x4004147AE0000000
  %5824 = fmul fast float %5819, 0x4004147AE0000000
  %5825 = fadd fast float %5822, 0x3F9EB851E0000000
  %5826 = fadd fast float %5823, 0x3F9EB851E0000000
  %5827 = fadd fast float %5824, 0x3F9EB851E0000000
  %5828 = fmul fast float %5825, %5817
  %5829 = fmul fast float %5826, %5818
  %5830 = fmul fast float %5827, %5819
  %5831 = fmul fast float %5817, 0x400370A3E0000000
  %5832 = fmul fast float %5818, 0x400370A3E0000000
  %5833 = fmul fast float %5819, 0x400370A3E0000000
  %5834 = fadd fast float %5831, 0x3FE2E147A0000000
  %5835 = fadd fast float %5832, 0x3FE2E147A0000000
  %5836 = fadd fast float %5833, 0x3FE2E147A0000000
  %5837 = fmul fast float %5834, %5817
  %5838 = fmul fast float %5835, %5818
  %5839 = fmul fast float %5836, %5819
  %5840 = fadd fast float %5837, 0x3FC1EB8520000000
  %5841 = fadd fast float %5838, 0x3FC1EB8520000000
  %5842 = fadd fast float %5839, 0x3FC1EB8520000000
  %5843 = fdiv fast float %5828, %5840
  %5844 = fdiv fast float %5829, %5841
  %5845 = fdiv fast float %5830, %5842
  br label %5846

; <label>:5846                                    ; preds = %5821, %5807
  %5847 = phi float [ %5843, %5821 ], [ %5817, %5807 ]
  %5848 = phi float [ %5844, %5821 ], [ %5818, %5807 ]
  %5849 = phi float [ %5845, %5821 ], [ %5819, %5807 ]
  %5850 = call float @dx.op.unary.f32(i32 7, float %5847)  ; Saturate(value)
  %5851 = call float @dx.op.unary.f32(i32 7, float %5848)  ; Saturate(value)
  %5852 = call float @dx.op.unary.f32(i32 7, float %5849)  ; Saturate(value)
  %5853 = call float @dx.op.dot3.f32(i32 55, float %5850, float %5851, float %5852, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5854 = fsub fast float %5850, %5853
  %5855 = fsub fast float %5851, %5853
  %5856 = fsub fast float %5852, %5853
  %5857 = fmul fast float %5854, %8
  %5858 = fmul fast float %5855, %8
  %5859 = fmul fast float %5856, %8
  %5860 = fadd fast float %5857, %5853
  %5861 = fadd fast float %5858, %5853
  %5862 = fadd fast float %5859, %5853
  %5863 = call float @dx.op.unary.f32(i32 7, float %5860)  ; Saturate(value)
  %5864 = call float @dx.op.unary.f32(i32 7, float %5861)  ; Saturate(value)
  %5865 = call float @dx.op.unary.f32(i32 7, float %5862)  ; Saturate(value)
  %5866 = fadd fast float %5863, 0xBFC70A3D80000000
  %5867 = fadd fast float %5864, 0xBFC70A3D80000000
  %5868 = fadd fast float %5865, 0xBFC70A3D80000000
  %5869 = fmul fast float %5866, %7
  %5870 = fmul fast float %5867, %7
  %5871 = fmul fast float %5868, %7
  %5872 = fadd fast float %5869, 0x3FC70A3D80000000
  %5873 = fadd fast float %5870, 0x3FC70A3D80000000
  %5874 = fadd fast float %5871, 0x3FC70A3D80000000
  %5875 = call float @dx.op.unary.f32(i32 7, float %5872)  ; Saturate(value)
  %5876 = call float @dx.op.unary.f32(i32 7, float %5873)  ; Saturate(value)
  %5877 = call float @dx.op.unary.f32(i32 7, float %5874)  ; Saturate(value)
  %5878 = add i32 %64, -1
  %5879 = call i32 @dx.op.binary.i32(i32 37, i32 %67, i32 0)  ; IMax(a,b)
  %5880 = call i32 @dx.op.binary.i32(i32 37, i32 %5878, i32 0)  ; IMax(a,b)
  %5881 = call i32 @dx.op.binary.i32(i32 38, i32 %5879, i32 %59)  ; IMin(a,b)
  %5882 = call i32 @dx.op.binary.i32(i32 38, i32 %5880, i32 %60)  ; IMin(a,b)
  %5883 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5881, i32 %5882, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5884 = extractvalue %dx.types.ResRet.f32 %5883, 0
  %5885 = fsub fast float 1.000000e+00, %84
  %5886 = fmul fast float %5885, 0x3FA99999A0000000
  %5887 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %5886)  ; FMax(a,b)
  %5888 = fsub fast float %5884, %84
  %5889 = call float @dx.op.unary.f32(i32 6, float %5888)  ; FAbs(value)
  %5890 = fdiv fast float %5889, %5887
  %5891 = fsub fast float 1.000000e+00, %5890
  %5892 = call float @dx.op.unary.f32(i32 7, float %5891)  ; Saturate(value)
  %5893 = fcmp fast ugt float %5892, 0.000000e+00
  br i1 %5893, label %5894, label %6167

; <label>:5894                                    ; preds = %5846
  %5895 = call i32 @dx.op.binary.i32(i32 37, i32 %5881, i32 0)  ; IMax(a,b)
  %5896 = call i32 @dx.op.binary.i32(i32 37, i32 %5882, i32 0)  ; IMax(a,b)
  %5897 = call i32 @dx.op.binary.i32(i32 38, i32 %5895, i32 %59)  ; IMin(a,b)
  %5898 = call i32 @dx.op.binary.i32(i32 38, i32 %5896, i32 %60)  ; IMin(a,b)
  %5899 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %5897, i32 %5898, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5900 = extractvalue %dx.types.ResRet.f32 %5899, 0
  %5901 = extractvalue %dx.types.ResRet.f32 %5899, 1
  %5902 = extractvalue %dx.types.ResRet.f32 %5899, 2
  %5903 = extractvalue %dx.types.ResRet.f32 %5899, 3
  %5904 = fcmp fast olt float %5903, 0.000000e+00
  br i1 %5904, label %5905, label %5939

; <label>:5905                                    ; preds = %5894
  %5906 = fcmp fast ogt float %5900, 0x3FA4B5DCC0000000
  %5907 = fcmp fast ogt float %5901, 0x3FA4B5DCC0000000
  %5908 = fcmp fast ogt float %5902, 0x3FA4B5DCC0000000
  %5909 = select i1 %5906, float 0.000000e+00, float 1.000000e+00
  %5910 = select i1 %5907, float 0.000000e+00, float 1.000000e+00
  %5911 = select i1 %5908, float 0.000000e+00, float 1.000000e+00
  %5912 = fmul fast float %5900, 0x3FB3D07220000000
  %5913 = fmul fast float %5901, 0x3FB3D07220000000
  %5914 = fmul fast float %5902, 0x3FB3D07220000000
  %5915 = fadd fast float %5900, 0x3FAC28F5C0000000
  %5916 = fadd fast float %5901, 0x3FAC28F5C0000000
  %5917 = fadd fast float %5902, 0x3FAC28F5C0000000
  %5918 = fmul fast float %5915, 0x3FEE54EDE0000000
  %5919 = fmul fast float %5916, 0x3FEE54EDE0000000
  %5920 = fmul fast float %5917, 0x3FEE54EDE0000000
  %5921 = call float @dx.op.unary.f32(i32 23, float %5918)  ; Log(value)
  %5922 = call float @dx.op.unary.f32(i32 23, float %5919)  ; Log(value)
  %5923 = call float @dx.op.unary.f32(i32 23, float %5920)  ; Log(value)
  %5924 = fmul fast float %5921, 0x4003333340000000
  %5925 = fmul fast float %5922, 0x4003333340000000
  %5926 = fmul fast float %5923, 0x4003333340000000
  %5927 = call float @dx.op.unary.f32(i32 21, float %5924)  ; Exp(value)
  %5928 = call float @dx.op.unary.f32(i32 21, float %5925)  ; Exp(value)
  %5929 = call float @dx.op.unary.f32(i32 21, float %5926)  ; Exp(value)
  %5930 = fsub fast float %5912, %5927
  %5931 = fsub fast float %5913, %5928
  %5932 = fsub fast float %5914, %5929
  %5933 = fmul fast float %5930, %5909
  %5934 = fmul fast float %5931, %5910
  %5935 = fmul fast float %5932, %5911
  %5936 = fadd fast float %5933, %5927
  %5937 = fadd fast float %5934, %5928
  %5938 = fadd fast float %5935, %5929
  br label %6154

; <label>:5939                                    ; preds = %5894
  %5940 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5897, i32 %5898, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5941 = extractvalue %dx.types.ResRet.f32 %5940, 0
  %5942 = fcmp fast ogt float %38, 5.000000e-01
  %5943 = fcmp fast olt float %5941, 1.000000e+00
  %5944 = and i1 %5942, %5943
  br i1 %5944, label %5945, label %6083

; <label>:5945                                    ; preds = %5939
  %5946 = sitofp i32 %5897 to float
  %5947 = sitofp i32 %5898 to float
  %5948 = fadd fast float %5946, 5.000000e-01
  %5949 = fadd fast float %5947, 5.000000e-01
  %5950 = fdiv fast float %5948, %45
  %5951 = fdiv fast float %5949, %46
  %5952 = fmul fast float %5950, 2.000000e+00
  %5953 = fmul fast float %5951, 2.000000e+00
  %5954 = fadd fast float %5952, -1.000000e+00
  %5955 = fsub fast float 1.000000e+00, %5953
  %5956 = fmul fast float %5954, %35
  %5957 = call float @dx.op.tertiary.f32(i32 46, float %5955, float %31, float %5956)  ; FMad(a,b,c)
  %5958 = call float @dx.op.tertiary.f32(i32 46, float %5941, float %27, float %5957)  ; FMad(a,b,c)
  %5959 = fadd fast float %5958, %23
  %5960 = call float @dx.op.unary.f32(i32 6, float %5959)  ; FAbs(value)
  %5961 = fcmp fast ogt float %5960, 0x3EB0C6F7A0000000
  br i1 %5961, label %5962, label %6083

; <label>:5962                                    ; preds = %5945
  %5963 = fmul fast float %5954, %34
  %5964 = call float @dx.op.tertiary.f32(i32 46, float %5955, float %30, float %5963)  ; FMad(a,b,c)
  %5965 = call float @dx.op.tertiary.f32(i32 46, float %5941, float %26, float %5964)  ; FMad(a,b,c)
  %5966 = fadd fast float %5965, %22
  %5967 = fmul fast float %5954, %33
  %5968 = call float @dx.op.tertiary.f32(i32 46, float %5955, float %29, float %5967)  ; FMad(a,b,c)
  %5969 = call float @dx.op.tertiary.f32(i32 46, float %5941, float %25, float %5968)  ; FMad(a,b,c)
  %5970 = fadd fast float %5969, %21
  %5971 = fmul fast float %5954, %32
  %5972 = call float @dx.op.tertiary.f32(i32 46, float %5955, float %28, float %5971)  ; FMad(a,b,c)
  %5973 = call float @dx.op.tertiary.f32(i32 46, float %5941, float %24, float %5972)  ; FMad(a,b,c)
  %5974 = fadd fast float %5973, %20
  %5975 = fdiv fast float %5974, %5959
  %5976 = fdiv fast float %5970, %5959
  %5977 = fdiv fast float %5966, %5959
  %5978 = fsub fast float %5975, %17
  %5979 = fsub fast float %5976, %18
  %5980 = fsub fast float %5977, %19
  %5981 = fmul fast float %5978, %5978
  %5982 = fmul fast float %5979, %5979
  %5983 = fadd fast float %5982, %5981
  %5984 = fmul fast float %5980, %5980
  %5985 = fadd fast float %5983, %5984
  %5986 = call float @dx.op.unary.f32(i32 24, float %5985)  ; Sqrt(value)
  %5987 = fsub fast float %5986, %9
  %5988 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5987)  ; FMax(a,b)
  %5989 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %5989, label %5990, label %6013

; <label>:5990                                    ; preds = %5962
  %5991 = call float @dx.op.unary.f32(i32 6, float %5979)  ; FAbs(value)
  %5992 = fmul fast float %5991, %11
  %5993 = fcmp fast olt float %5992, 0x3F50624DE0000000
  br i1 %5993, label %5994, label %5997

; <label>:5994                                    ; preds = %5990
  %5995 = fmul fast float %5992, 5.000000e-01
  %5996 = fsub fast float 1.000000e+00, %5995
  br label %6002

; <label>:5997                                    ; preds = %5990
  %5998 = fmul fast float %5992, 0xBFF7154760000000
  %5999 = call float @dx.op.unary.f32(i32 21, float %5998)  ; Exp(value)
  %6000 = fsub fast float 1.000000e+00, %5999
  %6001 = fdiv fast float %6000, %5992
  br label %6002

; <label>:6002                                    ; preds = %5997, %5994
  %6003 = phi float [ %5996, %5994 ], [ %6001, %5997 ]
  %6004 = call float @dx.op.binary.f32(i32 36, float %5976, float %18)  ; FMin(a,b)
  %6005 = fsub fast float %6004, %10
  %6006 = fmul fast float %11, %6005
  %6007 = fsub fast float -0.000000e+00, %6006
  %6008 = call float @dx.op.binary.f32(i32 35, float %6007, float -4.000000e+01)  ; FMax(a,b)
  %6009 = call float @dx.op.binary.f32(i32 36, float %6008, float 5.000000e+00)  ; FMin(a,b)
  %6010 = fmul fast float %6009, 0x3FF7154760000000
  %6011 = call float @dx.op.unary.f32(i32 21, float %6010)  ; Exp(value)
  %6012 = fmul fast float %6011, %6003
  br label %6013

; <label>:6013                                    ; preds = %6002, %5962
  %6014 = phi float [ %6012, %6002 ], [ 1.000000e+00, %5962 ]
  %6015 = fmul fast float %5988, %16
  %6016 = fmul fast float %6015, %6014
  %6017 = fcmp fast ole float %5986, %9
  %6018 = fcmp fast olt float %5986, 0x3F1A36E2E0000000
  %6019 = or i1 %6017, %6018
  br i1 %6019, label %6066, label %6020

; <label>:6020                                    ; preds = %6013
  %6021 = fdiv fast float %9, %5986
  %6022 = fmul fast float %6021, %5978
  %6023 = fmul fast float %6021, %5979
  %6024 = fmul fast float %6021, %5980
  %6025 = fadd fast float %6022, %17
  %6026 = fadd fast float %6023, %18
  %6027 = fadd fast float %6024, %19
  %6028 = fadd fast float %6025, -9.000000e+02
  %6029 = fadd fast float %6026, -1.500000e+01
  %6030 = fadd fast float %6027, -7.500000e+02
  %6031 = fmul fast float %6028, 0x3F62345680000000
  %6032 = fmul fast float %6029, 0x3F62345680000000
  %6033 = fmul fast float %6030, 0x3F62345680000000
  %6034 = call float @dx.op.dot3.f32(i32 55, float %6031, float %6032, float %6033, float %6031, float %6032, float %6033)  ; Dot3(ax,ay,az,bx,by,bz)
  %6035 = fsub fast float 1.000000e+00, %6034
  %6036 = call float @dx.op.unary.f32(i32 7, float %6035)  ; Saturate(value)
  %6037 = fmul fast float %6036, %6036
  %6038 = fadd fast float %6025, %5975
  %6039 = fadd fast float %6026, %5976
  %6040 = fadd fast float %6027, %5977
  %6041 = fmul fast float %6038, 0x3F52345680000000
  %6042 = fadd fast float %6041, -2.000000e+00
  %6043 = fmul fast float %6039, 0x3F52345680000000
  %6044 = fadd fast float %6043, 0xBFA1111120000000
  %6045 = fmul fast float %6040, 0x3F52345680000000
  %6046 = fadd fast float %6045, 0xBFFAAAAAC0000000
  %6047 = call float @dx.op.dot3.f32(i32 55, float %6042, float %6044, float %6046, float %6042, float %6044, float %6046)  ; Dot3(ax,ay,az,bx,by,bz)
  %6048 = fsub fast float 1.000000e+00, %6047
  %6049 = call float @dx.op.unary.f32(i32 7, float %6048)  ; Saturate(value)
  %6050 = fmul fast float %6049, %6049
  %6051 = fmul fast float %6050, 4.000000e+00
  %6052 = fadd fast float %6051, %6037
  %6053 = fadd fast float %5975, -9.000000e+02
  %6054 = fadd fast float %5976, -1.500000e+01
  %6055 = fadd fast float %5977, -7.500000e+02
  %6056 = fmul fast float %6053, 0x3F62345680000000
  %6057 = fmul fast float %6054, 0x3F62345680000000
  %6058 = fmul fast float %6055, 0x3F62345680000000
  %6059 = call float @dx.op.dot3.f32(i32 55, float %6056, float %6057, float %6058, float %6056, float %6057, float %6058)  ; Dot3(ax,ay,az,bx,by,bz)
  %6060 = fsub fast float 1.000000e+00, %6059
  %6061 = call float @dx.op.unary.f32(i32 7, float %6060)  ; Saturate(value)
  %6062 = fmul fast float %6061, %6061
  %6063 = fadd fast float %6052, %6062
  %6064 = fmul fast float %5987, 0x3F25D867E0000000
  %6065 = fmul fast float %6064, %6063
  br label %6066

; <label>:6066                                    ; preds = %6020, %6013
  %6067 = phi float [ %6065, %6020 ], [ 0.000000e+00, %6013 ]
  %6068 = fadd fast float %6067, %6016
  %6069 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %6068)  ; FMin(a,b)
  %6070 = fmul fast float %6069, 0xBFF7154760000000
  %6071 = call float @dx.op.unary.f32(i32 21, float %6070)  ; Exp(value)
  %6072 = fsub fast float 1.000000e+00, %6071
  %6073 = call float @dx.op.binary.f32(i32 36, float %12, float %6072)  ; FMin(a,b)
  %6074 = fsub fast float %13, %5900
  %6075 = fsub fast float %14, %5901
  %6076 = fsub fast float %15, %5902
  %6077 = fmul fast float %6073, %6074
  %6078 = fmul fast float %6073, %6075
  %6079 = fmul fast float %6073, %6076
  %6080 = fadd fast float %6077, %5900
  %6081 = fadd fast float %6078, %5901
  %6082 = fadd fast float %6079, %5902
  br label %6083

; <label>:6083                                    ; preds = %6066, %5945, %5939
  %6084 = phi float [ %6080, %6066 ], [ %5900, %5945 ], [ %5900, %5939 ]
  %6085 = phi float [ %6081, %6066 ], [ %5901, %5945 ], [ %5901, %5939 ]
  %6086 = phi float [ %6082, %6066 ], [ %5902, %5945 ], [ %5902, %5939 ]
  %6087 = fadd fast float %5, 1.000000e+00
  %6088 = fadd fast float %6, 1.000000e+00
  %6089 = fsub fast float 1.000000e+00, %5
  %6090 = fmul fast float %36, %6087
  %6091 = fmul fast float %36, %6088
  %6092 = fmul fast float %36, %6089
  %6093 = fmul fast float %6090, %6084
  %6094 = fmul fast float %6091, %6085
  %6095 = fmul fast float %6092, %6086
  %6096 = fcmp fast ult float %37, 5.000000e-01
  br i1 %6096, label %6122, label %6097

; <label>:6097                                    ; preds = %6083
  %6098 = fmul fast float %6093, 0x4004147AE0000000
  %6099 = fmul fast float %6094, 0x4004147AE0000000
  %6100 = fmul fast float %6095, 0x4004147AE0000000
  %6101 = fadd fast float %6098, 0x3F9EB851E0000000
  %6102 = fadd fast float %6099, 0x3F9EB851E0000000
  %6103 = fadd fast float %6100, 0x3F9EB851E0000000
  %6104 = fmul fast float %6101, %6093
  %6105 = fmul fast float %6102, %6094
  %6106 = fmul fast float %6103, %6095
  %6107 = fmul fast float %6093, 0x400370A3E0000000
  %6108 = fmul fast float %6094, 0x400370A3E0000000
  %6109 = fmul fast float %6095, 0x400370A3E0000000
  %6110 = fadd fast float %6107, 0x3FE2E147A0000000
  %6111 = fadd fast float %6108, 0x3FE2E147A0000000
  %6112 = fadd fast float %6109, 0x3FE2E147A0000000
  %6113 = fmul fast float %6110, %6093
  %6114 = fmul fast float %6111, %6094
  %6115 = fmul fast float %6112, %6095
  %6116 = fadd fast float %6113, 0x3FC1EB8520000000
  %6117 = fadd fast float %6114, 0x3FC1EB8520000000
  %6118 = fadd fast float %6115, 0x3FC1EB8520000000
  %6119 = fdiv fast float %6104, %6116
  %6120 = fdiv fast float %6105, %6117
  %6121 = fdiv fast float %6106, %6118
  br label %6122

; <label>:6122                                    ; preds = %6097, %6083
  %6123 = phi float [ %6119, %6097 ], [ %6093, %6083 ]
  %6124 = phi float [ %6120, %6097 ], [ %6094, %6083 ]
  %6125 = phi float [ %6121, %6097 ], [ %6095, %6083 ]
  %6126 = call float @dx.op.unary.f32(i32 7, float %6123)  ; Saturate(value)
  %6127 = call float @dx.op.unary.f32(i32 7, float %6124)  ; Saturate(value)
  %6128 = call float @dx.op.unary.f32(i32 7, float %6125)  ; Saturate(value)
  %6129 = call float @dx.op.dot3.f32(i32 55, float %6126, float %6127, float %6128, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %6130 = fsub fast float %6126, %6129
  %6131 = fsub fast float %6127, %6129
  %6132 = fsub fast float %6128, %6129
  %6133 = fmul fast float %6130, %8
  %6134 = fmul fast float %6131, %8
  %6135 = fmul fast float %6132, %8
  %6136 = fadd fast float %6133, %6129
  %6137 = fadd fast float %6134, %6129
  %6138 = fadd fast float %6135, %6129
  %6139 = call float @dx.op.unary.f32(i32 7, float %6136)  ; Saturate(value)
  %6140 = call float @dx.op.unary.f32(i32 7, float %6137)  ; Saturate(value)
  %6141 = call float @dx.op.unary.f32(i32 7, float %6138)  ; Saturate(value)
  %6142 = fadd fast float %6139, 0xBFC70A3D80000000
  %6143 = fadd fast float %6140, 0xBFC70A3D80000000
  %6144 = fadd fast float %6141, 0xBFC70A3D80000000
  %6145 = fmul fast float %6142, %7
  %6146 = fmul fast float %6143, %7
  %6147 = fmul fast float %6144, %7
  %6148 = fadd fast float %6145, 0x3FC70A3D80000000
  %6149 = fadd fast float %6146, 0x3FC70A3D80000000
  %6150 = fadd fast float %6147, 0x3FC70A3D80000000
  %6151 = call float @dx.op.unary.f32(i32 7, float %6148)  ; Saturate(value)
  %6152 = call float @dx.op.unary.f32(i32 7, float %6149)  ; Saturate(value)
  %6153 = call float @dx.op.unary.f32(i32 7, float %6150)  ; Saturate(value)
  br label %6154

; <label>:6154                                    ; preds = %6122, %5905
  %6155 = phi float [ %5936, %5905 ], [ %6151, %6122 ]
  %6156 = phi float [ %5937, %5905 ], [ %6152, %6122 ]
  %6157 = phi float [ %5938, %5905 ], [ %6153, %6122 ]
  %6158 = fsub fast float %6155, %5875
  %6159 = fsub fast float %6156, %5876
  %6160 = fsub fast float %6157, %5877
  %6161 = fmul fast float %6158, %5892
  %6162 = fmul fast float %6159, %5892
  %6163 = fmul fast float %6160, %5892
  %6164 = fadd fast float %6161, %5875
  %6165 = fadd fast float %6162, %5876
  %6166 = fadd fast float %6163, %5877
  br label %6167

; <label>:6167                                    ; preds = %6154, %5846
  %6168 = phi float [ %6164, %6154 ], [ %5875, %5846 ]
  %6169 = phi float [ %6165, %6154 ], [ %5876, %5846 ]
  %6170 = phi float [ %6166, %6154 ], [ %5877, %5846 ]
  %6171 = add i32 %64, 1
  %6172 = call i32 @dx.op.binary.i32(i32 37, i32 %6171, i32 0)  ; IMax(a,b)
  %6173 = call i32 @dx.op.binary.i32(i32 38, i32 %6172, i32 %60)  ; IMin(a,b)
  %6174 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5881, i32 %6173, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6175 = extractvalue %dx.types.ResRet.f32 %6174, 0
  %6176 = fsub fast float %6175, %84
  %6177 = call float @dx.op.unary.f32(i32 6, float %6176)  ; FAbs(value)
  %6178 = fdiv fast float %6177, %5887
  %6179 = fsub fast float 1.000000e+00, %6178
  %6180 = call float @dx.op.unary.f32(i32 7, float %6179)  ; Saturate(value)
  %6181 = fcmp fast ugt float %6180, 0.000000e+00
  br i1 %6181, label %6182, label %6455

; <label>:6182                                    ; preds = %6167
  %6183 = call i32 @dx.op.binary.i32(i32 37, i32 %5881, i32 0)  ; IMax(a,b)
  %6184 = call i32 @dx.op.binary.i32(i32 37, i32 %6173, i32 0)  ; IMax(a,b)
  %6185 = call i32 @dx.op.binary.i32(i32 38, i32 %6183, i32 %59)  ; IMin(a,b)
  %6186 = call i32 @dx.op.binary.i32(i32 38, i32 %6184, i32 %60)  ; IMin(a,b)
  %6187 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %6185, i32 %6186, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6188 = extractvalue %dx.types.ResRet.f32 %6187, 0
  %6189 = extractvalue %dx.types.ResRet.f32 %6187, 1
  %6190 = extractvalue %dx.types.ResRet.f32 %6187, 2
  %6191 = extractvalue %dx.types.ResRet.f32 %6187, 3
  %6192 = fcmp fast olt float %6191, 0.000000e+00
  br i1 %6192, label %6193, label %6227

; <label>:6193                                    ; preds = %6182
  %6194 = fcmp fast ogt float %6188, 0x3FA4B5DCC0000000
  %6195 = fcmp fast ogt float %6189, 0x3FA4B5DCC0000000
  %6196 = fcmp fast ogt float %6190, 0x3FA4B5DCC0000000
  %6197 = select i1 %6194, float 0.000000e+00, float 1.000000e+00
  %6198 = select i1 %6195, float 0.000000e+00, float 1.000000e+00
  %6199 = select i1 %6196, float 0.000000e+00, float 1.000000e+00
  %6200 = fmul fast float %6188, 0x3FB3D07220000000
  %6201 = fmul fast float %6189, 0x3FB3D07220000000
  %6202 = fmul fast float %6190, 0x3FB3D07220000000
  %6203 = fadd fast float %6188, 0x3FAC28F5C0000000
  %6204 = fadd fast float %6189, 0x3FAC28F5C0000000
  %6205 = fadd fast float %6190, 0x3FAC28F5C0000000
  %6206 = fmul fast float %6203, 0x3FEE54EDE0000000
  %6207 = fmul fast float %6204, 0x3FEE54EDE0000000
  %6208 = fmul fast float %6205, 0x3FEE54EDE0000000
  %6209 = call float @dx.op.unary.f32(i32 23, float %6206)  ; Log(value)
  %6210 = call float @dx.op.unary.f32(i32 23, float %6207)  ; Log(value)
  %6211 = call float @dx.op.unary.f32(i32 23, float %6208)  ; Log(value)
  %6212 = fmul fast float %6209, 0x4003333340000000
  %6213 = fmul fast float %6210, 0x4003333340000000
  %6214 = fmul fast float %6211, 0x4003333340000000
  %6215 = call float @dx.op.unary.f32(i32 21, float %6212)  ; Exp(value)
  %6216 = call float @dx.op.unary.f32(i32 21, float %6213)  ; Exp(value)
  %6217 = call float @dx.op.unary.f32(i32 21, float %6214)  ; Exp(value)
  %6218 = fsub fast float %6200, %6215
  %6219 = fsub fast float %6201, %6216
  %6220 = fsub fast float %6202, %6217
  %6221 = fmul fast float %6218, %6197
  %6222 = fmul fast float %6219, %6198
  %6223 = fmul fast float %6220, %6199
  %6224 = fadd fast float %6221, %6215
  %6225 = fadd fast float %6222, %6216
  %6226 = fadd fast float %6223, %6217
  br label %6442

; <label>:6227                                    ; preds = %6182
  %6228 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %6185, i32 %6186, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6229 = extractvalue %dx.types.ResRet.f32 %6228, 0
  %6230 = fcmp fast ogt float %38, 5.000000e-01
  %6231 = fcmp fast olt float %6229, 1.000000e+00
  %6232 = and i1 %6230, %6231
  br i1 %6232, label %6233, label %6371

; <label>:6233                                    ; preds = %6227
  %6234 = sitofp i32 %6185 to float
  %6235 = sitofp i32 %6186 to float
  %6236 = fadd fast float %6234, 5.000000e-01
  %6237 = fadd fast float %6235, 5.000000e-01
  %6238 = fdiv fast float %6236, %45
  %6239 = fdiv fast float %6237, %46
  %6240 = fmul fast float %6238, 2.000000e+00
  %6241 = fmul fast float %6239, 2.000000e+00
  %6242 = fadd fast float %6240, -1.000000e+00
  %6243 = fsub fast float 1.000000e+00, %6241
  %6244 = fmul fast float %6242, %35
  %6245 = call float @dx.op.tertiary.f32(i32 46, float %6243, float %31, float %6244)  ; FMad(a,b,c)
  %6246 = call float @dx.op.tertiary.f32(i32 46, float %6229, float %27, float %6245)  ; FMad(a,b,c)
  %6247 = fadd fast float %6246, %23
  %6248 = call float @dx.op.unary.f32(i32 6, float %6247)  ; FAbs(value)
  %6249 = fcmp fast ogt float %6248, 0x3EB0C6F7A0000000
  br i1 %6249, label %6250, label %6371

; <label>:6250                                    ; preds = %6233
  %6251 = fmul fast float %6242, %34
  %6252 = call float @dx.op.tertiary.f32(i32 46, float %6243, float %30, float %6251)  ; FMad(a,b,c)
  %6253 = call float @dx.op.tertiary.f32(i32 46, float %6229, float %26, float %6252)  ; FMad(a,b,c)
  %6254 = fadd fast float %6253, %22
  %6255 = fmul fast float %6242, %33
  %6256 = call float @dx.op.tertiary.f32(i32 46, float %6243, float %29, float %6255)  ; FMad(a,b,c)
  %6257 = call float @dx.op.tertiary.f32(i32 46, float %6229, float %25, float %6256)  ; FMad(a,b,c)
  %6258 = fadd fast float %6257, %21
  %6259 = fmul fast float %6242, %32
  %6260 = call float @dx.op.tertiary.f32(i32 46, float %6243, float %28, float %6259)  ; FMad(a,b,c)
  %6261 = call float @dx.op.tertiary.f32(i32 46, float %6229, float %24, float %6260)  ; FMad(a,b,c)
  %6262 = fadd fast float %6261, %20
  %6263 = fdiv fast float %6262, %6247
  %6264 = fdiv fast float %6258, %6247
  %6265 = fdiv fast float %6254, %6247
  %6266 = fsub fast float %6263, %17
  %6267 = fsub fast float %6264, %18
  %6268 = fsub fast float %6265, %19
  %6269 = fmul fast float %6266, %6266
  %6270 = fmul fast float %6267, %6267
  %6271 = fadd fast float %6270, %6269
  %6272 = fmul fast float %6268, %6268
  %6273 = fadd fast float %6271, %6272
  %6274 = call float @dx.op.unary.f32(i32 24, float %6273)  ; Sqrt(value)
  %6275 = fsub fast float %6274, %9
  %6276 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %6275)  ; FMax(a,b)
  %6277 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %6277, label %6278, label %6301

; <label>:6278                                    ; preds = %6250
  %6279 = call float @dx.op.unary.f32(i32 6, float %6267)  ; FAbs(value)
  %6280 = fmul fast float %6279, %11
  %6281 = fcmp fast olt float %6280, 0x3F50624DE0000000
  br i1 %6281, label %6282, label %6285

; <label>:6282                                    ; preds = %6278
  %6283 = fmul fast float %6280, 5.000000e-01
  %6284 = fsub fast float 1.000000e+00, %6283
  br label %6290

; <label>:6285                                    ; preds = %6278
  %6286 = fmul fast float %6280, 0xBFF7154760000000
  %6287 = call float @dx.op.unary.f32(i32 21, float %6286)  ; Exp(value)
  %6288 = fsub fast float 1.000000e+00, %6287
  %6289 = fdiv fast float %6288, %6280
  br label %6290

; <label>:6290                                    ; preds = %6285, %6282
  %6291 = phi float [ %6284, %6282 ], [ %6289, %6285 ]
  %6292 = call float @dx.op.binary.f32(i32 36, float %6264, float %18)  ; FMin(a,b)
  %6293 = fsub fast float %6292, %10
  %6294 = fmul fast float %11, %6293
  %6295 = fsub fast float -0.000000e+00, %6294
  %6296 = call float @dx.op.binary.f32(i32 35, float %6295, float -4.000000e+01)  ; FMax(a,b)
  %6297 = call float @dx.op.binary.f32(i32 36, float %6296, float 5.000000e+00)  ; FMin(a,b)
  %6298 = fmul fast float %6297, 0x3FF7154760000000
  %6299 = call float @dx.op.unary.f32(i32 21, float %6298)  ; Exp(value)
  %6300 = fmul fast float %6299, %6291
  br label %6301

; <label>:6301                                    ; preds = %6290, %6250
  %6302 = phi float [ %6300, %6290 ], [ 1.000000e+00, %6250 ]
  %6303 = fmul fast float %6276, %16
  %6304 = fmul fast float %6303, %6302
  %6305 = fcmp fast ole float %6274, %9
  %6306 = fcmp fast olt float %6274, 0x3F1A36E2E0000000
  %6307 = or i1 %6305, %6306
  br i1 %6307, label %6354, label %6308

; <label>:6308                                    ; preds = %6301
  %6309 = fdiv fast float %9, %6274
  %6310 = fmul fast float %6309, %6266
  %6311 = fmul fast float %6309, %6267
  %6312 = fmul fast float %6309, %6268
  %6313 = fadd fast float %6310, %17
  %6314 = fadd fast float %6311, %18
  %6315 = fadd fast float %6312, %19
  %6316 = fadd fast float %6313, -9.000000e+02
  %6317 = fadd fast float %6314, -1.500000e+01
  %6318 = fadd fast float %6315, -7.500000e+02
  %6319 = fmul fast float %6316, 0x3F62345680000000
  %6320 = fmul fast float %6317, 0x3F62345680000000
  %6321 = fmul fast float %6318, 0x3F62345680000000
  %6322 = call float @dx.op.dot3.f32(i32 55, float %6319, float %6320, float %6321, float %6319, float %6320, float %6321)  ; Dot3(ax,ay,az,bx,by,bz)
  %6323 = fsub fast float 1.000000e+00, %6322
  %6324 = call float @dx.op.unary.f32(i32 7, float %6323)  ; Saturate(value)
  %6325 = fmul fast float %6324, %6324
  %6326 = fadd fast float %6313, %6263
  %6327 = fadd fast float %6314, %6264
  %6328 = fadd fast float %6315, %6265
  %6329 = fmul fast float %6326, 0x3F52345680000000
  %6330 = fadd fast float %6329, -2.000000e+00
  %6331 = fmul fast float %6327, 0x3F52345680000000
  %6332 = fadd fast float %6331, 0xBFA1111120000000
  %6333 = fmul fast float %6328, 0x3F52345680000000
  %6334 = fadd fast float %6333, 0xBFFAAAAAC0000000
  %6335 = call float @dx.op.dot3.f32(i32 55, float %6330, float %6332, float %6334, float %6330, float %6332, float %6334)  ; Dot3(ax,ay,az,bx,by,bz)
  %6336 = fsub fast float 1.000000e+00, %6335
  %6337 = call float @dx.op.unary.f32(i32 7, float %6336)  ; Saturate(value)
  %6338 = fmul fast float %6337, %6337
  %6339 = fmul fast float %6338, 4.000000e+00
  %6340 = fadd fast float %6339, %6325
  %6341 = fadd fast float %6263, -9.000000e+02
  %6342 = fadd fast float %6264, -1.500000e+01
  %6343 = fadd fast float %6265, -7.500000e+02
  %6344 = fmul fast float %6341, 0x3F62345680000000
  %6345 = fmul fast float %6342, 0x3F62345680000000
  %6346 = fmul fast float %6343, 0x3F62345680000000
  %6347 = call float @dx.op.dot3.f32(i32 55, float %6344, float %6345, float %6346, float %6344, float %6345, float %6346)  ; Dot3(ax,ay,az,bx,by,bz)
  %6348 = fsub fast float 1.000000e+00, %6347
  %6349 = call float @dx.op.unary.f32(i32 7, float %6348)  ; Saturate(value)
  %6350 = fmul fast float %6349, %6349
  %6351 = fadd fast float %6340, %6350
  %6352 = fmul fast float %6275, 0x3F25D867E0000000
  %6353 = fmul fast float %6352, %6351
  br label %6354

; <label>:6354                                    ; preds = %6308, %6301
  %6355 = phi float [ %6353, %6308 ], [ 0.000000e+00, %6301 ]
  %6356 = fadd fast float %6355, %6304
  %6357 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %6356)  ; FMin(a,b)
  %6358 = fmul fast float %6357, 0xBFF7154760000000
  %6359 = call float @dx.op.unary.f32(i32 21, float %6358)  ; Exp(value)
  %6360 = fsub fast float 1.000000e+00, %6359
  %6361 = call float @dx.op.binary.f32(i32 36, float %12, float %6360)  ; FMin(a,b)
  %6362 = fsub fast float %13, %6188
  %6363 = fsub fast float %14, %6189
  %6364 = fsub fast float %15, %6190
  %6365 = fmul fast float %6361, %6362
  %6366 = fmul fast float %6361, %6363
  %6367 = fmul fast float %6361, %6364
  %6368 = fadd fast float %6365, %6188
  %6369 = fadd fast float %6366, %6189
  %6370 = fadd fast float %6367, %6190
  br label %6371

; <label>:6371                                    ; preds = %6354, %6233, %6227
  %6372 = phi float [ %6368, %6354 ], [ %6188, %6233 ], [ %6188, %6227 ]
  %6373 = phi float [ %6369, %6354 ], [ %6189, %6233 ], [ %6189, %6227 ]
  %6374 = phi float [ %6370, %6354 ], [ %6190, %6233 ], [ %6190, %6227 ]
  %6375 = fadd fast float %5, 1.000000e+00
  %6376 = fadd fast float %6, 1.000000e+00
  %6377 = fsub fast float 1.000000e+00, %5
  %6378 = fmul fast float %36, %6375
  %6379 = fmul fast float %36, %6376
  %6380 = fmul fast float %36, %6377
  %6381 = fmul fast float %6378, %6372
  %6382 = fmul fast float %6379, %6373
  %6383 = fmul fast float %6380, %6374
  %6384 = fcmp fast ult float %37, 5.000000e-01
  br i1 %6384, label %6410, label %6385

; <label>:6385                                    ; preds = %6371
  %6386 = fmul fast float %6381, 0x4004147AE0000000
  %6387 = fmul fast float %6382, 0x4004147AE0000000
  %6388 = fmul fast float %6383, 0x4004147AE0000000
  %6389 = fadd fast float %6386, 0x3F9EB851E0000000
  %6390 = fadd fast float %6387, 0x3F9EB851E0000000
  %6391 = fadd fast float %6388, 0x3F9EB851E0000000
  %6392 = fmul fast float %6389, %6381
  %6393 = fmul fast float %6390, %6382
  %6394 = fmul fast float %6391, %6383
  %6395 = fmul fast float %6381, 0x400370A3E0000000
  %6396 = fmul fast float %6382, 0x400370A3E0000000
  %6397 = fmul fast float %6383, 0x400370A3E0000000
  %6398 = fadd fast float %6395, 0x3FE2E147A0000000
  %6399 = fadd fast float %6396, 0x3FE2E147A0000000
  %6400 = fadd fast float %6397, 0x3FE2E147A0000000
  %6401 = fmul fast float %6398, %6381
  %6402 = fmul fast float %6399, %6382
  %6403 = fmul fast float %6400, %6383
  %6404 = fadd fast float %6401, 0x3FC1EB8520000000
  %6405 = fadd fast float %6402, 0x3FC1EB8520000000
  %6406 = fadd fast float %6403, 0x3FC1EB8520000000
  %6407 = fdiv fast float %6392, %6404
  %6408 = fdiv fast float %6393, %6405
  %6409 = fdiv fast float %6394, %6406
  br label %6410

; <label>:6410                                    ; preds = %6385, %6371
  %6411 = phi float [ %6407, %6385 ], [ %6381, %6371 ]
  %6412 = phi float [ %6408, %6385 ], [ %6382, %6371 ]
  %6413 = phi float [ %6409, %6385 ], [ %6383, %6371 ]
  %6414 = call float @dx.op.unary.f32(i32 7, float %6411)  ; Saturate(value)
  %6415 = call float @dx.op.unary.f32(i32 7, float %6412)  ; Saturate(value)
  %6416 = call float @dx.op.unary.f32(i32 7, float %6413)  ; Saturate(value)
  %6417 = call float @dx.op.dot3.f32(i32 55, float %6414, float %6415, float %6416, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %6418 = fsub fast float %6414, %6417
  %6419 = fsub fast float %6415, %6417
  %6420 = fsub fast float %6416, %6417
  %6421 = fmul fast float %6418, %8
  %6422 = fmul fast float %6419, %8
  %6423 = fmul fast float %6420, %8
  %6424 = fadd fast float %6421, %6417
  %6425 = fadd fast float %6422, %6417
  %6426 = fadd fast float %6423, %6417
  %6427 = call float @dx.op.unary.f32(i32 7, float %6424)  ; Saturate(value)
  %6428 = call float @dx.op.unary.f32(i32 7, float %6425)  ; Saturate(value)
  %6429 = call float @dx.op.unary.f32(i32 7, float %6426)  ; Saturate(value)
  %6430 = fadd fast float %6427, 0xBFC70A3D80000000
  %6431 = fadd fast float %6428, 0xBFC70A3D80000000
  %6432 = fadd fast float %6429, 0xBFC70A3D80000000
  %6433 = fmul fast float %6430, %7
  %6434 = fmul fast float %6431, %7
  %6435 = fmul fast float %6432, %7
  %6436 = fadd fast float %6433, 0x3FC70A3D80000000
  %6437 = fadd fast float %6434, 0x3FC70A3D80000000
  %6438 = fadd fast float %6435, 0x3FC70A3D80000000
  %6439 = call float @dx.op.unary.f32(i32 7, float %6436)  ; Saturate(value)
  %6440 = call float @dx.op.unary.f32(i32 7, float %6437)  ; Saturate(value)
  %6441 = call float @dx.op.unary.f32(i32 7, float %6438)  ; Saturate(value)
  br label %6442

; <label>:6442                                    ; preds = %6410, %6193
  %6443 = phi float [ %6224, %6193 ], [ %6439, %6410 ]
  %6444 = phi float [ %6225, %6193 ], [ %6440, %6410 ]
  %6445 = phi float [ %6226, %6193 ], [ %6441, %6410 ]
  %6446 = fsub fast float %6443, %5875
  %6447 = fsub fast float %6444, %5876
  %6448 = fsub fast float %6445, %5877
  %6449 = fmul fast float %6446, %6180
  %6450 = fmul fast float %6447, %6180
  %6451 = fmul fast float %6448, %6180
  %6452 = fadd fast float %6449, %5875
  %6453 = fadd fast float %6450, %5876
  %6454 = fadd fast float %6451, %5877
  br label %6455

; <label>:6455                                    ; preds = %6442, %6167
  %6456 = phi float [ %6452, %6442 ], [ %5875, %6167 ]
  %6457 = phi float [ %6453, %6442 ], [ %5876, %6167 ]
  %6458 = phi float [ %6454, %6442 ], [ %5877, %6167 ]
  %6459 = add i32 %67, -1
  %6460 = call i32 @dx.op.binary.i32(i32 37, i32 %6459, i32 0)  ; IMax(a,b)
  %6461 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %6462 = call i32 @dx.op.binary.i32(i32 38, i32 %6460, i32 %59)  ; IMin(a,b)
  %6463 = call i32 @dx.op.binary.i32(i32 38, i32 %6461, i32 %60)  ; IMin(a,b)
  %6464 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %6462, i32 %6463, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6465 = extractvalue %dx.types.ResRet.f32 %6464, 0
  %6466 = fsub fast float %6465, %84
  %6467 = call float @dx.op.unary.f32(i32 6, float %6466)  ; FAbs(value)
  %6468 = fdiv fast float %6467, %5887
  %6469 = fsub fast float 1.000000e+00, %6468
  %6470 = call float @dx.op.unary.f32(i32 7, float %6469)  ; Saturate(value)
  %6471 = fcmp fast ugt float %6470, 0.000000e+00
  br i1 %6471, label %6472, label %6745

; <label>:6472                                    ; preds = %6455
  %6473 = call i32 @dx.op.binary.i32(i32 37, i32 %6462, i32 0)  ; IMax(a,b)
  %6474 = call i32 @dx.op.binary.i32(i32 37, i32 %6463, i32 0)  ; IMax(a,b)
  %6475 = call i32 @dx.op.binary.i32(i32 38, i32 %6473, i32 %59)  ; IMin(a,b)
  %6476 = call i32 @dx.op.binary.i32(i32 38, i32 %6474, i32 %60)  ; IMin(a,b)
  %6477 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %6475, i32 %6476, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6478 = extractvalue %dx.types.ResRet.f32 %6477, 0
  %6479 = extractvalue %dx.types.ResRet.f32 %6477, 1
  %6480 = extractvalue %dx.types.ResRet.f32 %6477, 2
  %6481 = extractvalue %dx.types.ResRet.f32 %6477, 3
  %6482 = fcmp fast olt float %6481, 0.000000e+00
  br i1 %6482, label %6483, label %6517

; <label>:6483                                    ; preds = %6472
  %6484 = fcmp fast ogt float %6478, 0x3FA4B5DCC0000000
  %6485 = fcmp fast ogt float %6479, 0x3FA4B5DCC0000000
  %6486 = fcmp fast ogt float %6480, 0x3FA4B5DCC0000000
  %6487 = select i1 %6484, float 0.000000e+00, float 1.000000e+00
  %6488 = select i1 %6485, float 0.000000e+00, float 1.000000e+00
  %6489 = select i1 %6486, float 0.000000e+00, float 1.000000e+00
  %6490 = fmul fast float %6478, 0x3FB3D07220000000
  %6491 = fmul fast float %6479, 0x3FB3D07220000000
  %6492 = fmul fast float %6480, 0x3FB3D07220000000
  %6493 = fadd fast float %6478, 0x3FAC28F5C0000000
  %6494 = fadd fast float %6479, 0x3FAC28F5C0000000
  %6495 = fadd fast float %6480, 0x3FAC28F5C0000000
  %6496 = fmul fast float %6493, 0x3FEE54EDE0000000
  %6497 = fmul fast float %6494, 0x3FEE54EDE0000000
  %6498 = fmul fast float %6495, 0x3FEE54EDE0000000
  %6499 = call float @dx.op.unary.f32(i32 23, float %6496)  ; Log(value)
  %6500 = call float @dx.op.unary.f32(i32 23, float %6497)  ; Log(value)
  %6501 = call float @dx.op.unary.f32(i32 23, float %6498)  ; Log(value)
  %6502 = fmul fast float %6499, 0x4003333340000000
  %6503 = fmul fast float %6500, 0x4003333340000000
  %6504 = fmul fast float %6501, 0x4003333340000000
  %6505 = call float @dx.op.unary.f32(i32 21, float %6502)  ; Exp(value)
  %6506 = call float @dx.op.unary.f32(i32 21, float %6503)  ; Exp(value)
  %6507 = call float @dx.op.unary.f32(i32 21, float %6504)  ; Exp(value)
  %6508 = fsub fast float %6490, %6505
  %6509 = fsub fast float %6491, %6506
  %6510 = fsub fast float %6492, %6507
  %6511 = fmul fast float %6508, %6487
  %6512 = fmul fast float %6509, %6488
  %6513 = fmul fast float %6510, %6489
  %6514 = fadd fast float %6511, %6505
  %6515 = fadd fast float %6512, %6506
  %6516 = fadd fast float %6513, %6507
  br label %6732

; <label>:6517                                    ; preds = %6472
  %6518 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %6475, i32 %6476, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6519 = extractvalue %dx.types.ResRet.f32 %6518, 0
  %6520 = fcmp fast ogt float %38, 5.000000e-01
  %6521 = fcmp fast olt float %6519, 1.000000e+00
  %6522 = and i1 %6520, %6521
  br i1 %6522, label %6523, label %6661

; <label>:6523                                    ; preds = %6517
  %6524 = sitofp i32 %6475 to float
  %6525 = sitofp i32 %6476 to float
  %6526 = fadd fast float %6524, 5.000000e-01
  %6527 = fadd fast float %6525, 5.000000e-01
  %6528 = fdiv fast float %6526, %45
  %6529 = fdiv fast float %6527, %46
  %6530 = fmul fast float %6528, 2.000000e+00
  %6531 = fmul fast float %6529, 2.000000e+00
  %6532 = fadd fast float %6530, -1.000000e+00
  %6533 = fsub fast float 1.000000e+00, %6531
  %6534 = fmul fast float %6532, %35
  %6535 = call float @dx.op.tertiary.f32(i32 46, float %6533, float %31, float %6534)  ; FMad(a,b,c)
  %6536 = call float @dx.op.tertiary.f32(i32 46, float %6519, float %27, float %6535)  ; FMad(a,b,c)
  %6537 = fadd fast float %6536, %23
  %6538 = call float @dx.op.unary.f32(i32 6, float %6537)  ; FAbs(value)
  %6539 = fcmp fast ogt float %6538, 0x3EB0C6F7A0000000
  br i1 %6539, label %6540, label %6661

; <label>:6540                                    ; preds = %6523
  %6541 = fmul fast float %6532, %34
  %6542 = call float @dx.op.tertiary.f32(i32 46, float %6533, float %30, float %6541)  ; FMad(a,b,c)
  %6543 = call float @dx.op.tertiary.f32(i32 46, float %6519, float %26, float %6542)  ; FMad(a,b,c)
  %6544 = fadd fast float %6543, %22
  %6545 = fmul fast float %6532, %33
  %6546 = call float @dx.op.tertiary.f32(i32 46, float %6533, float %29, float %6545)  ; FMad(a,b,c)
  %6547 = call float @dx.op.tertiary.f32(i32 46, float %6519, float %25, float %6546)  ; FMad(a,b,c)
  %6548 = fadd fast float %6547, %21
  %6549 = fmul fast float %6532, %32
  %6550 = call float @dx.op.tertiary.f32(i32 46, float %6533, float %28, float %6549)  ; FMad(a,b,c)
  %6551 = call float @dx.op.tertiary.f32(i32 46, float %6519, float %24, float %6550)  ; FMad(a,b,c)
  %6552 = fadd fast float %6551, %20
  %6553 = fdiv fast float %6552, %6537
  %6554 = fdiv fast float %6548, %6537
  %6555 = fdiv fast float %6544, %6537
  %6556 = fsub fast float %6553, %17
  %6557 = fsub fast float %6554, %18
  %6558 = fsub fast float %6555, %19
  %6559 = fmul fast float %6556, %6556
  %6560 = fmul fast float %6557, %6557
  %6561 = fadd fast float %6560, %6559
  %6562 = fmul fast float %6558, %6558
  %6563 = fadd fast float %6561, %6562
  %6564 = call float @dx.op.unary.f32(i32 24, float %6563)  ; Sqrt(value)
  %6565 = fsub fast float %6564, %9
  %6566 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %6565)  ; FMax(a,b)
  %6567 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %6567, label %6568, label %6591

; <label>:6568                                    ; preds = %6540
  %6569 = call float @dx.op.unary.f32(i32 6, float %6557)  ; FAbs(value)
  %6570 = fmul fast float %6569, %11
  %6571 = fcmp fast olt float %6570, 0x3F50624DE0000000
  br i1 %6571, label %6572, label %6575

; <label>:6572                                    ; preds = %6568
  %6573 = fmul fast float %6570, 5.000000e-01
  %6574 = fsub fast float 1.000000e+00, %6573
  br label %6580

; <label>:6575                                    ; preds = %6568
  %6576 = fmul fast float %6570, 0xBFF7154760000000
  %6577 = call float @dx.op.unary.f32(i32 21, float %6576)  ; Exp(value)
  %6578 = fsub fast float 1.000000e+00, %6577
  %6579 = fdiv fast float %6578, %6570
  br label %6580

; <label>:6580                                    ; preds = %6575, %6572
  %6581 = phi float [ %6574, %6572 ], [ %6579, %6575 ]
  %6582 = call float @dx.op.binary.f32(i32 36, float %6554, float %18)  ; FMin(a,b)
  %6583 = fsub fast float %6582, %10
  %6584 = fmul fast float %11, %6583
  %6585 = fsub fast float -0.000000e+00, %6584
  %6586 = call float @dx.op.binary.f32(i32 35, float %6585, float -4.000000e+01)  ; FMax(a,b)
  %6587 = call float @dx.op.binary.f32(i32 36, float %6586, float 5.000000e+00)  ; FMin(a,b)
  %6588 = fmul fast float %6587, 0x3FF7154760000000
  %6589 = call float @dx.op.unary.f32(i32 21, float %6588)  ; Exp(value)
  %6590 = fmul fast float %6589, %6581
  br label %6591

; <label>:6591                                    ; preds = %6580, %6540
  %6592 = phi float [ %6590, %6580 ], [ 1.000000e+00, %6540 ]
  %6593 = fmul fast float %6566, %16
  %6594 = fmul fast float %6593, %6592
  %6595 = fcmp fast ole float %6564, %9
  %6596 = fcmp fast olt float %6564, 0x3F1A36E2E0000000
  %6597 = or i1 %6595, %6596
  br i1 %6597, label %6644, label %6598

; <label>:6598                                    ; preds = %6591
  %6599 = fdiv fast float %9, %6564
  %6600 = fmul fast float %6599, %6556
  %6601 = fmul fast float %6599, %6557
  %6602 = fmul fast float %6599, %6558
  %6603 = fadd fast float %6600, %17
  %6604 = fadd fast float %6601, %18
  %6605 = fadd fast float %6602, %19
  %6606 = fadd fast float %6603, -9.000000e+02
  %6607 = fadd fast float %6604, -1.500000e+01
  %6608 = fadd fast float %6605, -7.500000e+02
  %6609 = fmul fast float %6606, 0x3F62345680000000
  %6610 = fmul fast float %6607, 0x3F62345680000000
  %6611 = fmul fast float %6608, 0x3F62345680000000
  %6612 = call float @dx.op.dot3.f32(i32 55, float %6609, float %6610, float %6611, float %6609, float %6610, float %6611)  ; Dot3(ax,ay,az,bx,by,bz)
  %6613 = fsub fast float 1.000000e+00, %6612
  %6614 = call float @dx.op.unary.f32(i32 7, float %6613)  ; Saturate(value)
  %6615 = fmul fast float %6614, %6614
  %6616 = fadd fast float %6603, %6553
  %6617 = fadd fast float %6604, %6554
  %6618 = fadd fast float %6605, %6555
  %6619 = fmul fast float %6616, 0x3F52345680000000
  %6620 = fadd fast float %6619, -2.000000e+00
  %6621 = fmul fast float %6617, 0x3F52345680000000
  %6622 = fadd fast float %6621, 0xBFA1111120000000
  %6623 = fmul fast float %6618, 0x3F52345680000000
  %6624 = fadd fast float %6623, 0xBFFAAAAAC0000000
  %6625 = call float @dx.op.dot3.f32(i32 55, float %6620, float %6622, float %6624, float %6620, float %6622, float %6624)  ; Dot3(ax,ay,az,bx,by,bz)
  %6626 = fsub fast float 1.000000e+00, %6625
  %6627 = call float @dx.op.unary.f32(i32 7, float %6626)  ; Saturate(value)
  %6628 = fmul fast float %6627, %6627
  %6629 = fmul fast float %6628, 4.000000e+00
  %6630 = fadd fast float %6629, %6615
  %6631 = fadd fast float %6553, -9.000000e+02
  %6632 = fadd fast float %6554, -1.500000e+01
  %6633 = fadd fast float %6555, -7.500000e+02
  %6634 = fmul fast float %6631, 0x3F62345680000000
  %6635 = fmul fast float %6632, 0x3F62345680000000
  %6636 = fmul fast float %6633, 0x3F62345680000000
  %6637 = call float @dx.op.dot3.f32(i32 55, float %6634, float %6635, float %6636, float %6634, float %6635, float %6636)  ; Dot3(ax,ay,az,bx,by,bz)
  %6638 = fsub fast float 1.000000e+00, %6637
  %6639 = call float @dx.op.unary.f32(i32 7, float %6638)  ; Saturate(value)
  %6640 = fmul fast float %6639, %6639
  %6641 = fadd fast float %6630, %6640
  %6642 = fmul fast float %6565, 0x3F25D867E0000000
  %6643 = fmul fast float %6642, %6641
  br label %6644

; <label>:6644                                    ; preds = %6598, %6591
  %6645 = phi float [ %6643, %6598 ], [ 0.000000e+00, %6591 ]
  %6646 = fadd fast float %6645, %6594
  %6647 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %6646)  ; FMin(a,b)
  %6648 = fmul fast float %6647, 0xBFF7154760000000
  %6649 = call float @dx.op.unary.f32(i32 21, float %6648)  ; Exp(value)
  %6650 = fsub fast float 1.000000e+00, %6649
  %6651 = call float @dx.op.binary.f32(i32 36, float %12, float %6650)  ; FMin(a,b)
  %6652 = fsub fast float %13, %6478
  %6653 = fsub fast float %14, %6479
  %6654 = fsub fast float %15, %6480
  %6655 = fmul fast float %6651, %6652
  %6656 = fmul fast float %6651, %6653
  %6657 = fmul fast float %6651, %6654
  %6658 = fadd fast float %6655, %6478
  %6659 = fadd fast float %6656, %6479
  %6660 = fadd fast float %6657, %6480
  br label %6661

; <label>:6661                                    ; preds = %6644, %6523, %6517
  %6662 = phi float [ %6658, %6644 ], [ %6478, %6523 ], [ %6478, %6517 ]
  %6663 = phi float [ %6659, %6644 ], [ %6479, %6523 ], [ %6479, %6517 ]
  %6664 = phi float [ %6660, %6644 ], [ %6480, %6523 ], [ %6480, %6517 ]
  %6665 = fadd fast float %5, 1.000000e+00
  %6666 = fadd fast float %6, 1.000000e+00
  %6667 = fsub fast float 1.000000e+00, %5
  %6668 = fmul fast float %36, %6665
  %6669 = fmul fast float %36, %6666
  %6670 = fmul fast float %36, %6667
  %6671 = fmul fast float %6668, %6662
  %6672 = fmul fast float %6669, %6663
  %6673 = fmul fast float %6670, %6664
  %6674 = fcmp fast ult float %37, 5.000000e-01
  br i1 %6674, label %6700, label %6675

; <label>:6675                                    ; preds = %6661
  %6676 = fmul fast float %6671, 0x4004147AE0000000
  %6677 = fmul fast float %6672, 0x4004147AE0000000
  %6678 = fmul fast float %6673, 0x4004147AE0000000
  %6679 = fadd fast float %6676, 0x3F9EB851E0000000
  %6680 = fadd fast float %6677, 0x3F9EB851E0000000
  %6681 = fadd fast float %6678, 0x3F9EB851E0000000
  %6682 = fmul fast float %6679, %6671
  %6683 = fmul fast float %6680, %6672
  %6684 = fmul fast float %6681, %6673
  %6685 = fmul fast float %6671, 0x400370A3E0000000
  %6686 = fmul fast float %6672, 0x400370A3E0000000
  %6687 = fmul fast float %6673, 0x400370A3E0000000
  %6688 = fadd fast float %6685, 0x3FE2E147A0000000
  %6689 = fadd fast float %6686, 0x3FE2E147A0000000
  %6690 = fadd fast float %6687, 0x3FE2E147A0000000
  %6691 = fmul fast float %6688, %6671
  %6692 = fmul fast float %6689, %6672
  %6693 = fmul fast float %6690, %6673
  %6694 = fadd fast float %6691, 0x3FC1EB8520000000
  %6695 = fadd fast float %6692, 0x3FC1EB8520000000
  %6696 = fadd fast float %6693, 0x3FC1EB8520000000
  %6697 = fdiv fast float %6682, %6694
  %6698 = fdiv fast float %6683, %6695
  %6699 = fdiv fast float %6684, %6696
  br label %6700

; <label>:6700                                    ; preds = %6675, %6661
  %6701 = phi float [ %6697, %6675 ], [ %6671, %6661 ]
  %6702 = phi float [ %6698, %6675 ], [ %6672, %6661 ]
  %6703 = phi float [ %6699, %6675 ], [ %6673, %6661 ]
  %6704 = call float @dx.op.unary.f32(i32 7, float %6701)  ; Saturate(value)
  %6705 = call float @dx.op.unary.f32(i32 7, float %6702)  ; Saturate(value)
  %6706 = call float @dx.op.unary.f32(i32 7, float %6703)  ; Saturate(value)
  %6707 = call float @dx.op.dot3.f32(i32 55, float %6704, float %6705, float %6706, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %6708 = fsub fast float %6704, %6707
  %6709 = fsub fast float %6705, %6707
  %6710 = fsub fast float %6706, %6707
  %6711 = fmul fast float %6708, %8
  %6712 = fmul fast float %6709, %8
  %6713 = fmul fast float %6710, %8
  %6714 = fadd fast float %6711, %6707
  %6715 = fadd fast float %6712, %6707
  %6716 = fadd fast float %6713, %6707
  %6717 = call float @dx.op.unary.f32(i32 7, float %6714)  ; Saturate(value)
  %6718 = call float @dx.op.unary.f32(i32 7, float %6715)  ; Saturate(value)
  %6719 = call float @dx.op.unary.f32(i32 7, float %6716)  ; Saturate(value)
  %6720 = fadd fast float %6717, 0xBFC70A3D80000000
  %6721 = fadd fast float %6718, 0xBFC70A3D80000000
  %6722 = fadd fast float %6719, 0xBFC70A3D80000000
  %6723 = fmul fast float %6720, %7
  %6724 = fmul fast float %6721, %7
  %6725 = fmul fast float %6722, %7
  %6726 = fadd fast float %6723, 0x3FC70A3D80000000
  %6727 = fadd fast float %6724, 0x3FC70A3D80000000
  %6728 = fadd fast float %6725, 0x3FC70A3D80000000
  %6729 = call float @dx.op.unary.f32(i32 7, float %6726)  ; Saturate(value)
  %6730 = call float @dx.op.unary.f32(i32 7, float %6727)  ; Saturate(value)
  %6731 = call float @dx.op.unary.f32(i32 7, float %6728)  ; Saturate(value)
  br label %6732

; <label>:6732                                    ; preds = %6700, %6483
  %6733 = phi float [ %6514, %6483 ], [ %6729, %6700 ]
  %6734 = phi float [ %6515, %6483 ], [ %6730, %6700 ]
  %6735 = phi float [ %6516, %6483 ], [ %6731, %6700 ]
  %6736 = fsub fast float %6733, %5875
  %6737 = fsub fast float %6734, %5876
  %6738 = fsub fast float %6735, %5877
  %6739 = fmul fast float %6736, %6470
  %6740 = fmul fast float %6737, %6470
  %6741 = fmul fast float %6738, %6470
  %6742 = fadd fast float %6739, %5875
  %6743 = fadd fast float %6740, %5876
  %6744 = fadd fast float %6741, %5877
  br label %6745

; <label>:6745                                    ; preds = %6732, %6455
  %6746 = phi float [ %6742, %6732 ], [ %5875, %6455 ]
  %6747 = phi float [ %6743, %6732 ], [ %5876, %6455 ]
  %6748 = phi float [ %6744, %6732 ], [ %5877, %6455 ]
  %6749 = add i32 %67, 1
  %6750 = call i32 @dx.op.binary.i32(i32 37, i32 %6749, i32 0)  ; IMax(a,b)
  %6751 = call i32 @dx.op.binary.i32(i32 38, i32 %6750, i32 %59)  ; IMin(a,b)
  %6752 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %6751, i32 %6463, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6753 = extractvalue %dx.types.ResRet.f32 %6752, 0
  %6754 = fsub fast float %6753, %84
  %6755 = call float @dx.op.unary.f32(i32 6, float %6754)  ; FAbs(value)
  %6756 = fdiv fast float %6755, %5887
  %6757 = fsub fast float 1.000000e+00, %6756
  %6758 = call float @dx.op.unary.f32(i32 7, float %6757)  ; Saturate(value)
  %6759 = fcmp fast ugt float %6758, 0.000000e+00
  br i1 %6759, label %6760, label %7033

; <label>:6760                                    ; preds = %6745
  %6761 = call i32 @dx.op.binary.i32(i32 37, i32 %6751, i32 0)  ; IMax(a,b)
  %6762 = call i32 @dx.op.binary.i32(i32 37, i32 %6463, i32 0)  ; IMax(a,b)
  %6763 = call i32 @dx.op.binary.i32(i32 38, i32 %6761, i32 %59)  ; IMin(a,b)
  %6764 = call i32 @dx.op.binary.i32(i32 38, i32 %6762, i32 %60)  ; IMin(a,b)
  %6765 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %6763, i32 %6764, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6766 = extractvalue %dx.types.ResRet.f32 %6765, 0
  %6767 = extractvalue %dx.types.ResRet.f32 %6765, 1
  %6768 = extractvalue %dx.types.ResRet.f32 %6765, 2
  %6769 = extractvalue %dx.types.ResRet.f32 %6765, 3
  %6770 = fcmp fast olt float %6769, 0.000000e+00
  br i1 %6770, label %6771, label %6805

; <label>:6771                                    ; preds = %6760
  %6772 = fcmp fast ogt float %6766, 0x3FA4B5DCC0000000
  %6773 = fcmp fast ogt float %6767, 0x3FA4B5DCC0000000
  %6774 = fcmp fast ogt float %6768, 0x3FA4B5DCC0000000
  %6775 = select i1 %6772, float 0.000000e+00, float 1.000000e+00
  %6776 = select i1 %6773, float 0.000000e+00, float 1.000000e+00
  %6777 = select i1 %6774, float 0.000000e+00, float 1.000000e+00
  %6778 = fmul fast float %6766, 0x3FB3D07220000000
  %6779 = fmul fast float %6767, 0x3FB3D07220000000
  %6780 = fmul fast float %6768, 0x3FB3D07220000000
  %6781 = fadd fast float %6766, 0x3FAC28F5C0000000
  %6782 = fadd fast float %6767, 0x3FAC28F5C0000000
  %6783 = fadd fast float %6768, 0x3FAC28F5C0000000
  %6784 = fmul fast float %6781, 0x3FEE54EDE0000000
  %6785 = fmul fast float %6782, 0x3FEE54EDE0000000
  %6786 = fmul fast float %6783, 0x3FEE54EDE0000000
  %6787 = call float @dx.op.unary.f32(i32 23, float %6784)  ; Log(value)
  %6788 = call float @dx.op.unary.f32(i32 23, float %6785)  ; Log(value)
  %6789 = call float @dx.op.unary.f32(i32 23, float %6786)  ; Log(value)
  %6790 = fmul fast float %6787, 0x4003333340000000
  %6791 = fmul fast float %6788, 0x4003333340000000
  %6792 = fmul fast float %6789, 0x4003333340000000
  %6793 = call float @dx.op.unary.f32(i32 21, float %6790)  ; Exp(value)
  %6794 = call float @dx.op.unary.f32(i32 21, float %6791)  ; Exp(value)
  %6795 = call float @dx.op.unary.f32(i32 21, float %6792)  ; Exp(value)
  %6796 = fsub fast float %6778, %6793
  %6797 = fsub fast float %6779, %6794
  %6798 = fsub fast float %6780, %6795
  %6799 = fmul fast float %6796, %6775
  %6800 = fmul fast float %6797, %6776
  %6801 = fmul fast float %6798, %6777
  %6802 = fadd fast float %6799, %6793
  %6803 = fadd fast float %6800, %6794
  %6804 = fadd fast float %6801, %6795
  br label %7020

; <label>:6805                                    ; preds = %6760
  %6806 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %6763, i32 %6764, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %6807 = extractvalue %dx.types.ResRet.f32 %6806, 0
  %6808 = fcmp fast ogt float %38, 5.000000e-01
  %6809 = fcmp fast olt float %6807, 1.000000e+00
  %6810 = and i1 %6808, %6809
  br i1 %6810, label %6811, label %6949

; <label>:6811                                    ; preds = %6805
  %6812 = sitofp i32 %6763 to float
  %6813 = sitofp i32 %6764 to float
  %6814 = fadd fast float %6812, 5.000000e-01
  %6815 = fadd fast float %6813, 5.000000e-01
  %6816 = fdiv fast float %6814, %45
  %6817 = fdiv fast float %6815, %46
  %6818 = fmul fast float %6816, 2.000000e+00
  %6819 = fmul fast float %6817, 2.000000e+00
  %6820 = fadd fast float %6818, -1.000000e+00
  %6821 = fsub fast float 1.000000e+00, %6819
  %6822 = fmul fast float %6820, %35
  %6823 = call float @dx.op.tertiary.f32(i32 46, float %6821, float %31, float %6822)  ; FMad(a,b,c)
  %6824 = call float @dx.op.tertiary.f32(i32 46, float %6807, float %27, float %6823)  ; FMad(a,b,c)
  %6825 = fadd fast float %6824, %23
  %6826 = call float @dx.op.unary.f32(i32 6, float %6825)  ; FAbs(value)
  %6827 = fcmp fast ogt float %6826, 0x3EB0C6F7A0000000
  br i1 %6827, label %6828, label %6949

; <label>:6828                                    ; preds = %6811
  %6829 = fmul fast float %6820, %34
  %6830 = call float @dx.op.tertiary.f32(i32 46, float %6821, float %30, float %6829)  ; FMad(a,b,c)
  %6831 = call float @dx.op.tertiary.f32(i32 46, float %6807, float %26, float %6830)  ; FMad(a,b,c)
  %6832 = fadd fast float %6831, %22
  %6833 = fmul fast float %6820, %33
  %6834 = call float @dx.op.tertiary.f32(i32 46, float %6821, float %29, float %6833)  ; FMad(a,b,c)
  %6835 = call float @dx.op.tertiary.f32(i32 46, float %6807, float %25, float %6834)  ; FMad(a,b,c)
  %6836 = fadd fast float %6835, %21
  %6837 = fmul fast float %6820, %32
  %6838 = call float @dx.op.tertiary.f32(i32 46, float %6821, float %28, float %6837)  ; FMad(a,b,c)
  %6839 = call float @dx.op.tertiary.f32(i32 46, float %6807, float %24, float %6838)  ; FMad(a,b,c)
  %6840 = fadd fast float %6839, %20
  %6841 = fdiv fast float %6840, %6825
  %6842 = fdiv fast float %6836, %6825
  %6843 = fdiv fast float %6832, %6825
  %6844 = fsub fast float %6841, %17
  %6845 = fsub fast float %6842, %18
  %6846 = fsub fast float %6843, %19
  %6847 = fmul fast float %6844, %6844
  %6848 = fmul fast float %6845, %6845
  %6849 = fadd fast float %6848, %6847
  %6850 = fmul fast float %6846, %6846
  %6851 = fadd fast float %6849, %6850
  %6852 = call float @dx.op.unary.f32(i32 24, float %6851)  ; Sqrt(value)
  %6853 = fsub fast float %6852, %9
  %6854 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %6853)  ; FMax(a,b)
  %6855 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %6855, label %6856, label %6879

; <label>:6856                                    ; preds = %6828
  %6857 = call float @dx.op.unary.f32(i32 6, float %6845)  ; FAbs(value)
  %6858 = fmul fast float %6857, %11
  %6859 = fcmp fast olt float %6858, 0x3F50624DE0000000
  br i1 %6859, label %6860, label %6863

; <label>:6860                                    ; preds = %6856
  %6861 = fmul fast float %6858, 5.000000e-01
  %6862 = fsub fast float 1.000000e+00, %6861
  br label %6868

; <label>:6863                                    ; preds = %6856
  %6864 = fmul fast float %6858, 0xBFF7154760000000
  %6865 = call float @dx.op.unary.f32(i32 21, float %6864)  ; Exp(value)
  %6866 = fsub fast float 1.000000e+00, %6865
  %6867 = fdiv fast float %6866, %6858
  br label %6868

; <label>:6868                                    ; preds = %6863, %6860
  %6869 = phi float [ %6862, %6860 ], [ %6867, %6863 ]
  %6870 = call float @dx.op.binary.f32(i32 36, float %6842, float %18)  ; FMin(a,b)
  %6871 = fsub fast float %6870, %10
  %6872 = fmul fast float %11, %6871
  %6873 = fsub fast float -0.000000e+00, %6872
  %6874 = call float @dx.op.binary.f32(i32 35, float %6873, float -4.000000e+01)  ; FMax(a,b)
  %6875 = call float @dx.op.binary.f32(i32 36, float %6874, float 5.000000e+00)  ; FMin(a,b)
  %6876 = fmul fast float %6875, 0x3FF7154760000000
  %6877 = call float @dx.op.unary.f32(i32 21, float %6876)  ; Exp(value)
  %6878 = fmul fast float %6877, %6869
  br label %6879

; <label>:6879                                    ; preds = %6868, %6828
  %6880 = phi float [ %6878, %6868 ], [ 1.000000e+00, %6828 ]
  %6881 = fmul fast float %6854, %16
  %6882 = fmul fast float %6881, %6880
  %6883 = fcmp fast ole float %6852, %9
  %6884 = fcmp fast olt float %6852, 0x3F1A36E2E0000000
  %6885 = or i1 %6883, %6884
  br i1 %6885, label %6932, label %6886

; <label>:6886                                    ; preds = %6879
  %6887 = fdiv fast float %9, %6852
  %6888 = fmul fast float %6887, %6844
  %6889 = fmul fast float %6887, %6845
  %6890 = fmul fast float %6887, %6846
  %6891 = fadd fast float %6888, %17
  %6892 = fadd fast float %6889, %18
  %6893 = fadd fast float %6890, %19
  %6894 = fadd fast float %6891, -9.000000e+02
  %6895 = fadd fast float %6892, -1.500000e+01
  %6896 = fadd fast float %6893, -7.500000e+02
  %6897 = fmul fast float %6894, 0x3F62345680000000
  %6898 = fmul fast float %6895, 0x3F62345680000000
  %6899 = fmul fast float %6896, 0x3F62345680000000
  %6900 = call float @dx.op.dot3.f32(i32 55, float %6897, float %6898, float %6899, float %6897, float %6898, float %6899)  ; Dot3(ax,ay,az,bx,by,bz)
  %6901 = fsub fast float 1.000000e+00, %6900
  %6902 = call float @dx.op.unary.f32(i32 7, float %6901)  ; Saturate(value)
  %6903 = fmul fast float %6902, %6902
  %6904 = fadd fast float %6891, %6841
  %6905 = fadd fast float %6892, %6842
  %6906 = fadd fast float %6893, %6843
  %6907 = fmul fast float %6904, 0x3F52345680000000
  %6908 = fadd fast float %6907, -2.000000e+00
  %6909 = fmul fast float %6905, 0x3F52345680000000
  %6910 = fadd fast float %6909, 0xBFA1111120000000
  %6911 = fmul fast float %6906, 0x3F52345680000000
  %6912 = fadd fast float %6911, 0xBFFAAAAAC0000000
  %6913 = call float @dx.op.dot3.f32(i32 55, float %6908, float %6910, float %6912, float %6908, float %6910, float %6912)  ; Dot3(ax,ay,az,bx,by,bz)
  %6914 = fsub fast float 1.000000e+00, %6913
  %6915 = call float @dx.op.unary.f32(i32 7, float %6914)  ; Saturate(value)
  %6916 = fmul fast float %6915, %6915
  %6917 = fmul fast float %6916, 4.000000e+00
  %6918 = fadd fast float %6917, %6903
  %6919 = fadd fast float %6841, -9.000000e+02
  %6920 = fadd fast float %6842, -1.500000e+01
  %6921 = fadd fast float %6843, -7.500000e+02
  %6922 = fmul fast float %6919, 0x3F62345680000000
  %6923 = fmul fast float %6920, 0x3F62345680000000
  %6924 = fmul fast float %6921, 0x3F62345680000000
  %6925 = call float @dx.op.dot3.f32(i32 55, float %6922, float %6923, float %6924, float %6922, float %6923, float %6924)  ; Dot3(ax,ay,az,bx,by,bz)
  %6926 = fsub fast float 1.000000e+00, %6925
  %6927 = call float @dx.op.unary.f32(i32 7, float %6926)  ; Saturate(value)
  %6928 = fmul fast float %6927, %6927
  %6929 = fadd fast float %6918, %6928
  %6930 = fmul fast float %6853, 0x3F25D867E0000000
  %6931 = fmul fast float %6930, %6929
  br label %6932

; <label>:6932                                    ; preds = %6886, %6879
  %6933 = phi float [ %6931, %6886 ], [ 0.000000e+00, %6879 ]
  %6934 = fadd fast float %6933, %6882
  %6935 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %6934)  ; FMin(a,b)
  %6936 = fmul fast float %6935, 0xBFF7154760000000
  %6937 = call float @dx.op.unary.f32(i32 21, float %6936)  ; Exp(value)
  %6938 = fsub fast float 1.000000e+00, %6937
  %6939 = call float @dx.op.binary.f32(i32 36, float %12, float %6938)  ; FMin(a,b)
  %6940 = fsub fast float %13, %6766
  %6941 = fsub fast float %14, %6767
  %6942 = fsub fast float %15, %6768
  %6943 = fmul fast float %6939, %6940
  %6944 = fmul fast float %6939, %6941
  %6945 = fmul fast float %6939, %6942
  %6946 = fadd fast float %6943, %6766
  %6947 = fadd fast float %6944, %6767
  %6948 = fadd fast float %6945, %6768
  br label %6949

; <label>:6949                                    ; preds = %6932, %6811, %6805
  %6950 = phi float [ %6946, %6932 ], [ %6766, %6811 ], [ %6766, %6805 ]
  %6951 = phi float [ %6947, %6932 ], [ %6767, %6811 ], [ %6767, %6805 ]
  %6952 = phi float [ %6948, %6932 ], [ %6768, %6811 ], [ %6768, %6805 ]
  %6953 = fadd fast float %5, 1.000000e+00
  %6954 = fadd fast float %6, 1.000000e+00
  %6955 = fsub fast float 1.000000e+00, %5
  %6956 = fmul fast float %36, %6953
  %6957 = fmul fast float %36, %6954
  %6958 = fmul fast float %36, %6955
  %6959 = fmul fast float %6956, %6950
  %6960 = fmul fast float %6957, %6951
  %6961 = fmul fast float %6958, %6952
  %6962 = fcmp fast ult float %37, 5.000000e-01
  br i1 %6962, label %6988, label %6963

; <label>:6963                                    ; preds = %6949
  %6964 = fmul fast float %6959, 0x4004147AE0000000
  %6965 = fmul fast float %6960, 0x4004147AE0000000
  %6966 = fmul fast float %6961, 0x4004147AE0000000
  %6967 = fadd fast float %6964, 0x3F9EB851E0000000
  %6968 = fadd fast float %6965, 0x3F9EB851E0000000
  %6969 = fadd fast float %6966, 0x3F9EB851E0000000
  %6970 = fmul fast float %6967, %6959
  %6971 = fmul fast float %6968, %6960
  %6972 = fmul fast float %6969, %6961
  %6973 = fmul fast float %6959, 0x400370A3E0000000
  %6974 = fmul fast float %6960, 0x400370A3E0000000
  %6975 = fmul fast float %6961, 0x400370A3E0000000
  %6976 = fadd fast float %6973, 0x3FE2E147A0000000
  %6977 = fadd fast float %6974, 0x3FE2E147A0000000
  %6978 = fadd fast float %6975, 0x3FE2E147A0000000
  %6979 = fmul fast float %6976, %6959
  %6980 = fmul fast float %6977, %6960
  %6981 = fmul fast float %6978, %6961
  %6982 = fadd fast float %6979, 0x3FC1EB8520000000
  %6983 = fadd fast float %6980, 0x3FC1EB8520000000
  %6984 = fadd fast float %6981, 0x3FC1EB8520000000
  %6985 = fdiv fast float %6970, %6982
  %6986 = fdiv fast float %6971, %6983
  %6987 = fdiv fast float %6972, %6984
  br label %6988

; <label>:6988                                    ; preds = %6963, %6949
  %6989 = phi float [ %6985, %6963 ], [ %6959, %6949 ]
  %6990 = phi float [ %6986, %6963 ], [ %6960, %6949 ]
  %6991 = phi float [ %6987, %6963 ], [ %6961, %6949 ]
  %6992 = call float @dx.op.unary.f32(i32 7, float %6989)  ; Saturate(value)
  %6993 = call float @dx.op.unary.f32(i32 7, float %6990)  ; Saturate(value)
  %6994 = call float @dx.op.unary.f32(i32 7, float %6991)  ; Saturate(value)
  %6995 = call float @dx.op.dot3.f32(i32 55, float %6992, float %6993, float %6994, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %6996 = fsub fast float %6992, %6995
  %6997 = fsub fast float %6993, %6995
  %6998 = fsub fast float %6994, %6995
  %6999 = fmul fast float %6996, %8
  %7000 = fmul fast float %6997, %8
  %7001 = fmul fast float %6998, %8
  %7002 = fadd fast float %6999, %6995
  %7003 = fadd fast float %7000, %6995
  %7004 = fadd fast float %7001, %6995
  %7005 = call float @dx.op.unary.f32(i32 7, float %7002)  ; Saturate(value)
  %7006 = call float @dx.op.unary.f32(i32 7, float %7003)  ; Saturate(value)
  %7007 = call float @dx.op.unary.f32(i32 7, float %7004)  ; Saturate(value)
  %7008 = fadd fast float %7005, 0xBFC70A3D80000000
  %7009 = fadd fast float %7006, 0xBFC70A3D80000000
  %7010 = fadd fast float %7007, 0xBFC70A3D80000000
  %7011 = fmul fast float %7008, %7
  %7012 = fmul fast float %7009, %7
  %7013 = fmul fast float %7010, %7
  %7014 = fadd fast float %7011, 0x3FC70A3D80000000
  %7015 = fadd fast float %7012, 0x3FC70A3D80000000
  %7016 = fadd fast float %7013, 0x3FC70A3D80000000
  %7017 = call float @dx.op.unary.f32(i32 7, float %7014)  ; Saturate(value)
  %7018 = call float @dx.op.unary.f32(i32 7, float %7015)  ; Saturate(value)
  %7019 = call float @dx.op.unary.f32(i32 7, float %7016)  ; Saturate(value)
  br label %7020

; <label>:7020                                    ; preds = %6988, %6771
  %7021 = phi float [ %6802, %6771 ], [ %7017, %6988 ]
  %7022 = phi float [ %6803, %6771 ], [ %7018, %6988 ]
  %7023 = phi float [ %6804, %6771 ], [ %7019, %6988 ]
  %7024 = fsub fast float %7021, %5875
  %7025 = fsub fast float %7022, %5876
  %7026 = fsub fast float %7023, %5877
  %7027 = fmul fast float %7024, %6758
  %7028 = fmul fast float %7025, %6758
  %7029 = fmul fast float %7026, %6758
  %7030 = fadd fast float %7027, %5875
  %7031 = fadd fast float %7028, %5876
  %7032 = fadd fast float %7029, %5877
  br label %7033

; <label>:7033                                    ; preds = %7020, %6745
  %7034 = phi float [ %7030, %7020 ], [ %5875, %6745 ]
  %7035 = phi float [ %7031, %7020 ], [ %5876, %6745 ]
  %7036 = phi float [ %7032, %7020 ], [ %5877, %6745 ]
  %7037 = call float @dx.op.binary.f32(i32 36, float %6746, float %7034)  ; FMin(a,b)
  %7038 = call float @dx.op.binary.f32(i32 36, float %6747, float %7035)  ; FMin(a,b)
  %7039 = call float @dx.op.binary.f32(i32 36, float %6748, float %7036)  ; FMin(a,b)
  %7040 = call float @dx.op.binary.f32(i32 36, float %6168, float %6456)  ; FMin(a,b)
  %7041 = call float @dx.op.binary.f32(i32 36, float %6169, float %6457)  ; FMin(a,b)
  %7042 = call float @dx.op.binary.f32(i32 36, float %6170, float %6458)  ; FMin(a,b)
  %7043 = call float @dx.op.binary.f32(i32 36, float %7040, float %7037)  ; FMin(a,b)
  %7044 = call float @dx.op.binary.f32(i32 36, float %7041, float %7038)  ; FMin(a,b)
  %7045 = call float @dx.op.binary.f32(i32 36, float %7042, float %7039)  ; FMin(a,b)
  %7046 = call float @dx.op.binary.f32(i32 36, float %5875, float %7043)  ; FMin(a,b)
  %7047 = call float @dx.op.binary.f32(i32 36, float %5876, float %7044)  ; FMin(a,b)
  %7048 = call float @dx.op.binary.f32(i32 36, float %5877, float %7045)  ; FMin(a,b)
  %7049 = call float @dx.op.binary.f32(i32 35, float %6746, float %7034)  ; FMax(a,b)
  %7050 = call float @dx.op.binary.f32(i32 35, float %6747, float %7035)  ; FMax(a,b)
  %7051 = call float @dx.op.binary.f32(i32 35, float %6748, float %7036)  ; FMax(a,b)
  %7052 = call float @dx.op.binary.f32(i32 35, float %6168, float %6456)  ; FMax(a,b)
  %7053 = call float @dx.op.binary.f32(i32 35, float %6169, float %6457)  ; FMax(a,b)
  %7054 = call float @dx.op.binary.f32(i32 35, float %6170, float %6458)  ; FMax(a,b)
  %7055 = call float @dx.op.binary.f32(i32 35, float %7052, float %7049)  ; FMax(a,b)
  %7056 = call float @dx.op.binary.f32(i32 35, float %7053, float %7050)  ; FMax(a,b)
  %7057 = call float @dx.op.binary.f32(i32 35, float %7054, float %7051)  ; FMax(a,b)
  %7058 = call float @dx.op.binary.f32(i32 35, float %5875, float %7055)  ; FMax(a,b)
  %7059 = call float @dx.op.binary.f32(i32 35, float %5876, float %7056)  ; FMax(a,b)
  %7060 = call float @dx.op.binary.f32(i32 35, float %5877, float %7057)  ; FMax(a,b)
  %7061 = fsub fast float %7058, %7046
  %7062 = fsub fast float %7059, %7047
  %7063 = fsub fast float %7060, %7048
  %7064 = call float @dx.op.unary.f32(i32 6, float %7061)  ; FAbs(value)
  %7065 = call float @dx.op.unary.f32(i32 6, float %7062)  ; FAbs(value)
  %7066 = call float @dx.op.unary.f32(i32 6, float %7063)  ; FAbs(value)
  %7067 = call float @dx.op.binary.f32(i32 35, float %7065, float %7066)  ; FMax(a,b)
  %7068 = call float @dx.op.binary.f32(i32 35, float %7064, float %7067)  ; FMax(a,b)
  %7069 = call float @dx.op.binary.f32(i32 35, float %7059, float %7060)  ; FMax(a,b)
  %7070 = call float @dx.op.binary.f32(i32 35, float %7058, float %7069)  ; FMax(a,b)
  %7071 = fmul fast float %7070, 1.250000e-01
  %7072 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %7071)  ; FMax(a,b)
  %7073 = fcmp fast ogt float %7068, %7072
  br i1 %7073, label %7074, label %7135

; <label>:7074                                    ; preds = %7033
  %7075 = fsub fast float %6168, %6456
  %7076 = fsub fast float %6169, %6457
  %7077 = fsub fast float %6170, %6458
  %7078 = call float @dx.op.unary.f32(i32 6, float %7075)  ; FAbs(value)
  %7079 = call float @dx.op.unary.f32(i32 6, float %7076)  ; FAbs(value)
  %7080 = call float @dx.op.unary.f32(i32 6, float %7077)  ; FAbs(value)
  %7081 = call float @dx.op.binary.f32(i32 35, float %7079, float %7080)  ; FMax(a,b)
  %7082 = call float @dx.op.binary.f32(i32 35, float %7078, float %7081)  ; FMax(a,b)
  %7083 = fsub fast float %6746, %7034
  %7084 = fsub fast float %6747, %7035
  %7085 = fsub fast float %6748, %7036
  %7086 = call float @dx.op.unary.f32(i32 6, float %7083)  ; FAbs(value)
  %7087 = call float @dx.op.unary.f32(i32 6, float %7084)  ; FAbs(value)
  %7088 = call float @dx.op.unary.f32(i32 6, float %7085)  ; FAbs(value)
  %7089 = call float @dx.op.binary.f32(i32 35, float %7087, float %7088)  ; FMax(a,b)
  %7090 = call float @dx.op.binary.f32(i32 35, float %7086, float %7089)  ; FMax(a,b)
  %7091 = fcmp fast olt float %7082, %7090
  %7092 = select i1 %7091, float %6168, float %6746
  %7093 = select i1 %7091, float %6169, float %6747
  %7094 = select i1 %7091, float %6170, float %6748
  %7095 = select i1 %7091, float %6456, float %7034
  %7096 = select i1 %7091, float %6457, float %7035
  %7097 = select i1 %7091, float %6458, float %7036
  %7098 = fsub fast float %5875, %7095
  %7099 = fsub fast float %5876, %7096
  %7100 = fsub fast float %5877, %7097
  %7101 = fsub fast float %5875, %7092
  %7102 = fsub fast float %5876, %7093
  %7103 = fsub fast float %5877, %7094
  %7104 = call float @dx.op.dot3.f32(i32 55, float %7101, float %7102, float %7103, float %7098, float %7099, float %7100)  ; Dot3(ax,ay,az,bx,by,bz)
  %7105 = fcmp fast ogt float %7104, 0.000000e+00
  br i1 %7105, label %7106, label %7117

; <label>:7106                                    ; preds = %7074
  %7107 = fsub fast float %7092, %7095
  %7108 = fsub fast float %7093, %7096
  %7109 = fsub fast float %7094, %7097
  %7110 = call float @dx.op.unary.f32(i32 6, float %7107)  ; FAbs(value)
  %7111 = call float @dx.op.unary.f32(i32 6, float %7108)  ; FAbs(value)
  %7112 = call float @dx.op.unary.f32(i32 6, float %7109)  ; FAbs(value)
  %7113 = call float @dx.op.binary.f32(i32 35, float %7111, float %7112)  ; FMax(a,b)
  %7114 = call float @dx.op.binary.f32(i32 35, float %7110, float %7113)  ; FMax(a,b)
  %7115 = fmul fast float %7068, 2.500000e-01
  %7116 = fcmp fast olt float %7114, %7115
  br label %7117

; <label>:7117                                    ; preds = %7106, %7074
  %7118 = phi i1 [ false, %7074 ], [ %7116, %7106 ]
  %7119 = select i1 %7118, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  %7120 = fadd fast float %7092, %7095
  %7121 = fadd fast float %7093, %7096
  %7122 = fadd fast float %7094, %7097
  %7123 = fmul fast float %7120, 5.000000e-01
  %7124 = fmul fast float %7121, 5.000000e-01
  %7125 = fmul fast float %7122, 5.000000e-01
  %7126 = fsub fast float %7123, %5875
  %7127 = fsub fast float %7124, %5876
  %7128 = fsub fast float %7125, %5877
  %7129 = fmul fast float %7119, %7126
  %7130 = fmul fast float %7119, %7127
  %7131 = fmul fast float %7119, %7128
  %7132 = fadd fast float %7129, %5875
  %7133 = fadd fast float %7130, %5876
  %7134 = fadd fast float %7131, %5877
  br label %7135

; <label>:7135                                    ; preds = %7117, %7033, %5630
  %7136 = phi float [ %5661, %5630 ], [ %7132, %7117 ], [ %5875, %7033 ]
  %7137 = phi float [ %5662, %5630 ], [ %7133, %7117 ], [ %5876, %7033 ]
  %7138 = phi float [ %5663, %5630 ], [ %7134, %7117 ], [ %5877, %7033 ]
  %7139 = phi float [ %5664, %5630 ], [ %5628, %7117 ], [ %5628, %7033 ]
  %7140 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %63, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7141 = extractvalue %dx.types.ResRet.f32 %7140, 0
  %7142 = extractvalue %dx.types.ResRet.f32 %7140, 1
  %7143 = extractvalue %dx.types.ResRet.f32 %7140, 2
  %7144 = extractvalue %dx.types.ResRet.f32 %7140, 3
  %7145 = fcmp fast olt float %7144, 0.000000e+00
  br i1 %7145, label %7146, label %7181

; <label>:7146                                    ; preds = %7135
  %7147 = fcmp fast ogt float %7141, 0x3FA4B5DCC0000000
  %7148 = fcmp fast ogt float %7142, 0x3FA4B5DCC0000000
  %7149 = fcmp fast ogt float %7143, 0x3FA4B5DCC0000000
  %7150 = select i1 %7147, float 0.000000e+00, float 1.000000e+00
  %7151 = select i1 %7148, float 0.000000e+00, float 1.000000e+00
  %7152 = select i1 %7149, float 0.000000e+00, float 1.000000e+00
  %7153 = fmul fast float %7141, 0x3FB3D07220000000
  %7154 = fmul fast float %7142, 0x3FB3D07220000000
  %7155 = fmul fast float %7143, 0x3FB3D07220000000
  %7156 = fadd fast float %7141, 0x3FAC28F5C0000000
  %7157 = fadd fast float %7142, 0x3FAC28F5C0000000
  %7158 = fadd fast float %7143, 0x3FAC28F5C0000000
  %7159 = fmul fast float %7156, 0x3FEE54EDE0000000
  %7160 = fmul fast float %7157, 0x3FEE54EDE0000000
  %7161 = fmul fast float %7158, 0x3FEE54EDE0000000
  %7162 = call float @dx.op.unary.f32(i32 23, float %7159)  ; Log(value)
  %7163 = call float @dx.op.unary.f32(i32 23, float %7160)  ; Log(value)
  %7164 = call float @dx.op.unary.f32(i32 23, float %7161)  ; Log(value)
  %7165 = fmul fast float %7162, 0x4003333340000000
  %7166 = fmul fast float %7163, 0x4003333340000000
  %7167 = fmul fast float %7164, 0x4003333340000000
  %7168 = call float @dx.op.unary.f32(i32 21, float %7165)  ; Exp(value)
  %7169 = call float @dx.op.unary.f32(i32 21, float %7166)  ; Exp(value)
  %7170 = call float @dx.op.unary.f32(i32 21, float %7167)  ; Exp(value)
  %7171 = fsub fast float %7153, %7168
  %7172 = fsub fast float %7154, %7169
  %7173 = fsub fast float %7155, %7170
  %7174 = fmul fast float %7171, %7150
  %7175 = fmul fast float %7172, %7151
  %7176 = fmul fast float %7173, %7152
  %7177 = fadd fast float %7174, %7168
  %7178 = fadd fast float %7175, %7169
  %7179 = fadd fast float %7176, %7170
  %7180 = fsub fast float -1.000000e+00, %7144
  br label %8651

; <label>:7181                                    ; preds = %7135
  %7182 = fcmp fast ogt float %38, 5.000000e-01
  %7183 = fcmp fast olt float %86, 1.000000e+00
  %7184 = and i1 %7182, %7183
  br i1 %7184, label %7185, label %7323

; <label>:7185                                    ; preds = %7181
  %7186 = sitofp i32 %63 to float
  %7187 = sitofp i32 %70 to float
  %7188 = fadd fast float %7186, 5.000000e-01
  %7189 = fadd fast float %7187, 5.000000e-01
  %7190 = fdiv fast float %7188, %45
  %7191 = fdiv fast float %7189, %46
  %7192 = fmul fast float %7190, 2.000000e+00
  %7193 = fmul fast float %7191, 2.000000e+00
  %7194 = fadd fast float %7192, -1.000000e+00
  %7195 = fsub fast float 1.000000e+00, %7193
  %7196 = fmul fast float %7194, %35
  %7197 = call float @dx.op.tertiary.f32(i32 46, float %7195, float %31, float %7196)  ; FMad(a,b,c)
  %7198 = call float @dx.op.tertiary.f32(i32 46, float %86, float %27, float %7197)  ; FMad(a,b,c)
  %7199 = fadd fast float %7198, %23
  %7200 = call float @dx.op.unary.f32(i32 6, float %7199)  ; FAbs(value)
  %7201 = fcmp fast ogt float %7200, 0x3EB0C6F7A0000000
  br i1 %7201, label %7202, label %7323

; <label>:7202                                    ; preds = %7185
  %7203 = fmul fast float %7194, %34
  %7204 = call float @dx.op.tertiary.f32(i32 46, float %7195, float %30, float %7203)  ; FMad(a,b,c)
  %7205 = call float @dx.op.tertiary.f32(i32 46, float %86, float %26, float %7204)  ; FMad(a,b,c)
  %7206 = fadd fast float %7205, %22
  %7207 = fmul fast float %7194, %33
  %7208 = call float @dx.op.tertiary.f32(i32 46, float %7195, float %29, float %7207)  ; FMad(a,b,c)
  %7209 = call float @dx.op.tertiary.f32(i32 46, float %86, float %25, float %7208)  ; FMad(a,b,c)
  %7210 = fadd fast float %7209, %21
  %7211 = fmul fast float %7194, %32
  %7212 = call float @dx.op.tertiary.f32(i32 46, float %7195, float %28, float %7211)  ; FMad(a,b,c)
  %7213 = call float @dx.op.tertiary.f32(i32 46, float %86, float %24, float %7212)  ; FMad(a,b,c)
  %7214 = fadd fast float %7213, %20
  %7215 = fdiv fast float %7214, %7199
  %7216 = fdiv fast float %7210, %7199
  %7217 = fdiv fast float %7206, %7199
  %7218 = fsub fast float %7215, %17
  %7219 = fsub fast float %7216, %18
  %7220 = fsub fast float %7217, %19
  %7221 = fmul fast float %7218, %7218
  %7222 = fmul fast float %7219, %7219
  %7223 = fadd fast float %7222, %7221
  %7224 = fmul fast float %7220, %7220
  %7225 = fadd fast float %7223, %7224
  %7226 = call float @dx.op.unary.f32(i32 24, float %7225)  ; Sqrt(value)
  %7227 = fsub fast float %7226, %9
  %7228 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %7227)  ; FMax(a,b)
  %7229 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %7229, label %7230, label %7253

; <label>:7230                                    ; preds = %7202
  %7231 = call float @dx.op.unary.f32(i32 6, float %7219)  ; FAbs(value)
  %7232 = fmul fast float %7231, %11
  %7233 = fcmp fast olt float %7232, 0x3F50624DE0000000
  br i1 %7233, label %7234, label %7237

; <label>:7234                                    ; preds = %7230
  %7235 = fmul fast float %7232, 5.000000e-01
  %7236 = fsub fast float 1.000000e+00, %7235
  br label %7242

; <label>:7237                                    ; preds = %7230
  %7238 = fmul fast float %7232, 0xBFF7154760000000
  %7239 = call float @dx.op.unary.f32(i32 21, float %7238)  ; Exp(value)
  %7240 = fsub fast float 1.000000e+00, %7239
  %7241 = fdiv fast float %7240, %7232
  br label %7242

; <label>:7242                                    ; preds = %7237, %7234
  %7243 = phi float [ %7236, %7234 ], [ %7241, %7237 ]
  %7244 = call float @dx.op.binary.f32(i32 36, float %7216, float %18)  ; FMin(a,b)
  %7245 = fsub fast float %7244, %10
  %7246 = fmul fast float %11, %7245
  %7247 = fsub fast float -0.000000e+00, %7246
  %7248 = call float @dx.op.binary.f32(i32 35, float %7247, float -4.000000e+01)  ; FMax(a,b)
  %7249 = call float @dx.op.binary.f32(i32 36, float %7248, float 5.000000e+00)  ; FMin(a,b)
  %7250 = fmul fast float %7249, 0x3FF7154760000000
  %7251 = call float @dx.op.unary.f32(i32 21, float %7250)  ; Exp(value)
  %7252 = fmul fast float %7251, %7243
  br label %7253

; <label>:7253                                    ; preds = %7242, %7202
  %7254 = phi float [ %7252, %7242 ], [ 1.000000e+00, %7202 ]
  %7255 = fmul fast float %7228, %16
  %7256 = fmul fast float %7255, %7254
  %7257 = fcmp fast ole float %7226, %9
  %7258 = fcmp fast olt float %7226, 0x3F1A36E2E0000000
  %7259 = or i1 %7257, %7258
  br i1 %7259, label %7306, label %7260

; <label>:7260                                    ; preds = %7253
  %7261 = fdiv fast float %9, %7226
  %7262 = fmul fast float %7261, %7218
  %7263 = fmul fast float %7261, %7219
  %7264 = fmul fast float %7261, %7220
  %7265 = fadd fast float %7262, %17
  %7266 = fadd fast float %7263, %18
  %7267 = fadd fast float %7264, %19
  %7268 = fadd fast float %7265, -9.000000e+02
  %7269 = fadd fast float %7266, -1.500000e+01
  %7270 = fadd fast float %7267, -7.500000e+02
  %7271 = fmul fast float %7268, 0x3F62345680000000
  %7272 = fmul fast float %7269, 0x3F62345680000000
  %7273 = fmul fast float %7270, 0x3F62345680000000
  %7274 = call float @dx.op.dot3.f32(i32 55, float %7271, float %7272, float %7273, float %7271, float %7272, float %7273)  ; Dot3(ax,ay,az,bx,by,bz)
  %7275 = fsub fast float 1.000000e+00, %7274
  %7276 = call float @dx.op.unary.f32(i32 7, float %7275)  ; Saturate(value)
  %7277 = fmul fast float %7276, %7276
  %7278 = fadd fast float %7265, %7215
  %7279 = fadd fast float %7266, %7216
  %7280 = fadd fast float %7267, %7217
  %7281 = fmul fast float %7278, 0x3F52345680000000
  %7282 = fadd fast float %7281, -2.000000e+00
  %7283 = fmul fast float %7279, 0x3F52345680000000
  %7284 = fadd fast float %7283, 0xBFA1111120000000
  %7285 = fmul fast float %7280, 0x3F52345680000000
  %7286 = fadd fast float %7285, 0xBFFAAAAAC0000000
  %7287 = call float @dx.op.dot3.f32(i32 55, float %7282, float %7284, float %7286, float %7282, float %7284, float %7286)  ; Dot3(ax,ay,az,bx,by,bz)
  %7288 = fsub fast float 1.000000e+00, %7287
  %7289 = call float @dx.op.unary.f32(i32 7, float %7288)  ; Saturate(value)
  %7290 = fmul fast float %7289, %7289
  %7291 = fmul fast float %7290, 4.000000e+00
  %7292 = fadd fast float %7291, %7277
  %7293 = fadd fast float %7215, -9.000000e+02
  %7294 = fadd fast float %7216, -1.500000e+01
  %7295 = fadd fast float %7217, -7.500000e+02
  %7296 = fmul fast float %7293, 0x3F62345680000000
  %7297 = fmul fast float %7294, 0x3F62345680000000
  %7298 = fmul fast float %7295, 0x3F62345680000000
  %7299 = call float @dx.op.dot3.f32(i32 55, float %7296, float %7297, float %7298, float %7296, float %7297, float %7298)  ; Dot3(ax,ay,az,bx,by,bz)
  %7300 = fsub fast float 1.000000e+00, %7299
  %7301 = call float @dx.op.unary.f32(i32 7, float %7300)  ; Saturate(value)
  %7302 = fmul fast float %7301, %7301
  %7303 = fadd fast float %7292, %7302
  %7304 = fmul fast float %7227, 0x3F25D867E0000000
  %7305 = fmul fast float %7304, %7303
  br label %7306

; <label>:7306                                    ; preds = %7260, %7253
  %7307 = phi float [ %7305, %7260 ], [ 0.000000e+00, %7253 ]
  %7308 = fadd fast float %7307, %7256
  %7309 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %7308)  ; FMin(a,b)
  %7310 = fmul fast float %7309, 0xBFF7154760000000
  %7311 = call float @dx.op.unary.f32(i32 21, float %7310)  ; Exp(value)
  %7312 = fsub fast float 1.000000e+00, %7311
  %7313 = call float @dx.op.binary.f32(i32 36, float %12, float %7312)  ; FMin(a,b)
  %7314 = fsub fast float %13, %7141
  %7315 = fsub fast float %14, %7142
  %7316 = fsub fast float %15, %7143
  %7317 = fmul fast float %7313, %7314
  %7318 = fmul fast float %7313, %7315
  %7319 = fmul fast float %7313, %7316
  %7320 = fadd fast float %7317, %7141
  %7321 = fadd fast float %7318, %7142
  %7322 = fadd fast float %7319, %7143
  br label %7323

; <label>:7323                                    ; preds = %7306, %7185, %7181
  %7324 = phi float [ %7320, %7306 ], [ %7141, %7185 ], [ %7141, %7181 ]
  %7325 = phi float [ %7321, %7306 ], [ %7142, %7185 ], [ %7142, %7181 ]
  %7326 = phi float [ %7322, %7306 ], [ %7143, %7185 ], [ %7143, %7181 ]
  %7327 = fadd fast float %5, 1.000000e+00
  %7328 = fadd fast float %6, 1.000000e+00
  %7329 = fsub fast float 1.000000e+00, %5
  %7330 = fmul fast float %36, %7327
  %7331 = fmul fast float %36, %7328
  %7332 = fmul fast float %36, %7329
  %7333 = fmul fast float %7330, %7324
  %7334 = fmul fast float %7331, %7325
  %7335 = fmul fast float %7332, %7326
  %7336 = fcmp fast ult float %37, 5.000000e-01
  br i1 %7336, label %7362, label %7337

; <label>:7337                                    ; preds = %7323
  %7338 = fmul fast float %7333, 0x4004147AE0000000
  %7339 = fmul fast float %7334, 0x4004147AE0000000
  %7340 = fmul fast float %7335, 0x4004147AE0000000
  %7341 = fadd fast float %7338, 0x3F9EB851E0000000
  %7342 = fadd fast float %7339, 0x3F9EB851E0000000
  %7343 = fadd fast float %7340, 0x3F9EB851E0000000
  %7344 = fmul fast float %7341, %7333
  %7345 = fmul fast float %7342, %7334
  %7346 = fmul fast float %7343, %7335
  %7347 = fmul fast float %7333, 0x400370A3E0000000
  %7348 = fmul fast float %7334, 0x400370A3E0000000
  %7349 = fmul fast float %7335, 0x400370A3E0000000
  %7350 = fadd fast float %7347, 0x3FE2E147A0000000
  %7351 = fadd fast float %7348, 0x3FE2E147A0000000
  %7352 = fadd fast float %7349, 0x3FE2E147A0000000
  %7353 = fmul fast float %7350, %7333
  %7354 = fmul fast float %7351, %7334
  %7355 = fmul fast float %7352, %7335
  %7356 = fadd fast float %7353, 0x3FC1EB8520000000
  %7357 = fadd fast float %7354, 0x3FC1EB8520000000
  %7358 = fadd fast float %7355, 0x3FC1EB8520000000
  %7359 = fdiv fast float %7344, %7356
  %7360 = fdiv fast float %7345, %7357
  %7361 = fdiv fast float %7346, %7358
  br label %7362

; <label>:7362                                    ; preds = %7337, %7323
  %7363 = phi float [ %7359, %7337 ], [ %7333, %7323 ]
  %7364 = phi float [ %7360, %7337 ], [ %7334, %7323 ]
  %7365 = phi float [ %7361, %7337 ], [ %7335, %7323 ]
  %7366 = call float @dx.op.unary.f32(i32 7, float %7363)  ; Saturate(value)
  %7367 = call float @dx.op.unary.f32(i32 7, float %7364)  ; Saturate(value)
  %7368 = call float @dx.op.unary.f32(i32 7, float %7365)  ; Saturate(value)
  %7369 = call float @dx.op.dot3.f32(i32 55, float %7366, float %7367, float %7368, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %7370 = fsub fast float %7366, %7369
  %7371 = fsub fast float %7367, %7369
  %7372 = fsub fast float %7368, %7369
  %7373 = fmul fast float %7370, %8
  %7374 = fmul fast float %7371, %8
  %7375 = fmul fast float %7372, %8
  %7376 = fadd fast float %7373, %7369
  %7377 = fadd fast float %7374, %7369
  %7378 = fadd fast float %7375, %7369
  %7379 = call float @dx.op.unary.f32(i32 7, float %7376)  ; Saturate(value)
  %7380 = call float @dx.op.unary.f32(i32 7, float %7377)  ; Saturate(value)
  %7381 = call float @dx.op.unary.f32(i32 7, float %7378)  ; Saturate(value)
  %7382 = fadd fast float %7379, 0xBFC70A3D80000000
  %7383 = fadd fast float %7380, 0xBFC70A3D80000000
  %7384 = fadd fast float %7381, 0xBFC70A3D80000000
  %7385 = fmul fast float %7382, %7
  %7386 = fmul fast float %7383, %7
  %7387 = fmul fast float %7384, %7
  %7388 = fadd fast float %7385, 0x3FC70A3D80000000
  %7389 = fadd fast float %7386, 0x3FC70A3D80000000
  %7390 = fadd fast float %7387, 0x3FC70A3D80000000
  %7391 = call float @dx.op.unary.f32(i32 7, float %7388)  ; Saturate(value)
  %7392 = call float @dx.op.unary.f32(i32 7, float %7389)  ; Saturate(value)
  %7393 = call float @dx.op.unary.f32(i32 7, float %7390)  ; Saturate(value)
  %7394 = add i32 %70, -1
  %7395 = call i32 @dx.op.binary.i32(i32 37, i32 %63, i32 0)  ; IMax(a,b)
  %7396 = call i32 @dx.op.binary.i32(i32 37, i32 %7394, i32 0)  ; IMax(a,b)
  %7397 = call i32 @dx.op.binary.i32(i32 38, i32 %7395, i32 %59)  ; IMin(a,b)
  %7398 = call i32 @dx.op.binary.i32(i32 38, i32 %7396, i32 %60)  ; IMin(a,b)
  %7399 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %7397, i32 %7398, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7400 = extractvalue %dx.types.ResRet.f32 %7399, 0
  %7401 = fsub fast float 1.000000e+00, %86
  %7402 = fmul fast float %7401, 0x3FA99999A0000000
  %7403 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %7402)  ; FMax(a,b)
  %7404 = fsub fast float %7400, %86
  %7405 = call float @dx.op.unary.f32(i32 6, float %7404)  ; FAbs(value)
  %7406 = fdiv fast float %7405, %7403
  %7407 = fsub fast float 1.000000e+00, %7406
  %7408 = call float @dx.op.unary.f32(i32 7, float %7407)  ; Saturate(value)
  %7409 = fcmp fast ugt float %7408, 0.000000e+00
  br i1 %7409, label %7410, label %7683

; <label>:7410                                    ; preds = %7362
  %7411 = call i32 @dx.op.binary.i32(i32 37, i32 %7397, i32 0)  ; IMax(a,b)
  %7412 = call i32 @dx.op.binary.i32(i32 37, i32 %7398, i32 0)  ; IMax(a,b)
  %7413 = call i32 @dx.op.binary.i32(i32 38, i32 %7411, i32 %59)  ; IMin(a,b)
  %7414 = call i32 @dx.op.binary.i32(i32 38, i32 %7412, i32 %60)  ; IMin(a,b)
  %7415 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %7413, i32 %7414, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7416 = extractvalue %dx.types.ResRet.f32 %7415, 0
  %7417 = extractvalue %dx.types.ResRet.f32 %7415, 1
  %7418 = extractvalue %dx.types.ResRet.f32 %7415, 2
  %7419 = extractvalue %dx.types.ResRet.f32 %7415, 3
  %7420 = fcmp fast olt float %7419, 0.000000e+00
  br i1 %7420, label %7421, label %7455

; <label>:7421                                    ; preds = %7410
  %7422 = fcmp fast ogt float %7416, 0x3FA4B5DCC0000000
  %7423 = fcmp fast ogt float %7417, 0x3FA4B5DCC0000000
  %7424 = fcmp fast ogt float %7418, 0x3FA4B5DCC0000000
  %7425 = select i1 %7422, float 0.000000e+00, float 1.000000e+00
  %7426 = select i1 %7423, float 0.000000e+00, float 1.000000e+00
  %7427 = select i1 %7424, float 0.000000e+00, float 1.000000e+00
  %7428 = fmul fast float %7416, 0x3FB3D07220000000
  %7429 = fmul fast float %7417, 0x3FB3D07220000000
  %7430 = fmul fast float %7418, 0x3FB3D07220000000
  %7431 = fadd fast float %7416, 0x3FAC28F5C0000000
  %7432 = fadd fast float %7417, 0x3FAC28F5C0000000
  %7433 = fadd fast float %7418, 0x3FAC28F5C0000000
  %7434 = fmul fast float %7431, 0x3FEE54EDE0000000
  %7435 = fmul fast float %7432, 0x3FEE54EDE0000000
  %7436 = fmul fast float %7433, 0x3FEE54EDE0000000
  %7437 = call float @dx.op.unary.f32(i32 23, float %7434)  ; Log(value)
  %7438 = call float @dx.op.unary.f32(i32 23, float %7435)  ; Log(value)
  %7439 = call float @dx.op.unary.f32(i32 23, float %7436)  ; Log(value)
  %7440 = fmul fast float %7437, 0x4003333340000000
  %7441 = fmul fast float %7438, 0x4003333340000000
  %7442 = fmul fast float %7439, 0x4003333340000000
  %7443 = call float @dx.op.unary.f32(i32 21, float %7440)  ; Exp(value)
  %7444 = call float @dx.op.unary.f32(i32 21, float %7441)  ; Exp(value)
  %7445 = call float @dx.op.unary.f32(i32 21, float %7442)  ; Exp(value)
  %7446 = fsub fast float %7428, %7443
  %7447 = fsub fast float %7429, %7444
  %7448 = fsub fast float %7430, %7445
  %7449 = fmul fast float %7446, %7425
  %7450 = fmul fast float %7447, %7426
  %7451 = fmul fast float %7448, %7427
  %7452 = fadd fast float %7449, %7443
  %7453 = fadd fast float %7450, %7444
  %7454 = fadd fast float %7451, %7445
  br label %7670

; <label>:7455                                    ; preds = %7410
  %7456 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %7413, i32 %7414, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7457 = extractvalue %dx.types.ResRet.f32 %7456, 0
  %7458 = fcmp fast ogt float %38, 5.000000e-01
  %7459 = fcmp fast olt float %7457, 1.000000e+00
  %7460 = and i1 %7458, %7459
  br i1 %7460, label %7461, label %7599

; <label>:7461                                    ; preds = %7455
  %7462 = sitofp i32 %7413 to float
  %7463 = sitofp i32 %7414 to float
  %7464 = fadd fast float %7462, 5.000000e-01
  %7465 = fadd fast float %7463, 5.000000e-01
  %7466 = fdiv fast float %7464, %45
  %7467 = fdiv fast float %7465, %46
  %7468 = fmul fast float %7466, 2.000000e+00
  %7469 = fmul fast float %7467, 2.000000e+00
  %7470 = fadd fast float %7468, -1.000000e+00
  %7471 = fsub fast float 1.000000e+00, %7469
  %7472 = fmul fast float %7470, %35
  %7473 = call float @dx.op.tertiary.f32(i32 46, float %7471, float %31, float %7472)  ; FMad(a,b,c)
  %7474 = call float @dx.op.tertiary.f32(i32 46, float %7457, float %27, float %7473)  ; FMad(a,b,c)
  %7475 = fadd fast float %7474, %23
  %7476 = call float @dx.op.unary.f32(i32 6, float %7475)  ; FAbs(value)
  %7477 = fcmp fast ogt float %7476, 0x3EB0C6F7A0000000
  br i1 %7477, label %7478, label %7599

; <label>:7478                                    ; preds = %7461
  %7479 = fmul fast float %7470, %34
  %7480 = call float @dx.op.tertiary.f32(i32 46, float %7471, float %30, float %7479)  ; FMad(a,b,c)
  %7481 = call float @dx.op.tertiary.f32(i32 46, float %7457, float %26, float %7480)  ; FMad(a,b,c)
  %7482 = fadd fast float %7481, %22
  %7483 = fmul fast float %7470, %33
  %7484 = call float @dx.op.tertiary.f32(i32 46, float %7471, float %29, float %7483)  ; FMad(a,b,c)
  %7485 = call float @dx.op.tertiary.f32(i32 46, float %7457, float %25, float %7484)  ; FMad(a,b,c)
  %7486 = fadd fast float %7485, %21
  %7487 = fmul fast float %7470, %32
  %7488 = call float @dx.op.tertiary.f32(i32 46, float %7471, float %28, float %7487)  ; FMad(a,b,c)
  %7489 = call float @dx.op.tertiary.f32(i32 46, float %7457, float %24, float %7488)  ; FMad(a,b,c)
  %7490 = fadd fast float %7489, %20
  %7491 = fdiv fast float %7490, %7475
  %7492 = fdiv fast float %7486, %7475
  %7493 = fdiv fast float %7482, %7475
  %7494 = fsub fast float %7491, %17
  %7495 = fsub fast float %7492, %18
  %7496 = fsub fast float %7493, %19
  %7497 = fmul fast float %7494, %7494
  %7498 = fmul fast float %7495, %7495
  %7499 = fadd fast float %7498, %7497
  %7500 = fmul fast float %7496, %7496
  %7501 = fadd fast float %7499, %7500
  %7502 = call float @dx.op.unary.f32(i32 24, float %7501)  ; Sqrt(value)
  %7503 = fsub fast float %7502, %9
  %7504 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %7503)  ; FMax(a,b)
  %7505 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %7505, label %7506, label %7529

; <label>:7506                                    ; preds = %7478
  %7507 = call float @dx.op.unary.f32(i32 6, float %7495)  ; FAbs(value)
  %7508 = fmul fast float %7507, %11
  %7509 = fcmp fast olt float %7508, 0x3F50624DE0000000
  br i1 %7509, label %7510, label %7513

; <label>:7510                                    ; preds = %7506
  %7511 = fmul fast float %7508, 5.000000e-01
  %7512 = fsub fast float 1.000000e+00, %7511
  br label %7518

; <label>:7513                                    ; preds = %7506
  %7514 = fmul fast float %7508, 0xBFF7154760000000
  %7515 = call float @dx.op.unary.f32(i32 21, float %7514)  ; Exp(value)
  %7516 = fsub fast float 1.000000e+00, %7515
  %7517 = fdiv fast float %7516, %7508
  br label %7518

; <label>:7518                                    ; preds = %7513, %7510
  %7519 = phi float [ %7512, %7510 ], [ %7517, %7513 ]
  %7520 = call float @dx.op.binary.f32(i32 36, float %7492, float %18)  ; FMin(a,b)
  %7521 = fsub fast float %7520, %10
  %7522 = fmul fast float %11, %7521
  %7523 = fsub fast float -0.000000e+00, %7522
  %7524 = call float @dx.op.binary.f32(i32 35, float %7523, float -4.000000e+01)  ; FMax(a,b)
  %7525 = call float @dx.op.binary.f32(i32 36, float %7524, float 5.000000e+00)  ; FMin(a,b)
  %7526 = fmul fast float %7525, 0x3FF7154760000000
  %7527 = call float @dx.op.unary.f32(i32 21, float %7526)  ; Exp(value)
  %7528 = fmul fast float %7527, %7519
  br label %7529

; <label>:7529                                    ; preds = %7518, %7478
  %7530 = phi float [ %7528, %7518 ], [ 1.000000e+00, %7478 ]
  %7531 = fmul fast float %7504, %16
  %7532 = fmul fast float %7531, %7530
  %7533 = fcmp fast ole float %7502, %9
  %7534 = fcmp fast olt float %7502, 0x3F1A36E2E0000000
  %7535 = or i1 %7533, %7534
  br i1 %7535, label %7582, label %7536

; <label>:7536                                    ; preds = %7529
  %7537 = fdiv fast float %9, %7502
  %7538 = fmul fast float %7537, %7494
  %7539 = fmul fast float %7537, %7495
  %7540 = fmul fast float %7537, %7496
  %7541 = fadd fast float %7538, %17
  %7542 = fadd fast float %7539, %18
  %7543 = fadd fast float %7540, %19
  %7544 = fadd fast float %7541, -9.000000e+02
  %7545 = fadd fast float %7542, -1.500000e+01
  %7546 = fadd fast float %7543, -7.500000e+02
  %7547 = fmul fast float %7544, 0x3F62345680000000
  %7548 = fmul fast float %7545, 0x3F62345680000000
  %7549 = fmul fast float %7546, 0x3F62345680000000
  %7550 = call float @dx.op.dot3.f32(i32 55, float %7547, float %7548, float %7549, float %7547, float %7548, float %7549)  ; Dot3(ax,ay,az,bx,by,bz)
  %7551 = fsub fast float 1.000000e+00, %7550
  %7552 = call float @dx.op.unary.f32(i32 7, float %7551)  ; Saturate(value)
  %7553 = fmul fast float %7552, %7552
  %7554 = fadd fast float %7541, %7491
  %7555 = fadd fast float %7542, %7492
  %7556 = fadd fast float %7543, %7493
  %7557 = fmul fast float %7554, 0x3F52345680000000
  %7558 = fadd fast float %7557, -2.000000e+00
  %7559 = fmul fast float %7555, 0x3F52345680000000
  %7560 = fadd fast float %7559, 0xBFA1111120000000
  %7561 = fmul fast float %7556, 0x3F52345680000000
  %7562 = fadd fast float %7561, 0xBFFAAAAAC0000000
  %7563 = call float @dx.op.dot3.f32(i32 55, float %7558, float %7560, float %7562, float %7558, float %7560, float %7562)  ; Dot3(ax,ay,az,bx,by,bz)
  %7564 = fsub fast float 1.000000e+00, %7563
  %7565 = call float @dx.op.unary.f32(i32 7, float %7564)  ; Saturate(value)
  %7566 = fmul fast float %7565, %7565
  %7567 = fmul fast float %7566, 4.000000e+00
  %7568 = fadd fast float %7567, %7553
  %7569 = fadd fast float %7491, -9.000000e+02
  %7570 = fadd fast float %7492, -1.500000e+01
  %7571 = fadd fast float %7493, -7.500000e+02
  %7572 = fmul fast float %7569, 0x3F62345680000000
  %7573 = fmul fast float %7570, 0x3F62345680000000
  %7574 = fmul fast float %7571, 0x3F62345680000000
  %7575 = call float @dx.op.dot3.f32(i32 55, float %7572, float %7573, float %7574, float %7572, float %7573, float %7574)  ; Dot3(ax,ay,az,bx,by,bz)
  %7576 = fsub fast float 1.000000e+00, %7575
  %7577 = call float @dx.op.unary.f32(i32 7, float %7576)  ; Saturate(value)
  %7578 = fmul fast float %7577, %7577
  %7579 = fadd fast float %7568, %7578
  %7580 = fmul fast float %7503, 0x3F25D867E0000000
  %7581 = fmul fast float %7580, %7579
  br label %7582

; <label>:7582                                    ; preds = %7536, %7529
  %7583 = phi float [ %7581, %7536 ], [ 0.000000e+00, %7529 ]
  %7584 = fadd fast float %7583, %7532
  %7585 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %7584)  ; FMin(a,b)
  %7586 = fmul fast float %7585, 0xBFF7154760000000
  %7587 = call float @dx.op.unary.f32(i32 21, float %7586)  ; Exp(value)
  %7588 = fsub fast float 1.000000e+00, %7587
  %7589 = call float @dx.op.binary.f32(i32 36, float %12, float %7588)  ; FMin(a,b)
  %7590 = fsub fast float %13, %7416
  %7591 = fsub fast float %14, %7417
  %7592 = fsub fast float %15, %7418
  %7593 = fmul fast float %7589, %7590
  %7594 = fmul fast float %7589, %7591
  %7595 = fmul fast float %7589, %7592
  %7596 = fadd fast float %7593, %7416
  %7597 = fadd fast float %7594, %7417
  %7598 = fadd fast float %7595, %7418
  br label %7599

; <label>:7599                                    ; preds = %7582, %7461, %7455
  %7600 = phi float [ %7596, %7582 ], [ %7416, %7461 ], [ %7416, %7455 ]
  %7601 = phi float [ %7597, %7582 ], [ %7417, %7461 ], [ %7417, %7455 ]
  %7602 = phi float [ %7598, %7582 ], [ %7418, %7461 ], [ %7418, %7455 ]
  %7603 = fadd fast float %5, 1.000000e+00
  %7604 = fadd fast float %6, 1.000000e+00
  %7605 = fsub fast float 1.000000e+00, %5
  %7606 = fmul fast float %36, %7603
  %7607 = fmul fast float %36, %7604
  %7608 = fmul fast float %36, %7605
  %7609 = fmul fast float %7606, %7600
  %7610 = fmul fast float %7607, %7601
  %7611 = fmul fast float %7608, %7602
  %7612 = fcmp fast ult float %37, 5.000000e-01
  br i1 %7612, label %7638, label %7613

; <label>:7613                                    ; preds = %7599
  %7614 = fmul fast float %7609, 0x4004147AE0000000
  %7615 = fmul fast float %7610, 0x4004147AE0000000
  %7616 = fmul fast float %7611, 0x4004147AE0000000
  %7617 = fadd fast float %7614, 0x3F9EB851E0000000
  %7618 = fadd fast float %7615, 0x3F9EB851E0000000
  %7619 = fadd fast float %7616, 0x3F9EB851E0000000
  %7620 = fmul fast float %7617, %7609
  %7621 = fmul fast float %7618, %7610
  %7622 = fmul fast float %7619, %7611
  %7623 = fmul fast float %7609, 0x400370A3E0000000
  %7624 = fmul fast float %7610, 0x400370A3E0000000
  %7625 = fmul fast float %7611, 0x400370A3E0000000
  %7626 = fadd fast float %7623, 0x3FE2E147A0000000
  %7627 = fadd fast float %7624, 0x3FE2E147A0000000
  %7628 = fadd fast float %7625, 0x3FE2E147A0000000
  %7629 = fmul fast float %7626, %7609
  %7630 = fmul fast float %7627, %7610
  %7631 = fmul fast float %7628, %7611
  %7632 = fadd fast float %7629, 0x3FC1EB8520000000
  %7633 = fadd fast float %7630, 0x3FC1EB8520000000
  %7634 = fadd fast float %7631, 0x3FC1EB8520000000
  %7635 = fdiv fast float %7620, %7632
  %7636 = fdiv fast float %7621, %7633
  %7637 = fdiv fast float %7622, %7634
  br label %7638

; <label>:7638                                    ; preds = %7613, %7599
  %7639 = phi float [ %7635, %7613 ], [ %7609, %7599 ]
  %7640 = phi float [ %7636, %7613 ], [ %7610, %7599 ]
  %7641 = phi float [ %7637, %7613 ], [ %7611, %7599 ]
  %7642 = call float @dx.op.unary.f32(i32 7, float %7639)  ; Saturate(value)
  %7643 = call float @dx.op.unary.f32(i32 7, float %7640)  ; Saturate(value)
  %7644 = call float @dx.op.unary.f32(i32 7, float %7641)  ; Saturate(value)
  %7645 = call float @dx.op.dot3.f32(i32 55, float %7642, float %7643, float %7644, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %7646 = fsub fast float %7642, %7645
  %7647 = fsub fast float %7643, %7645
  %7648 = fsub fast float %7644, %7645
  %7649 = fmul fast float %7646, %8
  %7650 = fmul fast float %7647, %8
  %7651 = fmul fast float %7648, %8
  %7652 = fadd fast float %7649, %7645
  %7653 = fadd fast float %7650, %7645
  %7654 = fadd fast float %7651, %7645
  %7655 = call float @dx.op.unary.f32(i32 7, float %7652)  ; Saturate(value)
  %7656 = call float @dx.op.unary.f32(i32 7, float %7653)  ; Saturate(value)
  %7657 = call float @dx.op.unary.f32(i32 7, float %7654)  ; Saturate(value)
  %7658 = fadd fast float %7655, 0xBFC70A3D80000000
  %7659 = fadd fast float %7656, 0xBFC70A3D80000000
  %7660 = fadd fast float %7657, 0xBFC70A3D80000000
  %7661 = fmul fast float %7658, %7
  %7662 = fmul fast float %7659, %7
  %7663 = fmul fast float %7660, %7
  %7664 = fadd fast float %7661, 0x3FC70A3D80000000
  %7665 = fadd fast float %7662, 0x3FC70A3D80000000
  %7666 = fadd fast float %7663, 0x3FC70A3D80000000
  %7667 = call float @dx.op.unary.f32(i32 7, float %7664)  ; Saturate(value)
  %7668 = call float @dx.op.unary.f32(i32 7, float %7665)  ; Saturate(value)
  %7669 = call float @dx.op.unary.f32(i32 7, float %7666)  ; Saturate(value)
  br label %7670

; <label>:7670                                    ; preds = %7638, %7421
  %7671 = phi float [ %7452, %7421 ], [ %7667, %7638 ]
  %7672 = phi float [ %7453, %7421 ], [ %7668, %7638 ]
  %7673 = phi float [ %7454, %7421 ], [ %7669, %7638 ]
  %7674 = fsub fast float %7671, %7391
  %7675 = fsub fast float %7672, %7392
  %7676 = fsub fast float %7673, %7393
  %7677 = fmul fast float %7674, %7408
  %7678 = fmul fast float %7675, %7408
  %7679 = fmul fast float %7676, %7408
  %7680 = fadd fast float %7677, %7391
  %7681 = fadd fast float %7678, %7392
  %7682 = fadd fast float %7679, %7393
  br label %7683

; <label>:7683                                    ; preds = %7670, %7362
  %7684 = phi float [ %7680, %7670 ], [ %7391, %7362 ]
  %7685 = phi float [ %7681, %7670 ], [ %7392, %7362 ]
  %7686 = phi float [ %7682, %7670 ], [ %7393, %7362 ]
  %7687 = add i32 %70, 1
  %7688 = call i32 @dx.op.binary.i32(i32 37, i32 %7687, i32 0)  ; IMax(a,b)
  %7689 = call i32 @dx.op.binary.i32(i32 38, i32 %7688, i32 %60)  ; IMin(a,b)
  %7690 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %7397, i32 %7689, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7691 = extractvalue %dx.types.ResRet.f32 %7690, 0
  %7692 = fsub fast float %7691, %86
  %7693 = call float @dx.op.unary.f32(i32 6, float %7692)  ; FAbs(value)
  %7694 = fdiv fast float %7693, %7403
  %7695 = fsub fast float 1.000000e+00, %7694
  %7696 = call float @dx.op.unary.f32(i32 7, float %7695)  ; Saturate(value)
  %7697 = fcmp fast ugt float %7696, 0.000000e+00
  br i1 %7697, label %7698, label %7971

; <label>:7698                                    ; preds = %7683
  %7699 = call i32 @dx.op.binary.i32(i32 37, i32 %7397, i32 0)  ; IMax(a,b)
  %7700 = call i32 @dx.op.binary.i32(i32 37, i32 %7689, i32 0)  ; IMax(a,b)
  %7701 = call i32 @dx.op.binary.i32(i32 38, i32 %7699, i32 %59)  ; IMin(a,b)
  %7702 = call i32 @dx.op.binary.i32(i32 38, i32 %7700, i32 %60)  ; IMin(a,b)
  %7703 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %7701, i32 %7702, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7704 = extractvalue %dx.types.ResRet.f32 %7703, 0
  %7705 = extractvalue %dx.types.ResRet.f32 %7703, 1
  %7706 = extractvalue %dx.types.ResRet.f32 %7703, 2
  %7707 = extractvalue %dx.types.ResRet.f32 %7703, 3
  %7708 = fcmp fast olt float %7707, 0.000000e+00
  br i1 %7708, label %7709, label %7743

; <label>:7709                                    ; preds = %7698
  %7710 = fcmp fast ogt float %7704, 0x3FA4B5DCC0000000
  %7711 = fcmp fast ogt float %7705, 0x3FA4B5DCC0000000
  %7712 = fcmp fast ogt float %7706, 0x3FA4B5DCC0000000
  %7713 = select i1 %7710, float 0.000000e+00, float 1.000000e+00
  %7714 = select i1 %7711, float 0.000000e+00, float 1.000000e+00
  %7715 = select i1 %7712, float 0.000000e+00, float 1.000000e+00
  %7716 = fmul fast float %7704, 0x3FB3D07220000000
  %7717 = fmul fast float %7705, 0x3FB3D07220000000
  %7718 = fmul fast float %7706, 0x3FB3D07220000000
  %7719 = fadd fast float %7704, 0x3FAC28F5C0000000
  %7720 = fadd fast float %7705, 0x3FAC28F5C0000000
  %7721 = fadd fast float %7706, 0x3FAC28F5C0000000
  %7722 = fmul fast float %7719, 0x3FEE54EDE0000000
  %7723 = fmul fast float %7720, 0x3FEE54EDE0000000
  %7724 = fmul fast float %7721, 0x3FEE54EDE0000000
  %7725 = call float @dx.op.unary.f32(i32 23, float %7722)  ; Log(value)
  %7726 = call float @dx.op.unary.f32(i32 23, float %7723)  ; Log(value)
  %7727 = call float @dx.op.unary.f32(i32 23, float %7724)  ; Log(value)
  %7728 = fmul fast float %7725, 0x4003333340000000
  %7729 = fmul fast float %7726, 0x4003333340000000
  %7730 = fmul fast float %7727, 0x4003333340000000
  %7731 = call float @dx.op.unary.f32(i32 21, float %7728)  ; Exp(value)
  %7732 = call float @dx.op.unary.f32(i32 21, float %7729)  ; Exp(value)
  %7733 = call float @dx.op.unary.f32(i32 21, float %7730)  ; Exp(value)
  %7734 = fsub fast float %7716, %7731
  %7735 = fsub fast float %7717, %7732
  %7736 = fsub fast float %7718, %7733
  %7737 = fmul fast float %7734, %7713
  %7738 = fmul fast float %7735, %7714
  %7739 = fmul fast float %7736, %7715
  %7740 = fadd fast float %7737, %7731
  %7741 = fadd fast float %7738, %7732
  %7742 = fadd fast float %7739, %7733
  br label %7958

; <label>:7743                                    ; preds = %7698
  %7744 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %7701, i32 %7702, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7745 = extractvalue %dx.types.ResRet.f32 %7744, 0
  %7746 = fcmp fast ogt float %38, 5.000000e-01
  %7747 = fcmp fast olt float %7745, 1.000000e+00
  %7748 = and i1 %7746, %7747
  br i1 %7748, label %7749, label %7887

; <label>:7749                                    ; preds = %7743
  %7750 = sitofp i32 %7701 to float
  %7751 = sitofp i32 %7702 to float
  %7752 = fadd fast float %7750, 5.000000e-01
  %7753 = fadd fast float %7751, 5.000000e-01
  %7754 = fdiv fast float %7752, %45
  %7755 = fdiv fast float %7753, %46
  %7756 = fmul fast float %7754, 2.000000e+00
  %7757 = fmul fast float %7755, 2.000000e+00
  %7758 = fadd fast float %7756, -1.000000e+00
  %7759 = fsub fast float 1.000000e+00, %7757
  %7760 = fmul fast float %7758, %35
  %7761 = call float @dx.op.tertiary.f32(i32 46, float %7759, float %31, float %7760)  ; FMad(a,b,c)
  %7762 = call float @dx.op.tertiary.f32(i32 46, float %7745, float %27, float %7761)  ; FMad(a,b,c)
  %7763 = fadd fast float %7762, %23
  %7764 = call float @dx.op.unary.f32(i32 6, float %7763)  ; FAbs(value)
  %7765 = fcmp fast ogt float %7764, 0x3EB0C6F7A0000000
  br i1 %7765, label %7766, label %7887

; <label>:7766                                    ; preds = %7749
  %7767 = fmul fast float %7758, %34
  %7768 = call float @dx.op.tertiary.f32(i32 46, float %7759, float %30, float %7767)  ; FMad(a,b,c)
  %7769 = call float @dx.op.tertiary.f32(i32 46, float %7745, float %26, float %7768)  ; FMad(a,b,c)
  %7770 = fadd fast float %7769, %22
  %7771 = fmul fast float %7758, %33
  %7772 = call float @dx.op.tertiary.f32(i32 46, float %7759, float %29, float %7771)  ; FMad(a,b,c)
  %7773 = call float @dx.op.tertiary.f32(i32 46, float %7745, float %25, float %7772)  ; FMad(a,b,c)
  %7774 = fadd fast float %7773, %21
  %7775 = fmul fast float %7758, %32
  %7776 = call float @dx.op.tertiary.f32(i32 46, float %7759, float %28, float %7775)  ; FMad(a,b,c)
  %7777 = call float @dx.op.tertiary.f32(i32 46, float %7745, float %24, float %7776)  ; FMad(a,b,c)
  %7778 = fadd fast float %7777, %20
  %7779 = fdiv fast float %7778, %7763
  %7780 = fdiv fast float %7774, %7763
  %7781 = fdiv fast float %7770, %7763
  %7782 = fsub fast float %7779, %17
  %7783 = fsub fast float %7780, %18
  %7784 = fsub fast float %7781, %19
  %7785 = fmul fast float %7782, %7782
  %7786 = fmul fast float %7783, %7783
  %7787 = fadd fast float %7786, %7785
  %7788 = fmul fast float %7784, %7784
  %7789 = fadd fast float %7787, %7788
  %7790 = call float @dx.op.unary.f32(i32 24, float %7789)  ; Sqrt(value)
  %7791 = fsub fast float %7790, %9
  %7792 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %7791)  ; FMax(a,b)
  %7793 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %7793, label %7794, label %7817

; <label>:7794                                    ; preds = %7766
  %7795 = call float @dx.op.unary.f32(i32 6, float %7783)  ; FAbs(value)
  %7796 = fmul fast float %7795, %11
  %7797 = fcmp fast olt float %7796, 0x3F50624DE0000000
  br i1 %7797, label %7798, label %7801

; <label>:7798                                    ; preds = %7794
  %7799 = fmul fast float %7796, 5.000000e-01
  %7800 = fsub fast float 1.000000e+00, %7799
  br label %7806

; <label>:7801                                    ; preds = %7794
  %7802 = fmul fast float %7796, 0xBFF7154760000000
  %7803 = call float @dx.op.unary.f32(i32 21, float %7802)  ; Exp(value)
  %7804 = fsub fast float 1.000000e+00, %7803
  %7805 = fdiv fast float %7804, %7796
  br label %7806

; <label>:7806                                    ; preds = %7801, %7798
  %7807 = phi float [ %7800, %7798 ], [ %7805, %7801 ]
  %7808 = call float @dx.op.binary.f32(i32 36, float %7780, float %18)  ; FMin(a,b)
  %7809 = fsub fast float %7808, %10
  %7810 = fmul fast float %11, %7809
  %7811 = fsub fast float -0.000000e+00, %7810
  %7812 = call float @dx.op.binary.f32(i32 35, float %7811, float -4.000000e+01)  ; FMax(a,b)
  %7813 = call float @dx.op.binary.f32(i32 36, float %7812, float 5.000000e+00)  ; FMin(a,b)
  %7814 = fmul fast float %7813, 0x3FF7154760000000
  %7815 = call float @dx.op.unary.f32(i32 21, float %7814)  ; Exp(value)
  %7816 = fmul fast float %7815, %7807
  br label %7817

; <label>:7817                                    ; preds = %7806, %7766
  %7818 = phi float [ %7816, %7806 ], [ 1.000000e+00, %7766 ]
  %7819 = fmul fast float %7792, %16
  %7820 = fmul fast float %7819, %7818
  %7821 = fcmp fast ole float %7790, %9
  %7822 = fcmp fast olt float %7790, 0x3F1A36E2E0000000
  %7823 = or i1 %7821, %7822
  br i1 %7823, label %7870, label %7824

; <label>:7824                                    ; preds = %7817
  %7825 = fdiv fast float %9, %7790
  %7826 = fmul fast float %7825, %7782
  %7827 = fmul fast float %7825, %7783
  %7828 = fmul fast float %7825, %7784
  %7829 = fadd fast float %7826, %17
  %7830 = fadd fast float %7827, %18
  %7831 = fadd fast float %7828, %19
  %7832 = fadd fast float %7829, -9.000000e+02
  %7833 = fadd fast float %7830, -1.500000e+01
  %7834 = fadd fast float %7831, -7.500000e+02
  %7835 = fmul fast float %7832, 0x3F62345680000000
  %7836 = fmul fast float %7833, 0x3F62345680000000
  %7837 = fmul fast float %7834, 0x3F62345680000000
  %7838 = call float @dx.op.dot3.f32(i32 55, float %7835, float %7836, float %7837, float %7835, float %7836, float %7837)  ; Dot3(ax,ay,az,bx,by,bz)
  %7839 = fsub fast float 1.000000e+00, %7838
  %7840 = call float @dx.op.unary.f32(i32 7, float %7839)  ; Saturate(value)
  %7841 = fmul fast float %7840, %7840
  %7842 = fadd fast float %7829, %7779
  %7843 = fadd fast float %7830, %7780
  %7844 = fadd fast float %7831, %7781
  %7845 = fmul fast float %7842, 0x3F52345680000000
  %7846 = fadd fast float %7845, -2.000000e+00
  %7847 = fmul fast float %7843, 0x3F52345680000000
  %7848 = fadd fast float %7847, 0xBFA1111120000000
  %7849 = fmul fast float %7844, 0x3F52345680000000
  %7850 = fadd fast float %7849, 0xBFFAAAAAC0000000
  %7851 = call float @dx.op.dot3.f32(i32 55, float %7846, float %7848, float %7850, float %7846, float %7848, float %7850)  ; Dot3(ax,ay,az,bx,by,bz)
  %7852 = fsub fast float 1.000000e+00, %7851
  %7853 = call float @dx.op.unary.f32(i32 7, float %7852)  ; Saturate(value)
  %7854 = fmul fast float %7853, %7853
  %7855 = fmul fast float %7854, 4.000000e+00
  %7856 = fadd fast float %7855, %7841
  %7857 = fadd fast float %7779, -9.000000e+02
  %7858 = fadd fast float %7780, -1.500000e+01
  %7859 = fadd fast float %7781, -7.500000e+02
  %7860 = fmul fast float %7857, 0x3F62345680000000
  %7861 = fmul fast float %7858, 0x3F62345680000000
  %7862 = fmul fast float %7859, 0x3F62345680000000
  %7863 = call float @dx.op.dot3.f32(i32 55, float %7860, float %7861, float %7862, float %7860, float %7861, float %7862)  ; Dot3(ax,ay,az,bx,by,bz)
  %7864 = fsub fast float 1.000000e+00, %7863
  %7865 = call float @dx.op.unary.f32(i32 7, float %7864)  ; Saturate(value)
  %7866 = fmul fast float %7865, %7865
  %7867 = fadd fast float %7856, %7866
  %7868 = fmul fast float %7791, 0x3F25D867E0000000
  %7869 = fmul fast float %7868, %7867
  br label %7870

; <label>:7870                                    ; preds = %7824, %7817
  %7871 = phi float [ %7869, %7824 ], [ 0.000000e+00, %7817 ]
  %7872 = fadd fast float %7871, %7820
  %7873 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %7872)  ; FMin(a,b)
  %7874 = fmul fast float %7873, 0xBFF7154760000000
  %7875 = call float @dx.op.unary.f32(i32 21, float %7874)  ; Exp(value)
  %7876 = fsub fast float 1.000000e+00, %7875
  %7877 = call float @dx.op.binary.f32(i32 36, float %12, float %7876)  ; FMin(a,b)
  %7878 = fsub fast float %13, %7704
  %7879 = fsub fast float %14, %7705
  %7880 = fsub fast float %15, %7706
  %7881 = fmul fast float %7877, %7878
  %7882 = fmul fast float %7877, %7879
  %7883 = fmul fast float %7877, %7880
  %7884 = fadd fast float %7881, %7704
  %7885 = fadd fast float %7882, %7705
  %7886 = fadd fast float %7883, %7706
  br label %7887

; <label>:7887                                    ; preds = %7870, %7749, %7743
  %7888 = phi float [ %7884, %7870 ], [ %7704, %7749 ], [ %7704, %7743 ]
  %7889 = phi float [ %7885, %7870 ], [ %7705, %7749 ], [ %7705, %7743 ]
  %7890 = phi float [ %7886, %7870 ], [ %7706, %7749 ], [ %7706, %7743 ]
  %7891 = fadd fast float %5, 1.000000e+00
  %7892 = fadd fast float %6, 1.000000e+00
  %7893 = fsub fast float 1.000000e+00, %5
  %7894 = fmul fast float %36, %7891
  %7895 = fmul fast float %36, %7892
  %7896 = fmul fast float %36, %7893
  %7897 = fmul fast float %7894, %7888
  %7898 = fmul fast float %7895, %7889
  %7899 = fmul fast float %7896, %7890
  %7900 = fcmp fast ult float %37, 5.000000e-01
  br i1 %7900, label %7926, label %7901

; <label>:7901                                    ; preds = %7887
  %7902 = fmul fast float %7897, 0x4004147AE0000000
  %7903 = fmul fast float %7898, 0x4004147AE0000000
  %7904 = fmul fast float %7899, 0x4004147AE0000000
  %7905 = fadd fast float %7902, 0x3F9EB851E0000000
  %7906 = fadd fast float %7903, 0x3F9EB851E0000000
  %7907 = fadd fast float %7904, 0x3F9EB851E0000000
  %7908 = fmul fast float %7905, %7897
  %7909 = fmul fast float %7906, %7898
  %7910 = fmul fast float %7907, %7899
  %7911 = fmul fast float %7897, 0x400370A3E0000000
  %7912 = fmul fast float %7898, 0x400370A3E0000000
  %7913 = fmul fast float %7899, 0x400370A3E0000000
  %7914 = fadd fast float %7911, 0x3FE2E147A0000000
  %7915 = fadd fast float %7912, 0x3FE2E147A0000000
  %7916 = fadd fast float %7913, 0x3FE2E147A0000000
  %7917 = fmul fast float %7914, %7897
  %7918 = fmul fast float %7915, %7898
  %7919 = fmul fast float %7916, %7899
  %7920 = fadd fast float %7917, 0x3FC1EB8520000000
  %7921 = fadd fast float %7918, 0x3FC1EB8520000000
  %7922 = fadd fast float %7919, 0x3FC1EB8520000000
  %7923 = fdiv fast float %7908, %7920
  %7924 = fdiv fast float %7909, %7921
  %7925 = fdiv fast float %7910, %7922
  br label %7926

; <label>:7926                                    ; preds = %7901, %7887
  %7927 = phi float [ %7923, %7901 ], [ %7897, %7887 ]
  %7928 = phi float [ %7924, %7901 ], [ %7898, %7887 ]
  %7929 = phi float [ %7925, %7901 ], [ %7899, %7887 ]
  %7930 = call float @dx.op.unary.f32(i32 7, float %7927)  ; Saturate(value)
  %7931 = call float @dx.op.unary.f32(i32 7, float %7928)  ; Saturate(value)
  %7932 = call float @dx.op.unary.f32(i32 7, float %7929)  ; Saturate(value)
  %7933 = call float @dx.op.dot3.f32(i32 55, float %7930, float %7931, float %7932, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %7934 = fsub fast float %7930, %7933
  %7935 = fsub fast float %7931, %7933
  %7936 = fsub fast float %7932, %7933
  %7937 = fmul fast float %7934, %8
  %7938 = fmul fast float %7935, %8
  %7939 = fmul fast float %7936, %8
  %7940 = fadd fast float %7937, %7933
  %7941 = fadd fast float %7938, %7933
  %7942 = fadd fast float %7939, %7933
  %7943 = call float @dx.op.unary.f32(i32 7, float %7940)  ; Saturate(value)
  %7944 = call float @dx.op.unary.f32(i32 7, float %7941)  ; Saturate(value)
  %7945 = call float @dx.op.unary.f32(i32 7, float %7942)  ; Saturate(value)
  %7946 = fadd fast float %7943, 0xBFC70A3D80000000
  %7947 = fadd fast float %7944, 0xBFC70A3D80000000
  %7948 = fadd fast float %7945, 0xBFC70A3D80000000
  %7949 = fmul fast float %7946, %7
  %7950 = fmul fast float %7947, %7
  %7951 = fmul fast float %7948, %7
  %7952 = fadd fast float %7949, 0x3FC70A3D80000000
  %7953 = fadd fast float %7950, 0x3FC70A3D80000000
  %7954 = fadd fast float %7951, 0x3FC70A3D80000000
  %7955 = call float @dx.op.unary.f32(i32 7, float %7952)  ; Saturate(value)
  %7956 = call float @dx.op.unary.f32(i32 7, float %7953)  ; Saturate(value)
  %7957 = call float @dx.op.unary.f32(i32 7, float %7954)  ; Saturate(value)
  br label %7958

; <label>:7958                                    ; preds = %7926, %7709
  %7959 = phi float [ %7740, %7709 ], [ %7955, %7926 ]
  %7960 = phi float [ %7741, %7709 ], [ %7956, %7926 ]
  %7961 = phi float [ %7742, %7709 ], [ %7957, %7926 ]
  %7962 = fsub fast float %7959, %7391
  %7963 = fsub fast float %7960, %7392
  %7964 = fsub fast float %7961, %7393
  %7965 = fmul fast float %7962, %7696
  %7966 = fmul fast float %7963, %7696
  %7967 = fmul fast float %7964, %7696
  %7968 = fadd fast float %7965, %7391
  %7969 = fadd fast float %7966, %7392
  %7970 = fadd fast float %7967, %7393
  br label %7971

; <label>:7971                                    ; preds = %7958, %7683
  %7972 = phi float [ %7968, %7958 ], [ %7391, %7683 ]
  %7973 = phi float [ %7969, %7958 ], [ %7392, %7683 ]
  %7974 = phi float [ %7970, %7958 ], [ %7393, %7683 ]
  %7975 = add i32 %63, -1
  %7976 = call i32 @dx.op.binary.i32(i32 37, i32 %7975, i32 0)  ; IMax(a,b)
  %7977 = call i32 @dx.op.binary.i32(i32 37, i32 %70, i32 0)  ; IMax(a,b)
  %7978 = call i32 @dx.op.binary.i32(i32 38, i32 %7976, i32 %59)  ; IMin(a,b)
  %7979 = call i32 @dx.op.binary.i32(i32 38, i32 %7977, i32 %60)  ; IMin(a,b)
  %7980 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %7978, i32 %7979, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7981 = extractvalue %dx.types.ResRet.f32 %7980, 0
  %7982 = fsub fast float %7981, %86
  %7983 = call float @dx.op.unary.f32(i32 6, float %7982)  ; FAbs(value)
  %7984 = fdiv fast float %7983, %7403
  %7985 = fsub fast float 1.000000e+00, %7984
  %7986 = call float @dx.op.unary.f32(i32 7, float %7985)  ; Saturate(value)
  %7987 = fcmp fast ugt float %7986, 0.000000e+00
  br i1 %7987, label %7988, label %8261

; <label>:7988                                    ; preds = %7971
  %7989 = call i32 @dx.op.binary.i32(i32 37, i32 %7978, i32 0)  ; IMax(a,b)
  %7990 = call i32 @dx.op.binary.i32(i32 37, i32 %7979, i32 0)  ; IMax(a,b)
  %7991 = call i32 @dx.op.binary.i32(i32 38, i32 %7989, i32 %59)  ; IMin(a,b)
  %7992 = call i32 @dx.op.binary.i32(i32 38, i32 %7990, i32 %60)  ; IMin(a,b)
  %7993 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %7991, i32 %7992, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %7994 = extractvalue %dx.types.ResRet.f32 %7993, 0
  %7995 = extractvalue %dx.types.ResRet.f32 %7993, 1
  %7996 = extractvalue %dx.types.ResRet.f32 %7993, 2
  %7997 = extractvalue %dx.types.ResRet.f32 %7993, 3
  %7998 = fcmp fast olt float %7997, 0.000000e+00
  br i1 %7998, label %7999, label %8033

; <label>:7999                                    ; preds = %7988
  %8000 = fcmp fast ogt float %7994, 0x3FA4B5DCC0000000
  %8001 = fcmp fast ogt float %7995, 0x3FA4B5DCC0000000
  %8002 = fcmp fast ogt float %7996, 0x3FA4B5DCC0000000
  %8003 = select i1 %8000, float 0.000000e+00, float 1.000000e+00
  %8004 = select i1 %8001, float 0.000000e+00, float 1.000000e+00
  %8005 = select i1 %8002, float 0.000000e+00, float 1.000000e+00
  %8006 = fmul fast float %7994, 0x3FB3D07220000000
  %8007 = fmul fast float %7995, 0x3FB3D07220000000
  %8008 = fmul fast float %7996, 0x3FB3D07220000000
  %8009 = fadd fast float %7994, 0x3FAC28F5C0000000
  %8010 = fadd fast float %7995, 0x3FAC28F5C0000000
  %8011 = fadd fast float %7996, 0x3FAC28F5C0000000
  %8012 = fmul fast float %8009, 0x3FEE54EDE0000000
  %8013 = fmul fast float %8010, 0x3FEE54EDE0000000
  %8014 = fmul fast float %8011, 0x3FEE54EDE0000000
  %8015 = call float @dx.op.unary.f32(i32 23, float %8012)  ; Log(value)
  %8016 = call float @dx.op.unary.f32(i32 23, float %8013)  ; Log(value)
  %8017 = call float @dx.op.unary.f32(i32 23, float %8014)  ; Log(value)
  %8018 = fmul fast float %8015, 0x4003333340000000
  %8019 = fmul fast float %8016, 0x4003333340000000
  %8020 = fmul fast float %8017, 0x4003333340000000
  %8021 = call float @dx.op.unary.f32(i32 21, float %8018)  ; Exp(value)
  %8022 = call float @dx.op.unary.f32(i32 21, float %8019)  ; Exp(value)
  %8023 = call float @dx.op.unary.f32(i32 21, float %8020)  ; Exp(value)
  %8024 = fsub fast float %8006, %8021
  %8025 = fsub fast float %8007, %8022
  %8026 = fsub fast float %8008, %8023
  %8027 = fmul fast float %8024, %8003
  %8028 = fmul fast float %8025, %8004
  %8029 = fmul fast float %8026, %8005
  %8030 = fadd fast float %8027, %8021
  %8031 = fadd fast float %8028, %8022
  %8032 = fadd fast float %8029, %8023
  br label %8248

; <label>:8033                                    ; preds = %7988
  %8034 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %7991, i32 %7992, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %8035 = extractvalue %dx.types.ResRet.f32 %8034, 0
  %8036 = fcmp fast ogt float %38, 5.000000e-01
  %8037 = fcmp fast olt float %8035, 1.000000e+00
  %8038 = and i1 %8036, %8037
  br i1 %8038, label %8039, label %8177

; <label>:8039                                    ; preds = %8033
  %8040 = sitofp i32 %7991 to float
  %8041 = sitofp i32 %7992 to float
  %8042 = fadd fast float %8040, 5.000000e-01
  %8043 = fadd fast float %8041, 5.000000e-01
  %8044 = fdiv fast float %8042, %45
  %8045 = fdiv fast float %8043, %46
  %8046 = fmul fast float %8044, 2.000000e+00
  %8047 = fmul fast float %8045, 2.000000e+00
  %8048 = fadd fast float %8046, -1.000000e+00
  %8049 = fsub fast float 1.000000e+00, %8047
  %8050 = fmul fast float %8048, %35
  %8051 = call float @dx.op.tertiary.f32(i32 46, float %8049, float %31, float %8050)  ; FMad(a,b,c)
  %8052 = call float @dx.op.tertiary.f32(i32 46, float %8035, float %27, float %8051)  ; FMad(a,b,c)
  %8053 = fadd fast float %8052, %23
  %8054 = call float @dx.op.unary.f32(i32 6, float %8053)  ; FAbs(value)
  %8055 = fcmp fast ogt float %8054, 0x3EB0C6F7A0000000
  br i1 %8055, label %8056, label %8177

; <label>:8056                                    ; preds = %8039
  %8057 = fmul fast float %8048, %34
  %8058 = call float @dx.op.tertiary.f32(i32 46, float %8049, float %30, float %8057)  ; FMad(a,b,c)
  %8059 = call float @dx.op.tertiary.f32(i32 46, float %8035, float %26, float %8058)  ; FMad(a,b,c)
  %8060 = fadd fast float %8059, %22
  %8061 = fmul fast float %8048, %33
  %8062 = call float @dx.op.tertiary.f32(i32 46, float %8049, float %29, float %8061)  ; FMad(a,b,c)
  %8063 = call float @dx.op.tertiary.f32(i32 46, float %8035, float %25, float %8062)  ; FMad(a,b,c)
  %8064 = fadd fast float %8063, %21
  %8065 = fmul fast float %8048, %32
  %8066 = call float @dx.op.tertiary.f32(i32 46, float %8049, float %28, float %8065)  ; FMad(a,b,c)
  %8067 = call float @dx.op.tertiary.f32(i32 46, float %8035, float %24, float %8066)  ; FMad(a,b,c)
  %8068 = fadd fast float %8067, %20
  %8069 = fdiv fast float %8068, %8053
  %8070 = fdiv fast float %8064, %8053
  %8071 = fdiv fast float %8060, %8053
  %8072 = fsub fast float %8069, %17
  %8073 = fsub fast float %8070, %18
  %8074 = fsub fast float %8071, %19
  %8075 = fmul fast float %8072, %8072
  %8076 = fmul fast float %8073, %8073
  %8077 = fadd fast float %8076, %8075
  %8078 = fmul fast float %8074, %8074
  %8079 = fadd fast float %8077, %8078
  %8080 = call float @dx.op.unary.f32(i32 24, float %8079)  ; Sqrt(value)
  %8081 = fsub fast float %8080, %9
  %8082 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %8081)  ; FMax(a,b)
  %8083 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %8083, label %8084, label %8107

; <label>:8084                                    ; preds = %8056
  %8085 = call float @dx.op.unary.f32(i32 6, float %8073)  ; FAbs(value)
  %8086 = fmul fast float %8085, %11
  %8087 = fcmp fast olt float %8086, 0x3F50624DE0000000
  br i1 %8087, label %8088, label %8091

; <label>:8088                                    ; preds = %8084
  %8089 = fmul fast float %8086, 5.000000e-01
  %8090 = fsub fast float 1.000000e+00, %8089
  br label %8096

; <label>:8091                                    ; preds = %8084
  %8092 = fmul fast float %8086, 0xBFF7154760000000
  %8093 = call float @dx.op.unary.f32(i32 21, float %8092)  ; Exp(value)
  %8094 = fsub fast float 1.000000e+00, %8093
  %8095 = fdiv fast float %8094, %8086
  br label %8096

; <label>:8096                                    ; preds = %8091, %8088
  %8097 = phi float [ %8090, %8088 ], [ %8095, %8091 ]
  %8098 = call float @dx.op.binary.f32(i32 36, float %8070, float %18)  ; FMin(a,b)
  %8099 = fsub fast float %8098, %10
  %8100 = fmul fast float %11, %8099
  %8101 = fsub fast float -0.000000e+00, %8100
  %8102 = call float @dx.op.binary.f32(i32 35, float %8101, float -4.000000e+01)  ; FMax(a,b)
  %8103 = call float @dx.op.binary.f32(i32 36, float %8102, float 5.000000e+00)  ; FMin(a,b)
  %8104 = fmul fast float %8103, 0x3FF7154760000000
  %8105 = call float @dx.op.unary.f32(i32 21, float %8104)  ; Exp(value)
  %8106 = fmul fast float %8105, %8097
  br label %8107

; <label>:8107                                    ; preds = %8096, %8056
  %8108 = phi float [ %8106, %8096 ], [ 1.000000e+00, %8056 ]
  %8109 = fmul fast float %8082, %16
  %8110 = fmul fast float %8109, %8108
  %8111 = fcmp fast ole float %8080, %9
  %8112 = fcmp fast olt float %8080, 0x3F1A36E2E0000000
  %8113 = or i1 %8111, %8112
  br i1 %8113, label %8160, label %8114

; <label>:8114                                    ; preds = %8107
  %8115 = fdiv fast float %9, %8080
  %8116 = fmul fast float %8115, %8072
  %8117 = fmul fast float %8115, %8073
  %8118 = fmul fast float %8115, %8074
  %8119 = fadd fast float %8116, %17
  %8120 = fadd fast float %8117, %18
  %8121 = fadd fast float %8118, %19
  %8122 = fadd fast float %8119, -9.000000e+02
  %8123 = fadd fast float %8120, -1.500000e+01
  %8124 = fadd fast float %8121, -7.500000e+02
  %8125 = fmul fast float %8122, 0x3F62345680000000
  %8126 = fmul fast float %8123, 0x3F62345680000000
  %8127 = fmul fast float %8124, 0x3F62345680000000
  %8128 = call float @dx.op.dot3.f32(i32 55, float %8125, float %8126, float %8127, float %8125, float %8126, float %8127)  ; Dot3(ax,ay,az,bx,by,bz)
  %8129 = fsub fast float 1.000000e+00, %8128
  %8130 = call float @dx.op.unary.f32(i32 7, float %8129)  ; Saturate(value)
  %8131 = fmul fast float %8130, %8130
  %8132 = fadd fast float %8119, %8069
  %8133 = fadd fast float %8120, %8070
  %8134 = fadd fast float %8121, %8071
  %8135 = fmul fast float %8132, 0x3F52345680000000
  %8136 = fadd fast float %8135, -2.000000e+00
  %8137 = fmul fast float %8133, 0x3F52345680000000
  %8138 = fadd fast float %8137, 0xBFA1111120000000
  %8139 = fmul fast float %8134, 0x3F52345680000000
  %8140 = fadd fast float %8139, 0xBFFAAAAAC0000000
  %8141 = call float @dx.op.dot3.f32(i32 55, float %8136, float %8138, float %8140, float %8136, float %8138, float %8140)  ; Dot3(ax,ay,az,bx,by,bz)
  %8142 = fsub fast float 1.000000e+00, %8141
  %8143 = call float @dx.op.unary.f32(i32 7, float %8142)  ; Saturate(value)
  %8144 = fmul fast float %8143, %8143
  %8145 = fmul fast float %8144, 4.000000e+00
  %8146 = fadd fast float %8145, %8131
  %8147 = fadd fast float %8069, -9.000000e+02
  %8148 = fadd fast float %8070, -1.500000e+01
  %8149 = fadd fast float %8071, -7.500000e+02
  %8150 = fmul fast float %8147, 0x3F62345680000000
  %8151 = fmul fast float %8148, 0x3F62345680000000
  %8152 = fmul fast float %8149, 0x3F62345680000000
  %8153 = call float @dx.op.dot3.f32(i32 55, float %8150, float %8151, float %8152, float %8150, float %8151, float %8152)  ; Dot3(ax,ay,az,bx,by,bz)
  %8154 = fsub fast float 1.000000e+00, %8153
  %8155 = call float @dx.op.unary.f32(i32 7, float %8154)  ; Saturate(value)
  %8156 = fmul fast float %8155, %8155
  %8157 = fadd fast float %8146, %8156
  %8158 = fmul fast float %8081, 0x3F25D867E0000000
  %8159 = fmul fast float %8158, %8157
  br label %8160

; <label>:8160                                    ; preds = %8114, %8107
  %8161 = phi float [ %8159, %8114 ], [ 0.000000e+00, %8107 ]
  %8162 = fadd fast float %8161, %8110
  %8163 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %8162)  ; FMin(a,b)
  %8164 = fmul fast float %8163, 0xBFF7154760000000
  %8165 = call float @dx.op.unary.f32(i32 21, float %8164)  ; Exp(value)
  %8166 = fsub fast float 1.000000e+00, %8165
  %8167 = call float @dx.op.binary.f32(i32 36, float %12, float %8166)  ; FMin(a,b)
  %8168 = fsub fast float %13, %7994
  %8169 = fsub fast float %14, %7995
  %8170 = fsub fast float %15, %7996
  %8171 = fmul fast float %8167, %8168
  %8172 = fmul fast float %8167, %8169
  %8173 = fmul fast float %8167, %8170
  %8174 = fadd fast float %8171, %7994
  %8175 = fadd fast float %8172, %7995
  %8176 = fadd fast float %8173, %7996
  br label %8177

; <label>:8177                                    ; preds = %8160, %8039, %8033
  %8178 = phi float [ %8174, %8160 ], [ %7994, %8039 ], [ %7994, %8033 ]
  %8179 = phi float [ %8175, %8160 ], [ %7995, %8039 ], [ %7995, %8033 ]
  %8180 = phi float [ %8176, %8160 ], [ %7996, %8039 ], [ %7996, %8033 ]
  %8181 = fadd fast float %5, 1.000000e+00
  %8182 = fadd fast float %6, 1.000000e+00
  %8183 = fsub fast float 1.000000e+00, %5
  %8184 = fmul fast float %36, %8181
  %8185 = fmul fast float %36, %8182
  %8186 = fmul fast float %36, %8183
  %8187 = fmul fast float %8184, %8178
  %8188 = fmul fast float %8185, %8179
  %8189 = fmul fast float %8186, %8180
  %8190 = fcmp fast ult float %37, 5.000000e-01
  br i1 %8190, label %8216, label %8191

; <label>:8191                                    ; preds = %8177
  %8192 = fmul fast float %8187, 0x4004147AE0000000
  %8193 = fmul fast float %8188, 0x4004147AE0000000
  %8194 = fmul fast float %8189, 0x4004147AE0000000
  %8195 = fadd fast float %8192, 0x3F9EB851E0000000
  %8196 = fadd fast float %8193, 0x3F9EB851E0000000
  %8197 = fadd fast float %8194, 0x3F9EB851E0000000
  %8198 = fmul fast float %8195, %8187
  %8199 = fmul fast float %8196, %8188
  %8200 = fmul fast float %8197, %8189
  %8201 = fmul fast float %8187, 0x400370A3E0000000
  %8202 = fmul fast float %8188, 0x400370A3E0000000
  %8203 = fmul fast float %8189, 0x400370A3E0000000
  %8204 = fadd fast float %8201, 0x3FE2E147A0000000
  %8205 = fadd fast float %8202, 0x3FE2E147A0000000
  %8206 = fadd fast float %8203, 0x3FE2E147A0000000
  %8207 = fmul fast float %8204, %8187
  %8208 = fmul fast float %8205, %8188
  %8209 = fmul fast float %8206, %8189
  %8210 = fadd fast float %8207, 0x3FC1EB8520000000
  %8211 = fadd fast float %8208, 0x3FC1EB8520000000
  %8212 = fadd fast float %8209, 0x3FC1EB8520000000
  %8213 = fdiv fast float %8198, %8210
  %8214 = fdiv fast float %8199, %8211
  %8215 = fdiv fast float %8200, %8212
  br label %8216

; <label>:8216                                    ; preds = %8191, %8177
  %8217 = phi float [ %8213, %8191 ], [ %8187, %8177 ]
  %8218 = phi float [ %8214, %8191 ], [ %8188, %8177 ]
  %8219 = phi float [ %8215, %8191 ], [ %8189, %8177 ]
  %8220 = call float @dx.op.unary.f32(i32 7, float %8217)  ; Saturate(value)
  %8221 = call float @dx.op.unary.f32(i32 7, float %8218)  ; Saturate(value)
  %8222 = call float @dx.op.unary.f32(i32 7, float %8219)  ; Saturate(value)
  %8223 = call float @dx.op.dot3.f32(i32 55, float %8220, float %8221, float %8222, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %8224 = fsub fast float %8220, %8223
  %8225 = fsub fast float %8221, %8223
  %8226 = fsub fast float %8222, %8223
  %8227 = fmul fast float %8224, %8
  %8228 = fmul fast float %8225, %8
  %8229 = fmul fast float %8226, %8
  %8230 = fadd fast float %8227, %8223
  %8231 = fadd fast float %8228, %8223
  %8232 = fadd fast float %8229, %8223
  %8233 = call float @dx.op.unary.f32(i32 7, float %8230)  ; Saturate(value)
  %8234 = call float @dx.op.unary.f32(i32 7, float %8231)  ; Saturate(value)
  %8235 = call float @dx.op.unary.f32(i32 7, float %8232)  ; Saturate(value)
  %8236 = fadd fast float %8233, 0xBFC70A3D80000000
  %8237 = fadd fast float %8234, 0xBFC70A3D80000000
  %8238 = fadd fast float %8235, 0xBFC70A3D80000000
  %8239 = fmul fast float %8236, %7
  %8240 = fmul fast float %8237, %7
  %8241 = fmul fast float %8238, %7
  %8242 = fadd fast float %8239, 0x3FC70A3D80000000
  %8243 = fadd fast float %8240, 0x3FC70A3D80000000
  %8244 = fadd fast float %8241, 0x3FC70A3D80000000
  %8245 = call float @dx.op.unary.f32(i32 7, float %8242)  ; Saturate(value)
  %8246 = call float @dx.op.unary.f32(i32 7, float %8243)  ; Saturate(value)
  %8247 = call float @dx.op.unary.f32(i32 7, float %8244)  ; Saturate(value)
  br label %8248

; <label>:8248                                    ; preds = %8216, %7999
  %8249 = phi float [ %8030, %7999 ], [ %8245, %8216 ]
  %8250 = phi float [ %8031, %7999 ], [ %8246, %8216 ]
  %8251 = phi float [ %8032, %7999 ], [ %8247, %8216 ]
  %8252 = fsub fast float %8249, %7391
  %8253 = fsub fast float %8250, %7392
  %8254 = fsub fast float %8251, %7393
  %8255 = fmul fast float %8252, %7986
  %8256 = fmul fast float %8253, %7986
  %8257 = fmul fast float %8254, %7986
  %8258 = fadd fast float %8255, %7391
  %8259 = fadd fast float %8256, %7392
  %8260 = fadd fast float %8257, %7393
  br label %8261

; <label>:8261                                    ; preds = %8248, %7971
  %8262 = phi float [ %8258, %8248 ], [ %7391, %7971 ]
  %8263 = phi float [ %8259, %8248 ], [ %7392, %7971 ]
  %8264 = phi float [ %8260, %8248 ], [ %7393, %7971 ]
  %8265 = add i32 %63, 1
  %8266 = call i32 @dx.op.binary.i32(i32 37, i32 %8265, i32 0)  ; IMax(a,b)
  %8267 = call i32 @dx.op.binary.i32(i32 38, i32 %8266, i32 %59)  ; IMin(a,b)
  %8268 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %8267, i32 %7979, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %8269 = extractvalue %dx.types.ResRet.f32 %8268, 0
  %8270 = fsub fast float %8269, %86
  %8271 = call float @dx.op.unary.f32(i32 6, float %8270)  ; FAbs(value)
  %8272 = fdiv fast float %8271, %7403
  %8273 = fsub fast float 1.000000e+00, %8272
  %8274 = call float @dx.op.unary.f32(i32 7, float %8273)  ; Saturate(value)
  %8275 = fcmp fast ugt float %8274, 0.000000e+00
  br i1 %8275, label %8276, label %8549

; <label>:8276                                    ; preds = %8261
  %8277 = call i32 @dx.op.binary.i32(i32 37, i32 %8267, i32 0)  ; IMax(a,b)
  %8278 = call i32 @dx.op.binary.i32(i32 37, i32 %7979, i32 0)  ; IMax(a,b)
  %8279 = call i32 @dx.op.binary.i32(i32 38, i32 %8277, i32 %59)  ; IMin(a,b)
  %8280 = call i32 @dx.op.binary.i32(i32 38, i32 %8278, i32 %60)  ; IMin(a,b)
  %8281 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %8279, i32 %8280, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %8282 = extractvalue %dx.types.ResRet.f32 %8281, 0
  %8283 = extractvalue %dx.types.ResRet.f32 %8281, 1
  %8284 = extractvalue %dx.types.ResRet.f32 %8281, 2
  %8285 = extractvalue %dx.types.ResRet.f32 %8281, 3
  %8286 = fcmp fast olt float %8285, 0.000000e+00
  br i1 %8286, label %8287, label %8321

; <label>:8287                                    ; preds = %8276
  %8288 = fcmp fast ogt float %8282, 0x3FA4B5DCC0000000
  %8289 = fcmp fast ogt float %8283, 0x3FA4B5DCC0000000
  %8290 = fcmp fast ogt float %8284, 0x3FA4B5DCC0000000
  %8291 = select i1 %8288, float 0.000000e+00, float 1.000000e+00
  %8292 = select i1 %8289, float 0.000000e+00, float 1.000000e+00
  %8293 = select i1 %8290, float 0.000000e+00, float 1.000000e+00
  %8294 = fmul fast float %8282, 0x3FB3D07220000000
  %8295 = fmul fast float %8283, 0x3FB3D07220000000
  %8296 = fmul fast float %8284, 0x3FB3D07220000000
  %8297 = fadd fast float %8282, 0x3FAC28F5C0000000
  %8298 = fadd fast float %8283, 0x3FAC28F5C0000000
  %8299 = fadd fast float %8284, 0x3FAC28F5C0000000
  %8300 = fmul fast float %8297, 0x3FEE54EDE0000000
  %8301 = fmul fast float %8298, 0x3FEE54EDE0000000
  %8302 = fmul fast float %8299, 0x3FEE54EDE0000000
  %8303 = call float @dx.op.unary.f32(i32 23, float %8300)  ; Log(value)
  %8304 = call float @dx.op.unary.f32(i32 23, float %8301)  ; Log(value)
  %8305 = call float @dx.op.unary.f32(i32 23, float %8302)  ; Log(value)
  %8306 = fmul fast float %8303, 0x4003333340000000
  %8307 = fmul fast float %8304, 0x4003333340000000
  %8308 = fmul fast float %8305, 0x4003333340000000
  %8309 = call float @dx.op.unary.f32(i32 21, float %8306)  ; Exp(value)
  %8310 = call float @dx.op.unary.f32(i32 21, float %8307)  ; Exp(value)
  %8311 = call float @dx.op.unary.f32(i32 21, float %8308)  ; Exp(value)
  %8312 = fsub fast float %8294, %8309
  %8313 = fsub fast float %8295, %8310
  %8314 = fsub fast float %8296, %8311
  %8315 = fmul fast float %8312, %8291
  %8316 = fmul fast float %8313, %8292
  %8317 = fmul fast float %8314, %8293
  %8318 = fadd fast float %8315, %8309
  %8319 = fadd fast float %8316, %8310
  %8320 = fadd fast float %8317, %8311
  br label %8536

; <label>:8321                                    ; preds = %8276
  %8322 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %8279, i32 %8280, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %8323 = extractvalue %dx.types.ResRet.f32 %8322, 0
  %8324 = fcmp fast ogt float %38, 5.000000e-01
  %8325 = fcmp fast olt float %8323, 1.000000e+00
  %8326 = and i1 %8324, %8325
  br i1 %8326, label %8327, label %8465

; <label>:8327                                    ; preds = %8321
  %8328 = sitofp i32 %8279 to float
  %8329 = sitofp i32 %8280 to float
  %8330 = fadd fast float %8328, 5.000000e-01
  %8331 = fadd fast float %8329, 5.000000e-01
  %8332 = fdiv fast float %8330, %45
  %8333 = fdiv fast float %8331, %46
  %8334 = fmul fast float %8332, 2.000000e+00
  %8335 = fmul fast float %8333, 2.000000e+00
  %8336 = fadd fast float %8334, -1.000000e+00
  %8337 = fsub fast float 1.000000e+00, %8335
  %8338 = fmul fast float %8336, %35
  %8339 = call float @dx.op.tertiary.f32(i32 46, float %8337, float %31, float %8338)  ; FMad(a,b,c)
  %8340 = call float @dx.op.tertiary.f32(i32 46, float %8323, float %27, float %8339)  ; FMad(a,b,c)
  %8341 = fadd fast float %8340, %23
  %8342 = call float @dx.op.unary.f32(i32 6, float %8341)  ; FAbs(value)
  %8343 = fcmp fast ogt float %8342, 0x3EB0C6F7A0000000
  br i1 %8343, label %8344, label %8465

; <label>:8344                                    ; preds = %8327
  %8345 = fmul fast float %8336, %34
  %8346 = call float @dx.op.tertiary.f32(i32 46, float %8337, float %30, float %8345)  ; FMad(a,b,c)
  %8347 = call float @dx.op.tertiary.f32(i32 46, float %8323, float %26, float %8346)  ; FMad(a,b,c)
  %8348 = fadd fast float %8347, %22
  %8349 = fmul fast float %8336, %33
  %8350 = call float @dx.op.tertiary.f32(i32 46, float %8337, float %29, float %8349)  ; FMad(a,b,c)
  %8351 = call float @dx.op.tertiary.f32(i32 46, float %8323, float %25, float %8350)  ; FMad(a,b,c)
  %8352 = fadd fast float %8351, %21
  %8353 = fmul fast float %8336, %32
  %8354 = call float @dx.op.tertiary.f32(i32 46, float %8337, float %28, float %8353)  ; FMad(a,b,c)
  %8355 = call float @dx.op.tertiary.f32(i32 46, float %8323, float %24, float %8354)  ; FMad(a,b,c)
  %8356 = fadd fast float %8355, %20
  %8357 = fdiv fast float %8356, %8341
  %8358 = fdiv fast float %8352, %8341
  %8359 = fdiv fast float %8348, %8341
  %8360 = fsub fast float %8357, %17
  %8361 = fsub fast float %8358, %18
  %8362 = fsub fast float %8359, %19
  %8363 = fmul fast float %8360, %8360
  %8364 = fmul fast float %8361, %8361
  %8365 = fadd fast float %8364, %8363
  %8366 = fmul fast float %8362, %8362
  %8367 = fadd fast float %8365, %8366
  %8368 = call float @dx.op.unary.f32(i32 24, float %8367)  ; Sqrt(value)
  %8369 = fsub fast float %8368, %9
  %8370 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %8369)  ; FMax(a,b)
  %8371 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %8371, label %8372, label %8395

; <label>:8372                                    ; preds = %8344
  %8373 = call float @dx.op.unary.f32(i32 6, float %8361)  ; FAbs(value)
  %8374 = fmul fast float %8373, %11
  %8375 = fcmp fast olt float %8374, 0x3F50624DE0000000
  br i1 %8375, label %8376, label %8379

; <label>:8376                                    ; preds = %8372
  %8377 = fmul fast float %8374, 5.000000e-01
  %8378 = fsub fast float 1.000000e+00, %8377
  br label %8384

; <label>:8379                                    ; preds = %8372
  %8380 = fmul fast float %8374, 0xBFF7154760000000
  %8381 = call float @dx.op.unary.f32(i32 21, float %8380)  ; Exp(value)
  %8382 = fsub fast float 1.000000e+00, %8381
  %8383 = fdiv fast float %8382, %8374
  br label %8384

; <label>:8384                                    ; preds = %8379, %8376
  %8385 = phi float [ %8378, %8376 ], [ %8383, %8379 ]
  %8386 = call float @dx.op.binary.f32(i32 36, float %8358, float %18)  ; FMin(a,b)
  %8387 = fsub fast float %8386, %10
  %8388 = fmul fast float %11, %8387
  %8389 = fsub fast float -0.000000e+00, %8388
  %8390 = call float @dx.op.binary.f32(i32 35, float %8389, float -4.000000e+01)  ; FMax(a,b)
  %8391 = call float @dx.op.binary.f32(i32 36, float %8390, float 5.000000e+00)  ; FMin(a,b)
  %8392 = fmul fast float %8391, 0x3FF7154760000000
  %8393 = call float @dx.op.unary.f32(i32 21, float %8392)  ; Exp(value)
  %8394 = fmul fast float %8393, %8385
  br label %8395

; <label>:8395                                    ; preds = %8384, %8344
  %8396 = phi float [ %8394, %8384 ], [ 1.000000e+00, %8344 ]
  %8397 = fmul fast float %8370, %16
  %8398 = fmul fast float %8397, %8396
  %8399 = fcmp fast ole float %8368, %9
  %8400 = fcmp fast olt float %8368, 0x3F1A36E2E0000000
  %8401 = or i1 %8399, %8400
  br i1 %8401, label %8448, label %8402

; <label>:8402                                    ; preds = %8395
  %8403 = fdiv fast float %9, %8368
  %8404 = fmul fast float %8403, %8360
  %8405 = fmul fast float %8403, %8361
  %8406 = fmul fast float %8403, %8362
  %8407 = fadd fast float %8404, %17
  %8408 = fadd fast float %8405, %18
  %8409 = fadd fast float %8406, %19
  %8410 = fadd fast float %8407, -9.000000e+02
  %8411 = fadd fast float %8408, -1.500000e+01
  %8412 = fadd fast float %8409, -7.500000e+02
  %8413 = fmul fast float %8410, 0x3F62345680000000
  %8414 = fmul fast float %8411, 0x3F62345680000000
  %8415 = fmul fast float %8412, 0x3F62345680000000
  %8416 = call float @dx.op.dot3.f32(i32 55, float %8413, float %8414, float %8415, float %8413, float %8414, float %8415)  ; Dot3(ax,ay,az,bx,by,bz)
  %8417 = fsub fast float 1.000000e+00, %8416
  %8418 = call float @dx.op.unary.f32(i32 7, float %8417)  ; Saturate(value)
  %8419 = fmul fast float %8418, %8418
  %8420 = fadd fast float %8407, %8357
  %8421 = fadd fast float %8408, %8358
  %8422 = fadd fast float %8409, %8359
  %8423 = fmul fast float %8420, 0x3F52345680000000
  %8424 = fadd fast float %8423, -2.000000e+00
  %8425 = fmul fast float %8421, 0x3F52345680000000
  %8426 = fadd fast float %8425, 0xBFA1111120000000
  %8427 = fmul fast float %8422, 0x3F52345680000000
  %8428 = fadd fast float %8427, 0xBFFAAAAAC0000000
  %8429 = call float @dx.op.dot3.f32(i32 55, float %8424, float %8426, float %8428, float %8424, float %8426, float %8428)  ; Dot3(ax,ay,az,bx,by,bz)
  %8430 = fsub fast float 1.000000e+00, %8429
  %8431 = call float @dx.op.unary.f32(i32 7, float %8430)  ; Saturate(value)
  %8432 = fmul fast float %8431, %8431
  %8433 = fmul fast float %8432, 4.000000e+00
  %8434 = fadd fast float %8433, %8419
  %8435 = fadd fast float %8357, -9.000000e+02
  %8436 = fadd fast float %8358, -1.500000e+01
  %8437 = fadd fast float %8359, -7.500000e+02
  %8438 = fmul fast float %8435, 0x3F62345680000000
  %8439 = fmul fast float %8436, 0x3F62345680000000
  %8440 = fmul fast float %8437, 0x3F62345680000000
  %8441 = call float @dx.op.dot3.f32(i32 55, float %8438, float %8439, float %8440, float %8438, float %8439, float %8440)  ; Dot3(ax,ay,az,bx,by,bz)
  %8442 = fsub fast float 1.000000e+00, %8441
  %8443 = call float @dx.op.unary.f32(i32 7, float %8442)  ; Saturate(value)
  %8444 = fmul fast float %8443, %8443
  %8445 = fadd fast float %8434, %8444
  %8446 = fmul fast float %8369, 0x3F25D867E0000000
  %8447 = fmul fast float %8446, %8445
  br label %8448

; <label>:8448                                    ; preds = %8402, %8395
  %8449 = phi float [ %8447, %8402 ], [ 0.000000e+00, %8395 ]
  %8450 = fadd fast float %8449, %8398
  %8451 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %8450)  ; FMin(a,b)
  %8452 = fmul fast float %8451, 0xBFF7154760000000
  %8453 = call float @dx.op.unary.f32(i32 21, float %8452)  ; Exp(value)
  %8454 = fsub fast float 1.000000e+00, %8453
  %8455 = call float @dx.op.binary.f32(i32 36, float %12, float %8454)  ; FMin(a,b)
  %8456 = fsub fast float %13, %8282
  %8457 = fsub fast float %14, %8283
  %8458 = fsub fast float %15, %8284
  %8459 = fmul fast float %8455, %8456
  %8460 = fmul fast float %8455, %8457
  %8461 = fmul fast float %8455, %8458
  %8462 = fadd fast float %8459, %8282
  %8463 = fadd fast float %8460, %8283
  %8464 = fadd fast float %8461, %8284
  br label %8465

; <label>:8465                                    ; preds = %8448, %8327, %8321
  %8466 = phi float [ %8462, %8448 ], [ %8282, %8327 ], [ %8282, %8321 ]
  %8467 = phi float [ %8463, %8448 ], [ %8283, %8327 ], [ %8283, %8321 ]
  %8468 = phi float [ %8464, %8448 ], [ %8284, %8327 ], [ %8284, %8321 ]
  %8469 = fadd fast float %5, 1.000000e+00
  %8470 = fadd fast float %6, 1.000000e+00
  %8471 = fsub fast float 1.000000e+00, %5
  %8472 = fmul fast float %36, %8469
  %8473 = fmul fast float %36, %8470
  %8474 = fmul fast float %36, %8471
  %8475 = fmul fast float %8472, %8466
  %8476 = fmul fast float %8473, %8467
  %8477 = fmul fast float %8474, %8468
  %8478 = fcmp fast ult float %37, 5.000000e-01
  br i1 %8478, label %8504, label %8479

; <label>:8479                                    ; preds = %8465
  %8480 = fmul fast float %8475, 0x4004147AE0000000
  %8481 = fmul fast float %8476, 0x4004147AE0000000
  %8482 = fmul fast float %8477, 0x4004147AE0000000
  %8483 = fadd fast float %8480, 0x3F9EB851E0000000
  %8484 = fadd fast float %8481, 0x3F9EB851E0000000
  %8485 = fadd fast float %8482, 0x3F9EB851E0000000
  %8486 = fmul fast float %8483, %8475
  %8487 = fmul fast float %8484, %8476
  %8488 = fmul fast float %8485, %8477
  %8489 = fmul fast float %8475, 0x400370A3E0000000
  %8490 = fmul fast float %8476, 0x400370A3E0000000
  %8491 = fmul fast float %8477, 0x400370A3E0000000
  %8492 = fadd fast float %8489, 0x3FE2E147A0000000
  %8493 = fadd fast float %8490, 0x3FE2E147A0000000
  %8494 = fadd fast float %8491, 0x3FE2E147A0000000
  %8495 = fmul fast float %8492, %8475
  %8496 = fmul fast float %8493, %8476
  %8497 = fmul fast float %8494, %8477
  %8498 = fadd fast float %8495, 0x3FC1EB8520000000
  %8499 = fadd fast float %8496, 0x3FC1EB8520000000
  %8500 = fadd fast float %8497, 0x3FC1EB8520000000
  %8501 = fdiv fast float %8486, %8498
  %8502 = fdiv fast float %8487, %8499
  %8503 = fdiv fast float %8488, %8500
  br label %8504

; <label>:8504                                    ; preds = %8479, %8465
  %8505 = phi float [ %8501, %8479 ], [ %8475, %8465 ]
  %8506 = phi float [ %8502, %8479 ], [ %8476, %8465 ]
  %8507 = phi float [ %8503, %8479 ], [ %8477, %8465 ]
  %8508 = call float @dx.op.unary.f32(i32 7, float %8505)  ; Saturate(value)
  %8509 = call float @dx.op.unary.f32(i32 7, float %8506)  ; Saturate(value)
  %8510 = call float @dx.op.unary.f32(i32 7, float %8507)  ; Saturate(value)
  %8511 = call float @dx.op.dot3.f32(i32 55, float %8508, float %8509, float %8510, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %8512 = fsub fast float %8508, %8511
  %8513 = fsub fast float %8509, %8511
  %8514 = fsub fast float %8510, %8511
  %8515 = fmul fast float %8512, %8
  %8516 = fmul fast float %8513, %8
  %8517 = fmul fast float %8514, %8
  %8518 = fadd fast float %8515, %8511
  %8519 = fadd fast float %8516, %8511
  %8520 = fadd fast float %8517, %8511
  %8521 = call float @dx.op.unary.f32(i32 7, float %8518)  ; Saturate(value)
  %8522 = call float @dx.op.unary.f32(i32 7, float %8519)  ; Saturate(value)
  %8523 = call float @dx.op.unary.f32(i32 7, float %8520)  ; Saturate(value)
  %8524 = fadd fast float %8521, 0xBFC70A3D80000000
  %8525 = fadd fast float %8522, 0xBFC70A3D80000000
  %8526 = fadd fast float %8523, 0xBFC70A3D80000000
  %8527 = fmul fast float %8524, %7
  %8528 = fmul fast float %8525, %7
  %8529 = fmul fast float %8526, %7
  %8530 = fadd fast float %8527, 0x3FC70A3D80000000
  %8531 = fadd fast float %8528, 0x3FC70A3D80000000
  %8532 = fadd fast float %8529, 0x3FC70A3D80000000
  %8533 = call float @dx.op.unary.f32(i32 7, float %8530)  ; Saturate(value)
  %8534 = call float @dx.op.unary.f32(i32 7, float %8531)  ; Saturate(value)
  %8535 = call float @dx.op.unary.f32(i32 7, float %8532)  ; Saturate(value)
  br label %8536

; <label>:8536                                    ; preds = %8504, %8287
  %8537 = phi float [ %8318, %8287 ], [ %8533, %8504 ]
  %8538 = phi float [ %8319, %8287 ], [ %8534, %8504 ]
  %8539 = phi float [ %8320, %8287 ], [ %8535, %8504 ]
  %8540 = fsub fast float %8537, %7391
  %8541 = fsub fast float %8538, %7392
  %8542 = fsub fast float %8539, %7393
  %8543 = fmul fast float %8540, %8274
  %8544 = fmul fast float %8541, %8274
  %8545 = fmul fast float %8542, %8274
  %8546 = fadd fast float %8543, %7391
  %8547 = fadd fast float %8544, %7392
  %8548 = fadd fast float %8545, %7393
  br label %8549

; <label>:8549                                    ; preds = %8536, %8261
  %8550 = phi float [ %8546, %8536 ], [ %7391, %8261 ]
  %8551 = phi float [ %8547, %8536 ], [ %7392, %8261 ]
  %8552 = phi float [ %8548, %8536 ], [ %7393, %8261 ]
  %8553 = call float @dx.op.binary.f32(i32 36, float %8262, float %8550)  ; FMin(a,b)
  %8554 = call float @dx.op.binary.f32(i32 36, float %8263, float %8551)  ; FMin(a,b)
  %8555 = call float @dx.op.binary.f32(i32 36, float %8264, float %8552)  ; FMin(a,b)
  %8556 = call float @dx.op.binary.f32(i32 36, float %7684, float %7972)  ; FMin(a,b)
  %8557 = call float @dx.op.binary.f32(i32 36, float %7685, float %7973)  ; FMin(a,b)
  %8558 = call float @dx.op.binary.f32(i32 36, float %7686, float %7974)  ; FMin(a,b)
  %8559 = call float @dx.op.binary.f32(i32 36, float %8556, float %8553)  ; FMin(a,b)
  %8560 = call float @dx.op.binary.f32(i32 36, float %8557, float %8554)  ; FMin(a,b)
  %8561 = call float @dx.op.binary.f32(i32 36, float %8558, float %8555)  ; FMin(a,b)
  %8562 = call float @dx.op.binary.f32(i32 36, float %7391, float %8559)  ; FMin(a,b)
  %8563 = call float @dx.op.binary.f32(i32 36, float %7392, float %8560)  ; FMin(a,b)
  %8564 = call float @dx.op.binary.f32(i32 36, float %7393, float %8561)  ; FMin(a,b)
  %8565 = call float @dx.op.binary.f32(i32 35, float %8262, float %8550)  ; FMax(a,b)
  %8566 = call float @dx.op.binary.f32(i32 35, float %8263, float %8551)  ; FMax(a,b)
  %8567 = call float @dx.op.binary.f32(i32 35, float %8264, float %8552)  ; FMax(a,b)
  %8568 = call float @dx.op.binary.f32(i32 35, float %7684, float %7972)  ; FMax(a,b)
  %8569 = call float @dx.op.binary.f32(i32 35, float %7685, float %7973)  ; FMax(a,b)
  %8570 = call float @dx.op.binary.f32(i32 35, float %7686, float %7974)  ; FMax(a,b)
  %8571 = call float @dx.op.binary.f32(i32 35, float %8568, float %8565)  ; FMax(a,b)
  %8572 = call float @dx.op.binary.f32(i32 35, float %8569, float %8566)  ; FMax(a,b)
  %8573 = call float @dx.op.binary.f32(i32 35, float %8570, float %8567)  ; FMax(a,b)
  %8574 = call float @dx.op.binary.f32(i32 35, float %7391, float %8571)  ; FMax(a,b)
  %8575 = call float @dx.op.binary.f32(i32 35, float %7392, float %8572)  ; FMax(a,b)
  %8576 = call float @dx.op.binary.f32(i32 35, float %7393, float %8573)  ; FMax(a,b)
  %8577 = fsub fast float %8574, %8562
  %8578 = fsub fast float %8575, %8563
  %8579 = fsub fast float %8576, %8564
  %8580 = call float @dx.op.unary.f32(i32 6, float %8577)  ; FAbs(value)
  %8581 = call float @dx.op.unary.f32(i32 6, float %8578)  ; FAbs(value)
  %8582 = call float @dx.op.unary.f32(i32 6, float %8579)  ; FAbs(value)
  %8583 = call float @dx.op.binary.f32(i32 35, float %8581, float %8582)  ; FMax(a,b)
  %8584 = call float @dx.op.binary.f32(i32 35, float %8580, float %8583)  ; FMax(a,b)
  %8585 = call float @dx.op.binary.f32(i32 35, float %8575, float %8576)  ; FMax(a,b)
  %8586 = call float @dx.op.binary.f32(i32 35, float %8574, float %8585)  ; FMax(a,b)
  %8587 = fmul fast float %8586, 1.250000e-01
  %8588 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %8587)  ; FMax(a,b)
  %8589 = fcmp fast ogt float %8584, %8588
  br i1 %8589, label %8590, label %8651

; <label>:8590                                    ; preds = %8549
  %8591 = fsub fast float %7684, %7972
  %8592 = fsub fast float %7685, %7973
  %8593 = fsub fast float %7686, %7974
  %8594 = call float @dx.op.unary.f32(i32 6, float %8591)  ; FAbs(value)
  %8595 = call float @dx.op.unary.f32(i32 6, float %8592)  ; FAbs(value)
  %8596 = call float @dx.op.unary.f32(i32 6, float %8593)  ; FAbs(value)
  %8597 = call float @dx.op.binary.f32(i32 35, float %8595, float %8596)  ; FMax(a,b)
  %8598 = call float @dx.op.binary.f32(i32 35, float %8594, float %8597)  ; FMax(a,b)
  %8599 = fsub fast float %8262, %8550
  %8600 = fsub fast float %8263, %8551
  %8601 = fsub fast float %8264, %8552
  %8602 = call float @dx.op.unary.f32(i32 6, float %8599)  ; FAbs(value)
  %8603 = call float @dx.op.unary.f32(i32 6, float %8600)  ; FAbs(value)
  %8604 = call float @dx.op.unary.f32(i32 6, float %8601)  ; FAbs(value)
  %8605 = call float @dx.op.binary.f32(i32 35, float %8603, float %8604)  ; FMax(a,b)
  %8606 = call float @dx.op.binary.f32(i32 35, float %8602, float %8605)  ; FMax(a,b)
  %8607 = fcmp fast olt float %8598, %8606
  %8608 = select i1 %8607, float %7684, float %8262
  %8609 = select i1 %8607, float %7685, float %8263
  %8610 = select i1 %8607, float %7686, float %8264
  %8611 = select i1 %8607, float %7972, float %8550
  %8612 = select i1 %8607, float %7973, float %8551
  %8613 = select i1 %8607, float %7974, float %8552
  %8614 = fsub fast float %7391, %8611
  %8615 = fsub fast float %7392, %8612
  %8616 = fsub fast float %7393, %8613
  %8617 = fsub fast float %7391, %8608
  %8618 = fsub fast float %7392, %8609
  %8619 = fsub fast float %7393, %8610
  %8620 = call float @dx.op.dot3.f32(i32 55, float %8617, float %8618, float %8619, float %8614, float %8615, float %8616)  ; Dot3(ax,ay,az,bx,by,bz)
  %8621 = fcmp fast ogt float %8620, 0.000000e+00
  br i1 %8621, label %8622, label %8633

; <label>:8622                                    ; preds = %8590
  %8623 = fsub fast float %8608, %8611
  %8624 = fsub fast float %8609, %8612
  %8625 = fsub fast float %8610, %8613
  %8626 = call float @dx.op.unary.f32(i32 6, float %8623)  ; FAbs(value)
  %8627 = call float @dx.op.unary.f32(i32 6, float %8624)  ; FAbs(value)
  %8628 = call float @dx.op.unary.f32(i32 6, float %8625)  ; FAbs(value)
  %8629 = call float @dx.op.binary.f32(i32 35, float %8627, float %8628)  ; FMax(a,b)
  %8630 = call float @dx.op.binary.f32(i32 35, float %8626, float %8629)  ; FMax(a,b)
  %8631 = fmul fast float %8584, 2.500000e-01
  %8632 = fcmp fast olt float %8630, %8631
  br label %8633

; <label>:8633                                    ; preds = %8622, %8590
  %8634 = phi i1 [ false, %8590 ], [ %8632, %8622 ]
  %8635 = select i1 %8634, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  %8636 = fadd fast float %8608, %8611
  %8637 = fadd fast float %8609, %8612
  %8638 = fadd fast float %8610, %8613
  %8639 = fmul fast float %8636, 5.000000e-01
  %8640 = fmul fast float %8637, 5.000000e-01
  %8641 = fmul fast float %8638, 5.000000e-01
  %8642 = fsub fast float %8639, %7391
  %8643 = fsub fast float %8640, %7392
  %8644 = fsub fast float %8641, %7393
  %8645 = fmul fast float %8635, %8642
  %8646 = fmul fast float %8635, %8643
  %8647 = fmul fast float %8635, %8644
  %8648 = fadd fast float %8645, %7391
  %8649 = fadd fast float %8646, %7392
  %8650 = fadd fast float %8647, %7393
  br label %8651

; <label>:8651                                    ; preds = %8633, %8549, %7146
  %8652 = phi float [ %7177, %7146 ], [ %8648, %8633 ], [ %7391, %8549 ]
  %8653 = phi float [ %7178, %7146 ], [ %8649, %8633 ], [ %7392, %8549 ]
  %8654 = phi float [ %7179, %7146 ], [ %8650, %8633 ], [ %7393, %8549 ]
  %8655 = phi float [ %7180, %7146 ], [ %7144, %8633 ], [ %7144, %8549 ]
  %8656 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %67, i32 %70, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %8657 = extractvalue %dx.types.ResRet.f32 %8656, 0
  %8658 = extractvalue %dx.types.ResRet.f32 %8656, 1
  %8659 = extractvalue %dx.types.ResRet.f32 %8656, 2
  %8660 = extractvalue %dx.types.ResRet.f32 %8656, 3
  %8661 = fcmp fast olt float %8660, 0.000000e+00
  br i1 %8661, label %8662, label %8697

; <label>:8662                                    ; preds = %8651
  %8663 = fcmp fast ogt float %8657, 0x3FA4B5DCC0000000
  %8664 = fcmp fast ogt float %8658, 0x3FA4B5DCC0000000
  %8665 = fcmp fast ogt float %8659, 0x3FA4B5DCC0000000
  %8666 = select i1 %8663, float 0.000000e+00, float 1.000000e+00
  %8667 = select i1 %8664, float 0.000000e+00, float 1.000000e+00
  %8668 = select i1 %8665, float 0.000000e+00, float 1.000000e+00
  %8669 = fmul fast float %8657, 0x3FB3D07220000000
  %8670 = fmul fast float %8658, 0x3FB3D07220000000
  %8671 = fmul fast float %8659, 0x3FB3D07220000000
  %8672 = fadd fast float %8657, 0x3FAC28F5C0000000
  %8673 = fadd fast float %8658, 0x3FAC28F5C0000000
  %8674 = fadd fast float %8659, 0x3FAC28F5C0000000
  %8675 = fmul fast float %8672, 0x3FEE54EDE0000000
  %8676 = fmul fast float %8673, 0x3FEE54EDE0000000
  %8677 = fmul fast float %8674, 0x3FEE54EDE0000000
  %8678 = call float @dx.op.unary.f32(i32 23, float %8675)  ; Log(value)
  %8679 = call float @dx.op.unary.f32(i32 23, float %8676)  ; Log(value)
  %8680 = call float @dx.op.unary.f32(i32 23, float %8677)  ; Log(value)
  %8681 = fmul fast float %8678, 0x4003333340000000
  %8682 = fmul fast float %8679, 0x4003333340000000
  %8683 = fmul fast float %8680, 0x4003333340000000
  %8684 = call float @dx.op.unary.f32(i32 21, float %8681)  ; Exp(value)
  %8685 = call float @dx.op.unary.f32(i32 21, float %8682)  ; Exp(value)
  %8686 = call float @dx.op.unary.f32(i32 21, float %8683)  ; Exp(value)
  %8687 = fsub fast float %8669, %8684
  %8688 = fsub fast float %8670, %8685
  %8689 = fsub fast float %8671, %8686
  %8690 = fmul fast float %8687, %8666
  %8691 = fmul fast float %8688, %8667
  %8692 = fmul fast float %8689, %8668
  %8693 = fadd fast float %8690, %8684
  %8694 = fadd fast float %8691, %8685
  %8695 = fadd fast float %8692, %8686
  %8696 = fsub fast float -1.000000e+00, %8660
  br label %10167

; <label>:8697                                    ; preds = %8651
  %8698 = fcmp fast ogt float %38, 5.000000e-01
  %8699 = fcmp fast olt float %88, 1.000000e+00
  %8700 = and i1 %8698, %8699
  br i1 %8700, label %8701, label %8839

; <label>:8701                                    ; preds = %8697
  %8702 = sitofp i32 %67 to float
  %8703 = sitofp i32 %70 to float
  %8704 = fadd fast float %8702, 5.000000e-01
  %8705 = fadd fast float %8703, 5.000000e-01
  %8706 = fdiv fast float %8704, %45
  %8707 = fdiv fast float %8705, %46
  %8708 = fmul fast float %8706, 2.000000e+00
  %8709 = fmul fast float %8707, 2.000000e+00
  %8710 = fadd fast float %8708, -1.000000e+00
  %8711 = fsub fast float 1.000000e+00, %8709
  %8712 = fmul fast float %8710, %35
  %8713 = call float @dx.op.tertiary.f32(i32 46, float %8711, float %31, float %8712)  ; FMad(a,b,c)
  %8714 = call float @dx.op.tertiary.f32(i32 46, float %88, float %27, float %8713)  ; FMad(a,b,c)
  %8715 = fadd fast float %8714, %23
  %8716 = call float @dx.op.unary.f32(i32 6, float %8715)  ; FAbs(value)
  %8717 = fcmp fast ogt float %8716, 0x3EB0C6F7A0000000
  br i1 %8717, label %8718, label %8839

; <label>:8718                                    ; preds = %8701
  %8719 = fmul fast float %8710, %34
  %8720 = call float @dx.op.tertiary.f32(i32 46, float %8711, float %30, float %8719)  ; FMad(a,b,c)
  %8721 = call float @dx.op.tertiary.f32(i32 46, float %88, float %26, float %8720)  ; FMad(a,b,c)
  %8722 = fadd fast float %8721, %22
  %8723 = fmul fast float %8710, %33
  %8724 = call float @dx.op.tertiary.f32(i32 46, float %8711, float %29, float %8723)  ; FMad(a,b,c)
  %8725 = call float @dx.op.tertiary.f32(i32 46, float %88, float %25, float %8724)  ; FMad(a,b,c)
  %8726 = fadd fast float %8725, %21
  %8727 = fmul fast float %8710, %32
  %8728 = call float @dx.op.tertiary.f32(i32 46, float %8711, float %28, float %8727)  ; FMad(a,b,c)
  %8729 = call float @dx.op.tertiary.f32(i32 46, float %88, float %24, float %8728)  ; FMad(a,b,c)
  %8730 = fadd fast float %8729, %20
  %8731 = fdiv fast float %8730, %8715
  %8732 = fdiv fast float %8726, %8715
  %8733 = fdiv fast float %8722, %8715
  %8734 = fsub fast float %8731, %17
  %8735 = fsub fast float %8732, %18
  %8736 = fsub fast float %8733, %19
  %8737 = fmul fast float %8734, %8734
  %8738 = fmul fast float %8735, %8735
  %8739 = fadd fast float %8738, %8737
  %8740 = fmul fast float %8736, %8736
  %8741 = fadd fast float %8739, %8740
  %8742 = call float @dx.op.unary.f32(i32 24, float %8741)  ; Sqrt(value)
  %8743 = fsub fast float %8742, %9
  %8744 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %8743)  ; FMax(a,b)
  %8745 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %8745, label %8746, label %8769

; <label>:8746                                    ; preds = %8718
  %8747 = call float @dx.op.unary.f32(i32 6, float %8735)  ; FAbs(value)
  %8748 = fmul fast float %8747, %11
  %8749 = fcmp fast olt float %8748, 0x3F50624DE0000000
  br i1 %8749, label %8750, label %8753

; <label>:8750                                    ; preds = %8746
  %8751 = fmul fast float %8748, 5.000000e-01
  %8752 = fsub fast float 1.000000e+00, %8751
  br label %8758

; <label>:8753                                    ; preds = %8746
  %8754 = fmul fast float %8748, 0xBFF7154760000000
  %8755 = call float @dx.op.unary.f32(i32 21, float %8754)  ; Exp(value)
  %8756 = fsub fast float 1.000000e+00, %8755
  %8757 = fdiv fast float %8756, %8748
  br label %8758

; <label>:8758                                    ; preds = %8753, %8750
  %8759 = phi float [ %8752, %8750 ], [ %8757, %8753 ]
  %8760 = call float @dx.op.binary.f32(i32 36, float %8732, float %18)  ; FMin(a,b)
  %8761 = fsub fast float %8760, %10
  %8762 = fmul fast float %11, %8761
  %8763 = fsub fast float -0.000000e+00, %8762
  %8764 = call float @dx.op.binary.f32(i32 35, float %8763, float -4.000000e+01)  ; FMax(a,b)
  %8765 = call float @dx.op.binary.f32(i32 36, float %8764, float 5.000000e+00)  ; FMin(a,b)
  %8766 = fmul fast float %8765, 0x3FF7154760000000
  %8767 = call float @dx.op.unary.f32(i32 21, float %8766)  ; Exp(value)
  %8768 = fmul fast float %8767, %8759
  br label %8769

; <label>:8769                                    ; preds = %8758, %8718
  %8770 = phi float [ %8768, %8758 ], [ 1.000000e+00, %8718 ]
  %8771 = fmul fast float %8744, %16
  %8772 = fmul fast float %8771, %8770
  %8773 = fcmp fast ole float %8742, %9
  %8774 = fcmp fast olt float %8742, 0x3F1A36E2E0000000
  %8775 = or i1 %8773, %8774
  br i1 %8775, label %8822, label %8776

; <label>:8776                                    ; preds = %8769
  %8777 = fdiv fast float %9, %8742
  %8778 = fmul fast float %8777, %8734
  %8779 = fmul fast float %8777, %8735
  %8780 = fmul fast float %8777, %8736
  %8781 = fadd fast float %8778, %17
  %8782 = fadd fast float %8779, %18
  %8783 = fadd fast float %8780, %19
  %8784 = fadd fast float %8781, -9.000000e+02
  %8785 = fadd fast float %8782, -1.500000e+01
  %8786 = fadd fast float %8783, -7.500000e+02
  %8787 = fmul fast float %8784, 0x3F62345680000000
  %8788 = fmul fast float %8785, 0x3F62345680000000
  %8789 = fmul fast float %8786, 0x3F62345680000000
  %8790 = call float @dx.op.dot3.f32(i32 55, float %8787, float %8788, float %8789, float %8787, float %8788, float %8789)  ; Dot3(ax,ay,az,bx,by,bz)
  %8791 = fsub fast float 1.000000e+00, %8790
  %8792 = call float @dx.op.unary.f32(i32 7, float %8791)  ; Saturate(value)
  %8793 = fmul fast float %8792, %8792
  %8794 = fadd fast float %8781, %8731
  %8795 = fadd fast float %8782, %8732
  %8796 = fadd fast float %8783, %8733
  %8797 = fmul fast float %8794, 0x3F52345680000000
  %8798 = fadd fast float %8797, -2.000000e+00
  %8799 = fmul fast float %8795, 0x3F52345680000000
  %8800 = fadd fast float %8799, 0xBFA1111120000000
  %8801 = fmul fast float %8796, 0x3F52345680000000
  %8802 = fadd fast float %8801, 0xBFFAAAAAC0000000
  %8803 = call float @dx.op.dot3.f32(i32 55, float %8798, float %8800, float %8802, float %8798, float %8800, float %8802)  ; Dot3(ax,ay,az,bx,by,bz)
  %8804 = fsub fast float 1.000000e+00, %8803
  %8805 = call float @dx.op.unary.f32(i32 7, float %8804)  ; Saturate(value)
  %8806 = fmul fast float %8805, %8805
  %8807 = fmul fast float %8806, 4.000000e+00
  %8808 = fadd fast float %8807, %8793
  %8809 = fadd fast float %8731, -9.000000e+02
  %8810 = fadd fast float %8732, -1.500000e+01
  %8811 = fadd fast float %8733, -7.500000e+02
  %8812 = fmul fast float %8809, 0x3F62345680000000
  %8813 = fmul fast float %8810, 0x3F62345680000000
  %8814 = fmul fast float %8811, 0x3F62345680000000
  %8815 = call float @dx.op.dot3.f32(i32 55, float %8812, float %8813, float %8814, float %8812, float %8813, float %8814)  ; Dot3(ax,ay,az,bx,by,bz)
  %8816 = fsub fast float 1.000000e+00, %8815
  %8817 = call float @dx.op.unary.f32(i32 7, float %8816)  ; Saturate(value)
  %8818 = fmul fast float %8817, %8817
  %8819 = fadd fast float %8808, %8818
  %8820 = fmul fast float %8743, 0x3F25D867E0000000
  %8821 = fmul fast float %8820, %8819
  br label %8822

; <label>:8822                                    ; preds = %8776, %8769
  %8823 = phi float [ %8821, %8776 ], [ 0.000000e+00, %8769 ]
  %8824 = fadd fast float %8823, %8772
  %8825 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %8824)  ; FMin(a,b)
  %8826 = fmul fast float %8825, 0xBFF7154760000000
  %8827 = call float @dx.op.unary.f32(i32 21, float %8826)  ; Exp(value)
  %8828 = fsub fast float 1.000000e+00, %8827
  %8829 = call float @dx.op.binary.f32(i32 36, float %12, float %8828)  ; FMin(a,b)
  %8830 = fsub fast float %13, %8657
  %8831 = fsub fast float %14, %8658
  %8832 = fsub fast float %15, %8659
  %8833 = fmul fast float %8829, %8830
  %8834 = fmul fast float %8829, %8831
  %8835 = fmul fast float %8829, %8832
  %8836 = fadd fast float %8833, %8657
  %8837 = fadd fast float %8834, %8658
  %8838 = fadd fast float %8835, %8659
  br label %8839

; <label>:8839                                    ; preds = %8822, %8701, %8697
  %8840 = phi float [ %8836, %8822 ], [ %8657, %8701 ], [ %8657, %8697 ]
  %8841 = phi float [ %8837, %8822 ], [ %8658, %8701 ], [ %8658, %8697 ]
  %8842 = phi float [ %8838, %8822 ], [ %8659, %8701 ], [ %8659, %8697 ]
  %8843 = fadd fast float %5, 1.000000e+00
  %8844 = fadd fast float %6, 1.000000e+00
  %8845 = fsub fast float 1.000000e+00, %5
  %8846 = fmul fast float %36, %8843
  %8847 = fmul fast float %36, %8844
  %8848 = fmul fast float %36, %8845
  %8849 = fmul fast float %8846, %8840
  %8850 = fmul fast float %8847, %8841
  %8851 = fmul fast float %8848, %8842
  %8852 = fcmp fast ult float %37, 5.000000e-01
  br i1 %8852, label %8878, label %8853

; <label>:8853                                    ; preds = %8839
  %8854 = fmul fast float %8849, 0x4004147AE0000000
  %8855 = fmul fast float %8850, 0x4004147AE0000000
  %8856 = fmul fast float %8851, 0x4004147AE0000000
  %8857 = fadd fast float %8854, 0x3F9EB851E0000000
  %8858 = fadd fast float %8855, 0x3F9EB851E0000000
  %8859 = fadd fast float %8856, 0x3F9EB851E0000000
  %8860 = fmul fast float %8857, %8849
  %8861 = fmul fast float %8858, %8850
  %8862 = fmul fast float %8859, %8851
  %8863 = fmul fast float %8849, 0x400370A3E0000000
  %8864 = fmul fast float %8850, 0x400370A3E0000000
  %8865 = fmul fast float %8851, 0x400370A3E0000000
  %8866 = fadd fast float %8863, 0x3FE2E147A0000000
  %8867 = fadd fast float %8864, 0x3FE2E147A0000000
  %8868 = fadd fast float %8865, 0x3FE2E147A0000000
  %8869 = fmul fast float %8866, %8849
  %8870 = fmul fast float %8867, %8850
  %8871 = fmul fast float %8868, %8851
  %8872 = fadd fast float %8869, 0x3FC1EB8520000000
  %8873 = fadd fast float %8870, 0x3FC1EB8520000000
  %8874 = fadd fast float %8871, 0x3FC1EB8520000000
  %8875 = fdiv fast float %8860, %8872
  %8876 = fdiv fast float %8861, %8873
  %8877 = fdiv fast float %8862, %8874
  br label %8878

; <label>:8878                                    ; preds = %8853, %8839
  %8879 = phi float [ %8875, %8853 ], [ %8849, %8839 ]
  %8880 = phi float [ %8876, %8853 ], [ %8850, %8839 ]
  %8881 = phi float [ %8877, %8853 ], [ %8851, %8839 ]
  %8882 = call float @dx.op.unary.f32(i32 7, float %8879)  ; Saturate(value)
  %8883 = call float @dx.op.unary.f32(i32 7, float %8880)  ; Saturate(value)
  %8884 = call float @dx.op.unary.f32(i32 7, float %8881)  ; Saturate(value)
  %8885 = call float @dx.op.dot3.f32(i32 55, float %8882, float %8883, float %8884, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %8886 = fsub fast float %8882, %8885
  %8887 = fsub fast float %8883, %8885
  %8888 = fsub fast float %8884, %8885
  %8889 = fmul fast float %8886, %8
  %8890 = fmul fast float %8887, %8
  %8891 = fmul fast float %8888, %8
  %8892 = fadd fast float %8889, %8885
  %8893 = fadd fast float %8890, %8885
  %8894 = fadd fast float %8891, %8885
  %8895 = call float @dx.op.unary.f32(i32 7, float %8892)  ; Saturate(value)
  %8896 = call float @dx.op.unary.f32(i32 7, float %8893)  ; Saturate(value)
  %8897 = call float @dx.op.unary.f32(i32 7, float %8894)  ; Saturate(value)
  %8898 = fadd fast float %8895, 0xBFC70A3D80000000
  %8899 = fadd fast float %8896, 0xBFC70A3D80000000
  %8900 = fadd fast float %8897, 0xBFC70A3D80000000
  %8901 = fmul fast float %8898, %7
  %8902 = fmul fast float %8899, %7
  %8903 = fmul fast float %8900, %7
  %8904 = fadd fast float %8901, 0x3FC70A3D80000000
  %8905 = fadd fast float %8902, 0x3FC70A3D80000000
  %8906 = fadd fast float %8903, 0x3FC70A3D80000000
  %8907 = call float @dx.op.unary.f32(i32 7, float %8904)  ; Saturate(value)
  %8908 = call float @dx.op.unary.f32(i32 7, float %8905)  ; Saturate(value)
  %8909 = call float @dx.op.unary.f32(i32 7, float %8906)  ; Saturate(value)
  %8910 = add i32 %70, -1
  %8911 = call i32 @dx.op.binary.i32(i32 37, i32 %67, i32 0)  ; IMax(a,b)
  %8912 = call i32 @dx.op.binary.i32(i32 37, i32 %8910, i32 0)  ; IMax(a,b)
  %8913 = call i32 @dx.op.binary.i32(i32 38, i32 %8911, i32 %59)  ; IMin(a,b)
  %8914 = call i32 @dx.op.binary.i32(i32 38, i32 %8912, i32 %60)  ; IMin(a,b)
  %8915 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %8913, i32 %8914, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %8916 = extractvalue %dx.types.ResRet.f32 %8915, 0
  %8917 = fsub fast float 1.000000e+00, %88
  %8918 = fmul fast float %8917, 0x3FA99999A0000000
  %8919 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %8918)  ; FMax(a,b)
  %8920 = fsub fast float %8916, %88
  %8921 = call float @dx.op.unary.f32(i32 6, float %8920)  ; FAbs(value)
  %8922 = fdiv fast float %8921, %8919
  %8923 = fsub fast float 1.000000e+00, %8922
  %8924 = call float @dx.op.unary.f32(i32 7, float %8923)  ; Saturate(value)
  %8925 = fcmp fast ugt float %8924, 0.000000e+00
  br i1 %8925, label %8926, label %9199

; <label>:8926                                    ; preds = %8878
  %8927 = call i32 @dx.op.binary.i32(i32 37, i32 %8913, i32 0)  ; IMax(a,b)
  %8928 = call i32 @dx.op.binary.i32(i32 37, i32 %8914, i32 0)  ; IMax(a,b)
  %8929 = call i32 @dx.op.binary.i32(i32 38, i32 %8927, i32 %59)  ; IMin(a,b)
  %8930 = call i32 @dx.op.binary.i32(i32 38, i32 %8928, i32 %60)  ; IMin(a,b)
  %8931 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %8929, i32 %8930, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %8932 = extractvalue %dx.types.ResRet.f32 %8931, 0
  %8933 = extractvalue %dx.types.ResRet.f32 %8931, 1
  %8934 = extractvalue %dx.types.ResRet.f32 %8931, 2
  %8935 = extractvalue %dx.types.ResRet.f32 %8931, 3
  %8936 = fcmp fast olt float %8935, 0.000000e+00
  br i1 %8936, label %8937, label %8971

; <label>:8937                                    ; preds = %8926
  %8938 = fcmp fast ogt float %8932, 0x3FA4B5DCC0000000
  %8939 = fcmp fast ogt float %8933, 0x3FA4B5DCC0000000
  %8940 = fcmp fast ogt float %8934, 0x3FA4B5DCC0000000
  %8941 = select i1 %8938, float 0.000000e+00, float 1.000000e+00
  %8942 = select i1 %8939, float 0.000000e+00, float 1.000000e+00
  %8943 = select i1 %8940, float 0.000000e+00, float 1.000000e+00
  %8944 = fmul fast float %8932, 0x3FB3D07220000000
  %8945 = fmul fast float %8933, 0x3FB3D07220000000
  %8946 = fmul fast float %8934, 0x3FB3D07220000000
  %8947 = fadd fast float %8932, 0x3FAC28F5C0000000
  %8948 = fadd fast float %8933, 0x3FAC28F5C0000000
  %8949 = fadd fast float %8934, 0x3FAC28F5C0000000
  %8950 = fmul fast float %8947, 0x3FEE54EDE0000000
  %8951 = fmul fast float %8948, 0x3FEE54EDE0000000
  %8952 = fmul fast float %8949, 0x3FEE54EDE0000000
  %8953 = call float @dx.op.unary.f32(i32 23, float %8950)  ; Log(value)
  %8954 = call float @dx.op.unary.f32(i32 23, float %8951)  ; Log(value)
  %8955 = call float @dx.op.unary.f32(i32 23, float %8952)  ; Log(value)
  %8956 = fmul fast float %8953, 0x4003333340000000
  %8957 = fmul fast float %8954, 0x4003333340000000
  %8958 = fmul fast float %8955, 0x4003333340000000
  %8959 = call float @dx.op.unary.f32(i32 21, float %8956)  ; Exp(value)
  %8960 = call float @dx.op.unary.f32(i32 21, float %8957)  ; Exp(value)
  %8961 = call float @dx.op.unary.f32(i32 21, float %8958)  ; Exp(value)
  %8962 = fsub fast float %8944, %8959
  %8963 = fsub fast float %8945, %8960
  %8964 = fsub fast float %8946, %8961
  %8965 = fmul fast float %8962, %8941
  %8966 = fmul fast float %8963, %8942
  %8967 = fmul fast float %8964, %8943
  %8968 = fadd fast float %8965, %8959
  %8969 = fadd fast float %8966, %8960
  %8970 = fadd fast float %8967, %8961
  br label %9186

; <label>:8971                                    ; preds = %8926
  %8972 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %8929, i32 %8930, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %8973 = extractvalue %dx.types.ResRet.f32 %8972, 0
  %8974 = fcmp fast ogt float %38, 5.000000e-01
  %8975 = fcmp fast olt float %8973, 1.000000e+00
  %8976 = and i1 %8974, %8975
  br i1 %8976, label %8977, label %9115

; <label>:8977                                    ; preds = %8971
  %8978 = sitofp i32 %8929 to float
  %8979 = sitofp i32 %8930 to float
  %8980 = fadd fast float %8978, 5.000000e-01
  %8981 = fadd fast float %8979, 5.000000e-01
  %8982 = fdiv fast float %8980, %45
  %8983 = fdiv fast float %8981, %46
  %8984 = fmul fast float %8982, 2.000000e+00
  %8985 = fmul fast float %8983, 2.000000e+00
  %8986 = fadd fast float %8984, -1.000000e+00
  %8987 = fsub fast float 1.000000e+00, %8985
  %8988 = fmul fast float %8986, %35
  %8989 = call float @dx.op.tertiary.f32(i32 46, float %8987, float %31, float %8988)  ; FMad(a,b,c)
  %8990 = call float @dx.op.tertiary.f32(i32 46, float %8973, float %27, float %8989)  ; FMad(a,b,c)
  %8991 = fadd fast float %8990, %23
  %8992 = call float @dx.op.unary.f32(i32 6, float %8991)  ; FAbs(value)
  %8993 = fcmp fast ogt float %8992, 0x3EB0C6F7A0000000
  br i1 %8993, label %8994, label %9115

; <label>:8994                                    ; preds = %8977
  %8995 = fmul fast float %8986, %34
  %8996 = call float @dx.op.tertiary.f32(i32 46, float %8987, float %30, float %8995)  ; FMad(a,b,c)
  %8997 = call float @dx.op.tertiary.f32(i32 46, float %8973, float %26, float %8996)  ; FMad(a,b,c)
  %8998 = fadd fast float %8997, %22
  %8999 = fmul fast float %8986, %33
  %9000 = call float @dx.op.tertiary.f32(i32 46, float %8987, float %29, float %8999)  ; FMad(a,b,c)
  %9001 = call float @dx.op.tertiary.f32(i32 46, float %8973, float %25, float %9000)  ; FMad(a,b,c)
  %9002 = fadd fast float %9001, %21
  %9003 = fmul fast float %8986, %32
  %9004 = call float @dx.op.tertiary.f32(i32 46, float %8987, float %28, float %9003)  ; FMad(a,b,c)
  %9005 = call float @dx.op.tertiary.f32(i32 46, float %8973, float %24, float %9004)  ; FMad(a,b,c)
  %9006 = fadd fast float %9005, %20
  %9007 = fdiv fast float %9006, %8991
  %9008 = fdiv fast float %9002, %8991
  %9009 = fdiv fast float %8998, %8991
  %9010 = fsub fast float %9007, %17
  %9011 = fsub fast float %9008, %18
  %9012 = fsub fast float %9009, %19
  %9013 = fmul fast float %9010, %9010
  %9014 = fmul fast float %9011, %9011
  %9015 = fadd fast float %9014, %9013
  %9016 = fmul fast float %9012, %9012
  %9017 = fadd fast float %9015, %9016
  %9018 = call float @dx.op.unary.f32(i32 24, float %9017)  ; Sqrt(value)
  %9019 = fsub fast float %9018, %9
  %9020 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %9019)  ; FMax(a,b)
  %9021 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %9021, label %9022, label %9045

; <label>:9022                                    ; preds = %8994
  %9023 = call float @dx.op.unary.f32(i32 6, float %9011)  ; FAbs(value)
  %9024 = fmul fast float %9023, %11
  %9025 = fcmp fast olt float %9024, 0x3F50624DE0000000
  br i1 %9025, label %9026, label %9029

; <label>:9026                                    ; preds = %9022
  %9027 = fmul fast float %9024, 5.000000e-01
  %9028 = fsub fast float 1.000000e+00, %9027
  br label %9034

; <label>:9029                                    ; preds = %9022
  %9030 = fmul fast float %9024, 0xBFF7154760000000
  %9031 = call float @dx.op.unary.f32(i32 21, float %9030)  ; Exp(value)
  %9032 = fsub fast float 1.000000e+00, %9031
  %9033 = fdiv fast float %9032, %9024
  br label %9034

; <label>:9034                                    ; preds = %9029, %9026
  %9035 = phi float [ %9028, %9026 ], [ %9033, %9029 ]
  %9036 = call float @dx.op.binary.f32(i32 36, float %9008, float %18)  ; FMin(a,b)
  %9037 = fsub fast float %9036, %10
  %9038 = fmul fast float %11, %9037
  %9039 = fsub fast float -0.000000e+00, %9038
  %9040 = call float @dx.op.binary.f32(i32 35, float %9039, float -4.000000e+01)  ; FMax(a,b)
  %9041 = call float @dx.op.binary.f32(i32 36, float %9040, float 5.000000e+00)  ; FMin(a,b)
  %9042 = fmul fast float %9041, 0x3FF7154760000000
  %9043 = call float @dx.op.unary.f32(i32 21, float %9042)  ; Exp(value)
  %9044 = fmul fast float %9043, %9035
  br label %9045

; <label>:9045                                    ; preds = %9034, %8994
  %9046 = phi float [ %9044, %9034 ], [ 1.000000e+00, %8994 ]
  %9047 = fmul fast float %9020, %16
  %9048 = fmul fast float %9047, %9046
  %9049 = fcmp fast ole float %9018, %9
  %9050 = fcmp fast olt float %9018, 0x3F1A36E2E0000000
  %9051 = or i1 %9049, %9050
  br i1 %9051, label %9098, label %9052

; <label>:9052                                    ; preds = %9045
  %9053 = fdiv fast float %9, %9018
  %9054 = fmul fast float %9053, %9010
  %9055 = fmul fast float %9053, %9011
  %9056 = fmul fast float %9053, %9012
  %9057 = fadd fast float %9054, %17
  %9058 = fadd fast float %9055, %18
  %9059 = fadd fast float %9056, %19
  %9060 = fadd fast float %9057, -9.000000e+02
  %9061 = fadd fast float %9058, -1.500000e+01
  %9062 = fadd fast float %9059, -7.500000e+02
  %9063 = fmul fast float %9060, 0x3F62345680000000
  %9064 = fmul fast float %9061, 0x3F62345680000000
  %9065 = fmul fast float %9062, 0x3F62345680000000
  %9066 = call float @dx.op.dot3.f32(i32 55, float %9063, float %9064, float %9065, float %9063, float %9064, float %9065)  ; Dot3(ax,ay,az,bx,by,bz)
  %9067 = fsub fast float 1.000000e+00, %9066
  %9068 = call float @dx.op.unary.f32(i32 7, float %9067)  ; Saturate(value)
  %9069 = fmul fast float %9068, %9068
  %9070 = fadd fast float %9057, %9007
  %9071 = fadd fast float %9058, %9008
  %9072 = fadd fast float %9059, %9009
  %9073 = fmul fast float %9070, 0x3F52345680000000
  %9074 = fadd fast float %9073, -2.000000e+00
  %9075 = fmul fast float %9071, 0x3F52345680000000
  %9076 = fadd fast float %9075, 0xBFA1111120000000
  %9077 = fmul fast float %9072, 0x3F52345680000000
  %9078 = fadd fast float %9077, 0xBFFAAAAAC0000000
  %9079 = call float @dx.op.dot3.f32(i32 55, float %9074, float %9076, float %9078, float %9074, float %9076, float %9078)  ; Dot3(ax,ay,az,bx,by,bz)
  %9080 = fsub fast float 1.000000e+00, %9079
  %9081 = call float @dx.op.unary.f32(i32 7, float %9080)  ; Saturate(value)
  %9082 = fmul fast float %9081, %9081
  %9083 = fmul fast float %9082, 4.000000e+00
  %9084 = fadd fast float %9083, %9069
  %9085 = fadd fast float %9007, -9.000000e+02
  %9086 = fadd fast float %9008, -1.500000e+01
  %9087 = fadd fast float %9009, -7.500000e+02
  %9088 = fmul fast float %9085, 0x3F62345680000000
  %9089 = fmul fast float %9086, 0x3F62345680000000
  %9090 = fmul fast float %9087, 0x3F62345680000000
  %9091 = call float @dx.op.dot3.f32(i32 55, float %9088, float %9089, float %9090, float %9088, float %9089, float %9090)  ; Dot3(ax,ay,az,bx,by,bz)
  %9092 = fsub fast float 1.000000e+00, %9091
  %9093 = call float @dx.op.unary.f32(i32 7, float %9092)  ; Saturate(value)
  %9094 = fmul fast float %9093, %9093
  %9095 = fadd fast float %9084, %9094
  %9096 = fmul fast float %9019, 0x3F25D867E0000000
  %9097 = fmul fast float %9096, %9095
  br label %9098

; <label>:9098                                    ; preds = %9052, %9045
  %9099 = phi float [ %9097, %9052 ], [ 0.000000e+00, %9045 ]
  %9100 = fadd fast float %9099, %9048
  %9101 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %9100)  ; FMin(a,b)
  %9102 = fmul fast float %9101, 0xBFF7154760000000
  %9103 = call float @dx.op.unary.f32(i32 21, float %9102)  ; Exp(value)
  %9104 = fsub fast float 1.000000e+00, %9103
  %9105 = call float @dx.op.binary.f32(i32 36, float %12, float %9104)  ; FMin(a,b)
  %9106 = fsub fast float %13, %8932
  %9107 = fsub fast float %14, %8933
  %9108 = fsub fast float %15, %8934
  %9109 = fmul fast float %9105, %9106
  %9110 = fmul fast float %9105, %9107
  %9111 = fmul fast float %9105, %9108
  %9112 = fadd fast float %9109, %8932
  %9113 = fadd fast float %9110, %8933
  %9114 = fadd fast float %9111, %8934
  br label %9115

; <label>:9115                                    ; preds = %9098, %8977, %8971
  %9116 = phi float [ %9112, %9098 ], [ %8932, %8977 ], [ %8932, %8971 ]
  %9117 = phi float [ %9113, %9098 ], [ %8933, %8977 ], [ %8933, %8971 ]
  %9118 = phi float [ %9114, %9098 ], [ %8934, %8977 ], [ %8934, %8971 ]
  %9119 = fadd fast float %5, 1.000000e+00
  %9120 = fadd fast float %6, 1.000000e+00
  %9121 = fsub fast float 1.000000e+00, %5
  %9122 = fmul fast float %36, %9119
  %9123 = fmul fast float %36, %9120
  %9124 = fmul fast float %36, %9121
  %9125 = fmul fast float %9122, %9116
  %9126 = fmul fast float %9123, %9117
  %9127 = fmul fast float %9124, %9118
  %9128 = fcmp fast ult float %37, 5.000000e-01
  br i1 %9128, label %9154, label %9129

; <label>:9129                                    ; preds = %9115
  %9130 = fmul fast float %9125, 0x4004147AE0000000
  %9131 = fmul fast float %9126, 0x4004147AE0000000
  %9132 = fmul fast float %9127, 0x4004147AE0000000
  %9133 = fadd fast float %9130, 0x3F9EB851E0000000
  %9134 = fadd fast float %9131, 0x3F9EB851E0000000
  %9135 = fadd fast float %9132, 0x3F9EB851E0000000
  %9136 = fmul fast float %9133, %9125
  %9137 = fmul fast float %9134, %9126
  %9138 = fmul fast float %9135, %9127
  %9139 = fmul fast float %9125, 0x400370A3E0000000
  %9140 = fmul fast float %9126, 0x400370A3E0000000
  %9141 = fmul fast float %9127, 0x400370A3E0000000
  %9142 = fadd fast float %9139, 0x3FE2E147A0000000
  %9143 = fadd fast float %9140, 0x3FE2E147A0000000
  %9144 = fadd fast float %9141, 0x3FE2E147A0000000
  %9145 = fmul fast float %9142, %9125
  %9146 = fmul fast float %9143, %9126
  %9147 = fmul fast float %9144, %9127
  %9148 = fadd fast float %9145, 0x3FC1EB8520000000
  %9149 = fadd fast float %9146, 0x3FC1EB8520000000
  %9150 = fadd fast float %9147, 0x3FC1EB8520000000
  %9151 = fdiv fast float %9136, %9148
  %9152 = fdiv fast float %9137, %9149
  %9153 = fdiv fast float %9138, %9150
  br label %9154

; <label>:9154                                    ; preds = %9129, %9115
  %9155 = phi float [ %9151, %9129 ], [ %9125, %9115 ]
  %9156 = phi float [ %9152, %9129 ], [ %9126, %9115 ]
  %9157 = phi float [ %9153, %9129 ], [ %9127, %9115 ]
  %9158 = call float @dx.op.unary.f32(i32 7, float %9155)  ; Saturate(value)
  %9159 = call float @dx.op.unary.f32(i32 7, float %9156)  ; Saturate(value)
  %9160 = call float @dx.op.unary.f32(i32 7, float %9157)  ; Saturate(value)
  %9161 = call float @dx.op.dot3.f32(i32 55, float %9158, float %9159, float %9160, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %9162 = fsub fast float %9158, %9161
  %9163 = fsub fast float %9159, %9161
  %9164 = fsub fast float %9160, %9161
  %9165 = fmul fast float %9162, %8
  %9166 = fmul fast float %9163, %8
  %9167 = fmul fast float %9164, %8
  %9168 = fadd fast float %9165, %9161
  %9169 = fadd fast float %9166, %9161
  %9170 = fadd fast float %9167, %9161
  %9171 = call float @dx.op.unary.f32(i32 7, float %9168)  ; Saturate(value)
  %9172 = call float @dx.op.unary.f32(i32 7, float %9169)  ; Saturate(value)
  %9173 = call float @dx.op.unary.f32(i32 7, float %9170)  ; Saturate(value)
  %9174 = fadd fast float %9171, 0xBFC70A3D80000000
  %9175 = fadd fast float %9172, 0xBFC70A3D80000000
  %9176 = fadd fast float %9173, 0xBFC70A3D80000000
  %9177 = fmul fast float %9174, %7
  %9178 = fmul fast float %9175, %7
  %9179 = fmul fast float %9176, %7
  %9180 = fadd fast float %9177, 0x3FC70A3D80000000
  %9181 = fadd fast float %9178, 0x3FC70A3D80000000
  %9182 = fadd fast float %9179, 0x3FC70A3D80000000
  %9183 = call float @dx.op.unary.f32(i32 7, float %9180)  ; Saturate(value)
  %9184 = call float @dx.op.unary.f32(i32 7, float %9181)  ; Saturate(value)
  %9185 = call float @dx.op.unary.f32(i32 7, float %9182)  ; Saturate(value)
  br label %9186

; <label>:9186                                    ; preds = %9154, %8937
  %9187 = phi float [ %8968, %8937 ], [ %9183, %9154 ]
  %9188 = phi float [ %8969, %8937 ], [ %9184, %9154 ]
  %9189 = phi float [ %8970, %8937 ], [ %9185, %9154 ]
  %9190 = fsub fast float %9187, %8907
  %9191 = fsub fast float %9188, %8908
  %9192 = fsub fast float %9189, %8909
  %9193 = fmul fast float %9190, %8924
  %9194 = fmul fast float %9191, %8924
  %9195 = fmul fast float %9192, %8924
  %9196 = fadd fast float %9193, %8907
  %9197 = fadd fast float %9194, %8908
  %9198 = fadd fast float %9195, %8909
  br label %9199

; <label>:9199                                    ; preds = %9186, %8878
  %9200 = phi float [ %9196, %9186 ], [ %8907, %8878 ]
  %9201 = phi float [ %9197, %9186 ], [ %8908, %8878 ]
  %9202 = phi float [ %9198, %9186 ], [ %8909, %8878 ]
  %9203 = add i32 %70, 1
  %9204 = call i32 @dx.op.binary.i32(i32 37, i32 %9203, i32 0)  ; IMax(a,b)
  %9205 = call i32 @dx.op.binary.i32(i32 38, i32 %9204, i32 %60)  ; IMin(a,b)
  %9206 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %8913, i32 %9205, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %9207 = extractvalue %dx.types.ResRet.f32 %9206, 0
  %9208 = fsub fast float %9207, %88
  %9209 = call float @dx.op.unary.f32(i32 6, float %9208)  ; FAbs(value)
  %9210 = fdiv fast float %9209, %8919
  %9211 = fsub fast float 1.000000e+00, %9210
  %9212 = call float @dx.op.unary.f32(i32 7, float %9211)  ; Saturate(value)
  %9213 = fcmp fast ugt float %9212, 0.000000e+00
  br i1 %9213, label %9214, label %9487

; <label>:9214                                    ; preds = %9199
  %9215 = call i32 @dx.op.binary.i32(i32 37, i32 %8913, i32 0)  ; IMax(a,b)
  %9216 = call i32 @dx.op.binary.i32(i32 37, i32 %9205, i32 0)  ; IMax(a,b)
  %9217 = call i32 @dx.op.binary.i32(i32 38, i32 %9215, i32 %59)  ; IMin(a,b)
  %9218 = call i32 @dx.op.binary.i32(i32 38, i32 %9216, i32 %60)  ; IMin(a,b)
  %9219 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %9217, i32 %9218, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %9220 = extractvalue %dx.types.ResRet.f32 %9219, 0
  %9221 = extractvalue %dx.types.ResRet.f32 %9219, 1
  %9222 = extractvalue %dx.types.ResRet.f32 %9219, 2
  %9223 = extractvalue %dx.types.ResRet.f32 %9219, 3
  %9224 = fcmp fast olt float %9223, 0.000000e+00
  br i1 %9224, label %9225, label %9259

; <label>:9225                                    ; preds = %9214
  %9226 = fcmp fast ogt float %9220, 0x3FA4B5DCC0000000
  %9227 = fcmp fast ogt float %9221, 0x3FA4B5DCC0000000
  %9228 = fcmp fast ogt float %9222, 0x3FA4B5DCC0000000
  %9229 = select i1 %9226, float 0.000000e+00, float 1.000000e+00
  %9230 = select i1 %9227, float 0.000000e+00, float 1.000000e+00
  %9231 = select i1 %9228, float 0.000000e+00, float 1.000000e+00
  %9232 = fmul fast float %9220, 0x3FB3D07220000000
  %9233 = fmul fast float %9221, 0x3FB3D07220000000
  %9234 = fmul fast float %9222, 0x3FB3D07220000000
  %9235 = fadd fast float %9220, 0x3FAC28F5C0000000
  %9236 = fadd fast float %9221, 0x3FAC28F5C0000000
  %9237 = fadd fast float %9222, 0x3FAC28F5C0000000
  %9238 = fmul fast float %9235, 0x3FEE54EDE0000000
  %9239 = fmul fast float %9236, 0x3FEE54EDE0000000
  %9240 = fmul fast float %9237, 0x3FEE54EDE0000000
  %9241 = call float @dx.op.unary.f32(i32 23, float %9238)  ; Log(value)
  %9242 = call float @dx.op.unary.f32(i32 23, float %9239)  ; Log(value)
  %9243 = call float @dx.op.unary.f32(i32 23, float %9240)  ; Log(value)
  %9244 = fmul fast float %9241, 0x4003333340000000
  %9245 = fmul fast float %9242, 0x4003333340000000
  %9246 = fmul fast float %9243, 0x4003333340000000
  %9247 = call float @dx.op.unary.f32(i32 21, float %9244)  ; Exp(value)
  %9248 = call float @dx.op.unary.f32(i32 21, float %9245)  ; Exp(value)
  %9249 = call float @dx.op.unary.f32(i32 21, float %9246)  ; Exp(value)
  %9250 = fsub fast float %9232, %9247
  %9251 = fsub fast float %9233, %9248
  %9252 = fsub fast float %9234, %9249
  %9253 = fmul fast float %9250, %9229
  %9254 = fmul fast float %9251, %9230
  %9255 = fmul fast float %9252, %9231
  %9256 = fadd fast float %9253, %9247
  %9257 = fadd fast float %9254, %9248
  %9258 = fadd fast float %9255, %9249
  br label %9474

; <label>:9259                                    ; preds = %9214
  %9260 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %9217, i32 %9218, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %9261 = extractvalue %dx.types.ResRet.f32 %9260, 0
  %9262 = fcmp fast ogt float %38, 5.000000e-01
  %9263 = fcmp fast olt float %9261, 1.000000e+00
  %9264 = and i1 %9262, %9263
  br i1 %9264, label %9265, label %9403

; <label>:9265                                    ; preds = %9259
  %9266 = sitofp i32 %9217 to float
  %9267 = sitofp i32 %9218 to float
  %9268 = fadd fast float %9266, 5.000000e-01
  %9269 = fadd fast float %9267, 5.000000e-01
  %9270 = fdiv fast float %9268, %45
  %9271 = fdiv fast float %9269, %46
  %9272 = fmul fast float %9270, 2.000000e+00
  %9273 = fmul fast float %9271, 2.000000e+00
  %9274 = fadd fast float %9272, -1.000000e+00
  %9275 = fsub fast float 1.000000e+00, %9273
  %9276 = fmul fast float %9274, %35
  %9277 = call float @dx.op.tertiary.f32(i32 46, float %9275, float %31, float %9276)  ; FMad(a,b,c)
  %9278 = call float @dx.op.tertiary.f32(i32 46, float %9261, float %27, float %9277)  ; FMad(a,b,c)
  %9279 = fadd fast float %9278, %23
  %9280 = call float @dx.op.unary.f32(i32 6, float %9279)  ; FAbs(value)
  %9281 = fcmp fast ogt float %9280, 0x3EB0C6F7A0000000
  br i1 %9281, label %9282, label %9403

; <label>:9282                                    ; preds = %9265
  %9283 = fmul fast float %9274, %34
  %9284 = call float @dx.op.tertiary.f32(i32 46, float %9275, float %30, float %9283)  ; FMad(a,b,c)
  %9285 = call float @dx.op.tertiary.f32(i32 46, float %9261, float %26, float %9284)  ; FMad(a,b,c)
  %9286 = fadd fast float %9285, %22
  %9287 = fmul fast float %9274, %33
  %9288 = call float @dx.op.tertiary.f32(i32 46, float %9275, float %29, float %9287)  ; FMad(a,b,c)
  %9289 = call float @dx.op.tertiary.f32(i32 46, float %9261, float %25, float %9288)  ; FMad(a,b,c)
  %9290 = fadd fast float %9289, %21
  %9291 = fmul fast float %9274, %32
  %9292 = call float @dx.op.tertiary.f32(i32 46, float %9275, float %28, float %9291)  ; FMad(a,b,c)
  %9293 = call float @dx.op.tertiary.f32(i32 46, float %9261, float %24, float %9292)  ; FMad(a,b,c)
  %9294 = fadd fast float %9293, %20
  %9295 = fdiv fast float %9294, %9279
  %9296 = fdiv fast float %9290, %9279
  %9297 = fdiv fast float %9286, %9279
  %9298 = fsub fast float %9295, %17
  %9299 = fsub fast float %9296, %18
  %9300 = fsub fast float %9297, %19
  %9301 = fmul fast float %9298, %9298
  %9302 = fmul fast float %9299, %9299
  %9303 = fadd fast float %9302, %9301
  %9304 = fmul fast float %9300, %9300
  %9305 = fadd fast float %9303, %9304
  %9306 = call float @dx.op.unary.f32(i32 24, float %9305)  ; Sqrt(value)
  %9307 = fsub fast float %9306, %9
  %9308 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %9307)  ; FMax(a,b)
  %9309 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %9309, label %9310, label %9333

; <label>:9310                                    ; preds = %9282
  %9311 = call float @dx.op.unary.f32(i32 6, float %9299)  ; FAbs(value)
  %9312 = fmul fast float %9311, %11
  %9313 = fcmp fast olt float %9312, 0x3F50624DE0000000
  br i1 %9313, label %9314, label %9317

; <label>:9314                                    ; preds = %9310
  %9315 = fmul fast float %9312, 5.000000e-01
  %9316 = fsub fast float 1.000000e+00, %9315
  br label %9322

; <label>:9317                                    ; preds = %9310
  %9318 = fmul fast float %9312, 0xBFF7154760000000
  %9319 = call float @dx.op.unary.f32(i32 21, float %9318)  ; Exp(value)
  %9320 = fsub fast float 1.000000e+00, %9319
  %9321 = fdiv fast float %9320, %9312
  br label %9322

; <label>:9322                                    ; preds = %9317, %9314
  %9323 = phi float [ %9316, %9314 ], [ %9321, %9317 ]
  %9324 = call float @dx.op.binary.f32(i32 36, float %9296, float %18)  ; FMin(a,b)
  %9325 = fsub fast float %9324, %10
  %9326 = fmul fast float %11, %9325
  %9327 = fsub fast float -0.000000e+00, %9326
  %9328 = call float @dx.op.binary.f32(i32 35, float %9327, float -4.000000e+01)  ; FMax(a,b)
  %9329 = call float @dx.op.binary.f32(i32 36, float %9328, float 5.000000e+00)  ; FMin(a,b)
  %9330 = fmul fast float %9329, 0x3FF7154760000000
  %9331 = call float @dx.op.unary.f32(i32 21, float %9330)  ; Exp(value)
  %9332 = fmul fast float %9331, %9323
  br label %9333

; <label>:9333                                    ; preds = %9322, %9282
  %9334 = phi float [ %9332, %9322 ], [ 1.000000e+00, %9282 ]
  %9335 = fmul fast float %9308, %16
  %9336 = fmul fast float %9335, %9334
  %9337 = fcmp fast ole float %9306, %9
  %9338 = fcmp fast olt float %9306, 0x3F1A36E2E0000000
  %9339 = or i1 %9337, %9338
  br i1 %9339, label %9386, label %9340

; <label>:9340                                    ; preds = %9333
  %9341 = fdiv fast float %9, %9306
  %9342 = fmul fast float %9341, %9298
  %9343 = fmul fast float %9341, %9299
  %9344 = fmul fast float %9341, %9300
  %9345 = fadd fast float %9342, %17
  %9346 = fadd fast float %9343, %18
  %9347 = fadd fast float %9344, %19
  %9348 = fadd fast float %9345, -9.000000e+02
  %9349 = fadd fast float %9346, -1.500000e+01
  %9350 = fadd fast float %9347, -7.500000e+02
  %9351 = fmul fast float %9348, 0x3F62345680000000
  %9352 = fmul fast float %9349, 0x3F62345680000000
  %9353 = fmul fast float %9350, 0x3F62345680000000
  %9354 = call float @dx.op.dot3.f32(i32 55, float %9351, float %9352, float %9353, float %9351, float %9352, float %9353)  ; Dot3(ax,ay,az,bx,by,bz)
  %9355 = fsub fast float 1.000000e+00, %9354
  %9356 = call float @dx.op.unary.f32(i32 7, float %9355)  ; Saturate(value)
  %9357 = fmul fast float %9356, %9356
  %9358 = fadd fast float %9345, %9295
  %9359 = fadd fast float %9346, %9296
  %9360 = fadd fast float %9347, %9297
  %9361 = fmul fast float %9358, 0x3F52345680000000
  %9362 = fadd fast float %9361, -2.000000e+00
  %9363 = fmul fast float %9359, 0x3F52345680000000
  %9364 = fadd fast float %9363, 0xBFA1111120000000
  %9365 = fmul fast float %9360, 0x3F52345680000000
  %9366 = fadd fast float %9365, 0xBFFAAAAAC0000000
  %9367 = call float @dx.op.dot3.f32(i32 55, float %9362, float %9364, float %9366, float %9362, float %9364, float %9366)  ; Dot3(ax,ay,az,bx,by,bz)
  %9368 = fsub fast float 1.000000e+00, %9367
  %9369 = call float @dx.op.unary.f32(i32 7, float %9368)  ; Saturate(value)
  %9370 = fmul fast float %9369, %9369
  %9371 = fmul fast float %9370, 4.000000e+00
  %9372 = fadd fast float %9371, %9357
  %9373 = fadd fast float %9295, -9.000000e+02
  %9374 = fadd fast float %9296, -1.500000e+01
  %9375 = fadd fast float %9297, -7.500000e+02
  %9376 = fmul fast float %9373, 0x3F62345680000000
  %9377 = fmul fast float %9374, 0x3F62345680000000
  %9378 = fmul fast float %9375, 0x3F62345680000000
  %9379 = call float @dx.op.dot3.f32(i32 55, float %9376, float %9377, float %9378, float %9376, float %9377, float %9378)  ; Dot3(ax,ay,az,bx,by,bz)
  %9380 = fsub fast float 1.000000e+00, %9379
  %9381 = call float @dx.op.unary.f32(i32 7, float %9380)  ; Saturate(value)
  %9382 = fmul fast float %9381, %9381
  %9383 = fadd fast float %9372, %9382
  %9384 = fmul fast float %9307, 0x3F25D867E0000000
  %9385 = fmul fast float %9384, %9383
  br label %9386

; <label>:9386                                    ; preds = %9340, %9333
  %9387 = phi float [ %9385, %9340 ], [ 0.000000e+00, %9333 ]
  %9388 = fadd fast float %9387, %9336
  %9389 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %9388)  ; FMin(a,b)
  %9390 = fmul fast float %9389, 0xBFF7154760000000
  %9391 = call float @dx.op.unary.f32(i32 21, float %9390)  ; Exp(value)
  %9392 = fsub fast float 1.000000e+00, %9391
  %9393 = call float @dx.op.binary.f32(i32 36, float %12, float %9392)  ; FMin(a,b)
  %9394 = fsub fast float %13, %9220
  %9395 = fsub fast float %14, %9221
  %9396 = fsub fast float %15, %9222
  %9397 = fmul fast float %9393, %9394
  %9398 = fmul fast float %9393, %9395
  %9399 = fmul fast float %9393, %9396
  %9400 = fadd fast float %9397, %9220
  %9401 = fadd fast float %9398, %9221
  %9402 = fadd fast float %9399, %9222
  br label %9403

; <label>:9403                                    ; preds = %9386, %9265, %9259
  %9404 = phi float [ %9400, %9386 ], [ %9220, %9265 ], [ %9220, %9259 ]
  %9405 = phi float [ %9401, %9386 ], [ %9221, %9265 ], [ %9221, %9259 ]
  %9406 = phi float [ %9402, %9386 ], [ %9222, %9265 ], [ %9222, %9259 ]
  %9407 = fadd fast float %5, 1.000000e+00
  %9408 = fadd fast float %6, 1.000000e+00
  %9409 = fsub fast float 1.000000e+00, %5
  %9410 = fmul fast float %36, %9407
  %9411 = fmul fast float %36, %9408
  %9412 = fmul fast float %36, %9409
  %9413 = fmul fast float %9410, %9404
  %9414 = fmul fast float %9411, %9405
  %9415 = fmul fast float %9412, %9406
  %9416 = fcmp fast ult float %37, 5.000000e-01
  br i1 %9416, label %9442, label %9417

; <label>:9417                                    ; preds = %9403
  %9418 = fmul fast float %9413, 0x4004147AE0000000
  %9419 = fmul fast float %9414, 0x4004147AE0000000
  %9420 = fmul fast float %9415, 0x4004147AE0000000
  %9421 = fadd fast float %9418, 0x3F9EB851E0000000
  %9422 = fadd fast float %9419, 0x3F9EB851E0000000
  %9423 = fadd fast float %9420, 0x3F9EB851E0000000
  %9424 = fmul fast float %9421, %9413
  %9425 = fmul fast float %9422, %9414
  %9426 = fmul fast float %9423, %9415
  %9427 = fmul fast float %9413, 0x400370A3E0000000
  %9428 = fmul fast float %9414, 0x400370A3E0000000
  %9429 = fmul fast float %9415, 0x400370A3E0000000
  %9430 = fadd fast float %9427, 0x3FE2E147A0000000
  %9431 = fadd fast float %9428, 0x3FE2E147A0000000
  %9432 = fadd fast float %9429, 0x3FE2E147A0000000
  %9433 = fmul fast float %9430, %9413
  %9434 = fmul fast float %9431, %9414
  %9435 = fmul fast float %9432, %9415
  %9436 = fadd fast float %9433, 0x3FC1EB8520000000
  %9437 = fadd fast float %9434, 0x3FC1EB8520000000
  %9438 = fadd fast float %9435, 0x3FC1EB8520000000
  %9439 = fdiv fast float %9424, %9436
  %9440 = fdiv fast float %9425, %9437
  %9441 = fdiv fast float %9426, %9438
  br label %9442

; <label>:9442                                    ; preds = %9417, %9403
  %9443 = phi float [ %9439, %9417 ], [ %9413, %9403 ]
  %9444 = phi float [ %9440, %9417 ], [ %9414, %9403 ]
  %9445 = phi float [ %9441, %9417 ], [ %9415, %9403 ]
  %9446 = call float @dx.op.unary.f32(i32 7, float %9443)  ; Saturate(value)
  %9447 = call float @dx.op.unary.f32(i32 7, float %9444)  ; Saturate(value)
  %9448 = call float @dx.op.unary.f32(i32 7, float %9445)  ; Saturate(value)
  %9449 = call float @dx.op.dot3.f32(i32 55, float %9446, float %9447, float %9448, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %9450 = fsub fast float %9446, %9449
  %9451 = fsub fast float %9447, %9449
  %9452 = fsub fast float %9448, %9449
  %9453 = fmul fast float %9450, %8
  %9454 = fmul fast float %9451, %8
  %9455 = fmul fast float %9452, %8
  %9456 = fadd fast float %9453, %9449
  %9457 = fadd fast float %9454, %9449
  %9458 = fadd fast float %9455, %9449
  %9459 = call float @dx.op.unary.f32(i32 7, float %9456)  ; Saturate(value)
  %9460 = call float @dx.op.unary.f32(i32 7, float %9457)  ; Saturate(value)
  %9461 = call float @dx.op.unary.f32(i32 7, float %9458)  ; Saturate(value)
  %9462 = fadd fast float %9459, 0xBFC70A3D80000000
  %9463 = fadd fast float %9460, 0xBFC70A3D80000000
  %9464 = fadd fast float %9461, 0xBFC70A3D80000000
  %9465 = fmul fast float %9462, %7
  %9466 = fmul fast float %9463, %7
  %9467 = fmul fast float %9464, %7
  %9468 = fadd fast float %9465, 0x3FC70A3D80000000
  %9469 = fadd fast float %9466, 0x3FC70A3D80000000
  %9470 = fadd fast float %9467, 0x3FC70A3D80000000
  %9471 = call float @dx.op.unary.f32(i32 7, float %9468)  ; Saturate(value)
  %9472 = call float @dx.op.unary.f32(i32 7, float %9469)  ; Saturate(value)
  %9473 = call float @dx.op.unary.f32(i32 7, float %9470)  ; Saturate(value)
  br label %9474

; <label>:9474                                    ; preds = %9442, %9225
  %9475 = phi float [ %9256, %9225 ], [ %9471, %9442 ]
  %9476 = phi float [ %9257, %9225 ], [ %9472, %9442 ]
  %9477 = phi float [ %9258, %9225 ], [ %9473, %9442 ]
  %9478 = fsub fast float %9475, %8907
  %9479 = fsub fast float %9476, %8908
  %9480 = fsub fast float %9477, %8909
  %9481 = fmul fast float %9478, %9212
  %9482 = fmul fast float %9479, %9212
  %9483 = fmul fast float %9480, %9212
  %9484 = fadd fast float %9481, %8907
  %9485 = fadd fast float %9482, %8908
  %9486 = fadd fast float %9483, %8909
  br label %9487

; <label>:9487                                    ; preds = %9474, %9199
  %9488 = phi float [ %9484, %9474 ], [ %8907, %9199 ]
  %9489 = phi float [ %9485, %9474 ], [ %8908, %9199 ]
  %9490 = phi float [ %9486, %9474 ], [ %8909, %9199 ]
  %9491 = add i32 %67, -1
  %9492 = call i32 @dx.op.binary.i32(i32 37, i32 %9491, i32 0)  ; IMax(a,b)
  %9493 = call i32 @dx.op.binary.i32(i32 37, i32 %70, i32 0)  ; IMax(a,b)
  %9494 = call i32 @dx.op.binary.i32(i32 38, i32 %9492, i32 %59)  ; IMin(a,b)
  %9495 = call i32 @dx.op.binary.i32(i32 38, i32 %9493, i32 %60)  ; IMin(a,b)
  %9496 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %9494, i32 %9495, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %9497 = extractvalue %dx.types.ResRet.f32 %9496, 0
  %9498 = fsub fast float %9497, %88
  %9499 = call float @dx.op.unary.f32(i32 6, float %9498)  ; FAbs(value)
  %9500 = fdiv fast float %9499, %8919
  %9501 = fsub fast float 1.000000e+00, %9500
  %9502 = call float @dx.op.unary.f32(i32 7, float %9501)  ; Saturate(value)
  %9503 = fcmp fast ugt float %9502, 0.000000e+00
  br i1 %9503, label %9504, label %9777

; <label>:9504                                    ; preds = %9487
  %9505 = call i32 @dx.op.binary.i32(i32 37, i32 %9494, i32 0)  ; IMax(a,b)
  %9506 = call i32 @dx.op.binary.i32(i32 37, i32 %9495, i32 0)  ; IMax(a,b)
  %9507 = call i32 @dx.op.binary.i32(i32 38, i32 %9505, i32 %59)  ; IMin(a,b)
  %9508 = call i32 @dx.op.binary.i32(i32 38, i32 %9506, i32 %60)  ; IMin(a,b)
  %9509 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %9507, i32 %9508, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %9510 = extractvalue %dx.types.ResRet.f32 %9509, 0
  %9511 = extractvalue %dx.types.ResRet.f32 %9509, 1
  %9512 = extractvalue %dx.types.ResRet.f32 %9509, 2
  %9513 = extractvalue %dx.types.ResRet.f32 %9509, 3
  %9514 = fcmp fast olt float %9513, 0.000000e+00
  br i1 %9514, label %9515, label %9549

; <label>:9515                                    ; preds = %9504
  %9516 = fcmp fast ogt float %9510, 0x3FA4B5DCC0000000
  %9517 = fcmp fast ogt float %9511, 0x3FA4B5DCC0000000
  %9518 = fcmp fast ogt float %9512, 0x3FA4B5DCC0000000
  %9519 = select i1 %9516, float 0.000000e+00, float 1.000000e+00
  %9520 = select i1 %9517, float 0.000000e+00, float 1.000000e+00
  %9521 = select i1 %9518, float 0.000000e+00, float 1.000000e+00
  %9522 = fmul fast float %9510, 0x3FB3D07220000000
  %9523 = fmul fast float %9511, 0x3FB3D07220000000
  %9524 = fmul fast float %9512, 0x3FB3D07220000000
  %9525 = fadd fast float %9510, 0x3FAC28F5C0000000
  %9526 = fadd fast float %9511, 0x3FAC28F5C0000000
  %9527 = fadd fast float %9512, 0x3FAC28F5C0000000
  %9528 = fmul fast float %9525, 0x3FEE54EDE0000000
  %9529 = fmul fast float %9526, 0x3FEE54EDE0000000
  %9530 = fmul fast float %9527, 0x3FEE54EDE0000000
  %9531 = call float @dx.op.unary.f32(i32 23, float %9528)  ; Log(value)
  %9532 = call float @dx.op.unary.f32(i32 23, float %9529)  ; Log(value)
  %9533 = call float @dx.op.unary.f32(i32 23, float %9530)  ; Log(value)
  %9534 = fmul fast float %9531, 0x4003333340000000
  %9535 = fmul fast float %9532, 0x4003333340000000
  %9536 = fmul fast float %9533, 0x4003333340000000
  %9537 = call float @dx.op.unary.f32(i32 21, float %9534)  ; Exp(value)
  %9538 = call float @dx.op.unary.f32(i32 21, float %9535)  ; Exp(value)
  %9539 = call float @dx.op.unary.f32(i32 21, float %9536)  ; Exp(value)
  %9540 = fsub fast float %9522, %9537
  %9541 = fsub fast float %9523, %9538
  %9542 = fsub fast float %9524, %9539
  %9543 = fmul fast float %9540, %9519
  %9544 = fmul fast float %9541, %9520
  %9545 = fmul fast float %9542, %9521
  %9546 = fadd fast float %9543, %9537
  %9547 = fadd fast float %9544, %9538
  %9548 = fadd fast float %9545, %9539
  br label %9764

; <label>:9549                                    ; preds = %9504
  %9550 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %9507, i32 %9508, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %9551 = extractvalue %dx.types.ResRet.f32 %9550, 0
  %9552 = fcmp fast ogt float %38, 5.000000e-01
  %9553 = fcmp fast olt float %9551, 1.000000e+00
  %9554 = and i1 %9552, %9553
  br i1 %9554, label %9555, label %9693

; <label>:9555                                    ; preds = %9549
  %9556 = sitofp i32 %9507 to float
  %9557 = sitofp i32 %9508 to float
  %9558 = fadd fast float %9556, 5.000000e-01
  %9559 = fadd fast float %9557, 5.000000e-01
  %9560 = fdiv fast float %9558, %45
  %9561 = fdiv fast float %9559, %46
  %9562 = fmul fast float %9560, 2.000000e+00
  %9563 = fmul fast float %9561, 2.000000e+00
  %9564 = fadd fast float %9562, -1.000000e+00
  %9565 = fsub fast float 1.000000e+00, %9563
  %9566 = fmul fast float %9564, %35
  %9567 = call float @dx.op.tertiary.f32(i32 46, float %9565, float %31, float %9566)  ; FMad(a,b,c)
  %9568 = call float @dx.op.tertiary.f32(i32 46, float %9551, float %27, float %9567)  ; FMad(a,b,c)
  %9569 = fadd fast float %9568, %23
  %9570 = call float @dx.op.unary.f32(i32 6, float %9569)  ; FAbs(value)
  %9571 = fcmp fast ogt float %9570, 0x3EB0C6F7A0000000
  br i1 %9571, label %9572, label %9693

; <label>:9572                                    ; preds = %9555
  %9573 = fmul fast float %9564, %34
  %9574 = call float @dx.op.tertiary.f32(i32 46, float %9565, float %30, float %9573)  ; FMad(a,b,c)
  %9575 = call float @dx.op.tertiary.f32(i32 46, float %9551, float %26, float %9574)  ; FMad(a,b,c)
  %9576 = fadd fast float %9575, %22
  %9577 = fmul fast float %9564, %33
  %9578 = call float @dx.op.tertiary.f32(i32 46, float %9565, float %29, float %9577)  ; FMad(a,b,c)
  %9579 = call float @dx.op.tertiary.f32(i32 46, float %9551, float %25, float %9578)  ; FMad(a,b,c)
  %9580 = fadd fast float %9579, %21
  %9581 = fmul fast float %9564, %32
  %9582 = call float @dx.op.tertiary.f32(i32 46, float %9565, float %28, float %9581)  ; FMad(a,b,c)
  %9583 = call float @dx.op.tertiary.f32(i32 46, float %9551, float %24, float %9582)  ; FMad(a,b,c)
  %9584 = fadd fast float %9583, %20
  %9585 = fdiv fast float %9584, %9569
  %9586 = fdiv fast float %9580, %9569
  %9587 = fdiv fast float %9576, %9569
  %9588 = fsub fast float %9585, %17
  %9589 = fsub fast float %9586, %18
  %9590 = fsub fast float %9587, %19
  %9591 = fmul fast float %9588, %9588
  %9592 = fmul fast float %9589, %9589
  %9593 = fadd fast float %9592, %9591
  %9594 = fmul fast float %9590, %9590
  %9595 = fadd fast float %9593, %9594
  %9596 = call float @dx.op.unary.f32(i32 24, float %9595)  ; Sqrt(value)
  %9597 = fsub fast float %9596, %9
  %9598 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %9597)  ; FMax(a,b)
  %9599 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %9599, label %9600, label %9623

; <label>:9600                                    ; preds = %9572
  %9601 = call float @dx.op.unary.f32(i32 6, float %9589)  ; FAbs(value)
  %9602 = fmul fast float %9601, %11
  %9603 = fcmp fast olt float %9602, 0x3F50624DE0000000
  br i1 %9603, label %9604, label %9607

; <label>:9604                                    ; preds = %9600
  %9605 = fmul fast float %9602, 5.000000e-01
  %9606 = fsub fast float 1.000000e+00, %9605
  br label %9612

; <label>:9607                                    ; preds = %9600
  %9608 = fmul fast float %9602, 0xBFF7154760000000
  %9609 = call float @dx.op.unary.f32(i32 21, float %9608)  ; Exp(value)
  %9610 = fsub fast float 1.000000e+00, %9609
  %9611 = fdiv fast float %9610, %9602
  br label %9612

; <label>:9612                                    ; preds = %9607, %9604
  %9613 = phi float [ %9606, %9604 ], [ %9611, %9607 ]
  %9614 = call float @dx.op.binary.f32(i32 36, float %9586, float %18)  ; FMin(a,b)
  %9615 = fsub fast float %9614, %10
  %9616 = fmul fast float %11, %9615
  %9617 = fsub fast float -0.000000e+00, %9616
  %9618 = call float @dx.op.binary.f32(i32 35, float %9617, float -4.000000e+01)  ; FMax(a,b)
  %9619 = call float @dx.op.binary.f32(i32 36, float %9618, float 5.000000e+00)  ; FMin(a,b)
  %9620 = fmul fast float %9619, 0x3FF7154760000000
  %9621 = call float @dx.op.unary.f32(i32 21, float %9620)  ; Exp(value)
  %9622 = fmul fast float %9621, %9613
  br label %9623

; <label>:9623                                    ; preds = %9612, %9572
  %9624 = phi float [ %9622, %9612 ], [ 1.000000e+00, %9572 ]
  %9625 = fmul fast float %9598, %16
  %9626 = fmul fast float %9625, %9624
  %9627 = fcmp fast ole float %9596, %9
  %9628 = fcmp fast olt float %9596, 0x3F1A36E2E0000000
  %9629 = or i1 %9627, %9628
  br i1 %9629, label %9676, label %9630

; <label>:9630                                    ; preds = %9623
  %9631 = fdiv fast float %9, %9596
  %9632 = fmul fast float %9631, %9588
  %9633 = fmul fast float %9631, %9589
  %9634 = fmul fast float %9631, %9590
  %9635 = fadd fast float %9632, %17
  %9636 = fadd fast float %9633, %18
  %9637 = fadd fast float %9634, %19
  %9638 = fadd fast float %9635, -9.000000e+02
  %9639 = fadd fast float %9636, -1.500000e+01
  %9640 = fadd fast float %9637, -7.500000e+02
  %9641 = fmul fast float %9638, 0x3F62345680000000
  %9642 = fmul fast float %9639, 0x3F62345680000000
  %9643 = fmul fast float %9640, 0x3F62345680000000
  %9644 = call float @dx.op.dot3.f32(i32 55, float %9641, float %9642, float %9643, float %9641, float %9642, float %9643)  ; Dot3(ax,ay,az,bx,by,bz)
  %9645 = fsub fast float 1.000000e+00, %9644
  %9646 = call float @dx.op.unary.f32(i32 7, float %9645)  ; Saturate(value)
  %9647 = fmul fast float %9646, %9646
  %9648 = fadd fast float %9635, %9585
  %9649 = fadd fast float %9636, %9586
  %9650 = fadd fast float %9637, %9587
  %9651 = fmul fast float %9648, 0x3F52345680000000
  %9652 = fadd fast float %9651, -2.000000e+00
  %9653 = fmul fast float %9649, 0x3F52345680000000
  %9654 = fadd fast float %9653, 0xBFA1111120000000
  %9655 = fmul fast float %9650, 0x3F52345680000000
  %9656 = fadd fast float %9655, 0xBFFAAAAAC0000000
  %9657 = call float @dx.op.dot3.f32(i32 55, float %9652, float %9654, float %9656, float %9652, float %9654, float %9656)  ; Dot3(ax,ay,az,bx,by,bz)
  %9658 = fsub fast float 1.000000e+00, %9657
  %9659 = call float @dx.op.unary.f32(i32 7, float %9658)  ; Saturate(value)
  %9660 = fmul fast float %9659, %9659
  %9661 = fmul fast float %9660, 4.000000e+00
  %9662 = fadd fast float %9661, %9647
  %9663 = fadd fast float %9585, -9.000000e+02
  %9664 = fadd fast float %9586, -1.500000e+01
  %9665 = fadd fast float %9587, -7.500000e+02
  %9666 = fmul fast float %9663, 0x3F62345680000000
  %9667 = fmul fast float %9664, 0x3F62345680000000
  %9668 = fmul fast float %9665, 0x3F62345680000000
  %9669 = call float @dx.op.dot3.f32(i32 55, float %9666, float %9667, float %9668, float %9666, float %9667, float %9668)  ; Dot3(ax,ay,az,bx,by,bz)
  %9670 = fsub fast float 1.000000e+00, %9669
  %9671 = call float @dx.op.unary.f32(i32 7, float %9670)  ; Saturate(value)
  %9672 = fmul fast float %9671, %9671
  %9673 = fadd fast float %9662, %9672
  %9674 = fmul fast float %9597, 0x3F25D867E0000000
  %9675 = fmul fast float %9674, %9673
  br label %9676

; <label>:9676                                    ; preds = %9630, %9623
  %9677 = phi float [ %9675, %9630 ], [ 0.000000e+00, %9623 ]
  %9678 = fadd fast float %9677, %9626
  %9679 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %9678)  ; FMin(a,b)
  %9680 = fmul fast float %9679, 0xBFF7154760000000
  %9681 = call float @dx.op.unary.f32(i32 21, float %9680)  ; Exp(value)
  %9682 = fsub fast float 1.000000e+00, %9681
  %9683 = call float @dx.op.binary.f32(i32 36, float %12, float %9682)  ; FMin(a,b)
  %9684 = fsub fast float %13, %9510
  %9685 = fsub fast float %14, %9511
  %9686 = fsub fast float %15, %9512
  %9687 = fmul fast float %9683, %9684
  %9688 = fmul fast float %9683, %9685
  %9689 = fmul fast float %9683, %9686
  %9690 = fadd fast float %9687, %9510
  %9691 = fadd fast float %9688, %9511
  %9692 = fadd fast float %9689, %9512
  br label %9693

; <label>:9693                                    ; preds = %9676, %9555, %9549
  %9694 = phi float [ %9690, %9676 ], [ %9510, %9555 ], [ %9510, %9549 ]
  %9695 = phi float [ %9691, %9676 ], [ %9511, %9555 ], [ %9511, %9549 ]
  %9696 = phi float [ %9692, %9676 ], [ %9512, %9555 ], [ %9512, %9549 ]
  %9697 = fadd fast float %5, 1.000000e+00
  %9698 = fadd fast float %6, 1.000000e+00
  %9699 = fsub fast float 1.000000e+00, %5
  %9700 = fmul fast float %36, %9697
  %9701 = fmul fast float %36, %9698
  %9702 = fmul fast float %36, %9699
  %9703 = fmul fast float %9700, %9694
  %9704 = fmul fast float %9701, %9695
  %9705 = fmul fast float %9702, %9696
  %9706 = fcmp fast ult float %37, 5.000000e-01
  br i1 %9706, label %9732, label %9707

; <label>:9707                                    ; preds = %9693
  %9708 = fmul fast float %9703, 0x4004147AE0000000
  %9709 = fmul fast float %9704, 0x4004147AE0000000
  %9710 = fmul fast float %9705, 0x4004147AE0000000
  %9711 = fadd fast float %9708, 0x3F9EB851E0000000
  %9712 = fadd fast float %9709, 0x3F9EB851E0000000
  %9713 = fadd fast float %9710, 0x3F9EB851E0000000
  %9714 = fmul fast float %9711, %9703
  %9715 = fmul fast float %9712, %9704
  %9716 = fmul fast float %9713, %9705
  %9717 = fmul fast float %9703, 0x400370A3E0000000
  %9718 = fmul fast float %9704, 0x400370A3E0000000
  %9719 = fmul fast float %9705, 0x400370A3E0000000
  %9720 = fadd fast float %9717, 0x3FE2E147A0000000
  %9721 = fadd fast float %9718, 0x3FE2E147A0000000
  %9722 = fadd fast float %9719, 0x3FE2E147A0000000
  %9723 = fmul fast float %9720, %9703
  %9724 = fmul fast float %9721, %9704
  %9725 = fmul fast float %9722, %9705
  %9726 = fadd fast float %9723, 0x3FC1EB8520000000
  %9727 = fadd fast float %9724, 0x3FC1EB8520000000
  %9728 = fadd fast float %9725, 0x3FC1EB8520000000
  %9729 = fdiv fast float %9714, %9726
  %9730 = fdiv fast float %9715, %9727
  %9731 = fdiv fast float %9716, %9728
  br label %9732

; <label>:9732                                    ; preds = %9707, %9693
  %9733 = phi float [ %9729, %9707 ], [ %9703, %9693 ]
  %9734 = phi float [ %9730, %9707 ], [ %9704, %9693 ]
  %9735 = phi float [ %9731, %9707 ], [ %9705, %9693 ]
  %9736 = call float @dx.op.unary.f32(i32 7, float %9733)  ; Saturate(value)
  %9737 = call float @dx.op.unary.f32(i32 7, float %9734)  ; Saturate(value)
  %9738 = call float @dx.op.unary.f32(i32 7, float %9735)  ; Saturate(value)
  %9739 = call float @dx.op.dot3.f32(i32 55, float %9736, float %9737, float %9738, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %9740 = fsub fast float %9736, %9739
  %9741 = fsub fast float %9737, %9739
  %9742 = fsub fast float %9738, %9739
  %9743 = fmul fast float %9740, %8
  %9744 = fmul fast float %9741, %8
  %9745 = fmul fast float %9742, %8
  %9746 = fadd fast float %9743, %9739
  %9747 = fadd fast float %9744, %9739
  %9748 = fadd fast float %9745, %9739
  %9749 = call float @dx.op.unary.f32(i32 7, float %9746)  ; Saturate(value)
  %9750 = call float @dx.op.unary.f32(i32 7, float %9747)  ; Saturate(value)
  %9751 = call float @dx.op.unary.f32(i32 7, float %9748)  ; Saturate(value)
  %9752 = fadd fast float %9749, 0xBFC70A3D80000000
  %9753 = fadd fast float %9750, 0xBFC70A3D80000000
  %9754 = fadd fast float %9751, 0xBFC70A3D80000000
  %9755 = fmul fast float %9752, %7
  %9756 = fmul fast float %9753, %7
  %9757 = fmul fast float %9754, %7
  %9758 = fadd fast float %9755, 0x3FC70A3D80000000
  %9759 = fadd fast float %9756, 0x3FC70A3D80000000
  %9760 = fadd fast float %9757, 0x3FC70A3D80000000
  %9761 = call float @dx.op.unary.f32(i32 7, float %9758)  ; Saturate(value)
  %9762 = call float @dx.op.unary.f32(i32 7, float %9759)  ; Saturate(value)
  %9763 = call float @dx.op.unary.f32(i32 7, float %9760)  ; Saturate(value)
  br label %9764

; <label>:9764                                    ; preds = %9732, %9515
  %9765 = phi float [ %9546, %9515 ], [ %9761, %9732 ]
  %9766 = phi float [ %9547, %9515 ], [ %9762, %9732 ]
  %9767 = phi float [ %9548, %9515 ], [ %9763, %9732 ]
  %9768 = fsub fast float %9765, %8907
  %9769 = fsub fast float %9766, %8908
  %9770 = fsub fast float %9767, %8909
  %9771 = fmul fast float %9768, %9502
  %9772 = fmul fast float %9769, %9502
  %9773 = fmul fast float %9770, %9502
  %9774 = fadd fast float %9771, %8907
  %9775 = fadd fast float %9772, %8908
  %9776 = fadd fast float %9773, %8909
  br label %9777

; <label>:9777                                    ; preds = %9764, %9487
  %9778 = phi float [ %9774, %9764 ], [ %8907, %9487 ]
  %9779 = phi float [ %9775, %9764 ], [ %8908, %9487 ]
  %9780 = phi float [ %9776, %9764 ], [ %8909, %9487 ]
  %9781 = add i32 %67, 1
  %9782 = call i32 @dx.op.binary.i32(i32 37, i32 %9781, i32 0)  ; IMax(a,b)
  %9783 = call i32 @dx.op.binary.i32(i32 38, i32 %9782, i32 %59)  ; IMin(a,b)
  %9784 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %9783, i32 %9495, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %9785 = extractvalue %dx.types.ResRet.f32 %9784, 0
  %9786 = fsub fast float %9785, %88
  %9787 = call float @dx.op.unary.f32(i32 6, float %9786)  ; FAbs(value)
  %9788 = fdiv fast float %9787, %8919
  %9789 = fsub fast float 1.000000e+00, %9788
  %9790 = call float @dx.op.unary.f32(i32 7, float %9789)  ; Saturate(value)
  %9791 = fcmp fast ugt float %9790, 0.000000e+00
  br i1 %9791, label %9792, label %10065

; <label>:9792                                    ; preds = %9777
  %9793 = call i32 @dx.op.binary.i32(i32 37, i32 %9783, i32 0)  ; IMax(a,b)
  %9794 = call i32 @dx.op.binary.i32(i32 37, i32 %9495, i32 0)  ; IMax(a,b)
  %9795 = call i32 @dx.op.binary.i32(i32 38, i32 %9793, i32 %59)  ; IMin(a,b)
  %9796 = call i32 @dx.op.binary.i32(i32 38, i32 %9794, i32 %60)  ; IMin(a,b)
  %9797 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %9795, i32 %9796, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %9798 = extractvalue %dx.types.ResRet.f32 %9797, 0
  %9799 = extractvalue %dx.types.ResRet.f32 %9797, 1
  %9800 = extractvalue %dx.types.ResRet.f32 %9797, 2
  %9801 = extractvalue %dx.types.ResRet.f32 %9797, 3
  %9802 = fcmp fast olt float %9801, 0.000000e+00
  br i1 %9802, label %9803, label %9837

; <label>:9803                                    ; preds = %9792
  %9804 = fcmp fast ogt float %9798, 0x3FA4B5DCC0000000
  %9805 = fcmp fast ogt float %9799, 0x3FA4B5DCC0000000
  %9806 = fcmp fast ogt float %9800, 0x3FA4B5DCC0000000
  %9807 = select i1 %9804, float 0.000000e+00, float 1.000000e+00
  %9808 = select i1 %9805, float 0.000000e+00, float 1.000000e+00
  %9809 = select i1 %9806, float 0.000000e+00, float 1.000000e+00
  %9810 = fmul fast float %9798, 0x3FB3D07220000000
  %9811 = fmul fast float %9799, 0x3FB3D07220000000
  %9812 = fmul fast float %9800, 0x3FB3D07220000000
  %9813 = fadd fast float %9798, 0x3FAC28F5C0000000
  %9814 = fadd fast float %9799, 0x3FAC28F5C0000000
  %9815 = fadd fast float %9800, 0x3FAC28F5C0000000
  %9816 = fmul fast float %9813, 0x3FEE54EDE0000000
  %9817 = fmul fast float %9814, 0x3FEE54EDE0000000
  %9818 = fmul fast float %9815, 0x3FEE54EDE0000000
  %9819 = call float @dx.op.unary.f32(i32 23, float %9816)  ; Log(value)
  %9820 = call float @dx.op.unary.f32(i32 23, float %9817)  ; Log(value)
  %9821 = call float @dx.op.unary.f32(i32 23, float %9818)  ; Log(value)
  %9822 = fmul fast float %9819, 0x4003333340000000
  %9823 = fmul fast float %9820, 0x4003333340000000
  %9824 = fmul fast float %9821, 0x4003333340000000
  %9825 = call float @dx.op.unary.f32(i32 21, float %9822)  ; Exp(value)
  %9826 = call float @dx.op.unary.f32(i32 21, float %9823)  ; Exp(value)
  %9827 = call float @dx.op.unary.f32(i32 21, float %9824)  ; Exp(value)
  %9828 = fsub fast float %9810, %9825
  %9829 = fsub fast float %9811, %9826
  %9830 = fsub fast float %9812, %9827
  %9831 = fmul fast float %9828, %9807
  %9832 = fmul fast float %9829, %9808
  %9833 = fmul fast float %9830, %9809
  %9834 = fadd fast float %9831, %9825
  %9835 = fadd fast float %9832, %9826
  %9836 = fadd fast float %9833, %9827
  br label %10052

; <label>:9837                                    ; preds = %9792
  %9838 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %9795, i32 %9796, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %9839 = extractvalue %dx.types.ResRet.f32 %9838, 0
  %9840 = fcmp fast ogt float %38, 5.000000e-01
  %9841 = fcmp fast olt float %9839, 1.000000e+00
  %9842 = and i1 %9840, %9841
  br i1 %9842, label %9843, label %9981

; <label>:9843                                    ; preds = %9837
  %9844 = sitofp i32 %9795 to float
  %9845 = sitofp i32 %9796 to float
  %9846 = fadd fast float %9844, 5.000000e-01
  %9847 = fadd fast float %9845, 5.000000e-01
  %9848 = fdiv fast float %9846, %45
  %9849 = fdiv fast float %9847, %46
  %9850 = fmul fast float %9848, 2.000000e+00
  %9851 = fmul fast float %9849, 2.000000e+00
  %9852 = fadd fast float %9850, -1.000000e+00
  %9853 = fsub fast float 1.000000e+00, %9851
  %9854 = fmul fast float %9852, %35
  %9855 = call float @dx.op.tertiary.f32(i32 46, float %9853, float %31, float %9854)  ; FMad(a,b,c)
  %9856 = call float @dx.op.tertiary.f32(i32 46, float %9839, float %27, float %9855)  ; FMad(a,b,c)
  %9857 = fadd fast float %9856, %23
  %9858 = call float @dx.op.unary.f32(i32 6, float %9857)  ; FAbs(value)
  %9859 = fcmp fast ogt float %9858, 0x3EB0C6F7A0000000
  br i1 %9859, label %9860, label %9981

; <label>:9860                                    ; preds = %9843
  %9861 = fmul fast float %9852, %34
  %9862 = call float @dx.op.tertiary.f32(i32 46, float %9853, float %30, float %9861)  ; FMad(a,b,c)
  %9863 = call float @dx.op.tertiary.f32(i32 46, float %9839, float %26, float %9862)  ; FMad(a,b,c)
  %9864 = fadd fast float %9863, %22
  %9865 = fmul fast float %9852, %33
  %9866 = call float @dx.op.tertiary.f32(i32 46, float %9853, float %29, float %9865)  ; FMad(a,b,c)
  %9867 = call float @dx.op.tertiary.f32(i32 46, float %9839, float %25, float %9866)  ; FMad(a,b,c)
  %9868 = fadd fast float %9867, %21
  %9869 = fmul fast float %9852, %32
  %9870 = call float @dx.op.tertiary.f32(i32 46, float %9853, float %28, float %9869)  ; FMad(a,b,c)
  %9871 = call float @dx.op.tertiary.f32(i32 46, float %9839, float %24, float %9870)  ; FMad(a,b,c)
  %9872 = fadd fast float %9871, %20
  %9873 = fdiv fast float %9872, %9857
  %9874 = fdiv fast float %9868, %9857
  %9875 = fdiv fast float %9864, %9857
  %9876 = fsub fast float %9873, %17
  %9877 = fsub fast float %9874, %18
  %9878 = fsub fast float %9875, %19
  %9879 = fmul fast float %9876, %9876
  %9880 = fmul fast float %9877, %9877
  %9881 = fadd fast float %9880, %9879
  %9882 = fmul fast float %9878, %9878
  %9883 = fadd fast float %9881, %9882
  %9884 = call float @dx.op.unary.f32(i32 24, float %9883)  ; Sqrt(value)
  %9885 = fsub fast float %9884, %9
  %9886 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %9885)  ; FMax(a,b)
  %9887 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %9887, label %9888, label %9911

; <label>:9888                                    ; preds = %9860
  %9889 = call float @dx.op.unary.f32(i32 6, float %9877)  ; FAbs(value)
  %9890 = fmul fast float %9889, %11
  %9891 = fcmp fast olt float %9890, 0x3F50624DE0000000
  br i1 %9891, label %9892, label %9895

; <label>:9892                                    ; preds = %9888
  %9893 = fmul fast float %9890, 5.000000e-01
  %9894 = fsub fast float 1.000000e+00, %9893
  br label %9900

; <label>:9895                                    ; preds = %9888
  %9896 = fmul fast float %9890, 0xBFF7154760000000
  %9897 = call float @dx.op.unary.f32(i32 21, float %9896)  ; Exp(value)
  %9898 = fsub fast float 1.000000e+00, %9897
  %9899 = fdiv fast float %9898, %9890
  br label %9900

; <label>:9900                                    ; preds = %9895, %9892
  %9901 = phi float [ %9894, %9892 ], [ %9899, %9895 ]
  %9902 = call float @dx.op.binary.f32(i32 36, float %9874, float %18)  ; FMin(a,b)
  %9903 = fsub fast float %9902, %10
  %9904 = fmul fast float %11, %9903
  %9905 = fsub fast float -0.000000e+00, %9904
  %9906 = call float @dx.op.binary.f32(i32 35, float %9905, float -4.000000e+01)  ; FMax(a,b)
  %9907 = call float @dx.op.binary.f32(i32 36, float %9906, float 5.000000e+00)  ; FMin(a,b)
  %9908 = fmul fast float %9907, 0x3FF7154760000000
  %9909 = call float @dx.op.unary.f32(i32 21, float %9908)  ; Exp(value)
  %9910 = fmul fast float %9909, %9901
  br label %9911

; <label>:9911                                    ; preds = %9900, %9860
  %9912 = phi float [ %9910, %9900 ], [ 1.000000e+00, %9860 ]
  %9913 = fmul fast float %9886, %16
  %9914 = fmul fast float %9913, %9912
  %9915 = fcmp fast ole float %9884, %9
  %9916 = fcmp fast olt float %9884, 0x3F1A36E2E0000000
  %9917 = or i1 %9915, %9916
  br i1 %9917, label %9964, label %9918

; <label>:9918                                    ; preds = %9911
  %9919 = fdiv fast float %9, %9884
  %9920 = fmul fast float %9919, %9876
  %9921 = fmul fast float %9919, %9877
  %9922 = fmul fast float %9919, %9878
  %9923 = fadd fast float %9920, %17
  %9924 = fadd fast float %9921, %18
  %9925 = fadd fast float %9922, %19
  %9926 = fadd fast float %9923, -9.000000e+02
  %9927 = fadd fast float %9924, -1.500000e+01
  %9928 = fadd fast float %9925, -7.500000e+02
  %9929 = fmul fast float %9926, 0x3F62345680000000
  %9930 = fmul fast float %9927, 0x3F62345680000000
  %9931 = fmul fast float %9928, 0x3F62345680000000
  %9932 = call float @dx.op.dot3.f32(i32 55, float %9929, float %9930, float %9931, float %9929, float %9930, float %9931)  ; Dot3(ax,ay,az,bx,by,bz)
  %9933 = fsub fast float 1.000000e+00, %9932
  %9934 = call float @dx.op.unary.f32(i32 7, float %9933)  ; Saturate(value)
  %9935 = fmul fast float %9934, %9934
  %9936 = fadd fast float %9923, %9873
  %9937 = fadd fast float %9924, %9874
  %9938 = fadd fast float %9925, %9875
  %9939 = fmul fast float %9936, 0x3F52345680000000
  %9940 = fadd fast float %9939, -2.000000e+00
  %9941 = fmul fast float %9937, 0x3F52345680000000
  %9942 = fadd fast float %9941, 0xBFA1111120000000
  %9943 = fmul fast float %9938, 0x3F52345680000000
  %9944 = fadd fast float %9943, 0xBFFAAAAAC0000000
  %9945 = call float @dx.op.dot3.f32(i32 55, float %9940, float %9942, float %9944, float %9940, float %9942, float %9944)  ; Dot3(ax,ay,az,bx,by,bz)
  %9946 = fsub fast float 1.000000e+00, %9945
  %9947 = call float @dx.op.unary.f32(i32 7, float %9946)  ; Saturate(value)
  %9948 = fmul fast float %9947, %9947
  %9949 = fmul fast float %9948, 4.000000e+00
  %9950 = fadd fast float %9949, %9935
  %9951 = fadd fast float %9873, -9.000000e+02
  %9952 = fadd fast float %9874, -1.500000e+01
  %9953 = fadd fast float %9875, -7.500000e+02
  %9954 = fmul fast float %9951, 0x3F62345680000000
  %9955 = fmul fast float %9952, 0x3F62345680000000
  %9956 = fmul fast float %9953, 0x3F62345680000000
  %9957 = call float @dx.op.dot3.f32(i32 55, float %9954, float %9955, float %9956, float %9954, float %9955, float %9956)  ; Dot3(ax,ay,az,bx,by,bz)
  %9958 = fsub fast float 1.000000e+00, %9957
  %9959 = call float @dx.op.unary.f32(i32 7, float %9958)  ; Saturate(value)
  %9960 = fmul fast float %9959, %9959
  %9961 = fadd fast float %9950, %9960
  %9962 = fmul fast float %9885, 0x3F25D867E0000000
  %9963 = fmul fast float %9962, %9961
  br label %9964

; <label>:9964                                    ; preds = %9918, %9911
  %9965 = phi float [ %9963, %9918 ], [ 0.000000e+00, %9911 ]
  %9966 = fadd fast float %9965, %9914
  %9967 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %9966)  ; FMin(a,b)
  %9968 = fmul fast float %9967, 0xBFF7154760000000
  %9969 = call float @dx.op.unary.f32(i32 21, float %9968)  ; Exp(value)
  %9970 = fsub fast float 1.000000e+00, %9969
  %9971 = call float @dx.op.binary.f32(i32 36, float %12, float %9970)  ; FMin(a,b)
  %9972 = fsub fast float %13, %9798
  %9973 = fsub fast float %14, %9799
  %9974 = fsub fast float %15, %9800
  %9975 = fmul fast float %9971, %9972
  %9976 = fmul fast float %9971, %9973
  %9977 = fmul fast float %9971, %9974
  %9978 = fadd fast float %9975, %9798
  %9979 = fadd fast float %9976, %9799
  %9980 = fadd fast float %9977, %9800
  br label %9981

; <label>:9981                                    ; preds = %9964, %9843, %9837
  %9982 = phi float [ %9978, %9964 ], [ %9798, %9843 ], [ %9798, %9837 ]
  %9983 = phi float [ %9979, %9964 ], [ %9799, %9843 ], [ %9799, %9837 ]
  %9984 = phi float [ %9980, %9964 ], [ %9800, %9843 ], [ %9800, %9837 ]
  %9985 = fadd fast float %5, 1.000000e+00
  %9986 = fadd fast float %6, 1.000000e+00
  %9987 = fsub fast float 1.000000e+00, %5
  %9988 = fmul fast float %36, %9985
  %9989 = fmul fast float %36, %9986
  %9990 = fmul fast float %36, %9987
  %9991 = fmul fast float %9988, %9982
  %9992 = fmul fast float %9989, %9983
  %9993 = fmul fast float %9990, %9984
  %9994 = fcmp fast ult float %37, 5.000000e-01
  br i1 %9994, label %10020, label %9995

; <label>:9995                                    ; preds = %9981
  %9996 = fmul fast float %9991, 0x4004147AE0000000
  %9997 = fmul fast float %9992, 0x4004147AE0000000
  %9998 = fmul fast float %9993, 0x4004147AE0000000
  %9999 = fadd fast float %9996, 0x3F9EB851E0000000
  %10000 = fadd fast float %9997, 0x3F9EB851E0000000
  %10001 = fadd fast float %9998, 0x3F9EB851E0000000
  %10002 = fmul fast float %9999, %9991
  %10003 = fmul fast float %10000, %9992
  %10004 = fmul fast float %10001, %9993
  %10005 = fmul fast float %9991, 0x400370A3E0000000
  %10006 = fmul fast float %9992, 0x400370A3E0000000
  %10007 = fmul fast float %9993, 0x400370A3E0000000
  %10008 = fadd fast float %10005, 0x3FE2E147A0000000
  %10009 = fadd fast float %10006, 0x3FE2E147A0000000
  %10010 = fadd fast float %10007, 0x3FE2E147A0000000
  %10011 = fmul fast float %10008, %9991
  %10012 = fmul fast float %10009, %9992
  %10013 = fmul fast float %10010, %9993
  %10014 = fadd fast float %10011, 0x3FC1EB8520000000
  %10015 = fadd fast float %10012, 0x3FC1EB8520000000
  %10016 = fadd fast float %10013, 0x3FC1EB8520000000
  %10017 = fdiv fast float %10002, %10014
  %10018 = fdiv fast float %10003, %10015
  %10019 = fdiv fast float %10004, %10016
  br label %10020

; <label>:10020                                   ; preds = %9995, %9981
  %10021 = phi float [ %10017, %9995 ], [ %9991, %9981 ]
  %10022 = phi float [ %10018, %9995 ], [ %9992, %9981 ]
  %10023 = phi float [ %10019, %9995 ], [ %9993, %9981 ]
  %10024 = call float @dx.op.unary.f32(i32 7, float %10021)  ; Saturate(value)
  %10025 = call float @dx.op.unary.f32(i32 7, float %10022)  ; Saturate(value)
  %10026 = call float @dx.op.unary.f32(i32 7, float %10023)  ; Saturate(value)
  %10027 = call float @dx.op.dot3.f32(i32 55, float %10024, float %10025, float %10026, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %10028 = fsub fast float %10024, %10027
  %10029 = fsub fast float %10025, %10027
  %10030 = fsub fast float %10026, %10027
  %10031 = fmul fast float %10028, %8
  %10032 = fmul fast float %10029, %8
  %10033 = fmul fast float %10030, %8
  %10034 = fadd fast float %10031, %10027
  %10035 = fadd fast float %10032, %10027
  %10036 = fadd fast float %10033, %10027
  %10037 = call float @dx.op.unary.f32(i32 7, float %10034)  ; Saturate(value)
  %10038 = call float @dx.op.unary.f32(i32 7, float %10035)  ; Saturate(value)
  %10039 = call float @dx.op.unary.f32(i32 7, float %10036)  ; Saturate(value)
  %10040 = fadd fast float %10037, 0xBFC70A3D80000000
  %10041 = fadd fast float %10038, 0xBFC70A3D80000000
  %10042 = fadd fast float %10039, 0xBFC70A3D80000000
  %10043 = fmul fast float %10040, %7
  %10044 = fmul fast float %10041, %7
  %10045 = fmul fast float %10042, %7
  %10046 = fadd fast float %10043, 0x3FC70A3D80000000
  %10047 = fadd fast float %10044, 0x3FC70A3D80000000
  %10048 = fadd fast float %10045, 0x3FC70A3D80000000
  %10049 = call float @dx.op.unary.f32(i32 7, float %10046)  ; Saturate(value)
  %10050 = call float @dx.op.unary.f32(i32 7, float %10047)  ; Saturate(value)
  %10051 = call float @dx.op.unary.f32(i32 7, float %10048)  ; Saturate(value)
  br label %10052

; <label>:10052                                   ; preds = %10020, %9803
  %10053 = phi float [ %9834, %9803 ], [ %10049, %10020 ]
  %10054 = phi float [ %9835, %9803 ], [ %10050, %10020 ]
  %10055 = phi float [ %9836, %9803 ], [ %10051, %10020 ]
  %10056 = fsub fast float %10053, %8907
  %10057 = fsub fast float %10054, %8908
  %10058 = fsub fast float %10055, %8909
  %10059 = fmul fast float %10056, %9790
  %10060 = fmul fast float %10057, %9790
  %10061 = fmul fast float %10058, %9790
  %10062 = fadd fast float %10059, %8907
  %10063 = fadd fast float %10060, %8908
  %10064 = fadd fast float %10061, %8909
  br label %10065

; <label>:10065                                   ; preds = %10052, %9777
  %10066 = phi float [ %10062, %10052 ], [ %8907, %9777 ]
  %10067 = phi float [ %10063, %10052 ], [ %8908, %9777 ]
  %10068 = phi float [ %10064, %10052 ], [ %8909, %9777 ]
  %10069 = call float @dx.op.binary.f32(i32 36, float %9778, float %10066)  ; FMin(a,b)
  %10070 = call float @dx.op.binary.f32(i32 36, float %9779, float %10067)  ; FMin(a,b)
  %10071 = call float @dx.op.binary.f32(i32 36, float %9780, float %10068)  ; FMin(a,b)
  %10072 = call float @dx.op.binary.f32(i32 36, float %9200, float %9488)  ; FMin(a,b)
  %10073 = call float @dx.op.binary.f32(i32 36, float %9201, float %9489)  ; FMin(a,b)
  %10074 = call float @dx.op.binary.f32(i32 36, float %9202, float %9490)  ; FMin(a,b)
  %10075 = call float @dx.op.binary.f32(i32 36, float %10072, float %10069)  ; FMin(a,b)
  %10076 = call float @dx.op.binary.f32(i32 36, float %10073, float %10070)  ; FMin(a,b)
  %10077 = call float @dx.op.binary.f32(i32 36, float %10074, float %10071)  ; FMin(a,b)
  %10078 = call float @dx.op.binary.f32(i32 36, float %8907, float %10075)  ; FMin(a,b)
  %10079 = call float @dx.op.binary.f32(i32 36, float %8908, float %10076)  ; FMin(a,b)
  %10080 = call float @dx.op.binary.f32(i32 36, float %8909, float %10077)  ; FMin(a,b)
  %10081 = call float @dx.op.binary.f32(i32 35, float %9778, float %10066)  ; FMax(a,b)
  %10082 = call float @dx.op.binary.f32(i32 35, float %9779, float %10067)  ; FMax(a,b)
  %10083 = call float @dx.op.binary.f32(i32 35, float %9780, float %10068)  ; FMax(a,b)
  %10084 = call float @dx.op.binary.f32(i32 35, float %9200, float %9488)  ; FMax(a,b)
  %10085 = call float @dx.op.binary.f32(i32 35, float %9201, float %9489)  ; FMax(a,b)
  %10086 = call float @dx.op.binary.f32(i32 35, float %9202, float %9490)  ; FMax(a,b)
  %10087 = call float @dx.op.binary.f32(i32 35, float %10084, float %10081)  ; FMax(a,b)
  %10088 = call float @dx.op.binary.f32(i32 35, float %10085, float %10082)  ; FMax(a,b)
  %10089 = call float @dx.op.binary.f32(i32 35, float %10086, float %10083)  ; FMax(a,b)
  %10090 = call float @dx.op.binary.f32(i32 35, float %8907, float %10087)  ; FMax(a,b)
  %10091 = call float @dx.op.binary.f32(i32 35, float %8908, float %10088)  ; FMax(a,b)
  %10092 = call float @dx.op.binary.f32(i32 35, float %8909, float %10089)  ; FMax(a,b)
  %10093 = fsub fast float %10090, %10078
  %10094 = fsub fast float %10091, %10079
  %10095 = fsub fast float %10092, %10080
  %10096 = call float @dx.op.unary.f32(i32 6, float %10093)  ; FAbs(value)
  %10097 = call float @dx.op.unary.f32(i32 6, float %10094)  ; FAbs(value)
  %10098 = call float @dx.op.unary.f32(i32 6, float %10095)  ; FAbs(value)
  %10099 = call float @dx.op.binary.f32(i32 35, float %10097, float %10098)  ; FMax(a,b)
  %10100 = call float @dx.op.binary.f32(i32 35, float %10096, float %10099)  ; FMax(a,b)
  %10101 = call float @dx.op.binary.f32(i32 35, float %10091, float %10092)  ; FMax(a,b)
  %10102 = call float @dx.op.binary.f32(i32 35, float %10090, float %10101)  ; FMax(a,b)
  %10103 = fmul fast float %10102, 1.250000e-01
  %10104 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %10103)  ; FMax(a,b)
  %10105 = fcmp fast ogt float %10100, %10104
  br i1 %10105, label %10106, label %10167

; <label>:10106                                   ; preds = %10065
  %10107 = fsub fast float %9200, %9488
  %10108 = fsub fast float %9201, %9489
  %10109 = fsub fast float %9202, %9490
  %10110 = call float @dx.op.unary.f32(i32 6, float %10107)  ; FAbs(value)
  %10111 = call float @dx.op.unary.f32(i32 6, float %10108)  ; FAbs(value)
  %10112 = call float @dx.op.unary.f32(i32 6, float %10109)  ; FAbs(value)
  %10113 = call float @dx.op.binary.f32(i32 35, float %10111, float %10112)  ; FMax(a,b)
  %10114 = call float @dx.op.binary.f32(i32 35, float %10110, float %10113)  ; FMax(a,b)
  %10115 = fsub fast float %9778, %10066
  %10116 = fsub fast float %9779, %10067
  %10117 = fsub fast float %9780, %10068
  %10118 = call float @dx.op.unary.f32(i32 6, float %10115)  ; FAbs(value)
  %10119 = call float @dx.op.unary.f32(i32 6, float %10116)  ; FAbs(value)
  %10120 = call float @dx.op.unary.f32(i32 6, float %10117)  ; FAbs(value)
  %10121 = call float @dx.op.binary.f32(i32 35, float %10119, float %10120)  ; FMax(a,b)
  %10122 = call float @dx.op.binary.f32(i32 35, float %10118, float %10121)  ; FMax(a,b)
  %10123 = fcmp fast olt float %10114, %10122
  %10124 = select i1 %10123, float %9200, float %9778
  %10125 = select i1 %10123, float %9201, float %9779
  %10126 = select i1 %10123, float %9202, float %9780
  %10127 = select i1 %10123, float %9488, float %10066
  %10128 = select i1 %10123, float %9489, float %10067
  %10129 = select i1 %10123, float %9490, float %10068
  %10130 = fsub fast float %8907, %10127
  %10131 = fsub fast float %8908, %10128
  %10132 = fsub fast float %8909, %10129
  %10133 = fsub fast float %8907, %10124
  %10134 = fsub fast float %8908, %10125
  %10135 = fsub fast float %8909, %10126
  %10136 = call float @dx.op.dot3.f32(i32 55, float %10133, float %10134, float %10135, float %10130, float %10131, float %10132)  ; Dot3(ax,ay,az,bx,by,bz)
  %10137 = fcmp fast ogt float %10136, 0.000000e+00
  br i1 %10137, label %10138, label %10150

; <label>:10138                                   ; preds = %10106
  %10139 = fsub fast float %10124, %10127
  %10140 = fsub fast float %10125, %10128
  %10141 = fsub fast float %10126, %10129
  %10142 = call float @dx.op.unary.f32(i32 6, float %10139)  ; FAbs(value)
  %10143 = call float @dx.op.unary.f32(i32 6, float %10140)  ; FAbs(value)
  %10144 = call float @dx.op.unary.f32(i32 6, float %10141)  ; FAbs(value)
  %10145 = call float @dx.op.binary.f32(i32 35, float %10143, float %10144)  ; FMax(a,b)
  %10146 = call float @dx.op.binary.f32(i32 35, float %10142, float %10145)  ; FMax(a,b)
  %10147 = fmul fast float %10100, 2.500000e-01
  %10148 = fcmp fast olt float %10146, %10147
  %10149 = select i1 %10148, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  br label %10150

; <label>:10150                                   ; preds = %10138, %10106
  %10151 = phi float [ 0x3FC99999A0000000, %10106 ], [ %10149, %10138 ]
  %10152 = fadd fast float %10124, %10127
  %10153 = fadd fast float %10125, %10128
  %10154 = fadd fast float %10126, %10129
  %10155 = fmul fast float %10152, 5.000000e-01
  %10156 = fmul fast float %10153, 5.000000e-01
  %10157 = fmul fast float %10154, 5.000000e-01
  %10158 = fsub fast float %10155, %8907
  %10159 = fsub fast float %10156, %8908
  %10160 = fsub fast float %10157, %8909
  %10161 = fmul fast float %10151, %10158
  %10162 = fmul fast float %10151, %10159
  %10163 = fmul fast float %10151, %10160
  %10164 = fadd fast float %10161, %8907
  %10165 = fadd fast float %10162, %8908
  %10166 = fadd fast float %10163, %8909
  br label %10167

; <label>:10167                                   ; preds = %10150, %10065, %8662, %4090, %4005, %3384
  %10168 = phi float [ %1939, %3384 ], [ %5620, %8662 ], [ %1939, %4090 ], [ %1939, %4005 ], [ %5620, %10150 ], [ %5620, %10065 ]
  %10169 = phi float [ %1940, %3384 ], [ %5621, %8662 ], [ %1940, %4090 ], [ %1940, %4005 ], [ %5621, %10150 ], [ %5621, %10065 ]
  %10170 = phi float [ %1941, %3384 ], [ %5622, %8662 ], [ %1941, %4090 ], [ %1941, %4005 ], [ %5622, %10150 ], [ %5622, %10065 ]
  %10171 = phi float [ %1212, %3384 ], [ %5623, %8662 ], [ %1212, %4090 ], [ %1212, %4005 ], [ %5623, %10150 ], [ %5623, %10065 ]
  %10172 = phi float [ %2662, %3384 ], [ %7136, %8662 ], [ %2662, %4090 ], [ %2662, %4005 ], [ %7136, %10150 ], [ %7136, %10065 ]
  %10173 = phi float [ %2663, %3384 ], [ %7137, %8662 ], [ %2663, %4090 ], [ %2663, %4005 ], [ %7137, %10150 ], [ %7137, %10065 ]
  %10174 = phi float [ %2664, %3384 ], [ %7138, %8662 ], [ %2664, %4090 ], [ %2664, %4005 ], [ %7138, %10150 ], [ %7138, %10065 ]
  %10175 = phi float [ %1214, %3384 ], [ %7139, %8662 ], [ %1214, %4090 ], [ %1214, %4005 ], [ %7139, %10150 ], [ %7139, %10065 ]
  %10176 = phi float [ %3385, %3384 ], [ %8652, %8662 ], [ %3385, %4090 ], [ %3385, %4005 ], [ %8652, %10150 ], [ %8652, %10065 ]
  %10177 = phi float [ %3386, %3384 ], [ %8653, %8662 ], [ %3386, %4090 ], [ %3386, %4005 ], [ %8653, %10150 ], [ %8653, %10065 ]
  %10178 = phi float [ %3387, %3384 ], [ %8654, %8662 ], [ %3387, %4090 ], [ %3387, %4005 ], [ %8654, %10150 ], [ %8654, %10065 ]
  %10179 = phi float [ %1216, %3384 ], [ %8655, %8662 ], [ %1216, %4090 ], [ %1216, %4005 ], [ %8655, %10150 ], [ %8655, %10065 ]
  %10180 = phi float [ %1208, %3384 ], [ %8693, %8662 ], [ %4104, %4090 ], [ %1208, %4005 ], [ %10164, %10150 ], [ %8907, %10065 ]
  %10181 = phi float [ %1209, %3384 ], [ %8694, %8662 ], [ %4105, %4090 ], [ %1209, %4005 ], [ %10165, %10150 ], [ %8908, %10065 ]
  %10182 = phi float [ %1210, %3384 ], [ %8695, %8662 ], [ %4106, %4090 ], [ %1210, %4005 ], [ %10166, %10150 ], [ %8909, %10065 ]
  %10183 = phi float [ %1218, %3384 ], [ %8696, %8662 ], [ %1218, %4090 ], [ %1218, %4005 ], [ %8660, %10150 ], [ %8660, %10065 ]
  %10184 = fmul fast float %10168, %162
  %10185 = fmul fast float %10169, %162
  %10186 = fmul fast float %10170, %162
  %10187 = fmul fast float %10172, %163
  %10188 = fmul fast float %10173, %163
  %10189 = fmul fast float %10174, %163
  %10190 = fadd fast float %10187, %10184
  %10191 = fadd fast float %10188, %10185
  %10192 = fadd fast float %10189, %10186
  %10193 = fmul fast float %10176, %164
  %10194 = fmul fast float %10177, %164
  %10195 = fmul fast float %10178, %164
  %10196 = fadd fast float %10190, %10193
  %10197 = fadd fast float %10191, %10194
  %10198 = fadd fast float %10192, %10195
  %10199 = fmul fast float %10180, %165
  %10200 = fmul fast float %10181, %165
  %10201 = fmul fast float %10182, %165
  %10202 = fadd fast float %10196, %10199
  %10203 = fadd fast float %10197, %10200
  %10204 = fadd fast float %10198, %10201
  %10205 = fcmp fast ogt float %10202, 0x3F69A5C380000000
  %10206 = fcmp fast ogt float %10203, 0x3F69A5C380000000
  %10207 = fcmp fast ogt float %10204, 0x3F69A5C380000000
  %10208 = select i1 %10205, float 0.000000e+00, float 1.000000e+00
  %10209 = select i1 %10206, float 0.000000e+00, float 1.000000e+00
  %10210 = select i1 %10207, float 0.000000e+00, float 1.000000e+00
  %10211 = fmul fast float %10202, 0x4029D70A40000000
  %10212 = fmul fast float %10203, 0x4029D70A40000000
  %10213 = fmul fast float %10204, 0x4029D70A40000000
  %10214 = call float @dx.op.binary.f32(i32 35, float %10202, float 0.000000e+00)  ; FMax(a,b)
  %10215 = call float @dx.op.binary.f32(i32 35, float %10203, float 0.000000e+00)  ; FMax(a,b)
  %10216 = call float @dx.op.binary.f32(i32 35, float %10204, float 0.000000e+00)  ; FMax(a,b)
  %10217 = call float @dx.op.unary.f32(i32 23, float %10214)  ; Log(value)
  %10218 = call float @dx.op.unary.f32(i32 23, float %10215)  ; Log(value)
  %10219 = call float @dx.op.unary.f32(i32 23, float %10216)  ; Log(value)
  %10220 = fmul fast float %10217, 0x3FDAAAAAA0000000
  %10221 = fmul fast float %10218, 0x3FDAAAAAA0000000
  %10222 = fmul fast float %10219, 0x3FDAAAAAA0000000
  %10223 = call float @dx.op.unary.f32(i32 21, float %10220)  ; Exp(value)
  %10224 = call float @dx.op.unary.f32(i32 21, float %10221)  ; Exp(value)
  %10225 = call float @dx.op.unary.f32(i32 21, float %10222)  ; Exp(value)
  %10226 = fmul fast float %10223, 0x3FF0E147A0000000
  %10227 = fmul fast float %10224, 0x3FF0E147A0000000
  %10228 = fmul fast float %10225, 0x3FF0E147A0000000
  %10229 = fadd fast float %10226, 0xBFAC28F5C0000000
  %10230 = fadd fast float %10227, 0xBFAC28F5C0000000
  %10231 = fadd fast float %10228, 0xBFAC28F5C0000000
  %10232 = fsub fast float %10211, %10229
  %10233 = fsub fast float %10212, %10230
  %10234 = fsub fast float %10213, %10231
  %10235 = fmul fast float %10232, %10208
  %10236 = fmul fast float %10233, %10209
  %10237 = fmul fast float %10234, %10210
  %10238 = fadd fast float %10235, %10229
  %10239 = fadd fast float %10236, %10230
  %10240 = fadd fast float %10237, %10231
  %10241 = call float @dx.op.dot4.f32(i32 56, float %10171, float %10175, float %10179, float %10183, float %162, float %163, float %164, float %165)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %10238)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %10239)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %10240)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %10241)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %80)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare i1 @dx.op.isSpecialFloat.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !38, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, !37}
!36 = !{i32 9}
!37 = !{i32 3, i32 6}
!38 = !{!39, !40}
!39 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
!40 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !41}
!41 = !{i32 3, i32 1}
