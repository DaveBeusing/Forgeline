;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xy  
; TEXCOORD                 1   xyzw        2     NONE   float       
; TEXCOORD                 2   xyzw        3     NONE   float       
; TEXCOORD                 3   xyzw        4     NONE   float       
; TEXCOORD                 4   xyzw        5     NONE   float       
; TEXCOORD                 5   xyzw        6     NONE   float       
; TEXCOORD                 6   xyzw        7     NONE   float       
; TEXCOORD                 7   xyzw        8     NONE   float       
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float   x   
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
;
; shader hash: 7d7ae27002acbaa8c662325cb3c3306c
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=0
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 1
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 40 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 40 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 36, 37, 38, 39, 40 }
;   output 3 depends on inputs: { 0, 1 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %1, i32 0)  ; GetDimensions(handle,mipLevel)
  %12 = extractvalue %dx.types.Dimensions %11, 0
  %13 = extractvalue %dx.types.Dimensions %11, 1
  %14 = fptosi float %9 to i32
  %15 = fptosi float %10 to i32
  %16 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %14, i32 %15, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %17 = extractvalue %dx.types.ResRet.f32 %16, 0
  %18 = extractvalue %dx.types.ResRet.f32 %16, 1
  %19 = extractvalue %dx.types.ResRet.f32 %16, 2
  %20 = extractvalue %dx.types.ResRet.f32 %16, 3
  %21 = fcmp fast olt float %20, 0.000000e+00
  br i1 %21, label %22, label %24

; <label>:22                                      ; preds = %0
  %23 = fsub fast float -1.000000e+00, %20
  br label %699

; <label>:24                                      ; preds = %0
  %25 = fadd fast float %3, 1.000000e+00
  %26 = fadd fast float %4, 1.000000e+00
  %27 = fsub fast float 1.000000e+00, %3
  %28 = fmul fast float %7, %25
  %29 = fmul fast float %7, %26
  %30 = fmul fast float %7, %27
  %31 = fmul fast float %28, %17
  %32 = fmul fast float %29, %18
  %33 = fmul fast float %30, %19
  %34 = fcmp fast ult float %8, 5.000000e-01
  br i1 %34, label %60, label %35

; <label>:35                                      ; preds = %24
  %36 = fmul fast float %31, 0x4004147AE0000000
  %37 = fmul fast float %32, 0x4004147AE0000000
  %38 = fmul fast float %33, 0x4004147AE0000000
  %39 = fadd fast float %36, 0x3F9EB851E0000000
  %40 = fadd fast float %37, 0x3F9EB851E0000000
  %41 = fadd fast float %38, 0x3F9EB851E0000000
  %42 = fmul fast float %39, %31
  %43 = fmul fast float %40, %32
  %44 = fmul fast float %41, %33
  %45 = fmul fast float %31, 0x400370A3E0000000
  %46 = fmul fast float %32, 0x400370A3E0000000
  %47 = fmul fast float %33, 0x400370A3E0000000
  %48 = fadd fast float %45, 0x3FE2E147A0000000
  %49 = fadd fast float %46, 0x3FE2E147A0000000
  %50 = fadd fast float %47, 0x3FE2E147A0000000
  %51 = fmul fast float %48, %31
  %52 = fmul fast float %49, %32
  %53 = fmul fast float %50, %33
  %54 = fadd fast float %51, 0x3FC1EB8520000000
  %55 = fadd fast float %52, 0x3FC1EB8520000000
  %56 = fadd fast float %53, 0x3FC1EB8520000000
  %57 = fdiv fast float %42, %54
  %58 = fdiv fast float %43, %55
  %59 = fdiv fast float %44, %56
  br label %60

; <label>:60                                      ; preds = %35, %24
  %61 = phi float [ %57, %35 ], [ %31, %24 ]
  %62 = phi float [ %58, %35 ], [ %32, %24 ]
  %63 = phi float [ %59, %35 ], [ %33, %24 ]
  %64 = call float @dx.op.unary.f32(i32 7, float %61)  ; Saturate(value)
  %65 = call float @dx.op.unary.f32(i32 7, float %62)  ; Saturate(value)
  %66 = call float @dx.op.unary.f32(i32 7, float %63)  ; Saturate(value)
  %67 = call float @dx.op.dot3.f32(i32 55, float %64, float %65, float %66, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %68 = fsub fast float %64, %67
  %69 = fsub fast float %65, %67
  %70 = fsub fast float %66, %67
  %71 = fmul fast float %68, %6
  %72 = fmul fast float %69, %6
  %73 = fmul fast float %70, %6
  %74 = fadd fast float %71, %67
  %75 = fadd fast float %72, %67
  %76 = fadd fast float %73, %67
  %77 = call float @dx.op.unary.f32(i32 7, float %74)  ; Saturate(value)
  %78 = call float @dx.op.unary.f32(i32 7, float %75)  ; Saturate(value)
  %79 = call float @dx.op.unary.f32(i32 7, float %76)  ; Saturate(value)
  %80 = fadd fast float %77, 0xBFC70A3D80000000
  %81 = fadd fast float %78, 0xBFC70A3D80000000
  %82 = fadd fast float %79, 0xBFC70A3D80000000
  %83 = fmul fast float %80, %5
  %84 = fmul fast float %81, %5
  %85 = fmul fast float %82, %5
  %86 = fadd fast float %83, 0x3FC70A3D80000000
  %87 = fadd fast float %84, 0x3FC70A3D80000000
  %88 = fadd fast float %85, 0x3FC70A3D80000000
  %89 = call float @dx.op.unary.f32(i32 7, float %86)  ; Saturate(value)
  %90 = call float @dx.op.unary.f32(i32 7, float %87)  ; Saturate(value)
  %91 = call float @dx.op.unary.f32(i32 7, float %88)  ; Saturate(value)
  %92 = fcmp fast ogt float %2, 0.000000e+00
  br i1 %92, label %93, label %659

; <label>:93                                      ; preds = %60
  %94 = add i32 %15, -1
  %95 = add i32 %12, -1
  %96 = add i32 %13, -1
  %97 = call i32 @dx.op.binary.i32(i32 37, i32 %14, i32 0)  ; IMax(a,b)
  %98 = call i32 @dx.op.binary.i32(i32 37, i32 %94, i32 0)  ; IMax(a,b)
  %99 = call i32 @dx.op.binary.i32(i32 38, i32 %97, i32 %95)  ; IMin(a,b)
  %100 = call i32 @dx.op.binary.i32(i32 38, i32 %98, i32 %96)  ; IMin(a,b)
  %101 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %99, i32 %100, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %102 = extractvalue %dx.types.ResRet.f32 %101, 0
  %103 = extractvalue %dx.types.ResRet.f32 %101, 1
  %104 = extractvalue %dx.types.ResRet.f32 %101, 2
  %105 = extractvalue %dx.types.ResRet.f32 %101, 3
  %106 = fcmp fast olt float %105, 0.000000e+00
  br i1 %106, label %107, label %141

; <label>:107                                     ; preds = %93
  %108 = fcmp fast ogt float %102, 0x3FA4B5DCC0000000
  %109 = fcmp fast ogt float %103, 0x3FA4B5DCC0000000
  %110 = fcmp fast ogt float %104, 0x3FA4B5DCC0000000
  %111 = select i1 %108, float 0.000000e+00, float 1.000000e+00
  %112 = select i1 %109, float 0.000000e+00, float 1.000000e+00
  %113 = select i1 %110, float 0.000000e+00, float 1.000000e+00
  %114 = fmul fast float %102, 0x3FB3D07220000000
  %115 = fmul fast float %103, 0x3FB3D07220000000
  %116 = fmul fast float %104, 0x3FB3D07220000000
  %117 = fadd fast float %102, 0x3FAC28F5C0000000
  %118 = fadd fast float %103, 0x3FAC28F5C0000000
  %119 = fadd fast float %104, 0x3FAC28F5C0000000
  %120 = fmul fast float %117, 0x3FEE54EDE0000000
  %121 = fmul fast float %118, 0x3FEE54EDE0000000
  %122 = fmul fast float %119, 0x3FEE54EDE0000000
  %123 = call float @dx.op.unary.f32(i32 23, float %120)  ; Log(value)
  %124 = call float @dx.op.unary.f32(i32 23, float %121)  ; Log(value)
  %125 = call float @dx.op.unary.f32(i32 23, float %122)  ; Log(value)
  %126 = fmul fast float %123, 0x4003333340000000
  %127 = fmul fast float %124, 0x4003333340000000
  %128 = fmul fast float %125, 0x4003333340000000
  %129 = call float @dx.op.unary.f32(i32 21, float %126)  ; Exp(value)
  %130 = call float @dx.op.unary.f32(i32 21, float %127)  ; Exp(value)
  %131 = call float @dx.op.unary.f32(i32 21, float %128)  ; Exp(value)
  %132 = fsub fast float %114, %129
  %133 = fsub fast float %115, %130
  %134 = fsub fast float %116, %131
  %135 = fmul fast float %132, %111
  %136 = fmul fast float %133, %112
  %137 = fmul fast float %134, %113
  %138 = fadd fast float %135, %129
  %139 = fadd fast float %136, %130
  %140 = fadd fast float %137, %131
  br label %209

; <label>:141                                     ; preds = %93
  %142 = fadd fast float %3, 1.000000e+00
  %143 = fadd fast float %4, 1.000000e+00
  %144 = fsub fast float 1.000000e+00, %3
  %145 = fmul fast float %7, %142
  %146 = fmul fast float %7, %143
  %147 = fmul fast float %7, %144
  %148 = fmul fast float %145, %102
  %149 = fmul fast float %146, %103
  %150 = fmul fast float %147, %104
  %151 = fcmp fast ult float %8, 5.000000e-01
  br i1 %151, label %177, label %152

; <label>:152                                     ; preds = %141
  %153 = fmul fast float %148, 0x4004147AE0000000
  %154 = fmul fast float %149, 0x4004147AE0000000
  %155 = fmul fast float %150, 0x4004147AE0000000
  %156 = fadd fast float %153, 0x3F9EB851E0000000
  %157 = fadd fast float %154, 0x3F9EB851E0000000
  %158 = fadd fast float %155, 0x3F9EB851E0000000
  %159 = fmul fast float %156, %148
  %160 = fmul fast float %157, %149
  %161 = fmul fast float %158, %150
  %162 = fmul fast float %148, 0x400370A3E0000000
  %163 = fmul fast float %149, 0x400370A3E0000000
  %164 = fmul fast float %150, 0x400370A3E0000000
  %165 = fadd fast float %162, 0x3FE2E147A0000000
  %166 = fadd fast float %163, 0x3FE2E147A0000000
  %167 = fadd fast float %164, 0x3FE2E147A0000000
  %168 = fmul fast float %165, %148
  %169 = fmul fast float %166, %149
  %170 = fmul fast float %167, %150
  %171 = fadd fast float %168, 0x3FC1EB8520000000
  %172 = fadd fast float %169, 0x3FC1EB8520000000
  %173 = fadd fast float %170, 0x3FC1EB8520000000
  %174 = fdiv fast float %159, %171
  %175 = fdiv fast float %160, %172
  %176 = fdiv fast float %161, %173
  br label %177

; <label>:177                                     ; preds = %152, %141
  %178 = phi float [ %174, %152 ], [ %148, %141 ]
  %179 = phi float [ %175, %152 ], [ %149, %141 ]
  %180 = phi float [ %176, %152 ], [ %150, %141 ]
  %181 = call float @dx.op.unary.f32(i32 7, float %178)  ; Saturate(value)
  %182 = call float @dx.op.unary.f32(i32 7, float %179)  ; Saturate(value)
  %183 = call float @dx.op.unary.f32(i32 7, float %180)  ; Saturate(value)
  %184 = call float @dx.op.dot3.f32(i32 55, float %181, float %182, float %183, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %185 = fsub fast float %181, %184
  %186 = fsub fast float %182, %184
  %187 = fsub fast float %183, %184
  %188 = fmul fast float %185, %6
  %189 = fmul fast float %186, %6
  %190 = fmul fast float %187, %6
  %191 = fadd fast float %188, %184
  %192 = fadd fast float %189, %184
  %193 = fadd fast float %190, %184
  %194 = call float @dx.op.unary.f32(i32 7, float %191)  ; Saturate(value)
  %195 = call float @dx.op.unary.f32(i32 7, float %192)  ; Saturate(value)
  %196 = call float @dx.op.unary.f32(i32 7, float %193)  ; Saturate(value)
  %197 = fadd fast float %194, 0xBFC70A3D80000000
  %198 = fadd fast float %195, 0xBFC70A3D80000000
  %199 = fadd fast float %196, 0xBFC70A3D80000000
  %200 = fmul fast float %197, %5
  %201 = fmul fast float %198, %5
  %202 = fmul fast float %199, %5
  %203 = fadd fast float %200, 0x3FC70A3D80000000
  %204 = fadd fast float %201, 0x3FC70A3D80000000
  %205 = fadd fast float %202, 0x3FC70A3D80000000
  %206 = call float @dx.op.unary.f32(i32 7, float %203)  ; Saturate(value)
  %207 = call float @dx.op.unary.f32(i32 7, float %204)  ; Saturate(value)
  %208 = call float @dx.op.unary.f32(i32 7, float %205)  ; Saturate(value)
  br label %209

; <label>:209                                     ; preds = %177, %107
  %210 = phi float [ %138, %107 ], [ %206, %177 ]
  %211 = phi float [ %139, %107 ], [ %207, %177 ]
  %212 = phi float [ %140, %107 ], [ %208, %177 ]
  %213 = add i32 %15, 1
  %214 = call i32 @dx.op.binary.i32(i32 37, i32 %213, i32 0)  ; IMax(a,b)
  %215 = call i32 @dx.op.binary.i32(i32 38, i32 %214, i32 %96)  ; IMin(a,b)
  %216 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %99, i32 %215, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %217 = extractvalue %dx.types.ResRet.f32 %216, 0
  %218 = extractvalue %dx.types.ResRet.f32 %216, 1
  %219 = extractvalue %dx.types.ResRet.f32 %216, 2
  %220 = extractvalue %dx.types.ResRet.f32 %216, 3
  %221 = fcmp fast olt float %220, 0.000000e+00
  br i1 %221, label %222, label %256

; <label>:222                                     ; preds = %209
  %223 = fcmp fast ogt float %217, 0x3FA4B5DCC0000000
  %224 = fcmp fast ogt float %218, 0x3FA4B5DCC0000000
  %225 = fcmp fast ogt float %219, 0x3FA4B5DCC0000000
  %226 = select i1 %223, float 0.000000e+00, float 1.000000e+00
  %227 = select i1 %224, float 0.000000e+00, float 1.000000e+00
  %228 = select i1 %225, float 0.000000e+00, float 1.000000e+00
  %229 = fmul fast float %217, 0x3FB3D07220000000
  %230 = fmul fast float %218, 0x3FB3D07220000000
  %231 = fmul fast float %219, 0x3FB3D07220000000
  %232 = fadd fast float %217, 0x3FAC28F5C0000000
  %233 = fadd fast float %218, 0x3FAC28F5C0000000
  %234 = fadd fast float %219, 0x3FAC28F5C0000000
  %235 = fmul fast float %232, 0x3FEE54EDE0000000
  %236 = fmul fast float %233, 0x3FEE54EDE0000000
  %237 = fmul fast float %234, 0x3FEE54EDE0000000
  %238 = call float @dx.op.unary.f32(i32 23, float %235)  ; Log(value)
  %239 = call float @dx.op.unary.f32(i32 23, float %236)  ; Log(value)
  %240 = call float @dx.op.unary.f32(i32 23, float %237)  ; Log(value)
  %241 = fmul fast float %238, 0x4003333340000000
  %242 = fmul fast float %239, 0x4003333340000000
  %243 = fmul fast float %240, 0x4003333340000000
  %244 = call float @dx.op.unary.f32(i32 21, float %241)  ; Exp(value)
  %245 = call float @dx.op.unary.f32(i32 21, float %242)  ; Exp(value)
  %246 = call float @dx.op.unary.f32(i32 21, float %243)  ; Exp(value)
  %247 = fsub fast float %229, %244
  %248 = fsub fast float %230, %245
  %249 = fsub fast float %231, %246
  %250 = fmul fast float %247, %226
  %251 = fmul fast float %248, %227
  %252 = fmul fast float %249, %228
  %253 = fadd fast float %250, %244
  %254 = fadd fast float %251, %245
  %255 = fadd fast float %252, %246
  br label %324

; <label>:256                                     ; preds = %209
  %257 = fadd fast float %3, 1.000000e+00
  %258 = fadd fast float %4, 1.000000e+00
  %259 = fsub fast float 1.000000e+00, %3
  %260 = fmul fast float %7, %257
  %261 = fmul fast float %7, %258
  %262 = fmul fast float %7, %259
  %263 = fmul fast float %260, %217
  %264 = fmul fast float %261, %218
  %265 = fmul fast float %262, %219
  %266 = fcmp fast ult float %8, 5.000000e-01
  br i1 %266, label %292, label %267

; <label>:267                                     ; preds = %256
  %268 = fmul fast float %263, 0x4004147AE0000000
  %269 = fmul fast float %264, 0x4004147AE0000000
  %270 = fmul fast float %265, 0x4004147AE0000000
  %271 = fadd fast float %268, 0x3F9EB851E0000000
  %272 = fadd fast float %269, 0x3F9EB851E0000000
  %273 = fadd fast float %270, 0x3F9EB851E0000000
  %274 = fmul fast float %271, %263
  %275 = fmul fast float %272, %264
  %276 = fmul fast float %273, %265
  %277 = fmul fast float %263, 0x400370A3E0000000
  %278 = fmul fast float %264, 0x400370A3E0000000
  %279 = fmul fast float %265, 0x400370A3E0000000
  %280 = fadd fast float %277, 0x3FE2E147A0000000
  %281 = fadd fast float %278, 0x3FE2E147A0000000
  %282 = fadd fast float %279, 0x3FE2E147A0000000
  %283 = fmul fast float %280, %263
  %284 = fmul fast float %281, %264
  %285 = fmul fast float %282, %265
  %286 = fadd fast float %283, 0x3FC1EB8520000000
  %287 = fadd fast float %284, 0x3FC1EB8520000000
  %288 = fadd fast float %285, 0x3FC1EB8520000000
  %289 = fdiv fast float %274, %286
  %290 = fdiv fast float %275, %287
  %291 = fdiv fast float %276, %288
  br label %292

; <label>:292                                     ; preds = %267, %256
  %293 = phi float [ %289, %267 ], [ %263, %256 ]
  %294 = phi float [ %290, %267 ], [ %264, %256 ]
  %295 = phi float [ %291, %267 ], [ %265, %256 ]
  %296 = call float @dx.op.unary.f32(i32 7, float %293)  ; Saturate(value)
  %297 = call float @dx.op.unary.f32(i32 7, float %294)  ; Saturate(value)
  %298 = call float @dx.op.unary.f32(i32 7, float %295)  ; Saturate(value)
  %299 = call float @dx.op.dot3.f32(i32 55, float %296, float %297, float %298, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %300 = fsub fast float %296, %299
  %301 = fsub fast float %297, %299
  %302 = fsub fast float %298, %299
  %303 = fmul fast float %300, %6
  %304 = fmul fast float %301, %6
  %305 = fmul fast float %302, %6
  %306 = fadd fast float %303, %299
  %307 = fadd fast float %304, %299
  %308 = fadd fast float %305, %299
  %309 = call float @dx.op.unary.f32(i32 7, float %306)  ; Saturate(value)
  %310 = call float @dx.op.unary.f32(i32 7, float %307)  ; Saturate(value)
  %311 = call float @dx.op.unary.f32(i32 7, float %308)  ; Saturate(value)
  %312 = fadd fast float %309, 0xBFC70A3D80000000
  %313 = fadd fast float %310, 0xBFC70A3D80000000
  %314 = fadd fast float %311, 0xBFC70A3D80000000
  %315 = fmul fast float %312, %5
  %316 = fmul fast float %313, %5
  %317 = fmul fast float %314, %5
  %318 = fadd fast float %315, 0x3FC70A3D80000000
  %319 = fadd fast float %316, 0x3FC70A3D80000000
  %320 = fadd fast float %317, 0x3FC70A3D80000000
  %321 = call float @dx.op.unary.f32(i32 7, float %318)  ; Saturate(value)
  %322 = call float @dx.op.unary.f32(i32 7, float %319)  ; Saturate(value)
  %323 = call float @dx.op.unary.f32(i32 7, float %320)  ; Saturate(value)
  br label %324

; <label>:324                                     ; preds = %292, %222
  %325 = phi float [ %253, %222 ], [ %321, %292 ]
  %326 = phi float [ %254, %222 ], [ %322, %292 ]
  %327 = phi float [ %255, %222 ], [ %323, %292 ]
  %328 = add i32 %14, -1
  %329 = call i32 @dx.op.binary.i32(i32 37, i32 %328, i32 0)  ; IMax(a,b)
  %330 = call i32 @dx.op.binary.i32(i32 37, i32 %15, i32 0)  ; IMax(a,b)
  %331 = call i32 @dx.op.binary.i32(i32 38, i32 %329, i32 %95)  ; IMin(a,b)
  %332 = call i32 @dx.op.binary.i32(i32 38, i32 %330, i32 %96)  ; IMin(a,b)
  %333 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %331, i32 %332, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %334 = extractvalue %dx.types.ResRet.f32 %333, 0
  %335 = extractvalue %dx.types.ResRet.f32 %333, 1
  %336 = extractvalue %dx.types.ResRet.f32 %333, 2
  %337 = extractvalue %dx.types.ResRet.f32 %333, 3
  %338 = fcmp fast olt float %337, 0.000000e+00
  br i1 %338, label %339, label %373

; <label>:339                                     ; preds = %324
  %340 = fcmp fast ogt float %334, 0x3FA4B5DCC0000000
  %341 = fcmp fast ogt float %335, 0x3FA4B5DCC0000000
  %342 = fcmp fast ogt float %336, 0x3FA4B5DCC0000000
  %343 = select i1 %340, float 0.000000e+00, float 1.000000e+00
  %344 = select i1 %341, float 0.000000e+00, float 1.000000e+00
  %345 = select i1 %342, float 0.000000e+00, float 1.000000e+00
  %346 = fmul fast float %334, 0x3FB3D07220000000
  %347 = fmul fast float %335, 0x3FB3D07220000000
  %348 = fmul fast float %336, 0x3FB3D07220000000
  %349 = fadd fast float %334, 0x3FAC28F5C0000000
  %350 = fadd fast float %335, 0x3FAC28F5C0000000
  %351 = fadd fast float %336, 0x3FAC28F5C0000000
  %352 = fmul fast float %349, 0x3FEE54EDE0000000
  %353 = fmul fast float %350, 0x3FEE54EDE0000000
  %354 = fmul fast float %351, 0x3FEE54EDE0000000
  %355 = call float @dx.op.unary.f32(i32 23, float %352)  ; Log(value)
  %356 = call float @dx.op.unary.f32(i32 23, float %353)  ; Log(value)
  %357 = call float @dx.op.unary.f32(i32 23, float %354)  ; Log(value)
  %358 = fmul fast float %355, 0x4003333340000000
  %359 = fmul fast float %356, 0x4003333340000000
  %360 = fmul fast float %357, 0x4003333340000000
  %361 = call float @dx.op.unary.f32(i32 21, float %358)  ; Exp(value)
  %362 = call float @dx.op.unary.f32(i32 21, float %359)  ; Exp(value)
  %363 = call float @dx.op.unary.f32(i32 21, float %360)  ; Exp(value)
  %364 = fsub fast float %346, %361
  %365 = fsub fast float %347, %362
  %366 = fsub fast float %348, %363
  %367 = fmul fast float %364, %343
  %368 = fmul fast float %365, %344
  %369 = fmul fast float %366, %345
  %370 = fadd fast float %367, %361
  %371 = fadd fast float %368, %362
  %372 = fadd fast float %369, %363
  br label %441

; <label>:373                                     ; preds = %324
  %374 = fadd fast float %3, 1.000000e+00
  %375 = fadd fast float %4, 1.000000e+00
  %376 = fsub fast float 1.000000e+00, %3
  %377 = fmul fast float %7, %374
  %378 = fmul fast float %7, %375
  %379 = fmul fast float %7, %376
  %380 = fmul fast float %377, %334
  %381 = fmul fast float %378, %335
  %382 = fmul fast float %379, %336
  %383 = fcmp fast ult float %8, 5.000000e-01
  br i1 %383, label %409, label %384

; <label>:384                                     ; preds = %373
  %385 = fmul fast float %380, 0x4004147AE0000000
  %386 = fmul fast float %381, 0x4004147AE0000000
  %387 = fmul fast float %382, 0x4004147AE0000000
  %388 = fadd fast float %385, 0x3F9EB851E0000000
  %389 = fadd fast float %386, 0x3F9EB851E0000000
  %390 = fadd fast float %387, 0x3F9EB851E0000000
  %391 = fmul fast float %388, %380
  %392 = fmul fast float %389, %381
  %393 = fmul fast float %390, %382
  %394 = fmul fast float %380, 0x400370A3E0000000
  %395 = fmul fast float %381, 0x400370A3E0000000
  %396 = fmul fast float %382, 0x400370A3E0000000
  %397 = fadd fast float %394, 0x3FE2E147A0000000
  %398 = fadd fast float %395, 0x3FE2E147A0000000
  %399 = fadd fast float %396, 0x3FE2E147A0000000
  %400 = fmul fast float %397, %380
  %401 = fmul fast float %398, %381
  %402 = fmul fast float %399, %382
  %403 = fadd fast float %400, 0x3FC1EB8520000000
  %404 = fadd fast float %401, 0x3FC1EB8520000000
  %405 = fadd fast float %402, 0x3FC1EB8520000000
  %406 = fdiv fast float %391, %403
  %407 = fdiv fast float %392, %404
  %408 = fdiv fast float %393, %405
  br label %409

; <label>:409                                     ; preds = %384, %373
  %410 = phi float [ %406, %384 ], [ %380, %373 ]
  %411 = phi float [ %407, %384 ], [ %381, %373 ]
  %412 = phi float [ %408, %384 ], [ %382, %373 ]
  %413 = call float @dx.op.unary.f32(i32 7, float %410)  ; Saturate(value)
  %414 = call float @dx.op.unary.f32(i32 7, float %411)  ; Saturate(value)
  %415 = call float @dx.op.unary.f32(i32 7, float %412)  ; Saturate(value)
  %416 = call float @dx.op.dot3.f32(i32 55, float %413, float %414, float %415, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %417 = fsub fast float %413, %416
  %418 = fsub fast float %414, %416
  %419 = fsub fast float %415, %416
  %420 = fmul fast float %417, %6
  %421 = fmul fast float %418, %6
  %422 = fmul fast float %419, %6
  %423 = fadd fast float %420, %416
  %424 = fadd fast float %421, %416
  %425 = fadd fast float %422, %416
  %426 = call float @dx.op.unary.f32(i32 7, float %423)  ; Saturate(value)
  %427 = call float @dx.op.unary.f32(i32 7, float %424)  ; Saturate(value)
  %428 = call float @dx.op.unary.f32(i32 7, float %425)  ; Saturate(value)
  %429 = fadd fast float %426, 0xBFC70A3D80000000
  %430 = fadd fast float %427, 0xBFC70A3D80000000
  %431 = fadd fast float %428, 0xBFC70A3D80000000
  %432 = fmul fast float %429, %5
  %433 = fmul fast float %430, %5
  %434 = fmul fast float %431, %5
  %435 = fadd fast float %432, 0x3FC70A3D80000000
  %436 = fadd fast float %433, 0x3FC70A3D80000000
  %437 = fadd fast float %434, 0x3FC70A3D80000000
  %438 = call float @dx.op.unary.f32(i32 7, float %435)  ; Saturate(value)
  %439 = call float @dx.op.unary.f32(i32 7, float %436)  ; Saturate(value)
  %440 = call float @dx.op.unary.f32(i32 7, float %437)  ; Saturate(value)
  br label %441

; <label>:441                                     ; preds = %409, %339
  %442 = phi float [ %370, %339 ], [ %438, %409 ]
  %443 = phi float [ %371, %339 ], [ %439, %409 ]
  %444 = phi float [ %372, %339 ], [ %440, %409 ]
  %445 = add i32 %14, 1
  %446 = call i32 @dx.op.binary.i32(i32 37, i32 %445, i32 0)  ; IMax(a,b)
  %447 = call i32 @dx.op.binary.i32(i32 38, i32 %446, i32 %95)  ; IMin(a,b)
  %448 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %447, i32 %332, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %449 = extractvalue %dx.types.ResRet.f32 %448, 0
  %450 = extractvalue %dx.types.ResRet.f32 %448, 1
  %451 = extractvalue %dx.types.ResRet.f32 %448, 2
  %452 = extractvalue %dx.types.ResRet.f32 %448, 3
  %453 = fcmp fast olt float %452, 0.000000e+00
  br i1 %453, label %454, label %488

; <label>:454                                     ; preds = %441
  %455 = fcmp fast ogt float %449, 0x3FA4B5DCC0000000
  %456 = fcmp fast ogt float %450, 0x3FA4B5DCC0000000
  %457 = fcmp fast ogt float %451, 0x3FA4B5DCC0000000
  %458 = select i1 %455, float 0.000000e+00, float 1.000000e+00
  %459 = select i1 %456, float 0.000000e+00, float 1.000000e+00
  %460 = select i1 %457, float 0.000000e+00, float 1.000000e+00
  %461 = fmul fast float %449, 0x3FB3D07220000000
  %462 = fmul fast float %450, 0x3FB3D07220000000
  %463 = fmul fast float %451, 0x3FB3D07220000000
  %464 = fadd fast float %449, 0x3FAC28F5C0000000
  %465 = fadd fast float %450, 0x3FAC28F5C0000000
  %466 = fadd fast float %451, 0x3FAC28F5C0000000
  %467 = fmul fast float %464, 0x3FEE54EDE0000000
  %468 = fmul fast float %465, 0x3FEE54EDE0000000
  %469 = fmul fast float %466, 0x3FEE54EDE0000000
  %470 = call float @dx.op.unary.f32(i32 23, float %467)  ; Log(value)
  %471 = call float @dx.op.unary.f32(i32 23, float %468)  ; Log(value)
  %472 = call float @dx.op.unary.f32(i32 23, float %469)  ; Log(value)
  %473 = fmul fast float %470, 0x4003333340000000
  %474 = fmul fast float %471, 0x4003333340000000
  %475 = fmul fast float %472, 0x4003333340000000
  %476 = call float @dx.op.unary.f32(i32 21, float %473)  ; Exp(value)
  %477 = call float @dx.op.unary.f32(i32 21, float %474)  ; Exp(value)
  %478 = call float @dx.op.unary.f32(i32 21, float %475)  ; Exp(value)
  %479 = fsub fast float %461, %476
  %480 = fsub fast float %462, %477
  %481 = fsub fast float %463, %478
  %482 = fmul fast float %479, %458
  %483 = fmul fast float %480, %459
  %484 = fmul fast float %481, %460
  %485 = fadd fast float %482, %476
  %486 = fadd fast float %483, %477
  %487 = fadd fast float %484, %478
  br label %556

; <label>:488                                     ; preds = %441
  %489 = fadd fast float %3, 1.000000e+00
  %490 = fadd fast float %4, 1.000000e+00
  %491 = fsub fast float 1.000000e+00, %3
  %492 = fmul fast float %7, %489
  %493 = fmul fast float %7, %490
  %494 = fmul fast float %7, %491
  %495 = fmul fast float %492, %449
  %496 = fmul fast float %493, %450
  %497 = fmul fast float %494, %451
  %498 = fcmp fast ult float %8, 5.000000e-01
  br i1 %498, label %524, label %499

; <label>:499                                     ; preds = %488
  %500 = fmul fast float %495, 0x4004147AE0000000
  %501 = fmul fast float %496, 0x4004147AE0000000
  %502 = fmul fast float %497, 0x4004147AE0000000
  %503 = fadd fast float %500, 0x3F9EB851E0000000
  %504 = fadd fast float %501, 0x3F9EB851E0000000
  %505 = fadd fast float %502, 0x3F9EB851E0000000
  %506 = fmul fast float %503, %495
  %507 = fmul fast float %504, %496
  %508 = fmul fast float %505, %497
  %509 = fmul fast float %495, 0x400370A3E0000000
  %510 = fmul fast float %496, 0x400370A3E0000000
  %511 = fmul fast float %497, 0x400370A3E0000000
  %512 = fadd fast float %509, 0x3FE2E147A0000000
  %513 = fadd fast float %510, 0x3FE2E147A0000000
  %514 = fadd fast float %511, 0x3FE2E147A0000000
  %515 = fmul fast float %512, %495
  %516 = fmul fast float %513, %496
  %517 = fmul fast float %514, %497
  %518 = fadd fast float %515, 0x3FC1EB8520000000
  %519 = fadd fast float %516, 0x3FC1EB8520000000
  %520 = fadd fast float %517, 0x3FC1EB8520000000
  %521 = fdiv fast float %506, %518
  %522 = fdiv fast float %507, %519
  %523 = fdiv fast float %508, %520
  br label %524

; <label>:524                                     ; preds = %499, %488
  %525 = phi float [ %521, %499 ], [ %495, %488 ]
  %526 = phi float [ %522, %499 ], [ %496, %488 ]
  %527 = phi float [ %523, %499 ], [ %497, %488 ]
  %528 = call float @dx.op.unary.f32(i32 7, float %525)  ; Saturate(value)
  %529 = call float @dx.op.unary.f32(i32 7, float %526)  ; Saturate(value)
  %530 = call float @dx.op.unary.f32(i32 7, float %527)  ; Saturate(value)
  %531 = call float @dx.op.dot3.f32(i32 55, float %528, float %529, float %530, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %532 = fsub fast float %528, %531
  %533 = fsub fast float %529, %531
  %534 = fsub fast float %530, %531
  %535 = fmul fast float %532, %6
  %536 = fmul fast float %533, %6
  %537 = fmul fast float %534, %6
  %538 = fadd fast float %535, %531
  %539 = fadd fast float %536, %531
  %540 = fadd fast float %537, %531
  %541 = call float @dx.op.unary.f32(i32 7, float %538)  ; Saturate(value)
  %542 = call float @dx.op.unary.f32(i32 7, float %539)  ; Saturate(value)
  %543 = call float @dx.op.unary.f32(i32 7, float %540)  ; Saturate(value)
  %544 = fadd fast float %541, 0xBFC70A3D80000000
  %545 = fadd fast float %542, 0xBFC70A3D80000000
  %546 = fadd fast float %543, 0xBFC70A3D80000000
  %547 = fmul fast float %544, %5
  %548 = fmul fast float %545, %5
  %549 = fmul fast float %546, %5
  %550 = fadd fast float %547, 0x3FC70A3D80000000
  %551 = fadd fast float %548, 0x3FC70A3D80000000
  %552 = fadd fast float %549, 0x3FC70A3D80000000
  %553 = call float @dx.op.unary.f32(i32 7, float %550)  ; Saturate(value)
  %554 = call float @dx.op.unary.f32(i32 7, float %551)  ; Saturate(value)
  %555 = call float @dx.op.unary.f32(i32 7, float %552)  ; Saturate(value)
  br label %556

; <label>:556                                     ; preds = %524, %454
  %557 = phi float [ %485, %454 ], [ %553, %524 ]
  %558 = phi float [ %486, %454 ], [ %554, %524 ]
  %559 = phi float [ %487, %454 ], [ %555, %524 ]
  %560 = call float @dx.op.binary.f32(i32 36, float %442, float %557)  ; FMin(a,b)
  %561 = call float @dx.op.binary.f32(i32 36, float %443, float %558)  ; FMin(a,b)
  %562 = call float @dx.op.binary.f32(i32 36, float %444, float %559)  ; FMin(a,b)
  %563 = call float @dx.op.binary.f32(i32 36, float %210, float %325)  ; FMin(a,b)
  %564 = call float @dx.op.binary.f32(i32 36, float %211, float %326)  ; FMin(a,b)
  %565 = call float @dx.op.binary.f32(i32 36, float %212, float %327)  ; FMin(a,b)
  %566 = call float @dx.op.binary.f32(i32 36, float %563, float %560)  ; FMin(a,b)
  %567 = call float @dx.op.binary.f32(i32 36, float %564, float %561)  ; FMin(a,b)
  %568 = call float @dx.op.binary.f32(i32 36, float %565, float %562)  ; FMin(a,b)
  %569 = call float @dx.op.binary.f32(i32 36, float %89, float %566)  ; FMin(a,b)
  %570 = call float @dx.op.binary.f32(i32 36, float %90, float %567)  ; FMin(a,b)
  %571 = call float @dx.op.binary.f32(i32 36, float %91, float %568)  ; FMin(a,b)
  %572 = call float @dx.op.binary.f32(i32 35, float %442, float %557)  ; FMax(a,b)
  %573 = call float @dx.op.binary.f32(i32 35, float %443, float %558)  ; FMax(a,b)
  %574 = call float @dx.op.binary.f32(i32 35, float %444, float %559)  ; FMax(a,b)
  %575 = call float @dx.op.binary.f32(i32 35, float %210, float %325)  ; FMax(a,b)
  %576 = call float @dx.op.binary.f32(i32 35, float %211, float %326)  ; FMax(a,b)
  %577 = call float @dx.op.binary.f32(i32 35, float %212, float %327)  ; FMax(a,b)
  %578 = call float @dx.op.binary.f32(i32 35, float %575, float %572)  ; FMax(a,b)
  %579 = call float @dx.op.binary.f32(i32 35, float %576, float %573)  ; FMax(a,b)
  %580 = call float @dx.op.binary.f32(i32 35, float %577, float %574)  ; FMax(a,b)
  %581 = call float @dx.op.binary.f32(i32 35, float %89, float %578)  ; FMax(a,b)
  %582 = call float @dx.op.binary.f32(i32 35, float %90, float %579)  ; FMax(a,b)
  %583 = call float @dx.op.binary.f32(i32 35, float %91, float %580)  ; FMax(a,b)
  %584 = fsub fast float %581, %569
  %585 = fsub fast float %582, %570
  %586 = fsub fast float %583, %571
  %587 = call float @dx.op.unary.f32(i32 6, float %584)  ; FAbs(value)
  %588 = call float @dx.op.unary.f32(i32 6, float %585)  ; FAbs(value)
  %589 = call float @dx.op.unary.f32(i32 6, float %586)  ; FAbs(value)
  %590 = call float @dx.op.binary.f32(i32 35, float %588, float %589)  ; FMax(a,b)
  %591 = call float @dx.op.binary.f32(i32 35, float %587, float %590)  ; FMax(a,b)
  %592 = call float @dx.op.binary.f32(i32 35, float %582, float %583)  ; FMax(a,b)
  %593 = call float @dx.op.binary.f32(i32 35, float %581, float %592)  ; FMax(a,b)
  %594 = fmul fast float %593, 1.250000e-01
  %595 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %594)  ; FMax(a,b)
  %596 = fcmp fast ogt float %591, %595
  br i1 %596, label %597, label %659

; <label>:597                                     ; preds = %556
  %598 = fsub fast float %210, %325
  %599 = fsub fast float %211, %326
  %600 = fsub fast float %212, %327
  %601 = call float @dx.op.unary.f32(i32 6, float %598)  ; FAbs(value)
  %602 = call float @dx.op.unary.f32(i32 6, float %599)  ; FAbs(value)
  %603 = call float @dx.op.unary.f32(i32 6, float %600)  ; FAbs(value)
  %604 = call float @dx.op.binary.f32(i32 35, float %602, float %603)  ; FMax(a,b)
  %605 = call float @dx.op.binary.f32(i32 35, float %601, float %604)  ; FMax(a,b)
  %606 = fsub fast float %442, %557
  %607 = fsub fast float %443, %558
  %608 = fsub fast float %444, %559
  %609 = call float @dx.op.unary.f32(i32 6, float %606)  ; FAbs(value)
  %610 = call float @dx.op.unary.f32(i32 6, float %607)  ; FAbs(value)
  %611 = call float @dx.op.unary.f32(i32 6, float %608)  ; FAbs(value)
  %612 = call float @dx.op.binary.f32(i32 35, float %610, float %611)  ; FMax(a,b)
  %613 = call float @dx.op.binary.f32(i32 35, float %609, float %612)  ; FMax(a,b)
  %614 = fcmp fast olt float %605, %613
  %615 = select i1 %614, float %210, float %442
  %616 = select i1 %614, float %211, float %443
  %617 = select i1 %614, float %212, float %444
  %618 = select i1 %614, float %325, float %557
  %619 = select i1 %614, float %326, float %558
  %620 = select i1 %614, float %327, float %559
  %621 = fsub fast float %89, %618
  %622 = fsub fast float %90, %619
  %623 = fsub fast float %91, %620
  %624 = fsub fast float %89, %615
  %625 = fsub fast float %90, %616
  %626 = fsub fast float %91, %617
  %627 = call float @dx.op.dot3.f32(i32 55, float %624, float %625, float %626, float %621, float %622, float %623)  ; Dot3(ax,ay,az,bx,by,bz)
  %628 = fcmp fast ogt float %627, 0.000000e+00
  br i1 %628, label %629, label %641

; <label>:629                                     ; preds = %597
  %630 = fsub fast float %615, %618
  %631 = fsub fast float %616, %619
  %632 = fsub fast float %617, %620
  %633 = call float @dx.op.unary.f32(i32 6, float %630)  ; FAbs(value)
  %634 = call float @dx.op.unary.f32(i32 6, float %631)  ; FAbs(value)
  %635 = call float @dx.op.unary.f32(i32 6, float %632)  ; FAbs(value)
  %636 = call float @dx.op.binary.f32(i32 35, float %634, float %635)  ; FMax(a,b)
  %637 = call float @dx.op.binary.f32(i32 35, float %633, float %636)  ; FMax(a,b)
  %638 = fmul fast float %591, 2.500000e-01
  %639 = fcmp fast olt float %637, %638
  %640 = select i1 %639, float 5.000000e-01, float 1.000000e+00
  br label %641

; <label>:641                                     ; preds = %629, %597
  %642 = phi float [ 1.000000e+00, %597 ], [ %640, %629 ]
  %643 = fmul fast float %642, %2
  %644 = fadd fast float %615, %618
  %645 = fadd fast float %616, %619
  %646 = fadd fast float %617, %620
  %647 = fmul fast float %644, 5.000000e-01
  %648 = fmul fast float %645, 5.000000e-01
  %649 = fmul fast float %646, 5.000000e-01
  %650 = fsub fast float %647, %89
  %651 = fsub fast float %648, %90
  %652 = fsub fast float %649, %91
  %653 = fmul fast float %643, %650
  %654 = fmul fast float %643, %651
  %655 = fmul fast float %643, %652
  %656 = fadd fast float %653, %89
  %657 = fadd fast float %654, %90
  %658 = fadd fast float %655, %91
  br label %659

; <label>:659                                     ; preds = %641, %556, %60
  %660 = phi float [ %656, %641 ], [ %89, %556 ], [ %89, %60 ]
  %661 = phi float [ %657, %641 ], [ %90, %556 ], [ %90, %60 ]
  %662 = phi float [ %658, %641 ], [ %91, %556 ], [ %91, %60 ]
  %663 = fcmp fast ogt float %660, 0x3F69A5C380000000
  %664 = fcmp fast ogt float %661, 0x3F69A5C380000000
  %665 = fcmp fast ogt float %662, 0x3F69A5C380000000
  %666 = select i1 %663, float 0.000000e+00, float 1.000000e+00
  %667 = select i1 %664, float 0.000000e+00, float 1.000000e+00
  %668 = select i1 %665, float 0.000000e+00, float 1.000000e+00
  %669 = fmul fast float %660, 0x4029D70A40000000
  %670 = fmul fast float %661, 0x4029D70A40000000
  %671 = fmul fast float %662, 0x4029D70A40000000
  %672 = call float @dx.op.binary.f32(i32 35, float %660, float 0.000000e+00)  ; FMax(a,b)
  %673 = call float @dx.op.binary.f32(i32 35, float %661, float 0.000000e+00)  ; FMax(a,b)
  %674 = call float @dx.op.binary.f32(i32 35, float %662, float 0.000000e+00)  ; FMax(a,b)
  %675 = call float @dx.op.unary.f32(i32 23, float %672)  ; Log(value)
  %676 = call float @dx.op.unary.f32(i32 23, float %673)  ; Log(value)
  %677 = call float @dx.op.unary.f32(i32 23, float %674)  ; Log(value)
  %678 = fmul fast float %675, 0x3FDAAAAAA0000000
  %679 = fmul fast float %676, 0x3FDAAAAAA0000000
  %680 = fmul fast float %677, 0x3FDAAAAAA0000000
  %681 = call float @dx.op.unary.f32(i32 21, float %678)  ; Exp(value)
  %682 = call float @dx.op.unary.f32(i32 21, float %679)  ; Exp(value)
  %683 = call float @dx.op.unary.f32(i32 21, float %680)  ; Exp(value)
  %684 = fmul fast float %681, 0x3FF0E147A0000000
  %685 = fmul fast float %682, 0x3FF0E147A0000000
  %686 = fmul fast float %683, 0x3FF0E147A0000000
  %687 = fadd fast float %684, 0xBFAC28F5C0000000
  %688 = fadd fast float %685, 0xBFAC28F5C0000000
  %689 = fadd fast float %686, 0xBFAC28F5C0000000
  %690 = fsub fast float %669, %687
  %691 = fsub fast float %670, %688
  %692 = fsub fast float %671, %689
  %693 = fmul fast float %690, %666
  %694 = fmul fast float %691, %667
  %695 = fmul fast float %692, %668
  %696 = fadd fast float %693, %687
  %697 = fadd fast float %694, %688
  %698 = fadd fast float %695, %689
  br label %699

; <label>:699                                     ; preds = %659, %22
  %700 = phi float [ %17, %22 ], [ %696, %659 ]
  %701 = phi float [ %18, %22 ], [ %697, %659 ]
  %702 = phi float [ %19, %22 ], [ %698, %659 ]
  %703 = phi float [ %23, %22 ], [ %20, %659 ]
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %700)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %701)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %702)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %703)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!8}
!dx.entryPoints = !{!9}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 0, i32 0]}
!9 = !{void ()* @PSMain, !"PSMain", !10, !4, null}
!10 = !{!11, !36, null}
!11 = !{!12, !15, !16, !18, !20, !22, !24, !26, !28, !30, !33}
!12 = !{i32 0, !"SV_Position", i8 9, i8 3, !13, i8 4, i32 1, i8 4, i32 0, i8 0, !14}
!13 = !{i32 0}
!14 = !{i32 3, i32 3}
!15 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !13, i8 1, i32 1, i8 4, i32 1, i8 0, !14}
!16 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !17, i8 1, i32 1, i8 4, i32 2, i8 0, null}
!17 = !{i32 1}
!18 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 3, i8 0, null}
!19 = !{i32 2}
!20 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 4, i8 0, null}
!21 = !{i32 3}
!22 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 5, i8 0, null}
!23 = !{i32 4}
!24 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 6, i8 0, null}
!25 = !{i32 5}
!26 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 7, i8 0, null}
!27 = !{i32 6}
!28 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !29, i8 1, i32 1, i8 4, i32 8, i8 0, null}
!29 = !{i32 7}
!30 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !31, i8 1, i32 1, i8 4, i32 9, i8 0, !32}
!31 = !{i32 8}
!32 = !{i32 3, i32 15}
!33 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 10, i8 0, !35}
!34 = !{i32 9}
!35 = !{i32 3, i32 1}
!36 = !{!37}
!37 = !{i32 0, !"SV_Target", i8 9, i8 16, !13, i8 0, i32 1, i8 4, i32 0, i8 0, !32}
