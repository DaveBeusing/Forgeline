;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float       
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
;
; shader hash: a3d35e42a34e144a931f82258f8753d0
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=0
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 1
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39 }
;   output 3 depends on inputs: { 0, 1 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %40 = extractvalue %dx.types.Dimensions %39, 0
  %41 = extractvalue %dx.types.Dimensions %39, 1
  %42 = fptosi float %37 to i32
  %43 = fptosi float %38 to i32
  %44 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %42, i32 %43, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %45 = extractvalue %dx.types.ResRet.f32 %44, 0
  %46 = extractvalue %dx.types.ResRet.f32 %44, 1
  %47 = extractvalue %dx.types.ResRet.f32 %44, 2
  %48 = extractvalue %dx.types.ResRet.f32 %44, 3
  %49 = fcmp fast olt float %48, 0.000000e+00
  br i1 %49, label %50, label %52

; <label>:50                                      ; preds = %0
  %51 = fsub fast float -1.000000e+00, %48
  br label %254

; <label>:52                                      ; preds = %0
  %53 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %54 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %42, i32 %43, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %55 = extractvalue %dx.types.ResRet.f32 %54, 0
  %56 = fcmp fast ogt float %53, 5.000000e-01
  %57 = fcmp fast olt float %55, 1.000000e+00
  %58 = and i1 %56, %57
  br i1 %58, label %59, label %147

; <label>:59                                      ; preds = %52
  %60 = sitofp i32 %42 to float
  %61 = sitofp i32 %43 to float
  %62 = fadd fast float %60, 5.000000e-01
  %63 = fadd fast float %61, 5.000000e-01
  %64 = uitofp i32 %40 to float
  %65 = uitofp i32 %41 to float
  %66 = fdiv fast float %62, %64
  %67 = fdiv fast float %63, %65
  %68 = fmul fast float %66, 2.000000e+00
  %69 = fmul fast float %67, 2.000000e+00
  %70 = fadd fast float %68, -1.000000e+00
  %71 = fsub fast float 1.000000e+00, %69
  %72 = fmul fast float %70, %33
  %73 = call float @dx.op.tertiary.f32(i32 46, float %71, float %29, float %72)  ; FMad(a,b,c)
  %74 = call float @dx.op.tertiary.f32(i32 46, float %55, float %25, float %73)  ; FMad(a,b,c)
  %75 = fadd fast float %74, %21
  %76 = call float @dx.op.unary.f32(i32 6, float %75)  ; FAbs(value)
  %77 = fcmp fast ogt float %76, 0x3EB0C6F7A0000000
  br i1 %77, label %78, label %147

; <label>:78                                      ; preds = %59
  %79 = fmul fast float %70, %32
  %80 = call float @dx.op.tertiary.f32(i32 46, float %71, float %28, float %79)  ; FMad(a,b,c)
  %81 = call float @dx.op.tertiary.f32(i32 46, float %55, float %24, float %80)  ; FMad(a,b,c)
  %82 = fadd fast float %81, %20
  %83 = fmul fast float %70, %31
  %84 = call float @dx.op.tertiary.f32(i32 46, float %71, float %27, float %83)  ; FMad(a,b,c)
  %85 = call float @dx.op.tertiary.f32(i32 46, float %55, float %23, float %84)  ; FMad(a,b,c)
  %86 = fadd fast float %85, %19
  %87 = fmul fast float %70, %30
  %88 = call float @dx.op.tertiary.f32(i32 46, float %71, float %26, float %87)  ; FMad(a,b,c)
  %89 = call float @dx.op.tertiary.f32(i32 46, float %55, float %22, float %88)  ; FMad(a,b,c)
  %90 = fadd fast float %89, %18
  %91 = fdiv fast float %90, %75
  %92 = fdiv fast float %86, %75
  %93 = fdiv fast float %82, %75
  %94 = fsub fast float %91, %15
  %95 = fsub fast float %92, %16
  %96 = fsub fast float %93, %17
  %97 = fmul fast float %94, %94
  %98 = fmul fast float %95, %95
  %99 = fadd fast float %98, %97
  %100 = fmul fast float %96, %96
  %101 = fadd fast float %99, %100
  %102 = call float @dx.op.unary.f32(i32 24, float %101)  ; Sqrt(value)
  %103 = fsub fast float %102, %7
  %104 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %103)  ; FMax(a,b)
  %105 = fcmp fast ogt float %36, 1.500000e+00
  br i1 %105, label %106, label %129

; <label>:106                                     ; preds = %78
  %107 = call float @dx.op.unary.f32(i32 6, float %95)  ; FAbs(value)
  %108 = fmul fast float %107, %9
  %109 = fcmp fast olt float %108, 0x3F50624DE0000000
  br i1 %109, label %110, label %113

; <label>:110                                     ; preds = %106
  %111 = fmul fast float %108, 5.000000e-01
  %112 = fsub fast float 1.000000e+00, %111
  br label %118

; <label>:113                                     ; preds = %106
  %114 = fmul fast float %108, 0xBFF7154760000000
  %115 = call float @dx.op.unary.f32(i32 21, float %114)  ; Exp(value)
  %116 = fsub fast float 1.000000e+00, %115
  %117 = fdiv fast float %116, %108
  br label %118

; <label>:118                                     ; preds = %113, %110
  %119 = phi float [ %112, %110 ], [ %117, %113 ]
  %120 = call float @dx.op.binary.f32(i32 36, float %92, float %16)  ; FMin(a,b)
  %121 = fsub fast float %120, %8
  %122 = fmul fast float %9, %121
  %123 = fsub fast float -0.000000e+00, %122
  %124 = call float @dx.op.binary.f32(i32 35, float %123, float -4.000000e+01)  ; FMax(a,b)
  %125 = call float @dx.op.binary.f32(i32 36, float %124, float 5.000000e+00)  ; FMin(a,b)
  %126 = fmul fast float %125, 0x3FF7154760000000
  %127 = call float @dx.op.unary.f32(i32 21, float %126)  ; Exp(value)
  %128 = fmul fast float %127, %119
  br label %129

; <label>:129                                     ; preds = %118, %78
  %130 = phi float [ %128, %118 ], [ 1.000000e+00, %78 ]
  %131 = fmul fast float %104, %14
  %132 = fmul fast float %131, %130
  %133 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %132)  ; FMin(a,b)
  %134 = fmul fast float %133, 0xBFF7154760000000
  %135 = call float @dx.op.unary.f32(i32 21, float %134)  ; Exp(value)
  %136 = fsub fast float 1.000000e+00, %135
  %137 = call float @dx.op.binary.f32(i32 36, float %10, float %136)  ; FMin(a,b)
  %138 = fsub fast float %11, %45
  %139 = fsub fast float %12, %46
  %140 = fsub fast float %13, %47
  %141 = fmul fast float %137, %138
  %142 = fmul fast float %137, %139
  %143 = fmul fast float %137, %140
  %144 = fadd fast float %141, %45
  %145 = fadd fast float %142, %46
  %146 = fadd fast float %143, %47
  br label %147

; <label>:147                                     ; preds = %129, %59, %52
  %148 = phi float [ %144, %129 ], [ %45, %59 ], [ %45, %52 ]
  %149 = phi float [ %145, %129 ], [ %46, %59 ], [ %46, %52 ]
  %150 = phi float [ %146, %129 ], [ %47, %59 ], [ %47, %52 ]
  %151 = fadd fast float %3, 1.000000e+00
  %152 = fadd fast float %4, 1.000000e+00
  %153 = fsub fast float 1.000000e+00, %3
  %154 = fmul fast float %34, %151
  %155 = fmul fast float %34, %152
  %156 = fmul fast float %34, %153
  %157 = fmul fast float %154, %148
  %158 = fmul fast float %155, %149
  %159 = fmul fast float %156, %150
  %160 = fcmp fast ult float %35, 5.000000e-01
  br i1 %160, label %186, label %161

; <label>:161                                     ; preds = %147
  %162 = fmul fast float %157, 0x4004147AE0000000
  %163 = fmul fast float %158, 0x4004147AE0000000
  %164 = fmul fast float %159, 0x4004147AE0000000
  %165 = fadd fast float %162, 0x3F9EB851E0000000
  %166 = fadd fast float %163, 0x3F9EB851E0000000
  %167 = fadd fast float %164, 0x3F9EB851E0000000
  %168 = fmul fast float %165, %157
  %169 = fmul fast float %166, %158
  %170 = fmul fast float %167, %159
  %171 = fmul fast float %157, 0x400370A3E0000000
  %172 = fmul fast float %158, 0x400370A3E0000000
  %173 = fmul fast float %159, 0x400370A3E0000000
  %174 = fadd fast float %171, 0x3FE2E147A0000000
  %175 = fadd fast float %172, 0x3FE2E147A0000000
  %176 = fadd fast float %173, 0x3FE2E147A0000000
  %177 = fmul fast float %174, %157
  %178 = fmul fast float %175, %158
  %179 = fmul fast float %176, %159
  %180 = fadd fast float %177, 0x3FC1EB8520000000
  %181 = fadd fast float %178, 0x3FC1EB8520000000
  %182 = fadd fast float %179, 0x3FC1EB8520000000
  %183 = fdiv fast float %168, %180
  %184 = fdiv fast float %169, %181
  %185 = fdiv fast float %170, %182
  br label %186

; <label>:186                                     ; preds = %161, %147
  %187 = phi float [ %183, %161 ], [ %157, %147 ]
  %188 = phi float [ %184, %161 ], [ %158, %147 ]
  %189 = phi float [ %185, %161 ], [ %159, %147 ]
  %190 = call float @dx.op.unary.f32(i32 7, float %187)  ; Saturate(value)
  %191 = call float @dx.op.unary.f32(i32 7, float %188)  ; Saturate(value)
  %192 = call float @dx.op.unary.f32(i32 7, float %189)  ; Saturate(value)
  %193 = call float @dx.op.dot3.f32(i32 55, float %190, float %191, float %192, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %194 = fsub fast float %190, %193
  %195 = fsub fast float %191, %193
  %196 = fsub fast float %192, %193
  %197 = fmul fast float %194, %6
  %198 = fmul fast float %195, %6
  %199 = fmul fast float %196, %6
  %200 = fadd fast float %197, %193
  %201 = fadd fast float %198, %193
  %202 = fadd fast float %199, %193
  %203 = call float @dx.op.unary.f32(i32 7, float %200)  ; Saturate(value)
  %204 = call float @dx.op.unary.f32(i32 7, float %201)  ; Saturate(value)
  %205 = call float @dx.op.unary.f32(i32 7, float %202)  ; Saturate(value)
  %206 = fadd fast float %203, 0xBFC70A3D80000000
  %207 = fadd fast float %204, 0xBFC70A3D80000000
  %208 = fadd fast float %205, 0xBFC70A3D80000000
  %209 = fmul fast float %206, %5
  %210 = fmul fast float %207, %5
  %211 = fmul fast float %208, %5
  %212 = fadd fast float %209, 0x3FC70A3D80000000
  %213 = fadd fast float %210, 0x3FC70A3D80000000
  %214 = fadd fast float %211, 0x3FC70A3D80000000
  %215 = call float @dx.op.unary.f32(i32 7, float %212)  ; Saturate(value)
  %216 = call float @dx.op.unary.f32(i32 7, float %213)  ; Saturate(value)
  %217 = call float @dx.op.unary.f32(i32 7, float %214)  ; Saturate(value)
  %218 = fcmp fast ogt float %215, 0x3F69A5C380000000
  %219 = fcmp fast ogt float %216, 0x3F69A5C380000000
  %220 = fcmp fast ogt float %217, 0x3F69A5C380000000
  %221 = select i1 %218, float 0.000000e+00, float 1.000000e+00
  %222 = select i1 %219, float 0.000000e+00, float 1.000000e+00
  %223 = select i1 %220, float 0.000000e+00, float 1.000000e+00
  %224 = fmul fast float %215, 0x4029D70A40000000
  %225 = fmul fast float %216, 0x4029D70A40000000
  %226 = fmul fast float %217, 0x4029D70A40000000
  %227 = call float @dx.op.binary.f32(i32 35, float %215, float 0.000000e+00)  ; FMax(a,b)
  %228 = call float @dx.op.binary.f32(i32 35, float %216, float 0.000000e+00)  ; FMax(a,b)
  %229 = call float @dx.op.binary.f32(i32 35, float %217, float 0.000000e+00)  ; FMax(a,b)
  %230 = call float @dx.op.unary.f32(i32 23, float %227)  ; Log(value)
  %231 = call float @dx.op.unary.f32(i32 23, float %228)  ; Log(value)
  %232 = call float @dx.op.unary.f32(i32 23, float %229)  ; Log(value)
  %233 = fmul fast float %230, 0x3FDAAAAAA0000000
  %234 = fmul fast float %231, 0x3FDAAAAAA0000000
  %235 = fmul fast float %232, 0x3FDAAAAAA0000000
  %236 = call float @dx.op.unary.f32(i32 21, float %233)  ; Exp(value)
  %237 = call float @dx.op.unary.f32(i32 21, float %234)  ; Exp(value)
  %238 = call float @dx.op.unary.f32(i32 21, float %235)  ; Exp(value)
  %239 = fmul fast float %236, 0x3FF0E147A0000000
  %240 = fmul fast float %237, 0x3FF0E147A0000000
  %241 = fmul fast float %238, 0x3FF0E147A0000000
  %242 = fadd fast float %239, 0xBFAC28F5C0000000
  %243 = fadd fast float %240, 0xBFAC28F5C0000000
  %244 = fadd fast float %241, 0xBFAC28F5C0000000
  %245 = fsub fast float %224, %242
  %246 = fsub fast float %225, %243
  %247 = fsub fast float %226, %244
  %248 = fmul fast float %245, %221
  %249 = fmul fast float %246, %222
  %250 = fmul fast float %247, %223
  %251 = fadd fast float %248, %242
  %252 = fadd fast float %249, %243
  %253 = fadd fast float %250, %244
  br label %254

; <label>:254                                     ; preds = %186, %50
  %255 = phi float [ %45, %50 ], [ %251, %186 ]
  %256 = phi float [ %46, %50 ], [ %252, %186 ]
  %257 = phi float [ %47, %50 ], [ %253, %186 ]
  %258 = phi float [ %51, %50 ], [ %48, %186 ]
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %255)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %256)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %257)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %258)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 0, i32 0, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !37, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, null}
!36 = !{i32 9}
!37 = !{!38}
!38 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
