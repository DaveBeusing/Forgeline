;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float   xyz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: ea6ee8be1f4f0908f9ea9513fefd04bd
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %40 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %41 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %42 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %43 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %44 = extractvalue %dx.types.Dimensions %43, 0
  %45 = extractvalue %dx.types.Dimensions %43, 1
  %46 = uitofp i32 %44 to float
  %47 = uitofp i32 %45 to float
  %48 = fmul fast float %46, %41
  %49 = fmul fast float %47, %42
  %50 = fdiv fast float %48, %4
  %51 = fdiv fast float %49, %5
  %52 = fadd fast float %50, -5.000000e-01
  %53 = fadd fast float %51, -5.000000e-01
  %54 = call float @dx.op.unary.f32(i32 27, float %52)  ; Round_ni(value)
  %55 = call float @dx.op.unary.f32(i32 27, float %53)  ; Round_ni(value)
  %56 = fptosi float %54 to i32
  %57 = fptosi float %55 to i32
  %58 = call float @dx.op.unary.f32(i32 22, float %52)  ; Frc(value)
  %59 = call float @dx.op.unary.f32(i32 22, float %53)  ; Frc(value)
  %60 = add i32 %44, -1
  %61 = add i32 %45, -1
  %62 = call i32 @dx.op.binary.i32(i32 37, i32 %56, i32 0)  ; IMax(a,b)
  %63 = call i32 @dx.op.binary.i32(i32 37, i32 %57, i32 0)  ; IMax(a,b)
  %64 = call i32 @dx.op.binary.i32(i32 38, i32 %62, i32 %60)  ; IMin(a,b)
  %65 = call i32 @dx.op.binary.i32(i32 38, i32 %63, i32 %61)  ; IMin(a,b)
  %66 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %64, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %67 = extractvalue %dx.types.ResRet.f32 %66, 0
  %68 = extractvalue %dx.types.ResRet.f32 %66, 1
  %69 = extractvalue %dx.types.ResRet.f32 %66, 2
  %70 = extractvalue %dx.types.ResRet.f32 %66, 3
  %71 = fcmp fast olt float %70, 0.000000e+00
  br i1 %71, label %72, label %74

; <label>:72                                      ; preds = %0
  %73 = fsub fast float -1.000000e+00, %70
  br label %1482

; <label>:74                                      ; preds = %0
  %75 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %64, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %76 = extractvalue %dx.types.ResRet.f32 %75, 0
  %77 = fcmp fast ogt float %39, 5.000000e-01
  %78 = fcmp fast olt float %76, 1.000000e+00
  %79 = and i1 %77, %78
  br i1 %79, label %80, label %218

; <label>:80                                      ; preds = %74
  %81 = sitofp i32 %64 to float
  %82 = sitofp i32 %65 to float
  %83 = fadd fast float %81, 5.000000e-01
  %84 = fadd fast float %82, 5.000000e-01
  %85 = fdiv fast float %83, %46
  %86 = fdiv fast float %84, %47
  %87 = fmul fast float %85, 2.000000e+00
  %88 = fmul fast float %86, 2.000000e+00
  %89 = fadd fast float %87, -1.000000e+00
  %90 = fsub fast float 1.000000e+00, %88
  %91 = fmul fast float %89, %36
  %92 = call float @dx.op.tertiary.f32(i32 46, float %90, float %32, float %91)  ; FMad(a,b,c)
  %93 = call float @dx.op.tertiary.f32(i32 46, float %76, float %28, float %92)  ; FMad(a,b,c)
  %94 = fadd fast float %93, %24
  %95 = call float @dx.op.unary.f32(i32 6, float %94)  ; FAbs(value)
  %96 = fcmp fast ogt float %95, 0x3EB0C6F7A0000000
  br i1 %96, label %97, label %218

; <label>:97                                      ; preds = %80
  %98 = fmul fast float %89, %35
  %99 = call float @dx.op.tertiary.f32(i32 46, float %90, float %31, float %98)  ; FMad(a,b,c)
  %100 = call float @dx.op.tertiary.f32(i32 46, float %76, float %27, float %99)  ; FMad(a,b,c)
  %101 = fadd fast float %100, %23
  %102 = fmul fast float %89, %34
  %103 = call float @dx.op.tertiary.f32(i32 46, float %90, float %30, float %102)  ; FMad(a,b,c)
  %104 = call float @dx.op.tertiary.f32(i32 46, float %76, float %26, float %103)  ; FMad(a,b,c)
  %105 = fadd fast float %104, %22
  %106 = fmul fast float %89, %33
  %107 = call float @dx.op.tertiary.f32(i32 46, float %90, float %29, float %106)  ; FMad(a,b,c)
  %108 = call float @dx.op.tertiary.f32(i32 46, float %76, float %25, float %107)  ; FMad(a,b,c)
  %109 = fadd fast float %108, %21
  %110 = fdiv fast float %109, %94
  %111 = fdiv fast float %105, %94
  %112 = fdiv fast float %101, %94
  %113 = fsub fast float %110, %18
  %114 = fsub fast float %111, %19
  %115 = fsub fast float %112, %20
  %116 = fmul fast float %113, %113
  %117 = fmul fast float %114, %114
  %118 = fadd fast float %117, %116
  %119 = fmul fast float %115, %115
  %120 = fadd fast float %118, %119
  %121 = call float @dx.op.unary.f32(i32 24, float %120)  ; Sqrt(value)
  %122 = fsub fast float %121, %10
  %123 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %122)  ; FMax(a,b)
  %124 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %124, label %125, label %148

; <label>:125                                     ; preds = %97
  %126 = call float @dx.op.unary.f32(i32 6, float %114)  ; FAbs(value)
  %127 = fmul fast float %126, %12
  %128 = fcmp fast olt float %127, 0x3F50624DE0000000
  br i1 %128, label %129, label %132

; <label>:129                                     ; preds = %125
  %130 = fmul fast float %127, 5.000000e-01
  %131 = fsub fast float 1.000000e+00, %130
  br label %137

; <label>:132                                     ; preds = %125
  %133 = fmul fast float %127, 0xBFF7154760000000
  %134 = call float @dx.op.unary.f32(i32 21, float %133)  ; Exp(value)
  %135 = fsub fast float 1.000000e+00, %134
  %136 = fdiv fast float %135, %127
  br label %137

; <label>:137                                     ; preds = %132, %129
  %138 = phi float [ %131, %129 ], [ %136, %132 ]
  %139 = call float @dx.op.binary.f32(i32 36, float %111, float %19)  ; FMin(a,b)
  %140 = fsub fast float %139, %11
  %141 = fmul fast float %12, %140
  %142 = fsub fast float -0.000000e+00, %141
  %143 = call float @dx.op.binary.f32(i32 35, float %142, float -4.000000e+01)  ; FMax(a,b)
  %144 = call float @dx.op.binary.f32(i32 36, float %143, float 5.000000e+00)  ; FMin(a,b)
  %145 = fmul fast float %144, 0x3FF7154760000000
  %146 = call float @dx.op.unary.f32(i32 21, float %145)  ; Exp(value)
  %147 = fmul fast float %146, %138
  br label %148

; <label>:148                                     ; preds = %137, %97
  %149 = phi float [ %147, %137 ], [ 1.000000e+00, %97 ]
  %150 = fmul fast float %123, %17
  %151 = fmul fast float %150, %149
  %152 = fcmp fast ole float %121, %10
  %153 = fcmp fast olt float %121, 0x3F1A36E2E0000000
  %154 = or i1 %152, %153
  br i1 %154, label %201, label %155

; <label>:155                                     ; preds = %148
  %156 = fdiv fast float %10, %121
  %157 = fmul fast float %156, %113
  %158 = fmul fast float %156, %114
  %159 = fmul fast float %156, %115
  %160 = fadd fast float %157, %18
  %161 = fadd fast float %158, %19
  %162 = fadd fast float %159, %20
  %163 = fadd fast float %160, -9.000000e+02
  %164 = fadd fast float %161, -1.500000e+01
  %165 = fadd fast float %162, -7.500000e+02
  %166 = fmul fast float %163, 0x3F62345680000000
  %167 = fmul fast float %164, 0x3F62345680000000
  %168 = fmul fast float %165, 0x3F62345680000000
  %169 = call float @dx.op.dot3.f32(i32 55, float %166, float %167, float %168, float %166, float %167, float %168)  ; Dot3(ax,ay,az,bx,by,bz)
  %170 = fsub fast float 1.000000e+00, %169
  %171 = call float @dx.op.unary.f32(i32 7, float %170)  ; Saturate(value)
  %172 = fmul fast float %171, %171
  %173 = fadd fast float %160, %110
  %174 = fadd fast float %161, %111
  %175 = fadd fast float %162, %112
  %176 = fmul fast float %173, 0x3F52345680000000
  %177 = fadd fast float %176, -2.000000e+00
  %178 = fmul fast float %174, 0x3F52345680000000
  %179 = fadd fast float %178, 0xBFA1111120000000
  %180 = fmul fast float %175, 0x3F52345680000000
  %181 = fadd fast float %180, 0xBFFAAAAAC0000000
  %182 = call float @dx.op.dot3.f32(i32 55, float %177, float %179, float %181, float %177, float %179, float %181)  ; Dot3(ax,ay,az,bx,by,bz)
  %183 = fsub fast float 1.000000e+00, %182
  %184 = call float @dx.op.unary.f32(i32 7, float %183)  ; Saturate(value)
  %185 = fmul fast float %184, %184
  %186 = fmul fast float %185, 4.000000e+00
  %187 = fadd fast float %186, %172
  %188 = fadd fast float %110, -9.000000e+02
  %189 = fadd fast float %111, -1.500000e+01
  %190 = fadd fast float %112, -7.500000e+02
  %191 = fmul fast float %188, 0x3F62345680000000
  %192 = fmul fast float %189, 0x3F62345680000000
  %193 = fmul fast float %190, 0x3F62345680000000
  %194 = call float @dx.op.dot3.f32(i32 55, float %191, float %192, float %193, float %191, float %192, float %193)  ; Dot3(ax,ay,az,bx,by,bz)
  %195 = fsub fast float 1.000000e+00, %194
  %196 = call float @dx.op.unary.f32(i32 7, float %195)  ; Saturate(value)
  %197 = fmul fast float %196, %196
  %198 = fadd fast float %187, %197
  %199 = fmul fast float %122, 0x3F25D867E0000000
  %200 = fmul fast float %199, %198
  br label %201

; <label>:201                                     ; preds = %155, %148
  %202 = phi float [ %200, %155 ], [ 0.000000e+00, %148 ]
  %203 = fadd fast float %202, %151
  %204 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %203)  ; FMin(a,b)
  %205 = fmul fast float %204, 0xBFF7154760000000
  %206 = call float @dx.op.unary.f32(i32 21, float %205)  ; Exp(value)
  %207 = fsub fast float 1.000000e+00, %206
  %208 = call float @dx.op.binary.f32(i32 36, float %13, float %207)  ; FMin(a,b)
  %209 = fsub fast float %14, %67
  %210 = fsub fast float %15, %68
  %211 = fsub fast float %16, %69
  %212 = fmul fast float %208, %209
  %213 = fmul fast float %208, %210
  %214 = fmul fast float %208, %211
  %215 = fadd fast float %212, %67
  %216 = fadd fast float %213, %68
  %217 = fadd fast float %214, %69
  br label %218

; <label>:218                                     ; preds = %201, %80, %74
  %219 = phi float [ %215, %201 ], [ %67, %80 ], [ %67, %74 ]
  %220 = phi float [ %216, %201 ], [ %68, %80 ], [ %68, %74 ]
  %221 = phi float [ %217, %201 ], [ %69, %80 ], [ %69, %74 ]
  %222 = fadd fast float %6, 1.000000e+00
  %223 = fadd fast float %7, 1.000000e+00
  %224 = fsub fast float 1.000000e+00, %6
  %225 = fmul fast float %37, %222
  %226 = fmul fast float %37, %223
  %227 = fmul fast float %37, %224
  %228 = fmul fast float %225, %219
  %229 = fmul fast float %226, %220
  %230 = fmul fast float %227, %221
  %231 = fcmp fast ult float %38, 5.000000e-01
  br i1 %231, label %257, label %232

; <label>:232                                     ; preds = %218
  %233 = fmul fast float %228, 0x4004147AE0000000
  %234 = fmul fast float %229, 0x4004147AE0000000
  %235 = fmul fast float %230, 0x4004147AE0000000
  %236 = fadd fast float %233, 0x3F9EB851E0000000
  %237 = fadd fast float %234, 0x3F9EB851E0000000
  %238 = fadd fast float %235, 0x3F9EB851E0000000
  %239 = fmul fast float %236, %228
  %240 = fmul fast float %237, %229
  %241 = fmul fast float %238, %230
  %242 = fmul fast float %228, 0x400370A3E0000000
  %243 = fmul fast float %229, 0x400370A3E0000000
  %244 = fmul fast float %230, 0x400370A3E0000000
  %245 = fadd fast float %242, 0x3FE2E147A0000000
  %246 = fadd fast float %243, 0x3FE2E147A0000000
  %247 = fadd fast float %244, 0x3FE2E147A0000000
  %248 = fmul fast float %245, %228
  %249 = fmul fast float %246, %229
  %250 = fmul fast float %247, %230
  %251 = fadd fast float %248, 0x3FC1EB8520000000
  %252 = fadd fast float %249, 0x3FC1EB8520000000
  %253 = fadd fast float %250, 0x3FC1EB8520000000
  %254 = fdiv fast float %239, %251
  %255 = fdiv fast float %240, %252
  %256 = fdiv fast float %241, %253
  br label %257

; <label>:257                                     ; preds = %232, %218
  %258 = phi float [ %254, %232 ], [ %228, %218 ]
  %259 = phi float [ %255, %232 ], [ %229, %218 ]
  %260 = phi float [ %256, %232 ], [ %230, %218 ]
  %261 = call float @dx.op.unary.f32(i32 7, float %258)  ; Saturate(value)
  %262 = call float @dx.op.unary.f32(i32 7, float %259)  ; Saturate(value)
  %263 = call float @dx.op.unary.f32(i32 7, float %260)  ; Saturate(value)
  %264 = call float @dx.op.dot3.f32(i32 55, float %261, float %262, float %263, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %265 = fsub fast float %261, %264
  %266 = fsub fast float %262, %264
  %267 = fsub fast float %263, %264
  %268 = fmul fast float %265, %9
  %269 = fmul fast float %266, %9
  %270 = fmul fast float %267, %9
  %271 = fadd fast float %268, %264
  %272 = fadd fast float %269, %264
  %273 = fadd fast float %270, %264
  %274 = call float @dx.op.unary.f32(i32 7, float %271)  ; Saturate(value)
  %275 = call float @dx.op.unary.f32(i32 7, float %272)  ; Saturate(value)
  %276 = call float @dx.op.unary.f32(i32 7, float %273)  ; Saturate(value)
  %277 = fadd fast float %274, 0xBFC70A3D80000000
  %278 = fadd fast float %275, 0xBFC70A3D80000000
  %279 = fadd fast float %276, 0xBFC70A3D80000000
  %280 = fmul fast float %277, %8
  %281 = fmul fast float %278, %8
  %282 = fmul fast float %279, %8
  %283 = fadd fast float %280, 0x3FC70A3D80000000
  %284 = fadd fast float %281, 0x3FC70A3D80000000
  %285 = fadd fast float %282, 0x3FC70A3D80000000
  %286 = call float @dx.op.unary.f32(i32 7, float %283)  ; Saturate(value)
  %287 = call float @dx.op.unary.f32(i32 7, float %284)  ; Saturate(value)
  %288 = call float @dx.op.unary.f32(i32 7, float %285)  ; Saturate(value)
  %289 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %289, label %290, label %1442

; <label>:290                                     ; preds = %257
  %291 = add i32 %65, -1
  %292 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %293 = call i32 @dx.op.binary.i32(i32 37, i32 %291, i32 0)  ; IMax(a,b)
  %294 = call i32 @dx.op.binary.i32(i32 38, i32 %292, i32 %60)  ; IMin(a,b)
  %295 = call i32 @dx.op.binary.i32(i32 38, i32 %293, i32 %61)  ; IMin(a,b)
  %296 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %294, i32 %295, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %297 = extractvalue %dx.types.ResRet.f32 %296, 0
  %298 = extractvalue %dx.types.ResRet.f32 %296, 1
  %299 = extractvalue %dx.types.ResRet.f32 %296, 2
  %300 = extractvalue %dx.types.ResRet.f32 %296, 3
  %301 = fcmp fast olt float %300, 0.000000e+00
  br i1 %301, label %302, label %336

; <label>:302                                     ; preds = %290
  %303 = fcmp fast ogt float %297, 0x3FA4B5DCC0000000
  %304 = fcmp fast ogt float %298, 0x3FA4B5DCC0000000
  %305 = fcmp fast ogt float %299, 0x3FA4B5DCC0000000
  %306 = select i1 %303, float 0.000000e+00, float 1.000000e+00
  %307 = select i1 %304, float 0.000000e+00, float 1.000000e+00
  %308 = select i1 %305, float 0.000000e+00, float 1.000000e+00
  %309 = fmul fast float %297, 0x3FB3D07220000000
  %310 = fmul fast float %298, 0x3FB3D07220000000
  %311 = fmul fast float %299, 0x3FB3D07220000000
  %312 = fadd fast float %297, 0x3FAC28F5C0000000
  %313 = fadd fast float %298, 0x3FAC28F5C0000000
  %314 = fadd fast float %299, 0x3FAC28F5C0000000
  %315 = fmul fast float %312, 0x3FEE54EDE0000000
  %316 = fmul fast float %313, 0x3FEE54EDE0000000
  %317 = fmul fast float %314, 0x3FEE54EDE0000000
  %318 = call float @dx.op.unary.f32(i32 23, float %315)  ; Log(value)
  %319 = call float @dx.op.unary.f32(i32 23, float %316)  ; Log(value)
  %320 = call float @dx.op.unary.f32(i32 23, float %317)  ; Log(value)
  %321 = fmul fast float %318, 0x4003333340000000
  %322 = fmul fast float %319, 0x4003333340000000
  %323 = fmul fast float %320, 0x4003333340000000
  %324 = call float @dx.op.unary.f32(i32 21, float %321)  ; Exp(value)
  %325 = call float @dx.op.unary.f32(i32 21, float %322)  ; Exp(value)
  %326 = call float @dx.op.unary.f32(i32 21, float %323)  ; Exp(value)
  %327 = fsub fast float %309, %324
  %328 = fsub fast float %310, %325
  %329 = fsub fast float %311, %326
  %330 = fmul fast float %327, %306
  %331 = fmul fast float %328, %307
  %332 = fmul fast float %329, %308
  %333 = fadd fast float %330, %324
  %334 = fadd fast float %331, %325
  %335 = fadd fast float %332, %326
  br label %551

; <label>:336                                     ; preds = %290
  %337 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %294, i32 %295, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %338 = extractvalue %dx.types.ResRet.f32 %337, 0
  %339 = fcmp fast ogt float %39, 5.000000e-01
  %340 = fcmp fast olt float %338, 1.000000e+00
  %341 = and i1 %339, %340
  br i1 %341, label %342, label %480

; <label>:342                                     ; preds = %336
  %343 = sitofp i32 %294 to float
  %344 = sitofp i32 %295 to float
  %345 = fadd fast float %343, 5.000000e-01
  %346 = fadd fast float %344, 5.000000e-01
  %347 = fdiv fast float %345, %46
  %348 = fdiv fast float %346, %47
  %349 = fmul fast float %347, 2.000000e+00
  %350 = fmul fast float %348, 2.000000e+00
  %351 = fadd fast float %349, -1.000000e+00
  %352 = fsub fast float 1.000000e+00, %350
  %353 = fmul fast float %351, %36
  %354 = call float @dx.op.tertiary.f32(i32 46, float %352, float %32, float %353)  ; FMad(a,b,c)
  %355 = call float @dx.op.tertiary.f32(i32 46, float %338, float %28, float %354)  ; FMad(a,b,c)
  %356 = fadd fast float %355, %24
  %357 = call float @dx.op.unary.f32(i32 6, float %356)  ; FAbs(value)
  %358 = fcmp fast ogt float %357, 0x3EB0C6F7A0000000
  br i1 %358, label %359, label %480

; <label>:359                                     ; preds = %342
  %360 = fmul fast float %351, %35
  %361 = call float @dx.op.tertiary.f32(i32 46, float %352, float %31, float %360)  ; FMad(a,b,c)
  %362 = call float @dx.op.tertiary.f32(i32 46, float %338, float %27, float %361)  ; FMad(a,b,c)
  %363 = fadd fast float %362, %23
  %364 = fmul fast float %351, %34
  %365 = call float @dx.op.tertiary.f32(i32 46, float %352, float %30, float %364)  ; FMad(a,b,c)
  %366 = call float @dx.op.tertiary.f32(i32 46, float %338, float %26, float %365)  ; FMad(a,b,c)
  %367 = fadd fast float %366, %22
  %368 = fmul fast float %351, %33
  %369 = call float @dx.op.tertiary.f32(i32 46, float %352, float %29, float %368)  ; FMad(a,b,c)
  %370 = call float @dx.op.tertiary.f32(i32 46, float %338, float %25, float %369)  ; FMad(a,b,c)
  %371 = fadd fast float %370, %21
  %372 = fdiv fast float %371, %356
  %373 = fdiv fast float %367, %356
  %374 = fdiv fast float %363, %356
  %375 = fsub fast float %372, %18
  %376 = fsub fast float %373, %19
  %377 = fsub fast float %374, %20
  %378 = fmul fast float %375, %375
  %379 = fmul fast float %376, %376
  %380 = fadd fast float %379, %378
  %381 = fmul fast float %377, %377
  %382 = fadd fast float %380, %381
  %383 = call float @dx.op.unary.f32(i32 24, float %382)  ; Sqrt(value)
  %384 = fsub fast float %383, %10
  %385 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %384)  ; FMax(a,b)
  %386 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %386, label %387, label %410

; <label>:387                                     ; preds = %359
  %388 = call float @dx.op.unary.f32(i32 6, float %376)  ; FAbs(value)
  %389 = fmul fast float %388, %12
  %390 = fcmp fast olt float %389, 0x3F50624DE0000000
  br i1 %390, label %391, label %394

; <label>:391                                     ; preds = %387
  %392 = fmul fast float %389, 5.000000e-01
  %393 = fsub fast float 1.000000e+00, %392
  br label %399

; <label>:394                                     ; preds = %387
  %395 = fmul fast float %389, 0xBFF7154760000000
  %396 = call float @dx.op.unary.f32(i32 21, float %395)  ; Exp(value)
  %397 = fsub fast float 1.000000e+00, %396
  %398 = fdiv fast float %397, %389
  br label %399

; <label>:399                                     ; preds = %394, %391
  %400 = phi float [ %393, %391 ], [ %398, %394 ]
  %401 = call float @dx.op.binary.f32(i32 36, float %373, float %19)  ; FMin(a,b)
  %402 = fsub fast float %401, %11
  %403 = fmul fast float %12, %402
  %404 = fsub fast float -0.000000e+00, %403
  %405 = call float @dx.op.binary.f32(i32 35, float %404, float -4.000000e+01)  ; FMax(a,b)
  %406 = call float @dx.op.binary.f32(i32 36, float %405, float 5.000000e+00)  ; FMin(a,b)
  %407 = fmul fast float %406, 0x3FF7154760000000
  %408 = call float @dx.op.unary.f32(i32 21, float %407)  ; Exp(value)
  %409 = fmul fast float %408, %400
  br label %410

; <label>:410                                     ; preds = %399, %359
  %411 = phi float [ %409, %399 ], [ 1.000000e+00, %359 ]
  %412 = fmul fast float %385, %17
  %413 = fmul fast float %412, %411
  %414 = fcmp fast ole float %383, %10
  %415 = fcmp fast olt float %383, 0x3F1A36E2E0000000
  %416 = or i1 %414, %415
  br i1 %416, label %463, label %417

; <label>:417                                     ; preds = %410
  %418 = fdiv fast float %10, %383
  %419 = fmul fast float %418, %375
  %420 = fmul fast float %418, %376
  %421 = fmul fast float %418, %377
  %422 = fadd fast float %419, %18
  %423 = fadd fast float %420, %19
  %424 = fadd fast float %421, %20
  %425 = fadd fast float %422, -9.000000e+02
  %426 = fadd fast float %423, -1.500000e+01
  %427 = fadd fast float %424, -7.500000e+02
  %428 = fmul fast float %425, 0x3F62345680000000
  %429 = fmul fast float %426, 0x3F62345680000000
  %430 = fmul fast float %427, 0x3F62345680000000
  %431 = call float @dx.op.dot3.f32(i32 55, float %428, float %429, float %430, float %428, float %429, float %430)  ; Dot3(ax,ay,az,bx,by,bz)
  %432 = fsub fast float 1.000000e+00, %431
  %433 = call float @dx.op.unary.f32(i32 7, float %432)  ; Saturate(value)
  %434 = fmul fast float %433, %433
  %435 = fadd fast float %422, %372
  %436 = fadd fast float %423, %373
  %437 = fadd fast float %424, %374
  %438 = fmul fast float %435, 0x3F52345680000000
  %439 = fadd fast float %438, -2.000000e+00
  %440 = fmul fast float %436, 0x3F52345680000000
  %441 = fadd fast float %440, 0xBFA1111120000000
  %442 = fmul fast float %437, 0x3F52345680000000
  %443 = fadd fast float %442, 0xBFFAAAAAC0000000
  %444 = call float @dx.op.dot3.f32(i32 55, float %439, float %441, float %443, float %439, float %441, float %443)  ; Dot3(ax,ay,az,bx,by,bz)
  %445 = fsub fast float 1.000000e+00, %444
  %446 = call float @dx.op.unary.f32(i32 7, float %445)  ; Saturate(value)
  %447 = fmul fast float %446, %446
  %448 = fmul fast float %447, 4.000000e+00
  %449 = fadd fast float %448, %434
  %450 = fadd fast float %372, -9.000000e+02
  %451 = fadd fast float %373, -1.500000e+01
  %452 = fadd fast float %374, -7.500000e+02
  %453 = fmul fast float %450, 0x3F62345680000000
  %454 = fmul fast float %451, 0x3F62345680000000
  %455 = fmul fast float %452, 0x3F62345680000000
  %456 = call float @dx.op.dot3.f32(i32 55, float %453, float %454, float %455, float %453, float %454, float %455)  ; Dot3(ax,ay,az,bx,by,bz)
  %457 = fsub fast float 1.000000e+00, %456
  %458 = call float @dx.op.unary.f32(i32 7, float %457)  ; Saturate(value)
  %459 = fmul fast float %458, %458
  %460 = fadd fast float %449, %459
  %461 = fmul fast float %384, 0x3F25D867E0000000
  %462 = fmul fast float %461, %460
  br label %463

; <label>:463                                     ; preds = %417, %410
  %464 = phi float [ %462, %417 ], [ 0.000000e+00, %410 ]
  %465 = fadd fast float %464, %413
  %466 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %465)  ; FMin(a,b)
  %467 = fmul fast float %466, 0xBFF7154760000000
  %468 = call float @dx.op.unary.f32(i32 21, float %467)  ; Exp(value)
  %469 = fsub fast float 1.000000e+00, %468
  %470 = call float @dx.op.binary.f32(i32 36, float %13, float %469)  ; FMin(a,b)
  %471 = fsub fast float %14, %297
  %472 = fsub fast float %15, %298
  %473 = fsub fast float %16, %299
  %474 = fmul fast float %470, %471
  %475 = fmul fast float %470, %472
  %476 = fmul fast float %470, %473
  %477 = fadd fast float %474, %297
  %478 = fadd fast float %475, %298
  %479 = fadd fast float %476, %299
  br label %480

; <label>:480                                     ; preds = %463, %342, %336
  %481 = phi float [ %477, %463 ], [ %297, %342 ], [ %297, %336 ]
  %482 = phi float [ %478, %463 ], [ %298, %342 ], [ %298, %336 ]
  %483 = phi float [ %479, %463 ], [ %299, %342 ], [ %299, %336 ]
  %484 = fadd fast float %6, 1.000000e+00
  %485 = fadd fast float %7, 1.000000e+00
  %486 = fsub fast float 1.000000e+00, %6
  %487 = fmul fast float %37, %484
  %488 = fmul fast float %37, %485
  %489 = fmul fast float %37, %486
  %490 = fmul fast float %487, %481
  %491 = fmul fast float %488, %482
  %492 = fmul fast float %489, %483
  %493 = fcmp fast ult float %38, 5.000000e-01
  br i1 %493, label %519, label %494

; <label>:494                                     ; preds = %480
  %495 = fmul fast float %490, 0x4004147AE0000000
  %496 = fmul fast float %491, 0x4004147AE0000000
  %497 = fmul fast float %492, 0x4004147AE0000000
  %498 = fadd fast float %495, 0x3F9EB851E0000000
  %499 = fadd fast float %496, 0x3F9EB851E0000000
  %500 = fadd fast float %497, 0x3F9EB851E0000000
  %501 = fmul fast float %498, %490
  %502 = fmul fast float %499, %491
  %503 = fmul fast float %500, %492
  %504 = fmul fast float %490, 0x400370A3E0000000
  %505 = fmul fast float %491, 0x400370A3E0000000
  %506 = fmul fast float %492, 0x400370A3E0000000
  %507 = fadd fast float %504, 0x3FE2E147A0000000
  %508 = fadd fast float %505, 0x3FE2E147A0000000
  %509 = fadd fast float %506, 0x3FE2E147A0000000
  %510 = fmul fast float %507, %490
  %511 = fmul fast float %508, %491
  %512 = fmul fast float %509, %492
  %513 = fadd fast float %510, 0x3FC1EB8520000000
  %514 = fadd fast float %511, 0x3FC1EB8520000000
  %515 = fadd fast float %512, 0x3FC1EB8520000000
  %516 = fdiv fast float %501, %513
  %517 = fdiv fast float %502, %514
  %518 = fdiv fast float %503, %515
  br label %519

; <label>:519                                     ; preds = %494, %480
  %520 = phi float [ %516, %494 ], [ %490, %480 ]
  %521 = phi float [ %517, %494 ], [ %491, %480 ]
  %522 = phi float [ %518, %494 ], [ %492, %480 ]
  %523 = call float @dx.op.unary.f32(i32 7, float %520)  ; Saturate(value)
  %524 = call float @dx.op.unary.f32(i32 7, float %521)  ; Saturate(value)
  %525 = call float @dx.op.unary.f32(i32 7, float %522)  ; Saturate(value)
  %526 = call float @dx.op.dot3.f32(i32 55, float %523, float %524, float %525, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %527 = fsub fast float %523, %526
  %528 = fsub fast float %524, %526
  %529 = fsub fast float %525, %526
  %530 = fmul fast float %527, %9
  %531 = fmul fast float %528, %9
  %532 = fmul fast float %529, %9
  %533 = fadd fast float %530, %526
  %534 = fadd fast float %531, %526
  %535 = fadd fast float %532, %526
  %536 = call float @dx.op.unary.f32(i32 7, float %533)  ; Saturate(value)
  %537 = call float @dx.op.unary.f32(i32 7, float %534)  ; Saturate(value)
  %538 = call float @dx.op.unary.f32(i32 7, float %535)  ; Saturate(value)
  %539 = fadd fast float %536, 0xBFC70A3D80000000
  %540 = fadd fast float %537, 0xBFC70A3D80000000
  %541 = fadd fast float %538, 0xBFC70A3D80000000
  %542 = fmul fast float %539, %8
  %543 = fmul fast float %540, %8
  %544 = fmul fast float %541, %8
  %545 = fadd fast float %542, 0x3FC70A3D80000000
  %546 = fadd fast float %543, 0x3FC70A3D80000000
  %547 = fadd fast float %544, 0x3FC70A3D80000000
  %548 = call float @dx.op.unary.f32(i32 7, float %545)  ; Saturate(value)
  %549 = call float @dx.op.unary.f32(i32 7, float %546)  ; Saturate(value)
  %550 = call float @dx.op.unary.f32(i32 7, float %547)  ; Saturate(value)
  br label %551

; <label>:551                                     ; preds = %519, %302
  %552 = phi float [ %333, %302 ], [ %548, %519 ]
  %553 = phi float [ %334, %302 ], [ %549, %519 ]
  %554 = phi float [ %335, %302 ], [ %550, %519 ]
  %555 = add i32 %65, 1
  %556 = call i32 @dx.op.binary.i32(i32 37, i32 %555, i32 0)  ; IMax(a,b)
  %557 = call i32 @dx.op.binary.i32(i32 38, i32 %556, i32 %61)  ; IMin(a,b)
  %558 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %294, i32 %557, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %559 = extractvalue %dx.types.ResRet.f32 %558, 0
  %560 = extractvalue %dx.types.ResRet.f32 %558, 1
  %561 = extractvalue %dx.types.ResRet.f32 %558, 2
  %562 = extractvalue %dx.types.ResRet.f32 %558, 3
  %563 = fcmp fast olt float %562, 0.000000e+00
  br i1 %563, label %564, label %598

; <label>:564                                     ; preds = %551
  %565 = fcmp fast ogt float %559, 0x3FA4B5DCC0000000
  %566 = fcmp fast ogt float %560, 0x3FA4B5DCC0000000
  %567 = fcmp fast ogt float %561, 0x3FA4B5DCC0000000
  %568 = select i1 %565, float 0.000000e+00, float 1.000000e+00
  %569 = select i1 %566, float 0.000000e+00, float 1.000000e+00
  %570 = select i1 %567, float 0.000000e+00, float 1.000000e+00
  %571 = fmul fast float %559, 0x3FB3D07220000000
  %572 = fmul fast float %560, 0x3FB3D07220000000
  %573 = fmul fast float %561, 0x3FB3D07220000000
  %574 = fadd fast float %559, 0x3FAC28F5C0000000
  %575 = fadd fast float %560, 0x3FAC28F5C0000000
  %576 = fadd fast float %561, 0x3FAC28F5C0000000
  %577 = fmul fast float %574, 0x3FEE54EDE0000000
  %578 = fmul fast float %575, 0x3FEE54EDE0000000
  %579 = fmul fast float %576, 0x3FEE54EDE0000000
  %580 = call float @dx.op.unary.f32(i32 23, float %577)  ; Log(value)
  %581 = call float @dx.op.unary.f32(i32 23, float %578)  ; Log(value)
  %582 = call float @dx.op.unary.f32(i32 23, float %579)  ; Log(value)
  %583 = fmul fast float %580, 0x4003333340000000
  %584 = fmul fast float %581, 0x4003333340000000
  %585 = fmul fast float %582, 0x4003333340000000
  %586 = call float @dx.op.unary.f32(i32 21, float %583)  ; Exp(value)
  %587 = call float @dx.op.unary.f32(i32 21, float %584)  ; Exp(value)
  %588 = call float @dx.op.unary.f32(i32 21, float %585)  ; Exp(value)
  %589 = fsub fast float %571, %586
  %590 = fsub fast float %572, %587
  %591 = fsub fast float %573, %588
  %592 = fmul fast float %589, %568
  %593 = fmul fast float %590, %569
  %594 = fmul fast float %591, %570
  %595 = fadd fast float %592, %586
  %596 = fadd fast float %593, %587
  %597 = fadd fast float %594, %588
  br label %813

; <label>:598                                     ; preds = %551
  %599 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %294, i32 %557, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %600 = extractvalue %dx.types.ResRet.f32 %599, 0
  %601 = fcmp fast ogt float %39, 5.000000e-01
  %602 = fcmp fast olt float %600, 1.000000e+00
  %603 = and i1 %601, %602
  br i1 %603, label %604, label %742

; <label>:604                                     ; preds = %598
  %605 = sitofp i32 %294 to float
  %606 = sitofp i32 %557 to float
  %607 = fadd fast float %605, 5.000000e-01
  %608 = fadd fast float %606, 5.000000e-01
  %609 = fdiv fast float %607, %46
  %610 = fdiv fast float %608, %47
  %611 = fmul fast float %609, 2.000000e+00
  %612 = fmul fast float %610, 2.000000e+00
  %613 = fadd fast float %611, -1.000000e+00
  %614 = fsub fast float 1.000000e+00, %612
  %615 = fmul fast float %613, %36
  %616 = call float @dx.op.tertiary.f32(i32 46, float %614, float %32, float %615)  ; FMad(a,b,c)
  %617 = call float @dx.op.tertiary.f32(i32 46, float %600, float %28, float %616)  ; FMad(a,b,c)
  %618 = fadd fast float %617, %24
  %619 = call float @dx.op.unary.f32(i32 6, float %618)  ; FAbs(value)
  %620 = fcmp fast ogt float %619, 0x3EB0C6F7A0000000
  br i1 %620, label %621, label %742

; <label>:621                                     ; preds = %604
  %622 = fmul fast float %613, %35
  %623 = call float @dx.op.tertiary.f32(i32 46, float %614, float %31, float %622)  ; FMad(a,b,c)
  %624 = call float @dx.op.tertiary.f32(i32 46, float %600, float %27, float %623)  ; FMad(a,b,c)
  %625 = fadd fast float %624, %23
  %626 = fmul fast float %613, %34
  %627 = call float @dx.op.tertiary.f32(i32 46, float %614, float %30, float %626)  ; FMad(a,b,c)
  %628 = call float @dx.op.tertiary.f32(i32 46, float %600, float %26, float %627)  ; FMad(a,b,c)
  %629 = fadd fast float %628, %22
  %630 = fmul fast float %613, %33
  %631 = call float @dx.op.tertiary.f32(i32 46, float %614, float %29, float %630)  ; FMad(a,b,c)
  %632 = call float @dx.op.tertiary.f32(i32 46, float %600, float %25, float %631)  ; FMad(a,b,c)
  %633 = fadd fast float %632, %21
  %634 = fdiv fast float %633, %618
  %635 = fdiv fast float %629, %618
  %636 = fdiv fast float %625, %618
  %637 = fsub fast float %634, %18
  %638 = fsub fast float %635, %19
  %639 = fsub fast float %636, %20
  %640 = fmul fast float %637, %637
  %641 = fmul fast float %638, %638
  %642 = fadd fast float %641, %640
  %643 = fmul fast float %639, %639
  %644 = fadd fast float %642, %643
  %645 = call float @dx.op.unary.f32(i32 24, float %644)  ; Sqrt(value)
  %646 = fsub fast float %645, %10
  %647 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %646)  ; FMax(a,b)
  %648 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %648, label %649, label %672

; <label>:649                                     ; preds = %621
  %650 = call float @dx.op.unary.f32(i32 6, float %638)  ; FAbs(value)
  %651 = fmul fast float %650, %12
  %652 = fcmp fast olt float %651, 0x3F50624DE0000000
  br i1 %652, label %653, label %656

; <label>:653                                     ; preds = %649
  %654 = fmul fast float %651, 5.000000e-01
  %655 = fsub fast float 1.000000e+00, %654
  br label %661

; <label>:656                                     ; preds = %649
  %657 = fmul fast float %651, 0xBFF7154760000000
  %658 = call float @dx.op.unary.f32(i32 21, float %657)  ; Exp(value)
  %659 = fsub fast float 1.000000e+00, %658
  %660 = fdiv fast float %659, %651
  br label %661

; <label>:661                                     ; preds = %656, %653
  %662 = phi float [ %655, %653 ], [ %660, %656 ]
  %663 = call float @dx.op.binary.f32(i32 36, float %635, float %19)  ; FMin(a,b)
  %664 = fsub fast float %663, %11
  %665 = fmul fast float %12, %664
  %666 = fsub fast float -0.000000e+00, %665
  %667 = call float @dx.op.binary.f32(i32 35, float %666, float -4.000000e+01)  ; FMax(a,b)
  %668 = call float @dx.op.binary.f32(i32 36, float %667, float 5.000000e+00)  ; FMin(a,b)
  %669 = fmul fast float %668, 0x3FF7154760000000
  %670 = call float @dx.op.unary.f32(i32 21, float %669)  ; Exp(value)
  %671 = fmul fast float %670, %662
  br label %672

; <label>:672                                     ; preds = %661, %621
  %673 = phi float [ %671, %661 ], [ 1.000000e+00, %621 ]
  %674 = fmul fast float %647, %17
  %675 = fmul fast float %674, %673
  %676 = fcmp fast ole float %645, %10
  %677 = fcmp fast olt float %645, 0x3F1A36E2E0000000
  %678 = or i1 %676, %677
  br i1 %678, label %725, label %679

; <label>:679                                     ; preds = %672
  %680 = fdiv fast float %10, %645
  %681 = fmul fast float %680, %637
  %682 = fmul fast float %680, %638
  %683 = fmul fast float %680, %639
  %684 = fadd fast float %681, %18
  %685 = fadd fast float %682, %19
  %686 = fadd fast float %683, %20
  %687 = fadd fast float %684, -9.000000e+02
  %688 = fadd fast float %685, -1.500000e+01
  %689 = fadd fast float %686, -7.500000e+02
  %690 = fmul fast float %687, 0x3F62345680000000
  %691 = fmul fast float %688, 0x3F62345680000000
  %692 = fmul fast float %689, 0x3F62345680000000
  %693 = call float @dx.op.dot3.f32(i32 55, float %690, float %691, float %692, float %690, float %691, float %692)  ; Dot3(ax,ay,az,bx,by,bz)
  %694 = fsub fast float 1.000000e+00, %693
  %695 = call float @dx.op.unary.f32(i32 7, float %694)  ; Saturate(value)
  %696 = fmul fast float %695, %695
  %697 = fadd fast float %684, %634
  %698 = fadd fast float %685, %635
  %699 = fadd fast float %686, %636
  %700 = fmul fast float %697, 0x3F52345680000000
  %701 = fadd fast float %700, -2.000000e+00
  %702 = fmul fast float %698, 0x3F52345680000000
  %703 = fadd fast float %702, 0xBFA1111120000000
  %704 = fmul fast float %699, 0x3F52345680000000
  %705 = fadd fast float %704, 0xBFFAAAAAC0000000
  %706 = call float @dx.op.dot3.f32(i32 55, float %701, float %703, float %705, float %701, float %703, float %705)  ; Dot3(ax,ay,az,bx,by,bz)
  %707 = fsub fast float 1.000000e+00, %706
  %708 = call float @dx.op.unary.f32(i32 7, float %707)  ; Saturate(value)
  %709 = fmul fast float %708, %708
  %710 = fmul fast float %709, 4.000000e+00
  %711 = fadd fast float %710, %696
  %712 = fadd fast float %634, -9.000000e+02
  %713 = fadd fast float %635, -1.500000e+01
  %714 = fadd fast float %636, -7.500000e+02
  %715 = fmul fast float %712, 0x3F62345680000000
  %716 = fmul fast float %713, 0x3F62345680000000
  %717 = fmul fast float %714, 0x3F62345680000000
  %718 = call float @dx.op.dot3.f32(i32 55, float %715, float %716, float %717, float %715, float %716, float %717)  ; Dot3(ax,ay,az,bx,by,bz)
  %719 = fsub fast float 1.000000e+00, %718
  %720 = call float @dx.op.unary.f32(i32 7, float %719)  ; Saturate(value)
  %721 = fmul fast float %720, %720
  %722 = fadd fast float %711, %721
  %723 = fmul fast float %646, 0x3F25D867E0000000
  %724 = fmul fast float %723, %722
  br label %725

; <label>:725                                     ; preds = %679, %672
  %726 = phi float [ %724, %679 ], [ 0.000000e+00, %672 ]
  %727 = fadd fast float %726, %675
  %728 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %727)  ; FMin(a,b)
  %729 = fmul fast float %728, 0xBFF7154760000000
  %730 = call float @dx.op.unary.f32(i32 21, float %729)  ; Exp(value)
  %731 = fsub fast float 1.000000e+00, %730
  %732 = call float @dx.op.binary.f32(i32 36, float %13, float %731)  ; FMin(a,b)
  %733 = fsub fast float %14, %559
  %734 = fsub fast float %15, %560
  %735 = fsub fast float %16, %561
  %736 = fmul fast float %732, %733
  %737 = fmul fast float %732, %734
  %738 = fmul fast float %732, %735
  %739 = fadd fast float %736, %559
  %740 = fadd fast float %737, %560
  %741 = fadd fast float %738, %561
  br label %742

; <label>:742                                     ; preds = %725, %604, %598
  %743 = phi float [ %739, %725 ], [ %559, %604 ], [ %559, %598 ]
  %744 = phi float [ %740, %725 ], [ %560, %604 ], [ %560, %598 ]
  %745 = phi float [ %741, %725 ], [ %561, %604 ], [ %561, %598 ]
  %746 = fadd fast float %6, 1.000000e+00
  %747 = fadd fast float %7, 1.000000e+00
  %748 = fsub fast float 1.000000e+00, %6
  %749 = fmul fast float %37, %746
  %750 = fmul fast float %37, %747
  %751 = fmul fast float %37, %748
  %752 = fmul fast float %749, %743
  %753 = fmul fast float %750, %744
  %754 = fmul fast float %751, %745
  %755 = fcmp fast ult float %38, 5.000000e-01
  br i1 %755, label %781, label %756

; <label>:756                                     ; preds = %742
  %757 = fmul fast float %752, 0x4004147AE0000000
  %758 = fmul fast float %753, 0x4004147AE0000000
  %759 = fmul fast float %754, 0x4004147AE0000000
  %760 = fadd fast float %757, 0x3F9EB851E0000000
  %761 = fadd fast float %758, 0x3F9EB851E0000000
  %762 = fadd fast float %759, 0x3F9EB851E0000000
  %763 = fmul fast float %760, %752
  %764 = fmul fast float %761, %753
  %765 = fmul fast float %762, %754
  %766 = fmul fast float %752, 0x400370A3E0000000
  %767 = fmul fast float %753, 0x400370A3E0000000
  %768 = fmul fast float %754, 0x400370A3E0000000
  %769 = fadd fast float %766, 0x3FE2E147A0000000
  %770 = fadd fast float %767, 0x3FE2E147A0000000
  %771 = fadd fast float %768, 0x3FE2E147A0000000
  %772 = fmul fast float %769, %752
  %773 = fmul fast float %770, %753
  %774 = fmul fast float %771, %754
  %775 = fadd fast float %772, 0x3FC1EB8520000000
  %776 = fadd fast float %773, 0x3FC1EB8520000000
  %777 = fadd fast float %774, 0x3FC1EB8520000000
  %778 = fdiv fast float %763, %775
  %779 = fdiv fast float %764, %776
  %780 = fdiv fast float %765, %777
  br label %781

; <label>:781                                     ; preds = %756, %742
  %782 = phi float [ %778, %756 ], [ %752, %742 ]
  %783 = phi float [ %779, %756 ], [ %753, %742 ]
  %784 = phi float [ %780, %756 ], [ %754, %742 ]
  %785 = call float @dx.op.unary.f32(i32 7, float %782)  ; Saturate(value)
  %786 = call float @dx.op.unary.f32(i32 7, float %783)  ; Saturate(value)
  %787 = call float @dx.op.unary.f32(i32 7, float %784)  ; Saturate(value)
  %788 = call float @dx.op.dot3.f32(i32 55, float %785, float %786, float %787, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %789 = fsub fast float %785, %788
  %790 = fsub fast float %786, %788
  %791 = fsub fast float %787, %788
  %792 = fmul fast float %789, %9
  %793 = fmul fast float %790, %9
  %794 = fmul fast float %791, %9
  %795 = fadd fast float %792, %788
  %796 = fadd fast float %793, %788
  %797 = fadd fast float %794, %788
  %798 = call float @dx.op.unary.f32(i32 7, float %795)  ; Saturate(value)
  %799 = call float @dx.op.unary.f32(i32 7, float %796)  ; Saturate(value)
  %800 = call float @dx.op.unary.f32(i32 7, float %797)  ; Saturate(value)
  %801 = fadd fast float %798, 0xBFC70A3D80000000
  %802 = fadd fast float %799, 0xBFC70A3D80000000
  %803 = fadd fast float %800, 0xBFC70A3D80000000
  %804 = fmul fast float %801, %8
  %805 = fmul fast float %802, %8
  %806 = fmul fast float %803, %8
  %807 = fadd fast float %804, 0x3FC70A3D80000000
  %808 = fadd fast float %805, 0x3FC70A3D80000000
  %809 = fadd fast float %806, 0x3FC70A3D80000000
  %810 = call float @dx.op.unary.f32(i32 7, float %807)  ; Saturate(value)
  %811 = call float @dx.op.unary.f32(i32 7, float %808)  ; Saturate(value)
  %812 = call float @dx.op.unary.f32(i32 7, float %809)  ; Saturate(value)
  br label %813

; <label>:813                                     ; preds = %781, %564
  %814 = phi float [ %595, %564 ], [ %810, %781 ]
  %815 = phi float [ %596, %564 ], [ %811, %781 ]
  %816 = phi float [ %597, %564 ], [ %812, %781 ]
  %817 = add i32 %64, -1
  %818 = call i32 @dx.op.binary.i32(i32 37, i32 %817, i32 0)  ; IMax(a,b)
  %819 = call i32 @dx.op.binary.i32(i32 37, i32 %65, i32 0)  ; IMax(a,b)
  %820 = call i32 @dx.op.binary.i32(i32 38, i32 %818, i32 %60)  ; IMin(a,b)
  %821 = call i32 @dx.op.binary.i32(i32 38, i32 %819, i32 %61)  ; IMin(a,b)
  %822 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %820, i32 %821, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %823 = extractvalue %dx.types.ResRet.f32 %822, 0
  %824 = extractvalue %dx.types.ResRet.f32 %822, 1
  %825 = extractvalue %dx.types.ResRet.f32 %822, 2
  %826 = extractvalue %dx.types.ResRet.f32 %822, 3
  %827 = fcmp fast olt float %826, 0.000000e+00
  br i1 %827, label %828, label %862

; <label>:828                                     ; preds = %813
  %829 = fcmp fast ogt float %823, 0x3FA4B5DCC0000000
  %830 = fcmp fast ogt float %824, 0x3FA4B5DCC0000000
  %831 = fcmp fast ogt float %825, 0x3FA4B5DCC0000000
  %832 = select i1 %829, float 0.000000e+00, float 1.000000e+00
  %833 = select i1 %830, float 0.000000e+00, float 1.000000e+00
  %834 = select i1 %831, float 0.000000e+00, float 1.000000e+00
  %835 = fmul fast float %823, 0x3FB3D07220000000
  %836 = fmul fast float %824, 0x3FB3D07220000000
  %837 = fmul fast float %825, 0x3FB3D07220000000
  %838 = fadd fast float %823, 0x3FAC28F5C0000000
  %839 = fadd fast float %824, 0x3FAC28F5C0000000
  %840 = fadd fast float %825, 0x3FAC28F5C0000000
  %841 = fmul fast float %838, 0x3FEE54EDE0000000
  %842 = fmul fast float %839, 0x3FEE54EDE0000000
  %843 = fmul fast float %840, 0x3FEE54EDE0000000
  %844 = call float @dx.op.unary.f32(i32 23, float %841)  ; Log(value)
  %845 = call float @dx.op.unary.f32(i32 23, float %842)  ; Log(value)
  %846 = call float @dx.op.unary.f32(i32 23, float %843)  ; Log(value)
  %847 = fmul fast float %844, 0x4003333340000000
  %848 = fmul fast float %845, 0x4003333340000000
  %849 = fmul fast float %846, 0x4003333340000000
  %850 = call float @dx.op.unary.f32(i32 21, float %847)  ; Exp(value)
  %851 = call float @dx.op.unary.f32(i32 21, float %848)  ; Exp(value)
  %852 = call float @dx.op.unary.f32(i32 21, float %849)  ; Exp(value)
  %853 = fsub fast float %835, %850
  %854 = fsub fast float %836, %851
  %855 = fsub fast float %837, %852
  %856 = fmul fast float %853, %832
  %857 = fmul fast float %854, %833
  %858 = fmul fast float %855, %834
  %859 = fadd fast float %856, %850
  %860 = fadd fast float %857, %851
  %861 = fadd fast float %858, %852
  br label %1077

; <label>:862                                     ; preds = %813
  %863 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %820, i32 %821, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %864 = extractvalue %dx.types.ResRet.f32 %863, 0
  %865 = fcmp fast ogt float %39, 5.000000e-01
  %866 = fcmp fast olt float %864, 1.000000e+00
  %867 = and i1 %865, %866
  br i1 %867, label %868, label %1006

; <label>:868                                     ; preds = %862
  %869 = sitofp i32 %820 to float
  %870 = sitofp i32 %821 to float
  %871 = fadd fast float %869, 5.000000e-01
  %872 = fadd fast float %870, 5.000000e-01
  %873 = fdiv fast float %871, %46
  %874 = fdiv fast float %872, %47
  %875 = fmul fast float %873, 2.000000e+00
  %876 = fmul fast float %874, 2.000000e+00
  %877 = fadd fast float %875, -1.000000e+00
  %878 = fsub fast float 1.000000e+00, %876
  %879 = fmul fast float %877, %36
  %880 = call float @dx.op.tertiary.f32(i32 46, float %878, float %32, float %879)  ; FMad(a,b,c)
  %881 = call float @dx.op.tertiary.f32(i32 46, float %864, float %28, float %880)  ; FMad(a,b,c)
  %882 = fadd fast float %881, %24
  %883 = call float @dx.op.unary.f32(i32 6, float %882)  ; FAbs(value)
  %884 = fcmp fast ogt float %883, 0x3EB0C6F7A0000000
  br i1 %884, label %885, label %1006

; <label>:885                                     ; preds = %868
  %886 = fmul fast float %877, %35
  %887 = call float @dx.op.tertiary.f32(i32 46, float %878, float %31, float %886)  ; FMad(a,b,c)
  %888 = call float @dx.op.tertiary.f32(i32 46, float %864, float %27, float %887)  ; FMad(a,b,c)
  %889 = fadd fast float %888, %23
  %890 = fmul fast float %877, %34
  %891 = call float @dx.op.tertiary.f32(i32 46, float %878, float %30, float %890)  ; FMad(a,b,c)
  %892 = call float @dx.op.tertiary.f32(i32 46, float %864, float %26, float %891)  ; FMad(a,b,c)
  %893 = fadd fast float %892, %22
  %894 = fmul fast float %877, %33
  %895 = call float @dx.op.tertiary.f32(i32 46, float %878, float %29, float %894)  ; FMad(a,b,c)
  %896 = call float @dx.op.tertiary.f32(i32 46, float %864, float %25, float %895)  ; FMad(a,b,c)
  %897 = fadd fast float %896, %21
  %898 = fdiv fast float %897, %882
  %899 = fdiv fast float %893, %882
  %900 = fdiv fast float %889, %882
  %901 = fsub fast float %898, %18
  %902 = fsub fast float %899, %19
  %903 = fsub fast float %900, %20
  %904 = fmul fast float %901, %901
  %905 = fmul fast float %902, %902
  %906 = fadd fast float %905, %904
  %907 = fmul fast float %903, %903
  %908 = fadd fast float %906, %907
  %909 = call float @dx.op.unary.f32(i32 24, float %908)  ; Sqrt(value)
  %910 = fsub fast float %909, %10
  %911 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %910)  ; FMax(a,b)
  %912 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %912, label %913, label %936

; <label>:913                                     ; preds = %885
  %914 = call float @dx.op.unary.f32(i32 6, float %902)  ; FAbs(value)
  %915 = fmul fast float %914, %12
  %916 = fcmp fast olt float %915, 0x3F50624DE0000000
  br i1 %916, label %917, label %920

; <label>:917                                     ; preds = %913
  %918 = fmul fast float %915, 5.000000e-01
  %919 = fsub fast float 1.000000e+00, %918
  br label %925

; <label>:920                                     ; preds = %913
  %921 = fmul fast float %915, 0xBFF7154760000000
  %922 = call float @dx.op.unary.f32(i32 21, float %921)  ; Exp(value)
  %923 = fsub fast float 1.000000e+00, %922
  %924 = fdiv fast float %923, %915
  br label %925

; <label>:925                                     ; preds = %920, %917
  %926 = phi float [ %919, %917 ], [ %924, %920 ]
  %927 = call float @dx.op.binary.f32(i32 36, float %899, float %19)  ; FMin(a,b)
  %928 = fsub fast float %927, %11
  %929 = fmul fast float %12, %928
  %930 = fsub fast float -0.000000e+00, %929
  %931 = call float @dx.op.binary.f32(i32 35, float %930, float -4.000000e+01)  ; FMax(a,b)
  %932 = call float @dx.op.binary.f32(i32 36, float %931, float 5.000000e+00)  ; FMin(a,b)
  %933 = fmul fast float %932, 0x3FF7154760000000
  %934 = call float @dx.op.unary.f32(i32 21, float %933)  ; Exp(value)
  %935 = fmul fast float %934, %926
  br label %936

; <label>:936                                     ; preds = %925, %885
  %937 = phi float [ %935, %925 ], [ 1.000000e+00, %885 ]
  %938 = fmul fast float %911, %17
  %939 = fmul fast float %938, %937
  %940 = fcmp fast ole float %909, %10
  %941 = fcmp fast olt float %909, 0x3F1A36E2E0000000
  %942 = or i1 %940, %941
  br i1 %942, label %989, label %943

; <label>:943                                     ; preds = %936
  %944 = fdiv fast float %10, %909
  %945 = fmul fast float %944, %901
  %946 = fmul fast float %944, %902
  %947 = fmul fast float %944, %903
  %948 = fadd fast float %945, %18
  %949 = fadd fast float %946, %19
  %950 = fadd fast float %947, %20
  %951 = fadd fast float %948, -9.000000e+02
  %952 = fadd fast float %949, -1.500000e+01
  %953 = fadd fast float %950, -7.500000e+02
  %954 = fmul fast float %951, 0x3F62345680000000
  %955 = fmul fast float %952, 0x3F62345680000000
  %956 = fmul fast float %953, 0x3F62345680000000
  %957 = call float @dx.op.dot3.f32(i32 55, float %954, float %955, float %956, float %954, float %955, float %956)  ; Dot3(ax,ay,az,bx,by,bz)
  %958 = fsub fast float 1.000000e+00, %957
  %959 = call float @dx.op.unary.f32(i32 7, float %958)  ; Saturate(value)
  %960 = fmul fast float %959, %959
  %961 = fadd fast float %948, %898
  %962 = fadd fast float %949, %899
  %963 = fadd fast float %950, %900
  %964 = fmul fast float %961, 0x3F52345680000000
  %965 = fadd fast float %964, -2.000000e+00
  %966 = fmul fast float %962, 0x3F52345680000000
  %967 = fadd fast float %966, 0xBFA1111120000000
  %968 = fmul fast float %963, 0x3F52345680000000
  %969 = fadd fast float %968, 0xBFFAAAAAC0000000
  %970 = call float @dx.op.dot3.f32(i32 55, float %965, float %967, float %969, float %965, float %967, float %969)  ; Dot3(ax,ay,az,bx,by,bz)
  %971 = fsub fast float 1.000000e+00, %970
  %972 = call float @dx.op.unary.f32(i32 7, float %971)  ; Saturate(value)
  %973 = fmul fast float %972, %972
  %974 = fmul fast float %973, 4.000000e+00
  %975 = fadd fast float %974, %960
  %976 = fadd fast float %898, -9.000000e+02
  %977 = fadd fast float %899, -1.500000e+01
  %978 = fadd fast float %900, -7.500000e+02
  %979 = fmul fast float %976, 0x3F62345680000000
  %980 = fmul fast float %977, 0x3F62345680000000
  %981 = fmul fast float %978, 0x3F62345680000000
  %982 = call float @dx.op.dot3.f32(i32 55, float %979, float %980, float %981, float %979, float %980, float %981)  ; Dot3(ax,ay,az,bx,by,bz)
  %983 = fsub fast float 1.000000e+00, %982
  %984 = call float @dx.op.unary.f32(i32 7, float %983)  ; Saturate(value)
  %985 = fmul fast float %984, %984
  %986 = fadd fast float %975, %985
  %987 = fmul fast float %910, 0x3F25D867E0000000
  %988 = fmul fast float %987, %986
  br label %989

; <label>:989                                     ; preds = %943, %936
  %990 = phi float [ %988, %943 ], [ 0.000000e+00, %936 ]
  %991 = fadd fast float %990, %939
  %992 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %991)  ; FMin(a,b)
  %993 = fmul fast float %992, 0xBFF7154760000000
  %994 = call float @dx.op.unary.f32(i32 21, float %993)  ; Exp(value)
  %995 = fsub fast float 1.000000e+00, %994
  %996 = call float @dx.op.binary.f32(i32 36, float %13, float %995)  ; FMin(a,b)
  %997 = fsub fast float %14, %823
  %998 = fsub fast float %15, %824
  %999 = fsub fast float %16, %825
  %1000 = fmul fast float %996, %997
  %1001 = fmul fast float %996, %998
  %1002 = fmul fast float %996, %999
  %1003 = fadd fast float %1000, %823
  %1004 = fadd fast float %1001, %824
  %1005 = fadd fast float %1002, %825
  br label %1006

; <label>:1006                                    ; preds = %989, %868, %862
  %1007 = phi float [ %1003, %989 ], [ %823, %868 ], [ %823, %862 ]
  %1008 = phi float [ %1004, %989 ], [ %824, %868 ], [ %824, %862 ]
  %1009 = phi float [ %1005, %989 ], [ %825, %868 ], [ %825, %862 ]
  %1010 = fadd fast float %6, 1.000000e+00
  %1011 = fadd fast float %7, 1.000000e+00
  %1012 = fsub fast float 1.000000e+00, %6
  %1013 = fmul fast float %37, %1010
  %1014 = fmul fast float %37, %1011
  %1015 = fmul fast float %37, %1012
  %1016 = fmul fast float %1013, %1007
  %1017 = fmul fast float %1014, %1008
  %1018 = fmul fast float %1015, %1009
  %1019 = fcmp fast ult float %38, 5.000000e-01
  br i1 %1019, label %1045, label %1020

; <label>:1020                                    ; preds = %1006
  %1021 = fmul fast float %1016, 0x4004147AE0000000
  %1022 = fmul fast float %1017, 0x4004147AE0000000
  %1023 = fmul fast float %1018, 0x4004147AE0000000
  %1024 = fadd fast float %1021, 0x3F9EB851E0000000
  %1025 = fadd fast float %1022, 0x3F9EB851E0000000
  %1026 = fadd fast float %1023, 0x3F9EB851E0000000
  %1027 = fmul fast float %1024, %1016
  %1028 = fmul fast float %1025, %1017
  %1029 = fmul fast float %1026, %1018
  %1030 = fmul fast float %1016, 0x400370A3E0000000
  %1031 = fmul fast float %1017, 0x400370A3E0000000
  %1032 = fmul fast float %1018, 0x400370A3E0000000
  %1033 = fadd fast float %1030, 0x3FE2E147A0000000
  %1034 = fadd fast float %1031, 0x3FE2E147A0000000
  %1035 = fadd fast float %1032, 0x3FE2E147A0000000
  %1036 = fmul fast float %1033, %1016
  %1037 = fmul fast float %1034, %1017
  %1038 = fmul fast float %1035, %1018
  %1039 = fadd fast float %1036, 0x3FC1EB8520000000
  %1040 = fadd fast float %1037, 0x3FC1EB8520000000
  %1041 = fadd fast float %1038, 0x3FC1EB8520000000
  %1042 = fdiv fast float %1027, %1039
  %1043 = fdiv fast float %1028, %1040
  %1044 = fdiv fast float %1029, %1041
  br label %1045

; <label>:1045                                    ; preds = %1020, %1006
  %1046 = phi float [ %1042, %1020 ], [ %1016, %1006 ]
  %1047 = phi float [ %1043, %1020 ], [ %1017, %1006 ]
  %1048 = phi float [ %1044, %1020 ], [ %1018, %1006 ]
  %1049 = call float @dx.op.unary.f32(i32 7, float %1046)  ; Saturate(value)
  %1050 = call float @dx.op.unary.f32(i32 7, float %1047)  ; Saturate(value)
  %1051 = call float @dx.op.unary.f32(i32 7, float %1048)  ; Saturate(value)
  %1052 = call float @dx.op.dot3.f32(i32 55, float %1049, float %1050, float %1051, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1053 = fsub fast float %1049, %1052
  %1054 = fsub fast float %1050, %1052
  %1055 = fsub fast float %1051, %1052
  %1056 = fmul fast float %1053, %9
  %1057 = fmul fast float %1054, %9
  %1058 = fmul fast float %1055, %9
  %1059 = fadd fast float %1056, %1052
  %1060 = fadd fast float %1057, %1052
  %1061 = fadd fast float %1058, %1052
  %1062 = call float @dx.op.unary.f32(i32 7, float %1059)  ; Saturate(value)
  %1063 = call float @dx.op.unary.f32(i32 7, float %1060)  ; Saturate(value)
  %1064 = call float @dx.op.unary.f32(i32 7, float %1061)  ; Saturate(value)
  %1065 = fadd fast float %1062, 0xBFC70A3D80000000
  %1066 = fadd fast float %1063, 0xBFC70A3D80000000
  %1067 = fadd fast float %1064, 0xBFC70A3D80000000
  %1068 = fmul fast float %1065, %8
  %1069 = fmul fast float %1066, %8
  %1070 = fmul fast float %1067, %8
  %1071 = fadd fast float %1068, 0x3FC70A3D80000000
  %1072 = fadd fast float %1069, 0x3FC70A3D80000000
  %1073 = fadd fast float %1070, 0x3FC70A3D80000000
  %1074 = call float @dx.op.unary.f32(i32 7, float %1071)  ; Saturate(value)
  %1075 = call float @dx.op.unary.f32(i32 7, float %1072)  ; Saturate(value)
  %1076 = call float @dx.op.unary.f32(i32 7, float %1073)  ; Saturate(value)
  br label %1077

; <label>:1077                                    ; preds = %1045, %828
  %1078 = phi float [ %859, %828 ], [ %1074, %1045 ]
  %1079 = phi float [ %860, %828 ], [ %1075, %1045 ]
  %1080 = phi float [ %861, %828 ], [ %1076, %1045 ]
  %1081 = add i32 %64, 1
  %1082 = call i32 @dx.op.binary.i32(i32 37, i32 %1081, i32 0)  ; IMax(a,b)
  %1083 = call i32 @dx.op.binary.i32(i32 38, i32 %1082, i32 %60)  ; IMin(a,b)
  %1084 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1083, i32 %821, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1085 = extractvalue %dx.types.ResRet.f32 %1084, 0
  %1086 = extractvalue %dx.types.ResRet.f32 %1084, 1
  %1087 = extractvalue %dx.types.ResRet.f32 %1084, 2
  %1088 = extractvalue %dx.types.ResRet.f32 %1084, 3
  %1089 = fcmp fast olt float %1088, 0.000000e+00
  br i1 %1089, label %1090, label %1124

; <label>:1090                                    ; preds = %1077
  %1091 = fcmp fast ogt float %1085, 0x3FA4B5DCC0000000
  %1092 = fcmp fast ogt float %1086, 0x3FA4B5DCC0000000
  %1093 = fcmp fast ogt float %1087, 0x3FA4B5DCC0000000
  %1094 = select i1 %1091, float 0.000000e+00, float 1.000000e+00
  %1095 = select i1 %1092, float 0.000000e+00, float 1.000000e+00
  %1096 = select i1 %1093, float 0.000000e+00, float 1.000000e+00
  %1097 = fmul fast float %1085, 0x3FB3D07220000000
  %1098 = fmul fast float %1086, 0x3FB3D07220000000
  %1099 = fmul fast float %1087, 0x3FB3D07220000000
  %1100 = fadd fast float %1085, 0x3FAC28F5C0000000
  %1101 = fadd fast float %1086, 0x3FAC28F5C0000000
  %1102 = fadd fast float %1087, 0x3FAC28F5C0000000
  %1103 = fmul fast float %1100, 0x3FEE54EDE0000000
  %1104 = fmul fast float %1101, 0x3FEE54EDE0000000
  %1105 = fmul fast float %1102, 0x3FEE54EDE0000000
  %1106 = call float @dx.op.unary.f32(i32 23, float %1103)  ; Log(value)
  %1107 = call float @dx.op.unary.f32(i32 23, float %1104)  ; Log(value)
  %1108 = call float @dx.op.unary.f32(i32 23, float %1105)  ; Log(value)
  %1109 = fmul fast float %1106, 0x4003333340000000
  %1110 = fmul fast float %1107, 0x4003333340000000
  %1111 = fmul fast float %1108, 0x4003333340000000
  %1112 = call float @dx.op.unary.f32(i32 21, float %1109)  ; Exp(value)
  %1113 = call float @dx.op.unary.f32(i32 21, float %1110)  ; Exp(value)
  %1114 = call float @dx.op.unary.f32(i32 21, float %1111)  ; Exp(value)
  %1115 = fsub fast float %1097, %1112
  %1116 = fsub fast float %1098, %1113
  %1117 = fsub fast float %1099, %1114
  %1118 = fmul fast float %1115, %1094
  %1119 = fmul fast float %1116, %1095
  %1120 = fmul fast float %1117, %1096
  %1121 = fadd fast float %1118, %1112
  %1122 = fadd fast float %1119, %1113
  %1123 = fadd fast float %1120, %1114
  br label %1339

; <label>:1124                                    ; preds = %1077
  %1125 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1083, i32 %821, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1126 = extractvalue %dx.types.ResRet.f32 %1125, 0
  %1127 = fcmp fast ogt float %39, 5.000000e-01
  %1128 = fcmp fast olt float %1126, 1.000000e+00
  %1129 = and i1 %1127, %1128
  br i1 %1129, label %1130, label %1268

; <label>:1130                                    ; preds = %1124
  %1131 = sitofp i32 %1083 to float
  %1132 = sitofp i32 %821 to float
  %1133 = fadd fast float %1131, 5.000000e-01
  %1134 = fadd fast float %1132, 5.000000e-01
  %1135 = fdiv fast float %1133, %46
  %1136 = fdiv fast float %1134, %47
  %1137 = fmul fast float %1135, 2.000000e+00
  %1138 = fmul fast float %1136, 2.000000e+00
  %1139 = fadd fast float %1137, -1.000000e+00
  %1140 = fsub fast float 1.000000e+00, %1138
  %1141 = fmul fast float %1139, %36
  %1142 = call float @dx.op.tertiary.f32(i32 46, float %1140, float %32, float %1141)  ; FMad(a,b,c)
  %1143 = call float @dx.op.tertiary.f32(i32 46, float %1126, float %28, float %1142)  ; FMad(a,b,c)
  %1144 = fadd fast float %1143, %24
  %1145 = call float @dx.op.unary.f32(i32 6, float %1144)  ; FAbs(value)
  %1146 = fcmp fast ogt float %1145, 0x3EB0C6F7A0000000
  br i1 %1146, label %1147, label %1268

; <label>:1147                                    ; preds = %1130
  %1148 = fmul fast float %1139, %35
  %1149 = call float @dx.op.tertiary.f32(i32 46, float %1140, float %31, float %1148)  ; FMad(a,b,c)
  %1150 = call float @dx.op.tertiary.f32(i32 46, float %1126, float %27, float %1149)  ; FMad(a,b,c)
  %1151 = fadd fast float %1150, %23
  %1152 = fmul fast float %1139, %34
  %1153 = call float @dx.op.tertiary.f32(i32 46, float %1140, float %30, float %1152)  ; FMad(a,b,c)
  %1154 = call float @dx.op.tertiary.f32(i32 46, float %1126, float %26, float %1153)  ; FMad(a,b,c)
  %1155 = fadd fast float %1154, %22
  %1156 = fmul fast float %1139, %33
  %1157 = call float @dx.op.tertiary.f32(i32 46, float %1140, float %29, float %1156)  ; FMad(a,b,c)
  %1158 = call float @dx.op.tertiary.f32(i32 46, float %1126, float %25, float %1157)  ; FMad(a,b,c)
  %1159 = fadd fast float %1158, %21
  %1160 = fdiv fast float %1159, %1144
  %1161 = fdiv fast float %1155, %1144
  %1162 = fdiv fast float %1151, %1144
  %1163 = fsub fast float %1160, %18
  %1164 = fsub fast float %1161, %19
  %1165 = fsub fast float %1162, %20
  %1166 = fmul fast float %1163, %1163
  %1167 = fmul fast float %1164, %1164
  %1168 = fadd fast float %1167, %1166
  %1169 = fmul fast float %1165, %1165
  %1170 = fadd fast float %1168, %1169
  %1171 = call float @dx.op.unary.f32(i32 24, float %1170)  ; Sqrt(value)
  %1172 = fsub fast float %1171, %10
  %1173 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1172)  ; FMax(a,b)
  %1174 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %1174, label %1175, label %1198

; <label>:1175                                    ; preds = %1147
  %1176 = call float @dx.op.unary.f32(i32 6, float %1164)  ; FAbs(value)
  %1177 = fmul fast float %1176, %12
  %1178 = fcmp fast olt float %1177, 0x3F50624DE0000000
  br i1 %1178, label %1179, label %1182

; <label>:1179                                    ; preds = %1175
  %1180 = fmul fast float %1177, 5.000000e-01
  %1181 = fsub fast float 1.000000e+00, %1180
  br label %1187

; <label>:1182                                    ; preds = %1175
  %1183 = fmul fast float %1177, 0xBFF7154760000000
  %1184 = call float @dx.op.unary.f32(i32 21, float %1183)  ; Exp(value)
  %1185 = fsub fast float 1.000000e+00, %1184
  %1186 = fdiv fast float %1185, %1177
  br label %1187

; <label>:1187                                    ; preds = %1182, %1179
  %1188 = phi float [ %1181, %1179 ], [ %1186, %1182 ]
  %1189 = call float @dx.op.binary.f32(i32 36, float %1161, float %19)  ; FMin(a,b)
  %1190 = fsub fast float %1189, %11
  %1191 = fmul fast float %12, %1190
  %1192 = fsub fast float -0.000000e+00, %1191
  %1193 = call float @dx.op.binary.f32(i32 35, float %1192, float -4.000000e+01)  ; FMax(a,b)
  %1194 = call float @dx.op.binary.f32(i32 36, float %1193, float 5.000000e+00)  ; FMin(a,b)
  %1195 = fmul fast float %1194, 0x3FF7154760000000
  %1196 = call float @dx.op.unary.f32(i32 21, float %1195)  ; Exp(value)
  %1197 = fmul fast float %1196, %1188
  br label %1198

; <label>:1198                                    ; preds = %1187, %1147
  %1199 = phi float [ %1197, %1187 ], [ 1.000000e+00, %1147 ]
  %1200 = fmul fast float %1173, %17
  %1201 = fmul fast float %1200, %1199
  %1202 = fcmp fast ole float %1171, %10
  %1203 = fcmp fast olt float %1171, 0x3F1A36E2E0000000
  %1204 = or i1 %1202, %1203
  br i1 %1204, label %1251, label %1205

; <label>:1205                                    ; preds = %1198
  %1206 = fdiv fast float %10, %1171
  %1207 = fmul fast float %1206, %1163
  %1208 = fmul fast float %1206, %1164
  %1209 = fmul fast float %1206, %1165
  %1210 = fadd fast float %1207, %18
  %1211 = fadd fast float %1208, %19
  %1212 = fadd fast float %1209, %20
  %1213 = fadd fast float %1210, -9.000000e+02
  %1214 = fadd fast float %1211, -1.500000e+01
  %1215 = fadd fast float %1212, -7.500000e+02
  %1216 = fmul fast float %1213, 0x3F62345680000000
  %1217 = fmul fast float %1214, 0x3F62345680000000
  %1218 = fmul fast float %1215, 0x3F62345680000000
  %1219 = call float @dx.op.dot3.f32(i32 55, float %1216, float %1217, float %1218, float %1216, float %1217, float %1218)  ; Dot3(ax,ay,az,bx,by,bz)
  %1220 = fsub fast float 1.000000e+00, %1219
  %1221 = call float @dx.op.unary.f32(i32 7, float %1220)  ; Saturate(value)
  %1222 = fmul fast float %1221, %1221
  %1223 = fadd fast float %1210, %1160
  %1224 = fadd fast float %1211, %1161
  %1225 = fadd fast float %1212, %1162
  %1226 = fmul fast float %1223, 0x3F52345680000000
  %1227 = fadd fast float %1226, -2.000000e+00
  %1228 = fmul fast float %1224, 0x3F52345680000000
  %1229 = fadd fast float %1228, 0xBFA1111120000000
  %1230 = fmul fast float %1225, 0x3F52345680000000
  %1231 = fadd fast float %1230, 0xBFFAAAAAC0000000
  %1232 = call float @dx.op.dot3.f32(i32 55, float %1227, float %1229, float %1231, float %1227, float %1229, float %1231)  ; Dot3(ax,ay,az,bx,by,bz)
  %1233 = fsub fast float 1.000000e+00, %1232
  %1234 = call float @dx.op.unary.f32(i32 7, float %1233)  ; Saturate(value)
  %1235 = fmul fast float %1234, %1234
  %1236 = fmul fast float %1235, 4.000000e+00
  %1237 = fadd fast float %1236, %1222
  %1238 = fadd fast float %1160, -9.000000e+02
  %1239 = fadd fast float %1161, -1.500000e+01
  %1240 = fadd fast float %1162, -7.500000e+02
  %1241 = fmul fast float %1238, 0x3F62345680000000
  %1242 = fmul fast float %1239, 0x3F62345680000000
  %1243 = fmul fast float %1240, 0x3F62345680000000
  %1244 = call float @dx.op.dot3.f32(i32 55, float %1241, float %1242, float %1243, float %1241, float %1242, float %1243)  ; Dot3(ax,ay,az,bx,by,bz)
  %1245 = fsub fast float 1.000000e+00, %1244
  %1246 = call float @dx.op.unary.f32(i32 7, float %1245)  ; Saturate(value)
  %1247 = fmul fast float %1246, %1246
  %1248 = fadd fast float %1237, %1247
  %1249 = fmul fast float %1172, 0x3F25D867E0000000
  %1250 = fmul fast float %1249, %1248
  br label %1251

; <label>:1251                                    ; preds = %1205, %1198
  %1252 = phi float [ %1250, %1205 ], [ 0.000000e+00, %1198 ]
  %1253 = fadd fast float %1252, %1201
  %1254 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1253)  ; FMin(a,b)
  %1255 = fmul fast float %1254, 0xBFF7154760000000
  %1256 = call float @dx.op.unary.f32(i32 21, float %1255)  ; Exp(value)
  %1257 = fsub fast float 1.000000e+00, %1256
  %1258 = call float @dx.op.binary.f32(i32 36, float %13, float %1257)  ; FMin(a,b)
  %1259 = fsub fast float %14, %1085
  %1260 = fsub fast float %15, %1086
  %1261 = fsub fast float %16, %1087
  %1262 = fmul fast float %1258, %1259
  %1263 = fmul fast float %1258, %1260
  %1264 = fmul fast float %1258, %1261
  %1265 = fadd fast float %1262, %1085
  %1266 = fadd fast float %1263, %1086
  %1267 = fadd fast float %1264, %1087
  br label %1268

; <label>:1268                                    ; preds = %1251, %1130, %1124
  %1269 = phi float [ %1265, %1251 ], [ %1085, %1130 ], [ %1085, %1124 ]
  %1270 = phi float [ %1266, %1251 ], [ %1086, %1130 ], [ %1086, %1124 ]
  %1271 = phi float [ %1267, %1251 ], [ %1087, %1130 ], [ %1087, %1124 ]
  %1272 = fadd fast float %6, 1.000000e+00
  %1273 = fadd fast float %7, 1.000000e+00
  %1274 = fsub fast float 1.000000e+00, %6
  %1275 = fmul fast float %37, %1272
  %1276 = fmul fast float %37, %1273
  %1277 = fmul fast float %37, %1274
  %1278 = fmul fast float %1275, %1269
  %1279 = fmul fast float %1276, %1270
  %1280 = fmul fast float %1277, %1271
  %1281 = fcmp fast ult float %38, 5.000000e-01
  br i1 %1281, label %1307, label %1282

; <label>:1282                                    ; preds = %1268
  %1283 = fmul fast float %1278, 0x4004147AE0000000
  %1284 = fmul fast float %1279, 0x4004147AE0000000
  %1285 = fmul fast float %1280, 0x4004147AE0000000
  %1286 = fadd fast float %1283, 0x3F9EB851E0000000
  %1287 = fadd fast float %1284, 0x3F9EB851E0000000
  %1288 = fadd fast float %1285, 0x3F9EB851E0000000
  %1289 = fmul fast float %1286, %1278
  %1290 = fmul fast float %1287, %1279
  %1291 = fmul fast float %1288, %1280
  %1292 = fmul fast float %1278, 0x400370A3E0000000
  %1293 = fmul fast float %1279, 0x400370A3E0000000
  %1294 = fmul fast float %1280, 0x400370A3E0000000
  %1295 = fadd fast float %1292, 0x3FE2E147A0000000
  %1296 = fadd fast float %1293, 0x3FE2E147A0000000
  %1297 = fadd fast float %1294, 0x3FE2E147A0000000
  %1298 = fmul fast float %1295, %1278
  %1299 = fmul fast float %1296, %1279
  %1300 = fmul fast float %1297, %1280
  %1301 = fadd fast float %1298, 0x3FC1EB8520000000
  %1302 = fadd fast float %1299, 0x3FC1EB8520000000
  %1303 = fadd fast float %1300, 0x3FC1EB8520000000
  %1304 = fdiv fast float %1289, %1301
  %1305 = fdiv fast float %1290, %1302
  %1306 = fdiv fast float %1291, %1303
  br label %1307

; <label>:1307                                    ; preds = %1282, %1268
  %1308 = phi float [ %1304, %1282 ], [ %1278, %1268 ]
  %1309 = phi float [ %1305, %1282 ], [ %1279, %1268 ]
  %1310 = phi float [ %1306, %1282 ], [ %1280, %1268 ]
  %1311 = call float @dx.op.unary.f32(i32 7, float %1308)  ; Saturate(value)
  %1312 = call float @dx.op.unary.f32(i32 7, float %1309)  ; Saturate(value)
  %1313 = call float @dx.op.unary.f32(i32 7, float %1310)  ; Saturate(value)
  %1314 = call float @dx.op.dot3.f32(i32 55, float %1311, float %1312, float %1313, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1315 = fsub fast float %1311, %1314
  %1316 = fsub fast float %1312, %1314
  %1317 = fsub fast float %1313, %1314
  %1318 = fmul fast float %1315, %9
  %1319 = fmul fast float %1316, %9
  %1320 = fmul fast float %1317, %9
  %1321 = fadd fast float %1318, %1314
  %1322 = fadd fast float %1319, %1314
  %1323 = fadd fast float %1320, %1314
  %1324 = call float @dx.op.unary.f32(i32 7, float %1321)  ; Saturate(value)
  %1325 = call float @dx.op.unary.f32(i32 7, float %1322)  ; Saturate(value)
  %1326 = call float @dx.op.unary.f32(i32 7, float %1323)  ; Saturate(value)
  %1327 = fadd fast float %1324, 0xBFC70A3D80000000
  %1328 = fadd fast float %1325, 0xBFC70A3D80000000
  %1329 = fadd fast float %1326, 0xBFC70A3D80000000
  %1330 = fmul fast float %1327, %8
  %1331 = fmul fast float %1328, %8
  %1332 = fmul fast float %1329, %8
  %1333 = fadd fast float %1330, 0x3FC70A3D80000000
  %1334 = fadd fast float %1331, 0x3FC70A3D80000000
  %1335 = fadd fast float %1332, 0x3FC70A3D80000000
  %1336 = call float @dx.op.unary.f32(i32 7, float %1333)  ; Saturate(value)
  %1337 = call float @dx.op.unary.f32(i32 7, float %1334)  ; Saturate(value)
  %1338 = call float @dx.op.unary.f32(i32 7, float %1335)  ; Saturate(value)
  br label %1339

; <label>:1339                                    ; preds = %1307, %1090
  %1340 = phi float [ %1121, %1090 ], [ %1336, %1307 ]
  %1341 = phi float [ %1122, %1090 ], [ %1337, %1307 ]
  %1342 = phi float [ %1123, %1090 ], [ %1338, %1307 ]
  %1343 = call float @dx.op.binary.f32(i32 36, float %1078, float %1340)  ; FMin(a,b)
  %1344 = call float @dx.op.binary.f32(i32 36, float %1079, float %1341)  ; FMin(a,b)
  %1345 = call float @dx.op.binary.f32(i32 36, float %1080, float %1342)  ; FMin(a,b)
  %1346 = call float @dx.op.binary.f32(i32 36, float %552, float %814)  ; FMin(a,b)
  %1347 = call float @dx.op.binary.f32(i32 36, float %553, float %815)  ; FMin(a,b)
  %1348 = call float @dx.op.binary.f32(i32 36, float %554, float %816)  ; FMin(a,b)
  %1349 = call float @dx.op.binary.f32(i32 36, float %1346, float %1343)  ; FMin(a,b)
  %1350 = call float @dx.op.binary.f32(i32 36, float %1347, float %1344)  ; FMin(a,b)
  %1351 = call float @dx.op.binary.f32(i32 36, float %1348, float %1345)  ; FMin(a,b)
  %1352 = call float @dx.op.binary.f32(i32 36, float %286, float %1349)  ; FMin(a,b)
  %1353 = call float @dx.op.binary.f32(i32 36, float %287, float %1350)  ; FMin(a,b)
  %1354 = call float @dx.op.binary.f32(i32 36, float %288, float %1351)  ; FMin(a,b)
  %1355 = call float @dx.op.binary.f32(i32 35, float %1078, float %1340)  ; FMax(a,b)
  %1356 = call float @dx.op.binary.f32(i32 35, float %1079, float %1341)  ; FMax(a,b)
  %1357 = call float @dx.op.binary.f32(i32 35, float %1080, float %1342)  ; FMax(a,b)
  %1358 = call float @dx.op.binary.f32(i32 35, float %552, float %814)  ; FMax(a,b)
  %1359 = call float @dx.op.binary.f32(i32 35, float %553, float %815)  ; FMax(a,b)
  %1360 = call float @dx.op.binary.f32(i32 35, float %554, float %816)  ; FMax(a,b)
  %1361 = call float @dx.op.binary.f32(i32 35, float %1358, float %1355)  ; FMax(a,b)
  %1362 = call float @dx.op.binary.f32(i32 35, float %1359, float %1356)  ; FMax(a,b)
  %1363 = call float @dx.op.binary.f32(i32 35, float %1360, float %1357)  ; FMax(a,b)
  %1364 = call float @dx.op.binary.f32(i32 35, float %286, float %1361)  ; FMax(a,b)
  %1365 = call float @dx.op.binary.f32(i32 35, float %287, float %1362)  ; FMax(a,b)
  %1366 = call float @dx.op.binary.f32(i32 35, float %288, float %1363)  ; FMax(a,b)
  %1367 = fsub fast float %1364, %1352
  %1368 = fsub fast float %1365, %1353
  %1369 = fsub fast float %1366, %1354
  %1370 = call float @dx.op.unary.f32(i32 6, float %1367)  ; FAbs(value)
  %1371 = call float @dx.op.unary.f32(i32 6, float %1368)  ; FAbs(value)
  %1372 = call float @dx.op.unary.f32(i32 6, float %1369)  ; FAbs(value)
  %1373 = call float @dx.op.binary.f32(i32 35, float %1371, float %1372)  ; FMax(a,b)
  %1374 = call float @dx.op.binary.f32(i32 35, float %1370, float %1373)  ; FMax(a,b)
  %1375 = call float @dx.op.binary.f32(i32 35, float %1365, float %1366)  ; FMax(a,b)
  %1376 = call float @dx.op.binary.f32(i32 35, float %1364, float %1375)  ; FMax(a,b)
  %1377 = fmul fast float %1376, 1.250000e-01
  %1378 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1377)  ; FMax(a,b)
  %1379 = fcmp fast ogt float %1374, %1378
  br i1 %1379, label %1380, label %1442

; <label>:1380                                    ; preds = %1339
  %1381 = fsub fast float %552, %814
  %1382 = fsub fast float %553, %815
  %1383 = fsub fast float %554, %816
  %1384 = call float @dx.op.unary.f32(i32 6, float %1381)  ; FAbs(value)
  %1385 = call float @dx.op.unary.f32(i32 6, float %1382)  ; FAbs(value)
  %1386 = call float @dx.op.unary.f32(i32 6, float %1383)  ; FAbs(value)
  %1387 = call float @dx.op.binary.f32(i32 35, float %1385, float %1386)  ; FMax(a,b)
  %1388 = call float @dx.op.binary.f32(i32 35, float %1384, float %1387)  ; FMax(a,b)
  %1389 = fsub fast float %1078, %1340
  %1390 = fsub fast float %1079, %1341
  %1391 = fsub fast float %1080, %1342
  %1392 = call float @dx.op.unary.f32(i32 6, float %1389)  ; FAbs(value)
  %1393 = call float @dx.op.unary.f32(i32 6, float %1390)  ; FAbs(value)
  %1394 = call float @dx.op.unary.f32(i32 6, float %1391)  ; FAbs(value)
  %1395 = call float @dx.op.binary.f32(i32 35, float %1393, float %1394)  ; FMax(a,b)
  %1396 = call float @dx.op.binary.f32(i32 35, float %1392, float %1395)  ; FMax(a,b)
  %1397 = fcmp fast olt float %1388, %1396
  %1398 = select i1 %1397, float %552, float %1078
  %1399 = select i1 %1397, float %553, float %1079
  %1400 = select i1 %1397, float %554, float %1080
  %1401 = select i1 %1397, float %814, float %1340
  %1402 = select i1 %1397, float %815, float %1341
  %1403 = select i1 %1397, float %816, float %1342
  %1404 = fsub fast float %286, %1401
  %1405 = fsub fast float %287, %1402
  %1406 = fsub fast float %288, %1403
  %1407 = fsub fast float %286, %1398
  %1408 = fsub fast float %287, %1399
  %1409 = fsub fast float %288, %1400
  %1410 = call float @dx.op.dot3.f32(i32 55, float %1407, float %1408, float %1409, float %1404, float %1405, float %1406)  ; Dot3(ax,ay,az,bx,by,bz)
  %1411 = fcmp fast ogt float %1410, 0.000000e+00
  br i1 %1411, label %1412, label %1423

; <label>:1412                                    ; preds = %1380
  %1413 = fsub fast float %1398, %1401
  %1414 = fsub fast float %1399, %1402
  %1415 = fsub fast float %1400, %1403
  %1416 = call float @dx.op.unary.f32(i32 6, float %1413)  ; FAbs(value)
  %1417 = call float @dx.op.unary.f32(i32 6, float %1414)  ; FAbs(value)
  %1418 = call float @dx.op.unary.f32(i32 6, float %1415)  ; FAbs(value)
  %1419 = call float @dx.op.binary.f32(i32 35, float %1417, float %1418)  ; FMax(a,b)
  %1420 = call float @dx.op.binary.f32(i32 35, float %1416, float %1419)  ; FMax(a,b)
  %1421 = fmul fast float %1374, 2.500000e-01
  %1422 = fcmp fast olt float %1420, %1421
  br label %1423

; <label>:1423                                    ; preds = %1412, %1380
  %1424 = phi i1 [ false, %1380 ], [ %1422, %1412 ]
  %1425 = select i1 %1424, float 5.000000e-01, float 1.000000e+00
  %1426 = fmul fast float %1425, %3
  %1427 = fadd fast float %1398, %1401
  %1428 = fadd fast float %1399, %1402
  %1429 = fadd fast float %1400, %1403
  %1430 = fmul fast float %1427, 5.000000e-01
  %1431 = fmul fast float %1428, 5.000000e-01
  %1432 = fmul fast float %1429, 5.000000e-01
  %1433 = fsub fast float %1430, %286
  %1434 = fsub fast float %1431, %287
  %1435 = fsub fast float %1432, %288
  %1436 = fmul fast float %1426, %1433
  %1437 = fmul fast float %1426, %1434
  %1438 = fmul fast float %1426, %1435
  %1439 = fadd fast float %1436, %286
  %1440 = fadd fast float %1437, %287
  %1441 = fadd fast float %1438, %288
  br label %1442

; <label>:1442                                    ; preds = %1423, %1339, %257
  %1443 = phi float [ %1439, %1423 ], [ %286, %1339 ], [ %286, %257 ]
  %1444 = phi float [ %1440, %1423 ], [ %287, %1339 ], [ %287, %257 ]
  %1445 = phi float [ %1441, %1423 ], [ %288, %1339 ], [ %288, %257 ]
  %1446 = fcmp fast ogt float %1443, 0x3F69A5C380000000
  %1447 = fcmp fast ogt float %1444, 0x3F69A5C380000000
  %1448 = fcmp fast ogt float %1445, 0x3F69A5C380000000
  %1449 = select i1 %1446, float 0.000000e+00, float 1.000000e+00
  %1450 = select i1 %1447, float 0.000000e+00, float 1.000000e+00
  %1451 = select i1 %1448, float 0.000000e+00, float 1.000000e+00
  %1452 = fmul fast float %1443, 0x4029D70A40000000
  %1453 = fmul fast float %1444, 0x4029D70A40000000
  %1454 = fmul fast float %1445, 0x4029D70A40000000
  %1455 = call float @dx.op.binary.f32(i32 35, float %1443, float 0.000000e+00)  ; FMax(a,b)
  %1456 = call float @dx.op.binary.f32(i32 35, float %1444, float 0.000000e+00)  ; FMax(a,b)
  %1457 = call float @dx.op.binary.f32(i32 35, float %1445, float 0.000000e+00)  ; FMax(a,b)
  %1458 = call float @dx.op.unary.f32(i32 23, float %1455)  ; Log(value)
  %1459 = call float @dx.op.unary.f32(i32 23, float %1456)  ; Log(value)
  %1460 = call float @dx.op.unary.f32(i32 23, float %1457)  ; Log(value)
  %1461 = fmul fast float %1458, 0x3FDAAAAAA0000000
  %1462 = fmul fast float %1459, 0x3FDAAAAAA0000000
  %1463 = fmul fast float %1460, 0x3FDAAAAAA0000000
  %1464 = call float @dx.op.unary.f32(i32 21, float %1461)  ; Exp(value)
  %1465 = call float @dx.op.unary.f32(i32 21, float %1462)  ; Exp(value)
  %1466 = call float @dx.op.unary.f32(i32 21, float %1463)  ; Exp(value)
  %1467 = fmul fast float %1464, 0x3FF0E147A0000000
  %1468 = fmul fast float %1465, 0x3FF0E147A0000000
  %1469 = fmul fast float %1466, 0x3FF0E147A0000000
  %1470 = fadd fast float %1467, 0xBFAC28F5C0000000
  %1471 = fadd fast float %1468, 0xBFAC28F5C0000000
  %1472 = fadd fast float %1469, 0xBFAC28F5C0000000
  %1473 = fsub fast float %1452, %1470
  %1474 = fsub fast float %1453, %1471
  %1475 = fsub fast float %1454, %1472
  %1476 = fmul fast float %1473, %1449
  %1477 = fmul fast float %1474, %1450
  %1478 = fmul fast float %1475, %1451
  %1479 = fadd fast float %1476, %1470
  %1480 = fadd fast float %1477, %1471
  %1481 = fadd fast float %1478, %1472
  br label %1482

; <label>:1482                                    ; preds = %1442, %72
  %1483 = phi float [ %67, %72 ], [ %1479, %1442 ]
  %1484 = phi float [ %68, %72 ], [ %1480, %1442 ]
  %1485 = phi float [ %69, %72 ], [ %1481, %1442 ]
  %1486 = phi float [ %73, %72 ], [ %70, %1442 ]
  %1487 = add i32 %56, 1
  %1488 = call i32 @dx.op.binary.i32(i32 37, i32 %1487, i32 0)  ; IMax(a,b)
  %1489 = call i32 @dx.op.binary.i32(i32 38, i32 %1488, i32 %60)  ; IMin(a,b)
  %1490 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1489, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1491 = extractvalue %dx.types.ResRet.f32 %1490, 0
  %1492 = extractvalue %dx.types.ResRet.f32 %1490, 1
  %1493 = extractvalue %dx.types.ResRet.f32 %1490, 2
  %1494 = extractvalue %dx.types.ResRet.f32 %1490, 3
  %1495 = fcmp fast olt float %1494, 0.000000e+00
  br i1 %1495, label %1496, label %1498

; <label>:1496                                    ; preds = %1482
  %1497 = fsub fast float -1.000000e+00, %1494
  br label %2906

; <label>:1498                                    ; preds = %1482
  %1499 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1489, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1500 = extractvalue %dx.types.ResRet.f32 %1499, 0
  %1501 = fcmp fast ogt float %39, 5.000000e-01
  %1502 = fcmp fast olt float %1500, 1.000000e+00
  %1503 = and i1 %1501, %1502
  br i1 %1503, label %1504, label %1642

; <label>:1504                                    ; preds = %1498
  %1505 = sitofp i32 %1489 to float
  %1506 = sitofp i32 %65 to float
  %1507 = fadd fast float %1505, 5.000000e-01
  %1508 = fadd fast float %1506, 5.000000e-01
  %1509 = fdiv fast float %1507, %46
  %1510 = fdiv fast float %1508, %47
  %1511 = fmul fast float %1509, 2.000000e+00
  %1512 = fmul fast float %1510, 2.000000e+00
  %1513 = fadd fast float %1511, -1.000000e+00
  %1514 = fsub fast float 1.000000e+00, %1512
  %1515 = fmul fast float %1513, %36
  %1516 = call float @dx.op.tertiary.f32(i32 46, float %1514, float %32, float %1515)  ; FMad(a,b,c)
  %1517 = call float @dx.op.tertiary.f32(i32 46, float %1500, float %28, float %1516)  ; FMad(a,b,c)
  %1518 = fadd fast float %1517, %24
  %1519 = call float @dx.op.unary.f32(i32 6, float %1518)  ; FAbs(value)
  %1520 = fcmp fast ogt float %1519, 0x3EB0C6F7A0000000
  br i1 %1520, label %1521, label %1642

; <label>:1521                                    ; preds = %1504
  %1522 = fmul fast float %1513, %35
  %1523 = call float @dx.op.tertiary.f32(i32 46, float %1514, float %31, float %1522)  ; FMad(a,b,c)
  %1524 = call float @dx.op.tertiary.f32(i32 46, float %1500, float %27, float %1523)  ; FMad(a,b,c)
  %1525 = fadd fast float %1524, %23
  %1526 = fmul fast float %1513, %34
  %1527 = call float @dx.op.tertiary.f32(i32 46, float %1514, float %30, float %1526)  ; FMad(a,b,c)
  %1528 = call float @dx.op.tertiary.f32(i32 46, float %1500, float %26, float %1527)  ; FMad(a,b,c)
  %1529 = fadd fast float %1528, %22
  %1530 = fmul fast float %1513, %33
  %1531 = call float @dx.op.tertiary.f32(i32 46, float %1514, float %29, float %1530)  ; FMad(a,b,c)
  %1532 = call float @dx.op.tertiary.f32(i32 46, float %1500, float %25, float %1531)  ; FMad(a,b,c)
  %1533 = fadd fast float %1532, %21
  %1534 = fdiv fast float %1533, %1518
  %1535 = fdiv fast float %1529, %1518
  %1536 = fdiv fast float %1525, %1518
  %1537 = fsub fast float %1534, %18
  %1538 = fsub fast float %1535, %19
  %1539 = fsub fast float %1536, %20
  %1540 = fmul fast float %1537, %1537
  %1541 = fmul fast float %1538, %1538
  %1542 = fadd fast float %1541, %1540
  %1543 = fmul fast float %1539, %1539
  %1544 = fadd fast float %1542, %1543
  %1545 = call float @dx.op.unary.f32(i32 24, float %1544)  ; Sqrt(value)
  %1546 = fsub fast float %1545, %10
  %1547 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1546)  ; FMax(a,b)
  %1548 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %1548, label %1549, label %1572

; <label>:1549                                    ; preds = %1521
  %1550 = call float @dx.op.unary.f32(i32 6, float %1538)  ; FAbs(value)
  %1551 = fmul fast float %1550, %12
  %1552 = fcmp fast olt float %1551, 0x3F50624DE0000000
  br i1 %1552, label %1553, label %1556

; <label>:1553                                    ; preds = %1549
  %1554 = fmul fast float %1551, 5.000000e-01
  %1555 = fsub fast float 1.000000e+00, %1554
  br label %1561

; <label>:1556                                    ; preds = %1549
  %1557 = fmul fast float %1551, 0xBFF7154760000000
  %1558 = call float @dx.op.unary.f32(i32 21, float %1557)  ; Exp(value)
  %1559 = fsub fast float 1.000000e+00, %1558
  %1560 = fdiv fast float %1559, %1551
  br label %1561

; <label>:1561                                    ; preds = %1556, %1553
  %1562 = phi float [ %1555, %1553 ], [ %1560, %1556 ]
  %1563 = call float @dx.op.binary.f32(i32 36, float %1535, float %19)  ; FMin(a,b)
  %1564 = fsub fast float %1563, %11
  %1565 = fmul fast float %12, %1564
  %1566 = fsub fast float -0.000000e+00, %1565
  %1567 = call float @dx.op.binary.f32(i32 35, float %1566, float -4.000000e+01)  ; FMax(a,b)
  %1568 = call float @dx.op.binary.f32(i32 36, float %1567, float 5.000000e+00)  ; FMin(a,b)
  %1569 = fmul fast float %1568, 0x3FF7154760000000
  %1570 = call float @dx.op.unary.f32(i32 21, float %1569)  ; Exp(value)
  %1571 = fmul fast float %1570, %1562
  br label %1572

; <label>:1572                                    ; preds = %1561, %1521
  %1573 = phi float [ %1571, %1561 ], [ 1.000000e+00, %1521 ]
  %1574 = fmul fast float %1547, %17
  %1575 = fmul fast float %1574, %1573
  %1576 = fcmp fast ole float %1545, %10
  %1577 = fcmp fast olt float %1545, 0x3F1A36E2E0000000
  %1578 = or i1 %1576, %1577
  br i1 %1578, label %1625, label %1579

; <label>:1579                                    ; preds = %1572
  %1580 = fdiv fast float %10, %1545
  %1581 = fmul fast float %1580, %1537
  %1582 = fmul fast float %1580, %1538
  %1583 = fmul fast float %1580, %1539
  %1584 = fadd fast float %1581, %18
  %1585 = fadd fast float %1582, %19
  %1586 = fadd fast float %1583, %20
  %1587 = fadd fast float %1584, -9.000000e+02
  %1588 = fadd fast float %1585, -1.500000e+01
  %1589 = fadd fast float %1586, -7.500000e+02
  %1590 = fmul fast float %1587, 0x3F62345680000000
  %1591 = fmul fast float %1588, 0x3F62345680000000
  %1592 = fmul fast float %1589, 0x3F62345680000000
  %1593 = call float @dx.op.dot3.f32(i32 55, float %1590, float %1591, float %1592, float %1590, float %1591, float %1592)  ; Dot3(ax,ay,az,bx,by,bz)
  %1594 = fsub fast float 1.000000e+00, %1593
  %1595 = call float @dx.op.unary.f32(i32 7, float %1594)  ; Saturate(value)
  %1596 = fmul fast float %1595, %1595
  %1597 = fadd fast float %1584, %1534
  %1598 = fadd fast float %1585, %1535
  %1599 = fadd fast float %1586, %1536
  %1600 = fmul fast float %1597, 0x3F52345680000000
  %1601 = fadd fast float %1600, -2.000000e+00
  %1602 = fmul fast float %1598, 0x3F52345680000000
  %1603 = fadd fast float %1602, 0xBFA1111120000000
  %1604 = fmul fast float %1599, 0x3F52345680000000
  %1605 = fadd fast float %1604, 0xBFFAAAAAC0000000
  %1606 = call float @dx.op.dot3.f32(i32 55, float %1601, float %1603, float %1605, float %1601, float %1603, float %1605)  ; Dot3(ax,ay,az,bx,by,bz)
  %1607 = fsub fast float 1.000000e+00, %1606
  %1608 = call float @dx.op.unary.f32(i32 7, float %1607)  ; Saturate(value)
  %1609 = fmul fast float %1608, %1608
  %1610 = fmul fast float %1609, 4.000000e+00
  %1611 = fadd fast float %1610, %1596
  %1612 = fadd fast float %1534, -9.000000e+02
  %1613 = fadd fast float %1535, -1.500000e+01
  %1614 = fadd fast float %1536, -7.500000e+02
  %1615 = fmul fast float %1612, 0x3F62345680000000
  %1616 = fmul fast float %1613, 0x3F62345680000000
  %1617 = fmul fast float %1614, 0x3F62345680000000
  %1618 = call float @dx.op.dot3.f32(i32 55, float %1615, float %1616, float %1617, float %1615, float %1616, float %1617)  ; Dot3(ax,ay,az,bx,by,bz)
  %1619 = fsub fast float 1.000000e+00, %1618
  %1620 = call float @dx.op.unary.f32(i32 7, float %1619)  ; Saturate(value)
  %1621 = fmul fast float %1620, %1620
  %1622 = fadd fast float %1611, %1621
  %1623 = fmul fast float %1546, 0x3F25D867E0000000
  %1624 = fmul fast float %1623, %1622
  br label %1625

; <label>:1625                                    ; preds = %1579, %1572
  %1626 = phi float [ %1624, %1579 ], [ 0.000000e+00, %1572 ]
  %1627 = fadd fast float %1626, %1575
  %1628 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1627)  ; FMin(a,b)
  %1629 = fmul fast float %1628, 0xBFF7154760000000
  %1630 = call float @dx.op.unary.f32(i32 21, float %1629)  ; Exp(value)
  %1631 = fsub fast float 1.000000e+00, %1630
  %1632 = call float @dx.op.binary.f32(i32 36, float %13, float %1631)  ; FMin(a,b)
  %1633 = fsub fast float %14, %1491
  %1634 = fsub fast float %15, %1492
  %1635 = fsub fast float %16, %1493
  %1636 = fmul fast float %1632, %1633
  %1637 = fmul fast float %1632, %1634
  %1638 = fmul fast float %1632, %1635
  %1639 = fadd fast float %1636, %1491
  %1640 = fadd fast float %1637, %1492
  %1641 = fadd fast float %1638, %1493
  br label %1642

; <label>:1642                                    ; preds = %1625, %1504, %1498
  %1643 = phi float [ %1639, %1625 ], [ %1491, %1504 ], [ %1491, %1498 ]
  %1644 = phi float [ %1640, %1625 ], [ %1492, %1504 ], [ %1492, %1498 ]
  %1645 = phi float [ %1641, %1625 ], [ %1493, %1504 ], [ %1493, %1498 ]
  %1646 = fadd fast float %6, 1.000000e+00
  %1647 = fadd fast float %7, 1.000000e+00
  %1648 = fsub fast float 1.000000e+00, %6
  %1649 = fmul fast float %37, %1646
  %1650 = fmul fast float %37, %1647
  %1651 = fmul fast float %37, %1648
  %1652 = fmul fast float %1649, %1643
  %1653 = fmul fast float %1650, %1644
  %1654 = fmul fast float %1651, %1645
  %1655 = fcmp fast ult float %38, 5.000000e-01
  br i1 %1655, label %1681, label %1656

; <label>:1656                                    ; preds = %1642
  %1657 = fmul fast float %1652, 0x4004147AE0000000
  %1658 = fmul fast float %1653, 0x4004147AE0000000
  %1659 = fmul fast float %1654, 0x4004147AE0000000
  %1660 = fadd fast float %1657, 0x3F9EB851E0000000
  %1661 = fadd fast float %1658, 0x3F9EB851E0000000
  %1662 = fadd fast float %1659, 0x3F9EB851E0000000
  %1663 = fmul fast float %1660, %1652
  %1664 = fmul fast float %1661, %1653
  %1665 = fmul fast float %1662, %1654
  %1666 = fmul fast float %1652, 0x400370A3E0000000
  %1667 = fmul fast float %1653, 0x400370A3E0000000
  %1668 = fmul fast float %1654, 0x400370A3E0000000
  %1669 = fadd fast float %1666, 0x3FE2E147A0000000
  %1670 = fadd fast float %1667, 0x3FE2E147A0000000
  %1671 = fadd fast float %1668, 0x3FE2E147A0000000
  %1672 = fmul fast float %1669, %1652
  %1673 = fmul fast float %1670, %1653
  %1674 = fmul fast float %1671, %1654
  %1675 = fadd fast float %1672, 0x3FC1EB8520000000
  %1676 = fadd fast float %1673, 0x3FC1EB8520000000
  %1677 = fadd fast float %1674, 0x3FC1EB8520000000
  %1678 = fdiv fast float %1663, %1675
  %1679 = fdiv fast float %1664, %1676
  %1680 = fdiv fast float %1665, %1677
  br label %1681

; <label>:1681                                    ; preds = %1656, %1642
  %1682 = phi float [ %1678, %1656 ], [ %1652, %1642 ]
  %1683 = phi float [ %1679, %1656 ], [ %1653, %1642 ]
  %1684 = phi float [ %1680, %1656 ], [ %1654, %1642 ]
  %1685 = call float @dx.op.unary.f32(i32 7, float %1682)  ; Saturate(value)
  %1686 = call float @dx.op.unary.f32(i32 7, float %1683)  ; Saturate(value)
  %1687 = call float @dx.op.unary.f32(i32 7, float %1684)  ; Saturate(value)
  %1688 = call float @dx.op.dot3.f32(i32 55, float %1685, float %1686, float %1687, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1689 = fsub fast float %1685, %1688
  %1690 = fsub fast float %1686, %1688
  %1691 = fsub fast float %1687, %1688
  %1692 = fmul fast float %1689, %9
  %1693 = fmul fast float %1690, %9
  %1694 = fmul fast float %1691, %9
  %1695 = fadd fast float %1692, %1688
  %1696 = fadd fast float %1693, %1688
  %1697 = fadd fast float %1694, %1688
  %1698 = call float @dx.op.unary.f32(i32 7, float %1695)  ; Saturate(value)
  %1699 = call float @dx.op.unary.f32(i32 7, float %1696)  ; Saturate(value)
  %1700 = call float @dx.op.unary.f32(i32 7, float %1697)  ; Saturate(value)
  %1701 = fadd fast float %1698, 0xBFC70A3D80000000
  %1702 = fadd fast float %1699, 0xBFC70A3D80000000
  %1703 = fadd fast float %1700, 0xBFC70A3D80000000
  %1704 = fmul fast float %1701, %8
  %1705 = fmul fast float %1702, %8
  %1706 = fmul fast float %1703, %8
  %1707 = fadd fast float %1704, 0x3FC70A3D80000000
  %1708 = fadd fast float %1705, 0x3FC70A3D80000000
  %1709 = fadd fast float %1706, 0x3FC70A3D80000000
  %1710 = call float @dx.op.unary.f32(i32 7, float %1707)  ; Saturate(value)
  %1711 = call float @dx.op.unary.f32(i32 7, float %1708)  ; Saturate(value)
  %1712 = call float @dx.op.unary.f32(i32 7, float %1709)  ; Saturate(value)
  %1713 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %1713, label %1714, label %2866

; <label>:1714                                    ; preds = %1681
  %1715 = add i32 %65, -1
  %1716 = call i32 @dx.op.binary.i32(i32 37, i32 %1489, i32 0)  ; IMax(a,b)
  %1717 = call i32 @dx.op.binary.i32(i32 37, i32 %1715, i32 0)  ; IMax(a,b)
  %1718 = call i32 @dx.op.binary.i32(i32 38, i32 %1716, i32 %60)  ; IMin(a,b)
  %1719 = call i32 @dx.op.binary.i32(i32 38, i32 %1717, i32 %61)  ; IMin(a,b)
  %1720 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1718, i32 %1719, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1721 = extractvalue %dx.types.ResRet.f32 %1720, 0
  %1722 = extractvalue %dx.types.ResRet.f32 %1720, 1
  %1723 = extractvalue %dx.types.ResRet.f32 %1720, 2
  %1724 = extractvalue %dx.types.ResRet.f32 %1720, 3
  %1725 = fcmp fast olt float %1724, 0.000000e+00
  br i1 %1725, label %1726, label %1760

; <label>:1726                                    ; preds = %1714
  %1727 = fcmp fast ogt float %1721, 0x3FA4B5DCC0000000
  %1728 = fcmp fast ogt float %1722, 0x3FA4B5DCC0000000
  %1729 = fcmp fast ogt float %1723, 0x3FA4B5DCC0000000
  %1730 = select i1 %1727, float 0.000000e+00, float 1.000000e+00
  %1731 = select i1 %1728, float 0.000000e+00, float 1.000000e+00
  %1732 = select i1 %1729, float 0.000000e+00, float 1.000000e+00
  %1733 = fmul fast float %1721, 0x3FB3D07220000000
  %1734 = fmul fast float %1722, 0x3FB3D07220000000
  %1735 = fmul fast float %1723, 0x3FB3D07220000000
  %1736 = fadd fast float %1721, 0x3FAC28F5C0000000
  %1737 = fadd fast float %1722, 0x3FAC28F5C0000000
  %1738 = fadd fast float %1723, 0x3FAC28F5C0000000
  %1739 = fmul fast float %1736, 0x3FEE54EDE0000000
  %1740 = fmul fast float %1737, 0x3FEE54EDE0000000
  %1741 = fmul fast float %1738, 0x3FEE54EDE0000000
  %1742 = call float @dx.op.unary.f32(i32 23, float %1739)  ; Log(value)
  %1743 = call float @dx.op.unary.f32(i32 23, float %1740)  ; Log(value)
  %1744 = call float @dx.op.unary.f32(i32 23, float %1741)  ; Log(value)
  %1745 = fmul fast float %1742, 0x4003333340000000
  %1746 = fmul fast float %1743, 0x4003333340000000
  %1747 = fmul fast float %1744, 0x4003333340000000
  %1748 = call float @dx.op.unary.f32(i32 21, float %1745)  ; Exp(value)
  %1749 = call float @dx.op.unary.f32(i32 21, float %1746)  ; Exp(value)
  %1750 = call float @dx.op.unary.f32(i32 21, float %1747)  ; Exp(value)
  %1751 = fsub fast float %1733, %1748
  %1752 = fsub fast float %1734, %1749
  %1753 = fsub fast float %1735, %1750
  %1754 = fmul fast float %1751, %1730
  %1755 = fmul fast float %1752, %1731
  %1756 = fmul fast float %1753, %1732
  %1757 = fadd fast float %1754, %1748
  %1758 = fadd fast float %1755, %1749
  %1759 = fadd fast float %1756, %1750
  br label %1975

; <label>:1760                                    ; preds = %1714
  %1761 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1718, i32 %1719, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1762 = extractvalue %dx.types.ResRet.f32 %1761, 0
  %1763 = fcmp fast ogt float %39, 5.000000e-01
  %1764 = fcmp fast olt float %1762, 1.000000e+00
  %1765 = and i1 %1763, %1764
  br i1 %1765, label %1766, label %1904

; <label>:1766                                    ; preds = %1760
  %1767 = sitofp i32 %1718 to float
  %1768 = sitofp i32 %1719 to float
  %1769 = fadd fast float %1767, 5.000000e-01
  %1770 = fadd fast float %1768, 5.000000e-01
  %1771 = fdiv fast float %1769, %46
  %1772 = fdiv fast float %1770, %47
  %1773 = fmul fast float %1771, 2.000000e+00
  %1774 = fmul fast float %1772, 2.000000e+00
  %1775 = fadd fast float %1773, -1.000000e+00
  %1776 = fsub fast float 1.000000e+00, %1774
  %1777 = fmul fast float %1775, %36
  %1778 = call float @dx.op.tertiary.f32(i32 46, float %1776, float %32, float %1777)  ; FMad(a,b,c)
  %1779 = call float @dx.op.tertiary.f32(i32 46, float %1762, float %28, float %1778)  ; FMad(a,b,c)
  %1780 = fadd fast float %1779, %24
  %1781 = call float @dx.op.unary.f32(i32 6, float %1780)  ; FAbs(value)
  %1782 = fcmp fast ogt float %1781, 0x3EB0C6F7A0000000
  br i1 %1782, label %1783, label %1904

; <label>:1783                                    ; preds = %1766
  %1784 = fmul fast float %1775, %35
  %1785 = call float @dx.op.tertiary.f32(i32 46, float %1776, float %31, float %1784)  ; FMad(a,b,c)
  %1786 = call float @dx.op.tertiary.f32(i32 46, float %1762, float %27, float %1785)  ; FMad(a,b,c)
  %1787 = fadd fast float %1786, %23
  %1788 = fmul fast float %1775, %34
  %1789 = call float @dx.op.tertiary.f32(i32 46, float %1776, float %30, float %1788)  ; FMad(a,b,c)
  %1790 = call float @dx.op.tertiary.f32(i32 46, float %1762, float %26, float %1789)  ; FMad(a,b,c)
  %1791 = fadd fast float %1790, %22
  %1792 = fmul fast float %1775, %33
  %1793 = call float @dx.op.tertiary.f32(i32 46, float %1776, float %29, float %1792)  ; FMad(a,b,c)
  %1794 = call float @dx.op.tertiary.f32(i32 46, float %1762, float %25, float %1793)  ; FMad(a,b,c)
  %1795 = fadd fast float %1794, %21
  %1796 = fdiv fast float %1795, %1780
  %1797 = fdiv fast float %1791, %1780
  %1798 = fdiv fast float %1787, %1780
  %1799 = fsub fast float %1796, %18
  %1800 = fsub fast float %1797, %19
  %1801 = fsub fast float %1798, %20
  %1802 = fmul fast float %1799, %1799
  %1803 = fmul fast float %1800, %1800
  %1804 = fadd fast float %1803, %1802
  %1805 = fmul fast float %1801, %1801
  %1806 = fadd fast float %1804, %1805
  %1807 = call float @dx.op.unary.f32(i32 24, float %1806)  ; Sqrt(value)
  %1808 = fsub fast float %1807, %10
  %1809 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1808)  ; FMax(a,b)
  %1810 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %1810, label %1811, label %1834

; <label>:1811                                    ; preds = %1783
  %1812 = call float @dx.op.unary.f32(i32 6, float %1800)  ; FAbs(value)
  %1813 = fmul fast float %1812, %12
  %1814 = fcmp fast olt float %1813, 0x3F50624DE0000000
  br i1 %1814, label %1815, label %1818

; <label>:1815                                    ; preds = %1811
  %1816 = fmul fast float %1813, 5.000000e-01
  %1817 = fsub fast float 1.000000e+00, %1816
  br label %1823

; <label>:1818                                    ; preds = %1811
  %1819 = fmul fast float %1813, 0xBFF7154760000000
  %1820 = call float @dx.op.unary.f32(i32 21, float %1819)  ; Exp(value)
  %1821 = fsub fast float 1.000000e+00, %1820
  %1822 = fdiv fast float %1821, %1813
  br label %1823

; <label>:1823                                    ; preds = %1818, %1815
  %1824 = phi float [ %1817, %1815 ], [ %1822, %1818 ]
  %1825 = call float @dx.op.binary.f32(i32 36, float %1797, float %19)  ; FMin(a,b)
  %1826 = fsub fast float %1825, %11
  %1827 = fmul fast float %12, %1826
  %1828 = fsub fast float -0.000000e+00, %1827
  %1829 = call float @dx.op.binary.f32(i32 35, float %1828, float -4.000000e+01)  ; FMax(a,b)
  %1830 = call float @dx.op.binary.f32(i32 36, float %1829, float 5.000000e+00)  ; FMin(a,b)
  %1831 = fmul fast float %1830, 0x3FF7154760000000
  %1832 = call float @dx.op.unary.f32(i32 21, float %1831)  ; Exp(value)
  %1833 = fmul fast float %1832, %1824
  br label %1834

; <label>:1834                                    ; preds = %1823, %1783
  %1835 = phi float [ %1833, %1823 ], [ 1.000000e+00, %1783 ]
  %1836 = fmul fast float %1809, %17
  %1837 = fmul fast float %1836, %1835
  %1838 = fcmp fast ole float %1807, %10
  %1839 = fcmp fast olt float %1807, 0x3F1A36E2E0000000
  %1840 = or i1 %1838, %1839
  br i1 %1840, label %1887, label %1841

; <label>:1841                                    ; preds = %1834
  %1842 = fdiv fast float %10, %1807
  %1843 = fmul fast float %1842, %1799
  %1844 = fmul fast float %1842, %1800
  %1845 = fmul fast float %1842, %1801
  %1846 = fadd fast float %1843, %18
  %1847 = fadd fast float %1844, %19
  %1848 = fadd fast float %1845, %20
  %1849 = fadd fast float %1846, -9.000000e+02
  %1850 = fadd fast float %1847, -1.500000e+01
  %1851 = fadd fast float %1848, -7.500000e+02
  %1852 = fmul fast float %1849, 0x3F62345680000000
  %1853 = fmul fast float %1850, 0x3F62345680000000
  %1854 = fmul fast float %1851, 0x3F62345680000000
  %1855 = call float @dx.op.dot3.f32(i32 55, float %1852, float %1853, float %1854, float %1852, float %1853, float %1854)  ; Dot3(ax,ay,az,bx,by,bz)
  %1856 = fsub fast float 1.000000e+00, %1855
  %1857 = call float @dx.op.unary.f32(i32 7, float %1856)  ; Saturate(value)
  %1858 = fmul fast float %1857, %1857
  %1859 = fadd fast float %1846, %1796
  %1860 = fadd fast float %1847, %1797
  %1861 = fadd fast float %1848, %1798
  %1862 = fmul fast float %1859, 0x3F52345680000000
  %1863 = fadd fast float %1862, -2.000000e+00
  %1864 = fmul fast float %1860, 0x3F52345680000000
  %1865 = fadd fast float %1864, 0xBFA1111120000000
  %1866 = fmul fast float %1861, 0x3F52345680000000
  %1867 = fadd fast float %1866, 0xBFFAAAAAC0000000
  %1868 = call float @dx.op.dot3.f32(i32 55, float %1863, float %1865, float %1867, float %1863, float %1865, float %1867)  ; Dot3(ax,ay,az,bx,by,bz)
  %1869 = fsub fast float 1.000000e+00, %1868
  %1870 = call float @dx.op.unary.f32(i32 7, float %1869)  ; Saturate(value)
  %1871 = fmul fast float %1870, %1870
  %1872 = fmul fast float %1871, 4.000000e+00
  %1873 = fadd fast float %1872, %1858
  %1874 = fadd fast float %1796, -9.000000e+02
  %1875 = fadd fast float %1797, -1.500000e+01
  %1876 = fadd fast float %1798, -7.500000e+02
  %1877 = fmul fast float %1874, 0x3F62345680000000
  %1878 = fmul fast float %1875, 0x3F62345680000000
  %1879 = fmul fast float %1876, 0x3F62345680000000
  %1880 = call float @dx.op.dot3.f32(i32 55, float %1877, float %1878, float %1879, float %1877, float %1878, float %1879)  ; Dot3(ax,ay,az,bx,by,bz)
  %1881 = fsub fast float 1.000000e+00, %1880
  %1882 = call float @dx.op.unary.f32(i32 7, float %1881)  ; Saturate(value)
  %1883 = fmul fast float %1882, %1882
  %1884 = fadd fast float %1873, %1883
  %1885 = fmul fast float %1808, 0x3F25D867E0000000
  %1886 = fmul fast float %1885, %1884
  br label %1887

; <label>:1887                                    ; preds = %1841, %1834
  %1888 = phi float [ %1886, %1841 ], [ 0.000000e+00, %1834 ]
  %1889 = fadd fast float %1888, %1837
  %1890 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1889)  ; FMin(a,b)
  %1891 = fmul fast float %1890, 0xBFF7154760000000
  %1892 = call float @dx.op.unary.f32(i32 21, float %1891)  ; Exp(value)
  %1893 = fsub fast float 1.000000e+00, %1892
  %1894 = call float @dx.op.binary.f32(i32 36, float %13, float %1893)  ; FMin(a,b)
  %1895 = fsub fast float %14, %1721
  %1896 = fsub fast float %15, %1722
  %1897 = fsub fast float %16, %1723
  %1898 = fmul fast float %1894, %1895
  %1899 = fmul fast float %1894, %1896
  %1900 = fmul fast float %1894, %1897
  %1901 = fadd fast float %1898, %1721
  %1902 = fadd fast float %1899, %1722
  %1903 = fadd fast float %1900, %1723
  br label %1904

; <label>:1904                                    ; preds = %1887, %1766, %1760
  %1905 = phi float [ %1901, %1887 ], [ %1721, %1766 ], [ %1721, %1760 ]
  %1906 = phi float [ %1902, %1887 ], [ %1722, %1766 ], [ %1722, %1760 ]
  %1907 = phi float [ %1903, %1887 ], [ %1723, %1766 ], [ %1723, %1760 ]
  %1908 = fadd fast float %6, 1.000000e+00
  %1909 = fadd fast float %7, 1.000000e+00
  %1910 = fsub fast float 1.000000e+00, %6
  %1911 = fmul fast float %37, %1908
  %1912 = fmul fast float %37, %1909
  %1913 = fmul fast float %37, %1910
  %1914 = fmul fast float %1911, %1905
  %1915 = fmul fast float %1912, %1906
  %1916 = fmul fast float %1913, %1907
  %1917 = fcmp fast ult float %38, 5.000000e-01
  br i1 %1917, label %1943, label %1918

; <label>:1918                                    ; preds = %1904
  %1919 = fmul fast float %1914, 0x4004147AE0000000
  %1920 = fmul fast float %1915, 0x4004147AE0000000
  %1921 = fmul fast float %1916, 0x4004147AE0000000
  %1922 = fadd fast float %1919, 0x3F9EB851E0000000
  %1923 = fadd fast float %1920, 0x3F9EB851E0000000
  %1924 = fadd fast float %1921, 0x3F9EB851E0000000
  %1925 = fmul fast float %1922, %1914
  %1926 = fmul fast float %1923, %1915
  %1927 = fmul fast float %1924, %1916
  %1928 = fmul fast float %1914, 0x400370A3E0000000
  %1929 = fmul fast float %1915, 0x400370A3E0000000
  %1930 = fmul fast float %1916, 0x400370A3E0000000
  %1931 = fadd fast float %1928, 0x3FE2E147A0000000
  %1932 = fadd fast float %1929, 0x3FE2E147A0000000
  %1933 = fadd fast float %1930, 0x3FE2E147A0000000
  %1934 = fmul fast float %1931, %1914
  %1935 = fmul fast float %1932, %1915
  %1936 = fmul fast float %1933, %1916
  %1937 = fadd fast float %1934, 0x3FC1EB8520000000
  %1938 = fadd fast float %1935, 0x3FC1EB8520000000
  %1939 = fadd fast float %1936, 0x3FC1EB8520000000
  %1940 = fdiv fast float %1925, %1937
  %1941 = fdiv fast float %1926, %1938
  %1942 = fdiv fast float %1927, %1939
  br label %1943

; <label>:1943                                    ; preds = %1918, %1904
  %1944 = phi float [ %1940, %1918 ], [ %1914, %1904 ]
  %1945 = phi float [ %1941, %1918 ], [ %1915, %1904 ]
  %1946 = phi float [ %1942, %1918 ], [ %1916, %1904 ]
  %1947 = call float @dx.op.unary.f32(i32 7, float %1944)  ; Saturate(value)
  %1948 = call float @dx.op.unary.f32(i32 7, float %1945)  ; Saturate(value)
  %1949 = call float @dx.op.unary.f32(i32 7, float %1946)  ; Saturate(value)
  %1950 = call float @dx.op.dot3.f32(i32 55, float %1947, float %1948, float %1949, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1951 = fsub fast float %1947, %1950
  %1952 = fsub fast float %1948, %1950
  %1953 = fsub fast float %1949, %1950
  %1954 = fmul fast float %1951, %9
  %1955 = fmul fast float %1952, %9
  %1956 = fmul fast float %1953, %9
  %1957 = fadd fast float %1954, %1950
  %1958 = fadd fast float %1955, %1950
  %1959 = fadd fast float %1956, %1950
  %1960 = call float @dx.op.unary.f32(i32 7, float %1957)  ; Saturate(value)
  %1961 = call float @dx.op.unary.f32(i32 7, float %1958)  ; Saturate(value)
  %1962 = call float @dx.op.unary.f32(i32 7, float %1959)  ; Saturate(value)
  %1963 = fadd fast float %1960, 0xBFC70A3D80000000
  %1964 = fadd fast float %1961, 0xBFC70A3D80000000
  %1965 = fadd fast float %1962, 0xBFC70A3D80000000
  %1966 = fmul fast float %1963, %8
  %1967 = fmul fast float %1964, %8
  %1968 = fmul fast float %1965, %8
  %1969 = fadd fast float %1966, 0x3FC70A3D80000000
  %1970 = fadd fast float %1967, 0x3FC70A3D80000000
  %1971 = fadd fast float %1968, 0x3FC70A3D80000000
  %1972 = call float @dx.op.unary.f32(i32 7, float %1969)  ; Saturate(value)
  %1973 = call float @dx.op.unary.f32(i32 7, float %1970)  ; Saturate(value)
  %1974 = call float @dx.op.unary.f32(i32 7, float %1971)  ; Saturate(value)
  br label %1975

; <label>:1975                                    ; preds = %1943, %1726
  %1976 = phi float [ %1757, %1726 ], [ %1972, %1943 ]
  %1977 = phi float [ %1758, %1726 ], [ %1973, %1943 ]
  %1978 = phi float [ %1759, %1726 ], [ %1974, %1943 ]
  %1979 = add i32 %65, 1
  %1980 = call i32 @dx.op.binary.i32(i32 37, i32 %1979, i32 0)  ; IMax(a,b)
  %1981 = call i32 @dx.op.binary.i32(i32 38, i32 %1980, i32 %61)  ; IMin(a,b)
  %1982 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1718, i32 %1981, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1983 = extractvalue %dx.types.ResRet.f32 %1982, 0
  %1984 = extractvalue %dx.types.ResRet.f32 %1982, 1
  %1985 = extractvalue %dx.types.ResRet.f32 %1982, 2
  %1986 = extractvalue %dx.types.ResRet.f32 %1982, 3
  %1987 = fcmp fast olt float %1986, 0.000000e+00
  br i1 %1987, label %1988, label %2022

; <label>:1988                                    ; preds = %1975
  %1989 = fcmp fast ogt float %1983, 0x3FA4B5DCC0000000
  %1990 = fcmp fast ogt float %1984, 0x3FA4B5DCC0000000
  %1991 = fcmp fast ogt float %1985, 0x3FA4B5DCC0000000
  %1992 = select i1 %1989, float 0.000000e+00, float 1.000000e+00
  %1993 = select i1 %1990, float 0.000000e+00, float 1.000000e+00
  %1994 = select i1 %1991, float 0.000000e+00, float 1.000000e+00
  %1995 = fmul fast float %1983, 0x3FB3D07220000000
  %1996 = fmul fast float %1984, 0x3FB3D07220000000
  %1997 = fmul fast float %1985, 0x3FB3D07220000000
  %1998 = fadd fast float %1983, 0x3FAC28F5C0000000
  %1999 = fadd fast float %1984, 0x3FAC28F5C0000000
  %2000 = fadd fast float %1985, 0x3FAC28F5C0000000
  %2001 = fmul fast float %1998, 0x3FEE54EDE0000000
  %2002 = fmul fast float %1999, 0x3FEE54EDE0000000
  %2003 = fmul fast float %2000, 0x3FEE54EDE0000000
  %2004 = call float @dx.op.unary.f32(i32 23, float %2001)  ; Log(value)
  %2005 = call float @dx.op.unary.f32(i32 23, float %2002)  ; Log(value)
  %2006 = call float @dx.op.unary.f32(i32 23, float %2003)  ; Log(value)
  %2007 = fmul fast float %2004, 0x4003333340000000
  %2008 = fmul fast float %2005, 0x4003333340000000
  %2009 = fmul fast float %2006, 0x4003333340000000
  %2010 = call float @dx.op.unary.f32(i32 21, float %2007)  ; Exp(value)
  %2011 = call float @dx.op.unary.f32(i32 21, float %2008)  ; Exp(value)
  %2012 = call float @dx.op.unary.f32(i32 21, float %2009)  ; Exp(value)
  %2013 = fsub fast float %1995, %2010
  %2014 = fsub fast float %1996, %2011
  %2015 = fsub fast float %1997, %2012
  %2016 = fmul fast float %2013, %1992
  %2017 = fmul fast float %2014, %1993
  %2018 = fmul fast float %2015, %1994
  %2019 = fadd fast float %2016, %2010
  %2020 = fadd fast float %2017, %2011
  %2021 = fadd fast float %2018, %2012
  br label %2237

; <label>:2022                                    ; preds = %1975
  %2023 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1718, i32 %1981, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2024 = extractvalue %dx.types.ResRet.f32 %2023, 0
  %2025 = fcmp fast ogt float %39, 5.000000e-01
  %2026 = fcmp fast olt float %2024, 1.000000e+00
  %2027 = and i1 %2025, %2026
  br i1 %2027, label %2028, label %2166

; <label>:2028                                    ; preds = %2022
  %2029 = sitofp i32 %1718 to float
  %2030 = sitofp i32 %1981 to float
  %2031 = fadd fast float %2029, 5.000000e-01
  %2032 = fadd fast float %2030, 5.000000e-01
  %2033 = fdiv fast float %2031, %46
  %2034 = fdiv fast float %2032, %47
  %2035 = fmul fast float %2033, 2.000000e+00
  %2036 = fmul fast float %2034, 2.000000e+00
  %2037 = fadd fast float %2035, -1.000000e+00
  %2038 = fsub fast float 1.000000e+00, %2036
  %2039 = fmul fast float %2037, %36
  %2040 = call float @dx.op.tertiary.f32(i32 46, float %2038, float %32, float %2039)  ; FMad(a,b,c)
  %2041 = call float @dx.op.tertiary.f32(i32 46, float %2024, float %28, float %2040)  ; FMad(a,b,c)
  %2042 = fadd fast float %2041, %24
  %2043 = call float @dx.op.unary.f32(i32 6, float %2042)  ; FAbs(value)
  %2044 = fcmp fast ogt float %2043, 0x3EB0C6F7A0000000
  br i1 %2044, label %2045, label %2166

; <label>:2045                                    ; preds = %2028
  %2046 = fmul fast float %2037, %35
  %2047 = call float @dx.op.tertiary.f32(i32 46, float %2038, float %31, float %2046)  ; FMad(a,b,c)
  %2048 = call float @dx.op.tertiary.f32(i32 46, float %2024, float %27, float %2047)  ; FMad(a,b,c)
  %2049 = fadd fast float %2048, %23
  %2050 = fmul fast float %2037, %34
  %2051 = call float @dx.op.tertiary.f32(i32 46, float %2038, float %30, float %2050)  ; FMad(a,b,c)
  %2052 = call float @dx.op.tertiary.f32(i32 46, float %2024, float %26, float %2051)  ; FMad(a,b,c)
  %2053 = fadd fast float %2052, %22
  %2054 = fmul fast float %2037, %33
  %2055 = call float @dx.op.tertiary.f32(i32 46, float %2038, float %29, float %2054)  ; FMad(a,b,c)
  %2056 = call float @dx.op.tertiary.f32(i32 46, float %2024, float %25, float %2055)  ; FMad(a,b,c)
  %2057 = fadd fast float %2056, %21
  %2058 = fdiv fast float %2057, %2042
  %2059 = fdiv fast float %2053, %2042
  %2060 = fdiv fast float %2049, %2042
  %2061 = fsub fast float %2058, %18
  %2062 = fsub fast float %2059, %19
  %2063 = fsub fast float %2060, %20
  %2064 = fmul fast float %2061, %2061
  %2065 = fmul fast float %2062, %2062
  %2066 = fadd fast float %2065, %2064
  %2067 = fmul fast float %2063, %2063
  %2068 = fadd fast float %2066, %2067
  %2069 = call float @dx.op.unary.f32(i32 24, float %2068)  ; Sqrt(value)
  %2070 = fsub fast float %2069, %10
  %2071 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2070)  ; FMax(a,b)
  %2072 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %2072, label %2073, label %2096

; <label>:2073                                    ; preds = %2045
  %2074 = call float @dx.op.unary.f32(i32 6, float %2062)  ; FAbs(value)
  %2075 = fmul fast float %2074, %12
  %2076 = fcmp fast olt float %2075, 0x3F50624DE0000000
  br i1 %2076, label %2077, label %2080

; <label>:2077                                    ; preds = %2073
  %2078 = fmul fast float %2075, 5.000000e-01
  %2079 = fsub fast float 1.000000e+00, %2078
  br label %2085

; <label>:2080                                    ; preds = %2073
  %2081 = fmul fast float %2075, 0xBFF7154760000000
  %2082 = call float @dx.op.unary.f32(i32 21, float %2081)  ; Exp(value)
  %2083 = fsub fast float 1.000000e+00, %2082
  %2084 = fdiv fast float %2083, %2075
  br label %2085

; <label>:2085                                    ; preds = %2080, %2077
  %2086 = phi float [ %2079, %2077 ], [ %2084, %2080 ]
  %2087 = call float @dx.op.binary.f32(i32 36, float %2059, float %19)  ; FMin(a,b)
  %2088 = fsub fast float %2087, %11
  %2089 = fmul fast float %12, %2088
  %2090 = fsub fast float -0.000000e+00, %2089
  %2091 = call float @dx.op.binary.f32(i32 35, float %2090, float -4.000000e+01)  ; FMax(a,b)
  %2092 = call float @dx.op.binary.f32(i32 36, float %2091, float 5.000000e+00)  ; FMin(a,b)
  %2093 = fmul fast float %2092, 0x3FF7154760000000
  %2094 = call float @dx.op.unary.f32(i32 21, float %2093)  ; Exp(value)
  %2095 = fmul fast float %2094, %2086
  br label %2096

; <label>:2096                                    ; preds = %2085, %2045
  %2097 = phi float [ %2095, %2085 ], [ 1.000000e+00, %2045 ]
  %2098 = fmul fast float %2071, %17
  %2099 = fmul fast float %2098, %2097
  %2100 = fcmp fast ole float %2069, %10
  %2101 = fcmp fast olt float %2069, 0x3F1A36E2E0000000
  %2102 = or i1 %2100, %2101
  br i1 %2102, label %2149, label %2103

; <label>:2103                                    ; preds = %2096
  %2104 = fdiv fast float %10, %2069
  %2105 = fmul fast float %2104, %2061
  %2106 = fmul fast float %2104, %2062
  %2107 = fmul fast float %2104, %2063
  %2108 = fadd fast float %2105, %18
  %2109 = fadd fast float %2106, %19
  %2110 = fadd fast float %2107, %20
  %2111 = fadd fast float %2108, -9.000000e+02
  %2112 = fadd fast float %2109, -1.500000e+01
  %2113 = fadd fast float %2110, -7.500000e+02
  %2114 = fmul fast float %2111, 0x3F62345680000000
  %2115 = fmul fast float %2112, 0x3F62345680000000
  %2116 = fmul fast float %2113, 0x3F62345680000000
  %2117 = call float @dx.op.dot3.f32(i32 55, float %2114, float %2115, float %2116, float %2114, float %2115, float %2116)  ; Dot3(ax,ay,az,bx,by,bz)
  %2118 = fsub fast float 1.000000e+00, %2117
  %2119 = call float @dx.op.unary.f32(i32 7, float %2118)  ; Saturate(value)
  %2120 = fmul fast float %2119, %2119
  %2121 = fadd fast float %2108, %2058
  %2122 = fadd fast float %2109, %2059
  %2123 = fadd fast float %2110, %2060
  %2124 = fmul fast float %2121, 0x3F52345680000000
  %2125 = fadd fast float %2124, -2.000000e+00
  %2126 = fmul fast float %2122, 0x3F52345680000000
  %2127 = fadd fast float %2126, 0xBFA1111120000000
  %2128 = fmul fast float %2123, 0x3F52345680000000
  %2129 = fadd fast float %2128, 0xBFFAAAAAC0000000
  %2130 = call float @dx.op.dot3.f32(i32 55, float %2125, float %2127, float %2129, float %2125, float %2127, float %2129)  ; Dot3(ax,ay,az,bx,by,bz)
  %2131 = fsub fast float 1.000000e+00, %2130
  %2132 = call float @dx.op.unary.f32(i32 7, float %2131)  ; Saturate(value)
  %2133 = fmul fast float %2132, %2132
  %2134 = fmul fast float %2133, 4.000000e+00
  %2135 = fadd fast float %2134, %2120
  %2136 = fadd fast float %2058, -9.000000e+02
  %2137 = fadd fast float %2059, -1.500000e+01
  %2138 = fadd fast float %2060, -7.500000e+02
  %2139 = fmul fast float %2136, 0x3F62345680000000
  %2140 = fmul fast float %2137, 0x3F62345680000000
  %2141 = fmul fast float %2138, 0x3F62345680000000
  %2142 = call float @dx.op.dot3.f32(i32 55, float %2139, float %2140, float %2141, float %2139, float %2140, float %2141)  ; Dot3(ax,ay,az,bx,by,bz)
  %2143 = fsub fast float 1.000000e+00, %2142
  %2144 = call float @dx.op.unary.f32(i32 7, float %2143)  ; Saturate(value)
  %2145 = fmul fast float %2144, %2144
  %2146 = fadd fast float %2135, %2145
  %2147 = fmul fast float %2070, 0x3F25D867E0000000
  %2148 = fmul fast float %2147, %2146
  br label %2149

; <label>:2149                                    ; preds = %2103, %2096
  %2150 = phi float [ %2148, %2103 ], [ 0.000000e+00, %2096 ]
  %2151 = fadd fast float %2150, %2099
  %2152 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2151)  ; FMin(a,b)
  %2153 = fmul fast float %2152, 0xBFF7154760000000
  %2154 = call float @dx.op.unary.f32(i32 21, float %2153)  ; Exp(value)
  %2155 = fsub fast float 1.000000e+00, %2154
  %2156 = call float @dx.op.binary.f32(i32 36, float %13, float %2155)  ; FMin(a,b)
  %2157 = fsub fast float %14, %1983
  %2158 = fsub fast float %15, %1984
  %2159 = fsub fast float %16, %1985
  %2160 = fmul fast float %2156, %2157
  %2161 = fmul fast float %2156, %2158
  %2162 = fmul fast float %2156, %2159
  %2163 = fadd fast float %2160, %1983
  %2164 = fadd fast float %2161, %1984
  %2165 = fadd fast float %2162, %1985
  br label %2166

; <label>:2166                                    ; preds = %2149, %2028, %2022
  %2167 = phi float [ %2163, %2149 ], [ %1983, %2028 ], [ %1983, %2022 ]
  %2168 = phi float [ %2164, %2149 ], [ %1984, %2028 ], [ %1984, %2022 ]
  %2169 = phi float [ %2165, %2149 ], [ %1985, %2028 ], [ %1985, %2022 ]
  %2170 = fadd fast float %6, 1.000000e+00
  %2171 = fadd fast float %7, 1.000000e+00
  %2172 = fsub fast float 1.000000e+00, %6
  %2173 = fmul fast float %37, %2170
  %2174 = fmul fast float %37, %2171
  %2175 = fmul fast float %37, %2172
  %2176 = fmul fast float %2173, %2167
  %2177 = fmul fast float %2174, %2168
  %2178 = fmul fast float %2175, %2169
  %2179 = fcmp fast ult float %38, 5.000000e-01
  br i1 %2179, label %2205, label %2180

; <label>:2180                                    ; preds = %2166
  %2181 = fmul fast float %2176, 0x4004147AE0000000
  %2182 = fmul fast float %2177, 0x4004147AE0000000
  %2183 = fmul fast float %2178, 0x4004147AE0000000
  %2184 = fadd fast float %2181, 0x3F9EB851E0000000
  %2185 = fadd fast float %2182, 0x3F9EB851E0000000
  %2186 = fadd fast float %2183, 0x3F9EB851E0000000
  %2187 = fmul fast float %2184, %2176
  %2188 = fmul fast float %2185, %2177
  %2189 = fmul fast float %2186, %2178
  %2190 = fmul fast float %2176, 0x400370A3E0000000
  %2191 = fmul fast float %2177, 0x400370A3E0000000
  %2192 = fmul fast float %2178, 0x400370A3E0000000
  %2193 = fadd fast float %2190, 0x3FE2E147A0000000
  %2194 = fadd fast float %2191, 0x3FE2E147A0000000
  %2195 = fadd fast float %2192, 0x3FE2E147A0000000
  %2196 = fmul fast float %2193, %2176
  %2197 = fmul fast float %2194, %2177
  %2198 = fmul fast float %2195, %2178
  %2199 = fadd fast float %2196, 0x3FC1EB8520000000
  %2200 = fadd fast float %2197, 0x3FC1EB8520000000
  %2201 = fadd fast float %2198, 0x3FC1EB8520000000
  %2202 = fdiv fast float %2187, %2199
  %2203 = fdiv fast float %2188, %2200
  %2204 = fdiv fast float %2189, %2201
  br label %2205

; <label>:2205                                    ; preds = %2180, %2166
  %2206 = phi float [ %2202, %2180 ], [ %2176, %2166 ]
  %2207 = phi float [ %2203, %2180 ], [ %2177, %2166 ]
  %2208 = phi float [ %2204, %2180 ], [ %2178, %2166 ]
  %2209 = call float @dx.op.unary.f32(i32 7, float %2206)  ; Saturate(value)
  %2210 = call float @dx.op.unary.f32(i32 7, float %2207)  ; Saturate(value)
  %2211 = call float @dx.op.unary.f32(i32 7, float %2208)  ; Saturate(value)
  %2212 = call float @dx.op.dot3.f32(i32 55, float %2209, float %2210, float %2211, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2213 = fsub fast float %2209, %2212
  %2214 = fsub fast float %2210, %2212
  %2215 = fsub fast float %2211, %2212
  %2216 = fmul fast float %2213, %9
  %2217 = fmul fast float %2214, %9
  %2218 = fmul fast float %2215, %9
  %2219 = fadd fast float %2216, %2212
  %2220 = fadd fast float %2217, %2212
  %2221 = fadd fast float %2218, %2212
  %2222 = call float @dx.op.unary.f32(i32 7, float %2219)  ; Saturate(value)
  %2223 = call float @dx.op.unary.f32(i32 7, float %2220)  ; Saturate(value)
  %2224 = call float @dx.op.unary.f32(i32 7, float %2221)  ; Saturate(value)
  %2225 = fadd fast float %2222, 0xBFC70A3D80000000
  %2226 = fadd fast float %2223, 0xBFC70A3D80000000
  %2227 = fadd fast float %2224, 0xBFC70A3D80000000
  %2228 = fmul fast float %2225, %8
  %2229 = fmul fast float %2226, %8
  %2230 = fmul fast float %2227, %8
  %2231 = fadd fast float %2228, 0x3FC70A3D80000000
  %2232 = fadd fast float %2229, 0x3FC70A3D80000000
  %2233 = fadd fast float %2230, 0x3FC70A3D80000000
  %2234 = call float @dx.op.unary.f32(i32 7, float %2231)  ; Saturate(value)
  %2235 = call float @dx.op.unary.f32(i32 7, float %2232)  ; Saturate(value)
  %2236 = call float @dx.op.unary.f32(i32 7, float %2233)  ; Saturate(value)
  br label %2237

; <label>:2237                                    ; preds = %2205, %1988
  %2238 = phi float [ %2019, %1988 ], [ %2234, %2205 ]
  %2239 = phi float [ %2020, %1988 ], [ %2235, %2205 ]
  %2240 = phi float [ %2021, %1988 ], [ %2236, %2205 ]
  %2241 = add i32 %1489, -1
  %2242 = call i32 @dx.op.binary.i32(i32 37, i32 %2241, i32 0)  ; IMax(a,b)
  %2243 = call i32 @dx.op.binary.i32(i32 37, i32 %65, i32 0)  ; IMax(a,b)
  %2244 = call i32 @dx.op.binary.i32(i32 38, i32 %2242, i32 %60)  ; IMin(a,b)
  %2245 = call i32 @dx.op.binary.i32(i32 38, i32 %2243, i32 %61)  ; IMin(a,b)
  %2246 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2244, i32 %2245, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2247 = extractvalue %dx.types.ResRet.f32 %2246, 0
  %2248 = extractvalue %dx.types.ResRet.f32 %2246, 1
  %2249 = extractvalue %dx.types.ResRet.f32 %2246, 2
  %2250 = extractvalue %dx.types.ResRet.f32 %2246, 3
  %2251 = fcmp fast olt float %2250, 0.000000e+00
  br i1 %2251, label %2252, label %2286

; <label>:2252                                    ; preds = %2237
  %2253 = fcmp fast ogt float %2247, 0x3FA4B5DCC0000000
  %2254 = fcmp fast ogt float %2248, 0x3FA4B5DCC0000000
  %2255 = fcmp fast ogt float %2249, 0x3FA4B5DCC0000000
  %2256 = select i1 %2253, float 0.000000e+00, float 1.000000e+00
  %2257 = select i1 %2254, float 0.000000e+00, float 1.000000e+00
  %2258 = select i1 %2255, float 0.000000e+00, float 1.000000e+00
  %2259 = fmul fast float %2247, 0x3FB3D07220000000
  %2260 = fmul fast float %2248, 0x3FB3D07220000000
  %2261 = fmul fast float %2249, 0x3FB3D07220000000
  %2262 = fadd fast float %2247, 0x3FAC28F5C0000000
  %2263 = fadd fast float %2248, 0x3FAC28F5C0000000
  %2264 = fadd fast float %2249, 0x3FAC28F5C0000000
  %2265 = fmul fast float %2262, 0x3FEE54EDE0000000
  %2266 = fmul fast float %2263, 0x3FEE54EDE0000000
  %2267 = fmul fast float %2264, 0x3FEE54EDE0000000
  %2268 = call float @dx.op.unary.f32(i32 23, float %2265)  ; Log(value)
  %2269 = call float @dx.op.unary.f32(i32 23, float %2266)  ; Log(value)
  %2270 = call float @dx.op.unary.f32(i32 23, float %2267)  ; Log(value)
  %2271 = fmul fast float %2268, 0x4003333340000000
  %2272 = fmul fast float %2269, 0x4003333340000000
  %2273 = fmul fast float %2270, 0x4003333340000000
  %2274 = call float @dx.op.unary.f32(i32 21, float %2271)  ; Exp(value)
  %2275 = call float @dx.op.unary.f32(i32 21, float %2272)  ; Exp(value)
  %2276 = call float @dx.op.unary.f32(i32 21, float %2273)  ; Exp(value)
  %2277 = fsub fast float %2259, %2274
  %2278 = fsub fast float %2260, %2275
  %2279 = fsub fast float %2261, %2276
  %2280 = fmul fast float %2277, %2256
  %2281 = fmul fast float %2278, %2257
  %2282 = fmul fast float %2279, %2258
  %2283 = fadd fast float %2280, %2274
  %2284 = fadd fast float %2281, %2275
  %2285 = fadd fast float %2282, %2276
  br label %2501

; <label>:2286                                    ; preds = %2237
  %2287 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2244, i32 %2245, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2288 = extractvalue %dx.types.ResRet.f32 %2287, 0
  %2289 = fcmp fast ogt float %39, 5.000000e-01
  %2290 = fcmp fast olt float %2288, 1.000000e+00
  %2291 = and i1 %2289, %2290
  br i1 %2291, label %2292, label %2430

; <label>:2292                                    ; preds = %2286
  %2293 = sitofp i32 %2244 to float
  %2294 = sitofp i32 %2245 to float
  %2295 = fadd fast float %2293, 5.000000e-01
  %2296 = fadd fast float %2294, 5.000000e-01
  %2297 = fdiv fast float %2295, %46
  %2298 = fdiv fast float %2296, %47
  %2299 = fmul fast float %2297, 2.000000e+00
  %2300 = fmul fast float %2298, 2.000000e+00
  %2301 = fadd fast float %2299, -1.000000e+00
  %2302 = fsub fast float 1.000000e+00, %2300
  %2303 = fmul fast float %2301, %36
  %2304 = call float @dx.op.tertiary.f32(i32 46, float %2302, float %32, float %2303)  ; FMad(a,b,c)
  %2305 = call float @dx.op.tertiary.f32(i32 46, float %2288, float %28, float %2304)  ; FMad(a,b,c)
  %2306 = fadd fast float %2305, %24
  %2307 = call float @dx.op.unary.f32(i32 6, float %2306)  ; FAbs(value)
  %2308 = fcmp fast ogt float %2307, 0x3EB0C6F7A0000000
  br i1 %2308, label %2309, label %2430

; <label>:2309                                    ; preds = %2292
  %2310 = fmul fast float %2301, %35
  %2311 = call float @dx.op.tertiary.f32(i32 46, float %2302, float %31, float %2310)  ; FMad(a,b,c)
  %2312 = call float @dx.op.tertiary.f32(i32 46, float %2288, float %27, float %2311)  ; FMad(a,b,c)
  %2313 = fadd fast float %2312, %23
  %2314 = fmul fast float %2301, %34
  %2315 = call float @dx.op.tertiary.f32(i32 46, float %2302, float %30, float %2314)  ; FMad(a,b,c)
  %2316 = call float @dx.op.tertiary.f32(i32 46, float %2288, float %26, float %2315)  ; FMad(a,b,c)
  %2317 = fadd fast float %2316, %22
  %2318 = fmul fast float %2301, %33
  %2319 = call float @dx.op.tertiary.f32(i32 46, float %2302, float %29, float %2318)  ; FMad(a,b,c)
  %2320 = call float @dx.op.tertiary.f32(i32 46, float %2288, float %25, float %2319)  ; FMad(a,b,c)
  %2321 = fadd fast float %2320, %21
  %2322 = fdiv fast float %2321, %2306
  %2323 = fdiv fast float %2317, %2306
  %2324 = fdiv fast float %2313, %2306
  %2325 = fsub fast float %2322, %18
  %2326 = fsub fast float %2323, %19
  %2327 = fsub fast float %2324, %20
  %2328 = fmul fast float %2325, %2325
  %2329 = fmul fast float %2326, %2326
  %2330 = fadd fast float %2329, %2328
  %2331 = fmul fast float %2327, %2327
  %2332 = fadd fast float %2330, %2331
  %2333 = call float @dx.op.unary.f32(i32 24, float %2332)  ; Sqrt(value)
  %2334 = fsub fast float %2333, %10
  %2335 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2334)  ; FMax(a,b)
  %2336 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %2336, label %2337, label %2360

; <label>:2337                                    ; preds = %2309
  %2338 = call float @dx.op.unary.f32(i32 6, float %2326)  ; FAbs(value)
  %2339 = fmul fast float %2338, %12
  %2340 = fcmp fast olt float %2339, 0x3F50624DE0000000
  br i1 %2340, label %2341, label %2344

; <label>:2341                                    ; preds = %2337
  %2342 = fmul fast float %2339, 5.000000e-01
  %2343 = fsub fast float 1.000000e+00, %2342
  br label %2349

; <label>:2344                                    ; preds = %2337
  %2345 = fmul fast float %2339, 0xBFF7154760000000
  %2346 = call float @dx.op.unary.f32(i32 21, float %2345)  ; Exp(value)
  %2347 = fsub fast float 1.000000e+00, %2346
  %2348 = fdiv fast float %2347, %2339
  br label %2349

; <label>:2349                                    ; preds = %2344, %2341
  %2350 = phi float [ %2343, %2341 ], [ %2348, %2344 ]
  %2351 = call float @dx.op.binary.f32(i32 36, float %2323, float %19)  ; FMin(a,b)
  %2352 = fsub fast float %2351, %11
  %2353 = fmul fast float %12, %2352
  %2354 = fsub fast float -0.000000e+00, %2353
  %2355 = call float @dx.op.binary.f32(i32 35, float %2354, float -4.000000e+01)  ; FMax(a,b)
  %2356 = call float @dx.op.binary.f32(i32 36, float %2355, float 5.000000e+00)  ; FMin(a,b)
  %2357 = fmul fast float %2356, 0x3FF7154760000000
  %2358 = call float @dx.op.unary.f32(i32 21, float %2357)  ; Exp(value)
  %2359 = fmul fast float %2358, %2350
  br label %2360

; <label>:2360                                    ; preds = %2349, %2309
  %2361 = phi float [ %2359, %2349 ], [ 1.000000e+00, %2309 ]
  %2362 = fmul fast float %2335, %17
  %2363 = fmul fast float %2362, %2361
  %2364 = fcmp fast ole float %2333, %10
  %2365 = fcmp fast olt float %2333, 0x3F1A36E2E0000000
  %2366 = or i1 %2364, %2365
  br i1 %2366, label %2413, label %2367

; <label>:2367                                    ; preds = %2360
  %2368 = fdiv fast float %10, %2333
  %2369 = fmul fast float %2368, %2325
  %2370 = fmul fast float %2368, %2326
  %2371 = fmul fast float %2368, %2327
  %2372 = fadd fast float %2369, %18
  %2373 = fadd fast float %2370, %19
  %2374 = fadd fast float %2371, %20
  %2375 = fadd fast float %2372, -9.000000e+02
  %2376 = fadd fast float %2373, -1.500000e+01
  %2377 = fadd fast float %2374, -7.500000e+02
  %2378 = fmul fast float %2375, 0x3F62345680000000
  %2379 = fmul fast float %2376, 0x3F62345680000000
  %2380 = fmul fast float %2377, 0x3F62345680000000
  %2381 = call float @dx.op.dot3.f32(i32 55, float %2378, float %2379, float %2380, float %2378, float %2379, float %2380)  ; Dot3(ax,ay,az,bx,by,bz)
  %2382 = fsub fast float 1.000000e+00, %2381
  %2383 = call float @dx.op.unary.f32(i32 7, float %2382)  ; Saturate(value)
  %2384 = fmul fast float %2383, %2383
  %2385 = fadd fast float %2372, %2322
  %2386 = fadd fast float %2373, %2323
  %2387 = fadd fast float %2374, %2324
  %2388 = fmul fast float %2385, 0x3F52345680000000
  %2389 = fadd fast float %2388, -2.000000e+00
  %2390 = fmul fast float %2386, 0x3F52345680000000
  %2391 = fadd fast float %2390, 0xBFA1111120000000
  %2392 = fmul fast float %2387, 0x3F52345680000000
  %2393 = fadd fast float %2392, 0xBFFAAAAAC0000000
  %2394 = call float @dx.op.dot3.f32(i32 55, float %2389, float %2391, float %2393, float %2389, float %2391, float %2393)  ; Dot3(ax,ay,az,bx,by,bz)
  %2395 = fsub fast float 1.000000e+00, %2394
  %2396 = call float @dx.op.unary.f32(i32 7, float %2395)  ; Saturate(value)
  %2397 = fmul fast float %2396, %2396
  %2398 = fmul fast float %2397, 4.000000e+00
  %2399 = fadd fast float %2398, %2384
  %2400 = fadd fast float %2322, -9.000000e+02
  %2401 = fadd fast float %2323, -1.500000e+01
  %2402 = fadd fast float %2324, -7.500000e+02
  %2403 = fmul fast float %2400, 0x3F62345680000000
  %2404 = fmul fast float %2401, 0x3F62345680000000
  %2405 = fmul fast float %2402, 0x3F62345680000000
  %2406 = call float @dx.op.dot3.f32(i32 55, float %2403, float %2404, float %2405, float %2403, float %2404, float %2405)  ; Dot3(ax,ay,az,bx,by,bz)
  %2407 = fsub fast float 1.000000e+00, %2406
  %2408 = call float @dx.op.unary.f32(i32 7, float %2407)  ; Saturate(value)
  %2409 = fmul fast float %2408, %2408
  %2410 = fadd fast float %2399, %2409
  %2411 = fmul fast float %2334, 0x3F25D867E0000000
  %2412 = fmul fast float %2411, %2410
  br label %2413

; <label>:2413                                    ; preds = %2367, %2360
  %2414 = phi float [ %2412, %2367 ], [ 0.000000e+00, %2360 ]
  %2415 = fadd fast float %2414, %2363
  %2416 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2415)  ; FMin(a,b)
  %2417 = fmul fast float %2416, 0xBFF7154760000000
  %2418 = call float @dx.op.unary.f32(i32 21, float %2417)  ; Exp(value)
  %2419 = fsub fast float 1.000000e+00, %2418
  %2420 = call float @dx.op.binary.f32(i32 36, float %13, float %2419)  ; FMin(a,b)
  %2421 = fsub fast float %14, %2247
  %2422 = fsub fast float %15, %2248
  %2423 = fsub fast float %16, %2249
  %2424 = fmul fast float %2420, %2421
  %2425 = fmul fast float %2420, %2422
  %2426 = fmul fast float %2420, %2423
  %2427 = fadd fast float %2424, %2247
  %2428 = fadd fast float %2425, %2248
  %2429 = fadd fast float %2426, %2249
  br label %2430

; <label>:2430                                    ; preds = %2413, %2292, %2286
  %2431 = phi float [ %2427, %2413 ], [ %2247, %2292 ], [ %2247, %2286 ]
  %2432 = phi float [ %2428, %2413 ], [ %2248, %2292 ], [ %2248, %2286 ]
  %2433 = phi float [ %2429, %2413 ], [ %2249, %2292 ], [ %2249, %2286 ]
  %2434 = fadd fast float %6, 1.000000e+00
  %2435 = fadd fast float %7, 1.000000e+00
  %2436 = fsub fast float 1.000000e+00, %6
  %2437 = fmul fast float %37, %2434
  %2438 = fmul fast float %37, %2435
  %2439 = fmul fast float %37, %2436
  %2440 = fmul fast float %2437, %2431
  %2441 = fmul fast float %2438, %2432
  %2442 = fmul fast float %2439, %2433
  %2443 = fcmp fast ult float %38, 5.000000e-01
  br i1 %2443, label %2469, label %2444

; <label>:2444                                    ; preds = %2430
  %2445 = fmul fast float %2440, 0x4004147AE0000000
  %2446 = fmul fast float %2441, 0x4004147AE0000000
  %2447 = fmul fast float %2442, 0x4004147AE0000000
  %2448 = fadd fast float %2445, 0x3F9EB851E0000000
  %2449 = fadd fast float %2446, 0x3F9EB851E0000000
  %2450 = fadd fast float %2447, 0x3F9EB851E0000000
  %2451 = fmul fast float %2448, %2440
  %2452 = fmul fast float %2449, %2441
  %2453 = fmul fast float %2450, %2442
  %2454 = fmul fast float %2440, 0x400370A3E0000000
  %2455 = fmul fast float %2441, 0x400370A3E0000000
  %2456 = fmul fast float %2442, 0x400370A3E0000000
  %2457 = fadd fast float %2454, 0x3FE2E147A0000000
  %2458 = fadd fast float %2455, 0x3FE2E147A0000000
  %2459 = fadd fast float %2456, 0x3FE2E147A0000000
  %2460 = fmul fast float %2457, %2440
  %2461 = fmul fast float %2458, %2441
  %2462 = fmul fast float %2459, %2442
  %2463 = fadd fast float %2460, 0x3FC1EB8520000000
  %2464 = fadd fast float %2461, 0x3FC1EB8520000000
  %2465 = fadd fast float %2462, 0x3FC1EB8520000000
  %2466 = fdiv fast float %2451, %2463
  %2467 = fdiv fast float %2452, %2464
  %2468 = fdiv fast float %2453, %2465
  br label %2469

; <label>:2469                                    ; preds = %2444, %2430
  %2470 = phi float [ %2466, %2444 ], [ %2440, %2430 ]
  %2471 = phi float [ %2467, %2444 ], [ %2441, %2430 ]
  %2472 = phi float [ %2468, %2444 ], [ %2442, %2430 ]
  %2473 = call float @dx.op.unary.f32(i32 7, float %2470)  ; Saturate(value)
  %2474 = call float @dx.op.unary.f32(i32 7, float %2471)  ; Saturate(value)
  %2475 = call float @dx.op.unary.f32(i32 7, float %2472)  ; Saturate(value)
  %2476 = call float @dx.op.dot3.f32(i32 55, float %2473, float %2474, float %2475, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2477 = fsub fast float %2473, %2476
  %2478 = fsub fast float %2474, %2476
  %2479 = fsub fast float %2475, %2476
  %2480 = fmul fast float %2477, %9
  %2481 = fmul fast float %2478, %9
  %2482 = fmul fast float %2479, %9
  %2483 = fadd fast float %2480, %2476
  %2484 = fadd fast float %2481, %2476
  %2485 = fadd fast float %2482, %2476
  %2486 = call float @dx.op.unary.f32(i32 7, float %2483)  ; Saturate(value)
  %2487 = call float @dx.op.unary.f32(i32 7, float %2484)  ; Saturate(value)
  %2488 = call float @dx.op.unary.f32(i32 7, float %2485)  ; Saturate(value)
  %2489 = fadd fast float %2486, 0xBFC70A3D80000000
  %2490 = fadd fast float %2487, 0xBFC70A3D80000000
  %2491 = fadd fast float %2488, 0xBFC70A3D80000000
  %2492 = fmul fast float %2489, %8
  %2493 = fmul fast float %2490, %8
  %2494 = fmul fast float %2491, %8
  %2495 = fadd fast float %2492, 0x3FC70A3D80000000
  %2496 = fadd fast float %2493, 0x3FC70A3D80000000
  %2497 = fadd fast float %2494, 0x3FC70A3D80000000
  %2498 = call float @dx.op.unary.f32(i32 7, float %2495)  ; Saturate(value)
  %2499 = call float @dx.op.unary.f32(i32 7, float %2496)  ; Saturate(value)
  %2500 = call float @dx.op.unary.f32(i32 7, float %2497)  ; Saturate(value)
  br label %2501

; <label>:2501                                    ; preds = %2469, %2252
  %2502 = phi float [ %2283, %2252 ], [ %2498, %2469 ]
  %2503 = phi float [ %2284, %2252 ], [ %2499, %2469 ]
  %2504 = phi float [ %2285, %2252 ], [ %2500, %2469 ]
  %2505 = add i32 %1489, 1
  %2506 = call i32 @dx.op.binary.i32(i32 37, i32 %2505, i32 0)  ; IMax(a,b)
  %2507 = call i32 @dx.op.binary.i32(i32 38, i32 %2506, i32 %60)  ; IMin(a,b)
  %2508 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2507, i32 %2245, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2509 = extractvalue %dx.types.ResRet.f32 %2508, 0
  %2510 = extractvalue %dx.types.ResRet.f32 %2508, 1
  %2511 = extractvalue %dx.types.ResRet.f32 %2508, 2
  %2512 = extractvalue %dx.types.ResRet.f32 %2508, 3
  %2513 = fcmp fast olt float %2512, 0.000000e+00
  br i1 %2513, label %2514, label %2548

; <label>:2514                                    ; preds = %2501
  %2515 = fcmp fast ogt float %2509, 0x3FA4B5DCC0000000
  %2516 = fcmp fast ogt float %2510, 0x3FA4B5DCC0000000
  %2517 = fcmp fast ogt float %2511, 0x3FA4B5DCC0000000
  %2518 = select i1 %2515, float 0.000000e+00, float 1.000000e+00
  %2519 = select i1 %2516, float 0.000000e+00, float 1.000000e+00
  %2520 = select i1 %2517, float 0.000000e+00, float 1.000000e+00
  %2521 = fmul fast float %2509, 0x3FB3D07220000000
  %2522 = fmul fast float %2510, 0x3FB3D07220000000
  %2523 = fmul fast float %2511, 0x3FB3D07220000000
  %2524 = fadd fast float %2509, 0x3FAC28F5C0000000
  %2525 = fadd fast float %2510, 0x3FAC28F5C0000000
  %2526 = fadd fast float %2511, 0x3FAC28F5C0000000
  %2527 = fmul fast float %2524, 0x3FEE54EDE0000000
  %2528 = fmul fast float %2525, 0x3FEE54EDE0000000
  %2529 = fmul fast float %2526, 0x3FEE54EDE0000000
  %2530 = call float @dx.op.unary.f32(i32 23, float %2527)  ; Log(value)
  %2531 = call float @dx.op.unary.f32(i32 23, float %2528)  ; Log(value)
  %2532 = call float @dx.op.unary.f32(i32 23, float %2529)  ; Log(value)
  %2533 = fmul fast float %2530, 0x4003333340000000
  %2534 = fmul fast float %2531, 0x4003333340000000
  %2535 = fmul fast float %2532, 0x4003333340000000
  %2536 = call float @dx.op.unary.f32(i32 21, float %2533)  ; Exp(value)
  %2537 = call float @dx.op.unary.f32(i32 21, float %2534)  ; Exp(value)
  %2538 = call float @dx.op.unary.f32(i32 21, float %2535)  ; Exp(value)
  %2539 = fsub fast float %2521, %2536
  %2540 = fsub fast float %2522, %2537
  %2541 = fsub fast float %2523, %2538
  %2542 = fmul fast float %2539, %2518
  %2543 = fmul fast float %2540, %2519
  %2544 = fmul fast float %2541, %2520
  %2545 = fadd fast float %2542, %2536
  %2546 = fadd fast float %2543, %2537
  %2547 = fadd fast float %2544, %2538
  br label %2763

; <label>:2548                                    ; preds = %2501
  %2549 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2507, i32 %2245, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2550 = extractvalue %dx.types.ResRet.f32 %2549, 0
  %2551 = fcmp fast ogt float %39, 5.000000e-01
  %2552 = fcmp fast olt float %2550, 1.000000e+00
  %2553 = and i1 %2551, %2552
  br i1 %2553, label %2554, label %2692

; <label>:2554                                    ; preds = %2548
  %2555 = sitofp i32 %2507 to float
  %2556 = sitofp i32 %2245 to float
  %2557 = fadd fast float %2555, 5.000000e-01
  %2558 = fadd fast float %2556, 5.000000e-01
  %2559 = fdiv fast float %2557, %46
  %2560 = fdiv fast float %2558, %47
  %2561 = fmul fast float %2559, 2.000000e+00
  %2562 = fmul fast float %2560, 2.000000e+00
  %2563 = fadd fast float %2561, -1.000000e+00
  %2564 = fsub fast float 1.000000e+00, %2562
  %2565 = fmul fast float %2563, %36
  %2566 = call float @dx.op.tertiary.f32(i32 46, float %2564, float %32, float %2565)  ; FMad(a,b,c)
  %2567 = call float @dx.op.tertiary.f32(i32 46, float %2550, float %28, float %2566)  ; FMad(a,b,c)
  %2568 = fadd fast float %2567, %24
  %2569 = call float @dx.op.unary.f32(i32 6, float %2568)  ; FAbs(value)
  %2570 = fcmp fast ogt float %2569, 0x3EB0C6F7A0000000
  br i1 %2570, label %2571, label %2692

; <label>:2571                                    ; preds = %2554
  %2572 = fmul fast float %2563, %35
  %2573 = call float @dx.op.tertiary.f32(i32 46, float %2564, float %31, float %2572)  ; FMad(a,b,c)
  %2574 = call float @dx.op.tertiary.f32(i32 46, float %2550, float %27, float %2573)  ; FMad(a,b,c)
  %2575 = fadd fast float %2574, %23
  %2576 = fmul fast float %2563, %34
  %2577 = call float @dx.op.tertiary.f32(i32 46, float %2564, float %30, float %2576)  ; FMad(a,b,c)
  %2578 = call float @dx.op.tertiary.f32(i32 46, float %2550, float %26, float %2577)  ; FMad(a,b,c)
  %2579 = fadd fast float %2578, %22
  %2580 = fmul fast float %2563, %33
  %2581 = call float @dx.op.tertiary.f32(i32 46, float %2564, float %29, float %2580)  ; FMad(a,b,c)
  %2582 = call float @dx.op.tertiary.f32(i32 46, float %2550, float %25, float %2581)  ; FMad(a,b,c)
  %2583 = fadd fast float %2582, %21
  %2584 = fdiv fast float %2583, %2568
  %2585 = fdiv fast float %2579, %2568
  %2586 = fdiv fast float %2575, %2568
  %2587 = fsub fast float %2584, %18
  %2588 = fsub fast float %2585, %19
  %2589 = fsub fast float %2586, %20
  %2590 = fmul fast float %2587, %2587
  %2591 = fmul fast float %2588, %2588
  %2592 = fadd fast float %2591, %2590
  %2593 = fmul fast float %2589, %2589
  %2594 = fadd fast float %2592, %2593
  %2595 = call float @dx.op.unary.f32(i32 24, float %2594)  ; Sqrt(value)
  %2596 = fsub fast float %2595, %10
  %2597 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2596)  ; FMax(a,b)
  %2598 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %2598, label %2599, label %2622

; <label>:2599                                    ; preds = %2571
  %2600 = call float @dx.op.unary.f32(i32 6, float %2588)  ; FAbs(value)
  %2601 = fmul fast float %2600, %12
  %2602 = fcmp fast olt float %2601, 0x3F50624DE0000000
  br i1 %2602, label %2603, label %2606

; <label>:2603                                    ; preds = %2599
  %2604 = fmul fast float %2601, 5.000000e-01
  %2605 = fsub fast float 1.000000e+00, %2604
  br label %2611

; <label>:2606                                    ; preds = %2599
  %2607 = fmul fast float %2601, 0xBFF7154760000000
  %2608 = call float @dx.op.unary.f32(i32 21, float %2607)  ; Exp(value)
  %2609 = fsub fast float 1.000000e+00, %2608
  %2610 = fdiv fast float %2609, %2601
  br label %2611

; <label>:2611                                    ; preds = %2606, %2603
  %2612 = phi float [ %2605, %2603 ], [ %2610, %2606 ]
  %2613 = call float @dx.op.binary.f32(i32 36, float %2585, float %19)  ; FMin(a,b)
  %2614 = fsub fast float %2613, %11
  %2615 = fmul fast float %12, %2614
  %2616 = fsub fast float -0.000000e+00, %2615
  %2617 = call float @dx.op.binary.f32(i32 35, float %2616, float -4.000000e+01)  ; FMax(a,b)
  %2618 = call float @dx.op.binary.f32(i32 36, float %2617, float 5.000000e+00)  ; FMin(a,b)
  %2619 = fmul fast float %2618, 0x3FF7154760000000
  %2620 = call float @dx.op.unary.f32(i32 21, float %2619)  ; Exp(value)
  %2621 = fmul fast float %2620, %2612
  br label %2622

; <label>:2622                                    ; preds = %2611, %2571
  %2623 = phi float [ %2621, %2611 ], [ 1.000000e+00, %2571 ]
  %2624 = fmul fast float %2597, %17
  %2625 = fmul fast float %2624, %2623
  %2626 = fcmp fast ole float %2595, %10
  %2627 = fcmp fast olt float %2595, 0x3F1A36E2E0000000
  %2628 = or i1 %2626, %2627
  br i1 %2628, label %2675, label %2629

; <label>:2629                                    ; preds = %2622
  %2630 = fdiv fast float %10, %2595
  %2631 = fmul fast float %2630, %2587
  %2632 = fmul fast float %2630, %2588
  %2633 = fmul fast float %2630, %2589
  %2634 = fadd fast float %2631, %18
  %2635 = fadd fast float %2632, %19
  %2636 = fadd fast float %2633, %20
  %2637 = fadd fast float %2634, -9.000000e+02
  %2638 = fadd fast float %2635, -1.500000e+01
  %2639 = fadd fast float %2636, -7.500000e+02
  %2640 = fmul fast float %2637, 0x3F62345680000000
  %2641 = fmul fast float %2638, 0x3F62345680000000
  %2642 = fmul fast float %2639, 0x3F62345680000000
  %2643 = call float @dx.op.dot3.f32(i32 55, float %2640, float %2641, float %2642, float %2640, float %2641, float %2642)  ; Dot3(ax,ay,az,bx,by,bz)
  %2644 = fsub fast float 1.000000e+00, %2643
  %2645 = call float @dx.op.unary.f32(i32 7, float %2644)  ; Saturate(value)
  %2646 = fmul fast float %2645, %2645
  %2647 = fadd fast float %2634, %2584
  %2648 = fadd fast float %2635, %2585
  %2649 = fadd fast float %2636, %2586
  %2650 = fmul fast float %2647, 0x3F52345680000000
  %2651 = fadd fast float %2650, -2.000000e+00
  %2652 = fmul fast float %2648, 0x3F52345680000000
  %2653 = fadd fast float %2652, 0xBFA1111120000000
  %2654 = fmul fast float %2649, 0x3F52345680000000
  %2655 = fadd fast float %2654, 0xBFFAAAAAC0000000
  %2656 = call float @dx.op.dot3.f32(i32 55, float %2651, float %2653, float %2655, float %2651, float %2653, float %2655)  ; Dot3(ax,ay,az,bx,by,bz)
  %2657 = fsub fast float 1.000000e+00, %2656
  %2658 = call float @dx.op.unary.f32(i32 7, float %2657)  ; Saturate(value)
  %2659 = fmul fast float %2658, %2658
  %2660 = fmul fast float %2659, 4.000000e+00
  %2661 = fadd fast float %2660, %2646
  %2662 = fadd fast float %2584, -9.000000e+02
  %2663 = fadd fast float %2585, -1.500000e+01
  %2664 = fadd fast float %2586, -7.500000e+02
  %2665 = fmul fast float %2662, 0x3F62345680000000
  %2666 = fmul fast float %2663, 0x3F62345680000000
  %2667 = fmul fast float %2664, 0x3F62345680000000
  %2668 = call float @dx.op.dot3.f32(i32 55, float %2665, float %2666, float %2667, float %2665, float %2666, float %2667)  ; Dot3(ax,ay,az,bx,by,bz)
  %2669 = fsub fast float 1.000000e+00, %2668
  %2670 = call float @dx.op.unary.f32(i32 7, float %2669)  ; Saturate(value)
  %2671 = fmul fast float %2670, %2670
  %2672 = fadd fast float %2661, %2671
  %2673 = fmul fast float %2596, 0x3F25D867E0000000
  %2674 = fmul fast float %2673, %2672
  br label %2675

; <label>:2675                                    ; preds = %2629, %2622
  %2676 = phi float [ %2674, %2629 ], [ 0.000000e+00, %2622 ]
  %2677 = fadd fast float %2676, %2625
  %2678 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2677)  ; FMin(a,b)
  %2679 = fmul fast float %2678, 0xBFF7154760000000
  %2680 = call float @dx.op.unary.f32(i32 21, float %2679)  ; Exp(value)
  %2681 = fsub fast float 1.000000e+00, %2680
  %2682 = call float @dx.op.binary.f32(i32 36, float %13, float %2681)  ; FMin(a,b)
  %2683 = fsub fast float %14, %2509
  %2684 = fsub fast float %15, %2510
  %2685 = fsub fast float %16, %2511
  %2686 = fmul fast float %2682, %2683
  %2687 = fmul fast float %2682, %2684
  %2688 = fmul fast float %2682, %2685
  %2689 = fadd fast float %2686, %2509
  %2690 = fadd fast float %2687, %2510
  %2691 = fadd fast float %2688, %2511
  br label %2692

; <label>:2692                                    ; preds = %2675, %2554, %2548
  %2693 = phi float [ %2689, %2675 ], [ %2509, %2554 ], [ %2509, %2548 ]
  %2694 = phi float [ %2690, %2675 ], [ %2510, %2554 ], [ %2510, %2548 ]
  %2695 = phi float [ %2691, %2675 ], [ %2511, %2554 ], [ %2511, %2548 ]
  %2696 = fadd fast float %6, 1.000000e+00
  %2697 = fadd fast float %7, 1.000000e+00
  %2698 = fsub fast float 1.000000e+00, %6
  %2699 = fmul fast float %37, %2696
  %2700 = fmul fast float %37, %2697
  %2701 = fmul fast float %37, %2698
  %2702 = fmul fast float %2699, %2693
  %2703 = fmul fast float %2700, %2694
  %2704 = fmul fast float %2701, %2695
  %2705 = fcmp fast ult float %38, 5.000000e-01
  br i1 %2705, label %2731, label %2706

; <label>:2706                                    ; preds = %2692
  %2707 = fmul fast float %2702, 0x4004147AE0000000
  %2708 = fmul fast float %2703, 0x4004147AE0000000
  %2709 = fmul fast float %2704, 0x4004147AE0000000
  %2710 = fadd fast float %2707, 0x3F9EB851E0000000
  %2711 = fadd fast float %2708, 0x3F9EB851E0000000
  %2712 = fadd fast float %2709, 0x3F9EB851E0000000
  %2713 = fmul fast float %2710, %2702
  %2714 = fmul fast float %2711, %2703
  %2715 = fmul fast float %2712, %2704
  %2716 = fmul fast float %2702, 0x400370A3E0000000
  %2717 = fmul fast float %2703, 0x400370A3E0000000
  %2718 = fmul fast float %2704, 0x400370A3E0000000
  %2719 = fadd fast float %2716, 0x3FE2E147A0000000
  %2720 = fadd fast float %2717, 0x3FE2E147A0000000
  %2721 = fadd fast float %2718, 0x3FE2E147A0000000
  %2722 = fmul fast float %2719, %2702
  %2723 = fmul fast float %2720, %2703
  %2724 = fmul fast float %2721, %2704
  %2725 = fadd fast float %2722, 0x3FC1EB8520000000
  %2726 = fadd fast float %2723, 0x3FC1EB8520000000
  %2727 = fadd fast float %2724, 0x3FC1EB8520000000
  %2728 = fdiv fast float %2713, %2725
  %2729 = fdiv fast float %2714, %2726
  %2730 = fdiv fast float %2715, %2727
  br label %2731

; <label>:2731                                    ; preds = %2706, %2692
  %2732 = phi float [ %2728, %2706 ], [ %2702, %2692 ]
  %2733 = phi float [ %2729, %2706 ], [ %2703, %2692 ]
  %2734 = phi float [ %2730, %2706 ], [ %2704, %2692 ]
  %2735 = call float @dx.op.unary.f32(i32 7, float %2732)  ; Saturate(value)
  %2736 = call float @dx.op.unary.f32(i32 7, float %2733)  ; Saturate(value)
  %2737 = call float @dx.op.unary.f32(i32 7, float %2734)  ; Saturate(value)
  %2738 = call float @dx.op.dot3.f32(i32 55, float %2735, float %2736, float %2737, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2739 = fsub fast float %2735, %2738
  %2740 = fsub fast float %2736, %2738
  %2741 = fsub fast float %2737, %2738
  %2742 = fmul fast float %2739, %9
  %2743 = fmul fast float %2740, %9
  %2744 = fmul fast float %2741, %9
  %2745 = fadd fast float %2742, %2738
  %2746 = fadd fast float %2743, %2738
  %2747 = fadd fast float %2744, %2738
  %2748 = call float @dx.op.unary.f32(i32 7, float %2745)  ; Saturate(value)
  %2749 = call float @dx.op.unary.f32(i32 7, float %2746)  ; Saturate(value)
  %2750 = call float @dx.op.unary.f32(i32 7, float %2747)  ; Saturate(value)
  %2751 = fadd fast float %2748, 0xBFC70A3D80000000
  %2752 = fadd fast float %2749, 0xBFC70A3D80000000
  %2753 = fadd fast float %2750, 0xBFC70A3D80000000
  %2754 = fmul fast float %2751, %8
  %2755 = fmul fast float %2752, %8
  %2756 = fmul fast float %2753, %8
  %2757 = fadd fast float %2754, 0x3FC70A3D80000000
  %2758 = fadd fast float %2755, 0x3FC70A3D80000000
  %2759 = fadd fast float %2756, 0x3FC70A3D80000000
  %2760 = call float @dx.op.unary.f32(i32 7, float %2757)  ; Saturate(value)
  %2761 = call float @dx.op.unary.f32(i32 7, float %2758)  ; Saturate(value)
  %2762 = call float @dx.op.unary.f32(i32 7, float %2759)  ; Saturate(value)
  br label %2763

; <label>:2763                                    ; preds = %2731, %2514
  %2764 = phi float [ %2545, %2514 ], [ %2760, %2731 ]
  %2765 = phi float [ %2546, %2514 ], [ %2761, %2731 ]
  %2766 = phi float [ %2547, %2514 ], [ %2762, %2731 ]
  %2767 = call float @dx.op.binary.f32(i32 36, float %2502, float %2764)  ; FMin(a,b)
  %2768 = call float @dx.op.binary.f32(i32 36, float %2503, float %2765)  ; FMin(a,b)
  %2769 = call float @dx.op.binary.f32(i32 36, float %2504, float %2766)  ; FMin(a,b)
  %2770 = call float @dx.op.binary.f32(i32 36, float %1976, float %2238)  ; FMin(a,b)
  %2771 = call float @dx.op.binary.f32(i32 36, float %1977, float %2239)  ; FMin(a,b)
  %2772 = call float @dx.op.binary.f32(i32 36, float %1978, float %2240)  ; FMin(a,b)
  %2773 = call float @dx.op.binary.f32(i32 36, float %2770, float %2767)  ; FMin(a,b)
  %2774 = call float @dx.op.binary.f32(i32 36, float %2771, float %2768)  ; FMin(a,b)
  %2775 = call float @dx.op.binary.f32(i32 36, float %2772, float %2769)  ; FMin(a,b)
  %2776 = call float @dx.op.binary.f32(i32 36, float %1710, float %2773)  ; FMin(a,b)
  %2777 = call float @dx.op.binary.f32(i32 36, float %1711, float %2774)  ; FMin(a,b)
  %2778 = call float @dx.op.binary.f32(i32 36, float %1712, float %2775)  ; FMin(a,b)
  %2779 = call float @dx.op.binary.f32(i32 35, float %2502, float %2764)  ; FMax(a,b)
  %2780 = call float @dx.op.binary.f32(i32 35, float %2503, float %2765)  ; FMax(a,b)
  %2781 = call float @dx.op.binary.f32(i32 35, float %2504, float %2766)  ; FMax(a,b)
  %2782 = call float @dx.op.binary.f32(i32 35, float %1976, float %2238)  ; FMax(a,b)
  %2783 = call float @dx.op.binary.f32(i32 35, float %1977, float %2239)  ; FMax(a,b)
  %2784 = call float @dx.op.binary.f32(i32 35, float %1978, float %2240)  ; FMax(a,b)
  %2785 = call float @dx.op.binary.f32(i32 35, float %2782, float %2779)  ; FMax(a,b)
  %2786 = call float @dx.op.binary.f32(i32 35, float %2783, float %2780)  ; FMax(a,b)
  %2787 = call float @dx.op.binary.f32(i32 35, float %2784, float %2781)  ; FMax(a,b)
  %2788 = call float @dx.op.binary.f32(i32 35, float %1710, float %2785)  ; FMax(a,b)
  %2789 = call float @dx.op.binary.f32(i32 35, float %1711, float %2786)  ; FMax(a,b)
  %2790 = call float @dx.op.binary.f32(i32 35, float %1712, float %2787)  ; FMax(a,b)
  %2791 = fsub fast float %2788, %2776
  %2792 = fsub fast float %2789, %2777
  %2793 = fsub fast float %2790, %2778
  %2794 = call float @dx.op.unary.f32(i32 6, float %2791)  ; FAbs(value)
  %2795 = call float @dx.op.unary.f32(i32 6, float %2792)  ; FAbs(value)
  %2796 = call float @dx.op.unary.f32(i32 6, float %2793)  ; FAbs(value)
  %2797 = call float @dx.op.binary.f32(i32 35, float %2795, float %2796)  ; FMax(a,b)
  %2798 = call float @dx.op.binary.f32(i32 35, float %2794, float %2797)  ; FMax(a,b)
  %2799 = call float @dx.op.binary.f32(i32 35, float %2789, float %2790)  ; FMax(a,b)
  %2800 = call float @dx.op.binary.f32(i32 35, float %2788, float %2799)  ; FMax(a,b)
  %2801 = fmul fast float %2800, 1.250000e-01
  %2802 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %2801)  ; FMax(a,b)
  %2803 = fcmp fast ogt float %2798, %2802
  br i1 %2803, label %2804, label %2866

; <label>:2804                                    ; preds = %2763
  %2805 = fsub fast float %1976, %2238
  %2806 = fsub fast float %1977, %2239
  %2807 = fsub fast float %1978, %2240
  %2808 = call float @dx.op.unary.f32(i32 6, float %2805)  ; FAbs(value)
  %2809 = call float @dx.op.unary.f32(i32 6, float %2806)  ; FAbs(value)
  %2810 = call float @dx.op.unary.f32(i32 6, float %2807)  ; FAbs(value)
  %2811 = call float @dx.op.binary.f32(i32 35, float %2809, float %2810)  ; FMax(a,b)
  %2812 = call float @dx.op.binary.f32(i32 35, float %2808, float %2811)  ; FMax(a,b)
  %2813 = fsub fast float %2502, %2764
  %2814 = fsub fast float %2503, %2765
  %2815 = fsub fast float %2504, %2766
  %2816 = call float @dx.op.unary.f32(i32 6, float %2813)  ; FAbs(value)
  %2817 = call float @dx.op.unary.f32(i32 6, float %2814)  ; FAbs(value)
  %2818 = call float @dx.op.unary.f32(i32 6, float %2815)  ; FAbs(value)
  %2819 = call float @dx.op.binary.f32(i32 35, float %2817, float %2818)  ; FMax(a,b)
  %2820 = call float @dx.op.binary.f32(i32 35, float %2816, float %2819)  ; FMax(a,b)
  %2821 = fcmp fast olt float %2812, %2820
  %2822 = select i1 %2821, float %1976, float %2502
  %2823 = select i1 %2821, float %1977, float %2503
  %2824 = select i1 %2821, float %1978, float %2504
  %2825 = select i1 %2821, float %2238, float %2764
  %2826 = select i1 %2821, float %2239, float %2765
  %2827 = select i1 %2821, float %2240, float %2766
  %2828 = fsub fast float %1710, %2825
  %2829 = fsub fast float %1711, %2826
  %2830 = fsub fast float %1712, %2827
  %2831 = fsub fast float %1710, %2822
  %2832 = fsub fast float %1711, %2823
  %2833 = fsub fast float %1712, %2824
  %2834 = call float @dx.op.dot3.f32(i32 55, float %2831, float %2832, float %2833, float %2828, float %2829, float %2830)  ; Dot3(ax,ay,az,bx,by,bz)
  %2835 = fcmp fast ogt float %2834, 0.000000e+00
  br i1 %2835, label %2836, label %2847

; <label>:2836                                    ; preds = %2804
  %2837 = fsub fast float %2822, %2825
  %2838 = fsub fast float %2823, %2826
  %2839 = fsub fast float %2824, %2827
  %2840 = call float @dx.op.unary.f32(i32 6, float %2837)  ; FAbs(value)
  %2841 = call float @dx.op.unary.f32(i32 6, float %2838)  ; FAbs(value)
  %2842 = call float @dx.op.unary.f32(i32 6, float %2839)  ; FAbs(value)
  %2843 = call float @dx.op.binary.f32(i32 35, float %2841, float %2842)  ; FMax(a,b)
  %2844 = call float @dx.op.binary.f32(i32 35, float %2840, float %2843)  ; FMax(a,b)
  %2845 = fmul fast float %2798, 2.500000e-01
  %2846 = fcmp fast olt float %2844, %2845
  br label %2847

; <label>:2847                                    ; preds = %2836, %2804
  %2848 = phi i1 [ false, %2804 ], [ %2846, %2836 ]
  %2849 = select i1 %2848, float 5.000000e-01, float 1.000000e+00
  %2850 = fmul fast float %2849, %3
  %2851 = fadd fast float %2822, %2825
  %2852 = fadd fast float %2823, %2826
  %2853 = fadd fast float %2824, %2827
  %2854 = fmul fast float %2851, 5.000000e-01
  %2855 = fmul fast float %2852, 5.000000e-01
  %2856 = fmul fast float %2853, 5.000000e-01
  %2857 = fsub fast float %2854, %1710
  %2858 = fsub fast float %2855, %1711
  %2859 = fsub fast float %2856, %1712
  %2860 = fmul fast float %2850, %2857
  %2861 = fmul fast float %2850, %2858
  %2862 = fmul fast float %2850, %2859
  %2863 = fadd fast float %2860, %1710
  %2864 = fadd fast float %2861, %1711
  %2865 = fadd fast float %2862, %1712
  br label %2866

; <label>:2866                                    ; preds = %2847, %2763, %1681
  %2867 = phi float [ %2863, %2847 ], [ %1710, %2763 ], [ %1710, %1681 ]
  %2868 = phi float [ %2864, %2847 ], [ %1711, %2763 ], [ %1711, %1681 ]
  %2869 = phi float [ %2865, %2847 ], [ %1712, %2763 ], [ %1712, %1681 ]
  %2870 = fcmp fast ogt float %2867, 0x3F69A5C380000000
  %2871 = fcmp fast ogt float %2868, 0x3F69A5C380000000
  %2872 = fcmp fast ogt float %2869, 0x3F69A5C380000000
  %2873 = select i1 %2870, float 0.000000e+00, float 1.000000e+00
  %2874 = select i1 %2871, float 0.000000e+00, float 1.000000e+00
  %2875 = select i1 %2872, float 0.000000e+00, float 1.000000e+00
  %2876 = fmul fast float %2867, 0x4029D70A40000000
  %2877 = fmul fast float %2868, 0x4029D70A40000000
  %2878 = fmul fast float %2869, 0x4029D70A40000000
  %2879 = call float @dx.op.binary.f32(i32 35, float %2867, float 0.000000e+00)  ; FMax(a,b)
  %2880 = call float @dx.op.binary.f32(i32 35, float %2868, float 0.000000e+00)  ; FMax(a,b)
  %2881 = call float @dx.op.binary.f32(i32 35, float %2869, float 0.000000e+00)  ; FMax(a,b)
  %2882 = call float @dx.op.unary.f32(i32 23, float %2879)  ; Log(value)
  %2883 = call float @dx.op.unary.f32(i32 23, float %2880)  ; Log(value)
  %2884 = call float @dx.op.unary.f32(i32 23, float %2881)  ; Log(value)
  %2885 = fmul fast float %2882, 0x3FDAAAAAA0000000
  %2886 = fmul fast float %2883, 0x3FDAAAAAA0000000
  %2887 = fmul fast float %2884, 0x3FDAAAAAA0000000
  %2888 = call float @dx.op.unary.f32(i32 21, float %2885)  ; Exp(value)
  %2889 = call float @dx.op.unary.f32(i32 21, float %2886)  ; Exp(value)
  %2890 = call float @dx.op.unary.f32(i32 21, float %2887)  ; Exp(value)
  %2891 = fmul fast float %2888, 0x3FF0E147A0000000
  %2892 = fmul fast float %2889, 0x3FF0E147A0000000
  %2893 = fmul fast float %2890, 0x3FF0E147A0000000
  %2894 = fadd fast float %2891, 0xBFAC28F5C0000000
  %2895 = fadd fast float %2892, 0xBFAC28F5C0000000
  %2896 = fadd fast float %2893, 0xBFAC28F5C0000000
  %2897 = fsub fast float %2876, %2894
  %2898 = fsub fast float %2877, %2895
  %2899 = fsub fast float %2878, %2896
  %2900 = fmul fast float %2897, %2873
  %2901 = fmul fast float %2898, %2874
  %2902 = fmul fast float %2899, %2875
  %2903 = fadd fast float %2900, %2894
  %2904 = fadd fast float %2901, %2895
  %2905 = fadd fast float %2902, %2896
  br label %2906

; <label>:2906                                    ; preds = %2866, %1496
  %2907 = phi float [ %1491, %1496 ], [ %2903, %2866 ]
  %2908 = phi float [ %1492, %1496 ], [ %2904, %2866 ]
  %2909 = phi float [ %1493, %1496 ], [ %2905, %2866 ]
  %2910 = phi float [ %1497, %1496 ], [ %1494, %2866 ]
  %2911 = add i32 %57, 1
  %2912 = call i32 @dx.op.binary.i32(i32 37, i32 %2911, i32 0)  ; IMax(a,b)
  %2913 = call i32 @dx.op.binary.i32(i32 38, i32 %2912, i32 %61)  ; IMin(a,b)
  %2914 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %64, i32 %2913, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2915 = extractvalue %dx.types.ResRet.f32 %2914, 0
  %2916 = extractvalue %dx.types.ResRet.f32 %2914, 1
  %2917 = extractvalue %dx.types.ResRet.f32 %2914, 2
  %2918 = extractvalue %dx.types.ResRet.f32 %2914, 3
  %2919 = fcmp fast olt float %2918, 0.000000e+00
  br i1 %2919, label %2920, label %2922

; <label>:2920                                    ; preds = %2906
  %2921 = fsub fast float -1.000000e+00, %2918
  br label %4330

; <label>:2922                                    ; preds = %2906
  %2923 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %64, i32 %2913, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2924 = extractvalue %dx.types.ResRet.f32 %2923, 0
  %2925 = fcmp fast ogt float %39, 5.000000e-01
  %2926 = fcmp fast olt float %2924, 1.000000e+00
  %2927 = and i1 %2925, %2926
  br i1 %2927, label %2928, label %3066

; <label>:2928                                    ; preds = %2922
  %2929 = sitofp i32 %64 to float
  %2930 = sitofp i32 %2913 to float
  %2931 = fadd fast float %2929, 5.000000e-01
  %2932 = fadd fast float %2930, 5.000000e-01
  %2933 = fdiv fast float %2931, %46
  %2934 = fdiv fast float %2932, %47
  %2935 = fmul fast float %2933, 2.000000e+00
  %2936 = fmul fast float %2934, 2.000000e+00
  %2937 = fadd fast float %2935, -1.000000e+00
  %2938 = fsub fast float 1.000000e+00, %2936
  %2939 = fmul fast float %2937, %36
  %2940 = call float @dx.op.tertiary.f32(i32 46, float %2938, float %32, float %2939)  ; FMad(a,b,c)
  %2941 = call float @dx.op.tertiary.f32(i32 46, float %2924, float %28, float %2940)  ; FMad(a,b,c)
  %2942 = fadd fast float %2941, %24
  %2943 = call float @dx.op.unary.f32(i32 6, float %2942)  ; FAbs(value)
  %2944 = fcmp fast ogt float %2943, 0x3EB0C6F7A0000000
  br i1 %2944, label %2945, label %3066

; <label>:2945                                    ; preds = %2928
  %2946 = fmul fast float %2937, %35
  %2947 = call float @dx.op.tertiary.f32(i32 46, float %2938, float %31, float %2946)  ; FMad(a,b,c)
  %2948 = call float @dx.op.tertiary.f32(i32 46, float %2924, float %27, float %2947)  ; FMad(a,b,c)
  %2949 = fadd fast float %2948, %23
  %2950 = fmul fast float %2937, %34
  %2951 = call float @dx.op.tertiary.f32(i32 46, float %2938, float %30, float %2950)  ; FMad(a,b,c)
  %2952 = call float @dx.op.tertiary.f32(i32 46, float %2924, float %26, float %2951)  ; FMad(a,b,c)
  %2953 = fadd fast float %2952, %22
  %2954 = fmul fast float %2937, %33
  %2955 = call float @dx.op.tertiary.f32(i32 46, float %2938, float %29, float %2954)  ; FMad(a,b,c)
  %2956 = call float @dx.op.tertiary.f32(i32 46, float %2924, float %25, float %2955)  ; FMad(a,b,c)
  %2957 = fadd fast float %2956, %21
  %2958 = fdiv fast float %2957, %2942
  %2959 = fdiv fast float %2953, %2942
  %2960 = fdiv fast float %2949, %2942
  %2961 = fsub fast float %2958, %18
  %2962 = fsub fast float %2959, %19
  %2963 = fsub fast float %2960, %20
  %2964 = fmul fast float %2961, %2961
  %2965 = fmul fast float %2962, %2962
  %2966 = fadd fast float %2965, %2964
  %2967 = fmul fast float %2963, %2963
  %2968 = fadd fast float %2966, %2967
  %2969 = call float @dx.op.unary.f32(i32 24, float %2968)  ; Sqrt(value)
  %2970 = fsub fast float %2969, %10
  %2971 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2970)  ; FMax(a,b)
  %2972 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %2972, label %2973, label %2996

; <label>:2973                                    ; preds = %2945
  %2974 = call float @dx.op.unary.f32(i32 6, float %2962)  ; FAbs(value)
  %2975 = fmul fast float %2974, %12
  %2976 = fcmp fast olt float %2975, 0x3F50624DE0000000
  br i1 %2976, label %2977, label %2980

; <label>:2977                                    ; preds = %2973
  %2978 = fmul fast float %2975, 5.000000e-01
  %2979 = fsub fast float 1.000000e+00, %2978
  br label %2985

; <label>:2980                                    ; preds = %2973
  %2981 = fmul fast float %2975, 0xBFF7154760000000
  %2982 = call float @dx.op.unary.f32(i32 21, float %2981)  ; Exp(value)
  %2983 = fsub fast float 1.000000e+00, %2982
  %2984 = fdiv fast float %2983, %2975
  br label %2985

; <label>:2985                                    ; preds = %2980, %2977
  %2986 = phi float [ %2979, %2977 ], [ %2984, %2980 ]
  %2987 = call float @dx.op.binary.f32(i32 36, float %2959, float %19)  ; FMin(a,b)
  %2988 = fsub fast float %2987, %11
  %2989 = fmul fast float %12, %2988
  %2990 = fsub fast float -0.000000e+00, %2989
  %2991 = call float @dx.op.binary.f32(i32 35, float %2990, float -4.000000e+01)  ; FMax(a,b)
  %2992 = call float @dx.op.binary.f32(i32 36, float %2991, float 5.000000e+00)  ; FMin(a,b)
  %2993 = fmul fast float %2992, 0x3FF7154760000000
  %2994 = call float @dx.op.unary.f32(i32 21, float %2993)  ; Exp(value)
  %2995 = fmul fast float %2994, %2986
  br label %2996

; <label>:2996                                    ; preds = %2985, %2945
  %2997 = phi float [ %2995, %2985 ], [ 1.000000e+00, %2945 ]
  %2998 = fmul fast float %2971, %17
  %2999 = fmul fast float %2998, %2997
  %3000 = fcmp fast ole float %2969, %10
  %3001 = fcmp fast olt float %2969, 0x3F1A36E2E0000000
  %3002 = or i1 %3000, %3001
  br i1 %3002, label %3049, label %3003

; <label>:3003                                    ; preds = %2996
  %3004 = fdiv fast float %10, %2969
  %3005 = fmul fast float %3004, %2961
  %3006 = fmul fast float %3004, %2962
  %3007 = fmul fast float %3004, %2963
  %3008 = fadd fast float %3005, %18
  %3009 = fadd fast float %3006, %19
  %3010 = fadd fast float %3007, %20
  %3011 = fadd fast float %3008, -9.000000e+02
  %3012 = fadd fast float %3009, -1.500000e+01
  %3013 = fadd fast float %3010, -7.500000e+02
  %3014 = fmul fast float %3011, 0x3F62345680000000
  %3015 = fmul fast float %3012, 0x3F62345680000000
  %3016 = fmul fast float %3013, 0x3F62345680000000
  %3017 = call float @dx.op.dot3.f32(i32 55, float %3014, float %3015, float %3016, float %3014, float %3015, float %3016)  ; Dot3(ax,ay,az,bx,by,bz)
  %3018 = fsub fast float 1.000000e+00, %3017
  %3019 = call float @dx.op.unary.f32(i32 7, float %3018)  ; Saturate(value)
  %3020 = fmul fast float %3019, %3019
  %3021 = fadd fast float %3008, %2958
  %3022 = fadd fast float %3009, %2959
  %3023 = fadd fast float %3010, %2960
  %3024 = fmul fast float %3021, 0x3F52345680000000
  %3025 = fadd fast float %3024, -2.000000e+00
  %3026 = fmul fast float %3022, 0x3F52345680000000
  %3027 = fadd fast float %3026, 0xBFA1111120000000
  %3028 = fmul fast float %3023, 0x3F52345680000000
  %3029 = fadd fast float %3028, 0xBFFAAAAAC0000000
  %3030 = call float @dx.op.dot3.f32(i32 55, float %3025, float %3027, float %3029, float %3025, float %3027, float %3029)  ; Dot3(ax,ay,az,bx,by,bz)
  %3031 = fsub fast float 1.000000e+00, %3030
  %3032 = call float @dx.op.unary.f32(i32 7, float %3031)  ; Saturate(value)
  %3033 = fmul fast float %3032, %3032
  %3034 = fmul fast float %3033, 4.000000e+00
  %3035 = fadd fast float %3034, %3020
  %3036 = fadd fast float %2958, -9.000000e+02
  %3037 = fadd fast float %2959, -1.500000e+01
  %3038 = fadd fast float %2960, -7.500000e+02
  %3039 = fmul fast float %3036, 0x3F62345680000000
  %3040 = fmul fast float %3037, 0x3F62345680000000
  %3041 = fmul fast float %3038, 0x3F62345680000000
  %3042 = call float @dx.op.dot3.f32(i32 55, float %3039, float %3040, float %3041, float %3039, float %3040, float %3041)  ; Dot3(ax,ay,az,bx,by,bz)
  %3043 = fsub fast float 1.000000e+00, %3042
  %3044 = call float @dx.op.unary.f32(i32 7, float %3043)  ; Saturate(value)
  %3045 = fmul fast float %3044, %3044
  %3046 = fadd fast float %3035, %3045
  %3047 = fmul fast float %2970, 0x3F25D867E0000000
  %3048 = fmul fast float %3047, %3046
  br label %3049

; <label>:3049                                    ; preds = %3003, %2996
  %3050 = phi float [ %3048, %3003 ], [ 0.000000e+00, %2996 ]
  %3051 = fadd fast float %3050, %2999
  %3052 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3051)  ; FMin(a,b)
  %3053 = fmul fast float %3052, 0xBFF7154760000000
  %3054 = call float @dx.op.unary.f32(i32 21, float %3053)  ; Exp(value)
  %3055 = fsub fast float 1.000000e+00, %3054
  %3056 = call float @dx.op.binary.f32(i32 36, float %13, float %3055)  ; FMin(a,b)
  %3057 = fsub fast float %14, %2915
  %3058 = fsub fast float %15, %2916
  %3059 = fsub fast float %16, %2917
  %3060 = fmul fast float %3056, %3057
  %3061 = fmul fast float %3056, %3058
  %3062 = fmul fast float %3056, %3059
  %3063 = fadd fast float %3060, %2915
  %3064 = fadd fast float %3061, %2916
  %3065 = fadd fast float %3062, %2917
  br label %3066

; <label>:3066                                    ; preds = %3049, %2928, %2922
  %3067 = phi float [ %3063, %3049 ], [ %2915, %2928 ], [ %2915, %2922 ]
  %3068 = phi float [ %3064, %3049 ], [ %2916, %2928 ], [ %2916, %2922 ]
  %3069 = phi float [ %3065, %3049 ], [ %2917, %2928 ], [ %2917, %2922 ]
  %3070 = fadd fast float %6, 1.000000e+00
  %3071 = fadd fast float %7, 1.000000e+00
  %3072 = fsub fast float 1.000000e+00, %6
  %3073 = fmul fast float %37, %3070
  %3074 = fmul fast float %37, %3071
  %3075 = fmul fast float %37, %3072
  %3076 = fmul fast float %3073, %3067
  %3077 = fmul fast float %3074, %3068
  %3078 = fmul fast float %3075, %3069
  %3079 = fcmp fast ult float %38, 5.000000e-01
  br i1 %3079, label %3105, label %3080

; <label>:3080                                    ; preds = %3066
  %3081 = fmul fast float %3076, 0x4004147AE0000000
  %3082 = fmul fast float %3077, 0x4004147AE0000000
  %3083 = fmul fast float %3078, 0x4004147AE0000000
  %3084 = fadd fast float %3081, 0x3F9EB851E0000000
  %3085 = fadd fast float %3082, 0x3F9EB851E0000000
  %3086 = fadd fast float %3083, 0x3F9EB851E0000000
  %3087 = fmul fast float %3084, %3076
  %3088 = fmul fast float %3085, %3077
  %3089 = fmul fast float %3086, %3078
  %3090 = fmul fast float %3076, 0x400370A3E0000000
  %3091 = fmul fast float %3077, 0x400370A3E0000000
  %3092 = fmul fast float %3078, 0x400370A3E0000000
  %3093 = fadd fast float %3090, 0x3FE2E147A0000000
  %3094 = fadd fast float %3091, 0x3FE2E147A0000000
  %3095 = fadd fast float %3092, 0x3FE2E147A0000000
  %3096 = fmul fast float %3093, %3076
  %3097 = fmul fast float %3094, %3077
  %3098 = fmul fast float %3095, %3078
  %3099 = fadd fast float %3096, 0x3FC1EB8520000000
  %3100 = fadd fast float %3097, 0x3FC1EB8520000000
  %3101 = fadd fast float %3098, 0x3FC1EB8520000000
  %3102 = fdiv fast float %3087, %3099
  %3103 = fdiv fast float %3088, %3100
  %3104 = fdiv fast float %3089, %3101
  br label %3105

; <label>:3105                                    ; preds = %3080, %3066
  %3106 = phi float [ %3102, %3080 ], [ %3076, %3066 ]
  %3107 = phi float [ %3103, %3080 ], [ %3077, %3066 ]
  %3108 = phi float [ %3104, %3080 ], [ %3078, %3066 ]
  %3109 = call float @dx.op.unary.f32(i32 7, float %3106)  ; Saturate(value)
  %3110 = call float @dx.op.unary.f32(i32 7, float %3107)  ; Saturate(value)
  %3111 = call float @dx.op.unary.f32(i32 7, float %3108)  ; Saturate(value)
  %3112 = call float @dx.op.dot3.f32(i32 55, float %3109, float %3110, float %3111, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3113 = fsub fast float %3109, %3112
  %3114 = fsub fast float %3110, %3112
  %3115 = fsub fast float %3111, %3112
  %3116 = fmul fast float %3113, %9
  %3117 = fmul fast float %3114, %9
  %3118 = fmul fast float %3115, %9
  %3119 = fadd fast float %3116, %3112
  %3120 = fadd fast float %3117, %3112
  %3121 = fadd fast float %3118, %3112
  %3122 = call float @dx.op.unary.f32(i32 7, float %3119)  ; Saturate(value)
  %3123 = call float @dx.op.unary.f32(i32 7, float %3120)  ; Saturate(value)
  %3124 = call float @dx.op.unary.f32(i32 7, float %3121)  ; Saturate(value)
  %3125 = fadd fast float %3122, 0xBFC70A3D80000000
  %3126 = fadd fast float %3123, 0xBFC70A3D80000000
  %3127 = fadd fast float %3124, 0xBFC70A3D80000000
  %3128 = fmul fast float %3125, %8
  %3129 = fmul fast float %3126, %8
  %3130 = fmul fast float %3127, %8
  %3131 = fadd fast float %3128, 0x3FC70A3D80000000
  %3132 = fadd fast float %3129, 0x3FC70A3D80000000
  %3133 = fadd fast float %3130, 0x3FC70A3D80000000
  %3134 = call float @dx.op.unary.f32(i32 7, float %3131)  ; Saturate(value)
  %3135 = call float @dx.op.unary.f32(i32 7, float %3132)  ; Saturate(value)
  %3136 = call float @dx.op.unary.f32(i32 7, float %3133)  ; Saturate(value)
  %3137 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %3137, label %3138, label %4290

; <label>:3138                                    ; preds = %3105
  %3139 = add i32 %2913, -1
  %3140 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %3141 = call i32 @dx.op.binary.i32(i32 37, i32 %3139, i32 0)  ; IMax(a,b)
  %3142 = call i32 @dx.op.binary.i32(i32 38, i32 %3140, i32 %60)  ; IMin(a,b)
  %3143 = call i32 @dx.op.binary.i32(i32 38, i32 %3141, i32 %61)  ; IMin(a,b)
  %3144 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3142, i32 %3143, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3145 = extractvalue %dx.types.ResRet.f32 %3144, 0
  %3146 = extractvalue %dx.types.ResRet.f32 %3144, 1
  %3147 = extractvalue %dx.types.ResRet.f32 %3144, 2
  %3148 = extractvalue %dx.types.ResRet.f32 %3144, 3
  %3149 = fcmp fast olt float %3148, 0.000000e+00
  br i1 %3149, label %3150, label %3184

; <label>:3150                                    ; preds = %3138
  %3151 = fcmp fast ogt float %3145, 0x3FA4B5DCC0000000
  %3152 = fcmp fast ogt float %3146, 0x3FA4B5DCC0000000
  %3153 = fcmp fast ogt float %3147, 0x3FA4B5DCC0000000
  %3154 = select i1 %3151, float 0.000000e+00, float 1.000000e+00
  %3155 = select i1 %3152, float 0.000000e+00, float 1.000000e+00
  %3156 = select i1 %3153, float 0.000000e+00, float 1.000000e+00
  %3157 = fmul fast float %3145, 0x3FB3D07220000000
  %3158 = fmul fast float %3146, 0x3FB3D07220000000
  %3159 = fmul fast float %3147, 0x3FB3D07220000000
  %3160 = fadd fast float %3145, 0x3FAC28F5C0000000
  %3161 = fadd fast float %3146, 0x3FAC28F5C0000000
  %3162 = fadd fast float %3147, 0x3FAC28F5C0000000
  %3163 = fmul fast float %3160, 0x3FEE54EDE0000000
  %3164 = fmul fast float %3161, 0x3FEE54EDE0000000
  %3165 = fmul fast float %3162, 0x3FEE54EDE0000000
  %3166 = call float @dx.op.unary.f32(i32 23, float %3163)  ; Log(value)
  %3167 = call float @dx.op.unary.f32(i32 23, float %3164)  ; Log(value)
  %3168 = call float @dx.op.unary.f32(i32 23, float %3165)  ; Log(value)
  %3169 = fmul fast float %3166, 0x4003333340000000
  %3170 = fmul fast float %3167, 0x4003333340000000
  %3171 = fmul fast float %3168, 0x4003333340000000
  %3172 = call float @dx.op.unary.f32(i32 21, float %3169)  ; Exp(value)
  %3173 = call float @dx.op.unary.f32(i32 21, float %3170)  ; Exp(value)
  %3174 = call float @dx.op.unary.f32(i32 21, float %3171)  ; Exp(value)
  %3175 = fsub fast float %3157, %3172
  %3176 = fsub fast float %3158, %3173
  %3177 = fsub fast float %3159, %3174
  %3178 = fmul fast float %3175, %3154
  %3179 = fmul fast float %3176, %3155
  %3180 = fmul fast float %3177, %3156
  %3181 = fadd fast float %3178, %3172
  %3182 = fadd fast float %3179, %3173
  %3183 = fadd fast float %3180, %3174
  br label %3399

; <label>:3184                                    ; preds = %3138
  %3185 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3142, i32 %3143, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3186 = extractvalue %dx.types.ResRet.f32 %3185, 0
  %3187 = fcmp fast ogt float %39, 5.000000e-01
  %3188 = fcmp fast olt float %3186, 1.000000e+00
  %3189 = and i1 %3187, %3188
  br i1 %3189, label %3190, label %3328

; <label>:3190                                    ; preds = %3184
  %3191 = sitofp i32 %3142 to float
  %3192 = sitofp i32 %3143 to float
  %3193 = fadd fast float %3191, 5.000000e-01
  %3194 = fadd fast float %3192, 5.000000e-01
  %3195 = fdiv fast float %3193, %46
  %3196 = fdiv fast float %3194, %47
  %3197 = fmul fast float %3195, 2.000000e+00
  %3198 = fmul fast float %3196, 2.000000e+00
  %3199 = fadd fast float %3197, -1.000000e+00
  %3200 = fsub fast float 1.000000e+00, %3198
  %3201 = fmul fast float %3199, %36
  %3202 = call float @dx.op.tertiary.f32(i32 46, float %3200, float %32, float %3201)  ; FMad(a,b,c)
  %3203 = call float @dx.op.tertiary.f32(i32 46, float %3186, float %28, float %3202)  ; FMad(a,b,c)
  %3204 = fadd fast float %3203, %24
  %3205 = call float @dx.op.unary.f32(i32 6, float %3204)  ; FAbs(value)
  %3206 = fcmp fast ogt float %3205, 0x3EB0C6F7A0000000
  br i1 %3206, label %3207, label %3328

; <label>:3207                                    ; preds = %3190
  %3208 = fmul fast float %3199, %35
  %3209 = call float @dx.op.tertiary.f32(i32 46, float %3200, float %31, float %3208)  ; FMad(a,b,c)
  %3210 = call float @dx.op.tertiary.f32(i32 46, float %3186, float %27, float %3209)  ; FMad(a,b,c)
  %3211 = fadd fast float %3210, %23
  %3212 = fmul fast float %3199, %34
  %3213 = call float @dx.op.tertiary.f32(i32 46, float %3200, float %30, float %3212)  ; FMad(a,b,c)
  %3214 = call float @dx.op.tertiary.f32(i32 46, float %3186, float %26, float %3213)  ; FMad(a,b,c)
  %3215 = fadd fast float %3214, %22
  %3216 = fmul fast float %3199, %33
  %3217 = call float @dx.op.tertiary.f32(i32 46, float %3200, float %29, float %3216)  ; FMad(a,b,c)
  %3218 = call float @dx.op.tertiary.f32(i32 46, float %3186, float %25, float %3217)  ; FMad(a,b,c)
  %3219 = fadd fast float %3218, %21
  %3220 = fdiv fast float %3219, %3204
  %3221 = fdiv fast float %3215, %3204
  %3222 = fdiv fast float %3211, %3204
  %3223 = fsub fast float %3220, %18
  %3224 = fsub fast float %3221, %19
  %3225 = fsub fast float %3222, %20
  %3226 = fmul fast float %3223, %3223
  %3227 = fmul fast float %3224, %3224
  %3228 = fadd fast float %3227, %3226
  %3229 = fmul fast float %3225, %3225
  %3230 = fadd fast float %3228, %3229
  %3231 = call float @dx.op.unary.f32(i32 24, float %3230)  ; Sqrt(value)
  %3232 = fsub fast float %3231, %10
  %3233 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3232)  ; FMax(a,b)
  %3234 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %3234, label %3235, label %3258

; <label>:3235                                    ; preds = %3207
  %3236 = call float @dx.op.unary.f32(i32 6, float %3224)  ; FAbs(value)
  %3237 = fmul fast float %3236, %12
  %3238 = fcmp fast olt float %3237, 0x3F50624DE0000000
  br i1 %3238, label %3239, label %3242

; <label>:3239                                    ; preds = %3235
  %3240 = fmul fast float %3237, 5.000000e-01
  %3241 = fsub fast float 1.000000e+00, %3240
  br label %3247

; <label>:3242                                    ; preds = %3235
  %3243 = fmul fast float %3237, 0xBFF7154760000000
  %3244 = call float @dx.op.unary.f32(i32 21, float %3243)  ; Exp(value)
  %3245 = fsub fast float 1.000000e+00, %3244
  %3246 = fdiv fast float %3245, %3237
  br label %3247

; <label>:3247                                    ; preds = %3242, %3239
  %3248 = phi float [ %3241, %3239 ], [ %3246, %3242 ]
  %3249 = call float @dx.op.binary.f32(i32 36, float %3221, float %19)  ; FMin(a,b)
  %3250 = fsub fast float %3249, %11
  %3251 = fmul fast float %12, %3250
  %3252 = fsub fast float -0.000000e+00, %3251
  %3253 = call float @dx.op.binary.f32(i32 35, float %3252, float -4.000000e+01)  ; FMax(a,b)
  %3254 = call float @dx.op.binary.f32(i32 36, float %3253, float 5.000000e+00)  ; FMin(a,b)
  %3255 = fmul fast float %3254, 0x3FF7154760000000
  %3256 = call float @dx.op.unary.f32(i32 21, float %3255)  ; Exp(value)
  %3257 = fmul fast float %3256, %3248
  br label %3258

; <label>:3258                                    ; preds = %3247, %3207
  %3259 = phi float [ %3257, %3247 ], [ 1.000000e+00, %3207 ]
  %3260 = fmul fast float %3233, %17
  %3261 = fmul fast float %3260, %3259
  %3262 = fcmp fast ole float %3231, %10
  %3263 = fcmp fast olt float %3231, 0x3F1A36E2E0000000
  %3264 = or i1 %3262, %3263
  br i1 %3264, label %3311, label %3265

; <label>:3265                                    ; preds = %3258
  %3266 = fdiv fast float %10, %3231
  %3267 = fmul fast float %3266, %3223
  %3268 = fmul fast float %3266, %3224
  %3269 = fmul fast float %3266, %3225
  %3270 = fadd fast float %3267, %18
  %3271 = fadd fast float %3268, %19
  %3272 = fadd fast float %3269, %20
  %3273 = fadd fast float %3270, -9.000000e+02
  %3274 = fadd fast float %3271, -1.500000e+01
  %3275 = fadd fast float %3272, -7.500000e+02
  %3276 = fmul fast float %3273, 0x3F62345680000000
  %3277 = fmul fast float %3274, 0x3F62345680000000
  %3278 = fmul fast float %3275, 0x3F62345680000000
  %3279 = call float @dx.op.dot3.f32(i32 55, float %3276, float %3277, float %3278, float %3276, float %3277, float %3278)  ; Dot3(ax,ay,az,bx,by,bz)
  %3280 = fsub fast float 1.000000e+00, %3279
  %3281 = call float @dx.op.unary.f32(i32 7, float %3280)  ; Saturate(value)
  %3282 = fmul fast float %3281, %3281
  %3283 = fadd fast float %3270, %3220
  %3284 = fadd fast float %3271, %3221
  %3285 = fadd fast float %3272, %3222
  %3286 = fmul fast float %3283, 0x3F52345680000000
  %3287 = fadd fast float %3286, -2.000000e+00
  %3288 = fmul fast float %3284, 0x3F52345680000000
  %3289 = fadd fast float %3288, 0xBFA1111120000000
  %3290 = fmul fast float %3285, 0x3F52345680000000
  %3291 = fadd fast float %3290, 0xBFFAAAAAC0000000
  %3292 = call float @dx.op.dot3.f32(i32 55, float %3287, float %3289, float %3291, float %3287, float %3289, float %3291)  ; Dot3(ax,ay,az,bx,by,bz)
  %3293 = fsub fast float 1.000000e+00, %3292
  %3294 = call float @dx.op.unary.f32(i32 7, float %3293)  ; Saturate(value)
  %3295 = fmul fast float %3294, %3294
  %3296 = fmul fast float %3295, 4.000000e+00
  %3297 = fadd fast float %3296, %3282
  %3298 = fadd fast float %3220, -9.000000e+02
  %3299 = fadd fast float %3221, -1.500000e+01
  %3300 = fadd fast float %3222, -7.500000e+02
  %3301 = fmul fast float %3298, 0x3F62345680000000
  %3302 = fmul fast float %3299, 0x3F62345680000000
  %3303 = fmul fast float %3300, 0x3F62345680000000
  %3304 = call float @dx.op.dot3.f32(i32 55, float %3301, float %3302, float %3303, float %3301, float %3302, float %3303)  ; Dot3(ax,ay,az,bx,by,bz)
  %3305 = fsub fast float 1.000000e+00, %3304
  %3306 = call float @dx.op.unary.f32(i32 7, float %3305)  ; Saturate(value)
  %3307 = fmul fast float %3306, %3306
  %3308 = fadd fast float %3297, %3307
  %3309 = fmul fast float %3232, 0x3F25D867E0000000
  %3310 = fmul fast float %3309, %3308
  br label %3311

; <label>:3311                                    ; preds = %3265, %3258
  %3312 = phi float [ %3310, %3265 ], [ 0.000000e+00, %3258 ]
  %3313 = fadd fast float %3312, %3261
  %3314 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3313)  ; FMin(a,b)
  %3315 = fmul fast float %3314, 0xBFF7154760000000
  %3316 = call float @dx.op.unary.f32(i32 21, float %3315)  ; Exp(value)
  %3317 = fsub fast float 1.000000e+00, %3316
  %3318 = call float @dx.op.binary.f32(i32 36, float %13, float %3317)  ; FMin(a,b)
  %3319 = fsub fast float %14, %3145
  %3320 = fsub fast float %15, %3146
  %3321 = fsub fast float %16, %3147
  %3322 = fmul fast float %3318, %3319
  %3323 = fmul fast float %3318, %3320
  %3324 = fmul fast float %3318, %3321
  %3325 = fadd fast float %3322, %3145
  %3326 = fadd fast float %3323, %3146
  %3327 = fadd fast float %3324, %3147
  br label %3328

; <label>:3328                                    ; preds = %3311, %3190, %3184
  %3329 = phi float [ %3325, %3311 ], [ %3145, %3190 ], [ %3145, %3184 ]
  %3330 = phi float [ %3326, %3311 ], [ %3146, %3190 ], [ %3146, %3184 ]
  %3331 = phi float [ %3327, %3311 ], [ %3147, %3190 ], [ %3147, %3184 ]
  %3332 = fadd fast float %6, 1.000000e+00
  %3333 = fadd fast float %7, 1.000000e+00
  %3334 = fsub fast float 1.000000e+00, %6
  %3335 = fmul fast float %37, %3332
  %3336 = fmul fast float %37, %3333
  %3337 = fmul fast float %37, %3334
  %3338 = fmul fast float %3335, %3329
  %3339 = fmul fast float %3336, %3330
  %3340 = fmul fast float %3337, %3331
  %3341 = fcmp fast ult float %38, 5.000000e-01
  br i1 %3341, label %3367, label %3342

; <label>:3342                                    ; preds = %3328
  %3343 = fmul fast float %3338, 0x4004147AE0000000
  %3344 = fmul fast float %3339, 0x4004147AE0000000
  %3345 = fmul fast float %3340, 0x4004147AE0000000
  %3346 = fadd fast float %3343, 0x3F9EB851E0000000
  %3347 = fadd fast float %3344, 0x3F9EB851E0000000
  %3348 = fadd fast float %3345, 0x3F9EB851E0000000
  %3349 = fmul fast float %3346, %3338
  %3350 = fmul fast float %3347, %3339
  %3351 = fmul fast float %3348, %3340
  %3352 = fmul fast float %3338, 0x400370A3E0000000
  %3353 = fmul fast float %3339, 0x400370A3E0000000
  %3354 = fmul fast float %3340, 0x400370A3E0000000
  %3355 = fadd fast float %3352, 0x3FE2E147A0000000
  %3356 = fadd fast float %3353, 0x3FE2E147A0000000
  %3357 = fadd fast float %3354, 0x3FE2E147A0000000
  %3358 = fmul fast float %3355, %3338
  %3359 = fmul fast float %3356, %3339
  %3360 = fmul fast float %3357, %3340
  %3361 = fadd fast float %3358, 0x3FC1EB8520000000
  %3362 = fadd fast float %3359, 0x3FC1EB8520000000
  %3363 = fadd fast float %3360, 0x3FC1EB8520000000
  %3364 = fdiv fast float %3349, %3361
  %3365 = fdiv fast float %3350, %3362
  %3366 = fdiv fast float %3351, %3363
  br label %3367

; <label>:3367                                    ; preds = %3342, %3328
  %3368 = phi float [ %3364, %3342 ], [ %3338, %3328 ]
  %3369 = phi float [ %3365, %3342 ], [ %3339, %3328 ]
  %3370 = phi float [ %3366, %3342 ], [ %3340, %3328 ]
  %3371 = call float @dx.op.unary.f32(i32 7, float %3368)  ; Saturate(value)
  %3372 = call float @dx.op.unary.f32(i32 7, float %3369)  ; Saturate(value)
  %3373 = call float @dx.op.unary.f32(i32 7, float %3370)  ; Saturate(value)
  %3374 = call float @dx.op.dot3.f32(i32 55, float %3371, float %3372, float %3373, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3375 = fsub fast float %3371, %3374
  %3376 = fsub fast float %3372, %3374
  %3377 = fsub fast float %3373, %3374
  %3378 = fmul fast float %3375, %9
  %3379 = fmul fast float %3376, %9
  %3380 = fmul fast float %3377, %9
  %3381 = fadd fast float %3378, %3374
  %3382 = fadd fast float %3379, %3374
  %3383 = fadd fast float %3380, %3374
  %3384 = call float @dx.op.unary.f32(i32 7, float %3381)  ; Saturate(value)
  %3385 = call float @dx.op.unary.f32(i32 7, float %3382)  ; Saturate(value)
  %3386 = call float @dx.op.unary.f32(i32 7, float %3383)  ; Saturate(value)
  %3387 = fadd fast float %3384, 0xBFC70A3D80000000
  %3388 = fadd fast float %3385, 0xBFC70A3D80000000
  %3389 = fadd fast float %3386, 0xBFC70A3D80000000
  %3390 = fmul fast float %3387, %8
  %3391 = fmul fast float %3388, %8
  %3392 = fmul fast float %3389, %8
  %3393 = fadd fast float %3390, 0x3FC70A3D80000000
  %3394 = fadd fast float %3391, 0x3FC70A3D80000000
  %3395 = fadd fast float %3392, 0x3FC70A3D80000000
  %3396 = call float @dx.op.unary.f32(i32 7, float %3393)  ; Saturate(value)
  %3397 = call float @dx.op.unary.f32(i32 7, float %3394)  ; Saturate(value)
  %3398 = call float @dx.op.unary.f32(i32 7, float %3395)  ; Saturate(value)
  br label %3399

; <label>:3399                                    ; preds = %3367, %3150
  %3400 = phi float [ %3181, %3150 ], [ %3396, %3367 ]
  %3401 = phi float [ %3182, %3150 ], [ %3397, %3367 ]
  %3402 = phi float [ %3183, %3150 ], [ %3398, %3367 ]
  %3403 = add i32 %2913, 1
  %3404 = call i32 @dx.op.binary.i32(i32 37, i32 %3403, i32 0)  ; IMax(a,b)
  %3405 = call i32 @dx.op.binary.i32(i32 38, i32 %3404, i32 %61)  ; IMin(a,b)
  %3406 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3142, i32 %3405, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3407 = extractvalue %dx.types.ResRet.f32 %3406, 0
  %3408 = extractvalue %dx.types.ResRet.f32 %3406, 1
  %3409 = extractvalue %dx.types.ResRet.f32 %3406, 2
  %3410 = extractvalue %dx.types.ResRet.f32 %3406, 3
  %3411 = fcmp fast olt float %3410, 0.000000e+00
  br i1 %3411, label %3412, label %3446

; <label>:3412                                    ; preds = %3399
  %3413 = fcmp fast ogt float %3407, 0x3FA4B5DCC0000000
  %3414 = fcmp fast ogt float %3408, 0x3FA4B5DCC0000000
  %3415 = fcmp fast ogt float %3409, 0x3FA4B5DCC0000000
  %3416 = select i1 %3413, float 0.000000e+00, float 1.000000e+00
  %3417 = select i1 %3414, float 0.000000e+00, float 1.000000e+00
  %3418 = select i1 %3415, float 0.000000e+00, float 1.000000e+00
  %3419 = fmul fast float %3407, 0x3FB3D07220000000
  %3420 = fmul fast float %3408, 0x3FB3D07220000000
  %3421 = fmul fast float %3409, 0x3FB3D07220000000
  %3422 = fadd fast float %3407, 0x3FAC28F5C0000000
  %3423 = fadd fast float %3408, 0x3FAC28F5C0000000
  %3424 = fadd fast float %3409, 0x3FAC28F5C0000000
  %3425 = fmul fast float %3422, 0x3FEE54EDE0000000
  %3426 = fmul fast float %3423, 0x3FEE54EDE0000000
  %3427 = fmul fast float %3424, 0x3FEE54EDE0000000
  %3428 = call float @dx.op.unary.f32(i32 23, float %3425)  ; Log(value)
  %3429 = call float @dx.op.unary.f32(i32 23, float %3426)  ; Log(value)
  %3430 = call float @dx.op.unary.f32(i32 23, float %3427)  ; Log(value)
  %3431 = fmul fast float %3428, 0x4003333340000000
  %3432 = fmul fast float %3429, 0x4003333340000000
  %3433 = fmul fast float %3430, 0x4003333340000000
  %3434 = call float @dx.op.unary.f32(i32 21, float %3431)  ; Exp(value)
  %3435 = call float @dx.op.unary.f32(i32 21, float %3432)  ; Exp(value)
  %3436 = call float @dx.op.unary.f32(i32 21, float %3433)  ; Exp(value)
  %3437 = fsub fast float %3419, %3434
  %3438 = fsub fast float %3420, %3435
  %3439 = fsub fast float %3421, %3436
  %3440 = fmul fast float %3437, %3416
  %3441 = fmul fast float %3438, %3417
  %3442 = fmul fast float %3439, %3418
  %3443 = fadd fast float %3440, %3434
  %3444 = fadd fast float %3441, %3435
  %3445 = fadd fast float %3442, %3436
  br label %3661

; <label>:3446                                    ; preds = %3399
  %3447 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3142, i32 %3405, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3448 = extractvalue %dx.types.ResRet.f32 %3447, 0
  %3449 = fcmp fast ogt float %39, 5.000000e-01
  %3450 = fcmp fast olt float %3448, 1.000000e+00
  %3451 = and i1 %3449, %3450
  br i1 %3451, label %3452, label %3590

; <label>:3452                                    ; preds = %3446
  %3453 = sitofp i32 %3142 to float
  %3454 = sitofp i32 %3405 to float
  %3455 = fadd fast float %3453, 5.000000e-01
  %3456 = fadd fast float %3454, 5.000000e-01
  %3457 = fdiv fast float %3455, %46
  %3458 = fdiv fast float %3456, %47
  %3459 = fmul fast float %3457, 2.000000e+00
  %3460 = fmul fast float %3458, 2.000000e+00
  %3461 = fadd fast float %3459, -1.000000e+00
  %3462 = fsub fast float 1.000000e+00, %3460
  %3463 = fmul fast float %3461, %36
  %3464 = call float @dx.op.tertiary.f32(i32 46, float %3462, float %32, float %3463)  ; FMad(a,b,c)
  %3465 = call float @dx.op.tertiary.f32(i32 46, float %3448, float %28, float %3464)  ; FMad(a,b,c)
  %3466 = fadd fast float %3465, %24
  %3467 = call float @dx.op.unary.f32(i32 6, float %3466)  ; FAbs(value)
  %3468 = fcmp fast ogt float %3467, 0x3EB0C6F7A0000000
  br i1 %3468, label %3469, label %3590

; <label>:3469                                    ; preds = %3452
  %3470 = fmul fast float %3461, %35
  %3471 = call float @dx.op.tertiary.f32(i32 46, float %3462, float %31, float %3470)  ; FMad(a,b,c)
  %3472 = call float @dx.op.tertiary.f32(i32 46, float %3448, float %27, float %3471)  ; FMad(a,b,c)
  %3473 = fadd fast float %3472, %23
  %3474 = fmul fast float %3461, %34
  %3475 = call float @dx.op.tertiary.f32(i32 46, float %3462, float %30, float %3474)  ; FMad(a,b,c)
  %3476 = call float @dx.op.tertiary.f32(i32 46, float %3448, float %26, float %3475)  ; FMad(a,b,c)
  %3477 = fadd fast float %3476, %22
  %3478 = fmul fast float %3461, %33
  %3479 = call float @dx.op.tertiary.f32(i32 46, float %3462, float %29, float %3478)  ; FMad(a,b,c)
  %3480 = call float @dx.op.tertiary.f32(i32 46, float %3448, float %25, float %3479)  ; FMad(a,b,c)
  %3481 = fadd fast float %3480, %21
  %3482 = fdiv fast float %3481, %3466
  %3483 = fdiv fast float %3477, %3466
  %3484 = fdiv fast float %3473, %3466
  %3485 = fsub fast float %3482, %18
  %3486 = fsub fast float %3483, %19
  %3487 = fsub fast float %3484, %20
  %3488 = fmul fast float %3485, %3485
  %3489 = fmul fast float %3486, %3486
  %3490 = fadd fast float %3489, %3488
  %3491 = fmul fast float %3487, %3487
  %3492 = fadd fast float %3490, %3491
  %3493 = call float @dx.op.unary.f32(i32 24, float %3492)  ; Sqrt(value)
  %3494 = fsub fast float %3493, %10
  %3495 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3494)  ; FMax(a,b)
  %3496 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %3496, label %3497, label %3520

; <label>:3497                                    ; preds = %3469
  %3498 = call float @dx.op.unary.f32(i32 6, float %3486)  ; FAbs(value)
  %3499 = fmul fast float %3498, %12
  %3500 = fcmp fast olt float %3499, 0x3F50624DE0000000
  br i1 %3500, label %3501, label %3504

; <label>:3501                                    ; preds = %3497
  %3502 = fmul fast float %3499, 5.000000e-01
  %3503 = fsub fast float 1.000000e+00, %3502
  br label %3509

; <label>:3504                                    ; preds = %3497
  %3505 = fmul fast float %3499, 0xBFF7154760000000
  %3506 = call float @dx.op.unary.f32(i32 21, float %3505)  ; Exp(value)
  %3507 = fsub fast float 1.000000e+00, %3506
  %3508 = fdiv fast float %3507, %3499
  br label %3509

; <label>:3509                                    ; preds = %3504, %3501
  %3510 = phi float [ %3503, %3501 ], [ %3508, %3504 ]
  %3511 = call float @dx.op.binary.f32(i32 36, float %3483, float %19)  ; FMin(a,b)
  %3512 = fsub fast float %3511, %11
  %3513 = fmul fast float %12, %3512
  %3514 = fsub fast float -0.000000e+00, %3513
  %3515 = call float @dx.op.binary.f32(i32 35, float %3514, float -4.000000e+01)  ; FMax(a,b)
  %3516 = call float @dx.op.binary.f32(i32 36, float %3515, float 5.000000e+00)  ; FMin(a,b)
  %3517 = fmul fast float %3516, 0x3FF7154760000000
  %3518 = call float @dx.op.unary.f32(i32 21, float %3517)  ; Exp(value)
  %3519 = fmul fast float %3518, %3510
  br label %3520

; <label>:3520                                    ; preds = %3509, %3469
  %3521 = phi float [ %3519, %3509 ], [ 1.000000e+00, %3469 ]
  %3522 = fmul fast float %3495, %17
  %3523 = fmul fast float %3522, %3521
  %3524 = fcmp fast ole float %3493, %10
  %3525 = fcmp fast olt float %3493, 0x3F1A36E2E0000000
  %3526 = or i1 %3524, %3525
  br i1 %3526, label %3573, label %3527

; <label>:3527                                    ; preds = %3520
  %3528 = fdiv fast float %10, %3493
  %3529 = fmul fast float %3528, %3485
  %3530 = fmul fast float %3528, %3486
  %3531 = fmul fast float %3528, %3487
  %3532 = fadd fast float %3529, %18
  %3533 = fadd fast float %3530, %19
  %3534 = fadd fast float %3531, %20
  %3535 = fadd fast float %3532, -9.000000e+02
  %3536 = fadd fast float %3533, -1.500000e+01
  %3537 = fadd fast float %3534, -7.500000e+02
  %3538 = fmul fast float %3535, 0x3F62345680000000
  %3539 = fmul fast float %3536, 0x3F62345680000000
  %3540 = fmul fast float %3537, 0x3F62345680000000
  %3541 = call float @dx.op.dot3.f32(i32 55, float %3538, float %3539, float %3540, float %3538, float %3539, float %3540)  ; Dot3(ax,ay,az,bx,by,bz)
  %3542 = fsub fast float 1.000000e+00, %3541
  %3543 = call float @dx.op.unary.f32(i32 7, float %3542)  ; Saturate(value)
  %3544 = fmul fast float %3543, %3543
  %3545 = fadd fast float %3532, %3482
  %3546 = fadd fast float %3533, %3483
  %3547 = fadd fast float %3534, %3484
  %3548 = fmul fast float %3545, 0x3F52345680000000
  %3549 = fadd fast float %3548, -2.000000e+00
  %3550 = fmul fast float %3546, 0x3F52345680000000
  %3551 = fadd fast float %3550, 0xBFA1111120000000
  %3552 = fmul fast float %3547, 0x3F52345680000000
  %3553 = fadd fast float %3552, 0xBFFAAAAAC0000000
  %3554 = call float @dx.op.dot3.f32(i32 55, float %3549, float %3551, float %3553, float %3549, float %3551, float %3553)  ; Dot3(ax,ay,az,bx,by,bz)
  %3555 = fsub fast float 1.000000e+00, %3554
  %3556 = call float @dx.op.unary.f32(i32 7, float %3555)  ; Saturate(value)
  %3557 = fmul fast float %3556, %3556
  %3558 = fmul fast float %3557, 4.000000e+00
  %3559 = fadd fast float %3558, %3544
  %3560 = fadd fast float %3482, -9.000000e+02
  %3561 = fadd fast float %3483, -1.500000e+01
  %3562 = fadd fast float %3484, -7.500000e+02
  %3563 = fmul fast float %3560, 0x3F62345680000000
  %3564 = fmul fast float %3561, 0x3F62345680000000
  %3565 = fmul fast float %3562, 0x3F62345680000000
  %3566 = call float @dx.op.dot3.f32(i32 55, float %3563, float %3564, float %3565, float %3563, float %3564, float %3565)  ; Dot3(ax,ay,az,bx,by,bz)
  %3567 = fsub fast float 1.000000e+00, %3566
  %3568 = call float @dx.op.unary.f32(i32 7, float %3567)  ; Saturate(value)
  %3569 = fmul fast float %3568, %3568
  %3570 = fadd fast float %3559, %3569
  %3571 = fmul fast float %3494, 0x3F25D867E0000000
  %3572 = fmul fast float %3571, %3570
  br label %3573

; <label>:3573                                    ; preds = %3527, %3520
  %3574 = phi float [ %3572, %3527 ], [ 0.000000e+00, %3520 ]
  %3575 = fadd fast float %3574, %3523
  %3576 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3575)  ; FMin(a,b)
  %3577 = fmul fast float %3576, 0xBFF7154760000000
  %3578 = call float @dx.op.unary.f32(i32 21, float %3577)  ; Exp(value)
  %3579 = fsub fast float 1.000000e+00, %3578
  %3580 = call float @dx.op.binary.f32(i32 36, float %13, float %3579)  ; FMin(a,b)
  %3581 = fsub fast float %14, %3407
  %3582 = fsub fast float %15, %3408
  %3583 = fsub fast float %16, %3409
  %3584 = fmul fast float %3580, %3581
  %3585 = fmul fast float %3580, %3582
  %3586 = fmul fast float %3580, %3583
  %3587 = fadd fast float %3584, %3407
  %3588 = fadd fast float %3585, %3408
  %3589 = fadd fast float %3586, %3409
  br label %3590

; <label>:3590                                    ; preds = %3573, %3452, %3446
  %3591 = phi float [ %3587, %3573 ], [ %3407, %3452 ], [ %3407, %3446 ]
  %3592 = phi float [ %3588, %3573 ], [ %3408, %3452 ], [ %3408, %3446 ]
  %3593 = phi float [ %3589, %3573 ], [ %3409, %3452 ], [ %3409, %3446 ]
  %3594 = fadd fast float %6, 1.000000e+00
  %3595 = fadd fast float %7, 1.000000e+00
  %3596 = fsub fast float 1.000000e+00, %6
  %3597 = fmul fast float %37, %3594
  %3598 = fmul fast float %37, %3595
  %3599 = fmul fast float %37, %3596
  %3600 = fmul fast float %3597, %3591
  %3601 = fmul fast float %3598, %3592
  %3602 = fmul fast float %3599, %3593
  %3603 = fcmp fast ult float %38, 5.000000e-01
  br i1 %3603, label %3629, label %3604

; <label>:3604                                    ; preds = %3590
  %3605 = fmul fast float %3600, 0x4004147AE0000000
  %3606 = fmul fast float %3601, 0x4004147AE0000000
  %3607 = fmul fast float %3602, 0x4004147AE0000000
  %3608 = fadd fast float %3605, 0x3F9EB851E0000000
  %3609 = fadd fast float %3606, 0x3F9EB851E0000000
  %3610 = fadd fast float %3607, 0x3F9EB851E0000000
  %3611 = fmul fast float %3608, %3600
  %3612 = fmul fast float %3609, %3601
  %3613 = fmul fast float %3610, %3602
  %3614 = fmul fast float %3600, 0x400370A3E0000000
  %3615 = fmul fast float %3601, 0x400370A3E0000000
  %3616 = fmul fast float %3602, 0x400370A3E0000000
  %3617 = fadd fast float %3614, 0x3FE2E147A0000000
  %3618 = fadd fast float %3615, 0x3FE2E147A0000000
  %3619 = fadd fast float %3616, 0x3FE2E147A0000000
  %3620 = fmul fast float %3617, %3600
  %3621 = fmul fast float %3618, %3601
  %3622 = fmul fast float %3619, %3602
  %3623 = fadd fast float %3620, 0x3FC1EB8520000000
  %3624 = fadd fast float %3621, 0x3FC1EB8520000000
  %3625 = fadd fast float %3622, 0x3FC1EB8520000000
  %3626 = fdiv fast float %3611, %3623
  %3627 = fdiv fast float %3612, %3624
  %3628 = fdiv fast float %3613, %3625
  br label %3629

; <label>:3629                                    ; preds = %3604, %3590
  %3630 = phi float [ %3626, %3604 ], [ %3600, %3590 ]
  %3631 = phi float [ %3627, %3604 ], [ %3601, %3590 ]
  %3632 = phi float [ %3628, %3604 ], [ %3602, %3590 ]
  %3633 = call float @dx.op.unary.f32(i32 7, float %3630)  ; Saturate(value)
  %3634 = call float @dx.op.unary.f32(i32 7, float %3631)  ; Saturate(value)
  %3635 = call float @dx.op.unary.f32(i32 7, float %3632)  ; Saturate(value)
  %3636 = call float @dx.op.dot3.f32(i32 55, float %3633, float %3634, float %3635, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3637 = fsub fast float %3633, %3636
  %3638 = fsub fast float %3634, %3636
  %3639 = fsub fast float %3635, %3636
  %3640 = fmul fast float %3637, %9
  %3641 = fmul fast float %3638, %9
  %3642 = fmul fast float %3639, %9
  %3643 = fadd fast float %3640, %3636
  %3644 = fadd fast float %3641, %3636
  %3645 = fadd fast float %3642, %3636
  %3646 = call float @dx.op.unary.f32(i32 7, float %3643)  ; Saturate(value)
  %3647 = call float @dx.op.unary.f32(i32 7, float %3644)  ; Saturate(value)
  %3648 = call float @dx.op.unary.f32(i32 7, float %3645)  ; Saturate(value)
  %3649 = fadd fast float %3646, 0xBFC70A3D80000000
  %3650 = fadd fast float %3647, 0xBFC70A3D80000000
  %3651 = fadd fast float %3648, 0xBFC70A3D80000000
  %3652 = fmul fast float %3649, %8
  %3653 = fmul fast float %3650, %8
  %3654 = fmul fast float %3651, %8
  %3655 = fadd fast float %3652, 0x3FC70A3D80000000
  %3656 = fadd fast float %3653, 0x3FC70A3D80000000
  %3657 = fadd fast float %3654, 0x3FC70A3D80000000
  %3658 = call float @dx.op.unary.f32(i32 7, float %3655)  ; Saturate(value)
  %3659 = call float @dx.op.unary.f32(i32 7, float %3656)  ; Saturate(value)
  %3660 = call float @dx.op.unary.f32(i32 7, float %3657)  ; Saturate(value)
  br label %3661

; <label>:3661                                    ; preds = %3629, %3412
  %3662 = phi float [ %3443, %3412 ], [ %3658, %3629 ]
  %3663 = phi float [ %3444, %3412 ], [ %3659, %3629 ]
  %3664 = phi float [ %3445, %3412 ], [ %3660, %3629 ]
  %3665 = add i32 %64, -1
  %3666 = call i32 @dx.op.binary.i32(i32 37, i32 %3665, i32 0)  ; IMax(a,b)
  %3667 = call i32 @dx.op.binary.i32(i32 37, i32 %2913, i32 0)  ; IMax(a,b)
  %3668 = call i32 @dx.op.binary.i32(i32 38, i32 %3666, i32 %60)  ; IMin(a,b)
  %3669 = call i32 @dx.op.binary.i32(i32 38, i32 %3667, i32 %61)  ; IMin(a,b)
  %3670 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3668, i32 %3669, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3671 = extractvalue %dx.types.ResRet.f32 %3670, 0
  %3672 = extractvalue %dx.types.ResRet.f32 %3670, 1
  %3673 = extractvalue %dx.types.ResRet.f32 %3670, 2
  %3674 = extractvalue %dx.types.ResRet.f32 %3670, 3
  %3675 = fcmp fast olt float %3674, 0.000000e+00
  br i1 %3675, label %3676, label %3710

; <label>:3676                                    ; preds = %3661
  %3677 = fcmp fast ogt float %3671, 0x3FA4B5DCC0000000
  %3678 = fcmp fast ogt float %3672, 0x3FA4B5DCC0000000
  %3679 = fcmp fast ogt float %3673, 0x3FA4B5DCC0000000
  %3680 = select i1 %3677, float 0.000000e+00, float 1.000000e+00
  %3681 = select i1 %3678, float 0.000000e+00, float 1.000000e+00
  %3682 = select i1 %3679, float 0.000000e+00, float 1.000000e+00
  %3683 = fmul fast float %3671, 0x3FB3D07220000000
  %3684 = fmul fast float %3672, 0x3FB3D07220000000
  %3685 = fmul fast float %3673, 0x3FB3D07220000000
  %3686 = fadd fast float %3671, 0x3FAC28F5C0000000
  %3687 = fadd fast float %3672, 0x3FAC28F5C0000000
  %3688 = fadd fast float %3673, 0x3FAC28F5C0000000
  %3689 = fmul fast float %3686, 0x3FEE54EDE0000000
  %3690 = fmul fast float %3687, 0x3FEE54EDE0000000
  %3691 = fmul fast float %3688, 0x3FEE54EDE0000000
  %3692 = call float @dx.op.unary.f32(i32 23, float %3689)  ; Log(value)
  %3693 = call float @dx.op.unary.f32(i32 23, float %3690)  ; Log(value)
  %3694 = call float @dx.op.unary.f32(i32 23, float %3691)  ; Log(value)
  %3695 = fmul fast float %3692, 0x4003333340000000
  %3696 = fmul fast float %3693, 0x4003333340000000
  %3697 = fmul fast float %3694, 0x4003333340000000
  %3698 = call float @dx.op.unary.f32(i32 21, float %3695)  ; Exp(value)
  %3699 = call float @dx.op.unary.f32(i32 21, float %3696)  ; Exp(value)
  %3700 = call float @dx.op.unary.f32(i32 21, float %3697)  ; Exp(value)
  %3701 = fsub fast float %3683, %3698
  %3702 = fsub fast float %3684, %3699
  %3703 = fsub fast float %3685, %3700
  %3704 = fmul fast float %3701, %3680
  %3705 = fmul fast float %3702, %3681
  %3706 = fmul fast float %3703, %3682
  %3707 = fadd fast float %3704, %3698
  %3708 = fadd fast float %3705, %3699
  %3709 = fadd fast float %3706, %3700
  br label %3925

; <label>:3710                                    ; preds = %3661
  %3711 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3668, i32 %3669, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3712 = extractvalue %dx.types.ResRet.f32 %3711, 0
  %3713 = fcmp fast ogt float %39, 5.000000e-01
  %3714 = fcmp fast olt float %3712, 1.000000e+00
  %3715 = and i1 %3713, %3714
  br i1 %3715, label %3716, label %3854

; <label>:3716                                    ; preds = %3710
  %3717 = sitofp i32 %3668 to float
  %3718 = sitofp i32 %3669 to float
  %3719 = fadd fast float %3717, 5.000000e-01
  %3720 = fadd fast float %3718, 5.000000e-01
  %3721 = fdiv fast float %3719, %46
  %3722 = fdiv fast float %3720, %47
  %3723 = fmul fast float %3721, 2.000000e+00
  %3724 = fmul fast float %3722, 2.000000e+00
  %3725 = fadd fast float %3723, -1.000000e+00
  %3726 = fsub fast float 1.000000e+00, %3724
  %3727 = fmul fast float %3725, %36
  %3728 = call float @dx.op.tertiary.f32(i32 46, float %3726, float %32, float %3727)  ; FMad(a,b,c)
  %3729 = call float @dx.op.tertiary.f32(i32 46, float %3712, float %28, float %3728)  ; FMad(a,b,c)
  %3730 = fadd fast float %3729, %24
  %3731 = call float @dx.op.unary.f32(i32 6, float %3730)  ; FAbs(value)
  %3732 = fcmp fast ogt float %3731, 0x3EB0C6F7A0000000
  br i1 %3732, label %3733, label %3854

; <label>:3733                                    ; preds = %3716
  %3734 = fmul fast float %3725, %35
  %3735 = call float @dx.op.tertiary.f32(i32 46, float %3726, float %31, float %3734)  ; FMad(a,b,c)
  %3736 = call float @dx.op.tertiary.f32(i32 46, float %3712, float %27, float %3735)  ; FMad(a,b,c)
  %3737 = fadd fast float %3736, %23
  %3738 = fmul fast float %3725, %34
  %3739 = call float @dx.op.tertiary.f32(i32 46, float %3726, float %30, float %3738)  ; FMad(a,b,c)
  %3740 = call float @dx.op.tertiary.f32(i32 46, float %3712, float %26, float %3739)  ; FMad(a,b,c)
  %3741 = fadd fast float %3740, %22
  %3742 = fmul fast float %3725, %33
  %3743 = call float @dx.op.tertiary.f32(i32 46, float %3726, float %29, float %3742)  ; FMad(a,b,c)
  %3744 = call float @dx.op.tertiary.f32(i32 46, float %3712, float %25, float %3743)  ; FMad(a,b,c)
  %3745 = fadd fast float %3744, %21
  %3746 = fdiv fast float %3745, %3730
  %3747 = fdiv fast float %3741, %3730
  %3748 = fdiv fast float %3737, %3730
  %3749 = fsub fast float %3746, %18
  %3750 = fsub fast float %3747, %19
  %3751 = fsub fast float %3748, %20
  %3752 = fmul fast float %3749, %3749
  %3753 = fmul fast float %3750, %3750
  %3754 = fadd fast float %3753, %3752
  %3755 = fmul fast float %3751, %3751
  %3756 = fadd fast float %3754, %3755
  %3757 = call float @dx.op.unary.f32(i32 24, float %3756)  ; Sqrt(value)
  %3758 = fsub fast float %3757, %10
  %3759 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3758)  ; FMax(a,b)
  %3760 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %3760, label %3761, label %3784

; <label>:3761                                    ; preds = %3733
  %3762 = call float @dx.op.unary.f32(i32 6, float %3750)  ; FAbs(value)
  %3763 = fmul fast float %3762, %12
  %3764 = fcmp fast olt float %3763, 0x3F50624DE0000000
  br i1 %3764, label %3765, label %3768

; <label>:3765                                    ; preds = %3761
  %3766 = fmul fast float %3763, 5.000000e-01
  %3767 = fsub fast float 1.000000e+00, %3766
  br label %3773

; <label>:3768                                    ; preds = %3761
  %3769 = fmul fast float %3763, 0xBFF7154760000000
  %3770 = call float @dx.op.unary.f32(i32 21, float %3769)  ; Exp(value)
  %3771 = fsub fast float 1.000000e+00, %3770
  %3772 = fdiv fast float %3771, %3763
  br label %3773

; <label>:3773                                    ; preds = %3768, %3765
  %3774 = phi float [ %3767, %3765 ], [ %3772, %3768 ]
  %3775 = call float @dx.op.binary.f32(i32 36, float %3747, float %19)  ; FMin(a,b)
  %3776 = fsub fast float %3775, %11
  %3777 = fmul fast float %12, %3776
  %3778 = fsub fast float -0.000000e+00, %3777
  %3779 = call float @dx.op.binary.f32(i32 35, float %3778, float -4.000000e+01)  ; FMax(a,b)
  %3780 = call float @dx.op.binary.f32(i32 36, float %3779, float 5.000000e+00)  ; FMin(a,b)
  %3781 = fmul fast float %3780, 0x3FF7154760000000
  %3782 = call float @dx.op.unary.f32(i32 21, float %3781)  ; Exp(value)
  %3783 = fmul fast float %3782, %3774
  br label %3784

; <label>:3784                                    ; preds = %3773, %3733
  %3785 = phi float [ %3783, %3773 ], [ 1.000000e+00, %3733 ]
  %3786 = fmul fast float %3759, %17
  %3787 = fmul fast float %3786, %3785
  %3788 = fcmp fast ole float %3757, %10
  %3789 = fcmp fast olt float %3757, 0x3F1A36E2E0000000
  %3790 = or i1 %3788, %3789
  br i1 %3790, label %3837, label %3791

; <label>:3791                                    ; preds = %3784
  %3792 = fdiv fast float %10, %3757
  %3793 = fmul fast float %3792, %3749
  %3794 = fmul fast float %3792, %3750
  %3795 = fmul fast float %3792, %3751
  %3796 = fadd fast float %3793, %18
  %3797 = fadd fast float %3794, %19
  %3798 = fadd fast float %3795, %20
  %3799 = fadd fast float %3796, -9.000000e+02
  %3800 = fadd fast float %3797, -1.500000e+01
  %3801 = fadd fast float %3798, -7.500000e+02
  %3802 = fmul fast float %3799, 0x3F62345680000000
  %3803 = fmul fast float %3800, 0x3F62345680000000
  %3804 = fmul fast float %3801, 0x3F62345680000000
  %3805 = call float @dx.op.dot3.f32(i32 55, float %3802, float %3803, float %3804, float %3802, float %3803, float %3804)  ; Dot3(ax,ay,az,bx,by,bz)
  %3806 = fsub fast float 1.000000e+00, %3805
  %3807 = call float @dx.op.unary.f32(i32 7, float %3806)  ; Saturate(value)
  %3808 = fmul fast float %3807, %3807
  %3809 = fadd fast float %3796, %3746
  %3810 = fadd fast float %3797, %3747
  %3811 = fadd fast float %3798, %3748
  %3812 = fmul fast float %3809, 0x3F52345680000000
  %3813 = fadd fast float %3812, -2.000000e+00
  %3814 = fmul fast float %3810, 0x3F52345680000000
  %3815 = fadd fast float %3814, 0xBFA1111120000000
  %3816 = fmul fast float %3811, 0x3F52345680000000
  %3817 = fadd fast float %3816, 0xBFFAAAAAC0000000
  %3818 = call float @dx.op.dot3.f32(i32 55, float %3813, float %3815, float %3817, float %3813, float %3815, float %3817)  ; Dot3(ax,ay,az,bx,by,bz)
  %3819 = fsub fast float 1.000000e+00, %3818
  %3820 = call float @dx.op.unary.f32(i32 7, float %3819)  ; Saturate(value)
  %3821 = fmul fast float %3820, %3820
  %3822 = fmul fast float %3821, 4.000000e+00
  %3823 = fadd fast float %3822, %3808
  %3824 = fadd fast float %3746, -9.000000e+02
  %3825 = fadd fast float %3747, -1.500000e+01
  %3826 = fadd fast float %3748, -7.500000e+02
  %3827 = fmul fast float %3824, 0x3F62345680000000
  %3828 = fmul fast float %3825, 0x3F62345680000000
  %3829 = fmul fast float %3826, 0x3F62345680000000
  %3830 = call float @dx.op.dot3.f32(i32 55, float %3827, float %3828, float %3829, float %3827, float %3828, float %3829)  ; Dot3(ax,ay,az,bx,by,bz)
  %3831 = fsub fast float 1.000000e+00, %3830
  %3832 = call float @dx.op.unary.f32(i32 7, float %3831)  ; Saturate(value)
  %3833 = fmul fast float %3832, %3832
  %3834 = fadd fast float %3823, %3833
  %3835 = fmul fast float %3758, 0x3F25D867E0000000
  %3836 = fmul fast float %3835, %3834
  br label %3837

; <label>:3837                                    ; preds = %3791, %3784
  %3838 = phi float [ %3836, %3791 ], [ 0.000000e+00, %3784 ]
  %3839 = fadd fast float %3838, %3787
  %3840 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3839)  ; FMin(a,b)
  %3841 = fmul fast float %3840, 0xBFF7154760000000
  %3842 = call float @dx.op.unary.f32(i32 21, float %3841)  ; Exp(value)
  %3843 = fsub fast float 1.000000e+00, %3842
  %3844 = call float @dx.op.binary.f32(i32 36, float %13, float %3843)  ; FMin(a,b)
  %3845 = fsub fast float %14, %3671
  %3846 = fsub fast float %15, %3672
  %3847 = fsub fast float %16, %3673
  %3848 = fmul fast float %3844, %3845
  %3849 = fmul fast float %3844, %3846
  %3850 = fmul fast float %3844, %3847
  %3851 = fadd fast float %3848, %3671
  %3852 = fadd fast float %3849, %3672
  %3853 = fadd fast float %3850, %3673
  br label %3854

; <label>:3854                                    ; preds = %3837, %3716, %3710
  %3855 = phi float [ %3851, %3837 ], [ %3671, %3716 ], [ %3671, %3710 ]
  %3856 = phi float [ %3852, %3837 ], [ %3672, %3716 ], [ %3672, %3710 ]
  %3857 = phi float [ %3853, %3837 ], [ %3673, %3716 ], [ %3673, %3710 ]
  %3858 = fadd fast float %6, 1.000000e+00
  %3859 = fadd fast float %7, 1.000000e+00
  %3860 = fsub fast float 1.000000e+00, %6
  %3861 = fmul fast float %37, %3858
  %3862 = fmul fast float %37, %3859
  %3863 = fmul fast float %37, %3860
  %3864 = fmul fast float %3861, %3855
  %3865 = fmul fast float %3862, %3856
  %3866 = fmul fast float %3863, %3857
  %3867 = fcmp fast ult float %38, 5.000000e-01
  br i1 %3867, label %3893, label %3868

; <label>:3868                                    ; preds = %3854
  %3869 = fmul fast float %3864, 0x4004147AE0000000
  %3870 = fmul fast float %3865, 0x4004147AE0000000
  %3871 = fmul fast float %3866, 0x4004147AE0000000
  %3872 = fadd fast float %3869, 0x3F9EB851E0000000
  %3873 = fadd fast float %3870, 0x3F9EB851E0000000
  %3874 = fadd fast float %3871, 0x3F9EB851E0000000
  %3875 = fmul fast float %3872, %3864
  %3876 = fmul fast float %3873, %3865
  %3877 = fmul fast float %3874, %3866
  %3878 = fmul fast float %3864, 0x400370A3E0000000
  %3879 = fmul fast float %3865, 0x400370A3E0000000
  %3880 = fmul fast float %3866, 0x400370A3E0000000
  %3881 = fadd fast float %3878, 0x3FE2E147A0000000
  %3882 = fadd fast float %3879, 0x3FE2E147A0000000
  %3883 = fadd fast float %3880, 0x3FE2E147A0000000
  %3884 = fmul fast float %3881, %3864
  %3885 = fmul fast float %3882, %3865
  %3886 = fmul fast float %3883, %3866
  %3887 = fadd fast float %3884, 0x3FC1EB8520000000
  %3888 = fadd fast float %3885, 0x3FC1EB8520000000
  %3889 = fadd fast float %3886, 0x3FC1EB8520000000
  %3890 = fdiv fast float %3875, %3887
  %3891 = fdiv fast float %3876, %3888
  %3892 = fdiv fast float %3877, %3889
  br label %3893

; <label>:3893                                    ; preds = %3868, %3854
  %3894 = phi float [ %3890, %3868 ], [ %3864, %3854 ]
  %3895 = phi float [ %3891, %3868 ], [ %3865, %3854 ]
  %3896 = phi float [ %3892, %3868 ], [ %3866, %3854 ]
  %3897 = call float @dx.op.unary.f32(i32 7, float %3894)  ; Saturate(value)
  %3898 = call float @dx.op.unary.f32(i32 7, float %3895)  ; Saturate(value)
  %3899 = call float @dx.op.unary.f32(i32 7, float %3896)  ; Saturate(value)
  %3900 = call float @dx.op.dot3.f32(i32 55, float %3897, float %3898, float %3899, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3901 = fsub fast float %3897, %3900
  %3902 = fsub fast float %3898, %3900
  %3903 = fsub fast float %3899, %3900
  %3904 = fmul fast float %3901, %9
  %3905 = fmul fast float %3902, %9
  %3906 = fmul fast float %3903, %9
  %3907 = fadd fast float %3904, %3900
  %3908 = fadd fast float %3905, %3900
  %3909 = fadd fast float %3906, %3900
  %3910 = call float @dx.op.unary.f32(i32 7, float %3907)  ; Saturate(value)
  %3911 = call float @dx.op.unary.f32(i32 7, float %3908)  ; Saturate(value)
  %3912 = call float @dx.op.unary.f32(i32 7, float %3909)  ; Saturate(value)
  %3913 = fadd fast float %3910, 0xBFC70A3D80000000
  %3914 = fadd fast float %3911, 0xBFC70A3D80000000
  %3915 = fadd fast float %3912, 0xBFC70A3D80000000
  %3916 = fmul fast float %3913, %8
  %3917 = fmul fast float %3914, %8
  %3918 = fmul fast float %3915, %8
  %3919 = fadd fast float %3916, 0x3FC70A3D80000000
  %3920 = fadd fast float %3917, 0x3FC70A3D80000000
  %3921 = fadd fast float %3918, 0x3FC70A3D80000000
  %3922 = call float @dx.op.unary.f32(i32 7, float %3919)  ; Saturate(value)
  %3923 = call float @dx.op.unary.f32(i32 7, float %3920)  ; Saturate(value)
  %3924 = call float @dx.op.unary.f32(i32 7, float %3921)  ; Saturate(value)
  br label %3925

; <label>:3925                                    ; preds = %3893, %3676
  %3926 = phi float [ %3707, %3676 ], [ %3922, %3893 ]
  %3927 = phi float [ %3708, %3676 ], [ %3923, %3893 ]
  %3928 = phi float [ %3709, %3676 ], [ %3924, %3893 ]
  %3929 = add i32 %64, 1
  %3930 = call i32 @dx.op.binary.i32(i32 37, i32 %3929, i32 0)  ; IMax(a,b)
  %3931 = call i32 @dx.op.binary.i32(i32 38, i32 %3930, i32 %60)  ; IMin(a,b)
  %3932 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3931, i32 %3669, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3933 = extractvalue %dx.types.ResRet.f32 %3932, 0
  %3934 = extractvalue %dx.types.ResRet.f32 %3932, 1
  %3935 = extractvalue %dx.types.ResRet.f32 %3932, 2
  %3936 = extractvalue %dx.types.ResRet.f32 %3932, 3
  %3937 = fcmp fast olt float %3936, 0.000000e+00
  br i1 %3937, label %3938, label %3972

; <label>:3938                                    ; preds = %3925
  %3939 = fcmp fast ogt float %3933, 0x3FA4B5DCC0000000
  %3940 = fcmp fast ogt float %3934, 0x3FA4B5DCC0000000
  %3941 = fcmp fast ogt float %3935, 0x3FA4B5DCC0000000
  %3942 = select i1 %3939, float 0.000000e+00, float 1.000000e+00
  %3943 = select i1 %3940, float 0.000000e+00, float 1.000000e+00
  %3944 = select i1 %3941, float 0.000000e+00, float 1.000000e+00
  %3945 = fmul fast float %3933, 0x3FB3D07220000000
  %3946 = fmul fast float %3934, 0x3FB3D07220000000
  %3947 = fmul fast float %3935, 0x3FB3D07220000000
  %3948 = fadd fast float %3933, 0x3FAC28F5C0000000
  %3949 = fadd fast float %3934, 0x3FAC28F5C0000000
  %3950 = fadd fast float %3935, 0x3FAC28F5C0000000
  %3951 = fmul fast float %3948, 0x3FEE54EDE0000000
  %3952 = fmul fast float %3949, 0x3FEE54EDE0000000
  %3953 = fmul fast float %3950, 0x3FEE54EDE0000000
  %3954 = call float @dx.op.unary.f32(i32 23, float %3951)  ; Log(value)
  %3955 = call float @dx.op.unary.f32(i32 23, float %3952)  ; Log(value)
  %3956 = call float @dx.op.unary.f32(i32 23, float %3953)  ; Log(value)
  %3957 = fmul fast float %3954, 0x4003333340000000
  %3958 = fmul fast float %3955, 0x4003333340000000
  %3959 = fmul fast float %3956, 0x4003333340000000
  %3960 = call float @dx.op.unary.f32(i32 21, float %3957)  ; Exp(value)
  %3961 = call float @dx.op.unary.f32(i32 21, float %3958)  ; Exp(value)
  %3962 = call float @dx.op.unary.f32(i32 21, float %3959)  ; Exp(value)
  %3963 = fsub fast float %3945, %3960
  %3964 = fsub fast float %3946, %3961
  %3965 = fsub fast float %3947, %3962
  %3966 = fmul fast float %3963, %3942
  %3967 = fmul fast float %3964, %3943
  %3968 = fmul fast float %3965, %3944
  %3969 = fadd fast float %3966, %3960
  %3970 = fadd fast float %3967, %3961
  %3971 = fadd fast float %3968, %3962
  br label %4187

; <label>:3972                                    ; preds = %3925
  %3973 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3931, i32 %3669, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3974 = extractvalue %dx.types.ResRet.f32 %3973, 0
  %3975 = fcmp fast ogt float %39, 5.000000e-01
  %3976 = fcmp fast olt float %3974, 1.000000e+00
  %3977 = and i1 %3975, %3976
  br i1 %3977, label %3978, label %4116

; <label>:3978                                    ; preds = %3972
  %3979 = sitofp i32 %3931 to float
  %3980 = sitofp i32 %3669 to float
  %3981 = fadd fast float %3979, 5.000000e-01
  %3982 = fadd fast float %3980, 5.000000e-01
  %3983 = fdiv fast float %3981, %46
  %3984 = fdiv fast float %3982, %47
  %3985 = fmul fast float %3983, 2.000000e+00
  %3986 = fmul fast float %3984, 2.000000e+00
  %3987 = fadd fast float %3985, -1.000000e+00
  %3988 = fsub fast float 1.000000e+00, %3986
  %3989 = fmul fast float %3987, %36
  %3990 = call float @dx.op.tertiary.f32(i32 46, float %3988, float %32, float %3989)  ; FMad(a,b,c)
  %3991 = call float @dx.op.tertiary.f32(i32 46, float %3974, float %28, float %3990)  ; FMad(a,b,c)
  %3992 = fadd fast float %3991, %24
  %3993 = call float @dx.op.unary.f32(i32 6, float %3992)  ; FAbs(value)
  %3994 = fcmp fast ogt float %3993, 0x3EB0C6F7A0000000
  br i1 %3994, label %3995, label %4116

; <label>:3995                                    ; preds = %3978
  %3996 = fmul fast float %3987, %35
  %3997 = call float @dx.op.tertiary.f32(i32 46, float %3988, float %31, float %3996)  ; FMad(a,b,c)
  %3998 = call float @dx.op.tertiary.f32(i32 46, float %3974, float %27, float %3997)  ; FMad(a,b,c)
  %3999 = fadd fast float %3998, %23
  %4000 = fmul fast float %3987, %34
  %4001 = call float @dx.op.tertiary.f32(i32 46, float %3988, float %30, float %4000)  ; FMad(a,b,c)
  %4002 = call float @dx.op.tertiary.f32(i32 46, float %3974, float %26, float %4001)  ; FMad(a,b,c)
  %4003 = fadd fast float %4002, %22
  %4004 = fmul fast float %3987, %33
  %4005 = call float @dx.op.tertiary.f32(i32 46, float %3988, float %29, float %4004)  ; FMad(a,b,c)
  %4006 = call float @dx.op.tertiary.f32(i32 46, float %3974, float %25, float %4005)  ; FMad(a,b,c)
  %4007 = fadd fast float %4006, %21
  %4008 = fdiv fast float %4007, %3992
  %4009 = fdiv fast float %4003, %3992
  %4010 = fdiv fast float %3999, %3992
  %4011 = fsub fast float %4008, %18
  %4012 = fsub fast float %4009, %19
  %4013 = fsub fast float %4010, %20
  %4014 = fmul fast float %4011, %4011
  %4015 = fmul fast float %4012, %4012
  %4016 = fadd fast float %4015, %4014
  %4017 = fmul fast float %4013, %4013
  %4018 = fadd fast float %4016, %4017
  %4019 = call float @dx.op.unary.f32(i32 24, float %4018)  ; Sqrt(value)
  %4020 = fsub fast float %4019, %10
  %4021 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4020)  ; FMax(a,b)
  %4022 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %4022, label %4023, label %4046

; <label>:4023                                    ; preds = %3995
  %4024 = call float @dx.op.unary.f32(i32 6, float %4012)  ; FAbs(value)
  %4025 = fmul fast float %4024, %12
  %4026 = fcmp fast olt float %4025, 0x3F50624DE0000000
  br i1 %4026, label %4027, label %4030

; <label>:4027                                    ; preds = %4023
  %4028 = fmul fast float %4025, 5.000000e-01
  %4029 = fsub fast float 1.000000e+00, %4028
  br label %4035

; <label>:4030                                    ; preds = %4023
  %4031 = fmul fast float %4025, 0xBFF7154760000000
  %4032 = call float @dx.op.unary.f32(i32 21, float %4031)  ; Exp(value)
  %4033 = fsub fast float 1.000000e+00, %4032
  %4034 = fdiv fast float %4033, %4025
  br label %4035

; <label>:4035                                    ; preds = %4030, %4027
  %4036 = phi float [ %4029, %4027 ], [ %4034, %4030 ]
  %4037 = call float @dx.op.binary.f32(i32 36, float %4009, float %19)  ; FMin(a,b)
  %4038 = fsub fast float %4037, %11
  %4039 = fmul fast float %12, %4038
  %4040 = fsub fast float -0.000000e+00, %4039
  %4041 = call float @dx.op.binary.f32(i32 35, float %4040, float -4.000000e+01)  ; FMax(a,b)
  %4042 = call float @dx.op.binary.f32(i32 36, float %4041, float 5.000000e+00)  ; FMin(a,b)
  %4043 = fmul fast float %4042, 0x3FF7154760000000
  %4044 = call float @dx.op.unary.f32(i32 21, float %4043)  ; Exp(value)
  %4045 = fmul fast float %4044, %4036
  br label %4046

; <label>:4046                                    ; preds = %4035, %3995
  %4047 = phi float [ %4045, %4035 ], [ 1.000000e+00, %3995 ]
  %4048 = fmul fast float %4021, %17
  %4049 = fmul fast float %4048, %4047
  %4050 = fcmp fast ole float %4019, %10
  %4051 = fcmp fast olt float %4019, 0x3F1A36E2E0000000
  %4052 = or i1 %4050, %4051
  br i1 %4052, label %4099, label %4053

; <label>:4053                                    ; preds = %4046
  %4054 = fdiv fast float %10, %4019
  %4055 = fmul fast float %4054, %4011
  %4056 = fmul fast float %4054, %4012
  %4057 = fmul fast float %4054, %4013
  %4058 = fadd fast float %4055, %18
  %4059 = fadd fast float %4056, %19
  %4060 = fadd fast float %4057, %20
  %4061 = fadd fast float %4058, -9.000000e+02
  %4062 = fadd fast float %4059, -1.500000e+01
  %4063 = fadd fast float %4060, -7.500000e+02
  %4064 = fmul fast float %4061, 0x3F62345680000000
  %4065 = fmul fast float %4062, 0x3F62345680000000
  %4066 = fmul fast float %4063, 0x3F62345680000000
  %4067 = call float @dx.op.dot3.f32(i32 55, float %4064, float %4065, float %4066, float %4064, float %4065, float %4066)  ; Dot3(ax,ay,az,bx,by,bz)
  %4068 = fsub fast float 1.000000e+00, %4067
  %4069 = call float @dx.op.unary.f32(i32 7, float %4068)  ; Saturate(value)
  %4070 = fmul fast float %4069, %4069
  %4071 = fadd fast float %4058, %4008
  %4072 = fadd fast float %4059, %4009
  %4073 = fadd fast float %4060, %4010
  %4074 = fmul fast float %4071, 0x3F52345680000000
  %4075 = fadd fast float %4074, -2.000000e+00
  %4076 = fmul fast float %4072, 0x3F52345680000000
  %4077 = fadd fast float %4076, 0xBFA1111120000000
  %4078 = fmul fast float %4073, 0x3F52345680000000
  %4079 = fadd fast float %4078, 0xBFFAAAAAC0000000
  %4080 = call float @dx.op.dot3.f32(i32 55, float %4075, float %4077, float %4079, float %4075, float %4077, float %4079)  ; Dot3(ax,ay,az,bx,by,bz)
  %4081 = fsub fast float 1.000000e+00, %4080
  %4082 = call float @dx.op.unary.f32(i32 7, float %4081)  ; Saturate(value)
  %4083 = fmul fast float %4082, %4082
  %4084 = fmul fast float %4083, 4.000000e+00
  %4085 = fadd fast float %4084, %4070
  %4086 = fadd fast float %4008, -9.000000e+02
  %4087 = fadd fast float %4009, -1.500000e+01
  %4088 = fadd fast float %4010, -7.500000e+02
  %4089 = fmul fast float %4086, 0x3F62345680000000
  %4090 = fmul fast float %4087, 0x3F62345680000000
  %4091 = fmul fast float %4088, 0x3F62345680000000
  %4092 = call float @dx.op.dot3.f32(i32 55, float %4089, float %4090, float %4091, float %4089, float %4090, float %4091)  ; Dot3(ax,ay,az,bx,by,bz)
  %4093 = fsub fast float 1.000000e+00, %4092
  %4094 = call float @dx.op.unary.f32(i32 7, float %4093)  ; Saturate(value)
  %4095 = fmul fast float %4094, %4094
  %4096 = fadd fast float %4085, %4095
  %4097 = fmul fast float %4020, 0x3F25D867E0000000
  %4098 = fmul fast float %4097, %4096
  br label %4099

; <label>:4099                                    ; preds = %4053, %4046
  %4100 = phi float [ %4098, %4053 ], [ 0.000000e+00, %4046 ]
  %4101 = fadd fast float %4100, %4049
  %4102 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4101)  ; FMin(a,b)
  %4103 = fmul fast float %4102, 0xBFF7154760000000
  %4104 = call float @dx.op.unary.f32(i32 21, float %4103)  ; Exp(value)
  %4105 = fsub fast float 1.000000e+00, %4104
  %4106 = call float @dx.op.binary.f32(i32 36, float %13, float %4105)  ; FMin(a,b)
  %4107 = fsub fast float %14, %3933
  %4108 = fsub fast float %15, %3934
  %4109 = fsub fast float %16, %3935
  %4110 = fmul fast float %4106, %4107
  %4111 = fmul fast float %4106, %4108
  %4112 = fmul fast float %4106, %4109
  %4113 = fadd fast float %4110, %3933
  %4114 = fadd fast float %4111, %3934
  %4115 = fadd fast float %4112, %3935
  br label %4116

; <label>:4116                                    ; preds = %4099, %3978, %3972
  %4117 = phi float [ %4113, %4099 ], [ %3933, %3978 ], [ %3933, %3972 ]
  %4118 = phi float [ %4114, %4099 ], [ %3934, %3978 ], [ %3934, %3972 ]
  %4119 = phi float [ %4115, %4099 ], [ %3935, %3978 ], [ %3935, %3972 ]
  %4120 = fadd fast float %6, 1.000000e+00
  %4121 = fadd fast float %7, 1.000000e+00
  %4122 = fsub fast float 1.000000e+00, %6
  %4123 = fmul fast float %37, %4120
  %4124 = fmul fast float %37, %4121
  %4125 = fmul fast float %37, %4122
  %4126 = fmul fast float %4123, %4117
  %4127 = fmul fast float %4124, %4118
  %4128 = fmul fast float %4125, %4119
  %4129 = fcmp fast ult float %38, 5.000000e-01
  br i1 %4129, label %4155, label %4130

; <label>:4130                                    ; preds = %4116
  %4131 = fmul fast float %4126, 0x4004147AE0000000
  %4132 = fmul fast float %4127, 0x4004147AE0000000
  %4133 = fmul fast float %4128, 0x4004147AE0000000
  %4134 = fadd fast float %4131, 0x3F9EB851E0000000
  %4135 = fadd fast float %4132, 0x3F9EB851E0000000
  %4136 = fadd fast float %4133, 0x3F9EB851E0000000
  %4137 = fmul fast float %4134, %4126
  %4138 = fmul fast float %4135, %4127
  %4139 = fmul fast float %4136, %4128
  %4140 = fmul fast float %4126, 0x400370A3E0000000
  %4141 = fmul fast float %4127, 0x400370A3E0000000
  %4142 = fmul fast float %4128, 0x400370A3E0000000
  %4143 = fadd fast float %4140, 0x3FE2E147A0000000
  %4144 = fadd fast float %4141, 0x3FE2E147A0000000
  %4145 = fadd fast float %4142, 0x3FE2E147A0000000
  %4146 = fmul fast float %4143, %4126
  %4147 = fmul fast float %4144, %4127
  %4148 = fmul fast float %4145, %4128
  %4149 = fadd fast float %4146, 0x3FC1EB8520000000
  %4150 = fadd fast float %4147, 0x3FC1EB8520000000
  %4151 = fadd fast float %4148, 0x3FC1EB8520000000
  %4152 = fdiv fast float %4137, %4149
  %4153 = fdiv fast float %4138, %4150
  %4154 = fdiv fast float %4139, %4151
  br label %4155

; <label>:4155                                    ; preds = %4130, %4116
  %4156 = phi float [ %4152, %4130 ], [ %4126, %4116 ]
  %4157 = phi float [ %4153, %4130 ], [ %4127, %4116 ]
  %4158 = phi float [ %4154, %4130 ], [ %4128, %4116 ]
  %4159 = call float @dx.op.unary.f32(i32 7, float %4156)  ; Saturate(value)
  %4160 = call float @dx.op.unary.f32(i32 7, float %4157)  ; Saturate(value)
  %4161 = call float @dx.op.unary.f32(i32 7, float %4158)  ; Saturate(value)
  %4162 = call float @dx.op.dot3.f32(i32 55, float %4159, float %4160, float %4161, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4163 = fsub fast float %4159, %4162
  %4164 = fsub fast float %4160, %4162
  %4165 = fsub fast float %4161, %4162
  %4166 = fmul fast float %4163, %9
  %4167 = fmul fast float %4164, %9
  %4168 = fmul fast float %4165, %9
  %4169 = fadd fast float %4166, %4162
  %4170 = fadd fast float %4167, %4162
  %4171 = fadd fast float %4168, %4162
  %4172 = call float @dx.op.unary.f32(i32 7, float %4169)  ; Saturate(value)
  %4173 = call float @dx.op.unary.f32(i32 7, float %4170)  ; Saturate(value)
  %4174 = call float @dx.op.unary.f32(i32 7, float %4171)  ; Saturate(value)
  %4175 = fadd fast float %4172, 0xBFC70A3D80000000
  %4176 = fadd fast float %4173, 0xBFC70A3D80000000
  %4177 = fadd fast float %4174, 0xBFC70A3D80000000
  %4178 = fmul fast float %4175, %8
  %4179 = fmul fast float %4176, %8
  %4180 = fmul fast float %4177, %8
  %4181 = fadd fast float %4178, 0x3FC70A3D80000000
  %4182 = fadd fast float %4179, 0x3FC70A3D80000000
  %4183 = fadd fast float %4180, 0x3FC70A3D80000000
  %4184 = call float @dx.op.unary.f32(i32 7, float %4181)  ; Saturate(value)
  %4185 = call float @dx.op.unary.f32(i32 7, float %4182)  ; Saturate(value)
  %4186 = call float @dx.op.unary.f32(i32 7, float %4183)  ; Saturate(value)
  br label %4187

; <label>:4187                                    ; preds = %4155, %3938
  %4188 = phi float [ %3969, %3938 ], [ %4184, %4155 ]
  %4189 = phi float [ %3970, %3938 ], [ %4185, %4155 ]
  %4190 = phi float [ %3971, %3938 ], [ %4186, %4155 ]
  %4191 = call float @dx.op.binary.f32(i32 36, float %3926, float %4188)  ; FMin(a,b)
  %4192 = call float @dx.op.binary.f32(i32 36, float %3927, float %4189)  ; FMin(a,b)
  %4193 = call float @dx.op.binary.f32(i32 36, float %3928, float %4190)  ; FMin(a,b)
  %4194 = call float @dx.op.binary.f32(i32 36, float %3400, float %3662)  ; FMin(a,b)
  %4195 = call float @dx.op.binary.f32(i32 36, float %3401, float %3663)  ; FMin(a,b)
  %4196 = call float @dx.op.binary.f32(i32 36, float %3402, float %3664)  ; FMin(a,b)
  %4197 = call float @dx.op.binary.f32(i32 36, float %4194, float %4191)  ; FMin(a,b)
  %4198 = call float @dx.op.binary.f32(i32 36, float %4195, float %4192)  ; FMin(a,b)
  %4199 = call float @dx.op.binary.f32(i32 36, float %4196, float %4193)  ; FMin(a,b)
  %4200 = call float @dx.op.binary.f32(i32 36, float %3134, float %4197)  ; FMin(a,b)
  %4201 = call float @dx.op.binary.f32(i32 36, float %3135, float %4198)  ; FMin(a,b)
  %4202 = call float @dx.op.binary.f32(i32 36, float %3136, float %4199)  ; FMin(a,b)
  %4203 = call float @dx.op.binary.f32(i32 35, float %3926, float %4188)  ; FMax(a,b)
  %4204 = call float @dx.op.binary.f32(i32 35, float %3927, float %4189)  ; FMax(a,b)
  %4205 = call float @dx.op.binary.f32(i32 35, float %3928, float %4190)  ; FMax(a,b)
  %4206 = call float @dx.op.binary.f32(i32 35, float %3400, float %3662)  ; FMax(a,b)
  %4207 = call float @dx.op.binary.f32(i32 35, float %3401, float %3663)  ; FMax(a,b)
  %4208 = call float @dx.op.binary.f32(i32 35, float %3402, float %3664)  ; FMax(a,b)
  %4209 = call float @dx.op.binary.f32(i32 35, float %4206, float %4203)  ; FMax(a,b)
  %4210 = call float @dx.op.binary.f32(i32 35, float %4207, float %4204)  ; FMax(a,b)
  %4211 = call float @dx.op.binary.f32(i32 35, float %4208, float %4205)  ; FMax(a,b)
  %4212 = call float @dx.op.binary.f32(i32 35, float %3134, float %4209)  ; FMax(a,b)
  %4213 = call float @dx.op.binary.f32(i32 35, float %3135, float %4210)  ; FMax(a,b)
  %4214 = call float @dx.op.binary.f32(i32 35, float %3136, float %4211)  ; FMax(a,b)
  %4215 = fsub fast float %4212, %4200
  %4216 = fsub fast float %4213, %4201
  %4217 = fsub fast float %4214, %4202
  %4218 = call float @dx.op.unary.f32(i32 6, float %4215)  ; FAbs(value)
  %4219 = call float @dx.op.unary.f32(i32 6, float %4216)  ; FAbs(value)
  %4220 = call float @dx.op.unary.f32(i32 6, float %4217)  ; FAbs(value)
  %4221 = call float @dx.op.binary.f32(i32 35, float %4219, float %4220)  ; FMax(a,b)
  %4222 = call float @dx.op.binary.f32(i32 35, float %4218, float %4221)  ; FMax(a,b)
  %4223 = call float @dx.op.binary.f32(i32 35, float %4213, float %4214)  ; FMax(a,b)
  %4224 = call float @dx.op.binary.f32(i32 35, float %4212, float %4223)  ; FMax(a,b)
  %4225 = fmul fast float %4224, 1.250000e-01
  %4226 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %4225)  ; FMax(a,b)
  %4227 = fcmp fast ogt float %4222, %4226
  br i1 %4227, label %4228, label %4290

; <label>:4228                                    ; preds = %4187
  %4229 = fsub fast float %3400, %3662
  %4230 = fsub fast float %3401, %3663
  %4231 = fsub fast float %3402, %3664
  %4232 = call float @dx.op.unary.f32(i32 6, float %4229)  ; FAbs(value)
  %4233 = call float @dx.op.unary.f32(i32 6, float %4230)  ; FAbs(value)
  %4234 = call float @dx.op.unary.f32(i32 6, float %4231)  ; FAbs(value)
  %4235 = call float @dx.op.binary.f32(i32 35, float %4233, float %4234)  ; FMax(a,b)
  %4236 = call float @dx.op.binary.f32(i32 35, float %4232, float %4235)  ; FMax(a,b)
  %4237 = fsub fast float %3926, %4188
  %4238 = fsub fast float %3927, %4189
  %4239 = fsub fast float %3928, %4190
  %4240 = call float @dx.op.unary.f32(i32 6, float %4237)  ; FAbs(value)
  %4241 = call float @dx.op.unary.f32(i32 6, float %4238)  ; FAbs(value)
  %4242 = call float @dx.op.unary.f32(i32 6, float %4239)  ; FAbs(value)
  %4243 = call float @dx.op.binary.f32(i32 35, float %4241, float %4242)  ; FMax(a,b)
  %4244 = call float @dx.op.binary.f32(i32 35, float %4240, float %4243)  ; FMax(a,b)
  %4245 = fcmp fast olt float %4236, %4244
  %4246 = select i1 %4245, float %3400, float %3926
  %4247 = select i1 %4245, float %3401, float %3927
  %4248 = select i1 %4245, float %3402, float %3928
  %4249 = select i1 %4245, float %3662, float %4188
  %4250 = select i1 %4245, float %3663, float %4189
  %4251 = select i1 %4245, float %3664, float %4190
  %4252 = fsub fast float %3134, %4249
  %4253 = fsub fast float %3135, %4250
  %4254 = fsub fast float %3136, %4251
  %4255 = fsub fast float %3134, %4246
  %4256 = fsub fast float %3135, %4247
  %4257 = fsub fast float %3136, %4248
  %4258 = call float @dx.op.dot3.f32(i32 55, float %4255, float %4256, float %4257, float %4252, float %4253, float %4254)  ; Dot3(ax,ay,az,bx,by,bz)
  %4259 = fcmp fast ogt float %4258, 0.000000e+00
  br i1 %4259, label %4260, label %4271

; <label>:4260                                    ; preds = %4228
  %4261 = fsub fast float %4246, %4249
  %4262 = fsub fast float %4247, %4250
  %4263 = fsub fast float %4248, %4251
  %4264 = call float @dx.op.unary.f32(i32 6, float %4261)  ; FAbs(value)
  %4265 = call float @dx.op.unary.f32(i32 6, float %4262)  ; FAbs(value)
  %4266 = call float @dx.op.unary.f32(i32 6, float %4263)  ; FAbs(value)
  %4267 = call float @dx.op.binary.f32(i32 35, float %4265, float %4266)  ; FMax(a,b)
  %4268 = call float @dx.op.binary.f32(i32 35, float %4264, float %4267)  ; FMax(a,b)
  %4269 = fmul fast float %4222, 2.500000e-01
  %4270 = fcmp fast olt float %4268, %4269
  br label %4271

; <label>:4271                                    ; preds = %4260, %4228
  %4272 = phi i1 [ false, %4228 ], [ %4270, %4260 ]
  %4273 = select i1 %4272, float 5.000000e-01, float 1.000000e+00
  %4274 = fmul fast float %4273, %3
  %4275 = fadd fast float %4246, %4249
  %4276 = fadd fast float %4247, %4250
  %4277 = fadd fast float %4248, %4251
  %4278 = fmul fast float %4275, 5.000000e-01
  %4279 = fmul fast float %4276, 5.000000e-01
  %4280 = fmul fast float %4277, 5.000000e-01
  %4281 = fsub fast float %4278, %3134
  %4282 = fsub fast float %4279, %3135
  %4283 = fsub fast float %4280, %3136
  %4284 = fmul fast float %4274, %4281
  %4285 = fmul fast float %4274, %4282
  %4286 = fmul fast float %4274, %4283
  %4287 = fadd fast float %4284, %3134
  %4288 = fadd fast float %4285, %3135
  %4289 = fadd fast float %4286, %3136
  br label %4290

; <label>:4290                                    ; preds = %4271, %4187, %3105
  %4291 = phi float [ %4287, %4271 ], [ %3134, %4187 ], [ %3134, %3105 ]
  %4292 = phi float [ %4288, %4271 ], [ %3135, %4187 ], [ %3135, %3105 ]
  %4293 = phi float [ %4289, %4271 ], [ %3136, %4187 ], [ %3136, %3105 ]
  %4294 = fcmp fast ogt float %4291, 0x3F69A5C380000000
  %4295 = fcmp fast ogt float %4292, 0x3F69A5C380000000
  %4296 = fcmp fast ogt float %4293, 0x3F69A5C380000000
  %4297 = select i1 %4294, float 0.000000e+00, float 1.000000e+00
  %4298 = select i1 %4295, float 0.000000e+00, float 1.000000e+00
  %4299 = select i1 %4296, float 0.000000e+00, float 1.000000e+00
  %4300 = fmul fast float %4291, 0x4029D70A40000000
  %4301 = fmul fast float %4292, 0x4029D70A40000000
  %4302 = fmul fast float %4293, 0x4029D70A40000000
  %4303 = call float @dx.op.binary.f32(i32 35, float %4291, float 0.000000e+00)  ; FMax(a,b)
  %4304 = call float @dx.op.binary.f32(i32 35, float %4292, float 0.000000e+00)  ; FMax(a,b)
  %4305 = call float @dx.op.binary.f32(i32 35, float %4293, float 0.000000e+00)  ; FMax(a,b)
  %4306 = call float @dx.op.unary.f32(i32 23, float %4303)  ; Log(value)
  %4307 = call float @dx.op.unary.f32(i32 23, float %4304)  ; Log(value)
  %4308 = call float @dx.op.unary.f32(i32 23, float %4305)  ; Log(value)
  %4309 = fmul fast float %4306, 0x3FDAAAAAA0000000
  %4310 = fmul fast float %4307, 0x3FDAAAAAA0000000
  %4311 = fmul fast float %4308, 0x3FDAAAAAA0000000
  %4312 = call float @dx.op.unary.f32(i32 21, float %4309)  ; Exp(value)
  %4313 = call float @dx.op.unary.f32(i32 21, float %4310)  ; Exp(value)
  %4314 = call float @dx.op.unary.f32(i32 21, float %4311)  ; Exp(value)
  %4315 = fmul fast float %4312, 0x3FF0E147A0000000
  %4316 = fmul fast float %4313, 0x3FF0E147A0000000
  %4317 = fmul fast float %4314, 0x3FF0E147A0000000
  %4318 = fadd fast float %4315, 0xBFAC28F5C0000000
  %4319 = fadd fast float %4316, 0xBFAC28F5C0000000
  %4320 = fadd fast float %4317, 0xBFAC28F5C0000000
  %4321 = fsub fast float %4300, %4318
  %4322 = fsub fast float %4301, %4319
  %4323 = fsub fast float %4302, %4320
  %4324 = fmul fast float %4321, %4297
  %4325 = fmul fast float %4322, %4298
  %4326 = fmul fast float %4323, %4299
  %4327 = fadd fast float %4324, %4318
  %4328 = fadd fast float %4325, %4319
  %4329 = fadd fast float %4326, %4320
  br label %4330

; <label>:4330                                    ; preds = %4290, %2920
  %4331 = phi float [ %2915, %2920 ], [ %4327, %4290 ]
  %4332 = phi float [ %2916, %2920 ], [ %4328, %4290 ]
  %4333 = phi float [ %2917, %2920 ], [ %4329, %4290 ]
  %4334 = phi float [ %2921, %2920 ], [ %2918, %4290 ]
  %4335 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1489, i32 %2913, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4336 = extractvalue %dx.types.ResRet.f32 %4335, 0
  %4337 = extractvalue %dx.types.ResRet.f32 %4335, 1
  %4338 = extractvalue %dx.types.ResRet.f32 %4335, 2
  %4339 = extractvalue %dx.types.ResRet.f32 %4335, 3
  %4340 = fcmp fast olt float %4339, 0.000000e+00
  br i1 %4340, label %4341, label %4343

; <label>:4341                                    ; preds = %4330
  %4342 = fsub fast float -1.000000e+00, %4339
  br label %5751

; <label>:4343                                    ; preds = %4330
  %4344 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1489, i32 %2913, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4345 = extractvalue %dx.types.ResRet.f32 %4344, 0
  %4346 = fcmp fast ogt float %39, 5.000000e-01
  %4347 = fcmp fast olt float %4345, 1.000000e+00
  %4348 = and i1 %4346, %4347
  br i1 %4348, label %4349, label %4487

; <label>:4349                                    ; preds = %4343
  %4350 = sitofp i32 %1489 to float
  %4351 = sitofp i32 %2913 to float
  %4352 = fadd fast float %4350, 5.000000e-01
  %4353 = fadd fast float %4351, 5.000000e-01
  %4354 = fdiv fast float %4352, %46
  %4355 = fdiv fast float %4353, %47
  %4356 = fmul fast float %4354, 2.000000e+00
  %4357 = fmul fast float %4355, 2.000000e+00
  %4358 = fadd fast float %4356, -1.000000e+00
  %4359 = fsub fast float 1.000000e+00, %4357
  %4360 = fmul fast float %4358, %36
  %4361 = call float @dx.op.tertiary.f32(i32 46, float %4359, float %32, float %4360)  ; FMad(a,b,c)
  %4362 = call float @dx.op.tertiary.f32(i32 46, float %4345, float %28, float %4361)  ; FMad(a,b,c)
  %4363 = fadd fast float %4362, %24
  %4364 = call float @dx.op.unary.f32(i32 6, float %4363)  ; FAbs(value)
  %4365 = fcmp fast ogt float %4364, 0x3EB0C6F7A0000000
  br i1 %4365, label %4366, label %4487

; <label>:4366                                    ; preds = %4349
  %4367 = fmul fast float %4358, %35
  %4368 = call float @dx.op.tertiary.f32(i32 46, float %4359, float %31, float %4367)  ; FMad(a,b,c)
  %4369 = call float @dx.op.tertiary.f32(i32 46, float %4345, float %27, float %4368)  ; FMad(a,b,c)
  %4370 = fadd fast float %4369, %23
  %4371 = fmul fast float %4358, %34
  %4372 = call float @dx.op.tertiary.f32(i32 46, float %4359, float %30, float %4371)  ; FMad(a,b,c)
  %4373 = call float @dx.op.tertiary.f32(i32 46, float %4345, float %26, float %4372)  ; FMad(a,b,c)
  %4374 = fadd fast float %4373, %22
  %4375 = fmul fast float %4358, %33
  %4376 = call float @dx.op.tertiary.f32(i32 46, float %4359, float %29, float %4375)  ; FMad(a,b,c)
  %4377 = call float @dx.op.tertiary.f32(i32 46, float %4345, float %25, float %4376)  ; FMad(a,b,c)
  %4378 = fadd fast float %4377, %21
  %4379 = fdiv fast float %4378, %4363
  %4380 = fdiv fast float %4374, %4363
  %4381 = fdiv fast float %4370, %4363
  %4382 = fsub fast float %4379, %18
  %4383 = fsub fast float %4380, %19
  %4384 = fsub fast float %4381, %20
  %4385 = fmul fast float %4382, %4382
  %4386 = fmul fast float %4383, %4383
  %4387 = fadd fast float %4386, %4385
  %4388 = fmul fast float %4384, %4384
  %4389 = fadd fast float %4387, %4388
  %4390 = call float @dx.op.unary.f32(i32 24, float %4389)  ; Sqrt(value)
  %4391 = fsub fast float %4390, %10
  %4392 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4391)  ; FMax(a,b)
  %4393 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %4393, label %4394, label %4417

; <label>:4394                                    ; preds = %4366
  %4395 = call float @dx.op.unary.f32(i32 6, float %4383)  ; FAbs(value)
  %4396 = fmul fast float %4395, %12
  %4397 = fcmp fast olt float %4396, 0x3F50624DE0000000
  br i1 %4397, label %4398, label %4401

; <label>:4398                                    ; preds = %4394
  %4399 = fmul fast float %4396, 5.000000e-01
  %4400 = fsub fast float 1.000000e+00, %4399
  br label %4406

; <label>:4401                                    ; preds = %4394
  %4402 = fmul fast float %4396, 0xBFF7154760000000
  %4403 = call float @dx.op.unary.f32(i32 21, float %4402)  ; Exp(value)
  %4404 = fsub fast float 1.000000e+00, %4403
  %4405 = fdiv fast float %4404, %4396
  br label %4406

; <label>:4406                                    ; preds = %4401, %4398
  %4407 = phi float [ %4400, %4398 ], [ %4405, %4401 ]
  %4408 = call float @dx.op.binary.f32(i32 36, float %4380, float %19)  ; FMin(a,b)
  %4409 = fsub fast float %4408, %11
  %4410 = fmul fast float %12, %4409
  %4411 = fsub fast float -0.000000e+00, %4410
  %4412 = call float @dx.op.binary.f32(i32 35, float %4411, float -4.000000e+01)  ; FMax(a,b)
  %4413 = call float @dx.op.binary.f32(i32 36, float %4412, float 5.000000e+00)  ; FMin(a,b)
  %4414 = fmul fast float %4413, 0x3FF7154760000000
  %4415 = call float @dx.op.unary.f32(i32 21, float %4414)  ; Exp(value)
  %4416 = fmul fast float %4415, %4407
  br label %4417

; <label>:4417                                    ; preds = %4406, %4366
  %4418 = phi float [ %4416, %4406 ], [ 1.000000e+00, %4366 ]
  %4419 = fmul fast float %4392, %17
  %4420 = fmul fast float %4419, %4418
  %4421 = fcmp fast ole float %4390, %10
  %4422 = fcmp fast olt float %4390, 0x3F1A36E2E0000000
  %4423 = or i1 %4421, %4422
  br i1 %4423, label %4470, label %4424

; <label>:4424                                    ; preds = %4417
  %4425 = fdiv fast float %10, %4390
  %4426 = fmul fast float %4425, %4382
  %4427 = fmul fast float %4425, %4383
  %4428 = fmul fast float %4425, %4384
  %4429 = fadd fast float %4426, %18
  %4430 = fadd fast float %4427, %19
  %4431 = fadd fast float %4428, %20
  %4432 = fadd fast float %4429, -9.000000e+02
  %4433 = fadd fast float %4430, -1.500000e+01
  %4434 = fadd fast float %4431, -7.500000e+02
  %4435 = fmul fast float %4432, 0x3F62345680000000
  %4436 = fmul fast float %4433, 0x3F62345680000000
  %4437 = fmul fast float %4434, 0x3F62345680000000
  %4438 = call float @dx.op.dot3.f32(i32 55, float %4435, float %4436, float %4437, float %4435, float %4436, float %4437)  ; Dot3(ax,ay,az,bx,by,bz)
  %4439 = fsub fast float 1.000000e+00, %4438
  %4440 = call float @dx.op.unary.f32(i32 7, float %4439)  ; Saturate(value)
  %4441 = fmul fast float %4440, %4440
  %4442 = fadd fast float %4429, %4379
  %4443 = fadd fast float %4430, %4380
  %4444 = fadd fast float %4431, %4381
  %4445 = fmul fast float %4442, 0x3F52345680000000
  %4446 = fadd fast float %4445, -2.000000e+00
  %4447 = fmul fast float %4443, 0x3F52345680000000
  %4448 = fadd fast float %4447, 0xBFA1111120000000
  %4449 = fmul fast float %4444, 0x3F52345680000000
  %4450 = fadd fast float %4449, 0xBFFAAAAAC0000000
  %4451 = call float @dx.op.dot3.f32(i32 55, float %4446, float %4448, float %4450, float %4446, float %4448, float %4450)  ; Dot3(ax,ay,az,bx,by,bz)
  %4452 = fsub fast float 1.000000e+00, %4451
  %4453 = call float @dx.op.unary.f32(i32 7, float %4452)  ; Saturate(value)
  %4454 = fmul fast float %4453, %4453
  %4455 = fmul fast float %4454, 4.000000e+00
  %4456 = fadd fast float %4455, %4441
  %4457 = fadd fast float %4379, -9.000000e+02
  %4458 = fadd fast float %4380, -1.500000e+01
  %4459 = fadd fast float %4381, -7.500000e+02
  %4460 = fmul fast float %4457, 0x3F62345680000000
  %4461 = fmul fast float %4458, 0x3F62345680000000
  %4462 = fmul fast float %4459, 0x3F62345680000000
  %4463 = call float @dx.op.dot3.f32(i32 55, float %4460, float %4461, float %4462, float %4460, float %4461, float %4462)  ; Dot3(ax,ay,az,bx,by,bz)
  %4464 = fsub fast float 1.000000e+00, %4463
  %4465 = call float @dx.op.unary.f32(i32 7, float %4464)  ; Saturate(value)
  %4466 = fmul fast float %4465, %4465
  %4467 = fadd fast float %4456, %4466
  %4468 = fmul fast float %4391, 0x3F25D867E0000000
  %4469 = fmul fast float %4468, %4467
  br label %4470

; <label>:4470                                    ; preds = %4424, %4417
  %4471 = phi float [ %4469, %4424 ], [ 0.000000e+00, %4417 ]
  %4472 = fadd fast float %4471, %4420
  %4473 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4472)  ; FMin(a,b)
  %4474 = fmul fast float %4473, 0xBFF7154760000000
  %4475 = call float @dx.op.unary.f32(i32 21, float %4474)  ; Exp(value)
  %4476 = fsub fast float 1.000000e+00, %4475
  %4477 = call float @dx.op.binary.f32(i32 36, float %13, float %4476)  ; FMin(a,b)
  %4478 = fsub fast float %14, %4336
  %4479 = fsub fast float %15, %4337
  %4480 = fsub fast float %16, %4338
  %4481 = fmul fast float %4477, %4478
  %4482 = fmul fast float %4477, %4479
  %4483 = fmul fast float %4477, %4480
  %4484 = fadd fast float %4481, %4336
  %4485 = fadd fast float %4482, %4337
  %4486 = fadd fast float %4483, %4338
  br label %4487

; <label>:4487                                    ; preds = %4470, %4349, %4343
  %4488 = phi float [ %4484, %4470 ], [ %4336, %4349 ], [ %4336, %4343 ]
  %4489 = phi float [ %4485, %4470 ], [ %4337, %4349 ], [ %4337, %4343 ]
  %4490 = phi float [ %4486, %4470 ], [ %4338, %4349 ], [ %4338, %4343 ]
  %4491 = fadd fast float %6, 1.000000e+00
  %4492 = fadd fast float %7, 1.000000e+00
  %4493 = fsub fast float 1.000000e+00, %6
  %4494 = fmul fast float %37, %4491
  %4495 = fmul fast float %37, %4492
  %4496 = fmul fast float %37, %4493
  %4497 = fmul fast float %4494, %4488
  %4498 = fmul fast float %4495, %4489
  %4499 = fmul fast float %4496, %4490
  %4500 = fcmp fast ult float %38, 5.000000e-01
  br i1 %4500, label %4526, label %4501

; <label>:4501                                    ; preds = %4487
  %4502 = fmul fast float %4497, 0x4004147AE0000000
  %4503 = fmul fast float %4498, 0x4004147AE0000000
  %4504 = fmul fast float %4499, 0x4004147AE0000000
  %4505 = fadd fast float %4502, 0x3F9EB851E0000000
  %4506 = fadd fast float %4503, 0x3F9EB851E0000000
  %4507 = fadd fast float %4504, 0x3F9EB851E0000000
  %4508 = fmul fast float %4505, %4497
  %4509 = fmul fast float %4506, %4498
  %4510 = fmul fast float %4507, %4499
  %4511 = fmul fast float %4497, 0x400370A3E0000000
  %4512 = fmul fast float %4498, 0x400370A3E0000000
  %4513 = fmul fast float %4499, 0x400370A3E0000000
  %4514 = fadd fast float %4511, 0x3FE2E147A0000000
  %4515 = fadd fast float %4512, 0x3FE2E147A0000000
  %4516 = fadd fast float %4513, 0x3FE2E147A0000000
  %4517 = fmul fast float %4514, %4497
  %4518 = fmul fast float %4515, %4498
  %4519 = fmul fast float %4516, %4499
  %4520 = fadd fast float %4517, 0x3FC1EB8520000000
  %4521 = fadd fast float %4518, 0x3FC1EB8520000000
  %4522 = fadd fast float %4519, 0x3FC1EB8520000000
  %4523 = fdiv fast float %4508, %4520
  %4524 = fdiv fast float %4509, %4521
  %4525 = fdiv fast float %4510, %4522
  br label %4526

; <label>:4526                                    ; preds = %4501, %4487
  %4527 = phi float [ %4523, %4501 ], [ %4497, %4487 ]
  %4528 = phi float [ %4524, %4501 ], [ %4498, %4487 ]
  %4529 = phi float [ %4525, %4501 ], [ %4499, %4487 ]
  %4530 = call float @dx.op.unary.f32(i32 7, float %4527)  ; Saturate(value)
  %4531 = call float @dx.op.unary.f32(i32 7, float %4528)  ; Saturate(value)
  %4532 = call float @dx.op.unary.f32(i32 7, float %4529)  ; Saturate(value)
  %4533 = call float @dx.op.dot3.f32(i32 55, float %4530, float %4531, float %4532, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4534 = fsub fast float %4530, %4533
  %4535 = fsub fast float %4531, %4533
  %4536 = fsub fast float %4532, %4533
  %4537 = fmul fast float %4534, %9
  %4538 = fmul fast float %4535, %9
  %4539 = fmul fast float %4536, %9
  %4540 = fadd fast float %4537, %4533
  %4541 = fadd fast float %4538, %4533
  %4542 = fadd fast float %4539, %4533
  %4543 = call float @dx.op.unary.f32(i32 7, float %4540)  ; Saturate(value)
  %4544 = call float @dx.op.unary.f32(i32 7, float %4541)  ; Saturate(value)
  %4545 = call float @dx.op.unary.f32(i32 7, float %4542)  ; Saturate(value)
  %4546 = fadd fast float %4543, 0xBFC70A3D80000000
  %4547 = fadd fast float %4544, 0xBFC70A3D80000000
  %4548 = fadd fast float %4545, 0xBFC70A3D80000000
  %4549 = fmul fast float %4546, %8
  %4550 = fmul fast float %4547, %8
  %4551 = fmul fast float %4548, %8
  %4552 = fadd fast float %4549, 0x3FC70A3D80000000
  %4553 = fadd fast float %4550, 0x3FC70A3D80000000
  %4554 = fadd fast float %4551, 0x3FC70A3D80000000
  %4555 = call float @dx.op.unary.f32(i32 7, float %4552)  ; Saturate(value)
  %4556 = call float @dx.op.unary.f32(i32 7, float %4553)  ; Saturate(value)
  %4557 = call float @dx.op.unary.f32(i32 7, float %4554)  ; Saturate(value)
  %4558 = fcmp fast ogt float %3, 0.000000e+00
  br i1 %4558, label %4559, label %5711

; <label>:4559                                    ; preds = %4526
  %4560 = add i32 %2913, -1
  %4561 = call i32 @dx.op.binary.i32(i32 37, i32 %1489, i32 0)  ; IMax(a,b)
  %4562 = call i32 @dx.op.binary.i32(i32 37, i32 %4560, i32 0)  ; IMax(a,b)
  %4563 = call i32 @dx.op.binary.i32(i32 38, i32 %4561, i32 %60)  ; IMin(a,b)
  %4564 = call i32 @dx.op.binary.i32(i32 38, i32 %4562, i32 %61)  ; IMin(a,b)
  %4565 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4563, i32 %4564, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4566 = extractvalue %dx.types.ResRet.f32 %4565, 0
  %4567 = extractvalue %dx.types.ResRet.f32 %4565, 1
  %4568 = extractvalue %dx.types.ResRet.f32 %4565, 2
  %4569 = extractvalue %dx.types.ResRet.f32 %4565, 3
  %4570 = fcmp fast olt float %4569, 0.000000e+00
  br i1 %4570, label %4571, label %4605

; <label>:4571                                    ; preds = %4559
  %4572 = fcmp fast ogt float %4566, 0x3FA4B5DCC0000000
  %4573 = fcmp fast ogt float %4567, 0x3FA4B5DCC0000000
  %4574 = fcmp fast ogt float %4568, 0x3FA4B5DCC0000000
  %4575 = select i1 %4572, float 0.000000e+00, float 1.000000e+00
  %4576 = select i1 %4573, float 0.000000e+00, float 1.000000e+00
  %4577 = select i1 %4574, float 0.000000e+00, float 1.000000e+00
  %4578 = fmul fast float %4566, 0x3FB3D07220000000
  %4579 = fmul fast float %4567, 0x3FB3D07220000000
  %4580 = fmul fast float %4568, 0x3FB3D07220000000
  %4581 = fadd fast float %4566, 0x3FAC28F5C0000000
  %4582 = fadd fast float %4567, 0x3FAC28F5C0000000
  %4583 = fadd fast float %4568, 0x3FAC28F5C0000000
  %4584 = fmul fast float %4581, 0x3FEE54EDE0000000
  %4585 = fmul fast float %4582, 0x3FEE54EDE0000000
  %4586 = fmul fast float %4583, 0x3FEE54EDE0000000
  %4587 = call float @dx.op.unary.f32(i32 23, float %4584)  ; Log(value)
  %4588 = call float @dx.op.unary.f32(i32 23, float %4585)  ; Log(value)
  %4589 = call float @dx.op.unary.f32(i32 23, float %4586)  ; Log(value)
  %4590 = fmul fast float %4587, 0x4003333340000000
  %4591 = fmul fast float %4588, 0x4003333340000000
  %4592 = fmul fast float %4589, 0x4003333340000000
  %4593 = call float @dx.op.unary.f32(i32 21, float %4590)  ; Exp(value)
  %4594 = call float @dx.op.unary.f32(i32 21, float %4591)  ; Exp(value)
  %4595 = call float @dx.op.unary.f32(i32 21, float %4592)  ; Exp(value)
  %4596 = fsub fast float %4578, %4593
  %4597 = fsub fast float %4579, %4594
  %4598 = fsub fast float %4580, %4595
  %4599 = fmul fast float %4596, %4575
  %4600 = fmul fast float %4597, %4576
  %4601 = fmul fast float %4598, %4577
  %4602 = fadd fast float %4599, %4593
  %4603 = fadd fast float %4600, %4594
  %4604 = fadd fast float %4601, %4595
  br label %4820

; <label>:4605                                    ; preds = %4559
  %4606 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4563, i32 %4564, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4607 = extractvalue %dx.types.ResRet.f32 %4606, 0
  %4608 = fcmp fast ogt float %39, 5.000000e-01
  %4609 = fcmp fast olt float %4607, 1.000000e+00
  %4610 = and i1 %4608, %4609
  br i1 %4610, label %4611, label %4749

; <label>:4611                                    ; preds = %4605
  %4612 = sitofp i32 %4563 to float
  %4613 = sitofp i32 %4564 to float
  %4614 = fadd fast float %4612, 5.000000e-01
  %4615 = fadd fast float %4613, 5.000000e-01
  %4616 = fdiv fast float %4614, %46
  %4617 = fdiv fast float %4615, %47
  %4618 = fmul fast float %4616, 2.000000e+00
  %4619 = fmul fast float %4617, 2.000000e+00
  %4620 = fadd fast float %4618, -1.000000e+00
  %4621 = fsub fast float 1.000000e+00, %4619
  %4622 = fmul fast float %4620, %36
  %4623 = call float @dx.op.tertiary.f32(i32 46, float %4621, float %32, float %4622)  ; FMad(a,b,c)
  %4624 = call float @dx.op.tertiary.f32(i32 46, float %4607, float %28, float %4623)  ; FMad(a,b,c)
  %4625 = fadd fast float %4624, %24
  %4626 = call float @dx.op.unary.f32(i32 6, float %4625)  ; FAbs(value)
  %4627 = fcmp fast ogt float %4626, 0x3EB0C6F7A0000000
  br i1 %4627, label %4628, label %4749

; <label>:4628                                    ; preds = %4611
  %4629 = fmul fast float %4620, %35
  %4630 = call float @dx.op.tertiary.f32(i32 46, float %4621, float %31, float %4629)  ; FMad(a,b,c)
  %4631 = call float @dx.op.tertiary.f32(i32 46, float %4607, float %27, float %4630)  ; FMad(a,b,c)
  %4632 = fadd fast float %4631, %23
  %4633 = fmul fast float %4620, %34
  %4634 = call float @dx.op.tertiary.f32(i32 46, float %4621, float %30, float %4633)  ; FMad(a,b,c)
  %4635 = call float @dx.op.tertiary.f32(i32 46, float %4607, float %26, float %4634)  ; FMad(a,b,c)
  %4636 = fadd fast float %4635, %22
  %4637 = fmul fast float %4620, %33
  %4638 = call float @dx.op.tertiary.f32(i32 46, float %4621, float %29, float %4637)  ; FMad(a,b,c)
  %4639 = call float @dx.op.tertiary.f32(i32 46, float %4607, float %25, float %4638)  ; FMad(a,b,c)
  %4640 = fadd fast float %4639, %21
  %4641 = fdiv fast float %4640, %4625
  %4642 = fdiv fast float %4636, %4625
  %4643 = fdiv fast float %4632, %4625
  %4644 = fsub fast float %4641, %18
  %4645 = fsub fast float %4642, %19
  %4646 = fsub fast float %4643, %20
  %4647 = fmul fast float %4644, %4644
  %4648 = fmul fast float %4645, %4645
  %4649 = fadd fast float %4648, %4647
  %4650 = fmul fast float %4646, %4646
  %4651 = fadd fast float %4649, %4650
  %4652 = call float @dx.op.unary.f32(i32 24, float %4651)  ; Sqrt(value)
  %4653 = fsub fast float %4652, %10
  %4654 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4653)  ; FMax(a,b)
  %4655 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %4655, label %4656, label %4679

; <label>:4656                                    ; preds = %4628
  %4657 = call float @dx.op.unary.f32(i32 6, float %4645)  ; FAbs(value)
  %4658 = fmul fast float %4657, %12
  %4659 = fcmp fast olt float %4658, 0x3F50624DE0000000
  br i1 %4659, label %4660, label %4663

; <label>:4660                                    ; preds = %4656
  %4661 = fmul fast float %4658, 5.000000e-01
  %4662 = fsub fast float 1.000000e+00, %4661
  br label %4668

; <label>:4663                                    ; preds = %4656
  %4664 = fmul fast float %4658, 0xBFF7154760000000
  %4665 = call float @dx.op.unary.f32(i32 21, float %4664)  ; Exp(value)
  %4666 = fsub fast float 1.000000e+00, %4665
  %4667 = fdiv fast float %4666, %4658
  br label %4668

; <label>:4668                                    ; preds = %4663, %4660
  %4669 = phi float [ %4662, %4660 ], [ %4667, %4663 ]
  %4670 = call float @dx.op.binary.f32(i32 36, float %4642, float %19)  ; FMin(a,b)
  %4671 = fsub fast float %4670, %11
  %4672 = fmul fast float %12, %4671
  %4673 = fsub fast float -0.000000e+00, %4672
  %4674 = call float @dx.op.binary.f32(i32 35, float %4673, float -4.000000e+01)  ; FMax(a,b)
  %4675 = call float @dx.op.binary.f32(i32 36, float %4674, float 5.000000e+00)  ; FMin(a,b)
  %4676 = fmul fast float %4675, 0x3FF7154760000000
  %4677 = call float @dx.op.unary.f32(i32 21, float %4676)  ; Exp(value)
  %4678 = fmul fast float %4677, %4669
  br label %4679

; <label>:4679                                    ; preds = %4668, %4628
  %4680 = phi float [ %4678, %4668 ], [ 1.000000e+00, %4628 ]
  %4681 = fmul fast float %4654, %17
  %4682 = fmul fast float %4681, %4680
  %4683 = fcmp fast ole float %4652, %10
  %4684 = fcmp fast olt float %4652, 0x3F1A36E2E0000000
  %4685 = or i1 %4683, %4684
  br i1 %4685, label %4732, label %4686

; <label>:4686                                    ; preds = %4679
  %4687 = fdiv fast float %10, %4652
  %4688 = fmul fast float %4687, %4644
  %4689 = fmul fast float %4687, %4645
  %4690 = fmul fast float %4687, %4646
  %4691 = fadd fast float %4688, %18
  %4692 = fadd fast float %4689, %19
  %4693 = fadd fast float %4690, %20
  %4694 = fadd fast float %4691, -9.000000e+02
  %4695 = fadd fast float %4692, -1.500000e+01
  %4696 = fadd fast float %4693, -7.500000e+02
  %4697 = fmul fast float %4694, 0x3F62345680000000
  %4698 = fmul fast float %4695, 0x3F62345680000000
  %4699 = fmul fast float %4696, 0x3F62345680000000
  %4700 = call float @dx.op.dot3.f32(i32 55, float %4697, float %4698, float %4699, float %4697, float %4698, float %4699)  ; Dot3(ax,ay,az,bx,by,bz)
  %4701 = fsub fast float 1.000000e+00, %4700
  %4702 = call float @dx.op.unary.f32(i32 7, float %4701)  ; Saturate(value)
  %4703 = fmul fast float %4702, %4702
  %4704 = fadd fast float %4691, %4641
  %4705 = fadd fast float %4692, %4642
  %4706 = fadd fast float %4693, %4643
  %4707 = fmul fast float %4704, 0x3F52345680000000
  %4708 = fadd fast float %4707, -2.000000e+00
  %4709 = fmul fast float %4705, 0x3F52345680000000
  %4710 = fadd fast float %4709, 0xBFA1111120000000
  %4711 = fmul fast float %4706, 0x3F52345680000000
  %4712 = fadd fast float %4711, 0xBFFAAAAAC0000000
  %4713 = call float @dx.op.dot3.f32(i32 55, float %4708, float %4710, float %4712, float %4708, float %4710, float %4712)  ; Dot3(ax,ay,az,bx,by,bz)
  %4714 = fsub fast float 1.000000e+00, %4713
  %4715 = call float @dx.op.unary.f32(i32 7, float %4714)  ; Saturate(value)
  %4716 = fmul fast float %4715, %4715
  %4717 = fmul fast float %4716, 4.000000e+00
  %4718 = fadd fast float %4717, %4703
  %4719 = fadd fast float %4641, -9.000000e+02
  %4720 = fadd fast float %4642, -1.500000e+01
  %4721 = fadd fast float %4643, -7.500000e+02
  %4722 = fmul fast float %4719, 0x3F62345680000000
  %4723 = fmul fast float %4720, 0x3F62345680000000
  %4724 = fmul fast float %4721, 0x3F62345680000000
  %4725 = call float @dx.op.dot3.f32(i32 55, float %4722, float %4723, float %4724, float %4722, float %4723, float %4724)  ; Dot3(ax,ay,az,bx,by,bz)
  %4726 = fsub fast float 1.000000e+00, %4725
  %4727 = call float @dx.op.unary.f32(i32 7, float %4726)  ; Saturate(value)
  %4728 = fmul fast float %4727, %4727
  %4729 = fadd fast float %4718, %4728
  %4730 = fmul fast float %4653, 0x3F25D867E0000000
  %4731 = fmul fast float %4730, %4729
  br label %4732

; <label>:4732                                    ; preds = %4686, %4679
  %4733 = phi float [ %4731, %4686 ], [ 0.000000e+00, %4679 ]
  %4734 = fadd fast float %4733, %4682
  %4735 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4734)  ; FMin(a,b)
  %4736 = fmul fast float %4735, 0xBFF7154760000000
  %4737 = call float @dx.op.unary.f32(i32 21, float %4736)  ; Exp(value)
  %4738 = fsub fast float 1.000000e+00, %4737
  %4739 = call float @dx.op.binary.f32(i32 36, float %13, float %4738)  ; FMin(a,b)
  %4740 = fsub fast float %14, %4566
  %4741 = fsub fast float %15, %4567
  %4742 = fsub fast float %16, %4568
  %4743 = fmul fast float %4739, %4740
  %4744 = fmul fast float %4739, %4741
  %4745 = fmul fast float %4739, %4742
  %4746 = fadd fast float %4743, %4566
  %4747 = fadd fast float %4744, %4567
  %4748 = fadd fast float %4745, %4568
  br label %4749

; <label>:4749                                    ; preds = %4732, %4611, %4605
  %4750 = phi float [ %4746, %4732 ], [ %4566, %4611 ], [ %4566, %4605 ]
  %4751 = phi float [ %4747, %4732 ], [ %4567, %4611 ], [ %4567, %4605 ]
  %4752 = phi float [ %4748, %4732 ], [ %4568, %4611 ], [ %4568, %4605 ]
  %4753 = fadd fast float %6, 1.000000e+00
  %4754 = fadd fast float %7, 1.000000e+00
  %4755 = fsub fast float 1.000000e+00, %6
  %4756 = fmul fast float %37, %4753
  %4757 = fmul fast float %37, %4754
  %4758 = fmul fast float %37, %4755
  %4759 = fmul fast float %4756, %4750
  %4760 = fmul fast float %4757, %4751
  %4761 = fmul fast float %4758, %4752
  %4762 = fcmp fast ult float %38, 5.000000e-01
  br i1 %4762, label %4788, label %4763

; <label>:4763                                    ; preds = %4749
  %4764 = fmul fast float %4759, 0x4004147AE0000000
  %4765 = fmul fast float %4760, 0x4004147AE0000000
  %4766 = fmul fast float %4761, 0x4004147AE0000000
  %4767 = fadd fast float %4764, 0x3F9EB851E0000000
  %4768 = fadd fast float %4765, 0x3F9EB851E0000000
  %4769 = fadd fast float %4766, 0x3F9EB851E0000000
  %4770 = fmul fast float %4767, %4759
  %4771 = fmul fast float %4768, %4760
  %4772 = fmul fast float %4769, %4761
  %4773 = fmul fast float %4759, 0x400370A3E0000000
  %4774 = fmul fast float %4760, 0x400370A3E0000000
  %4775 = fmul fast float %4761, 0x400370A3E0000000
  %4776 = fadd fast float %4773, 0x3FE2E147A0000000
  %4777 = fadd fast float %4774, 0x3FE2E147A0000000
  %4778 = fadd fast float %4775, 0x3FE2E147A0000000
  %4779 = fmul fast float %4776, %4759
  %4780 = fmul fast float %4777, %4760
  %4781 = fmul fast float %4778, %4761
  %4782 = fadd fast float %4779, 0x3FC1EB8520000000
  %4783 = fadd fast float %4780, 0x3FC1EB8520000000
  %4784 = fadd fast float %4781, 0x3FC1EB8520000000
  %4785 = fdiv fast float %4770, %4782
  %4786 = fdiv fast float %4771, %4783
  %4787 = fdiv fast float %4772, %4784
  br label %4788

; <label>:4788                                    ; preds = %4763, %4749
  %4789 = phi float [ %4785, %4763 ], [ %4759, %4749 ]
  %4790 = phi float [ %4786, %4763 ], [ %4760, %4749 ]
  %4791 = phi float [ %4787, %4763 ], [ %4761, %4749 ]
  %4792 = call float @dx.op.unary.f32(i32 7, float %4789)  ; Saturate(value)
  %4793 = call float @dx.op.unary.f32(i32 7, float %4790)  ; Saturate(value)
  %4794 = call float @dx.op.unary.f32(i32 7, float %4791)  ; Saturate(value)
  %4795 = call float @dx.op.dot3.f32(i32 55, float %4792, float %4793, float %4794, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4796 = fsub fast float %4792, %4795
  %4797 = fsub fast float %4793, %4795
  %4798 = fsub fast float %4794, %4795
  %4799 = fmul fast float %4796, %9
  %4800 = fmul fast float %4797, %9
  %4801 = fmul fast float %4798, %9
  %4802 = fadd fast float %4799, %4795
  %4803 = fadd fast float %4800, %4795
  %4804 = fadd fast float %4801, %4795
  %4805 = call float @dx.op.unary.f32(i32 7, float %4802)  ; Saturate(value)
  %4806 = call float @dx.op.unary.f32(i32 7, float %4803)  ; Saturate(value)
  %4807 = call float @dx.op.unary.f32(i32 7, float %4804)  ; Saturate(value)
  %4808 = fadd fast float %4805, 0xBFC70A3D80000000
  %4809 = fadd fast float %4806, 0xBFC70A3D80000000
  %4810 = fadd fast float %4807, 0xBFC70A3D80000000
  %4811 = fmul fast float %4808, %8
  %4812 = fmul fast float %4809, %8
  %4813 = fmul fast float %4810, %8
  %4814 = fadd fast float %4811, 0x3FC70A3D80000000
  %4815 = fadd fast float %4812, 0x3FC70A3D80000000
  %4816 = fadd fast float %4813, 0x3FC70A3D80000000
  %4817 = call float @dx.op.unary.f32(i32 7, float %4814)  ; Saturate(value)
  %4818 = call float @dx.op.unary.f32(i32 7, float %4815)  ; Saturate(value)
  %4819 = call float @dx.op.unary.f32(i32 7, float %4816)  ; Saturate(value)
  br label %4820

; <label>:4820                                    ; preds = %4788, %4571
  %4821 = phi float [ %4602, %4571 ], [ %4817, %4788 ]
  %4822 = phi float [ %4603, %4571 ], [ %4818, %4788 ]
  %4823 = phi float [ %4604, %4571 ], [ %4819, %4788 ]
  %4824 = add i32 %2913, 1
  %4825 = call i32 @dx.op.binary.i32(i32 37, i32 %4824, i32 0)  ; IMax(a,b)
  %4826 = call i32 @dx.op.binary.i32(i32 38, i32 %4825, i32 %61)  ; IMin(a,b)
  %4827 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4563, i32 %4826, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4828 = extractvalue %dx.types.ResRet.f32 %4827, 0
  %4829 = extractvalue %dx.types.ResRet.f32 %4827, 1
  %4830 = extractvalue %dx.types.ResRet.f32 %4827, 2
  %4831 = extractvalue %dx.types.ResRet.f32 %4827, 3
  %4832 = fcmp fast olt float %4831, 0.000000e+00
  br i1 %4832, label %4833, label %4867

; <label>:4833                                    ; preds = %4820
  %4834 = fcmp fast ogt float %4828, 0x3FA4B5DCC0000000
  %4835 = fcmp fast ogt float %4829, 0x3FA4B5DCC0000000
  %4836 = fcmp fast ogt float %4830, 0x3FA4B5DCC0000000
  %4837 = select i1 %4834, float 0.000000e+00, float 1.000000e+00
  %4838 = select i1 %4835, float 0.000000e+00, float 1.000000e+00
  %4839 = select i1 %4836, float 0.000000e+00, float 1.000000e+00
  %4840 = fmul fast float %4828, 0x3FB3D07220000000
  %4841 = fmul fast float %4829, 0x3FB3D07220000000
  %4842 = fmul fast float %4830, 0x3FB3D07220000000
  %4843 = fadd fast float %4828, 0x3FAC28F5C0000000
  %4844 = fadd fast float %4829, 0x3FAC28F5C0000000
  %4845 = fadd fast float %4830, 0x3FAC28F5C0000000
  %4846 = fmul fast float %4843, 0x3FEE54EDE0000000
  %4847 = fmul fast float %4844, 0x3FEE54EDE0000000
  %4848 = fmul fast float %4845, 0x3FEE54EDE0000000
  %4849 = call float @dx.op.unary.f32(i32 23, float %4846)  ; Log(value)
  %4850 = call float @dx.op.unary.f32(i32 23, float %4847)  ; Log(value)
  %4851 = call float @dx.op.unary.f32(i32 23, float %4848)  ; Log(value)
  %4852 = fmul fast float %4849, 0x4003333340000000
  %4853 = fmul fast float %4850, 0x4003333340000000
  %4854 = fmul fast float %4851, 0x4003333340000000
  %4855 = call float @dx.op.unary.f32(i32 21, float %4852)  ; Exp(value)
  %4856 = call float @dx.op.unary.f32(i32 21, float %4853)  ; Exp(value)
  %4857 = call float @dx.op.unary.f32(i32 21, float %4854)  ; Exp(value)
  %4858 = fsub fast float %4840, %4855
  %4859 = fsub fast float %4841, %4856
  %4860 = fsub fast float %4842, %4857
  %4861 = fmul fast float %4858, %4837
  %4862 = fmul fast float %4859, %4838
  %4863 = fmul fast float %4860, %4839
  %4864 = fadd fast float %4861, %4855
  %4865 = fadd fast float %4862, %4856
  %4866 = fadd fast float %4863, %4857
  br label %5082

; <label>:4867                                    ; preds = %4820
  %4868 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4563, i32 %4826, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4869 = extractvalue %dx.types.ResRet.f32 %4868, 0
  %4870 = fcmp fast ogt float %39, 5.000000e-01
  %4871 = fcmp fast olt float %4869, 1.000000e+00
  %4872 = and i1 %4870, %4871
  br i1 %4872, label %4873, label %5011

; <label>:4873                                    ; preds = %4867
  %4874 = sitofp i32 %4563 to float
  %4875 = sitofp i32 %4826 to float
  %4876 = fadd fast float %4874, 5.000000e-01
  %4877 = fadd fast float %4875, 5.000000e-01
  %4878 = fdiv fast float %4876, %46
  %4879 = fdiv fast float %4877, %47
  %4880 = fmul fast float %4878, 2.000000e+00
  %4881 = fmul fast float %4879, 2.000000e+00
  %4882 = fadd fast float %4880, -1.000000e+00
  %4883 = fsub fast float 1.000000e+00, %4881
  %4884 = fmul fast float %4882, %36
  %4885 = call float @dx.op.tertiary.f32(i32 46, float %4883, float %32, float %4884)  ; FMad(a,b,c)
  %4886 = call float @dx.op.tertiary.f32(i32 46, float %4869, float %28, float %4885)  ; FMad(a,b,c)
  %4887 = fadd fast float %4886, %24
  %4888 = call float @dx.op.unary.f32(i32 6, float %4887)  ; FAbs(value)
  %4889 = fcmp fast ogt float %4888, 0x3EB0C6F7A0000000
  br i1 %4889, label %4890, label %5011

; <label>:4890                                    ; preds = %4873
  %4891 = fmul fast float %4882, %35
  %4892 = call float @dx.op.tertiary.f32(i32 46, float %4883, float %31, float %4891)  ; FMad(a,b,c)
  %4893 = call float @dx.op.tertiary.f32(i32 46, float %4869, float %27, float %4892)  ; FMad(a,b,c)
  %4894 = fadd fast float %4893, %23
  %4895 = fmul fast float %4882, %34
  %4896 = call float @dx.op.tertiary.f32(i32 46, float %4883, float %30, float %4895)  ; FMad(a,b,c)
  %4897 = call float @dx.op.tertiary.f32(i32 46, float %4869, float %26, float %4896)  ; FMad(a,b,c)
  %4898 = fadd fast float %4897, %22
  %4899 = fmul fast float %4882, %33
  %4900 = call float @dx.op.tertiary.f32(i32 46, float %4883, float %29, float %4899)  ; FMad(a,b,c)
  %4901 = call float @dx.op.tertiary.f32(i32 46, float %4869, float %25, float %4900)  ; FMad(a,b,c)
  %4902 = fadd fast float %4901, %21
  %4903 = fdiv fast float %4902, %4887
  %4904 = fdiv fast float %4898, %4887
  %4905 = fdiv fast float %4894, %4887
  %4906 = fsub fast float %4903, %18
  %4907 = fsub fast float %4904, %19
  %4908 = fsub fast float %4905, %20
  %4909 = fmul fast float %4906, %4906
  %4910 = fmul fast float %4907, %4907
  %4911 = fadd fast float %4910, %4909
  %4912 = fmul fast float %4908, %4908
  %4913 = fadd fast float %4911, %4912
  %4914 = call float @dx.op.unary.f32(i32 24, float %4913)  ; Sqrt(value)
  %4915 = fsub fast float %4914, %10
  %4916 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4915)  ; FMax(a,b)
  %4917 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %4917, label %4918, label %4941

; <label>:4918                                    ; preds = %4890
  %4919 = call float @dx.op.unary.f32(i32 6, float %4907)  ; FAbs(value)
  %4920 = fmul fast float %4919, %12
  %4921 = fcmp fast olt float %4920, 0x3F50624DE0000000
  br i1 %4921, label %4922, label %4925

; <label>:4922                                    ; preds = %4918
  %4923 = fmul fast float %4920, 5.000000e-01
  %4924 = fsub fast float 1.000000e+00, %4923
  br label %4930

; <label>:4925                                    ; preds = %4918
  %4926 = fmul fast float %4920, 0xBFF7154760000000
  %4927 = call float @dx.op.unary.f32(i32 21, float %4926)  ; Exp(value)
  %4928 = fsub fast float 1.000000e+00, %4927
  %4929 = fdiv fast float %4928, %4920
  br label %4930

; <label>:4930                                    ; preds = %4925, %4922
  %4931 = phi float [ %4924, %4922 ], [ %4929, %4925 ]
  %4932 = call float @dx.op.binary.f32(i32 36, float %4904, float %19)  ; FMin(a,b)
  %4933 = fsub fast float %4932, %11
  %4934 = fmul fast float %12, %4933
  %4935 = fsub fast float -0.000000e+00, %4934
  %4936 = call float @dx.op.binary.f32(i32 35, float %4935, float -4.000000e+01)  ; FMax(a,b)
  %4937 = call float @dx.op.binary.f32(i32 36, float %4936, float 5.000000e+00)  ; FMin(a,b)
  %4938 = fmul fast float %4937, 0x3FF7154760000000
  %4939 = call float @dx.op.unary.f32(i32 21, float %4938)  ; Exp(value)
  %4940 = fmul fast float %4939, %4931
  br label %4941

; <label>:4941                                    ; preds = %4930, %4890
  %4942 = phi float [ %4940, %4930 ], [ 1.000000e+00, %4890 ]
  %4943 = fmul fast float %4916, %17
  %4944 = fmul fast float %4943, %4942
  %4945 = fcmp fast ole float %4914, %10
  %4946 = fcmp fast olt float %4914, 0x3F1A36E2E0000000
  %4947 = or i1 %4945, %4946
  br i1 %4947, label %4994, label %4948

; <label>:4948                                    ; preds = %4941
  %4949 = fdiv fast float %10, %4914
  %4950 = fmul fast float %4949, %4906
  %4951 = fmul fast float %4949, %4907
  %4952 = fmul fast float %4949, %4908
  %4953 = fadd fast float %4950, %18
  %4954 = fadd fast float %4951, %19
  %4955 = fadd fast float %4952, %20
  %4956 = fadd fast float %4953, -9.000000e+02
  %4957 = fadd fast float %4954, -1.500000e+01
  %4958 = fadd fast float %4955, -7.500000e+02
  %4959 = fmul fast float %4956, 0x3F62345680000000
  %4960 = fmul fast float %4957, 0x3F62345680000000
  %4961 = fmul fast float %4958, 0x3F62345680000000
  %4962 = call float @dx.op.dot3.f32(i32 55, float %4959, float %4960, float %4961, float %4959, float %4960, float %4961)  ; Dot3(ax,ay,az,bx,by,bz)
  %4963 = fsub fast float 1.000000e+00, %4962
  %4964 = call float @dx.op.unary.f32(i32 7, float %4963)  ; Saturate(value)
  %4965 = fmul fast float %4964, %4964
  %4966 = fadd fast float %4953, %4903
  %4967 = fadd fast float %4954, %4904
  %4968 = fadd fast float %4955, %4905
  %4969 = fmul fast float %4966, 0x3F52345680000000
  %4970 = fadd fast float %4969, -2.000000e+00
  %4971 = fmul fast float %4967, 0x3F52345680000000
  %4972 = fadd fast float %4971, 0xBFA1111120000000
  %4973 = fmul fast float %4968, 0x3F52345680000000
  %4974 = fadd fast float %4973, 0xBFFAAAAAC0000000
  %4975 = call float @dx.op.dot3.f32(i32 55, float %4970, float %4972, float %4974, float %4970, float %4972, float %4974)  ; Dot3(ax,ay,az,bx,by,bz)
  %4976 = fsub fast float 1.000000e+00, %4975
  %4977 = call float @dx.op.unary.f32(i32 7, float %4976)  ; Saturate(value)
  %4978 = fmul fast float %4977, %4977
  %4979 = fmul fast float %4978, 4.000000e+00
  %4980 = fadd fast float %4979, %4965
  %4981 = fadd fast float %4903, -9.000000e+02
  %4982 = fadd fast float %4904, -1.500000e+01
  %4983 = fadd fast float %4905, -7.500000e+02
  %4984 = fmul fast float %4981, 0x3F62345680000000
  %4985 = fmul fast float %4982, 0x3F62345680000000
  %4986 = fmul fast float %4983, 0x3F62345680000000
  %4987 = call float @dx.op.dot3.f32(i32 55, float %4984, float %4985, float %4986, float %4984, float %4985, float %4986)  ; Dot3(ax,ay,az,bx,by,bz)
  %4988 = fsub fast float 1.000000e+00, %4987
  %4989 = call float @dx.op.unary.f32(i32 7, float %4988)  ; Saturate(value)
  %4990 = fmul fast float %4989, %4989
  %4991 = fadd fast float %4980, %4990
  %4992 = fmul fast float %4915, 0x3F25D867E0000000
  %4993 = fmul fast float %4992, %4991
  br label %4994

; <label>:4994                                    ; preds = %4948, %4941
  %4995 = phi float [ %4993, %4948 ], [ 0.000000e+00, %4941 ]
  %4996 = fadd fast float %4995, %4944
  %4997 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4996)  ; FMin(a,b)
  %4998 = fmul fast float %4997, 0xBFF7154760000000
  %4999 = call float @dx.op.unary.f32(i32 21, float %4998)  ; Exp(value)
  %5000 = fsub fast float 1.000000e+00, %4999
  %5001 = call float @dx.op.binary.f32(i32 36, float %13, float %5000)  ; FMin(a,b)
  %5002 = fsub fast float %14, %4828
  %5003 = fsub fast float %15, %4829
  %5004 = fsub fast float %16, %4830
  %5005 = fmul fast float %5001, %5002
  %5006 = fmul fast float %5001, %5003
  %5007 = fmul fast float %5001, %5004
  %5008 = fadd fast float %5005, %4828
  %5009 = fadd fast float %5006, %4829
  %5010 = fadd fast float %5007, %4830
  br label %5011

; <label>:5011                                    ; preds = %4994, %4873, %4867
  %5012 = phi float [ %5008, %4994 ], [ %4828, %4873 ], [ %4828, %4867 ]
  %5013 = phi float [ %5009, %4994 ], [ %4829, %4873 ], [ %4829, %4867 ]
  %5014 = phi float [ %5010, %4994 ], [ %4830, %4873 ], [ %4830, %4867 ]
  %5015 = fadd fast float %6, 1.000000e+00
  %5016 = fadd fast float %7, 1.000000e+00
  %5017 = fsub fast float 1.000000e+00, %6
  %5018 = fmul fast float %37, %5015
  %5019 = fmul fast float %37, %5016
  %5020 = fmul fast float %37, %5017
  %5021 = fmul fast float %5018, %5012
  %5022 = fmul fast float %5019, %5013
  %5023 = fmul fast float %5020, %5014
  %5024 = fcmp fast ult float %38, 5.000000e-01
  br i1 %5024, label %5050, label %5025

; <label>:5025                                    ; preds = %5011
  %5026 = fmul fast float %5021, 0x4004147AE0000000
  %5027 = fmul fast float %5022, 0x4004147AE0000000
  %5028 = fmul fast float %5023, 0x4004147AE0000000
  %5029 = fadd fast float %5026, 0x3F9EB851E0000000
  %5030 = fadd fast float %5027, 0x3F9EB851E0000000
  %5031 = fadd fast float %5028, 0x3F9EB851E0000000
  %5032 = fmul fast float %5029, %5021
  %5033 = fmul fast float %5030, %5022
  %5034 = fmul fast float %5031, %5023
  %5035 = fmul fast float %5021, 0x400370A3E0000000
  %5036 = fmul fast float %5022, 0x400370A3E0000000
  %5037 = fmul fast float %5023, 0x400370A3E0000000
  %5038 = fadd fast float %5035, 0x3FE2E147A0000000
  %5039 = fadd fast float %5036, 0x3FE2E147A0000000
  %5040 = fadd fast float %5037, 0x3FE2E147A0000000
  %5041 = fmul fast float %5038, %5021
  %5042 = fmul fast float %5039, %5022
  %5043 = fmul fast float %5040, %5023
  %5044 = fadd fast float %5041, 0x3FC1EB8520000000
  %5045 = fadd fast float %5042, 0x3FC1EB8520000000
  %5046 = fadd fast float %5043, 0x3FC1EB8520000000
  %5047 = fdiv fast float %5032, %5044
  %5048 = fdiv fast float %5033, %5045
  %5049 = fdiv fast float %5034, %5046
  br label %5050

; <label>:5050                                    ; preds = %5025, %5011
  %5051 = phi float [ %5047, %5025 ], [ %5021, %5011 ]
  %5052 = phi float [ %5048, %5025 ], [ %5022, %5011 ]
  %5053 = phi float [ %5049, %5025 ], [ %5023, %5011 ]
  %5054 = call float @dx.op.unary.f32(i32 7, float %5051)  ; Saturate(value)
  %5055 = call float @dx.op.unary.f32(i32 7, float %5052)  ; Saturate(value)
  %5056 = call float @dx.op.unary.f32(i32 7, float %5053)  ; Saturate(value)
  %5057 = call float @dx.op.dot3.f32(i32 55, float %5054, float %5055, float %5056, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5058 = fsub fast float %5054, %5057
  %5059 = fsub fast float %5055, %5057
  %5060 = fsub fast float %5056, %5057
  %5061 = fmul fast float %5058, %9
  %5062 = fmul fast float %5059, %9
  %5063 = fmul fast float %5060, %9
  %5064 = fadd fast float %5061, %5057
  %5065 = fadd fast float %5062, %5057
  %5066 = fadd fast float %5063, %5057
  %5067 = call float @dx.op.unary.f32(i32 7, float %5064)  ; Saturate(value)
  %5068 = call float @dx.op.unary.f32(i32 7, float %5065)  ; Saturate(value)
  %5069 = call float @dx.op.unary.f32(i32 7, float %5066)  ; Saturate(value)
  %5070 = fadd fast float %5067, 0xBFC70A3D80000000
  %5071 = fadd fast float %5068, 0xBFC70A3D80000000
  %5072 = fadd fast float %5069, 0xBFC70A3D80000000
  %5073 = fmul fast float %5070, %8
  %5074 = fmul fast float %5071, %8
  %5075 = fmul fast float %5072, %8
  %5076 = fadd fast float %5073, 0x3FC70A3D80000000
  %5077 = fadd fast float %5074, 0x3FC70A3D80000000
  %5078 = fadd fast float %5075, 0x3FC70A3D80000000
  %5079 = call float @dx.op.unary.f32(i32 7, float %5076)  ; Saturate(value)
  %5080 = call float @dx.op.unary.f32(i32 7, float %5077)  ; Saturate(value)
  %5081 = call float @dx.op.unary.f32(i32 7, float %5078)  ; Saturate(value)
  br label %5082

; <label>:5082                                    ; preds = %5050, %4833
  %5083 = phi float [ %4864, %4833 ], [ %5079, %5050 ]
  %5084 = phi float [ %4865, %4833 ], [ %5080, %5050 ]
  %5085 = phi float [ %4866, %4833 ], [ %5081, %5050 ]
  %5086 = add i32 %1489, -1
  %5087 = call i32 @dx.op.binary.i32(i32 37, i32 %5086, i32 0)  ; IMax(a,b)
  %5088 = call i32 @dx.op.binary.i32(i32 37, i32 %2913, i32 0)  ; IMax(a,b)
  %5089 = call i32 @dx.op.binary.i32(i32 38, i32 %5087, i32 %60)  ; IMin(a,b)
  %5090 = call i32 @dx.op.binary.i32(i32 38, i32 %5088, i32 %61)  ; IMin(a,b)
  %5091 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %5089, i32 %5090, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5092 = extractvalue %dx.types.ResRet.f32 %5091, 0
  %5093 = extractvalue %dx.types.ResRet.f32 %5091, 1
  %5094 = extractvalue %dx.types.ResRet.f32 %5091, 2
  %5095 = extractvalue %dx.types.ResRet.f32 %5091, 3
  %5096 = fcmp fast olt float %5095, 0.000000e+00
  br i1 %5096, label %5097, label %5131

; <label>:5097                                    ; preds = %5082
  %5098 = fcmp fast ogt float %5092, 0x3FA4B5DCC0000000
  %5099 = fcmp fast ogt float %5093, 0x3FA4B5DCC0000000
  %5100 = fcmp fast ogt float %5094, 0x3FA4B5DCC0000000
  %5101 = select i1 %5098, float 0.000000e+00, float 1.000000e+00
  %5102 = select i1 %5099, float 0.000000e+00, float 1.000000e+00
  %5103 = select i1 %5100, float 0.000000e+00, float 1.000000e+00
  %5104 = fmul fast float %5092, 0x3FB3D07220000000
  %5105 = fmul fast float %5093, 0x3FB3D07220000000
  %5106 = fmul fast float %5094, 0x3FB3D07220000000
  %5107 = fadd fast float %5092, 0x3FAC28F5C0000000
  %5108 = fadd fast float %5093, 0x3FAC28F5C0000000
  %5109 = fadd fast float %5094, 0x3FAC28F5C0000000
  %5110 = fmul fast float %5107, 0x3FEE54EDE0000000
  %5111 = fmul fast float %5108, 0x3FEE54EDE0000000
  %5112 = fmul fast float %5109, 0x3FEE54EDE0000000
  %5113 = call float @dx.op.unary.f32(i32 23, float %5110)  ; Log(value)
  %5114 = call float @dx.op.unary.f32(i32 23, float %5111)  ; Log(value)
  %5115 = call float @dx.op.unary.f32(i32 23, float %5112)  ; Log(value)
  %5116 = fmul fast float %5113, 0x4003333340000000
  %5117 = fmul fast float %5114, 0x4003333340000000
  %5118 = fmul fast float %5115, 0x4003333340000000
  %5119 = call float @dx.op.unary.f32(i32 21, float %5116)  ; Exp(value)
  %5120 = call float @dx.op.unary.f32(i32 21, float %5117)  ; Exp(value)
  %5121 = call float @dx.op.unary.f32(i32 21, float %5118)  ; Exp(value)
  %5122 = fsub fast float %5104, %5119
  %5123 = fsub fast float %5105, %5120
  %5124 = fsub fast float %5106, %5121
  %5125 = fmul fast float %5122, %5101
  %5126 = fmul fast float %5123, %5102
  %5127 = fmul fast float %5124, %5103
  %5128 = fadd fast float %5125, %5119
  %5129 = fadd fast float %5126, %5120
  %5130 = fadd fast float %5127, %5121
  br label %5346

; <label>:5131                                    ; preds = %5082
  %5132 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5089, i32 %5090, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5133 = extractvalue %dx.types.ResRet.f32 %5132, 0
  %5134 = fcmp fast ogt float %39, 5.000000e-01
  %5135 = fcmp fast olt float %5133, 1.000000e+00
  %5136 = and i1 %5134, %5135
  br i1 %5136, label %5137, label %5275

; <label>:5137                                    ; preds = %5131
  %5138 = sitofp i32 %5089 to float
  %5139 = sitofp i32 %5090 to float
  %5140 = fadd fast float %5138, 5.000000e-01
  %5141 = fadd fast float %5139, 5.000000e-01
  %5142 = fdiv fast float %5140, %46
  %5143 = fdiv fast float %5141, %47
  %5144 = fmul fast float %5142, 2.000000e+00
  %5145 = fmul fast float %5143, 2.000000e+00
  %5146 = fadd fast float %5144, -1.000000e+00
  %5147 = fsub fast float 1.000000e+00, %5145
  %5148 = fmul fast float %5146, %36
  %5149 = call float @dx.op.tertiary.f32(i32 46, float %5147, float %32, float %5148)  ; FMad(a,b,c)
  %5150 = call float @dx.op.tertiary.f32(i32 46, float %5133, float %28, float %5149)  ; FMad(a,b,c)
  %5151 = fadd fast float %5150, %24
  %5152 = call float @dx.op.unary.f32(i32 6, float %5151)  ; FAbs(value)
  %5153 = fcmp fast ogt float %5152, 0x3EB0C6F7A0000000
  br i1 %5153, label %5154, label %5275

; <label>:5154                                    ; preds = %5137
  %5155 = fmul fast float %5146, %35
  %5156 = call float @dx.op.tertiary.f32(i32 46, float %5147, float %31, float %5155)  ; FMad(a,b,c)
  %5157 = call float @dx.op.tertiary.f32(i32 46, float %5133, float %27, float %5156)  ; FMad(a,b,c)
  %5158 = fadd fast float %5157, %23
  %5159 = fmul fast float %5146, %34
  %5160 = call float @dx.op.tertiary.f32(i32 46, float %5147, float %30, float %5159)  ; FMad(a,b,c)
  %5161 = call float @dx.op.tertiary.f32(i32 46, float %5133, float %26, float %5160)  ; FMad(a,b,c)
  %5162 = fadd fast float %5161, %22
  %5163 = fmul fast float %5146, %33
  %5164 = call float @dx.op.tertiary.f32(i32 46, float %5147, float %29, float %5163)  ; FMad(a,b,c)
  %5165 = call float @dx.op.tertiary.f32(i32 46, float %5133, float %25, float %5164)  ; FMad(a,b,c)
  %5166 = fadd fast float %5165, %21
  %5167 = fdiv fast float %5166, %5151
  %5168 = fdiv fast float %5162, %5151
  %5169 = fdiv fast float %5158, %5151
  %5170 = fsub fast float %5167, %18
  %5171 = fsub fast float %5168, %19
  %5172 = fsub fast float %5169, %20
  %5173 = fmul fast float %5170, %5170
  %5174 = fmul fast float %5171, %5171
  %5175 = fadd fast float %5174, %5173
  %5176 = fmul fast float %5172, %5172
  %5177 = fadd fast float %5175, %5176
  %5178 = call float @dx.op.unary.f32(i32 24, float %5177)  ; Sqrt(value)
  %5179 = fsub fast float %5178, %10
  %5180 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5179)  ; FMax(a,b)
  %5181 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %5181, label %5182, label %5205

; <label>:5182                                    ; preds = %5154
  %5183 = call float @dx.op.unary.f32(i32 6, float %5171)  ; FAbs(value)
  %5184 = fmul fast float %5183, %12
  %5185 = fcmp fast olt float %5184, 0x3F50624DE0000000
  br i1 %5185, label %5186, label %5189

; <label>:5186                                    ; preds = %5182
  %5187 = fmul fast float %5184, 5.000000e-01
  %5188 = fsub fast float 1.000000e+00, %5187
  br label %5194

; <label>:5189                                    ; preds = %5182
  %5190 = fmul fast float %5184, 0xBFF7154760000000
  %5191 = call float @dx.op.unary.f32(i32 21, float %5190)  ; Exp(value)
  %5192 = fsub fast float 1.000000e+00, %5191
  %5193 = fdiv fast float %5192, %5184
  br label %5194

; <label>:5194                                    ; preds = %5189, %5186
  %5195 = phi float [ %5188, %5186 ], [ %5193, %5189 ]
  %5196 = call float @dx.op.binary.f32(i32 36, float %5168, float %19)  ; FMin(a,b)
  %5197 = fsub fast float %5196, %11
  %5198 = fmul fast float %12, %5197
  %5199 = fsub fast float -0.000000e+00, %5198
  %5200 = call float @dx.op.binary.f32(i32 35, float %5199, float -4.000000e+01)  ; FMax(a,b)
  %5201 = call float @dx.op.binary.f32(i32 36, float %5200, float 5.000000e+00)  ; FMin(a,b)
  %5202 = fmul fast float %5201, 0x3FF7154760000000
  %5203 = call float @dx.op.unary.f32(i32 21, float %5202)  ; Exp(value)
  %5204 = fmul fast float %5203, %5195
  br label %5205

; <label>:5205                                    ; preds = %5194, %5154
  %5206 = phi float [ %5204, %5194 ], [ 1.000000e+00, %5154 ]
  %5207 = fmul fast float %5180, %17
  %5208 = fmul fast float %5207, %5206
  %5209 = fcmp fast ole float %5178, %10
  %5210 = fcmp fast olt float %5178, 0x3F1A36E2E0000000
  %5211 = or i1 %5209, %5210
  br i1 %5211, label %5258, label %5212

; <label>:5212                                    ; preds = %5205
  %5213 = fdiv fast float %10, %5178
  %5214 = fmul fast float %5213, %5170
  %5215 = fmul fast float %5213, %5171
  %5216 = fmul fast float %5213, %5172
  %5217 = fadd fast float %5214, %18
  %5218 = fadd fast float %5215, %19
  %5219 = fadd fast float %5216, %20
  %5220 = fadd fast float %5217, -9.000000e+02
  %5221 = fadd fast float %5218, -1.500000e+01
  %5222 = fadd fast float %5219, -7.500000e+02
  %5223 = fmul fast float %5220, 0x3F62345680000000
  %5224 = fmul fast float %5221, 0x3F62345680000000
  %5225 = fmul fast float %5222, 0x3F62345680000000
  %5226 = call float @dx.op.dot3.f32(i32 55, float %5223, float %5224, float %5225, float %5223, float %5224, float %5225)  ; Dot3(ax,ay,az,bx,by,bz)
  %5227 = fsub fast float 1.000000e+00, %5226
  %5228 = call float @dx.op.unary.f32(i32 7, float %5227)  ; Saturate(value)
  %5229 = fmul fast float %5228, %5228
  %5230 = fadd fast float %5217, %5167
  %5231 = fadd fast float %5218, %5168
  %5232 = fadd fast float %5219, %5169
  %5233 = fmul fast float %5230, 0x3F52345680000000
  %5234 = fadd fast float %5233, -2.000000e+00
  %5235 = fmul fast float %5231, 0x3F52345680000000
  %5236 = fadd fast float %5235, 0xBFA1111120000000
  %5237 = fmul fast float %5232, 0x3F52345680000000
  %5238 = fadd fast float %5237, 0xBFFAAAAAC0000000
  %5239 = call float @dx.op.dot3.f32(i32 55, float %5234, float %5236, float %5238, float %5234, float %5236, float %5238)  ; Dot3(ax,ay,az,bx,by,bz)
  %5240 = fsub fast float 1.000000e+00, %5239
  %5241 = call float @dx.op.unary.f32(i32 7, float %5240)  ; Saturate(value)
  %5242 = fmul fast float %5241, %5241
  %5243 = fmul fast float %5242, 4.000000e+00
  %5244 = fadd fast float %5243, %5229
  %5245 = fadd fast float %5167, -9.000000e+02
  %5246 = fadd fast float %5168, -1.500000e+01
  %5247 = fadd fast float %5169, -7.500000e+02
  %5248 = fmul fast float %5245, 0x3F62345680000000
  %5249 = fmul fast float %5246, 0x3F62345680000000
  %5250 = fmul fast float %5247, 0x3F62345680000000
  %5251 = call float @dx.op.dot3.f32(i32 55, float %5248, float %5249, float %5250, float %5248, float %5249, float %5250)  ; Dot3(ax,ay,az,bx,by,bz)
  %5252 = fsub fast float 1.000000e+00, %5251
  %5253 = call float @dx.op.unary.f32(i32 7, float %5252)  ; Saturate(value)
  %5254 = fmul fast float %5253, %5253
  %5255 = fadd fast float %5244, %5254
  %5256 = fmul fast float %5179, 0x3F25D867E0000000
  %5257 = fmul fast float %5256, %5255
  br label %5258

; <label>:5258                                    ; preds = %5212, %5205
  %5259 = phi float [ %5257, %5212 ], [ 0.000000e+00, %5205 ]
  %5260 = fadd fast float %5259, %5208
  %5261 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %5260)  ; FMin(a,b)
  %5262 = fmul fast float %5261, 0xBFF7154760000000
  %5263 = call float @dx.op.unary.f32(i32 21, float %5262)  ; Exp(value)
  %5264 = fsub fast float 1.000000e+00, %5263
  %5265 = call float @dx.op.binary.f32(i32 36, float %13, float %5264)  ; FMin(a,b)
  %5266 = fsub fast float %14, %5092
  %5267 = fsub fast float %15, %5093
  %5268 = fsub fast float %16, %5094
  %5269 = fmul fast float %5265, %5266
  %5270 = fmul fast float %5265, %5267
  %5271 = fmul fast float %5265, %5268
  %5272 = fadd fast float %5269, %5092
  %5273 = fadd fast float %5270, %5093
  %5274 = fadd fast float %5271, %5094
  br label %5275

; <label>:5275                                    ; preds = %5258, %5137, %5131
  %5276 = phi float [ %5272, %5258 ], [ %5092, %5137 ], [ %5092, %5131 ]
  %5277 = phi float [ %5273, %5258 ], [ %5093, %5137 ], [ %5093, %5131 ]
  %5278 = phi float [ %5274, %5258 ], [ %5094, %5137 ], [ %5094, %5131 ]
  %5279 = fadd fast float %6, 1.000000e+00
  %5280 = fadd fast float %7, 1.000000e+00
  %5281 = fsub fast float 1.000000e+00, %6
  %5282 = fmul fast float %37, %5279
  %5283 = fmul fast float %37, %5280
  %5284 = fmul fast float %37, %5281
  %5285 = fmul fast float %5282, %5276
  %5286 = fmul fast float %5283, %5277
  %5287 = fmul fast float %5284, %5278
  %5288 = fcmp fast ult float %38, 5.000000e-01
  br i1 %5288, label %5314, label %5289

; <label>:5289                                    ; preds = %5275
  %5290 = fmul fast float %5285, 0x4004147AE0000000
  %5291 = fmul fast float %5286, 0x4004147AE0000000
  %5292 = fmul fast float %5287, 0x4004147AE0000000
  %5293 = fadd fast float %5290, 0x3F9EB851E0000000
  %5294 = fadd fast float %5291, 0x3F9EB851E0000000
  %5295 = fadd fast float %5292, 0x3F9EB851E0000000
  %5296 = fmul fast float %5293, %5285
  %5297 = fmul fast float %5294, %5286
  %5298 = fmul fast float %5295, %5287
  %5299 = fmul fast float %5285, 0x400370A3E0000000
  %5300 = fmul fast float %5286, 0x400370A3E0000000
  %5301 = fmul fast float %5287, 0x400370A3E0000000
  %5302 = fadd fast float %5299, 0x3FE2E147A0000000
  %5303 = fadd fast float %5300, 0x3FE2E147A0000000
  %5304 = fadd fast float %5301, 0x3FE2E147A0000000
  %5305 = fmul fast float %5302, %5285
  %5306 = fmul fast float %5303, %5286
  %5307 = fmul fast float %5304, %5287
  %5308 = fadd fast float %5305, 0x3FC1EB8520000000
  %5309 = fadd fast float %5306, 0x3FC1EB8520000000
  %5310 = fadd fast float %5307, 0x3FC1EB8520000000
  %5311 = fdiv fast float %5296, %5308
  %5312 = fdiv fast float %5297, %5309
  %5313 = fdiv fast float %5298, %5310
  br label %5314

; <label>:5314                                    ; preds = %5289, %5275
  %5315 = phi float [ %5311, %5289 ], [ %5285, %5275 ]
  %5316 = phi float [ %5312, %5289 ], [ %5286, %5275 ]
  %5317 = phi float [ %5313, %5289 ], [ %5287, %5275 ]
  %5318 = call float @dx.op.unary.f32(i32 7, float %5315)  ; Saturate(value)
  %5319 = call float @dx.op.unary.f32(i32 7, float %5316)  ; Saturate(value)
  %5320 = call float @dx.op.unary.f32(i32 7, float %5317)  ; Saturate(value)
  %5321 = call float @dx.op.dot3.f32(i32 55, float %5318, float %5319, float %5320, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5322 = fsub fast float %5318, %5321
  %5323 = fsub fast float %5319, %5321
  %5324 = fsub fast float %5320, %5321
  %5325 = fmul fast float %5322, %9
  %5326 = fmul fast float %5323, %9
  %5327 = fmul fast float %5324, %9
  %5328 = fadd fast float %5325, %5321
  %5329 = fadd fast float %5326, %5321
  %5330 = fadd fast float %5327, %5321
  %5331 = call float @dx.op.unary.f32(i32 7, float %5328)  ; Saturate(value)
  %5332 = call float @dx.op.unary.f32(i32 7, float %5329)  ; Saturate(value)
  %5333 = call float @dx.op.unary.f32(i32 7, float %5330)  ; Saturate(value)
  %5334 = fadd fast float %5331, 0xBFC70A3D80000000
  %5335 = fadd fast float %5332, 0xBFC70A3D80000000
  %5336 = fadd fast float %5333, 0xBFC70A3D80000000
  %5337 = fmul fast float %5334, %8
  %5338 = fmul fast float %5335, %8
  %5339 = fmul fast float %5336, %8
  %5340 = fadd fast float %5337, 0x3FC70A3D80000000
  %5341 = fadd fast float %5338, 0x3FC70A3D80000000
  %5342 = fadd fast float %5339, 0x3FC70A3D80000000
  %5343 = call float @dx.op.unary.f32(i32 7, float %5340)  ; Saturate(value)
  %5344 = call float @dx.op.unary.f32(i32 7, float %5341)  ; Saturate(value)
  %5345 = call float @dx.op.unary.f32(i32 7, float %5342)  ; Saturate(value)
  br label %5346

; <label>:5346                                    ; preds = %5314, %5097
  %5347 = phi float [ %5128, %5097 ], [ %5343, %5314 ]
  %5348 = phi float [ %5129, %5097 ], [ %5344, %5314 ]
  %5349 = phi float [ %5130, %5097 ], [ %5345, %5314 ]
  %5350 = add i32 %1489, 1
  %5351 = call i32 @dx.op.binary.i32(i32 37, i32 %5350, i32 0)  ; IMax(a,b)
  %5352 = call i32 @dx.op.binary.i32(i32 38, i32 %5351, i32 %60)  ; IMin(a,b)
  %5353 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %5352, i32 %5090, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5354 = extractvalue %dx.types.ResRet.f32 %5353, 0
  %5355 = extractvalue %dx.types.ResRet.f32 %5353, 1
  %5356 = extractvalue %dx.types.ResRet.f32 %5353, 2
  %5357 = extractvalue %dx.types.ResRet.f32 %5353, 3
  %5358 = fcmp fast olt float %5357, 0.000000e+00
  br i1 %5358, label %5359, label %5393

; <label>:5359                                    ; preds = %5346
  %5360 = fcmp fast ogt float %5354, 0x3FA4B5DCC0000000
  %5361 = fcmp fast ogt float %5355, 0x3FA4B5DCC0000000
  %5362 = fcmp fast ogt float %5356, 0x3FA4B5DCC0000000
  %5363 = select i1 %5360, float 0.000000e+00, float 1.000000e+00
  %5364 = select i1 %5361, float 0.000000e+00, float 1.000000e+00
  %5365 = select i1 %5362, float 0.000000e+00, float 1.000000e+00
  %5366 = fmul fast float %5354, 0x3FB3D07220000000
  %5367 = fmul fast float %5355, 0x3FB3D07220000000
  %5368 = fmul fast float %5356, 0x3FB3D07220000000
  %5369 = fadd fast float %5354, 0x3FAC28F5C0000000
  %5370 = fadd fast float %5355, 0x3FAC28F5C0000000
  %5371 = fadd fast float %5356, 0x3FAC28F5C0000000
  %5372 = fmul fast float %5369, 0x3FEE54EDE0000000
  %5373 = fmul fast float %5370, 0x3FEE54EDE0000000
  %5374 = fmul fast float %5371, 0x3FEE54EDE0000000
  %5375 = call float @dx.op.unary.f32(i32 23, float %5372)  ; Log(value)
  %5376 = call float @dx.op.unary.f32(i32 23, float %5373)  ; Log(value)
  %5377 = call float @dx.op.unary.f32(i32 23, float %5374)  ; Log(value)
  %5378 = fmul fast float %5375, 0x4003333340000000
  %5379 = fmul fast float %5376, 0x4003333340000000
  %5380 = fmul fast float %5377, 0x4003333340000000
  %5381 = call float @dx.op.unary.f32(i32 21, float %5378)  ; Exp(value)
  %5382 = call float @dx.op.unary.f32(i32 21, float %5379)  ; Exp(value)
  %5383 = call float @dx.op.unary.f32(i32 21, float %5380)  ; Exp(value)
  %5384 = fsub fast float %5366, %5381
  %5385 = fsub fast float %5367, %5382
  %5386 = fsub fast float %5368, %5383
  %5387 = fmul fast float %5384, %5363
  %5388 = fmul fast float %5385, %5364
  %5389 = fmul fast float %5386, %5365
  %5390 = fadd fast float %5387, %5381
  %5391 = fadd fast float %5388, %5382
  %5392 = fadd fast float %5389, %5383
  br label %5608

; <label>:5393                                    ; preds = %5346
  %5394 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5352, i32 %5090, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5395 = extractvalue %dx.types.ResRet.f32 %5394, 0
  %5396 = fcmp fast ogt float %39, 5.000000e-01
  %5397 = fcmp fast olt float %5395, 1.000000e+00
  %5398 = and i1 %5396, %5397
  br i1 %5398, label %5399, label %5537

; <label>:5399                                    ; preds = %5393
  %5400 = sitofp i32 %5352 to float
  %5401 = sitofp i32 %5090 to float
  %5402 = fadd fast float %5400, 5.000000e-01
  %5403 = fadd fast float %5401, 5.000000e-01
  %5404 = fdiv fast float %5402, %46
  %5405 = fdiv fast float %5403, %47
  %5406 = fmul fast float %5404, 2.000000e+00
  %5407 = fmul fast float %5405, 2.000000e+00
  %5408 = fadd fast float %5406, -1.000000e+00
  %5409 = fsub fast float 1.000000e+00, %5407
  %5410 = fmul fast float %5408, %36
  %5411 = call float @dx.op.tertiary.f32(i32 46, float %5409, float %32, float %5410)  ; FMad(a,b,c)
  %5412 = call float @dx.op.tertiary.f32(i32 46, float %5395, float %28, float %5411)  ; FMad(a,b,c)
  %5413 = fadd fast float %5412, %24
  %5414 = call float @dx.op.unary.f32(i32 6, float %5413)  ; FAbs(value)
  %5415 = fcmp fast ogt float %5414, 0x3EB0C6F7A0000000
  br i1 %5415, label %5416, label %5537

; <label>:5416                                    ; preds = %5399
  %5417 = fmul fast float %5408, %35
  %5418 = call float @dx.op.tertiary.f32(i32 46, float %5409, float %31, float %5417)  ; FMad(a,b,c)
  %5419 = call float @dx.op.tertiary.f32(i32 46, float %5395, float %27, float %5418)  ; FMad(a,b,c)
  %5420 = fadd fast float %5419, %23
  %5421 = fmul fast float %5408, %34
  %5422 = call float @dx.op.tertiary.f32(i32 46, float %5409, float %30, float %5421)  ; FMad(a,b,c)
  %5423 = call float @dx.op.tertiary.f32(i32 46, float %5395, float %26, float %5422)  ; FMad(a,b,c)
  %5424 = fadd fast float %5423, %22
  %5425 = fmul fast float %5408, %33
  %5426 = call float @dx.op.tertiary.f32(i32 46, float %5409, float %29, float %5425)  ; FMad(a,b,c)
  %5427 = call float @dx.op.tertiary.f32(i32 46, float %5395, float %25, float %5426)  ; FMad(a,b,c)
  %5428 = fadd fast float %5427, %21
  %5429 = fdiv fast float %5428, %5413
  %5430 = fdiv fast float %5424, %5413
  %5431 = fdiv fast float %5420, %5413
  %5432 = fsub fast float %5429, %18
  %5433 = fsub fast float %5430, %19
  %5434 = fsub fast float %5431, %20
  %5435 = fmul fast float %5432, %5432
  %5436 = fmul fast float %5433, %5433
  %5437 = fadd fast float %5436, %5435
  %5438 = fmul fast float %5434, %5434
  %5439 = fadd fast float %5437, %5438
  %5440 = call float @dx.op.unary.f32(i32 24, float %5439)  ; Sqrt(value)
  %5441 = fsub fast float %5440, %10
  %5442 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5441)  ; FMax(a,b)
  %5443 = fcmp fast ogt float %40, 1.500000e+00
  br i1 %5443, label %5444, label %5467

; <label>:5444                                    ; preds = %5416
  %5445 = call float @dx.op.unary.f32(i32 6, float %5433)  ; FAbs(value)
  %5446 = fmul fast float %5445, %12
  %5447 = fcmp fast olt float %5446, 0x3F50624DE0000000
  br i1 %5447, label %5448, label %5451

; <label>:5448                                    ; preds = %5444
  %5449 = fmul fast float %5446, 5.000000e-01
  %5450 = fsub fast float 1.000000e+00, %5449
  br label %5456

; <label>:5451                                    ; preds = %5444
  %5452 = fmul fast float %5446, 0xBFF7154760000000
  %5453 = call float @dx.op.unary.f32(i32 21, float %5452)  ; Exp(value)
  %5454 = fsub fast float 1.000000e+00, %5453
  %5455 = fdiv fast float %5454, %5446
  br label %5456

; <label>:5456                                    ; preds = %5451, %5448
  %5457 = phi float [ %5450, %5448 ], [ %5455, %5451 ]
  %5458 = call float @dx.op.binary.f32(i32 36, float %5430, float %19)  ; FMin(a,b)
  %5459 = fsub fast float %5458, %11
  %5460 = fmul fast float %12, %5459
  %5461 = fsub fast float -0.000000e+00, %5460
  %5462 = call float @dx.op.binary.f32(i32 35, float %5461, float -4.000000e+01)  ; FMax(a,b)
  %5463 = call float @dx.op.binary.f32(i32 36, float %5462, float 5.000000e+00)  ; FMin(a,b)
  %5464 = fmul fast float %5463, 0x3FF7154760000000
  %5465 = call float @dx.op.unary.f32(i32 21, float %5464)  ; Exp(value)
  %5466 = fmul fast float %5465, %5457
  br label %5467

; <label>:5467                                    ; preds = %5456, %5416
  %5468 = phi float [ %5466, %5456 ], [ 1.000000e+00, %5416 ]
  %5469 = fmul fast float %5442, %17
  %5470 = fmul fast float %5469, %5468
  %5471 = fcmp fast ole float %5440, %10
  %5472 = fcmp fast olt float %5440, 0x3F1A36E2E0000000
  %5473 = or i1 %5471, %5472
  br i1 %5473, label %5520, label %5474

; <label>:5474                                    ; preds = %5467
  %5475 = fdiv fast float %10, %5440
  %5476 = fmul fast float %5475, %5432
  %5477 = fmul fast float %5475, %5433
  %5478 = fmul fast float %5475, %5434
  %5479 = fadd fast float %5476, %18
  %5480 = fadd fast float %5477, %19
  %5481 = fadd fast float %5478, %20
  %5482 = fadd fast float %5479, -9.000000e+02
  %5483 = fadd fast float %5480, -1.500000e+01
  %5484 = fadd fast float %5481, -7.500000e+02
  %5485 = fmul fast float %5482, 0x3F62345680000000
  %5486 = fmul fast float %5483, 0x3F62345680000000
  %5487 = fmul fast float %5484, 0x3F62345680000000
  %5488 = call float @dx.op.dot3.f32(i32 55, float %5485, float %5486, float %5487, float %5485, float %5486, float %5487)  ; Dot3(ax,ay,az,bx,by,bz)
  %5489 = fsub fast float 1.000000e+00, %5488
  %5490 = call float @dx.op.unary.f32(i32 7, float %5489)  ; Saturate(value)
  %5491 = fmul fast float %5490, %5490
  %5492 = fadd fast float %5479, %5429
  %5493 = fadd fast float %5480, %5430
  %5494 = fadd fast float %5481, %5431
  %5495 = fmul fast float %5492, 0x3F52345680000000
  %5496 = fadd fast float %5495, -2.000000e+00
  %5497 = fmul fast float %5493, 0x3F52345680000000
  %5498 = fadd fast float %5497, 0xBFA1111120000000
  %5499 = fmul fast float %5494, 0x3F52345680000000
  %5500 = fadd fast float %5499, 0xBFFAAAAAC0000000
  %5501 = call float @dx.op.dot3.f32(i32 55, float %5496, float %5498, float %5500, float %5496, float %5498, float %5500)  ; Dot3(ax,ay,az,bx,by,bz)
  %5502 = fsub fast float 1.000000e+00, %5501
  %5503 = call float @dx.op.unary.f32(i32 7, float %5502)  ; Saturate(value)
  %5504 = fmul fast float %5503, %5503
  %5505 = fmul fast float %5504, 4.000000e+00
  %5506 = fadd fast float %5505, %5491
  %5507 = fadd fast float %5429, -9.000000e+02
  %5508 = fadd fast float %5430, -1.500000e+01
  %5509 = fadd fast float %5431, -7.500000e+02
  %5510 = fmul fast float %5507, 0x3F62345680000000
  %5511 = fmul fast float %5508, 0x3F62345680000000
  %5512 = fmul fast float %5509, 0x3F62345680000000
  %5513 = call float @dx.op.dot3.f32(i32 55, float %5510, float %5511, float %5512, float %5510, float %5511, float %5512)  ; Dot3(ax,ay,az,bx,by,bz)
  %5514 = fsub fast float 1.000000e+00, %5513
  %5515 = call float @dx.op.unary.f32(i32 7, float %5514)  ; Saturate(value)
  %5516 = fmul fast float %5515, %5515
  %5517 = fadd fast float %5506, %5516
  %5518 = fmul fast float %5441, 0x3F25D867E0000000
  %5519 = fmul fast float %5518, %5517
  br label %5520

; <label>:5520                                    ; preds = %5474, %5467
  %5521 = phi float [ %5519, %5474 ], [ 0.000000e+00, %5467 ]
  %5522 = fadd fast float %5521, %5470
  %5523 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %5522)  ; FMin(a,b)
  %5524 = fmul fast float %5523, 0xBFF7154760000000
  %5525 = call float @dx.op.unary.f32(i32 21, float %5524)  ; Exp(value)
  %5526 = fsub fast float 1.000000e+00, %5525
  %5527 = call float @dx.op.binary.f32(i32 36, float %13, float %5526)  ; FMin(a,b)
  %5528 = fsub fast float %14, %5354
  %5529 = fsub fast float %15, %5355
  %5530 = fsub fast float %16, %5356
  %5531 = fmul fast float %5527, %5528
  %5532 = fmul fast float %5527, %5529
  %5533 = fmul fast float %5527, %5530
  %5534 = fadd fast float %5531, %5354
  %5535 = fadd fast float %5532, %5355
  %5536 = fadd fast float %5533, %5356
  br label %5537

; <label>:5537                                    ; preds = %5520, %5399, %5393
  %5538 = phi float [ %5534, %5520 ], [ %5354, %5399 ], [ %5354, %5393 ]
  %5539 = phi float [ %5535, %5520 ], [ %5355, %5399 ], [ %5355, %5393 ]
  %5540 = phi float [ %5536, %5520 ], [ %5356, %5399 ], [ %5356, %5393 ]
  %5541 = fadd fast float %6, 1.000000e+00
  %5542 = fadd fast float %7, 1.000000e+00
  %5543 = fsub fast float 1.000000e+00, %6
  %5544 = fmul fast float %37, %5541
  %5545 = fmul fast float %37, %5542
  %5546 = fmul fast float %37, %5543
  %5547 = fmul fast float %5544, %5538
  %5548 = fmul fast float %5545, %5539
  %5549 = fmul fast float %5546, %5540
  %5550 = fcmp fast ult float %38, 5.000000e-01
  br i1 %5550, label %5576, label %5551

; <label>:5551                                    ; preds = %5537
  %5552 = fmul fast float %5547, 0x4004147AE0000000
  %5553 = fmul fast float %5548, 0x4004147AE0000000
  %5554 = fmul fast float %5549, 0x4004147AE0000000
  %5555 = fadd fast float %5552, 0x3F9EB851E0000000
  %5556 = fadd fast float %5553, 0x3F9EB851E0000000
  %5557 = fadd fast float %5554, 0x3F9EB851E0000000
  %5558 = fmul fast float %5555, %5547
  %5559 = fmul fast float %5556, %5548
  %5560 = fmul fast float %5557, %5549
  %5561 = fmul fast float %5547, 0x400370A3E0000000
  %5562 = fmul fast float %5548, 0x400370A3E0000000
  %5563 = fmul fast float %5549, 0x400370A3E0000000
  %5564 = fadd fast float %5561, 0x3FE2E147A0000000
  %5565 = fadd fast float %5562, 0x3FE2E147A0000000
  %5566 = fadd fast float %5563, 0x3FE2E147A0000000
  %5567 = fmul fast float %5564, %5547
  %5568 = fmul fast float %5565, %5548
  %5569 = fmul fast float %5566, %5549
  %5570 = fadd fast float %5567, 0x3FC1EB8520000000
  %5571 = fadd fast float %5568, 0x3FC1EB8520000000
  %5572 = fadd fast float %5569, 0x3FC1EB8520000000
  %5573 = fdiv fast float %5558, %5570
  %5574 = fdiv fast float %5559, %5571
  %5575 = fdiv fast float %5560, %5572
  br label %5576

; <label>:5576                                    ; preds = %5551, %5537
  %5577 = phi float [ %5573, %5551 ], [ %5547, %5537 ]
  %5578 = phi float [ %5574, %5551 ], [ %5548, %5537 ]
  %5579 = phi float [ %5575, %5551 ], [ %5549, %5537 ]
  %5580 = call float @dx.op.unary.f32(i32 7, float %5577)  ; Saturate(value)
  %5581 = call float @dx.op.unary.f32(i32 7, float %5578)  ; Saturate(value)
  %5582 = call float @dx.op.unary.f32(i32 7, float %5579)  ; Saturate(value)
  %5583 = call float @dx.op.dot3.f32(i32 55, float %5580, float %5581, float %5582, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5584 = fsub fast float %5580, %5583
  %5585 = fsub fast float %5581, %5583
  %5586 = fsub fast float %5582, %5583
  %5587 = fmul fast float %5584, %9
  %5588 = fmul fast float %5585, %9
  %5589 = fmul fast float %5586, %9
  %5590 = fadd fast float %5587, %5583
  %5591 = fadd fast float %5588, %5583
  %5592 = fadd fast float %5589, %5583
  %5593 = call float @dx.op.unary.f32(i32 7, float %5590)  ; Saturate(value)
  %5594 = call float @dx.op.unary.f32(i32 7, float %5591)  ; Saturate(value)
  %5595 = call float @dx.op.unary.f32(i32 7, float %5592)  ; Saturate(value)
  %5596 = fadd fast float %5593, 0xBFC70A3D80000000
  %5597 = fadd fast float %5594, 0xBFC70A3D80000000
  %5598 = fadd fast float %5595, 0xBFC70A3D80000000
  %5599 = fmul fast float %5596, %8
  %5600 = fmul fast float %5597, %8
  %5601 = fmul fast float %5598, %8
  %5602 = fadd fast float %5599, 0x3FC70A3D80000000
  %5603 = fadd fast float %5600, 0x3FC70A3D80000000
  %5604 = fadd fast float %5601, 0x3FC70A3D80000000
  %5605 = call float @dx.op.unary.f32(i32 7, float %5602)  ; Saturate(value)
  %5606 = call float @dx.op.unary.f32(i32 7, float %5603)  ; Saturate(value)
  %5607 = call float @dx.op.unary.f32(i32 7, float %5604)  ; Saturate(value)
  br label %5608

; <label>:5608                                    ; preds = %5576, %5359
  %5609 = phi float [ %5390, %5359 ], [ %5605, %5576 ]
  %5610 = phi float [ %5391, %5359 ], [ %5606, %5576 ]
  %5611 = phi float [ %5392, %5359 ], [ %5607, %5576 ]
  %5612 = call float @dx.op.binary.f32(i32 36, float %5347, float %5609)  ; FMin(a,b)
  %5613 = call float @dx.op.binary.f32(i32 36, float %5348, float %5610)  ; FMin(a,b)
  %5614 = call float @dx.op.binary.f32(i32 36, float %5349, float %5611)  ; FMin(a,b)
  %5615 = call float @dx.op.binary.f32(i32 36, float %4821, float %5083)  ; FMin(a,b)
  %5616 = call float @dx.op.binary.f32(i32 36, float %4822, float %5084)  ; FMin(a,b)
  %5617 = call float @dx.op.binary.f32(i32 36, float %4823, float %5085)  ; FMin(a,b)
  %5618 = call float @dx.op.binary.f32(i32 36, float %5615, float %5612)  ; FMin(a,b)
  %5619 = call float @dx.op.binary.f32(i32 36, float %5616, float %5613)  ; FMin(a,b)
  %5620 = call float @dx.op.binary.f32(i32 36, float %5617, float %5614)  ; FMin(a,b)
  %5621 = call float @dx.op.binary.f32(i32 36, float %4555, float %5618)  ; FMin(a,b)
  %5622 = call float @dx.op.binary.f32(i32 36, float %4556, float %5619)  ; FMin(a,b)
  %5623 = call float @dx.op.binary.f32(i32 36, float %4557, float %5620)  ; FMin(a,b)
  %5624 = call float @dx.op.binary.f32(i32 35, float %5347, float %5609)  ; FMax(a,b)
  %5625 = call float @dx.op.binary.f32(i32 35, float %5348, float %5610)  ; FMax(a,b)
  %5626 = call float @dx.op.binary.f32(i32 35, float %5349, float %5611)  ; FMax(a,b)
  %5627 = call float @dx.op.binary.f32(i32 35, float %4821, float %5083)  ; FMax(a,b)
  %5628 = call float @dx.op.binary.f32(i32 35, float %4822, float %5084)  ; FMax(a,b)
  %5629 = call float @dx.op.binary.f32(i32 35, float %4823, float %5085)  ; FMax(a,b)
  %5630 = call float @dx.op.binary.f32(i32 35, float %5627, float %5624)  ; FMax(a,b)
  %5631 = call float @dx.op.binary.f32(i32 35, float %5628, float %5625)  ; FMax(a,b)
  %5632 = call float @dx.op.binary.f32(i32 35, float %5629, float %5626)  ; FMax(a,b)
  %5633 = call float @dx.op.binary.f32(i32 35, float %4555, float %5630)  ; FMax(a,b)
  %5634 = call float @dx.op.binary.f32(i32 35, float %4556, float %5631)  ; FMax(a,b)
  %5635 = call float @dx.op.binary.f32(i32 35, float %4557, float %5632)  ; FMax(a,b)
  %5636 = fsub fast float %5633, %5621
  %5637 = fsub fast float %5634, %5622
  %5638 = fsub fast float %5635, %5623
  %5639 = call float @dx.op.unary.f32(i32 6, float %5636)  ; FAbs(value)
  %5640 = call float @dx.op.unary.f32(i32 6, float %5637)  ; FAbs(value)
  %5641 = call float @dx.op.unary.f32(i32 6, float %5638)  ; FAbs(value)
  %5642 = call float @dx.op.binary.f32(i32 35, float %5640, float %5641)  ; FMax(a,b)
  %5643 = call float @dx.op.binary.f32(i32 35, float %5639, float %5642)  ; FMax(a,b)
  %5644 = call float @dx.op.binary.f32(i32 35, float %5634, float %5635)  ; FMax(a,b)
  %5645 = call float @dx.op.binary.f32(i32 35, float %5633, float %5644)  ; FMax(a,b)
  %5646 = fmul fast float %5645, 1.250000e-01
  %5647 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %5646)  ; FMax(a,b)
  %5648 = fcmp fast ogt float %5643, %5647
  br i1 %5648, label %5649, label %5711

; <label>:5649                                    ; preds = %5608
  %5650 = fsub fast float %4821, %5083
  %5651 = fsub fast float %4822, %5084
  %5652 = fsub fast float %4823, %5085
  %5653 = call float @dx.op.unary.f32(i32 6, float %5650)  ; FAbs(value)
  %5654 = call float @dx.op.unary.f32(i32 6, float %5651)  ; FAbs(value)
  %5655 = call float @dx.op.unary.f32(i32 6, float %5652)  ; FAbs(value)
  %5656 = call float @dx.op.binary.f32(i32 35, float %5654, float %5655)  ; FMax(a,b)
  %5657 = call float @dx.op.binary.f32(i32 35, float %5653, float %5656)  ; FMax(a,b)
  %5658 = fsub fast float %5347, %5609
  %5659 = fsub fast float %5348, %5610
  %5660 = fsub fast float %5349, %5611
  %5661 = call float @dx.op.unary.f32(i32 6, float %5658)  ; FAbs(value)
  %5662 = call float @dx.op.unary.f32(i32 6, float %5659)  ; FAbs(value)
  %5663 = call float @dx.op.unary.f32(i32 6, float %5660)  ; FAbs(value)
  %5664 = call float @dx.op.binary.f32(i32 35, float %5662, float %5663)  ; FMax(a,b)
  %5665 = call float @dx.op.binary.f32(i32 35, float %5661, float %5664)  ; FMax(a,b)
  %5666 = fcmp fast olt float %5657, %5665
  %5667 = select i1 %5666, float %4821, float %5347
  %5668 = select i1 %5666, float %4822, float %5348
  %5669 = select i1 %5666, float %4823, float %5349
  %5670 = select i1 %5666, float %5083, float %5609
  %5671 = select i1 %5666, float %5084, float %5610
  %5672 = select i1 %5666, float %5085, float %5611
  %5673 = fsub fast float %4555, %5670
  %5674 = fsub fast float %4556, %5671
  %5675 = fsub fast float %4557, %5672
  %5676 = fsub fast float %4555, %5667
  %5677 = fsub fast float %4556, %5668
  %5678 = fsub fast float %4557, %5669
  %5679 = call float @dx.op.dot3.f32(i32 55, float %5676, float %5677, float %5678, float %5673, float %5674, float %5675)  ; Dot3(ax,ay,az,bx,by,bz)
  %5680 = fcmp fast ogt float %5679, 0.000000e+00
  br i1 %5680, label %5681, label %5693

; <label>:5681                                    ; preds = %5649
  %5682 = fsub fast float %5667, %5670
  %5683 = fsub fast float %5668, %5671
  %5684 = fsub fast float %5669, %5672
  %5685 = call float @dx.op.unary.f32(i32 6, float %5682)  ; FAbs(value)
  %5686 = call float @dx.op.unary.f32(i32 6, float %5683)  ; FAbs(value)
  %5687 = call float @dx.op.unary.f32(i32 6, float %5684)  ; FAbs(value)
  %5688 = call float @dx.op.binary.f32(i32 35, float %5686, float %5687)  ; FMax(a,b)
  %5689 = call float @dx.op.binary.f32(i32 35, float %5685, float %5688)  ; FMax(a,b)
  %5690 = fmul fast float %5643, 2.500000e-01
  %5691 = fcmp fast olt float %5689, %5690
  %5692 = select i1 %5691, float 5.000000e-01, float 1.000000e+00
  br label %5693

; <label>:5693                                    ; preds = %5681, %5649
  %5694 = phi float [ 1.000000e+00, %5649 ], [ %5692, %5681 ]
  %5695 = fmul fast float %5694, %3
  %5696 = fadd fast float %5667, %5670
  %5697 = fadd fast float %5668, %5671
  %5698 = fadd fast float %5669, %5672
  %5699 = fmul fast float %5696, 5.000000e-01
  %5700 = fmul fast float %5697, 5.000000e-01
  %5701 = fmul fast float %5698, 5.000000e-01
  %5702 = fsub fast float %5699, %4555
  %5703 = fsub fast float %5700, %4556
  %5704 = fsub fast float %5701, %4557
  %5705 = fmul fast float %5695, %5702
  %5706 = fmul fast float %5695, %5703
  %5707 = fmul fast float %5695, %5704
  %5708 = fadd fast float %5705, %4555
  %5709 = fadd fast float %5706, %4556
  %5710 = fadd fast float %5707, %4557
  br label %5711

; <label>:5711                                    ; preds = %5693, %5608, %4526
  %5712 = phi float [ %5708, %5693 ], [ %4555, %5608 ], [ %4555, %4526 ]
  %5713 = phi float [ %5709, %5693 ], [ %4556, %5608 ], [ %4556, %4526 ]
  %5714 = phi float [ %5710, %5693 ], [ %4557, %5608 ], [ %4557, %4526 ]
  %5715 = fcmp fast ogt float %5712, 0x3F69A5C380000000
  %5716 = fcmp fast ogt float %5713, 0x3F69A5C380000000
  %5717 = fcmp fast ogt float %5714, 0x3F69A5C380000000
  %5718 = select i1 %5715, float 0.000000e+00, float 1.000000e+00
  %5719 = select i1 %5716, float 0.000000e+00, float 1.000000e+00
  %5720 = select i1 %5717, float 0.000000e+00, float 1.000000e+00
  %5721 = fmul fast float %5712, 0x4029D70A40000000
  %5722 = fmul fast float %5713, 0x4029D70A40000000
  %5723 = fmul fast float %5714, 0x4029D70A40000000
  %5724 = call float @dx.op.binary.f32(i32 35, float %5712, float 0.000000e+00)  ; FMax(a,b)
  %5725 = call float @dx.op.binary.f32(i32 35, float %5713, float 0.000000e+00)  ; FMax(a,b)
  %5726 = call float @dx.op.binary.f32(i32 35, float %5714, float 0.000000e+00)  ; FMax(a,b)
  %5727 = call float @dx.op.unary.f32(i32 23, float %5724)  ; Log(value)
  %5728 = call float @dx.op.unary.f32(i32 23, float %5725)  ; Log(value)
  %5729 = call float @dx.op.unary.f32(i32 23, float %5726)  ; Log(value)
  %5730 = fmul fast float %5727, 0x3FDAAAAAA0000000
  %5731 = fmul fast float %5728, 0x3FDAAAAAA0000000
  %5732 = fmul fast float %5729, 0x3FDAAAAAA0000000
  %5733 = call float @dx.op.unary.f32(i32 21, float %5730)  ; Exp(value)
  %5734 = call float @dx.op.unary.f32(i32 21, float %5731)  ; Exp(value)
  %5735 = call float @dx.op.unary.f32(i32 21, float %5732)  ; Exp(value)
  %5736 = fmul fast float %5733, 0x3FF0E147A0000000
  %5737 = fmul fast float %5734, 0x3FF0E147A0000000
  %5738 = fmul fast float %5735, 0x3FF0E147A0000000
  %5739 = fadd fast float %5736, 0xBFAC28F5C0000000
  %5740 = fadd fast float %5737, 0xBFAC28F5C0000000
  %5741 = fadd fast float %5738, 0xBFAC28F5C0000000
  %5742 = fsub fast float %5721, %5739
  %5743 = fsub fast float %5722, %5740
  %5744 = fsub fast float %5723, %5741
  %5745 = fmul fast float %5742, %5718
  %5746 = fmul fast float %5743, %5719
  %5747 = fmul fast float %5744, %5720
  %5748 = fadd fast float %5745, %5739
  %5749 = fadd fast float %5746, %5740
  %5750 = fadd fast float %5747, %5741
  br label %5751

; <label>:5751                                    ; preds = %5711, %4341
  %5752 = phi float [ %4336, %4341 ], [ %5748, %5711 ]
  %5753 = phi float [ %4337, %4341 ], [ %5749, %5711 ]
  %5754 = phi float [ %4338, %4341 ], [ %5750, %5711 ]
  %5755 = phi float [ %4342, %4341 ], [ %4339, %5711 ]
  %5756 = call float @dx.op.unary.f32(i32 27, float %50)  ; Round_ni(value)
  %5757 = call float @dx.op.unary.f32(i32 27, float %51)  ; Round_ni(value)
  %5758 = fptosi float %5756 to i32
  %5759 = fptosi float %5757 to i32
  %5760 = call i32 @dx.op.binary.i32(i32 37, i32 %5758, i32 0)  ; IMax(a,b)
  %5761 = call i32 @dx.op.binary.i32(i32 37, i32 %5759, i32 0)  ; IMax(a,b)
  %5762 = call i32 @dx.op.binary.i32(i32 38, i32 %5760, i32 %60)  ; IMin(a,b)
  %5763 = call i32 @dx.op.binary.i32(i32 38, i32 %5761, i32 %61)  ; IMin(a,b)
  %5764 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5762, i32 %5763, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5765 = extractvalue %dx.types.ResRet.f32 %5764, 0
  %5766 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %64, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5767 = extractvalue %dx.types.ResRet.f32 %5766, 0
  %5768 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1489, i32 %65, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5769 = extractvalue %dx.types.ResRet.f32 %5768, 0
  %5770 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %64, i32 %2913, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5771 = extractvalue %dx.types.ResRet.f32 %5770, 0
  %5772 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1489, i32 %2913, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5773 = extractvalue %dx.types.ResRet.f32 %5772, 0
  %5774 = fsub fast float 1.000000e+00, %58
  %5775 = fsub fast float 1.000000e+00, %59
  %5776 = fmul fast float %5775, %5774
  %5777 = fmul fast float %5775, %58
  %5778 = fmul fast float %5774, %59
  %5779 = fmul fast float %59, %58
  %5780 = fsub fast float 1.000000e+00, %5765
  %5781 = fmul fast float %5780, 0x3FA99999A0000000
  %5782 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %5781)  ; FMax(a,b)
  %5783 = fsub fast float %5767, %5765
  %5784 = fsub fast float %5769, %5765
  %5785 = fsub fast float %5771, %5765
  %5786 = fsub fast float %5773, %5765
  %5787 = call float @dx.op.unary.f32(i32 6, float %5783)  ; FAbs(value)
  %5788 = call float @dx.op.unary.f32(i32 6, float %5784)  ; FAbs(value)
  %5789 = call float @dx.op.unary.f32(i32 6, float %5785)  ; FAbs(value)
  %5790 = call float @dx.op.unary.f32(i32 6, float %5786)  ; FAbs(value)
  %5791 = fdiv fast float %5787, %5782
  %5792 = fdiv fast float %5788, %5782
  %5793 = fdiv fast float %5789, %5782
  %5794 = fdiv fast float %5790, %5782
  %5795 = fsub fast float 1.000000e+00, %5791
  %5796 = fsub fast float 1.000000e+00, %5792
  %5797 = fsub fast float 1.000000e+00, %5793
  %5798 = fsub fast float 1.000000e+00, %5794
  %5799 = call float @dx.op.unary.f32(i32 7, float %5795)  ; Saturate(value)
  %5800 = call float @dx.op.unary.f32(i32 7, float %5796)  ; Saturate(value)
  %5801 = call float @dx.op.unary.f32(i32 7, float %5797)  ; Saturate(value)
  %5802 = call float @dx.op.unary.f32(i32 7, float %5798)  ; Saturate(value)
  %5803 = fmul fast float %5776, %5799
  %5804 = fmul fast float %5777, %5800
  %5805 = fmul fast float %5778, %5801
  %5806 = fmul fast float %5779, %5802
  %5807 = call float @dx.op.dot4.f32(i32 56, float %5803, float %5804, float %5805, float %5806, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %5808 = call float @dx.op.binary.f32(i32 35, float %5807, float 0x3EE4F8B580000000)  ; FMax(a,b)
  %5809 = fdiv fast float %5803, %5808
  %5810 = fdiv fast float %5804, %5808
  %5811 = fdiv fast float %5805, %5808
  %5812 = fdiv fast float %5806, %5808
  %5813 = fcmp fast ogt float %1483, 0x3FA4B5DCC0000000
  %5814 = fcmp fast ogt float %1484, 0x3FA4B5DCC0000000
  %5815 = fcmp fast ogt float %1485, 0x3FA4B5DCC0000000
  %5816 = select i1 %5813, float 0.000000e+00, float 1.000000e+00
  %5817 = select i1 %5814, float 0.000000e+00, float 1.000000e+00
  %5818 = select i1 %5815, float 0.000000e+00, float 1.000000e+00
  %5819 = fmul fast float %1483, 0x3FB3D07220000000
  %5820 = fmul fast float %1484, 0x3FB3D07220000000
  %5821 = fmul fast float %1485, 0x3FB3D07220000000
  %5822 = fadd fast float %1483, 0x3FAC28F5C0000000
  %5823 = fadd fast float %1484, 0x3FAC28F5C0000000
  %5824 = fadd fast float %1485, 0x3FAC28F5C0000000
  %5825 = fmul fast float %5822, 0x3FEE54EDE0000000
  %5826 = fmul fast float %5823, 0x3FEE54EDE0000000
  %5827 = fmul fast float %5824, 0x3FEE54EDE0000000
  %5828 = call float @dx.op.unary.f32(i32 23, float %5825)  ; Log(value)
  %5829 = call float @dx.op.unary.f32(i32 23, float %5826)  ; Log(value)
  %5830 = call float @dx.op.unary.f32(i32 23, float %5827)  ; Log(value)
  %5831 = fmul fast float %5828, 0x4003333340000000
  %5832 = fmul fast float %5829, 0x4003333340000000
  %5833 = fmul fast float %5830, 0x4003333340000000
  %5834 = call float @dx.op.unary.f32(i32 21, float %5831)  ; Exp(value)
  %5835 = call float @dx.op.unary.f32(i32 21, float %5832)  ; Exp(value)
  %5836 = call float @dx.op.unary.f32(i32 21, float %5833)  ; Exp(value)
  %5837 = fsub fast float %5819, %5834
  %5838 = fsub fast float %5820, %5835
  %5839 = fsub fast float %5821, %5836
  %5840 = fmul fast float %5837, %5816
  %5841 = fmul fast float %5838, %5817
  %5842 = fmul fast float %5839, %5818
  %5843 = fadd fast float %5840, %5834
  %5844 = fadd fast float %5841, %5835
  %5845 = fadd fast float %5842, %5836
  %5846 = fmul fast float %5843, %5809
  %5847 = fmul fast float %5844, %5809
  %5848 = fmul fast float %5845, %5809
  %5849 = fcmp fast ogt float %2907, 0x3FA4B5DCC0000000
  %5850 = fcmp fast ogt float %2908, 0x3FA4B5DCC0000000
  %5851 = fcmp fast ogt float %2909, 0x3FA4B5DCC0000000
  %5852 = select i1 %5849, float 0.000000e+00, float 1.000000e+00
  %5853 = select i1 %5850, float 0.000000e+00, float 1.000000e+00
  %5854 = select i1 %5851, float 0.000000e+00, float 1.000000e+00
  %5855 = fmul fast float %2907, 0x3FB3D07220000000
  %5856 = fmul fast float %2908, 0x3FB3D07220000000
  %5857 = fmul fast float %2909, 0x3FB3D07220000000
  %5858 = fadd fast float %2907, 0x3FAC28F5C0000000
  %5859 = fadd fast float %2908, 0x3FAC28F5C0000000
  %5860 = fadd fast float %2909, 0x3FAC28F5C0000000
  %5861 = fmul fast float %5858, 0x3FEE54EDE0000000
  %5862 = fmul fast float %5859, 0x3FEE54EDE0000000
  %5863 = fmul fast float %5860, 0x3FEE54EDE0000000
  %5864 = call float @dx.op.unary.f32(i32 23, float %5861)  ; Log(value)
  %5865 = call float @dx.op.unary.f32(i32 23, float %5862)  ; Log(value)
  %5866 = call float @dx.op.unary.f32(i32 23, float %5863)  ; Log(value)
  %5867 = fmul fast float %5864, 0x4003333340000000
  %5868 = fmul fast float %5865, 0x4003333340000000
  %5869 = fmul fast float %5866, 0x4003333340000000
  %5870 = call float @dx.op.unary.f32(i32 21, float %5867)  ; Exp(value)
  %5871 = call float @dx.op.unary.f32(i32 21, float %5868)  ; Exp(value)
  %5872 = call float @dx.op.unary.f32(i32 21, float %5869)  ; Exp(value)
  %5873 = fsub fast float %5855, %5870
  %5874 = fsub fast float %5856, %5871
  %5875 = fsub fast float %5857, %5872
  %5876 = fmul fast float %5873, %5852
  %5877 = fmul fast float %5874, %5853
  %5878 = fmul fast float %5875, %5854
  %5879 = fadd fast float %5876, %5870
  %5880 = fadd fast float %5877, %5871
  %5881 = fadd fast float %5878, %5872
  %5882 = fmul fast float %5879, %5810
  %5883 = fmul fast float %5880, %5810
  %5884 = fmul fast float %5881, %5810
  %5885 = fadd fast float %5882, %5846
  %5886 = fadd fast float %5883, %5847
  %5887 = fadd fast float %5884, %5848
  %5888 = fcmp fast ogt float %4331, 0x3FA4B5DCC0000000
  %5889 = fcmp fast ogt float %4332, 0x3FA4B5DCC0000000
  %5890 = fcmp fast ogt float %4333, 0x3FA4B5DCC0000000
  %5891 = select i1 %5888, float 0.000000e+00, float 1.000000e+00
  %5892 = select i1 %5889, float 0.000000e+00, float 1.000000e+00
  %5893 = select i1 %5890, float 0.000000e+00, float 1.000000e+00
  %5894 = fmul fast float %4331, 0x3FB3D07220000000
  %5895 = fmul fast float %4332, 0x3FB3D07220000000
  %5896 = fmul fast float %4333, 0x3FB3D07220000000
  %5897 = fadd fast float %4331, 0x3FAC28F5C0000000
  %5898 = fadd fast float %4332, 0x3FAC28F5C0000000
  %5899 = fadd fast float %4333, 0x3FAC28F5C0000000
  %5900 = fmul fast float %5897, 0x3FEE54EDE0000000
  %5901 = fmul fast float %5898, 0x3FEE54EDE0000000
  %5902 = fmul fast float %5899, 0x3FEE54EDE0000000
  %5903 = call float @dx.op.unary.f32(i32 23, float %5900)  ; Log(value)
  %5904 = call float @dx.op.unary.f32(i32 23, float %5901)  ; Log(value)
  %5905 = call float @dx.op.unary.f32(i32 23, float %5902)  ; Log(value)
  %5906 = fmul fast float %5903, 0x4003333340000000
  %5907 = fmul fast float %5904, 0x4003333340000000
  %5908 = fmul fast float %5905, 0x4003333340000000
  %5909 = call float @dx.op.unary.f32(i32 21, float %5906)  ; Exp(value)
  %5910 = call float @dx.op.unary.f32(i32 21, float %5907)  ; Exp(value)
  %5911 = call float @dx.op.unary.f32(i32 21, float %5908)  ; Exp(value)
  %5912 = fsub fast float %5894, %5909
  %5913 = fsub fast float %5895, %5910
  %5914 = fsub fast float %5896, %5911
  %5915 = fmul fast float %5912, %5891
  %5916 = fmul fast float %5913, %5892
  %5917 = fmul fast float %5914, %5893
  %5918 = fadd fast float %5915, %5909
  %5919 = fadd fast float %5916, %5910
  %5920 = fadd fast float %5917, %5911
  %5921 = fmul fast float %5918, %5811
  %5922 = fmul fast float %5919, %5811
  %5923 = fmul fast float %5920, %5811
  %5924 = fadd fast float %5885, %5921
  %5925 = fadd fast float %5886, %5922
  %5926 = fadd fast float %5887, %5923
  %5927 = fcmp fast ogt float %5752, 0x3FA4B5DCC0000000
  %5928 = fcmp fast ogt float %5753, 0x3FA4B5DCC0000000
  %5929 = fcmp fast ogt float %5754, 0x3FA4B5DCC0000000
  %5930 = select i1 %5927, float 0.000000e+00, float 1.000000e+00
  %5931 = select i1 %5928, float 0.000000e+00, float 1.000000e+00
  %5932 = select i1 %5929, float 0.000000e+00, float 1.000000e+00
  %5933 = fmul fast float %5752, 0x3FB3D07220000000
  %5934 = fmul fast float %5753, 0x3FB3D07220000000
  %5935 = fmul fast float %5754, 0x3FB3D07220000000
  %5936 = fadd fast float %5752, 0x3FAC28F5C0000000
  %5937 = fadd fast float %5753, 0x3FAC28F5C0000000
  %5938 = fadd fast float %5754, 0x3FAC28F5C0000000
  %5939 = fmul fast float %5936, 0x3FEE54EDE0000000
  %5940 = fmul fast float %5937, 0x3FEE54EDE0000000
  %5941 = fmul fast float %5938, 0x3FEE54EDE0000000
  %5942 = call float @dx.op.unary.f32(i32 23, float %5939)  ; Log(value)
  %5943 = call float @dx.op.unary.f32(i32 23, float %5940)  ; Log(value)
  %5944 = call float @dx.op.unary.f32(i32 23, float %5941)  ; Log(value)
  %5945 = fmul fast float %5942, 0x4003333340000000
  %5946 = fmul fast float %5943, 0x4003333340000000
  %5947 = fmul fast float %5944, 0x4003333340000000
  %5948 = call float @dx.op.unary.f32(i32 21, float %5945)  ; Exp(value)
  %5949 = call float @dx.op.unary.f32(i32 21, float %5946)  ; Exp(value)
  %5950 = call float @dx.op.unary.f32(i32 21, float %5947)  ; Exp(value)
  %5951 = fsub fast float %5933, %5948
  %5952 = fsub fast float %5934, %5949
  %5953 = fsub fast float %5935, %5950
  %5954 = fmul fast float %5951, %5930
  %5955 = fmul fast float %5952, %5931
  %5956 = fmul fast float %5953, %5932
  %5957 = fadd fast float %5954, %5948
  %5958 = fadd fast float %5955, %5949
  %5959 = fadd fast float %5956, %5950
  %5960 = fmul fast float %5957, %5812
  %5961 = fmul fast float %5958, %5812
  %5962 = fmul fast float %5959, %5812
  %5963 = fadd fast float %5924, %5960
  %5964 = fadd fast float %5925, %5961
  %5965 = fadd fast float %5926, %5962
  %5966 = fcmp fast ogt float %5963, 0x3F69A5C380000000
  %5967 = fcmp fast ogt float %5964, 0x3F69A5C380000000
  %5968 = fcmp fast ogt float %5965, 0x3F69A5C380000000
  %5969 = select i1 %5966, float 0.000000e+00, float 1.000000e+00
  %5970 = select i1 %5967, float 0.000000e+00, float 1.000000e+00
  %5971 = select i1 %5968, float 0.000000e+00, float 1.000000e+00
  %5972 = fmul fast float %5963, 0x4029D70A40000000
  %5973 = fmul fast float %5964, 0x4029D70A40000000
  %5974 = fmul fast float %5965, 0x4029D70A40000000
  %5975 = call float @dx.op.binary.f32(i32 35, float %5963, float 0.000000e+00)  ; FMax(a,b)
  %5976 = call float @dx.op.binary.f32(i32 35, float %5964, float 0.000000e+00)  ; FMax(a,b)
  %5977 = call float @dx.op.binary.f32(i32 35, float %5965, float 0.000000e+00)  ; FMax(a,b)
  %5978 = call float @dx.op.unary.f32(i32 23, float %5975)  ; Log(value)
  %5979 = call float @dx.op.unary.f32(i32 23, float %5976)  ; Log(value)
  %5980 = call float @dx.op.unary.f32(i32 23, float %5977)  ; Log(value)
  %5981 = fmul fast float %5978, 0x3FDAAAAAA0000000
  %5982 = fmul fast float %5979, 0x3FDAAAAAA0000000
  %5983 = fmul fast float %5980, 0x3FDAAAAAA0000000
  %5984 = call float @dx.op.unary.f32(i32 21, float %5981)  ; Exp(value)
  %5985 = call float @dx.op.unary.f32(i32 21, float %5982)  ; Exp(value)
  %5986 = call float @dx.op.unary.f32(i32 21, float %5983)  ; Exp(value)
  %5987 = fmul fast float %5984, 0x3FF0E147A0000000
  %5988 = fmul fast float %5985, 0x3FF0E147A0000000
  %5989 = fmul fast float %5986, 0x3FF0E147A0000000
  %5990 = fadd fast float %5987, 0xBFAC28F5C0000000
  %5991 = fadd fast float %5988, 0xBFAC28F5C0000000
  %5992 = fadd fast float %5989, 0xBFAC28F5C0000000
  %5993 = fsub fast float %5972, %5990
  %5994 = fsub fast float %5973, %5991
  %5995 = fsub fast float %5974, %5992
  %5996 = fmul fast float %5993, %5969
  %5997 = fmul fast float %5994, %5970
  %5998 = fmul fast float %5995, %5971
  %5999 = fadd fast float %5996, %5990
  %6000 = fadd fast float %5997, %5991
  %6001 = fadd fast float %5998, %5992
  %6002 = call float @dx.op.dot4.f32(i32 56, float %1486, float %2910, float %4334, float %5755, float %5809, float %5810, float %5811, float %5812)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %5999)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %6000)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %6001)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %6002)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %5765)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !37, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, !28}
!36 = !{i32 9}
!37 = !{!38, !39}
!38 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
!39 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !40}
!40 = !{i32 3, i32 1}
