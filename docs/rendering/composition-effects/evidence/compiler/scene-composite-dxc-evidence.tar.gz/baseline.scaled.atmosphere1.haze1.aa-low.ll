;
; Input signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Position              0   xyzw        0      POS   float   xy  
; TEXCOORD                 0   xyzw        1     NONE   float   xyzw
; TEXCOORD                 1   xyzw        2     NONE   float   xyzw
; TEXCOORD                 2   xyzw        3     NONE   float   xyzw
; TEXCOORD                 3   xyzw        4     NONE   float   xyzw
; TEXCOORD                 4   xyzw        5     NONE   float   xyzw
; TEXCOORD                 5   xyzw        6     NONE   float   xyz 
; TEXCOORD                 6   xyzw        7     NONE   float   xyzw
; TEXCOORD                 7   xyzw        8     NONE   float   xyzw
; TEXCOORD                 8   xyzw        9     NONE   float   xyzw
; TEXCOORD                 9   xyzw       10     NONE   float    yz 
;
;
; Output signature:
;
; Name                 Index   Mask Register SysValue  Format   Used
; -------------------- ----- ------ -------- -------- ------- ------
; SV_Target                0   xyzw        0   TARGET   float   xyzw
; SV_Depth                 0    N/A   oDepth    DEPTH   float    YES
;
; shader hash: 98a4ccebf65ad5e591b456635ce2d228
;
; Pipeline Runtime Information: 
;
;PSVRuntimeInfo:
; Pixel Shader
; DepthOutput=1
; SampleFrequency=0
; MinimumExpectedWaveLaneCount: 0
; MaximumExpectedWaveLaneCount: 4294967295
; UsesViewID: false
; SigInputElements: 11
; SigOutputElements: 2
; SigPatchConstOrPrimElements: 0
; SigInputVectors: 11
; SigOutputVectors[0]: 1
; SigOutputVectors[1]: 0
; SigOutputVectors[2]: 0
; SigOutputVectors[3]: 0
; EntryFunctionName: PSMain
;
;
; Input signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Position              0          noperspective       
; TEXCOORD                 0        nointerpolation       
; TEXCOORD                 1        nointerpolation       
; TEXCOORD                 2        nointerpolation       
; TEXCOORD                 3        nointerpolation       
; TEXCOORD                 4        nointerpolation       
; TEXCOORD                 5        nointerpolation       
; TEXCOORD                 6        nointerpolation       
; TEXCOORD                 7        nointerpolation       
; TEXCOORD                 8        nointerpolation       
; TEXCOORD                 9        nointerpolation       
;
; Output signature:
;
; Name                 Index             InterpMode DynIdx
; -------------------- ----- ---------------------- ------
; SV_Target                0                              
; SV_Depth                 0                              
;
; Buffer Definitions:
;
;
; Resource Bindings:
;
; Name                                 Type  Format         Dim      ID      HLSL Bind  Count
; ------------------------------ ---------- ------- ----------- ------- -------------- ------
; Scene                             texture     f32          2d      T0             t0     1
; Depth                             texture     f32          2d      T1             t1     1
;
;
; ViewId state:
;
; Number of inputs: 44, outputs: 4
; Outputs dependent on ViewId: {  }
; Inputs contributing to computation of Outputs:
;   output 0 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 1 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 2 depends on inputs: { 0, 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42 }
;   output 3 depends on inputs: { 0, 1, 41, 42 }
;
target datalayout = "e-m:e-p:32:32-i1:32-i8:32-i16:32-i32:32-i64:64-f16:32-f32:32-f64:64-n8:16:32:64"
target triple = "dxil-ms-dx"

%dx.types.Handle = type { i8* }
%dx.types.Dimensions = type { i32, i32, i32, i32 }
%dx.types.ResRet.f32 = type { float, float, float, float, i32 }
%"class.Texture2D<vector<float, 4> >" = type { <4 x float>, %"class.Texture2D<vector<float, 4> >::mips_type" }
%"class.Texture2D<vector<float, 4> >::mips_type" = type { i32 }
%"class.Texture2D<float>" = type { float, %"class.Texture2D<float>::mips_type" }
%"class.Texture2D<float>::mips_type" = type { i32 }

define void @PSMain() {
  %1 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 1, i32 1, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %2 = call %dx.types.Handle @dx.op.createHandle(i32 57, i8 0, i32 0, i32 0, i1 false)  ; CreateHandle(resourceClass,rangeId,index,nonUniformIndex)
  %3 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %4 = call float @dx.op.loadInput.f32(i32 4, i32 10, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %5 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %6 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %7 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %8 = call float @dx.op.loadInput.f32(i32 4, i32 9, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %9 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %10 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %11 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %12 = call float @dx.op.loadInput.f32(i32 4, i32 8, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %13 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %14 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %15 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %16 = call float @dx.op.loadInput.f32(i32 4, i32 7, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %17 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %18 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %19 = call float @dx.op.loadInput.f32(i32 4, i32 6, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %20 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %21 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %22 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %23 = call float @dx.op.loadInput.f32(i32 4, i32 5, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %24 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %25 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %26 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %27 = call float @dx.op.loadInput.f32(i32 4, i32 4, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %28 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %29 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %30 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %31 = call float @dx.op.loadInput.f32(i32 4, i32 3, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %32 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %33 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %34 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %35 = call float @dx.op.loadInput.f32(i32 4, i32 2, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %36 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %37 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %38 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 2, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %39 = call float @dx.op.loadInput.f32(i32 4, i32 1, i32 0, i8 3, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %40 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 0, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %41 = call float @dx.op.loadInput.f32(i32 4, i32 0, i32 0, i8 1, i32 undef)  ; LoadInput(inputSigId,rowIndex,colIndex,gsVertexAxis)
  %42 = call %dx.types.Dimensions @dx.op.getDimensions(i32 72, %dx.types.Handle %2, i32 0)  ; GetDimensions(handle,mipLevel)
  %43 = extractvalue %dx.types.Dimensions %42, 0
  %44 = extractvalue %dx.types.Dimensions %42, 1
  %45 = uitofp i32 %43 to float
  %46 = uitofp i32 %44 to float
  %47 = fmul fast float %45, %40
  %48 = fmul fast float %46, %41
  %49 = fdiv fast float %47, %3
  %50 = fdiv fast float %48, %4
  %51 = fadd fast float %49, -5.000000e-01
  %52 = fadd fast float %50, -5.000000e-01
  %53 = call float @dx.op.unary.f32(i32 27, float %51)  ; Round_ni(value)
  %54 = call float @dx.op.unary.f32(i32 27, float %52)  ; Round_ni(value)
  %55 = fptosi float %53 to i32
  %56 = fptosi float %54 to i32
  %57 = call float @dx.op.unary.f32(i32 22, float %51)  ; Frc(value)
  %58 = call float @dx.op.unary.f32(i32 22, float %52)  ; Frc(value)
  %59 = add i32 %43, -1
  %60 = add i32 %44, -1
  %61 = call i32 @dx.op.binary.i32(i32 37, i32 %55, i32 0)  ; IMax(a,b)
  %62 = call i32 @dx.op.binary.i32(i32 37, i32 %56, i32 0)  ; IMax(a,b)
  %63 = call i32 @dx.op.binary.i32(i32 38, i32 %61, i32 %59)  ; IMin(a,b)
  %64 = call i32 @dx.op.binary.i32(i32 38, i32 %62, i32 %60)  ; IMin(a,b)
  %65 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %66 = extractvalue %dx.types.ResRet.f32 %65, 0
  %67 = extractvalue %dx.types.ResRet.f32 %65, 1
  %68 = extractvalue %dx.types.ResRet.f32 %65, 2
  %69 = extractvalue %dx.types.ResRet.f32 %65, 3
  %70 = fcmp fast olt float %69, 0.000000e+00
  br i1 %70, label %71, label %73

; <label>:71                                      ; preds = %0
  %72 = fsub fast float -1.000000e+00, %69
  br label %1478

; <label>:73                                      ; preds = %0
  %74 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %75 = extractvalue %dx.types.ResRet.f32 %74, 0
  %76 = fcmp fast ogt float %38, 5.000000e-01
  %77 = fcmp fast olt float %75, 1.000000e+00
  %78 = and i1 %76, %77
  br i1 %78, label %79, label %217

; <label>:79                                      ; preds = %73
  %80 = sitofp i32 %63 to float
  %81 = sitofp i32 %64 to float
  %82 = fadd fast float %80, 5.000000e-01
  %83 = fadd fast float %81, 5.000000e-01
  %84 = fdiv fast float %82, %45
  %85 = fdiv fast float %83, %46
  %86 = fmul fast float %84, 2.000000e+00
  %87 = fmul fast float %85, 2.000000e+00
  %88 = fadd fast float %86, -1.000000e+00
  %89 = fsub fast float 1.000000e+00, %87
  %90 = fmul fast float %88, %35
  %91 = call float @dx.op.tertiary.f32(i32 46, float %89, float %31, float %90)  ; FMad(a,b,c)
  %92 = call float @dx.op.tertiary.f32(i32 46, float %75, float %27, float %91)  ; FMad(a,b,c)
  %93 = fadd fast float %92, %23
  %94 = call float @dx.op.unary.f32(i32 6, float %93)  ; FAbs(value)
  %95 = fcmp fast ogt float %94, 0x3EB0C6F7A0000000
  br i1 %95, label %96, label %217

; <label>:96                                      ; preds = %79
  %97 = fmul fast float %88, %34
  %98 = call float @dx.op.tertiary.f32(i32 46, float %89, float %30, float %97)  ; FMad(a,b,c)
  %99 = call float @dx.op.tertiary.f32(i32 46, float %75, float %26, float %98)  ; FMad(a,b,c)
  %100 = fadd fast float %99, %22
  %101 = fmul fast float %88, %33
  %102 = call float @dx.op.tertiary.f32(i32 46, float %89, float %29, float %101)  ; FMad(a,b,c)
  %103 = call float @dx.op.tertiary.f32(i32 46, float %75, float %25, float %102)  ; FMad(a,b,c)
  %104 = fadd fast float %103, %21
  %105 = fmul fast float %88, %32
  %106 = call float @dx.op.tertiary.f32(i32 46, float %89, float %28, float %105)  ; FMad(a,b,c)
  %107 = call float @dx.op.tertiary.f32(i32 46, float %75, float %24, float %106)  ; FMad(a,b,c)
  %108 = fadd fast float %107, %20
  %109 = fdiv fast float %108, %93
  %110 = fdiv fast float %104, %93
  %111 = fdiv fast float %100, %93
  %112 = fsub fast float %109, %17
  %113 = fsub fast float %110, %18
  %114 = fsub fast float %111, %19
  %115 = fmul fast float %112, %112
  %116 = fmul fast float %113, %113
  %117 = fadd fast float %116, %115
  %118 = fmul fast float %114, %114
  %119 = fadd fast float %117, %118
  %120 = call float @dx.op.unary.f32(i32 24, float %119)  ; Sqrt(value)
  %121 = fsub fast float %120, %9
  %122 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %121)  ; FMax(a,b)
  %123 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %123, label %124, label %147

; <label>:124                                     ; preds = %96
  %125 = call float @dx.op.unary.f32(i32 6, float %113)  ; FAbs(value)
  %126 = fmul fast float %125, %11
  %127 = fcmp fast olt float %126, 0x3F50624DE0000000
  br i1 %127, label %128, label %131

; <label>:128                                     ; preds = %124
  %129 = fmul fast float %126, 5.000000e-01
  %130 = fsub fast float 1.000000e+00, %129
  br label %136

; <label>:131                                     ; preds = %124
  %132 = fmul fast float %126, 0xBFF7154760000000
  %133 = call float @dx.op.unary.f32(i32 21, float %132)  ; Exp(value)
  %134 = fsub fast float 1.000000e+00, %133
  %135 = fdiv fast float %134, %126
  br label %136

; <label>:136                                     ; preds = %131, %128
  %137 = phi float [ %130, %128 ], [ %135, %131 ]
  %138 = call float @dx.op.binary.f32(i32 36, float %110, float %18)  ; FMin(a,b)
  %139 = fsub fast float %138, %10
  %140 = fmul fast float %11, %139
  %141 = fsub fast float -0.000000e+00, %140
  %142 = call float @dx.op.binary.f32(i32 35, float %141, float -4.000000e+01)  ; FMax(a,b)
  %143 = call float @dx.op.binary.f32(i32 36, float %142, float 5.000000e+00)  ; FMin(a,b)
  %144 = fmul fast float %143, 0x3FF7154760000000
  %145 = call float @dx.op.unary.f32(i32 21, float %144)  ; Exp(value)
  %146 = fmul fast float %145, %137
  br label %147

; <label>:147                                     ; preds = %136, %96
  %148 = phi float [ %146, %136 ], [ 1.000000e+00, %96 ]
  %149 = fmul fast float %122, %16
  %150 = fmul fast float %149, %148
  %151 = fcmp fast ole float %120, %9
  %152 = fcmp fast olt float %120, 0x3F1A36E2E0000000
  %153 = or i1 %151, %152
  br i1 %153, label %200, label %154

; <label>:154                                     ; preds = %147
  %155 = fdiv fast float %9, %120
  %156 = fmul fast float %155, %112
  %157 = fmul fast float %155, %113
  %158 = fmul fast float %155, %114
  %159 = fadd fast float %156, %17
  %160 = fadd fast float %157, %18
  %161 = fadd fast float %158, %19
  %162 = fadd fast float %159, -9.000000e+02
  %163 = fadd fast float %160, -1.500000e+01
  %164 = fadd fast float %161, -7.500000e+02
  %165 = fmul fast float %162, 0x3F62345680000000
  %166 = fmul fast float %163, 0x3F62345680000000
  %167 = fmul fast float %164, 0x3F62345680000000
  %168 = call float @dx.op.dot3.f32(i32 55, float %165, float %166, float %167, float %165, float %166, float %167)  ; Dot3(ax,ay,az,bx,by,bz)
  %169 = fsub fast float 1.000000e+00, %168
  %170 = call float @dx.op.unary.f32(i32 7, float %169)  ; Saturate(value)
  %171 = fmul fast float %170, %170
  %172 = fadd fast float %159, %109
  %173 = fadd fast float %160, %110
  %174 = fadd fast float %161, %111
  %175 = fmul fast float %172, 0x3F52345680000000
  %176 = fadd fast float %175, -2.000000e+00
  %177 = fmul fast float %173, 0x3F52345680000000
  %178 = fadd fast float %177, 0xBFA1111120000000
  %179 = fmul fast float %174, 0x3F52345680000000
  %180 = fadd fast float %179, 0xBFFAAAAAC0000000
  %181 = call float @dx.op.dot3.f32(i32 55, float %176, float %178, float %180, float %176, float %178, float %180)  ; Dot3(ax,ay,az,bx,by,bz)
  %182 = fsub fast float 1.000000e+00, %181
  %183 = call float @dx.op.unary.f32(i32 7, float %182)  ; Saturate(value)
  %184 = fmul fast float %183, %183
  %185 = fmul fast float %184, 4.000000e+00
  %186 = fadd fast float %185, %171
  %187 = fadd fast float %109, -9.000000e+02
  %188 = fadd fast float %110, -1.500000e+01
  %189 = fadd fast float %111, -7.500000e+02
  %190 = fmul fast float %187, 0x3F62345680000000
  %191 = fmul fast float %188, 0x3F62345680000000
  %192 = fmul fast float %189, 0x3F62345680000000
  %193 = call float @dx.op.dot3.f32(i32 55, float %190, float %191, float %192, float %190, float %191, float %192)  ; Dot3(ax,ay,az,bx,by,bz)
  %194 = fsub fast float 1.000000e+00, %193
  %195 = call float @dx.op.unary.f32(i32 7, float %194)  ; Saturate(value)
  %196 = fmul fast float %195, %195
  %197 = fadd fast float %186, %196
  %198 = fmul fast float %121, 0x3F25D867E0000000
  %199 = fmul fast float %198, %197
  br label %200

; <label>:200                                     ; preds = %154, %147
  %201 = phi float [ %199, %154 ], [ 0.000000e+00, %147 ]
  %202 = fadd fast float %201, %150
  %203 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %202)  ; FMin(a,b)
  %204 = fmul fast float %203, 0xBFF7154760000000
  %205 = call float @dx.op.unary.f32(i32 21, float %204)  ; Exp(value)
  %206 = fsub fast float 1.000000e+00, %205
  %207 = call float @dx.op.binary.f32(i32 36, float %12, float %206)  ; FMin(a,b)
  %208 = fsub fast float %13, %66
  %209 = fsub fast float %14, %67
  %210 = fsub fast float %15, %68
  %211 = fmul fast float %207, %208
  %212 = fmul fast float %207, %209
  %213 = fmul fast float %207, %210
  %214 = fadd fast float %211, %66
  %215 = fadd fast float %212, %67
  %216 = fadd fast float %213, %68
  br label %217

; <label>:217                                     ; preds = %200, %79, %73
  %218 = phi float [ %214, %200 ], [ %66, %79 ], [ %66, %73 ]
  %219 = phi float [ %215, %200 ], [ %67, %79 ], [ %67, %73 ]
  %220 = phi float [ %216, %200 ], [ %68, %79 ], [ %68, %73 ]
  %221 = fadd fast float %5, 1.000000e+00
  %222 = fadd fast float %6, 1.000000e+00
  %223 = fsub fast float 1.000000e+00, %5
  %224 = fmul fast float %36, %221
  %225 = fmul fast float %36, %222
  %226 = fmul fast float %36, %223
  %227 = fmul fast float %224, %218
  %228 = fmul fast float %225, %219
  %229 = fmul fast float %226, %220
  %230 = fcmp fast ult float %37, 5.000000e-01
  br i1 %230, label %256, label %231

; <label>:231                                     ; preds = %217
  %232 = fmul fast float %227, 0x4004147AE0000000
  %233 = fmul fast float %228, 0x4004147AE0000000
  %234 = fmul fast float %229, 0x4004147AE0000000
  %235 = fadd fast float %232, 0x3F9EB851E0000000
  %236 = fadd fast float %233, 0x3F9EB851E0000000
  %237 = fadd fast float %234, 0x3F9EB851E0000000
  %238 = fmul fast float %235, %227
  %239 = fmul fast float %236, %228
  %240 = fmul fast float %237, %229
  %241 = fmul fast float %227, 0x400370A3E0000000
  %242 = fmul fast float %228, 0x400370A3E0000000
  %243 = fmul fast float %229, 0x400370A3E0000000
  %244 = fadd fast float %241, 0x3FE2E147A0000000
  %245 = fadd fast float %242, 0x3FE2E147A0000000
  %246 = fadd fast float %243, 0x3FE2E147A0000000
  %247 = fmul fast float %244, %227
  %248 = fmul fast float %245, %228
  %249 = fmul fast float %246, %229
  %250 = fadd fast float %247, 0x3FC1EB8520000000
  %251 = fadd fast float %248, 0x3FC1EB8520000000
  %252 = fadd fast float %249, 0x3FC1EB8520000000
  %253 = fdiv fast float %238, %250
  %254 = fdiv fast float %239, %251
  %255 = fdiv fast float %240, %252
  br label %256

; <label>:256                                     ; preds = %231, %217
  %257 = phi float [ %253, %231 ], [ %227, %217 ]
  %258 = phi float [ %254, %231 ], [ %228, %217 ]
  %259 = phi float [ %255, %231 ], [ %229, %217 ]
  %260 = call float @dx.op.unary.f32(i32 7, float %257)  ; Saturate(value)
  %261 = call float @dx.op.unary.f32(i32 7, float %258)  ; Saturate(value)
  %262 = call float @dx.op.unary.f32(i32 7, float %259)  ; Saturate(value)
  %263 = call float @dx.op.dot3.f32(i32 55, float %260, float %261, float %262, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %264 = fsub fast float %260, %263
  %265 = fsub fast float %261, %263
  %266 = fsub fast float %262, %263
  %267 = fmul fast float %264, %8
  %268 = fmul fast float %265, %8
  %269 = fmul fast float %266, %8
  %270 = fadd fast float %267, %263
  %271 = fadd fast float %268, %263
  %272 = fadd fast float %269, %263
  %273 = call float @dx.op.unary.f32(i32 7, float %270)  ; Saturate(value)
  %274 = call float @dx.op.unary.f32(i32 7, float %271)  ; Saturate(value)
  %275 = call float @dx.op.unary.f32(i32 7, float %272)  ; Saturate(value)
  %276 = fadd fast float %273, 0xBFC70A3D80000000
  %277 = fadd fast float %274, 0xBFC70A3D80000000
  %278 = fadd fast float %275, 0xBFC70A3D80000000
  %279 = fmul fast float %276, %7
  %280 = fmul fast float %277, %7
  %281 = fmul fast float %278, %7
  %282 = fadd fast float %279, 0x3FC70A3D80000000
  %283 = fadd fast float %280, 0x3FC70A3D80000000
  %284 = fadd fast float %281, 0x3FC70A3D80000000
  %285 = call float @dx.op.unary.f32(i32 7, float %282)  ; Saturate(value)
  %286 = call float @dx.op.unary.f32(i32 7, float %283)  ; Saturate(value)
  %287 = call float @dx.op.unary.f32(i32 7, float %284)  ; Saturate(value)
  %288 = add i32 %64, -1
  %289 = call i32 @dx.op.binary.i32(i32 37, i32 %63, i32 0)  ; IMax(a,b)
  %290 = call i32 @dx.op.binary.i32(i32 37, i32 %288, i32 0)  ; IMax(a,b)
  %291 = call i32 @dx.op.binary.i32(i32 38, i32 %289, i32 %59)  ; IMin(a,b)
  %292 = call i32 @dx.op.binary.i32(i32 38, i32 %290, i32 %60)  ; IMin(a,b)
  %293 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %291, i32 %292, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %294 = extractvalue %dx.types.ResRet.f32 %293, 0
  %295 = extractvalue %dx.types.ResRet.f32 %293, 1
  %296 = extractvalue %dx.types.ResRet.f32 %293, 2
  %297 = extractvalue %dx.types.ResRet.f32 %293, 3
  %298 = fcmp fast olt float %297, 0.000000e+00
  br i1 %298, label %299, label %333

; <label>:299                                     ; preds = %256
  %300 = fcmp fast ogt float %294, 0x3FA4B5DCC0000000
  %301 = fcmp fast ogt float %295, 0x3FA4B5DCC0000000
  %302 = fcmp fast ogt float %296, 0x3FA4B5DCC0000000
  %303 = select i1 %300, float 0.000000e+00, float 1.000000e+00
  %304 = select i1 %301, float 0.000000e+00, float 1.000000e+00
  %305 = select i1 %302, float 0.000000e+00, float 1.000000e+00
  %306 = fmul fast float %294, 0x3FB3D07220000000
  %307 = fmul fast float %295, 0x3FB3D07220000000
  %308 = fmul fast float %296, 0x3FB3D07220000000
  %309 = fadd fast float %294, 0x3FAC28F5C0000000
  %310 = fadd fast float %295, 0x3FAC28F5C0000000
  %311 = fadd fast float %296, 0x3FAC28F5C0000000
  %312 = fmul fast float %309, 0x3FEE54EDE0000000
  %313 = fmul fast float %310, 0x3FEE54EDE0000000
  %314 = fmul fast float %311, 0x3FEE54EDE0000000
  %315 = call float @dx.op.unary.f32(i32 23, float %312)  ; Log(value)
  %316 = call float @dx.op.unary.f32(i32 23, float %313)  ; Log(value)
  %317 = call float @dx.op.unary.f32(i32 23, float %314)  ; Log(value)
  %318 = fmul fast float %315, 0x4003333340000000
  %319 = fmul fast float %316, 0x4003333340000000
  %320 = fmul fast float %317, 0x4003333340000000
  %321 = call float @dx.op.unary.f32(i32 21, float %318)  ; Exp(value)
  %322 = call float @dx.op.unary.f32(i32 21, float %319)  ; Exp(value)
  %323 = call float @dx.op.unary.f32(i32 21, float %320)  ; Exp(value)
  %324 = fsub fast float %306, %321
  %325 = fsub fast float %307, %322
  %326 = fsub fast float %308, %323
  %327 = fmul fast float %324, %303
  %328 = fmul fast float %325, %304
  %329 = fmul fast float %326, %305
  %330 = fadd fast float %327, %321
  %331 = fadd fast float %328, %322
  %332 = fadd fast float %329, %323
  br label %548

; <label>:333                                     ; preds = %256
  %334 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %291, i32 %292, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %335 = extractvalue %dx.types.ResRet.f32 %334, 0
  %336 = fcmp fast ogt float %38, 5.000000e-01
  %337 = fcmp fast olt float %335, 1.000000e+00
  %338 = and i1 %336, %337
  br i1 %338, label %339, label %477

; <label>:339                                     ; preds = %333
  %340 = sitofp i32 %291 to float
  %341 = sitofp i32 %292 to float
  %342 = fadd fast float %340, 5.000000e-01
  %343 = fadd fast float %341, 5.000000e-01
  %344 = fdiv fast float %342, %45
  %345 = fdiv fast float %343, %46
  %346 = fmul fast float %344, 2.000000e+00
  %347 = fmul fast float %345, 2.000000e+00
  %348 = fadd fast float %346, -1.000000e+00
  %349 = fsub fast float 1.000000e+00, %347
  %350 = fmul fast float %348, %35
  %351 = call float @dx.op.tertiary.f32(i32 46, float %349, float %31, float %350)  ; FMad(a,b,c)
  %352 = call float @dx.op.tertiary.f32(i32 46, float %335, float %27, float %351)  ; FMad(a,b,c)
  %353 = fadd fast float %352, %23
  %354 = call float @dx.op.unary.f32(i32 6, float %353)  ; FAbs(value)
  %355 = fcmp fast ogt float %354, 0x3EB0C6F7A0000000
  br i1 %355, label %356, label %477

; <label>:356                                     ; preds = %339
  %357 = fmul fast float %348, %34
  %358 = call float @dx.op.tertiary.f32(i32 46, float %349, float %30, float %357)  ; FMad(a,b,c)
  %359 = call float @dx.op.tertiary.f32(i32 46, float %335, float %26, float %358)  ; FMad(a,b,c)
  %360 = fadd fast float %359, %22
  %361 = fmul fast float %348, %33
  %362 = call float @dx.op.tertiary.f32(i32 46, float %349, float %29, float %361)  ; FMad(a,b,c)
  %363 = call float @dx.op.tertiary.f32(i32 46, float %335, float %25, float %362)  ; FMad(a,b,c)
  %364 = fadd fast float %363, %21
  %365 = fmul fast float %348, %32
  %366 = call float @dx.op.tertiary.f32(i32 46, float %349, float %28, float %365)  ; FMad(a,b,c)
  %367 = call float @dx.op.tertiary.f32(i32 46, float %335, float %24, float %366)  ; FMad(a,b,c)
  %368 = fadd fast float %367, %20
  %369 = fdiv fast float %368, %353
  %370 = fdiv fast float %364, %353
  %371 = fdiv fast float %360, %353
  %372 = fsub fast float %369, %17
  %373 = fsub fast float %370, %18
  %374 = fsub fast float %371, %19
  %375 = fmul fast float %372, %372
  %376 = fmul fast float %373, %373
  %377 = fadd fast float %376, %375
  %378 = fmul fast float %374, %374
  %379 = fadd fast float %377, %378
  %380 = call float @dx.op.unary.f32(i32 24, float %379)  ; Sqrt(value)
  %381 = fsub fast float %380, %9
  %382 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %381)  ; FMax(a,b)
  %383 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %383, label %384, label %407

; <label>:384                                     ; preds = %356
  %385 = call float @dx.op.unary.f32(i32 6, float %373)  ; FAbs(value)
  %386 = fmul fast float %385, %11
  %387 = fcmp fast olt float %386, 0x3F50624DE0000000
  br i1 %387, label %388, label %391

; <label>:388                                     ; preds = %384
  %389 = fmul fast float %386, 5.000000e-01
  %390 = fsub fast float 1.000000e+00, %389
  br label %396

; <label>:391                                     ; preds = %384
  %392 = fmul fast float %386, 0xBFF7154760000000
  %393 = call float @dx.op.unary.f32(i32 21, float %392)  ; Exp(value)
  %394 = fsub fast float 1.000000e+00, %393
  %395 = fdiv fast float %394, %386
  br label %396

; <label>:396                                     ; preds = %391, %388
  %397 = phi float [ %390, %388 ], [ %395, %391 ]
  %398 = call float @dx.op.binary.f32(i32 36, float %370, float %18)  ; FMin(a,b)
  %399 = fsub fast float %398, %10
  %400 = fmul fast float %11, %399
  %401 = fsub fast float -0.000000e+00, %400
  %402 = call float @dx.op.binary.f32(i32 35, float %401, float -4.000000e+01)  ; FMax(a,b)
  %403 = call float @dx.op.binary.f32(i32 36, float %402, float 5.000000e+00)  ; FMin(a,b)
  %404 = fmul fast float %403, 0x3FF7154760000000
  %405 = call float @dx.op.unary.f32(i32 21, float %404)  ; Exp(value)
  %406 = fmul fast float %405, %397
  br label %407

; <label>:407                                     ; preds = %396, %356
  %408 = phi float [ %406, %396 ], [ 1.000000e+00, %356 ]
  %409 = fmul fast float %382, %16
  %410 = fmul fast float %409, %408
  %411 = fcmp fast ole float %380, %9
  %412 = fcmp fast olt float %380, 0x3F1A36E2E0000000
  %413 = or i1 %411, %412
  br i1 %413, label %460, label %414

; <label>:414                                     ; preds = %407
  %415 = fdiv fast float %9, %380
  %416 = fmul fast float %415, %372
  %417 = fmul fast float %415, %373
  %418 = fmul fast float %415, %374
  %419 = fadd fast float %416, %17
  %420 = fadd fast float %417, %18
  %421 = fadd fast float %418, %19
  %422 = fadd fast float %419, -9.000000e+02
  %423 = fadd fast float %420, -1.500000e+01
  %424 = fadd fast float %421, -7.500000e+02
  %425 = fmul fast float %422, 0x3F62345680000000
  %426 = fmul fast float %423, 0x3F62345680000000
  %427 = fmul fast float %424, 0x3F62345680000000
  %428 = call float @dx.op.dot3.f32(i32 55, float %425, float %426, float %427, float %425, float %426, float %427)  ; Dot3(ax,ay,az,bx,by,bz)
  %429 = fsub fast float 1.000000e+00, %428
  %430 = call float @dx.op.unary.f32(i32 7, float %429)  ; Saturate(value)
  %431 = fmul fast float %430, %430
  %432 = fadd fast float %419, %369
  %433 = fadd fast float %420, %370
  %434 = fadd fast float %421, %371
  %435 = fmul fast float %432, 0x3F52345680000000
  %436 = fadd fast float %435, -2.000000e+00
  %437 = fmul fast float %433, 0x3F52345680000000
  %438 = fadd fast float %437, 0xBFA1111120000000
  %439 = fmul fast float %434, 0x3F52345680000000
  %440 = fadd fast float %439, 0xBFFAAAAAC0000000
  %441 = call float @dx.op.dot3.f32(i32 55, float %436, float %438, float %440, float %436, float %438, float %440)  ; Dot3(ax,ay,az,bx,by,bz)
  %442 = fsub fast float 1.000000e+00, %441
  %443 = call float @dx.op.unary.f32(i32 7, float %442)  ; Saturate(value)
  %444 = fmul fast float %443, %443
  %445 = fmul fast float %444, 4.000000e+00
  %446 = fadd fast float %445, %431
  %447 = fadd fast float %369, -9.000000e+02
  %448 = fadd fast float %370, -1.500000e+01
  %449 = fadd fast float %371, -7.500000e+02
  %450 = fmul fast float %447, 0x3F62345680000000
  %451 = fmul fast float %448, 0x3F62345680000000
  %452 = fmul fast float %449, 0x3F62345680000000
  %453 = call float @dx.op.dot3.f32(i32 55, float %450, float %451, float %452, float %450, float %451, float %452)  ; Dot3(ax,ay,az,bx,by,bz)
  %454 = fsub fast float 1.000000e+00, %453
  %455 = call float @dx.op.unary.f32(i32 7, float %454)  ; Saturate(value)
  %456 = fmul fast float %455, %455
  %457 = fadd fast float %446, %456
  %458 = fmul fast float %381, 0x3F25D867E0000000
  %459 = fmul fast float %458, %457
  br label %460

; <label>:460                                     ; preds = %414, %407
  %461 = phi float [ %459, %414 ], [ 0.000000e+00, %407 ]
  %462 = fadd fast float %461, %410
  %463 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %462)  ; FMin(a,b)
  %464 = fmul fast float %463, 0xBFF7154760000000
  %465 = call float @dx.op.unary.f32(i32 21, float %464)  ; Exp(value)
  %466 = fsub fast float 1.000000e+00, %465
  %467 = call float @dx.op.binary.f32(i32 36, float %12, float %466)  ; FMin(a,b)
  %468 = fsub fast float %13, %294
  %469 = fsub fast float %14, %295
  %470 = fsub fast float %15, %296
  %471 = fmul fast float %467, %468
  %472 = fmul fast float %467, %469
  %473 = fmul fast float %467, %470
  %474 = fadd fast float %471, %294
  %475 = fadd fast float %472, %295
  %476 = fadd fast float %473, %296
  br label %477

; <label>:477                                     ; preds = %460, %339, %333
  %478 = phi float [ %474, %460 ], [ %294, %339 ], [ %294, %333 ]
  %479 = phi float [ %475, %460 ], [ %295, %339 ], [ %295, %333 ]
  %480 = phi float [ %476, %460 ], [ %296, %339 ], [ %296, %333 ]
  %481 = fadd fast float %5, 1.000000e+00
  %482 = fadd fast float %6, 1.000000e+00
  %483 = fsub fast float 1.000000e+00, %5
  %484 = fmul fast float %36, %481
  %485 = fmul fast float %36, %482
  %486 = fmul fast float %36, %483
  %487 = fmul fast float %484, %478
  %488 = fmul fast float %485, %479
  %489 = fmul fast float %486, %480
  %490 = fcmp fast ult float %37, 5.000000e-01
  br i1 %490, label %516, label %491

; <label>:491                                     ; preds = %477
  %492 = fmul fast float %487, 0x4004147AE0000000
  %493 = fmul fast float %488, 0x4004147AE0000000
  %494 = fmul fast float %489, 0x4004147AE0000000
  %495 = fadd fast float %492, 0x3F9EB851E0000000
  %496 = fadd fast float %493, 0x3F9EB851E0000000
  %497 = fadd fast float %494, 0x3F9EB851E0000000
  %498 = fmul fast float %495, %487
  %499 = fmul fast float %496, %488
  %500 = fmul fast float %497, %489
  %501 = fmul fast float %487, 0x400370A3E0000000
  %502 = fmul fast float %488, 0x400370A3E0000000
  %503 = fmul fast float %489, 0x400370A3E0000000
  %504 = fadd fast float %501, 0x3FE2E147A0000000
  %505 = fadd fast float %502, 0x3FE2E147A0000000
  %506 = fadd fast float %503, 0x3FE2E147A0000000
  %507 = fmul fast float %504, %487
  %508 = fmul fast float %505, %488
  %509 = fmul fast float %506, %489
  %510 = fadd fast float %507, 0x3FC1EB8520000000
  %511 = fadd fast float %508, 0x3FC1EB8520000000
  %512 = fadd fast float %509, 0x3FC1EB8520000000
  %513 = fdiv fast float %498, %510
  %514 = fdiv fast float %499, %511
  %515 = fdiv fast float %500, %512
  br label %516

; <label>:516                                     ; preds = %491, %477
  %517 = phi float [ %513, %491 ], [ %487, %477 ]
  %518 = phi float [ %514, %491 ], [ %488, %477 ]
  %519 = phi float [ %515, %491 ], [ %489, %477 ]
  %520 = call float @dx.op.unary.f32(i32 7, float %517)  ; Saturate(value)
  %521 = call float @dx.op.unary.f32(i32 7, float %518)  ; Saturate(value)
  %522 = call float @dx.op.unary.f32(i32 7, float %519)  ; Saturate(value)
  %523 = call float @dx.op.dot3.f32(i32 55, float %520, float %521, float %522, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %524 = fsub fast float %520, %523
  %525 = fsub fast float %521, %523
  %526 = fsub fast float %522, %523
  %527 = fmul fast float %524, %8
  %528 = fmul fast float %525, %8
  %529 = fmul fast float %526, %8
  %530 = fadd fast float %527, %523
  %531 = fadd fast float %528, %523
  %532 = fadd fast float %529, %523
  %533 = call float @dx.op.unary.f32(i32 7, float %530)  ; Saturate(value)
  %534 = call float @dx.op.unary.f32(i32 7, float %531)  ; Saturate(value)
  %535 = call float @dx.op.unary.f32(i32 7, float %532)  ; Saturate(value)
  %536 = fadd fast float %533, 0xBFC70A3D80000000
  %537 = fadd fast float %534, 0xBFC70A3D80000000
  %538 = fadd fast float %535, 0xBFC70A3D80000000
  %539 = fmul fast float %536, %7
  %540 = fmul fast float %537, %7
  %541 = fmul fast float %538, %7
  %542 = fadd fast float %539, 0x3FC70A3D80000000
  %543 = fadd fast float %540, 0x3FC70A3D80000000
  %544 = fadd fast float %541, 0x3FC70A3D80000000
  %545 = call float @dx.op.unary.f32(i32 7, float %542)  ; Saturate(value)
  %546 = call float @dx.op.unary.f32(i32 7, float %543)  ; Saturate(value)
  %547 = call float @dx.op.unary.f32(i32 7, float %544)  ; Saturate(value)
  br label %548

; <label>:548                                     ; preds = %516, %299
  %549 = phi float [ %330, %299 ], [ %545, %516 ]
  %550 = phi float [ %331, %299 ], [ %546, %516 ]
  %551 = phi float [ %332, %299 ], [ %547, %516 ]
  %552 = add i32 %64, 1
  %553 = call i32 @dx.op.binary.i32(i32 37, i32 %552, i32 0)  ; IMax(a,b)
  %554 = call i32 @dx.op.binary.i32(i32 38, i32 %553, i32 %60)  ; IMin(a,b)
  %555 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %291, i32 %554, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %556 = extractvalue %dx.types.ResRet.f32 %555, 0
  %557 = extractvalue %dx.types.ResRet.f32 %555, 1
  %558 = extractvalue %dx.types.ResRet.f32 %555, 2
  %559 = extractvalue %dx.types.ResRet.f32 %555, 3
  %560 = fcmp fast olt float %559, 0.000000e+00
  br i1 %560, label %561, label %595

; <label>:561                                     ; preds = %548
  %562 = fcmp fast ogt float %556, 0x3FA4B5DCC0000000
  %563 = fcmp fast ogt float %557, 0x3FA4B5DCC0000000
  %564 = fcmp fast ogt float %558, 0x3FA4B5DCC0000000
  %565 = select i1 %562, float 0.000000e+00, float 1.000000e+00
  %566 = select i1 %563, float 0.000000e+00, float 1.000000e+00
  %567 = select i1 %564, float 0.000000e+00, float 1.000000e+00
  %568 = fmul fast float %556, 0x3FB3D07220000000
  %569 = fmul fast float %557, 0x3FB3D07220000000
  %570 = fmul fast float %558, 0x3FB3D07220000000
  %571 = fadd fast float %556, 0x3FAC28F5C0000000
  %572 = fadd fast float %557, 0x3FAC28F5C0000000
  %573 = fadd fast float %558, 0x3FAC28F5C0000000
  %574 = fmul fast float %571, 0x3FEE54EDE0000000
  %575 = fmul fast float %572, 0x3FEE54EDE0000000
  %576 = fmul fast float %573, 0x3FEE54EDE0000000
  %577 = call float @dx.op.unary.f32(i32 23, float %574)  ; Log(value)
  %578 = call float @dx.op.unary.f32(i32 23, float %575)  ; Log(value)
  %579 = call float @dx.op.unary.f32(i32 23, float %576)  ; Log(value)
  %580 = fmul fast float %577, 0x4003333340000000
  %581 = fmul fast float %578, 0x4003333340000000
  %582 = fmul fast float %579, 0x4003333340000000
  %583 = call float @dx.op.unary.f32(i32 21, float %580)  ; Exp(value)
  %584 = call float @dx.op.unary.f32(i32 21, float %581)  ; Exp(value)
  %585 = call float @dx.op.unary.f32(i32 21, float %582)  ; Exp(value)
  %586 = fsub fast float %568, %583
  %587 = fsub fast float %569, %584
  %588 = fsub fast float %570, %585
  %589 = fmul fast float %586, %565
  %590 = fmul fast float %587, %566
  %591 = fmul fast float %588, %567
  %592 = fadd fast float %589, %583
  %593 = fadd fast float %590, %584
  %594 = fadd fast float %591, %585
  br label %810

; <label>:595                                     ; preds = %548
  %596 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %291, i32 %554, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %597 = extractvalue %dx.types.ResRet.f32 %596, 0
  %598 = fcmp fast ogt float %38, 5.000000e-01
  %599 = fcmp fast olt float %597, 1.000000e+00
  %600 = and i1 %598, %599
  br i1 %600, label %601, label %739

; <label>:601                                     ; preds = %595
  %602 = sitofp i32 %291 to float
  %603 = sitofp i32 %554 to float
  %604 = fadd fast float %602, 5.000000e-01
  %605 = fadd fast float %603, 5.000000e-01
  %606 = fdiv fast float %604, %45
  %607 = fdiv fast float %605, %46
  %608 = fmul fast float %606, 2.000000e+00
  %609 = fmul fast float %607, 2.000000e+00
  %610 = fadd fast float %608, -1.000000e+00
  %611 = fsub fast float 1.000000e+00, %609
  %612 = fmul fast float %610, %35
  %613 = call float @dx.op.tertiary.f32(i32 46, float %611, float %31, float %612)  ; FMad(a,b,c)
  %614 = call float @dx.op.tertiary.f32(i32 46, float %597, float %27, float %613)  ; FMad(a,b,c)
  %615 = fadd fast float %614, %23
  %616 = call float @dx.op.unary.f32(i32 6, float %615)  ; FAbs(value)
  %617 = fcmp fast ogt float %616, 0x3EB0C6F7A0000000
  br i1 %617, label %618, label %739

; <label>:618                                     ; preds = %601
  %619 = fmul fast float %610, %34
  %620 = call float @dx.op.tertiary.f32(i32 46, float %611, float %30, float %619)  ; FMad(a,b,c)
  %621 = call float @dx.op.tertiary.f32(i32 46, float %597, float %26, float %620)  ; FMad(a,b,c)
  %622 = fadd fast float %621, %22
  %623 = fmul fast float %610, %33
  %624 = call float @dx.op.tertiary.f32(i32 46, float %611, float %29, float %623)  ; FMad(a,b,c)
  %625 = call float @dx.op.tertiary.f32(i32 46, float %597, float %25, float %624)  ; FMad(a,b,c)
  %626 = fadd fast float %625, %21
  %627 = fmul fast float %610, %32
  %628 = call float @dx.op.tertiary.f32(i32 46, float %611, float %28, float %627)  ; FMad(a,b,c)
  %629 = call float @dx.op.tertiary.f32(i32 46, float %597, float %24, float %628)  ; FMad(a,b,c)
  %630 = fadd fast float %629, %20
  %631 = fdiv fast float %630, %615
  %632 = fdiv fast float %626, %615
  %633 = fdiv fast float %622, %615
  %634 = fsub fast float %631, %17
  %635 = fsub fast float %632, %18
  %636 = fsub fast float %633, %19
  %637 = fmul fast float %634, %634
  %638 = fmul fast float %635, %635
  %639 = fadd fast float %638, %637
  %640 = fmul fast float %636, %636
  %641 = fadd fast float %639, %640
  %642 = call float @dx.op.unary.f32(i32 24, float %641)  ; Sqrt(value)
  %643 = fsub fast float %642, %9
  %644 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %643)  ; FMax(a,b)
  %645 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %645, label %646, label %669

; <label>:646                                     ; preds = %618
  %647 = call float @dx.op.unary.f32(i32 6, float %635)  ; FAbs(value)
  %648 = fmul fast float %647, %11
  %649 = fcmp fast olt float %648, 0x3F50624DE0000000
  br i1 %649, label %650, label %653

; <label>:650                                     ; preds = %646
  %651 = fmul fast float %648, 5.000000e-01
  %652 = fsub fast float 1.000000e+00, %651
  br label %658

; <label>:653                                     ; preds = %646
  %654 = fmul fast float %648, 0xBFF7154760000000
  %655 = call float @dx.op.unary.f32(i32 21, float %654)  ; Exp(value)
  %656 = fsub fast float 1.000000e+00, %655
  %657 = fdiv fast float %656, %648
  br label %658

; <label>:658                                     ; preds = %653, %650
  %659 = phi float [ %652, %650 ], [ %657, %653 ]
  %660 = call float @dx.op.binary.f32(i32 36, float %632, float %18)  ; FMin(a,b)
  %661 = fsub fast float %660, %10
  %662 = fmul fast float %11, %661
  %663 = fsub fast float -0.000000e+00, %662
  %664 = call float @dx.op.binary.f32(i32 35, float %663, float -4.000000e+01)  ; FMax(a,b)
  %665 = call float @dx.op.binary.f32(i32 36, float %664, float 5.000000e+00)  ; FMin(a,b)
  %666 = fmul fast float %665, 0x3FF7154760000000
  %667 = call float @dx.op.unary.f32(i32 21, float %666)  ; Exp(value)
  %668 = fmul fast float %667, %659
  br label %669

; <label>:669                                     ; preds = %658, %618
  %670 = phi float [ %668, %658 ], [ 1.000000e+00, %618 ]
  %671 = fmul fast float %644, %16
  %672 = fmul fast float %671, %670
  %673 = fcmp fast ole float %642, %9
  %674 = fcmp fast olt float %642, 0x3F1A36E2E0000000
  %675 = or i1 %673, %674
  br i1 %675, label %722, label %676

; <label>:676                                     ; preds = %669
  %677 = fdiv fast float %9, %642
  %678 = fmul fast float %677, %634
  %679 = fmul fast float %677, %635
  %680 = fmul fast float %677, %636
  %681 = fadd fast float %678, %17
  %682 = fadd fast float %679, %18
  %683 = fadd fast float %680, %19
  %684 = fadd fast float %681, -9.000000e+02
  %685 = fadd fast float %682, -1.500000e+01
  %686 = fadd fast float %683, -7.500000e+02
  %687 = fmul fast float %684, 0x3F62345680000000
  %688 = fmul fast float %685, 0x3F62345680000000
  %689 = fmul fast float %686, 0x3F62345680000000
  %690 = call float @dx.op.dot3.f32(i32 55, float %687, float %688, float %689, float %687, float %688, float %689)  ; Dot3(ax,ay,az,bx,by,bz)
  %691 = fsub fast float 1.000000e+00, %690
  %692 = call float @dx.op.unary.f32(i32 7, float %691)  ; Saturate(value)
  %693 = fmul fast float %692, %692
  %694 = fadd fast float %681, %631
  %695 = fadd fast float %682, %632
  %696 = fadd fast float %683, %633
  %697 = fmul fast float %694, 0x3F52345680000000
  %698 = fadd fast float %697, -2.000000e+00
  %699 = fmul fast float %695, 0x3F52345680000000
  %700 = fadd fast float %699, 0xBFA1111120000000
  %701 = fmul fast float %696, 0x3F52345680000000
  %702 = fadd fast float %701, 0xBFFAAAAAC0000000
  %703 = call float @dx.op.dot3.f32(i32 55, float %698, float %700, float %702, float %698, float %700, float %702)  ; Dot3(ax,ay,az,bx,by,bz)
  %704 = fsub fast float 1.000000e+00, %703
  %705 = call float @dx.op.unary.f32(i32 7, float %704)  ; Saturate(value)
  %706 = fmul fast float %705, %705
  %707 = fmul fast float %706, 4.000000e+00
  %708 = fadd fast float %707, %693
  %709 = fadd fast float %631, -9.000000e+02
  %710 = fadd fast float %632, -1.500000e+01
  %711 = fadd fast float %633, -7.500000e+02
  %712 = fmul fast float %709, 0x3F62345680000000
  %713 = fmul fast float %710, 0x3F62345680000000
  %714 = fmul fast float %711, 0x3F62345680000000
  %715 = call float @dx.op.dot3.f32(i32 55, float %712, float %713, float %714, float %712, float %713, float %714)  ; Dot3(ax,ay,az,bx,by,bz)
  %716 = fsub fast float 1.000000e+00, %715
  %717 = call float @dx.op.unary.f32(i32 7, float %716)  ; Saturate(value)
  %718 = fmul fast float %717, %717
  %719 = fadd fast float %708, %718
  %720 = fmul fast float %643, 0x3F25D867E0000000
  %721 = fmul fast float %720, %719
  br label %722

; <label>:722                                     ; preds = %676, %669
  %723 = phi float [ %721, %676 ], [ 0.000000e+00, %669 ]
  %724 = fadd fast float %723, %672
  %725 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %724)  ; FMin(a,b)
  %726 = fmul fast float %725, 0xBFF7154760000000
  %727 = call float @dx.op.unary.f32(i32 21, float %726)  ; Exp(value)
  %728 = fsub fast float 1.000000e+00, %727
  %729 = call float @dx.op.binary.f32(i32 36, float %12, float %728)  ; FMin(a,b)
  %730 = fsub fast float %13, %556
  %731 = fsub fast float %14, %557
  %732 = fsub fast float %15, %558
  %733 = fmul fast float %729, %730
  %734 = fmul fast float %729, %731
  %735 = fmul fast float %729, %732
  %736 = fadd fast float %733, %556
  %737 = fadd fast float %734, %557
  %738 = fadd fast float %735, %558
  br label %739

; <label>:739                                     ; preds = %722, %601, %595
  %740 = phi float [ %736, %722 ], [ %556, %601 ], [ %556, %595 ]
  %741 = phi float [ %737, %722 ], [ %557, %601 ], [ %557, %595 ]
  %742 = phi float [ %738, %722 ], [ %558, %601 ], [ %558, %595 ]
  %743 = fadd fast float %5, 1.000000e+00
  %744 = fadd fast float %6, 1.000000e+00
  %745 = fsub fast float 1.000000e+00, %5
  %746 = fmul fast float %36, %743
  %747 = fmul fast float %36, %744
  %748 = fmul fast float %36, %745
  %749 = fmul fast float %746, %740
  %750 = fmul fast float %747, %741
  %751 = fmul fast float %748, %742
  %752 = fcmp fast ult float %37, 5.000000e-01
  br i1 %752, label %778, label %753

; <label>:753                                     ; preds = %739
  %754 = fmul fast float %749, 0x4004147AE0000000
  %755 = fmul fast float %750, 0x4004147AE0000000
  %756 = fmul fast float %751, 0x4004147AE0000000
  %757 = fadd fast float %754, 0x3F9EB851E0000000
  %758 = fadd fast float %755, 0x3F9EB851E0000000
  %759 = fadd fast float %756, 0x3F9EB851E0000000
  %760 = fmul fast float %757, %749
  %761 = fmul fast float %758, %750
  %762 = fmul fast float %759, %751
  %763 = fmul fast float %749, 0x400370A3E0000000
  %764 = fmul fast float %750, 0x400370A3E0000000
  %765 = fmul fast float %751, 0x400370A3E0000000
  %766 = fadd fast float %763, 0x3FE2E147A0000000
  %767 = fadd fast float %764, 0x3FE2E147A0000000
  %768 = fadd fast float %765, 0x3FE2E147A0000000
  %769 = fmul fast float %766, %749
  %770 = fmul fast float %767, %750
  %771 = fmul fast float %768, %751
  %772 = fadd fast float %769, 0x3FC1EB8520000000
  %773 = fadd fast float %770, 0x3FC1EB8520000000
  %774 = fadd fast float %771, 0x3FC1EB8520000000
  %775 = fdiv fast float %760, %772
  %776 = fdiv fast float %761, %773
  %777 = fdiv fast float %762, %774
  br label %778

; <label>:778                                     ; preds = %753, %739
  %779 = phi float [ %775, %753 ], [ %749, %739 ]
  %780 = phi float [ %776, %753 ], [ %750, %739 ]
  %781 = phi float [ %777, %753 ], [ %751, %739 ]
  %782 = call float @dx.op.unary.f32(i32 7, float %779)  ; Saturate(value)
  %783 = call float @dx.op.unary.f32(i32 7, float %780)  ; Saturate(value)
  %784 = call float @dx.op.unary.f32(i32 7, float %781)  ; Saturate(value)
  %785 = call float @dx.op.dot3.f32(i32 55, float %782, float %783, float %784, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %786 = fsub fast float %782, %785
  %787 = fsub fast float %783, %785
  %788 = fsub fast float %784, %785
  %789 = fmul fast float %786, %8
  %790 = fmul fast float %787, %8
  %791 = fmul fast float %788, %8
  %792 = fadd fast float %789, %785
  %793 = fadd fast float %790, %785
  %794 = fadd fast float %791, %785
  %795 = call float @dx.op.unary.f32(i32 7, float %792)  ; Saturate(value)
  %796 = call float @dx.op.unary.f32(i32 7, float %793)  ; Saturate(value)
  %797 = call float @dx.op.unary.f32(i32 7, float %794)  ; Saturate(value)
  %798 = fadd fast float %795, 0xBFC70A3D80000000
  %799 = fadd fast float %796, 0xBFC70A3D80000000
  %800 = fadd fast float %797, 0xBFC70A3D80000000
  %801 = fmul fast float %798, %7
  %802 = fmul fast float %799, %7
  %803 = fmul fast float %800, %7
  %804 = fadd fast float %801, 0x3FC70A3D80000000
  %805 = fadd fast float %802, 0x3FC70A3D80000000
  %806 = fadd fast float %803, 0x3FC70A3D80000000
  %807 = call float @dx.op.unary.f32(i32 7, float %804)  ; Saturate(value)
  %808 = call float @dx.op.unary.f32(i32 7, float %805)  ; Saturate(value)
  %809 = call float @dx.op.unary.f32(i32 7, float %806)  ; Saturate(value)
  br label %810

; <label>:810                                     ; preds = %778, %561
  %811 = phi float [ %592, %561 ], [ %807, %778 ]
  %812 = phi float [ %593, %561 ], [ %808, %778 ]
  %813 = phi float [ %594, %561 ], [ %809, %778 ]
  %814 = add i32 %63, -1
  %815 = call i32 @dx.op.binary.i32(i32 37, i32 %814, i32 0)  ; IMax(a,b)
  %816 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %817 = call i32 @dx.op.binary.i32(i32 38, i32 %815, i32 %59)  ; IMin(a,b)
  %818 = call i32 @dx.op.binary.i32(i32 38, i32 %816, i32 %60)  ; IMin(a,b)
  %819 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %817, i32 %818, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %820 = extractvalue %dx.types.ResRet.f32 %819, 0
  %821 = extractvalue %dx.types.ResRet.f32 %819, 1
  %822 = extractvalue %dx.types.ResRet.f32 %819, 2
  %823 = extractvalue %dx.types.ResRet.f32 %819, 3
  %824 = fcmp fast olt float %823, 0.000000e+00
  br i1 %824, label %825, label %859

; <label>:825                                     ; preds = %810
  %826 = fcmp fast ogt float %820, 0x3FA4B5DCC0000000
  %827 = fcmp fast ogt float %821, 0x3FA4B5DCC0000000
  %828 = fcmp fast ogt float %822, 0x3FA4B5DCC0000000
  %829 = select i1 %826, float 0.000000e+00, float 1.000000e+00
  %830 = select i1 %827, float 0.000000e+00, float 1.000000e+00
  %831 = select i1 %828, float 0.000000e+00, float 1.000000e+00
  %832 = fmul fast float %820, 0x3FB3D07220000000
  %833 = fmul fast float %821, 0x3FB3D07220000000
  %834 = fmul fast float %822, 0x3FB3D07220000000
  %835 = fadd fast float %820, 0x3FAC28F5C0000000
  %836 = fadd fast float %821, 0x3FAC28F5C0000000
  %837 = fadd fast float %822, 0x3FAC28F5C0000000
  %838 = fmul fast float %835, 0x3FEE54EDE0000000
  %839 = fmul fast float %836, 0x3FEE54EDE0000000
  %840 = fmul fast float %837, 0x3FEE54EDE0000000
  %841 = call float @dx.op.unary.f32(i32 23, float %838)  ; Log(value)
  %842 = call float @dx.op.unary.f32(i32 23, float %839)  ; Log(value)
  %843 = call float @dx.op.unary.f32(i32 23, float %840)  ; Log(value)
  %844 = fmul fast float %841, 0x4003333340000000
  %845 = fmul fast float %842, 0x4003333340000000
  %846 = fmul fast float %843, 0x4003333340000000
  %847 = call float @dx.op.unary.f32(i32 21, float %844)  ; Exp(value)
  %848 = call float @dx.op.unary.f32(i32 21, float %845)  ; Exp(value)
  %849 = call float @dx.op.unary.f32(i32 21, float %846)  ; Exp(value)
  %850 = fsub fast float %832, %847
  %851 = fsub fast float %833, %848
  %852 = fsub fast float %834, %849
  %853 = fmul fast float %850, %829
  %854 = fmul fast float %851, %830
  %855 = fmul fast float %852, %831
  %856 = fadd fast float %853, %847
  %857 = fadd fast float %854, %848
  %858 = fadd fast float %855, %849
  br label %1074

; <label>:859                                     ; preds = %810
  %860 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %817, i32 %818, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %861 = extractvalue %dx.types.ResRet.f32 %860, 0
  %862 = fcmp fast ogt float %38, 5.000000e-01
  %863 = fcmp fast olt float %861, 1.000000e+00
  %864 = and i1 %862, %863
  br i1 %864, label %865, label %1003

; <label>:865                                     ; preds = %859
  %866 = sitofp i32 %817 to float
  %867 = sitofp i32 %818 to float
  %868 = fadd fast float %866, 5.000000e-01
  %869 = fadd fast float %867, 5.000000e-01
  %870 = fdiv fast float %868, %45
  %871 = fdiv fast float %869, %46
  %872 = fmul fast float %870, 2.000000e+00
  %873 = fmul fast float %871, 2.000000e+00
  %874 = fadd fast float %872, -1.000000e+00
  %875 = fsub fast float 1.000000e+00, %873
  %876 = fmul fast float %874, %35
  %877 = call float @dx.op.tertiary.f32(i32 46, float %875, float %31, float %876)  ; FMad(a,b,c)
  %878 = call float @dx.op.tertiary.f32(i32 46, float %861, float %27, float %877)  ; FMad(a,b,c)
  %879 = fadd fast float %878, %23
  %880 = call float @dx.op.unary.f32(i32 6, float %879)  ; FAbs(value)
  %881 = fcmp fast ogt float %880, 0x3EB0C6F7A0000000
  br i1 %881, label %882, label %1003

; <label>:882                                     ; preds = %865
  %883 = fmul fast float %874, %34
  %884 = call float @dx.op.tertiary.f32(i32 46, float %875, float %30, float %883)  ; FMad(a,b,c)
  %885 = call float @dx.op.tertiary.f32(i32 46, float %861, float %26, float %884)  ; FMad(a,b,c)
  %886 = fadd fast float %885, %22
  %887 = fmul fast float %874, %33
  %888 = call float @dx.op.tertiary.f32(i32 46, float %875, float %29, float %887)  ; FMad(a,b,c)
  %889 = call float @dx.op.tertiary.f32(i32 46, float %861, float %25, float %888)  ; FMad(a,b,c)
  %890 = fadd fast float %889, %21
  %891 = fmul fast float %874, %32
  %892 = call float @dx.op.tertiary.f32(i32 46, float %875, float %28, float %891)  ; FMad(a,b,c)
  %893 = call float @dx.op.tertiary.f32(i32 46, float %861, float %24, float %892)  ; FMad(a,b,c)
  %894 = fadd fast float %893, %20
  %895 = fdiv fast float %894, %879
  %896 = fdiv fast float %890, %879
  %897 = fdiv fast float %886, %879
  %898 = fsub fast float %895, %17
  %899 = fsub fast float %896, %18
  %900 = fsub fast float %897, %19
  %901 = fmul fast float %898, %898
  %902 = fmul fast float %899, %899
  %903 = fadd fast float %902, %901
  %904 = fmul fast float %900, %900
  %905 = fadd fast float %903, %904
  %906 = call float @dx.op.unary.f32(i32 24, float %905)  ; Sqrt(value)
  %907 = fsub fast float %906, %9
  %908 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %907)  ; FMax(a,b)
  %909 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %909, label %910, label %933

; <label>:910                                     ; preds = %882
  %911 = call float @dx.op.unary.f32(i32 6, float %899)  ; FAbs(value)
  %912 = fmul fast float %911, %11
  %913 = fcmp fast olt float %912, 0x3F50624DE0000000
  br i1 %913, label %914, label %917

; <label>:914                                     ; preds = %910
  %915 = fmul fast float %912, 5.000000e-01
  %916 = fsub fast float 1.000000e+00, %915
  br label %922

; <label>:917                                     ; preds = %910
  %918 = fmul fast float %912, 0xBFF7154760000000
  %919 = call float @dx.op.unary.f32(i32 21, float %918)  ; Exp(value)
  %920 = fsub fast float 1.000000e+00, %919
  %921 = fdiv fast float %920, %912
  br label %922

; <label>:922                                     ; preds = %917, %914
  %923 = phi float [ %916, %914 ], [ %921, %917 ]
  %924 = call float @dx.op.binary.f32(i32 36, float %896, float %18)  ; FMin(a,b)
  %925 = fsub fast float %924, %10
  %926 = fmul fast float %11, %925
  %927 = fsub fast float -0.000000e+00, %926
  %928 = call float @dx.op.binary.f32(i32 35, float %927, float -4.000000e+01)  ; FMax(a,b)
  %929 = call float @dx.op.binary.f32(i32 36, float %928, float 5.000000e+00)  ; FMin(a,b)
  %930 = fmul fast float %929, 0x3FF7154760000000
  %931 = call float @dx.op.unary.f32(i32 21, float %930)  ; Exp(value)
  %932 = fmul fast float %931, %923
  br label %933

; <label>:933                                     ; preds = %922, %882
  %934 = phi float [ %932, %922 ], [ 1.000000e+00, %882 ]
  %935 = fmul fast float %908, %16
  %936 = fmul fast float %935, %934
  %937 = fcmp fast ole float %906, %9
  %938 = fcmp fast olt float %906, 0x3F1A36E2E0000000
  %939 = or i1 %937, %938
  br i1 %939, label %986, label %940

; <label>:940                                     ; preds = %933
  %941 = fdiv fast float %9, %906
  %942 = fmul fast float %941, %898
  %943 = fmul fast float %941, %899
  %944 = fmul fast float %941, %900
  %945 = fadd fast float %942, %17
  %946 = fadd fast float %943, %18
  %947 = fadd fast float %944, %19
  %948 = fadd fast float %945, -9.000000e+02
  %949 = fadd fast float %946, -1.500000e+01
  %950 = fadd fast float %947, -7.500000e+02
  %951 = fmul fast float %948, 0x3F62345680000000
  %952 = fmul fast float %949, 0x3F62345680000000
  %953 = fmul fast float %950, 0x3F62345680000000
  %954 = call float @dx.op.dot3.f32(i32 55, float %951, float %952, float %953, float %951, float %952, float %953)  ; Dot3(ax,ay,az,bx,by,bz)
  %955 = fsub fast float 1.000000e+00, %954
  %956 = call float @dx.op.unary.f32(i32 7, float %955)  ; Saturate(value)
  %957 = fmul fast float %956, %956
  %958 = fadd fast float %945, %895
  %959 = fadd fast float %946, %896
  %960 = fadd fast float %947, %897
  %961 = fmul fast float %958, 0x3F52345680000000
  %962 = fadd fast float %961, -2.000000e+00
  %963 = fmul fast float %959, 0x3F52345680000000
  %964 = fadd fast float %963, 0xBFA1111120000000
  %965 = fmul fast float %960, 0x3F52345680000000
  %966 = fadd fast float %965, 0xBFFAAAAAC0000000
  %967 = call float @dx.op.dot3.f32(i32 55, float %962, float %964, float %966, float %962, float %964, float %966)  ; Dot3(ax,ay,az,bx,by,bz)
  %968 = fsub fast float 1.000000e+00, %967
  %969 = call float @dx.op.unary.f32(i32 7, float %968)  ; Saturate(value)
  %970 = fmul fast float %969, %969
  %971 = fmul fast float %970, 4.000000e+00
  %972 = fadd fast float %971, %957
  %973 = fadd fast float %895, -9.000000e+02
  %974 = fadd fast float %896, -1.500000e+01
  %975 = fadd fast float %897, -7.500000e+02
  %976 = fmul fast float %973, 0x3F62345680000000
  %977 = fmul fast float %974, 0x3F62345680000000
  %978 = fmul fast float %975, 0x3F62345680000000
  %979 = call float @dx.op.dot3.f32(i32 55, float %976, float %977, float %978, float %976, float %977, float %978)  ; Dot3(ax,ay,az,bx,by,bz)
  %980 = fsub fast float 1.000000e+00, %979
  %981 = call float @dx.op.unary.f32(i32 7, float %980)  ; Saturate(value)
  %982 = fmul fast float %981, %981
  %983 = fadd fast float %972, %982
  %984 = fmul fast float %907, 0x3F25D867E0000000
  %985 = fmul fast float %984, %983
  br label %986

; <label>:986                                     ; preds = %940, %933
  %987 = phi float [ %985, %940 ], [ 0.000000e+00, %933 ]
  %988 = fadd fast float %987, %936
  %989 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %988)  ; FMin(a,b)
  %990 = fmul fast float %989, 0xBFF7154760000000
  %991 = call float @dx.op.unary.f32(i32 21, float %990)  ; Exp(value)
  %992 = fsub fast float 1.000000e+00, %991
  %993 = call float @dx.op.binary.f32(i32 36, float %12, float %992)  ; FMin(a,b)
  %994 = fsub fast float %13, %820
  %995 = fsub fast float %14, %821
  %996 = fsub fast float %15, %822
  %997 = fmul fast float %993, %994
  %998 = fmul fast float %993, %995
  %999 = fmul fast float %993, %996
  %1000 = fadd fast float %997, %820
  %1001 = fadd fast float %998, %821
  %1002 = fadd fast float %999, %822
  br label %1003

; <label>:1003                                    ; preds = %986, %865, %859
  %1004 = phi float [ %1000, %986 ], [ %820, %865 ], [ %820, %859 ]
  %1005 = phi float [ %1001, %986 ], [ %821, %865 ], [ %821, %859 ]
  %1006 = phi float [ %1002, %986 ], [ %822, %865 ], [ %822, %859 ]
  %1007 = fadd fast float %5, 1.000000e+00
  %1008 = fadd fast float %6, 1.000000e+00
  %1009 = fsub fast float 1.000000e+00, %5
  %1010 = fmul fast float %36, %1007
  %1011 = fmul fast float %36, %1008
  %1012 = fmul fast float %36, %1009
  %1013 = fmul fast float %1010, %1004
  %1014 = fmul fast float %1011, %1005
  %1015 = fmul fast float %1012, %1006
  %1016 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1016, label %1042, label %1017

; <label>:1017                                    ; preds = %1003
  %1018 = fmul fast float %1013, 0x4004147AE0000000
  %1019 = fmul fast float %1014, 0x4004147AE0000000
  %1020 = fmul fast float %1015, 0x4004147AE0000000
  %1021 = fadd fast float %1018, 0x3F9EB851E0000000
  %1022 = fadd fast float %1019, 0x3F9EB851E0000000
  %1023 = fadd fast float %1020, 0x3F9EB851E0000000
  %1024 = fmul fast float %1021, %1013
  %1025 = fmul fast float %1022, %1014
  %1026 = fmul fast float %1023, %1015
  %1027 = fmul fast float %1013, 0x400370A3E0000000
  %1028 = fmul fast float %1014, 0x400370A3E0000000
  %1029 = fmul fast float %1015, 0x400370A3E0000000
  %1030 = fadd fast float %1027, 0x3FE2E147A0000000
  %1031 = fadd fast float %1028, 0x3FE2E147A0000000
  %1032 = fadd fast float %1029, 0x3FE2E147A0000000
  %1033 = fmul fast float %1030, %1013
  %1034 = fmul fast float %1031, %1014
  %1035 = fmul fast float %1032, %1015
  %1036 = fadd fast float %1033, 0x3FC1EB8520000000
  %1037 = fadd fast float %1034, 0x3FC1EB8520000000
  %1038 = fadd fast float %1035, 0x3FC1EB8520000000
  %1039 = fdiv fast float %1024, %1036
  %1040 = fdiv fast float %1025, %1037
  %1041 = fdiv fast float %1026, %1038
  br label %1042

; <label>:1042                                    ; preds = %1017, %1003
  %1043 = phi float [ %1039, %1017 ], [ %1013, %1003 ]
  %1044 = phi float [ %1040, %1017 ], [ %1014, %1003 ]
  %1045 = phi float [ %1041, %1017 ], [ %1015, %1003 ]
  %1046 = call float @dx.op.unary.f32(i32 7, float %1043)  ; Saturate(value)
  %1047 = call float @dx.op.unary.f32(i32 7, float %1044)  ; Saturate(value)
  %1048 = call float @dx.op.unary.f32(i32 7, float %1045)  ; Saturate(value)
  %1049 = call float @dx.op.dot3.f32(i32 55, float %1046, float %1047, float %1048, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1050 = fsub fast float %1046, %1049
  %1051 = fsub fast float %1047, %1049
  %1052 = fsub fast float %1048, %1049
  %1053 = fmul fast float %1050, %8
  %1054 = fmul fast float %1051, %8
  %1055 = fmul fast float %1052, %8
  %1056 = fadd fast float %1053, %1049
  %1057 = fadd fast float %1054, %1049
  %1058 = fadd fast float %1055, %1049
  %1059 = call float @dx.op.unary.f32(i32 7, float %1056)  ; Saturate(value)
  %1060 = call float @dx.op.unary.f32(i32 7, float %1057)  ; Saturate(value)
  %1061 = call float @dx.op.unary.f32(i32 7, float %1058)  ; Saturate(value)
  %1062 = fadd fast float %1059, 0xBFC70A3D80000000
  %1063 = fadd fast float %1060, 0xBFC70A3D80000000
  %1064 = fadd fast float %1061, 0xBFC70A3D80000000
  %1065 = fmul fast float %1062, %7
  %1066 = fmul fast float %1063, %7
  %1067 = fmul fast float %1064, %7
  %1068 = fadd fast float %1065, 0x3FC70A3D80000000
  %1069 = fadd fast float %1066, 0x3FC70A3D80000000
  %1070 = fadd fast float %1067, 0x3FC70A3D80000000
  %1071 = call float @dx.op.unary.f32(i32 7, float %1068)  ; Saturate(value)
  %1072 = call float @dx.op.unary.f32(i32 7, float %1069)  ; Saturate(value)
  %1073 = call float @dx.op.unary.f32(i32 7, float %1070)  ; Saturate(value)
  br label %1074

; <label>:1074                                    ; preds = %1042, %825
  %1075 = phi float [ %856, %825 ], [ %1071, %1042 ]
  %1076 = phi float [ %857, %825 ], [ %1072, %1042 ]
  %1077 = phi float [ %858, %825 ], [ %1073, %1042 ]
  %1078 = add i32 %63, 1
  %1079 = call i32 @dx.op.binary.i32(i32 37, i32 %1078, i32 0)  ; IMax(a,b)
  %1080 = call i32 @dx.op.binary.i32(i32 38, i32 %1079, i32 %59)  ; IMin(a,b)
  %1081 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1080, i32 %818, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1082 = extractvalue %dx.types.ResRet.f32 %1081, 0
  %1083 = extractvalue %dx.types.ResRet.f32 %1081, 1
  %1084 = extractvalue %dx.types.ResRet.f32 %1081, 2
  %1085 = extractvalue %dx.types.ResRet.f32 %1081, 3
  %1086 = fcmp fast olt float %1085, 0.000000e+00
  br i1 %1086, label %1087, label %1121

; <label>:1087                                    ; preds = %1074
  %1088 = fcmp fast ogt float %1082, 0x3FA4B5DCC0000000
  %1089 = fcmp fast ogt float %1083, 0x3FA4B5DCC0000000
  %1090 = fcmp fast ogt float %1084, 0x3FA4B5DCC0000000
  %1091 = select i1 %1088, float 0.000000e+00, float 1.000000e+00
  %1092 = select i1 %1089, float 0.000000e+00, float 1.000000e+00
  %1093 = select i1 %1090, float 0.000000e+00, float 1.000000e+00
  %1094 = fmul fast float %1082, 0x3FB3D07220000000
  %1095 = fmul fast float %1083, 0x3FB3D07220000000
  %1096 = fmul fast float %1084, 0x3FB3D07220000000
  %1097 = fadd fast float %1082, 0x3FAC28F5C0000000
  %1098 = fadd fast float %1083, 0x3FAC28F5C0000000
  %1099 = fadd fast float %1084, 0x3FAC28F5C0000000
  %1100 = fmul fast float %1097, 0x3FEE54EDE0000000
  %1101 = fmul fast float %1098, 0x3FEE54EDE0000000
  %1102 = fmul fast float %1099, 0x3FEE54EDE0000000
  %1103 = call float @dx.op.unary.f32(i32 23, float %1100)  ; Log(value)
  %1104 = call float @dx.op.unary.f32(i32 23, float %1101)  ; Log(value)
  %1105 = call float @dx.op.unary.f32(i32 23, float %1102)  ; Log(value)
  %1106 = fmul fast float %1103, 0x4003333340000000
  %1107 = fmul fast float %1104, 0x4003333340000000
  %1108 = fmul fast float %1105, 0x4003333340000000
  %1109 = call float @dx.op.unary.f32(i32 21, float %1106)  ; Exp(value)
  %1110 = call float @dx.op.unary.f32(i32 21, float %1107)  ; Exp(value)
  %1111 = call float @dx.op.unary.f32(i32 21, float %1108)  ; Exp(value)
  %1112 = fsub fast float %1094, %1109
  %1113 = fsub fast float %1095, %1110
  %1114 = fsub fast float %1096, %1111
  %1115 = fmul fast float %1112, %1091
  %1116 = fmul fast float %1113, %1092
  %1117 = fmul fast float %1114, %1093
  %1118 = fadd fast float %1115, %1109
  %1119 = fadd fast float %1116, %1110
  %1120 = fadd fast float %1117, %1111
  br label %1336

; <label>:1121                                    ; preds = %1074
  %1122 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1080, i32 %818, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1123 = extractvalue %dx.types.ResRet.f32 %1122, 0
  %1124 = fcmp fast ogt float %38, 5.000000e-01
  %1125 = fcmp fast olt float %1123, 1.000000e+00
  %1126 = and i1 %1124, %1125
  br i1 %1126, label %1127, label %1265

; <label>:1127                                    ; preds = %1121
  %1128 = sitofp i32 %1080 to float
  %1129 = sitofp i32 %818 to float
  %1130 = fadd fast float %1128, 5.000000e-01
  %1131 = fadd fast float %1129, 5.000000e-01
  %1132 = fdiv fast float %1130, %45
  %1133 = fdiv fast float %1131, %46
  %1134 = fmul fast float %1132, 2.000000e+00
  %1135 = fmul fast float %1133, 2.000000e+00
  %1136 = fadd fast float %1134, -1.000000e+00
  %1137 = fsub fast float 1.000000e+00, %1135
  %1138 = fmul fast float %1136, %35
  %1139 = call float @dx.op.tertiary.f32(i32 46, float %1137, float %31, float %1138)  ; FMad(a,b,c)
  %1140 = call float @dx.op.tertiary.f32(i32 46, float %1123, float %27, float %1139)  ; FMad(a,b,c)
  %1141 = fadd fast float %1140, %23
  %1142 = call float @dx.op.unary.f32(i32 6, float %1141)  ; FAbs(value)
  %1143 = fcmp fast ogt float %1142, 0x3EB0C6F7A0000000
  br i1 %1143, label %1144, label %1265

; <label>:1144                                    ; preds = %1127
  %1145 = fmul fast float %1136, %34
  %1146 = call float @dx.op.tertiary.f32(i32 46, float %1137, float %30, float %1145)  ; FMad(a,b,c)
  %1147 = call float @dx.op.tertiary.f32(i32 46, float %1123, float %26, float %1146)  ; FMad(a,b,c)
  %1148 = fadd fast float %1147, %22
  %1149 = fmul fast float %1136, %33
  %1150 = call float @dx.op.tertiary.f32(i32 46, float %1137, float %29, float %1149)  ; FMad(a,b,c)
  %1151 = call float @dx.op.tertiary.f32(i32 46, float %1123, float %25, float %1150)  ; FMad(a,b,c)
  %1152 = fadd fast float %1151, %21
  %1153 = fmul fast float %1136, %32
  %1154 = call float @dx.op.tertiary.f32(i32 46, float %1137, float %28, float %1153)  ; FMad(a,b,c)
  %1155 = call float @dx.op.tertiary.f32(i32 46, float %1123, float %24, float %1154)  ; FMad(a,b,c)
  %1156 = fadd fast float %1155, %20
  %1157 = fdiv fast float %1156, %1141
  %1158 = fdiv fast float %1152, %1141
  %1159 = fdiv fast float %1148, %1141
  %1160 = fsub fast float %1157, %17
  %1161 = fsub fast float %1158, %18
  %1162 = fsub fast float %1159, %19
  %1163 = fmul fast float %1160, %1160
  %1164 = fmul fast float %1161, %1161
  %1165 = fadd fast float %1164, %1163
  %1166 = fmul fast float %1162, %1162
  %1167 = fadd fast float %1165, %1166
  %1168 = call float @dx.op.unary.f32(i32 24, float %1167)  ; Sqrt(value)
  %1169 = fsub fast float %1168, %9
  %1170 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1169)  ; FMax(a,b)
  %1171 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1171, label %1172, label %1195

; <label>:1172                                    ; preds = %1144
  %1173 = call float @dx.op.unary.f32(i32 6, float %1161)  ; FAbs(value)
  %1174 = fmul fast float %1173, %11
  %1175 = fcmp fast olt float %1174, 0x3F50624DE0000000
  br i1 %1175, label %1176, label %1179

; <label>:1176                                    ; preds = %1172
  %1177 = fmul fast float %1174, 5.000000e-01
  %1178 = fsub fast float 1.000000e+00, %1177
  br label %1184

; <label>:1179                                    ; preds = %1172
  %1180 = fmul fast float %1174, 0xBFF7154760000000
  %1181 = call float @dx.op.unary.f32(i32 21, float %1180)  ; Exp(value)
  %1182 = fsub fast float 1.000000e+00, %1181
  %1183 = fdiv fast float %1182, %1174
  br label %1184

; <label>:1184                                    ; preds = %1179, %1176
  %1185 = phi float [ %1178, %1176 ], [ %1183, %1179 ]
  %1186 = call float @dx.op.binary.f32(i32 36, float %1158, float %18)  ; FMin(a,b)
  %1187 = fsub fast float %1186, %10
  %1188 = fmul fast float %11, %1187
  %1189 = fsub fast float -0.000000e+00, %1188
  %1190 = call float @dx.op.binary.f32(i32 35, float %1189, float -4.000000e+01)  ; FMax(a,b)
  %1191 = call float @dx.op.binary.f32(i32 36, float %1190, float 5.000000e+00)  ; FMin(a,b)
  %1192 = fmul fast float %1191, 0x3FF7154760000000
  %1193 = call float @dx.op.unary.f32(i32 21, float %1192)  ; Exp(value)
  %1194 = fmul fast float %1193, %1185
  br label %1195

; <label>:1195                                    ; preds = %1184, %1144
  %1196 = phi float [ %1194, %1184 ], [ 1.000000e+00, %1144 ]
  %1197 = fmul fast float %1170, %16
  %1198 = fmul fast float %1197, %1196
  %1199 = fcmp fast ole float %1168, %9
  %1200 = fcmp fast olt float %1168, 0x3F1A36E2E0000000
  %1201 = or i1 %1199, %1200
  br i1 %1201, label %1248, label %1202

; <label>:1202                                    ; preds = %1195
  %1203 = fdiv fast float %9, %1168
  %1204 = fmul fast float %1203, %1160
  %1205 = fmul fast float %1203, %1161
  %1206 = fmul fast float %1203, %1162
  %1207 = fadd fast float %1204, %17
  %1208 = fadd fast float %1205, %18
  %1209 = fadd fast float %1206, %19
  %1210 = fadd fast float %1207, -9.000000e+02
  %1211 = fadd fast float %1208, -1.500000e+01
  %1212 = fadd fast float %1209, -7.500000e+02
  %1213 = fmul fast float %1210, 0x3F62345680000000
  %1214 = fmul fast float %1211, 0x3F62345680000000
  %1215 = fmul fast float %1212, 0x3F62345680000000
  %1216 = call float @dx.op.dot3.f32(i32 55, float %1213, float %1214, float %1215, float %1213, float %1214, float %1215)  ; Dot3(ax,ay,az,bx,by,bz)
  %1217 = fsub fast float 1.000000e+00, %1216
  %1218 = call float @dx.op.unary.f32(i32 7, float %1217)  ; Saturate(value)
  %1219 = fmul fast float %1218, %1218
  %1220 = fadd fast float %1207, %1157
  %1221 = fadd fast float %1208, %1158
  %1222 = fadd fast float %1209, %1159
  %1223 = fmul fast float %1220, 0x3F52345680000000
  %1224 = fadd fast float %1223, -2.000000e+00
  %1225 = fmul fast float %1221, 0x3F52345680000000
  %1226 = fadd fast float %1225, 0xBFA1111120000000
  %1227 = fmul fast float %1222, 0x3F52345680000000
  %1228 = fadd fast float %1227, 0xBFFAAAAAC0000000
  %1229 = call float @dx.op.dot3.f32(i32 55, float %1224, float %1226, float %1228, float %1224, float %1226, float %1228)  ; Dot3(ax,ay,az,bx,by,bz)
  %1230 = fsub fast float 1.000000e+00, %1229
  %1231 = call float @dx.op.unary.f32(i32 7, float %1230)  ; Saturate(value)
  %1232 = fmul fast float %1231, %1231
  %1233 = fmul fast float %1232, 4.000000e+00
  %1234 = fadd fast float %1233, %1219
  %1235 = fadd fast float %1157, -9.000000e+02
  %1236 = fadd fast float %1158, -1.500000e+01
  %1237 = fadd fast float %1159, -7.500000e+02
  %1238 = fmul fast float %1235, 0x3F62345680000000
  %1239 = fmul fast float %1236, 0x3F62345680000000
  %1240 = fmul fast float %1237, 0x3F62345680000000
  %1241 = call float @dx.op.dot3.f32(i32 55, float %1238, float %1239, float %1240, float %1238, float %1239, float %1240)  ; Dot3(ax,ay,az,bx,by,bz)
  %1242 = fsub fast float 1.000000e+00, %1241
  %1243 = call float @dx.op.unary.f32(i32 7, float %1242)  ; Saturate(value)
  %1244 = fmul fast float %1243, %1243
  %1245 = fadd fast float %1234, %1244
  %1246 = fmul fast float %1169, 0x3F25D867E0000000
  %1247 = fmul fast float %1246, %1245
  br label %1248

; <label>:1248                                    ; preds = %1202, %1195
  %1249 = phi float [ %1247, %1202 ], [ 0.000000e+00, %1195 ]
  %1250 = fadd fast float %1249, %1198
  %1251 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1250)  ; FMin(a,b)
  %1252 = fmul fast float %1251, 0xBFF7154760000000
  %1253 = call float @dx.op.unary.f32(i32 21, float %1252)  ; Exp(value)
  %1254 = fsub fast float 1.000000e+00, %1253
  %1255 = call float @dx.op.binary.f32(i32 36, float %12, float %1254)  ; FMin(a,b)
  %1256 = fsub fast float %13, %1082
  %1257 = fsub fast float %14, %1083
  %1258 = fsub fast float %15, %1084
  %1259 = fmul fast float %1255, %1256
  %1260 = fmul fast float %1255, %1257
  %1261 = fmul fast float %1255, %1258
  %1262 = fadd fast float %1259, %1082
  %1263 = fadd fast float %1260, %1083
  %1264 = fadd fast float %1261, %1084
  br label %1265

; <label>:1265                                    ; preds = %1248, %1127, %1121
  %1266 = phi float [ %1262, %1248 ], [ %1082, %1127 ], [ %1082, %1121 ]
  %1267 = phi float [ %1263, %1248 ], [ %1083, %1127 ], [ %1083, %1121 ]
  %1268 = phi float [ %1264, %1248 ], [ %1084, %1127 ], [ %1084, %1121 ]
  %1269 = fadd fast float %5, 1.000000e+00
  %1270 = fadd fast float %6, 1.000000e+00
  %1271 = fsub fast float 1.000000e+00, %5
  %1272 = fmul fast float %36, %1269
  %1273 = fmul fast float %36, %1270
  %1274 = fmul fast float %36, %1271
  %1275 = fmul fast float %1272, %1266
  %1276 = fmul fast float %1273, %1267
  %1277 = fmul fast float %1274, %1268
  %1278 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1278, label %1304, label %1279

; <label>:1279                                    ; preds = %1265
  %1280 = fmul fast float %1275, 0x4004147AE0000000
  %1281 = fmul fast float %1276, 0x4004147AE0000000
  %1282 = fmul fast float %1277, 0x4004147AE0000000
  %1283 = fadd fast float %1280, 0x3F9EB851E0000000
  %1284 = fadd fast float %1281, 0x3F9EB851E0000000
  %1285 = fadd fast float %1282, 0x3F9EB851E0000000
  %1286 = fmul fast float %1283, %1275
  %1287 = fmul fast float %1284, %1276
  %1288 = fmul fast float %1285, %1277
  %1289 = fmul fast float %1275, 0x400370A3E0000000
  %1290 = fmul fast float %1276, 0x400370A3E0000000
  %1291 = fmul fast float %1277, 0x400370A3E0000000
  %1292 = fadd fast float %1289, 0x3FE2E147A0000000
  %1293 = fadd fast float %1290, 0x3FE2E147A0000000
  %1294 = fadd fast float %1291, 0x3FE2E147A0000000
  %1295 = fmul fast float %1292, %1275
  %1296 = fmul fast float %1293, %1276
  %1297 = fmul fast float %1294, %1277
  %1298 = fadd fast float %1295, 0x3FC1EB8520000000
  %1299 = fadd fast float %1296, 0x3FC1EB8520000000
  %1300 = fadd fast float %1297, 0x3FC1EB8520000000
  %1301 = fdiv fast float %1286, %1298
  %1302 = fdiv fast float %1287, %1299
  %1303 = fdiv fast float %1288, %1300
  br label %1304

; <label>:1304                                    ; preds = %1279, %1265
  %1305 = phi float [ %1301, %1279 ], [ %1275, %1265 ]
  %1306 = phi float [ %1302, %1279 ], [ %1276, %1265 ]
  %1307 = phi float [ %1303, %1279 ], [ %1277, %1265 ]
  %1308 = call float @dx.op.unary.f32(i32 7, float %1305)  ; Saturate(value)
  %1309 = call float @dx.op.unary.f32(i32 7, float %1306)  ; Saturate(value)
  %1310 = call float @dx.op.unary.f32(i32 7, float %1307)  ; Saturate(value)
  %1311 = call float @dx.op.dot3.f32(i32 55, float %1308, float %1309, float %1310, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1312 = fsub fast float %1308, %1311
  %1313 = fsub fast float %1309, %1311
  %1314 = fsub fast float %1310, %1311
  %1315 = fmul fast float %1312, %8
  %1316 = fmul fast float %1313, %8
  %1317 = fmul fast float %1314, %8
  %1318 = fadd fast float %1315, %1311
  %1319 = fadd fast float %1316, %1311
  %1320 = fadd fast float %1317, %1311
  %1321 = call float @dx.op.unary.f32(i32 7, float %1318)  ; Saturate(value)
  %1322 = call float @dx.op.unary.f32(i32 7, float %1319)  ; Saturate(value)
  %1323 = call float @dx.op.unary.f32(i32 7, float %1320)  ; Saturate(value)
  %1324 = fadd fast float %1321, 0xBFC70A3D80000000
  %1325 = fadd fast float %1322, 0xBFC70A3D80000000
  %1326 = fadd fast float %1323, 0xBFC70A3D80000000
  %1327 = fmul fast float %1324, %7
  %1328 = fmul fast float %1325, %7
  %1329 = fmul fast float %1326, %7
  %1330 = fadd fast float %1327, 0x3FC70A3D80000000
  %1331 = fadd fast float %1328, 0x3FC70A3D80000000
  %1332 = fadd fast float %1329, 0x3FC70A3D80000000
  %1333 = call float @dx.op.unary.f32(i32 7, float %1330)  ; Saturate(value)
  %1334 = call float @dx.op.unary.f32(i32 7, float %1331)  ; Saturate(value)
  %1335 = call float @dx.op.unary.f32(i32 7, float %1332)  ; Saturate(value)
  br label %1336

; <label>:1336                                    ; preds = %1304, %1087
  %1337 = phi float [ %1118, %1087 ], [ %1333, %1304 ]
  %1338 = phi float [ %1119, %1087 ], [ %1334, %1304 ]
  %1339 = phi float [ %1120, %1087 ], [ %1335, %1304 ]
  %1340 = call float @dx.op.binary.f32(i32 36, float %1075, float %1337)  ; FMin(a,b)
  %1341 = call float @dx.op.binary.f32(i32 36, float %1076, float %1338)  ; FMin(a,b)
  %1342 = call float @dx.op.binary.f32(i32 36, float %1077, float %1339)  ; FMin(a,b)
  %1343 = call float @dx.op.binary.f32(i32 36, float %549, float %811)  ; FMin(a,b)
  %1344 = call float @dx.op.binary.f32(i32 36, float %550, float %812)  ; FMin(a,b)
  %1345 = call float @dx.op.binary.f32(i32 36, float %551, float %813)  ; FMin(a,b)
  %1346 = call float @dx.op.binary.f32(i32 36, float %1343, float %1340)  ; FMin(a,b)
  %1347 = call float @dx.op.binary.f32(i32 36, float %1344, float %1341)  ; FMin(a,b)
  %1348 = call float @dx.op.binary.f32(i32 36, float %1345, float %1342)  ; FMin(a,b)
  %1349 = call float @dx.op.binary.f32(i32 36, float %285, float %1346)  ; FMin(a,b)
  %1350 = call float @dx.op.binary.f32(i32 36, float %286, float %1347)  ; FMin(a,b)
  %1351 = call float @dx.op.binary.f32(i32 36, float %287, float %1348)  ; FMin(a,b)
  %1352 = call float @dx.op.binary.f32(i32 35, float %1075, float %1337)  ; FMax(a,b)
  %1353 = call float @dx.op.binary.f32(i32 35, float %1076, float %1338)  ; FMax(a,b)
  %1354 = call float @dx.op.binary.f32(i32 35, float %1077, float %1339)  ; FMax(a,b)
  %1355 = call float @dx.op.binary.f32(i32 35, float %549, float %811)  ; FMax(a,b)
  %1356 = call float @dx.op.binary.f32(i32 35, float %550, float %812)  ; FMax(a,b)
  %1357 = call float @dx.op.binary.f32(i32 35, float %551, float %813)  ; FMax(a,b)
  %1358 = call float @dx.op.binary.f32(i32 35, float %1355, float %1352)  ; FMax(a,b)
  %1359 = call float @dx.op.binary.f32(i32 35, float %1356, float %1353)  ; FMax(a,b)
  %1360 = call float @dx.op.binary.f32(i32 35, float %1357, float %1354)  ; FMax(a,b)
  %1361 = call float @dx.op.binary.f32(i32 35, float %285, float %1358)  ; FMax(a,b)
  %1362 = call float @dx.op.binary.f32(i32 35, float %286, float %1359)  ; FMax(a,b)
  %1363 = call float @dx.op.binary.f32(i32 35, float %287, float %1360)  ; FMax(a,b)
  %1364 = fsub fast float %1361, %1349
  %1365 = fsub fast float %1362, %1350
  %1366 = fsub fast float %1363, %1351
  %1367 = call float @dx.op.unary.f32(i32 6, float %1364)  ; FAbs(value)
  %1368 = call float @dx.op.unary.f32(i32 6, float %1365)  ; FAbs(value)
  %1369 = call float @dx.op.unary.f32(i32 6, float %1366)  ; FAbs(value)
  %1370 = call float @dx.op.binary.f32(i32 35, float %1368, float %1369)  ; FMax(a,b)
  %1371 = call float @dx.op.binary.f32(i32 35, float %1367, float %1370)  ; FMax(a,b)
  %1372 = call float @dx.op.binary.f32(i32 35, float %1362, float %1363)  ; FMax(a,b)
  %1373 = call float @dx.op.binary.f32(i32 35, float %1361, float %1372)  ; FMax(a,b)
  %1374 = fmul fast float %1373, 1.250000e-01
  %1375 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %1374)  ; FMax(a,b)
  %1376 = fcmp fast ogt float %1371, %1375
  br i1 %1376, label %1377, label %1438

; <label>:1377                                    ; preds = %1336
  %1378 = fsub fast float %549, %811
  %1379 = fsub fast float %550, %812
  %1380 = fsub fast float %551, %813
  %1381 = call float @dx.op.unary.f32(i32 6, float %1378)  ; FAbs(value)
  %1382 = call float @dx.op.unary.f32(i32 6, float %1379)  ; FAbs(value)
  %1383 = call float @dx.op.unary.f32(i32 6, float %1380)  ; FAbs(value)
  %1384 = call float @dx.op.binary.f32(i32 35, float %1382, float %1383)  ; FMax(a,b)
  %1385 = call float @dx.op.binary.f32(i32 35, float %1381, float %1384)  ; FMax(a,b)
  %1386 = fsub fast float %1075, %1337
  %1387 = fsub fast float %1076, %1338
  %1388 = fsub fast float %1077, %1339
  %1389 = call float @dx.op.unary.f32(i32 6, float %1386)  ; FAbs(value)
  %1390 = call float @dx.op.unary.f32(i32 6, float %1387)  ; FAbs(value)
  %1391 = call float @dx.op.unary.f32(i32 6, float %1388)  ; FAbs(value)
  %1392 = call float @dx.op.binary.f32(i32 35, float %1390, float %1391)  ; FMax(a,b)
  %1393 = call float @dx.op.binary.f32(i32 35, float %1389, float %1392)  ; FMax(a,b)
  %1394 = fcmp fast olt float %1385, %1393
  %1395 = select i1 %1394, float %549, float %1075
  %1396 = select i1 %1394, float %550, float %1076
  %1397 = select i1 %1394, float %551, float %1077
  %1398 = select i1 %1394, float %811, float %1337
  %1399 = select i1 %1394, float %812, float %1338
  %1400 = select i1 %1394, float %813, float %1339
  %1401 = fsub fast float %285, %1398
  %1402 = fsub fast float %286, %1399
  %1403 = fsub fast float %287, %1400
  %1404 = fsub fast float %285, %1395
  %1405 = fsub fast float %286, %1396
  %1406 = fsub fast float %287, %1397
  %1407 = call float @dx.op.dot3.f32(i32 55, float %1404, float %1405, float %1406, float %1401, float %1402, float %1403)  ; Dot3(ax,ay,az,bx,by,bz)
  %1408 = fcmp fast ogt float %1407, 0.000000e+00
  br i1 %1408, label %1409, label %1420

; <label>:1409                                    ; preds = %1377
  %1410 = fsub fast float %1395, %1398
  %1411 = fsub fast float %1396, %1399
  %1412 = fsub fast float %1397, %1400
  %1413 = call float @dx.op.unary.f32(i32 6, float %1410)  ; FAbs(value)
  %1414 = call float @dx.op.unary.f32(i32 6, float %1411)  ; FAbs(value)
  %1415 = call float @dx.op.unary.f32(i32 6, float %1412)  ; FAbs(value)
  %1416 = call float @dx.op.binary.f32(i32 35, float %1414, float %1415)  ; FMax(a,b)
  %1417 = call float @dx.op.binary.f32(i32 35, float %1413, float %1416)  ; FMax(a,b)
  %1418 = fmul fast float %1371, 2.500000e-01
  %1419 = fcmp fast olt float %1417, %1418
  br label %1420

; <label>:1420                                    ; preds = %1409, %1377
  %1421 = phi i1 [ false, %1377 ], [ %1419, %1409 ]
  %1422 = select i1 %1421, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  %1423 = fadd fast float %1395, %1398
  %1424 = fadd fast float %1396, %1399
  %1425 = fadd fast float %1397, %1400
  %1426 = fmul fast float %1423, 5.000000e-01
  %1427 = fmul fast float %1424, 5.000000e-01
  %1428 = fmul fast float %1425, 5.000000e-01
  %1429 = fsub fast float %1426, %285
  %1430 = fsub fast float %1427, %286
  %1431 = fsub fast float %1428, %287
  %1432 = fmul fast float %1422, %1429
  %1433 = fmul fast float %1422, %1430
  %1434 = fmul fast float %1422, %1431
  %1435 = fadd fast float %1432, %285
  %1436 = fadd fast float %1433, %286
  %1437 = fadd fast float %1434, %287
  br label %1438

; <label>:1438                                    ; preds = %1420, %1336
  %1439 = phi float [ %1435, %1420 ], [ %285, %1336 ]
  %1440 = phi float [ %1436, %1420 ], [ %286, %1336 ]
  %1441 = phi float [ %1437, %1420 ], [ %287, %1336 ]
  %1442 = fcmp fast ogt float %1439, 0x3F69A5C380000000
  %1443 = fcmp fast ogt float %1440, 0x3F69A5C380000000
  %1444 = fcmp fast ogt float %1441, 0x3F69A5C380000000
  %1445 = select i1 %1442, float 0.000000e+00, float 1.000000e+00
  %1446 = select i1 %1443, float 0.000000e+00, float 1.000000e+00
  %1447 = select i1 %1444, float 0.000000e+00, float 1.000000e+00
  %1448 = fmul fast float %1439, 0x4029D70A40000000
  %1449 = fmul fast float %1440, 0x4029D70A40000000
  %1450 = fmul fast float %1441, 0x4029D70A40000000
  %1451 = call float @dx.op.binary.f32(i32 35, float %1439, float 0.000000e+00)  ; FMax(a,b)
  %1452 = call float @dx.op.binary.f32(i32 35, float %1440, float 0.000000e+00)  ; FMax(a,b)
  %1453 = call float @dx.op.binary.f32(i32 35, float %1441, float 0.000000e+00)  ; FMax(a,b)
  %1454 = call float @dx.op.unary.f32(i32 23, float %1451)  ; Log(value)
  %1455 = call float @dx.op.unary.f32(i32 23, float %1452)  ; Log(value)
  %1456 = call float @dx.op.unary.f32(i32 23, float %1453)  ; Log(value)
  %1457 = fmul fast float %1454, 0x3FDAAAAAA0000000
  %1458 = fmul fast float %1455, 0x3FDAAAAAA0000000
  %1459 = fmul fast float %1456, 0x3FDAAAAAA0000000
  %1460 = call float @dx.op.unary.f32(i32 21, float %1457)  ; Exp(value)
  %1461 = call float @dx.op.unary.f32(i32 21, float %1458)  ; Exp(value)
  %1462 = call float @dx.op.unary.f32(i32 21, float %1459)  ; Exp(value)
  %1463 = fmul fast float %1460, 0x3FF0E147A0000000
  %1464 = fmul fast float %1461, 0x3FF0E147A0000000
  %1465 = fmul fast float %1462, 0x3FF0E147A0000000
  %1466 = fadd fast float %1463, 0xBFAC28F5C0000000
  %1467 = fadd fast float %1464, 0xBFAC28F5C0000000
  %1468 = fadd fast float %1465, 0xBFAC28F5C0000000
  %1469 = fsub fast float %1448, %1466
  %1470 = fsub fast float %1449, %1467
  %1471 = fsub fast float %1450, %1468
  %1472 = fmul fast float %1469, %1445
  %1473 = fmul fast float %1470, %1446
  %1474 = fmul fast float %1471, %1447
  %1475 = fadd fast float %1472, %1466
  %1476 = fadd fast float %1473, %1467
  %1477 = fadd fast float %1474, %1468
  br label %1478

; <label>:1478                                    ; preds = %1438, %71
  %1479 = phi float [ %66, %71 ], [ %1475, %1438 ]
  %1480 = phi float [ %67, %71 ], [ %1476, %1438 ]
  %1481 = phi float [ %68, %71 ], [ %1477, %1438 ]
  %1482 = phi float [ %72, %71 ], [ %69, %1438 ]
  %1483 = add i32 %55, 1
  %1484 = call i32 @dx.op.binary.i32(i32 37, i32 %1483, i32 0)  ; IMax(a,b)
  %1485 = call i32 @dx.op.binary.i32(i32 38, i32 %1484, i32 %59)  ; IMin(a,b)
  %1486 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1485, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1487 = extractvalue %dx.types.ResRet.f32 %1486, 0
  %1488 = extractvalue %dx.types.ResRet.f32 %1486, 1
  %1489 = extractvalue %dx.types.ResRet.f32 %1486, 2
  %1490 = extractvalue %dx.types.ResRet.f32 %1486, 3
  %1491 = fcmp fast olt float %1490, 0.000000e+00
  br i1 %1491, label %1492, label %1494

; <label>:1492                                    ; preds = %1478
  %1493 = fsub fast float -1.000000e+00, %1490
  br label %2899

; <label>:1494                                    ; preds = %1478
  %1495 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1485, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1496 = extractvalue %dx.types.ResRet.f32 %1495, 0
  %1497 = fcmp fast ogt float %38, 5.000000e-01
  %1498 = fcmp fast olt float %1496, 1.000000e+00
  %1499 = and i1 %1497, %1498
  br i1 %1499, label %1500, label %1638

; <label>:1500                                    ; preds = %1494
  %1501 = sitofp i32 %1485 to float
  %1502 = sitofp i32 %64 to float
  %1503 = fadd fast float %1501, 5.000000e-01
  %1504 = fadd fast float %1502, 5.000000e-01
  %1505 = fdiv fast float %1503, %45
  %1506 = fdiv fast float %1504, %46
  %1507 = fmul fast float %1505, 2.000000e+00
  %1508 = fmul fast float %1506, 2.000000e+00
  %1509 = fadd fast float %1507, -1.000000e+00
  %1510 = fsub fast float 1.000000e+00, %1508
  %1511 = fmul fast float %1509, %35
  %1512 = call float @dx.op.tertiary.f32(i32 46, float %1510, float %31, float %1511)  ; FMad(a,b,c)
  %1513 = call float @dx.op.tertiary.f32(i32 46, float %1496, float %27, float %1512)  ; FMad(a,b,c)
  %1514 = fadd fast float %1513, %23
  %1515 = call float @dx.op.unary.f32(i32 6, float %1514)  ; FAbs(value)
  %1516 = fcmp fast ogt float %1515, 0x3EB0C6F7A0000000
  br i1 %1516, label %1517, label %1638

; <label>:1517                                    ; preds = %1500
  %1518 = fmul fast float %1509, %34
  %1519 = call float @dx.op.tertiary.f32(i32 46, float %1510, float %30, float %1518)  ; FMad(a,b,c)
  %1520 = call float @dx.op.tertiary.f32(i32 46, float %1496, float %26, float %1519)  ; FMad(a,b,c)
  %1521 = fadd fast float %1520, %22
  %1522 = fmul fast float %1509, %33
  %1523 = call float @dx.op.tertiary.f32(i32 46, float %1510, float %29, float %1522)  ; FMad(a,b,c)
  %1524 = call float @dx.op.tertiary.f32(i32 46, float %1496, float %25, float %1523)  ; FMad(a,b,c)
  %1525 = fadd fast float %1524, %21
  %1526 = fmul fast float %1509, %32
  %1527 = call float @dx.op.tertiary.f32(i32 46, float %1510, float %28, float %1526)  ; FMad(a,b,c)
  %1528 = call float @dx.op.tertiary.f32(i32 46, float %1496, float %24, float %1527)  ; FMad(a,b,c)
  %1529 = fadd fast float %1528, %20
  %1530 = fdiv fast float %1529, %1514
  %1531 = fdiv fast float %1525, %1514
  %1532 = fdiv fast float %1521, %1514
  %1533 = fsub fast float %1530, %17
  %1534 = fsub fast float %1531, %18
  %1535 = fsub fast float %1532, %19
  %1536 = fmul fast float %1533, %1533
  %1537 = fmul fast float %1534, %1534
  %1538 = fadd fast float %1537, %1536
  %1539 = fmul fast float %1535, %1535
  %1540 = fadd fast float %1538, %1539
  %1541 = call float @dx.op.unary.f32(i32 24, float %1540)  ; Sqrt(value)
  %1542 = fsub fast float %1541, %9
  %1543 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1542)  ; FMax(a,b)
  %1544 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1544, label %1545, label %1568

; <label>:1545                                    ; preds = %1517
  %1546 = call float @dx.op.unary.f32(i32 6, float %1534)  ; FAbs(value)
  %1547 = fmul fast float %1546, %11
  %1548 = fcmp fast olt float %1547, 0x3F50624DE0000000
  br i1 %1548, label %1549, label %1552

; <label>:1549                                    ; preds = %1545
  %1550 = fmul fast float %1547, 5.000000e-01
  %1551 = fsub fast float 1.000000e+00, %1550
  br label %1557

; <label>:1552                                    ; preds = %1545
  %1553 = fmul fast float %1547, 0xBFF7154760000000
  %1554 = call float @dx.op.unary.f32(i32 21, float %1553)  ; Exp(value)
  %1555 = fsub fast float 1.000000e+00, %1554
  %1556 = fdiv fast float %1555, %1547
  br label %1557

; <label>:1557                                    ; preds = %1552, %1549
  %1558 = phi float [ %1551, %1549 ], [ %1556, %1552 ]
  %1559 = call float @dx.op.binary.f32(i32 36, float %1531, float %18)  ; FMin(a,b)
  %1560 = fsub fast float %1559, %10
  %1561 = fmul fast float %11, %1560
  %1562 = fsub fast float -0.000000e+00, %1561
  %1563 = call float @dx.op.binary.f32(i32 35, float %1562, float -4.000000e+01)  ; FMax(a,b)
  %1564 = call float @dx.op.binary.f32(i32 36, float %1563, float 5.000000e+00)  ; FMin(a,b)
  %1565 = fmul fast float %1564, 0x3FF7154760000000
  %1566 = call float @dx.op.unary.f32(i32 21, float %1565)  ; Exp(value)
  %1567 = fmul fast float %1566, %1558
  br label %1568

; <label>:1568                                    ; preds = %1557, %1517
  %1569 = phi float [ %1567, %1557 ], [ 1.000000e+00, %1517 ]
  %1570 = fmul fast float %1543, %16
  %1571 = fmul fast float %1570, %1569
  %1572 = fcmp fast ole float %1541, %9
  %1573 = fcmp fast olt float %1541, 0x3F1A36E2E0000000
  %1574 = or i1 %1572, %1573
  br i1 %1574, label %1621, label %1575

; <label>:1575                                    ; preds = %1568
  %1576 = fdiv fast float %9, %1541
  %1577 = fmul fast float %1576, %1533
  %1578 = fmul fast float %1576, %1534
  %1579 = fmul fast float %1576, %1535
  %1580 = fadd fast float %1577, %17
  %1581 = fadd fast float %1578, %18
  %1582 = fadd fast float %1579, %19
  %1583 = fadd fast float %1580, -9.000000e+02
  %1584 = fadd fast float %1581, -1.500000e+01
  %1585 = fadd fast float %1582, -7.500000e+02
  %1586 = fmul fast float %1583, 0x3F62345680000000
  %1587 = fmul fast float %1584, 0x3F62345680000000
  %1588 = fmul fast float %1585, 0x3F62345680000000
  %1589 = call float @dx.op.dot3.f32(i32 55, float %1586, float %1587, float %1588, float %1586, float %1587, float %1588)  ; Dot3(ax,ay,az,bx,by,bz)
  %1590 = fsub fast float 1.000000e+00, %1589
  %1591 = call float @dx.op.unary.f32(i32 7, float %1590)  ; Saturate(value)
  %1592 = fmul fast float %1591, %1591
  %1593 = fadd fast float %1580, %1530
  %1594 = fadd fast float %1581, %1531
  %1595 = fadd fast float %1582, %1532
  %1596 = fmul fast float %1593, 0x3F52345680000000
  %1597 = fadd fast float %1596, -2.000000e+00
  %1598 = fmul fast float %1594, 0x3F52345680000000
  %1599 = fadd fast float %1598, 0xBFA1111120000000
  %1600 = fmul fast float %1595, 0x3F52345680000000
  %1601 = fadd fast float %1600, 0xBFFAAAAAC0000000
  %1602 = call float @dx.op.dot3.f32(i32 55, float %1597, float %1599, float %1601, float %1597, float %1599, float %1601)  ; Dot3(ax,ay,az,bx,by,bz)
  %1603 = fsub fast float 1.000000e+00, %1602
  %1604 = call float @dx.op.unary.f32(i32 7, float %1603)  ; Saturate(value)
  %1605 = fmul fast float %1604, %1604
  %1606 = fmul fast float %1605, 4.000000e+00
  %1607 = fadd fast float %1606, %1592
  %1608 = fadd fast float %1530, -9.000000e+02
  %1609 = fadd fast float %1531, -1.500000e+01
  %1610 = fadd fast float %1532, -7.500000e+02
  %1611 = fmul fast float %1608, 0x3F62345680000000
  %1612 = fmul fast float %1609, 0x3F62345680000000
  %1613 = fmul fast float %1610, 0x3F62345680000000
  %1614 = call float @dx.op.dot3.f32(i32 55, float %1611, float %1612, float %1613, float %1611, float %1612, float %1613)  ; Dot3(ax,ay,az,bx,by,bz)
  %1615 = fsub fast float 1.000000e+00, %1614
  %1616 = call float @dx.op.unary.f32(i32 7, float %1615)  ; Saturate(value)
  %1617 = fmul fast float %1616, %1616
  %1618 = fadd fast float %1607, %1617
  %1619 = fmul fast float %1542, 0x3F25D867E0000000
  %1620 = fmul fast float %1619, %1618
  br label %1621

; <label>:1621                                    ; preds = %1575, %1568
  %1622 = phi float [ %1620, %1575 ], [ 0.000000e+00, %1568 ]
  %1623 = fadd fast float %1622, %1571
  %1624 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1623)  ; FMin(a,b)
  %1625 = fmul fast float %1624, 0xBFF7154760000000
  %1626 = call float @dx.op.unary.f32(i32 21, float %1625)  ; Exp(value)
  %1627 = fsub fast float 1.000000e+00, %1626
  %1628 = call float @dx.op.binary.f32(i32 36, float %12, float %1627)  ; FMin(a,b)
  %1629 = fsub fast float %13, %1487
  %1630 = fsub fast float %14, %1488
  %1631 = fsub fast float %15, %1489
  %1632 = fmul fast float %1628, %1629
  %1633 = fmul fast float %1628, %1630
  %1634 = fmul fast float %1628, %1631
  %1635 = fadd fast float %1632, %1487
  %1636 = fadd fast float %1633, %1488
  %1637 = fadd fast float %1634, %1489
  br label %1638

; <label>:1638                                    ; preds = %1621, %1500, %1494
  %1639 = phi float [ %1635, %1621 ], [ %1487, %1500 ], [ %1487, %1494 ]
  %1640 = phi float [ %1636, %1621 ], [ %1488, %1500 ], [ %1488, %1494 ]
  %1641 = phi float [ %1637, %1621 ], [ %1489, %1500 ], [ %1489, %1494 ]
  %1642 = fadd fast float %5, 1.000000e+00
  %1643 = fadd fast float %6, 1.000000e+00
  %1644 = fsub fast float 1.000000e+00, %5
  %1645 = fmul fast float %36, %1642
  %1646 = fmul fast float %36, %1643
  %1647 = fmul fast float %36, %1644
  %1648 = fmul fast float %1645, %1639
  %1649 = fmul fast float %1646, %1640
  %1650 = fmul fast float %1647, %1641
  %1651 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1651, label %1677, label %1652

; <label>:1652                                    ; preds = %1638
  %1653 = fmul fast float %1648, 0x4004147AE0000000
  %1654 = fmul fast float %1649, 0x4004147AE0000000
  %1655 = fmul fast float %1650, 0x4004147AE0000000
  %1656 = fadd fast float %1653, 0x3F9EB851E0000000
  %1657 = fadd fast float %1654, 0x3F9EB851E0000000
  %1658 = fadd fast float %1655, 0x3F9EB851E0000000
  %1659 = fmul fast float %1656, %1648
  %1660 = fmul fast float %1657, %1649
  %1661 = fmul fast float %1658, %1650
  %1662 = fmul fast float %1648, 0x400370A3E0000000
  %1663 = fmul fast float %1649, 0x400370A3E0000000
  %1664 = fmul fast float %1650, 0x400370A3E0000000
  %1665 = fadd fast float %1662, 0x3FE2E147A0000000
  %1666 = fadd fast float %1663, 0x3FE2E147A0000000
  %1667 = fadd fast float %1664, 0x3FE2E147A0000000
  %1668 = fmul fast float %1665, %1648
  %1669 = fmul fast float %1666, %1649
  %1670 = fmul fast float %1667, %1650
  %1671 = fadd fast float %1668, 0x3FC1EB8520000000
  %1672 = fadd fast float %1669, 0x3FC1EB8520000000
  %1673 = fadd fast float %1670, 0x3FC1EB8520000000
  %1674 = fdiv fast float %1659, %1671
  %1675 = fdiv fast float %1660, %1672
  %1676 = fdiv fast float %1661, %1673
  br label %1677

; <label>:1677                                    ; preds = %1652, %1638
  %1678 = phi float [ %1674, %1652 ], [ %1648, %1638 ]
  %1679 = phi float [ %1675, %1652 ], [ %1649, %1638 ]
  %1680 = phi float [ %1676, %1652 ], [ %1650, %1638 ]
  %1681 = call float @dx.op.unary.f32(i32 7, float %1678)  ; Saturate(value)
  %1682 = call float @dx.op.unary.f32(i32 7, float %1679)  ; Saturate(value)
  %1683 = call float @dx.op.unary.f32(i32 7, float %1680)  ; Saturate(value)
  %1684 = call float @dx.op.dot3.f32(i32 55, float %1681, float %1682, float %1683, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1685 = fsub fast float %1681, %1684
  %1686 = fsub fast float %1682, %1684
  %1687 = fsub fast float %1683, %1684
  %1688 = fmul fast float %1685, %8
  %1689 = fmul fast float %1686, %8
  %1690 = fmul fast float %1687, %8
  %1691 = fadd fast float %1688, %1684
  %1692 = fadd fast float %1689, %1684
  %1693 = fadd fast float %1690, %1684
  %1694 = call float @dx.op.unary.f32(i32 7, float %1691)  ; Saturate(value)
  %1695 = call float @dx.op.unary.f32(i32 7, float %1692)  ; Saturate(value)
  %1696 = call float @dx.op.unary.f32(i32 7, float %1693)  ; Saturate(value)
  %1697 = fadd fast float %1694, 0xBFC70A3D80000000
  %1698 = fadd fast float %1695, 0xBFC70A3D80000000
  %1699 = fadd fast float %1696, 0xBFC70A3D80000000
  %1700 = fmul fast float %1697, %7
  %1701 = fmul fast float %1698, %7
  %1702 = fmul fast float %1699, %7
  %1703 = fadd fast float %1700, 0x3FC70A3D80000000
  %1704 = fadd fast float %1701, 0x3FC70A3D80000000
  %1705 = fadd fast float %1702, 0x3FC70A3D80000000
  %1706 = call float @dx.op.unary.f32(i32 7, float %1703)  ; Saturate(value)
  %1707 = call float @dx.op.unary.f32(i32 7, float %1704)  ; Saturate(value)
  %1708 = call float @dx.op.unary.f32(i32 7, float %1705)  ; Saturate(value)
  %1709 = add i32 %64, -1
  %1710 = call i32 @dx.op.binary.i32(i32 37, i32 %1485, i32 0)  ; IMax(a,b)
  %1711 = call i32 @dx.op.binary.i32(i32 37, i32 %1709, i32 0)  ; IMax(a,b)
  %1712 = call i32 @dx.op.binary.i32(i32 38, i32 %1710, i32 %59)  ; IMin(a,b)
  %1713 = call i32 @dx.op.binary.i32(i32 38, i32 %1711, i32 %60)  ; IMin(a,b)
  %1714 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1712, i32 %1713, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1715 = extractvalue %dx.types.ResRet.f32 %1714, 0
  %1716 = extractvalue %dx.types.ResRet.f32 %1714, 1
  %1717 = extractvalue %dx.types.ResRet.f32 %1714, 2
  %1718 = extractvalue %dx.types.ResRet.f32 %1714, 3
  %1719 = fcmp fast olt float %1718, 0.000000e+00
  br i1 %1719, label %1720, label %1754

; <label>:1720                                    ; preds = %1677
  %1721 = fcmp fast ogt float %1715, 0x3FA4B5DCC0000000
  %1722 = fcmp fast ogt float %1716, 0x3FA4B5DCC0000000
  %1723 = fcmp fast ogt float %1717, 0x3FA4B5DCC0000000
  %1724 = select i1 %1721, float 0.000000e+00, float 1.000000e+00
  %1725 = select i1 %1722, float 0.000000e+00, float 1.000000e+00
  %1726 = select i1 %1723, float 0.000000e+00, float 1.000000e+00
  %1727 = fmul fast float %1715, 0x3FB3D07220000000
  %1728 = fmul fast float %1716, 0x3FB3D07220000000
  %1729 = fmul fast float %1717, 0x3FB3D07220000000
  %1730 = fadd fast float %1715, 0x3FAC28F5C0000000
  %1731 = fadd fast float %1716, 0x3FAC28F5C0000000
  %1732 = fadd fast float %1717, 0x3FAC28F5C0000000
  %1733 = fmul fast float %1730, 0x3FEE54EDE0000000
  %1734 = fmul fast float %1731, 0x3FEE54EDE0000000
  %1735 = fmul fast float %1732, 0x3FEE54EDE0000000
  %1736 = call float @dx.op.unary.f32(i32 23, float %1733)  ; Log(value)
  %1737 = call float @dx.op.unary.f32(i32 23, float %1734)  ; Log(value)
  %1738 = call float @dx.op.unary.f32(i32 23, float %1735)  ; Log(value)
  %1739 = fmul fast float %1736, 0x4003333340000000
  %1740 = fmul fast float %1737, 0x4003333340000000
  %1741 = fmul fast float %1738, 0x4003333340000000
  %1742 = call float @dx.op.unary.f32(i32 21, float %1739)  ; Exp(value)
  %1743 = call float @dx.op.unary.f32(i32 21, float %1740)  ; Exp(value)
  %1744 = call float @dx.op.unary.f32(i32 21, float %1741)  ; Exp(value)
  %1745 = fsub fast float %1727, %1742
  %1746 = fsub fast float %1728, %1743
  %1747 = fsub fast float %1729, %1744
  %1748 = fmul fast float %1745, %1724
  %1749 = fmul fast float %1746, %1725
  %1750 = fmul fast float %1747, %1726
  %1751 = fadd fast float %1748, %1742
  %1752 = fadd fast float %1749, %1743
  %1753 = fadd fast float %1750, %1744
  br label %1969

; <label>:1754                                    ; preds = %1677
  %1755 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1712, i32 %1713, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1756 = extractvalue %dx.types.ResRet.f32 %1755, 0
  %1757 = fcmp fast ogt float %38, 5.000000e-01
  %1758 = fcmp fast olt float %1756, 1.000000e+00
  %1759 = and i1 %1757, %1758
  br i1 %1759, label %1760, label %1898

; <label>:1760                                    ; preds = %1754
  %1761 = sitofp i32 %1712 to float
  %1762 = sitofp i32 %1713 to float
  %1763 = fadd fast float %1761, 5.000000e-01
  %1764 = fadd fast float %1762, 5.000000e-01
  %1765 = fdiv fast float %1763, %45
  %1766 = fdiv fast float %1764, %46
  %1767 = fmul fast float %1765, 2.000000e+00
  %1768 = fmul fast float %1766, 2.000000e+00
  %1769 = fadd fast float %1767, -1.000000e+00
  %1770 = fsub fast float 1.000000e+00, %1768
  %1771 = fmul fast float %1769, %35
  %1772 = call float @dx.op.tertiary.f32(i32 46, float %1770, float %31, float %1771)  ; FMad(a,b,c)
  %1773 = call float @dx.op.tertiary.f32(i32 46, float %1756, float %27, float %1772)  ; FMad(a,b,c)
  %1774 = fadd fast float %1773, %23
  %1775 = call float @dx.op.unary.f32(i32 6, float %1774)  ; FAbs(value)
  %1776 = fcmp fast ogt float %1775, 0x3EB0C6F7A0000000
  br i1 %1776, label %1777, label %1898

; <label>:1777                                    ; preds = %1760
  %1778 = fmul fast float %1769, %34
  %1779 = call float @dx.op.tertiary.f32(i32 46, float %1770, float %30, float %1778)  ; FMad(a,b,c)
  %1780 = call float @dx.op.tertiary.f32(i32 46, float %1756, float %26, float %1779)  ; FMad(a,b,c)
  %1781 = fadd fast float %1780, %22
  %1782 = fmul fast float %1769, %33
  %1783 = call float @dx.op.tertiary.f32(i32 46, float %1770, float %29, float %1782)  ; FMad(a,b,c)
  %1784 = call float @dx.op.tertiary.f32(i32 46, float %1756, float %25, float %1783)  ; FMad(a,b,c)
  %1785 = fadd fast float %1784, %21
  %1786 = fmul fast float %1769, %32
  %1787 = call float @dx.op.tertiary.f32(i32 46, float %1770, float %28, float %1786)  ; FMad(a,b,c)
  %1788 = call float @dx.op.tertiary.f32(i32 46, float %1756, float %24, float %1787)  ; FMad(a,b,c)
  %1789 = fadd fast float %1788, %20
  %1790 = fdiv fast float %1789, %1774
  %1791 = fdiv fast float %1785, %1774
  %1792 = fdiv fast float %1781, %1774
  %1793 = fsub fast float %1790, %17
  %1794 = fsub fast float %1791, %18
  %1795 = fsub fast float %1792, %19
  %1796 = fmul fast float %1793, %1793
  %1797 = fmul fast float %1794, %1794
  %1798 = fadd fast float %1797, %1796
  %1799 = fmul fast float %1795, %1795
  %1800 = fadd fast float %1798, %1799
  %1801 = call float @dx.op.unary.f32(i32 24, float %1800)  ; Sqrt(value)
  %1802 = fsub fast float %1801, %9
  %1803 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %1802)  ; FMax(a,b)
  %1804 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %1804, label %1805, label %1828

; <label>:1805                                    ; preds = %1777
  %1806 = call float @dx.op.unary.f32(i32 6, float %1794)  ; FAbs(value)
  %1807 = fmul fast float %1806, %11
  %1808 = fcmp fast olt float %1807, 0x3F50624DE0000000
  br i1 %1808, label %1809, label %1812

; <label>:1809                                    ; preds = %1805
  %1810 = fmul fast float %1807, 5.000000e-01
  %1811 = fsub fast float 1.000000e+00, %1810
  br label %1817

; <label>:1812                                    ; preds = %1805
  %1813 = fmul fast float %1807, 0xBFF7154760000000
  %1814 = call float @dx.op.unary.f32(i32 21, float %1813)  ; Exp(value)
  %1815 = fsub fast float 1.000000e+00, %1814
  %1816 = fdiv fast float %1815, %1807
  br label %1817

; <label>:1817                                    ; preds = %1812, %1809
  %1818 = phi float [ %1811, %1809 ], [ %1816, %1812 ]
  %1819 = call float @dx.op.binary.f32(i32 36, float %1791, float %18)  ; FMin(a,b)
  %1820 = fsub fast float %1819, %10
  %1821 = fmul fast float %11, %1820
  %1822 = fsub fast float -0.000000e+00, %1821
  %1823 = call float @dx.op.binary.f32(i32 35, float %1822, float -4.000000e+01)  ; FMax(a,b)
  %1824 = call float @dx.op.binary.f32(i32 36, float %1823, float 5.000000e+00)  ; FMin(a,b)
  %1825 = fmul fast float %1824, 0x3FF7154760000000
  %1826 = call float @dx.op.unary.f32(i32 21, float %1825)  ; Exp(value)
  %1827 = fmul fast float %1826, %1818
  br label %1828

; <label>:1828                                    ; preds = %1817, %1777
  %1829 = phi float [ %1827, %1817 ], [ 1.000000e+00, %1777 ]
  %1830 = fmul fast float %1803, %16
  %1831 = fmul fast float %1830, %1829
  %1832 = fcmp fast ole float %1801, %9
  %1833 = fcmp fast olt float %1801, 0x3F1A36E2E0000000
  %1834 = or i1 %1832, %1833
  br i1 %1834, label %1881, label %1835

; <label>:1835                                    ; preds = %1828
  %1836 = fdiv fast float %9, %1801
  %1837 = fmul fast float %1836, %1793
  %1838 = fmul fast float %1836, %1794
  %1839 = fmul fast float %1836, %1795
  %1840 = fadd fast float %1837, %17
  %1841 = fadd fast float %1838, %18
  %1842 = fadd fast float %1839, %19
  %1843 = fadd fast float %1840, -9.000000e+02
  %1844 = fadd fast float %1841, -1.500000e+01
  %1845 = fadd fast float %1842, -7.500000e+02
  %1846 = fmul fast float %1843, 0x3F62345680000000
  %1847 = fmul fast float %1844, 0x3F62345680000000
  %1848 = fmul fast float %1845, 0x3F62345680000000
  %1849 = call float @dx.op.dot3.f32(i32 55, float %1846, float %1847, float %1848, float %1846, float %1847, float %1848)  ; Dot3(ax,ay,az,bx,by,bz)
  %1850 = fsub fast float 1.000000e+00, %1849
  %1851 = call float @dx.op.unary.f32(i32 7, float %1850)  ; Saturate(value)
  %1852 = fmul fast float %1851, %1851
  %1853 = fadd fast float %1840, %1790
  %1854 = fadd fast float %1841, %1791
  %1855 = fadd fast float %1842, %1792
  %1856 = fmul fast float %1853, 0x3F52345680000000
  %1857 = fadd fast float %1856, -2.000000e+00
  %1858 = fmul fast float %1854, 0x3F52345680000000
  %1859 = fadd fast float %1858, 0xBFA1111120000000
  %1860 = fmul fast float %1855, 0x3F52345680000000
  %1861 = fadd fast float %1860, 0xBFFAAAAAC0000000
  %1862 = call float @dx.op.dot3.f32(i32 55, float %1857, float %1859, float %1861, float %1857, float %1859, float %1861)  ; Dot3(ax,ay,az,bx,by,bz)
  %1863 = fsub fast float 1.000000e+00, %1862
  %1864 = call float @dx.op.unary.f32(i32 7, float %1863)  ; Saturate(value)
  %1865 = fmul fast float %1864, %1864
  %1866 = fmul fast float %1865, 4.000000e+00
  %1867 = fadd fast float %1866, %1852
  %1868 = fadd fast float %1790, -9.000000e+02
  %1869 = fadd fast float %1791, -1.500000e+01
  %1870 = fadd fast float %1792, -7.500000e+02
  %1871 = fmul fast float %1868, 0x3F62345680000000
  %1872 = fmul fast float %1869, 0x3F62345680000000
  %1873 = fmul fast float %1870, 0x3F62345680000000
  %1874 = call float @dx.op.dot3.f32(i32 55, float %1871, float %1872, float %1873, float %1871, float %1872, float %1873)  ; Dot3(ax,ay,az,bx,by,bz)
  %1875 = fsub fast float 1.000000e+00, %1874
  %1876 = call float @dx.op.unary.f32(i32 7, float %1875)  ; Saturate(value)
  %1877 = fmul fast float %1876, %1876
  %1878 = fadd fast float %1867, %1877
  %1879 = fmul fast float %1802, 0x3F25D867E0000000
  %1880 = fmul fast float %1879, %1878
  br label %1881

; <label>:1881                                    ; preds = %1835, %1828
  %1882 = phi float [ %1880, %1835 ], [ 0.000000e+00, %1828 ]
  %1883 = fadd fast float %1882, %1831
  %1884 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %1883)  ; FMin(a,b)
  %1885 = fmul fast float %1884, 0xBFF7154760000000
  %1886 = call float @dx.op.unary.f32(i32 21, float %1885)  ; Exp(value)
  %1887 = fsub fast float 1.000000e+00, %1886
  %1888 = call float @dx.op.binary.f32(i32 36, float %12, float %1887)  ; FMin(a,b)
  %1889 = fsub fast float %13, %1715
  %1890 = fsub fast float %14, %1716
  %1891 = fsub fast float %15, %1717
  %1892 = fmul fast float %1888, %1889
  %1893 = fmul fast float %1888, %1890
  %1894 = fmul fast float %1888, %1891
  %1895 = fadd fast float %1892, %1715
  %1896 = fadd fast float %1893, %1716
  %1897 = fadd fast float %1894, %1717
  br label %1898

; <label>:1898                                    ; preds = %1881, %1760, %1754
  %1899 = phi float [ %1895, %1881 ], [ %1715, %1760 ], [ %1715, %1754 ]
  %1900 = phi float [ %1896, %1881 ], [ %1716, %1760 ], [ %1716, %1754 ]
  %1901 = phi float [ %1897, %1881 ], [ %1717, %1760 ], [ %1717, %1754 ]
  %1902 = fadd fast float %5, 1.000000e+00
  %1903 = fadd fast float %6, 1.000000e+00
  %1904 = fsub fast float 1.000000e+00, %5
  %1905 = fmul fast float %36, %1902
  %1906 = fmul fast float %36, %1903
  %1907 = fmul fast float %36, %1904
  %1908 = fmul fast float %1905, %1899
  %1909 = fmul fast float %1906, %1900
  %1910 = fmul fast float %1907, %1901
  %1911 = fcmp fast ult float %37, 5.000000e-01
  br i1 %1911, label %1937, label %1912

; <label>:1912                                    ; preds = %1898
  %1913 = fmul fast float %1908, 0x4004147AE0000000
  %1914 = fmul fast float %1909, 0x4004147AE0000000
  %1915 = fmul fast float %1910, 0x4004147AE0000000
  %1916 = fadd fast float %1913, 0x3F9EB851E0000000
  %1917 = fadd fast float %1914, 0x3F9EB851E0000000
  %1918 = fadd fast float %1915, 0x3F9EB851E0000000
  %1919 = fmul fast float %1916, %1908
  %1920 = fmul fast float %1917, %1909
  %1921 = fmul fast float %1918, %1910
  %1922 = fmul fast float %1908, 0x400370A3E0000000
  %1923 = fmul fast float %1909, 0x400370A3E0000000
  %1924 = fmul fast float %1910, 0x400370A3E0000000
  %1925 = fadd fast float %1922, 0x3FE2E147A0000000
  %1926 = fadd fast float %1923, 0x3FE2E147A0000000
  %1927 = fadd fast float %1924, 0x3FE2E147A0000000
  %1928 = fmul fast float %1925, %1908
  %1929 = fmul fast float %1926, %1909
  %1930 = fmul fast float %1927, %1910
  %1931 = fadd fast float %1928, 0x3FC1EB8520000000
  %1932 = fadd fast float %1929, 0x3FC1EB8520000000
  %1933 = fadd fast float %1930, 0x3FC1EB8520000000
  %1934 = fdiv fast float %1919, %1931
  %1935 = fdiv fast float %1920, %1932
  %1936 = fdiv fast float %1921, %1933
  br label %1937

; <label>:1937                                    ; preds = %1912, %1898
  %1938 = phi float [ %1934, %1912 ], [ %1908, %1898 ]
  %1939 = phi float [ %1935, %1912 ], [ %1909, %1898 ]
  %1940 = phi float [ %1936, %1912 ], [ %1910, %1898 ]
  %1941 = call float @dx.op.unary.f32(i32 7, float %1938)  ; Saturate(value)
  %1942 = call float @dx.op.unary.f32(i32 7, float %1939)  ; Saturate(value)
  %1943 = call float @dx.op.unary.f32(i32 7, float %1940)  ; Saturate(value)
  %1944 = call float @dx.op.dot3.f32(i32 55, float %1941, float %1942, float %1943, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %1945 = fsub fast float %1941, %1944
  %1946 = fsub fast float %1942, %1944
  %1947 = fsub fast float %1943, %1944
  %1948 = fmul fast float %1945, %8
  %1949 = fmul fast float %1946, %8
  %1950 = fmul fast float %1947, %8
  %1951 = fadd fast float %1948, %1944
  %1952 = fadd fast float %1949, %1944
  %1953 = fadd fast float %1950, %1944
  %1954 = call float @dx.op.unary.f32(i32 7, float %1951)  ; Saturate(value)
  %1955 = call float @dx.op.unary.f32(i32 7, float %1952)  ; Saturate(value)
  %1956 = call float @dx.op.unary.f32(i32 7, float %1953)  ; Saturate(value)
  %1957 = fadd fast float %1954, 0xBFC70A3D80000000
  %1958 = fadd fast float %1955, 0xBFC70A3D80000000
  %1959 = fadd fast float %1956, 0xBFC70A3D80000000
  %1960 = fmul fast float %1957, %7
  %1961 = fmul fast float %1958, %7
  %1962 = fmul fast float %1959, %7
  %1963 = fadd fast float %1960, 0x3FC70A3D80000000
  %1964 = fadd fast float %1961, 0x3FC70A3D80000000
  %1965 = fadd fast float %1962, 0x3FC70A3D80000000
  %1966 = call float @dx.op.unary.f32(i32 7, float %1963)  ; Saturate(value)
  %1967 = call float @dx.op.unary.f32(i32 7, float %1964)  ; Saturate(value)
  %1968 = call float @dx.op.unary.f32(i32 7, float %1965)  ; Saturate(value)
  br label %1969

; <label>:1969                                    ; preds = %1937, %1720
  %1970 = phi float [ %1751, %1720 ], [ %1966, %1937 ]
  %1971 = phi float [ %1752, %1720 ], [ %1967, %1937 ]
  %1972 = phi float [ %1753, %1720 ], [ %1968, %1937 ]
  %1973 = add i32 %64, 1
  %1974 = call i32 @dx.op.binary.i32(i32 37, i32 %1973, i32 0)  ; IMax(a,b)
  %1975 = call i32 @dx.op.binary.i32(i32 38, i32 %1974, i32 %60)  ; IMin(a,b)
  %1976 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1712, i32 %1975, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %1977 = extractvalue %dx.types.ResRet.f32 %1976, 0
  %1978 = extractvalue %dx.types.ResRet.f32 %1976, 1
  %1979 = extractvalue %dx.types.ResRet.f32 %1976, 2
  %1980 = extractvalue %dx.types.ResRet.f32 %1976, 3
  %1981 = fcmp fast olt float %1980, 0.000000e+00
  br i1 %1981, label %1982, label %2016

; <label>:1982                                    ; preds = %1969
  %1983 = fcmp fast ogt float %1977, 0x3FA4B5DCC0000000
  %1984 = fcmp fast ogt float %1978, 0x3FA4B5DCC0000000
  %1985 = fcmp fast ogt float %1979, 0x3FA4B5DCC0000000
  %1986 = select i1 %1983, float 0.000000e+00, float 1.000000e+00
  %1987 = select i1 %1984, float 0.000000e+00, float 1.000000e+00
  %1988 = select i1 %1985, float 0.000000e+00, float 1.000000e+00
  %1989 = fmul fast float %1977, 0x3FB3D07220000000
  %1990 = fmul fast float %1978, 0x3FB3D07220000000
  %1991 = fmul fast float %1979, 0x3FB3D07220000000
  %1992 = fadd fast float %1977, 0x3FAC28F5C0000000
  %1993 = fadd fast float %1978, 0x3FAC28F5C0000000
  %1994 = fadd fast float %1979, 0x3FAC28F5C0000000
  %1995 = fmul fast float %1992, 0x3FEE54EDE0000000
  %1996 = fmul fast float %1993, 0x3FEE54EDE0000000
  %1997 = fmul fast float %1994, 0x3FEE54EDE0000000
  %1998 = call float @dx.op.unary.f32(i32 23, float %1995)  ; Log(value)
  %1999 = call float @dx.op.unary.f32(i32 23, float %1996)  ; Log(value)
  %2000 = call float @dx.op.unary.f32(i32 23, float %1997)  ; Log(value)
  %2001 = fmul fast float %1998, 0x4003333340000000
  %2002 = fmul fast float %1999, 0x4003333340000000
  %2003 = fmul fast float %2000, 0x4003333340000000
  %2004 = call float @dx.op.unary.f32(i32 21, float %2001)  ; Exp(value)
  %2005 = call float @dx.op.unary.f32(i32 21, float %2002)  ; Exp(value)
  %2006 = call float @dx.op.unary.f32(i32 21, float %2003)  ; Exp(value)
  %2007 = fsub fast float %1989, %2004
  %2008 = fsub fast float %1990, %2005
  %2009 = fsub fast float %1991, %2006
  %2010 = fmul fast float %2007, %1986
  %2011 = fmul fast float %2008, %1987
  %2012 = fmul fast float %2009, %1988
  %2013 = fadd fast float %2010, %2004
  %2014 = fadd fast float %2011, %2005
  %2015 = fadd fast float %2012, %2006
  br label %2231

; <label>:2016                                    ; preds = %1969
  %2017 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1712, i32 %1975, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2018 = extractvalue %dx.types.ResRet.f32 %2017, 0
  %2019 = fcmp fast ogt float %38, 5.000000e-01
  %2020 = fcmp fast olt float %2018, 1.000000e+00
  %2021 = and i1 %2019, %2020
  br i1 %2021, label %2022, label %2160

; <label>:2022                                    ; preds = %2016
  %2023 = sitofp i32 %1712 to float
  %2024 = sitofp i32 %1975 to float
  %2025 = fadd fast float %2023, 5.000000e-01
  %2026 = fadd fast float %2024, 5.000000e-01
  %2027 = fdiv fast float %2025, %45
  %2028 = fdiv fast float %2026, %46
  %2029 = fmul fast float %2027, 2.000000e+00
  %2030 = fmul fast float %2028, 2.000000e+00
  %2031 = fadd fast float %2029, -1.000000e+00
  %2032 = fsub fast float 1.000000e+00, %2030
  %2033 = fmul fast float %2031, %35
  %2034 = call float @dx.op.tertiary.f32(i32 46, float %2032, float %31, float %2033)  ; FMad(a,b,c)
  %2035 = call float @dx.op.tertiary.f32(i32 46, float %2018, float %27, float %2034)  ; FMad(a,b,c)
  %2036 = fadd fast float %2035, %23
  %2037 = call float @dx.op.unary.f32(i32 6, float %2036)  ; FAbs(value)
  %2038 = fcmp fast ogt float %2037, 0x3EB0C6F7A0000000
  br i1 %2038, label %2039, label %2160

; <label>:2039                                    ; preds = %2022
  %2040 = fmul fast float %2031, %34
  %2041 = call float @dx.op.tertiary.f32(i32 46, float %2032, float %30, float %2040)  ; FMad(a,b,c)
  %2042 = call float @dx.op.tertiary.f32(i32 46, float %2018, float %26, float %2041)  ; FMad(a,b,c)
  %2043 = fadd fast float %2042, %22
  %2044 = fmul fast float %2031, %33
  %2045 = call float @dx.op.tertiary.f32(i32 46, float %2032, float %29, float %2044)  ; FMad(a,b,c)
  %2046 = call float @dx.op.tertiary.f32(i32 46, float %2018, float %25, float %2045)  ; FMad(a,b,c)
  %2047 = fadd fast float %2046, %21
  %2048 = fmul fast float %2031, %32
  %2049 = call float @dx.op.tertiary.f32(i32 46, float %2032, float %28, float %2048)  ; FMad(a,b,c)
  %2050 = call float @dx.op.tertiary.f32(i32 46, float %2018, float %24, float %2049)  ; FMad(a,b,c)
  %2051 = fadd fast float %2050, %20
  %2052 = fdiv fast float %2051, %2036
  %2053 = fdiv fast float %2047, %2036
  %2054 = fdiv fast float %2043, %2036
  %2055 = fsub fast float %2052, %17
  %2056 = fsub fast float %2053, %18
  %2057 = fsub fast float %2054, %19
  %2058 = fmul fast float %2055, %2055
  %2059 = fmul fast float %2056, %2056
  %2060 = fadd fast float %2059, %2058
  %2061 = fmul fast float %2057, %2057
  %2062 = fadd fast float %2060, %2061
  %2063 = call float @dx.op.unary.f32(i32 24, float %2062)  ; Sqrt(value)
  %2064 = fsub fast float %2063, %9
  %2065 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2064)  ; FMax(a,b)
  %2066 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %2066, label %2067, label %2090

; <label>:2067                                    ; preds = %2039
  %2068 = call float @dx.op.unary.f32(i32 6, float %2056)  ; FAbs(value)
  %2069 = fmul fast float %2068, %11
  %2070 = fcmp fast olt float %2069, 0x3F50624DE0000000
  br i1 %2070, label %2071, label %2074

; <label>:2071                                    ; preds = %2067
  %2072 = fmul fast float %2069, 5.000000e-01
  %2073 = fsub fast float 1.000000e+00, %2072
  br label %2079

; <label>:2074                                    ; preds = %2067
  %2075 = fmul fast float %2069, 0xBFF7154760000000
  %2076 = call float @dx.op.unary.f32(i32 21, float %2075)  ; Exp(value)
  %2077 = fsub fast float 1.000000e+00, %2076
  %2078 = fdiv fast float %2077, %2069
  br label %2079

; <label>:2079                                    ; preds = %2074, %2071
  %2080 = phi float [ %2073, %2071 ], [ %2078, %2074 ]
  %2081 = call float @dx.op.binary.f32(i32 36, float %2053, float %18)  ; FMin(a,b)
  %2082 = fsub fast float %2081, %10
  %2083 = fmul fast float %11, %2082
  %2084 = fsub fast float -0.000000e+00, %2083
  %2085 = call float @dx.op.binary.f32(i32 35, float %2084, float -4.000000e+01)  ; FMax(a,b)
  %2086 = call float @dx.op.binary.f32(i32 36, float %2085, float 5.000000e+00)  ; FMin(a,b)
  %2087 = fmul fast float %2086, 0x3FF7154760000000
  %2088 = call float @dx.op.unary.f32(i32 21, float %2087)  ; Exp(value)
  %2089 = fmul fast float %2088, %2080
  br label %2090

; <label>:2090                                    ; preds = %2079, %2039
  %2091 = phi float [ %2089, %2079 ], [ 1.000000e+00, %2039 ]
  %2092 = fmul fast float %2065, %16
  %2093 = fmul fast float %2092, %2091
  %2094 = fcmp fast ole float %2063, %9
  %2095 = fcmp fast olt float %2063, 0x3F1A36E2E0000000
  %2096 = or i1 %2094, %2095
  br i1 %2096, label %2143, label %2097

; <label>:2097                                    ; preds = %2090
  %2098 = fdiv fast float %9, %2063
  %2099 = fmul fast float %2098, %2055
  %2100 = fmul fast float %2098, %2056
  %2101 = fmul fast float %2098, %2057
  %2102 = fadd fast float %2099, %17
  %2103 = fadd fast float %2100, %18
  %2104 = fadd fast float %2101, %19
  %2105 = fadd fast float %2102, -9.000000e+02
  %2106 = fadd fast float %2103, -1.500000e+01
  %2107 = fadd fast float %2104, -7.500000e+02
  %2108 = fmul fast float %2105, 0x3F62345680000000
  %2109 = fmul fast float %2106, 0x3F62345680000000
  %2110 = fmul fast float %2107, 0x3F62345680000000
  %2111 = call float @dx.op.dot3.f32(i32 55, float %2108, float %2109, float %2110, float %2108, float %2109, float %2110)  ; Dot3(ax,ay,az,bx,by,bz)
  %2112 = fsub fast float 1.000000e+00, %2111
  %2113 = call float @dx.op.unary.f32(i32 7, float %2112)  ; Saturate(value)
  %2114 = fmul fast float %2113, %2113
  %2115 = fadd fast float %2102, %2052
  %2116 = fadd fast float %2103, %2053
  %2117 = fadd fast float %2104, %2054
  %2118 = fmul fast float %2115, 0x3F52345680000000
  %2119 = fadd fast float %2118, -2.000000e+00
  %2120 = fmul fast float %2116, 0x3F52345680000000
  %2121 = fadd fast float %2120, 0xBFA1111120000000
  %2122 = fmul fast float %2117, 0x3F52345680000000
  %2123 = fadd fast float %2122, 0xBFFAAAAAC0000000
  %2124 = call float @dx.op.dot3.f32(i32 55, float %2119, float %2121, float %2123, float %2119, float %2121, float %2123)  ; Dot3(ax,ay,az,bx,by,bz)
  %2125 = fsub fast float 1.000000e+00, %2124
  %2126 = call float @dx.op.unary.f32(i32 7, float %2125)  ; Saturate(value)
  %2127 = fmul fast float %2126, %2126
  %2128 = fmul fast float %2127, 4.000000e+00
  %2129 = fadd fast float %2128, %2114
  %2130 = fadd fast float %2052, -9.000000e+02
  %2131 = fadd fast float %2053, -1.500000e+01
  %2132 = fadd fast float %2054, -7.500000e+02
  %2133 = fmul fast float %2130, 0x3F62345680000000
  %2134 = fmul fast float %2131, 0x3F62345680000000
  %2135 = fmul fast float %2132, 0x3F62345680000000
  %2136 = call float @dx.op.dot3.f32(i32 55, float %2133, float %2134, float %2135, float %2133, float %2134, float %2135)  ; Dot3(ax,ay,az,bx,by,bz)
  %2137 = fsub fast float 1.000000e+00, %2136
  %2138 = call float @dx.op.unary.f32(i32 7, float %2137)  ; Saturate(value)
  %2139 = fmul fast float %2138, %2138
  %2140 = fadd fast float %2129, %2139
  %2141 = fmul fast float %2064, 0x3F25D867E0000000
  %2142 = fmul fast float %2141, %2140
  br label %2143

; <label>:2143                                    ; preds = %2097, %2090
  %2144 = phi float [ %2142, %2097 ], [ 0.000000e+00, %2090 ]
  %2145 = fadd fast float %2144, %2093
  %2146 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2145)  ; FMin(a,b)
  %2147 = fmul fast float %2146, 0xBFF7154760000000
  %2148 = call float @dx.op.unary.f32(i32 21, float %2147)  ; Exp(value)
  %2149 = fsub fast float 1.000000e+00, %2148
  %2150 = call float @dx.op.binary.f32(i32 36, float %12, float %2149)  ; FMin(a,b)
  %2151 = fsub fast float %13, %1977
  %2152 = fsub fast float %14, %1978
  %2153 = fsub fast float %15, %1979
  %2154 = fmul fast float %2150, %2151
  %2155 = fmul fast float %2150, %2152
  %2156 = fmul fast float %2150, %2153
  %2157 = fadd fast float %2154, %1977
  %2158 = fadd fast float %2155, %1978
  %2159 = fadd fast float %2156, %1979
  br label %2160

; <label>:2160                                    ; preds = %2143, %2022, %2016
  %2161 = phi float [ %2157, %2143 ], [ %1977, %2022 ], [ %1977, %2016 ]
  %2162 = phi float [ %2158, %2143 ], [ %1978, %2022 ], [ %1978, %2016 ]
  %2163 = phi float [ %2159, %2143 ], [ %1979, %2022 ], [ %1979, %2016 ]
  %2164 = fadd fast float %5, 1.000000e+00
  %2165 = fadd fast float %6, 1.000000e+00
  %2166 = fsub fast float 1.000000e+00, %5
  %2167 = fmul fast float %36, %2164
  %2168 = fmul fast float %36, %2165
  %2169 = fmul fast float %36, %2166
  %2170 = fmul fast float %2167, %2161
  %2171 = fmul fast float %2168, %2162
  %2172 = fmul fast float %2169, %2163
  %2173 = fcmp fast ult float %37, 5.000000e-01
  br i1 %2173, label %2199, label %2174

; <label>:2174                                    ; preds = %2160
  %2175 = fmul fast float %2170, 0x4004147AE0000000
  %2176 = fmul fast float %2171, 0x4004147AE0000000
  %2177 = fmul fast float %2172, 0x4004147AE0000000
  %2178 = fadd fast float %2175, 0x3F9EB851E0000000
  %2179 = fadd fast float %2176, 0x3F9EB851E0000000
  %2180 = fadd fast float %2177, 0x3F9EB851E0000000
  %2181 = fmul fast float %2178, %2170
  %2182 = fmul fast float %2179, %2171
  %2183 = fmul fast float %2180, %2172
  %2184 = fmul fast float %2170, 0x400370A3E0000000
  %2185 = fmul fast float %2171, 0x400370A3E0000000
  %2186 = fmul fast float %2172, 0x400370A3E0000000
  %2187 = fadd fast float %2184, 0x3FE2E147A0000000
  %2188 = fadd fast float %2185, 0x3FE2E147A0000000
  %2189 = fadd fast float %2186, 0x3FE2E147A0000000
  %2190 = fmul fast float %2187, %2170
  %2191 = fmul fast float %2188, %2171
  %2192 = fmul fast float %2189, %2172
  %2193 = fadd fast float %2190, 0x3FC1EB8520000000
  %2194 = fadd fast float %2191, 0x3FC1EB8520000000
  %2195 = fadd fast float %2192, 0x3FC1EB8520000000
  %2196 = fdiv fast float %2181, %2193
  %2197 = fdiv fast float %2182, %2194
  %2198 = fdiv fast float %2183, %2195
  br label %2199

; <label>:2199                                    ; preds = %2174, %2160
  %2200 = phi float [ %2196, %2174 ], [ %2170, %2160 ]
  %2201 = phi float [ %2197, %2174 ], [ %2171, %2160 ]
  %2202 = phi float [ %2198, %2174 ], [ %2172, %2160 ]
  %2203 = call float @dx.op.unary.f32(i32 7, float %2200)  ; Saturate(value)
  %2204 = call float @dx.op.unary.f32(i32 7, float %2201)  ; Saturate(value)
  %2205 = call float @dx.op.unary.f32(i32 7, float %2202)  ; Saturate(value)
  %2206 = call float @dx.op.dot3.f32(i32 55, float %2203, float %2204, float %2205, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2207 = fsub fast float %2203, %2206
  %2208 = fsub fast float %2204, %2206
  %2209 = fsub fast float %2205, %2206
  %2210 = fmul fast float %2207, %8
  %2211 = fmul fast float %2208, %8
  %2212 = fmul fast float %2209, %8
  %2213 = fadd fast float %2210, %2206
  %2214 = fadd fast float %2211, %2206
  %2215 = fadd fast float %2212, %2206
  %2216 = call float @dx.op.unary.f32(i32 7, float %2213)  ; Saturate(value)
  %2217 = call float @dx.op.unary.f32(i32 7, float %2214)  ; Saturate(value)
  %2218 = call float @dx.op.unary.f32(i32 7, float %2215)  ; Saturate(value)
  %2219 = fadd fast float %2216, 0xBFC70A3D80000000
  %2220 = fadd fast float %2217, 0xBFC70A3D80000000
  %2221 = fadd fast float %2218, 0xBFC70A3D80000000
  %2222 = fmul fast float %2219, %7
  %2223 = fmul fast float %2220, %7
  %2224 = fmul fast float %2221, %7
  %2225 = fadd fast float %2222, 0x3FC70A3D80000000
  %2226 = fadd fast float %2223, 0x3FC70A3D80000000
  %2227 = fadd fast float %2224, 0x3FC70A3D80000000
  %2228 = call float @dx.op.unary.f32(i32 7, float %2225)  ; Saturate(value)
  %2229 = call float @dx.op.unary.f32(i32 7, float %2226)  ; Saturate(value)
  %2230 = call float @dx.op.unary.f32(i32 7, float %2227)  ; Saturate(value)
  br label %2231

; <label>:2231                                    ; preds = %2199, %1982
  %2232 = phi float [ %2013, %1982 ], [ %2228, %2199 ]
  %2233 = phi float [ %2014, %1982 ], [ %2229, %2199 ]
  %2234 = phi float [ %2015, %1982 ], [ %2230, %2199 ]
  %2235 = add i32 %1485, -1
  %2236 = call i32 @dx.op.binary.i32(i32 37, i32 %2235, i32 0)  ; IMax(a,b)
  %2237 = call i32 @dx.op.binary.i32(i32 37, i32 %64, i32 0)  ; IMax(a,b)
  %2238 = call i32 @dx.op.binary.i32(i32 38, i32 %2236, i32 %59)  ; IMin(a,b)
  %2239 = call i32 @dx.op.binary.i32(i32 38, i32 %2237, i32 %60)  ; IMin(a,b)
  %2240 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2238, i32 %2239, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2241 = extractvalue %dx.types.ResRet.f32 %2240, 0
  %2242 = extractvalue %dx.types.ResRet.f32 %2240, 1
  %2243 = extractvalue %dx.types.ResRet.f32 %2240, 2
  %2244 = extractvalue %dx.types.ResRet.f32 %2240, 3
  %2245 = fcmp fast olt float %2244, 0.000000e+00
  br i1 %2245, label %2246, label %2280

; <label>:2246                                    ; preds = %2231
  %2247 = fcmp fast ogt float %2241, 0x3FA4B5DCC0000000
  %2248 = fcmp fast ogt float %2242, 0x3FA4B5DCC0000000
  %2249 = fcmp fast ogt float %2243, 0x3FA4B5DCC0000000
  %2250 = select i1 %2247, float 0.000000e+00, float 1.000000e+00
  %2251 = select i1 %2248, float 0.000000e+00, float 1.000000e+00
  %2252 = select i1 %2249, float 0.000000e+00, float 1.000000e+00
  %2253 = fmul fast float %2241, 0x3FB3D07220000000
  %2254 = fmul fast float %2242, 0x3FB3D07220000000
  %2255 = fmul fast float %2243, 0x3FB3D07220000000
  %2256 = fadd fast float %2241, 0x3FAC28F5C0000000
  %2257 = fadd fast float %2242, 0x3FAC28F5C0000000
  %2258 = fadd fast float %2243, 0x3FAC28F5C0000000
  %2259 = fmul fast float %2256, 0x3FEE54EDE0000000
  %2260 = fmul fast float %2257, 0x3FEE54EDE0000000
  %2261 = fmul fast float %2258, 0x3FEE54EDE0000000
  %2262 = call float @dx.op.unary.f32(i32 23, float %2259)  ; Log(value)
  %2263 = call float @dx.op.unary.f32(i32 23, float %2260)  ; Log(value)
  %2264 = call float @dx.op.unary.f32(i32 23, float %2261)  ; Log(value)
  %2265 = fmul fast float %2262, 0x4003333340000000
  %2266 = fmul fast float %2263, 0x4003333340000000
  %2267 = fmul fast float %2264, 0x4003333340000000
  %2268 = call float @dx.op.unary.f32(i32 21, float %2265)  ; Exp(value)
  %2269 = call float @dx.op.unary.f32(i32 21, float %2266)  ; Exp(value)
  %2270 = call float @dx.op.unary.f32(i32 21, float %2267)  ; Exp(value)
  %2271 = fsub fast float %2253, %2268
  %2272 = fsub fast float %2254, %2269
  %2273 = fsub fast float %2255, %2270
  %2274 = fmul fast float %2271, %2250
  %2275 = fmul fast float %2272, %2251
  %2276 = fmul fast float %2273, %2252
  %2277 = fadd fast float %2274, %2268
  %2278 = fadd fast float %2275, %2269
  %2279 = fadd fast float %2276, %2270
  br label %2495

; <label>:2280                                    ; preds = %2231
  %2281 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2238, i32 %2239, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2282 = extractvalue %dx.types.ResRet.f32 %2281, 0
  %2283 = fcmp fast ogt float %38, 5.000000e-01
  %2284 = fcmp fast olt float %2282, 1.000000e+00
  %2285 = and i1 %2283, %2284
  br i1 %2285, label %2286, label %2424

; <label>:2286                                    ; preds = %2280
  %2287 = sitofp i32 %2238 to float
  %2288 = sitofp i32 %2239 to float
  %2289 = fadd fast float %2287, 5.000000e-01
  %2290 = fadd fast float %2288, 5.000000e-01
  %2291 = fdiv fast float %2289, %45
  %2292 = fdiv fast float %2290, %46
  %2293 = fmul fast float %2291, 2.000000e+00
  %2294 = fmul fast float %2292, 2.000000e+00
  %2295 = fadd fast float %2293, -1.000000e+00
  %2296 = fsub fast float 1.000000e+00, %2294
  %2297 = fmul fast float %2295, %35
  %2298 = call float @dx.op.tertiary.f32(i32 46, float %2296, float %31, float %2297)  ; FMad(a,b,c)
  %2299 = call float @dx.op.tertiary.f32(i32 46, float %2282, float %27, float %2298)  ; FMad(a,b,c)
  %2300 = fadd fast float %2299, %23
  %2301 = call float @dx.op.unary.f32(i32 6, float %2300)  ; FAbs(value)
  %2302 = fcmp fast ogt float %2301, 0x3EB0C6F7A0000000
  br i1 %2302, label %2303, label %2424

; <label>:2303                                    ; preds = %2286
  %2304 = fmul fast float %2295, %34
  %2305 = call float @dx.op.tertiary.f32(i32 46, float %2296, float %30, float %2304)  ; FMad(a,b,c)
  %2306 = call float @dx.op.tertiary.f32(i32 46, float %2282, float %26, float %2305)  ; FMad(a,b,c)
  %2307 = fadd fast float %2306, %22
  %2308 = fmul fast float %2295, %33
  %2309 = call float @dx.op.tertiary.f32(i32 46, float %2296, float %29, float %2308)  ; FMad(a,b,c)
  %2310 = call float @dx.op.tertiary.f32(i32 46, float %2282, float %25, float %2309)  ; FMad(a,b,c)
  %2311 = fadd fast float %2310, %21
  %2312 = fmul fast float %2295, %32
  %2313 = call float @dx.op.tertiary.f32(i32 46, float %2296, float %28, float %2312)  ; FMad(a,b,c)
  %2314 = call float @dx.op.tertiary.f32(i32 46, float %2282, float %24, float %2313)  ; FMad(a,b,c)
  %2315 = fadd fast float %2314, %20
  %2316 = fdiv fast float %2315, %2300
  %2317 = fdiv fast float %2311, %2300
  %2318 = fdiv fast float %2307, %2300
  %2319 = fsub fast float %2316, %17
  %2320 = fsub fast float %2317, %18
  %2321 = fsub fast float %2318, %19
  %2322 = fmul fast float %2319, %2319
  %2323 = fmul fast float %2320, %2320
  %2324 = fadd fast float %2323, %2322
  %2325 = fmul fast float %2321, %2321
  %2326 = fadd fast float %2324, %2325
  %2327 = call float @dx.op.unary.f32(i32 24, float %2326)  ; Sqrt(value)
  %2328 = fsub fast float %2327, %9
  %2329 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2328)  ; FMax(a,b)
  %2330 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %2330, label %2331, label %2354

; <label>:2331                                    ; preds = %2303
  %2332 = call float @dx.op.unary.f32(i32 6, float %2320)  ; FAbs(value)
  %2333 = fmul fast float %2332, %11
  %2334 = fcmp fast olt float %2333, 0x3F50624DE0000000
  br i1 %2334, label %2335, label %2338

; <label>:2335                                    ; preds = %2331
  %2336 = fmul fast float %2333, 5.000000e-01
  %2337 = fsub fast float 1.000000e+00, %2336
  br label %2343

; <label>:2338                                    ; preds = %2331
  %2339 = fmul fast float %2333, 0xBFF7154760000000
  %2340 = call float @dx.op.unary.f32(i32 21, float %2339)  ; Exp(value)
  %2341 = fsub fast float 1.000000e+00, %2340
  %2342 = fdiv fast float %2341, %2333
  br label %2343

; <label>:2343                                    ; preds = %2338, %2335
  %2344 = phi float [ %2337, %2335 ], [ %2342, %2338 ]
  %2345 = call float @dx.op.binary.f32(i32 36, float %2317, float %18)  ; FMin(a,b)
  %2346 = fsub fast float %2345, %10
  %2347 = fmul fast float %11, %2346
  %2348 = fsub fast float -0.000000e+00, %2347
  %2349 = call float @dx.op.binary.f32(i32 35, float %2348, float -4.000000e+01)  ; FMax(a,b)
  %2350 = call float @dx.op.binary.f32(i32 36, float %2349, float 5.000000e+00)  ; FMin(a,b)
  %2351 = fmul fast float %2350, 0x3FF7154760000000
  %2352 = call float @dx.op.unary.f32(i32 21, float %2351)  ; Exp(value)
  %2353 = fmul fast float %2352, %2344
  br label %2354

; <label>:2354                                    ; preds = %2343, %2303
  %2355 = phi float [ %2353, %2343 ], [ 1.000000e+00, %2303 ]
  %2356 = fmul fast float %2329, %16
  %2357 = fmul fast float %2356, %2355
  %2358 = fcmp fast ole float %2327, %9
  %2359 = fcmp fast olt float %2327, 0x3F1A36E2E0000000
  %2360 = or i1 %2358, %2359
  br i1 %2360, label %2407, label %2361

; <label>:2361                                    ; preds = %2354
  %2362 = fdiv fast float %9, %2327
  %2363 = fmul fast float %2362, %2319
  %2364 = fmul fast float %2362, %2320
  %2365 = fmul fast float %2362, %2321
  %2366 = fadd fast float %2363, %17
  %2367 = fadd fast float %2364, %18
  %2368 = fadd fast float %2365, %19
  %2369 = fadd fast float %2366, -9.000000e+02
  %2370 = fadd fast float %2367, -1.500000e+01
  %2371 = fadd fast float %2368, -7.500000e+02
  %2372 = fmul fast float %2369, 0x3F62345680000000
  %2373 = fmul fast float %2370, 0x3F62345680000000
  %2374 = fmul fast float %2371, 0x3F62345680000000
  %2375 = call float @dx.op.dot3.f32(i32 55, float %2372, float %2373, float %2374, float %2372, float %2373, float %2374)  ; Dot3(ax,ay,az,bx,by,bz)
  %2376 = fsub fast float 1.000000e+00, %2375
  %2377 = call float @dx.op.unary.f32(i32 7, float %2376)  ; Saturate(value)
  %2378 = fmul fast float %2377, %2377
  %2379 = fadd fast float %2366, %2316
  %2380 = fadd fast float %2367, %2317
  %2381 = fadd fast float %2368, %2318
  %2382 = fmul fast float %2379, 0x3F52345680000000
  %2383 = fadd fast float %2382, -2.000000e+00
  %2384 = fmul fast float %2380, 0x3F52345680000000
  %2385 = fadd fast float %2384, 0xBFA1111120000000
  %2386 = fmul fast float %2381, 0x3F52345680000000
  %2387 = fadd fast float %2386, 0xBFFAAAAAC0000000
  %2388 = call float @dx.op.dot3.f32(i32 55, float %2383, float %2385, float %2387, float %2383, float %2385, float %2387)  ; Dot3(ax,ay,az,bx,by,bz)
  %2389 = fsub fast float 1.000000e+00, %2388
  %2390 = call float @dx.op.unary.f32(i32 7, float %2389)  ; Saturate(value)
  %2391 = fmul fast float %2390, %2390
  %2392 = fmul fast float %2391, 4.000000e+00
  %2393 = fadd fast float %2392, %2378
  %2394 = fadd fast float %2316, -9.000000e+02
  %2395 = fadd fast float %2317, -1.500000e+01
  %2396 = fadd fast float %2318, -7.500000e+02
  %2397 = fmul fast float %2394, 0x3F62345680000000
  %2398 = fmul fast float %2395, 0x3F62345680000000
  %2399 = fmul fast float %2396, 0x3F62345680000000
  %2400 = call float @dx.op.dot3.f32(i32 55, float %2397, float %2398, float %2399, float %2397, float %2398, float %2399)  ; Dot3(ax,ay,az,bx,by,bz)
  %2401 = fsub fast float 1.000000e+00, %2400
  %2402 = call float @dx.op.unary.f32(i32 7, float %2401)  ; Saturate(value)
  %2403 = fmul fast float %2402, %2402
  %2404 = fadd fast float %2393, %2403
  %2405 = fmul fast float %2328, 0x3F25D867E0000000
  %2406 = fmul fast float %2405, %2404
  br label %2407

; <label>:2407                                    ; preds = %2361, %2354
  %2408 = phi float [ %2406, %2361 ], [ 0.000000e+00, %2354 ]
  %2409 = fadd fast float %2408, %2357
  %2410 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2409)  ; FMin(a,b)
  %2411 = fmul fast float %2410, 0xBFF7154760000000
  %2412 = call float @dx.op.unary.f32(i32 21, float %2411)  ; Exp(value)
  %2413 = fsub fast float 1.000000e+00, %2412
  %2414 = call float @dx.op.binary.f32(i32 36, float %12, float %2413)  ; FMin(a,b)
  %2415 = fsub fast float %13, %2241
  %2416 = fsub fast float %14, %2242
  %2417 = fsub fast float %15, %2243
  %2418 = fmul fast float %2414, %2415
  %2419 = fmul fast float %2414, %2416
  %2420 = fmul fast float %2414, %2417
  %2421 = fadd fast float %2418, %2241
  %2422 = fadd fast float %2419, %2242
  %2423 = fadd fast float %2420, %2243
  br label %2424

; <label>:2424                                    ; preds = %2407, %2286, %2280
  %2425 = phi float [ %2421, %2407 ], [ %2241, %2286 ], [ %2241, %2280 ]
  %2426 = phi float [ %2422, %2407 ], [ %2242, %2286 ], [ %2242, %2280 ]
  %2427 = phi float [ %2423, %2407 ], [ %2243, %2286 ], [ %2243, %2280 ]
  %2428 = fadd fast float %5, 1.000000e+00
  %2429 = fadd fast float %6, 1.000000e+00
  %2430 = fsub fast float 1.000000e+00, %5
  %2431 = fmul fast float %36, %2428
  %2432 = fmul fast float %36, %2429
  %2433 = fmul fast float %36, %2430
  %2434 = fmul fast float %2431, %2425
  %2435 = fmul fast float %2432, %2426
  %2436 = fmul fast float %2433, %2427
  %2437 = fcmp fast ult float %37, 5.000000e-01
  br i1 %2437, label %2463, label %2438

; <label>:2438                                    ; preds = %2424
  %2439 = fmul fast float %2434, 0x4004147AE0000000
  %2440 = fmul fast float %2435, 0x4004147AE0000000
  %2441 = fmul fast float %2436, 0x4004147AE0000000
  %2442 = fadd fast float %2439, 0x3F9EB851E0000000
  %2443 = fadd fast float %2440, 0x3F9EB851E0000000
  %2444 = fadd fast float %2441, 0x3F9EB851E0000000
  %2445 = fmul fast float %2442, %2434
  %2446 = fmul fast float %2443, %2435
  %2447 = fmul fast float %2444, %2436
  %2448 = fmul fast float %2434, 0x400370A3E0000000
  %2449 = fmul fast float %2435, 0x400370A3E0000000
  %2450 = fmul fast float %2436, 0x400370A3E0000000
  %2451 = fadd fast float %2448, 0x3FE2E147A0000000
  %2452 = fadd fast float %2449, 0x3FE2E147A0000000
  %2453 = fadd fast float %2450, 0x3FE2E147A0000000
  %2454 = fmul fast float %2451, %2434
  %2455 = fmul fast float %2452, %2435
  %2456 = fmul fast float %2453, %2436
  %2457 = fadd fast float %2454, 0x3FC1EB8520000000
  %2458 = fadd fast float %2455, 0x3FC1EB8520000000
  %2459 = fadd fast float %2456, 0x3FC1EB8520000000
  %2460 = fdiv fast float %2445, %2457
  %2461 = fdiv fast float %2446, %2458
  %2462 = fdiv fast float %2447, %2459
  br label %2463

; <label>:2463                                    ; preds = %2438, %2424
  %2464 = phi float [ %2460, %2438 ], [ %2434, %2424 ]
  %2465 = phi float [ %2461, %2438 ], [ %2435, %2424 ]
  %2466 = phi float [ %2462, %2438 ], [ %2436, %2424 ]
  %2467 = call float @dx.op.unary.f32(i32 7, float %2464)  ; Saturate(value)
  %2468 = call float @dx.op.unary.f32(i32 7, float %2465)  ; Saturate(value)
  %2469 = call float @dx.op.unary.f32(i32 7, float %2466)  ; Saturate(value)
  %2470 = call float @dx.op.dot3.f32(i32 55, float %2467, float %2468, float %2469, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2471 = fsub fast float %2467, %2470
  %2472 = fsub fast float %2468, %2470
  %2473 = fsub fast float %2469, %2470
  %2474 = fmul fast float %2471, %8
  %2475 = fmul fast float %2472, %8
  %2476 = fmul fast float %2473, %8
  %2477 = fadd fast float %2474, %2470
  %2478 = fadd fast float %2475, %2470
  %2479 = fadd fast float %2476, %2470
  %2480 = call float @dx.op.unary.f32(i32 7, float %2477)  ; Saturate(value)
  %2481 = call float @dx.op.unary.f32(i32 7, float %2478)  ; Saturate(value)
  %2482 = call float @dx.op.unary.f32(i32 7, float %2479)  ; Saturate(value)
  %2483 = fadd fast float %2480, 0xBFC70A3D80000000
  %2484 = fadd fast float %2481, 0xBFC70A3D80000000
  %2485 = fadd fast float %2482, 0xBFC70A3D80000000
  %2486 = fmul fast float %2483, %7
  %2487 = fmul fast float %2484, %7
  %2488 = fmul fast float %2485, %7
  %2489 = fadd fast float %2486, 0x3FC70A3D80000000
  %2490 = fadd fast float %2487, 0x3FC70A3D80000000
  %2491 = fadd fast float %2488, 0x3FC70A3D80000000
  %2492 = call float @dx.op.unary.f32(i32 7, float %2489)  ; Saturate(value)
  %2493 = call float @dx.op.unary.f32(i32 7, float %2490)  ; Saturate(value)
  %2494 = call float @dx.op.unary.f32(i32 7, float %2491)  ; Saturate(value)
  br label %2495

; <label>:2495                                    ; preds = %2463, %2246
  %2496 = phi float [ %2277, %2246 ], [ %2492, %2463 ]
  %2497 = phi float [ %2278, %2246 ], [ %2493, %2463 ]
  %2498 = phi float [ %2279, %2246 ], [ %2494, %2463 ]
  %2499 = add i32 %1485, 1
  %2500 = call i32 @dx.op.binary.i32(i32 37, i32 %2499, i32 0)  ; IMax(a,b)
  %2501 = call i32 @dx.op.binary.i32(i32 38, i32 %2500, i32 %59)  ; IMin(a,b)
  %2502 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %2501, i32 %2239, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2503 = extractvalue %dx.types.ResRet.f32 %2502, 0
  %2504 = extractvalue %dx.types.ResRet.f32 %2502, 1
  %2505 = extractvalue %dx.types.ResRet.f32 %2502, 2
  %2506 = extractvalue %dx.types.ResRet.f32 %2502, 3
  %2507 = fcmp fast olt float %2506, 0.000000e+00
  br i1 %2507, label %2508, label %2542

; <label>:2508                                    ; preds = %2495
  %2509 = fcmp fast ogt float %2503, 0x3FA4B5DCC0000000
  %2510 = fcmp fast ogt float %2504, 0x3FA4B5DCC0000000
  %2511 = fcmp fast ogt float %2505, 0x3FA4B5DCC0000000
  %2512 = select i1 %2509, float 0.000000e+00, float 1.000000e+00
  %2513 = select i1 %2510, float 0.000000e+00, float 1.000000e+00
  %2514 = select i1 %2511, float 0.000000e+00, float 1.000000e+00
  %2515 = fmul fast float %2503, 0x3FB3D07220000000
  %2516 = fmul fast float %2504, 0x3FB3D07220000000
  %2517 = fmul fast float %2505, 0x3FB3D07220000000
  %2518 = fadd fast float %2503, 0x3FAC28F5C0000000
  %2519 = fadd fast float %2504, 0x3FAC28F5C0000000
  %2520 = fadd fast float %2505, 0x3FAC28F5C0000000
  %2521 = fmul fast float %2518, 0x3FEE54EDE0000000
  %2522 = fmul fast float %2519, 0x3FEE54EDE0000000
  %2523 = fmul fast float %2520, 0x3FEE54EDE0000000
  %2524 = call float @dx.op.unary.f32(i32 23, float %2521)  ; Log(value)
  %2525 = call float @dx.op.unary.f32(i32 23, float %2522)  ; Log(value)
  %2526 = call float @dx.op.unary.f32(i32 23, float %2523)  ; Log(value)
  %2527 = fmul fast float %2524, 0x4003333340000000
  %2528 = fmul fast float %2525, 0x4003333340000000
  %2529 = fmul fast float %2526, 0x4003333340000000
  %2530 = call float @dx.op.unary.f32(i32 21, float %2527)  ; Exp(value)
  %2531 = call float @dx.op.unary.f32(i32 21, float %2528)  ; Exp(value)
  %2532 = call float @dx.op.unary.f32(i32 21, float %2529)  ; Exp(value)
  %2533 = fsub fast float %2515, %2530
  %2534 = fsub fast float %2516, %2531
  %2535 = fsub fast float %2517, %2532
  %2536 = fmul fast float %2533, %2512
  %2537 = fmul fast float %2534, %2513
  %2538 = fmul fast float %2535, %2514
  %2539 = fadd fast float %2536, %2530
  %2540 = fadd fast float %2537, %2531
  %2541 = fadd fast float %2538, %2532
  br label %2757

; <label>:2542                                    ; preds = %2495
  %2543 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %2501, i32 %2239, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2544 = extractvalue %dx.types.ResRet.f32 %2543, 0
  %2545 = fcmp fast ogt float %38, 5.000000e-01
  %2546 = fcmp fast olt float %2544, 1.000000e+00
  %2547 = and i1 %2545, %2546
  br i1 %2547, label %2548, label %2686

; <label>:2548                                    ; preds = %2542
  %2549 = sitofp i32 %2501 to float
  %2550 = sitofp i32 %2239 to float
  %2551 = fadd fast float %2549, 5.000000e-01
  %2552 = fadd fast float %2550, 5.000000e-01
  %2553 = fdiv fast float %2551, %45
  %2554 = fdiv fast float %2552, %46
  %2555 = fmul fast float %2553, 2.000000e+00
  %2556 = fmul fast float %2554, 2.000000e+00
  %2557 = fadd fast float %2555, -1.000000e+00
  %2558 = fsub fast float 1.000000e+00, %2556
  %2559 = fmul fast float %2557, %35
  %2560 = call float @dx.op.tertiary.f32(i32 46, float %2558, float %31, float %2559)  ; FMad(a,b,c)
  %2561 = call float @dx.op.tertiary.f32(i32 46, float %2544, float %27, float %2560)  ; FMad(a,b,c)
  %2562 = fadd fast float %2561, %23
  %2563 = call float @dx.op.unary.f32(i32 6, float %2562)  ; FAbs(value)
  %2564 = fcmp fast ogt float %2563, 0x3EB0C6F7A0000000
  br i1 %2564, label %2565, label %2686

; <label>:2565                                    ; preds = %2548
  %2566 = fmul fast float %2557, %34
  %2567 = call float @dx.op.tertiary.f32(i32 46, float %2558, float %30, float %2566)  ; FMad(a,b,c)
  %2568 = call float @dx.op.tertiary.f32(i32 46, float %2544, float %26, float %2567)  ; FMad(a,b,c)
  %2569 = fadd fast float %2568, %22
  %2570 = fmul fast float %2557, %33
  %2571 = call float @dx.op.tertiary.f32(i32 46, float %2558, float %29, float %2570)  ; FMad(a,b,c)
  %2572 = call float @dx.op.tertiary.f32(i32 46, float %2544, float %25, float %2571)  ; FMad(a,b,c)
  %2573 = fadd fast float %2572, %21
  %2574 = fmul fast float %2557, %32
  %2575 = call float @dx.op.tertiary.f32(i32 46, float %2558, float %28, float %2574)  ; FMad(a,b,c)
  %2576 = call float @dx.op.tertiary.f32(i32 46, float %2544, float %24, float %2575)  ; FMad(a,b,c)
  %2577 = fadd fast float %2576, %20
  %2578 = fdiv fast float %2577, %2562
  %2579 = fdiv fast float %2573, %2562
  %2580 = fdiv fast float %2569, %2562
  %2581 = fsub fast float %2578, %17
  %2582 = fsub fast float %2579, %18
  %2583 = fsub fast float %2580, %19
  %2584 = fmul fast float %2581, %2581
  %2585 = fmul fast float %2582, %2582
  %2586 = fadd fast float %2585, %2584
  %2587 = fmul fast float %2583, %2583
  %2588 = fadd fast float %2586, %2587
  %2589 = call float @dx.op.unary.f32(i32 24, float %2588)  ; Sqrt(value)
  %2590 = fsub fast float %2589, %9
  %2591 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2590)  ; FMax(a,b)
  %2592 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %2592, label %2593, label %2616

; <label>:2593                                    ; preds = %2565
  %2594 = call float @dx.op.unary.f32(i32 6, float %2582)  ; FAbs(value)
  %2595 = fmul fast float %2594, %11
  %2596 = fcmp fast olt float %2595, 0x3F50624DE0000000
  br i1 %2596, label %2597, label %2600

; <label>:2597                                    ; preds = %2593
  %2598 = fmul fast float %2595, 5.000000e-01
  %2599 = fsub fast float 1.000000e+00, %2598
  br label %2605

; <label>:2600                                    ; preds = %2593
  %2601 = fmul fast float %2595, 0xBFF7154760000000
  %2602 = call float @dx.op.unary.f32(i32 21, float %2601)  ; Exp(value)
  %2603 = fsub fast float 1.000000e+00, %2602
  %2604 = fdiv fast float %2603, %2595
  br label %2605

; <label>:2605                                    ; preds = %2600, %2597
  %2606 = phi float [ %2599, %2597 ], [ %2604, %2600 ]
  %2607 = call float @dx.op.binary.f32(i32 36, float %2579, float %18)  ; FMin(a,b)
  %2608 = fsub fast float %2607, %10
  %2609 = fmul fast float %11, %2608
  %2610 = fsub fast float -0.000000e+00, %2609
  %2611 = call float @dx.op.binary.f32(i32 35, float %2610, float -4.000000e+01)  ; FMax(a,b)
  %2612 = call float @dx.op.binary.f32(i32 36, float %2611, float 5.000000e+00)  ; FMin(a,b)
  %2613 = fmul fast float %2612, 0x3FF7154760000000
  %2614 = call float @dx.op.unary.f32(i32 21, float %2613)  ; Exp(value)
  %2615 = fmul fast float %2614, %2606
  br label %2616

; <label>:2616                                    ; preds = %2605, %2565
  %2617 = phi float [ %2615, %2605 ], [ 1.000000e+00, %2565 ]
  %2618 = fmul fast float %2591, %16
  %2619 = fmul fast float %2618, %2617
  %2620 = fcmp fast ole float %2589, %9
  %2621 = fcmp fast olt float %2589, 0x3F1A36E2E0000000
  %2622 = or i1 %2620, %2621
  br i1 %2622, label %2669, label %2623

; <label>:2623                                    ; preds = %2616
  %2624 = fdiv fast float %9, %2589
  %2625 = fmul fast float %2624, %2581
  %2626 = fmul fast float %2624, %2582
  %2627 = fmul fast float %2624, %2583
  %2628 = fadd fast float %2625, %17
  %2629 = fadd fast float %2626, %18
  %2630 = fadd fast float %2627, %19
  %2631 = fadd fast float %2628, -9.000000e+02
  %2632 = fadd fast float %2629, -1.500000e+01
  %2633 = fadd fast float %2630, -7.500000e+02
  %2634 = fmul fast float %2631, 0x3F62345680000000
  %2635 = fmul fast float %2632, 0x3F62345680000000
  %2636 = fmul fast float %2633, 0x3F62345680000000
  %2637 = call float @dx.op.dot3.f32(i32 55, float %2634, float %2635, float %2636, float %2634, float %2635, float %2636)  ; Dot3(ax,ay,az,bx,by,bz)
  %2638 = fsub fast float 1.000000e+00, %2637
  %2639 = call float @dx.op.unary.f32(i32 7, float %2638)  ; Saturate(value)
  %2640 = fmul fast float %2639, %2639
  %2641 = fadd fast float %2628, %2578
  %2642 = fadd fast float %2629, %2579
  %2643 = fadd fast float %2630, %2580
  %2644 = fmul fast float %2641, 0x3F52345680000000
  %2645 = fadd fast float %2644, -2.000000e+00
  %2646 = fmul fast float %2642, 0x3F52345680000000
  %2647 = fadd fast float %2646, 0xBFA1111120000000
  %2648 = fmul fast float %2643, 0x3F52345680000000
  %2649 = fadd fast float %2648, 0xBFFAAAAAC0000000
  %2650 = call float @dx.op.dot3.f32(i32 55, float %2645, float %2647, float %2649, float %2645, float %2647, float %2649)  ; Dot3(ax,ay,az,bx,by,bz)
  %2651 = fsub fast float 1.000000e+00, %2650
  %2652 = call float @dx.op.unary.f32(i32 7, float %2651)  ; Saturate(value)
  %2653 = fmul fast float %2652, %2652
  %2654 = fmul fast float %2653, 4.000000e+00
  %2655 = fadd fast float %2654, %2640
  %2656 = fadd fast float %2578, -9.000000e+02
  %2657 = fadd fast float %2579, -1.500000e+01
  %2658 = fadd fast float %2580, -7.500000e+02
  %2659 = fmul fast float %2656, 0x3F62345680000000
  %2660 = fmul fast float %2657, 0x3F62345680000000
  %2661 = fmul fast float %2658, 0x3F62345680000000
  %2662 = call float @dx.op.dot3.f32(i32 55, float %2659, float %2660, float %2661, float %2659, float %2660, float %2661)  ; Dot3(ax,ay,az,bx,by,bz)
  %2663 = fsub fast float 1.000000e+00, %2662
  %2664 = call float @dx.op.unary.f32(i32 7, float %2663)  ; Saturate(value)
  %2665 = fmul fast float %2664, %2664
  %2666 = fadd fast float %2655, %2665
  %2667 = fmul fast float %2590, 0x3F25D867E0000000
  %2668 = fmul fast float %2667, %2666
  br label %2669

; <label>:2669                                    ; preds = %2623, %2616
  %2670 = phi float [ %2668, %2623 ], [ 0.000000e+00, %2616 ]
  %2671 = fadd fast float %2670, %2619
  %2672 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %2671)  ; FMin(a,b)
  %2673 = fmul fast float %2672, 0xBFF7154760000000
  %2674 = call float @dx.op.unary.f32(i32 21, float %2673)  ; Exp(value)
  %2675 = fsub fast float 1.000000e+00, %2674
  %2676 = call float @dx.op.binary.f32(i32 36, float %12, float %2675)  ; FMin(a,b)
  %2677 = fsub fast float %13, %2503
  %2678 = fsub fast float %14, %2504
  %2679 = fsub fast float %15, %2505
  %2680 = fmul fast float %2676, %2677
  %2681 = fmul fast float %2676, %2678
  %2682 = fmul fast float %2676, %2679
  %2683 = fadd fast float %2680, %2503
  %2684 = fadd fast float %2681, %2504
  %2685 = fadd fast float %2682, %2505
  br label %2686

; <label>:2686                                    ; preds = %2669, %2548, %2542
  %2687 = phi float [ %2683, %2669 ], [ %2503, %2548 ], [ %2503, %2542 ]
  %2688 = phi float [ %2684, %2669 ], [ %2504, %2548 ], [ %2504, %2542 ]
  %2689 = phi float [ %2685, %2669 ], [ %2505, %2548 ], [ %2505, %2542 ]
  %2690 = fadd fast float %5, 1.000000e+00
  %2691 = fadd fast float %6, 1.000000e+00
  %2692 = fsub fast float 1.000000e+00, %5
  %2693 = fmul fast float %36, %2690
  %2694 = fmul fast float %36, %2691
  %2695 = fmul fast float %36, %2692
  %2696 = fmul fast float %2693, %2687
  %2697 = fmul fast float %2694, %2688
  %2698 = fmul fast float %2695, %2689
  %2699 = fcmp fast ult float %37, 5.000000e-01
  br i1 %2699, label %2725, label %2700

; <label>:2700                                    ; preds = %2686
  %2701 = fmul fast float %2696, 0x4004147AE0000000
  %2702 = fmul fast float %2697, 0x4004147AE0000000
  %2703 = fmul fast float %2698, 0x4004147AE0000000
  %2704 = fadd fast float %2701, 0x3F9EB851E0000000
  %2705 = fadd fast float %2702, 0x3F9EB851E0000000
  %2706 = fadd fast float %2703, 0x3F9EB851E0000000
  %2707 = fmul fast float %2704, %2696
  %2708 = fmul fast float %2705, %2697
  %2709 = fmul fast float %2706, %2698
  %2710 = fmul fast float %2696, 0x400370A3E0000000
  %2711 = fmul fast float %2697, 0x400370A3E0000000
  %2712 = fmul fast float %2698, 0x400370A3E0000000
  %2713 = fadd fast float %2710, 0x3FE2E147A0000000
  %2714 = fadd fast float %2711, 0x3FE2E147A0000000
  %2715 = fadd fast float %2712, 0x3FE2E147A0000000
  %2716 = fmul fast float %2713, %2696
  %2717 = fmul fast float %2714, %2697
  %2718 = fmul fast float %2715, %2698
  %2719 = fadd fast float %2716, 0x3FC1EB8520000000
  %2720 = fadd fast float %2717, 0x3FC1EB8520000000
  %2721 = fadd fast float %2718, 0x3FC1EB8520000000
  %2722 = fdiv fast float %2707, %2719
  %2723 = fdiv fast float %2708, %2720
  %2724 = fdiv fast float %2709, %2721
  br label %2725

; <label>:2725                                    ; preds = %2700, %2686
  %2726 = phi float [ %2722, %2700 ], [ %2696, %2686 ]
  %2727 = phi float [ %2723, %2700 ], [ %2697, %2686 ]
  %2728 = phi float [ %2724, %2700 ], [ %2698, %2686 ]
  %2729 = call float @dx.op.unary.f32(i32 7, float %2726)  ; Saturate(value)
  %2730 = call float @dx.op.unary.f32(i32 7, float %2727)  ; Saturate(value)
  %2731 = call float @dx.op.unary.f32(i32 7, float %2728)  ; Saturate(value)
  %2732 = call float @dx.op.dot3.f32(i32 55, float %2729, float %2730, float %2731, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %2733 = fsub fast float %2729, %2732
  %2734 = fsub fast float %2730, %2732
  %2735 = fsub fast float %2731, %2732
  %2736 = fmul fast float %2733, %8
  %2737 = fmul fast float %2734, %8
  %2738 = fmul fast float %2735, %8
  %2739 = fadd fast float %2736, %2732
  %2740 = fadd fast float %2737, %2732
  %2741 = fadd fast float %2738, %2732
  %2742 = call float @dx.op.unary.f32(i32 7, float %2739)  ; Saturate(value)
  %2743 = call float @dx.op.unary.f32(i32 7, float %2740)  ; Saturate(value)
  %2744 = call float @dx.op.unary.f32(i32 7, float %2741)  ; Saturate(value)
  %2745 = fadd fast float %2742, 0xBFC70A3D80000000
  %2746 = fadd fast float %2743, 0xBFC70A3D80000000
  %2747 = fadd fast float %2744, 0xBFC70A3D80000000
  %2748 = fmul fast float %2745, %7
  %2749 = fmul fast float %2746, %7
  %2750 = fmul fast float %2747, %7
  %2751 = fadd fast float %2748, 0x3FC70A3D80000000
  %2752 = fadd fast float %2749, 0x3FC70A3D80000000
  %2753 = fadd fast float %2750, 0x3FC70A3D80000000
  %2754 = call float @dx.op.unary.f32(i32 7, float %2751)  ; Saturate(value)
  %2755 = call float @dx.op.unary.f32(i32 7, float %2752)  ; Saturate(value)
  %2756 = call float @dx.op.unary.f32(i32 7, float %2753)  ; Saturate(value)
  br label %2757

; <label>:2757                                    ; preds = %2725, %2508
  %2758 = phi float [ %2539, %2508 ], [ %2754, %2725 ]
  %2759 = phi float [ %2540, %2508 ], [ %2755, %2725 ]
  %2760 = phi float [ %2541, %2508 ], [ %2756, %2725 ]
  %2761 = call float @dx.op.binary.f32(i32 36, float %2496, float %2758)  ; FMin(a,b)
  %2762 = call float @dx.op.binary.f32(i32 36, float %2497, float %2759)  ; FMin(a,b)
  %2763 = call float @dx.op.binary.f32(i32 36, float %2498, float %2760)  ; FMin(a,b)
  %2764 = call float @dx.op.binary.f32(i32 36, float %1970, float %2232)  ; FMin(a,b)
  %2765 = call float @dx.op.binary.f32(i32 36, float %1971, float %2233)  ; FMin(a,b)
  %2766 = call float @dx.op.binary.f32(i32 36, float %1972, float %2234)  ; FMin(a,b)
  %2767 = call float @dx.op.binary.f32(i32 36, float %2764, float %2761)  ; FMin(a,b)
  %2768 = call float @dx.op.binary.f32(i32 36, float %2765, float %2762)  ; FMin(a,b)
  %2769 = call float @dx.op.binary.f32(i32 36, float %2766, float %2763)  ; FMin(a,b)
  %2770 = call float @dx.op.binary.f32(i32 36, float %1706, float %2767)  ; FMin(a,b)
  %2771 = call float @dx.op.binary.f32(i32 36, float %1707, float %2768)  ; FMin(a,b)
  %2772 = call float @dx.op.binary.f32(i32 36, float %1708, float %2769)  ; FMin(a,b)
  %2773 = call float @dx.op.binary.f32(i32 35, float %2496, float %2758)  ; FMax(a,b)
  %2774 = call float @dx.op.binary.f32(i32 35, float %2497, float %2759)  ; FMax(a,b)
  %2775 = call float @dx.op.binary.f32(i32 35, float %2498, float %2760)  ; FMax(a,b)
  %2776 = call float @dx.op.binary.f32(i32 35, float %1970, float %2232)  ; FMax(a,b)
  %2777 = call float @dx.op.binary.f32(i32 35, float %1971, float %2233)  ; FMax(a,b)
  %2778 = call float @dx.op.binary.f32(i32 35, float %1972, float %2234)  ; FMax(a,b)
  %2779 = call float @dx.op.binary.f32(i32 35, float %2776, float %2773)  ; FMax(a,b)
  %2780 = call float @dx.op.binary.f32(i32 35, float %2777, float %2774)  ; FMax(a,b)
  %2781 = call float @dx.op.binary.f32(i32 35, float %2778, float %2775)  ; FMax(a,b)
  %2782 = call float @dx.op.binary.f32(i32 35, float %1706, float %2779)  ; FMax(a,b)
  %2783 = call float @dx.op.binary.f32(i32 35, float %1707, float %2780)  ; FMax(a,b)
  %2784 = call float @dx.op.binary.f32(i32 35, float %1708, float %2781)  ; FMax(a,b)
  %2785 = fsub fast float %2782, %2770
  %2786 = fsub fast float %2783, %2771
  %2787 = fsub fast float %2784, %2772
  %2788 = call float @dx.op.unary.f32(i32 6, float %2785)  ; FAbs(value)
  %2789 = call float @dx.op.unary.f32(i32 6, float %2786)  ; FAbs(value)
  %2790 = call float @dx.op.unary.f32(i32 6, float %2787)  ; FAbs(value)
  %2791 = call float @dx.op.binary.f32(i32 35, float %2789, float %2790)  ; FMax(a,b)
  %2792 = call float @dx.op.binary.f32(i32 35, float %2788, float %2791)  ; FMax(a,b)
  %2793 = call float @dx.op.binary.f32(i32 35, float %2783, float %2784)  ; FMax(a,b)
  %2794 = call float @dx.op.binary.f32(i32 35, float %2782, float %2793)  ; FMax(a,b)
  %2795 = fmul fast float %2794, 1.250000e-01
  %2796 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %2795)  ; FMax(a,b)
  %2797 = fcmp fast ogt float %2792, %2796
  br i1 %2797, label %2798, label %2859

; <label>:2798                                    ; preds = %2757
  %2799 = fsub fast float %1970, %2232
  %2800 = fsub fast float %1971, %2233
  %2801 = fsub fast float %1972, %2234
  %2802 = call float @dx.op.unary.f32(i32 6, float %2799)  ; FAbs(value)
  %2803 = call float @dx.op.unary.f32(i32 6, float %2800)  ; FAbs(value)
  %2804 = call float @dx.op.unary.f32(i32 6, float %2801)  ; FAbs(value)
  %2805 = call float @dx.op.binary.f32(i32 35, float %2803, float %2804)  ; FMax(a,b)
  %2806 = call float @dx.op.binary.f32(i32 35, float %2802, float %2805)  ; FMax(a,b)
  %2807 = fsub fast float %2496, %2758
  %2808 = fsub fast float %2497, %2759
  %2809 = fsub fast float %2498, %2760
  %2810 = call float @dx.op.unary.f32(i32 6, float %2807)  ; FAbs(value)
  %2811 = call float @dx.op.unary.f32(i32 6, float %2808)  ; FAbs(value)
  %2812 = call float @dx.op.unary.f32(i32 6, float %2809)  ; FAbs(value)
  %2813 = call float @dx.op.binary.f32(i32 35, float %2811, float %2812)  ; FMax(a,b)
  %2814 = call float @dx.op.binary.f32(i32 35, float %2810, float %2813)  ; FMax(a,b)
  %2815 = fcmp fast olt float %2806, %2814
  %2816 = select i1 %2815, float %1970, float %2496
  %2817 = select i1 %2815, float %1971, float %2497
  %2818 = select i1 %2815, float %1972, float %2498
  %2819 = select i1 %2815, float %2232, float %2758
  %2820 = select i1 %2815, float %2233, float %2759
  %2821 = select i1 %2815, float %2234, float %2760
  %2822 = fsub fast float %1706, %2819
  %2823 = fsub fast float %1707, %2820
  %2824 = fsub fast float %1708, %2821
  %2825 = fsub fast float %1706, %2816
  %2826 = fsub fast float %1707, %2817
  %2827 = fsub fast float %1708, %2818
  %2828 = call float @dx.op.dot3.f32(i32 55, float %2825, float %2826, float %2827, float %2822, float %2823, float %2824)  ; Dot3(ax,ay,az,bx,by,bz)
  %2829 = fcmp fast ogt float %2828, 0.000000e+00
  br i1 %2829, label %2830, label %2841

; <label>:2830                                    ; preds = %2798
  %2831 = fsub fast float %2816, %2819
  %2832 = fsub fast float %2817, %2820
  %2833 = fsub fast float %2818, %2821
  %2834 = call float @dx.op.unary.f32(i32 6, float %2831)  ; FAbs(value)
  %2835 = call float @dx.op.unary.f32(i32 6, float %2832)  ; FAbs(value)
  %2836 = call float @dx.op.unary.f32(i32 6, float %2833)  ; FAbs(value)
  %2837 = call float @dx.op.binary.f32(i32 35, float %2835, float %2836)  ; FMax(a,b)
  %2838 = call float @dx.op.binary.f32(i32 35, float %2834, float %2837)  ; FMax(a,b)
  %2839 = fmul fast float %2792, 2.500000e-01
  %2840 = fcmp fast olt float %2838, %2839
  br label %2841

; <label>:2841                                    ; preds = %2830, %2798
  %2842 = phi i1 [ false, %2798 ], [ %2840, %2830 ]
  %2843 = select i1 %2842, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  %2844 = fadd fast float %2816, %2819
  %2845 = fadd fast float %2817, %2820
  %2846 = fadd fast float %2818, %2821
  %2847 = fmul fast float %2844, 5.000000e-01
  %2848 = fmul fast float %2845, 5.000000e-01
  %2849 = fmul fast float %2846, 5.000000e-01
  %2850 = fsub fast float %2847, %1706
  %2851 = fsub fast float %2848, %1707
  %2852 = fsub fast float %2849, %1708
  %2853 = fmul fast float %2843, %2850
  %2854 = fmul fast float %2843, %2851
  %2855 = fmul fast float %2843, %2852
  %2856 = fadd fast float %2853, %1706
  %2857 = fadd fast float %2854, %1707
  %2858 = fadd fast float %2855, %1708
  br label %2859

; <label>:2859                                    ; preds = %2841, %2757
  %2860 = phi float [ %2856, %2841 ], [ %1706, %2757 ]
  %2861 = phi float [ %2857, %2841 ], [ %1707, %2757 ]
  %2862 = phi float [ %2858, %2841 ], [ %1708, %2757 ]
  %2863 = fcmp fast ogt float %2860, 0x3F69A5C380000000
  %2864 = fcmp fast ogt float %2861, 0x3F69A5C380000000
  %2865 = fcmp fast ogt float %2862, 0x3F69A5C380000000
  %2866 = select i1 %2863, float 0.000000e+00, float 1.000000e+00
  %2867 = select i1 %2864, float 0.000000e+00, float 1.000000e+00
  %2868 = select i1 %2865, float 0.000000e+00, float 1.000000e+00
  %2869 = fmul fast float %2860, 0x4029D70A40000000
  %2870 = fmul fast float %2861, 0x4029D70A40000000
  %2871 = fmul fast float %2862, 0x4029D70A40000000
  %2872 = call float @dx.op.binary.f32(i32 35, float %2860, float 0.000000e+00)  ; FMax(a,b)
  %2873 = call float @dx.op.binary.f32(i32 35, float %2861, float 0.000000e+00)  ; FMax(a,b)
  %2874 = call float @dx.op.binary.f32(i32 35, float %2862, float 0.000000e+00)  ; FMax(a,b)
  %2875 = call float @dx.op.unary.f32(i32 23, float %2872)  ; Log(value)
  %2876 = call float @dx.op.unary.f32(i32 23, float %2873)  ; Log(value)
  %2877 = call float @dx.op.unary.f32(i32 23, float %2874)  ; Log(value)
  %2878 = fmul fast float %2875, 0x3FDAAAAAA0000000
  %2879 = fmul fast float %2876, 0x3FDAAAAAA0000000
  %2880 = fmul fast float %2877, 0x3FDAAAAAA0000000
  %2881 = call float @dx.op.unary.f32(i32 21, float %2878)  ; Exp(value)
  %2882 = call float @dx.op.unary.f32(i32 21, float %2879)  ; Exp(value)
  %2883 = call float @dx.op.unary.f32(i32 21, float %2880)  ; Exp(value)
  %2884 = fmul fast float %2881, 0x3FF0E147A0000000
  %2885 = fmul fast float %2882, 0x3FF0E147A0000000
  %2886 = fmul fast float %2883, 0x3FF0E147A0000000
  %2887 = fadd fast float %2884, 0xBFAC28F5C0000000
  %2888 = fadd fast float %2885, 0xBFAC28F5C0000000
  %2889 = fadd fast float %2886, 0xBFAC28F5C0000000
  %2890 = fsub fast float %2869, %2887
  %2891 = fsub fast float %2870, %2888
  %2892 = fsub fast float %2871, %2889
  %2893 = fmul fast float %2890, %2866
  %2894 = fmul fast float %2891, %2867
  %2895 = fmul fast float %2892, %2868
  %2896 = fadd fast float %2893, %2887
  %2897 = fadd fast float %2894, %2888
  %2898 = fadd fast float %2895, %2889
  br label %2899

; <label>:2899                                    ; preds = %2859, %1492
  %2900 = phi float [ %1487, %1492 ], [ %2896, %2859 ]
  %2901 = phi float [ %1488, %1492 ], [ %2897, %2859 ]
  %2902 = phi float [ %1489, %1492 ], [ %2898, %2859 ]
  %2903 = phi float [ %1493, %1492 ], [ %1490, %2859 ]
  %2904 = add i32 %56, 1
  %2905 = call i32 @dx.op.binary.i32(i32 37, i32 %2904, i32 0)  ; IMax(a,b)
  %2906 = call i32 @dx.op.binary.i32(i32 38, i32 %2905, i32 %60)  ; IMin(a,b)
  %2907 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %63, i32 %2906, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2908 = extractvalue %dx.types.ResRet.f32 %2907, 0
  %2909 = extractvalue %dx.types.ResRet.f32 %2907, 1
  %2910 = extractvalue %dx.types.ResRet.f32 %2907, 2
  %2911 = extractvalue %dx.types.ResRet.f32 %2907, 3
  %2912 = fcmp fast olt float %2911, 0.000000e+00
  br i1 %2912, label %2913, label %2915

; <label>:2913                                    ; preds = %2899
  %2914 = fsub fast float -1.000000e+00, %2911
  br label %4320

; <label>:2915                                    ; preds = %2899
  %2916 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %2906, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %2917 = extractvalue %dx.types.ResRet.f32 %2916, 0
  %2918 = fcmp fast ogt float %38, 5.000000e-01
  %2919 = fcmp fast olt float %2917, 1.000000e+00
  %2920 = and i1 %2918, %2919
  br i1 %2920, label %2921, label %3059

; <label>:2921                                    ; preds = %2915
  %2922 = sitofp i32 %63 to float
  %2923 = sitofp i32 %2906 to float
  %2924 = fadd fast float %2922, 5.000000e-01
  %2925 = fadd fast float %2923, 5.000000e-01
  %2926 = fdiv fast float %2924, %45
  %2927 = fdiv fast float %2925, %46
  %2928 = fmul fast float %2926, 2.000000e+00
  %2929 = fmul fast float %2927, 2.000000e+00
  %2930 = fadd fast float %2928, -1.000000e+00
  %2931 = fsub fast float 1.000000e+00, %2929
  %2932 = fmul fast float %2930, %35
  %2933 = call float @dx.op.tertiary.f32(i32 46, float %2931, float %31, float %2932)  ; FMad(a,b,c)
  %2934 = call float @dx.op.tertiary.f32(i32 46, float %2917, float %27, float %2933)  ; FMad(a,b,c)
  %2935 = fadd fast float %2934, %23
  %2936 = call float @dx.op.unary.f32(i32 6, float %2935)  ; FAbs(value)
  %2937 = fcmp fast ogt float %2936, 0x3EB0C6F7A0000000
  br i1 %2937, label %2938, label %3059

; <label>:2938                                    ; preds = %2921
  %2939 = fmul fast float %2930, %34
  %2940 = call float @dx.op.tertiary.f32(i32 46, float %2931, float %30, float %2939)  ; FMad(a,b,c)
  %2941 = call float @dx.op.tertiary.f32(i32 46, float %2917, float %26, float %2940)  ; FMad(a,b,c)
  %2942 = fadd fast float %2941, %22
  %2943 = fmul fast float %2930, %33
  %2944 = call float @dx.op.tertiary.f32(i32 46, float %2931, float %29, float %2943)  ; FMad(a,b,c)
  %2945 = call float @dx.op.tertiary.f32(i32 46, float %2917, float %25, float %2944)  ; FMad(a,b,c)
  %2946 = fadd fast float %2945, %21
  %2947 = fmul fast float %2930, %32
  %2948 = call float @dx.op.tertiary.f32(i32 46, float %2931, float %28, float %2947)  ; FMad(a,b,c)
  %2949 = call float @dx.op.tertiary.f32(i32 46, float %2917, float %24, float %2948)  ; FMad(a,b,c)
  %2950 = fadd fast float %2949, %20
  %2951 = fdiv fast float %2950, %2935
  %2952 = fdiv fast float %2946, %2935
  %2953 = fdiv fast float %2942, %2935
  %2954 = fsub fast float %2951, %17
  %2955 = fsub fast float %2952, %18
  %2956 = fsub fast float %2953, %19
  %2957 = fmul fast float %2954, %2954
  %2958 = fmul fast float %2955, %2955
  %2959 = fadd fast float %2958, %2957
  %2960 = fmul fast float %2956, %2956
  %2961 = fadd fast float %2959, %2960
  %2962 = call float @dx.op.unary.f32(i32 24, float %2961)  ; Sqrt(value)
  %2963 = fsub fast float %2962, %9
  %2964 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %2963)  ; FMax(a,b)
  %2965 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %2965, label %2966, label %2989

; <label>:2966                                    ; preds = %2938
  %2967 = call float @dx.op.unary.f32(i32 6, float %2955)  ; FAbs(value)
  %2968 = fmul fast float %2967, %11
  %2969 = fcmp fast olt float %2968, 0x3F50624DE0000000
  br i1 %2969, label %2970, label %2973

; <label>:2970                                    ; preds = %2966
  %2971 = fmul fast float %2968, 5.000000e-01
  %2972 = fsub fast float 1.000000e+00, %2971
  br label %2978

; <label>:2973                                    ; preds = %2966
  %2974 = fmul fast float %2968, 0xBFF7154760000000
  %2975 = call float @dx.op.unary.f32(i32 21, float %2974)  ; Exp(value)
  %2976 = fsub fast float 1.000000e+00, %2975
  %2977 = fdiv fast float %2976, %2968
  br label %2978

; <label>:2978                                    ; preds = %2973, %2970
  %2979 = phi float [ %2972, %2970 ], [ %2977, %2973 ]
  %2980 = call float @dx.op.binary.f32(i32 36, float %2952, float %18)  ; FMin(a,b)
  %2981 = fsub fast float %2980, %10
  %2982 = fmul fast float %11, %2981
  %2983 = fsub fast float -0.000000e+00, %2982
  %2984 = call float @dx.op.binary.f32(i32 35, float %2983, float -4.000000e+01)  ; FMax(a,b)
  %2985 = call float @dx.op.binary.f32(i32 36, float %2984, float 5.000000e+00)  ; FMin(a,b)
  %2986 = fmul fast float %2985, 0x3FF7154760000000
  %2987 = call float @dx.op.unary.f32(i32 21, float %2986)  ; Exp(value)
  %2988 = fmul fast float %2987, %2979
  br label %2989

; <label>:2989                                    ; preds = %2978, %2938
  %2990 = phi float [ %2988, %2978 ], [ 1.000000e+00, %2938 ]
  %2991 = fmul fast float %2964, %16
  %2992 = fmul fast float %2991, %2990
  %2993 = fcmp fast ole float %2962, %9
  %2994 = fcmp fast olt float %2962, 0x3F1A36E2E0000000
  %2995 = or i1 %2993, %2994
  br i1 %2995, label %3042, label %2996

; <label>:2996                                    ; preds = %2989
  %2997 = fdiv fast float %9, %2962
  %2998 = fmul fast float %2997, %2954
  %2999 = fmul fast float %2997, %2955
  %3000 = fmul fast float %2997, %2956
  %3001 = fadd fast float %2998, %17
  %3002 = fadd fast float %2999, %18
  %3003 = fadd fast float %3000, %19
  %3004 = fadd fast float %3001, -9.000000e+02
  %3005 = fadd fast float %3002, -1.500000e+01
  %3006 = fadd fast float %3003, -7.500000e+02
  %3007 = fmul fast float %3004, 0x3F62345680000000
  %3008 = fmul fast float %3005, 0x3F62345680000000
  %3009 = fmul fast float %3006, 0x3F62345680000000
  %3010 = call float @dx.op.dot3.f32(i32 55, float %3007, float %3008, float %3009, float %3007, float %3008, float %3009)  ; Dot3(ax,ay,az,bx,by,bz)
  %3011 = fsub fast float 1.000000e+00, %3010
  %3012 = call float @dx.op.unary.f32(i32 7, float %3011)  ; Saturate(value)
  %3013 = fmul fast float %3012, %3012
  %3014 = fadd fast float %3001, %2951
  %3015 = fadd fast float %3002, %2952
  %3016 = fadd fast float %3003, %2953
  %3017 = fmul fast float %3014, 0x3F52345680000000
  %3018 = fadd fast float %3017, -2.000000e+00
  %3019 = fmul fast float %3015, 0x3F52345680000000
  %3020 = fadd fast float %3019, 0xBFA1111120000000
  %3021 = fmul fast float %3016, 0x3F52345680000000
  %3022 = fadd fast float %3021, 0xBFFAAAAAC0000000
  %3023 = call float @dx.op.dot3.f32(i32 55, float %3018, float %3020, float %3022, float %3018, float %3020, float %3022)  ; Dot3(ax,ay,az,bx,by,bz)
  %3024 = fsub fast float 1.000000e+00, %3023
  %3025 = call float @dx.op.unary.f32(i32 7, float %3024)  ; Saturate(value)
  %3026 = fmul fast float %3025, %3025
  %3027 = fmul fast float %3026, 4.000000e+00
  %3028 = fadd fast float %3027, %3013
  %3029 = fadd fast float %2951, -9.000000e+02
  %3030 = fadd fast float %2952, -1.500000e+01
  %3031 = fadd fast float %2953, -7.500000e+02
  %3032 = fmul fast float %3029, 0x3F62345680000000
  %3033 = fmul fast float %3030, 0x3F62345680000000
  %3034 = fmul fast float %3031, 0x3F62345680000000
  %3035 = call float @dx.op.dot3.f32(i32 55, float %3032, float %3033, float %3034, float %3032, float %3033, float %3034)  ; Dot3(ax,ay,az,bx,by,bz)
  %3036 = fsub fast float 1.000000e+00, %3035
  %3037 = call float @dx.op.unary.f32(i32 7, float %3036)  ; Saturate(value)
  %3038 = fmul fast float %3037, %3037
  %3039 = fadd fast float %3028, %3038
  %3040 = fmul fast float %2963, 0x3F25D867E0000000
  %3041 = fmul fast float %3040, %3039
  br label %3042

; <label>:3042                                    ; preds = %2996, %2989
  %3043 = phi float [ %3041, %2996 ], [ 0.000000e+00, %2989 ]
  %3044 = fadd fast float %3043, %2992
  %3045 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3044)  ; FMin(a,b)
  %3046 = fmul fast float %3045, 0xBFF7154760000000
  %3047 = call float @dx.op.unary.f32(i32 21, float %3046)  ; Exp(value)
  %3048 = fsub fast float 1.000000e+00, %3047
  %3049 = call float @dx.op.binary.f32(i32 36, float %12, float %3048)  ; FMin(a,b)
  %3050 = fsub fast float %13, %2908
  %3051 = fsub fast float %14, %2909
  %3052 = fsub fast float %15, %2910
  %3053 = fmul fast float %3049, %3050
  %3054 = fmul fast float %3049, %3051
  %3055 = fmul fast float %3049, %3052
  %3056 = fadd fast float %3053, %2908
  %3057 = fadd fast float %3054, %2909
  %3058 = fadd fast float %3055, %2910
  br label %3059

; <label>:3059                                    ; preds = %3042, %2921, %2915
  %3060 = phi float [ %3056, %3042 ], [ %2908, %2921 ], [ %2908, %2915 ]
  %3061 = phi float [ %3057, %3042 ], [ %2909, %2921 ], [ %2909, %2915 ]
  %3062 = phi float [ %3058, %3042 ], [ %2910, %2921 ], [ %2910, %2915 ]
  %3063 = fadd fast float %5, 1.000000e+00
  %3064 = fadd fast float %6, 1.000000e+00
  %3065 = fsub fast float 1.000000e+00, %5
  %3066 = fmul fast float %36, %3063
  %3067 = fmul fast float %36, %3064
  %3068 = fmul fast float %36, %3065
  %3069 = fmul fast float %3066, %3060
  %3070 = fmul fast float %3067, %3061
  %3071 = fmul fast float %3068, %3062
  %3072 = fcmp fast ult float %37, 5.000000e-01
  br i1 %3072, label %3098, label %3073

; <label>:3073                                    ; preds = %3059
  %3074 = fmul fast float %3069, 0x4004147AE0000000
  %3075 = fmul fast float %3070, 0x4004147AE0000000
  %3076 = fmul fast float %3071, 0x4004147AE0000000
  %3077 = fadd fast float %3074, 0x3F9EB851E0000000
  %3078 = fadd fast float %3075, 0x3F9EB851E0000000
  %3079 = fadd fast float %3076, 0x3F9EB851E0000000
  %3080 = fmul fast float %3077, %3069
  %3081 = fmul fast float %3078, %3070
  %3082 = fmul fast float %3079, %3071
  %3083 = fmul fast float %3069, 0x400370A3E0000000
  %3084 = fmul fast float %3070, 0x400370A3E0000000
  %3085 = fmul fast float %3071, 0x400370A3E0000000
  %3086 = fadd fast float %3083, 0x3FE2E147A0000000
  %3087 = fadd fast float %3084, 0x3FE2E147A0000000
  %3088 = fadd fast float %3085, 0x3FE2E147A0000000
  %3089 = fmul fast float %3086, %3069
  %3090 = fmul fast float %3087, %3070
  %3091 = fmul fast float %3088, %3071
  %3092 = fadd fast float %3089, 0x3FC1EB8520000000
  %3093 = fadd fast float %3090, 0x3FC1EB8520000000
  %3094 = fadd fast float %3091, 0x3FC1EB8520000000
  %3095 = fdiv fast float %3080, %3092
  %3096 = fdiv fast float %3081, %3093
  %3097 = fdiv fast float %3082, %3094
  br label %3098

; <label>:3098                                    ; preds = %3073, %3059
  %3099 = phi float [ %3095, %3073 ], [ %3069, %3059 ]
  %3100 = phi float [ %3096, %3073 ], [ %3070, %3059 ]
  %3101 = phi float [ %3097, %3073 ], [ %3071, %3059 ]
  %3102 = call float @dx.op.unary.f32(i32 7, float %3099)  ; Saturate(value)
  %3103 = call float @dx.op.unary.f32(i32 7, float %3100)  ; Saturate(value)
  %3104 = call float @dx.op.unary.f32(i32 7, float %3101)  ; Saturate(value)
  %3105 = call float @dx.op.dot3.f32(i32 55, float %3102, float %3103, float %3104, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3106 = fsub fast float %3102, %3105
  %3107 = fsub fast float %3103, %3105
  %3108 = fsub fast float %3104, %3105
  %3109 = fmul fast float %3106, %8
  %3110 = fmul fast float %3107, %8
  %3111 = fmul fast float %3108, %8
  %3112 = fadd fast float %3109, %3105
  %3113 = fadd fast float %3110, %3105
  %3114 = fadd fast float %3111, %3105
  %3115 = call float @dx.op.unary.f32(i32 7, float %3112)  ; Saturate(value)
  %3116 = call float @dx.op.unary.f32(i32 7, float %3113)  ; Saturate(value)
  %3117 = call float @dx.op.unary.f32(i32 7, float %3114)  ; Saturate(value)
  %3118 = fadd fast float %3115, 0xBFC70A3D80000000
  %3119 = fadd fast float %3116, 0xBFC70A3D80000000
  %3120 = fadd fast float %3117, 0xBFC70A3D80000000
  %3121 = fmul fast float %3118, %7
  %3122 = fmul fast float %3119, %7
  %3123 = fmul fast float %3120, %7
  %3124 = fadd fast float %3121, 0x3FC70A3D80000000
  %3125 = fadd fast float %3122, 0x3FC70A3D80000000
  %3126 = fadd fast float %3123, 0x3FC70A3D80000000
  %3127 = call float @dx.op.unary.f32(i32 7, float %3124)  ; Saturate(value)
  %3128 = call float @dx.op.unary.f32(i32 7, float %3125)  ; Saturate(value)
  %3129 = call float @dx.op.unary.f32(i32 7, float %3126)  ; Saturate(value)
  %3130 = add i32 %2906, -1
  %3131 = call i32 @dx.op.binary.i32(i32 37, i32 %63, i32 0)  ; IMax(a,b)
  %3132 = call i32 @dx.op.binary.i32(i32 37, i32 %3130, i32 0)  ; IMax(a,b)
  %3133 = call i32 @dx.op.binary.i32(i32 38, i32 %3131, i32 %59)  ; IMin(a,b)
  %3134 = call i32 @dx.op.binary.i32(i32 38, i32 %3132, i32 %60)  ; IMin(a,b)
  %3135 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3133, i32 %3134, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3136 = extractvalue %dx.types.ResRet.f32 %3135, 0
  %3137 = extractvalue %dx.types.ResRet.f32 %3135, 1
  %3138 = extractvalue %dx.types.ResRet.f32 %3135, 2
  %3139 = extractvalue %dx.types.ResRet.f32 %3135, 3
  %3140 = fcmp fast olt float %3139, 0.000000e+00
  br i1 %3140, label %3141, label %3175

; <label>:3141                                    ; preds = %3098
  %3142 = fcmp fast ogt float %3136, 0x3FA4B5DCC0000000
  %3143 = fcmp fast ogt float %3137, 0x3FA4B5DCC0000000
  %3144 = fcmp fast ogt float %3138, 0x3FA4B5DCC0000000
  %3145 = select i1 %3142, float 0.000000e+00, float 1.000000e+00
  %3146 = select i1 %3143, float 0.000000e+00, float 1.000000e+00
  %3147 = select i1 %3144, float 0.000000e+00, float 1.000000e+00
  %3148 = fmul fast float %3136, 0x3FB3D07220000000
  %3149 = fmul fast float %3137, 0x3FB3D07220000000
  %3150 = fmul fast float %3138, 0x3FB3D07220000000
  %3151 = fadd fast float %3136, 0x3FAC28F5C0000000
  %3152 = fadd fast float %3137, 0x3FAC28F5C0000000
  %3153 = fadd fast float %3138, 0x3FAC28F5C0000000
  %3154 = fmul fast float %3151, 0x3FEE54EDE0000000
  %3155 = fmul fast float %3152, 0x3FEE54EDE0000000
  %3156 = fmul fast float %3153, 0x3FEE54EDE0000000
  %3157 = call float @dx.op.unary.f32(i32 23, float %3154)  ; Log(value)
  %3158 = call float @dx.op.unary.f32(i32 23, float %3155)  ; Log(value)
  %3159 = call float @dx.op.unary.f32(i32 23, float %3156)  ; Log(value)
  %3160 = fmul fast float %3157, 0x4003333340000000
  %3161 = fmul fast float %3158, 0x4003333340000000
  %3162 = fmul fast float %3159, 0x4003333340000000
  %3163 = call float @dx.op.unary.f32(i32 21, float %3160)  ; Exp(value)
  %3164 = call float @dx.op.unary.f32(i32 21, float %3161)  ; Exp(value)
  %3165 = call float @dx.op.unary.f32(i32 21, float %3162)  ; Exp(value)
  %3166 = fsub fast float %3148, %3163
  %3167 = fsub fast float %3149, %3164
  %3168 = fsub fast float %3150, %3165
  %3169 = fmul fast float %3166, %3145
  %3170 = fmul fast float %3167, %3146
  %3171 = fmul fast float %3168, %3147
  %3172 = fadd fast float %3169, %3163
  %3173 = fadd fast float %3170, %3164
  %3174 = fadd fast float %3171, %3165
  br label %3390

; <label>:3175                                    ; preds = %3098
  %3176 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3133, i32 %3134, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3177 = extractvalue %dx.types.ResRet.f32 %3176, 0
  %3178 = fcmp fast ogt float %38, 5.000000e-01
  %3179 = fcmp fast olt float %3177, 1.000000e+00
  %3180 = and i1 %3178, %3179
  br i1 %3180, label %3181, label %3319

; <label>:3181                                    ; preds = %3175
  %3182 = sitofp i32 %3133 to float
  %3183 = sitofp i32 %3134 to float
  %3184 = fadd fast float %3182, 5.000000e-01
  %3185 = fadd fast float %3183, 5.000000e-01
  %3186 = fdiv fast float %3184, %45
  %3187 = fdiv fast float %3185, %46
  %3188 = fmul fast float %3186, 2.000000e+00
  %3189 = fmul fast float %3187, 2.000000e+00
  %3190 = fadd fast float %3188, -1.000000e+00
  %3191 = fsub fast float 1.000000e+00, %3189
  %3192 = fmul fast float %3190, %35
  %3193 = call float @dx.op.tertiary.f32(i32 46, float %3191, float %31, float %3192)  ; FMad(a,b,c)
  %3194 = call float @dx.op.tertiary.f32(i32 46, float %3177, float %27, float %3193)  ; FMad(a,b,c)
  %3195 = fadd fast float %3194, %23
  %3196 = call float @dx.op.unary.f32(i32 6, float %3195)  ; FAbs(value)
  %3197 = fcmp fast ogt float %3196, 0x3EB0C6F7A0000000
  br i1 %3197, label %3198, label %3319

; <label>:3198                                    ; preds = %3181
  %3199 = fmul fast float %3190, %34
  %3200 = call float @dx.op.tertiary.f32(i32 46, float %3191, float %30, float %3199)  ; FMad(a,b,c)
  %3201 = call float @dx.op.tertiary.f32(i32 46, float %3177, float %26, float %3200)  ; FMad(a,b,c)
  %3202 = fadd fast float %3201, %22
  %3203 = fmul fast float %3190, %33
  %3204 = call float @dx.op.tertiary.f32(i32 46, float %3191, float %29, float %3203)  ; FMad(a,b,c)
  %3205 = call float @dx.op.tertiary.f32(i32 46, float %3177, float %25, float %3204)  ; FMad(a,b,c)
  %3206 = fadd fast float %3205, %21
  %3207 = fmul fast float %3190, %32
  %3208 = call float @dx.op.tertiary.f32(i32 46, float %3191, float %28, float %3207)  ; FMad(a,b,c)
  %3209 = call float @dx.op.tertiary.f32(i32 46, float %3177, float %24, float %3208)  ; FMad(a,b,c)
  %3210 = fadd fast float %3209, %20
  %3211 = fdiv fast float %3210, %3195
  %3212 = fdiv fast float %3206, %3195
  %3213 = fdiv fast float %3202, %3195
  %3214 = fsub fast float %3211, %17
  %3215 = fsub fast float %3212, %18
  %3216 = fsub fast float %3213, %19
  %3217 = fmul fast float %3214, %3214
  %3218 = fmul fast float %3215, %3215
  %3219 = fadd fast float %3218, %3217
  %3220 = fmul fast float %3216, %3216
  %3221 = fadd fast float %3219, %3220
  %3222 = call float @dx.op.unary.f32(i32 24, float %3221)  ; Sqrt(value)
  %3223 = fsub fast float %3222, %9
  %3224 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3223)  ; FMax(a,b)
  %3225 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %3225, label %3226, label %3249

; <label>:3226                                    ; preds = %3198
  %3227 = call float @dx.op.unary.f32(i32 6, float %3215)  ; FAbs(value)
  %3228 = fmul fast float %3227, %11
  %3229 = fcmp fast olt float %3228, 0x3F50624DE0000000
  br i1 %3229, label %3230, label %3233

; <label>:3230                                    ; preds = %3226
  %3231 = fmul fast float %3228, 5.000000e-01
  %3232 = fsub fast float 1.000000e+00, %3231
  br label %3238

; <label>:3233                                    ; preds = %3226
  %3234 = fmul fast float %3228, 0xBFF7154760000000
  %3235 = call float @dx.op.unary.f32(i32 21, float %3234)  ; Exp(value)
  %3236 = fsub fast float 1.000000e+00, %3235
  %3237 = fdiv fast float %3236, %3228
  br label %3238

; <label>:3238                                    ; preds = %3233, %3230
  %3239 = phi float [ %3232, %3230 ], [ %3237, %3233 ]
  %3240 = call float @dx.op.binary.f32(i32 36, float %3212, float %18)  ; FMin(a,b)
  %3241 = fsub fast float %3240, %10
  %3242 = fmul fast float %11, %3241
  %3243 = fsub fast float -0.000000e+00, %3242
  %3244 = call float @dx.op.binary.f32(i32 35, float %3243, float -4.000000e+01)  ; FMax(a,b)
  %3245 = call float @dx.op.binary.f32(i32 36, float %3244, float 5.000000e+00)  ; FMin(a,b)
  %3246 = fmul fast float %3245, 0x3FF7154760000000
  %3247 = call float @dx.op.unary.f32(i32 21, float %3246)  ; Exp(value)
  %3248 = fmul fast float %3247, %3239
  br label %3249

; <label>:3249                                    ; preds = %3238, %3198
  %3250 = phi float [ %3248, %3238 ], [ 1.000000e+00, %3198 ]
  %3251 = fmul fast float %3224, %16
  %3252 = fmul fast float %3251, %3250
  %3253 = fcmp fast ole float %3222, %9
  %3254 = fcmp fast olt float %3222, 0x3F1A36E2E0000000
  %3255 = or i1 %3253, %3254
  br i1 %3255, label %3302, label %3256

; <label>:3256                                    ; preds = %3249
  %3257 = fdiv fast float %9, %3222
  %3258 = fmul fast float %3257, %3214
  %3259 = fmul fast float %3257, %3215
  %3260 = fmul fast float %3257, %3216
  %3261 = fadd fast float %3258, %17
  %3262 = fadd fast float %3259, %18
  %3263 = fadd fast float %3260, %19
  %3264 = fadd fast float %3261, -9.000000e+02
  %3265 = fadd fast float %3262, -1.500000e+01
  %3266 = fadd fast float %3263, -7.500000e+02
  %3267 = fmul fast float %3264, 0x3F62345680000000
  %3268 = fmul fast float %3265, 0x3F62345680000000
  %3269 = fmul fast float %3266, 0x3F62345680000000
  %3270 = call float @dx.op.dot3.f32(i32 55, float %3267, float %3268, float %3269, float %3267, float %3268, float %3269)  ; Dot3(ax,ay,az,bx,by,bz)
  %3271 = fsub fast float 1.000000e+00, %3270
  %3272 = call float @dx.op.unary.f32(i32 7, float %3271)  ; Saturate(value)
  %3273 = fmul fast float %3272, %3272
  %3274 = fadd fast float %3261, %3211
  %3275 = fadd fast float %3262, %3212
  %3276 = fadd fast float %3263, %3213
  %3277 = fmul fast float %3274, 0x3F52345680000000
  %3278 = fadd fast float %3277, -2.000000e+00
  %3279 = fmul fast float %3275, 0x3F52345680000000
  %3280 = fadd fast float %3279, 0xBFA1111120000000
  %3281 = fmul fast float %3276, 0x3F52345680000000
  %3282 = fadd fast float %3281, 0xBFFAAAAAC0000000
  %3283 = call float @dx.op.dot3.f32(i32 55, float %3278, float %3280, float %3282, float %3278, float %3280, float %3282)  ; Dot3(ax,ay,az,bx,by,bz)
  %3284 = fsub fast float 1.000000e+00, %3283
  %3285 = call float @dx.op.unary.f32(i32 7, float %3284)  ; Saturate(value)
  %3286 = fmul fast float %3285, %3285
  %3287 = fmul fast float %3286, 4.000000e+00
  %3288 = fadd fast float %3287, %3273
  %3289 = fadd fast float %3211, -9.000000e+02
  %3290 = fadd fast float %3212, -1.500000e+01
  %3291 = fadd fast float %3213, -7.500000e+02
  %3292 = fmul fast float %3289, 0x3F62345680000000
  %3293 = fmul fast float %3290, 0x3F62345680000000
  %3294 = fmul fast float %3291, 0x3F62345680000000
  %3295 = call float @dx.op.dot3.f32(i32 55, float %3292, float %3293, float %3294, float %3292, float %3293, float %3294)  ; Dot3(ax,ay,az,bx,by,bz)
  %3296 = fsub fast float 1.000000e+00, %3295
  %3297 = call float @dx.op.unary.f32(i32 7, float %3296)  ; Saturate(value)
  %3298 = fmul fast float %3297, %3297
  %3299 = fadd fast float %3288, %3298
  %3300 = fmul fast float %3223, 0x3F25D867E0000000
  %3301 = fmul fast float %3300, %3299
  br label %3302

; <label>:3302                                    ; preds = %3256, %3249
  %3303 = phi float [ %3301, %3256 ], [ 0.000000e+00, %3249 ]
  %3304 = fadd fast float %3303, %3252
  %3305 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3304)  ; FMin(a,b)
  %3306 = fmul fast float %3305, 0xBFF7154760000000
  %3307 = call float @dx.op.unary.f32(i32 21, float %3306)  ; Exp(value)
  %3308 = fsub fast float 1.000000e+00, %3307
  %3309 = call float @dx.op.binary.f32(i32 36, float %12, float %3308)  ; FMin(a,b)
  %3310 = fsub fast float %13, %3136
  %3311 = fsub fast float %14, %3137
  %3312 = fsub fast float %15, %3138
  %3313 = fmul fast float %3309, %3310
  %3314 = fmul fast float %3309, %3311
  %3315 = fmul fast float %3309, %3312
  %3316 = fadd fast float %3313, %3136
  %3317 = fadd fast float %3314, %3137
  %3318 = fadd fast float %3315, %3138
  br label %3319

; <label>:3319                                    ; preds = %3302, %3181, %3175
  %3320 = phi float [ %3316, %3302 ], [ %3136, %3181 ], [ %3136, %3175 ]
  %3321 = phi float [ %3317, %3302 ], [ %3137, %3181 ], [ %3137, %3175 ]
  %3322 = phi float [ %3318, %3302 ], [ %3138, %3181 ], [ %3138, %3175 ]
  %3323 = fadd fast float %5, 1.000000e+00
  %3324 = fadd fast float %6, 1.000000e+00
  %3325 = fsub fast float 1.000000e+00, %5
  %3326 = fmul fast float %36, %3323
  %3327 = fmul fast float %36, %3324
  %3328 = fmul fast float %36, %3325
  %3329 = fmul fast float %3326, %3320
  %3330 = fmul fast float %3327, %3321
  %3331 = fmul fast float %3328, %3322
  %3332 = fcmp fast ult float %37, 5.000000e-01
  br i1 %3332, label %3358, label %3333

; <label>:3333                                    ; preds = %3319
  %3334 = fmul fast float %3329, 0x4004147AE0000000
  %3335 = fmul fast float %3330, 0x4004147AE0000000
  %3336 = fmul fast float %3331, 0x4004147AE0000000
  %3337 = fadd fast float %3334, 0x3F9EB851E0000000
  %3338 = fadd fast float %3335, 0x3F9EB851E0000000
  %3339 = fadd fast float %3336, 0x3F9EB851E0000000
  %3340 = fmul fast float %3337, %3329
  %3341 = fmul fast float %3338, %3330
  %3342 = fmul fast float %3339, %3331
  %3343 = fmul fast float %3329, 0x400370A3E0000000
  %3344 = fmul fast float %3330, 0x400370A3E0000000
  %3345 = fmul fast float %3331, 0x400370A3E0000000
  %3346 = fadd fast float %3343, 0x3FE2E147A0000000
  %3347 = fadd fast float %3344, 0x3FE2E147A0000000
  %3348 = fadd fast float %3345, 0x3FE2E147A0000000
  %3349 = fmul fast float %3346, %3329
  %3350 = fmul fast float %3347, %3330
  %3351 = fmul fast float %3348, %3331
  %3352 = fadd fast float %3349, 0x3FC1EB8520000000
  %3353 = fadd fast float %3350, 0x3FC1EB8520000000
  %3354 = fadd fast float %3351, 0x3FC1EB8520000000
  %3355 = fdiv fast float %3340, %3352
  %3356 = fdiv fast float %3341, %3353
  %3357 = fdiv fast float %3342, %3354
  br label %3358

; <label>:3358                                    ; preds = %3333, %3319
  %3359 = phi float [ %3355, %3333 ], [ %3329, %3319 ]
  %3360 = phi float [ %3356, %3333 ], [ %3330, %3319 ]
  %3361 = phi float [ %3357, %3333 ], [ %3331, %3319 ]
  %3362 = call float @dx.op.unary.f32(i32 7, float %3359)  ; Saturate(value)
  %3363 = call float @dx.op.unary.f32(i32 7, float %3360)  ; Saturate(value)
  %3364 = call float @dx.op.unary.f32(i32 7, float %3361)  ; Saturate(value)
  %3365 = call float @dx.op.dot3.f32(i32 55, float %3362, float %3363, float %3364, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3366 = fsub fast float %3362, %3365
  %3367 = fsub fast float %3363, %3365
  %3368 = fsub fast float %3364, %3365
  %3369 = fmul fast float %3366, %8
  %3370 = fmul fast float %3367, %8
  %3371 = fmul fast float %3368, %8
  %3372 = fadd fast float %3369, %3365
  %3373 = fadd fast float %3370, %3365
  %3374 = fadd fast float %3371, %3365
  %3375 = call float @dx.op.unary.f32(i32 7, float %3372)  ; Saturate(value)
  %3376 = call float @dx.op.unary.f32(i32 7, float %3373)  ; Saturate(value)
  %3377 = call float @dx.op.unary.f32(i32 7, float %3374)  ; Saturate(value)
  %3378 = fadd fast float %3375, 0xBFC70A3D80000000
  %3379 = fadd fast float %3376, 0xBFC70A3D80000000
  %3380 = fadd fast float %3377, 0xBFC70A3D80000000
  %3381 = fmul fast float %3378, %7
  %3382 = fmul fast float %3379, %7
  %3383 = fmul fast float %3380, %7
  %3384 = fadd fast float %3381, 0x3FC70A3D80000000
  %3385 = fadd fast float %3382, 0x3FC70A3D80000000
  %3386 = fadd fast float %3383, 0x3FC70A3D80000000
  %3387 = call float @dx.op.unary.f32(i32 7, float %3384)  ; Saturate(value)
  %3388 = call float @dx.op.unary.f32(i32 7, float %3385)  ; Saturate(value)
  %3389 = call float @dx.op.unary.f32(i32 7, float %3386)  ; Saturate(value)
  br label %3390

; <label>:3390                                    ; preds = %3358, %3141
  %3391 = phi float [ %3172, %3141 ], [ %3387, %3358 ]
  %3392 = phi float [ %3173, %3141 ], [ %3388, %3358 ]
  %3393 = phi float [ %3174, %3141 ], [ %3389, %3358 ]
  %3394 = add i32 %2906, 1
  %3395 = call i32 @dx.op.binary.i32(i32 37, i32 %3394, i32 0)  ; IMax(a,b)
  %3396 = call i32 @dx.op.binary.i32(i32 38, i32 %3395, i32 %60)  ; IMin(a,b)
  %3397 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3133, i32 %3396, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3398 = extractvalue %dx.types.ResRet.f32 %3397, 0
  %3399 = extractvalue %dx.types.ResRet.f32 %3397, 1
  %3400 = extractvalue %dx.types.ResRet.f32 %3397, 2
  %3401 = extractvalue %dx.types.ResRet.f32 %3397, 3
  %3402 = fcmp fast olt float %3401, 0.000000e+00
  br i1 %3402, label %3403, label %3437

; <label>:3403                                    ; preds = %3390
  %3404 = fcmp fast ogt float %3398, 0x3FA4B5DCC0000000
  %3405 = fcmp fast ogt float %3399, 0x3FA4B5DCC0000000
  %3406 = fcmp fast ogt float %3400, 0x3FA4B5DCC0000000
  %3407 = select i1 %3404, float 0.000000e+00, float 1.000000e+00
  %3408 = select i1 %3405, float 0.000000e+00, float 1.000000e+00
  %3409 = select i1 %3406, float 0.000000e+00, float 1.000000e+00
  %3410 = fmul fast float %3398, 0x3FB3D07220000000
  %3411 = fmul fast float %3399, 0x3FB3D07220000000
  %3412 = fmul fast float %3400, 0x3FB3D07220000000
  %3413 = fadd fast float %3398, 0x3FAC28F5C0000000
  %3414 = fadd fast float %3399, 0x3FAC28F5C0000000
  %3415 = fadd fast float %3400, 0x3FAC28F5C0000000
  %3416 = fmul fast float %3413, 0x3FEE54EDE0000000
  %3417 = fmul fast float %3414, 0x3FEE54EDE0000000
  %3418 = fmul fast float %3415, 0x3FEE54EDE0000000
  %3419 = call float @dx.op.unary.f32(i32 23, float %3416)  ; Log(value)
  %3420 = call float @dx.op.unary.f32(i32 23, float %3417)  ; Log(value)
  %3421 = call float @dx.op.unary.f32(i32 23, float %3418)  ; Log(value)
  %3422 = fmul fast float %3419, 0x4003333340000000
  %3423 = fmul fast float %3420, 0x4003333340000000
  %3424 = fmul fast float %3421, 0x4003333340000000
  %3425 = call float @dx.op.unary.f32(i32 21, float %3422)  ; Exp(value)
  %3426 = call float @dx.op.unary.f32(i32 21, float %3423)  ; Exp(value)
  %3427 = call float @dx.op.unary.f32(i32 21, float %3424)  ; Exp(value)
  %3428 = fsub fast float %3410, %3425
  %3429 = fsub fast float %3411, %3426
  %3430 = fsub fast float %3412, %3427
  %3431 = fmul fast float %3428, %3407
  %3432 = fmul fast float %3429, %3408
  %3433 = fmul fast float %3430, %3409
  %3434 = fadd fast float %3431, %3425
  %3435 = fadd fast float %3432, %3426
  %3436 = fadd fast float %3433, %3427
  br label %3652

; <label>:3437                                    ; preds = %3390
  %3438 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3133, i32 %3396, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3439 = extractvalue %dx.types.ResRet.f32 %3438, 0
  %3440 = fcmp fast ogt float %38, 5.000000e-01
  %3441 = fcmp fast olt float %3439, 1.000000e+00
  %3442 = and i1 %3440, %3441
  br i1 %3442, label %3443, label %3581

; <label>:3443                                    ; preds = %3437
  %3444 = sitofp i32 %3133 to float
  %3445 = sitofp i32 %3396 to float
  %3446 = fadd fast float %3444, 5.000000e-01
  %3447 = fadd fast float %3445, 5.000000e-01
  %3448 = fdiv fast float %3446, %45
  %3449 = fdiv fast float %3447, %46
  %3450 = fmul fast float %3448, 2.000000e+00
  %3451 = fmul fast float %3449, 2.000000e+00
  %3452 = fadd fast float %3450, -1.000000e+00
  %3453 = fsub fast float 1.000000e+00, %3451
  %3454 = fmul fast float %3452, %35
  %3455 = call float @dx.op.tertiary.f32(i32 46, float %3453, float %31, float %3454)  ; FMad(a,b,c)
  %3456 = call float @dx.op.tertiary.f32(i32 46, float %3439, float %27, float %3455)  ; FMad(a,b,c)
  %3457 = fadd fast float %3456, %23
  %3458 = call float @dx.op.unary.f32(i32 6, float %3457)  ; FAbs(value)
  %3459 = fcmp fast ogt float %3458, 0x3EB0C6F7A0000000
  br i1 %3459, label %3460, label %3581

; <label>:3460                                    ; preds = %3443
  %3461 = fmul fast float %3452, %34
  %3462 = call float @dx.op.tertiary.f32(i32 46, float %3453, float %30, float %3461)  ; FMad(a,b,c)
  %3463 = call float @dx.op.tertiary.f32(i32 46, float %3439, float %26, float %3462)  ; FMad(a,b,c)
  %3464 = fadd fast float %3463, %22
  %3465 = fmul fast float %3452, %33
  %3466 = call float @dx.op.tertiary.f32(i32 46, float %3453, float %29, float %3465)  ; FMad(a,b,c)
  %3467 = call float @dx.op.tertiary.f32(i32 46, float %3439, float %25, float %3466)  ; FMad(a,b,c)
  %3468 = fadd fast float %3467, %21
  %3469 = fmul fast float %3452, %32
  %3470 = call float @dx.op.tertiary.f32(i32 46, float %3453, float %28, float %3469)  ; FMad(a,b,c)
  %3471 = call float @dx.op.tertiary.f32(i32 46, float %3439, float %24, float %3470)  ; FMad(a,b,c)
  %3472 = fadd fast float %3471, %20
  %3473 = fdiv fast float %3472, %3457
  %3474 = fdiv fast float %3468, %3457
  %3475 = fdiv fast float %3464, %3457
  %3476 = fsub fast float %3473, %17
  %3477 = fsub fast float %3474, %18
  %3478 = fsub fast float %3475, %19
  %3479 = fmul fast float %3476, %3476
  %3480 = fmul fast float %3477, %3477
  %3481 = fadd fast float %3480, %3479
  %3482 = fmul fast float %3478, %3478
  %3483 = fadd fast float %3481, %3482
  %3484 = call float @dx.op.unary.f32(i32 24, float %3483)  ; Sqrt(value)
  %3485 = fsub fast float %3484, %9
  %3486 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3485)  ; FMax(a,b)
  %3487 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %3487, label %3488, label %3511

; <label>:3488                                    ; preds = %3460
  %3489 = call float @dx.op.unary.f32(i32 6, float %3477)  ; FAbs(value)
  %3490 = fmul fast float %3489, %11
  %3491 = fcmp fast olt float %3490, 0x3F50624DE0000000
  br i1 %3491, label %3492, label %3495

; <label>:3492                                    ; preds = %3488
  %3493 = fmul fast float %3490, 5.000000e-01
  %3494 = fsub fast float 1.000000e+00, %3493
  br label %3500

; <label>:3495                                    ; preds = %3488
  %3496 = fmul fast float %3490, 0xBFF7154760000000
  %3497 = call float @dx.op.unary.f32(i32 21, float %3496)  ; Exp(value)
  %3498 = fsub fast float 1.000000e+00, %3497
  %3499 = fdiv fast float %3498, %3490
  br label %3500

; <label>:3500                                    ; preds = %3495, %3492
  %3501 = phi float [ %3494, %3492 ], [ %3499, %3495 ]
  %3502 = call float @dx.op.binary.f32(i32 36, float %3474, float %18)  ; FMin(a,b)
  %3503 = fsub fast float %3502, %10
  %3504 = fmul fast float %11, %3503
  %3505 = fsub fast float -0.000000e+00, %3504
  %3506 = call float @dx.op.binary.f32(i32 35, float %3505, float -4.000000e+01)  ; FMax(a,b)
  %3507 = call float @dx.op.binary.f32(i32 36, float %3506, float 5.000000e+00)  ; FMin(a,b)
  %3508 = fmul fast float %3507, 0x3FF7154760000000
  %3509 = call float @dx.op.unary.f32(i32 21, float %3508)  ; Exp(value)
  %3510 = fmul fast float %3509, %3501
  br label %3511

; <label>:3511                                    ; preds = %3500, %3460
  %3512 = phi float [ %3510, %3500 ], [ 1.000000e+00, %3460 ]
  %3513 = fmul fast float %3486, %16
  %3514 = fmul fast float %3513, %3512
  %3515 = fcmp fast ole float %3484, %9
  %3516 = fcmp fast olt float %3484, 0x3F1A36E2E0000000
  %3517 = or i1 %3515, %3516
  br i1 %3517, label %3564, label %3518

; <label>:3518                                    ; preds = %3511
  %3519 = fdiv fast float %9, %3484
  %3520 = fmul fast float %3519, %3476
  %3521 = fmul fast float %3519, %3477
  %3522 = fmul fast float %3519, %3478
  %3523 = fadd fast float %3520, %17
  %3524 = fadd fast float %3521, %18
  %3525 = fadd fast float %3522, %19
  %3526 = fadd fast float %3523, -9.000000e+02
  %3527 = fadd fast float %3524, -1.500000e+01
  %3528 = fadd fast float %3525, -7.500000e+02
  %3529 = fmul fast float %3526, 0x3F62345680000000
  %3530 = fmul fast float %3527, 0x3F62345680000000
  %3531 = fmul fast float %3528, 0x3F62345680000000
  %3532 = call float @dx.op.dot3.f32(i32 55, float %3529, float %3530, float %3531, float %3529, float %3530, float %3531)  ; Dot3(ax,ay,az,bx,by,bz)
  %3533 = fsub fast float 1.000000e+00, %3532
  %3534 = call float @dx.op.unary.f32(i32 7, float %3533)  ; Saturate(value)
  %3535 = fmul fast float %3534, %3534
  %3536 = fadd fast float %3523, %3473
  %3537 = fadd fast float %3524, %3474
  %3538 = fadd fast float %3525, %3475
  %3539 = fmul fast float %3536, 0x3F52345680000000
  %3540 = fadd fast float %3539, -2.000000e+00
  %3541 = fmul fast float %3537, 0x3F52345680000000
  %3542 = fadd fast float %3541, 0xBFA1111120000000
  %3543 = fmul fast float %3538, 0x3F52345680000000
  %3544 = fadd fast float %3543, 0xBFFAAAAAC0000000
  %3545 = call float @dx.op.dot3.f32(i32 55, float %3540, float %3542, float %3544, float %3540, float %3542, float %3544)  ; Dot3(ax,ay,az,bx,by,bz)
  %3546 = fsub fast float 1.000000e+00, %3545
  %3547 = call float @dx.op.unary.f32(i32 7, float %3546)  ; Saturate(value)
  %3548 = fmul fast float %3547, %3547
  %3549 = fmul fast float %3548, 4.000000e+00
  %3550 = fadd fast float %3549, %3535
  %3551 = fadd fast float %3473, -9.000000e+02
  %3552 = fadd fast float %3474, -1.500000e+01
  %3553 = fadd fast float %3475, -7.500000e+02
  %3554 = fmul fast float %3551, 0x3F62345680000000
  %3555 = fmul fast float %3552, 0x3F62345680000000
  %3556 = fmul fast float %3553, 0x3F62345680000000
  %3557 = call float @dx.op.dot3.f32(i32 55, float %3554, float %3555, float %3556, float %3554, float %3555, float %3556)  ; Dot3(ax,ay,az,bx,by,bz)
  %3558 = fsub fast float 1.000000e+00, %3557
  %3559 = call float @dx.op.unary.f32(i32 7, float %3558)  ; Saturate(value)
  %3560 = fmul fast float %3559, %3559
  %3561 = fadd fast float %3550, %3560
  %3562 = fmul fast float %3485, 0x3F25D867E0000000
  %3563 = fmul fast float %3562, %3561
  br label %3564

; <label>:3564                                    ; preds = %3518, %3511
  %3565 = phi float [ %3563, %3518 ], [ 0.000000e+00, %3511 ]
  %3566 = fadd fast float %3565, %3514
  %3567 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3566)  ; FMin(a,b)
  %3568 = fmul fast float %3567, 0xBFF7154760000000
  %3569 = call float @dx.op.unary.f32(i32 21, float %3568)  ; Exp(value)
  %3570 = fsub fast float 1.000000e+00, %3569
  %3571 = call float @dx.op.binary.f32(i32 36, float %12, float %3570)  ; FMin(a,b)
  %3572 = fsub fast float %13, %3398
  %3573 = fsub fast float %14, %3399
  %3574 = fsub fast float %15, %3400
  %3575 = fmul fast float %3571, %3572
  %3576 = fmul fast float %3571, %3573
  %3577 = fmul fast float %3571, %3574
  %3578 = fadd fast float %3575, %3398
  %3579 = fadd fast float %3576, %3399
  %3580 = fadd fast float %3577, %3400
  br label %3581

; <label>:3581                                    ; preds = %3564, %3443, %3437
  %3582 = phi float [ %3578, %3564 ], [ %3398, %3443 ], [ %3398, %3437 ]
  %3583 = phi float [ %3579, %3564 ], [ %3399, %3443 ], [ %3399, %3437 ]
  %3584 = phi float [ %3580, %3564 ], [ %3400, %3443 ], [ %3400, %3437 ]
  %3585 = fadd fast float %5, 1.000000e+00
  %3586 = fadd fast float %6, 1.000000e+00
  %3587 = fsub fast float 1.000000e+00, %5
  %3588 = fmul fast float %36, %3585
  %3589 = fmul fast float %36, %3586
  %3590 = fmul fast float %36, %3587
  %3591 = fmul fast float %3588, %3582
  %3592 = fmul fast float %3589, %3583
  %3593 = fmul fast float %3590, %3584
  %3594 = fcmp fast ult float %37, 5.000000e-01
  br i1 %3594, label %3620, label %3595

; <label>:3595                                    ; preds = %3581
  %3596 = fmul fast float %3591, 0x4004147AE0000000
  %3597 = fmul fast float %3592, 0x4004147AE0000000
  %3598 = fmul fast float %3593, 0x4004147AE0000000
  %3599 = fadd fast float %3596, 0x3F9EB851E0000000
  %3600 = fadd fast float %3597, 0x3F9EB851E0000000
  %3601 = fadd fast float %3598, 0x3F9EB851E0000000
  %3602 = fmul fast float %3599, %3591
  %3603 = fmul fast float %3600, %3592
  %3604 = fmul fast float %3601, %3593
  %3605 = fmul fast float %3591, 0x400370A3E0000000
  %3606 = fmul fast float %3592, 0x400370A3E0000000
  %3607 = fmul fast float %3593, 0x400370A3E0000000
  %3608 = fadd fast float %3605, 0x3FE2E147A0000000
  %3609 = fadd fast float %3606, 0x3FE2E147A0000000
  %3610 = fadd fast float %3607, 0x3FE2E147A0000000
  %3611 = fmul fast float %3608, %3591
  %3612 = fmul fast float %3609, %3592
  %3613 = fmul fast float %3610, %3593
  %3614 = fadd fast float %3611, 0x3FC1EB8520000000
  %3615 = fadd fast float %3612, 0x3FC1EB8520000000
  %3616 = fadd fast float %3613, 0x3FC1EB8520000000
  %3617 = fdiv fast float %3602, %3614
  %3618 = fdiv fast float %3603, %3615
  %3619 = fdiv fast float %3604, %3616
  br label %3620

; <label>:3620                                    ; preds = %3595, %3581
  %3621 = phi float [ %3617, %3595 ], [ %3591, %3581 ]
  %3622 = phi float [ %3618, %3595 ], [ %3592, %3581 ]
  %3623 = phi float [ %3619, %3595 ], [ %3593, %3581 ]
  %3624 = call float @dx.op.unary.f32(i32 7, float %3621)  ; Saturate(value)
  %3625 = call float @dx.op.unary.f32(i32 7, float %3622)  ; Saturate(value)
  %3626 = call float @dx.op.unary.f32(i32 7, float %3623)  ; Saturate(value)
  %3627 = call float @dx.op.dot3.f32(i32 55, float %3624, float %3625, float %3626, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3628 = fsub fast float %3624, %3627
  %3629 = fsub fast float %3625, %3627
  %3630 = fsub fast float %3626, %3627
  %3631 = fmul fast float %3628, %8
  %3632 = fmul fast float %3629, %8
  %3633 = fmul fast float %3630, %8
  %3634 = fadd fast float %3631, %3627
  %3635 = fadd fast float %3632, %3627
  %3636 = fadd fast float %3633, %3627
  %3637 = call float @dx.op.unary.f32(i32 7, float %3634)  ; Saturate(value)
  %3638 = call float @dx.op.unary.f32(i32 7, float %3635)  ; Saturate(value)
  %3639 = call float @dx.op.unary.f32(i32 7, float %3636)  ; Saturate(value)
  %3640 = fadd fast float %3637, 0xBFC70A3D80000000
  %3641 = fadd fast float %3638, 0xBFC70A3D80000000
  %3642 = fadd fast float %3639, 0xBFC70A3D80000000
  %3643 = fmul fast float %3640, %7
  %3644 = fmul fast float %3641, %7
  %3645 = fmul fast float %3642, %7
  %3646 = fadd fast float %3643, 0x3FC70A3D80000000
  %3647 = fadd fast float %3644, 0x3FC70A3D80000000
  %3648 = fadd fast float %3645, 0x3FC70A3D80000000
  %3649 = call float @dx.op.unary.f32(i32 7, float %3646)  ; Saturate(value)
  %3650 = call float @dx.op.unary.f32(i32 7, float %3647)  ; Saturate(value)
  %3651 = call float @dx.op.unary.f32(i32 7, float %3648)  ; Saturate(value)
  br label %3652

; <label>:3652                                    ; preds = %3620, %3403
  %3653 = phi float [ %3434, %3403 ], [ %3649, %3620 ]
  %3654 = phi float [ %3435, %3403 ], [ %3650, %3620 ]
  %3655 = phi float [ %3436, %3403 ], [ %3651, %3620 ]
  %3656 = add i32 %63, -1
  %3657 = call i32 @dx.op.binary.i32(i32 37, i32 %3656, i32 0)  ; IMax(a,b)
  %3658 = call i32 @dx.op.binary.i32(i32 37, i32 %2906, i32 0)  ; IMax(a,b)
  %3659 = call i32 @dx.op.binary.i32(i32 38, i32 %3657, i32 %59)  ; IMin(a,b)
  %3660 = call i32 @dx.op.binary.i32(i32 38, i32 %3658, i32 %60)  ; IMin(a,b)
  %3661 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3659, i32 %3660, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3662 = extractvalue %dx.types.ResRet.f32 %3661, 0
  %3663 = extractvalue %dx.types.ResRet.f32 %3661, 1
  %3664 = extractvalue %dx.types.ResRet.f32 %3661, 2
  %3665 = extractvalue %dx.types.ResRet.f32 %3661, 3
  %3666 = fcmp fast olt float %3665, 0.000000e+00
  br i1 %3666, label %3667, label %3701

; <label>:3667                                    ; preds = %3652
  %3668 = fcmp fast ogt float %3662, 0x3FA4B5DCC0000000
  %3669 = fcmp fast ogt float %3663, 0x3FA4B5DCC0000000
  %3670 = fcmp fast ogt float %3664, 0x3FA4B5DCC0000000
  %3671 = select i1 %3668, float 0.000000e+00, float 1.000000e+00
  %3672 = select i1 %3669, float 0.000000e+00, float 1.000000e+00
  %3673 = select i1 %3670, float 0.000000e+00, float 1.000000e+00
  %3674 = fmul fast float %3662, 0x3FB3D07220000000
  %3675 = fmul fast float %3663, 0x3FB3D07220000000
  %3676 = fmul fast float %3664, 0x3FB3D07220000000
  %3677 = fadd fast float %3662, 0x3FAC28F5C0000000
  %3678 = fadd fast float %3663, 0x3FAC28F5C0000000
  %3679 = fadd fast float %3664, 0x3FAC28F5C0000000
  %3680 = fmul fast float %3677, 0x3FEE54EDE0000000
  %3681 = fmul fast float %3678, 0x3FEE54EDE0000000
  %3682 = fmul fast float %3679, 0x3FEE54EDE0000000
  %3683 = call float @dx.op.unary.f32(i32 23, float %3680)  ; Log(value)
  %3684 = call float @dx.op.unary.f32(i32 23, float %3681)  ; Log(value)
  %3685 = call float @dx.op.unary.f32(i32 23, float %3682)  ; Log(value)
  %3686 = fmul fast float %3683, 0x4003333340000000
  %3687 = fmul fast float %3684, 0x4003333340000000
  %3688 = fmul fast float %3685, 0x4003333340000000
  %3689 = call float @dx.op.unary.f32(i32 21, float %3686)  ; Exp(value)
  %3690 = call float @dx.op.unary.f32(i32 21, float %3687)  ; Exp(value)
  %3691 = call float @dx.op.unary.f32(i32 21, float %3688)  ; Exp(value)
  %3692 = fsub fast float %3674, %3689
  %3693 = fsub fast float %3675, %3690
  %3694 = fsub fast float %3676, %3691
  %3695 = fmul fast float %3692, %3671
  %3696 = fmul fast float %3693, %3672
  %3697 = fmul fast float %3694, %3673
  %3698 = fadd fast float %3695, %3689
  %3699 = fadd fast float %3696, %3690
  %3700 = fadd fast float %3697, %3691
  br label %3916

; <label>:3701                                    ; preds = %3652
  %3702 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3659, i32 %3660, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3703 = extractvalue %dx.types.ResRet.f32 %3702, 0
  %3704 = fcmp fast ogt float %38, 5.000000e-01
  %3705 = fcmp fast olt float %3703, 1.000000e+00
  %3706 = and i1 %3704, %3705
  br i1 %3706, label %3707, label %3845

; <label>:3707                                    ; preds = %3701
  %3708 = sitofp i32 %3659 to float
  %3709 = sitofp i32 %3660 to float
  %3710 = fadd fast float %3708, 5.000000e-01
  %3711 = fadd fast float %3709, 5.000000e-01
  %3712 = fdiv fast float %3710, %45
  %3713 = fdiv fast float %3711, %46
  %3714 = fmul fast float %3712, 2.000000e+00
  %3715 = fmul fast float %3713, 2.000000e+00
  %3716 = fadd fast float %3714, -1.000000e+00
  %3717 = fsub fast float 1.000000e+00, %3715
  %3718 = fmul fast float %3716, %35
  %3719 = call float @dx.op.tertiary.f32(i32 46, float %3717, float %31, float %3718)  ; FMad(a,b,c)
  %3720 = call float @dx.op.tertiary.f32(i32 46, float %3703, float %27, float %3719)  ; FMad(a,b,c)
  %3721 = fadd fast float %3720, %23
  %3722 = call float @dx.op.unary.f32(i32 6, float %3721)  ; FAbs(value)
  %3723 = fcmp fast ogt float %3722, 0x3EB0C6F7A0000000
  br i1 %3723, label %3724, label %3845

; <label>:3724                                    ; preds = %3707
  %3725 = fmul fast float %3716, %34
  %3726 = call float @dx.op.tertiary.f32(i32 46, float %3717, float %30, float %3725)  ; FMad(a,b,c)
  %3727 = call float @dx.op.tertiary.f32(i32 46, float %3703, float %26, float %3726)  ; FMad(a,b,c)
  %3728 = fadd fast float %3727, %22
  %3729 = fmul fast float %3716, %33
  %3730 = call float @dx.op.tertiary.f32(i32 46, float %3717, float %29, float %3729)  ; FMad(a,b,c)
  %3731 = call float @dx.op.tertiary.f32(i32 46, float %3703, float %25, float %3730)  ; FMad(a,b,c)
  %3732 = fadd fast float %3731, %21
  %3733 = fmul fast float %3716, %32
  %3734 = call float @dx.op.tertiary.f32(i32 46, float %3717, float %28, float %3733)  ; FMad(a,b,c)
  %3735 = call float @dx.op.tertiary.f32(i32 46, float %3703, float %24, float %3734)  ; FMad(a,b,c)
  %3736 = fadd fast float %3735, %20
  %3737 = fdiv fast float %3736, %3721
  %3738 = fdiv fast float %3732, %3721
  %3739 = fdiv fast float %3728, %3721
  %3740 = fsub fast float %3737, %17
  %3741 = fsub fast float %3738, %18
  %3742 = fsub fast float %3739, %19
  %3743 = fmul fast float %3740, %3740
  %3744 = fmul fast float %3741, %3741
  %3745 = fadd fast float %3744, %3743
  %3746 = fmul fast float %3742, %3742
  %3747 = fadd fast float %3745, %3746
  %3748 = call float @dx.op.unary.f32(i32 24, float %3747)  ; Sqrt(value)
  %3749 = fsub fast float %3748, %9
  %3750 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %3749)  ; FMax(a,b)
  %3751 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %3751, label %3752, label %3775

; <label>:3752                                    ; preds = %3724
  %3753 = call float @dx.op.unary.f32(i32 6, float %3741)  ; FAbs(value)
  %3754 = fmul fast float %3753, %11
  %3755 = fcmp fast olt float %3754, 0x3F50624DE0000000
  br i1 %3755, label %3756, label %3759

; <label>:3756                                    ; preds = %3752
  %3757 = fmul fast float %3754, 5.000000e-01
  %3758 = fsub fast float 1.000000e+00, %3757
  br label %3764

; <label>:3759                                    ; preds = %3752
  %3760 = fmul fast float %3754, 0xBFF7154760000000
  %3761 = call float @dx.op.unary.f32(i32 21, float %3760)  ; Exp(value)
  %3762 = fsub fast float 1.000000e+00, %3761
  %3763 = fdiv fast float %3762, %3754
  br label %3764

; <label>:3764                                    ; preds = %3759, %3756
  %3765 = phi float [ %3758, %3756 ], [ %3763, %3759 ]
  %3766 = call float @dx.op.binary.f32(i32 36, float %3738, float %18)  ; FMin(a,b)
  %3767 = fsub fast float %3766, %10
  %3768 = fmul fast float %11, %3767
  %3769 = fsub fast float -0.000000e+00, %3768
  %3770 = call float @dx.op.binary.f32(i32 35, float %3769, float -4.000000e+01)  ; FMax(a,b)
  %3771 = call float @dx.op.binary.f32(i32 36, float %3770, float 5.000000e+00)  ; FMin(a,b)
  %3772 = fmul fast float %3771, 0x3FF7154760000000
  %3773 = call float @dx.op.unary.f32(i32 21, float %3772)  ; Exp(value)
  %3774 = fmul fast float %3773, %3765
  br label %3775

; <label>:3775                                    ; preds = %3764, %3724
  %3776 = phi float [ %3774, %3764 ], [ 1.000000e+00, %3724 ]
  %3777 = fmul fast float %3750, %16
  %3778 = fmul fast float %3777, %3776
  %3779 = fcmp fast ole float %3748, %9
  %3780 = fcmp fast olt float %3748, 0x3F1A36E2E0000000
  %3781 = or i1 %3779, %3780
  br i1 %3781, label %3828, label %3782

; <label>:3782                                    ; preds = %3775
  %3783 = fdiv fast float %9, %3748
  %3784 = fmul fast float %3783, %3740
  %3785 = fmul fast float %3783, %3741
  %3786 = fmul fast float %3783, %3742
  %3787 = fadd fast float %3784, %17
  %3788 = fadd fast float %3785, %18
  %3789 = fadd fast float %3786, %19
  %3790 = fadd fast float %3787, -9.000000e+02
  %3791 = fadd fast float %3788, -1.500000e+01
  %3792 = fadd fast float %3789, -7.500000e+02
  %3793 = fmul fast float %3790, 0x3F62345680000000
  %3794 = fmul fast float %3791, 0x3F62345680000000
  %3795 = fmul fast float %3792, 0x3F62345680000000
  %3796 = call float @dx.op.dot3.f32(i32 55, float %3793, float %3794, float %3795, float %3793, float %3794, float %3795)  ; Dot3(ax,ay,az,bx,by,bz)
  %3797 = fsub fast float 1.000000e+00, %3796
  %3798 = call float @dx.op.unary.f32(i32 7, float %3797)  ; Saturate(value)
  %3799 = fmul fast float %3798, %3798
  %3800 = fadd fast float %3787, %3737
  %3801 = fadd fast float %3788, %3738
  %3802 = fadd fast float %3789, %3739
  %3803 = fmul fast float %3800, 0x3F52345680000000
  %3804 = fadd fast float %3803, -2.000000e+00
  %3805 = fmul fast float %3801, 0x3F52345680000000
  %3806 = fadd fast float %3805, 0xBFA1111120000000
  %3807 = fmul fast float %3802, 0x3F52345680000000
  %3808 = fadd fast float %3807, 0xBFFAAAAAC0000000
  %3809 = call float @dx.op.dot3.f32(i32 55, float %3804, float %3806, float %3808, float %3804, float %3806, float %3808)  ; Dot3(ax,ay,az,bx,by,bz)
  %3810 = fsub fast float 1.000000e+00, %3809
  %3811 = call float @dx.op.unary.f32(i32 7, float %3810)  ; Saturate(value)
  %3812 = fmul fast float %3811, %3811
  %3813 = fmul fast float %3812, 4.000000e+00
  %3814 = fadd fast float %3813, %3799
  %3815 = fadd fast float %3737, -9.000000e+02
  %3816 = fadd fast float %3738, -1.500000e+01
  %3817 = fadd fast float %3739, -7.500000e+02
  %3818 = fmul fast float %3815, 0x3F62345680000000
  %3819 = fmul fast float %3816, 0x3F62345680000000
  %3820 = fmul fast float %3817, 0x3F62345680000000
  %3821 = call float @dx.op.dot3.f32(i32 55, float %3818, float %3819, float %3820, float %3818, float %3819, float %3820)  ; Dot3(ax,ay,az,bx,by,bz)
  %3822 = fsub fast float 1.000000e+00, %3821
  %3823 = call float @dx.op.unary.f32(i32 7, float %3822)  ; Saturate(value)
  %3824 = fmul fast float %3823, %3823
  %3825 = fadd fast float %3814, %3824
  %3826 = fmul fast float %3749, 0x3F25D867E0000000
  %3827 = fmul fast float %3826, %3825
  br label %3828

; <label>:3828                                    ; preds = %3782, %3775
  %3829 = phi float [ %3827, %3782 ], [ 0.000000e+00, %3775 ]
  %3830 = fadd fast float %3829, %3778
  %3831 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %3830)  ; FMin(a,b)
  %3832 = fmul fast float %3831, 0xBFF7154760000000
  %3833 = call float @dx.op.unary.f32(i32 21, float %3832)  ; Exp(value)
  %3834 = fsub fast float 1.000000e+00, %3833
  %3835 = call float @dx.op.binary.f32(i32 36, float %12, float %3834)  ; FMin(a,b)
  %3836 = fsub fast float %13, %3662
  %3837 = fsub fast float %14, %3663
  %3838 = fsub fast float %15, %3664
  %3839 = fmul fast float %3835, %3836
  %3840 = fmul fast float %3835, %3837
  %3841 = fmul fast float %3835, %3838
  %3842 = fadd fast float %3839, %3662
  %3843 = fadd fast float %3840, %3663
  %3844 = fadd fast float %3841, %3664
  br label %3845

; <label>:3845                                    ; preds = %3828, %3707, %3701
  %3846 = phi float [ %3842, %3828 ], [ %3662, %3707 ], [ %3662, %3701 ]
  %3847 = phi float [ %3843, %3828 ], [ %3663, %3707 ], [ %3663, %3701 ]
  %3848 = phi float [ %3844, %3828 ], [ %3664, %3707 ], [ %3664, %3701 ]
  %3849 = fadd fast float %5, 1.000000e+00
  %3850 = fadd fast float %6, 1.000000e+00
  %3851 = fsub fast float 1.000000e+00, %5
  %3852 = fmul fast float %36, %3849
  %3853 = fmul fast float %36, %3850
  %3854 = fmul fast float %36, %3851
  %3855 = fmul fast float %3852, %3846
  %3856 = fmul fast float %3853, %3847
  %3857 = fmul fast float %3854, %3848
  %3858 = fcmp fast ult float %37, 5.000000e-01
  br i1 %3858, label %3884, label %3859

; <label>:3859                                    ; preds = %3845
  %3860 = fmul fast float %3855, 0x4004147AE0000000
  %3861 = fmul fast float %3856, 0x4004147AE0000000
  %3862 = fmul fast float %3857, 0x4004147AE0000000
  %3863 = fadd fast float %3860, 0x3F9EB851E0000000
  %3864 = fadd fast float %3861, 0x3F9EB851E0000000
  %3865 = fadd fast float %3862, 0x3F9EB851E0000000
  %3866 = fmul fast float %3863, %3855
  %3867 = fmul fast float %3864, %3856
  %3868 = fmul fast float %3865, %3857
  %3869 = fmul fast float %3855, 0x400370A3E0000000
  %3870 = fmul fast float %3856, 0x400370A3E0000000
  %3871 = fmul fast float %3857, 0x400370A3E0000000
  %3872 = fadd fast float %3869, 0x3FE2E147A0000000
  %3873 = fadd fast float %3870, 0x3FE2E147A0000000
  %3874 = fadd fast float %3871, 0x3FE2E147A0000000
  %3875 = fmul fast float %3872, %3855
  %3876 = fmul fast float %3873, %3856
  %3877 = fmul fast float %3874, %3857
  %3878 = fadd fast float %3875, 0x3FC1EB8520000000
  %3879 = fadd fast float %3876, 0x3FC1EB8520000000
  %3880 = fadd fast float %3877, 0x3FC1EB8520000000
  %3881 = fdiv fast float %3866, %3878
  %3882 = fdiv fast float %3867, %3879
  %3883 = fdiv fast float %3868, %3880
  br label %3884

; <label>:3884                                    ; preds = %3859, %3845
  %3885 = phi float [ %3881, %3859 ], [ %3855, %3845 ]
  %3886 = phi float [ %3882, %3859 ], [ %3856, %3845 ]
  %3887 = phi float [ %3883, %3859 ], [ %3857, %3845 ]
  %3888 = call float @dx.op.unary.f32(i32 7, float %3885)  ; Saturate(value)
  %3889 = call float @dx.op.unary.f32(i32 7, float %3886)  ; Saturate(value)
  %3890 = call float @dx.op.unary.f32(i32 7, float %3887)  ; Saturate(value)
  %3891 = call float @dx.op.dot3.f32(i32 55, float %3888, float %3889, float %3890, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %3892 = fsub fast float %3888, %3891
  %3893 = fsub fast float %3889, %3891
  %3894 = fsub fast float %3890, %3891
  %3895 = fmul fast float %3892, %8
  %3896 = fmul fast float %3893, %8
  %3897 = fmul fast float %3894, %8
  %3898 = fadd fast float %3895, %3891
  %3899 = fadd fast float %3896, %3891
  %3900 = fadd fast float %3897, %3891
  %3901 = call float @dx.op.unary.f32(i32 7, float %3898)  ; Saturate(value)
  %3902 = call float @dx.op.unary.f32(i32 7, float %3899)  ; Saturate(value)
  %3903 = call float @dx.op.unary.f32(i32 7, float %3900)  ; Saturate(value)
  %3904 = fadd fast float %3901, 0xBFC70A3D80000000
  %3905 = fadd fast float %3902, 0xBFC70A3D80000000
  %3906 = fadd fast float %3903, 0xBFC70A3D80000000
  %3907 = fmul fast float %3904, %7
  %3908 = fmul fast float %3905, %7
  %3909 = fmul fast float %3906, %7
  %3910 = fadd fast float %3907, 0x3FC70A3D80000000
  %3911 = fadd fast float %3908, 0x3FC70A3D80000000
  %3912 = fadd fast float %3909, 0x3FC70A3D80000000
  %3913 = call float @dx.op.unary.f32(i32 7, float %3910)  ; Saturate(value)
  %3914 = call float @dx.op.unary.f32(i32 7, float %3911)  ; Saturate(value)
  %3915 = call float @dx.op.unary.f32(i32 7, float %3912)  ; Saturate(value)
  br label %3916

; <label>:3916                                    ; preds = %3884, %3667
  %3917 = phi float [ %3698, %3667 ], [ %3913, %3884 ]
  %3918 = phi float [ %3699, %3667 ], [ %3914, %3884 ]
  %3919 = phi float [ %3700, %3667 ], [ %3915, %3884 ]
  %3920 = add i32 %63, 1
  %3921 = call i32 @dx.op.binary.i32(i32 37, i32 %3920, i32 0)  ; IMax(a,b)
  %3922 = call i32 @dx.op.binary.i32(i32 38, i32 %3921, i32 %59)  ; IMin(a,b)
  %3923 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %3922, i32 %3660, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3924 = extractvalue %dx.types.ResRet.f32 %3923, 0
  %3925 = extractvalue %dx.types.ResRet.f32 %3923, 1
  %3926 = extractvalue %dx.types.ResRet.f32 %3923, 2
  %3927 = extractvalue %dx.types.ResRet.f32 %3923, 3
  %3928 = fcmp fast olt float %3927, 0.000000e+00
  br i1 %3928, label %3929, label %3963

; <label>:3929                                    ; preds = %3916
  %3930 = fcmp fast ogt float %3924, 0x3FA4B5DCC0000000
  %3931 = fcmp fast ogt float %3925, 0x3FA4B5DCC0000000
  %3932 = fcmp fast ogt float %3926, 0x3FA4B5DCC0000000
  %3933 = select i1 %3930, float 0.000000e+00, float 1.000000e+00
  %3934 = select i1 %3931, float 0.000000e+00, float 1.000000e+00
  %3935 = select i1 %3932, float 0.000000e+00, float 1.000000e+00
  %3936 = fmul fast float %3924, 0x3FB3D07220000000
  %3937 = fmul fast float %3925, 0x3FB3D07220000000
  %3938 = fmul fast float %3926, 0x3FB3D07220000000
  %3939 = fadd fast float %3924, 0x3FAC28F5C0000000
  %3940 = fadd fast float %3925, 0x3FAC28F5C0000000
  %3941 = fadd fast float %3926, 0x3FAC28F5C0000000
  %3942 = fmul fast float %3939, 0x3FEE54EDE0000000
  %3943 = fmul fast float %3940, 0x3FEE54EDE0000000
  %3944 = fmul fast float %3941, 0x3FEE54EDE0000000
  %3945 = call float @dx.op.unary.f32(i32 23, float %3942)  ; Log(value)
  %3946 = call float @dx.op.unary.f32(i32 23, float %3943)  ; Log(value)
  %3947 = call float @dx.op.unary.f32(i32 23, float %3944)  ; Log(value)
  %3948 = fmul fast float %3945, 0x4003333340000000
  %3949 = fmul fast float %3946, 0x4003333340000000
  %3950 = fmul fast float %3947, 0x4003333340000000
  %3951 = call float @dx.op.unary.f32(i32 21, float %3948)  ; Exp(value)
  %3952 = call float @dx.op.unary.f32(i32 21, float %3949)  ; Exp(value)
  %3953 = call float @dx.op.unary.f32(i32 21, float %3950)  ; Exp(value)
  %3954 = fsub fast float %3936, %3951
  %3955 = fsub fast float %3937, %3952
  %3956 = fsub fast float %3938, %3953
  %3957 = fmul fast float %3954, %3933
  %3958 = fmul fast float %3955, %3934
  %3959 = fmul fast float %3956, %3935
  %3960 = fadd fast float %3957, %3951
  %3961 = fadd fast float %3958, %3952
  %3962 = fadd fast float %3959, %3953
  br label %4178

; <label>:3963                                    ; preds = %3916
  %3964 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %3922, i32 %3660, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %3965 = extractvalue %dx.types.ResRet.f32 %3964, 0
  %3966 = fcmp fast ogt float %38, 5.000000e-01
  %3967 = fcmp fast olt float %3965, 1.000000e+00
  %3968 = and i1 %3966, %3967
  br i1 %3968, label %3969, label %4107

; <label>:3969                                    ; preds = %3963
  %3970 = sitofp i32 %3922 to float
  %3971 = sitofp i32 %3660 to float
  %3972 = fadd fast float %3970, 5.000000e-01
  %3973 = fadd fast float %3971, 5.000000e-01
  %3974 = fdiv fast float %3972, %45
  %3975 = fdiv fast float %3973, %46
  %3976 = fmul fast float %3974, 2.000000e+00
  %3977 = fmul fast float %3975, 2.000000e+00
  %3978 = fadd fast float %3976, -1.000000e+00
  %3979 = fsub fast float 1.000000e+00, %3977
  %3980 = fmul fast float %3978, %35
  %3981 = call float @dx.op.tertiary.f32(i32 46, float %3979, float %31, float %3980)  ; FMad(a,b,c)
  %3982 = call float @dx.op.tertiary.f32(i32 46, float %3965, float %27, float %3981)  ; FMad(a,b,c)
  %3983 = fadd fast float %3982, %23
  %3984 = call float @dx.op.unary.f32(i32 6, float %3983)  ; FAbs(value)
  %3985 = fcmp fast ogt float %3984, 0x3EB0C6F7A0000000
  br i1 %3985, label %3986, label %4107

; <label>:3986                                    ; preds = %3969
  %3987 = fmul fast float %3978, %34
  %3988 = call float @dx.op.tertiary.f32(i32 46, float %3979, float %30, float %3987)  ; FMad(a,b,c)
  %3989 = call float @dx.op.tertiary.f32(i32 46, float %3965, float %26, float %3988)  ; FMad(a,b,c)
  %3990 = fadd fast float %3989, %22
  %3991 = fmul fast float %3978, %33
  %3992 = call float @dx.op.tertiary.f32(i32 46, float %3979, float %29, float %3991)  ; FMad(a,b,c)
  %3993 = call float @dx.op.tertiary.f32(i32 46, float %3965, float %25, float %3992)  ; FMad(a,b,c)
  %3994 = fadd fast float %3993, %21
  %3995 = fmul fast float %3978, %32
  %3996 = call float @dx.op.tertiary.f32(i32 46, float %3979, float %28, float %3995)  ; FMad(a,b,c)
  %3997 = call float @dx.op.tertiary.f32(i32 46, float %3965, float %24, float %3996)  ; FMad(a,b,c)
  %3998 = fadd fast float %3997, %20
  %3999 = fdiv fast float %3998, %3983
  %4000 = fdiv fast float %3994, %3983
  %4001 = fdiv fast float %3990, %3983
  %4002 = fsub fast float %3999, %17
  %4003 = fsub fast float %4000, %18
  %4004 = fsub fast float %4001, %19
  %4005 = fmul fast float %4002, %4002
  %4006 = fmul fast float %4003, %4003
  %4007 = fadd fast float %4006, %4005
  %4008 = fmul fast float %4004, %4004
  %4009 = fadd fast float %4007, %4008
  %4010 = call float @dx.op.unary.f32(i32 24, float %4009)  ; Sqrt(value)
  %4011 = fsub fast float %4010, %9
  %4012 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4011)  ; FMax(a,b)
  %4013 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %4013, label %4014, label %4037

; <label>:4014                                    ; preds = %3986
  %4015 = call float @dx.op.unary.f32(i32 6, float %4003)  ; FAbs(value)
  %4016 = fmul fast float %4015, %11
  %4017 = fcmp fast olt float %4016, 0x3F50624DE0000000
  br i1 %4017, label %4018, label %4021

; <label>:4018                                    ; preds = %4014
  %4019 = fmul fast float %4016, 5.000000e-01
  %4020 = fsub fast float 1.000000e+00, %4019
  br label %4026

; <label>:4021                                    ; preds = %4014
  %4022 = fmul fast float %4016, 0xBFF7154760000000
  %4023 = call float @dx.op.unary.f32(i32 21, float %4022)  ; Exp(value)
  %4024 = fsub fast float 1.000000e+00, %4023
  %4025 = fdiv fast float %4024, %4016
  br label %4026

; <label>:4026                                    ; preds = %4021, %4018
  %4027 = phi float [ %4020, %4018 ], [ %4025, %4021 ]
  %4028 = call float @dx.op.binary.f32(i32 36, float %4000, float %18)  ; FMin(a,b)
  %4029 = fsub fast float %4028, %10
  %4030 = fmul fast float %11, %4029
  %4031 = fsub fast float -0.000000e+00, %4030
  %4032 = call float @dx.op.binary.f32(i32 35, float %4031, float -4.000000e+01)  ; FMax(a,b)
  %4033 = call float @dx.op.binary.f32(i32 36, float %4032, float 5.000000e+00)  ; FMin(a,b)
  %4034 = fmul fast float %4033, 0x3FF7154760000000
  %4035 = call float @dx.op.unary.f32(i32 21, float %4034)  ; Exp(value)
  %4036 = fmul fast float %4035, %4027
  br label %4037

; <label>:4037                                    ; preds = %4026, %3986
  %4038 = phi float [ %4036, %4026 ], [ 1.000000e+00, %3986 ]
  %4039 = fmul fast float %4012, %16
  %4040 = fmul fast float %4039, %4038
  %4041 = fcmp fast ole float %4010, %9
  %4042 = fcmp fast olt float %4010, 0x3F1A36E2E0000000
  %4043 = or i1 %4041, %4042
  br i1 %4043, label %4090, label %4044

; <label>:4044                                    ; preds = %4037
  %4045 = fdiv fast float %9, %4010
  %4046 = fmul fast float %4045, %4002
  %4047 = fmul fast float %4045, %4003
  %4048 = fmul fast float %4045, %4004
  %4049 = fadd fast float %4046, %17
  %4050 = fadd fast float %4047, %18
  %4051 = fadd fast float %4048, %19
  %4052 = fadd fast float %4049, -9.000000e+02
  %4053 = fadd fast float %4050, -1.500000e+01
  %4054 = fadd fast float %4051, -7.500000e+02
  %4055 = fmul fast float %4052, 0x3F62345680000000
  %4056 = fmul fast float %4053, 0x3F62345680000000
  %4057 = fmul fast float %4054, 0x3F62345680000000
  %4058 = call float @dx.op.dot3.f32(i32 55, float %4055, float %4056, float %4057, float %4055, float %4056, float %4057)  ; Dot3(ax,ay,az,bx,by,bz)
  %4059 = fsub fast float 1.000000e+00, %4058
  %4060 = call float @dx.op.unary.f32(i32 7, float %4059)  ; Saturate(value)
  %4061 = fmul fast float %4060, %4060
  %4062 = fadd fast float %4049, %3999
  %4063 = fadd fast float %4050, %4000
  %4064 = fadd fast float %4051, %4001
  %4065 = fmul fast float %4062, 0x3F52345680000000
  %4066 = fadd fast float %4065, -2.000000e+00
  %4067 = fmul fast float %4063, 0x3F52345680000000
  %4068 = fadd fast float %4067, 0xBFA1111120000000
  %4069 = fmul fast float %4064, 0x3F52345680000000
  %4070 = fadd fast float %4069, 0xBFFAAAAAC0000000
  %4071 = call float @dx.op.dot3.f32(i32 55, float %4066, float %4068, float %4070, float %4066, float %4068, float %4070)  ; Dot3(ax,ay,az,bx,by,bz)
  %4072 = fsub fast float 1.000000e+00, %4071
  %4073 = call float @dx.op.unary.f32(i32 7, float %4072)  ; Saturate(value)
  %4074 = fmul fast float %4073, %4073
  %4075 = fmul fast float %4074, 4.000000e+00
  %4076 = fadd fast float %4075, %4061
  %4077 = fadd fast float %3999, -9.000000e+02
  %4078 = fadd fast float %4000, -1.500000e+01
  %4079 = fadd fast float %4001, -7.500000e+02
  %4080 = fmul fast float %4077, 0x3F62345680000000
  %4081 = fmul fast float %4078, 0x3F62345680000000
  %4082 = fmul fast float %4079, 0x3F62345680000000
  %4083 = call float @dx.op.dot3.f32(i32 55, float %4080, float %4081, float %4082, float %4080, float %4081, float %4082)  ; Dot3(ax,ay,az,bx,by,bz)
  %4084 = fsub fast float 1.000000e+00, %4083
  %4085 = call float @dx.op.unary.f32(i32 7, float %4084)  ; Saturate(value)
  %4086 = fmul fast float %4085, %4085
  %4087 = fadd fast float %4076, %4086
  %4088 = fmul fast float %4011, 0x3F25D867E0000000
  %4089 = fmul fast float %4088, %4087
  br label %4090

; <label>:4090                                    ; preds = %4044, %4037
  %4091 = phi float [ %4089, %4044 ], [ 0.000000e+00, %4037 ]
  %4092 = fadd fast float %4091, %4040
  %4093 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4092)  ; FMin(a,b)
  %4094 = fmul fast float %4093, 0xBFF7154760000000
  %4095 = call float @dx.op.unary.f32(i32 21, float %4094)  ; Exp(value)
  %4096 = fsub fast float 1.000000e+00, %4095
  %4097 = call float @dx.op.binary.f32(i32 36, float %12, float %4096)  ; FMin(a,b)
  %4098 = fsub fast float %13, %3924
  %4099 = fsub fast float %14, %3925
  %4100 = fsub fast float %15, %3926
  %4101 = fmul fast float %4097, %4098
  %4102 = fmul fast float %4097, %4099
  %4103 = fmul fast float %4097, %4100
  %4104 = fadd fast float %4101, %3924
  %4105 = fadd fast float %4102, %3925
  %4106 = fadd fast float %4103, %3926
  br label %4107

; <label>:4107                                    ; preds = %4090, %3969, %3963
  %4108 = phi float [ %4104, %4090 ], [ %3924, %3969 ], [ %3924, %3963 ]
  %4109 = phi float [ %4105, %4090 ], [ %3925, %3969 ], [ %3925, %3963 ]
  %4110 = phi float [ %4106, %4090 ], [ %3926, %3969 ], [ %3926, %3963 ]
  %4111 = fadd fast float %5, 1.000000e+00
  %4112 = fadd fast float %6, 1.000000e+00
  %4113 = fsub fast float 1.000000e+00, %5
  %4114 = fmul fast float %36, %4111
  %4115 = fmul fast float %36, %4112
  %4116 = fmul fast float %36, %4113
  %4117 = fmul fast float %4114, %4108
  %4118 = fmul fast float %4115, %4109
  %4119 = fmul fast float %4116, %4110
  %4120 = fcmp fast ult float %37, 5.000000e-01
  br i1 %4120, label %4146, label %4121

; <label>:4121                                    ; preds = %4107
  %4122 = fmul fast float %4117, 0x4004147AE0000000
  %4123 = fmul fast float %4118, 0x4004147AE0000000
  %4124 = fmul fast float %4119, 0x4004147AE0000000
  %4125 = fadd fast float %4122, 0x3F9EB851E0000000
  %4126 = fadd fast float %4123, 0x3F9EB851E0000000
  %4127 = fadd fast float %4124, 0x3F9EB851E0000000
  %4128 = fmul fast float %4125, %4117
  %4129 = fmul fast float %4126, %4118
  %4130 = fmul fast float %4127, %4119
  %4131 = fmul fast float %4117, 0x400370A3E0000000
  %4132 = fmul fast float %4118, 0x400370A3E0000000
  %4133 = fmul fast float %4119, 0x400370A3E0000000
  %4134 = fadd fast float %4131, 0x3FE2E147A0000000
  %4135 = fadd fast float %4132, 0x3FE2E147A0000000
  %4136 = fadd fast float %4133, 0x3FE2E147A0000000
  %4137 = fmul fast float %4134, %4117
  %4138 = fmul fast float %4135, %4118
  %4139 = fmul fast float %4136, %4119
  %4140 = fadd fast float %4137, 0x3FC1EB8520000000
  %4141 = fadd fast float %4138, 0x3FC1EB8520000000
  %4142 = fadd fast float %4139, 0x3FC1EB8520000000
  %4143 = fdiv fast float %4128, %4140
  %4144 = fdiv fast float %4129, %4141
  %4145 = fdiv fast float %4130, %4142
  br label %4146

; <label>:4146                                    ; preds = %4121, %4107
  %4147 = phi float [ %4143, %4121 ], [ %4117, %4107 ]
  %4148 = phi float [ %4144, %4121 ], [ %4118, %4107 ]
  %4149 = phi float [ %4145, %4121 ], [ %4119, %4107 ]
  %4150 = call float @dx.op.unary.f32(i32 7, float %4147)  ; Saturate(value)
  %4151 = call float @dx.op.unary.f32(i32 7, float %4148)  ; Saturate(value)
  %4152 = call float @dx.op.unary.f32(i32 7, float %4149)  ; Saturate(value)
  %4153 = call float @dx.op.dot3.f32(i32 55, float %4150, float %4151, float %4152, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4154 = fsub fast float %4150, %4153
  %4155 = fsub fast float %4151, %4153
  %4156 = fsub fast float %4152, %4153
  %4157 = fmul fast float %4154, %8
  %4158 = fmul fast float %4155, %8
  %4159 = fmul fast float %4156, %8
  %4160 = fadd fast float %4157, %4153
  %4161 = fadd fast float %4158, %4153
  %4162 = fadd fast float %4159, %4153
  %4163 = call float @dx.op.unary.f32(i32 7, float %4160)  ; Saturate(value)
  %4164 = call float @dx.op.unary.f32(i32 7, float %4161)  ; Saturate(value)
  %4165 = call float @dx.op.unary.f32(i32 7, float %4162)  ; Saturate(value)
  %4166 = fadd fast float %4163, 0xBFC70A3D80000000
  %4167 = fadd fast float %4164, 0xBFC70A3D80000000
  %4168 = fadd fast float %4165, 0xBFC70A3D80000000
  %4169 = fmul fast float %4166, %7
  %4170 = fmul fast float %4167, %7
  %4171 = fmul fast float %4168, %7
  %4172 = fadd fast float %4169, 0x3FC70A3D80000000
  %4173 = fadd fast float %4170, 0x3FC70A3D80000000
  %4174 = fadd fast float %4171, 0x3FC70A3D80000000
  %4175 = call float @dx.op.unary.f32(i32 7, float %4172)  ; Saturate(value)
  %4176 = call float @dx.op.unary.f32(i32 7, float %4173)  ; Saturate(value)
  %4177 = call float @dx.op.unary.f32(i32 7, float %4174)  ; Saturate(value)
  br label %4178

; <label>:4178                                    ; preds = %4146, %3929
  %4179 = phi float [ %3960, %3929 ], [ %4175, %4146 ]
  %4180 = phi float [ %3961, %3929 ], [ %4176, %4146 ]
  %4181 = phi float [ %3962, %3929 ], [ %4177, %4146 ]
  %4182 = call float @dx.op.binary.f32(i32 36, float %3917, float %4179)  ; FMin(a,b)
  %4183 = call float @dx.op.binary.f32(i32 36, float %3918, float %4180)  ; FMin(a,b)
  %4184 = call float @dx.op.binary.f32(i32 36, float %3919, float %4181)  ; FMin(a,b)
  %4185 = call float @dx.op.binary.f32(i32 36, float %3391, float %3653)  ; FMin(a,b)
  %4186 = call float @dx.op.binary.f32(i32 36, float %3392, float %3654)  ; FMin(a,b)
  %4187 = call float @dx.op.binary.f32(i32 36, float %3393, float %3655)  ; FMin(a,b)
  %4188 = call float @dx.op.binary.f32(i32 36, float %4185, float %4182)  ; FMin(a,b)
  %4189 = call float @dx.op.binary.f32(i32 36, float %4186, float %4183)  ; FMin(a,b)
  %4190 = call float @dx.op.binary.f32(i32 36, float %4187, float %4184)  ; FMin(a,b)
  %4191 = call float @dx.op.binary.f32(i32 36, float %3127, float %4188)  ; FMin(a,b)
  %4192 = call float @dx.op.binary.f32(i32 36, float %3128, float %4189)  ; FMin(a,b)
  %4193 = call float @dx.op.binary.f32(i32 36, float %3129, float %4190)  ; FMin(a,b)
  %4194 = call float @dx.op.binary.f32(i32 35, float %3917, float %4179)  ; FMax(a,b)
  %4195 = call float @dx.op.binary.f32(i32 35, float %3918, float %4180)  ; FMax(a,b)
  %4196 = call float @dx.op.binary.f32(i32 35, float %3919, float %4181)  ; FMax(a,b)
  %4197 = call float @dx.op.binary.f32(i32 35, float %3391, float %3653)  ; FMax(a,b)
  %4198 = call float @dx.op.binary.f32(i32 35, float %3392, float %3654)  ; FMax(a,b)
  %4199 = call float @dx.op.binary.f32(i32 35, float %3393, float %3655)  ; FMax(a,b)
  %4200 = call float @dx.op.binary.f32(i32 35, float %4197, float %4194)  ; FMax(a,b)
  %4201 = call float @dx.op.binary.f32(i32 35, float %4198, float %4195)  ; FMax(a,b)
  %4202 = call float @dx.op.binary.f32(i32 35, float %4199, float %4196)  ; FMax(a,b)
  %4203 = call float @dx.op.binary.f32(i32 35, float %3127, float %4200)  ; FMax(a,b)
  %4204 = call float @dx.op.binary.f32(i32 35, float %3128, float %4201)  ; FMax(a,b)
  %4205 = call float @dx.op.binary.f32(i32 35, float %3129, float %4202)  ; FMax(a,b)
  %4206 = fsub fast float %4203, %4191
  %4207 = fsub fast float %4204, %4192
  %4208 = fsub fast float %4205, %4193
  %4209 = call float @dx.op.unary.f32(i32 6, float %4206)  ; FAbs(value)
  %4210 = call float @dx.op.unary.f32(i32 6, float %4207)  ; FAbs(value)
  %4211 = call float @dx.op.unary.f32(i32 6, float %4208)  ; FAbs(value)
  %4212 = call float @dx.op.binary.f32(i32 35, float %4210, float %4211)  ; FMax(a,b)
  %4213 = call float @dx.op.binary.f32(i32 35, float %4209, float %4212)  ; FMax(a,b)
  %4214 = call float @dx.op.binary.f32(i32 35, float %4204, float %4205)  ; FMax(a,b)
  %4215 = call float @dx.op.binary.f32(i32 35, float %4203, float %4214)  ; FMax(a,b)
  %4216 = fmul fast float %4215, 1.250000e-01
  %4217 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %4216)  ; FMax(a,b)
  %4218 = fcmp fast ogt float %4213, %4217
  br i1 %4218, label %4219, label %4280

; <label>:4219                                    ; preds = %4178
  %4220 = fsub fast float %3391, %3653
  %4221 = fsub fast float %3392, %3654
  %4222 = fsub fast float %3393, %3655
  %4223 = call float @dx.op.unary.f32(i32 6, float %4220)  ; FAbs(value)
  %4224 = call float @dx.op.unary.f32(i32 6, float %4221)  ; FAbs(value)
  %4225 = call float @dx.op.unary.f32(i32 6, float %4222)  ; FAbs(value)
  %4226 = call float @dx.op.binary.f32(i32 35, float %4224, float %4225)  ; FMax(a,b)
  %4227 = call float @dx.op.binary.f32(i32 35, float %4223, float %4226)  ; FMax(a,b)
  %4228 = fsub fast float %3917, %4179
  %4229 = fsub fast float %3918, %4180
  %4230 = fsub fast float %3919, %4181
  %4231 = call float @dx.op.unary.f32(i32 6, float %4228)  ; FAbs(value)
  %4232 = call float @dx.op.unary.f32(i32 6, float %4229)  ; FAbs(value)
  %4233 = call float @dx.op.unary.f32(i32 6, float %4230)  ; FAbs(value)
  %4234 = call float @dx.op.binary.f32(i32 35, float %4232, float %4233)  ; FMax(a,b)
  %4235 = call float @dx.op.binary.f32(i32 35, float %4231, float %4234)  ; FMax(a,b)
  %4236 = fcmp fast olt float %4227, %4235
  %4237 = select i1 %4236, float %3391, float %3917
  %4238 = select i1 %4236, float %3392, float %3918
  %4239 = select i1 %4236, float %3393, float %3919
  %4240 = select i1 %4236, float %3653, float %4179
  %4241 = select i1 %4236, float %3654, float %4180
  %4242 = select i1 %4236, float %3655, float %4181
  %4243 = fsub fast float %3127, %4240
  %4244 = fsub fast float %3128, %4241
  %4245 = fsub fast float %3129, %4242
  %4246 = fsub fast float %3127, %4237
  %4247 = fsub fast float %3128, %4238
  %4248 = fsub fast float %3129, %4239
  %4249 = call float @dx.op.dot3.f32(i32 55, float %4246, float %4247, float %4248, float %4243, float %4244, float %4245)  ; Dot3(ax,ay,az,bx,by,bz)
  %4250 = fcmp fast ogt float %4249, 0.000000e+00
  br i1 %4250, label %4251, label %4262

; <label>:4251                                    ; preds = %4219
  %4252 = fsub fast float %4237, %4240
  %4253 = fsub fast float %4238, %4241
  %4254 = fsub fast float %4239, %4242
  %4255 = call float @dx.op.unary.f32(i32 6, float %4252)  ; FAbs(value)
  %4256 = call float @dx.op.unary.f32(i32 6, float %4253)  ; FAbs(value)
  %4257 = call float @dx.op.unary.f32(i32 6, float %4254)  ; FAbs(value)
  %4258 = call float @dx.op.binary.f32(i32 35, float %4256, float %4257)  ; FMax(a,b)
  %4259 = call float @dx.op.binary.f32(i32 35, float %4255, float %4258)  ; FMax(a,b)
  %4260 = fmul fast float %4213, 2.500000e-01
  %4261 = fcmp fast olt float %4259, %4260
  br label %4262

; <label>:4262                                    ; preds = %4251, %4219
  %4263 = phi i1 [ false, %4219 ], [ %4261, %4251 ]
  %4264 = select i1 %4263, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  %4265 = fadd fast float %4237, %4240
  %4266 = fadd fast float %4238, %4241
  %4267 = fadd fast float %4239, %4242
  %4268 = fmul fast float %4265, 5.000000e-01
  %4269 = fmul fast float %4266, 5.000000e-01
  %4270 = fmul fast float %4267, 5.000000e-01
  %4271 = fsub fast float %4268, %3127
  %4272 = fsub fast float %4269, %3128
  %4273 = fsub fast float %4270, %3129
  %4274 = fmul fast float %4264, %4271
  %4275 = fmul fast float %4264, %4272
  %4276 = fmul fast float %4264, %4273
  %4277 = fadd fast float %4274, %3127
  %4278 = fadd fast float %4275, %3128
  %4279 = fadd fast float %4276, %3129
  br label %4280

; <label>:4280                                    ; preds = %4262, %4178
  %4281 = phi float [ %4277, %4262 ], [ %3127, %4178 ]
  %4282 = phi float [ %4278, %4262 ], [ %3128, %4178 ]
  %4283 = phi float [ %4279, %4262 ], [ %3129, %4178 ]
  %4284 = fcmp fast ogt float %4281, 0x3F69A5C380000000
  %4285 = fcmp fast ogt float %4282, 0x3F69A5C380000000
  %4286 = fcmp fast ogt float %4283, 0x3F69A5C380000000
  %4287 = select i1 %4284, float 0.000000e+00, float 1.000000e+00
  %4288 = select i1 %4285, float 0.000000e+00, float 1.000000e+00
  %4289 = select i1 %4286, float 0.000000e+00, float 1.000000e+00
  %4290 = fmul fast float %4281, 0x4029D70A40000000
  %4291 = fmul fast float %4282, 0x4029D70A40000000
  %4292 = fmul fast float %4283, 0x4029D70A40000000
  %4293 = call float @dx.op.binary.f32(i32 35, float %4281, float 0.000000e+00)  ; FMax(a,b)
  %4294 = call float @dx.op.binary.f32(i32 35, float %4282, float 0.000000e+00)  ; FMax(a,b)
  %4295 = call float @dx.op.binary.f32(i32 35, float %4283, float 0.000000e+00)  ; FMax(a,b)
  %4296 = call float @dx.op.unary.f32(i32 23, float %4293)  ; Log(value)
  %4297 = call float @dx.op.unary.f32(i32 23, float %4294)  ; Log(value)
  %4298 = call float @dx.op.unary.f32(i32 23, float %4295)  ; Log(value)
  %4299 = fmul fast float %4296, 0x3FDAAAAAA0000000
  %4300 = fmul fast float %4297, 0x3FDAAAAAA0000000
  %4301 = fmul fast float %4298, 0x3FDAAAAAA0000000
  %4302 = call float @dx.op.unary.f32(i32 21, float %4299)  ; Exp(value)
  %4303 = call float @dx.op.unary.f32(i32 21, float %4300)  ; Exp(value)
  %4304 = call float @dx.op.unary.f32(i32 21, float %4301)  ; Exp(value)
  %4305 = fmul fast float %4302, 0x3FF0E147A0000000
  %4306 = fmul fast float %4303, 0x3FF0E147A0000000
  %4307 = fmul fast float %4304, 0x3FF0E147A0000000
  %4308 = fadd fast float %4305, 0xBFAC28F5C0000000
  %4309 = fadd fast float %4306, 0xBFAC28F5C0000000
  %4310 = fadd fast float %4307, 0xBFAC28F5C0000000
  %4311 = fsub fast float %4290, %4308
  %4312 = fsub fast float %4291, %4309
  %4313 = fsub fast float %4292, %4310
  %4314 = fmul fast float %4311, %4287
  %4315 = fmul fast float %4312, %4288
  %4316 = fmul fast float %4313, %4289
  %4317 = fadd fast float %4314, %4308
  %4318 = fadd fast float %4315, %4309
  %4319 = fadd fast float %4316, %4310
  br label %4320

; <label>:4320                                    ; preds = %4280, %2913
  %4321 = phi float [ %2908, %2913 ], [ %4317, %4280 ]
  %4322 = phi float [ %2909, %2913 ], [ %4318, %4280 ]
  %4323 = phi float [ %2910, %2913 ], [ %4319, %4280 ]
  %4324 = phi float [ %2914, %2913 ], [ %2911, %4280 ]
  %4325 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %1485, i32 %2906, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4326 = extractvalue %dx.types.ResRet.f32 %4325, 0
  %4327 = extractvalue %dx.types.ResRet.f32 %4325, 1
  %4328 = extractvalue %dx.types.ResRet.f32 %4325, 2
  %4329 = extractvalue %dx.types.ResRet.f32 %4325, 3
  %4330 = fcmp fast olt float %4329, 0.000000e+00
  br i1 %4330, label %4331, label %4333

; <label>:4331                                    ; preds = %4320
  %4332 = fsub fast float -1.000000e+00, %4329
  br label %5738

; <label>:4333                                    ; preds = %4320
  %4334 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1485, i32 %2906, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4335 = extractvalue %dx.types.ResRet.f32 %4334, 0
  %4336 = fcmp fast ogt float %38, 5.000000e-01
  %4337 = fcmp fast olt float %4335, 1.000000e+00
  %4338 = and i1 %4336, %4337
  br i1 %4338, label %4339, label %4477

; <label>:4339                                    ; preds = %4333
  %4340 = sitofp i32 %1485 to float
  %4341 = sitofp i32 %2906 to float
  %4342 = fadd fast float %4340, 5.000000e-01
  %4343 = fadd fast float %4341, 5.000000e-01
  %4344 = fdiv fast float %4342, %45
  %4345 = fdiv fast float %4343, %46
  %4346 = fmul fast float %4344, 2.000000e+00
  %4347 = fmul fast float %4345, 2.000000e+00
  %4348 = fadd fast float %4346, -1.000000e+00
  %4349 = fsub fast float 1.000000e+00, %4347
  %4350 = fmul fast float %4348, %35
  %4351 = call float @dx.op.tertiary.f32(i32 46, float %4349, float %31, float %4350)  ; FMad(a,b,c)
  %4352 = call float @dx.op.tertiary.f32(i32 46, float %4335, float %27, float %4351)  ; FMad(a,b,c)
  %4353 = fadd fast float %4352, %23
  %4354 = call float @dx.op.unary.f32(i32 6, float %4353)  ; FAbs(value)
  %4355 = fcmp fast ogt float %4354, 0x3EB0C6F7A0000000
  br i1 %4355, label %4356, label %4477

; <label>:4356                                    ; preds = %4339
  %4357 = fmul fast float %4348, %34
  %4358 = call float @dx.op.tertiary.f32(i32 46, float %4349, float %30, float %4357)  ; FMad(a,b,c)
  %4359 = call float @dx.op.tertiary.f32(i32 46, float %4335, float %26, float %4358)  ; FMad(a,b,c)
  %4360 = fadd fast float %4359, %22
  %4361 = fmul fast float %4348, %33
  %4362 = call float @dx.op.tertiary.f32(i32 46, float %4349, float %29, float %4361)  ; FMad(a,b,c)
  %4363 = call float @dx.op.tertiary.f32(i32 46, float %4335, float %25, float %4362)  ; FMad(a,b,c)
  %4364 = fadd fast float %4363, %21
  %4365 = fmul fast float %4348, %32
  %4366 = call float @dx.op.tertiary.f32(i32 46, float %4349, float %28, float %4365)  ; FMad(a,b,c)
  %4367 = call float @dx.op.tertiary.f32(i32 46, float %4335, float %24, float %4366)  ; FMad(a,b,c)
  %4368 = fadd fast float %4367, %20
  %4369 = fdiv fast float %4368, %4353
  %4370 = fdiv fast float %4364, %4353
  %4371 = fdiv fast float %4360, %4353
  %4372 = fsub fast float %4369, %17
  %4373 = fsub fast float %4370, %18
  %4374 = fsub fast float %4371, %19
  %4375 = fmul fast float %4372, %4372
  %4376 = fmul fast float %4373, %4373
  %4377 = fadd fast float %4376, %4375
  %4378 = fmul fast float %4374, %4374
  %4379 = fadd fast float %4377, %4378
  %4380 = call float @dx.op.unary.f32(i32 24, float %4379)  ; Sqrt(value)
  %4381 = fsub fast float %4380, %9
  %4382 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4381)  ; FMax(a,b)
  %4383 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %4383, label %4384, label %4407

; <label>:4384                                    ; preds = %4356
  %4385 = call float @dx.op.unary.f32(i32 6, float %4373)  ; FAbs(value)
  %4386 = fmul fast float %4385, %11
  %4387 = fcmp fast olt float %4386, 0x3F50624DE0000000
  br i1 %4387, label %4388, label %4391

; <label>:4388                                    ; preds = %4384
  %4389 = fmul fast float %4386, 5.000000e-01
  %4390 = fsub fast float 1.000000e+00, %4389
  br label %4396

; <label>:4391                                    ; preds = %4384
  %4392 = fmul fast float %4386, 0xBFF7154760000000
  %4393 = call float @dx.op.unary.f32(i32 21, float %4392)  ; Exp(value)
  %4394 = fsub fast float 1.000000e+00, %4393
  %4395 = fdiv fast float %4394, %4386
  br label %4396

; <label>:4396                                    ; preds = %4391, %4388
  %4397 = phi float [ %4390, %4388 ], [ %4395, %4391 ]
  %4398 = call float @dx.op.binary.f32(i32 36, float %4370, float %18)  ; FMin(a,b)
  %4399 = fsub fast float %4398, %10
  %4400 = fmul fast float %11, %4399
  %4401 = fsub fast float -0.000000e+00, %4400
  %4402 = call float @dx.op.binary.f32(i32 35, float %4401, float -4.000000e+01)  ; FMax(a,b)
  %4403 = call float @dx.op.binary.f32(i32 36, float %4402, float 5.000000e+00)  ; FMin(a,b)
  %4404 = fmul fast float %4403, 0x3FF7154760000000
  %4405 = call float @dx.op.unary.f32(i32 21, float %4404)  ; Exp(value)
  %4406 = fmul fast float %4405, %4397
  br label %4407

; <label>:4407                                    ; preds = %4396, %4356
  %4408 = phi float [ %4406, %4396 ], [ 1.000000e+00, %4356 ]
  %4409 = fmul fast float %4382, %16
  %4410 = fmul fast float %4409, %4408
  %4411 = fcmp fast ole float %4380, %9
  %4412 = fcmp fast olt float %4380, 0x3F1A36E2E0000000
  %4413 = or i1 %4411, %4412
  br i1 %4413, label %4460, label %4414

; <label>:4414                                    ; preds = %4407
  %4415 = fdiv fast float %9, %4380
  %4416 = fmul fast float %4415, %4372
  %4417 = fmul fast float %4415, %4373
  %4418 = fmul fast float %4415, %4374
  %4419 = fadd fast float %4416, %17
  %4420 = fadd fast float %4417, %18
  %4421 = fadd fast float %4418, %19
  %4422 = fadd fast float %4419, -9.000000e+02
  %4423 = fadd fast float %4420, -1.500000e+01
  %4424 = fadd fast float %4421, -7.500000e+02
  %4425 = fmul fast float %4422, 0x3F62345680000000
  %4426 = fmul fast float %4423, 0x3F62345680000000
  %4427 = fmul fast float %4424, 0x3F62345680000000
  %4428 = call float @dx.op.dot3.f32(i32 55, float %4425, float %4426, float %4427, float %4425, float %4426, float %4427)  ; Dot3(ax,ay,az,bx,by,bz)
  %4429 = fsub fast float 1.000000e+00, %4428
  %4430 = call float @dx.op.unary.f32(i32 7, float %4429)  ; Saturate(value)
  %4431 = fmul fast float %4430, %4430
  %4432 = fadd fast float %4419, %4369
  %4433 = fadd fast float %4420, %4370
  %4434 = fadd fast float %4421, %4371
  %4435 = fmul fast float %4432, 0x3F52345680000000
  %4436 = fadd fast float %4435, -2.000000e+00
  %4437 = fmul fast float %4433, 0x3F52345680000000
  %4438 = fadd fast float %4437, 0xBFA1111120000000
  %4439 = fmul fast float %4434, 0x3F52345680000000
  %4440 = fadd fast float %4439, 0xBFFAAAAAC0000000
  %4441 = call float @dx.op.dot3.f32(i32 55, float %4436, float %4438, float %4440, float %4436, float %4438, float %4440)  ; Dot3(ax,ay,az,bx,by,bz)
  %4442 = fsub fast float 1.000000e+00, %4441
  %4443 = call float @dx.op.unary.f32(i32 7, float %4442)  ; Saturate(value)
  %4444 = fmul fast float %4443, %4443
  %4445 = fmul fast float %4444, 4.000000e+00
  %4446 = fadd fast float %4445, %4431
  %4447 = fadd fast float %4369, -9.000000e+02
  %4448 = fadd fast float %4370, -1.500000e+01
  %4449 = fadd fast float %4371, -7.500000e+02
  %4450 = fmul fast float %4447, 0x3F62345680000000
  %4451 = fmul fast float %4448, 0x3F62345680000000
  %4452 = fmul fast float %4449, 0x3F62345680000000
  %4453 = call float @dx.op.dot3.f32(i32 55, float %4450, float %4451, float %4452, float %4450, float %4451, float %4452)  ; Dot3(ax,ay,az,bx,by,bz)
  %4454 = fsub fast float 1.000000e+00, %4453
  %4455 = call float @dx.op.unary.f32(i32 7, float %4454)  ; Saturate(value)
  %4456 = fmul fast float %4455, %4455
  %4457 = fadd fast float %4446, %4456
  %4458 = fmul fast float %4381, 0x3F25D867E0000000
  %4459 = fmul fast float %4458, %4457
  br label %4460

; <label>:4460                                    ; preds = %4414, %4407
  %4461 = phi float [ %4459, %4414 ], [ 0.000000e+00, %4407 ]
  %4462 = fadd fast float %4461, %4410
  %4463 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4462)  ; FMin(a,b)
  %4464 = fmul fast float %4463, 0xBFF7154760000000
  %4465 = call float @dx.op.unary.f32(i32 21, float %4464)  ; Exp(value)
  %4466 = fsub fast float 1.000000e+00, %4465
  %4467 = call float @dx.op.binary.f32(i32 36, float %12, float %4466)  ; FMin(a,b)
  %4468 = fsub fast float %13, %4326
  %4469 = fsub fast float %14, %4327
  %4470 = fsub fast float %15, %4328
  %4471 = fmul fast float %4467, %4468
  %4472 = fmul fast float %4467, %4469
  %4473 = fmul fast float %4467, %4470
  %4474 = fadd fast float %4471, %4326
  %4475 = fadd fast float %4472, %4327
  %4476 = fadd fast float %4473, %4328
  br label %4477

; <label>:4477                                    ; preds = %4460, %4339, %4333
  %4478 = phi float [ %4474, %4460 ], [ %4326, %4339 ], [ %4326, %4333 ]
  %4479 = phi float [ %4475, %4460 ], [ %4327, %4339 ], [ %4327, %4333 ]
  %4480 = phi float [ %4476, %4460 ], [ %4328, %4339 ], [ %4328, %4333 ]
  %4481 = fadd fast float %5, 1.000000e+00
  %4482 = fadd fast float %6, 1.000000e+00
  %4483 = fsub fast float 1.000000e+00, %5
  %4484 = fmul fast float %36, %4481
  %4485 = fmul fast float %36, %4482
  %4486 = fmul fast float %36, %4483
  %4487 = fmul fast float %4484, %4478
  %4488 = fmul fast float %4485, %4479
  %4489 = fmul fast float %4486, %4480
  %4490 = fcmp fast ult float %37, 5.000000e-01
  br i1 %4490, label %4516, label %4491

; <label>:4491                                    ; preds = %4477
  %4492 = fmul fast float %4487, 0x4004147AE0000000
  %4493 = fmul fast float %4488, 0x4004147AE0000000
  %4494 = fmul fast float %4489, 0x4004147AE0000000
  %4495 = fadd fast float %4492, 0x3F9EB851E0000000
  %4496 = fadd fast float %4493, 0x3F9EB851E0000000
  %4497 = fadd fast float %4494, 0x3F9EB851E0000000
  %4498 = fmul fast float %4495, %4487
  %4499 = fmul fast float %4496, %4488
  %4500 = fmul fast float %4497, %4489
  %4501 = fmul fast float %4487, 0x400370A3E0000000
  %4502 = fmul fast float %4488, 0x400370A3E0000000
  %4503 = fmul fast float %4489, 0x400370A3E0000000
  %4504 = fadd fast float %4501, 0x3FE2E147A0000000
  %4505 = fadd fast float %4502, 0x3FE2E147A0000000
  %4506 = fadd fast float %4503, 0x3FE2E147A0000000
  %4507 = fmul fast float %4504, %4487
  %4508 = fmul fast float %4505, %4488
  %4509 = fmul fast float %4506, %4489
  %4510 = fadd fast float %4507, 0x3FC1EB8520000000
  %4511 = fadd fast float %4508, 0x3FC1EB8520000000
  %4512 = fadd fast float %4509, 0x3FC1EB8520000000
  %4513 = fdiv fast float %4498, %4510
  %4514 = fdiv fast float %4499, %4511
  %4515 = fdiv fast float %4500, %4512
  br label %4516

; <label>:4516                                    ; preds = %4491, %4477
  %4517 = phi float [ %4513, %4491 ], [ %4487, %4477 ]
  %4518 = phi float [ %4514, %4491 ], [ %4488, %4477 ]
  %4519 = phi float [ %4515, %4491 ], [ %4489, %4477 ]
  %4520 = call float @dx.op.unary.f32(i32 7, float %4517)  ; Saturate(value)
  %4521 = call float @dx.op.unary.f32(i32 7, float %4518)  ; Saturate(value)
  %4522 = call float @dx.op.unary.f32(i32 7, float %4519)  ; Saturate(value)
  %4523 = call float @dx.op.dot3.f32(i32 55, float %4520, float %4521, float %4522, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4524 = fsub fast float %4520, %4523
  %4525 = fsub fast float %4521, %4523
  %4526 = fsub fast float %4522, %4523
  %4527 = fmul fast float %4524, %8
  %4528 = fmul fast float %4525, %8
  %4529 = fmul fast float %4526, %8
  %4530 = fadd fast float %4527, %4523
  %4531 = fadd fast float %4528, %4523
  %4532 = fadd fast float %4529, %4523
  %4533 = call float @dx.op.unary.f32(i32 7, float %4530)  ; Saturate(value)
  %4534 = call float @dx.op.unary.f32(i32 7, float %4531)  ; Saturate(value)
  %4535 = call float @dx.op.unary.f32(i32 7, float %4532)  ; Saturate(value)
  %4536 = fadd fast float %4533, 0xBFC70A3D80000000
  %4537 = fadd fast float %4534, 0xBFC70A3D80000000
  %4538 = fadd fast float %4535, 0xBFC70A3D80000000
  %4539 = fmul fast float %4536, %7
  %4540 = fmul fast float %4537, %7
  %4541 = fmul fast float %4538, %7
  %4542 = fadd fast float %4539, 0x3FC70A3D80000000
  %4543 = fadd fast float %4540, 0x3FC70A3D80000000
  %4544 = fadd fast float %4541, 0x3FC70A3D80000000
  %4545 = call float @dx.op.unary.f32(i32 7, float %4542)  ; Saturate(value)
  %4546 = call float @dx.op.unary.f32(i32 7, float %4543)  ; Saturate(value)
  %4547 = call float @dx.op.unary.f32(i32 7, float %4544)  ; Saturate(value)
  %4548 = add i32 %2906, -1
  %4549 = call i32 @dx.op.binary.i32(i32 37, i32 %1485, i32 0)  ; IMax(a,b)
  %4550 = call i32 @dx.op.binary.i32(i32 37, i32 %4548, i32 0)  ; IMax(a,b)
  %4551 = call i32 @dx.op.binary.i32(i32 38, i32 %4549, i32 %59)  ; IMin(a,b)
  %4552 = call i32 @dx.op.binary.i32(i32 38, i32 %4550, i32 %60)  ; IMin(a,b)
  %4553 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4551, i32 %4552, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4554 = extractvalue %dx.types.ResRet.f32 %4553, 0
  %4555 = extractvalue %dx.types.ResRet.f32 %4553, 1
  %4556 = extractvalue %dx.types.ResRet.f32 %4553, 2
  %4557 = extractvalue %dx.types.ResRet.f32 %4553, 3
  %4558 = fcmp fast olt float %4557, 0.000000e+00
  br i1 %4558, label %4559, label %4593

; <label>:4559                                    ; preds = %4516
  %4560 = fcmp fast ogt float %4554, 0x3FA4B5DCC0000000
  %4561 = fcmp fast ogt float %4555, 0x3FA4B5DCC0000000
  %4562 = fcmp fast ogt float %4556, 0x3FA4B5DCC0000000
  %4563 = select i1 %4560, float 0.000000e+00, float 1.000000e+00
  %4564 = select i1 %4561, float 0.000000e+00, float 1.000000e+00
  %4565 = select i1 %4562, float 0.000000e+00, float 1.000000e+00
  %4566 = fmul fast float %4554, 0x3FB3D07220000000
  %4567 = fmul fast float %4555, 0x3FB3D07220000000
  %4568 = fmul fast float %4556, 0x3FB3D07220000000
  %4569 = fadd fast float %4554, 0x3FAC28F5C0000000
  %4570 = fadd fast float %4555, 0x3FAC28F5C0000000
  %4571 = fadd fast float %4556, 0x3FAC28F5C0000000
  %4572 = fmul fast float %4569, 0x3FEE54EDE0000000
  %4573 = fmul fast float %4570, 0x3FEE54EDE0000000
  %4574 = fmul fast float %4571, 0x3FEE54EDE0000000
  %4575 = call float @dx.op.unary.f32(i32 23, float %4572)  ; Log(value)
  %4576 = call float @dx.op.unary.f32(i32 23, float %4573)  ; Log(value)
  %4577 = call float @dx.op.unary.f32(i32 23, float %4574)  ; Log(value)
  %4578 = fmul fast float %4575, 0x4003333340000000
  %4579 = fmul fast float %4576, 0x4003333340000000
  %4580 = fmul fast float %4577, 0x4003333340000000
  %4581 = call float @dx.op.unary.f32(i32 21, float %4578)  ; Exp(value)
  %4582 = call float @dx.op.unary.f32(i32 21, float %4579)  ; Exp(value)
  %4583 = call float @dx.op.unary.f32(i32 21, float %4580)  ; Exp(value)
  %4584 = fsub fast float %4566, %4581
  %4585 = fsub fast float %4567, %4582
  %4586 = fsub fast float %4568, %4583
  %4587 = fmul fast float %4584, %4563
  %4588 = fmul fast float %4585, %4564
  %4589 = fmul fast float %4586, %4565
  %4590 = fadd fast float %4587, %4581
  %4591 = fadd fast float %4588, %4582
  %4592 = fadd fast float %4589, %4583
  br label %4808

; <label>:4593                                    ; preds = %4516
  %4594 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4551, i32 %4552, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4595 = extractvalue %dx.types.ResRet.f32 %4594, 0
  %4596 = fcmp fast ogt float %38, 5.000000e-01
  %4597 = fcmp fast olt float %4595, 1.000000e+00
  %4598 = and i1 %4596, %4597
  br i1 %4598, label %4599, label %4737

; <label>:4599                                    ; preds = %4593
  %4600 = sitofp i32 %4551 to float
  %4601 = sitofp i32 %4552 to float
  %4602 = fadd fast float %4600, 5.000000e-01
  %4603 = fadd fast float %4601, 5.000000e-01
  %4604 = fdiv fast float %4602, %45
  %4605 = fdiv fast float %4603, %46
  %4606 = fmul fast float %4604, 2.000000e+00
  %4607 = fmul fast float %4605, 2.000000e+00
  %4608 = fadd fast float %4606, -1.000000e+00
  %4609 = fsub fast float 1.000000e+00, %4607
  %4610 = fmul fast float %4608, %35
  %4611 = call float @dx.op.tertiary.f32(i32 46, float %4609, float %31, float %4610)  ; FMad(a,b,c)
  %4612 = call float @dx.op.tertiary.f32(i32 46, float %4595, float %27, float %4611)  ; FMad(a,b,c)
  %4613 = fadd fast float %4612, %23
  %4614 = call float @dx.op.unary.f32(i32 6, float %4613)  ; FAbs(value)
  %4615 = fcmp fast ogt float %4614, 0x3EB0C6F7A0000000
  br i1 %4615, label %4616, label %4737

; <label>:4616                                    ; preds = %4599
  %4617 = fmul fast float %4608, %34
  %4618 = call float @dx.op.tertiary.f32(i32 46, float %4609, float %30, float %4617)  ; FMad(a,b,c)
  %4619 = call float @dx.op.tertiary.f32(i32 46, float %4595, float %26, float %4618)  ; FMad(a,b,c)
  %4620 = fadd fast float %4619, %22
  %4621 = fmul fast float %4608, %33
  %4622 = call float @dx.op.tertiary.f32(i32 46, float %4609, float %29, float %4621)  ; FMad(a,b,c)
  %4623 = call float @dx.op.tertiary.f32(i32 46, float %4595, float %25, float %4622)  ; FMad(a,b,c)
  %4624 = fadd fast float %4623, %21
  %4625 = fmul fast float %4608, %32
  %4626 = call float @dx.op.tertiary.f32(i32 46, float %4609, float %28, float %4625)  ; FMad(a,b,c)
  %4627 = call float @dx.op.tertiary.f32(i32 46, float %4595, float %24, float %4626)  ; FMad(a,b,c)
  %4628 = fadd fast float %4627, %20
  %4629 = fdiv fast float %4628, %4613
  %4630 = fdiv fast float %4624, %4613
  %4631 = fdiv fast float %4620, %4613
  %4632 = fsub fast float %4629, %17
  %4633 = fsub fast float %4630, %18
  %4634 = fsub fast float %4631, %19
  %4635 = fmul fast float %4632, %4632
  %4636 = fmul fast float %4633, %4633
  %4637 = fadd fast float %4636, %4635
  %4638 = fmul fast float %4634, %4634
  %4639 = fadd fast float %4637, %4638
  %4640 = call float @dx.op.unary.f32(i32 24, float %4639)  ; Sqrt(value)
  %4641 = fsub fast float %4640, %9
  %4642 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4641)  ; FMax(a,b)
  %4643 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %4643, label %4644, label %4667

; <label>:4644                                    ; preds = %4616
  %4645 = call float @dx.op.unary.f32(i32 6, float %4633)  ; FAbs(value)
  %4646 = fmul fast float %4645, %11
  %4647 = fcmp fast olt float %4646, 0x3F50624DE0000000
  br i1 %4647, label %4648, label %4651

; <label>:4648                                    ; preds = %4644
  %4649 = fmul fast float %4646, 5.000000e-01
  %4650 = fsub fast float 1.000000e+00, %4649
  br label %4656

; <label>:4651                                    ; preds = %4644
  %4652 = fmul fast float %4646, 0xBFF7154760000000
  %4653 = call float @dx.op.unary.f32(i32 21, float %4652)  ; Exp(value)
  %4654 = fsub fast float 1.000000e+00, %4653
  %4655 = fdiv fast float %4654, %4646
  br label %4656

; <label>:4656                                    ; preds = %4651, %4648
  %4657 = phi float [ %4650, %4648 ], [ %4655, %4651 ]
  %4658 = call float @dx.op.binary.f32(i32 36, float %4630, float %18)  ; FMin(a,b)
  %4659 = fsub fast float %4658, %10
  %4660 = fmul fast float %11, %4659
  %4661 = fsub fast float -0.000000e+00, %4660
  %4662 = call float @dx.op.binary.f32(i32 35, float %4661, float -4.000000e+01)  ; FMax(a,b)
  %4663 = call float @dx.op.binary.f32(i32 36, float %4662, float 5.000000e+00)  ; FMin(a,b)
  %4664 = fmul fast float %4663, 0x3FF7154760000000
  %4665 = call float @dx.op.unary.f32(i32 21, float %4664)  ; Exp(value)
  %4666 = fmul fast float %4665, %4657
  br label %4667

; <label>:4667                                    ; preds = %4656, %4616
  %4668 = phi float [ %4666, %4656 ], [ 1.000000e+00, %4616 ]
  %4669 = fmul fast float %4642, %16
  %4670 = fmul fast float %4669, %4668
  %4671 = fcmp fast ole float %4640, %9
  %4672 = fcmp fast olt float %4640, 0x3F1A36E2E0000000
  %4673 = or i1 %4671, %4672
  br i1 %4673, label %4720, label %4674

; <label>:4674                                    ; preds = %4667
  %4675 = fdiv fast float %9, %4640
  %4676 = fmul fast float %4675, %4632
  %4677 = fmul fast float %4675, %4633
  %4678 = fmul fast float %4675, %4634
  %4679 = fadd fast float %4676, %17
  %4680 = fadd fast float %4677, %18
  %4681 = fadd fast float %4678, %19
  %4682 = fadd fast float %4679, -9.000000e+02
  %4683 = fadd fast float %4680, -1.500000e+01
  %4684 = fadd fast float %4681, -7.500000e+02
  %4685 = fmul fast float %4682, 0x3F62345680000000
  %4686 = fmul fast float %4683, 0x3F62345680000000
  %4687 = fmul fast float %4684, 0x3F62345680000000
  %4688 = call float @dx.op.dot3.f32(i32 55, float %4685, float %4686, float %4687, float %4685, float %4686, float %4687)  ; Dot3(ax,ay,az,bx,by,bz)
  %4689 = fsub fast float 1.000000e+00, %4688
  %4690 = call float @dx.op.unary.f32(i32 7, float %4689)  ; Saturate(value)
  %4691 = fmul fast float %4690, %4690
  %4692 = fadd fast float %4679, %4629
  %4693 = fadd fast float %4680, %4630
  %4694 = fadd fast float %4681, %4631
  %4695 = fmul fast float %4692, 0x3F52345680000000
  %4696 = fadd fast float %4695, -2.000000e+00
  %4697 = fmul fast float %4693, 0x3F52345680000000
  %4698 = fadd fast float %4697, 0xBFA1111120000000
  %4699 = fmul fast float %4694, 0x3F52345680000000
  %4700 = fadd fast float %4699, 0xBFFAAAAAC0000000
  %4701 = call float @dx.op.dot3.f32(i32 55, float %4696, float %4698, float %4700, float %4696, float %4698, float %4700)  ; Dot3(ax,ay,az,bx,by,bz)
  %4702 = fsub fast float 1.000000e+00, %4701
  %4703 = call float @dx.op.unary.f32(i32 7, float %4702)  ; Saturate(value)
  %4704 = fmul fast float %4703, %4703
  %4705 = fmul fast float %4704, 4.000000e+00
  %4706 = fadd fast float %4705, %4691
  %4707 = fadd fast float %4629, -9.000000e+02
  %4708 = fadd fast float %4630, -1.500000e+01
  %4709 = fadd fast float %4631, -7.500000e+02
  %4710 = fmul fast float %4707, 0x3F62345680000000
  %4711 = fmul fast float %4708, 0x3F62345680000000
  %4712 = fmul fast float %4709, 0x3F62345680000000
  %4713 = call float @dx.op.dot3.f32(i32 55, float %4710, float %4711, float %4712, float %4710, float %4711, float %4712)  ; Dot3(ax,ay,az,bx,by,bz)
  %4714 = fsub fast float 1.000000e+00, %4713
  %4715 = call float @dx.op.unary.f32(i32 7, float %4714)  ; Saturate(value)
  %4716 = fmul fast float %4715, %4715
  %4717 = fadd fast float %4706, %4716
  %4718 = fmul fast float %4641, 0x3F25D867E0000000
  %4719 = fmul fast float %4718, %4717
  br label %4720

; <label>:4720                                    ; preds = %4674, %4667
  %4721 = phi float [ %4719, %4674 ], [ 0.000000e+00, %4667 ]
  %4722 = fadd fast float %4721, %4670
  %4723 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4722)  ; FMin(a,b)
  %4724 = fmul fast float %4723, 0xBFF7154760000000
  %4725 = call float @dx.op.unary.f32(i32 21, float %4724)  ; Exp(value)
  %4726 = fsub fast float 1.000000e+00, %4725
  %4727 = call float @dx.op.binary.f32(i32 36, float %12, float %4726)  ; FMin(a,b)
  %4728 = fsub fast float %13, %4554
  %4729 = fsub fast float %14, %4555
  %4730 = fsub fast float %15, %4556
  %4731 = fmul fast float %4727, %4728
  %4732 = fmul fast float %4727, %4729
  %4733 = fmul fast float %4727, %4730
  %4734 = fadd fast float %4731, %4554
  %4735 = fadd fast float %4732, %4555
  %4736 = fadd fast float %4733, %4556
  br label %4737

; <label>:4737                                    ; preds = %4720, %4599, %4593
  %4738 = phi float [ %4734, %4720 ], [ %4554, %4599 ], [ %4554, %4593 ]
  %4739 = phi float [ %4735, %4720 ], [ %4555, %4599 ], [ %4555, %4593 ]
  %4740 = phi float [ %4736, %4720 ], [ %4556, %4599 ], [ %4556, %4593 ]
  %4741 = fadd fast float %5, 1.000000e+00
  %4742 = fadd fast float %6, 1.000000e+00
  %4743 = fsub fast float 1.000000e+00, %5
  %4744 = fmul fast float %36, %4741
  %4745 = fmul fast float %36, %4742
  %4746 = fmul fast float %36, %4743
  %4747 = fmul fast float %4744, %4738
  %4748 = fmul fast float %4745, %4739
  %4749 = fmul fast float %4746, %4740
  %4750 = fcmp fast ult float %37, 5.000000e-01
  br i1 %4750, label %4776, label %4751

; <label>:4751                                    ; preds = %4737
  %4752 = fmul fast float %4747, 0x4004147AE0000000
  %4753 = fmul fast float %4748, 0x4004147AE0000000
  %4754 = fmul fast float %4749, 0x4004147AE0000000
  %4755 = fadd fast float %4752, 0x3F9EB851E0000000
  %4756 = fadd fast float %4753, 0x3F9EB851E0000000
  %4757 = fadd fast float %4754, 0x3F9EB851E0000000
  %4758 = fmul fast float %4755, %4747
  %4759 = fmul fast float %4756, %4748
  %4760 = fmul fast float %4757, %4749
  %4761 = fmul fast float %4747, 0x400370A3E0000000
  %4762 = fmul fast float %4748, 0x400370A3E0000000
  %4763 = fmul fast float %4749, 0x400370A3E0000000
  %4764 = fadd fast float %4761, 0x3FE2E147A0000000
  %4765 = fadd fast float %4762, 0x3FE2E147A0000000
  %4766 = fadd fast float %4763, 0x3FE2E147A0000000
  %4767 = fmul fast float %4764, %4747
  %4768 = fmul fast float %4765, %4748
  %4769 = fmul fast float %4766, %4749
  %4770 = fadd fast float %4767, 0x3FC1EB8520000000
  %4771 = fadd fast float %4768, 0x3FC1EB8520000000
  %4772 = fadd fast float %4769, 0x3FC1EB8520000000
  %4773 = fdiv fast float %4758, %4770
  %4774 = fdiv fast float %4759, %4771
  %4775 = fdiv fast float %4760, %4772
  br label %4776

; <label>:4776                                    ; preds = %4751, %4737
  %4777 = phi float [ %4773, %4751 ], [ %4747, %4737 ]
  %4778 = phi float [ %4774, %4751 ], [ %4748, %4737 ]
  %4779 = phi float [ %4775, %4751 ], [ %4749, %4737 ]
  %4780 = call float @dx.op.unary.f32(i32 7, float %4777)  ; Saturate(value)
  %4781 = call float @dx.op.unary.f32(i32 7, float %4778)  ; Saturate(value)
  %4782 = call float @dx.op.unary.f32(i32 7, float %4779)  ; Saturate(value)
  %4783 = call float @dx.op.dot3.f32(i32 55, float %4780, float %4781, float %4782, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %4784 = fsub fast float %4780, %4783
  %4785 = fsub fast float %4781, %4783
  %4786 = fsub fast float %4782, %4783
  %4787 = fmul fast float %4784, %8
  %4788 = fmul fast float %4785, %8
  %4789 = fmul fast float %4786, %8
  %4790 = fadd fast float %4787, %4783
  %4791 = fadd fast float %4788, %4783
  %4792 = fadd fast float %4789, %4783
  %4793 = call float @dx.op.unary.f32(i32 7, float %4790)  ; Saturate(value)
  %4794 = call float @dx.op.unary.f32(i32 7, float %4791)  ; Saturate(value)
  %4795 = call float @dx.op.unary.f32(i32 7, float %4792)  ; Saturate(value)
  %4796 = fadd fast float %4793, 0xBFC70A3D80000000
  %4797 = fadd fast float %4794, 0xBFC70A3D80000000
  %4798 = fadd fast float %4795, 0xBFC70A3D80000000
  %4799 = fmul fast float %4796, %7
  %4800 = fmul fast float %4797, %7
  %4801 = fmul fast float %4798, %7
  %4802 = fadd fast float %4799, 0x3FC70A3D80000000
  %4803 = fadd fast float %4800, 0x3FC70A3D80000000
  %4804 = fadd fast float %4801, 0x3FC70A3D80000000
  %4805 = call float @dx.op.unary.f32(i32 7, float %4802)  ; Saturate(value)
  %4806 = call float @dx.op.unary.f32(i32 7, float %4803)  ; Saturate(value)
  %4807 = call float @dx.op.unary.f32(i32 7, float %4804)  ; Saturate(value)
  br label %4808

; <label>:4808                                    ; preds = %4776, %4559
  %4809 = phi float [ %4590, %4559 ], [ %4805, %4776 ]
  %4810 = phi float [ %4591, %4559 ], [ %4806, %4776 ]
  %4811 = phi float [ %4592, %4559 ], [ %4807, %4776 ]
  %4812 = add i32 %2906, 1
  %4813 = call i32 @dx.op.binary.i32(i32 37, i32 %4812, i32 0)  ; IMax(a,b)
  %4814 = call i32 @dx.op.binary.i32(i32 38, i32 %4813, i32 %60)  ; IMin(a,b)
  %4815 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %4551, i32 %4814, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4816 = extractvalue %dx.types.ResRet.f32 %4815, 0
  %4817 = extractvalue %dx.types.ResRet.f32 %4815, 1
  %4818 = extractvalue %dx.types.ResRet.f32 %4815, 2
  %4819 = extractvalue %dx.types.ResRet.f32 %4815, 3
  %4820 = fcmp fast olt float %4819, 0.000000e+00
  br i1 %4820, label %4821, label %4855

; <label>:4821                                    ; preds = %4808
  %4822 = fcmp fast ogt float %4816, 0x3FA4B5DCC0000000
  %4823 = fcmp fast ogt float %4817, 0x3FA4B5DCC0000000
  %4824 = fcmp fast ogt float %4818, 0x3FA4B5DCC0000000
  %4825 = select i1 %4822, float 0.000000e+00, float 1.000000e+00
  %4826 = select i1 %4823, float 0.000000e+00, float 1.000000e+00
  %4827 = select i1 %4824, float 0.000000e+00, float 1.000000e+00
  %4828 = fmul fast float %4816, 0x3FB3D07220000000
  %4829 = fmul fast float %4817, 0x3FB3D07220000000
  %4830 = fmul fast float %4818, 0x3FB3D07220000000
  %4831 = fadd fast float %4816, 0x3FAC28F5C0000000
  %4832 = fadd fast float %4817, 0x3FAC28F5C0000000
  %4833 = fadd fast float %4818, 0x3FAC28F5C0000000
  %4834 = fmul fast float %4831, 0x3FEE54EDE0000000
  %4835 = fmul fast float %4832, 0x3FEE54EDE0000000
  %4836 = fmul fast float %4833, 0x3FEE54EDE0000000
  %4837 = call float @dx.op.unary.f32(i32 23, float %4834)  ; Log(value)
  %4838 = call float @dx.op.unary.f32(i32 23, float %4835)  ; Log(value)
  %4839 = call float @dx.op.unary.f32(i32 23, float %4836)  ; Log(value)
  %4840 = fmul fast float %4837, 0x4003333340000000
  %4841 = fmul fast float %4838, 0x4003333340000000
  %4842 = fmul fast float %4839, 0x4003333340000000
  %4843 = call float @dx.op.unary.f32(i32 21, float %4840)  ; Exp(value)
  %4844 = call float @dx.op.unary.f32(i32 21, float %4841)  ; Exp(value)
  %4845 = call float @dx.op.unary.f32(i32 21, float %4842)  ; Exp(value)
  %4846 = fsub fast float %4828, %4843
  %4847 = fsub fast float %4829, %4844
  %4848 = fsub fast float %4830, %4845
  %4849 = fmul fast float %4846, %4825
  %4850 = fmul fast float %4847, %4826
  %4851 = fmul fast float %4848, %4827
  %4852 = fadd fast float %4849, %4843
  %4853 = fadd fast float %4850, %4844
  %4854 = fadd fast float %4851, %4845
  br label %5070

; <label>:4855                                    ; preds = %4808
  %4856 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %4551, i32 %4814, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %4857 = extractvalue %dx.types.ResRet.f32 %4856, 0
  %4858 = fcmp fast ogt float %38, 5.000000e-01
  %4859 = fcmp fast olt float %4857, 1.000000e+00
  %4860 = and i1 %4858, %4859
  br i1 %4860, label %4861, label %4999

; <label>:4861                                    ; preds = %4855
  %4862 = sitofp i32 %4551 to float
  %4863 = sitofp i32 %4814 to float
  %4864 = fadd fast float %4862, 5.000000e-01
  %4865 = fadd fast float %4863, 5.000000e-01
  %4866 = fdiv fast float %4864, %45
  %4867 = fdiv fast float %4865, %46
  %4868 = fmul fast float %4866, 2.000000e+00
  %4869 = fmul fast float %4867, 2.000000e+00
  %4870 = fadd fast float %4868, -1.000000e+00
  %4871 = fsub fast float 1.000000e+00, %4869
  %4872 = fmul fast float %4870, %35
  %4873 = call float @dx.op.tertiary.f32(i32 46, float %4871, float %31, float %4872)  ; FMad(a,b,c)
  %4874 = call float @dx.op.tertiary.f32(i32 46, float %4857, float %27, float %4873)  ; FMad(a,b,c)
  %4875 = fadd fast float %4874, %23
  %4876 = call float @dx.op.unary.f32(i32 6, float %4875)  ; FAbs(value)
  %4877 = fcmp fast ogt float %4876, 0x3EB0C6F7A0000000
  br i1 %4877, label %4878, label %4999

; <label>:4878                                    ; preds = %4861
  %4879 = fmul fast float %4870, %34
  %4880 = call float @dx.op.tertiary.f32(i32 46, float %4871, float %30, float %4879)  ; FMad(a,b,c)
  %4881 = call float @dx.op.tertiary.f32(i32 46, float %4857, float %26, float %4880)  ; FMad(a,b,c)
  %4882 = fadd fast float %4881, %22
  %4883 = fmul fast float %4870, %33
  %4884 = call float @dx.op.tertiary.f32(i32 46, float %4871, float %29, float %4883)  ; FMad(a,b,c)
  %4885 = call float @dx.op.tertiary.f32(i32 46, float %4857, float %25, float %4884)  ; FMad(a,b,c)
  %4886 = fadd fast float %4885, %21
  %4887 = fmul fast float %4870, %32
  %4888 = call float @dx.op.tertiary.f32(i32 46, float %4871, float %28, float %4887)  ; FMad(a,b,c)
  %4889 = call float @dx.op.tertiary.f32(i32 46, float %4857, float %24, float %4888)  ; FMad(a,b,c)
  %4890 = fadd fast float %4889, %20
  %4891 = fdiv fast float %4890, %4875
  %4892 = fdiv fast float %4886, %4875
  %4893 = fdiv fast float %4882, %4875
  %4894 = fsub fast float %4891, %17
  %4895 = fsub fast float %4892, %18
  %4896 = fsub fast float %4893, %19
  %4897 = fmul fast float %4894, %4894
  %4898 = fmul fast float %4895, %4895
  %4899 = fadd fast float %4898, %4897
  %4900 = fmul fast float %4896, %4896
  %4901 = fadd fast float %4899, %4900
  %4902 = call float @dx.op.unary.f32(i32 24, float %4901)  ; Sqrt(value)
  %4903 = fsub fast float %4902, %9
  %4904 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %4903)  ; FMax(a,b)
  %4905 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %4905, label %4906, label %4929

; <label>:4906                                    ; preds = %4878
  %4907 = call float @dx.op.unary.f32(i32 6, float %4895)  ; FAbs(value)
  %4908 = fmul fast float %4907, %11
  %4909 = fcmp fast olt float %4908, 0x3F50624DE0000000
  br i1 %4909, label %4910, label %4913

; <label>:4910                                    ; preds = %4906
  %4911 = fmul fast float %4908, 5.000000e-01
  %4912 = fsub fast float 1.000000e+00, %4911
  br label %4918

; <label>:4913                                    ; preds = %4906
  %4914 = fmul fast float %4908, 0xBFF7154760000000
  %4915 = call float @dx.op.unary.f32(i32 21, float %4914)  ; Exp(value)
  %4916 = fsub fast float 1.000000e+00, %4915
  %4917 = fdiv fast float %4916, %4908
  br label %4918

; <label>:4918                                    ; preds = %4913, %4910
  %4919 = phi float [ %4912, %4910 ], [ %4917, %4913 ]
  %4920 = call float @dx.op.binary.f32(i32 36, float %4892, float %18)  ; FMin(a,b)
  %4921 = fsub fast float %4920, %10
  %4922 = fmul fast float %11, %4921
  %4923 = fsub fast float -0.000000e+00, %4922
  %4924 = call float @dx.op.binary.f32(i32 35, float %4923, float -4.000000e+01)  ; FMax(a,b)
  %4925 = call float @dx.op.binary.f32(i32 36, float %4924, float 5.000000e+00)  ; FMin(a,b)
  %4926 = fmul fast float %4925, 0x3FF7154760000000
  %4927 = call float @dx.op.unary.f32(i32 21, float %4926)  ; Exp(value)
  %4928 = fmul fast float %4927, %4919
  br label %4929

; <label>:4929                                    ; preds = %4918, %4878
  %4930 = phi float [ %4928, %4918 ], [ 1.000000e+00, %4878 ]
  %4931 = fmul fast float %4904, %16
  %4932 = fmul fast float %4931, %4930
  %4933 = fcmp fast ole float %4902, %9
  %4934 = fcmp fast olt float %4902, 0x3F1A36E2E0000000
  %4935 = or i1 %4933, %4934
  br i1 %4935, label %4982, label %4936

; <label>:4936                                    ; preds = %4929
  %4937 = fdiv fast float %9, %4902
  %4938 = fmul fast float %4937, %4894
  %4939 = fmul fast float %4937, %4895
  %4940 = fmul fast float %4937, %4896
  %4941 = fadd fast float %4938, %17
  %4942 = fadd fast float %4939, %18
  %4943 = fadd fast float %4940, %19
  %4944 = fadd fast float %4941, -9.000000e+02
  %4945 = fadd fast float %4942, -1.500000e+01
  %4946 = fadd fast float %4943, -7.500000e+02
  %4947 = fmul fast float %4944, 0x3F62345680000000
  %4948 = fmul fast float %4945, 0x3F62345680000000
  %4949 = fmul fast float %4946, 0x3F62345680000000
  %4950 = call float @dx.op.dot3.f32(i32 55, float %4947, float %4948, float %4949, float %4947, float %4948, float %4949)  ; Dot3(ax,ay,az,bx,by,bz)
  %4951 = fsub fast float 1.000000e+00, %4950
  %4952 = call float @dx.op.unary.f32(i32 7, float %4951)  ; Saturate(value)
  %4953 = fmul fast float %4952, %4952
  %4954 = fadd fast float %4941, %4891
  %4955 = fadd fast float %4942, %4892
  %4956 = fadd fast float %4943, %4893
  %4957 = fmul fast float %4954, 0x3F52345680000000
  %4958 = fadd fast float %4957, -2.000000e+00
  %4959 = fmul fast float %4955, 0x3F52345680000000
  %4960 = fadd fast float %4959, 0xBFA1111120000000
  %4961 = fmul fast float %4956, 0x3F52345680000000
  %4962 = fadd fast float %4961, 0xBFFAAAAAC0000000
  %4963 = call float @dx.op.dot3.f32(i32 55, float %4958, float %4960, float %4962, float %4958, float %4960, float %4962)  ; Dot3(ax,ay,az,bx,by,bz)
  %4964 = fsub fast float 1.000000e+00, %4963
  %4965 = call float @dx.op.unary.f32(i32 7, float %4964)  ; Saturate(value)
  %4966 = fmul fast float %4965, %4965
  %4967 = fmul fast float %4966, 4.000000e+00
  %4968 = fadd fast float %4967, %4953
  %4969 = fadd fast float %4891, -9.000000e+02
  %4970 = fadd fast float %4892, -1.500000e+01
  %4971 = fadd fast float %4893, -7.500000e+02
  %4972 = fmul fast float %4969, 0x3F62345680000000
  %4973 = fmul fast float %4970, 0x3F62345680000000
  %4974 = fmul fast float %4971, 0x3F62345680000000
  %4975 = call float @dx.op.dot3.f32(i32 55, float %4972, float %4973, float %4974, float %4972, float %4973, float %4974)  ; Dot3(ax,ay,az,bx,by,bz)
  %4976 = fsub fast float 1.000000e+00, %4975
  %4977 = call float @dx.op.unary.f32(i32 7, float %4976)  ; Saturate(value)
  %4978 = fmul fast float %4977, %4977
  %4979 = fadd fast float %4968, %4978
  %4980 = fmul fast float %4903, 0x3F25D867E0000000
  %4981 = fmul fast float %4980, %4979
  br label %4982

; <label>:4982                                    ; preds = %4936, %4929
  %4983 = phi float [ %4981, %4936 ], [ 0.000000e+00, %4929 ]
  %4984 = fadd fast float %4983, %4932
  %4985 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %4984)  ; FMin(a,b)
  %4986 = fmul fast float %4985, 0xBFF7154760000000
  %4987 = call float @dx.op.unary.f32(i32 21, float %4986)  ; Exp(value)
  %4988 = fsub fast float 1.000000e+00, %4987
  %4989 = call float @dx.op.binary.f32(i32 36, float %12, float %4988)  ; FMin(a,b)
  %4990 = fsub fast float %13, %4816
  %4991 = fsub fast float %14, %4817
  %4992 = fsub fast float %15, %4818
  %4993 = fmul fast float %4989, %4990
  %4994 = fmul fast float %4989, %4991
  %4995 = fmul fast float %4989, %4992
  %4996 = fadd fast float %4993, %4816
  %4997 = fadd fast float %4994, %4817
  %4998 = fadd fast float %4995, %4818
  br label %4999

; <label>:4999                                    ; preds = %4982, %4861, %4855
  %5000 = phi float [ %4996, %4982 ], [ %4816, %4861 ], [ %4816, %4855 ]
  %5001 = phi float [ %4997, %4982 ], [ %4817, %4861 ], [ %4817, %4855 ]
  %5002 = phi float [ %4998, %4982 ], [ %4818, %4861 ], [ %4818, %4855 ]
  %5003 = fadd fast float %5, 1.000000e+00
  %5004 = fadd fast float %6, 1.000000e+00
  %5005 = fsub fast float 1.000000e+00, %5
  %5006 = fmul fast float %36, %5003
  %5007 = fmul fast float %36, %5004
  %5008 = fmul fast float %36, %5005
  %5009 = fmul fast float %5006, %5000
  %5010 = fmul fast float %5007, %5001
  %5011 = fmul fast float %5008, %5002
  %5012 = fcmp fast ult float %37, 5.000000e-01
  br i1 %5012, label %5038, label %5013

; <label>:5013                                    ; preds = %4999
  %5014 = fmul fast float %5009, 0x4004147AE0000000
  %5015 = fmul fast float %5010, 0x4004147AE0000000
  %5016 = fmul fast float %5011, 0x4004147AE0000000
  %5017 = fadd fast float %5014, 0x3F9EB851E0000000
  %5018 = fadd fast float %5015, 0x3F9EB851E0000000
  %5019 = fadd fast float %5016, 0x3F9EB851E0000000
  %5020 = fmul fast float %5017, %5009
  %5021 = fmul fast float %5018, %5010
  %5022 = fmul fast float %5019, %5011
  %5023 = fmul fast float %5009, 0x400370A3E0000000
  %5024 = fmul fast float %5010, 0x400370A3E0000000
  %5025 = fmul fast float %5011, 0x400370A3E0000000
  %5026 = fadd fast float %5023, 0x3FE2E147A0000000
  %5027 = fadd fast float %5024, 0x3FE2E147A0000000
  %5028 = fadd fast float %5025, 0x3FE2E147A0000000
  %5029 = fmul fast float %5026, %5009
  %5030 = fmul fast float %5027, %5010
  %5031 = fmul fast float %5028, %5011
  %5032 = fadd fast float %5029, 0x3FC1EB8520000000
  %5033 = fadd fast float %5030, 0x3FC1EB8520000000
  %5034 = fadd fast float %5031, 0x3FC1EB8520000000
  %5035 = fdiv fast float %5020, %5032
  %5036 = fdiv fast float %5021, %5033
  %5037 = fdiv fast float %5022, %5034
  br label %5038

; <label>:5038                                    ; preds = %5013, %4999
  %5039 = phi float [ %5035, %5013 ], [ %5009, %4999 ]
  %5040 = phi float [ %5036, %5013 ], [ %5010, %4999 ]
  %5041 = phi float [ %5037, %5013 ], [ %5011, %4999 ]
  %5042 = call float @dx.op.unary.f32(i32 7, float %5039)  ; Saturate(value)
  %5043 = call float @dx.op.unary.f32(i32 7, float %5040)  ; Saturate(value)
  %5044 = call float @dx.op.unary.f32(i32 7, float %5041)  ; Saturate(value)
  %5045 = call float @dx.op.dot3.f32(i32 55, float %5042, float %5043, float %5044, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5046 = fsub fast float %5042, %5045
  %5047 = fsub fast float %5043, %5045
  %5048 = fsub fast float %5044, %5045
  %5049 = fmul fast float %5046, %8
  %5050 = fmul fast float %5047, %8
  %5051 = fmul fast float %5048, %8
  %5052 = fadd fast float %5049, %5045
  %5053 = fadd fast float %5050, %5045
  %5054 = fadd fast float %5051, %5045
  %5055 = call float @dx.op.unary.f32(i32 7, float %5052)  ; Saturate(value)
  %5056 = call float @dx.op.unary.f32(i32 7, float %5053)  ; Saturate(value)
  %5057 = call float @dx.op.unary.f32(i32 7, float %5054)  ; Saturate(value)
  %5058 = fadd fast float %5055, 0xBFC70A3D80000000
  %5059 = fadd fast float %5056, 0xBFC70A3D80000000
  %5060 = fadd fast float %5057, 0xBFC70A3D80000000
  %5061 = fmul fast float %5058, %7
  %5062 = fmul fast float %5059, %7
  %5063 = fmul fast float %5060, %7
  %5064 = fadd fast float %5061, 0x3FC70A3D80000000
  %5065 = fadd fast float %5062, 0x3FC70A3D80000000
  %5066 = fadd fast float %5063, 0x3FC70A3D80000000
  %5067 = call float @dx.op.unary.f32(i32 7, float %5064)  ; Saturate(value)
  %5068 = call float @dx.op.unary.f32(i32 7, float %5065)  ; Saturate(value)
  %5069 = call float @dx.op.unary.f32(i32 7, float %5066)  ; Saturate(value)
  br label %5070

; <label>:5070                                    ; preds = %5038, %4821
  %5071 = phi float [ %4852, %4821 ], [ %5067, %5038 ]
  %5072 = phi float [ %4853, %4821 ], [ %5068, %5038 ]
  %5073 = phi float [ %4854, %4821 ], [ %5069, %5038 ]
  %5074 = add i32 %1485, -1
  %5075 = call i32 @dx.op.binary.i32(i32 37, i32 %5074, i32 0)  ; IMax(a,b)
  %5076 = call i32 @dx.op.binary.i32(i32 37, i32 %2906, i32 0)  ; IMax(a,b)
  %5077 = call i32 @dx.op.binary.i32(i32 38, i32 %5075, i32 %59)  ; IMin(a,b)
  %5078 = call i32 @dx.op.binary.i32(i32 38, i32 %5076, i32 %60)  ; IMin(a,b)
  %5079 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %5077, i32 %5078, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5080 = extractvalue %dx.types.ResRet.f32 %5079, 0
  %5081 = extractvalue %dx.types.ResRet.f32 %5079, 1
  %5082 = extractvalue %dx.types.ResRet.f32 %5079, 2
  %5083 = extractvalue %dx.types.ResRet.f32 %5079, 3
  %5084 = fcmp fast olt float %5083, 0.000000e+00
  br i1 %5084, label %5085, label %5119

; <label>:5085                                    ; preds = %5070
  %5086 = fcmp fast ogt float %5080, 0x3FA4B5DCC0000000
  %5087 = fcmp fast ogt float %5081, 0x3FA4B5DCC0000000
  %5088 = fcmp fast ogt float %5082, 0x3FA4B5DCC0000000
  %5089 = select i1 %5086, float 0.000000e+00, float 1.000000e+00
  %5090 = select i1 %5087, float 0.000000e+00, float 1.000000e+00
  %5091 = select i1 %5088, float 0.000000e+00, float 1.000000e+00
  %5092 = fmul fast float %5080, 0x3FB3D07220000000
  %5093 = fmul fast float %5081, 0x3FB3D07220000000
  %5094 = fmul fast float %5082, 0x3FB3D07220000000
  %5095 = fadd fast float %5080, 0x3FAC28F5C0000000
  %5096 = fadd fast float %5081, 0x3FAC28F5C0000000
  %5097 = fadd fast float %5082, 0x3FAC28F5C0000000
  %5098 = fmul fast float %5095, 0x3FEE54EDE0000000
  %5099 = fmul fast float %5096, 0x3FEE54EDE0000000
  %5100 = fmul fast float %5097, 0x3FEE54EDE0000000
  %5101 = call float @dx.op.unary.f32(i32 23, float %5098)  ; Log(value)
  %5102 = call float @dx.op.unary.f32(i32 23, float %5099)  ; Log(value)
  %5103 = call float @dx.op.unary.f32(i32 23, float %5100)  ; Log(value)
  %5104 = fmul fast float %5101, 0x4003333340000000
  %5105 = fmul fast float %5102, 0x4003333340000000
  %5106 = fmul fast float %5103, 0x4003333340000000
  %5107 = call float @dx.op.unary.f32(i32 21, float %5104)  ; Exp(value)
  %5108 = call float @dx.op.unary.f32(i32 21, float %5105)  ; Exp(value)
  %5109 = call float @dx.op.unary.f32(i32 21, float %5106)  ; Exp(value)
  %5110 = fsub fast float %5092, %5107
  %5111 = fsub fast float %5093, %5108
  %5112 = fsub fast float %5094, %5109
  %5113 = fmul fast float %5110, %5089
  %5114 = fmul fast float %5111, %5090
  %5115 = fmul fast float %5112, %5091
  %5116 = fadd fast float %5113, %5107
  %5117 = fadd fast float %5114, %5108
  %5118 = fadd fast float %5115, %5109
  br label %5334

; <label>:5119                                    ; preds = %5070
  %5120 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5077, i32 %5078, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5121 = extractvalue %dx.types.ResRet.f32 %5120, 0
  %5122 = fcmp fast ogt float %38, 5.000000e-01
  %5123 = fcmp fast olt float %5121, 1.000000e+00
  %5124 = and i1 %5122, %5123
  br i1 %5124, label %5125, label %5263

; <label>:5125                                    ; preds = %5119
  %5126 = sitofp i32 %5077 to float
  %5127 = sitofp i32 %5078 to float
  %5128 = fadd fast float %5126, 5.000000e-01
  %5129 = fadd fast float %5127, 5.000000e-01
  %5130 = fdiv fast float %5128, %45
  %5131 = fdiv fast float %5129, %46
  %5132 = fmul fast float %5130, 2.000000e+00
  %5133 = fmul fast float %5131, 2.000000e+00
  %5134 = fadd fast float %5132, -1.000000e+00
  %5135 = fsub fast float 1.000000e+00, %5133
  %5136 = fmul fast float %5134, %35
  %5137 = call float @dx.op.tertiary.f32(i32 46, float %5135, float %31, float %5136)  ; FMad(a,b,c)
  %5138 = call float @dx.op.tertiary.f32(i32 46, float %5121, float %27, float %5137)  ; FMad(a,b,c)
  %5139 = fadd fast float %5138, %23
  %5140 = call float @dx.op.unary.f32(i32 6, float %5139)  ; FAbs(value)
  %5141 = fcmp fast ogt float %5140, 0x3EB0C6F7A0000000
  br i1 %5141, label %5142, label %5263

; <label>:5142                                    ; preds = %5125
  %5143 = fmul fast float %5134, %34
  %5144 = call float @dx.op.tertiary.f32(i32 46, float %5135, float %30, float %5143)  ; FMad(a,b,c)
  %5145 = call float @dx.op.tertiary.f32(i32 46, float %5121, float %26, float %5144)  ; FMad(a,b,c)
  %5146 = fadd fast float %5145, %22
  %5147 = fmul fast float %5134, %33
  %5148 = call float @dx.op.tertiary.f32(i32 46, float %5135, float %29, float %5147)  ; FMad(a,b,c)
  %5149 = call float @dx.op.tertiary.f32(i32 46, float %5121, float %25, float %5148)  ; FMad(a,b,c)
  %5150 = fadd fast float %5149, %21
  %5151 = fmul fast float %5134, %32
  %5152 = call float @dx.op.tertiary.f32(i32 46, float %5135, float %28, float %5151)  ; FMad(a,b,c)
  %5153 = call float @dx.op.tertiary.f32(i32 46, float %5121, float %24, float %5152)  ; FMad(a,b,c)
  %5154 = fadd fast float %5153, %20
  %5155 = fdiv fast float %5154, %5139
  %5156 = fdiv fast float %5150, %5139
  %5157 = fdiv fast float %5146, %5139
  %5158 = fsub fast float %5155, %17
  %5159 = fsub fast float %5156, %18
  %5160 = fsub fast float %5157, %19
  %5161 = fmul fast float %5158, %5158
  %5162 = fmul fast float %5159, %5159
  %5163 = fadd fast float %5162, %5161
  %5164 = fmul fast float %5160, %5160
  %5165 = fadd fast float %5163, %5164
  %5166 = call float @dx.op.unary.f32(i32 24, float %5165)  ; Sqrt(value)
  %5167 = fsub fast float %5166, %9
  %5168 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5167)  ; FMax(a,b)
  %5169 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %5169, label %5170, label %5193

; <label>:5170                                    ; preds = %5142
  %5171 = call float @dx.op.unary.f32(i32 6, float %5159)  ; FAbs(value)
  %5172 = fmul fast float %5171, %11
  %5173 = fcmp fast olt float %5172, 0x3F50624DE0000000
  br i1 %5173, label %5174, label %5177

; <label>:5174                                    ; preds = %5170
  %5175 = fmul fast float %5172, 5.000000e-01
  %5176 = fsub fast float 1.000000e+00, %5175
  br label %5182

; <label>:5177                                    ; preds = %5170
  %5178 = fmul fast float %5172, 0xBFF7154760000000
  %5179 = call float @dx.op.unary.f32(i32 21, float %5178)  ; Exp(value)
  %5180 = fsub fast float 1.000000e+00, %5179
  %5181 = fdiv fast float %5180, %5172
  br label %5182

; <label>:5182                                    ; preds = %5177, %5174
  %5183 = phi float [ %5176, %5174 ], [ %5181, %5177 ]
  %5184 = call float @dx.op.binary.f32(i32 36, float %5156, float %18)  ; FMin(a,b)
  %5185 = fsub fast float %5184, %10
  %5186 = fmul fast float %11, %5185
  %5187 = fsub fast float -0.000000e+00, %5186
  %5188 = call float @dx.op.binary.f32(i32 35, float %5187, float -4.000000e+01)  ; FMax(a,b)
  %5189 = call float @dx.op.binary.f32(i32 36, float %5188, float 5.000000e+00)  ; FMin(a,b)
  %5190 = fmul fast float %5189, 0x3FF7154760000000
  %5191 = call float @dx.op.unary.f32(i32 21, float %5190)  ; Exp(value)
  %5192 = fmul fast float %5191, %5183
  br label %5193

; <label>:5193                                    ; preds = %5182, %5142
  %5194 = phi float [ %5192, %5182 ], [ 1.000000e+00, %5142 ]
  %5195 = fmul fast float %5168, %16
  %5196 = fmul fast float %5195, %5194
  %5197 = fcmp fast ole float %5166, %9
  %5198 = fcmp fast olt float %5166, 0x3F1A36E2E0000000
  %5199 = or i1 %5197, %5198
  br i1 %5199, label %5246, label %5200

; <label>:5200                                    ; preds = %5193
  %5201 = fdiv fast float %9, %5166
  %5202 = fmul fast float %5201, %5158
  %5203 = fmul fast float %5201, %5159
  %5204 = fmul fast float %5201, %5160
  %5205 = fadd fast float %5202, %17
  %5206 = fadd fast float %5203, %18
  %5207 = fadd fast float %5204, %19
  %5208 = fadd fast float %5205, -9.000000e+02
  %5209 = fadd fast float %5206, -1.500000e+01
  %5210 = fadd fast float %5207, -7.500000e+02
  %5211 = fmul fast float %5208, 0x3F62345680000000
  %5212 = fmul fast float %5209, 0x3F62345680000000
  %5213 = fmul fast float %5210, 0x3F62345680000000
  %5214 = call float @dx.op.dot3.f32(i32 55, float %5211, float %5212, float %5213, float %5211, float %5212, float %5213)  ; Dot3(ax,ay,az,bx,by,bz)
  %5215 = fsub fast float 1.000000e+00, %5214
  %5216 = call float @dx.op.unary.f32(i32 7, float %5215)  ; Saturate(value)
  %5217 = fmul fast float %5216, %5216
  %5218 = fadd fast float %5205, %5155
  %5219 = fadd fast float %5206, %5156
  %5220 = fadd fast float %5207, %5157
  %5221 = fmul fast float %5218, 0x3F52345680000000
  %5222 = fadd fast float %5221, -2.000000e+00
  %5223 = fmul fast float %5219, 0x3F52345680000000
  %5224 = fadd fast float %5223, 0xBFA1111120000000
  %5225 = fmul fast float %5220, 0x3F52345680000000
  %5226 = fadd fast float %5225, 0xBFFAAAAAC0000000
  %5227 = call float @dx.op.dot3.f32(i32 55, float %5222, float %5224, float %5226, float %5222, float %5224, float %5226)  ; Dot3(ax,ay,az,bx,by,bz)
  %5228 = fsub fast float 1.000000e+00, %5227
  %5229 = call float @dx.op.unary.f32(i32 7, float %5228)  ; Saturate(value)
  %5230 = fmul fast float %5229, %5229
  %5231 = fmul fast float %5230, 4.000000e+00
  %5232 = fadd fast float %5231, %5217
  %5233 = fadd fast float %5155, -9.000000e+02
  %5234 = fadd fast float %5156, -1.500000e+01
  %5235 = fadd fast float %5157, -7.500000e+02
  %5236 = fmul fast float %5233, 0x3F62345680000000
  %5237 = fmul fast float %5234, 0x3F62345680000000
  %5238 = fmul fast float %5235, 0x3F62345680000000
  %5239 = call float @dx.op.dot3.f32(i32 55, float %5236, float %5237, float %5238, float %5236, float %5237, float %5238)  ; Dot3(ax,ay,az,bx,by,bz)
  %5240 = fsub fast float 1.000000e+00, %5239
  %5241 = call float @dx.op.unary.f32(i32 7, float %5240)  ; Saturate(value)
  %5242 = fmul fast float %5241, %5241
  %5243 = fadd fast float %5232, %5242
  %5244 = fmul fast float %5167, 0x3F25D867E0000000
  %5245 = fmul fast float %5244, %5243
  br label %5246

; <label>:5246                                    ; preds = %5200, %5193
  %5247 = phi float [ %5245, %5200 ], [ 0.000000e+00, %5193 ]
  %5248 = fadd fast float %5247, %5196
  %5249 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %5248)  ; FMin(a,b)
  %5250 = fmul fast float %5249, 0xBFF7154760000000
  %5251 = call float @dx.op.unary.f32(i32 21, float %5250)  ; Exp(value)
  %5252 = fsub fast float 1.000000e+00, %5251
  %5253 = call float @dx.op.binary.f32(i32 36, float %12, float %5252)  ; FMin(a,b)
  %5254 = fsub fast float %13, %5080
  %5255 = fsub fast float %14, %5081
  %5256 = fsub fast float %15, %5082
  %5257 = fmul fast float %5253, %5254
  %5258 = fmul fast float %5253, %5255
  %5259 = fmul fast float %5253, %5256
  %5260 = fadd fast float %5257, %5080
  %5261 = fadd fast float %5258, %5081
  %5262 = fadd fast float %5259, %5082
  br label %5263

; <label>:5263                                    ; preds = %5246, %5125, %5119
  %5264 = phi float [ %5260, %5246 ], [ %5080, %5125 ], [ %5080, %5119 ]
  %5265 = phi float [ %5261, %5246 ], [ %5081, %5125 ], [ %5081, %5119 ]
  %5266 = phi float [ %5262, %5246 ], [ %5082, %5125 ], [ %5082, %5119 ]
  %5267 = fadd fast float %5, 1.000000e+00
  %5268 = fadd fast float %6, 1.000000e+00
  %5269 = fsub fast float 1.000000e+00, %5
  %5270 = fmul fast float %36, %5267
  %5271 = fmul fast float %36, %5268
  %5272 = fmul fast float %36, %5269
  %5273 = fmul fast float %5270, %5264
  %5274 = fmul fast float %5271, %5265
  %5275 = fmul fast float %5272, %5266
  %5276 = fcmp fast ult float %37, 5.000000e-01
  br i1 %5276, label %5302, label %5277

; <label>:5277                                    ; preds = %5263
  %5278 = fmul fast float %5273, 0x4004147AE0000000
  %5279 = fmul fast float %5274, 0x4004147AE0000000
  %5280 = fmul fast float %5275, 0x4004147AE0000000
  %5281 = fadd fast float %5278, 0x3F9EB851E0000000
  %5282 = fadd fast float %5279, 0x3F9EB851E0000000
  %5283 = fadd fast float %5280, 0x3F9EB851E0000000
  %5284 = fmul fast float %5281, %5273
  %5285 = fmul fast float %5282, %5274
  %5286 = fmul fast float %5283, %5275
  %5287 = fmul fast float %5273, 0x400370A3E0000000
  %5288 = fmul fast float %5274, 0x400370A3E0000000
  %5289 = fmul fast float %5275, 0x400370A3E0000000
  %5290 = fadd fast float %5287, 0x3FE2E147A0000000
  %5291 = fadd fast float %5288, 0x3FE2E147A0000000
  %5292 = fadd fast float %5289, 0x3FE2E147A0000000
  %5293 = fmul fast float %5290, %5273
  %5294 = fmul fast float %5291, %5274
  %5295 = fmul fast float %5292, %5275
  %5296 = fadd fast float %5293, 0x3FC1EB8520000000
  %5297 = fadd fast float %5294, 0x3FC1EB8520000000
  %5298 = fadd fast float %5295, 0x3FC1EB8520000000
  %5299 = fdiv fast float %5284, %5296
  %5300 = fdiv fast float %5285, %5297
  %5301 = fdiv fast float %5286, %5298
  br label %5302

; <label>:5302                                    ; preds = %5277, %5263
  %5303 = phi float [ %5299, %5277 ], [ %5273, %5263 ]
  %5304 = phi float [ %5300, %5277 ], [ %5274, %5263 ]
  %5305 = phi float [ %5301, %5277 ], [ %5275, %5263 ]
  %5306 = call float @dx.op.unary.f32(i32 7, float %5303)  ; Saturate(value)
  %5307 = call float @dx.op.unary.f32(i32 7, float %5304)  ; Saturate(value)
  %5308 = call float @dx.op.unary.f32(i32 7, float %5305)  ; Saturate(value)
  %5309 = call float @dx.op.dot3.f32(i32 55, float %5306, float %5307, float %5308, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5310 = fsub fast float %5306, %5309
  %5311 = fsub fast float %5307, %5309
  %5312 = fsub fast float %5308, %5309
  %5313 = fmul fast float %5310, %8
  %5314 = fmul fast float %5311, %8
  %5315 = fmul fast float %5312, %8
  %5316 = fadd fast float %5313, %5309
  %5317 = fadd fast float %5314, %5309
  %5318 = fadd fast float %5315, %5309
  %5319 = call float @dx.op.unary.f32(i32 7, float %5316)  ; Saturate(value)
  %5320 = call float @dx.op.unary.f32(i32 7, float %5317)  ; Saturate(value)
  %5321 = call float @dx.op.unary.f32(i32 7, float %5318)  ; Saturate(value)
  %5322 = fadd fast float %5319, 0xBFC70A3D80000000
  %5323 = fadd fast float %5320, 0xBFC70A3D80000000
  %5324 = fadd fast float %5321, 0xBFC70A3D80000000
  %5325 = fmul fast float %5322, %7
  %5326 = fmul fast float %5323, %7
  %5327 = fmul fast float %5324, %7
  %5328 = fadd fast float %5325, 0x3FC70A3D80000000
  %5329 = fadd fast float %5326, 0x3FC70A3D80000000
  %5330 = fadd fast float %5327, 0x3FC70A3D80000000
  %5331 = call float @dx.op.unary.f32(i32 7, float %5328)  ; Saturate(value)
  %5332 = call float @dx.op.unary.f32(i32 7, float %5329)  ; Saturate(value)
  %5333 = call float @dx.op.unary.f32(i32 7, float %5330)  ; Saturate(value)
  br label %5334

; <label>:5334                                    ; preds = %5302, %5085
  %5335 = phi float [ %5116, %5085 ], [ %5331, %5302 ]
  %5336 = phi float [ %5117, %5085 ], [ %5332, %5302 ]
  %5337 = phi float [ %5118, %5085 ], [ %5333, %5302 ]
  %5338 = add i32 %1485, 1
  %5339 = call i32 @dx.op.binary.i32(i32 37, i32 %5338, i32 0)  ; IMax(a,b)
  %5340 = call i32 @dx.op.binary.i32(i32 38, i32 %5339, i32 %59)  ; IMin(a,b)
  %5341 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %2, i32 0, i32 %5340, i32 %5078, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5342 = extractvalue %dx.types.ResRet.f32 %5341, 0
  %5343 = extractvalue %dx.types.ResRet.f32 %5341, 1
  %5344 = extractvalue %dx.types.ResRet.f32 %5341, 2
  %5345 = extractvalue %dx.types.ResRet.f32 %5341, 3
  %5346 = fcmp fast olt float %5345, 0.000000e+00
  br i1 %5346, label %5347, label %5381

; <label>:5347                                    ; preds = %5334
  %5348 = fcmp fast ogt float %5342, 0x3FA4B5DCC0000000
  %5349 = fcmp fast ogt float %5343, 0x3FA4B5DCC0000000
  %5350 = fcmp fast ogt float %5344, 0x3FA4B5DCC0000000
  %5351 = select i1 %5348, float 0.000000e+00, float 1.000000e+00
  %5352 = select i1 %5349, float 0.000000e+00, float 1.000000e+00
  %5353 = select i1 %5350, float 0.000000e+00, float 1.000000e+00
  %5354 = fmul fast float %5342, 0x3FB3D07220000000
  %5355 = fmul fast float %5343, 0x3FB3D07220000000
  %5356 = fmul fast float %5344, 0x3FB3D07220000000
  %5357 = fadd fast float %5342, 0x3FAC28F5C0000000
  %5358 = fadd fast float %5343, 0x3FAC28F5C0000000
  %5359 = fadd fast float %5344, 0x3FAC28F5C0000000
  %5360 = fmul fast float %5357, 0x3FEE54EDE0000000
  %5361 = fmul fast float %5358, 0x3FEE54EDE0000000
  %5362 = fmul fast float %5359, 0x3FEE54EDE0000000
  %5363 = call float @dx.op.unary.f32(i32 23, float %5360)  ; Log(value)
  %5364 = call float @dx.op.unary.f32(i32 23, float %5361)  ; Log(value)
  %5365 = call float @dx.op.unary.f32(i32 23, float %5362)  ; Log(value)
  %5366 = fmul fast float %5363, 0x4003333340000000
  %5367 = fmul fast float %5364, 0x4003333340000000
  %5368 = fmul fast float %5365, 0x4003333340000000
  %5369 = call float @dx.op.unary.f32(i32 21, float %5366)  ; Exp(value)
  %5370 = call float @dx.op.unary.f32(i32 21, float %5367)  ; Exp(value)
  %5371 = call float @dx.op.unary.f32(i32 21, float %5368)  ; Exp(value)
  %5372 = fsub fast float %5354, %5369
  %5373 = fsub fast float %5355, %5370
  %5374 = fsub fast float %5356, %5371
  %5375 = fmul fast float %5372, %5351
  %5376 = fmul fast float %5373, %5352
  %5377 = fmul fast float %5374, %5353
  %5378 = fadd fast float %5375, %5369
  %5379 = fadd fast float %5376, %5370
  %5380 = fadd fast float %5377, %5371
  br label %5596

; <label>:5381                                    ; preds = %5334
  %5382 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5340, i32 %5078, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5383 = extractvalue %dx.types.ResRet.f32 %5382, 0
  %5384 = fcmp fast ogt float %38, 5.000000e-01
  %5385 = fcmp fast olt float %5383, 1.000000e+00
  %5386 = and i1 %5384, %5385
  br i1 %5386, label %5387, label %5525

; <label>:5387                                    ; preds = %5381
  %5388 = sitofp i32 %5340 to float
  %5389 = sitofp i32 %5078 to float
  %5390 = fadd fast float %5388, 5.000000e-01
  %5391 = fadd fast float %5389, 5.000000e-01
  %5392 = fdiv fast float %5390, %45
  %5393 = fdiv fast float %5391, %46
  %5394 = fmul fast float %5392, 2.000000e+00
  %5395 = fmul fast float %5393, 2.000000e+00
  %5396 = fadd fast float %5394, -1.000000e+00
  %5397 = fsub fast float 1.000000e+00, %5395
  %5398 = fmul fast float %5396, %35
  %5399 = call float @dx.op.tertiary.f32(i32 46, float %5397, float %31, float %5398)  ; FMad(a,b,c)
  %5400 = call float @dx.op.tertiary.f32(i32 46, float %5383, float %27, float %5399)  ; FMad(a,b,c)
  %5401 = fadd fast float %5400, %23
  %5402 = call float @dx.op.unary.f32(i32 6, float %5401)  ; FAbs(value)
  %5403 = fcmp fast ogt float %5402, 0x3EB0C6F7A0000000
  br i1 %5403, label %5404, label %5525

; <label>:5404                                    ; preds = %5387
  %5405 = fmul fast float %5396, %34
  %5406 = call float @dx.op.tertiary.f32(i32 46, float %5397, float %30, float %5405)  ; FMad(a,b,c)
  %5407 = call float @dx.op.tertiary.f32(i32 46, float %5383, float %26, float %5406)  ; FMad(a,b,c)
  %5408 = fadd fast float %5407, %22
  %5409 = fmul fast float %5396, %33
  %5410 = call float @dx.op.tertiary.f32(i32 46, float %5397, float %29, float %5409)  ; FMad(a,b,c)
  %5411 = call float @dx.op.tertiary.f32(i32 46, float %5383, float %25, float %5410)  ; FMad(a,b,c)
  %5412 = fadd fast float %5411, %21
  %5413 = fmul fast float %5396, %32
  %5414 = call float @dx.op.tertiary.f32(i32 46, float %5397, float %28, float %5413)  ; FMad(a,b,c)
  %5415 = call float @dx.op.tertiary.f32(i32 46, float %5383, float %24, float %5414)  ; FMad(a,b,c)
  %5416 = fadd fast float %5415, %20
  %5417 = fdiv fast float %5416, %5401
  %5418 = fdiv fast float %5412, %5401
  %5419 = fdiv fast float %5408, %5401
  %5420 = fsub fast float %5417, %17
  %5421 = fsub fast float %5418, %18
  %5422 = fsub fast float %5419, %19
  %5423 = fmul fast float %5420, %5420
  %5424 = fmul fast float %5421, %5421
  %5425 = fadd fast float %5424, %5423
  %5426 = fmul fast float %5422, %5422
  %5427 = fadd fast float %5425, %5426
  %5428 = call float @dx.op.unary.f32(i32 24, float %5427)  ; Sqrt(value)
  %5429 = fsub fast float %5428, %9
  %5430 = call float @dx.op.binary.f32(i32 35, float 0.000000e+00, float %5429)  ; FMax(a,b)
  %5431 = fcmp fast ogt float %39, 1.500000e+00
  br i1 %5431, label %5432, label %5455

; <label>:5432                                    ; preds = %5404
  %5433 = call float @dx.op.unary.f32(i32 6, float %5421)  ; FAbs(value)
  %5434 = fmul fast float %5433, %11
  %5435 = fcmp fast olt float %5434, 0x3F50624DE0000000
  br i1 %5435, label %5436, label %5439

; <label>:5436                                    ; preds = %5432
  %5437 = fmul fast float %5434, 5.000000e-01
  %5438 = fsub fast float 1.000000e+00, %5437
  br label %5444

; <label>:5439                                    ; preds = %5432
  %5440 = fmul fast float %5434, 0xBFF7154760000000
  %5441 = call float @dx.op.unary.f32(i32 21, float %5440)  ; Exp(value)
  %5442 = fsub fast float 1.000000e+00, %5441
  %5443 = fdiv fast float %5442, %5434
  br label %5444

; <label>:5444                                    ; preds = %5439, %5436
  %5445 = phi float [ %5438, %5436 ], [ %5443, %5439 ]
  %5446 = call float @dx.op.binary.f32(i32 36, float %5418, float %18)  ; FMin(a,b)
  %5447 = fsub fast float %5446, %10
  %5448 = fmul fast float %11, %5447
  %5449 = fsub fast float -0.000000e+00, %5448
  %5450 = call float @dx.op.binary.f32(i32 35, float %5449, float -4.000000e+01)  ; FMax(a,b)
  %5451 = call float @dx.op.binary.f32(i32 36, float %5450, float 5.000000e+00)  ; FMin(a,b)
  %5452 = fmul fast float %5451, 0x3FF7154760000000
  %5453 = call float @dx.op.unary.f32(i32 21, float %5452)  ; Exp(value)
  %5454 = fmul fast float %5453, %5445
  br label %5455

; <label>:5455                                    ; preds = %5444, %5404
  %5456 = phi float [ %5454, %5444 ], [ 1.000000e+00, %5404 ]
  %5457 = fmul fast float %5430, %16
  %5458 = fmul fast float %5457, %5456
  %5459 = fcmp fast ole float %5428, %9
  %5460 = fcmp fast olt float %5428, 0x3F1A36E2E0000000
  %5461 = or i1 %5459, %5460
  br i1 %5461, label %5508, label %5462

; <label>:5462                                    ; preds = %5455
  %5463 = fdiv fast float %9, %5428
  %5464 = fmul fast float %5463, %5420
  %5465 = fmul fast float %5463, %5421
  %5466 = fmul fast float %5463, %5422
  %5467 = fadd fast float %5464, %17
  %5468 = fadd fast float %5465, %18
  %5469 = fadd fast float %5466, %19
  %5470 = fadd fast float %5467, -9.000000e+02
  %5471 = fadd fast float %5468, -1.500000e+01
  %5472 = fadd fast float %5469, -7.500000e+02
  %5473 = fmul fast float %5470, 0x3F62345680000000
  %5474 = fmul fast float %5471, 0x3F62345680000000
  %5475 = fmul fast float %5472, 0x3F62345680000000
  %5476 = call float @dx.op.dot3.f32(i32 55, float %5473, float %5474, float %5475, float %5473, float %5474, float %5475)  ; Dot3(ax,ay,az,bx,by,bz)
  %5477 = fsub fast float 1.000000e+00, %5476
  %5478 = call float @dx.op.unary.f32(i32 7, float %5477)  ; Saturate(value)
  %5479 = fmul fast float %5478, %5478
  %5480 = fadd fast float %5467, %5417
  %5481 = fadd fast float %5468, %5418
  %5482 = fadd fast float %5469, %5419
  %5483 = fmul fast float %5480, 0x3F52345680000000
  %5484 = fadd fast float %5483, -2.000000e+00
  %5485 = fmul fast float %5481, 0x3F52345680000000
  %5486 = fadd fast float %5485, 0xBFA1111120000000
  %5487 = fmul fast float %5482, 0x3F52345680000000
  %5488 = fadd fast float %5487, 0xBFFAAAAAC0000000
  %5489 = call float @dx.op.dot3.f32(i32 55, float %5484, float %5486, float %5488, float %5484, float %5486, float %5488)  ; Dot3(ax,ay,az,bx,by,bz)
  %5490 = fsub fast float 1.000000e+00, %5489
  %5491 = call float @dx.op.unary.f32(i32 7, float %5490)  ; Saturate(value)
  %5492 = fmul fast float %5491, %5491
  %5493 = fmul fast float %5492, 4.000000e+00
  %5494 = fadd fast float %5493, %5479
  %5495 = fadd fast float %5417, -9.000000e+02
  %5496 = fadd fast float %5418, -1.500000e+01
  %5497 = fadd fast float %5419, -7.500000e+02
  %5498 = fmul fast float %5495, 0x3F62345680000000
  %5499 = fmul fast float %5496, 0x3F62345680000000
  %5500 = fmul fast float %5497, 0x3F62345680000000
  %5501 = call float @dx.op.dot3.f32(i32 55, float %5498, float %5499, float %5500, float %5498, float %5499, float %5500)  ; Dot3(ax,ay,az,bx,by,bz)
  %5502 = fsub fast float 1.000000e+00, %5501
  %5503 = call float @dx.op.unary.f32(i32 7, float %5502)  ; Saturate(value)
  %5504 = fmul fast float %5503, %5503
  %5505 = fadd fast float %5494, %5504
  %5506 = fmul fast float %5429, 0x3F25D867E0000000
  %5507 = fmul fast float %5506, %5505
  br label %5508

; <label>:5508                                    ; preds = %5462, %5455
  %5509 = phi float [ %5507, %5462 ], [ 0.000000e+00, %5455 ]
  %5510 = fadd fast float %5509, %5458
  %5511 = call float @dx.op.binary.f32(i32 36, float 8.000000e+01, float %5510)  ; FMin(a,b)
  %5512 = fmul fast float %5511, 0xBFF7154760000000
  %5513 = call float @dx.op.unary.f32(i32 21, float %5512)  ; Exp(value)
  %5514 = fsub fast float 1.000000e+00, %5513
  %5515 = call float @dx.op.binary.f32(i32 36, float %12, float %5514)  ; FMin(a,b)
  %5516 = fsub fast float %13, %5342
  %5517 = fsub fast float %14, %5343
  %5518 = fsub fast float %15, %5344
  %5519 = fmul fast float %5515, %5516
  %5520 = fmul fast float %5515, %5517
  %5521 = fmul fast float %5515, %5518
  %5522 = fadd fast float %5519, %5342
  %5523 = fadd fast float %5520, %5343
  %5524 = fadd fast float %5521, %5344
  br label %5525

; <label>:5525                                    ; preds = %5508, %5387, %5381
  %5526 = phi float [ %5522, %5508 ], [ %5342, %5387 ], [ %5342, %5381 ]
  %5527 = phi float [ %5523, %5508 ], [ %5343, %5387 ], [ %5343, %5381 ]
  %5528 = phi float [ %5524, %5508 ], [ %5344, %5387 ], [ %5344, %5381 ]
  %5529 = fadd fast float %5, 1.000000e+00
  %5530 = fadd fast float %6, 1.000000e+00
  %5531 = fsub fast float 1.000000e+00, %5
  %5532 = fmul fast float %36, %5529
  %5533 = fmul fast float %36, %5530
  %5534 = fmul fast float %36, %5531
  %5535 = fmul fast float %5532, %5526
  %5536 = fmul fast float %5533, %5527
  %5537 = fmul fast float %5534, %5528
  %5538 = fcmp fast ult float %37, 5.000000e-01
  br i1 %5538, label %5564, label %5539

; <label>:5539                                    ; preds = %5525
  %5540 = fmul fast float %5535, 0x4004147AE0000000
  %5541 = fmul fast float %5536, 0x4004147AE0000000
  %5542 = fmul fast float %5537, 0x4004147AE0000000
  %5543 = fadd fast float %5540, 0x3F9EB851E0000000
  %5544 = fadd fast float %5541, 0x3F9EB851E0000000
  %5545 = fadd fast float %5542, 0x3F9EB851E0000000
  %5546 = fmul fast float %5543, %5535
  %5547 = fmul fast float %5544, %5536
  %5548 = fmul fast float %5545, %5537
  %5549 = fmul fast float %5535, 0x400370A3E0000000
  %5550 = fmul fast float %5536, 0x400370A3E0000000
  %5551 = fmul fast float %5537, 0x400370A3E0000000
  %5552 = fadd fast float %5549, 0x3FE2E147A0000000
  %5553 = fadd fast float %5550, 0x3FE2E147A0000000
  %5554 = fadd fast float %5551, 0x3FE2E147A0000000
  %5555 = fmul fast float %5552, %5535
  %5556 = fmul fast float %5553, %5536
  %5557 = fmul fast float %5554, %5537
  %5558 = fadd fast float %5555, 0x3FC1EB8520000000
  %5559 = fadd fast float %5556, 0x3FC1EB8520000000
  %5560 = fadd fast float %5557, 0x3FC1EB8520000000
  %5561 = fdiv fast float %5546, %5558
  %5562 = fdiv fast float %5547, %5559
  %5563 = fdiv fast float %5548, %5560
  br label %5564

; <label>:5564                                    ; preds = %5539, %5525
  %5565 = phi float [ %5561, %5539 ], [ %5535, %5525 ]
  %5566 = phi float [ %5562, %5539 ], [ %5536, %5525 ]
  %5567 = phi float [ %5563, %5539 ], [ %5537, %5525 ]
  %5568 = call float @dx.op.unary.f32(i32 7, float %5565)  ; Saturate(value)
  %5569 = call float @dx.op.unary.f32(i32 7, float %5566)  ; Saturate(value)
  %5570 = call float @dx.op.unary.f32(i32 7, float %5567)  ; Saturate(value)
  %5571 = call float @dx.op.dot3.f32(i32 55, float %5568, float %5569, float %5570, float 0x3FCB367A00000000, float 0x3FE6E2EB20000000, float 0x3FB27BB300000000)  ; Dot3(ax,ay,az,bx,by,bz)
  %5572 = fsub fast float %5568, %5571
  %5573 = fsub fast float %5569, %5571
  %5574 = fsub fast float %5570, %5571
  %5575 = fmul fast float %5572, %8
  %5576 = fmul fast float %5573, %8
  %5577 = fmul fast float %5574, %8
  %5578 = fadd fast float %5575, %5571
  %5579 = fadd fast float %5576, %5571
  %5580 = fadd fast float %5577, %5571
  %5581 = call float @dx.op.unary.f32(i32 7, float %5578)  ; Saturate(value)
  %5582 = call float @dx.op.unary.f32(i32 7, float %5579)  ; Saturate(value)
  %5583 = call float @dx.op.unary.f32(i32 7, float %5580)  ; Saturate(value)
  %5584 = fadd fast float %5581, 0xBFC70A3D80000000
  %5585 = fadd fast float %5582, 0xBFC70A3D80000000
  %5586 = fadd fast float %5583, 0xBFC70A3D80000000
  %5587 = fmul fast float %5584, %7
  %5588 = fmul fast float %5585, %7
  %5589 = fmul fast float %5586, %7
  %5590 = fadd fast float %5587, 0x3FC70A3D80000000
  %5591 = fadd fast float %5588, 0x3FC70A3D80000000
  %5592 = fadd fast float %5589, 0x3FC70A3D80000000
  %5593 = call float @dx.op.unary.f32(i32 7, float %5590)  ; Saturate(value)
  %5594 = call float @dx.op.unary.f32(i32 7, float %5591)  ; Saturate(value)
  %5595 = call float @dx.op.unary.f32(i32 7, float %5592)  ; Saturate(value)
  br label %5596

; <label>:5596                                    ; preds = %5564, %5347
  %5597 = phi float [ %5378, %5347 ], [ %5593, %5564 ]
  %5598 = phi float [ %5379, %5347 ], [ %5594, %5564 ]
  %5599 = phi float [ %5380, %5347 ], [ %5595, %5564 ]
  %5600 = call float @dx.op.binary.f32(i32 36, float %5335, float %5597)  ; FMin(a,b)
  %5601 = call float @dx.op.binary.f32(i32 36, float %5336, float %5598)  ; FMin(a,b)
  %5602 = call float @dx.op.binary.f32(i32 36, float %5337, float %5599)  ; FMin(a,b)
  %5603 = call float @dx.op.binary.f32(i32 36, float %4809, float %5071)  ; FMin(a,b)
  %5604 = call float @dx.op.binary.f32(i32 36, float %4810, float %5072)  ; FMin(a,b)
  %5605 = call float @dx.op.binary.f32(i32 36, float %4811, float %5073)  ; FMin(a,b)
  %5606 = call float @dx.op.binary.f32(i32 36, float %5603, float %5600)  ; FMin(a,b)
  %5607 = call float @dx.op.binary.f32(i32 36, float %5604, float %5601)  ; FMin(a,b)
  %5608 = call float @dx.op.binary.f32(i32 36, float %5605, float %5602)  ; FMin(a,b)
  %5609 = call float @dx.op.binary.f32(i32 36, float %4545, float %5606)  ; FMin(a,b)
  %5610 = call float @dx.op.binary.f32(i32 36, float %4546, float %5607)  ; FMin(a,b)
  %5611 = call float @dx.op.binary.f32(i32 36, float %4547, float %5608)  ; FMin(a,b)
  %5612 = call float @dx.op.binary.f32(i32 35, float %5335, float %5597)  ; FMax(a,b)
  %5613 = call float @dx.op.binary.f32(i32 35, float %5336, float %5598)  ; FMax(a,b)
  %5614 = call float @dx.op.binary.f32(i32 35, float %5337, float %5599)  ; FMax(a,b)
  %5615 = call float @dx.op.binary.f32(i32 35, float %4809, float %5071)  ; FMax(a,b)
  %5616 = call float @dx.op.binary.f32(i32 35, float %4810, float %5072)  ; FMax(a,b)
  %5617 = call float @dx.op.binary.f32(i32 35, float %4811, float %5073)  ; FMax(a,b)
  %5618 = call float @dx.op.binary.f32(i32 35, float %5615, float %5612)  ; FMax(a,b)
  %5619 = call float @dx.op.binary.f32(i32 35, float %5616, float %5613)  ; FMax(a,b)
  %5620 = call float @dx.op.binary.f32(i32 35, float %5617, float %5614)  ; FMax(a,b)
  %5621 = call float @dx.op.binary.f32(i32 35, float %4545, float %5618)  ; FMax(a,b)
  %5622 = call float @dx.op.binary.f32(i32 35, float %4546, float %5619)  ; FMax(a,b)
  %5623 = call float @dx.op.binary.f32(i32 35, float %4547, float %5620)  ; FMax(a,b)
  %5624 = fsub fast float %5621, %5609
  %5625 = fsub fast float %5622, %5610
  %5626 = fsub fast float %5623, %5611
  %5627 = call float @dx.op.unary.f32(i32 6, float %5624)  ; FAbs(value)
  %5628 = call float @dx.op.unary.f32(i32 6, float %5625)  ; FAbs(value)
  %5629 = call float @dx.op.unary.f32(i32 6, float %5626)  ; FAbs(value)
  %5630 = call float @dx.op.binary.f32(i32 35, float %5628, float %5629)  ; FMax(a,b)
  %5631 = call float @dx.op.binary.f32(i32 35, float %5627, float %5630)  ; FMax(a,b)
  %5632 = call float @dx.op.binary.f32(i32 35, float %5622, float %5623)  ; FMax(a,b)
  %5633 = call float @dx.op.binary.f32(i32 35, float %5621, float %5632)  ; FMax(a,b)
  %5634 = fmul fast float %5633, 1.250000e-01
  %5635 = call float @dx.op.binary.f32(i32 35, float 0x3F999999A0000000, float %5634)  ; FMax(a,b)
  %5636 = fcmp fast ogt float %5631, %5635
  br i1 %5636, label %5637, label %5698

; <label>:5637                                    ; preds = %5596
  %5638 = fsub fast float %4809, %5071
  %5639 = fsub fast float %4810, %5072
  %5640 = fsub fast float %4811, %5073
  %5641 = call float @dx.op.unary.f32(i32 6, float %5638)  ; FAbs(value)
  %5642 = call float @dx.op.unary.f32(i32 6, float %5639)  ; FAbs(value)
  %5643 = call float @dx.op.unary.f32(i32 6, float %5640)  ; FAbs(value)
  %5644 = call float @dx.op.binary.f32(i32 35, float %5642, float %5643)  ; FMax(a,b)
  %5645 = call float @dx.op.binary.f32(i32 35, float %5641, float %5644)  ; FMax(a,b)
  %5646 = fsub fast float %5335, %5597
  %5647 = fsub fast float %5336, %5598
  %5648 = fsub fast float %5337, %5599
  %5649 = call float @dx.op.unary.f32(i32 6, float %5646)  ; FAbs(value)
  %5650 = call float @dx.op.unary.f32(i32 6, float %5647)  ; FAbs(value)
  %5651 = call float @dx.op.unary.f32(i32 6, float %5648)  ; FAbs(value)
  %5652 = call float @dx.op.binary.f32(i32 35, float %5650, float %5651)  ; FMax(a,b)
  %5653 = call float @dx.op.binary.f32(i32 35, float %5649, float %5652)  ; FMax(a,b)
  %5654 = fcmp fast olt float %5645, %5653
  %5655 = select i1 %5654, float %4809, float %5335
  %5656 = select i1 %5654, float %4810, float %5336
  %5657 = select i1 %5654, float %4811, float %5337
  %5658 = select i1 %5654, float %5071, float %5597
  %5659 = select i1 %5654, float %5072, float %5598
  %5660 = select i1 %5654, float %5073, float %5599
  %5661 = fsub fast float %4545, %5658
  %5662 = fsub fast float %4546, %5659
  %5663 = fsub fast float %4547, %5660
  %5664 = fsub fast float %4545, %5655
  %5665 = fsub fast float %4546, %5656
  %5666 = fsub fast float %4547, %5657
  %5667 = call float @dx.op.dot3.f32(i32 55, float %5664, float %5665, float %5666, float %5661, float %5662, float %5663)  ; Dot3(ax,ay,az,bx,by,bz)
  %5668 = fcmp fast ogt float %5667, 0.000000e+00
  br i1 %5668, label %5669, label %5681

; <label>:5669                                    ; preds = %5637
  %5670 = fsub fast float %5655, %5658
  %5671 = fsub fast float %5656, %5659
  %5672 = fsub fast float %5657, %5660
  %5673 = call float @dx.op.unary.f32(i32 6, float %5670)  ; FAbs(value)
  %5674 = call float @dx.op.unary.f32(i32 6, float %5671)  ; FAbs(value)
  %5675 = call float @dx.op.unary.f32(i32 6, float %5672)  ; FAbs(value)
  %5676 = call float @dx.op.binary.f32(i32 35, float %5674, float %5675)  ; FMax(a,b)
  %5677 = call float @dx.op.binary.f32(i32 35, float %5673, float %5676)  ; FMax(a,b)
  %5678 = fmul fast float %5631, 2.500000e-01
  %5679 = fcmp fast olt float %5677, %5678
  %5680 = select i1 %5679, float 0x3FB99999A0000000, float 0x3FC99999A0000000
  br label %5681

; <label>:5681                                    ; preds = %5669, %5637
  %5682 = phi float [ 0x3FC99999A0000000, %5637 ], [ %5680, %5669 ]
  %5683 = fadd fast float %5655, %5658
  %5684 = fadd fast float %5656, %5659
  %5685 = fadd fast float %5657, %5660
  %5686 = fmul fast float %5683, 5.000000e-01
  %5687 = fmul fast float %5684, 5.000000e-01
  %5688 = fmul fast float %5685, 5.000000e-01
  %5689 = fsub fast float %5686, %4545
  %5690 = fsub fast float %5687, %4546
  %5691 = fsub fast float %5688, %4547
  %5692 = fmul fast float %5682, %5689
  %5693 = fmul fast float %5682, %5690
  %5694 = fmul fast float %5682, %5691
  %5695 = fadd fast float %5692, %4545
  %5696 = fadd fast float %5693, %4546
  %5697 = fadd fast float %5694, %4547
  br label %5698

; <label>:5698                                    ; preds = %5681, %5596
  %5699 = phi float [ %5695, %5681 ], [ %4545, %5596 ]
  %5700 = phi float [ %5696, %5681 ], [ %4546, %5596 ]
  %5701 = phi float [ %5697, %5681 ], [ %4547, %5596 ]
  %5702 = fcmp fast ogt float %5699, 0x3F69A5C380000000
  %5703 = fcmp fast ogt float %5700, 0x3F69A5C380000000
  %5704 = fcmp fast ogt float %5701, 0x3F69A5C380000000
  %5705 = select i1 %5702, float 0.000000e+00, float 1.000000e+00
  %5706 = select i1 %5703, float 0.000000e+00, float 1.000000e+00
  %5707 = select i1 %5704, float 0.000000e+00, float 1.000000e+00
  %5708 = fmul fast float %5699, 0x4029D70A40000000
  %5709 = fmul fast float %5700, 0x4029D70A40000000
  %5710 = fmul fast float %5701, 0x4029D70A40000000
  %5711 = call float @dx.op.binary.f32(i32 35, float %5699, float 0.000000e+00)  ; FMax(a,b)
  %5712 = call float @dx.op.binary.f32(i32 35, float %5700, float 0.000000e+00)  ; FMax(a,b)
  %5713 = call float @dx.op.binary.f32(i32 35, float %5701, float 0.000000e+00)  ; FMax(a,b)
  %5714 = call float @dx.op.unary.f32(i32 23, float %5711)  ; Log(value)
  %5715 = call float @dx.op.unary.f32(i32 23, float %5712)  ; Log(value)
  %5716 = call float @dx.op.unary.f32(i32 23, float %5713)  ; Log(value)
  %5717 = fmul fast float %5714, 0x3FDAAAAAA0000000
  %5718 = fmul fast float %5715, 0x3FDAAAAAA0000000
  %5719 = fmul fast float %5716, 0x3FDAAAAAA0000000
  %5720 = call float @dx.op.unary.f32(i32 21, float %5717)  ; Exp(value)
  %5721 = call float @dx.op.unary.f32(i32 21, float %5718)  ; Exp(value)
  %5722 = call float @dx.op.unary.f32(i32 21, float %5719)  ; Exp(value)
  %5723 = fmul fast float %5720, 0x3FF0E147A0000000
  %5724 = fmul fast float %5721, 0x3FF0E147A0000000
  %5725 = fmul fast float %5722, 0x3FF0E147A0000000
  %5726 = fadd fast float %5723, 0xBFAC28F5C0000000
  %5727 = fadd fast float %5724, 0xBFAC28F5C0000000
  %5728 = fadd fast float %5725, 0xBFAC28F5C0000000
  %5729 = fsub fast float %5708, %5726
  %5730 = fsub fast float %5709, %5727
  %5731 = fsub fast float %5710, %5728
  %5732 = fmul fast float %5729, %5705
  %5733 = fmul fast float %5730, %5706
  %5734 = fmul fast float %5731, %5707
  %5735 = fadd fast float %5732, %5726
  %5736 = fadd fast float %5733, %5727
  %5737 = fadd fast float %5734, %5728
  br label %5738

; <label>:5738                                    ; preds = %5698, %4331
  %5739 = phi float [ %4326, %4331 ], [ %5735, %5698 ]
  %5740 = phi float [ %4327, %4331 ], [ %5736, %5698 ]
  %5741 = phi float [ %4328, %4331 ], [ %5737, %5698 ]
  %5742 = phi float [ %4332, %4331 ], [ %4329, %5698 ]
  %5743 = call float @dx.op.unary.f32(i32 27, float %49)  ; Round_ni(value)
  %5744 = call float @dx.op.unary.f32(i32 27, float %50)  ; Round_ni(value)
  %5745 = fptosi float %5743 to i32
  %5746 = fptosi float %5744 to i32
  %5747 = call i32 @dx.op.binary.i32(i32 37, i32 %5745, i32 0)  ; IMax(a,b)
  %5748 = call i32 @dx.op.binary.i32(i32 37, i32 %5746, i32 0)  ; IMax(a,b)
  %5749 = call i32 @dx.op.binary.i32(i32 38, i32 %5747, i32 %59)  ; IMin(a,b)
  %5750 = call i32 @dx.op.binary.i32(i32 38, i32 %5748, i32 %60)  ; IMin(a,b)
  %5751 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %5749, i32 %5750, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5752 = extractvalue %dx.types.ResRet.f32 %5751, 0
  %5753 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5754 = extractvalue %dx.types.ResRet.f32 %5753, 0
  %5755 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1485, i32 %64, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5756 = extractvalue %dx.types.ResRet.f32 %5755, 0
  %5757 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %63, i32 %2906, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5758 = extractvalue %dx.types.ResRet.f32 %5757, 0
  %5759 = call %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32 66, %dx.types.Handle %1, i32 0, i32 %1485, i32 %2906, i32 undef, i32 undef, i32 undef, i32 undef)  ; TextureLoad(srv,mipLevelOrSampleCount,coord0,coord1,coord2,offset0,offset1,offset2)
  %5760 = extractvalue %dx.types.ResRet.f32 %5759, 0
  %5761 = fsub fast float 1.000000e+00, %57
  %5762 = fsub fast float 1.000000e+00, %58
  %5763 = fmul fast float %5762, %5761
  %5764 = fmul fast float %5762, %57
  %5765 = fmul fast float %5761, %58
  %5766 = fmul fast float %58, %57
  %5767 = fsub fast float 1.000000e+00, %5752
  %5768 = fmul fast float %5767, 0x3FA99999A0000000
  %5769 = call float @dx.op.binary.f32(i32 35, float 0x3EE4F8B580000000, float %5768)  ; FMax(a,b)
  %5770 = fsub fast float %5754, %5752
  %5771 = fsub fast float %5756, %5752
  %5772 = fsub fast float %5758, %5752
  %5773 = fsub fast float %5760, %5752
  %5774 = call float @dx.op.unary.f32(i32 6, float %5770)  ; FAbs(value)
  %5775 = call float @dx.op.unary.f32(i32 6, float %5771)  ; FAbs(value)
  %5776 = call float @dx.op.unary.f32(i32 6, float %5772)  ; FAbs(value)
  %5777 = call float @dx.op.unary.f32(i32 6, float %5773)  ; FAbs(value)
  %5778 = fdiv fast float %5774, %5769
  %5779 = fdiv fast float %5775, %5769
  %5780 = fdiv fast float %5776, %5769
  %5781 = fdiv fast float %5777, %5769
  %5782 = fsub fast float 1.000000e+00, %5778
  %5783 = fsub fast float 1.000000e+00, %5779
  %5784 = fsub fast float 1.000000e+00, %5780
  %5785 = fsub fast float 1.000000e+00, %5781
  %5786 = call float @dx.op.unary.f32(i32 7, float %5782)  ; Saturate(value)
  %5787 = call float @dx.op.unary.f32(i32 7, float %5783)  ; Saturate(value)
  %5788 = call float @dx.op.unary.f32(i32 7, float %5784)  ; Saturate(value)
  %5789 = call float @dx.op.unary.f32(i32 7, float %5785)  ; Saturate(value)
  %5790 = fmul fast float %5763, %5786
  %5791 = fmul fast float %5764, %5787
  %5792 = fmul fast float %5765, %5788
  %5793 = fmul fast float %5766, %5789
  %5794 = call float @dx.op.dot4.f32(i32 56, float %5790, float %5791, float %5792, float %5793, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00, float 1.000000e+00)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  %5795 = call float @dx.op.binary.f32(i32 35, float %5794, float 0x3EE4F8B580000000)  ; FMax(a,b)
  %5796 = fdiv fast float %5790, %5795
  %5797 = fdiv fast float %5791, %5795
  %5798 = fdiv fast float %5792, %5795
  %5799 = fdiv fast float %5793, %5795
  %5800 = fcmp fast ogt float %1479, 0x3FA4B5DCC0000000
  %5801 = fcmp fast ogt float %1480, 0x3FA4B5DCC0000000
  %5802 = fcmp fast ogt float %1481, 0x3FA4B5DCC0000000
  %5803 = select i1 %5800, float 0.000000e+00, float 1.000000e+00
  %5804 = select i1 %5801, float 0.000000e+00, float 1.000000e+00
  %5805 = select i1 %5802, float 0.000000e+00, float 1.000000e+00
  %5806 = fmul fast float %1479, 0x3FB3D07220000000
  %5807 = fmul fast float %1480, 0x3FB3D07220000000
  %5808 = fmul fast float %1481, 0x3FB3D07220000000
  %5809 = fadd fast float %1479, 0x3FAC28F5C0000000
  %5810 = fadd fast float %1480, 0x3FAC28F5C0000000
  %5811 = fadd fast float %1481, 0x3FAC28F5C0000000
  %5812 = fmul fast float %5809, 0x3FEE54EDE0000000
  %5813 = fmul fast float %5810, 0x3FEE54EDE0000000
  %5814 = fmul fast float %5811, 0x3FEE54EDE0000000
  %5815 = call float @dx.op.unary.f32(i32 23, float %5812)  ; Log(value)
  %5816 = call float @dx.op.unary.f32(i32 23, float %5813)  ; Log(value)
  %5817 = call float @dx.op.unary.f32(i32 23, float %5814)  ; Log(value)
  %5818 = fmul fast float %5815, 0x4003333340000000
  %5819 = fmul fast float %5816, 0x4003333340000000
  %5820 = fmul fast float %5817, 0x4003333340000000
  %5821 = call float @dx.op.unary.f32(i32 21, float %5818)  ; Exp(value)
  %5822 = call float @dx.op.unary.f32(i32 21, float %5819)  ; Exp(value)
  %5823 = call float @dx.op.unary.f32(i32 21, float %5820)  ; Exp(value)
  %5824 = fsub fast float %5806, %5821
  %5825 = fsub fast float %5807, %5822
  %5826 = fsub fast float %5808, %5823
  %5827 = fmul fast float %5824, %5803
  %5828 = fmul fast float %5825, %5804
  %5829 = fmul fast float %5826, %5805
  %5830 = fadd fast float %5827, %5821
  %5831 = fadd fast float %5828, %5822
  %5832 = fadd fast float %5829, %5823
  %5833 = fmul fast float %5830, %5796
  %5834 = fmul fast float %5831, %5796
  %5835 = fmul fast float %5832, %5796
  %5836 = fcmp fast ogt float %2900, 0x3FA4B5DCC0000000
  %5837 = fcmp fast ogt float %2901, 0x3FA4B5DCC0000000
  %5838 = fcmp fast ogt float %2902, 0x3FA4B5DCC0000000
  %5839 = select i1 %5836, float 0.000000e+00, float 1.000000e+00
  %5840 = select i1 %5837, float 0.000000e+00, float 1.000000e+00
  %5841 = select i1 %5838, float 0.000000e+00, float 1.000000e+00
  %5842 = fmul fast float %2900, 0x3FB3D07220000000
  %5843 = fmul fast float %2901, 0x3FB3D07220000000
  %5844 = fmul fast float %2902, 0x3FB3D07220000000
  %5845 = fadd fast float %2900, 0x3FAC28F5C0000000
  %5846 = fadd fast float %2901, 0x3FAC28F5C0000000
  %5847 = fadd fast float %2902, 0x3FAC28F5C0000000
  %5848 = fmul fast float %5845, 0x3FEE54EDE0000000
  %5849 = fmul fast float %5846, 0x3FEE54EDE0000000
  %5850 = fmul fast float %5847, 0x3FEE54EDE0000000
  %5851 = call float @dx.op.unary.f32(i32 23, float %5848)  ; Log(value)
  %5852 = call float @dx.op.unary.f32(i32 23, float %5849)  ; Log(value)
  %5853 = call float @dx.op.unary.f32(i32 23, float %5850)  ; Log(value)
  %5854 = fmul fast float %5851, 0x4003333340000000
  %5855 = fmul fast float %5852, 0x4003333340000000
  %5856 = fmul fast float %5853, 0x4003333340000000
  %5857 = call float @dx.op.unary.f32(i32 21, float %5854)  ; Exp(value)
  %5858 = call float @dx.op.unary.f32(i32 21, float %5855)  ; Exp(value)
  %5859 = call float @dx.op.unary.f32(i32 21, float %5856)  ; Exp(value)
  %5860 = fsub fast float %5842, %5857
  %5861 = fsub fast float %5843, %5858
  %5862 = fsub fast float %5844, %5859
  %5863 = fmul fast float %5860, %5839
  %5864 = fmul fast float %5861, %5840
  %5865 = fmul fast float %5862, %5841
  %5866 = fadd fast float %5863, %5857
  %5867 = fadd fast float %5864, %5858
  %5868 = fadd fast float %5865, %5859
  %5869 = fmul fast float %5866, %5797
  %5870 = fmul fast float %5867, %5797
  %5871 = fmul fast float %5868, %5797
  %5872 = fadd fast float %5869, %5833
  %5873 = fadd fast float %5870, %5834
  %5874 = fadd fast float %5871, %5835
  %5875 = fcmp fast ogt float %4321, 0x3FA4B5DCC0000000
  %5876 = fcmp fast ogt float %4322, 0x3FA4B5DCC0000000
  %5877 = fcmp fast ogt float %4323, 0x3FA4B5DCC0000000
  %5878 = select i1 %5875, float 0.000000e+00, float 1.000000e+00
  %5879 = select i1 %5876, float 0.000000e+00, float 1.000000e+00
  %5880 = select i1 %5877, float 0.000000e+00, float 1.000000e+00
  %5881 = fmul fast float %4321, 0x3FB3D07220000000
  %5882 = fmul fast float %4322, 0x3FB3D07220000000
  %5883 = fmul fast float %4323, 0x3FB3D07220000000
  %5884 = fadd fast float %4321, 0x3FAC28F5C0000000
  %5885 = fadd fast float %4322, 0x3FAC28F5C0000000
  %5886 = fadd fast float %4323, 0x3FAC28F5C0000000
  %5887 = fmul fast float %5884, 0x3FEE54EDE0000000
  %5888 = fmul fast float %5885, 0x3FEE54EDE0000000
  %5889 = fmul fast float %5886, 0x3FEE54EDE0000000
  %5890 = call float @dx.op.unary.f32(i32 23, float %5887)  ; Log(value)
  %5891 = call float @dx.op.unary.f32(i32 23, float %5888)  ; Log(value)
  %5892 = call float @dx.op.unary.f32(i32 23, float %5889)  ; Log(value)
  %5893 = fmul fast float %5890, 0x4003333340000000
  %5894 = fmul fast float %5891, 0x4003333340000000
  %5895 = fmul fast float %5892, 0x4003333340000000
  %5896 = call float @dx.op.unary.f32(i32 21, float %5893)  ; Exp(value)
  %5897 = call float @dx.op.unary.f32(i32 21, float %5894)  ; Exp(value)
  %5898 = call float @dx.op.unary.f32(i32 21, float %5895)  ; Exp(value)
  %5899 = fsub fast float %5881, %5896
  %5900 = fsub fast float %5882, %5897
  %5901 = fsub fast float %5883, %5898
  %5902 = fmul fast float %5899, %5878
  %5903 = fmul fast float %5900, %5879
  %5904 = fmul fast float %5901, %5880
  %5905 = fadd fast float %5902, %5896
  %5906 = fadd fast float %5903, %5897
  %5907 = fadd fast float %5904, %5898
  %5908 = fmul fast float %5905, %5798
  %5909 = fmul fast float %5906, %5798
  %5910 = fmul fast float %5907, %5798
  %5911 = fadd fast float %5872, %5908
  %5912 = fadd fast float %5873, %5909
  %5913 = fadd fast float %5874, %5910
  %5914 = fcmp fast ogt float %5739, 0x3FA4B5DCC0000000
  %5915 = fcmp fast ogt float %5740, 0x3FA4B5DCC0000000
  %5916 = fcmp fast ogt float %5741, 0x3FA4B5DCC0000000
  %5917 = select i1 %5914, float 0.000000e+00, float 1.000000e+00
  %5918 = select i1 %5915, float 0.000000e+00, float 1.000000e+00
  %5919 = select i1 %5916, float 0.000000e+00, float 1.000000e+00
  %5920 = fmul fast float %5739, 0x3FB3D07220000000
  %5921 = fmul fast float %5740, 0x3FB3D07220000000
  %5922 = fmul fast float %5741, 0x3FB3D07220000000
  %5923 = fadd fast float %5739, 0x3FAC28F5C0000000
  %5924 = fadd fast float %5740, 0x3FAC28F5C0000000
  %5925 = fadd fast float %5741, 0x3FAC28F5C0000000
  %5926 = fmul fast float %5923, 0x3FEE54EDE0000000
  %5927 = fmul fast float %5924, 0x3FEE54EDE0000000
  %5928 = fmul fast float %5925, 0x3FEE54EDE0000000
  %5929 = call float @dx.op.unary.f32(i32 23, float %5926)  ; Log(value)
  %5930 = call float @dx.op.unary.f32(i32 23, float %5927)  ; Log(value)
  %5931 = call float @dx.op.unary.f32(i32 23, float %5928)  ; Log(value)
  %5932 = fmul fast float %5929, 0x4003333340000000
  %5933 = fmul fast float %5930, 0x4003333340000000
  %5934 = fmul fast float %5931, 0x4003333340000000
  %5935 = call float @dx.op.unary.f32(i32 21, float %5932)  ; Exp(value)
  %5936 = call float @dx.op.unary.f32(i32 21, float %5933)  ; Exp(value)
  %5937 = call float @dx.op.unary.f32(i32 21, float %5934)  ; Exp(value)
  %5938 = fsub fast float %5920, %5935
  %5939 = fsub fast float %5921, %5936
  %5940 = fsub fast float %5922, %5937
  %5941 = fmul fast float %5938, %5917
  %5942 = fmul fast float %5939, %5918
  %5943 = fmul fast float %5940, %5919
  %5944 = fadd fast float %5941, %5935
  %5945 = fadd fast float %5942, %5936
  %5946 = fadd fast float %5943, %5937
  %5947 = fmul fast float %5944, %5799
  %5948 = fmul fast float %5945, %5799
  %5949 = fmul fast float %5946, %5799
  %5950 = fadd fast float %5911, %5947
  %5951 = fadd fast float %5912, %5948
  %5952 = fadd fast float %5913, %5949
  %5953 = fcmp fast ogt float %5950, 0x3F69A5C380000000
  %5954 = fcmp fast ogt float %5951, 0x3F69A5C380000000
  %5955 = fcmp fast ogt float %5952, 0x3F69A5C380000000
  %5956 = select i1 %5953, float 0.000000e+00, float 1.000000e+00
  %5957 = select i1 %5954, float 0.000000e+00, float 1.000000e+00
  %5958 = select i1 %5955, float 0.000000e+00, float 1.000000e+00
  %5959 = fmul fast float %5950, 0x4029D70A40000000
  %5960 = fmul fast float %5951, 0x4029D70A40000000
  %5961 = fmul fast float %5952, 0x4029D70A40000000
  %5962 = call float @dx.op.binary.f32(i32 35, float %5950, float 0.000000e+00)  ; FMax(a,b)
  %5963 = call float @dx.op.binary.f32(i32 35, float %5951, float 0.000000e+00)  ; FMax(a,b)
  %5964 = call float @dx.op.binary.f32(i32 35, float %5952, float 0.000000e+00)  ; FMax(a,b)
  %5965 = call float @dx.op.unary.f32(i32 23, float %5962)  ; Log(value)
  %5966 = call float @dx.op.unary.f32(i32 23, float %5963)  ; Log(value)
  %5967 = call float @dx.op.unary.f32(i32 23, float %5964)  ; Log(value)
  %5968 = fmul fast float %5965, 0x3FDAAAAAA0000000
  %5969 = fmul fast float %5966, 0x3FDAAAAAA0000000
  %5970 = fmul fast float %5967, 0x3FDAAAAAA0000000
  %5971 = call float @dx.op.unary.f32(i32 21, float %5968)  ; Exp(value)
  %5972 = call float @dx.op.unary.f32(i32 21, float %5969)  ; Exp(value)
  %5973 = call float @dx.op.unary.f32(i32 21, float %5970)  ; Exp(value)
  %5974 = fmul fast float %5971, 0x3FF0E147A0000000
  %5975 = fmul fast float %5972, 0x3FF0E147A0000000
  %5976 = fmul fast float %5973, 0x3FF0E147A0000000
  %5977 = fadd fast float %5974, 0xBFAC28F5C0000000
  %5978 = fadd fast float %5975, 0xBFAC28F5C0000000
  %5979 = fadd fast float %5976, 0xBFAC28F5C0000000
  %5980 = fsub fast float %5959, %5977
  %5981 = fsub fast float %5960, %5978
  %5982 = fsub fast float %5961, %5979
  %5983 = fmul fast float %5980, %5956
  %5984 = fmul fast float %5981, %5957
  %5985 = fmul fast float %5982, %5958
  %5986 = fadd fast float %5983, %5977
  %5987 = fadd fast float %5984, %5978
  %5988 = fadd fast float %5985, %5979
  %5989 = call float @dx.op.dot4.f32(i32 56, float %1482, float %2903, float %4324, float %5742, float %5796, float %5797, float %5798, float %5799)  ; Dot4(ax,ay,az,aw,bx,by,bz,bw)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 0, float %5986)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 1, float %5987)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 2, float %5988)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 0, i32 0, i8 3, float %5989)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  call void @dx.op.storeOutput.f32(i32 5, i32 1, i32 0, i8 0, float %5752)  ; StoreOutput(outputSigId,rowIndex,colIndex,value)
  ret void
}

; Function Attrs: nounwind readnone
declare float @dx.op.loadInput.f32(i32, i32, i32, i8, i32) #0

; Function Attrs: nounwind
declare void @dx.op.storeOutput.f32(i32, i32, i32, i8, float) #1

; Function Attrs: nounwind readonly
declare %dx.types.Dimensions @dx.op.getDimensions(i32, %dx.types.Handle, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.unary.f32(i32, float) #0

; Function Attrs: nounwind readnone
declare i32 @dx.op.binary.i32(i32, i32, i32) #0

; Function Attrs: nounwind readonly
declare %dx.types.ResRet.f32 @dx.op.textureLoad.f32(i32, %dx.types.Handle, i32, i32, i32, i32, i32, i32, i32) #2

; Function Attrs: nounwind readnone
declare float @dx.op.binary.f32(i32, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot4.f32(i32, float, float, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.dot3.f32(i32, float, float, float, float, float, float) #0

; Function Attrs: nounwind readnone
declare float @dx.op.tertiary.f32(i32, float, float, float) #0

; Function Attrs: nounwind readonly
declare %dx.types.Handle @dx.op.createHandle(i32, i8, i32, i32, i1) #2

attributes #0 = { nounwind readnone }
attributes #1 = { nounwind }
attributes #2 = { nounwind readonly }

!llvm.ident = !{!0}
!dx.version = !{!1}
!dx.valver = !{!2}
!dx.shaderModel = !{!3}
!dx.resources = !{!4}
!dx.viewIdState = !{!9}
!dx.entryPoints = !{!10}

!0 = !{!"dxcoob 1.9.2609.5 (01b62ad47)"}
!1 = !{i32 1, i32 0}
!2 = !{i32 1, i32 9}
!3 = !{!"ps", i32 6, i32 0}
!4 = !{!5, null, null, null}
!5 = !{!6, !8}
!6 = !{i32 0, %"class.Texture2D<vector<float, 4> >"* undef, !"", i32 0, i32 0, i32 1, i32 2, i32 0, !7}
!7 = !{i32 0, i32 9}
!8 = !{i32 1, %"class.Texture2D<float>"* undef, !"", i32 0, i32 1, i32 1, i32 2, i32 0, !7}
!9 = !{[46 x i32] [i32 44, i32 4, i32 15, i32 15, i32 0, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 7, i32 0, i32 15, i32 15, i32 0]}
!10 = !{void ()* @PSMain, !"PSMain", !11, !4, null}
!11 = !{!12, !38, null}
!12 = !{!13, !16, !18, !20, !22, !24, !26, !29, !31, !33, !35}
!13 = !{i32 0, !"SV_Position", i8 9, i8 3, !14, i8 4, i32 1, i8 4, i32 0, i8 0, !15}
!14 = !{i32 0}
!15 = !{i32 3, i32 3}
!16 = !{i32 1, !"TEXCOORD", i8 9, i8 0, !14, i8 1, i32 1, i8 4, i32 1, i8 0, !17}
!17 = !{i32 3, i32 15}
!18 = !{i32 2, !"TEXCOORD", i8 9, i8 0, !19, i8 1, i32 1, i8 4, i32 2, i8 0, !17}
!19 = !{i32 1}
!20 = !{i32 3, !"TEXCOORD", i8 9, i8 0, !21, i8 1, i32 1, i8 4, i32 3, i8 0, !17}
!21 = !{i32 2}
!22 = !{i32 4, !"TEXCOORD", i8 9, i8 0, !23, i8 1, i32 1, i8 4, i32 4, i8 0, !17}
!23 = !{i32 3}
!24 = !{i32 5, !"TEXCOORD", i8 9, i8 0, !25, i8 1, i32 1, i8 4, i32 5, i8 0, !17}
!25 = !{i32 4}
!26 = !{i32 6, !"TEXCOORD", i8 9, i8 0, !27, i8 1, i32 1, i8 4, i32 6, i8 0, !28}
!27 = !{i32 5}
!28 = !{i32 3, i32 7}
!29 = !{i32 7, !"TEXCOORD", i8 9, i8 0, !30, i8 1, i32 1, i8 4, i32 7, i8 0, !17}
!30 = !{i32 6}
!31 = !{i32 8, !"TEXCOORD", i8 9, i8 0, !32, i8 1, i32 1, i8 4, i32 8, i8 0, !17}
!32 = !{i32 7}
!33 = !{i32 9, !"TEXCOORD", i8 9, i8 0, !34, i8 1, i32 1, i8 4, i32 9, i8 0, !17}
!34 = !{i32 8}
!35 = !{i32 10, !"TEXCOORD", i8 9, i8 0, !36, i8 1, i32 1, i8 4, i32 10, i8 0, !37}
!36 = !{i32 9}
!37 = !{i32 3, i32 6}
!38 = !{!39, !40}
!39 = !{i32 0, !"SV_Target", i8 9, i8 16, !14, i8 0, i32 1, i8 4, i32 0, i8 0, !17}
!40 = !{i32 1, !"SV_Depth", i8 9, i8 17, !14, i8 0, i32 1, i8 1, i32 -1, i8 -1, !41}
!41 = !{i32 3, i32 1}
